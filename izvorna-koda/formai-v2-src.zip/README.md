# FORMAI v2

Nova aplikacija FORMAI — AI trener za kolo, tek, moč in prehrano, v slovenščini. Nadomesti `forma-app` (formai.si).

- **Sklad:** Vite + React + TypeScript, PWA (vite-plugin-pwa), IndexedDB (idb), Leaflet. Dizajn iz `FORMAI-dizajn-v2.html`.
- **Struktura:** `src/domain` (čista logika, testirana) · `src/data` (IndexedDB, migracija iz v1) · `src/state` (store) · `src/screens` · `src/ui` · `src/styles`.
- **Načela:** lokalno-prvo; sledi nikoli v oblak; vsaka aktivnost nosi izvor (`aiEligible`, `geoRetain`) — pravila berejo zastavice; varovalke prehrane so v aritmetiki, ne v promptu.

```bash
npm install
npm run dev      # http://localhost:5173
npm test         # vitest
npm run build    # dist/ → GitHub Pages
```
