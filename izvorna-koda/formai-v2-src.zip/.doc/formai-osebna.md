# FORMAI — osebna aplikacija, cilj Franja 2027 (stanje 24. 9. 2026, v3.18)

Blažev sklep: FORMAI je samo zanj. Od 22. 9. je vse podrejeno enemu cilju: **postati res dober kolesar do Maratona Franja 2027** (velika, 156 km, nedelja 13. 6. 2027 — franja.org). Teža, moč in prehrana služijo temu; kar odvrača, je odstranjeno.

v3.1 (22. 9.): Blaž ne vpisuje več ciljne teže ali ciljnega FTP — **aplikacija ju izračuna sama**, pove, koliko jesti vsak dan in na kolesu, ob prvem cilju pokaže vodnik in ga pelje skozi vsak trening.

## Kje je kaj

- **V živo:** https://formai.si/ (koren). `forma-trener.html` → `/`, `kalorije.html` → `/#/prehrana`, `/v2/` → preusmeritev + odjava starega SW.
- **Repo:** `Poni-9/forma-app` (javni, GitHub Pages). **Izvorna koda:** `izvorna-koda/formai-v2-src.zip` (brez `MARKETING.md`) + README.
- **Gradnja:** `npm ci && npm test && BASE_PATH=/ npx vite build` → `dist/` v koren repozitorija. Objava prek GitHub → Upload files (najprej `assets/`, nato `index.html` + `sw.js`, nato zip). Kratko sporočilo commita (< 50 znakov). Pred objavo `new Function` / `node --check`, preverba, da so vse datoteke iz predpomnilnika SW v paketu; po ~75 s `curl` + SHA primerjava.

## Samodejni cilji (src/domain/nutrition/body.ts, src/domain/training/goal.ts)

- **Najboljša teža:** maščoba izmerjena ali ocena iz BMI (Deurenberg 1991: 1,2·BMI + 0,23·starost − 10,8·spol − 5,4) → pusta masa ostane, cilj ~10 % maščobe (ženske 18 %); spodnja meja BMI 20,5 (ž 19,5), nikoli nad trenutno; omejeno s časom: največ 0,45 kg/teden v 68 % tednov do dirke. Deficit se ustavi, ko je dosežena.
- **Največji možni FTP do dirke:** prirastek po ravni W/kg (< 2,5: 26 %, < 3,25: 20 %, < 3,8: 15 %, < 4,3: 10 %, < 5: 6 %, sicer 3 %) × (ure/12)^0,8 × (tedni/38)^0,75; realno = 65 % prirastka.
- **Blaž (profil v živo 22. 9.: 78 kg, FTP 240, 14 h):** najboljša teža **71,5 kg** (razpon 70,5–73,0), FTP realno **274 W**, največ **293 W**, W/kg 3,08 → **4,10** (realno 3,83), tempo ~0,25 kg/teden. Pri 12 h: 288 W in 72 kg = 4,00.
- Cilj sezone (GoalSheet): vpiše samo dirko, FTP zdaj, težo, (maščobo, če jo ve), ure 8–14, čas treninga, moč 0/1/2 — izračun se pokaže v živo pred potrditvijo.

## Model načrta (src/domain/training/planner.ts)

- **Makrocikel do dirke**, bloki 3 + 1 šteti nazaj od taperinga: osnova → gradnja (12 tednov) → specifično (8 tednov) → tapering → teden dirke → »po dirki« 2 tedna, nato 12-tedenski cikli.
- **Teden (80/20):** pon počitek · tor VO2max + moč jedro · sre Z2 · čet sweet spot / prag / »Kladje« · pet regeneracija + moč noge · sob dolga Z2 (gradnja: tempo v zadnji uri; specifično: simulacija Franje) · ned Z2 ali skupinska.
- **Ure:** blok 0,88 / 1,0 / 1,12 / razbremenitev 0,52; v osnovi rampa 85 % → 100 % v 12 tednih.
- **Testi FTP:** uvodni v 1. tednu (če FTP > 28 dni), nato v razbremenilnih tednih vsakih 8 tednov. 5-min test → ocena VO2max (10,8 × W/kg + 7).

## Vodenje prehrane (src/domain/nutrition/energy.ts, dayplan.ts)

- **Dnevni cilj** = poraba + načrtovan trening (iz FTP) − deficit dneva. Tla: max(BMR, 1500/1200, BMR + pol treninga, poraba − 750); pod 18 brez deficita.
- **Deficit dneva:** poln na lahkih dneh; pol na ključnem treningu / testu / dolgi ≥ 3 h in v specifični fazi; 0 v taperingu, tednu dirke in na najboljši teži. Samo pri obrokih, nikoli na kolesu.
- **Razpored obrokov** (Prehrana → »Danes jej po načrtu«): obroki po času treninga (zjutraj / popoldne / zvečer), vsak s kcal, beljakovinami, OH in primerom s količinami (kosmiči, riž, piščanec, testenine, tuna …); kalorije goriva na kolesu so že vštete.
- **Gorivo na kolesu (rideFuel):** g/h po vrsti seje (VO2max/prag ≥ 75 min 70, dolga ≥ 150 min 60, simulacija 80, dirka 85, Z2 ≥ 90 min 40, kratke/regeneracija 0), od 30. minute. Seznam se sešteje: domači izotonik (750 ml + 40 g sladkorja/maltodekstrina + ščep soli = 40 g) + ploščice / banane / geli; tekočina 600–700 ml/h, vrečke za dolivanje na postanku. **Časovnica:** opomnik vsakih 20 min (od 30. min, ne v zadnjih 15 min), trda hrana enakomerno razporejena, opomnik za dolivanje.
  - Primer VO2max 4 × 4 (75 min): 1 bidon izotonika + 1 bidon vode + 1 gel, hrana 0:30 gel, skupaj ~55 g OH, ~0,9 l.
  - Primer dolga Z2 3 h 25: 2 bidona izotonika + 1 vrečka za dolivanje + ploščica + banana, hrana 0:30 ploščica, 2:10 banana, skupaj ~175 g, ~2 l.

## Izvajalnik treninga (src/screens/Vadba.tsx)

- **Pred začetkom:** kaj te čaka (koraki z vati), zakaj, vzemi s seboj + urnik goriva, kaj pojesti prej; pri moči tehnika vsake vaje.
- **Med vožnjo:** en korak naenkrat z vati, RPE, kadenco; pisk 3 s pred menjavo; zaslon ostane prižgan; **opomnik za gorivo** (pisk + vibracija) po časovnici — med intervalom/testom počaka na prvi odmor; tap ga zapre.
- **Po koncu:** obnova (beljakovine + OH v 45 min), kaj sledi, vožnja iz Garmina pride prek intervals.icu.

## Vodnik »Kako deluje« (src/ui/Guide.tsx)

6 korakov s Blaževimi številkami: cilj (W/kg, najboljša teža, FTP), dejanski teden iz načrta (ključni treningi krepko) in cone v vatih, vsak trening, prehrana (današnji cilj, gorivo), jutro in testi (datum naslednjega testa), trener. Pokaže se enkrat, ko je cilj nastavljen (`settings.guideSeen`), kadarkoli prek »Kako deluje«.

## AI

- Persona: osebni kolesarski trener, vedno konkretne številke (vati iz FTP, W/kg, g/h, kcal, datumi), brez markdown, metoda 80/20 in 3 + 1; kontekst vsebuje cilj, samodejne cilje in metodo izračuna, mejnike, fazo, današnji cilj, razpored obrokov in gorivo za današnjo vožnjo.
- Strava nikoli v AI (tudi ne posredno), `sanitizeGaps()` na vseh AI besedilih, zdravstveni pridržek ob kalorijah in planu.

## Odstranjeno kot motnja

Karta pokritosti (in Leaflet), neobvezna hoja ob počitku, moč potisk/poteg, testi zgibov/sklec, drog za zgibe, ročna ciljna teža in ciljni FTP.

## Za Blaža

- Na Danes: **Nastavi cilj** → preveri FTP (240) in težo → izberi ure (predlog 14 h, ker ima v profilu 15) → **Potrdi in sestavi načrt**. Nato se odpre vodnik.
- Stehtaj se zjutraj 3× na teden; 20-min test FTP je v četrtek prvega tedna.
- AI brez omejitve: Firestore `proUsers/<uid>` → `pro: true` (čaka na Blaževo dovoljenje).

## Preverjeno 22. 9. 2026 (v3.1)

60/60 testov, `tsc` čist, E2E 390 px (cilj → vodnik → Danes → Prehrana → Vadba; opomnik goriva z lažno uro: 30. min med intervalom → prikazan v 32. min v odmoru; 0 napak), objava: index.html, sw.js, `index-DvJiCork.js`, `index-Bvj18HwO.css`, zip na formai.si enaki zgrajenim, vseh 15 datotek iz predpomnilnika dosegljivih; v Blaževem Chromu teče `index-DvJiCork.js` pod novim SW.

## v3.2–v3.3.1 (22. 9. popoldne)

- **Sinhronizacija v oblak popravljena:** Firestore je zavračal cel zapis zaradi polj `undefined` pri uvoženih vožnjah (notes, exercises, ext.*) — s tega računalnika se ni nikoli nič shranilo. Zdaj `cloudSafe()` očisti zapis pred `setDoc`; prva združitev naprave velja šele po uspešni izmenjavi (`remoteTs`), da se ob prvem uspehu podatki združijo, ne prepišejo.
- **AI brez omejitve:** `proUsers/QUVAYjAF7ucaM86bmYkQDLGI50C2` → `pro: true` obstaja od 27. 7.; strežnik (aiLog `pro: true`) ga upošteva. Oznaka »AI 10/dan« je bila napačna, ker poti `/stripe/status` na nameščenem strežniku ni (404) — aplikacija zdaj bere `proUsers/{uid}` neposredno. Nameščena različica strežnika je starejša od `repo/server-index.js` (nima Stripe poti; `strava: true`).
- **Trase za vsak dan:** knjižnica tras samo na napravi (KV `routes.v1`) iz Garmin voženj prek intervals.icu (latlng = `data`/`data2`, višine), brez Strave. Analiza: dolžina, vzpon, profil vsakih 50 m, klanci (≥ 35 m, ≥ 500 m, ≥ 3 %), krog, smer. Izbor po treningu: VO2max/prag/test → klanec, kjer interval traja dovolj pri ciljnih vatih (ponovitve gor–dol), Z2/regeneracija → ravno, dolga → dolžina; čas s fiziko (moč, teža + 9 kg, CdA 0,32) umerjen na njegove čase; start > 3 km od doma (Radovljica, Preddvor, Tolmin) močno kaznovan razen za dolgo. Blaž: 24 tras, 18 krogov; domače trase nimajo klanca za VO2max → predlaga ravni odsek ali novo traso.
- **Nova trasa:** BRouter (brouter.de, profil `fastbike-lowtraffic`, CORS dovoljen) — krog od doma, za Z2 najbolj ravna od treh smeri, za intervale čez domači klanec, dolžina po času treninga. Pošlje se samo začetna točka in obrati.
- **Kje:** Danes (kartica Trasa z orisom, profilom, navodilom za intervale, Druga / Nova trasa / GPX / Zemljevid), Plan (razširjen dan = načrt dneva: koraki z vati, trasa, gorivo, prehrana ta dan), Vadba (pregled pred treningom), AI kontekst (brez imen in koordinat).
- **GPX:** Strava → Dashboard → My Routes → Create New Route → uvozi (samo splet); Garmin Connect → Proge → Uvozi.

## Strava (stališče 22. 9. 2026)

Strava API Policy (velja od 1. 6. 2026) §5.3 prepoveduje Stravine podatke v kateri koli AI aplikaciji, izrecno tudi »ingestion into a context window«; izjeme za 10-uporabniški (Standard) nivo ni — ta omejuje samo število uporabnikov. Hramba največ 7 dni (§6.2), API aplikacija zahteva plačano naročnino. Edina dovoljena pot do AI: Stravin MCP (§3.5). Blaž je vprašal, ali lahko, ker je »samo zanj« — odgovor: ne; vožnje že pridejo z Garmina prek intervals.icu. Client ID/secret sta na strežniku (Cloud Run), aplikacija jih namenoma ne uporablja.

## Preverjeno (v3.3.1)

71/71 testov, `tsc` čist, E2E (trase: kartica, Druga, GPX 637 točk z višinami, nova trasa z BRouterjem, načrt dneva, Vadba; opomnik goriva; vodnik) brez napak; na formai.si enake datoteke; v Blaževem Chromu teče `index-C5lCg0Wn.js`, »usklajeno«, »AI brez omejitve«, knjižnica 24 tras, BRouter z formai.si deluje.

## v3.4 — »trening v resnici« (22. 9. zvečer)

Blaž je hotel, da aplikacija sama naredi to, kar je Claude naredil s Strava MCP. Vse je iz Garmin voženj prek intervals.icu (dovoljeno, tudi za AI), ne iz Strave.
- **Podatki:** vožnje dobijo `hrZoneSec` (čas v 7 conah utripa po LTHR iz intervals.icu), `hrZoneTop`, `deviceWatts`, `trainer`; enkratni ponovni uvoz leta (KV `icu.zones.v1`). LTHR/max/mirovni utrip iz intervals.icu, če manjkajo.
- **Merilnik moči:** zaznan iz voženj (`gear.powerMeter`, `powerMeterAuto`; ročno v Nastavitve → Oprema). Brez merilnika so vsi cilji v utripu po LTHR (Z1 < 81 %, Z2 81–89 %, Z3 90–93 %, Z4 94–100 %, Z5 > 100 % · RPE 9), vati samo orientacija; FTP test postane utripni (LTHR). Blaž: brez merilnika, LTHR 184 → Z2 149–164.
- **Načrt raste od dejanskih ur:** `profile.baseHours` = povprečje polnih tednov (do 8); zgornja meja ur = max(4, 1,2 × base) × 1,1^teden (razbremenitev 60 %). Pri < 5,5 h en ključni trening na teden. Napoved FTP uporablja povprečne dejanske ure načrta. Blaž: 3,5 h → ta teden ~4 h, 14 h v ~13 tednih; načrt od jutri samodejno prestavljen.
- **Po vožnji:** Danes pokaže, ali je vožnja ustrezala načrtu (VO2max: ≥ 10 min nad pragom; prag: ≥ 60 % dela v Z3+; Z2: ≥ 75 % lahko …), gumb »Prestavi na kasneje v tednu« zamenja ključni trening z naslednjim lahkim dnem. Blaž danes: »VO2max ni bil narejen — bila je lahka (Z2) vožnja · 1 h 56 min · 92 % lahko · 4 min nad 172«.
- **Napredek → Trening v resnici:** ure po tednih proti načrtu, 80/20 po utripu (Blaž: 83/10/7), ključni treningi 2 tedna, aerobna učinkovitost (km/h na 100 udarcev na ravnih vožnjah; Blaž +16 %, šumno), merilnik moči.
- **AI trener** dobi vse to v kontekst in navodilo, naj najprej primerja resnico z načrtom; brez merilnika daje cilje v utripu.
- **Trase:** VO2max ponovitve tudi na strmih klancih do 14 %; nova trasa čez klanec do 15 km od doma (npr. Šmarjetna gora).
- Preverjeno: 76/76 testov, E2E (cilj z rampo, preverba vožnje, prestavitev, kartica, trase, gorivo), v Blaževem Chromu: 39/40 voženj s conami, merilnik = ne, baseHours 3,5, današnja vožnja povezana in ocenjena.
- Opazka: vožnja 27. 8. je v Stravi, v intervals.icu je ni (verjetno posneta samo s telefonom) — v FORMAI teden 24. 8. kaže 0 h.
- **v3.4.1 (isti večer):** zamujen ključni trening se prestavi samo na lahek dan, ki ima pred in za sabo dan brez ključnega/testa/dolge; sicer Danes napiše »Izpusti ga … Naslednji ključni: …« (brez nizov trdih dni). Gumb pove dan (»Prestavi na četrtek«). Blaž ta teden: čet test, sob dolga → izpusti VO2max. Objavljeno `index-EtNw0IEJ.js`, 76/76 testov, E2E oba primera, v Blaževem Chromu preverjeno.
- **v3.4.2 (22. 9. zvečer):** Blaž je vprašal, zakaj ima 4 h, če je »idealno 12 h« in je izbral 14 h. Pomeni: 14 h = izbrani polni teden (doseže ga 28. 12.; bloki 12,5 → 14 → 15,5 h, razbremenilni 7,5 h), 12 h = povprečje sezone z rampo (napoved FTP: idealno 288 W; brez rampe 293 W), 4 h = ta teden od dejanskih ur (Strava zadnjih 8 tednov 3,7 h, zadnje 4 tedne 2,4 h, največ 10,3 h konec julija). Popravljeno: graf »Pot do dirke« riše načrtovane ure (prej fazni volumen — prvi tedni so bili videti polni), »Opravljeno« šteje dejanski čas povezane vožnje (1 h 56 min namesto 1 h 15 min), pri cilju tedna in v idealnem scenariju piše »14 h od 28. 12.« / »povprečno 12 h čez sezono«. Možnosti hitrejšega začetka (model): začetek 6 h → 14 h od 7. 12., povp. 13 h, 291 W; začetek 7 h → od 9. 11., 13,5 h, 293 W. Odločitev čaka na Blaža. Objavljeno `index-1ATLJUcb.js`, 76/76 testov, preverjeno v Blaževem Chromu.
- **v3.5 (22. 9. zvečer):** Blaž: »kamot več peljem, to je blo sam ker nism meu časa — začni na več.« V Uredi cilj je zdaj izbira **»Načrt začne pri«** (4 · 5 · 6 · 7 · 8 · 10 h, predlog iz voženj = 1,2 × povprečje); shranjuje se kot `baseHours` = izbira / 1,2, tako da rampCap prvega tedna da točno izbrano številko. Plan in GoalCard pišeta začetek (`rampStart`), ne surovega baseHours. Nastavljeno na **7 h**: ta teden sre Z2 70, čet test 60, pet regen 45, sob dolga 120, ned Z2 50 (danes je že opravljen); rast 7 → 7,5 → 8,5 → 9,5 → *6* → 11 → 12,5 → 13,5 → *7,5* → 12 → 13,5 → 15,5 h, 14 h od 7. 12.; napoved FTP 293 W / realno 274 W (prej 288/271). Opozorilo zanj: ta teden bo skupaj ~8,8 h proti 2,4 h povprečja zadnjega meseca, forma v nedeljo ≈ −18. V profilu ima **dirko 97 km (Mala Franja)** in **moč izklopljeno** — velja preveriti. Objavljeno `index-DTC2ALwj.js`, 76/76 testov, E2E izbire začetka, preverjeno v Blaževem Chromu.

## v3.6 — telefon: hitrejši uvoz in treningi na uro (23. 9.)

Blaž je hotel oboje: (1) uvoz vožnje takoj po vožnji, (2) strukturirani treningi na Garmin uro.
- **Uvoz:** samodejni uvoz iz intervals.icu ob zagonu/vrnitvi v aplikacijo zdaj največ na 10 min (prej 3 h); `autoSyncIntervals` vrne število novih voženj. Na Danes gumb **»Preveri Garmin«** (ob Opravil, ko je danes kolo/test in je intervals povezan) → prisilni uvoz, toast, če nove vožnje še ni.
- **Treningi na uro:** `src/domain/intervals/workouts.ts` — `icuWorkout(day, p)` prevede dan (kolo/test, ne dirka/moč/tek/počitek) v besedilo intervals.icu (koraki `- Cue 15m 81-89% LTHR`, bloki `Interval 4x` z delom in odmorom, test `95-105% LTHR`; z merilnikom vati `259-276w`, cone v % FTP). Cue brez Z2/števil/% (razčlenjevalnik). `workoutDiff` primerja z obstoječimi dogodki (ključ uid **ali** external_id `formai-<datum>`): create (bulk POST `?upsertOnUid=true`), update (PUT /events/{id}), remove (samo naši, tudi dvojniki). Tuji dogodki nedotaknjeni. `client.ts`: fetchEvents/createEvents/updateEvent/deleteEvent (CORS z formai.si preverjen: GET/POST/PUT/DELETE).
- **Store:** `pushWorkouts(manual)` za naslednjih 14 dni, `schedulePushWorkouts(delay, ifStale)` ob vsakem savePlanDays/savePlanDay (2,5 s zamik), ob zagonu in vrnitvi (če > 6 h od zadnjega). Stanje `icuWorkouts` {at, n, changed, removed, err} v KV `icu.workouts`. Nastavitev `settings.intervals.pushWorkouts` (privzeto vklopljeno). UI v Več → Uvoz (Garmin): »Treningi na uro« vklop/izklop, status, »pošlji zdaj«, navodilo za intervals.icu Settings → Garmin → Upload planned workouts.
- Cilji v % LTHR se v intervals.icu pretvorijo z njihovim LTHR (184, isti kot v FORMAI). Če Blaž po testu spremeni LTHR v FORMAI, ga mora tudi v intervals.icu.
- Preverjeno: 80/80 testov, E2E z lažnim intervals.icu (5 treningov ustvarjenih, star formai dogodek pobrisan, tuj pusti, druga runda brez sprememb, sprememba dneva → en PUT, tudi če strežnik uid zavrže; gumb Preveri Garmin). Objavljeno 23. 9. ~13:05 (`index-DOYA9VGO.js`); ob prvem odprtju v Blaževem Chromu poslanih 11 treningov v njegov koledar intervals.icu (intervals.icu **uid prepiše s svojim**, obdrži pa external_id → ujemanje po external_id je nujno). Drugo pošiljanje: »že enak načrtu (11 treningov)«.

- **Opazka 23. 9.:** Blaž je sam ob 11:33 v Uredi cilj izbral **začetek 8 h** (baseHours 6,67); ob tem se je `ftpDate` postavil na 23. 9., zato četrtkov 20-min test ni več v načrtu (čet = Sweet spot 3 × 12). Vprašan, ali hoče test nazaj.

## v3.7 — pogovor s trenerjem se sinhronizira in ima spomin (23. 9.)

Blaž: »pogovor s trenerjem naj ne gre vsakič ko se prijavim znova … naj si zapomne in da samo nadaljujem.« Vzrok: pogovor je bil samo v lokalnem KV `ai.chat` (na telefonu prazen).
- Pogovor je zdaj v `settings.coach { msgs, summary }` → sinhroniziran prek Firestore kot vse nastavitve (zadnji zapis zmaga). Enkratna selitev iz `ai.chat` (Blaž: 2 sporočili preneseni).
- Spomin: trener vidi zadnjih 12 sporočil dobesedno + **povzetek** starejših; ko pogovor preseže 40 sporočil, gre najstarejših 20 v povzetek (en AI klic, ≤ 1500 znakov, »zapiski trenerja«), na zaslonu ostane ≥ 20. `trimChat` testiran. Gumb »nov pogovor« pobriše oboje.
- Objavljeno `index-Buqy2x9U.js`, 81/81 testov, E2E selitve; v Blaževem Chromu preverjeno (coach 2 sporočili, legacy prazen; pošiljanje na uro stabilno: 11 treningov, brez sprememb).

## v3.7.1 — vreme v oknu treninga (23. 9.)

Blaž: »piše megla in 18 °C, zunaj je sončen dan.« Vzrok: Open-Meteo **dnevna** koda je najhujša koda dneva (megla 3–8 h), tmin–tmax cel dan. Zdaj urni podatki + `current`: za vsak dan povzetek **okna treninga** po `profile.trainTime` (zjutraj 7–11, popoldne 13–18, zvečer 17–21): prevladujoča koda (dež prevlada pri ≥ 50 %), min–max temperatura v oknu, max padavine/veter; danes: če okno teče → od zdaj do konca, če je mimo → naslednje 3 ure; »zdaj X °C«. Predpomnilnik 1 h, ključ `wx7h.<lat>.<lon>.<od>-<do>`; ob spremembi kraja ali časa treninga osveži. Planer dobi dež po oknu. Testi `weather.test.ts` (3). Pri Blažu: »jasno · 17–18 °C popoldne · zdaj 17 °C«. Objavljeno `index-zWWhM_Fb.js`, 84/84.
- **Garmin:** Blaž se je sam prijavil v Garmin SSO; v intervals.icu je »Naložite načrtovane treninge« vklopljeno (Vse vrste, razpon moči 2,5 %, utripa 1,5 %, »Nazadnje naloženo 1 minute ago«) → treningi so v Garmin Connect. intervals.icu ima težo 78 kg, FORMAI 79.
- Test v četrtek: Blaž noče zdaj (»bom kasneje«).

## v3.8 / v3.8.1 — trasa po korakih treninga, samodejna nova, »Na uro« (23. 9.)

Blaž: zemljevid na Garmin uro, dolžina prilagojena intenzivnosti, da pride domov točno ob koncu; lahko tudi nova pot.
- **Garmin nima poti za proge iz intervals.icu** (API Routes so samo zaznane trase; Course = skupinski dogodki; Garmin Courses API zaprt). Edina pot: GPX → Garmin Connect (app: »Odpri z / Deli v Garmin Connect« → proga → sinhronizacija na uro, ~1 min; splet: Proge → Uvozi). V RouteCard gumb **»Na uro«** (Web Share API z GPX datoteko, ime »FORMAI 24. 9. Sweet spot …«), na napravah brez deljenja datotek ostane GPX + navodilo.
- **Čas trase po korakih treninga** (`workoutMinutes` v match.ts): po profilu trase vsak 50 m odsek pri moči trenutnega koraka (Z1 0,5 · Z2 0,65 · Z3 0,83 · Z4 0,95 · Z5 1,1 × FTP, delo = sredina ciljnih vatov), koraki raztegnjeni s k (paceFactor). Za klanec s ponovitvami ostane enakomerna ocena + ponovitve. Kartica: »Domov prideš, ko se trening konča« / »~X min po koncu« / »~X min pred koncem«.
- **Nova trasa:** makeLoop 3 popravki polmera na ±7 %. Za trde treninge obrat na klancu tam, kjer se interval izteče (`climbTurnPoint`), ne na vrhu; če s klancem ne pride v ±15 %, raven krog (intervali na ravnem).
- **Samodejno** (`autoRoutes` ob zagonu/vrnitvi, danes + jutri): če nobena tvoja trasa ne ustreza (±12 %) ali si najboljšo vozil v zadnjih 3 dneh, nariše novo; narisano, ki ne ustreza, zamenja (enkrat na dan). Blaž jutri (Sweet spot 3 × 12, 90 min): najprej 27,7 km čez 10-km klanec (+19 min), po popravku raven krog 45,3 km, ~1 h 29 → »Domov prideš, ko se trening konča«.
- Preverjeno: 86/86 testov, E2E trase (ARRIVE besedilo, GPX 658 točk, BRouter), v Blaževem Chromu. Objavljeno `index-BZuE8YiY.js`.
- Danes 23. 9. je Blaž vozil Z2 1 h 20 min (100 % lahko, povp. utrip 149) — uvoz in ocena sta se zgodila sama.

## v3.9 — manj je več (23. 9.)

Blaž: »Aktivnosti in Analitika sta brez pomena — daj ven nepomembno, ohrani pomembno.«
- Zavihki (telefon): **Danes · Plan · Prehrana · Trener · Napredek** — brez »Več«. Namizje: isti + Nastavitve. Nastavitve za avatarjem (obe postavitvi), Uvoz iz Nastavitev → »Ura in uvoz → Uredi uvoz«.
- Odstranjeno: zaslon **Analitika** (`AnalitikaFull.tsx` izbrisan; forma/obseg/80-20 pokriva »Trening v resnici«, forma je na Danes), meni **Več** (`Vec` v Ostalo.tsx), zavihek **Aktivnosti** (zaslon ostane samo kot »Vpiši vadbo« / ročni vnos z Danes in Uvoza), v Napredku kartica **»Kakšen športnik si«** (AI profil) in gumb »Forma in cone«; kartica **Moč** se pokaže samo, če je moč vklopljena ali so vadbe moči. Na Danes spodaj: »Slikaj obrok« in »Vpiši vadbo« (Napredek je zavihek). Stare poti #/vec in #/analitika preusmerijo na Napredek.
- Objavljeno `index-D2-98Uz8.js` (paket manjši za ~18 kB), 86/86 testov, E2E nav (zavihki, preusmeritve, Napredek brez odstranjenih kartic), preverjeno v Blaževem Chromu. Sinhronizacija zelena.
- Kandidati za naslednji rez (nisem sam odločil): Nastavitve → »Odtenek zelene«, Prehrana → tedenski jedilnik z nakupovalnim seznamom, Napredek → mesečna AI ocena in »Doslednost«.

## v3.10 — gorivo z izdelki, oblačila, trener brez ponavljanja (24. 9. dopoldne)

Blaž: naj pove, koliko česa (Frutabela, izotonik …), kako se obleči (tudi dež), trener naj ne ponavlja »zadnjih 8 tednov / zaostanek« pri vsakem odgovoru, vrstica za pisanje mora biti vedno na vidiku, kamera v Prehrani bolj vidna, Plan naj se odpre na današnjem dnevu.
- **Komplet za na kolo** (Nastavitve → Prehrana → »Kaj imaš za na kolo«, `profile.fuelKit`): domači izotonik 40 g · kupljen izotonik 45 g · Frutabela 19 g · ploščica 40 g · banana 25 g · datlji 30 g · sendvič 45 g · riževi kolački 30 g · gel 25 g OH; privzeto domači izotonik + Frutabela + banana + gel. `rideFuel(day, kit)` izbere pijačo in razporedi trdo hrano po kompletu (vrstni red po vrsti vožnje: trda / dirka / dolga / lahka), napiše izdelek s količino (»1 × Frutabela (sadna ploščica 30 g ≈ 19 g OH)«) in dolivanje glede na pijačo.
- **Oblačila:** `clothing(wx)` iz vremena v oknu treninga (min temp, dež, veter) → »Obleci: …« na Danes in v razširjenem dnevu Plana (npr. 9–14 °C z dežjem: dolge hlače, termo majica + dolgi rokavi, rokavice, kapa pod čelado, vetrovka, nepremočljiva jakna, čepica s šiltom).
- **Trener:** nadaljevanje pogovora = odgovor samo na zadnje vprašanje, ≤ 120 besed, brez ponavljanja stanja in brez »Naslednji korak«, razen če vpraša. Vnosna vrstica je lepljiva nad zavihki (`.composer`), pogovor se odpre na koncu.
- **Prehrana:** »Slikaj obrok« kot glavni gumb v glavi (kamera), čip »vpiši« za ročni vnos. **Plan:** odpre se na današnjem dnevu (`dan-<datum>`), pretekli dnevi strnjeni v eno vrstico.
- Objavljeno `index-DVtR1xQE.js` + `index-Se8i2Jei.css`, 87/87 testov, E2E ux (gorivo, oblačila, skok na danes, vrstica nad zavihki, kamera, komplet) brez napak.

## v3.11 — uvoz pove resnico o Stravi, izklop treningov jih pobriše (24. 9.)

Blaž: »a lahko moj brat naredi svoj profil?« in nato posnetek z Gašperjeve naprave: »Povezan kot Gašper Gregorc« (intervals.icu `i281064`), »Treningi na uro vklopljeno · 10 treningov v koledarju«, toast »intervals.icu ni vrnil aktivnosti v tem obdobju« — »zakaj ne dela?«.
- **Vzrok (zelo verjeten):** Gašperjev intervals.icu dobiva vožnje s **Strave**. intervals.icu po Stravinih pravilih takih aktivnosti ne izda drugim aplikacijam — API vrne samo »stub« (id, datum, `source: STRAVA`, opomba). FORMAI jih je tiho preskočil (brez vrste/trajanja) še preden jih je preštel, zato se opozorilo o Stravi ni nikoli sprožilo in je pisalo »ni aktivnosti«. Njegov račun ni nov (`i281064` < Blažev `i328559`), leto brez ene same uporabne vožnje pri tekmovalcu → Strava.
- Blaževa naprava ni prizadeta: po osvežitvi še vedno Blaž Gregorc `i328559`, zadnja sinhronizacija 11:33 (Gašperjev zapis ob 11:39 ni šel v Blažev račun → Gašper ima svoj Google račun ali ni prijavljen).
- **Popravek:** `isStravaStub` + `stravaStubs`/`total` v `fetchActivities` (izvor se preveri pred vsem drugim); `importDiagnosis` (`src/domain/intervals/diagnosis.ts`, KV `icu.diag`) → okence v Uvozu: »7 voženj je s Strave — FORMAI jih ne vidi« + rešitev (intervals.icu → Settings → Garmin Connect → Connect, neposredno) + povezava na intervals.icu/settings; prazen račun → »ura najbrž ni povezana« (+ »Import all Garmin data« za zgodovino); »Preveri Garmin« na Danes pove isti razlog.
- **Treningi na uro:** nova povezava ima pošiljanje **izklopljeno** (brez vprašanja ne pišemo v tuj koledar); obstoječa (Blaž) ostane vklopljena. Izklop zdaj **pobriše** naše dogodke (`formai-…`, danes +30 dni) iz koledarja intervals.icu (`removeWorkouts`), tuji ostanejo. Gašper ima od 11:39 v koledarju 10 treningov FORMAI — če jih noče, en klik na »vklopljeno«.
- Preverjeno: 92/92 testov (novi: stubi z in brez vrste, stari Stravin zapis s podatki, pojasnila, izklop), E2E z lažnim intervals.icu (7 stubov → okence; nova povezava brez klicev koledarja; vklop → 5 poslanih; izklop → 5 pobrisanih, tuj ostane), ux/nav brez napak. Objavljeno `index-B6NKjaZy.js` (CSS isti), v Blaževem Chromu teče.
- **Za Gašperja (odgovor Blažu):** svoja naprava + **svoj Google račun** (ločeni podatki); svoj intervals.icu z uro povezano neposredno; AI 10 klicev/dan, neomejeno z `proUsers/<njegov uid>` (strošek na Blaževem projektu); načrt je narejen za rekreativni cilj (Franja), za tekmovalca v ekipi je prej pomoč pri prehrani, gorivu, vremenu in trasah kot glavni trener.

## v3.12 — trener kot pogovor, ure do 20 h in »največ, kar gre«, imena goriva (24. 9.)

- **Trener** (Blaž: »se zmeša in ne vem, kje so odgovori«): prej so bili odgovori na treh mestih (kartica Pogovor zgoraj, Pregled tedna v svoji kartici, Nasvet za danes v svoji kartici, Prilagodi v toastu), vnosna vrstica pa pod njimi. Zdaj **ena časovnica** kot v aplikaciji za sporočila: vprašanja desno (zelena), odgovori levo z oznako (NASVET ZA DANES / PREGLED TEDNA / TEDEN PRILAGOJEN), ločilniki »danes / včeraj / 22. 9.«, najnovejše spodaj tik nad vrstico za pisanje; bližnjice »Kaj naj danes naredim? · Pregled tedna · Prilagodi ta teden« so v prilepljeni vrstici in odgovorijo v isti pogovor (`CoachMsg.kind`, `addToChat`; trener te odgovore vidi v kontekstu). Po odgovoru je tvoje vprašanje na vrhu zaslona. »Nov pogovor« zahteva drugi klik. Vse se shrani tudi po privolitvi (prej se je prvi odgovor po privolitvi izgubil).
- **Popravek »vrstica vedno na vidiku«:** aplikacija se pomika kot dokument, `.scroll` pa je imel `overflow-y: auto` → `position: sticky` je bil vezan nanj in se pri dolgem pogovoru ni prijel zaslona (v3.10 je bil preverjen samo s kratkim). Na Trenerju `.scroll.chat-page { overflow: visible; overflow-x: clip }`, vrstica 12 px nad zavihki.
- Persona: raven ocenjuj zadržano, brez hvaljenja; če FTP ni izmerjen z merilnikom, to najprej povej (Gašperjev odgovor »prehod med kontinentalnim profesionalcem in WorldTour« pri vpisanih 400 W brez merilnika).
- **Gorivo:** izbira »Kaj imaš za na kolo« je kazala rodilnik (»domačega izotonika«) → kratka imena (`FuelItem.label`: domači izotonik, kupljen izotonik, Frutabela, energijska ploščica, banana, datlji, sendvič, riževi kolački, gel); »pest dateljnov« → »pest datljev«.
- **Ure na teden** (Blaž: »zakaj je to vse, kar je možno … da vpraša, ali hočem na max, in pove, koliko ur, ali pa sam določim, koliko imam časa«): v Cilju sezone dve možnosti — **»Največ, kar gre · X h«** (`hoursAdvice`: 1,3 × najdaljši teden v zadnjem letu, 2 × povprečje leta ali 1,5 × zadnjih 8 tednov; brez voženj vpisane ure × 1,3; najmanj 8, največ 18 h, do 18 let 12 h; blizu dirke omejeno z rastjo +10 %/teden) ali **»Sam določim«** (6–20 h ali poljubno 3–20). `profile.hoursMode`. »Načrt začne pri« do 16 h. Blaž: največ = **13,5 h** (vrh 10,3 h × 1,3), ima izbranih 14 h in začetek 8 h (nič spremenjeno).
- **Načrt res doseže velike ure:** tedenska predloga se je prej ustavila pri ~14,7 h (sobota ≤ 5 h, sreda ≤ 3 h, nedelja ≤ 2,5 h). Nad ~14,5 h: sobota do 6 h, sreda in nedelja do 4 h, preostanek kot Z2 po ključnih treningih (do +90 min); razbremenilni teden nad 8 h ima daljše lahke dneve. 20 h → teden ~20 h; 12 in 14 h ostaneta enaka.
- Preverjeno: 101/101 testov (novi: pogovor, ure, velik obseg), E2E chat (telefon + namizje: vrstki red, vrstica prilepljena, pomik), hours (obe možnosti, shranjevanje), ux/nav/stub brez napak. Objavljeno `index-W6yRp8Bt.js` + `index-CJGtZkm-.css`; v Blaževem Chromu teče, pogovor 34 sporočil v novi časovnici.

## v3.13 — profesionalni obseg do 30 h (24. 9.)

Blaž: »vem, da profiji furajo več ur … naj bo tudi to možnost.«
- Za primerjavo (TOUR o študiji v Biology of Sport, feb. 2026: 32 kolesarjev WorldTour, 10 tednov priprav 2018–19): moški povprečno **19,1 h/teden**, najtežji teden 22,5 h; ženske 16,7 h / 20,1 h; ~70 % nizke intenzivnosti. 25–30 h le na pripravah.
- »Sam določim«: 6 … 20, **25, 30 h** ali poljubno 3–30; nad 20 h opomba s temi številkami. `targetHours` do 30 h.
- »Največ, kar gre« = **1,3 × najdaljši teden v zadnjem letu** (brez voženj: vpisane ure × 1,3); strop 18 h, višje samo, če si tak obseg že vozil: najdaljši teden (ali vpisane ure) + 6 h, največ 30 h; do 18 let 12 h. (Pravili »2 × povprečje leta« in »1,5 × zadnjih 8 tednov« odstranjeni — pri stalnih kolesarjih sta podvojila obseg.) Blaž ostane 13,5 h.
- Predloga tedna nad ~21 h (»profi«): petek 2 h lahko, sobota do 6,5 h, sreda in nedelja do 5,5 h, Z2 po ključnih treningih do +3 h; nad 24 h še ponedeljek 75 min lahkega vrtenja. 25 h → ~25 h, 30 h → ~30 h; nobena vožnja čez 6,5 h. Razbremenilni teden nad 12 h: lahki dnevi 2 h + petek 1 h.
- Preverjeno: 103/103 testov, E2E ure (30 h, besedilo), objavljeno `index-CXHkAtz6.js` (CSS isti). Pri nalaganju na GitHub se polje za sporočilo commita po nalaganju datotek ne da vedno izbrati s klikom (fokus ostane na izbirniku datotek) — vrednost nastavi JS (`#commit-summary-input` + dogodek input), gumb Commit klikni po koordinatah in preveri na /commits/main/<mapa>.

## v3.14 — trening in proga hkrati na uri (24. 9.)

Blaž: »da bom v Garmin uri videl poleg plana še zemljevid, da dam lahko navigacijo.«
- Blaževa ura iz voženj: **Garmin Forerunner 255** (40 od 42 voženj). FR255 **nima zemljevida s cestami** — pri progi pokaže črto poti, puščico in opozori, ko zaideš (Garmin forum; zemljevidi šele FR955/965).
- Samodejno progo na uro ne gre: Garminov program za razvijalce je ustavljen, intervals.icu prog ne pošilja (razvijalec 2021: trening je po času, proga po razdalji; ni implementirano). Trening gre sam (intervals.icu), proga z gumbom »Na uro« (deli GPX v Garmin Connect → »Send to Device«).
- Novo: `src/domain/routes/watch.ts` — `watchOf` (ura iz `deviceName` zadnjih voženj: zemljevidi da/ne, Edge), `watchSteps` (koraki: uvoz proge → na uri START → Bike, drži UP → Training → Training Calendar → Do Workout, drži UP → Navigation → Courses → Do Course, šele nato START; iskreno o zemljevidu; »prvič poskusi doma«), `courseName` (»FORMAI 25.9. Sweet spot 3 × 12«). RouteCard: po »Na uro« ali GPX se pokažejo koraki za tvojo uro, čip »kako na uri?«. GPX dobi `<type>cycling</type>`.
- Preverjeno: 107/107 testov (watch.test.ts), E2E trase (koraki za FR255, GPX ime in tip), objavljeno `index-PoI5qSN-.js` (CSS isti).

## v3.15 — sinhronizacija združuje naprave (24. 9. zvečer)

Blaž: »zaužite kalorije so se mi 2× že zbrisale … na telefonu sem imel, na računalniku pa ne … tudi na telefonu mi je enkrat izginilo.«
- **Vzrok:** sinhronizacija je bila »novejša naprava prepiše vse« (en dokument `formaSync/{uid}.v2`, zmaga višji `_ts`). Računalnik s staro kopijo je ob zagonu sam uvozil vožnjo iz intervals.icu (`touch` → nov `_ts`), pogosto preden je prebral oblak (tekma v `pullNow`: `localTs` se je bral po `getDoc`), in poslal svojo kopijo brez obrokov s telefona; telefon je nato »prevzel z druge naprave« (`replaceCollections`) in obroke izgubil tudi sam. Sprožilo se je tudi, ko je Claude odprl formai.si v Blaževem Chromu (24. 9. ~15:28). Dokazano s preizkusom dveh naprav (stara logika: računalnik 0 obrokov, nova: vsi).
- **Popravek:** `src/data/merge.ts` (čiste funkcije, simetrične — merge(a, b) = merge(b, a) — in idempotentne): obroki, aktivnosti in testi so unija po id-ju (zmaga novejši `updatedAt`, sličice in sledi ostanejo lokalne); izbris velja samo z **grobom** (`sync.tomb`: `m:<id>`, `a:icu:<id>`, `t:<id>`, 120 dni); ista vožnja iz intervals.icu pod dvema lokalnima id-jema postane ena (najstarejši id, najnovejša vsebina, `done.activityId` preslikan), prav tako FIT + intervals ±90 s; načrt po dnevih (cel dan iz naprave, ki ga je spremenila zadnja); check-in po datumu z dopolnjevanjem; profil novejši, a prazna naprava nikoli ne prepiše pravega; nastavitve novejše + unija testov, mesečnih ocen in pogovora s trenerjem (brez obujanja že povzetih sporočil).
- `sync.ts`: branje, združitev in zapis v eni **Firestore transakciji** (`runTransaction`, `set(…, { mergeFields: ['v2'] })` — polji stare aplikacije ostaneta), zapis samo ob razliki (primerjava urejenih zapisov, brez »prepiranja«), lokalno se zapiše samo razlika in nič, kar si medtem spremenil. Novi ključi `sync2.*` → prvo usklajevanje po posodobitvi je polna združitev.
- Samodejni uvoz iz intervals.icu, izpeljave iz voženj in trase tečejo **šele po prvem usklajevanju** (največ 8 s čakanja); ob vrnitvi v aplikacijo najprej uskladi. Izbrisana vožnja se ne uvozi znova.
- Časovni žigi: `MealEntry.updatedAt`, `DailyCheckin.updatedAt`, `Settings.updatedAt`; načrt ob zapisu dobi nov `updatedAt`. Nastavitve: »uskladi zdaj« in oznaka različice pri računu.
- Izgubljenih obrokov ni bilo mogoče obnoviti (Firestore hrani prejšnjo različico 1 h; branje bi zahtevalo Blaževo prijavo, ki je Claude ne sme uporabiti). Blažu svetovano: najprej odpreti na telefonu, nato na računalniku.
- Preverjeno: 125/125 testov (merge 17, dve napravi z Firestorom v pomnilniku), E2E brez napak. Objavljeno `index-CZc_QFC3.js`.

## v3.16 — trase po tvojih cestah, zemljevid v aplikaciji, gorivo, ki se šteje (24. 9. zvečer)

Blaž po vožnji: trasa v redu, a predolga, po makadamu, polno semaforjev in groznih cest; najboljše so poti, ki jih vozi največkrat (naj jih menja), nove samo »tako, kot folk hodi«; dolžina naj se uči iz prejšnjih voženj; ni mogel spiti vsega (ni bilo vroče) — ali se te kalorije štejejo? Nato: »sit sem, ne vem, če bom danes pojedel toliko, kot je predpisano«.
- **Današnja vožnja (Strava prek Claudovega MCP, samo za odgovor, ne v FORMAI):** 49,4 km, 1 h 47 gibanja / 1 h 53 skupaj; ocena trase 45,3 km ~1 h 29 → ocena ~20 % prekratka. Po trasi je vozil ~60 %. Obnova trase prek BRouterja: **46 semaforjev**, 2,8 km `path` + 0,6 km `track` (makadam), 4,9 km naselij — `fastbike-lowtraffic` kaznuje promet, semafor pa stane le 20.
- **Profil »cestno kolo za trening«** (`src/domain/routes/roadProfile.ts`, iz fastbike-lowtraffic, MIT): track/path/footway samo, če so asfalt; neasfaltirano prepovedano; semafor 250; `consider_town`; brez stopnic; kolesarske steze le asfaltne (1,6). Naloži se na brouter.de (`POST /brouter/profile` → `custom_…`, velja 3 h), rezerva fastbike-lowtraffic. Okoli Vodic: makadam 0 km v vseh smereh, semaforji 7 → 2 (sever), 34 → 5 (jug), 14 → 4 (severozahod).
- **Nova trasa:** 4 smeri, izbere po kazni (na 40 km: semafor 0,08, makadam 0,5/km, naselja 0,06/km, kolesarske 0,03/km, glavne ceste 0,02/km; za Z2 še vzpon; −0,8 × delež po **cestah, ki jih že voziš** — mreža ~150 m iz knjižnice voženj), nato do 2 popravka dolžine (skupaj ≤ 6 klicev). Kakovost se shrani (`RouteRec.quality`) in pokaže (»2 semaforja«).
- **Izbor:** tvoje pogoste poti imajo prednost (−0,1 × log2(prevoženo), največ −0,3), menjava (včeraj +0,35, pred 2–3 dnevi +0,2), nova +0,3 (+ semaforji in makadam). Nova se samodejno nariše samo, če nobena tvoja ne ustreza (±12 %, start doma). Po gumbu »Nova trasa« se pokaže prav nova.
- **Učenje dolžine** (`paceAdj`): na dneve treninga (opravljen dan + vožnja + sled) dejanski čas od odhoda do prihoda (`Activity.elapsedMin` iz intervals.icu, največ 1,15 × čas gibanja) proti oceni po korakih na isti sledi; mediana zadnjih 8 (60 dni), ena vožnja šteje pol, meje 0,85–1,35; pomnoži `paceFactor` v vseh ocenah tras. Kartica pove, za koliko so treningi trajali dlje.
- **Zemljevid v aplikaciji** (`src/ui/RouteMap.tsx`, Leaflet + OpenStreetMap, naloži se šele ob odprtju): točno ta sled, smer (puščice vsakih 5 km), kilometri, start, klanec za intervale — namesto brouter-web, ki je pot preračunal po svoje.
- **Gorivo:** tekočina po temperaturi v oknu treninga (< 12 °C 350, < 18 °C 450, < 23 °C 550, < 28 °C 700, sicer 850 ml/h; trdi treningi +50) × koliko spiješ ti (`fluidFactorOf`: popito / predlagano zadnjih 6 vpisov v 60 dneh, 0,7–1,15); izotonika toliko bidonov, kot jih res spiješ, ostanek OH v trdi hrani. Sweet spot 90 min pri 17 °C: 1 bidon izotonika (prej 2), 0,75 l.
- **Kalorije na kolesu se štejejo:** po vožnji na Danes kartica »Na kolesu« (v Prehrani »vpiši, kaj si porabil«): vse po načrtu / približno pol / nič ali po kosih (bidoni po pol, tudi kar ni bilo v načrtu) → obrok »Med vožnjo« (`fluidMl`, `planMl`, `forDay`, `fuel`), kcal na kos (izotonik 160, Frutabela 100, gel 100 …). Prej je bil cilj dneva izračunan z gorivom, pojedeno pa brez njega.
- **Kalorije danes:** cilj ≈ BMR 1.815 × 1,4 + vožnja ~1.000 − pol deficita ≈ 3.300 kcal (realna poraba za ta dan); pojedeno je bilo prikazano prenizko (izbrisani obroki, gorivo ni šteto). Zvečer, ko manjka > 600 kcal: »Če si sit, ne jej na silo … šteje tedensko povprečje«. Če cilj še vedno zdi previsok: Nastavitve → gibanje izven treninga »sedeče« (1,3) = −180 kcal.
- Preverjeno: 135/135 testov (routes-learn, fuel-ctx), E2E (profil naložen 1×, vsi klici z našim profilom, kartica s semaforji, zemljevid s puščicami in km, vpis goriva → obrok Med vožnjo 130 kcal, 0,75 l), 0 napak. Objavljeno `index-DWeaUJfv.js` + `index-CV-0GTs8.css` + `leaflet-src-BGhH227W.js` + `leaflet-CIGW-MKW.css`.

## v3.17 — dnevni cilj sledi porabi čez dan (24. 9. zvečer)

Blaž: vse kalorije je treba upoštevati (tudi sladkor v bidonih, in če ne spije vsega); vprašaj, ali je spil vse, in bolje načrtuj (načrtoval 2 bidona, spil komaj enega — ni bilo vroče, skoraj ni švical); »a je normalno, da tako težko pojem, čeprav hujšam?«; če porabim več ali manj od načrta, preračunaj in daj v dnevni cilj — cilj naj se čez dan prilagaja.
- **Cilj** (`dailyTarget`): trening = IZMERJENA poraba vseh današnjih aktivnosti (tudi nenačrtovanih) + NAČRTOVANA za treninge, ki še niso izmerjeni. Prej: `burn > 0 ? burn : planned` → jutranji sprehod je izbrisal načrtovano vožnjo iz cilja, ročni »Opravil« pred uvozom pa je cilj znižal za ~1000 kcal. Vožnja, ki je že tu, a še ni povezana, se ne šteje dvakrat.
- **Brez stropa 1200 kcal** za trening (5-urna vožnja z 2800 kcal bi sicer dala deficit ~2300 — mimo meje 750); namesto tega preverba smiselnosti na aktivnost: največ 1100 kcal/h + 100 (napaka naprave). Varovalke (BMR, 1500/1200, deficit ≤ 750, pod 18 brez deficita) nespremenjene.
- **Razčlenitev** v Prehrani: »Cilj = osnova 2 527 − deficit 200 + trening ~972 po načrtu — popravim, ko vožnja pride z Garmina« → po uvozu »trening 1 230 izmerjeno (načrt 1 010, +220)« (`targetParts`, `plannedWas`).
- **Ob uvozu današnje vožnje** toast: »Vožnja z Garmina: X kcal (načrt Y, ±Z) → današnji cilj N kcal. Na Danes vpiši, kaj si popil in pojedel na kolesu.«
- **Obroki čez dan** (`adjustToEaten`): pojedeni ostanejo, preostali se sorazmerno prilagodijo do cilja (0–1,35 × prvotnega), gorivo na kolesu po vpisu namesto po načrtu; če tudi 1,35 × ne zadošča: »do cilja manjka še ~X kcal — če si sit, ne jej na silo«.
- Opomba tekočine brez gnezdenih oklepajev (»~550 ml na uro pri 17 °C, prilagojeno temu, koliko spiješ ti«).
- Odgovor Blažu: cilj ~3 300 kcal je realna poraba dneva z ~1 h 50 sweet spota (osnova ~2 540 + vožnja ~1 000) in že vsebuje deficit; po trdem treningu je apetit pogosto zmanjšan (normalno); na velike dneve energijsko gostejša hrana in tekoče kalorije, na kolesu OH; resnična kontrola je trend teže (0,25–0,5 kg/teden).
- Preverjeno: 139/139 testov (day-adjust, dailyTarget: brez stropa, nepovezana vožnja, ročno opravljeno, sprehod + vožnja, napaka naprave), E2E (razčlenitev cilja, prilagojeni obroki po vpisu goriva) 0 napak. Objavljeno `index-DAWdMl9d.js`.

## v3.18 — obrok po uri, seznam dneva po času (24. 9. zvečer)

Blaž (posnetek Prehrane ob 19:46: Malica 12:00, Kosilo 12:00 in 14:00, Med vožnjo 19:43, Večerja 18:00 in 19:00, Drugo 17:00, spodaj »Dodaj zajtrk«): »poglej ure — a je to zajtrk? To naj naredi avtomatsko, kot je takrat čas. Če pa izberem popoldne zajtrk, to pomeni, da vpisujem za nazaj — premakni ga pod zajtrk.«
- `src/domain/nutrition/slots.ts`: `slotAt` (5–10 zajtrk, 10–12 malica, 12–15 kosilo, 15–17 malica, 17–21 večerja, sicer drugo), `timeForSlot` (drug obrok kot zdaj = vpis za nazaj → tipična ura: zajtrk 7:30, kosilo 13:00, večerja 19:00, malica 10:30/16:00), `byTime`, `photoTime` (EXIF istega dne, sicer čas datoteke iz galerije, če je starejši od 5 min, sicer zdaj), `SLOT_ACC` (»Dodaj večerjo«).
- Prej: »Dodaj …« je iskal prvi manjkajoči obrok (ob 19:46 → »zajtrk«, v imenovalniku »Dodaj večerja«); seznam je bil po vrsti obroka (Med vožnjo pred Večerjo 18:00, Drugo 17:00 čisto spodaj); slika je dobila uro zaokroženo na celo uro in obrok z drugačnimi mejami.
- Zdaj: nov vpis = obrok in ura po zdajšnjem času; v obrazcu polje **Ura** (obrok sledi uri, razen če ga izbereš sam); izbira drugega obroka → tipična ura in oznaka »vpis za nazaj«; slika: ura posnetka (EXIF z minutami) → obrok; seznam dneva po uri; vpis »Na kolesu« dobi uro začetka vožnje z Garmina.
- Preverjeno: 145/145 testov (slots.test.ts), E2E z uro 19:46 (seznam po času, »Dodaj večerjo«, privzeto Večerja 19:46, Zajtrk → 07:30 »vpis za nazaj« → na vrhu seznama, ura 12:30 → Kosilo) 0 napak. Objavljeno `index-CCyOt7hG.js` + `index-VAaNrLny.css`.

## v3.19 — fitnes in hribi v osnovi, jedro po želji, več tekem (24. 9. zvečer)

Blaž: do 4. januarja namesto kolesa lahko hribi, zraven fitnes; v rumeni in rdeči fazi jedro po želji; več ciljev sezone (Franja + druge tekme čez vikend), načrt naj se jim prilagodi (dan pred tekmo nič trdega), tekme dodajaš tudi kasneje.
- Nastavitve → Oprema in moč: 0/1/2×, doma/fitnes, »vso sezono« ali »samo v osnovi (do 10. 1.)«. Fitnes A (torek, težko: polovični počep, nožna preša na eni nogi, romunski mrtvi dvig, dvig kolena, prsti, deska) in B (petek: stopanje na klop, hip thrust, bolgarski počep, veslanje, Pallof, dead bug) — Rønnestad & Mujika 2014.
- Plan: »Hribi namesto kolesa« na Z2/dolgih/regeneracijskih dneh (×1,15 trajanja, 50 TSS/h, en klik nazaj), »+ jedro po želji« (ne šteje v realizacijo). Tekme B (pomembna: dva dni prej brez trdega, dan prej predaktivacija, teden −20 %, dan po lahko) in C (za trening: nadomesti ključni trening). Test FTP ≥ 2 dni od tekme.
- 154 testov. Objavljeno `index--SsP1SVL.js`.

## v3.20 — hitrejši preklop zaslonov, poslušanje oblaka, malo vlaknin pred tekmo (24. 9. zvečer)

Blaž: »ko kliknem plan, trener, ful steka, predolgo čakam«; »vlaknine ne smejo biti vsaj dva dni pred dirko«.
- **Vzrok zatikanja** (merjeno s Playwrightom, CPU ×4 kot telefon, leto voženj ~216 sledi): kartica trase na Planu in Danes je ob VSAKEM odprtju primerjala vse sledi med seboj (`dedupeRoutes`, haversine, 258 ms na namizju) in po 32-kratni bisekciji računala hitrost na vsakih 50 m (`paceFactor`, `suggestRoutes`, `paceAdj`) → **~4,5 s na preklop**. Popravek: primerjava sledi v ravnini z dekodiranjem enkrat in predčasnim izhodom (18 ms), rezultat v predpomnilniku po podpisu knjižnice (`libSig`), `routePace` v predpomnilniku, hitrost iz tabele po naklonu (`speedFast`, napaka < 0,01 %), `formSeries` po tabeli aktivnosti, `addDays` s predpomnilnikom, Napredek brez zank O(n²). **Preklop zdaj ~0,1 s** (dolga opravila ≤ 90 ms pri ×4). Animacija zaslona 160 ms (prej 280 + zamiki do 280 ms).
- **Sinhronizacija:** prej vsakih 20 s cel dokument (~0,5 MB) + branje cele baze + 2 izrisa aplikacije. Zdaj `onSnapshot` poslušalec: ko se oblak ne spremeni in tu ni nič novega, je usklajevanje le preverba (brez prenosa); ob zapisu druge naprave takoj polna združitev; vsakih 5 min vseeno polno; ob napaki poslušalca nazaj na 20 s. Status »usklajujem« šele po 0,7 s, enako stanje brez izrisa. Test »dve napravi v živo«.
- **Malo vlaknin** (`src/domain/nutrition/race.ts`): 2 dni pred vsako tekmo (tudi Franja) in na dan tekme do starta; obroki iz predlog z belim kruhom, rižem, testeninami, krompirjem brez lupine, banano (brez polnozrnatega, stročnic, zelenjave, oreškov); opomba na Danes, okvir v Prehrani, pravilo v AI kontekstu in tedenskem jedilniku; dan pred drugo tekmo in na dan tekme brez deficita.
- 160 testov. Objavljeno `index-B-3qZpz8.js` + `index-DdnCIwWX.css`.

## v3.21 — sezona z več cilji, vrste dirk, off-season, lahek začetek, celovit kolesar (24. 9. ponoči)

Blaž (posnetki trenerja so z Gašperjevega računa): več ciljev sezone, tudi samo šprinti, samo klanci, vzponi; pri vsaki tekmi povej, kakšna je (km, klanci, napornost, rang, pomembnost), višji rang in daljše dirke → drugačen načrt; »hočem celostno napredovati — klanci, šprint, ravnina«; off-season (teden–dva počitka, hribi) po zadnji dirki, začetek osnove na easy, FTP po premoru nižji (»intenzivnost dol, ker se izčrpaš, ni svežine«); vročinska prilagoditev z oblačili, po občutku, brez termometra; »koliko sezon že treniraš« v oceni napredka; ure: aplikacija določi maksimum, skupaj izbereva »po času« ali »največji napredek«. Tekme vpisuje sam.
- **Tekma** (`Race`): prio A/B/C, `type` (šprint, klanci, vzpon, maraton, kronometer, cestna — predlog iz imena, km in m/km), `elevM`, `level` (amater / višji rang). `raceMinutes` (38 km/h − 0,45 × m/km, višji rang +6 %), `raceDemand` (napornost 1–5). Glavni cilj ima ista polja (tap v kartici).
- **Makrocikel z več vrhovi** (`seasonGoals`, `weekContext`): pred prvim ciljem osnova → gradnja → specifično (8 t.) → tapering → teden cilja; po vsakem cilju teden (pri razmiku ≥ 10 tednov dva) lahko, nato bloki naprej (1, 2, 3, razbremenitev; teden pred taperingom nikoli razbremenilni), nikoli nazaj v osnovo. Cilj na katerikoli dan v tednu (dan prej predaktivacija, dan po regeneracija; pred dolgo dirko dan počitka s polnjenjem OH).
- **Off-season** (faza `prehod`): 1–4 tedne od začetka (`offSeasonWeeks`), ~40 % ur: 2 × po občutku, 2 × hribi, brez intervalov in moči. Vprašanje »Je bila X zadnja tekma sezone?« (tekma v zadnjih 6 tednih, nobene v 4 tednih) ali gumb »sezona je končana → off-season«; »Spočit sem — začni z osnovo«. **FTP po premoru** −1/−3/−5/−7 % (1–4 tedne) za vate, dokler ne izmeriš (`ftpForWeek`).
- **Lahek začetek sezone** (3 tedne, če je do prvega cilja ≥ 11 tednov): torek Z2 + šprinti, četrtek visoka kadenca → klanci z nizko kadenco → tempo 3 × 10; volumen 60/70/80 % (po off-seasonu) oz. 75/80/85 %; test FTP v 4. tednu; prvi VO2max 4 × 4.
- **Celovit kolesar:** sreda Z2 + 6–8 × 10–15 s šprint vsak teden; četrtek izmenično na ravnini, na klancu, over-under (3 × (2 min 95 % + 1 min 105 %)); v gradnji vsak 3. teden 30/15 (Rønnestad 2020); sobota v osnovi izmenično ravnina in hribi. **Specifični blok po vrsti:** šprint (napadi 3 × 5 × 30 s, šprint iz zavetrja, 40/20, anaerobno 8 × 30 s, skupinska), klanci (6 × 3 min, napadi 5 × 4 min, over-under na klancu, dolga razgibana), vzpon (2 × 20 / 3 × 15 / 1 × 30 na klancu, dolga + 3 klanci), kronometer (v aero), maraton (Kladje/dolgi klanec, simulacija). Dolga vožnja pred dolgo dirko ~85 % njenega trajanja (do 6 h 30).
- **Vročina:** cilj junij–avgust → zadnja 2 tedna do 3 lahke Z2 (≤ 2 h) »· vročina« z navodili brez termometra (za 10–15 °C topleje oblečen, zadnjih 30–40 min vroče in znojno, utrip +10, pij z elektroliti, tehtanje ≤ 2 %, opozorilni znaki; alternativa savna/kopel). Intervali ostanejo hladni.
- **Napredek:** `ftpPotential` × sezone treninga (1. ×1,35 · 2. ×1,15 · 3.–4. ×1 · 5.–7. ×0,8 · 8+ ×0,6) × starost (≤ 20 ×1,1, 30+ ×0,95, 40+ ×0,9) × ure (nad 12 h 1 + 0,45·ln(h/12), strop 1,35). Gašper (19 let, 400 W, 74,5 kg, 3.–4. sezona, 19 h): ~410 W realno, največ ~416 W (+3–4 %). Blaž ostane ~288–291 W.
- **Ure:** »Največji napredek · X h« / »Po mojem času« s primerjavo FTP ob cilju; namig iz najdaljše tekme (vsaj ~2,5 × trajanje + 3 h na teden v gradnji); največ = najdaljši teden × (1,3 do 12 h → 1,1 pri 20 h+); v načinu »največji napredek« se ure same dvignejo, ko vožnje pokažejo več (nikoli same ne padejo). Ponovna potrditev istega cilja ne začne makrocikla znova.
- AI kontekst: cilji A z vrsto, km, vzponom, rangom in napornostjo; tekme B/C; sezone treninga (ali prošnja, da jih vpiše); faza z lahkim začetkom/off-seasonom in FTP po premoru; METODA za celovitega kolesarja.
- 175 testov (season-goals: vrste, trajanje, več ciljev, bloki naprej, specifični bloki, dolga vožnja, cilj v soboto, off-season, lahek začetek, FTP po premoru, vročina, sezone). E2E (dodaj cilja A in B z vzponom/rangom, časovnica, off-season 2 tedna, Danes) 0 napak; preklop zaslonov ≤ 175 ms pri ×4. Objavljeno `index-CMg61ecW.js`.
- Naslednje: trasa za intervale (krog čez različne podobne klance, ceste brez mesta, semaforjev in makadama).

## v3.22 — vrhovi forme, kratka kartica tekem, daljši off-season (25. 9., pripravljeno, objava čaka na Blažev računalnik)

Blaž: »ali ne moreš prilagoditi samo tedna tekme — je to dovolj?«; »če je veliko tekem, se vse pomakne dol, predolg stolpec«; »off-season je daljše obdobje, začne se po zadnji dirki ali ko se odločiš, potem spet počasi gradiš«.
- **Vrhovi forme** (`peakGoals`): glavni cilj je vedno vrh; drug cilj A je svoj vrh le, če je ≥ 5 tednov od drugega vrha. Bližnji cilji A se vozijo v isti formi (samo teden tekme, kot B). Po zadnjem vrhu, če so še cilji A: teden lahko, nato vzdrževanje (specifično), ne osnova. Odgovor: za B in C se že spremeni samo teden tekme; za 2–3 glavne tekme en teden ni dovolj (tapering 8–14 dni, −41–60 % volumna, intenzivnost ostane — Bosquet 2007).
- **Kartica »Tekme sezone«**: ena vrstica na tekmo, samo naslednje 3 (vedno tudi naslednji cilj A), »vse tekme (N)« odpre seznam s podrobnostmi; pri 12 tekmah 222 px.
- **Off-season 2/3/4/6 tednov** (priporočeno 4): počitek (tretjina, vse po želji, kolo počiva) → aktivni počitek (2 × hribi, 2 × po občutku) → vrnitev (3 lahke vožnje + hribi); po 4+ tednih lahki tedni od 50 %, osnova od 80 % proti 100 % v 12 tednih; FTP −1/3/5/7/8/9 %.
- 178 testov. Paket `index-Dm6nkzqc.js` v /mnt/user-data/outputs/formai-objava.

## v3.23 — prvi vtis, spanec in HRV, intervali čez klance, testni program (25. 9., pripravljeno, čaka na izbiro ikone in objavo)

Blaž: »ni fajn, da ga napadeš z anketo — kje je tista lepa spletna stran, vse mora biti profesionalno«; »logo na telefonu in logo hrane sta slaba«; iz načrta izboljšav izbral **točke 1–10**.
1. **Pristajalna stran** (`landing/landing.html` + `landing.css`, v `index.html` vstavi Vite vtičnik): statični HTML, hiter prvi izris, berljiv iskalnikom (`noindex` odstranjen, canonical + og). Hero »Kolo in prehrana. En načrt.« z živim tednom v telefonu, 3 koraki, sezona z vrhovi forme, kaj dobiš (6), prehrana z varovalkami, zasebnost, zgodnji dostop, vprašanja, noga (zasebnost, pogoji, kontakt). Kdo vidi: samo nov obiskovalec na golem naslovu. Aplikacija takoj: nameščena (standalone), zastavica `formai.app` v localStorage, stari ključi v1, pot `#/…`, `?code=` (OAuth). Povabilo `?pilot=KODA` pokaže vrstico »Povabilo · KODA«.
2. **Uvod v 3 korakih** (`Onboarding.tsx`): za kaj treniraš (tekma z datumom + Franja z enim dotikom / hitrejši / shujšati / forma) → koliko časa (ure, katera sezona, zunaj/trenažer, moč 2×) → o tebi (spol, starost, višina, teža, FTP neobvezno) → **prvih 7 dni** po dnevih (kolo in moč v eni vrstici) + »Shrani na vse naprave« (prijava ne prepiše načrta na računu). »Že imam račun« → `#/prijava` (počaka na prvo usklajevanje: račun z načrtom → Danes, brez → uvod).
3. **Ikona**: 3 predlogi (A krivulja forme, B obroč s F, C poševni F na limeti) — **čaka na Blaževo izbiro**; generator vseh velikosti (192, 512, maskable, apple-touch 180, favicon, mark) in og.png je pripravljen.
4. **Ikone zavihkov**: enoten komplet (hiša, koledar s tremi dnevi, krožnik z vilicami in nožem, oblaček z iskrico, krivulja navzgor), izbrani zavihek z mehkim polnilom.
5. **Vodnik »Kako deluje« v 3 korakih** (tvoj načrt · vsak dan · hrana in trener), pokaže se enkrat po uvodu; samo dnevi od danes.
6. **Poliranje**: datumi po slovensko (`DateField`, »13. junija 2027«, rodilnik tudi v glavi Danes), graf ur brez prekrivanja, jutranji vnos v enakih vrsticah (večji dotik), večje površine dotika čipov in kljukic, številska polja brez puščic, trdi presledek pred %, obroč 0 % brez pike, trasa: ravna brez praznega profila, gumb »Kako na uro?«; »Prvi koraki« (poveži uro, tekme, začetni zaslon, račun) pod današnjim treningom; namestitveni poziv ne prvi dan.
7. **»Poveži z intervals.icu« z enim dotikom (OAuth)** — pripravljeno za zastavico `ICU_CLIENT_ID` (config.ts); strežnik `/icu/token` (skrivnost `ICU_CLIENT_SECRET`), žeton Bearer, athlete `0`, odklop `DELETE /disconnect-app`. Vodeni koraki v Uvozu s samodejnim zaznavanjem: povezan ✓ · ura pošilja vožnje ✓ (izvor GARMIN) · spanec in HRV.
8. **Spanec, HRV, mirovni utrip** (intervals.icu wellness; `src/domain/wellness.ts`): izrecen vklop, samo na napravi (ne v oblak, ne v AI), ob izklopu izbris. Primerjava s tvojim običajnim (28 dni, ≥ 7 meritev): HRV (ln rMSSD) −0,75 SD → −8, −1,5 SD → −15; utrip +4 → −6, +7 → −12; spanec z ure < 5,5 h −15, < 6,5 h −7, ≥ 8 h +4; ocena spanca < 50 −6. Jasni znaki prevladajo nad svežino iz treninga (odbitek ≥ 20 → največ 44 »nizka«, ≥ 12 → največ 59). Danes: ⌚ na pripravljenosti, list z razlogi in »Olajšaj dan«, namig v kartici treninga, spanec z ure v jutranjem vnosu.
9. **Intervali čez več klancev** (`climbLoop.ts`): 2–4 podobni klanci iz tvojih voženj (čas pri ciljnih vatih ±35 %, naklon ±2,5 %, do 20 km od doma, izsek ≤ 150°), po smeri okoli doma; BRouter s profilom za cestno kolo; zavrne makadam > 0,5 km ali > 30 % naselij; predolgo → en klanec manj. Opis: »1) pri 6. km (1,4 km, 6 %) 2× · 2) …«.
10. **Testni program brez nadlegovanja** (`pilot.ts`, `PilotCard`): po 7 dneh »Kako ti je po prvem tednu?« (en dotik) + »Kaj bi najprej popravil?«, nato vsakih 30 dni NPS, kaj koristi, kaj manjka, bi plačal; »ne zdaj« (7 dni), »ne sprašuj več«; anonimna oznaka, koda povabila, brez imena in e-pošte. Strežnik `/pilot/answer`, `/pilot/summary` (samo `ADMIN_EMAILS`). Pregled `#/pilot` + QR povezava s kodo.
- 200 testov (wellness, climb-loop, icu-oauth, pilot, nov uporabnik brez cilja → test FTP v 4. tednu). E2E: pristajalna stran (390 in 1280), uvod → 7 dni → Danes → vodnik, prijava, stari uporabnik; spanec/HRV → pripravljenost 44, vprašanje → vrsta, vodeni koraki, QR — 0 napak.
- **Blaž mora:** izbrati ikono (A/B/C); potrditi besedila; za OAuth zaprositi na https://intervals.icu/oauth/apply (redirect https://formai.si/) in na strežnik dodati `ICU_CLIENT_ID`, `ICU_CLIENT_SECRET`; za pregled testnega programa `ADMIN_EMAILS` in namestiti nov `server-index.js` na Cloud Run.
