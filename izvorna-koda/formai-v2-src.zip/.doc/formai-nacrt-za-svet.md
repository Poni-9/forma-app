# FORMAI — svetovni trg in načrt izboljšav (25. 9. 2026)

Blaž: kako bi se FORMAI obnesel po svetu, kako ga dati v svet, kaj še čaka, Garmin, spanje in zdravje, prijava, koliko denarja, kaj popraviti, ali je s.p. nujen. In: ob prvem obisku ne »napasti z anketo«, nazaj lepa spletna stran, vse profesionalno; ikona na telefonu in ikona hrane sta slabi; najprej načrt z idejami, Blaž izbere.

## Dejstva (preverjeno 24.–25. 9. 2026)
- **Garmin:** pregled novih prošenj za API je še vedno ustavljen, brez roka (the5krunner 14. 9., Sahha 19. 9.); program je »only for business use« (podjetje); Health API (spanje, HRV, stres, Body Battery) za komercialno rabo z licenčnino. Garmin je 22. 7. 2026 kupil TrainingPeaks. → Na Garmina ne računamo.
- **Spanje/HRV brez Garmina:** intervals.icu wellness (sleepSecs, sleepScore, hrv, restingHR, readiness …) se iz Garmin Connect uvaža samodejno; OAuth s scope WELLNESS. Javna aplikacija mora uporabljati OAuth (ne API ključa); 100 zahtevkov na uporabnika na dan. HealthKit/Health Connect samo z native aplikacijo. Oura/WHOOP: 10 uporabnikov do odobritve.
- **Konkurenca:** TrainerRoad 21,99 $/mes, TrainingPeaks 19,95 $, Wahoo 17,99 €, JOIN 16,99 €, Athletica 19,90 $, Xert 14,99 $, Zwift 19,99 €; AI trenerji na intervals.icu 3–9 €/$ (v imeniku že 40+). Strava je kupila Runna in The Breakaway, pripravlja IPO; Stravina API politika od 1. 6. 2026 prepoveduje rabo v AI.
- **RevenueCat 2026, zdravje in fitnes:** prenos → plačnik 2,9 % (35. dan), preizkus → plačnik 37,7 %, prihodek na namestitev 0,66 $ (60. dan), prihodek na plačnika v 1. letu 35,64 $, mediana 9,99 $/mes ali 39,94 $/leto; 1.000 $/mes v 2 letih doseže 17,3 % aplikacij, 10.000 $/mes 4,6 %. Trdo plačilno okno konvertira 10,7 %, freemium 2,1 %.
- **Trgovine:** Google Play TWA; nov osebni račun: 12 testerjev 14 dni, 25 $; od 30. 6. 2026 naročnine 10 % + 5 % za Play Billing, dovoljeno tudi lastno plačilo. Apple 99 $/leto, goli PWA ovoj tvega zavrnitev (4.2), naročnine prek IAP (15 % Small Business), EU od 1. 10. 2026 povezava ven 10–15 %.
- **Plačila:** MoR Paddle 5 % + 0,50 $ (posameznik brez podjetja OK pri Paddle), Polar 5 % + 0,50 $ (+1,5 %), Lemon Squeezy (Stripe) 5 % + 0,50 $ +1,5 % — MoR obračuna DDV. Brez MoR: OSS nad 10.000 € čezmejne prodaje v EU.
- **Slovenija:** redna prodaja = dejavnost → registracija (SPOT: »za spletno prodajo potrebujete podjetje«). Polni s.p. 651,04 €/mes prispevkov (1. leto 463,60 €, 2. leto 540,74 €); popoldanski samo za zaposlene; študent s s.p. izgubi študentsko delo. Študentski s.p. je še predlog (DS podprl 10. 6.; sprejetja v DZ do 24. 9. ni); »mikro s.p.« iz ZIURS še ne velja (podpisi za referendum do 5. 10.). Normiranec: efektivno ~4 % prihodkov davka. d.o.o. 7.500 € kapitala.
- **Pravno:** zdravje = posebna vrsta podatkov (izrecna privolitev, DPIA je obvezna za aplikacije za spremljanje zdravja); AI Act čl. 50 velja od 2. 8. 2026 (povedati, da gre za AI, strojno označene AI vsebine); wellness aplikacija ni medicinski pripomoček, dokler ne obljublja diagnoze ali zdravljenja.

## Denar (moj izračun iz meril zgoraj)
- ~1 $ prihodka na prenos v prvem letu. SLO: 1.000–3.000 prenosov → ~1.000–3.100 $/leto. Svet (angleščina + Play), 20.000 prenosov → ~20.000 $/leto (~1.700 $/mes) pred stroški.
- Stroški: AI ~⅕ prihodka, MoR ~5–7 %, s.p. v 1. letu 5.563 € prispevkov → pri ~40 €/leto (z DDV) ostane ~25 € na plačnika → ~220 plačnikov samo za prispevke.
- Sklep: najprej brezplačen pilot (SLO), plačila in s.p. šele, ko je ≥ 20 »bi plačal« in ≥ 30 % tedensko aktivnih; svet šele z angleščino, OAuth in kanalom do kupcev (klubi, forum intervals.icu, YouTube/Reddit).

## Načrt izboljšav — Blaž izbere

**25. 9.: Blaž izbral 1–10 → narejeno v v3.23** (glej formai-osebna, v3.23). Odprto: izbira ikone (3), OAuth odobritev in strežnik (7), `ADMIN_EMAILS` na strežniku (10), objava.
A. Prvi vtis in videz
1. Pristajalna stran na formai.si (posodobljena »lepa«): hero z živim primerom tedna, 3 koraki, kaj dobiš, zasebnost, testni program, vprašanja; prijavljen gre naravnost v aplikacijo. ~2 dni.
2. Uvod v 3 korakih namesto 8 (cilj ali tekma · ure · osnovni podatki; FTP neobvezen), takoj prvi teden; ostalo vpraša kasneje, ko je potrebno. »Že imam račun« na začetku. ~1,5 dni.
3. Nova ikona aplikacije (telefon, zavihek, deljenje) — 3 predlogi, izbere Blaž. ~0,5 dni.
4. Nove ikone zavihkov (Prehrana: krožnik z vilicami in nožem), enoten slog. ~0,5 dni.
5. Vodnik »Kako deluje« 3 kratki koraki namesto 6 zaslonov. ~0,5 dni.
6. Poliranje zaslonov na telefonu (grafi brez prekrivanj, datumi dd. mm., prazna stanja, skeleti, dotik 44 px, kontrast). ~2 dni.
B. Podatki
7. »Poveži z intervals.icu« z enim dotikom (OAuth) + vodeni koraki za Garmin. ~2–3 dni + odobritev intervals.icu.
8. Spanje, HRV, mirovni utrip prek intervals.icu → samodejna jutranja pripravljenost in prilagoditev dneva. ~2 dni.
9. Trase za intervale: krog čez različne podobne klance, ceste brez mesta, semaforjev in makadama. ~2–3 dni.
C. Pilot
10. Testni program brez nadlegovanja: koda/QR, prva vprašanja šele po 7 dneh (1 dotik), mesečno 3–5, vse preskočljivo; pregled za Blaža. ~2 dni.
11. Klubski način (koda kluba, logotip, skupinske vožnje v načrtu). ~3–5 dni, kasneje.
D. Svet
12. Angleščina in enote, splošen privzeti cilj. ~4–6 dni.
13. Google Play (TWA); iOS kasneje (native). ~1–2 dni.
14. Plačila prek MoR (po pravni obliki). Cena predlog 5–8 €/mes ali ~49 €/leto.
15. Pravno za svet: DPIA, AI Act čl. 50, zasebnost in pogoji v angleščini. ~1–2 dni.
E. Posel
16. s.p. šele po uspešnem pilotu (ali študentski s.p., če bo sprejet).
17. Garmin: čakamo; vse potrebno prek intervals.icu.
