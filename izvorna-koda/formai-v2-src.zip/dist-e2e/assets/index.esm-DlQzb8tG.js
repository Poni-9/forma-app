import{F as hm,v as yt,L as dm,J as ue,w as as,x as ra,y as Bl,z as fm,R as mm,l as gm,e as Ul,T as pm,i as _m,U as ym,V as Im,C as oi,W as jl,X as zl,S as Tm,h as Em,P as wm,r as dc,g as vm}from"./index.esm2017-Du_VomL_.js";var fc=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var Se,Gl;(function(){var r;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function t(T,_){function I(){}I.prototype=_.prototype,T.D=_.prototype,T.prototype=new I,T.prototype.constructor=T,T.C=function(E,w,V){for(var y=Array(arguments.length-2),ie=2;ie<arguments.length;ie++)y[ie-2]=arguments[ie];return _.prototype[w].apply(E,y)}}function e(){this.blockSize=-1}function n(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.B=Array(this.blockSize),this.o=this.h=0,this.s()}t(n,e),n.prototype.s=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function s(T,_,I){I||(I=0);var E=Array(16);if(typeof _=="string")for(var w=0;16>w;++w)E[w]=_.charCodeAt(I++)|_.charCodeAt(I++)<<8|_.charCodeAt(I++)<<16|_.charCodeAt(I++)<<24;else for(w=0;16>w;++w)E[w]=_[I++]|_[I++]<<8|_[I++]<<16|_[I++]<<24;_=T.g[0],I=T.g[1],w=T.g[2];var V=T.g[3],y=_+(V^I&(w^V))+E[0]+3614090360&4294967295;_=I+(y<<7&4294967295|y>>>25),y=V+(w^_&(I^w))+E[1]+3905402710&4294967295,V=_+(y<<12&4294967295|y>>>20),y=w+(I^V&(_^I))+E[2]+606105819&4294967295,w=V+(y<<17&4294967295|y>>>15),y=I+(_^w&(V^_))+E[3]+3250441966&4294967295,I=w+(y<<22&4294967295|y>>>10),y=_+(V^I&(w^V))+E[4]+4118548399&4294967295,_=I+(y<<7&4294967295|y>>>25),y=V+(w^_&(I^w))+E[5]+1200080426&4294967295,V=_+(y<<12&4294967295|y>>>20),y=w+(I^V&(_^I))+E[6]+2821735955&4294967295,w=V+(y<<17&4294967295|y>>>15),y=I+(_^w&(V^_))+E[7]+4249261313&4294967295,I=w+(y<<22&4294967295|y>>>10),y=_+(V^I&(w^V))+E[8]+1770035416&4294967295,_=I+(y<<7&4294967295|y>>>25),y=V+(w^_&(I^w))+E[9]+2336552879&4294967295,V=_+(y<<12&4294967295|y>>>20),y=w+(I^V&(_^I))+E[10]+4294925233&4294967295,w=V+(y<<17&4294967295|y>>>15),y=I+(_^w&(V^_))+E[11]+2304563134&4294967295,I=w+(y<<22&4294967295|y>>>10),y=_+(V^I&(w^V))+E[12]+1804603682&4294967295,_=I+(y<<7&4294967295|y>>>25),y=V+(w^_&(I^w))+E[13]+4254626195&4294967295,V=_+(y<<12&4294967295|y>>>20),y=w+(I^V&(_^I))+E[14]+2792965006&4294967295,w=V+(y<<17&4294967295|y>>>15),y=I+(_^w&(V^_))+E[15]+1236535329&4294967295,I=w+(y<<22&4294967295|y>>>10),y=_+(w^V&(I^w))+E[1]+4129170786&4294967295,_=I+(y<<5&4294967295|y>>>27),y=V+(I^w&(_^I))+E[6]+3225465664&4294967295,V=_+(y<<9&4294967295|y>>>23),y=w+(_^I&(V^_))+E[11]+643717713&4294967295,w=V+(y<<14&4294967295|y>>>18),y=I+(V^_&(w^V))+E[0]+3921069994&4294967295,I=w+(y<<20&4294967295|y>>>12),y=_+(w^V&(I^w))+E[5]+3593408605&4294967295,_=I+(y<<5&4294967295|y>>>27),y=V+(I^w&(_^I))+E[10]+38016083&4294967295,V=_+(y<<9&4294967295|y>>>23),y=w+(_^I&(V^_))+E[15]+3634488961&4294967295,w=V+(y<<14&4294967295|y>>>18),y=I+(V^_&(w^V))+E[4]+3889429448&4294967295,I=w+(y<<20&4294967295|y>>>12),y=_+(w^V&(I^w))+E[9]+568446438&4294967295,_=I+(y<<5&4294967295|y>>>27),y=V+(I^w&(_^I))+E[14]+3275163606&4294967295,V=_+(y<<9&4294967295|y>>>23),y=w+(_^I&(V^_))+E[3]+4107603335&4294967295,w=V+(y<<14&4294967295|y>>>18),y=I+(V^_&(w^V))+E[8]+1163531501&4294967295,I=w+(y<<20&4294967295|y>>>12),y=_+(w^V&(I^w))+E[13]+2850285829&4294967295,_=I+(y<<5&4294967295|y>>>27),y=V+(I^w&(_^I))+E[2]+4243563512&4294967295,V=_+(y<<9&4294967295|y>>>23),y=w+(_^I&(V^_))+E[7]+1735328473&4294967295,w=V+(y<<14&4294967295|y>>>18),y=I+(V^_&(w^V))+E[12]+2368359562&4294967295,I=w+(y<<20&4294967295|y>>>12),y=_+(I^w^V)+E[5]+4294588738&4294967295,_=I+(y<<4&4294967295|y>>>28),y=V+(_^I^w)+E[8]+2272392833&4294967295,V=_+(y<<11&4294967295|y>>>21),y=w+(V^_^I)+E[11]+1839030562&4294967295,w=V+(y<<16&4294967295|y>>>16),y=I+(w^V^_)+E[14]+4259657740&4294967295,I=w+(y<<23&4294967295|y>>>9),y=_+(I^w^V)+E[1]+2763975236&4294967295,_=I+(y<<4&4294967295|y>>>28),y=V+(_^I^w)+E[4]+1272893353&4294967295,V=_+(y<<11&4294967295|y>>>21),y=w+(V^_^I)+E[7]+4139469664&4294967295,w=V+(y<<16&4294967295|y>>>16),y=I+(w^V^_)+E[10]+3200236656&4294967295,I=w+(y<<23&4294967295|y>>>9),y=_+(I^w^V)+E[13]+681279174&4294967295,_=I+(y<<4&4294967295|y>>>28),y=V+(_^I^w)+E[0]+3936430074&4294967295,V=_+(y<<11&4294967295|y>>>21),y=w+(V^_^I)+E[3]+3572445317&4294967295,w=V+(y<<16&4294967295|y>>>16),y=I+(w^V^_)+E[6]+76029189&4294967295,I=w+(y<<23&4294967295|y>>>9),y=_+(I^w^V)+E[9]+3654602809&4294967295,_=I+(y<<4&4294967295|y>>>28),y=V+(_^I^w)+E[12]+3873151461&4294967295,V=_+(y<<11&4294967295|y>>>21),y=w+(V^_^I)+E[15]+530742520&4294967295,w=V+(y<<16&4294967295|y>>>16),y=I+(w^V^_)+E[2]+3299628645&4294967295,I=w+(y<<23&4294967295|y>>>9),y=_+(w^(I|~V))+E[0]+4096336452&4294967295,_=I+(y<<6&4294967295|y>>>26),y=V+(I^(_|~w))+E[7]+1126891415&4294967295,V=_+(y<<10&4294967295|y>>>22),y=w+(_^(V|~I))+E[14]+2878612391&4294967295,w=V+(y<<15&4294967295|y>>>17),y=I+(V^(w|~_))+E[5]+4237533241&4294967295,I=w+(y<<21&4294967295|y>>>11),y=_+(w^(I|~V))+E[12]+1700485571&4294967295,_=I+(y<<6&4294967295|y>>>26),y=V+(I^(_|~w))+E[3]+2399980690&4294967295,V=_+(y<<10&4294967295|y>>>22),y=w+(_^(V|~I))+E[10]+4293915773&4294967295,w=V+(y<<15&4294967295|y>>>17),y=I+(V^(w|~_))+E[1]+2240044497&4294967295,I=w+(y<<21&4294967295|y>>>11),y=_+(w^(I|~V))+E[8]+1873313359&4294967295,_=I+(y<<6&4294967295|y>>>26),y=V+(I^(_|~w))+E[15]+4264355552&4294967295,V=_+(y<<10&4294967295|y>>>22),y=w+(_^(V|~I))+E[6]+2734768916&4294967295,w=V+(y<<15&4294967295|y>>>17),y=I+(V^(w|~_))+E[13]+1309151649&4294967295,I=w+(y<<21&4294967295|y>>>11),y=_+(w^(I|~V))+E[4]+4149444226&4294967295,_=I+(y<<6&4294967295|y>>>26),y=V+(I^(_|~w))+E[11]+3174756917&4294967295,V=_+(y<<10&4294967295|y>>>22),y=w+(_^(V|~I))+E[2]+718787259&4294967295,w=V+(y<<15&4294967295|y>>>17),y=I+(V^(w|~_))+E[9]+3951481745&4294967295,T.g[0]=T.g[0]+_&4294967295,T.g[1]=T.g[1]+(w+(y<<21&4294967295|y>>>11))&4294967295,T.g[2]=T.g[2]+w&4294967295,T.g[3]=T.g[3]+V&4294967295}n.prototype.u=function(T,_){_===void 0&&(_=T.length);for(var I=_-this.blockSize,E=this.B,w=this.h,V=0;V<_;){if(w==0)for(;V<=I;)s(this,T,V),V+=this.blockSize;if(typeof T=="string"){for(;V<_;)if(E[w++]=T.charCodeAt(V++),w==this.blockSize){s(this,E),w=0;break}}else for(;V<_;)if(E[w++]=T[V++],w==this.blockSize){s(this,E),w=0;break}}this.h=w,this.o+=_},n.prototype.v=function(){var T=Array((56>this.h?this.blockSize:2*this.blockSize)-this.h);T[0]=128;for(var _=1;_<T.length-8;++_)T[_]=0;var I=8*this.o;for(_=T.length-8;_<T.length;++_)T[_]=I&255,I/=256;for(this.u(T),T=Array(16),_=I=0;4>_;++_)for(var E=0;32>E;E+=8)T[I++]=this.g[_]>>>E&255;return T};function i(T,_){var I=u;return Object.prototype.hasOwnProperty.call(I,T)?I[T]:I[T]=_(T)}function a(T,_){this.h=_;for(var I=[],E=!0,w=T.length-1;0<=w;w--){var V=T[w]|0;E&&V==_||(I[w]=V,E=!1)}this.g=I}var u={};function c(T){return-128<=T&&128>T?i(T,function(_){return new a([_|0],0>_?-1:0)}):new a([T|0],0>T?-1:0)}function h(T){if(isNaN(T)||!isFinite(T))return m;if(0>T)return x(h(-T));for(var _=[],I=1,E=0;T>=I;E++)_[E]=T/I|0,I*=4294967296;return new a(_,0)}function f(T,_){if(T.length==0)throw Error("number format error: empty string");if(_=_||10,2>_||36<_)throw Error("radix out of range: "+_);if(T.charAt(0)=="-")return x(f(T.substring(1),_));if(0<=T.indexOf("-"))throw Error('number format error: interior "-" character');for(var I=h(Math.pow(_,8)),E=m,w=0;w<T.length;w+=8){var V=Math.min(8,T.length-w),y=parseInt(T.substring(w,w+V),_);8>V?(V=h(Math.pow(_,V)),E=E.j(V).add(h(y))):(E=E.j(I),E=E.add(h(y)))}return E}var m=c(0),p=c(1),R=c(16777216);r=a.prototype,r.m=function(){if(D(this))return-x(this).m();for(var T=0,_=1,I=0;I<this.g.length;I++){var E=this.i(I);T+=(0<=E?E:4294967296+E)*_,_*=4294967296}return T},r.toString=function(T){if(T=T||10,2>T||36<T)throw Error("radix out of range: "+T);if(b(this))return"0";if(D(this))return"-"+x(this).toString(T);for(var _=h(Math.pow(T,6)),I=this,E="";;){var w=$(I,_).g;I=L(I,w.j(_));var V=((0<I.g.length?I.g[0]:I.h)>>>0).toString(T);if(I=w,b(I))return V+E;for(;6>V.length;)V="0"+V;E=V+E}},r.i=function(T){return 0>T?0:T<this.g.length?this.g[T]:this.h};function b(T){if(T.h!=0)return!1;for(var _=0;_<T.g.length;_++)if(T.g[_]!=0)return!1;return!0}function D(T){return T.h==-1}r.l=function(T){return T=L(this,T),D(T)?-1:b(T)?0:1};function x(T){for(var _=T.g.length,I=[],E=0;E<_;E++)I[E]=~T.g[E];return new a(I,~T.h).add(p)}r.abs=function(){return D(this)?x(this):this},r.add=function(T){for(var _=Math.max(this.g.length,T.g.length),I=[],E=0,w=0;w<=_;w++){var V=E+(this.i(w)&65535)+(T.i(w)&65535),y=(V>>>16)+(this.i(w)>>>16)+(T.i(w)>>>16);E=y>>>16,V&=65535,y&=65535,I[w]=y<<16|V}return new a(I,I[I.length-1]&-2147483648?-1:0)};function L(T,_){return T.add(x(_))}r.j=function(T){if(b(this)||b(T))return m;if(D(this))return D(T)?x(this).j(x(T)):x(x(this).j(T));if(D(T))return x(this.j(x(T)));if(0>this.l(R)&&0>T.l(R))return h(this.m()*T.m());for(var _=this.g.length+T.g.length,I=[],E=0;E<2*_;E++)I[E]=0;for(E=0;E<this.g.length;E++)for(var w=0;w<T.g.length;w++){var V=this.i(E)>>>16,y=this.i(E)&65535,ie=T.i(w)>>>16,fr=T.i(w)&65535;I[2*E+2*w]+=y*fr,j(I,2*E+2*w),I[2*E+2*w+1]+=V*fr,j(I,2*E+2*w+1),I[2*E+2*w+1]+=y*ie,j(I,2*E+2*w+1),I[2*E+2*w+2]+=V*ie,j(I,2*E+2*w+2)}for(E=0;E<_;E++)I[E]=I[2*E+1]<<16|I[2*E];for(E=_;E<2*_;E++)I[E]=0;return new a(I,0)};function j(T,_){for(;(T[_]&65535)!=T[_];)T[_+1]+=T[_]>>>16,T[_]&=65535,_++}function B(T,_){this.g=T,this.h=_}function $(T,_){if(b(_))throw Error("division by zero");if(b(T))return new B(m,m);if(D(T))return _=$(x(T),_),new B(x(_.g),x(_.h));if(D(_))return _=$(T,x(_)),new B(x(_.g),_.h);if(30<T.g.length){if(D(T)||D(_))throw Error("slowDivide_ only works with positive integers.");for(var I=p,E=_;0>=E.l(T);)I=Y(I),E=Y(E);var w=K(I,1),V=K(E,1);for(E=K(E,2),I=K(I,2);!b(E);){var y=V.add(E);0>=y.l(T)&&(w=w.add(I),V=y),E=K(E,1),I=K(I,1)}return _=L(T,w.j(_)),new B(w,_)}for(w=m;0<=T.l(_);){for(I=Math.max(1,Math.floor(T.m()/_.m())),E=Math.ceil(Math.log(I)/Math.LN2),E=48>=E?1:Math.pow(2,E-48),V=h(I),y=V.j(_);D(y)||0<y.l(T);)I-=E,V=h(I),y=V.j(_);b(V)&&(V=p),w=w.add(V),T=L(T,y)}return new B(w,T)}r.A=function(T){return $(this,T).h},r.and=function(T){for(var _=Math.max(this.g.length,T.g.length),I=[],E=0;E<_;E++)I[E]=this.i(E)&T.i(E);return new a(I,this.h&T.h)},r.or=function(T){for(var _=Math.max(this.g.length,T.g.length),I=[],E=0;E<_;E++)I[E]=this.i(E)|T.i(E);return new a(I,this.h|T.h)},r.xor=function(T){for(var _=Math.max(this.g.length,T.g.length),I=[],E=0;E<_;E++)I[E]=this.i(E)^T.i(E);return new a(I,this.h^T.h)};function Y(T){for(var _=T.g.length+1,I=[],E=0;E<_;E++)I[E]=T.i(E)<<1|T.i(E-1)>>>31;return new a(I,T.h)}function K(T,_){var I=_>>5;_%=32;for(var E=T.g.length-I,w=[],V=0;V<E;V++)w[V]=0<_?T.i(V+I)>>>_|T.i(V+I+1)<<32-_:T.i(V+I);return new a(w,T.h)}n.prototype.digest=n.prototype.v,n.prototype.reset=n.prototype.s,n.prototype.update=n.prototype.u,Gl=n,a.prototype.add=a.prototype.add,a.prototype.multiply=a.prototype.j,a.prototype.modulo=a.prototype.A,a.prototype.compare=a.prototype.l,a.prototype.toNumber=a.prototype.m,a.prototype.toString=a.prototype.toString,a.prototype.getBits=a.prototype.i,a.fromNumber=h,a.fromString=f,Se=a}).apply(typeof fc<"u"?fc:typeof self<"u"?self:typeof window<"u"?window:{});var Us=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var Kl,Fr,$l,Hs,Co,Ql,Wl,Hl;(function(){var r,t=typeof Object.defineProperties=="function"?Object.defineProperty:function(o,l,d){return o==Array.prototype||o==Object.prototype||(o[l]=d.value),o};function e(o){o=[typeof globalThis=="object"&&globalThis,o,typeof window=="object"&&window,typeof self=="object"&&self,typeof Us=="object"&&Us];for(var l=0;l<o.length;++l){var d=o[l];if(d&&d.Math==Math)return d}throw Error("Cannot find global object")}var n=e(this);function s(o,l){if(l)t:{var d=n;o=o.split(".");for(var g=0;g<o.length-1;g++){var A=o[g];if(!(A in d))break t;d=d[A]}o=o[o.length-1],g=d[o],l=l(g),l!=g&&l!=null&&t(d,o,{configurable:!0,writable:!0,value:l})}}function i(o,l){o instanceof String&&(o+="");var d=0,g=!1,A={next:function(){if(!g&&d<o.length){var S=d++;return{value:l(S,o[S]),done:!1}}return g=!0,{done:!0,value:void 0}}};return A[Symbol.iterator]=function(){return A},A}s("Array.prototype.values",function(o){return o||function(){return i(this,function(l,d){return d})}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var a=a||{},u=this||self;function c(o){var l=typeof o;return l=l!="object"?l:o?Array.isArray(o)?"array":l:"null",l=="array"||l=="object"&&typeof o.length=="number"}function h(o){var l=typeof o;return l=="object"&&o!=null||l=="function"}function f(o,l,d){return o.call.apply(o.bind,arguments)}function m(o,l,d){if(!o)throw Error();if(2<arguments.length){var g=Array.prototype.slice.call(arguments,2);return function(){var A=Array.prototype.slice.call(arguments);return Array.prototype.unshift.apply(A,g),o.apply(l,A)}}return function(){return o.apply(l,arguments)}}function p(o,l,d){return p=Function.prototype.bind&&Function.prototype.bind.toString().indexOf("native code")!=-1?f:m,p.apply(null,arguments)}function R(o,l){var d=Array.prototype.slice.call(arguments,1);return function(){var g=d.slice();return g.push.apply(g,arguments),o.apply(this,g)}}function b(o,l){function d(){}d.prototype=l.prototype,o.aa=l.prototype,o.prototype=new d,o.prototype.constructor=o,o.Qb=function(g,A,S){for(var O=Array(arguments.length-2),rt=2;rt<arguments.length;rt++)O[rt-2]=arguments[rt];return l.prototype[A].apply(g,O)}}function D(o){const l=o.length;if(0<l){const d=Array(l);for(let g=0;g<l;g++)d[g]=o[g];return d}return[]}function x(o,l){for(let d=1;d<arguments.length;d++){const g=arguments[d];if(c(g)){const A=o.length||0,S=g.length||0;o.length=A+S;for(let O=0;O<S;O++)o[A+O]=g[O]}else o.push(g)}}class L{constructor(l,d){this.i=l,this.j=d,this.h=0,this.g=null}get(){let l;return 0<this.h?(this.h--,l=this.g,this.g=l.next,l.next=null):l=this.i(),l}}function j(o){return/^[\s\xa0]*$/.test(o)}function B(){var o=u.navigator;return o&&(o=o.userAgent)?o:""}function $(o){return $[" "](o),o}$[" "]=function(){};var Y=B().indexOf("Gecko")!=-1&&!(B().toLowerCase().indexOf("webkit")!=-1&&B().indexOf("Edge")==-1)&&!(B().indexOf("Trident")!=-1||B().indexOf("MSIE")!=-1)&&B().indexOf("Edge")==-1;function K(o,l,d){for(const g in o)l.call(d,o[g],g,o)}function T(o,l){for(const d in o)l.call(void 0,o[d],d,o)}function _(o){const l={};for(const d in o)l[d]=o[d];return l}const I="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function E(o,l){let d,g;for(let A=1;A<arguments.length;A++){g=arguments[A];for(d in g)o[d]=g[d];for(let S=0;S<I.length;S++)d=I[S],Object.prototype.hasOwnProperty.call(g,d)&&(o[d]=g[d])}}function w(o){var l=1;o=o.split(":");const d=[];for(;0<l&&o.length;)d.push(o.shift()),l--;return o.length&&d.push(o.join(":")),d}function V(o){u.setTimeout(()=>{throw o},0)}function y(){var o=Ji;let l=null;return o.g&&(l=o.g,o.g=o.g.next,o.g||(o.h=null),l.next=null),l}class ie{constructor(){this.h=this.g=null}add(l,d){const g=fr.get();g.set(l,d),this.h?this.h.next=g:this.g=g,this.h=g}}var fr=new L(()=>new Cf,o=>o.reset());class Cf{constructor(){this.next=this.g=this.h=null}set(l,d){this.h=l,this.g=d,this.next=null}reset(){this.next=this.g=this.h=null}}let mr,gr=!1,Ji=new ie,du=()=>{const o=u.Promise.resolve(void 0);mr=()=>{o.then(Df)}};var Df=()=>{for(var o;o=y();){try{o.h.call(o.g)}catch(d){V(d)}var l=fr;l.j(o),100>l.h&&(l.h++,o.next=l.g,l.g=o)}gr=!1};function pe(){this.s=this.s,this.C=this.C}pe.prototype.s=!1,pe.prototype.ma=function(){this.s||(this.s=!0,this.N())},pe.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function Vt(o,l){this.type=o,this.g=this.target=l,this.defaultPrevented=!1}Vt.prototype.h=function(){this.defaultPrevented=!0};var xf=(function(){if(!u.addEventListener||!Object.defineProperty)return!1;var o=!1,l=Object.defineProperty({},"passive",{get:function(){o=!0}});try{const d=()=>{};u.addEventListener("test",d,l),u.removeEventListener("test",d,l)}catch{}return o})();function pr(o,l){if(Vt.call(this,o?o.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,o){var d=this.type=o.type,g=o.changedTouches&&o.changedTouches.length?o.changedTouches[0]:null;if(this.target=o.target||o.srcElement,this.g=l,l=o.relatedTarget){if(Y){t:{try{$(l.nodeName);var A=!0;break t}catch{}A=!1}A||(l=null)}}else d=="mouseover"?l=o.fromElement:d=="mouseout"&&(l=o.toElement);this.relatedTarget=l,g?(this.clientX=g.clientX!==void 0?g.clientX:g.pageX,this.clientY=g.clientY!==void 0?g.clientY:g.pageY,this.screenX=g.screenX||0,this.screenY=g.screenY||0):(this.clientX=o.clientX!==void 0?o.clientX:o.pageX,this.clientY=o.clientY!==void 0?o.clientY:o.pageY,this.screenX=o.screenX||0,this.screenY=o.screenY||0),this.button=o.button,this.key=o.key||"",this.ctrlKey=o.ctrlKey,this.altKey=o.altKey,this.shiftKey=o.shiftKey,this.metaKey=o.metaKey,this.pointerId=o.pointerId||0,this.pointerType=typeof o.pointerType=="string"?o.pointerType:Nf[o.pointerType]||"",this.state=o.state,this.i=o,o.defaultPrevented&&pr.aa.h.call(this)}}b(pr,Vt);var Nf={2:"touch",3:"pen",4:"mouse"};pr.prototype.h=function(){pr.aa.h.call(this);var o=this.i;o.preventDefault?o.preventDefault():o.returnValue=!1};var ws="closure_listenable_"+(1e6*Math.random()|0),kf=0;function Ff(o,l,d,g,A){this.listener=o,this.proxy=null,this.src=l,this.type=d,this.capture=!!g,this.ha=A,this.key=++kf,this.da=this.fa=!1}function vs(o){o.da=!0,o.listener=null,o.proxy=null,o.src=null,o.ha=null}function As(o){this.src=o,this.g={},this.h=0}As.prototype.add=function(o,l,d,g,A){var S=o.toString();o=this.g[S],o||(o=this.g[S]=[],this.h++);var O=Zi(o,l,g,A);return-1<O?(l=o[O],d||(l.fa=!1)):(l=new Ff(l,this.src,S,!!g,A),l.fa=d,o.push(l)),l};function Yi(o,l){var d=l.type;if(d in o.g){var g=o.g[d],A=Array.prototype.indexOf.call(g,l,void 0),S;(S=0<=A)&&Array.prototype.splice.call(g,A,1),S&&(vs(l),o.g[d].length==0&&(delete o.g[d],o.h--))}}function Zi(o,l,d,g){for(var A=0;A<o.length;++A){var S=o[A];if(!S.da&&S.listener==l&&S.capture==!!d&&S.ha==g)return A}return-1}var to="closure_lm_"+(1e6*Math.random()|0),eo={};function fu(o,l,d,g,A){if(Array.isArray(l)){for(var S=0;S<l.length;S++)fu(o,l[S],d,g,A);return null}return d=pu(d),o&&o[ws]?o.K(l,d,h(g)?!!g.capture:!1,A):Of(o,l,d,!1,g,A)}function Of(o,l,d,g,A,S){if(!l)throw Error("Invalid event type");var O=h(A)?!!A.capture:!!A,rt=ro(o);if(rt||(o[to]=rt=new As(o)),d=rt.add(l,d,g,O,S),d.proxy)return d;if(g=Mf(),d.proxy=g,g.src=o,g.listener=d,o.addEventListener)xf||(A=O),A===void 0&&(A=!1),o.addEventListener(l.toString(),g,A);else if(o.attachEvent)o.attachEvent(gu(l.toString()),g);else if(o.addListener&&o.removeListener)o.addListener(g);else throw Error("addEventListener and attachEvent are unavailable.");return d}function Mf(){function o(d){return l.call(o.src,o.listener,d)}const l=Lf;return o}function mu(o,l,d,g,A){if(Array.isArray(l))for(var S=0;S<l.length;S++)mu(o,l[S],d,g,A);else g=h(g)?!!g.capture:!!g,d=pu(d),o&&o[ws]?(o=o.i,l=String(l).toString(),l in o.g&&(S=o.g[l],d=Zi(S,d,g,A),-1<d&&(vs(S[d]),Array.prototype.splice.call(S,d,1),S.length==0&&(delete o.g[l],o.h--)))):o&&(o=ro(o))&&(l=o.g[l.toString()],o=-1,l&&(o=Zi(l,d,g,A)),(d=-1<o?l[o]:null)&&no(d))}function no(o){if(typeof o!="number"&&o&&!o.da){var l=o.src;if(l&&l[ws])Yi(l.i,o);else{var d=o.type,g=o.proxy;l.removeEventListener?l.removeEventListener(d,g,o.capture):l.detachEvent?l.detachEvent(gu(d),g):l.addListener&&l.removeListener&&l.removeListener(g),(d=ro(l))?(Yi(d,o),d.h==0&&(d.src=null,l[to]=null)):vs(o)}}}function gu(o){return o in eo?eo[o]:eo[o]="on"+o}function Lf(o,l){if(o.da)o=!0;else{l=new pr(l,this);var d=o.listener,g=o.ha||o.src;o.fa&&no(o),o=d.call(g,l)}return o}function ro(o){return o=o[to],o instanceof As?o:null}var so="__closure_events_fn_"+(1e9*Math.random()>>>0);function pu(o){return typeof o=="function"?o:(o[so]||(o[so]=function(l){return o.handleEvent(l)}),o[so])}function St(){pe.call(this),this.i=new As(this),this.M=this,this.F=null}b(St,pe),St.prototype[ws]=!0,St.prototype.removeEventListener=function(o,l,d,g){mu(this,o,l,d,g)};function Ft(o,l){var d,g=o.F;if(g)for(d=[];g;g=g.F)d.push(g);if(o=o.M,g=l.type||l,typeof l=="string")l=new Vt(l,o);else if(l instanceof Vt)l.target=l.target||o;else{var A=l;l=new Vt(g,o),E(l,A)}if(A=!0,d)for(var S=d.length-1;0<=S;S--){var O=l.g=d[S];A=Rs(O,g,!0,l)&&A}if(O=l.g=o,A=Rs(O,g,!0,l)&&A,A=Rs(O,g,!1,l)&&A,d)for(S=0;S<d.length;S++)O=l.g=d[S],A=Rs(O,g,!1,l)&&A}St.prototype.N=function(){if(St.aa.N.call(this),this.i){var o=this.i,l;for(l in o.g){for(var d=o.g[l],g=0;g<d.length;g++)vs(d[g]);delete o.g[l],o.h--}}this.F=null},St.prototype.K=function(o,l,d,g){return this.i.add(String(o),l,!1,d,g)},St.prototype.L=function(o,l,d,g){return this.i.add(String(o),l,!0,d,g)};function Rs(o,l,d,g){if(l=o.i.g[String(l)],!l)return!0;l=l.concat();for(var A=!0,S=0;S<l.length;++S){var O=l[S];if(O&&!O.da&&O.capture==d){var rt=O.listener,At=O.ha||O.src;O.fa&&Yi(o.i,O),A=rt.call(At,g)!==!1&&A}}return A&&!g.defaultPrevented}function _u(o,l,d){if(typeof o=="function")d&&(o=p(o,d));else if(o&&typeof o.handleEvent=="function")o=p(o.handleEvent,o);else throw Error("Invalid listener argument");return 2147483647<Number(l)?-1:u.setTimeout(o,l||0)}function yu(o){o.g=_u(()=>{o.g=null,o.i&&(o.i=!1,yu(o))},o.l);const l=o.h;o.h=null,o.m.apply(null,l)}class qf extends pe{constructor(l,d){super(),this.m=l,this.l=d,this.h=null,this.i=!1,this.g=null}j(l){this.h=arguments,this.g?this.i=!0:yu(this)}N(){super.N(),this.g&&(u.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function _r(o){pe.call(this),this.h=o,this.g={}}b(_r,pe);var Iu=[];function Tu(o){K(o.g,function(l,d){this.g.hasOwnProperty(d)&&no(l)},o),o.g={}}_r.prototype.N=function(){_r.aa.N.call(this),Tu(this)},_r.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var io=u.JSON.stringify,Bf=u.JSON.parse,Uf=class{stringify(o){return u.JSON.stringify(o,void 0)}parse(o){return u.JSON.parse(o,void 0)}};function oo(){}oo.prototype.h=null;function Eu(o){return o.h||(o.h=o.i())}function wu(){}var yr={OPEN:"a",kb:"b",Ja:"c",wb:"d"};function ao(){Vt.call(this,"d")}b(ao,Vt);function uo(){Vt.call(this,"c")}b(uo,Vt);var ze={},vu=null;function Ps(){return vu=vu||new St}ze.La="serverreachability";function Au(o){Vt.call(this,ze.La,o)}b(Au,Vt);function Ir(o){const l=Ps();Ft(l,new Au(l))}ze.STAT_EVENT="statevent";function Ru(o,l){Vt.call(this,ze.STAT_EVENT,o),this.stat=l}b(Ru,Vt);function Ot(o){const l=Ps();Ft(l,new Ru(l,o))}ze.Ma="timingevent";function Pu(o,l){Vt.call(this,ze.Ma,o),this.size=l}b(Pu,Vt);function Tr(o,l){if(typeof o!="function")throw Error("Fn must not be null and must be a function");return u.setTimeout(function(){o()},l)}function Er(){this.g=!0}Er.prototype.xa=function(){this.g=!1};function jf(o,l,d,g,A,S){o.info(function(){if(o.g)if(S)for(var O="",rt=S.split("&"),At=0;At<rt.length;At++){var J=rt[At].split("=");if(1<J.length){var bt=J[0];J=J[1];var Ct=bt.split("_");O=2<=Ct.length&&Ct[1]=="type"?O+(bt+"="+J+"&"):O+(bt+"=redacted&")}}else O=null;else O=S;return"XMLHTTP REQ ("+g+") [attempt "+A+"]: "+l+`
`+d+`
`+O})}function zf(o,l,d,g,A,S,O){o.info(function(){return"XMLHTTP RESP ("+g+") [ attempt "+A+"]: "+l+`
`+d+`
`+S+" "+O})}function En(o,l,d,g){o.info(function(){return"XMLHTTP TEXT ("+l+"): "+Kf(o,d)+(g?" "+g:"")})}function Gf(o,l){o.info(function(){return"TIMEOUT: "+l})}Er.prototype.info=function(){};function Kf(o,l){if(!o.g)return l;if(!l)return null;try{var d=JSON.parse(l);if(d){for(o=0;o<d.length;o++)if(Array.isArray(d[o])){var g=d[o];if(!(2>g.length)){var A=g[1];if(Array.isArray(A)&&!(1>A.length)){var S=A[0];if(S!="noop"&&S!="stop"&&S!="close")for(var O=1;O<A.length;O++)A[O]=""}}}}return io(d)}catch{return l}}var Vs={NO_ERROR:0,gb:1,tb:2,sb:3,nb:4,rb:5,ub:6,Ia:7,TIMEOUT:8,xb:9},Vu={lb:"complete",Hb:"success",Ja:"error",Ia:"abort",zb:"ready",Ab:"readystatechange",TIMEOUT:"timeout",vb:"incrementaldata",yb:"progress",ob:"downloadprogress",Pb:"uploadprogress"},co;function Ss(){}b(Ss,oo),Ss.prototype.g=function(){return new XMLHttpRequest},Ss.prototype.i=function(){return{}},co=new Ss;function _e(o,l,d,g){this.j=o,this.i=l,this.l=d,this.R=g||1,this.U=new _r(this),this.I=45e3,this.H=null,this.o=!1,this.m=this.A=this.v=this.L=this.F=this.S=this.B=null,this.D=[],this.g=null,this.C=0,this.s=this.u=null,this.X=-1,this.J=!1,this.O=0,this.M=null,this.W=this.K=this.T=this.P=!1,this.h=new Su}function Su(){this.i=null,this.g="",this.h=!1}var bu={},lo={};function ho(o,l,d){o.L=1,o.v=xs(oe(l)),o.m=d,o.P=!0,Cu(o,null)}function Cu(o,l){o.F=Date.now(),bs(o),o.A=oe(o.v);var d=o.A,g=o.R;Array.isArray(g)||(g=[String(g)]),Gu(d.i,"t",g),o.C=0,d=o.j.J,o.h=new Su,o.g=uc(o.j,d?l:null,!o.m),0<o.O&&(o.M=new qf(p(o.Y,o,o.g),o.O)),l=o.U,d=o.g,g=o.ca;var A="readystatechange";Array.isArray(A)||(A&&(Iu[0]=A.toString()),A=Iu);for(var S=0;S<A.length;S++){var O=fu(d,A[S],g||l.handleEvent,!1,l.h||l);if(!O)break;l.g[O.key]=O}l=o.H?_(o.H):{},o.m?(o.u||(o.u="POST"),l["Content-Type"]="application/x-www-form-urlencoded",o.g.ea(o.A,o.u,o.m,l)):(o.u="GET",o.g.ea(o.A,o.u,null,l)),Ir(),jf(o.i,o.u,o.A,o.l,o.R,o.m)}_e.prototype.ca=function(o){o=o.target;const l=this.M;l&&ae(o)==3?l.j():this.Y(o)},_e.prototype.Y=function(o){try{if(o==this.g)t:{const Ct=ae(this.g);var l=this.g.Ba();const An=this.g.Z();if(!(3>Ct)&&(Ct!=3||this.g&&(this.h.h||this.g.oa()||Ju(this.g)))){this.J||Ct!=4||l==7||(l==8||0>=An?Ir(3):Ir(2)),fo(this);var d=this.g.Z();this.X=d;e:if(Du(this)){var g=Ju(this.g);o="";var A=g.length,S=ae(this.g)==4;if(!this.h.i){if(typeof TextDecoder>"u"){Ge(this),wr(this);var O="";break e}this.h.i=new u.TextDecoder}for(l=0;l<A;l++)this.h.h=!0,o+=this.h.i.decode(g[l],{stream:!(S&&l==A-1)});g.length=0,this.h.g+=o,this.C=0,O=this.h.g}else O=this.g.oa();if(this.o=d==200,zf(this.i,this.u,this.A,this.l,this.R,Ct,d),this.o){if(this.T&&!this.K){e:{if(this.g){var rt,At=this.g;if((rt=At.g?At.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!j(rt)){var J=rt;break e}}J=null}if(d=J)En(this.i,this.l,d,"Initial handshake response via X-HTTP-Initial-Response"),this.K=!0,mo(this,d);else{this.o=!1,this.s=3,Ot(12),Ge(this),wr(this);break t}}if(this.P){d=!0;let Qt;for(;!this.J&&this.C<O.length;)if(Qt=$f(this,O),Qt==lo){Ct==4&&(this.s=4,Ot(14),d=!1),En(this.i,this.l,null,"[Incomplete Response]");break}else if(Qt==bu){this.s=4,Ot(15),En(this.i,this.l,O,"[Invalid Chunk]"),d=!1;break}else En(this.i,this.l,Qt,null),mo(this,Qt);if(Du(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),Ct!=4||O.length!=0||this.h.h||(this.s=1,Ot(16),d=!1),this.o=this.o&&d,!d)En(this.i,this.l,O,"[Invalid Chunked Response]"),Ge(this),wr(this);else if(0<O.length&&!this.W){this.W=!0;var bt=this.j;bt.g==this&&bt.ba&&!bt.M&&(bt.j.info("Great, no buffering proxy detected. Bytes received: "+O.length),To(bt),bt.M=!0,Ot(11))}}else En(this.i,this.l,O,null),mo(this,O);Ct==4&&Ge(this),this.o&&!this.J&&(Ct==4?sc(this.j,this):(this.o=!1,bs(this)))}else cm(this.g),d==400&&0<O.indexOf("Unknown SID")?(this.s=3,Ot(12)):(this.s=0,Ot(13)),Ge(this),wr(this)}}}catch{}finally{}};function Du(o){return o.g?o.u=="GET"&&o.L!=2&&o.j.Ca:!1}function $f(o,l){var d=o.C,g=l.indexOf(`
`,d);return g==-1?lo:(d=Number(l.substring(d,g)),isNaN(d)?bu:(g+=1,g+d>l.length?lo:(l=l.slice(g,g+d),o.C=g+d,l)))}_e.prototype.cancel=function(){this.J=!0,Ge(this)};function bs(o){o.S=Date.now()+o.I,xu(o,o.I)}function xu(o,l){if(o.B!=null)throw Error("WatchDog timer not null");o.B=Tr(p(o.ba,o),l)}function fo(o){o.B&&(u.clearTimeout(o.B),o.B=null)}_e.prototype.ba=function(){this.B=null;const o=Date.now();0<=o-this.S?(Gf(this.i,this.A),this.L!=2&&(Ir(),Ot(17)),Ge(this),this.s=2,wr(this)):xu(this,this.S-o)};function wr(o){o.j.G==0||o.J||sc(o.j,o)}function Ge(o){fo(o);var l=o.M;l&&typeof l.ma=="function"&&l.ma(),o.M=null,Tu(o.U),o.g&&(l=o.g,o.g=null,l.abort(),l.ma())}function mo(o,l){try{var d=o.j;if(d.G!=0&&(d.g==o||go(d.h,o))){if(!o.K&&go(d.h,o)&&d.G==3){try{var g=d.Da.g.parse(l)}catch{g=null}if(Array.isArray(g)&&g.length==3){var A=g;if(A[0]==0){t:if(!d.u){if(d.g)if(d.g.F+3e3<o.F)Ls(d),Os(d);else break t;Io(d),Ot(18)}}else d.za=A[1],0<d.za-d.T&&37500>A[2]&&d.F&&d.v==0&&!d.C&&(d.C=Tr(p(d.Za,d),6e3));if(1>=Fu(d.h)&&d.ca){try{d.ca()}catch{}d.ca=void 0}}else $e(d,11)}else if((o.K||d.g==o)&&Ls(d),!j(l))for(A=d.Da.g.parse(l),l=0;l<A.length;l++){let J=A[l];if(d.T=J[0],J=J[1],d.G==2)if(J[0]=="c"){d.K=J[1],d.ia=J[2];const bt=J[3];bt!=null&&(d.la=bt,d.j.info("VER="+d.la));const Ct=J[4];Ct!=null&&(d.Aa=Ct,d.j.info("SVER="+d.Aa));const An=J[5];An!=null&&typeof An=="number"&&0<An&&(g=1.5*An,d.L=g,d.j.info("backChannelRequestTimeoutMs_="+g)),g=d;const Qt=o.g;if(Qt){const Bs=Qt.g?Qt.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(Bs){var S=g.h;S.g||Bs.indexOf("spdy")==-1&&Bs.indexOf("quic")==-1&&Bs.indexOf("h2")==-1||(S.j=S.l,S.g=new Set,S.h&&(po(S,S.h),S.h=null))}if(g.D){const Eo=Qt.g?Qt.g.getResponseHeader("X-HTTP-Session-Id"):null;Eo&&(g.ya=Eo,ot(g.I,g.D,Eo))}}d.G=3,d.l&&d.l.ua(),d.ba&&(d.R=Date.now()-o.F,d.j.info("Handshake RTT: "+d.R+"ms")),g=d;var O=o;if(g.qa=ac(g,g.J?g.ia:null,g.W),O.K){Ou(g.h,O);var rt=O,At=g.L;At&&(rt.I=At),rt.B&&(fo(rt),bs(rt)),g.g=O}else nc(g);0<d.i.length&&Ms(d)}else J[0]!="stop"&&J[0]!="close"||$e(d,7);else d.G==3&&(J[0]=="stop"||J[0]=="close"?J[0]=="stop"?$e(d,7):yo(d):J[0]!="noop"&&d.l&&d.l.ta(J),d.v=0)}}Ir(4)}catch{}}var Qf=class{constructor(o,l){this.g=o,this.map=l}};function Nu(o){this.l=o||10,u.PerformanceNavigationTiming?(o=u.performance.getEntriesByType("navigation"),o=0<o.length&&(o[0].nextHopProtocol=="hq"||o[0].nextHopProtocol=="h2")):o=!!(u.chrome&&u.chrome.loadTimes&&u.chrome.loadTimes()&&u.chrome.loadTimes().wasFetchedViaSpdy),this.j=o?this.l:1,this.g=null,1<this.j&&(this.g=new Set),this.h=null,this.i=[]}function ku(o){return o.h?!0:o.g?o.g.size>=o.j:!1}function Fu(o){return o.h?1:o.g?o.g.size:0}function go(o,l){return o.h?o.h==l:o.g?o.g.has(l):!1}function po(o,l){o.g?o.g.add(l):o.h=l}function Ou(o,l){o.h&&o.h==l?o.h=null:o.g&&o.g.has(l)&&o.g.delete(l)}Nu.prototype.cancel=function(){if(this.i=Mu(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const o of this.g.values())o.cancel();this.g.clear()}};function Mu(o){if(o.h!=null)return o.i.concat(o.h.D);if(o.g!=null&&o.g.size!==0){let l=o.i;for(const d of o.g.values())l=l.concat(d.D);return l}return D(o.i)}function Wf(o){if(o.V&&typeof o.V=="function")return o.V();if(typeof Map<"u"&&o instanceof Map||typeof Set<"u"&&o instanceof Set)return Array.from(o.values());if(typeof o=="string")return o.split("");if(c(o)){for(var l=[],d=o.length,g=0;g<d;g++)l.push(o[g]);return l}l=[],d=0;for(g in o)l[d++]=o[g];return l}function Hf(o){if(o.na&&typeof o.na=="function")return o.na();if(!o.V||typeof o.V!="function"){if(typeof Map<"u"&&o instanceof Map)return Array.from(o.keys());if(!(typeof Set<"u"&&o instanceof Set)){if(c(o)||typeof o=="string"){var l=[];o=o.length;for(var d=0;d<o;d++)l.push(d);return l}l=[],d=0;for(const g in o)l[d++]=g;return l}}}function Lu(o,l){if(o.forEach&&typeof o.forEach=="function")o.forEach(l,void 0);else if(c(o)||typeof o=="string")Array.prototype.forEach.call(o,l,void 0);else for(var d=Hf(o),g=Wf(o),A=g.length,S=0;S<A;S++)l.call(void 0,g[S],d&&d[S],o)}var qu=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function Xf(o,l){if(o){o=o.split("&");for(var d=0;d<o.length;d++){var g=o[d].indexOf("="),A=null;if(0<=g){var S=o[d].substring(0,g);A=o[d].substring(g+1)}else S=o[d];l(S,A?decodeURIComponent(A.replace(/\+/g," ")):"")}}}function Ke(o){if(this.g=this.o=this.j="",this.s=null,this.m=this.l="",this.h=!1,o instanceof Ke){this.h=o.h,Cs(this,o.j),this.o=o.o,this.g=o.g,Ds(this,o.s),this.l=o.l;var l=o.i,d=new Rr;d.i=l.i,l.g&&(d.g=new Map(l.g),d.h=l.h),Bu(this,d),this.m=o.m}else o&&(l=String(o).match(qu))?(this.h=!1,Cs(this,l[1]||"",!0),this.o=vr(l[2]||""),this.g=vr(l[3]||"",!0),Ds(this,l[4]),this.l=vr(l[5]||"",!0),Bu(this,l[6]||"",!0),this.m=vr(l[7]||"")):(this.h=!1,this.i=new Rr(null,this.h))}Ke.prototype.toString=function(){var o=[],l=this.j;l&&o.push(Ar(l,Uu,!0),":");var d=this.g;return(d||l=="file")&&(o.push("//"),(l=this.o)&&o.push(Ar(l,Uu,!0),"@"),o.push(encodeURIComponent(String(d)).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),d=this.s,d!=null&&o.push(":",String(d))),(d=this.l)&&(this.g&&d.charAt(0)!="/"&&o.push("/"),o.push(Ar(d,d.charAt(0)=="/"?Zf:Yf,!0))),(d=this.i.toString())&&o.push("?",d),(d=this.m)&&o.push("#",Ar(d,em)),o.join("")};function oe(o){return new Ke(o)}function Cs(o,l,d){o.j=d?vr(l,!0):l,o.j&&(o.j=o.j.replace(/:$/,""))}function Ds(o,l){if(l){if(l=Number(l),isNaN(l)||0>l)throw Error("Bad port number "+l);o.s=l}else o.s=null}function Bu(o,l,d){l instanceof Rr?(o.i=l,nm(o.i,o.h)):(d||(l=Ar(l,tm)),o.i=new Rr(l,o.h))}function ot(o,l,d){o.i.set(l,d)}function xs(o){return ot(o,"zx",Math.floor(2147483648*Math.random()).toString(36)+Math.abs(Math.floor(2147483648*Math.random())^Date.now()).toString(36)),o}function vr(o,l){return o?l?decodeURI(o.replace(/%25/g,"%2525")):decodeURIComponent(o):""}function Ar(o,l,d){return typeof o=="string"?(o=encodeURI(o).replace(l,Jf),d&&(o=o.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),o):null}function Jf(o){return o=o.charCodeAt(0),"%"+(o>>4&15).toString(16)+(o&15).toString(16)}var Uu=/[#\/\?@]/g,Yf=/[#\?:]/g,Zf=/[#\?]/g,tm=/[#\?@]/g,em=/#/g;function Rr(o,l){this.h=this.g=null,this.i=o||null,this.j=!!l}function ye(o){o.g||(o.g=new Map,o.h=0,o.i&&Xf(o.i,function(l,d){o.add(decodeURIComponent(l.replace(/\+/g," ")),d)}))}r=Rr.prototype,r.add=function(o,l){ye(this),this.i=null,o=wn(this,o);var d=this.g.get(o);return d||this.g.set(o,d=[]),d.push(l),this.h+=1,this};function ju(o,l){ye(o),l=wn(o,l),o.g.has(l)&&(o.i=null,o.h-=o.g.get(l).length,o.g.delete(l))}function zu(o,l){return ye(o),l=wn(o,l),o.g.has(l)}r.forEach=function(o,l){ye(this),this.g.forEach(function(d,g){d.forEach(function(A){o.call(l,A,g,this)},this)},this)},r.na=function(){ye(this);const o=Array.from(this.g.values()),l=Array.from(this.g.keys()),d=[];for(let g=0;g<l.length;g++){const A=o[g];for(let S=0;S<A.length;S++)d.push(l[g])}return d},r.V=function(o){ye(this);let l=[];if(typeof o=="string")zu(this,o)&&(l=l.concat(this.g.get(wn(this,o))));else{o=Array.from(this.g.values());for(let d=0;d<o.length;d++)l=l.concat(o[d])}return l},r.set=function(o,l){return ye(this),this.i=null,o=wn(this,o),zu(this,o)&&(this.h-=this.g.get(o).length),this.g.set(o,[l]),this.h+=1,this},r.get=function(o,l){return o?(o=this.V(o),0<o.length?String(o[0]):l):l};function Gu(o,l,d){ju(o,l),0<d.length&&(o.i=null,o.g.set(wn(o,l),D(d)),o.h+=d.length)}r.toString=function(){if(this.i)return this.i;if(!this.g)return"";const o=[],l=Array.from(this.g.keys());for(var d=0;d<l.length;d++){var g=l[d];const S=encodeURIComponent(String(g)),O=this.V(g);for(g=0;g<O.length;g++){var A=S;O[g]!==""&&(A+="="+encodeURIComponent(String(O[g]))),o.push(A)}}return this.i=o.join("&")};function wn(o,l){return l=String(l),o.j&&(l=l.toLowerCase()),l}function nm(o,l){l&&!o.j&&(ye(o),o.i=null,o.g.forEach(function(d,g){var A=g.toLowerCase();g!=A&&(ju(this,g),Gu(this,A,d))},o)),o.j=l}function rm(o,l){const d=new Er;if(u.Image){const g=new Image;g.onload=R(Ie,d,"TestLoadImage: loaded",!0,l,g),g.onerror=R(Ie,d,"TestLoadImage: error",!1,l,g),g.onabort=R(Ie,d,"TestLoadImage: abort",!1,l,g),g.ontimeout=R(Ie,d,"TestLoadImage: timeout",!1,l,g),u.setTimeout(function(){g.ontimeout&&g.ontimeout()},1e4),g.src=o}else l(!1)}function sm(o,l){const d=new Er,g=new AbortController,A=setTimeout(()=>{g.abort(),Ie(d,"TestPingServer: timeout",!1,l)},1e4);fetch(o,{signal:g.signal}).then(S=>{clearTimeout(A),S.ok?Ie(d,"TestPingServer: ok",!0,l):Ie(d,"TestPingServer: server error",!1,l)}).catch(()=>{clearTimeout(A),Ie(d,"TestPingServer: error",!1,l)})}function Ie(o,l,d,g,A){try{A&&(A.onload=null,A.onerror=null,A.onabort=null,A.ontimeout=null),g(d)}catch{}}function im(){this.g=new Uf}function om(o,l,d){const g=d||"";try{Lu(o,function(A,S){let O=A;h(A)&&(O=io(A)),l.push(g+S+"="+encodeURIComponent(O))})}catch(A){throw l.push(g+"type="+encodeURIComponent("_badmap")),A}}function Ns(o){this.l=o.Ub||null,this.j=o.eb||!1}b(Ns,oo),Ns.prototype.g=function(){return new ks(this.l,this.j)},Ns.prototype.i=(function(o){return function(){return o}})({});function ks(o,l){St.call(this),this.D=o,this.o=l,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.u=new Headers,this.h=null,this.B="GET",this.A="",this.g=!1,this.v=this.j=this.l=null}b(ks,St),r=ks.prototype,r.open=function(o,l){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.B=o,this.A=l,this.readyState=1,Vr(this)},r.send=function(o){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");this.g=!0;const l={headers:this.u,method:this.B,credentials:this.m,cache:void 0};o&&(l.body=o),(this.D||u).fetch(new Request(this.A,l)).then(this.Sa.bind(this),this.ga.bind(this))},r.abort=function(){this.response=this.responseText="",this.u=new Headers,this.status=0,this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),1<=this.readyState&&this.g&&this.readyState!=4&&(this.g=!1,Pr(this)),this.readyState=0},r.Sa=function(o){if(this.g&&(this.l=o,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=o.headers,this.readyState=2,Vr(this)),this.g&&(this.readyState=3,Vr(this),this.g)))if(this.responseType==="arraybuffer")o.arrayBuffer().then(this.Qa.bind(this),this.ga.bind(this));else if(typeof u.ReadableStream<"u"&&"body"in o){if(this.j=o.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.v=new TextDecoder;Ku(this)}else o.text().then(this.Ra.bind(this),this.ga.bind(this))};function Ku(o){o.j.read().then(o.Pa.bind(o)).catch(o.ga.bind(o))}r.Pa=function(o){if(this.g){if(this.o&&o.value)this.response.push(o.value);else if(!this.o){var l=o.value?o.value:new Uint8Array(0);(l=this.v.decode(l,{stream:!o.done}))&&(this.response=this.responseText+=l)}o.done?Pr(this):Vr(this),this.readyState==3&&Ku(this)}},r.Ra=function(o){this.g&&(this.response=this.responseText=o,Pr(this))},r.Qa=function(o){this.g&&(this.response=o,Pr(this))},r.ga=function(){this.g&&Pr(this)};function Pr(o){o.readyState=4,o.l=null,o.j=null,o.v=null,Vr(o)}r.setRequestHeader=function(o,l){this.u.append(o,l)},r.getResponseHeader=function(o){return this.h&&this.h.get(o.toLowerCase())||""},r.getAllResponseHeaders=function(){if(!this.h)return"";const o=[],l=this.h.entries();for(var d=l.next();!d.done;)d=d.value,o.push(d[0]+": "+d[1]),d=l.next();return o.join(`\r
`)};function Vr(o){o.onreadystatechange&&o.onreadystatechange.call(o)}Object.defineProperty(ks.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(o){this.m=o?"include":"same-origin"}});function $u(o){let l="";return K(o,function(d,g){l+=g,l+=":",l+=d,l+=`\r
`}),l}function _o(o,l,d){t:{for(g in d){var g=!1;break t}g=!0}g||(d=$u(d),typeof o=="string"?d!=null&&encodeURIComponent(String(d)):ot(o,l,d))}function dt(o){St.call(this),this.headers=new Map,this.o=o||null,this.h=!1,this.v=this.g=null,this.D="",this.m=0,this.l="",this.j=this.B=this.u=this.A=!1,this.I=null,this.H="",this.J=!1}b(dt,St);var am=/^https?$/i,um=["POST","PUT"];r=dt.prototype,r.Ha=function(o){this.J=o},r.ea=function(o,l,d,g){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+o);l=l?l.toUpperCase():"GET",this.D=o,this.l="",this.m=0,this.A=!1,this.h=!0,this.g=this.o?this.o.g():co.g(),this.v=this.o?Eu(this.o):Eu(co),this.g.onreadystatechange=p(this.Ea,this);try{this.B=!0,this.g.open(l,String(o),!0),this.B=!1}catch(S){Qu(this,S);return}if(o=d||"",d=new Map(this.headers),g)if(Object.getPrototypeOf(g)===Object.prototype)for(var A in g)d.set(A,g[A]);else if(typeof g.keys=="function"&&typeof g.get=="function")for(const S of g.keys())d.set(S,g.get(S));else throw Error("Unknown input type for opt_headers: "+String(g));g=Array.from(d.keys()).find(S=>S.toLowerCase()=="content-type"),A=u.FormData&&o instanceof u.FormData,!(0<=Array.prototype.indexOf.call(um,l,void 0))||g||A||d.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[S,O]of d)this.g.setRequestHeader(S,O);this.H&&(this.g.responseType=this.H),"withCredentials"in this.g&&this.g.withCredentials!==this.J&&(this.g.withCredentials=this.J);try{Xu(this),this.u=!0,this.g.send(o),this.u=!1}catch(S){Qu(this,S)}};function Qu(o,l){o.h=!1,o.g&&(o.j=!0,o.g.abort(),o.j=!1),o.l=l,o.m=5,Wu(o),Fs(o)}function Wu(o){o.A||(o.A=!0,Ft(o,"complete"),Ft(o,"error"))}r.abort=function(o){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.m=o||7,Ft(this,"complete"),Ft(this,"abort"),Fs(this))},r.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),Fs(this,!0)),dt.aa.N.call(this)},r.Ea=function(){this.s||(this.B||this.u||this.j?Hu(this):this.bb())},r.bb=function(){Hu(this)};function Hu(o){if(o.h&&typeof a<"u"&&(!o.v[1]||ae(o)!=4||o.Z()!=2)){if(o.u&&ae(o)==4)_u(o.Ea,0,o);else if(Ft(o,"readystatechange"),ae(o)==4){o.h=!1;try{const O=o.Z();t:switch(O){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var l=!0;break t;default:l=!1}var d;if(!(d=l)){var g;if(g=O===0){var A=String(o.D).match(qu)[1]||null;!A&&u.self&&u.self.location&&(A=u.self.location.protocol.slice(0,-1)),g=!am.test(A?A.toLowerCase():"")}d=g}if(d)Ft(o,"complete"),Ft(o,"success");else{o.m=6;try{var S=2<ae(o)?o.g.statusText:""}catch{S=""}o.l=S+" ["+o.Z()+"]",Wu(o)}}finally{Fs(o)}}}}function Fs(o,l){if(o.g){Xu(o);const d=o.g,g=o.v[0]?()=>{}:null;o.g=null,o.v=null,l||Ft(o,"ready");try{d.onreadystatechange=g}catch{}}}function Xu(o){o.I&&(u.clearTimeout(o.I),o.I=null)}r.isActive=function(){return!!this.g};function ae(o){return o.g?o.g.readyState:0}r.Z=function(){try{return 2<ae(this)?this.g.status:-1}catch{return-1}},r.oa=function(){try{return this.g?this.g.responseText:""}catch{return""}},r.Oa=function(o){if(this.g){var l=this.g.responseText;return o&&l.indexOf(o)==0&&(l=l.substring(o.length)),Bf(l)}};function Ju(o){try{if(!o.g)return null;if("response"in o.g)return o.g.response;switch(o.H){case"":case"text":return o.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in o.g)return o.g.mozResponseArrayBuffer}return null}catch{return null}}function cm(o){const l={};o=(o.g&&2<=ae(o)&&o.g.getAllResponseHeaders()||"").split(`\r
`);for(let g=0;g<o.length;g++){if(j(o[g]))continue;var d=w(o[g]);const A=d[0];if(d=d[1],typeof d!="string")continue;d=d.trim();const S=l[A]||[];l[A]=S,S.push(d)}T(l,function(g){return g.join(", ")})}r.Ba=function(){return this.m},r.Ka=function(){return typeof this.l=="string"?this.l:String(this.l)};function Sr(o,l,d){return d&&d.internalChannelParams&&d.internalChannelParams[o]||l}function Yu(o){this.Aa=0,this.i=[],this.j=new Er,this.ia=this.qa=this.I=this.W=this.g=this.ya=this.D=this.H=this.m=this.S=this.o=null,this.Ya=this.U=0,this.Va=Sr("failFast",!1,o),this.F=this.C=this.u=this.s=this.l=null,this.X=!0,this.za=this.T=-1,this.Y=this.v=this.B=0,this.Ta=Sr("baseRetryDelayMs",5e3,o),this.cb=Sr("retryDelaySeedMs",1e4,o),this.Wa=Sr("forwardChannelMaxRetries",2,o),this.wa=Sr("forwardChannelRequestTimeoutMs",2e4,o),this.pa=o&&o.xmlHttpFactory||void 0,this.Xa=o&&o.Tb||void 0,this.Ca=o&&o.useFetchStreams||!1,this.L=void 0,this.J=o&&o.supportsCrossDomainXhr||!1,this.K="",this.h=new Nu(o&&o.concurrentRequestLimit),this.Da=new im,this.P=o&&o.fastHandshake||!1,this.O=o&&o.encodeInitMessageHeaders||!1,this.P&&this.O&&(this.O=!1),this.Ua=o&&o.Rb||!1,o&&o.xa&&this.j.xa(),o&&o.forceLongPolling&&(this.X=!1),this.ba=!this.P&&this.X&&o&&o.detectBufferingProxy||!1,this.ja=void 0,o&&o.longPollingTimeout&&0<o.longPollingTimeout&&(this.ja=o.longPollingTimeout),this.ca=void 0,this.R=0,this.M=!1,this.ka=this.A=null}r=Yu.prototype,r.la=8,r.G=1,r.connect=function(o,l,d,g){Ot(0),this.W=o,this.H=l||{},d&&g!==void 0&&(this.H.OSID=d,this.H.OAID=g),this.F=this.X,this.I=ac(this,null,this.W),Ms(this)};function yo(o){if(Zu(o),o.G==3){var l=o.U++,d=oe(o.I);if(ot(d,"SID",o.K),ot(d,"RID",l),ot(d,"TYPE","terminate"),br(o,d),l=new _e(o,o.j,l),l.L=2,l.v=xs(oe(d)),d=!1,u.navigator&&u.navigator.sendBeacon)try{d=u.navigator.sendBeacon(l.v.toString(),"")}catch{}!d&&u.Image&&(new Image().src=l.v,d=!0),d||(l.g=uc(l.j,null),l.g.ea(l.v)),l.F=Date.now(),bs(l)}oc(o)}function Os(o){o.g&&(To(o),o.g.cancel(),o.g=null)}function Zu(o){Os(o),o.u&&(u.clearTimeout(o.u),o.u=null),Ls(o),o.h.cancel(),o.s&&(typeof o.s=="number"&&u.clearTimeout(o.s),o.s=null)}function Ms(o){if(!ku(o.h)&&!o.s){o.s=!0;var l=o.Ga;mr||du(),gr||(mr(),gr=!0),Ji.add(l,o),o.B=0}}function lm(o,l){return Fu(o.h)>=o.h.j-(o.s?1:0)?!1:o.s?(o.i=l.D.concat(o.i),!0):o.G==1||o.G==2||o.B>=(o.Va?0:o.Wa)?!1:(o.s=Tr(p(o.Ga,o,l),ic(o,o.B)),o.B++,!0)}r.Ga=function(o){if(this.s)if(this.s=null,this.G==1){if(!o){this.U=Math.floor(1e5*Math.random()),o=this.U++;const A=new _e(this,this.j,o);let S=this.o;if(this.S&&(S?(S=_(S),E(S,this.S)):S=this.S),this.m!==null||this.O||(A.H=S,S=null),this.P)t:{for(var l=0,d=0;d<this.i.length;d++){e:{var g=this.i[d];if("__data__"in g.map&&(g=g.map.__data__,typeof g=="string")){g=g.length;break e}g=void 0}if(g===void 0)break;if(l+=g,4096<l){l=d;break t}if(l===4096||d===this.i.length-1){l=d+1;break t}}l=1e3}else l=1e3;l=ec(this,A,l),d=oe(this.I),ot(d,"RID",o),ot(d,"CVER",22),this.D&&ot(d,"X-HTTP-Session-Id",this.D),br(this,d),S&&(this.O?l="headers="+encodeURIComponent(String($u(S)))+"&"+l:this.m&&_o(d,this.m,S)),po(this.h,A),this.Ua&&ot(d,"TYPE","init"),this.P?(ot(d,"$req",l),ot(d,"SID","null"),A.T=!0,ho(A,d,null)):ho(A,d,l),this.G=2}}else this.G==3&&(o?tc(this,o):this.i.length==0||ku(this.h)||tc(this))};function tc(o,l){var d;l?d=l.l:d=o.U++;const g=oe(o.I);ot(g,"SID",o.K),ot(g,"RID",d),ot(g,"AID",o.T),br(o,g),o.m&&o.o&&_o(g,o.m,o.o),d=new _e(o,o.j,d,o.B+1),o.m===null&&(d.H=o.o),l&&(o.i=l.D.concat(o.i)),l=ec(o,d,1e3),d.I=Math.round(.5*o.wa)+Math.round(.5*o.wa*Math.random()),po(o.h,d),ho(d,g,l)}function br(o,l){o.H&&K(o.H,function(d,g){ot(l,g,d)}),o.l&&Lu({},function(d,g){ot(l,g,d)})}function ec(o,l,d){d=Math.min(o.i.length,d);var g=o.l?p(o.l.Na,o.l,o):null;t:{var A=o.i;let S=-1;for(;;){const O=["count="+d];S==-1?0<d?(S=A[0].g,O.push("ofs="+S)):S=0:O.push("ofs="+S);let rt=!0;for(let At=0;At<d;At++){let J=A[At].g;const bt=A[At].map;if(J-=S,0>J)S=Math.max(0,A[At].g-100),rt=!1;else try{om(bt,O,"req"+J+"_")}catch{g&&g(bt)}}if(rt){g=O.join("&");break t}}}return o=o.i.splice(0,d),l.D=o,g}function nc(o){if(!o.g&&!o.u){o.Y=1;var l=o.Fa;mr||du(),gr||(mr(),gr=!0),Ji.add(l,o),o.v=0}}function Io(o){return o.g||o.u||3<=o.v?!1:(o.Y++,o.u=Tr(p(o.Fa,o),ic(o,o.v)),o.v++,!0)}r.Fa=function(){if(this.u=null,rc(this),this.ba&&!(this.M||this.g==null||0>=this.R)){var o=2*this.R;this.j.info("BP detection timer enabled: "+o),this.A=Tr(p(this.ab,this),o)}},r.ab=function(){this.A&&(this.A=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.M=!0,Ot(10),Os(this),rc(this))};function To(o){o.A!=null&&(u.clearTimeout(o.A),o.A=null)}function rc(o){o.g=new _e(o,o.j,"rpc",o.Y),o.m===null&&(o.g.H=o.o),o.g.O=0;var l=oe(o.qa);ot(l,"RID","rpc"),ot(l,"SID",o.K),ot(l,"AID",o.T),ot(l,"CI",o.F?"0":"1"),!o.F&&o.ja&&ot(l,"TO",o.ja),ot(l,"TYPE","xmlhttp"),br(o,l),o.m&&o.o&&_o(l,o.m,o.o),o.L&&(o.g.I=o.L);var d=o.g;o=o.ia,d.L=1,d.v=xs(oe(l)),d.m=null,d.P=!0,Cu(d,o)}r.Za=function(){this.C!=null&&(this.C=null,Os(this),Io(this),Ot(19))};function Ls(o){o.C!=null&&(u.clearTimeout(o.C),o.C=null)}function sc(o,l){var d=null;if(o.g==l){Ls(o),To(o),o.g=null;var g=2}else if(go(o.h,l))d=l.D,Ou(o.h,l),g=1;else return;if(o.G!=0){if(l.o)if(g==1){d=l.m?l.m.length:0,l=Date.now()-l.F;var A=o.B;g=Ps(),Ft(g,new Pu(g,d)),Ms(o)}else nc(o);else if(A=l.s,A==3||A==0&&0<l.X||!(g==1&&lm(o,l)||g==2&&Io(o)))switch(d&&0<d.length&&(l=o.h,l.i=l.i.concat(d)),A){case 1:$e(o,5);break;case 4:$e(o,10);break;case 3:$e(o,6);break;default:$e(o,2)}}}function ic(o,l){let d=o.Ta+Math.floor(Math.random()*o.cb);return o.isActive()||(d*=2),d*l}function $e(o,l){if(o.j.info("Error code "+l),l==2){var d=p(o.fb,o),g=o.Xa;const A=!g;g=new Ke(g||"//www.google.com/images/cleardot.gif"),u.location&&u.location.protocol=="http"||Cs(g,"https"),xs(g),A?rm(g.toString(),d):sm(g.toString(),d)}else Ot(2);o.G=0,o.l&&o.l.sa(l),oc(o),Zu(o)}r.fb=function(o){o?(this.j.info("Successfully pinged google.com"),Ot(2)):(this.j.info("Failed to ping google.com"),Ot(1))};function oc(o){if(o.G=0,o.ka=[],o.l){const l=Mu(o.h);(l.length!=0||o.i.length!=0)&&(x(o.ka,l),x(o.ka,o.i),o.h.i.length=0,D(o.i),o.i.length=0),o.l.ra()}}function ac(o,l,d){var g=d instanceof Ke?oe(d):new Ke(d);if(g.g!="")l&&(g.g=l+"."+g.g),Ds(g,g.s);else{var A=u.location;g=A.protocol,l=l?l+"."+A.hostname:A.hostname,A=+A.port;var S=new Ke(null);g&&Cs(S,g),l&&(S.g=l),A&&Ds(S,A),d&&(S.l=d),g=S}return d=o.D,l=o.ya,d&&l&&ot(g,d,l),ot(g,"VER",o.la),br(o,g),g}function uc(o,l,d){if(l&&!o.J)throw Error("Can't create secondary domain capable XhrIo object.");return l=o.Ca&&!o.pa?new dt(new Ns({eb:d})):new dt(o.pa),l.Ha(o.J),l}r.isActive=function(){return!!this.l&&this.l.isActive(this)};function cc(){}r=cc.prototype,r.ua=function(){},r.ta=function(){},r.sa=function(){},r.ra=function(){},r.isActive=function(){return!0},r.Na=function(){};function qs(){}qs.prototype.g=function(o,l){return new Ut(o,l)};function Ut(o,l){St.call(this),this.g=new Yu(l),this.l=o,this.h=l&&l.messageUrlParams||null,o=l&&l.messageHeaders||null,l&&l.clientProtocolHeaderRequired&&(o?o["X-Client-Protocol"]="webchannel":o={"X-Client-Protocol":"webchannel"}),this.g.o=o,o=l&&l.initMessageHeaders||null,l&&l.messageContentType&&(o?o["X-WebChannel-Content-Type"]=l.messageContentType:o={"X-WebChannel-Content-Type":l.messageContentType}),l&&l.va&&(o?o["X-WebChannel-Client-Profile"]=l.va:o={"X-WebChannel-Client-Profile":l.va}),this.g.S=o,(o=l&&l.Sb)&&!j(o)&&(this.g.m=o),this.v=l&&l.supportsCrossDomainXhr||!1,this.u=l&&l.sendRawJson||!1,(l=l&&l.httpSessionIdParam)&&!j(l)&&(this.g.D=l,o=this.h,o!==null&&l in o&&(o=this.h,l in o&&delete o[l])),this.j=new vn(this)}b(Ut,St),Ut.prototype.m=function(){this.g.l=this.j,this.v&&(this.g.J=!0),this.g.connect(this.l,this.h||void 0)},Ut.prototype.close=function(){yo(this.g)},Ut.prototype.o=function(o){var l=this.g;if(typeof o=="string"){var d={};d.__data__=o,o=d}else this.u&&(d={},d.__data__=io(o),o=d);l.i.push(new Qf(l.Ya++,o)),l.G==3&&Ms(l)},Ut.prototype.N=function(){this.g.l=null,delete this.j,yo(this.g),delete this.g,Ut.aa.N.call(this)};function lc(o){ao.call(this),o.__headers__&&(this.headers=o.__headers__,this.statusCode=o.__status__,delete o.__headers__,delete o.__status__);var l=o.__sm__;if(l){t:{for(const d in l){o=d;break t}o=void 0}(this.i=o)&&(o=this.i,l=l!==null&&o in l?l[o]:void 0),this.data=l}else this.data=o}b(lc,ao);function hc(){uo.call(this),this.status=1}b(hc,uo);function vn(o){this.g=o}b(vn,cc),vn.prototype.ua=function(){Ft(this.g,"a")},vn.prototype.ta=function(o){Ft(this.g,new lc(o))},vn.prototype.sa=function(o){Ft(this.g,new hc)},vn.prototype.ra=function(){Ft(this.g,"b")},qs.prototype.createWebChannel=qs.prototype.g,Ut.prototype.send=Ut.prototype.o,Ut.prototype.open=Ut.prototype.m,Ut.prototype.close=Ut.prototype.close,Hl=function(){return new qs},Wl=function(){return Ps()},Ql=ze,Co={mb:0,pb:1,qb:2,Jb:3,Ob:4,Lb:5,Mb:6,Kb:7,Ib:8,Nb:9,PROXY:10,NOPROXY:11,Gb:12,Cb:13,Db:14,Bb:15,Eb:16,Fb:17,ib:18,hb:19,jb:20},Vs.NO_ERROR=0,Vs.TIMEOUT=8,Vs.HTTP_ERROR=6,Hs=Vs,Vu.COMPLETE="complete",$l=Vu,wu.EventType=yr,yr.OPEN="a",yr.CLOSE="b",yr.ERROR="c",yr.MESSAGE="d",St.prototype.listen=St.prototype.K,Fr=wu,dt.prototype.listenOnce=dt.prototype.L,dt.prototype.getLastError=dt.prototype.Ka,dt.prototype.getLastErrorCode=dt.prototype.Ba,dt.prototype.getStatus=dt.prototype.Z,dt.prototype.getResponseJson=dt.prototype.Oa,dt.prototype.getResponseText=dt.prototype.oa,dt.prototype.send=dt.prototype.ea,dt.prototype.setWithCredentials=dt.prototype.Ha,Kl=dt}).apply(typeof Us<"u"?Us:typeof self<"u"?self:typeof window<"u"?window:{});const mc="@firebase/firestore",gc="4.8.0";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Et{constructor(t){this.uid=t}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(t){return t.uid===this.uid}}Et.UNAUTHENTICATED=new Et(null),Et.GOOGLE_CREDENTIALS=new Et("google-credentials-uid"),Et.FIRST_PARTY=new Et("first-party-uid"),Et.MOCK_USER=new Et("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let rr="11.10.0";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ce=new dm("@firebase/firestore");function Dn(){return Ce.logLevel}function fy(r){Ce.setLogLevel(r)}function N(r,...t){if(Ce.logLevel<=ue.DEBUG){const e=t.map(sa);Ce.debug(`Firestore (${rr}): ${r}`,...e)}}function mt(r,...t){if(Ce.logLevel<=ue.ERROR){const e=t.map(sa);Ce.error(`Firestore (${rr}): ${r}`,...e)}}function Mt(r,...t){if(Ce.logLevel<=ue.WARN){const e=t.map(sa);Ce.warn(`Firestore (${rr}): ${r}`,...e)}}function sa(r){if(typeof r=="string")return r;try{/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/return(function(e){return JSON.stringify(e)})(r)}catch{return r}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function M(r,t,e){let n="Unexpected state";typeof t=="string"?n=t:e=t,Xl(r,n,e)}function Xl(r,t,e){let n=`FIRESTORE (${rr}) INTERNAL ASSERTION FAILED: ${t} (ID: ${r.toString(16)})`;if(e!==void 0)try{n+=" CONTEXT: "+JSON.stringify(e)}catch{n+=" CONTEXT: "+e}throw mt(n),new Error(n)}function q(r,t,e,n){let s="Unexpected state";typeof e=="string"?s=e:n=e,r||Xl(t,s,n)}function my(r,t){r||M(57014,t)}function F(r,t){return r}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const P={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class C extends hm{constructor(t,e){super(t,e),this.code=t,this.message=e,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wt{constructor(){this.promise=new Promise(((t,e)=>{this.resolve=t,this.reject=e}))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jl{constructor(t,e){this.user=e,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${t}`)}}class Am{getToken(){return Promise.resolve(null)}invalidateToken(){}start(t,e){t.enqueueRetryable((()=>e(Et.UNAUTHENTICATED)))}shutdown(){}}class Rm{constructor(t){this.token=t,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(t,e){this.changeListener=e,t.enqueueRetryable((()=>e(this.token.user)))}shutdown(){this.changeListener=null}}class Pm{constructor(t){this.t=t,this.currentUser=Et.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(t,e){q(this.o===void 0,42304);let n=this.i;const s=c=>this.i!==n?(n=this.i,e(c)):Promise.resolve();let i=new wt;this.o=()=>{this.i++,this.currentUser=this.u(),i.resolve(),i=new wt,t.enqueueRetryable((()=>s(this.currentUser)))};const a=()=>{const c=i;t.enqueueRetryable((async()=>{await c.promise,await s(this.currentUser)}))},u=c=>{N("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=c,this.o&&(this.auth.addAuthTokenListener(this.o),a())};this.t.onInit((c=>u(c))),setTimeout((()=>{if(!this.auth){const c=this.t.getImmediate({optional:!0});c?u(c):(N("FirebaseAuthCredentialsProvider","Auth not yet detected"),i.resolve(),i=new wt)}}),0),a()}getToken(){const t=this.i,e=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(e).then((n=>this.i!==t?(N("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):n?(q(typeof n.accessToken=="string",31837,{l:n}),new Jl(n.accessToken,this.currentUser)):null)):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.o&&this.auth.removeAuthTokenListener(this.o),this.o=void 0}u(){const t=this.auth&&this.auth.getUid();return q(t===null||typeof t=="string",2055,{h:t}),new Et(t)}}class Vm{constructor(t,e,n){this.P=t,this.T=e,this.I=n,this.type="FirstParty",this.user=Et.FIRST_PARTY,this.A=new Map}R(){return this.I?this.I():null}get headers(){this.A.set("X-Goog-AuthUser",this.P);const t=this.R();return t&&this.A.set("Authorization",t),this.T&&this.A.set("X-Goog-Iam-Authorization-Token",this.T),this.A}}class Sm{constructor(t,e,n){this.P=t,this.T=e,this.I=n}getToken(){return Promise.resolve(new Vm(this.P,this.T,this.I))}start(t,e){t.enqueueRetryable((()=>e(Et.FIRST_PARTY)))}shutdown(){}invalidateToken(){}}class Do{constructor(t){this.value=t,this.type="AppCheck",this.headers=new Map,t&&t.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class bm{constructor(t,e){this.V=e,this.forceRefresh=!1,this.appCheck=null,this.m=null,this.p=null,vm(t)&&t.settings.appCheckToken&&(this.p=t.settings.appCheckToken)}start(t,e){q(this.o===void 0,3512);const n=i=>{i.error!=null&&N("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${i.error.message}`);const a=i.token!==this.m;return this.m=i.token,N("FirebaseAppCheckTokenProvider",`Received ${a?"new":"existing"} token.`),a?e(i.token):Promise.resolve()};this.o=i=>{t.enqueueRetryable((()=>n(i)))};const s=i=>{N("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=i,this.o&&this.appCheck.addTokenListener(this.o)};this.V.onInit((i=>s(i))),setTimeout((()=>{if(!this.appCheck){const i=this.V.getImmediate({optional:!0});i?s(i):N("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}}),0)}getToken(){if(this.p)return Promise.resolve(new Do(this.p));const t=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(t).then((e=>e?(q(typeof e.token=="string",44558,{tokenResult:e}),this.m=e.token,new Do(e.token)):null)):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.o&&this.appCheck.removeTokenListener(this.o),this.o=void 0}}class gy{getToken(){return Promise.resolve(new Do(""))}invalidateToken(){}start(t,e){}shutdown(){}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Cm(r){const t=typeof self<"u"&&(self.crypto||self.msCrypto),e=new Uint8Array(r);if(t&&typeof t.getRandomValues=="function")t.getRandomValues(e);else for(let n=0;n<r;n++)e[n]=Math.floor(256*Math.random());return e}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ia(){return new TextEncoder}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class oa{static newId(){const t="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",e=62*Math.floor(4.129032258064516);let n="";for(;n.length<20;){const s=Cm(40);for(let i=0;i<s.length;++i)n.length<20&&s[i]<e&&(n+=t.charAt(s[i]%62))}return n}}function z(r,t){return r<t?-1:r>t?1:0}function xo(r,t){let e=0;for(;e<r.length&&e<t.length;){const n=r.codePointAt(e),s=t.codePointAt(e);if(n!==s){if(n<128&&s<128)return z(n,s);{const i=ia(),a=Dm(i.encode(pc(r,e)),i.encode(pc(t,e)));return a!==0?a:z(n,s)}}e+=n>65535?2:1}return z(r.length,t.length)}function pc(r,t){return r.codePointAt(t)>65535?r.substring(t,t+2):r.substring(t,t+1)}function Dm(r,t){for(let e=0;e<r.length&&e<t.length;++e)if(r[e]!==t[e])return z(r[e],t[e]);return z(r.length,t.length)}function Mn(r,t,e){return r.length===t.length&&r.every(((n,s)=>e(n,t[s])))}function Yl(r){return r+"\0"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const No="__name__";class Xt{constructor(t,e,n){e===void 0?e=0:e>t.length&&M(637,{offset:e,range:t.length}),n===void 0?n=t.length-e:n>t.length-e&&M(1746,{length:n,range:t.length-e}),this.segments=t,this.offset=e,this.len=n}get length(){return this.len}isEqual(t){return Xt.comparator(this,t)===0}child(t){const e=this.segments.slice(this.offset,this.limit());return t instanceof Xt?t.forEach((n=>{e.push(n)})):e.push(t),this.construct(e)}limit(){return this.offset+this.length}popFirst(t){return t=t===void 0?1:t,this.construct(this.segments,this.offset+t,this.length-t)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(t){return this.segments[this.offset+t]}isEmpty(){return this.length===0}isPrefixOf(t){if(t.length<this.length)return!1;for(let e=0;e<this.length;e++)if(this.get(e)!==t.get(e))return!1;return!0}isImmediateParentOf(t){if(this.length+1!==t.length)return!1;for(let e=0;e<this.length;e++)if(this.get(e)!==t.get(e))return!1;return!0}forEach(t){for(let e=this.offset,n=this.limit();e<n;e++)t(this.segments[e])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(t,e){const n=Math.min(t.length,e.length);for(let s=0;s<n;s++){const i=Xt.compareSegments(t.get(s),e.get(s));if(i!==0)return i}return z(t.length,e.length)}static compareSegments(t,e){const n=Xt.isNumericId(t),s=Xt.isNumericId(e);return n&&!s?-1:!n&&s?1:n&&s?Xt.extractNumericId(t).compare(Xt.extractNumericId(e)):xo(t,e)}static isNumericId(t){return t.startsWith("__id")&&t.endsWith("__")}static extractNumericId(t){return Se.fromString(t.substring(4,t.length-2))}}class Q extends Xt{construct(t,e,n){return new Q(t,e,n)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...t){const e=[];for(const n of t){if(n.indexOf("//")>=0)throw new C(P.INVALID_ARGUMENT,`Invalid segment (${n}). Paths must not contain // in them.`);e.push(...n.split("/").filter((s=>s.length>0)))}return new Q(e)}static emptyPath(){return new Q([])}}const xm=/^[_a-zA-Z][_a-zA-Z0-9]*$/;class ct extends Xt{construct(t,e,n){return new ct(t,e,n)}static isValidIdentifier(t){return xm.test(t)}canonicalString(){return this.toArray().map((t=>(t=t.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),ct.isValidIdentifier(t)||(t="`"+t+"`"),t))).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)===No}static keyField(){return new ct([No])}static fromServerFormat(t){const e=[];let n="",s=0;const i=()=>{if(n.length===0)throw new C(P.INVALID_ARGUMENT,`Invalid field path (${t}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);e.push(n),n=""};let a=!1;for(;s<t.length;){const u=t[s];if(u==="\\"){if(s+1===t.length)throw new C(P.INVALID_ARGUMENT,"Path has trailing escape character: "+t);const c=t[s+1];if(c!=="\\"&&c!=="."&&c!=="`")throw new C(P.INVALID_ARGUMENT,"Path has invalid escape sequence: "+t);n+=c,s+=2}else u==="`"?(a=!a,s++):u!=="."||a?(n+=u,s++):(i(),s++)}if(i(),a)throw new C(P.INVALID_ARGUMENT,"Unterminated ` in path: "+t);return new ct(e)}static emptyPath(){return new ct([])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class k{constructor(t){this.path=t}static fromPath(t){return new k(Q.fromString(t))}static fromName(t){return new k(Q.fromString(t).popFirst(5))}static empty(){return new k(Q.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(t){return this.path.length>=2&&this.path.get(this.path.length-2)===t}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(t){return t!==null&&Q.comparator(this.path,t.path)===0}toString(){return this.path.toString()}static comparator(t,e){return Q.comparator(t.path,e.path)}static isDocumentKey(t){return t.length%2==0}static fromSegments(t){return new k(new Q(t.slice()))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function aa(r,t,e){if(!e)throw new C(P.INVALID_ARGUMENT,`Function ${r}() cannot be called with an empty ${t}.`)}function Nm(r,t,e,n){if(t===!0&&n===!0)throw new C(P.INVALID_ARGUMENT,`${r} and ${e} cannot be used together.`)}function _c(r){if(!k.isDocumentKey(r))throw new C(P.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${r} has ${r.length}.`)}function yc(r){if(k.isDocumentKey(r))throw new C(P.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${r} has ${r.length}.`)}function Zl(r){return typeof r=="object"&&r!==null&&(Object.getPrototypeOf(r)===Object.prototype||Object.getPrototypeOf(r)===null)}function vi(r){if(r===void 0)return"undefined";if(r===null)return"null";if(typeof r=="string")return r.length>20&&(r=`${r.substring(0,20)}...`),JSON.stringify(r);if(typeof r=="number"||typeof r=="boolean")return""+r;if(typeof r=="object"){if(r instanceof Array)return"an array";{const t=(function(n){return n.constructor?n.constructor.name:null})(r);return t?`a custom ${t} object`:"an object"}}return typeof r=="function"?"a function":M(12329,{type:typeof r})}function W(r,t){if("_delegate"in r&&(r=r._delegate),!(r instanceof t)){if(t.name===r.constructor.name)throw new C(P.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const e=vi(r);throw new C(P.INVALID_ARGUMENT,`Expected type '${t.name}', but it was: ${e}`)}}return r}function th(r,t){if(t<=0)throw new C(P.INVALID_ARGUMENT,`Function ${r}() requires a positive number, but it was: ${t}.`)}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _t(r,t){const e={typeString:r};return t&&(e.value=t),e}function gn(r,t){if(!Zl(r))throw new C(P.INVALID_ARGUMENT,"JSON must be an object");let e;for(const n in t)if(t[n]){const s=t[n].typeString,i="value"in t[n]?{value:t[n].value}:void 0;if(!(n in r)){e=`JSON missing required field: '${n}'`;break}const a=r[n];if(s&&typeof a!==s){e=`JSON field '${n}' must be a ${s}.`;break}if(i!==void 0&&a!==i.value){e=`Expected '${n}' field to equal '${i.value}'`;break}}if(e)throw new C(P.INVALID_ARGUMENT,e);return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ic=-62135596800,Tc=1e6;class Z{static now(){return Z.fromMillis(Date.now())}static fromDate(t){return Z.fromMillis(t.getTime())}static fromMillis(t){const e=Math.floor(t/1e3),n=Math.floor((t-1e3*e)*Tc);return new Z(e,n)}constructor(t,e){if(this.seconds=t,this.nanoseconds=e,e<0)throw new C(P.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+e);if(e>=1e9)throw new C(P.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+e);if(t<Ic)throw new C(P.INVALID_ARGUMENT,"Timestamp seconds out of range: "+t);if(t>=253402300800)throw new C(P.INVALID_ARGUMENT,"Timestamp seconds out of range: "+t)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/Tc}_compareTo(t){return this.seconds===t.seconds?z(this.nanoseconds,t.nanoseconds):z(this.seconds,t.seconds)}isEqual(t){return t.seconds===this.seconds&&t.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{type:Z._jsonSchemaVersion,seconds:this.seconds,nanoseconds:this.nanoseconds}}static fromJSON(t){if(gn(t,Z._jsonSchema))return new Z(t.seconds,t.nanoseconds)}valueOf(){const t=this.seconds-Ic;return String(t).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}Z._jsonSchemaVersion="firestore/timestamp/1.0",Z._jsonSchema={type:_t("string",Z._jsonSchemaVersion),seconds:_t("number"),nanoseconds:_t("number")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class U{static fromTimestamp(t){return new U(t)}static min(){return new U(new Z(0,0))}static max(){return new U(new Z(253402300799,999999999))}constructor(t){this.timestamp=t}compareTo(t){return this.timestamp._compareTo(t.timestamp)}isEqual(t){return this.timestamp.isEqual(t.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ln=-1;class qn{constructor(t,e,n,s){this.indexId=t,this.collectionGroup=e,this.fields=n,this.indexState=s}}function ko(r){return r.fields.find((t=>t.kind===2))}function We(r){return r.fields.filter((t=>t.kind!==2))}function km(r,t){let e=z(r.collectionGroup,t.collectionGroup);if(e!==0)return e;for(let n=0;n<Math.min(r.fields.length,t.fields.length);++n)if(e=Fm(r.fields[n],t.fields[n]),e!==0)return e;return z(r.fields.length,t.fields.length)}qn.UNKNOWN_ID=-1;class en{constructor(t,e){this.fieldPath=t,this.kind=e}}function Fm(r,t){const e=ct.comparator(r.fieldPath,t.fieldPath);return e!==0?e:z(r.kind,t.kind)}class Bn{constructor(t,e){this.sequenceNumber=t,this.offset=e}static empty(){return new Bn(0,$t.min())}}function eh(r,t){const e=r.toTimestamp().seconds,n=r.toTimestamp().nanoseconds+1,s=U.fromTimestamp(n===1e9?new Z(e+1,0):new Z(e,n));return new $t(s,k.empty(),t)}function nh(r){return new $t(r.readTime,r.key,Ln)}class $t{constructor(t,e,n){this.readTime=t,this.documentKey=e,this.largestBatchId=n}static min(){return new $t(U.min(),k.empty(),Ln)}static max(){return new $t(U.max(),k.empty(),Ln)}}function ua(r,t){let e=r.readTime.compareTo(t.readTime);return e!==0?e:(e=k.comparator(r.documentKey,t.documentKey),e!==0?e:z(r.largestBatchId,t.largestBatchId))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rh="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class sh{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(t){this.onCommittedListeners.push(t)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach((t=>t()))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Me(r){if(r.code!==P.FAILED_PRECONDITION||r.message!==rh)throw r;N("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class v{constructor(t){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,t((e=>{this.isDone=!0,this.result=e,this.nextCallback&&this.nextCallback(e)}),(e=>{this.isDone=!0,this.error=e,this.catchCallback&&this.catchCallback(e)}))}catch(t){return this.next(void 0,t)}next(t,e){return this.callbackAttached&&M(59440),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(e,this.error):this.wrapSuccess(t,this.result):new v(((n,s)=>{this.nextCallback=i=>{this.wrapSuccess(t,i).next(n,s)},this.catchCallback=i=>{this.wrapFailure(e,i).next(n,s)}}))}toPromise(){return new Promise(((t,e)=>{this.next(t,e)}))}wrapUserFunction(t){try{const e=t();return e instanceof v?e:v.resolve(e)}catch(e){return v.reject(e)}}wrapSuccess(t,e){return t?this.wrapUserFunction((()=>t(e))):v.resolve(e)}wrapFailure(t,e){return t?this.wrapUserFunction((()=>t(e))):v.reject(e)}static resolve(t){return new v(((e,n)=>{e(t)}))}static reject(t){return new v(((e,n)=>{n(t)}))}static waitFor(t){return new v(((e,n)=>{let s=0,i=0,a=!1;t.forEach((u=>{++s,u.next((()=>{++i,a&&i===s&&e()}),(c=>n(c)))})),a=!0,i===s&&e()}))}static or(t){let e=v.resolve(!1);for(const n of t)e=e.next((s=>s?v.resolve(s):n()));return e}static forEach(t,e){const n=[];return t.forEach(((s,i)=>{n.push(e.call(this,s,i))})),this.waitFor(n)}static mapArray(t,e){return new v(((n,s)=>{const i=t.length,a=new Array(i);let u=0;for(let c=0;c<i;c++){const h=c;e(t[h]).next((f=>{a[h]=f,++u,u===i&&n(a)}),(f=>s(f)))}}))}static doWhile(t,e){return new v(((n,s)=>{const i=()=>{t()===!0?e().next((()=>{i()}),s):n()};i()}))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const jt="SimpleDb";class Ai{static open(t,e,n,s){try{return new Ai(e,t.transaction(s,n))}catch(i){throw new qr(e,i)}}constructor(t,e){this.action=t,this.transaction=e,this.aborted=!1,this.S=new wt,this.transaction.oncomplete=()=>{this.S.resolve()},this.transaction.onabort=()=>{e.error?this.S.reject(new qr(t,e.error)):this.S.resolve()},this.transaction.onerror=n=>{const s=ca(n.target.error);this.S.reject(new qr(t,s))}}get D(){return this.S.promise}abort(t){t&&this.S.reject(t),this.aborted||(N(jt,"Aborting transaction:",t?t.message:"Client-initiated abort"),this.aborted=!0,this.transaction.abort())}v(){const t=this.transaction;this.aborted||typeof t.commit!="function"||t.commit()}store(t){const e=this.transaction.objectStore(t);return new Mm(e)}}class te{static delete(t){return N(jt,"Removing database:",t),Xe(ym().indexedDB.deleteDatabase(t)).toPromise()}static C(){if(!Im())return!1;if(te.F())return!0;const t=oi(),e=te.M(t),n=0<e&&e<10,s=ih(t),i=0<s&&s<4.5;return!(t.indexOf("MSIE ")>0||t.indexOf("Trident/")>0||t.indexOf("Edge/")>0||n||i)}static F(){var t;return typeof process<"u"&&((t=process.__PRIVATE_env)===null||t===void 0?void 0:t.O)==="YES"}static N(t,e){return t.store(e)}static M(t){const e=t.match(/i(?:phone|pad|pod) os ([\d_]+)/i),n=e?e[1].split("_").slice(0,2).join("."):"-1";return Number(n)}constructor(t,e,n){this.name=t,this.version=e,this.B=n,this.L=null,te.M(oi())===12.2&&mt("Firestore persistence suffers from a bug in iOS 12.2 Safari that may cause your app to stop working. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.")}async k(t){return this.db||(N(jt,"Opening database:",this.name),this.db=await new Promise(((e,n)=>{const s=indexedDB.open(this.name,this.version);s.onsuccess=i=>{const a=i.target.result;e(a)},s.onblocked=()=>{n(new qr(t,"Cannot upgrade IndexedDB schema while another tab is open. Close all tabs that access Firestore and reload this page to proceed."))},s.onerror=i=>{const a=i.target.error;a.name==="VersionError"?n(new C(P.FAILED_PRECONDITION,"A newer version of the Firestore SDK was previously used and so the persisted data is not compatible with the version of the SDK you are now using. The SDK will operate with persistence disabled. If you need persistence, please re-upgrade to a newer version of the SDK or else clear the persisted IndexedDB data for your app to start fresh.")):a.name==="InvalidStateError"?n(new C(P.FAILED_PRECONDITION,"Unable to open an IndexedDB connection. This could be due to running in a private browsing session on a browser whose private browsing sessions do not support IndexedDB: "+a)):n(new qr(t,a))},s.onupgradeneeded=i=>{N(jt,'Database "'+this.name+'" requires upgrade from version:',i.oldVersion);const a=i.target.result;if(this.L!==null&&this.L!==i.oldVersion)throw new Error(`refusing to open IndexedDB database due to potential corruption of the IndexedDB database data; this corruption could be caused by clicking the "clear site data" button in a web browser; try reloading the web page to re-initialize the IndexedDB database: lastClosedDbVersion=${this.L}, event.oldVersion=${i.oldVersion}, event.newVersion=${i.newVersion}, db.version=${a.version}`);this.B.q(a,s.transaction,i.oldVersion,this.version).next((()=>{N(jt,"Database upgrade to version "+this.version+" complete")}))}})),this.db.addEventListener("close",(e=>{const n=e.target;this.L=n.version}),{passive:!0})),this.db.addEventListener("versionchange",(e=>{var n;e.newVersion===null&&(Mt('Received "versionchange" event with newVersion===null; notifying the registered DatabaseDeletedListener, if any'),(n=this.databaseDeletedListener)===null||n===void 0||n.call(this))}),{passive:!0}),this.db}setDatabaseDeletedListener(t){if(this.databaseDeletedListener)throw new Error("setDatabaseDeletedListener() may only be called once, and it has already been called");this.databaseDeletedListener=t}async runTransaction(t,e,n,s){const i=e==="readonly";let a=0;for(;;){++a;try{this.db=await this.k(t);const u=Ai.open(this.db,t,i?"readonly":"readwrite",n),c=s(u).next((h=>(u.v(),h))).catch((h=>(u.abort(h),v.reject(h)))).toPromise();return c.catch((()=>{})),await u.D,c}catch(u){const c=u,h=c.name!=="FirebaseError"&&a<3;if(N(jt,"Transaction failed with error:",c.message,"Retrying:",h),this.close(),!h)return Promise.reject(c)}}}close(){this.db&&this.db.close(),this.db=void 0}}function ih(r){const t=r.match(/Android ([\d.]+)/i),e=t?t[1].split(".").slice(0,2).join("."):"-1";return Number(e)}class Om{constructor(t){this.$=t,this.U=!1,this.K=null}get isDone(){return this.U}get W(){return this.K}set cursor(t){this.$=t}done(){this.U=!0}G(t){this.K=t}delete(){return Xe(this.$.delete())}}class qr extends C{constructor(t,e){super(P.UNAVAILABLE,`IndexedDB transaction '${t}' failed: ${e}`),this.name="IndexedDbTransactionError"}}function Le(r){return r.name==="IndexedDbTransactionError"}class Mm{constructor(t){this.store=t}put(t,e){let n;return e!==void 0?(N(jt,"PUT",this.store.name,t,e),n=this.store.put(e,t)):(N(jt,"PUT",this.store.name,"<auto-key>",t),n=this.store.put(t)),Xe(n)}add(t){return N(jt,"ADD",this.store.name,t,t),Xe(this.store.add(t))}get(t){return Xe(this.store.get(t)).next((e=>(e===void 0&&(e=null),N(jt,"GET",this.store.name,t,e),e)))}delete(t){return N(jt,"DELETE",this.store.name,t),Xe(this.store.delete(t))}count(){return N(jt,"COUNT",this.store.name),Xe(this.store.count())}j(t,e){const n=this.options(t,e),s=n.index?this.store.index(n.index):this.store;if(typeof s.getAll=="function"){const i=s.getAll(n.range);return new v(((a,u)=>{i.onerror=c=>{u(c.target.error)},i.onsuccess=c=>{a(c.target.result)}}))}{const i=this.cursor(n),a=[];return this.J(i,((u,c)=>{a.push(c)})).next((()=>a))}}H(t,e){const n=this.store.getAll(t,e===null?void 0:e);return new v(((s,i)=>{n.onerror=a=>{i(a.target.error)},n.onsuccess=a=>{s(a.target.result)}}))}Y(t,e){N(jt,"DELETE ALL",this.store.name);const n=this.options(t,e);n.Z=!1;const s=this.cursor(n);return this.J(s,((i,a,u)=>u.delete()))}X(t,e){let n;e?n=t:(n={},e=t);const s=this.cursor(n);return this.J(s,e)}ee(t){const e=this.cursor({});return new v(((n,s)=>{e.onerror=i=>{const a=ca(i.target.error);s(a)},e.onsuccess=i=>{const a=i.target.result;a?t(a.primaryKey,a.value).next((u=>{u?a.continue():n()})):n()}}))}J(t,e){const n=[];return new v(((s,i)=>{t.onerror=a=>{i(a.target.error)},t.onsuccess=a=>{const u=a.target.result;if(!u)return void s();const c=new Om(u),h=e(u.primaryKey,u.value,c);if(h instanceof v){const f=h.catch((m=>(c.done(),v.reject(m))));n.push(f)}c.isDone?s():c.W===null?u.continue():u.continue(c.W)}})).next((()=>v.waitFor(n)))}options(t,e){let n;return t!==void 0&&(typeof t=="string"?n=t:e=t),{index:n,range:e}}cursor(t){let e="next";if(t.reverse&&(e="prev"),t.index){const n=this.store.index(t.index);return t.Z?n.openKeyCursor(t.range,e):n.openCursor(t.range,e)}return this.store.openCursor(t.range,e)}}function Xe(r){return new v(((t,e)=>{r.onsuccess=n=>{const s=n.target.result;t(s)},r.onerror=n=>{const s=ca(n.target.error);e(s)}}))}let Ec=!1;function ca(r){const t=te.M(oi());if(t>=12.2&&t<13){const e="An internal error was encountered in the Indexed Database server";if(r.message.indexOf(e)>=0){const n=new C("internal",`IOS_INDEXEDDB_BUG1: IndexedDb has thrown '${e}'. This is likely due to an unavoidable bug in iOS. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.`);return Ec||(Ec=!0,setTimeout((()=>{throw n}),0)),n}}return r}const Br="IndexBackfiller";class Lm{constructor(t,e){this.asyncQueue=t,this.te=e,this.task=null}start(){this.ne(15e3)}stop(){this.task&&(this.task.cancel(),this.task=null)}get started(){return this.task!==null}ne(t){N(Br,`Scheduled in ${t}ms`),this.task=this.asyncQueue.enqueueAfterDelay("index_backfill",t,(async()=>{this.task=null;try{const e=await this.te.re();N(Br,`Documents written: ${e}`)}catch(e){Le(e)?N(Br,"Ignoring IndexedDB error during index backfill: ",e):await Me(e)}await this.ne(6e4)}))}}class qm{constructor(t,e){this.localStore=t,this.persistence=e}async re(t=50){return this.persistence.runTransaction("Backfill Indexes","readwrite-primary",(e=>this.ie(e,t)))}ie(t,e){const n=new Set;let s=e,i=!0;return v.doWhile((()=>i===!0&&s>0),(()=>this.localStore.indexManager.getNextCollectionGroupToUpdate(t).next((a=>{if(a!==null&&!n.has(a))return N(Br,`Processing collection: ${a}`),this.se(t,a,s).next((u=>{s-=u,n.add(a)}));i=!1})))).next((()=>e-s))}se(t,e,n){return this.localStore.indexManager.getMinOffsetFromCollectionGroup(t,e).next((s=>this.localStore.localDocuments.getNextDocuments(t,e,s,n).next((i=>{const a=i.changes;return this.localStore.indexManager.updateIndexEntries(t,a).next((()=>this.oe(s,i))).next((u=>(N(Br,`Updating offset: ${u}`),this.localStore.indexManager.updateCollectionGroup(t,e,u)))).next((()=>a.size))}))))}oe(t,e){let n=t;return e.changes.forEach(((s,i)=>{const a=nh(i);ua(a,n)>0&&(n=a)})),new $t(n.readTime,n.documentKey,Math.max(e.batchId,t.largestBatchId))}}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lt{constructor(t,e){this.previousValue=t,e&&(e.sequenceNumberHandler=n=>this._e(n),this.ae=n=>e.writeSequenceNumber(n))}_e(t){return this.previousValue=Math.max(t,this.previousValue),this.previousValue}next(){const t=++this.previousValue;return this.ae&&this.ae(t),t}}Lt.ue=-1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const be=-1;function us(r){return r==null}function Qr(r){return r===0&&1/r==-1/0}function oh(r){return typeof r=="number"&&Number.isInteger(r)&&!Qr(r)&&r<=Number.MAX_SAFE_INTEGER&&r>=Number.MIN_SAFE_INTEGER}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ai="";function Nt(r){let t="";for(let e=0;e<r.length;e++)t.length>0&&(t=wc(t)),t=Bm(r.get(e),t);return wc(t)}function Bm(r,t){let e=t;const n=r.length;for(let s=0;s<n;s++){const i=r.charAt(s);switch(i){case"\0":e+="";break;case ai:e+="";break;default:e+=i}}return e}function wc(r){return r+ai+""}function Yt(r){const t=r.length;if(q(t>=2,64408,{path:r}),t===2)return q(r.charAt(0)===ai&&r.charAt(1)==="",56145,{path:r}),Q.emptyPath();const e=t-2,n=[];let s="";for(let i=0;i<t;){const a=r.indexOf(ai,i);switch((a<0||a>e)&&M(50515,{path:r}),r.charAt(a+1)){case"":const u=r.substring(i,a);let c;s.length===0?c=u:(s+=u,c=s,s=""),n.push(c);break;case"":s+=r.substring(i,a),s+="\0";break;case"":s+=r.substring(i,a+1);break;default:M(61167,{path:r})}i=a+2}return new Q(n)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const He="remoteDocuments",cs="owner",Rn="owner",Wr="mutationQueues",Um="userId",Wt="mutations",vc="batchId",tn="userMutationsIndex",Ac=["userId","batchId"];/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xs(r,t){return[r,Nt(t)]}function ah(r,t,e){return[r,Nt(t),e]}const jm={},Un="documentMutations",ui="remoteDocumentsV14",zm=["prefixPath","collectionGroup","readTime","documentId"],Js="documentKeyIndex",Gm=["prefixPath","collectionGroup","documentId"],uh="collectionGroupIndex",Km=["collectionGroup","readTime","prefixPath","documentId"],Hr="remoteDocumentGlobal",Fo="remoteDocumentGlobalKey",jn="targets",ch="queryTargetsIndex",$m=["canonicalId","targetId"],zn="targetDocuments",Qm=["targetId","path"],la="documentTargetsIndex",Wm=["path","targetId"],ci="targetGlobalKey",nn="targetGlobal",Xr="collectionParents",Hm=["collectionId","parent"],Gn="clientMetadata",Xm="clientId",Ri="bundles",Jm="bundleId",Pi="namedQueries",Ym="name",ha="indexConfiguration",Zm="indexId",Oo="collectionGroupIndex",tg="collectionGroup",Ur="indexState",eg=["indexId","uid"],lh="sequenceNumberIndex",ng=["uid","sequenceNumber"],jr="indexEntries",rg=["indexId","uid","arrayValue","directionalValue","orderedDocumentKey","documentKey"],hh="documentKeyIndex",sg=["indexId","uid","orderedDocumentKey"],Vi="documentOverlays",ig=["userId","collectionPath","documentId"],Mo="collectionPathOverlayIndex",og=["userId","collectionPath","largestBatchId"],dh="collectionGroupOverlayIndex",ag=["userId","collectionGroup","largestBatchId"],da="globals",ug="name",fh=[Wr,Wt,Un,He,jn,cs,nn,zn,Gn,Hr,Xr,Ri,Pi],cg=[...fh,Vi],mh=[Wr,Wt,Un,ui,jn,cs,nn,zn,Gn,Hr,Xr,Ri,Pi,Vi],gh=mh,fa=[...gh,ha,Ur,jr],lg=fa,ph=[...fa,da],hg=ph;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lo extends sh{constructor(t,e){super(),this.ce=t,this.currentSequenceNumber=e}}function It(r,t){const e=F(r);return te.N(e.ce,t)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Rc(r){let t=0;for(const e in r)Object.prototype.hasOwnProperty.call(r,e)&&t++;return t}function qe(r,t){for(const e in r)Object.prototype.hasOwnProperty.call(r,e)&&t(e,r[e])}function _h(r,t){const e=[];for(const n in r)Object.prototype.hasOwnProperty.call(r,n)&&e.push(t(r[n],n,r));return e}function yh(r){for(const t in r)if(Object.prototype.hasOwnProperty.call(r,t))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class it{constructor(t,e){this.comparator=t,this.root=e||Rt.EMPTY}insert(t,e){return new it(this.comparator,this.root.insert(t,e,this.comparator).copy(null,null,Rt.BLACK,null,null))}remove(t){return new it(this.comparator,this.root.remove(t,this.comparator).copy(null,null,Rt.BLACK,null,null))}get(t){let e=this.root;for(;!e.isEmpty();){const n=this.comparator(t,e.key);if(n===0)return e.value;n<0?e=e.left:n>0&&(e=e.right)}return null}indexOf(t){let e=0,n=this.root;for(;!n.isEmpty();){const s=this.comparator(t,n.key);if(s===0)return e+n.left.size;s<0?n=n.left:(e+=n.left.size+1,n=n.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(t){return this.root.inorderTraversal(t)}forEach(t){this.inorderTraversal(((e,n)=>(t(e,n),!1)))}toString(){const t=[];return this.inorderTraversal(((e,n)=>(t.push(`${e}:${n}`),!1))),`{${t.join(", ")}}`}reverseTraversal(t){return this.root.reverseTraversal(t)}getIterator(){return new js(this.root,null,this.comparator,!1)}getIteratorFrom(t){return new js(this.root,t,this.comparator,!1)}getReverseIterator(){return new js(this.root,null,this.comparator,!0)}getReverseIteratorFrom(t){return new js(this.root,t,this.comparator,!0)}}class js{constructor(t,e,n,s){this.isReverse=s,this.nodeStack=[];let i=1;for(;!t.isEmpty();)if(i=e?n(t.key,e):1,e&&s&&(i*=-1),i<0)t=this.isReverse?t.left:t.right;else{if(i===0){this.nodeStack.push(t);break}this.nodeStack.push(t),t=this.isReverse?t.right:t.left}}getNext(){let t=this.nodeStack.pop();const e={key:t.key,value:t.value};if(this.isReverse)for(t=t.left;!t.isEmpty();)this.nodeStack.push(t),t=t.right;else for(t=t.right;!t.isEmpty();)this.nodeStack.push(t),t=t.left;return e}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const t=this.nodeStack[this.nodeStack.length-1];return{key:t.key,value:t.value}}}class Rt{constructor(t,e,n,s,i){this.key=t,this.value=e,this.color=n??Rt.RED,this.left=s??Rt.EMPTY,this.right=i??Rt.EMPTY,this.size=this.left.size+1+this.right.size}copy(t,e,n,s,i){return new Rt(t??this.key,e??this.value,n??this.color,s??this.left,i??this.right)}isEmpty(){return!1}inorderTraversal(t){return this.left.inorderTraversal(t)||t(this.key,this.value)||this.right.inorderTraversal(t)}reverseTraversal(t){return this.right.reverseTraversal(t)||t(this.key,this.value)||this.left.reverseTraversal(t)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(t,e,n){let s=this;const i=n(t,s.key);return s=i<0?s.copy(null,null,null,s.left.insert(t,e,n),null):i===0?s.copy(null,e,null,null,null):s.copy(null,null,null,null,s.right.insert(t,e,n)),s.fixUp()}removeMin(){if(this.left.isEmpty())return Rt.EMPTY;let t=this;return t.left.isRed()||t.left.left.isRed()||(t=t.moveRedLeft()),t=t.copy(null,null,null,t.left.removeMin(),null),t.fixUp()}remove(t,e){let n,s=this;if(e(t,s.key)<0)s.left.isEmpty()||s.left.isRed()||s.left.left.isRed()||(s=s.moveRedLeft()),s=s.copy(null,null,null,s.left.remove(t,e),null);else{if(s.left.isRed()&&(s=s.rotateRight()),s.right.isEmpty()||s.right.isRed()||s.right.left.isRed()||(s=s.moveRedRight()),e(t,s.key)===0){if(s.right.isEmpty())return Rt.EMPTY;n=s.right.min(),s=s.copy(n.key,n.value,null,null,s.right.removeMin())}s=s.copy(null,null,null,null,s.right.remove(t,e))}return s.fixUp()}isRed(){return this.color}fixUp(){let t=this;return t.right.isRed()&&!t.left.isRed()&&(t=t.rotateLeft()),t.left.isRed()&&t.left.left.isRed()&&(t=t.rotateRight()),t.left.isRed()&&t.right.isRed()&&(t=t.colorFlip()),t}moveRedLeft(){let t=this.colorFlip();return t.right.left.isRed()&&(t=t.copy(null,null,null,null,t.right.rotateRight()),t=t.rotateLeft(),t=t.colorFlip()),t}moveRedRight(){let t=this.colorFlip();return t.left.left.isRed()&&(t=t.rotateRight(),t=t.colorFlip()),t}rotateLeft(){const t=this.copy(null,null,Rt.RED,null,this.right.left);return this.right.copy(null,null,this.color,t,null)}rotateRight(){const t=this.copy(null,null,Rt.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,t)}colorFlip(){const t=this.left.copy(null,null,!this.left.color,null,null),e=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,t,e)}checkMaxDepth(){const t=this.check();return Math.pow(2,t)<=this.size+1}check(){if(this.isRed()&&this.left.isRed())throw M(43730,{key:this.key,value:this.value});if(this.right.isRed())throw M(14113,{key:this.key,value:this.value});const t=this.left.check();if(t!==this.right.check())throw M(27949);return t+(this.isRed()?0:1)}}Rt.EMPTY=null,Rt.RED=!0,Rt.BLACK=!1;Rt.EMPTY=new class{constructor(){this.size=0}get key(){throw M(57766)}get value(){throw M(16141)}get color(){throw M(16727)}get left(){throw M(29726)}get right(){throw M(36894)}copy(t,e,n,s,i){return this}insert(t,e,n){return new Rt(t,e)}remove(t,e){return this}isEmpty(){return!0}inorderTraversal(t){return!1}reverseTraversal(t){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class et{constructor(t){this.comparator=t,this.data=new it(this.comparator)}has(t){return this.data.get(t)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(t){return this.data.indexOf(t)}forEach(t){this.data.inorderTraversal(((e,n)=>(t(e),!1)))}forEachInRange(t,e){const n=this.data.getIteratorFrom(t[0]);for(;n.hasNext();){const s=n.getNext();if(this.comparator(s.key,t[1])>=0)return;e(s.key)}}forEachWhile(t,e){let n;for(n=e!==void 0?this.data.getIteratorFrom(e):this.data.getIterator();n.hasNext();)if(!t(n.getNext().key))return}firstAfterOrEqual(t){const e=this.data.getIteratorFrom(t);return e.hasNext()?e.getNext().key:null}getIterator(){return new Pc(this.data.getIterator())}getIteratorFrom(t){return new Pc(this.data.getIteratorFrom(t))}add(t){return this.copy(this.data.remove(t).insert(t,!0))}delete(t){return this.has(t)?this.copy(this.data.remove(t)):this}isEmpty(){return this.data.isEmpty()}unionWith(t){let e=this;return e.size<t.size&&(e=t,t=this),t.forEach((n=>{e=e.add(n)})),e}isEqual(t){if(!(t instanceof et)||this.size!==t.size)return!1;const e=this.data.getIterator(),n=t.data.getIterator();for(;e.hasNext();){const s=e.getNext().key,i=n.getNext().key;if(this.comparator(s,i)!==0)return!1}return!0}toArray(){const t=[];return this.forEach((e=>{t.push(e)})),t}toString(){const t=[];return this.forEach((e=>t.push(e))),"SortedSet("+t.toString()+")"}copy(t){const e=new et(this.comparator);return e.data=t,e}}class Pc{constructor(t){this.iter=t}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}function Pn(r){return r.hasNext()?r.getNext():void 0}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qt{constructor(t){this.fields=t,t.sort(ct.comparator)}static empty(){return new qt([])}unionWith(t){let e=new et(ct.comparator);for(const n of this.fields)e=e.add(n);for(const n of t)e=e.add(n);return new qt(e.toArray())}covers(t){for(const e of this.fields)if(e.isPrefixOf(t))return!0;return!1}isEqual(t){return Mn(this.fields,t.fields,((e,n)=>e.isEqual(n)))}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ih extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _y(){return typeof atob<"u"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ft{constructor(t){this.binaryString=t}static fromBase64String(t){const e=(function(s){try{return atob(s)}catch(i){throw typeof DOMException<"u"&&i instanceof DOMException?new Ih("Invalid base64 string: "+i):i}})(t);return new ft(e)}static fromUint8Array(t){const e=(function(s){let i="";for(let a=0;a<s.length;++a)i+=String.fromCharCode(s[a]);return i})(t);return new ft(e)}[Symbol.iterator](){let t=0;return{next:()=>t<this.binaryString.length?{value:this.binaryString.charCodeAt(t++),done:!1}:{value:void 0,done:!0}}}toBase64(){return(function(e){return btoa(e)})(this.binaryString)}toUint8Array(){return(function(e){const n=new Uint8Array(e.length);for(let s=0;s<e.length;s++)n[s]=e.charCodeAt(s);return n})(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(t){return z(this.binaryString,t.binaryString)}isEqual(t){return this.binaryString===t.binaryString}}ft.EMPTY_BYTE_STRING=new ft("");const dg=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function le(r){if(q(!!r,39018),typeof r=="string"){let t=0;const e=dg.exec(r);if(q(!!e,46558,{timestamp:r}),e[1]){let s=e[1];s=(s+"000000000").substr(0,9),t=Number(s)}const n=new Date(r);return{seconds:Math.floor(n.getTime()/1e3),nanos:t}}return{seconds:ut(r.seconds),nanos:ut(r.nanos)}}function ut(r){return typeof r=="number"?r:typeof r=="string"?Number(r):0}function he(r){return typeof r=="string"?ft.fromBase64String(r):ft.fromUint8Array(r)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Th="server_timestamp",Eh="__type__",wh="__previous_value__",vh="__local_write_time__";function Si(r){var t,e;return((e=(((t=r?.mapValue)===null||t===void 0?void 0:t.fields)||{})[Eh])===null||e===void 0?void 0:e.stringValue)===Th}function bi(r){const t=r.mapValue.fields[wh];return Si(t)?bi(t):t}function Jr(r){const t=le(r.mapValue.fields[vh].timestampValue);return new Z(t.seconds,t.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fg{constructor(t,e,n,s,i,a,u,c,h,f){this.databaseId=t,this.appId=e,this.persistenceKey=n,this.host=s,this.ssl=i,this.forceLongPolling=a,this.autoDetectLongPolling=u,this.longPollingOptions=c,this.useFetchStreams=h,this.isUsingEmulator=f}}const Yr="(default)";class sn{constructor(t,e){this.projectId=t,this.database=e||Yr}static empty(){return new sn("","")}get isDefaultDatabase(){return this.database===Yr}isEqual(t){return t instanceof sn&&t.projectId===this.projectId&&t.database===this.database}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ma="__type__",Ah="__max__",Re={mapValue:{fields:{__type__:{stringValue:Ah}}}},ga="__vector__",Kn="value",Ys={nullValue:"NULL_VALUE"};function De(r){return"nullValue"in r?0:"booleanValue"in r?1:"integerValue"in r||"doubleValue"in r?2:"timestampValue"in r?3:"stringValue"in r?5:"bytesValue"in r?6:"referenceValue"in r?7:"geoPointValue"in r?8:"arrayValue"in r?9:"mapValue"in r?Si(r)?4:Rh(r)?9007199254740991:Ci(r)?10:11:M(28295,{value:r})}function se(r,t){if(r===t)return!0;const e=De(r);if(e!==De(t))return!1;switch(e){case 0:case 9007199254740991:return!0;case 1:return r.booleanValue===t.booleanValue;case 4:return Jr(r).isEqual(Jr(t));case 3:return(function(s,i){if(typeof s.timestampValue=="string"&&typeof i.timestampValue=="string"&&s.timestampValue.length===i.timestampValue.length)return s.timestampValue===i.timestampValue;const a=le(s.timestampValue),u=le(i.timestampValue);return a.seconds===u.seconds&&a.nanos===u.nanos})(r,t);case 5:return r.stringValue===t.stringValue;case 6:return(function(s,i){return he(s.bytesValue).isEqual(he(i.bytesValue))})(r,t);case 7:return r.referenceValue===t.referenceValue;case 8:return(function(s,i){return ut(s.geoPointValue.latitude)===ut(i.geoPointValue.latitude)&&ut(s.geoPointValue.longitude)===ut(i.geoPointValue.longitude)})(r,t);case 2:return(function(s,i){if("integerValue"in s&&"integerValue"in i)return ut(s.integerValue)===ut(i.integerValue);if("doubleValue"in s&&"doubleValue"in i){const a=ut(s.doubleValue),u=ut(i.doubleValue);return a===u?Qr(a)===Qr(u):isNaN(a)&&isNaN(u)}return!1})(r,t);case 9:return Mn(r.arrayValue.values||[],t.arrayValue.values||[],se);case 10:case 11:return(function(s,i){const a=s.mapValue.fields||{},u=i.mapValue.fields||{};if(Rc(a)!==Rc(u))return!1;for(const c in a)if(a.hasOwnProperty(c)&&(u[c]===void 0||!se(a[c],u[c])))return!1;return!0})(r,t);default:return M(52216,{left:r})}}function Zr(r,t){return(r.values||[]).find((e=>se(e,t)))!==void 0}function xe(r,t){if(r===t)return 0;const e=De(r),n=De(t);if(e!==n)return z(e,n);switch(e){case 0:case 9007199254740991:return 0;case 1:return z(r.booleanValue,t.booleanValue);case 2:return(function(i,a){const u=ut(i.integerValue||i.doubleValue),c=ut(a.integerValue||a.doubleValue);return u<c?-1:u>c?1:u===c?0:isNaN(u)?isNaN(c)?0:-1:1})(r,t);case 3:return Vc(r.timestampValue,t.timestampValue);case 4:return Vc(Jr(r),Jr(t));case 5:return xo(r.stringValue,t.stringValue);case 6:return(function(i,a){const u=he(i),c=he(a);return u.compareTo(c)})(r.bytesValue,t.bytesValue);case 7:return(function(i,a){const u=i.split("/"),c=a.split("/");for(let h=0;h<u.length&&h<c.length;h++){const f=z(u[h],c[h]);if(f!==0)return f}return z(u.length,c.length)})(r.referenceValue,t.referenceValue);case 8:return(function(i,a){const u=z(ut(i.latitude),ut(a.latitude));return u!==0?u:z(ut(i.longitude),ut(a.longitude))})(r.geoPointValue,t.geoPointValue);case 9:return Sc(r.arrayValue,t.arrayValue);case 10:return(function(i,a){var u,c,h,f;const m=i.fields||{},p=a.fields||{},R=(u=m[Kn])===null||u===void 0?void 0:u.arrayValue,b=(c=p[Kn])===null||c===void 0?void 0:c.arrayValue,D=z(((h=R?.values)===null||h===void 0?void 0:h.length)||0,((f=b?.values)===null||f===void 0?void 0:f.length)||0);return D!==0?D:Sc(R,b)})(r.mapValue,t.mapValue);case 11:return(function(i,a){if(i===Re.mapValue&&a===Re.mapValue)return 0;if(i===Re.mapValue)return 1;if(a===Re.mapValue)return-1;const u=i.fields||{},c=Object.keys(u),h=a.fields||{},f=Object.keys(h);c.sort(),f.sort();for(let m=0;m<c.length&&m<f.length;++m){const p=xo(c[m],f[m]);if(p!==0)return p;const R=xe(u[c[m]],h[f[m]]);if(R!==0)return R}return z(c.length,f.length)})(r.mapValue,t.mapValue);default:throw M(23264,{le:e})}}function Vc(r,t){if(typeof r=="string"&&typeof t=="string"&&r.length===t.length)return z(r,t);const e=le(r),n=le(t),s=z(e.seconds,n.seconds);return s!==0?s:z(e.nanos,n.nanos)}function Sc(r,t){const e=r.values||[],n=t.values||[];for(let s=0;s<e.length&&s<n.length;++s){const i=xe(e[s],n[s]);if(i)return i}return z(e.length,n.length)}function $n(r){return qo(r)}function qo(r){return"nullValue"in r?"null":"booleanValue"in r?""+r.booleanValue:"integerValue"in r?""+r.integerValue:"doubleValue"in r?""+r.doubleValue:"timestampValue"in r?(function(e){const n=le(e);return`time(${n.seconds},${n.nanos})`})(r.timestampValue):"stringValue"in r?r.stringValue:"bytesValue"in r?(function(e){return he(e).toBase64()})(r.bytesValue):"referenceValue"in r?(function(e){return k.fromName(e).toString()})(r.referenceValue):"geoPointValue"in r?(function(e){return`geo(${e.latitude},${e.longitude})`})(r.geoPointValue):"arrayValue"in r?(function(e){let n="[",s=!0;for(const i of e.values||[])s?s=!1:n+=",",n+=qo(i);return n+"]"})(r.arrayValue):"mapValue"in r?(function(e){const n=Object.keys(e.fields||{}).sort();let s="{",i=!0;for(const a of n)i?i=!1:s+=",",s+=`${a}:${qo(e.fields[a])}`;return s+"}"})(r.mapValue):M(61005,{value:r})}function Zs(r){switch(De(r)){case 0:case 1:return 4;case 2:return 8;case 3:case 8:return 16;case 4:const t=bi(r);return t?16+Zs(t):16;case 5:return 2*r.stringValue.length;case 6:return he(r.bytesValue).approximateByteSize();case 7:return r.referenceValue.length;case 9:return(function(n){return(n.values||[]).reduce(((s,i)=>s+Zs(i)),0)})(r.arrayValue);case 10:case 11:return(function(n){let s=0;return qe(n.fields,((i,a)=>{s+=i.length+Zs(a)})),s})(r.mapValue);default:throw M(13486,{value:r})}}function on(r,t){return{referenceValue:`projects/${r.projectId}/databases/${r.database}/documents/${t.path.canonicalString()}`}}function Bo(r){return!!r&&"integerValue"in r}function ts(r){return!!r&&"arrayValue"in r}function bc(r){return!!r&&"nullValue"in r}function Cc(r){return!!r&&"doubleValue"in r&&isNaN(Number(r.doubleValue))}function ti(r){return!!r&&"mapValue"in r}function Ci(r){var t,e;return((e=(((t=r?.mapValue)===null||t===void 0?void 0:t.fields)||{})[ma])===null||e===void 0?void 0:e.stringValue)===ga}function zr(r){if(r.geoPointValue)return{geoPointValue:Object.assign({},r.geoPointValue)};if(r.timestampValue&&typeof r.timestampValue=="object")return{timestampValue:Object.assign({},r.timestampValue)};if(r.mapValue){const t={mapValue:{fields:{}}};return qe(r.mapValue.fields,((e,n)=>t.mapValue.fields[e]=zr(n))),t}if(r.arrayValue){const t={arrayValue:{values:[]}};for(let e=0;e<(r.arrayValue.values||[]).length;++e)t.arrayValue.values[e]=zr(r.arrayValue.values[e]);return t}return Object.assign({},r)}function Rh(r){return(((r.mapValue||{}).fields||{}).__type__||{}).stringValue===Ah}const Ph={mapValue:{fields:{[ma]:{stringValue:ga},[Kn]:{arrayValue:{}}}}};function mg(r){return"nullValue"in r?Ys:"booleanValue"in r?{booleanValue:!1}:"integerValue"in r||"doubleValue"in r?{doubleValue:NaN}:"timestampValue"in r?{timestampValue:{seconds:Number.MIN_SAFE_INTEGER}}:"stringValue"in r?{stringValue:""}:"bytesValue"in r?{bytesValue:""}:"referenceValue"in r?on(sn.empty(),k.empty()):"geoPointValue"in r?{geoPointValue:{latitude:-90,longitude:-180}}:"arrayValue"in r?{arrayValue:{}}:"mapValue"in r?Ci(r)?Ph:{mapValue:{}}:M(35942,{value:r})}function gg(r){return"nullValue"in r?{booleanValue:!1}:"booleanValue"in r?{doubleValue:NaN}:"integerValue"in r||"doubleValue"in r?{timestampValue:{seconds:Number.MIN_SAFE_INTEGER}}:"timestampValue"in r?{stringValue:""}:"stringValue"in r?{bytesValue:""}:"bytesValue"in r?on(sn.empty(),k.empty()):"referenceValue"in r?{geoPointValue:{latitude:-90,longitude:-180}}:"geoPointValue"in r?{arrayValue:{}}:"arrayValue"in r?Ph:"mapValue"in r?Ci(r)?{mapValue:{}}:Re:M(61959,{value:r})}function Dc(r,t){const e=xe(r.value,t.value);return e!==0?e:r.inclusive&&!t.inclusive?-1:!r.inclusive&&t.inclusive?1:0}function xc(r,t){const e=xe(r.value,t.value);return e!==0?e:r.inclusive&&!t.inclusive?1:!r.inclusive&&t.inclusive?-1:0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pt{constructor(t){this.value=t}static empty(){return new Pt({mapValue:{}})}field(t){if(t.isEmpty())return this.value;{let e=this.value;for(let n=0;n<t.length-1;++n)if(e=(e.mapValue.fields||{})[t.get(n)],!ti(e))return null;return e=(e.mapValue.fields||{})[t.lastSegment()],e||null}}set(t,e){this.getFieldsMap(t.popLast())[t.lastSegment()]=zr(e)}setAll(t){let e=ct.emptyPath(),n={},s=[];t.forEach(((a,u)=>{if(!e.isImmediateParentOf(u)){const c=this.getFieldsMap(e);this.applyChanges(c,n,s),n={},s=[],e=u.popLast()}a?n[u.lastSegment()]=zr(a):s.push(u.lastSegment())}));const i=this.getFieldsMap(e);this.applyChanges(i,n,s)}delete(t){const e=this.field(t.popLast());ti(e)&&e.mapValue.fields&&delete e.mapValue.fields[t.lastSegment()]}isEqual(t){return se(this.value,t.value)}getFieldsMap(t){let e=this.value;e.mapValue.fields||(e.mapValue={fields:{}});for(let n=0;n<t.length;++n){let s=e.mapValue.fields[t.get(n)];ti(s)&&s.mapValue.fields||(s={mapValue:{fields:{}}},e.mapValue.fields[t.get(n)]=s),e=s}return e.mapValue.fields}applyChanges(t,e,n){qe(e,((s,i)=>t[s]=i));for(const s of n)delete t[s]}clone(){return new Pt(zr(this.value))}}function Vh(r){const t=[];return qe(r.fields,((e,n)=>{const s=new ct([e]);if(ti(n)){const i=Vh(n.mapValue).fields;if(i.length===0)t.push(s);else for(const a of i)t.push(s.child(a))}else t.push(s)})),new qt(t)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class at{constructor(t,e,n,s,i,a,u){this.key=t,this.documentType=e,this.version=n,this.readTime=s,this.createTime=i,this.data=a,this.documentState=u}static newInvalidDocument(t){return new at(t,0,U.min(),U.min(),U.min(),Pt.empty(),0)}static newFoundDocument(t,e,n,s){return new at(t,1,e,U.min(),n,s,0)}static newNoDocument(t,e){return new at(t,2,e,U.min(),U.min(),Pt.empty(),0)}static newUnknownDocument(t,e){return new at(t,3,e,U.min(),U.min(),Pt.empty(),2)}convertToFoundDocument(t,e){return!this.createTime.isEqual(U.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=t),this.version=t,this.documentType=1,this.data=e,this.documentState=0,this}convertToNoDocument(t){return this.version=t,this.documentType=2,this.data=Pt.empty(),this.documentState=0,this}convertToUnknownDocument(t){return this.version=t,this.documentType=3,this.data=Pt.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=U.min(),this}setReadTime(t){return this.readTime=t,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(t){return t instanceof at&&this.key.isEqual(t.key)&&this.version.isEqual(t.version)&&this.documentType===t.documentType&&this.documentState===t.documentState&&this.data.isEqual(t.data)}mutableCopy(){return new at(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ne{constructor(t,e){this.position=t,this.inclusive=e}}function Nc(r,t,e){let n=0;for(let s=0;s<r.position.length;s++){const i=t[s],a=r.position[s];if(i.field.isKeyField()?n=k.comparator(k.fromName(a.referenceValue),e.key):n=xe(a,e.data.field(i.field)),i.dir==="desc"&&(n*=-1),n!==0)break}return n}function kc(r,t){if(r===null)return t===null;if(t===null||r.inclusive!==t.inclusive||r.position.length!==t.position.length)return!1;for(let e=0;e<r.position.length;e++)if(!se(r.position[e],t.position[e]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class es{constructor(t,e="asc"){this.field=t,this.dir=e}}function pg(r,t){return r.dir===t.dir&&r.field.isEqual(t.field)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sh{}class H extends Sh{constructor(t,e,n){super(),this.field=t,this.op=e,this.value=n}static create(t,e,n){return t.isKeyField()?e==="in"||e==="not-in"?this.createKeyFieldInFilter(t,e,n):new _g(t,e,n):e==="array-contains"?new Tg(t,n):e==="in"?new kh(t,n):e==="not-in"?new Eg(t,n):e==="array-contains-any"?new wg(t,n):new H(t,e,n)}static createKeyFieldInFilter(t,e,n){return e==="in"?new yg(t,n):new Ig(t,n)}matches(t){const e=t.data.field(this.field);return this.op==="!="?e!==null&&e.nullValue===void 0&&this.matchesComparison(xe(e,this.value)):e!==null&&De(this.value)===De(e)&&this.matchesComparison(xe(e,this.value))}matchesComparison(t){switch(this.op){case"<":return t<0;case"<=":return t<=0;case"==":return t===0;case"!=":return t!==0;case">":return t>0;case">=":return t>=0;default:return M(47266,{operator:this.op})}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class tt extends Sh{constructor(t,e){super(),this.filters=t,this.op=e,this.he=null}static create(t,e){return new tt(t,e)}matches(t){return Qn(this)?this.filters.find((e=>!e.matches(t)))===void 0:this.filters.find((e=>e.matches(t)))!==void 0}getFlattenedFilters(){return this.he!==null||(this.he=this.filters.reduce(((t,e)=>t.concat(e.getFlattenedFilters())),[])),this.he}getFilters(){return Object.assign([],this.filters)}}function Qn(r){return r.op==="and"}function Uo(r){return r.op==="or"}function pa(r){return bh(r)&&Qn(r)}function bh(r){for(const t of r.filters)if(t instanceof tt)return!1;return!0}function jo(r){if(r instanceof H)return r.field.canonicalString()+r.op.toString()+$n(r.value);if(pa(r))return r.filters.map((t=>jo(t))).join(",");{const t=r.filters.map((e=>jo(e))).join(",");return`${r.op}(${t})`}}function Ch(r,t){return r instanceof H?(function(n,s){return s instanceof H&&n.op===s.op&&n.field.isEqual(s.field)&&se(n.value,s.value)})(r,t):r instanceof tt?(function(n,s){return s instanceof tt&&n.op===s.op&&n.filters.length===s.filters.length?n.filters.reduce(((i,a,u)=>i&&Ch(a,s.filters[u])),!0):!1})(r,t):void M(19439)}function Dh(r,t){const e=r.filters.concat(t);return tt.create(e,r.op)}function xh(r){return r instanceof H?(function(e){return`${e.field.canonicalString()} ${e.op} ${$n(e.value)}`})(r):r instanceof tt?(function(e){return e.op.toString()+" {"+e.getFilters().map(xh).join(" ,")+"}"})(r):"Filter"}class _g extends H{constructor(t,e,n){super(t,e,n),this.key=k.fromName(n.referenceValue)}matches(t){const e=k.comparator(t.key,this.key);return this.matchesComparison(e)}}class yg extends H{constructor(t,e){super(t,"in",e),this.keys=Nh("in",e)}matches(t){return this.keys.some((e=>e.isEqual(t.key)))}}class Ig extends H{constructor(t,e){super(t,"not-in",e),this.keys=Nh("not-in",e)}matches(t){return!this.keys.some((e=>e.isEqual(t.key)))}}function Nh(r,t){var e;return(((e=t.arrayValue)===null||e===void 0?void 0:e.values)||[]).map((n=>k.fromName(n.referenceValue)))}class Tg extends H{constructor(t,e){super(t,"array-contains",e)}matches(t){const e=t.data.field(this.field);return ts(e)&&Zr(e.arrayValue,this.value)}}class kh extends H{constructor(t,e){super(t,"in",e)}matches(t){const e=t.data.field(this.field);return e!==null&&Zr(this.value.arrayValue,e)}}class Eg extends H{constructor(t,e){super(t,"not-in",e)}matches(t){if(Zr(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const e=t.data.field(this.field);return e!==null&&e.nullValue===void 0&&!Zr(this.value.arrayValue,e)}}class wg extends H{constructor(t,e){super(t,"array-contains-any",e)}matches(t){const e=t.data.field(this.field);return!(!ts(e)||!e.arrayValue.values)&&e.arrayValue.values.some((n=>Zr(this.value.arrayValue,n)))}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vg{constructor(t,e=null,n=[],s=[],i=null,a=null,u=null){this.path=t,this.collectionGroup=e,this.orderBy=n,this.filters=s,this.limit=i,this.startAt=a,this.endAt=u,this.Pe=null}}function zo(r,t=null,e=[],n=[],s=null,i=null,a=null){return new vg(r,t,e,n,s,i,a)}function an(r){const t=F(r);if(t.Pe===null){let e=t.path.canonicalString();t.collectionGroup!==null&&(e+="|cg:"+t.collectionGroup),e+="|f:",e+=t.filters.map((n=>jo(n))).join(","),e+="|ob:",e+=t.orderBy.map((n=>(function(i){return i.field.canonicalString()+i.dir})(n))).join(","),us(t.limit)||(e+="|l:",e+=t.limit),t.startAt&&(e+="|lb:",e+=t.startAt.inclusive?"b:":"a:",e+=t.startAt.position.map((n=>$n(n))).join(",")),t.endAt&&(e+="|ub:",e+=t.endAt.inclusive?"a:":"b:",e+=t.endAt.position.map((n=>$n(n))).join(",")),t.Pe=e}return t.Pe}function ls(r,t){if(r.limit!==t.limit||r.orderBy.length!==t.orderBy.length)return!1;for(let e=0;e<r.orderBy.length;e++)if(!pg(r.orderBy[e],t.orderBy[e]))return!1;if(r.filters.length!==t.filters.length)return!1;for(let e=0;e<r.filters.length;e++)if(!Ch(r.filters[e],t.filters[e]))return!1;return r.collectionGroup===t.collectionGroup&&!!r.path.isEqual(t.path)&&!!kc(r.startAt,t.startAt)&&kc(r.endAt,t.endAt)}function li(r){return k.isDocumentKey(r.path)&&r.collectionGroup===null&&r.filters.length===0}function hi(r,t){return r.filters.filter((e=>e instanceof H&&e.field.isEqual(t)))}function Fc(r,t,e){let n=Ys,s=!0;for(const i of hi(r,t)){let a=Ys,u=!0;switch(i.op){case"<":case"<=":a=mg(i.value);break;case"==":case"in":case">=":a=i.value;break;case">":a=i.value,u=!1;break;case"!=":case"not-in":a=Ys}Dc({value:n,inclusive:s},{value:a,inclusive:u})<0&&(n=a,s=u)}if(e!==null){for(let i=0;i<r.orderBy.length;++i)if(r.orderBy[i].field.isEqual(t)){const a=e.position[i];Dc({value:n,inclusive:s},{value:a,inclusive:e.inclusive})<0&&(n=a,s=e.inclusive);break}}return{value:n,inclusive:s}}function Oc(r,t,e){let n=Re,s=!0;for(const i of hi(r,t)){let a=Re,u=!0;switch(i.op){case">=":case">":a=gg(i.value),u=!1;break;case"==":case"in":case"<=":a=i.value;break;case"<":a=i.value,u=!1;break;case"!=":case"not-in":a=Re}xc({value:n,inclusive:s},{value:a,inclusive:u})>0&&(n=a,s=u)}if(e!==null){for(let i=0;i<r.orderBy.length;++i)if(r.orderBy[i].field.isEqual(t)){const a=e.position[i];xc({value:n,inclusive:s},{value:a,inclusive:e.inclusive})>0&&(n=a,s=e.inclusive);break}}return{value:n,inclusive:s}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class de{constructor(t,e=null,n=[],s=[],i=null,a="F",u=null,c=null){this.path=t,this.collectionGroup=e,this.explicitOrderBy=n,this.filters=s,this.limit=i,this.limitType=a,this.startAt=u,this.endAt=c,this.Te=null,this.Ie=null,this.de=null,this.startAt,this.endAt}}function Fh(r,t,e,n,s,i,a,u){return new de(r,t,e,n,s,i,a,u)}function sr(r){return new de(r)}function Mc(r){return r.filters.length===0&&r.limit===null&&r.startAt==null&&r.endAt==null&&(r.explicitOrderBy.length===0||r.explicitOrderBy.length===1&&r.explicitOrderBy[0].field.isKeyField())}function _a(r){return r.collectionGroup!==null}function Fn(r){const t=F(r);if(t.Te===null){t.Te=[];const e=new Set;for(const i of t.explicitOrderBy)t.Te.push(i),e.add(i.field.canonicalString());const n=t.explicitOrderBy.length>0?t.explicitOrderBy[t.explicitOrderBy.length-1].dir:"asc";(function(a){let u=new et(ct.comparator);return a.filters.forEach((c=>{c.getFlattenedFilters().forEach((h=>{h.isInequality()&&(u=u.add(h.field))}))})),u})(t).forEach((i=>{e.has(i.canonicalString())||i.isKeyField()||t.Te.push(new es(i,n))})),e.has(ct.keyField().canonicalString())||t.Te.push(new es(ct.keyField(),n))}return t.Te}function kt(r){const t=F(r);return t.Ie||(t.Ie=Mh(t,Fn(r))),t.Ie}function Oh(r){const t=F(r);return t.de||(t.de=Mh(t,r.explicitOrderBy)),t.de}function Mh(r,t){if(r.limitType==="F")return zo(r.path,r.collectionGroup,t,r.filters,r.limit,r.startAt,r.endAt);{t=t.map((s=>{const i=s.dir==="desc"?"asc":"desc";return new es(s.field,i)}));const e=r.endAt?new Ne(r.endAt.position,r.endAt.inclusive):null,n=r.startAt?new Ne(r.startAt.position,r.startAt.inclusive):null;return zo(r.path,r.collectionGroup,t,r.filters,r.limit,e,n)}}function Go(r,t){const e=r.filters.concat([t]);return new de(r.path,r.collectionGroup,r.explicitOrderBy.slice(),e,r.limit,r.limitType,r.startAt,r.endAt)}function di(r,t,e){return new de(r.path,r.collectionGroup,r.explicitOrderBy.slice(),r.filters.slice(),t,e,r.startAt,r.endAt)}function hs(r,t){return ls(kt(r),kt(t))&&r.limitType===t.limitType}function Lh(r){return`${an(kt(r))}|lt:${r.limitType}`}function xn(r){return`Query(target=${(function(e){let n=e.path.canonicalString();return e.collectionGroup!==null&&(n+=" collectionGroup="+e.collectionGroup),e.filters.length>0&&(n+=`, filters: [${e.filters.map((s=>xh(s))).join(", ")}]`),us(e.limit)||(n+=", limit: "+e.limit),e.orderBy.length>0&&(n+=`, orderBy: [${e.orderBy.map((s=>(function(a){return`${a.field.canonicalString()} (${a.dir})`})(s))).join(", ")}]`),e.startAt&&(n+=", startAt: ",n+=e.startAt.inclusive?"b:":"a:",n+=e.startAt.position.map((s=>$n(s))).join(",")),e.endAt&&(n+=", endAt: ",n+=e.endAt.inclusive?"a:":"b:",n+=e.endAt.position.map((s=>$n(s))).join(",")),`Target(${n})`})(kt(r))}; limitType=${r.limitType})`}function ds(r,t){return t.isFoundDocument()&&(function(n,s){const i=s.key.path;return n.collectionGroup!==null?s.key.hasCollectionId(n.collectionGroup)&&n.path.isPrefixOf(i):k.isDocumentKey(n.path)?n.path.isEqual(i):n.path.isImmediateParentOf(i)})(r,t)&&(function(n,s){for(const i of Fn(n))if(!i.field.isKeyField()&&s.data.field(i.field)===null)return!1;return!0})(r,t)&&(function(n,s){for(const i of n.filters)if(!i.matches(s))return!1;return!0})(r,t)&&(function(n,s){return!(n.startAt&&!(function(a,u,c){const h=Nc(a,u,c);return a.inclusive?h<=0:h<0})(n.startAt,Fn(n),s)||n.endAt&&!(function(a,u,c){const h=Nc(a,u,c);return a.inclusive?h>=0:h>0})(n.endAt,Fn(n),s))})(r,t)}function qh(r){return r.collectionGroup||(r.path.length%2==1?r.path.lastSegment():r.path.get(r.path.length-2))}function Bh(r){return(t,e)=>{let n=!1;for(const s of Fn(r)){const i=Ag(s,t,e);if(i!==0)return i;n=n||s.field.isKeyField()}return 0}}function Ag(r,t,e){const n=r.field.isKeyField()?k.comparator(t.key,e.key):(function(i,a,u){const c=a.data.field(i),h=u.data.field(i);return c!==null&&h!==null?xe(c,h):M(42886)})(r.field,t,e);switch(r.dir){case"asc":return n;case"desc":return-1*n;default:return M(19790,{direction:r.dir})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fe{constructor(t,e){this.mapKeyFn=t,this.equalsFn=e,this.inner={},this.innerSize=0}get(t){const e=this.mapKeyFn(t),n=this.inner[e];if(n!==void 0){for(const[s,i]of n)if(this.equalsFn(s,t))return i}}has(t){return this.get(t)!==void 0}set(t,e){const n=this.mapKeyFn(t),s=this.inner[n];if(s===void 0)return this.inner[n]=[[t,e]],void this.innerSize++;for(let i=0;i<s.length;i++)if(this.equalsFn(s[i][0],t))return void(s[i]=[t,e]);s.push([t,e]),this.innerSize++}delete(t){const e=this.mapKeyFn(t),n=this.inner[e];if(n===void 0)return!1;for(let s=0;s<n.length;s++)if(this.equalsFn(n[s][0],t))return n.length===1?delete this.inner[e]:n.splice(s,1),this.innerSize--,!0;return!1}forEach(t){qe(this.inner,((e,n)=>{for(const[s,i]of n)t(s,i)}))}isEmpty(){return yh(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Rg=new it(k.comparator);function Bt(){return Rg}const Uh=new it(k.comparator);function Or(...r){let t=Uh;for(const e of r)t=t.insert(e.key,e);return t}function jh(r){let t=Uh;return r.forEach(((e,n)=>t=t.insert(e,n.overlayedDocument))),t}function Zt(){return Gr()}function zh(){return Gr()}function Gr(){return new fe((r=>r.toString()),((r,t)=>r.isEqual(t)))}const Pg=new it(k.comparator),Vg=new et(k.comparator);function G(...r){let t=Vg;for(const e of r)t=t.add(e);return t}const Sg=new et(z);function ya(){return Sg}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ia(r,t){if(r.useProto3Json){if(isNaN(t))return{doubleValue:"NaN"};if(t===1/0)return{doubleValue:"Infinity"};if(t===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:Qr(t)?"-0":t}}function Gh(r){return{integerValue:""+r}}function Kh(r,t){return oh(t)?Gh(t):Ia(r,t)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Di{constructor(){this._=void 0}}function bg(r,t,e){return r instanceof Wn?(function(s,i){const a={fields:{[Eh]:{stringValue:Th},[vh]:{timestampValue:{seconds:s.seconds,nanos:s.nanoseconds}}}};return i&&Si(i)&&(i=bi(i)),i&&(a.fields[wh]=i),{mapValue:a}})(e,t):r instanceof un?Qh(r,t):r instanceof cn?Wh(r,t):(function(s,i){const a=$h(s,i),u=Lc(a)+Lc(s.Ee);return Bo(a)&&Bo(s.Ee)?Gh(u):Ia(s.serializer,u)})(r,t)}function Cg(r,t,e){return r instanceof un?Qh(r,t):r instanceof cn?Wh(r,t):e}function $h(r,t){return r instanceof Hn?(function(n){return Bo(n)||(function(i){return!!i&&"doubleValue"in i})(n)})(t)?t:{integerValue:0}:null}class Wn extends Di{}class un extends Di{constructor(t){super(),this.elements=t}}function Qh(r,t){const e=Hh(t);for(const n of r.elements)e.some((s=>se(s,n)))||e.push(n);return{arrayValue:{values:e}}}class cn extends Di{constructor(t){super(),this.elements=t}}function Wh(r,t){let e=Hh(t);for(const n of r.elements)e=e.filter((s=>!se(s,n)));return{arrayValue:{values:e}}}class Hn extends Di{constructor(t,e){super(),this.serializer=t,this.Ee=e}}function Lc(r){return ut(r.integerValue||r.doubleValue)}function Hh(r){return ts(r)&&r.arrayValue.values?r.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fs{constructor(t,e){this.field=t,this.transform=e}}function Dg(r,t){return r.field.isEqual(t.field)&&(function(n,s){return n instanceof un&&s instanceof un||n instanceof cn&&s instanceof cn?Mn(n.elements,s.elements,se):n instanceof Hn&&s instanceof Hn?se(n.Ee,s.Ee):n instanceof Wn&&s instanceof Wn})(r.transform,t.transform)}class xg{constructor(t,e){this.version=t,this.transformResults=e}}class lt{constructor(t,e){this.updateTime=t,this.exists=e}static none(){return new lt}static exists(t){return new lt(void 0,t)}static updateTime(t){return new lt(t)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(t){return this.exists===t.exists&&(this.updateTime?!!t.updateTime&&this.updateTime.isEqual(t.updateTime):!t.updateTime)}}function ei(r,t){return r.updateTime!==void 0?t.isFoundDocument()&&t.version.isEqual(r.updateTime):r.exists===void 0||r.exists===t.isFoundDocument()}class xi{}function Xh(r,t){if(!r.hasLocalMutations||t&&t.fields.length===0)return null;if(t===null)return r.isNoDocument()?new or(r.key,lt.none()):new ir(r.key,r.data,lt.none());{const e=r.data,n=Pt.empty();let s=new et(ct.comparator);for(let i of t.fields)if(!s.has(i)){let a=e.field(i);a===null&&i.length>1&&(i=i.popLast(),a=e.field(i)),a===null?n.delete(i):n.set(i,a),s=s.add(i)}return new me(r.key,n,new qt(s.toArray()),lt.none())}}function Ng(r,t,e){r instanceof ir?(function(s,i,a){const u=s.value.clone(),c=Bc(s.fieldTransforms,i,a.transformResults);u.setAll(c),i.convertToFoundDocument(a.version,u).setHasCommittedMutations()})(r,t,e):r instanceof me?(function(s,i,a){if(!ei(s.precondition,i))return void i.convertToUnknownDocument(a.version);const u=Bc(s.fieldTransforms,i,a.transformResults),c=i.data;c.setAll(Jh(s)),c.setAll(u),i.convertToFoundDocument(a.version,c).setHasCommittedMutations()})(r,t,e):(function(s,i,a){i.convertToNoDocument(a.version).setHasCommittedMutations()})(0,t,e)}function Kr(r,t,e,n){return r instanceof ir?(function(i,a,u,c){if(!ei(i.precondition,a))return u;const h=i.value.clone(),f=Uc(i.fieldTransforms,c,a);return h.setAll(f),a.convertToFoundDocument(a.version,h).setHasLocalMutations(),null})(r,t,e,n):r instanceof me?(function(i,a,u,c){if(!ei(i.precondition,a))return u;const h=Uc(i.fieldTransforms,c,a),f=a.data;return f.setAll(Jh(i)),f.setAll(h),a.convertToFoundDocument(a.version,f).setHasLocalMutations(),u===null?null:u.unionWith(i.fieldMask.fields).unionWith(i.fieldTransforms.map((m=>m.field)))})(r,t,e,n):(function(i,a,u){return ei(i.precondition,a)?(a.convertToNoDocument(a.version).setHasLocalMutations(),null):u})(r,t,e)}function kg(r,t){let e=null;for(const n of r.fieldTransforms){const s=t.data.field(n.field),i=$h(n.transform,s||null);i!=null&&(e===null&&(e=Pt.empty()),e.set(n.field,i))}return e||null}function qc(r,t){return r.type===t.type&&!!r.key.isEqual(t.key)&&!!r.precondition.isEqual(t.precondition)&&!!(function(n,s){return n===void 0&&s===void 0||!(!n||!s)&&Mn(n,s,((i,a)=>Dg(i,a)))})(r.fieldTransforms,t.fieldTransforms)&&(r.type===0?r.value.isEqual(t.value):r.type!==1||r.data.isEqual(t.data)&&r.fieldMask.isEqual(t.fieldMask))}class ir extends xi{constructor(t,e,n,s=[]){super(),this.key=t,this.value=e,this.precondition=n,this.fieldTransforms=s,this.type=0}getFieldMask(){return null}}class me extends xi{constructor(t,e,n,s,i=[]){super(),this.key=t,this.data=e,this.fieldMask=n,this.precondition=s,this.fieldTransforms=i,this.type=1}getFieldMask(){return this.fieldMask}}function Jh(r){const t=new Map;return r.fieldMask.fields.forEach((e=>{if(!e.isEmpty()){const n=r.data.field(e);t.set(e,n)}})),t}function Bc(r,t,e){const n=new Map;q(r.length===e.length,32656,{Ae:e.length,Re:r.length});for(let s=0;s<e.length;s++){const i=r[s],a=i.transform,u=t.data.field(i.field);n.set(i.field,Cg(a,u,e[s]))}return n}function Uc(r,t,e){const n=new Map;for(const s of r){const i=s.transform,a=e.data.field(s.field);n.set(s.field,bg(i,a,t))}return n}class or extends xi{constructor(t,e){super(),this.key=t,this.precondition=e,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class Ta extends xi{constructor(t,e){super(),this.key=t,this.precondition=e,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ea{constructor(t,e,n,s){this.batchId=t,this.localWriteTime=e,this.baseMutations=n,this.mutations=s}applyToRemoteDocument(t,e){const n=e.mutationResults;for(let s=0;s<this.mutations.length;s++){const i=this.mutations[s];i.key.isEqual(t.key)&&Ng(i,t,n[s])}}applyToLocalView(t,e){for(const n of this.baseMutations)n.key.isEqual(t.key)&&(e=Kr(n,t,e,this.localWriteTime));for(const n of this.mutations)n.key.isEqual(t.key)&&(e=Kr(n,t,e,this.localWriteTime));return e}applyToLocalDocumentSet(t,e){const n=zh();return this.mutations.forEach((s=>{const i=t.get(s.key),a=i.overlayedDocument;let u=this.applyToLocalView(a,i.mutatedFields);u=e.has(s.key)?null:u;const c=Xh(a,u);c!==null&&n.set(s.key,c),a.isValidDocument()||a.convertToNoDocument(U.min())})),n}keys(){return this.mutations.reduce(((t,e)=>t.add(e.key)),G())}isEqual(t){return this.batchId===t.batchId&&Mn(this.mutations,t.mutations,((e,n)=>qc(e,n)))&&Mn(this.baseMutations,t.baseMutations,((e,n)=>qc(e,n)))}}class wa{constructor(t,e,n,s){this.batch=t,this.commitVersion=e,this.mutationResults=n,this.docVersions=s}static from(t,e,n){q(t.mutations.length===n.length,58842,{Ve:t.mutations.length,me:n.length});let s=(function(){return Pg})();const i=t.mutations;for(let a=0;a<i.length;a++)s=s.insert(i[a].key,n[a].version);return new wa(t,e,n,s)}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class va{constructor(t,e){this.largestBatchId=t,this.mutation=e}getKey(){return this.mutation.key}isEqual(t){return t!==null&&this.mutation===t.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yh{constructor(t,e,n){this.alias=t,this.aggregateType=e,this.fieldPath=n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fg{constructor(t,e){this.count=t,this.unchangedNames=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var pt,X;function Zh(r){switch(r){case P.OK:return M(64938);case P.CANCELLED:case P.UNKNOWN:case P.DEADLINE_EXCEEDED:case P.RESOURCE_EXHAUSTED:case P.INTERNAL:case P.UNAVAILABLE:case P.UNAUTHENTICATED:return!1;case P.INVALID_ARGUMENT:case P.NOT_FOUND:case P.ALREADY_EXISTS:case P.PERMISSION_DENIED:case P.FAILED_PRECONDITION:case P.ABORTED:case P.OUT_OF_RANGE:case P.UNIMPLEMENTED:case P.DATA_LOSS:return!0;default:return M(15467,{code:r})}}function td(r){if(r===void 0)return mt("GRPC error has no .code"),P.UNKNOWN;switch(r){case pt.OK:return P.OK;case pt.CANCELLED:return P.CANCELLED;case pt.UNKNOWN:return P.UNKNOWN;case pt.DEADLINE_EXCEEDED:return P.DEADLINE_EXCEEDED;case pt.RESOURCE_EXHAUSTED:return P.RESOURCE_EXHAUSTED;case pt.INTERNAL:return P.INTERNAL;case pt.UNAVAILABLE:return P.UNAVAILABLE;case pt.UNAUTHENTICATED:return P.UNAUTHENTICATED;case pt.INVALID_ARGUMENT:return P.INVALID_ARGUMENT;case pt.NOT_FOUND:return P.NOT_FOUND;case pt.ALREADY_EXISTS:return P.ALREADY_EXISTS;case pt.PERMISSION_DENIED:return P.PERMISSION_DENIED;case pt.FAILED_PRECONDITION:return P.FAILED_PRECONDITION;case pt.ABORTED:return P.ABORTED;case pt.OUT_OF_RANGE:return P.OUT_OF_RANGE;case pt.UNIMPLEMENTED:return P.UNIMPLEMENTED;case pt.DATA_LOSS:return P.DATA_LOSS;default:return M(39323,{code:r})}}(X=pt||(pt={}))[X.OK=0]="OK",X[X.CANCELLED=1]="CANCELLED",X[X.UNKNOWN=2]="UNKNOWN",X[X.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",X[X.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",X[X.NOT_FOUND=5]="NOT_FOUND",X[X.ALREADY_EXISTS=6]="ALREADY_EXISTS",X[X.PERMISSION_DENIED=7]="PERMISSION_DENIED",X[X.UNAUTHENTICATED=16]="UNAUTHENTICATED",X[X.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",X[X.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",X[X.ABORTED=10]="ABORTED",X[X.OUT_OF_RANGE=11]="OUT_OF_RANGE",X[X.UNIMPLEMENTED=12]="UNIMPLEMENTED",X[X.INTERNAL=13]="INTERNAL",X[X.UNAVAILABLE=14]="UNAVAILABLE",X[X.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let fi=null;/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Og=new Se([4294967295,4294967295],0);function jc(r){const t=ia().encode(r),e=new Gl;return e.update(t),new Uint8Array(e.digest())}function zc(r){const t=new DataView(r.buffer),e=t.getUint32(0,!0),n=t.getUint32(4,!0),s=t.getUint32(8,!0),i=t.getUint32(12,!0);return[new Se([e,n],0),new Se([s,i],0)]}class Aa{constructor(t,e,n){if(this.bitmap=t,this.padding=e,this.hashCount=n,e<0||e>=8)throw new Mr(`Invalid padding: ${e}`);if(n<0)throw new Mr(`Invalid hash count: ${n}`);if(t.length>0&&this.hashCount===0)throw new Mr(`Invalid hash count: ${n}`);if(t.length===0&&e!==0)throw new Mr(`Invalid padding when bitmap length is 0: ${e}`);this.fe=8*t.length-e,this.ge=Se.fromNumber(this.fe)}pe(t,e,n){let s=t.add(e.multiply(Se.fromNumber(n)));return s.compare(Og)===1&&(s=new Se([s.getBits(0),s.getBits(1)],0)),s.modulo(this.ge).toNumber()}ye(t){return!!(this.bitmap[Math.floor(t/8)]&1<<t%8)}mightContain(t){if(this.fe===0)return!1;const e=jc(t),[n,s]=zc(e);for(let i=0;i<this.hashCount;i++){const a=this.pe(n,s,i);if(!this.ye(a))return!1}return!0}static create(t,e,n){const s=t%8==0?0:8-t%8,i=new Uint8Array(Math.ceil(t/8)),a=new Aa(i,s,e);return n.forEach((u=>a.insert(u))),a}insert(t){if(this.fe===0)return;const e=jc(t),[n,s]=zc(e);for(let i=0;i<this.hashCount;i++){const a=this.pe(n,s,i);this.we(a)}}we(t){const e=Math.floor(t/8),n=t%8;this.bitmap[e]|=1<<n}}class Mr extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ms{constructor(t,e,n,s,i){this.snapshotVersion=t,this.targetChanges=e,this.targetMismatches=n,this.documentUpdates=s,this.resolvedLimboDocuments=i}static createSynthesizedRemoteEventForCurrentChange(t,e,n){const s=new Map;return s.set(t,gs.createSynthesizedTargetChangeForCurrentChange(t,e,n)),new ms(U.min(),s,new it(z),Bt(),G())}}class gs{constructor(t,e,n,s,i){this.resumeToken=t,this.current=e,this.addedDocuments=n,this.modifiedDocuments=s,this.removedDocuments=i}static createSynthesizedTargetChangeForCurrentChange(t,e,n){return new gs(n,e,G(),G(),G())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ni{constructor(t,e,n,s){this.Se=t,this.removedTargetIds=e,this.key=n,this.be=s}}class ed{constructor(t,e){this.targetId=t,this.De=e}}class nd{constructor(t,e,n=ft.EMPTY_BYTE_STRING,s=null){this.state=t,this.targetIds=e,this.resumeToken=n,this.cause=s}}class Gc{constructor(){this.ve=0,this.Ce=Kc(),this.Fe=ft.EMPTY_BYTE_STRING,this.Me=!1,this.xe=!0}get current(){return this.Me}get resumeToken(){return this.Fe}get Oe(){return this.ve!==0}get Ne(){return this.xe}Be(t){t.approximateByteSize()>0&&(this.xe=!0,this.Fe=t)}Le(){let t=G(),e=G(),n=G();return this.Ce.forEach(((s,i)=>{switch(i){case 0:t=t.add(s);break;case 2:e=e.add(s);break;case 1:n=n.add(s);break;default:M(38017,{changeType:i})}})),new gs(this.Fe,this.Me,t,e,n)}ke(){this.xe=!1,this.Ce=Kc()}qe(t,e){this.xe=!0,this.Ce=this.Ce.insert(t,e)}Qe(t){this.xe=!0,this.Ce=this.Ce.remove(t)}$e(){this.ve+=1}Ue(){this.ve-=1,q(this.ve>=0,3241,{ve:this.ve})}Ke(){this.xe=!0,this.Me=!0}}class Mg{constructor(t){this.We=t,this.Ge=new Map,this.ze=Bt(),this.je=zs(),this.Je=zs(),this.He=new it(z)}Ye(t){for(const e of t.Se)t.be&&t.be.isFoundDocument()?this.Ze(e,t.be):this.Xe(e,t.key,t.be);for(const e of t.removedTargetIds)this.Xe(e,t.key,t.be)}et(t){this.forEachTarget(t,(e=>{const n=this.tt(e);switch(t.state){case 0:this.nt(e)&&n.Be(t.resumeToken);break;case 1:n.Ue(),n.Oe||n.ke(),n.Be(t.resumeToken);break;case 2:n.Ue(),n.Oe||this.removeTarget(e);break;case 3:this.nt(e)&&(n.Ke(),n.Be(t.resumeToken));break;case 4:this.nt(e)&&(this.rt(e),n.Be(t.resumeToken));break;default:M(56790,{state:t.state})}}))}forEachTarget(t,e){t.targetIds.length>0?t.targetIds.forEach(e):this.Ge.forEach(((n,s)=>{this.nt(s)&&e(s)}))}it(t){const e=t.targetId,n=t.De.count,s=this.st(e);if(s){const i=s.target;if(li(i))if(n===0){const a=new k(i.path);this.Xe(e,a,at.newNoDocument(a,U.min()))}else q(n===1,20013,{expectedCount:n});else{const a=this.ot(e);if(a!==n){const u=this._t(t),c=u?this.ut(u,t,a):1;if(c!==0){this.rt(e);const h=c===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.He=this.He.insert(e,h)}fi?.ct((function(f,m,p,R,b){var D,x,L,j,B,$;const Y={localCacheCount:f,existenceFilterCount:m.count,databaseId:p.database,projectId:p.projectId},K=m.unchangedNames;return K&&(Y.bloomFilter={applied:b===0,hashCount:(D=K?.hashCount)!==null&&D!==void 0?D:0,bitmapLength:(j=(L=(x=K?.bits)===null||x===void 0?void 0:x.bitmap)===null||L===void 0?void 0:L.length)!==null&&j!==void 0?j:0,padding:($=(B=K?.bits)===null||B===void 0?void 0:B.padding)!==null&&$!==void 0?$:0,mightContain:T=>{var _;return(_=R?.mightContain(T))!==null&&_!==void 0&&_}}),Y})(a,t.De,this.We.lt(),u,c))}}}}_t(t){const e=t.De.unchangedNames;if(!e||!e.bits)return null;const{bits:{bitmap:n="",padding:s=0},hashCount:i=0}=e;let a,u;try{a=he(n).toUint8Array()}catch(c){if(c instanceof Ih)return Mt("Decoding the base64 bloom filter in existence filter failed ("+c.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw c}try{u=new Aa(a,s,i)}catch(c){return Mt(c instanceof Mr?"BloomFilter error: ":"Applying bloom filter failed: ",c),null}return u.fe===0?null:u}ut(t,e,n){return e.De.count===n-this.ht(t,e.targetId)?0:2}ht(t,e){const n=this.We.getRemoteKeysForTarget(e);let s=0;return n.forEach((i=>{const a=this.We.lt(),u=`projects/${a.projectId}/databases/${a.database}/documents/${i.path.canonicalString()}`;t.mightContain(u)||(this.Xe(e,i,null),s++)})),s}Pt(t){const e=new Map;this.Ge.forEach(((i,a)=>{const u=this.st(a);if(u){if(i.current&&li(u.target)){const c=new k(u.target.path);this.Tt(c).has(a)||this.It(a,c)||this.Xe(a,c,at.newNoDocument(c,t))}i.Ne&&(e.set(a,i.Le()),i.ke())}}));let n=G();this.Je.forEach(((i,a)=>{let u=!0;a.forEachWhile((c=>{const h=this.st(c);return!h||h.purpose==="TargetPurposeLimboResolution"||(u=!1,!1)})),u&&(n=n.add(i))})),this.ze.forEach(((i,a)=>a.setReadTime(t)));const s=new ms(t,e,this.He,this.ze,n);return this.ze=Bt(),this.je=zs(),this.Je=zs(),this.He=new it(z),s}Ze(t,e){if(!this.nt(t))return;const n=this.It(t,e.key)?2:0;this.tt(t).qe(e.key,n),this.ze=this.ze.insert(e.key,e),this.je=this.je.insert(e.key,this.Tt(e.key).add(t)),this.Je=this.Je.insert(e.key,this.dt(e.key).add(t))}Xe(t,e,n){if(!this.nt(t))return;const s=this.tt(t);this.It(t,e)?s.qe(e,1):s.Qe(e),this.Je=this.Je.insert(e,this.dt(e).delete(t)),this.Je=this.Je.insert(e,this.dt(e).add(t)),n&&(this.ze=this.ze.insert(e,n))}removeTarget(t){this.Ge.delete(t)}ot(t){const e=this.tt(t).Le();return this.We.getRemoteKeysForTarget(t).size+e.addedDocuments.size-e.removedDocuments.size}$e(t){this.tt(t).$e()}tt(t){let e=this.Ge.get(t);return e||(e=new Gc,this.Ge.set(t,e)),e}dt(t){let e=this.Je.get(t);return e||(e=new et(z),this.Je=this.Je.insert(t,e)),e}Tt(t){let e=this.je.get(t);return e||(e=new et(z),this.je=this.je.insert(t,e)),e}nt(t){const e=this.st(t)!==null;return e||N("WatchChangeAggregator","Detected inactive target",t),e}st(t){const e=this.Ge.get(t);return e&&e.Oe?null:this.We.Et(t)}rt(t){this.Ge.set(t,new Gc),this.We.getRemoteKeysForTarget(t).forEach((e=>{this.Xe(t,e,null)}))}It(t,e){return this.We.getRemoteKeysForTarget(t).has(e)}}function zs(){return new it(k.comparator)}function Kc(){return new it(k.comparator)}const Lg={asc:"ASCENDING",desc:"DESCENDING"},qg={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},Bg={and:"AND",or:"OR"};class Ug{constructor(t,e){this.databaseId=t,this.useProto3Json=e}}function Ko(r,t){return r.useProto3Json||us(t)?t:{value:t}}function Xn(r,t){return r.useProto3Json?`${new Date(1e3*t.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+t.nanoseconds).slice(-9)}Z`:{seconds:""+t.seconds,nanos:t.nanoseconds}}function rd(r,t){return r.useProto3Json?t.toBase64():t.toUint8Array()}function jg(r,t){return Xn(r,t.toTimestamp())}function gt(r){return q(!!r,49232),U.fromTimestamp((function(e){const n=le(e);return new Z(n.seconds,n.nanos)})(r))}function Ra(r,t){return $o(r,t).canonicalString()}function $o(r,t){const e=(function(s){return new Q(["projects",s.projectId,"databases",s.database])})(r).child("documents");return t===void 0?e:e.child(t)}function sd(r){const t=Q.fromString(r);return q(fd(t),10190,{key:t.toString()}),t}function ns(r,t){return Ra(r.databaseId,t.path)}function ee(r,t){const e=sd(t);if(e.get(1)!==r.databaseId.projectId)throw new C(P.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+e.get(1)+" vs "+r.databaseId.projectId);if(e.get(3)!==r.databaseId.database)throw new C(P.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+e.get(3)+" vs "+r.databaseId.database);return new k(ad(e))}function id(r,t){return Ra(r.databaseId,t)}function od(r){const t=sd(r);return t.length===4?Q.emptyPath():ad(t)}function Qo(r){return new Q(["projects",r.databaseId.projectId,"databases",r.databaseId.database]).canonicalString()}function ad(r){return q(r.length>4&&r.get(4)==="documents",29091,{key:r.toString()}),r.popFirst(5)}function $c(r,t,e){return{name:ns(r,t),fields:e.value.mapValue.fields}}function Ni(r,t,e){const n=ee(r,t.name),s=gt(t.updateTime),i=t.createTime?gt(t.createTime):U.min(),a=new Pt({mapValue:{fields:t.fields}}),u=at.newFoundDocument(n,s,i,a);return e&&u.setHasCommittedMutations(),e?u.setHasCommittedMutations():u}function zg(r,t){return"found"in t?(function(n,s){q(!!s.found,43571),s.found.name,s.found.updateTime;const i=ee(n,s.found.name),a=gt(s.found.updateTime),u=s.found.createTime?gt(s.found.createTime):U.min(),c=new Pt({mapValue:{fields:s.found.fields}});return at.newFoundDocument(i,a,u,c)})(r,t):"missing"in t?(function(n,s){q(!!s.missing,3894),q(!!s.readTime,22933);const i=ee(n,s.missing),a=gt(s.readTime);return at.newNoDocument(i,a)})(r,t):M(7234,{result:t})}function Gg(r,t){let e;if("targetChange"in t){t.targetChange;const n=(function(h){return h==="NO_CHANGE"?0:h==="ADD"?1:h==="REMOVE"?2:h==="CURRENT"?3:h==="RESET"?4:M(39313,{state:h})})(t.targetChange.targetChangeType||"NO_CHANGE"),s=t.targetChange.targetIds||[],i=(function(h,f){return h.useProto3Json?(q(f===void 0||typeof f=="string",58123),ft.fromBase64String(f||"")):(q(f===void 0||f instanceof Buffer||f instanceof Uint8Array,16193),ft.fromUint8Array(f||new Uint8Array))})(r,t.targetChange.resumeToken),a=t.targetChange.cause,u=a&&(function(h){const f=h.code===void 0?P.UNKNOWN:td(h.code);return new C(f,h.message||"")})(a);e=new nd(n,s,i,u||null)}else if("documentChange"in t){t.documentChange;const n=t.documentChange;n.document,n.document.name,n.document.updateTime;const s=ee(r,n.document.name),i=gt(n.document.updateTime),a=n.document.createTime?gt(n.document.createTime):U.min(),u=new Pt({mapValue:{fields:n.document.fields}}),c=at.newFoundDocument(s,i,a,u),h=n.targetIds||[],f=n.removedTargetIds||[];e=new ni(h,f,c.key,c)}else if("documentDelete"in t){t.documentDelete;const n=t.documentDelete;n.document;const s=ee(r,n.document),i=n.readTime?gt(n.readTime):U.min(),a=at.newNoDocument(s,i),u=n.removedTargetIds||[];e=new ni([],u,a.key,a)}else if("documentRemove"in t){t.documentRemove;const n=t.documentRemove;n.document;const s=ee(r,n.document),i=n.removedTargetIds||[];e=new ni([],i,s,null)}else{if(!("filter"in t))return M(11601,{At:t});{t.filter;const n=t.filter;n.targetId;const{count:s=0,unchangedNames:i}=n,a=new Fg(s,i),u=n.targetId;e=new ed(u,a)}}return e}function rs(r,t){let e;if(t instanceof ir)e={update:$c(r,t.key,t.value)};else if(t instanceof or)e={delete:ns(r,t.key)};else if(t instanceof me)e={update:$c(r,t.key,t.data),updateMask:Xg(t.fieldMask)};else{if(!(t instanceof Ta))return M(16599,{Rt:t.type});e={verify:ns(r,t.key)}}return t.fieldTransforms.length>0&&(e.updateTransforms=t.fieldTransforms.map((n=>(function(i,a){const u=a.transform;if(u instanceof Wn)return{fieldPath:a.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(u instanceof un)return{fieldPath:a.field.canonicalString(),appendMissingElements:{values:u.elements}};if(u instanceof cn)return{fieldPath:a.field.canonicalString(),removeAllFromArray:{values:u.elements}};if(u instanceof Hn)return{fieldPath:a.field.canonicalString(),increment:u.Ee};throw M(20930,{transform:a.transform})})(0,n)))),t.precondition.isNone||(e.currentDocument=(function(s,i){return i.updateTime!==void 0?{updateTime:jg(s,i.updateTime)}:i.exists!==void 0?{exists:i.exists}:M(27497)})(r,t.precondition)),e}function Wo(r,t){const e=t.currentDocument?(function(i){return i.updateTime!==void 0?lt.updateTime(gt(i.updateTime)):i.exists!==void 0?lt.exists(i.exists):lt.none()})(t.currentDocument):lt.none(),n=t.updateTransforms?t.updateTransforms.map((s=>(function(a,u){let c=null;if("setToServerValue"in u)q(u.setToServerValue==="REQUEST_TIME",16630,{proto:u}),c=new Wn;else if("appendMissingElements"in u){const f=u.appendMissingElements.values||[];c=new un(f)}else if("removeAllFromArray"in u){const f=u.removeAllFromArray.values||[];c=new cn(f)}else"increment"in u?c=new Hn(a,u.increment):M(16584,{proto:u});const h=ct.fromServerFormat(u.fieldPath);return new fs(h,c)})(r,s))):[];if(t.update){t.update.name;const s=ee(r,t.update.name),i=new Pt({mapValue:{fields:t.update.fields}});if(t.updateMask){const a=(function(c){const h=c.fieldPaths||[];return new qt(h.map((f=>ct.fromServerFormat(f))))})(t.updateMask);return new me(s,i,a,e,n)}return new ir(s,i,e,n)}if(t.delete){const s=ee(r,t.delete);return new or(s,e)}if(t.verify){const s=ee(r,t.verify);return new Ta(s,e)}return M(1463,{proto:t})}function Kg(r,t){return r&&r.length>0?(q(t!==void 0,14353),r.map((e=>(function(s,i){let a=s.updateTime?gt(s.updateTime):gt(i);return a.isEqual(U.min())&&(a=gt(i)),new xg(a,s.transformResults||[])})(e,t)))):[]}function ud(r,t){return{documents:[id(r,t.path)]}}function ki(r,t){const e={structuredQuery:{}},n=t.path;let s;t.collectionGroup!==null?(s=n,e.structuredQuery.from=[{collectionId:t.collectionGroup,allDescendants:!0}]):(s=n.popLast(),e.structuredQuery.from=[{collectionId:n.lastSegment()}]),e.parent=id(r,s);const i=(function(h){if(h.length!==0)return dd(tt.create(h,"and"))})(t.filters);i&&(e.structuredQuery.where=i);const a=(function(h){if(h.length!==0)return h.map((f=>(function(p){return{field:ve(p.field),direction:Qg(p.dir)}})(f)))})(t.orderBy);a&&(e.structuredQuery.orderBy=a);const u=Ko(r,t.limit);return u!==null&&(e.structuredQuery.limit=u),t.startAt&&(e.structuredQuery.startAt=(function(h){return{before:h.inclusive,values:h.position}})(t.startAt)),t.endAt&&(e.structuredQuery.endAt=(function(h){return{before:!h.inclusive,values:h.position}})(t.endAt)),{Vt:e,parent:s}}function cd(r,t,e,n){const{Vt:s,parent:i}=ki(r,t),a={},u=[];let c=0;return e.forEach((h=>{const f=n?h.alias:"aggregate_"+c++;a[f]=h.alias,h.aggregateType==="count"?u.push({alias:f,count:{}}):h.aggregateType==="avg"?u.push({alias:f,avg:{field:ve(h.fieldPath)}}):h.aggregateType==="sum"&&u.push({alias:f,sum:{field:ve(h.fieldPath)}})})),{request:{structuredAggregationQuery:{aggregations:u,structuredQuery:s.structuredQuery},parent:s.parent},ft:a,parent:i}}function ld(r){let t=od(r.parent);const e=r.structuredQuery,n=e.from?e.from.length:0;let s=null;if(n>0){q(n===1,65062);const f=e.from[0];f.allDescendants?s=f.collectionId:t=t.child(f.collectionId)}let i=[];e.where&&(i=(function(m){const p=hd(m);return p instanceof tt&&pa(p)?p.getFilters():[p]})(e.where));let a=[];e.orderBy&&(a=(function(m){return m.map((p=>(function(b){return new es(Nn(b.field),(function(x){switch(x){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}})(b.direction))})(p)))})(e.orderBy));let u=null;e.limit&&(u=(function(m){let p;return p=typeof m=="object"?m.value:m,us(p)?null:p})(e.limit));let c=null;e.startAt&&(c=(function(m){const p=!!m.before,R=m.values||[];return new Ne(R,p)})(e.startAt));let h=null;return e.endAt&&(h=(function(m){const p=!m.before,R=m.values||[];return new Ne(R,p)})(e.endAt)),Fh(t,s,a,i,u,"F",c,h)}function $g(r,t){const e=(function(s){switch(s){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return M(28987,{purpose:s})}})(t.purpose);return e==null?null:{"goog-listen-tags":e}}function hd(r){return r.unaryFilter!==void 0?(function(e){switch(e.unaryFilter.op){case"IS_NAN":const n=Nn(e.unaryFilter.field);return H.create(n,"==",{doubleValue:NaN});case"IS_NULL":const s=Nn(e.unaryFilter.field);return H.create(s,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const i=Nn(e.unaryFilter.field);return H.create(i,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const a=Nn(e.unaryFilter.field);return H.create(a,"!=",{nullValue:"NULL_VALUE"});case"OPERATOR_UNSPECIFIED":return M(61313);default:return M(60726)}})(r):r.fieldFilter!==void 0?(function(e){return H.create(Nn(e.fieldFilter.field),(function(s){switch(s){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";case"OPERATOR_UNSPECIFIED":return M(58110);default:return M(50506)}})(e.fieldFilter.op),e.fieldFilter.value)})(r):r.compositeFilter!==void 0?(function(e){return tt.create(e.compositeFilter.filters.map((n=>hd(n))),(function(s){switch(s){case"AND":return"and";case"OR":return"or";default:return M(1026)}})(e.compositeFilter.op))})(r):M(30097,{filter:r})}function Qg(r){return Lg[r]}function Wg(r){return qg[r]}function Hg(r){return Bg[r]}function ve(r){return{fieldPath:r.canonicalString()}}function Nn(r){return ct.fromServerFormat(r.fieldPath)}function dd(r){return r instanceof H?(function(e){if(e.op==="=="){if(Cc(e.value))return{unaryFilter:{field:ve(e.field),op:"IS_NAN"}};if(bc(e.value))return{unaryFilter:{field:ve(e.field),op:"IS_NULL"}}}else if(e.op==="!="){if(Cc(e.value))return{unaryFilter:{field:ve(e.field),op:"IS_NOT_NAN"}};if(bc(e.value))return{unaryFilter:{field:ve(e.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:ve(e.field),op:Wg(e.op),value:e.value}}})(r):r instanceof tt?(function(e){const n=e.getFilters().map((s=>dd(s)));return n.length===1?n[0]:{compositeFilter:{op:Hg(e.op),filters:n}}})(r):M(54877,{filter:r})}function Xg(r){const t=[];return r.fields.forEach((e=>t.push(e.canonicalString()))),{fieldPaths:t}}function fd(r){return r.length>=4&&r.get(0)==="projects"&&r.get(2)==="databases"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ce{constructor(t,e,n,s,i=U.min(),a=U.min(),u=ft.EMPTY_BYTE_STRING,c=null){this.target=t,this.targetId=e,this.purpose=n,this.sequenceNumber=s,this.snapshotVersion=i,this.lastLimboFreeSnapshotVersion=a,this.resumeToken=u,this.expectedCount=c}withSequenceNumber(t){return new ce(this.target,this.targetId,this.purpose,t,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(t,e){return new ce(this.target,this.targetId,this.purpose,this.sequenceNumber,e,this.lastLimboFreeSnapshotVersion,t,null)}withExpectedCount(t){return new ce(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,t)}withLastLimboFreeSnapshotVersion(t){return new ce(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,t,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class md{constructor(t){this.gt=t}}function Jg(r,t){let e;if(t.document)e=Ni(r.gt,t.document,!!t.hasCommittedMutations);else if(t.noDocument){const n=k.fromSegments(t.noDocument.path),s=hn(t.noDocument.readTime);e=at.newNoDocument(n,s),t.hasCommittedMutations&&e.setHasCommittedMutations()}else{if(!t.unknownDocument)return M(56709);{const n=k.fromSegments(t.unknownDocument.path),s=hn(t.unknownDocument.version);e=at.newUnknownDocument(n,s)}}return t.readTime&&e.setReadTime((function(s){const i=new Z(s[0],s[1]);return U.fromTimestamp(i)})(t.readTime)),e}function Qc(r,t){const e=t.key,n={prefixPath:e.getCollectionPath().popLast().toArray(),collectionGroup:e.collectionGroup,documentId:e.path.lastSegment(),readTime:mi(t.readTime),hasCommittedMutations:t.hasCommittedMutations};if(t.isFoundDocument())n.document=(function(i,a){return{name:ns(i,a.key),fields:a.data.value.mapValue.fields,updateTime:Xn(i,a.version.toTimestamp()),createTime:Xn(i,a.createTime.toTimestamp())}})(r.gt,t);else if(t.isNoDocument())n.noDocument={path:e.path.toArray(),readTime:ln(t.version)};else{if(!t.isUnknownDocument())return M(57904,{document:t});n.unknownDocument={path:e.path.toArray(),version:ln(t.version)}}return n}function mi(r){const t=r.toTimestamp();return[t.seconds,t.nanoseconds]}function ln(r){const t=r.toTimestamp();return{seconds:t.seconds,nanoseconds:t.nanoseconds}}function hn(r){const t=new Z(r.seconds,r.nanoseconds);return U.fromTimestamp(t)}function Je(r,t){const e=(t.baseMutations||[]).map((i=>Wo(r.gt,i)));for(let i=0;i<t.mutations.length-1;++i){const a=t.mutations[i];if(i+1<t.mutations.length&&t.mutations[i+1].transform!==void 0){const u=t.mutations[i+1];a.updateTransforms=u.transform.fieldTransforms,t.mutations.splice(i+1,1),++i}}const n=t.mutations.map((i=>Wo(r.gt,i))),s=Z.fromMillis(t.localWriteTimeMs);return new Ea(t.batchId,s,e,n)}function Lr(r){const t=hn(r.readTime),e=r.lastLimboFreeSnapshotVersion!==void 0?hn(r.lastLimboFreeSnapshotVersion):U.min();let n;return n=(function(i){return i.documents!==void 0})(r.query)?(function(i){const a=i.documents.length;return q(a===1,1966,{count:a}),kt(sr(od(i.documents[0])))})(r.query):(function(i){return kt(ld(i))})(r.query),new ce(n,r.targetId,"TargetPurposeListen",r.lastListenSequenceNumber,t,e,ft.fromBase64String(r.resumeToken))}function gd(r,t){const e=ln(t.snapshotVersion),n=ln(t.lastLimboFreeSnapshotVersion);let s;s=li(t.target)?ud(r.gt,t.target):ki(r.gt,t.target).Vt;const i=t.resumeToken.toBase64();return{targetId:t.targetId,canonicalId:an(t.target),readTime:e,resumeToken:i,lastListenSequenceNumber:t.sequenceNumber,lastLimboFreeSnapshotVersion:n,query:s}}function Fi(r){const t=ld({parent:r.parent,structuredQuery:r.structuredQuery});return r.limitType==="LAST"?di(t,t.limit,"L"):t}function wo(r,t){return new va(t.largestBatchId,Wo(r.gt,t.overlayMutation))}function Wc(r,t){const e=t.path.lastSegment();return[r,Nt(t.path.popLast()),e]}function Hc(r,t,e,n){return{indexId:r,uid:t,sequenceNumber:e,readTime:ln(n.readTime),documentKey:Nt(n.documentKey.path),largestBatchId:n.largestBatchId}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yg{getBundleMetadata(t,e){return Xc(t).get(e).next((n=>{if(n)return(function(i){return{id:i.bundleId,createTime:hn(i.createTime),version:i.version}})(n)}))}saveBundleMetadata(t,e){return Xc(t).put((function(s){return{bundleId:s.id,createTime:ln(gt(s.createTime)),version:s.version}})(e))}getNamedQuery(t,e){return Jc(t).get(e).next((n=>{if(n)return(function(i){return{name:i.name,query:Fi(i.bundledQuery),readTime:hn(i.readTime)}})(n)}))}saveNamedQuery(t,e){return Jc(t).put((function(s){return{name:s.name,readTime:ln(gt(s.readTime)),bundledQuery:s.bundledQuery}})(e))}}function Xc(r){return It(r,Ri)}function Jc(r){return It(r,Pi)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Oi{constructor(t,e){this.serializer=t,this.userId=e}static yt(t,e){const n=e.uid||"";return new Oi(t,n)}getOverlay(t,e){return Cr(t).get(Wc(this.userId,e)).next((n=>n?wo(this.serializer,n):null))}getOverlays(t,e){const n=Zt();return v.forEach(e,(s=>this.getOverlay(t,s).next((i=>{i!==null&&n.set(s,i)})))).next((()=>n))}saveOverlays(t,e,n){const s=[];return n.forEach(((i,a)=>{const u=new va(e,a);s.push(this.wt(t,u))})),v.waitFor(s)}removeOverlaysForBatchId(t,e,n){const s=new Set;e.forEach((a=>s.add(Nt(a.getCollectionPath()))));const i=[];return s.forEach((a=>{const u=IDBKeyRange.bound([this.userId,a,n],[this.userId,a,n+1],!1,!0);i.push(Cr(t).Y(Mo,u))})),v.waitFor(i)}getOverlaysForCollection(t,e,n){const s=Zt(),i=Nt(e),a=IDBKeyRange.bound([this.userId,i,n],[this.userId,i,Number.POSITIVE_INFINITY],!0);return Cr(t).j(Mo,a).next((u=>{for(const c of u){const h=wo(this.serializer,c);s.set(h.getKey(),h)}return s}))}getOverlaysForCollectionGroup(t,e,n,s){const i=Zt();let a;const u=IDBKeyRange.bound([this.userId,e,n],[this.userId,e,Number.POSITIVE_INFINITY],!0);return Cr(t).X({index:dh,range:u},((c,h,f)=>{const m=wo(this.serializer,h);i.size()<s||m.largestBatchId===a?(i.set(m.getKey(),m),a=m.largestBatchId):f.done()})).next((()=>i))}wt(t,e){return Cr(t).put((function(s,i,a){const[u,c,h]=Wc(i,a.mutation.key);return{userId:i,collectionPath:c,documentId:h,collectionGroup:a.mutation.key.getCollectionGroup(),largestBatchId:a.largestBatchId,overlayMutation:rs(s.gt,a.mutation)}})(this.serializer,this.userId,e))}}function Cr(r){return It(r,Vi)}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zg{St(t){return It(t,da)}getSessionToken(t){return this.St(t).get("sessionToken").next((e=>{const n=e?.value;return n?ft.fromUint8Array(n):ft.EMPTY_BYTE_STRING}))}setSessionToken(t,e){return this.St(t).put({name:"sessionToken",value:e.toUint8Array()})}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ye{constructor(){}bt(t,e){this.Dt(t,e),e.vt()}Dt(t,e){if("nullValue"in t)this.Ct(e,5);else if("booleanValue"in t)this.Ct(e,10),e.Ft(t.booleanValue?1:0);else if("integerValue"in t)this.Ct(e,15),e.Ft(ut(t.integerValue));else if("doubleValue"in t){const n=ut(t.doubleValue);isNaN(n)?this.Ct(e,13):(this.Ct(e,15),Qr(n)?e.Ft(0):e.Ft(n))}else if("timestampValue"in t){let n=t.timestampValue;this.Ct(e,20),typeof n=="string"&&(n=le(n)),e.Mt(`${n.seconds||""}`),e.Ft(n.nanos||0)}else if("stringValue"in t)this.xt(t.stringValue,e),this.Ot(e);else if("bytesValue"in t)this.Ct(e,30),e.Nt(he(t.bytesValue)),this.Ot(e);else if("referenceValue"in t)this.Bt(t.referenceValue,e);else if("geoPointValue"in t){const n=t.geoPointValue;this.Ct(e,45),e.Ft(n.latitude||0),e.Ft(n.longitude||0)}else"mapValue"in t?Rh(t)?this.Ct(e,Number.MAX_SAFE_INTEGER):Ci(t)?this.Lt(t.mapValue,e):(this.kt(t.mapValue,e),this.Ot(e)):"arrayValue"in t?(this.qt(t.arrayValue,e),this.Ot(e)):M(19022,{Qt:t})}xt(t,e){this.Ct(e,25),this.$t(t,e)}$t(t,e){e.Mt(t)}kt(t,e){const n=t.fields||{};this.Ct(e,55);for(const s of Object.keys(n))this.xt(s,e),this.Dt(n[s],e)}Lt(t,e){var n,s;const i=t.fields||{};this.Ct(e,53);const a=Kn,u=((s=(n=i[a].arrayValue)===null||n===void 0?void 0:n.values)===null||s===void 0?void 0:s.length)||0;this.Ct(e,15),e.Ft(ut(u)),this.xt(a,e),this.Dt(i[a],e)}qt(t,e){const n=t.values||[];this.Ct(e,50);for(const s of n)this.Dt(s,e)}Bt(t,e){this.Ct(e,37),k.fromName(t).path.forEach((n=>{this.Ct(e,60),this.$t(n,e)}))}Ct(t,e){t.Ft(e)}Ot(t){t.Ft(2)}}Ye.Ut=new Ye;/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law | agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES | CONDITIONS OF ANY KIND, either express | implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Vn=255;function tp(r){if(r===0)return 8;let t=0;return r>>4||(t+=4,r<<=4),r>>6||(t+=2,r<<=2),r>>7||(t+=1),t}function Yc(r){const t=64-(function(n){let s=0;for(let i=0;i<8;++i){const a=tp(255&n[i]);if(s+=a,a!==8)break}return s})(r);return Math.ceil(t/8)}class ep{constructor(){this.buffer=new Uint8Array(1024),this.position=0}Kt(t){const e=t[Symbol.iterator]();let n=e.next();for(;!n.done;)this.Wt(n.value),n=e.next();this.Gt()}zt(t){const e=t[Symbol.iterator]();let n=e.next();for(;!n.done;)this.jt(n.value),n=e.next();this.Jt()}Ht(t){for(const e of t){const n=e.charCodeAt(0);if(n<128)this.Wt(n);else if(n<2048)this.Wt(960|n>>>6),this.Wt(128|63&n);else if(e<"\uD800"||"\uDBFF"<e)this.Wt(480|n>>>12),this.Wt(128|63&n>>>6),this.Wt(128|63&n);else{const s=e.codePointAt(0);this.Wt(240|s>>>18),this.Wt(128|63&s>>>12),this.Wt(128|63&s>>>6),this.Wt(128|63&s)}}this.Gt()}Yt(t){for(const e of t){const n=e.charCodeAt(0);if(n<128)this.jt(n);else if(n<2048)this.jt(960|n>>>6),this.jt(128|63&n);else if(e<"\uD800"||"\uDBFF"<e)this.jt(480|n>>>12),this.jt(128|63&n>>>6),this.jt(128|63&n);else{const s=e.codePointAt(0);this.jt(240|s>>>18),this.jt(128|63&s>>>12),this.jt(128|63&s>>>6),this.jt(128|63&s)}}this.Jt()}Zt(t){const e=this.Xt(t),n=Yc(e);this.en(1+n),this.buffer[this.position++]=255&n;for(let s=e.length-n;s<e.length;++s)this.buffer[this.position++]=255&e[s]}tn(t){const e=this.Xt(t),n=Yc(e);this.en(1+n),this.buffer[this.position++]=~(255&n);for(let s=e.length-n;s<e.length;++s)this.buffer[this.position++]=~(255&e[s])}nn(){this.rn(Vn),this.rn(255)}sn(){this._n(Vn),this._n(255)}reset(){this.position=0}seed(t){this.en(t.length),this.buffer.set(t,this.position),this.position+=t.length}an(){return this.buffer.slice(0,this.position)}Xt(t){const e=(function(i){const a=new DataView(new ArrayBuffer(8));return a.setFloat64(0,i,!1),new Uint8Array(a.buffer)})(t),n=!!(128&e[0]);e[0]^=n?255:128;for(let s=1;s<e.length;++s)e[s]^=n?255:0;return e}Wt(t){const e=255&t;e===0?(this.rn(0),this.rn(255)):e===Vn?(this.rn(Vn),this.rn(0)):this.rn(e)}jt(t){const e=255&t;e===0?(this._n(0),this._n(255)):e===Vn?(this._n(Vn),this._n(0)):this._n(t)}Gt(){this.rn(0),this.rn(1)}Jt(){this._n(0),this._n(1)}rn(t){this.en(1),this.buffer[this.position++]=t}_n(t){this.en(1),this.buffer[this.position++]=~t}en(t){const e=t+this.position;if(e<=this.buffer.length)return;let n=2*this.buffer.length;n<e&&(n=e);const s=new Uint8Array(n);s.set(this.buffer),this.buffer=s}}class np{constructor(t){this.un=t}Nt(t){this.un.Kt(t)}Mt(t){this.un.Ht(t)}Ft(t){this.un.Zt(t)}vt(){this.un.nn()}}class rp{constructor(t){this.un=t}Nt(t){this.un.zt(t)}Mt(t){this.un.Yt(t)}Ft(t){this.un.tn(t)}vt(){this.un.sn()}}class Dr{constructor(){this.un=new ep,this.cn=new np(this.un),this.ln=new rp(this.un)}seed(t){this.un.seed(t)}hn(t){return t===0?this.cn:this.ln}an(){return this.un.an()}reset(){this.un.reset()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ze{constructor(t,e,n,s){this.Pn=t,this.Tn=e,this.In=n,this.dn=s}En(){const t=this.dn.length,e=t===0||this.dn[t-1]===255?t+1:t,n=new Uint8Array(e);return n.set(this.dn,0),e!==t?n.set([0],this.dn.length):++n[n.length-1],new Ze(this.Pn,this.Tn,this.In,n)}An(t,e,n){return{indexId:this.Pn,uid:t,arrayValue:ri(this.In),directionalValue:ri(this.dn),orderedDocumentKey:ri(e),documentKey:n.path.toArray()}}Rn(t,e,n){const s=this.An(t,e,n);return[s.indexId,s.uid,s.arrayValue,s.directionalValue,s.orderedDocumentKey,s.documentKey]}}function Te(r,t){let e=r.Pn-t.Pn;return e!==0?e:(e=Zc(r.In,t.In),e!==0?e:(e=Zc(r.dn,t.dn),e!==0?e:k.comparator(r.Tn,t.Tn)))}function Zc(r,t){for(let e=0;e<r.length&&e<t.length;++e){const n=r[e]-t[e];if(n!==0)return n}return r.length-t.length}function ri(r){return zl()?(function(e){let n="";for(let s=0;s<e.length;s++)n+=String.fromCharCode(e[s]);return n})(r):r}function tl(r){return typeof r!="string"?r:(function(e){const n=new Uint8Array(e.length);for(let s=0;s<e.length;s++)n[s]=e.charCodeAt(s);return n})(r)}class el{constructor(t){this.Vn=new et(((e,n)=>ct.comparator(e.field,n.field))),this.collectionId=t.collectionGroup!=null?t.collectionGroup:t.path.lastSegment(),this.mn=t.orderBy,this.fn=[];for(const e of t.filters){const n=e;n.isInequality()?this.Vn=this.Vn.add(n):this.fn.push(n)}}get gn(){return this.Vn.size>1}pn(t){if(q(t.collectionGroup===this.collectionId,49279),this.gn)return!1;const e=ko(t);if(e!==void 0&&!this.yn(e))return!1;const n=We(t);let s=new Set,i=0,a=0;for(;i<n.length&&this.yn(n[i]);++i)s=s.add(n[i].fieldPath.canonicalString());if(i===n.length)return!0;if(this.Vn.size>0){const u=this.Vn.getIterator().getNext();if(!s.has(u.field.canonicalString())){const c=n[i];if(!this.wn(u,c)||!this.Sn(this.mn[a++],c))return!1}++i}for(;i<n.length;++i){const u=n[i];if(a>=this.mn.length||!this.Sn(this.mn[a++],u))return!1}return!0}bn(){if(this.gn)return null;let t=new et(ct.comparator);const e=[];for(const n of this.fn)if(!n.field.isKeyField())if(n.op==="array-contains"||n.op==="array-contains-any")e.push(new en(n.field,2));else{if(t.has(n.field))continue;t=t.add(n.field),e.push(new en(n.field,0))}for(const n of this.mn)n.field.isKeyField()||t.has(n.field)||(t=t.add(n.field),e.push(new en(n.field,n.dir==="asc"?0:1)));return new qn(qn.UNKNOWN_ID,this.collectionId,e,Bn.empty())}yn(t){for(const e of this.fn)if(this.wn(e,t))return!0;return!1}wn(t,e){if(t===void 0||!t.field.isEqual(e.fieldPath))return!1;const n=t.op==="array-contains"||t.op==="array-contains-any";return e.kind===2===n}Sn(t,e){return!!t.field.isEqual(e.fieldPath)&&(e.kind===0&&t.dir==="asc"||e.kind===1&&t.dir==="desc")}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pd(r){var t,e;if(q(r instanceof H||r instanceof tt,20012),r instanceof H){if(r instanceof kh){const s=((e=(t=r.value.arrayValue)===null||t===void 0?void 0:t.values)===null||e===void 0?void 0:e.map((i=>H.create(r.field,"==",i))))||[];return tt.create(s,"or")}return r}const n=r.filters.map((s=>pd(s)));return tt.create(n,r.op)}function sp(r){if(r.getFilters().length===0)return[];const t=Jo(pd(r));return q(_d(t),7391),Ho(t)||Xo(t)?[t]:t.getFilters()}function Ho(r){return r instanceof H}function Xo(r){return r instanceof tt&&pa(r)}function _d(r){return Ho(r)||Xo(r)||(function(e){if(e instanceof tt&&Uo(e)){for(const n of e.getFilters())if(!Ho(n)&&!Xo(n))return!1;return!0}return!1})(r)}function Jo(r){if(q(r instanceof H||r instanceof tt,34018),r instanceof H)return r;if(r.filters.length===1)return Jo(r.filters[0]);const t=r.filters.map((n=>Jo(n)));let e=tt.create(t,r.op);return e=gi(e),_d(e)?e:(q(e instanceof tt,64498),q(Qn(e),40251),q(e.filters.length>1,57927),e.filters.reduce(((n,s)=>Pa(n,s))))}function Pa(r,t){let e;return q(r instanceof H||r instanceof tt,38388),q(t instanceof H||t instanceof tt,25473),e=r instanceof H?t instanceof H?(function(s,i){return tt.create([s,i],"and")})(r,t):nl(r,t):t instanceof H?nl(t,r):(function(s,i){if(q(s.filters.length>0&&i.filters.length>0,48005),Qn(s)&&Qn(i))return Dh(s,i.getFilters());const a=Uo(s)?s:i,u=Uo(s)?i:s,c=a.filters.map((h=>Pa(h,u)));return tt.create(c,"or")})(r,t),gi(e)}function nl(r,t){if(Qn(t))return Dh(t,r.getFilters());{const e=t.filters.map((n=>Pa(r,n)));return tt.create(e,"or")}}function gi(r){if(q(r instanceof H||r instanceof tt,11850),r instanceof H)return r;const t=r.getFilters();if(t.length===1)return gi(t[0]);if(bh(r))return r;const e=t.map((s=>gi(s))),n=[];return e.forEach((s=>{s instanceof H?n.push(s):s instanceof tt&&(s.op===r.op?n.push(...s.filters):n.push(s))})),n.length===1?n[0]:tt.create(n,r.op)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ip{constructor(){this.Dn=new Va}addToCollectionParentIndex(t,e){return this.Dn.add(e),v.resolve()}getCollectionParents(t,e){return v.resolve(this.Dn.getEntries(e))}addFieldIndex(t,e){return v.resolve()}deleteFieldIndex(t,e){return v.resolve()}deleteAllFieldIndexes(t){return v.resolve()}createTargetIndexes(t,e){return v.resolve()}getDocumentsMatchingTarget(t,e){return v.resolve(null)}getIndexType(t,e){return v.resolve(0)}getFieldIndexes(t,e){return v.resolve([])}getNextCollectionGroupToUpdate(t){return v.resolve(null)}getMinOffset(t,e){return v.resolve($t.min())}getMinOffsetFromCollectionGroup(t,e){return v.resolve($t.min())}updateCollectionGroup(t,e,n){return v.resolve()}updateIndexEntries(t,e){return v.resolve()}}class Va{constructor(){this.index={}}add(t){const e=t.lastSegment(),n=t.popLast(),s=this.index[e]||new et(Q.comparator),i=!s.has(n);return this.index[e]=s.add(n),i}has(t){const e=t.lastSegment(),n=t.popLast(),s=this.index[e];return s&&s.has(n)}getEntries(t){return(this.index[t]||new et(Q.comparator)).toArray()}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rl="IndexedDbIndexManager",Gs=new Uint8Array(0);class op{constructor(t,e){this.databaseId=e,this.vn=new Va,this.Cn=new fe((n=>an(n)),((n,s)=>ls(n,s))),this.uid=t.uid||""}addToCollectionParentIndex(t,e){if(!this.vn.has(e)){const n=e.lastSegment(),s=e.popLast();t.addOnCommittedListener((()=>{this.vn.add(e)}));const i={collectionId:n,parent:Nt(s)};return sl(t).put(i)}return v.resolve()}getCollectionParents(t,e){const n=[],s=IDBKeyRange.bound([e,""],[Yl(e),""],!1,!0);return sl(t).j(s).next((i=>{for(const a of i){if(a.collectionId!==e)break;n.push(Yt(a.parent))}return n}))}addFieldIndex(t,e){const n=xr(t),s=(function(u){return{indexId:u.indexId,collectionGroup:u.collectionGroup,fields:u.fields.map((c=>[c.fieldPath.canonicalString(),c.kind]))}})(e);delete s.indexId;const i=n.add(s);if(e.indexState){const a=bn(t);return i.next((u=>{a.put(Hc(u,this.uid,e.indexState.sequenceNumber,e.indexState.offset))}))}return i.next()}deleteFieldIndex(t,e){const n=xr(t),s=bn(t),i=Sn(t);return n.delete(e.indexId).next((()=>s.delete(IDBKeyRange.bound([e.indexId],[e.indexId+1],!1,!0)))).next((()=>i.delete(IDBKeyRange.bound([e.indexId],[e.indexId+1],!1,!0))))}deleteAllFieldIndexes(t){const e=xr(t),n=Sn(t),s=bn(t);return e.Y().next((()=>n.Y())).next((()=>s.Y()))}createTargetIndexes(t,e){return v.forEach(this.Fn(e),(n=>this.getIndexType(t,n).next((s=>{if(s===0||s===1){const i=new el(n).bn();if(i!=null)return this.addFieldIndex(t,i)}}))))}getDocumentsMatchingTarget(t,e){const n=Sn(t);let s=!0;const i=new Map;return v.forEach(this.Fn(e),(a=>this.Mn(t,a).next((u=>{s&&(s=!!u),i.set(a,u)})))).next((()=>{if(s){let a=G();const u=[];return v.forEach(i,((c,h)=>{N(rl,`Using index ${(function(B){return`id=${B.indexId}|cg=${B.collectionGroup}|f=${B.fields.map(($=>`${$.fieldPath}:${$.kind}`)).join(",")}`})(c)} to execute ${an(e)}`);const f=(function(B,$){const Y=ko($);if(Y===void 0)return null;for(const K of hi(B,Y.fieldPath))switch(K.op){case"array-contains-any":return K.value.arrayValue.values||[];case"array-contains":return[K.value]}return null})(h,c),m=(function(B,$){const Y=new Map;for(const K of We($))for(const T of hi(B,K.fieldPath))switch(T.op){case"==":case"in":Y.set(K.fieldPath.canonicalString(),T.value);break;case"not-in":case"!=":return Y.set(K.fieldPath.canonicalString(),T.value),Array.from(Y.values())}return null})(h,c),p=(function(B,$){const Y=[];let K=!0;for(const T of We($)){const _=T.kind===0?Fc(B,T.fieldPath,B.startAt):Oc(B,T.fieldPath,B.startAt);Y.push(_.value),K&&(K=_.inclusive)}return new Ne(Y,K)})(h,c),R=(function(B,$){const Y=[];let K=!0;for(const T of We($)){const _=T.kind===0?Oc(B,T.fieldPath,B.endAt):Fc(B,T.fieldPath,B.endAt);Y.push(_.value),K&&(K=_.inclusive)}return new Ne(Y,K)})(h,c),b=this.xn(c,h,p),D=this.xn(c,h,R),x=this.On(c,h,m),L=this.Nn(c.indexId,f,b,p.inclusive,D,R.inclusive,x);return v.forEach(L,(j=>n.H(j,e.limit).next((B=>{B.forEach(($=>{const Y=k.fromSegments($.documentKey);a.has(Y)||(a=a.add(Y),u.push(Y))}))}))))})).next((()=>u))}return v.resolve(null)}))}Fn(t){let e=this.Cn.get(t);return e||(t.filters.length===0?e=[t]:e=sp(tt.create(t.filters,"and")).map((n=>zo(t.path,t.collectionGroup,t.orderBy,n.getFilters(),t.limit,t.startAt,t.endAt))),this.Cn.set(t,e),e)}Nn(t,e,n,s,i,a,u){const c=(e!=null?e.length:1)*Math.max(n.length,i.length),h=c/(e!=null?e.length:1),f=[];for(let m=0;m<c;++m){const p=e?this.Bn(e[m/h]):Gs,R=this.Ln(t,p,n[m%h],s),b=this.kn(t,p,i[m%h],a),D=u.map((x=>this.Ln(t,p,x,!0)));f.push(...this.createRange(R,b,D))}return f}Ln(t,e,n,s){const i=new Ze(t,k.empty(),e,n);return s?i:i.En()}kn(t,e,n,s){const i=new Ze(t,k.empty(),e,n);return s?i.En():i}Mn(t,e){const n=new el(e),s=e.collectionGroup!=null?e.collectionGroup:e.path.lastSegment();return this.getFieldIndexes(t,s).next((i=>{let a=null;for(const u of i)n.pn(u)&&(!a||u.fields.length>a.fields.length)&&(a=u);return a}))}getIndexType(t,e){let n=2;const s=this.Fn(e);return v.forEach(s,(i=>this.Mn(t,i).next((a=>{a?n!==0&&a.fields.length<(function(c){let h=new et(ct.comparator),f=!1;for(const m of c.filters)for(const p of m.getFlattenedFilters())p.field.isKeyField()||(p.op==="array-contains"||p.op==="array-contains-any"?f=!0:h=h.add(p.field));for(const m of c.orderBy)m.field.isKeyField()||(h=h.add(m.field));return h.size+(f?1:0)})(i)&&(n=1):n=0})))).next((()=>(function(a){return a.limit!==null})(e)&&s.length>1&&n===2?1:n))}qn(t,e){const n=new Dr;for(const s of We(t)){const i=e.data.field(s.fieldPath);if(i==null)return null;const a=n.hn(s.kind);Ye.Ut.bt(i,a)}return n.an()}Bn(t){const e=new Dr;return Ye.Ut.bt(t,e.hn(0)),e.an()}Qn(t,e){const n=new Dr;return Ye.Ut.bt(on(this.databaseId,e),n.hn((function(i){const a=We(i);return a.length===0?0:a[a.length-1].kind})(t))),n.an()}On(t,e,n){if(n===null)return[];let s=[];s.push(new Dr);let i=0;for(const a of We(t)){const u=n[i++];for(const c of s)if(this.$n(e,a.fieldPath)&&ts(u))s=this.Un(s,a,u);else{const h=c.hn(a.kind);Ye.Ut.bt(u,h)}}return this.Kn(s)}xn(t,e,n){return this.On(t,e,n.position)}Kn(t){const e=[];for(let n=0;n<t.length;++n)e[n]=t[n].an();return e}Un(t,e,n){const s=[...t],i=[];for(const a of n.arrayValue.values||[])for(const u of s){const c=new Dr;c.seed(u.an()),Ye.Ut.bt(a,c.hn(e.kind)),i.push(c)}return i}$n(t,e){return!!t.filters.find((n=>n instanceof H&&n.field.isEqual(e)&&(n.op==="in"||n.op==="not-in")))}getFieldIndexes(t,e){const n=xr(t),s=bn(t);return(e?n.j(Oo,IDBKeyRange.bound(e,e)):n.j()).next((i=>{const a=[];return v.forEach(i,(u=>s.get([u.indexId,this.uid]).next((c=>{a.push((function(f,m){const p=m?new Bn(m.sequenceNumber,new $t(hn(m.readTime),new k(Yt(m.documentKey)),m.largestBatchId)):Bn.empty(),R=f.fields.map((([b,D])=>new en(ct.fromServerFormat(b),D)));return new qn(f.indexId,f.collectionGroup,R,p)})(u,c))})))).next((()=>a))}))}getNextCollectionGroupToUpdate(t){return this.getFieldIndexes(t).next((e=>e.length===0?null:(e.sort(((n,s)=>{const i=n.indexState.sequenceNumber-s.indexState.sequenceNumber;return i!==0?i:z(n.collectionGroup,s.collectionGroup)})),e[0].collectionGroup)))}updateCollectionGroup(t,e,n){const s=xr(t),i=bn(t);return this.Wn(t).next((a=>s.j(Oo,IDBKeyRange.bound(e,e)).next((u=>v.forEach(u,(c=>i.put(Hc(c.indexId,this.uid,a,n))))))))}updateIndexEntries(t,e){const n=new Map;return v.forEach(e,((s,i)=>{const a=n.get(s.collectionGroup);return(a?v.resolve(a):this.getFieldIndexes(t,s.collectionGroup)).next((u=>(n.set(s.collectionGroup,u),v.forEach(u,(c=>this.Gn(t,s,c).next((h=>{const f=this.zn(i,c);return h.isEqual(f)?v.resolve():this.jn(t,i,c,h,f)})))))))}))}Jn(t,e,n,s){return Sn(t).put(s.An(this.uid,this.Qn(n,e.key),e.key))}Hn(t,e,n,s){return Sn(t).delete(s.Rn(this.uid,this.Qn(n,e.key),e.key))}Gn(t,e,n){const s=Sn(t);let i=new et(Te);return s.X({index:hh,range:IDBKeyRange.only([n.indexId,this.uid,ri(this.Qn(n,e))])},((a,u)=>{i=i.add(new Ze(n.indexId,e,tl(u.arrayValue),tl(u.directionalValue)))})).next((()=>i))}zn(t,e){let n=new et(Te);const s=this.qn(e,t);if(s==null)return n;const i=ko(e);if(i!=null){const a=t.data.field(i.fieldPath);if(ts(a))for(const u of a.arrayValue.values||[])n=n.add(new Ze(e.indexId,t.key,this.Bn(u),s))}else n=n.add(new Ze(e.indexId,t.key,Gs,s));return n}jn(t,e,n,s,i){N(rl,"Updating index entries for document '%s'",e.key);const a=[];return(function(c,h,f,m,p){const R=c.getIterator(),b=h.getIterator();let D=Pn(R),x=Pn(b);for(;D||x;){let L=!1,j=!1;if(D&&x){const B=f(D,x);B<0?j=!0:B>0&&(L=!0)}else D!=null?j=!0:L=!0;L?(m(x),x=Pn(b)):j?(p(D),D=Pn(R)):(D=Pn(R),x=Pn(b))}})(s,i,Te,(u=>{a.push(this.Jn(t,e,n,u))}),(u=>{a.push(this.Hn(t,e,n,u))})),v.waitFor(a)}Wn(t){let e=1;return bn(t).X({index:lh,reverse:!0,range:IDBKeyRange.upperBound([this.uid,Number.MAX_SAFE_INTEGER])},((n,s,i)=>{i.done(),e=s.sequenceNumber+1})).next((()=>e))}createRange(t,e,n){n=n.sort(((a,u)=>Te(a,u))).filter(((a,u,c)=>!u||Te(a,c[u-1])!==0));const s=[];s.push(t);for(const a of n){const u=Te(a,t),c=Te(a,e);if(u===0)s[0]=t.En();else if(u>0&&c<0)s.push(a),s.push(a.En());else if(c>0)break}s.push(e);const i=[];for(let a=0;a<s.length;a+=2){if(this.Yn(s[a],s[a+1]))return[];const u=s[a].Rn(this.uid,Gs,k.empty()),c=s[a+1].Rn(this.uid,Gs,k.empty());i.push(IDBKeyRange.bound(u,c))}return i}Yn(t,e){return Te(t,e)>0}getMinOffsetFromCollectionGroup(t,e){return this.getFieldIndexes(t,e).next(il)}getMinOffset(t,e){return v.mapArray(this.Fn(e),(n=>this.Mn(t,n).next((s=>s||M(44426))))).next(il)}}function sl(r){return It(r,Xr)}function Sn(r){return It(r,jr)}function xr(r){return It(r,ha)}function bn(r){return It(r,Ur)}function il(r){q(r.length!==0,28825);let t=r[0].indexState.offset,e=t.largestBatchId;for(let n=1;n<r.length;n++){const s=r[n].indexState.offset;ua(s,t)<0&&(t=s),e<s.largestBatchId&&(e=s.largestBatchId)}return new $t(t.readTime,t.documentKey,e)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ol={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0},yd=41943040;class xt{static withCacheSize(t){return new xt(t,xt.DEFAULT_COLLECTION_PERCENTILE,xt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}constructor(t,e,n){this.cacheSizeCollectionThreshold=t,this.percentileToCollect=e,this.maximumSequenceNumbersToCollect=n}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Id(r,t,e){const n=r.store(Wt),s=r.store(Un),i=[],a=IDBKeyRange.only(e.batchId);let u=0;const c=n.X({range:a},((f,m,p)=>(u++,p.delete())));i.push(c.next((()=>{q(u===1,47070,{batchId:e.batchId})})));const h=[];for(const f of e.mutations){const m=ah(t,f.key.path,e.batchId);i.push(s.delete(m)),h.push(f.key)}return v.waitFor(i).next((()=>h))}function pi(r){if(!r)return 0;let t;if(r.document)t=r.document;else if(r.unknownDocument)t=r.unknownDocument;else{if(!r.noDocument)throw M(14731);t=r.noDocument}return JSON.stringify(t).length}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */xt.DEFAULT_COLLECTION_PERCENTILE=10,xt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,xt.DEFAULT=new xt(yd,xt.DEFAULT_COLLECTION_PERCENTILE,xt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),xt.DISABLED=new xt(-1,0,0);class Mi{constructor(t,e,n,s){this.userId=t,this.serializer=e,this.indexManager=n,this.referenceDelegate=s,this.Zn={}}static yt(t,e,n,s){q(t.uid!=="",64387);const i=t.isAuthenticated()?t.uid:"";return new Mi(i,e,n,s)}checkEmpty(t){let e=!0;const n=IDBKeyRange.bound([this.userId,Number.NEGATIVE_INFINITY],[this.userId,Number.POSITIVE_INFINITY]);return Ee(t).X({index:tn,range:n},((s,i,a)=>{e=!1,a.done()})).next((()=>e))}addMutationBatch(t,e,n,s){const i=kn(t),a=Ee(t);return a.add({}).next((u=>{q(typeof u=="number",49019);const c=new Ea(u,e,n,s),h=(function(R,b,D){const x=D.baseMutations.map((j=>rs(R.gt,j))),L=D.mutations.map((j=>rs(R.gt,j)));return{userId:b,batchId:D.batchId,localWriteTimeMs:D.localWriteTime.toMillis(),baseMutations:x,mutations:L}})(this.serializer,this.userId,c),f=[];let m=new et(((p,R)=>z(p.canonicalString(),R.canonicalString())));for(const p of s){const R=ah(this.userId,p.key.path,u);m=m.add(p.key.path.popLast()),f.push(a.put(h)),f.push(i.put(R,jm))}return m.forEach((p=>{f.push(this.indexManager.addToCollectionParentIndex(t,p))})),t.addOnCommittedListener((()=>{this.Zn[u]=c.keys()})),v.waitFor(f).next((()=>c))}))}lookupMutationBatch(t,e){return Ee(t).get(e).next((n=>n?(q(n.userId===this.userId,48,"Unexpected user for mutation batch",{userId:n.userId,batchId:e}),Je(this.serializer,n)):null))}Xn(t,e){return this.Zn[e]?v.resolve(this.Zn[e]):this.lookupMutationBatch(t,e).next((n=>{if(n){const s=n.keys();return this.Zn[e]=s,s}return null}))}getNextMutationBatchAfterBatchId(t,e){const n=e+1,s=IDBKeyRange.lowerBound([this.userId,n]);let i=null;return Ee(t).X({index:tn,range:s},((a,u,c)=>{u.userId===this.userId&&(q(u.batchId>=n,47524,{er:n}),i=Je(this.serializer,u)),c.done()})).next((()=>i))}getHighestUnacknowledgedBatchId(t){const e=IDBKeyRange.upperBound([this.userId,Number.POSITIVE_INFINITY]);let n=be;return Ee(t).X({index:tn,range:e,reverse:!0},((s,i,a)=>{n=i.batchId,a.done()})).next((()=>n))}getAllMutationBatches(t){const e=IDBKeyRange.bound([this.userId,be],[this.userId,Number.POSITIVE_INFINITY]);return Ee(t).j(tn,e).next((n=>n.map((s=>Je(this.serializer,s)))))}getAllMutationBatchesAffectingDocumentKey(t,e){const n=Xs(this.userId,e.path),s=IDBKeyRange.lowerBound(n),i=[];return kn(t).X({range:s},((a,u,c)=>{const[h,f,m]=a,p=Yt(f);if(h===this.userId&&e.path.isEqual(p))return Ee(t).get(m).next((R=>{if(!R)throw M(61480,{tr:a,batchId:m});q(R.userId===this.userId,10503,"Unexpected user for mutation batch",{userId:R.userId,batchId:m}),i.push(Je(this.serializer,R))}));c.done()})).next((()=>i))}getAllMutationBatchesAffectingDocumentKeys(t,e){let n=new et(z);const s=[];return e.forEach((i=>{const a=Xs(this.userId,i.path),u=IDBKeyRange.lowerBound(a),c=kn(t).X({range:u},((h,f,m)=>{const[p,R,b]=h,D=Yt(R);p===this.userId&&i.path.isEqual(D)?n=n.add(b):m.done()}));s.push(c)})),v.waitFor(s).next((()=>this.nr(t,n)))}getAllMutationBatchesAffectingQuery(t,e){const n=e.path,s=n.length+1,i=Xs(this.userId,n),a=IDBKeyRange.lowerBound(i);let u=new et(z);return kn(t).X({range:a},((c,h,f)=>{const[m,p,R]=c,b=Yt(p);m===this.userId&&n.isPrefixOf(b)?b.length===s&&(u=u.add(R)):f.done()})).next((()=>this.nr(t,u)))}nr(t,e){const n=[],s=[];return e.forEach((i=>{s.push(Ee(t).get(i).next((a=>{if(a===null)throw M(35274,{batchId:i});q(a.userId===this.userId,9748,"Unexpected user for mutation batch",{userId:a.userId,batchId:i}),n.push(Je(this.serializer,a))})))})),v.waitFor(s).next((()=>n))}removeMutationBatch(t,e){return Id(t.ce,this.userId,e).next((n=>(t.addOnCommittedListener((()=>{this.rr(e.batchId)})),v.forEach(n,(s=>this.referenceDelegate.markPotentiallyOrphaned(t,s))))))}rr(t){delete this.Zn[t]}performConsistencyCheck(t){return this.checkEmpty(t).next((e=>{if(!e)return v.resolve();const n=IDBKeyRange.lowerBound((function(a){return[a]})(this.userId)),s=[];return kn(t).X({range:n},((i,a,u)=>{if(i[0]===this.userId){const c=Yt(i[1]);s.push(c)}else u.done()})).next((()=>{q(s.length===0,56720,{ir:s.map((i=>i.canonicalString()))})}))}))}containsKey(t,e){return Td(t,this.userId,e)}sr(t){return Ed(t).get(this.userId).next((e=>e||{userId:this.userId,lastAcknowledgedBatchId:be,lastStreamToken:""}))}}function Td(r,t,e){const n=Xs(t,e.path),s=n[1],i=IDBKeyRange.lowerBound(n);let a=!1;return kn(r).X({range:i,Z:!0},((u,c,h)=>{const[f,m,p]=u;f===t&&m===s&&(a=!0),h.done()})).next((()=>a))}function Ee(r){return It(r,Wt)}function kn(r){return It(r,Un)}function Ed(r){return It(r,Wr)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dn{constructor(t){this._r=t}next(){return this._r+=2,this._r}static ar(){return new dn(0)}static ur(){return new dn(-1)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ap{constructor(t,e){this.referenceDelegate=t,this.serializer=e}allocateTargetId(t){return this.cr(t).next((e=>{const n=new dn(e.highestTargetId);return e.highestTargetId=n.next(),this.lr(t,e).next((()=>e.highestTargetId))}))}getLastRemoteSnapshotVersion(t){return this.cr(t).next((e=>U.fromTimestamp(new Z(e.lastRemoteSnapshotVersion.seconds,e.lastRemoteSnapshotVersion.nanoseconds))))}getHighestSequenceNumber(t){return this.cr(t).next((e=>e.highestListenSequenceNumber))}setTargetsMetadata(t,e,n){return this.cr(t).next((s=>(s.highestListenSequenceNumber=e,n&&(s.lastRemoteSnapshotVersion=n.toTimestamp()),e>s.highestListenSequenceNumber&&(s.highestListenSequenceNumber=e),this.lr(t,s))))}addTargetData(t,e){return this.hr(t,e).next((()=>this.cr(t).next((n=>(n.targetCount+=1,this.Pr(e,n),this.lr(t,n))))))}updateTargetData(t,e){return this.hr(t,e)}removeTargetData(t,e){return this.removeMatchingKeysForTargetId(t,e.targetId).next((()=>Cn(t).delete(e.targetId))).next((()=>this.cr(t))).next((n=>(q(n.targetCount>0,8065),n.targetCount-=1,this.lr(t,n))))}removeTargets(t,e,n){let s=0;const i=[];return Cn(t).X(((a,u)=>{const c=Lr(u);c.sequenceNumber<=e&&n.get(c.targetId)===null&&(s++,i.push(this.removeTargetData(t,c)))})).next((()=>v.waitFor(i))).next((()=>s))}forEachTarget(t,e){return Cn(t).X(((n,s)=>{const i=Lr(s);e(i)}))}cr(t){return al(t).get(ci).next((e=>(q(e!==null,2888),e)))}lr(t,e){return al(t).put(ci,e)}hr(t,e){return Cn(t).put(gd(this.serializer,e))}Pr(t,e){let n=!1;return t.targetId>e.highestTargetId&&(e.highestTargetId=t.targetId,n=!0),t.sequenceNumber>e.highestListenSequenceNumber&&(e.highestListenSequenceNumber=t.sequenceNumber,n=!0),n}getTargetCount(t){return this.cr(t).next((e=>e.targetCount))}getTargetData(t,e){const n=an(e),s=IDBKeyRange.bound([n,Number.NEGATIVE_INFINITY],[n,Number.POSITIVE_INFINITY]);let i=null;return Cn(t).X({range:s,index:ch},((a,u,c)=>{const h=Lr(u);ls(e,h.target)&&(i=h,c.done())})).next((()=>i))}addMatchingKeys(t,e,n){const s=[],i=Ae(t);return e.forEach((a=>{const u=Nt(a.path);s.push(i.put({targetId:n,path:u})),s.push(this.referenceDelegate.addReference(t,n,a))})),v.waitFor(s)}removeMatchingKeys(t,e,n){const s=Ae(t);return v.forEach(e,(i=>{const a=Nt(i.path);return v.waitFor([s.delete([n,a]),this.referenceDelegate.removeReference(t,n,i)])}))}removeMatchingKeysForTargetId(t,e){const n=Ae(t),s=IDBKeyRange.bound([e],[e+1],!1,!0);return n.delete(s)}getMatchingKeysForTargetId(t,e){const n=IDBKeyRange.bound([e],[e+1],!1,!0),s=Ae(t);let i=G();return s.X({range:n,Z:!0},((a,u,c)=>{const h=Yt(a[1]),f=new k(h);i=i.add(f)})).next((()=>i))}containsKey(t,e){const n=Nt(e.path),s=IDBKeyRange.bound([n],[Yl(n)],!1,!0);let i=0;return Ae(t).X({index:la,Z:!0,range:s},(([a,u],c,h)=>{a!==0&&(i++,h.done())})).next((()=>i>0))}Et(t,e){return Cn(t).get(e).next((n=>n?Lr(n):null))}}function Cn(r){return It(r,jn)}function al(r){return It(r,nn)}function Ae(r){return It(r,zn)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ul="LruGarbageCollector",wd=1048576;function cl([r,t],[e,n]){const s=z(r,e);return s===0?z(t,n):s}class up{constructor(t){this.Tr=t,this.buffer=new et(cl),this.Ir=0}dr(){return++this.Ir}Er(t){const e=[t,this.dr()];if(this.buffer.size<this.Tr)this.buffer=this.buffer.add(e);else{const n=this.buffer.last();cl(e,n)<0&&(this.buffer=this.buffer.delete(n).add(e))}}get maxValue(){return this.buffer.last()[0]}}class vd{constructor(t,e,n){this.garbageCollector=t,this.asyncQueue=e,this.localStore=n,this.Ar=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.Rr(6e4)}stop(){this.Ar&&(this.Ar.cancel(),this.Ar=null)}get started(){return this.Ar!==null}Rr(t){N(ul,`Garbage collection scheduled in ${t}ms`),this.Ar=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",t,(async()=>{this.Ar=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(e){Le(e)?N(ul,"Ignoring IndexedDB error during garbage collection: ",e):await Me(e)}await this.Rr(3e5)}))}}class cp{constructor(t,e){this.Vr=t,this.params=e}calculateTargetCount(t,e){return this.Vr.mr(t).next((n=>Math.floor(e/100*n)))}nthSequenceNumber(t,e){if(e===0)return v.resolve(Lt.ue);const n=new up(e);return this.Vr.forEachTarget(t,(s=>n.Er(s.sequenceNumber))).next((()=>this.Vr.gr(t,(s=>n.Er(s))))).next((()=>n.maxValue))}removeTargets(t,e,n){return this.Vr.removeTargets(t,e,n)}removeOrphanedDocuments(t,e){return this.Vr.removeOrphanedDocuments(t,e)}collect(t,e){return this.params.cacheSizeCollectionThreshold===-1?(N("LruGarbageCollector","Garbage collection skipped; disabled"),v.resolve(ol)):this.getCacheSize(t).next((n=>n<this.params.cacheSizeCollectionThreshold?(N("LruGarbageCollector",`Garbage collection skipped; Cache size ${n} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),ol):this.pr(t,e)))}getCacheSize(t){return this.Vr.getCacheSize(t)}pr(t,e){let n,s,i,a,u,c,h;const f=Date.now();return this.calculateTargetCount(t,this.params.percentileToCollect).next((m=>(m>this.params.maximumSequenceNumbersToCollect?(N("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${m}`),s=this.params.maximumSequenceNumbersToCollect):s=m,a=Date.now(),this.nthSequenceNumber(t,s)))).next((m=>(n=m,u=Date.now(),this.removeTargets(t,n,e)))).next((m=>(i=m,c=Date.now(),this.removeOrphanedDocuments(t,n)))).next((m=>(h=Date.now(),Dn()<=ue.DEBUG&&N("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${a-f}ms
	Determined least recently used ${s} in `+(u-a)+`ms
	Removed ${i} targets in `+(c-u)+`ms
	Removed ${m} documents in `+(h-c)+`ms
Total Duration: ${h-f}ms`),v.resolve({didRun:!0,sequenceNumbersCollected:s,targetsRemoved:i,documentsRemoved:m}))))}}function Ad(r,t){return new cp(r,t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lp{constructor(t,e){this.db=t,this.garbageCollector=Ad(this,e)}mr(t){const e=this.yr(t);return this.db.getTargetCache().getTargetCount(t).next((n=>e.next((s=>n+s))))}yr(t){let e=0;return this.gr(t,(n=>{e++})).next((()=>e))}forEachTarget(t,e){return this.db.getTargetCache().forEachTarget(t,e)}gr(t,e){return this.wr(t,((n,s)=>e(s)))}addReference(t,e,n){return Ks(t,n)}removeReference(t,e,n){return Ks(t,n)}removeTargets(t,e,n){return this.db.getTargetCache().removeTargets(t,e,n)}markPotentiallyOrphaned(t,e){return Ks(t,e)}Sr(t,e){return(function(s,i){let a=!1;return Ed(s).ee((u=>Td(s,u,i).next((c=>(c&&(a=!0),v.resolve(!c)))))).next((()=>a))})(t,e)}removeOrphanedDocuments(t,e){const n=this.db.getRemoteDocumentCache().newChangeBuffer(),s=[];let i=0;return this.wr(t,((a,u)=>{if(u<=e){const c=this.Sr(t,a).next((h=>{if(!h)return i++,n.getEntry(t,a).next((()=>(n.removeEntry(a,U.min()),Ae(t).delete((function(m){return[0,Nt(m.path)]})(a)))))}));s.push(c)}})).next((()=>v.waitFor(s))).next((()=>n.apply(t))).next((()=>i))}removeTarget(t,e){const n=e.withSequenceNumber(t.currentSequenceNumber);return this.db.getTargetCache().updateTargetData(t,n)}updateLimboDocument(t,e){return Ks(t,e)}wr(t,e){const n=Ae(t);let s,i=Lt.ue;return n.X({index:la},(([a,u],{path:c,sequenceNumber:h})=>{a===0?(i!==Lt.ue&&e(new k(Yt(s)),i),i=h,s=c):i=Lt.ue})).next((()=>{i!==Lt.ue&&e(new k(Yt(s)),i)}))}getCacheSize(t){return this.db.getRemoteDocumentCache().getSize(t)}}function Ks(r,t){return Ae(r).put((function(n,s){return{targetId:0,path:Nt(n.path),sequenceNumber:s}})(t,r.currentSequenceNumber))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rd{constructor(){this.changes=new fe((t=>t.toString()),((t,e)=>t.isEqual(e))),this.changesApplied=!1}addEntry(t){this.assertNotApplied(),this.changes.set(t.key,t)}removeEntry(t,e){this.assertNotApplied(),this.changes.set(t,at.newInvalidDocument(t).setReadTime(e))}getEntry(t,e){this.assertNotApplied();const n=this.changes.get(e);return n!==void 0?v.resolve(n):this.getFromCache(t,e)}getEntries(t,e){return this.getAllFromCache(t,e)}apply(t){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(t)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hp{constructor(t){this.serializer=t}setIndexManager(t){this.indexManager=t}addEntry(t,e,n){return Qe(t).put(n)}removeEntry(t,e,n){return Qe(t).delete((function(i,a){const u=i.path.toArray();return[u.slice(0,u.length-2),u[u.length-2],mi(a),u[u.length-1]]})(e,n))}updateMetadata(t,e){return this.getMetadata(t).next((n=>(n.byteSize+=e,this.br(t,n))))}getEntry(t,e){let n=at.newInvalidDocument(e);return Qe(t).X({index:Js,range:IDBKeyRange.only(Nr(e))},((s,i)=>{n=this.Dr(e,i)})).next((()=>n))}vr(t,e){let n={size:0,document:at.newInvalidDocument(e)};return Qe(t).X({index:Js,range:IDBKeyRange.only(Nr(e))},((s,i)=>{n={document:this.Dr(e,i),size:pi(i)}})).next((()=>n))}getEntries(t,e){let n=Bt();return this.Cr(t,e,((s,i)=>{const a=this.Dr(s,i);n=n.insert(s,a)})).next((()=>n))}Fr(t,e){let n=Bt(),s=new it(k.comparator);return this.Cr(t,e,((i,a)=>{const u=this.Dr(i,a);n=n.insert(i,u),s=s.insert(i,pi(a))})).next((()=>({documents:n,Mr:s})))}Cr(t,e,n){if(e.isEmpty())return v.resolve();let s=new et(dl);e.forEach((c=>s=s.add(c)));const i=IDBKeyRange.bound(Nr(s.first()),Nr(s.last())),a=s.getIterator();let u=a.getNext();return Qe(t).X({index:Js,range:i},((c,h,f)=>{const m=k.fromSegments([...h.prefixPath,h.collectionGroup,h.documentId]);for(;u&&dl(u,m)<0;)n(u,null),u=a.getNext();u&&u.isEqual(m)&&(n(u,h),u=a.hasNext()?a.getNext():null),u?f.G(Nr(u)):f.done()})).next((()=>{for(;u;)n(u,null),u=a.hasNext()?a.getNext():null}))}getDocumentsMatchingQuery(t,e,n,s,i){const a=e.path,u=[a.popLast().toArray(),a.lastSegment(),mi(n.readTime),n.documentKey.path.isEmpty()?"":n.documentKey.path.lastSegment()],c=[a.popLast().toArray(),a.lastSegment(),[Number.MAX_SAFE_INTEGER,Number.MAX_SAFE_INTEGER],""];return Qe(t).j(IDBKeyRange.bound(u,c,!0)).next((h=>{i?.incrementDocumentReadCount(h.length);let f=Bt();for(const m of h){const p=this.Dr(k.fromSegments(m.prefixPath.concat(m.collectionGroup,m.documentId)),m);p.isFoundDocument()&&(ds(e,p)||s.has(p.key))&&(f=f.insert(p.key,p))}return f}))}getAllFromCollectionGroup(t,e,n,s){let i=Bt();const a=hl(e,n),u=hl(e,$t.max());return Qe(t).X({index:uh,range:IDBKeyRange.bound(a,u,!0)},((c,h,f)=>{const m=this.Dr(k.fromSegments(h.prefixPath.concat(h.collectionGroup,h.documentId)),h);i=i.insert(m.key,m),i.size===s&&f.done()})).next((()=>i))}newChangeBuffer(t){return new dp(this,!!t&&t.trackRemovals)}getSize(t){return this.getMetadata(t).next((e=>e.byteSize))}getMetadata(t){return ll(t).get(Fo).next((e=>(q(!!e,20021),e)))}br(t,e){return ll(t).put(Fo,e)}Dr(t,e){if(e){const n=Jg(this.serializer,e);if(!(n.isNoDocument()&&n.version.isEqual(U.min())))return n}return at.newInvalidDocument(t)}}function Pd(r){return new hp(r)}class dp extends Rd{constructor(t,e){super(),this.Or=t,this.trackRemovals=e,this.Nr=new fe((n=>n.toString()),((n,s)=>n.isEqual(s)))}applyChanges(t){const e=[];let n=0,s=new et(((i,a)=>z(i.canonicalString(),a.canonicalString())));return this.changes.forEach(((i,a)=>{const u=this.Nr.get(i);if(e.push(this.Or.removeEntry(t,i,u.readTime)),a.isValidDocument()){const c=Qc(this.Or.serializer,a);s=s.add(i.path.popLast());const h=pi(c);n+=h-u.size,e.push(this.Or.addEntry(t,i,c))}else if(n-=u.size,this.trackRemovals){const c=Qc(this.Or.serializer,a.convertToNoDocument(U.min()));e.push(this.Or.addEntry(t,i,c))}})),s.forEach((i=>{e.push(this.Or.indexManager.addToCollectionParentIndex(t,i))})),e.push(this.Or.updateMetadata(t,n)),v.waitFor(e)}getFromCache(t,e){return this.Or.vr(t,e).next((n=>(this.Nr.set(e,{size:n.size,readTime:n.document.readTime}),n.document)))}getAllFromCache(t,e){return this.Or.Fr(t,e).next((({documents:n,Mr:s})=>(s.forEach(((i,a)=>{this.Nr.set(i,{size:a,readTime:n.get(i).readTime})})),n)))}}function ll(r){return It(r,Hr)}function Qe(r){return It(r,ui)}function Nr(r){const t=r.path.toArray();return[t.slice(0,t.length-2),t[t.length-2],t[t.length-1]]}function hl(r,t){const e=t.documentKey.path.toArray();return[r,mi(t.readTime),e.slice(0,e.length-2),e.length>0?e[e.length-1]:""]}function dl(r,t){const e=r.path.toArray(),n=t.path.toArray();let s=0;for(let i=0;i<e.length-2&&i<n.length-2;++i)if(s=z(e[i],n[i]),s)return s;return s=z(e.length,n.length),s||(s=z(e[e.length-2],n[n.length-2]),s||z(e[e.length-1],n[n.length-1]))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fp{constructor(t,e){this.overlayedDocument=t,this.mutatedFields=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vd{constructor(t,e,n,s){this.remoteDocumentCache=t,this.mutationQueue=e,this.documentOverlayCache=n,this.indexManager=s}getDocument(t,e){let n=null;return this.documentOverlayCache.getOverlay(t,e).next((s=>(n=s,this.remoteDocumentCache.getEntry(t,e)))).next((s=>(n!==null&&Kr(n.mutation,s,qt.empty(),Z.now()),s)))}getDocuments(t,e){return this.remoteDocumentCache.getEntries(t,e).next((n=>this.getLocalViewOfDocuments(t,n,G()).next((()=>n))))}getLocalViewOfDocuments(t,e,n=G()){const s=Zt();return this.populateOverlays(t,s,e).next((()=>this.computeViews(t,e,s,n).next((i=>{let a=Or();return i.forEach(((u,c)=>{a=a.insert(u,c.overlayedDocument)})),a}))))}getOverlayedDocuments(t,e){const n=Zt();return this.populateOverlays(t,n,e).next((()=>this.computeViews(t,e,n,G())))}populateOverlays(t,e,n){const s=[];return n.forEach((i=>{e.has(i)||s.push(i)})),this.documentOverlayCache.getOverlays(t,s).next((i=>{i.forEach(((a,u)=>{e.set(a,u)}))}))}computeViews(t,e,n,s){let i=Bt();const a=Gr(),u=(function(){return Gr()})();return e.forEach(((c,h)=>{const f=n.get(h.key);s.has(h.key)&&(f===void 0||f.mutation instanceof me)?i=i.insert(h.key,h):f!==void 0?(a.set(h.key,f.mutation.getFieldMask()),Kr(f.mutation,h,f.mutation.getFieldMask(),Z.now())):a.set(h.key,qt.empty())})),this.recalculateAndSaveOverlays(t,i).next((c=>(c.forEach(((h,f)=>a.set(h,f))),e.forEach(((h,f)=>{var m;return u.set(h,new fp(f,(m=a.get(h))!==null&&m!==void 0?m:null))})),u)))}recalculateAndSaveOverlays(t,e){const n=Gr();let s=new it(((a,u)=>a-u)),i=G();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(t,e).next((a=>{for(const u of a)u.keys().forEach((c=>{const h=e.get(c);if(h===null)return;let f=n.get(c)||qt.empty();f=u.applyToLocalView(h,f),n.set(c,f);const m=(s.get(u.batchId)||G()).add(c);s=s.insert(u.batchId,m)}))})).next((()=>{const a=[],u=s.getReverseIterator();for(;u.hasNext();){const c=u.getNext(),h=c.key,f=c.value,m=zh();f.forEach((p=>{if(!i.has(p)){const R=Xh(e.get(p),n.get(p));R!==null&&m.set(p,R),i=i.add(p)}})),a.push(this.documentOverlayCache.saveOverlays(t,h,m))}return v.waitFor(a)})).next((()=>n))}recalculateAndSaveOverlaysForDocumentKeys(t,e){return this.remoteDocumentCache.getEntries(t,e).next((n=>this.recalculateAndSaveOverlays(t,n)))}getDocumentsMatchingQuery(t,e,n,s){return(function(a){return k.isDocumentKey(a.path)&&a.collectionGroup===null&&a.filters.length===0})(e)?this.getDocumentsMatchingDocumentQuery(t,e.path):_a(e)?this.getDocumentsMatchingCollectionGroupQuery(t,e,n,s):this.getDocumentsMatchingCollectionQuery(t,e,n,s)}getNextDocuments(t,e,n,s){return this.remoteDocumentCache.getAllFromCollectionGroup(t,e,n,s).next((i=>{const a=s-i.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(t,e,n.largestBatchId,s-i.size):v.resolve(Zt());let u=Ln,c=i;return a.next((h=>v.forEach(h,((f,m)=>(u<m.largestBatchId&&(u=m.largestBatchId),i.get(f)?v.resolve():this.remoteDocumentCache.getEntry(t,f).next((p=>{c=c.insert(f,p)}))))).next((()=>this.populateOverlays(t,h,i))).next((()=>this.computeViews(t,c,h,G()))).next((f=>({batchId:u,changes:jh(f)})))))}))}getDocumentsMatchingDocumentQuery(t,e){return this.getDocument(t,new k(e)).next((n=>{let s=Or();return n.isFoundDocument()&&(s=s.insert(n.key,n)),s}))}getDocumentsMatchingCollectionGroupQuery(t,e,n,s){const i=e.collectionGroup;let a=Or();return this.indexManager.getCollectionParents(t,i).next((u=>v.forEach(u,(c=>{const h=(function(m,p){return new de(p,null,m.explicitOrderBy.slice(),m.filters.slice(),m.limit,m.limitType,m.startAt,m.endAt)})(e,c.child(i));return this.getDocumentsMatchingCollectionQuery(t,h,n,s).next((f=>{f.forEach(((m,p)=>{a=a.insert(m,p)}))}))})).next((()=>a))))}getDocumentsMatchingCollectionQuery(t,e,n,s){let i;return this.documentOverlayCache.getOverlaysForCollection(t,e.path,n.largestBatchId).next((a=>(i=a,this.remoteDocumentCache.getDocumentsMatchingQuery(t,e,n,i,s)))).next((a=>{i.forEach(((c,h)=>{const f=h.getKey();a.get(f)===null&&(a=a.insert(f,at.newInvalidDocument(f)))}));let u=Or();return a.forEach(((c,h)=>{const f=i.get(c);f!==void 0&&Kr(f.mutation,h,qt.empty(),Z.now()),ds(e,h)&&(u=u.insert(c,h))})),u}))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mp{constructor(t){this.serializer=t,this.Br=new Map,this.Lr=new Map}getBundleMetadata(t,e){return v.resolve(this.Br.get(e))}saveBundleMetadata(t,e){return this.Br.set(e.id,(function(s){return{id:s.id,version:s.version,createTime:gt(s.createTime)}})(e)),v.resolve()}getNamedQuery(t,e){return v.resolve(this.Lr.get(e))}saveNamedQuery(t,e){return this.Lr.set(e.name,(function(s){return{name:s.name,query:Fi(s.bundledQuery),readTime:gt(s.readTime)}})(e)),v.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gp{constructor(){this.overlays=new it(k.comparator),this.kr=new Map}getOverlay(t,e){return v.resolve(this.overlays.get(e))}getOverlays(t,e){const n=Zt();return v.forEach(e,(s=>this.getOverlay(t,s).next((i=>{i!==null&&n.set(s,i)})))).next((()=>n))}saveOverlays(t,e,n){return n.forEach(((s,i)=>{this.wt(t,e,i)})),v.resolve()}removeOverlaysForBatchId(t,e,n){const s=this.kr.get(n);return s!==void 0&&(s.forEach((i=>this.overlays=this.overlays.remove(i))),this.kr.delete(n)),v.resolve()}getOverlaysForCollection(t,e,n){const s=Zt(),i=e.length+1,a=new k(e.child("")),u=this.overlays.getIteratorFrom(a);for(;u.hasNext();){const c=u.getNext().value,h=c.getKey();if(!e.isPrefixOf(h.path))break;h.path.length===i&&c.largestBatchId>n&&s.set(c.getKey(),c)}return v.resolve(s)}getOverlaysForCollectionGroup(t,e,n,s){let i=new it(((h,f)=>h-f));const a=this.overlays.getIterator();for(;a.hasNext();){const h=a.getNext().value;if(h.getKey().getCollectionGroup()===e&&h.largestBatchId>n){let f=i.get(h.largestBatchId);f===null&&(f=Zt(),i=i.insert(h.largestBatchId,f)),f.set(h.getKey(),h)}}const u=Zt(),c=i.getIterator();for(;c.hasNext()&&(c.getNext().value.forEach(((h,f)=>u.set(h,f))),!(u.size()>=s)););return v.resolve(u)}wt(t,e,n){const s=this.overlays.get(n.key);if(s!==null){const a=this.kr.get(s.largestBatchId).delete(n.key);this.kr.set(s.largestBatchId,a)}this.overlays=this.overlays.insert(n.key,new va(e,n));let i=this.kr.get(e);i===void 0&&(i=G(),this.kr.set(e,i)),this.kr.set(e,i.add(n.key))}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pp{constructor(){this.sessionToken=ft.EMPTY_BYTE_STRING}getSessionToken(t){return v.resolve(this.sessionToken)}setSessionToken(t,e){return this.sessionToken=e,v.resolve()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sa{constructor(){this.qr=new et(Tt.Qr),this.$r=new et(Tt.Ur)}isEmpty(){return this.qr.isEmpty()}addReference(t,e){const n=new Tt(t,e);this.qr=this.qr.add(n),this.$r=this.$r.add(n)}Kr(t,e){t.forEach((n=>this.addReference(n,e)))}removeReference(t,e){this.Wr(new Tt(t,e))}Gr(t,e){t.forEach((n=>this.removeReference(n,e)))}zr(t){const e=new k(new Q([])),n=new Tt(e,t),s=new Tt(e,t+1),i=[];return this.$r.forEachInRange([n,s],(a=>{this.Wr(a),i.push(a.key)})),i}jr(){this.qr.forEach((t=>this.Wr(t)))}Wr(t){this.qr=this.qr.delete(t),this.$r=this.$r.delete(t)}Jr(t){const e=new k(new Q([])),n=new Tt(e,t),s=new Tt(e,t+1);let i=G();return this.$r.forEachInRange([n,s],(a=>{i=i.add(a.key)})),i}containsKey(t){const e=new Tt(t,0),n=this.qr.firstAfterOrEqual(e);return n!==null&&t.isEqual(n.key)}}class Tt{constructor(t,e){this.key=t,this.Hr=e}static Qr(t,e){return k.comparator(t.key,e.key)||z(t.Hr,e.Hr)}static Ur(t,e){return z(t.Hr,e.Hr)||k.comparator(t.key,e.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _p{constructor(t,e){this.indexManager=t,this.referenceDelegate=e,this.mutationQueue=[],this.er=1,this.Yr=new et(Tt.Qr)}checkEmpty(t){return v.resolve(this.mutationQueue.length===0)}addMutationBatch(t,e,n,s){const i=this.er;this.er++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const a=new Ea(i,e,n,s);this.mutationQueue.push(a);for(const u of s)this.Yr=this.Yr.add(new Tt(u.key,i)),this.indexManager.addToCollectionParentIndex(t,u.key.path.popLast());return v.resolve(a)}lookupMutationBatch(t,e){return v.resolve(this.Zr(e))}getNextMutationBatchAfterBatchId(t,e){const n=e+1,s=this.Xr(n),i=s<0?0:s;return v.resolve(this.mutationQueue.length>i?this.mutationQueue[i]:null)}getHighestUnacknowledgedBatchId(){return v.resolve(this.mutationQueue.length===0?be:this.er-1)}getAllMutationBatches(t){return v.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(t,e){const n=new Tt(e,0),s=new Tt(e,Number.POSITIVE_INFINITY),i=[];return this.Yr.forEachInRange([n,s],(a=>{const u=this.Zr(a.Hr);i.push(u)})),v.resolve(i)}getAllMutationBatchesAffectingDocumentKeys(t,e){let n=new et(z);return e.forEach((s=>{const i=new Tt(s,0),a=new Tt(s,Number.POSITIVE_INFINITY);this.Yr.forEachInRange([i,a],(u=>{n=n.add(u.Hr)}))})),v.resolve(this.ei(n))}getAllMutationBatchesAffectingQuery(t,e){const n=e.path,s=n.length+1;let i=n;k.isDocumentKey(i)||(i=i.child(""));const a=new Tt(new k(i),0);let u=new et(z);return this.Yr.forEachWhile((c=>{const h=c.key.path;return!!n.isPrefixOf(h)&&(h.length===s&&(u=u.add(c.Hr)),!0)}),a),v.resolve(this.ei(u))}ei(t){const e=[];return t.forEach((n=>{const s=this.Zr(n);s!==null&&e.push(s)})),e}removeMutationBatch(t,e){q(this.ti(e.batchId,"removed")===0,55003),this.mutationQueue.shift();let n=this.Yr;return v.forEach(e.mutations,(s=>{const i=new Tt(s.key,e.batchId);return n=n.delete(i),this.referenceDelegate.markPotentiallyOrphaned(t,s.key)})).next((()=>{this.Yr=n}))}rr(t){}containsKey(t,e){const n=new Tt(e,0),s=this.Yr.firstAfterOrEqual(n);return v.resolve(e.isEqual(s&&s.key))}performConsistencyCheck(t){return this.mutationQueue.length,v.resolve()}ti(t,e){return this.Xr(t)}Xr(t){return this.mutationQueue.length===0?0:t-this.mutationQueue[0].batchId}Zr(t){const e=this.Xr(t);return e<0||e>=this.mutationQueue.length?null:this.mutationQueue[e]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yp{constructor(t){this.ni=t,this.docs=(function(){return new it(k.comparator)})(),this.size=0}setIndexManager(t){this.indexManager=t}addEntry(t,e){const n=e.key,s=this.docs.get(n),i=s?s.size:0,a=this.ni(e);return this.docs=this.docs.insert(n,{document:e.mutableCopy(),size:a}),this.size+=a-i,this.indexManager.addToCollectionParentIndex(t,n.path.popLast())}removeEntry(t){const e=this.docs.get(t);e&&(this.docs=this.docs.remove(t),this.size-=e.size)}getEntry(t,e){const n=this.docs.get(e);return v.resolve(n?n.document.mutableCopy():at.newInvalidDocument(e))}getEntries(t,e){let n=Bt();return e.forEach((s=>{const i=this.docs.get(s);n=n.insert(s,i?i.document.mutableCopy():at.newInvalidDocument(s))})),v.resolve(n)}getDocumentsMatchingQuery(t,e,n,s){let i=Bt();const a=e.path,u=new k(a.child("__id-9223372036854775808__")),c=this.docs.getIteratorFrom(u);for(;c.hasNext();){const{key:h,value:{document:f}}=c.getNext();if(!a.isPrefixOf(h.path))break;h.path.length>a.length+1||ua(nh(f),n)<=0||(s.has(f.key)||ds(e,f))&&(i=i.insert(f.key,f.mutableCopy()))}return v.resolve(i)}getAllFromCollectionGroup(t,e,n,s){M(9500)}ri(t,e){return v.forEach(this.docs,(n=>e(n)))}newChangeBuffer(t){return new Ip(this)}getSize(t){return v.resolve(this.size)}}class Ip extends Rd{constructor(t){super(),this.Or=t}applyChanges(t){const e=[];return this.changes.forEach(((n,s)=>{s.isValidDocument()?e.push(this.Or.addEntry(t,s)):this.Or.removeEntry(n)})),v.waitFor(e)}getFromCache(t,e){return this.Or.getEntry(t,e)}getAllFromCache(t,e){return this.Or.getEntries(t,e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tp{constructor(t){this.persistence=t,this.ii=new fe((e=>an(e)),ls),this.lastRemoteSnapshotVersion=U.min(),this.highestTargetId=0,this.si=0,this.oi=new Sa,this.targetCount=0,this._i=dn.ar()}forEachTarget(t,e){return this.ii.forEach(((n,s)=>e(s))),v.resolve()}getLastRemoteSnapshotVersion(t){return v.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(t){return v.resolve(this.si)}allocateTargetId(t){return this.highestTargetId=this._i.next(),v.resolve(this.highestTargetId)}setTargetsMetadata(t,e,n){return n&&(this.lastRemoteSnapshotVersion=n),e>this.si&&(this.si=e),v.resolve()}hr(t){this.ii.set(t.target,t);const e=t.targetId;e>this.highestTargetId&&(this._i=new dn(e),this.highestTargetId=e),t.sequenceNumber>this.si&&(this.si=t.sequenceNumber)}addTargetData(t,e){return this.hr(e),this.targetCount+=1,v.resolve()}updateTargetData(t,e){return this.hr(e),v.resolve()}removeTargetData(t,e){return this.ii.delete(e.target),this.oi.zr(e.targetId),this.targetCount-=1,v.resolve()}removeTargets(t,e,n){let s=0;const i=[];return this.ii.forEach(((a,u)=>{u.sequenceNumber<=e&&n.get(u.targetId)===null&&(this.ii.delete(a),i.push(this.removeMatchingKeysForTargetId(t,u.targetId)),s++)})),v.waitFor(i).next((()=>s))}getTargetCount(t){return v.resolve(this.targetCount)}getTargetData(t,e){const n=this.ii.get(e)||null;return v.resolve(n)}addMatchingKeys(t,e,n){return this.oi.Kr(e,n),v.resolve()}removeMatchingKeys(t,e,n){this.oi.Gr(e,n);const s=this.persistence.referenceDelegate,i=[];return s&&e.forEach((a=>{i.push(s.markPotentiallyOrphaned(t,a))})),v.waitFor(i)}removeMatchingKeysForTargetId(t,e){return this.oi.zr(e),v.resolve()}getMatchingKeysForTargetId(t,e){const n=this.oi.Jr(e);return v.resolve(n)}containsKey(t,e){return v.resolve(this.oi.containsKey(e))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ba{constructor(t,e){this.ai={},this.overlays={},this.ui=new Lt(0),this.ci=!1,this.ci=!0,this.li=new pp,this.referenceDelegate=t(this),this.hi=new Tp(this),this.indexManager=new ip,this.remoteDocumentCache=(function(s){return new yp(s)})((n=>this.referenceDelegate.Pi(n))),this.serializer=new md(e),this.Ti=new mp(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.ci=!1,Promise.resolve()}get started(){return this.ci}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(t){return this.indexManager}getDocumentOverlayCache(t){let e=this.overlays[t.toKey()];return e||(e=new gp,this.overlays[t.toKey()]=e),e}getMutationQueue(t,e){let n=this.ai[t.toKey()];return n||(n=new _p(e,this.referenceDelegate),this.ai[t.toKey()]=n),n}getGlobalsCache(){return this.li}getTargetCache(){return this.hi}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.Ti}runTransaction(t,e,n){N("MemoryPersistence","Starting transaction:",t);const s=new Ep(this.ui.next());return this.referenceDelegate.Ii(),n(s).next((i=>this.referenceDelegate.di(s).next((()=>i)))).toPromise().then((i=>(s.raiseOnCommittedEvent(),i)))}Ei(t,e){return v.or(Object.values(this.ai).map((n=>()=>n.containsKey(t,e))))}}class Ep extends sh{constructor(t){super(),this.currentSequenceNumber=t}}class Li{constructor(t){this.persistence=t,this.Ai=new Sa,this.Ri=null}static Vi(t){return new Li(t)}get mi(){if(this.Ri)return this.Ri;throw M(60996)}addReference(t,e,n){return this.Ai.addReference(n,e),this.mi.delete(n.toString()),v.resolve()}removeReference(t,e,n){return this.Ai.removeReference(n,e),this.mi.add(n.toString()),v.resolve()}markPotentiallyOrphaned(t,e){return this.mi.add(e.toString()),v.resolve()}removeTarget(t,e){this.Ai.zr(e.targetId).forEach((s=>this.mi.add(s.toString())));const n=this.persistence.getTargetCache();return n.getMatchingKeysForTargetId(t,e.targetId).next((s=>{s.forEach((i=>this.mi.add(i.toString())))})).next((()=>n.removeTargetData(t,e)))}Ii(){this.Ri=new Set}di(t){const e=this.persistence.getRemoteDocumentCache().newChangeBuffer();return v.forEach(this.mi,(n=>{const s=k.fromPath(n);return this.fi(t,s).next((i=>{i||e.removeEntry(s,U.min())}))})).next((()=>(this.Ri=null,e.apply(t))))}updateLimboDocument(t,e){return this.fi(t,e).next((n=>{n?this.mi.delete(e.toString()):this.mi.add(e.toString())}))}Pi(t){return 0}fi(t,e){return v.or([()=>v.resolve(this.Ai.containsKey(e)),()=>this.persistence.getTargetCache().containsKey(t,e),()=>this.persistence.Ei(t,e)])}}class _i{constructor(t,e){this.persistence=t,this.gi=new fe((n=>Nt(n.path)),((n,s)=>n.isEqual(s))),this.garbageCollector=Ad(this,e)}static Vi(t,e){return new _i(t,e)}Ii(){}di(t){return v.resolve()}forEachTarget(t,e){return this.persistence.getTargetCache().forEachTarget(t,e)}mr(t){const e=this.yr(t);return this.persistence.getTargetCache().getTargetCount(t).next((n=>e.next((s=>n+s))))}yr(t){let e=0;return this.gr(t,(n=>{e++})).next((()=>e))}gr(t,e){return v.forEach(this.gi,((n,s)=>this.Sr(t,n,s).next((i=>i?v.resolve():e(s)))))}removeTargets(t,e,n){return this.persistence.getTargetCache().removeTargets(t,e,n)}removeOrphanedDocuments(t,e){let n=0;const s=this.persistence.getRemoteDocumentCache(),i=s.newChangeBuffer();return s.ri(t,(a=>this.Sr(t,a,e).next((u=>{u||(n++,i.removeEntry(a,U.min()))})))).next((()=>i.apply(t))).next((()=>n))}markPotentiallyOrphaned(t,e){return this.gi.set(e,t.currentSequenceNumber),v.resolve()}removeTarget(t,e){const n=e.withSequenceNumber(t.currentSequenceNumber);return this.persistence.getTargetCache().updateTargetData(t,n)}addReference(t,e,n){return this.gi.set(n,t.currentSequenceNumber),v.resolve()}removeReference(t,e,n){return this.gi.set(n,t.currentSequenceNumber),v.resolve()}updateLimboDocument(t,e){return this.gi.set(e,t.currentSequenceNumber),v.resolve()}Pi(t){let e=t.key.toString().length;return t.isFoundDocument()&&(e+=Zs(t.data.value)),e}Sr(t,e,n){return v.or([()=>this.persistence.Ei(t,e),()=>this.persistence.getTargetCache().containsKey(t,e),()=>{const s=this.gi.get(e);return v.resolve(s!==void 0&&s>n)}])}getCacheSize(t){return this.persistence.getRemoteDocumentCache().getSize(t)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wp{constructor(t){this.serializer=t}q(t,e,n,s){const i=new Ai("createOrUpgrade",e);n<1&&s>=1&&((function(c){c.createObjectStore(cs)})(t),(function(c){c.createObjectStore(Wr,{keyPath:Um}),c.createObjectStore(Wt,{keyPath:vc,autoIncrement:!0}).createIndex(tn,Ac,{unique:!0}),c.createObjectStore(Un)})(t),fl(t),(function(c){c.createObjectStore(He)})(t));let a=v.resolve();return n<3&&s>=3&&(n!==0&&((function(c){c.deleteObjectStore(zn),c.deleteObjectStore(jn),c.deleteObjectStore(nn)})(t),fl(t)),a=a.next((()=>(function(c){const h=c.store(nn),f={highestTargetId:0,highestListenSequenceNumber:0,lastRemoteSnapshotVersion:U.min().toTimestamp(),targetCount:0};return h.put(ci,f)})(i)))),n<4&&s>=4&&(n!==0&&(a=a.next((()=>(function(c,h){return h.store(Wt).j().next((m=>{c.deleteObjectStore(Wt),c.createObjectStore(Wt,{keyPath:vc,autoIncrement:!0}).createIndex(tn,Ac,{unique:!0});const p=h.store(Wt),R=m.map((b=>p.put(b)));return v.waitFor(R)}))})(t,i)))),a=a.next((()=>{(function(c){c.createObjectStore(Gn,{keyPath:Xm})})(t)}))),n<5&&s>=5&&(a=a.next((()=>this.pi(i)))),n<6&&s>=6&&(a=a.next((()=>((function(c){c.createObjectStore(Hr)})(t),this.yi(i))))),n<7&&s>=7&&(a=a.next((()=>this.wi(i)))),n<8&&s>=8&&(a=a.next((()=>this.Si(t,i)))),n<9&&s>=9&&(a=a.next((()=>{(function(c){c.objectStoreNames.contains("remoteDocumentChanges")&&c.deleteObjectStore("remoteDocumentChanges")})(t)}))),n<10&&s>=10&&(a=a.next((()=>this.bi(i)))),n<11&&s>=11&&(a=a.next((()=>{(function(c){c.createObjectStore(Ri,{keyPath:Jm})})(t),(function(c){c.createObjectStore(Pi,{keyPath:Ym})})(t)}))),n<12&&s>=12&&(a=a.next((()=>{(function(c){const h=c.createObjectStore(Vi,{keyPath:ig});h.createIndex(Mo,og,{unique:!1}),h.createIndex(dh,ag,{unique:!1})})(t)}))),n<13&&s>=13&&(a=a.next((()=>(function(c){const h=c.createObjectStore(ui,{keyPath:zm});h.createIndex(Js,Gm),h.createIndex(uh,Km)})(t))).next((()=>this.Di(t,i))).next((()=>t.deleteObjectStore(He)))),n<14&&s>=14&&(a=a.next((()=>this.Ci(t,i)))),n<15&&s>=15&&(a=a.next((()=>(function(c){c.createObjectStore(ha,{keyPath:Zm,autoIncrement:!0}).createIndex(Oo,tg,{unique:!1}),c.createObjectStore(Ur,{keyPath:eg}).createIndex(lh,ng,{unique:!1}),c.createObjectStore(jr,{keyPath:rg}).createIndex(hh,sg,{unique:!1})})(t)))),n<16&&s>=16&&(a=a.next((()=>{e.objectStore(Ur).clear()})).next((()=>{e.objectStore(jr).clear()}))),n<17&&s>=17&&(a=a.next((()=>{(function(c){c.createObjectStore(da,{keyPath:ug})})(t)}))),n<18&&s>=18&&zl()&&(a=a.next((()=>{e.objectStore(Ur).clear()})).next((()=>{e.objectStore(jr).clear()}))),a}yi(t){let e=0;return t.store(He).X(((n,s)=>{e+=pi(s)})).next((()=>{const n={byteSize:e};return t.store(Hr).put(Fo,n)}))}pi(t){const e=t.store(Wr),n=t.store(Wt);return e.j().next((s=>v.forEach(s,(i=>{const a=IDBKeyRange.bound([i.userId,be],[i.userId,i.lastAcknowledgedBatchId]);return n.j(tn,a).next((u=>v.forEach(u,(c=>{q(c.userId===i.userId,18650,"Cannot process batch from unexpected user",{batchId:c.batchId});const h=Je(this.serializer,c);return Id(t,i.userId,h).next((()=>{}))}))))}))))}wi(t){const e=t.store(zn),n=t.store(He);return t.store(nn).get(ci).next((s=>{const i=[];return n.X(((a,u)=>{const c=new Q(a),h=(function(m){return[0,Nt(m)]})(c);i.push(e.get(h).next((f=>f?v.resolve():(m=>e.put({targetId:0,path:Nt(m),sequenceNumber:s.highestListenSequenceNumber}))(c))))})).next((()=>v.waitFor(i)))}))}Si(t,e){t.createObjectStore(Xr,{keyPath:Hm});const n=e.store(Xr),s=new Va,i=a=>{if(s.add(a)){const u=a.lastSegment(),c=a.popLast();return n.put({collectionId:u,parent:Nt(c)})}};return e.store(He).X({Z:!0},((a,u)=>{const c=new Q(a);return i(c.popLast())})).next((()=>e.store(Un).X({Z:!0},(([a,u,c],h)=>{const f=Yt(u);return i(f.popLast())}))))}bi(t){const e=t.store(jn);return e.X(((n,s)=>{const i=Lr(s),a=gd(this.serializer,i);return e.put(a)}))}Di(t,e){const n=e.store(He),s=[];return n.X(((i,a)=>{const u=e.store(ui),c=(function(m){return m.document?new k(Q.fromString(m.document.name).popFirst(5)):m.noDocument?k.fromSegments(m.noDocument.path):m.unknownDocument?k.fromSegments(m.unknownDocument.path):M(36783)})(a).path.toArray(),h={prefixPath:c.slice(0,c.length-2),collectionGroup:c[c.length-2],documentId:c[c.length-1],readTime:a.readTime||[0,0],unknownDocument:a.unknownDocument,noDocument:a.noDocument,document:a.document,hasCommittedMutations:!!a.hasCommittedMutations};s.push(u.put(h))})).next((()=>v.waitFor(s)))}Ci(t,e){const n=e.store(Wt),s=Pd(this.serializer),i=new ba(Li.Vi,this.serializer.gt);return n.j().next((a=>{const u=new Map;return a.forEach((c=>{var h;let f=(h=u.get(c.userId))!==null&&h!==void 0?h:G();Je(this.serializer,c).keys().forEach((m=>f=f.add(m))),u.set(c.userId,f)})),v.forEach(u,((c,h)=>{const f=new Et(h),m=Oi.yt(this.serializer,f),p=i.getIndexManager(f),R=Mi.yt(f,this.serializer,p,i.referenceDelegate);return new Vd(s,R,m,p).recalculateAndSaveOverlaysForDocumentKeys(new Lo(e,Lt.ue),c).next()}))}))}}function fl(r){r.createObjectStore(zn,{keyPath:Qm}).createIndex(la,Wm,{unique:!0}),r.createObjectStore(jn,{keyPath:"targetId"}).createIndex(ch,$m,{unique:!0}),r.createObjectStore(nn)}const we="IndexedDbPersistence",vo=18e5,Ao=5e3,Ro="Failed to obtain exclusive access to the persistence layer. To allow shared access, multi-tab synchronization has to be enabled in all tabs. If you are using `experimentalForceOwningTab:true`, make sure that only one tab has persistence enabled at any given time.",Sd="main";class Ca{constructor(t,e,n,s,i,a,u,c,h,f,m=18){if(this.allowTabSynchronization=t,this.persistenceKey=e,this.clientId=n,this.Fi=i,this.window=a,this.document=u,this.Mi=h,this.xi=f,this.Oi=m,this.ui=null,this.ci=!1,this.isPrimary=!1,this.networkEnabled=!0,this.Ni=null,this.inForeground=!1,this.Bi=null,this.Li=null,this.ki=Number.NEGATIVE_INFINITY,this.qi=p=>Promise.resolve(),!Ca.C())throw new C(P.UNIMPLEMENTED,"This platform is either missing IndexedDB or is known to have an incomplete implementation. Offline persistence has been disabled.");this.referenceDelegate=new lp(this,s),this.Qi=e+Sd,this.serializer=new md(c),this.$i=new te(this.Qi,this.Oi,new wp(this.serializer)),this.li=new Zg,this.hi=new ap(this.referenceDelegate,this.serializer),this.remoteDocumentCache=Pd(this.serializer),this.Ti=new Yg,this.window&&this.window.localStorage?this.Ui=this.window.localStorage:(this.Ui=null,f===!1&&mt(we,"LocalStorage is unavailable. As a result, persistence may not work reliably. In particular enablePersistence() could fail immediately after refreshing the page."))}start(){return this.Ki().then((()=>{if(!this.isPrimary&&!this.allowTabSynchronization)throw new C(P.FAILED_PRECONDITION,Ro);return this.Wi(),this.Gi(),this.zi(),this.runTransaction("getHighestListenSequenceNumber","readonly",(t=>this.hi.getHighestSequenceNumber(t)))})).then((t=>{this.ui=new Lt(t,this.Mi)})).then((()=>{this.ci=!0})).catch((t=>(this.$i&&this.$i.close(),Promise.reject(t))))}ji(t){return this.qi=async e=>{if(this.started)return t(e)},t(this.isPrimary)}setDatabaseDeletedListener(t){this.$i.setDatabaseDeletedListener(t)}setNetworkEnabled(t){this.networkEnabled!==t&&(this.networkEnabled=t,this.Fi.enqueueAndForget((async()=>{this.started&&await this.Ki()})))}Ki(){return this.runTransaction("updateClientMetadataAndTryBecomePrimary","readwrite",(t=>$s(t).put({clientId:this.clientId,updateTimeMs:Date.now(),networkEnabled:this.networkEnabled,inForeground:this.inForeground}).next((()=>{if(this.isPrimary)return this.Ji(t).next((e=>{e||(this.isPrimary=!1,this.Fi.enqueueRetryable((()=>this.qi(!1))))}))})).next((()=>this.Hi(t))).next((e=>this.isPrimary&&!e?this.Yi(t).next((()=>!1)):!!e&&this.Zi(t).next((()=>!0)))))).catch((t=>{if(Le(t))return N(we,"Failed to extend owner lease: ",t),this.isPrimary;if(!this.allowTabSynchronization)throw t;return N(we,"Releasing owner lease after error during lease refresh",t),!1})).then((t=>{this.isPrimary!==t&&this.Fi.enqueueRetryable((()=>this.qi(t))),this.isPrimary=t}))}Ji(t){return kr(t).get(Rn).next((e=>v.resolve(this.Xi(e))))}es(t){return $s(t).delete(this.clientId)}async ts(){if(this.isPrimary&&!this.ns(this.ki,vo)){this.ki=Date.now();const t=await this.runTransaction("maybeGarbageCollectMultiClientState","readwrite-primary",(e=>{const n=It(e,Gn);return n.j().next((s=>{const i=this.rs(s,vo),a=s.filter((u=>i.indexOf(u)===-1));return v.forEach(a,(u=>n.delete(u.clientId))).next((()=>a))}))})).catch((()=>[]));if(this.Ui)for(const e of t)this.Ui.removeItem(this.ss(e.clientId))}}zi(){this.Li=this.Fi.enqueueAfterDelay("client_metadata_refresh",4e3,(()=>this.Ki().then((()=>this.ts())).then((()=>this.zi()))))}Xi(t){return!!t&&t.ownerId===this.clientId}Hi(t){return this.xi?v.resolve(!0):kr(t).get(Rn).next((e=>{if(e!==null&&this.ns(e.leaseTimestampMs,Ao)&&!this._s(e.ownerId)){if(this.Xi(e)&&this.networkEnabled)return!0;if(!this.Xi(e)){if(!e.allowTabSynchronization)throw new C(P.FAILED_PRECONDITION,Ro);return!1}}return!(!this.networkEnabled||!this.inForeground)||$s(t).j().next((n=>this.rs(n,Ao).find((s=>{if(this.clientId!==s.clientId){const i=!this.networkEnabled&&s.networkEnabled,a=!this.inForeground&&s.inForeground,u=this.networkEnabled===s.networkEnabled;if(i||a&&u)return!0}return!1}))===void 0))})).next((e=>(this.isPrimary!==e&&N(we,`Client ${e?"is":"is not"} eligible for a primary lease.`),e)))}async shutdown(){this.ci=!1,this.us(),this.Li&&(this.Li.cancel(),this.Li=null),this.cs(),this.ls(),await this.$i.runTransaction("shutdown","readwrite",[cs,Gn],(t=>{const e=new Lo(t,Lt.ue);return this.Yi(e).next((()=>this.es(e)))})),this.$i.close(),this.hs()}rs(t,e){return t.filter((n=>this.ns(n.updateTimeMs,e)&&!this._s(n.clientId)))}Ps(){return this.runTransaction("getActiveClients","readonly",(t=>$s(t).j().next((e=>this.rs(e,vo).map((n=>n.clientId))))))}get started(){return this.ci}getGlobalsCache(){return this.li}getMutationQueue(t,e){return Mi.yt(t,this.serializer,e,this.referenceDelegate)}getTargetCache(){return this.hi}getRemoteDocumentCache(){return this.remoteDocumentCache}getIndexManager(t){return new op(t,this.serializer.gt.databaseId)}getDocumentOverlayCache(t){return Oi.yt(this.serializer,t)}getBundleCache(){return this.Ti}runTransaction(t,e,n){N(we,"Starting transaction:",t);const s=e==="readonly"?"readonly":"readwrite",i=(function(c){return c===18?hg:c===17?ph:c===16?lg:c===15?fa:c===14?gh:c===13?mh:c===12?cg:c===11?fh:void M(60245)})(this.Oi);let a;return this.$i.runTransaction(t,s,i,(u=>(a=new Lo(u,this.ui?this.ui.next():Lt.ue),e==="readwrite-primary"?this.Ji(a).next((c=>!!c||this.Hi(a))).next((c=>{if(!c)throw mt(`Failed to obtain primary lease for action '${t}'.`),this.isPrimary=!1,this.Fi.enqueueRetryable((()=>this.qi(!1))),new C(P.FAILED_PRECONDITION,rh);return n(a)})).next((c=>this.Zi(a).next((()=>c)))):this.Ts(a).next((()=>n(a)))))).then((u=>(a.raiseOnCommittedEvent(),u)))}Ts(t){return kr(t).get(Rn).next((e=>{if(e!==null&&this.ns(e.leaseTimestampMs,Ao)&&!this._s(e.ownerId)&&!this.Xi(e)&&!(this.xi||this.allowTabSynchronization&&e.allowTabSynchronization))throw new C(P.FAILED_PRECONDITION,Ro)}))}Zi(t){const e={ownerId:this.clientId,allowTabSynchronization:this.allowTabSynchronization,leaseTimestampMs:Date.now()};return kr(t).put(Rn,e)}static C(){return te.C()}Yi(t){const e=kr(t);return e.get(Rn).next((n=>this.Xi(n)?(N(we,"Releasing primary lease."),e.delete(Rn)):v.resolve()))}ns(t,e){const n=Date.now();return!(t<n-e)&&(!(t>n)||(mt(`Detected an update time that is in the future: ${t} > ${n}`),!1))}Wi(){this.document!==null&&typeof this.document.addEventListener=="function"&&(this.Bi=()=>{this.Fi.enqueueAndForget((()=>(this.inForeground=this.document.visibilityState==="visible",this.Ki())))},this.document.addEventListener("visibilitychange",this.Bi),this.inForeground=this.document.visibilityState==="visible")}cs(){this.Bi&&(this.document.removeEventListener("visibilitychange",this.Bi),this.Bi=null)}Gi(){var t;typeof((t=this.window)===null||t===void 0?void 0:t.addEventListener)=="function"&&(this.Ni=()=>{this.us();const e=/(?:Version|Mobile)\/1[456]/;jl()&&(navigator.appVersion.match(e)||navigator.userAgent.match(e))&&this.Fi.enterRestrictedMode(!0),this.Fi.enqueueAndForget((()=>this.shutdown()))},this.window.addEventListener("pagehide",this.Ni))}ls(){this.Ni&&(this.window.removeEventListener("pagehide",this.Ni),this.Ni=null)}_s(t){var e;try{const n=((e=this.Ui)===null||e===void 0?void 0:e.getItem(this.ss(t)))!==null;return N(we,`Client '${t}' ${n?"is":"is not"} zombied in LocalStorage`),n}catch(n){return mt(we,"Failed to get zombied client id.",n),!1}}us(){if(this.Ui)try{this.Ui.setItem(this.ss(this.clientId),String(Date.now()))}catch(t){mt("Failed to set zombie client id.",t)}}hs(){if(this.Ui)try{this.Ui.removeItem(this.ss(this.clientId))}catch{}}ss(t){return`firestore_zombie_${this.persistenceKey}_${t}`}}function kr(r){return It(r,cs)}function $s(r){return It(r,Gn)}function Da(r,t){let e=r.projectId;return r.isDefaultDatabase||(e+="."+r.database),"firestore/"+t+"/"+e+"/"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xa{constructor(t,e,n,s){this.targetId=t,this.fromCache=e,this.Is=n,this.ds=s}static Es(t,e){let n=G(),s=G();for(const i of e.docChanges)switch(i.type){case 0:n=n.add(i.doc.key);break;case 1:s=s.add(i.doc.key)}return new xa(t,e.fromCache,n,s)}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vp{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(t){this._documentReadCount+=t}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bd{constructor(){this.As=!1,this.Rs=!1,this.Vs=100,this.fs=(function(){return jl()?8:ih(oi())>0?6:4})()}initialize(t,e){this.gs=t,this.indexManager=e,this.As=!0}getDocumentsMatchingQuery(t,e,n,s){const i={result:null};return this.ps(t,e).next((a=>{i.result=a})).next((()=>{if(!i.result)return this.ys(t,e,s,n).next((a=>{i.result=a}))})).next((()=>{if(i.result)return;const a=new vp;return this.ws(t,e,a).next((u=>{if(i.result=u,this.Rs)return this.Ss(t,e,a,u.size)}))})).next((()=>i.result))}Ss(t,e,n,s){return n.documentReadCount<this.Vs?(Dn()<=ue.DEBUG&&N("QueryEngine","SDK will not create cache indexes for query:",xn(e),"since it only creates cache indexes for collection contains","more than or equal to",this.Vs,"documents"),v.resolve()):(Dn()<=ue.DEBUG&&N("QueryEngine","Query:",xn(e),"scans",n.documentReadCount,"local documents and returns",s,"documents as results."),n.documentReadCount>this.fs*s?(Dn()<=ue.DEBUG&&N("QueryEngine","The SDK decides to create cache indexes for query:",xn(e),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(t,kt(e))):v.resolve())}ps(t,e){if(Mc(e))return v.resolve(null);let n=kt(e);return this.indexManager.getIndexType(t,n).next((s=>s===0?null:(e.limit!==null&&s===1&&(e=di(e,null,"F"),n=kt(e)),this.indexManager.getDocumentsMatchingTarget(t,n).next((i=>{const a=G(...i);return this.gs.getDocuments(t,a).next((u=>this.indexManager.getMinOffset(t,n).next((c=>{const h=this.bs(e,u);return this.Ds(e,h,a,c.readTime)?this.ps(t,di(e,null,"F")):this.vs(t,h,e,c)}))))})))))}ys(t,e,n,s){return Mc(e)||s.isEqual(U.min())?v.resolve(null):this.gs.getDocuments(t,n).next((i=>{const a=this.bs(e,i);return this.Ds(e,a,n,s)?v.resolve(null):(Dn()<=ue.DEBUG&&N("QueryEngine","Re-using previous result from %s to execute query: %s",s.toString(),xn(e)),this.vs(t,a,e,eh(s,Ln)).next((u=>u)))}))}bs(t,e){let n=new et(Bh(t));return e.forEach(((s,i)=>{ds(t,i)&&(n=n.add(i))})),n}Ds(t,e,n,s){if(t.limit===null)return!1;if(n.size!==e.size)return!0;const i=t.limitType==="F"?e.last():e.first();return!!i&&(i.hasPendingWrites||i.version.compareTo(s)>0)}ws(t,e,n){return Dn()<=ue.DEBUG&&N("QueryEngine","Using full collection scan to execute query:",xn(e)),this.gs.getDocumentsMatchingQuery(t,e,$t.min(),n)}vs(t,e,n,s){return this.gs.getDocumentsMatchingQuery(t,n,s).next((i=>(e.forEach((a=>{i=i.insert(a.key,a)})),i)))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Na="LocalStore",Ap=3e8;class Rp{constructor(t,e,n,s){this.persistence=t,this.Cs=e,this.serializer=s,this.Fs=new it(z),this.Ms=new fe((i=>an(i)),ls),this.xs=new Map,this.Os=t.getRemoteDocumentCache(),this.hi=t.getTargetCache(),this.Ti=t.getBundleCache(),this.Ns(n)}Ns(t){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(t),this.indexManager=this.persistence.getIndexManager(t),this.mutationQueue=this.persistence.getMutationQueue(t,this.indexManager),this.localDocuments=new Vd(this.Os,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.Os.setIndexManager(this.indexManager),this.Cs.initialize(this.localDocuments,this.indexManager)}collectGarbage(t){return this.persistence.runTransaction("Collect garbage","readwrite-primary",(e=>t.collect(e,this.Fs)))}}function Cd(r,t,e,n){return new Rp(r,t,e,n)}async function Dd(r,t){const e=F(r);return await e.persistence.runTransaction("Handle user change","readonly",(n=>{let s;return e.mutationQueue.getAllMutationBatches(n).next((i=>(s=i,e.Ns(t),e.mutationQueue.getAllMutationBatches(n)))).next((i=>{const a=[],u=[];let c=G();for(const h of s){a.push(h.batchId);for(const f of h.mutations)c=c.add(f.key)}for(const h of i){u.push(h.batchId);for(const f of h.mutations)c=c.add(f.key)}return e.localDocuments.getDocuments(n,c).next((h=>({Bs:h,removedBatchIds:a,addedBatchIds:u})))}))}))}function Pp(r,t){const e=F(r);return e.persistence.runTransaction("Acknowledge batch","readwrite-primary",(n=>{const s=t.batch.keys(),i=e.Os.newChangeBuffer({trackRemovals:!0});return(function(u,c,h,f){const m=h.batch,p=m.keys();let R=v.resolve();return p.forEach((b=>{R=R.next((()=>f.getEntry(c,b))).next((D=>{const x=h.docVersions.get(b);q(x!==null,48541),D.version.compareTo(x)<0&&(m.applyToRemoteDocument(D,h),D.isValidDocument()&&(D.setReadTime(h.commitVersion),f.addEntry(D)))}))})),R.next((()=>u.mutationQueue.removeMutationBatch(c,m)))})(e,n,t,i).next((()=>i.apply(n))).next((()=>e.mutationQueue.performConsistencyCheck(n))).next((()=>e.documentOverlayCache.removeOverlaysForBatchId(n,s,t.batch.batchId))).next((()=>e.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(n,(function(u){let c=G();for(let h=0;h<u.mutationResults.length;++h)u.mutationResults[h].transformResults.length>0&&(c=c.add(u.batch.mutations[h].key));return c})(t)))).next((()=>e.localDocuments.getDocuments(n,s)))}))}function xd(r){const t=F(r);return t.persistence.runTransaction("Get last remote snapshot version","readonly",(e=>t.hi.getLastRemoteSnapshotVersion(e)))}function Vp(r,t){const e=F(r),n=t.snapshotVersion;let s=e.Fs;return e.persistence.runTransaction("Apply remote event","readwrite-primary",(i=>{const a=e.Os.newChangeBuffer({trackRemovals:!0});s=e.Fs;const u=[];t.targetChanges.forEach(((f,m)=>{const p=s.get(m);if(!p)return;u.push(e.hi.removeMatchingKeys(i,f.removedDocuments,m).next((()=>e.hi.addMatchingKeys(i,f.addedDocuments,m))));let R=p.withSequenceNumber(i.currentSequenceNumber);t.targetMismatches.get(m)!==null?R=R.withResumeToken(ft.EMPTY_BYTE_STRING,U.min()).withLastLimboFreeSnapshotVersion(U.min()):f.resumeToken.approximateByteSize()>0&&(R=R.withResumeToken(f.resumeToken,n)),s=s.insert(m,R),(function(D,x,L){return D.resumeToken.approximateByteSize()===0||x.snapshotVersion.toMicroseconds()-D.snapshotVersion.toMicroseconds()>=Ap?!0:L.addedDocuments.size+L.modifiedDocuments.size+L.removedDocuments.size>0})(p,R,f)&&u.push(e.hi.updateTargetData(i,R))}));let c=Bt(),h=G();if(t.documentUpdates.forEach((f=>{t.resolvedLimboDocuments.has(f)&&u.push(e.persistence.referenceDelegate.updateLimboDocument(i,f))})),u.push(Nd(i,a,t.documentUpdates).next((f=>{c=f.Ls,h=f.ks}))),!n.isEqual(U.min())){const f=e.hi.getLastRemoteSnapshotVersion(i).next((m=>e.hi.setTargetsMetadata(i,i.currentSequenceNumber,n)));u.push(f)}return v.waitFor(u).next((()=>a.apply(i))).next((()=>e.localDocuments.getLocalViewOfDocuments(i,c,h))).next((()=>c))})).then((i=>(e.Fs=s,i)))}function Nd(r,t,e){let n=G(),s=G();return e.forEach((i=>n=n.add(i))),t.getEntries(r,n).next((i=>{let a=Bt();return e.forEach(((u,c)=>{const h=i.get(u);c.isFoundDocument()!==h.isFoundDocument()&&(s=s.add(u)),c.isNoDocument()&&c.version.isEqual(U.min())?(t.removeEntry(u,c.readTime),a=a.insert(u,c)):!h.isValidDocument()||c.version.compareTo(h.version)>0||c.version.compareTo(h.version)===0&&h.hasPendingWrites?(t.addEntry(c),a=a.insert(u,c)):N(Na,"Ignoring outdated watch update for ",u,". Current version:",h.version," Watch version:",c.version)})),{Ls:a,ks:s}}))}function Sp(r,t){const e=F(r);return e.persistence.runTransaction("Get next mutation batch","readonly",(n=>(t===void 0&&(t=be),e.mutationQueue.getNextMutationBatchAfterBatchId(n,t))))}function Jn(r,t){const e=F(r);return e.persistence.runTransaction("Allocate target","readwrite",(n=>{let s;return e.hi.getTargetData(n,t).next((i=>i?(s=i,v.resolve(s)):e.hi.allocateTargetId(n).next((a=>(s=new ce(t,a,"TargetPurposeListen",n.currentSequenceNumber),e.hi.addTargetData(n,s).next((()=>s)))))))})).then((n=>{const s=e.Fs.get(n.targetId);return(s===null||n.snapshotVersion.compareTo(s.snapshotVersion)>0)&&(e.Fs=e.Fs.insert(n.targetId,n),e.Ms.set(t,n.targetId)),n}))}async function Yn(r,t,e){const n=F(r),s=n.Fs.get(t),i=e?"readwrite":"readwrite-primary";try{e||await n.persistence.runTransaction("Release target",i,(a=>n.persistence.referenceDelegate.removeTarget(a,s)))}catch(a){if(!Le(a))throw a;N(Na,`Failed to update sequence numbers for target ${t}: ${a}`)}n.Fs=n.Fs.remove(t),n.Ms.delete(s.target)}function yi(r,t,e){const n=F(r);let s=U.min(),i=G();return n.persistence.runTransaction("Execute query","readwrite",(a=>(function(c,h,f){const m=F(c),p=m.Ms.get(f);return p!==void 0?v.resolve(m.Fs.get(p)):m.hi.getTargetData(h,f)})(n,a,kt(t)).next((u=>{if(u)return s=u.lastLimboFreeSnapshotVersion,n.hi.getMatchingKeysForTargetId(a,u.targetId).next((c=>{i=c}))})).next((()=>n.Cs.getDocumentsMatchingQuery(a,t,e?s:U.min(),e?i:G()))).next((u=>(Od(n,qh(t),u),{documents:u,qs:i})))))}function kd(r,t){const e=F(r),n=F(e.hi),s=e.Fs.get(t);return s?Promise.resolve(s.target):e.persistence.runTransaction("Get target data","readonly",(i=>n.Et(i,t).next((a=>a?a.target:null))))}function Fd(r,t){const e=F(r),n=e.xs.get(t)||U.min();return e.persistence.runTransaction("Get new document changes","readonly",(s=>e.Os.getAllFromCollectionGroup(s,t,eh(n,Ln),Number.MAX_SAFE_INTEGER))).then((s=>(Od(e,t,s),s)))}function Od(r,t,e){let n=r.xs.get(t)||U.min();e.forEach(((s,i)=>{i.readTime.compareTo(n)>0&&(n=i.readTime)})),r.xs.set(t,n)}async function bp(r,t,e,n){const s=F(r);let i=G(),a=Bt();for(const h of e){const f=t.Qs(h.metadata.name);h.document&&(i=i.add(f));const m=t.$s(h);m.setReadTime(t.Us(h.metadata.readTime)),a=a.insert(f,m)}const u=s.Os.newChangeBuffer({trackRemovals:!0}),c=await Jn(s,(function(f){return kt(sr(Q.fromString(`__bundle__/docs/${f}`)))})(n));return s.persistence.runTransaction("Apply bundle documents","readwrite",(h=>Nd(h,u,a).next((f=>(u.apply(h),f))).next((f=>s.hi.removeMatchingKeysForTargetId(h,c.targetId).next((()=>s.hi.addMatchingKeys(h,i,c.targetId))).next((()=>s.localDocuments.getLocalViewOfDocuments(h,f.Ls,f.ks))).next((()=>f.Ls))))))}async function Cp(r,t,e=G()){const n=await Jn(r,kt(Fi(t.bundledQuery))),s=F(r);return s.persistence.runTransaction("Save named query","readwrite",(i=>{const a=gt(t.readTime);if(n.snapshotVersion.compareTo(a)>=0)return s.Ti.saveNamedQuery(i,t);const u=n.withResumeToken(ft.EMPTY_BYTE_STRING,a);return s.Fs=s.Fs.insert(u.targetId,u),s.hi.updateTargetData(i,u).next((()=>s.hi.removeMatchingKeysForTargetId(i,n.targetId))).next((()=>s.hi.addMatchingKeys(i,e,n.targetId))).next((()=>s.Ti.saveNamedQuery(i,t)))}))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Md="firestore_clients";function ml(r,t){return`${Md}_${r}_${t}`}const Ld="firestore_mutations";function gl(r,t,e){let n=`${Ld}_${r}_${e}`;return t.isAuthenticated()&&(n+=`_${t.uid}`),n}const qd="firestore_targets";function Po(r,t){return`${qd}_${r}_${t}`}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Jt="SharedClientState";class Ii{constructor(t,e,n,s){this.user=t,this.batchId=e,this.state=n,this.error=s}static Ks(t,e,n){const s=JSON.parse(n);let i,a=typeof s=="object"&&["pending","acknowledged","rejected"].indexOf(s.state)!==-1&&(s.error===void 0||typeof s.error=="object");return a&&s.error&&(a=typeof s.error.message=="string"&&typeof s.error.code=="string",a&&(i=new C(s.error.code,s.error.message))),a?new Ii(t,e,s.state,i):(mt(Jt,`Failed to parse mutation state for ID '${e}': ${n}`),null)}Ws(){const t={state:this.state,updateTimeMs:Date.now()};return this.error&&(t.error={code:this.error.code,message:this.error.message}),JSON.stringify(t)}}class $r{constructor(t,e,n){this.targetId=t,this.state=e,this.error=n}static Ks(t,e){const n=JSON.parse(e);let s,i=typeof n=="object"&&["not-current","current","rejected"].indexOf(n.state)!==-1&&(n.error===void 0||typeof n.error=="object");return i&&n.error&&(i=typeof n.error.message=="string"&&typeof n.error.code=="string",i&&(s=new C(n.error.code,n.error.message))),i?new $r(t,n.state,s):(mt(Jt,`Failed to parse target state for ID '${t}': ${e}`),null)}Ws(){const t={state:this.state,updateTimeMs:Date.now()};return this.error&&(t.error={code:this.error.code,message:this.error.message}),JSON.stringify(t)}}class Ti{constructor(t,e){this.clientId=t,this.activeTargetIds=e}static Ks(t,e){const n=JSON.parse(e);let s=typeof n=="object"&&n.activeTargetIds instanceof Array,i=ya();for(let a=0;s&&a<n.activeTargetIds.length;++a)s=oh(n.activeTargetIds[a]),i=i.add(n.activeTargetIds[a]);return s?new Ti(t,i):(mt(Jt,`Failed to parse client data for instance '${t}': ${e}`),null)}}class ka{constructor(t,e){this.clientId=t,this.onlineState=e}static Ks(t){const e=JSON.parse(t);return typeof e=="object"&&["Unknown","Online","Offline"].indexOf(e.onlineState)!==-1&&typeof e.clientId=="string"?new ka(e.clientId,e.onlineState):(mt(Jt,`Failed to parse online state: ${t}`),null)}}class Yo{constructor(){this.activeTargetIds=ya()}Gs(t){this.activeTargetIds=this.activeTargetIds.add(t)}zs(t){this.activeTargetIds=this.activeTargetIds.delete(t)}Ws(){const t={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(t)}}class Vo{constructor(t,e,n,s,i){this.window=t,this.Fi=e,this.persistenceKey=n,this.js=s,this.syncEngine=null,this.onlineStateHandler=null,this.sequenceNumberHandler=null,this.Js=this.Hs.bind(this),this.Ys=new it(z),this.started=!1,this.Zs=[];const a=n.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");this.storage=this.window.localStorage,this.currentUser=i,this.Xs=ml(this.persistenceKey,this.js),this.eo=(function(c){return`firestore_sequence_number_${c}`})(this.persistenceKey),this.Ys=this.Ys.insert(this.js,new Yo),this.no=new RegExp(`^${Md}_${a}_([^_]*)$`),this.ro=new RegExp(`^${Ld}_${a}_(\\d+)(?:_(.*))?$`),this.io=new RegExp(`^${qd}_${a}_(\\d+)$`),this.so=(function(c){return`firestore_online_state_${c}`})(this.persistenceKey),this.oo=(function(c){return`firestore_bundle_loaded_v2_${c}`})(this.persistenceKey),this.window.addEventListener("storage",this.Js)}static C(t){return!(!t||!t.localStorage)}async start(){const t=await this.syncEngine.Ps();for(const n of t){if(n===this.js)continue;const s=this.getItem(ml(this.persistenceKey,n));if(s){const i=Ti.Ks(n,s);i&&(this.Ys=this.Ys.insert(i.clientId,i))}}this._o();const e=this.storage.getItem(this.so);if(e){const n=this.ao(e);n&&this.uo(n)}for(const n of this.Zs)this.Hs(n);this.Zs=[],this.window.addEventListener("pagehide",(()=>this.shutdown())),this.started=!0}writeSequenceNumber(t){this.setItem(this.eo,JSON.stringify(t))}getAllActiveQueryTargets(){return this.co(this.Ys)}isActiveQueryTarget(t){let e=!1;return this.Ys.forEach(((n,s)=>{s.activeTargetIds.has(t)&&(e=!0)})),e}addPendingMutation(t){this.lo(t,"pending")}updateMutationState(t,e,n){this.lo(t,e,n),this.ho(t)}addLocalQueryTarget(t,e=!0){let n="not-current";if(this.isActiveQueryTarget(t)){const s=this.storage.getItem(Po(this.persistenceKey,t));if(s){const i=$r.Ks(t,s);i&&(n=i.state)}}return e&&this.Po.Gs(t),this._o(),n}removeLocalQueryTarget(t){this.Po.zs(t),this._o()}isLocalQueryTarget(t){return this.Po.activeTargetIds.has(t)}clearQueryState(t){this.removeItem(Po(this.persistenceKey,t))}updateQueryState(t,e,n){this.To(t,e,n)}handleUserChange(t,e,n){e.forEach((s=>{this.ho(s)})),this.currentUser=t,n.forEach((s=>{this.addPendingMutation(s)}))}setOnlineState(t){this.Io(t)}notifyBundleLoaded(t){this.Eo(t)}shutdown(){this.started&&(this.window.removeEventListener("storage",this.Js),this.removeItem(this.Xs),this.started=!1)}getItem(t){const e=this.storage.getItem(t);return N(Jt,"READ",t,e),e}setItem(t,e){N(Jt,"SET",t,e),this.storage.setItem(t,e)}removeItem(t){N(Jt,"REMOVE",t),this.storage.removeItem(t)}Hs(t){const e=t;if(e.storageArea===this.storage){if(N(Jt,"EVENT",e.key,e.newValue),e.key===this.Xs)return void mt("Received WebStorage notification for local change. Another client might have garbage-collected our state");this.Fi.enqueueRetryable((async()=>{if(this.started){if(e.key!==null){if(this.no.test(e.key)){if(e.newValue==null){const n=this.Ao(e.key);return this.Ro(n,null)}{const n=this.Vo(e.key,e.newValue);if(n)return this.Ro(n.clientId,n)}}else if(this.ro.test(e.key)){if(e.newValue!==null){const n=this.mo(e.key,e.newValue);if(n)return this.fo(n)}}else if(this.io.test(e.key)){if(e.newValue!==null){const n=this.po(e.key,e.newValue);if(n)return this.yo(n)}}else if(e.key===this.so){if(e.newValue!==null){const n=this.ao(e.newValue);if(n)return this.uo(n)}}else if(e.key===this.eo){const n=(function(i){let a=Lt.ue;if(i!=null)try{const u=JSON.parse(i);q(typeof u=="number",30636,{wo:i}),a=u}catch(u){mt(Jt,"Failed to read sequence number from WebStorage",u)}return a})(e.newValue);n!==Lt.ue&&this.sequenceNumberHandler(n)}else if(e.key===this.oo){const n=this.So(e.newValue);await Promise.all(n.map((s=>this.syncEngine.bo(s))))}}}else this.Zs.push(e)}))}}get Po(){return this.Ys.get(this.js)}_o(){this.setItem(this.Xs,this.Po.Ws())}lo(t,e,n){const s=new Ii(this.currentUser,t,e,n),i=gl(this.persistenceKey,this.currentUser,t);this.setItem(i,s.Ws())}ho(t){const e=gl(this.persistenceKey,this.currentUser,t);this.removeItem(e)}Io(t){const e={clientId:this.js,onlineState:t};this.storage.setItem(this.so,JSON.stringify(e))}To(t,e,n){const s=Po(this.persistenceKey,t),i=new $r(t,e,n);this.setItem(s,i.Ws())}Eo(t){const e=JSON.stringify(Array.from(t));this.setItem(this.oo,e)}Ao(t){const e=this.no.exec(t);return e?e[1]:null}Vo(t,e){const n=this.Ao(t);return Ti.Ks(n,e)}mo(t,e){const n=this.ro.exec(t),s=Number(n[1]),i=n[2]!==void 0?n[2]:null;return Ii.Ks(new Et(i),s,e)}po(t,e){const n=this.io.exec(t),s=Number(n[1]);return $r.Ks(s,e)}ao(t){return ka.Ks(t)}So(t){return JSON.parse(t)}async fo(t){if(t.user.uid===this.currentUser.uid)return this.syncEngine.Do(t.batchId,t.state,t.error);N(Jt,`Ignoring mutation for non-active user ${t.user.uid}`)}yo(t){return this.syncEngine.vo(t.targetId,t.state,t.error)}Ro(t,e){const n=e?this.Ys.insert(t,e):this.Ys.remove(t),s=this.co(this.Ys),i=this.co(n),a=[],u=[];return i.forEach((c=>{s.has(c)||a.push(c)})),s.forEach((c=>{i.has(c)||u.push(c)})),this.syncEngine.Co(a,u).then((()=>{this.Ys=n}))}uo(t){this.Ys.get(t.clientId)&&this.onlineStateHandler(t.onlineState)}co(t){let e=ya();return t.forEach(((n,s)=>{e=e.unionWith(s.activeTargetIds)})),e}}class Bd{constructor(){this.Fo=new Yo,this.Mo={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(t){}updateMutationState(t,e,n){}addLocalQueryTarget(t,e=!0){return e&&this.Fo.Gs(t),this.Mo[t]||"not-current"}updateQueryState(t,e,n){this.Mo[t]=e}removeLocalQueryTarget(t){this.Fo.zs(t)}isLocalQueryTarget(t){return this.Fo.activeTargetIds.has(t)}clearQueryState(t){delete this.Mo[t]}getAllActiveQueryTargets(){return this.Fo.activeTargetIds}isActiveQueryTarget(t){return this.Fo.activeTargetIds.has(t)}start(){return this.Fo=new Yo,Promise.resolve()}handleUserChange(t,e,n){}setOnlineState(t){}shutdown(){}writeSequenceNumber(t){}notifyBundleLoaded(t){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Dp{xo(t){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pl="ConnectivityMonitor";class _l{constructor(){this.Oo=()=>this.No(),this.Bo=()=>this.Lo(),this.ko=[],this.qo()}xo(t){this.ko.push(t)}shutdown(){window.removeEventListener("online",this.Oo),window.removeEventListener("offline",this.Bo)}qo(){window.addEventListener("online",this.Oo),window.addEventListener("offline",this.Bo)}No(){N(pl,"Network connectivity changed: AVAILABLE");for(const t of this.ko)t(0)}Lo(){N(pl,"Network connectivity changed: UNAVAILABLE");for(const t of this.ko)t(1)}static C(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Qs=null;function Zo(){return Qs===null?Qs=(function(){return 268435456+Math.round(2147483648*Math.random())})():Qs++,"0x"+Qs.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const So="RestConnection",xp={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery"};class Np{get Qo(){return!1}constructor(t){this.databaseInfo=t,this.databaseId=t.databaseId;const e=t.ssl?"https":"http",n=encodeURIComponent(this.databaseId.projectId),s=encodeURIComponent(this.databaseId.database);this.$o=e+"://"+t.host,this.Uo=`projects/${n}/databases/${s}`,this.Ko=this.databaseId.database===Yr?`project_id=${n}`:`project_id=${n}&database_id=${s}`}Wo(t,e,n,s,i){const a=Zo(),u=this.Go(t,e.toUriEncodedString());N(So,`Sending RPC '${t}' ${a}:`,u,n);const c={"google-cloud-resource-prefix":this.Uo,"x-goog-request-params":this.Ko};this.zo(c,s,i);const{host:h}=new URL(u),f=ra(h);return this.jo(t,u,c,n,f).then((m=>(N(So,`Received RPC '${t}' ${a}: `,m),m)),(m=>{throw Mt(So,`RPC '${t}' ${a} failed with error: `,m,"url: ",u,"request:",n),m}))}Jo(t,e,n,s,i,a){return this.Wo(t,e,n,s,i)}zo(t,e,n){t["X-Goog-Api-Client"]=(function(){return"gl-js/ fire/"+rr})(),t["Content-Type"]="text/plain",this.databaseInfo.appId&&(t["X-Firebase-GMPID"]=this.databaseInfo.appId),e&&e.headers.forEach(((s,i)=>t[i]=s)),n&&n.headers.forEach(((s,i)=>t[i]=s))}Go(t,e){const n=xp[t];return`${this.$o}/v1/${e}:${n}`}terminate(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kp{constructor(t){this.Ho=t.Ho,this.Yo=t.Yo}Zo(t){this.Xo=t}e_(t){this.t_=t}n_(t){this.r_=t}onMessage(t){this.i_=t}close(){this.Yo()}send(t){this.Ho(t)}s_(){this.Xo()}o_(){this.t_()}__(t){this.r_(t)}a_(t){this.i_(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Dt="WebChannelConnection";class Fp extends Np{constructor(t){super(t),this.u_=[],this.forceLongPolling=t.forceLongPolling,this.autoDetectLongPolling=t.autoDetectLongPolling,this.useFetchStreams=t.useFetchStreams,this.longPollingOptions=t.longPollingOptions}jo(t,e,n,s,i){const a=Zo();return new Promise(((u,c)=>{const h=new Kl;h.setWithCredentials(!0),h.listenOnce($l.COMPLETE,(()=>{try{switch(h.getLastErrorCode()){case Hs.NO_ERROR:const m=h.getResponseJson();N(Dt,`XHR for RPC '${t}' ${a} received:`,JSON.stringify(m)),u(m);break;case Hs.TIMEOUT:N(Dt,`RPC '${t}' ${a} timed out`),c(new C(P.DEADLINE_EXCEEDED,"Request time out"));break;case Hs.HTTP_ERROR:const p=h.getStatus();if(N(Dt,`RPC '${t}' ${a} failed with status:`,p,"response text:",h.getResponseText()),p>0){let R=h.getResponseJson();Array.isArray(R)&&(R=R[0]);const b=R?.error;if(b&&b.status&&b.message){const D=(function(L){const j=L.toLowerCase().replace(/_/g,"-");return Object.values(P).indexOf(j)>=0?j:P.UNKNOWN})(b.status);c(new C(D,b.message))}else c(new C(P.UNKNOWN,"Server responded with status "+h.getStatus()))}else c(new C(P.UNAVAILABLE,"Connection failed."));break;default:M(9055,{c_:t,streamId:a,l_:h.getLastErrorCode(),h_:h.getLastError()})}}finally{N(Dt,`RPC '${t}' ${a} completed.`)}}));const f=JSON.stringify(s);N(Dt,`RPC '${t}' ${a} sending request:`,s),h.send(e,"POST",f,n,15)}))}P_(t,e,n){const s=Zo(),i=[this.$o,"/","google.firestore.v1.Firestore","/",t,"/channel"],a=Hl(),u=Wl(),c={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},h=this.longPollingOptions.timeoutSeconds;h!==void 0&&(c.longPollingTimeout=Math.round(1e3*h)),this.useFetchStreams&&(c.useFetchStreams=!0),this.zo(c.initMessageHeaders,e,n),c.encodeInitMessageHeaders=!0;const f=i.join("");N(Dt,`Creating RPC '${t}' stream ${s}: ${f}`,c);const m=a.createWebChannel(f,c);this.T_(m);let p=!1,R=!1;const b=new kp({Ho:x=>{R?N(Dt,`Not sending because RPC '${t}' stream ${s} is closed:`,x):(p||(N(Dt,`Opening RPC '${t}' stream ${s} transport.`),m.open(),p=!0),N(Dt,`RPC '${t}' stream ${s} sending:`,x),m.send(x))},Yo:()=>m.close()}),D=(x,L,j)=>{x.listen(L,(B=>{try{j(B)}catch($){setTimeout((()=>{throw $}),0)}}))};return D(m,Fr.EventType.OPEN,(()=>{R||(N(Dt,`RPC '${t}' stream ${s} transport opened.`),b.s_())})),D(m,Fr.EventType.CLOSE,(()=>{R||(R=!0,N(Dt,`RPC '${t}' stream ${s} transport closed`),b.__(),this.I_(m))})),D(m,Fr.EventType.ERROR,(x=>{R||(R=!0,Mt(Dt,`RPC '${t}' stream ${s} transport errored. Name:`,x.name,"Message:",x.message),b.__(new C(P.UNAVAILABLE,"The operation could not be completed")))})),D(m,Fr.EventType.MESSAGE,(x=>{var L;if(!R){const j=x.data[0];q(!!j,16349);const B=j,$=B?.error||((L=B[0])===null||L===void 0?void 0:L.error);if($){N(Dt,`RPC '${t}' stream ${s} received error:`,$);const Y=$.status;let K=(function(I){const E=pt[I];if(E!==void 0)return td(E)})(Y),T=$.message;K===void 0&&(K=P.INTERNAL,T="Unknown error status: "+Y+" with message "+$.message),R=!0,b.__(new C(K,T)),m.close()}else N(Dt,`RPC '${t}' stream ${s} received:`,j),b.a_(j)}})),D(u,Ql.STAT_EVENT,(x=>{x.stat===Co.PROXY?N(Dt,`RPC '${t}' stream ${s} detected buffering proxy`):x.stat===Co.NOPROXY&&N(Dt,`RPC '${t}' stream ${s} detected no buffering proxy`)})),setTimeout((()=>{b.o_()}),0),b}terminate(){this.u_.forEach((t=>t.close())),this.u_=[]}T_(t){this.u_.push(t)}I_(t){this.u_=this.u_.filter((e=>e===t))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ud(){return typeof window<"u"?window:null}function si(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pn(r){return new Ug(r,!0)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fa{constructor(t,e,n=1e3,s=1.5,i=6e4){this.Fi=t,this.timerId=e,this.d_=n,this.E_=s,this.A_=i,this.R_=0,this.V_=null,this.m_=Date.now(),this.reset()}reset(){this.R_=0}f_(){this.R_=this.A_}g_(t){this.cancel();const e=Math.floor(this.R_+this.p_()),n=Math.max(0,Date.now()-this.m_),s=Math.max(0,e-n);s>0&&N("ExponentialBackoff",`Backing off for ${s} ms (base delay: ${this.R_} ms, delay with jitter: ${e} ms, last attempt: ${n} ms ago)`),this.V_=this.Fi.enqueueAfterDelay(this.timerId,s,(()=>(this.m_=Date.now(),t()))),this.R_*=this.E_,this.R_<this.d_&&(this.R_=this.d_),this.R_>this.A_&&(this.R_=this.A_)}y_(){this.V_!==null&&(this.V_.skipDelay(),this.V_=null)}cancel(){this.V_!==null&&(this.V_.cancel(),this.V_=null)}p_(){return(Math.random()-.5)*this.R_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yl="PersistentStream";class jd{constructor(t,e,n,s,i,a,u,c){this.Fi=t,this.w_=n,this.S_=s,this.connection=i,this.authCredentialsProvider=a,this.appCheckCredentialsProvider=u,this.listener=c,this.state=0,this.b_=0,this.D_=null,this.v_=null,this.stream=null,this.C_=0,this.F_=new Fa(t,e)}M_(){return this.state===1||this.state===5||this.x_()}x_(){return this.state===2||this.state===3}start(){this.C_=0,this.state!==4?this.auth():this.O_()}async stop(){this.M_()&&await this.close(0)}N_(){this.state=0,this.F_.reset()}B_(){this.x_()&&this.D_===null&&(this.D_=this.Fi.enqueueAfterDelay(this.w_,6e4,(()=>this.L_())))}k_(t){this.q_(),this.stream.send(t)}async L_(){if(this.x_())return this.close(0)}q_(){this.D_&&(this.D_.cancel(),this.D_=null)}Q_(){this.v_&&(this.v_.cancel(),this.v_=null)}async close(t,e){this.q_(),this.Q_(),this.F_.cancel(),this.b_++,t!==4?this.F_.reset():e&&e.code===P.RESOURCE_EXHAUSTED?(mt(e.toString()),mt("Using maximum backoff delay to prevent overloading the backend."),this.F_.f_()):e&&e.code===P.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this.U_(),this.stream.close(),this.stream=null),this.state=t,await this.listener.n_(e)}U_(){}auth(){this.state=1;const t=this.K_(this.b_),e=this.b_;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then((([n,s])=>{this.b_===e&&this.W_(n,s)}),(n=>{t((()=>{const s=new C(P.UNKNOWN,"Fetching auth token failed: "+n.message);return this.G_(s)}))}))}W_(t,e){const n=this.K_(this.b_);this.stream=this.z_(t,e),this.stream.Zo((()=>{n((()=>this.listener.Zo()))})),this.stream.e_((()=>{n((()=>(this.state=2,this.v_=this.Fi.enqueueAfterDelay(this.S_,1e4,(()=>(this.x_()&&(this.state=3),Promise.resolve()))),this.listener.e_())))})),this.stream.n_((s=>{n((()=>this.G_(s)))})),this.stream.onMessage((s=>{n((()=>++this.C_==1?this.j_(s):this.onNext(s)))}))}O_(){this.state=5,this.F_.g_((async()=>{this.state=0,this.start()}))}G_(t){return N(yl,`close with error: ${t}`),this.stream=null,this.close(4,t)}K_(t){return e=>{this.Fi.enqueueAndForget((()=>this.b_===t?e():(N(yl,"stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve())))}}}class Op extends jd{constructor(t,e,n,s,i,a){super(t,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",e,n,s,a),this.serializer=i}z_(t,e){return this.connection.P_("Listen",t,e)}j_(t){return this.onNext(t)}onNext(t){this.F_.reset();const e=Gg(this.serializer,t),n=(function(i){if(!("targetChange"in i))return U.min();const a=i.targetChange;return a.targetIds&&a.targetIds.length?U.min():a.readTime?gt(a.readTime):U.min()})(t);return this.listener.J_(e,n)}H_(t){const e={};e.database=Qo(this.serializer),e.addTarget=(function(i,a){let u;const c=a.target;if(u=li(c)?{documents:ud(i,c)}:{query:ki(i,c).Vt},u.targetId=a.targetId,a.resumeToken.approximateByteSize()>0){u.resumeToken=rd(i,a.resumeToken);const h=Ko(i,a.expectedCount);h!==null&&(u.expectedCount=h)}else if(a.snapshotVersion.compareTo(U.min())>0){u.readTime=Xn(i,a.snapshotVersion.toTimestamp());const h=Ko(i,a.expectedCount);h!==null&&(u.expectedCount=h)}return u})(this.serializer,t);const n=$g(this.serializer,t);n&&(e.labels=n),this.k_(e)}Y_(t){const e={};e.database=Qo(this.serializer),e.removeTarget=t,this.k_(e)}}class Mp extends jd{constructor(t,e,n,s,i,a){super(t,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",e,n,s,a),this.serializer=i}get Z_(){return this.C_>0}start(){this.lastStreamToken=void 0,super.start()}U_(){this.Z_&&this.X_([])}z_(t,e){return this.connection.P_("Write",t,e)}j_(t){return q(!!t.streamToken,31322),this.lastStreamToken=t.streamToken,q(!t.writeResults||t.writeResults.length===0,55816),this.listener.ea()}onNext(t){q(!!t.streamToken,12678),this.lastStreamToken=t.streamToken,this.F_.reset();const e=Kg(t.writeResults,t.commitTime),n=gt(t.commitTime);return this.listener.ta(n,e)}na(){const t={};t.database=Qo(this.serializer),this.k_(t)}X_(t){const e={streamToken:this.lastStreamToken,writes:t.map((n=>rs(this.serializer,n)))};this.k_(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lp{}class qp extends Lp{constructor(t,e,n,s){super(),this.authCredentials=t,this.appCheckCredentials=e,this.connection=n,this.serializer=s,this.ra=!1}ia(){if(this.ra)throw new C(P.FAILED_PRECONDITION,"The client has already been terminated.")}Wo(t,e,n,s){return this.ia(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then((([i,a])=>this.connection.Wo(t,$o(e,n),s,i,a))).catch((i=>{throw i.name==="FirebaseError"?(i.code===P.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),i):new C(P.UNKNOWN,i.toString())}))}Jo(t,e,n,s,i){return this.ia(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then((([a,u])=>this.connection.Jo(t,$o(e,n),s,a,u,i))).catch((a=>{throw a.name==="FirebaseError"?(a.code===P.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),a):new C(P.UNKNOWN,a.toString())}))}terminate(){this.ra=!0,this.connection.terminate()}}class Bp{constructor(t,e){this.asyncQueue=t,this.onlineStateHandler=e,this.state="Unknown",this.sa=0,this.oa=null,this._a=!0}aa(){this.sa===0&&(this.ua("Unknown"),this.oa=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,(()=>(this.oa=null,this.ca("Backend didn't respond within 10 seconds."),this.ua("Offline"),Promise.resolve()))))}la(t){this.state==="Online"?this.ua("Unknown"):(this.sa++,this.sa>=1&&(this.ha(),this.ca(`Connection failed 1 times. Most recent error: ${t.toString()}`),this.ua("Offline")))}set(t){this.ha(),this.sa=0,t==="Online"&&(this._a=!1),this.ua(t)}ua(t){t!==this.state&&(this.state=t,this.onlineStateHandler(t))}ca(t){const e=`Could not reach Cloud Firestore backend. ${t}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this._a?(mt(e),this._a=!1):N("OnlineStateTracker",e)}ha(){this.oa!==null&&(this.oa.cancel(),this.oa=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fn="RemoteStore";class Up{constructor(t,e,n,s,i){this.localStore=t,this.datastore=e,this.asyncQueue=n,this.remoteSyncer={},this.Pa=[],this.Ta=new Map,this.Ia=new Set,this.da=[],this.Ea=i,this.Ea.xo((a=>{n.enqueueAndForget((async()=>{Be(this)&&(N(fn,"Restarting streams for network reachability change."),await(async function(c){const h=F(c);h.Ia.add(4),await ar(h),h.Aa.set("Unknown"),h.Ia.delete(4),await ps(h)})(this))}))})),this.Aa=new Bp(n,s)}}async function ps(r){if(Be(r))for(const t of r.da)await t(!0)}async function ar(r){for(const t of r.da)await t(!1)}function qi(r,t){const e=F(r);e.Ta.has(t.targetId)||(e.Ta.set(t.targetId,t),La(e)?Ma(e):cr(e).x_()&&Oa(e,t))}function Zn(r,t){const e=F(r),n=cr(e);e.Ta.delete(t),n.x_()&&zd(e,t),e.Ta.size===0&&(n.x_()?n.B_():Be(e)&&e.Aa.set("Unknown"))}function Oa(r,t){if(r.Ra.$e(t.targetId),t.resumeToken.approximateByteSize()>0||t.snapshotVersion.compareTo(U.min())>0){const e=r.remoteSyncer.getRemoteKeysForTarget(t.targetId).size;t=t.withExpectedCount(e)}cr(r).H_(t)}function zd(r,t){r.Ra.$e(t),cr(r).Y_(t)}function Ma(r){r.Ra=new Mg({getRemoteKeysForTarget:t=>r.remoteSyncer.getRemoteKeysForTarget(t),Et:t=>r.Ta.get(t)||null,lt:()=>r.datastore.serializer.databaseId}),cr(r).start(),r.Aa.aa()}function La(r){return Be(r)&&!cr(r).M_()&&r.Ta.size>0}function Be(r){return F(r).Ia.size===0}function Gd(r){r.Ra=void 0}async function jp(r){r.Aa.set("Online")}async function zp(r){r.Ta.forEach(((t,e)=>{Oa(r,t)}))}async function Gp(r,t){Gd(r),La(r)?(r.Aa.la(t),Ma(r)):r.Aa.set("Unknown")}async function Kp(r,t,e){if(r.Aa.set("Online"),t instanceof nd&&t.state===2&&t.cause)try{await(async function(s,i){const a=i.cause;for(const u of i.targetIds)s.Ta.has(u)&&(await s.remoteSyncer.rejectListen(u,a),s.Ta.delete(u),s.Ra.removeTarget(u))})(r,t)}catch(n){N(fn,"Failed to remove targets %s: %s ",t.targetIds.join(","),n),await Ei(r,n)}else if(t instanceof ni?r.Ra.Ye(t):t instanceof ed?r.Ra.it(t):r.Ra.et(t),!e.isEqual(U.min()))try{const n=await xd(r.localStore);e.compareTo(n)>=0&&await(function(i,a){const u=i.Ra.Pt(a);return u.targetChanges.forEach(((c,h)=>{if(c.resumeToken.approximateByteSize()>0){const f=i.Ta.get(h);f&&i.Ta.set(h,f.withResumeToken(c.resumeToken,a))}})),u.targetMismatches.forEach(((c,h)=>{const f=i.Ta.get(c);if(!f)return;i.Ta.set(c,f.withResumeToken(ft.EMPTY_BYTE_STRING,f.snapshotVersion)),zd(i,c);const m=new ce(f.target,c,h,f.sequenceNumber);Oa(i,m)})),i.remoteSyncer.applyRemoteEvent(u)})(r,e)}catch(n){N(fn,"Failed to raise snapshot:",n),await Ei(r,n)}}async function Ei(r,t,e){if(!Le(t))throw t;r.Ia.add(1),await ar(r),r.Aa.set("Offline"),e||(e=()=>xd(r.localStore)),r.asyncQueue.enqueueRetryable((async()=>{N(fn,"Retrying IndexedDB access"),await e(),r.Ia.delete(1),await ps(r)}))}function Kd(r,t){return t().catch((e=>Ei(r,e,t)))}async function ur(r){const t=F(r),e=ke(t);let n=t.Pa.length>0?t.Pa[t.Pa.length-1].batchId:be;for(;$p(t);)try{const s=await Sp(t.localStore,n);if(s===null){t.Pa.length===0&&e.B_();break}n=s.batchId,Qp(t,s)}catch(s){await Ei(t,s)}$d(t)&&Qd(t)}function $p(r){return Be(r)&&r.Pa.length<10}function Qp(r,t){r.Pa.push(t);const e=ke(r);e.x_()&&e.Z_&&e.X_(t.mutations)}function $d(r){return Be(r)&&!ke(r).M_()&&r.Pa.length>0}function Qd(r){ke(r).start()}async function Wp(r){ke(r).na()}async function Hp(r){const t=ke(r);for(const e of r.Pa)t.X_(e.mutations)}async function Xp(r,t,e){const n=r.Pa.shift(),s=wa.from(n,t,e);await Kd(r,(()=>r.remoteSyncer.applySuccessfulWrite(s))),await ur(r)}async function Jp(r,t){t&&ke(r).Z_&&await(async function(n,s){if((function(a){return Zh(a)&&a!==P.ABORTED})(s.code)){const i=n.Pa.shift();ke(n).N_(),await Kd(n,(()=>n.remoteSyncer.rejectFailedWrite(i.batchId,s))),await ur(n)}})(r,t),$d(r)&&Qd(r)}async function Il(r,t){const e=F(r);e.asyncQueue.verifyOperationInProgress(),N(fn,"RemoteStore received new credentials");const n=Be(e);e.Ia.add(3),await ar(e),n&&e.Aa.set("Unknown"),await e.remoteSyncer.handleCredentialChange(t),e.Ia.delete(3),await ps(e)}async function ta(r,t){const e=F(r);t?(e.Ia.delete(2),await ps(e)):t||(e.Ia.add(2),await ar(e),e.Aa.set("Unknown"))}function cr(r){return r.Va||(r.Va=(function(e,n,s){const i=F(e);return i.ia(),new Op(n,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,s)})(r.datastore,r.asyncQueue,{Zo:jp.bind(null,r),e_:zp.bind(null,r),n_:Gp.bind(null,r),J_:Kp.bind(null,r)}),r.da.push((async t=>{t?(r.Va.N_(),La(r)?Ma(r):r.Aa.set("Unknown")):(await r.Va.stop(),Gd(r))}))),r.Va}function ke(r){return r.ma||(r.ma=(function(e,n,s){const i=F(e);return i.ia(),new Mp(n,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,s)})(r.datastore,r.asyncQueue,{Zo:()=>Promise.resolve(),e_:Wp.bind(null,r),n_:Jp.bind(null,r),ea:Hp.bind(null,r),ta:Xp.bind(null,r)}),r.da.push((async t=>{t?(r.ma.N_(),await ur(r)):(await r.ma.stop(),r.Pa.length>0&&(N(fn,`Stopping write stream with ${r.Pa.length} pending writes`),r.Pa=[]))}))),r.ma}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qa{constructor(t,e,n,s,i){this.asyncQueue=t,this.timerId=e,this.targetTimeMs=n,this.op=s,this.removalCallback=i,this.deferred=new wt,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch((a=>{}))}get promise(){return this.deferred.promise}static createAndSchedule(t,e,n,s,i){const a=Date.now()+n,u=new qa(t,e,a,s,i);return u.start(n),u}start(t){this.timerHandle=setTimeout((()=>this.handleDelayElapsed()),t)}skipDelay(){return this.handleDelayElapsed()}cancel(t){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new C(P.CANCELLED,"Operation cancelled"+(t?": "+t:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget((()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then((t=>this.deferred.resolve(t)))):Promise.resolve()))}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function lr(r,t){if(mt("AsyncQueue",`${t}: ${r}`),Le(r))return new C(P.UNAVAILABLE,`${t}: ${r}`);throw r}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rn{static emptySet(t){return new rn(t.comparator)}constructor(t){this.comparator=t?(e,n)=>t(e,n)||k.comparator(e.key,n.key):(e,n)=>k.comparator(e.key,n.key),this.keyedMap=Or(),this.sortedSet=new it(this.comparator)}has(t){return this.keyedMap.get(t)!=null}get(t){return this.keyedMap.get(t)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(t){const e=this.keyedMap.get(t);return e?this.sortedSet.indexOf(e):-1}get size(){return this.sortedSet.size}forEach(t){this.sortedSet.inorderTraversal(((e,n)=>(t(e),!1)))}add(t){const e=this.delete(t.key);return e.copy(e.keyedMap.insert(t.key,t),e.sortedSet.insert(t,null))}delete(t){const e=this.get(t);return e?this.copy(this.keyedMap.remove(t),this.sortedSet.remove(e)):this}isEqual(t){if(!(t instanceof rn)||this.size!==t.size)return!1;const e=this.sortedSet.getIterator(),n=t.sortedSet.getIterator();for(;e.hasNext();){const s=e.getNext().key,i=n.getNext().key;if(!s.isEqual(i))return!1}return!0}toString(){const t=[];return this.forEach((e=>{t.push(e.toString())})),t.length===0?"DocumentSet ()":`DocumentSet (
  `+t.join(`  
`)+`
)`}copy(t,e){const n=new rn;return n.comparator=this.comparator,n.keyedMap=t,n.sortedSet=e,n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tl{constructor(){this.fa=new it(k.comparator)}track(t){const e=t.doc.key,n=this.fa.get(e);n?t.type!==0&&n.type===3?this.fa=this.fa.insert(e,t):t.type===3&&n.type!==1?this.fa=this.fa.insert(e,{type:n.type,doc:t.doc}):t.type===2&&n.type===2?this.fa=this.fa.insert(e,{type:2,doc:t.doc}):t.type===2&&n.type===0?this.fa=this.fa.insert(e,{type:0,doc:t.doc}):t.type===1&&n.type===0?this.fa=this.fa.remove(e):t.type===1&&n.type===2?this.fa=this.fa.insert(e,{type:1,doc:n.doc}):t.type===0&&n.type===1?this.fa=this.fa.insert(e,{type:2,doc:t.doc}):M(63341,{At:t,ga:n}):this.fa=this.fa.insert(e,t)}pa(){const t=[];return this.fa.inorderTraversal(((e,n)=>{t.push(n)})),t}}class mn{constructor(t,e,n,s,i,a,u,c,h){this.query=t,this.docs=e,this.oldDocs=n,this.docChanges=s,this.mutatedKeys=i,this.fromCache=a,this.syncStateChanged=u,this.excludesMetadataChanges=c,this.hasCachedResults=h}static fromInitialDocuments(t,e,n,s,i){const a=[];return e.forEach((u=>{a.push({type:0,doc:u})})),new mn(t,e,rn.emptySet(e),a,n,s,!0,!1,i)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(t){if(!(this.fromCache===t.fromCache&&this.hasCachedResults===t.hasCachedResults&&this.syncStateChanged===t.syncStateChanged&&this.mutatedKeys.isEqual(t.mutatedKeys)&&hs(this.query,t.query)&&this.docs.isEqual(t.docs)&&this.oldDocs.isEqual(t.oldDocs)))return!1;const e=this.docChanges,n=t.docChanges;if(e.length!==n.length)return!1;for(let s=0;s<e.length;s++)if(e[s].type!==n[s].type||!e[s].doc.isEqual(n[s].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yp{constructor(){this.ya=void 0,this.wa=[]}Sa(){return this.wa.some((t=>t.ba()))}}class Zp{constructor(){this.queries=El(),this.onlineState="Unknown",this.Da=new Set}terminate(){(function(e,n){const s=F(e),i=s.queries;s.queries=El(),i.forEach(((a,u)=>{for(const c of u.wa)c.onError(n)}))})(this,new C(P.ABORTED,"Firestore shutting down"))}}function El(){return new fe((r=>Lh(r)),hs)}async function Ba(r,t){const e=F(r);let n=3;const s=t.query;let i=e.queries.get(s);i?!i.Sa()&&t.ba()&&(n=2):(i=new Yp,n=t.ba()?0:1);try{switch(n){case 0:i.ya=await e.onListen(s,!0);break;case 1:i.ya=await e.onListen(s,!1);break;case 2:await e.onFirstRemoteStoreListen(s)}}catch(a){const u=lr(a,`Initialization of query '${xn(t.query)}' failed`);return void t.onError(u)}e.queries.set(s,i),i.wa.push(t),t.va(e.onlineState),i.ya&&t.Ca(i.ya)&&ja(e)}async function Ua(r,t){const e=F(r),n=t.query;let s=3;const i=e.queries.get(n);if(i){const a=i.wa.indexOf(t);a>=0&&(i.wa.splice(a,1),i.wa.length===0?s=t.ba()?0:1:!i.Sa()&&t.ba()&&(s=2))}switch(s){case 0:return e.queries.delete(n),e.onUnlisten(n,!0);case 1:return e.queries.delete(n),e.onUnlisten(n,!1);case 2:return e.onLastRemoteStoreUnlisten(n);default:return}}function t_(r,t){const e=F(r);let n=!1;for(const s of t){const i=s.query,a=e.queries.get(i);if(a){for(const u of a.wa)u.Ca(s)&&(n=!0);a.ya=s}}n&&ja(e)}function e_(r,t,e){const n=F(r),s=n.queries.get(t);if(s)for(const i of s.wa)i.onError(e);n.queries.delete(t)}function ja(r){r.Da.forEach((t=>{t.next()}))}var ea,wl;(wl=ea||(ea={})).Fa="default",wl.Cache="cache";class za{constructor(t,e,n){this.query=t,this.Ma=e,this.xa=!1,this.Oa=null,this.onlineState="Unknown",this.options=n||{}}Ca(t){if(!this.options.includeMetadataChanges){const n=[];for(const s of t.docChanges)s.type!==3&&n.push(s);t=new mn(t.query,t.docs,t.oldDocs,n,t.mutatedKeys,t.fromCache,t.syncStateChanged,!0,t.hasCachedResults)}let e=!1;return this.xa?this.Na(t)&&(this.Ma.next(t),e=!0):this.Ba(t,this.onlineState)&&(this.La(t),e=!0),this.Oa=t,e}onError(t){this.Ma.error(t)}va(t){this.onlineState=t;let e=!1;return this.Oa&&!this.xa&&this.Ba(this.Oa,t)&&(this.La(this.Oa),e=!0),e}Ba(t,e){if(!t.fromCache||!this.ba())return!0;const n=e!=="Offline";return(!this.options.ka||!n)&&(!t.docs.isEmpty()||t.hasCachedResults||e==="Offline")}Na(t){if(t.docChanges.length>0)return!0;const e=this.Oa&&this.Oa.hasPendingWrites!==t.hasPendingWrites;return!(!t.syncStateChanged&&!e)&&this.options.includeMetadataChanges===!0}La(t){t=mn.fromInitialDocuments(t.query,t.docs,t.mutatedKeys,t.fromCache,t.hasCachedResults),this.xa=!0,this.Ma.next(t)}ba(){return this.options.source!==ea.Cache}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wd{constructor(t,e){this.qa=t,this.byteLength=e}Qa(){return"metadata"in this.qa}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vl{constructor(t){this.serializer=t}Qs(t){return ee(this.serializer,t)}$s(t){return t.metadata.exists?Ni(this.serializer,t.document,!1):at.newNoDocument(this.Qs(t.metadata.name),this.Us(t.metadata.readTime))}Us(t){return gt(t)}}class Ga{constructor(t,e){this.$a=t,this.serializer=e,this.Ua=[],this.Ka=[],this.collectionGroups=new Set,this.progress=Hd(t)}get queries(){return this.Ua}get documents(){return this.Ka}Wa(t){this.progress.bytesLoaded+=t.byteLength;let e=this.progress.documentsLoaded;if(t.qa.namedQuery)this.Ua.push(t.qa.namedQuery);else if(t.qa.documentMetadata){this.Ka.push({metadata:t.qa.documentMetadata}),t.qa.documentMetadata.exists||++e;const n=Q.fromString(t.qa.documentMetadata.name);this.collectionGroups.add(n.get(n.length-2))}else t.qa.document&&(this.Ka[this.Ka.length-1].document=t.qa.document,++e);return e!==this.progress.documentsLoaded?(this.progress.documentsLoaded=e,Object.assign({},this.progress)):null}Ga(t){const e=new Map,n=new vl(this.serializer);for(const s of t)if(s.metadata.queries){const i=n.Qs(s.metadata.name);for(const a of s.metadata.queries){const u=(e.get(a)||G()).add(i);e.set(a,u)}}return e}async za(t){const e=await bp(t,new vl(this.serializer),this.Ka,this.$a.id),n=this.Ga(this.documents);for(const s of this.Ua)await Cp(t,s,n.get(s.name));return this.progress.taskState="Success",{progress:this.progress,ja:this.collectionGroups,Ja:e}}}function Hd(r){return{taskState:"Running",documentsLoaded:0,bytesLoaded:0,totalDocuments:r.totalDocuments,totalBytes:r.totalBytes}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xd{constructor(t){this.key=t}}class Jd{constructor(t){this.key=t}}class Yd{constructor(t,e){this.query=t,this.Ha=e,this.Ya=null,this.hasCachedResults=!1,this.current=!1,this.Za=G(),this.mutatedKeys=G(),this.Xa=Bh(t),this.eu=new rn(this.Xa)}get tu(){return this.Ha}nu(t,e){const n=e?e.ru:new Tl,s=e?e.eu:this.eu;let i=e?e.mutatedKeys:this.mutatedKeys,a=s,u=!1;const c=this.query.limitType==="F"&&s.size===this.query.limit?s.last():null,h=this.query.limitType==="L"&&s.size===this.query.limit?s.first():null;if(t.inorderTraversal(((f,m)=>{const p=s.get(f),R=ds(this.query,m)?m:null,b=!!p&&this.mutatedKeys.has(p.key),D=!!R&&(R.hasLocalMutations||this.mutatedKeys.has(R.key)&&R.hasCommittedMutations);let x=!1;p&&R?p.data.isEqual(R.data)?b!==D&&(n.track({type:3,doc:R}),x=!0):this.iu(p,R)||(n.track({type:2,doc:R}),x=!0,(c&&this.Xa(R,c)>0||h&&this.Xa(R,h)<0)&&(u=!0)):!p&&R?(n.track({type:0,doc:R}),x=!0):p&&!R&&(n.track({type:1,doc:p}),x=!0,(c||h)&&(u=!0)),x&&(R?(a=a.add(R),i=D?i.add(f):i.delete(f)):(a=a.delete(f),i=i.delete(f)))})),this.query.limit!==null)for(;a.size>this.query.limit;){const f=this.query.limitType==="F"?a.last():a.first();a=a.delete(f.key),i=i.delete(f.key),n.track({type:1,doc:f})}return{eu:a,ru:n,Ds:u,mutatedKeys:i}}iu(t,e){return t.hasLocalMutations&&e.hasCommittedMutations&&!e.hasLocalMutations}applyChanges(t,e,n,s){const i=this.eu;this.eu=t.eu,this.mutatedKeys=t.mutatedKeys;const a=t.ru.pa();a.sort(((f,m)=>(function(R,b){const D=x=>{switch(x){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return M(20277,{At:x})}};return D(R)-D(b)})(f.type,m.type)||this.Xa(f.doc,m.doc))),this.su(n),s=s!=null&&s;const u=e&&!s?this.ou():[],c=this.Za.size===0&&this.current&&!s?1:0,h=c!==this.Ya;return this.Ya=c,a.length!==0||h?{snapshot:new mn(this.query,t.eu,i,a,t.mutatedKeys,c===0,h,!1,!!n&&n.resumeToken.approximateByteSize()>0),_u:u}:{_u:u}}va(t){return this.current&&t==="Offline"?(this.current=!1,this.applyChanges({eu:this.eu,ru:new Tl,mutatedKeys:this.mutatedKeys,Ds:!1},!1)):{_u:[]}}au(t){return!this.Ha.has(t)&&!!this.eu.has(t)&&!this.eu.get(t).hasLocalMutations}su(t){t&&(t.addedDocuments.forEach((e=>this.Ha=this.Ha.add(e))),t.modifiedDocuments.forEach((e=>{})),t.removedDocuments.forEach((e=>this.Ha=this.Ha.delete(e))),this.current=t.current)}ou(){if(!this.current)return[];const t=this.Za;this.Za=G(),this.eu.forEach((n=>{this.au(n.key)&&(this.Za=this.Za.add(n.key))}));const e=[];return t.forEach((n=>{this.Za.has(n)||e.push(new Jd(n))})),this.Za.forEach((n=>{t.has(n)||e.push(new Xd(n))})),e}uu(t){this.Ha=t.qs,this.Za=G();const e=this.nu(t.documents);return this.applyChanges(e,!0)}cu(){return mn.fromInitialDocuments(this.query,this.eu,this.mutatedKeys,this.Ya===0,this.hasCachedResults)}}const Ue="SyncEngine";class n_{constructor(t,e,n){this.query=t,this.targetId=e,this.view=n}}class r_{constructor(t){this.key=t,this.lu=!1}}class s_{constructor(t,e,n,s,i,a){this.localStore=t,this.remoteStore=e,this.eventManager=n,this.sharedClientState=s,this.currentUser=i,this.maxConcurrentLimboResolutions=a,this.hu={},this.Pu=new fe((u=>Lh(u)),hs),this.Tu=new Map,this.Iu=new Set,this.du=new it(k.comparator),this.Eu=new Map,this.Au=new Sa,this.Ru={},this.Vu=new Map,this.mu=dn.ur(),this.onlineState="Unknown",this.fu=void 0}get isPrimaryClient(){return this.fu===!0}}async function i_(r,t,e=!0){const n=Bi(r);let s;const i=n.Pu.get(t);return i?(n.sharedClientState.addLocalQueryTarget(i.targetId),s=i.view.cu()):s=await Zd(n,t,e,!0),s}async function o_(r,t){const e=Bi(r);await Zd(e,t,!0,!1)}async function Zd(r,t,e,n){const s=await Jn(r.localStore,kt(t)),i=s.targetId,a=r.sharedClientState.addLocalQueryTarget(i,e);let u;return n&&(u=await Ka(r,t,i,a==="current",s.resumeToken)),r.isPrimaryClient&&e&&qi(r.remoteStore,s),u}async function Ka(r,t,e,n,s){r.gu=(m,p,R)=>(async function(D,x,L,j){let B=x.view.nu(L);B.Ds&&(B=await yi(D.localStore,x.query,!1).then((({documents:T})=>x.view.nu(T,B))));const $=j&&j.targetChanges.get(x.targetId),Y=j&&j.targetMismatches.get(x.targetId)!=null,K=x.view.applyChanges(B,D.isPrimaryClient,$,Y);return na(D,x.targetId,K._u),K.snapshot})(r,m,p,R);const i=await yi(r.localStore,t,!0),a=new Yd(t,i.qs),u=a.nu(i.documents),c=gs.createSynthesizedTargetChangeForCurrentChange(e,n&&r.onlineState!=="Offline",s),h=a.applyChanges(u,r.isPrimaryClient,c);na(r,e,h._u);const f=new n_(t,e,a);return r.Pu.set(t,f),r.Tu.has(e)?r.Tu.get(e).push(t):r.Tu.set(e,[t]),h.snapshot}async function a_(r,t,e){const n=F(r),s=n.Pu.get(t),i=n.Tu.get(s.targetId);if(i.length>1)return n.Tu.set(s.targetId,i.filter((a=>!hs(a,t)))),void n.Pu.delete(t);n.isPrimaryClient?(n.sharedClientState.removeLocalQueryTarget(s.targetId),n.sharedClientState.isActiveQueryTarget(s.targetId)||await Yn(n.localStore,s.targetId,!1).then((()=>{n.sharedClientState.clearQueryState(s.targetId),e&&Zn(n.remoteStore,s.targetId),tr(n,s.targetId)})).catch(Me)):(tr(n,s.targetId),await Yn(n.localStore,s.targetId,!0))}async function u_(r,t){const e=F(r),n=e.Pu.get(t),s=e.Tu.get(n.targetId);e.isPrimaryClient&&s.length===1&&(e.sharedClientState.removeLocalQueryTarget(n.targetId),Zn(e.remoteStore,n.targetId))}async function c_(r,t,e){const n=Ha(r);try{const s=await(function(a,u){const c=F(a),h=Z.now(),f=u.reduce(((R,b)=>R.add(b.key)),G());let m,p;return c.persistence.runTransaction("Locally write mutations","readwrite",(R=>{let b=Bt(),D=G();return c.Os.getEntries(R,f).next((x=>{b=x,b.forEach(((L,j)=>{j.isValidDocument()||(D=D.add(L))}))})).next((()=>c.localDocuments.getOverlayedDocuments(R,b))).next((x=>{m=x;const L=[];for(const j of u){const B=kg(j,m.get(j.key).overlayedDocument);B!=null&&L.push(new me(j.key,B,Vh(B.value.mapValue),lt.exists(!0)))}return c.mutationQueue.addMutationBatch(R,h,L,u)})).next((x=>{p=x;const L=x.applyToLocalDocumentSet(m,D);return c.documentOverlayCache.saveOverlays(R,x.batchId,L)}))})).then((()=>({batchId:p.batchId,changes:jh(m)})))})(n.localStore,t);n.sharedClientState.addPendingMutation(s.batchId),(function(a,u,c){let h=a.Ru[a.currentUser.toKey()];h||(h=new it(z)),h=h.insert(u,c),a.Ru[a.currentUser.toKey()]=h})(n,s.batchId,e),await ge(n,s.changes),await ur(n.remoteStore)}catch(s){const i=lr(s,"Failed to persist write");e.reject(i)}}async function tf(r,t){const e=F(r);try{const n=await Vp(e.localStore,t);t.targetChanges.forEach(((s,i)=>{const a=e.Eu.get(i);a&&(q(s.addedDocuments.size+s.modifiedDocuments.size+s.removedDocuments.size<=1,22616),s.addedDocuments.size>0?a.lu=!0:s.modifiedDocuments.size>0?q(a.lu,14607):s.removedDocuments.size>0&&(q(a.lu,42227),a.lu=!1))})),await ge(e,n,t)}catch(n){await Me(n)}}function Al(r,t,e){const n=F(r);if(n.isPrimaryClient&&e===0||!n.isPrimaryClient&&e===1){const s=[];n.Pu.forEach(((i,a)=>{const u=a.view.va(t);u.snapshot&&s.push(u.snapshot)})),(function(a,u){const c=F(a);c.onlineState=u;let h=!1;c.queries.forEach(((f,m)=>{for(const p of m.wa)p.va(u)&&(h=!0)})),h&&ja(c)})(n.eventManager,t),s.length&&n.hu.J_(s),n.onlineState=t,n.isPrimaryClient&&n.sharedClientState.setOnlineState(t)}}async function l_(r,t,e){const n=F(r);n.sharedClientState.updateQueryState(t,"rejected",e);const s=n.Eu.get(t),i=s&&s.key;if(i){let a=new it(k.comparator);a=a.insert(i,at.newNoDocument(i,U.min()));const u=G().add(i),c=new ms(U.min(),new Map,new it(z),a,u);await tf(n,c),n.du=n.du.remove(i),n.Eu.delete(t),Wa(n)}else await Yn(n.localStore,t,!1).then((()=>tr(n,t,e))).catch(Me)}async function h_(r,t){const e=F(r),n=t.batch.batchId;try{const s=await Pp(e.localStore,t);Qa(e,n,null),$a(e,n),e.sharedClientState.updateMutationState(n,"acknowledged"),await ge(e,s)}catch(s){await Me(s)}}async function d_(r,t,e){const n=F(r);try{const s=await(function(a,u){const c=F(a);return c.persistence.runTransaction("Reject batch","readwrite-primary",(h=>{let f;return c.mutationQueue.lookupMutationBatch(h,u).next((m=>(q(m!==null,37113),f=m.keys(),c.mutationQueue.removeMutationBatch(h,m)))).next((()=>c.mutationQueue.performConsistencyCheck(h))).next((()=>c.documentOverlayCache.removeOverlaysForBatchId(h,f,u))).next((()=>c.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(h,f))).next((()=>c.localDocuments.getDocuments(h,f)))}))})(n.localStore,t);Qa(n,t,e),$a(n,t),n.sharedClientState.updateMutationState(t,"rejected",e),await ge(n,s)}catch(s){await Me(s)}}async function f_(r,t){const e=F(r);Be(e.remoteStore)||N(Ue,"The network is disabled. The task returned by 'awaitPendingWrites()' will not complete until the network is enabled.");try{const n=await(function(a){const u=F(a);return u.persistence.runTransaction("Get highest unacknowledged batch id","readonly",(c=>u.mutationQueue.getHighestUnacknowledgedBatchId(c)))})(e.localStore);if(n===be)return void t.resolve();const s=e.Vu.get(n)||[];s.push(t),e.Vu.set(n,s)}catch(n){const s=lr(n,"Initialization of waitForPendingWrites() operation failed");t.reject(s)}}function $a(r,t){(r.Vu.get(t)||[]).forEach((e=>{e.resolve()})),r.Vu.delete(t)}function Qa(r,t,e){const n=F(r);let s=n.Ru[n.currentUser.toKey()];if(s){const i=s.get(t);i&&(e?i.reject(e):i.resolve(),s=s.remove(t)),n.Ru[n.currentUser.toKey()]=s}}function tr(r,t,e=null){r.sharedClientState.removeLocalQueryTarget(t);for(const n of r.Tu.get(t))r.Pu.delete(n),e&&r.hu.pu(n,e);r.Tu.delete(t),r.isPrimaryClient&&r.Au.zr(t).forEach((n=>{r.Au.containsKey(n)||ef(r,n)}))}function ef(r,t){r.Iu.delete(t.path.canonicalString());const e=r.du.get(t);e!==null&&(Zn(r.remoteStore,e),r.du=r.du.remove(t),r.Eu.delete(e),Wa(r))}function na(r,t,e){for(const n of e)n instanceof Xd?(r.Au.addReference(n.key,t),m_(r,n)):n instanceof Jd?(N(Ue,"Document no longer in limbo: "+n.key),r.Au.removeReference(n.key,t),r.Au.containsKey(n.key)||ef(r,n.key)):M(19791,{yu:n})}function m_(r,t){const e=t.key,n=e.path.canonicalString();r.du.get(e)||r.Iu.has(n)||(N(Ue,"New document in limbo: "+e),r.Iu.add(n),Wa(r))}function Wa(r){for(;r.Iu.size>0&&r.du.size<r.maxConcurrentLimboResolutions;){const t=r.Iu.values().next().value;r.Iu.delete(t);const e=new k(Q.fromString(t)),n=r.mu.next();r.Eu.set(n,new r_(e)),r.du=r.du.insert(e,n),qi(r.remoteStore,new ce(kt(sr(e.path)),n,"TargetPurposeLimboResolution",Lt.ue))}}async function ge(r,t,e){const n=F(r),s=[],i=[],a=[];n.Pu.isEmpty()||(n.Pu.forEach(((u,c)=>{a.push(n.gu(c,t,e).then((h=>{var f;if((h||e)&&n.isPrimaryClient){const m=h?!h.fromCache:(f=e?.targetChanges.get(c.targetId))===null||f===void 0?void 0:f.current;n.sharedClientState.updateQueryState(c.targetId,m?"current":"not-current")}if(h){s.push(h);const m=xa.Es(c.targetId,h);i.push(m)}})))})),await Promise.all(a),n.hu.J_(s),await(async function(c,h){const f=F(c);try{await f.persistence.runTransaction("notifyLocalViewChanges","readwrite",(m=>v.forEach(h,(p=>v.forEach(p.Is,(R=>f.persistence.referenceDelegate.addReference(m,p.targetId,R))).next((()=>v.forEach(p.ds,(R=>f.persistence.referenceDelegate.removeReference(m,p.targetId,R)))))))))}catch(m){if(!Le(m))throw m;N(Na,"Failed to update sequence numbers: "+m)}for(const m of h){const p=m.targetId;if(!m.fromCache){const R=f.Fs.get(p),b=R.snapshotVersion,D=R.withLastLimboFreeSnapshotVersion(b);f.Fs=f.Fs.insert(p,D)}}})(n.localStore,i))}async function g_(r,t){const e=F(r);if(!e.currentUser.isEqual(t)){N(Ue,"User change. New user:",t.toKey());const n=await Dd(e.localStore,t);e.currentUser=t,(function(i,a){i.Vu.forEach((u=>{u.forEach((c=>{c.reject(new C(P.CANCELLED,a))}))})),i.Vu.clear()})(e,"'waitForPendingWrites' promise is rejected due to a user change."),e.sharedClientState.handleUserChange(t,n.removedBatchIds,n.addedBatchIds),await ge(e,n.Bs)}}function p_(r,t){const e=F(r),n=e.Eu.get(t);if(n&&n.lu)return G().add(n.key);{let s=G();const i=e.Tu.get(t);if(!i)return s;for(const a of i){const u=e.Pu.get(a);s=s.unionWith(u.view.tu)}return s}}async function __(r,t){const e=F(r),n=await yi(e.localStore,t.query,!0),s=t.view.uu(n);return e.isPrimaryClient&&na(e,t.targetId,s._u),s}async function y_(r,t){const e=F(r);return Fd(e.localStore,t).then((n=>ge(e,n)))}async function I_(r,t,e,n){const s=F(r),i=await(function(u,c){const h=F(u),f=F(h.mutationQueue);return h.persistence.runTransaction("Lookup mutation documents","readonly",(m=>f.Xn(m,c).next((p=>p?h.localDocuments.getDocuments(m,p):v.resolve(null)))))})(s.localStore,t);i!==null?(e==="pending"?await ur(s.remoteStore):e==="acknowledged"||e==="rejected"?(Qa(s,t,n||null),$a(s,t),(function(u,c){F(F(u).mutationQueue).rr(c)})(s.localStore,t)):M(6720,"Unknown batchState",{wu:e}),await ge(s,i)):N(Ue,"Cannot apply mutation batch with id: "+t)}async function T_(r,t){const e=F(r);if(Bi(e),Ha(e),t===!0&&e.fu!==!0){const n=e.sharedClientState.getAllActiveQueryTargets(),s=await Rl(e,n.toArray());e.fu=!0,await ta(e.remoteStore,!0);for(const i of s)qi(e.remoteStore,i)}else if(t===!1&&e.fu!==!1){const n=[];let s=Promise.resolve();e.Tu.forEach(((i,a)=>{e.sharedClientState.isLocalQueryTarget(a)?n.push(a):s=s.then((()=>(tr(e,a),Yn(e.localStore,a,!0)))),Zn(e.remoteStore,a)})),await s,await Rl(e,n),(function(a){const u=F(a);u.Eu.forEach(((c,h)=>{Zn(u.remoteStore,h)})),u.Au.jr(),u.Eu=new Map,u.du=new it(k.comparator)})(e),e.fu=!1,await ta(e.remoteStore,!1)}}async function Rl(r,t,e){const n=F(r),s=[],i=[];for(const a of t){let u;const c=n.Tu.get(a);if(c&&c.length!==0){u=await Jn(n.localStore,kt(c[0]));for(const h of c){const f=n.Pu.get(h),m=await __(n,f);m.snapshot&&i.push(m.snapshot)}}else{const h=await kd(n.localStore,a);u=await Jn(n.localStore,h),await Ka(n,nf(h),a,!1,u.resumeToken)}s.push(u)}return n.hu.J_(i),s}function nf(r){return Fh(r.path,r.collectionGroup,r.orderBy,r.filters,r.limit,"F",r.startAt,r.endAt)}function E_(r){return(function(e){return F(F(e).persistence).Ps()})(F(r).localStore)}async function w_(r,t,e,n){const s=F(r);if(s.fu)return void N(Ue,"Ignoring unexpected query state notification.");const i=s.Tu.get(t);if(i&&i.length>0)switch(e){case"current":case"not-current":{const a=await Fd(s.localStore,qh(i[0])),u=ms.createSynthesizedRemoteEventForCurrentChange(t,e==="current",ft.EMPTY_BYTE_STRING);await ge(s,a,u);break}case"rejected":await Yn(s.localStore,t,!0),tr(s,t,n);break;default:M(64155,e)}}async function v_(r,t,e){const n=Bi(r);if(n.fu){for(const s of t){if(n.Tu.has(s)&&n.sharedClientState.isActiveQueryTarget(s)){N(Ue,"Adding an already active target "+s);continue}const i=await kd(n.localStore,s),a=await Jn(n.localStore,i);await Ka(n,nf(i),a.targetId,!1,a.resumeToken),qi(n.remoteStore,a)}for(const s of e)n.Tu.has(s)&&await Yn(n.localStore,s,!1).then((()=>{Zn(n.remoteStore,s),tr(n,s)})).catch(Me)}}function Bi(r){const t=F(r);return t.remoteStore.remoteSyncer.applyRemoteEvent=tf.bind(null,t),t.remoteStore.remoteSyncer.getRemoteKeysForTarget=p_.bind(null,t),t.remoteStore.remoteSyncer.rejectListen=l_.bind(null,t),t.hu.J_=t_.bind(null,t.eventManager),t.hu.pu=e_.bind(null,t.eventManager),t}function Ha(r){const t=F(r);return t.remoteStore.remoteSyncer.applySuccessfulWrite=h_.bind(null,t),t.remoteStore.remoteSyncer.rejectFailedWrite=d_.bind(null,t),t}function A_(r,t,e){const n=F(r);(async function(i,a,u){try{const c=await a.getMetadata();if(await(function(R,b){const D=F(R),x=gt(b.createTime);return D.persistence.runTransaction("hasNewerBundle","readonly",(L=>D.Ti.getBundleMetadata(L,b.id))).then((L=>!!L&&L.createTime.compareTo(x)>=0))})(i.localStore,c))return await a.close(),u._completeWith((function(R){return{taskState:"Success",documentsLoaded:R.totalDocuments,bytesLoaded:R.totalBytes,totalDocuments:R.totalDocuments,totalBytes:R.totalBytes}})(c)),Promise.resolve(new Set);u._updateProgress(Hd(c));const h=new Ga(c,a.serializer);let f=await a.Su();for(;f;){const p=await h.Wa(f);p&&u._updateProgress(p),f=await a.Su()}const m=await h.za(i.localStore);return await ge(i,m.Ja,void 0),await(function(R,b){const D=F(R);return D.persistence.runTransaction("Save bundle","readwrite",(x=>D.Ti.saveBundleMetadata(x,b)))})(i.localStore,c),u._completeWith(m.progress),Promise.resolve(m.ja)}catch(c){return Mt(Ue,`Loading bundle failed with ${c}`),u._failWith(c),Promise.resolve(new Set)}})(n,t,e).then((s=>{n.sharedClientState.notifyBundleLoaded(s)}))}class er{constructor(){this.kind="memory",this.synchronizeTabs=!1}async initialize(t){this.serializer=pn(t.databaseInfo.databaseId),this.sharedClientState=this.bu(t),this.persistence=this.Du(t),await this.persistence.start(),this.localStore=this.vu(t),this.gcScheduler=this.Cu(t,this.localStore),this.indexBackfillerScheduler=this.Fu(t,this.localStore)}Cu(t,e){return null}Fu(t,e){return null}vu(t){return Cd(this.persistence,new bd,t.initialUser,this.serializer)}Du(t){return new ba(Li.Vi,this.serializer)}bu(t){return new Bd}async terminate(){var t,e;(t=this.gcScheduler)===null||t===void 0||t.stop(),(e=this.indexBackfillerScheduler)===null||e===void 0||e.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}er.provider={build:()=>new er};class Xa extends er{constructor(t){super(),this.cacheSizeBytes=t}Cu(t,e){q(this.persistence.referenceDelegate instanceof _i,46915);const n=this.persistence.referenceDelegate.garbageCollector;return new vd(n,t.asyncQueue,e)}Du(t){const e=this.cacheSizeBytes!==void 0?xt.withCacheSize(this.cacheSizeBytes):xt.DEFAULT;return new ba((n=>_i.Vi(n,e)),this.serializer)}}class Ja extends er{constructor(t,e,n){super(),this.Mu=t,this.cacheSizeBytes=e,this.forceOwnership=n,this.kind="persistent",this.synchronizeTabs=!1}async initialize(t){await super.initialize(t),await this.Mu.initialize(this,t),await Ha(this.Mu.syncEngine),await ur(this.Mu.remoteStore),await this.persistence.ji((()=>(this.gcScheduler&&!this.gcScheduler.started&&this.gcScheduler.start(),this.indexBackfillerScheduler&&!this.indexBackfillerScheduler.started&&this.indexBackfillerScheduler.start(),Promise.resolve())))}vu(t){return Cd(this.persistence,new bd,t.initialUser,this.serializer)}Cu(t,e){const n=this.persistence.referenceDelegate.garbageCollector;return new vd(n,t.asyncQueue,e)}Fu(t,e){const n=new qm(e,this.persistence);return new Lm(t.asyncQueue,n)}Du(t){const e=Da(t.databaseInfo.databaseId,t.databaseInfo.persistenceKey),n=this.cacheSizeBytes!==void 0?xt.withCacheSize(this.cacheSizeBytes):xt.DEFAULT;return new Ca(this.synchronizeTabs,e,t.clientId,n,t.asyncQueue,Ud(),si(),this.serializer,this.sharedClientState,!!this.forceOwnership)}bu(t){return new Bd}}class rf extends Ja{constructor(t,e){super(t,e,!1),this.Mu=t,this.cacheSizeBytes=e,this.synchronizeTabs=!0}async initialize(t){await super.initialize(t);const e=this.Mu.syncEngine;this.sharedClientState instanceof Vo&&(this.sharedClientState.syncEngine={Do:I_.bind(null,e),vo:w_.bind(null,e),Co:v_.bind(null,e),Ps:E_.bind(null,e),bo:y_.bind(null,e)},await this.sharedClientState.start()),await this.persistence.ji((async n=>{await T_(this.Mu.syncEngine,n),this.gcScheduler&&(n&&!this.gcScheduler.started?this.gcScheduler.start():n||this.gcScheduler.stop()),this.indexBackfillerScheduler&&(n&&!this.indexBackfillerScheduler.started?this.indexBackfillerScheduler.start():n||this.indexBackfillerScheduler.stop())}))}bu(t){const e=Ud();if(!Vo.C(e))throw new C(P.UNIMPLEMENTED,"IndexedDB persistence is only available on platforms that support LocalStorage.");const n=Da(t.databaseInfo.databaseId,t.databaseInfo.persistenceKey);return new Vo(e,t.asyncQueue,n,t.clientId,t.initialUser)}}class Fe{async initialize(t,e){this.localStore||(this.localStore=t.localStore,this.sharedClientState=t.sharedClientState,this.datastore=this.createDatastore(e),this.remoteStore=this.createRemoteStore(e),this.eventManager=this.createEventManager(e),this.syncEngine=this.createSyncEngine(e,!t.synchronizeTabs),this.sharedClientState.onlineStateHandler=n=>Al(this.syncEngine,n,1),this.remoteStore.remoteSyncer.handleCredentialChange=g_.bind(null,this.syncEngine),await ta(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(t){return(function(){return new Zp})()}createDatastore(t){const e=pn(t.databaseInfo.databaseId),n=(function(i){return new Fp(i)})(t.databaseInfo);return(function(i,a,u,c){return new qp(i,a,u,c)})(t.authCredentials,t.appCheckCredentials,n,e)}createRemoteStore(t){return(function(n,s,i,a,u){return new Up(n,s,i,a,u)})(this.localStore,this.datastore,t.asyncQueue,(e=>Al(this.syncEngine,e,0)),(function(){return _l.C()?new _l:new Dp})())}createSyncEngine(t,e){return(function(s,i,a,u,c,h,f){const m=new s_(s,i,a,u,c,h);return f&&(m.fu=!0),m})(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,t.initialUser,t.maxConcurrentLimboResolutions,e)}async terminate(){var t,e;await(async function(s){const i=F(s);N(fn,"RemoteStore shutting down."),i.Ia.add(5),await ar(i),i.Ea.shutdown(),i.Aa.set("Unknown")})(this.remoteStore),(t=this.datastore)===null||t===void 0||t.terminate(),(e=this.eventManager)===null||e===void 0||e.terminate()}}Fe.provider={build:()=>new Fe};function Pl(r,t=10240){let e=0;return{async read(){if(e<r.byteLength){const n={value:r.slice(e,e+t),done:!1};return e+=t,n}return{done:!0}},async cancel(){},releaseLock(){},closed:Promise.resolve()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ui{constructor(t){this.observer=t,this.muted=!1}next(t){this.muted||this.observer.next&&this.xu(this.observer.next,t)}error(t){this.muted||(this.observer.error?this.xu(this.observer.error,t):mt("Uncaught Error in snapshot listener:",t.toString()))}Ou(){this.muted=!0}xu(t,e){setTimeout((()=>{this.muted||t(e)}),0)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class R_{constructor(t,e){this.Nu=t,this.serializer=e,this.metadata=new wt,this.buffer=new Uint8Array,this.Bu=(function(){return new TextDecoder("utf-8")})(),this.Lu().then((n=>{n&&n.Qa()?this.metadata.resolve(n.qa.metadata):this.metadata.reject(new Error(`The first element of the bundle is not a metadata, it is
             ${JSON.stringify(n?.qa)}`))}),(n=>this.metadata.reject(n)))}close(){return this.Nu.cancel()}async getMetadata(){return this.metadata.promise}async Su(){return await this.getMetadata(),this.Lu()}async Lu(){const t=await this.ku();if(t===null)return null;const e=this.Bu.decode(t),n=Number(e);isNaN(n)&&this.qu(`length string (${e}) is not valid number`);const s=await this.Qu(n);return new Wd(JSON.parse(s),t.length+n)}$u(){return this.buffer.findIndex((t=>t===123))}async ku(){for(;this.$u()<0&&!await this.Uu(););if(this.buffer.length===0)return null;const t=this.$u();t<0&&this.qu("Reached the end of bundle when a length string is expected.");const e=this.buffer.slice(0,t);return this.buffer=this.buffer.slice(t),e}async Qu(t){for(;this.buffer.length<t;)await this.Uu()&&this.qu("Reached the end of bundle when more is expected.");const e=this.Bu.decode(this.buffer.slice(0,t));return this.buffer=this.buffer.slice(t),e}qu(t){throw this.Nu.cancel(),new Error(`Invalid bundle format: ${t}`)}async Uu(){const t=await this.Nu.read();if(!t.done){const e=new Uint8Array(this.buffer.length+t.value.length);e.set(this.buffer),e.set(t.value,this.buffer.length),this.buffer=e}return t.done}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class P_{constructor(t,e){this.bundleData=t,this.serializer=e,this.cursor=0,this.elements=[];let n=this.Su();if(!n||!n.Qa())throw new Error(`The first element of the bundle is not a metadata object, it is
         ${JSON.stringify(n?.qa)}`);this.metadata=n;do n=this.Su(),n!==null&&this.elements.push(n);while(n!==null)}getMetadata(){return this.metadata}Ku(){return this.elements}Su(){if(this.cursor===this.bundleData.length)return null;const t=this.ku(),e=this.Qu(t);return new Wd(JSON.parse(e),t)}Qu(t){if(this.cursor+t>this.bundleData.length)throw new C(P.INTERNAL,"Reached the end of bundle when more is expected.");return this.bundleData.slice(this.cursor,this.cursor+=t)}ku(){const t=this.cursor;let e=this.cursor;for(;e<this.bundleData.length;){if(this.bundleData[e]==="{"){if(e===t)throw new Error("First character is a bracket and not a number");return this.cursor=e,Number(this.bundleData.slice(t,e))}e++}throw new Error("Reached the end of bundle when more is expected.")}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class V_{constructor(t){this.datastore=t,this.readVersions=new Map,this.mutations=[],this.committed=!1,this.lastTransactionError=null,this.writtenDocs=new Set}async lookup(t){if(this.ensureCommitNotCalled(),this.mutations.length>0)throw this.lastTransactionError=new C(P.INVALID_ARGUMENT,"Firestore transactions require all reads to be executed before all writes."),this.lastTransactionError;const e=await(async function(s,i){const a=F(s),u={documents:i.map((m=>ns(a.serializer,m)))},c=await a.Jo("BatchGetDocuments",a.serializer.databaseId,Q.emptyPath(),u,i.length),h=new Map;c.forEach((m=>{const p=zg(a.serializer,m);h.set(p.key.toString(),p)}));const f=[];return i.forEach((m=>{const p=h.get(m.toString());q(!!p,55234,{key:m}),f.push(p)})),f})(this.datastore,t);return e.forEach((n=>this.recordVersion(n))),e}set(t,e){this.write(e.toMutation(t,this.precondition(t))),this.writtenDocs.add(t.toString())}update(t,e){try{this.write(e.toMutation(t,this.preconditionForUpdate(t)))}catch(n){this.lastTransactionError=n}this.writtenDocs.add(t.toString())}delete(t){this.write(new or(t,this.precondition(t))),this.writtenDocs.add(t.toString())}async commit(){if(this.ensureCommitNotCalled(),this.lastTransactionError)throw this.lastTransactionError;const t=this.readVersions;this.mutations.forEach((e=>{t.delete(e.key.toString())})),t.forEach(((e,n)=>{const s=k.fromPath(n);this.mutations.push(new Ta(s,this.precondition(s)))})),await(async function(n,s){const i=F(n),a={writes:s.map((u=>rs(i.serializer,u)))};await i.Wo("Commit",i.serializer.databaseId,Q.emptyPath(),a)})(this.datastore,this.mutations),this.committed=!0}recordVersion(t){let e;if(t.isFoundDocument())e=t.version;else{if(!t.isNoDocument())throw M(50498,{Wu:t.constructor.name});e=U.min()}const n=this.readVersions.get(t.key.toString());if(n){if(!e.isEqual(n))throw new C(P.ABORTED,"Document version changed between two reads.")}else this.readVersions.set(t.key.toString(),e)}precondition(t){const e=this.readVersions.get(t.toString());return!this.writtenDocs.has(t.toString())&&e?e.isEqual(U.min())?lt.exists(!1):lt.updateTime(e):lt.none()}preconditionForUpdate(t){const e=this.readVersions.get(t.toString());if(!this.writtenDocs.has(t.toString())&&e){if(e.isEqual(U.min()))throw new C(P.INVALID_ARGUMENT,"Can't update a document that doesn't exist.");return lt.updateTime(e)}return lt.exists(!0)}write(t){this.ensureCommitNotCalled(),this.mutations.push(t)}ensureCommitNotCalled(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class S_{constructor(t,e,n,s,i){this.asyncQueue=t,this.datastore=e,this.options=n,this.updateFunction=s,this.deferred=i,this.Gu=n.maxAttempts,this.F_=new Fa(this.asyncQueue,"transaction_retry")}zu(){this.Gu-=1,this.ju()}ju(){this.F_.g_((async()=>{const t=new V_(this.datastore),e=this.Ju(t);e&&e.then((n=>{this.asyncQueue.enqueueAndForget((()=>t.commit().then((()=>{this.deferred.resolve(n)})).catch((s=>{this.Hu(s)}))))})).catch((n=>{this.Hu(n)}))}))}Ju(t){try{const e=this.updateFunction(t);return!us(e)&&e.catch&&e.then?e:(this.deferred.reject(Error("Transaction callback must return a Promise")),null)}catch(e){return this.deferred.reject(e),null}}Hu(t){this.Gu>0&&this.Yu(t)?(this.Gu-=1,this.asyncQueue.enqueueAndForget((()=>(this.ju(),Promise.resolve())))):this.deferred.reject(t)}Yu(t){if(t.name==="FirebaseError"){const e=t.code;return e==="aborted"||e==="failed-precondition"||e==="already-exists"||!Zh(e)}return!1}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Oe="FirestoreClient";class b_{constructor(t,e,n,s,i){this.authCredentials=t,this.appCheckCredentials=e,this.asyncQueue=n,this.databaseInfo=s,this.user=Et.UNAUTHENTICATED,this.clientId=oa.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this._uninitializedComponentsProvider=i,this.authCredentials.start(n,(async a=>{N(Oe,"Received user=",a.uid),await this.authCredentialListener(a),this.user=a})),this.appCheckCredentials.start(n,(a=>(N(Oe,"Received new app check token=",a),this.appCheckCredentialListener(a,this.user))))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this.databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(t){this.authCredentialListener=t}setAppCheckTokenChangeListener(t){this.appCheckCredentialListener=t}terminate(){this.asyncQueue.enterRestrictedMode();const t=new wt;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted((async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),t.resolve()}catch(e){const n=lr(e,"Failed to shutdown persistence");t.reject(n)}})),t.promise}}async function bo(r,t){r.asyncQueue.verifyOperationInProgress(),N(Oe,"Initializing OfflineComponentProvider");const e=r.configuration;await t.initialize(e);let n=e.initialUser;r.setCredentialChangeListener((async s=>{n.isEqual(s)||(await Dd(t.localStore,s),n=s)})),t.persistence.setDatabaseDeletedListener((()=>{Mt("Terminating Firestore due to IndexedDb database deletion"),r.terminate().then((()=>{N("Terminating Firestore due to IndexedDb database deletion completed successfully")})).catch((s=>{Mt("Terminating Firestore due to IndexedDb database deletion failed",s)}))})),r._offlineComponents=t}async function Vl(r,t){r.asyncQueue.verifyOperationInProgress();const e=await Ya(r);N(Oe,"Initializing OnlineComponentProvider"),await t.initialize(e,r.configuration),r.setCredentialChangeListener((n=>Il(t.remoteStore,n))),r.setAppCheckTokenChangeListener(((n,s)=>Il(t.remoteStore,s))),r._onlineComponents=t}async function Ya(r){if(!r._offlineComponents)if(r._uninitializedComponentsProvider){N(Oe,"Using user provided OfflineComponentProvider");try{await bo(r,r._uninitializedComponentsProvider._offline)}catch(t){const e=t;if(!(function(s){return s.name==="FirebaseError"?s.code===P.FAILED_PRECONDITION||s.code===P.UNIMPLEMENTED:!(typeof DOMException<"u"&&s instanceof DOMException)||s.code===22||s.code===20||s.code===11})(e))throw e;Mt("Error using user provided cache. Falling back to memory cache: "+e),await bo(r,new er)}}else N(Oe,"Using default OfflineComponentProvider"),await bo(r,new Xa(void 0));return r._offlineComponents}async function ji(r){return r._onlineComponents||(r._uninitializedComponentsProvider?(N(Oe,"Using user provided OnlineComponentProvider"),await Vl(r,r._uninitializedComponentsProvider._online)):(N(Oe,"Using default OnlineComponentProvider"),await Vl(r,new Fe))),r._onlineComponents}function sf(r){return Ya(r).then((t=>t.persistence))}function hr(r){return Ya(r).then((t=>t.localStore))}function of(r){return ji(r).then((t=>t.remoteStore))}function Za(r){return ji(r).then((t=>t.syncEngine))}function af(r){return ji(r).then((t=>t.datastore))}async function nr(r){const t=await ji(r),e=t.eventManager;return e.onListen=i_.bind(null,t.syncEngine),e.onUnlisten=a_.bind(null,t.syncEngine),e.onFirstRemoteStoreListen=o_.bind(null,t.syncEngine),e.onLastRemoteStoreUnlisten=u_.bind(null,t.syncEngine),e}function C_(r){return r.asyncQueue.enqueue((async()=>{const t=await sf(r),e=await of(r);return t.setNetworkEnabled(!0),(function(s){const i=F(s);return i.Ia.delete(0),ps(i)})(e)}))}function D_(r){return r.asyncQueue.enqueue((async()=>{const t=await sf(r),e=await of(r);return t.setNetworkEnabled(!1),(async function(s){const i=F(s);i.Ia.add(0),await ar(i),i.Aa.set("Offline")})(e)}))}function x_(r,t){const e=new wt;return r.asyncQueue.enqueueAndForget((async()=>(async function(s,i,a){try{const u=await(function(h,f){const m=F(h);return m.persistence.runTransaction("read document","readonly",(p=>m.localDocuments.getDocument(p,f)))})(s,i);u.isFoundDocument()?a.resolve(u):u.isNoDocument()?a.resolve(null):a.reject(new C(P.UNAVAILABLE,"Failed to get document from cache. (However, this document may exist on the server. Run again without setting 'source' in the GetOptions to attempt to retrieve the document from the server.)"))}catch(u){const c=lr(u,`Failed to get document '${i} from cache`);a.reject(c)}})(await hr(r),t,e))),e.promise}function uf(r,t,e={}){const n=new wt;return r.asyncQueue.enqueueAndForget((async()=>(function(i,a,u,c,h){const f=new Ui({next:p=>{f.Ou(),a.enqueueAndForget((()=>Ua(i,m)));const R=p.docs.has(u);!R&&p.fromCache?h.reject(new C(P.UNAVAILABLE,"Failed to get document because the client is offline.")):R&&p.fromCache&&c&&c.source==="server"?h.reject(new C(P.UNAVAILABLE,'Failed to get document from server. (However, this document does exist in the local cache. Run again without setting source to "server" to retrieve the cached document.)')):h.resolve(p)},error:p=>h.reject(p)}),m=new za(sr(u.path),f,{includeMetadataChanges:!0,ka:!0});return Ba(i,m)})(await nr(r),r.asyncQueue,t,e,n))),n.promise}function N_(r,t){const e=new wt;return r.asyncQueue.enqueueAndForget((async()=>(async function(s,i,a){try{const u=await yi(s,i,!0),c=new Yd(i,u.qs),h=c.nu(u.documents),f=c.applyChanges(h,!1);a.resolve(f.snapshot)}catch(u){const c=lr(u,`Failed to execute query '${i} against cache`);a.reject(c)}})(await hr(r),t,e))),e.promise}function cf(r,t,e={}){const n=new wt;return r.asyncQueue.enqueueAndForget((async()=>(function(i,a,u,c,h){const f=new Ui({next:p=>{f.Ou(),a.enqueueAndForget((()=>Ua(i,m))),p.fromCache&&c.source==="server"?h.reject(new C(P.UNAVAILABLE,'Failed to get documents from server. (However, these documents may exist in the local cache. Run again without setting source to "server" to retrieve the cached documents.)')):h.resolve(p)},error:p=>h.reject(p)}),m=new za(u,f,{includeMetadataChanges:!0,ka:!0});return Ba(i,m)})(await nr(r),r.asyncQueue,t,e,n))),n.promise}function k_(r,t,e){const n=new wt;return r.asyncQueue.enqueueAndForget((async()=>{try{const s=await af(r);n.resolve((async function(a,u,c){var h;const f=F(a),{request:m,ft:p,parent:R}=cd(f.serializer,Oh(u),c);f.connection.Qo||delete m.parent;const b=(await f.Jo("RunAggregationQuery",f.serializer.databaseId,R,m,1)).filter((x=>!!x.result));q(b.length===1,64727);const D=(h=b[0].result)===null||h===void 0?void 0:h.aggregateFields;return Object.keys(D).reduce(((x,L)=>(x[p[L]]=D[L],x)),{})})(s,t,e))}catch(s){n.reject(s)}})),n.promise}function F_(r,t){const e=new Ui(t);return r.asyncQueue.enqueueAndForget((async()=>(function(s,i){F(s).Da.add(i),i.next()})(await nr(r),e))),()=>{e.Ou(),r.asyncQueue.enqueueAndForget((async()=>(function(s,i){F(s).Da.delete(i)})(await nr(r),e)))}}function O_(r,t,e,n){const s=(function(a,u){let c;return c=typeof a=="string"?ia().encode(a):a,(function(f,m){return new R_(f,m)})((function(f,m){if(f instanceof Uint8Array)return Pl(f,m);if(f instanceof ArrayBuffer)return Pl(new Uint8Array(f),m);if(f instanceof ReadableStream)return f.getReader();throw new Error("Source of `toByteStreamReader` has to be a ArrayBuffer or ReadableStream")})(c),u)})(e,pn(t));r.asyncQueue.enqueueAndForget((async()=>{A_(await Za(r),s,n)}))}function M_(r,t){return r.asyncQueue.enqueue((async()=>(function(n,s){const i=F(n);return i.persistence.runTransaction("Get named query","readonly",(a=>i.Ti.getNamedQuery(a,s)))})(await hr(r),t)))}function lf(r,t){return(function(n,s){return new P_(n,s)})(r,t)}function L_(r,t){return r.asyncQueue.enqueue((async()=>(async function(n,s){const i=F(n),a=i.indexManager,u=[];return i.persistence.runTransaction("Configure indexes","readwrite",(c=>a.getFieldIndexes(c).next((h=>(function(m,p,R,b,D){m=[...m],p=[...p],m.sort(R),p.sort(R);const x=m.length,L=p.length;let j=0,B=0;for(;j<L&&B<x;){const $=R(m[B],p[j]);$<0?D(m[B++]):$>0?b(p[j++]):(j++,B++)}for(;j<L;)b(p[j++]);for(;B<x;)D(m[B++])})(h,s,km,(f=>{u.push(a.addFieldIndex(c,f))}),(f=>{u.push(a.deleteFieldIndex(c,f))})))).next((()=>v.waitFor(u)))))})(await hr(r),t)))}function q_(r,t){return r.asyncQueue.enqueue((async()=>(function(n,s){F(n).Cs.Rs=s})(await hr(r),t)))}function B_(r){return r.asyncQueue.enqueue((async()=>(function(e){const n=F(e),s=n.indexManager;return n.persistence.runTransaction("Delete All Indexes","readwrite",(i=>s.deleteAllFieldIndexes(i)))})(await hr(r))))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hf(r){const t={};return r.timeoutSeconds!==void 0&&(t.timeoutSeconds=r.timeoutSeconds),t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Sl=new Map;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const df="firestore.googleapis.com",bl=!0;class Cl{constructor(t){var e,n;if(t.host===void 0){if(t.ssl!==void 0)throw new C(P.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host=df,this.ssl=bl}else this.host=t.host,this.ssl=(e=t.ssl)!==null&&e!==void 0?e:bl;if(this.isUsingEmulator=t.emulatorOptions!==void 0,this.credentials=t.credentials,this.ignoreUndefinedProperties=!!t.ignoreUndefinedProperties,this.localCache=t.localCache,t.cacheSizeBytes===void 0)this.cacheSizeBytes=yd;else{if(t.cacheSizeBytes!==-1&&t.cacheSizeBytes<wd)throw new C(P.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=t.cacheSizeBytes}Nm("experimentalForceLongPolling",t.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",t.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!t.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:t.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!t.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=hf((n=t.experimentalLongPollingOptions)!==null&&n!==void 0?n:{}),(function(i){if(i.timeoutSeconds!==void 0){if(isNaN(i.timeoutSeconds))throw new C(P.INVALID_ARGUMENT,`invalid long polling timeout: ${i.timeoutSeconds} (must not be NaN)`);if(i.timeoutSeconds<5)throw new C(P.INVALID_ARGUMENT,`invalid long polling timeout: ${i.timeoutSeconds} (minimum allowed value is 5)`);if(i.timeoutSeconds>30)throw new C(P.INVALID_ARGUMENT,`invalid long polling timeout: ${i.timeoutSeconds} (maximum allowed value is 30)`)}})(this.experimentalLongPollingOptions),this.useFetchStreams=!!t.useFetchStreams}isEqual(t){return this.host===t.host&&this.ssl===t.ssl&&this.credentials===t.credentials&&this.cacheSizeBytes===t.cacheSizeBytes&&this.experimentalForceLongPolling===t.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===t.experimentalAutoDetectLongPolling&&(function(n,s){return n.timeoutSeconds===s.timeoutSeconds})(this.experimentalLongPollingOptions,t.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===t.ignoreUndefinedProperties&&this.useFetchStreams===t.useFetchStreams}}class _s{constructor(t,e,n,s){this._authCredentials=t,this._appCheckCredentials=e,this._databaseId=n,this._app=s,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new Cl({}),this._settingsFrozen=!1,this._emulatorOptions={},this._terminateTask="notTerminated"}get app(){if(!this._app)throw new C(P.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!=="notTerminated"}_setSettings(t){if(this._settingsFrozen)throw new C(P.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new Cl(t),this._emulatorOptions=t.emulatorOptions||{},t.credentials!==void 0&&(this._authCredentials=(function(n){if(!n)return new Am;switch(n.type){case"firstParty":return new Sm(n.sessionIndex||"0",n.iamToken||null,n.authTokenFactory||null);case"provider":return n.client;default:throw new C(P.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}})(t.credentials))}_getSettings(){return this._settings}_getEmulatorOptions(){return this._emulatorOptions}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask==="notTerminated"&&(this._terminateTask=this._terminate()),this._terminateTask}async _restart(){this._terminateTask==="notTerminated"?await this._terminate():this._terminateTask="notTerminated"}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return(function(e){const n=Sl.get(e);n&&(N("ComponentProvider","Removing Datastore"),Sl.delete(e),n.terminate())})(this),Promise.resolve()}}function U_(r,t,e,n={}){var s;r=W(r,_s);const i=ra(t),a=r._getSettings(),u=Object.assign(Object.assign({},a),{emulatorOptions:r._getEmulatorOptions()}),c=`${t}:${e}`;i&&(Bl(`https://${c}`),fm("Firestore",!0)),a.host!==df&&a.host!==c&&Mt("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used.");const h=Object.assign(Object.assign({},a),{host:c,ssl:i,emulatorOptions:n});if(!as(h,u)&&(r._setSettings(h),n.mockUserToken)){let f,m;if(typeof n.mockUserToken=="string")f=n.mockUserToken,m=Et.MOCK_USER;else{f=mm(n.mockUserToken,(s=r._app)===null||s===void 0?void 0:s.options.projectId);const p=n.mockUserToken.sub||n.mockUserToken.user_id;if(!p)throw new C(P.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");m=new Et(p)}r._authCredentials=new Rm(new Jl(f,m))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vt{constructor(t,e,n){this.converter=e,this._query=n,this.type="query",this.firestore=t}withConverter(t){return new vt(this.firestore,t,this._query)}}class nt{constructor(t,e,n){this.converter=e,this._key=n,this.type="document",this.firestore=t}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new ne(this.firestore,this.converter,this._key.path.popLast())}withConverter(t){return new nt(this.firestore,t,this._key)}toJSON(){return{type:nt._jsonSchemaVersion,referencePath:this._key.toString()}}static fromJSON(t,e,n){if(gn(e,nt._jsonSchema))return new nt(t,n||null,new k(Q.fromString(e.referencePath)))}}nt._jsonSchemaVersion="firestore/documentReference/1.0",nt._jsonSchema={type:_t("string",nt._jsonSchemaVersion),referencePath:_t("string")};class ne extends vt{constructor(t,e,n){super(t,e,sr(n)),this._path=n,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const t=this._path.popLast();return t.isEmpty()?null:new nt(this.firestore,null,new k(t))}withConverter(t){return new ne(this.firestore,t,this._path)}}function yy(r,t,...e){if(r=yt(r),aa("collection","path",t),r instanceof _s){const n=Q.fromString(t,...e);return yc(n),new ne(r,null,n)}{if(!(r instanceof nt||r instanceof ne))throw new C(P.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const n=r._path.child(Q.fromString(t,...e));return yc(n),new ne(r.firestore,null,n)}}function Iy(r,t){if(r=W(r,_s),aa("collectionGroup","collection id",t),t.indexOf("/")>=0)throw new C(P.INVALID_ARGUMENT,`Invalid collection ID '${t}' passed to function collectionGroup(). Collection IDs must not contain '/'.`);return new vt(r,null,(function(n){return new de(Q.emptyPath(),n)})(t))}function j_(r,t,...e){if(r=yt(r),arguments.length===1&&(t=oa.newId()),aa("doc","path",t),r instanceof _s){const n=Q.fromString(t,...e);return _c(n),new nt(r,null,new k(n))}{if(!(r instanceof nt||r instanceof ne))throw new C(P.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const n=r._path.child(Q.fromString(t,...e));return _c(n),new nt(r.firestore,r instanceof ne?r.converter:null,new k(n))}}function Ty(r,t){return r=yt(r),t=yt(t),(r instanceof nt||r instanceof ne)&&(t instanceof nt||t instanceof ne)&&r.firestore===t.firestore&&r.path===t.path&&r.converter===t.converter}function ff(r,t){return r=yt(r),t=yt(t),r instanceof vt&&t instanceof vt&&r.firestore===t.firestore&&hs(r._query,t._query)&&r.converter===t.converter}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Dl="AsyncQueue";class xl{constructor(t=Promise.resolve()){this.Zu=[],this.Xu=!1,this.ec=[],this.tc=null,this.nc=!1,this.rc=!1,this.sc=[],this.F_=new Fa(this,"async_queue_retry"),this.oc=()=>{const n=si();n&&N(Dl,"Visibility state changed to "+n.visibilityState),this.F_.y_()},this._c=t;const e=si();e&&typeof e.addEventListener=="function"&&e.addEventListener("visibilitychange",this.oc)}get isShuttingDown(){return this.Xu}enqueueAndForget(t){this.enqueue(t)}enqueueAndForgetEvenWhileRestricted(t){this.ac(),this.uc(t)}enterRestrictedMode(t){if(!this.Xu){this.Xu=!0,this.rc=t||!1;const e=si();e&&typeof e.removeEventListener=="function"&&e.removeEventListener("visibilitychange",this.oc)}}enqueue(t){if(this.ac(),this.Xu)return new Promise((()=>{}));const e=new wt;return this.uc((()=>this.Xu&&this.rc?Promise.resolve():(t().then(e.resolve,e.reject),e.promise))).then((()=>e.promise))}enqueueRetryable(t){this.enqueueAndForget((()=>(this.Zu.push(t),this.cc())))}async cc(){if(this.Zu.length!==0){try{await this.Zu[0](),this.Zu.shift(),this.F_.reset()}catch(t){if(!Le(t))throw t;N(Dl,"Operation failed with retryable error: "+t)}this.Zu.length>0&&this.F_.g_((()=>this.cc()))}}uc(t){const e=this._c.then((()=>(this.nc=!0,t().catch((n=>{throw this.tc=n,this.nc=!1,mt("INTERNAL UNHANDLED ERROR: ",Nl(n)),n})).then((n=>(this.nc=!1,n))))));return this._c=e,e}enqueueAfterDelay(t,e,n){this.ac(),this.sc.indexOf(t)>-1&&(e=0);const s=qa.createAndSchedule(this,t,e,n,(i=>this.lc(i)));return this.ec.push(s),s}ac(){this.tc&&M(47125,{hc:Nl(this.tc)})}verifyOperationInProgress(){}async Pc(){let t;do t=this._c,await t;while(t!==this._c)}Tc(t){for(const e of this.ec)if(e.timerId===t)return!0;return!1}Ic(t){return this.Pc().then((()=>{this.ec.sort(((e,n)=>e.targetTimeMs-n.targetTimeMs));for(const e of this.ec)if(e.skipDelay(),t!=="all"&&e.timerId===t)break;return this.Pc()}))}dc(t){this.sc.push(t)}lc(t){const e=this.ec.indexOf(t);this.ec.splice(e,1)}}function Nl(r){let t=r.message||"";return r.stack&&(t=r.stack.includes(r.message)?r.stack:r.message+`
`+r.stack),t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function On(r){return(function(e,n){if(typeof e!="object"||e===null)return!1;const s=e;for(const i of n)if(i in s&&typeof s[i]=="function")return!0;return!1})(r,["next","error","complete"])}class z_{constructor(){this._progressObserver={},this._taskCompletionResolver=new wt,this._lastProgress={taskState:"Running",totalBytes:0,totalDocuments:0,bytesLoaded:0,documentsLoaded:0}}onProgress(t,e,n){this._progressObserver={next:t,error:e,complete:n}}catch(t){return this._taskCompletionResolver.promise.catch(t)}then(t,e){return this._taskCompletionResolver.promise.then(t,e)}_completeWith(t){this._updateProgress(t),this._progressObserver.complete&&this._progressObserver.complete(),this._taskCompletionResolver.resolve(t)}_failWith(t){this._lastProgress.taskState="Error",this._progressObserver.next&&this._progressObserver.next(this._lastProgress),this._progressObserver.error&&this._progressObserver.error(t),this._taskCompletionResolver.reject(t)}_updateProgress(t){this._lastProgress=t,this._progressObserver.next&&this._progressObserver.next(t)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ey=-1;class st extends _s{constructor(t,e,n,s){super(t,e,n,s),this.type="firestore",this._queue=new xl,this._persistenceKey=s?.name||"[DEFAULT]"}async _terminate(){if(this._firestoreClient){const t=this._firestoreClient.terminate();this._queue=new xl(t),this._firestoreClient=void 0,await t}}}function wy(r,t,e){e||(e=Yr);const n=Ul(r,"firestore");if(n.isInitialized(e)){const s=n.getImmediate({identifier:e}),i=n.getOptions(e);if(as(i,t))return s;throw new C(P.FAILED_PRECONDITION,"initializeFirestore() has already been called with different options. To avoid this error, call initializeFirestore() with the same options as when it was originally called, or call getFirestore() to return the already initialized instance.")}if(t.cacheSizeBytes!==void 0&&t.localCache!==void 0)throw new C(P.INVALID_ARGUMENT,"cache and cacheSizeBytes cannot be specified at the same time as cacheSizeBytes willbe deprecated. Instead, specify the cache size in the cache object");if(t.cacheSizeBytes!==void 0&&t.cacheSizeBytes!==-1&&t.cacheSizeBytes<wd)throw new C(P.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");return t.host&&ra(t.host)&&Bl(t.host),n.initialize({options:t,instanceIdentifier:e})}function vy(r,t){const e=typeof r=="object"?r:gm(),n=typeof r=="string"?r:t||Yr,s=Ul(e,"firestore").getImmediate({identifier:n});if(!s._initialized){const i=pm("firestore");i&&U_(s,...i)}return s}function ht(r){if(r._terminated)throw new C(P.FAILED_PRECONDITION,"The client has already been terminated.");return r._firestoreClient||mf(r),r._firestoreClient}function mf(r){var t,e,n;const s=r._freezeSettings(),i=(function(u,c,h,f){return new fg(u,c,h,f.host,f.ssl,f.experimentalForceLongPolling,f.experimentalAutoDetectLongPolling,hf(f.experimentalLongPollingOptions),f.useFetchStreams,f.isUsingEmulator)})(r._databaseId,((t=r._app)===null||t===void 0?void 0:t.options.appId)||"",r._persistenceKey,s);r._componentsProvider||!((e=s.localCache)===null||e===void 0)&&e._offlineComponentProvider&&(!((n=s.localCache)===null||n===void 0)&&n._onlineComponentProvider)&&(r._componentsProvider={_offline:s.localCache._offlineComponentProvider,_online:s.localCache._onlineComponentProvider}),r._firestoreClient=new b_(r._authCredentials,r._appCheckCredentials,r._queue,i,r._componentsProvider&&(function(u){const c=u?._online.build();return{_offline:u?._offline.build(c),_online:c}})(r._componentsProvider))}function Ay(r,t){Mt("enableIndexedDbPersistence() will be deprecated in the future, you can use `FirestoreSettings.cache` instead.");const e=r._freezeSettings();return gf(r,Fe.provider,{build:n=>new Ja(n,e.cacheSizeBytes,t?.forceOwnership)}),Promise.resolve()}async function Ry(r){Mt("enableMultiTabIndexedDbPersistence() will be deprecated in the future, you can use `FirestoreSettings.cache` instead.");const t=r._freezeSettings();gf(r,Fe.provider,{build:e=>new rf(e,t.cacheSizeBytes)})}function gf(r,t,e){if((r=W(r,st))._firestoreClient||r._terminated)throw new C(P.FAILED_PRECONDITION,"Firestore has already been started and persistence can no longer be enabled. You can only enable persistence before calling any other methods on a Firestore object.");if(r._componentsProvider||r._getSettings().localCache)throw new C(P.FAILED_PRECONDITION,"SDK cache is already specified.");r._componentsProvider={_online:t,_offline:e},mf(r)}function Py(r){if(r._initialized&&!r._terminated)throw new C(P.FAILED_PRECONDITION,"Persistence can only be cleared before a Firestore instance is initialized or after it is terminated.");const t=new wt;return r._queue.enqueueAndForgetEvenWhileRestricted((async()=>{try{await(async function(n){if(!te.C())return Promise.resolve();const s=n+Sd;await te.delete(s)})(Da(r._databaseId,r._persistenceKey)),t.resolve()}catch(e){t.reject(e)}})),t.promise}function Vy(r){return(function(e){const n=new wt;return e.asyncQueue.enqueueAndForget((async()=>f_(await Za(e),n))),n.promise})(ht(r=W(r,st)))}function Sy(r){return C_(ht(r=W(r,st)))}function by(r){return D_(ht(r=W(r,st)))}function Cy(r){return _m(r.app,"firestore",r._databaseId.database),r._delete()}function kl(r,t){const e=ht(r=W(r,st)),n=new z_;return O_(e,r._databaseId,t,n),n}function G_(r,t){return M_(ht(r=W(r,st)),t).then((e=>e?new vt(r,null,e.query):null))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ss{constructor(t="count",e){this._internalFieldPath=e,this.type="AggregateField",this.aggregateType=t}}class K_{constructor(t,e,n){this._userDataWriter=e,this._data=n,this.type="AggregateQuerySnapshot",this.query=t}data(){return this._userDataWriter.convertObjectMap(this._data)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zt{constructor(t){this._byteString=t}static fromBase64String(t){try{return new zt(ft.fromBase64String(t))}catch(e){throw new C(P.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+e)}}static fromUint8Array(t){return new zt(ft.fromUint8Array(t))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(t){return this._byteString.isEqual(t._byteString)}toJSON(){return{type:zt._jsonSchemaVersion,bytes:this.toBase64()}}static fromJSON(t){if(gn(t,zt._jsonSchema))return zt.fromBase64String(t.bytes)}}zt._jsonSchemaVersion="firestore/bytes/1.0",zt._jsonSchema={type:_t("string",zt._jsonSchemaVersion),bytes:_t("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _n{constructor(...t){for(let e=0;e<t.length;++e)if(t[e].length===0)throw new C(P.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new ct(t)}isEqual(t){return this._internalPath.isEqual(t._internalPath)}}function Dy(){return new _n(No)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yn{constructor(t){this._methodName=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class re{constructor(t,e){if(!isFinite(t)||t<-90||t>90)throw new C(P.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+t);if(!isFinite(e)||e<-180||e>180)throw new C(P.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+e);this._lat=t,this._long=e}get latitude(){return this._lat}get longitude(){return this._long}isEqual(t){return this._lat===t._lat&&this._long===t._long}_compareTo(t){return z(this._lat,t._lat)||z(this._long,t._long)}toJSON(){return{latitude:this._lat,longitude:this._long,type:re._jsonSchemaVersion}}static fromJSON(t){if(gn(t,re._jsonSchema))return new re(t.latitude,t.longitude)}}re._jsonSchemaVersion="firestore/geoPoint/1.0",re._jsonSchema={type:_t("string",re._jsonSchemaVersion),latitude:_t("number"),longitude:_t("number")};/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ht{constructor(t){this._values=(t||[]).map((e=>e))}toArray(){return this._values.map((t=>t))}isEqual(t){return(function(n,s){if(n.length!==s.length)return!1;for(let i=0;i<n.length;++i)if(n[i]!==s[i])return!1;return!0})(this._values,t._values)}toJSON(){return{type:Ht._jsonSchemaVersion,vectorValues:this._values}}static fromJSON(t){if(gn(t,Ht._jsonSchema)){if(Array.isArray(t.vectorValues)&&t.vectorValues.every((e=>typeof e=="number")))return new Ht(t.vectorValues);throw new C(P.INVALID_ARGUMENT,"Expected 'vectorValues' field to be a number array")}}}Ht._jsonSchemaVersion="firestore/vectorValue/1.0",Ht._jsonSchema={type:_t("string",Ht._jsonSchemaVersion),vectorValues:_t("object")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $_=/^__.*__$/;class Q_{constructor(t,e,n){this.data=t,this.fieldMask=e,this.fieldTransforms=n}toMutation(t,e){return this.fieldMask!==null?new me(t,this.data,this.fieldMask,e,this.fieldTransforms):new ir(t,this.data,e,this.fieldTransforms)}}class pf{constructor(t,e,n){this.data=t,this.fieldMask=e,this.fieldTransforms=n}toMutation(t,e){return new me(t,this.data,this.fieldMask,e,this.fieldTransforms)}}function _f(r){switch(r){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw M(40011,{Ec:r})}}class zi{constructor(t,e,n,s,i,a){this.settings=t,this.databaseId=e,this.serializer=n,this.ignoreUndefinedProperties=s,i===void 0&&this.Ac(),this.fieldTransforms=i||[],this.fieldMask=a||[]}get path(){return this.settings.path}get Ec(){return this.settings.Ec}Rc(t){return new zi(Object.assign(Object.assign({},this.settings),t),this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}Vc(t){var e;const n=(e=this.path)===null||e===void 0?void 0:e.child(t),s=this.Rc({path:n,mc:!1});return s.fc(t),s}gc(t){var e;const n=(e=this.path)===null||e===void 0?void 0:e.child(t),s=this.Rc({path:n,mc:!1});return s.Ac(),s}yc(t){return this.Rc({path:void 0,mc:!0})}wc(t){return wi(t,this.settings.methodName,this.settings.Sc||!1,this.path,this.settings.bc)}contains(t){return this.fieldMask.find((e=>t.isPrefixOf(e)))!==void 0||this.fieldTransforms.find((e=>t.isPrefixOf(e.field)))!==void 0}Ac(){if(this.path)for(let t=0;t<this.path.length;t++)this.fc(this.path.get(t))}fc(t){if(t.length===0)throw this.wc("Document fields must not be empty");if(_f(this.Ec)&&$_.test(t))throw this.wc('Document fields cannot begin and end with "__"')}}class W_{constructor(t,e,n){this.databaseId=t,this.ignoreUndefinedProperties=e,this.serializer=n||pn(t)}Dc(t,e,n,s=!1){return new zi({Ec:t,methodName:e,bc:n,path:ct.emptyPath(),mc:!1,Sc:s},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function In(r){const t=r._freezeSettings(),e=pn(r._databaseId);return new W_(r._databaseId,!!t.ignoreUndefinedProperties,e)}function Gi(r,t,e,n,s,i={}){const a=r.Dc(i.merge||i.mergeFields?2:0,t,e,s);ou("Data must be an object, but it was:",a,n);const u=Tf(n,a);let c,h;if(i.merge)c=new qt(a.fieldMask),h=a.fieldTransforms;else if(i.mergeFields){const f=[];for(const m of i.mergeFields){const p=is(t,m,e);if(!a.contains(p))throw new C(P.INVALID_ARGUMENT,`Field '${p}' is specified in your field mask but missing from your input data.`);wf(f,p)||f.push(p)}c=new qt(f),h=a.fieldTransforms.filter((m=>c.covers(m.field)))}else c=null,h=a.fieldTransforms;return new Q_(new Pt(u),c,h)}class ys extends yn{_toFieldTransform(t){if(t.Ec!==2)throw t.Ec===1?t.wc(`${this._methodName}() can only appear at the top level of your update data`):t.wc(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return t.fieldMask.push(t.path),null}isEqual(t){return t instanceof ys}}function yf(r,t,e){return new zi({Ec:3,bc:t.settings.bc,methodName:r._methodName,mc:e},t.databaseId,t.serializer,t.ignoreUndefinedProperties)}class tu extends yn{_toFieldTransform(t){return new fs(t.path,new Wn)}isEqual(t){return t instanceof tu}}class eu extends yn{constructor(t,e){super(t),this.vc=e}_toFieldTransform(t){const e=yf(this,t,!0),n=this.vc.map((i=>Tn(i,e))),s=new un(n);return new fs(t.path,s)}isEqual(t){return t instanceof eu&&as(this.vc,t.vc)}}class nu extends yn{constructor(t,e){super(t),this.vc=e}_toFieldTransform(t){const e=yf(this,t,!0),n=this.vc.map((i=>Tn(i,e))),s=new cn(n);return new fs(t.path,s)}isEqual(t){return t instanceof nu&&as(this.vc,t.vc)}}class ru extends yn{constructor(t,e){super(t),this.Cc=e}_toFieldTransform(t){const e=new Hn(t.serializer,Kh(t.serializer,this.Cc));return new fs(t.path,e)}isEqual(t){return t instanceof ru&&this.Cc===t.Cc}}function su(r,t,e,n){const s=r.Dc(1,t,e);ou("Data must be an object, but it was:",s,n);const i=[],a=Pt.empty();qe(n,((c,h)=>{const f=Ki(t,c,e);h=yt(h);const m=s.gc(f);if(h instanceof ys)i.push(f);else{const p=Tn(h,m);p!=null&&(i.push(f),a.set(f,p))}}));const u=new qt(i);return new pf(a,u,s.fieldTransforms)}function iu(r,t,e,n,s,i){const a=r.Dc(1,t,e),u=[is(t,n,e)],c=[s];if(i.length%2!=0)throw new C(P.INVALID_ARGUMENT,`Function ${t}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let p=0;p<i.length;p+=2)u.push(is(t,i[p])),c.push(i[p+1]);const h=[],f=Pt.empty();for(let p=u.length-1;p>=0;--p)if(!wf(h,u[p])){const R=u[p];let b=c[p];b=yt(b);const D=a.gc(R);if(b instanceof ys)h.push(R);else{const x=Tn(b,D);x!=null&&(h.push(R),f.set(R,x))}}const m=new qt(h);return new pf(f,m,a.fieldTransforms)}function If(r,t,e,n=!1){return Tn(e,r.Dc(n?4:3,t))}function Tn(r,t){if(Ef(r=yt(r)))return ou("Unsupported field value:",t,r),Tf(r,t);if(r instanceof yn)return(function(n,s){if(!_f(s.Ec))throw s.wc(`${n._methodName}() can only be used with update() and set()`);if(!s.path)throw s.wc(`${n._methodName}() is not currently supported inside arrays`);const i=n._toFieldTransform(s);i&&s.fieldTransforms.push(i)})(r,t),null;if(r===void 0&&t.ignoreUndefinedProperties)return null;if(t.path&&t.fieldMask.push(t.path),r instanceof Array){if(t.settings.mc&&t.Ec!==4)throw t.wc("Nested arrays are not supported");return(function(n,s){const i=[];let a=0;for(const u of n){let c=Tn(u,s.yc(a));c==null&&(c={nullValue:"NULL_VALUE"}),i.push(c),a++}return{arrayValue:{values:i}}})(r,t)}return(function(n,s){if((n=yt(n))===null)return{nullValue:"NULL_VALUE"};if(typeof n=="number")return Kh(s.serializer,n);if(typeof n=="boolean")return{booleanValue:n};if(typeof n=="string")return{stringValue:n};if(n instanceof Date){const i=Z.fromDate(n);return{timestampValue:Xn(s.serializer,i)}}if(n instanceof Z){const i=new Z(n.seconds,1e3*Math.floor(n.nanoseconds/1e3));return{timestampValue:Xn(s.serializer,i)}}if(n instanceof re)return{geoPointValue:{latitude:n.latitude,longitude:n.longitude}};if(n instanceof zt)return{bytesValue:rd(s.serializer,n._byteString)};if(n instanceof nt){const i=s.databaseId,a=n.firestore._databaseId;if(!a.isEqual(i))throw s.wc(`Document reference is for database ${a.projectId}/${a.database} but should be for database ${i.projectId}/${i.database}`);return{referenceValue:Ra(n.firestore._databaseId||s.databaseId,n._key.path)}}if(n instanceof Ht)return(function(a,u){return{mapValue:{fields:{[ma]:{stringValue:ga},[Kn]:{arrayValue:{values:a.toArray().map((h=>{if(typeof h!="number")throw u.wc("VectorValues must only contain numeric values.");return Ia(u.serializer,h)}))}}}}}})(n,s);throw s.wc(`Unsupported field value: ${vi(n)}`)})(r,t)}function Tf(r,t){const e={};return yh(r)?t.path&&t.path.length>0&&t.fieldMask.push(t.path):qe(r,((n,s)=>{const i=Tn(s,t.Vc(n));i!=null&&(e[n]=i)})),{mapValue:{fields:e}}}function Ef(r){return!(typeof r!="object"||r===null||r instanceof Array||r instanceof Date||r instanceof Z||r instanceof re||r instanceof zt||r instanceof nt||r instanceof yn||r instanceof Ht)}function ou(r,t,e){if(!Ef(e)||!Zl(e)){const n=vi(e);throw n==="an object"?t.wc(r+" a custom object"):t.wc(r+" "+n)}}function is(r,t,e){if((t=yt(t))instanceof _n)return t._internalPath;if(typeof t=="string")return Ki(r,t);throw wi("Field path arguments must be of type string or ",r,!1,void 0,e)}const H_=new RegExp("[~\\*/\\[\\]]");function Ki(r,t,e){if(t.search(H_)>=0)throw wi(`Invalid field path (${t}). Paths must not contain '~', '*', '/', '[', or ']'`,r,!1,void 0,e);try{return new _n(...t.split("."))._internalPath}catch{throw wi(`Invalid field path (${t}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,r,!1,void 0,e)}}function wi(r,t,e,n,s){const i=n&&!n.isEmpty(),a=s!==void 0;let u=`Function ${t}() called with invalid data`;e&&(u+=" (via `toFirestore()`)"),u+=". ";let c="";return(i||a)&&(c+=" (found",i&&(c+=` in field ${n}`),a&&(c+=` in document ${s}`),c+=")"),new C(P.INVALID_ARGUMENT,u+r+c)}function wf(r,t){return r.some((e=>e.isEqual(t)))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class os{constructor(t,e,n,s,i){this._firestore=t,this._userDataWriter=e,this._key=n,this._document=s,this._converter=i}get id(){return this._key.path.lastSegment()}get ref(){return new nt(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const t=new X_(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(t)}return this._userDataWriter.convertValue(this._document.data.value)}}get(t){if(this._document){const e=this._document.data.field($i("DocumentSnapshot.get",t));if(e!==null)return this._userDataWriter.convertValue(e)}}}class X_ extends os{data(){return super.data()}}function $i(r,t){return typeof t=="string"?Ki(r,t):t instanceof _n?t._internalPath:t._delegate._internalPath}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function vf(r){if(r.limitType==="L"&&r.explicitOrderBy.length===0)throw new C(P.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class au{}class Is extends au{}function xy(r,t,...e){let n=[];t instanceof au&&n.push(t),n=n.concat(e),(function(i){const a=i.filter((c=>c instanceof dr)).length,u=i.filter((c=>c instanceof Ts)).length;if(a>1||a>0&&u>0)throw new C(P.INVALID_ARGUMENT,"InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.")})(n);for(const s of n)r=s._apply(r);return r}class Ts extends Is{constructor(t,e,n){super(),this._field=t,this._op=e,this._value=n,this.type="where"}static _create(t,e,n){return new Ts(t,e,n)}_apply(t){const e=this._parse(t);return Rf(t._query,e),new vt(t.firestore,t.converter,Go(t._query,e))}_parse(t){const e=In(t.firestore);return(function(i,a,u,c,h,f,m){let p;if(h.isKeyField()){if(f==="array-contains"||f==="array-contains-any")throw new C(P.INVALID_ARGUMENT,`Invalid Query. You can't perform '${f}' queries on documentId().`);if(f==="in"||f==="not-in"){Ol(m,f);const b=[];for(const D of m)b.push(Fl(c,i,D));p={arrayValue:{values:b}}}else p=Fl(c,i,m)}else f!=="in"&&f!=="not-in"&&f!=="array-contains-any"||Ol(m,f),p=If(u,a,m,f==="in"||f==="not-in");return H.create(h,f,p)})(t._query,"where",e,t.firestore._databaseId,this._field,this._op,this._value)}}function Ny(r,t,e){const n=t,s=$i("where",r);return Ts._create(s,n,e)}class dr extends au{constructor(t,e){super(),this.type=t,this._queryConstraints=e}static _create(t,e){return new dr(t,e)}_parse(t){const e=this._queryConstraints.map((n=>n._parse(t))).filter((n=>n.getFilters().length>0));return e.length===1?e[0]:tt.create(e,this._getOperator())}_apply(t){const e=this._parse(t);return e.getFilters().length===0?t:((function(s,i){let a=s;const u=i.getFlattenedFilters();for(const c of u)Rf(a,c),a=Go(a,c)})(t._query,e),new vt(t.firestore,t.converter,Go(t._query,e)))}_getQueryConstraints(){return this._queryConstraints}_getOperator(){return this.type==="and"?"and":"or"}}function ky(...r){return r.forEach((t=>Pf("or",t))),dr._create("or",r)}function Fy(...r){return r.forEach((t=>Pf("and",t))),dr._create("and",r)}class uu extends Is{constructor(t,e){super(),this._field=t,this._direction=e,this.type="orderBy"}static _create(t,e){return new uu(t,e)}_apply(t){const e=(function(s,i,a){if(s.startAt!==null)throw new C(P.INVALID_ARGUMENT,"Invalid query. You must not call startAt() or startAfter() before calling orderBy().");if(s.endAt!==null)throw new C(P.INVALID_ARGUMENT,"Invalid query. You must not call endAt() or endBefore() before calling orderBy().");return new es(i,a)})(t._query,this._field,this._direction);return new vt(t.firestore,t.converter,(function(s,i){const a=s.explicitOrderBy.concat([i]);return new de(s.path,s.collectionGroup,a,s.filters.slice(),s.limit,s.limitType,s.startAt,s.endAt)})(t._query,e))}}function Oy(r,t="asc"){const e=t,n=$i("orderBy",r);return uu._create(n,e)}class Qi extends Is{constructor(t,e,n){super(),this.type=t,this._limit=e,this._limitType=n}static _create(t,e,n){return new Qi(t,e,n)}_apply(t){return new vt(t.firestore,t.converter,di(t._query,this._limit,this._limitType))}}function My(r){return th("limit",r),Qi._create("limit",r,"F")}function Ly(r){return th("limitToLast",r),Qi._create("limitToLast",r,"L")}class Wi extends Is{constructor(t,e,n){super(),this.type=t,this._docOrFields=e,this._inclusive=n}static _create(t,e,n){return new Wi(t,e,n)}_apply(t){const e=Af(t,this.type,this._docOrFields,this._inclusive);return new vt(t.firestore,t.converter,(function(s,i){return new de(s.path,s.collectionGroup,s.explicitOrderBy.slice(),s.filters.slice(),s.limit,s.limitType,i,s.endAt)})(t._query,e))}}function qy(...r){return Wi._create("startAt",r,!0)}function By(...r){return Wi._create("startAfter",r,!1)}class Hi extends Is{constructor(t,e,n){super(),this.type=t,this._docOrFields=e,this._inclusive=n}static _create(t,e,n){return new Hi(t,e,n)}_apply(t){const e=Af(t,this.type,this._docOrFields,this._inclusive);return new vt(t.firestore,t.converter,(function(s,i){return new de(s.path,s.collectionGroup,s.explicitOrderBy.slice(),s.filters.slice(),s.limit,s.limitType,s.startAt,i)})(t._query,e))}}function Uy(...r){return Hi._create("endBefore",r,!1)}function jy(...r){return Hi._create("endAt",r,!0)}function Af(r,t,e,n){if(e[0]=yt(e[0]),e[0]instanceof os)return(function(i,a,u,c,h){if(!c)throw new C(P.NOT_FOUND,`Can't use a DocumentSnapshot that doesn't exist for ${u}().`);const f=[];for(const m of Fn(i))if(m.field.isKeyField())f.push(on(a,c.key));else{const p=c.data.field(m.field);if(Si(p))throw new C(P.INVALID_ARGUMENT,'Invalid query. You are trying to start or end a query using a document for which the field "'+m.field+'" is an uncommitted server timestamp. (Since the value of this field is unknown, you cannot start/end a query with it.)');if(p===null){const R=m.field.canonicalString();throw new C(P.INVALID_ARGUMENT,`Invalid query. You are trying to start or end a query using a document for which the field '${R}' (used as the orderBy) does not exist.`)}f.push(p)}return new Ne(f,h)})(r._query,r.firestore._databaseId,t,e[0]._document,n);{const s=In(r.firestore);return(function(a,u,c,h,f,m){const p=a.explicitOrderBy;if(f.length>p.length)throw new C(P.INVALID_ARGUMENT,`Too many arguments provided to ${h}(). The number of arguments must be less than or equal to the number of orderBy() clauses`);const R=[];for(let b=0;b<f.length;b++){const D=f[b];if(p[b].field.isKeyField()){if(typeof D!="string")throw new C(P.INVALID_ARGUMENT,`Invalid query. Expected a string for document ID in ${h}(), but got a ${typeof D}`);if(!_a(a)&&D.indexOf("/")!==-1)throw new C(P.INVALID_ARGUMENT,`Invalid query. When querying a collection and ordering by documentId(), the value passed to ${h}() must be a plain document ID, but '${D}' contains a slash.`);const x=a.path.child(Q.fromString(D));if(!k.isDocumentKey(x))throw new C(P.INVALID_ARGUMENT,`Invalid query. When querying a collection group and ordering by documentId(), the value passed to ${h}() must result in a valid document path, but '${x}' is not because it contains an odd number of segments.`);const L=new k(x);R.push(on(u,L))}else{const x=If(c,h,D);R.push(x)}}return new Ne(R,m)})(r._query,r.firestore._databaseId,s,t,e,n)}}function Fl(r,t,e){if(typeof(e=yt(e))=="string"){if(e==="")throw new C(P.INVALID_ARGUMENT,"Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");if(!_a(t)&&e.indexOf("/")!==-1)throw new C(P.INVALID_ARGUMENT,`Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${e}' contains a '/' character.`);const n=t.path.child(Q.fromString(e));if(!k.isDocumentKey(n))throw new C(P.INVALID_ARGUMENT,`Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${n}' is not because it has an odd number of segments (${n.length}).`);return on(r,new k(n))}if(e instanceof nt)return on(r,e._key);throw new C(P.INVALID_ARGUMENT,`Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${vi(e)}.`)}function Ol(r,t){if(!Array.isArray(r)||r.length===0)throw new C(P.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${t.toString()}' filters.`)}function Rf(r,t){const e=(function(s,i){for(const a of s)for(const u of a.getFlattenedFilters())if(i.indexOf(u.op)>=0)return u.op;return null})(r.filters,(function(s){switch(s){case"!=":return["!=","not-in"];case"array-contains-any":case"in":return["not-in"];case"not-in":return["array-contains-any","in","not-in","!="];default:return[]}})(t.op));if(e!==null)throw e===t.op?new C(P.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${t.op.toString()}' filter.`):new C(P.INVALID_ARGUMENT,`Invalid query. You cannot use '${t.op.toString()}' filters with '${e.toString()}' filters.`)}function Pf(r,t){if(!(t instanceof Ts||t instanceof dr))throw new C(P.INVALID_ARGUMENT,`Function ${r}() requires AppliableConstraints created with a call to 'where(...)', 'or(...)', or 'and(...)'.`)}class Vf{convertValue(t,e="none"){switch(De(t)){case 0:return null;case 1:return t.booleanValue;case 2:return ut(t.integerValue||t.doubleValue);case 3:return this.convertTimestamp(t.timestampValue);case 4:return this.convertServerTimestamp(t,e);case 5:return t.stringValue;case 6:return this.convertBytes(he(t.bytesValue));case 7:return this.convertReference(t.referenceValue);case 8:return this.convertGeoPoint(t.geoPointValue);case 9:return this.convertArray(t.arrayValue,e);case 11:return this.convertObject(t.mapValue,e);case 10:return this.convertVectorValue(t.mapValue);default:throw M(62114,{value:t})}}convertObject(t,e){return this.convertObjectMap(t.fields,e)}convertObjectMap(t,e="none"){const n={};return qe(t,((s,i)=>{n[s]=this.convertValue(i,e)})),n}convertVectorValue(t){var e,n,s;const i=(s=(n=(e=t.fields)===null||e===void 0?void 0:e[Kn].arrayValue)===null||n===void 0?void 0:n.values)===null||s===void 0?void 0:s.map((a=>ut(a.doubleValue)));return new Ht(i)}convertGeoPoint(t){return new re(ut(t.latitude),ut(t.longitude))}convertArray(t,e){return(t.values||[]).map((n=>this.convertValue(n,e)))}convertServerTimestamp(t,e){switch(e){case"previous":const n=bi(t);return n==null?null:this.convertValue(n,e);case"estimate":return this.convertTimestamp(Jr(t));default:return null}}convertTimestamp(t){const e=le(t);return new Z(e.seconds,e.nanos)}convertDocumentKey(t,e){const n=Q.fromString(t);q(fd(n),9688,{name:t});const s=new sn(n.get(1),n.get(3)),i=new k(n.popFirst(5));return s.isEqual(e)||mt(`Document ${i} contains a document reference within a different database (${s.projectId}/${s.database}) which is not supported. It will be treated as a reference in the current database (${e.projectId}/${e.database}) instead.`),i}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xi(r,t,e){let n;return n=r?e&&(e.merge||e.mergeFields)?r.toFirestore(t,e):r.toFirestore(t):t,n}class cu extends Vf{constructor(t){super(),this.firestore=t}convertBytes(t){return new zt(t)}convertReference(t){const e=this.convertDocumentKey(t,this.firestore._databaseId);return new nt(this.firestore,null,e)}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function zy(r){return new ss("sum",is("sum",r))}function Gy(r){return new ss("avg",is("average",r))}function J_(){return new ss("count")}function Ky(r,t){var e,n;return r instanceof ss&&t instanceof ss&&r.aggregateType===t.aggregateType&&((e=r._internalFieldPath)===null||e===void 0?void 0:e.canonicalString())===((n=t._internalFieldPath)===null||n===void 0?void 0:n.canonicalString())}function $y(r,t){return ff(r.query,t.query)&&as(r.data(),t.data())}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Sf="NOT SUPPORTED";class Pe{constructor(t,e){this.hasPendingWrites=t,this.fromCache=e}isEqual(t){return this.hasPendingWrites===t.hasPendingWrites&&this.fromCache===t.fromCache}}class Gt extends os{constructor(t,e,n,s,i,a){super(t,e,n,s,a),this._firestore=t,this._firestoreImpl=t,this.metadata=i}exists(){return super.exists()}data(t={}){if(this._document){if(this._converter){const e=new ii(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(e,t)}return this._userDataWriter.convertValue(this._document.data.value,t.serverTimestamps)}}get(t,e={}){if(this._document){const n=this._document.data.field($i("DocumentSnapshot.get",t));if(n!==null)return this._userDataWriter.convertValue(n,e.serverTimestamps)}}toJSON(){if(this.metadata.hasPendingWrites)throw new C(P.FAILED_PRECONDITION,"DocumentSnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const t=this._document,e={};return e.type=Gt._jsonSchemaVersion,e.bundle="",e.bundleSource="DocumentSnapshot",e.bundleName=this._key.toString(),!t||!t.isValidDocument()||!t.isFoundDocument()?e:(this._userDataWriter.convertObjectMap(t.data.value.mapValue.fields,"previous"),e.bundle=(this._firestore,this.ref.path,"NOT SUPPORTED"),e)}}function Qy(r,t,e){if(gn(t,Gt._jsonSchema)){if(t.bundle===Sf)throw new C(P.INVALID_ARGUMENT,"The provided JSON object was created in a client environment, which is not supported.");const n=pn(r._databaseId),s=lf(t.bundle,n),i=s.Ku(),a=new Ga(s.getMetadata(),n);for(const f of i)a.Wa(f);const u=a.documents;if(u.length!==1)throw new C(P.INVALID_ARGUMENT,`Expected bundle data to contain 1 document, but it contains ${u.length} documents.`);const c=Ni(n,u[0].document),h=new k(Q.fromString(t.bundleName));return new Gt(r,new cu(r),h,c,new Pe(!1,!1),e||null)}}Gt._jsonSchemaVersion="firestore/documentSnapshot/1.0",Gt._jsonSchema={type:_t("string",Gt._jsonSchemaVersion),bundleSource:_t("string","DocumentSnapshot"),bundleName:_t("string"),bundle:_t("string")};class ii extends Gt{data(t={}){return super.data(t)}}class Kt{constructor(t,e,n,s){this._firestore=t,this._userDataWriter=e,this._snapshot=s,this.metadata=new Pe(s.hasPendingWrites,s.fromCache),this.query=n}get docs(){const t=[];return this.forEach((e=>t.push(e))),t}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(t,e){this._snapshot.docs.forEach((n=>{t.call(e,new ii(this._firestore,this._userDataWriter,n.key,n,new Pe(this._snapshot.mutatedKeys.has(n.key),this._snapshot.fromCache),this.query.converter))}))}docChanges(t={}){const e=!!t.includeMetadataChanges;if(e&&this._snapshot.excludesMetadataChanges)throw new C(P.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===e||(this._cachedChanges=(function(s,i){if(s._snapshot.oldDocs.isEmpty()){let a=0;return s._snapshot.docChanges.map((u=>{const c=new ii(s._firestore,s._userDataWriter,u.doc.key,u.doc,new Pe(s._snapshot.mutatedKeys.has(u.doc.key),s._snapshot.fromCache),s.query.converter);return u.doc,{type:"added",doc:c,oldIndex:-1,newIndex:a++}}))}{let a=s._snapshot.oldDocs;return s._snapshot.docChanges.filter((u=>i||u.type!==3)).map((u=>{const c=new ii(s._firestore,s._userDataWriter,u.doc.key,u.doc,new Pe(s._snapshot.mutatedKeys.has(u.doc.key),s._snapshot.fromCache),s.query.converter);let h=-1,f=-1;return u.type!==0&&(h=a.indexOf(u.doc.key),a=a.delete(u.doc.key)),u.type!==1&&(a=a.add(u.doc),f=a.indexOf(u.doc.key)),{type:Y_(u.type),doc:c,oldIndex:h,newIndex:f}}))}})(this,e),this._cachedChangesIncludeMetadataChanges=e),this._cachedChanges}toJSON(){if(this.metadata.hasPendingWrites)throw new C(P.FAILED_PRECONDITION,"QuerySnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const t={};t.type=Kt._jsonSchemaVersion,t.bundleSource="QuerySnapshot",t.bundleName=oa.newId(),this._firestore._databaseId.database,this._firestore._databaseId.projectId;const e=[],n=[],s=[];return this.docs.forEach((i=>{i._document!==null&&(e.push(i._document),n.push(this._userDataWriter.convertObjectMap(i._document.data.value.mapValue.fields,"previous")),s.push(i.ref.path))})),t.bundle=(this._firestore,this.query._query,t.bundleName,"NOT SUPPORTED"),t}}function Wy(r,t,e){if(gn(t,Kt._jsonSchema)){if(t.bundle===Sf)throw new C(P.INVALID_ARGUMENT,"The provided JSON object was created in a client environment, which is not supported.");const n=pn(r._databaseId),s=lf(t.bundle,n),i=s.Ku(),a=new Ga(s.getMetadata(),n);for(const p of i)a.Wa(p);if(a.queries.length!==1)throw new C(P.INVALID_ARGUMENT,`Snapshot data expected 1 query but found ${a.queries.length} queries.`);const u=Fi(a.queries[0].bundledQuery),c=a.documents;let h=new rn;c.map((p=>{const R=Ni(n,p.document);h=h.add(R)}));const f=mn.fromInitialDocuments(u,h,G(),!1,!1),m=new vt(r,e||null,u);return new Kt(r,new cu(r),m,f)}}function Y_(r){switch(r){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return M(61501,{type:r})}}function Hy(r,t){return r instanceof Gt&&t instanceof Gt?r._firestore===t._firestore&&r._key.isEqual(t._key)&&(r._document===null?t._document===null:r._document.isEqual(t._document))&&r._converter===t._converter:r instanceof Kt&&t instanceof Kt&&r._firestore===t._firestore&&ff(r.query,t.query)&&r.metadata.isEqual(t.metadata)&&r._snapshot.isEqual(t._snapshot)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xy(r){r=W(r,nt);const t=W(r.firestore,st);return uf(ht(t),r._key).then((e=>lu(t,r,e)))}Kt._jsonSchemaVersion="firestore/querySnapshot/1.0",Kt._jsonSchema={type:_t("string",Kt._jsonSchemaVersion),bundleSource:_t("string","QuerySnapshot"),bundleName:_t("string"),bundle:_t("string")};class je extends Vf{constructor(t){super(),this.firestore=t}convertBytes(t){return new zt(t)}convertReference(t){const e=this.convertDocumentKey(t,this.firestore._databaseId);return new nt(this.firestore,null,e)}}function Jy(r){r=W(r,nt);const t=W(r.firestore,st),e=ht(t),n=new je(t);return x_(e,r._key).then((s=>new Gt(t,n,r._key,s,new Pe(s!==null&&s.hasLocalMutations,!0),r.converter)))}function Yy(r){r=W(r,nt);const t=W(r.firestore,st);return uf(ht(t),r._key,{source:"server"}).then((e=>lu(t,r,e)))}function Zy(r){r=W(r,vt);const t=W(r.firestore,st),e=ht(t),n=new je(t);return vf(r._query),cf(e,r._query).then((s=>new Kt(t,n,r,s)))}function tI(r){r=W(r,vt);const t=W(r.firestore,st),e=ht(t),n=new je(t);return N_(e,r._query).then((s=>new Kt(t,n,r,s)))}function eI(r){r=W(r,vt);const t=W(r.firestore,st),e=ht(t),n=new je(t);return cf(e,r._query,{source:"server"}).then((s=>new Kt(t,n,r,s)))}function nI(r,t,e){r=W(r,nt);const n=W(r.firestore,st),s=Xi(r.converter,t,e);return Es(n,[Gi(In(n),"setDoc",r._key,s,r.converter!==null,e).toMutation(r._key,lt.none())])}function rI(r,t,e,...n){r=W(r,nt);const s=W(r.firestore,st),i=In(s);let a;return a=typeof(t=yt(t))=="string"||t instanceof _n?iu(i,"updateDoc",r._key,t,e,n):su(i,"updateDoc",r._key,t),Es(s,[a.toMutation(r._key,lt.exists(!0))])}function sI(r){return Es(W(r.firestore,st),[new or(r._key,lt.none())])}function iI(r,t){const e=W(r.firestore,st),n=j_(r),s=Xi(r.converter,t);return Es(e,[Gi(In(r.firestore),"addDoc",n._key,s,r.converter!==null,{}).toMutation(n._key,lt.exists(!1))]).then((()=>n))}function Ml(r,...t){var e,n,s;r=yt(r);let i={includeMetadataChanges:!1,source:"default"},a=0;typeof t[a]!="object"||On(t[a])||(i=t[a++]);const u={includeMetadataChanges:i.includeMetadataChanges,source:i.source};if(On(t[a])){const m=t[a];t[a]=(e=m.next)===null||e===void 0?void 0:e.bind(m),t[a+1]=(n=m.error)===null||n===void 0?void 0:n.bind(m),t[a+2]=(s=m.complete)===null||s===void 0?void 0:s.bind(m)}let c,h,f;if(r instanceof nt)h=W(r.firestore,st),f=sr(r._key.path),c={next:m=>{t[a]&&t[a](lu(h,r,m))},error:t[a+1],complete:t[a+2]};else{const m=W(r,vt);h=W(m.firestore,st),f=m._query;const p=new je(h);c={next:R=>{t[a]&&t[a](new Kt(h,p,m,R))},error:t[a+1],complete:t[a+2]},vf(r._query)}return(function(p,R,b,D){const x=new Ui(D),L=new za(R,x,b);return p.asyncQueue.enqueueAndForget((async()=>Ba(await nr(p),L))),()=>{x.Ou(),p.asyncQueue.enqueueAndForget((async()=>Ua(await nr(p),L)))}})(ht(h),f,u,c)}function oI(r,t,...e){const n=yt(r),s=(function(c){const h={bundle:"",bundleName:"",bundleSource:""},f=["bundle","bundleName","bundleSource"];for(const m of f){if(!(m in c)){h.error=`snapshotJson missing required field: ${m}`;break}const p=c[m];if(typeof p!="string"){h.error=`snapshotJson field '${m}' must be a string.`;break}if(p.length===0){h.error=`snapshotJson field '${m}' cannot be an empty string.`;break}m==="bundle"?h.bundle=p:m==="bundleName"?h.bundleName=p:m==="bundleSource"&&(h.bundleSource=p)}return h})(t);if(s.error)throw new C(P.INVALID_ARGUMENT,s.error);let i,a=0;if(typeof e[a]!="object"||On(e[a])||(i=e[a++]),s.bundleSource==="QuerySnapshot"){let u=null;if(typeof e[a]=="object"&&On(e[a])){const c=e[a++];u={next:c.next,error:c.error,complete:c.complete}}else u={next:e[a++],error:e[a++],complete:e[a++]};return(function(h,f,m,p,R){let b,D=!1;return kl(h,f.bundle).then((()=>G_(h,f.bundleName))).then((L=>{L&&!D&&(R&&L.withConverter(R),b=Ml(L,m||{},p))})).catch((L=>(p.error&&p.error(L),()=>{}))),()=>{D||(D=!0,b&&b())}})(n,s,i,u,e[a])}if(s.bundleSource==="DocumentSnapshot"){let u=null;if(typeof e[a]=="object"&&On(e[a])){const c=e[a++];u={next:c.next,error:c.error,complete:c.complete}}else u={next:e[a++],error:e[a++],complete:e[a++]};return(function(h,f,m,p,R){let b,D=!1;return kl(h,f.bundle).then((()=>{if(!D){const L=new nt(h,R||null,k.fromPath(f.bundleName));b=Ml(L,m||{},p)}})).catch((L=>(p.error&&p.error(L),()=>{}))),()=>{D||(D=!0,b&&b())}})(n,s,i,u,e[a])}throw new C(P.INVALID_ARGUMENT,`unsupported bundle source: ${s.bundleSource}`)}function aI(r,t){return F_(ht(r=W(r,st)),On(t)?t:{next:t})}function Es(r,t){return(function(n,s){const i=new wt;return n.asyncQueue.enqueueAndForget((async()=>c_(await Za(n),s,i))),i.promise})(ht(r),t)}function lu(r,t,e){const n=e.docs.get(t._key),s=new je(r);return new Gt(r,s,t._key,n,new Pe(e.hasPendingWrites,e.fromCache),t.converter)}function uI(r){return Z_(r,{count:J_()})}function Z_(r,t){const e=W(r.firestore,st),n=ht(e),s=_h(t,((i,a)=>new Yh(a,i.aggregateType,i._internalFieldPath)));return k_(n,r._query,s).then((i=>(function(u,c,h){const f=new je(u);return new K_(c,f,h)})(e,r,i)))}class ty{constructor(t){this.kind="memory",this._onlineComponentProvider=Fe.provider,t?.garbageCollector?this._offlineComponentProvider=t.garbageCollector._offlineComponentProvider:this._offlineComponentProvider={build:()=>new Xa(void 0)}}toJSON(){return{kind:this.kind}}}class ey{constructor(t){let e;this.kind="persistent",t?.tabManager?(t.tabManager._initialize(t),e=t.tabManager):(e=oy(void 0),e._initialize(t)),this._onlineComponentProvider=e._onlineComponentProvider,this._offlineComponentProvider=e._offlineComponentProvider}toJSON(){return{kind:this.kind}}}class ny{constructor(){this.kind="memoryEager",this._offlineComponentProvider=er.provider}toJSON(){return{kind:this.kind}}}class ry{constructor(t){this.kind="memoryLru",this._offlineComponentProvider={build:()=>new Xa(t)}}toJSON(){return{kind:this.kind}}}function cI(){return new ny}function lI(r){return new ry(r?.cacheSizeBytes)}function hI(r){return new ty(r)}function dI(r){return new ey(r)}class sy{constructor(t){this.forceOwnership=t,this.kind="persistentSingleTab"}toJSON(){return{kind:this.kind}}_initialize(t){this._onlineComponentProvider=Fe.provider,this._offlineComponentProvider={build:e=>new Ja(e,t?.cacheSizeBytes,this.forceOwnership)}}}class iy{constructor(){this.kind="PersistentMultipleTab"}toJSON(){return{kind:this.kind}}_initialize(t){this._onlineComponentProvider=Fe.provider,this._offlineComponentProvider={build:e=>new rf(e,t?.cacheSizeBytes)}}}function oy(r){return new sy(r?.forceOwnership)}function fI(){return new iy}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ay={maxAttempts:5};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uy{constructor(t,e){this._firestore=t,this._commitHandler=e,this._mutations=[],this._committed=!1,this._dataReader=In(t)}set(t,e,n){this._verifyNotCommitted();const s=Ve(t,this._firestore),i=Xi(s.converter,e,n),a=Gi(this._dataReader,"WriteBatch.set",s._key,i,s.converter!==null,n);return this._mutations.push(a.toMutation(s._key,lt.none())),this}update(t,e,n,...s){this._verifyNotCommitted();const i=Ve(t,this._firestore);let a;return a=typeof(e=yt(e))=="string"||e instanceof _n?iu(this._dataReader,"WriteBatch.update",i._key,e,n,s):su(this._dataReader,"WriteBatch.update",i._key,e),this._mutations.push(a.toMutation(i._key,lt.exists(!0))),this}delete(t){this._verifyNotCommitted();const e=Ve(t,this._firestore);return this._mutations=this._mutations.concat(new or(e._key,lt.none())),this}commit(){return this._verifyNotCommitted(),this._committed=!0,this._mutations.length>0?this._commitHandler(this._mutations):Promise.resolve()}_verifyNotCommitted(){if(this._committed)throw new C(P.FAILED_PRECONDITION,"A write batch can no longer be used after commit() has been called.")}}function Ve(r,t){if((r=yt(r)).firestore!==t)throw new C(P.INVALID_ARGUMENT,"Provided document reference is from a different Firestore instance.");return r}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cy{constructor(t,e){this._firestore=t,this._transaction=e,this._dataReader=In(t)}get(t){const e=Ve(t,this._firestore),n=new cu(this._firestore);return this._transaction.lookup([e._key]).then((s=>{if(!s||s.length!==1)return M(24041);const i=s[0];if(i.isFoundDocument())return new os(this._firestore,n,i.key,i,e.converter);if(i.isNoDocument())return new os(this._firestore,n,e._key,null,e.converter);throw M(18433,{doc:i})}))}set(t,e,n){const s=Ve(t,this._firestore),i=Xi(s.converter,e,n),a=Gi(this._dataReader,"Transaction.set",s._key,i,s.converter!==null,n);return this._transaction.set(s._key,a),this}update(t,e,n,...s){const i=Ve(t,this._firestore);let a;return a=typeof(e=yt(e))=="string"||e instanceof _n?iu(this._dataReader,"Transaction.update",i._key,e,n,s):su(this._dataReader,"Transaction.update",i._key,e),this._transaction.update(i._key,a),this}delete(t){const e=Ve(t,this._firestore);return this._transaction.delete(e._key),this}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ly extends cy{constructor(t,e){super(t,e),this._firestore=t}get(t){const e=Ve(t,this._firestore),n=new je(this._firestore);return super.get(t).then((s=>new Gt(this._firestore,n,e._key,s._document,new Pe(!1,!1),e.converter)))}}function mI(r,t,e){r=W(r,st);const n=Object.assign(Object.assign({},ay),e);return(function(i){if(i.maxAttempts<1)throw new C(P.INVALID_ARGUMENT,"Max attempts must be at least 1")})(n),(function(i,a,u){const c=new wt;return i.asyncQueue.enqueueAndForget((async()=>{const h=await af(i);new S_(i.asyncQueue,h,u,a,c).zu()})),c.promise})(ht(r),(s=>t(new ly(r,s))),n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function gI(){return new ys("deleteField")}function pI(){return new tu("serverTimestamp")}function _I(...r){return new eu("arrayUnion",r)}function yI(...r){return new nu("arrayRemove",r)}function II(r){return new ru("increment",r)}function TI(r){return new Ht(r)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function EI(r){return ht(r=W(r,st)),new uy(r,(t=>Es(r,t)))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function wI(r,t){const e=ht(r=W(r,st));if(!e._uninitializedComponentsProvider||e._uninitializedComponentsProvider._offline.kind==="memory")return Mt("Cannot enable indexes when persistence is disabled"),Promise.resolve();const n=(function(i){const a=typeof i=="string"?(function(h){try{return JSON.parse(h)}catch(f){throw new C(P.INVALID_ARGUMENT,"Failed to parse JSON: "+f?.message)}})(i):i,u=[];if(Array.isArray(a.indexes))for(const c of a.indexes){const h=Ll(c,"collectionGroup"),f=[];if(Array.isArray(c.fields))for(const m of c.fields){const p=Ki("setIndexConfiguration",Ll(m,"fieldPath"));m.arrayConfig==="CONTAINS"?f.push(new en(p,2)):m.order==="ASCENDING"?f.push(new en(p,0)):m.order==="DESCENDING"&&f.push(new en(p,1))}u.push(new qn(qn.UNKNOWN_ID,h,f,Bn.empty()))}return u})(t);return L_(e,n)}function Ll(r,t){if(typeof r[t]!="string")throw new C(P.INVALID_ARGUMENT,"Missing string value for: "+t);return r[t]}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hy{constructor(t){this._firestore=t,this.type="PersistentCacheIndexManager"}}function vI(r){var t;r=W(r,st);const e=ql.get(r);if(e)return e;if(((t=ht(r)._uninitializedComponentsProvider)===null||t===void 0?void 0:t._offline.kind)!=="persistent")return null;const n=new hy(r);return ql.set(r,n),n}function AI(r){bf(r,!0)}function RI(r){bf(r,!1)}function PI(r){B_(ht(r._firestore)).then((t=>N("deleting all persistent cache indexes succeeded"))).catch((t=>Mt("deleting all persistent cache indexes failed",t)))}function bf(r,t){q_(ht(r._firestore),t).then((e=>N(`setting persistent cache index auto creation isEnabled=${t} succeeded`))).catch((e=>Mt(`setting persistent cache index auto creation isEnabled=${t} failed`,e)))}const ql=new WeakMap;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function VI(r){var t;const e=(t=ht(W(r.firestore,st))._onlineComponents)===null||t===void 0?void 0:t.datastore.serializer;return e===void 0?null:ki(e,kt(r._query)).Vt}function SI(r,t){var e;const n=_h(t,((i,a)=>new Yh(a,i.aggregateType,i._internalFieldPath))),s=(e=ht(W(r.firestore,st))._onlineComponents)===null||e===void 0?void 0:e.datastore.serializer;return s===void 0?null:cd(s,Oh(r._query),n,!0).request}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bI{constructor(){throw new Error("instances of this class should not be created")}static onExistenceFilterMismatch(t){return hu.instance.onExistenceFilterMismatch(t)}}class hu{constructor(){this.Fc=new Map}static get instance(){return Ws||(Ws=new hu,(function(e){if(fi)throw new Error("a TestingHooksSpi instance is already set");fi=e})(Ws)),Ws}ct(t){this.Fc.forEach((e=>e(t)))}onExistenceFilterMismatch(t){const e=Symbol(),n=this.Fc;return n.set(e,t),()=>n.delete(e)}}let Ws=null;(function(t,e=!0){(function(s){rr=s})(Tm),Em(new wm("firestore",((n,{instanceIdentifier:s,options:i})=>{const a=n.getProvider("app").getImmediate(),u=new st(new Pm(n.getProvider("auth-internal")),new bm(a,n.getProvider("app-check-internal")),(function(h,f){if(!Object.prototype.hasOwnProperty.apply(h.options,["projectId"]))throw new C(P.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new sn(h.options.projectId,f)})(a,s),a);return i=Object.assign({useFetchStreams:e},i),u._setSettings(i),u}),"PUBLIC").setMultipleInstances(!0)),dc(mc,gc,t),dc(mc,gc,"esm2017")})();export{Vf as AbstractUserDataWriter,ss as AggregateField,K_ as AggregateQuerySnapshot,zt as Bytes,Ey as CACHE_SIZE_UNLIMITED,ne as CollectionReference,nt as DocumentReference,Gt as DocumentSnapshot,_n as FieldPath,yn as FieldValue,st as Firestore,C as FirestoreError,re as GeoPoint,z_ as LoadBundleTask,hy as PersistentCacheIndexManager,vt as Query,dr as QueryCompositeFilterConstraint,Is as QueryConstraint,ii as QueryDocumentSnapshot,Hi as QueryEndAtConstraint,Ts as QueryFieldFilterConstraint,Qi as QueryLimitConstraint,uu as QueryOrderByConstraint,Kt as QuerySnapshot,Wi as QueryStartAtConstraint,Pe as SnapshotMetadata,Z as Timestamp,ly as Transaction,Ht as VectorValue,uy as WriteBatch,oa as _AutoId,ft as _ByteString,sn as _DatabaseId,k as _DocumentKey,gy as _EmptyAppCheckTokenProvider,Am as _EmptyAuthCredentialsProvider,ct as _FieldPath,bI as _TestingHooks,W as _cast,my as _debugAssert,SI as _internalAggregationQueryToProtoRunAggregationQueryRequest,VI as _internalQueryToProtoQueryTarget,_y as _isBase64Available,Mt as _logWarn,Nm as _validateIsNotUsedTogether,iI as addDoc,Ky as aggregateFieldEqual,$y as aggregateQuerySnapshotEqual,Fy as and,yI as arrayRemove,_I as arrayUnion,Gy as average,Py as clearIndexedDbPersistence,yy as collection,Iy as collectionGroup,U_ as connectFirestoreEmulator,J_ as count,PI as deleteAllPersistentCacheIndexes,sI as deleteDoc,gI as deleteField,by as disableNetwork,RI as disablePersistentCacheIndexAutoCreation,j_ as doc,Dy as documentId,Qy as documentSnapshotFromJSON,Ay as enableIndexedDbPersistence,Ry as enableMultiTabIndexedDbPersistence,Sy as enableNetwork,AI as enablePersistentCacheIndexAutoCreation,jy as endAt,Uy as endBefore,ht as ensureFirestoreConfigured,Es as executeWrite,Z_ as getAggregateFromServer,uI as getCountFromServer,Xy as getDoc,Jy as getDocFromCache,Yy as getDocFromServer,Zy as getDocs,tI as getDocsFromCache,eI as getDocsFromServer,vy as getFirestore,vI as getPersistentCacheIndexManager,II as increment,wy as initializeFirestore,My as limit,Ly as limitToLast,kl as loadBundle,cI as memoryEagerGarbageCollector,hI as memoryLocalCache,lI as memoryLruGarbageCollector,G_ as namedQuery,Ml as onSnapshot,oI as onSnapshotResume,aI as onSnapshotsInSync,ky as or,Oy as orderBy,dI as persistentLocalCache,fI as persistentMultipleTabManager,oy as persistentSingleTabManager,xy as query,ff as queryEqual,Wy as querySnapshotFromJSON,Ty as refEqual,mI as runTransaction,pI as serverTimestamp,nI as setDoc,wI as setIndexConfiguration,fy as setLogLevel,Hy as snapshotEqual,By as startAfter,qy as startAt,zy as sum,Cy as terminate,rI as updateDoc,TI as vector,Vy as waitForPendingWrites,Ny as where,EI as writeBatch};
