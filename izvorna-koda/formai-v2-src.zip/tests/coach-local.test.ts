import { describe, it, expect, vi } from 'vitest'

const h = vi.hoisted(() => ({ calls: [] as string[] }))
vi.mock('../src/domain/ai/client', () => {
  class AiError extends Error { kind: string; constructor(kind: string, m: string) { super(m); this.kind = kind } }
  const textOf = (parts: { text?: string }[]) => parts.map(p => p.text || '').join('\n')
  return { AiError, askText: async (parts: { text?: string }[]) => { h.calls.push(textOf(parts)); return 'Odgovor modela.' }, askJson: async () => ({}) }
})

import { localAdvice, localReview, mainOf, type LocalCoachCtx } from '../src/domain/coach/local'
import { rpeWarn, rpeLabel, cleanRpe, meantEasy } from '../src/domain/coach/rpe'
import * as A from '../src/domain/ai/actions'
import { snapOf } from '../src/state/snap'
import { addDays, weekStartIso } from '../src/domain/training/load'
import type { AppState } from '../src/state/store'
import type { Activity, PlanDay, Profile, MealEntry } from '../src/domain/types'

const today = '2026-10-07'          // sreda
const ws = weekStartIso(today)
const NOW = today + 'T08:00:00.000Z'
const d = (n: number) => addDays(today, n)
const profile: Profile = {
  name: 'Test', sex: 'm', age: 30, weightKg: 75, heightCm: 180, ftp: 250, restHr: 50, maxHr: 192, lthr: 175, hoursPerWeek: 8, goal: 'dirka', deficit: 300, neat: 1.4, proteinGkg: 1.8,
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true, powerMeterAuto: true }, strength: { on: true, equipment: 'home' }, strengthDays: 2,
  event: { name: 'Maraton Franja', date: addDays(today, 200), distanceKm: 156 }, cycleStart: weekStartIso(addDays(today, -28)),
  aiConsentAt: NOW, onboardingDone: true, createdAt: NOW, updatedAt: NOW,
}
const day = (id: string, date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id, date, kind: 'kolo', title: 'Z2 vzdržljivost', desc: 'Enakomerno v Z2.', durationMin: 90, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })
const act = (id: string, date: string, o: Partial<Activity> = {}): Activity => ({ id, source: 'intervals', originHint: 'GARMIN', sport: 'kolo', date, start: date + 'T15:00:00.000Z', name: 'Kolesarjenje', durationMin: 90, tss: 60, hrZoneSec: [600, 4200, 300, 0, 0, 0, 0], aiEligible: true, geoRetain: true, createdAt: NOW, updatedAt: NOW, ...o })
const meal = (kcal: number, p: number): MealEntry => ({ id: 'm' + kcal, date: today, time: '08:00', slot: 'zajtrk', name: 'Zajtrk', grams: null, kcal, proteinG: p, carbsG: null, fatG: null, confidence: 'srednja', source: 'manual', thumb: null, createdAt: NOW })

const plan: PlanDay[] = [
  day('p1', ws, { kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, role: null }),
  day('p2', d(-1), { title: 'VO2max 5 × 4 min', zone: 'Z5', role: 'kljucna', durationMin: 75, target: { lo: 270, hi: 300 }, done: { at: NOW, activityId: 'a2' } }),
  day('p3', today, { title: 'Z2 vzdržljivost', durationMin: 90 }),
  day('p3m', today, { kind: 'moc', title: 'Moč — jedro', durationMin: 25, zone: null, role: 'moc', exercises: [{ name: 'Deska', sets: 3, reps: '45 s' }] }),
  day('p4', d(1), { title: 'Prag 2 × 15 min', zone: 'Z4', role: 'kljucna', durationMin: 80 }),
  day('p5', d(3), { title: 'Dolga Z2', role: 'dolga', durationMin: 180 }),
]
const acts: Activity[] = [act('a2', d(-1), { durationMin: 75, tss: 90, hrZoneSec: [300, 900, 600, 1200, 1200, 0, 0] }), act('a0', d(-4)), act('a00', d(-6))]
const ctx = (o: Partial<LocalCoachCtx> = {}): LocalCoachCtx => ({ profile, plan, activities: acts, checkins: [], checkinToday: null, wellness: null, wellnessOn: false, mealsToday: [], recentMeals: [], weather: null, today, ...o })

describe('trener brez AI — kaj danes', () => {
  it('glavna seja dneva: kolo pred močjo, počitek in »po želji« na koncu', () => {
    expect(mainOf(plan, today)?.id).toBe('p3')
    expect(mainOf(plan, ws)?.kind).toBe('pocitek')
    expect(mainOf(plan, d(10))).toBeNull()
  })
  it('seja s ciljem, dodatna moč, forma, gorivo, hrana z ostankom in jutri', () => {
    const t = localAdvice(ctx({ mealsToday: [meal(600, 30)] }))
    const L = t.split('\n')
    expect(L[0]).toMatch(/^Danes: Z2 vzdržljivost — 1 h 30 min\. Cilj: Z2 · \d+–\d+ W\./)
    expect(t).toContain('Dodatno: Moč — jedro (25 min).')
    expect(t).toMatch(/Forma [+−]?\d+ \(/)
    expect(t).toMatch(/Pred: /)
    expect(t).toMatch(/Hrana: cilj [\d ]+ kcal in \d+ g beljakovin; vpisanih 600 kcal in 30 g — ostane ~[\d ]+ kcal/)
    expect(L[L.length - 1]).toBe('Jutri: Prag 2 × 15 min, 1 h 20 min.')
  })
  it('nizka pripravljenost → predlog, naj olajša dan', () => {
    const t = localAdvice(ctx({ checkinToday: { date: today, mood: 1, soreness: 5, sleepH: 5 } }))
    expect(t).toMatch(/Pripravljenost \d+ — nizka \(.*boleče mišice.*\)\. Danes raje lažje/)
  })
  it('počitek in opravljen trening', () => {
    expect(localAdvice(ctx({ today: ws }))).toMatch(/^Danes je počitek/)
    const done = plan.map(x => (x.id === 'p3' ? { ...x, done: { at: NOW, activityId: null } } : x))
    expect(localAdvice(ctx({ plan: done }))).toMatch(/^Današnji trening je opravljen: Z2 vzdržljivost\./)
  })
  it('brez načrta za danes', () => {
    expect(localAdvice(ctx({ plan: [] }))).toMatch(/^Za danes v načrtu ni ničesar/)
  })
})

describe('trener brez AI — pregled tedna', () => {
  it('opravljeno, ure na kolesu, ključni, forma, naslednji ključni', () => {
    const t = localReview(ctx())
    expect(t).toMatch(/^Teden od ponedeljka 5\. 10\./)
    expect(t).toMatch(/Opravljeno 1 od 5 sej \(do danes jih je bilo 3\) · na kolesu 1 h 15 min od 7 h 05 min · 90 TSS\./)
    expect(t).toMatch(/Ključni: VO2max 5 × 4 min \(tor\) — /)
    expect(t.split('\n').pop()).toBe('Naslednji ključni: Prag 2 × 15 min, četrtek 8. 10.')
    expect(t).not.toMatch(/−0\b|\.\.$/m)
  })
  it('občutek: lahke vožnje »težko« dvakrat → opozorilo o utrujenosti', () => {
    const rated = [act('e1', d(-2), { rpe: 8 }), act('e2', d(-3), { rpe: 9 }), ...acts]
    expect(localReview(ctx({ activities: rated }))).toMatch(/Občutek: lahke vožnje so se ti v zadnjih 10 dneh 2× zdele težke/)
  })
})

describe('RPE', () => {
  it('oznake, čiščenje, lahko/težko po načrtu ali conah', () => {
    expect(rpeLabel(8)).toBe('težko'); expect(rpeLabel(3)).toBe('lahkotno'); expect(rpeLabel(null)).toBeNull()
    expect(cleanRpe(7.4)).toBe(7); expect(cleanRpe(0)).toBeNull(); expect(cleanRpe('11')).toBeNull(); expect(cleanRpe('6')).toBe(6)
    expect(meantEasy(act('x', today), day('d', today))).toBe(true)
    expect(meantEasy(act('x', today), day('d', today, { role: 'kljucna', zone: 'Z5' }))).toBe(false)
    expect(meantEasy(act('x', today, { hrZoneSec: [60, 600, 1200, 600, 0, 0, 0] }))).toBe(false)
    expect(meantEasy(act('x', today, { sport: 'tek' }))).toBeNull()
  })
  it('opozorilo samo z vsaj dvema primeroma; ključni »lahko« → cilji morda prenizki', () => {
    expect(rpeWarn([act('e1', d(-2), { rpe: 9 })], plan, today)).toBeNull()
    const easyKeys = [act('k1', d(-1), { rpe: 3 }), act('k2', d(-5), { rpe: 4 })]
    const pl = [...plan.map(x => (x.id === 'p2' ? { ...x, done: { at: NOW, activityId: 'k1' } } : x)), day('p0', d(-5), { title: 'Prag', zone: 'Z4', role: 'kljucna', done: { at: NOW, activityId: 'k2' } })]
    expect(rpeWarn(easyKeys, pl, today)).toMatch(/ključni treningi so se ti 2× zdeli lahki/)
    expect(rpeWarn([act('o', d(-12), { rpe: 9 }), act('o2', d(-13), { rpe: 9 })], plan, today)).toBeNull()
  })
})

describe('odgovori iz načrta ne gredo v AI', () => {
  it('pogovor z AI ne vidi lokalnih sporočil', async () => {
    h.calls.length = 0
    const app = { ready: true, profile, settings: { lang: 'sl', tests: [] }, activities: acts, plan, mealsToday: [], recentMeals: [], checkinToday: null, checkins: [], weather: null, today, wellness: null } as unknown as AppState
    const mem = { msgs: [
      { role: 'user' as const, text: 'Kaj naj danes naredim?', at: NOW, local: true },
      { role: 'ai' as const, text: 'LOKALNI-ODGOVOR-123', at: NOW, kind: 'advice' as const, local: true },
      { role: 'user' as const, text: 'Pravo vprašanje prej', at: NOW },
    ], summary: null }
    const out = await A.chat(snapOf(app), 'Kako mi gre?', mem)
    expect(h.calls.join('\n')).not.toContain('LOKALNI-ODGOVOR-123')
    expect(h.calls.join('\n')).toContain('Pravo vprašanje prej')
    expect(out.msgs.some(m => m.local)).toBe(true)          // v pogovoru ostanejo (na zaslonu)
  })
  it('povzetek starih sporočil izpusti lokalne; če so samo lokalni, ostane dosedanji povzetek brez klica AI', async () => {
    h.calls.length = 0
    const msgs = Array.from({ length: 41 }, (_, i) => ({ role: (i % 2 ? 'ai' : 'user') as 'ai' | 'user', text: `L${i}`, at: `2026-10-0${1 + Math.floor(i / 10)}T08:${String(i).padStart(2, '0')}:00Z`, local: true }))
    const m = await A.addToChat({ msgs, summary: 'star povzetek' }, [{ role: 'user', text: 'novo', at: '2026-10-07T09:00:00Z' }])
    expect(h.calls.length).toBe(0)
    expect(m.summary).toBe('star povzetek')
  })
})
