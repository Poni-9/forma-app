import { describe, it, expect, vi, afterEach } from 'vitest'
import { wellnessFromIcu, recoveryOf, sleepBucket, fmtSleep, type WellnessDay } from '../src/domain/wellness'
import { fetchWellness } from '../src/domain/intervals/client'
import { readinessOf } from '../src/ui/Checkin'

afterEach(() => { vi.unstubAllGlobals() })
const day = (i: number) => new Date(Date.UTC(2026, 8, 1 + i)).toISOString().slice(0, 10)
/** 20 običajnih noči: HRV ~60 ms (55–66), mirovni utrip 47–49, spanec 7,5 h */
const normal: WellnessDay[] = Array.from({ length: 20 }, (_, i) => ({ date: day(i), sleepH: 7.5, sleepScore: 80, hrv: [55, 58, 60, 62, 66][i % 5]!, rhr: [47, 48, 49][i % 3]! }))
const today = day(20)

describe('spanec, HRV, mirovni utrip z ure', () => {
  it('zapis intervals.icu → dan (ure spanca, zaokroženo); prazen zapis se izpusti', () => {
    expect(wellnessFromIcu({ id: '2026-09-24', sleepSecs: 25920, sleepScore: 83.4, hrv: 61.26, restingHR: 48 })).toEqual({ date: '2026-09-24', sleepH: 7.2, sleepScore: 83, hrv: 61.3, rhr: 48 })
    expect(wellnessFromIcu({ id: '2026-09-24', ctl: 60, atl: 70 })).toBeNull()
    expect(wellnessFromIcu({ id: 'x' })).toBeNull()
  })
  it('običajna noč: brez odbitka in brez razlogov', () => {
    const r = recoveryOf([...normal, { date: today, sleepH: 7.6, sleepScore: 82, hrv: 60, rhr: 48 }], today)!
    expect(r.penalty).toBe(0); expect(r.reasons).toEqual([])
    expect(r.hrvBase!.lo).toBeLessThan(60); expect(r.hrvBase!.hi).toBeGreaterThan(60)
    expect(r.rhrBase!.mean).toBe(48)
  })
  it('slaba noč: HRV precej pod običajnim, utrip +8, 5 h spanca → velik odbitek (največ 30) in razlogi', () => {
    const r = recoveryOf([...normal, { date: today, sleepH: 5, sleepScore: 41, hrv: 42, rhr: 56 }], today)!
    expect(r.hrvZ!).toBeLessThan(-1.5)
    expect(r.rhrDelta).toBe(8)
    expect(r.reasons).toEqual(['HRV precej pod običajnim', 'mirovni utrip +8', 'malo spanja', 'slaba kakovost spanja'])
    expect(r.penalty).toBe(30)
  })
  it('ročni vnos spanca ima prednost: ura ne odšteje še enkrat za spanec', () => {
    const r = recoveryOf([...normal, { date: today, sleepH: 5, sleepScore: 70, hrv: 60, rhr: 48 }], today, 7)!
    expect(r.reasons).toEqual([]); expect(r.penalty).toBe(0)
  })
  it('manj kot 7 meritev: HRV in utrip še brez sodbe (ni »običajnega«), spanec šteje', () => {
    const r = recoveryOf([...normal.slice(-4), { date: today, sleepH: 6, sleepScore: null, hrv: 30, rhr: 70 }], today)!
    expect(r.hrvBase).toBeNull(); expect(r.rhrBase).toBeNull()
    expect(r.reasons).toEqual(['kratek spanec']); expect(r.penalty).toBe(7)
  })
  it('brez današnjega zapisa ni ocene', () => {
    expect(recoveryOf(normal, today)).toBeNull()
    expect(recoveryOf(null, today)).toBeNull()
  })
  it('pripravljenost: slaba noč spusti oceno pod 45 (ponudi Olajšaj dan), razlogi so vidni', () => {
    const rec = recoveryOf([...normal, { date: today, sleepH: 5, sleepScore: 41, hrv: 42, rhr: 56 }], today)!
    const good = readinessOf(0, null, recoveryOf([...normal, { date: today, sleepH: 8.2, sleepScore: 90, hrv: 61, rhr: 47 }], today))!
    const bad = readinessOf(0, null, rec)!
    expect(good.score).toBeGreaterThanOrEqual(60)
    expect(bad.score).toBeLessThan(45)
    expect(bad.reasons).toContain('malo spanja')
    // tudi ko je forma iz treninga zelo sveža (+25), slaba noč z ure ostane »nizka«
    expect(readinessOf(25, null, rec)!.score).toBeLessThan(45)
    // blažji znaki (samo kratek spanec + HRV malo pod običajnim) največ »srednja«
    const mild = recoveryOf([...normal, { date: today, sleepH: 6.2, sleepScore: 70, hrv: 52, rhr: 48 }], today)!
    expect(mild.penalty).toBeGreaterThanOrEqual(12)
    expect(readinessOf(25, null, mild)!.score).toBeLessThan(60)
  })
  it('gumb spanca in zapis ur', () => {
    expect([4.9, 5.6, 6.4, 7.2, 7.6, 8.4, 9.3].map(sleepBucket)).toEqual([5, 6, 6, 7, 8, 8, 9])
    expect(fmtSleep(7.2)).toBe('7 h 12 min'); expect(fmtSleep(8)).toBe('8 h')
  })
  it('fetchWellness: samo potrebna polja, razvrščeno po datumu', async () => {
    const f = vi.fn(async (_u: string) => new Response(JSON.stringify([{ id: '2026-09-24', sleepSecs: 27000, hrv: 58, restingHR: 49 }, { id: '2026-09-23', restingHR: 50 }, { id: '2026-09-22' }]), { status: 200 }))
    vi.stubGlobal('fetch', f)
    const r = await fetchWellness({ athleteId: 'i1', apiKey: 'k' }, '2026-08-20', '2026-09-24')
    expect(String(f.mock.calls[0]![0])).toContain('/athlete/i1/wellness?oldest=2026-08-20&newest=2026-09-24&fields=id,sleepSecs,sleepScore,hrv,restingHR')
    expect(r.map(d => d.date)).toEqual(['2026-09-23', '2026-09-24'])
    expect(r[1]).toEqual({ date: '2026-09-24', sleepH: 7.5, sleepScore: null, hrv: 58, rhr: 49 })
  })
})
