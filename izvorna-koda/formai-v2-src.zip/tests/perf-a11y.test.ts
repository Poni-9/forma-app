import { describe, it, expect } from 'vitest'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'

// Dostopnost globalnih slogov: kontrast utišanega besedila, površina dotika, fokus, manj gibanja.
const css = (f: string) => readFileSync(resolve(process.cwd(), 'src/styles', f), 'utf8')
const token = (name: string) => { const m = css('tokens.css').match(new RegExp(`--${name}:\\s*(#[0-9a-fA-F]{6})`)); if (!m) throw new Error(name); return m[1]! }
const lum = (hex: string) => {
  const [r, g, b] = [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16) / 255).map(c => (c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4)) as [number, number, number]
  return 0.2126 * r + 0.7152 * g + 0.0722 * b
}
const contrast = (a: string, b: string) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05) }

describe('dostopnost — tokeni in osnovni slogi', () => {
  it('utišano besedilo (--ink-3) ima ≥ 4,5 : 1 na vseh podlagah', () => {
    for (const s of ['bg', 'bg-deep', 'card', 'raised']) expect(contrast(token('ink-3'), token(s)), s).toBeGreaterThanOrEqual(4.5)
  })
  it('besedilo (--ink, --ink-2) ima ≥ 4,5 : 1 na vseh podlagah', () => {
    for (const t of ['ink', 'ink-2']) for (const s of ['bg', 'card', 'raised']) expect(contrast(token(t), token(s)), `${t}/${s}`).toBeGreaterThanOrEqual(4.5)
  })
  it('majhni gumbi (čip ×, −/+, avatar) imajo površino dotika vsaj 40 px', () => {
    const b = css('base.css')
    expect(b).toMatch(/\.chip\.click::after[^{]*\{[^}]*min-width:\s*40px;[^}]*min-height:\s*40px/)
    expect(b).toMatch(/\.avatar::after/)
  })
  it('vidna oznaka fokusa za gumbe, povezave in polja', () => {
    const b = css('base.css')
    expect(b).toMatch(/button[^{]*:focus-visible[^{]*\{[^}]*outline:\s*2px solid/)
    expect(b).toMatch(/input, select, textarea\):focus-visible[^{]*\{[^}]*outline:\s*2px solid/)
  })
  it('manj gibanja: brez animacij in prehodov (tudi psevdoelementi)', () => {
    expect(css('base.css')).toMatch(/prefers-reduced-motion: reduce\)\s*\{\s*\*, \*::before, \*::after\s*\{[^}]*animation: none !important/)
  })
})
