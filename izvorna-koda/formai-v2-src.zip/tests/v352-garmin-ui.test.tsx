// v3.52 UI — Garmin Connect neposredno, zasloni: kartica na Uvozu (brez/z povezavo, prijava, napaka, odklop), stikala v
// Nastavitvah (setGarminOpt, cikel samo pri ženskah), »Kaj gre v AI« z Garminom, Danes (wellnessActive, cikel, »Preveri
// Garmin«), ReadinessSheet (stres, Body Battery, vir), Prehrana (opomba cikla), Plan (»na uri«), RouteCard (»Trasa na uro«),
// vodnik (Garmin kot prva pot).
import 'fake-indexeddb/auto'
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'uvoz', params: {} as Record<string, string> }, nav: [] as unknown[][], live: false }))
vi.mock('@/state/store', async () => {
  const { vi: v } = await import('vitest')
  const base: Record<string | symbol, unknown> = {
    useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
    getState: () => S.state,
    routePace: () => ({ k: 1, adj: { n: 0, adj: 1 } }),
    stateToday: () => ({ level: 0, legs: false, reasons: [] }),
    toast: v.fn(),
    // kot v store: povezan + pošiljanje ni izklopljeno + (brez dovoljenj ali WORKOUT_IMPORT)
    garminPushOn: (s: { garmin?: { connected?: boolean; pushWorkouts?: boolean; permissions?: string[] | null } | null }) => !!s.garmin?.connected && s.garmin.pushWorkouts !== false && (!s.garmin.permissions?.length || s.garmin.permissions.includes('WORKOUT_IMPORT')),
    garminPreview: (d: { kind: string }) => (d.kind === 'kolo' || d.kind === 'test' || d.kind === 'tek' ? { uid: 'x' } : null),
    garminAllows: (g: { connected?: boolean; permissions?: string[] | null } | null, p: string) => !!g?.connected && (!Array.isArray(g.permissions) || g.permissions.includes(p)),
    syncGarmin: v.fn(async () => ({ added: 0, upgraded: 0, healthDays: 0, cycleDays: 0, error: null, skipped: null })),
    LAST_EXPORT_KEY: 'x',
  }
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' || typeof k === 'symbol' ? undefined : (t[k] = v.fn(async () => undefined))), has: (_t, k) => k !== 'then' })
})
vi.mock('@/domain/garmin/client', () => ({ garminLive: async () => S.live, garminOn: () => S.live }))
vi.mock('@/app/router', () => ({ navigate: (...a: unknown[]) => { S.nav.push(a) }, useRoute: () => S.route, parseHash: () => S.route, subscribeRoute: () => () => undefined }))
vi.mock('@/app/hash', () => ({ replaceParams: () => undefined }))
vi.mock('@/app/landing', () => ({ markApp: () => undefined, forgetApp: () => undefined }))
vi.mock('@/app/Shell', () => ({ Head: () => null }))
vi.mock('@/ui/useAi', () => ({ useAi: () => ({ busy: false, signedIn: false, consent: false, run: async (fn: () => Promise<unknown>) => fn(), sheet: null }) }))
vi.mock('@/state/snap', () => ({ snapOf: () => ({}) }))
vi.mock('@/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
vi.mock('@/data/icuOauth', () => ({ icuOauthOn: () => false, probeIcuOauth: async () => false, startIcuOAuth: () => undefined }))
vi.mock('@/data/db', () => ({ getKV: async () => undefined, setKV: async () => undefined, storagePersisted: () => null, requestPersist: async () => false }))
vi.mock('@/data/repo', () => ({ wipeAll: vi.fn() }))
vi.mock('@/data/backup', () => ({ downloadBackup: vi.fn() }))
vi.mock('@/data/sync', () => ({ syncNow: vi.fn() }))
vi.mock('@/data/feedback', () => ({
  FB_KINDS: [], FB_SHOT_MAX: 1, FB_TEXT_MAX: 1, makeFeedback: async (o: object) => o, sendFeedback: async () => 'poslano', captureScreen: async () => null,
  fetchFeedbackList: async () => ({ error: 'x' }), flushFeedback: async () => 0, queuedFeedback: async () => 0,
}))
vi.mock('@/ui/ClaudeAdmin', () => ({ ClaudeAdmin: () => null }))
vi.mock('@/ui/BackupImport', () => ({ BackupImport: () => null }))
vi.mock('@/ui/GoalCard', () => ({ GoalCard: () => null }))
vi.mock('@/ui/theme', () => ({ THEME_PREFS: [['samodejno', 'kot telefon']], themePref: () => 'samodejno', setThemePref: vi.fn(), subscribeTheme: () => () => {} }))
// listi na Danes niso leni (ReadinessSheet se odpre takoj)
vi.mock('@/ui/DanesSheetsLazy', async () => {
  const r = await import('@/ui/ReadinessSheet'), w = await import('@/ui/WeighSheet'), s = await import('@/ui/SkipSheet'), m = await import('@/ui/MoveDaySheet')
  return { ReadinessSheet: r.ReadinessSheet, WeighSheet: w.WeighSheet, SkipSheet: s.SkipSheet, MoveDaySheet: m.MoveDaySheet }
})

import * as store from '@/state/store'
import { Uvoz } from '@/screens/Uvoz'
import { Nastavitve } from '@/screens/Ostalo'
import { Danes } from '@/screens/Danes'
import { Plan, onGarminWatch } from '@/screens/Plan'
import { ReadinessSheet } from '@/ui/ReadinessSheet'
import { RouteCard } from '@/ui/RouteCard'
import { GarminCard, GarminOpts, lastSyncLine, garminNeedsReconnect, workoutsLine } from '@/ui/GarminCard'
import { watchPath } from '@/ui/Guide'
import { checkinDone } from '@/ui/Checkin'
import { wellnessActive } from '@/domain/wellness'
import { analyzeTrack } from '@/domain/routes/analyze'
import type { Activity, PlanDay, Profile, GarminSettings } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-23'   // petek
const NOW = `${TODAY}T08:00:00.000Z`
const P = { sex: 'm', age: 30, heightCm: 180, weightKg: 78, ftp: 240, maxHr: 190, restHr: 50, lthr: 170, hoursPerWeek: 8, trainTime: 'popoldne', gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, strength: { on: false, equipment: 'none' }, strengthDays: 0, onboardingDone: true, goal: 'hitrejsi', createdAt: NOW, updatedAt: NOW } as unknown as Profile
const ANA = { ...P, sex: 'z', name: 'Ana' } as Profile
const G = (o: Partial<GarminSettings> = {}): GarminSettings => ({ connected: true, connectedAt: NOW, userId: 'u1', permissions: ['ACTIVITY_EXPORT', 'HEALTH_EXPORT', 'WORKOUT_IMPORT', 'COURSE_IMPORT', 'MCT_EXPORT'], pushWorkouts: true, pushCourses: true, health: false, cycle: false, lastSyncAt: null, lastError: null, ...o })
const day = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: date + (o.kind || 'kolo') + (o.title || ''), date, kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, zone: 'Z2', role: 'lahka', tssTarget: 42, source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o } as PlanDay)
const hard = (date: string) => day(date, { title: 'VO2max 5×3 min', zone: 'Z5', role: 'kljucna', tssTarget: 70 })
const act0 = (o: Partial<Activity> = {}): Activity => ({ id: 'a1', source: 'garmin', sport: 'kolo', date: TODAY, start: null, name: 'Kolo', durationMin: 60, distKm: 30, elevM: null, avgHr: null, avgPower: null, kcal: null, speedKmh: 30, tss: 50, polyline: null, aiEligible: true, geoRetain: true, deviceName: 'Garmin Edge 540', originHint: 'GARMIN_API', createdAt: NOW, updatedAt: NOW, ...o } as Activity)
const state = (o: Record<string, unknown> = {}) => ({
  ready: true, today: TODAY, profile: P, plan: [], activities: [], checkins: [], checkinToday: null, weather: null, wellness: null, user: null, authKnown: true, changes: [], pro: false,
  settings: { lang: 'sl', intervals: null, guideSeen: true, startDone: true, tests: [], coach: { msgs: [], summary: null } }, sync: { state: 'off' }, mealsToday: [], recentMeals: [], icuDiag: null, icuWorkouts: null, icuErr: null,
  routeLib: null, routesBusy: false, cycle: null, garminBusy: false, garminErr: null, garminWorkouts: null, firstSync: null, ...o,
})
const set = (o: Record<string, unknown> = {}) => { S.state = state(o); S.subs.forEach(f => f()) }
const fn = (k: string) => (store as unknown as Record<string, ReturnType<typeof vi.fn>>)[k]!

let div: HTMLDivElement | null = null, root: Root | null = null
async function render(el: ReactElement) { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div); await act(async () => { root!.render(el) }); await flush(); return div }
async function unmount() { if (root) await act(async () => root!.unmount()); div?.remove(); root = null; div = null }
const sp = (x: string | null | undefined) => (x || '').replace(/[\u2060\u200b]/g, '').replace(/[\u00a0\u2009\u202f]/g, ' ')
const text = () => sp(document.body.textContent)
const btn = (label: string | RegExp) => [...document.querySelectorAll('button')].find(b => (typeof label === 'string' ? sp(b.textContent).trim() === label || b.getAttribute('aria-label') === label : label.test(sp(b.textContent).trim()))) as HTMLButtonElement | undefined
async function click(label: string | RegExp) { const b = btn(label); if (!b) throw new Error(`ni gumba: ${label}`); await act(async () => { b.click() }); await flush() }
const flush = async () => { for (let i = 0; i < 8; i++) await act(async () => { await Promise.resolve() }) }
/** gumb v listu potrditve (zadnji z istim imenom) */
async function clickLast(label: string) { const all = [...document.querySelectorAll('button')].filter(b => sp(b.textContent).trim() === label); const b = all.at(-1); if (!b) throw new Error(`ni gumba: ${label}`); await act(async () => { b.click() }); await flush() }
/** ChangeDaySheet požene izbiro čez 30 ms */
const wait = async (ms = 60) => { await act(async () => { await new Promise(r => setTimeout(r, ms)) }); await flush() }
/** ISO današnjega dne ob 7:12 po lokalnem času (za »zadnjič danes 07:12«) */
const AT712 = (() => { const d = new Date(); d.setHours(7, 12, 0, 0); return d.toISOString() })()
beforeEach(() => { vi.clearAllMocks(); S.live = false; S.nav = []; S.route = { name: 'uvoz', params: {} }; set(); Element.prototype.scrollIntoView = vi.fn(); window.scrollTo = vi.fn() as unknown as typeof window.scrollTo })
afterEach(async () => { await unmount(); document.body.innerHTML = '' })

/* ---------- Uvoz: kartica Garmin Connect ---------- */
describe('Uvoz · kartica Garmin Connect', () => {
  it('brez strežnika z Garminom in brez povezave kartice ni; intervals.icu ostane »1 · Odslej samodejno«', async () => {
    await render(<Uvoz />)
    await click(/^Garmin ura ali števec/)
    expect(document.querySelector('.g-card')).toBeNull()
    expect(text()).not.toContain('Poveži z Garmin Connect')
    expect(text()).toContain('1 · Odslej samodejno')
  })
  it('strežnik ima Garmin, brez prijave: »Prijavi se, da povežeš Garmin« kliče signIn; s prijavo »Poveži z Garmin Connect« kliče connectGarmin', async () => {
    S.live = true
    await render(<Uvoz />)
    await click(/^Garmin ura ali števec/)
    expect(text()).toContain('Garmin Connect')
    expect(text()).toContain('Vožnje z ure pridejo same (Garmin → FORMAI). Treningi iz načrta gredo na uro.')
    await click('Prijavi se, da povežeš Garmin')
    expect(fn('signIn')).toHaveBeenCalledTimes(1)
    expect(fn('connectGarmin')).not.toHaveBeenCalled()
    set({ user: { uid: 'u', email: 'a@b.si' } })
    await flush()
    await click('Poveži z Garmin Connect')
    expect(fn('connectGarmin')).toHaveBeenCalledTimes(1)
  })
  it('povezano: »Povezano · Garmin«, zadnji prenos, »Preveri Garmin« kliče syncGarmin(true), opomba o intervals.icu', async () => {
    S.live = true
    set({ user: { uid: 'u' }, settings: { ...state().settings, garmin: G({ lastSyncAt: AT712 }), intervals: { athleteId: 'i1', apiKey: 'k', name: 'Blaž', pushWorkouts: false } }, activities: [act0({ source: 'intervals', originHint: 'GARMIN' })] })
    await render(<Uvoz />)
    expect(text()).toContain('Povezano · Garmin')
    expect(text()).toContain('zadnji prenos danes 07:12')
    expect(text()).toContain('Ista vožnja z Garmina in intervals.icu se ne podvoji.')
    expect(text()).toContain('Tudi prek intervals.icu')
    expect(text()).not.toContain('1 · Odslej samodejno')
    await click('Preveri Garmin')
    expect(fn('syncGarmin')).toHaveBeenCalledWith(true)
    // nič novega → obvestilo (napake in nove vadbe pove store)
    expect(fn('toast').mock.calls.some(c => /Nove vožnje še ni/.test(String(c[0])))).toBe(true)
  })
  it('prenos teče: »Prenašam z Garmina …«; napaka s »poveži znova« → gumb »Poveži znova« (connectGarmin), brez »Preveri Garmin«', async () => {
    set({ user: { uid: 'u' }, settings: { ...state().settings, garmin: G() }, garminBusy: true })
    await render(<Uvoz />)
    expect(text()).toContain('Prenašam z Garmina …')
    set({ user: { uid: 'u' }, settings: { ...state().settings, garmin: G({ lastError: 'Garmin je prekinil povezavo (žeton ne velja) — poveži znova.' }) } })
    await flush()
    expect(text()).toContain('Povezava ne dela')
    expect(text()).toContain('Garmin je prekinil povezavo (žeton ne velja) — poveži znova.')
    expect(btn('Preveri Garmin')).toBeUndefined()
    await click('Poveži znova')
    expect(fn('connectGarmin')).toHaveBeenCalledTimes(1)
  })
  it('»Odklopi« vpraša (vožnje ostanejo) in šele po potrditvi kliče disconnectGarmin', async () => {
    set({ user: { uid: 'u' }, settings: { ...state().settings, garmin: G() } })
    await render(<GarminCard />)
    await click('Odklopi')
    expect(fn('disconnectGarmin')).not.toHaveBeenCalled()
    expect(text()).toContain('Odklopim Garmin Connect?')
    expect(text()).toContain('Tvoje vožnje ostanejo v aplikaciji.')
    await clickLast('Odklopi')   // gumb v listu potrditve (oba imata isto ime, list je zadnji)
    expect(fn('disconnectGarmin')).toHaveBeenCalledTimes(1)
  })
  it('Garmin spanec vklopljen (brez intervals.icu wellnessOn): korak »Spanec, HRV in mirovni utrip« odkljukan s pripisom', async () => {
    set({ user: { uid: 'u' }, settings: { ...state().settings, garmin: G({ health: true }), intervals: { athleteId: 'i1', apiKey: 'k', name: 'Blaž', pushWorkouts: false } } })
    await render(<Uvoz />)
    expect(text()).toContain('Vklopljeno (prek Garmin Connect) — jutranja pripravljenost je samodejna.')
  })
  it('pomožne: lastSyncLine, garminNeedsReconnect, workoutsLine', () => {
    const now = new Date(`${TODAY}T10:00:00`)
    expect(lastSyncLine(null)).toBe('še ni prenosa')
    expect(lastSyncLine(`${TODAY}T07:12:00`, now)).toBe('zadnji prenos danes 07:12')
    expect(lastSyncLine('2026-10-21T18:05:00', now)).toBe('zadnji prenos 21. 10. 18:05')
    expect(garminNeedsReconnect(null, null)).toBe(false)
    expect(garminNeedsReconnect(G(), null)).toBe(false)
    expect(garminNeedsReconnect(G({ connected: false }), null)).toBe(true)
    expect(garminNeedsReconnect(G(), 'Garmin je zavrnil dostop — poveži znova.')).toBe(true)
    expect(garminNeedsReconnect(G(), 'Strežnik ni dosegljiv — preveri povezavo.')).toBe(false)
    expect(workoutsLine(null)).toBe('Še ni poslano.')
    expect(sp(workoutsLine({ at: `${TODAY}T07:12:00`, n: 9, err: null }, now))).toBe('Na uri: 9 treningov · zadnjič danes 07:12')
    expect(sp(workoutsLine({ at: '2026-10-21T07:12:00', n: 1, err: null }, now))).toBe('Na uri: 1 trening · zadnjič 21. 10. 07:12')
    expect(workoutsLine({ at: `${TODAY}T07:12:00`, n: 0, err: 'Garmin je zavrnil trening (napaka 400).' }, now)).toBe('Napaka: Garmin je zavrnil trening (napaka 400).')
  })
})

/* ---------- Nastavitve: razdelek Garmin ---------- */
describe('Nastavitve · Garmin', () => {
  it('brez povezave razdelka ni', async () => {
    S.route = { name: 'nastavitve', params: {} }
    await render(<Nastavitve />)
    expect(document.getElementById('n-garmin')).toBeNull()
  })
  it('stikala kličejo setGarminOpt; cikel se pri moškem ne pokaže; »Pošlji znova« kliče pushGarminWorkouts(true)', async () => {
    S.route = { name: 'nastavitve', params: { sec: 'n-garmin' } }
    set({ user: { uid: 'u' }, settings: { ...state().settings, garmin: G() }, garminWorkouts: { at: AT712, n: 9, created: 9, updated: 0, removed: 0, errors: [], err: null } })
    await render(<Nastavitve />)
    expect(text()).toContain('Treningi na uro (14 dni)')
    expect(text()).toContain('Na uri: 9 treningov · zadnjič danes 07:12')
    expect(text()).not.toContain('Menstrualni cikel')
    const push = document.getElementById('g-push') as HTMLButtonElement
    expect(push.getAttribute('aria-pressed')).toBe('true')
    await act(async () => { push.click() }); await flush()
    expect(fn('setGarminOpt')).toHaveBeenCalledWith('pushWorkouts', false)
    await act(async () => { (document.getElementById('g-courses') as HTMLButtonElement).click() }); await flush()
    expect(fn('setGarminOpt')).toHaveBeenCalledWith('pushCourses', false)
    const health = document.getElementById('g-health') as HTMLButtonElement
    expect(health.getAttribute('aria-pressed')).toBe('false')
    await act(async () => { health.click() }); await flush()
    expect(fn('setGarminOpt')).toHaveBeenCalledWith('health', true)
    expect(text()).toContain('V AI gre samo ocena pripravljenosti, nikoli surovi podatki.')
    await click('Pošlji znova')
    expect(fn('pushGarminWorkouts')).toHaveBeenCalledWith(true)
    // »Kaj gre v AI ›« odpre razdelek Račun in AI, kjer je vrstica o Garminu
    await click('Kaj gre v AI ›')
    expect(text()).toContain('povzetki vadb gredo v AI kot pri drugih urah; spanec, HRV, utrip, stres in Body Battery samo kot ocena pripravljenosti (številke ostanejo pri tebi); menstrualni cikel nikoli.')
  })
  it('ženska: stikalo »Menstrualni cikel« (NIKOLI v AI) kliče setGarminOpt(cycle); napaka pošiljanja rdeče z dnevi', async () => {
    S.route = { name: 'nastavitve', params: { sec: 'n-garmin' } }
    set({ user: { uid: 'u' }, profile: ANA, settings: { ...state().settings, garmin: G({ cycle: true }) }, garminWorkouts: { at: NOW, n: 3, created: 2, updated: 0, removed: 0, errors: [{ date: '2026-10-25', error: 'napaka 400' }], err: '1 trening Garmin ni sprejel: napaka 400' } })
    await render(<Nastavitve />)
    const cyc = document.getElementById('g-cycle') as HTMLButtonElement
    expect(cyc).toBeTruthy()
    expect(cyc.getAttribute('aria-pressed')).toBe('true')
    expect(text()).toContain('NIKOLI ne gre v AI')
    await act(async () => { cyc.click() }); await flush()
    expect(fn('setGarminOpt')).toHaveBeenCalledWith('cycle', false)
    expect(text()).toContain('Napaka: 1 trening Garmin ni sprejel: napaka 400')
    expect(text()).toContain('25. 10.: napaka 400')
  })
  it('brez dovoljenja HEALTH_EXPORT opis pove, da je treba povezati znova', async () => {
    set({ settings: { ...state().settings, garmin: G({ permissions: ['ACTIVITY_EXPORT', 'WORKOUT_IMPORT'] }) } })
    await render(<GarminOpts />)
    expect(text()).toContain('Garminu nisi dovolil deljenja zdravja — poveži znova in potrdi.')
  })
})

/* ---------- Danes ---------- */
describe('Danes · wellnessActive, cikel, Preveri Garmin', () => {
  // (popravki V7) stres za pripravljenost je včerajšnji cel dan; »ob prebujanju« samo z bbAtWake
  const WELL = [{ date: '2026-10-22', sleepH: 7, sleepScore: 75, hrv: 58, rhr: 49, stress: 55 }, { date: TODAY, sleepH: 7.5, sleepScore: 80, hrv: 60, rhr: 48, stress: 20, bodyBattery: 25, bbAtWake: true }]
  it('spanec z ure prek Garmina (brez wellnessOn): pripravljenost z ikono ure; ReadinessSheet pokaže stres in Body Battery z virom Garmin Connect', async () => {
    set({ plan: [day(TODAY)], wellness: WELL, settings: { ...state().settings, garmin: G({ health: true }) } })
    expect(wellnessActive(S.state.settings)).toBe(true)
    await render(<Danes />)
    expect(document.querySelector('[aria-label="z ure"]')).toBeTruthy()
    await click(/^pripravljenost \d+/)
    expect(text()).toContain('Stres včeraj (Garmin)55')
    expect(text()).toContain('Body Battery')
    expect(text()).toContain('ob prebujanju')
    expect(text()).toContain('prek Garmin Connect')
    expect(text()).not.toContain('prek intervals.icu')
  })
  it('brez zdravja z Garmina: brez ikone ure, list ponudi vklop v Nastavitve → Garmin', async () => {
    set({ plan: [day(TODAY)], wellness: WELL, checkinToday: { date: TODAY, mood: 4, soreness: 2, sleepH: 7 }, settings: { ...state().settings, garmin: G({ health: false }) } })
    await render(<Danes />)
    expect(document.querySelector('[aria-label="z ure"]')).toBeNull()
    await click(/^pripravljenost \d+/)
    expect(text()).toContain('Garmin jih pošlje neposredno (tudi stres in Body Battery).')
    await click('Vklopi v Nastavitvah')
    expect(S.nav.at(-1)).toEqual(['nastavitve', { sec: 'n-garmin' }])
  })
  it('cikel: vrstica faze samo pri ženski z vklopom in podatki; trd dan v menstrualni fazi → namig ob »Olajšaj dan«', async () => {
    const cycle = [{ date: TODAY, dayInCycle: 2, cycleLength: 28, periodLength: 5, phase: 'menstrualna', predicted: false, periodStartDate: '2026-10-22' }]
    // moški (ali cikel izklopljen): nič
    set({ plan: [hard(TODAY)], cycle, settings: { ...state().settings, garmin: G({ cycle: true }) } })
    await render(<Danes />)
    expect(text()).not.toContain('menstrualna faza')
    await unmount()
    set({ profile: ANA, plan: [hard(TODAY)], cycle, settings: { ...state().settings, garmin: G({ cycle: false }) } })
    await render(<Danes />)
    expect(text()).not.toContain('menstrualna faza')
    await unmount()
    set({ profile: ANA, plan: [hard(TODAY)], cycle, settings: { ...state().settings, garmin: G({ cycle: true }) } })
    await render(<Danes />)
    expect(text()).toContain('menstrualna faza · 2. dan — če se počutiš slabše, trd dan olajšaj; lahkega ni treba spreminjati.')
    expect(text()).toContain('Trd dan v menstrualni fazi — če se ne počutiš dobro, ga olajšaj')
    await click(/Trd dan v menstrualni fazi/)
    await wait()
    expect(text()).toContain('Menstrualna faza in trd dan — lahko olajšaš.')
    // brez besed o zdravju / diagnoz
    expect(text()).not.toMatch(/bolezen|zdravnik.*cikel|diagnoz/i)
  })
  it('lahek dan v folikularni fazi: samo faza, brez namiga', async () => {
    set({ profile: ANA, plan: [day(TODAY)], cycle: [{ date: TODAY, dayInCycle: 9, cycleLength: 28, periodLength: 5, phase: 'folikularna', predicted: true, periodStartDate: null }], settings: { ...state().settings, garmin: G({ cycle: true }) } })
    await render(<Danes />)
    expect(text()).toContain('folikularna faza · 9. dan (napoved)')
    expect(text()).not.toContain('olajšaj')
  })
  it('»Preveri Garmin« pod Spremeni: z Garminom neposredno (brez intervals.icu) kliče syncGarmin(true)', async () => {
    set({ plan: [day(TODAY)], settings: { ...state().settings, garmin: G() } })
    await render(<Danes />)
    await click(/^Spremeni/)
    await click(/^Preveri Garmin/)
    await wait()
    expect(fn('syncGarmin')).toHaveBeenCalledWith(true)
    expect(fn('syncIntervals')).not.toHaveBeenCalled()
  })
  it('checkinDone šteje spanec z ure tudi prek Garmina', () => {
    const s = { checkinToday: { date: TODAY, mood: 4, soreness: 2 } as never, wellness: [{ date: TODAY, sleepH: 7 }], today: TODAY }
    expect(checkinDone({ ...s, settings: { garmin: { connected: true, health: true } } })).toBe(true)
    expect(checkinDone({ ...s, settings: { garmin: { connected: true, health: false } } })).toBe(false)
    expect(checkinDone({ ...s, settings: { wellnessOn: true } })).toBe(true)
  })
})

describe('ReadinessSheet · vir', () => {
  const ready = { score: 60, label: 'v redu', color: 'var(--ok)', reasons: ['visok stres'] }
  it('intervals.icu brez Garmina: »prek intervals.icu«; stres brez vrednosti se ne izpiše', async () => {
    await render(<ReadinessSheet open onClose={() => undefined} ready={ready} rec={{ date: TODAY, sleepH: 7, sleepScore: null, hrv: null, hrvBase: null, hrvZ: null, rhr: null, rhrBase: null, rhrDelta: null, penalty: 0, reasons: [] }} tsb={0} checkin={null} wellnessOn hasIntervals device="Garmin Forerunner 255" />)
    expect(text()).toContain('Spanec, HRV in mirovni utrip: Garmin Forerunner 255 · prek intervals.icu.')
    expect(text()).not.toContain('Stres včeraj (Garmin)')
  })
  it('Garmin neposredno s stresom: vrstice in »prek Garmin Connect«; opozorilo pri stresu ≥ 50 in Body Battery < 30; brez bodyBatteryAtWake »najvišja danes«', async () => {
    await render(<ReadinessSheet open onClose={() => undefined} ready={ready} rec={{ date: TODAY, sleepH: 7, sleepScore: null, hrv: null, hrvBase: null, hrvZ: null, rhr: null, rhrBase: null, rhrDelta: null, stress: 62, bodyBattery: 22, penalty: 10, reasons: ['včeraj visok stres', 'Body Battery nizek'] }} tsb={0} checkin={null} wellnessOn hasIntervals={false} garmin />)
    expect(text()).toContain('Stres včeraj (Garmin)62visok — telo si še ni odpočilo')
    expect(text()).toContain('Body Battery22najvišja danes')
    expect(text()).not.toContain('ob prebujanju')
    expect(text()).toContain('Spanec, HRV, utrip, stres in Body Battery: Garmin · prek Garmin Connect.')
  })
})

/* ---------- Plan: »na uri« in trasa ---------- */
describe('Plan · oznaka »na uri«', () => {
  const TOM = '2026-10-24'
  const app = (g: Partial<GarminSettings> | null, w: unknown) => ({ settings: { ...state().settings, garmin: g ? G(g) : null }, garminWorkouts: w } as never)
  const ok = { at: NOW, n: 2, created: 2, updated: 0, removed: 0, errors: [], err: null }
  it('onGarminWatch: samo prihodnji, neopravljen trening za uro, s pošiljanjem brez napake', () => {
    expect(onGarminWatch(day(TOM), TOM, false, app({}, ok))).toBe(true)
    expect(onGarminWatch(day(TOM, { kind: 'moc' }), TOM, false, app({}, ok))).toBe(false)
    expect(onGarminWatch(day(TOM), TOM, true, app({}, ok))).toBe(false)
    expect(onGarminWatch(day(TOM, { done: { at: NOW } as never }), TOM, false, app({}, ok))).toBe(false)
    expect(onGarminWatch(day(TOM, { optional: true }), TOM, false, app({}, ok))).toBe(false)
    expect(onGarminWatch(day(TOM), TOM, false, app({ pushWorkouts: false }, ok))).toBe(false)
    expect(onGarminWatch(day(TOM), TOM, false, app(null, ok))).toBe(false)
    expect(onGarminWatch(day(TOM), TOM, false, app({}, null))).toBe(false)
    expect(onGarminWatch(day(TOM), TOM, false, app({}, { ...ok, err: 'napaka' }))).toBe(false)
    expect(onGarminWatch(day(TOM), TOM, false, app({}, { ...ok, errors: [{ date: TOM, error: 'x' }] }))).toBe(false)
    expect(onGarminWatch(day(TOM), TOM, false, app({}, { ...ok, errors: [{ date: '2026-10-25', error: 'x' }] }))).toBe(true)
  })
  it('v Planu je oznaka na jutrišnjem kolesu, ne na moči', async () => {
    S.route = { name: 'plan', params: {} }
    set({ plan: [day(TODAY), day(TOM), day('2026-10-25', { kind: 'moc', title: 'Moč', zone: null, role: 'moc' })], settings: { ...state().settings, garmin: G() }, garminWorkouts: ok })
    await render(<Plan />)
    const marks = [...document.querySelectorAll('.g-onwatch')]
    expect(marks.length).toBeGreaterThanOrEqual(1)
    expect(marks.every(m => m.textContent === 'na uri')).toBe(true)
  })
})

describe('RouteCard · »Trasa na uro«', () => {
  // krog ~32 km okoli Vodic (točke vsakih ~400 m), višine rahlo valovite
  const N = 80
  const pts: [number, number][] = Array.from({ length: N + 1 }, (_, i) => { const a = (i / N) * 2 * Math.PI; return [46.19 + 0.046 * Math.sin(a), 14.49 + 0.066 * Math.cos(a)] })
  const alt = pts.map((_, i) => 320 + 40 * Math.sin((i / N) * 4 * Math.PI))
  const rec = analyzeTrack({ id: 'r1', source: 'voznja', name: 'Krog Vodice', date: '2026-10-10', rodeMin: 75 }, pts, alt)!
  const lib = { v: 1 as const, raw: [rec], gen: [], home: null, done: [], at: 0 }
  it('z Garminom (trase vklopljene) gumb »Trasa na uro« kliče pushGarminCourse(day, trasa); z izklopom ga ni', async () => {
    const d = day(TODAY, { title: 'Dolga vožnja Z2', durationMin: 80, role: 'dolga' })
    set({ plan: [d], routeLib: lib, settings: { ...state().settings, garmin: G() } })
    await render(<RouteCard day={d} />)
    if (!btn('Trasa na uro')) return   // brez ustreznega predloga trase kartica gumba nima (odvisno od ujemanja dolžine)
    await click('Trasa na uro')
    expect(fn('pushGarminCourse')).toHaveBeenCalledTimes(1)
    expect(fn('pushGarminCourse').mock.calls[0]![0]).toBe(d)
    expect((fn('pushGarminCourse').mock.calls[0]![1] as { id: string }).id).toBe('r1')
    await unmount()
    set({ plan: [d], routeLib: lib, settings: { ...state().settings, garmin: G({ pushCourses: false }) } })
    await render(<RouteCard day={d} />)
    expect(btn('Trasa na uro')).toBeUndefined()
  })
})

/* ---------- vodnik ---------- */
describe('Guide · watchPath', () => {
  it('Garmin Connect je prva pot, intervals.icu alternativa; s povezavo pove, da vožnje že pridejo', () => {
    expect(watchPath({ intervals: null, garmin: null })).toContain('Poveži Garmin Connect v Uvozu — ure ni treba več povezovati prek intervals.icu')
    expect(watchPath({ intervals: null, garmin: null })).toContain('prek intervals.icu')
    expect(watchPath({ intervals: null, garmin: G() }, true)).toBe('Vožnje z ure pridejo same prek Garmin Connect in odkljukajo dan.')
    expect(watchPath({ intervals: { athleteId: 'i', apiKey: 'k' } as never, garmin: null })).toBe('Treningi z ure pridejo sami prek intervals.icu in odkljukajo dan (Nastavitve → Ura in uvoz).')
  })
})
