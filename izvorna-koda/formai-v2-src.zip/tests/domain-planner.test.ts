import { describe, it, expect } from 'vitest'
import { buildWeek, weekContext, macroWeeks, strengthSession, forecastForm, easeDay, FRANJA_2027 } from '../src/domain/training/planner'
import { addDays } from '../src/domain/training/load'
import type { Activity, PlanDay, Profile, Race } from '../src/domain/types'

const now = new Date().toISOString()
const P = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 35, heightCm: 180, weightKg: 78, ftp: 250, ftpDate: '2026-09-01', maxHr: 185, restHr: 50,
  gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: true }, strength: { on: false, equipment: 'none' },
  hoursPerWeek: 9, onboardingDone: true, createdAt: now, updatedAt: now, event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', ...o,
} as Profile)
const wk = (p: Profile, ws: string) => buildWeek({ profile: p, activities: [], weekStart: ws, notBefore: '2026-01-01' })
const race = (o: Partial<Race>): Race => ({ id: 'r' + (o.date || ''), name: 'Tekma', date: '2027-06-12', prio: 'B', ...o } as Race)
const on = (w: PlanDay[], date: string) => w.filter(d => d.date === date)
const bikeMin = (w: PlanDay[]) => w.filter(d => !d.optional && (d.kind === 'kolo' || d.kind === 'test') && d.role !== 'dirka').reduce((s, d) => s + d.durationMin, 0)

describe('druge tekme ne prepišejo cilja sezone ali polnjenja z OH', () => {
  it('B (ali A, ki ni vrh) v soboto pred Franjo: Franja ostane, petek ostane polnjenje z OH', () => {
    for (const r of [race({ name: 'Sobotni vzpon', prio: 'B', type: 'vzpon', distanceKm: 10 }), race({ name: 'A sobota', prio: 'A', distanceKm: 60 })]) {
      const w = wk(P({ races: [r] }), '2027-06-07')
      const sun = on(w, '2027-06-13').find(d => d.kind === 'kolo')!
      expect(sun.role).toBe('dirka'); expect(sun.title).toBe('Maraton Franja — 156 km')
      expect(on(w, '2027-06-12').find(d => d.kind === 'kolo')!.role).toBe('dirka')
      expect(on(w, '2027-06-11')[0]!.title).toBe('Počitek + polnjenje OH')
    }
  })
  it('B v ponedeljek po Franji: nedelja ostane Franja (ne predaktivacija)', () => {
    const w = wk(P({ races: [race({ name: 'B pon', date: '2027-06-14' })] }), '2027-06-07')
    expect(on(w, '2027-06-13').find(d => d.kind === 'kolo')!.title).toBe('Maraton Franja — 156 km')
  })
  it('dve tekmi isti dan: obe vidni v enem dnevu', () => {
    const w = wk(P({ races: [race({ id: 'c1', name: 'C1', date: '2027-03-17', prio: 'C' }), race({ id: 'c2', name: 'C2', date: '2027-03-17', prio: 'C' })] }), '2027-03-15')
    const wed = on(w, '2027-03-17').filter(d => d.kind === 'kolo')
    expect(wed).toHaveLength(1)
    expect(wed[0]!.title).toBe('C1 + C2'); expect(wed[0]!.role).toBe('dirka'); expect(['c1', 'c2']).toContain(wed[0]!.raceId)
    expect(wed[0]!.why).toMatch(/Na isti dan sta dve tekmi/)
  })
})

describe('vrnitev po off-seasonu po zadnji tekmi', () => {
  it('šteje od konca off-seasona: 3 lahki tedni (od ~60 % ur), nato razbremenilni s testom — kot brez cilja', () => {
    const p = P({ event: { name: 'Pretekla', date: '2026-08-30', distanceKm: 120 }, cycleStart: '2026-09-07', offSeasonWeeks: 3 })
    const noEvent = { ...p, event: null }
    const ws = ['2026-09-28', '2026-10-05', '2026-10-12', '2026-10-19']
    const c = ws.map(x => weekContext(p, x))
    expect(c.map(x => x.easy)).toEqual([1, 2, 3, 0])
    expect(c.map(x => x.test)).toEqual([false, false, false, true])
    expect(c.every(x => x.phase === 'osnova')).toBe(true)
    expect(c[0]!.hours).toBeLessThanOrEqual(9 * 0.65)
    expect(ws.map(x => weekContext(noEvent, x).easy)).toEqual([1, 2, 3, 0])
    expect(wk(p, '2026-09-28').some(d => d.role === 'kljucna')).toBe(false)
  })
})

describe('malo ur: razbremenilni in tapering sta res lažja, noben teden čez 1,1 × cilj', () => {
  it('3–6 h na teden čez cel makrocikel', () => {
    for (const h of [3, 4, 5, 6]) {
      const p = P({ hoursPerWeek: h })
      let prevLoad: number | null = null
      for (const w of macroWeeks(p, '2026-09-25')) {
        const m = bikeMin(wk(p, w.weekStart)), tgt = w.hours * 60
        expect(m, `${h} h ${w.weekStart}`).toBeLessThanOrEqual(tgt * 1.1 + 1)
        if (w.recovery && w.phase !== 'prehod' && prevLoad) expect(m, `razbremenilni ${w.weekStart}`).toBeLessThanOrEqual(prevLoad * 0.7 + 1)
        if (w.phase === 'tapering' && prevLoad) expect(m, `tapering ${w.weekStart}`).toBeLessThanOrEqual(prevLoad * 0.6 + 1)
        if (!w.recovery && !['prehod', 'po', 'tapering', 'dirka'].includes(w.phase)) prevLoad = tgt
      }
    }
  })
  it('pri 9 h ostane kot prej (razbremenilni ~4,5 h, tapering ~5,5 h)', () => {
    const p = P()
    expect(bikeMin(wk(p, '2026-10-19')) / 60).toBeCloseTo(4.5, 0)
    expect(Math.abs(bikeMin(wk(p, '2027-05-31')) - 330)).toBeLessThanOrEqual(10)
  })
})

describe('forma nove uporabnice ne skrajša tedna', () => {
  it('14 dni zgodovine (TSB kratko po začetku) → brez −15 %', () => {
    const today = new Date(); const t = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`
    const acts = Array.from({ length: 14 }, (_, i) => ({ id: 'a' + i, source: 'intervals', sport: 'kolo', date: addDays(t, -1 - i), name: 'v', durationMin: 150, tss: 150, aiEligible: true, geoRetain: true, createdAt: now, updatedAt: now }) as Activity)
    const p = P({ event: null, cycleStart: null })
    const w = buildWeek({ profile: p, activities: acts, weekStart: addDays(t, -((new Date(t + 'T12:00:00Z').getUTCDay() + 6) % 7)) })
    expect(w.some(d => (d.why || '').includes('−15 %'))).toBe(false)
  })
})

describe('moč: obseg ponovitev ostane, teža gor po zgornji meji', () => {
  const p = P({ strength: { on: true, equipment: 'gym' } })
  const log = (reps: string, kg: number, date = '2026-10-01'): Activity => ({ id: date + reps, source: 'manual', sport: 'moc', date, name: 'Fitnes — noge (težko)', exercises: [{ name: 'Polovični počep s palico', sets: 4, reps, kg }], aiEligible: true, geoRetain: true, createdAt: now, updatedAt: now } as Activity)
  it('prepisan razpon »5–8« → isti razpon in kg; zgornja meja »8« → +5 kg; nikoli 17–20 ponovitev', () => {
    const same = strengthSession('fitnesA', p, [log('5–8', 60)])
    expect(same.exercises[0]).toMatchObject({ reps: '5–8', kg: 60 }); expect(same.progressed).toBe(false)
    const up = strengthSession('fitnesA', p, [log('8', 60)])
    expect(up.exercises[0]).toMatchObject({ reps: '5–8', kg: 65 }); expect(up.progressed).toBe(true)
    expect(strengthSession('fitnesA', p, [log('8, 8, 7, 6', 60)]).exercises[0]!.kg).toBe(60)      // ne v vseh serijah
    let acts: Activity[] = []
    for (let i = 1; i <= 14; i++) {
      const s = strengthSession('fitnesA', p, acts)
      acts = [...acts, { ...log(s.exercises[0]!.reps, 60, `2026-10-${String(i).padStart(2, '0')}`), exercises: s.exercises.map(e => ({ ...e })) }]
    }
    expect(strengthSession('fitnesA', p, acts).exercises.every(e => !/1[3-9]|20/.test(e.reps))).toBe(true)
  })
  it('doma: ne več kot imaš uteži', () => {
    const home = P({ strength: { on: true, equipment: 'home' }, gear: { bikeOutdoor: true, trainer: false, noBike: false, dumbbells: true, dumbbellKg: 10 } })
    const last: Activity = { id: 'h', source: 'manual', sport: 'moc', date: '2026-10-01', name: 'Moč — noge in jedro', exercises: [{ name: 'Bolgarski počep', sets: 3, reps: '12', kg: 10 }], aiEligible: true, geoRetain: true, createdAt: now, updatedAt: now } as Activity
    expect(strengthSession('noge', home, [last]).exercises.find(e => e.name === 'Bolgarski počep')!.kg).toBe(10)
  })
})

describe('napoved forme, dan v tednu, olajšan dan', () => {
  it('napoved vključi današnjo še neopravljeno sejo', () => {
    const d: PlanDay = { id: 'd', date: '2026-11-10', kind: 'kolo', title: 'VO2max', desc: '', durationMin: 75, zone: 'Z5', role: 'kljucna', tssTarget: 70, source: 'rules', createdAt: now, updatedAt: now }
    expect(forecastForm([], [d], '2026-11-10')).toMatchObject({ atl: 10, date: '2026-11-10' })
    expect(forecastForm([], [{ ...d, done: { at: now } }], '2026-11-10')!.atl).toBe(0)
  })
  it('dan tekme v razlagi tedna ne glede na časovni pas naprave', () => {
    const prev = process.env.TZ
    try {
      for (const tz of ['Europe/Ljubljana', 'America/Los_Angeles', 'Pacific/Kiritimati']) {
        process.env.TZ = tz
        const w = wk(P({ races: [race({ id: 'c', name: 'Nedeljska C', date: '2027-03-21', prio: 'C' })] }), '2027-03-15')
        expect(w.find(d => /Tekma v /.test(d.why || ''))!.why, tz).toMatch(/Tekma v nedeljo: Nedeljska C/)
      }
    } finally { if (prev === undefined) delete process.env.TZ; else process.env.TZ = prev }
  })
  it('olajšan dan: trd trening ne na dan med dvema trdima, ne na dan pred tekmo', () => {
    const d = (date: string, o: Partial<PlanDay>): PlanDay => ({ id: date, date, kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: now, updatedAt: now, ...o })
    const rest = (date: string): PlanDay => d(date, { kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, role: null })
    const vo2 = d('2026-11-10', { title: 'VO2max 5 × 4 min', zone: 'Z5', role: 'kljucna', durationMin: 90 })
    // čet ključni, pet prost, sob dolga → petek bi bil tretji trd dan zapored
    const w1 = [rest('2026-11-09'), vo2, d('2026-11-11', {}), d('2026-11-12', { title: 'Prag', zone: 'Z4', role: 'kljucna' }), rest('2026-11-13'), d('2026-11-14', { title: 'Dolga Z2', role: 'dolga', durationMin: 180 }), d('2026-11-15', {})]
    const out1 = easeDay(w1, '2026-11-10')!
    expect(out1).toHaveLength(1); expect(out1[0]!.optional).toBe(true); expect(out1[0]!.why).toMatch(/odpade/)
    // prost dan pred tekmo ni primeren; prost dan z lahkimi sosedi je
    const w2 = [rest('2026-11-09'), vo2, d('2026-11-11', {}), rest('2026-11-12'), d('2026-11-13', {}), rest('2026-11-14'), d('2026-11-15', { title: 'Tekma', zone: 'dirka', role: 'dirka' })]
    const out2 = easeDay(w2, '2026-11-10')!
    expect(out2.find(x => x.date !== '2026-11-10')!.date).toBe('2026-11-12')
    const w3 = [rest('2026-11-09'), vo2, d('2026-11-11', { title: 'Prag', zone: 'Z4', role: 'kljucna' }), d('2026-11-12', { title: 'Prag', zone: 'Z4', role: 'kljucna' }), d('2026-11-13', {}), rest('2026-11-14'), d('2026-11-15', { title: 'Tekma', zone: 'dirka', role: 'dirka' })]
    expect(easeDay(w3, '2026-11-10')).toHaveLength(1)                                    // sobota je dan pred tekmo
  })
})
