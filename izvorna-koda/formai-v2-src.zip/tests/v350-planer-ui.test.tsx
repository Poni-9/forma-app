// v3.50 PLANER (UI): H21 — »Ta teden: …, ~X h« v kartici preteklega tedna iz sestavljenega tedna (brez tekme), ne iz formule.
import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any }))
vi.mock('@/state/store', () => ({ useApp: () => S.state, getState: () => S.state, toast: vi.fn() }))

import { LastWeekCard } from '@/ui/LastWeekCard'
import { FRANJA_2027 } from '@/domain/training/planner'
import type { PlanDay } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

const today = '2026-11-09'   // ponedeljek
const day = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: 'd' + date + (o.title || ''), date, kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, zone: 'Z2', tssTarget: 40, role: 'lahka', source: 'rules', createdAt: 'x', updatedAt: 'x', done: null, ...o } as PlanDay)
const profile = { sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, ftpDate: '2026-09-20', lthr: 184, hoursPerWeek: 11, level: 3, gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, strength: { on: false, equipment: 'none' }, onboardingDone: true, createdAt: 'x', updatedAt: 'x', event: { ...FRANJA_2027 }, races: [], cycleStart: '2026-09-21' }

let div: HTMLDivElement, root: Root
beforeEach(() => { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div); try { localStorage.clear() } catch { /* */ } })
afterEach(async () => { await act(async () => root.unmount()); div.remove() })

describe('H21 kartica preteklega tedna', () => {
  it('ure tega tedna iz načrta (2 h 30 min na kolesu, tekma ne šteje) — prej formula ~9 h', async () => {
    const plan = [
      day('2026-11-03', { done: { at: 'x' } }), day('2026-11-05'),                                           // pretekli teden
      day('2026-11-10', { durationMin: 90 }), day('2026-11-12', { durationMin: 60 }),                       // ta teden: 2 h 30 min
      day('2026-11-15', { title: 'Kriterij', durationMin: 120, zone: 'dirka', role: 'dirka', raceId: 'r1' }),
    ]
    S.state = { today, profile, plan, activities: [], checkins: [], settings: {} }
    await act(async () => { root.render(<LastWeekCard />) })
    expect(div.textContent).toMatch(/Ta teden: [^,]+, ~2,5 h\./)
  })
})
