import { describe, it, expect } from 'vitest'
import { icuWorkout, workoutDiff, durText } from '../src/domain/intervals/workouts'
import type { PlanDay, Profile } from '../src/domain/types'

const now = new Date().toISOString()
const base = { sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, lthr: 184, maxHr: 199, restHr: 52, strength: { on: false, equipment: 'home' }, onboardingDone: true, createdAt: now, updatedAt: now } as unknown as Profile
const hrOnly: Profile = { ...base, gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false } }
const withPm: Profile = { ...base, gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true } }
const day = (o: Partial<PlanDay>): PlanDay => ({ id: 'x', date: '2026-09-29', kind: 'kolo', title: 'Z2 vzdržljivost', desc: '', durationMin: 70, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: now, updatedAt: now, ...o })

describe('trening na uro (intervals.icu besedilo)', () => {
  it('VO2max 4 × 4 min brez merilnika → blok 4x v % LTHR', () => {
    const w = icuWorkout(day({ title: 'VO2max 4 × 4 min', desc: '15 min ogrevanje, 4 × 4 min, vmes 4 min lahko, 10 min izvoz', zone: 'Z5', role: 'kljucna', durationMin: 75, target: { lo: 259, hi: 276 } }), hrOnly)!
    expect(w.uid).toBe('formai-2026-09-29'); expect(w.name).toBe('VO2max 4 × 4 min')
    expect(w.description).toBe('- Ogrevanje 15m 81-89% LTHR\n\nInterval 4x\n- 4m 100-108% LTHR\n- Lahko 4m 60-80% LTHR\n\n- Iztek 10m 60-80% LTHR')
    expect(w.movingTime).toBe((15 + 4 * 8 + 10) * 60)
  })
  it('z merilnikom moči so delovni koraki v vatih', () => {
    const w = icuWorkout(day({ title: 'Sweet spot 3 × 12 min', desc: '', zone: 'Z4', role: 'kljucna', durationMin: 90, target: { lo: 210, hi: 225 } }), withPm)!
    expect(w.description).toContain('- 12m 210-225w')
    expect(w.description).toContain('56-75%')
  })
  it('Z2 vožnja in test', () => {
    const z2 = icuWorkout(day({}), hrOnly)!
    expect(z2.description).toBe('- Ogrevanje 8m 60-80% LTHR\n\n- Vzdržljivost 56m 81-89% LTHR\n\n- Iztek 6m 60-80% LTHR')
    expect(z2.movingTime).toBe(70 * 60)
    const t = icuWorkout(day({ kind: 'test', title: '20-minutni test FTP', role: 'test', durationMin: 60 }), hrOnly)!
    expect(t.description).toContain('- Test 20m 95-105% LTHR')
    expect(icuWorkout(day({ title: 'Z2 — sam ali v skupini', durationMin: 50 }), hrOnly)!.description).toContain('- Sam ali v skupini ')
    expect(icuWorkout(day({ title: 'Dolga Z2', role: 'dolga', durationMin: 120 }), hrOnly)!.description).toContain('- Dolga ')
    expect(icuWorkout(day({ kind: 'moc', title: 'Moč — jedro' }), hrOnly)).toBeNull()
    expect(icuWorkout(day({ role: 'dirka', title: 'Maraton Franja' }), hrOnly)).toBeNull()
    expect(durText(90)).toBe('1m30'); expect(durText(45)).toBe('45s'); expect(durText(600)).toBe('10m')
  })
  it('razlika: pošlje samo nove ali spremenjene, pobriše samo svoje, tuje pusti', () => {
    const a = icuWorkout(day({}), hrOnly)!, b = icuWorkout(day({ date: '2026-09-30', title: 'Regeneracija', zone: 'Z1', role: 'regen', durationMin: 45 }), hrOnly)!
    const existing = [
      { id: 1, uid: a.uid, name: a.name, description: a.description, moving_time: a.movingTime },
      { id: 2, uid: 'formai-2026-10-01', name: 'Star trening', description: '- 10m 60% LTHR', moving_time: 600 },
      { id: 3, uid: 'trainerroad-xyz', name: 'Tuji trening', description: '- 10m 60%', moving_time: 600 },
      { id: 4, uid: null, name: 'Ročno vpisan', description: '', moving_time: null },
    ]
    const d = workoutDiff([a, b], existing)
    expect(d.create.map(x => x.uid)).toEqual([b.uid]); expect(d.update).toEqual([])
    expect(d.remove).toEqual([2])
    const d2 = workoutDiff([{ ...a, name: 'Z2 — daljša vožnja' }], existing)
    expect(d2.create).toEqual([]); expect(d2.update.map(u => u.id)).toEqual([1])
    // če strežnik uid zavrže, nas reši external_id; dvojnik istega dne gre stran
    const d3 = workoutDiff([a], [{ id: 7, uid: 'srv-uid', external_id: a.uid, name: a.name, description: a.description, moving_time: a.movingTime }, { id: 8, uid: null, external_id: a.uid, name: 'x', description: '', moving_time: 0 }])
    expect(d3.create).toEqual([]); expect(d3.update).toEqual([]); expect(d3.remove).toEqual([8])
  })
})
