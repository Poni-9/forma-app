import { describe, it, expect } from 'vitest'
import { navigate, scrollAfterRoute, parseHash } from '../src/app/router'

describe('višina zaslona ob prehodu', () => {
  it('zavihek/gumb → nov zaslon na vrhu; Nazaj → višina, kjer si zaslon zapustil; isti naslov → nič', () => {
    location.hash = '#/napredek'
    scrollAfterRoute()
    Object.defineProperty(window, 'scrollY', { value: 2584, configurable: true })
    navigate('prehrana')
    expect(parseHash().name).toBe('prehrana')
    expect(scrollAfterRoute('#/prehrana')).toBe('top')
    expect(scrollAfterRoute('#/prehrana')).toBeNull()            // zastavica je porabljena
    expect(scrollAfterRoute('#/napredek')).toBe(2584)            // Nazaj na Napredek
    navigate('prehrana')                                         // isti naslov: brez prehoda
    expect(scrollAfterRoute('#/prehrana')).toBeNull()
  })
})
