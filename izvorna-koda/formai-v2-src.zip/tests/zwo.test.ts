import { describe, it, expect } from 'vitest'
import { zwoFor, hrZoneRows, powerZoneRows, powerOf } from '../src/domain/training/zwo'
import { stepsFor, totalSec } from '../src/domain/training/workout'
import type { PlanDay, Profile } from '../src/domain/types'

const NOW = '2026-10-03T08:00:00.000Z'
const p = { sex: 'm', age: 30, weightKg: 75, ftp: 250, maxHr: 192, restHr: 50, lthr: 175, gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: true }, strength: { on: false, equipment: 'home' }, createdAt: NOW, updatedAt: NOW } as Profile
const day = (o: Partial<PlanDay>): PlanDay => ({ id: 'd', date: '2026-10-06', kind: 'kolo', title: 'Z2 vzdržljivost', desc: 'Enakomerno v Z2.', durationMin: 60, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })

/** Skupno trajanje iz .zwo (IntervalsT = ponovitve × (delo + odmor)). */
function zwoSec(xml: string): number {
  let t = 0
  for (const m of xml.matchAll(/<(Warmup|Cooldown|SteadyState|FreeRide) Duration="(\d+)"/g)) t += +m[2]!
  for (const m of xml.matchAll(/<IntervalsT Repeat="(\d+)" OnDuration="(\d+)" OffDuration="(\d+)"/g)) t += +m[1]! * (+m[2]! + +m[3]!)
  return t
}

describe('izvoz za trenažer (.zwo)', () => {
  it('VO2max: ogrevanje, blok ponovitev, iztek; trajanje kot v načrtu; veljaven XML', () => {
    const d = day({ title: 'VO2max 5 × 4 min', desc: '5 × 4 min pri 108–115 % FTP, vmes 4 min lahko.', durationMin: 75, zone: 'Z5', role: 'kljucna', target: { lo: 270, hi: 288 } })
    const z = zwoFor(d, p)!
    expect(z.name).toBe('formai-2026-10-06-vo2max-5-4-min.zwo')
    expect(z.xml).toMatch(/<Warmup Duration="\d+" PowerLow="0.45" PowerHigh="0.\d+"/)
    expect(z.xml).toMatch(/<IntervalsT Repeat="[45]" OnDuration="240" OffDuration="240" OnPower="1.12" OffPower="0.5"/)
    expect(z.xml).toMatch(/<Cooldown /)
    expect(zwoSec(z.xml)).toBe(totalSec(stepsFor(d, p).filter(s => s.sec > 0)))
    const doc = new DOMParser().parseFromString(z.xml, 'application/xml')
    expect(doc.getElementsByTagName('parsererror').length).toBe(0)
    expect(doc.querySelector('name')!.textContent).toBe('VO2max 5 × 4 min')
  })
  it('Z2: enakomerno v coni; test in šprint brez ERG (FreeRide)', () => {
    const z2 = zwoFor(day({}), p)!
    expect(z2.xml).toMatch(/<SteadyState Duration="\d+" Power="0.65"/)
    expect(zwoSec(z2.xml)).toBe(totalSec(stepsFor(day({}), p).filter(s => s.sec > 0)))
    const t = zwoFor(day({ kind: 'test', title: 'Test FTP 20 min', desc: '20-minutni test.', durationMin: 60, zone: 'test', role: 'test' }), p)!
    expect(t.xml).toMatch(/<FreeRide Duration="1200"/)
    expect(powerOf({ kind: 'delo', label: 'šprint', sec: 10, z: 'max' }, { target: null }, p)).toBeNull()
  })
  it('počitek, moč, tek in dirka nimajo .zwo; posebni znaki so ubežani', () => {
    expect(zwoFor(day({ kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, role: null }), p)).toBeNull()
    expect(zwoFor(day({ kind: 'moc', title: 'Moč', zone: null, role: 'moc' }), p)).toBeNull()
    expect(zwoFor(day({ role: 'dirka', title: 'Dirka' }), p)).toBeNull()
    expect(zwoFor(day({ title: 'Z2 <&> "test"' }), p)!.xml).toContain('<name>Z2 &lt;&amp;&gt; &quot;test&quot;</name>')
  })
})

describe('tvoje cone', () => {
  it('utrip po pražnem utripu (ali oceni iz max in mirovnega)', () => {
    expect(hrZoneRows(p)!.rows.map(r => r.range)).toEqual(['pod 142', '142–156', '158–163', '165–175', 'nad 175'])
    const est = hrZoneRows({ maxHr: 192, restHr: 50, lthr: null })!
    expect(est.estimated).toBe(true); expect(est.lthr).toBe(171)
    expect(hrZoneRows({ maxHr: null, restHr: null, lthr: null })).toBeNull()
  })
  it('moč iz FTP (Coggan, 7 con)', () => {
    expect(powerZoneRows({ ftp: 250 })!.map(r => r.range)).toEqual(['pod 140', '140–188', '190–225', '228–263', '265–300', '303–375', 'nad 375'])
    expect(powerZoneRows({ ftp: null })).toBeNull()
  })
})
