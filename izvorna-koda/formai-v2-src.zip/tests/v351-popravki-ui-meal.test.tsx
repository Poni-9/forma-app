// v3.51 POPRAVKI51-UI (U8): Enter v listu obroka nima več dvojnega vpisa (samoponavljanje, dva Enterja pred zaprtjem lista).
import 'fake-indexeddb/auto'
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'prehrana', params: {} as Record<string, string> }, added: [] as any[], toasts: [] as string[] }))
vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
vi.mock('@/state/store', async (orig) => ({
  ...(await orig<typeof import('../src/state/store')>()),
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  // shranjevanje traja (IndexedDB): drugi Enter pride, preden se list zapre
  addMeal: async (m: unknown) => { S.added.push(m); await new Promise(r => setTimeout(r, 5)) },
  removeMeal: async () => undefined,
  saveCheckin: async () => undefined,
  setPlanDone: async () => undefined,
  toast: (m: string) => { S.toasts.push(m) },
}))
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => S.route, subscribeRoute: () => () => undefined }))

import * as repo from '../src/data/repo'
import { Prehrana } from '@/screens/Prehrana'
import { FRANJA_2027 } from '../src/domain/training/planner'
import type { Profile } from '../src/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const NOW = '2026-10-01T08:00:00.000Z'
const TODAY = '2026-10-17'   // sobota
const P = {
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, restHr: 55, maxHr: 200, lthr: 184, ftp: 240, ftpDate: '2026-09-20',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, hoursPerWeek: 14, baseHours: null,
  strength: { on: false, equipment: 'home', phases: null }, strengthDays: 0, goal: 'dirka', deficit: 400, neat: 1.4,
  event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', onboardingDone: true, trainTime: 'popoldne', createdAt: NOW, updatedAt: NOW, races: [],
} as unknown as Profile

let div: HTMLDivElement, root: Root
afterEach(async () => {
  await act(async () => root?.unmount()); div?.remove(); vi.useRealTimers()
  S.added.length = 0; S.toasts.length = 0
  try { localStorage.clear() } catch { /* */ }
})
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(b.textContent || '') || re.test(b.getAttribute('aria-label') || ''))
async function typeIn(el: Element | null, v: string) {
  expect(el).toBeTruthy()
  await act(async () => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(el, v); el!.dispatchEvent(new Event('input', { bubbles: true })) })
}
const enter = (el: Element, repeat = false) => el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true, repeat }))
const wait = (ms = 20) => act(async () => { await new Promise(r => setTimeout(r, ms)) })

async function open(): Promise<Element> {
  vi.useFakeTimers({ toFake: ['Date'] })
  vi.setSystemTime(new Date(`${TODAY}T12:30:00`))
  S.state = { ready: true, settings: repo.defaultSettings(), changes: [], toast: null, sync: { state: 'off' }, authKnown: true, pro: false, wellness: null, checkinToday: null, today: TODAY, profile: P, plan: [], activities: [], mealsToday: [], recentMeals: [], checkins: [], weather: null, user: null }
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root.render(<Prehrana />) })
  const add = btn(/^Dodaj /)
  expect(add).toBeTruthy()
  await act(async () => { (add as HTMLElement).click(); await new Promise(r => setTimeout(r, 0)) })
  await typeIn(document.querySelector('#meal-name'), 'skyr')
  await typeIn(document.querySelector('#meal-kcal'), '120')
  return document.querySelector('#meal-kcal')!
}

describe('U8 Enter v listu obroka', () => {
  it('samoponavljanje (keydown z repeat) → en obrok', async () => {
    const el = await open()
    await act(async () => { enter(el); enter(el, true) })
    await wait()
    expect(S.added).toHaveLength(1)
    expect(S.added[0]).toMatchObject({ name: 'skyr', kcal: 120 })
  })
  it('dva Enterja (brez repeat), preden se shranjevanje konča → en obrok', async () => {
    const el = await open()
    await act(async () => { enter(el); enter(el) })
    await wait()
    expect(S.added).toHaveLength(1)
  })
  it('napaka v obrazcu ne zaklene shranjevanja', async () => {
    const el = await open()
    await typeIn(el, '')
    await act(async () => { enter(el) })
    await wait()
    expect(S.added).toHaveLength(0)
    await typeIn(el, '120')
    await act(async () => { enter(el) })
    await wait()
    expect(S.added).toHaveLength(1)
  })
})
