import { describe, it, expect, vi, afterEach } from 'vitest'
import { moveKeySession, moveKeyPlan, checkRide } from '../src/domain/training/review'
import { makeLoop, brouterRoute, coarse } from '../src/domain/routes/brouter'
import type { PlanDay } from '../src/domain/types'

const now = new Date().toISOString()
const day = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: date, date, kind: 'kolo', title: 'Z2 vzdržljivost', desc: '', durationMin: 60, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: now, updatedAt: now, ...o })

describe('zamujen ključni trening: tekma je ključni dan', () => {
  // pon počitek · tor VO2max · sre Z2 · čet prag · pet regeneracija · sob predaktivacija · ned tekma B
  const week = [
    day('2027-03-15', { kind: 'pocitek', title: 'Počitek', role: null, durationMin: 0 }),
    day('2027-03-16', { title: 'VO2max 5 × 4 min', zone: 'Z5', role: 'kljucna', durationMin: 90 }),
    day('2027-03-17', { title: 'Z2 vzdržljivost + 6 × 10 s šprint' }),
    day('2027-03-18', { title: 'Prag na ravnini 3 × 12 min', zone: 'Z4', role: 'kljucna', durationMin: 105 }),
    day('2027-03-19', { title: 'Regeneracija', zone: 'Z1', role: 'regen', durationMin: 45 }),
    day('2027-03-20', { title: 'Predaktivacija 3 × 1 min', zone: 'Z5', role: 'lahka', durationMin: 40 }),
    day('2027-03-21', { title: 'B tekma — 90 km', zone: 'dirka', role: 'dirka', durationMin: 180 }),
  ]
  it('nikoli na dan pred tekmo; razlog za prikaz', () => {
    expect(moveKeySession(week, week[1]!, '2027-03-16')).toBeNull()
    expect(moveKeySession(week, week[3]!, '2027-03-18')).toBeNull()
    const r = moveKeyPlan(week, week[3]!, '2027-03-18')
    expect(r.days).toBeNull(); expect(r.reason).toMatch(/tekm/)
  })
  it('lahek dan z lahkima sosedoma je še vedno dober', () => {
    const w = [week[1]!, day('2027-03-18'), day('2027-03-19'), day('2027-03-20'), day('2027-03-21', { title: 'Dolga Z2', role: 'dolga', durationMin: 120 })]
    const r = moveKeyPlan(w, week[1]!, '2027-03-16')
    expect(r.days?.[1].date).toBe('2027-03-18'); expect(r.reason).toBeNull()
  })
})

describe('cone utripa same ničle = brez podatkov', () => {
  it('ne trdi »bila je vožnja v tempu«', () => {
    const c = checkRide({ role: 'kljucna', zone: 'Z5', title: 'VO2max 4 × 4 min', kind: 'kolo', durationMin: 75 }, { durationMin: 75, hrZoneSec: [0, 0, 0, 0, 0, 0, 0], hrZoneTop: null, avgHr: null, maxHr: null })!
    expect(c.status).toBe('delno'); expect(c.verdict).toMatch(/Brez podatkov o utripu/)
  })
})

describe('zasebnost: dom gre na brouter.de zaokrožen na ~100 m', () => {
  const urls: string[] = []
  const orig = globalThis.fetch
  afterEach(() => { globalThis.fetch = orig; urls.length = 0 })
  const fake = () => {
    globalThis.fetch = vi.fn(async (url: RequestInfo | URL) => {
      const u = String(url); urls.push(u)
      if (u.endsWith('/profile')) return { ok: true, json: async () => ({ profileid: 'custom_test' }) } as unknown as Response
      const coords = Array.from({ length: 40 }, (_, i) => [14.5 + i * 0.002, 46.1 + Math.sin(i / 6) * 0.01, 300 + i])
      return { ok: true, json: async () => ({ features: [{ properties: { 'track-length': '30000' }, geometry: { coordinates: coords } }] }) } as unknown as Response
    }) as unknown as typeof fetch
  }
  it('krog od doma in točke poti: začetek in konec zaokrožena, klanci natančni', async () => {
    fake()
    const home: [number, number] = [46.123456, 14.654321]
    const r = await makeLoop(home, 90, () => 90, { seed: 1, wantFlat: true })
    const sent = urls.filter(u => u.includes('lonlats='))
    expect(sent.length).toBeGreaterThan(0)
    for (const u of sent) { expect(u).not.toContain('14.65432'); expect(u).not.toContain('46.12346'); expect(u).toContain('lonlats=14.65400,46.12300') }
    expect(r.via[0]).toEqual(coarse(home))
    urls.length = 0
    await brouterRoute([home, [46.20001, 14.70001], home])
    expect(urls[0]).toContain('14.70001,46.20001')                 // vmesna točka (klanec) ostane natančna
    expect(urls[0]).toMatch(/lonlats=14\.65400,46\.12300\|.*\|14\.65400,46\.12300&/)
  })
})
