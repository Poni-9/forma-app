import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { parseBackup, exportForFile } from '../src/data/backup'
import { todayIso } from '../src/domain/training/load'
import type { Activity, MealEntry } from '../src/domain/types'

const today = todayIso()
const NOW = new Date().toISOString()
const ride = (id: string, o: Partial<Activity> = {}): Activity => ({ id, source: 'intervals', originHint: 'GARMIN', sport: 'kolo', date: today, start: today + 'T07:00:00.000Z', name: 'Vožnja', durationMin: 90, distKm: 40, aiEligible: true, geoRetain: true, ext: { intervalsId: 'i-' + id }, createdAt: NOW, updatedAt: NOW, ...o })
const meal = (id: string, kcal: number): MealEntry => ({ id, date: today, time: '08:00', slot: 'zajtrk', name: 'Obrok ' + id, grams: null, kcal, proteinG: 20, carbsG: null, fatG: null, confidence: 'srednja', source: 'manual', thumb: null, createdAt: NOW })

beforeEach(async () => { await repo.wipeAll(); localStorage.clear(); await store.reloadAll() })

describe('varnostna kopija — branje', () => {
  it('zavrne, kar ni kopija FORMAI, in prazno kopijo', () => {
    expect(() => parseBackup('ni json')).toThrow(/ni varnostna kopija/)
    expect(() => parseBackup('{"a":1}')).toThrow(/ni varnostna kopija/)
    expect(() => parseBackup(JSON.stringify({ version: 3, activities: [ride('a')] }))).toThrow(/druge različice/)
    expect(() => parseBackup(JSON.stringify({ version: 2, activities: [], meals: [] }))).toThrow(/prazna/)
  })
  it('izpusti neveljavne zapise in prešteje veljavne', () => {
    const p = parseBackup(JSON.stringify({ version: 2, exportedAt: '2026-10-01T10:00:00.000Z', activities: [ride('a'), { id: 'x' }, null], meals: [meal('m', 300), { id: 'b', date: 'včeraj', kcal: 5 }], plan: [], checkins: [{ date: today, weightKg: 75 }, { weightKg: 1 }], profile: { sex: 'm', onboardingDone: true }, settings: { lang: 'sl', wellnessOn: true } }))
    expect(p.info).toEqual({ exportedAt: '2026-10-01T10:00:00.000Z', activities: 1, plan: 0, meals: 1, checkins: 1, profile: true })
    expect(p.state.settings).not.toHaveProperty('wellnessOn')        // nastavitev samo te naprave se ne prenese
  })
})

describe('varnostna kopija — obnovitev', () => {
  it('izvoz → izbris → nov obrok → uvoz: vse je spet tu, nič se ne izgubi', async () => {
    await store.updateProfile({ sex: 'm', age: 30, weightKg: 75, heightCm: 180, ftp: 250, onboardingDone: true, name: 'Test' })
    await store.addActivities([ride('a1'), ride('a2', { start: today + 'T15:00:00.000Z', ext: { intervalsId: 'i-a2' } })])
    await store.addMeal(meal('m1', 500))
    const text = JSON.stringify(await repo.exportAll())
    await repo.wipeAll(); await store.reloadAll()
    await store.addMeal(meal('m2', 300))
    const r = await store.restoreFromBackup(parseBackup(text), { fromBackup: true })
    expect(r).toMatchObject({ activities: 2, meals: 1, changed: true })
    const s = store.getState()
    expect(s.activities.map(a => a.id).sort()).toEqual(['a1', 'a2'])
    expect(s.mealsToday.map(m => m.id).sort()).toEqual(['m1', 'm2'])
    expect(s.profile).toMatchObject({ ftp: 250, onboardingDone: true, name: 'Test' })
  })
  it('kar je po izvozu izbrisano na tej napravi (grob), ostane izbrisano', async () => {
    await store.addMeal(meal('m1', 500)); await store.addMeal(meal('m2', 200))
    const text = JSON.stringify(await repo.exportAll())
    await store.removeMeal('m2')
    const r = await store.restoreFromBackup(parseBackup(text))
    expect(store.getState().mealsToday.map(m => m.id)).toEqual(['m1'])
    expect(r.deleted).toBe(1)
  })
  it('brez »profil iz kopije« velja novejša vrednost polja; nastavitev naprave ostane', async () => {
    await store.updateProfile({ ftp: 230, onboardingDone: true, name: 'Star' })
    await store.addMeal(meal('m1', 500))
    const text = JSON.stringify(await repo.exportAll())
    await new Promise(r => setTimeout(r, 5))
    await store.updateProfile({ ftp: 260 })
    await store.updateSettings({ wellnessOn: true })
    await store.restoreFromBackup(parseBackup(text))
    expect(store.getState().profile.ftp).toBe(260)
    expect(store.getState().settings.wellnessOn).toBe(true)
  })
  it('ponovni uvoz iste kopije ne podvoji ničesar', async () => {
    await store.addActivities([ride('a1')]); await store.addMeal(meal('m1', 500))
    const p = parseBackup(JSON.stringify(await repo.exportAll()))
    const r = await store.restoreFromBackup(p)
    expect(r).toMatchObject({ activities: 0, meals: 0, plan: 0, checkins: 0 })
    expect(store.getState().activities.length).toBe(1)
  })
  it('izvoz v datoteko nima ključa intervals.icu; uvoz take kopije povezave na napravi ne odklopi (tudi s profilom iz kopije)', async () => {
    await store.updateSettings({ intervals: { athleteId: 'i123', apiKey: 'SKRIVNOST-123', name: 'Blaž' } })
    await store.addMeal(meal('m1', 500))
    const d = await exportForFile()
    const text = JSON.stringify(d)
    expect(text).not.toContain('SKRIVNOST-123')
    expect(text).not.toContain('apiKey')
    expect((d.settings as { intervals?: unknown }).intervals).toBeUndefined()
    await store.restoreFromBackup(parseBackup(text), { fromBackup: true })
    expect(store.getState().settings.intervals?.apiKey).toBe('SKRIVNOST-123')
  })
})
