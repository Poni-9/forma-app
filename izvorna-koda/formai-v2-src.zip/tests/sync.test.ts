import { describe, it, expect } from 'vitest'
import { keepLocalTracks } from '../src/data/sync'
import { cloudSafe } from '../src/data/cloudSafe'
import { deriveFlags, aiAllowed, geoAllowed } from '../src/domain/import/provenance'
import type { Activity } from '../src/domain/types'

const now = new Date().toISOString()
const act = (o: Partial<Activity>): Activity => ({ id: 'x', source: 'file', sport: 'kolo', date: '2026-08-20', name: 'x', aiEligible: true, geoRetain: true, createdAt: now, updatedAt: now, ...o })

describe('sinhronizacija — sledi ostanejo lokalne', () => {
  it('prevzem iz oblaka obdrzi lokalne sledi po id-ju', () => {
    const local = [act({ id: 'a', polyline: 'SLED-A' }), act({ id: 'b', polyline: null })]
    const remote = [act({ id: 'a', polyline: null, name: 'iz oblaka' }), act({ id: 'c', polyline: null })]
    const out = keepLocalTracks(remote, local)
    expect(out.find(a => a.id === 'a')?.polyline).toBe('SLED-A')
    expect(out.find(a => a.id === 'a')?.name).toBe('iz oblaka')
    expect(out.find(a => a.id === 'c')?.polyline).toBeNull()
  })
})

describe('demo podatki', () => {
  it('demo: karta da, AI ne', () => {
    const f = deriveFlags('demo')
    expect(aiAllowed({ aiEligible: f.aiEligible, expiresAt: f.expiresAt })).toBe(false)
    expect(geoAllowed({ geoRetain: f.geoRetain, polyline: 'x' })).toBe(true)
  })
})

describe('oblak: zapis brez undefined', () => {
  it('izpusti undefined, v seznamih null, NaN → null, Date → ISO', () => {
    const x = { a: undefined, b: [1, undefined, 3], c: { d: undefined, e: NaN, f: 'x' }, g: new Date(0), h: null, '': 5 }
    expect(cloudSafe(x)).toEqual({ b: [1, null, 3], c: { e: null, f: 'x' }, g: '1970-01-01T00:00:00.000Z', h: null })
  })
  it('vožnja iz intervals.icu z notes/exercises/ext undefined gre čez', () => {
    const a = { id: 'x', source: 'intervals', notes: undefined, exercises: undefined, ext: { intervalsId: 'i1', stravaId: undefined }, polyline: null }
    const out = cloudSafe({ activities: [a] })
    const walk = (v: unknown): boolean => v === undefined ? true : Array.isArray(v) ? v.some(walk) : v && typeof v === 'object' ? Object.values(v).some(walk) : false
    expect(walk(out)).toBe(false)
    expect(out.activities[0]).toEqual({ id: 'x', source: 'intervals', ext: { intervalsId: 'i1' }, polyline: null })
  })
})
