import { describe, it, expect } from 'vitest'
import { keepLocalTracks } from '../src/data/sync'
import { deriveFlags, aiAllowed, geoAllowed } from '../src/domain/import/provenance'
import type { Activity } from '../src/domain/types'

const now = new Date().toISOString()
const act = (o: Partial<Activity>): Activity => ({ id: 'x', source: 'file', sport: 'kolo', date: '2026-08-20', name: 'x', aiEligible: true, geoRetain: true, createdAt: now, updatedAt: now, ...o })

describe('sinhronizacija — sledi ostanejo lokalne', () => {
  it('prevzem iz oblaka obdrzi lokalne sledi po id-ju', () => {
    const local = [act({ id: 'a', polyline: 'SLED-A' }), act({ id: 'b', polyline: null })]
    const remote = [act({ id: 'a', polyline: null, name: 'iz oblaka' }), act({ id: 'c', polyline: null })]
    const out = keepLocalTracks(remote, local)
    expect(out.find(a => a.id === 'a')?.polyline).toBe('SLED-A')
    expect(out.find(a => a.id === 'a')?.name).toBe('iz oblaka')
    expect(out.find(a => a.id === 'c')?.polyline).toBeNull()
  })
})

describe('demo podatki', () => {
  it('demo: karta da, AI ne', () => {
    const f = deriveFlags('demo')
    expect(aiAllowed({ aiEligible: f.aiEligible, expiresAt: f.expiresAt })).toBe(false)
    expect(geoAllowed({ geoRetain: f.geoRetain, polyline: 'x' })).toBe(true)
  })
})
