// v3.49 DANES (shramba): prvi dogovor ob 21:30 ne pusti današnjega treninga — načrt začne jutri (C18).
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { ruleProposal } from '../src/domain/focus/rules'

/** tekač začetnik »zjutraj«, 4 dni (vsi dnevi odprti) — da ima načrt trening tudi ob koncu tedna */
const runner = () => ruleProposal('Rad bi pretekel 5 km brez ustavljanja. Nimam ure, samo telefon.', [{ id: 'dni', q: 'Koliko dni na teden?', a: '4' }, { id: 'cas', q: 'Koliko časa imaš za eno vadbo?', a: '30 min' }], 38).focus
async function agreeAt(h: number, m: number) {
  vi.useFakeTimers({ toFake: ['Date'] })
  vi.setSystemTime(new Date(2026, 9, 17, h, m))   // sobota, po lokalnem času
  await repo.wipeAll(); localStorage.clear(); await store.reloadAll()
  const today = store.getState().today
  await store.applyAgreement(runner(), { sex: 'm', age: 38, heightCm: 180, weightKg: 92, trainTime: 'zjutraj' })
  return { today, plan: store.getState().plan }
}

describe('C18: prvi dogovor pozno zvečer', () => {
  beforeEach(() => { vi.useRealTimers() })
  afterEach(() => { vi.useRealTimers() })
  // (v3.50 H38) jutri (nedelja) je počitek, prvi trening je v ponedeljek — prej »začneva jutri«
  it('ob 21:30 (navada »zjutraj«): danes počitek »Danes je že pozno — začneva v ponedeljek.«, treningi od jutri', async () => {
    const { today, plan } = await agreeAt(21, 30)
    expect(today).toBe('2026-10-17')
    expect(plan.filter(d => d.date === today).map(d => [d.kind, d.desc])).toEqual([['pocitek', 'Danes je že pozno — začneva v ponedeljek.']])
    expect(plan.some(d => d.date > today && d.kind !== 'pocitek')).toBe(true)
  })
  it('ob 9:00: načrt se začne danes (današnji dan po načrtu, ne »pozno«)', async () => {
    const { today, plan } = await agreeAt(9, 0)
    const t = plan.filter(d => d.date === today)
    expect(t.length).toBeGreaterThan(0)
    expect(t.some(d => /pozno/.test(d.desc))).toBe(false)
  })
})
