import { describe, it, expect } from 'vitest'
import { dailyTarget, activityKcal, plausibleKcal, estimatePlanKcal, targetParts, bmr, tdee, noDeficitDay, raceCarbs, MAX_DEFICIT, MIN_ABS_M, MIN_ABS_Z } from '../src/domain/nutrition/energy'
import { matchesPlanned, bestPlanMatch, activityMinutes } from '../src/domain/training/plandays'
import type { Activity, PlanDay, Profile } from '../src/domain/types'

const now = new Date().toISOString()
const P = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 35, heightCm: 180, weightKg: 75, ftp: 250, deficit: 500, neat: 1.4,
  gear: { bikeOutdoor: true, trainer: false, noBike: false }, strength: { on: false, equipment: 'none' },
  onboardingDone: true, createdAt: now, updatedAt: now, ...o,
} as Profile)
const act = (o: Partial<Activity>): Activity => ({ id: Math.random().toString(36).slice(2), source: 'manual', sport: 'kolo', date: '2026-09-26', name: 'x', aiEligible: true, geoRetain: true, createdAt: now, updatedAt: now, ...o } as Activity)
const day = (o: Partial<PlanDay> = {}): PlanDay => ({ id: 'd1', date: '2026-09-26', kind: 'kolo', title: 'Dolga Z2', desc: '', durationMin: 240, zone: 'Z2', role: 'dolga', source: 'rules', createdAt: now, updatedAt: now, done: null, ...o } as PlanDay)
const DATE = '2026-09-26'
/** zjutraj tistega dne: načrtovana seja še šteje */
const AT = { today: DATE, hour: 9 }

describe('poraba aktivnosti: negativne in neznane vrednosti', () => {
  it('negativne kcal ali trajanje ne znižajo porabe in ne prebijejo meje 750', () => {
    const p = P({ age: 25, heightCm: 190, weightKg: 100, deficit: 750, neat: 1.6 })
    expect(activityKcal(act({ kcal: -1500, durationMin: 60 }), p)).toBeGreaterThanOrEqual(0)
    expect(activityKcal(act({ durationMin: -120, kcal: null }), p)).toBe(0)
    expect(plausibleKcal(-500, 60)).toBe(0)
    expect(estimatePlanKcal(day({ durationMin: -90 }), p)).toBe(0)
    for (const a of [act({ kcal: -1500, durationMin: 60 }), act({ durationMin: -120, kcal: null }), act({ kcal: Number.NaN, durationMin: 60 })]) {
      const t = dailyTarget(p, [a], [day({ durationMin: -60, kcalBurn: -900 })], DATE)!
      const training = t.burn + t.plannedBurn + (t.estimatedBurn || 0)
      expect(training).toBeGreaterThanOrEqual(0)
      expect(t.maintenance + training - t.kcal).toBeLessThanOrEqual(MAX_DEFICIT)
    }
  })
  it('brez trajanja: kcal iz naprave se ne režejo, kot da je vožnja trajala 1 h; trajanje iz časa s postanki ali razdalje', () => {
    const p = P()
    expect(plausibleKcal(2600, null)).toBe(2600)
    expect(activityKcal(act({ kcal: 2600, durationMin: null, distKm: 140 }), p)).toBe(2600)
    expect(activityKcal(act({ kcal: 5000, durationMin: 60 }), p)).toBe(1200)                     // napaka naprave: 1100/h + 100
    expect(activityMinutes({ sport: 'kolo', durationMin: null, elapsedMin: 300 })).toBe(300)
    expect(activityMinutes({ sport: 'kolo', durationMin: null, distKm: 100 })).toBe(240)            // 25 km/h
    expect(activityKcal(act({ kcal: null, durationMin: null, elapsedMin: 300, distKm: 140 }), p)).toBeGreaterThan(1500)
    // 5-urna vožnja brez trajanja: cilj = osnova − deficit + vsa poraba (deficit ostane 500, ne 1900)
    const t = dailyTarget(p, [act({ kcal: 2600, durationMin: null, distKm: 140 })], [], DATE)!
    expect(t.maintenance + 2600 - t.kcal).toBe(500)
  })
  it('povezana vožnja brez porabe in trajanja: šteje vsaj načrt, ne 0', () => {
    const p = P()
    const plan = day({ done: { at: now, activityId: 'L' } })
    const est = estimatePlanKcal(plan, p)
    const t = dailyTarget(p, [act({ id: 'L', kcal: null, durationMin: null })], [plan], DATE)!
    expect(t.burn).toBe(0)
    expect(t.estimatedBurn).toBe(est)
    expect(t.kcal).toBe(tdee(p)! - t.deficit + est)
    expect(targetParts(t, p)).toMatch(/vožnja nima podatka o porabi/)
  })
})

describe('kratka vožnja ni načrtovana seja (≥ 50 % trajanja, najbližja)', () => {
  const p = P()
  const plan = day()
  it('20-min vožnja v službo pred 4-urno vožnjo: cilj ne pade, nič dvakrat', () => {
    const before = dailyTarget(p, [], [plan], DATE, AT)!
    const commute = act({ id: 'c', source: 'intervals', durationMin: 20, kcal: 150 })
    const after = dailyTarget(p, [commute], [plan], DATE, AT)!
    expect(after.kcal).toBe(before.kcal)                          // prej: −2190 kcal
    expect(after.burn).toBe(150); expect(after.plannedBurn).toBe(before.plannedBurn - 150)
    // ko pride dolga vožnja, ta zamenja načrt, vožnja v službo je dodatek
    const ride = act({ id: 'r', source: 'intervals', durationMin: 235, kcal: 2400 })
    const done = dailyTarget(p, [commute, ride], [plan], DATE, AT)!
    expect(done.plannedBurn).toBe(0); expect(done.plannedWas).toBe(before.plannedBurn)
    expect(done.kcal).toBe(tdee(p)! - 250 + 150 + 2400)           // dolga vožnja: pol deficita
  })
  it('matchesPlanned / bestPlanMatch za store (linkToPlan)', () => {
    expect(matchesPlanned({ sport: 'kolo', durationMin: 20 }, plan)).toBe(false)
    expect(matchesPlanned({ sport: 'kolo', durationMin: 120 }, plan)).toBe(true)
    expect(matchesPlanned({ sport: 'kolo', durationMin: null }, plan)).toBe(true)                // brez trajanja: ne vemo, velja
    expect(matchesPlanned({ sport: 'tek', durationMin: 240 }, plan)).toBe(false)
    expect(matchesPlanned({ sport: 'kolo', durationMin: 60 }, day({ kind: 'test', durationMin: 60 }))).toBe(true)
    const short = day({ id: 's', durationMin: 60, role: 'lahka' }), long = day({ id: 'l', durationMin: 240 })
    expect(bestPlanMatch({ sport: 'kolo', durationMin: 70, date: DATE }, [long, short])?.id).toBe('s')
    expect(bestPlanMatch({ sport: 'kolo', durationMin: 200, date: DATE }, [short, long])?.id).toBe('l')
    expect(bestPlanMatch({ sport: 'kolo', durationMin: 15, date: DATE }, [short, long])).toBeNull()
    expect(bestPlanMatch({ sport: 'kolo', durationMin: 200, date: '2026-09-27' }, [long])).toBeNull()
  })
})

describe('varovalke: BMR, 1500/1200, mladoletni, strop 750, trening se ne krči', () => {
  it('za vse kombinacije profila, ročnega cilja in aktivnosti', () => {
    for (const sex of ['m', 'z'] as const) for (const age of [16, 17, 18, 40, 70]) for (const [h, w] of [[150, 42], [170, 60], [190, 110]]) for (const deficit of [0, 750, 2000]) for (const ov of [null, 800, 1600]) for (const acts of [[], [act({ kcal: 900, durationMin: 120 })], [act({ kcal: -300, durationMin: 30 })]]) {
      const p = P({ sex, age, heightCm: h, weightKg: w, deficit, kcalOverride: ov, goal: 'shujsati', neat: 1.6 })
      const t = dailyTarget(p, acts, [day({ durationMin: 90, role: 'lahka' })], DATE)!
      const training = t.burn + t.plannedBurn + (t.estimatedBurn || 0)
      expect(t.kcal).toBeGreaterThanOrEqual(bmr(p)!)
      expect(t.kcal).toBeGreaterThanOrEqual(sex === 'z' ? MIN_ABS_Z : MIN_ABS_M)
      expect(t.maintenance + training - t.kcal).toBeLessThanOrEqual(MAX_DEFICIT)
      if (age < 18) expect(t.kcal).toBeGreaterThanOrEqual(t.maintenance + training)
    }
  })
  it('poraba treninga se vedno prišteje v celoti (deficit samo pri obrokih)', () => {
    const p = P({ deficit: 500 })
    const rest = dailyTarget(p, [], [], DATE)!
    expect(rest.clampedToFloor).toBe(false)
    const ride = dailyTarget(p, [act({ kcal: 2800, durationMin: 300 })], [], DATE)!
    expect(ride.kcal - rest.kcal).toBe(2800)
  })
})

describe('tekme: ročni cilj in polnjenje z OH', () => {
  const franja = { name: 'Maraton Franja', date: '2027-06-13', distanceKm: 156 }
  const p = P({ weightKg: 78, kcalOverride: 1900, deficit: 500, event: franja, cycleStart: '2026-09-21', hoursPerWeek: 9 })
  it('ročni cilj na dan brez deficita ne velja (max(ročni, osnova) + trening)', () => {
    const race = day({ date: '2027-06-13', role: 'dirka', zone: 'dirka', durationMin: 300, title: 'Franja' })
    const t = dailyTarget(p, [], [race], '2027-06-13')!
    expect(t.overrideOff).toBe(true)
    expect(t.kcal).toBe(t.maintenance + t.plannedBurn)
    expect(targetParts(t, p)).toMatch(/tvoj cilj 1 900 danes ne velja/)
    expect(noDeficitDay(p, '2027-06-11')).toBeTruthy()
    // navaden dan: ročni cilj velja
    const normal = dailyTarget(p, [], [], '2026-10-14')!
    expect(normal.overrideOff).toBe(false); expect(normal.kcal).toBe(1900)
  })
  it('2 dni pred tekmo ≥ 150 min: OH 8 g na kg in kalorije gor (nič dol)', () => {
    const q = { ...p, kcalOverride: null }
    for (const d of ['2027-06-11', '2027-06-12']) {
      const t = dailyTarget(q, [], [], d)!
      expect(t.carbsG).toBe(Math.round(8 * 78))
      expect(t.kcal).toBeGreaterThanOrEqual(t.proteinG * 4 + t.fatG * 9 + t.carbsG * 4 - 5)
      expect(t.kcal).toBeGreaterThanOrEqual(t.maintenance)
      expect(t.carbLoad).toBeGreaterThan(0)
    }
    expect(dailyTarget(q, [], [], '2027-06-10')!.carbsG).toBeLessThan(8 * 78)
    // kratka tekma (kronometer 30 min): brez polnjenja
    const tt = { ...q, event: { name: 'Kronometer', date: '2027-06-13', distanceKm: 20, type: 'kronometer' as const } }
    expect(raceCarbs(tt, '2027-06-12')).toBeNull()
    // druga tekma brez dolžine (načrt jo ima za 2 h): dan prej 5 g na kg, ne polnjenje
    const c = { ...q, event: null, races: [{ id: 'c', name: 'Nedeljska', date: '2026-10-18', prio: 'C' as const }] }
    expect(raceCarbs(c, '2026-10-16')).toBeNull()
    expect(raceCarbs(c, '2026-10-17')).toMatchObject({ gkg: 5, load: false })
  })
})
