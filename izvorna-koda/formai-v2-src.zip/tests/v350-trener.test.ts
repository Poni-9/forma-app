// v3.50 TRENER: odgovor trenerja (seznam, »zagotovo«, mladoletni), kaj dobi model (persona, naloge, dan v tednu, decimalke,
// ženske oblike, pretekli dnevi tedna, vir FTP, prvi mejnik teže, metoda brez uteži, tempo hujšanja), »Prilagodi teden«
// (samo od danes, naslednji teden, moč po dogovoru), odtis nasveta, trener brez AI (minute, tekma, današnja seja),
// lestvica maščobe za pas, hitra vprašanja.
import { describe, it, expect, vi, beforeEach } from 'vitest'

const h = vi.hoisted(() => ({ kv: new Map<string, unknown>(), json: vi.fn(async (_p: unknown) => ({} as unknown)) }))
vi.mock('@/data/db', () => ({ getKV: async (k: string) => h.kv.get(k), setKV: async (k: string, v: unknown) => { h.kv.set(k, v) } }))
vi.mock('../src/domain/ai/client', async (orig) => { const m = await orig<typeof import('../src/domain/ai/client')>(); return { ...m, askJson: (p: unknown) => h.json(p), askText: async () => 'ok' } })

import { honest, HONEST_NOTE, HONEST_NOTE_MINOR } from '../src/domain/ai/sanitize'
import { plainAi, mdBlocks } from '../src/domain/ai/md'
import { aiContext, coachDailyPrompt, weeklyReviewPrompt, LOOKS_RULE, LOOKS_RULE_MINOR } from '../src/domain/ai/prompts'
import { personalContext } from '../src/domain/ai/personal'
import { adaptWeek, adviceSig } from '../src/domain/ai/actions'
import { adaptTarget } from '../src/domain/ai/coachchat'
import { focusContext, needToKnow, strategyPrompt } from '../src/domain/ai/focusAi'
import { ruleStrategy } from '../src/domain/focus/rules'
import { normalizeFocus } from '../src/domain/focus/model'
import { buildWeek, FRANJA_2027 } from '../src/domain/training/planner'
import { localReview, lastWeekSummary, type LocalCoachCtx } from '../src/domain/coach/local'
import { keyCompliance } from '../src/domain/training/review'
import { bodyFatView, waistIntent } from '../src/domain/coach/bodyfat'
import { quick, quickCustom } from '../src/screens/Trener'
import type { AgreedSession, Focus, PlanDay, Profile } from '../src/domain/types'

const NOW = '2026-10-18T10:00:00.000Z'
const SUN = '2026-10-18'                     // nedelja; teden od 12. 10.
const WED = '2026-10-14'
const txt = (parts: readonly unknown[]) => parts.map(p => (p as { text?: string }).text || '').join('\n')
const bike = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, ftpDate: '2026-09-14', maxHr: 195, restHr: 50, lthr: 184,
  gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, strength: { on: true, equipment: 'home' },
  hoursPerWeek: 11, goal: 'dirka', deficit: 400, onboardingDone: true, event: { ...FRANJA_2027 }, cycleStart: '2026-09-21',
  goalStart: { date: '2026-09-22', ftp: 240, weightKg: 79 }, aiConsentAt: NOW, aiConsentV: 2, createdAt: NOW, updatedAt: NOW, ...o,
} as Profile)
const focus = (sessions: AgreedSession[], o: Partial<Focus> = {}): Focus => normalizeFocus({ wish: 'po meri', sports: [...new Set(sessions.map(s => s.type))], aims: ['moc'], level: 2, equipment: ['fitnes'], sessions, ...o }, { now: NOW, by: 'pravila' })!
const custom = (f: Focus, o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 30, heightCm: 178, weightKg: 85, goal: 'forma', deficit: 0, level: 2, hoursPerWeek: 3,
  gear: { bikeOutdoor: false, trainer: false, noBike: true, powerMeter: null }, strength: { on: true, equipment: 'gym' },
  onboardingDone: true, createdAt: NOW, updatedAt: NOW, aiConsentAt: NOW, aiConsentV: 2, focus: f, ...o,
} as unknown as Profile)
const day = (o: Partial<PlanDay>): PlanDay => ({ id: 'd' + (o.date || SUN) + (o.kind || ''), date: SUN, kind: 'kolo', title: 'Z2', desc: 'Enakomerno.', durationMin: 60, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o } as PlanDay)
const gymF = () => focus([{ type: 'fitnes', part: 'zgornji', min: 60 }, { type: 'fitnes', part: 'spodnji', min: 60 }])
const runF = () => focus([{ type: 'tek', cardio: 'lahko', min: 30 }, { type: 'tek', cardio: 'lahko', min: 30 }, { type: 'tek', cardio: 'lahko', min: 30 }], { aims: ['kondicija'], equipment: [], level: 1 })
const homeF = () => focus([{ type: 'doma', part: 'celo', min: 30 }, { type: 'tek', cardio: 'lahko', min: 30 }], { aims: ['kondicija'], equipment: ['nic'], level: 1 })
const lctx = (p: Profile, plan: PlanDay[], today: string, o: Partial<LocalCoachCtx> = {}): LocalCoachCtx => ({ profile: p, plan, activities: [], checkins: [], checkinToday: null, wellness: null, wellnessOn: false, mealsToday: [], recentMeals: [], weather: null, today, ...o })

beforeEach(() => { h.kv.clear(); h.json.mockReset() })

describe('C06 vrstni števnik ni seznam', () => {
  it('»4. teden …« in »13. 6. 2027 …« ostaneta besedilo; pravi seznam od 1 ostane seznam', () => {
    expect(plainAi('4. teden bloka je lažji — serija manj.')).toBe('4. teden bloka je lažji — serija manj.')
    expect(plainAi('13. 6. 2027 je Franja.')).toBe('13. 6. 2027 je Franja.')
    expect(plainAi('1. 6. 2027 je rok.')).toBe('1. 6. 2027 je rok.')
    expect(mdBlocks('Načrt:\n3. teden je najtežji.\n4. teden je lažji.').some(b => b.k === 'ol')).toBe(false)
    const ol = mdBlocks('Koraki:\n1. ogrevanje\n2. glavni del\n\n3. ohlajanje')
    expect(ol[1]).toMatchObject({ k: 'ol' })
    expect((ol[1] as { items: unknown[] }).items).toHaveLength(3)
    expect(plainAi('1. a\n2. b')).toBe('1. a\n2. b')
  })
})

describe('C24 + C28 honest', () => {
  it('»zagotovo« v navodilu ostane; v obljubi izida → »verjetno«; videz izpade', () => {
    expect(honest('Zagotovo vzemi gel s sabo.')).toBe('Zagotovo vzemi gel s sabo.')
    expect(honest('Danes zagotovo ne treniraj — mišice 5/5.')).toBe('Danes zagotovo ne treniraj — mišice 5/5.')
    expect(honest('Zagotovo boš do junija hitrejši.')).toBe('Verjetno boš do junija hitrejši.')
    expect(honest('Zagotovo izgubiš 3 kg v 6 tednih.')).toBe('Verjetno izgubiš 3 kg v 6 tednih.')
    const look = honest('Zagotovo boš do marca izklesan. Spi 8 h.')
    expect(look).not.toMatch(/zagotov|verjetno/i)
    expect(look).toBe(`Spi 8 h.\n\n${HONEST_NOTE}`)
  })
  it('mladoletni: pripis brez tempa teže', () => {
    const t = honest('Zagotovim ti six-pack do poletja. Jej dovolj.', { minor: true })
    expect(t).toBe(`Jej dovolj.\n\n${HONEST_NOTE_MINOR}`)
    expect(t).not.toMatch(/kg na teden/)
  })
  it('mladoletni: persona brez tempa teže in lestvice maščobe', () => {
    const t = txt(coachDailyPrompt(aiContext([], bike({ age: 16, deficit: 0 }), [], false, SUN), [], 'Kdaj bom imel six pack?'))
    expect(t).toContain(LOOKS_RULE_MINOR)
    expect(t).not.toContain(LOOKS_RULE)
    expect(t).not.toMatch(/tempo teže 0,3–0,5/)
    const adult = txt(coachDailyPrompt(aiContext([], bike(), [], false, SUN), [], 'Kdaj bom imel six pack?'))
    expect(adult).toContain(LOOKS_RULE)
  })
})

describe('kaj dobi model', () => {
  it('C26: klepet brez »najprej poglej trening v resnici«; nasvet za danes in pregled tedna kolesarja z njim', () => {
    const ctx = aiContext([], bike(), [], false, SUN)
    const ride = [day({ date: SUN })]
    expect(txt(coachDailyPrompt(ctx, ride, 'Kaj naj jem pred spanjem?'))).not.toContain('Najprej poglej »trening v resnici«')
    expect(txt(coachDailyPrompt(ctx, ride))).toContain('Najprej poglej »trening v resnici«')
    expect(txt(weeklyReviewPrompt(ctx))).toContain('Najprej poglej »trening v resnici«')
  })
  it('C34: klepet pri načrtu po meri brez »kolesarjenjem«', () => {
    const c = aiContext([], custom(gymF()), [], false, SUN)
    expect(txt(coachDailyPrompt(c, [], 'Kaj naj jem?'))).not.toContain('kolesarjenjem')
    expect(txt(coachDailyPrompt(c, [], 'Kaj naj jem?'))).toContain('ni povezano s treningom, zdravjem ali prehrano')
    expect(txt(coachDailyPrompt(aiContext([], bike(), [], false, SUN), [], 'Kaj naj jem?'))).toContain('s kolesarjenjem, treningom')
  })
  it('C35: raven iz W/kg, oprema po slovensko, decimalna vejica', () => {
    const c = aiContext([], bike({ level: null, hoursPerWeek: 7.5, weightKg: 79.4 }), [], false, SUN)
    expect(c).not.toContain('raven ni podana')
    expect(c).toContain('Raven: povprečen amater (3,02 W/kg), na voljo 7,5 h/teden')
    expect(c).toContain('moč: da (doma)')
    expect(c).toContain('79,4 kg')
    expect(c).not.toMatch(/\d\.\d (h|kg)|\(home\)/)
    const pc = personalContext({ profile: bike(), activities: [], plan: [], checkins: [{ date: SUN, sleepH: 7.1, soreness: 2, mood: 4 }], recentMeals: [], today: SUN })
    expect(pc).toContain('spanec 7,1 h')
  })
  it('C36: uporabnica — »Športnica«, »Njene besede« in navodilo za ženske oblike', () => {
    const p = custom(gymF(), { sex: 'z' })
    const c = aiContext([], p, [], false, SUN)
    expect(c).toContain('Športnica: ženska')
    expect(c).toContain('Njene besede')
    expect(focusContext(p)).toContain('Njene besede')
    expect(txt(coachDailyPrompt(c, [], 'Kaj danes?'))).toContain('piši v ženski obliki')
    const m = txt(coachDailyPrompt(aiContext([], custom(gymF()), [], false, SUN), [], 'Kaj danes?'))
    expect(m).not.toContain('ženski obliki')
    expect(m).toContain('Njegove besede')
  })
  it('C42: dan v tednu v kontekstu in v načrtu', () => {
    const c = aiContext([], bike(), [day({ date: SUN }), day({ date: '2026-10-19', title: 'VO2max' })], false, SUN)
    expect(c).toContain('Danes: nedelja, 18. 10. 2026 (2026-10-18)')
    expect(c).toContain('- 2026-10-19 pon · kolo · VO2max')
  })
  it('C43: dan počitka — naloga brez serij in goriva', () => {
    const ctx = aiContext([], bike(), [], false, SUN)
    const t = txt(coachDailyPrompt(ctx, [day({ kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, role: null })]))
    expect(t).toContain('danes je dan počitka')
    expect(t).not.toContain('gorivom (g OH na uro)')
    expect(txt(coachDailyPrompt(ctx, []))).not.toContain('dan počitka')        // brez načrta ni »dan počitka«
    expect(txt(coachDailyPrompt(ctx, [day({})]))).toContain('gorivom (g OH na uro)')
  })
  it('C10: pregled tedna (načrt po meri) vidi opravljene dneve tega tedna', () => {
    const p = custom(gymF())
    const plan = [
      day({ date: '2026-10-12', kind: 'moc', title: 'Fitnes — zgornji del', zone: null, role: 'moc', done: { at: NOW, activityId: null } }),
      day({ date: '2026-10-13', kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, role: null }),
      day({ date: '2026-10-15', kind: 'moc', title: 'Fitnes — spodnji del', zone: null, role: 'moc' }),
    ]
    const r = txt(weeklyReviewPrompt(aiContext([], p, plan, false, '2026-10-16')))
    expect(r).toContain('Ta teden do danes')
    expect(r).toContain('- 2026-10-12 pon · moc · Fitnes — zgornji del · 60 min · opravljeno')
    expect(r).toContain('moč 1 od 2')
    expect(r).not.toContain('2026-10-13 tor')               // počitek ne
  })
  it('C25: brez merilnika — vir FTP, »orientacija« pri ciljih in mejnikih; persona brez »izhajaj iz W/kg«', () => {
    const p = bike()
    const pc = personalContext({ profile: p, activities: [], plan: [], checkins: [], recentMeals: [], tests: [{ id: 't', kind: 'ftp', date: '2026-09-14', value: 253, unit: 'W' }], today: SUN })
    expect(pc).toContain('FTP 240 W (iz 20-min testa 14. 9. 2026, brez merilnika moči)')
    expect(pc).toMatch(/Cilj na dan dirke: .* — brez merilnika moči je to orientacija/)
    expect(pc).toMatch(/Mejniki: .*\(orientacija — brez merilnika moči vodi po utripu in testih\)\./)
    const t = txt(coachDailyPrompt(aiContext([], p, [], false, SUN), [], 'Kako dober sem?'))
    expect(t).not.toContain('izhajaj iz W/kg zdaj')
    expect(t).toContain('W/kg in vati so brez merilnika moči samo orientacija')
    const pm = bike({ gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: true } })
    expect(txt(coachDailyPrompt(aiContext([], pm, [], false, SUN), [], 'Kako dober sem?'))).toContain('izhajaj iz W/kg zdaj')
    const manual = personalContext({ profile: pm, activities: [], plan: [], checkins: [], recentMeals: [], today: SUN })
    expect(manual).toContain('FTP 240 W (vpisan 14. 9. 2026)')
    expect(manual).not.toContain('orientacija')
  })
  it('C12: fitnes uporabnica brez ročne ciljne teže — prvi mejnik, ne kolesarska teža', () => {
    const f = focus([{ type: 'fitnes', part: 'celo', min: 45 }, { type: 'fitnes', part: 'celo', min: 45 }, { type: 'tek', cardio: 'lahko', min: 45 }], { aims: ['hujsanje', 'moc'] })
    const p = custom(f, { sex: 'z', age: 34, heightCm: 165, weightKg: 72, goal: 'shujsati', deficit: 400, goalStart: { date: '2026-10-12', ftp: null, weightKg: 72 } })
    const pc = personalContext({ profile: p, activities: [], plan: [], checkins: [], recentMeals: [], today: SUN })
    expect(pc).not.toMatch(/58(,5)? kg/)
    expect(pc).toContain('prvi mejnik teže ~65 kg')
    expect(pc).toContain('do prvega mejnika ~65 kg')
    expect(pc).toContain('nad 0,5 kg je prehitro')
    const own = personalContext({ profile: { ...p, targetWeightKg: 66 }, activities: [], plan: [], checkins: [], recentMeals: [], today: SUN })
    expect(own).toContain('ciljna teža ~66 kg (vpisana)')
  })
  it('C23: metoda brez uteži s ponovitvami; s fitnesom s kilogrami', () => {
    const home = personalContext({ profile: custom(homeF(), { strength: { on: true, equipment: 'none' } }), activities: [], plan: [], checkins: [], recentMeals: [], today: SUN })
    expect(home).toMatch(/METODA: .*s ponovitvami in nato s težjo različico/)
    expect(home).not.toContain('moč napreduje s kilogrami')
    const gym = personalContext({ profile: custom(gymF()), activities: [], plan: [], checkins: [], recentMeals: [], today: SUN })
    expect(gym).toContain('moč napreduje s kilogrami')
    const run = personalContext({ profile: custom(runF()), activities: [], plan: [], checkins: [], recentMeals: [], today: SUN })
    expect(run).not.toMatch(/moč napreduje/)
  })
  it('C41: en tempo hujšanja 0,3–0,5 kg na teden (strategija AI in po pravilih)', () => {
    const f = focus([{ type: 'fitnes', part: 'celo', min: 45 }, { type: 'fitnes', part: 'celo', min: 45 }], { aims: ['hujsanje'] })
    const s = txt(strategyPrompt(f, { sex: 'z', age: 34 }, { kcal: 1700, proteinG: 120, deficit: 400 }))
    expect(s).toContain('hujšanje 0,3–0,5 kg na teden')
    expect(s).not.toContain('0,25–0,75')
    expect(ruleStrategy(f, { kcal: 1700, proteinG: 120, deficit: 400 })).toContain('Pričakuj 0,3–0,5 kg na teden')
  })
  it('C22 (AI): »Postava: vitka in močna« vpraša za poudarek, »six pack« ne', () => {
    expect(needToKnow('Postava: vitka in močna. Rad delam: fitnes.', {})).toContain('poudarek pri moči')
    expect(needToKnow('Postava: six pack. Rad delam: fitnes.', {})).not.toContain('poudarek pri moči')
  })
})

describe('C09 + C11 + C30 Prilagodi teden', () => {
  const p = bike()
  const plan = [...buildWeek({ profile: p, activities: [], weekStart: '2026-10-12', notBefore: '2026-10-12', today: '2026-10-12' })]
  it('C09: pretekli neopravljeni dnevi ne gredo v poziv in se ne spremenijo', async () => {
    const vo2 = plan.find(d => /VO2max/.test(d.title))!
    expect(vo2.date < WED).toBe(true)
    const before = keyCompliance(plan, [], '2026-10-12', '2026-10-13').total
    expect(before).toBeGreaterThan(0)
    h.json.mockImplementation(async () => ({ dnevi: plan.filter(d => d.kind !== 'moc').map(d => ({ date: d.date, kind: 'pocitek', title: 'Počitek', desc: 'Prosto.', durationMin: 0, zone: null, tssTarget: 0 })), povzetek: 'Vse v počitek.' }))
    const r = await adaptWeek({ profile: p, activities: [], plan, today: WED }, plan)
    const sent = txt(h.json.mock.calls[0]![0] as unknown[])
    const week = sent.slice(sent.indexOf('OBSTOJEČI TEDEN'))
    expect(week).not.toContain(vo2.date)                         // samo od danes naprej
    expect(sent).toContain('kar je bilo pred danes, je zgodovina')
    expect(r.days.every(d => d.date >= WED)).toBe(true)
    const merged = plan.map(d => r.days.find(x => x.id === d.id) ?? d)
    expect(merged.find(d => d.id === vo2.id)!.title).toBe(vo2.title)
    expect(keyCompliance(merged, [], '2026-10-12', '2026-10-13').total).toBe(before)   // zgodovina ostane (prej »0 od 3« → »0 od 2«)
  })
  it('C11: načrt po meri — vadbe moči gredo v poziv kot fiksne', async () => {
    const g = custom(focus([{ type: 'fitnes', part: 'zgornji', min: 60 }, { type: 'tek', cardio: 'lahko', min: 30 }, { type: 'fitnes', part: 'spodnji', min: 60 }]))
    const wk = [day({ date: WED, kind: 'moc', title: 'Fitnes — zgornji del', zone: null, role: 'moc' }), day({ date: '2026-10-15', kind: 'tek', title: 'Tek — lahko', durationMin: 30, zone: null }), day({ date: '2026-10-17', kind: 'moc', title: 'Fitnes — spodnji del', zone: null, role: 'moc' })]
    h.json.mockImplementation(async () => ({ dnevi: [{ date: '2026-10-15', kind: 'tek', title: 'Tek — lahko', desc: 'x', durationMin: 25, zone: null, tssTarget: null }], povzetek: 'Krajši tek.' }))
    const r = await adaptWeek({ profile: g, activities: [], plan: wk, today: WED }, wk)
    const sent = txt(h.json.mock.calls[0]![0] as unknown[])
    expect(sent).toContain('Vadbe moči ostanejo, kot so v dogovoru')
    expect(sent).toContain('MOČ TA TEDEN (fiksno, ne vračaj): 2026-10-14 Fitnes — zgornji del 60 min; 2026-10-17 Fitnes — spodnji del 60 min.')
    expect(sent).not.toContain('Moč (jedro, noge)')
    expect(r.days.filter(d => d.kind === 'moc')).toHaveLength(2)
  })
  it('C30: v nedeljo in ko je teden mimo — naslednji teden, če je sestavljen', () => {
    const next = [day({ date: '2026-10-20', title: 'VO2max' }), day({ date: '2026-10-22' })]
    const cur = [day({ date: '2026-10-16' }), day({ date: SUN, kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, role: null })]
    expect(adaptTarget([...cur, ...next], SUN)).toEqual({ days: next, next: true })
    expect(adaptTarget(cur, SUN)).toEqual({ days: [cur[1]], next: false })          // naslednji ni sestavljen
    // petek: preostali dnevi samo počitek → naslednji teden
    expect(adaptTarget([day({ date: '2026-10-17', kind: 'pocitek', title: 'Počitek', durationMin: 0 }), ...next], '2026-10-16')!.next).toBe(true)
    // sreda s treningi: od danes do nedelje (brez preteklih)
    const mid = [day({ date: '2026-10-13' }), day({ date: WED }), day({ date: '2026-10-16' }), ...next]
    expect(adaptTarget(mid, WED)).toEqual({ days: [mid[1], mid[2]], next: false })
  })
})

describe('C31 odtis nasveta', () => {
  it('sprememba opisa ali vaj spremeni odtis', () => {
    const d = day({ kind: 'moc', title: 'Fitnes — zgornji del', zone: null })
    const a = adviceSig({ plan: [{ ...d, desc: 'Potisk 4 × 6', exercises: [{ name: 'Potisk', sets: 4, reps: '6' }] }], today: SUN })
    const b = adviceSig({ plan: [{ ...d, desc: 'Veslanje 3 × 12', exercises: [{ name: 'Potisk', sets: 4, reps: '6' }] }], today: SUN })
    const c = adviceSig({ plan: [{ ...d, desc: 'Potisk 4 × 6', exercises: [{ name: 'Potisk', sets: 3, reps: '10' }] }], today: SUN })
    expect(a).not.toBe(b)
    expect(a).not.toBe(c)
    expect(adviceSig({ plan: [{ ...d, desc: 'Potisk 4 × 6', exercises: [{ name: 'Potisk', sets: 4, reps: '6' }] }], today: SUN })).toBe(a)
  })
})

describe('C15 + H24 + H43 trener brez AI', () => {
  it('tekač: brez »na kolesu«, minute vseh sej', () => {
    const p = custom(runF())
    const plan = [day({ date: '2026-10-13', kind: 'tek', title: 'Tek — lahko', durationMin: 30, zone: null, done: { at: NOW, activityId: null } }), day({ date: '2026-10-15', kind: 'tek', title: 'Tek — lahko', durationMin: 30, zone: null }), day({ date: '2026-10-17', kind: 'tek', title: 'Tek — lahko', durationMin: 45, zone: null })]
    const r = localReview(lctx(p, plan, '2026-10-17'))
    expect(r).not.toMatch(/kolesu|od —/)
    expect(r).toContain('Opravljeno 1 od 3 sej (do danes jih je bilo 2) · skupaj 30 min od 1 h 45 min.')
    expect(lastWeekSummary(plan, [], '2026-10-19')!.lines[0]).toBe('1 od 3 sej · skupaj 30 min od 1 h 45 min.')
  })
  it('kolesar: tekma v naslednjih dneh je v pregledu', () => {
    const p = bike({ races: [{ id: 'r1', name: 'Kronometer Vodice', date: '2026-10-23', distanceKm: 18, prio: 'B', type: 'kronometer' }] } as Partial<Profile>)
    const plan = [...buildWeek({ profile: p, activities: [], weekStart: '2026-10-12', notBefore: '2026-10-12', today: SUN }), ...buildWeek({ profile: p, activities: [], weekStart: '2026-10-19', notBefore: '2026-10-19', today: SUN })]
    expect(plan.some(d => d.role === 'dirka' && d.date === '2026-10-23')).toBe(true)
    expect(localReview(lctx(p, plan, SUN))).toMatch(/Tekma: Kronometer Vodice.*, petek 23\. 10\./)
  })
  it('H43: današnja seja zjutraj ni zamujena', () => {
    const p = bike()
    const plan = [day({ date: '2026-10-19', title: 'Z2' }), day({ date: '2026-10-21', title: 'VO2max' })]
    const r = localReview(lctx(p, plan, '2026-10-19'))
    expect(r).toContain('Opravljeno 0 od 2 sej · na kolesu 0 min od 2 h.')
    expect(r).not.toContain('(do danes')
    expect(localReview(lctx(p, plan, '2026-10-20'))).toContain('(do danes jih je bilo 1)')
  })
})

describe('C29 lestvica maščobe za pas', () => {
  const z = { sex: 'z' as const, age: 34, heightCm: 165, weightKg: 72, bodyFatPct: null }
  it('»maščoba okoli pasu« pri 34 %: prvi cilj ploščat trebuh 21–25 %', () => {
    expect(waistIntent('Kako izgubim maščobo okoli pasu?')).toBe(true)
    expect(waistIntent('Kdaj bom imel six pack?')).toBe(false)
    const v = bodyFatView(z, 72, 'Kako izgubim maščobo okoli pasu?')
    if (v.kind !== 'scale') throw new Error(v.kind)
    expect(v.target).toEqual({ lo: 21, hi: 25 })
    expect(v.lines.join(' ')).toContain('Za ploščat trebuh je prvi cilj ~21–25 %; obrisi trebušnih mišic se pokažejo šele pri ~18–21 %.')
    const abs = bodyFatView(z, 72, 'Kdaj se mi bodo videle trebušne mišice?')
    if (abs.kind !== 'scale') throw new Error(abs.kind)
    expect(abs.target).toEqual({ lo: 18, hi: 21 })
    expect(bodyFatView(z, 72).kind === 'scale' && (bodyFatView(z, 72) as { target: unknown }).target).toEqual({ lo: 18, hi: 21 })
  })
})

describe('C13 + H23 hitra vprašanja', () => {
  it('doma brez opreme in mladoleten: brez kilogramov, maščobe in teže', () => {
    const q = quickCustom(homeF(), true).join(' | ')
    expect(q).not.toMatch(/kg|maščob|teža/i)
    expect(q).toContain('Koliko ponovitev danes pri osnovnih vajah?')
    expect(q).toContain('Koliko spanja rabim?')
  })
  it('fitnes, odrasel: kilogrami, pas in teža ostanejo', () => {
    const q = quickCustom({ ...gymF(), aims: ['moc', 'hujsanje'] }, false)   // (v3.51) pas in teža samo pri hujšanju (C39)
    expect(q).toEqual(expect.arrayContaining(['Koliko kg danes pri osnovnih vajah?', 'Kako izgubim maščobo okoli pasu?', 'Zakaj teža stoji?']))
  })
  it('kolesar 16 let brez »Zakaj teža stoji?«', () => {
    expect(quick(bike({ age: 16, deficit: 0 }))).not.toContain('Zakaj teža stoji?')
    expect(quick(bike())).toContain('Zakaj teža stoji?')
  })
})
