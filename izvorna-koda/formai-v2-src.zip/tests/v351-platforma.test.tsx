// v3.51 PLATFORMA (UI): ponoven prenos dela kode, meja napake brez povezave, list ne zavrže prebrane slike, »Razveljavi«
// s tipkovnico, preskok na vsebino, trak tedna v Planu, ime zaslona v h1, glava na namizju, slika (gumb, napaka, branje,
// prijava, napaka AI), list se odpira, namestitev na računalniku, obvestila po času.
import { act, Suspense, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>() }))
const store = vi.hoisted(() => ({ toast: vi.fn(), dismissToast: vi.fn(), signIn: vi.fn(async () => null), warmAuth: vi.fn(), updateSettings: vi.fn(async () => undefined) }))
vi.mock('@/state/store', () => ({
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  ...store,
}))
const ai = vi.hoisted(() => ({ fail: null as string | null, calls: 0 }))
vi.mock('@/ui/useAi', () => ({
  useAi: () => ({
    busy: false, signedIn: true, consent: true, sheet: null,
    run: async (fn: () => Promise<unknown>, o?: { onError?: (m: string) => void }) => { ai.calls++; if (ai.fail) { o?.onError?.(ai.fail); return undefined } return fn() },
  }),
}))
const W = vi.hoisted(() => ({ kind: 'moc', title: 'Noge', minutes: 40, exercises: [{ name: 'Počep s palico', sets: 3, reps: '8', kg: null, rest: null }], blocks: [], note: null }))
vi.mock('@/domain/ai/photoTraining', async orig => ({ ...(await orig<object>()), workoutFromPhoto: async () => JSON.parse(JSON.stringify(W)) }))
vi.mock('@/domain/ai/image', () => ({ fileToBase64Resized: async () => ({ data: 'AAAA', mime: 'image/jpeg', thumb: '' }), exifStamp: async () => null, exifHour: async () => null }))
vi.mock('@/app/router', async orig => ({ ...(await orig<typeof import('@/app/router')>()), navigate: () => undefined }))

import { retryLazy } from '@/app/chunk'
import { ErrorBoundary } from '@/app/ErrorBoundary'
import { ChunkBoundary } from '@/ui/ChunkBoundary'
import { Sheet } from '@/ui/primitives'
import { undoToast, UndoHost, _resetUndo, undoKey } from '@/ui/Confirm'
import { Shell, Head, skipToContent } from '@/app/Shell'
import { WeekRibbon } from '@/ui/PlanHero'
import { PhotoInput, DESK_HINT } from '@/ui/PhotoInput'
import { PhotoTrainingSheet } from '@/ui/PhotoTrainingSheet'
import { InstallRow } from '@/ui/PlatformRows'
import { Toasts } from '@/ui/Toasts'
import { OverlayHost } from '@/ui/OverlayHost'
import { openPhotoTraining, closePhotoTraining } from '@/ui/photoOpen'
import type { PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
window.scrollTo = (() => undefined) as typeof window.scrollTo

const TODAY = '2026-10-21'
const profile = { sex: 'm', age: 30, heightCm: 180, weightKg: 75, ftp: 250, aiConsentAt: 'x', aiConsentV: 3, gear: { bikeOutdoor: true, trainer: false, noBike: false }, strength: { on: false, equipment: 'none' }, onboardingDone: true, createdAt: 'x', updatedAt: 'x' } as unknown as Profile
const base = (o: Record<string, unknown> = {}) => ({ ready: true, today: TODAY, plan: [], activities: [], recentMeals: [], weather: null, settings: { lang: 'sl', intervals: null }, toast: null, toasts: [], profile, user: { uid: 'u' }, authKnown: true, sync: { state: 'off' }, changes: [], ...o })

let div: HTMLDivElement, root: Root | null = null
async function mount(el: ReactElement) { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div); await act(async () => { root!.render(el) }) }
const sp = (x: string | null | undefined) => (x || '').replace(/[  ⁠]/g, ' ')
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(sp(b.textContent)) || re.test(b.getAttribute('aria-label') || '')) as HTMLButtonElement | undefined
const flush = async (n = 6) => { for (let i = 0; i < n; i++) await act(async () => { await new Promise(r => setTimeout(r, 0)) }) }
const setOnline = (v: boolean) => Object.defineProperty(navigator, 'onLine', { configurable: true, get: () => v })
beforeEach(() => { S.state = base(); S.subs.clear(); store.toast.mockClear(); ai.fail = null; ai.calls = 0; setOnline(true) })
afterEach(async () => { if (root) { await act(async () => root!.unmount()); root = null } document.body.innerHTML = ''; _resetUndo(); setOnline(true) })

describe('G03 — del kode, ki se ne prenese, se po vrnitvi povezave prenese (brez osvežitve)', () => {
  it('retryLazy: po neuspehu »Poskusi znova« prenaša znova in pokaže zaslon (React.lazy bi ostal pokvarjen)', async () => {
    const err = console.error; console.error = () => undefined
    setOnline(false)   // orReload brez povezave ne osveži strani
    let ok = false, calls = 0
    const Comp = () => <p>Plan je tu</p>
    const L = retryLazy(() => { calls++; return ok ? Promise.resolve(Comp) : Promise.reject(new TypeError('Failed to fetch dynamically imported module: /assets/Plan-x.js')) })
    location.hash = '#/plan'
    await mount(<ErrorBoundary screen><Suspense fallback={null}><L /></Suspense></ErrorBoundary>)
    await flush()
    expect(document.body.textContent).toContain('Ta zaslon se ni naložil')
    // G15: vzrok je povezava, ne »drugi zavihki delajo«
    expect(sp(document.body.textContent)).toContain('Ni povezave — Plan še ni na napravi.')
    expect(document.body.textContent).not.toContain('Drugi zavihki delajo')
    ok = true; setOnline(true)
    await act(async () => { btn(/Poskusi znova/)!.click() })
    await flush()
    expect(document.body.textContent).toContain('Plan je tu')
    expect(calls).toBeLessThanOrEqual(3)   // brez kroga: prvi prenos, en ponoven ob meji, »Poskusi znova«
    console.error = err
  })
  it('meja zaslona poskusi znova sama, ko se povezava vrne (dogodek online)', async () => {
    const err = console.error; console.error = () => undefined
    setOnline(false)
    let ok = false
    const L = retryLazy(() => (ok ? Promise.resolve(() => <p>Prehrana je tu</p>) : Promise.reject(new TypeError('Importing a module script failed.'))))
    await mount(<ErrorBoundary screen><Suspense fallback={null}><L /></Suspense></ErrorBoundary>)
    await flush()
    expect(document.body.textContent).toContain('Ta zaslon se ni naložil')
    ok = true; setOnline(true)
    await act(async () => { window.dispatchEvent(new Event('online')) })
    await flush()
    expect(document.body.textContent).toContain('Prehrana je tu')
    console.error = err
  })
  it('ChunkBoundary (list): ime dela, besedilo o povezavi in »Poskusi znova«', async () => {
    const err = console.error; console.error = () => undefined
    setOnline(false)
    let ok = false
    const L = retryLazy(() => (ok ? Promise.resolve(() => <p>List s slike</p>) : Promise.reject(new TypeError('Failed to fetch dynamically imported module'))))
    await mount(<ChunkBoundary onClose={() => undefined} label="Trening s slike"><Suspense fallback={null}><L /></Suspense></ChunkBoundary>)
    await flush()
    expect(document.querySelector('h2')!.textContent).toBe('Trening s slike')
    expect(document.body.textContent).toContain('Ni povezave — tega dela še ni na napravi.')
    ok = true; setOnline(true)
    await act(async () => { btn(/^Poskusi znova$/)!.click() })
    await flush()
    expect(document.body.textContent).toContain('List s slike')
    console.error = err
  })
})

describe('G04 — Esc, Nazaj ali tap ob listu ne zavržejo prebrane slike', () => {
  it('guard: Esc pokaže »Zavržem prebrani trening?«, »Ostani« pusti list, »Zavrzi« zapre', async () => {
    const onClose = vi.fn()
    await mount(<Sheet open onClose={onClose} guard="Zavržem prebrani trening?"><p>predogled</p></Sheet>)
    await act(async () => { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })) })
    expect(onClose).not.toHaveBeenCalled()
    expect(document.querySelector('[role="alertdialog"]')!.textContent).toContain('Zavržem prebrani trening?')
    await act(async () => { btn(/^Ostani$/)!.click() })
    expect(document.querySelector('[role="alertdialog"]')).toBeNull()
    await act(async () => { (document.querySelector('.veil') as HTMLElement).click() })
    expect(onClose).not.toHaveBeenCalled()
    await act(async () => { btn(/^Zavrzi$/)!.click() })
    expect(onClose).toHaveBeenCalledTimes(1)
  })
  it('brez guard: Esc zapre kot prej', async () => {
    const onClose = vi.fn()
    await mount(<Sheet open onClose={onClose}><p>nič prebranega</p></Sheet>)
    await act(async () => { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })) })
    expect(onClose).toHaveBeenCalledTimes(1)
  })
  it('Trening s slike: po branju (predogled) Esc vpraša', async () => {
    const P = PhotoTrainingSheet
    await mount(<P req={{ mode: 'plan' }} />)
    const input = document.querySelector('input[type=file]:not([capture])') as HTMLInputElement
    Object.defineProperty(input, 'files', { configurable: true, value: [new File(['x'], 't.jpg', { type: 'image/jpeg' })] })
    await act(async () => { input.dispatchEvent(new Event('change', { bubbles: true })) })
    await flush()
    expect(document.body.textContent).toContain('Preveri trening s slike')
    await act(async () => { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })) })
    expect(document.querySelector('[role="alertdialog"]')!.textContent).toContain('Zavržem prebrani trening?')
  })
})

describe('G10 — »Razveljavi« s tipkovnico', () => {
  it('fokus ali kazalec na obvestilu ustavi čas; Ctrl+Z razveljavi', async () => {
    vi.useFakeTimers()
    const undo = vi.fn()
    await mount(<div className="toast-stack"><UndoHost /></div>)
    await act(async () => { undoToast('Premor do nedelje.', undo, { ms: 8000 }) })
    const b = btn(/Razveljavi/)!
    expect(b.getAttribute('aria-keyshortcuts')).toBe('Control+Z')
    await act(async () => { b.focus() })
    await act(async () => { vi.advanceTimersByTime(20_000) })
    expect(btn(/Razveljavi/)).toBeTruthy()                        // prej po 8 s izginilo
    await act(async () => { b.blur() })
    await act(async () => { vi.advanceTimersByTime(4100) })
    expect(btn(/Razveljavi/)).toBeUndefined()
    await act(async () => { undoToast('Premor do nedelje.', undo, { ms: 8000 }) })
    await act(async () => { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', ctrlKey: true, bubbles: true })) })
    await act(async () => { await Promise.resolve() })
    expect(undo).toHaveBeenCalledTimes(1)
    vi.useRealTimers()
  })
  it('Ctrl+Z med tipkanjem v polje ne razveljavi', () => {
    const undo = vi.fn()
    undoToast('x', undo)
    const inp = document.createElement('input')
    expect(undoKey({ key: 'z', ctrlKey: true, metaKey: false, shiftKey: false, altKey: false, target: inp })).toBe(false)
    expect(undoKey({ key: 'z', ctrlKey: true, metaKey: false, shiftKey: false, altKey: false, target: document.body })).toBe(true)
  })
})

describe('G16, G18, G20, G44 — glava', () => {
  it('»Preskoči na vsebino« pristane za glavo zaslona (ne na gumbih glave)', async () => {
    location.hash = '#/plan'
    await mount(<Shell><Head hi="Teden" nm="Ta teden" /><div className="scroll"><button>Prejšnji</button></div></Shell>)
    skipToContent()
    expect(document.activeElement!.classList.contains('scroll')).toBe(true)
    expect(document.activeElement!.closest('.head')).toBeNull()
  })
  it('h1 pove zaslon (»Plan — Ta teden«); brez dvojnika, ko ime že je zaslon', async () => {
    location.hash = '#/plan'
    await mount(<Head hi="Teden" nm="Ta teden" />)
    expect(document.querySelector('h1')!.getAttribute('aria-label')).toBe('Plan — Ta teden')
    expect(document.querySelector('h1')!.textContent).toBe('Ta teden')
    location.hash = '#/napredek'
    await act(async () => { root!.render(<Head hi="x" nm="Napredek" key="b" />) })
    expect(document.querySelector('h1')!.getAttribute('aria-label')).toBeNull()
  })
  it('vrstica na namizju je <header> (orientir); avatar pove napako usklajevanja', async () => {
    S.state = base({ sync: { state: 'error' } })
    location.hash = '#/danes'
    await mount(<Shell><Head hi="x" nm="Živjo" /></Shell>)
    expect(document.querySelector('.dbar')!.tagName).toBe('HEADER')
    for (const a of document.querySelectorAll('button.avatar')) expect(a.getAttribute('aria-label')).toBe('Nastavitve in profil — usklajevanje ne dela')
    expect(document.querySelector('.dot.sync-err')).toBeTruthy()
  })
})

describe('G17 — trak tedna v Planu: en postanek Tab', () => {
  it('natanko en gumb s tabIndex 0 (izbran dan), puščica premakne fokus', async () => {
    const days = Array.from({ length: 7 }, (_, i) => `2026-10-${String(19 + i).padStart(2, '0')}`)
    const d = (date: string): PlanDay => ({ id: date, date, kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, source: 'rules', createdAt: 'x', updatedAt: 'x' } as PlanDay)
    await mount(<WeekRibbon days={days} items={days.map(d)} today={TODAY} focus={TODAY} onPick={() => undefined} />)
    const bs = [...document.querySelectorAll('.pl-ribbon button')] as HTMLButtonElement[]
    expect(bs.filter(b => b.tabIndex === 0)).toHaveLength(1)
    expect(bs[2]!.tabIndex).toBe(0)
    bs[2]!.focus()
    await act(async () => { bs[2]!.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true })) })
    expect(document.activeElement).toBe(bs[3])
  })
})

describe('G26, G28, G29 — izbira slike', () => {
  const mm = (fine: boolean) => { window.matchMedia = ((q: string) => ({ matches: fine ? q === '(pointer: fine)' : q === '(any-pointer: coarse)', media: q, addEventListener() {}, removeEventListener() {} })) as never }
  it('računalnik z miško: en gumb »Izberi sliko« in namig za povleci-spusti / Ctrl+V tudi ob lastnem namigu', async () => {
    mm(true)
    await mount(<PhotoInput onPick={() => undefined} hint="Posnetkov iz Strave ne nalagaj." />)
    expect(btn(/Izberi sliko/)).toBeTruthy()
    expect(btn(/Slikaj/)).toBeUndefined()
    expect(document.body.textContent).toContain(DESK_HINT)
    expect(document.body.textContent).toContain('Posnetkov iz Strave ne nalagaj.')
  })
  it('telefon: »Slikaj« in »Iz galerije«; datoteka, ki ni slika → sporočilo, onPick ni klican', async () => {
    mm(false)
    const onPick = vi.fn()
    await mount(<PhotoInput onPick={onPick} />)
    expect(btn(/Slikaj/)).toBeTruthy(); expect(btn(/Iz galerije/)).toBeTruthy()
    const input = document.querySelectorAll('input[type=file]')[1] as HTMLInputElement
    Object.defineProperty(input, 'files', { configurable: true, value: [new File(['x'], 'trening.pdf', { type: 'application/pdf' })] })
    await act(async () => { input.dispatchEvent(new Event('change', { bubbles: true })) })
    expect(onPick).not.toHaveBeenCalled()
    expect(document.querySelector('[role="alert"]')!.textContent).toMatch(/^To ni slika — izberi fotografijo ali posnetek zaslona \(JPG, PNG, HEIC\)\. Pri PDF-ju pošlji posnetek zaslona\.$/)
  })
  it('»Berem sliko …« v živem območju (role=status), kartica aria-busy', async () => {
    await mount(<PhotoInput onPick={() => undefined} busy />)
    expect(document.querySelector('[role="status"]')!.textContent).toBe('Berem sliko …')
    expect(document.querySelector('[aria-busy="true"]')).toBeTruthy()
  })
})

describe('G11, G13 — Trening s slike: prijava pred sliko, napaka v listu', () => {
  it('brez prijave: »Prijava z Googlom« namesto izbire slike (okno se odpre v dotiku)', async () => {
    S.state = base({ user: null, authKnown: true })
    await mount(<PhotoTrainingSheet req={{ mode: 'plan' }} />)
    expect(btn(/Prijava z Googlom/)).toBeTruthy()
    expect(document.querySelector('input[type=file]')).toBeNull()
    expect(store.warmAuth).toHaveBeenCalled()
    await act(async () => { btn(/Prijava z Googlom/)!.click() })
    expect(store.signIn).toHaveBeenCalled()
  })
  it('napaka AI: v listu role=alert z »Poskusi znova« (ista slika) in ročno potjo; brez obvestila nad listom', async () => {
    ai.fail = 'AI zdaj ne more odgovoriti — poskusi čez minuto.'
    await mount(<PhotoTrainingSheet req={{ mode: 'done' }} />)
    const input = document.querySelectorAll('input[type=file]')[1] as HTMLInputElement
    Object.defineProperty(input, 'files', { configurable: true, value: [new File(['x'], 'ura.jpg', { type: 'image/jpeg' })] })
    await act(async () => { input.dispatchEvent(new Event('change', { bubbles: true })) })
    await flush()
    const al = [...document.querySelectorAll('[role="alert"]')].find(e => /Branje ni uspelo/.test(e.textContent || ''))!
    expect(al.textContent).toContain('AI zdaj ne more odgovoriti')
    expect(btn(/Vpiši ročno/)).toBeTruthy()
    await act(async () => { btn(/^Poskusi znova$/)!.click() })
    expect(ai.calls).toBe(2)
  })
})

describe('G27 — napaka v obrazcu s slike: fokus na napačno polje', () => {
  it('ponovitve 900 → po »Dodaj v načrt« fokus na polju z aria-invalid in opisom napake', async () => {
    const P = PhotoTrainingSheet
    await mount(<P req={{ mode: 'plan' }} />)
    const input = document.querySelector('input[type=file]:not([capture])') as HTMLInputElement
    Object.defineProperty(input, 'files', { configurable: true, value: [new File(['x'], 't.jpg', { type: 'image/jpeg' })] })
    await act(async () => { input.dispatchEvent(new Event('change', { bubbles: true })) })
    await flush()
    const reps = document.querySelector('input[aria-label="Ponovitve ali sekunde"]') as HTMLInputElement
    await act(async () => { const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!; set.call(reps, '900'); reps.dispatchEvent(new Event('input', { bubbles: true })) })
    await act(async () => { btn(/Dodaj v načrt/)!.click() })
    await flush()
    const a = document.activeElement as HTMLElement
    expect(a.getAttribute('aria-invalid')).toBe('true')
    expect(a.getAttribute('aria-describedby')).toBe('pt-err')
    expect(document.getElementById('pt-err')!.getAttribute('role')).toBe('alert')
  })
})

describe('G30 — prvo odprtje lista s slike ni prazno', () => {
  it('med prenosom »Trening s slike · Odpiram …«', async () => {
    await mount(<OverlayHost />)
    await act(async () => { openPhotoTraining({ mode: 'plan' }) })
    expect(document.querySelector('.sheet')!.textContent).toMatch(/Trening s slike|Odpiram …/)
    await flush(10)
    closePhotoTraining()
  })
})

describe('G36 — namestitev na računalniku, ko jo brskalnik ponuja', () => {
  it('1440 px brez poziva: nič; s pozivom: »Namesti na računalnik«', async () => {
    Object.defineProperty(window, 'innerWidth', { configurable: true, value: 1440 })
    await mount(<InstallRow />)
    expect(btn(/Namesti/)).toBeUndefined()
    await act(async () => root!.unmount()); root = null
    const ev = Object.assign(new Event('beforeinstallprompt'), { prompt: async () => undefined, userChoice: Promise.resolve({ outcome: 'dismissed' }) })
    window.dispatchEvent(ev)
    await mount(<InstallRow />)
    expect(btn(/Namesti na računalnik/)).toBeTruthy()
    Object.defineProperty(window, 'innerWidth', { configurable: true, value: 1024 })
  })
})

describe('G45 — obvestila po času', () => {
  it('napaka med drugimi dobi order po id (novejše spodaj)', async () => {
    S.state = base({ toasts: [{ id: 1, msg: 'Posodobitev …', kind: 'info' }, { id: 2, msg: 'Ni povezave', kind: 'err' }, { id: 3, msg: 'Novo', kind: 'info' }] })
    await mount(<Toasts />)
    const order = (re: RegExp) => Number(([...document.querySelectorAll('.toast')] as HTMLElement[]).find(t => re.test(t.textContent || ''))!.style.order)
    expect(order(/Posodobitev/)).toBeLessThan(order(/Ni povezave/))
    expect(order(/Ni povezave/)).toBeLessThan(order(/Novo/))
    expect(document.querySelector('[role="alert"]')!.textContent).toContain('Ni povezave')   // živi območji ostaneta ločeni
  })
})
