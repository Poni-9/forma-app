import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { fetchStreams, fetchActivities, fetchEvents, createEvents, IcuError, IcuBusy, IcuBudget, icuErrorKind, icuBudget, resetIcuPause, setIcuQuotaStore, ICU_DAILY_BUDGET, type IcuQuota } from '../src/domain/intervals/client'
import { fillRouteLib, loadRouteLib, saveRouteLib, ROUTE_STREAMS_PER_RUN } from '../src/data/routes'
import type { Activity } from '../src/domain/types'

const C = { athleteId: '0', apiKey: '', token: 'tok' }
const KEY = { athleteId: 'i1', apiKey: 'k' }
beforeEach(() => { resetIcuPause(); void setIcuQuotaStore(null) })
afterEach(() => { vi.unstubAllGlobals(); resetIcuPause(); void setIcuQuotaStore(null) })
const stub = (f: (url: string, init?: RequestInit) => Response | Promise<Response>) => { const m = vi.fn(async (u: string, i?: RequestInit) => f(u, i)); vi.stubGlobal('fetch', m); return m }
// ~20 km sledi (400 točk po ~50 m), z višinami
const LAT = Array.from({ length: 400 }, (_, k) => 46 + k * 0.00045), LNG = Array.from({ length: 400 }, (_, k) => 14 + Math.sin(k / 40) * 0.01), ALT = Array.from({ length: 400 }, (_, k) => 300 + (k % 100))
const track = () => new Response(JSON.stringify([{ type: 'latlng', data: LAT, data2: LNG }, { type: 'altitude', data: ALT }]), { status: 200 })
const ride = (i: number, o: Partial<Activity> = {}): Activity => ({ id: 'a' + i, source: 'intervals', originHint: 'GARMIN', sport: 'kolo', date: '2026-09-' + String(1 + (i % 25)).padStart(2, '0'), name: 'x', distKm: 40, aiEligible: true, geoRetain: true, ext: { intervalsId: 'i' + i }, createdAt: '', updatedAt: '', ...o })

describe('sled vožnje (fetchStreams)', () => {
  it('404 ali prazen odgovor → brez sledi; 401/403/429/5xx/omrežje → napaka (vožnja ostane za naslednjič)', async () => {
    stub(() => new Response('', { status: 404 })); expect(await fetchStreams(C, 1)).toBeNull()
    stub(() => new Response('', { status: 200 })); expect(await fetchStreams(C, 1)).toBeNull()
    stub(() => new Response('[]', { status: 200 })); expect(await fetchStreams(C, 1)).toBeNull()
    for (const s of [401, 403]) {
      stub(() => new Response('', { status: s }))
      const e = await fetchStreams(C, 1).catch(x => x)
      expect(e).toBeInstanceOf(IcuError); expect(icuErrorKind(e)).toBe('auth')
    }
    stub(() => new Response('', { status: 502 })); expect(icuErrorKind(await fetchStreams(C, 1).catch(x => x))).toBe('network')
    stub(() => { throw new TypeError('Failed to fetch') }); expect(icuErrorKind(await fetchStreams(C, 1).catch(x => x))).toBe('network')
    stub(() => new Response('', { status: 429, headers: { 'Retry-After': '60' } })); expect(await fetchStreams(C, 1).catch(x => x)).toBeInstanceOf(IcuBusy)
  })
  it('vsak klic ima časovno omejitev (signal)', async () => {
    const f = stub(() => new Response('[]', { status: 200 }))
    await fetchActivities(KEY, '2026-09-01', '2026-09-25')
    expect(f.mock.calls[0]![1]!.signal).toBeTruthy()
  })
})

describe('knjižnica tras (fillRouteLib)', () => {
  beforeEach(async () => { await saveRouteLib({ v: 1, raw: [], gen: [], home: null, done: [], at: 0 }) })
  it('401 (preklican žeton): nobena vožnja ni označena kot »brez sledi«; en zahtevek, nato stop', async () => {
    const acts = Array.from({ length: 60 }, (_, i) => ride(i))
    const f = stub(() => new Response('{"status":401}', { status: 401 }))
    const r = await fillRouteLib(C, acts)
    expect(f).toHaveBeenCalledTimes(1)
    expect(icuErrorKind(r.error)).toBe('auth')
    expect((await loadRouteLib()).done).toEqual([])
    // žeton popravljen → največ 15 na krog, vsaka vožnja enkrat
    const g = stub(() => track())
    const r2 = await fillRouteLib(C, acts)
    expect(g).toHaveBeenCalledTimes(ROUTE_STREAMS_PER_RUN)
    expect(r2.error).toBeNull()
    const lib = await loadRouteLib()
    expect(lib.done.length).toBe(ROUTE_STREAMS_PER_RUN)
    const g2 = stub(() => track())
    await fillRouteLib(C, acts.slice(0, 20))
    const left = 20 - lib.done.filter(k => acts.slice(0, 20).some(a => k === 'icu:' + a.ext!.intervalsId)).length
    expect(g2).toHaveBeenCalledTimes(Math.min(ROUTE_STREAMS_PER_RUN, left))
  })
  it('vožnja, pozneje prepoznana kot Strava (geoRetain false), gre iz knjižnice; preimenovan lokalni id ne sproži ponovnega prenosa', async () => {
    const acts = [ride(1), ride(2)]
    stub(() => track())
    await fillRouteLib(C, acts)
    expect((await loadRouteLib()).raw.map(r => r.id).sort()).toEqual(['a1', 'a2'])
    const f = stub(() => track())
    const after = [ride(1, { originHint: 'STRAVA', aiEligible: false, geoRetain: false }), ride(2, { id: 'b2' })]
    const r = await fillRouteLib(C, after)
    expect(f).not.toHaveBeenCalled()
    expect(r.lib.raw.map(x => x.id)).toEqual(['b2'])
  })
  it('knjižnica se shrani samo ob spremembi', async () => {
    stub(() => track())
    await fillRouteLib(C, [ride(1)])
    const at = (await loadRouteLib()).at
    await new Promise(r => setTimeout(r, 5))
    stub(() => track())
    await fillRouteLib(C, [ride(1)])
    expect((await loadRouteLib()).at).toBe(at)
  })
})

describe('kvota intervals.icu', () => {
  it('premor po 429 se shrani in velja tudi po ponovnem zagonu (shramba)', async () => {
    let saved: IcuQuota | null = null
    await setIcuQuotaStore({ load: async () => saved, save: async q => { saved = q } })
    stub(() => new Response('', { status: 429, headers: { 'Retry-After': '600' } }))
    await expect(fetchActivities(C, '2026-09-01', '2026-09-25')).rejects.toBeInstanceOf(IcuBusy)
    expect(saved!.pauseUntil).toBeGreaterThan(Date.now() + 500_000)
    // »ponovni zagon«: pomnilnik prazen, shramba ima premor
    resetIcuPause()
    const f = stub(() => new Response('[]', { status: 200 }))
    await setIcuQuotaStore({ load: async () => saved, save: async q => { saved = q } })
    await expect(fetchActivities(C, '2026-09-01', '2026-09-25')).rejects.toBeInstanceOf(IcuBusy)
    expect(f).not.toHaveBeenCalled()
  })
  it('dnevni proračun (OAuth 80): nenujni klici (sledi, koledar) po porabi počakajo, nujni (seznam voženj) gredo', async () => {
    const f = stub(() => new Response('[]', { status: 200 }))
    for (let i = 0; i < ICU_DAILY_BUDGET.oauth; i++) await fetchStreams(C, i)
    expect(icuBudget(C).left).toBe(0)
    const e = await fetchStreams(C, 999).catch(x => x)
    expect(e).toBeInstanceOf(IcuBudget); expect(icuErrorKind(e)).toBe('quota')
    await expect(fetchEvents(C, '2026-09-25', '2026-10-08')).rejects.toBeInstanceOf(IcuBudget)
    await expect(createEvents(C, [{ uid: 'formai-2026-09-26', date: '2026-09-26', name: 'x', description: '', movingTime: 60 }], { essential: true })).resolves.toBeUndefined()
    await expect(fetchActivities(C, '2026-09-01', '2026-09-25')).resolves.toBeTruthy()
    expect(f).toHaveBeenCalledTimes(ICU_DAILY_BUDGET.oauth + 2)
    // osebni API ključ ima večji proračun
    expect(icuBudget(KEY).left).toBe(ICU_DAILY_BUDGET.key - ICU_DAILY_BUDGET.oauth - 2)
  })
  it('razvrstitev napak: 401 pri seznamu voženj = auth z enakim sporočilom kot prej', async () => {
    stub(() => new Response('', { status: 401 }))
    const e = await fetchActivities(C, '2026-09-01', '2026-09-25').catch(x => x)
    expect(icuErrorKind(e)).toBe('auth'); expect(e.message).toMatch(/zavrača dostop \(HTTP 401\)/)
    expect(icuErrorKind(Object.assign(new Error('x'), { name: 'TimeoutError' }))).toBe('network')
    expect(icuErrorKind(new Error('x'))).toBe('other')
  })
})
