import { describe, it, expect } from 'vitest'
import { bikeWeeks, baselineHours, zoneSplit, checkRide, powerMeterFrom, moveKeySession, keyCompliance, efTrend, realitySummary } from '../src/domain/training/review'
import { weekContext, rampCap, FRANJA_2027 } from '../src/domain/training/planner'
import { effectiveHours, ftpPotential } from '../src/domain/training/goal'
import { workText, zoneText } from '../src/domain/training/zones'
import type { Activity, PlanDay, Profile } from '../src/domain/types'

const now = new Date().toISOString()
const act = (o: Partial<Activity>): Activity => ({ id: Math.random().toString(36).slice(2), source: 'intervals', sport: 'kolo', date: '2026-09-22', name: 'x', durationMin: 60, aiEligible: true, geoRetain: true, createdAt: now, updatedAt: now, ...o })
const day = (o: Partial<PlanDay>): PlanDay => ({ id: Math.random().toString(36).slice(2), date: '2026-09-22', kind: 'kolo', title: 'Z2 vzdržljivost', desc: '', durationMin: 90, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: now, updatedAt: now, ...o })
// Blaževa vožnja 22. 9.: 1 h 57 min, cone utripa iz intervals.icu (LTHR 184)
const today22 = act({ durationMin: 116, avgHr: 151, maxHr: 181, hrZoneSec: [2375, 4044, 340, 232, 0, 0, 0], hrZoneTop: [148, 164, 171, 183, 188, 194, 203], deviceWatts: false, distKm: 53.1, elevM: 502, speedKmh: 27.2 })

describe('trening v resnici', () => {
  it('ure na teden in izhodišče (samo polni tedni od prvega s podatki)', () => {
    const acts = [act({ date: '2026-09-01', durationMin: 120 }), act({ date: '2026-09-03', durationMin: 60 }), act({ date: '2026-09-09', durationMin: 90 }), act({ date: '2026-09-15', durationMin: 130 }), act({ date: '2026-09-21', durationMin: 70 }), today22]
    const bw = bikeWeeks(acts, '2026-09-22', 8)
    expect(bw.full.map(w => w.hours)).toEqual([3, 1.5, 2.2])
    expect(bw.current.hours).toBe(3.1)
    expect(baselineHours(acts, '2026-09-22')).toBe(2.2)
    expect(baselineHours([today22], '2026-09-22')).toBeNull()
  })
  it('VO2max na dan, ko je bila lahka vožnja → »ni bil narejen«; prestavi na naslednji lahki dan', () => {
    const vo = day({ title: 'VO2max 4 × 4 min', zone: 'Z5', role: 'kljucna', durationMin: 75, target: { lo: 259, hi: 276 }, done: { at: now, activityId: today22.id } })
    const c = checkRide(vo, today22)!
    expect(c.status).toBe('drugace'); expect(c.verdict).toMatch(/VO2max ni bil narejen — bila je lahka/)
    expect(c.easyPct).toBe(92); expect(c.detail).toMatch(/nad 172/)
    const ok = checkRide(vo, act({ durationMin: 75, hrZoneSec: [900, 1500, 600, 500, 400, 100, 0] }))!
    expect(ok.status).toBe('ok')
    const z2 = checkRide(day({}), act({ durationMin: 90, hrZoneSec: [600, 2400, 1200, 1200, 0, 0, 0] }))!
    expect(z2.status).toBe('delno'); expect(z2.verdict).toMatch(/Pretežko za Z2/)
    // teden: tor VO2max (danes), sre Z2, čet prag, pet regeneracija, sob dolga, ned Z2
    const w = [vo, day({ date: '2026-09-23' }), day({ date: '2026-09-24', title: 'Sweet spot 3 × 12 min', role: 'kljucna', zone: 'Z4' }), day({ date: '2026-09-25', title: 'Regeneracija', role: 'regen', zone: 'Z1' }), day({ date: '2026-09-26', title: 'Dolga Z2', role: 'dolga', durationMin: 200 }), day({ date: '2026-09-27', title: 'Z2 — sam ali v skupini' })]
    // vsi lahki dnevi so ob ključnem ali dolgem (čet prag, sob dolga) → ne prestavi, izpusti
    expect(moveKeySession(w, vo, '2026-09-22')).toBeNull()
    // teden z malo urami: tor ključni, čet Z2, sob dolga → na četrtek (sreda in petek sta prosta)
    const lw = [vo, day({ date: '2026-09-24' }), day({ date: '2026-09-26', title: 'Dolga Z2', role: 'dolga', durationMin: 100 })]
    const r = moveKeySession(lw, vo, '2026-09-22')!
    expect(r[0].title).toMatch(/Z2/); expect(r[0].done).toBeTruthy()
    expect(r[1].title).toBe('VO2max 4 × 4 min'); expect(r[1].date).toBe('2026-09-24')
    // ta teden (po prestavitvi načrta): čet test, sob dolga, ostalo počitek/moč → ni kam
    const bw2 = [vo, day({ date: '2026-09-24', kind: 'test', title: 'Test FTP 20 min', role: 'test' }), day({ date: '2026-09-26', title: 'Dolga Z2', role: 'dolga', durationMin: 100 })]
    expect(moveKeySession(bw2, vo, '2026-09-22')).toBeNull()
    const kc = keyCompliance(w, [today22], '2026-09-22', '2026-09-22')
    expect(kc).toMatchObject({ ok: 0, total: 1 })
  })
  it('80/20 po utripu, merilnik moči, aerobna učinkovitost', () => {
    const zs = zoneSplit([today22])!
    expect(zs.easy).toBe(92); expect(zs.hard).toBe(3)
    expect(powerMeterFrom([today22, act({ date: '2026-09-15', deviceWatts: false }), act({ date: '2026-09-08', deviceWatts: false })], '2026-09-22')).toBe(false)
    expect(powerMeterFrom([today22, act({ deviceWatts: true })], '2026-09-22')).toBe(true)
    expect(powerMeterFrom([today22], '2026-09-22')).toBeNull()
    const ef = efTrend([act({ date: '2026-08-04', durationMin: 60, avgHr: 150, speedKmh: 27, distKm: 27, elevM: 100 }), act({ date: '2026-09-01', durationMin: 60, avgHr: 150, speedKmh: 28, distKm: 28, elevM: 100 }), act({ date: '2026-09-15', durationMin: 60, avgHr: 148, speedKmh: 29, distKm: 29, elevM: 100 })], '2026-09-22', 12)
    expect(ef.length).toBe(3); expect(ef[2]!.ef).toBeGreaterThan(ef[0]!.ef)
  })
  it('načrt raste od dejanskih ur (+10 % na teden) in napoved FTP temu sledi', () => {
    expect(rampCap({ baseHours: 3.7 }, 0, false)).toBeCloseTo(4.44, 2)
    expect(rampCap({ baseHours: 3.7 }, 1, false)).toBeCloseTo(4.88, 2)
    expect(rampCap({ baseHours: null }, 0, false)).toBe(Infinity)
    const p = { sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, ftpDate: '2026-09-20', hoursPerWeek: 14, level: 3, goal: 'dirka', strength: { on: true }, strengthDays: 2, gear: { bikeOutdoor: true, trainer: false, noBike: false }, event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', goalStart: { date: '2026-09-22', ftp: 240, weightKg: 79 } } as unknown as Profile
    expect(weekContext(p, '2026-09-21').hours).toBeGreaterThan(9)
    const r = { ...p, baseHours: 3.7 }
    expect(weekContext(r, '2026-09-21').hours).toBe(4.5)
    expect(weekContext(r, '2026-09-28').hours).toBeLessThanOrEqual(5)
    expect(effectiveHours(r, '2026-09-22')).toBeLessThan(14)
    expect(ftpPotential(r, '2026-09-22')!.ideal).toBeLessThan(ftpPotential(p, '2026-09-22')!.ideal)
  })
  it('brez merilnika moči: cilji v utripu po pražnem utripu', () => {
    const p = { ftp: 240, lthr: 184, maxHr: 203, restHr: 70, gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false } } as unknown as Profile
    expect(zoneText(p, 'Z2')).toBe('utrip 149–164')
    expect(workText(p, { target: { lo: 259, hi: 276 }, zone: 'Z5' })).toBe('utrip nad 184 · RPE 9')
    expect(workText({ ...p, gear: { ...p.gear, powerMeter: true } }, { target: { lo: 259, hi: 276 }, zone: 'Z5' })).toBe('259–276 W')
    const lines = realitySummary({ hoursPerWeek: 14, gear: p.gear }, [act({ date: '2026-09-01', durationMin: 120 }), act({ date: '2026-09-09', durationMin: 90 }), act({ date: '2026-09-15', durationMin: 130 }), today22], [], '2026-09-22')
    expect(lines.join(' ')).toMatch(/Nima merilnika moči/)
    expect(lines[0]).toMatch(/povprečno .* h na teden/)
  })
})
