import { describe, it, expect } from 'vitest'
import { watchOf, watchSteps, courseName } from '../src/domain/routes/watch'
import { toGpx } from '../src/domain/routes/brouter'

const a = (deviceName: string | null, date: string) => ({ deviceName, date })

describe('ura iz voženj', () => {
  it('Forerunner 255 (Blaž): brez zemljevida s cestami, zadnja vožnja šteje', () => {
    const w = watchOf([a('Garmin Edge 530', '2026-05-01'), a('Garmin Forerunner 255', '2026-09-23'), a(null, '2026-09-24')])
    expect(w).toEqual({ name: 'Garmin Forerunner 255', maps: false, edge: false })
    expect(watchOf([a('GARMIN FR255', '2026-09-01')]).name).toBe('Garmin Forerunner 255')
  })
  it('modeli z zemljevidi, Edge in neznano', () => {
    expect(watchOf([a('Garmin Forerunner 965', '2026-09-01')]).maps).toBe(true)
    expect(watchOf([a('Garmin fēnix 7', '2026-09-01')]).maps).toBe(true)
    expect(watchOf([a('Garmin fenix 6', '2026-09-01')]).maps).toBe(false)
    expect(watchOf([a('Garmin Edge 540', '2026-09-01')])).toMatchObject({ edge: true, maps: true })
    expect(watchOf([a('Garmin Edge 130 Plus', '2026-09-01')])).toMatchObject({ edge: true, maps: false })
    expect(watchOf([a('Zwift', '2026-09-01')])).toEqual({ name: null, maps: null, edge: false })
  })
  it('koraki: trening in proga pred START, iskreno o zemljevidu', () => {
    const w = watchOf([a('Garmin Forerunner 255', '2026-09-23')])
    const s = watchSteps(w, 'FORMAI 25.9. Sweet spot 3 × 12', 'Sweet spot 3 × 12 min', true)
    expect(s[0]).toMatch(/Send to Device/)
    expect(s.join(' ')).toMatch(/Do Workout[\s\S]*Do Course\. Šele zdaj START/)
    expect(s.join(' ')).toMatch(/Forerunner 255 nima zemljevida s cestami/)
    expect(watchSteps(w, 'x', 'y', false)[0]).toMatch(/connect\.garmin\.com/)
  })
  it('kratko ime proge in GPX s tipom kolesarjenje', () => {
    expect(courseName('2026-09-25', 'Sweet spot 3 × 12 min')).toBe('FORMAI 25.9. Sweet spot 3 × 12')
    expect(toGpx('FORMAI', [[46.19, 14.49], [46.2, 14.5]])).toMatch(/<trk><name>FORMAI<\/name><type>cycling<\/type><trkseg>/)
  })
})
