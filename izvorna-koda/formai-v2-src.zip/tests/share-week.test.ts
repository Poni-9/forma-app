import { describe, it, expect } from 'vitest'
import { weekText } from '../src/domain/training/share'
import type { PlanDay } from '../src/domain/types'

const now = '2026-10-02T08:00:00.000Z'
const d = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: 'p' + date + (o.kind || 'kolo'), date, kind: 'kolo', title: 'Z2 vzdržljivost', desc: '', durationMin: 60, zone: 'Z2', tssTarget: 42, role: 'lahka', source: 'rules', createdAt: now, updatedAt: now, ...o })

describe('teden kot besedilo', () => {
  it('en dan v vrstico, dodatne seje s plusom, vati, kljukica, vsota; dnevi brez načrta so počitek; brez osebnih podatkov', () => {
    const t = weekText([
      d('2026-10-06', { title: 'VO2max 4 × 4 min', durationMin: 75, tssTarget: 68, target: { lo: 259, hi: 276 }, done: { at: now } }),
      d('2026-10-06', { kind: 'moc', title: 'Moč — jedro', durationMin: 25, tssTarget: 15, role: 'moc' }),
      d('2026-10-05', { kind: 'pocitek', title: 'Počitek', durationMin: 0, tssTarget: 0, role: null }),
      d('2026-10-10', { title: 'Dolga Z2', durationMin: 180, tssTarget: 127, role: 'dolga' }),
      d('2026-10-11', { title: 'Jedro', kind: 'moc', durationMin: 20, tssTarget: 10, optional: true }),
    ], '2026-10-05')
    const L = t.split('\n')
    expect(L[0]).toBe('FORMAI · teden 5. 10. – 11. 10.')
    expect(L[1]).toBe('pon 5. 10.: počitek')
    expect(L[2]).toBe('tor 6. 10.: VO2max 4 × 4 min · 1 h 15 min · 259–276 W ✓ + Moč — jedro · 25 min')
    expect(L[3]).toBe('sre 7. 10.: počitek')
    expect(L[6]).toBe('sob 10. 10.: Dolga Z2 · 3 h')
    expect(L[7]).toBe('ned 11. 10.: Jedro · 20 min (po želji)')
    expect(L[8]).toBe('Skupaj 4 h 40 min · 210 TSS')
    expect(t).not.toMatch(/kcal|kg|Blaž/)
  })
})
