// v3.50 PLANER: kolesarski planer, ure tedna in sezone, forma (revizija audit50: F-B, F-H, F-E).
import { describe, it, expect } from 'vitest'
import {
  buildWeek, weekContext, macroWeeks, planHours, plannedMacro, realityCap, storedBikeHours, weekBikeMinutes, forecastForm, zoneMinutes, hikeSwap,
  phaseDescFor, defaultZ2, FRANJA_2027,
} from '../src/domain/training/planner'
import { raceMinutes } from '../src/domain/training/season'
import { unsickify, BACK_TITLE } from '../src/domain/training/sick'
import { addDays, formSeries } from '../src/domain/training/load'
import { zoneText } from '../src/domain/training/zones'
import { rideFuel } from '../src/domain/nutrition/dayplan'
import type { Activity, PlanDay, Profile, Race } from '../src/domain/types'

const NOW = '2026-10-17T08:00:00.000Z'
const T = '2026-10-17'                                     // sobota; tekoči teden od 12. 10.
/** Blaž: Franja, 11 h, brez merilnika, LTHR 184, moč doma 2×, načrt od 21. 9. */
const P = (o: Partial<Profile> = {}): Profile => ({
  name: 'B', sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, ftpDate: '2026-09-20', maxHr: 195, restHr: 48, lthr: 184, level: 3,
  gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, hoursPerWeek: 11, hoursMode: 'own',
  strength: { on: true, equipment: 'home' }, strengthDays: 2, goal: 'dirka', deficit: 400, neat: 1.4, proteinGkg: 1.8,
  event: { ...FRANJA_2027 }, races: [], cycleStart: '2026-09-21', onboardingDone: true, createdAt: NOW, updatedAt: NOW, ...o,
} as Profile)
const U23 = (o: Partial<Profile> = {}) => P({ age: 20, ftp: 330, weightKg: 70, hoursPerWeek: 15, level: 4, gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: true }, strength: { on: true, equipment: 'gym' }, ...o })
/** začetnik: raven 1, 4 h, brez FTP in brez utripa, brez cilja */
const NOV = P({ level: 1, hoursPerWeek: 4, ftp: null, ftpDate: null, lthr: null, maxHr: null, restHr: null, event: null, races: [], cycleStart: '2026-10-19', gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, strength: { on: false, equipment: 'none' }, strengthDays: 0, goal: 'forma', deficit: 0 })
/** ženska 50 let: 6 h, FTP 170, 64 kg, Franja, moč 1×, brez deficita */
/** Franja z vzponom (kot v profilu): ocena 4 h 40 pri ~3 W/kg */
const FR = { ...FRANJA_2027, type: 'maraton' as const, elevM: 1600 }
const ZENA = P({ sex: 'z', age: 50, weightKg: 64, ftp: 170, hoursPerWeek: 6, cycleStart: '2026-10-19', event: { ...FR }, gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true }, strengthDays: 1, deficit: 0 })
const ride = (date: string, min: number, o: Partial<Activity> = {}): Activity => ({ id: `a${date}-${min}-${Math.random().toString(36).slice(2, 6)}`, source: 'manual', sport: 'kolo', date, name: 'x', durationMin: min, tss: Math.round(min * 0.7), aiEligible: true, geoRetain: true, createdAt: NOW, updatedAt: NOW, ...o } as Activity)
/** vožnje tor/čet/sob v tednih od `from` do `to` (ponedeljki), skupaj `h` ur na teden */
const weekly = (from: string, to: string, h: number): Activity[] => {
  const out: Activity[] = []
  for (let ws = from; ws <= to; ws = addDays(ws, 7)) for (const k of [1, 3, 5]) out.push(ride(addDays(ws, k), Math.round((h * 60) / 3)))
  return out
}
const bw = (p: Profile, ws: string, acts: Activity[] = [], today = ws) => buildWeek({ profile: p, activities: acts, weekStart: ws, notBefore: ws, today })
const weeks = (from: string, n: number) => Array.from({ length: n }, (_, k) => addDays(from, 7 * k))
const days = (a: string, b: string) => Math.round((Date.parse(b + 'T12:00:00Z') - Date.parse(a + 'T12:00:00Z')) / 86_400_000)
const race = (o: Partial<Race>): Race => ({ id: 'r' + (o.date || ''), name: 'Tekma', date: '2026-11-15', prio: 'B', ...o } as Race)
const bike = (w: PlanDay[]) => w.filter(d => !d.optional && (d.kind === 'kolo' || d.kind === 'test'))

describe('B01 nedelja: teden, sestavljen »od danes«, ni prazen', () => {
  it('odprta je samo nedelja → nanjo gre najdaljša vožnja tedna, razlaga pove, da se teden začne v ponedeljek', () => {
    const p = P({ hoursPerWeek: 5 })
    const w = buildWeek({ profile: p, activities: [], weekStart: '2026-10-19', notBefore: '2026-10-25', today: '2026-10-25' })
    const sun = w.filter(d => d.date === '2026-10-25')
    const r = sun.find(d => d.kind === 'kolo')!
    expect(r).toBeTruthy()
    expect(r.why).toMatch(/Nedelja: .+ — teden se začne v ponedeljek\./)
    expect(w.filter(d => d.date < '2026-10-25').every(d => d.title === 'Pred začetkom')).toBe(true)
  })
})

describe('B02 + B49 ure tedna iz sestavljenega tedna', () => {
  it('teden v shrambi: planHours in sezona = minute na kolesu tega tedna (brez tekme); drugi tedni po formuli', () => {
    const p = P(), ws = '2026-10-19'
    const w = bw(p, ws).map(d => (d.kind === 'kolo' ? { ...d, durationMin: Math.round(d.durationMin / 2) } : d))
    const exp = Math.round(weekBikeMinutes(w) / 6) / 10
    expect(planHours(p, [], ws, T, w)).toMatchObject({ hours: exp, stored: true })
    const m = plannedMacro(p, [], T, w)
    expect(m.find(x => x.weekStart === ws)!.hours).toBe(exp)
    expect(m.find(x => x.weekStart === '2026-11-09')!.hours).toBe(planHours(p, [], '2026-11-09', T).hours)
    // teden dirke: treningi brez dirke same (prej 4,5 h iz formule ob treningih 3 h 15 in dirki 4 h 40)
    const rw = bw(p, '2027-06-07')
    const tr = storedBikeHours(rw, '2027-06-07')!
    expect(tr).toBe(Math.round(weekBikeMinutes(rw.filter(d => d.role !== 'dirka')) / 6) / 10)
    expect(tr * 60).toBeLessThan(weekBikeMinutes(rw) - 200)
  })
})

describe('B03 razbremenilni teden v sezoni kot sestavljen', () => {
  it('≤ 70 % zadnjega obremenilnega tedna in ±0,5 h od sestavljenega tedna', () => {
    const p = P(), acts = weekly('2026-09-21', '2026-10-05', 3)
    const rec = '2026-11-02'
    expect(weekContext(p, rec).recovery).toBe(true)
    const prev = planHours(p, acts, '2026-10-26', T).hours, h = planHours(p, acts, rec, T).hours
    expect(h).toBeLessThanOrEqual(prev * 0.7 + 0.26)
    expect(Math.abs(weekBikeMinutes(buildWeek({ profile: p, activities: acts, weekStart: rec, notBefore: rec, today: T })) / 60 - h)).toBeLessThanOrEqual(0.5)
  })
})

describe('B06 teden s testom FTP', () => {
  it('dva dni pred testom in dan po njem ni ključnega treninga ali tekme (vsi tedni s testom, doma in v fitnesu)', () => {
    // FTP star: prvi test v 4. tednu (prej: torek VO2max, četrtek test)
    for (const p of [P({ ftpDate: '2026-08-01' }), U23({ ftpDate: '2026-08-01' })]) {
      for (const w of macroWeeks(p, T).filter(x => x.test)) {
        const d = bw(p, w.weekStart), t = d.find(x => x.role === 'test')!
        expect(t, w.weekStart).toBeTruthy()
        for (const k of [-2, -1, 1]) expect(d.some(x => x.date === addDays(t.date, k) && (x.role === 'kljucna' || x.role === 'dirka')), `${w.weekStart} ${k}`).toBe(false)
      }
    }
  })
  it('tekma B v petek tedna s testom: test ni ob VO2max in je vsaj 3 dni pred tekmo (prej tor VO2max, sre test, čet predaktivacija)', () => {
    const p = P({ hoursPerWeek: 7, ftpDate: '2026-08-01', races: [race({ id: 'b', name: 'Kronometer Vodice', date: '2026-10-16', distanceKm: 18, type: 'kronometer' })] })
    expect(weekContext(p, '2026-10-12').test).toBe(true)
    const w = bw(p, '2026-10-12'), t = w.find(d => d.role === 'test')!
    expect(t).toBeTruthy()
    expect(days(t.date, '2026-10-16')).toBeGreaterThanOrEqual(3)
    for (const k of [-1, 1]) expect(w.some(x => x.date === addDays(t.date, k) && (x.role === 'kljucna' || x.role === 'dirka'))).toBe(false)
  })
})

describe('B07 tekma C v nedeljo', () => {
  it('dolga vožnja ostane, teden (z dirko) vsaj 85 % tedna brez tekme', () => {
    const p = P({ hoursPerWeek: 12 }), ws = '2026-11-09'
    const base = bw(p, ws), w = bw({ ...p, races: [race({ id: 'c', name: 'Kriterij', date: '2026-11-15', distanceKm: 40, prio: 'C', type: 'sprint' })] }, ws)
    expect(w.some(d => d.role === 'dolga')).toBe(true)
    expect(weekBikeMinutes(w)).toBeGreaterThanOrEqual(0.85 * weekBikeMinutes(base))
    expect(w.find(d => d.date === '2026-11-14' && d.kind === 'kolo')!.title).not.toMatch(/Predaktivacija/)
  })
})

describe('B08 + B09 + B26 začetnik brez merilnika in utripa', () => {
  const all = weeks('2026-10-19', 12).map(ws => ({ ws, w: bw(NOV, ws) }))
  it('B08 test FTP brez »utripa«: isti odsek, napredek je čas', () => {
    const t = all.flatMap(x => x.w).find(d => d.role === 'test')!
    expect(t.desc).not.toMatch(/povprečni utrip|pražni utrip|Nastavitve/)
    expect(t.desc).toMatch(/odseku/)
  })
  it('B09 prvih 12 tednov brez VO2max (Z5) — tempo in sweet spot', () => {
    expect(all.flatMap(x => x.w).some(d => d.zone === 'Z5' || /VO2max/.test(d.title))).toBe(false)
    expect(all.flatMap(x => x.w).some(d => d.role === 'kljucna' && /^(Tempo|Sweet spot)/.test(d.title))).toBe(true)
  })
  it('B26 brez cilja: razlaga razbremenilnega tedna s testom pove oboje', () => {
    const r = all.find(x => weekContext(NOV, x.ws).recovery)!
    const why = r.w.find(d => d.kind !== 'pocitek' && d.kind !== 'moc')!.why!
    expect(why).toMatch(/razbremenilni teden/)
    expect(why).toMatch(/test FTP/)
  })
})

describe('B10 + B11 dolga vožnja pri malo urah in trajanje dirke po kolesarju', () => {
  it('B11 2,7 W/kg vozi Franjo dlje kot 3,0 W/kg; brez podatkov ostane ocena', () => {
    expect(raceMinutes(FR, { ftp: 170, weightKg: 64 })).toBeGreaterThan(raceMinutes(FR, { ftp: 240, weightKg: 79 }))
    expect(raceMinutes(FR)).toBe(280)
    expect(raceMinutes(FR, { ftp: 240, weightKg: 79 })).toBe(280)
    expect(raceMinutes(FR, { ftp: 400, weightKg: 70 })).toBe(280)     // hitrejši: ocena ostane (gorivo ni premalo)
  })
  it('B10 ženska 6 h: v specifičnem vsaj ena dolga ≥ 70 % dirke, noben teden čez 1,1 × načrt', () => {
    const spec = macroWeeks(ZENA, '2026-10-17').filter(x => x.phase === 'specificno')
    const lw = spec.map(x => ({ x, w: bw(ZENA, x.weekStart) }))
    const longest = Math.max(...lw.flatMap(({ w }) => w.filter(d => d.role === 'dolga').map(d => d.durationMin)))
    expect(longest).toBeGreaterThanOrEqual(0.7 * raceMinutes(FR, ZENA))
    for (const { x, w } of lw) expect(weekBikeMinutes(w.filter(d => d.role !== 'dirka')), x.weekStart).toBeLessThanOrEqual(x.hours * 60 * 1.1 + 1)
    expect(lw.flatMap(({ w }) => w).some(d => /% dirke, ki traja/.test(d.why || ''))).toBe(true)
  })
})

describe('B12 samo trenažer', () => {
  it('opisi treningov brez klancev, skupine, hribov, trase in hitrosti', () => {
    const p = P({ gear: { bikeOutdoor: false, trainer: true, noBike: false, powerMeter: true }, hoursPerWeek: 9 })
    const bad = /klanc|skupin|hrib|km\/h|tras|ravnin/i
    for (const x of macroWeeks(p, T)) {
      for (const d of bike(bw(p, x.weekStart)).filter(d => d.role !== 'dirka')) expect(`${d.title} · ${d.desc}`, x.weekStart).not.toMatch(bad)
    }
  })
})

describe('B13 forma na startu', () => {
  it('teden dirke: napoved zjutraj na dan dirke, brez TSS dirke', () => {
    const w = bw(P(), '2027-06-07')
    const fc = forecastForm([], w, '2027-06-07')!, without = forecastForm([], w.filter(d => d.date < '2027-06-13'), '2027-06-07')!
    expect(fc).toMatchObject({ tsb: without.tsb, ctl: without.ctl, date: '2027-06-13', race: true })
  })
})

describe('B14 + B36 po glavnem cilju', () => {
  it('B14 »Po dirki · teden 1/2«, ne »teden 39/38«', () => {
    expect(weekContext(P(), '2027-06-14')).toMatchObject({ phase: 'po', week: 1, total: 2 })
    expect(weekContext(P(), '2027-06-21')).toMatchObject({ phase: 'po', week: 2, total: 2 })
  })
  it('B36 brez off-seasona: po dveh tednih »po« lahki tedni brez VO2max, ure ≤ 1,25 × teden »po«', () => {
    const p = P(), po = weekContext(p, '2027-06-21').hours
    for (const ws of ['2027-06-28', '2027-07-05', '2027-07-12']) {
      expect(bw(p, ws).some(d => d.zone === 'Z5' || d.role === 'test'), ws).toBe(false)
      expect(weekContext(p, ws).easy).toBeGreaterThan(0)
    }
    expect(weekContext(p, '2027-06-28').hours).toBeLessThanOrEqual(po * 1.25)
  })
})

describe('B15 regeneracija po tekmi', () => {
  it('sobota po tekmi B v petek: »po tekmi«, ne »pred vikendom«', () => {
    const w = bw(P({ races: [race({ date: '2026-11-13', name: 'Kronometer', distanceKm: 20, type: 'kronometer' })] }), '2026-11-09')
    const sat = w.find(d => d.date === '2026-11-14' && d.kind === 'kolo')!
    expect(sat.role).toBe('regen')
    expect(sat.why).toMatch(/po tekmi/)
    expect(sat.why).not.toMatch(/pred vikendom/)
  })
})

describe('B27 moč za noge ne ob testu FTP', () => {
  it('na dan testa in dan pred njim ni moči za noge (doma 2×, fitnes, ženska 1×)', () => {
    for (const p of [P(), U23(), ZENA]) {
      for (const x of macroWeeks(p, T).filter(c => c.test)) {
        const w = bw(p, x.weekStart), t = w.find(d => d.role === 'test')!
        expect(w.some(d => d.kind === 'moc' && /noge|Fitnes/.test(d.title) && (d.date === t.date || d.date === addDays(t.date, -1))), x.weekStart).toBe(false)
      }
    }
  })
})

describe('B30 hribi namesto kolesa', () => {
  it('enak aerobni učinek = enak TSS kot zamenjana vožnja', () => {
    const d = bw(P(), '2026-11-09').find(x => x.role === 'dolga')!
    expect(hikeSwap(d, P()).tssTarget).toBe(d.tssTarget)
  })
})

describe('B37 + H26 po lahkem začetku', () => {
  it('B37 za tremi lahkimi tedni vsaj dva tedna bloka pred razbremenilnim (vsi začetki v 4 tednih)', () => {
    for (const cs of weeks('2026-09-21', 4)) {
      const m = macroWeeks(P({ cycleStart: cs }), cs)
      const e3 = m.findIndex(w => w.easy === 3), r = m.findIndex((w, i) => i > e3 && w.recovery)
      expect(r - e3 - 1, cs).toBeGreaterThanOrEqual(2)
    }
  })
  it('H26 3. teden lahkega začetka ni razbremenilni (U23 15 h: prej 9 → 6 h)', () => {
    for (const cs of weeks('2026-10-19', 4)) {
      const c = weekContext(U23({ cycleStart: cs }), addDays(cs, 14))
      expect(c.easy, cs).toBe(3)
      expect(c.recovery, cs).toBe(false)
    }
  })
})

describe('B38 + B39 + B45 ure iz resnice', () => {
  it('B38 teden po razbremenilnem največ ~10 % nad zadnjim obremenilnim (prej 7,5 → 5,5 → 9 h)', () => {
    const p = P(), m = plannedMacro(p, weekly('2026-09-21', '2026-10-05', 3.5), T)
    const load = (w: typeof m[number]) => !w.recovery && !['prehod', 'po', 'tapering', 'dirka'].includes(w.phase)
    let n = 0
    for (let i = 1; i + 1 < m.length; i++) {
      if (!m[i]!.recovery || !load(m[i - 1]!) || !load(m[i + 1]!) || m[i - 1]!.weekStart < '2026-10-12') continue
      expect(m[i + 1]!.hours, m[i + 1]!.weekStart).toBeLessThanOrEqual(m[i - 1]!.hours * 1.1 + 0.5)   // ure na 0,5 h
      n++
    }
    expect(n).toBeGreaterThan(3)
  })
  it('B39 U23 s 15 h po 4 tednih brez voženj začne pri polovici (≥ 7 h), ne pri 4 h; razlaga s številko', () => {
    const u = U23({ cycleStart: '2026-08-31' }), acts = weekly('2026-08-31', '2026-09-21', 15)
    expect(planHours(u, acts, '2026-10-26', '2026-10-26').hours).toBeGreaterThanOrEqual(7)
    const w = buildWeek({ profile: u, activities: acts, weekStart: '2026-10-26', notBefore: '2026-10-26', today: '2026-10-26' })
    expect(w.some(d => /polovica tega, kar si vozil prej/.test(d.why || ''))).toBe(true)
    // dolg premor (8+ tednov): kot prej 4 h
    expect(realityCap(acts, '2026-12-07', '2026-12-07')).toMatchObject({ cap: 4, base: 0 })
  })
  it('B45 po premoru razlaga ne obljublja »intenzivnost pride v 4. tednu«', () => {
    const acts = weekly('2026-03-02', '2026-09-07', 5)
    const w = buildWeek({ profile: P({ cycleStart: '2026-03-02' }), activities: acts, weekStart: '2026-10-26', notBefore: '2026-10-26', today: '2026-10-26' })
    const why = w.map(d => d.why || '').join(' ')
    expect(why).toMatch(/brez intervalov/)
    expect(why).not.toMatch(/4\. tednu/)
  })
})

describe('B40 po bolezni', () => {
  const key: PlanDay = { id: 'k', date: '2026-10-29', kind: 'kolo', title: 'Sweet spot na ravnini 3 × 12 min', desc: '3 × 12 min.', durationMin: 90, zone: 'Z3', tssTarget: 81, role: 'kljucna', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null } as PlanDay
  const rest: PlanDay = { ...key, kind: 'pocitek', title: 'Počitek — bolezen', durationMin: 0, zone: null, tssTarget: 0, role: null, sickPrev: [key] } as PlanDay
  it('»Spet zdrav« po 3+ dneh: prvi dan nazaj lahka Z2 do 60 min; razveljavitev in kratka bolezen vrneta original', () => {
    const back = unsickify([rest], '2026-10-29', NOW, '2026-10-26')[0]!
    expect(back.role).toBe('lahka'); expect(back.title).toBe(BACK_TITLE); expect(back.durationMin).toBeLessThanOrEqual(60); expect(back.id).toBe('k')
    expect(unsickify([rest], '2026-10-29', NOW)[0]!.role).toBe('kljucna')
    expect(unsickify([rest], '2026-10-29', NOW, '2026-10-28')[0]!.role).toBe('kljucna')
  })
})

describe('B42 opis faze po kolesarju', () => {
  it('moč 1×, brez deficita: brez »moč 2×« in »teža dol«; začetnik v gradnji sweet spot, ne prag', () => {
    const d = weekContext(ZENA, '2026-11-09').phaseDesc
    expect(d).toMatch(/moč 1×/)
    expect(d).not.toMatch(/2×|teža dol/)
    expect(phaseDescFor({ strength: { on: false } as Profile['strength'], strengthDays: 0, deficit: 0, level: 1 }, 'gradnja', 9)).toMatch(/sweet spot/)
    expect(phaseDescFor({ strength: { on: false } as Profile['strength'], strengthDays: 0, deficit: 0, level: 1 }, 'gradnja', 9)).not.toMatch(/prag 3 × 15|moč/)
    expect(weekContext(P(), '2026-11-09').phaseDesc).toMatch(/moč 2×.*Tu gre teža dol/)
  })
})

describe('B43 gorivo v opisu = Gorivo', () => {
  it('dolge vožnje: g OH na uro v opisu kot rideFuel za ta dan (tudi skrajšane)', () => {
    let n = 0
    for (const x of macroWeeks(P(), T)) {
      for (const d of bw(P(), x.weekStart).filter(d => d.role === 'dolga' && d.kind === 'kolo')) {
        const m = /~(\d+) g (?:ogljikovih hidratov|OH) na uro/.exec(d.desc)
        expect(m, `${d.date} ${d.title}`).not.toBeNull()
        expect(+m![1]!, `${d.date} ${d.title} ${d.durationMin}`).toBe(rideFuel(d)!.gph)
        n++
      }
    }
    expect(n).toBeGreaterThan(20)
  })
})

describe('B44 cone tedna iz korakov', () => {
  const p = P({ gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: true } })
  const gr = macroWeeks(p, T).filter(x => x.phase === 'gradnja').map(x => bw(p, x.weekStart)).flat()
  it('»Dolga Z2 + tempo« ima 30 min Z3; 30/15 ~20 min trdo (prej 0 in 36)', () => {
    const long = gr.find(d => d.title === 'Dolga Z2 + tempo')!
    expect(zoneMinutes([long], p).Z3).toBe(30)
    const t = gr.find(d => d.title.startsWith('30/15'))!
    const z = zoneMinutes([t], p)
    expect(z.Z4 + z.Z5).toBeLessThanOrEqual(25)
    expect(z.Z4 + z.Z5).toBeGreaterThanOrEqual(18)
    const all = zoneMinutes([long, t])
    expect(Math.abs(all.Z1 + all.Z2 + all.Z3 + all.Z4 + all.Z5 - long.durationMin - t.durationMin)).toBeLessThanOrEqual(2)
  })
})

describe('B50 privzeti »Dodaj trening«', () => {
  it('Z2 iz iste predloge kot načrt (cona v utripu, kadenca 90+)', () => {
    const d = defaultZ2(P(), 60)
    expect(d.desc).toContain(zoneText(P(), 'Z2'))
    expect(d.desc).toMatch(/kadenca 90\+/)
    expect(d).toMatchObject({ kind: 'kolo', durationMin: 60, zone: 'Z2', role: 'lahka' })
  })
})

describe('H09 dogovor brez ene vadbe', () => {
  it('kolesar po dogovoru, ki še ni začel: 4. teden brez intervalov in testa, razlaga pove zakaj', () => {
    const focus = { v: 1, mode: 'kolo', wish: 'x', sports: ['kolo'], aims: ['tekma'], muscles: [], days: 3, minutes: 60, level: 2, equipment: ['nic'], limits: null, title: 'Kondicija', sessions: [{ type: 'kolo', cardio: 'lahko', min: 60 }], notes: [], offDays: [], at: NOW, by: 'rules' }
    const p = P({ focus: focus as unknown as Profile['focus'], event: null, goal: 'forma', hoursPerWeek: 6 })
    for (const ws of ['2026-10-12', '2026-10-19', '2026-10-26']) {
      const w = buildWeek({ profile: p, activities: [], weekStart: ws, notBefore: ws, today: addDays(ws, -1) })
      if (weekContext(p, ws).recovery) continue
      expect(w.some(d => d.zone === 'Z4' || d.zone === 'Z5' || d.role === 'test'), ws).toBe(false)
      expect(w.some(d => /Ker še nisi začel/.test(d.why || '')), ws).toBe(true)
    }
  })
})

describe('H22 polnjenje OH z imenom tekme', () => {
  it('dan polnjenja pove, pred katero tekmo (tekma B in cilj sezone)', () => {
    const w = bw(P({ races: [race({ name: 'VN Vodice', date: '2026-11-15', distanceKm: 100, type: 'cestna' })] }), '2026-11-09')
    expect(w.find(d => d.date === '2026-11-13')!.desc).toMatch(/Polnjenje OH pred tekmo VN Vodice: danes in jutri 8–10 g/)
    expect(bw(P(), '2027-06-07').find(d => d.date === '2027-06-11')!.desc).toMatch(/pred tekmo Maraton Franja/)
  })
})

describe('E03 + E20 forma', () => {
  it('E03 ena vožnja 80 TSS ni »kondicija 80«', () => {
    expect(formSeries([ride(T, 90, { tss: 80 })], T).at(-1)!.ctl).toBeLessThan(5)
  })
  it('E20 vnos 5000 TSS šteje največ 150 na uro (60 min) in nikoli več kot 600', () => {
    const s = formSeries([ride(addDays(T, -1), 60, { tss: 5000 })], T)
    expect(Math.max(...s.map(x => x.tss))).toBeLessThanOrEqual(150)
    expect(Math.max(...formSeries([ride(addDays(T, -1), 1440, { tss: 1008 })], T).map(x => x.tss))).toBe(600)
  })
})
