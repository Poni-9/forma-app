// v3.49 VADBA — vodena vadba in tekme: tempo kronometra in drugih tekem (A11), over-under izmenično pod in nad pragom
// (A13, tudi na uri in v .zwo), klanci v dolgi vožnji (A32), »Začni trening« na dnu (A28), olajšan dan z gumbom (A35),
// konec v ozadju šteje vse korake (A36), manj dela med vožnjo (D01), nadaljevanje po zaprtju aplikacije (D02), pravilo
// »brez merilnika« tudi za AI (N1).
import { act, Profiler, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { readFileSync } from 'node:fs'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'vadba', params: {} as Record<string, string> } }))
vi.mock('@/state/store', async () => {
  const { vi: v } = await import('vitest')
  const base: Record<string | symbol, unknown> = {
    useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
    getState: () => S.state,
    routePace: () => ({ k: 1, adj: { n: 0, adj: 1 } }),
  }
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' || typeof k === 'symbol' ? undefined : (t[k] = v.fn(async () => ({ added: 1, dupes: 0, upgraded: 0 })))), has: (_t, k) => k !== 'then' })
})
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => S.route }))

import * as store from '@/state/store'
import { Vadba, RUN_KEY, FIG_PLAY_MS, type Run } from '@/screens/Vadba'
import { runningDayId, savedRun, saveRunCopy, watchRunCopy, pillDay, pillLabel, RUN_SAVED_KEY, RUN_SAVED_MAX_MS, RUN_KEY_SHARED } from '@/ui/runState'
import { buildWeek, FRANJA_2027 } from '@/domain/training/planner'
import { stepsFor, structureLines, totalSec, raceTarget, minMinutes } from '@/domain/training/workout'
import { icuWorkout } from '@/domain/intervals/workouts'
import { zwoFor } from '@/domain/training/zwo'
import { addDays } from '@/domain/training/load'
import { planPayload, type PlanCtx } from '@/domain/ai/claudePlan'
import { realitySummary } from '@/domain/training/review'
import type { PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-17'
const NOW = `${TODAY}T08:00:00.000Z`
/** Blaž: Franja, brez merilnika moči, LTHR 184 (pm = true: z merilnikom, FTP 240) */
const bike = (pm: boolean, o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, ftpDate: '2026-09-14', maxHr: 195, restHr: 50, lthr: 184,
  gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: pm }, strength: { on: false, equipment: 'none' },
  hoursPerWeek: 11, goal: 'dirka', deficit: 400, onboardingDone: true, event: { ...FRANJA_2027 }, cycleStart: '2026-09-21',
  goalStart: { date: '2026-09-22', ftp: 240, weightKg: 79 }, createdAt: NOW, updatedAt: NOW, ...o,
} as Profile)
/** prvi dan v naslednjih 40 tednih, ki ustreza pogoju */
function findDay(p: Profile, ok: (d: PlanDay) => boolean): PlanDay {
  for (let k = 0; k < 40; k++) {
    const d = buildWeek({ profile: p, activities: [], weekStart: addDays('2026-09-21', 7 * k), notBefore: '2026-01-01' }).find(ok)
    if (d) return d
  }
  throw new Error('ni dneva')
}

describe('A11 tempo na tekmi: kronometer, vzpon, klanci', () => {
  const tt = { id: 'r1', name: 'Kronometer Vodice', date: '2026-10-23', distanceKm: 18, prio: 'B' as const, type: 'kronometer' as const }
  const race = (p: Profile) => buildWeek({ profile: p, activities: [], weekStart: '2026-10-19', notBefore: '2026-01-01' }).find(d => d.role === 'dirka')!
  it('kronometer 18 km brez merilnika: utrip iz LTHR (prvih 5 min, nato malo nad pragom), brez vatov; vodena vadba isto', () => {
    const d = race(bike(false, { races: [tt] }))
    expect(d.title).toBe('Kronometer Vodice — 18 km')
    expect(d.desc).toContain('Prvih 5 min pri utripu 178–184 (ne prehitro), nato pri utripu 184–188, zadnje 3 min vse.')
    expect(d.desc).not.toMatch(/\d\s?W\b/)
    const st = stepsFor(d, bike(false, { races: [tt] }))
    expect(st.find(s => s.label === 'Tekma')!.target).toBe('utrip 184–188')
  })
  it('kronometer z merilnikom: vati in cilj dneva = glavni del (240–252 W pri FTP 240)', () => {
    const p = bike(true, { races: [tt] })
    const d = race(p)
    expect(d.desc).toContain('Prvih 5 min 228–240 W (ne prehitro), nato 240–252 W, zadnje 3 min vse.')
    expect(d.target).toEqual({ lo: 240, hi: 252 })
    expect(stepsFor(d, p).find(s => s.label === 'Tekma')!.target).toBe('240–252 W')
  })
  it('daljši kronometer (cilj sezone 40 km): na pragu; brez LTHR in merilnika po občutku', () => {
    const p = bike(false, { event: { name: 'Kronometer Ljubljana', date: '2027-06-13', distanceKm: 40 } as Profile['event'] })
    const d = buildWeek({ profile: p, activities: [], weekStart: '2027-06-07', notBefore: '2026-01-01' }).find(x => x.role === 'dirka')!
    expect(d.durationMin).toBeGreaterThanOrEqual(40)
    expect(d.desc).toContain('nato na pragu (utrip 172–184), zadnjih 5 min vse.')
    expect(raceTarget(d.desc)).toBe('utrip 172–184')
    const q = bike(false, { lthr: null, maxHr: null, restHr: null, races: [tt] } as Partial<Profile>)
    expect(race(q).desc).toContain('nato RPE 9, zadnje 3 min vse.')
  })
  it('vzpon in klanci brez merilnika: prag v utripu; z merilnikom cilj za vodeno vadbo', () => {
    const climb = { ...tt, name: 'Vzpon na Krvavec', type: 'vzpon' as const, distanceKm: 12 }
    const hills = { ...tt, name: 'Dirka po hribih', type: 'klanci' as const, distanceKm: 80 }
    expect(race(bike(false, { races: [climb] })).desc).toContain('prvih 5 min ne prehitro (utrip 172–184)')
    expect(race(bike(false, { races: [hills] })).desc).toContain('Na klancih enakomerno na pragu (utrip 172–184)')
    expect(race(bike(true, { races: [climb] })).target).toEqual({ lo: 228, hi: 240 })
  })
})

describe('A13 over-under: pod in nad pragom izmenično (vodena vadba, ura, .zwo)', () => {
  const ou = (pm: boolean) => findDay(bike(pm), d => /^Over-under/.test(d.title))
  it('z merilnikom: 3 serije × 3 × (2 min pod + 1 min nad pragom), vmes 5 min; trajanje kot v načrtu', () => {
    const p = bike(true), d = ou(true), st = stepsFor(d, p)
    const under = st.filter(s => /^Pod pragom/.test(s.label)), over = st.filter(s => /^Nad pragom/.test(s.label))
    expect(under).toHaveLength(9); expect(over).toHaveLength(9)
    expect(new Set(st.filter(s => s.kind === 'delo').map(s => s.target))).toEqual(new Set(['223–233 W', '247–257 W']))
    expect(under.every(s => s.sec === 120) && over.every(s => s.sec === 60)).toBe(true)
    // takoj za vsakim »pod« pride »nad« (brez odmora)
    st.forEach((s, i) => { if (/^Pod pragom/.test(s.label)) expect(st[i + 1]!.label).toMatch(/^Nad pragom/) })
    expect(st.filter(s => s.label === 'Med serijami').map(s => s.sec)).toEqual([300, 300])
    expect(totalSec(st)).toBe(d.durationMin * 60)
    expect(structureLines(st)).toContain('3 serije × 3 × (2 min pri 223–233 W + 1 min pri 247–257 W); med serijami 5 min lahko')
    expect(minMinutes(d)).toBe(50)
  })
  it('na uri (intervals.icu) in v .zwo: blok s pod in nad pragom', () => {
    const p = bike(true), d = ou(true)
    const w = icuWorkout(d, p)!
    expect(w.description).toContain('Pod in nad pragom 3x\n- 2m 223-233w\n- 1m 247-257w')
    expect(w.movingTime).toBe(d.durationMin * 60)
    expect(zwoFor(d, p)!.xml).toContain('<IntervalsT Repeat="3" OnDuration="120" OffDuration="60" OnPower="0.95" OffPower="1.05">')
  })
  it('brez merilnika: po občutku (utrip pri 1-min menjavah zaostaja); star opis (shranjen teden) se tudi izmenjuje', () => {
    const st = stepsFor(ou(false), bike(false))
    expect(st.find(s => /^Pod pragom/.test(s.label))!.target).toBe('tik pod pragom · RPE 7')
    expect(st.find(s => /^Nad pragom/.test(s.label))!.target).toBe('malo nad pragom · RPE 8–9')
    const old = { ...ou(true), desc: '20 min ogrevanje s 3 kratkimi pospeški · 3 × 9 min pri 228–252 W (95–105 % FTP), vmes 5 min lahko · nato 35 min Z2 (134–180 W) · 13 min iztek. Vsak interval 3 × (2 min pri 95 % + 1 min pri 105 % FTP) — pospeški nad pragom in okrevanje na pragu, kot na dirki.' }
    const so = stepsFor(old, bike(true))
    expect(so.filter(s => s.kind === 'delo').map(s => s.target).slice(0, 2)).toEqual(['228 W', '252 W'])
    expect(so.filter(s => s.kind === 'delo')).toHaveLength(18)
  })
  it('»+« z lahkim drugim delom (tek in hoja) ostane delo in odmor — ni over-under', () => {
    const run: PlanDay = { id: 't', date: TODAY, kind: 'tek', title: 'Tek in hoja', desc: '10 min lahkega teka, nato 6 × (2 min tek + 1 min hoja). 5 min lahko na koncu.', durationMin: 35, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW }
    const st = stepsFor(run, bike(false))
    expect(st.some(s => /pragom/.test(s.label))).toBe(false)
    expect(st.filter(s => s.label === 'Hoja').map(s => s.sec)).toEqual([60, 60, 60, 60, 60])
  })
})

describe('A32 dolga vožnja s klanci', () => {
  const vz = { name: 'Vzpon na Vršič', date: '2027-06-13', distanceKm: 120, elevM: 2500, type: 'vzpon' } as unknown as Profile['event']
  const kl = { name: 'Dirka po hribih', date: '2027-06-13', distanceKm: 140, elevM: 2600, type: 'klanci' } as unknown as Profile['event']
  it('»Dolga + 3 dolgi klanci«: 3 × 15 min na klancu, vmes 25 min Z2 (prej 3 h enakomerne Z2)', () => {
    const p = bike(false, { event: vz }), d = findDay(p, x => x.title === 'Dolga + 3 dolgi klanci')
    const st = stepsFor(d, p)
    const climbs = st.filter(s => /^Klanec/.test(s.label))
    expect(climbs.map(s => s.sec)).toEqual([900, 900, 900])
    expect(climbs[0]!.target).toBe('utrip 165–171')
    expect(st.filter(s => s.kind === 'lahko' && s.sec === 1500)).toHaveLength(2)
    expect(totalSec(st)).toBe(d.durationMin * 60)
  })
  it('»Dolga razgibana«: navodilo za klance v koraku Z2', () => {
    const p = bike(true, { event: kl }), d = findDay(p, x => x.title === 'Dolga razgibana')
    const main = stepsFor(d, p).find(s => s.kind === 'delo')!
    expect(main.note).toMatch(/^Vse klance v tempu 204–228 W \(85–95 % FTP\), na vrhu 15 s pospešek čez rob\. RPE 3–4/)
  })
})

describe('A35 olajšan dan: gumb »Začni (po želji)«', () => {
  const d = (o: Partial<PlanDay>): PlanDay => ({ id: 'x', date: TODAY, kind: 'kolo', title: 'Lahek dan — Z1', desc: '', durationMin: 40, zone: 'Z1', role: 'regen', optional: true, source: 'rules', createdAt: NOW, updatedAt: NOW, ...o } as PlanDay)
  it('neobvezna vožnja ali tek, ko ni druge seje; glavni trening ima prednost; sprehod in opravljen dan ne', () => {
    expect(pillDay([d({})], TODAY)?.id).toBe('x')
    expect(pillDay([d({}), d({ id: 'm', kind: 'moc', optional: false, title: 'Moč' })], TODAY)?.id).toBe('m')
    expect(pillDay([d({ kind: 'pohod' })], TODAY)).toBeUndefined()
    expect(pillDay([d({ done: { at: NOW } })], TODAY)).toBeUndefined()
    // (v3.50) napis gumba je v pillLabel (A30/A44)
    expect(pillLabel({ kind: 'kolo', optional: true })).toBe('Začni (po želji)')
    expect(readFileSync('src/app/App.tsx', 'utf8')).toContain('pillLabel(today,')
  })
})

describe('N1 »brez merilnika« tudi za AI (noPower)', () => {
  const ctx = (gear: Profile['gear'], ftp: number | null): PlanCtx => ({
    today: TODAY, profile: { sex: 'm', age: 30, gear, ftp, strength: { on: false, equipment: 'none' }, onboardingDone: true, createdAt: NOW, updatedAt: NOW } as unknown as Profile,
    basics: { sex: 'm', age: 30, heightCm: 180, weightKg: 80, avail: [1, 3, 5], trainTime: 'zvecer', push: 'zmerno', main: 'kardio' }, picks: {}, text: '', wish: 'kolo', qa: [], activities: [], plan: [], checkins: [],
  })
  const kolo = (c: PlanCtx) => (planPayload(c).uporabnik as { kolo: { merilnik_moci: unknown } }).kolo.merilnik_moci
  const g = (pm?: boolean | null) => ({ bikeOutdoor: true, trainer: false, noBike: false, ...(pm === undefined ? {} : { powerMeter: pm }) })
  it('Claude trener: star profil brez izbire in brez FTP → brez merilnika (prej null); z znanim FTP vati', () => {
    expect(kolo(ctx(g(), null))).toBe(false)
    expect(kolo(ctx(g(null), null))).toBe(false)
    expect(kolo(ctx(g(null), 250))).toBe(true)
    expect(kolo(ctx(g(true), null))).toBe(true)
    expect(kolo(ctx(g(false), 250))).toBe(false)
  })
  it('trening v resnici: »Nima merilnika« tudi pri null brez FTP', () => {
    expect(realitySummary({ hoursPerWeek: 8, gear: g(null), ftp: null }, [], [], TODAY).join(' ')).toMatch(/Nima merilnika moči/)
    expect(realitySummary({ hoursPerWeek: 8, gear: g(null), ftp: 250 }, [], [], TODAY).join(' ')).not.toMatch(/Nima merilnika/)
  })
})

describe('D02 kopija tekoče vadbe (runState)', () => {
  beforeEach(() => { sessionStorage.clear(); localStorage.clear() })
  const run = (o: Record<string, unknown> = {}) => ({ v: 1, dayId: 'd1', i: 1, finished: false, ...o })
  it('po »novi seji« (prazen sessionStorage) vrne kopijo; starejšo od 12 h in končano zavrže', () => {
    const t = Date.parse(NOW)
    saveRunCopy(run(), t)
    expect(savedRun(t + 60_000)?.dayId).toBe('d1')
    expect(runningDayId(t + 60_000)).toBe('d1')
    expect(savedRun(t + RUN_SAVED_MAX_MS + 1)).toBeNull()
    expect(localStorage.getItem(RUN_SAVED_KEY)).toBeNull()
    saveRunCopy(run({ finished: true }), t)
    expect(savedRun(t)).toBeNull()
    // vadba v tem zavihku ima prednost: končana tu pomeni, da ni kaj nadaljevati
    saveRunCopy(run(), t)
    sessionStorage.setItem(RUN_KEY_SHARED, JSON.stringify(run({ finished: true })))
    expect(runningDayId(t)).toBeNull()
  })
  it('ko gre aplikacija v ozadje, gre kopija iz sessionStorage v localStorage', () => {
    const stop = watchRunCopy()
    sessionStorage.setItem(RUN_KEY_SHARED, JSON.stringify(run({ i: 2 })))
    Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => 'hidden' })
    document.dispatchEvent(new Event('visibilitychange'))
    stop()
    delete (document as { visibilityState?: unknown }).visibilityState   // nazaj na brskalnikovo (prototip)
    const c = JSON.parse(localStorage.getItem(RUN_SAVED_KEY) || 'null')
    expect(c).toMatchObject({ dayId: 'd1', i: 2 })
    expect(typeof c.savedAt).toBe('number')
  })
})

/* ---------------------------------- zaslon vodene vadbe ---------------------------------- */
const P = { sex: 'm', age: 35, heightCm: 180, weightKg: 75, ftp: 250, ftpDate: '2026-09-01', gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true }, strength: { on: false, equipment: 'none' }, onboardingDone: true, hoursPerWeek: 8, goal: 'forma', createdAt: NOW, updatedAt: NOW } as unknown as Profile
const ride: PlanDay = { id: 'd1', date: TODAY, kind: 'kolo', title: 'Z2 vožnja', desc: 'Enakomerno v Z2.', durationMin: 60, zone: 'Z2', role: 'lahka', tssTarget: 42, source: 'rules', createdAt: NOW, updatedAt: NOW }
const gym: PlanDay = { id: 'm1', date: TODAY, kind: 'moc', title: 'Moč — noge', desc: 'Noge.', durationMin: 40, zone: null, role: 'moc', exercises: [{ name: 'Goblet počep', sets: 3, reps: '8', kg: 30 }], source: 'rules', createdAt: NOW, updatedAt: NOW }
const reset = (plan: PlanDay[]) => {
  S.state = { ready: true, today: TODAY, plan, activities: [], recentMeals: [], mealsToday: [], checkins: [], weather: null, routeLib: null, routesBusy: false, settings: { lang: 'sl', intervals: null }, toast: null, profile: P, user: null, changes: [], sync: { state: 'ok' } }
}
const fn = (k: string) => (store as unknown as Record<string, ReturnType<typeof vi.fn>>)[k]!
let div: HTMLDivElement | null = null, root: Root | null = null
async function render(el: ReactElement) {
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root!.render(el) })
  return div
}
const sp = (x: string | null | undefined) => (x || '').replace(/[  ⁠]/g, ' ')
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(sp(b.textContent))) as HTMLButtonElement | undefined
const tick = async (ms: number) => { await act(async () => { vi.advanceTimersByTime(ms) }) }
const flush = async () => { for (let i = 0; i < 6; i++) await act(async () => { await Promise.resolve() }) }
const open = async (day: PlanDay, el: ReactElement = <Vadba />) => { S.route = { name: 'vadba', params: { id: day.id } }; return render(el) }
/** kopija vadbe, kot jo pusti zaprta aplikacija: korak i, čas do prekinitve el (s), kopija pred `ago` ms */
function copyOf(day: PlanDay, i: number, el: number, ago: number, o: Partial<Run> = {}) {
  const steps = stepsFor(day, P)
  const stepAt = steps.slice(0, i).reduce((t, s) => t + s.sec, 0) * 1000
  const savedAt = Date.now() - ago
  const r = { v: 1, dayId: day.id, day, steps, i, stepAt, acc: el * 1000 - 60_000, runFrom: savedAt - 60_000, cues: [], cue: null, finished: false, saved: false, ...o }
  localStorage.setItem(RUN_SAVED_KEY, JSON.stringify({ ...r, savedAt }))
  return steps
}

describe('Vadba (zaslon)', () => {
  beforeEach(() => {
    vi.useFakeTimers(); vi.setSystemTime(new Date(`${TODAY}T10:00:00`)); sessionStorage.clear(); localStorage.clear(); S.subs.clear()
    fn('setPlanDone').mockClear(); fn('addActivities').mockClear()
  })
  afterEach(async () => { if (root) { await act(async () => root!.unmount()); root = null } div?.remove(); document.body.innerHTML = ''; vi.unstubAllGlobals(); vi.useRealTimers() })

  it('A28: »Začni trening« je v lepljivi vrstici na dnu (pod pregledom)', async () => {
    reset([ride])
    await open(ride)
    const b = btn(/^Začni trening$/)!
    expect(b.parentElement!.className).toBe('run-start')
    expect(readFileSync('src/styles/base.css', 'utf8')).toMatch(/\.run-start \{ position: sticky; bottom: 0;/)
  })

  it('A36: konec v ozadju (zaklenjen telefon) — »Opravljeno« z vsemi koraki, ne »1 od 3«', async () => {
    reset([ride])
    const steps = stepsFor(ride, P)
    await open(ride)
    await act(async () => { btn(/^Začni trening$/)!.click() })
    vi.setSystemTime(Date.now() + (totalSec(steps) + 60) * 1000)
    await tick(250); await flush()
    expect(div!.textContent).toContain('Opravljeno')
    expect(div!.textContent).not.toMatch(/1 od \d+ korakov/)
    expect(JSON.parse(sessionStorage.getItem(RUN_KEY)!).i).toBe(steps.length - 1)
    expect(fn('setPlanDone')).toHaveBeenCalledWith('d1', true, null, 60)
  })

  it('D01: med vožnjo izris 1× na sekundo (prej 4×)', async () => {
    vi.stubGlobal('requestAnimationFrame', () => 0)   // figura brez sličic — štejemo samo izrise zaslona
    vi.stubGlobal('cancelAnimationFrame', () => undefined)
    reset([ride])
    let commits = 0
    await open(ride, <Profiler id="v" onRender={() => { commits++ }}><Vadba /></Profiler>)
    await act(async () => { btn(/^Začni trening$/)!.click() })
    await tick(1000)
    commits = 0
    for (let k = 0; k < 40; k++) await tick(250)   // vsak tik posebej (act ne združi izrisov)
    expect(commits).toBeGreaterThanOrEqual(9)
    expect(commits).toBeLessThanOrEqual(12)
  })

  it('D01: figura se giblje prvih 8 s koraka, nato miruje (brez sličic)', async () => {
    let raf = 0
    vi.stubGlobal('requestAnimationFrame', (f: (t: number) => void) => { raf++; return setTimeout(() => f(Date.now()), 16) as unknown as number })
    vi.stubGlobal('cancelAnimationFrame', (h: number) => clearTimeout(h))
    reset([ride])
    await open(ride)
    await act(async () => { btn(/^Začni trening$/)!.click() })
    await tick(2000)
    expect(raf).toBeGreaterThan(50)
    await tick(FIG_PLAY_MS)
    raf = 0
    await tick(3000)
    expect(raf).toBe(0)
    expect(document.querySelector('.fig-cardio svg')).toBeTruthy()   // figura ostane, samo miruje
    const css = readFileSync('src/styles/base.css', 'utf8')
    expect(css).not.toMatch(/\.stepring \.fg \{ fill[^}]*transition/)
    expect(css).toContain('.track.run-track i { transition: none; }')
  })

  it('D02: po zaprtju aplikacije »Vadba je bila prekinjena …« → Nadaljuj od prekinitve (čas zaprte aplikacije ne šteje)', async () => {
    reset([ride])
    const steps = copyOf(ride, 1, 20 * 60, 40 * 60_000)
    await open(ride)
    expect(sp(div!.textContent)).toContain('Vadba je bila prekinjena pri 20:00 (korak 2 od 3).')
    expect(btn(/^Začni trening$/)).toBeUndefined()                   // glavni gumb je »Nadaljuj«; spodaj »Začni znova«
    expect(btn(/^Začni znova$/)!.parentElement!.className).toBe('run-start')
    await act(async () => { btn(/^Nadaljuj$/)!.click() })
    expect(div!.textContent).toContain(`2 / ${steps.length}`)
    expect(sp(div!.textContent)).toContain('Skupaj 0:20:00')
    await tick(5000)
    expect(sp(div!.textContent)).toContain('Skupaj 0:20:05')
    expect(JSON.parse(sessionStorage.getItem(RUN_KEY)!).i).toBe(1)
  })

  it('D02: »Shrani, kar si naredil« pri moči zapiše vpisane kg; »Zavrzi« pobriše kopijo; stara (12 h+) in opravljen dan se ne ponudita', async () => {
    reset([gym])
    copyOf(gym, 3, 12 * 60, 60_000, { log: { 1: { kg: 32.5, reps: 8 } }, runFrom: null, acc: 12 * 60_000 })
    await open(gym)
    await act(async () => { btn(/^Shrani, kar si naredil \(12:00\)$/)!.click() })
    await flush()
    expect(fn('addActivities')).toHaveBeenCalledTimes(1)
    const a = (fn('addActivities').mock.calls[0]![0] as { exercises: { kg: number; reps: string }[]; durationMin: number }[])[0]!
    expect(a.exercises[0]).toMatchObject({ kg: 32.5, reps: '8' })
    expect(fn('setPlanDone')).toHaveBeenCalledWith('m1', true, expect.any(String), 12)
    expect(localStorage.getItem(RUN_SAVED_KEY)).toBeNull()
    await act(async () => root!.unmount()); root = null; div!.remove(); sessionStorage.clear()

    reset([ride]); copyOf(ride, 1, 20 * 60, 60_000)
    await open(ride)
    await act(async () => { btn(/^Zavrzi$/)!.click() })
    expect(div!.textContent).not.toContain('prekinjena')
    expect(localStorage.getItem(RUN_SAVED_KEY)).toBeNull()
    await act(async () => root!.unmount()); root = null; div!.remove()

    reset([ride]); copyOf(ride, 1, 20 * 60, RUN_SAVED_MAX_MS + 60_000)
    await open(ride)
    expect(div!.textContent).not.toContain('prekinjena')
    await act(async () => root!.unmount()); root = null; div!.remove()

    reset([{ ...ride, done: { at: NOW } }]); copyOf(ride, 1, 20 * 60, 60_000)
    await open(ride)
    expect(div!.textContent).not.toContain('prekinjena')
    await flush()
    expect(localStorage.getItem(RUN_SAVED_KEY)).toBeNull()
  })
})
