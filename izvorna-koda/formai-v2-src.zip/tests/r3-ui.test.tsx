// Krog 3: vrstica pod obročem za pretekli dan, vnos decimalk z vejico
import { act, useState, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, afterEach, vi } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import { DayBalance } from '../src/screens/Prehrana'
import { DecimalInput } from '../src/ui/primitives'
import { withoutFuelLine } from '../src/ui/format'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
let div: HTMLDivElement, root: Root
async function render(el: ReactElement) {
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root.render(el) })
  return (div.textContent || '').replace(/[  ]/g, ' ')
}
afterEach(async () => { await act(async () => root.unmount()); div.remove() })

describe('Prehrana — vrstica pod obročem', () => {
  it('danes: »Še … kcal · … g beljakovin«; presežene beljakovine niso »0 g«', async () => {
    expect(await render(<DayBalance remaining={303} proteinLeft={20} past={false} logged />)).toBe('Še 303 kcal · 20 g beljakovin')
  })
  it('danes, beljakovine dosežene', async () => {
    expect(await render(<DayBalance remaining={303} proteinLeft={-8} past={false} logged />)).toBe('Še 303 kcal · beljakovine dosežene')
  })
  it('pretekli dan: »pod ciljem«, ne »še«', async () => {
    expect(await render(<DayBalance remaining={303} proteinLeft={12} past logged />)).toBe('303 kcal pod ciljem · 12 g beljakovin manj')
  })
  it('pretekli dan brez vpisov ne kaže primanjkljaja', async () => {
    expect(await render(<DayBalance remaining={2853} proteinLeft={142} past logged={false} />)).toBe('Za ta dan ni vpisanih obrokov')
  })
  it('nad ciljem', async () => {
    expect(await render(<DayBalance remaining={-120} proteinLeft={0} past logged />)).toBe('Nad ciljem za 120 kcal · beljakovine dosežene')
  })
})

describe('DecimalInput', () => {
  function Box({ out }: { out: string[] }) {
    const [v, setV] = useState('79.9')
    return <DecimalInput aria-label="teža" value={v} onChange={e => { out.push(e.target.value); setV(e.target.value) }} />
  }
  const type = async (input: HTMLInputElement, text: string) => {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!
    await act(async () => { setter.call(input, text); input.dispatchEvent(new Event('input', { bubbles: true })) })
  }
  it('kaže vejico, starš dobi piko; črk ne sprejme', async () => {
    const out: string[] = []
    await render(<Box out={out} />)
    const input = div.querySelector('input')!
    expect(input.value).toBe('79,9')
    expect(input.getAttribute('inputmode')).toBe('decimal')
    await type(input, '80,4')
    expect(out.at(-1)).toBe('80.4')
    expect(input.value).toBe('80,4')
    await type(input, '80a')
    expect(out.at(-1)).toBe('80.4')
  })
})

describe('opis treninga brez podvojenega goriva', () => {
  it('odstrani stavek »Gorivo: od 30. minute … piše v Gorivu.«, ostalo ostane', () => {
    const d = 'Enakomerno pogovorni tempo. Gorivo: od 30. minute 50–60 g ogljikovih hidratov na uro in 500–750 ml tekočine na uro — kaj vzeti in kdaj jesti piše v Gorivu. Lahek začetek sezone.'
    expect(withoutFuelLine(d)).toBe('Enakomerno pogovorni tempo. Lahek začetek sezone.')
    expect(withoutFuelLine('Samo Z2.')).toBe('Samo Z2.')
  })
})
