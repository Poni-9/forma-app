import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

/**
 * VAROVALKA: Stravini podatki (Strava API, intervals.icu z izvorom STRAVA, Stravin arhiv, posnetek Strave)
 * ne smejo v AI ne neposredno ne posredno (kljukica »opravljeno« v načrtu, število skritih, izpeljanke v profilu,
 * kcal cilj …). Preizkus: vsak poziv (vsi graditelji in vsa dejanja v src/domain/ai) mora biti ENAK kot za enake
 * podatke brez Strave (primerjava s stanjem, ki ima prav tako eno skrito, a ne-Stravino aktivnost).
 * Poleg tega: podatki z ure (HRV, spanec, mirovni utrip) in ime/kraj nikoli v pozivu; sanitizeGaps na vsem besedilu AI.
 */
const h = vi.hoisted(() => ({ calls: [] as string[], text: 'Dober nasvet.', json: {} as unknown }))
vi.mock('../src/domain/ai/client', () => {
  class AiError extends Error { kind: string; constructor(kind: string, m: string) { super(m); this.kind = kind } }
  const textOf = (parts: { text?: string }[]) => parts.map(p => p.text || '').join('\n')
  return {
    AiError,
    askText: async (parts: { text?: string }[]) => { h.calls.push(textOf(parts)); return h.text },
    askJson: async (parts: { text?: string }[]) => { h.calls.push(textOf(parts)); return JSON.parse(JSON.stringify(h.json)) },
  }
})
vi.mock('../src/domain/ai/image', () => ({ fileToBase64Resized: async () => ({ data: 'AAAA', mime: 'image/jpeg', thumb: 'data:image/jpeg;base64,AAAA' }), exifStamp: async () => null }))

import * as A from '../src/domain/ai/actions'
import { aiContext, coachDailyPrompt, weeklyReviewPrompt, adaptPlanPrompt } from '../src/domain/ai/prompts'
import { personalContext } from '../src/domain/ai/personal'
import { aiSafeView, HIDDEN_NOTE } from '../src/domain/ai/safe'
import { snapOf } from '../src/state/snap'
import { todayIso, addDays, weekStartIso } from '../src/domain/training/load'
import type { AppState } from '../src/state/store'
import type { Activity, PlanDay, Profile } from '../src/domain/types'

const today = todayIso()
const NOW = new Date().toISOString()
const d = (n: number) => addDays(today, n)

const profile: Profile = {
  name: 'Blažko Testni', sex: 'm', age: 30, weightKg: 75, heightCm: 180, ftp: 250, hoursPerWeek: 8, goal: 'dirka', deficit: 300, targetWeightKg: 72, neat: 1.4, proteinGkg: 1.8,
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true, powerMeterAuto: true }, strength: { on: true, equipment: 'home' }, strengthDays: 2,
  event: { name: 'Maraton Franja', date: addDays(today, 200), distanceKm: 156 }, cycleStart: weekStartIso(addDays(today, -28)),
  place: { name: 'Radovljica', lat: 46.3441, lon: 14.1746 }, aiConsentAt: NOW, onboardingDone: true, createdAt: NOW, updatedAt: NOW,
}
// lastne vožnje (Garmin prek intervals.icu) — ime z mestom, kot ga da Garmin
const own = (i: number, o: Partial<Activity> = {}): Activity => ({
  id: 'own' + i, source: 'intervals', originHint: 'GARMIN', sport: 'kolo', date: d(-2 - i * 3), start: d(-2 - i * 3) + 'T07:00:00.000Z', name: 'Radovljica Kolesarjenje',
  distKm: 40 + i, durationMin: 90 + i, avgHr: 132, tss: 60 + i, deviceWatts: false, hrZoneSec: [600, 3600, 900, 200, 0, 0, 0], aiEligible: true, geoRetain: true, expiresAt: null,
  ext: { intervalsId: 'g' + i }, createdAt: NOW, updatedAt: NOW, ...o,
})
const OWN = Array.from({ length: 14 }, (_, i) => own(i))
// Stravini podatki z opaznimi številkami
const STRAVA: Activity[] = [
  { id: 's1', source: 'intervals', originHint: 'STRAVA', sport: 'kolo', date: d(-3), start: d(-3) + 'T08:00:00.000Z', name: 'Strava VO2 ride', distKm: 87.3, durationMin: 213, avgHr: 151, avgPower: 247, tss: 234, kcal: 2345, deviceWatts: true, hrZoneSec: [100, 200, 300, 4000, 900, 0, 0], aiEligible: false, geoRetain: false, expiresAt: null, ext: { intervalsId: 'st1' }, createdAt: NOW, updatedAt: NOW },
  { id: 's2', source: 'strava_api', sport: 'kolo', date: d(-1), start: d(-1) + 'T08:00:00.000Z', name: 'Strava Morning Ride', distKm: 63.1, durationMin: 157, kcal: 1777, tss: 188, aiEligible: false, geoRetain: false, expiresAt: new Date(Date.now() + 5 * 86400_000).toISOString(), ext: { stravaId: 999 }, createdAt: NOW, updatedAt: NOW },
  { id: 's3', source: 'screenshot', originHint: 'STRAVA', sport: 'kolo', date: today, start: null, name: 'Posnetek Strave', distKm: 44.4, durationMin: 95, kcal: 1234, tss: 111, aiEligible: false, geoRetain: false, expiresAt: null, createdAt: NOW, updatedAt: NOW },
  { id: 's4', source: 'archive', originHint: 'STRAVA', sport: 'kolo', date: d(-10), start: d(-10) + 'T08:00:00.000Z', name: 'Stravin arhiv', distKm: 99.9, durationMin: 181, tss: 177, aiEligible: false, geoRetain: true, expiresAt: null, createdAt: NOW, updatedAt: NOW },
  { id: 's5', source: 'strava_api', sport: 'moc', date: d(-2), start: null, name: 'Strava moč', durationMin: 61, kcal: 901, exercises: [{ name: 'Sklece', sets: 3, reps: '17' }], aiEligible: false, geoRetain: false, expiresAt: new Date(Date.now() + 5 * 86400_000).toISOString(), createdAt: NOW, updatedAt: NOW },
]
// ena skrita, a ne-Stravina aktivnost (neznan izvor) — da ima tudi primerjalno stanje opombo o skritih
const OTHER_HIDDEN: Activity = { id: 'u1', source: 'intervals', originHint: 'NEZNANO', sport: 'kolo', date: d(-20), start: null, name: 'x', durationMin: 30, aiEligible: false, geoRetain: false, expiresAt: null, createdAt: NOW, updatedAt: NOW }

const day = (id: string, date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id, date, kind: 'kolo', title: 'Z2 vzdržljivost', desc: 'Enakomerno v Z2.', durationMin: 90, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })
const planOf = (stravaDone: boolean): PlanDay[] => {
  const done = (id: string) => (stravaDone ? { done: { at: NOW, activityId: id }, doneAt: NOW } : {})
  return [
    day('p1', d(-3), { title: 'VO2max 5 × 4 min', zone: 'Z5', role: 'kljucna', durationMin: 75, ...done('s1') }),
    day('p2', d(-10), { title: 'Dolga Z2', role: 'dolga', durationMin: 180, ...done('s4') }),
    day('p3', d(-8), { title: 'Sweet spot 3 × 12', zone: 'Z4', role: 'kljucna', durationMin: 80, ...done('s-izbrisana') }),   // kaže na (Stravino) vožnjo, ki je potekla
    day('p4', today, { title: 'Prag 2 × 20 min', zone: 'Z4', role: 'kljucna', durationMin: 90, ...done('s3') }),
    day('p5', d(-2), { kind: 'moc', title: 'Moč noge', zone: null, role: 'moc', durationMin: 30, ...done('s5') }),
    day('p6', d(1), { title: 'Z2 90 min' }),
    day('p7', d(2), { kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, role: null }),
    day('p8', d(4), { title: 'Dolga Z2', role: 'dolga', durationMin: 200 }),
  ]
}
const appOf = (withStrava: boolean): AppState => ({
  ready: true, profile, settings: { lang: 'sl', tests: [], wellnessOn: true }, activities: withStrava ? [...OWN, ...STRAVA, OTHER_HIDDEN] : [...OWN, OTHER_HIDDEN],
  plan: planOf(withStrava), mealsToday: [], recentMeals: [], checkinToday: null, checkins: [{ date: today, sleepH: 7, mood: 4, soreness: 2, weightKg: 75 }],
  weather: null, today, toast: null, migration: null, user: null, authKnown: true, sync: { state: 'off' }, pro: false, routeLib: null, routesBusy: false,
  icuWorkouts: null, icuDiag: null, firstSync: null, accountClash: null, icuErr: null, syncDeleted: null,
  // podatki z ure (samo na napravi) — ne smejo v AI
  wellness: [{ date: today, sleepH: 6.1, sleepScore: 71, hrv: 61.3, rhr: 47 }],
} as unknown as AppState)

const norm = (t: string) => t.replace(/Ura: \d\d:\d\d/g, 'Ura: HH:MM')

/** Vsi pozivi (graditelji + dejanja) za dano stanje. */
async function allPrompts(app: AppState): Promise<string[]> {
  h.calls.length = 0
  h.text = 'Kratek nasvet.'
  const s = snapOf(app)
  const ws = weekStartIso(today)
  const rawWeek = app.plan.filter(x => x.date >= ws && x.date <= addDays(ws, 6))
  const out: string[] = []
  // graditelji neposredno, s SUROVIMI podatki (vse aktivnosti, surovi načrt) — se morajo zaščititi sami
  out.push(aiContext(app.activities, app.profile, app.plan))
  out.push(personalContext({ profile: app.profile, activities: app.activities, plan: app.plan, checkins: app.checkins, recentMeals: [], tests: [], today }))
  out.push(coachDailyPrompt('ctx', app.plan.filter(x => x.date === today), 'vprašanje', app.activities).map(p => ('text' in p ? p.text : '')).join('\n'))
  out.push(adaptPlanPrompt('ctx', rawWeek, app.activities).map(p => ('text' in p ? p.text : '')).join('\n'))
  out.push(weeklyReviewPrompt(s.extra || '').map(p => ('text' in p ? p.text : '')).join('\n'))
  // dejanja (tako, kot jih kličejo zasloni: snapOf + surovi teden)
  await A.dailyAdvice(s, true)
  await A.chat(s, 'Kako mi gre?', { msgs: [], summary: null })
  await A.weeklyReview(s, true)
  h.json = { dnevi: rawWeek.filter(x => x.kind !== 'moc').map(x => ({ date: x.date, kind: x.kind, title: x.title, desc: x.desc, durationMin: x.durationMin, zone: x.zone, tssTarget: null })), povzetek: 'ok' }
  await A.adaptWeek(s, rawWeek)
  h.json = { predlogi: [] }
  await A.mealIdeas(s, 900, 60)
  h.json = { dnevi: [], nakup: [] }
  await A.weekMenu(s, 2000, 140, [])
  await A.monthReview(s, 'september: 12 vaj')
  h.json = { tip: 'x', opis: 'x', ocene: {}, moci: [], sibkosti: [], fokus: 'x' }
  await A.athleteProfile(s)
  return [...out, ...h.calls].map(norm)
}

describe('Strava nikoli v AI — ne neposredno ne posredno (vsi pozivi)', () => {
  it('vsak poziv je enak kot brez Stravinih podatkov (kljukice, število, kcal, merilnik moči, ure …)', async () => {
    const base = await allPrompts(appOf(false))
    const withStrava = await allPrompts(appOf(true))
    expect(withStrava.length).toBe(base.length)
    expect(withStrava.length).toBeGreaterThanOrEqual(13)
    for (let i = 0; i < base.length; i++) expect(withStrava[i], `poziv #${i}`).toBe(base[i])
    const all = withStrava.join('\n')
    for (const leak of ['87.3', '87,3', '213 min', '234', '247 W', '1777', '1234', '99.9', '99,9', '63.1', 'Strava VO2', 'Strava Morning', 'Posnetek Strave', 'Stravin arhiv', 'Strava moč', 'opravljeno']) {
      expect(all, leak).not.toContain(leak)
    }
    // ključni trening, ki ga je »opravila« Stravina vožnja: za AI ni opravljen (kot da vožnje ni)
    expect(all).toMatch(/VO2max 5 × 4 min: ni/)
    expect(all).not.toMatch(/VO2max 5 × 4 min: (da|delno|drugače)/)
    // skrite aktivnosti: samo stavek, nikoli število
    expect(all).toContain(HIDDEN_NOTE)
    expect(all).not.toMatch(/\d+\s+aktivnost\w*\s+ni v tem povzetku/)
  })

  it('AI-safe pogled: brez Stravinih aktivnosti, brez kljukic na skrite, merilnik moči samo iz dovoljenih voženj', () => {
    const app = appOf(true)
    const v = aiSafeView({ profile: app.profile, activities: app.activities, plan: app.plan, today })
    expect(v.activities.every(a => a.aiEligible)).toBe(true)
    expect(v.hidden).toBe(true)
    expect(v.plan.filter(x => x.done)).toHaveLength(0)
    // merilnik moči je »zaznal« samo Stravin s1 (deviceWatts) — iz lastnih voženj ga ni
    expect(v.profile.gear.powerMeter).toBe(false)
    // ročna kljukica (brez aktivnosti) in kljukica na dovoljeno vožnjo ostaneta
    const manual = aiSafeView({ profile, activities: OWN, plan: [day('m', d(-1), { done: { at: NOW, activityId: null } }), day('o', d(-2), { done: { at: NOW, activityId: 'own0' } })], today })
    expect(manual.plan.map(x => !!x.done)).toEqual([true, true])
    const s = snapOf(app)
    expect(s.activities.some(a => !a.aiEligible)).toBe(false)
    expect(s.hidden).toBe(true)
  })

  it('podatki z ure (HRV, spanec z ure, mirovni utrip) ter ime in kraj nikoli v pozivu', async () => {
    const all = (await allPrompts(appOf(true))).join('\n')
    for (const x of ['HRV', '61.3', '61,3', '6.1 h', '6,1 h', 'Blažko', 'Testni', 'Radovljica', '46.34', '14.17']) expect(all, x).not.toContain(x)
  })
})

describe('sanitizeGaps na VSEM besedilu AI, ki ga pokažemo', () => {
  const GAP = 'Ta teden si bil neaktiven.'
  beforeEach(() => { h.calls.length = 0 })
  afterEach(() => { h.text = 'Kratek nasvet.' })
  const s = () => snapOf(appOf(true))

  it('besedilni odgovori (nasvet, pogovor, pregled, mesečna ocena)', async () => {
    h.text = `${GAP} Jutri lahka vožnja Z2.`
    expect(await A.dailyAdvice(s(), true)).toBe('Jutri lahka vožnja Z2.')
    expect(await A.weeklyReview(s(), true)).toBe('Jutri lahka vožnja Z2.')
    expect(await A.monthReview(s(), 'x')).toBe('Jutri lahka vožnja Z2.')
    const m = await A.chat(s(), 'Kaj danes?', { msgs: [], summary: null })
    expect(m.msgs[1]!.text).toBe('Jutri lahka vožnja Z2.')
  })

  it('prilagoditev tedna: naslov, opis, cona, zakaj, povzetek', async () => {
    const app = appOf(true), ws = weekStartIso(today)
    const week = app.plan.filter(x => x.date >= ws && x.date <= addDays(ws, 6) && !x.done)
    h.json = { dnevi: week.map(x => ({ date: x.date, kind: 'kolo', title: 'Premor', desc: `${GAP} Vozi 90 min v Z2.`, durationMin: 90, zone: 'Z2 po pavzi', tssTarget: 60, why: 'Po tednu brez treninga začni lahko.' })), povzetek: `Po premoru se vračaš. Prilagodil sem teden.` }
    const r = await A.adaptWeek(snapOf(app), week)
    const changed = r.days.filter(x => week.some(w => w.id === x.id) && x.kind !== 'moc')
    expect(changed.length).toBeGreaterThan(0)
    for (const x of changed) {
      expect(x.title).not.toMatch(/premor/i)
      expect(x.desc).toBe('Vozi 90 min v Z2.')
      expect(x.zone ?? '').not.toMatch(/pavz/i)
      expect(x.why ?? '').not.toMatch(/brez treninga/)
    }
    expect(r.summary).toBe('Prilagodil sem teden.')
  })

  it('obroki, hladilnik, jedilnik, profil športnika', async () => {
    h.json = { predlogi: [{ jed: 'Skuta po premoru', opis: `Ker si bil neaktiven, jej manj. Skuta 250 g z jagodami.`, kcal: 400, b: 40, oh: 30, m: 10, minut: 5 }] }
    const ideas = await A.mealIdeas(s(), 900, 60)
    expect(ideas[0]!.name).toBe('Obrok'); expect(ideas[0]!.desc).toBe('Skuta 250 g z jagodami.')
    h.json = { vidim: ['jajca', 'pavza med nakupi'], predlogi: [{ jed: 'Omleta', opis: `${GAP} Tri jajca in špinača.`, kcal: 350, b: 25, oh: 5, m: 20, manjka: 'brez aktivnosti' }] }
    const fr = await A.fridgeMeals(profile, new File(['x'], 'x.jpg', { type: 'image/jpeg' }), 900, 60, null)
    expect(fr.seen).toEqual(['jajca']); expect(fr.ideas[0]!.desc).toBe('Tri jajca in špinača.'); expect(fr.ideas[0]!.missing).toBeNull()
    const ws = weekStartIso(today)
    h.json = { dnevi: [{ datum: ws, zajtrk: `Po pavzi lažje. Ovsena kaša 80 g.`, kosilo: 'Riž s piščancem', malica: 'Jogurt', vecerja: 'Testenine', kcal: 2600, b: 140 }], nakup: ['riž 1 kg', 'nič po premoru'] }
    const menu = await A.weekMenu(s(), 2000, 140, [])
    expect(menu.days[0]!.zajtrk).toBe('Ovsena kaša 80 g.'); expect(menu.shopping).toEqual(['riž 1 kg'])
    h.json = { tip: 'Neaktiven vzdržljivec', opis: `Brez treningov zadnji teden. Močan na klancih.`, ocene: { vzdrzljivost: 70 }, moci: ['klanci', 'dolgi premori'], sibkosti: ['šprint'], fokus: `${GAP} Dodaj šprinte.` }
    const ap = await A.athleteProfile(s())
    expect(ap.type).toBe(''); expect(ap.summary).toBe('Močan na klancih.'); expect(ap.strengths).toEqual(['klanci']); expect(ap.focus).toBe('Dodaj šprinte.')
  })
})
