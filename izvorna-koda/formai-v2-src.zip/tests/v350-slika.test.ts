// v3.50 SLIKA — trening s slike: (1) posnetek opravljenega treninga odkljuka dan, (2) slika treninga → dan načrta s koraki
// za vodeno vadbo, (3) slika sebe → predlog vaj (samo odrasli, brez ocene videza). AI je prestrežen.
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const h = vi.hoisted(() => ({ json: {} as unknown, prompts: [] as string[], calls: 0 }))
vi.mock('../src/domain/ai/client', () => {
  class AiError extends Error { kind: string; constructor(kind: string, m: string) { super(m); this.kind = kind } }
  return {
    AiError,
    askText: async () => '',
    askJson: async (parts: { text?: string }[]) => { h.calls++; h.prompts.push(parts.map(p => p.text || '').join('\n')); return JSON.parse(JSON.stringify(h.json)) },
  }
})
vi.mock('../src/domain/ai/image', () => ({ fileToBase64Resized: async () => ({ data: 'SLIKA64BASE', mime: 'image/jpeg', thumb: 'data:image/jpeg;base64,SLICICA' }), exifStamp: async () => null }))
vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { saveDoneShot, addPhotoWorkout, addSelfSessions } from '../src/state/photoTraining'
import { doneFromPhoto, workoutFromPhoto, selfFromPhoto, selfAvailable, selfPhotoPrompt, workoutPhotoPrompt, MINOR_SELF, NO_WORKOUT, STRAVA_WORKOUT } from '../src/domain/ai/photoTraining'
import {
  cleanShot, shotErrors, doneDayOptions, pickDoneDay, fitsDay, draftFromOut, draftErrors, draftToPlanDay, draftDesc, matchExercise,
  placeWorkout, replaceOptions, selfFromOut, selfSessions, cleanPoints, repsOf, atOf, PHOTO_LIMITS, type PhotoWorkout,
} from '../src/domain/training/fromPhoto'
import { stepsFor, structureLines, totalSec } from '../src/domain/training/workout'
import { exByName } from '../src/domain/training/exercises'
import { AI_SENT } from '../src/domain/ai/consent'
import { addDays } from '../src/domain/training/load'
import type { Activity, PlanDay, Profile } from '../src/domain/types'

const TODAY = '2026-10-22'   // četrtek
// (v3.50 POPRAVKI-NU, N9) slika sebe zahteva privolitev različice 3 (besedilo z vrstico o slikah sebe)
const P = { aiConsentAt: '2026-10-01T08:00:00.000Z', aiConsentV: 3, age: 21, sex: 'm', weightKg: 78, heightCm: 182, ftp: 250, lthr: 172, maxHr: 195, restHr: 50, name: 'Blaž' } as unknown as Profile
const file = () => new File(['x'], 'slika.jpg', { type: 'image/jpeg' })
const now = '2026-10-22T08:00:00.000Z'
const day = (o: Partial<PlanDay> & Pick<PlanDay, 'id' | 'date' | 'kind'>): PlanDay => ({ title: o.kind === 'pocitek' ? 'Počitek' : 'Trening', desc: '', durationMin: 60, source: 'rules', createdAt: now, updatedAt: now, done: null, ...o })
const act = (o: Partial<Activity>): Activity => ({ id: 'a1', source: 'screenshot', sport: 'kolo', date: TODAY, name: 'Vožnja', durationMin: 60, aiEligible: true, geoRetain: false, createdAt: now, updatedAt: now, ...o })

beforeEach(() => { h.json = {}; h.prompts.length = 0; h.calls = 0 })

describe('1 · posnetek opravljenega treninga: razčlenitev in preverba', () => {
  it('veljaven posnetek (Zwift): vir screenshot, številke ostanejo; poziv pozna fitnes naprave in današnji datum', async () => {
    h.json = { app: 'zwift', sport: 'kolo', datum: addDays(TODAY, -1), trajanje_min: 62, razdalja_km: 31.44, vzpon_m: 220, povprecni_utrip: 148, povprecna_moc: 205, kcal: 690, ime: 'Zwift — Watopia', zanesljivost: 'visoka' }
    const a = await doneFromPhoto(P, file(), TODAY)
    expect(a.source).toBe('screenshot')
    expect([a.date, a.durationMin, a.distKm, a.avgHr, a.avgPower, a.kcal, a.aiEligible]).toEqual([addDays(TODAY, -1), 62, 31.4, 148, 205, 690, true])
    expect(h.prompts[0]).toContain(`Današnji datum je ${TODAY}`)
    expect(h.prompts[0]).toMatch(/tekalna steza/)
    expect(shotErrors(a)).toEqual({})
  })
  it('nesmiselne številke → prazna polja (ročni popravek), trajanje je obvezno 5–480 min', async () => {
    h.json = { app: 'garmin', sport: 'tek', datum: null, trajanje_min: 2000, razdalja_km: 9999, povprecni_utrip: 900, povprecna_moc: -5, kcal: 'veliko', zanesljivost: 'nizka' }
    const a = await doneFromPhoto(P, file(), TODAY)
    expect([a.durationMin, a.distKm, a.avgHr, a.avgPower, a.kcal]).toEqual([null, null, null, null, null])
    expect(a.date).toBe(TODAY)
    expect(shotErrors(a).min).toBe('Vpiši trajanje.')
    expect(shotErrors({ ...a, durationMin: 3 }).min).toBe('Trajanje: od 5 do 480 min.')
    expect(shotErrors({ ...a, durationMin: 45, avgHr: 300 }).hr).toMatch(/Utrip: od 30 do 230/)
    expect(cleanShot(act({ durationMin: 4 })).durationMin).toBeNull()
    expect(cleanShot(act({ durationMin: 481 })).durationMin).toBeNull()
    expect(cleanShot(act({ durationMin: 480 })).durationMin).toBe(480)
  })
  it('prazen odgovor: aktivnost brez številk (ne shrani se, dokler ne vpišeš trajanja); Strava → trener ne vidi', async () => {
    h.json = {}
    const a = await doneFromPhoto(P, file(), TODAY)
    expect(a.durationMin).toBeNull(); expect(shotErrors(a).min).toBeTruthy()
    h.json = { app: 'strava', sport: 'kolo', trajanje_min: 90, zanesljivost: 'visoka' }
    const s = await doneFromPhoto(P, file(), TODAY)
    expect(s.aiEligible).toBe(false); expect(s.originHint).toBe('STRAVA')
  })
})

describe('1 · povezava z dnevom načrta (isti šport, nadomestek, brez dvojnika)', () => {
  const plan = [
    day({ id: 'k', date: TODAY, kind: 'kolo', title: 'Z2 vzdržljivost', durationMin: 60 }),
    day({ id: 'm', date: TODAY, kind: 'moc', title: 'Jedro', durationMin: 20, optional: true }),
    day({ id: 't', date: addDays(TODAY, -1), kind: 'tek', title: 'Lahek tek', durationMin: 40 }),
    day({ id: 'p', date: addDays(TODAY, -2), kind: 'pocitek' }),
    day({ id: 'old', date: addDays(TODAY, -9), kind: 'kolo' }),
    day({ id: 'fut', date: addDays(TODAY, 1), kind: 'kolo' }),
  ]
  it('ponujeni dnevi: zadnjih 7 dni do danes, brez počitka in prihodnosti; dan s pravo vadbo ne, »Opravil« brez ure da', () => {
    expect(doneDayOptions(plan, TODAY).map(d => d.id)).toEqual(['k', 'm', 't'])
    const withReal = plan.map(d => (d.id === 'k' ? { ...d, done: { at: now, activityId: 'garmin1' } } : d.id === 't' ? { ...d, done: { at: now } } : d))
    expect(doneDayOptions(withReal, TODAY).map(d => d.id)).toEqual(['m', 't'])
  })
  it('isti šport istega dne; izbrani dan (Včeraj …) ima prednost; nadomestek hribi ↔ kolo vsaj 40 %', () => {
    expect(pickDoneDay(act({ sport: 'kolo', durationMin: 55 }), plan, TODAY)?.id).toBe('k')
    expect(pickDoneDay(act({ sport: 'tek', durationMin: 35, date: TODAY }), plan, TODAY, 't')?.id).toBe('t')
    expect(pickDoneDay(act({ sport: 'pohod', durationMin: 50 }), plan, TODAY, 'k')?.id).toBe('k')
    expect(fitsDay(act({ sport: 'pohod', durationMin: 50 }), plan[0]!)).toBe(true)
    // 15 min hoje ni 60-minutna vožnja (40 % pravilo), moč ni kolo
    expect(pickDoneDay(act({ sport: 'pohod', durationMin: 15 }), plan, TODAY, 'k')).toBeNull()
    expect(fitsDay(act({ sport: 'moc', durationMin: 60 }), plan[0]!)).toBe(false)
    expect(pickDoneDay(act({ sport: 'moc', durationMin: 25 }), plan, TODAY)?.id).toBe('m')
    // dan, ki ga je že odkljukala vožnja z ure, posnetek ne odkljuka še enkrat
    const real = plan.map(d => (d.id === 'k' ? { ...d, done: { at: now, activityId: 'garmin1' } } : d))
    expect(pickDoneDay(act({ sport: 'kolo', durationMin: 60 }), real, TODAY, 'k')).toBeNull()
  })

  describe('shramba', () => {
    beforeEach(async () => {
      vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date(2026, 9, 22, 18, 0))
      await repo.wipeAll(); localStorage.clear()
      await repo.saveProfile({ ...(await repo.loadProfile()), ...P, onboardingDone: true } as Profile)
      await repo.putPlanDays([day({ id: 'k', date: TODAY, kind: 'kolo', title: 'Z2 vzdržljivost', durationMin: 60, tssTarget: 50 }), day({ id: 't', date: addDays(TODAY, -1), kind: 'tek', title: 'Lahek tek', durationMin: 40 })])
      await store.reloadAll()
    })
    afterEach(() => { vi.useRealTimers() })
    it('»Opravil« brez ure + posnetek: zapis iz načrta odpade, dan kaže na posnetek; isti posnetek drugič je dvojnik', async () => {
      await store.setPlanDone('k', true)
      expect(store.getState().activities.filter(a => a.date === TODAY).map(a => a.source)).toEqual(['plan'])
      const r = await saveDoneShot(act({ id: 'shot1', sport: 'kolo', durationMin: 58, distKm: 27 }), 'k')
      expect(r.added).toBe(true); expect(r.day?.id).toBe('k')
      const s = store.getState()
      expect(s.activities.filter(a => a.date === TODAY).map(a => a.id)).toEqual(['shot1'])
      expect(s.plan.find(d => d.id === 'k')?.done?.activityId).toBe('shot1')
      const again = await saveDoneShot(act({ id: 'shot2', sport: 'kolo', durationMin: 58, distKm: 27 }), 'k')
      expect(again.added).toBe(false)
      expect(store.getState().activities.filter(a => a.date === TODAY)).toHaveLength(1)
    })
    it('nadomestek: hribi 45 min na dan kolesa → dan odkljukan (setPlanDone), datum posnetka = datum dneva', async () => {
      const r = await saveDoneShot(act({ id: 'hike', sport: 'pohod', durationMin: 45, date: TODAY }), 'k')
      expect(r.day?.id).toBe('k')
      expect(store.getState().plan.find(d => d.id === 'k')?.done?.activityId).toBe('hike')
      // včerajšnji tek iz vprašanja »Včeraj … si ga naredil?«: posnetek dobi včerajšnji datum
      const y = await saveDoneShot(act({ id: 'run', sport: 'tek', durationMin: 38, date: TODAY }), 't')
      expect(y.day?.id).toBe('t')
      expect(store.getState().activities.find(a => a.id === 'run')?.date).toBe(addDays(TODAY, -1))
    })
    it('ne ustreza (moč na dan kolesa): shrani se kot dodatna vadba, dan ostane neodkljukan', async () => {
      const r = await saveDoneShot(act({ id: 'gym', sport: 'moc', durationMin: 40 }), 'k')
      expect(r.added).toBe(true); expect(r.day).toBeNull()
      expect(store.getState().plan.find(d => d.id === 'k')?.done ?? null).toBeNull()
    })
  })
})

describe('2 · trening s slike: razčlenitev in preverba', () => {
  it('veljaven WOD: imena s table → knjižnica (s sliko), ponovitve in sekunde, kg', async () => {
    h.json = { vrsta: 'moc', naslov: 'WOD četrtek', minut: 40, vaje: [{ ime: 'Back squat', serije: 5, ponovitve: 5, kg: 80, pavza_s: 120 }, { ime: 'Burpees', serije: 3, ponovitve: 15 }, { ime: 'Plank', serije: 3, cas_s: 45 }, { ime: 'Wall ball', serije: 3, ponovitve: 20, kg: 9 }], opomba: 'AMRAP 10 min na koncu' }
    const w = await workoutFromPhoto(P, file())
    expect(w.kind).toBe('moc'); expect(w.minutes).toBe(40); expect(w.title).toBe('WOD četrtek')
    expect(w.exercises.map(e => [e.name, e.sets, e.reps, e.kg, e.lib])).toEqual([
      ['Počep s palico', 5, '5', 80, 'pocep-p'], ['Burpee', 3, '15', null, 'burpee'], ['Deska', 3, '45 s', null, 'deska'], ['Met žoge v steno', 3, '20', 9, 'wallball'],   // (v3.51 H51) Wall ball je v knjižnici
    ])
    expect(draftErrors(w)).toEqual([])
    expect(h.prompts[0]).toMatch(/Bolgarski počep/)   // seznam vaj iz knjižnice je v pozivu
  })
  it('nesmiselno: serije 99, ponovitve 500, kg 1000, 20 vaj → prazna polja in največ 15 vaj; napake povedo, kaj vpisati', () => {
    const w = draftFromOut({ vrsta: 'moc', minut: 9999, vaje: [{ ime: 'Počep', serije: 99, ponovitve: 500, kg: 1000 }, ...Array.from({ length: 19 }, (_, i) => ({ ime: `Vaja ${i}`, serije: 3, ponovitve: 10 }))] })!
    expect(w.exercises).toHaveLength(PHOTO_LIMITS.ex)
    expect(w.exercises[0]).toMatchObject({ name: 'Počep', sets: null, reps: '', kg: null })
    expect(w.minutes).toBeNull()
    expect(draftErrors(w).join(' ')).toMatch(/Vpiši serije in ponovitve.*Počep/)
    expect(repsOf(0)).toBe(''); expect(repsOf(101)).toBe(''); expect(repsOf('8-12')).toBe('8–12'); expect(repsOf(null, 30)).toBe('30 s'); expect(repsOf('3000 s')).toBe('')
    expect(atOf('Z4')).toBe('RPE 8'); expect(atOf('250-270W')).toBe('250–270 W'); expect(atOf('95 %')).toBe('95–95 % FTP'); expect(atOf('9999 W')).toBe(''); expect(atOf('sprint')).toBe('šprint — vse, kar gre')
  })
  it('prazno ali brez treninga → napaka z rezervno potjo (ročno)', async () => {
    expect(draftFromOut(null)).toBeNull(); expect(draftFromOut('abc')).toBeNull(); expect(draftFromOut({})).toBeNull()
    expect(draftFromOut({ vrsta: 'moc', vaje: [] })).toBeNull(); expect(draftFromOut({ vrsta: 'kolo', koraki: [] })).toBeNull()
    h.json = { vrsta: 'moc', vaje: [], koraki: [] }
    await expect(workoutFromPhoto(P, file())).rejects.toThrow(NO_WORKOUT)
    // posnetek iz Strave: rezultat se ne uporabi
    h.json = { app: 'Strava', vrsta: 'kolo', koraki: [{ tip: 'ponovitve', ponovitve: 4, delo_s: 240 }] }
    await expect(workoutFromPhoto(P, file())).rejects.toThrow(STRAVA_WORKOUT)
    expect(workoutPhotoPrompt('x', 'image/jpeg')[0]).toMatchObject({ text: expect.stringMatching(/Ničesar ne dodajaj/) })
  })
})

describe('2 · pretvorba v dan načrta s koraki, ki jih vodena vadba (stepsFor) razume', () => {
  const kolo = (blocks: PhotoWorkout['blocks'], o: Partial<PhotoWorkout> = {}): PhotoWorkout => ({ kind: 'kolo', title: 'Zwift intervali', minutes: null, exercises: [], blocks, note: '', ...o })
  it('5 × (3 min pri RPE 8 / 2 min): 5 ponovitev, 4 odmori, ogrevanje in iztek; trajanje = struktura', () => {
    const w = draftFromOut({ vrsta: 'kolo', naslov: 'Zwift intervali', koraki: [{ tip: 'ogrevanje', min: 10 }, { tip: 'ponovitve', ponovitve: 5, delo_s: 180, odmor_s: 120, intenzivnost: 'Z4' }, { tip: 'iztek', min: 5 }] })!
    const d = draftToPlanDay(w, TODAY, P)
    expect(d.desc).toBe('10 min ogrevanja, nato 5 × (3 min pri RPE 8 / 2 min lahko). 5 min iztek.')
    expect([d.kind, d.durationMin, d.zone, d.done]).toEqual(['kolo', 38, 'Z4', null])
    const st = stepsFor(d, P)
    const work = st.filter(s => s.kind === 'delo')
    expect(work.map(s => s.sec)).toEqual([180, 180, 180, 180, 180])
    expect(st.filter(s => s.kind === 'lahko' && s.group === 0).map(s => s.sec)).toEqual([120, 120, 120, 120])
    expect(st[0]).toMatchObject({ kind: 'ogrevanje', sec: 600 }); expect(st[st.length - 1]).toMatchObject({ kind: 'iztek', sec: 300 })
    expect(totalSec(st)).toBe(38 * 60)
    expect(structureLines(st).join(' · ')).toMatch(/5 × 3 min.*vmes 2 min/)
  })
  it('sekunde in privzet odmor: 8 × 30 s šprint brez odmora na sliki → 15 s ni, odmor 30 s (polovica dela, najmanj 30 s)', () => {
    const w = kolo([{ kind: 'ponovitve', min: null, n: 8, workS: 30, restS: null, at: 'šprint — vse, kar gre' }])
    const d = draftToPlanDay(w, TODAY, P)
    expect(d.desc).toMatch(/8 × \(30 s šprint — vse, kar gre \/ 30 s lahko\)/)
    const st = stepsFor(d, P)
    expect(st.filter(s => s.kind === 'delo').map(s => s.sec)).toEqual(Array(8).fill(30))
    expect(st.filter(s => s.kind === 'lahko' && s.group === 0).every(s => s.sec === 30)).toBe(true)
    expect(d.zone).toBe('Z5')
  })
  it('več blokov in tempo (tek): 4 × 4 min, nato 20 min tempo; presledek med bloki je odmor prejšnjega', () => {
    const w: PhotoWorkout = { kind: 'tek', title: 'Tek s table', minutes: null, exercises: [], note: '', blocks: [
      { kind: 'ogrevanje', min: 15, n: null, workS: null, restS: null, at: '' },
      { kind: 'ponovitve', min: null, n: 4, workS: 240, restS: 180, at: 'RPE 8' },
      { kind: 'enakomerno', min: 20, n: null, workS: null, restS: null, at: 'tempo' },
      { kind: 'iztek', min: 10, n: null, workS: null, restS: null, at: '' },
    ] }
    const d = draftToPlanDay(w, TODAY, P)
    const st = stepsFor(d, P)
    expect(st.filter(s => s.kind === 'delo').map(s => s.sec)).toEqual([240, 240, 240, 240, 1200])
    expect(totalSec(st)).toBe(d.durationMin * 60)
    expect(d.durationMin).toBe(15 + 16 + 9 + 3 + 20 + 10)
  })
  it('moč: vaje gredo v načrt, vodena vadba ima sliko vsake vaje iz knjižnice (exByName) in pavze', () => {
    const w = draftFromOut({ vrsta: 'moc', vaje: [{ ime: 'počepi s palico', serije: 4, ponovitve: 6, kg: 70, pavza_s: 150 }, { ime: 'deska', serije: 3, cas_s: 40 }] })!
    const d = draftToPlanDay(w, TODAY, P)
    expect(d.exercises).toEqual([{ name: 'Počep s palico', sets: 4, reps: '6', kg: 70, rest: 150 }, { name: 'Deska', sets: 3, reps: '40 s' }])
    const st = stepsFor(d, P)
    const vaje = st.filter(s => s.kind === 'vaja')
    expect(vaje).toHaveLength(7)
    expect(vaje.every(s => !!exByName(s.label))).toBe(true)
    expect(vaje.find(s => s.label === 'Deska')?.sec).toBe(40)
    expect(st.find(s => s.kind === 'pavza' && s.label === 'Odmor')?.sec).toBe(150)
    expect(d.durationMin).toBeGreaterThanOrEqual(PHOTO_LIMITS.min[0])
  })
  it('opomba s slike z »×« ne postane ponovitev vodene vadbe', () => {
    const w = kolo([{ kind: 'ponovitve', min: null, n: 3, workS: 300, restS: 120, at: 'RPE 7' }], { note: 'nato še 6 × 10 s šprint, če gre' })
    const d = draftToPlanDay(w, TODAY, P)
    expect(draftDesc(w)).toMatch(/S slike: nato še 6 x 10 s/)
    expect(stepsFor(d, P).filter(s => s.kind === 'delo')).toHaveLength(3)
  })
})

describe('2 · povezava imen vaj s knjižnico (sklon, angleška imena)', () => {
  it.each([
    ['počepi s palico', 'pocep-p'], ['mrtvega dviga', 'mrtvi'], ['izpadnih korakov', 'izpadni'], ['Bolgarski počepi', 'bolgarski'],
    ['Sklec', 'sklece'], ['Back squat', 'pocep-p'], ['Burpees', 'burpee'], ['Lat pulldown', 'pulldown'], ['Kettlebell swings', 'zamah'], ['Side plank', 'stranska'], ['Deska', 'deska'],
  ])('%s → %s', (name, id) => { expect(matchExercise(name)?.id).toBe(id) })
  it('neznana vaja ostane brez povezave (ime ostane)', () => {
    expect(matchExercise('skok v vodo')).toBeNull(); expect(matchExercise('')).toBeNull()
  })
})

describe('2 · v načrt: počitek se zamenja, opravljeno nikoli, »Namesto« po izbiri', () => {
  const w = draftFromOut({ vrsta: 'moc', vaje: [{ ime: 'Sklece', serije: 3, ponovitve: 10 }] })!
  it('počitek → zamenjan (isti id); opravljen trening ostane, novi gre poleg; »Namesto« zamenja izbranega, tekme ne', () => {
    const rest = [day({ id: 'r', date: TODAY, kind: 'pocitek' })]
    const a = placeWorkout(rest, draftToPlanDay(w, TODAY, P))
    expect(a.write.id).toBe('r'); expect(a.write.kind).toBe('moc'); expect(a.replaced?.id).toBe('r')
    const done = [day({ id: 'd', date: TODAY, kind: 'kolo', done: { at: now, activityId: 'x' } })]
    const b = placeWorkout(done, draftToPlanDay(w, TODAY, P), { replaceId: 'd' })
    expect(b.write.id).not.toBe('d'); expect(b.replaced).toBeNull(); expect(b.prev).toEqual([])
    const two = [day({ id: 'k', date: TODAY, kind: 'kolo', title: 'Z2' }), day({ id: 'race', date: TODAY, kind: 'kolo', role: 'dirka', raceId: 'r1' })]
    expect(replaceOptions(two, TODAY).map(d => d.id)).toEqual(['k'])
    expect(placeWorkout(two, draftToPlanDay(w, TODAY, P), { replaceId: 'k' }).write.id).toBe('k')
    expect(placeWorkout(two, draftToPlanDay(w, TODAY, P), { replaceId: 'race' }).replaced).toBeNull()
  })
  describe('shramba', () => {
    beforeEach(async () => {
      vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date(2026, 9, 22, 9, 0))
      await repo.wipeAll(); localStorage.clear()
      await repo.saveProfile({ ...(await repo.loadProfile()), ...P, onboardingDone: true } as Profile)
      await repo.putPlanDays([day({ id: 'k', date: TODAY, kind: 'kolo', title: 'Z2 vzdržljivost' }), day({ id: 'r', date: addDays(TODAY, 1), kind: 'pocitek' })])
      await store.reloadAll()
    })
    afterEach(() => { vi.useRealTimers() })
    it('poleg in razveljavi: dan ima oba, »Razveljavi« vrne prejšnje stanje; namesto počitka jutri', async () => {
      const r = await addPhotoWorkout(draftToPlanDay(w, TODAY, P))
      expect(store.getState().plan.filter(d => d.date === TODAY).map(d => d.kind).sort()).toEqual(['kolo', 'moc'])
      await r.undo()
      expect(store.getState().plan.filter(d => d.date === TODAY).map(d => d.id)).toEqual(['k'])
      const t = await addPhotoWorkout(draftToPlanDay(w, addDays(TODAY, 1), P))
      expect(t.day.id).toBe('r')
      expect(store.getState().plan.filter(d => d.date === addDays(TODAY, 1)).map(d => d.kind)).toEqual(['moc'])
    })
  })
})

describe('3 · slika sebe', () => {
  it('pod 18 let ni na voljo (brez klica AI); brez starosti tudi ne', async () => {
    expect(selfAvailable({ age: 17 })).toBe('minor')
    expect(selfAvailable({ age: null })).toBe('noage')
    expect(selfAvailable({ age: 18 })).toBe('ok')
    expect(MINOR_SELF).toBe('Za mlajše od 18 let ocene s slike ne delam — vaje za držo pa so v Vajah.')
    await expect(selfFromPhoto({ ...P, age: 16 }, file())).rejects.toThrow(MINOR_SELF)
    await expect(selfFromPhoto({ ...P, age: null }, file())).rejects.toThrow(/starost/)
    expect(h.calls).toBe(0)
  })
  it('poziv prepove oceno videza, maščobe, teže in obljube; v AI gre samo slika (brez imena in teže)', async () => {
    const t = (selfPhotoPrompt('x', 'image/jpeg')[0] as { text: string }).text
    for (const rx of [/privlačnosti/, /odstotek telesne maščobe/, /ocena teže/, /obljube videza/, /roki/, /sramotenje/, /grob vtis s slike, ne meritev/i]) expect(t).toMatch(rx)
    h.json = { poudarki: ['Ramena so rahlo naprej — okrepi zgornji hrbet in zadnje rame.'], podrocje: 'drza', predlog: { naslov: 'Hrbet in rame', krat_na_teden: 2, minut: 15, vaje: [{ ime: 'Superman z vlekom', serije: 3, ponovitve: 10 }, { ime: 'Face pull', serije: 3, ponovitve: 12 }] } }
    const s = await selfFromPhoto(P, file())
    expect(h.prompts[0]).not.toMatch(/Blaž|78|182/)
    expect(s.points).toEqual(['Ramena so rahlo naprej — okrepi zgornji hrbet in zadnje rame.'])
    // (v3.51 H18) predlog je za doma — vaja na kablu izpade, ostanejo privzete z lastno težo
    expect(s.exercises.map(e => e.name)).toEqual(['Superman z vlekom', 'Superman', 'Deska'])
    expect([s.perWeek, s.minutes, s.title]).toEqual([2, 15, 'Hrbet in rame'])
  })
  it('poudarki o maščobi, videzu, teži in rokih izpadejo; brez vaj iz knjižnice → privzete za področje', () => {
    expect(cleanPoints(['Imaš okoli 22 % maščobe.', 'Leva stran deluje šibkejša — dodaj vaje na eni nogi.', 'V 8 tednih boš videti lepši.', 'Izgubi nekaj teže.', 'Postava je privlačna.', 'Jedro okrepi z desko.'])).toEqual(['Leva stran deluje šibkejša — dodaj vaje na eni nogi.', 'Jedro okrepi z desko.'])
    const s = selfFromOut({ poudarki: ['Kolena gredo malo navznoter — okrepi zadnjico.'], podrocje: 'noge', predlog: { naslov: 'Do poletja izklesan', krat_na_teden: 9, minut: 90, vaje: [{ ime: 'Nekaj čudnega' }] } })!
    expect(s.title).toBe('Noge in zadnjica'); expect(s.perWeek).toBe(2); expect(s.minutes).toBe(15)
    expect(s.exercises.map(e => e.name)).toEqual(['Počep', 'Izpadni koraki', 'Dvig bokov leže'])
    expect(selfFromOut({})).toBeNull(); expect(selfFromOut('x')).toBeNull()
    expect(selfFromOut({ poudarki: [], opomba: 'Na sliki te ne vidim v celoti.' })).toMatchObject({ points: [], exercises: [], note: 'Na sliki te ne vidim v celoti.' })
  })
  it('seje v načrt: neobvezne, dan narazen, najprej počitek; ne na trd dan, bolezen ali premor', () => {
    const plan = [
      day({ id: '1', date: TODAY, kind: 'kolo', role: 'kljucna', zone: 'Z4' }),
      day({ id: '2', date: addDays(TODAY, 1), kind: 'pocitek' }),
      day({ id: '3', date: addDays(TODAY, 2), kind: 'kolo', role: 'lahka', zone: 'Z2' }),
      day({ id: '4', date: addDays(TODAY, 3), kind: 'pocitek' }),
      day({ id: '5', date: addDays(TODAY, 4), kind: 'kolo', role: 'dolga' }),
      day({ id: '6', date: addDays(TODAY, 5), kind: 'pocitek' }),
      day({ id: '7', date: addDays(TODAY, 6), kind: 'kolo', role: 'lahka' }),
    ]
    const s = selfFromOut({ poudarki: ['Ramena so rahlo naprej — okrepi zgornji hrbet.'], podrocje: 'drza', predlog: { krat_na_teden: 2, minut: 15 } })!
    const ds = selfSessions(s, plan, { sick: null, weekPause: null }, TODAY, now)
    expect(ds.map(d => d.date)).toEqual([addDays(TODAY, 1), addDays(TODAY, 3)])
    expect(ds.every(d => d.kind === 'moc' && d.optional && d.durationMin === 15 && d.done === null)).toBe(true)
    expect(selfSessions(s, plan, { sick: { from: TODAY, to: addDays(TODAY, 3) }, weekPause: null }, TODAY, now).map(d => d.date)).toEqual([addDays(TODAY, 5)])
  })
})

describe('slike se ne shranijo — samo rezultat', () => {
  beforeEach(async () => {
    vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date(2026, 9, 22, 18, 0))
    await repo.wipeAll(); localStorage.clear()
    await repo.saveProfile({ ...(await repo.loadProfile()), ...P, onboardingDone: true } as Profile)
    await repo.putPlanDays([day({ id: 'k', date: TODAY, kind: 'kolo', title: 'Z2 vzdržljivost', durationMin: 60 })])
    await store.reloadAll()
  })
  afterEach(() => { vi.useRealTimers() })
  it('aktivnost, dan načrta in seje ne vsebujejo slike ali sličice (ne v shrambi ne v localStorage)', async () => {
    h.json = { app: 'garmin', sport: 'kolo', trajanje_min: 61, razdalja_km: 30, zanesljivost: 'visoka' }
    const a = await doneFromPhoto(P, file(), TODAY)
    await saveDoneShot(a, 'k')
    h.json = { vrsta: 'moc', vaje: [{ ime: 'Sklece', serije: 3, ponovitve: 10 }] }
    const w = await workoutFromPhoto(P, file())
    await addPhotoWorkout(draftToPlanDay(w, addDays(TODAY, 1), P))
    h.json = { poudarki: ['Ramena so rahlo naprej — okrepi zgornji hrbet.'], podrocje: 'drza', predlog: {} }
    const s = await selfFromPhoto(P, file())
    await addSelfSessions(selfSessions(s, store.getState().plan, P, TODAY))
    const dump = JSON.stringify([a, w, s, await repo.allActivities(), await repo.allPlan(), { ...localStorage }])
    expect(dump).not.toMatch(/SLIKA64BASE|SLICICA|data:image/)
    expect((await repo.allActivities()).some(x => x.source === 'screenshot')).toBe(true)
  })
  it('privolitev: seznam »Gre v AI« ima vrstico za slike treninga in sebe; brez privolitve ni klica AI', async () => {
    expect(AI_SENT.join(' ')).toMatch(/slike treninga.*slike sebe/)
    await expect(workoutFromPhoto({ ...P, aiConsentAt: null } as Profile, file())).rejects.toMatchObject({ kind: 'consent' })
    await expect(doneFromPhoto({ ...P, aiConsentAt: null } as Profile, file(), TODAY)).rejects.toMatchObject({ kind: 'consent' })
    expect(h.calls).toBe(0)
  })
})
