import { describe, it, expect } from 'vitest'
import { decodePolyline, encodePolyline, thinTrack, haversineM, trackLengthKm } from '../src/domain/import/polyline'
import { deriveFlags, aiAllowed, geoAllowed } from '../src/domain/import/provenance'
import { sameActivity, splitNew } from '../src/domain/import/dedupe'
import { parseGpx, parseTcx, toActivity } from '../src/domain/import/parsers'
import { estimateTss, formSeries, formBand, sportOfType, addDays, weekStartIso } from '../src/domain/training/load'
import { hrZones5, powerZones7 } from '../src/domain/training/zones'
import { buildWeek } from '../src/domain/training/planner'
import { bmr, dailyTarget, goalDeficit, MIN_ABS_Z, MAX_DEFICIT } from '../src/domain/nutrition/energy'
import type { Activity, Profile } from '../src/domain/types'

const now = new Date().toISOString()
const baseProfile = (): Profile => ({
  sex: 'm', age: 30, heightCm: 180, weightKg: 76, restHr: 52, maxHr: 190, ftp: 250,
  gear: { bikeOutdoor: true, trainer: false, noBike: false }, level: 2, hoursPerWeek: 5,
  strength: { on: true, equipment: 'home' }, onboardingDone: true, createdAt: now, updatedAt: now,
})
const act = (o: Partial<Activity>): Activity => ({
  id: Math.random().toString(36).slice(2), source: 'file', sport: 'kolo', date: '2026-08-20', name: 'x', aiEligible: true, geoRetain: true,
  createdAt: now, updatedAt: now, ...o,
})

describe('polyline', () => {
  it('se ujema s kanoničnim Google testnim vektorjem', () => {
    const REF = '_p~iF~ps|U_ulLnnqC_mqNvxq`@'
    const pts: [number, number][] = [[38.5, -120.2], [40.7, -120.95], [43.252, -126.453]]
    expect(encodePolyline(pts)).toBe(REF)
    expect(decodePolyline(REF)).toEqual(pts)
  })
  it('round-trip odklon < 1.1 m', () => {
    const track: [number, number][] = Array.from({ length: 2000 }, (_, i) => [46.19 + i * 0.000018, 14.493 + i * 0.000021])
    const rt = decodePolyline(encodePolyline(track))
    let max = 0
    for (let i = 0; i < track.length; i++) max = Math.max(max, haversineM(track[i]!, rt[i]!))
    expect(max).toBeLessThan(1.1)
  })
  it('thinTrack ohrani začetek/konec in redči na ~20 m', () => {
    const track: [number, number][] = Array.from({ length: 3000 }, (_, i) => [46.19 + i * 0.000018, 14.493 + i * 0.000021])
    const th = thinTrack(track, 20)
    expect(th[0]).toEqual(track[0]); expect(th[th.length - 1]).toEqual(track[track.length - 1])
    expect(th.length).toBeLessThan(track.length / 4)
    for (let i = 2; i < th.length - 1; i++) expect(haversineM(th[i - 1]!, th[i]!)).toBeGreaterThanOrEqual(19.9)
    expect(Math.abs(trackLengthKm(th) - trackLengthKm(track))).toBeLessThan(0.05)
  })
})

describe('izvor (provenance) — privzetek zaprt', () => {
  it('strava_api: ne AI, ne karta, poteče v 7 dneh', () => {
    const f = deriveFlags('strava_api', null, new Date('2026-08-22T00:00:00Z'))
    expect(f.aiEligible).toBe(false); expect(f.geoRetain).toBe(false); expect(f.expiresAt).toBe('2026-08-29T00:00:00.000Z')
  })
  it('intervals: samo znan ne-Stravin izvor', () => {
    expect(deriveFlags('intervals', 'GARMIN').aiEligible).toBe(true)
    expect(deriveFlags('intervals', 'STRAVA').aiEligible).toBe(false)
    expect(deriveFlags('intervals', 'NEKAJ_NOVEGA').aiEligible).toBe(false)
    expect(deriveFlags('intervals', null).aiEligible).toBe(false)
  })
  it('datoteke/arhiv/posnetek/ročno: dovoljeno', () => {
    for (const s of ['file', 'archive', 'screenshot', 'manual', 'recorder'] as const) expect(deriveFlags(s).aiEligible).toBe(true)
  })
  it('aiAllowed spoštuje potek', () => {
    expect(aiAllowed({ aiEligible: true, expiresAt: '2000-01-01T00:00:00Z' })).toBe(false)
    expect(aiAllowed({ aiEligible: true, expiresAt: null })).toBe(true)
    expect(geoAllowed({ geoRetain: true, polyline: null })).toBe(false)
  })
})

describe('deduplikacija', () => {
  it('začetek ±90 s in podobno trajanje = ista', () => {
    const a = act({ start: '2026-08-20T07:00:00Z', durationMin: 60 }), b = act({ start: '2026-08-20T07:01:20Z', durationMin: 63 })
    expect(sameActivity(a, b)).toBe(true)
    expect(sameActivity(a, act({ start: '2026-08-20T07:05:00Z', durationMin: 60 }))).toBe(false)
    expect(sameActivity(a, act({ start: '2026-08-20T07:00:30Z', durationMin: 120 }))).toBe(false)
  })
  it('brez začetka: dan + šport + razdalja', () => {
    expect(sameActivity(act({ distKm: 40 }), act({ distKm: 41 }))).toBe(true)
    expect(sameActivity(act({ distKm: 40 }), act({ distKm: 45 }))).toBe(false)
  })
  it('splitNew loči tudi dvojnike znotraj kandidatov', () => {
    const ex = [act({ start: '2026-08-20T07:00:00Z', durationMin: 60 })]
    const c = [act({ start: '2026-08-20T07:00:10Z', durationMin: 60 }), act({ start: '2026-08-21T07:00:00Z', durationMin: 30 }), act({ start: '2026-08-21T07:00:20Z', durationMin: 31 })]
    const { fresh, dupes } = splitNew(ex, c)
    expect(fresh.length).toBe(1); expect(dupes.length).toBe(2)
  })
})

describe('GPX / TCX razčlenjevanje', () => {
  const mkGpx = (n: number) => {
    let s = '<?xml version="1.0"?><gpx version="1.1" xmlns="http://www.topografix.com/GPX/1/1"><trk><name>Vodice krog</name><type>cycling</type><trkseg>'
    for (let i = 0; i < n; i++) { const t = new Date(Date.UTC(2026, 7, 20, 7, 0, i)).toISOString(); s += `<trkpt lat="${(46.19 + i * 0.00002).toFixed(6)}" lon="${(14.49 + i * 0.000025).toFixed(6)}"><ele>${300 + (i % 40)}</ele><time>${t}</time></trkpt>` }
    return s + '</trkseg></trk></gpx>'
  }
  it('GPX: razdalja, čas, sled, šport', async () => {
    const r = await parseGpx(new Blob([mkGpx(1800)]), 'test.gpx')
    expect(r.name).toBe('Vodice krog'); expect(r.sport).toBe('kolo'); expect(r.durationMin).toBe(30)
    expect(r.distKm).toBeGreaterThan(4); expect(r.polyline).toBeTruthy(); expect(r.start).toBe('2026-08-20T07:00:00.000Z')
    const a = toActivity(r, 'file', 40)
    expect(a.aiEligible).toBe(true); expect(a.geoRetain).toBe(true)
  })
  it('TCX: Sport atribut, utrip, razdalja', async () => {
    let s = '<?xml version="1.0"?><TrainingCenterDatabase xmlns="http://www.garmin.com/xmlschemas/TrainingCenterDatabase/v2"><Activities><Activity Sport="Running"><Lap><Track>'
    for (let i = 0; i < 600; i++) { const t = new Date(Date.UTC(2026, 7, 21, 6, 0, i)).toISOString(); s += `<Trackpoint><Time>${t}</Time><Position><LatitudeDegrees>${(46.21 + i * 0.000015).toFixed(6)}</LatitudeDegrees><LongitudeDegrees>${(14.47 + i * 0.00001).toFixed(6)}</LongitudeDegrees></Position><DistanceMeters>${(i * 2.6).toFixed(1)}</DistanceMeters><HeartRateBpm><Value>${140 + (i % 15)}</Value></HeartRateBpm></Trackpoint>` }
    s += '</Track></Lap></Activity></Activities></TrainingCenterDatabase>'
    const r = await parseTcx(new Blob([s]), 'run.tcx')
    expect(r.sport).toBe('tek'); expect(r.avgHr).toBeGreaterThan(140); expect(r.distKm).toBe(1.6); expect(r.polyline).toBeTruthy()
  })
})

describe('obremenitev in forma', () => {
  const p = baseProfile()
  it('TSS iz moči, utripa in hitrosti', () => {
    expect(estimateTss({ sport: 'kolo', durationMin: 60, avgPower: 250 }, p)).toBe(Math.round(1 * 1.05 * 1.05 * 100))
    expect(estimateTss({ sport: 'kolo', durationMin: 60, avgHr: 150 }, p)).toBeGreaterThan(50)
    // 25 km/h → 62 TSS/h (pasovi <18:42, <24:50, <30:62, sicer 75)
    expect(estimateTss({ sport: 'kolo', durationMin: 120, distKm: 50 }, p)).toBe(Math.round(2 * 62))
    expect(estimateTss({ sport: 'kolo', durationMin: 60, distKm: 15 }, p)).toBe(42)
    expect(estimateTss({ sport: 'moc', durationMin: 45 }, p)).toBe(Math.round(0.75 * 70))
  })
  it('formSeries: CTL/ATL rasteta, TSB po obremenitvi pade', () => {
    const acts = Array.from({ length: 14 }, (_, i) => ({ date: addDays('2026-08-01', i), tss: 80 }))
    const s = formSeries(acts, '2026-08-14')
    const last = s[s.length - 1]!
    expect(last.ctl).toBeGreaterThan(0); expect(last.atl).toBeGreaterThan(last.ctl); expect(last.tsb).toBeLessThan(0)
    expect(formBand(12).band).toBe('svež'); expect(formBand(-25).band).toBe('utrujen')
  })
  it('cone', () => {
    expect(hrZones5(p)!.length).toBe(5); expect(powerZones7(p)![3]!.key).toBe('Z4')
    expect(hrZones5({ maxHr: null })).toBeNull()
  })
  it('šport iz tipa', () => { expect(sportOfType('VirtualRide')).toBe('kolo'); expect(sportOfType('Run')).toBe('tek'); expect(sportOfType('WeightTraining')).toBe('moc') })
  it('datumi', () => { expect(weekStartIso('2026-08-22')).toBe('2026-08-17'); expect(addDays('2026-08-31', 1)).toBe('2026-09-01') })
})

describe('deterministični načrt', () => {
  it('7 dni, kolo + moč 2×, prvi teden s testom (FTP brez datuma)', () => {
    const days = buildWeek({ profile: baseProfile(), activities: [], weekStart: '2026-08-17', firstWeek: true, notBefore: '2026-08-17' })
    expect(new Set(days.map(d => d.date)).size).toBe(7)
    expect(days.filter(d => d.kind === 'moc').length).toBe(2)
    expect(days.some(d => d.title.includes('20-minutni test'))).toBe(true)
    expect(days.every(d => d.date >= '2026-08-17' && d.date <= '2026-08-23')).toBe(true)
    expect(days.filter(d => d.kind === 'kolo' || d.kind === 'test').length).toBeGreaterThanOrEqual(3)   // pri malo urah: test + Z2 + daljša
    expect(days.find(d => d.date === '2026-08-17')!.kind).toBe('pocitek')   // ponedeljek počitek
  })
  it('utrujenost (TSB < -20) zniža obseg za 15 %', () => {
    const p = baseProfile()
    // forma se računa do DANES — zato je blok obremenitve relativen na danes (10 dni do vključno včeraj)
    const today = new Date(); const tIso = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`
    const heavy = Array.from({ length: 10 }, (_, i) => act({ date: addDays(tIso, -1 - i), tss: 150 }))
    const ws = weekStartIso(tIso)
    const a = buildWeek({ profile: p, activities: [], weekStart: ws })
    const b = buildWeek({ profile: p, activities: heavy, weekStart: ws })
    const sum = (d: typeof a) => d.reduce((s, x) => s + x.durationMin, 0)
    expect(sum(b)).toBeLessThan(sum(a))
    expect(b.some(d => (d.why || '').includes('−15 %'))).toBe(true)
  })
})

describe('prehrana — varovalke v aritmetiki', () => {
  it('BMR Mifflin-St Jeor; brez popolnega profila null', () => {
    expect(bmr(baseProfile())).toBe(Math.round(10 * 76 + 6.25 * 180 - 5 * 30 + 5))
    expect(bmr({ weightKg: 76, heightCm: null, age: 30, sex: 'm' })).toBeNull()
  })
  it('mladoletni: deficit 0, cilj nikoli pod vzdrževanje', () => {
    const p = baseProfile(); p.age = 16; p.goal = 'shujsati'
    expect(goalDeficit(p)).toBe(0)
    const t = dailyTarget(p, [], [])!
    expect(t.kcal).toBeGreaterThanOrEqual(t.maintenance); expect(t.minor).toBe(true)
  })
  it('deficit omejen na MAX_DEFICIT in na dno', () => {
    const p = baseProfile(); p.goal = 'shujsati'; p.sex = 'z'; p.weightKg = 50; p.heightCm = 160; p.age = 40; p.hoursPerWeek = 1
    const t = dailyTarget(p, [], [])!
    expect(t.maintenance - t.kcal).toBeLessThanOrEqual(MAX_DEFICIT)
    expect(t.kcal).toBeGreaterThanOrEqual(MIN_ABS_Z)
  })
  it('trening dvigne cilj že zjutraj (načrt), izmerjena vožnja ga nadomesti; brez stropa, le preverba smiselnosti', () => {
    const p = baseProfile()
    const base = dailyTarget(p, [], [])!
    const withRide = dailyTarget(p, [act({ durationMin: 120, kcal: 700 })], [])!
    expect(withRide.kcal - base.kcal).toBe(700)
    const planDay = { id: 'x', date: '2026-08-20', kind: 'kolo' as const, title: '', desc: '', durationMin: 180, zone: 'Z2', source: 'rules' as const, createdAt: now, updatedAt: now, kcalBurn: 1800 }
    const planned = dailyTarget(p, [], [planDay])!
    expect(planned.kcal - base.kcal).toBe(1800)                       // dolga vožnja šteje vsa (prej strop 1200)
    const done = dailyTarget(p, [act({ id: 'r1', durationMin: 180, kcal: 900 })], [{ ...planDay, done: { at: now, activityId: 'r1' } }])!
    expect(done.kcal - base.kcal).toBe(900)                            // dejanska poraba, ne načrt
    expect(done.plannedWas).toBe(1800); expect(done.plannedBurn).toBe(0)
    const unlinked = dailyTarget(p, [act({ id: 'r2', durationMin: 180, kcal: 950 })], [planDay])!
    expect(unlinked.kcal - base.kcal).toBe(950)                        // vožnja je tu, še ni povezana → ne dvakrat
    const manual = dailyTarget(p, [], [{ ...planDay, done: { at: now } }])!
    expect(manual.kcal - base.kcal).toBe(1800)                         // »Opravil«, vožnja še ni prišla → cilj ne pade
    const extra = dailyTarget(p, [act({ id: 'w', sport: 'pohod', durationMin: 60, kcal: 250 })], [planDay])!
    expect(extra.kcal - base.kcal).toBe(2050)                          // sprehod zjutraj + vožnja še pride
    const bogus = dailyTarget(p, [act({ durationMin: 60, kcal: 5000 })], [])!
    expect(bogus.kcal - base.kcal).toBe(1200)                          // napaka naprave: največ 1100/h + 100
    const walk = dailyTarget(p, [], [{ ...planDay, kind: 'pohod', optional: true }])!
    expect(walk.kcal).toBe(base.kcal)                                  // neobvezna hoja ne šteje vnaprej
  })
})

describe('načrt sredi tedna', () => {
  it('dnevi pred začetkom so »Pred začetkom«, dolga vožnja ni v preteklosti', () => {
    const days = buildWeek({ profile: baseProfile(), activities: [], weekStart: '2026-08-17', notBefore: '2026-08-21' })
    expect(days.filter(d => d.date < '2026-08-21').every(d => d.kind === 'pocitek' && d.title === 'Pred začetkom')).toBe(true)
    const active = days.filter(d => d.kind !== 'pocitek')
    expect(active.length).toBeGreaterThan(0)
    expect(active.every(d => d.date >= '2026-08-21')).toBe(true)
  })
  it('firstPlanWeekStart: pon–sre ta teden, čet+ naslednji', async () => {
    const { firstPlanWeekStart } = await import('../src/domain/training/planner')
    expect(firstPlanWeekStart('2026-08-18')).toBe('2026-08-17')   // torek
    expect(firstPlanWeekStart('2026-08-20')).toBe('2026-08-24')   // četrtek
    expect(firstPlanWeekStart('2026-08-23')).toBe('2026-08-24')   // nedelja
  })
})
