// v3.51 RECEPTI-NAPREDEK — prehranske želje po živilih (celiakija, zelje, svinjina, vegan, tofu, pescetarijanec, »ob petkih«,
// čebula in česen, sladkor, »ne pijem mleka«), 14-dnevne simulacije brez puščanja in z raznolikostjo, recept za več oseb,
// nakupovalni seznam, besedila »zakaj«, Napredek (kartica cilja, mesec, Motor, rekordi, tehtanja, testi, moč).
import 'fake-indexeddb/auto'
import { readFileSync } from 'fs'
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'prehrana', params: {} as Record<string, string> }, nav: [] as unknown[][] }))
vi.mock('@/state/store', async (orig) => ({
  ...(await orig<typeof import('../src/state/store')>()),
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  addMeal: async () => undefined,
  toast: () => undefined,
  setRecipeAlt: async () => undefined,
}))
vi.mock('@/app/router', () => ({ navigate: (...a: unknown[]) => { S.nav.push(a) }, useRoute: () => S.route, subscribeRoute: () => () => undefined }))

import * as repo from '../src/data/repo'
import { Prehrana } from '@/screens/Prehrana'
import { Napredek, weightPace, hoursTxt, e1rmTxt, setTxt, customHead } from '@/screens/Napredek'
import { GoalCard } from '@/ui/GoalCard'
import { RecordsCard } from '@/ui/RecordsCard'
import {
  DISHES, LF_DISHES, dishesFor, exclusionsOf, recipeOkFor, fitDish, whyRecipe, scaleText, scaleSteps, scaleIngredients, shoppingGroups,
  foodPrefsFromWish, soyOk, prefsOn, prefsNote, shopGotOf, type Recipe,
} from '../src/domain/nutrition/recipes'
import { F, measureOf, qtyText } from '../src/domain/nutrition/dayplan'
import { dayMealsOf, recipeCtxOf, recipesOf } from '../src/domain/nutrition/daymeals'
import { dailyTarget } from '../src/domain/nutrition/energy'
import { addDays } from '../src/domain/training/load'
import { FRANJA_2027 } from '../src/domain/training/planner'
import { normalizeFocus } from '../src/domain/focus/model'
import type { Activity, PlanDay, Profile } from '../src/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const NOW = '2026-10-01T08:00:00.000Z'
const TODAY = '2026-10-23'
const nb = (s: string | null | undefined) => (s || '').replace(/[  ⁠]/g, ' ')
const P = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, restHr: 55, maxHr: 200, lthr: 184, ftp: 240, ftpDate: '2026-09-20',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, hoursPerWeek: 14, baseHours: null,
  strength: { on: false, equipment: 'home', phases: null }, strengthDays: 0, goal: 'dirka', deficit: 400, neat: 1.4,
  event: null, cycleStart: '2026-09-21', onboardingDone: true, trainTime: 'popoldne', createdAt: NOW, updatedAt: NOW,
  races: [], ...o,
} as Profile)
const day = (date: string, kind: PlanDay['kind'], min: number, o: Partial<PlanDay> = {}): PlanDay => ({ id: `${kind}${date}`, date, kind, title: kind === 'pocitek' ? 'Počitek' : 'Vožnja', desc: '', durationMin: min, zone: 'Z2', role: kind === 'pocitek' ? 'pocitek' : 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, ...o } as PlanDay)
const weekDay = (i: number, d: string): PlanDay => [day(d, 'pocitek', 0), day(d, 'kolo', 60), day(d, 'kolo', 75, { role: 'kljucna', zone: 'Z4' }), day(d, 'pocitek', 0), day(d, 'kolo', 60), day(d, 'kolo', 180, { role: 'dolga' }), day(d, 'kolo', 90)][i % 7]!
const dish = (id: string) => [...DISHES, ...LF_DISHES].find(d => d.id === id)
const rec = (name: string, ...ing: string[]) => ({ name, ingredients: ing.map((text, i) => ({ key: 'ai' + i, qty: 0, text })) })

/* ---------- 14-dnevne simulacije: brez puščanja in z raznolikostjo ---------- */

const GLU = new Set(['kruh', 'belkruh', 'testenine', 'testenineb', 'kuskus', 'oves', 'jesprenj', 'moka'])
const txt = (r: Recipe) => [r.name, ...r.ingredients.map(i => i.text)].join(' | ').toLowerCase()
const keys = (r: Recipe) => r.ingredients.map(i => i.key)
const isFri = (d: string) => new Date(`${d}T12:00:00Z`).getUTCDay() === 5
type Prof = { name: string; prefs: string; p?: Profile; leak: (r: Recipe, d: string) => boolean; free?: boolean }
const PROFILES: Prof[] = [
  { name: 'vsejedec', prefs: '', leak: () => false, free: true },
  { name: 'ženska 58 kg', prefs: '', p: P({ sex: 'z', weightKg: 58, heightCm: 165, age: 30, goal: 'shujsati' as Profile['goal'] }), leak: () => false, free: true },
  { name: 'vegan', prefs: 'vegan', leak: r => !!dish(r.dish)?.contains.some(c => ['meso', 'riba', 'mleko', 'jajca'].includes(c)) || keys(r).some(k => ['med', 'jogurt', 'skuta', 'mleko', 'jajce', 'kefir', 'sir'].includes(k)) },
  { name: 'celiakija', prefs: 'celiakija', leak: r => !!dish(r.dish)?.contains.includes('gluten') || keys(r).some(k => GLU.has(k)) },
  { name: 'ne maram zelja', prefs: 'ne maram zelja', leak: r => keys(r).includes('zelje') || /zelje|zeljem/.test(txt(r)) },
  { name: 'ne jem svinjine', prefs: 'ne jem svinjine', leak: r => /svinj|pršut|slanin|ocvirk|klobas|salam/.test(txt(r)) },
  { name: 'ne maram tofuja', prefs: 'ne maram tofuja', leak: r => keys(r).includes('tofu') || /tofu/.test(txt(r)) },
  { name: 'pescetarijanec', prefs: 'vegetarijanec, jem pa ribe', leak: r => !!dish(r.dish)?.contains.includes('meso') },
  { name: 'ob petkih', prefs: 'ne jem mesa ob petkih', leak: (r, d) => isFri(d) && !!dish(r.dish)?.contains.includes('meso') },
  { name: 'čebula in česen', prefs: 'ne maram čebule in česna', leak: r => keys(r).includes('cebula') },
  { name: 'brez sladkorja', prefs: 'brez sladkorja', leak: r => keys(r).some(k => k === 'med' || k === 'marmelada' || k === 'sok') },
  { name: 'diabetes', prefs: 'sladkorna bolezen', leak: r => keys(r).some(k => k === 'med' || k === 'marmelada' || k === 'sok') },
  { name: 'oreški, ribe', prefs: 'alergija na oreške, ne maram rib', leak: r => !!dish(r.dish)?.contains.some(c => c === 'oreski' || c === 'riba') },
  { name: 'ne pijem mleka', prefs: 'ne pijem mleka', leak: r => keys(r).includes('mleko') },
]
const STARTS = ['2026-10-19', '2026-10-26', '2026-11-02', '2026-11-23']
function twoWeeks(pr: Prof, start: string) {
  const p = pr.p || P(), by: Record<string, string[]> = {}, all: { d: string; r: Recipe }[] = [], rest: { got: number; goal: number }[] = []
  for (let i = 0; i < 14; i++) {
    const d = addDays(start, i), plan = [weekDay(i, d)]
    const t = dailyTarget(p, [], plan, d, { today: d, hour: 9 })!
    const settings = { foodPrefs: pr.prefs, dayMenus: null }
    const dm = dayMealsOf({ p, target: t, plan, activities: [], meals: [], recentMeals: [], weather: null, day: d, today: d })
    const r = recipesOf(dm.dp, d, recipeCtxOf(p, t, settings, dm.training), settings)
    for (const s of dm.dp.slots) if (r[s.key]) { (by[s.key] ||= []).push(r[s.key]!.dish); all.push({ d, r: r[s.key]! }) }
    if (!dm.training) rest.push({ got: Object.values(r).reduce((a, x) => a + x.c, 0), goal: dm.dp.slots.filter(s => r[s.key]).reduce((a, s) => a + s.carbsG, 0) })
  }
  const maxRep = Math.max(...Object.values(by).map(v => Math.max(...Object.values(v.reduce<Record<string, number>>((c, n) => ({ ...c, [n]: (c[n] || 0) + 1 }), {})))))
  return { by, all, maxRep, rest }
}

describe('E07, E16 in želje — 14 dni, 14 profilov, 4 začetni datumi', () => {
  const runs = PROFILES.flatMap(pr => STARTS.map(st => ({ pr, st, w: twoWeeks(pr, st) })))
  it('nobena jed, ki je želje ne dovolijo (0 puščanj v 14 × 14 × 4 dneh)', () => {
    for (const { pr, st, w } of runs) {
      const bad = w.all.filter(x => pr.leak(x.r, x.d))
      expect(bad.map(x => `${x.d} ${x.r.name}`), `${pr.name} od ${st}`).toEqual([])
    }
  })
  it('raznolikost: vsejedec ≤ 5× ista jed v istem obroku, omejene diete ≤ 7× (prej sendvič 10 od 14, polenta 8 od 14)', () => {
    for (const { pr, st, w } of runs) expect(w.maxRep, `${pr.name} od ${st}: ${JSON.stringify(w.by)}`).toBeLessThanOrEqual(pr.free ? 5 : 7)
  })
  it('»ob petkih«: meso ostane ostale dni; pescetarijanec dobi ribe', () => {
    for (const { pr, w } of runs) {
      if (pr.name === 'ob petkih') expect(w.all.filter(x => !isFri(x.d) && dish(x.r.dish)?.contains.includes('meso')).length).toBeGreaterThan(5)
      if (pr.name === 'pescetarijanec') expect(w.all.filter(x => dish(x.r.dish)?.contains.includes('riba')).length).toBeGreaterThan(3)
    }
  })
  it('E16: dan brez vadbe — OH receptov skupaj največ 12 % čez cilj (ženska 58 kg, prej +24 %)', () => {
    for (const { pr, st, w } of runs.filter(x => x.pr.name === 'ženska 58 kg' || x.pr.name === 'vsejedec')) for (const x of w.rest) expect(x.got, `${pr.name} od ${st}`).toBeLessThanOrEqual(x.goal * 1.12 + 1)
  })
})

/* ---------- želje po živilih ---------- */

describe('E01 — celiakija: AI recept z glutenom ne gre skozi', () => {
  it('müsli, pica, burek, granola, krekerji, drobtine, keksi, pecivo → zavrnjen; koruzni kosmiči brez glutena ostanejo', () => {
    for (const t of ['müsli 60 g', 'pica 300 g', 'burek 200 g', 'granola 50 g', 'krekerji 40 g', 'drobtine 30 g', 'keksi 40 g', 'pecivo 80 g', 'pirin kruh 60 g', 'panirani piščanec 150 g'])
      expect(recipeOkFor(rec('Obrok', t), 'celiakija'), t).toBe(false)
    expect(recipeOkFor(rec('Grški jogurt z granolo', 'grški jogurt 200 g'), 'brez glutena')).toBe(false)
    expect(recipeOkFor(rec('Kosmiči', 'koruzni kosmiči brez glutena 50 g', 'mleko 200 ml'), 'celiakija')).toBe(true)
    expect(recipeOkFor(rec('Riž s piščancem', 'riž 80 g', 'piščanec 150 g', '1 zavitek tofuja'), 'celiakija')).toBe(true)
  })
})

describe('E02 — »ne maram zelja« izloči samo zelje', () => {
  it('kosila, večerje in obnova ostanejo (prej 14 → 5 kosil); jota gre', () => {
    for (const tpl of ['kosilo', 'vecerja', 'obnova', 'zajtrk']) {
      const all = dishesFor(tpl, ''), z = dishesFor(tpl, 'ne maram zelja')
      expect(z.length, tpl).toBeGreaterThanOrEqual(all.length - 1)
      expect(z.some(d => d.id === 'jota'), tpl).toBe(false)
    }
    // kratke besede še vedno zadenejo: »ne maram tune«, »ne maram riža«, »ne maram sira«
    expect(dishesFor('kosilo', 'ne maram tune').some(d => d.items.some(([k]) => k === 'tuna'))).toBe(false)
    expect(dishesFor('kosilo', 'ne maram riža').some(d => d.items.some(([k]) => k === 'riz'))).toBe(false)
  })
})

describe('E09, E10 — svinjina, halal, vegan', () => {
  it('»ne jem svinjine« in »halal«: pršut, ocvirki, slanina zavrnjeni; puranja šunka ostane', () => {
    for (const prefs of ['ne jem svinjine', 'halal']) {
      expect(recipeOkFor(rec('Sendvič s pršutom', 'kruh 80 g', 'pršut 40 g'), prefs), prefs).toBe(false)
      expect(recipeOkFor(rec('Ajdovi žganci z ocvirki', 'ajdova moka 100 g', 'ocvirki 30 g'), prefs), prefs).toBe(false)
      expect(recipeOkFor(rec('Jajca', '3 jajca', 'slanina 30 g'), prefs), prefs).toBe(false)
      expect(recipeOkFor(rec('Sendvič', 'kruh 80 g', 'puranja šunka 60 g'), prefs), prefs).toBe(true)
    }
  })
  it('vegan: whey in želatina zavrnjena', () => {
    expect(recipeOkFor(rec('Ovseni kosmiči', 'ovseni kosmiči 60 g', 'whey protein 30 g'), 'vegan')).toBe(false)
    expect(recipeOkFor(rec('Sadni žele', 'sadje 150 g', 'želatina 10 g'), 'vegan')).toBe(false)
    expect(recipeOkFor(rec('Ovseni kosmiči', 'ovseni kosmiči 60 g', 'sojin napitek 250 ml'), 'vegan')).toBe(true)
  })
})

describe('E11, E12, E13, E42 — tofu, pescetarijanec, »ob petkih«, »ne pijem mleka«', () => {
  it('»ne maram tofuja« ne doda soje vsejedcu', () => {
    for (const tpl of ['zajtrk', 'kosilo', 'malica']) expect(dishesFor(tpl, 'ne maram tofuja').length, tpl).toBeLessThanOrEqual(dishesFor(tpl, '').length)
    expect(soyOk(exclusionsOf('ne maram tofuja'), 'ne maram tofuja')).toBe(false)
    expect(soyOk(exclusionsOf('rad imam tofu'), 'rad imam tofu')).toBe(true)
  })
  it('»vegetarijanec, jem pa ribe«: brez mesa, ribe ostanejo; iz uvoda »pescetarijansko«', () => {
    expect(exclusionsOf('vegetarijanec, jem pa ribe').contains).toEqual(['meso'])
    expect(foodPrefsFromWish('Sem vegetarijanec, jem pa ribe.')).toBe('pescetarijansko')
    expect(exclusionsOf('vegetarijanec').contains.sort()).toEqual(['meso', 'riba'])
    expect(exclusionsOf('vegetarijanec, alergija na ribe').contains).toContain('riba')
  })
  it('»ne jem mesa ob petkih«: meso samo ob petkih izločeno (prej vse dni); beseda »petkih« ni živilo', () => {
    expect(exclusionsOf('ne jem mesa ob petkih', '2026-10-23').contains).toEqual(['meso'])   // petek
    expect(exclusionsOf('ne jem mesa ob petkih', '2026-10-26').contains).toEqual([])   // ponedeljek
    expect(exclusionsOf('ne jem mesa ob petkih').words).toEqual([])
    expect(prefsOn('brez laktoze, ne jem mesa ob petkih', '2026-10-26')).toBe('brez laktoze')
    expect(recipeOkFor(rec('Piščanec z rižem', 'piščanec 150 g'), 'ne jem mesa ob petkih', '2026-10-23')).toBe(false)
    expect(recipeOkFor(rec('Piščanec z rižem', 'piščanec 150 g'), 'ne jem mesa ob petkih', '2026-10-26')).toBe(true)
  })
  it('»ne pijem mleka«: brez jedi z mlekom, jogurt in skuta ostaneta', () => {
    const ex = exclusionsOf('ne pijem mleka')
    expect(ex.words).toContain('mleka')
    expect(ex.contains).toEqual([])
    expect(dishesFor('zajtrk', 'ne pijem mleka').some(d => d.items.some(([k]) => k === 'mleko'))).toBe(false)
    expect(dishesFor('zajtrk', 'ne pijem mleka').some(d => d.items.some(([k]) => k === 'jogurt'))).toBe(true)
  })
})

describe('E25, E26, E41 — čebula in česen, sladkor, želje iz uvoda', () => {
  it('»ne maram čebule«: jedi ostanejo, sestavine ni, prvi korak pove, da jo izpustiš', () => {
    expect(dishesFor('kosilo', 'ne maram čebule').length).toBe(dishesFor('kosilo', '').length)
    const r = fitDish(DISHES.find(d => d.id === 'pisc-riz')!, 700, 45, { deficit: false, prefs: 'ne maram čebule in česna' })
    expect(r.ingredients.some(i => i.key === 'cebula')).toBe(false)
    expect(r.steps[0]).toMatch(/^Brez čebule in česna/)
    // alergija ostane izločitev
    expect(dishesFor('kosilo', 'alergija na čebulo').some(d => d.items.some(([k]) => k === 'cebula'))).toBe(false)
    // samo česen: čebula ostane v sestavinah brez česna
    const g = fitDish(DISHES.find(d => d.id === 'pisc-riz')!, 700, 45, { deficit: false, prefs: 'ne maram česna' })
    expect(g.ingredients.find(i => i.key === 'cebula')!.text).toMatch(/^čebula \d+ g$/)
    expect(g.steps[0]).toBe('Brez česna: v korakih ga izpusti.')
  })
  it('»brez sladkorja« in sladkorna bolezen: brez medu in marmelade; opomba za diabetes in keto', () => {
    const r = fitDish(DISHES.find(d => d.id === 'kasa')!, 600, 30, { deficit: false, prefs: 'brez sladkorja' })
    expect(r.ingredients.some(i => i.key === 'med')).toBe(false)
    expect(r.name).toMatch(/\(brez medu\)/)
    expect(recipeOkFor(rec('Kruh z medom', 'kruh 60 g', 'med 20 g'), 'sladkorna bolezen')).toBe(false)
    expect(prefsNote('sladkorna bolezen')).toMatch(/Posvetuj se z zdravnikom/)
    expect(prefsNote('keto')).toBeTruthy()
    expect(prefsNote('brez laktoze')).toBeNull()
  })
  it('iz uvoda se prenesejo »ne jem svinjine«, »ne maram česna«, »ne maram kaše«', () => {
    expect(foodPrefsFromWish('Ne jem svinjine.')).toBe('ne jem svinjine')
    expect(foodPrefsFromWish('Ne maram česna.')).toBe('ne maram česna')
    expect(foodPrefsFromWish('Ne maram kaše.')).toBe('ne maram kaše')
    expect(foodPrefsFromWish('Ne maram teka.')).toBeNull()
  })
})

/* ---------- besedilo »zakaj« in jedi ---------- */

describe('E14, E15, E19 — zakaj zate', () => {
  const ctx = { deficit: false, keepMuscle: false, training: false }
  it('OH malo čez cilj obroka (+5 g): brez opozorila; velik presežek imenuje sestavino', () => {
    expect(whyRecipe({ p: 30, c: 30, f: 5 }, { key: 'malica', proteinG: 25, carbsG: 25 }, ctx)).not.toMatch(/cilja? obroka/)
    const r = fitDish(DISHES.find(d => d.id === 'polenta-z')!, 560, 39, { deficit: false, training: false }, 61)
    const w = whyRecipe({ ...r, c: 82 }, { key: 'zajtrk', proteinG: 39, carbsG: 61 }, ctx)
    expect(w).toMatch(/82 g ogljikovih hidratov \(cilj obroka 61 g\) — vzemi ~\d+ g polente namesto \d+ g/)
    expect(w).not.toMatch(/priloge/)
  })
  it('OH čez cilj in premalo beljakovin: ne »čičeriko« (doda OH)', () => {
    const w = whyRecipe({ p: 20, c: 102, f: 8, ingredients: [{ key: 'leca', qty: 250, text: '' }, { key: 'krompir', qty: 150, text: '' }] }, { key: 'vecerja', proteinG: 43, carbsG: 69 }, { ...ctx, prefs: 'vegan' })
    expect(w).not.toMatch(/čičerik/)
    expect(w).toMatch(/tofu/)
  })
  it('pred vadbo in startom: brez »dodaj jogurt ali skuto«', () => {
    const w = whyRecipe({ p: 4, c: 46, f: 1 }, { key: 'pred', proteinG: 10, lf: true, label: 'Pred startom' }, ctx)
    expect(w).not.toMatch(/dodaj|beljakovin/)
    expect(w).toBe('46 g lahkih ogljikovih hidratov za energijo na startu.')
  })
})

describe('E17, E18, E28, E32 — jedi', () => {
  it('kruh s tofujem: vsaj rezina kruha in 50 g solate, beljakovine z več tofuja (prej ½ rezine)', () => {
    const r = fitDish(DISHES.find(d => d.id === 'tofu-kruh')!, 260, 26, { deficit: true, prefs: 'vegan' })
    expect(r.ingredients.find(i => i.key === 'kruh')!.qty).toBeGreaterThanOrEqual(30)
    expect(r.ingredients.find(i => i.key === 'kruh')!.text).toMatch(/\(1 rezina\)/)
    expect(r.p).toBeGreaterThanOrEqual(26 * 0.75)
    expect(r.ingredients.find(i => i.key === 'solata')!.qty).toBeGreaterThanOrEqual(50)
  })
  it('slan obrok z manjkom beljakovin: ne »zraven: grški jogurt 300 g« — kuhana jajca ali jogurt za sladico do 150 g', () => {
    for (const id of ['leca-riz', 'krompir-cic-o', 'kuskus-cic-o']) {
      const r = fitDish(DISHES.find(d => d.id === id)!, 900, 55, { deficit: false })
      for (const i of r.ingredients.filter(x => x.side && x.key === 'jogurt')) { expect(i.qty, id).toBeLessThanOrEqual(150); expect(i.text).toMatch(/^za sladico:/) }
      expect(r.ingredients.some(i => i.side && /^zraven: \d kuhan/.test(i.text)) || !r.ingredients.some(i => i.side && i.key === 'jajce'), id).toBe(true)
    }
  })
  it('pred vadbo: čas pove glava obroka, ne korak (prej »45–60 min pred vadbo« pod »30–60 min prej«)', () => {
    for (const d of [...DISHES, ...LF_DISHES].filter(x => x.tpl === 'pred')) for (const s of [...d.steps, ...(d.vg?.steps || [])]) expect(s, d.id).not.toMatch(/min pred|uro pred/)
  })
  it('kaša: ne »(2 : 1)«', () => {
    for (const d of DISHES) expect(d.steps.join(' '), d.id).not.toMatch(/2 : 1/)
  })
})

/* ---------- recept za več oseb ---------- */

describe('E08, E22, E33–E38 — količine', () => {
  it('koraki za več oseb: voda in grami (prej »320 g zdroba v 3 dl vode«)', () => {
    expect(scaleSteps(['Koruzni zdrob vsipaj v 3 dl vrele slane vode.'], 4)).toEqual(['Koruzni zdrob vsipaj v 12 dl vrele slane vode.'])
    expect(scaleSteps(['Ješprenj kuhaj v 1 l vode 20 min, na 200 °C.'], 3)).toEqual(['Ješprenj kuhaj v 3 l vode 20 min, na 200 °C.'])
    expect(scaleSteps(['kuhaj 3–4 min'], 4)).toEqual(['kuhaj 3–4 min'])
    expect(scaleSteps(['v 3 dl'], 1)).toEqual(['v 3 dl'])
  })
  it('pridevnik in samostalnik, »pol«, enote brez ulomkov', () => {
    expect(scaleText('1 srednja čebula', 3)).toBe('3 srednje čebule')
    expect(scaleText('2 veliki jajci', 3)).toBe('6 velikih jajc')
    expect(scaleText('1 manjša bučka', 4)).toBe('4 manjše bučke')
    expect(scaleText('1 bučka', 3)).toBe('3 bučke')
    expect(scaleText('1 tortilja', 2)).toBe('2 tortilji')
    expect(scaleText('1 ščep soli', 3)).toBe('3 ščepi soli')
    expect(scaleText('1 vejica rožmarina', 4)).toBe('4 vejice rožmarina')
    expect(scaleText('pol limone', 3)).toBe('1½ limone')
    expect(scaleText('12,5 g masla', 3)).toBe('40 g masla')
    expect(scaleText('0,5 l mleka', 3)).toBe('1,5 l mleka')
    expect(scaleText('400 g piščanca', 3)).toBe('1,2 kg piščanca')
  })
  it('qtyText od 1000 v l in kg; domače mere do 5 žlic; krompir po pol kosa', () => {
    expect(qtyText('mleko', 1200)).toBe('mleko 1,5 % 1,2 l')
    expect(qtyText('jogurt', 1320)).toMatch(/^grški jogurt 2 % 1,3 kg/)
    expect(nb(measureOf('riz', 400))).toBe('kuhanega ≈ 1 040 g')
    expect(measureOf('med', 60)).toBeNull()
    expect(measureOf('med', 20)).toBe('3 žličke')
    expect(measureOf('oves', 280)).toBeNull()
    expect(measureOf('krompir', 80)).toBe('≈ ½ kosa')
    expect(measureOf('krompir', 200)).toBe('≈ 1½ kosa')
    expect(measureOf('krompir', 300)).toBe('≈ 2 kosa')
  })
  it('recept za 3 osebe: dodatek ostane »zraven« z obliko', () => {
    const r = { ingredients: [{ key: 'jajce', qty: 2, text: 'zraven: 2 kuhani jajci', side: true }, { key: 'jogurt', qty: 150, text: 'za sladico: grški jogurt 2 % 150 g', side: true }] }
    expect(scaleIngredients(r, 3)).toEqual(['zraven: 6 kuhana jajca', 'za sladico: grški jogurt 2 % 450 g (3 lončki po 150 g)'])
  })
})

/* ---------- nakupovalni seznam ---------- */

describe('E20, E21, E29, E30, E31, E39 — nakupovalni seznam', () => {
  const g = (rs: { dish: string; ingredients: { key: string; qty: number; text: string }[] }[], prefs?: string) => shoppingGroups(rs, prefs)
  const lines = (x: ReturnType<typeof g>) => x.flatMap(y => y.items)
  it('čičerika in fižol posebej (prej »fižol ali čičerika«)', () => {
    const l = lines(g([{ dish: 'cicerika', ingredients: [{ key: 'cicerika', qty: 250, text: '' }] }, { dish: 'jota', ingredients: [{ key: 'fizol', qty: 200, text: '' }] }]))
    expect(l.some(x => /fižol ali čičerika/.test(x))).toBe(false)
    expect(l).toContain('čičerika (kuhana): 250 g (2 pločevinki po 240 g)')
    expect(l).toContain('fižol (kuhan): 200 g (1 pločevinka po 240 g)')
    expect(DISHES.find(d => d.id === 'cicerika')!.items.some(([k]) => k === 'cicerika')).toBe(true)
    expect(F.cicerika!.kcal).toBe(F.fizol!.kcal)
  })
  it('solata in paradižnik posebej, jabolka v eni vrstici, zelena (gomolj), začimbe iz korakov', () => {
    const l = lines(g([
      { dish: 'kruh-skuta', ingredients: [{ key: 'solata', qty: 620, text: '' }] },
      { dish: 'banana-or', ingredients: [{ key: 'jabolko', qty: 1, text: '' }, { key: 'sadje', qty: 670, text: '' }] },
      { dish: 'ricet', ingredients: [{ key: 'zelenjava', qty: 140, text: '' }] },
      { dish: 'oslic-kr', ingredients: [{ key: 'oslic', qty: 180, text: '' }] },
    ]))
    expect(l.some(x => /zelena solata in paradižnik/.test(x))).toBe(false)
    expect(l).toContain('paradižnik: 380 g (≈ 3 kosi)')
    expect(l).toContain('zelena solata: 250 g (≈ 1 glava)')
    expect(l.filter(x => /jabolk/.test(x))).toEqual(['jabolka ali hruške: ≈ 5 kosov'])
    expect(l).toContain('zelena (gomolj): 70 g')
    expect(l).toEqual(expect.arrayContaining(['limona', 'lovorov list', 'česen']))
    expect(g([{ dish: 'oslic-kr', ingredients: [] }])[0]!.title).toBe('Začimbe in drobno')
  })
  it('»ne maram čebule in česna«: ni ju v nakupu', () => {
    const l = lines(g([{ dish: 'pec-pisc', ingredients: [{ key: 'zelenjava', qty: 300, text: '' }] }, { dish: 'oslic-kr', ingredients: [] }], 'ne maram čebule in česna'))
    expect(l.some(x => /čebula|česen/.test(x))).toBe(false)
  })
  it('kljukice veljajo 7 dni od začetka (prej do ponedeljka)', () => {
    expect(shopGotOf({ from: '2026-10-24', got: { a: true } }, '2026-10-26')).toEqual({ from: '2026-10-24', got: { a: true } })   // sobota → ponedeljek
    expect(shopGotOf({ from: '2026-10-24', got: { a: true } }, '2026-10-30')).toEqual({ from: '2026-10-24', got: { a: true } })
    expect(shopGotOf({ from: '2026-10-24', got: { a: true } }, '2026-10-31')).toEqual({ from: '2026-10-31', got: {} })
    expect(shopGotOf({ a: true }, '2026-10-26')).toEqual({ from: '2026-10-26', got: {} })
    expect(shopGotOf(null, '2026-10-26')).toEqual({ from: '2026-10-26', got: {} })
  })
})

/* ---------- zaslon Prehrana: deli, kljukice, opomba, čipi ---------- */

let div: HTMLDivElement, root: Root
const mount = async (el: React.ReactElement) => { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div); await act(async () => { root.render(el) }) }
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(b.textContent || '') || re.test(b.getAttribute('aria-label') || ''))
async function click(el: Element | undefined | null) { expect(el).toBeTruthy(); await act(async () => { (el as HTMLElement).click(); await new Promise(r => setTimeout(r, 0)) }) }
const text = () => nb(document.body.textContent)
beforeEach(() => { try { localStorage.clear() } catch { /* */ } S.nav.length = 0 })
afterEach(async () => { if (root) await act(async () => root.unmount()); div?.remove(); vi.useRealTimers(); if (location.hash) location.hash = ''; S.route = { name: 'prehrana', params: {} } })
function setPrehrana(o: { prefs?: string | null } = {}) {
  vi.useFakeTimers({ toFake: ['Date'] })
  vi.setSystemTime(new Date(`${TODAY}T08:30:00`))
  S.state = { ready: true, settings: { ...repo.defaultSettings(), foodPrefs: o.prefs ?? null }, changes: [], toast: null, sync: { state: 'off' }, authKnown: true, pro: false, wellness: null, checkinToday: null, today: TODAY, profile: P(), plan: [day(TODAY, 'kolo', 90)], activities: [], mealsToday: [], recentMeals: [], checkins: [], weather: null, user: null }
}

describe('Prehrana — nakup in želje (E39, E40, E26, E13, E23)', () => {
  it('»Deli seznam« pošlje seznam brez odkljukanih; kljukice se shranijo z dnem začetka', async () => {
    setPrehrana()
    const share = vi.fn(async () => undefined)
    Object.defineProperty(navigator, 'share', { value: share, configurable: true })
    await mount(<Prehrana />)
    await click(btn(/^nakupovalni seznam$/))
    for (let i = 0; i < 100 && !document.querySelector('.shop-list button'); i++) await act(async () => { await new Promise(r => setTimeout(r, 10)) })
    const first = [...document.querySelectorAll('.shop-list button')][0]!
    const name = first.textContent!
    await click(first)
    expect(JSON.parse(localStorage.getItem('formai.shop')!)).toEqual({ from: TODAY, got: { [name.split(':')[0]!.trim()]: true } })
    await click(btn(/^Deli seznam$/))
    expect(share).toHaveBeenCalledTimes(1)
    const sent = (share.mock.calls[0] as unknown as [{ text: string }])[0].text
    expect(sent.length).toBeGreaterThan(10)
    expect(sent.split('\n')).not.toContain(name)
    expect(text()).toMatch(/kljukice ostanejo 7 dni/)
    delete (navigator as { share?: unknown }).share
  })
  it('list želja: opomba za sladkorno bolezen in za del »ob petkih«', async () => {
    setPrehrana({ prefs: 'sladkorna bolezen, ne jem mesa ob petkih' })
    await mount(<Prehrana />)
    await click(btn(/^želje:/))
    expect(text()).toMatch(/Sladkorne bolezni in keto prehrane recepti ne upoštevajo/)
    expect(text()).toMatch(/velja samo na ta dan/)
  })
  it('CSS: čipi za osebe in gumbi recepta 40 px', () => {
    const css = readFileSync('src/styles/base.css', 'utf8')
    expect(css).toMatch(/\.recipe-persons \.chip\.sm \{ min-width: 40px; min-height: 40px;/)
    expect(css).toMatch(/\.recipe-acts \.chip\.sm, \.shop-days \.chip \{ min-height: 40px; \}/)
    expect(css).toMatch(/\.chip\.icon-x \{ min-width: 40px; min-height: 40px;/)
  })
})

/* ---------- Napredek ---------- */

const NAP_TODAY = '2026-10-23'
const act1 = (id: string, date: string, o: Partial<Activity> = {}): Activity => ({ id, source: 'manual', sport: 'kolo', date, name: 'Vožnja ' + id, durationMin: 90, distKm: 40, elevM: 300, tss: 70, aiEligible: true, geoRetain: true, createdAt: NOW, updatedAt: NOW, ...o } as Activity)
function setNap(o: { profile?: Profile; activities?: Activity[]; checkins?: any[]; tests?: any[]; plan?: PlanDay[] } = {}) {
  S.route = { name: 'napredek', params: {} }
  S.state = { ready: true, settings: { ...repo.defaultSettings(), tests: o.tests || [] }, changes: [], toast: null, sync: { state: 'off' }, authKnown: true, pro: false, wellness: null, checkinToday: null, today: NAP_TODAY, profile: o.profile || P({ deficit: 0, event: { ...FRANJA_2027 }, weightKg: 79.9 }), plan: o.plan || [], activities: o.activities || [], mealsToday: [], recentMeals: [], checkins: o.checkins || [], weather: null, user: null }
}

describe('GoalCard — E03, E04, E05, E27, E55', () => {
  it('E04: mejnik v preteklosti brez dosežka nima kljukice »doseženo«', async () => {
    setNap({ profile: P({ ftp: 240, weightKg: 80, deficit: 400, event: { ...FRANJA_2027 }, goalStart: { date: '2026-01-05', ftp: 240, weightKg: 80 } } as Partial<Profile>), checkins: [{ date: NAP_TODAY, weightKg: 80 }] })
    await mount(<GoalCard full />)
    expect(div.querySelectorAll('[aria-label="doseženo"]').length).toBe(0)
    expect(text()).toMatch(/zdaj 3,00/)
  })
  it('E05, E27: brez deficita ni »Najboljša teža«; ročni cilj 72 kg je »Tvoj cilj 72 kg« (ne »72,0« ali »74,0«)', async () => {
    setNap({ profile: P({ deficit: 0, event: { ...FRANJA_2027 }, weightKg: 79.9, goalStart: { date: '2026-09-21', ftp: 240, weightKg: 79.9 } } as Partial<Profile>) })
    await mount(<GoalCard full />)
    expect(text()).not.toMatch(/Najboljša teža/)
    expect(text()).toMatch(/Teže ne spreminjaš — cilj so vati/)
    await act(async () => root.unmount()); div.remove()
    setNap({ profile: P({ deficit: 400, event: { ...FRANJA_2027 }, targetWeightKg: 72, weightKg: 79.9 } as Partial<Profile>) })
    await mount(<GoalCard full />)
    expect(text()).toMatch(/Tvoj cilj 72 kg/)
    expect(text()).not.toMatch(/72,0|74,0/)
  })
  it('E03: ena številka »ta teden« (prej »0,8 h ta teden« in »ta teden 4 h«)', async () => {
    const acts = Array.from({ length: 8 }, (_, i) => act1('a' + i, addDays('2026-10-20', -Math.round(i * 3.5 + 3))))
    setNap({ profile: P({ deficit: 0, event: { ...FRANJA_2027 }, hoursPerWeek: 11, goalStart: { date: '2026-09-21', ftp: 240, weightKg: 79 } } as Partial<Profile>), activities: acts, plan: [day('2026-10-24', 'kolo', 48)] })
    await mount(<GoalCard full />)
    const t = text()
    const nums = [...t.matchAll(/(\d+(?:,\d+)?) h ta teden|ta teden (\d+(?:,\d+)?) h/g)].map(m => m[1] ?? m[2])
    expect(nums.length, t).toBe(2)
    expect(new Set(nums).size, t).toBe(1)
  })
  it('E55: brez FTP ni tabele mejnikov', async () => {
    setNap({ profile: P({ ftp: null, ftpDate: null, deficit: 0, event: { ...FRANJA_2027 }, goalStart: { date: '2026-09-21', ftp: null, weightKg: 80 } } as Partial<Profile>) })
    await mount(<GoalCard full />)
    expect(div.querySelector('table')).toBeNull()
  })
})

describe('E06 — tempo, ko je cilj dosežen šele po tekmi', () => {
  it('ni »Tempo je pravi« in ni zeleno', () => {
    const ev = { name: 'Maraton Franja', date: '2027-06-13' }
    const x = weightPace({ stale: false, dw: 0, rate: -0.2, target: 72, avg7: 80, today: '2026-11-01', noise: 0.05, nPace: 14, event: ev })
    expect(x.text).not.toMatch(/Tempo je pravi/)
    expect(nb(x.text)).toMatch(/Tempo je skoraj pravi — pri tem tempu je cilj dosežen ~\d+\. \d+\. 2027, \d+ dni po tekmi \(Maraton Franja\)\./)
    expect(x.color).not.toBe('var(--ok)')
    // pravočasno: kot prej
    expect(weightPace({ stale: false, dw: 0, rate: -0.4, target: 76, avg7: 80, today: '2026-11-01', noise: 0.05, nPace: 14, event: ev }).text).toMatch(/^Tempo je pravi\./)
  })
})

describe('Napredek — E43, E44, E45, E46, E47, E49, E50, E51, E52, E56, E24', () => {
  it('E43: z eno vadbo ni grafa forme, ampak »Graf forme pokažem po 3 vadbah.«', async () => {
    location.hash = '#/napredek?sec=p-motor'
    setNap({ activities: [act1('a', addDays(NAP_TODAY, -2))] })
    await mount(<Napredek />)
    expect(div.querySelector('svg[aria-label^="Graf forme"]')).toBeNull()
    expect(text()).toMatch(/Graf forme pokažem po 3 vadbah\./)
  })
  it('E44: 90 min je »1 h 30 min« (prej »2 h«), od 10 h cele ure', () => {
    expect(hoursTxt(90)).toBe('1 h 30 min')
    expect(nb(hoursTxt(750))).toBe('13 h')
    expect(nb(hoursTxt(0))).toBe('0 h')
  })
  it('E45: prazen mesec brez »0 vadb« in »Prej —« in brez »Kopiraj«', async () => {
    location.hash = '#/napredek?sec=p-mesec'
    setNap()
    await mount(<Napredek />)
    const sec = () => nb(document.getElementById('p-mesec')?.textContent)
    expect(sec()).toMatch(/Ta mesec/)
    expect(sec()).not.toMatch(/0 vadb/)
    expect(sec()).not.toMatch(/Prej —/)
    expect(btn(/^Kopiraj$/)).toBeFalsy()
    expect(text()).toMatch(/Ta mesec še ni česa oceniti/)
  })
  it('E46: mesec brez »moč 0×«; eno tehtanje »teža 79,9 kg«; teža z decimalko', async () => {
    location.hash = '#/napredek?sec=p-mesec'
    setNap({ activities: [act1('a', addDays(NAP_TODAY, -2))], checkins: [{ date: addDays(NAP_TODAY, -1), weightKg: 79.9 }] })
    await mount(<Napredek />)
    expect(text()).not.toMatch(/moč 0×/)
    expect(text()).toMatch(/teža 79,9 kg/)
    expect(text()).not.toMatch(/79,9 → 79,9/)
  })
  it('E47, E49: »3×8 · 44 kg«, 1RM na 5 kg', () => {
    expect(nb(setTxt({ sets: 3, reps: '8', kg: 44 }))).toBe('3×8 · 44 kg')
    expect(setTxt({ sets: 3, reps: '8', kg: null })).toBe('3×8')
    expect(e1rmTxt(106.5)).toBe('105')
    expect(e1rmTxt(87.5)).toBe('90')
  })
  it('E50: vrstica testa »240 W (20 min) → FTP 228 W«; trend v FTP', async () => {
    location.hash = '#/napredek?sec=p-testi'
    setNap({ tests: [{ id: 't1', date: '2026-07-14', kind: 'ftp', value: 232, unit: 'W' }, { id: 't2', date: '2026-09-14', kind: 'ftp', value: 240, unit: 'W' }] })
    await mount(<Napredek />)
    expect(text()).toMatch(/240 W\(20 min\) → FTP 228 W/)
    expect(text()).toMatch(/FTP iz testov: 220 W → 228 W/)
  })
  it('E51: glava po športih dogovora; samo moč: »obremenitev« in brez con', async () => {
    const run = normalizeFocus({ v: 1, mode: 'meri', wish: 'tek', sports: ['tek'], sessions: [{ type: 'tek', min: 40 }, { type: 'tek', min: 40 }] })!
    expect(customHead(P({ focus: run }))).toBe('Tek')
    const gym = normalizeFocus({ v: 1, mode: 'meri', wish: 'mišice', sports: ['fitnes'], sessions: [{ type: 'fitnes', min: 60 }, { type: 'fitnes', min: 60 }] })!
    setNap({ profile: P({ focus: gym, event: null }), activities: [1, 3, 5, 8].map(i => act1('m' + i, addDays(NAP_TODAY, -i), { sport: 'moc', distKm: 0, elevM: 0 })) })
    await mount(<Napredek />)
    expect(text()).toMatch(/Moč · teža · obremenitev/)
    expect(text()).toMatch(/Obremenitev/)
    expect(text()).not.toMatch(/Tvoje cone/)
  })
  it('E56: seznam tehtanj 5 zadnjih, nato »pokaži vse (14)«', async () => {
    setNap({ checkins: Array.from({ length: 14 }, (_, i) => ({ date: addDays(NAP_TODAY, -i), weightKg: 80 - i * 0.1 })) })
    await mount(<Napredek />)
    await click(btn(/^Zadnja tehtanja/))
    expect(div.querySelectorAll('[aria-label^="Izbriši tehtanje"]').length).toBe(5)
    await click(btn(/^pokaži vse \(14\)$/))
    expect(div.querySelectorAll('[aria-label^="Izbriši tehtanje"]').length).toBe(14)
  })
  it('E52: kondicija brez spremembe »enako kot pred 6 tedni« (prej »0 v 6 tednih«)', async () => {
    location.hash = '#/napredek?sec=p-motor'
    const long = Array.from({ length: 60 }, (_, i) => act1('L' + i, addDays(NAP_TODAY, -1 - i * 2), { tss: 60 }))
    setNap({ activities: long })
    await mount(<Napredek />)
    expect(text()).toMatch(/enako kot pred 6 tedni/)
    expect(text()).not.toMatch(/(?<![\d−+-])0 v 6 tednih/)
  })
  it('E53: napisi pod stolpci »Trening v resnici« 10,5 px (prej 9 px)', () => {
    const src = readFileSync('src/ui/RealityCard.tsx', 'utf8')
    expect(src).not.toMatch(/rem\(9(\.5)?\)/)
    expect(src).toMatch(/weeks\.length <= 6 \|\| \(weeks\.length - 1 - i\) % 2 === 0/)
  })
  it('E48: rekord iz lanskega leta ima letnico', async () => {
    const acts = [act1('x', '2025-11-14', { durationMin: 189, distKm: 95 }), ...[2, 4, 6, 8, 10].map(i => act1('y' + i, addDays(NAP_TODAY, -i)))]
    await mount(<RecordsCard acts={acts} today={NAP_TODAY} />)
    expect(text()).toMatch(/14\. 11\. 2025/)
  })
})

describe('E24 — ploščica Forma odpre Motor', () => {
  it('Danes: navigate("napredek", { sec: "p-motor" })', () => {
    const src = readFileSync('src/screens/Danes.tsx', 'utf8')
    expect(src).toMatch(/onClick=\{\(\) => navigate\('napredek', \{ sec: 'p-motor' \}\)\} aria-label=\{`Forma/)
  })
})
