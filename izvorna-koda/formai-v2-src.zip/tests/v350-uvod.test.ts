// v3.50 UVOD (domena) — vstopne animacije ne povozijo :disabled (F03), pot do uvoza (F40), zanikanje v želji (H03),
// tekma tudi za tek s tednom tekme (H02), več tekem in ime brez »Glavna tekma A:« (H20), FTP iz besed in vprašanje (H04),
// povedane ure in počitek iz pravega tedna (H05, H26), drug šport v 1. koraku (H11), preproste besede za začetnika (H30),
// namig za prvo težo (H32).
import { readFileSync, readdirSync, statSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { describe, it, expect } from 'vitest'
import { wishSignals, ruleQuestions, ruleProposal, ftpFromTalk, statedWeekHours, withStatedHours } from '@/domain/focus/rules'
import { raceIn, racesIn, moreRacesFromTalk, raceFromTalk } from '@/domain/focus/race'
import { ftpIn } from '@/domain/focus/dose'
import { composeWish, splitWish, otherSportDays } from '@/domain/focus/choices'
import { normalizeFocus, profileFromFocus } from '@/domain/focus/model'
import { coachReview } from '@/domain/focus/coach'
import { buildFocusWeek, raceKmOf } from '@/domain/training/focusPlan'
import { addDays } from '@/domain/training/load'
import { plainTerms, firstKgHint } from '@/domain/start'
import { kindLabelOf } from '@/ui/primitives'
import type { Focus, Profile } from '@/domain/types'

/** pot od korena projekta (test je v tests/) */
const fromRoot = (p: string) => join(dirname(fileURLToPath(import.meta.url)), '..', p)
const TUE = '2026-10-20'   // torek
const MON = '2026-10-19'
const NOW = `${MON}T08:00:00.000Z`

/* ---------- persone revizije H ---------- */
const U23 = composeWish({ cilj: ['Hitrejši in vzdržljivejši', 'Pripravljen na tekmo'], delam: ['Kolo'], raven: ['Redno, več let'], kolo: ['Zunaj po cesti', 'Merilnik moči'] },
  'Tekmujem v U23. Glavna tekma A: VN Kranj 2. 5. 2027. Tekma B: Kronometer Vodice 18. 4. 2027. Treniram 15 ur na teden. FTP 320 W.')
const VEGAN = composeWish({ cilj: ['Hitrejši in vzdržljivejši', 'Pripravljen na tekmo'], delam: ['Tek'], raven: ['Redno, več let'], tek: ['Polmaraton ali več'] },
  'Sem vegan. Ljubljanski maraton — polmaraton 25. 10. 2026. Tečem približno 35 km na teden.')
const K60 = composeWish({ cilj: ['Zdravje in počutje'], delam: ['Kolo'], raven: ['Redno, več let'], kolo: ['Trenažer doma'] },
  'Vozim samo trenažer doma. Nimam tekme, hočem ostati zdrav in v formi. Imam visok krvni tlak.')
const NIC = composeWish({ cilj: ['Zdravje in počutje'], delam: ['Vadba doma'], raven: ['Začenjam'] },
  'Nimam nič — ne kolesa, ne ure, ne opreme. Samo telefon. Dva dni na teden po pol ure.')
const ids = (w: string, o: Parameters<typeof ruleQuestions>[1]) => ruleQuestions(w, o).questions.map(q => q.id)

describe('F03 vstopne animacije: »backwards«, ne »both«', () => {
  const css = readFileSync(fromRoot('src/styles/motion.css'), 'utf8')
  const rule = (sel: string) => css.split('\n').find(l => l.includes(sel) && /animation:/.test(l)) || ''
  it('gumbi in čipi v uvodu, na straneh in v seznamih: končna sličica ne povozi :disabled (opacity .45/.4)', () => {
    for (const sel of ['main.ob > * {', '.page .chip {', '.page .deal-notes > li {', '.stagger > * {', '.sec-b, .fold-b {', '.page .wk-pick .wk-d {', '.page .head .head-act > * {']) {
      const r = rule(sel)
      expect(r, sel).toMatch(/backwards/)
      expect(r, sel).not.toMatch(/\bboth\b/)
    }
    // pravila za onemogočene ostanejo
    const base = readFileSync(fromRoot('src/styles/base.css'), 'utf8')
    expect(base).toMatch(/\.btn:disabled \{ opacity: \.45/)
    expect(base).toMatch(/\.chip:disabled \{ opacity: \.4/)
  })
})

describe('F40 »Nastavitve → Uvoz« ne obstaja več nikjer', () => {
  it('povsod »Nastavitve → Ura in uvoz«', () => {
    const files: string[] = []
    const walk = (d: string) => { for (const n of readdirSync(d)) { const p = join(d, n); if (statSync(p).isDirectory()) walk(p); else if (/\.(tsx?|css)$/.test(n)) files.push(p) } }
    walk(fromRoot('src'))
    const bad = files.filter(f => /Nastavitve → Uvoz/.test(readFileSync(f, 'utf8')))
    expect(bad).toEqual([])
    expect(readFileSync(fromRoot('src/screens/Danes.tsx'), 'utf8')).toContain('Pojasnilo: Nastavitve → Ura in uvoz.')
  })
})

describe('H03 zanikanje v želji', () => {
  it('»Nimam tekme« ni cilj tekma; »ne kolesa, ne ure« ni kolo; zanikanje ne pobriše, kar je res', () => {
    const s = wishSignals('Nimam tekme, hočem ostati zdrav.')
    expect(s.aims).not.toContain('tekma')
    expect(s.noRace).toBe(true)
    expect(wishSignals('Nimam nič — ne kolesa, ne ure, ne opreme.').sports).not.toContain('kolo')
    expect(wishSignals('Ne maram teka, rad kolesarim.').sports).toEqual(['kolo'])
    expect(wishSignals('Brez kolesa, samo tek.').sports).toEqual(['tek'])
    // kontrola: kar ni zanikano, ostane
    expect(wishSignals('Tekmujem na Franji. Rad delam: kolo.').aims).toContain('tekma')
    expect(wishSignals('Rad delam: kolo. Ne vem, ali bi še tek.').sports).toEqual(expect.arrayContaining(['kolo', 'tek']))
    expect(wishSignals('Vadba doma, brez opreme.').sports).toContain('doma')
  })
  it('kolesar 60 (»Nimam tekme«): brez vprašanja o tekmi; »nimam nič — ne kolesa«: brez vprašanj o kolesu in »2 h ali več«', () => {
    expect(ids(K60, { avail: [0, 2, 4, 5, 6], today: TUE })).not.toContain('tekma')
    const q = ruleQuestions(NIC, { avail: [1, 3], today: TUE })
    expect(q.questions.map(x => x.id)).not.toContain('kolo')
    expect(q.questions.map(x => x.id)).not.toContain('kolocilj')
    expect(q.questions.flatMap(x => x.options)).not.toContain('2 h ali več')
    // kontrola: kolesar brez besede o tekmi še vedno dobi »Imaš tekmo?«
    expect(ids(composeWish({ delam: ['Kolo'] }, 'Rad bi bil hitrejši.'), { avail: [1, 3, 5], today: TUE })).toContain('tekma')
  })
  it('predlog za kolesarja 60 brez tekme je načrt po meri (ne kolesarski načrt do tekme)', () => {
    const p = ruleProposal(K60, [{ id: 'dni', q: 'Koliko od teh 5 dni bi res treniral?', a: '4' }, { id: 'ure', q: 'Koliko ur na teden imaš za to?', a: '4–5 h' }], 60, { avail: [0, 2, 4, 5, 6], today: TUE })
    expect(p.focus.aims).not.toContain('tekma')
    expect(p.focus.mode).toBe('meri')
  })
})

describe('H20 več tekem v enem stavku, ime brez oznake', () => {
  it('»Glavna tekma A: VN Kranj …. Tekma B: Kronometer Vodice …« → dve tekmi z imenom in rangom', () => {
    expect(racesIn(U23, TUE)).toEqual([
      { name: 'VN Kranj', date: '2027-05-02', distanceKm: null, prio: 'A' },
      { name: 'Kronometer Vodice', date: '2027-04-18', distanceKm: null, prio: 'B' },
    ])
    expect(raceIn(U23, TUE)?.name).toBe('VN Kranj')
    // B prva v besedilu: glavna je še vedno A
    expect(raceIn('Tekma B: Kronometer Vodice 18. 4. 2027. Glavni cilj A: Maraton Franja 13. 6. 2027.', TUE)?.name).toBe('Maraton Franja')
    expect(racesIn('Tekma B: Kronometer Vodice 18. 4. 2027. Glavni cilj A: Maraton Franja 13. 6. 2027.', TUE).map(r => r.name)).toEqual(['Kronometer Vodice', 'Maraton Franja'])
  })
  it('vprašanje našteje obe; »Da« → glavna in druga tekma', () => {
    const q = ruleQuestions(U23, { avail: [0, 1, 2, 3, 4, 5, 6], today: TUE })
    expect(q.questions[0]!.text).toBe('Tvoji tekmi: VN Kranj · 2. 5. 2027 (cilj A), Kronometer Vodice · 18. 4. 2027 (B). Je prav?')
    const qa = [{ id: 'tekma', q: q.questions[0]!.text, a: 'Da' }]
    expect(raceFromTalk(U23, qa, TUE)?.name).toBe('VN Kranj')
    expect(moreRacesFromTalk(U23, qa, TUE)).toEqual([{ name: 'Kronometer Vodice', date: '2027-04-18', distanceKm: null, prio: 'B' }])
    expect(moreRacesFromTalk(U23, [{ id: 'tekma', q: 'x', a: 'Še nimam datuma' }], TUE)).toEqual([])
  })
  it('ena tekma ostane kot prej', () => {
    expect(raceIn('Maraton Franja 13. junija 2027, dolga trasa 156 km.', TUE)).toEqual({ name: 'Maraton Franja', date: '2027-06-13', distanceKm: 156 })
    expect(raceIn('Kronometer Vodice, 23. 10.', TUE)).toEqual({ name: 'Kronometer Vodice', date: '2026-10-23', distanceKm: null })
  })
})

describe('H02 tekačica s tekmo z datumom', () => {
  it('vprašalnik vpraša tekmo tudi tekača; »Polmaraton ali več« brez datuma ni vprašanje o tekmi', () => {
    const q = ruleQuestions(VEGAN, { avail: [1, 3, 5, 6], today: MON })
    expect(q.questions[0]).toMatchObject({ id: 'tekma', text: 'Tvoja tekma: Ljubljanski maraton — polmaraton · 25. 10. 2026. Je prav?' })
    expect(ids(composeWish({ delam: ['Tek'], tek: ['Polmaraton ali več'] }, ''), { avail: [1, 3, 5], today: MON })).not.toContain('tekma')
    expect(ids(composeWish({ cilj: ['Pripravljen na tekmo'], delam: ['Tek'] }, ''), { avail: [1, 3, 5], today: MON })).toContain('tekma')
  })
  const base = { sex: 'z', age: 28, heightCm: 168, weightKg: 58, ftp: null, gear: { bikeOutdoor: false, trainer: false, noBike: true }, strength: { on: false, equipment: 'none' }, onboardingDone: false, createdAt: NOW, updatedAt: NOW } as unknown as Profile
  const f0 = normalizeFocus({ wish: VEGAN, sports: ['tek'], aims: ['kondicija', 'vzdrzljivost', 'tekma'], level: 3, offDays: [0, 2, 4],
    sessions: [{ type: 'tek', cardio: 'intervali', min: 60 }, { type: 'tek', cardio: 'tempo', min: 60 }, { type: 'tek', cardio: 'lahko', min: 60 }, { type: 'tek', cardio: 'dolgo', min: 90 }],
    race: { name: 'Ljubljanski maraton — polmaraton', date: '2026-10-25', distanceKm: null, sport: 'tek' } }, { by: 'pravila', now: NOW })!
  it('tekma ostane v dogovoru (normalizeFocus, trener)', () => {
    expect(f0.race).toEqual({ name: 'Ljubljanski maraton — polmaraton', date: '2026-10-25', distanceKm: null, sport: 'tek' })
    expect(coachReview({ ...f0, sessions: f0.sessions.slice(0, 3) }, { age: 28, wantDays: 3 }).focus.race?.date).toBe('2026-10-25')
    expect(normalizeFocus({ ...f0, race: { date: 'jutri' } }, { by: 'pravila' })!.race).toBeUndefined()
    expect(raceKmOf(f0.race!)).toBe(21.1)
  })
  it('teden tekme: na dan tekme tekma (~2 h), dan prej 20 min s pospeški, 3 dni prej nič težkega, dan po počitek', () => {
    const p = { ...base, ...profileFromFocus(f0, base, MON, MON) } as Profile
    const w1 = buildFocusWeek({ profile: p, activities: [], weekStart: MON, notBefore: MON, today: MON } as never)
    const w2 = buildFocusWeek({ profile: p, activities: [], weekStart: addDays(MON, 7), notBefore: addDays(MON, 7), today: MON } as never)
    const at = (d: string) => [...w1, ...w2].find(x => x.date === d)!
    expect(at('2026-10-25')).toMatchObject({ kind: 'tek', role: 'dirka', title: 'Tekma: Ljubljanski maraton — polmaraton' })
    expect(at('2026-10-25').durationMin).toBeGreaterThanOrEqual(100)
    expect(at('2026-10-25').desc).toContain('Ogrevanje 10 min')
    expect(at('2026-10-24').title).toBe('Lahek tek — 20 min + 3 pospeški')
    for (const d of ['2026-10-22', '2026-10-23', '2026-10-24']) expect(at(d).zone === 'Z3' || at(d).zone === 'Z4' || at(d).zone === 'Z5', d).toBe(false)
    expect(at('2026-10-26')).toMatchObject({ kind: 'pocitek', title: 'Počitek po tekmi' })
    // prej: na dan tekme »Daljši lahek tek — 1 h 30 min«
    expect([...w1, ...w2].some(d => d.date === '2026-10-25' && /Daljši lahek tek/.test(d.title))).toBe(false)
  })
  it('brez tekme teden ostane, kot je bil', () => {
    const { race: _r, ...noRace } = f0
    const p = { ...base, ...profileFromFocus(noRace as Focus, base, MON, MON) } as Profile
    const w = buildFocusWeek({ profile: p, activities: [], weekStart: MON, notBefore: MON, today: MON } as never)
    expect(w.some(d => d.role === 'dirka')).toBe(false)
    expect(w.find(d => d.date === '2026-10-25')!.title).toMatch(/Daljši lahek tek/)
  })
})

describe('H04 FTP iz besed in vprašanje o FTP', () => {
  it('ftpIn', () => {
    expect(ftpIn(U23)).toBe(320)
    expect(ftpIn('Moj FTP je 280.')).toBe(280)
    expect(ftpIn('ftp: 255 W')).toBe(255)
    expect(ftpIn('Prag 300 W.')).toBe(300)
    expect(ftpIn('Treniram 15 ur na teden.')).toBeNull()
    expect(ftpIn('FTP 9000')).toBeNull()
    expect(ftpIn('285 W', true)).toBe(285)
    expect(ftpIn('285 W')).toBeNull()
  })
  it('merilnik moči brez FTP: vprašanje; FTP v besedah ali v profilu: brez', () => {
    const w = composeWish({ cilj: ['Pripravljen na tekmo'], delam: ['Kolo'], kolo: ['Merilnik moči'] }, 'Maraton Franja 13. 6. 2027.')
    const q = ruleQuestions(w, { avail: [1, 3, 5, 6], today: TUE })
    expect(q.questions.find(x => x.id === 'ftp')).toMatchObject({ text: 'Kakšen je tvoj FTP (20-minutni test ali ocena ure)?', options: ['Ne vem — izmeriva ga'], other: true })
    expect(ids(U23, { avail: [1, 3, 5, 6], today: TUE })).not.toContain('ftp')
    expect(ids(w, { avail: [1, 3, 5, 6], today: TUE, ftp: 250 })).not.toContain('ftp')
    expect(ids(composeWish({ delam: ['Kolo'], kolo: ['Zunaj po cesti'] }, ''), { avail: [1, 3, 5], today: TUE })).not.toContain('ftp')
    expect(ftpFromTalk(w, [{ id: 'ftp', q: 'Kakšen je tvoj FTP?', a: '285 W' }])).toBe(285)
    expect(ftpFromTalk(w, [{ id: 'ftp', q: 'Kakšen je tvoj FTP?', a: 'Ne vem — izmeriva ga' }])).toBeNull()
    expect(ftpFromTalk(U23, [])).toBe(320)
  })
})

describe('H05 + H26 povedane ure pri kolesarskem načrtu', () => {
  it('»Treniram 15 ur na teden« → 15 h (prej ~12 h); odgovor »9–12 h« → 10,5 h', () => {
    expect(statedWeekHours(U23, [])).toBe(15)
    expect(statedWeekHours('Rad delam: kolo.', [{ id: 'ure', q: 'Koliko ur na teden imaš za to?', a: '9–12 h' }])).toBe(10.5)
    expect(statedWeekHours('Rad delam: kolo.', [])).toBeNull()
    const qa = ruleQuestions(U23, { avail: [0, 1, 2, 3, 4, 5, 6], today: TUE }).questions.map(q => ({ id: q.id, q: q.text, a: q.id === 'tekma' ? 'Da' : q.id === 'dni' ? '6' : q.options[0] || '' }))
    const f = coachReview({ ...ruleProposal(U23, qa, 20, { avail: [0, 1, 2, 3, 4, 5, 6], today: TUE }).focus, main: 'kardio' }, { age: 20, wantDays: 6 }).focus
    expect(f.mode).toBe('kolo')
    const sum = (x: Pick<Focus, 'sessions'>) => x.sessions.reduce((t, s) => t + s.min, 0)
    expect(sum(f)).toBeLessThan(13.5 * 60)             // stropi posamezne vožnje: prej tiho ~12 h
    const g = withStatedHours(f, statedWeekHours(U23, qa))
    expect(Math.abs(sum(g) - 15 * 60)).toBeLessThanOrEqual(30)
    const base = { sex: 'm', age: 20, heightCm: 182, weightKg: 70, gear: { bikeOutdoor: true, trainer: false, noBike: false }, strength: { on: false, equipment: 'none' }, onboardingDone: false } as unknown as Profile
    expect(profileFromFocus(g, base, MON, TUE).hoursPerWeek).toBe(15)
  })
  it('načrt po meri in teden od Claude ostaneta, kot sta', () => {
    const m = normalizeFocus({ wish: 'tek', sessions: [{ type: 'tek', cardio: 'lahko', min: 40 }, { type: 'tek', cardio: 'lahko', min: 40 }], aims: ['kondicija'] }, { by: 'pravila' })!
    expect(withStatedHours(m, 15)).toBe(m)
    const k = normalizeFocus({ wish: 'kolo', sessions: [{ type: 'kolo', cardio: 'lahko', min: 90 }, { type: 'kolo', cardio: 'dolgo', min: 180 }], aims: ['tekma'] }, { by: 'claude' })!
    expect(withStatedHours(k, 15)).toBe(k)
  })
})

describe('H11 drug šport v 1. koraku', () => {
  it('»Drug šport« + polje → »Drug šport: nogomet tor in čet; tekma sob.«; nazaj v izbire in polje', () => {
    const w = composeWish({ delam: ['Fitnes', 'Drug šport'] }, 'Rad bi bil močnejši.', 'nogomet tor in čet, tekma sob.')
    expect(w).toBe('Rad delam: fitnes, drug šport. Drug šport: nogomet tor in čet, tekma sob. Rad bi bil močnejši.')
    expect(splitWish(w)).toEqual({ picks: { delam: ['Fitnes', 'Drug šport'] }, text: 'Rad bi bil močnejši.', other: 'nogomet tor in čet, tekma sob' })
    expect(otherSportDays(w).map(x => [x.day, x.match])).toEqual([[1, false], [3, false], [5, true]])
    // brez izbire polje ne velja
    expect(composeWish({ delam: ['Fitnes'] }, '', 'nogomet tor')).toBe('Rad delam: fitnes.')
  })
  it('dnevi drugega športa niso prosti za vadbo; tekma pri nogometu ni cilj tekma', () => {
    const w = composeWish({ cilj: ['Več mišic in moči'], delam: ['Fitnes', 'Drug šport'], raven: ['Občasno'] }, '', 'nogomet tor in čet, tekma sob')
    const p = ruleProposal(w, [{ id: 'cas', q: 'Koliko časa imaš za eno vadbo?', a: '1 h' }], 16, { avail: [0, 1, 2, 3, 4, 5, 6], today: TUE })
    expect(p.focus.offDays).toEqual(expect.arrayContaining([1, 3, 5]))
    expect(p.focus.aims).not.toContain('tekma')
  })
})

describe('H30 preproste besede za začetnika brez ure', () => {
  const f = (level: 1 | 2 | 3, wish = 'Rad delam: tek.') => normalizeFocus({ wish, level, sessions: [{ type: 'tek', cardio: 'lahko', min: 25 }, { type: 'hribi', cardio: 'lahko', min: 60 }], aims: ['zdravje'] }, { by: 'pravila' })!
  it('plainTerms: začetnik ali občasni brez povezane ure; z uro ali izkušen ne; kolesarski načrt ne', () => {
    expect(plainTerms({ focus: f(1) }, false)).toBe(true)
    expect(plainTerms({ focus: f(2) }, false)).toBe(true)
    expect(plainTerms({ focus: f(1) }, true)).toBe(false)
    expect(plainTerms({ focus: f(3) }, false)).toBe(false)
    expect(plainTerms({ focus: f(3, 'Nimam ure, samo telefon.') }, false)).toBe(true)
    expect(plainTerms({ focus: { ...f(1), mode: 'kolo', aims: ['tekma'] } }, false)).toBe(false)
    expect(plainTerms({ focus: null }, false)).toBe(false)
  })
  it('»Hitra hoja« je HOJA, ne HRIBI; tura v hribe ostane »Hribi«', () => {
    expect(kindLabelOf({ kind: 'pohod', title: 'Hitra hoja — 1 h', role: 'lahka' })).toBe('Hoja')
    expect(kindLabelOf({ kind: 'pohod', title: 'Hribi — 2 h 30 min', role: 'dolga' })).toBe('Hribi')
    expect(kindLabelOf({ kind: 'pohod', title: 'Sprehod', role: 'regen' })).toBe('Hoja')
  })
})

describe('H32 prva teža', () => {
  it('s palico prazna palica, sicer teža z rezervo', () => {
    expect(firstKgHint('Počep s palico')).toBe('Prvič: začni s prazno palico (običajno 20 kg). Ko narediš vse ponovitve lepo, naslednjič dodaj 2,5 kg.')
    expect(firstKgHint('Hip thrust s palico')).toContain('prazno palico')
    expect(firstKgHint('Veslanje z ročko')).toBe('Prvič: izberi težo, s katero narediš vse ponovitve lepo in ti ostaneta še 2–3 v rezervi. Ko gre zlahka, naslednjič več.')
  })
})
