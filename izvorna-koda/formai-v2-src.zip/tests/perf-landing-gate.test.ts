import { describe, it, expect, beforeEach, vi } from 'vitest'
import { gate } from '@/app/enter'

// Pristajalna stran ne naloži aplikacije; naloži jo šele vstop (#/…), namera (prst/miška na gumbu) jo prenese vnaprej.
function setup(mode: 'is-land' | 'is-app') {
  document.documentElement.className = mode
  document.body.innerHTML = '<div id="land"><a id="kako" href="#kako">Kako</a><a id="cta" href="#/uvod">Sestavi moj načrt</a></div>'
  history.replaceState(null, '', '/')
  const load = vi.fn(() => Promise.resolve())
  const start = vi.fn()
  return { load, start, now: gate({ load, start }) }
}
const hash = (h: string) => { history.replaceState(null, '', '/' + h); window.dispatchEvent(new HashChangeEvent('hashchange')) }

describe('vstop s pristajalne strani', () => {
  beforeEach(() => { document.documentElement.className = '' })

  it('aplikacija (is-app) začne takoj', () => {
    const g = setup('is-app')
    expect(g.now).toBe(true)
    expect(g.start).toHaveBeenCalledTimes(1)
  })

  it('pristajalna stran: nič se ne naloži, dokler obiskovalec ne vstopi', () => {
    const g = setup('is-land')
    expect(g.now).toBe(false)
    hash('#kako')   // sidro na strani ni vstop
    expect(g.start).not.toHaveBeenCalled()
    expect(g.load).not.toHaveBeenCalled()
    hash('#/uvod')
    expect(g.start).toHaveBeenCalledTimes(1)
    hash('#/prijava')
    expect(g.start).toHaveBeenCalledTimes(1)
  })

  it('namera na gumbu za vstop prenese aplikacijo vnaprej (enkrat), drugi elementi ne', () => {
    const g = setup('is-land')
    document.getElementById('kako')!.dispatchEvent(new Event('pointerover', { bubbles: true }))
    expect(g.load).not.toHaveBeenCalled()
    document.getElementById('cta')!.dispatchEvent(new Event('pointerover', { bubbles: true }))
    document.getElementById('cta')!.dispatchEvent(new Event('touchstart', { bubbles: true }))
    expect(g.load).toHaveBeenCalledTimes(1)
    expect(g.start).not.toHaveBeenCalled()
  })
})
