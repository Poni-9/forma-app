// Potrditev v aplikaciji in »Razveljavi«: zakasnjen izbris (skrito takoj, izbris čez 5 s, razveljavitev nič ne
// izbriše in ničesar ne doda nazaj), novo obvestilo zaključi prejšnje, ob skritju aplikacije se čakajoči izbrisi izvedejo.
import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { deferDelete, undoToast, useHidden, useConfirm, UndoHost, flushDeletes, _resetUndo } from '@/ui/Confirm'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

let div: HTMLDivElement, root: Root
const flush = async () => { for (let i = 0; i < 6; i++) await act(async () => { await Promise.resolve() }) }
const undoBtn = () => [...document.querySelectorAll('button')].find(b => b.textContent === 'Razveljavi') as HTMLButtonElement | undefined

function List({ ids }: { ids: string[] }) {
  const hidden = useHidden()
  return <><ul>{ids.filter(id => !hidden.has('meal:' + id)).map(id => <li key={id}>{id}</li>)}</ul><UndoHost /><UndoHost /></>
}

beforeEach(async () => {
  vi.useFakeTimers(); _resetUndo()
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
})
afterEach(async () => { await act(async () => root.unmount()); div.remove(); vi.useRealTimers(); document.body.innerHTML = '' })

describe('deferDelete', () => {
  it('skrije takoj, izbriše po 5 s; en sam gumb »Razveljavi« tudi z dvema gostiteljema', async () => {
    const commit = vi.fn()
    await act(async () => { root.render(<List ids={['a', 'b']} />) })
    await act(async () => { deferDelete('meal:a', 'Izbrisano: a', commit) })
    expect(div.querySelectorAll('li')).toHaveLength(1)
    expect(document.querySelectorAll('.toast.undo')).toHaveLength(1)
    await act(async () => { vi.advanceTimersByTime(4_900) })
    expect(commit).not.toHaveBeenCalled()
    await act(async () => { vi.advanceTimersByTime(200) }); await flush()
    expect(commit).toHaveBeenCalledTimes(1)
    expect(undoBtn()).toBeUndefined()
  })

  it('»Razveljavi«: nič se ne izbriše, zapis je spet viden', async () => {
    const commit = vi.fn()
    await act(async () => { root.render(<List ids={['a', 'b']} />) })
    await act(async () => { deferDelete('meal:a', 'Izbrisano: a', commit) })
    await act(async () => { undoBtn()!.click() }); await flush()
    await act(async () => { vi.advanceTimersByTime(10_000) }); await flush()
    expect(commit).not.toHaveBeenCalled()
    expect(div.querySelectorAll('li')).toHaveLength(2)
  })

  it('nov izbris zaključi prejšnjega takoj; skrita aplikacija izvede čakajoče', async () => {
    const a = vi.fn(), b = vi.fn()
    await act(async () => { root.render(<List ids={['a', 'b']} />) })
    await act(async () => { deferDelete('meal:a', 'a', a) })
    await act(async () => { deferDelete('meal:b', 'b', b) }); await flush()
    expect(a).toHaveBeenCalledTimes(1)
    expect(b).not.toHaveBeenCalled()
    await act(async () => { flushDeletes() }); await flush()
    expect(b).toHaveBeenCalledTimes(1)
  })
})

describe('undoToast (načrt)', () => {
  it('»Razveljavi« pokliče obnovo, po izteku ne', async () => {
    const restore = vi.fn()
    await act(async () => { root.render(<List ids={[]} />) })
    await act(async () => { undoToast('Teden je sestavljen znova.', restore) })
    expect(document.body.textContent).toContain('Teden je sestavljen znova.')
    await act(async () => { undoBtn()!.click() }); await flush()
    expect(restore).toHaveBeenCalledTimes(1)
    await act(async () => { undoToast('Še enkrat.', restore) })
    await act(async () => { vi.advanceTimersByTime(6_000) }); await flush()
    expect(restore).toHaveBeenCalledTimes(1)
  })
})

describe('useConfirm', () => {
  function Ask({ out }: { out: boolean[] }) {
    const { confirm, sheet } = useConfirm()
    return <><button id="ask" onClick={async () => out.push(await confirm({ title: 'Izbrišem vse?', ok: 'Izbriši', danger: true }))}>ask</button>{sheet}</>
  }
  it('vrne true ob potrditvi in false ob preklicu; list ima role=dialog in ime', async () => {
    const out: boolean[] = []
    await act(async () => { root.render(<Ask out={out} />) })
    await act(async () => { (div.querySelector('#ask') as HTMLButtonElement).click() })
    const dlg = document.querySelector('[role="dialog"]')!
    expect(dlg.getAttribute('aria-modal')).toBe('true')
    expect(dlg.getAttribute('aria-label')).toBe('Izbrišem vse?')
    await act(async () => { ([...dlg.querySelectorAll('button')].find(b => b.textContent === 'Izbriši') as HTMLButtonElement).click() }); await flush()
    await act(async () => { (div.querySelector('#ask') as HTMLButtonElement).click() })
    await act(async () => { ([...document.querySelectorAll('[role="dialog"] button')].find(b => b.textContent === 'Prekliči') as HTMLButtonElement).click() }); await flush()
    expect(out).toEqual([true, false])
  })
})
