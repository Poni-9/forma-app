import { describe, it, expect } from 'vitest'
import { adaptAfterLoad, undoLoadAdapt, FRANJA_2027 } from '../src/domain/training/planner'
import type { Activity, PlanDay, Profile } from '../src/domain/types'

const now = new Date().toISOString()
const P = {
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, ftpDate: '2026-09-01', maxHr: 195, restHr: 48,
  gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: true }, strength: { on: false, equipment: 'none' },
  hoursPerWeek: 8, onboardingDone: true, createdAt: now, updatedAt: now, event: { ...FRANJA_2027 }, cycleStart: '2026-09-21',
} as unknown as Profile
const d = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: 'p' + date, date, kind: 'kolo', title: 'Z2 vzdržljivost', desc: '', durationMin: 60, zone: 'Z2', tssTarget: 42, role: 'lahka', source: 'rules', createdAt: now, updatedAt: now, ...o })
const rest = (date: string) => d(date, { kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, tssTarget: 0, role: null })
const ride = (date: string, min: number, tss: number): Activity => ({ id: 'a' + date, source: 'intervals', sport: 'kolo', date, name: 'Vožnja', durationMin: min, tss, aiEligible: true, geoRetain: false } as Activity)

// teden 9.–15. 11. 2026: v torek načrtovana regeneracija, odpeljane 3 ure
const regenTue = d('2026-11-10', { title: 'Regeneracija', zone: 'Z1', durationMin: 45, tssTarget: 19, role: 'regen', done: { at: now, activityId: 'a2026-11-10' } })
const vo2Wed = d('2026-11-11', { title: 'VO2max 5 × 4 min', zone: 'Z5', durationMin: 90, tssTarget: 95, role: 'kljucna' })
const week = (wed: PlanDay = vo2Wed): PlanDay[] => [rest('2026-11-09'), regenTue, wed, d('2026-11-12'), rest('2026-11-13'), d('2026-11-14', { title: 'Dolga Z2', durationMin: 180, tssTarget: 127, role: 'dolga' }), d('2026-11-15', { durationMin: 90, tssTarget: 63 })]
const big = [ride('2026-11-10', 183, 150)]

describe('po pretežki vožnji je dan za tem lažji', () => {
  it('ključni trening jutri gre na naslednji primeren lahki dan, jutri regeneracija', () => {
    const r = adaptAfterLoad(P, week(), big, '2026-11-10', '2026-11-10')!
    expect(r.state).toBe('predlog')
    expect(r.actual).toBe(150); expect(r.planned).toBe(19)
    const wed = r.days.find(x => x.date === '2026-11-11')!, thu = r.days.find(x => x.date === '2026-11-12')!
    expect(wed.role).toBe('regen'); expect(wed.zone).toBe('Z1'); expect(wed.durationMin).toBeLessThanOrEqual(45)
    expect(wed.adapt?.prev?.title).toBe('VO2max 5 × 4 min')
    expect(thu.title).toBe('VO2max 5 × 4 min'); expect(thu.why).toMatch(/s srede/)
    expect(r.text).toBe('Jutri regeneracija 45 min, VO2max 5 × 4 min gre na četrtek.')
  })
  it('že prilagojeno → »prilagojeno«; vrni prvotni → vsebina nazaj in ne predlaga znova', () => {
    const r = adaptAfterLoad(P, week(), big, '2026-11-10', '2026-11-10')!
    const applied = week().map(x => r.days.find(y => y.id === x.id) ?? x)
    const again = adaptAfterLoad(P, applied, big, '2026-11-10', '2026-11-10')!
    expect(again.state).toBe('prilagojeno'); expect(again.days).toHaveLength(0)
    expect(again.text).toMatch(/^Jutri regeneracija 45 min, VO2max 5 × 4 min je v četrtek\.$/)
    const back = undoLoadAdapt(applied, '2026-11-10')
    expect(back).toHaveLength(2)
    const restored = applied.map(x => back.find(y => y.id === x.id) ?? x)
    expect(restored.find(x => x.date === '2026-11-11')!.title).toBe('VO2max 5 × 4 min')
    expect(restored.find(x => x.date === '2026-11-12')!.title).toBe('Z2 vzdržljivost')
    expect(adaptAfterLoad(P, restored, big, '2026-11-10', '2026-11-10')!.state).toBe('vrnjeno')
  })
  it('jutri dolga, danes že dolgo → jutri regeneracija; jutri počitek → nič ne spreminja', () => {
    const long = adaptAfterLoad(P, week(d('2026-11-11', { title: 'Dolga Z2', durationMin: 180, tssTarget: 127, role: 'dolga' })), big, '2026-11-10', '2026-11-10')!
    expect(long.days).toHaveLength(1); expect(long.text).toMatch(/namesto dolge vožnje/)
    const r = adaptAfterLoad(P, week(rest('2026-11-11')), big, '2026-11-10', '2026-11-10')!
    expect(r.state).toBe('info'); expect(r.days).toHaveLength(0); expect(r.text).toMatch(/počitek/)
  })
  it('tekme ne spreminja; ključnega ne prestavi ob drug trd dan (odpade)', () => {
    const race = adaptAfterLoad(P, week(d('2026-11-11', { title: 'Tekma', zone: 'dirka', role: 'dirka' })), big, '2026-11-10', '2026-11-10')!
    expect(race.state).toBe('info'); expect(race.text).toMatch(/tekma/)
    // četrtek med dvema trdima dnevoma, nedelja že v naslednjem tednu ni → ni primernega dne
    const w = week().map(x => x.date === '2026-11-13' ? d('2026-11-13', { title: 'Prag', zone: 'Z4', role: 'kljucna', tssTarget: 80 }) : x.date === '2026-11-15' ? rest('2026-11-15') : x)
    const r = adaptAfterLoad(P, w, big, '2026-11-10', '2026-11-10')!
    expect(r.days).toHaveLength(1); expect(r.text).toMatch(/ni kam prestaviti/)
  })
  it('malo več od načrta ni pretežko; včerajšnja vožnja olajša danes', () => {
    expect(adaptAfterLoad(P, week(), [ride('2026-11-10', 70, 55)], '2026-11-10', '2026-11-10')).toBeNull()
    const y = adaptAfterLoad(P, week(), big, '2026-11-10', '2026-11-11')!
    expect(y.text).toMatch(/^Danes regeneracija/)
    expect(adaptAfterLoad(P, week(), big, '2026-11-10', '2026-11-12')).toBeNull()   // dan za tem je že mimo
  })
})
