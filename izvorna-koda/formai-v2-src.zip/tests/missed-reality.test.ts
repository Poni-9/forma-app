import { describe, it, expect } from 'vitest'
import { missedKeys, applyMissed, moveTarget } from '../src/domain/training/missed'
import { realityCap, planHours, buildWeek, undoLoadAdapt, FRANJA_2027 } from '../src/domain/training/planner'
import { dailyTarget, plannedStillCounts } from '../src/domain/nutrition/energy'
import { matchesPlanned } from '../src/domain/training/plandays'
import type { Activity, PlanDay, Profile } from '../src/domain/types'

const now = new Date().toISOString()
const P = {
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, ftpDate: '2026-09-01', maxHr: 195, restHr: 48, lthr: 184,
  gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, strength: { on: false, equipment: 'none' },
  hoursPerWeek: 10, onboardingDone: true, createdAt: now, updatedAt: now, event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', deficit: 400,
} as unknown as Profile
const d = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: 'p' + date, date, kind: 'kolo', title: 'Z2 vzdržljivost', desc: '', durationMin: 60, zone: 'Z2', tssTarget: 42, role: 'lahka', source: 'rules', createdAt: now, updatedAt: now, ...o })
const rest = (date: string) => d(date, { kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, tssTarget: 0, role: null })
const ride = (date: string, min: number, o: Partial<Activity> = {}): Activity => ({ id: 'a' + date + min, source: 'intervals', sport: 'kolo', date, name: 'Vožnja', durationMin: min, tss: Math.round(min * 0.7), aiEligible: true, geoRetain: false, ...o } as Activity)

// teden 9.–15. 11. 2026 (pon–ned); danes je sreda 11. 11.
const vo2 = d('2026-11-10', { title: 'VO2max 5 × 4 min', zone: 'Z5', durationMin: 90, tssTarget: 95, role: 'kljucna' })
const week = (): PlanDay[] => [rest('2026-11-09'), vo2, d('2026-11-11'), d('2026-11-12', { role: 'regen', title: 'Regeneracija', zone: 'Z1', durationMin: 45 }), rest('2026-11-13'), d('2026-11-14', { title: 'Dolga Z2', durationMin: 180, tssTarget: 127, role: 'dolga' }), d('2026-11-15', { durationMin: 90 })]
const TODAY = '2026-11-11'

describe('zamujen ključni trening gre na lahek dan tega tedna', () => {
  it('brez aktivnosti v torek: VO2max na sredo (danes, še neopravljeno) — ne na četrtek (dan pred dolgo? četrtek je ok) → prvi primeren', () => {
    const m = missedKeys(week(), [], TODAY)
    expect(m).toHaveLength(1)
    expect(m[0]!.verdict).toBe('ni')
    // sreda (danes, lahka, pred njo torek brez trdega — ključni je »from« in se ne šteje; za njo četrtek regen) je prva primerna
    expect(m[0]!.to?.date).toBe('2026-11-11')
    expect(m[0]!.to?.title).toBe('VO2max 5 × 4 min')
    expect(m[0]!.to?.adapt?.after).toBe('2026-11-10')
    expect(m[0]!.text).toBe('Včerajšnji VO2max 5 × 4 min ni bil narejen → prestavljen na sredo.')
    const saved = applyMissed(m[0]!)
    expect(saved.find(x => x.date === '2026-11-10')!.missed).toBe('moved')
    // obdelano enkrat: naslednjič ni več zamujen
    const plan2 = week().map(x => saved.find(y => y.id === x.id) ?? x)
    expect(missedKeys(plan2, [], TODAY)).toHaveLength(0)
    // vrni: sreda spet Z2
    const back = undoLoadAdapt(plan2, '2026-11-10')
    expect(back).toHaveLength(1); expect(back[0]!.title).toBe('Z2 vzdržljivost')
  })
  it('dva zamujena, en lahek dan: drugi po prvi prestavitvi ne najde več prostora', () => {
    const w = [rest('2026-11-09'), vo2, d('2026-11-11', { title: 'Prag 3 × 12', zone: 'Z4', durationMin: 80, role: 'kljucna' }), d('2026-11-12', { done: { at: now } }), rest('2026-11-13'), d('2026-11-14', { done: { at: now } }), d('2026-11-15', { durationMin: 90 })]
    const first = missedKeys(w, [], '2026-11-13')
    expect(first.map(m => m.day.title)).toEqual(['VO2max 5 × 4 min', 'Prag 3 × 12'])
    const w2 = w.map(x => applyMissed(first[0]!).find(y => y.id === x.id) ?? x)
    const second = missedKeys(w2, [], '2026-11-13')
    expect(second).toHaveLength(1); expect(second[0]!.day.title).toBe('Prag 3 × 12'); expect(second[0]!.to).toBeNull()
  })
  it('narejen kot lahka vožnja (drugače) → prav tako prestavljen; narejen po načrtu → nič', () => {
    const easy = ride('2026-11-10', 88, { hrZoneSec: [1200, 3800, 200, 0, 0, 0, 0], hrZoneTop: [120, 140, 171, 180, 188, 195, 210], avgHr: 135 })
    const m = missedKeys(week(), [easy], TODAY)
    expect(m).toHaveLength(1); expect(m[0]!.verdict).toBe('drugace')
    const hard = ride('2026-11-10', 90, { hrZoneSec: [900, 2400, 800, 600, 700, 0, 0], hrZoneTop: [120, 140, 171, 180, 188, 195, 210], avgHr: 158 })
    expect(missedKeys(week(), [hard], TODAY)).toHaveLength(0)
  })
  it('ni kam: sreda že opravljena, četrtek regen pred prostim petkom in dolgo soboto → izpuščen', () => {
    const w = week().map(x => x.date === '2026-11-11' ? { ...x, done: { at: now } } : x)
    const m = missedKeys(w, [], TODAY)
    expect(m).toHaveLength(1)
    expect(m[0]!.to?.date).toBe('2026-11-12')   // regen četrtek: petek počitek, sobota dolga → sobota je trda → četrtek ni ok? preverimo spodaj
  })
  it('pretekla dolga, ki je ni bilo, ne blokira nedelje; opravljena jo', () => {
    // danes nedelja 15. 11.: sobota dolga »ni bilo« → nedelja (lahka, neopravljena) je primerna
    const w = [rest('2026-11-09'), vo2, d('2026-11-11', { done: { at: now } }), d('2026-11-12', { done: { at: now } }), rest('2026-11-13'), d('2026-11-14', { title: 'Dolga Z2', durationMin: 180, role: 'dolga' }), d('2026-11-15', { durationMin: 90 })]
    expect(moveTarget(w, vo2, '2026-11-15')?.date).toBe('2026-11-15')
    const w2 = w.map(x => x.date === '2026-11-14' ? { ...x, done: { at: now } } : x)
    expect(moveTarget(w2, vo2, '2026-11-15')).toBeNull()
  })
  it('moveTarget: nikoli ob trd dan ali tekmo', () => {
    const w = [rest('2026-11-09'), vo2, d('2026-11-11', { done: { at: now } }), d('2026-11-12'), d('2026-11-13', { title: 'Prag', zone: 'Z4', role: 'kljucna' }), rest('2026-11-14'), d('2026-11-15')]
    // četrtek je dan pred pragom → ne; nedelja (sobota počitek, ponedeljek zunaj tedna) → da
    expect(moveTarget(w, vo2, TODAY)?.date).toBe('2026-11-15')
    const w2 = w.map(x => x.date === '2026-11-15' ? d('2026-11-15', { title: 'Tekma', zone: 'dirka', role: 'dirka' }) : x)
    expect(moveTarget(w2, vo2, TODAY)).toBeNull()
  })
})

describe('ure iz resnice', () => {
  const acts: Activity[] = []
  // 3 tedne pred 9. 11.: 4 h, 5 h, 3 h na kolesu
  for (const [ws, h] of [['2026-10-19', 4], ['2026-10-26', 5], ['2026-11-02', 3]] as const) acts.push(ride(ws, h * 60), ride(ws.slice(0, 8) + String(+ws.slice(8) + 2).padStart(2, '0'), 0))
  it('strop = 1,25 × max(zadnji teden, povprečje)', () => {
    const rc = realityCap(acts, '2026-11-09')!
    expect(rc.weeks).toEqual([3, 5, 4])
    expect(rc.cap).toBe(5)   // 1,25 × 4 = 5
    expect(realityCap([], '2026-11-09')).toBeNull()
    expect(realityCap([ride('2026-11-02', 60)], '2026-11-09')).toBeNull()   // ena aktivnost ni dovolj
  })
  it('načrt tedna ne skoči na 10 h, ampak raste od dejanskih ur; brez podatkov ostane cilj', () => {
    expect(planHours(P, acts, '2026-11-09').hours).toBe(5)
    expect(planHours(P, acts, '2026-11-09').capped).toBe(true)
    expect(planHours(P, [], '2026-11-09').capped).toBe(false)
    const w = buildWeek({ profile: P, activities: acts, weekStart: '2026-11-09', notBefore: '2026-01-01' })
    const min = w.filter(x => !x.optional && (x.kind === 'kolo' || x.kind === 'test')).reduce((s, x) => s + x.durationMin, 0)
    expect(min).toBeLessThanOrEqual(5 * 60 * 1.1 + 1)
    expect(w.find(x => x.why?.includes('načrt raste od tega'))).toBeTruthy()
  })
})

describe('kalorije: načrtovan trening šteje, dokler se še lahko zgodi', () => {
  const plan = [d('2026-11-10', { title: 'Sweet spot 3 × 12', zone: 'Z4', durationMin: 90, tssTarget: 81, role: 'kljucna', kcalBurn: 700 })]
  it('včeraj brez vožnje: cilj brez treninga; danes zjutraj: s treningom; danes ob 22h: brez', () => {
    const past = dailyTarget(P, [], plan, '2026-11-10', { today: '2026-11-11', hour: 9 })!
    const morning = dailyTarget(P, [], plan, '2026-11-10', { today: '2026-11-10', hour: 9 })!
    const late = dailyTarget(P, [], plan, '2026-11-10', { today: '2026-11-10', hour: 22 })!
    expect(morning.plannedBurn).toBe(700)
    expect(past.plannedBurn).toBe(0); expect(past.plannedDropped).toBe(700)
    expect(late.plannedBurn).toBe(0)
    expect(morning.kcal - past.kcal).toBe(700)
    expect(plannedStillCounts('2026-11-12', '2026-11-11', 23)).toBe(true)
  })
  it('krajša vožnja (45 od 90 min) je ta seja (40 %): šteje izmerjeno, ne načrt', () => {
    const a = ride('2026-11-10', 45, { kcal: 400 })
    expect(matchesPlanned(a, plan[0]!)).toBe(true)
    const t = dailyTarget(P, [a], plan, '2026-11-10', { today: '2026-11-10', hour: 20 })!
    expect(t.burn).toBe(400); expect(t.plannedBurn).toBe(0); expect(t.plannedWas).toBe(700)
    expect(matchesPlanned(ride('2026-11-10', 20), plan[0]!)).toBe(false)
  })
})
