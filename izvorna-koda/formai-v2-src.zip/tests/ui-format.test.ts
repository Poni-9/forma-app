// Slovenska množina, števila (vejica, tisočice, minus, nedeljivi presledek), datumi in celice CSV.
import { describe, it, expect } from 'vitest'
import { plural, count, W, int, dec, num, signed, unit, kcal, pct, dm, dmy, dayName, dayAcc, csvCell, nb, NBSP, NNBSP, MINUS } from '@/ui/format'

describe('plural (1 / 2 / 3–4 / 5+ in 101, 102 …)', () => {
  const teden = ['teden', 'tedna', 'tedni', 'tednov'] as const
  it.each([
    [0, 'tednov'], [1, 'teden'], [2, 'tedna'], [3, 'tedni'], [4, 'tedni'], [5, 'tednov'], [11, 'tednov'], [12, 'tednov'], [14, 'tednov'],
    [21, 'tednov'], [101, 'teden'], [102, 'tedna'], [103, 'tedni'], [104, 'tedni'], [111, 'tednov'], [201, 'teden'],
  ])('%i → %s', (n, w) => expect(plural(n, teden)).toBe(w))
  it('count: število in samostalnik z nedeljivim presledkom', () => {
    expect(count(4, W.vaja)).toBe(`4${NBSP}vaje`)
    expect(count(2, W.teden)).toBe(`2${NBSP}tedna`)
    expect(count(1, W.dan)).toBe(`1${NBSP}dan`)
    expect(count(1, W.danT)).toBe(`1${NBSP}dan`)          // čez 1 dan
    expect(count(3, W.danT)).toBe(`3${NBSP}dni`)          // čez 3 dni
    expect(count(2, W.tedenT)).toBe(`2${NBSP}tedna`)      // off-season 2 tedna (ne »2 tedne«)
    expect(count(3, W.tedenT)).toBe(`3${NBSP}tedne`)
    expect(count(1, W.vadba)).toBe(`1${NBSP}vadba`)
    expect(count(5, W.vadba)).toBe(`5${NBSP}vadb`)
    expect(count(1, W.aktivnost)).toBe(`1${NBSP}aktivnost`)
  })
})

describe('števila', () => {
  it('tisočice z ozkim nedeljivim presledkom, minus »−«', () => {
    expect(int(1840)).toBe(`1${NNBSP}840`)
    expect(int(12500)).toBe(`12${NNBSP}500`)
    expect(int(999)).toBe('999')
    expect(int(-2300)).toBe(`${MINUS}2${NNBSP}300`)
    expect(kcal(2150)).toBe(`2${NNBSP}150${NBSP}kcal`)
  })
  it('decimalna vejica', () => {
    expect(dec(72.46)).toBe('72,5')
    expect(dec(0.5, 2)).toBe('0,50')
    expect(dec(-0.5, 2)).toBe(`${MINUS}0,50`)
    expect(dec(-0.004, 2)).toBe('0,00')                   // brez »−0,00«
    expect(num(72)).toBe('72')
    expect(num(72.25)).toBe('72,3')
    expect(num(12.5)).toBe('12,5')
    expect(num(1840.4, 0)).toBe(`1${NNBSP}840`)
  })
  it('predznak in enote', () => {
    expect(signed(0.5, 2)).toBe('+0,50')
    expect(signed(-0.5, 2)).toBe(`${MINUS}0,50`)
    expect(signed(0, 0)).toBe('0')
    expect(`${signed(-0.5, 2)}${NBSP}kg/teden`).toBe(`${MINUS}0,50${NBSP}kg/teden`)
    expect(unit(72.5, 'kg')).toBe(`72,5${NBSP}kg`)
    expect(pct(79.6)).toBe(`80${NBSP}%`)
  })
  it('nb: enota in razpon ostaneta skupaj s številom', () => {
    expect(nb('zelenjava 270 g, 3 × 12 min')).toBe(`zelenjava 270${NBSP}g, 3 × 12${NBSP}min`)
    expect(nb('bidon ≈ 40–45 g')).toBe(`bidon ≈ 40–⁠${'45'}${NBSP}g`)   // U+2060: brez preloma za »–«
    expect(nb('2 gela in 5 minut')).toBe('2 gela in 5 minut')   // »g« v »gela« ni enota
  })
})

describe('datumi', () => {
  it('brez vodilnih ničel, s presledkom (»22. 9.«, ne »22.9.« ali »07. 9.«)', () => {
    expect(dm('2026-09-22')).toBe(`22.${NBSP}9.`)
    expect(dm('2026-09-07')).toBe(`7.${NBSP}9.`)
  })
  it('leto samo, kadar ni letošnje', () => {
    expect(dmy('2026-09-22', '2026-09-25')).toBe(`22.${NBSP}9.`)
    expect(dmy('2025-12-31', '2026-09-25')).toBe(`31.${NBSP}12.${NBSP}2025`)
  })
  it('dan v tednu v imenovalniku in tožilniku', () => {
    expect(dayName('2026-09-23')).toBe('sreda')
    expect(dayAcc('2026-09-23')).toBe('sredo')        // prestavljeno na sredo
    expect(dayAcc('2026-09-27')).toBe('nedeljo')
  })
})

describe('CSV', () => {
  it('celice, ki bi jih preglednica izvedla kot formulo, dobijo apostrof', () => {
    expect(csvCell('=HYPERLINK("http://x","klik")')).toBe(`"'=HYPERLINK(""http://x"",""klik"")"`)
    expect(csvCell('+386')).toBe(`"'+386"`)
    expect(csvCell('-cmd')).toBe(`"'-cmd"`)
    expect(csvCell('@SUM(A1)')).toBe(`"'@SUM(A1)"`)
    expect(csvCell('KK-ROG')).toBe('"KK-ROG"')
    expect(csvCell(-3)).toBe('"-3"')                   // število ostane število
    expect(csvCell(null)).toBe('""')
  })
})
