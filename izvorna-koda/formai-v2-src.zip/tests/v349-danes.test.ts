// v3.49 DANES (domena): moč po meri — iste vaje ves blok, mišice 2× na teden (celo telo A/B), kolesarska moč doma
// napreduje brez uteži, težke noge 65 min; Danes — nasvet po jutranjem vnosu po vrsti treninga, »Trener pravi« za moč
// in tek, »Imam samo X min«, pozen prvi dogovor začne jutri, prvi trening ob začetku s počitkom; animacije v mirovanju.
import { readFileSync } from 'node:fs'
import { describe, it, expect } from 'vitest'
import { strengthWorkout, exByName } from '../src/domain/training/exercises'
import { strengthSession, buildWeek } from '../src/domain/training/planner'
import { stepsFor, totalSec } from '../src/domain/training/workout'
import { ruleProposal } from '../src/domain/focus/rules'
import { coachReview, splitStrengthParts } from '../src/domain/focus/coach'
import { profileFromFocus, isStrength } from '../src/domain/focus/model'
import { addDays } from '../src/domain/training/load'
import { mildAdvice, shortenDay, shortOptions, startsTomorrow, firstTraining } from '../src/domain/training/danes'
import type { Activity, PlanDay, Profile } from '../src/domain/types'

const NOW = '2026-10-12T08:00:00.000Z'
const MON = '2026-10-12'   // ponedeljek — brez uvodnih dni
const BASE = { name: 'X', sex: 'm', age: 34, heightCm: 180, weightKg: 95, restHr: null, maxHr: null, lthr: null, ftp: null, ftpDate: null, goal: 'forma', gear: { bikeOutdoor: false, trainer: false, noBike: true, powerMeter: null }, hoursPerWeek: 4, hoursMode: 'own', strength: { on: false, equipment: 'none' }, strengthDays: 0, deficit: 0, neat: 1.4, proteinGkg: 1.6, event: null, races: [], level: 1, onboardingDone: true, createdAt: NOW, updatedAt: NOW } as unknown as Profile
/** fitnes in tek, cilj mišice in manj kilogramov, nekaj izkušenj, 4 dni po 60 min (A/fitnes.log) */
function gymPersona(days = '4') {
  const pr = ruleProposal('Cilj: manj kilogramov, mišice. Rad delam: fitnes, tek. Izkušnje: nekaj.', [{ id: 'dni', q: 'Koliko dni na teden?', a: days }, { id: 'cas', q: 'Koliko časa imaš za eno vadbo?', a: '60 min' }, { id: 'izkusnje', q: 'Izkušnje', a: 'nekaj izkušenj' }], 34)
  const f = coachReview(pr.focus, { age: 34 }).focus
  return { f, p: { ...BASE, ...profileFromFocus(f, BASE, MON, MON) } as Profile }
}
const week = (p: Profile, ws: string) => buildWeek({ profile: p, activities: [], weekStart: ws, notBefore: ws, today: MON })
const gymDays = (p: Profile, ws: string) => week(p, ws).filter(d => d.kind === 'moc')

describe('A20/C22: vaje moči ostanejo iste ves blok (4 tedne)', () => {
  it('načrt po meri v fitnesu: tedni 1–4 ista imena vaj pri isti seji (prej 4 od 6 vaj vsak teden drugih)', () => {
    const { p } = gymPersona()
    const names = (ws: string) => gymDays(p, ws).map(d => `${d.title}: ${d.exercises!.map(e => e.name).join(', ')}`)
    const w1 = names(MON)
    expect(w1.length).toBe(2)
    for (const k of [1, 2, 3]) expect(names(addDays(MON, 7 * k))).toEqual(w1)
  })
  it('strengthWorkout: teden 1 in 2 isti; teden 5 (nov blok) lahko druge dodatne vaje, prva ostane', () => {
    const o = { part: 'zgornji' as const, where: 'fitnes' as const, equip: ['fitnes'] as const, level: 2 as const, aims: ['misice'] as const, muscles: [], min: 60 }
    const a = strengthWorkout({ ...o, week: 1 }).exercises.map(e => e.name)
    expect(strengthWorkout({ ...o, week: 2 }).exercises.map(e => e.name)).toEqual(a)
    expect(strengthWorkout({ ...o, week: 4 }).exercises.map(e => e.name)).toEqual(a)
    const b5 = strengthWorkout({ ...o, week: 5 }).exercises.map(e => e.name)
    expect(b5[0]).toBe(a[0])
    expect(b5).not.toEqual(a)
  })
  it('v fitnesu brez stola in elastike, kadar so naprave ali uteži (pike sklece, dipi na stolu, upogib z elastiko)', () => {
    for (const part of ['zgornji', 'spodnji', 'celo', 'potisk', 'poteg'] as const) for (const week of [1, 5, 9, 13]) for (const level of [1, 2, 3] as const) {
      const w = strengthWorkout({ part, where: 'fitnes', equip: ['fitnes'], level, aims: ['misice'], muscles: ['roke', 'ramena'], min: 60, week })
      for (const e of w.exercises) {
        const d = exByName(e.name)!
        if (d.pat !== 'trebuh' && d.pat !== 'kondicija') expect([d.eq, part, week, level].join(' ')).not.toMatch(/^(nic|elastike) /)
      }
    }
  })
})

describe('A21: cilj mišice — vsaka mišica vsaj 2× na teden', () => {
  it('2 dneva moči (raven 2): celo telo dvakrat, ne zgornji + spodnji; trener (coachReview) tega ne razdeli', () => {
    const { f } = gymPersona()
    expect(f.level).toBe(2)
    expect(f.sessions.filter(isStrength).map(s => s.part)).toEqual(['celo', 'celo'])
    expect(f.why!.join(' ')).toMatch(/Celo telo 2× na teden/)
  })
  it('celo telo A/B: ista prva vaja (napredek), druge dodatne vaje', () => {
    const { p } = gymPersona()
    const [a, b] = gymDays(p, MON)
    expect(a!.exercises![0]!.name).toBe(b!.exercises![0]!.name)
    expect(a!.exercises!.map(e => e.name)).not.toEqual(b!.exercises!.map(e => e.name))
  })
  it('delitev: celo ×2 ostane (razen dva dneva zapored), 3 seje zgornji/spodnji/celo; brez cilja mišice kot prej', () => {
    const m = { upperOnly: false, level: 2 as const, aims: ['misice'] as const }
    expect(splitStrengthParts(['celo', 'celo'], m)).toEqual(['celo', 'celo'])
    expect(splitStrengthParts(['celo', 'celo'], { ...m, days: [1, 2] })).toEqual(['zgornji', 'spodnji'])
    expect(splitStrengthParts(['celo', 'celo'], { ...m, days: [6, 0] })).toEqual(['zgornji', 'spodnji'])   // nedelja–ponedeljek
    expect(splitStrengthParts(['celo', 'celo'], { ...m, days: [1, 4] })).toEqual(['celo', 'celo'])
    expect(splitStrengthParts(['celo', 'celo', 'celo'], m)).toEqual(['zgornji', 'spodnji', 'celo'])
    expect(splitStrengthParts(['celo', 'celo'], { upperOnly: false, level: 2, aims: ['zdravje'] })).toEqual(['zgornji', 'spodnji'])
  })
  it('pravila: 3 dni moči z mišicami → zgornji, spodnji, celo; 4 dni → zgornji/spodnji ×2 (noge 2×, prej 1×)', () => {
    const parts = (n: string) => ruleProposal('Cilj: mišice. Rad delam: fitnes. Izkušnje: nekaj.', [{ id: 'dni', q: 'Koliko dni na teden?', a: n }, { id: 'izkusnje', q: 'Izkušnje', a: 'nekaj izkušenj' }], 30).focus.sessions.filter(isStrength).map(s => s.part)
    expect(parts('3')).toEqual(['zgornji', 'spodnji', 'celo'])
    expect(parts('4')).toEqual(['zgornji', 'spodnji', 'zgornji', 'spodnji'])
  })
})

describe('A22: kolesarska moč doma brez uteži napreduje', () => {
  const home = { ...BASE, strength: { on: true, equipment: 'home' }, gear: { bikeOutdoor: true, trainer: false, noBike: false } } as unknown as Profile
  const log = (date: string, ex: { name: string; sets: number; reps: string; kg?: number | null }[], name = 'Moč — noge in jedro'): Activity => ({ id: date + name, source: 'manual', sport: 'moc', date, name, exercises: ex, aiEligible: true, geoRetain: true, createdAt: NOW, updatedAt: NOW } as Activity)
  it('vse ponovitve brez kg: serija več (do 4) in vrstica »Prejšnjič vse ponovitve — danes …«', () => {
    const s = strengthSession('noge', home, [log('2026-10-08', [{ name: 'Bolgarski počep', sets: 3, reps: '12, 12, 12' }])])
    expect(s.exercises.find(e => e.name === 'Bolgarski počep')).toMatchObject({ sets: 4, reps: '8–12' })
    expect(s.desc).toMatch(/Prejšnjič vse ponovitve — danes Bolgarski počep 4 serije\./)
    expect(s.progressed).toBe(true)
  })
  it('4 serije na zgornji meji → več ponovitev; nato počasen spust; manj ponovitev → ostane', () => {
    const more = strengthSession('noge', home, [log('2026-10-08', [{ name: 'Bolgarski počep', sets: 4, reps: '12, 12, 12, 12' }])])
    expect(more.exercises.find(e => e.name === 'Bolgarski počep')).toMatchObject({ sets: 4, reps: '12–16' })
    const slow = strengthSession('noge', home, [log('2026-10-08', [{ name: 'Bolgarski počep', sets: 4, reps: '16, 16, 16, 16' }])])
    expect(slow.exercises.find(e => e.name === 'Bolgarski počep')!.reps).toBe('12–16, počasi dol')
    expect(slow.desc).toMatch(/dodaj nahrbtnik/)
    // vodena vadba: »počasi dol« ni vaja na čas
    const st = stepsFor({ kind: 'moc', title: slow.title, desc: slow.desc, durationMin: slow.min, exercises: slow.exercises } as PlanDay, home)
    expect(st.find(x => x.label === 'Bolgarski počep')!.sec).toBe(0)
    const same = strengthSession('noge', home, [log('2026-10-08', [{ name: 'Bolgarski počep', sets: 3, reps: '12, 10, 9' }])])
    expect(same.exercises.find(e => e.name === 'Bolgarski počep')).toMatchObject({ sets: 3, reps: '8–12' })
  })
  it('deska: po dveh polnih sejah na istem času +15 s (do 90 s); po eni ne', () => {
    const one = strengthSession('noge', home, [log('2026-10-08', [{ name: 'Deska', sets: 3, reps: '45–60 s' }])])
    expect(one.exercises.find(e => e.name === 'Deska')!.reps).toBe('45–60 s')
    const two = strengthSession('noge', home, [log('2026-10-05', [{ name: 'Deska', sets: 3, reps: '45–60 s' }]), log('2026-10-08', [{ name: 'Deska', sets: 3, reps: '45–60 s' }])])
    expect(two.exercises.find(e => e.name === 'Deska')!.reps).toBe('60–75 s')
    const top = strengthSession('noge', home, [log('2026-10-05', [{ name: 'Deska', sets: 3, reps: '75–90 s' }]), log('2026-10-08', [{ name: 'Deska', sets: 3, reps: '75–90 s' }])])
    expect(top.exercises.find(e => e.name === 'Deska')!.reps).toBe('75–90 s')
  })
  it('po lažjem tednu (serija manj) ostane, kjer si bil — ne nazaj na 3 × 8–12', () => {
    const s = strengthSession('noge', home, [log('2026-10-01', [{ name: 'Bolgarski počep', sets: 4, reps: '12, 12, 12, 12' }]), log('2026-10-08', [{ name: 'Bolgarski počep', sets: 2, reps: '10, 10' }])])
    expect(s.exercises.find(e => e.name === 'Bolgarski počep')).toMatchObject({ sets: 4, reps: '12–16' })
  })
  it('z vsemi ročkami, ki jih imaš (10 kg): kg ostanejo, serija več', () => {
    const db = { ...home, gear: { ...home.gear, dumbbells: true, dumbbellKg: 10 } } as Profile
    const s = strengthSession('noge', db, [log('2026-10-08', [{ name: 'Bolgarski počep', sets: 3, reps: '12', kg: 10 }])])
    expect(s.exercises.find(e => e.name === 'Bolgarski počep')).toMatchObject({ kg: 10, sets: 4 })
  })
})

describe('N2: »Fitnes — noge (težko)« — načrtovano trajanje kot vodena vadba', () => {
  it('65 min (časovniki ~59 min in serije); lažji teden ostane 41 min', () => {
    const gym = { ...BASE, strength: { on: true, equipment: 'gym' } } as unknown as Profile
    const s = strengthSession('fitnesA', gym, [])
    expect(s.min).toBe(65)
    const st = stepsFor({ kind: 'moc', title: s.title, desc: s.desc, durationMin: s.min, exercises: s.exercises } as PlanDay, gym)
    const est = (totalSec(st) + st.filter(x => x.kind === 'vaja' && !x.sec).length * 30) / 60
    expect(Math.abs(est - s.min)).toBeLessThanOrEqual(5)
    expect(strengthSession('fitnesA', gym, [], true).min).toBe(41)
  })
})

const day = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: date + (o.kind || 'kolo'), date, kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, zone: 'Z2', role: 'lahka', tssTarget: 42, source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })
const P = { sex: 'm', age: 30, heightCm: 180, weightKg: 75, ftp: 250, maxHr: 190, restHr: 50, lthr: 172, gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: true }, strength: { on: false, equipment: 'none' }, onboardingDone: true, createdAt: NOW, updatedAt: NOW } as unknown as Profile

describe('A23: »Po jutranjem vnosu« po vrsti treninga', () => {
  it('dolga Z2: brez »intervalov«, skrajšaj za tretjino, jej od 30. minute', () => {
    const t = mildAdvice({ kind: 'kolo', role: 'dolga', durationMin: 105 }, ['malo energije'])
    expect(t).not.toMatch(/interval/)
    expect(t).toBe('Malo energije: drži se spodnjega dela Z2 in po potrebi skrajšaj na ~1 h 10 min. Jej od 30. minute.')
    expect(mildAdvice({ kind: 'tek', role: 'dolga', durationMin: 75 }, ['noge malo bolijo'])).not.toMatch(/Jej/)
  })
  it('ključni: pol intervalov ali Z2 (kot prej); test: prestavi', () => {
    expect(mildAdvice({ kind: 'kolo', role: 'kljucna', durationMin: 75 }, ['slab spanec'])).toMatch(/pol intervalov/)
    expect(mildAdvice({ kind: 'test', role: 'test', durationMin: 60 }, ['slab spanec'])).toMatch(/prestavi/)
  })
})

describe('A27: »Imam samo X min« — krajše, jedro ostane', () => {
  const vo2 = day('2026-10-20', { title: 'VO2max 4 × 4 min', desc: '20 min ogrevanje s 3 kratkimi pospeški. 4 × 4 min pri 270–290 W (108–115 % FTP), vmes 4 min lahko. 10 min iztek.', durationMin: 75, zone: 'Z5', role: 'kljucna', tssTarget: 80, target: { lo: 270, hi: 290 } })
  const work = (d: PlanDay) => stepsFor(d, P).filter(s => s.kind === 'delo')
  it('ključni trening: ponovitve ostanejo, ogrevanje 10 min, iztek 5 min; ne krajše, kot ponovitve rabijo', () => {
    const r = shortenDay(vo2, P, 45)!
    expect(work(r.day)).toHaveLength(work(vo2).length)
    expect(r.day.desc).toMatch(/^10 min ogrevanje/)
    expect(r.day.desc).toMatch(/5 min iztek/)
    expect(r.min).toBe(45)
    expect(Math.round(totalSec(stepsFor(r.day, P)) / 60)).toBeLessThanOrEqual(45)
    // (POPRAVKI-DOM R7) delo ostane — odpade samo 30 min lahkega vrtenja (~0,7 TSS/min), ne sorazmerno (prej 48)
    expect(r.day.tssTarget).toBe(Math.round(80 - 30 * (0.65 * 0.65 * 100) / 60))
    expect(r.day.tssTarget!).toBeGreaterThan(Math.round(80 * 45 / 75))
    const tight = shortenDay(vo2, P, 30)!
    expect(tight.min).toBeGreaterThan(30)
    expect(work(tight.day)).toHaveLength(4)
  })
  it('dolga vožnja: sorazmerno krajša, naslov in obremenitev; ponovitev ni', () => {
    const long = day('2026-10-24', { title: 'Kolo — daljša vožnja 1 h 45 min', durationMin: 105, role: 'dolga', tssTarget: 74, kcalBurn: 900 })
    const r = shortenDay(long, P, 60)!
    expect(r.day).toMatchObject({ durationMin: 60, title: 'Kolo — daljša vožnja 1 h', tssTarget: Math.round(74 * 60 / 105), kcalBurn: Math.round(900 * 60 / 105) })
  })
  it('moč: vaje po vrsti, manj serij (najmanj 2), prva vaja ostane', () => {
    const ex = ['Počep s palico', 'Potisk s palico na ravni klopi', 'Veslanje na kablu sede', 'Romunski mrtvi dvig s palico', 'Poteg na prsi', 'Deska'].map((name, i) => ({ name, sets: i < 2 ? 4 : 3, reps: name === 'Deska' ? '30–45 s' : '6–10', rest: 120 }))
    const gymDay = day('2026-10-20', { kind: 'moc', title: 'Fitnes — celo telo', desc: '8–10 min ogrevanja (kolo ali veslanje), nato prva vaja 1–2 lažji seriji. Med serijami 90 s.', durationMin: 60, zone: null, role: 'moc', tssTarget: 48, exercises: ex })
    const r = shortenDay(gymDay, P, 30)!
    expect(r.day.exercises![0]!.name).toBe('Počep s palico')
    expect(r.day.exercises!.length).toBeGreaterThanOrEqual(3)
    expect(r.day.exercises!.every(e => e.sets >= 2)).toBe(true)
    expect(r.day.exercises!.reduce((a, e) => a + e.sets, 0)).toBeLessThan(ex.reduce((a, e) => a + e.sets, 0))
    expect(r.min).toBeLessThan(60)
  })
  it('ni izbire: opravljeno, test, tekma; izbire samo krajše od treninga', () => {
    expect(shortOptions(vo2)).toEqual([20, 30, 45, 60].filter(m => m <= 65))
    expect(shortOptions({ ...vo2, done: { at: NOW, activityId: null } })).toEqual([])
    expect(shortOptions({ ...vo2, kind: 'test', role: 'test' })).toEqual([])
    expect(shortOptions({ ...vo2, role: 'dirka' })).toEqual([])
    expect(shortOptions({ ...vo2, durationMin: 25 })).toEqual([])
  })
})

describe('C18: prvi dogovor pozno — načrt začne jutri', () => {
  it('»zjutraj« po 12. uri, »zvečer« po 21. uri, sicer po 20. uri', () => {
    expect(startsTomorrow('zjutraj', 11)).toBe(false)
    expect(startsTomorrow('zjutraj', 12)).toBe(true)
    expect(startsTomorrow('zvecer', 20)).toBe(false)
    expect(startsTomorrow('zvecer', 21)).toBe(true)
    expect(startsTomorrow(null, 19)).toBe(false)
    expect(startsTomorrow('popoldne', 21)).toBe(true)
  })
})

describe('C19: prvi dan počitek — kdaj je prvi trening', () => {
  const rest = (date: string) => day(date, { kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, role: null })
  const today = '2026-10-17'
  it('prvi neopravljen trening po danes; nič, ko je kaj že za tabo', () => {
    const plan = [rest(today), rest('2026-10-18'), day('2026-10-19', { kind: 'moc', title: 'Fitnes — zgornji del' }), day('2026-10-21', { kind: 'tek' })]
    expect(firstTraining(plan, today)!.date).toBe('2026-10-19')
    expect(firstTraining([...plan, day('2026-10-16', { kind: 'tek' })], today)).toBeNull()
    expect(firstTraining(plan.map(d => d.date === '2026-10-19' ? { ...d, done: { at: NOW, activityId: null } } : d), today)).toBeNull()
    expect(firstTraining([rest(today), day('2026-10-18', { optional: true })], today)).toBeNull()
  })
})

describe('D06: Danes v mirovanju — animacije pozornosti niso neskončne', () => {
  it('dihanje dneva in kartice, pilula, obroč (vrtenje in sij): končno število ciklov', () => {
    const css = readFileSync('src/styles/motion.css', 'utf8') + readFileSync('src/styles/base.css', 'utf8')
    for (const name of ['dayBreathe', 'spotBreathe', 'pillFloat', 'ringSpin', 'ringGlow']) {
      const uses = css.split('\n').filter(l => new RegExp(`animation:[^;]*\\b${name}\\b`).test(l))
      expect(uses.length, name).toBeGreaterThan(0)
      for (const l of uses) expect(l, name).not.toMatch(new RegExp(`${name}[^,;]*infinite`))
    }
  })
})
