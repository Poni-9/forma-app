import { describe, it, expect, vi, afterEach, beforeEach } from 'vitest'
vi.mock('@/data/firebase', () => ({ idToken: async () => null }))
vi.mock('@/config', async (orig) => ({ ...(await orig() as object), ICU_CLIENT_ID: 'cid123' }))
import { finishIcuOAuth, icuOauthOn, probeIcuOauth } from '../src/data/icuOauth'
import { icuReady, fetchWellness } from '../src/domain/intervals/client'

beforeEach(() => { sessionStorage.clear(); history.replaceState(null, '', '/') })
afterEach(() => { vi.unstubAllGlobals() })

describe('intervals.icu OAuth (Poveži z enim dotikom)', () => {
  it('povezava je uporabna z žetonom ali ključem; žeton gre v glavo kot Bearer', async () => {
    expect(icuReady({ athleteId: '0', apiKey: '', token: 't' })).toBe(true)
    expect(icuReady({ athleteId: 'i1', apiKey: '' })).toBe(false)
    expect(icuReady(null)).toBe(false)
    const f = vi.fn(async (_u: string, _i?: RequestInit) => new Response('[]', { status: 200 }))
    vi.stubGlobal('fetch', f)
    await fetchWellness({ athleteId: '0', apiKey: '', token: 'tok' }, '2026-09-01', '2026-09-25')
    expect((f.mock.calls[0]![1]!.headers as Record<string, string>).Authorization).toBe('Bearer tok')
    expect(String(f.mock.calls[0]![0])).toContain('/athlete/0/wellness')
  })
  it('gumb se pokaže šele, ko strežnik javi, da je OAuth nastavljen (/health → icu)', async () => {
    expect(icuOauthOn()).toBe(false)
    const h = vi.fn(async (_u: string) => new Response(JSON.stringify({ ok: true, icu: true }), { status: 200 }))
    vi.stubGlobal('fetch', h)
    expect(await probeIcuOauth()).toBe(true)
    expect(String(h.mock.calls[0]![0])).toMatch(/\/health$/)
    expect(icuOauthOn()).toBe(true)
  })
  it('vrnitev s kodo: strežnik zamenja kodo za žeton, naslov se počisti na #/uvoz', async () => {
    expect(icuOauthOn()).toBe(true)
    sessionStorage.setItem('icu.oauth.state', 's1')
    history.replaceState(null, '', '/?code=abc&state=s1')
    const f = vi.fn(async (_u: string, _i?: RequestInit) => new Response(JSON.stringify({ access_token: 'tok', scope: 'ACTIVITY:READ', athlete: { id: '99', name: 'Blaž' } }), { status: 200 }))
    vi.stubGlobal('fetch', f)
    const r = await finishIcuOAuth()
    expect(r).toEqual({ token: 'tok', athleteId: '0', name: 'Blaž', scope: 'ACTIVITY:READ' })
    expect(String(f.mock.calls[0]![0])).toMatch(/\/icu\/token$/)
    expect(JSON.parse(String(f.mock.calls[0]![1]!.body))).toEqual({ code: 'abc', redirect_uri: `${location.origin}/` })
    expect(location.search).toBe(''); expect(location.hash).toBe('#/uvoz')
  })
  it('napačno stanje ali zavrnjen dostop → napaka, brez klica strežnika; brez kode → nič', async () => {
    const f = vi.fn(); vi.stubGlobal('fetch', f)
    sessionStorage.setItem('icu.oauth.state', 's1'); history.replaceState(null, '', '/?code=abc&state=zlo')
    expect(await finishIcuOAuth()).toEqual({ error: 'Povezava ni uspela (neveljavno stanje) — poskusi znova.' })
    history.replaceState(null, '', '/?error=access_denied&state=s1')
    expect(await finishIcuOAuth()).toEqual({ error: 'Dostop ni bil potrjen.' })
    history.replaceState(null, '', '/#/danes')
    expect(await finishIcuOAuth()).toBeNull()
    expect(f).not.toHaveBeenCalled()
  })
})
