import { describe, it, expect, vi, afterEach, beforeEach } from 'vitest'

const st = vi.hoisted(() => ({ initFails: 1, user: null as null | Record<string, unknown>, reauth: 0, deletedUser: 0, deletedDoc: [] as string[] }))
vi.mock('firebase/app', () => ({ getApps: () => [], getApp: () => ({}), initializeApp: () => { if (st.initFails-- > 0) throw new Error('brez omrežja'); return {} } }))
vi.mock('firebase/auth', () => {
  class GoogleAuthProvider { setCustomParameters() { /* */ } }
  return {
    GoogleAuthProvider,
    getAuth: () => ({ get currentUser() { return st.user } }),
    setPersistence: async () => undefined, browserLocalPersistence: {}, getRedirectResult: async () => null,
    onAuthStateChanged: () => () => undefined,
    reauthenticateWithPopup: async () => { st.reauth++ },
    deleteUser: async () => { st.deletedUser++ },
    signOut: async () => undefined,
  }
})
vi.mock('firebase/firestore', () => ({ getFirestore: () => ({}), doc: (_f: unknown, c: string, id: string) => `${c}/${id}`, deleteDoc: async (p: string) => { st.deletedDoc.push(p) } }))

import { core, deleteAccount, setAccountDeleteHooks } from '../src/data/firebase'

beforeEach(() => { st.reauth = 0; st.deletedUser = 0; st.deletedDoc = []; st.user = { uid: 'u1', email: 'a@b.si', getIdToken: async () => 'svež-žeton' } })
afterEach(() => { vi.unstubAllGlobals(); setAccountDeleteHooks({}) })

describe('Firebase', () => {
  it('neuspel zagon se ne zapomni: naslednji klic poskusi znova', async () => {
    expect(await core()).toBeNull()
    expect(await core()).not.toBeNull()
  })
})

describe('izbris računa (strežnik /account/delete)', () => {
  it('403 reauth → ponovna prijava z Googlom in še en poskus; pred klicem ustavi sinhronizacijo; pilotId gre strežniku', async () => {
    const calls: { url: string; init?: RequestInit }[] = []
    let n = 0
    vi.stubGlobal('fetch', vi.fn(async (url: string, init?: RequestInit) => { calls.push({ url, init }); return n++ === 0 ? new Response(JSON.stringify({ error: 'reauth' }), { status: 403 }) : new Response('{}', { status: 200 }) }))
    const before = vi.fn(), failed = vi.fn()
    setAccountDeleteHooks({ before, failed, pilotId: () => 'anon7' })
    const r = await deleteAccount()
    expect(r).toEqual({ ok: true, reauth: false, via: 'server' })
    expect(before).toHaveBeenCalledTimes(1); expect(failed).not.toHaveBeenCalled()
    expect(st.reauth).toBe(1)
    expect(calls).toHaveLength(2)
    expect(calls[0]!.url).toMatch(/\/account\/delete$/)
    expect((calls[1]!.init!.headers as Record<string, string>).Authorization).toBe('Bearer svež-žeton')
    expect(JSON.parse(String(calls[1]!.init!.body))).toEqual({ pilotId: 'anon7' })
    expect(st.deletedUser).toBe(0)
  })
  it('404 (strežnik poti še nima) → izbris na odjemalcu (dokument + račun)', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('', { status: 404 })))
    const r = await deleteAccount('x')
    expect(r).toEqual({ ok: true, reauth: false, via: 'client' })
    expect(st.deletedDoc).toEqual(['formaSync/u1']); expect(st.deletedUser).toBe(1)
  })
  it('napaka strežnika → neuspeh, sinhronizacija se nadaljuje (kljuka failed)', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('', { status: 500 })))
    const failed = vi.fn()
    setAccountDeleteHooks({ failed })
    const r = await deleteAccount()
    expect(r.ok).toBe(false); expect(r.error).toMatch(/500/)
    expect(failed).toHaveBeenCalledTimes(1)
  })
})
