// v3.48 N2 — Prehrana in Napredek: ročni vpis brez negativnih kalorij, gorivo ni »pogost obrok«, »Na kolesu« ob pravem
// času, povprečje brez današnjega dne, prihodnji dan samo cilj, presežen obrok ni zelen, tempo teže po varovalki,
// izračunana ciljna teža, mišice in testi po dogovoru, doslednost od začetka, dostopna polja, sklon in množina.
import 'fake-indexeddb/auto'
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { readFileSync } from 'node:fs'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'prehrana', params: {} as Record<string, string> } }))
vi.mock('@/state/store', async (orig) => ({
  ...(await orig<typeof import('../src/state/store')>()),
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
}))
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => S.route, subscribeRoute: () => () => undefined }))

import * as repo from '../src/data/repo'
import { Prehrana, draftError, frequentMeals, slotTone } from '@/screens/Prehrana'
import { weightPace, consistencyDays, showMuscles, offeredTests, TestSheet } from '@/screens/Napredek'
import { WeighSheet } from '@/ui/WeighSheet'
import { RecordsCard } from '@/ui/RecordsCard'
import { DotLineChart } from '@/ui/charts'
import { FRANJA_2027 } from '@/domain/training/planner'
import type { Activity, MealEntry, PlanDay, Profile, Focus } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const NOW = '2026-10-01T08:00:00.000Z'
const TODAY = '2026-10-17'
const P = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 180, weightKg: 80, restHr: 55, maxHr: 200, lthr: 184, ftp: 240, ftpDate: '2026-09-20',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, hoursPerWeek: 14, baseHours: null,
  strength: { on: false, equipment: 'home', phases: null }, strengthDays: 0, goal: 'dirka', deficit: 300, neat: 1.4,
  event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', onboardingDone: true, trainTime: 'popoldne', createdAt: NOW, updatedAt: NOW,
  races: [], ...o,
} as Profile)
const ride = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: 'r' + date, date, kind: 'kolo', title: 'Dolga Z2', desc: '', durationMin: 105, zone: 'Z2', role: 'dolga', source: 'rules', createdAt: NOW, updatedAt: NOW, ...o })
const meal = (date: string, slot: MealEntry['slot'], kcal: number, o: Partial<MealEntry> = {}): MealEntry => ({ id: `${date}-${slot}-${kcal}-${o.name || ''}`, date, slot, name: o.name || slot, kcal, source: 'manual', createdAt: NOW, time: o.time ?? null, ...o })

let div: HTMLDivElement, root: Root
async function render(el: React.ReactElement) {
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root.render(el) })
  return text()
}
const text = () => (document.body.textContent || '').replace(/[  ]/g, ' ')
afterEach(async () => { await act(async () => root?.unmount()); div?.remove(); vi.useRealTimers() })

function setState(o: { meals?: MealEntry[]; recent?: MealEntry[]; plan?: PlanDay[]; profile?: Profile; hour?: number } = {}) {
  vi.useFakeTimers({ toFake: ['Date'] })
  vi.setSystemTime(new Date(`${TODAY}T${String(o.hour ?? 8).padStart(2, '0')}:30:00`))
  const meals = o.meals || []
  S.state = { ready: true, settings: repo.defaultSettings(), changes: [], toast: null, sync: { state: 'off' }, authKnown: true, pro: false, wellness: null, checkinToday: null, today: TODAY, profile: o.profile || P(), plan: o.plan || [ride(TODAY)], activities: [], mealsToday: meals, recentMeals: [...(o.recent || []), ...meals], checkins: [], weather: null, user: null }
}
const planCard = () => [...document.querySelectorAll('.card')].find(c => /po načrtu/.test(c.querySelector('h2')?.textContent || ''))?.textContent?.replace(/[  ]/g, ' ') || ''

describe('Prehrana — vpis (C17, C18)', () => {
  it('C17: ročni vpis ne sprejme negativnih ali nesmiselnih kalorij in makrov', () => {
    const d = { name: 'test', kcal: '-900', prot: '-50', carb: '', fat: '', grams: '' }
    expect(draftError(d)).toBe('Kalorije morajo biti med 1 in 5 000.')
    expect(draftError({ ...d, kcal: '9000', prot: '' })).toBe('Kalorije morajo biti med 1 in 5 000.')
    expect(draftError({ ...d, kcal: '500' })).toBe('Grami in makri ne morejo biti negativni.')
    expect(draftError({ ...d, kcal: '500', prot: '', grams: '-100' })).toBe('Grami in makri ne morejo biti negativni.')
    expect(draftError({ ...d, kcal: '200', prot: '150' })).toBe('Makri so previsoki za te kalorije — preveri številke.')
    expect(draftError({ ...d, name: ' ', kcal: '500', prot: '' })).toBe('Vpiši vsaj ime in kalorije.')
    expect(draftError({ name: 'skuta z jagodami', kcal: '620', prot: '41', carb: '88', fat: '26', grams: '' })).toBeNull()
  })
  it('C18: gorivo na kolesu (med vožnjo, vezano na vožnjo) ni med pogostimi obroki', () => {
    const fuel = (d: string) => meal(d, 'med_vadbo', 265, { name: 'Na kolesu (Z2 vzdržljivost): 1 × bidon', forDay: 'r' + d, fuel: { banana: 1 } })
    const recent = ['2026-10-10', '2026-10-11', '2026-10-12'].flatMap(d => [fuel(d), meal(d, 'zajtrk', 620, { name: 'Ovseni kosmiči' })])
    expect(frequentMeals(recent).map(m => m.name)).toEqual(['Ovseni kosmiči'])
  })
})

describe('Prehrana — načrt obrokov (C31, C44)', () => {
  it('C31: zjutraj (naslednji je zajtrk) brez bloka »Na kolesu«; ko je na vrsti kosilo pred vožnjo, je blok tu', async () => {
    setState({ hour: 8 })
    await render(<Prehrana />)
    expect(planCard()).toMatch(/Zajtrk/)
    expect(planCard()).not.toMatch(/Na kolesu/)
    await act(async () => root.unmount()); div.remove()
    setState({ hour: 12, meals: [meal(TODAY, 'zajtrk', 760, { time: '08:00' })] })
    await render(<Prehrana />)
    expect(planCard()).toMatch(/Kosilo.*Na kolesu/)
  })
  it('C44: nad ciljem — sporočilo »nad ciljem« namesto »Vsi obroki pojedeni«; presežen obrok ni zelen', async () => {
    setState({ hour: 15, meals: [meal(TODAY, 'zajtrk', 1500, { time: '08:00' }), meal(TODAY, 'kosilo', 1300, { time: '12:00' }), meal(TODAY, 'malica', 700, { time: '14:00' })] })
    await render(<Prehrana />)
    expect(planCard()).toMatch(/Danes si že nad ciljem \(\+\d[\d ]* kcal\)\. Ostane samo obnova po vožnji\./)
    expect(planCard()).not.toMatch(/Vsi obroki po načrtu so za danes pojedeni/)
    expect(slotTone(1500, 740)).toBe('var(--warn)')
    expect(slotTone(700, 740)).toBe('var(--ok)')
    expect(slotTone(0, 0)).toBe('var(--ink)')
    expect(slotTone(300, 740)).toBe('var(--ink)')
  })
})

describe('Prehrana — prihodnji dan, sklon, enote, povprečje (C27, C32, C34, C43)', () => {
  it('C43 + C27: jutri samo cilj (brez obroča »0 od …«), »za nedeljo«', async () => {
    setState()
    S.route = { name: 'prehrana', params: { dan: '2026-10-18' } }
    await render(<Prehrana />)
    S.route = { name: 'prehrana', params: {} }
    const t = text()
    expect(t).toMatch(/Cilj tega dne/)
    expect(t).not.toMatch(/\b0 od /)
    expect(t).not.toMatch(/Beljakovine 0 \//)
    expect(t).toMatch(/Načrt obrokov za nedeljo, 18\. 10\./)
  })
  it('C27: pretekli dan »Vpis za soboto«', async () => {
    setState()
    S.route = { name: 'prehrana', params: { dan: '2026-10-10' } }
    await render(<Prehrana />)
    S.route = { name: 'prehrana', params: {} }
    expect(text()).toMatch(/Vpis za soboto, 10\. 10\./)
  })
  it('C33: povezava ?dan= starejša od 90 dni odpre danes; onemogočen čip brez inline prosojnosti', async () => {
    setState()
    S.route = { name: 'prehrana', params: { dan: '2026-06-01' } }
    await render(<Prehrana />)
    S.route = { name: 'prehrana', params: {} }
    expect(text()).not.toMatch(/Vpis za/)
    const css = readFileSync('src/styles/base.css', 'utf8')
    expect(css).toMatch(/\.chip:disabled \{ opacity: \.4; cursor: default; \}/)
    expect(readFileSync('src/screens/Prehrana.tsx', 'utf8')).not.toMatch(/opacity: day >= /)
  })
  it('C34 + C32: »620 kcal« z enoto; povprečje 7 dni brez današnjega dneva', async () => {
    setState({ hour: 9, meals: [meal(TODAY, 'zajtrk', 728, { time: '08:00', name: 'Skuta' })], recent: [meal('2026-10-16', 'kosilo', 2400, { name: 'Ovseni kosmiči' }), meal('2026-10-15', 'kosilo', 2600, { name: 'Ovseni kosmiči' })] })
    await render(<Prehrana />)
    const t = text()
    expect(t).toMatch(/Ovseni kosmiči2 600 kcal/)            // pogost obrok z enoto
    expect(t).toMatch(/Skuta.*728 kcal/)                       // vrstica obroka z enoto
    expect(t).toMatch(/povprečno 2 500 kcal · 3\/7 dni/)       // (2400 + 2600) / 2, današnji zajtrk ne šteje
  })
  it('C32: samo današnji vpis — »danes do zdaj«, ne »povprečno«', async () => {
    setState({ hour: 9, meals: [meal(TODAY, 'zajtrk', 728, { time: '08:00' })] })
    await render(<Prehrana />)
    expect(text()).toMatch(/danes do zdaj 728 kcal · 1\/7 dni/)
    expect(text()).not.toMatch(/povprečno 728/)
  })
})

describe('Napredek — teža, doslednost, mišice in testi (C22, D42, D43)', () => {
  const base = { stale: false, dw: 1, target: 72, avg7: 79, weeksTo: 12, today: TODAY }
  it('C22: −0,6 kg na teden ni »Tempo je pravi« (meja 0,5 kot varovalka); −0,4 je', () => {
    const fast = weightPace({ ...base, rate: -0.6 })
    expect(fast.text).toBe('Izgubljaš 0,6 kg na teden — več kot 0,5 kg je prehitro, gredo vati. Dodaj 150–250 kcal na dan.')
    expect(fast.color).toBe('var(--warn)')
    expect(weightPace({ ...base, rate: -0.8 }).text).toMatch(/več kot 0,7 kg/)
    const ok = weightPace({ ...base, rate: -0.4 })
    expect(ok.text).toMatch(/^Tempo je pravi\./)
    expect(ok.color).toBe('var(--ok)')
  })
  it('D43: doslednost od začetka — prvi dan imenovalec 1, po 10 dneh 10, nato največ 28', () => {
    expect(consistencyDays({ createdAt: `${TODAY}T07:00:00.000Z` }, TODAY)).toBe(1)
    expect(consistencyDays({ createdAt: '2026-10-08T07:00:00.000Z' }, TODAY)).toBe(10)
    expect(consistencyDays({ createdAt: '2026-01-01T07:00:00.000Z', goalStart: { date: TODAY } as never }, TODAY)).toBe(28)
    expect(consistencyDays({ createdAt: '' }, TODAY)).toBe(28)
  })
  it('D42: kartica Mišice in testi moči samo z močjo v dogovoru; kolo → FTP', () => {
    const focus = (types: string[]): Focus => ({ v: 1, mode: 'meri', wish: '', sports: types, sessions: types.map(t => ({ type: t, min: 60 })) } as unknown as Focus)
    expect(showMuscles({ focus: focus(['kolo', 'kolo']) }, 0)).toBe(false)
    expect(showMuscles({ focus: focus(['kolo', 'fitnes']) }, 0)).toBe(true)
    expect(showMuscles({ focus: null } as never, 12)).toBe(true)
    expect(offeredTests(true, true, false).map(t => t.kind)).toEqual(['ftp', 'p5', 'rhr'])
    expect(offeredTests(true, false, true).map(t => t.kind)).toEqual(['rhr', 'deska', 'zgibi', 'sklece', 'pocep'])
    expect(offeredTests(false, true, false).map(t => t.kind)).toEqual(['ftp', 'p5', 'rhr', 'deska'])
  })
})

describe('dostopna polja, × in drobno (C20, C21, C35, C36, C23, C24, C25)', () => {
  beforeEach(() => { setState() })
  it('C20: Tehtanje in Vpiši test — polja imajo ime (label for → id)', async () => {
    await render(<WeighSheet open onClose={() => undefined} />)
    for (const id of ['weigh-kg', 'weigh-waist']) {
      expect(document.getElementById(id)?.tagName).toBe('INPUT')
      expect(document.querySelector(`label[for="${id}"]`)).not.toBeNull()
    }
    await act(async () => root.unmount()); div.remove()
    await render(<TestSheet open onClose={() => undefined} />)
    expect(document.getElementById('test-val')?.tagName).toBe('INPUT')
    expect(document.querySelector('label[for="test-val"]')?.textContent).toMatch(/Rezultat/)
  })
  it('C21: × pri testu in obroku z razredom icon-x (najmanj 32 × 32 px)', () => {
    expect(readFileSync('src/styles/base.css', 'utf8')).toMatch(/\.chip\.icon-x \{ min-width: 32px; min-height: 32px;/)
    expect(readFileSync('src/screens/Napredek.tsx', 'utf8')).toMatch(/className="chip sm click icon-x" onClick=\{\(\) => deferDelete\('test:'/)
    expect(readFileSync('src/screens/Prehrana.tsx', 'utf8')).toMatch(/className="chip sm click icon-x" onClick=\{\(\) => remove\(m\)\}/)
  })
  it('C36: »2 vožnji letos« (množina)', async () => {
    const a = (id: string, date: string): Activity => ({ id, date, sport: 'kolo', name: 'Vožnja', durationMin: 90, distKm: 40, elevM: 300, source: 'manual' } as Activity)
    await render(<RecordsCard acts={[a('a', '2026-03-01'), a('b', '2026-04-01')]} today={TODAY} />)
    expect(text()).toMatch(/2 vožnji letos\./)
  })
  it('C35: legenda 7-dnevnega povprečja v barvi črte', async () => {
    const pts = [{ date: '2026-10-10', v: 80 }, { date: '2026-10-12', v: 79.6 }, { date: '2026-10-14', v: 79.4 }]
    await render(<DotLineChart points={pts} line={pts} />)
    const leg = [...div.querySelectorAll('span.row')].find(s => /7-dnevno povprečje/.test(s.textContent || ''))!
    expect(leg.querySelector('i')!.getAttribute('style')).toMatch(/var\(--accent-fg\)/)
  })
  it('C23/C24/C25: izračunana ciljna teža, graf forme v Motorju, Kopiraj skozi sanitizeGaps', () => {
    const src = readFileSync('src/screens/Napredek.tsx', 'utf8')
    expect(src).toMatch(/const target = shownTargetWeight\(p, custom, today\)/)
    expect(src).toMatch(/<FormChart data=\{series\.slice\(-90\)\}/)
    expect(src).toMatch(/writeText\(`\$\{mText\(mNow\)\}\\n\$\{review \? sanitizeGaps\(review\.text, hidden\) : ''\}`\)/)
    expect(readFileSync('src/screens/Danes.tsx', 'utf8')).toMatch(/const goalKg = shownTargetWeight\(p, isCustom\(p\), today\)/)
  })
})
