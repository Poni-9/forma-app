// v3.49 TRENER (zaslon): odgovor brez surovega markdowna in zagotovil, lestvica maščobe pod vprašanjem o videzu (T01),
// ploščice vaj z lenimi slikami, ki odprejo Vaje na tej vaji (T02), neuspelo vprašanje ostane s »Poskusi znova« (A33),
// hitri gumb »Kako izgubim maščobo okoli pasu?« (A01).
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>() }))
const h = vi.hoisted(() => ({ run: vi.fn(async (fn: () => Promise<unknown>, _o?: { onError?: (m: string) => void }) => fn()) }))
vi.mock('@/state/store', () => ({
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  savePlanDays: vi.fn(), updateSettings: vi.fn(async () => {}), toast: vi.fn(), newCoachChat: vi.fn(), restorePlanDays: vi.fn(),
}))
vi.mock('@/app/Shell', () => ({ Head: () => null }))
vi.mock('@/ui/useAi', () => ({ useAi: () => ({ busy: false, signedIn: true, consent: true, run: h.run, sheet: null }) }))
vi.mock('@/state/snap', () => ({ snapOf: () => ({}) }))
vi.mock('@/data/db', () => ({ getKV: async () => undefined, setKV: async () => {} }))
vi.mock('@/ui/useDictation', () => ({ useDictation: () => ({ listening: false, canSpeak: false, toggle: () => {}, stop: () => {}, transcribing: false, level: 0 }) }))
vi.mock('@/ui/ListenBar', () => ({ ListenBar: () => null }))
vi.mock('@/ui/Confirm', () => ({ undoToast: vi.fn() }))

import { Trener } from '@/screens/Trener'
import { Vaje } from '@/screens/Vaje'
import { MINOR_TEXT } from '@/domain/coach/bodyfat'
import { HONEST_NOTE } from '@/domain/ai/sanitize'
import { normalizeFocus } from '@/domain/focus/model'
import type { Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

const NOW = '2026-10-17T08:00:00.000Z'
const base = { sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, strength: { on: false, equipment: 'none' }, onboardingDone: true, createdAt: NOW, updatedAt: NOW } as unknown as Profile
const Q = 'Do kdaj bom izklesan? A lahko pokažeš sliko, kako bom zgledal?'
const A = '**Zagotovim** ti six-pack do marca.\n### Plan\n* Deficit 400 kcal\n* 3 × 10 počepov in deska 3 × 45 s\n<img src=x onerror="window.__x=1"> [vir](javascript:alert(1))'
const reset = (p: Partial<Profile> = {}, msgs: { role: 'user' | 'ai'; text: string; at: string }[] = [{ role: 'user', text: Q, at: NOW }, { role: 'ai', text: A, at: NOW }]) => {
  S.state = { ready: true, today: '2026-10-17', plan: [], activities: [], checkins: [], recentMeals: [], weather: null, wellness: [], settings: { coach: { msgs, summary: null } }, user: { uid: 'u' }, authKnown: true, firstSync: true, profile: { ...base, ...p } }
  S.subs.forEach(f => f())
}

let div: HTMLDivElement, root: Root | null = null
async function mount(el: React.ReactElement) { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div); await act(async () => { root!.render(el) }) }
const flush = async () => { for (let i = 0; i < 5; i++) await act(async () => { await Promise.resolve() }) }
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(b.textContent || '')) as HTMLButtonElement | undefined

beforeEach(() => { reset(); h.run.mockClear(); window.scrollTo = vi.fn() as never; location.hash = '#/trener' })
afterEach(async () => { if (root) { await act(async () => root!.unmount()); root = null; div.remove() } document.body.innerHTML = '' })

describe('odgovor trenerja', () => {
  it('brez »**«, »###«, »* «, HTML in povezav; brez »zagotovim« s pripisom; seznam kot seznam', async () => {
    await mount(<Trener />)
    const ai = document.querySelector('.msg.ai')!
    const t = ai.textContent || ''
    expect(t).not.toMatch(/\*\*|###|<img|javascript|Zagotovim|six-pack/)
    expect(t).toContain(HONEST_NOTE)
    expect(ai.querySelectorAll('ul li')).toHaveLength(2)
    expect(ai.querySelector('.md-h')?.textContent).toBe('Plan')
    expect(ai.querySelector('img, a')).toBeNull()
    expect((window as { __x?: number }).__x).toBeUndefined()
  })
  it('T01: pod vprašanjem o videzu lestvica maščobe — zdaj (ocena), cilj in okvirni čas', async () => {
    await mount(<Trener />)
    const card = document.querySelector('.bf-card')!
    expect(card).not.toBeNull()
    const t = card.textContent || ''
    expect(t).toContain('zdaj ~18 % (ocena)')
    expect(t).toContain('cilj ~10–12 %')
    expect(t).toContain('okvirno 6–12 mesecev — ne obljuba')
    expect(card.querySelectorAll('.bf-seg')).toHaveLength(5)
    expect(card.querySelectorAll('.bf-seg.tgt')).toHaveLength(1)
    expect(t).not.toMatch(/zagotov/i)
    expect(card.querySelector('img')).toBeNull()                         // narisano, ne slika
  })
  it('T01: mladoletni — brez lestvice, en stavek o rasti', async () => {
    reset({ age: 16 })
    await mount(<Trener />)
    const card = document.querySelector('.bf-card')!
    expect(card.textContent).toBe(MINOR_TEXT)
    expect(card.querySelector('.bf-scale')).toBeNull()
  })
  it('T01: drugo vprašanje — brez lestvice', async () => {
    reset({}, [{ role: 'user', text: 'Koliko OH na dolgi vožnji?', at: NOW }, { role: 'ai', text: '60 g na uro.', at: NOW }])
    await mount(<Trener />)
    expect(document.querySelector('.bf-card')).toBeNull()
  })
  it('T02: ploščice vaj iz odgovora z lenimi slikami; dotik odpre Vaje na vaji', async () => {
    await mount(<Trener />)
    const tiles = [...document.querySelectorAll<HTMLButtonElement>('.coach-ex button')]
    expect(tiles.map(b => b.textContent)).toEqual(['Počep', 'Deska'])
    const imgs = [...document.querySelectorAll<HTMLImageElement>('.coach-ex img')]
    expect(imgs.length).toBeGreaterThan(0)
    expect(imgs.every(i => i.getAttribute('loading') === 'lazy')).toBe(true)
    await act(async () => { tiles[0]!.click() })
    expect(location.hash).toBe('#/vaje?v=pocep')
  })
})

describe('A33 napaka AI', () => {
  it('neuspelo vprašanje ostane v pogovoru z razlogom in »Poskusi znova«', async () => {
    h.run.mockImplementation(async (_fn, o) => { o?.onError?.('AI zdaj ne more odgovoriti — poskusi čez minuto.'); return undefined })
    reset({}, [])
    await mount(<Trener />)
    const input = document.querySelector<HTMLInputElement>('input.field')!
    await act(async () => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(input, 'Kaj pa jutri?'); input.dispatchEvent(new Event('input', { bubbles: true })) })
    await act(async () => { input.form!.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true })) })
    await flush()
    expect(document.querySelector('.msg.user.failed')?.textContent).toBe('Kaj pa jutri?')
    expect(document.querySelector('.msg-fail')?.textContent).toMatch(/^AI zdaj ne more odgovoriti — poskusi čez minuto\.Poskusi znova$/)
    expect(document.body.textContent).not.toMatch(/HTTP/)
    await act(async () => { btn(/^Poskusi znova$/)!.click() })
    await flush()
    expect(h.run).toHaveBeenCalledTimes(2)
  })
})

describe('A01 hitri gumb načrta po meri', () => {
  it('»Kako izgubim maščobo okoli pasu?« namesto »Kako do vidnega trebuha?«', async () => {
    const focus = normalizeFocus({ wish: 'fitnes', sports: ['fitnes'], aims: ['moc', 'hujsanje'], level: 2, equipment: ['fitnes'], sessions: [{ type: 'fitnes', part: 'celo', min: 60 }, { type: 'fitnes', part: 'celo', min: 60 }] }, { now: NOW, by: 'pravila' })!
    reset({ focus }, [])
    await mount(<Trener />)
    expect(btn(/^Kako izgubim maščobo okoli pasu\?$/)).toBeDefined()
    expect(btn(/vidnega trebuha/)).toBeUndefined()
  })
})

describe('T02 Vaje odprejo vajo iz povezave', () => {
  it('#/vaje?v=pocep odpre list »Počep«', async () => {
    // kot v aplikaciji: zaslon se izriše po prehodu (popstate/hashchange sta že mimo — sicer bi Nazaj zaprl list)
    location.hash = '#/vaje?v=pocep'
    await new Promise(r => setTimeout(r, 0))
    await mount(<Vaje />)
    await flush()
    expect(document.body.textContent).toContain('Stopala v širini ramen, boki nazaj in dol')
  })
})
