// v3.49 POPRAVKI-DOM: popravki ugotovitev REVIEW-DOMENA R1–R9 (reprodukcije revizorja, obrnjene v pričakovanja).
// R1 tempo teže pri tedenskem tehtanju, R2 tek in hoja po pogajanju na načrtu od Claude, R3 besedilo in gumb »Tek in hoja«,
// R4 stopnja po premoru, R5 oljke/sirup, R6 recipeOkFor, R7 TSS pri »Imam samo X min«, R8 ure v AI brez moči,
// R9 zapis iz načrta ob krajši vadbi drugega športa.
import { describe, it, expect } from 'vitest'
import { weightTrend, dailyTarget } from '../src/domain/nutrition/energy'
import { alerts } from '../src/domain/alerts'
import { buildFocusWeek, weekWords, RUN_WALK } from '../src/domain/training/focusPlan'
import { ruleAdjust, adjustNote, ruleProposal } from '../src/domain/focus/rules'
import { coachReview } from '../src/domain/focus/coach'
import { normalizeFocus, profileFromFocus } from '../src/domain/focus/model'
import { buildWeek, planHours, FRANJA_2027 } from '../src/domain/training/planner'
import { addDays } from '../src/domain/training/load'
import { standInsToDrop, standInFor, realOn } from '../src/domain/training/standin'
import { swapsPlanned } from '../src/domain/training/plandays'
import { shortenDay } from '../src/domain/training/danes'
import { stepsFor } from '../src/domain/training/workout'
import { estimateMeal } from '../src/domain/nutrition/localMeal'
import { recipeOkFor } from '../src/domain/nutrition/recipes'
import { personalContext } from '../src/domain/ai/personal'
import type { Activity, Focus, PlanDay, Profile } from '../src/domain/types'

const NOW = '2026-10-17T08:00:00.000Z'
const P = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 30, heightCm: 180, weightKg: 79, ftp: 240, ftpDate: '2026-09-20', maxHr: 200, restHr: 55, lthr: 184, level: 3,
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true }, hoursPerWeek: 9, hoursMode: 'own', strength: { on: true, equipment: 'none' }, strengthDays: 2,
  goal: 'dirka', deficit: 400, neat: 1.4, proteinGkg: 1.8, event: { ...FRANJA_2027 }, cycleStart: '2026-03-02', trainTime: 'popoldne',
  onboardingDone: true, createdAt: NOW, updatedAt: NOW, races: [], ...o,
} as Profile)
const ride = (date: string, min = 90, o: Partial<Activity> = {}): Activity => ({ id: 'a' + Math.random().toString(36).slice(2), source: 'manual', sport: 'kolo', date, name: 'x', durationMin: min, aiEligible: true, geoRetain: true, createdAt: NOW, updatedAt: NOW, ...o } as Activity)
const blank = { name: 'X', sex: 'm', age: 30, heightCm: 180, weightKg: 80, restHr: null, maxHr: null, lthr: null, ftp: null, ftpDate: null, goal: 'forma', gear: { bikeOutdoor: false, trainer: false, noBike: true, powerMeter: null }, hoursPerWeek: 4, hoursMode: 'own', strength: { on: false, equipment: 'none' }, strengthDays: 0, deficit: 0, neat: 1.4, proteinGkg: 1.6, event: null, races: [], level: 1, onboardingDone: true, createdAt: NOW, updatedAt: NOW } as unknown as Profile
const MON = '2026-10-12'
const qa3 = [{ id: 'dni', q: 'Koliko dni na teden?', a: '3' }, { id: 'cas', q: 'Koliko časa imaš za eno vadbo?', a: '30 min' }]

describe('R1 tempo teže pri tedenskem tehtanju', () => {
  it('tehtanje enkrat na teden, −1 kg na teden 4 tedne: tempo je (4 tehtanja v 21 dneh), opozorilo »prehitro« se sproži', () => {
    const ch = [['2026-09-13', 85], ['2026-09-20', 84], ['2026-09-27', 83], ['2026-10-04', 82], ['2026-10-11', 81]].map(([d, kg]) => ({ date: d as string, weightKg: kg as number }))
    const tr = weightTrend(ch)!
    expect(tr.nPace).toBe(4)
    expect(tr.deltaWeek).toBeCloseTo(-1, 2)
    const out = alerts({ profile: P({ weightKg: 81 }), activities: [], plan: [], checkins: ch, recentMeals: [], today: '2026-10-12' })
    expect(out.some(a => /prehitro/.test(a.text))).toBe(true)
  })
  it('tri tedenska tehtanja še niso tempo (B06 ostane); 22 dni nazaj izpade', () => {
    expect(weightTrend([{ date: '2026-10-03', weightKg: 80.4 }, { date: '2026-10-10', weightKg: 80.3 }, { date: '2026-10-17', weightKg: 79.4 }])!.deltaWeek).toBeNull()
    const tr = weightTrend([{ date: '2026-09-25', weightKg: 85 }, { date: '2026-10-03', weightKg: 84 }, { date: '2026-10-10', weightKg: 83 }, { date: '2026-10-17', weightKg: 82 }])!
    expect(tr.nPace).toBe(3)
    expect(tr.deltaWeek).toBeNull()
  })
})

describe('R2 tek in hoja po pogajanju na načrtu od Claude', () => {
  it('ruleAdjust »hoja in tek izmenično« na načrtu by: claude → teden ima tek in hojo (tudi seja s trenerjevim »kaj«), kcal po deležu', () => {
    const f0 = normalizeFocus({
      wish: 'rad bi začel teči in bil bolj fit', sports: ['tek', 'doma'], aims: ['kondicija'], muscles: [], level: 1, equipment: ['nic'],
      sessions: [{ type: 'tek', cardio: 'lahko', min: 30, what: 'Lahek tek 30 min v pogovornem tempu.' }, { type: 'tek', cardio: 'lahko', min: 30 }, { type: 'doma', part: 'celo', min: 40 }],
      offDays: [], notes: null,
    } as unknown as Focus, { age: 30, by: 'claude', now: NOW })!
    const f1 = ruleAdjust(f0, 'hoja in tek izmenično', 30)!
    expect(f1.by).toBe('claude')
    expect(f1.sessions.filter(s => s.type === 'tek').every(s => s.walk)).toBe(true)
    expect(adjustNote(f0, f1)).toMatch(/tek in hoja/)
    expect(weekWords(f1)).toMatch(/tek in hoja/)
    const p = P({ focus: f1, cycleStart: '2026-10-19', event: null, goal: 'forma', ftp: null, weightKg: 92, heightCm: 178 })
    const wk = buildFocusWeek({ profile: p, activities: [], weekStart: '2026-10-19', today: '2026-10-19', notBefore: '2026-10-19' })
    const runs = wk.filter(d => d.kind === 'tek')
    expect(runs.length).toBe(2)
    for (const d of runs) {
      expect(d.title).toMatch(/^Tek in hoja/)
      expect(d.desc).toMatch(/\(1 min tek \/ 1 min 30 s hoja\)/)
      expect(d.desc).not.toMatch(/Lahek tek 30 min/)
      expect(d.kcalBurn).toBeGreaterThan(0)
      expect(stepsFor(d, p).some(s => s.label === 'Hoja')).toBe(true)
    }
  })
})

describe('R3 besedilo in gumb »Tek in hoja«', () => {
  it('raven 1 (že stopnja 1) klikne »Tek in hoja«: obvestilo z minutami prve stopnje, teden na stopnji 0 (1 min tek / 1 min 30 s hoja)', () => {
    // (v3.50 C40) predlog po pravilih ima tek in hojo že sam — dogovor brez nje (od AI, starejši) se dobi tako, da se izbriše
    const fr = coachReview(ruleProposal('Cilj: kondicija. Rad delam: tek. Izkušnje: začenjam.', qa3, 30).focus, { age: 30 }).focus
    const f0 = { ...fr, sessions: fr.sessions.map(({ walk: _w, ...s }) => s) }
    const f1 = ruleAdjust(f0, 'Tek in hoja', 30)!
    const note = adjustNote(f0, f1)
    const [, run, walk] = RUN_WALK[0]!
    expect([run, walk]).toEqual([60, 90])
    expect(note).toMatch(/najprej 1 min teka in 1 min 30 s hoje/)
    expect(note).not.toMatch(/2 min hoje/)
    const p = { ...blank, ...profileFromFocus(f1, blank, MON, MON) } as Profile
    const before = buildFocusWeek({ profile: { ...blank, ...profileFromFocus(f0, blank, MON, MON) } as Profile, activities: [], weekStart: MON, notBefore: MON, today: MON }).find(d => d.kind === 'tek')!
    const run1 = buildFocusWeek({ profile: p, activities: [], weekStart: MON, notBefore: MON, today: MON }).find(d => d.kind === 'tek')!
    expect(before.desc).toMatch(/\(2 min tek \/ 1 min hoja\)/)
    expect(run1.desc).toMatch(/\(1 min tek \/ 1 min 30 s hoja\)/)   // gumb ima učinek
  })
  it('»tečem rad, hoja me ne zanima« in »brez hoje« nista prošnja za tek in hojo', () => {
    const f0 = coachReview(ruleProposal('Cilj: kondicija. Rad delam: tek. Izkušnje: občasno. Tek: tečem do 10 km.', qa3, 30).focus, { age: 30 }).focus
    expect(ruleAdjust(f0, 'tečem rad, hoja me ne zanima', 30)?.sessions.some(s => s.walk)).not.toBe(true)
    expect(ruleAdjust(f0, 'tek brez hoje', 30)?.sessions.some(s => s.walk)).not.toBe(true)
    // prava prošnja še deluje
    expect(ruleAdjust(f0, 'Raje hoja in tek izmenično, ker še ne zmorem teči 25 minut.', 30)!.sessions.every(s => s.walk)).toBe(true)
  })
})

describe('R4 po premoru: ta teden stopnja 1, naslednji 2', () => {
  it('premor 7 tednov, danes pon 26. 10.: ta teden »visoka kadenca«, naslednji »klanci z nizko kadenco«', () => {
    const p = P()
    const acts: Activity[] = []
    for (let d = '2026-03-02'; d <= '2026-09-06'; d = addDays(d, 7)) { acts.push(ride(d), ride(addDays(d, 2), 60), ride(addDays(d, 5), 150)) }
    const today = '2026-10-26'
    expect(planHours(p, acts, today, today).base).toBe(0)
    const w1 = buildWeek({ profile: p, activities: acts, weekStart: today, notBefore: today, today })
    const w2 = buildWeek({ profile: p, activities: acts, weekStart: addDays(today, 7), notBefore: today, today })
    expect(w1.find(d => d.date === '2026-10-29' && d.kind === 'kolo')!.title).toBe('Z2 + 5 × 1 min visoka kadenca')
    expect(w2.find(d => d.date === '2026-11-05' && d.kind === 'kolo')!.title).toBe('Z2 + klanci z nizko kadenco')
    for (const w of [w1, w2]) expect(w.some(d => d.zone === 'Z4' || d.zone === 'Z5')).toBe(false)
    // teden po vožnjah (ena vožnja prejšnji teden): stopnja 2
    const w2b = buildWeek({ profile: p, activities: [...acts, ride('2026-10-28', 60)], weekStart: '2026-11-02', notBefore: '2026-11-02', today: '2026-11-02' })
    expect(w2b.find(d => d.date === '2026-11-05' && d.kind === 'kolo')!.title).toBe('Z2 + klanci z nizko kadenco')
  })
})

describe('R5 ocena brez AI: oljke in sirup', () => {
  it('»10 oljk« ni 100 g olja; »javorjev sirup« ni sir; olje in sir ostanejo', () => {
    expect(estimateMeal('10 oljk')).toBeNull()
    expect(estimateMeal('solata z oljkami')!.items.map(i => i.key)).toEqual(['solata'])
    expect(estimateMeal('javorjev sirup 30 g')).toBeNull()
    expect(estimateMeal('olivno olje 10 g')!.items[0]!.key).toBe('olje')
    expect(estimateMeal('sir 40 g')!.items[0]!.key).toBe('sir')
    expect(estimateMeal('kruh s sirom')!.items.map(i => i.key).sort()).toEqual(['kruh', 'sir'])
  })
})

describe('R6 recipeOkFor ne zavrže veljavnih', () => {
  const r = (text: string, name = 'Jed') => ({ name, ingredients: [{ key: '', qty: 0, text }] })
  it('kokos ni meso, koruzna/ajdova moka ni gluten, kakavovo maslo ni mleko; kokoš, pšenična moka in maslo še izpadejo', () => {
    expect(recipeOkFor(r('kokos 20 g'), 'vegetarijansko')).toBe(true)
    expect(recipeOkFor(r('kokosova moka 30 g'), 'vegan')).toBe(true)
    expect(recipeOkFor(r('kokošje prsi 150 g'), 'vegetarijansko')).toBe(false)
    expect(recipeOkFor(r('kokosja juha'), 'vegetarijansko')).toBe(false)
    expect(recipeOkFor(r('koruzna moka 80 g', 'Polenta'), 'celiakija')).toBe(true)
    expect(recipeOkFor(r('ajdova moka 80 g', 'Ajdovi žganci'), 'brez glutena')).toBe(true)
    expect(recipeOkFor(r('pšenična moka 80 g'), 'celiakija')).toBe(false)
    expect(recipeOkFor(r('moka 80 g'), 'brez glutena')).toBe(false)
    expect(recipeOkFor(r('kakavovo maslo 10 g'), 'brez mleka')).toBe(true)
    expect(recipeOkFor(r('kokosovo mleko 200 ml'), 'brez mleka')).toBe(true)
    expect(recipeOkFor(r('maslo 10 g'), 'brez mleka')).toBe(false)
  })
})

describe('R7 »Imam samo X min« — TSS po ohranjenem delu', () => {
  it('VO2max 4 × 4 min, 75 → 45 min: delo ostane, TSS odšteje samo lahke minute (≈ 54, ne 45)', () => {
    const p = P()
    const d: PlanDay = { id: 'k', date: '2026-10-20', kind: 'kolo', title: 'VO2max 4 × 4 min', desc: '15 min ogrevanje, 4 × 4 min pri 110–120 % FTP (vmes 4 min lahko), 10 min iztek.', durationMin: 75, zone: 'Z5', role: 'kljucna', tssTarget: 75, source: 'rules', createdAt: NOW, updatedAt: NOW, done: null } as PlanDay
    const s = shortenDay(d, p, 45)!
    const st = stepsFor(s.day, p)
    expect(st.filter(x => x.kind === 'delo').reduce((a, x) => a + x.sec, 0)).toBe(4 * 240)
    expect(s.day.tssTarget).toBeGreaterThan(Math.round(75 * s.min / 75))
    expect(s.day.tssTarget).toBe(Math.round(75 - (75 - s.min) * (0.65 * 0.65 * 100) / 60))
    expect(s.day.tssTarget!).toBeLessThan(75)
    // enakomerna vožnja (brez ponovitev): sorazmerno kot prej
    const z2: PlanDay = { ...d, id: 'z', title: 'Z2 — 2 h', desc: 'Mirno v Z2.', durationMin: 120, zone: 'Z2', role: 'lahka', tssTarget: 80 }
    expect(shortenDay(z2, p, 60)!.day.tssTarget).toBe(40)
  })
})

describe('R8 AI kontekst: ure tedna kot Plan »Na kolesu«', () => {
  it('kolesar: moč (ne po želji) ni v »načrt ta teden X h«', () => {
    const T = '2026-10-17'
    const day = (o: Partial<PlanDay>): PlanDay => ({ id: 'd' + (o.date || T), date: T, kind: 'kolo', title: 'Dolga Z2', desc: 'Enakomerno.', durationMin: 105, zone: 'Z2', role: 'dolga', source: 'rules', createdAt: NOW, updatedAt: NOW, ...o } as PlanDay)
    const p = P({ hoursPerWeek: 11, cycleStart: '2026-09-21', aiConsentAt: NOW, aiConsentV: 2 } as Partial<Profile>)
    const plan = [day({ date: '2026-10-13', durationMin: 60 }), day({ date: '2026-10-13', kind: 'moc', title: 'Doma — noge', zone: null, role: 'moc', durationMin: 30 }), day({ date: '2026-10-15', durationMin: 90 }), day({ date: '2026-10-16', kind: 'moc', title: 'Doma — jedro', zone: null, role: 'moc', durationMin: 20 }), day({ date: '2026-10-17', durationMin: 120 })]
    const pc = personalContext({ profile: p, activities: [], plan, checkins: [], recentMeals: [], today: T })
    expect(pc).toContain('načrt ta teden 4,5 h')
    expect(pc).not.toContain('načrt ta teden 5,5 h')
  })
})

describe('R9 zapis iz načrta ob krajši vadbi drugega športa', () => {
  const p = P()
  const d: PlanDay = { id: 'd1', date: '2026-10-20', kind: 'kolo', title: 'Z2 — 90 min', desc: '', durationMin: 90, zone: 'Z2', role: 'lahka', tssTarget: 60, source: 'rules', createdAt: NOW, updatedAt: NOW, done: { at: '2026-10-20T18:00:00.000Z', activityId: null } } as PlanDay
  it('»Opravil« kolo brez ure + ročno vpisan tek 30 min istega dne: zapis kolesa ostane; forma in dnevni cilj vidita oboje', () => {
    const si = standInFor(d, p)!
    const run: Activity = { ...ride('2026-10-20', 30), sport: 'tek', id: 'run1' }
    expect(swapsPlanned(run, d)).toBe(false)
    expect(realOn([si, run], d.date, 'kolo', { plan: [d], dayId: d.id })).toBeNull()
    expect(standInsToDrop([si, run], [], [d])).toHaveLength(0)
    const t = dailyTarget(p, [run], [d], '2026-10-20', { today: '2026-10-20', hour: 20 })!
    expect(t.burn).toBeGreaterThan(0)
    expect(t.estimatedBurn).toBeGreaterThan(0)
  })
  it('hribi 2 h z ure namesto kolesa (≥ 40 %): zapis izpade in dnevni cilj šteje hribe izmerjeno — oboje enako', () => {
    const si = standInFor(d, p)!
    const hike: Activity = { ...ride('2026-10-20', 120), sport: 'pohod', id: 'h1', kcal: 700 }
    expect(swapsPlanned(hike, d)).toBe(true)
    expect(standInsToDrop([si, hike], [], [d]).map(a => a.id)).toEqual([si.id])
    const t = dailyTarget(p, [hike], [d], '2026-10-20', { today: '2026-10-20', hour: 20 })!
    expect(t.burn).toBe(700)
    expect(t.estimatedBurn).toBe(0)
    // ista vrsta: kot prej
    expect(standInsToDrop([si, ride('2026-10-20', 85)], [], [d]).map(a => a.id)).toEqual([si.id])
  })
})
