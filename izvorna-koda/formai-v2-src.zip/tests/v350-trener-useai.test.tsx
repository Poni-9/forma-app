// v3.50 TRENER (H46): po privolitvi gre napaka AI isto pot kot brez lista — onError (zaslon pokaže razlog in rezervo brez
// AI), brez splošnega obvestila pri »quiet«; prej se je opts ob privolitvi izgubil.
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>() }))
const emit = () => S.subs.forEach(f => f())
vi.mock('@/state/store', () => ({
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  signIn: vi.fn(),
  grantAiConsent: vi.fn(async () => { S.state = { ...S.state, profile: { ...S.state.profile, aiConsentAt: 'zdaj' } }; emit() }),
  toast: vi.fn(),
}))
vi.mock('@/screens/Privolitev', () => ({
  PrivolitevSheet: ({ open, onAccept }: { open: boolean; onAccept: () => void }) => (open ? <button id="accept" onClick={() => onAccept()}>accept</button> : null),
}))

import { useAi } from '@/ui/useAi'
import { AiError } from '@/domain/ai/errors'
import * as store from '@/state/store'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

function Harness({ fn, onError }: { fn: () => Promise<number>; onError: (m: string) => void }) {
  const ai = useAi()
  return <><button id="go" onClick={() => { void ai.run(fn, { onError, quiet: true }) }}>go</button>{ai.sheet}</>
}
let div: HTMLDivElement, root: Root
const flush = async () => { for (let i = 0; i < 6; i++) await act(async () => { await Promise.resolve() }) }
const click = async (sel: string) => { await act(async () => { (div.querySelector(sel) as HTMLButtonElement).click() }); await flush() }
afterEach(async () => { await act(async () => root.unmount()); div.remove() })

describe('H46 napaka po privolitvi', () => {
  it('onError se pokliče tudi po listu privolitve; »quiet« brez obvestila', async () => {
    S.state = { user: { uid: 'u1' }, profile: { aiConsentAt: null } }
    const fn = vi.fn(async () => { throw new AiError('network', 'AI zdaj ne more odgovoriti — poskusi čez minuto.') })
    const onError = vi.fn()
    div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
    await act(async () => { root.render(<Harness fn={fn} onError={onError} />) })
    await click('#go')
    expect(fn).not.toHaveBeenCalled()                  // najprej list
    await click('#accept')
    expect(fn).toHaveBeenCalledTimes(1)
    expect(onError).toHaveBeenCalledWith('AI zdaj ne more odgovoriti — poskusi čez minuto.')
    expect(store.toast).not.toHaveBeenCalled()
  })
})
