// v3.52 POPRAVKI-APP — čiste funkcije: V2 (združitev povzetka in podrobnosti v repo), V6 (nextSince), V7 (Body Battery ob
// prebujanju, stres samo iz celega dneva, pripravljenost z včerajšnjim stresom, strop odbitka), N1 (today v PUT/DELETE),
// N2 (slovenska besedila kod), N3 (»na uri« samo v 14-dnevnem oknu in brez dni premora).
import { describe, it, expect, vi } from 'vitest'
vi.mock('../src/data/firebase', () => ({ idToken: async () => 'tok', timeoutSignal: () => undefined }))
import { wellnessFromGarmin, mergeWellness, wholeDay } from '../src/domain/garmin/wellness'
import { recoveryOf, type WellnessDay } from '../src/domain/wellness'
import { putGarminWorkouts, deleteGarminWorkouts, garminErrorText } from '../src/domain/garmin/pushClient'
import { garminErrOf, nextSince } from '../src/domain/garmin/client'
import { onGarminWatchIds, garminWorkoutsFor, garminPaused } from '../src/domain/garmin/workouts'
import { mergeSameSource } from '../src/data/repo'
import { addDays } from '../src/domain/training/load'
import type { Activity, PlanDay, Profile } from '../src/domain/types'

const NOW = new Date().toISOString()

describe('V7 · zdravje: Body Battery ob prebujanju in stres samo iz celega dneva', () => {
  it('bodyBatteryAtWake → bodyBattery + bbAtWake; brez njega bodyBatteryMax BREZ bbAtWake', () => {
    const d = wellnessFromGarmin({ stress: [
      { summaryId: 'a', calendarDate: '2026-10-25', averageStressLevel: 40, bodyBatteryAtWake: 66, bodyBatteryMax: 90, partial: false },
      { summaryId: 'b', calendarDate: '2026-10-26', averageStressLevel: 40, bodyBatteryMax: 90, partial: false },
    ] })
    expect(d[0]).toMatchObject({ date: '2026-10-25', bodyBattery: 66, bbAtWake: true })
    expect(d[1]).toMatchObject({ date: '2026-10-26', bodyBattery: 90 }); expect(d[1]!.bbAtWake).toBeUndefined()
  })
  it('stres: partial: true (današnji delni dan) → brez stresa; partial: false → stres; brez oznake šteje samo zapis s trajanjem celega dneva', () => {
    const d = wellnessFromGarmin({
      stress: [
        { summaryId: 'a', calendarDate: '2026-10-24', averageStressLevel: 61, partial: true, bodyBatteryAtWake: 50 },
        { summaryId: 'b', calendarDate: '2026-10-25', averageStressLevel: 58, partial: false },
        { summaryId: 'c', calendarDate: '2026-10-26', averageStressLevel: 30, durationInSeconds: 86400 },
        { summaryId: 'd', calendarDate: '2026-10-27', averageStressLevel: 30, durationInSeconds: 25000, bodyBatteryMax: 70 },
      ],
      dailies: [{ summaryId: 'e', calendarDate: '2026-10-24', averageStressLevel: 70, durationInSeconds: 20000, restingHeartRateInBeatsPerMinute: 50 }],
    })
    expect(d.map(x => [x.date, x.stress ?? null])).toEqual([['2026-10-24', null], ['2026-10-25', 58], ['2026-10-26', 30], ['2026-10-27', null]])
    expect(wholeDay({ partial: false })).toBe(true); expect(wholeDay({ partial: true, durationInSeconds: 86400 })).toBe(false); expect(wholeDay({ durationInSeconds: 86400 })).toBe(true); expect(wholeDay(null)).toBe(false)
  })
  it('mergeWellness prenese bbAtWake z Garminovim dnem (in ga vzame, če novi dan nima oznake)', () => {
    const m = mergeWellness([{ date: '2026-10-25', sleepH: 7, sleepScore: null, hrv: null, rhr: null, bodyBattery: 80, bbAtWake: true }], [{ date: '2026-10-25', sleepH: 7, sleepScore: null, hrv: null, rhr: null, bodyBattery: 44 }])
    expect(m[0]!.bodyBattery).toBe(44); expect(m[0]!.bbAtWake).toBeUndefined()
    const m2 = mergeWellness([{ date: '2026-10-25', sleepH: 7, sleepScore: null, hrv: null, rhr: null }], [{ date: '2026-10-25', sleepH: 7, sleepScore: null, hrv: null, rhr: null, bodyBattery: 44, bbAtWake: true }])
    expect(m2[0]!.bbAtWake).toBe(true)
  })
})

describe('V7 · pripravljenost: včerajšnji stres, Body Battery ob prebujanju, strop 30', () => {
  const T = '2026-10-26', Y = addDays(T, -1)
  const base: WellnessDay[] = Array.from({ length: 10 }, (_, i) => ({ date: `2026-10-${String(10 + i).padStart(2, '0')}`, sleepH: 7.5, sleepScore: 80, hrv: 60, rhr: 48 }))
  it('stres za pripravljenost je VČERAJŠNJI (cel dan), današnji delni se ne upošteva; razlog »včeraj visok stres«', () => {
    const r = recoveryOf([...base, { date: Y, sleepH: 7, sleepScore: 80, hrv: 60, rhr: 48, stress: 64 }, { date: T, sleepH: 7.5, sleepScore: 80, hrv: 60, rhr: 48, stress: 12 }], T)!
    expect(r.stress).toBe(64); expect(r.reasons).toEqual(['včeraj visok stres']); expect(r.penalty).toBe(4)
    // samo današnji (delni) stres, včerajšnjega ni → brez stresa v oceni
    const only = recoveryOf([...base, { date: T, sleepH: 7.5, sleepScore: 80, hrv: 60, rhr: 48, stress: 90 }], T)!
    expect(only.stress ?? null).toBeNull(); expect(only.reasons).toEqual([]); expect(only.penalty).toBe(0)
  })
  it('bodyBatteryAtWake se prenese v Recovery samo, ko je dan označen bbAtWake', () => {
    const a = recoveryOf([...base, { date: T, sleepH: 7.5, sleepScore: 80, hrv: 60, rhr: 48, bodyBattery: 25, bbAtWake: true }], T)!
    expect(a.bodyBattery).toBe(25); expect(a.bodyBatteryAtWake).toBe(true); expect(a.reasons).toEqual(['Body Battery nizek'])
    const b = recoveryOf([...base, { date: T, sleepH: 7.5, sleepScore: 80, hrv: 60, rhr: 48, bodyBattery: 25 }], T)!
    expect(b.bodyBattery).toBe(25); expect(b.bodyBatteryAtWake).toBeUndefined()
  })
  it('kratek spanec (−15) + slaba ocena (−6) + Body Battery (−6) + včerajšnji stres (−4) = 31 → omejeno na 30 (ni dvojne kazni čez strop)', () => {
    const r = recoveryOf([...base, { date: Y, sleepH: 7, sleepScore: 80, hrv: 60, rhr: 48, stress: 70 }, { date: T, sleepH: 5, sleepScore: 40, hrv: 60, rhr: 48, bodyBattery: 20, bbAtWake: true }], T)!
    expect(r.reasons).toEqual(['malo spanja', 'slaba kakovost spanja', 'včeraj visok stres', 'Body Battery nizek'])
    expect(r.penalty).toBe(30)
    // brez spanca z ure: samo stres + BB = 10
    const r2 = recoveryOf([...base, { date: Y, sleepH: null, sleepScore: null, hrv: null, rhr: null, stress: 70 }, { date: T, sleepH: null, sleepScore: null, hrv: 60, rhr: 48, bodyBattery: 20 }], T)!
    expect(r2.penalty).toBe(10)
  })
})

describe('V6 · nextSince: iz `now` odgovora (največji vrnjeni t), nikoli Date.now(), nikoli nazaj', () => {
  it('now → now; brez now → največji t zapisov; prazna stran brez now → ostane; nazaj ne gre', () => {
    expect(nextSince(100, { now: 5000, more: false }, [{ t: 1000 }, { t: 3000 }])).toBe(5000)
    expect(nextSince(100, { now: null, more: false }, [{ t: 1000 }, { t: 3000 }])).toBe(3000)
    expect(nextSince(100, { now: null, more: false }, [])).toBe(100)
    expect(nextSince(9000, { now: 5000, more: false }, [{ t: 1000 }])).toBe(9000)
    expect(nextSince(0, { now: null, more: true }, [{ t: 'x' }, {}])).toBe(0)
    // nikoli ura naprave
    expect(nextSince(0, { now: null, more: false }, [{ t: 1000 }])).toBeLessThan(Date.now() - 1_000_000)
  })
})

describe('V2 · mergeSameSource: povzetek + podrobnosti iste vožnje v istem paketu', () => {
  const act = (o: Partial<Activity>): Activity => ({ id: 'a', source: 'garmin', originHint: 'GARMIN_API', sport: 'kolo', date: '2026-10-26', start: '2026-10-26T06:40:00.000Z', name: 'Vožnja', durationMin: 90, distKm: 45, avgHr: 140, kcal: 1100, tss: 80, deviceWatts: false, aiEligible: true, geoRetain: true, ext: { garminId: '9', garminSummaryId: 'a9' }, createdAt: NOW, updatedAt: NOW, ...o } as Activity)
  it('osnova je zapis s podrobnostmi (moč, sled) ne glede na vrstni red; prazna polja dopolni drugi; ext združen', () => {
    const sum = act({ id: 's', avgPower: null, polyline: null, maxHr: null })
    const det = act({ id: 'd', avgPower: 190, maxHr: 170, polyline: 'pl', tss: 101, deviceWatts: true, kcal: null, ext: { garminId: '9', garminSummaryId: 'a9-detail' } })
    for (const m of [mergeSameSource(sum, det), mergeSameSource(det, sum)]) {
      expect(m.avgPower).toBe(190); expect(m.polyline).toBe('pl'); expect(m.maxHr).toBe(170); expect(m.tss).toBe(101); expect(m.deviceWatts).toBe(true)
      expect(m.kcal).toBe(1100)   // iz povzetka
      expect(m.ext).toEqual({ garminId: '9', garminSummaryId: 'a9-detail' })
    }
  })
})

describe('N1 · today (lokalni datum) gre na strežnik pri PUT in DELETE /garmin/workouts', () => {
  const mk = (status: number, body: unknown) => vi.fn(async () => ({ ok: status < 400, status, json: async () => body })) as unknown as typeof fetch
  it('PUT telo ima today; DELETE ima ?today=', async () => {
    const f = mk(200, { created: 0, updated: 0, skipped: 0, removed: 0, errors: [] })
    await putGarminWorkouts([], f, '2026-10-26')
    const [url, init] = (f as unknown as ReturnType<typeof vi.fn>).mock.calls[0] as [string, RequestInit]
    expect(url).toMatch(/\/garmin\/workouts$/); expect(JSON.parse(String(init.body))).toEqual({ workouts: [], today: '2026-10-26' })
    const g = mk(200, { removed: 1 })
    await deleteGarminWorkouts(g, '2026-10-26')
    expect(((g as unknown as ReturnType<typeof vi.fn>).mock.calls[0] as [string])[0]).toMatch(/\/garmin\/workouts\?today=2026-10-26$/)
    // brez podanega datuma gre današnji lokalni (nikoli brez)
    const h = mk(200, { removed: 0 })
    await deleteGarminWorkouts(h)
    expect(((h as unknown as ReturnType<typeof vi.fn>).mock.calls[0] as [string])[0]).toMatch(/\?today=\d{4}-\d{2}-\d{2}$/)
  })
})

describe('N2 · slovenska besedila kod strežnika', () => {
  it('pushClient: povezava_prekinjena, ni_dovoljenja, prevec_klicev, prevec_treningov, neveljavno', () => {
    expect(garminErrorText('povezava_prekinjena', 409)).toBe('Garmin je prekinil povezavo — poveži znova.')
    expect(garminErrorText('ni_dovoljenja', 403)).toBe('Garmin za ta račun ne deli teh podatkov — v Garmin Connect preveri dovoljenja za FORMAI.')
    expect(garminErrorText('prevec_klicev', 429)).toBe('Preveč zahtevkov na Garmin — poskusi čez minuto.')
    expect(garminErrorText('prevec_treningov', 400)).toMatch(/največ 14/)
    expect(garminErrorText('neveljavno', 400)).toMatch(/neveljaven/)
    for (const c of ['povezava_prekinjena', 'ni_dovoljenja', 'prevec_klicev']) expect(garminErrorText(c, 409)).not.toMatch(/strežnik \d+/)
  })
  it('client: iste kode brez »napaka strežnika (409)«; kind broken/garmin', () => {
    expect(garminErrOf(409, 'povezava_prekinjena')).toMatchObject({ kind: 'broken', message: 'Garmin je prekinil povezavo — poveži znova.' })
    expect(garminErrOf(403, 'ni_dovoljenja')).toMatchObject({ kind: 'garmin', message: expect.stringMatching(/preveri dovoljenja za FORMAI/) })
    expect(garminErrOf(403, null).message).toMatch(/dovoljenja/)
    expect(garminErrOf(429, 'prevec_klicev')).toMatchObject({ kind: 'garmin', message: 'Preveč zahtevkov na Garmin — poskusi čez minuto.' })
    expect(garminErrOf(409, 'ni_povezave').kind).toBe('none')
  })
})

describe('N3 · onGarminWatchIds: samo 14-dnevno okno, brez dni premora, isti dnevi kot garminWorkoutsFor', () => {
  const T = '2026-10-26'
  const p = { sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, lthr: 184, maxHr: 199, restHr: 52, gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true }, strength: { on: false, equipment: 'home' }, onboardingDone: true, createdAt: NOW, updatedAt: NOW } as unknown as Profile
  const day = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: `d-${date}-${o.kind || 'kolo'}`, date, kind: 'kolo', title: 'Z2 vzdržljivost', desc: '', durationMin: 70, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, ...o })
  const plan = [day(T), day(addDays(T, 5)), day(addDays(T, 13)), day(addDays(T, 14)), day(addDays(T, 20)), day(addDays(T, 2), { kind: 'moc', title: 'Moč' }), day(addDays(T, 3), { kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, role: null })]
  it('dan 14 in 20 dni naprej, moč in počitek niso na uri; 0, 5 in 13 so', () => {
    const ids = onGarminWatchIds(plan, p, T)
    expect([...ids].sort()).toEqual([day(T).id, day(addDays(T, 5)).id, day(addDays(T, 13)).id].sort())
    expect(ids.has(day(addDays(T, 14)).id)).toBe(false); expect(ids.has(day(addDays(T, 20)).id)).toBe(false)
    expect([...ids].sort()).toEqual(garminWorkoutsFor(plan, p, T).map(w => plan.find(d => d.date === w.date && d.kind === 'kolo')!.id).sort())
  })
  it('premor »brez treningov« od danes do +6: dnevi v premoru niso na uri, dan +13 je', () => {
    const paused: Profile = { ...p, weekPause: { from: T, to: addDays(T, 6), mode: 'vse' } }
    const ids = onGarminWatchIds(plan, paused, T)
    expect(ids.has(day(T).id)).toBe(false); expect(ids.has(day(addDays(T, 5)).id)).toBe(false); expect(ids.has(day(addDays(T, 13)).id)).toBe(true)
    expect(garminPaused(paused, day(T))).toBe(true); expect(garminPaused(paused, day(addDays(T, 7)))).toBe(false)
    // »brez kolesa« vzame kolo, tek ostane
    const bike: Profile = { ...p, weekPause: { from: T, to: addDays(T, 6), mode: 'kolo' } }
    expect(garminPaused(bike, day(T, { kind: 'tek' }))).toBe(false); expect(garminPaused(bike, day(T))).toBe(true)
  })
})
