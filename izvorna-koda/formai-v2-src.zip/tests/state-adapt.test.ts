import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { readState, adaptToState, undoState, stateNow, badMornings, load3 } from '../src/domain/training/state'
import { buildWeek, weekContext } from '../src/domain/training/planner'
import { swapDays } from '../src/domain/training/swap'
import { todayIso, addDays, weekStartIso } from '../src/domain/training/load'
import type { DailyCheckin, PlanDay, Profile } from '../src/domain/types'

const NOW = '2026-10-03T08:00:00.000Z'
const p = { sex: 'm', age: 30, weightKg: 75, heightCm: 180, ftp: 250, hoursPerWeek: 8, gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true }, strength: { on: true, equipment: 'home' }, strengthDays: 2, onboardingDone: true, createdAt: NOW, updatedAt: NOW } as Profile
const T = '2026-10-07'   // sreda
const day = (id: string, date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id, date, kind: 'kolo', title: 'Z2 vzdržljivost', desc: 'Enakomerno.', durationMin: 90, zone: 'Z2', tssTarget: 60, role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })
const ck = (o: Partial<DailyCheckin>, date = T): DailyCheckin => ({ date, ...o })
// teden: pon počitek, tor VO2 (opravljen), sre prag + moč, čet Z2, pet regen, sob dolga, ned Z2
const week = [
  day('mon', '2026-10-05', { kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, tssTarget: 0, role: null }),
  day('tue', '2026-10-06', { title: 'VO2max 5 × 4 min', zone: 'Z5', role: 'kljucna', done: { at: NOW, activityId: null } }),
  day('wed', T, { title: 'Prag 2 × 15 min', zone: 'Z4', role: 'kljucna', durationMin: 80, tssTarget: 85 }),
  day('wedm', T, { kind: 'moc', title: 'Moč — noge', zone: null, role: 'moc', durationMin: 30, tssTarget: 20, exercises: [{ name: 'Počep', sets: 3, reps: '8' }] }),
  day('thu', '2026-10-08', { title: 'Z2 vzdržljivost', durationMin: 75 }),
  day('fri', '2026-10-09', { title: 'Regeneracija', zone: 'Z1', role: 'regen', durationMin: 45, tssTarget: 20 }),
  day('sat', '2026-10-10', { title: 'Dolga Z2', role: 'dolga', durationMin: 180, tssTarget: 130 }),
  day('sun', '2026-10-11', { title: 'Z2 vzdržljivost', durationMin: 90 }),
]

describe('stanje iz jutranjega vnosa', () => {
  it('stopnje: noge bolijo / na tleh = 3, zelo boleče = 2, precej = 1, brez vnosa 0', () => {
    expect(readState({ checkin: ck({ soreness: 5 }) })).toMatchObject({ level: 3, legs: true })
    expect(readState({ checkin: ck({ mood: 1 }) })).toMatchObject({ level: 3, legs: false })
    expect(readState({ checkin: ck({ soreness: 4, mood: 4 }) })).toMatchObject({ level: 2, legs: true })
    expect(readState({ checkin: ck({ soreness: 4, mood: 2 }) }).level).toBe(3)
    expect(readState({ checkin: ck({ soreness: 3, mood: 4 }) }).level).toBe(1)
    expect(readState({ checkin: null, readiness: 20 }).level).toBe(0)                                  // ura sama načrta ne spremeni
    expect(readState({ checkin: ck({ soreness: 2, mood: 4 }), readiness: 40 }).level).toBe(2)
  })
  it('kar si naredil: dve slabi jutri zapored, visoka utrujenost ali zadnje 3 dni precej več od načrta — stopnja višje', () => {
    expect(readState({ checkin: ck({ soreness: 3, mood: 3 }), yesterday: ck({ soreness: 4 }, '2026-10-06') })).toMatchObject({ level: 2, reasons: expect.arrayContaining(['že včeraj slabo']) })
    expect(readState({ checkin: ck({ soreness: 3 }), tsb: -34 }).level).toBe(2)
    const r = readState({ checkin: ck({ mood: 2 }), load3: { actual: 260, planned: 120 } })
    expect(r.level).toBe(2); expect(r.reasons.join(' ')).toMatch(/zadnje 3 dni 260 TSS namesto ~120/)
    expect(readState({ checkin: ck({ soreness: 1, mood: 4 }), load3: { actual: 260, planned: 120 } }).level).toBe(0)   // dobro počutje: ne spreminjaj
  })
  it('slaba jutra in zadnji trije dnevi', () => {
    expect(badMornings([ck({ soreness: 4 }, '2026-10-01'), ck({ mood: 2 }, '2026-10-03'), ck({ soreness: 2 }, '2026-10-04')], '2026-10-01', '2026-10-07')).toBe(2)
    const l = load3(p, week, [{ id: 'a', source: 'manual', sport: 'kolo', date: '2026-10-06', name: 'x', durationMin: 120, tss: 150, aiEligible: true, geoRetain: true, createdAt: NOW, updatedAt: NOW }], T)
    expect(l).toEqual({ actual: 150, planned: 60 })
  })
})

describe('prilagoditev dneva in tedna', () => {
  it('noge zelo bolijo: danes sprehod (brez kolesa), prag gre na kasnejši lahek dan, moč samo jedro', () => {
    const r = adaptToState(p, week, T, readState({ checkin: ck({ soreness: 4, mood: 3 }) }), { now: NOW })!
    const by = new Map(r.days.map(d => [d.id, d]))
    expect(r.mode).toBe('sprehod')
    expect(by.get('wed')).toMatchObject({ kind: 'pohod', title: 'Sprehod', optional: true, role: 'regen', byState: { date: T, auto: true, mode: 'sprehod' } })
    expect(by.get('wed')!.byState!.prev!.title).toBe('Prag 2 × 15 min')
    // noge: ključni šele čez 2 dni — petek in nedelja sta ob dolgi soboti (trd dan) → ta teden odpade
    expect([...by.values()].some(d => d.byState?.mode === 'premik')).toBe(false)
    expect(r.lines).toContain('Prag 2 × 15 min ta teden odpade — bolje en trening manj kot teden v luknji. Naslednji pride po načrtu.')
    expect(by.get('wedm')).toMatchObject({ optional: true, byState: { mode: 'moc' } })
    expect(by.get('wedm')!.desc).toMatch(/^Noge počivajo/)
    expect(r.lines[0]).toBe('Danes sprehod po želji namesto: Prag 2 × 15 min, 1 h 20 min.')
  })
  it('ko je prostor: ključni gre na prvi lahek dan čez 2 dni (ne ob trd dan); brez bolečih nog že jutri', () => {
    const plan = week.map(d => (d.id === 'sat' ? { ...d, title: 'Z2 dolgo-lahko', role: 'lahka' as const, durationMin: 120 } : d))
    const legs = adaptToState(p, plan, T, readState({ checkin: ck({ soreness: 4 }) }), { now: NOW })!
    expect(legs.days.find(d => d.byState?.mode === 'premik')).toMatchObject({ id: 'fri', title: 'Prag 2 × 15 min', role: 'kljucna' })
    expect(legs.lines).toContain('Prag 2 × 15 min gre na petek.')
    const tired = adaptToState(p, plan, T, readState({ checkin: ck({ soreness: 2, mood: 3 }), readiness: 40 }), { now: NOW })!
    expect(tired.mode).toBe('vrtenje')
    expect(tired.days.find(d => d.byState?.mode === 'premik')).toMatchObject({ id: 'thu' })
  })
  it('na dnu: danes počitek, jutri lahko vrtenje; ključni ne pride ob drug trd dan', () => {
    const plan = week.map(d => (d.id === 'thu' ? { ...d, title: 'VO2max 4 × 4', zone: 'Z5', role: 'kljucna' as const } : d))
    const r = adaptToState(p, plan, T, readState({ checkin: ck({ mood: 1, soreness: 2 }) }), { now: NOW })!
    const by = new Map(r.days.map(d => [d.id, d]))
    expect(by.get('wed')).toMatchObject({ kind: 'pocitek', title: 'Počitek' })
    expect(by.get('thu')).toMatchObject({ kind: 'kolo', title: 'Lahko vrtenje', optional: false, byState: { mode: 'lazje' } })
    // prag (danes) bi šel na petek, a je petek ob dolgi soboti (trd dan) → ni prostega dne; VO2 (jutri) prav tako
    expect(r.lines.join(' ')).toMatch(/Prag 2 × 15 min ta teden odpade/)
    expect([...by.values()].some(d => d.date === '2026-10-09' && d.role === 'kljucna')).toBe(false)
  })
  it('stopnja 1 ne spremeni ničesar; opravljeno, tekma in že prilagojen dan ostanejo', () => {
    expect(adaptToState(p, week, T, readState({ checkin: ck({ soreness: 3 }) }))).toBeNull()
    const done = week.map(d => (d.id === 'wed' || d.id === 'wedm' ? { ...d, done: { at: NOW } } : d))
    expect(adaptToState(p, done, T, readState({ checkin: ck({ soreness: 4 }) }))).toBeNull()
    const race = week.map(d => (d.id === 'wed' ? { ...d, role: 'dirka' as const, raceId: 'r1' } : d)).filter(d => d.id !== 'wedm')
    expect(adaptToState(p, race, T, readState({ checkin: ck({ soreness: 4 }) }))).toBeNull()
  })
  it('vrni po načrtu: prvotna vsebina, oznaka »off« (danes ne prilagodi znova); prikaz pove, kaj se je zgodilo', () => {
    const r = adaptToState(p, week, T, readState({ checkin: ck({ soreness: 5 }) }), { now: NOW })!
    const plan = week.map(d => r.days.find(x => x.id === d.id) ?? d)
    const now = stateNow(plan, T)!
    expect(now.mode).toBe('sprehod')
    expect(now.lines[0]).toBe('Danes sprehod po želji namesto: Prag 2 × 15 min.')
    const back = undoState(plan, T, { now: NOW })
    expect(back.find(d => d.id === 'wed')).toMatchObject({ kind: 'kolo', title: 'Prag 2 × 15 min', role: 'kljucna', optional: false, byState: { date: T, off: true } })
    expect(back.find(d => d.id === 'wedm')!.desc).not.toMatch(/Noge počivajo/)
    expect(stateNow(plan.map(d => back.find(x => x.id === d.id) ?? d), T)).toBeNull()
  })
})

describe('teden posluša jutra', () => {
  it('3 slaba jutra v zadnjem tednu → naslednji teden −15 %', () => {
    const today = todayIso()
    const prof = { ...p, event: { name: 'Maraton', date: addDays(today, 150), distanceKm: 156 }, cycleStart: weekStartIso(addDays(today, -35)) } as Profile
    // prvi teden, ki ni razbremenilni (ta je že lažji in ga utrujenost ne krajša še bolj)
    const ws = [0, 7, 14, 21].map(k => addDays(weekStartIso(today), k)).find(w => !weekContext(prof, w).recovery)!
    const mins = (w: PlanDay[]) => w.filter(d => d.kind === 'kolo' && !d.optional).reduce((s, d) => s + d.durationMin, 0)
    const fresh = buildWeek({ profile: prof, activities: [], weekStart: ws, notBefore: ws, checkins: [] })
    const bad = [1, 2, 3].map(i => ({ date: addDays(today, -i), soreness: 4 as const }))
    const tired = buildWeek({ profile: prof, activities: [], weekStart: ws, notBefore: ws, checkins: bad })
    expect(mins(tired)).toBeLessThan(mins(fresh))
    expect(tired.map(d => d.why || '').join(' ')).toMatch(/zadnji teden si bil 3× utrujen ali z bolečimi nogami/)
  })
})

describe('v aplikaciji', () => {
  beforeEach(async () => { await repo.wipeAll(); localStorage.clear(); await store.reloadAll() })
  const today = () => store.getState().today
  const seedWeek = async () => {
    const t = today(), NOW2 = new Date().toISOString()
    await store.savePlanDays([
      day('a', t, { title: 'Prag 2 × 15 min', zone: 'Z4', role: 'kljucna', durationMin: 80, createdAt: NOW2, updatedAt: NOW2 }),
      day('am', t, { kind: 'moc', title: 'Moč — noge', zone: null, role: 'moc', durationMin: 30 }),
      day('b', addDays(t, 1), { title: 'Z2', durationMin: 60 }),
    ])
  }
  it('jutranji vnos »Boli« → danes sprehod; popravek na »Malo« → nazaj po načrtu; moč na istem dnevu ostane', async () => {
    await store.updateProfile({ ...p })
    await seedWeek()
    await store.saveCheckin({ date: today(), mood: 3, soreness: 5 })
    let s = store.getState()
    expect(s.plan.find(d => d.id === 'a')).toMatchObject({ title: 'Sprehod', kind: 'pohod' })
    expect(s.plan.find(d => d.id === 'am')).toMatchObject({ optional: true })
    await store.saveCheckin({ date: today(), mood: 3, soreness: 2 })
    s = store.getState()
    expect(s.plan.find(d => d.id === 'a')).toMatchObject({ title: 'Prag 2 × 15 min', kind: 'kolo', byState: null })
    expect(s.plan.find(d => d.id === 'am')).toMatchObject({ title: 'Moč — noge', optional: false })
  })
  it('izbira načina in »Vrni po načrtu« (potem danes ne prilagodi znova)', async () => {
    await store.updateProfile({ ...p })
    await seedWeek()
    await store.saveCheckin({ date: today(), mood: 1, soreness: 2 })
    expect(store.getState().plan.find(d => d.id === 'a')!.title).toBe('Počitek')
    await store.setStateMode('vrtenje')
    expect(store.getState().plan.find(d => d.id === 'a')).toMatchObject({ title: 'Lahko vrtenje', byState: { mode: 'vrtenje', auto: false } })
    await store.undoStateToday()
    expect(store.getState().plan.find(d => d.id === 'a')!.title).toBe('Prag 2 × 15 min')
    await store.saveCheckin({ date: today(), mood: 1, soreness: 5 })
    expect(store.getState().plan.find(d => d.id === 'a')!.title).toBe('Prag 2 × 15 min')
    expect(store.getState().plan.filter(d => d.date === today()).length).toBe(2)
  })
  it('premik ali prestavitev enega vnosa ne pobriše moči na istem dnevu (napaka v v3.26)', async () => {
    const t = today(), NOW2 = new Date().toISOString()
    await store.savePlanDays([day('x', addDays(t, 1)), day('y', addDays(t, 2)), day('ym', addDays(t, 2), { kind: 'moc', title: 'Moč', role: 'moc', zone: null, updatedAt: NOW2 })])
    const g = (id: string) => store.getState().plan.find(d => d.id === id)!
    const [a, b] = swapDays(g('x'), g('y'))
    await store.updatePlanDays([a, b])
    expect(store.getState().plan.map(d => d.id).sort()).toEqual(['x', 'y', 'ym'])
    expect(g('y').date).toBe(addDays(t, 2))
  })
})
