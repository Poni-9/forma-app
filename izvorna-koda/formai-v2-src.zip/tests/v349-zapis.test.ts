// v3.49 ZAPIS — opravljen trening brez ure se zapiše in šteje povsod: zapis iz načrta (forma, ure tedna, načrt, Napredek),
// brez dvojnika ob uvozu z ure, odznačitev ga pobriše, delne minute, kalorije po dejanskih minutah, stare kljukice.
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeAll, afterAll, beforeEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { setKV } from '../src/data/db'
import { standInFor, standInsToDrop, standInsToAdd, standInId, minuteOptions, doneMinutes, isStandIn } from '../src/domain/training/standin'
import { dailyTarget, targetParts, doneShare } from '../src/domain/nutrition/energy'
import { realityCap, planHours } from '../src/domain/training/planner'
import { formSeries, addDays } from '../src/domain/training/load'
import { keyCompliance } from '../src/domain/training/review'
import { extraActivities } from '../src/ui/ActivityBox'
import { yesterdayToRate, yesterdayUnmarked } from '../src/ui/YesterdayRate'
import { sourceLabel } from '../src/domain/import/provenance'
import type { Activity, PlanDay, Profile } from '../src/domain/types'

const TODAY = '2026-10-17'   // sobota
const NOW = `${TODAY}T08:00:00.000Z`
const P = {
  sex: 'm', age: 30, heightCm: 180, weightKg: 75, ftp: 250, ftpDate: '2026-10-01', maxHr: 190, restHr: 50, level: 3, hoursPerWeek: 11, hoursMode: 'own',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true }, strength: { on: false, equipment: 'none' }, strengthDays: 0,
  deficit: 500, goal: 'shujsati', neat: 1.4, proteinGkg: 1.8, onboardingDone: true, createdAt: NOW, updatedAt: NOW,
} as unknown as Profile
const day = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: 'd' + date + (o.kind || 'kolo'), date, kind: 'kolo', title: 'Dolga Z2', desc: 'Mirno v Z2.', durationMin: 105, zone: 'Z2', role: 'dolga', tssTarget: 80, source: 'rules', createdAt: NOW, updatedAt: NOW, ...o })
const real = (date: string, o: Partial<Activity> = {}): Activity => ({ id: 'r' + date + (o.sport || 'kolo'), source: 'intervals', originHint: 'GARMIN', sport: 'kolo', date, start: `${date}T07:00:00.000Z`, name: 'Jutranja vožnja', durationMin: 100, distKm: 40, avgHr: 135, tss: 75, aiEligible: true, geoRetain: true, expiresAt: null, ext: { intervalsId: 'i' + date }, createdAt: NOW, updatedAt: NOW, ...o } as Activity)
const done = (d: PlanDay, min?: number): PlanDay => ({ ...d, done: { at: NOW, activityId: null, ...(min ? { min } : {}) } })

describe('A03/A04/C04 zapis iz načrta (domena)', () => {
  it('»Opravil« brez minut: cel trening iz načrta (vir »iz načrta«, TSS in kcal po načrtu)', () => {
    const a = standInFor(done(day(TODAY)), P, null, NOW)!
    expect(a).toMatchObject({ source: 'plan', planDayId: 'd2026-10-17kolo', sport: 'kolo', date: TODAY, durationMin: 105, tss: 80, aiEligible: true })
    expect(a.kcal).toBeGreaterThan(500)
    expect(sourceLabel(a)).toBe('Iz načrta')
    expect(isStandIn(a)).toBe(true)
  })
  it('delno (31 od 105 min): minute, TSS in kcal sorazmerno', () => {
    const full = standInFor(done(day(TODAY)), P, null, NOW)!
    const part = standInFor(done(day(TODAY), 31), P, null, NOW)!
    expect(part.durationMin).toBe(31)
    expect(part.tss).toBe(Math.round(80 * 31 / 105))
    expect(Math.abs(part.kcal! - full.kcal! * 31 / 105)).toBeLessThanOrEqual(1)
    expect(doneMinutes(done(day(TODAY), 31))).toBe(31)
    expect(doneShare(done(day(TODAY), 31))).toBeCloseTo(31 / 105, 5)
  })
  it('ni zapisa: počitek, neopravljen dan, dan povezan s pravo vadbo; test FTP je vožnja, moč je moč', () => {
    expect(standInFor(done(day(TODAY, { kind: 'pocitek', durationMin: 0 })), P)).toBeNull()
    expect(standInFor(day(TODAY), P)).toBeNull()
    expect(standInFor({ ...day(TODAY), done: { at: NOW, activityId: 'x' } }, P)).toBeNull()
    expect(standInFor(done(day(TODAY, { kind: 'test', zone: 'test', tssTarget: 70, durationMin: 60 })), P)!.sport).toBe('kolo')
    expect(standInFor(done(day(TODAY, { kind: 'moc', durationMin: 30, tssTarget: null })), P)!).toMatchObject({ sport: 'moc', durationMin: 30, tss: 35 })
  })
  it('brez dvojnika: prava vadba istega dne in športa zamenja zapis iz načrta; moč, drug dan ali demo ne', () => {
    const s = standInFor(done(day(TODAY)), P, null, NOW)!
    expect(standInsToDrop([s], [real(TODAY)]).map(a => a.id)).toEqual([s.id])
    expect(standInsToDrop([s, real(TODAY)]).map(a => a.id)).toEqual([s.id])
    expect(standInsToDrop([s], [real(TODAY, { sport: 'moc' })])).toEqual([])
    expect(standInsToDrop([s], [real(addDays(TODAY, -1))])).toEqual([])
    expect(standInsToDrop([s], [real(TODAY, { source: 'demo' })])).toEqual([])
  })
  it('hribi z ure namesto kolesa (odkljukano kolo): dan šteje enkrat — razen če so hribi drug dan načrta; moč ostane', () => {
    const d = done(day('2026-10-03', { title: 'Dolga Z2 po hribih', durationMin: 140 }))
    const hike = real('2026-10-03', { sport: 'pohod', id: 'h', durationMin: 128 })
    expect(standInsToAdd([d], [hike], P, { today: TODAY, from: '2026-06-19' })).toEqual([])
    const s = standInFor(d, P)!
    expect(standInsToDrop([s], [hike]).map(a => a.id)).toEqual([s.id])
    const walk = done(day('2026-10-03', { kind: 'pohod', optional: true, durationMin: 120 }))
    const linked = { ...walk, done: { at: NOW, activityId: 'h' } }
    expect(standInsToAdd([d, linked], [hike], P, { today: TODAY, from: '2026-06-19' }).map(a => a.planDayId)).toEqual([d.id])
    const gym = done(day('2026-10-03', { kind: 'moc', title: 'Moč', durationMin: 30, tssTarget: 20 }))
    expect(standInsToAdd([gym], [real('2026-10-03')], P, { today: TODAY, from: '2026-06-19' }).map(a => a.sport)).toEqual(['moc'])
  })
  it('»Opravil« na dveh napravah brez povezave: ob usklajevanju ostane en zapis (novejši), na obeh isti', () => {
    const d = done(day(TODAY))
    const a = { ...standInFor(d, P, null, NOW)!, id: 'plan-a', updatedAt: '2026-10-17T08:00:00.000Z' }
    const b = { ...a, id: 'plan-b', updatedAt: '2026-10-17T09:00:00.000Z' }
    expect(standInsToDrop([a, b]).map(x => x.id)).toEqual(['plan-a'])
    expect(standInsToDrop([b, a]).map(x => x.id)).toEqual(['plan-a'])
  })
  it('stare kljukice: zapis za pretekle opravljene dneve; ne ob pravi vadbi, ne prihodnji, ne izbrisani (grob), ne dvakrat', () => {
    const d1 = done(day('2026-10-10')), d2 = done(day('2026-10-11')), d3 = done(day('2026-10-19')), d4 = done(day('2026-10-12'))
    const add = standInsToAdd([d1, d2, d3, d4], [real('2026-10-11')], P, { today: TODAY, from: '2026-06-19', tomb: { [`a:id:${standInId(d4)}`]: 1 } })
    expect(add.map(a => a.planDayId)).toEqual([d1.id])
    expect(add[0]!.id).toBe(standInId(d1))   // isti id na vseh napravah
    expect(standInsToAdd([d1], add, P, { today: TODAY, from: '2026-06-19' })).toEqual([])
  })
  it('A04: ura neha pošiljati 20. 9., nato 3 tedne po 5 × 60 min »Opravil« — načrt ni »po premoru« (4 h), forma ni »prepočit«', () => {
    // do 20. 9. vsak dan vožnja z ure, potem samo kljukice
    const old: Activity[] = []
    for (let d = '2026-07-23'; d <= '2026-09-20'; d = addDays(d, 1)) old.push(real(d, { id: 'r' + d, tss: 60, durationMin: 90 }))
    const days: PlanDay[] = []
    for (const ws of ['2026-09-21', '2026-09-28', '2026-10-05', '2026-10-12']) for (const k of [0, 1, 3, 5, 6]) days.push(done(day(addDays(ws, k), { durationMin: 60, tssTarget: 50 })))
    const si = standInsToAdd(days, old, P, { today: TODAY, from: addDays(TODAY, -120) })
    expect(si).toHaveLength(19)   // nedelja 18. 10. je še pred nami
    // prej: »po premoru« — (v3.50 B39) po 3 tednih premora polovica prejšnjega obsega (10,5 h → 5,5 h), ne vedno 4 h
    expect(realityCap(old, '2026-10-12', TODAY)).toMatchObject({ cap: 5.5, base: 0 })
    expect(realityCap([...old, ...si], '2026-10-12', TODAY)).toMatchObject({ base: 5, cap: 6.5 })
    const p = { ...P, hoursPerWeek: 9, goal: 'forma' } as Profile
    expect(planHours(p, old, '2026-10-12', TODAY).hours).toBe(5.5)
    expect(planHours(p, [...old, ...si], '2026-10-12', TODAY).hours).toBeGreaterThan(6)
    const tsb = (acts: Activity[]) => formSeries(acts, TODAY).at(-1)!.tsb
    expect(tsb(old)).toBeGreaterThan(20)
    expect(tsb([...old, ...si])).toBeLessThan(tsb(old) - 5)
  })
  it('ključni trening, odkljukan brez ure, šteje kot opravljen (ne »brez podatkov o utripu«)', () => {
    const k = done(day('2026-10-14', { title: 'VO2max 4 × 4 min', zone: 'Z5', role: 'kljucna', durationMin: 75, tssTarget: 70 }))
    const s = standInFor(k, P)!
    expect(keyCompliance([k], [s], '2026-10-12', TODAY).items[0]!.status).toBe('ok')
  })
  it('Plan: zapis iz načrta ni »dodatna vadba, ni bilo v načrtu«', () => {
    const d = done(day(TODAY)), s = standInFor(d, P)!
    expect(extraActivities([s, real(TODAY, { sport: 'tek', id: 'run' })], [d], TODAY).map(a => a.id)).toEqual(['run'])
  })
  it('»Krajše«: minute po 15 pri 1 h 45 min, po 5 pri 25 min, po 30 pri 4 h', () => {
    expect(minuteOptions(105)).toEqual([15, 30, 45, 60, 75, 90])
    expect(minuteOptions(25)).toEqual([5, 10, 15, 20])
    expect(minuteOptions(240)).toEqual([30, 60, 90, 120, 150, 180, 210])
    expect(minuteOptions(0)).toEqual([])
  })
})

describe('A05 kalorije po dejanskih minutah', () => {
  const opts = { today: TODAY, hour: 12 }
  it('31 od 105 min: cilj kot pri 31-minutnem treningu (prej +693 kcal za cel trening)', () => {
    const part = dailyTarget(P, [], [done(day(TODAY), 31)], TODAY, opts)!
    const short = dailyTarget(P, [], [done(day(TODAY, { durationMin: 31, tssTarget: 24 }))], TODAY, opts)!
    const full = dailyTarget(P, [], [done(day(TODAY))], TODAY, opts)!
    expect(Math.abs(part.kcal - short.kcal)).toBeLessThanOrEqual(10)
    expect(full.kcal - part.kcal).toBeGreaterThan(300)
    expect(targetParts(part, P)).toMatch(/trening ~\S+ po načrtu/)
  })
  it('zapis iz načrta ni »izmerjeno« in se ne šteje dvakrat', () => {
    const d = done(day(TODAY), 31), s = standInFor(d, P, null, NOW)!
    const a = dailyTarget(P, [s], [d], TODAY, opts)!, b = dailyTarget(P, [], [d], TODAY, opts)!
    expect(a.kcal).toBe(b.kcal)
    expect(a.burn).toBe(0)
    expect(targetParts(a, P)).not.toMatch(/izmerjeno/)
  })
  it('neopravljen dan šteje cel načrtovani trening (brez spremembe)', () => {
    const a = dailyTarget(P, [], [day(TODAY)], TODAY, opts)!, b = dailyTarget(P, [], [done(day(TODAY))], TODAY, opts)!
    expect(a.plannedBurn).toBe(b.estimatedBurn)
  })
})

describe('C05 včeraj: »Si ga naredil?« in ocena', () => {
  const Y = '2026-10-16'
  it('neoznačen včerajšnji trening brez vadbe z ure → vprašanje; z vožnjo z ure, po želji ali prestavljen → ne', () => {
    const d = day(Y)
    expect(yesterdayUnmarked({ today: TODAY, plan: [d], activities: [] })?.id).toBe(d.id)
    expect(yesterdayUnmarked({ today: TODAY, plan: [d], activities: [real(Y)] })).toBeNull()
    expect(yesterdayUnmarked({ today: TODAY, plan: [{ ...d, optional: true }], activities: [] })).toBeNull()
    expect(yesterdayUnmarked({ today: TODAY, plan: [{ ...d, missed: 'moved' }], activities: [] })).toBeNull()
    expect(yesterdayUnmarked({ today: TODAY, plan: [done(d)], activities: [] })).toBeNull()
  })
  it('ocena gre na dan načrta, ne na zapis iz načrta', () => {
    const d = done(day(Y)), s = standInFor(d, P)!
    expect(yesterdayToRate({ today: TODAY, plan: [d], activities: [s] })).toEqual({ title: d.title, activityId: null, dayId: d.id })
  })
})

describe('Shramba: »Opravil«, odznačitev, uvoz z ure, stare kljukice', () => {
  beforeAll(() => { vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date(`${TODAY}T10:00:00`)) })
  afterAll(() => { vi.useRealTimers() })
  beforeEach(async () => {
    await repo.wipeAll(); localStorage.clear(); await setKV('plan.changes', [])
    await repo.saveProfile(P)
    await store.reloadAll()
  })
  const plans = () => store.getState().activities.filter(isStandIn)
  async function seed(...days: PlanDay[]) { await repo.upsertPlanDays(days); await store.reloadAll() }

  it('»Opravil« zapiše vadbo iz načrta (Napredek, forma); odznačitev jo pobriše', async () => {
    const d = day(TODAY)
    await seed(d)
    await store.setPlanDone(d.id, true)
    expect(plans()).toHaveLength(1)
    expect(plans()[0]).toMatchObject({ planDayId: d.id, durationMin: 105, tss: 80, source: 'plan' })
    expect((await repo.allActivities()).length).toBe(1)
    expect(store.getState().plan.find(x => x.id === d.id)!.done!.activityId).toBeNull()   // dan ni »izmerjen«
    expect(formSeries(store.getState().activities, TODAY).at(-1)!.tss).toBe(80)
    await store.setPlanDone(d.id, false)
    expect(plans()).toHaveLength(0)
    expect(await repo.allActivities()).toEqual([])
    // ponovno »Opravil« (nov čas kljukice) — zapis spet nastane, grob ga ne skrije
    await store.setPlanDone(d.id, true)
    expect(plans()).toHaveLength(1)
  })

  it('delne minute (vodena vadba, »Krajše«): zapis z dejanskimi minutami, nove minute posodobijo isti zapis', async () => {
    const d = day(TODAY)
    await seed(d)
    await store.setPlanDone(d.id, true, null, 31)
    const first = plans()[0]!
    expect(first.durationMin).toBe(31)
    await store.setPlanDone(d.id, true, null, 45)
    expect(plans()).toHaveLength(1)
    expect(plans()[0]).toMatchObject({ id: first.id, durationMin: 45, tss: Math.round(80 * 45 / 105) })
  })

  it('brez dvojnika: vožnja z ure za isti dan zamenja zapis iz načrta in se poveže z dnem', async () => {
    const d = day(TODAY)
    await seed(d)
    await store.setPlanDone(d.id, true, null, 31)
    await store.addActivities([real(TODAY)])
    const acts = store.getState().activities.filter(a => a.date === TODAY)
    expect(acts.map(a => a.source)).toEqual(['intervals'])
    expect(store.getState().plan.find(x => x.id === d.id)!.done!.activityId).toBe(acts[0]!.id)
    expect(formSeries(store.getState().activities, TODAY).at(-1)!.tss).toBe(75)   // šteje enkrat (ura), ne 75 + 24
  })

  it('vožnja brez razdalje (trenažer) ni »dvojnik« zapisa iz načrta — uvozi se', async () => {
    const d = day(TODAY)
    await seed(d)
    await store.setPlanDone(d.id, true)
    const r = await store.addActivities([real(TODAY, { source: 'file', start: null, distKm: null, durationMin: 104, ext: undefined, trainer: true })])
    expect(r.added).toBe(1)
    expect(store.getState().activities.map(a => a.source)).toEqual(['file'])
  })

  it('vožnja z ure je že tu: »Opravil« ne doda zapisa iz načrta', async () => {
    const d = day(TODAY)
    await seed(d)
    await store.addActivities([real(TODAY, { durationMin: 20, distKm: 6, name: 'V službo' })])   // prekratka za ta trening
    await store.setPlanDone(d.id, true)
    expect(plans()).toHaveLength(0)
  })

  it('včerajšnji dan (C05) dobi zapis s svojim datumom; prihodnji dan ne', async () => {
    const y = day('2026-10-16'), t = day('2026-10-19')
    await seed(y, t)
    await store.setPlanDone(y.id, true)
    await store.setPlanDone(t.id, true)
    expect(plans().map(a => a.date)).toEqual(['2026-10-16'])
  })

  it('izbris zapisa iz načrta (Vse vadbe) odznači dan; ocena zapisa gre na dan', async () => {
    const d = day(TODAY)
    await seed(d)
    await store.setPlanDone(d.id, true)
    await store.rateSession({ activityId: plans()[0]!.id }, 7)
    expect(store.getState().plan.find(x => x.id === d.id)!.rpe).toBe(7)
    expect(plans()[0]!.rpe).toBeUndefined()
    await store.removeActivity(plans()[0]!.id)
    expect(store.getState().plan.find(x => x.id === d.id)!.done).toBeNull()
  })

  it('stare kljukice (pred v3.49) in kopija: zapis nastane enkrat, drugič nič', async () => {
    const old = done(day('2026-10-13', { durationMin: 60, tssTarget: 50 }))
    await seed(old, done(day('2026-10-14', { kind: 'pocitek', durationMin: 0, tssTarget: 0 })))
    expect(await store.ensureStandIns()).toBe(1)
    expect(plans()[0]).toMatchObject({ date: '2026-10-13', durationMin: 60, id: standInId(old) })
    expect(await store.ensureStandIns()).toBe(0)
  })

  it('druga naprava je uvozila vožnjo, zapis iz načrta je prišel ob usklajevanju: ob ponovnem branju odpade', async () => {
    const d = done(day(TODAY))
    await seed(d)
    await repo.putActivity(standInFor(d, P, null, NOW)!)
    await repo.putActivity(real(TODAY))
    await store.reloadAll()
    expect(store.getState().activities.map(a => a.source)).toEqual(['intervals'])
  })
})
