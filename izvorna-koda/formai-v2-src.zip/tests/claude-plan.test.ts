import { describe, it, expect } from 'vitest'
import type { Profile } from '../src/domain/types'
import { QUESTIONS_SCHEMA, PROPOSAL_SCHEMA, buildSchema, questionsRequest, proposalRequest, buildRequest, parseClaudeQuestions, parseClaudeProposal, parseClaudeBuild, planPayload, CLAUDE_SYSTEM, type PlanCtx } from '../src/domain/ai/claudePlan'
import { EXERCISES } from '../src/domain/training/exercises'
import { normalizeFocus, tailsOf, trainingDays } from '../src/domain/focus/model'
import { buildFocusWeek } from '../src/domain/training/focusPlan'
import { hasConsent, CONSENT_V } from '../src/domain/ai/actions'
import { focusWeekContext } from '../src/domain/training/focusPlan'
import { addDays } from '../src/domain/training/load'

/**
 * CLAUDE TRENER (14. 10.): model dobi vse dovoljene podatke in odloči sam; aplikacija sestavi točno njegov teden
 * (dnevi, kardio po moči, vsebina »kaj«), preveri samo varovalke.
 */
const NOW = '2026-10-14T08:00:00.000Z'
const TODAY = '2026-10-14'
const profile: Profile = { name: 'Ime Priimek', email: 'x@y.si', sex: 'm', age: 34, heightCm: 182, weightKg: 84, gear: { bikeOutdoor: true, trainer: true, noBike: false }, strength: { on: true, equipment: 'gym' }, onboardingDone: true, createdAt: NOW, updatedAt: NOW, place: { name: 'Kranj', lat: 46.2, lon: 14.3 } } as unknown as Profile
const ctx: PlanCtx = {
  today: TODAY, profile, basics: { sex: 'm', age: 34, heightCm: 182, weightKg: 84, avail: [0, 1, 3, 4, 5, 6], trainTime: 'zvecer', push: 'zmerno', main: 'oboje' },
  picks: { cilj: ['Manj kilogramov'], delam: ['Fitnes', 'Kolo'] }, text: 'Ob sredah ne morem.', wish: 'Cilj: manj kilogramov. Rad delam: fitnes, kolo. Ob sredah ne morem.',
  qa: [{ id: 'q1', q: 'Koliko časa imaš na vadbo?', a: '60–75 min' }], activities: [], plan: [], checkins: [{ date: TODAY, sleepH: 7, mood: 4, soreness: 2 }],
}

/** vsak objekt v shemi: vsa polja obvezna, brez dodatnih (zahteva strukturiranega izhoda) */
function strict(s: unknown, path = '$'): string[] {
  if (!s || typeof s !== 'object') return []
  const o = s as Record<string, unknown>
  const bad: string[] = []
  if (o.type === 'object') {
    const keys = Object.keys((o.properties || {}) as object)
    if (o.additionalProperties !== false) bad.push(`${path}: additionalProperties`)
    if (JSON.stringify([...((o.required as string[]) || [])].sort()) !== JSON.stringify([...keys].sort())) bad.push(`${path}: required`)
    for (const k of keys) bad.push(...strict((o.properties as Record<string, unknown>)[k], `${path}.${k}`))
  }
  if (o.type === 'array') bad.push(...strict(o.items, `${path}[]`))
  for (const k of ['minimum', 'maximum', 'minLength', 'maxLength', 'minItems', 'maxItems', 'pattern']) if (k in o) bad.push(`${path}: ${k}`)
  return bad
}

describe('Claude trener — zahtevki', () => {
  it('sheme so stroge (vsa polja obvezna, brez omejitev min/max) in majhne', () => {
    const all = buildSchema(EXERCISES.map(e => e.id))
    for (const s of [QUESTIONS_SCHEMA, PROPOSAL_SCHEMA, all]) expect(strict(s)).toEqual([])
    expect(JSON.stringify(all).length).toBeLessThan(60000)
  })
  it('podatki: brez imena, e-pošte in kraja; dnevi brez časa, odgovori, jutranji vnosi, pretekle vaje s kilogrami; brez izračuna aplikacije (proste roke)', () => {
    const acts = [{ id: 'a1', source: 'manual', sport: 'moc', date: '2026-10-10', start: null, name: 'Kranj fitnes', durationMin: 55, exercises: [{ name: 'Počep s palico', sets: 4, reps: '6', kg: 90 }], aiEligible: true, geoRetain: false, expiresAt: null, createdAt: NOW, updatedAt: NOW }] as unknown as PlanCtx['activities']
    const p = JSON.stringify(planPayload({ ...ctx, activities: acts, dose: { level: 2, days: 4, mix: { s: 2, c: 2 } } }))
    for (const x of ['Ime', 'Priimek', 'x@y.si', 'Kranj', '46.2']) expect(p).not.toContain(x)
    expect(p).toContain('"dnevi_brez_casa":["sreda"]')
    expect(p).toContain('60–75 min')
    expect(p).toContain('"spanec_h":7')
    expect(p).toContain('Počep s palico 4 × 6 90 kg')
    expect(p).not.toContain('izracun_aplikacije')
    expect(p).not.toContain('2× moč')
  })
  it('naloge: vprašanja (srednji premislek), predlog (največ), popravek (samo kar je rekel), sestava z vajami iz knjižnice', () => {
    const q = questionsRequest(ctx, 1)
    expect(q).toMatchObject({ purpose: 'vprasanja', effort: 'high', system: CLAUDE_SYSTEM })
    const p = proposalRequest(ctx)
    expect(p).toMatchObject({ purpose: 'predlog', effort: 'max' })
    expect(p.user).toContain('sestavi najboljši možen načrt')
    const fb = proposalRequest({ ...ctx, feedback: 'Več kolesa, fitnes ostane.' })
    expect(fb.effort).toBe('max')
    expect(fb.user).toContain('Več kolesa, fitnes ostane.')
    const f = normalizeFocus({ wish: ctx.wish, equipment: ['fitnes'], level: 2, sessions: [{ type: 'fitnes', part: 'zgornji', min: 60 }, { type: 'kolo', cardio: 'lahko', min: 90 }] }, { now: NOW })!
    const b = buildRequest({ ...ctx, focus: f, nutrition: { kcal: 2300, proteinG: 150, deficit: 400 } })
    expect(b).toMatchObject({ purpose: 'sestava', effort: 'max' })
    expect(b.user).toContain('~2300 kcal')
    expect(b.user).toContain('KNJIŽNICA VAJ')
    // sistem: proste roke; nedotakljivo ostane prehrana (varovalke) in zdravstveni pridržek
    for (const x of ['Pod 18 let nikoli hujšanja', 'nikoli pod bazalno porabo', 'največ 750 kcal', 'Nisi zdravnik', 'nima vnaprejšnjih omejitev']) expect(CLAUDE_SYSTEM).toContain(x)
    for (const x of ['Največ 6', '20 h']) expect(CLAUDE_SYSTEM).not.toContain(x)
  })
})

describe('Claude trener — odgovori → aplikacija', () => {
  const RAW = {
    odgovor: 'Upošteval: ob sredah ne moreš, manj kilogramov. Teden ima dve moči in tri kolesa.', ime: 'Lažji in močnejši', raven: 2,
    cilji: ['hujsanje', 'moc'], misice: [], oprema: ['fitnes'], omejitve: '', ohraniMisice: true, dneviBrezCasa: [2, 6],
    seje: [
      { dan: 3, vrsta: 'fitnes', del: 'spodnji', kardio: '', min: 60, poMoci: false, kaj: 'Počep, mrtvi dvig, iztisk z nogami', zakaj: 'Noge daleč od dolge vožnje.' },
      { dan: 0, vrsta: 'fitnes', del: 'zgornji', kardio: '', min: 60, poMoci: false, kaj: '**Potisk** in poteg, 6–10 ponovitev', zakaj: 'Začetek tedna.' },
      { dan: 0, vrsta: 'kolo', del: '', kardio: 'lahko', min: 20, poMoci: true, kaj: 'Lahko na trenažerju', zakaj: 'Ohladitev.' },
      { dan: 5, vrsta: 'kolo', del: '', kardio: 'dolgo', min: 150, poMoci: false, kaj: 'Dolga lahka vožnja v pogovornem tempu', zakaj: 'Ob vikendu imaš čas.' },
      { dan: 1, vrsta: 'kolo', del: '', kardio: 'intervali', min: 60, poMoci: false, kaj: '4 × 6 min hitro, vmes 4 min lahko', zakaj: 'Ključna vadba.' },
      { dan: 6, vrsta: 'kolo', del: '', kardio: 'lahko', min: 60, poMoci: false, kaj: 'Lahko', zakaj: 'Na prost dan ne sme.' },
    ],
    zakaj: ['Moč je razmaknjena (pon, čet).', 'Ta teden si bil neaktiven, zato lažje.'], opombe: [], hitri: ['Več moči', 'Manj dni'],
  }

  it('vsaka seja na svoj dan, kardio po moči takoj za močjo, vsebina ostane; dnevi brez časa iz 1. koraka in od trenerja', () => {
    const out = parseClaudeProposal(RAW, { wish: ctx.wish, age: 34, now: NOW, offDays: [2], hidden: true })!
    const f = out.focus
    expect(f.by).toBe('claude')
    expect(f.offDays).toEqual([2, 6])
    // nedelja je dan brez časa: seja tam izgubi dan (aplikacija jo razporedi drugam)
    expect(f.sessions.map(s => [s.type, s.day ?? null, !!s.after])).toEqual([
      ['fitnes', 0, false], ['kolo', null, true], ['kolo', 1, false], ['fitnes', 3, false], ['kolo', 5, false], ['kolo', null, false],
    ])
    expect(tailsOf(f.sessions).get(1)).toBe(0)
    expect(f.sessions[0]!.what).toBe('Potisk in poteg, 6–10 ponovitev')
    expect(f.sessions[2]!.what).toBe('4 × 6 min hitro, vmes 4 min lahko')
    expect(trainingDays(f.sessions)).toBe(5)
    expect(f.keepMuscle).toBe(true)
    // skrite aktivnosti: »neaktiven« iz razlage izpade
    expect(f.why!.join(' ')).not.toMatch(/neaktiven/)
    expect(out.reply.startsWith('Upošteval:')).toBe(true)
    expect(out.quick).toEqual(['Več moči', 'Manj dni'])
  })

  it('proste roke: 7 dni in dolge vadbe ostanejo, kot jih je dal; nedotakljivo: pod 18 brez hujšanja; nesmisel (100 h) se zavrne', () => {
    const many = { ...RAW, raven: 1, dneviBrezCasa: [], seje: [0, 1, 2, 3, 4, 5, 6].map(d => ({ dan: d, vrsta: 'tek', del: '', kardio: 'lahko', min: 200, poMoci: false, kaj: '', zakaj: '' })) }
    const f = parseClaudeProposal(many, { wish: 'x', age: 16, now: NOW, offDays: [] })!.focus
    expect(f.aims).not.toContain('hujsanje')
    expect(trainingDays(f.sessions)).toBe(7)
    expect(f.sessions.every(s => s.min === 200)).toBe(true)
    expect(f.mode).toBe('meri')
    const crazy = parseClaudeProposal({ ...many, seje: many.seje.map(x => ({ ...x, min: 99999 })) }, { wish: 'x', offDays: [] })!.focus
    expect(crazy.sessions.reduce((t, s) => t + s.min, 0)).toBeLessThanOrEqual(50 * 60)
    // obseg bloka od trenerja
    expect(parseClaudeProposal({ ...RAW, obseg_4_tednov: [1, 1.1, 1.2, 0.6] }, { wish: 'x', offDays: [] })!.focus.block).toEqual([1, 1.1, 1.2, 0.6])
  })

  it('dva kardia na dan moči → en kardio po moči (minute skupaj); dve glavni vadbi na dan → druga drug dan in odgovor to pove', () => {
    const raw = { ...RAW, dneviBrezCasa: [], seje: [
      { dan: 0, vrsta: 'fitnes', del: 'celo', kardio: '', min: 50, poMoci: false, kaj: 'Moč', zakaj: '' },
      { dan: 0, vrsta: 'kolo', del: '', kardio: 'lahko', min: 15, poMoci: true, kaj: 'Kolo', zakaj: '' },
      { dan: 0, vrsta: 'tek', del: '', kardio: 'lahko', min: 10, poMoci: true, kaj: 'Tek', zakaj: '' },
      { dan: 2, vrsta: 'tek', del: '', kardio: 'intervali', min: 45, poMoci: false, kaj: 'Intervali', zakaj: '' },
      { dan: 2, vrsta: 'kolo', del: '', kardio: 'lahko', min: 60, poMoci: false, kaj: 'Lahko kolo', zakaj: '' },
      { dan: 3, vrsta: 'fitnes', del: 'celo', kardio: '', min: 50, poMoci: false, kaj: 'Moč 2', zakaj: '' },
    ] }
    const out = parseClaudeProposal(raw, { wish: 'x', offDays: [] })!
    const f = out.focus
    expect(f.sessions.map(s => [s.type, s.day ?? null, !!s.after, s.min])).toEqual([['fitnes', 0, false, 50], ['kolo', null, true, 25], ['tek', 2, false, 45], ['kolo', null, false, 60], ['fitnes', 3, false, 50]])
    expect(f.sessions[1]!.what).toBe('Kolo; Tek')
    expect(tailsOf(f.sessions).get(1)).toBe(0)
    expect(out.reply).toContain('Aplikacija: kolo na drugem dnevu')
  })

  it('lažji teden v trenerjevem bloku: samo izrazito najmanjši (ne prvi teden z 0,9)', () => {
    const f = parseClaudeProposal({ ...RAW, obseg_4_tednov: [0.9, 1, 1.1, 0.7] }, { wish: 'x', offDays: [] })!.focus
    const p = { ...profile, focus: f, cycleStart: '2026-10-19' } as Profile
    expect([0, 1, 2, 3].map(w => focusWeekContext(p, addDays('2026-10-19', 7 * w)).recovery)).toEqual([false, false, false, true])
    const g = parseClaudeProposal({ ...RAW, obseg_4_tednov: [1, 1, 1, 1] }, { wish: 'x', offDays: [] })!.focus
    expect([0, 1, 2, 3].map(w => focusWeekContext({ ...p, focus: g }, addDays('2026-10-19', 7 * w)).recovery)).toEqual([false, false, false, false])
  })

  it('česa aplikacija ne zna: trenerjev seznam + dve glavni vadbi na isti dan (gre uporabniku in med predloge)', () => {
    const out = parseClaudeProposal({ ...RAW, aplikacija_ne_zna: ['plavanje kot obnovitvena vadba'], seje: [...RAW.seje, { dan: 1, vrsta: 'tek', del: '', kardio: 'lahko', min: 30, poMoci: false, kaj: 'x', zakaj: 'y' }] }, { wish: 'x', offDays: [] })!
    expect(out.missing![0]).toBe('plavanje kot obnovitvena vadba')
    expect(out.missing!.some(m => /dve glavni vadbi/.test(m))).toBe(true)
    expect(parseClaudeProposal(RAW, { wish: 'x', offDays: [2] })!.missing).toEqual([])
  })
  it('slike gredo trenerju (vsi trije klici); dnevi niso označeni → vpraša', () => {
    const img = { mime: 'image/jpeg', data: 'AAAA' }
    expect(questionsRequest({ ...ctx, images: [img] }, 1).images).toEqual([img])
    expect(proposalRequest({ ...ctx, images: [img] }).images).toEqual([img])
    expect(proposalRequest(ctx).images).toBeUndefined()
    const p = JSON.stringify(planPayload({ ...ctx, images: [img], daysPicked: false }))
    expect(p).toContain('ni označil')
    expect(p).not.toContain('dnevi_brez_casa')
    expect(p).toContain('"prilozene_slike":"1 (na začetku sporočila)"')
    expect(CLAUDE_SYSTEM).toContain('Ljudi na slikah ne prepoznavaj')
  })

  it('prazen ali pokvarjen odgovor → null (aplikacija gre na rezervo)', () => {
    expect(parseClaudeProposal(null, { wish: 'x', offDays: [] })).toBeNull()
    expect(parseClaudeProposal({ seje: [] }, { wish: 'x', offDays: [] })).toBeNull()
    expect(parseClaudeQuestions({ razumel: 'ok', vprasanja: [{ id: 'a', vprasanje: 'Koliko dni?', vec: false, moznosti: ['3', '4'], drugo: true }], dovolj: false })!.questions).toHaveLength(1)
  })

  it('sestava: vaje samo iz knjižnice (vsaj 3), vsebina in razlog vsake seje, strategija v vrsticah', () => {
    const f = normalizeFocus({ wish: 'x', equipment: ['fitnes'], level: 2, sessions: [{ type: 'fitnes', part: 'zgornji', min: 60 }, { type: 'kolo', cardio: 'lahko', min: 90, what: 'stara vsebina' }] }, { now: NOW, by: 'claude' })!
    const ids = EXERCISES.filter(e => e.eq !== 'nic').slice(0, 4).map(e => e.id)
    const v = (id: string, k = 0) => ({ id, serije: 4, ponovitve: '6–8', odmor_s: 120, kg: k })
    const out = parseClaudeBuild({ seje: [{ i: 0, vaje: [...ids.map((id, k) => v(id, k ? 0 : 62.3)), v('izmisljena')], kaj: 'Potisk na klopi 4 × 6', zakaj: 'Moč zgoraj.' }, { i: 1, vaje: [], kaj: 'Lahka vožnja 90 min', zakaj: '' }, { i: 7, vaje: [], kaj: 'x', zakaj: 'x' }], strategija: 'Prva vrstica\n- druga vrstica\n– tretja' }, f)
    expect(out.sessions[0]!.ex).toEqual(ids)
    expect(out.sessions[0]!.plan![0]).toEqual({ id: ids[0], sets: 4, reps: '6–8', rest: 120, kg: 62.5 })
    expect(out.sessions[0]!.plan![1]!.kg).toBeNull()
    expect(out.sessions[0]!.what).toBe('Potisk na klopi 4 × 6')
    expect(out.sessions[1]!.what).toBe('Lahka vožnja 90 min')
    expect(out.strategy).toBe('– Prva vrstica\n– druga vrstica\n– tretja')
    // ena sama vaja je tudi trenerjeva odločitev
    const one = parseClaudeBuild({ seje: [{ i: 0, vaje: [v(ids[0]!)], kaj: '', zakaj: '' }], strategija: '' }, f)
    expect(one.sessions[0]!.ex).toEqual([ids[0]])
    expect(one.sessions[1]!.what).toBe('stara vsebina')
  })

  it('aplikacija sestavi točno trenerjev teden: dnevi in vsebina v načrtu', () => {
    const f = parseClaudeProposal(RAW, { wish: ctx.wish, age: 34, now: NOW, offDays: [2] })!.focus
    const ws = '2026-10-19'   // ponedeljek
    const p = { ...profile, focus: f, cycleStart: ws } as Profile
    const week = buildFocusWeek({ profile: p, activities: [], weekStart: ws, notBefore: ws })
    const on = (d: number) => week.filter(x => x.date === addDays(ws, d) && x.kind !== 'pocitek')
    expect(on(0).map(x => x.kind)).toEqual(['moc'])
    expect(on(0)[0]!.tail).toMatchObject({ kind: 'kolo', durationMin: 20 })   // točno trenerjevih 20 min
    expect(on(0)[0]!.desc).toContain('Potisk in poteg')
    expect(on(1)[0]!.desc).toContain('4 × 6 min hitro')
    expect(on(2)).toHaveLength(0)
    expect(on(3)[0]!.kind).toBe('moc')
    expect(on(5)[0]!.desc).toContain('Dolga lahka vožnja')
    expect(on(6)).toHaveLength(0)
  })

  it('vaje točno od trenerja (serije, ponovitve, odmor, kg) in obseg tednov iz njegovega bloka', () => {
    const base = parseClaudeProposal({ ...RAW, obseg_4_tednov: [1, 1.2, 1.3, 0.5] }, { wish: ctx.wish, age: 34, now: NOW, offDays: [2] })!.focus
    const gym = EXERCISES.filter(e => e.eq === 'fitnes').slice(0, 2)
    const f = parseClaudeBuild({ seje: [{ i: 0, vaje: gym.map((e, k) => ({ id: e.id, serije: 5 + k, ponovitve: '5', odmor_s: 180, kg: e.kg ? 100 : 0 })), kaj: 'Težko', zakaj: '' }], strategija: '' }, base)
    const ws = '2026-10-19'
    const p = { ...profile, focus: f, cycleStart: ws } as Profile
    const mon = (w: number) => buildFocusWeek({ profile: p, activities: [], weekStart: addDays(ws, 7 * w), notBefore: addDays(ws, 7 * w) }).find(x => x.date === addDays(ws, 7 * w))!
    expect(mon(0).exercises!.map(e => [e.name, e.sets, e.reps, e.rest])).toEqual(gym.map((e, k) => [e.name, 5 + k, '5', 180]))
    expect(mon(0).exercises![0]!.kg ?? null).toBe(gym[0]!.kg ? 100 : null)
    // lažji teden (0,5): serija manj; kardio × obseg
    expect(mon(3).exercises!.map(e => e.sets)).toEqual(gym.map((_, k) => 4 + k))
    const sat = (w: number) => buildFocusWeek({ profile: p, activities: [], weekStart: addDays(ws, 7 * w), notBefore: addDays(ws, 7 * w) }).find(x => x.date === addDays(ws, 7 * w + 5))!
    expect([0, 1, 2, 3].map(w => sat(w).durationMin)).toEqual([150, 180, 195, 75])
  })
})

describe('privolitev za AI', () => {
  it('Gemini: vsaka privolitev; Claude in glas: samo besedilo različice 2 (ne po uri naprave)', () => {
    expect(CONSENT_V).toBe(2)
    expect(hasConsent({ aiConsentAt: null, aiConsentV: 2 })).toBe(false)
    expect(hasConsent({ aiConsentAt: '2026-09-01T08:00:00.000Z' })).toBe(true)
    expect(hasConsent({ aiConsentAt: '2026-09-01T08:00:00.000Z' }, CONSENT_V)).toBe(false)
    expect(hasConsent({ aiConsentAt: '2026-11-01T08:00:00.000Z' }, CONSENT_V)).toBe(false)   // stara aplikacija po izidu: brez različice
    expect(hasConsent({ aiConsentAt: '2020-01-01T08:00:00.000Z', aiConsentV: 2 }, CONSENT_V)).toBe(true)   // ura naprave zaostaja: velja
  })
})
