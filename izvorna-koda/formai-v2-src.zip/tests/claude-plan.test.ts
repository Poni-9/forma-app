import { describe, it, expect } from 'vitest'
import type { Profile } from '../src/domain/types'
import { QUESTIONS_SCHEMA, PROPOSAL_SCHEMA, buildSchema, questionsRequest, proposalRequest, buildRequest, parseClaudeQuestions, parseClaudeProposal, parseClaudeBuild, planPayload, CLAUDE_SYSTEM, type PlanCtx } from '../src/domain/ai/claudePlan'
import { EXERCISES } from '../src/domain/training/exercises'
import { normalizeFocus, tailsOf, trainingDays } from '../src/domain/focus/model'
import { buildFocusWeek } from '../src/domain/training/focusPlan'
import { hasConsent, CONSENT_V } from '../src/domain/ai/actions'
import { focusWeekContext } from '../src/domain/training/focusPlan'
import { addDays } from '../src/domain/training/load'

/**
 * CLAUDE TRENER (14. 10.): model dobi vse dovoljene podatke in odloči sam; aplikacija sestavi točno njegov teden
 * (dnevi, kardio po moči, vsebina »kaj«), preveri samo varovalke.
 */
const NOW = '2026-10-14T08:00:00.000Z'
const TODAY = '2026-10-14'
const profile: Profile = { name: 'Ime Priimek', email: 'x@y.si', sex: 'm', age: 34, heightCm: 182, weightKg: 84, gear: { bikeOutdoor: true, trainer: true, noBike: false }, strength: { on: true, equipment: 'gym' }, onboardingDone: true, createdAt: NOW, updatedAt: NOW, place: { name: 'Kranj', lat: 46.2, lon: 14.3 } } as unknown as Profile
const ctx: PlanCtx = {
  today: TODAY, profile, basics: { sex: 'm', age: 34, heightCm: 182, weightKg: 84, avail: [0, 1, 3, 4, 5, 6], trainTime: 'zvecer', push: 'zmerno', main: 'oboje' },
  picks: { cilj: ['Manj kilogramov'], delam: ['Fitnes', 'Kolo'] }, text: 'Ob sredah ne morem.', wish: 'Cilj: manj kilogramov. Rad delam: fitnes, kolo. Ob sredah ne morem.',
  qa: [{ id: 'q1', q: 'Koliko časa imaš na vadbo?', a: '60–75 min' }], activities: [], plan: [], checkins: [{ date: TODAY, sleepH: 7, mood: 4, soreness: 2 }],
}

/** vsak objekt v shemi: vsa polja obvezna, brez dodatnih (zahteva strukturiranega izhoda) */
function strict(s: unknown, path = '$'): string[] {
  if (!s || typeof s !== 'object') return []
  const o = s as Record<string, unknown>
  const bad: string[] = []
  if (o.type === 'object') {
    const keys = Object.keys((o.properties || {}) as object)
    if (o.additionalProperties !== false) bad.push(`${path}: additionalProperties`)
    if (JSON.stringify([...((o.required as string[]) || [])].sort()) !== JSON.stringify([...keys].sort())) bad.push(`${path}: required`)
    for (const k of keys) bad.push(...strict((o.properties as Record<string, unknown>)[k], `${path}.${k}`))
  }
  if (o.type === 'array') bad.push(...strict(o.items, `${path}[]`))
  for (const k of ['minimum', 'maximum', 'minLength', 'maxLength', 'minItems', 'maxItems', 'pattern']) if (k in o) bad.push(`${path}: ${k}`)
  return bad
}

describe('Claude trener — zahtevki', () => {
  it('sheme so stroge (vsa polja obvezna, brez omejitev min/max) in majhne', () => {
    const all = buildSchema(EXERCISES.map(e => e.id))
    for (const s of [QUESTIONS_SCHEMA, PROPOSAL_SCHEMA, all]) expect(strict(s)).toEqual([])
    expect(JSON.stringify(all).length).toBeLessThan(60000)
  })
  it('podatki: brez imena, e-pošte in kraja; dnevi brez časa, odgovori, jutranji vnosi, pretekle vaje s kilogrami; brez izračuna aplikacije (proste roke)', () => {
    const acts = [{ id: 'a1', source: 'manual', sport: 'moc', date: '2026-10-10', start: null, name: 'Kranj fitnes', durationMin: 55, exercises: [{ name: 'Počep s palico', sets: 4, reps: '6', kg: 90 }], aiEligible: true, geoRetain: false, expiresAt: null, createdAt: NOW, updatedAt: NOW }] as unknown as PlanCtx['activities']
    const p = JSON.stringify(planPayload({ ...ctx, activities: acts, dose: { level: 2, days: 4, mix: { s: 2, c: 2 } } }))
    for (const x of ['Ime', 'Priimek', 'x@y.si', 'Kranj', '46.2']) expect(p).not.toContain(x)
    expect(p).toContain('"dnevi_brez_casa":["sreda"]')
    expect(p).toContain('60–75 min')
    expect(p).toContain('"spanec_h":7')
    expect(p).toContain('Počep s palico 4 × 6 90 kg')
    expect(p).not.toContain('izracun_aplikacije')
    expect(p).not.toContain('2× moč')
  })
  it('naloge: vprašanja, predlog in sestava na visokem premisleku (max je porabil ves strop), popravek (samo kar je rekel), sestava z vajami iz knjižnice', () => {
    const q = questionsRequest(ctx, 1)
    expect(q).toMatchObject({ purpose: 'vprasanja', effort: 'high', system: CLAUDE_SYSTEM })
    const p = proposalRequest(ctx)
    expect(p).toMatchObject({ purpose: 'predlog', effort: 'high' })
    expect(p.user).toContain('sestavi najboljši možen načrt')
    const fb = proposalRequest({ ...ctx, feedback: 'Več kolesa, fitnes ostane.' })
    expect(fb.effort).toBe('medium')
    expect(fb.user).toContain('Več kolesa, fitnes ostane.')
    const f = normalizeFocus({ wish: ctx.wish, equipment: ['fitnes'], level: 2, sessions: [{ type: 'fitnes', part: 'zgornji', min: 60 }, { type: 'kolo', cardio: 'lahko', min: 90 }] }, { now: NOW })!
    const b = buildRequest({ ...ctx, focus: f, nutrition: { kcal: 2300, proteinG: 150, deficit: 400 } })
    expect(b).toMatchObject({ purpose: 'sestava', effort: 'high' })
    expect(b.user).toContain('~2300 kcal')
    expect(b.user).toContain('KNJIŽNICA VAJ')
    // sistem: proste roke; nedotakljivo ostane prehrana (varovalke) in zdravstveni pridržek
    for (const x of ['Pod 18 let nikoli hujšanja', 'nikoli pod bazalno porabo', 'največ 750 kcal', 'Nisi zdravnik', 'nima vnaprejšnjih omejitev']) expect(CLAUDE_SYSTEM).toContain(x)
    for (const x of ['Največ 6', '20 h']) expect(CLAUDE_SYSTEM).not.toContain(x)
  })
})

describe('Claude trener — odgovori → aplikacija', () => {
  const RAW = {
    odgovor: 'Upošteval: ob sredah ne moreš, manj kilogramov. Teden ima dve moči in tri kolesa.', ime: 'Lažji in močnejši', raven: 2,
    cilji: ['hujsanje', 'moc'], misice: [], oprema: ['fitnes'], omejitve: '', ohraniMisice: true, dneviBrezCasa: [2, 6],
    seje: [
      { dan: 3, vrsta: 'fitnes', del: 'spodnji', kardio: '', min: 60, poMoci: false, kaj: 'Počep, mrtvi dvig, iztisk z nogami', zakaj: 'Noge daleč od dolge vožnje.' },
      { dan: 0, vrsta: 'fitnes', del: 'zgornji', kardio: '', min: 60, poMoci: false, kaj: '**Potisk** in poteg, 6–10 ponovitev', zakaj: 'Začetek tedna.' },
      { dan: 0, vrsta: 'kolo', del: '', kardio: 'lahko', min: 20, poMoci: true, kaj: 'Lahko na trenažerju', zakaj: 'Ohladitev.' },
      { dan: 5, vrsta: 'kolo', del: '', kardio: 'dolgo', min: 150, poMoci: false, kaj: 'Dolga lahka vožnja v pogovornem tempu', zakaj: 'Ob vikendu imaš čas.' },
      { dan: 1, vrsta: 'kolo', del: '', kardio: 'intervali', min: 60, poMoci: false, kaj: '4 × 6 min hitro, vmes 4 min lahko', zakaj: 'Ključna vadba.' },
      { dan: 6, vrsta: 'kolo', del: '', kardio: 'lahko', min: 60, poMoci: false, kaj: 'Lahko', zakaj: 'Na prost dan ne sme.' },
    ],
    zakaj: ['Moč je razmaknjena (pon, čet).', 'Ta teden si bil neaktiven, zato lažje.'], opombe: [], hitri: ['Več moči', 'Manj dni'],
  }

  it('vsaka seja na svoj dan, kardio po moči takoj za močjo, vsebina ostane; dnevi brez časa iz 1. koraka in od trenerja', () => {
    const out = parseClaudeProposal(RAW, { wish: ctx.wish, age: 34, now: NOW, offDays: [2], hidden: true })!
    const f = out.focus
    expect(f.by).toBe('claude')
    expect(f.offDays).toEqual([2, 6])
    // nedelja je dan brez časa: seja tam izgubi dan (aplikacija jo razporedi drugam)
    expect(f.sessions.map(s => [s.type, s.day ?? null, !!s.after])).toEqual([
      ['fitnes', 0, false], ['kolo', null, true], ['kolo', 1, false], ['fitnes', 3, false], ['kolo', 5, false], ['kolo', null, false],
    ])
    expect(tailsOf(f.sessions).get(1)).toBe(0)
    expect(f.sessions[0]!.what).toBe('Potisk in poteg, 6–10 ponovitev')
    expect(f.sessions[2]!.what).toBe('4 × 6 min hitro, vmes 4 min lahko')
    expect(trainingDays(f.sessions)).toBe(5)
    expect(f.keepMuscle).toBe(true)
    // skrite aktivnosti: »neaktiven« iz razlage izpade
    expect(f.why!.join(' ')).not.toMatch(/neaktiven/)
    expect(out.reply.startsWith('Upošteval:')).toBe(true)
    expect(out.quick).toEqual(['Več moči', 'Manj dni'])
  })

  it('proste roke: 7 dni in dolge vadbe ostanejo, kot jih je dal; nedotakljivo: pod 18 brez hujšanja; nesmisel (100 h) se zavrne', () => {
    const many = { ...RAW, raven: 1, dneviBrezCasa: [], seje: [0, 1, 2, 3, 4, 5, 6].map(d => ({ dan: d, vrsta: 'tek', del: '', kardio: 'lahko', min: 200, poMoci: false, kaj: '', zakaj: '' })) }
    const f = parseClaudeProposal(many, { wish: 'x', age: 16, now: NOW, offDays: [] })!.focus
    expect(f.aims).not.toContain('hujsanje')
    expect(trainingDays(f.sessions)).toBe(7)
    expect(f.sessions.every(s => s.min === 200)).toBe(true)
    expect(f.mode).toBe('meri')
    const crazy = parseClaudeProposal({ ...many, seje: many.seje.map(x => ({ ...x, min: 99999 })) }, { wish: 'x', offDays: [] })!.focus
    expect(crazy.sessions.reduce((t, s) => t + s.min, 0)).toBeLessThanOrEqual(50 * 60)
    // obseg bloka od trenerja
    expect(parseClaudeProposal({ ...RAW, obseg_4_tednov: [1, 1.1, 1.2, 0.6] }, { wish: 'x', offDays: [] })!.focus.block).toEqual([1, 1.1, 1.2, 0.6])
  })

  it('dva kardia na dan moči → en kardio po moči (minute skupaj); dve glavni vadbi na dan → druga drug dan in odgovor to pove', () => {
    const raw = { ...RAW, dneviBrezCasa: [], seje: [
      { dan: 0, vrsta: 'fitnes', del: 'celo', kardio: '', min: 50, poMoci: false, kaj: 'Moč', zakaj: '' },
      { dan: 0, vrsta: 'kolo', del: '', kardio: 'lahko', min: 15, poMoci: true, kaj: 'Kolo', zakaj: '' },
      { dan: 0, vrsta: 'tek', del: '', kardio: 'lahko', min: 10, poMoci: true, kaj: 'Tek', zakaj: '' },
      { dan: 2, vrsta: 'tek', del: '', kardio: 'intervali', min: 45, poMoci: false, kaj: 'Intervali', zakaj: '' },
      { dan: 2, vrsta: 'kolo', del: '', kardio: 'lahko', min: 60, poMoci: false, kaj: 'Lahko kolo', zakaj: '' },
      { dan: 3, vrsta: 'fitnes', del: 'celo', kardio: '', min: 50, poMoci: false, kaj: 'Moč 2', zakaj: '' },
    ] }
    const out = parseClaudeProposal(raw, { wish: 'x', offDays: [] })!
    const f = out.focus
    expect(f.sessions.map(s => [s.type, s.day ?? null, !!s.after, s.min])).toEqual([['fitnes', 0, false, 50], ['kolo', null, true, 25], ['tek', 2, false, 45], ['kolo', null, false, 60], ['fitnes', 3, false, 50]])
    expect(f.sessions[1]!.what).toBe('Kolo; Tek')
    expect(tailsOf(f.sessions).get(1)).toBe(0)
    expect(out.reply).toContain('Aplikacija: kolo na drugem dnevu')
  })

  it('lažji teden v trenerjevem bloku: samo izrazito najmanjši (ne prvi teden z 0,9)', () => {
    const f = parseClaudeProposal({ ...RAW, obseg_4_tednov: [0.9, 1, 1.1, 0.7] }, { wish: 'x', offDays: [] })!.focus
    const p = { ...profile, focus: f, cycleStart: '2026-10-19' } as Profile
    expect([0, 1, 2, 3].map(w => focusWeekContext(p, addDays('2026-10-19', 7 * w)).recovery)).toEqual([false, false, false, true])
    const g = parseClaudeProposal({ ...RAW, obseg_4_tednov: [1, 1, 1, 1] }, { wish: 'x', offDays: [] })!.focus
    expect([0, 1, 2, 3].map(w => focusWeekContext({ ...p, focus: g }, addDays('2026-10-19', 7 * w)).recovery)).toEqual([false, false, false, false])
  })

  it('česa aplikacija ne zna: trenerjev seznam + dve glavni vadbi na isti dan (gre uporabniku in med predloge)', () => {
    const out = parseClaudeProposal({ ...RAW, aplikacija_ne_zna: ['plavanje kot obnovitvena vadba'], seje: [...RAW.seje, { dan: 1, vrsta: 'tek', del: '', kardio: 'lahko', min: 30, poMoci: false, kaj: 'x', zakaj: 'y' }] }, { wish: 'x', offDays: [] })!
    expect(out.missing![0]).toBe('plavanje kot obnovitvena vadba')
    expect(out.missing!.some(m => /dve glavni vadbi/.test(m))).toBe(true)
    expect(parseClaudeProposal(RAW, { wish: 'x', offDays: [2] })!.missing).toEqual([])
  })
  it('slike gredo trenerju (vsi trije klici); dnevi niso označeni → vpraša', () => {
    const img = { mime: 'image/jpeg', data: 'AAAA' }
    expect(questionsRequest({ ...ctx, images: [img] }, 1).images).toEqual([img])
    expect(proposalRequest({ ...ctx, images: [img] }).images).toEqual([img])
    expect(proposalRequest(ctx).images).toBeUndefined()
    const p = JSON.stringify(planPayload({ ...ctx, images: [img], daysPicked: false }))
    expect(p).toContain('ni označil')
    expect(p).not.toContain('dnevi_brez_casa')
    expect(p).toContain('"prilozene_slike":"1 (na začetku sporočila)"')
    expect(CLAUDE_SYSTEM).toContain('Ljudi na slikah ne prepoznavaj')
  })

  it('prazen ali pokvarjen odgovor → null (aplikacija gre na rezervo)', () => {
    expect(parseClaudeProposal(null, { wish: 'x', offDays: [] })).toBeNull()
    expect(parseClaudeProposal({ seje: [] }, { wish: 'x', offDays: [] })).toBeNull()
    expect(parseClaudeQuestions({ razumel: 'ok', vprasanja: [{ id: 'a', vprasanje: 'Koliko dni?', vec: false, moznosti: ['3', '4'], drugo: true }], dovolj: false })!.questions).toHaveLength(1)
  })

  it('sestava: vaje samo iz knjižnice (vsaj 3), vsebina in razlog vsake seje, strategija v vrsticah', () => {
    const f = normalizeFocus({ wish: 'x', equipment: ['fitnes'], level: 2, sessions: [{ type: 'fitnes', part: 'zgornji', min: 60 }, { type: 'kolo', cardio: 'lahko', min: 90, what: 'stara vsebina' }] }, { now: NOW, by: 'claude' })!
    const ids = EXERCISES.filter(e => e.eq !== 'nic').slice(0, 4).map(e => e.id)
    const v = (id: string, k = 0) => ({ id, serije: 4, ponovitve: '6–8', odmor_s: 120, kg: k })
    const out = parseClaudeBuild({ seje: [{ i: 0, vaje: [...ids.map((id, k) => v(id, k ? 0 : 62.3)), v('izmisljena')], kaj: 'Potisk na klopi 4 × 6', zakaj: 'Moč zgoraj.' }, { i: 1, vaje: [], kaj: 'Lahka vožnja 90 min', zakaj: '' }, { i: 7, vaje: [], kaj: 'x', zakaj: 'x' }], strategija: 'Prva vrstica\n- druga vrstica\n– tretja' }, f)
    expect(out.sessions[0]!.ex).toEqual(ids)
    expect(out.sessions[0]!.plan![0]).toEqual({ id: ids[0], sets: 4, reps: '6–8', rest: 120, kg: 62.5 })
    expect(out.sessions[0]!.plan![1]!.kg).toBeNull()
    expect(out.sessions[0]!.what).toBe('Potisk na klopi 4 × 6')
    expect(out.sessions[1]!.what).toBe('Lahka vožnja 90 min')
    expect(out.strategy).toBe('– Prva vrstica\n– druga vrstica\n– tretja')
    // ena sama vaja je tudi trenerjeva odločitev
    const one = parseClaudeBuild({ seje: [{ i: 0, vaje: [v(ids[0]!)], kaj: '', zakaj: '' }], strategija: '' }, f)
    expect(one.sessions[0]!.ex).toEqual([ids[0]])
    expect(one.sessions[1]!.what).toBe('stara vsebina')
  })

  it('intervali brez zapisanih ponovitev ostanejo intervali (17. 10.: »Kolo — intervali 1 h« je bil 48 min enakomerno — »tole niso lih intervali«)', async () => {
    const { stepsFor, hasDrills } = await import('@/domain/training/workout')
    const raw = { ...RAW, seje: RAW.seje.map(x => (x.kardio === 'intervali' ? { ...x, kaj: 'Ključni intenzivni kardio trening tedna' } : x)) }
    const f = parseClaudeProposal(raw, { wish: ctx.wish, age: 34, now: NOW, offDays: [2], hidden: true })!.focus
    const ws = '2026-10-19'
    const week = buildFocusWeek({ profile: { ...profile, focus: f, cycleStart: ws } as Profile, activities: [], weekStart: ws, notBefore: ws })
    const iv = week.find(d => d.date === addDays(ws, 1) && d.kind === 'kolo')!
    expect(iv.title).toMatch(/intervali/)
    expect(iv.desc).toMatch(/^Ključni intenzivni kardio trening tedna\./)
    expect(hasDrills(iv.desc)).toBe(true)
    const st = stepsFor(iv, profile)
    expect(st.filter(x => x.kind === 'delo').length).toBeGreaterThanOrEqual(3)
    expect(st.some(x => x.kind === 'delo' && x.z === 'Z4')).toBe(true)
    // trenerjeve ponovitve ostanejo njegove (4 × 6 min)
    const f2 = parseClaudeProposal(RAW, { wish: ctx.wish, age: 34, now: NOW, offDays: [2], hidden: true })!.focus
    const w2 = buildFocusWeek({ profile: { ...profile, focus: f2, cycleStart: ws } as Profile, activities: [], weekStart: ws, notBefore: ws })
    const iv2 = w2.find(d => d.date === addDays(ws, 1) && d.kind === 'kolo')!
    expect(iv2.desc).toMatch(/^4 × 6 min hitro/)
    expect(iv2.desc).not.toMatch(/× 4 min hitro/)
  })
  it('že shranjen trd dan brez ponovitev: vodena vadba doda ponovitve; lahka vožnja ostane enakomerna', async () => {
    const { stepsFor } = await import('@/domain/training/workout')
    const base = { id: 'x', date: '2026-10-17', kind: 'kolo', title: 'Kolo — intervali 1 h', desc: 'Ključni intenzivni trening tedna. Lahko = utrip 149–164; hitro = utrip 170–180.', durationMin: 60, zone: 'Z4', tssTarget: 63, role: 'kljucna', target: null, kcalBurn: null, done: null } as never
    const p = { ...profile, lthr: 184, gear: { bikeOutdoor: true, trainer: false, noBike: false, power: false } } as unknown as Profile
    const st = stepsFor(base, p)
    const work = st.filter(x => x.kind === 'delo')
    expect(work.length).toBe(4)
    expect(work.every(x => x.sec === 4 * 60 && x.z === 'Z4')).toBe(true)
    expect(st.some(x => /intervali 1 h/.test(x.label))).toBe(false)
    expect(st.reduce((t, x) => t + x.sec, 0)).toBe(60 * 60)
    const run = stepsFor({ ...(base as object), kind: 'tek', title: 'Tek — intervali 45 min', durationMin: 45 } as never, p)
    expect(run.filter(x => x.kind === 'delo').length).toBeGreaterThanOrEqual(5)
    const easy = stepsFor({ ...(base as object), title: 'Kolo — lahko 1 h', zone: 'Z2', role: 'lahka' } as never, p)
    expect(easy.filter(x => x.kind === 'delo').length).toBe(1)
  })
  it('samo pražni utrip: cone iz praga, Z1 pod Z2 (prej »utrip do 155« za Z1 in »do 146« za Z2)', async () => {
    const { zoneText } = await import('@/domain/training/zones')
    const p = { sex: 'm', age: 21, lthr: 172 } as never
    expect(zoneText(p, 'Z1')).toBe('utrip pod 139')
    expect(zoneText(p, 'Z2')).toBe('utrip 139–153')
    expect(zoneText(p, 'Z4')).toBe('utrip 161–172')   // brez luknje za Z3 (154–160)
    expect(zoneText(p, 'Z3')).toBe('utrip 154–160')
  })

  it('začet teden: vadba z dnem se ne preseli na dan, ki ga nisi izbral (16. 10.: »torka nisem označil, pa mi ga da«)', () => {
    const f = parseClaudeProposal(RAW, { wish: ctx.wish, age: 34, now: NOW, offDays: [2] })!.focus
    const ws = '2026-10-19'   // ponedeljek; dogovor v torek — ponedeljkova vadba je zamujena
    const p = { ...profile, focus: f, cycleStart: ws } as Profile
    const full = buildFocusWeek({ profile: p, activities: [], weekStart: ws, notBefore: ws })
    const mid = buildFocusWeek({ profile: p, activities: [], weekStart: ws, notBefore: addDays(ws, 1) })
    for (let d = 1; d < 7; d++) {
      const a = full.filter(x => x.date === addDays(ws, d) && x.kind !== 'pocitek').map(x => x.title)
      const b = mid.filter(x => x.date === addDays(ws, d) && x.kind !== 'pocitek').map(x => x.title)
      expect(b, `dan ${d}`).toEqual(a)
    }
    // Blažev primer: fitnes pon in pet, kolo v nedeljo, dnevi niso označeni; dogovor v torek → torek ostane prost
    const g = normalizeFocus({ wish: 'pon pet fitnes, ned kolo', equipment: ['fitnes'], level: 2, sessions: [{ type: 'fitnes', part: 'celo', min: 60, day: 0 }, { type: 'fitnes', part: 'celo', min: 60, day: 4 }, { type: 'kolo', cardio: 'dolgo', min: 120, day: 6 }] }, { now: NOW, by: 'claude' })!
    const q = { ...profile, focus: g, cycleStart: ws } as Profile
    const tue = buildFocusWeek({ profile: q, activities: [], weekStart: ws, notBefore: addDays(ws, 1) })
    expect(tue.filter(x => x.kind !== 'pocitek').map(x => x.date)).toEqual([addDays(ws, 4), addDays(ws, 6)])
  })

  it('aplikacija sestavi točno trenerjev teden: dnevi in vsebina v načrtu', () => {
    const f = parseClaudeProposal(RAW, { wish: ctx.wish, age: 34, now: NOW, offDays: [2] })!.focus
    const ws = '2026-10-19'   // ponedeljek
    const p = { ...profile, focus: f, cycleStart: ws } as Profile
    const week = buildFocusWeek({ profile: p, activities: [], weekStart: ws, notBefore: ws })
    const on = (d: number) => week.filter(x => x.date === addDays(ws, d) && x.kind !== 'pocitek')
    expect(on(0).map(x => x.kind)).toEqual(['moc'])
    expect(on(0)[0]!.tail).toMatchObject({ kind: 'kolo', durationMin: 20 })   // točno trenerjevih 20 min
    expect(on(0)[0]!.desc).toContain('Potisk in poteg')
    expect(on(1)[0]!.desc).toContain('4 × 6 min hitro')
    expect(on(2)).toHaveLength(0)
    expect(on(3)[0]!.kind).toBe('moc')
    expect(on(5)[0]!.desc).toContain('Dolga lahka vožnja')
    expect(on(6)).toHaveLength(0)
  })

  it('vaje točno od trenerja (serije, ponovitve, odmor, kg) in obseg tednov iz njegovega bloka', () => {
    const base = parseClaudeProposal({ ...RAW, obseg_4_tednov: [1, 1.2, 1.3, 0.5] }, { wish: ctx.wish, age: 34, now: NOW, offDays: [2] })!.focus
    const gym = EXERCISES.filter(e => e.eq === 'fitnes').slice(0, 2)
    const f = parseClaudeBuild({ seje: [{ i: 0, vaje: gym.map((e, k) => ({ id: e.id, serije: 5 + k, ponovitve: '5', odmor_s: 180, kg: e.kg ? 100 : 0 })), kaj: 'Težko', zakaj: '' }], strategija: '' }, base)
    const ws = '2026-10-19'
    const p = { ...profile, focus: f, cycleStart: ws } as Profile
    const mon = (w: number) => buildFocusWeek({ profile: p, activities: [], weekStart: addDays(ws, 7 * w), notBefore: addDays(ws, 7 * w) }).find(x => x.date === addDays(ws, 7 * w))!
    expect(mon(0).exercises!.map(e => [e.name, e.sets, e.reps, e.rest])).toEqual(gym.map((e, k) => [e.name, 5 + k, '5', 180]))
    expect(mon(0).exercises![0]!.kg ?? null).toBe(gym[0]!.kg ? 100 : null)
    // lažji teden (0,5): serija manj; kardio × obseg
    expect(mon(3).exercises!.map(e => e.sets)).toEqual(gym.map((_, k) => 4 + k))
    const sat = (w: number) => buildFocusWeek({ profile: p, activities: [], weekStart: addDays(ws, 7 * w), notBefore: addDays(ws, 7 * w) }).find(x => x.date === addDays(ws, 7 * w + 5))!
    expect([0, 1, 2, 3].map(w => sat(w).durationMin)).toEqual([150, 180, 195, 75])
  })
})

describe('privolitev za AI', () => {
  it('Gemini: vsaka privolitev; Claude in glas: samo besedilo različice 2 (ne po uri naprave)', () => {
    expect(CONSENT_V).toBe(2)
    expect(hasConsent({ aiConsentAt: null, aiConsentV: 2 })).toBe(false)
    expect(hasConsent({ aiConsentAt: '2026-09-01T08:00:00.000Z' })).toBe(true)
    expect(hasConsent({ aiConsentAt: '2026-09-01T08:00:00.000Z' }, CONSENT_V)).toBe(false)
    expect(hasConsent({ aiConsentAt: '2026-11-01T08:00:00.000Z' }, CONSENT_V)).toBe(false)   // stara aplikacija po izidu: brez različice
    expect(hasConsent({ aiConsentAt: '2020-01-01T08:00:00.000Z', aiConsentV: 2 }, CONSENT_V)).toBe(true)   // ura naprave zaostaja: velja
  })
})

describe('Čakanje na trenerja — nasveti in figure', () => {
  it('športi iz besed (brez lažnih zadetkov: koleno ≠ kolo, teden ≠ tek)', async () => {
    const { sportsIn } = await import('@/domain/focus/tips')
    expect(sportsIn('Ob vikendih kolo, med tednom tečem 10–20 min')).toEqual(expect.arrayContaining(['kolo', 'tek']))
    expect(sportsIn('Boli me koleno, trikrat na teden fitnes')).toEqual(['moc'])
    expect(sportsIn('hoja v hribe in kolesarjenje')).toEqual(expect.arrayContaining(['kolo', 'hribi']))
  })
  it('nasveti: njegovi športi najprej, brez podvajanj, brez kaloričnih številk', async () => {
    const { tipsFor } = await import('@/domain/focus/tips')
    const t = tipsFor(['kolo'], 1)
    expect(new Set(t).size).toBe(t.length)
    expect(t.slice(0, 2).every(x => /kol[eo]s?|vožnj|kadenc|intervali/i.test(x))).toBe(true)
    expect(t.some(x => /kcal|kalorij/i.test(x))).toBe(false)
  })
  it('figure: kolo, tek, moč v fitnesu ali doma', async () => {
    const { figsFor } = await import('@/domain/focus/tips')
    expect(figsFor(['kolo', 'moc'], 'fitnes in kolo').map(f => f.label)).toEqual(['Kolo', 'Počep z utežjo'])
    expect(figsFor(['moc'], 'vadba doma').map(f => f.label)).toEqual(['Sklece'])
  })
})

describe('Čas razmisleka (zgodovina na napravi)', () => {
  it('srednji in zadnji čas, največ 5 zapisov', async () => {
    const { claudeTook, claudeTypical, claudeLast } = await import('@/domain/ai/client')
    localStorage.removeItem('formai.claude-cas')
    expect(claudeTypical('predlog', 'high')).toBeNull()
    for (const s of [50, 80, 60, 400, 70, 65]) claudeTook('predlog', 'high', s)
    expect(claudeLast('predlog', 'high')).toBe(65)
    expect(claudeTypical('predlog', 'high')).toBe(70)   // [80, 60, 400, 70, 65] → srednji 70
    expect(claudeTypical('sestava', 'high')).toBeNull()
  })
})

describe('Na hitro, kaj danes (16. 10.)', () => {
  it('bistvo opisa: prvi stavek, dolgo skrajšano; naslov brez pripetega kardia', async () => {
    const { gist, hasMore, baseTitle } = await import('@/ui/SessBits')
    expect(gist('Potisk na klopi, veslanje, ramena: 4 × 6–10. 8–10 min ogrevanja, nato prva vaja.')).toBe('Potisk na klopi, veslanje, ramena: 4 × 6–10.')
    expect(hasMore('Potisk na klopi, veslanje, ramena: 4 × 6–10. 8–10 min ogrevanja, nato prva vaja.')).toBe(true)
    expect(hasMore('Dolga lahka vožnja zunaj.')).toBe(false)
    expect(gist('a '.repeat(80)).length).toBeLessThanOrEqual(92)
    expect(baseTitle({ title: 'Fitnes — zgornji del + kolo 33 min', durationMin: 93, tail: { kind: 'kolo', title: 'Kolo — lahko', desc: '', durationMin: 33 } })).toBe('Fitnes — zgornji del')
    expect(baseTitle({ title: 'Kolo — dolgo', durationMin: 60, tail: null })).toBe('Kolo — dolgo')
  })
  it('naslov brez trajanja, ki je že v ploščici; drugačno število ostane', async () => {
    const { baseTitle } = await import('@/ui/SessBits')
    const { titleNoDur } = await import('@/domain/training/load')
    expect(baseTitle({ title: 'Kolo — daljša vožnja 2 h 30 min', durationMin: 150, tail: null })).toBe('Kolo — daljša vožnja')
    expect(titleNoDur('Kolo — intervali 1 h 06 min', 66)).toBe('Kolo — intervali')
    expect(titleNoDur('Hribi — 3 h', 180)).toBe('Hribi')
    expect(titleNoDur('Tek — lahko 45 min', 45)).toBe('Tek — lahko')
    expect(titleNoDur('Fitnes — zgornji del + kolo 33 min', 93)).toBe('Fitnes — zgornji del + kolo 33 min')
    expect(titleNoDur('Kolo — 5 × 4 min hitro', 60)).toBe('Kolo — 5 × 4 min hitro')
  })
  it('enakomerni korak vodene vadbe: ime brez trajanja celega treninga', async () => {
    const { stepsFor } = await import('@/domain/training/workout')
    const day = { id: 'x', date: '2026-10-17', kind: 'kolo', title: 'Kolo — daljša vožnja 2 h 30 min', desc: 'Dolga lahka vožnja zunaj.', durationMin: 150, zone: 'Z2', tssTarget: 105, role: 'dolga', target: null, kcalBurn: null, done: null } as never
    const st = stepsFor(day, { sex: 'M', age: 34, heightCm: 182, weightKg: 84 } as never)
    const work = st.find(s => s.kind === 'delo')!
    expect(work.label).toBe('Kolo — daljša vožnja')
    expect(st.map(s => s.label).join(' ')).not.toMatch(/2 h 30 min/)
  })
})

describe('20 izboljšav (16. 10.)', () => {
  it('strategija trenerja: njegova številka kalorij zamenjana s ciljem dneva (aplikacija računa z varovalkami)', async () => {
    const { strategyLines } = await import('@/domain/focus/model')
    const l = strategyLines('– Teden: dve moči in kardio.\n– Prehrana: ~2300 kcal.\n– Jej okoli 2.300–2.500 kcal na dan in 160 g beljakovin.\n– Spanec 7–8 h.')
    expect(l).toHaveLength(4)
    expect(l.join(' ')).not.toMatch(/\d\s*kcal/)
    expect(l[1]).toBe('Prehrana: kalorije po dnevu (v Prehrani; na dan treninga več).')
    expect(l[2]).toContain('160 g beljakovin')
    expect(l[3]).toBe('Spanec 7–8 h.')
  })
  it('pripravljenost brez vadb, jutranjega vnosa in ure ni izmišljena (prej »60«)', async () => {
    const { localAdvice } = await import('@/domain/coach/local')
    const { readinessOf } = await import('@/domain/readiness')
    expect(readinessOf(null, null, null)).toBeNull()
    // teža iz sestave načrta je zapis današnjega dne, a ne pove nič o počutju
    expect(readinessOf(null, { date: '2026-10-17', weightKg: 84 } as never, null)).toBeNull()
    expect(readinessOf(null, { date: '2026-10-17', sleepH: 5 } as never, null)!.score).toBeLessThan(60)
    const t = localAdvice({ profile: { sex: 'M', age: 34, heightCm: 182, weightKg: 84 } as never, plan: [{ id: 'a', date: '2026-10-17', kind: 'kolo', title: 'Kolo — lahko 60 min', desc: 'Lahko.', durationMin: 60, zone: 'Z2', role: 'lahka', target: null, kcalBurn: null, done: null, source: 'rules', createdAt: '', updatedAt: '' }], activities: [], checkins: [], checkinToday: { date: '2026-10-17', weightKg: 84 }, wellness: [], wellnessOn: false, mealsToday: [], recentMeals: [], today: '2026-10-17', weather: null } as never)
    expect(t).not.toMatch(/pripravljenost/i)
  })
})
