// v3.50 UVOD (zasloni) — osnutek hrani vprašanja, odgovore in predlog (F04), »Nazaj« in »Naprej« obdržita odgovore (F05),
// pripomba brez spremembe (F42), števec znakov (F43), »Kakšen tip si« z razlago (F44), gradnja brez moči brez zemljevida
// mišic (F45), prehranske želje v dogovoru (H01), tekačica s tekmo (H02), dve tekmi, FTP in 15 h (H20, H04, H05), drug
// šport (H11), prvi teden kolesarja (H15), preproste besede (H30), prva teža (H32), brez tekme (H34).
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, afterEach, beforeEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), nav: [] as string[], route: { name: 'uvod', params: {} as Record<string, string> } }))
vi.mock('@/state/store', async () => {
  const { vi: v } = await import('vitest')
  const base: Record<string | symbol, unknown> = {
    useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
    getState: () => S.state,
    routePace: () => ({ k: 1, adj: { n: 0, adj: 1 } }),
  }
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' || typeof k === 'symbol' ? undefined : (t[k] = v.fn(async () => {}))), has: (_t, k) => k !== 'then' })
})
vi.mock('@/app/router', () => ({ navigate: (to: string) => { S.nav.push(to) }, useRoute: () => S.route }))
vi.mock('@/app/landing', () => ({ markApp: () => undefined }))
vi.mock('@/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '@/state/store'
import { Sestavi, readDraft, firstBikeWeek, lenNote } from '@/screens/Sestavi'
import { BuildShow, cardioNote } from '@/ui/BuildShow'
import { Vadba } from '@/screens/Vadba'
import { Plan } from '@/screens/Plan'
import { Guide } from '@/ui/Guide'
import { normalizeFocus } from '@/domain/focus/model'
import type { Focus, PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const MON = '2026-10-19', TUE = '2026-10-20'
const NOW = `${MON}T08:00:00.000Z`
const NEW = { sex: 'm', age: 30, heightCm: 180, weightKg: 75, ftp: null, maxHr: null, restHr: null, gear: { bikeOutdoor: false, trainer: false, noBike: false }, strength: { on: false, equipment: 'none' }, onboardingDone: false, createdAt: NOW, updatedAt: NOW } as unknown as Profile

let div: HTMLDivElement | null = null, root: Root | null = null
async function render(el: ReactElement): Promise<HTMLDivElement> {
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root!.render(el) })
  return div
}
async function unmount() { if (root) await act(async () => root!.unmount()); div?.remove(); root = null; div = null }
afterEach(async () => { await unmount(); vi.useRealTimers(); document.body.innerHTML = '' })
const sp = (x: string) => x.replace(/[    ⁠]/g, ' ')
const txt = (d: Element = document.body) => sp(d.textContent || '')
const btn = (label: string | RegExp, r: ParentNode = document) => [...r.querySelectorAll('button')].find(b => (typeof label === 'string' ? sp(b.textContent || '').trim() === label || b.getAttribute('aria-label') === label : label.test(sp(b.textContent || ''))))
async function click(label: string | RegExp) { const b = btn(label); if (!b) throw new Error(`ni gumba: ${label}`); await act(async () => { b.click() }) }
async function type(el: HTMLTextAreaElement | HTMLInputElement, v: string) {
  const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype
  await act(async () => { Object.getOwnPropertyDescriptor(proto, 'value')!.set!.call(el, v); el.dispatchEvent(new Event('input', { bubbles: true })) })
}
const state = (o: Record<string, unknown> = {}) => ({ ready: true, today: MON, profile: NEW, activities: [], plan: [], checkins: [], weather: null, user: null, changes: [], settings: { lang: 'sl', intervals: null, guideSeen: true }, sync: { state: 'off' }, mealsToday: [], recentMeals: [], routeLib: null, routesBusy: false, toast: null, toasts: [], ...o })
const agreeCalls = () => (store.applyAgreement as unknown as ReturnType<typeof vi.fn>).mock.calls
beforeEach(() => {
  S.state = state(); S.nav = []; S.route = { name: 'uvod', params: {} }; sessionStorage.clear(); localStorage.clear()
  window.scrollTo = vi.fn() as unknown as typeof window.scrollTo
  Element.prototype.scrollIntoView = vi.fn()
  ;(store.applyAgreement as unknown as ReturnType<typeof vi.fn>).mockClear?.()
})
/** »Dogovorjeno« → predstava → »Preskoči« → shranjeno (kot v3.49 C23) */
async function agree() {
  vi.useFakeTimers()
  await click('Dogovorjeno — sestavi moj načrt')
  await act(async () => { await vi.advanceTimersByTimeAsync(200) })
  await act(async () => { await vi.advanceTimersByTimeAsync(10_500) })
  await click('Preskoči ›')
  await act(async () => { await vi.advanceTimersByTimeAsync(3000) })
  return agreeCalls()[0]!
}
const days = async (...ds: string[]) => { for (const d of ds) await click(`${d}: nimam časa`) }

/* ---------- F04, F05: osnutek poteka in »Nazaj« ---------- */
describe('F04 osvežitev sredi vprašanj ali dogovora', () => {
  it('vprašanja in dani odgovori ostanejo; tudi dogovor', async () => {
    const d = await render(<Sestavi />)
    await click('Tek'); await click('Boljša kondicija')
    await days('ponedeljek', 'sreda', 'petek')
    await click('Raje brez prijave (vprašalnik brez AI)')
    expect(d.querySelector('h1')!.textContent).toBe('Še nekaj vprašanj')
    await click('3')
    expect([...d.querySelectorAll('.q-ans')].map(x => x.textContent)).toEqual(['3'])
    expect(readDraft(false)?.flow?.ans).toMatchObject({ dni: { picks: ['3'] } })
    await unmount()
    const d2 = await render(<Sestavi />)
    expect(d2.querySelector('h1')!.textContent).toBe('Še nekaj vprašanj')
    expect([...d2.querySelectorAll('.q-ans')].map(x => x.textContent)).toEqual(['3'])
    // do konca → dogovor; osvežitev → spet dogovor (brez novih vprašanj)
    while (!txt(d2).includes('Najin dogovor')) {
      const cur = d2.querySelector('.q-turn')
      if (!cur) break
      const chip = cur.querySelector('.q-opts button') as HTMLButtonElement
      await act(async () => { chip.click() })
      const next = btn('Naprej ›', cur)
      if (next) await act(async () => { next.click() })
    }
    expect(d2.querySelector('h1')!.textContent).toBe('Najin dogovor')
    await unmount()
    const d3 = await render(<Sestavi />)
    expect(d3.querySelector('h1')!.textContent).toBe('Najin dogovor')
    expect(txt(d3)).toContain('Dogovorjeno — sestavi moj načrt')
  })
  it('pokvarjen osnutek poteka: samo 1. korak', () => {
    localStorage.setItem('formai.uvod', JSON.stringify({ v: 1, again: false, at: Date.now(), picks: {}, text: 'x', avail: [1], trainTime: null, push: 'zmerno', main: 'oboje', b: { sex: 'm', age: '', height: '', weight: '' }, flow: { step: 'dogovor', prop: { focus: {} } } }))
    expect(readDraft(false)).toMatchObject({ text: 'x', flow: null })
  })
})

describe('F05 »Nazaj« na 1. korak in spet »Naprej«', () => {
  it('ista želja in dnevi: odgovori ostanejo; drugi dnevi: ostanejo odgovori na vprašanja, ki so enaka', async () => {
    const d = await render(<Sestavi />)
    await click('Tek'); await click('Boljša kondicija')
    await days('ponedeljek', 'sreda', 'petek')
    await click('Raje brez prijave (vprašalnik brez AI)')
    await click('3')
    await click('45 min')
    expect(d.querySelectorAll('.q-ans').length).toBe(2)
    await click('Nazaj')
    expect(d.querySelector('h1')!.textContent).toBe('Kaj si želiš?')
    await click('Raje brez prijave (vprašalnik brez AI)')
    expect(d.querySelector('h1')!.textContent).toBe('Še nekaj vprašanj')
    expect([...d.querySelectorAll('.q-ans')].map(x => x.textContent)).toEqual(['3', '45 min'])
    // drug dan: vprašanje o dnevih je drugo (»od teh 4 dni«), čas na vadbo ostane
    await click('Nazaj')
    await days('nedelja')
    await click('Naprej')
    expect(txt(d)).toContain('Koliko od teh 4 dni bi res treniral?')
    await click('3')
    expect([...d.querySelectorAll('.q-ans')].map(x => x.textContent)).toEqual(['3', '45 min'])
  })
})

/* ---------- F42, F43, F44 ---------- */
describe('F42 pripomba, ki ne spremeni ničesar', () => {
  it('»raje 2 dni« pri 2 dneh: »Tako že je — teden ima 2 dneva.«', async () => {
    const d = await render(<Sestavi />)
    await click('Tek')
    await days('ponedeljek', 'četrtek')
    await click('Raje brez prijave (vprašalnik brez AI)')
    for (let g = 0; g < 8 && !txt(d).includes('Najin dogovor'); g++) {
      const cur = d.querySelector('.q-turn')!
      await act(async () => { (cur.querySelector('.q-opts button') as HTMLButtonElement).click() })
      const next = btn('Naprej ›', cur)
      if (next) await act(async () => { next.click() })
    }
    await type(d.querySelector('#sest-say') as HTMLTextAreaElement, 'raje 2 dni')
    await click('Pošlji trenerju')
    const talk = [...d.querySelectorAll('.talk:not(.me)')].map(x => txt(x))
    expect(talk[talk.length - 1]).toMatch(/Tako že je — teden ima 2 dneva\..*Če želiš kaj drugega, povej\.$/)
  })
})

describe('F43 + F44 prvi korak', () => {
  it('števec od 80 % dolžine; »Kakšen tip si« z razlago', async () => {
    expect(lenNote(500, 700)).toBe('')
    expect(lenNote(560, 700)).toBe('560 / 700')
    expect(lenNote(700, 700)).toBe('700 / 700 — več ne gre')
    const d = await render(<Sestavi />)
    const w = d.querySelector('#sest-wish') as HTMLTextAreaElement
    await type(w, 'a'.repeat(500))
    expect(d.querySelector('#sest-wish-len')!.textContent).toBe('')
    await type(w, 'a'.repeat(612))
    expect(d.querySelector('#sest-wish-len')!.textContent).toBe('612 / 700')
    expect(w.getAttribute('aria-describedby')).toBe('sest-wish-len')
    expect(txt(d)).toContain('Kakšen tip si (koliko te sme trener naložiti):')
  })
})

/* ---------- F45 ---------- */
describe('F45 gradnja: dogovor brez moči', () => {
  const basics = { sex: 'm' as const, age: 30, heightCm: 180, weightKg: 75, avail: [0, 2, 4], trainTime: null, push: 'zmerno' as const, main: 'kardio' as const }
  it('tekač: brez zemljevida mišic in »Uravnoteženo celo telo« — »Noge in srce s tekom«', async () => {
    expect(cardioNote([{ type: 'tek' }, { type: 'kolo' }])).toBe('Noge in srce s tekom in kolesom')
    const f = normalizeFocus({ wish: 'Rad delam: tek.', sessions: [{ type: 'tek', cardio: 'lahko', min: 30 }, { type: 'tek', cardio: 'lahko', min: 30 }], aims: ['kondicija'] }, { by: 'pravila' })!
    vi.useFakeTimers()
    await render(<BuildShow focus={f} basics={basics} ai={false} again onSave={async () => {}} onDone={() => {}} />)
    await act(async () => { await vi.advanceTimersByTimeAsync(300) })
    expect(txt()).toContain('Noge in srce s tekom')
    expect(txt()).not.toContain('Uravnoteženo celo telo')
    expect(document.querySelector('.bs-body')).toBeNull()
  })
  it('kontrola: z močjo ostane zemljevid mišic', async () => {
    const f = normalizeFocus({ wish: 'Rad delam: fitnes, tek.', sessions: [{ type: 'fitnes', part: 'celo', min: 50 }, { type: 'tek', cardio: 'lahko', min: 30 }], aims: ['kondicija'] }, { by: 'pravila' })!
    vi.useFakeTimers()
    await render(<BuildShow focus={f} basics={basics} ai={false} again onSave={async () => {}} onDone={() => {}} />)
    await act(async () => { await vi.advanceTimersByTimeAsync(300) })
    expect(txt()).toContain('Uravnoteženo celo telo · noge in srce s kardiem')
    expect(document.querySelector('.bs-body')).toBeTruthy()
  })
})

/* ---------- H02 + H01: tekačica s polmaratonom, veganka ---------- */
describe('H02 + H01 tekačica s tekmo z datumom (persona »vegan«)', () => {
  it('tekma vprašana, v dogovoru vidna in shranjena v dogovor; prehrana »vegan« v dogovoru', async () => {
    const d = await render(<Sestavi />)
    for (const c of ['Hitrejši in vzdržljivejši', 'Pripravljen na tekmo', 'Tek', 'Redno, več let']) await click(c)
    await click('Polmaraton ali več')
    await type(d.querySelector('#sest-wish') as HTMLTextAreaElement, 'Sem vegan. Ljubljanski maraton — polmaraton 25. 10. 2026. Tečem približno 35 km na teden.')
    await days('torek', 'četrtek', 'sobota', 'nedelja')
    await click('Raje brez prijave (vprašalnik brez AI)')
    expect(txt(d)).toContain('Tvoja tekma: Ljubljanski maraton — polmaraton · 25. 10. 2026. Je prav?')
    await click('Da'); await click('4'); await click('1 h'); await click('Ne'); await click('Naprej ›')
    expect(txt(d)).toContain('Tekma: Ljubljanski maraton — polmaraton · 25. 10. 2026 — teden tekme je lažji, na dan tekme je tekma, dan po njej počitek.')
    expect(txt(d)).toContain('Prehrana upošteva: vegan — recepti bodo po tem.')
    const [f] = await agree()
    expect((f as Focus).race).toEqual({ name: 'Ljubljanski maraton — polmaraton', date: '2026-10-25', distanceKm: null, sport: 'tek' })
  })
})

/* ---------- H20 + H04 + H05 + H15: U23 ---------- */
describe('H20 + H04 + H05 + H15 tekmovalec U23 (dve tekmi, FTP 320 W, 15 h)', () => {
  it('obe tekmi, FTP in 15 h gredo v profil; »Ta teden«; počitek iz pravega tedna, ne »ob sobotah«', async () => {
    S.state = state({ today: TUE })
    const d = await render(<Sestavi />)
    for (const c of ['Hitrejši in vzdržljivejši', 'Pripravljen na tekmo', 'Kolo', 'Redno, več let']) await click(c)
    await click('Zunaj po cesti'); await click('Merilnik moči')
    await type(d.querySelector('#sest-wish') as HTMLTextAreaElement, 'Tekmujem v U23. Glavna tekma A: VN Kranj 2. 5. 2027. Tekma B: Kronometer Vodice 18. 4. 2027. Treniram 15 ur na teden. FTP 320 W.')
    await click('vsak dan')
    await click('Raje brez prijave (vprašalnik brez AI)')
    expect(txt(d)).toContain('Tvoji tekmi: VN Kranj · 2. 5. 2027 (cilj A), Kronometer Vodice · 18. 4. 2027 (B). Je prav?')
    expect(txt(d)).not.toContain('Kakšen je tvoj FTP')
    await click('Da'); await click('6'); await click('Ne'); await click('Naprej ›')
    expect(txt(d)).toContain('Do tekme: VN Kranj')
    expect(txt(d)).toMatch(/~15 h na teden/)
    expect(txt(d)).toMatch(/Ta teden · /)
    expect(txt(d)).toMatch(/Prvi trije tedni so lahki \(~\d+(,5)?–\d+(,5)? h\), nato ~15 h na teden\./)
    const [f, basics] = await agree()
    expect(basics).toMatchObject({ event: { name: 'VN Kranj', date: '2027-05-02' }, ftp: 320, ftpDate: TUE })
    expect(basics.races).toEqual([expect.objectContaining({ name: 'Kronometer Vodice', date: '2027-04-18', prio: 'B' })])
    const sum = (f as Focus).sessions.reduce((t, s) => t + s.min, 0)
    expect(Math.abs(sum - 900)).toBeLessThanOrEqual(30)
    const why = ((f as Focus).why || []).join(' ')
    expect(why).toMatch(/^Počitek ob /)
    expect(why).not.toContain('ob sobotah')
    expect(why).not.toMatch(/Težki dnevi|Trajanja sem umeril/)
  })
  it('H15 prvi teden: od ponedeljka do srede ta teden, od četrtka naslednji', () => {
    const f = normalizeFocus({ wish: 'Rad delam: kolo. Cilj: pripravljen na tekmo.', sessions: [{ type: 'kolo', cardio: 'lahko', min: 90 }, { type: 'kolo', cardio: 'dolgo', min: 180 }, { type: 'kolo', cardio: 'intervali', min: 75 }], aims: ['tekma'], level: 3 }, { by: 'pravila' })!
    expect(firstBikeWeek(f, NEW, [], TUE).weekStart).toBe(MON)
    expect(firstBikeWeek(f, NEW, [], '2026-10-22').weekStart).toBe('2026-10-26')
    expect(firstBikeWeek(f, NEW, [], '2026-10-17').weekStart).toBe(MON)
    expect(firstBikeWeek(f, NEW, [], TUE).days.find(x => x.date === MON)!.kind).toBe('pocitek')
  })
})

/* ---------- H11 ---------- */
describe('H11 drug šport v 1. koraku', () => {
  it('»Drug šport« odpre polje; dnevi nogometa niso dnevi za vadbo', async () => {
    const d = await render(<Sestavi />)
    expect(d.querySelector('#sest-other')).toBeNull()
    await click('Fitnes'); await click('Drug šport'); await click('Več mišic in moči')
    await type(d.querySelector('#sest-other') as HTMLInputElement, 'nogomet tor in čet, tekma sob')
    await click('vsak dan')
    await click('Raje brez prijave (vprašalnik brez AI)')
    expect(readDraft(false)?.other).toBe('nogomet tor in čet, tekma sob')
    for (let g = 0; g < 9 && !txt(d).includes('Najin dogovor'); g++) {
      const cur = d.querySelector('.q-turn')!
      await act(async () => { (cur.querySelector('.q-opts button') as HTMLButtonElement).click() })
      const next = btn('Naprej ›', cur)
      if (next) await act(async () => { next.click() })
    }
    expect(txt(d)).toContain('Ob torkih, četrtkih in sobotah ni vadbe.')
  })
})

/* ---------- H30, H32: Vadba in Plan ---------- */
const run = (o: Partial<PlanDay> = {}): PlanDay => ({ id: 'd1', date: MON, kind: 'tek', title: 'Tek in hoja — 8 × 1 min teka', desc: 'Izmenično.', durationMin: 30, zone: 'Z2', role: 'lahka', tssTarget: 18, source: 'rules', createdAt: NOW, updatedAt: NOW, ...o } as PlanDay)
const beginner = (level: 1 | 3, extra: Partial<Profile> = {}) => ({ ...NEW, onboardingDone: true, focus: normalizeFocus({ wish: 'Rad delam: tek.', level, sessions: [{ type: 'tek', cardio: 'lahko', min: 30 }, { type: 'tek', cardio: 'lahko', min: 30 }], aims: ['kondicija'] }, { by: 'pravila' }), ...extra } as Profile)
describe('H30 začetnik brez ure: brez TSS in »(Z2)«', () => {
  it('Vadba: brez ploščice TSS pri začetniku; izkušen jo ima', async () => {
    S.route = { name: 'vadba', params: { id: 'd1' } }
    S.state = state({ profile: beginner(1), plan: [run()] })
    const d = await render(<Vadba />)
    expect([...d.querySelectorAll('.kpi small')].map(x => x.textContent)).not.toContain('TSS')
    await unmount()
    S.state = state({ profile: beginner(3), plan: [run()] })
    const d2 = await render(<Vadba />)
    expect([...d2.querySelectorAll('.kpi small')].map(x => x.textContent)).toContain('TSS')
  })
  it('Plan: »30 min · lahko« brez »(Z2)«; »Hitra hoja« je HOJA', async () => {
    S.route = { name: 'plan', params: {} }
    S.state = state({ profile: beginner(1), plan: [run(), run({ id: 'd2', date: '2026-10-21', kind: 'pohod', title: 'Hitra hoja — 1 h', durationMin: 60, tssTarget: 30 })] })
    const d = await render(<Plan />)
    expect(txt(d)).toContain('30 min · lahko')
    expect(txt(d)).not.toContain('lahko (Z2)')
    expect(txt(d)).not.toMatch(/HRIBI|Hribi ·/)
  })
})

describe('H32 prva seja s palico: namig za prvo težo', () => {
  it('KG prazen → »Prvič: začni s prazno palico«', async () => {
    vi.useFakeTimers(); vi.setSystemTime(new Date(`${MON}T10:00:00`))
    const gym = run({ id: 'g1', kind: 'moc', title: 'Fitnes — celo telo', desc: 'Fitnes.', durationMin: 50, zone: null, role: 'moc', tssTarget: 0, exercises: [{ name: 'Počep s palico', sets: 3, reps: '6–10' }] })
    S.route = { name: 'vadba', params: { id: 'g1' } }
    S.state = state({ profile: { ...beginner(1), strength: { on: true, equipment: 'gym' } }, plan: [gym] })
    const d = await render(<Vadba />)
    await act(async () => { btn(/^Začni trening$/)!.click() })
    for (let g = 0; g < 4 && !d.querySelector('input[aria-label="Kilogrami"]'); g++) await act(async () => { (document.querySelector('button[aria-label="Preskoči korak"]') as HTMLButtonElement).click() })
    expect(d.querySelector('input[aria-label="Kilogrami"]')).toBeTruthy()
    expect(txt(d)).toContain('Prvič: začni s prazno palico (običajno 20 kg). Ko narediš vse ponovitve lepo, naslednjič dodaj 2,5 kg.')
  })
})

/* ---------- H34: kolesar brez tekme ---------- */
describe('H34 »nimam tekme«: brez poziva k dirki v Planu in vodniku', () => {
  const bike = (wish: string) => ({ ...NEW, onboardingDone: true, goal: 'hitrejsi', event: null, races: [], gear: { bikeOutdoor: true, trainer: false, noBike: false }, hoursPerWeek: 5, level: 3,
    focus: { ...normalizeFocus({ wish, level: 3, sessions: [{ type: 'kolo', cardio: 'lahko', min: 90 }, { type: 'kolo', cardio: 'dolgo', min: 150 }], aims: ['tekma', 'zdravje'] }, { by: 'pravila' })!, mode: 'kolo' as const } } as Profile)
  it('Plan: »Brez tekme načrt teče …«, ne »Nastavi dirko«', async () => {
    S.route = { name: 'plan', params: {} }
    S.state = state({ profile: bike('Rad delam: kolo. Nimam tekme, hočem ostati zdrav.'), plan: [run({ kind: 'kolo', title: 'Z2 vzdržljivost', durationMin: 90 })] })
    const d = await render(<Plan />)
    expect(txt(d)).toContain('Brez tekme načrt teče v 12-tedenskih ciklih za formo in zdravje. Cilj z datumom lahko dodaš kadar koli.')
    expect(txt(d)).not.toContain('Nastavi dirko')
  })
  it('vodnik: brez »tekma ~85 g/h«; kolesar s tekmo jo ima', async () => {
    for (const [wish, has] of [['Rad delam: kolo. Nimam tekme, hočem ostati zdrav.', false], ['Rad delam: kolo. Rad bi dirkal.', true]] as const) {
      S.state = state({ profile: { ...bike(wish), focus: { ...bike(wish).focus!, aims: has ? ['tekma'] : ['tekma', 'zdravje'] } }, plan: [] })
      await render(<Guide open onClose={() => {}} />)
      await click('Naprej'); await click('Naprej')
      expect(txt().includes('tekma ~85 g/h'), wish).toBe(has)
      expect(txt()).toContain('trdi treningi nad 75 min ~70 g/h')
      await unmount(); document.body.innerHTML = ''
    }
  })
})
