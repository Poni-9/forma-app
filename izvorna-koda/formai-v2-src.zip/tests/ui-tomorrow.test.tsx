// Jutri v eni vrstici: kaj te čaka, vreme; zvečer ali po opravljenem treningu v barvi vrste; brez načrta za jutri ni kartice.
import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const nav = vi.hoisted(() => ({ calls: [] as unknown[] }))
vi.mock('@/app/router', () => ({ navigate: (...a: unknown[]) => { nav.calls.push(a) } }))
import { TomorrowCard } from '@/ui/TomorrowCard'
import type { PlanDay } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
let div: HTMLDivElement, root: Root
const render = async (el: React.ReactNode) => { await act(async () => { root.render(el) }) }
beforeEach(() => { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div) })
afterEach(async () => { await act(async () => root.unmount()); div.remove() })

const NOW = '2026-10-02T10:00:00.000Z'
const d = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: 'p' + date + (o.kind || 'kolo'), date, kind: 'kolo', title: 'Dolga Z2 po hribih', desc: '', durationMin: 140, zone: 'Z2', tssTarget: 99, role: 'dolga', source: 'rules', createdAt: NOW, updatedAt: NOW, ...o })

describe('TomorrowCard', () => {
  it('kolo + moč jutri: naslov, trajanje, TSS, dodatna moč; dopoldne brez poudarka; tap odpre dan v Planu', async () => {
    await render(<TomorrowCard plan={[d('2026-10-03'), d('2026-10-03', { kind: 'moc', title: 'Moč — jedro', durationMin: 25, tssTarget: 15 })]} today="2026-10-02" hour={9} />)
    expect(div.textContent).toContain('Jutri · sobota')
    expect(div.textContent).toContain('Dolga Z2 po hribih')
    expect(div.textContent).toMatch(/2 h 20 min · 99 TSS · \+ moč 25 min/)
    expect(div.querySelector('.tomorrow.evening')).toBeNull()
    await act(async () => { (div.querySelector('button') as HTMLButtonElement).click() })
    expect(nav.calls.at(-1)).toEqual(['plan', { dan: '2026-10-03' }])
  })
  it('zvečer ali po opravljenem današnjem treningu je poudarjena; počitek je »dan brez treninga«', async () => {
    await render(<TomorrowCard plan={[d('2026-10-03')]} today="2026-10-02" hour={19} />)
    expect(div.querySelector('.tomorrow.evening')).toBeTruthy()
    await render(<TomorrowCard plan={[d('2026-10-03', { kind: 'pocitek', title: 'Počitek', durationMin: 0, tssTarget: null, role: null })]} today="2026-10-02" hour={9} todayDone />)
    expect(div.querySelector('.tomorrow.evening')).toBeTruthy()
    expect(div.textContent).toContain('Počitek'); expect(div.textContent).toContain('dan brez treninga')
  })
  it('brez načrta za jutri ni kartice; vreme zunaj se pokaže', async () => {
    await render(<TomorrowCard plan={[d('2026-10-05')]} today="2026-10-02" hour={9} />)
    expect(div.querySelector('.tomorrow')).toBeNull()
    await render(<TomorrowCard plan={[d('2026-10-03')]} today="2026-10-02" hour={9} weather={{ '2026-10-03': { code: 61, tmin: 9, tmax: 14, rain: 80, wind: 20, now: null } as never }} />)
    expect(div.textContent).toMatch(/dež|Dež/)
  })
})
