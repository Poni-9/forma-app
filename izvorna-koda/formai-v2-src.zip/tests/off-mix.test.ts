import { describe, it, expect } from 'vitest'
import { buildWeek, weekContext, FRANJA_2027, PHASE_INFO } from '../src/domain/training/planner'
import { offMixOf, OFF_MIX } from '../src/domain/training/offMix'
import type { PlanDay, Profile } from '../src/domain/types'

const now = new Date().toISOString()
// off-season 3 tedne od 28. 9.: 1. teden počitek, 2. aktivni počitek, 3. vrnitev
const prof = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, restHr: 55, maxHr: 200, lthr: 184, ftp: 240, ftpDate: '2026-09-20',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, hoursPerWeek: 14, baseHours: null,
  strength: { on: true, equipment: 'gym', phases: ['osnova'] }, strengthDays: 2, goal: 'dirka', deficit: 400, neat: 1.4,
  event: { ...FRANJA_2027 }, cycleStart: '2026-09-28', offSeasonWeeks: 3, onboardingDone: true, createdAt: now, updatedAt: now, ...o,
})
const W1 = '2026-09-28', W2 = '2026-10-05', W3 = '2026-10-12'
const week = (p: Profile, ws: string): PlanDay[] => buildWeek({ profile: p, activities: [], weekStart: ws, notBefore: ws })
const hikes = (w: PlanDay[]) => w.filter(d => d.kind === 'pohod').length
const rides = (w: PlanDay[]) => w.filter(d => d.kind === 'kolo').length

describe('off-season: kaj delaš, izbere uporabnik', () => {
  it('faze: počitek → aktivni počitek → vrnitev', () => {
    expect([W1, W2, W3].map(w => weekContext(prof(), w).offStage)).toEqual(['pocitek', 'aktivno', 'vrnitev'])
  })
  it('privzeto (ni izbral): nikjer hribov — kolo po občutku; aplikacija ne odloči namesto njega', () => {
    const p = prof()
    expect(offMixOf(p)).toBe('kolo')
    for (const ws of [W1, W2, W3]) expect(hikes(week(p, ws))).toBe(0)
    expect(rides(week(p, W2))).toBe(4)
    expect(week(p, W2).find(d => d.role === 'dolga')?.title).toBe('Daljša vožnja po občutku')
  })
  it('počitek s kolesom: vse po želji (neobvezno), brez intervalov', () => {
    const w = week(prof({ offMix: 'kolo' }), W1).filter(d => d.kind !== 'pocitek')
    expect(w.length).toBeGreaterThan(0)
    expect(w.every(d => d.optional)).toBe(true)
    expect(w.every(d => d.zone === 'Z2' || d.zone === 'Z1' || d.zone == null)).toBe(true)
  })
  it('»Kolo in hribi«: aktivni teden 2 × hribi in 2 × kolo', () => {
    const w = week(prof({ offMix: 'mesano' }), W2)
    expect(hikes(w)).toBe(2)
    expect(rides(w)).toBe(2)
  })
  it('»Več hribov«: aktivni teden 3 × hribi, kolo enkrat; počitek s sprehodom/hribi po želji', () => {
    const p = prof({ offMix: 'hribi' })
    expect(hikes(week(p, W2))).toBe(3)
    expect(rides(week(p, W2))).toBe(1)
    expect(hikes(week(p, W1))).toBe(2)
    expect(week(p, W1).filter(d => d.kind === 'pohod').every(d => d.optional)).toBe(true)
  })
  it('vrnitev: kolo pri vseh, zadnji dan hribi samo, če jih je izbral', () => {
    expect(hikes(week(prof({ offMix: 'kolo' }), W3))).toBe(0)
    expect(hikes(week(prof({ offMix: 'mesano' }), W3))).toBe(1)
  })
  it('razlaga tedna sledi izbiri (pri kolesu ne omenja hribov)', () => {
    const why = (p: Profile) => week(p, W2).map(d => d.why ?? '').join(' ')
    expect(why(prof())).toMatch(/vožnja po občutku — brez intervalov/)
    expect(why(prof())).not.toMatch(/hrib/i)
    expect(why(prof({ offMix: 'hribi' }))).toMatch(new RegExp(OFF_MIX.hribi.active))
    expect(PHASE_INFO.prehod.desc).toMatch(/izbereš sam/)
  })
})
