// Kartica cilja: po datumu dirke »končano« s pozivom za nov cilj ali off-season (ne »danes« za vedno);
// Franja samo pri tekmovalnih ciljih. Napaka intervals.icu: odjava → »Poveži znova«, kvota → do kdaj čakamo.
import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any }))
vi.mock('@/state/store', () => ({
  useApp: () => S.state, getState: () => S.state, toast: vi.fn(), updateProfile: vi.fn(), updateSettings: vi.fn(), saveCheckin: vi.fn(), savePlanDays: vi.fn(),
}))

import { GoalCard } from '@/ui/GoalCard'
import { IcuErrorCard, icuErrText, quotaUntil, icuErrActive, syncResult } from '@/ui/IcuStatus'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

const today = '2026-09-25'
const base = { sex: 'm', age: 30, heightCm: 180, weightKg: 75, ftp: 250, gear: { bikeOutdoor: true, trainer: false, noBike: false }, strength: { on: false, equipment: 'none' }, onboardingDone: true, createdAt: 'x', updatedAt: 'x' }
const setApp = (profile: object) => { S.state = { today, profile: { ...base, ...profile }, checkins: [], settings: { tests: [] }, plan: [], activities: [] } }

let div: HTMLDivElement, root: Root
const render = async (el: React.ReactNode) => { await act(async () => { root.render(el) }) }
beforeEach(() => { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div) })
afterEach(async () => { await act(async () => root.unmount()); div.remove() })

describe('GoalCard', () => {
  it('dirka je mimo: »končano« in poziv za nov cilj / off-season, ne »danes«', async () => {
    setApp({ goal: 'dirka', event: { name: 'Kronometer Vodice', date: '2026-09-20', distanceKm: 40 } })
    await render(<GoalCard />)
    expect(div.textContent).toContain('končano')
    expect(div.textContent).not.toContain('danes')
    expect(div.textContent).toContain('Nov cilj')
    expect(div.textContent).toContain('Off-season')
  })
  it('dan dirke: »danes«', async () => {
    setApp({ goal: 'dirka', event: { name: 'Kronometer Vodice', date: today, distanceKm: 40 } })
    await render(<GoalCard />)
    expect(div.textContent).toContain('danes')
  })
  it('Franja samo pri tekmovalnih ciljih', async () => {
    setApp({ goal: 'hitrejsi', event: null })
    await render(<GoalCard />)
    expect(div.textContent).toContain('Franja')
    setApp({ goal: 'shujsati', event: null })
    await render(<GoalCard />)
    expect(div.textContent).toBe('')                       // na Danes nič
    await render(<GoalCard full />)
    expect(div.textContent).not.toContain('Franja')         // v Napredku nevtralno »Cilj z datumom«
    expect(div.textContent).toContain('Cilj z datumom')
  })
  it('še 1 dan / 2 dni / 3 tedne: prave oblike', async () => {
    setApp({ goal: 'dirka', event: { name: 'X', date: '2026-09-26' } })
    await render(<GoalCard />)
    expect(div.textContent).toContain('še 1 dan')
    setApp({ goal: 'dirka', event: { name: 'X', date: '2026-09-27' } })
    await render(<GoalCard />)
    expect(div.textContent).toContain('še 2 dneva')
  })
})

describe('IcuErrorCard', () => {
  it('odjava: »Poveži znova«', async () => {
    const e = { at: Date.now(), kind: 'auth' as const, msg: 'HTTP 401' }
    await render(<IcuErrorCard err={e} />)
    expect([...div.querySelectorAll('button')].some(b => b.textContent === 'Poveži znova')).toBe(true)
  })
  it('kvota: do kdaj čakamo (iz sporočila »~N min«), po izteku se ne kaže več', () => {
    const at = new Date('2026-09-25T10:00:00').getTime()
    const e = { at, kind: 'quota' as const, msg: 'intervals.icu: preveč zahtevkov — poskusim znova čez ~15 min.' }
    expect(quotaUntil(e)).toBe(at + 15 * 60_000)
    expect(icuErrText(e)).toContain('počakam do 10:15')
    expect(icuErrActive(e, at + 60_000)).toBe(true)
    expect(icuErrActive(e, at + 16 * 60_000)).toBe(false)
  })
  it('ostale napake pokažejo pravo sporočilo', () => {
    expect(icuErrText({ at: 0, kind: 'other', msg: 'intervals.icu: HTTP 404' })).toBe('intervals.icu: HTTP 404')
    // omrežje: poved iz shrambe ostane cela (brez podvajanja), strežniška napaka dobi razlago
    expect(icuErrText({ at: 0, kind: 'network', msg: 'intervals.icu ni dosegljiv — preveri povezavo.' })).toBe('intervals.icu ni dosegljiv — preveri povezavo.')
    expect(icuErrText({ at: 0, kind: 'network', msg: 'intervals.icu: HTTP 503' })).toBe('intervals.icu trenutno ne odgovarja (HTTP 503) — poskusim znova ob naslednjem odprtju.')
  })
  it('»Preveri Garmin«: napaka ni »vožnje še ni«, preskočen uvoz ni napaka', () => {
    expect(syncResult({ added: 0, error: 'intervals.icu zavrača dostop', kind: 'auth' })).toEqual({ added: 0, error: 'intervals.icu zavrača dostop', skipped: false })
    expect(syncResult({ added: 0, error: 'Uvoz iz intervals.icu že teče.', kind: 'skipped' })).toMatchObject({ skipped: true })
    expect(syncResult({ added: 3 })).toEqual({ added: 3, error: null, skipped: false })
    expect(syncResult(null)).toEqual({ added: null, error: null, skipped: false })
  })
})
