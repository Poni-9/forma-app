import { describe, it, expect } from 'vitest'
import { ruleQuestions, ruleProposal, ruleAdjust, offDaysIn, wishSignals, ruleStrategy } from '../src/domain/focus/rules'
import { coachReview, planInputs } from '../src/domain/focus/coach'
import { normalizeFocus, profileFromFocus, weekLine, sessionLabel } from '../src/domain/focus/model'
import { composeWish } from '../src/domain/focus/choices'
import { buildFocusWeek } from '../src/domain/training/focusPlan'
import { buildWeek } from '../src/domain/training/planner'
import { dose, strengthWorkout, EXERCISES } from '../src/domain/training/exercises'
import { minutesIn as perSessionIn } from '../src/domain/focus/dose'
import { raceIn } from '../src/domain/focus/race'
import { focusContext } from '../src/domain/ai/focusAi'
import { addDays, weekStartIso } from '../src/domain/training/load'
import { templateFor } from '../src/ui/figure/templates'
import type { Focus, PlanDay, Profile } from '../src/domain/types'

/* v3.50 FOCUS-NACRT: načrt po meri po pravilih (persone brez AI, kot vprašalnik »Raje brez prijave«) — tek in hoja,
   odmerek moči, mladoletni, zdravstvene omejitve, drug šport, pogajanje brez AI, besede o dnevih in času. */

const T = '2026-10-18'   // nedelja: 1. teden bloka se začne v ponedeljek 19. 10.
const NOW = '2026-10-18T10:00:00.000Z'
const blank = { name: 'X', sex: 'm', age: 30, heightCm: 180, weightKg: 80, restHr: null, maxHr: null, lthr: null, ftp: null, ftpDate: null, goal: 'forma', gear: { bikeOutdoor: false, trainer: false, noBike: true, powerMeter: null }, hoursPerWeek: 4, hoursMode: 'own', strength: { on: false, equipment: 'none' }, strengthDays: 0, deficit: 0, neat: 1.4, proteinGkg: 1.6, event: null, races: [], level: 1, onboardingDone: true, createdAt: NOW, updatedAt: NOW, aiConsentAt: NOW, aiConsentV: 2 } as unknown as Profile

function persona(o: { picks: Record<string, string[]>; text?: string; answers: Record<string, string>; base: Profile; main?: 'kardio' | 'oboje' | 'moc' }) {
  const wish = composeWish(o.picks, o.text || '')
  const qs = ruleQuestions(wish, { avail: null, today: T, event: null })
  const qa = qs.questions.map(q => ({ id: q.id, q: q.text, a: o.answers[q.id] ?? (q.options[0] || '') }))
  const pr = ruleProposal(wish, qa, o.base.age, { avail: null, today: T, body: o.base } as Parameters<typeof ruleProposal>[3])
  const { opts } = planInputs({ picks: o.picks, wish, qa, age: o.base.age, main: o.main || 'oboje', avail: null })
  const rv = coachReview({ ...pr.focus, main: o.main || 'oboje' }, opts)
  const p = { ...o.base, ...profileFromFocus(rv.focus, o.base, weekStartIso(T), T) } as Profile
  return { wish, qs, qa, pr, rv, p, f: rv.focus }
}
const week = (p: Profile, ws: string, today = T, o: Partial<Parameters<typeof buildFocusWeek>[0]> = {}) => buildFocusWeek({ profile: p, activities: [], weekStart: ws, notBefore: ws, today, ...o })
const runSec = (d: PlanDay) => { const m = /(\d+) × \((\d+) min(?: (\d+) s)? tek/.exec(d.desc); return m ? +m[1]! * (+m[2]! * 60 + (m[3] ? +m[3] : 0)) : d.durationMin * 60 }
const legs = (d?: PlanDay) => !!d && d.kind === 'moc' && /spodnji|noge|celo/.test(d.title)

const tekac = () => persona({ picks: { cilj: ['Manj kilogramov', 'Boljša kondicija'], delam: ['Tek'], raven: ['Začenjam'], tek: ['Začenjam s tekom'] }, answers: { dni: '3', cas: '30 min', nedni: 'Vsi gredo', poskodbe: 'Ne' }, base: { ...blank, age: 38, heightCm: 178, weightKg: 95 } as Profile })
const doma = () => persona({ picks: { cilj: ['Boljša kondicija', 'Zdravje in počutje'], delam: ['Vadba doma'], raven: ['Začenjam'] }, answers: { dni: '3', cas: '30 min', kje: 'Nič', kardio: 'Tek', nedni: 'Vsi gredo', poskodbe: 'Ne' }, base: { ...blank, sex: 'z', age: 45, heightCm: 168, weightKg: 66 } as Profile })
const zenska = () => persona({ picks: { cilj: ['Manj kilogramov'], delam: ['Fitnes'], raven: ['Občasno'], postava: ['Vitka in močna'] }, answers: { dni: '4', cas: '45 min', poudarek: 'Noge in zadnjica', kardio: 'Tek', nedni: 'Vsi gredo', poskodbe: 'Ne' }, base: { ...blank, sex: 'z', age: 34, heightCm: 165, weightKg: 72 } as Profile })
const mlad = () => persona({ picks: { cilj: ['Manj kilogramov', 'Več mišic in moči'], delam: ['Vadba doma'], raven: ['Začenjam'], postava: ['Six pack'] }, text: 'Rad bi shujšal in imel six pack.', answers: { dni: '3', cas: '30 min', kje: 'Nič', kardio: 'Tek', nedni: 'Vsi gredo', poskodbe: 'Ne' }, base: { ...blank, age: 16, heightCm: 172, weightKg: 70 } as Profile, main: 'moc' })

describe('C01 + C45: tek in hoja — brez skoka na neprekinjen tek, ne čez povedani čas', () => {
  it('95-kg začetnik (3 × 30 min): lestvica se nadaljuje (prej 5. teden »Tek — lahko 25 min«), lažji teden ima manj teka kot teden prej', () => {
    const p = tekac().p
    const first = (ws: string) => week(p, ws).find(d => d.kind === 'tek')!
    const titles = [0, 1, 2, 3, 4, 5, 6].map(k => first(addDays('2026-10-19', 7 * k)).title)
    for (const t of titles) expect(t).toMatch(/^Tek in hoja/)
    // 4. teden bloka (lažji) ≤ 3. teden
    expect(runSec(first('2026-11-09'))).toBeLessThanOrEqual(runSec(first('2026-11-02')))
    expect(first('2026-11-09').desc).toContain('Lažji teden: ista stopnja, ponovitev manj.')
  })
  it('doma brez opreme (tek iz vprašalnika): lažji teden ni »Tek — lahko 20 min« po 4 × 5 min', () => {
    const p = doma().p
    for (let k = 0; k < 6; k++) for (const d of week(p, addDays('2026-10-19', 7 * k)).filter(x => x.kind === 'tek')) expect(d.title).not.toMatch(/^Tek — lahko/)
  })
  it('C45: tek in hoja ostane pri 30 min tudi v 3. tednu bloka (prej 35)', () => {
    for (const p of [tekac().p, doma().p]) for (let k = 0; k < 8; k++) for (const d of week(p, addDays('2026-10-19', 7 * k)).filter(x => x.kind === 'tek')) expect(d.durationMin).toBeLessThanOrEqual(30)
  })
})

describe('C02: »Več mišic in moči« in »vitka in močna« — ne vedno 4 × 4–6', () => {
  const bench = EXERCISES.find(e => e.id === 'bench')!
  it('dose: mišice + moč 6–8, hujšanje + moč 6–10, čista moč ostane 4–6', () => {
    expect(dose(bench, ['misice', 'moc'], 2).reps).toBe('6–8')
    expect(dose(bench, ['hujsanje', 'definicija', 'moc'], 2).reps).toBe('6–10')
    expect(dose(bench, ['moc'], 2).reps).toBe('4–6')
  })
  it('»vitka in močna« ni cilj moč; fitnes uporabnice brez 4–6 in brez »2–3 min« pavze', () => {
    expect(wishSignals('Postava: vitka in močna.').aims).not.toContain('moc')
    const x = zenska()
    const m = week(x.p, '2026-10-19').filter(d => d.kind === 'moc')
    expect(m.length).toBeGreaterThan(0)
    for (const d of m) { expect(d.exercises!.every(e => e.reps !== '4–6')).toBe(true); expect(d.desc).not.toContain('2–3 min') }
  })
})

describe('C03 + F02 + H23: mladoletni — nič o hujšanju in primanjkljaju', () => {
  it('odgovor, pojasnila in AI kontekst brez hujšanja; namesto tega stavek o vzdrževanju', () => {
    const x = mlad()
    expect(x.pr.reply).not.toMatch(/hujš|deficit/i)
    expect(x.f.notes.join(' ')).not.toMatch(/hujš|deficit|primanjkljaj/i)
    expect(x.f.notes.join(' ')).toContain('Do 18. leta kalorije ostanejo za vzdrževanje')
    expect(x.f.keepMuscle).toBe(false)
    expect(focusContext(x.p)).not.toContain('hujšanju')
    expect((x.f.why || []).join(' ')).not.toMatch(/hujš|deficit/i)
  })
  it('normalizeFocus (tudi odgovor AI): opomba o deficitu do 18. leta izpade', () => {
    const f = normalizeFocus({ sessions: [{ type: 'fitnes', part: 'celo', min: 45 }], aims: ['hujsanje', 'misice'], notes: ['Hujšanje: zmeren deficit in dovolj beljakovin — tako gre dol maščoba, ne mišice.'], strategy: '– Prehrana: deficit 400 kcal.\n– Spanec 7–9 h.', keepMuscle: true }, { age: 16, now: NOW })!
    expect(f.notes.join(' ')).not.toMatch(/deficit|hujš/i)
    expect(f.strategy).not.toMatch(/deficit/)
    expect(f.keepMuscle).toBe(false)
  })
})

describe('C05 + H44: čas na vadbo, kot ga je povedal', () => {
  it('rekel 30 min → teki 30 min (prej 25, sprememba pod 10 min se je zavrgla)', () => {
    expect(tekac().f.sessions.every(s => s.min === 30)).toBe(true)
  })
})

describe('C07: dnevi brez časa iz pogostih stavkov', () => {
  it('ne treniram, odpade, počivam, služba do večera, samo dan + »ne«', () => {
    expect(offDaysIn('ob nedeljah ne treniram')).toEqual([6])
    expect(offDaysIn('čez vikend ne treniram')).toEqual([5, 6])
    expect(offDaysIn('sobota in nedelja ne')).toEqual([5, 6])
    expect(offDaysIn('petek ne')).toEqual([4])
    expect(offDaysIn('sreda odpade')).toEqual([2])
    expect(offDaysIn('v nedeljo počivam')).toEqual([6])
    expect(offDaysIn('ob petkih delam do 20h')).toEqual([4])
    expect(offDaysIn('vikend je za družino')).toEqual([5, 6])
    // ostane kot prej
    expect(offDaysIn('v fitnes ne hodim ob sobotah')).toEqual([])
    expect(offDaysIn('ob sobotah ne delam')).toEqual([])
  })
})

describe('C08: mladoletnemu ostane kardio, ki ga je izbral', () => {
  it('16 let, glavno moč, kardio »Tek« → v tednu je tek (prej 3 × vadba doma)', () => {
    const x = mlad()
    expect(x.f.sessions.some(s => s.type === 'tek')).toBe(true)
  })
})

describe('C16 + C17: noge niso dan pred dolgo vadbo; tek po kilometrih', () => {
  it('kolesar + fitnes: dan pred dolgo vožnjo ni moči za noge', () => {
    const x = persona({ picks: { cilj: ['Hitrejši in vzdržljivejši', 'Več mišic in moči'], delam: ['Kolo', 'Fitnes'], raven: ['Redno, več let'], kolo: ['Zunaj po cesti', 'Merilnik moči'] }, answers: { dni: '5', cas: '1 h', poudarek: 'Celo telo', kolocilj: 'Samo forma', tekma: 'Ne', nedni: 'Vsi gredo', poskodbe: 'Ne' }, base: { ...blank, age: 29, heightCm: 182, weightKg: 78, ftp: 250, lthr: 170, maxHr: 190, gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true } } as Profile })
    const w = week(x.p, '2026-10-19')
    const i = w.findIndex(d => d.role === 'dolga')
    expect(i).toBeGreaterThan(0)
    expect(legs(w[i - 1])).toBe(false)
  })
  it('6 dni, fitnes + tek, »10–25 km«: teka ≤ 2 h 30 min na teden (prej 3 h 15 min), dan pred dolgim tekom ni nog', () => {
    const x = persona({ picks: { cilj: ['Več mišic in moči', 'Boljša kondicija'], delam: ['Fitnes', 'Tek'], raven: ['Redno, več let'] }, answers: { dni: '6', cas: '1 h', poudarek: 'Celo telo', km: '10–25 km', nedni: 'Vsi gredo', poskodbe: 'Ne' }, base: { ...blank, age: 24, heightCm: 183, weightKg: 80 } as Profile })
    expect(x.f.sessions.filter(s => s.type === 'tek').reduce((t, s) => t + s.min, 0)).toBeLessThanOrEqual(150)
    expect(x.rv.why.join(' ')).toContain('Zdaj tečeš 10–25 km na teden')
    const w = week(x.p, '2026-10-19')
    expect(w.filter(d => d.kind === 'tek').reduce((t, d) => t + d.durationMin, 0)).toBeLessThanOrEqual(150)
    const i = w.findIndex(d => d.role === 'dolga')
    expect(legs(w[i - 1])).toBe(false)
  })
})

describe('C19 + C37 + C38 + C39: besede trenerja', () => {
  it('C19: začetnik reče 6 dni → »Rekel si 6«, ne »Hočeš 5«', () => {
    const x = persona({ picks: { cilj: ['Boljša kondicija'], delam: ['Fitnes', 'Tek'], raven: ['Začenjam'] }, answers: { dni: '6', cas: '45 min', poudarek: 'Celo telo', km: 'Do 10 km', nedni: 'Vsi gredo', poskodbe: 'Ne' }, base: blank })
    expect(x.f.days).toBe(5)
    expect(x.rv.why.join(' ')).toContain('Rekel si 6')
    expect(x.rv.why.join(' ')).not.toContain('Hočeš 5')
  })
  it('C37: »En tek na teden je daljši in lahek«', () => {
    const x = persona({ picks: { cilj: ['Več mišic in moči', 'Boljša kondicija'], delam: ['Fitnes', 'Tek'], raven: ['Redno, več let'] }, answers: { dni: '6', cas: '1 h', poudarek: 'Celo telo', km: '25–40 km', nedni: 'Vsi gredo', poskodbe: 'Ne' }, base: { ...blank, age: 24 } as Profile })
    expect(x.rv.why.join(' ')).not.toContain('Ena tek')
    expect(x.rv.why.join(' ')).toContain('En tek na teden je daljši in lahek')
  })
  it('C38: »Predlagam 3 dni«, nalepka ostane »3 dnevi«', () => {
    const x = tekac()
    expect(x.pr.reply).toMatch(/^Predlagam 3 dni ·/)
    // (v3.50 NAPREDEK, H16) pod 2 h točno, kot napredek tedna na Planu (prej »~1,5 h«)
    expect(weekLine(x.f, { acc: true } as never)).toBe('3 dni · 1 h 30 min na teden')
    expect(weekLine(x.f)).toBe('3 dnevi · 1 h 30 min na teden')
  })
  it('C39 + H25: brez »(lahke krajše …)«, ko niso krajše', () => {
    expect(zenska().rv.why.join(' ')).not.toContain('lahke krajše')
  })
})

describe('C18 + C20 + C27: pogajanje brez AI', () => {
  const f0 = normalizeFocus({ wish: 'fitnes', sports: ['fitnes', 'tek'], aims: ['kondicija'], level: 2, equipment: ['fitnes'], sessions: [{ type: 'fitnes', part: 'zgornji', min: 60 }, { type: 'fitnes', part: 'spodnji', min: 60 }, { type: 'tek', cardio: 'lahko', min: 40 }] }, { now: NOW, by: 'pravila' })!
  const types = (f: Focus | null) => f!.sessions.map(s => s.type)
  it('C18: »noge me bolijo« ne doda vadbe za noge; »koleno me boli« gre v omejitve', () => {
    expect(ruleAdjust(f0, 'noge me bolijo', 30)).toBeNull()
    const k = ruleAdjust(f0, 'koleno me boli', 30)!
    expect(k.limits).toContain('koleno')
    expect(k.sessions.map(s => s.part)).toEqual(f0.sessions.map(s => s.part))
  })
  it('C20: »fitnes raje 3x« → 3 × fitnes, tek ostane', () => {
    const a = ruleAdjust(f0, 'fitnes raje 3x', 30)!
    expect(a.sessions.filter(s => s.type === 'fitnes').length).toBe(3)
    expect(a.sessions.filter(s => s.type === 'tek').length).toBe(1)
  })
  it('C27: brez fitnesa, namesto teka kolo, želim intervale, dodaj hojo, tek naj bo 30 min, več počitka', () => {
    expect(types(ruleAdjust(f0, 'brez fitnesa', 30))).toEqual(['tek'])
    expect(types(ruleAdjust(f0, 'namesto teka kolo', 30))).toEqual(['fitnes', 'fitnes', 'kolo'])
    expect(ruleAdjust(f0, 'želim intervale', 30)!.sessions.some(s => s.cardio === 'intervali')).toBe(true)
    expect(types(ruleAdjust(f0, 'dodaj hojo', 30))).toContain('hribi')
    expect(ruleAdjust(f0, 'tek naj bo 30 min', 30)!.sessions.find(s => s.type === 'tek')!.min).toBe(30)
    expect(ruleAdjust(f0, 'več počitka', 30)!.sessions.length).toBe(2)
  })
})

describe('C21 + C40 + F06 + H15: dogovor = načrt pri teku in hoji', () => {
  it('tekač začetnik: seje v dogovoru so tek in hoja, hitrega odgovora »Tek in hoja« ni', () => {
    const x = tekac()
    expect(x.f.sessions.every(s => s.walk)).toBe(true)
    expect(sessionLabel(x.f.sessions[0]!)).toContain('tek in hoja')
    expect(x.pr.quick).not.toContain('Tek in hoja')
    expect(week(x.p, '2026-10-19').find(d => d.kind === 'tek')!.title).toMatch(/^Tek in hoja/)
  })
  it('C21: tek, izbran šele v vprašalniku (raven 2): tek in hoja, ne 45 min v kosu od 1. tedna', () => {
    const r = week(zenska().p, '2026-10-19').filter(d => d.kind === 'tek')
    expect(r.length).toBeGreaterThan(0)
    for (const d of r) expect(d.title).toMatch(/^Tek in hoja/)
  })
})

describe('C22 + H47: vprašalnik', () => {
  it('C22: »vitka in močna« vpraša za poudarek, six pack ne', () => {
    expect(ruleQuestions('Cilj: manj kilogramov. Rad delam: fitnes. Postava: vitka in močna.').questions.some(q => q.id === 'poudarek')).toBe(true)
    expect(ruleQuestions('Cilj: več mišic in moči. Rad delam: fitnes. Postava: six pack.').questions.some(q => q.id === 'poudarek')).toBe(false)
  })
  it('H47: »po pol ure« je čas na vadbo — brez vprašanja o času', () => {
    expect(perSessionIn('dva dni na teden po pol ure')).toEqual({ lo: 30, hi: 30 })
    expect(perSessionIn('po uro in pol')).toEqual({ lo: 90, hi: 90 })
    expect(ruleQuestions('Cilj: zdravje. Rad delam: vadba doma. Dva dni na teden po pol ure.').questions.some(q => q.id === 'cas')).toBe(false)
  })
})

describe('C23: doma brez opreme — vaja za hrbet, ponovitve namesto kilogramov', () => {
  it('celo telo doma (30 in 45 min) ima poteg', () => {
    for (const min of [30, 45]) {
      const w = strengthWorkout({ part: 'celo', where: 'doma', equip: ['nic'], level: 1, aims: ['kondicija'], muscles: [], min, week: 1 })
      expect(w.exercises.some(e => EXERCISES.find(x => x.name === e.name)?.pat === 'potegV'), String(min)).toBe(true)
    }
  })
  it('nova vaja ima figuro leže (kot superman), ne privzete stoje', () => {
    expect(templateFor('superman-vlek')).toBe(templateFor('superman'))
    expect(templateFor('superman-vlek')).not.toBe(templateFor('ni-take-vaje'))
  })
  it('opis in »zakaj« brez kilogramov', () => {
    const d = week(mlad().p, '2026-10-19').find(x => x.kind === 'moc')!
    expect(d.desc).not.toContain('kilograme')
    expect(d.desc).toContain('ponovitve vpiši')
    expect(d.why || '').not.toContain('kilograme')
  })
})

describe('C46: kolesarska tekma brez dneva', () => {
  it('»Maraton Franja 2027« in »junija Franja« → 13. 6. 2027; »lani sem bil na Franji« ni cilj', () => {
    expect(raceIn('Maraton Franja 2027', T)?.date).toBe('2027-06-13')
    expect(raceIn('junija Franja', T)?.date).toBe('2027-06-13')
    expect(raceIn('Lani sem bil na Franji', T)).toBeNull()
  })
  it('kolesar brez tekme v želji dobi vprašanje »Katera tekma in kdaj?«', () => {
    const q = ruleQuestions('Cilj: hitrejši in vzdržljivejši. Rad delam: kolo.', { today: T }).questions
    expect(q.find(x => x.id === 'tekma')?.text).toMatch(/Katera in kdaj/)
  })
})

describe('H11: mladoletni nogometaš', () => {
  const x = () => persona({ picks: { cilj: ['Boljša kondicija', 'Več mišic in moči'], delam: ['Fitnes'], raven: ['Občasno'], postava: ['Mišičasta'] }, text: 'Igram nogomet: treningi ob torkih in četrtkih, tekma v soboto. Fitnes bi hodil dvakrat na teden.', answers: { cas: '1 h', poudarek: 'Celo telo', kardio: 'Brez kardia', nedni: 'Vsi gredo', poskodbe: 'Ne' }, base: { ...blank, age: 16, heightCm: 175, weightKg: 65 } as Profile, main: 'moc' })
  it('1. teden: brez 4–6 s palico in brez negativnih zgibov', () => {
    const m = week(x().p, '2026-10-19').filter(d => d.kind === 'moc')
    expect(m.length).toBe(2)
    for (const d of m) { expect(d.exercises!.every(e => e.reps !== '4–6')).toBe(true); expect(d.exercises!.some(e => e.name === 'Negativni zgibi')).toBe(false) }
  })
  it('nogomet ni »Počitek — nimaš časa«; »tekma v soboto« ni cilj tekma', () => {
    const y = x()
    expect(y.f.aims).not.toContain('tekma')
    const w = week(y.p, '2026-10-19')
    expect(w[1]!.title).toBe('Nogomet')
    expect(w[5]!.title).toBe('Nogomet — tekma')
    expect(w.filter(d => d.kind === 'moc').every(d => ![1, 3, 5].includes(w.indexOf(d)))).toBe(true)
    expect(y.rv.why.join(' ')).toContain('Nogomet (tor, čet, sob) šteje kot trening')
  })
})

describe('H12: zdravstvena omejitev iz uvoda', () => {
  const base = { ...blank, age: 60, heightCm: 178, weightKg: 85, ftp: 200, gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false } } as Profile
  it('načrt po meri: omejitev in pojasnilo z zdravnikom, brez hitrih intervalov in težkih serij', () => {
    const x = persona({ picks: { cilj: ['Boljša kondicija'], delam: ['Kolo', 'Fitnes'], raven: ['Občasno'] }, text: 'Imam visok krvni tlak.', answers: { dni: '4', cas: '1 h', poudarek: 'Celo telo', kolocilj: 'Samo forma', tekma: 'Ne', nedni: 'Vsi gredo', poskodbe: 'Ne' }, base })
    expect(x.f.limits).toContain('tlak')
    expect(x.f.notes.join(' ')).toContain('Pišeš, da imaš visok krvni tlak')
    expect(x.f.notes.join(' ')).toContain('posvetuj z zdravnikom')
    expect(x.f.sessions.some(s => s.cardio === 'intervali')).toBe(false)
    const w = week(x.p, '2026-10-19')
    expect(w.some(d => /hitro\b/.test(d.title))).toBe(false)
    for (const d of w.filter(d => d.kind === 'moc')) { expect(d.exercises!.every(e => e.reps !== '4–6' && e.reps !== '6–10')).toBe(true); expect(d.desc).toContain('Brez zadrževanja diha') }
  })
  it('kolesarski načrt: brez šprintov »vse, kar gre«; vprašalnik pozna »Srce ali tlak«', () => {
    const f = normalizeFocus({ wish: 'Cilj: pripravljen na tekmo. Rad delam: kolo. Imam visok krvni tlak.', sessions: [{ type: 'kolo', cardio: 'lahko', min: 60 }, { type: 'kolo', cardio: 'dolgo', min: 120 }, { type: 'kolo', cardio: 'lahko', min: 60 }], aims: ['tekma'] }, { age: 60, now: NOW })!
    expect(f.mode).toBe('kolo')
    const p = { ...base, focus: f, event: { name: 'Maraton Franja', date: '2027-06-13', distanceKm: 156 }, cycleStart: '2026-10-19', hoursPerWeek: 5 } as Profile
    const all = ['2026-10-19', '2026-10-26', '2026-11-02'].flatMap(ws => buildWeek({ profile: p, activities: [], weekStart: ws, notBefore: ws, today: T }))
    expect(all.some(d => /šprint/.test(d.title))).toBe(false)
    expect(all.some(d => /vse, kar gre/.test(d.desc))).toBe(false)
    expect(ruleQuestions('Cilj: kondicija. Rad delam: fitnes.').questions.find(q => q.id === 'poskodbe')!.options).toContain('Srce ali tlak')
  })
})

describe('H25: pojasnila, ki za persono ne veljajo', () => {
  it('brez kardia ni vrstice o intervalih; »vitka in močna« brez trebušnih mišic; tek brez »teža gor«', () => {
    const fit = persona({ picks: { cilj: ['Boljša kondicija', 'Več mišic in moči'], delam: ['Fitnes'], raven: ['Občasno'] }, answers: { dni: '2', cas: '1 h', poudarek: 'Celo telo', kardio: 'Brez kardia', nedni: 'Vsi gredo', poskodbe: 'Ne' }, base: blank, main: 'moc' })
    expect(fit.f.notes.join(' ')).not.toContain('intervalov')
    expect(zenska().f.notes.join(' ')).not.toContain('Trebušne mišice')
    expect(tekac().rv.why.join(' ')).not.toContain('teža')
  })
  it('strategija brez hujšanja: »na kondiciji«, ne »na kilogramih«, kjer ni uteži', () => {
    const f = normalizeFocus({ sessions: [{ type: 'kolo', cardio: 'lahko', min: 60 }, { type: 'kolo', cardio: 'dolgo', min: 120 }], aims: ['tekma'], level: 3 }, { now: NOW })!
    const s = ruleStrategy(f, { kcal: 2500, proteinG: 130, deficit: 0 })
    expect(s).not.toContain('kilogramih')
    expect(s).toContain('na kondiciji')
  })
})

describe('H09: premor 6 tednov pri načrtu po meri', () => {
  it('tekač brez vadbe od dogovora: po vrnitvi tek in hoja znova od prve stopnje, teden ne raste, razlaga pove zakaj', () => {
    const p = tekac().p
    const w1 = week(p, '2026-10-19').find(d => d.kind === 'tek')!
    const back = buildFocusWeek({ profile: p, activities: [], weekStart: '2026-11-30', notBefore: '2026-12-01', today: '2026-12-01' })
    const r = back.find(d => d.kind === 'tek')!
    expect(r.title).toBe(w1.title)
    expect(back.some(d => /Dolgo te ni bilo/.test(d.why || ''))).toBe(true)
  })
})
