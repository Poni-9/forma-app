// v3.49 CILJ — dnevni cilj in teža: poraba treninga brez osnove za čas treninga (ni dvakrat), MET teka po tempu in vrsti
// seje, beljakovine na ciljno težo pri ITM nad 25, maščobe največ 1,2 g na kg, »Zadnjih 7 dni« proti cilju istih dni,
// tempo teže iz naklona (dovolj tehtanj, nihanje), potreben tempo in datum z letnico, teža za izračun = 7-dnevno
// povprečje, »Pred« in »Po« iz razporeda Prehrane, ocena obroka brez AI iz tabele živil. Varovalke ostanejo.
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { todayIso, addDays } from '../src/domain/training/load'
import { _resetUndo } from '../src/ui/Confirm'
import {
  dailyTarget, activityKcal, estimatePlanKcal, targetParts, tdee, bmr, trainingIn, restDuring, planNetKcal, proteinRefKg,
  weightTrend, calcWeightKg, fueling, MAX_DEFICIT, MIN_ABS_M, MIN_ABS_Z,
} from '../src/domain/nutrition/energy'
import { planRunMet, runMetBySpeed } from '../src/domain/nutrition/met'
import { weekBalance } from '../src/domain/nutrition/week'
import { estimateMeal, sumFoods } from '../src/domain/nutrition/localMeal'
import { dayMealPlan } from '../src/domain/nutrition/dayplan'
import { alerts } from '../src/domain/alerts'
import { weightPace } from '../src/screens/Napredek'
import { FRANJA_2027 } from '../src/domain/training/planner'
import type { Activity, PlanDay, Profile } from '../src/domain/types'

const NOW = '2026-10-17T08:00:00.000Z'
const DAY = '2026-10-21'                      // sreda, osnovna faza (ni taperinga) — datum vedno izrecno
const AT = { today: DAY, hour: 9 }
const P = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, ftpDate: '2026-09-20', maxHr: 200, restHr: 55,
  gear: { bikeOutdoor: true, trainer: false, noBike: false }, hoursPerWeek: 12, strength: { on: false, equipment: 'none' },
  goal: 'dirka', deficit: 400, neat: 1.4, proteinGkg: 1.8, event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', trainTime: 'popoldne',
  onboardingDone: true, createdAt: NOW, updatedAt: NOW, races: [], ...o,
} as Profile)
/** tekač začetnik: 92 kg, 178 cm (ITM 29), hujšanje 500 */
const BEG = (o: Partial<Profile> = {}) => P({ age: 34, heightCm: 178, weightKg: 92, ftp: null, goal: 'shujsati', deficit: 500, proteinGkg: null, event: null, focus: { level: 1 } as Profile['focus'], ...o })
const day = (o: Partial<PlanDay> = {}): PlanDay => ({ id: 'd' + Math.random().toString(36).slice(2), date: DAY, kind: 'kolo', title: 'Dolga Z2', desc: '', durationMin: 105, zone: 'Z2', role: 'dolga', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o } as PlanDay)
const nb = (s: string) => s.replace(/[\u00a0\u202f\u2060]/g, ' ').replace(/ +/g, ' ')
const act = (o: Partial<Activity>): Activity => ({ id: 'a' + Math.random().toString(36).slice(2), source: 'manual', sport: 'kolo', date: DAY, name: 'x', aiEligible: true, geoRetain: true, createdAt: NOW, updatedAt: NOW, ...o } as Activity)

describe('B03 — poraba treninga ne šteje osnove dvakrat', () => {
  it('Blaž, 105 min Z2 po načrtu: cilj = 2 141 + 983 − 185 (prej 3 124)', () => {
    const p = P()
    expect(tdee(p)).toBe(2541)
    const t = dailyTarget(p, [], [day()], DAY, AT)!
    expect(t.plannedBurn).toBe(983)                        // bruto (kJ ≈ kcal), kot prej
    expect(t.restIn).toBe(185)                             // 2 541 × 105 / 1 440 — že v »osnova 2 541«
    expect(t.kcal).toBe(2541 - 400 + 983 - 185)
    expect(trainingIn(t)).toBe(798)
    expect(targetParts(t, p)).toMatch(/trening ~983 po načrtu .*− osnova med treningom 185 \(je že v osnovi\)/)
  })
  it('dan počitka in seja 0 min: cilj nespremenjen, osnova za trening 0', () => {
    const p = P()
    const rest = dailyTarget(p, [], [], DAY, AT)!
    expect(rest.kcal).toBe(2141); expect(rest.restIn).toBe(0)
    const zero = dailyTarget(p, [], [day({ durationMin: 0 })], DAY, AT)!
    expect(zero.restIn).toBe(0); expect(zero.kcal).toBe(2141)
    expect(targetParts(rest, p)).not.toMatch(/osnova med treningom/)
  })
  it('izmerjeno (Garmin, skupne kalorije): odšteta osnova za minute vožnje; nikoli več od same porabe', () => {
    const p = P()
    const t = dailyTarget(p, [act({ durationMin: 240, distKm: 110, kcal: 2250 })], [day({ durationMin: 240 })], DAY, AT)!
    expect(t.burn).toBe(2250)
    expect(t.restIn).toBe(Math.round((2541 * 240) / 1440))
    expect(t.kcal).toBe(2541 - t.deficit + 2250 - 424)
    expect(restDuring(2541, 10, 120)).toBe(10)            // 10 kcal v 2 h: ne gre pod 0
  })
  it('zamujena seja (po 21h) pade za neto porabo; »Si ga opravil?« kaže isto številko', () => {
    const p = P(), d = day()
    const late = dailyTarget(p, [], [d], DAY, { today: DAY, hour: 22 })!
    expect(late.plannedDropped).toBe(983 - 185)
    expect(planNetKcal(d, p)).toBe(798)
  })
})

describe('B04 — tek po tempu in vrsti seje (prej vedno 9,5 MET)', () => {
  it('načrt: tek in hoja 30 min pri 92 kg ≤ 320 kcal (prej 437); lahek 8, dolg 9, tempo 10,5 MET', () => {
    const p = BEG()
    expect(estimatePlanKcal(day({ kind: 'tek', title: 'Tek in hoja 6 × (3 min tek, 2 min hoja)', durationMin: 30, role: 'lahka' }), p)).toBeLessThanOrEqual(320)
    expect(planRunMet({ title: 'Lahek tek', zone: 'Z2', role: 'lahka' })).toBe(8)
    expect(planRunMet({ title: 'Dolgi tek', zone: 'Z2', role: 'dolga' })).toBe(9)
    expect(planRunMet({ title: 'Tempo tek', zone: 'Z3', role: 'kljucna' })).toBe(10.5)
    expect(planRunMet({ title: 'Lahek tek', zone: 'Z2', role: 'lahka' }, 1)).toBe(6.5)
  })
  it('zabeleženo: 5 km v 40 min < 9,5 MET; hitreje = več; vzpon šteje', () => {
    const p = BEG()
    expect(activityKcal(act({ sport: 'tek', distKm: 5, durationMin: 40 }), p)).toBeLessThan((9.5 * 92 * 40) / 60)
    const run = P({ weightKg: 70 })
    const slow = activityKcal(act({ sport: 'tek', distKm: 10, durationMin: 60 }), run), fast = activityKcal(act({ sport: 'tek', distKm: 12.5, durationMin: 60 }), run)
    expect(fast).toBeGreaterThan(slow)
    expect(slow).toBeGreaterThanOrEqual(690); expect(slow).toBeLessThanOrEqual(710)   // 10 km/h ≈ 10 MET × 70 kg (prej 665)
    const trail = activityKcal(act({ sport: 'tek', distKm: 10, durationMin: 90, elevM: 800 }), run), flat = activityKcal(act({ sport: 'tek', distKm: 10, durationMin: 90 }), run)
    expect(trail).toBeGreaterThan(flat)
    expect(runMetBySpeed(null)).toBe(9)
  })
  it('začetnik, 30 min tek in hoja: cilj dneva PRED 2 552 (v3.48.1) → PO pod 2 400', () => {
    const t = dailyTarget(BEG(), [], [day({ kind: 'tek', title: 'Tek in hoja 6 × (3 min tek, 2 min hoja)', durationMin: 30, zone: 'Z2', role: 'lahka' })], DAY, AT)!
    expect(t.kcal).toBeLessThan(2400)
    expect(t.kcal).toBeGreaterThan(2115)                     // dan počitka 2 115: trening še vedno doda
  })
})

describe('B19 in B20 — beljakovine in maščobe', () => {
  it('beljakovine pri ITM 29 na težo pri ITM 25: 92 kg → 158 g (prej 184); ITM 22 ostane cela teža', () => {
    const t = dailyTarget(BEG(), [], [], DAY, AT)!
    expect(proteinRefKg(BEG())).toBeCloseTo(79.2, 1)
    expect(t.proteinG).toBe(158)
    const lean = P({ weightKg: 70, heightCm: 178, goal: 'shujsati', proteinGkg: null })
    expect(dailyTarget(lean, [], [], DAY, AT)!.proteinG).toBe(140)
    // izmerjena nizka maščoba (mišice, ne prekomerna teža): cela teža
    expect(dailyTarget(BEG({ bodyFatPct: 14 }), [], [], DAY, AT)!.proteinG).toBe(184)
    // kolesarka 72 kg, 165 cm: 136 g (prej 144 g = 39 % kalorij)
    expect(dailyTarget(P({ sex: 'z', age: 35, heightCm: 165, weightKg: 72, goal: 'shujsati', deficit: 500, proteinGkg: null, event: null }), [], [], DAY, AT)!.proteinG).toBe(136)
  })
  it('maščobe na dolgi vožnji največ 1,2 g na kg (prej 127 g pri 4 h), ostanek gre v OH; vsota makrov = kalorije', () => {
    const p = P()
    const t = dailyTarget(p, [], [day({ durationMin: 240 })], DAY, AT)!
    expect(t.fatG).toBeLessThanOrEqual(Math.round(1.2 * 79))
    expect(Math.abs(t.proteinG * 4 + t.carbsG * 4 + t.fatG * 9 - t.kcal)).toBeLessThanOrEqual(10)
    // navaden dan: 25 % kalorij, vsaj 0,7 g na kg (nespremenjeno)
    const rest = dailyTarget(p, [], [], DAY, AT)!
    expect(rest.fatG).toBe(Math.round(Math.max(0.7 * 79, (rest.kcal * 0.25) / 9)))
  })
})

describe('varovalke ostanejo po spremembi formul (BMR, 1500/1200, < 18 brez deficita, strop 750)', () => {
  it('za profile, ročni cilj, načrtovane in izmerjene teke, vožnje in tek z hojo', () => {
    const plans: PlanDay[][] = [[], [day({ durationMin: 240 })], [day({ kind: 'tek', title: 'Tek in hoja — 6 × 2 min teka', durationMin: 30, role: 'lahka', kcalBurn: 271 })], [day({ kind: 'tek', title: 'Tempo', zone: 'Z3', role: 'kljucna', durationMin: 60 })]]
    const actsL: Activity[][] = [[], [act({ sport: 'tek', distKm: 10, durationMin: 60 })], [act({ kcal: 900, durationMin: 120 })], [act({ kcal: 30, durationMin: 200 })]]
    for (const sex of ['m', 'z'] as const) for (const age of [16, 17, 25, 70]) for (const [h, w] of [[150, 42], [178, 92], [190, 110]]) for (const deficit of [0, 750, 2000]) for (const ov of [null, 900, 1600]) for (const plan of plans) for (const acts of actsL) {
      const p = P({ sex, age, heightCm: h, weightKg: w, deficit, kcalOverride: ov, goal: 'shujsati', neat: 1.6, event: null })
      const t = dailyTarget(p, acts, plan, DAY, AT)!
      const training = trainingIn(t)
      expect(training).toBeGreaterThanOrEqual(0)
      expect(t.kcal).toBeGreaterThanOrEqual(bmr(p)!)
      expect(t.kcal).toBeGreaterThanOrEqual(sex === 'z' ? MIN_ABS_Z : MIN_ABS_M)
      expect(t.maintenance + training - t.kcal).toBeLessThanOrEqual(MAX_DEFICIT)
      expect(t.deficit).toBeLessThanOrEqual(MAX_DEFICIT)
      if (age < 18) { expect(t.deficit).toBe(0); expect(t.kcal).toBeGreaterThanOrEqual(t.maintenance + training) }
    }
  })
  it('opozorilo »pod varno mejo« računa mejo z isto (neto) porabo kot cilj', () => {
    const p = P()
    const d1 = addDays(DAY, -1), d2 = addDays(DAY, -2)
    const acts = [d1, d2].map(date => act({ date, durationMin: 180, kcal: 1800 }))
    // vožnja 3 h z 1 800 kcal: meja v cilju 2 541 + (1 800 − 318) − 750 = 3 273 (prej z bruto porabo 3 591)
    expect(dailyTarget(p, [acts[0]!], [], d1, { today: DAY, hour: 12 })!.floor).toBe(3273)
    const meals = (kcal: number) => [d1, d2].flatMap((date, i) => (['zajtrk', 'kosilo', 'vecerja'] as const).map(slot => ({ id: `m${i}${slot}`, date, slot, name: 'x', kcal, proteinG: 50, source: 'manual' as const, createdAt: NOW })))
    // 3 000 kcal na dan je nad 0,9 × 3 273 — ni »pod varno mejo«; 2 100 je
    expect(alerts({ profile: p, activities: acts, plan: [], checkins: [], recentMeals: meals(1000), today: DAY, hour: 12 }).some(x => x.kind === 'bad')).toBe(false)
    expect(alerts({ profile: p, activities: acts, plan: [], checkins: [], recentMeals: meals(700), today: DAY, hour: 12 })[0]?.kind).toBe('bad')
  })
})

describe('B05 — »Zadnjih 7 dni« proti cilju istih dni', () => {
  it('cilji 4 105 · 2 299 · 2 710 · 2 141 · 2 246 · 2 141, pojedeno ~na cilju → razlika ~0, ne +409', () => {
    const targets = [4105, 2299, 2710, 2141, 2246, 2141]
    const eaten = [4000, 2350, 2600, 2200, 2200, 1925]
    const wb = weekBalance(targets.map((t, i) => ({ eaten: eaten[i]!, target: t })))
    expect(wb.avgTarget).toBe(2607)
    expect(wb.avgEaten).toBe(2546)
    expect(wb.diff).toBe(-61)
    // dan brez vpisa ne šteje (ne v povprečje, ne v cilj)
    expect(weekBalance([{ eaten: 0, target: 4000 }, { eaten: 2000, target: 2100 }])).toEqual({ n: 1, avgEaten: 2000, avgTarget: 2100, diff: -100 })
  })
})

describe('B06 in B07 — tempo teže', () => {
  const ci = (d: string, kg: number) => ({ date: d, weightKg: kg })
  it('dve tehtanji 7 dni narazen ali eno na teden: ni tempa (prej »prehitro, dodaj 200–300 kcal«)', () => {
    expect(weightTrend([ci('2026-10-10', 80), ci('2026-10-17', 79.2)])!.deltaWeek).toBeNull()
    expect(weightTrend([ci('2026-10-03', 80.4), ci('2026-10-10', 80.3), ci('2026-10-17', 79.4)])!.deltaWeek).toBeNull()
    const pace = weightPace({ stale: false, dw: 0, rate: null, target: 72, avg7: 79.4, today: '2026-10-17', nPace: 3 })
    expect(pace.text).toMatch(/Za tempo rabim vsaj 4 tehtanja v 3 tednih — zdaj 3/)
  })
  it('14 dni stabilne teže z nihanjem ±0,4: ne »gre gor« in ne »preveri vpise«', () => {
    const y = [79.6, 80.4, 79.7, 80.0, 79.8, 80.1, 79.6, 80.3, 79.7, 80.4, 79.9, 80.2, 79.8, 80.4]
    const tr = weightTrend(y.map((kg, i) => ci(addDays('2026-10-04', i), kg)))!
    expect(tr.deltaWeek).not.toBeNull()
    expect(tr.noise!).toBeGreaterThan(Math.abs(tr.deltaWeek!))
    // brez ciljne teže: stabilna (prej »+0,10 kg na teden · Teža gre gor«)
    expect(nb(weightPace({ stale: false, dw: 0, rate: tr.deltaWeek, noise: tr.noise, nPace: tr.nPace, avg7: tr.avg7, target: null, today: '2026-10-17' }).text)).toMatch(/^Teža je stabilna \(\+0,16 kg na teden je v okviru nihanja\)\.$/)
    // s ciljem 72 kg do Franje: nikoli »gre gor« (teža se ne premika, kar je do cilja premalo — to pove)
    const t = nb(weightPace({ stale: false, dw: 0, rate: tr.deltaWeek, noise: tr.noise, nPace: tr.nPace, avg7: tr.avg7, target: 72, today: '2026-10-17', event: { name: 'Maraton Franja', date: '2027-06-13' } }).text)
    expect(t).not.toMatch(/gre gor/)
    expect(t).toMatch(/^Teža stoji — do 13\. 6\. 2027 \(Maraton Franja\) bi rabil ~0,24 kg na teden/)
  })
  it('enakomerno −0,1 kg na dan: naklon −0,7 kg na teden', () => {
    const tr = weightTrend(Array.from({ length: 14 }, (_, i) => ci(addDays('2026-10-04', i), 80 - i * 0.1)))!
    expect(tr.deltaWeek).toBeCloseTo(-0.7, 2)
    expect(tr.noise).toBeCloseTo(0, 2)
  })
  it('−0,06 kg na teden do Franje ni »Tempo je pravi«: potreben tempo ~0,23 in datum z letnico', () => {
    const t = nb(weightPace({ stale: false, dw: 0, rate: -0.06, noise: 0.03, nPace: 14, target: 72, avg7: 79.9, today: '2026-10-17', event: { name: 'Maraton Franja', date: '2027-06-13' }, canMore: true }).text)
    expect(t).not.toMatch(/Tempo je pravi/)
    expect(t).toMatch(/Izgubljaš 0,06 kg na teden — do 13\. 6\. 2027 \(Maraton Franja\) bi rabil ~0,23 kg na teden/)
    expect(t).toMatch(/2029/)
    expect(t).toMatch(/večji deficit/)
    // dovolj hitro: »pravi« in datum z letnico
    const ok = nb(weightPace({ stale: false, dw: 0, rate: -0.3, noise: 0.05, nPace: 14, target: 72, avg7: 79.9, today: '2026-10-17', event: { name: 'Maraton Franja', date: '2027-06-13' } }).text)
    expect(ok).toMatch(/^Tempo je pravi\. Pri tem tempu je cilj dosežen ~24\. 4\. 2027\./)
    // mladoletni ali strop 750: brez »večji deficit«
    expect(weightPace({ stale: false, dw: 0, rate: -0.06, noise: 0.03, target: 72, avg7: 79.9, today: '2026-10-17', canMore: false }).text).not.toMatch(/deficit/)
  })
})

describe('B34 — teža za izračun je 7-dnevno povprečje', () => {
  const ci = (d: string, kg: number | null) => ({ date: d, weightKg: kg })
  it('vsaj 3 tehtanja v 7 dneh: povprečje; manj: zadnje', () => {
    expect(calcWeightKg([ci('2026-10-15', 79), ci('2026-10-16', 80.5), ci('2026-10-17', 78.6)])).toBe(79.4)
    expect(calcWeightKg([ci('2026-10-10', 79), ci('2026-10-17', 80.5)])).toBe(80.5)
    expect(calcWeightKg([ci('2026-10-16', 79), ci('2026-10-17', null)])).toBe(79)
    expect(calcWeightKg([])).toBeNull()
  })
})

describe('B34 — shramba: teža v profilu po tehtanju in po izbrisu', () => {
  beforeEach(async () => { _resetUndo(); await repo.wipeAll(); localStorage.clear(); await store.reloadAll() })
  it('nihanje ±1 kg v 5 dneh: profil = povprečje (prej zadnje); izbris tehtanja ga izloči iz povprečja', async () => {
    const T0 = todayIso()
    await store.updateProfile({ sex: 'm', age: 21, heightCm: 180, weightKg: 79 })
    const kg = [79.0, 80.0, 78.8, 80.2, 79.5]
    for (let i = 0; i < kg.length; i++) await store.saveCheckin({ date: addDays(T0, -4 + i), weightKg: kg[i]! })
    expect(store.getState().profile.weightKg).toBe(79.5)     // (79 + 80 + 78,8 + 80,2 + 79,5) / 5 = 79,5
    await store.saveCheckin({ date: T0, weightKg: 81.5 })    // popravek današnjega
    expect(store.getState().profile.weightKg).toBe(79.9)
    await store.removeWeigh(addDays(T0, -1))                  // 80,2 ven
    expect(store.getState().profile.weightKg).toBe(79.8)     // (79 + 80 + 78,8 + 81,5) / 4
    // jutranji vnos brez teže teže v profilu ne spremeni
    await store.saveCheckin({ date: T0, mood: 4 })
    expect(store.getState().profile.weightKg).toBe(79.8)
  })
})

describe('B26 — »Pred« in »Po« kot v Prehrani', () => {
  const p = P()
  it('popoldne: kosilo 2–3 h prej (prej »1 h prej prigrizek«) — isti obrok kot v načrtu obrokov', () => {
    const d = { kind: 'kolo' as const, durationMin: 105, zone: 'Z2', role: 'dolga' as const }
    const f = fueling(d, p)!
    const dp = dayMealPlan(p, { kcal: 3000, proteinG: 142, carbsG: 400 }, d)
    const pre = dp.slots.filter(s => s.beforeRide).pop()!
    expect(f.before.startsWith(`${pre.label} · ${pre.when}`)).toBe(true)
    expect(f.before).toMatch(/^Kosilo · 2–3 h pred vožnjo \(v Prehrani\)/)
    expect(f.after).toMatch(/^Večerja v 45 min po vožnji \(v Prehrani\)/)
  })
  it('zjutraj, dolga 4 h in kratka: isti razpored kot Prehrana', () => {
    for (const d of [{ kind: 'kolo' as const, durationMin: 240, zone: 'Z2', role: 'dolga' as const }, { kind: 'kolo' as const, durationMin: 75, zone: 'Z2', role: 'lahka' as const }]) {
      const q = P({ trainTime: 'zjutraj' })
      const pre = dayMealPlan(q, { kcal: 3000, proteinG: 142, carbsG: 400 }, d).slots.filter(s => s.beforeRide).pop()!
      expect(fueling(d, q)!.before.startsWith(`${pre.label} · ${pre.when}`)).toBe(true)
    }
    expect(fueling({ kind: 'kolo', durationMin: 75, zone: 'Z2', role: 'lahka' }, P({ trainTime: 'zjutraj' }))!.before).toMatch(/^Pred vožnjo · 45–60 min prej/)
  })
  it('lahka ura pri deficitu: brez posebne obnove z OH (prej »63–79 g OH v 45 min«); brez deficita ostane', () => {
    const d = { kind: 'kolo' as const, durationMin: 60, zone: 'Z2', role: 'lahka' as const }
    const f = fueling(d, P({ deficit: 400 }))!
    expect(f.after).not.toMatch(/OH|ogljikov/)
    expect(f.after).toMatch(/posebna obnova po lahki uri ni potrebna/)
    expect(fueling(d, P({ deficit: 0, goal: 'dirka' }))!.after).toMatch(/g ogljikovih hidratov/)
    // ključna vožnja tudi pri deficitu: obnova ostane
    expect(fueling({ kind: 'kolo', durationMin: 90, zone: 'Z4', role: 'kljucna' }, P({ trainTime: 'zvecer' }))!.after).toMatch(/g ogljikovih hidratov/)
  })
  it('dan tekme: zajtrk po pravilu tekme in »30–60 min prej« kot v Prehrani; moč nespremenjena', () => {
    const f = fueling({ kind: 'kolo', durationMin: 300, zone: 'dirka', role: 'dirka' }, p)!
    expect(f.before).toMatch(/^Zajtrk 3 h pred startom/)
    expect(f.before).toMatch(/30–60 min prej banana ali gel/)
    expect(fueling({ kind: 'moc', durationMin: 40, zone: null }, p)!.after).toMatch(/beljakovin/)
  })
})

describe('B30 — ocena obroka brez AI iz tabele živil', () => {
  it('sumFoods: ovseni kosmiči 70 g + jogurt 200 g = 405 kcal', () => {
    expect(sumFoods([['oves', 70], ['jogurt', 200]]).kcal).toBe(405)
  })
  it('opis s količinami, kosi, kuhan riž in neznana živila', () => {
    const a = estimateMeal('ovseni kosmiči 70 g, jogurt 200 g in banana')!
    expect(a.kcal).toBe(510)
    expect(a.items.map(i => i.key)).toEqual(['oves', 'jogurt', 'banana'])
    const b = estimateMeal('2 jajci in 2 rezini kruha')!
    expect(b.kcal).toBe(150 + 200)
    expect(estimateMeal('kuhan riž 260 g s piščancem 150 g')!.kcal).toBe(350 + 165)
    // (v3.50) sendvič in pica sta zdaj v tabeli (D11); nadev je že v sendviču
    const c = estimateMeal('sendvič s šunko in jabolko')!
    expect(c.items.map(i => i.key)).toEqual(['sendvic', 'jabolko'])
    expect(c.unknown).toEqual([])
    expect(estimateMeal('pica')!.items.map(i => i.key)).toEqual(['pica'])
    expect(estimateMeal('kuhan kamenček')).toBeNull()
    expect(estimateMeal('kruh z medom')!.items.map(i => i.key)).toEqual(['kruh', 'med'])
    expect(estimateMeal('banana med vožnjo')!.items.map(i => i.key)).toEqual(['banana'])
  })
})
