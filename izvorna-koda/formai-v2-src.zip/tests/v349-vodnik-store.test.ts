// v3.49 VODNIK (shramba): prvi dogovor prosi brskalnik za trajno shrambo (C24/D16) — brez računa je vse samo na napravi;
// brez podpore (navigator.storage ni) brez napake.
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { storagePersisted } from '../src/data/db'
import { ruleProposal } from '../src/domain/focus/rules'
import { composeWish } from '../src/domain/focus/choices'

const flush = async () => { for (let i = 0; i < 10; i++) await new Promise(r => setTimeout(r, 0)) }
const setStorage = (v: unknown) => Object.defineProperty(navigator, 'storage', { value: v, configurable: true, writable: true })
const proposal = () => {
  const today = store.getState().today
  const wish = composeWish({ cilj: ['Več kondicije'], delam: ['Tek'], raven: ['Začenjam'] }, 'Nimam ure, samo telefon.')
  return ruleProposal(wish, [{ id: 'dni', q: 'Koliko dni?', a: '3' }], 38, { avail: [0, 2, 4, 5], today }).focus
}

describe('C24 trajna shramba ob prvem dogovoru', () => {
  beforeEach(async () => { await repo.wipeAll(); localStorage.clear(); await store.reloadAll(); await flush() })
  afterEach(() => { setStorage(undefined) })
  it('prvi dogovor pokliče navigator.storage.persist() in si zapomni izid; nov dogovor ne', async () => {
    const persist = vi.fn(async () => true)
    setStorage({ persisted: async () => false, persist })
    await store.applyAgreement(proposal(), { sex: 'm', age: 38, heightCm: 180, weightKg: 92 })
    await flush()
    expect(persist).toHaveBeenCalledTimes(1)
    expect(storagePersisted()).toBe(true)
    persist.mockClear()
    await store.applyAgreement(proposal(), {})
    await flush()
    expect(persist).not.toHaveBeenCalled()
  })
  it('brez navigator.storage: dogovor gre skozi brez napake', async () => {
    setStorage(undefined)
    const prof = await store.applyAgreement(proposal(), { sex: 'm', age: 38, heightCm: 180, weightKg: 92 })
    expect(prof.onboardingDone).toBe(true)
  })
})
