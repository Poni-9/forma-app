import { describe, it, expect } from 'vitest'
import { dayMealPlan, adjustToEaten, rideFuel } from '../src/domain/nutrition/dayplan'
import { fueling } from '../src/domain/nutrition/energy'
import { buildWeek, FRANJA_2027 } from '../src/domain/training/planner'
import type { MealEntry, Profile, Race } from '../src/domain/types'

const now = new Date().toISOString()
const ride = (durationMin: number, o: Record<string, unknown> = {}) => ({ kind: 'kolo' as const, durationMin, zone: 'Z2', role: 'dolga' as const, title: 'Dolga Z2', ...o })

describe('obroki: OH se seštejejo v dnevni cilj', () => {
  it('OH obrokov + gorivo na kolesu = OH cilja; noben obrok ne čez svoje kalorije', () => {
    const cases: [number, number, number, ReturnType<typeof ride> | null, 'zjutraj' | 'popoldne' | 'zvecer'][] = [
      [3200, 142, 450, ride(90, { role: 'kljucna', zone: 'Z4' }), 'popoldne'], [3700, 156, 624, null, 'popoldne'], [5400, 150, 820, ride(300), 'zjutraj'], [2600, 140, 300, ride(60, { role: 'lahka' }), 'zvecer']]
    for (const [kcal, proteinG, carbsG, main, trainTime] of cases) {
      const dp = dayMealPlan({ weightKg: 78, trainTime }, { kcal, proteinG, carbsG }, main, {})
      expect(dp.slots.reduce((s, x) => s + x.carbsG, 0) + (dp.onBike?.carbs || 0)).toBe(carbsG)
      for (const s of dp.slots) expect(s.carbsG * 4 + s.proteinG * 4).toBeLessThanOrEqual(s.kcal + 4)
    }
  })
  it('beljakovine: vsota = cilj, glavni obrok vsaj 20 g, noben čez 40 % svojih kalorij, kosilo več kot malica', () => {
    for (const [kcal, proteinG] of [[2400, 160], [1500, 120], [3300, 158], [2000, 90]] as const) {
      const dp = dayMealPlan({ weightKg: 84, trainTime: 'popoldne' }, { kcal, proteinG, carbsG: Math.round(kcal / 8) }, null)
      expect(dp.slots.reduce((s, x) => s + x.proteinG, 0), `${kcal}/${proteinG}`).toBe(proteinG)
      for (const s of dp.slots) { expect(s.proteinG, s.key).toBeGreaterThanOrEqual(Math.min(20, Math.floor(s.kcal * 0.4 / 4))); expect(s.proteinG * 4, s.key).toBeLessThanOrEqual(s.kcal * 0.4 + 4) }
      expect(dp.slots.find(s => s.key === 'kosilo')!.proteinG).toBeGreaterThan(dp.slots.find(s => s.key === 'malica')!.proteinG)
    }
    const ride = { kind: 'kolo' as const, durationMin: 120, zone: 'Z2', role: 'dolga' as const, title: 'Dolga' }
    const am = dayMealPlan({ weightKg: 78, trainTime: 'zjutraj' }, { kcal: 3000, proteinG: 150, carbsG: 400 }, ride, {})
    expect(am.slots.find(s => s.key === 'pred')!.proteinG).toBe(10)
    expect(am.slots.reduce((s, x) => s + x.proteinG, 0)).toBe(150)
  })
})

describe('čez dan: vožnja opravljena, gorivo ni vpisano', () => {
  const dp = dayMealPlan({ weightKg: 79, trainTime: 'popoldne' }, { kcal: 3300, proteinG: 158, carbsG: 450 }, ride(180), { tempC: 18 })
  const zajtrk: MealEntry = { id: 'z', date: '2026-09-24', slot: 'zajtrk', name: 'zajtrk', kcal: dp.slots[0]!.kcal, source: 'manual', createdAt: now }
  it('ne predpostavlja, da je bilo gorivo pojedeno — obroki po vožnji se ne krčijo', () => {
    const assumed = adjustToEaten(dp, [zajtrk], 3300)
    const done = adjustToEaten(dp, [zajtrk], 3300, { rideDone: true })
    const obnova = (x: typeof dp) => x.slots.find(s => s.key === 'obnova')!.kcal
    expect(obnova(done)).toBeGreaterThan(obnova(assumed))
    expect(obnova(done)).toBeGreaterThanOrEqual(dp.slots.find(s => s.key === 'obnova')!.kcal)
    // nič pojedeno, vožnja opravljena brez goriva: preostali obroki prevzamejo gorivo (do 1,35 ×)
    const none = adjustToEaten(dp, [], 3300, { rideDone: true })
    expect(none.adjusted).toBe(true)
    // brez rideDone je vse kot prej
    expect(adjustToEaten(dp, [], 3300).adjusted).toBeFalsy()
  })
})

describe('gorivo na tekmi po trajanju; polnjenje z OH samo pred dolgo tekmo', () => {
  it('kronometer 30 min: normalen dan in največ 30–60 g na uro', () => {
    const f = fueling({ kind: 'kolo', durationMin: 30, zone: 'dirka', role: 'dirka' }, { weightKg: 75 })!
    expect(f.before).not.toMatch(/8–10 g/); expect(f.before).toMatch(/normalno/)
    expect(f.during).toMatch(/Največ 30–60 g/)
    expect(rideFuel({ kind: 'kolo', durationMin: 30, zone: 'dirka', role: 'dirka' })!.totalCarbs).toBe(0)
    expect(rideFuel({ kind: 'kolo', durationMin: 70, zone: 'dirka', role: 'dirka' })!.gph).toBeLessThan(60)
    expect(rideFuel({ kind: 'kolo', durationMin: 120, zone: 'dirka', role: 'dirka' })!.gph).toBeGreaterThanOrEqual(60)
    expect(rideFuel({ kind: 'kolo', durationMin: 300, zone: 'dirka', role: 'dirka' })!.gph).toBe(85)
  })
  it('dolga tekma: 8–10 g na kg dva dni prej, 80–90 g na uro; druga tekma: ~1 g OH na kg po tekmi (ne »na kg« za gramom)', () => {
    const f = fueling({ kind: 'kolo', durationMin: 310, zone: 'dirka', role: 'dirka' }, { weightKg: 78 })!
    expect(f.before).toMatch(/8–10 g OH na kg \(624–780 g\)/); expect(f.during).toMatch(/80–90 g/)
    const b = fueling({ kind: 'kolo', durationMin: 180, zone: 'dirka', role: 'dirka', raceId: 'r' }, { weightKg: 75 })!
    expect(b.after).toMatch(/~75 g OH \(1 g na kg\)/); expect(b.after).not.toMatch(/75 g OH na kg/)
    expect(b.before).toMatch(/8–10 g OH na kg/)
    const mid = fueling({ kind: 'kolo', durationMin: 100, zone: 'dirka', role: 'dirka', raceId: 'r' }, { weightKg: 75 })!
    expect(mid.before).toMatch(/Dan prej več/); expect(mid.before).not.toMatch(/8–10/)
  })
  it('načrt: tekma 60–90 min ima na kolesu največ 30–60 g na uro; dolga C tekma dobi dan polnjenja', () => {
    const p = { sex: 'm', age: 35, heightCm: 180, weightKg: 78, ftp: 250, gear: { bikeOutdoor: true, trainer: false, noBike: false }, strength: { on: false, equipment: 'none' }, hoursPerWeek: 9, onboardingDone: true, createdAt: now, updatedAt: now, event: { ...FRANJA_2027 }, cycleStart: '2026-09-21' } as Profile
    const short: Race = { id: 's', name: 'Kratka', date: '2027-03-21', prio: 'C', distanceKm: 40, type: 'cestna' }
    const w = buildWeek({ profile: { ...p, races: [short] }, activities: [], weekStart: '2027-03-15', notBefore: '2026-01-01' })
    expect(w.find(d => d.date === '2027-03-21')!.desc).toMatch(/največ 30–60 g OH na uro/)
    const long: Race = { id: 'l', name: 'Dolga C', date: '2027-03-21', prio: 'C', distanceKm: 160, type: 'maraton' }
    const w2 = buildWeek({ profile: { ...p, races: [long] }, activities: [], weekStart: '2027-03-15', notBefore: '2026-01-01' })
    expect(w2.find(d => d.date === '2027-03-19' && d.kind !== 'moc')!.desc).toMatch(/8–10 g ogljikovih hidratov na kg/)
    expect(w2.find(d => d.date === '2027-03-20')!.desc).toMatch(/8–10 g OH na kg/)
  })
})
