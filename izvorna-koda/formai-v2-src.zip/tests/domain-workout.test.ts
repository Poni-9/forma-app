import { describe, it, expect } from 'vitest'
import { buildWeek } from '../src/domain/training/planner'
import { stepsFor, structureLines, totalSec, minMinutes } from '../src/domain/training/workout'
import { icuWorkout } from '../src/domain/intervals/workouts'
import { needOf, suggestRoutes } from '../src/domain/routes/match'
import { analyzeTrack, type RouteRec } from '../src/domain/routes/analyze'
import { dest } from '../src/domain/routes/brouter'
import type { LatLon } from '../src/domain/import/polyline'
import type { PlanDay, Profile } from '../src/domain/types'

const now = new Date().toISOString()
const P = (h: number, type: 'maraton' | 'sprint', name = 'Dirka'): Profile => ({
  sex: 'm', age: 35, heightCm: 180, weightKg: 78, ftp: 250, ftpDate: '2026-09-01', maxHr: 185, restHr: 50,
  gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: true }, strength: { on: false, equipment: 'none' },
  hoursPerWeek: h, onboardingDone: true, createdAt: now, updatedAt: now, event: { name, date: '2027-06-13', distanceKm: 156, type }, cycleStart: '2026-09-21',
} as Profile)
const find = (p: Profile, ws: string, re: RegExp): PlanDay => {
  const d = buildWeek({ profile: p, activities: [], weekStart: ws, notBefore: '2026-01-01' }).find(x => re.test(x.title))
  if (!d) throw new Error(`ni dneva ${re} v tednu ${ws}`)
  return d
}
const franja = P(12, 'maraton', 'Maraton Franja')

describe('test FTP samo po vrsti dneva, ne po »20 min« v naslovu', () => {
  it('»Sweet spot 2 × 20 min« in »Kladje 2 × 20 min« sta intervala, ne test', () => {
    for (const [ws, re] of [['2026-11-09', /Sweet spot 2 × 20/], ['2027-04-19', /Kladje 2 × 20/]] as const) {
      const d = find(franja, ws, re)
      const st = stepsFor(d, franja)
      expect(st.some(s => s.kind === 'test')).toBe(false)
      expect(st.filter(s => s.kind === 'delo').map(s => s.sec)).toEqual([1200, 1200])
      expect(icuWorkout(d, franja)!.description).not.toMatch(/Test/)
    }
    const t: PlanDay = { id: 't', date: '2026-10-15', kind: 'test', title: '20-minutni test FTP', desc: '', durationMin: 60, zone: 'test', role: 'test', source: 'rules', createdAt: now, updatedAt: now }
    expect(stepsFor(t, franja).some(s => s.kind === 'test')).toBe(true)
    expect(totalSec(stepsFor(t, franja))).toBe(3600)
  })
})

describe('struktura iz opisa + Z2 do načrtovanega trajanja', () => {
  it('30/15 — 3 serije × 13: ponovitve v treh serijah, trening na uri traja kot načrt', () => {
    const d = find(franja, '2027-02-01', /30\/15/)
    const st = stepsFor(d, franja)
    const work = st.filter(s => s.kind === 'delo')
    expect(work).toHaveLength(39)
    expect(work.every(s => s.sec === 30 && s.target === '300–325 W')).toBe(true)
    expect(st.filter(s => /^Med serij/.test(s.label)).map(s => s.sec)).toEqual([180, 180])
    expect(totalSec(st)).toBe(d.durationMin * 60)
    expect(structureLines(st)).toContain('3 serije × 13 × 30 s pri 300–325 W, vmes 15 s lahko; med serijami 3 min lahko')
    const w = icuWorkout(d, franja)!
    expect(w.description.match(/Ponovitev 13x/g)).toHaveLength(3)
    expect(w.description).toContain('- 30s 300-325w')
    expect(w.movingTime).toBe(d.durationMin * 60)
  })
  it('dolge vožnje z vajami niso odrezane: skupinska 180 min, kadenca 115 min, tempo na koncu', () => {
    const cases: [Profile, string, RegExp][] = [[P(9, 'sprint'), '2027-04-26', /Skupinska vožnja ali dirkalni/], [P(16, 'maraton'), '2026-09-21', /visoka kadenca/], [franja, '2027-01-18', /Dolga Z2 \+ tempo/]]
    for (const [p, ws, re] of cases) {
      const d = find(p, ws, re)
      const st = stepsFor(d, p)
      expect(totalSec(st)).toBe(d.durationMin * 60)
      expect(icuWorkout(d, p)!.movingTime).toBe(d.durationMin * 60)
    }
    const kad = find(P(16, 'maraton'), '2026-09-21', /visoka kadenca/)
    const reps = stepsFor(kad, P(16, 'maraton')).filter(s => s.kind === 'delo')
    expect(reps).toHaveLength(5)
    expect(reps.every(s => s.z === 'Z2' && /kadenca 110\+/.test(s.target || ''))).toBe(true)        // kadenca, ne prag
    const sk = stepsFor(find(P(9, 'sprint'), '2027-04-26', /Skupinska vožnja ali dirkalni/), P(9, 'sprint'))
    expect(sk.filter(s => s.kind === 'delo' && s.sec === 60)).toHaveLength(10)
    expect(sk.filter(s => s.kind === 'delo' && s.sec === 15)).toHaveLength(3)
  })
  it('najkrajša smiselna dolžina seje z vajami (planer je ne skrajša pod to)', () => {
    expect(minMinutes({ title: 'Z2 + klanci z nizko kadenco', desc: 'Z2; na klancu 4 × 5 min sede pri 60–70 obratih, vmes navzdol lahko.', role: 'lahka' })).toBe(45)
    expect(minMinutes({ title: 'Z2 vzdržljivost', desc: 'Mirno.', role: 'lahka' })).toBe(0)
  })
  it('dirka: vodilo po tekmi — »Kladje« samo pri Franji', () => {
    const race = (title: string): PlanDay => ({ id: 'r', date: '2027-06-13', kind: 'kolo', title, desc: '', durationMin: 120, zone: 'dirka', role: 'dirka', target: { lo: 238, hi: 250 }, source: 'rules', createdAt: now, updatedAt: now })
    expect(stepsFor(race('Maraton Franja — 156 km'), franja)[0]!.target).toBe('Kladje 238–250 W')
    expect(stepsFor(race('Kronometer Vodice — 30 km'), franja)[0]!.target).toBe('238–250 W')
  })
})

describe('trase: ponovitve iz strukture, nikoli »1× gor 0 min«', () => {
  const loop = (km: number): { pts: LatLon[]; alt: number[] } => {
    const n = Math.round((km * 1000) / 20), R = km / (2 * Math.PI), pts: LatLon[] = [], alt: number[] = []
    for (let i = 0; i <= n; i++) { const f = i / n; pts.push(dest([46.19, 14.5], R, f * 360)); alt.push(300 + (f >= 0.3 && f <= 0.4 ? 200 * ((f - 0.3) / 0.1) : f > 0.4 ? 200 * Math.max(0, 1 - (f - 0.4) / 0.6) : 0)) }
    return { pts, alt }
  }
  const t = loop(35)
  const hill: RouteRec = analyzeTrack({ id: 'hrib', source: 'voznja', name: 'hrib', date: '2026-09-10', rodeMin: 80 }, t.pts, t.alt)!
  it('30/15: 3 serije po 9,5 min', () => {
    const need = needOf(find(franja, '2027-02-01', /30\/15/), franja)!
    expect(need.need).toBe('vo2'); expect(need.reps).toBe(3); expect(need.workMin).toBe(9.5)
    const s = suggestRoutes([hill], need, franja, '2026-09-22')[0]!
    expect(s.climb).not.toBeNull()
    expect(s.how).not.toMatch(/ 0 min|1× gor/)
    expect(s.how).toMatch(/3× gor 9,5 min/)
  })
  it('neznana struktura: navodilo brez številk ponovitev', () => {
    const d: PlanDay = { id: 'x', date: '2026-11-10', kind: 'kolo', title: '30/15 — 3 serije × 13', desc: '20 min ogrevanje ...', durationMin: 90, zone: 'Z5', role: 'kljucna', target: null, source: 'rules', createdAt: now, updatedAt: now }
    const need = needOf(d, franja)!
    const s = suggestRoutes([hill], need, franja, '2026-11-10')[0]!
    expect(s.how).not.toMatch(/ 0 min/)
  })
})
