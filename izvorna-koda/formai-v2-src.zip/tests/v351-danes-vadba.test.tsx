// v3.51 DANES-VADBA — Danes, vodena vadba, Vaje (F-A): prihodnji dan se zapiše danes (A01), moč predčasno (A02, A15, A22),
// ženske oblike (A04), obroki po uri vadbe (A05), presledek na gumbu (A06), premor in tekma (A08, A17, A18, A20, A21),
// po tekmi (A10), nasvet po premoru (A11), utrip v opisu (A12, A13), premor jutri (A19), bralnik (A23), »Odmor« (A24),
// hribi brez »Vožnja« (A25), test na Danes (A26, A44), gorivo v lahkih delih (A27), rezultat testa (A28), »Nadaljuj« (A29),
// »Olajšaj dan« (A30), jedro na počitku (A31, A42), Vaje (A35–A37), »Ne« z »Razveljavi« (A41), zvečer (A43), čas tekme (A45).
import 'fake-indexeddb/auto'
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'danes', params: {} as Record<string, string> }, nav: [] as unknown[][] }))
vi.mock('@/state/store', async () => {
  const { vi: v } = await import('vitest')
  const base: Record<string | symbol, unknown> = {
    useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
    getState: () => S.state,
    routePace: () => ({ k: 1, adj: { n: 0, adj: 1 } }),
    stateToday: () => ({ level: 0, legs: false, reasons: [] }),
    toast: v.fn(),
  }
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' || typeof k === 'symbol' ? undefined : (t[k] = v.fn(async () => undefined))), has: (_t, k) => k !== 'then' })
})
vi.mock('@/app/router', () => ({ navigate: (...a: unknown[]) => { S.nav.push(a) }, useRoute: () => S.route }))
vi.mock('@/app/Shell', () => ({ Head: () => null }))
vi.mock('@/ui/useAi', () => ({ useAi: () => ({ busy: false, signedIn: false, consent: false, run: async (fn: () => Promise<unknown>) => fn(), sheet: null }) }))
vi.mock('@/state/snap', () => ({ snapOf: () => ({}) }))
vi.mock('@/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
vi.mock('@/ui/Confirm', async (orig) => {
  const m = await orig<typeof import('@/ui/Confirm')>()
  const { vi: v } = await import('vitest')
  return { ...m, undoToast: v.fn() }
})

import * as store from '@/state/store'
import { undoToast } from '@/ui/Confirm'
import { Danes, coachLine, partialLine, tooLate, testLine } from '@/screens/Danes'
import { Vadba, TestResult, RUN_KEY, stepAnnounce, loggedExercises, type Run } from '@/screens/Vadba'
import { Vaje, GLOSS, filterEx, fold } from '@/screens/Vaje'
import { YesterdayRate } from '@/ui/YesterdayRate'
import { TomorrowCard } from '@/ui/TomorrowCard'
import { WeekPauseSheet, WeekPauseCard, pausePreview } from '@/ui/WeekPauseSheet'
import { ExGrid, drillGist } from '@/ui/SessBits'
import { easeTexts } from '@/ui/ChangeDaySheet'
import { g, isF } from '@/ui/gender'
import { stepsFor, descShown, type Step } from '@/domain/training/workout'
import { EXERCISES } from '@/domain/training/exercises'
import { coreOnDemand } from '@/domain/training/planner'
import { fueling } from '@/domain/nutrition/energy'
import { saidNo } from '@/state/noAsk'
import type { Activity, PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-23', YDAY = '2026-10-22', TOMORROW = '2026-10-24', SUN = '2026-10-25'   // petek
const NOW = `${TODAY}T08:00:00.000Z`
/** Blaž: brez merilnika, LTHR 184 */
const P = { sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, ftpDate: '2026-09-14', lthr: 184, maxHr: 195, restHr: 48, trainTime: 'popoldne', gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, strength: { on: true, equipment: 'home' }, strengthDays: 2, onboardingDone: true, hoursPerWeek: 8, goal: 'forma', createdAt: '2026-08-01T08:00:00.000Z', updatedAt: NOW } as unknown as Profile
const ANA = { ...P, sex: 'z', name: 'Ana' } as Profile
const day = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: date + (o.kind || 'kolo') + (o.title || ''), date, kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, zone: 'Z2', role: 'lahka', tssTarget: 42, source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })
const rest = (date: string, o: Partial<PlanDay> = {}) => day(date, { kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, tssTarget: 0, role: null, ...o })
const legs = (date: string, o: Partial<PlanDay> = {}) => day(date, { kind: 'moc', title: 'Moč — noge in jedro', desc: 'Počasi in s kontrolo.', durationMin: 30, zone: null, role: 'moc', exercises: [{ name: 'Bolgarski počep', sets: 2, reps: '8–12', kg: null }, { name: 'Izpadni koraki', sets: 2, reps: '10–12', kg: null }, { name: 'Dvigi na prste', sets: 2, reps: '15–20', kg: null }, { name: 'Deska', sets: 2, reps: '45–60 s', kg: null }], ...o })
const race = (date: string, o: Partial<PlanDay> = {}) => day(date, { title: 'Kronometer Vodice — 18 km', desc: 'Zajtrk 2–3 h prej. Ogrevanje 25 min; prvih 5 min ne prehitro.', durationMin: 30, zone: 'dirka', role: 'dirka', raceId: 'r1', tssTarget: 45, ...o })
const reset = (plan: PlanDay[], o: Record<string, unknown> = {}) => {
  S.state = { ready: true, today: TODAY, plan, activities: [], recentMeals: [], mealsToday: [], checkins: [], checkinToday: null, weather: null, wellness: null, routeLib: null, routesBusy: false, icuDiag: null, settings: { lang: 'sl', intervals: null, coach: { msgs: [], summary: null }, startDone: true, guideSeen: true, tests: [] }, toast: null, profile: P, user: null, authKnown: true, firstSync: null, changes: [], sync: { state: 'ok' }, ...o }
  S.subs.forEach(f => f())
}
const fn = (k: string) => (store as unknown as Record<string, ReturnType<typeof vi.fn>>)[k]!
let div: HTMLDivElement | null = null, root: Root | null = null
async function render(el: ReactElement) { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div); await act(async () => { root!.render(el) }); await flush(); return div }
const sp = (x: string | null | undefined) => (x || '').replace(/⁠/g, '').replace(/[  ]/g, ' ')
const text = () => sp(document.body.textContent)
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(sp(b.textContent).trim())) as HTMLButtonElement | undefined
const flush = async () => { for (let i = 0; i < 6; i++) await act(async () => { await Promise.resolve() }) }
const tick = async (ms: number) => { await act(async () => { vi.advanceTimersByTime(ms) }) }
const runNow = () => JSON.parse(sessionStorage.getItem(RUN_KEY) || 'null') as Run | null

beforeEach(() => {
  sessionStorage.clear(); localStorage.clear(); S.subs.clear(); S.nav = []; S.route = { name: 'danes', params: {} }
  window.scrollTo = vi.fn() as never
  vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date(2026, 9, 23, 9, 0))
  for (const k of ['setPlanDone', 'addActivities', 'updatePlanDays', 'toast', 'autoMissed', 'savePlanDay']) fn(k).mockClear()
  vi.mocked(undoToast).mockClear()
})
afterEach(async () => { if (root) { await act(async () => root!.unmount()); root = null } div?.remove(); document.body.innerHTML = ''; vi.useRealTimers() })

/* ============================== vodena vadba ============================== */
describe('A01: trening prihodnjega dne, končan danes', () => {
  it('dan zamenja mesto z današnjim (updatePlanDays), kljukica gre na današnji dan — ne na soboto', async () => {
    vi.useRealTimers(); vi.useFakeTimers(); vi.setSystemTime(new Date(2026, 9, 23, 10, 0))
    const fut = day(TOMORROW, { id: 'fut', title: 'Z2 kratka', durationMin: 10 })
    const tod = day(TODAY, { id: 'tod', kind: 'tek', title: 'Tempo tek', durationMin: 40, zone: 'Z3' })
    reset([fut, tod]); S.route = { name: 'vadba', params: { id: 'fut' } }
    await render(<Vadba />)
    await act(async () => { btn(/^Začni trening$/)!.click() })
    await tick(20 * 60_000); await flush()
    const [a, b] = fn('updatePlanDays').mock.calls[0]![0] as [PlanDay, PlanDay]
    expect(a.id).toBe('fut'); expect(a.date).toBe(TOMORROW); expect(a.title).toBe('Tempo tek')
    expect(b.id).toBe('tod'); expect(b.date).toBe(TODAY); expect(b.title).toBe('Z2 kratka')
    expect(fn('setPlanDone')).toHaveBeenCalledWith('tod', true, null, expect.any(Number))
    expect(fn('setPlanDone')).not.toHaveBeenCalledWith('fut', true, null, expect.anything())
  })
  it('današnji dan je tekma: brez zamenjave (kot prej)', async () => {
    vi.useRealTimers(); vi.useFakeTimers(); vi.setSystemTime(new Date(2026, 9, 23, 10, 0))
    const fut = day(TOMORROW, { id: 'fut', title: 'Z2 kratka', durationMin: 10 })
    reset([fut, race(TODAY, { id: 'rc' })]); S.route = { name: 'vadba', params: { id: 'fut' } }
    await render(<Vadba />)
    await act(async () => { btn(/^Začni trening$/)!.click() })
    await tick(20 * 60_000); await flush()
    expect(fn('updatePlanDays')).not.toHaveBeenCalled()
    expect(fn('setPlanDone')).toHaveBeenCalledWith('fut', true, null, expect.any(Number))
  })
})

describe('A02/A15: moč, končana predčasno', () => {
  const plan = legs(TODAY).exercises!
  it('ExGrid: vaja brez zapisa je »ni narejeno«, ena serija »9« je narejeno', async () => {
    reset([])
    await render(<ExGrid exercises={plan} done={[{ name: 'Bolgarski počep', sets: 2, reps: '—, 9' }]} />)
    const tiles = [...document.querySelectorAll('.ex-t')].map(t => sp(t.textContent))
    expect(tiles[0]).toMatch(/narejeno —, 9/)
    expect(tiles[1]).toMatch(/Izpadni koraki.*ni narejeno/)
  })
  it('čip »delno · 2 od 8 serij« namesto »opravljeno«; zapis drugega izvora (ni vaj iz načrta) ostane »opravljeno«', () => {
    const d = { exercises: plan, done: { at: NOW, activityId: 'a1' } }
    expect(partialLine(d, [{ id: 'a1', exercises: [{ name: 'Bolgarski počep', sets: 2, reps: '9' }] }])).toBe('delno · 2 od 8 serij')
    expect(partialLine(d, [{ id: 'a1', exercises: plan.map(e => ({ ...e })) }])).toBeNull()
    expect(partialLine(d, [{ id: 'a1', exercises: [{ name: 'Sklece', sets: 3, reps: '10' }] }])).toBeNull()
  })
  it('loggedExercises: serija brez vpisa ostane na mestu (»—, 9«); deska na čas, ki je mimo, je v zapisu', () => {
    const d = legs(TODAY)
    const steps = stepsFor(d, P)
    const bs = steps.map((s, k) => (s.kind === 'vaja' && s.label === 'Bolgarski počep' ? k : -1)).filter(k => k >= 0)
    const deska = steps.map((s, k) => (s.label === 'Deska' ? k : -1)).filter(k => k >= 0)
    const log = { [bs[0]!]: { kg: null, reps: null }, [bs[1]!]: { kg: null, reps: 9 } }
    const ex = loggedExercises({ day: d, steps, log, upTo: deska[1]! + 1 })
    expect(ex.find(e => e.name === 'Bolgarski počep')).toMatchObject({ sets: 2, reps: '—, 9' })
    expect(ex.find(e => e.name === 'Deska')).toMatchObject({ sets: 2 })
    expect(ex.find(e => e.name === 'Izpadni koraki')).toBeUndefined()
  })
})

describe('A22/A45: zaslon »Opravljeno«', () => {
  const finished = (d: PlanDay, o: Partial<Run> = {}): Run => { const steps = stepsFor(d, P); return { v: 1, dayId: d.id, day: d, steps, i: steps.length - 1, stepAt: 0, acc: 6000, runFrom: null, cues: [], cue: null, finished: true, saved: true, ...o } }
  it('moč: »2 od 8 serij« kot tik prej (ne »5 od 17 korakov«)', async () => {
    const d = legs(TODAY, { id: 'm1' })
    const steps = stepsFor(d, P)
    const bs = steps.map((s, k) => (s.label === 'Bolgarski počep' ? k : -1)).filter(k => k >= 0)
    reset([d]); sessionStorage.setItem(RUN_KEY, JSON.stringify(finished(d, { i: bs[1]! + 1, upTo: bs[1]! + 1, log: { [bs[0]!]: { kg: null, reps: 9 }, [bs[1]!]: { kg: null, reps: 9 } } })))
    S.route = { name: 'vadba', params: { id: 'm1' } }
    await render(<Vadba />)
    expect(text()).toMatch(/0:06 · 2 od 8 serij/)
    expect(text()).not.toMatch(/korakov/)
  })
  it('tekma: »Tvoj čas« iz štoparice koraka »Tekma« (brez ogrevanja)', async () => {
    const d = race(TODAY, { id: 'rc' })
    const steps = stepsFor(d, P)
    reset([d]); sessionStorage.setItem(RUN_KEY, JSON.stringify(finished(d, { i: steps.length - 1, stepAt: 25 * 60_000, acc: (25 * 60 + 32 * 60 + 14) * 1000 })))
    S.route = { name: 'vadba', params: { id: 'rc' } }
    await render(<Vadba />)
    expect(text()).toMatch(/Tvoj čas: 32:14/)
  })
  it('A25 hribi z intervals.icu: »Vadba pride iz Garmina«, ne »Vožnja«', async () => {
    const d = day(TODAY, { id: 'h1', kind: 'pohod', title: 'Hribi namesto kolesa', durationMin: 120, zone: 'Z2' })
    reset([d], { settings: { lang: 'sl', intervals: { athleteId: 'i1', apiKey: 'x' }, tests: [] } })
    sessionStorage.setItem(RUN_KEY, JSON.stringify(finished(d)))
    S.route = { name: 'vadba', params: { id: 'h1' } }
    await render(<Vadba />)
    expect(text()).toMatch(/Vadba pride iz Garmina/)
    expect(text()).not.toMatch(/Vožnja pride/)
  })
})

describe('A05/A06/A27/A29: vodena vadba', () => {
  it('A05 ob 9:45: »Pred treningom« brez »Kosilo … pred vožnjo« (trainTime popoldne)', async () => {
    vi.setSystemTime(new Date(2026, 9, 23, 9, 45))
    const d = day(TODAY, { id: 'z2', title: 'Z2 vzdržljivost', durationMin: 120, role: 'dolga' })
    expect(fueling(d, P)!.before).toMatch(/Kosilo/)   // brez ure: po nastavitvi (popoldne)
    reset([d]); S.route = { name: 'vadba', params: { id: 'z2' } }
    await render(<Vadba />)
    const pred = [...document.querySelectorAll('.card')].find(c => /Pred treningom/.test(sp(c.textContent)))
    expect(pred).toBeTruthy()
    expect(sp(pred!.textContent)).not.toMatch(/Kosilo/)
  })
  it('A06 presledek na gumbu v fokusu (»Preskoči korak«) ne ustavi vadbe', async () => {
    vi.useRealTimers(); vi.useFakeTimers(); vi.setSystemTime(new Date(2026, 9, 23, 10, 0))
    const d = day(TODAY, { id: 'z2', durationMin: 60 })
    reset([d]); S.route = { name: 'vadba', params: { id: 'z2' } }
    await render(<Vadba />)
    await act(async () => { btn(/^Začni trening$/)!.click() })
    const skip = document.querySelector('button[aria-label="Preskoči korak"]') as HTMLButtonElement
    skip.focus()
    await act(async () => { skip.dispatchEvent(new KeyboardEvent('keydown', { key: ' ', bubbles: true })) })
    expect(runNow()!.runFrom).not.toBeNull()
    // presledek drugje (telo strani) še vedno ustavi
    await act(async () => { window.dispatchEvent(new KeyboardEvent('keydown', { key: ' ' })) })
    expect(runNow()!.runFrom).toBeNull()
  })
  it('A27 test FTP: gel v lahkem delu pred testom (0:19), ne ob 0:30 sredi testa', async () => {
    const t = day(TODAY, { id: 't1', kind: 'test', title: '20-minutni test FTP', desc: 'Test.', durationMin: 60, zone: 'test', role: 'test' })
    reset([t], { profile: { ...P, fuelKit: ['gel', 'banana'] } }); S.route = { name: 'vadba', params: { id: 't1' } }
    await render(<Vadba />)
    const chips = [...document.querySelectorAll('.food-chip')].map(c => sp(c.textContent))
    expect(chips.join(' ')).toMatch(/0:19/)
    expect(chips.join(' ')).not.toMatch(/0:30/)
  })
  it('A29 ustavljena vadba: »Zaključi« → »Nadaljuj trening« čas res požene', async () => {
    vi.useRealTimers(); vi.useFakeTimers(); vi.setSystemTime(new Date(2026, 9, 23, 10, 0))
    const d = day(TODAY, { id: 'z2', durationMin: 60 })
    reset([d]); S.route = { name: 'vadba', params: { id: 'z2' } }
    await render(<Vadba />)
    await act(async () => { btn(/^Začni trening$/)!.click() })
    await tick(60_000)
    await act(async () => { btn(/^Pavza$/)!.click() })
    expect(runNow()!.runFrom).toBeNull()
    await act(async () => { (document.querySelector('.run-end') as HTMLButtonElement).click() })
    await act(async () => { [...document.querySelectorAll('.sheet button')].find(b => /^Nadaljuj trening$/.test(sp(b.textContent)))!.dispatchEvent(new MouseEvent('click', { bubbles: true })) })
    expect(runNow()!.runFrom).not.toBeNull()
  })
  it('A28 rezultat testa: namig »npr. 186«, pod poljem »Zdaj: 184« (ne siv 184 v polju)', async () => {
    reset([])
    await render(<TestResult />)
    const inp = document.querySelector('#test-hr') as HTMLInputElement
    expect(inp.placeholder).toBe('npr. 186')
    expect(text()).toMatch(/Zdaj: 184 · vpiši novega/)
  })
  it('A23/A24 bralnik: »1 minuta«, »2 minuti«; odmor moči je »Odmor« (gumb ostane »Pavza«)', () => {
    const s = (sec: number): Step => ({ kind: 'pavza', label: 'Odmor', sec })
    expect(sp(stepAnnounce(0, 3, s(60)))).toBe('Korak 1 od 3: Odmor, 1 minuta')
    expect(sp(stepAnnounce(0, 3, s(120)))).toMatch(/2 minuti$/)
    expect(sp(stepAnnounce(0, 3, s(300)))).toMatch(/5 minut$/)
    expect(sp(stepAnnounce(0, 3, s(30)))).toMatch(/30 sekund$/)
    const st = stepsFor(legs(TODAY), P)
    expect(st.some(x => x.label === 'Pavza' || /^Pavza/.test(x.label))).toBe(false)
    expect(st.some(x => x.label === 'Odmor')).toBe(true)
  })
})

/* ============================== Danes ============================== */
describe('A04: uporabnica — ženske oblike', () => {
  it('g() in isF() po profilu (sex »z«)', () => {
    expect(g(ANA, 'naredil', 'naredila')).toBe('naredila')
    expect(g(P, 'naredil', 'naredila')).toBe('naredil')
    expect(isF(null)).toBe(false)
  })
  it('»Včeraj … si ga naredila?«, »Da, opravljeno«; na kartici treninga »Opravljeno«; trener »trenirala«', async () => {
    reset([day(YDAY, { title: 'Z2 vzdržljivost' }), day(TODAY, { title: 'Tempo 3 × 10 min', durationMin: 75, zone: 'Z3', role: 'kljucna' })], { profile: ANA })
    await render(<YesterdayRate />)
    expect(text()).toMatch(/si ga naredila\?/)
    expect(btn(/Da, opravljeno/)).toBeTruthy()
    expect(text()).not.toMatch(/naredil\?/)
    expect(coachLine(31, { kind: 'pocitek' }, 5, 10, 70, { f: true })).toMatch(/^Dolgo si trenirala manj/)
    expect(coachLine(15, { kind: 'pocitek' }, 5, 10, 70, { f: true })).toMatch(/^Sveža si/)
    expect(coachLine(0, null, 5, 10, 70, { sick: true, f: true })).toMatch(/Bolna si .*»Spet zdrava«/)
  })
  it('Danes: gumb »Opravljeno« in »Bolna sem« na dnevu počitka', async () => {
    reset([day(TODAY, { title: 'Z2' })], { profile: ANA })
    await render(<Danes />)
    expect(btn(/^Opravljeno$/)).toBeTruthy()
    expect(btn(/^Opravil$/)).toBeUndefined()
    if (root) { await act(async () => root!.unmount()); root = null }
    document.body.innerHTML = ''
    reset([rest(TODAY)], { profile: ANA })
    await render(<Danes />)
    expect(btn(/^Bolna sem$/)).toBeTruthy()
  })
})

describe('A41: »Ne« pri »si ga naredil?« ima »Razveljavi«', () => {
  it('ko ni prestavitve: obvestilo z »Razveljavi«, ki vrne vprašanje', async () => {
    const y = day(YDAY, { title: 'Z2 vzdržljivost' })
    reset([y, day(TODAY)])
    await render(<YesterdayRate />)
    await act(async () => { btn(/^Ne$/)!.click() })
    await flush()
    expect(fn('autoMissed')).toHaveBeenCalledWith(y.id)
    expect(text()).toBe('')
    const call = vi.mocked(undoToast).mock.calls[0]!
    expect(call[0]).toBe('Zabeleženo: Z2 vzdržljivost ni bil narejen.')
    expect(saidNo(y.id)).toBe(true)
    await act(async () => { void call[1]() })
    expect(saidNo(y.id)).toBe(false)
    expect(text()).toMatch(/Včeraj: Z2 vzdržljivost — si ga naredil\?/)
  })
})

describe('A10/A42/A43/A44: Danes', () => {
  it('A10 po opravljeni tekmi brez »Malo vlaknin … do starta«', async () => {
    const races = [{ id: 'r1', name: 'Kronometer Vodice', date: TODAY, distanceKm: 18, prio: 'B', type: 'kronometer' }]
    reset([race(TODAY, { done: { at: NOW, activityId: null } })], { profile: { ...P, races } })
    await render(<Danes />)
    expect(text()).not.toMatch(/Malo vlaknin/)
    expect(text()).not.toMatch(/Zajtrk pred tekmo/)
    if (root) { await act(async () => root!.unmount()); root = null }
    document.body.innerHTML = ''
    reset([race(TODAY)], { profile: { ...P, races } })
    await render(<Danes />)
    expect(text()).toMatch(/Malo vlaknin/)
  })
  it('A42 dan počitka z jedrom po želji: kartica počitka ostane (»Dodaj trening«, »Bolan sem«), jedro je pod njo z »Začni moč«', async () => {
    const core = legs(TODAY, { id: 'core', title: 'Moč — jedro', optional: true, durationMin: 20 })
    reset([rest(TODAY), core])
    await render(<Danes />)
    expect(btn(/^Dodaj trening$/)).toBeTruthy()
    expect(btn(/^Bolan sem$/)).toBeTruthy()
    expect(btn(/^Začni moč$/)).toBeTruthy()
    expect(text()).toMatch(/Dan brez treninga/)
  })
  it('A43 ob 21:30 za 1 h 25 min: »Danes ne gre ›« (odpre »Danes ne gre — zakaj?«); ob 9h ne', async () => {
    expect(tooLate(85, new Date(2026, 9, 25, 21, 30))).toBe(true)
    expect(tooLate(85, new Date(2026, 9, 25, 9, 0))).toBe(false)
    expect(tooLate(60, new Date(2026, 9, 25, 20, 30))).toBe(false)
    vi.setSystemTime(new Date(2026, 9, 23, 21, 30))
    reset([day(TODAY, { title: 'Z2 — daljša vožnja', durationMin: 85 })])
    await render(<Danes />)
    expect(text()).toMatch(/Za 1 h 25 min je danes že pozno/)
    await act(async () => { btn(/^Danes ne gre ›$/)!.click() })
    // (po združitvi s PLATFORMA) listi na Danes se naložijo leno
    await act(async () => { await vi.dynamicImportSettled() })
    expect(text()).toMatch(/Danes ne gre — zakaj\?/)
  })
  it('A44 po testu: »Pražni utrip 190 (prej 184) · cone so posodobljene«', async () => {
    expect(sp(testLine([{ date: '2026-09-01', kind: 'ftp', value: 253 }, { date: TODAY, kind: 'ftp', value: 265 }], TODAY))).toBe('FTP 252 W (prej 240 W) · vati so posodobljeni')
    const t = day(TODAY, { kind: 'test', title: '20-minutni test FTP', durationMin: 60, zone: 'test', role: 'test', done: { at: NOW, activityId: null } })
    reset([t], { settings: { lang: 'sl', intervals: null, coach: { msgs: [], summary: null }, startDone: true, guideSeen: true, tests: [{ id: 'x', date: '2026-09-20', kind: 'lthr', value: 184, unit: 'bpm' }, { id: 'y', date: TODAY, kind: 'lthr', value: 190, unit: 'bpm' }] } })
    await render(<Danes />)
    expect(text()).toMatch(/Pražni utrip 190 \(prej 184\) · cone so posodobljene/)
  })
  it('A26 test FTP: struktura (»20 min test … · 20 min iztek«) namesto odrezanega opisa', () => {
    const t = day(TODAY, { kind: 'test', title: '20-minutni test FTP', durationMin: 60, zone: 'test', role: 'test' })
    expect(drillGist(stepsFor(t, P))).toMatch(/^20 min test \(čim močneje, enakomerno\) · 20 min iztek/)
  })
  it('A12/A13 brez merilnika: opis »pri utripu 165–171« (cone zdaj), brez »≈ … W«', async () => {
    const desc = '20 min ogrevanje s 3 kratkimi pospeški · 3 × 10 min pri utrip 166–171 (≈ 182–204 W, brez merilnika po občutku), vmes 5 min lahko · 15 min iztek.'
    const d = day(TODAY, { title: 'Tempo 3 × 10 min', desc, durationMin: 75, zone: 'Z3', role: 'kljucna', target: { lo: 182, hi: 204 } })
    expect(descShown(desc, P, d)).toBe('20 min ogrevanje s 3 kratkimi pospeški · 3 × 10 min pri utripu 165–171, vmes 5 min lahko · 15 min iztek.')
    // z merilnikom nespremenjeno; razpon druge cone ostane
    expect(descShown(desc, { ...P, gear: { ...P.gear, powerMeter: true } } as Profile, d)).toBe(desc)
    expect(descShown('Z2 pri utrip 149–164.', P, d)).toBe('Z2 pri utripu 149–164.')
    reset([d])
    await render(<Danes />)
    const more = sp(document.querySelector('details.more')?.textContent)
    expect(more).toMatch(/pri utripu 165–171/)
    expect(more).not.toMatch(/W, brez merilnika/)
  })
  it('A11 po dolgem premoru in trd trening v načrtu: kdaj, ne »dva tedna brez trdih intervalov«', () => {
    expect(coachLine(31, { kind: 'pocitek' }, 5, 10, 70, { nextHard: 'v torek, 27. 10.' })).toBe('Dolgo si treniral manj — začni postopno. Prvi trd trening (v torek, 27. 10.) začni malo pod razponom.')
    expect(coachLine(31, { kind: 'pocitek' }, 5, 10, 70, {})).toMatch(/Prva dva tedna brez trdih/)
  })
  it('A19 jutri premor: »Premor — brez kolesa« (kot v Planu), ne »Počitek«', async () => {
    reset([])
    await render(<TomorrowCard plan={[rest(TOMORROW, { title: 'Premor — brez kolesa' })]} today={TODAY} />)
    expect(text()).toMatch(/Premor — brez kolesa/)
    expect(text()).not.toMatch(/Počitek/)
  })
})

describe('A08/A17/A18/A20/A21: premor »Ta teden …«', () => {
  const pause = (mode: 'vse' | 'kolo', o: Record<string, unknown> = {}) => ({ ...P, weekPause: { from: TODAY, to: SUN, mode, ...o } })
  it('vrstica pod tekmo: tekma ostane; gumb »Prekliči premor«', async () => {
    reset([race(TODAY)], { profile: pause('kolo') })
    await render(<WeekPauseCard compact />)
    expect(text()).toMatch(/Kronometer Vodice ostane — odstraniš ga v Planu\./)
    expect(btn(/^Prekliči premor$/)).toBeTruthy()
  })
  it('list: veljavni način ima aria-pressed in »velja«; predogled, kaj odpade', async () => {
    reset([day(TODAY), legs(TOMORROW), day(SUN, { durationMin: 90 })], { profile: pause('kolo') })
    await render(<WeekPauseSheet open onClose={() => undefined} />)
    const kolo = btn(/^Brez kolesa do nedelje/)!, vse = btn(/^Brez treningov do nedelje/)!
    expect(kolo.getAttribute('aria-pressed')).toBe('true')
    expect(sp(kolo.textContent)).toMatch(/✓ velja/)
    expect(vse.getAttribute('aria-pressed')).toBe('false')
    expect(sp(vse.textContent)).toMatch(/Odpade še 3 treningi \(3 h\)\./)
  })
  it('pausePreview: brez kolesa 2 vožnji, brez treningov 3; tekma posebej', () => {
    const plan = [day(TODAY), legs(TOMORROW), day(SUN, { durationMin: 90 }), race(SUN, { id: 'rc' }), day('2026-10-26')]
    expect(pausePreview(plan, 'kolo', TODAY, SUN)).toMatchObject({ n: 2, min: 150 })
    expect(pausePreview(plan, 'vse', TODAY, SUN)).toMatchObject({ n: 3, min: 180 })
    expect(pausePreview(plan, 'vse', TODAY, SUN).races.map(d => d.id)).toEqual(['rc'])
  })
  it('nedelja: »Brez treningov danes — Današnji trening odpade« (ne »do takrat«)', async () => {
    reset([day(SUN)], { today: SUN })
    await render(<WeekPauseSheet open onClose={() => undefined} />)
    expect(btn(/^Brez treningov danes/)).toBeTruthy()
    expect(text()).not.toMatch(/do takrat/)
    expect(text()).toMatch(/Današnji trening odpade/)
    expect(text()).toMatch(/današnja vožnja odpade/)
  })
})

describe('A30/A31: besedila dneva', () => {
  it('»Olajšaj dan« brez »bolje en manj kot bolezen«', () => {
    expect(easeTexts({ title: 'Z2 — daljša vožnja', durationMin: 85, role: 'dolga' }, null, SUN).sub).toBe('Danes samo lahko; Z2 — daljša vožnja ta teden odpade — en trening manj ne škodi.')
  })
  it('jedro po želji na dan brez kolesa: »Kadar koli danes«; z vožnjo »Po kolesu ali zvečer«', () => {
    expect(coreOnDemand(P, [], TODAY, { ride: false }).desc).toMatch(/^Kadar koli danes — \d+ min\. /)
    expect(coreOnDemand(P, [], TODAY, { ride: false }).desc).toMatch(/Po želji — ne šteje v realizacijo tedna\.$/)
    expect(coreOnDemand(P, [], TODAY, { ride: true }).desc).toMatch(/^Po kolesu ali zvečer\./)
  })
})

/* ============================== Vaje ============================== */
describe('A35/A36/A37: Vaje', () => {
  it('angleška imena imajo slovensko razlago; vse razlage so za obstoječe vaje', () => {
    const en = /\b(Dead|bug|Pike|Superman|Burpee|Goblet|Hip|thrust|Pallof|press|Face|pull)\b/
    for (const e of EXERCISES) if (en.test(e.name)) expect(GLOSS[e.name], e.name).toBeTruthy()
    for (const n of Object.keys(GLOSS)) expect(EXERCISES.some(e => e.name === n), n).toBe(true)
  })
  it('filter po mišici in iskanje brez šumnikov (tudi po razlagi)', () => {
    expect(filterEx(EXERCISES, { m: 'hrbet' }).every(e => e.m.includes('hrbet'))).toBe(true)
    expect(filterEx(EXERCISES, { m: 'hrbet' }).length).toBeGreaterThan(3)
    expect(filterEx(EXERCISES, { q: 'pocep' }).map(e => e.name)).toContain('Bolgarski počep')
    expect(filterEx(EXERCISES, { q: 'hrošč' }).map(e => e.name)).toEqual(['Dead bug'])
    expect(fold('Počep Š')).toBe('pocep s')
  })
  it('zaslon: »Nazaj«, iskanje zoži seznam, list vaje z razlago', async () => {
    reset([]); S.route = { name: 'vaje', params: {} }
    await render(<Vaje />)
    expect(btn(/Nazaj$/)).toBeTruthy()
    const inp = document.querySelector('#vaje-q') as HTMLInputElement
    await act(async () => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(inp, 'pallof'); inp.dispatchEvent(new Event('input', { bubbles: true })) })
    const tiles = [...document.querySelectorAll('.vaja-tile')].map(t => sp(t.textContent))
    expect(tiles).toEqual(['Pallof press'])
    await act(async () => { (document.querySelector('.vaja-tile') as HTMLButtonElement).click() })
    expect(text()).toMatch(/Po slovensko: protirotacijski potisk/)
  })
})

// pomožno: Activity za tipe v testih zgoraj
export type _A = Activity
