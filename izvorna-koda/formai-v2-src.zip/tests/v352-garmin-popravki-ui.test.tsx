// v3.52 POPRAVKI-APP — UI: oznaka »na uri« v Planu samo za dneve v 14-dnevnem oknu in ne na dnevih premora (N3);
// kartica Garmin pokaže razlog napake tudi brez povezave (?garmin=err); ReadinessSheet »ob prebujanju« samo z bodyBatteryAtWake.
// Mocki so isti kot v tests/v352-garmin-ui.test.tsx (store je lažen, domena garmin/workouts je prava).
import 'fake-indexeddb/auto'
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'uvoz', params: {} as Record<string, string> }, nav: [] as unknown[][], live: false }))
vi.mock('@/state/store', async () => {
  const { vi: v } = await import('vitest')
  const base: Record<string | symbol, unknown> = {
    useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
    getState: () => S.state,
    routePace: () => ({ k: 1, adj: { n: 0, adj: 1 } }),
    stateToday: () => ({ level: 0, legs: false, reasons: [] }),
    toast: v.fn(),
    // kot v store: povezan + pošiljanje ni izklopljeno + (brez dovoljenj ali WORKOUT_IMPORT)
    garminPushOn: (s: { garmin?: { connected?: boolean; pushWorkouts?: boolean; permissions?: string[] | null } | null }) => !!s.garmin?.connected && s.garmin.pushWorkouts !== false && (!s.garmin.permissions?.length || s.garmin.permissions.includes('WORKOUT_IMPORT')),
    garminPreview: (d: { kind: string }) => (d.kind === 'kolo' || d.kind === 'test' || d.kind === 'tek' ? { uid: 'x' } : null),
    garminAllows: (g: { connected?: boolean; permissions?: string[] | null } | null, p: string) => !!g?.connected && (!Array.isArray(g.permissions) || g.permissions.includes(p)),
    syncGarmin: v.fn(async () => ({ added: 0, upgraded: 0, healthDays: 0, cycleDays: 0, error: null, skipped: null })),
    LAST_EXPORT_KEY: 'x',
  }
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' || typeof k === 'symbol' ? undefined : (t[k] = v.fn(async () => undefined))), has: (_t, k) => k !== 'then' })
})
vi.mock('@/domain/garmin/client', () => ({ garminLive: async () => S.live, garminOn: () => S.live }))
vi.mock('@/app/router', () => ({ navigate: (...a: unknown[]) => { S.nav.push(a) }, useRoute: () => S.route, parseHash: () => S.route, subscribeRoute: () => () => undefined }))
vi.mock('@/app/hash', () => ({ replaceParams: () => undefined }))
vi.mock('@/app/landing', () => ({ markApp: () => undefined, forgetApp: () => undefined }))
vi.mock('@/app/Shell', () => ({ Head: () => null }))
vi.mock('@/ui/useAi', () => ({ useAi: () => ({ busy: false, signedIn: false, consent: false, run: async (fn: () => Promise<unknown>) => fn(), sheet: null }) }))
vi.mock('@/state/snap', () => ({ snapOf: () => ({}) }))
vi.mock('@/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
vi.mock('@/data/icuOauth', () => ({ icuOauthOn: () => false, probeIcuOauth: async () => false, startIcuOAuth: () => undefined }))
vi.mock('@/data/db', () => ({ getKV: async () => undefined, setKV: async () => undefined, storagePersisted: () => null, requestPersist: async () => false }))
vi.mock('@/data/repo', () => ({ wipeAll: vi.fn() }))
vi.mock('@/data/backup', () => ({ downloadBackup: vi.fn() }))
vi.mock('@/data/sync', () => ({ syncNow: vi.fn() }))
vi.mock('@/data/feedback', () => ({
  FB_KINDS: [], FB_SHOT_MAX: 1, FB_TEXT_MAX: 1, makeFeedback: async (o: object) => o, sendFeedback: async () => 'poslano', captureScreen: async () => null,
  fetchFeedbackList: async () => ({ error: 'x' }), flushFeedback: async () => 0, queuedFeedback: async () => 0,
}))
vi.mock('@/ui/ClaudeAdmin', () => ({ ClaudeAdmin: () => null }))
vi.mock('@/ui/BackupImport', () => ({ BackupImport: () => null }))
vi.mock('@/ui/GoalCard', () => ({ GoalCard: () => null }))
vi.mock('@/ui/theme', () => ({ THEME_PREFS: [['samodejno', 'kot telefon']], themePref: () => 'samodejno', setThemePref: vi.fn(), subscribeTheme: () => () => {} }))
// listi na Danes niso leni (ReadinessSheet se odpre takoj)
vi.mock('@/ui/DanesSheetsLazy', async () => {
  const r = await import('@/ui/ReadinessSheet'), w = await import('@/ui/WeighSheet'), s = await import('@/ui/SkipSheet'), m = await import('@/ui/MoveDaySheet')
  return { ReadinessSheet: r.ReadinessSheet, WeighSheet: w.WeighSheet, SkipSheet: s.SkipSheet, MoveDaySheet: m.MoveDaySheet }
})

import { Plan, onGarminWatch } from '@/screens/Plan'
import { ReadinessSheet } from '@/ui/ReadinessSheet'
import { GarminCard } from '@/ui/GarminCard'
import { onGarminWatchIds } from '@/domain/garmin/workouts'
import type { PlanDay, Profile, GarminSettings } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-23'   // petek
const NOW = `${TODAY}T08:00:00.000Z`
const P = { sex: 'm', age: 30, heightCm: 180, weightKg: 78, ftp: 240, maxHr: 190, restHr: 50, lthr: 170, hoursPerWeek: 8, trainTime: 'popoldne', gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, strength: { on: false, equipment: 'none' }, strengthDays: 0, onboardingDone: true, goal: 'hitrejsi', createdAt: NOW, updatedAt: NOW } as unknown as Profile
const G = (o: Partial<GarminSettings> = {}): GarminSettings => ({ connected: true, connectedAt: NOW, userId: 'u1', permissions: ['ACTIVITY_EXPORT', 'HEALTH_EXPORT', 'WORKOUT_IMPORT', 'COURSE_IMPORT', 'MCT_EXPORT'], pushWorkouts: true, pushCourses: true, health: false, cycle: false, lastSyncAt: null, lastError: null, ...o })
const day = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: date + (o.kind || 'kolo') + (o.title || ''), date, kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, zone: 'Z2', role: 'lahka', tssTarget: 42, source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o } as PlanDay)
const state = (o: Record<string, unknown> = {}) => ({
  ready: true, today: TODAY, profile: P, plan: [], activities: [], checkins: [], checkinToday: null, weather: null, wellness: null, user: null, authKnown: true, changes: [], pro: false,
  settings: { lang: 'sl', intervals: null, guideSeen: true, startDone: true, tests: [], coach: { msgs: [], summary: null } }, sync: { state: 'off' }, mealsToday: [], recentMeals: [], icuDiag: null, icuWorkouts: null, icuErr: null,
  routeLib: null, routesBusy: false, cycle: null, garminBusy: false, garminErr: null, garminWorkouts: null, firstSync: null, ...o,
})
const set = (o: Record<string, unknown> = {}) => { S.state = state(o); S.subs.forEach(f => f()) }

let div: HTMLDivElement | null = null, root: Root | null = null
async function render(el: ReactElement) { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div); await act(async () => { root!.render(el) }); await flush(); return div }
async function unmount() { if (root) await act(async () => root!.unmount()); div?.remove(); root = null; div = null }
const sp = (x: string | null | undefined) => (x || '').replace(/[\u2060\u200b]/g, '').replace(/[\u00a0\u2009\u202f]/g, ' ')
const text = () => sp(document.body.textContent)
const flush = async () => { for (let i = 0; i < 8; i++) await act(async () => { await Promise.resolve() }) }
beforeEach(() => { vi.clearAllMocks(); S.live = false; S.nav = []; S.route = { name: 'uvoz', params: {} }; set(); Element.prototype.scrollIntoView = vi.fn(); window.scrollTo = vi.fn() as unknown as typeof window.scrollTo })
afterEach(async () => { await unmount(); document.body.innerHTML = '' })


/* ---------- Plan: »na uri« samo v oknu in brez premora ---------- */
describe('Plan · »na uri« (popravki N3)', () => {
  const ok = { at: NOW, n: 2, created: 2, updated: 0, removed: 0, errors: [], err: null }
  const app = (g: Partial<GarminSettings> | null, w: unknown) => ({ settings: { ...state().settings, garmin: g ? G(g) : null }, garminWorkouts: w } as never)
  const D5 = '2026-10-28', D13 = '2026-11-05', D14 = '2026-11-06', D20 = '2026-11-12'
  it('onGarminWatch z množico dni: dan čez 14 dni in dan premora nista na uri, dan v oknu je', () => {
    const plan = [day(D5), day(D13), day(D14), day(D20)]
    const ids = onGarminWatchIds(plan, P, TODAY)
    expect(onGarminWatch(day(D5), D5, false, app({}, ok), ids)).toBe(true)
    expect(onGarminWatch(day(D13), D13, false, app({}, ok), ids)).toBe(true)
    expect(onGarminWatch(day(D14), D14, false, app({}, ok), ids)).toBe(false)
    expect(onGarminWatch(day(D20), D20, false, app({}, ok), ids)).toBe(false)
    const paused = onGarminWatchIds(plan, { ...P, weekPause: { from: TODAY, to: D5, mode: 'vse' } } as Profile, TODAY)
    expect(onGarminWatch(day(D5), D5, false, app({}, ok), paused)).toBe(false)
    expect(onGarminWatch(day(D13), D13, false, app({}, ok), paused)).toBe(true)
  })
  it('v Planu: dan premora »brez treningov« nima oznake »na uri«, naslednji dan jo ima', async () => {
    S.route = { name: 'plan', params: {} }
    // petek 23. 10.: sobota 24. je v premoru, nedelja 25. ne (pogled tega tedna; okno 14 dni je vedno širše od pogleda)
    set({ plan: [day('2026-10-24'), day('2026-10-25')], settings: { ...state().settings, garmin: G() }, garminWorkouts: ok, profile: { ...P, weekPause: { from: '2026-10-24', to: '2026-10-24', mode: 'vse' } } })
    await render(<Plan />)
    const marks = [...document.querySelectorAll('.g-onwatch')]
    expect(marks).toHaveLength(1)
    expect(sp(marks[0]!.closest('.card')?.textContent)).toMatch(/25/)
    expect(sp(marks[0]!.closest('.card')?.textContent)).not.toMatch(/24\./)
  })
})

/* ---------- GarminCard: razlog napake brez povezave ---------- */
describe('GarminCard · ?garmin=err brez povezave', () => {
  it('garminErr se pokaže tudi, ko settings.garmin ni (vrnitev z Garmina z napako)', async () => {
    S.live = true
    set({ user: { uid: 'u' }, garminErr: 'Povezava z Garmin Connect ni uspela — Garmin je povezavo zavrnil ali je potekel čas (10 min). Na Uvozu tapni »Poveži z Garmin Connect« in jo znova potrdi.' })
    await render(<GarminCard />)
    expect(document.querySelector('[role="alert"]')).toBeTruthy()
    expect(text()).toContain('Povezava z Garmin Connect ni uspela')
    expect(text()).toContain('Poveži z Garmin Connect')
  })
})

/* ---------- ReadinessSheet: Body Battery besedilo ---------- */
describe('ReadinessSheet · Body Battery (popravki V7)', () => {
  const ready = { score: 60, label: 'v redu', color: 'var(--ok)', reasons: [] as string[] }
  const rec0 = { date: TODAY, sleepH: 7, sleepScore: null, hrv: null, hrvBase: null, hrvZ: null, rhr: null, rhrBase: null, rhrDelta: null, penalty: 0, reasons: [] as string[] }
  it('z bodyBatteryAtWake »ob prebujanju«, brez »najvišja danes«; stres je označen kot včerajšnji', async () => {
    await render(<ReadinessSheet open onClose={() => undefined} ready={ready} rec={{ ...rec0, stress: 40, bodyBattery: 70, bodyBatteryAtWake: true }} tsb={0} checkin={null} wellnessOn hasIntervals={false} garmin />)
    expect(text()).toContain('Body Battery70ob prebujanju')
    expect(text()).toContain('Stres včeraj (Garmin)40')
    await unmount()
    await render(<ReadinessSheet open onClose={() => undefined} ready={ready} rec={{ ...rec0, bodyBattery: 70 }} tsb={0} checkin={null} wellnessOn hasIntervals={false} garmin />)
    expect(text()).toContain('Body Battery70najvišja danes')
    expect(text()).not.toContain('ob prebujanju')
  })
})
