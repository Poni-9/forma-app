// v3.50 TRENER (C44): v Predlogu so pojasnila pod »Zakaj tako« z naslovom »Vedi še« (prej ena lista z dvema temama).
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>() }))
vi.mock('@/state/store', async () => {
  const { vi: v } = await import('vitest')
  const base: Record<string | symbol, unknown> = {
    useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
    getState: () => S.state,
  }
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' || typeof k === 'symbol' ? undefined : (t[k] = v.fn(async () => {}))), has: (_t, k) => k !== 'then' })
})
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => ({ name: 'sestavi', params: {} }) }))
vi.mock('@/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import { Deal } from '@/screens/Sestavi'
import { normalizeFocus } from '@/domain/focus/model'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const NOW = '2026-10-18T08:00:00.000Z'
let div: HTMLDivElement, root: Root
afterEach(async () => { await act(async () => root.unmount()); div.remove() })

describe('C44 Predlog: »Zakaj tako« in »Vedi še«', () => {
  it('pojasnila imajo svoj naslov za »Zakaj tako«; brez »Zakaj tako« brez naslova', async () => {
    S.state = { today: '2026-10-18', profile: { sex: 'm', age: 30 }, plan: [], activities: [], settings: {} }
    const f = normalizeFocus({ wish: 'fitnes', sports: ['fitnes'], aims: ['moc'], level: 2, equipment: ['fitnes'], sessions: [{ type: 'fitnes', part: 'zgornji', min: 60 }, { type: 'fitnes', part: 'spodnji', min: 60 }], notes: ['Trebušne mišice vaje okrepijo.'] }, { now: NOW, by: 'pravila' })!
    div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
    await act(async () => { root.render(<Deal f={{ ...f, why: ['Moč pon in čet — vmes dva dni obnove.'] }} />) })
    const heads = [...div.querySelectorAll('.h4')].map(x => x.textContent)
    expect(heads).toContain('Zakaj tako')
    expect(heads.indexOf('Vedi še')).toBeGreaterThan(heads.indexOf('Zakaj tako'))
    const lists = div.querySelectorAll('ul.deal-notes')
    expect(lists[lists.length - 1]!.textContent).toContain('Trebušne mišice vaje okrepijo.')
    await act(async () => { root.render(<Deal f={{ ...f, why: [] }} />) })
    expect([...div.querySelectorAll('.h4')].map(x => x.textContent)).not.toContain('Vedi še')
  })
})
