import { describe, it, expect, vi, afterEach } from 'vitest'
import { fetchActivities, isStravaStub } from '../src/domain/intervals/client'
import { importDiagnosis } from '../src/domain/intervals/diagnosis'

const creds = { athleteId: 'i281064', apiKey: 'x' }
const mockFetch = (list: unknown[]) => vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify(list), { status: 200, headers: { 'Content-Type': 'application/json' } })))
afterEach(() => { vi.unstubAllGlobals() })

describe('uvoz iz intervals.icu — Stravini zapisi', () => {
  it('stub brez vrste in stub z vrsto, a brez podatkov, sta prešteta, ne tiho izgubljena', async () => {
    mockFetch([
      { id: '1', start_date_local: '2026-09-20T08:00:00', source: 'STRAVA', _note: 'STRAVA activities are not available via the API' },
      { id: '2', start_date_local: '2026-09-21T08:00:00', type: 'Ride', source: 'STRAVA' },
      { id: 'i3', start_date_local: '2026-09-22T08:00:00', type: 'Ride', source: 'GARMIN_CONNECT', moving_time: 5400, distance: 45000, average_heartrate: 140 },
      { id: 'i4', start_date_local: '2026-09-23T08:00:00', type: 'Ride', source: 'GARMIN_CONNECT', moving_time: 120, distance: 500 },
    ])
    const r = await fetchActivities(creds, '2025-09-24', '2026-09-25')
    expect(r.total).toBe(4)
    expect(r.stravaStubs).toBe(2)
    expect(r.stravaOrigin).toBe(2)
    expect(r.skippedShort).toBe(1)
    expect(r.activities.map(a => a.ext?.intervalsId)).toEqual(['i3'])
    expect(r.activities[0]!.aiEligible).toBe(true)
  })
  it('Stravin zapis s podatki (star način) ni stub: uvozi se, a ne gre v AI', async () => {
    expect(isStravaStub({ source: 'STRAVA', moving_time: 3600, type: 'Ride' })).toBe(false)
    mockFetch([{ id: '9', start_date_local: '2024-05-01T08:00:00', type: 'Ride', source: 'STRAVA', moving_time: 3600, distance: 30000 }])
    const r = await fetchActivities(creds, '2024-01-01', '2024-12-31')
    expect(r.stravaStubs).toBe(0); expect(r.stravaOrigin).toBe(1)
    expect(r.activities).toHaveLength(1); expect(r.activities[0]!.aiEligible).toBe(false)
  })
})

describe('pojasnilo po uvozu', () => {
  const base = { at: '2026-09-24T10:00:00Z', days: 365, total: 0, usable: 0, stravaStubs: 0, known: 0 }
  it('vse s Strave → opozorilo z rešitvijo (Garmin neposredno)', () => {
    const a = importDiagnosis({ ...base, total: 180, stravaStubs: 180 })!
    expect(a.tone).toBe('warn'); expect(a.title).toMatch(/180 voženj je s Strave/); expect(a.text).toMatch(/NEPOSREDNO/)
  })
  it('del s Strave → samo informacija', () => {
    const a = importDiagnosis({ ...base, total: 10, usable: 7, stravaStubs: 3 })!
    expect(a.tone).toBe('info'); expect(a.title).toBe('3 od 10 voženj je s Strave')
  })
  it('prazen račun → povezava ure; prazno okno pri obstoječih vožnjah → nič', () => {
    expect(importDiagnosis(base)!.title).toMatch(/nima nobene vožnje/)
    expect(importDiagnosis({ ...base, days: 21, known: 40 })).toBeNull()
    expect(importDiagnosis({ ...base, total: 5, usable: 5 })).toBeNull()
    expect(importDiagnosis(null)).toBeNull()
  })
})
