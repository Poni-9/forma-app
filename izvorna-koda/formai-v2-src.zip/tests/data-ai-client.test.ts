import { describe, it, expect, vi, afterEach } from 'vitest'
vi.mock('../src/data/firebase', () => ({ idToken: async () => 'tok' }))
import { askText, AiError, AI_TIMEOUT_MS } from '../src/domain/ai/client'
import { FREE_AI_PER_DAY } from '../src/config'

afterEach(() => { vi.unstubAllGlobals() })

describe('AI odjemalec', () => {
  it('porabljena kvota: brez navodil za Firebase konzolo — »brezplačna dnevna kvota … nova jutri«', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('', { status: 402 })))
    const e = await askText([{ text: 'x' }]).catch(x => x) as AiError
    expect(e.kind).toBe('quota')
    expect(e.message).toMatch(/^Današnja kvota AI \(10\s\S+\) je porabljena — nova se odpre jutri\.$/)
    expect(FREE_AI_PER_DAY).toBe(10)
    expect(e.message).not.toMatch(/Firebase|proUsers|uid/)
  })
  it('vsak klic ima časovno omejitev 90 s; ob izteku brez ponavljanja', async () => {
    expect(AI_TIMEOUT_MS).toBe(90_000)
    const ok = vi.fn(async (_u: string, _i?: RequestInit) => new Response(JSON.stringify({ text: 'ok' }), { status: 200 }))
    vi.stubGlobal('fetch', ok)
    expect(await askText([{ text: 'x' }])).toBe('ok')
    expect(ok.mock.calls[0]![1]!.signal).toBeTruthy()
    const slow = vi.fn(async () => { throw Object.assign(new Error('timeout'), { name: 'TimeoutError' }) })
    vi.stubGlobal('fetch', slow)
    const e = await askText([{ text: 'x' }]).catch(x => x) as AiError
    expect(e.kind).toBe('network'); expect(e.message).toMatch(/90 sekundah/)
    expect(slow).toHaveBeenCalledTimes(1)
  })
})
