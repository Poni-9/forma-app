import { describe, it, expect, vi, afterEach } from 'vitest'
const h = vi.hoisted(() => ({ idToken: vi.fn(async (_force?: boolean) => 'tok') }))
vi.mock('../src/data/firebase', () => ({ idToken: (force?: boolean) => h.idToken(force) }))
import { askText, AiError, AI_TIMEOUT_MS, FALLBACK_MODEL } from '../src/domain/ai/client'
import { FREE_AI_PER_DAY } from '../src/config'

afterEach(() => { vi.unstubAllGlobals() })

describe('AI odjemalec', () => {
  it('porabljena kvota (strežnik {error:limit}): brez navodil za Firebase konzolo — »… nova jutri«', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ error: 'limit', limit: 30 }), { status: 402 })))
    const e = await askText([{ text: 'x' }]).catch(x => x) as AiError
    expect(e.kind).toBe('quota')
    expect(e.message).toMatch(/^Današnja kvota AI \(30\s\S+\) je porabljena — nova se odpre jutri\.$/)
    expect(e.message).not.toMatch(/Firebase|proUsers|uid/)
    // starejši strežnik brez števila → število iz nastavitve (ena visoka meja: 1000 na dan)
    expect(FREE_AI_PER_DAY).toBe(1000)
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ error: 'limit' }), { status: 402 })))
    const e2 = await askText([{ text: 'x' }]).catch(x => x) as AiError
    expect(e2.kind).toBe('quota'); expect(e2.message).toMatch(/^Današnja kvota AI \(1000\s\S+\) je porabljena — nova se odpre jutri\.$/)
  })
  it('402 od Googla (porabljeno predplačilo) NI uporabnikova kvota: sporočilo o ponudniku, brez ponavljanja', async () => {
    const f = vi.fn(async () => new Response(JSON.stringify({ error: { code: 402, message: 'Your prepayment credits are depleted.', status: 'RESOURCE_EXHAUSTED' } }), { status: 402 }))
    vi.stubGlobal('fetch', f)
    const e = await askText([{ text: 'x' }]).catch(x => x) as AiError
    expect(e.kind).toBe('network'); expect(e.message).toMatch(/ponudniku/)
    expect(f).toHaveBeenCalledTimes(1)
    vi.stubGlobal('fetch', vi.fn(async () => new Response('', { status: 402 })))
    expect(((await askText([{ text: 'x' }]).catch(x => x)) as AiError).message).toMatch(/ponudniku/)
    // novejši strežnik: 503 {error:'ai_placilo'} — brez ponavljanja
    const g = vi.fn(async () => new Response(JSON.stringify({ error: 'ai_placilo' }), { status: 503 }))
    vi.stubGlobal('fetch', g)
    expect(((await askText([{ text: 'x' }]).catch(x => x)) as AiError).message).toMatch(/ponudniku/)
    expect(g).toHaveBeenCalledTimes(1)
  })
  it('preobremenjen najnovejši model (503) ali polna kvota (429): takoj rezervni model, brez čakanja', async () => {
    for (const st of [503, 429]) {
      const seen: string[] = []
      const f = vi.fn(async (_u: string, i?: RequestInit) => {
        const m = JSON.parse(String(i!.body)).model as string; seen.push(m)
        return m === FALLBACK_MODEL ? new Response(JSON.stringify({ text: 'ok' }), { status: 200 }) : new Response(JSON.stringify({ error: { code: st, status: 'UNAVAILABLE', message: 'This model is currently experiencing high demand.' } }), { status: st })
      })
      vi.stubGlobal('fetch', f)
      const t0 = Date.now()
      expect(await askText([{ text: 'x' }])).toBe('ok')
      expect(seen).toEqual(['gemini-flash-latest', FALLBACK_MODEL])
      expect(Date.now() - t0).toBeLessThan(1000)
    }
  })
  it('izbrisan ali neveljaven ključ na strežniku (400 API_KEY_INVALID od Googla) → sporočilo o ponudniku', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ error: { code: 400, message: 'API key not valid. Please pass a valid API key.', status: 'INVALID_ARGUMENT', details: [{ reason: 'API_KEY_INVALID' }] } }), { status: 400 })))
    const e = await askText([{ text: 'x' }]).catch(x => x) as AiError
    expect(e.message).toMatch(/ponudniku/)
    // druga 400 (vsebina) ostane splošna napaka
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ error: { code: 400, message: 'Request contains an invalid argument.' } }), { status: 400 })))
    expect(((await askText([{ text: 'x' }]).catch(x => x)) as AiError).message).toMatch(/HTTP 400/)
  })
  it('401 od Googla (ključ na strežniku, npr. ACCESS_TOKEN_TYPE_UNSUPPORTED) ni »prijavi se«, ampak ponudnik — brez ponavljanja', async () => {
    const g = { error: { code: 401, status: 'UNAUTHENTICATED', message: 'Request had invalid authentication credentials.', details: [{ reason: 'ACCESS_TOKEN_TYPE_UNSUPPORTED' }] } }
    const f = vi.fn(async () => new Response(JSON.stringify(g), { status: 401 }))
    vi.stubGlobal('fetch', f)
    const e = await askText([{ text: 'x' }]).catch(x => x) as AiError
    expect(e.kind).toBe('network'); expect(e.message).toMatch(/ponudniku/); expect(f).toHaveBeenCalledTimes(1)
    // novejši strežnik: 503 {error:'ai_kljuc'} → isto
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ error: 'ai_kljuc' }), { status: 503 })))
    expect(((await askText([{ text: 'x' }]).catch(x => x)) as AiError).message).toMatch(/ponudniku/)
  })
  it('naš 401: zavrnjen žeton → enkrat z osveženim žetonom; brez žetona → »prijavi se«', async () => {
    h.idToken.mockClear()
    const f = vi.fn()
      .mockResolvedValueOnce(new Response(JSON.stringify({ error: 'neveljaven_token' }), { status: 401 }))
      .mockResolvedValueOnce(new Response(JSON.stringify({ text: 'ok' }), { status: 200 }))
    vi.stubGlobal('fetch', f)
    expect(await askText([{ text: 'x' }])).toBe('ok')
    expect(h.idToken.mock.calls.map(c => c[0])).toEqual([false, true])
    // drugič zavrnjen tudi osvežen → prijava
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ error: 'neveljaven_token' }), { status: 401 })))
    expect(((await askText([{ text: 'x' }]).catch(x => x)) as AiError).kind).toBe('auth')
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ error: 'prijava_potrebna' }), { status: 401 })))
    expect(((await askText([{ text: 'x' }]).catch(x => x)) as AiError).kind).toBe('auth')
  })
  it('vsak klic ima časovno omejitev 90 s; ob izteku brez ponavljanja', async () => {
    expect(AI_TIMEOUT_MS).toBe(90_000)
    const ok = vi.fn(async (_u: string, _i?: RequestInit) => new Response(JSON.stringify({ text: 'ok' }), { status: 200 }))
    vi.stubGlobal('fetch', ok)
    expect(await askText([{ text: 'x' }])).toBe('ok')
    expect(ok.mock.calls[0]![1]!.signal).toBeTruthy()
    const slow = vi.fn(async () => { throw Object.assign(new Error('timeout'), { name: 'TimeoutError' }) })
    vi.stubGlobal('fetch', slow)
    const e = await askText([{ text: 'x' }]).catch(x => x) as AiError
    expect(e.kind).toBe('network'); expect(e.message).toMatch(/90 sekundah/)
    expect(slow).toHaveBeenCalledTimes(1)
  })
})
