import { describe, it, expect, vi, afterEach, beforeEach } from 'vitest'
import { fetchActivities, fetchStreams, IcuBusy, resetIcuPause } from '../src/domain/intervals/client'

const C = { athleteId: '0', apiKey: '', token: 'tok' }
beforeEach(() => resetIcuPause())
afterEach(() => { vi.unstubAllGlobals(); resetIcuPause() })

describe('kvote intervals.icu (429)', () => {
  it('ob 429 počaka po Retry-After in medtem ne kliče', async () => {
    const f = vi.fn(async () => new Response('', { status: 429, headers: { 'Retry-After': '120' } }))
    vi.stubGlobal('fetch', f)
    await expect(fetchActivities(C, '2026-09-01', '2026-09-25')).rejects.toBeInstanceOf(IcuBusy)
    await expect(fetchActivities(C, '2026-09-01', '2026-09-25')).rejects.toThrow(/preveč zahtevkov.*2 min/)
    expect(f).toHaveBeenCalledTimes(1)
  })
  it('brez Retry-After počaka 5 min', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('', { status: 429 })))
    const e = await fetchActivities(C, '2026-09-01', '2026-09-25').catch(x => x) as IcuBusy
    expect(Math.round((e.until - Date.now()) / 60000)).toBe(5)
  })
  it('sled: napaka strežnika ali kvota → napaka (vožnja ostane za naslednjič); ni sledi → null', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('', { status: 503 })))
    await expect(fetchStreams(C, 123)).rejects.toThrow(/503/)
    vi.stubGlobal('fetch', vi.fn(async () => new Response('', { status: 404 })))
    expect(await fetchStreams(C, 123)).toBeNull()
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify([{ type: 'watts', data: [1] }]), { status: 200 })))
    expect(await fetchStreams(C, 123)).toBeNull()
    vi.stubGlobal('fetch', vi.fn(async () => new Response('', { status: 429 })))
    await expect(fetchStreams(C, 123)).rejects.toBeInstanceOf(IcuBusy)
  })
})
