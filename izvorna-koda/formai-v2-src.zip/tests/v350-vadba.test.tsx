// v3.50 VADBA — vodena vadba, Vaje, trase: gel ne sredi testa (A02), ponovitve brez privzete zgornje meje (A04), trasa po
// trajanju (A05), nov pražni utrip v načrtu in zapis testa (A17, A18), kg pri vajah z lastno težo (A19), zamenjava po mišici
// (A20), kadenca s ciljem kadence (A21), hribi brez kolesarskih napotkov in z »Vzemi s seboj« (A23), figura namesto napačne
// fotografije (A24), moč po serijah (A25, A32), oznaka teka (A31), besedila testa (A33), tipkovnica (A35), litri in legenda
// goriva (A36), tekma brez deleža iz ogrevanja (A37), list vaje (A38), naslov Vaj (A39), enota cone (A40), FTP »od naslednjega
// tedna« (A45), trajanje seje moči (C04, H18), »od« se ne spreminja (H45), vati samo s FTP in »po urniku« samo z opomniki
// (H19), obvestila na vrhu (G05), kontrast čipa (G36), bralnik ob menjavi koraka (G38).
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { existsSync, readFileSync } from 'node:fs'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'vadba', params: {} as Record<string, string> } }))
vi.mock('@/state/store', async () => {
  const { vi: v } = await import('vitest')
  const base: Record<string | symbol, unknown> = {
    useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
    getState: () => S.state,
    routePace: () => ({ k: 1, adj: { n: 0, adj: 1 } }),
  }
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' || typeof k === 'symbol' ? undefined : (t[k] = v.fn(async () => ({ added: 1, dupes: 0, upgraded: 0 })))), has: (_t, k) => k !== 'then' })
})
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => S.route }))

import * as store from '@/state/store'
import { Vadba, TestResult, RUN_KEY, holdCue, hikeItems, stepAnnounce, setsOf } from '@/screens/Vadba'
import { Vaje } from '@/screens/Vaje'
import { RouteCard } from '@/ui/RouteCard'
import { FuelTimeline, l1 } from '@/ui/FuelTimeline'
import { stepsFor, structureLines, totalSec, raceTarget, rescaleHr } from '@/domain/training/workout'
import { swapOptions, strengthMinutes, exByName } from '@/domain/training/exercises'
import { strengthDay } from '@/domain/training/focusPlan'
import { routeFits } from '@/domain/routes/match'
import { rideFuel, type RideFuel } from '@/domain/nutrition/dayplan'
import { effortOf } from '@/domain/training/effort'
import { kindLabelOf } from '@/ui/primitives'
import { hasPhoto } from '@/ui/figure/photos'
import { templateFor } from '@/ui/figure/templates'
import { topOf } from '@/ui/figure/ExerciseFigure'
import { accentDeep, contrast, mixOver, LIGHT_SOFT } from '@/ui/theme'
import { encodePolyline, type LatLon } from '@/domain/import/polyline'
import type { AgreedSession, Focus, PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-18'
const NOW = `${TODAY}T08:00:00.000Z`
/** z merilnikom, FTP 250 */
const P = { sex: 'm', age: 35, heightCm: 180, weightKg: 75, ftp: 250, ftpDate: '2026-09-01', gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true }, strength: { on: false, equipment: 'none' }, onboardingDone: true, hoursPerWeek: 8, goal: 'forma', createdAt: NOW, updatedAt: NOW } as unknown as Profile
/** Blaž: brez merilnika, LTHR 184 */
const NOPM = { ...P, ftp: 240, gear: { ...P.gear, powerMeter: false }, lthr: 184, maxHr: 195, restHr: 50 } as Profile
const day = (o: Partial<PlanDay>): PlanDay => ({ id: 'd1', date: TODAY, kind: 'kolo', title: 'Z2 vožnja', desc: 'Enakomerno v Z2.', durationMin: 60, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, ...o } as PlanDay)
const ride = day({})
const long = day({ id: 'd2', title: 'Dolga Z2', durationMin: 105, role: 'dolga' })
const test = day({ id: 't1', kind: 'test', title: '20-minutni test FTP', desc: 'Test.', durationMin: 60, zone: 'test', role: 'test' })
const homeLegs = day({ id: 'm1', kind: 'moc', title: 'Moč — noge in jedro', desc: 'Doma, brez opreme.', durationMin: 30, zone: null, role: 'moc', exercises: [{ name: 'Bolgarski počep', sets: 3, reps: '8–12' }] })
const raceDay = day({ id: 'r1', title: 'Kronometer Vodice — 18 km', desc: 'Zajtrk 2–3 h pred startom (1–2 g OH na kg). Ogrevanje 25 min s 3 × 2 min na pragu. Prvih 5 min pri utripu 178–184 (ne prehitro), nato pri utripu 184–188, zadnje 3 min vse.', durationMin: 30, zone: 'dirka', role: 'dirka', raceId: 'r1', date: '2026-10-23' })

const reset = (plan: PlanDay[], o: Record<string, unknown> = {}) => {
  S.state = { ready: true, today: TODAY, plan, activities: [], recentMeals: [], mealsToday: [], checkins: [], weather: null, routeLib: null, routesBusy: false, settings: { lang: 'sl', intervals: null }, toast: null, profile: P, user: null, changes: [], sync: { state: 'ok' }, ...o }
}
const fn = (k: string) => (store as unknown as Record<string, ReturnType<typeof vi.fn>>)[k]!
let div: HTMLDivElement | null = null, root: Root | null = null
async function render(el: ReactElement) {
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root!.render(el) })
  return div
}
const sp = (x: string | null | undefined) => (x || '').replace(/[\u00a0\u202f\u2007\u2009\u2060]/g, ' ')
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(sp(b.textContent))) as HTMLButtonElement | undefined
const sheetBtn = (re: RegExp) => [...document.querySelectorAll('.sheet button')].find(b => re.test(sp(b.textContent))) as HTMLButtonElement | undefined
const tick = async (ms: number) => { await act(async () => { vi.advanceTimersByTime(ms) }) }
const flush = async () => { for (let i = 0; i < 6; i++) await act(async () => { await Promise.resolve() }) }
const open = async (d: PlanDay) => { S.route = { name: 'vadba', params: { id: d.id } }; return render(<Vadba />) }
const start = async () => { await act(async () => { btn(/^Začni trening$/)!.click() }) }
const skip = async () => { await act(async () => { (document.querySelector('button[aria-label="Preskoči korak"]') as HTMLButtonElement).click() }) }
const sum = () => sp(div!.querySelector('.run-sum')!.textContent)
const type = async (el: HTMLInputElement, v: string) => { await act(async () => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(el, v); el.dispatchEvent(new Event('input', { bubbles: true })) }) }

beforeEach(() => {
  vi.useFakeTimers(); vi.setSystemTime(new Date(`${TODAY}T10:00:00`)); sessionStorage.clear(); localStorage.clear(); S.subs.clear()
  for (const k of ['setPlanDone', 'addActivities', 'updateProfile', 'addTest', 'updatePlanDays', 'toast']) fn(k).mockClear()
})
afterEach(async () => { if (root) { await act(async () => root!.unmount()); root = null } div?.remove(); document.body.innerHTML = ''; vi.useRealTimers() })

/* ------------------------------------------------------------ domena ------------------------------------------------------------ */
describe('koraki vodene vadbe', () => {
  it('A02 opomnik za gel počaka do konca testa (korak test brez skupine), pokaže se v izteku', () => {
    const st = stepsFor(test, P)
    const t = st.find(s => s.kind === 'test')!
    expect(holdCue(t)).toBe(true)
    // gel ob 30. minuti pade v test (20.–40. min) — zato ga je treba zadržati
    const from = st.slice(0, st.indexOf(t)).reduce((a, s) => a + s.sec, 0) / 60
    expect(rideFuel(test)!.cues.some(c => c.atMin >= from && c.atMin < from + 20)).toBe(true)
    expect(holdCue(st.find(s => s.kind === 'iztek'))).toBe(false)
  })
  it('A21 »4 × 30 s hitra kadenca«: cilj je kadenca in lahka prestava, ne utrip', () => {
    const d = day({ title: 'Z2 + 4 × 30 s pospeški', desc: 'Lahko utrip 149–164; na sredi 4 × 30 s hitra kadenca (ne sila). Razbremenilni teden.', durationMin: 40 })
    const k = stepsFor(d, NOPM).filter(s => /^Kadenca/.test(s.label))
    expect(k).toHaveLength(4)
    expect(k.every(s => s.target === 'kadenca 100–110 · lahka prestava')).toBe(true)
    expect(structureLines(stepsFor(d, NOPM)).join(' | ')).toContain('4 × 30 s (kadenca 100–110 · lahka prestava), vmes 4 min lahko')
  })
  it('A23 hribi in tek: brez »kadenca 85–95« in »noge vrtijo«', () => {
    const hike = day({ kind: 'pohod', title: 'Hribi namesto kolesa', desc: 'Hoja v hribe. Voda, nekaj za pojest.', durationMin: 120 })
    const st = stepsFor(hike, NOPM)
    expect(st[0]!.note).toBe('Hitra hoja, da se ogreješ.')
    expect(st.map(s => s.note || '').join(' ')).not.toMatch(/kadenc|vrtijo|Vrti/i)
    const run = day({ kind: 'tek', title: 'Tempo tek — 45 min', desc: '15 min lahkega teka, nato 2 × 10 min tempo, vmes 3 min lahko.', durationMin: 45, zone: 'Z3', role: 'kljucna' })
    expect(stepsFor(run, NOPM).map(s => s.note || '').join(' ')).not.toMatch(/kadenc|vrtijo|Vrti/i)
    expect(hikeItems(120)).toEqual(['~1 l vode', '2 × prigrizek (banana, ploščica) — na vsako uro eden'])
    expect(hikeItems(45)).toBeNull()
  })
  it('A33 test: »20 min test (…)«, »5 min lahko« z malo; na polno je beseda, test pripis', () => {
    const lines = structureLines(stepsFor(test, NOPM))
    expect(lines).toContain('20 min test (čim močneje, enakomerno)')
    expect(lines.some(l => /^5 min lahko \(/.test(l))).toBe(true)
    expect(lines.join(' ')).not.toMatch(/20-minutni|Lahko/)
    expect(effortOf(test)).toMatchObject({ w: 'na polno', sub: 'test 20 min' })
  })
  it('A17 nov pražni utrip: tempo tekme po trenutnem pragu (ne iz shranjenega opisa); opis se preračuna', () => {
    const p190 = { ...NOPM, lthr: 190 }
    expect(raceTarget(raceDay.desc, p190)).toBe('utrip 190–194')
    expect(stepsFor(raceDay, p190).find(s => s.label === 'Tekma')!.target).toBe('utrip 190–194')
    expect(stepsFor(raceDay, NOPM).find(s => s.label === 'Tekma')!.target).toBe('utrip 184–188')
    expect(rescaleHr(raceDay.desc, 184, 190)).toContain('Prvih 5 min pri utripu 184–190 (ne prehitro), nato pri utripu 190–194')
    expect(rescaleHr('Lahko utrip 149–164; na koncu utrip pod 149.', 184, 190)).toBe('Lahko utrip 154–169; na koncu utrip pod 154.')
  })
  it('H18 tek in hoja »na koncu 5 min hoje«: iztek 5 min (prej 7), trajanje kot v načrtu', () => {
    const d = day({ kind: 'tek', title: 'Tek in hoja — 6 × 2 min teka', desc: '5 min hitre hoje, nato 6 × (2 min tek / 1 min hoja). Na koncu 5 min hoje.', durationMin: 29 })
    const st = stepsFor(d, NOPM)
    expect(st[st.length - 1]).toMatchObject({ kind: 'iztek', sec: 300 })
    expect(totalSec(st)).toBe(29 * 60)
  })
})

describe('seja moči: trajanje in zamenjava', () => {
  const f = (o: Partial<Focus>) => ({ by: 'rules', sessions: [], equipment: [], level: 2, aims: [], muscles: [], limits: null, ...o } as unknown as Focus)
  /** čas vodene vadbe: časovniki + 35 s na serijo brez časovnika */
  const run = (fx: Focus, s: AgreedSession) => {
    const d0 = strengthDay(P, { ...fx, sessions: [s] }, s, { volume: 1, recovery: false, week: 1 }, [])
    const d = day({ kind: 'moc', title: d0.title, desc: d0.desc, durationMin: d0.min, zone: null, role: 'moc', exercises: d0.exercises })
    const st = stepsFor(d, P)
    return (totalSec(st) + st.filter(x => x.kind === 'vaja' && x.sec === 0).length * 35) / 60
  }
  it('C04 fitnes 45 min (moč, hujšanje): vodena vadba ≤ 45 min + 10 % (prej 53 min)', () => {
    const m = run(f({ equipment: ['utezi'], level: 2, aims: ['moc', 'hujsanje'] }), { type: 'fitnes', part: 'zgornji', min: 45 } as AgreedSession)
    expect(m).toBeLessThanOrEqual(45 * 1.1)
    expect(m).toBeGreaterThanOrEqual(45 * 0.75)
  })
  it('H18 doma 30 min brez opreme: ±5 min od 30 (prej 3 vaje = 22 min)', () => {
    const m = run(f({ level: 1, aims: ['kondicija'] }), { type: 'doma', part: 'celo', min: 30 } as AgreedSession)
    expect(Math.abs(m - 30)).toBeLessThanOrEqual(5)
  })
  it('strengthMinutes: ogrevanje, serije, pavze, raztezanje', () => {
    expect(strengthMinutes([{ name: 'Počep', sets: 3, reps: '10–12', rest: 60 }])).toBe(Math.round((300 + 240 + 3 * 35 + 2 * 60) / 60))
  })
  it('A20 bolgarski počep doma brez opreme: zamenjava z isto mišico (prej nič)', () => {
    const o = swapOptions('Bolgarski počep', { where: 'doma', equip: [], level: 2 }, ['Bolgarski počep', 'Izpadni koraki', 'Dvigi na prste', 'Deska'])
    expect(o.map(x => x.name)).toContain('Počep')
    expect(o.every(x => ['noge', 'zadnjica'].includes(x.m[0]!) && x.pat !== 'kondicija')).toBe(true)
    // ista vrsta (deska → stranska deska) ostane po vzorcu
    expect(swapOptions('Deska', { where: 'doma', equip: [], level: 2 }).every(x => x.pat === 'trebuh')).toBe(true)
  })
})

describe('drugo', () => {
  it('A31 »Tempo tek«, »Daljši lahek tek« = Tek; »Tek in hoja« ostane', () => {
    expect(kindLabelOf({ kind: 'tek', title: 'Tempo tek — 30 min' })).toBe('Tek')
    expect(kindLabelOf({ kind: 'tek', title: 'Daljši lahek tek — 60 min' })).toBe('Tek')
    expect(kindLabelOf({ kind: 'tek', title: 'Tek in hoja — 6 × 2 min teka' })).toBe('Tek in hoja')
  })
  it('A24 napačne fotografije ven — figura (hip thrust z ročko z ročko, ne s palico)', () => {
    for (const id of ['bolgarski', 'hip-r', 'zasuki-r']) {
      expect(hasPhoto(id)).toBe(false)
      expect(existsSync(`public/vaje/${id}-0.webp`)).toBe(false)
    }
    expect(templateFor('hip-r', 'pavza').equip).toContain('dumbbell-hips')
    expect(templateFor('zasuki-r', 'pavza').equip).toContain('dumbbell-chest')
    expect(hasPhoto('hip-p')).toBe(true)
  })
  it('A38 figura ležeče vaje brez praznine nad telesom; z drogom okvir ostane cel', () => {
    expect(topOf(templateFor('deska', 'pavza'))).toBeGreaterThan(40)
    expect(topOf(templateFor('zgibi', 'pavza'))).toBe(0)
  })
  it('A36 litri na 0,25 l (bidon 0,75 l); legenda brez »pitje«, ko ni opomnikov pitja', async () => {
    // (v3.51 PREHRANA, D05) en zapis litrov za časovnico in besedilo (na 0,05 l): 400 ml je »0,4«, ne »0,5«
    expect(l1(750)).toBe('0,75'); expect(l1(1500)).toBe('1,5'); expect(l1(400)).toBe('0,4')
    const rf = { cues: [{ atMin: 30, solid: true, short: 'gel', text: 'Pojej gel.' }], carriedCarbs: 25, fluidMl: 750, everyMin: 0 } as unknown as RideFuel
    await render(<FuelTimeline rf={rf} minutes={60} />)
    expect(div!.querySelector('.legend .cue.drink')).toBeNull()
    expect(sp(div!.querySelector('.legend')!.textContent)).toContain('~0,75 l')
  })
  it('A05 trasa za 2 h ni predlog za 40 min', () => {
    expect(routeFits(121, 40)).toBe(false)
    expect(routeFits(60, 40)).toBe(true)
  })
  it('G05 obvestilo med vodeno vadbo na vrhu (ne čez Pavza / Preskoči)', () => {
    expect(readFileSync('src/styles/base.css', 'utf8')).toContain('body:has(.run-main):not(:has(.sheet)) .toast { bottom: auto; top:')
  })
  it('G36 poudarek za besedilo ≥ 4,5 : 1 tudi na mehki podlagi čez globlje ozadje (prej 4,41)', () => {
    for (const a of ['#A3E635', '#84CC16', '#4ADE80', '#2DD4BF']) expect(contrast(accentDeep(a), mixOver(a, '#E9EDE5', LIGHT_SOFT)), a).toBeGreaterThanOrEqual(4.5)
    expect(readFileSync('src/styles/tokens.css', 'utf8')).toContain(`--accent-deep: ${accentDeep('#A3E635')};`)
  })
  it('G38 besedilo za bralnik ob menjavi koraka', () => {
    expect(stepAnnounce(1, 11, { kind: 'lahko', label: 'Z2 vzdržljivost', sec: 480, target: 'utrip 149–164' })).toBe('Korak 2 od 11: Z2 vzdržljivost, 8 minut, utrip 149 do 164')
  })
  it('setsOf: vpisane serije in serije na čas, ki so mimo', () => {
    const st = stepsFor(day({ kind: 'moc', exercises: [{ name: 'Deska', sets: 2, reps: '40 s' }, { name: 'Počep', sets: 2, reps: '10' }] }), P)
    const k = st.findIndex(s => s.label === 'Počep')
    expect(setsOf({ steps: st, i: k, log: {} })).toEqual({ done: 2, all: 4 })
    expect(setsOf({ steps: st, i: k + 1, log: { [k]: { kg: null, reps: 10 } } })).toEqual({ done: 3, all: 4 })
  })
})

/* ------------------------------------------------------------ zasloni ------------------------------------------------------------ */
describe('Vadba (zaslon)', () => {
  it('A02 med testom brez opomnika za gel; v izteku pride', async () => {
    reset([test])
    await open(test); await start()
    await tick(30 * 60_000 + 10_000)                                   // 30:10 — gel po urniku, a sredi testa (20.–40. min)
    expect(div!.textContent).toContain('Test')
    expect(div!.textContent).not.toContain('tapni, ko je opravljeno')
    await tick(10 * 60_000)                                            // 40:10 — iztek (opomnik izgine po 45 s)
    expect(div!.textContent).toContain('Iztek')
    expect(div!.textContent).toContain('tapni, ko je opravljeno')
  })

  it('A04/A19 moč doma: ponovitve prazne (ne 12), namig; kg (nahrbtnik) pri bolgarskem počepu; »Narejeno« brez dotika ne zapiše 12', async () => {
    reset([homeLegs])
    await open(homeLegs); await start(); await skip()
    expect(div!.querySelector('.stepper b')!.textContent).toBe('—')
    expect(sp(div!.textContent)).toContain('Vpiši, koliko ponovitev si res naredil (načrt 8–12).')
    expect(div!.querySelector('input[aria-label="Kilogrami"]')).toBeTruthy()
    expect(sp(div!.textContent)).toContain('kg (nahrbtnik)')
    await act(async () => { btn(/^Narejeno/)!.click() })
    expect(JSON.parse(sessionStorage.getItem(RUN_KEY)!).log[1]).toEqual({ kg: null, reps: null })
  })

  it('A04 z zadnjo vadbo: predlog je, kar si res naredil zadnjič (najslabša serija)', async () => {
    reset([homeLegs], { activities: [{ id: 'a1', source: 'manual', sport: 'moc', date: '2026-10-14', name: 'Moč — noge in jedro', durationMin: 30, exercises: [{ name: 'Bolgarski počep', sets: 3, reps: '10, 10, 9', kg: null }] }] })
    await open(homeLegs); await start(); await skip()
    expect(div!.querySelector('.stepper b')!.textContent).toBe('9')
  })

  it('A20 bolgarski počep doma (izpadni in prsti so že v seji): »Zamenjaj vajo« z isto mišico', async () => {
    const legs = { ...homeLegs, exercises: [{ name: 'Bolgarski počep', sets: 3, reps: '8–12' }, { name: 'Izpadni koraki', sets: 3, reps: '10–12' }, { name: 'Dvigi na prste', sets: 3, reps: '15–20' }] }
    reset([legs], { profile: { ...P, strength: { on: true, equipment: 'none' } } })
    await open(legs); await start(); await skip()
    await act(async () => { btn(/^Zamenjaj vajo$/)!.click() })
    expect(sp(document.querySelector('.sheet')!.textContent)).toContain('Ista mišica, druga vaja.')
    expect(sheetBtn(/^Počep/)).toBeTruthy()
  })

  it('A25/A32 moč po 20 s: »Narejeno 0 od 3 serij«, brez shranjevanja; »Skupaj« šteje serije, ne minut', async () => {
    reset([homeLegs])
    await open(homeLegs); await start()
    await tick(20_000)
    expect(sum()).not.toMatch(/ od \d+:\d\d/)
    expect(sum()).toContain('0 od 3 serij')
    await act(async () => { (div!.querySelector('.run-end') as HTMLButtonElement).click() })
    const sh = sp(document.querySelector('.sheet')!.textContent)
    expect(sh).toContain('Narejeno 0 od 3 serij')
    expect(sheetBtn(/Shrani/)).toBeUndefined()
    await act(async () => { sheetBtn(/^Prekini brez oznake$/)!.click() })
    await flush()
    expect(fn('addActivities')).not.toHaveBeenCalled()
    expect(fn('setPlanDone')).not.toHaveBeenCalled()
  })

  it('A25 moč z večino serij: potrditev »(2 od 3 serij)«, zapis z dejanskimi minutami (ne najmanj 10)', async () => {
    reset([homeLegs])
    await open(homeLegs); await start(); await skip()
    await act(async () => { (document.querySelector('button[aria-label="Ena ponovitev več"]') as HTMLButtonElement).click() })      // prazno → spodnja meja 8
    await act(async () => { btn(/^Narejeno/)!.click() })
    await skip()                                                      // pavza
    await act(async () => { btn(/^Narejeno/)!.click() })
    expect(sum()).toContain('2 od 3 serij')
    await act(async () => { (div!.querySelector('.run-end') as HTMLButtonElement).click() })
    expect(sp(document.querySelector('.sheet')!.textContent)).toContain('Dan se označi kot opravljen (2 od 3 serij).')
    await act(async () => { sheetBtn(/^Zaključi$/)!.click() })
    await flush()
    const a = (fn('addActivities').mock.calls[0]![0] as { durationMin: number; exercises: { reps: string }[] }[])[0]!
    expect(a.durationMin).toBe(1)
    expect(a.exercises[0]!.reps).toBe('8, 8')
  })

  it('A23 hribi: »Vzemi s seboj« voda in prigrizek', async () => {
    const hike = day({ id: 'h1', kind: 'pohod', title: 'Hribi namesto kolesa', desc: 'Hoja v hribe. Voda, nekaj za pojest.', durationMin: 120 })
    reset([hike], { profile: NOPM })
    await open(hike)
    const t = sp(div!.textContent)
    expect(t).toContain('Vzemi s seboj')
    expect(t).toContain('~1 l vode')
  })

  it('A37 tekma: »Zaključi« med ogrevanjem brez deleža; po startu čas tekme', async () => {
    reset([raceDay], { profile: NOPM, today: '2026-10-23' })
    vi.setSystemTime(new Date('2026-10-23T10:00:00'))
    await open(raceDay); await start()
    await tick(4_000)
    await act(async () => { (div!.querySelector('.run-end') as HTMLButtonElement).click() })
    let sh = sp(document.querySelector('.sheet')!.textContent)
    expect(sh).not.toMatch(/% treninga/)
    expect(sh).toContain('Dan se označi kot opravljen (1 min).')
    await act(async () => { sheetBtn(/Prekliči|Ne/)?.click() })
    await act(async () => root!.unmount()); root = null; div!.remove(); sessionStorage.clear()
    await open(raceDay); await start(); await skip()
    await tick(10_000)
    await act(async () => { btn(/^Zaključi$/)!.click() })
    sh = sp(document.querySelector('.sheet')!.textContent)
    expect(sh).toContain('Tekma je trajala 0:10.')
  })

  it('A35 tipkovnica: presledek pavza / nadaljuj, → naprej', async () => {
    reset([ride])
    await open(ride); await start()
    await act(async () => { window.dispatchEvent(new KeyboardEvent('keydown', { key: ' ' })) })
    expect(sum()).toContain('· pavza')
    await act(async () => { window.dispatchEvent(new KeyboardEvent('keydown', { key: ' ' })) })
    expect(sum()).not.toContain('pavza')
    await act(async () => { window.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight' })) })
    expect(div!.textContent).toContain(`2 / ${stepsFor(ride, P).length}`)
    expect(div!.querySelector('.run-keys')!.textContent).toBe('presledek: pavza · → naprej · ← nazaj')
  })

  it('A40 ploščica cone brez merilnika: »utrip 149–164« (prej samo številke)', async () => {
    reset([ride], { profile: NOPM })
    await open(ride)
    expect([...div!.querySelectorAll('.kpi small')].map(x => sp(x.textContent))).toContain('utrip 149–164')
  })

  it('H45 »od« ostane cel trening po »Preskoči«; preskočeno v »še …«', async () => {
    reset([long])
    await open(long); await start()
    await tick(4_000)
    expect(sum()).toMatch(/^Skupaj 0:00:04 od 1:45:00/)
    await skip()
    expect(sum()).toMatch(/^Skupaj 0:00:04 od 1:45:00 · še 1 h 3\d min/)
  })

  it('H19 merilnik brez FTP: »utrip ali občutek«; lahka 80-min vožnja brez opomnikov: »Pij po žeji«, ne »aplikacija te opomni«', async () => {
    const d = day({ durationMin: 80 })
    reset([d], { profile: { ...P, ftp: null } })
    await open(d)
    expect(sp(div!.textContent)).toContain('Med treningom: utrip ali občutek za vsak korak')
    await start(); await skip()
    const t = sp(div!.textContent)
    expect(t).toContain('Pij po žeji.')
    expect(t).not.toContain('aplikacija te opomni')
  })

  it('G38 živo območje: »Korak 1 od 3: Ogrevanje …«, po »Preskoči« »Korak 2 od 3«', async () => {
    reset([ride])
    await open(ride); await start()
    const live = () => sp(div!.querySelector('.sr-only[role="status"]')!.textContent)
    expect(live()).toMatch(/^Korak 1 od 3: Ogrevanje, \d+ minut/)
    await skip()
    expect(live()).toMatch(/^Korak 2 od 3: /)
  })
})

describe('Rezultat testa (A17, A18, A45)', () => {
  it('brez merilnika: zapis testa »lthr«, opisi neopravljenih dni po novem pragu, besedilo', async () => {
    const past = { ...raceDay, id: 'old', date: '2026-10-10' }
    const done = { ...raceDay, id: 'dn', date: '2026-10-19', done: { at: NOW } }
    reset([test, raceDay, past, done], { profile: NOPM })
    await render(<TestResult />)
    await type(document.getElementById('test-hr') as HTMLInputElement, '190')
    await act(async () => { btn(/^Shrani$/)!.click() })
    await flush()
    expect(fn('updateProfile')).toHaveBeenCalledWith({ lthr: 190 })
    expect(fn('addTest')).toHaveBeenCalledWith(expect.objectContaining({ kind: 'lthr', value: 190, unit: 'bpm', date: TODAY }))
    const days = fn('updatePlanDays').mock.calls[0]![0] as PlanDay[]
    expect(days.map(d => d.id)).toEqual(['r1'])
    expect(days[0]!.desc).toContain('nato pri utripu 190–194')
    expect(sp(div!.textContent)).toContain('Nov pražni utrip 190 — cone in utrip v načrtu so posodobljeni.')
  })
  it('z merilnikom: FTP »v vodeni vadbi takoj, v načrtu od naslednjega tedna«', async () => {
    reset([test], { profile: { ...P, ftp: 247, ftpDate: TODAY } })
    await render(<TestResult />)
    expect(sp(div!.textContent)).toContain('FTP 247 W — v vodeni vadbi takoj, v načrtu od naslednjega tedna.')
  })
})

describe('Vaje in trasa', () => {
  it('A38/A39 list vaje: zahtevnost, opozorilo iz omejitev; po »Zapri« naslov brez ?v=', async () => {
    reset([])
    history.replaceState(null, '', '#/vaje?v=bolgarski')
    S.route = { name: 'vaje', params: { v: 'bolgarski' } }
    await render(<Vaje />)
    const t = sp(document.querySelector('.sheet')!.textContent)
    expect(t).toContain('zahtevnost srednja')
    expect(t).toContain('Previdno, če te boli: koleno.')
    expect(exByName('Bolgarski počep')!.avoid).toEqual(['koleno'])
    await act(async () => { sheetBtn(/^Zapri$/)!.click() })
    expect(location.hash).toBe('#/vaje')
    expect(document.querySelector('.sheet')).toBeNull()
  })

  it('A05 40-min vožnja in edina trasa za ~2 h: kartica »nimaš dovolj kratke trase« in »Vseeno pokaži«', async () => {
    // krog 54 km okoli Vodic, raven
    const c: LatLon = [46.19, 14.49], r = 54 / (2 * Math.PI)
    const pts: LatLon[] = Array.from({ length: 241 }, (_, k) => { const a = (k / 240) * 2 * Math.PI; return [c[0] + (r / 111) * Math.sin(a), c[1] + (r / (111 * Math.cos((c[0] * Math.PI) / 180))) * Math.cos(a)] as LatLon })
    const rec = { id: 'v1', source: 'voznja', name: 'Krog proti jugovzhodu', date: '2026-10-01', km: 54, gainM: 0, rodeMin: 120, loop: true, start: pts[0]!, poly: encodePolyline(pts), prof: Array(1081).fill(300), climbs: [], hilly: 0, times: 3 }
    const d = day({ id: 'k1', title: 'Z2 + 4 × 30 s pospeški', desc: 'Lahko; na sredi 4 × 30 s hitra kadenca (ne sila).', durationMin: 40 })
    reset([d], { routeLib: { v: 1, raw: [], gen: [rec], home: null, done: [], at: 0 }, settings: { lang: 'sl', intervals: { athleteId: 'i1', apiKey: 'k' } } })
    await render(<RouteCard day={d} compact />)
    const t = sp(div!.textContent)
    expect(t).toMatch(/Za 40 min nimaš dovolj kratke trase \(najkrajša ~[12] h/)
    expect(div!.querySelector('svg[aria-label="Oris trase"]')).toBeNull()
    await act(async () => { btn(/^Vseeno pokaži$/)!.click() })
    expect(sp(div!.textContent)).toContain('54 km')
  })
})
