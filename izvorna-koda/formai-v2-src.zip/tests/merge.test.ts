import { describe, it, expect } from 'vitest'
import { mergeState, mergeMeals, mergeActivities, mergePlan, mergeCheckins, mergeProfile, mergeSettings, stableStr, tombMeal, tombAct, tombTest, type SyncState } from '../src/data/merge'
import { toCloud, fromCloud } from '../src/data/sync'
import type { Activity, MealEntry, PlanDay, Profile, Settings } from '../src/domain/types'

const T = (h: number) => new Date(Date.UTC(2026, 8, 24, h)).toISOString()
const NOW = Date.UTC(2026, 8, 24, 20)
const meal = (id: string, o: Partial<MealEntry> = {}): MealEntry => ({ id, date: '2026-09-24', slot: 'kosilo', name: id, kcal: 500, source: 'photo', createdAt: T(12), ...o })
const act = (id: string, o: Partial<Activity> = {}): Activity => ({ id, source: 'intervals', sport: 'kolo', date: '2026-09-24', start: '2026-09-24T14:00:00Z', name: 'Vožnja', aiEligible: true, geoRetain: true, createdAt: T(15), updatedAt: T(15), ...o })
const day = (id: string, date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id, date, kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, source: 'rules', createdAt: T(1), updatedAt: T(1), ...o })
const prof = (o: Partial<Profile> = {}): Profile => ({ sex: 'm', gear: { bikeOutdoor: true, trainer: false, noBike: false }, strength: { on: false, equipment: 'none' }, onboardingDone: true, name: 'Blaž', createdAt: T(0), updatedAt: T(1), ...o })
const st = (o: Partial<SyncState> = {}): SyncState => ({ profile: prof(), settings: { lang: 'sl' }, activities: [], plan: [], meals: [], checkins: [], tomb: {}, ...o })

describe('sinhronizacija — nobena naprava ne pobriše druge', () => {
  it('obroki s telefona ostanejo, ko je računalnik »novejši« zaradi samodejnega uvoza vožnje', () => {
    const phone = st({ meals: [meal('zajtrk', { thumb: 'SLIKA' }), meal('kosilo')], activities: [act('p1', { ext: { intervalsId: 'i1' } })] })
    const desktop = st({ activities: [act('d1', { ext: { intervalsId: 'i1' } }), act('d2', { ext: { intervalsId: 'i2' }, start: '2026-09-24T16:00:00Z', updatedAt: T(18), createdAt: T(18) })], profile: prof({ updatedAt: T(18) }) })
    const cloud = fromCloud(toCloud(phone, 1).payload)        // telefon je poslal (brez sličic)
    const m = mergeState(desktop, cloud, NOW)                  // računalnik združi namesto prepiše
    expect(m.meals.map(x => x.id).sort()).toEqual(['kosilo', 'zajtrk'])
    expect(m.activities).toHaveLength(2)                       // i1 enkrat, i2 nova
    const back = mergeState(phone, fromCloud(toCloud(m, 2).payload), NOW)   // telefon prevzame združeno
    expect(back.meals.map(x => x.id).sort()).toEqual(['kosilo', 'zajtrk'])
    expect(back.meals.find(x => x.id === 'zajtrk')?.thumb).toBe('SLIKA')   // sličica ostane na telefonu
    expect(back.activities.map(a => a.ext?.intervalsId).sort()).toEqual(['i1', 'i2'])
  })

  it('izbris velja na vseh napravah (grob), ne vstane', () => {
    const phone = st({ meals: [meal('b')], tomb: { [tombMeal('a')]: NOW - 1000 } })
    const desktop = st({ meals: [meal('a'), meal('b')] })
    expect(mergeState(desktop, phone, NOW).meals.map(x => x.id)).toEqual(['b'])
    expect(mergeState(phone, desktop, NOW).meals.map(x => x.id)).toEqual(['b'])
  })

  it('stari grobovi (nad 120 dni) se pobrišejo', () => {
    const m = mergeState(st({ tomb: { [tombMeal('x')]: NOW - 130 * 86400_000, [tombMeal('y')]: NOW - 1 } }), st(), NOW)
    expect(Object.keys(m.tomb)).toEqual([tombMeal('y')])
  })

  it('isti obrok, popravljen na eni napravi → zmaga novejša različica', () => {
    const a = [meal('k', { kcal: 500, updatedAt: T(12) })], b = [meal('k', { kcal: 650, updatedAt: T(13) })]
    expect(mergeMeals(a, b, {})[0]!.kcal).toBe(650)
    expect(mergeMeals(b, a, {})[0]!.kcal).toBe(650)
  })
})

describe('aktivnosti čez naprave', () => {
  it('ista vožnja iz intervals.icu pod dvema id-jema → ena, načrt kaže nanjo', () => {
    const a = [act('aaa', { ext: { intervalsId: 'i9' }, createdAt: T(15), polyline: 'SLED' })]
    const b = [act('bbb', { ext: { intervalsId: 'i9' }, createdAt: T(16), updatedAt: T(17), avgPower: 210 })]
    const r = mergeActivities(a, b, {}, NOW)
    expect(r.list).toHaveLength(1)
    expect(r.list[0]!.id).toBe('aaa')                           // najstarejši id
    expect(r.list[0]!.avgPower).toBe(210)                       // najnovejša vsebina
    expect(r.list[0]!.polyline).toBe('SLED')                    // lokalna sled
    expect(r.remap).toEqual({ bbb: 'aaa' })
    const plan = mergePlan([day('d', '2026-09-24', { done: { at: T(18), activityId: 'bbb' } })], [], r.remap)
    expect(plan[0]!.done?.activityId).toBe('aaa')
    expect(stableStr(mergeActivities(b, a, {}, NOW).list)).toBe(stableStr(r.list))
  })
  it('izbrisana vožnja ne vstane, tudi če jo druga naprava ima pod drugim id-jem', () => {
    const x = act('x', { ext: { intervalsId: 'i5' } })
    const r = mergeActivities([act('y', { ext: { intervalsId: 'i5' } })], [], { [tombAct(x)]: NOW }, NOW)
    expect(r.list).toHaveLength(0)
  })
  it('ista vožnja iz datoteke in iz intervals.icu (±90 s) → ena', () => {
    const r = mergeActivities([act('f', { source: 'file', start: '2026-09-24T14:00:30Z', polyline: 'SLED' })], [act('i', { ext: { intervalsId: 'i7' } })], {}, NOW)
    expect(r.list).toHaveLength(1)
    expect(r.list[0]!.polyline).toBe('SLED')
  })
  it('dve različni vožnji v intervals.icu ob istem času ostaneta dve', () => {
    const r = mergeActivities([act('a', { ext: { intervalsId: 'i1' } })], [act('b', { ext: { intervalsId: 'i2' }, start: '2026-09-24T14:00:20Z' })], {}, NOW)
    expect(r.list).toHaveLength(2)
  })
  it('potekle (Strava §6.2) se ne vrnejo', () => {
    const r = mergeActivities([act('s', { expiresAt: new Date(NOW - 1000).toISOString() })], [], {}, NOW)
    expect(r.list).toHaveLength(0)
  })
})

describe('načrt, check-in, profil, nastavitve', () => {
  it('načrt: dan iz naprave, ki ga je spremenila zadnja (brez podvojenih treningov)', () => {
    const a = [day('a1', '2026-09-25', { updatedAt: T(10) }), day('a2', '2026-09-26', { updatedAt: T(10) })]
    const b = [day('b1', '2026-09-25', { updatedAt: T(12), title: 'Sweet spot' }), day('a2', '2026-09-26', { updatedAt: T(9) })]
    const m = mergePlan(a, b)
    expect(m.map(d => d.id)).toEqual(['b1', 'a2'])
    expect(stableStr(mergePlan(b, a))).toBe(stableStr(m))
  })
  it('check-in: novejši je osnova, manjkajoče iz drugega', () => {
    const m = mergeCheckins([{ date: '2026-09-24', weightKg: 72, updatedAt: T(8) }], [{ date: '2026-09-24', sleepH: 7, updatedAt: T(9) }])
    expect(m[0]).toMatchObject({ weightKg: 72, sleepH: 7 })
  })
  it('prazna nova naprava ne prepiše pravega profila, tudi če je »novejša«', () => {
    const fresh = prof({ onboardingDone: false, name: undefined, updatedAt: T(23) })
    expect(mergeProfile(fresh, prof())?.name).toBe('Blaž')
    expect(mergeProfile(prof(), fresh)?.name).toBe('Blaž')
  })
  it('pogovor s trenerjem: sporočila z obeh naprav, brez že strnjenih', () => {
    const a: Settings = { lang: 'sl', updatedAt: T(10), coach: { msgs: [{ role: 'user', text: 'x', at: T(5) }, { role: 'ai', text: 'y', at: T(6) }], summary: 'povzetek' } }
    const b: Settings = { lang: 'sl', updatedAt: T(9), coach: { msgs: [{ role: 'user', text: 'star', at: T(1) }, { role: 'user', text: 'x', at: T(5) }, { role: 'user', text: 'nov', at: T(7) }] } }
    const m = mergeSettings(a, b, {})!
    expect(m.coach!.msgs.map(x => x.text)).toEqual(['x', 'y', 'nov'])
    expect(m.coach!.summary).toBe('povzetek')
    expect(stableStr(mergeSettings(b, a, {}))).toBe(stableStr(m))
  })
  it('testi: unija, izbrisan (grob) ne vstane', () => {
    const a: Settings = { lang: 'sl', tests: [{ id: 't1', date: '2026-09-01', kind: 'ftp', value: 250, unit: 'W' }] }
    const b: Settings = { lang: 'sl', tests: [{ id: 't2', date: '2026-09-10', kind: 'p5', value: 300, unit: 'W' }, { id: 't1', date: '2026-09-01', kind: 'ftp', value: 250, unit: 'W' }] }
    expect(mergeSettings(a, b, {})!.tests!.map(t => t.id)).toEqual(['t1', 't2'])
    expect(mergeSettings(a, b, { [tombTest('t1')]: NOW })!.tests!.map(t => t.id)).toEqual(['t2'])
  })
})

describe('lastnosti združevanja', () => {
  const a = st({ meals: [meal('m1'), meal('m2', { updatedAt: T(14), kcal: 1 })], activities: [act('x', { ext: { intervalsId: 'i1' } })], plan: [day('p', '2026-09-25')], checkins: [{ date: '2026-09-24', weightKg: 71 }], tomb: { [tombMeal('m9')]: NOW - 5 } })
  const b = st({ meals: [meal('m2', { updatedAt: T(15), kcal: 2 }), meal('m3'), meal('m9')], activities: [act('y', { ext: { intervalsId: 'i1' }, updatedAt: T(19) })], plan: [day('q', '2026-09-25', { updatedAt: T(3) })], checkins: [{ date: '2026-09-24', sleepH: 6 }], profile: prof({ updatedAt: T(5), weightKg: 70 }) })
  it('simetrično: a+b = b+a', () => { expect(stableStr(mergeState(a, b, NOW))).toBe(stableStr(mergeState(b, a, NOW))) })
  it('idempotentno in konvergira', () => {
    const m = mergeState(a, b, NOW)
    expect(stableStr(mergeState(m, m, NOW))).toBe(stableStr(m))
    expect(stableStr(mergeState(a, m, NOW))).toBe(stableStr(m))
    expect(stableStr(mergeState(b, m, NOW))).toBe(stableStr(m))
  })
  it('v oblak nikoli sledi in sličice', () => {
    const p = toCloud(st({ meals: [meal('z', { thumb: 'SLIKA' })], activities: [act('s', { polyline: 'SLED' })] }), 5).payload
    expect(p.meals[0]!.thumb).toBeNull()
    expect(p.activities[0]!.polyline).toBeNull()
    expect(JSON.stringify(p)).not.toMatch(/SLIKA|SLED/)
  })
})
