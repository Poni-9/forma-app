// v3.49 UVOD (shramba): dogovor kolesarja s tekmo iz pogovora — tekma je glavni cilj (goal »dirka«), načrt teče do nje,
// merilnika moči ni, če ga ni izbral (C01, C03).
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { addDays, weekStartIso } from '../src/domain/training/load'
import { weekContext } from '../src/domain/training/planner'
import { ruleProposal } from '../src/domain/focus/rules'
import { composeWish } from '../src/domain/focus/choices'
import { eventOf, raceIn } from '../src/domain/focus/race'

describe('C01 dogovor s tekmo', () => {
  beforeEach(async () => { await repo.wipeAll(); localStorage.clear(); await store.reloadAll() })
  it('tekma iz pogovora → glavni cilj, »dirka«, načrt do tekme; brez izbranega merilnika moči', async () => {
    const today = store.getState().today
    // datum tekme glede na današnji dan v shrambi (čez ~34 tednov), da test ne zastara
    const date = addDays(weekStartIso(today), 7 * 34 + 6)
    const [y, m, d] = date.split('-').map(Number)
    const text = `Maraton Franja ${d}. ${m}. ${y}, dolga trasa 156 km.`
    const race = raceIn(text, today)!
    expect(race).toEqual({ name: 'Maraton Franja', date, distanceKm: 156 })
    const wish = composeWish({ cilj: ['Hitrejši in vzdržljivejši', 'Pripravljen na tekmo'], delam: ['Kolo'], raven: ['Redno, več let'], kolo: ['Zunaj po cesti'] }, text)
    const qa = [{ id: 'tekma', q: 'Tvoja tekma … Je prav?', a: 'Da' }, { id: 'dni', q: 'Koliko od teh 5 dni bi res treniral?', a: '4' }, { id: 'ure', q: 'Koliko ur na teden imaš za to?', a: '6–8 h' }]
    const f = ruleProposal(wish, qa, 29, { avail: [1, 2, 3, 5, 6], today }).focus
    const prof = await store.applyAgreement(f, { sex: 'm', age: 29, heightCm: 180, weightKg: 75, event: eventOf(race) })
    expect(prof.event).toMatchObject({ name: 'Maraton Franja', date, distanceKm: 156 })
    expect(prof.goal).toBe('dirka')
    expect(prof.gear.powerMeter).toBe(false)
    expect(prof.focus?.title).toBe('Do tekme: Maraton Franja')
    const cx = weekContext(prof, addDays(weekStartIso(today), 7))
    expect(cx.event?.name).toBe('Maraton Franja')
    expect(cx.weeksToEvent).toBeGreaterThan(20)
    expect(store.getState().plan.length).toBeGreaterThan(0)
  })
})
