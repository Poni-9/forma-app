import { describe, it, expect } from 'vitest'
import { garminDevice, hasGarminData, sourceLabel } from '@/domain/import/provenance'

describe('Garmin pripis (pogoj Garmin API prek intervals.icu)', () => {
  it('pokaže »Garmin [model]«', () => {
    expect(garminDevice({ originHint: 'GARMIN_CONNECT', deviceName: 'Garmin Edge 530' })).toBe('Garmin Edge 530')
    expect(garminDevice({ originHint: 'GARMIN_CONNECT', deviceName: 'Edge 530' })).toBe('Garmin Edge 530')
    expect(garminDevice({ originHint: 'GARMIN_CONNECT', deviceName: 'GARMIN FR 255' })).toBe('Garmin Forerunner 255')
    expect(garminDevice({ originHint: 'GARMIN_CONNECT', deviceName: null })).toBe('Garmin')
    expect(garminDevice({ originHint: 'STRAVA', deviceName: 'Wahoo ELEMNT' })).toBeNull()
  })
  it('oznaka izvora na kartici aktivnosti vsebuje model', () => {
    expect(sourceLabel({ source: 'intervals', originHint: 'GARMIN_CONNECT', deviceName: 'Garmin Forerunner 965' })).toBe('Garmin Forerunner 965')
    expect(sourceLabel({ source: 'intervals', originHint: 'STRAVA', deviceName: 'Garmin Edge 530' })).toBe('Strava (prek intervals.icu)')
  })
  it('pripis pod izračuni samo, če so Garmin podatki iz intervals.icu', () => {
    expect(hasGarminData([{ source: 'intervals', originHint: 'GARMIN_CONNECT', deviceName: null }])).toBe(true)
    expect(hasGarminData([{ source: 'manual', originHint: null, deviceName: null }])).toBe(false)
  })
})
