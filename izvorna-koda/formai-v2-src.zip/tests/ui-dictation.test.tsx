// Narekovanje: na Androidu krog za krogom (Chrome neha ob premoru), brez podvajanja, tipkanje med narekovanjem obvelja,
// po dveh tihih krogih se mikrofon sam ugasne, drugi tap ga ustavi.
import { act, useState } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, beforeEach, afterEach } from 'vitest'
import { useDictation } from '@/ui/useDictation'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

/** Lažna prepoznava: zapiše vsak primerek, testi sprožijo dogodke sami. */
const R = { all: [] as FakeRec[], errs: [] as string[] }
class FakeRec {
  lang = ''; interimResults = false; continuous = false; maxAlternatives = 1
  onresult: ((e: any) => void) | null = null
  onend: (() => void) | null = null
  onerror: ((e: { error: string }) => void) | null = null
  started = 0; stopped = 0
  constructor() { R.all.push(this) }
  start() { this.started++ }
  stop() { this.stopped++; this.onend?.() }
  abort() { this.stopped++ }
  /** rezultati kroga: [besedilo, isFinal] */
  say(parts: [string, boolean][]) {
    this.onresult?.({ resultIndex: 0, results: parts.map(([t, f]) => Object.assign([{ transcript: t, confidence: .9 }], { isFinal: f, length: 1 })) })
  }
  end() { this.onend?.() }
}

function Probe() {
  const [text, setText] = useState('')
  const d = useDictation(text, setText, m => R.errs.push(m))
  return (<div>
    <textarea value={text} onChange={e => setText(e.target.value)} />
    <button onClick={d.toggle}>{d.listening ? 'stop' : 'mic'}</button>
    <button onClick={() => setText(text + ' in jogurt')}>type</button>
  </div>)
}

let div: HTMLDivElement, root: Root
const txt = () => (div.querySelector('textarea') as HTMLTextAreaElement).value
const btn = () => div.querySelector('button') as HTMLButtonElement
const last = () => R.all[R.all.length - 1]!

beforeEach(async () => {
  R.all = []; R.errs = []
  ;(window as any).webkitSpeechRecognition = FakeRec
  Object.defineProperty(navigator, 'userAgent', { value: 'Mozilla/5.0 (Linux; Android 14; Pixel 8) Chrome/130 Mobile', configurable: true })
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root.render(<Probe />) })
})
afterEach(async () => { await act(async () => root.unmount()); div.remove(); delete (window as any).webkitSpeechRecognition })

describe('narekovanje', () => {
  it('Android: krog za krogom, besedilo se nabira, brez podvajanja', async () => {
    await act(async () => { btn().click() })
    expect(R.all.length).toBe(1); expect(last().continuous).toBe(false); expect(last().lang).toBe('sl-SI'); expect(btn().textContent).toBe('stop')
    await act(async () => { last().say([['pojedel sem', false]]) })
    expect(txt()).toBe('pojedel sem')
    await act(async () => { last().say([['pojedel sem jabolko', true]]) })
    expect(txt()).toBe('pojedel sem jabolko')
    // Chrome na Androidu konča krog → nov krog se začne sam
    await act(async () => { last().end(); await new Promise(r => setTimeout(r, 200)) })
    expect(R.all.length).toBe(2); expect(btn().textContent).toBe('stop')
    // Android isti stavek včasih vrne še enkrat — ne podvojimo
    await act(async () => { last().say([['pojedel sem jabolko', true]]); last().end(); await new Promise(r => setTimeout(r, 200)) })
    expect(txt()).toBe('pojedel sem jabolko')
    expect(R.all.length).toBe(3)
    await act(async () => { last().say([['in dva kosa kruha', true]]) })
    expect(txt()).toBe('pojedel sem jabolko in dva kosa kruha')
    // drugi tap ustavi — brez novega kroga
    await act(async () => { btn().click(); await new Promise(r => setTimeout(r, 200)) })
    expect(btn().textContent).toBe('mic'); expect(R.all.length).toBe(3); expect(last().stopped).toBe(1)
    expect(txt()).toBe('pojedel sem jabolko in dva kosa kruha')
  })

  it('po dveh tihih krogih se ugasne sam; no-speech ni napaka', async () => {
    await act(async () => { btn().click() })
    await act(async () => { last().onerror?.({ error: 'no-speech' }); last().end(); await new Promise(r => setTimeout(r, 200)) })
    expect(R.all.length).toBe(2); expect(btn().textContent).toBe('stop')
    await act(async () => { last().onerror?.({ error: 'no-speech' }); last().end(); await new Promise(r => setTimeout(r, 200)) })
    expect(R.all.length).toBe(2); expect(btn().textContent).toBe('mic'); expect(R.errs).toEqual([])
  })

  it('tipkanje med narekovanjem obvelja; obstoječe besedilo ostane spredaj', async () => {
    const ta = div.querySelector('textarea') as HTMLTextAreaElement
    await act(async () => { Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')!.set!.call(ta, 'zajtrk:'); ta.dispatchEvent(new Event('input', { bubbles: true })) })
    await act(async () => { btn().click() })
    await act(async () => { last().say([['dve jajci', true]]) })
    expect(txt()).toBe('zajtrk: dve jajci')
    await act(async () => { (div.querySelectorAll('button')[1] as HTMLButtonElement).click() })
    expect(txt()).toBe('zajtrk: dve jajci in jogurt')
    await act(async () => { last().end(); await new Promise(r => setTimeout(r, 200)) })
    await act(async () => { last().say([['in kava', true]]) })
    expect(txt()).toBe('zajtrk: dve jajci in jogurt in kava')
  })

  it('zavrnjen mikrofon → razumljivo sporočilo, konec', async () => {
    await act(async () => { btn().click() })
    await act(async () => { last().onerror?.({ error: 'not-allowed' }); last().end(); await new Promise(r => setTimeout(r, 200)) })
    expect(btn().textContent).toBe('mic'); expect(R.all.length).toBe(1)
    expect(R.errs[0]).toMatch(/Dovoli mikrofon/)
  })

  it('namizje: neprekinjeno, po koncu Chroma nadaljuje z istim besedilom', async () => {
    Object.defineProperty(navigator, 'userAgent', { value: 'Mozilla/5.0 (X11; Linux x86_64) Chrome/130', configurable: true })
    await act(async () => { btn().click() })
    expect(last().continuous).toBe(true)
    await act(async () => { last().say([['danes sem tekel ', true], ['deset kilometrov', false]]) })
    expect(txt()).toBe('danes sem tekel deset kilometrov')
    await act(async () => { last().end(); await new Promise(r => setTimeout(r, 200)) })
    expect(R.all.length).toBe(2)
    await act(async () => { last().say([['v eni uri', true]]) })
    expect(txt()).toBe('danes sem tekel deset kilometrov v eni uri')
  })
})
