// v3.49 CILJ — zasloni: štetje kalorij ne izrisuje celega zaslona (D13, B32), »Zadnjih 7 dni« s ciljem istih dni (B05),
// ocena obroka brez AI iz tabele živil (B30), zdravstveni pridržek ostane.
import 'fake-indexeddb/auto'
import { act, useSyncExternalStore, useState } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { readFileSync } from 'node:fs'
import { describe, it, expect, vi, afterEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'prehrana', params: {} as Record<string, string> }, recipes: 0 }))
vi.mock('@/state/store', async (orig) => ({
  ...(await orig<typeof import('../src/state/store')>()),
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  addMeal: async () => undefined,
}))
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => S.route, subscribeRoute: () => () => undefined }))
// koliko krat zaslon izračuna recepte (= koliko krat se izriše)
vi.mock('@/domain/nutrition/daymeals', async (orig) => {
  const m = await orig<typeof import('../src/domain/nutrition/daymeals')>()
  return { ...m, recipesOf: (...a: Parameters<typeof m.recipesOf>) => { S.recipes++; return m.recipesOf(...a) } }
})

import * as repo from '../src/data/repo'
import { Prehrana } from '@/screens/Prehrana'
import { CountUp } from '@/ui/CountUp'
import { FRANJA_2027 } from '../src/domain/training/planner'
import type { MealEntry, PlanDay, Profile } from '../src/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const NOW = '2026-10-01T08:00:00.000Z'
const TODAY = '2026-10-17'
const P = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, restHr: 55, maxHr: 200, lthr: 184, ftp: 240, ftpDate: '2026-09-20',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, hoursPerWeek: 14, baseHours: null,
  strength: { on: false, equipment: 'home', phases: null }, strengthDays: 0, goal: 'dirka', deficit: 400, neat: 1.4,
  event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', onboardingDone: true, trainTime: 'popoldne', createdAt: NOW, updatedAt: NOW,
  races: [], ...o,
} as Profile)
const planDay = (date: string, min: number, o: Partial<PlanDay> = {}): PlanDay => ({ id: 'r' + date, date, kind: 'kolo', title: 'Dolga Z2', desc: '', durationMin: min, zone: 'Z2', role: 'dolga', source: 'rules', createdAt: NOW, updatedAt: NOW, ...o })
const meal = (date: string, slot: MealEntry['slot'], kcal: number, o: Partial<MealEntry> = {}): MealEntry => ({ id: `${date}-${slot}-${kcal}`, date, slot, name: o.name || slot, kcal, source: 'manual', createdAt: NOW, time: o.time ?? null, ...o })

let div: HTMLDivElement, root: Root
async function render(el: React.ReactElement) {
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root.render(el) })
  return text()
}
const text = () => (document.body.textContent || '').replace(/[  ⁠]/g, ' ')
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(b.textContent || '') || re.test(b.getAttribute('aria-label') || ''))
async function click(el: Element | undefined | null) { expect(el).toBeTruthy(); await act(async () => { (el as HTMLElement).click(); await Promise.resolve() }) }
async function typeIn(el: Element | null, v: string) {
  expect(el).toBeTruthy()
  await act(async () => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(el, v); el!.dispatchEvent(new Event('input', { bubbles: true })) })
}
afterEach(async () => { await act(async () => root?.unmount()); div?.remove(); vi.useRealTimers(); S.recipes = 0 })

function setState(o: { meals?: MealEntry[]; recent?: MealEntry[]; plan?: PlanDay[]; profile?: Profile } = {}) {
  vi.useFakeTimers({ toFake: ['Date', 'requestAnimationFrame', 'cancelAnimationFrame', 'performance'] })
  vi.setSystemTime(new Date(`${TODAY}T12:30:00`))
  const meals = o.meals || []
  S.state = { ready: true, settings: repo.defaultSettings(), changes: [], toast: null, sync: { state: 'off' }, authKnown: true, pro: false, wellness: null, checkinToday: null, today: TODAY, profile: o.profile || P(), plan: o.plan || [], activities: [], mealsToday: meals, recentMeals: [...(o.recent || []), ...meals], checkins: [], weather: null, user: null }
}

describe('D13 / B32 — štetje kalorij v svojem elementu', () => {
  it('CountUp šteje do vrednosti, starš se med štetjem ne izriše znova', async () => {
    vi.useFakeTimers({ toFake: ['requestAnimationFrame', 'cancelAnimationFrame', 'performance'] })
    let renders = 0
    function Parent() { renders++; const [v] = useState(1840); return <b id="n"><CountUp value={v} id="t-a" format={n => String(Math.round(n))} /></b> }
    await render(<Parent />)
    expect(document.getElementById('n')!.textContent).toBe('0')            // prvič od 0
    await act(async () => { vi.advanceTimersByTime(500) })
    const mid = +document.getElementById('n')!.textContent!
    expect(mid).toBeGreaterThan(0); expect(mid).toBeLessThan(1840)
    await act(async () => { vi.advanceTimersByTime(1000) })
    expect(document.getElementById('n')!.textContent).toBe('1840')
    expect(renders).toBe(1)
  })
  it('ponoven prihod z isto številko: brez štetja (takoj prava)', async () => {
    vi.useFakeTimers({ toFake: ['requestAnimationFrame', 'cancelAnimationFrame', 'performance'] })
    await render(<b id="n"><CountUp value={620} id="t-b" /></b>)
    await act(async () => { vi.advanceTimersByTime(1500) })
    await act(async () => root.unmount()); div.remove()
    await render(<b id="n"><CountUp value={620} id="t-b" /></b>)
    expect(document.getElementById('n')!.textContent).toBe('620')
  })
  it('Prehrana: med štetjem (1,1 s) se recepti ne računajo znova (prej ~66 izrisov celega zaslona)', async () => {
    setState({ meals: [meal(TODAY, 'zajtrk', 620, { time: '07:30' })], plan: [planDay(TODAY, 105)] })
    await render(<Prehrana />)
    const after = S.recipes
    expect(after).toBeGreaterThan(0)
    await act(async () => { vi.advanceTimersByTime(1300) })
    expect(S.recipes).toBe(after)
    expect(document.querySelector('.ring-wrap b.num')!.textContent!.replace(/\s/g, '')).toBe('620')
  })
  it('Danes ne uporablja več štetja v korenu zaslona', () => {
    for (const f of ['src/screens/Danes.tsx', 'src/screens/Prehrana.tsx']) expect(readFileSync(f, 'utf8')).not.toMatch(/useCountUp/)
  })
})

describe('B05 — »Zadnjih 7 dni« s ciljem istih dni', () => {
  it('včeraj opravljena vožnja 1 h 45 (cilj 2 939), predvčerajšnjim počitek (2 141): »cilj 2 540«, ne »cilj brez treninga«', async () => {
    const y = '2026-10-16', yy = '2026-10-15'
    setState({ plan: [planDay(y, 105, { done: { at: NOW } })], recent: [meal(y, 'kosilo', 3000), meal(yy, 'kosilo', 2000)] })
    const t = await render(<Prehrana />)
    expect(t).toMatch(/povprečno 2 500 kcal · cilj 2 540 · 2 dneva/)   // (v3.50) dni z vpisom brez današnjega
    await click(btn(/Zadnjih 7 dni/))
    expect(text()).toMatch(/40 kcal pod ciljem teh dni \(povprečno 2 540 kcal\)/)
    expect(text()).toMatch(/Črtica = cilj tistega dne \(s treningom\)/)
    expect(text()).not.toMatch(/Cilj brez treninga/)
    // črtica cilja nad vsakim dnem s ciljem
    expect(document.querySelectorAll('line.bar-ref').length).toBe(7)
  })
})

describe('B30 — ocena obroka brez AI', () => {
  it('ročni vpis: »Oceni brez AI« iz tabele živil izpolni kalorije in makre (nizka zanesljivost)', async () => {
    setState({ plan: [] })
    await render(<Prehrana />)
    await click(btn(/^Dodaj /))
    await typeIn(document.querySelector('#meal-name'), 'ovseni kosmiči 70 g, jogurt 200 g')
    await click(btn(/Oceni brez AI/))
    expect((document.querySelector('#meal-kcal') as HTMLInputElement).value).toBe('405')
    expect((document.querySelector('#meal-prot') as HTMLInputElement).value).toBe('29')
    expect(text()).toMatch(/Ocena brez AI · tabela živil/)
    expect(text()).toMatch(/zanesljivost ocene: nizka/)
  })
  it('zdravstveni pridržek pri kalorični številki ostane', async () => {
    setState({ plan: [planDay(TODAY, 105)] })
    expect(await render(<Prehrana />)).toMatch(/ne zdravniški nasvet/)
  })
})
