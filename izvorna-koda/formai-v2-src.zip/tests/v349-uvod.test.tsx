// v3.49 UVOD — »Sestaviva načrt«: tekma iz besed postane cilj (C01), »Garmin uro« ni čas (C02), brez izbranega merilnika
// moči brez vatov (C03), prvo usklajevanje = en načrt (C07), osnutek uvoda (C09), hitra hoja (C10), razlaga pred prijavo
// (C11), pogajanje brez AI (C12, C13), »Preskoči« pri gradnji (C23), brez odvečnih vprašanj (C29).
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, afterEach, beforeEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), nav: [] as string[] }))
vi.mock('@/state/store', async () => {
  const { vi: v } = await import('vitest')
  const base: Record<string | symbol, unknown> = {
    useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
    getState: () => S.state,
    routePace: () => ({ k: 1, adj: { n: 0, adj: 1 } }),
  }
  // vse druge funkcije stanja so prazne (applyAgreement, toast …) — klice preverimo
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' || typeof k === 'symbol' ? undefined : (t[k] = v.fn(async () => {}))), has: (_t, k) => k !== 'then' })
})
vi.mock('@/app/router', () => ({ navigate: (to: string) => { S.nav.push(to) }, useRoute: () => ({ name: 'uvod', params: {} }) }))
vi.mock('@/app/landing', () => ({ markApp: () => undefined }))
vi.mock('@/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '@/state/store'
import { Sestavi, readDraft, writeDraft, clearDraft } from '@/screens/Sestavi'
import { BuildShow } from '@/ui/BuildShow'
import { Vadba } from '@/screens/Vadba'
import { raceIn, raceFromTalk } from '@/domain/focus/race'
import { ruleQuestions, ruleProposal, ruleAdjust, quickFor, adjustNote } from '@/domain/focus/rules'
import { coachReview, coachOptsFrom, planInputs, weekDiff } from '@/domain/focus/coach'
import { minutesRange, minutesIn } from '@/domain/focus/dose'
import { composeWish } from '@/domain/focus/choices'
import { normalizeFocus, profileFromFocus, weekLine, usesAgreement, sessionLabel } from '@/domain/focus/model'
import { noPower } from '@/domain/training/zones'
import { buildWeek } from '@/domain/training/planner'
import { cardioDay, buildFocusWeek } from '@/domain/training/focusPlan'
import { stepsFor } from '@/domain/training/workout'
import { addDays } from '@/domain/training/load'
import { mergeState, type SyncState } from '@/data/merge'
import { sessName } from '@/ui/WeekStrip'
import type { Focus, PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-17'   // sobota
const NOW = `${TODAY}T08:00:00.000Z`
const AVAIL_K = [1, 2, 3, 5, 6]
const sum = (f: Pick<Focus, 'sessions'>) => f.sessions.reduce((t, s) => t + s.min, 0)

/* ---------- kolesar s tekmo (persona K) ---------- */
const PICKS_K = { cilj: ['Hitrejši in vzdržljivejši', 'Pripravljen na tekmo'], delam: ['Kolo'], raven: ['Redno, več let'], kolo: ['Zunaj po cesti'] }
const TEXT_K = 'Maraton Franja 13. junija 2027, dolga trasa 156 km. Imam Garmin uro.'
const WISH_K = composeWish(PICKS_K, TEXT_K)
const QA_K = [
  { id: 'tekma', q: 'Tvoja tekma: Maraton Franja · 13. 6. 2027 · 156 km. Je prav?', a: 'Da' },
  { id: 'dni', q: 'Koliko od teh 5 dni bi res treniral?', a: '4' },
  { id: 'ure', q: 'Koliko ur na teden imaš za to?', a: '6–8 h' },
  { id: 'poskodbe', q: 'Te kaj boli ali imaš poškodbo?', a: 'Ne' },
]
const NEW: Profile = { sex: 'm', age: 29, heightCm: 180, weightKg: 75, ftp: null, maxHr: null, restHr: null, gear: { bikeOutdoor: false, trainer: false, noBike: false }, strength: { on: false, equipment: 'none' }, onboardingDone: false, createdAt: NOW, updatedAt: NOW } as unknown as Profile

describe('C01 tekma iz napisanega besedila', () => {
  it('ime, datum in km iz besed; datum brez besede o tekmi ni tekma', () => {
    expect(raceIn(TEXT_K, TODAY)).toEqual({ name: 'Maraton Franja', date: '2027-06-13', distanceKm: 156 })
    expect(raceIn('Kronometer Vodice, 23. 10.', TODAY)).toEqual({ name: 'Kronometer Vodice', date: '2026-10-23', distanceKm: null })
    expect(raceIn('Granfondo Alpe 4 julij 2027, 120 km', TODAY)?.date).toBe('2027-07-04')
    expect(raceIn('Do 1. junija 5 kg manj.', TODAY)).toBeNull()
    expect(raceIn('Moj cilj je do 1. 6. shujšati 5 kg.', TODAY)).toBeNull()
    expect(raceIn('Maraton 13. 6. 2025', TODAY)).toBeNull()   // mimo
  })
  it('vprašalnik kolesarja s tekmo: najprej potrdi napisano tekmo; brez datuma vpraša; z glavnim ciljem ne', () => {
    const q = ruleQuestions(WISH_K, { avail: AVAIL_K, today: TODAY })
    expect(q.questions[0]).toMatchObject({ id: 'tekma', options: ['Da', 'Še nimam datuma'], other: true })
    expect(q.questions[0]!.text).toContain('Maraton Franja · 13. 6. 2027 · 156 km')
    const noDate = ruleQuestions(composeWish(PICKS_K, ''), { avail: AVAIL_K, today: TODAY })
    expect(noDate.questions.find(x => x.id === 'tekma')?.text).toMatch(/^Katera tekma in kdaj\?/)
    expect(ruleQuestions(WISH_K, { avail: AVAIL_K, today: TODAY, event: { name: 'Franja', date: '2027-06-13' } }).questions.some(x => x.id === 'tekma')).toBe(false)
  })
  it('odgovor »Da« = tekma iz želje; »Še ne vem« = brez; vpisan odgovor', () => {
    expect(raceFromTalk(WISH_K, QA_K, TODAY)?.date).toBe('2027-06-13')
    expect(raceFromTalk(WISH_K, [{ id: 'tekma', q: 'x', a: 'Še nimam datuma' }], TODAY)).toBeNull()
    expect(raceFromTalk(composeWish(PICKS_K, ''), [{ id: 'tekma', q: 'Katera tekma in kdaj?', a: 'Maraton Franja, 2027-06-13' }], TODAY)).toMatchObject({ name: 'Maraton Franja', date: '2027-06-13' })
  })
  it('predlog po pravilih: kolesarski način, ime po tekmi', () => {
    const p = ruleProposal(WISH_K, QA_K, 29, { avail: AVAIL_K, today: TODAY })
    expect(usesAgreement(p.focus)).toBe(false)
    expect(p.focus.title).toBe('Do tekme: Maraton Franja')
  })
})

describe('C02 »Imam Garmin uro« ni čas na vadbo', () => {
  it('minutesRange / minutesIn', () => {
    expect(minutesRange('Imam Garmin uro.')).toBeNull()
    expect(minutesRange('Uro imam, a je ne nosim.')).toBeNull()
    expect(minutesIn('Imam pametno uro.')).toBeNull()
    expect(minutesRange('eno uro')).toEqual({ lo: 60, hi: 60 })
    expect(minutesRange('uro')).toEqual({ lo: 60, hi: 60 })
    expect(minutesIn('imam uro časa na dan')).toEqual({ lo: 60, hi: 60 })
    expect(minutesRange('1 h 30 min')).toEqual({ lo: 90, hi: 90 })
  })
  it('odgovor »6–8 h« na teden ima prednost pred minutami iz želje', () => {
    const o = coachOptsFrom({ wish: 'Rad bi bil hitrejši. 1 h na vadbo.', qa: [{ q: 'Koliko ur na teden imaš za to?', a: '6–8 h' }], strengthOk: false, cardioOk: true })
    expect(o.weekMin).toEqual({ lo: 360, hi: 480 })
    expect(o.minRange).toBeNull()
    expect(coachOptsFrom({ wish: 'Imam Garmin uro.', qa: [{ q: 'Koliko ur na teden imaš za to?', a: '6–8 h' }], strengthOk: false, cardioOk: true }).weekMin).toEqual({ lo: 360, hi: 480 })
  })
  it('kolesar s 6–8 h dobi ~7 h na teden (prej ~4,5 h)', () => {
    const p = ruleProposal(WISH_K, QA_K, 29, { avail: AVAIL_K, today: TODAY })
    const rev = coachReview({ ...p.focus, main: 'kardio' }, planInputs({ picks: PICKS_K, wish: WISH_K, qa: QA_K, age: 29, push: 'zmerno', main: 'kardio', avail: AVAIL_K }).opts)
    expect(sum(rev.focus)).toBeGreaterThanOrEqual(6.5 * 60)
    expect(rev.why.join(' ')).not.toMatch(/1 h na vadbo/)
  })
})

describe('C03 brez izbranega merilnika moči: utrip in občutek', () => {
  const f = normalizeFocus({ wish: 'Kolo: zunaj po cesti.', sessions: [{ type: 'kolo', cardio: 'intervali', min: 75 }, { type: 'kolo', cardio: 'lahko', min: 90 }, { type: 'kolo', cardio: 'dolgo', min: 150 }], aims: ['tekma', 'vzdrzljivost'], level: 3 }, { by: 'pravila' })!
  it('prvi dogovor brez izbire »Merilnik moči« → brez merilnika; izbran → z merilnikom (zaznava ga ne ugasne)', () => {
    expect(profileFromFocus(f, NEW, '2026-10-12', TODAY).gear!.powerMeter).toBe(false)
    const pm = profileFromFocus({ ...f, wish: 'Kolo: zunaj po cesti, merilnik moči.' }, NEW, '2026-10-12', TODAY).gear!
    expect(pm.powerMeter).toBe(true)
    expect(pm.powerMeterAuto).toBe(false)
    // nov dogovor (že ima načrt): kar je nastavljeno, ostane
    expect(profileFromFocus(f, { ...NEW, onboardingDone: true, gear: { ...NEW.gear, powerMeter: true } }, '2026-10-12', TODAY).gear!.powerMeter).toBe(true)
  })
  it('»ne vemo« (null) brez FTP = brez merilnika; z znanim FTP ostanejo vati', () => {
    expect(noPower({ gear: { powerMeter: null }, ftp: null })).toBe(true)
    expect(noPower({ gear: {}, ftp: null })).toBe(true)
    expect(noPower({ gear: { powerMeter: null }, ftp: 250 })).toBe(false)
    expect(noPower({ gear: { powerMeter: true }, ftp: null })).toBe(false)
  })
  it('načrt do Franje brez merilnika: nikjer % FTP ali vatov, test po utripu', () => {
    const base = { ...NEW, event: { name: 'Maraton Franja', date: '2027-06-13', distanceKm: 156 } } as Profile
    const prof = { ...base, ...profileFromFocus(f, base, '2026-10-12', TODAY) } as Profile
    const bad: string[] = []
    let tests = 0
    for (let w = 0; w < 30; w++) {
      const ws = addDays('2026-10-19', 7 * w)
      for (const d of buildWeek({ profile: prof, activities: [], weekStart: ws, notBefore: ws, checkins: [], today: TODAY })) {
        const t = `${d.title} ${d.desc}`.replace(/ista hitrost za \d+ W manj/, '')
        if (/% FTP|\d\s?W\b|FTP = 95/.test(t)) bad.push(`${d.date} ${d.title}: ${d.desc}`)
        if (d.role === 'test') tests++
      }
    }
    expect(bad).toEqual([])
    expect(tests).toBeGreaterThan(0)
  })
})

describe('C07 prvo usklajevanje: en načrt (z računa) + opravljeno s te naprave', () => {
  const day = (id: string, date: string, title: string, at: string, o: Partial<PlanDay> = {}): PlanDay => ({ id, date, kind: 'kolo', title, desc: '', durationMin: 60, source: 'rules', createdAt: at, updatedAt: at, ...o }) as PlanDay
  const prof = (title: string, at: string) => ({ onboardingDone: true, focus: { title }, updatedAt: at, fieldAt: { focus: at, onboardingDone: at } }) as unknown as Profile
  const cloud: SyncState = { profile: prof('Kolo za kondicijo', '2026-10-10T08:00:00Z'), settings: null, activities: [], meals: [], checkins: [], tomb: {},
    plan: [day('a1', '2026-10-20', 'Z2 + šprint', '2026-10-10T08:00:00Z'), day('a2', '2026-10-22', 'Z2 klanci', '2026-10-10T08:00:00Z'), day('a3', '2026-10-24', 'Z2 daljša', '2026-10-10T08:00:00Z')] }
  const laptop: SyncState = { profile: prof('Vitka in močna postava', '2026-10-17T08:00:00Z'), settings: null, activities: [], meals: [], checkins: [], tomb: {},
    plan: [day('b0', '2026-10-17', 'Hitra hoja', '2026-10-17T08:00:00Z', { kind: 'pohod', done: { at: '2026-10-17T18:00:00Z', activityId: null } as PlanDay['done'] }), day('b1', '2026-10-19', 'Fitnes — zgornji del', '2026-10-17T08:00:00Z', { kind: 'moc' }), day('b2', '2026-10-22', 'Fitnes — spodnji del', '2026-10-17T08:00:00Z', { kind: 'moc' }), day('b3', '2026-10-23', 'Hribi', '2026-10-17T08:00:00Z', { kind: 'pohod' })] }
  it('dogovor in teden z računa, opravljena hoja s te naprave ostane (prej mešanica fitnesa in kolesa)', () => {
    const m = mergeState(laptop, cloud, Date.parse('2026-10-17T19:00:00Z'), { authority: 'b' })
    expect((m.profile as unknown as { focus: { title: string } }).focus.title).toBe('Kolo za kondicijo')
    expect(m.plan.map(d => d.title)).toEqual(['Hitra hoja', 'Z2 + šprint', 'Z2 klanci', 'Z2 daljša'])
  })
  it('redno usklajevanje (brez avtoritete) ostane po dnevih kot prej', () => {
    const m = mergeState(laptop, cloud, Date.parse('2026-10-17T19:00:00Z'))
    expect(m.plan.some(d => d.title === 'Fitnes — zgornji del')).toBe(true)
  })
})

describe('C09 osnutek uvoda', () => {
  beforeEach(() => { sessionStorage.clear(); localStorage.clear() })
  it('zapiše, prebere (isti način), stari ali drug način ne velja, pobriše', () => {
    writeDraft({ again: false, picks: { delam: ['Tek'] }, text: 'Ob torkih nimam časa.', avail: [0, 2, 9], trainTime: 'zvecer', push: 'lahko', main: 'kardio', b: { sex: 'z', age: '33', height: '', weight: '' } })
    const d = readDraft(false)!
    expect(d.text).toBe('Ob torkih nimam časa.')
    expect(d.avail).toEqual([0, 2])
    expect(readDraft(true)).toBeNull()
    expect(readDraft(false, Date.now() + 13 * 3600_000)).toBeNull()
    clearDraft()
    expect(readDraft(false)).toBeNull()
  })
})

describe('C10 hoja ali pohod: kratka hoja ni tura v hribe', () => {
  const f = normalizeFocus({ wish: 'x', sessions: [{ type: 'hribi', cardio: 'lahko', min: 30 }, { type: 'doma', part: 'celo', min: 30 }], aims: ['zdravje'] }, { by: 'pravila' })!
  it('30 min: hitra hoja, lahek dan, brez palic in prigrizka; 2 h: tura', () => {
    const d = cardioDay(NEW, f, f.sessions[0]!, { volume: 1, recovery: false, week: 1 })
    expect(d.title).toBe('Hitra hoja — 30 min')
    expect(d.desc).not.toMatch(/Palice|prigrizek|Tura/)
    expect(d.role).toBe('lahka')
    const long = cardioDay(NEW, f, { type: 'hribi', cardio: 'lahko', min: 150 }, { volume: 1, recovery: false, week: 1 })
    expect(long.title).toMatch(/^Hribi/)
    expect(long.role).toBe('dolga')
    expect(sessName(f.sessions[0]!)).toBe('Hitra hoja')
    expect(sessionLabel(f.sessions[0]!)).toBe('Hitra hoja · 30 min')
  })
})

describe('C12 pogajanje brez AI: kolesar', () => {
  const k = () => {
    const p = ruleProposal(WISH_K, QA_K, 29, { avail: AVAIL_K, today: TODAY })
    return coachReview({ ...p.focus, main: 'kardio' }, planInputs({ picks: PICKS_K, wish: WISH_K, qa: QA_K, age: 29, push: 'zmerno', main: 'kardio', avail: AVAIL_K }).opts).focus
  }
  const round = (f: Focus, say: string) => {
    const adj = ruleAdjust(f, say, 29)!
    return coachReview(adj, planInputs({ picks: PICKS_K, wish: WISH_K, qa: QA_K, feedback: say, age: 29, push: 'zmerno', main: 'kardio', avail: AVAIL_K }).opts).focus
  }
  it('hitri odgovori kolesarja: ure in dnevi (ne »več kardia« in »več moči«)', () => {
    expect(quickFor(k())).toEqual(['Več ur', 'Manj ur', 'Manj dni', 'Več dni'])
  })
  it('»Več kardia« in »Več ur« teden podaljšata (prej skrajšala), »Manj ur« skrajša', () => {
    const f = k()
    expect(sum(round(f, 'Več kardia'))).toBeGreaterThan(sum(f))
    expect(sum(round(f, 'Več ur'))).toBeGreaterThan(sum(f))
    expect(sum(round(f, 'Manj ur'))).toBeLessThan(sum(f))
  })
  it('»Več dni« doda vožnjo (ne vadbe doma), »Manj dni« vzame lahko vožnjo (ne dolge)', () => {
    const f = k()
    const more = ruleAdjust(f, 'Več dni', 29)!
    expect(more.sessions.every(s => s.type === 'kolo')).toBe(true)
    const less = ruleAdjust(f, 'Manj dni', 29)!
    expect(less.sessions.some(s => s.cardio === 'dolgo')).toBe(true)
  })
})

describe('C13 »hoja in tek izmenično« brez AI', () => {
  const t = normalizeFocus({ wish: 'Tek: začenjam s tekom.', sessions: [{ type: 'tek', cardio: 'lahko', min: 25 }, { type: 'tek', cardio: 'lahko', min: 25 }, { type: 'tek', cardio: 'lahko', min: 30 }], aims: ['kondicija', 'hujsanje'], level: 1 }, { by: 'pravila' })!
  it('razume prošnjo, teki postanejo tek in hoja; »več teka in manj hoje« ni to', () => {
    const adj = ruleAdjust(t, 'Raje hoja in tek izmenično, ker še ne zmorem teči 25 minut.', 38)
    expect(adj).not.toBeNull()
    expect(adj!.sessions.every(s => s.walk === true)).toBe(true)
    expect(adjustNote(t, adj!)).toMatch(/tek in hoja/)
    expect(ruleAdjust(t, 'več teka in manj hoje', 38)?.sessions.some(s => s.walk)).not.toBe(true)
    expect(quickFor(t)[0]).toBe('Tek in hoja')
    expect(quickFor(adj!)).not.toContain('Tek in hoja')
  })
  it('načrt: tek in hoja s piskom menjav, vsak teden več teka, nato tek v kosu', () => {
    const f = ruleAdjust(t, 'hoja in tek izmenično', 38)!
    const p = { ...NEW, focus: f, cycleStart: '2026-10-19', onboardingDone: true } as Profile
    const runOf = (week: number) => {
      const ws = addDays('2026-10-19', 7 * (week - 1))
      const d = buildFocusWeek({ profile: p, activities: [], weekStart: ws, notBefore: ws, checkins: [] }).find(x => x.kind === 'tek')!
      return d
    }
    const w1 = runOf(1)
    expect(w1.title).toMatch(/^Tek in hoja/)
    expect(w1.desc).toMatch(/× \(1 min tek \/ 1 min 30 s hoja\)/)   // (po združitvi) ena lestvica teka in hoje (PLAN)
    expect(stepsFor(w1, p).some(s => s.label === 'Hoja')).toBe(true)
    const runMin = (d: PlanDay) => { const m = /(\d+) × \((\d+) min tek/.exec(d.desc); return m ? +m[1]! * +m[2]! : d.durationMin }
    expect(runMin(runOf(5))).toBeGreaterThan(runMin(w1))
    expect(runOf(12).title).toMatch(/^Tek — lahko/)
  })
})

describe('C29 brez odvečnih vprašanj', () => {
  it('»dvakrat na teden po 30 minut« z 2 dnevoma: ne »Koliko od teh 2 dni?« ne »Koliko časa?«', () => {
    const wish = composeWish({ cilj: ['Zdravje in počutje'], delam: ['Še ne vem'] }, 'Rad bi se več gibal, dvakrat na teden po 30 minut.')
    const q = ruleQuestions(wish, { avail: [1, 3], today: TODAY })
    expect(q.questions.map(x => x.id)).not.toContain('dni')
    expect(q.questions.map(x => x.id)).not.toContain('cas')
    expect(minutesIn('dvakrat na teden po 30 minut')).toEqual({ lo: 30, hi: 30 })
    const p = ruleProposal(wish, [{ id: 'kardio', q: 'Kaj ti je dostopno ali bi rad poskusil?', a: 'Hoja ali pohod, Vadba doma' }], 40, { avail: [1, 3], today: TODAY })
    expect(p.focus.sessions.length).toBe(2)
    expect(p.focus.sessions.every(s => s.min <= 30 || s.type === 'hribi')).toBe(true)
  })
  it('ena sama možnost dni se ne vpraša; več možnosti se', () => {
    expect(ruleQuestions('Rad delam: tek.', { avail: [1, 3], today: TODAY }).questions.some(x => x.id === 'dni')).toBe(false)
    expect(ruleQuestions('Rad delam: tek.', { avail: [0, 2, 4], today: TODAY }).questions.some(x => x.id === 'dni')).toBe(true)
  })
})

/* ---------- zasloni ---------- */
let div: HTMLDivElement | null = null, root: Root | null = null
async function render(el: ReactElement): Promise<HTMLDivElement> {
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root!.render(el) })
  return div
}
async function unmount() { if (root) await act(async () => root!.unmount()); div?.remove(); root = null; div = null }
afterEach(async () => { await unmount(); vi.useRealTimers(); document.body.innerHTML = '' })
const sp = (x: string) => x.replace(/[  ⁠]/g, ' ')
const txt = (d: Element) => sp(d.textContent || '')
const btn = (label: string | RegExp, root: ParentNode = document) => [...root.querySelectorAll('button')].find(b => (typeof label === 'string' ? sp(b.textContent || '').trim() === label || b.getAttribute('aria-label') === label : label.test(sp(b.textContent || ''))))
async function click(label: string | RegExp) { const b = btn(label); if (!b) throw new Error(`ni gumba: ${label}`); await act(async () => { b.click() }) }
async function type(el: HTMLTextAreaElement, v: string) {
  await act(async () => { Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')!.set!.call(el, v); el.dispatchEvent(new Event('input', { bubbles: true })) })
}
const state = (o: Record<string, unknown> = {}) => ({ ready: true, today: TODAY, profile: NEW, activities: [], plan: [], checkins: [], weather: null, user: null, changes: [], settings: {}, sync: { state: 'off' }, mealsToday: [], recentMeals: [], ...o })
beforeEach(() => {
  S.state = state(); S.nav = []; sessionStorage.clear(); localStorage.clear()   // (v3.51) osnutek uvoda je v localStorage
  window.scrollTo = vi.fn() as unknown as typeof window.scrollTo
  Element.prototype.scrollIntoView = vi.fn()
  ;(store.applyAgreement as unknown as ReturnType<typeof vi.fn>).mockClear?.()
})

describe('C11 uvod brez računa: razlaga pred Googlovo prijavo', () => {
  it('pod »Naprej« piše, da sledi prijava z Googlom; pot brez prijave je gumb', async () => {
    const d = await render(<Sestavi />)
    expect(txt(d)).toContain('Trener teče prek AI — potrebna je prijava z Googlom.')
    expect(btn('Raje brez prijave (vprašalnik brez AI)')?.className).toMatch(/\bbtn\b.*\bghost\b/)
  })
})

describe('C09 osnutek ostane ob ponovnem odprtju uvoda', () => {
  it('besedilo, izbire in dnevi ostanejo; ob prvem odprtju brez sprememb osnutka ni', async () => {
    const d = await render(<Sestavi />)
    expect(localStorage.getItem('formai.uvod')).toBeNull()
    await type(d.querySelector('#sest-wish') as HTMLTextAreaElement, 'Ob torkih nimam časa.')
    await click('Tek')
    await click('sreda: nimam časa')
    await unmount()
    const d2 = await render(<Sestavi />)
    expect((d2.querySelector('#sest-wish') as HTMLTextAreaElement).value).toBe('Ob torkih nimam časa.')
    expect(btn('Tek')?.getAttribute('aria-pressed')).toBe('true')
    expect(btn('sreda: imam čas')).toBeTruthy()
  })
})

describe('C01 + C02 + C12 + C23 + C09 kolesar s Franjo po pravilih (cela pot)', () => {
  it('potrdi tekmo, ~7 h, »Več ur« z eno številko prej, »Preskoči«, cilj gre v profil, osnutek se pobriše', async () => {
    const d = await render(<Sestavi />)
    for (const c of ['Pripravljen na tekmo', 'Hitrejši in vzdržljivejši', 'Kolo', 'Redno, več let']) await click(c)
    await click('Zunaj po cesti')
    await type(d.querySelector('#sest-wish') as HTMLTextAreaElement, TEXT_K)
    for (const day of ['torek', 'sreda', 'četrtek', 'sobota', 'nedelja']) await click(`${day}: nimam časa`)
    await click('Raje brez prijave (vprašalnik brez AI)')
    expect(txt(d)).toContain('Tvoja tekma: Maraton Franja · 13. 6. 2027 · 156 km. Je prav?')
    await click('Da')
    await click('4')
    await click('6–8 h')
    await click('Ne')
    await click('Naprej ›')
    expect(txt(d)).toContain('Do tekme: Maraton Franja')
    expect(txt(d)).toContain('Kolesarski načrt do tekme Maraton Franja (13. 6. 2027): faze, vrh forme in teden dirke.')
    expect(txt(d)).toMatch(/~7(,5)? h na teden/)
    expect(btn('Več kardia')).toBeUndefined()
    await click('Več ur')
    const talk = [...d.querySelectorAll('.talk:not(.me)')].map(txt)
    const last = talk[talk.length - 1]!
    expect(last).not.toMatch(/Medtem/)
    expect(last.match(/→/g)?.length).toBe(1)
    expect(last).toMatch(/Spremenil: skupaj .+ → .+ na teden/)
    // brez prijave: AI se ne ponuja, ko so pravila prošnjo razumela (in pripomba ni odprla prijave)
    expect(btn('↻ Poskusi znova z AI')).toBeUndefined()
    expect((store.signIn as unknown as ReturnType<typeof vi.fn>).mock.calls.length).toBe(0)
    expect(localStorage.getItem('formai.uvod')).not.toBeNull()
    vi.useFakeTimers()
    await click('Dogovorjeno — sestavi moj načrt')
    await act(async () => { await vi.advanceTimersByTimeAsync(200) })
    expect(btn('Preskoči ›')).toBeUndefined()   // prva predstava: »Preskoči« šele po 10 s
    await act(async () => { await vi.advanceTimersByTimeAsync(10_500) })
    await click('Preskoči ›')
    await act(async () => { await vi.advanceTimersByTimeAsync(3000) })
    const calls = (store.applyAgreement as unknown as ReturnType<typeof vi.fn>).mock.calls
    expect(calls.length).toBe(1)
    expect(calls[0]![1]).toMatchObject({ event: { name: 'Maraton Franja', date: '2027-06-13', distanceKm: 156 } })
    expect((calls[0]![0] as Focus).title).toBe('Do tekme: Maraton Franja')
    expect(S.nav).toContain('danes')
    expect(localStorage.getItem('formai.uvod')).toBeNull()
  })
})

describe('C23 nov dogovor: »Preskoči« takoj', () => {
  it('again: gumb je viden takoj, klik shrani in odpre aplikacijo', async () => {
    S.state = state({ profile: { ...NEW, onboardingDone: true } })
    const f = normalizeFocus({ wish: 'Rad delam: tek.', sessions: [{ type: 'tek', cardio: 'lahko', min: 30 }, { type: 'tek', cardio: 'lahko', min: 30 }], aims: ['kondicija'] }, { by: 'pravila' })!
    const onSave = vi.fn(async () => {}), onDone = vi.fn()
    vi.useFakeTimers()
    await render(<BuildShow focus={f} basics={{ sex: 'm', age: 30, heightCm: 180, weightKg: 75, avail: [0, 2, 4], trainTime: null, push: 'zmerno', main: 'kardio' }} ai={false} again onSave={onSave} onDone={onDone} />)
    await act(async () => { await vi.advanceTimersByTimeAsync(50) })
    await click('Preskoči ›')
    await act(async () => { await vi.advanceTimersByTimeAsync(2000) })
    expect(onSave).toHaveBeenCalledTimes(1)
    expect(onDone).toHaveBeenCalledTimes(1)
  })
})

describe('C03 vodena vadba: tek nikoli v vatih', () => {
  const P = { ...NEW, ftp: 250, onboardingDone: true, gear: { ...NEW.gear, powerMeter: true } }
  const dayOf = (kind: PlanDay['kind'], title: string): PlanDay => ({ id: `d-${kind}`, date: TODAY, kind, title, desc: 'Pogovorni tempo.', durationMin: 30, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW }) as PlanDay
  it('tek z merilnikom moči: »utrip ali občutek«; kolo z merilnikom: »vati«', async () => {
    S.state = state({ profile: P, plan: [dayOf('tek', 'Tek — lahko 30 min')], routeLib: null, routesBusy: false, toast: null, settings: { lang: 'sl', intervals: null } })
    const d = await render(<Vadba />)
    expect(txt(d)).toContain('Med treningom: utrip ali občutek za vsak korak')
    await unmount()
    S.state = state({ profile: P, plan: [dayOf('kolo', 'Z2 vožnja')], routeLib: null, routesBusy: false, toast: null, settings: { lang: 'sl', intervals: null } })
    const d2 = await render(<Vadba />)
    expect(txt(d2)).toContain('Med treningom: vati za vsak korak')
  })
})

// pomožno: weekDiff ostane ena vrstica s skupnim časom (za C12 odgovor)
describe('C12 ena številka »prej«', () => {
  it('weekDiff od prejšnjega predloga: ena primerjava skupnega časa', () => {
    const a = { sessions: [{ type: 'kolo', cardio: 'lahko', min: 90 }, { type: 'kolo', cardio: 'dolgo', min: 150 }] } as Pick<Focus, 'sessions'>
    const b = { sessions: [{ type: 'kolo', cardio: 'lahko', min: 105 }, { type: 'kolo', cardio: 'dolgo', min: 175 }] } as Pick<Focus, 'sessions'>
    expect(weekDiff(a, b)).toBe('skupaj 4 h → 4 h 40 min na teden')
    expect(weekLine(b)).toBe('2 dneva · ~4,5 h na teden')
  })
})
