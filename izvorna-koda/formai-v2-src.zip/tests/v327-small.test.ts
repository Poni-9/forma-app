import { describe, it, expect, vi } from 'vitest'
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => ({ name: 'plan', params: {} }) }))
import { scaleDraft } from '../src/screens/Prehrana'
import { applyDayEdit, ADD_DEFAULT } from '../src/screens/Plan'
import { dayGen } from '../src/ui/format'
import type { PlanDay } from '../src/domain/types'

const NOW = '2026-10-03T08:00:00.000Z'

describe('drobne izboljšave v3.27', () => {
  it('količina obroka: ½, 1½, 2× preračuna vse številke in sestavine; prazna polja ostanejo prazna', () => {
    const d = { kcal: '620', grams: '', prot: '31', carb: '85', fat: '17', items: [{ name: 'ovseni kosmiči', qty: '80 g', kcal: 296 }, { name: 'banana', qty: null, kcal: 105 }] }
    const h = scaleDraft(d, 0.5)
    expect(h).toMatchObject({ kcal: '310', grams: '', prot: '16', carb: '43', fat: '9' })
    expect(h.items).toEqual([{ name: 'ovseni kosmiči', qty: '80 g ×½', kcal: 148 }, { name: 'banana', qty: '×½', kcal: 53 }])
    expect(scaleDraft(d, 2).kcal).toBe('1240')
    expect(scaleDraft({ ...d, items: undefined }, 1.5).kcal).toBe('930')
  })
  it('dan počitka → dodan trening: lahka vožnja s trajanjem, TSS in brez vloge počitka', () => {
    const rest: PlanDay = { id: 'r', date: '2026-10-05', kind: 'pocitek', title: 'Počitek', desc: 'Hoja.', durationMin: 0, zone: null, tssTarget: 0, role: null, source: 'rules', createdAt: NOW, updatedAt: NOW }
    const out = applyDayEdit(rest, ADD_DEFAULT, [])
    expect(out).toMatchObject({ id: 'r', kind: 'kolo', title: 'Z2 vzdržljivost', durationMin: 60, zone: 'Z2', tssTarget: 50, role: null })
  })
  it('rodilnik dni: do nedelje, do ponedeljka', () => {
    expect(dayGen('2026-10-04')).toBe('nedelje')
    expect(dayGen('2026-10-05')).toBe('ponedeljka')
    expect(dayGen('2026-10-07')).toBe('srede')
  })
})
