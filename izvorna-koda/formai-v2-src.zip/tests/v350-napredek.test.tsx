// v3.50 NAPREDEK — Napredek in grafi: smer cilja teže, rekordi po športu, grafi (os, kontrast, bralnik, cilj zunaj
// razpona, vrzel do danes), kartica cilja brez FTP in za mladoletne, stavki v Motorju, testi (pražni utrip, vsi),
// AI ocena meseca samo s prijavo, doslednost z uvoženo zgodovino, ure tedna iz enega vira (H16), fmtDur.
import 'fake-indexeddb/auto'
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>() }))
vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
vi.mock('@/state/store', async (orig) => ({
  ...(await orig<typeof import('../src/state/store')>()),
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  toast: () => undefined,
}))
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => ({ name: 'napredek', params: {} }), subscribeRoute: () => () => undefined }))

import * as repo from '../src/data/repo'
import { Napredek, weightPace, goalDir, consistencyDays, motorNote, phaseLine } from '@/screens/Napredek'
import { DotLineChart, FormChart, StackBars, niceTicks } from '@/ui/charts'
import { GoalCard } from '@/ui/GoalCard'
import { RecordsCard, recordsSum } from '@/ui/RecordsCard'
import { RealityCard } from '@/ui/RealityCard'
import { ZonesCard } from '@/ui/ZonesCard'
import { thisWeek } from '@/ui/LastWeekCard'
import { customWeeks } from '@/ui/PlanHero'
import { records, yearTotals, recordSport } from '../src/domain/training/records'
import { fmtDur, addDays, weekStartIso } from '../src/domain/training/load'
import { levelOf } from '../src/domain/training/goal'
import { weekContext, FRANJA_2027 } from '../src/domain/training/planner'
import { hrZoneRows } from '../src/domain/training/zwo'
import { termOf } from '../src/domain/glossary'
import { normalizeFocus, weekLine, dealStrategy } from '../src/domain/focus/model'
import { dm } from '@/ui/format'
import type { Activity, PlanDay, Profile, TestEntry } from '../src/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const NOW = '2026-09-01T08:00:00.000Z'
const TODAY = '2026-10-18'   // nedelja
const nb = (s: string | null | undefined) => (s || '').replace(/[  ⁠]/g, ' ')
const P = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 180, weightKg: 79.9, restHr: 50, maxHr: 195, lthr: 175, ftp: 250, ftpDate: '2026-09-20',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true }, hoursPerWeek: 11, baseHours: null,
  strength: { on: false, equipment: 'home', phases: null }, strengthDays: 0, goal: 'dirka', deficit: 0, neat: 1.4,
  event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', onboardingDone: true, trainTime: 'popoldne', createdAt: NOW, updatedAt: NOW,
  races: [], ...o,
} as Profile)
const act1 = (id: string, date: string, o: Partial<Activity> = {}): Activity => ({ id, source: 'manual', sport: 'kolo', date, name: 'Vožnja ' + id, durationMin: 90, distKm: 40, elevM: 300, tss: 70, aiEligible: true, geoRetain: true, createdAt: NOW, updatedAt: NOW, ...o } as Activity)
const test1 = (id: string, date: string, kind: TestEntry['kind'], value: number, unit = 'bpm'): TestEntry => ({ id, date, kind, value, unit } as TestEntry)

let div: HTMLDivElement, root: Root
const render = async (el: React.ReactNode) => { await act(async () => { root.render(el) }) }
const text = () => nb(div.textContent)
beforeEach(() => { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div) })
afterEach(async () => { await act(async () => root.unmount()); div.remove(); location.hash = '' })
function setState(o: { profile?: Profile; today?: string; checkins?: any[]; activities?: Activity[]; plan?: PlanDay[]; tests?: TestEntry[]; user?: unknown; meals?: any[] } = {}) {
  S.state = { ready: true, settings: { ...repo.defaultSettings(), tests: o.tests || [] }, changes: [], toast: null, sync: { state: 'off' }, authKnown: true, pro: false, wellness: null, checkinToday: null, today: o.today || TODAY, profile: o.profile || P(), plan: o.plan || [], activities: o.activities || [], mealsToday: [], recentMeals: o.meals || [], checkins: o.checkins || [], weather: null, user: o.user ?? null }
}
const weighs = (from: string, n: number, kg: (i: number) => number) => Array.from({ length: n }, (_, i) => ({ date: addDays(from, i), weightKg: kg(i) }))

/* ---------- domena in pomožne funkcije ---------- */

describe('E54 — fmtDur zaokroži minute pred urami', () => {
  it('59,6 min je »1 h«, 119,6 »2 h«, ostalo kot prej', () => {
    expect(fmtDur(59.6)).toBe('1 h')
    expect(fmtDur(119.6)).toBe('2 h')
    expect(fmtDur(125)).toBe('2 h 05 min')
    expect(fmtDur(44.4)).toBe('44 min')
    expect(fmtDur(60)).toBe('1 h')
    expect(fmtDur(0)).toBe('—')
  })
})

describe('E06 — cilj nad trenutno težo ali na cilju', () => {
  const base = { stale: false, dw: 0, avg7: 79.9, today: TODAY, noise: 0.05, nPace: 14 }
  it('cilj 85 kg pri 79,9: padec teže ni »Tempo je pravi« (zeleno), ampak »cilj je višje«', () => {
    expect(goalDir(79.9, 85)).toBe('gain')
    const down = weightPace({ ...base, target: 85, rate: -0.3 })
    expect(down.text).not.toMatch(/Tempo je pravi/)
    expect(down.color).not.toBe('var(--ok)')
    expect(nb(down.text)).toBe('Teža pada (−0,30 kg na teden), cilj je višje — dodaj 200–300 kcal na dan.')
    const up = weightPace({ ...base, target: 85, rate: 0.3 })
    expect(up.text).toMatch(/^Tempo je pravi — teža raste proti cilju\./)
    expect(up.color).toBe('var(--ok)')
    expect(weightPace({ ...base, target: 85, rate: 0.7 }).text).toMatch(/nad 0,5 kg gre večinoma v maščobo/)
  })
  it('na cilju (±0,5 kg): »Si na cilju«, padec pod cilj opozori', () => {
    expect(goalDir(79.9, 80)).toBe('hold')
    expect(weightPace({ ...base, target: 80, rate: -0.02 }).text).toBe('Si na cilju — drži težo (±0,5 kg).')
    const fall = weightPace({ ...base, target: 80, rate: -0.3 })
    expect(fall.text).toMatch(/na cilju/)
    expect(fall.text).not.toMatch(/Tempo je pravi/)
    // prehitra izguba ostane opozorilo kot prej
    expect(weightPace({ ...base, target: 80, rate: -0.6 }).text).toMatch(/več kot 0,5 kg je prehitro/)
  })
  it('hujšanje je nespremenjeno', () => {
    expect(goalDir(79.9, 72)).toBe('lose')
    expect(weightPace({ ...base, target: 72, rate: -0.4 }).text).toMatch(/^Tempo je pravi\./)
  })
})

describe('E21 + E49 — rekordi po športu, »nov« šele, ko preseže prejšnjega', () => {
  const runs = [act1('r1', '2026-09-02', { sport: 'tek', distKm: 8, durationMin: 50, elevM: 60 }), act1('r2', '2026-09-20', { sport: 'tek', distKm: 12, durationMin: 70, elevM: 80 }), act1('r3', '2026-10-10', { sport: 'tek', distKm: 15, durationMin: 90, elevM: 120 })]
  it('tekač: najdaljši tek in letni seštevek teka', () => {
    expect(records(runs, TODAY, 'tek').distance!.value).toBe(15)
    expect(records(runs, TODAY, 'tek').distance!.fresh).toBe(true)
    expect(yearTotals(runs, TODAY, 'tek').now.km).toBe(35)
    expect(recordSport(runs, TODAY, false)).toBe('tek')
    expect(recordSport(runs, TODAY, true)).toBe('kolo')
  })
  it('ena vožnja: brez rekordov; tri vožnje v 14 dneh: brez »nov« (ni prejšnjega rekorda)', () => {
    expect(records([act1('1', '2026-10-17')], TODAY).distance).toBeNull()
    const three = [act1('1', '2026-10-10'), act1('2', '2026-10-12', { distKm: 50 }), act1('3', '2026-10-17', { distKm: 42 })]
    const r = records(three, TODAY)
    expect(r.distance!.value).toBe(50)
    expect([r.distance!.fresh, r.duration!.fresh, r.climb!.fresh, r.week!.fresh]).toEqual([false, false, false, false])
  })
  it('kartica: tekač dobi »Letos in rekordi · tek«; zapisi iz načrta brez »0 km« in »0 m vzpona«', async () => {
    await render(<RecordsCard acts={runs} today={TODAY} sport="tek" />)
    expect(text()).toMatch(/Letos in rekordi · tek/)
    expect(text()).toMatch(/Najdaljši tek/)
    expect(text()).toMatch(/35\s*km v 2026/)
    const plan = [1, 2, 3].map(i => act1('p' + i, `2026-10-1${i}`, { source: 'plan', distKm: null, elevM: null }))
    await render(<RecordsCard acts={plan} today={TODAY} />)
    expect(text()).not.toMatch(/km v 2026/)
    expect(text()).not.toMatch(/m vzpona/)
    expect(text()).toMatch(/5 h\s*na kolesu/)
  })
  it('povzetek razdelka s številkami', () => {
    expect(nb(recordsSum(runs, TODAY, 'tek'))).toBe('35 km · 4 h letos')
  })
})

describe('E38 — raven po W/kg kot v tabeli; vodnik z isto lestvico', () => {
  it('3,76 je »Dober amater«, 3,8 »Top amater«, 4,36 še »Top amater«', () => {
    expect(levelOf(3.76)!.name).toBe('Dober amater')
    expect(levelOf(3.8)!.name).toBe('Top amater')
    expect(levelOf(4.36)!.name).toBe('Top amater')
    expect(levelOf(3.25)!.name).toBe('Povprečen amater')
    expect(termOf('wkg').d).toContain('3,3–3,7')
    expect(termOf('wkg').d).not.toContain('dober amater ~4')
  })
})

describe('E48 — cone utripa: iz česa je ocena', () => {
  it('samo max utrip: »90 % max«; max in mirovni: Karvonen', async () => {
    expect(hrZoneRows({ maxHr: 190, restHr: null, lthr: null })!.basis).toBe('max')
    expect(hrZoneRows({ maxHr: 190, restHr: 50, lthr: null })!.basis).toBe('karvonen')
    expect(hrZoneRows({ maxHr: 190, restHr: 50, lthr: 172 })!.basis).toBe('lthr')
    await render(<ZonesCard p={P({ lthr: null, restHr: null, maxHr: 190, ftp: null, gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false } })} />)
    expect(text()).toMatch(/ocena: 90 % max utripa/)
    expect(text()).not.toMatch(/max in mirovnega/)
  })
})

describe('E50 — doslednost z uvoženo zgodovino', () => {
  it('vadbe pred začetkom: okno 28 dni (hrana od začetka)', () => {
    const p = { createdAt: `${TODAY}T07:00:00.000Z` }
    expect(consistencyDays(p, TODAY)).toBe(1)
    expect(consistencyDays(p, TODAY, addDays(TODAY, -20))).toBe(28)
    expect(consistencyDays(p, TODAY, TODAY)).toBe(1)
  })
})

describe('E25 + E53 — stavki v Motorju', () => {
  it('»Hujšanje dvigne W/kg« samo odraslim z vsaj 1 kg do cilja', () => {
    expect(motorNote({ custom: false, minor: false, target: 72, avg7: 79.9 })).toMatch(/^Hujšanje dvigne W\/kg/)
    expect(motorNote({ custom: false, minor: true, target: 72, avg7: 79.9 })).not.toMatch(/Hujšanje/)
    expect(motorNote({ custom: false, minor: false, target: 80, avg7: 79.9 })).not.toMatch(/Hujšanje/)
    expect(motorNote({ custom: false, minor: false, target: null, avg7: 79.9 })).not.toMatch(/Hujšanje/)
  })
  it('dogovor: »Teden 4 dogovora«, ne ime načrta kot faza', () => {
    expect(phaseLine({ custom: true, phaseName: 'Tek', week: 4, total: null, recovery: false })).toBe('Teden 4 dogovora.')
    expect(phaseLine({ custom: true, phaseName: 'Tek', week: 4, total: null, recovery: true })).toBe('Lažji teden (4.).')
    expect(phaseLine({ custom: false, phaseName: 'Osnova', week: 5, total: 38, recovery: false })).toBe('Osnova, teden 5/38.')
    expect(thisWeek({ custom: true, recovery: false, phaseName: 'Tek', week: 4, hours: 1.5 }, 75, 0)).toBe('teden 4 dogovora, 1 h 15 min')
  })
})

describe('H16 — ure tedna iz enega vira', () => {
  const f = normalizeFocus({ v: 1, mode: 'meri', wish: 'tek', sports: ['tek'], sessions: [{ type: 'tek', min: 25 }, { type: 'tek', min: 25 }, { type: 'tek', min: 25 }] })!
  it('dogovor pod 2 h točno (»1 h 15 min«), nad 2 h zaokroženo', () => {
    expect(nb(weekLine(f))).toBe('3 dnevi · 1 h 15 min na teden')
    const big = normalizeFocus({ v: 1, mode: 'meri', wish: 'tek', sports: ['tek'], sessions: [{ type: 'tek', min: 60 }, { type: 'tek', min: 60 }, { type: 'tek', min: 75 }] })!
    expect(weekLine(big)).toBe('3 dnevi · ~3,5 h na teden')
    // stara shranjena vrstica tedna se še vedno skrije
    expect(dealStrategy({ ...f, strategy: '– 3 dnevi · ~1,5 h na teden: Tek 3×.\n– Spanec 7–9 h.' } as never)).toEqual(['Spanec 7–9 h.'])
  })
  it('trak tednov: sestavljen teden šteje minute iz načrta (kot napredek tedna)', () => {
    const p = P({ focus: f, cycleStart: '2026-10-05', event: null })
    const ws = weekStartIso(TODAY)
    const day = (d: number, min: number, o: Partial<PlanDay> = {}): PlanDay => ({ id: 'd' + d, date: addDays(ws, d), kind: 'tek', title: 'Tek in hoja', desc: '', durationMin: min, source: 'rules', createdAt: NOW, updatedAt: NOW, ...o } as PlanDay)
    const plan = [day(0, 25), day(2, 25), day(4, 25), day(5, 0, { kind: 'pocitek' }), day(6, 30, { optional: true })]
    const [w0, w1] = customWeeks(p, ws, 2, plan)
    expect(w0!.tek).toBe(75)
    expect(w0!.n.tek).toBe(3)
    // naslednji teden še ni sestavljen: po dogovoru
    expect(w1!.tek).toBe(Math.round(25 * weekContext(p, addDays(ws, 7)).volume) * 3)
  })
})

/* ---------- grafi ---------- */

describe('E40 + E41 + E22 + E43 — grafi', () => {
  it('os forme pri −16 … 80 ima korak 20 (prej samo »0« in »50«); ure 0 … 8,9 korak 2', () => {
    const t = niceTicks(-23.7, 87.7, 4)
    expect(t.length).toBeGreaterThanOrEqual(5)
    expect(t).toContain(20)
    expect(niceTicks(0, 8.9, 3)).toEqual([0, 2, 4, 6, 8])
    expect(niceTicks(0, 9.5, 3)).toEqual([0, 2, 4, 6, 8])
    // širok razpon (utrujenost po težkem tednu): še vedno 4–7 oznak, ne samo »0« in »50«
    const wide = niceTicks(-34, 92, 4)
    expect(wide.length).toBeGreaterThanOrEqual(4)
    expect(wide.length).toBeLessThanOrEqual(7)
    // teža 79,25 … 80,65: korak 0,5 kot prej
    expect(niceTicks(79.25, 80.65, 4)).toEqual([79.5, 80, 80.5])
  })
  it('graf forme: bralnik sliši zdajšnje vrednosti; utrujenost ni oranžna kot moč; ploskev z obrobo', async () => {
    const data = Array.from({ length: 30 }, (_, i) => ({ date: addDays('2026-09-19', i), ctl: 30 + i * 0.3, atl: 20 + (i % 5), tsb: 10 - i }))
    await render(<FormChart data={data} />)
    const svg = div.querySelector('svg')!
    expect(nb(svg.getAttribute('aria-label'))).toMatch(/^Graf forme za 30 dni: zdaj kondicija 39, utrujenost 24, forma −19$/)
    expect(div.querySelector('.atl-line')!.getAttribute('stroke')).not.toBe('var(--t-moc)')
    expect(div.querySelectorAll('.tsb-edge').length).toBe(2)
    expect([...div.querySelectorAll('text')].every(t => +t.getAttribute('font-size')! >= 10.5)).toBe(true)
  })
  it('stolpci ur: vsota nad stolpcem in opis za bralnik', async () => {
    const bars = [{ label: 'a', parts: [{ v: 1, color: 'x' }, { v: 0.5, color: 'y' }] }, { label: 'b', parts: [{ v: 2, color: 'x' }] }]
    await render(<StackBars bars={bars} legend={[]} label="Ure vadbe na teden" />)
    expect(div.querySelector('svg')!.getAttribute('aria-label')).toBe('Ure vadbe na teden')
    expect([...div.querySelectorAll('.bar-sum')].map(t => t.textContent)).toEqual(['1,5', '2'])
  })
})

describe('E23 + E44 + E41 + E55 — graf teže', () => {
  const pts = [{ date: '2026-09-20', v: 80 }, { date: '2026-09-27', v: 79.5 }, { date: '2026-10-04', v: 79.9 }]
  it('cilj daleč od meritev ne stisne grafa: os ≤ 4 kg, puščica s ciljem; bralnik sliši predmet in cilj', async () => {
    await render(<DotLineChart points={pts} reference={72} refLabel="cilj" unit="kg" title="Teža" />)
    const ticks = [...div.querySelectorAll('svg g text')].map(t => +String(t.textContent).replace(',', '.'))
    expect(Math.max(...ticks) - Math.min(...ticks)).toBeLessThanOrEqual(4)
    expect(nb(div.querySelector('.ref-label')!.textContent)).toBe('cilj 72 kg ↓ · še 7,9 kg')
    expect(nb(div.querySelector('svg')!.getAttribute('aria-label'))).toBe('Teža, 3 meritve od 20. 9. do 4. 10., zadnja 79,9 kg, cilj 72 kg')
  })
  it('blizu cilja: črta z napisom; until podaljša os do danes', async () => {
    await render(<DotLineChart points={pts} reference={78} unit="kg" until={TODAY} />)
    expect(nb(div.querySelector('.ref-label')!.textContent)).toBe('cilj 78 kg')
    const xl = [...div.querySelectorAll('svg > text')].map(t => t.textContent)
    expect(xl[xl.length - 1]).toBe('18. 10.')
  })
})

/* ---------- kartice ---------- */

describe('GoalCard — brez FTP, mladoletni, besedila (E24, E37, E55, F01)', () => {
  const noFtp = (o: Partial<Profile> = {}) => P({ ftp: null, ftpDate: null, goalStart: { date: '2026-09-21', ftp: null, weightKg: 80 }, ...o } as Partial<Profile>)
  it('E24: brez FTP ure iz profila (11 h), ne »12–14 h«', async () => {
    setState({ profile: noFtp() })
    await render(<GoalCard full />)
    expect(text()).toMatch(/Idealen scenarij: brez bolezni in poškodb, povprečno 11 h na teden čez sezono/)
    expect(text()).not.toMatch(/12–14/)
  })
  it('E37: test v tednu, ki se končuje (nedelja) — ne »v tednu od« tega tedna; v ponedeljek »ta teden«', async () => {
    const p = noFtp()
    let ws = '2026-09-21'
    for (let i = 0; i < 30 && !weekContext(p, ws).test; i++) ws = addDays(ws, 7)
    expect(weekContext(p, ws).test).toBe(true)
    setState({ profile: p, today: addDays(ws, 6) })
    await render(<GoalCard full />)
    expect(text()).toMatch(/FTP še ne poznam/)
    expect(text()).not.toContain(`v tednu od ${nb(dm(ws))}`)
    setState({ profile: p, today: ws })
    await render(<GoalCard full />)
    expect(text()).toMatch(/z 20-minutnim testom ta teden/)
  })
  it('E55: Danes brez FTP pove, kdaj pokažem pot; »h na teden« povsod', async () => {
    setState({ profile: noFtp() })
    await render(<GoalCard compact />)
    expect(text()).toMatch(/Moč \(FTP\) še ne poznam — ko jo izmeriš s testom, pokažem pot do cilja\./)
    setState({ profile: P({ goalStart: { date: '2026-09-21', ftp: 240, weightKg: 80 } } as Partial<Profile>) })
    await render(<GoalCard full />)
    expect(text()).not.toMatch(/h\/teden/)
    expect(text()).toMatch(/pri \d+(,\d)? h na teden\)/)
  })
  it('F01: mladoletni — tabela mejnikov brez stolpca teže in brez stavkov o hujšanju', async () => {
    setState({ profile: P({ age: 16, goalStart: { date: '2026-09-21', ftp: 220, weightKg: 70 }, weightKg: 70, ftp: 220 } as Partial<Profile>) })
    await render(<GoalCard full />)
    const heads = [...div.querySelectorAll('th')].map(t => t.textContent)
    expect(heads).toEqual(['mejnik', 'FTP', 'W/kg'])
    expect(text()).toMatch(/Do 18\. leta ciljne teže ne računam/)
    expect(text()).not.toMatch(/teža pada večinoma v osnovi/)
  })
})

describe('E47 — Trening v resnici: vir po resnici', () => {
  it('ročne vožnje: ne »z Garmina«', async () => {
    const acts = Array.from({ length: 6 }, (_, i) => act1('m' + i, addDays(TODAY, -3 - i * 4)))
    setState({ activities: acts })
    await render(<RealityCard />)
    expect(text()).toMatch(/Iz tvojih zabeleženih voženj — ne iz načrta\./)
    expect(text()).not.toMatch(/Garmina/)
  })
})

/* ---------- zaslon Napredek ---------- */

describe('Napredek — zaslon', () => {
  const rides = Array.from({ length: 20 }, (_, i) => act1('k' + i, addDays(TODAY, -2 - i * 3), { tss: 80 }))
  it('E45 + E51: brez prijave ni »AI ocena meseca«; razdelek »Ta mesec · oktober«', async () => {
    location.hash = '#/napredek?sec=p-mesec'
    setState({ activities: rides })
    await render(<Napredek />)
    expect(text()).toMatch(/Ta mesec · oktober/)
    expect([...div.querySelectorAll('button')].some(b => /AI ocena meseca/.test(b.textContent || ''))).toBe(false)
    expect([...div.querySelectorAll('button')].some(b => b.textContent === 'Prijava za AI oceno')).toBe(true)
  })
  it('E45: prijavljen, a mesec brez vadb in hrane — ni gumba, pove zakaj', async () => {
    location.hash = '#/napredek?sec=p-mesec'
    setState({ activities: [act1('old', '2026-08-01')], user: { uid: 'u1' } })
    await render(<Napredek />)
    expect([...div.querySelectorAll('button')].some(b => /AI ocena meseca/.test(b.textContent || ''))).toBe(false)
    expect(text()).toMatch(/Ta mesec še ni česa oceniti/)
    setState({ activities: rides, user: { uid: 'u1' } })
    await render(<Napredek />)
    expect([...div.querySelectorAll('button')].some(b => /AI ocena meseca/.test(b.textContent || ''))).toBe(true)
  })
  it('E39 + E42 + E25: »v 6 tednih«, naslov stolpcev ur, brez »Hujšanje« na cilju', async () => {
    location.hash = '#/napredek?sec=p-motor'
    const long = Array.from({ length: 40 }, (_, i) => act1('L' + i, addDays(TODAY, -1 - i * 2), { tss: 60 }))
    setState({ activities: long, profile: P({ targetWeightKg: 80 } as Partial<Profile>), checkins: weighs(addDays(TODAY, -13), 14, () => 79.9) })
    await render(<Napredek />)
    expect(text()).toMatch(/v 6 tednih/)
    expect(text()).not.toMatch(/v 6 t\./)
    expect(text()).toMatch(/Ure na teden · 12 tednov/)
    expect(text()).not.toMatch(/Hujšanje dvigne/)
    expect(div.querySelector('svg[aria-label^="Ure vadbe na teden"]')).not.toBeNull()
  })
  it('H35: pod 3 vadbami kondicija »še računam«', async () => {
    location.hash = '#/napredek?sec=p-motor'
    setState({ activities: [act1('a', addDays(TODAY, -2))] })
    await render(<Napredek />)
    expect(text()).toMatch(/kondicija · še računam/)
  })
  it('E06 + E44: na cilju »NA CILJU«; staro tehtanje »POVPREČJE DO 4. 10.«', async () => {
    setState({ profile: P({ targetWeightKg: 80 } as Partial<Profile>), checkins: weighs(addDays(TODAY, -13), 14, () => 79.9) })
    await render(<Napredek />)
    expect(text()).toMatch(/NA CILJU/)
    expect(text()).not.toMatch(/DO CILJA/)
    setState({ checkins: weighs('2026-09-28', 7, () => 79.9) })
    await render(<Napredek />)
    expect(text()).toMatch(/POVPREČJE DO 4\. 10\./)
    expect(text()).not.toMatch(/7-DNEVNO POVPREČJE/)
  })
  it('E52 + A18: 15 testov → »pokaži vse (15)«; trend pražnega utripa', async () => {
    location.hash = '#/napredek?sec=p-testi'
    const tests = [...Array.from({ length: 13 }, (_, i) => test1('r' + i, addDays(TODAY, -7 * i), 'rhr', 48 + (i % 3))), test1('l1', '2026-08-20', 'lthr', 170), test1('l2', '2026-10-15', 'lthr', 174)]
    setState({ tests })
    await render(<Napredek />)
    const rows = () => div.querySelectorAll('#p-testi-b .icon-x').length
    expect(rows()).toBe(12)
    const more = [...div.querySelectorAll('button')].find(b => b.textContent === 'pokaži vse (15)')!
    expect(more).toBeTruthy()
    await act(async () => { more.click() })
    expect(rows()).toBe(15)
    // trend: obe vrsti z dvema rezultatoma; pražni utrip se izbere s čipom
    const chip = [...div.querySelectorAll<HTMLButtonElement>('#p-testi-b button')].find(b => b.textContent === 'Pražni utrip (test)')!
    expect(chip).toBeTruthy()
    await act(async () => { chip.click() })
    expect(text()).toMatch(/Pražni utrip \(test\): 170 bpm → 174 bpm · 2 testa od 20\. 8\./)
  })
  it('E21: tekač po meri ima »Letos in rekordi · tek« in km teka v mesecu', async () => {
    location.hash = '#/napredek?sec=p-mesec'
    const f = normalizeFocus({ v: 1, mode: 'meri', wish: 'tek', sports: ['tek'], sessions: [{ type: 'tek', min: 40 }, { type: 'tek', min: 40 }, { type: 'tek', min: 50 }] })!
    const runs = Array.from({ length: 6 }, (_, i) => act1('t' + i, addDays(TODAY, -1 - i * 3), { sport: 'tek', distKm: 7, elevM: 40, durationMin: 45 }))
    setState({ profile: P({ focus: f, event: null, cycleStart: '2026-09-21' } as Partial<Profile>), activities: runs })
    await render(<Napredek />)
    expect(text()).toMatch(/Letos in rekordi/)
    expect(text()).toMatch(/oktober 2026: 6 vadb, 4 h 30 min, 42 km teka, 240 m vzpona/)
  })
  it('E50: uvožena zgodovina prvi dan — vadbe zadnjih 28 dni, hrana od začetka', async () => {
    const acts = [1, 5, 9, 20].map(d => act1('h' + d, addDays(TODAY, -d)))
    setState({ profile: P({ createdAt: `${TODAY}T07:00:00.000Z` }), activities: acts })
    await render(<Napredek />)
    expect(text()).toMatch(/Doslednost · zadnjih 28 dni/)
    expect(text()).toMatch(/0\/1\s*dni s hrano/)
    expect(text()).toMatch(/4 vadbe/)
  })
})
