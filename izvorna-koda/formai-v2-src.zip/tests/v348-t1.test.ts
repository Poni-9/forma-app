import { describe, it, expect } from 'vitest'
import { buildWeek, weekContext, macroWeeks, realityCap, planHours, weekBikeMinutes, raceBreakfast, FRANJA_2027 } from '../src/domain/training/planner'
import { ftpPotential } from '../src/domain/training/goal'
import { effortOf } from '../src/domain/training/effort'
import { fueling } from '../src/domain/nutrition/energy'
import { addDays } from '../src/domain/training/load'
import type { Activity, PlanDay, Profile, Race } from '../src/domain/types'

/* v3.48 T1: logika načrta — ure po premoru in v prihodnjih tednih, tapering iz dejanskih ur, besedila brez Franje,
   osnova med oddaljenima ciljema, blag prvi VO2max, predaktivacija, slovnica opisov, test FTP, zajtrk pred tekmo,
   FTP po urah, »daljša vožnja«, Z2 na 5 min, intenzivnost teka in hribov. */

const now = new Date().toISOString()
const P = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 30, heightCm: 180, weightKg: 75, ftp: 250, ftpDate: '2026-09-15', maxHr: 190, restHr: 50, lthr: 172,
  gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: true }, strength: { on: false, equipment: 'none' },
  hoursPerWeek: 10, baseHours: null, onboardingDone: true, createdAt: now, updatedAt: now, event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', ...o,
} as Profile)
const ride = (date: string, min: number): Activity => ({ id: 'a' + date + min, source: 'intervals', sport: 'kolo', date, name: 'Vožnja', durationMin: min, tss: Math.round(min * 0.7), aiEligible: true, geoRetain: false } as Activity)
/** dve vožnji na teden (torek, sobota) po `h` urah skupaj, v tednih od `from` do `to` (ponedeljki) */
const weekly = (from: string, to: string, h: number): Activity[] => {
  const out: Activity[] = []
  for (let ws = from; ws <= to; ws = addDays(ws, 7)) out.push(ride(addDays(ws, 1), Math.round(h * 30)), ride(addDays(ws, 5), Math.round(h * 30)))
  return out
}
const T = '2026-10-17'                                     // sobota; ta teden se začne 12. 10.
const bike = (w: PlanDay[]) => w.filter(d => !d.optional && (d.kind === 'kolo' || d.kind === 'test'))
const text = (w: PlanDay[]) => w.flatMap(d => [d.title, d.desc, d.why || ''])

describe('A04 + B01: po premoru in v prihodnjih tednih načrt ne skoči na polne ure', () => {
  it('premor (starejše vožnje, zadnje 3 tedne nič) = najnižji začetek 4 h; nov uporabnik brez podatkov = brez stropa', () => {
    const acts = weekly('2026-08-31', '2026-09-28', 6)            // zadnja vožnja 3. 10.
    const rc = realityCap(acts, '2026-10-26', '2026-10-27')!
    expect(rc).not.toBeNull()
    expect(rc.cap).toBe(4); expect(rc.base).toBe(0)
    expect(realityCap([], '2026-10-26', '2026-10-27')).toBeNull()
    const p = P({ hoursPerWeek: 11 })
    expect(planHours(p, acts, '2026-10-26', '2026-10-27').hours).toBe(4)
    // naprej raste po ~10 % na teden, ne skoči nazaj na 9–10 h
    const h = [0, 1, 2, 3].map(k => planHours(p, acts, addDays('2026-10-26', 7 * k), '2026-10-27').hours)
    expect(Math.max(...h)).toBeLessThanOrEqual(5.5)
    const w = buildWeek({ profile: p, activities: acts, weekStart: '2026-10-26', notBefore: '2026-10-26', today: '2026-10-27' })
    expect(w.some(d => d.why?.includes('Po premoru začneš pri 4 h'))).toBe(true)
  })
  it('projekcija naslednjih tednov: iz tedna v teden največ ~25 % več (razen po razbremenilnem tednu)', () => {
    const p = P({ hoursPerWeek: 12 })
    const acts = weekly('2026-09-21', '2026-10-12', 5).filter(a => a.date <= T)
    const weeks = Array.from({ length: 11 }, (_, k) => addDays('2026-10-12', 7 * k))
    const h = weeks.map(ws => planHours(p, acts, ws, T).hours)
    const rec = weeks.map(ws => weekContext(p, ws).recovery)
    for (let k = 0; k + 1 < weeks.length; k++) if (!rec[k] && !rec[k + 1]) expect(h[k + 1]!).toBeLessThanOrEqual(h[k]! * 1.25)
    // »2 tedna«: teden čez dva tedna ni 2,5 × naslednjega
    // (po pregledu: naslednji teden je tu razbremenilni, zato primerjava z zadnjim obremenilnim — tekočim — tednom; ~10 % na teden)
    expect(planHours(p, acts, addDays('2026-10-12', 14), T).hours).toBeLessThanOrEqual(planHours(p, acts, '2026-10-12', T).hours * 1.1 * 1.1 + 0.5)
    expect(planHours(p, acts, addDays('2026-10-12', 28), T).capped).toBe(true)
  })
})

describe('B02: tapering in teden dirke iz dejanskih ur', () => {
  const ev = { name: 'Dirka X', date: '2026-11-01', distanceKm: 100, type: 'cestna' as const }
  const acts = weekly('2026-09-21', '2026-10-05', 3.5)
  const wk = (p: Profile, ws: string) => buildWeek({ profile: p, activities: acts, weekStart: ws, notBefore: ws, today: T })
  it('tapering ≤ 0,7 × zadnjega polnega tedna, teden dirke (brez dirke) še manj', () => {
    const p = P({ event: ev })
    expect(weekContext(p, '2026-10-19').phase).toBe('tapering')
    const load = weekBikeMinutes(wk(p, '2026-10-12')), taper = weekBikeMinutes(wk(p, '2026-10-19'))
    const race = bike(wk(p, '2026-10-26')).filter(d => d.role !== 'dirka').reduce((t, d) => t + d.durationMin, 0)
    expect(taper).toBeLessThanOrEqual(load * 0.7)
    expect(race).toBeLessThanOrEqual(load * 0.6)
    expect(planHours(p, acts, '2026-10-19', T).hours).toBeLessThan(weekContext(p, '2026-10-19').hours)
  })
  it('brez stropa (polne ure) ostane tapering po fazi', () => {
    const p = P({ event: ev })
    expect(planHours(p, [], '2026-10-19', T).hours).toBe(weekContext(p, '2026-10-19').hours)
  })
})

describe('B03: Franja, Kladje in 156 km samo pri Franji', () => {
  it('brez cilja 14 tednov in gorski kronometer: nikjer Franje', () => {
    const none = P({ event: null, races: [] })
    for (let k = 0; k < 14; k++) for (const t of text(buildWeek({ profile: none, activities: [], weekStart: addDays('2026-09-21', 7 * k), notBefore: '2026-01-01' }))) expect(t).not.toMatch(/Franj|Kladj|156 km/)
    const vr = P({ hoursPerWeek: 12, event: { name: 'Gorski kronometer Vršič', date: '2027-06-20', distanceKm: 12, type: 'vzpon' } })
    for (const w of macroWeeks(vr, T)) {
      expect(w.phaseDesc).not.toMatch(/Franj|Kladj/)
      for (const t of text(buildWeek({ profile: vr, activities: [], weekStart: w.weekStart, notBefore: '2026-01-01' }))) expect(t).not.toMatch(/Franj|Kladj|156 km/)
    }
  })
  it('pri Franji ostane: specifično »Za Franjo«, Kladje', () => {
    const p = P({ hoursPerWeek: 12 })
    expect(weekContext(p, '2027-04-19').phaseDesc).toMatch(/Za Franjo/)
    expect(text(buildWeek({ profile: p, activities: [], weekStart: '2027-04-19', notBefore: '2026-01-01' })).join(' ')).toMatch(/Kladj/)
  })
})

describe('B05: cilj A čez 2 tedna ne pobriše osnove pred glavnim ciljem', () => {
  it('razmik 30+ tednov: po počitku vsaj 8 tednov osnove', () => {
    const p = P({ races: [{ id: 'a', name: 'Jesenska A', date: '2026-10-31', distanceKm: 120, prio: 'A' } as Race] })
    const after = macroWeeks(p, T).filter(w => w.weekStart > '2026-11-01' && w.weekStart < '2027-06-07')
    expect(after.filter(w => w.phase === 'osnova').length).toBeGreaterThanOrEqual(8)
  })
})

describe('B09: začetnik — prvi VO2max blag', () => {
  it('raven 1, brez cilja: prvi ključni VO2max je 4 × 4, v prvih 12 tednih brez 30/15', () => {
    const p = P({ level: 1, hoursPerWeek: 4, ftp: null, ftpDate: null, event: null, races: [], cycleStart: '2026-10-19', gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false } })
    const all = Array.from({ length: 12 }, (_, k) => buildWeek({ profile: p, activities: [], weekStart: addDays('2026-10-19', 7 * k), notBefore: '2026-01-01', firstWeek: k === 0 })).flat()
    const v = all.find(d => d.role === 'kljucna' && /VO2max/.test(d.title))!
    expect(v.title).toBe('VO2max 4 × 4 min')
    expect(all.some(d => /30\/15/.test(d.title))).toBe(false)
  })
})

describe('B12 + B44: intenzivnost z besedo', () => {
  it('predaktivacija je lahko (kratki pospeški); tek in hribi imajo besedo', () => {
    expect(effortOf({ kind: 'kolo', zone: 'Z5', role: 'lahka', target: { lo: 275, hi: 300 }, title: 'Predaktivacija 3 × 1 min' })).toMatchObject({ w: 'lahko', sub: '3 kratki pospeški' })
    expect(effortOf({ kind: 'tek', zone: 'Z4', role: 'kljucna', target: null })!.w).toBe('težko')
    expect(effortOf({ kind: 'pohod', zone: 'Z2', role: 'lahka', target: null })!.w).toBe('lahko')
  })
  it('teden dirke: »Predaktivacija« samo dan pred dirko', () => {
    const w = buildWeek({ profile: P({ hoursPerWeek: 12 }), activities: [], weekStart: '2027-06-07', notBefore: '2026-01-01' })
    const pre = w.filter(d => /Predaktivacija/.test(d.title)).map(d => d.date)
    expect(pre).toEqual(['2027-06-12'])
  })
})

describe('A11 + B13 + B28 + B34: opisi intervalov', () => {
  it('brez merilnika: nikjer »pri po občutku« ali »pri zelo trdo«; »nato N min Z2« na 5 min; brez »najšibkejše točke«', () => {
    const p = P({ gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, races: [{ id: 'c', name: 'Kriterij', date: '2027-03-20', prio: 'C' } as Race] })
    const days = macroWeeks(p, T).flatMap(w => buildWeek({ profile: p, activities: [], weekStart: w.weekStart, notBefore: '2026-01-01' }))
    expect(days.some(d => /3 × 1 min zelo trdo \(RPE 9\)/.test(d.desc))).toBe(true)
    for (const d of days) {
      expect(d.desc).not.toMatch(/pri (po|zelo|vse)/)
      const m = /nato (\d+) min Z2/.exec(d.desc)
      if (m) expect(+m[1]! % 5).toBe(0)
      expect(d.why || '').not.toMatch(/najšibkejša/)
    }
  })
})

describe('A17: test FTP brez merilnika moči', () => {
  it('opis brez vatov; iztek v opisu = dejanski ostanek', () => {
    for (const pm of [false, true]) {
      const p = P({ gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: pm }, ftpDate: '2026-01-01' })
      expect(weekContext(p, '2026-10-12').test).toBe(true)                  // po treh lahkih tednih
      const t = buildWeek({ profile: p, activities: [], weekStart: '2026-10-12', notBefore: '2026-01-01' }).find(d => d.role === 'test')!
      expect(t).toBeTruthy()
      expect(t.desc).toContain(`${t.durationMin - 40} min iztek`)
      if (!pm) { expect(t.desc).not.toMatch(/\d\s*W\b/); expect(t.desc).toMatch(/pražni utrip/) }
    }
  })
})

describe('A42: zajtrk pred tekmo = Gorivo', () => {
  it('g OH na kg v opisu tekme in v Gorivu po istem pravilu', () => {
    const w = 75
    for (const min of [30, 100, 200]) for (const other of [false, true]) {
      const before = fueling({ kind: 'kolo', durationMin: min, zone: 'dirka', role: 'dirka', raceId: other ? 'r' : null }, { weightKg: w })!.before
      const m = /Zajtrk[^:]*:\s*(\d+)(?:–(\d+))?\s*g OH/.exec(before)!
      const lo = Math.round(+m[1]! / w), hi = Math.round(+(m[2] ?? m[1])! / w)
      const desc = raceBreakfast(min, other)
      expect(desc).toContain(lo === hi ? `~${lo} g OH na kg` : `${lo}–${hi} g OH na kg`)
      expect(before).toContain(desc.match(/Zajtrk ([\d–]+) h/)![1]! + ' h pred startom')
    }
  })
  it('kratka tekma (kronometer 18 km): opis ne piše ~2 g', () => {
    const p = P({ races: [{ id: 'k', name: 'Kronometer Vodice', date: '2026-10-23', distanceKm: 18, prio: 'B', type: 'kronometer' } as Race] })
    const r = buildWeek({ profile: p, activities: [], weekStart: '2026-10-19', notBefore: '2026-01-01' }).find(d => d.role === 'dirka')!
    expect(r.desc).toMatch(/1–2 g OH na kg/)
  })
})

describe('B15: FTP po urah na teden', () => {
  it('3, 4, 5 in 6 h ne dajo istega FTP', () => {
    const p = P({ ftp: 240, weightKg: 75 })
    const ideal = [3, 4, 5, 6].map(h => ftpPotential(p, T, h)!.ideal)
    for (let i = 1; i < ideal.length; i++) expect(ideal[i]!).toBeGreaterThan(ideal[i - 1]!)
  })
})

describe('B27: »Z2 — daljša vožnja« je najdaljša vožnja tedna', () => {
  it('pri 3 h na teden', () => {
    const p = P({ hoursPerWeek: 3, baseHours: 2.5 })
    for (let k = 0; k < 12; k++) {
      const w = bike(buildWeek({ profile: p, activities: [], weekStart: addDays('2026-09-21', 7 * k), notBefore: '2026-01-01' })).filter(d => d.role !== 'dirka')
      const long = w.find(d => d.title === 'Z2 — daljša vožnja')
      if (long) expect(long.durationMin).toBe(Math.max(...w.map(d => d.durationMin)))
    }
  })
})
