import { describe, it, expect } from 'vitest'
import { coachReview, splitStrengthParts } from '../src/domain/focus/coach'
import { normalizeFocus, tailsOf, trainingDays } from '../src/domain/focus/model'
import { ruleQuestions, ruleProposal } from '../src/domain/focus/rules'
import { scheduleWeek, weekWords } from '../src/domain/training/focusPlan'
import { availLine, questionsPrompt, proposalPrompt } from '../src/domain/ai/focusAi'
import type { AgreedSession } from '../src/domain/types'

const BLAZ = normalizeFocus({ wish: 'Postava: vitka in močna, six pack. Rad delam: fitnes, tek, kolo. Še: ful kondicije, ne izgubiti mišic, samo zgornji del.', sports: ['fitnes', 'tek', 'kolo'], aims: ['definicija', 'kondicija'], muscles: ['trebuh', 'prsa', 'hrbet', 'ramena', 'roke'], level: 2, equipment: ['fitnes'],
  sessions: [{ type: 'fitnes', part: 'zgornji', min: 40, day: 0 }, { type: 'tek', cardio: 'lahko', min: 20, after: true }, { type: 'fitnes', part: 'zgornji', min: 40, day: 4 }, { type: 'tek', cardio: 'intervali', min: 20, after: true }, { type: 'kolo', cardio: 'tempo', min: 45 }, { type: 'kolo', cardio: 'lahko', min: 50 }] }, { by: 'ai' })!

describe('trener razmisli (coachReview)', () => {
  it('deli moči: dvakrat zgornji del → potisk + poteg; dvakrat celo telo: začetnik ostane, izkušen zgornji + spodnji; podvojen del dobi dopolnilnega', () => {
    expect(splitStrengthParts(['zgornji', 'zgornji'], { upperOnly: true, level: 2 })).toEqual(['potisk', 'poteg'])
    expect(splitStrengthParts(['zgornji', 'zgornji', 'zgornji'], { upperOnly: false, level: 2 })).toEqual(['potisk', 'poteg', 'zgornji'])
    expect(splitStrengthParts(['celo', 'celo'], { upperOnly: false, level: 1 })).toEqual(['celo', 'celo'])
    expect(splitStrengthParts(['celo', 'celo'], { upperOnly: false, level: 2 })).toEqual(['zgornji', 'spodnji'])
    expect(splitStrengthParts(['celo', 'celo', 'celo'], { upperOnly: false, level: 3 })).toEqual(['potisk', 'noge', 'poteg'])
    expect(splitStrengthParts(['potisk', 'noge', 'potisk'], { upperOnly: false, level: 2 })).toEqual(['potisk', 'noge', 'zgornji'])
    expect(splitStrengthParts(['zgornji'], { upperOnly: true, level: 2 })).toEqual(['zgornji'])
  })
  it('Blažev predlog: dve vadbi zgornjega dela postaneta potisk + poteg, kardio po moči ostane, kolo gre na sre in ned (premor med težkimi dnevi), zakaj tako', () => {
    const r = coachReview(BLAZ, { age: 21 })
    expect(r.changed).toEqual(['deli moči'])
    expect(r.focus.sessions.filter(s => s.type === 'fitnes').map(s => [s.part, s.day])).toEqual([['potisk', 0], ['poteg', 4]])
    expect(tailsOf(r.focus.sessions).size).toBe(2)
    expect(weekWords(r.focus)).toBe('pon fitnes prsa, ramena, triceps + tek · sre kolo tempo · pet fitnes hrbet in biceps + tek intervali · ned kolo')
    expect(r.focus.why!.length).toBeGreaterThanOrEqual(3)
    expect(r.focus.why![0]).toMatch(/razdelil na potisk/)
    expect(r.focus.why!.join(' ')).toMatch(/premora/)
    expect(r.focus.why!.join(' ')).toMatch(/Napredovanje po blokih/)
    expect(r.focus.title).toBe(BLAZ.title)
    // drugič nič novega (idempotentno)
    const r2 = coachReview(r.focus, { age: 21 })
    expect(r2.changed).toEqual([])
    expect(r2.focus.sessions).toEqual(r.focus.sessions)
  })
  it('začetnik: intervali po moči postanejo lahek tek; celo telo dvakrat ostane z razlago', () => {
    const g = normalizeFocus({ wish: 'fitnes in tek', sports: ['fitnes', 'tek'], aims: ['misice'], level: 1, sessions: [{ type: 'fitnes', part: 'celo', min: 50 }, { type: 'tek', cardio: 'intervali', min: 30, after: true }, { type: 'fitnes', part: 'celo', min: 50 }, { type: 'tek', cardio: 'lahko', min: 30 }] }, { by: 'pravila' })!
    const r = coachReview(g)
    expect(r.changed).toEqual(['kardio po moči lahek'])
    expect(r.focus.sessions[1]).toMatchObject({ type: 'tek', cardio: 'lahko', after: true })
    expect(r.focus.sessions.filter(s => s.type === 'fitnes').map(s => s.part)).toEqual(['celo', 'celo'])
    expect(r.focus.why![0]).toMatch(/Začetnik: celo telo/)
  })
})

describe('razpored: premor med težkimi dnevi', () => {
  const S = (part: string, day?: number): AgreedSession => ({ type: 'fitnes', part: part as never, min: 45, ...(day != null ? { day } : {}) })
  const C = (cardio: string, type: 'tek' | 'kolo' = 'tek'): AgreedSession => ({ type, cardio: cardio as never, min: 30 })
  const words = (s: AgreedSession[], open = [0, 1, 2, 3, 4, 5, 6]) => weekWords({ sessions: s, offDays: [0, 1, 2, 3, 4, 5, 6].filter(d => !open.includes(d)), preferDays: null })
  it('4 seje: moč, intervali, moč, lahek tek → pon, sre, pet, ned (vsak težek dan ima premor)', () => {
    expect(words([S('zgornji'), C('intervali'), S('spodnji'), C('lahko')])).toBe('pon fitnes zgornji del · sre tek intervali · pet fitnes spodnji del · ned tek')
  })
  it('3 seje → pon, sre, pet; 2 seji → tor, pet; dnevi s časom tor, čet, sob → prav ti', () => {
    expect(words([S('celo'), C('lahko'), S('celo')])).toBe('pon fitnes celo telo · sre tek · pet fitnes celo telo')
    expect(words([S('celo'), C('lahko')])).toBe('tor fitnes celo telo · pet tek')
    expect(words([S('celo'), C('lahko'), S('celo')], [1, 3, 5])).toBe('tor fitnes celo telo · čet tek · sob fitnes celo telo')
  })
  it('določeni dnevi štejejo pri razmiku: moč pon in pet + dve kolesi → sre in ned (ne tor)', () => {
    const o = scheduleWeek([S('potisk', 0), S('poteg', 4), C('tempo', 'kolo'), C('lahko', 'kolo')], [0, 1, 2, 3, 4, 5, 6])
    expect(o.map((k, d) => (k != null ? d : -1)).filter(d => d >= 0)).toEqual([0, 2, 4, 6])
    expect(o[2]).toBe(2); expect(o[6]).toBe(3)
  })
  it('samo štirje dnevi zapored na voljo: moč ne dva dni zapored na istih mišicah, kardio vmes', () => {
    expect(words([S('zgornji'), C('lahko'), S('spodnji')], [0, 1, 2, 3])).toBe('pon fitnes zgornji del · sre tek · čet fitnes spodnji del')
  })
})

describe('kdaj imaš čas (1. korak)', () => {
  it('vprašalnik brez AI: brez vprašanja o dnevih, »koliko od teh dni«, možnosti do števila dni', () => {
    const q = ruleQuestions('fitnes in tek', { avail: [0, 2, 4, 6] })
    expect(q.questions.some(x => x.id === 'nedni')).toBe(false)
    expect(q.questions[0]).toMatchObject({ id: 'dni', text: 'Koliko od teh 4 dni bi res treniral?', options: ['2', '3', '4'] })
    expect(ruleQuestions('fitnes in tek').questions.some(x => x.id === 'nedni')).toBe(true)
  })
  it('predlog po pravilih: vadbe samo na dneve s časom; dnevi brez časa so vsi ostali', () => {
    const f = ruleProposal('Fitnes in tek, samo zgornji del.', [{ id: 'dni', q: 'dni', a: '4' }], 29, { avail: [0, 2, 4, 6] }).focus
    expect(f.offDays).toEqual([1, 3, 5])
    expect(trainingDays(f.sessions)).toBeLessThanOrEqual(4)
    expect(f.sessions.filter(s => s.type === 'fitnes').map(s => s.part)).toEqual(['potisk', 'poteg', 'zgornji'])   // 4 dni: 3× moč (samo zgornji del) + tek
    const g = ruleProposal('Fitnes in tek.', [{ id: 'dni', q: 'dni', a: '5' }], 29, { avail: [1, 4] }).focus
    expect(trainingDays(g.sessions)).toBe(2)
    expect(g.offDays).toEqual([0, 2, 3, 5, 6])
  })
  it('AI dobi dneve s časom; vprašanj o dnevih ne postavlja; predlog razmisli kot trener', () => {
    const b = { age: 21, sex: 'm' as const, avail: [0, 2, 4, 6], trainTime: 'zvecer' as const }
    expect(availLine(b)).toBe('Ima čas: pon, sre, pet, ned (4 dnevi na teden), običajno zvečer; drugi dnevi NE gredo (neGre: tor, čet, sob = [1, 3, 5]).')
    expect(availLine({ avail: [] })).toBe('')
    const txt = (parts: unknown[]) => parts.map(x => String((x as { text?: string }).text || '')).join('\n')
    const q = txt(questionsPrompt({ wish: 'fitnes', basics: b, qa: [], round: 1 }))
    expect(q).toMatch(/o dnevih NE sprašuj/)
    expect(q).toContain('Ima čas: pon, sre, pet, ned')
    const p = txt(proposalPrompt({ wish: 'fitnes', basics: b, qa: [] }))
    expect(p).toMatch(/RAZMISLI KOT TRENER/)
    expect(p).toMatch(/"neGre" mora vsebovati vse druge dneve/)
    expect(txt(questionsPrompt({ wish: 'fitnes', basics: { age: 21 }, qa: [], round: 1 }))).toMatch(/kateri dnevi mu ne gredo/)
  })
})
