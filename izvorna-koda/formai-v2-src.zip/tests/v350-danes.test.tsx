// v3.50 DANES (zasloni, lažja shramba): dan tekme brez lažne prilagoditve (A07), »Imam samo …« z doseženimi minutami (A08),
// list pripravljenosti »Kaj vpliva« (A09), ploščice vaj tapljive in z narejenim (A14, A22), »Včeraj« pod treningom (A15),
// Podrobnosti po opravljenem (A28), »Začni moč« (A30), dan počitka z »Dodaj trening« (A46), gorivo moči brez kolesa (A12),
// neoznačen trening izpred dveh dni (H29), kolesar brez tekme (H34), forma »še računam« (H35), trak tedna kolo pred močjo (B22).
import 'fake-indexeddb/auto'
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'danes', params: {} as Record<string, string> }, nav: [] as unknown[][] }))
vi.mock('@/state/store', async () => {
  const { vi: v } = await import('vitest')
  const base: Record<string | symbol, unknown> = {
    useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
    getState: () => S.state,
    routePace: () => ({ k: 1, adj: { n: 0, adj: 1 } }),
    stateToday: () => ({ level: 0, legs: false, reasons: [] }),
    toast: v.fn(),
  }
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' || typeof k === 'symbol' ? undefined : (t[k] = v.fn(async () => undefined))), has: (_t, k) => k !== 'then' })
})
vi.mock('@/app/router', () => ({ navigate: (...a: unknown[]) => { S.nav.push(a) }, useRoute: () => S.route }))
vi.mock('@/app/Shell', () => ({ Head: () => null }))
vi.mock('@/ui/useAi', () => ({ useAi: () => ({ busy: false, signedIn: false, consent: false, run: async (fn: () => Promise<unknown>) => fn(), sheet: null }) }))
vi.mock('@/state/snap', () => ({ snapOf: () => ({}) }))
vi.mock('@/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '@/state/store'
import { Danes } from '@/screens/Danes'
import { SkipSheet } from '@/ui/SkipSheet'
import { ReadinessSheet } from '@/ui/ReadinessSheet'
import { YesterdayRate } from '@/ui/YesterdayRate'
import { GoalCard } from '@/ui/GoalCard'
import { ExGrid } from '@/ui/SessBits'
import { WeekRibbon } from '@/ui/PlanHero'
import type { Activity, PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-18', YDAY = '2026-10-17'   // nedelja
const NOW = `${TODAY}T08:00:00.000Z`
const P = { sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, ftpDate: '2026-09-14', lthr: 184, maxHr: 195, restHr: 48, gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, strength: { on: true, equipment: 'home' }, strengthDays: 2, onboardingDone: true, hoursPerWeek: 8, goal: 'forma', createdAt: '2026-08-01T08:00:00.000Z', updatedAt: NOW } as unknown as Profile
const day = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: date + (o.kind || 'kolo') + (o.title || ''), date, kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, zone: 'Z2', role: 'lahka', tssTarget: 42, source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })
const rest = (date: string) => day(date, { kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, tssTarget: 0, role: null })
const tempo = day(TODAY, { title: 'Tempo 3 × 10 min', desc: '20 min ogrevanje s 3 kratkimi pospeški · 3 × 10 min pri utrip 166–171 (≈ 182–204 W, brez merilnika po občutku), vmes 5 min lahko · 15 min iztek. Prvi malo trši trening sezone: enakomerno, pogovor še mogoč v kratkih stavkih.', durationMin: 75, zone: 'Z3', role: 'kljucna', tssTarget: 59, target: { lo: 182, hi: 204 }, why: 'Most do sweet spota.' })
const noge = day(TODAY, { kind: 'moc', title: 'Moč — noge in jedro', desc: 'Počasi in s kontrolo.', durationMin: 30, zone: null, role: 'moc', tssTarget: 24, exercises: [{ name: 'Bolgarski počep', sets: 3, reps: '8–12', kg: null }, { name: 'Izpadni koraki', sets: 3, reps: '10–12', kg: null }, { name: 'Deska', sets: 3, reps: '45–60 s', kg: null }] })
const race = day(TODAY, { title: 'Kronometer Vodice — 18 km', desc: 'Zajtrk 2–3 h prej. Ogrevanje 25 min; prvih 5 min ne prehitro.', durationMin: 30, zone: 'dirka', role: 'dirka', raceId: 'r1', tssTarget: 45 })
const act1 = (date: string, o: Partial<Activity> = {}): Activity => ({ id: 'a' + date + (o.sport || 'kolo'), source: 'manual', sport: 'kolo', date, durationMin: 60, tss: 40, name: 'Z2', aiEligible: true, geoRetain: false, createdAt: NOW, updatedAt: NOW, ...o } as unknown as Activity)
const reset = (plan: PlanDay[], o: Record<string, unknown> = {}) => {
  S.state = { ready: true, today: TODAY, plan, activities: [], recentMeals: [], mealsToday: [], checkins: [], checkinToday: null, weather: null, wellness: null, routeLib: null, routesBusy: false, icuDiag: null, settings: { lang: 'sl', intervals: null, coach: { msgs: [], summary: null }, startDone: true, guideSeen: true, tests: [] }, toast: null, profile: P, user: null, authKnown: true, firstSync: null, changes: [], sync: { state: 'ok' }, ...o }
  S.subs.forEach(f => f())
}
const fn = (k: string) => (store as unknown as Record<string, ReturnType<typeof vi.fn>>)[k]!
let div: HTMLDivElement | null = null, root: Root | null = null
async function render(el: ReactElement) { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div); await act(async () => { root!.render(el) }); await flush(); return div }
const sp = (x: string | null | undefined) => (x || '').replace(/⁠/g, '').replace(/[  ]/g, ' ')
const text = () => sp(document.body.textContent)
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(sp(b.textContent))) as HTMLButtonElement | undefined
const flush = async () => { for (let i = 0; i < 4; i++) await act(async () => { await Promise.resolve() }) }

beforeEach(() => { sessionStorage.clear(); localStorage.clear(); S.subs.clear(); S.nav = []; window.scrollTo = vi.fn() as never; vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date(2026, 9, 18, 9, 0)) })
afterEach(async () => { if (root) { await act(async () => root!.unmount()); root = null } div?.remove(); document.body.innerHTML = ''; vi.useRealTimers() })

describe('A07: dan tekme — »Danes ne gre« ne obljublja prilagoditve', () => {
  it('brez »Noge bolijo« in »Na tleh sem«; pove, da tekme načrt ne spreminja; saveCheckin se ne kliče', async () => {
    reset([race])
    await render(<SkipSheet day={race} canMove={false} onClose={() => undefined} onMove={() => undefined} onSick={() => undefined} />)
    expect(btn(/Noge bolijo/)).toBeUndefined()
    expect(btn(/Na tleh sem/)).toBeUndefined()
    expect(text()).toMatch(/Tekma je tvoja odločitev — načrt je ne spreminja\./)
    expect(btn(/Bolan sem/)).toBeTruthy()
    expect(fn('saveCheckin')).not.toHaveBeenCalled()
  })
  it('navaden dan kot prej: »Noge bolijo« shrani jutranji vnos', async () => {
    reset([tempo])
    await render(<SkipSheet day={tempo} canMove onClose={() => undefined} onMove={() => undefined} onSick={() => undefined} />)
    await act(async () => { btn(/Noge bolijo/)!.click() })
    expect(fn('saveCheckin')).toHaveBeenCalledWith(expect.objectContaining({ soreness: 5 }))
  })
})

describe('A08: »Imam samo …« z doseženimi minutami', () => {
  it('Tempo 3 × 10: čipa »50 min« in »1 h« (ne 20 · 30 · 45) in vrstica o spodnji meji', async () => {
    reset([tempo])
    await render(<SkipSheet day={tempo} canMove onClose={() => undefined} onMove={() => undefined} onSick={() => undefined} />)
    await act(async () => { btn(/Imam samo/)!.click() })
    expect([...document.querySelectorAll('.skip-mins button')].map(x => sp(x.textContent))).toEqual(['50 min', '1 h'])
    expect(text()).toMatch(/Krajše od 50 min ne gre — ponovitve rabijo svoj čas\./)
    await act(async () => { btn(/^50 min$/)!.click() })
    expect((fn('savePlanDay').mock.calls[0]![0] as PlanDay).durationMin).toBe(50)
  })
})

describe('A09: list pripravljenosti', () => {
  const ready = (score: number) => ({ score, label: score >= 70 ? 'dobra' : 'srednja', color: 'var(--ok)', reasons: ['dolgo brez rednega treninga — kondicija pada'] })
  it('pri 78 »Kaj vpliva«, pri 55 »Zakaj nižja«', async () => {
    await render(<ReadinessSheet open onClose={() => undefined} ready={ready(78)} rec={null} tsb={32} checkin={null} wellnessOn={false} hasIntervals={false} />)
    expect(text()).toMatch(/Kaj vpliva: dolgo brez rednega treninga — kondicija pada\./)
    expect(text()).not.toMatch(/Zakaj nižja/)
    await render(<ReadinessSheet open onClose={() => undefined} ready={ready(55)} rec={null} tsb={-5} checkin={null} wellnessOn={false} hasIntervals={false} />)
    expect(text()).toMatch(/Zakaj nižja/)
  })
})

describe('A14/A22: ploščice vaj', () => {
  it('ploščica je gumb z »kako se izvaja« in odpre vajo v knjižnici; po vadbi pokaže narejeno', async () => {
    await render(<ExGrid exercises={noge.exercises!} done={[{ name: 'Bolgarski počep', sets: 3, reps: '11, 11, 11', kg: 12 }]} />)
    const b = btn(/Bolgarski počep/)!
    expect(b.getAttribute('aria-label')).toBe('Bolgarski počep — kako se izvaja')
    expect(sp(b.textContent)).toMatch(/narejeno 11, 11, 11 · 12 kg · načrt 3 × 8–12/)
    expect(sp(btn(/Izpadni koraki/)!.textContent)).toMatch(/3 × 10–12/)
    await act(async () => { b.click() })
    expect(S.nav[0]).toEqual(['vaje', { v: 'bolgarski' }])
  })
})

describe('H29: neoznačen trening izpred dveh dni', () => {
  it('sreda: »Ponedeljek: Tek in hoja — si ga naredil?« z »Da, opravil«; »Ne« pokliče autoMissed s tem dnem', async () => {
    const wed = '2026-10-21'
    const mon = day('2026-10-19', { kind: 'tek', title: 'Tek in hoja', durationMin: 25 })
    reset([mon, rest('2026-10-20'), day(wed, { kind: 'tek', title: 'Tek', durationMin: 25 })], { today: wed })
    fn('autoMissed').mockClear()
    await render(<YesterdayRate />)
    expect(text()).toMatch(/Ponedeljek: Tek in hoja — si ga naredil\?/)
    expect(btn(/Da, opravil/)).toBeTruthy()
    await act(async () => { btn(/^Ne$/)!.click() })
    expect(fn('autoMissed')).toHaveBeenCalledWith(mon.id)
    expect(text()).toBe('')
  })
  it('včeraj in predvčerajšnjim: dve kartici, včeraj prva', async () => {
    reset([day('2026-10-16', { title: 'Petek Z2' }), day(YDAY, { title: 'Sobota Z2' }), tempo])
    await render(<YesterdayRate />)
    const heads = [...document.querySelectorAll('.yday-rate h2')].map(h => sp(h.textContent))
    expect(heads).toEqual(['Včeraj: Sobota Z2 — si ga naredil?', 'Petek: Petek Z2 — si ga naredil?'])
  })
})

describe('H34: kolesar brez tekme', () => {
  it('»nimam tekme, zdravje«: kartica »Cilj: forma in zdravje« namesto »Tekma z datumom«', async () => {
    const focus = { v: 1, mode: 'kolo', wish: 'Cilj: zdravje in počutje. Nimam tekme, hočem ostati zdrav in v formi.', aims: ['tekma', 'zdravje'], sports: ['kolo'], muscles: [], level: 3, equipment: ['nic'], limits: null, sessions: [], offDays: null, notes: [], title: 'Kolo', by: 'pravila', at: NOW }
    reset([tempo], { profile: { ...P, goal: null, focus } })
    await render(<GoalCard compact />)
    expect(text()).toMatch(/Cilj: forma in zdravje/)
    expect(text()).toMatch(/Cilj z datumom lahko dodaš kadar koli/)
    expect(text()).not.toMatch(/Tekma z datumom/)
    await act(async () => { reset([tempo], { profile: { ...P, goal: null, focus: { ...focus, wish: 'Maraton Franja 2027.', aims: ['tekma'] } } }) })
    expect(text()).toMatch(/Tekma z datumom/)
  })
})

describe('B22: trak tedna — kolo pred močjo', () => {
  it('dan z močjo in kolesom (moč prva v shrambi): ikona in barva kolesa, oznaka »Z2 … + Moč«', async () => {
    const tue = '2026-10-13'
    const m = day(tue, { kind: 'moc', title: 'Moč — jedro', durationMin: 20, zone: null, role: 'moc' })
    const k = day(tue, { title: 'Z2 + 8 × 15 s šprint', durationMin: 65 })
    const days = Array.from({ length: 7 }, (_, i) => `2026-10-${12 + i}`)
    await render(<WeekRibbon days={days} items={[m, k]} today={TODAY} focus={TODAY} />)
    const el = document.querySelector(`.pl-day[aria-label^="tor"]`)!
    expect(el.getAttribute('aria-label')).toBe('tor 13.: Z2 + 8 × 15 s šprint + Moč — jedro, ni označeno')
    expect((el as HTMLElement).style.getPropertyValue('--c')).toBe('var(--t-kolo)')
  })
})

describe('Danes — zaslon', () => {
  it('A15: »Včeraj … si ga naredil?« je pred »Prvi koraki«; A30: kartica moči ima »Začni moč«', async () => {
    reset([day(YDAY, { title: 'Sobota Z2' }), tempo, noge], { settings: { lang: 'sl', intervals: null, coach: { msgs: [], summary: null }, startDone: false, guideSeen: true, tests: [] } })
    await render(<Danes />)
    const all = [...document.querySelectorAll('.yday-rate, .card')]
    const y = all.findIndex(e => e.classList.contains('yday-rate'))
    const fs = all.findIndex(e => /Prvi koraki/.test(sp(e.textContent)) && !e.classList.contains('yday-rate'))
    expect(y).toBeGreaterThanOrEqual(0)
    expect(fs).toBeGreaterThan(y)
    expect(btn(/^Začni moč$/)).toBeTruthy()
    expect(btn(/^Začni$/)).toBeUndefined()
  })
  it('A28: po opravljenem ostanejo »Podrobnosti« (brez oblačil); A22: narejene ponovitve na kartici moči', async () => {
    const act = act1(TODAY, { sport: 'moc', name: 'Moč — noge in jedro', exercises: [{ name: 'Bolgarski počep', sets: 3, reps: '11, 11, 11', kg: null }] })
    reset([{ ...tempo, done: { at: NOW } }, { ...noge, done: { at: NOW, activityId: act.id } }], { activities: [act], weather: { [TODAY]: { tMax: 14, tMin: 8, rain: 0, wind: 10, code: 1 } } })
    await render(<Danes />)
    const det = document.querySelector('details.more')!
    expect(det).toBeTruthy()
    expect(sp(det.textContent)).toMatch(/Zakaj: Most do sweet spota\./)
    expect(sp(det.textContent)).not.toMatch(/Obleci/)
    expect(text()).toMatch(/Bolgarski počep 11, 11, 11/)
  })
  it('A46: dan počitka ima »Dodaj trening« (Plan, ta dan) in »Jedro po želji«; H35: forma »še računam« pod 3 vadbami', async () => {
    reset([rest(TODAY), day('2026-10-20', { title: 'Z2 torek' })], { activities: [act1('2026-10-10'), act1('2026-10-14')] })
    await render(<Danes />)
    await act(async () => { btn(/^Dodaj trening$/)!.click() })
    expect(S.nav[0]).toEqual(['plan', { dan: TODAY }])
    await act(async () => { btn(/Jedro po želji/)!.click() })
    expect(fn('addCore')).toHaveBeenCalledWith(TODAY)
    expect(text()).toMatch(/še računam/)
    expect(text()).not.toMatch(/premalo zgodovine/)
  })
  it('A12: dan samo z močjo — »Pred« brez »po kolesu«', async () => {
    // (po združitvi z NUTRI-DOMENA) seje pod 45 min nimajo kartice goriva (H31), zato 50 min
    reset([{ ...noge, durationMin: 50 }])
    await render(<Danes />)
    const fold = btn(/Gorivo za ta trening/)
    if (fold) await act(async () => { fold.click() })
    expect(text()).not.toMatch(/po kolesu/)
    expect(text()).toMatch(/Lahek obrok 1–2 h prej|pred vadbo/)   // (po združitvi) razpored obrokov tudi za moč (D17)
  })
  it('A42: zložena vrstica trase brez povezave ne obljublja GPX in ure', async () => {
    reset([tempo])
    await render(<Danes />)
    expect(text()).toMatch(/poveži intervals\.icu za predloge/)
    expect(text()).not.toMatch(/GPX · na uro/)
  })
})
