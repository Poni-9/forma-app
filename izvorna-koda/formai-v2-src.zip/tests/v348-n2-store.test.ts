// v3.48 N2 — testi FTP: star test ne prepiše novejšega FTP; izbris zadnjega testa vrne FTP na prejšnji najnovejši
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { setKV } from '../src/data/db'

const ftpTest = (id: string, date: string, value: number) => ({ id, date, kind: 'ftp' as const, value, unit: 'W' })

describe('C03 — FTP iz testov', () => {
  beforeEach(async () => { await repo.wipeAll(); localStorage.clear(); await setKV('plan.changes', []); await store.reloadAll() })

  it('star test (2. 5.) ne prepiše FTP iz novejšega testa (14. 9.)', async () => {
    await store.addTest(ftpTest('a', '2026-08-03', 244))
    await store.addTest(ftpTest('b', '2026-09-14', 253))
    expect(store.getState().profile).toMatchObject({ ftp: 240, ftpDate: '2026-09-14' })
    await store.addTest(ftpTest('c', '2026-05-02', 190))
    expect(store.getState().profile).toMatchObject({ ftp: 240, ftpDate: '2026-09-14' })
    expect(store.getState().settings.tests!.map(t => t.id)).toEqual(['c', 'a', 'b'])
  })

  it('test, starejši od ročno vpisanega FTP, FTP ne spremeni', async () => {
    await store.updateProfile({ ftp: 250, ftpDate: '2026-10-10' })
    await store.addTest(ftpTest('a', '2026-10-01', 230))
    expect(store.getState().profile).toMatchObject({ ftp: 250, ftpDate: '2026-10-10' })
  })

  it('izbris zadnjega testa: FTP spet po prejšnjem najnovejšem testu; izbris starega testa FTP ne spremeni', async () => {
    await store.addTest(ftpTest('a', '2026-08-03', 244))
    await store.addTest(ftpTest('b', '2026-09-14', 253))
    await store.addTest(ftpTest('c', '2026-05-02', 190))
    await store.removeTest('c')
    expect(store.getState().profile).toMatchObject({ ftp: 240, ftpDate: '2026-09-14' })
    await store.removeTest('b')
    expect(store.getState().profile).toMatchObject({ ftp: 232, ftpDate: '2026-08-03' })
  })

  it('ročno vpisan FTP po testu ostane, ko test izbrišeš', async () => {
    await store.addTest(ftpTest('a', '2026-08-03', 244))
    await store.addTest(ftpTest('b', '2026-09-14', 253))
    await store.updateProfile({ ftp: 260, ftpDate: '2026-10-12' })
    await store.removeTest('b')
    expect(store.getState().profile).toMatchObject({ ftp: 260, ftpDate: '2026-10-12' })
  })

  it('po pregledu: izbris uvodnega testa vrne tudi izhodišče cilja (goalStart.ftp)', async () => {
    await store.addTest(ftpTest('a', '2026-08-03', 244))
    await store.updateProfile({ goalStart: { date: '2026-09-10', weightKg: 80, ftp: 232 } } as never)
    await store.addTest(ftpTest('b', '2026-09-14', 253))   // 4 dni po potrditvi cilja → uvodni (calib)
    expect(store.getState().profile.goalStart).toMatchObject({ ftp: 240 })
    await store.removeTest('b')
    expect(store.getState().profile).toMatchObject({ ftp: 232, ftpDate: '2026-08-03' })
    expect(store.getState().profile.goalStart).toMatchObject({ ftp: 232 })
  })

  it('latestFtpTest: najnovejši po datumu, drugi testi ne štejejo', () => {
    expect(store.latestFtpTest([ftpTest('a', '2026-09-14', 250), ftpTest('b', '2026-05-02', 190), { id: 'p', date: '2026-10-01', kind: 'p5', value: 330, unit: 'W' }])?.id).toBe('a')
    expect(store.latestFtpTest([])).toBeNull()
  })
})
