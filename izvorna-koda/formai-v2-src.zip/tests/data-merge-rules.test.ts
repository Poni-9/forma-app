import 'fake-indexeddb/auto'
import { describe, it, expect } from 'vitest'
import { mergePlan, mergeCheckins, mergeCoach, mergeSettings, mergeProfile, mergeState, stableStr, COACH_MAX_MSGS, type SyncState } from '../src/data/merge'
import { stampFields, defaultSettings } from '../src/data/repo'
import type { PlanDay, Profile, Settings, CoachMsg } from '../src/domain/types'

const T = (h: number, m = 0) => new Date(Date.UTC(2026, 8, 25, h, m)).toISOString()
const day = (id: string, o: Partial<PlanDay> = {}): PlanDay => ({ id, date: '2026-09-25', kind: 'kolo', title: 'VO2max', desc: '', durationMin: 75, source: 'rules', createdAt: T(0), updatedAt: T(0), ...o })
const sym = <T,>(f: (a: T, b: T) => unknown, a: T, b: T) => { expect(stableStr(f(a, b))).toBe(stableStr(f(b, a))) }

describe('načrt: po vnosu, »opravljeno« s svojim časom', () => {
  it('kljukica na telefonu ostane, ko računalnik (neusklajen) doda jedro na isti dan', () => {
    const phone = [day('r1', { done: { at: T(18), activityId: 'a1' }, doneAt: T(18), updatedAt: T(18) })]
    const laptop = [day('r1'), day('c1', { kind: 'moc', title: 'Jedro po želji', optional: true, createdAt: T(18, 1), updatedAt: T(18, 1) })]
    const m = mergePlan(phone, laptop)
    expect(m.map(d => [d.id, d.done?.activityId ?? null])).toEqual([['c1', null], ['r1', 'a1']])
    sym(mergePlan, phone, laptop)
    expect(stableStr(mergePlan(m, m))).toBe(stableStr(m))
    expect(stableStr(mergePlan(phone, m))).toBe(stableStr(m))
    expect(stableStr(mergePlan(laptop, m))).toBe(stableStr(m))
  })
  it('odkljukanje (novejši doneAt) velja; starejša kljukica ne vstane zaradi nepovezane spremembe', () => {
    const a = [day('r1', { done: { at: T(10), activityId: null }, doneAt: T(10), updatedAt: T(10) })]
    const b = [day('r1', { done: null, doneAt: T(11), title: 'VO2max', updatedAt: T(11) })]
    expect(mergePlan(a, b)[0]!.done ?? null).toBeNull()
    // druga naprava je pozneje spremenila opis (ne kljukice) → kljukica ostane po svojem času
    const c = [day('r1', { desc: 'nov opis', updatedAt: T(12) })]
    const m = mergePlan(a, c)[0]!
    expect(m.desc).toBe('nov opis'); expect(m.done?.at).toBe(T(10))
    sym(mergePlan, a, c)
  })
  it('druga naprava je dan sestavila znova (novi id-ji), ne vedoč za kljukico → opravljen trening ostane, neopravljen iste reže odpade', () => {
    const phone = [day('x1', { done: { at: T(17), activityId: 'a9' }, doneAt: T(17), updatedAt: T(17) }), day('x2', { kind: 'moc', title: 'Moč', updatedAt: T(1) })]
    const laptop = [day('y1', { title: 'Z2', updatedAt: T(18) }), day('y2', { kind: 'moc', title: 'Moč B', updatedAt: T(18) })]
    const m = mergePlan(phone, laptop)
    expect(m.map(d => d.id).sort()).toEqual(['x1', 'y2'])
    sym(mergePlan, phone, laptop)
    expect(stableStr(mergePlan(laptop, m))).toBe(stableStr(m))
    expect(stableStr(mergePlan(phone, m))).toBe(stableStr(m))
  })
})

describe('check-in: dopolni samo manjkajoča polja', () => {
  it('opomba, izbrisana (null) na novejši napravi, se ne vrne; manjkajoče polje se dopolni', () => {
    const newer = { date: '2026-09-25', weightKg: 72, note: null, updatedAt: T(9) }
    const older = { date: '2026-09-25', weightKg: 72, note: 'bolan', sleepH: 7, updatedAt: T(7) }
    const m = mergeCheckins([newer], [older])[0]!
    expect(m.note).toBeNull()
    expect(m.sleepH).toBe(7)
    sym(mergeCheckins, [newer], [older])
  })
})

describe('pogovor s trenerjem: unija sporočil', () => {
  const msg = (text: string, at: string, role: CoachMsg['role'] = 'user'): CoachMsg => ({ role, text, at })
  it('prazen seznam ne pobriše; sporočila z obeh naprav; »nov pogovor« (clearedAt) velja povsod', () => {
    const a = { msgs: [msg('a', T(1)), msg('b', T(2), 'ai')], summary: null }
    expect(mergeCoach(a, { msgs: [], summary: null })!.msgs.map(m => m.text)).toEqual(['a', 'b'])
    const b = { msgs: [msg('a', T(1)), msg('c', T(3))], summary: null }
    expect(mergeCoach(a, b)!.msgs.map(m => m.text)).toEqual(['a', 'b', 'c'])
    sym(mergeCoach, a, b)
    const cleared = { msgs: [msg('nov', T(5))], summary: null, clearedAt: T(4) }
    expect(mergeCoach(a, cleared)!.msgs.map(m => m.text)).toEqual(['nov'])
    expect(mergeCoach(cleared, a)!.clearedAt).toBe(T(4))
  })
  it('strnjeno (foldedTo) se ne vrne z druge naprave; zgodovina je omejena', () => {
    const folded = { msgs: [msg('x', T(6))], summary: 'zapiski', summaryAt: T(6), foldedTo: T(5) }
    const old = { msgs: [msg('star', T(2)), msg('x', T(6))], summary: null }
    const m = mergeCoach(folded, old)!
    expect(m.msgs.map(x => x.text)).toEqual(['x']); expect(m.summary).toBe('zapiski')
    const many = { msgs: Array.from({ length: 150 }, (_, i) => msg('m' + i, new Date(Date.UTC(2026, 8, 1) + i * 60000).toISOString())), summary: null }
    expect(mergeCoach(many, null)!.msgs.length).toBe(COACH_MAX_MSGS)
  })
})

describe('nastavitve in profil: vsako polje s svojim časom', () => {
  it('novejša nepovezana sprememba ne pobriše žetona; odklop (novejši) velja; wellnessOn ne gre čez', () => {
    const phone: Settings = { lang: 'sl', accentHex: '#A3E635', intervals: { athleteId: '0', apiKey: '', token: 'T' }, wellnessOn: true, updatedAt: T(10), fieldAt: { intervals: T(10), wellnessOn: T(10) } }
    const laptop: Settings = { lang: 'sl', accentHex: '#84CC16', intervals: null, updatedAt: T(11), fieldAt: { accentHex: T(11) } }
    const m = mergeSettings(phone, laptop, {})!
    expect(m.intervals?.token).toBe('T'); expect(m.accentHex).toBe('#84CC16'); expect(m.wellnessOn).toBeUndefined()
    sym((x: Settings, y: Settings) => mergeSettings(x, y, {}), phone, laptop)
    const off: Settings = { ...laptop, intervals: null, fieldAt: { ...laptop.fieldAt, intervals: T(12) } }
    expect(mergeSettings(phone, off, {})!.intervals ?? null).toBeNull()
  })
  it('stari zapisi (brez fieldAt): prazno polje ne zmaga nad vrednostjo', () => {
    const a: Settings = { lang: 'sl', intervals: { athleteId: '0', apiKey: 'k' }, updatedAt: T(1) }
    const b: Settings = { lang: 'sl', intervals: null, accentHex: '#84CC16', updatedAt: T(2) }
    expect(mergeSettings(a, b, {})!.intervals?.apiKey).toBe('k')
  })
  it('preklic privolitve za AI (novejši) se ne vrne zaradi novejše spremembe teže na drugi napravi', () => {
    const base = { sex: 'm', gear: { bikeOutdoor: true, trainer: false, noBike: false }, strength: { on: false, equipment: 'none' }, onboardingDone: true, name: 'B', createdAt: T(0) } as Profile
    const phone: Profile = { ...base, aiConsentAt: null, weightKg: 72, updatedAt: T(10), fieldAt: { aiConsentAt: T(10), weightKg: T(1) } }
    const laptop: Profile = { ...base, aiConsentAt: T(0), weightKg: 71, updatedAt: T(11), fieldAt: { aiConsentAt: T(0), weightKg: T(11) } }
    const m = mergeProfile(phone, laptop)!
    expect(m.aiConsentAt ?? null).toBeNull(); expect(m.weightKg).toBe(71)
    sym(mergeProfile, phone, laptop)
  })
  it('privzete vrednosti ob shranjevanju ne dobijo časa (nova naprava z intervals: null ne prepiše žetona)', () => {
    const now = T(20)
    const at = stampFields<Settings>(undefined, { ...defaultSettings(), guideSeen: false }, defaultSettings(), now)
    expect(at).toEqual({ guideSeen: now })
    const legacy: Settings = { lang: 'sl', accentHex: '#A3E635', intervals: { athleteId: '0', apiKey: 'k' }, updatedAt: T(3) }
    expect(stampFields<Settings>(legacy, { ...legacy, accentHex: '#84CC16' }, defaultSettings(), now)).toEqual({ accentHex: now, intervals: T(3) })
  })
  it('prvo usklajevanje (oblak je avtoriteta): profil računa ostane, novejša lokalna povezava intervals.icu tudi', () => {
    const acct = { sex: 'm', gear: { bikeOutdoor: true, trainer: false, noBike: false }, strength: { on: false, equipment: 'none' }, onboardingDone: true, name: 'Blaž', ftp: 280, createdAt: T(0), updatedAt: T(1) } as Profile
    const local = { ...acct, name: undefined, ftp: null, weightKg: 80, aiConsentAt: T(9), updatedAt: T(9), fieldAt: { ftp: T(9), weightKg: T(9), aiConsentAt: T(9) } } as Profile
    const st = (profile: Profile, settings: Settings): SyncState => ({ profile, settings, activities: [], plan: [], meals: [], checkins: [], tomb: {} })
    const m = mergeState(st(local, { lang: 'sl', accentHex: '#4ADE80', intervals: { athleteId: '0', apiKey: '', token: 'NEW' }, fieldAt: { intervals: T(9), accentHex: T(9) } }), st(acct, { lang: 'sl', accentHex: '#84CC16', updatedAt: T(1) }), Date.parse(T(21)), { authority: 'b' })
    expect(m.profile!.ftp).toBe(280); expect(m.profile!.name).toBe('Blaž'); expect(m.profile!.weightKg).toBeUndefined()
    expect(m.profile!.aiConsentAt).toBe(T(9))
    expect(m.settings!.accentHex).toBe('#84CC16'); expect(m.settings!.intervals?.token).toBe('NEW')
  })
})
