import 'fake-indexeddb/auto'
import { describe, it, expect, vi, afterEach } from 'vitest'
import { IDBFactory } from 'fake-indexeddb'

/**
 * Regresija (pregled 25. 9.): dve napravi, vsaka s svojo bazo, en dokument v »oblaku«. Preverja:
 * izbris računa na eni napravi (druga ga NE ustvari znova), prazen pogovor na novi napravi ne pobriše pogovora,
 * lokalni uvod na novi napravi ne prepiše profila računa, nepovezana novejša nastavitev ne pobriše žetona
 * intervals.icu, preklic privolitve za AI se ne vrne, drug račun na isti napravi se ne združi, wellnessOn ostane na napravi.
 */
type Doc = Record<string, unknown>
const cloud: Record<string, Doc> = {}
let writes = 0
const live = { on: false, subs: new Map<string, Set<(s: unknown) => void>>() }
const snapOf = (path: string) => ({ metadata: { fromCache: false, hasPendingWrites: false }, exists: () => !!cloud[path], get: (fp: string) => fp.split('.').reduce<unknown>((o, k) => (o as Record<string, unknown> | undefined)?.[k], cloud[path]) })
const notify = (path: string) => setTimeout(() => { for (const f of live.subs.get(path) || []) f(snapOf(path)) }, 0)
let coreDown = false
const fakeCore = {
  fs: {},
  fsMod: {
    doc: (_fs: unknown, col: string, id: string) => ({ path: `${col}/${id}` }),
    get onSnapshot() {
      if (!live.on) return undefined
      return (ref: { path: string }, _o: unknown, next: (s: unknown) => void) => {
        const set = live.subs.get(ref.path) || new Set(); set.add(next); live.subs.set(ref.path, set)
        setTimeout(() => next(snapOf(ref.path)), 0)
        return () => { set.delete(next) }
      }
    },
    runTransaction: async (_fs: unknown, fn: (tx: unknown) => Promise<void>) => {
      let pending: { path: string; data: Doc; opts: { mergeFields?: string[] } } | null = null
      const tx = {
        get: async (ref: { path: string }) => ({ exists: () => !!cloud[ref.path], data: () => JSON.parse(JSON.stringify(cloud[ref.path])) }),
        set: (ref: { path: string }, data: Doc, opts: { mergeFields?: string[] }) => { pending = { path: ref.path, data, opts } },
      }
      await fn(tx)
      const p = pending as unknown as { path: string; data: Doc; opts: { mergeFields?: string[] } } | null
      if (p) {
        writes++
        const next: Doc = { ...(cloud[p.path] || {}) }
        for (const f of p.opts?.mergeFields || Object.keys(p.data)) next[f] = JSON.parse(JSON.stringify(p.data[f]))
        cloud[p.path] = next
        notify(p.path)
      }
    },
  },
}
async function device() {
  vi.resetModules()
  ;(globalThis as Record<string, unknown>).indexedDB = new IDBFactory()
  vi.doMock('../src/data/firebase', () => ({ core: async () => (coreDown ? null : fakeCore) }))
  const sync = await import('../src/data/sync')
  const repo = await import('../src/data/repo')
  const db = await import('../src/data/db')
  await db.db()
  return { sync, repo, db }
}
const tick = (ms = 30) => new Promise(r => setTimeout(r, ms))
afterEach(() => { for (const k of Object.keys(cloud)) delete cloud[k]; live.on = false; live.subs.clear(); coreDown = false })
const meal = (id: string) => ({ id, date: '2026-09-24', slot: 'kosilo' as const, name: 'Obrok ' + id, kcal: 500, source: 'manual' as const, thumb: null, createdAt: new Date().toISOString() })

describe('izbris računa na drugi napravi', () => {
  it('poslušalec na računalniku dokumenta NE ustvari znova; sinhronizacija se ustavi in javi izbris', async () => {
    live.on = true
    const phone = await device(); phone.sync.startSync('u1')
    await phone.repo.putMeal(meal('m1')); await phone.sync.touch(); await phone.sync.syncNow(); await tick(60)
    const laptop = await device()
    const onDeleted = vi.fn()
    laptop.sync.startSync('u1', undefined, undefined, { onDeleted }); await laptop.sync.syncNow(); await tick(60)
    expect(cloud['formaSync/u1']).toBeTruthy()
    // telefon: izbris računa → dokument izbrisan (strežnik /account/delete)
    phone.sync.stopSync()
    delete cloud['formaSync/u1']; notify('formaSync/u1')
    await tick(200)
    expect(cloud['formaSync/u1']).toBeUndefined()
    expect(onDeleted).toHaveBeenCalledTimes(1)
    expect(laptop.sync.syncStatus().state).toBe('error')
    expect(laptop.sync.syncStatus().msg).toMatch(/izbrisani/)
    // tudi ročno »uskladi zdaj« ga ne ustvari (sinhronizacija je ustavljena)
    expect(await laptop.sync.syncNow()).toBe(false)
    expect(cloud['formaSync/u1']).toBeUndefined()
    // ponovna prijava z istim računom po forgetRemote: dokument se ustvari iz te naprave
    await laptop.sync.forgetRemote()
    laptop.sync.startSync('u1'); await laptop.sync.syncNow()
    expect((cloud['formaSync/u1'] as { v2: { meals: { id: string }[] } }).v2.meals.map(m => m.id)).toEqual(['m1'])
    laptop.sync.stopSync()
  })
})

describe('pogovor s trenerjem in nastavitve po poljih', () => {
  it('nova naprava s praznim pogovorom (selitev) ne pobriše pogovora; žeton intervals.icu ostane', async () => {
    const phone = await device(); phone.sync.startSync('u1'); await phone.sync.syncNow()
    const s0 = await phone.repo.loadSettings()
    await phone.repo.saveSettings({ ...s0, coach: { msgs: [{ role: 'user', text: 'vprašanje', at: '2026-09-20T10:00:00.000Z' }, { role: 'ai', text: 'odgovor', at: '2026-09-20T10:00:05.000Z' }], summary: 'zapiski' }, intervals: { athleteId: '0', apiKey: '', token: 'TOKEN' } })
    await phone.sync.touch(); await phone.sync.syncNow()
    await tick(20)
    const laptop = await device()
    const l0 = await laptop.repo.loadSettings()
    await laptop.repo.saveSettings({ ...l0, coach: { msgs: [], summary: null } })
    await laptop.sync.touch(); laptop.sync.startSync('u1'); await laptop.sync.syncNow()
    await phone.sync.syncNow()
    for (const dev of [phone, laptop]) {
      const s = await dev.repo.loadSettings()
      expect(s.coach?.msgs?.map(m => m.text)).toEqual(['vprašanje', 'odgovor'])
      expect(s.coach?.summary).toBe('zapiski')
      expect(s.intervals?.token).toBe('TOKEN')
    }
    phone.sync.stopSync(); laptop.sync.stopSync()
  })

  it('novejša nepovezana sprememba (barva) na drugi napravi ne pobriše žetona; preklic privolitve za AI se ne vrne', async () => {
    const phone = await device(); phone.sync.startSync('u1')
    const laptop = await device(); laptop.sync.startSync('u1')
    await phone.sync.syncNow(); await laptop.sync.syncNow()
    await phone.repo.saveProfile({ ...(await phone.repo.loadProfile()), onboardingDone: true, name: 'B', aiConsentAt: '2026-09-01T10:00:00.000Z' }); await phone.sync.touch(); await phone.sync.syncNow(); await laptop.sync.syncNow()
    // telefon (brez povezave) poveže intervals.icu in prekliče privolitev za AI
    const ps = await phone.repo.loadSettings()
    await phone.repo.saveSettings({ ...ps, intervals: { athleteId: '0', apiKey: '', token: 'TOKEN' } }); await phone.sync.touch()
    await phone.repo.saveProfile({ ...(await phone.repo.loadProfile()), aiConsentAt: null }); await phone.sync.touch()
    await tick(15)
    // računalnik malo kasneje spremeni nekaj drugega (barva, teža)
    const ls = await laptop.repo.loadSettings()
    await laptop.repo.saveSettings({ ...ls, accentHex: '#84CC16' }); await laptop.sync.touch()
    await laptop.repo.saveProfile({ ...(await laptop.repo.loadProfile()), weightKg: 71 }); await laptop.sync.touch()
    await phone.sync.syncNow(); await laptop.sync.syncNow(); await phone.sync.syncNow()
    for (const dev of [phone, laptop]) {
      const s = await dev.repo.loadSettings(), p = await dev.repo.loadProfile()
      expect(s.intervals?.token).toBe('TOKEN')
      expect(s.accentHex).toBe('#84CC16')
      expect(p.aiConsentAt ?? null).toBeNull()
      expect(p.weightKg).toBe(71)
    }
    phone.sync.stopSync(); laptop.sync.stopSync()
  })

  it('wellnessOn ostane samo na napravi: ne gre v oblak, star dokument z wellnessOn ga ne vklopi', async () => {
    const phone = await device(); phone.sync.startSync('u1'); await phone.sync.syncNow()
    const s = await phone.repo.loadSettings()
    await phone.repo.saveSettings({ ...s, wellnessOn: true }); await phone.sync.touch(); await phone.sync.syncNow()
    expect(JSON.stringify(cloud['formaSync/u1'])).not.toMatch(/wellnessOn/)
    expect((await phone.repo.loadSettings()).wellnessOn).toBe(true)
    // star dokument (prejšnja različica je wellnessOn sinhronizirala)
    ;((cloud['formaSync/u1'] as { v2: { settings: Record<string, unknown>; _ts: number } }).v2.settings).wellnessOn = true
    ;(cloud['formaSync/u1'] as { v2: { _ts: number } }).v2._ts += 5
    const laptop = await device(); laptop.sync.startSync('u1'); await laptop.sync.syncNow()
    expect((await laptop.repo.loadSettings()).wellnessOn).toBeUndefined()
    phone.sync.stopSync(); laptop.sync.stopSync()
  })
})

describe('prvo usklajevanje nove naprave', () => {
  it('lokalni uvod na novi napravi ne prepiše profila računa (FTP, teža, ime, cilj, tekme)', async () => {
    const phone = await device(); phone.sync.startSync('u1')
    await phone.repo.saveProfile({ ...phone.repo.defaultProfile(), name: 'Blaž', onboardingDone: true, ftp: 280, weightKg: 72, event: { name: 'Franja', date: '2027-06-13' }, races: [{ id: 'r1', name: 'Dirka B', date: '2027-04-01', prio: 'B' }] })
    await phone.sync.touch(); await phone.sync.syncNow()
    await tick(20)
    const laptop = await device()
    await laptop.repo.saveProfile({ ...laptop.repo.defaultProfile(), onboardingDone: true, ftp: null, weightKg: 80, goal: 'hitrejsi' })
    const first = vi.fn()
    await laptop.sync.touch(); laptop.sync.startSync('u1', undefined, first); await laptop.sync.syncNow(); await phone.sync.syncNow()
    expect(first).toHaveBeenCalledWith('ok')
    for (const dev of [phone, laptop]) {
      const p = await dev.repo.loadProfile()
      expect({ name: p.name, ftp: p.ftp, weightKg: p.weightKg, goal: p.goal, event: p.event?.name, races: p.races?.length }).toEqual({ name: 'Blaž', ftp: 280, weightKg: 72, goal: 'dirka', event: 'Franja', races: 1 })
    }
    // po prvem usklajevanju pa sprememba na računalniku velja
    await laptop.repo.saveProfile({ ...(await laptop.repo.loadProfile()), weightKg: 71.5 }); await laptop.sync.touch(); await laptop.sync.syncNow(); await phone.sync.syncNow()
    expect((await phone.repo.loadProfile()).weightKg).toBe(71.5)
    phone.sync.stopSync(); laptop.sync.stopSync()
  })

  it('izid prvega usklajevanja: prazen račun »empty«, napaka »error« (ni prazen račun), nato ob uspehu »ok«', async () => {
    const a = await device()
    const r1 = vi.fn()
    a.sync.startSync('u9', undefined, r1); await a.sync.syncNow()
    expect(r1).toHaveBeenCalledWith('empty')
    a.sync.stopSync()
    const b = await device()
    coreDown = true
    const r2 = vi.fn()
    b.sync.startSync('u9', undefined, r2); await b.sync.syncNow()
    expect(r2).toHaveBeenLastCalledWith('error')
    expect(b.sync.syncStatus().msg).toMatch(/Ni povezave/)
    coreDown = false
    await b.sync.syncNow()
    expect(r2).toHaveBeenLastCalledWith('ok')
    b.sync.stopSync()
  })
})

describe('drug račun na isti napravi', () => {
  it('podatki računa u1 se NE združijo v račun u2 (sinhronizacija se ustavi, clash)', async () => {
    const dev = await device()
    dev.sync.startSync('u1')
    await dev.repo.putMeal(meal('u1-private-meal')); await dev.repo.saveProfile({ ...dev.repo.defaultProfile(), name: 'Uporabnik Ena', onboardingDone: true, weightKg: 91 })
    await dev.sync.touch(); await dev.sync.syncNow()
    expect(await dev.sync.syncOwner()).toEqual({ uid: 'u1', email: null })
    dev.sync.stopSync()
    cloud['formaSync/u2'] = { v2: { _v: 2, _ts: 5, profile: { ...dev.repo.defaultProfile(), name: 'Uporabnik Dva', onboardingDone: true, updatedAt: '2020-01-01T00:00:00.000Z' }, settings: { lang: 'sl' }, activities: [], plan: [], meals: [], checkins: [], tomb: {} } }
    const onClash = vi.fn(), first = vi.fn()
    dev.sync.startSync('u2', undefined, first, { onClash }); await dev.sync.syncNow()
    const v2 = (cloud['formaSync/u2'] as { v2: { meals: { id: string }[]; profile: { name: string } } }).v2
    expect(v2.meals).toEqual([])
    expect(v2.profile.name).toBe('Uporabnik Dva')
    expect(onClash).toHaveBeenCalledTimes(1)
    expect(first).toHaveBeenCalledWith('error')
    expect(dev.sync.syncStatus().msg).toMatch(/drugega računa/)
    // po »Počisti in nadaljuj« (wipeAll) se naprava uskladi z u2
    await dev.repo.wipeAll()
    dev.sync.startSync('u2'); await dev.sync.syncNow()
    expect((await dev.repo.loadProfile()).name).toBe('Uporabnik Dva')
    expect(await dev.repo.allMeals()).toEqual([])
    dev.sync.stopSync()
  })
})
