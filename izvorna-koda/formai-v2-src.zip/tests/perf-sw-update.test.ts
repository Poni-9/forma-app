import { describe, it, expect } from 'vitest'
import { routeOf, isTyping, safeToApply, type Moment } from '@/app/sw'

// Nova različica aplikacije se uveljavi (ponovno nalaganje) samo ob varnem trenutku — nikoli med vadbo ali tipkanjem.
const idle = (p: Partial<Moment> = {}): Moment => ({ why: 'hidden', route: 'danes', active: null, sheet: false, dirty: false, sinceInput: 60_000, ...p })
const el = (html: string): Element => { const d = document.createElement('div'); d.innerHTML = html; return d.firstElementChild! }

describe('posodobitev service workerja', () => {
  it('ime zaslona iz naslova', () => {
    expect(routeOf('')).toBe('danes')
    expect(routeOf('#/')).toBe('danes')
    expect(routeOf('#/vadba?id=x')).toBe('vadba')
    expect(routeOf('#/plan')).toBe('plan')
  })

  it('polja za tipkanje (in izbirnik datoteke) štejejo kot delo v teku, gumbi ne', () => {
    expect(isTyping(el('<input>'))).toBe(true)
    expect(isTyping(el('<input type="number">'))).toBe(true)
    expect(isTyping(el('<input type="file">'))).toBe(true)
    expect(isTyping(el('<textarea></textarea>'))).toBe(true)
    expect(isTyping(el('<select></select>'))).toBe(true)
    expect(isTyping(el('<input type="checkbox">'))).toBe(false)
    expect(isTyping(el('<button>Plan</button>'))).toBe(false)
    expect(isTyping(null)).toBe(false)
  })

  it('skrita stran v miru → da', () => {
    expect(safeToApply(idle())).toBe(true)
  })

  it('nikoli med vadbo — ne skrita ne ob prehodu z nje ali nanjo', () => {
    expect(safeToApply(idle({ route: 'vadba' }))).toBe(false)
    expect(safeToApply(idle({ why: 'nav', from: 'vadba', route: 'danes' }))).toBe(false)
    expect(safeToApply(idle({ why: 'nav', from: 'danes', route: 'vadba' }))).toBe(false)
  })

  it('ne med uvodom ali prijavo (stanje je samo v pomnilniku, okno za prijavo skrije stran)', () => {
    expect(safeToApply(idle({ route: 'uvod' }))).toBe(false)
    expect(safeToApply(idle({ route: 'prijava' }))).toBe(false)
    expect(safeToApply(idle({ why: 'nav', from: 'uvod', route: 'danes' }))).toBe(false)
  })

  it('ne med tipkanjem, pri odprtem listu ali nedokončanem vnosu', () => {
    expect(safeToApply(idle({ active: el('<textarea></textarea>') }))).toBe(false)
    expect(safeToApply(idle({ why: 'nav', from: 'trener', route: 'plan', active: el('<input>') }))).toBe(false)
    expect(safeToApply(idle({ sheet: true }))).toBe(false)
    expect(safeToApply(idle({ dirty: true }))).toBe(false)
  })

  it('ne tik po dotiku (izbirnik datotek, kamera, deljenje skrijejo stran)', () => {
    expect(safeToApply(idle({ sinceInput: 800 }))).toBe(false)
    expect(safeToApply(idle({ sinceInput: 6000 }))).toBe(true)
  })

  it('ob prehodu na drug zaslon da, na istem zaslonu ne', () => {
    expect(safeToApply(idle({ why: 'nav', from: 'plan', route: 'prehrana', sinceInput: 0, dirty: true }))).toBe(true)
    expect(safeToApply(idle({ why: 'nav', from: 'plan', route: 'plan' }))).toBe(false)
  })
})
