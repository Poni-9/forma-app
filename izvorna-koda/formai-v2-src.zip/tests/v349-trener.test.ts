// v3.49 TRENER: videz brez obljub (pravilo, honest), kontekst načrta po meri brez kolesarstva, brez merilnika moči brez
// vatov (tekma in pozivi), nasvet za danes z odtisom dneva, markdown v odgovorih, ure in ciljna teža v kontekstu, vaje
// v dnevnem pozivu, napaka AI brez »HTTP«, lestvica telesne maščobe (T01) in vaje iz odgovora (T02).
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const h = vi.hoisted(() => ({ kv: new Map<string, unknown>(), idToken: vi.fn(async (_force?: boolean) => 'tok') }))
vi.mock('@/data/db', () => ({ getKV: async (k: string) => h.kv.get(k), setKV: async (k: string, v: unknown) => { h.kv.set(k, v) } }))
vi.mock('../src/data/firebase', () => ({ idToken: (force?: boolean) => h.idToken(force) }))

import { aiContext, coachDailyPrompt, adaptPlanPrompt, LOOKS_RULE, NO_POWER_MARK } from '../src/domain/ai/prompts'
import { honest, HONEST_NOTE, sanitizeGaps } from '../src/domain/ai/sanitize'
import { mdBlocks, plainAi } from '../src/domain/ai/md'
import { personalContext } from '../src/domain/ai/personal'
import { dailyAdvice, cachedDailyAdvice, adviceSig, type Snapshot } from '../src/domain/ai/actions'
import { askText, AiError } from '../src/domain/ai/client'
import { buildWeek, FRANJA_2027 } from '../src/domain/training/planner'
import { normalizeFocus, isCustom } from '../src/domain/focus/model'
import { looksIntent, bodyFatView, monthsTo, monthsText, scalePos, BANDS, TOP, FLOOR, MINOR_TEXT } from '../src/domain/coach/bodyfat'
import { exercisesIn } from '../src/domain/coach/exmention'
import type { PlanDay, Profile } from '../src/domain/types'

const NOW = '2026-10-17T08:00:00.000Z'
const T = '2026-10-17'                       // sobota; teden se začne 12. 10.
const bike = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, ftpDate: '2026-09-14', maxHr: 195, restHr: 50, lthr: 184,
  gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, strength: { on: false, equipment: 'none' },
  hoursPerWeek: 11, goal: 'dirka', deficit: 400, onboardingDone: true, event: { ...FRANJA_2027 }, cycleStart: '2026-09-21',
  goalStart: { date: '2026-09-22', ftp: 240, weightKg: 79 }, aiConsentAt: NOW, aiConsentV: 2, createdAt: NOW, updatedAt: NOW, ...o,
} as Profile)
const day = (o: Partial<PlanDay>): PlanDay => ({ id: 'd' + (o.date || T), date: T, kind: 'kolo', title: 'Dolga Z2', desc: 'Enakomerno.', durationMin: 105, zone: 'Z2', role: 'dolga', source: 'rules', createdAt: NOW, updatedAt: NOW, ...o } as PlanDay)
const txt = (parts: readonly unknown[]) => parts.map(p => (p as { text?: string }).text || '').join('\n')
const gym = (): Profile => ({
  sex: 'm', age: 30, heightCm: 178, weightKg: 95, goal: 'shujsati', deficit: 350, gear: { bikeOutdoor: true, trainer: true, noBike: false }, strength: { on: true, equipment: 'gym' },
  onboardingDone: true, createdAt: NOW, updatedAt: NOW,
  focus: normalizeFocus({ wish: 'fitnes in hujšanje', title: 'Močnejši in lažji', sports: ['fitnes'], aims: ['hujsanje', 'moc'], level: 2, equipment: ['fitnes'], keepMuscle: true, sessions: [{ type: 'fitnes', part: 'zgornji', min: 60 }, { type: 'fitnes', part: 'spodnji', min: 60 }, { type: 'fitnes', part: 'zgornji', min: 60 }, { type: 'fitnes', part: 'spodnji', min: 60 }] }, { now: NOW, by: 'pravila' }),
} as Profile)

beforeEach(() => { h.kv.clear() })
afterEach(() => { vi.unstubAllGlobals(); vi.useRealTimers() })

describe('A01 videz: brez obljub, slik in »zagotovim«', () => {
  it('pravilo o videzu je v obeh personah; poziv pove, da lestvico in slike vaj pokaže aplikacija', () => {
    for (const p of [bike(), gym()]) {
      const t = txt(coachDailyPrompt(aiContext([], p, []), [], 'Do kdaj bom izklesan?'))
      expect(t).toContain('nikoli ne obljubljaj rezultata ali datuma')
      expect(t).toContain('pokaže lestvico telesne maščobe (odraslim) in slike vaj iz svoje knjižnice')
      expect(t).toContain(LOOKS_RULE)
    }
  })
  it('honest: zagotovilo videza izpade s pripisom, »zagotovim ti, da« → »realno je, da«, ostalo ostane', () => {
    const a = honest('Zagotovim ti six-pack do marca. Jej 140 g beljakovin.')
    expect(a).not.toMatch(/zagotovim|six-pack/i)
    expect(a).toBe(`Jej 140 g beljakovin.\n\n${HONEST_NOTE}`)
    expect(honest('Zagotovim ti, da boš močnejši.')).toBe('Realno je, da boš močnejši.')
    expect(honest('Zagotovo boš do poletja izklesan. Spi 8 h.')).toBe(`Spi 8 h.\n\n${HONEST_NOTE}`)
    expect(honest('To ti zagotovim.\nDanes Z2.')).toBe('Danes Z2.')
    // markdown in alineje ostanejo; »zagotovijo« ni obljuba
    expect(honest('**Zagotovim** ti six-pack.\n- Deficit 400 kcal\n- Spanec')).toBe(`- Deficit 400 kcal\n- Spanec\n\n${HONEST_NOTE}`)
    const keep = 'Ogljikovi hidrati zagotovijo energijo za 100 % FTP.'
    expect(honest(keep)).toBe(keep)
    expect(honest('')).toBe('')
  })
  it('kontekst: najboljša teža brez »maščoba ~18 % → ~10 %«', () => {
    const pc = personalContext({ profile: bike(), activities: [], plan: [], checkins: [], recentMeals: [], today: T })
    expect(pc).toMatch(/najboljša teža \d+(\.\d)? kg \(ocena iz BMI; pusta masa/)
    expect(pc).not.toMatch(/maščoba ~|→ ~10 %/)
  })
})

describe('A02 načrt po meri: kontekst brez kolesarstva', () => {
  it('fitnes in hujšanje: brez kolesarja, FTP, W/kg, metode in OH na kolesu; cilj po dogovoru in metoda blokov', () => {
    const p = gym()
    expect(isCustom(p)).toBe(true)
    const pc = personalContext({ profile: p, activities: [], plan: [], checkins: [], recentMeals: [], today: T })
    expect(pc).not.toMatch(/kolesar|W\/kg|FTP|na kolesu|METODA \(drži|Lestvica amaterjev|izven kolesa/)
    expect(pc).toMatch(/^CILJ PO DOGOVORU: .*teža zdaj 95 kg/m)
    expect(pc).toContain('METODA: bloki po 4 tedne')
    expect(pc).toMatch(/PREHRANA: teža naj pada 0,3–0,5 kg na teden.*deficit 350 kcal na dan/)
    // kolesar: kot prej
    const cyc = personalContext({ profile: bike(), activities: [], plan: [], checkins: [], recentMeals: [], today: T })
    expect(cyc).toContain('GLAVNI CILJ'); expect(cyc).toMatch(/W\/kg/)
  })
})

describe('A10 brez merilnika moči: tekma in pozivi v utripu', () => {
  const race = (pm: boolean) => buildWeek({ profile: bike({ gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: pm } }), activities: [], weekStart: '2027-06-07', notBefore: '2026-01-01' }).find(d => d.role === 'dirka')!
  it('Franja: brez merilnika »Kladje … pri utripu«, z merilnikom vati; cilj za vodeno vadbo ostane', () => {
    const no = race(false)
    expect(no.desc).toMatch(/Kladje \(7 km, 6,3 %\) enakomerno pri utripu \d+–184/)
    expect(no.desc).not.toMatch(/\d\s?W\b/)
    expect(no.target).not.toBeNull()
    expect(race(true).desc).toMatch(/Kladje \(7 km, 6,3 %\) enakomerno pri \d+–\d+ W/)
  })
  it('pozivi: brez merilnika brez »z vati« in »vate iz FTP«; z merilnikom kot prej', () => {
    const ctx = aiContext([], bike(), [])
    expect(ctx).toContain(NO_POWER_MARK)
    const t = txt(coachDailyPrompt(ctx, []))
    expect(t).not.toMatch(/z vati za današnjo sejo|izračunaj iz FTP/)
    expect(t).toMatch(/z utripom in občutkom \(RPE\)/)
    expect(txt(adaptPlanPrompt(ctx, [day({})]))).not.toContain('V opisih navedi vate iz FTP')
    const pm = aiContext([], bike({ gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: true } }), [])
    expect(pm).not.toContain(NO_POWER_MARK)
    expect(txt(coachDailyPrompt(pm, []))).toContain('z vati za današnjo sejo')
    expect(txt(adaptPlanPrompt(pm, [day({})]))).toContain('V opisih navedi vate iz FTP')
  })
})

describe('A12 nasvet za danes velja samo za dan, kot je bil', () => {
  it('po spremembi treninga ali počutja je shranjen nasvet star; nov klic vpraša AI znova', async () => {
    const f = vi.fn(async () => new Response(JSON.stringify({ text: 'Danes dolga Z2 1 h 45 min.' }), { status: 200 }))
    vi.stubGlobal('fetch', f)
    const plan = [day({})]
    const s: Snapshot = { profile: bike(), activities: [], plan, today: T, extra: '' }
    const a = adviceSig({ plan, today: T, checkinToday: null })
    expect(await dailyAdvice(s, false, a)).toBe('Danes dolga Z2 1 h 45 min.')
    expect(await cachedDailyAdvice(T, a)).toEqual({ text: 'Danes dolga Z2 1 h 45 min.', stale: false })
    await dailyAdvice(s, false, a)
    expect(f).toHaveBeenCalledTimes(1)                                   // isti dan → iz predpomnilnika
    const walk = [day({ title: 'Sprehod', kind: 'pohod', durationMin: 30, byState: { date: T, mode: 'sprehod' } })]
    const b = adviceSig({ plan: walk, today: T, checkinToday: { mood: 2, soreness: 4 } })
    expect(b).not.toBe(a)
    expect(adviceSig({ plan, today: T, checkinToday: { mood: 2, soreness: 4 } })).not.toBe(a)   // samo počutje
    expect((await cachedDailyAdvice(T, b))!.stale).toBe(true)
    await dailyAdvice({ ...s, plan: walk }, false, b)
    expect(f).toHaveBeenCalledTimes(2)
    // star zapis (samo besedilo, pred v3.49): odtisa ne poznamo → ga ne kažemo (Danes: lokalna vrstica in »AI nasvet za danes«)
    h.kv.set(`ai.daily.${T}`, 'star nasvet')
    expect(await cachedDailyAdvice(T, b)).toBeNull()
  })
})

describe('A14/D14 markdown v odgovoru trenerja', () => {
  it('krepko, naslov kot krepka vrstica, alineje kot seznam; povezave in HTML izginejo', () => {
    expect(plainAi('**A** b\n- c\n## d')).toBe('A b\n– c\nd')
    expect(mdBlocks('**A** b\n- c\n## d')).toEqual([{ k: 'p', c: [{ t: 'A', b: true }, { t: ' b' }] }, { k: 'ul', items: [[{ t: 'c' }]] }, { k: 'h', c: [{ t: 'd' }] }])
    expect(mdBlocks('1. ena\n2) dve\n\n* tri\n\n* štiri')).toEqual([{ k: 'ol', items: [[{ t: 'ena' }], [{ t: 'dve' }]] }, { k: 'ul', items: [[{ t: 'tri' }], [{ t: 'štiri' }]] }])
    const bad = plainAi('Tu je [klik](javascript:alert(1)) <img src=x onerror=alert(1)> ![slika](http://x/y.png) *poševno* `koda`')
    expect(bad).toBe('Tu je klik poševno koda')
    expect(plainAi('| a | b |\n|---|---|\n| 1 | 2 |\n---\nkonec')).toBe('a · b\n1 · 2\nkonec')
    // sanitizeGaps (nespremenjen) loči vrstice s prazno vrstico — seznam ostane en seznam
    const hidden = sanitizeGaps('Dobro.\n- ena\n- dve\nPo premoru lahko.', true)
    expect(mdBlocks(hidden).map(b => b.k)).toEqual(['p', 'ul'])
  })
})

describe('A15 kontekst: ure tedna iz načrta in ciljna teža brez »?«', () => {
  it('»načrt ta teden 4,5 h« iz Plana; »do … kg« iz ciljne teže ali brez', () => {
    const plan = [day({ date: '2026-10-13', durationMin: 60 }), day({ date: '2026-10-15', durationMin: 90 }), day({ date: '2026-10-17', durationMin: 120 }), day({ date: '2026-10-16', kind: 'moc', durationMin: 30, optional: true }), day({ date: '2026-10-19', durationMin: 300 })]
    const pc = personalContext({ profile: bike(), activities: [], plan, checkins: [], recentMeals: [], today: T })
    expect(pc).toContain('načrt ta teden 4,5 h (normalen teden 11 h')
    expect(pc).not.toContain('do ? kg')
    expect(pc).toMatch(/teža naj pada 0,3–0,5 kg na teden do \d+(\.\d)? kg/)
    const noGoal = personalContext({ profile: bike({ event: null, goal: 'hitrejsi', targetWeightKg: null }), activities: [], plan, checkins: [], recentMeals: [], today: T })
    expect(noGoal).not.toMatch(/do \?|do null/)
  })
})

describe('A16 dnevni nasvet pri moči: vaje iz načrta v pozivu', () => {
  it('dan moči z dvema vajama → obe vaji s serijami in kg', () => {
    const moc = day({ kind: 'moc', title: 'Fitnes — zgornji del', durationMin: 60, zone: null, role: null, exercises: [{ name: 'Potisk s palico na ravni klopi', sets: 3, reps: '6–10', kg: 40 }, { name: 'Sklece', sets: 3, reps: '8–15' }] })
    const t = txt(coachDailyPrompt(aiContext([], gym(), []), [moc]))
    expect(t).toContain('vaje: Potisk s palico na ravni klopi 3×6–10 @40 kg, Sklece 3×8–15')
  })
})

describe('A33 napaka AI brez »HTTP 503«', () => {
  it('preobremenjen strežnik: »AI zdaj ne more odgovoriti — poskusi čez minuto.«', async () => {
    vi.useFakeTimers()
    vi.stubGlobal('fetch', vi.fn(async () => new Response('{}', { status: 503 })))
    const p = askText([{ text: 'x' }]).catch(x => x)
    await vi.runAllTimersAsync()
    const e = await p as AiError
    expect(e.kind).toBe('network')
    expect(e.message).toBe('AI zdaj ne more odgovoriti — poskusi čez minuto.')
  })
})

describe('T01 lestvica telesne maščobe', () => {
  it('zaznava vprašanj o videzu (tudi brez strešic), ne pa »boli me trebuh« ali »postavi«', () => {
    for (const q of ['Do kdaj bom izklesan? A lahko pokažeš sliko, kako bom zgledal?', 'Kako izgubim maščobo okoli pasu?', 'Kdaj bom imel six-pack?', 'Kako do vidnega trebuha?', 'kdaj se mi bodo videle trebusne misice', 'Kakšna bo moja postava čez pol leta?', 'Koliko % maščobe imam?'])
      expect(looksIntent(q), q).toBe(true)
    for (const q of ['Kako izpeljem VO2max intervale?', 'Boli me trebuh po vožnji.', 'Postavi mi plan za jutri.', 'Koliko OH na dolgi vožnji?', 'Kako delam kolesarske trebušnjake?'])
      expect(looksIntent(q), q).toBe(false)
  })
  it('ocena po Deurenbergu, cilj 10–12 % (m) / 18–21 % (ž), okvirni čas kot razpon, brez »zagotovo«', () => {
    const v = bodyFatView(bike())
    if (v.kind !== 'scale') throw new Error(v.kind)
    expect(v.now).toEqual({ pct: 17.9, measured: false })               // 1,2 · 24,4 + 0,23 · 21 − 10,8 − 5,4
    expect(v.target).toEqual({ lo: 10, hi: 12 })
    expect(v.months).toEqual({ lo: 6, hi: 12 })
    expect(v.lines[0]).toContain('okvirno 6–12 mesecev — ne obljuba')
    expect(v.lines.join(' ')).toMatch(/genetike, razporeditve maščobe in mišic/)
    expect(v.lines.join(' ')).toMatch(/ocena iz BMI/)
    expect(JSON.stringify(v)).not.toMatch(/zagotov/i)
    const z = bodyFatView(bike({ sex: 'z', heightCm: 168, weightKg: 64, age: 30 }))
    if (z.kind !== 'scale') throw new Error(z.kind)
    expect(z.target).toEqual({ lo: 18, hi: 21 })
    expect(z.bands).toBe(BANDS.z)
    // vpisana maščoba ima prednost; že v razponu → brez časa, nikoli nižje od 10 %
    const lean = bodyFatView(bike({ bodyFatPct: 11 }))
    if (lean.kind !== 'scale') throw new Error(lean.kind)
    expect(lean.now).toEqual({ pct: 11, measured: true }); expect(lean.months).toBeNull()
    expect(lean.lines[0]).toMatch(/Si že v razponu.*Nižje od 10 % ne ciljaj/)
  })
  it('pod 18 let in brez starosti: brez lestvice; cilj nikoli pod mejo', () => {
    expect(bodyFatView(bike({ age: 16 }))).toEqual({ kind: 'minor', text: MINOR_TEXT })
    expect(bodyFatView(bike({ age: 16, bodyFatPct: 20 })).kind).toBe('minor')
    expect(bodyFatView(bike({ age: null })).kind).toBe('need')
    expect(bodyFatView(bike({ sex: null as never })).kind).toBe('need')
    for (const sex of ['m', 'z'] as const) for (const bf of [5, 9, 12, 16, 25, 40]) {
      const v = bodyFatView(bike({ sex, bodyFatPct: bf }))
      if (v.kind !== 'scale') throw new Error(v.kind)
      expect(v.target.lo).toBeGreaterThanOrEqual(FLOOR[sex])
    }
    expect(monthsTo(12, 12)).toBeNull(); expect(monthsTo(12.4, 12)).toEqual({ lo: 1, hi: 1 })
    expect(monthsText({ lo: 2, hi: 4 })).toBe('okvirno 2–4 mesece — ne obljuba')
    // položaj na lestvici narašča in ostane 0–1
    const ps = [5, 10, 11, 12, 15, 20, 25, 30, 45].map(x => scalePos(x, BANDS.m, TOP.m))
    for (let i = 1; i < ps.length; i++) expect(ps[i]!).toBeGreaterThanOrEqual(ps[i - 1]!)
    expect(ps[0]).toBe(0); expect(ps[ps.length - 1]).toBe(1)
  })
})

describe('T02 vaje iz odgovora trenerja', () => {
  const ids = (t: string) => exercisesIn(t).map(e => e.id)
  it('sklon in deblo: počepe, počepov, mrtvega dviga, plezalca; daljše ime ima prednost', () => {
    expect(ids('Naredi 3 serije počepov in 3 × 10 sklec.')).toEqual(['pocep', 'sklece'])
    expect(ids('Počepe delaj počasi.')).toEqual(['pocep'])
    expect(ids('Mrtvega dviga danes ne delaj.')).toEqual(['mrtvi'])
    expect(ids('Romunski mrtvi dvig z ročkami in nato bolgarski počep.')).toEqual(['rdl-r', 'bolgarski'])
    expect(ids('Stranska deska 3 × 30 s, nato navadna deska in 20 plezalcev.')).toEqual(['stranska', 'deska', 'plezalec'])
    expect(ids('Upogibi za biceps in izpadne korake.')).toEqual(['biceps-r', 'izpadni'])
    expect(ids('Zgibi, deska, počep, sklece')).toHaveLength(3)                        // največ 3
  })
  it('brez napačnih zadetkov: počitek, most, dvigni, tek in kolo niso vaje', () => {
    expect(ids('Počitek je danes pomemben. Dvigni boke? Ne, danes tek in kolo Z2 čez most.')).toEqual([])
    expect(ids('')).toEqual([])
  })
})
