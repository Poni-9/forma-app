// v3.48 T2 — koraki in cone (vodena vadba, ura, Danes): tempo tek je en blok, tek in hoja s ciljem iz opisa, cone brez
// FTP iz praga, Z2 vožnja s tempom v Z3, kratki napori brez merilnika po občutku, tekma z ogrevanjem in štoparico,
// ogrevanje/iztek iz opisa in na 5 min, cone moči brez lukenj, regeneracija en korak, moč kot v opisu; Gorivo na dan
// tekme brez »Dan prej«; delno shranjena vožnja šteje dejanski čas; Vadba: hook pred return, besedila, oblika časa.
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), id: '' }))
const emit = () => S.subs.forEach(f => f())
const store = vi.hoisted(() => ({ setPlanDone: vi.fn(async () => {}), addActivities: vi.fn(async () => ({ added: 1, dupes: 0, upgraded: 0 })), toast: vi.fn(), savePlanDay: vi.fn(), savePlanDays: vi.fn(), saveCheckin: vi.fn(async () => {}), rateSession: vi.fn() }))
vi.mock('@/state/store', () => ({
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  ...store,
  newRouteFor: vi.fn(), routePace: () => ({ k: 1, adj: { n: 0, adj: 1 } }),
}))
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => ({ name: 'vadba', params: { id: S.id } }) }))

import { stepsFor, structureLines, fmtClock, totalSec } from '@/domain/training/workout'
import { zoneText, workText, lthrZoneText } from '@/domain/training/zones'
import { hrZoneRows, powerZoneRows } from '@/domain/training/zwo'
import { weekProgress } from '@/domain/training/share'
import { fueling } from '@/domain/nutrition/energy'
import { raceBreakfast } from '@/domain/training/planner'
import { zoneLineOf } from '@/screens/Danes'
import { drillGist } from '@/ui/SessBits'
import { Vadba } from '@/screens/Vadba'
import type { PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

const NOW = '2026-10-17T08:00:00.000Z'
const day = (o: Partial<PlanDay> = {}): PlanDay => ({ id: 'd1', date: '2026-10-17', kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, ...o })
// brez merilnika moči (prag 184: Z1 pod 149, Z2 149–164, Z3 165–171, Z4 172–184, Z5 nad 184)
const NOPM = { sex: 'm', age: 21, weightKg: 79, ftp: 240, lthr: 184, maxHr: 203, restHr: 70, gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, strength: { on: false, equipment: 'none' } } as unknown as Profile
const PM = { ...NOPM, ftp: 250, gear: { ...NOPM.gear, powerMeter: true } } as unknown as Profile
// tekač brez FTP (prag 55 + 0,85 × 140 = 174: Z2 141–155, Z3 156–162, Z4 163–174)
const RUN = { sex: 'm', age: 24, weightKg: 82, maxHr: 195, restHr: 55, gear: { bikeOutdoor: false, trainer: false, noBike: true }, strength: { on: false, equipment: 'none' } } as unknown as Profile
const work = (st: ReturnType<typeof stepsFor>) => st.filter(s => s.kind === 'delo')

describe('A05/A06/A20/A43 tek: tempo en blok, tek in hoja s ciljem, ogrevanje iz opisa', () => {
  it('A05 »Tempo tek — 15 min« je 1 × 15 min tempa takoj po 10 min ogrevanja (prej 2 × 8 min)', () => {
    const d = day({ kind: 'tek', title: 'Tempo tek — 15 min', desc: '10 min lahko, nato 15 min udobno hitro (utrip 156–162), na koncu lahko do konca.', durationMin: 40, zone: 'Z3', role: 'kljucna' })
    const st = stepsFor(d, RUN)
    expect(work(st).map(s => s.sec)).toEqual([900])
    expect(work(st)[0]!.target).toBe('utrip 156–162')
    expect(st[0]!.kind).toBe('ogrevanje'); expect(st[0]!.sec).toBe(600)
    expect(st[1]!.kind).toBe('delo')
    expect(totalSec(st)).toBe(40 * 60)
    expect(structureLines(st)).toContain('15 min tempo (utrip 156–162)')
  })
  it('A06 tek in hoja: hitri deli z utripom iz opisa, »pogovorni tempo« ne; pregled »teka … hoje«', () => {
    const d = day({ kind: 'tek', title: 'Tek in hoja — 5 × 1 min hitreje', desc: '10 min hitre hoje ali lahkega teka, nato 5 × (1 min tek hitreje / 2 min hoja). Hitreje = utrip 163–174, ne na vso moč. Na koncu 5 min hoje.', durationMin: 30, zone: 'Z4', role: 'kljucna' })
    const st = stepsFor(d, RUN)
    expect(work(st).length).toBe(5)
    expect(work(st).every(s => s.target === 'utrip 163–174')).toBe(true)
    expect(structureLines(st)).toContain('5 × 1 min teka (utrip 163–174), vmes 2 min hoje')
    expect(st[0]!.sec).toBe(600)                                   // A20: »10 min hitre hoje …, nato«
  })
  it('A20/A43 »Tek — 4 × 2 min«: 12 min ogrevanja, 5 min na koncu, vmes »Lahek tek« (ne »Z2 vzdržljivost«)', () => {
    const d = day({ kind: 'tek', title: 'Tek — 4 × 2 min hitro', desc: '12 min lahkega teka, nato 4 × (2 min hitro / 2 min lahko). Hitro = utrip 163–174. Enakomerno — zadnji naj bo enako hiter kot prvi. 5 min lahko na koncu.', durationMin: 35, zone: 'Z4', role: 'kljucna' })
    const st = stepsFor(d, RUN)
    expect(st[0]!.sec).toBe(12 * 60); expect(st[st.length - 1]!.sec).toBe(5 * 60)
    expect(st.some(s => s.label === 'Z2 vzdržljivost')).toBe(false)
    expect(st.some(s => s.label === 'Lahek tek')).toBe(true)
    expect(work(st).every(s => s.target === 'utrip 163–174')).toBe(true)   // A08: iste meje kot opis
  })
  it('A20 kolo »15 min lahko, nato 5 × 4 min …, zadnjih 10 min zelo lahko«: 15 in 10 min (prej 12 in 7)', () => {
    const d = day({ title: 'Kolo — 5 × 4 min hitro', desc: '15 min lahko, nato 5 × 4 min hitro (utrip 163–174), vmes 3 min lahko. Preostanek lahko, zadnjih 10 min zelo lahko.', durationMin: 60, zone: 'Z4', role: 'kljucna' })
    const st = stepsFor(d, RUN)
    expect(st[0]!.sec).toBe(900); expect(st[st.length - 1]!.sec).toBe(600)
  })
})

describe('A08/A27 cone', () => {
  it('A08 brez FTP: cone iz praga, enako kot Napredek (prej Karvonen: 134–148 proti 137–150)', () => {
    const p = { maxHr: 190, restHr: 50, gear: {} } as unknown as Profile
    const rows = hrZoneRows(p)!.rows
    expect(zoneText(p, 'Z2')).toBe(`utrip ${rows[1]!.range}`)
    expect(zoneText(p, 'Z4')).toBe(`utrip ${rows[3]!.range}`)
    expect(zoneText(p, 'Z1')).toBe(`utrip ${rows[0]!.range}`)
  })
  it('A27 vati: »pod 140 W« in brez lukenj, iste meje kot Napredek', () => {
    expect(zoneText(PM, 'Z1')).toBe('pod 140 W')
    expect(zoneText(PM, 'Z3')).toMatch(/^189–/)
    const rows = powerZoneRows(PM)!
    for (const [k, i] of [['Z1', 0], ['Z2', 1], ['Z3', 2], ['Z4', 3], ['Z5', 4]] as const) expect(zoneText(PM, k)).toBe(`${rows[i]!.range} W`)
    // v pregledu »(pod 140 W)«, ne »pri pod 140 W«
    expect(structureLines(stepsFor(day({ durationMin: 60 }), PM)).join(' ')).not.toMatch(/pri pod/)
  })
})

describe('A09/A10 cilj dela', () => {
  const tempoDirke = day({ title: 'Z2 + 3 × 5 min tempo dirke', desc: 'Z2 utrip 149–164; v drugi uri 3 × 5 min pri utripu 165–171 (≈ 211–228 W, brez merilnika po občutku). Gorivo 60–80 g/h — preizkusi, kar boš jedel na dirki.', durationMin: 135, zone: 'Z2', role: 'dolga', target: { lo: 211, hi: 228 } })
  it('A09 Z2 vožnja s tempom: cilj je Z3 (opis 165–171), ne Z4 (172–184) — Danes in koraki', () => {
    expect(workText(NOPM, { target: { lo: 204, hi: 221 }, zone: 'Z2' })).toBe(lthrZoneText(NOPM, 'Z3'))
    const st = stepsFor(tempoDirke, NOPM)
    expect(work(st).every(s => s.z === 'Z3' && s.target === 'utrip 165–171')).toBe(true)
    // z merilnikom: isti blok je Z3 (barva, ura), cilj v vatih iz opisa
    const pm = { ...tempoDirke, desc: 'Z2 134–180 W; v drugi uri 3 × 5 min pri 211–228 W (88–95 % FTP).', target: { lo: 211, hi: 228 } }
    expect(work(stepsFor(pm, { ...PM, ftp: 240 } as Profile)).every(s => s.z === 'Z3')).toBe(true)
    expect(zoneLineOf(tempoDirke, NOPM, st).line).toBe('tempo utrip 165–171')
  })
  it('A09 »intervali« samo pri ključnem treningu; VO2max ostane', () => {
    const vo2 = day({ title: 'VO2max 4 × 4 min', desc: '20 min ogrevanje s 3 kratkimi pospeški · 4 × 4 min pri utripu nad 184 · RPE 9 (≈ 259–276 W, brez merilnika po občutku), vmes 4 min lahko · nato 10 min Z2 (utrip 149–164) · 17 min iztek.', durationMin: 75, zone: 'Z5', role: 'kljucna', target: { lo: 259, hi: 276 } })
    expect(zoneLineOf(vo2, NOPM, stepsFor(vo2, NOPM)).line).toBe('intervali utrip nad 184 · RPE 9')
  })
  it('A10 kratki napori brez merilnika: koraki in Danes »RPE 9 · po občutku«, ne »utrip nad 184«', () => {
    const pre = day({ title: 'Predaktivacija 3 × 1 min', desc: '20 min ogrevanje s 3 kratkimi pospeški · 3 × 1 min zelo trdo (RPE 9), vmes 2 min lahko · 15 min iztek. Brez merilnika moči: utrip pri kratkih naporih zaostaja — vozi po občutku.', durationMin: 40, zone: 'Z5', role: 'lahka', target: { lo: 264, hi: 288 } })
    const st = stepsFor(pre, NOPM)
    expect(work(st).length).toBe(3)
    expect(work(st).every(s => s.target === 'RPE 9 · po občutku')).toBe(true)
    const z = zoneLineOf(pre, NOPM, st)
    expect(z.line).toBe('pospeški RPE 9 · po občutku')
    expect(drillGist(st, z.known)).toBe('3 × 1 min, vmes 2 min lahko')
    // 30/15 (ključni, brez cilja v W): enako
    const t15 = day({ title: '30/15 — 3 serije × 13', desc: '20 min ogrevanje s 3 kratkimi pospeški · 3 serije × 13 × (30 s zelo trdo, a enakomerno / 15 s lahko), med serijami 3 min lahko · ostanek Z2 (utrip 149–164), 15 min iztek.', durationMin: 90, zone: 'Z5', role: 'kljucna', target: null })
    const s15 = stepsFor(t15, NOPM)
    expect(work(s15).every(s => !/utrip/.test(s.target || ''))).toBe(true)
    expect(zoneLineOf(t15, NOPM, s15).line).toBe('intervali RPE 9 · po občutku')
    // z merilnikom ostanejo vati
    expect(work(stepsFor({ ...pre, desc: '20 min ogrevanje s 3 kratkimi pospeški · 3 × 1 min pri 264–288 W (110–120 % FTP), vmes 2 min lahko · 15 min iztek.' }, { ...PM, ftp: 240 } as Profile))[0]!.target).toBe('264–288 W')
  })
})

describe('A13 tekma: ogrevanje iz opisa + »Tekma« brez časovnika', () => {
  it('kronometer: 25 min ogrevanja, nato korak brez časa; opomba brez zajtrka', () => {
    const r = day({ title: 'Kronometer Vodice — 18 km', desc: 'Zajtrk 2–3 h pred startom (1–2 g OH na kg). Ogrevanje 25 min s 3 × 2 min na pragu; enakomerno, zadnjih 5 min vse.', durationMin: 30, zone: 'dirka', role: 'dirka', raceId: 'r1' })
    const st = stepsFor(r, NOPM)
    expect(st.map(s => [s.kind, s.sec])).toEqual([['ogrevanje', 1500], ['delo', 0]])
    expect(st[0]!.note).toBe('Lahko, s 3 × 2 min na pragu.')
    expect(st[1]!.label).toBe('Tekma')
    expect(st[1]!.note).toBe('Enakomerno, zadnjih 5 min vse. Ko prečkaš cilj, tapni Zaključi.')
    expect(st[1]!.note).not.toMatch(/Zajtrk|OH/)
  })
  it('maraton brez ogrevanja v opisu: en korak brez časa', () => {
    const f = day({ title: 'Maraton Franja — 156 km', desc: 'Zajtrk 3 h pred startom (2–3 g OH na kg). Na kolesu ~85 g OH na uro od 30. minute (seznam in urnik v Gorivu), pijača z elektroliti. Ravnina v zavetrini, Kladje enakomerno na pragu — ne po špicah skupine.', durationMin: 280, zone: 'dirka', role: 'dirka' })
    const st = stepsFor(f, NOPM)
    expect(st.length).toBe(1); expect(st[0]!.sec).toBe(0)
    expect(st[0]!.note).toMatch(/^Ravnina v zavetrini/)
  })
})

describe('A32/A33/A46 koraki', () => {
  it('A32 regeneracija = en korak čez cel čas', () => {
    const st = stepsFor(day({ title: 'Regeneracija', desc: 'Zelo lahko (utrip pod 149) — noge samo vrtijo.', durationMin: 45, zone: 'Z1', role: 'regen' }), NOPM)
    expect(st.length).toBe(1); expect(st[0]!.sec).toBe(45 * 60)
  })
  it('A33 seje z vajami: ogrevanje in iztek na 5 min (prej 11 in 7 min)', () => {
    for (const min of [90, 95, 115]) {
      const st = stepsFor(day({ title: 'Z2 vzdržljivost + 6 × 10 s šprint', desc: 'Mirno utrip 149–164, kadenca 90+. Na sredi 6 × 10 s šprint — vse, kar gre; vmes 4–5 min zelo lahko.', durationMin: min }), NOPM)
      for (const s of st.filter(x => x.kind === 'ogrevanje' || x.kind === 'iztek')) expect(s.sec % 300).toBe(0)
      expect(totalSec(st)).toBe(min * 60)
    }
  })
  it('A46 moč: ogrevanje in pavze, kot piše opis (8 min, najmanj 90 s)', () => {
    const d = day({ kind: 'moc', title: 'Fitnes — prsa, ramena, triceps', desc: '8–10 min ogrevanja (kolo ali veslanje), nato prva vaja 1–2 lažji seriji. Med serijami 2–3 min pri osnovnih vajah, 90 s pri ostalih.', durationMin: 55, zone: null, role: 'moc', exercises: [{ name: 'Potisk s palico na ravni klopi', sets: 4, reps: '4–6', rest: 150 }, { name: 'Pike sklece', sets: 3, reps: '10–15', rest: 60 }] })
    const st = stepsFor(d, NOPM)
    expect(st[0]!.sec).toBe(8 * 60); expect(st[0]!.note).toBe('Kolo ali veslanje.')
    expect(st.filter(s => s.kind === 'pavza').every(s => s.sec >= 90)).toBe(true)
    expect(st.filter(s => s.kind === 'pavza' && s.label === 'Odmor').map(s => s.sec)).toEqual([150, 150, 150, 90, 90])
  })
})

describe('A42/A03/A28', () => {
  it('A42 Gorivo na dan tekme: zajtrk po istem pravilu kot opis, brez »Dan prej …«', () => {
    for (const min of [30, 100, 300]) {
      const f = fueling({ kind: 'kolo', durationMin: min, zone: 'dirka', role: 'dirka' }, { weightKg: 75 })!
      expect(f.before.startsWith(raceBreakfast(min, false))).toBe(true)
      expect(f.before).not.toMatch(/Dan prej/)
    }
  })
  it('A03 delno shranjena vožnja šteje dejanski čas (10 min od 75)', () => {
    const d = day({ durationMin: 75, done: { at: NOW, activityId: null, min: 10 } })
    expect(weekProgress([d], []).minDone).toBe(10)
    // povezana vožnja z ure ima prednost
    expect(weekProgress([{ ...d, done: { at: NOW, activityId: 'a', min: 10 } }], [{ id: 'a', durationMin: 70 }]).minDone).toBe(70)
    expect(weekProgress([{ ...d, done: { at: NOW } }], []).minDone).toBe(75)
  })
  it('A28 ista oblika časa: »0:01:55« ob »1:45:00«', () => {
    expect(fmtClock(115, true)).toBe('0:01:55')
    expect(fmtClock(115)).toBe('1:55')
  })
})

/* ---------- Vadba ---------- */
const today = new Date().toISOString().slice(0, 10)
const P = { sex: 'm', age: 35, heightCm: 180, weightKg: 75, ftp: 250, gear: { bikeOutdoor: true, trainer: false, noBike: false }, strength: { on: false, equipment: 'none' }, onboardingDone: true, createdAt: 'x', updatedAt: 'x' } as unknown as Profile
const ride = day({ id: 'd1', date: today, title: 'Z2 vožnja', desc: 'Enakomerno v Z2.', durationMin: 60 })
const long = day({ id: 'd2', date: today, title: 'Dolga Z2', desc: 'Enakomerno v Z2.', durationMin: 105, role: 'dolga' })
const raceDay = day({ id: 'r1', date: today, title: 'Kronometer Vodice — 18 km', desc: 'Zajtrk 2–3 h pred startom (1–2 g OH na kg). Ogrevanje 25 min s 3 × 2 min na pragu; enakomerno, zadnjih 5 min vse.', durationMin: 30, zone: 'dirka', role: 'dirka', raceId: 'r1' })
const reset = (plan: PlanDay[], intervals: unknown = null) => { S.state = { ready: true, today, plan, activities: [], recentMeals: [], weather: null, routeLib: null, routesBusy: false, settings: { lang: 'sl', intervals }, toast: null, profile: P } }

let div: HTMLDivElement, root: Root | null
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(b.textContent || '')) as HTMLButtonElement | undefined
const sheetBtn = (t: string) => [...document.querySelectorAll('.sheet button')].find(b => b.textContent === t) as HTMLButtonElement
async function mount(id: string) {
  S.id = id
  div = document.createElement('div'); document.body.appendChild(div)
  root = createRoot(div)
  await act(async () => { root!.render(<Vadba />) })
}
async function unmount() { if (root) { await act(async () => root!.unmount()); root = null } div?.remove() }
const tick = async (ms: number) => { await act(async () => { vi.advanceTimersByTime(ms) }) }
const flush = async () => { for (let i = 0; i < 6; i++) await act(async () => { await Promise.resolve() }) }

describe('Vadba (v3.48 T2)', () => {
  beforeEach(() => { vi.useFakeTimers(); sessionStorage.clear(); store.setPlanDone.mockClear(); S.subs.clear() })
  afterEach(async () => { await unmount(); vi.useRealTimers(); document.body.innerHTML = '' })

  it('A07 dan izgine iz načrta med pregledom: »Danes ni treninga«, brez napake hookov', async () => {
    reset([ride])
    await mount('d1')
    expect(div.textContent).toContain('Začni trening')
    const errs: string[] = []; const ce = console.error; console.error = (...a: unknown[]) => { errs.push(String(a[0])) }
    await act(async () => { S.state = { ...S.state, plan: [] }; emit() })
    console.error = ce
    // (v3.50 G27) dan s tem id-jem ni več v načrtu: to povemo (prej »Danes ni treninga«)
    expect(div.textContent).toContain('Te vadbe ni več v načrtu')
    expect(errs.join(' ')).not.toMatch(/hooks/i)
  })

  it('A31/A44/A38 pred vadbo: značka je intenzivnost (vrsta je v glavi), glava »Zapusti vadbo«, brez »OH«', async () => {
    // (v3.51) obroki po uri vadbe: popoldanska vožnja (prej po nastavitvi ne glede na uro)
    vi.setSystemTime(new Date(2026, 9, 18, 15, 0))
    reset([ride])
    await mount('d1')
    expect(div.querySelector('.kbadge')!.textContent).not.toMatch(/korak/)
    expect(div.querySelector('.kbadge')!.textContent).not.toBe('Kolo')
    expect(div.querySelector('header button')!.getAttribute('aria-label')).toBe('Zapusti vadbo')
    // (v3.49 CILJ, B26) »Pred« kot v Prehrani: kosilo 2–3 h prej (prej »1 h prej lahek prigrizek z ogljikovimi hidrati«)
    expect(div.textContent).toMatch(/Kosilo\s·\s2\W{0,3}3\sh\spred\svožnjo/)
    expect(div.textContent).not.toMatch(/\bOH\b/)
    await act(async () => { btn(/Začni trening/)!.click() })
    expect(btn(/Prejšnji/)!.getAttribute('aria-label')).toBe('Prejšnji korak')
    expect(div.textContent).not.toMatch(/‹ Nazaj/)
  })

  it('A26 obroč koraka v barvi cone koraka (ogrevanje Z1, delo Z2)', async () => {
    reset([ride])
    await mount('d1')
    await act(async () => { btn(/Začni trening/)!.click() })
    expect((div.querySelector('.stepring') as HTMLElement).style.getPropertyValue('--c')).toBe('var(--z1)')
    await act(async () => { btn(/Preskoči/)!.click() })
    expect((div.querySelector('.stepring') as HTMLElement).style.getPropertyValue('--c')).toBe('var(--z2)')
  })

  it('A28/A29 »Skupaj 0:00:04 od 1:45:00«; po »Preskoči« »od« ostane, preostanek v »še …« (v3.50 H45)', async () => {
    reset([long])
    const st = stepsFor(long, P)
    await mount('d2')
    await act(async () => { btn(/Začni trening/)!.click() })
    await tick(4_000)
    expect(div.querySelector('.run-sum')!.textContent).toMatch(/^Skupaj 0:00:04 od 1:45:00/)
    await act(async () => { btn(/Preskoči/)!.click() })
    expect(div.querySelector('.run-sum')!.textContent).toContain('od 1:45:00 · še')
    expect(totalSec(st.slice(1))).toBeLessThan(105 * 60)
  })

  it('A03/A31 delno: »Dan se označi kot opravljen (31 min od 1 h)«, shrani 31 min, »2 od 3 korakov«', async () => {
    reset([ride])
    await mount('d1')
    await act(async () => { btn(/Začni trening/)!.click() })
    await tick(31 * 60_000)
    await act(async () => { btn(/^Zaključi$/)!.click() })
    expect(document.querySelector('.sheet')!.textContent).toContain('Dan se označi kot opravljen (31 min od 1 h).')
    await act(async () => { sheetBtn('Zaključi').click() })
    await flush()
    expect(store.setPlanDone).toHaveBeenCalledWith('d1', true, null, 31)
    expect(div.textContent).toContain('2 od 3 korakov')
    // A16: brez povezave z intervals.icu ne obljubi vožnje iz Garmina
    expect(div.textContent).toContain('uvozi kot datoteko (.fit, .gpx)')
    expect(div.textContent).not.toContain('pride iz Garmina')
  })

  it('A16 s povezavo intervals.icu: »Vožnja pride iz Garmina«', async () => {
    reset([ride], { athleteId: 'i1', apiKey: 'k' })
    await mount('d1')
    await act(async () => { btn(/Začni trening/)!.click() })
    await tick(61 * 60_000)
    await flush()
    expect(div.textContent).toContain('Opravljeno')
    expect(div.textContent).toContain('Vožnja pride iz Garmina')
  })

  it('A13 tekma: po ogrevanju štoparica teče naprej in se ne konča sama; »Zaključi« shrani čas', async () => {
    reset([raceDay])
    await mount('r1')
    expect(div.querySelector('.kbadge')!.textContent).toBe('Tekma')
    await act(async () => { btn(/Začni trening/)!.click() })
    await tick(25 * 60_000 + 500)
    expect(div.textContent).toContain('2 / 2')
    expect(div.textContent).toContain('Tekma')
    await tick(40 * 60_000)                                       // 40 min tekme — ne konča se sam (prej ob 30:00 … 0:00)
    expect(div.textContent).not.toContain('Opravljeno')
    expect(div.querySelector('.num')!.textContent).toBe('40:00')
    expect(div.querySelector('.run-sum')!.textContent).not.toMatch(/ od /)
    expect(store.setPlanDone).not.toHaveBeenCalled()
    await act(async () => { btn(/^Zaključi$/)!.click() })
    await act(async () => { sheetBtn('Zaključi').click() })
    await flush()
    expect(store.setPlanDone).toHaveBeenCalledWith('r1', true, null, 65)
  })
})
