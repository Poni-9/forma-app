// v3.51 PLANER-PLAN (domena in shramba): premor »Ta teden …«, razbremenilni teden, lastni treningi ob ponovni sestavi,
// test FTP po premoru, razlaga tedna, cikel brez cilja, izvozi, moč pred tekmo, trenažer, neznana vrsta tekme.
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach } from 'vitest'

// shramba: danes je sreda, 21. 10. 2026 (samo Date — fake-indexeddb rabi prave časovnike); domena dobi `today` izrecno
vi.hoisted(() => { vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date('2026-10-21T10:00:00')) })
const u = vi.hoisted(() => ({ undo: null as null | (() => unknown), msg: '' }))
vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
vi.mock('../src/ui/Confirm', () => ({ undoToast: (msg: string, fn: () => unknown) => { u.msg = msg; u.undo = fn }, useHidden: () => new Set() }))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { buildWeek, planHours, weekContext, weekBikeMinutes, cycleMacro, strengthPlanText, STRENGTH_SPEC, FRANJA_2027 } from '../src/domain/training/planner'
import { pauseify, pauseBuilt, pauseLine, pauseShort, pauseDays, pauseWeeks, ownDay, OWN_WHY, PAUSE_TITLE, BACK_TITLE_PAUSE, type WeekPause } from '../src/domain/training/pause'
import { raceMinutes, raceTypeOf } from '../src/domain/training/season'
import { weekText } from '../src/domain/training/share'
import { icsCount, weekToIcs } from '../src/domain/training/ics'
import { addDays, estimateTss, fmtDur, STRENGTH_TSS_H } from '../src/domain/training/load'
import type { Activity, PlanDay, Profile, Race } from '../src/domain/types'

const NOW = '2026-10-21T08:00:00.000Z'
const T = '2026-10-21'                         // sreda; teden od 19. 10.
const W0 = '2026-10-19', W1 = '2026-10-26'
/** kolesar s Franjo, 9 h, moč doma 2×, načrt od 31. 8. */
const P = (o: Partial<Profile> = {}): Profile => ({
  name: 'B', sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, ftpDate: '2026-09-20', maxHr: 195, restHr: 48, lthr: 184, level: 3,
  gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, hoursPerWeek: 9, hoursMode: 'own',
  strength: { on: true, equipment: 'home' }, strengthDays: 2, goal: 'dirka', deficit: 400, neat: 1.4, proteinGkg: 1.8,
  event: { ...FRANJA_2027 }, races: [], cycleStart: '2026-08-31', onboardingDone: true, createdAt: NOW, updatedAt: NOW, ...o,
} as Profile)
const ride = (date: string, min: number): Activity => ({ id: `a${date}-${min}`, source: 'manual', sport: 'kolo', date, name: 'x', durationMin: min, tss: Math.round(min * 0.7), aiEligible: true, geoRetain: true, createdAt: NOW, updatedAt: NOW } as Activity)
const weekly = (from: string, to: string, hrs: number): Activity[] => {
  const out: Activity[] = []
  for (let ws = from; ws <= to; ws = addDays(ws, 7)) for (const k of [1, 3, 5]) out.push(ride(addDays(ws, k), Math.round((hrs * 60) / 3)))
  return out
}
const ACTS = weekly('2026-08-31', '2026-10-12', 8)
const build = (p: Profile, ws: string, o: { acts?: Activity[]; notBefore?: string; today?: string; done?: { date: string; kind: PlanDay['kind'] }[] } = {}) =>
  buildWeek({ profile: p, activities: o.acts ?? ACTS, weekStart: ws, notBefore: o.notBefore ?? (ws < T ? T : ws), today: o.today ?? T, done: o.done })
const bikeNoRace = (xs: readonly PlanDay[]) => weekBikeMinutes(xs.filter(d => d.role !== 'dirka' && !d.raceId))
/** prvi teden od `from` (12 tednov naprej), ki ustreza pogoju */
const findWeek = (p: Profile, ok: (c: ReturnType<typeof weekContext>) => boolean, from = W1): string => {
  for (let ws = from, k = 0; k < 30; ws = addDays(ws, 7), k++) if (ok(weekContext(p, ws))) return ws
  throw new Error('ni tedna')
}

describe('B02 razbremenilni teden pri veliko urah', () => {
  const p = P({ hoursPerWeek: 15 })
  const acts = weekly('2026-08-31', '2026-10-12', 15)
  it('brez testa: sestavljeno ≥ 90 % ur tedna (prej 6 h ob 8 h)', () => {
    const ws = findWeek(p, c => c.recovery && !c.test && c.phase !== 'prehod')
    const w = build(p, ws, { acts })
    const h = planHours(p, acts, ws, T).hours
    expect(h).toBeGreaterThanOrEqual(6.5)
    expect(weekBikeMinutes(w)).toBeGreaterThanOrEqual(Math.round(h * 60 * 0.9))
  })
  it('s testom: ≥ 80 % ur tedna (prej 5 h ob 8 h)', () => {
    const ws = findWeek(p, c => c.recovery && c.test)
    const w = build(p, ws, { acts })
    const h = planHours(p, acts, ws, T).hours
    expect(w.some(d => d.kind === 'test')).toBe(true)
    expect(weekBikeMinutes(w)).toBeGreaterThanOrEqual(Math.round(h * 60 * 0.8))
  })
  it('malo ur ostane, kot je bilo (5 h razbremenilni: torek in četrtek do 60 min)', () => {
    const p5 = P({ hoursPerWeek: 7 })
    const ws = findWeek(p5, c => c.recovery && !c.test && c.phase !== 'prehod')
    const w = build(p5, ws, { acts: weekly('2026-08-31', '2026-10-12', 7) })
    expect(w.filter(d => d.kind === 'kolo' && (d.date === addDays(ws, 1) || d.date === addDays(ws, 3))).every(d => d.durationMin <= 60)).toBe(true)
  })
})

describe('B18 razlaga tedna z urami sestavljenega tedna', () => {
  it('teden s tekmo B: »treningi X + tekma« = minute na kolesu brez tekme', () => {
    const race: Race = { id: 'r1', name: 'Kronometer Vodice', date: '2026-10-30', prio: 'B', type: 'kronometer', distanceKm: 18 }
    const w = build(P({ races: [race] }), W1)
    const why = w.find(d => d.why && /teden bloka|Osnova|Gradnja/.test(d.why))?.why ?? ''
    expect(why).toContain(`treningi ${fmtDur(bikeNoRace(w))} + tekma`)
  })
  it('navaden teden: ure v razlagi so ure tedna (ne formula)', () => {
    const w = build(P(), W1)
    const why = w.find(d => d.why && /teden bloka/.test(d.why))!.why!
    expect(why).toContain(`· ${fmtDur(weekBikeMinutes(w))}.`)
  })
})

describe('B09 B10 B16 kolesar brez cilja (novinec)', () => {
  const nov = P({ level: 1, hoursPerWeek: 4, event: null, races: [], goal: 'forma', cycleStart: W0, ftp: null, ftpDate: null, lthr: null, maxHr: null, strength: { on: false, equipment: 'none' } as Profile['strength'] })
  it('B09 lahek začetek ne obljublja »4. tednu« in brez cilja ne »za tekme«', () => {
    const w = build(nov, W0, { notBefore: T, acts: [] })
    const all = w.map(d => d.why || '').join(' ')
    expect(all).toMatch(/Lahek začetek sezone/)
    expect(all).not.toMatch(/4\. tednu/)
    expect(all).not.toMatch(/tekme/)
  })
  it('B10 po treh lahkih tednih ni takoj razbremenilnega tedna — prvi teden bloka s testom (četrtek)', () => {
    const c = weekContext(nov, '2026-11-09')
    expect(c.easy).toBe(0)
    expect(c.recovery).toBe(false)
    expect(c.test).toBe(true)
    const w = build(nov, '2026-11-09', { today: '2026-11-09', acts: [] })
    expect(w.find(d => d.kind === 'test')?.date).toBe('2026-11-12')
    // razbremenilni pride po bloku (3 tedne kasneje)
    expect(weekContext(nov, '2026-11-30').recovery).toBe(true)
  })
  it('B16 cikel brez cilja: 12 tednov naprej za »Sezona po tednih«', () => {
    const m = cycleMacro(nov, [], T)
    expect(m).toHaveLength(12)
    expect(m[0]!.weekStart).toBe(W0)
    expect(cycleMacro(P(), [], T)).toEqual([])              // s ciljem je sezona do cilja (plannedMacro)
  })
})

describe('B06 test FTP v tednu premora', () => {
  it('naslednji teden po premoru ima test (prej šele čez 8 tednov)', () => {
    const p0 = P()
    const wt = findWeek(p0, c => c.test && c.phase !== 'prehod')
    const p = P({ weekPause: { from: wt, to: addDays(wt, 6), mode: 'kolo' } })
    const next = addDays(wt, 7)
    const acts = weekly('2026-08-31', addDays(wt, -7), 8)
    expect(weekContext(p, next).test).toBe(false)
    const w = build(p, next, { today: wt, acts })
    expect(w.some(d => d.kind === 'test')).toBe(true)
    expect(w.map(d => d.why || '').join(' ')).toContain('Test FTP je bil v tednu premora')
    // test je bil opravljen pred premorom: ne znova
    const w2 = build(p, next, { today: wt, acts, done: [{ date: addDays(wt, 3), kind: 'test' }] })
    expect(w2.some(d => d.kind === 'test')).toBe(false)
  })
})

describe('B07 premor čez teden s tekmo', () => {
  it('tekma ostane in z njo predaktivacija dan prej', () => {
    const race: Race = { id: 'r1', name: 'Kronometer Vodice', date: '2026-10-23', prio: 'B', type: 'kronometer', distanceKm: 18 }
    const p = P({ races: [race] })
    const plan = build(p, W0)
    expect(plan.some(d => d.date === '2026-10-22' && /^Predaktivacija/.test(d.title))).toBe(true)
    const w: WeekPause = { from: T, to: '2026-10-25', mode: 'vse' }
    const out = pauseify(plan, w, T, NOW)
    expect(out.some(d => d.date === '2026-10-22')).toBe(false)                // dan ostane, kot je
    expect(out.filter(d => d.date === '2026-10-24').every(d => d.kind === 'pocitek')).toBe(true)
    // nova sestava med premorom: isto
    const built = build({ ...p, weekPause: w }, W0)
    expect(built.some(d => d.date === '2026-10-22' && /^Predaktivacija/.test(d.title))).toBe(true)
  })
})

describe('B32 premor samo en dan', () => {
  it('ne zavre naslednjega tedna', () => {
    const p = P(), sun = '2026-10-25'
    const pp = P({ weekPause: { from: sun, to: sun, mode: 'vse' } })
    expect(planHours(pp, ACTS, W1, T).hours).toBe(planHours(p, ACTS, W1, T).hours)
    expect(pauseWeeks(pp).size).toBe(0)
  })
})

describe('B44 preklic dvotedenskega premora po 6 dneh', () => {
  it('prvi dan nazaj lahek (prej VO2max takoj), drugi po načrtu', () => {
    const w: WeekPause = { from: '2026-10-14', to: '2026-10-19', mode: 'vse' }
    expect(pauseDays(w)).toBe(6)
    const raw = build(P(), W0, { notBefore: '2026-10-20', today: '2026-10-20' })
    expect(raw.some(d => d.date === '2026-10-20' && d.role === 'kljucna')).toBe(true)
    const out = pauseBuilt(raw, { weekPause: w }, NOW)
    const tue = out.filter(d => d.date === '2026-10-20' && d.kind === 'kolo')
    expect(tue.some(d => d.role === 'kljucna')).toBe(false)
    expect(tue[0]!.title).toBe(BACK_TITLE_PAUSE)
    expect(tue[0]!.desc).toMatch(/^Prvi dan po premoru/)
    expect(out.filter(d => d.date === '2026-10-22' && d.kind === 'kolo')).toEqual(raw.filter(d => d.date === '2026-10-22' && d.kind === 'kolo'))
  })
})

describe('B45 B20 besedilo premora', () => {
  it('dvotedenski premor ni »Ta teden: …«', () => {
    expect(pauseLine({ from: T, to: '2026-11-01', mode: 'kolo' }, T)).toBe('Ta in naslednji teden: premor (brez kolesa)')
    expect(pauseLine({ from: T, to: '2026-10-25', mode: 'vse' }, T)).toBe('Ta teden: premor do nedelje')
    expect(pauseShort({ from: T, to: '2026-11-01', mode: 'vse' }, T)).toBe('premor do nedelje, 1. 11.')
  })
})

describe('B29 B30 deli in koledar v tednu premora', () => {
  const w: WeekPause = { from: W0, to: '2026-10-25', mode: 'vse' }
  const plan = pauseify(build(P(), W0, { notBefore: W0, today: W0 }), w, W0, NOW)
  it('deli: »premor«, ne »počitek« in »Skupaj —«', () => {
    const t = weekText(plan, W0)
    expect(t).toContain('pon 19. 10.: počitek')                               // počitek iz načrta ostane počitek
    expect(t).toContain('tor 20. 10.: premor')
    expect(t).not.toContain('Skupaj —')
    expect(t).toContain('Skupaj: premor — brez treningov.')
  })
  it('koledar: brez dogodkov ni datoteke', () => {
    expect(plan.every(d => d.title.startsWith(PAUSE_TITLE))).toBe(true)
    expect(icsCount(plan)).toBe(0)
    expect(weekToIcs(plan)).not.toContain('VEVENT')
  })
})

describe('B34 B35 B15 moč', () => {
  it('B34 tekma B v petek: v torek ne noge (samo jedro)', () => {
    const race: Race = { id: 'r1', name: 'Kronometer Vodice', date: '2026-10-30', prio: 'B', type: 'kronometer', distanceKm: 18 }
    const w = build(P({ races: [race] }), W1)
    const tue = w.filter(d => d.date === '2026-10-27' && d.kind === 'moc')
    expect(tue.every(d => !/noge/i.test(d.title))).toBe(true)
    // brez tekme so noge v torek
    expect(build(P(), W1).some(d => d.date === '2026-10-27' && d.kind === 'moc' && /noge/i.test(d.title))).toBe(true)
  })
  it('B35 opis specifične faze pove, da je moč samo jedro', () => {
    const ws = findWeek(P(), c => c.phase === 'specificno', '2027-03-01')
    expect(weekContext(P(), ws).phaseDesc).toContain(STRENGTH_SPEC)
    expect(weekContext(P({ strength: { on: false, equipment: 'none' } as Profile['strength'] }), ws).phaseDesc).not.toContain(STRENGTH_SPEC)
  })
  it('B15 besedilo Nastavitev = dnevi moči v načrtu', () => {
    const w = build(P(), W1)
    const moc = w.filter(d => d.kind === 'moc').map(d => `${new Date(d.date + 'T12:00:00Z').getUTCDay()}:${d.title}`)
    expect(moc).toEqual(['2:Moč — noge in jedro', '5:Moč — jedro'])
    expect(strengthPlanText(false, 2)).toBe('Moč doma: noge + jedro v torek (po VO2max) in jedro v petek, 20–30 min.')
    const g = build(P({ strength: { on: true, equipment: 'gym' } as Profile['strength'] }), W1).filter(d => d.kind === 'moc').map(d => new Date(d.date + 'T12:00:00Z').getUTCDay())
    expect(g).toEqual([2, 4])
    expect(strengthPlanText(true, 2)).toMatch(/torek noge težko .*četrtek enonožne/)
  })
  it('B36 TSS moči enak v načrtu, ročnem vnosu in »Dodaj trening«', () => {
    const w = build(P(), W1)
    const m = w.find(d => d.kind === 'moc' && d.durationMin === 30)!
    expect(m.tssTarget).toBe(Math.round(30 * STRENGTH_TSS_H / 60))
    expect(estimateTss({ sport: 'moc', durationMin: 30 } as Activity, P())).toBe(m.tssTarget)
  })
})

describe('B37 B38', () => {
  it('B37 neznana vrsta tekme ne sesuje sestave', () => {
    const r = { id: 'k', name: 'Kriterij Kranj', date: '2026-10-24', prio: 'C', type: 'kriterij' } as unknown as Race
    expect(raceTypeOf(r)).toBe('sprint')
    expect(Number.isFinite(raceMinutes(r))).toBe(true)
    expect(() => build(P({ races: [r] }), W0)).not.toThrow()
  })
  it('B38 samo trenažer: dolga vožnja največ 2 h 30 min', () => {
    const p = P({ hoursPerWeek: 11, gear: { bikeOutdoor: false, trainer: true, noBike: false, powerMeter: false } as Profile['gear'] })
    const acts = weekly('2026-08-31', '2026-10-12', 11)
    const out = build({ ...p, gear: { ...p.gear, bikeOutdoor: true } }, W1, { acts })
    const long = out.find(d => d.role === 'dolga')!
    expect(long.durationMin).toBeGreaterThan(150)
    const ind = build(p, W1, { acts }).find(d => d.role === 'dolga')!
    expect(ind.durationMin).toBeLessThanOrEqual(150)
    expect(ind.desc).toMatch(/Na trenažerju je .* enakovredno/)
  })
})

/* ---------- shramba ---------- */
const prof = {
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, ftpDate: '2026-09-20', maxHr: 195, restHr: 48, lthr: 184, level: 3,
  gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, hoursPerWeek: 9, hoursMode: 'own',
  strength: { on: true, equipment: 'home' }, strengthDays: 2, goal: 'dirka', event: { ...FRANJA_2027 }, races: [], cycleStart: '2026-08-31',
  onboardingDone: true, createdAt: NOW, updatedAt: NOW,
} as unknown as Profile
const plan = async () => (await repo.allPlan()).sort((a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id))
const at = async (date: string) => (await plan()).filter(d => d.date === date)
async function dayOn(date: string, h: number) { vi.setSystemTime(new Date(`${date}T${String(h).padStart(2, '0')}:00:00`)); await store.reloadAll() }
/** »Dodaj trening« (kot EditDay): nov zapis na ta dan */
const own = (date: string, title: string, why: string | null = null): PlanDay => ({ id: `own-${date}-${title}`, date, kind: 'kolo', title, desc: 'Enakomerno v Z2.', durationMin: 60, zone: 'Z2', tssTarget: 40, role: null, why, source: 'rules', createdAt: NOW, updatedAt: NOW, done: null })

describe('shramba', () => {
  beforeEach(async () => {
    await dayOn(T, 10)
    await repo.wipeAll(); localStorage.clear(); await store.reloadAll()
    await store.updateProfile({ ...prof, weekPause: null, sick: null })
    await store.ensureWeeks()
    u.undo = null
  })

  it('B01 »Še naslednji teden« ob premoru od prejšnjega tedna: do nedelje, 1. 11. (prej tiho 27. 10.)', async () => {
    await dayOn('2026-10-14', 10)
    await repo.wipeAll(); await store.reloadAll(); await store.updateProfile({ ...prof, weekPause: null }); await store.ensureWeeks()
    await store.setWeekPause('vse', { twoWeeks: true })
    expect((await repo.loadProfile()).weekPause).toMatchObject({ from: '2026-10-14', to: '2026-10-25' })
    await dayOn(T, 10)
    await store.ensureWeeks()
    const w = await store.setWeekPause('kolo', { twoWeeks: true })
    expect(w).toMatchObject({ from: T, to: '2026-11-01', since: '2026-10-14', mode: 'kolo' })
    for (const d of ['2026-10-28', '2026-10-31', '2026-11-01']) expect((await at(d)).some(x => x.kind === 'kolo' || x.kind === 'test')).toBe(false)
    expect(u.msg).toMatch(/^Ta in naslednji teden: premor \(brez kolesa\)\./)
    // prvi del šteje za premor (ure, prehod po premoru): 19 dni
    expect(pauseDays(w)).toBe(19)
    expect([...pauseWeeks({ weekPause: w })]).toEqual(['2026-10-12', W0, W1])
  })

  it('B03 lastni trening ostane ob spremembi tekem, »sestavi znova« (rebuildFromToday) in moči', async () => {
    const thu = '2026-10-22', fri = '2026-10-23'
    await store.savePlanDay(own(thu, 'Moj trening četrtek'))
    await store.savePlanDay(own(fri, 'Z2 vzdržljivost', OWN_WHY))        // privzeti naslov »Dodaj trening« z oznako
    await store.saveRaces([{ id: 'r9', name: 'VN Vodice', date: '2026-11-08', prio: 'C' }])
    expect((await at(thu)).some(d => d.title === 'Moj trening četrtek')).toBe(true)
    expect((await at(fri)).some(d => d.id === `own-${fri}-Z2 vzdržljivost`)).toBe(true)
    await store.rebuildFromToday()
    await store.setStrength({ equipment: 'gym' })
    expect((await at(thu)).some(d => d.title === 'Moj trening četrtek')).toBe(true)
    expect((await at(fri)).some(d => d.id === `own-${fri}-Z2 vzdržljivost`)).toBe(true)
    // na dnevu lastnega treninga ni še ene sestavljene vožnje
    expect((await at(thu)).filter(d => d.kind === 'kolo')).toHaveLength(1)
  })

  it('B03 keepOwn: sestavljeni dnevi iz načrta niso »lastni« (sestavi znova jih zamenja)', async () => {
    const s = store.getState()
    const built = buildWeek({ profile: s.profile, activities: s.activities, weekStart: W0, notBefore: T, today: T })
    const out = store.keepOwn(built)
    expect(out.map(d => d.id).sort()).toEqual(built.map(d => d.id).sort())
    expect(s.plan.filter(d => d.date >= T && d.date <= '2026-10-25').some(d => ownDay(d, s.profile, new Set()))).toBe(true)  // brez reference bi bili
  })

  it('B19 premor + lasten trening + bolan danes + »Razveljavi« → lasten trening ostane', async () => {
    await store.setWeekPause('vse')
    const fri = '2026-10-23'
    await store.savePlanDay(own(fri, 'Moj trening petek'))
    vi.setSystemTime(new Date('2026-10-21T10:05:00'))
    await store.setSick(1)
    expect(u.undo).toBeTruthy()
    await u.undo!()
    expect((await at(fri)).some(d => d.title === 'Moj trening petek')).toBe(true)
  })

  it('B19 »Spet zdrav« ne pobriše lastnega treninga v premoru', async () => {
    await store.setWeekPause('vse')
    const sat = '2026-10-24'
    await store.savePlanDay(own(sat, 'Moj trening sobota'))
    vi.setSystemTime(new Date('2026-10-21T10:05:00'))
    await store.setSick(5)
    await dayOn('2026-10-23', 10)
    await store.endSick()
    expect((await at(sat)).some(d => d.title === 'Moj trening sobota')).toBe(true)
  })

  it('B44 preklic dvotedenskega premora po 6 dneh: danes ni ključnega treninga', async () => {
    await dayOn('2026-10-14', 10)
    await repo.wipeAll(); await store.reloadAll(); await store.updateProfile({ ...prof, weekPause: null }); await store.ensureWeeks()
    await store.setWeekPause('vse', { twoWeeks: true })
    await dayOn('2026-10-20', 10)
    await store.endWeekPause()
    expect((await repo.loadProfile()).weekPause).toMatchObject({ from: '2026-10-14', to: '2026-10-19' })
    const tue = await at('2026-10-20')
    expect(tue.some(d => d.kind === 'kolo')).toBe(true)
    expect(tue.some(d => d.role === 'kljucna')).toBe(false)
  })
})
