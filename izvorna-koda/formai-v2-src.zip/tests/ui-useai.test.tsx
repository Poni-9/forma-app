// Prvi AI trenutek je en tok: prijava → privolitev → odgovor (regresija: list se je odpiral v nedogled,
// neprijavljen uporabnik je dobil Googlovo okno dvakrat, klic se ni nikoli izvedel).
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), signIns: 0 }))
const emit = () => S.subs.forEach(f => f())
vi.mock('@/state/store', () => ({
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  signIn: vi.fn(async () => { S.signIns++; S.state = { ...S.state, user: { uid: 'u1' } }; emit(); return { uid: 'u1' } }),
  grantAiConsent: vi.fn(async () => { S.state = { ...S.state, profile: { ...S.state.profile, aiConsentAt: 'zdaj' } }; emit() }),
  toast: vi.fn(),
}))
vi.mock('@/screens/Privolitev', () => ({
  PrivolitevSheet: ({ open, onAccept, onClose }: { open: boolean; onAccept: () => void; onClose: () => void }) => open
    ? <><button id="accept" onClick={() => onAccept()}>accept</button><button id="decline" onClick={() => onClose()}>decline</button></>
    : null,
}))
vi.mock('@/domain/ai/actions', () => {
  class AiError extends Error { kind: string; constructor(k: string, m: string) { super(m); this.kind = k } }
  return { AiError, aiErrorText: (e: Error) => String(e?.message), isConsentError: (e: unknown) => e instanceof AiError && e.kind === 'consent', isAuthError: () => false }
})

import { useAi } from '@/ui/useAi'
import { AiError } from '@/domain/ai/actions'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

/** Kot prava AI dejanja: brez privolitve v profilu (ob klicu!) vržejo napako. */
const makeFn = () => vi.fn(async () => { if (!S.state.profile.aiConsentAt) throw new (AiError as any)('consent', 'privolitev'); return 42 })

function Harness({ fn, out }: { fn: () => Promise<number>; out: unknown[] }) {
  const ai = useAi()
  return <><button id="go" onClick={() => { void ai.run(fn).then(v => { out.push(v) }) }}>go</button>{ai.sheet}</>
}

let div: HTMLDivElement, root: Root
const flush = async () => { for (let i = 0; i < 6; i++) await act(async () => { await Promise.resolve() }) }
const click = async (sel: string) => { await act(async () => { (div.querySelector(sel) as HTMLButtonElement).click() }); await flush() }
async function mount(fn: () => Promise<number>, out: unknown[]) {
  div = document.createElement('div'); document.body.appendChild(div)
  root = createRoot(div)
  await act(async () => { root.render(<Harness fn={fn} out={out} />) })
}

beforeEach(() => { S.signIns = 0; S.subs.clear() })
afterEach(async () => { await act(async () => root.unmount()); div.remove() })

describe('useAi — prvi AI trenutek', () => {
  it('prijavljen, brez privolitve: potrditev takoj izvede klic (enkrat) in vrne odgovor klicatelju', async () => {
    S.state = { user: { uid: 'u1' }, profile: { aiConsentAt: null } }
    const fn = makeFn(), out: unknown[] = []
    await mount(fn, out)
    await click('#go')
    expect(div.querySelector('#accept')).not.toBeNull()
    expect(fn).not.toHaveBeenCalled()
    await click('#accept')
    expect(fn).toHaveBeenCalledTimes(1)
    expect(div.querySelector('#accept')).toBeNull()        // list se ne odpre znova
    expect(out).toEqual([42])                              // klicatelj dobi odgovor (en tok)
  })

  it('neprijavljen: ena prijava, nato privolitev in odgovor — brez drugega Googlovega okna', async () => {
    S.state = { user: null, profile: { aiConsentAt: null } }
    const fn = makeFn(), out: unknown[] = []
    await mount(fn, out)
    await click('#go')
    expect(S.signIns).toBe(1)
    await click('#accept')
    expect(S.signIns).toBe(1)
    expect(fn).toHaveBeenCalledTimes(1)
    expect(div.querySelector('#accept')).toBeNull()
    expect(out).toEqual([42])
  })

  it('»Ne zdaj«: klic se ne izvede, klicatelj dobi undefined', async () => {
    S.state = { user: { uid: 'u1' }, profile: { aiConsentAt: null } }
    const fn = makeFn(), out: unknown[] = []
    await mount(fn, out)
    await click('#go')
    await click('#decline')
    expect(fn).not.toHaveBeenCalled()
    expect(out).toEqual([undefined])
  })

  it('privolitev že dana: brez lista, naravnost klic', async () => {
    S.state = { user: { uid: 'u1' }, profile: { aiConsentAt: 'prej' } }
    const fn = makeFn(), out: unknown[] = []
    await mount(fn, out)
    await click('#go')
    expect(div.querySelector('#accept')).toBeNull()
    expect(fn).toHaveBeenCalledTimes(1)
    expect(out).toEqual([42])
  })
})
