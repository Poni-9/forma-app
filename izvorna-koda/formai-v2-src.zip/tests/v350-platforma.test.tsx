// v3.50 PLATFORMA (UI): obvestila (role=alert, ×, Esc), meja napake, pripomba takoj, fokus po prehodu, trak tedna,
// stara povezava na vadbo, namestitev v Nastavitvah, skrajšan oblak, oznake v uvodu.
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>() }))
const emit = () => S.subs.forEach(f => f())
const store = vi.hoisted(() => ({ toast: vi.fn(), dismissToast: vi.fn(), setPlanDone: vi.fn(async () => {}), addActivities: vi.fn(async () => ({ added: 1, dupes: 0, upgraded: 0 })) }))
vi.mock('@/state/store', () => ({
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  ...store,
  newRouteFor: vi.fn(), routePace: () => ({ k: 1, adj: { n: 0, adj: 1 } }),
}))
const shot = vi.hoisted(() => ({ resolve: null as null | ((s: string | null) => void), calls: 0 }))
vi.mock('@/data/feedback', async (orig) => ({
  ...(await orig<typeof import('@/data/feedback')>()),
  captureScreen: () => { shot.calls++; return new Promise<string | null>(r => { shot.resolve = r }) },
}))

import { Toasts } from '@/ui/Toasts'
import { ErrorBoundary } from '@/app/ErrorBoundary'
import { startFeedback } from '@/ui/HelpSheet'
import { overlayState, closeFeedback } from '@/ui/overlays'
import { focusScreen } from '@/app/router'
import { rovingTab, rovingKey } from '@/ui/roving'
import { Vadba } from '@/screens/Vadba'
import { InstallRow, CloudTrimNote } from '@/ui/PlatformRows'
import type { PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
window.scrollTo = (() => undefined) as typeof window.scrollTo

const today = new Date().toISOString().slice(0, 10)
const profile = { sex: 'm', age: 35, heightCm: 180, weightKg: 75, ftp: 250, gear: { bikeOutdoor: true, trainer: false, noBike: false }, strength: { on: false, equipment: 'none' }, onboardingDone: true, createdAt: 'x', updatedAt: 'x' } as unknown as Profile
const ride: PlanDay = { id: 'd1', date: today, kind: 'kolo', title: 'Z2 vožnja', desc: 'Enakomerno v Z2.', durationMin: 60, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: 'x', updatedAt: 'x' }
const base = (o: Record<string, unknown> = {}) => ({ ready: true, today, plan: [ride], activities: [], recentMeals: [], weather: null, routeLib: null, routesBusy: false, settings: { lang: 'sl', intervals: null }, toast: null, toasts: [], profile, user: null, sync: { state: 'off' }, ...o })

let div: HTMLDivElement, root: Root | null = null
async function mount(el: React.ReactNode) {
  div = document.createElement('div'); document.body.appendChild(div)
  root = createRoot(div)
  await act(async () => { root!.render(el) })
}
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(b.textContent || '') || re.test(b.getAttribute('aria-label') || '')) as HTMLButtonElement | undefined
beforeEach(() => { S.state = base(); S.subs.clear(); store.toast.mockClear(); store.dismissToast.mockClear() })
afterEach(async () => { if (root) { await act(async () => root!.unmount()); root = null } document.body.innerHTML = '' })

describe('G30, G31 — obvestila: napaka v role="alert", gumb ×, Esc, ikona', () => {
  it('napaka je v alert z gumbom »Zapri obvestilo« in ikono; uspeh v status; Esc zapre zadnje', async () => {
    S.state = base({ toasts: [{ id: 1, msg: 'Vreme ni dosegljivo.', kind: 'err' }, { id: 2, msg: 'Teža zabeležena.', kind: 'ok' }] })
    await mount(<Toasts />)
    const alert = document.querySelector('[role="alert"]')!
    expect(alert.textContent).toContain('Vreme ni dosegljivo.')
    expect(alert.querySelector('[data-kind="err"] .toast-ico')!.textContent).toBe('✕')
    expect(document.querySelector('[role="status"]')!.textContent).toContain('Teža zabeležena.')
    expect(document.querySelector('[role="status"] [data-kind="ok"] .toast-ico')!.textContent).toBe('✓')
    await act(async () => { btn(/Zapri obvestilo/)!.click() })
    expect(store.dismissToast).toHaveBeenCalledWith(1)
    await act(async () => { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' })) })
    expect(store.dismissToast).toHaveBeenLastCalledWith()
  })
  it('gumb v obvestilu izvede dejanje in obvestilo zapre', async () => {
    const run = vi.fn()
    S.state = base({ toasts: [{ id: 5, msg: 'Nova različica je pripravljena.', kind: 'info', action: { label: 'Osveži', run } }] })
    await mount(<Toasts />)
    await act(async () => { btn(/^Osveži$/)!.click() })
    expect(run).toHaveBeenCalledTimes(1); expect(store.dismissToast).toHaveBeenCalledWith(5)
  })
})

describe('G24 — meja napake: po dveh neuspelih poskusih »Osveži aplikacijo« in »Na Danes«', () => {
  it('trajna napaka ne ponuja samo »Poskusi znova«', async () => {
    const err = console.error; console.error = () => undefined
    location.hash = '#/plan'
    function Bad(): never { throw new Error('Cannot read properties of undefined (reading \'replace\')') }
    await mount(<ErrorBoundary screen><Bad /></ErrorBoundary>)
    expect(btn(/Poskusi znova/)).toBeTruthy(); expect(btn(/Osveži aplikacijo/)).toBeUndefined()
    await act(async () => { btn(/Poskusi znova/)!.click() })
    expect(btn(/Osveži aplikacijo/)).toBeUndefined()
    await act(async () => { btn(/Poskusi znova/)!.click() })
    expect(btn(/Osveži aplikacijo/)).toBeTruthy()
    expect(btn(/Na Danes/)).toBeTruthy()
    expect(document.body.textContent).toContain('Napaka se ponavlja.')
    console.error = err
  })
})

describe('G04 — pripomba: list takoj, posnetek v ozadju', () => {
  it('openFeedback je klican takoj (prej šele po zajemu 6,7–8 s); posnetek pride pozneje', async () => {
    location.hash = '#/prehrana'
    shot.calls = 0
    const p = startFeedback()
    expect(overlayState().fb).toEqual({ shot: null, route: 'prehrana', capturing: true })
    for (let i = 0; i < 20 && !shot.resolve; i++) await new Promise(r => setTimeout(r, 5))
    expect(shot.calls).toBe(1)
    shot.resolve!('data:image/jpeg;base64,AAAA')
    await p
    expect(overlayState().fb).toEqual({ shot: 'data:image/jpeg;base64,AAAA', route: 'prehrana', capturing: false })
    closeFeedback()
  })
})

describe('G04 — list pripombe med zajemom', () => {
  it('»Zajemam posnetek zaslona …« → posnetek brez vmesnega »ni bilo mogoče«; neuspeh pove, da lahko dodaš sliko', async () => {
    const { FeedbackSheet } = await import('@/ui/FeedbackSheet')
    await mount(<FeedbackSheet shot={null} route="danes" capturing />)
    expect(document.body.textContent).toContain('Zajemam posnetek zaslona …')
    await act(async () => { root!.render(<FeedbackSheet shot="data:image/jpeg;base64,AAAA" route="danes" capturing={false} />) })
    expect(document.querySelector('.fb-shot img')).toBeTruthy()
    expect(document.body.textContent).not.toContain('Posnetka ni bilo mogoče zajeti')
    await act(async () => { root!.render(<FeedbackSheet shot={null} route="danes" capturing={false} key="b" />) })
    expect(document.body.textContent).toContain('Posnetka ni bilo mogoče zajeti — lahko dodaš sliko.')
  })
})

describe('G09 — fokus na naslov novega zaslona', () => {
  it('h1 dobi fokus (tabindex -1); ne, če uporabnik tipka', () => {
    document.body.innerHTML = '<nav><button id="tab">Plan</button></nav><main class="screen"><header class="head"><h1>Ta teden</h1></header></main><input id="q" />'
    ;(document.getElementById('tab') as HTMLButtonElement).focus()
    focusScreen()
    const h = document.querySelector('main h1') as HTMLElement
    expect(document.activeElement).toBe(h)
    expect(h.getAttribute('tabindex')).toBe('-1')
    ;(document.getElementById('q') as HTMLInputElement).focus()
    focusScreen()
    expect(document.activeElement!.id).toBe('q')
  })
})

describe('G34 — trak tedna: en postanek Tab, puščice', () => {
  it('samo danes ima tabIndex 0; → premakne fokus in postanek', async () => {
    const days = ['pon', 'tor', 'sre', 'čet', 'pet', 'sob', 'ned']
    await mount(<div className="week" role="group" onKeyDown={rovingKey}>{days.map((d, i) => <button key={d} type="button" {...rovingTab(i, 2)}>{d}</button>)}</div>)
    const bs = [...div.querySelectorAll('button')]
    expect(bs.filter(b => b.tabIndex === 0).map(b => b.textContent)).toEqual(['sre'])
    bs[2]!.focus()
    await act(async () => { bs[2]!.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true })) })
    expect(document.activeElement).toBe(bs[3])
    expect(bs.filter(b => b.tabIndex === 0).map(b => b.textContent)).toEqual(['čet'])
    await act(async () => { bs[3]!.dispatchEvent(new KeyboardEvent('keydown', { key: 'End', bubbles: true })) })
    expect(document.activeElement).toBe(bs[6])
  })
})

describe('G27 — stara povezava na vadbo', () => {
  it('#/vadba?id=neobstoječ: »Te vadbe ni več v načrtu« in »Današnji trening« (prej tiho današnji ali »Danes ni treninga«)', async () => {
    location.hash = '#/vadba?id=ni-takega'
    await mount(<Vadba />)
    expect(document.querySelector('h1')!.textContent).toBe('Te vadbe ni več v načrtu')
    expect(btn(/Današnji trening/)).toBeTruthy()
    expect(btn(/Odpri plan/)).toBeTruthy()
  })
  it('brez treninga danes: »Danes ni treninga« kot naslov h1', async () => {
    S.state = base({ plan: [] })
    location.hash = '#/vadba'
    await mount(<Vadba />)
    expect(document.querySelector('h1')!.textContent).toBe('Danes ni treninga')
    expect(btn(/Današnji trening/)).toBeUndefined()
  })
})

describe('G37 — uvod (hitro): oznake povezane s polji', () => {
  const lab = (t: string) => { const l = [...document.querySelectorAll('label')].find(x => x.textContent!.startsWith(t))!; return l.htmlFor ? document.getElementById(l.htmlFor) : null }
  it('Tekma, Dolžina, Ime, FTP: tap na oznako najde polje (bralnik prebere ime)', async () => {
    S.state = base({ profile: { ...profile, goal: 'dirka', event: { name: 'Maraton Franja', date: '2027-06-13' } } })
    const { Onboarding } = await import('@/screens/Onboarding')
    await mount(<Onboarding />)
    expect(lab('Tekma')?.tagName).toBe('INPUT')
    expect(lab('Dolžina')?.tagName).toBe('INPUT')
    await act(async () => { root!.unmount() }); root = null; div.remove()
    await mount(<Onboarding start="o-tebi" />)
    expect(lab('Ime')?.tagName).toBe('INPUT')
    expect(lab('FTP')?.tagName).toBe('INPUT')
  })
})

describe('G17, G23 — Nastavitve', () => {
  it('»Namesti na telefon« na telefonu v brskalniku', async () => {
    const w = window.innerWidth
    Object.defineProperty(window, 'innerWidth', { configurable: true, value: 390 })
    await mount(<InstallRow />)
    expect(btn(/Namesti na telefon/)).toBeTruthy()
    Object.defineProperty(window, 'innerWidth', { configurable: true, value: w })
  })
  it('skrajšan oblak je povedan v Podatkih', async () => {
    S.state = base({ sync: { state: 'idle', at: 1, trimmed: { acts: 400, mealDays: 120 } } })
    await mount(<CloudTrimNote />)
    expect(div.textContent).toBe('V oblaku je zadnjih 400 vadb in 120 dni obrokov — starejše so samo na tej napravi. Za vse izvozi kopijo.')
    await act(async () => { S.state = base({ sync: { state: 'idle', at: 2, trimmed: null } }); emit() })
    expect(div.textContent).toBe('')
  })
})
