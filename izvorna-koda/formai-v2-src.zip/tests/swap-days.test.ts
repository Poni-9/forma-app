import { describe, it, expect } from 'vitest'
import { canMove, canReceive, partnerOn, swapDays, moveTargets } from '../src/domain/training/swap'
import type { PlanDay } from '../src/domain/types'

const now = '2026-10-02T08:00:00.000Z'
const d = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: 'p' + date + (o.kind || 'kolo'), date, kind: 'kolo', title: 'Z2 vzdržljivost', desc: 'lahko', durationMin: 60, zone: 'Z2', tssTarget: 42, role: 'lahka', source: 'rules', createdAt: now, updatedAt: now, ...o })
const rest = (date: string) => d(date, { kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, tssTarget: 0, role: null })
const TODAY = '2026-10-02'
const vo2 = d('2026-10-03', { title: 'VO2max 4 × 4', zone: 'Z5', durationMin: 75, tssTarget: 68, role: 'kljucna', target: { lo: 259, hi: 276 }, why: 'ključni' })
const plan = [d('2026-10-01', { done: { at: now } }), d(TODAY), vo2, rest('2026-10-04'), d('2026-10-05', { kind: 'moc', title: 'Moč — jedro', durationMin: 25, role: 'moc', exercises: [{ name: 'Deska', sets: 3, reps: '45 s' }] }), d('2026-10-05', { title: 'Dolga Z2', durationMin: 180, role: 'dolga' }), d('2026-10-06', { role: 'dirka', raceId: 'r1', title: 'Tekma' })]

describe('premik treninga na drug dan', () => {
  it('sme: prihodnji, neopravljen, ne tekma, ne počitek; cilj: ne isti dan, ne opravljen, ne tekma', () => {
    expect(canMove(vo2, TODAY)).toBe(true)
    expect(canMove(plan[0]!, TODAY)).toBe(false)      // opravljen (včeraj)
    expect(canMove(rest('2026-10-04'), TODAY)).toBe(false)
    expect(canMove(plan[6]!, TODAY)).toBe(false)      // tekma
    expect(canReceive(rest('2026-10-04'), vo2, TODAY)).toBe(true)
    expect(canReceive(plan[6]!, vo2, TODAY)).toBe(false)
    expect(canReceive(vo2, vo2, TODAY)).toBe(false)
  })
  it('partner: iste vrste, sicer glavna seja (ne moč), sicer karkoli', () => {
    expect(partnerOn(plan, vo2, '2026-10-05', TODAY)!.title).toBe('Dolga Z2')
    const moc = plan[4]!
    expect(partnerOn(plan, moc, '2026-10-04', TODAY)!.kind).toBe('pocitek')
    expect(partnerOn(plan, moc, '2026-10-03', TODAY)!.title).toBe('VO2max 4 × 4')
    expect(partnerOn(plan, vo2, '2026-10-06', TODAY)).toBeNull()
  })
  it('zamenjava: vsebina gre tja in nazaj, datum/id/tekma ostanejo; prilagoditev se pobriše', () => {
    const r = rest('2026-10-04')
    const [a, b] = swapDays({ ...vo2, adapt: { after: '2026-10-01', prev: null } }, r)
    expect(a.date).toBe('2026-10-03'); expect(a.id).toBe(vo2.id); expect(a.kind).toBe('pocitek'); expect(a.title).toBe('Počitek'); expect(a.durationMin).toBe(0); expect(a.target ?? null).toBeNull()
    expect(b.date).toBe('2026-10-04'); expect(b.id).toBe(r.id); expect(b.title).toBe('VO2max 4 × 4'); expect(b.target).toEqual({ lo: 259, hi: 276 }); expect(b.why).toBe('ključni'); expect(b.role).toBe('kljucna')
    expect(a.adapt).toBeNull(); expect(b.adapt).toBeNull()
    // dvakrat = prvotno stanje (brez časa)
    const [a2, b2] = swapDays(a, b)
    const norm = (x: PlanDay) => { const { updatedAt: _u, adapt: _a, ...rest } = x; return rest }
    expect(norm(a2)).toEqual(norm({ ...vo2 }))
    expect(norm(b2)).toEqual(norm(r))
  })
  it('cilji premika: od danes do konca obdobja, brez tekme in brez lastnega datuma', () => {
    const t = moveTargets(plan, vo2, TODAY, '2026-10-08')
    expect(t.map(x => x.date)).toEqual([TODAY, '2026-10-04', '2026-10-05'])
    expect(t[2]!.partner.title).toBe('Dolga Z2')
  })
})
