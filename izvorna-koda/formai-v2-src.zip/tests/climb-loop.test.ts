import { describe, it, expect } from 'vitest'
import { climbCandidates, pickClimbLoop, repsPerClimb, intervalStops, viaOf, stopsText } from '../src/domain/routes/climbLoop'
import { suggestRoutes, type RouteNeed } from '../src/domain/routes/match'
import { encodePolyline, type LatLon } from '../src/domain/import/polyline'
import type { Climb, RouteRec } from '../src/domain/routes/analyze'
import { dest } from '../src/domain/routes/brouter'

const home: LatLon = [46.05, 14.5]
const p = { ftp: 280, weightKg: 75 }
const need: RouteNeed = { need: 'vo2', minutes: 90, reps: 4, workMin: 4, workW: 310, lo: 300, hi: 320, label: 'VO2max ponovitve', wtxt: '300–320 W' }
/** klanec v smeri b (°) na d km od doma, dolg km, naklon g % */
const climbAt = (b: number, d: number, km: number, g: number): Climb => { const foot = dest(home, d, b), top = dest(foot, km, b); return { atKm: d, km, gainM: Math.round(km * g * 10), grade: g, foot, top } }
const ride = (id: string, climbs: Climb[], times = 3): RouteRec => ({
  id, source: 'voznja', name: id, date: '2026-09-01', km: 40, gainM: 400, rodeMin: 90, loop: true, start: home,
  poly: encodePolyline([home, ...climbs.flatMap(c => [c.foot, c.top]), home]), prof: Array.from({ length: 800 }, (_, i) => 300 + (i % 100)), climbs, hilly: 10, times,
})

describe('intervali čez več klancev', () => {
  const A = climbAt(10, 6, 1.4, 6), B = climbAt(70, 8, 1.5, 6.5), C = climbAt(130, 7, 1.3, 5.5), far = climbAt(200, 40, 1.4, 6), steep = climbAt(40, 5, 1.2, 16), short = climbAt(300, 5, 0.3, 6)
  const recs = [ride('r1', [A, B]), ride('r2', [C, far, steep, short]), ride('r3', [A], 1)]   // A v dveh vožnjah
  it('kandidati: dovolj dolgi pri ciljnih vatih, ne prestrmi, do 20 km od doma, isti klanec samo enkrat', () => {
    const c = climbCandidates(recs, need, p, home, 20)
    expect(c.map(x => x.climb)).toEqual(expect.arrayContaining([A, B, C]))
    expect(c).toHaveLength(3)
    for (const x of c) expect(x.sec).toBeGreaterThanOrEqual(4 * 60 * 0.9)
  })
  it('izbor: podobni klanci v izseku okoli doma, v vrstnem redu vožnje; največ toliko kot ponovitev', () => {
    const c = climbCandidates(recs, need, p, home, 20)
    const pick = pickClimbLoop(c, need.reps)
    expect(pick.map(x => x.climb)).toEqual([A, B, C])            // po smeri: 10° → 70° → 130°
    expect(pickClimbLoop(c, 2)).toHaveLength(2)
    expect(pickClimbLoop(c.slice(0, 1), 4)).toEqual([])            // en sam klanec → ostane stara pot (ponovitve)
    expect(viaOf(pick)).toHaveLength(6)
  })
  it('ponovitve po klancih: 5 na 3 → 2, 2, 1; 4 na 2 → 2, 2', () => {
    expect(repsPerClimb(5, 3)).toEqual([2, 2, 1])
    expect(repsPerClimb(4, 2)).toEqual([2, 2])
  })
  it('na narisani trasi: kje je vsak klanec (km) in besedilo za vožnjo', () => {
    const pick = pickClimbLoop(climbCandidates(recs, need, p, home, 20), 4)
    const pts: LatLon[] = [home, ...pick.flatMap(x => [x.climb.foot, x.climb.top]), home]
    const st = intervalStops(pts, pick, 4)
    expect(st.map(s => s.reps)).toEqual([2, 1, 1])
    expect(st[0]!.atKm).toBeCloseTo(6, 0)
    expect(st[1]!.atKm).toBeGreaterThan(st[0]!.atKm)
    expect(stopsText(st)).toMatch(/^1\) pri 6(,\d)?\. km \(1,4 km, 6 %\) 2× · 2\) pri/)
  })
  it('predlog za dan: nova trasa čez več klancev ima prednost in pove, kje je kateri interval', () => {
    const pick = pickClimbLoop(climbCandidates(recs, need, p, home, 20), 4)
    const pts: LatLon[] = [home, ...pick.flatMap(x => [x.climb.foot, x.climb.top]), home]
    const nova: RouteRec = { ...ride('nova', pick.map(x => x.climb)), source: 'nova', intervals: intervalStops(pts, pick, 4) }
    const s = suggestRoutes([nova], need, p, '2026-09-25', 1.1, home)[0]!
    expect(s.why).toMatch(/krog čez 3 klance/)
    expect(s.how).toMatch(/Vsak interval na svojem klancu: 1\) pri/)
    expect(s.how).toMatch(/300–320 W/)
  })
})
