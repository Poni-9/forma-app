// v3.49 RECEPTI — recepti po željah (tudi AI), brez laktoze ni brez mleka, vsejedec brez tofuja, raznolikost čez 14 dni,
// slovenske jedi, meja banan, gorivo na teku, »Kot včeraj«, recept za več oseb, nakupovalni seznam brez AI, recept z Danes.
import 'fake-indexeddb/auto'
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, afterEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
const H = vi.hoisted(() => ({ json: {} as unknown, prompts: [] as string[] }))
vi.mock('../src/domain/ai/client', () => {
  class AiError extends Error { kind: string; constructor(kind: string, m: string) { super(m); this.kind = kind } }
  return {
    AiError,
    askText: async () => '',
    askJson: async (parts: { text?: string }[]) => { H.prompts.push(parts.map(p => p.text || '').join('\n')); return JSON.parse(JSON.stringify(H.json)) },
  }
})
const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'prehrana', params: {} as Record<string, string> }, added: [] as any[] }))
vi.mock('@/state/store', async (orig) => ({
  ...(await orig<typeof import('../src/state/store')>()),
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  addMeal: async (m: unknown) => { S.added.push(m) },
}))
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => S.route, subscribeRoute: () => () => undefined }))

import * as repo from '../src/data/repo'
import { Prehrana, yesterdaySame } from '@/screens/Prehrana'
import { DISHES, LF_DISHES, DAY_BANANAS, dayRecipes, dishesFor, exclusionsOf, recipeOkFor, scaleIngredients, shoppingList, basesOf, type Recipe } from '../src/domain/nutrition/recipes'
import { F, dayMealPlan, runFuel } from '../src/domain/nutrition/dayplan'
import { dayMealsOf, recipeCtxOf, recipesOf, recipesAhead } from '../src/domain/nutrition/daymeals'
import { dailyTarget, fueling } from '../src/domain/nutrition/energy'
import { raceSoon } from '../src/domain/nutrition/race'
import { dayRecipesAi, type Snapshot } from '../src/domain/ai/actions'
import { FRANJA_2027 } from '../src/domain/training/planner'
import type { MealEntry, PlanDay, Profile } from '../src/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const NOW = '2026-10-01T08:00:00.000Z'
const TODAY = '2026-10-17'
const P = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, restHr: 55, maxHr: 200, lthr: 184, ftp: 240, ftpDate: '2026-09-20',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, hoursPerWeek: 14, baseHours: null,
  strength: { on: false, equipment: 'home', phases: null }, strengthDays: 0, goal: 'dirka', deficit: 400, neat: 1.4,
  event: null, cycleStart: '2026-09-21', onboardingDone: true, trainTime: 'popoldne', createdAt: NOW, updatedAt: NOW,
  races: [], ...o,
} as Profile)
const day = (date: string, kind: PlanDay['kind'], min: number, o: Partial<PlanDay> = {}): PlanDay => ({ id: `${kind}${date}`, date, kind, title: kind === 'tek' ? 'Dolgi tek' : kind === 'pocitek' ? 'Počitek' : 'Vožnja', desc: '', durationMin: min, zone: 'Z2', role: kind === 'pocitek' ? 'pocitek' : 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, ...o } as PlanDay)
const meal = (date: string, slot: MealEntry['slot'], kcal: number, o: Partial<MealEntry> = {}): MealEntry => ({ id: `${date}-${slot}-${kcal}-${o.name || ''}`, date, slot, name: o.name || slot, kcal, source: 'manual', createdAt: NOW, time: o.time ?? null, ...o })
const addD = (s: string, n: number) => new Date(Date.parse(s + 'T12:00:00Z') + n * 864e5).toISOString().slice(0, 10)
// teden kot v reviziji: počitek, lahka, ključna, počitek, lahka, dolga, lahka (popoldne)
const weekDay = (i: number, d: string): PlanDay => [day(d, 'pocitek', 0), day(d, 'kolo', 60), day(d, 'kolo', 75, { role: 'kljucna', zone: 'Z4' }), day(d, 'pocitek', 0), day(d, 'kolo', 60), day(d, 'kolo', 180, { role: 'dolga' }), day(d, 'kolo', 90)][i % 7]!
/** recepti dneva po pravilih, kot jih vidi Prehrana */
function dayOf(p: Profile, plan: PlanDay[], d: string, prefs = '') {
  const t = dailyTarget(p, [], plan, d, { today: d, hour: 9 })!
  const settings = { foodPrefs: prefs, dayMenus: null }
  const dm = dayMealsOf({ p, target: t, plan, activities: [], meals: [], recentMeals: [], weather: null, day: d, today: d })
  return { dp: dm.dp, r: recipesOf(dm.dp, d, recipeCtxOf(p, t, settings, dm.training), settings) }
}
/** 14 dni: po obroku imena jedi, po dnevu recepti */
function twoWeeks(prefs: string, p = P()) {
  const bySlot: Record<string, string[]> = {}
  const days: Recipe[][] = []
  for (let i = 0; i < 14; i++) {
    const d = addD('2026-10-19', i)
    const { dp, r } = dayOf(p, [weekDay(i, d)], d, prefs)
    days.push(dp.slots.map(s => r[s.key]).filter((x): x is Recipe => !!x))
    for (const s of dp.slots) if (r[s.key]) (bySlot[s.key] ||= []).push(r[s.key]!.name)
  }
  return { bySlot, days }
}
const maxRepeat = (bySlot: Record<string, string[]>) => Math.max(...Object.values(bySlot).map(v => Math.max(...Object.values(v.reduce<Record<string, number>>((c, n) => ({ ...c, [n]: (c[n] || 0) + 1 }), {})))))
const hasTofu = (r: Recipe) => /tofu/i.test(r.name) || r.ingredients.some(i => i.key === 'tofu')

/* ---------- B12: AI recepti po željah ---------- */

describe('B12 — AI recepti spoštujejo prehranske želje', () => {
  const ai = (name: string, ing: string[], kcal: number, p: number): Recipe => ({ dish: 'ai-kosilo', name, kcal, p, c: 90, f: 15, minutes: 25, ingredients: ing.map((text, i) => ({ key: `ai${i}`, qty: 0, text })), steps: ['Skuhaj.'], why: '', by: 'ai' })
  it('shranjen AI recept s piščancem: vegetarijanec dobi recept po pravilih (prej »Piščančji wok · vir ai«)', () => {
    const p = P(), plan = [day(TODAY, 'pocitek', 0)]
    const t = dailyTarget(p, [], plan, TODAY, { today: TODAY, hour: 9 })!
    const dm = dayMealsOf({ p, target: t, plan, activities: [], meals: [], recentMeals: [], weather: null, day: TODAY, today: TODAY })
    const k = dm.dp.slots.find(s => s.key === 'kosilo')!
    const settings = { foodPrefs: 'vegetarijansko', dayMenus: { [TODAY]: { at: NOW, slots: { kosilo: ai('Piščančji wok z rižem', ['piščančje prsi 160 g', 'riž 90 g'], k.kcal, k.proteinG) } } } }
    const r = recipesOf(dm.dp, TODAY, recipeCtxOf(p, t, settings, false), settings)
    expect(r.kosilo!.by).toBe('pravila')
    expect(r.kosilo!.ingredients.some(i => ['piscanec', 'puran', 'tuna', 'losos', 'govedina', 'mleto', 'oslic', 'sunka'].includes(i.key))).toBe(false)
    // brez želja AI recept ostane
    const r0 = recipesOf(dm.dp, TODAY, recipeCtxOf(p, t, { foodPrefs: '' }, false), { dayMenus: settings.dayMenus })
    expect(r0.kosilo!.by).toBe('ai')
  })
  it('preverba besedila: meso, mleko, laktoza, oreški, »ne maram …«, brez glutena; rastlinski napitki niso mleko', () => {
    const ok = (prefs: string, ...ing: string[]) => recipeOkFor({ name: 'Obrok', ingredients: ing.map(text => ({ key: 'ai0', qty: 0, text })) }, prefs)
    expect(ok('vegetarijansko', 'goveji golaž 200 g')).toBe(false)
    expect(ok('vegetarijansko', 'puranja šunka 60 g')).toBe(false)
    expect(ok('vegetarijansko', 'skuta 200 g', 'jajce 2 kosa')).toBe(true)
    expect(ok('vegan', 'grški jogurt 200 g')).toBe(false)
    expect(ok('vegan', 'sojin napitek 300 ml', 'kokosovo mleko 1 dl', 'arašidovo maslo 20 g')).toBe(true)
    expect(ok('brez laktoze', 'grški jogurt 200 g')).toBe(false)
    expect(ok('brez laktoze', 'jogurt brez laktoze 200 g', 'parmezan 20 g')).toBe(true)
    expect(ok('alergija na oreške', 'mandlji 20 g')).toBe(false)
    expect(ok('ne maram brokolija', 'brokoli 200 g')).toBe(false)
    expect(ok('brez glutena', 'testenine brez glutena 100 g')).toBe(true)
    expect(ok('brez glutena', 'polnozrnat kruh 60 g')).toBe(false)
    expect(ok('ne maram rib', 'rdeči ribez 50 g', 'jabolko 1 kos')).toBe(true)
    expect(ok('ne maram rib', 'tuna 120 g')).toBe(false)
  })
  it('AI odgovor: recept z mesom za vegetarijanca izpade še pred shranjevanjem; poziv pove, kaj izločiti', async () => {
    const profile = { ...P(), aiConsentAt: '2026-10-15T08:00:00.000Z', aiConsentV: 2 } as Profile
    const s: Snapshot = { profile, activities: [], plan: [], today: TODAY, extra: '' }
    const slots = [{ key: 'zajtrk', label: 'Zajtrk', when: 'zjutraj', kcal: 600, proteinG: 40, carbsG: 70 }, { key: 'kosilo', label: 'Kosilo', when: 'opoldne', kcal: 800, proteinG: 48, carbsG: 90 }]
    const m = (key: string, ime: string, sestavine: { ime: string; kolicina: string }[], kcal: number, b: number) => ({ key, ime, sestavine, koraki: ['Skuhaj.', 'Postrezi.'], kcal, b, oh: 70, m: 15, minut: 20, zakaj: 'Beljakovine.' })
    H.json = { obroki: [
      m('zajtrk', 'Skuta s kosmiči', [{ ime: 'skuta', kolicina: '250 g' }, { ime: 'ovseni kosmiči', kolicina: '60 g' }], 600, 40),
      m('kosilo', 'Piščančji wok', [{ ime: 'piščančje prsi', kolicina: '160 g' }, { ime: 'riž', kolicina: '90 g' }], 800, 48),
    ] }
    const r = await dayRecipesAi(s, slots, 'vegetarijansko', null, { deficit: true, keepMuscle: false })
    expect(Object.keys(r)).toEqual(['zajtrk'])
    expect(H.prompts[H.prompts.length - 1]).toMatch(/Brez mesa \(tudi piščanca, purana, šunke\), rib in morske hrane/)
    await dayRecipesAi(s, slots, 'brez laktoze', null, { deficit: true, keepMuscle: false })
    expect(H.prompts[H.prompts.length - 1]).toMatch(/Mlečni izdelki samo brez laktoze/)
  })
})

/* ---------- B13: brez laktoze ---------- */

describe('B13 — »brez laktoze« ni »brez mleka«', () => {
  it('želje: laktoza → izdelki brez laktoze; mleko izločijo samo »brez mleka«, »alergija na mleko« in »vegan«', () => {
    expect(exclusionsOf('brez laktoze')).toEqual({ contains: [], words: [], lactoseFree: true })
    expect(exclusionsOf('ne prenašam laktoze').lactoseFree).toBe(true)
    expect(exclusionsOf('brez mleka').contains).toContain('mleko')
    expect(exclusionsOf('alergija na mleko').contains).toContain('mleko')
    expect(exclusionsOf('vegan').contains).toContain('mleko')
    expect(exclusionsOf('vegan, brez laktoze').lactoseFree).toBeUndefined()
  })
  it('14 dni brez laktoze: tofu za zajtrk največ 2× (prej 11×), mlečni izdelki so »brez laktoze«, edamec ostane', () => {
    const { days, bySlot } = twoWeeks('brez laktoze')
    expect(bySlot.zajtrk!.filter(n => /tofu/i.test(n)).length).toBeLessThanOrEqual(2)
    const ing = days.flat().flatMap(r => r.ingredients)
    expect(ing.some(i => ['jogurt', 'skuta', 'mleko', 'kefir'].includes(i.key))).toBe(true)
    for (const i of ing.filter(x => ['jogurt', 'skuta', 'mleko', 'kefir'].includes(x.key))) expect(i.text).toMatch(/brez laktoze/)
    // pečena čičerika ni več vsak večer
    expect(bySlot.malica!.filter(n => /čičerika/.test(n)).length).toBeLessThanOrEqual(4)
  })
})

/* ---------- B14: vsejedec brez tofuja ---------- */

describe('B14 — vsejedec ne dobi tofuja', () => {
  it('14 dni brez želja: tofu v nobenem obroku (prej 7 od 56, zajtrk 4×)', () => {
    expect(twoWeeks('').days.flat().filter(hasTofu).length).toBe(0)
  })
  it('dan pred Franjo (malo vlaknin): ne »Bel riž s tofujem«', () => {
    const p = P({ event: { ...FRANJA_2027 } })
    for (const d of ['2027-06-11', '2027-06-12']) {
      const dp = dayMealPlan(p, { kcal: 3600, proteinG: 140, carbsG: 700 }, null, { race: raceSoon(p, d) })
      expect(Object.values(dayRecipes(dp, d, { deficit: false, keepMuscle: false, training: false })).filter(hasTofu)).toEqual([])
    }
  })
  it('tofu ostane, ko želje izločijo meso, mleko ali jajca ali ga omenijo same', () => {
    expect(dishesFor('zajtrk', 'vegan').some(d => d.contains.includes('soja'))).toBe(true)
    expect(dishesFor('zajtrk', 'rad imam tofu').some(d => d.id === 'tofu-z')).toBe(true)
    expect(dishesFor('zajtrk', '').some(d => d.contains.includes('soja'))).toBe(false)
    // v3.50 (E04): »brez tofuja« izloči tofu, sojini koščki ostanejo
    expect(dishesFor('kosilo', 'brez tofuja, vegetarijansko').some(d => d.items.some(([k]) => k === 'tofu'))).toBe(false)
  })
})

/* ---------- B15: raznolikost pri veganu in vegetarijancu ---------- */

describe('B15 — vegan in vegetarijanec: več raznolikosti, tofu največ enkrat na dan', () => {
  it('14 dni: tofu ≤ 1× na dan; nobena jed ni več kot 9× v istem obroku (prej 10–12×); vsejedec ≤ 5×', () => {
    for (const prefs of ['vegan', 'vegetarijansko']) {
      const { days, bySlot } = twoWeeks(prefs)
      for (const [i, rs] of days.entries()) expect(rs.filter(hasTofu).length, `${prefs} dan ${i}: ${rs.map(r => r.name).join(', ')}`).toBeLessThanOrEqual(1)
      // (po združitvi s CILJ: beljakovine pri ITM > 25 in strop maščob dajo manj ustreznih malic — vegan humus 9×)
      expect(maxRepeat(bySlot), `${prefs}: ${JSON.stringify(bySlot)}`).toBeLessThanOrEqual(9)
      // vegan: zajtrk ni samo tofu (prej 14/14)
      if (prefs === 'vegan') expect(bySlot.zajtrk!.filter(n => !/tofu/i.test(n)).length).toBeGreaterThanOrEqual(7)
    }
    expect(maxRepeat(twoWeeks('').bySlot)).toBeLessThanOrEqual(5)
  })
  it('»drug predlog« zamenja samo ta obrok, ostali ostanejo', () => {
    const { dp } = dayOf(P(), [day(TODAY, 'pocitek', 0)], TODAY)
    const ctx = { deficit: true, keepMuscle: false, training: false }
    const a = dayRecipes(dp, TODAY, ctx), b = dayRecipes(dp, TODAY, { ...ctx, alt: { kosilo: 1 } })
    expect(b.kosilo!.dish).not.toBe(a.kosilo!.dish)
    for (const k of Object.keys(a).filter(k => k !== 'kosilo')) expect(b[k]!.dish, k).toBe(a[k]!.dish)
  })
})

/* ---------- B16: slovenske jedi ---------- */

describe('B16 — slovenske jedi v knjižnici in v rotaciji', () => {
  const SLO = /ajdov|polent|ričet|jota|golaž|bolonjsk|juha|oslič|šunk|palačink/i
  it('kosilo ima vsaj 3 jedi z ajdo, polento, ješprenjem ali kislim zeljem; osnova se prepozna', () => {
    const k = dishesFor('kosilo').filter(d => d.items.some(([key]) => ['ajda', 'polenta', 'jesprenj', 'zelje'].includes(key as string)))
    expect(k.length).toBeGreaterThanOrEqual(3)
    expect(basesOf(DISHES.find(d => d.id === 'golaz')!)).toEqual({ carb: 'polenta', prot: 'govedina' })
    expect(basesOf(DISHES.find(d => d.id === 'ricet')!).carb).toBe('jesprenj')
    // vsaka nova jed: 1–4 koraki, sestavine v tabeli, jota je veganska, sendvič je malica
    for (const id of ['polenta-z', 'ajda-pisc', 'ajda-jajce', 'golaz', 'bolonjska', 'oslic-kr', 'ricet', 'jota', 'juha-zel', 'sendvic-sunka', 'palacinke', 'ajda-mleko']) {
      const d = DISHES.find(x => x.id === id)!
      expect(d, id).toBeTruthy(); expect(d.steps.length).toBeGreaterThanOrEqual(1); expect(d.steps.length).toBeLessThanOrEqual(4)
      for (const [key] of d.items) expect(F[key as string], `${id}: ${String(key)}`).toBeTruthy()
    }
    expect(DISHES.find(d => d.id === 'jota')!.contains).toEqual([])
    expect(dishesFor('malica').some(d => d.id === 'sendvic-sunka')).toBe(true)
    expect(dishesFor('vecerja', 'vegan').map(d => d.id)).toEqual(expect.arrayContaining(['jota', 'ricet', 'leca-juha', 'cicerika']))
  })
  it('makri novih živil na 100 g so realni (kcal ≈ 4·B + 4·OH + 9·M)', () => {
    for (const k of ['ajda', 'polenta', 'jesprenj', 'govedina', 'mleto', 'oslic', 'sunka', 'zelje', 'sojmleko', 'sojjogurt', 'arasid', 'sok', 'moka']) {
      const f = F[k]!
      const est = 4 * f.p + 4 * f.c + 9 * f.f
      expect(Math.abs(est - f.kcal) / f.kcal, k).toBeLessThan(0.12)
    }
  })
  it('v 14 dneh vsejedec dobi vsaj 4 različne slovenske jedi in skupaj vsaj 8 obrokov z njimi', () => {
    const names = twoWeeks('').days.flat().map(r => r.name).filter(n => SLO.test(n))
    expect(new Set(names).size).toBeGreaterThanOrEqual(4)
    expect(names.length).toBeGreaterThanOrEqual(8)
  })
})

/* ---------- B21: banane ---------- */

describe('B21 — banan na dan največ 3 (obroki in gorivo na kolesu skupaj)', () => {
  const bananas = (rs: Record<string, Recipe>) => Object.values(rs).reduce((a, r) => a + r.ingredients.filter(i => i.key === 'banana').reduce((s, i) => s + i.qty, 0), 0)
  it('7 dni dolgih voženj (240 min) in dva dni pred Franjo', () => {
    for (let i = 0; i < 7; i++) {
      const d = addD('2026-10-19', i)
      const { dp, r } = dayOf(P(), [day(d, 'kolo', 240, { role: 'dolga' })], d)
      expect(bananas(r) + (dp.onBike?.bananas || 0), d).toBeLessThanOrEqual(DAY_BANANAS)
    }
    const p = P({ event: { ...FRANJA_2027 } })
    for (const d of ['2027-06-11', '2027-06-12']) {
      const { dp, r } = dayOf(p, [day(d, 'pocitek', 0)], d)
      expect(bananas(r) + (dp.onBike?.bananas || 0), d).toBeLessThanOrEqual(DAY_BANANAS)
    }
  })
  it('namesto banane kozarec soka ali bel kruh pred tekmo', () => {
    const p = P({ event: { ...FRANJA_2027 } })
    const { r } = dayOf(p, [day('2027-06-12', 'pocitek', 0)], '2027-06-12')
    const sides = Object.values(r).flatMap(x => x.ingredients.filter(i => i.side).map(i => i.key))
    expect(sides.some(k => k === 'sok' || k === 'belkruh')).toBe(true)
    expect(LF_DISHES.length).toBeGreaterThan(0)
  })
})

/* ---------- B22: gorivo na teku ---------- */

describe('B22 — dolgi tek ima gorivo v Prehrani (isto kot Danes)', () => {
  it('90 min: 2 gela (45. in 75. minuta) in ~0,6 l vode; do 75 min samo voda; kolo ni prizadeto', () => {
    const rf = runFuel({ kind: 'tek', durationMin: 90, zone: 'Z2' })!
    expect(rf.plan.find(x => x.key === 'gel')!.n).toBe(2)
    expect(rf.cues.map(c => c.atMin)).toEqual([45, 75])
    expect(rf.schedule).toMatch(/Gel v 45\. in 75\. minuti/)
    expect(rf.items.join(' ')).toMatch(/0,6 l vode/)
    expect(runFuel({ kind: 'tek', durationMin: 60, zone: 'Z2' })!.cues).toEqual([])
    expect(runFuel({ kind: 'kolo', durationMin: 90, zone: 'Z2' })).toBeNull()
  })
  it('Danes (fueling) za tek: gel in voda, ne banana in ploščica; vožnja ostane', () => {
    const run = fueling({ kind: 'tek', durationMin: 90, zone: 'Z2', role: 'dolga' }, { weightKg: 79 })!
    expect(run.during).not.toMatch(/\(banana, ploščica/)
    expect(run.during).toMatch(/^Gel v 45\. in 75\. minuti .* Banana in ploščica med tekom ne gresta\.$/)
    expect(fueling({ kind: 'kolo', durationMin: 90, zone: 'Z2', role: 'dolga' }, { weightKg: 79 })!.during).toMatch(/banana, ploščica/)
  })
})

/* ---------- B27, B28, B29: domena ---------- */

describe('B27 — »Kot včeraj«', () => {
  it('včerajšnji vpis v istem obroku; brez goriva; prazno, če je danes že vpisano isto', () => {
    const y = addD(TODAY, -1)
    const recent = [meal(y, 'zajtrk', 620, { name: 'Ovseni kosmiči z jogurtom', time: '07:30' }), meal(y, 'kosilo', 800, { name: 'Golaž' }), meal(y, 'med_vadbo', 300, { name: 'Na kolesu', forDay: 'x' })]
    expect(yesterdaySame(recent, [], TODAY, 'zajtrk').map(m => m.name)).toEqual(['Ovseni kosmiči z jogurtom'])
    expect(yesterdaySame(recent, [], TODAY, 'med_vadbo')).toEqual([])
    expect(yesterdaySame(recent, [{ slot: 'zajtrk', name: 'ovseni kosmiči z jogurtom' }], TODAY, 'zajtrk')).toEqual([])
  })
})

describe('B28 — recept za več oseb', () => {
  it('knjižnica: količine × n z domačo mero; AI: številke × n, odstotki ostanejo', () => {
    const r: Pick<Recipe, 'ingredients'> = { ingredients: [{ key: 'riz', qty: 90, text: 'riž (suh) 90 g (kuhanega ≈ 230 g)' }, { key: 'jajce', qty: 2, text: '2 × jajce' }, { key: 'kruh', qty: 40, text: 'zraven: polnozrnat kruh 40 g (1 rezina)', side: true }] }
    expect(scaleIngredients(r, 3)).toEqual(['riž (suh) 270 g (kuhanega ≈ 700 g)', '6 × jajce', 'zraven: polnozrnat kruh 120 g (3 rezine)'])
    expect(scaleIngredients(r, 1)).toEqual(r.ingredients.map(i => i.text))
    // v3.50 (E15): število in samostalnik skupaj — »3 kosi« (prej »3 kosa«)
    expect(scaleIngredients({ ingredients: [{ key: 'ai0', qty: 0, text: 'mleko 1,5 % 250 ml' }, { key: 'ai1', qty: 0, text: 'jajce 1,5 kosa' }] }, 2)).toEqual(['mleko 1,5 % 500 ml', 'jajce 3 kosi'])
    expect(scaleIngredients({ ingredients: [{ key: 'jogurt', qty: 150, text: '' }] }, 2, 'brez laktoze')[0]).toMatch(/^grški jogurt brez laktoze 300 g/)
    // domača mera po številu (prej »6 lončka«); v3.50 (E14): lonček jogurta je »po 150 g« (v nakupu velik lonček 500 g)
    expect(scaleIngredients({ ingredients: [{ key: 'jogurt', qty: 300, text: '' }, { key: 'skuta', qty: 250, text: '' }, { key: 'mleko', qty: 250, text: '' }] }, 3)).toEqual(['grški jogurt 2 % 900 g (6 lončkov po 150 g)', 'skuta 750 g (3 lončki)', 'mleko 1,5 % 750 ml (3 kozarci)'])
  })
})

describe('B29 — nakupovalni seznam iz receptov (brez AI)', () => {
  it('seštevek po živilu in pakiranje; AI sestavine, kot so napisane', () => {
    const r = (ing: [string, number][]): Pick<Recipe, 'ingredients'> => ({ ingredients: ing.map(([key, qty]) => ({ key, qty, text: '' })) })
    const l = shoppingList([r([['skuta', 250], ['jajce', 3], ['testenine', 120]]), r([['skuta', 250], ['jajce', 4], ['krompirb', 300], ['krompir', 200]]), r([['jajce', 7], ['testenine', 500]]), { ingredients: [{ key: 'ai0', qty: 0, text: 'tempeh 100 g' }] }])
    expect(l).toContain('skuta: 500 g (2 lončka po 250 g)')
    expect(l).toContain('jajce: 14 kosov (2 škatli po 10)')
    expect(l).toContain('testenine (suhe): 620 g (2 paketa po 500 g)')
    expect(l).toContain('krompir: 500 g')
    expect(l[l.length - 1]).toBe('tempeh 100 g (AI recept)')
    expect(shoppingList([r([['mleko', 1200]])], 'brez laktoze')).toEqual(['mleko 1,5 % brez laktoze: 1,2 l (2 litra)'])
  })
  it('7 dni po pravilih brez prijave: danes samo nepojedeni obroki', () => {
    const p = P(), plan = [0, 1, 2, 3, 4, 5, 6].map(i => weekDay(i, addD(TODAY, i)))
    const ms = [meal(TODAY, 'zajtrk', 700, { time: '07:30' })]
    const x = { p, plan, activities: [], meals: ms, recentMeals: ms, weather: null, today: TODAY, settings: { foodPrefs: '' }, targetOf: (d: string) => dailyTarget(p, [], plan.filter(q => q.date === d), d, { today: TODAY, hour: 9 }) }
    const ahead = recipesAhead({ ...x, days: 7 })
    expect(ahead.map(a => a.day)).toEqual([0, 1, 2, 3, 4, 5, 6].map(i => addD(TODAY, i)))
    expect(ahead.slice(1).every(a => a.recipes.length >= 3)).toBe(true)
    const todayDp = dayMealsOf({ p, target: x.targetOf(TODAY)!, plan, activities: [], meals: ms, recentMeals: ms, weather: null, day: TODAY, today: TODAY }).dp
    expect(ahead[0]!.recipes.length).toBeLessThan(todayDp.slots.length)
    expect(shoppingList(ahead.flatMap(a => a.recipes)).length).toBeGreaterThan(8)
  })
})

/* ---------- zaslon ---------- */

let div: HTMLDivElement, root: Root
async function render(el: React.ReactElement) {
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root.render(el) })
  return text()
}
const text = () => (document.body.textContent || '').replace(/[  ]/g, ' ')
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(b.textContent || '') || re.test(b.getAttribute('aria-label') || ''))
async function click(el: Element | undefined | null) { expect(el).toBeTruthy(); await act(async () => { (el as HTMLElement).click(); await new Promise(r => setTimeout(r, 0)) }) }
afterEach(async () => { await act(async () => root?.unmount()); div?.remove(); vi.useRealTimers(); S.added.length = 0; S.route = { name: 'prehrana', params: {} } })

function setState(o: { meals?: MealEntry[]; recent?: MealEntry[]; plan?: PlanDay[]; time?: string; prefs?: string } = {}) {
  vi.useFakeTimers({ toFake: ['Date'] })
  vi.setSystemTime(new Date(`${TODAY}T${o.time || '08:30'}:00`))
  const meals = o.meals || []
  S.state = { ready: true, settings: { ...repo.defaultSettings(), foodPrefs: o.prefs || null }, changes: [], toast: null, sync: { state: 'off' }, authKnown: true, pro: false, wellness: null, checkinToday: null, today: TODAY, profile: P(), plan: o.plan || [], activities: [], mealsToday: meals, recentMeals: [...(o.recent || []), ...meals], checkins: [], weather: null, user: null }
}

describe('Prehrana — recepti', () => {
  it('B31: »recept ›« z Danes (?recept=kosilo) odpre Prehrano na odprtem receptu za kosilo (prej zaprt, na vrhu)', async () => {
    S.route = { name: 'prehrana', params: { recept: 'kosilo' } }
    setState({ time: '08:30' })
    await render(<Prehrana />)
    const row = document.getElementById('recept-kosilo')
    expect(row?.querySelector('.recipe')).toBeTruthy()
    expect(row?.querySelector('[aria-expanded="true"]')).toBeTruthy()
    expect(document.querySelectorAll('.recipe').length).toBe(1)
  })
  it('B28: čip »3« preračuna sestavine za 3 osebe, kalorije ostanejo za tvojo porcijo', async () => {
    S.route = { name: 'prehrana', params: { recept: 'zajtrk' } }
    setState({ time: '08:30' })
    await render(<Prehrana />)
    const items = () => [...document.querySelectorAll('.recipe-ing li')].map(li => li.textContent)
    const before = items()
    await click([...document.querySelectorAll('.recipe-persons button')].find(b => b.textContent === '3'))
    expect(items()).not.toEqual(before)
    expect(text()).toMatch(/Količine za 3 osebe\. Tvoj obrok je ena porcija: [\d ]+ kcal/)
  })
  it('B27: »Kot včeraj« vpiše včerajšnji zajtrk v zdajšnji obrok z uro zdaj', async () => {
    setState({ time: '08:10', recent: [meal(addD(TODAY, -1), 'zajtrk', 620, { name: 'Ovseni kosmiči z jogurtom', time: '07:30' })] })
    expect(await render(<Prehrana />)).toMatch(/Kot včeraj: Ovseni kosmiči z jogurtom/)
    await click(btn(/^Kot včeraj: Ovseni kosmiči z jogurtom — dodaj$/))
    expect(S.added[0]).toMatchObject({ name: 'Ovseni kosmiči z jogurtom', slot: 'zajtrk', time: '08:10', date: TODAY, kcal: 620 })
  })
  it('B29: nakupovalni seznam brez prijave; kopira, kar ni odkljukano', async () => {
    setState({ time: '08:30', plan: [day(TODAY, 'kolo', 90)] })
    const writes: string[] = []
    Object.defineProperty(navigator, 'clipboard', { configurable: true, value: { writeText: async (t: string) => { writes.push(t) } } })
    await render(<Prehrana />)
    await click(btn(/^nakupovalni seznam$/))
    const lines = [...document.querySelectorAll('.shop-list button')]
    expect(lines.length).toBeGreaterThan(8)
    await click(lines[0])
    await click(btn(/^Kopiraj seznam$/))
    expect(writes[0]!.split('\n').length).toBe(lines.length - 1)
  })
  it('B22: dolgi tek ima »Na teku« z geli in vpis brez učenja tekočine za kolo', async () => {
    setState({ time: '08:30', plan: [day(TODAY, 'tek', 90, { role: 'dolga' })] })
    expect(await render(<Prehrana />)).toMatch(/Na teku · 1 h 30 min/)
    expect(text()).toMatch(/2 × gel/)
    await click(btn(/vpiši, kaj si porabil/))
    await click(btn(/^Shrani$/))
    expect(S.added[0]).toMatchObject({ slot: 'med_vadbo', forDay: `tek${TODAY}`, planMl: null })
    expect(S.added[0].name).toMatch(/^Na teku \(Dolgi tek\): 2 × gel/)
  })
})
