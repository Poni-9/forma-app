// v3.51 POPRAVKI51-UI: popravki po pregledu REVIEW-UI — premor, ki že velja (U1), Nazaj in »ostani« v listu (U2),
// predogled premora s predaktivacijo (U4), opravljena današnja tekma (U5), spust datoteke kjer koli (U6), »‹ Nazaj« na
// Vajah (U7). Leni deli (U3) in dvojni obrok (U8) sta v v351-popravki-ui-chunk / v351-popravki-ui-meal.
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, afterEach, beforeEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), nav: [] as string[], route: { name: 'plan', params: {} as Record<string, string> }, fromApp: false }))
vi.mock('@/state/store', async () => {
  const { vi: v } = await import('vitest')
  const base: Record<string | symbol, unknown> = {
    useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
    getState: () => S.state,
    routePace: () => ({ k: 1, adj: { n: 0, adj: 1 } }),
    keepOwn: (b: unknown[]) => b,
    addActivities: v.fn(async () => ({ added: 1, dupes: 0, upgraded: 0 })),
    updateProfile: v.fn(async (patch: Record<string, unknown>) => ({ ...S.state.profile, ...patch })),
    LAST_EXPORT_KEY: 'x',
  }
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' || typeof k === 'symbol' ? undefined : (t[k] = v.fn(async () => undefined))), has: (_t, k) => k !== 'then' })
})
vi.mock('@/app/router', () => ({ navigate: (to: string) => { S.nav.push(to) }, useRoute: () => S.route, parseHash: () => S.route, subscribeRoute: () => () => undefined, cameFromApp: () => S.fromApp }))
vi.mock('@/app/landing', () => ({ markApp: () => undefined, forgetApp: () => undefined }))
vi.mock('@/app/Shell', async (orig) => ({ ...(await orig<object>()), Head: () => null }))
vi.mock('@/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
vi.mock('@/data/icuOauth', () => ({ icuOauthOn: () => false, probeIcuOauth: async () => false, startIcuOAuth: () => undefined }))
vi.mock('@/data/feedback', () => ({
  FB_KINDS: [['nejasno', 'Ni jasno'], ['napaka', 'Napaka'], ['predlog', 'Predlog']], FB_SHOT_MAX: 700000, FB_TEXT_MAX: 3000,
  makeFeedback: async (o: object) => ({ ...o, id: 'x', meta: {}, anon: 'a' }), sendFeedback: async () => 'poslano', captureScreen: async () => null,
  fetchFeedbackList: async () => ({ error: 'x' }), flushFeedback: async () => 0, queuedFeedback: async () => 0,
}))

import * as store from '@/state/store'
import { WeekPauseSheet, pausePreview, bikePauseOf } from '@/ui/WeekPauseSheet'
import { ActivitySheet } from '@/ui/ActivitySheet'
import { FeedbackSheet } from '@/ui/FeedbackSheet'
import { Uvoz } from '@/screens/Uvoz'
import { Vaje } from '@/screens/Vaje'
import { pauseify, pausePeriod, PAUSE_TITLE_KOLO, PAUSE_DESC_KOLO } from '@/domain/training/pause'
import { addDays } from '@/domain/training/load'
import type { Activity, PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-21'   // sreda
const NOW = `${TODAY}T08:00:00.000Z`
const W0 = '2026-10-19'

let div: HTMLDivElement | null = null, root: Root | null = null
async function render(el: ReactElement): Promise<HTMLDivElement> {
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root!.render(el) })
  return div
}
afterEach(async () => { if (root) await act(async () => root!.unmount()); div?.remove(); root = null; div = null; document.body.innerHTML = '' })
beforeEach(() => {
  vi.clearAllMocks()
  S.nav = []; S.route = { name: 'plan', params: {} }; S.fromApp = false
  window.scrollTo = vi.fn() as unknown as typeof window.scrollTo
  Element.prototype.scrollIntoView = vi.fn()
})
const sp = (x: string | null | undefined) => (x || '').replace(/[  ⁠]/g, ' ')
const txt = (d: Element = document.body) => sp(d.textContent)
const fn = (k: string) => (store as unknown as Record<string, ReturnType<typeof vi.fn>>)[k]!
const btn = (re: RegExp, el: ParentNode = document) => [...el.querySelectorAll('button')].find(b => re.test(sp(b.textContent).trim())) as HTMLButtonElement | undefined
async function click(re: RegExp) { const b = btn(re); if (!b) throw new Error(`ni gumba: ${re}`); await act(async () => { b.click() }) }
async function type(el: HTMLTextAreaElement | HTMLInputElement, v: string) {
  const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype
  await act(async () => { Object.getOwnPropertyDescriptor(proto, 'value')!.set!.call(el, v); el.dispatchEvent(new Event('input', { bubbles: true })) })
}
const flush = async () => { for (let i = 0; i < 8; i++) await act(async () => { await Promise.resolve() }) }
const back = async () => { await act(async () => { window.dispatchEvent(new PopStateEvent('popstate', { state: null })) }); await flush() }
const esc = async () => { await act(async () => { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true })) }); await flush() }

const day = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: date + (o.kind || 'kolo') + (o.role || '') + (o.title || ''), date, kind: 'kolo', title: 'Z2 vzdržljivost', desc: 'Mirno.', durationMin: 60, zone: 'Z2', role: 'lahka', tssTarget: 42, source: 'rules', createdAt: NOW, updatedAt: NOW, ...o })
const rest = (date: string, title = 'Počitek', desc = 'Prosto.'): PlanDay => day(date, { kind: 'pocitek', title, desc, durationMin: 0, zone: null, role: null, tssTarget: 0 })
const BLAZ = {
  name: 'Blaž', sex: 'm', age: 21, heightCm: 180, weightKg: 79, restHr: 48, maxHr: 195, lthr: 184, ftp: 240, ftpDate: '2026-09-14', goal: 'dirka', level: 3,
  gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, hoursPerWeek: 11, strength: { on: true, equipment: 'home' }, strengthDays: 2,
  deficit: 400, neat: 1.4, races: [], trainTime: 'popoldne', cycleStart: '2026-09-21', onboardingDone: true, createdAt: NOW, updatedAt: NOW,
} as unknown as Profile
const state = (o: Record<string, unknown> = {}) => ({
  ready: true, today: TODAY, profile: BLAZ, activities: [], plan: [], checkins: [], weather: null, wellness: [], user: null, changes: [], pro: false,
  settings: { lang: 'sl', intervals: null, guideSeen: true }, sync: { state: 'off' }, mealsToday: [], recentMeals: [], routeLib: null, icuDiag: null, icuWorkouts: null, icuErr: null, ...o,
})

describe('U1 premor, ki že velja, se ne uveljavi znova', () => {
  it('tap na »Brez kolesa do nedelje ✓ velja« ne pokliče setWeekPause; drugi način ostane na voljo', async () => {
    const plan = [rest(W0), ...[2, 3, 4, 5, 6].map(i => rest(addDays(W0, i), PAUSE_TITLE_KOLO, PAUSE_DESC_KOLO))]
    S.state = state({ profile: { ...BLAZ, weekPause: { from: TODAY, to: '2026-10-25', mode: 'kolo', at: NOW } }, plan })
    await render(<WeekPauseSheet open onClose={() => undefined} />)
    const cur = btn(/^Brez kolesa do nedelje.*velja/)!
    expect(cur.disabled).toBe(true)
    await act(async () => { cur.click() })
    await flush()
    expect(fn('setWeekPause')).not.toHaveBeenCalled()
    const other = btn(/^Brez treningov do nedelje/)!
    expect(other.disabled).toBe(false)
    await act(async () => { other.click() })
    await flush()
    expect(fn('setWeekPause').mock.calls[0]![0]).toBe('vse')
  })
})

describe('U5 opravljena današnja tekma', () => {
  const race = { id: 'r1', name: 'Kronometer Vodice', date: TODAY, type: 'kronometer', priority: 'B' }
  const raceDay = (done: boolean) => day(TODAY, { title: 'Kronometer Vodice — 18 km', role: 'dirka', raceId: 'r1', durationMin: 30, done: done ? { at: NOW, activityId: null } : null } as never)
  it('ni »Ostane« ne »Odstrani tekmo«', async () => {
    S.state = state({ profile: { ...BLAZ, races: [race] }, plan: [raceDay(true)] })
    await render(<WeekPauseSheet open onClose={() => undefined} />)
    expect(txt()).not.toContain('V tem času je tekma')
    expect(btn(/^Odstrani tekmo$/)).toBeUndefined()
  })
  it('neopravljena današnja tekma: »Ostane.« brez »predaktivacija dan prej« (ta je bila včeraj)', async () => {
    S.state = state({ profile: { ...BLAZ, races: [race] }, plan: [raceDay(false)] })
    await render(<WeekPauseSheet open onClose={() => undefined} />)
    expect(txt()).toContain('V tem času je tekma Kronometer Vodice (sreda, 21. 10.). Ostane.')
    expect(txt()).not.toContain('predaktivacija dan prej')
    expect(btn(/^Odstrani tekmo$/)).toBeTruthy()
  })
})

describe('U4 predogled premora = pauseify (predaktivacija pred tekmo ostane)', () => {
  const plan = [day('2026-10-22', { title: 'Z2 vzdržljivost', durationMin: 60 }), day('2026-10-24', { title: 'Predaktivacija — 3 × 1 min', durationMin: 45 }), day('2026-10-25', { title: 'Kronometer — 18 km', role: 'dirka', raceId: 'r1', durationMin: 30 })]
  it('tekma v nedeljo: odpade samo četrtkova vožnja', () => {
    const w = { ...pausePeriod(TODAY, 'kolo', {}), at: NOW }
    const out = pauseify(plan, w, TODAY, NOW)
    const removed = plan.filter(x => !x.raceId && out.some(o => o.date === x.date && o.kind === 'pocitek'))
    const pv = pausePreview(plan, 'kolo', TODAY, w.to)
    expect(removed.map(x => x.title)).toEqual(['Z2 vzdržljivost'])
    expect([pv.n, pv.min]).toEqual([1, 60])
  })
  it('edina vožnja v obdobju je predaktivacija: »Brez kolesa« ni ponujen', () => {
    const only = plan.filter(x => x.date !== '2026-10-22')
    expect(bikePauseOf(only, BLAZ, TODAY, '2026-10-25').bike).toBe(false)
    // opravljena tekma: predaktivacija ni več »ob tekmi« (pauseify jo umakne) — predogled jo šteje
    const doneRace = only.map(x => (x.raceId ? { ...x, done: { at: NOW, activityId: null } } : x)) as PlanDay[]
    expect(pausePreview(doneRace, 'kolo', TODAY, '2026-10-25').n).toBe(1)
  })
})

describe('U2 Nazaj in »ostani« — list ostane upravljiv', () => {
  const P = { ...BLAZ, age: 30, ftp: 240 } as Profile
  const act0 = (o: Partial<Activity> = {}): Activity => ({ id: 'a1', source: 'manual', sport: 'kolo', date: TODAY, start: null, name: 'Kolo', durationMin: 40, distKm: 15, elevM: null, avgHr: null, avgPower: null, kcal: null, speedKmh: 22.5, tss: 47, polyline: null, aiEligible: true, geoRetain: false, createdAt: NOW, updatedAt: NOW, ...o } as Activity)
  it('ActivitySheet: popravek z napako → Nazaj vpraša v listu → ostani → Esc vpraša znova → Zavrzi zapre brez shranjevanja', async () => {
    S.state = state({ profile: P, activities: [act0()] })
    let closed = 0
    await render(<ActivitySheet id="a1" onClose={() => { closed++ }} onDelete={() => undefined} />)
    await click(/^Uredi$/)
    await type(document.getElementById('ae-dist') as HTMLInputElement, '300')
    await back()
    expect(txt()).toContain('Zavržem popravek?')
    await click(/^(Ostani|Popravi)$/)
    await flush()
    expect(closed).toBe(0)
    expect(txt()).not.toContain('Zavržem popravek?')
    await esc()
    expect(txt()).toContain('Zavržem popravek?')   // prej: nič (list ni bil več med odprtimi)
    expect(closed).toBe(0)
    await click(/^Zavrzi$/)
    await flush()
    expect(closed).toBe(1)
    expect(fn('saveActivity').mock.calls.some(c => (c[0] as Activity).distKm === 300)).toBe(false)
  })
  it('ActivitySheet: veljaven popravek se z Nazaj shrani brez vprašanja', async () => {
    S.state = state({ profile: P, activities: [act0()] })
    let closed = 0
    await render(<ActivitySheet id="a1" onClose={() => { closed++ }} onDelete={() => undefined} />)
    await click(/^Uredi$/)
    await type(document.getElementById('ae-min') as HTMLInputElement, '55')
    await back()
    expect(txt()).not.toContain('Zavržem popravek?')
    expect(closed).toBe(1)
    expect(fn('saveActivity').mock.calls.some(c => (c[0] as Activity).durationMin === 55)).toBe(true)
  })
  it('FeedbackSheet: napisano → Nazaj → ostani → Esc vpraša znova', async () => {
    await render(<FeedbackSheet shot={null} route="danes" />)
    await type(document.querySelector('textarea') as HTMLTextAreaElement, 'Gumb ne dela')
    await back()
    expect(txt()).toContain('Zavržem napisano pripombo?')
    await click(/^(Ostani|Nadaljuj pisanje)$/)
    await flush()
    expect(txt()).not.toContain('Zavržem napisano pripombo?')
    await esc()
    expect(txt()).toContain('Zavržem napisano pripombo?')
    expect((document.querySelector('textarea') as HTMLTextAreaElement).value).toBe('Gumb ne dela')
  })
})

describe('U6 spust datoteke kjer koli na zaslonu Uvoz', () => {
  const dragEv = (type: string, files: File[]) => {
    const ev = new Event(type, { bubbles: true, cancelable: true })
    Object.defineProperty(ev, 'dataTransfer', { value: { types: ['Files'], files, dropEffect: 'none' } })
    return ev
  }
  it('dragover in drop na glavi (zunaj .scroll): privzeto vedenje preprečeno, datoteka obdelana', async () => {
    S.route = { name: 'uvoz', params: {} }
    S.state = state({ profile: BLAZ })
    await render(<Uvoz />)
    const head = document.createElement('header'); document.body.appendChild(head)
    const over = dragEv('dragover', [])
    await act(async () => { head.dispatchEvent(over) })
    expect(over.defaultPrevented).toBe(true)
    const drop = dragEv('drop', [new File(['x'], 'beleske.txt', { type: 'text/plain' })])
    await act(async () => { head.dispatchEvent(drop) })
    await flush()
    expect(drop.defaultPrevented).toBe(true)
    expect(fn('toast').mock.calls.some(c => /beleske\.txt/.test(String(c[0])))).toBe(true)
  })
  it('vlečenje besedila (ne datotek) ostane brskalniku', async () => {
    S.state = state({ profile: BLAZ })
    await render(<Uvoz />)
    const ev = new Event('dragover', { bubbles: true, cancelable: true })
    Object.defineProperty(ev, 'dataTransfer', { value: { types: ['text/plain'], files: [] } })
    await act(async () => { document.body.dispatchEvent(ev) })
    expect(ev.defaultPrevented).toBe(false)
  })
})

describe('U7 »‹ Nazaj« na Vajah', () => {
  it('odprto s povezavo od drugod (history.length > 1): na Danes, ne history.back()', async () => {
    history.pushState(null, '', '#/x'); history.pushState(null, '', '#/vaje')
    expect(history.length).toBeGreaterThan(1)
    const hb = vi.spyOn(history, 'back').mockImplementation(() => undefined)
    S.route = { name: 'vaje', params: {} }
    S.state = state()
    await render(<Vaje />)
    await click(/Nazaj$/)
    expect(hb).not.toHaveBeenCalled()
    expect(S.nav).toEqual(['danes'])
    hb.mockRestore()
  })
  it('iz aplikacije: history.back()', async () => {
    S.fromApp = true
    const hb = vi.spyOn(history, 'back').mockImplementation(() => undefined)
    S.route = { name: 'vaje', params: {} }
    S.state = state()
    await render(<Vaje />)
    await click(/Nazaj$/)
    expect(hb).toHaveBeenCalledTimes(1)
    expect(S.nav).toEqual([])
    hb.mockRestore()
  })
  it('router: navigate() označi nov vnos »iz aplikacije«, zamenjava ga obdrži; vnos brez oznake ni iz aplikacije', async () => {
    const r = await vi.importActual<typeof import('@/app/router')>('@/app/router')
    history.replaceState(null, '', '#/danes')
    expect(r.cameFromApp()).toBe(false)
    r.navigate('vaje')
    expect(location.hash).toBe('#/vaje')
    expect(r.cameFromApp()).toBe(true)
    r.navigate('plan', undefined, { replace: true })
    expect(r.cameFromApp()).toBe(true)
    history.replaceState(null, '', '#/vaje')
    expect(r.cameFromApp()).toBe(false)
  })
})
