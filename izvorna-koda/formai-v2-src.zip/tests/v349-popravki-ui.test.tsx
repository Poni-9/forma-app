// v3.49 POPRAVKI-UI (REVIEW-UI U2–U8, zasloni z lažno shrambo): »Si ga naredil?« ima prednost pred autoMissed (U2),
// »Prvi trening« samo za res novega uporabnika (U3), vadba moči iz kopije z včeraj pod včerajšnjim dnem (U4),
// »Prvi koraki« se starim uporabnikom ne vrnejo (U5), »Ne« velja za dan ob izrisu (U7), »Poskusi znova« ne izgubi vprašanja (U8).
// Shramba s pravo bazo (U1, U2 autoMissed, U6) je v tests/v349-popravki-ui-store.test.tsx.
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'vadba', params: {} as Record<string, string> } }))
const h = vi.hoisted(() => ({ run: vi.fn(async (fn: () => Promise<unknown>, _o?: { onError?: (m: string) => void }) => fn()) }))
vi.mock('@/state/store', async () => {
  const { vi: v } = await import('vitest')
  const base: Record<string | symbol, unknown> = {
    useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
    getState: () => S.state,
    routePace: () => ({ k: 1, adj: { n: 0, adj: 1 } }),
  }
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' || typeof k === 'symbol' ? undefined : (t[k] = v.fn(async () => ({ added: 1, dupes: 0, upgraded: 0 })))), has: (_t, k) => k !== 'then' })
})
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => S.route }))
vi.mock('@/app/Shell', () => ({ Head: () => null }))
vi.mock('@/ui/useAi', () => ({ useAi: () => ({ busy: false, signedIn: true, consent: true, run: h.run, sheet: null }) }))
vi.mock('@/state/snap', () => ({ snapOf: () => ({}) }))
vi.mock('@/ui/useDictation', () => ({ useDictation: () => ({ listening: false, canSpeak: false, toggle: () => {}, stop: () => {}, transcribing: false, level: 0 }) }))
vi.mock('@/ui/ListenBar', () => ({ ListenBar: () => null }))
vi.mock('@/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '@/state/store'
import { Vadba, type Run } from '@/screens/Vadba'
import { Plan } from '@/screens/Plan'
import { Trener } from '@/screens/Trener'
import { YesterdayRate } from '@/ui/YesterdayRate'
import { FirstSteps } from '@/ui/FirstSteps'
import { RUN_SAVED_KEY } from '@/ui/runState'
import { stepsFor } from '@/domain/training/workout'
import { firstTraining } from '@/domain/training/danes'
import { yesterdayUnmarked } from '@/domain/training/missed'
import { addDays } from '@/domain/training/load'
import type { Activity, PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-17', YDAY = '2026-10-16'
const NOW = `${TODAY}T08:00:00.000Z`
const P = { sex: 'm', age: 35, heightCm: 180, weightKg: 75, ftp: 250, ftpDate: '2026-09-01', gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true }, strength: { on: true, equipment: 'none' }, onboardingDone: true, hoursPerWeek: 8, goal: 'forma', createdAt: NOW, updatedAt: NOW } as unknown as Profile
const day = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: date + (o.kind || 'kolo'), date, kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, zone: 'Z2', role: 'lahka', tssTarget: 42, source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })
const rest = (date: string, o: Partial<PlanDay> = {}) => day(date, { kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, tssTarget: 0, role: null, ...o })
const ride: PlanDay = { id: 'd1', date: TODAY, kind: 'kolo', title: 'Z2 vožnja', desc: 'Enakomerno v Z2.', durationMin: 60, zone: 'Z2', role: 'lahka', tssTarget: 42, source: 'rules', createdAt: NOW, updatedAt: NOW }
const gym: PlanDay = { id: 'm1', date: YDAY, kind: 'moc', title: 'Moč — noge', desc: 'Noge.', durationMin: 40, zone: null, role: 'moc', exercises: [{ name: 'Goblet počep', sets: 3, reps: '8', kg: 30 }], source: 'rules', createdAt: NOW, updatedAt: NOW }
const reset = (plan: PlanDay[], o: Record<string, unknown> = {}) => {
  S.state = { ready: true, today: TODAY, plan, activities: [], recentMeals: [], mealsToday: [], checkins: [], checkinToday: null, weather: null, wellness: null, routeLib: null, routesBusy: false, settings: { lang: 'sl', intervals: null, coach: { msgs: [], summary: null } }, toast: null, profile: P, user: null, authKnown: true, firstSync: null, changes: [], sync: { state: 'ok' }, ...o }
  S.subs.forEach(f => f())
}
const fn = (k: string) => (store as unknown as Record<string, ReturnType<typeof vi.fn>>)[k]!
let div: HTMLDivElement | null = null, root: Root | null = null
async function render(el: ReactElement) { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div); await act(async () => { root!.render(el) }); return div }
const sp = (x: string | null | undefined) => (x || '').replace(/[  ⁠]/g, ' ')
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(sp(b.textContent))) as HTMLButtonElement | undefined
const flush = async () => { for (let i = 0; i < 6; i++) await act(async () => { await Promise.resolve() }) }
const setInput = async (input: HTMLInputElement, v: string) => { await act(async () => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(input, v); input.dispatchEvent(new Event('input', { bubbles: true })) }) }

beforeEach(() => { sessionStorage.clear(); localStorage.clear(); S.subs.clear(); window.scrollTo = vi.fn() as never })
afterEach(async () => { if (root) { await act(async () => root!.unmount()); root = null } div?.remove(); document.body.innerHTML = ''; vi.useRealTimers() })

describe('U2 »Včeraj: … si ga naredil?« proti autoMissed', () => {
  const key = day(YDAY, { id: 'y1', title: 'VO2max 4 × 4 min', role: 'kljucna', zone: 'Z5', durationMin: 75, tssTarget: 80 })
  it('»Ne« prestavi ključni trening (autoMissed s tem dnem) — do odgovora ga autoMissed pusti', async () => {
    reset([key, ride])
    fn('autoMissed').mockClear()
    await render(<YesterdayRate />)
    expect(sp(div!.textContent)).toContain('Včeraj: VO2max 4 × 4 min — si ga naredil?')
    await act(async () => { btn(/^Ne$/)!.click() })
    expect(fn('autoMissed')).toHaveBeenCalledWith('y1')
    expect(div!.textContent).toBe('')
  })
  it('yesterdayUnmarked: že obdelan dan (prestavljen ali izpuščen) ne sprašuje', () => {
    expect(yesterdayUnmarked({ today: TODAY, plan: [key], activities: [] })?.id).toBe('y1')
    expect(yesterdayUnmarked({ today: TODAY, plan: [{ ...key, missed: 'moved' }], activities: [] })).toBeNull()
    expect(yesterdayUnmarked({ today: TODAY, plan: [{ ...key, missed: 'skipped' }], activities: [] })).toBeNull()
  })
  it('Plan: pretekli »prestavljen« dan ponudi »Opravil« (ne »Začni«)', async () => {
    vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date(`${TODAY}T10:00:00`))
    const past: PlanDay = { ...ride, id: 'p1', date: '2026-10-15', title: 'VO2max 4 × 4 min', role: 'kljucna', zone: 'Z5', missed: 'moved' }
    S.route = { name: 'plan', params: { dan: '2026-10-15' } }
    reset([past, ride])
    fn('setPlanDone').mockClear()
    await render(<Plan />)
    const card = document.getElementById('dan-2026-10-15')!
    expect(sp(card.textContent)).toContain('prestavljeno')
    const b = [...card.querySelectorAll('button')].find(x => sp(x.textContent).trim() === 'Opravil') as HTMLButtonElement | undefined
    expect(b).toBeTruthy()
    expect([...card.querySelectorAll('button')].some(x => /Začni/.test(x.textContent || ''))).toBe(false)
    await act(async () => { b!.click() })
    expect(fn('setPlanDone')).toHaveBeenCalledWith('p1', true)
  })
})

describe('U3 firstTraining samo za res novega uporabnika', () => {
  it('off-season »počitek« (14 dni vožnje po želji in počitek, nekaj opravljenih): ni »prvi trening«', () => {
    const plan: PlanDay[] = []
    for (let k = -14; k < 0; k++) plan.push(k % 2 ? day(addDays(TODAY, k), { optional: true, title: 'Kolo po želji', done: { at: NOW, activityId: 'a' + k } }) : rest(addDays(TODAY, k)))
    plan.push(rest(TODAY), day(addDays(TODAY, 1), { optional: true, title: 'Kolo po želji' }), day(addDays(TODAY, 10), { title: 'Z2 — vrnitev' }))
    expect(firstTraining(plan, TODAY)).toBeNull()
  })
  it('po 2 tednih bolezni (počitek s shranjenimi dnevi), jutri trening: ni »začneva jutri«', () => {
    const plan: PlanDay[] = []
    for (let k = -14; k <= 0; k++) plan.push(rest(addDays(TODAY, k), { sickPrev: [day(addDays(TODAY, k))] }))
    plan.push(day(addDays(TODAY, 1), { title: 'Z2 lahko' }))
    expect(firstTraining(plan, TODAY)).toBeNull()
  })
  it('vadba v zadnjih 60 dneh ali off-season v profilu: null; res nov uporabnik: prvi trening', () => {
    const plan = [rest(TODAY), rest(addDays(TODAY, 1)), day(addDays(TODAY, 2), { kind: 'moc', title: 'Fitnes — noge' })]
    expect(firstTraining(plan, TODAY, { activities: [], profile: P })!.date).toBe(addDays(TODAY, 2))
    const old = { id: 'a1', source: 'file', sport: 'kolo', date: addDays(TODAY, -40), name: 'Vožnja', durationMin: 90 } as Activity
    expect(firstTraining(plan, TODAY, { activities: [old], profile: P })).toBeNull()
    expect(firstTraining(plan, TODAY, { activities: [{ ...old, date: addDays(TODAY, -90) }], profile: P })!.date).toBe(addDays(TODAY, 2))
    expect(firstTraining(plan, TODAY, { activities: [], profile: { ...P, cycleStart: '2026-10-12', offSeasonWeeks: 3 } })).toBeNull()
  })
})

describe('U4 Vadba — kopija moči z včerajšnjega dne', () => {
  function copyOf(d: PlanDay, i: number, el: number, ago: number, o: Partial<Run> = {}) {
    const steps = stepsFor(d, P)
    const stepAt = steps.slice(0, i).reduce((t, s) => t + s.sec, 0) * 1000
    const savedAt = Date.now() - ago
    const r = { v: 1, dayId: d.id, day: d, steps, i, stepAt, acc: el * 1000 - 60_000, runFrom: savedAt - 60_000, cues: [], cue: null, finished: false, saved: false, ...o }
    localStorage.setItem(RUN_SAVED_KEY, JSON.stringify({ ...r, savedAt }))
  }
  it('»Shrani, kar si naredil« zapiše vadbo z datumom dneva načrta (včeraj), ne današnjim', async () => {
    vi.useFakeTimers(); vi.setSystemTime(new Date(`${TODAY}T07:30:00`))
    reset([gym])
    fn('setPlanDone').mockClear(); fn('addActivities').mockClear()
    // prekinjena včeraj ob 22:00 (9,5 h nazaj), 12 min narejenih
    copyOf(gym, 3, 12 * 60, 9.5 * 3600_000, { log: { 1: { kg: 32.5, reps: 8 } }, runFrom: null, acc: 12 * 60_000 })
    S.route = { name: 'vadba', params: { id: 'm1' } }
    await render(<Vadba />)
    expect(sp(div!.textContent)).toContain('Vadba je bila prekinjena pri 12:00')
    await act(async () => { btn(/^Shrani, kar si naredil \(12:00\)$/)!.click() })
    await flush()
    expect(fn('setPlanDone')).toHaveBeenCalledWith('m1', true, expect.any(String), 12)
    const a = (fn('addActivities').mock.calls[0]![0] as Activity[])[0]!
    expect(a.date).toBe(YDAY)
  })
})

describe('U5 »Prvi koraki« se starim uporabnikom ne vrnejo', () => {
  const act1 = (i: number, source: Activity['source']): Activity => ({ id: 'a' + i, source, sport: 'kolo', date: addDays(TODAY, -i), name: 'Vožnja', durationMin: 60 } as Activity)
  const old = { ...P, event: { name: 'Franja', date: '2027-06-12' } } as unknown as Profile
  it('12 vadb iz datotek brez intervals.icu: korak »Poveži uro« je opravljen → kartice ni', async () => {
    reset([ride], { profile: old, user: { uid: 'u' }, activities: Array.from({ length: 12 }, (_, i) => act1(i, 'file')), settings: { lang: 'sl', intervals: null, startDone: false } })
    await render(<FirstSteps />)
    expect(div!.textContent).toBe('')
  })
  it('dve datoteki ali ročni vnosi še ne (C26 ostane)', async () => {
    reset([ride], { profile: old, user: { uid: 'u' }, activities: [act1(1, 'file'), act1(2, 'file'), ...Array.from({ length: 10 }, (_, i) => act1(10 + i, 'manual'))], settings: { lang: 'sl', intervals: null, startDone: false } })
    await render(<FirstSteps />)
    expect(div!.textContent).toContain('Poveži uro')
  })
})

describe('U7 »Ne« in »ne zdaj« veljata za dan ob izrisu', () => {
  it('po polnoči z odprtim Danes se vprašanje za novi dan pokaže', async () => {
    const y1 = day(YDAY, { id: 'y1', title: 'Lahek tek', kind: 'tek', durationMin: 25 })
    const t1 = day(TODAY, { id: 't1', title: 'Z2 lahko' })
    reset([y1, t1])
    await render(<YesterdayRate />)
    await act(async () => { btn(/^Ne$/)!.click() })
    expect(div!.textContent).toBe('')
    expect(localStorage.getItem(`formai.ydayAsk.${TODAY}`)).toBe('1')
    // polnoč: today naprej, včeraj je zdaj t1 (brez kljukice)
    await act(async () => { S.state = { ...S.state, today: addDays(TODAY, 1) }; S.subs.forEach(f => f()) })
    expect(sp(div!.textContent)).toContain('Včeraj: Z2 lahko — si ga naredil?')
  })
})

describe('U8 Trener »Poskusi znova«', () => {
  it('ob preklicu prijave ali privolitve (brez razloga) gre vprašanje nazaj v polje', async () => {
    reset([], { user: { uid: 'u' }, firstSync: true, settings: { coach: { msgs: [], summary: null } } })
    h.run.mockReset()
    h.run.mockImplementationOnce(async (_fn, o) => { o?.onError?.('AI zdaj ne more odgovoriti — poskusi čez minuto.'); return undefined })
    location.hash = '#/trener'
    await render(<Trener />)
    const input = document.querySelector<HTMLInputElement>('input.field')!
    await setInput(input, 'Kaj pa jutri?')
    await act(async () => { input.form!.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true })) })
    await flush()
    expect(document.querySelector('.msg.user.failed')?.textContent).toBe('Kaj pa jutri?')
    // ponovni poskus: prijava preklicana → run vrne undefined brez onError
    h.run.mockImplementationOnce(async () => undefined)
    await act(async () => { btn(/^Poskusi znova$/)!.click() })
    await flush()
    expect(document.querySelector('.msg.user.failed')).toBeNull()
    expect((document.querySelector<HTMLInputElement>('input.field')!).value).toBe('Kaj pa jutri?')
  })
})
