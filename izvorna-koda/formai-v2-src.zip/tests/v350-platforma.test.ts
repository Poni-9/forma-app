// v3.50 PLATFORMA: normalizacija ob branju, usmerjevalnik, obvestila, sinhronizacija, posodobitve, CSS, manifest.
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, afterEach } from 'vitest'
import { readFileSync } from 'node:fs'

const FB = vi.hoisted(() => ({ onAuth: vi.fn(() => () => undefined) }))
vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: FB.onAuth, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import { normalizePlanDay, normalizeActivity, normalizeCheckin, normalizeList } from '../src/data/normalize'
import { fromCloud, toCloud, trimmedOf, type SyncStatus } from '../src/data/sync'
import { parseBackup } from '../src/data/backup'
import * as repo from '../src/data/repo'
import { db } from '../src/data/db'
import { stepsFor } from '../src/domain/training/workout'
import { parseHash, normalizeRoute, navigate, navTab, replaceParams, hashFor } from '../src/app/router'
import * as store from '../src/state/store'
import { syncNotice, NOTICE_EMPTY, ERR_AFTER_MS } from '../src/data/syncNotice'
import { cloudTrimText, updateCheckText } from '../src/ui/PlatformRows'
import { updatedNoticeFor, checkForUpdate } from '../src/app/sw'
import { shouldBootAuth, authHintSync, markAuth, AUTH_FLAG } from '../src/data/authHint'
import { themeToggle } from '../src/ui/theme'
import { OFFLINE_BAR } from '../src/app/Shell'
import type { Activity, DailyCheckin, PlanDay } from '../src/domain/types'

const src = (f: string) => readFileSync(new URL('../' + f, import.meta.url), 'utf8')

const TODAY = '2026-10-18'
const NOW = '2026-10-18T08:00:00.000Z'
const day = (o: Partial<PlanDay> = {}): PlanDay => ({ id: 'd1', date: TODAY, kind: 'kolo', title: 'Z2 vožnja', desc: 'Lahko, pogovorni tempo.', durationMin: 60, zone: 'Z2', source: 'rules', createdAt: NOW, updatedAt: NOW, ...o })
const ride = (o: Partial<Activity> = {}): Activity => ({ id: 'a1', source: 'manual', sport: 'kolo', date: TODAY, start: null, name: 'Vožnja', durationMin: 60, distKm: 30, aiEligible: true, geoRetain: false, ...o } as Activity)

describe('G02 — pokvarjen dan načrta se popravi ob branju', () => {
  const P = repo.defaultProfile()
  it('veljaven dan ostane isti predmet (tudi moč z vajami)', () => {
    const d = day(); expect(normalizePlanDay(d)).toBe(d)
    const m = day({ kind: 'moc', title: 'Moč — noge', exercises: [{ name: 'Počep', sets: 3, reps: '8', kg: 40, rest: 90 }] })
    expect(normalizePlanDay(m)).toBe(m)
    const list = [d, m]; expect(normalizeList(list, normalizePlanDay)).toBe(list)
  })
  it('vaje kot niz, vaja brez imena, vaja null, dan brez naslova → uporaben dan; brez id-ja ali datuma → izpuščen', () => {
    const asStr = normalizePlanDay(day({ kind: 'moc', title: 'Moč?', exercises: 'ni seznam' as never }))!
    expect(asStr.exercises).toBeUndefined()
    const noName = day({ kind: 'moc', title: 'Moč — noge', exercises: [{ id: 'pocep', sets: 3, reps: '8' } as never, { name: 'Sklece', sets: 3, reps: 10 as never }] })
    expect(() => stepsFor(noName, P)).toThrow()   // stara pot: »Cannot read properties of undefined (reading 'toLowerCase')«
    const fixed = normalizePlanDay(noName)!
    expect(fixed.exercises).toEqual([{ name: 'Sklece', sets: 3, reps: '10', kg: null, rest: null }])
    expect(() => stepsFor(fixed, P)).not.toThrow()
    expect(normalizePlanDay(day({ kind: 'moc', title: 'Moč', exercises: [null as never] }))!.exercises).toEqual([])
    const noTitle = { id: 'b7', date: TODAY, kind: 'kolo', durationMin: 60 } as unknown as PlanDay
    expect(() => stepsFor(noTitle, P)).toThrow()   // stara pot: »reading 'matchAll'«
    const t = normalizePlanDay(noTitle)!
    expect(t.title).toBe('Kolo'); expect(t.desc).toBe(''); expect(t.source).toBe('rules')
    expect(() => stepsFor(t, P)).not.toThrow()
    expect(normalizePlanDay(day({ durationMin: 'abc' as never }))!.durationMin).toBe(0)
    expect(normalizePlanDay({ id: 'x', date: null, kind: 'xyz', title: 'Čudna' } as never)).toBeNull()
    expect(normalizePlanDay(day({ id: '' }))).toBeNull()
    expect(normalizePlanDay(null as never)).toBeNull()
  })
  it('oblak in kopija: pokvarjen dan je popravljen, ne sesuje', () => {
    const s = fromCloud({ plan: [day(), { id: 'b2', date: TODAY, kind: 'moc', title: 'Moč?', durationMin: 40, exercises: 'ni seznam' } as never, { id: 'b0' } as never] })
    expect(s.plan.map(d => d.id)).toEqual(['d1', 'b2'])
    expect(s.plan[1]!.exercises).toBeUndefined()
    const b = parseBackup(JSON.stringify({ version: 2, plan: [{ id: 'b7', date: TODAY, kind: 'kolo', durationMin: 60 }] }))
    expect(b.state.plan[0]!.title).toBe('Kolo')
  })
  it('baza: planBetween in allPlan vrneta popravljen dan', async () => {
    await repo.wipeAll()
    const d = await db()
    await d.put('plan', { id: 'b5', date: TODAY, kind: 'moc', title: 'Moč — noge', durationMin: 45, exercises: [{ id: 'pocep', sets: 3, reps: '8' }] } as never)
    const [x] = await repo.planBetween('2026-10-12', '2026-10-25')
    expect(x!.exercises).toEqual([])
    expect((await repo.allPlan())[0]!.exercises).toEqual([])
  })
})

describe('G03 — pokvarjena vadba se popravi ob branju', () => {
  it('veljavna vadba ostane isti predmet', () => {
    const a = ride(); expect(normalizeActivity(a)).toBe(a)
    const old = ride({ aiEligible: undefined as never, geoRetain: undefined as never }); expect(normalizeActivity(old)).toBe(old)
  })
  it('datum število ali null, šport število, ime null, številke niz → popravljeno ali izpuščeno', () => {
    expect(normalizeActivity(ride({ date: 20261018 as never }))).toBeNull()
    expect(normalizeActivity(ride({ date: null as never, start: '2026-10-17T10:00:00.000Z' }))!.date).toBe('2026-10-17')
    const x = normalizeActivity(ride({ sport: 42 as never, name: null as never, durationMin: null, distKm: 'x' as never, tss: {} as never }))!
    expect(x.sport).toBe('drugo'); expect(x.name).toBe('Vadba'); expect(x.distKm).toBeNull(); expect(x.tss).toBeNull()
    expect(normalizeActivity(ride({ sport: 'joga' as never }))!.sport).toBe('drugo')
    expect(normalizeActivity(ride({ aiEligible: 'da' as never }))!.aiEligible).toBe(false)
  })
  it('oblak: vadba brez datuma ne pride naprej; baza: allActivities preskoči pokvarjeno', async () => {
    const s = fromCloud({ activities: [ride(), ride({ id: 'b3', date: null as never })] })
    expect(s.activities.map(a => a.id)).toEqual(['a1'])
    await repo.wipeAll()
    const d = await db()
    await d.put('activities', { id: 'b9', source: 'manual', sport: 'kolo', date: 20261018, name: 'X', durationMin: 60 } as never)
    await d.put('activities', ride() as never)
    const all = await repo.allActivities()
    expect(all.map(a => a.id)).toEqual(['a1'])
    expect(() => all.map(a => a.date.slice(0, 7))).not.toThrow()
  })
})

describe('G45 — jutranji vnos s težo kot nizom', () => {
  it('teža niz → brez teže; veljaven vnos isti predmet; samo pokvarjena teža → izpuščen', () => {
    const ok: DailyCheckin = { date: TODAY, weightKg: 80.4, sleepH: 7, mood: 4 }
    expect(normalizeCheckin(ok)).toBe(ok)
    expect(normalizeCheckin({ date: TODAY, weightKg: 'osemdeset' as never, sleepH: 7 })).toEqual({ date: TODAY, weightKg: null, sleepH: 7, waistCm: null, soreness: null, mood: null, note: null })
    expect(normalizeCheckin({ date: TODAY, weightKg: 7.6 })).toBeNull()
    expect(normalizeCheckin({ date: TODAY, mood: 9 as never, sleepH: 6 })!.mood).toBeNull()
    expect(normalizeCheckin({ weightKg: 80 } as never)).toBeNull()
  })
  it('oblak in baza: graf teže ne dobi niza', async () => {
    const s = fromCloud({ checkins: [{ date: TODAY, weightKg: 'osemdeset' as never, sleepH: 7 }] })
    expect(s.checkins[0]!.weightKg).toBeNull()
    await repo.wipeAll()
    await (await db()).put('checkins', { date: TODAY, weightKg: 'osemdeset', sleepH: 7 } as never)
    const all = await repo.allCheckins()
    expect(all.every(c => c.weightKg == null || Number.isFinite(c.weightKg))).toBe(true)
    expect((await repo.getCheckin(TODAY))!.weightKg).toBeNull()
  })
})

/* ---------- usmerjevalnik ---------- */
const tick = () => new Promise(r => setTimeout(r, 0))
const untilHash = async (h: string) => { for (let i = 0; i < 50 && location.hash !== h; i++) await new Promise(r => setTimeout(r, 10)) }
const TABS = ['danes', 'plan', 'prehrana', 'trener', 'napredek']

describe('G25, G26 — poti', () => {
  it('% v naslovu ne vrže URIError', () => {
    expect(() => parseHash('#/plan?x=%')).not.toThrow()
    expect(parseHash('#/plan?x=%')).toEqual({ name: 'plan', params: { x: '%' } })
    expect(parseHash('#/plan?dan=2026-10-18&sec=pl%20x')).toEqual({ name: 'plan', params: { dan: '2026-10-18', sec: 'pl x' } })
  })
  it('neznana pot → danes, velike črke → prava pot', () => {
    expect(normalizeRoute('neznano')).toBe('danes')
    expect(normalizeRoute('DANES')).toBe('danes')
    expect(normalizeRoute('PLAN')).toBe('plan')
    expect(normalizeRoute('vadba')).toBe('vadba')
    expect(normalizeRoute('vec')).toBe('vec')
  })
})

describe('G44 — zavihki ne polnijo zgodovine', () => {
  it('prvi odhod z Danes doda en vnos, menjava zavihkov ga zamenja, Danes se vrne (Nazaj gre iz aplikacije)', async () => {
    location.hash = '#/danes'; await tick()
    const L0 = history.length
    let changes = 0
    const on = () => { changes++ }
    addEventListener('hashchange', on)
    navTab('plan', TABS); await untilHash('#/plan')
    expect(history.length).toBe(L0 + 1)
    navTab('prehrana', TABS); await tick()
    expect(location.hash).toBe('#/prehrana')
    expect(history.length).toBe(L0 + 1)   // prej L0 + 2
    navTab('napredek', TABS); await tick()
    expect(history.length).toBe(L0 + 1)   // prej L0 + 3
    navTab('danes', TABS); await untilHash('#/danes')
    expect(location.hash).toBe('#/danes')
    expect(changes).toBeGreaterThanOrEqual(4)   // zamenjava naslova sproži hashchange (zaslon sledi)
    removeEventListener('hashchange', on)
  })
  it('navigate z replace: brez novega vnosa, hashchange se sproži', async () => {
    location.hash = '#/plan'; await tick()
    const L0 = history.length
    let n = 0; const on = () => { n++ }
    addEventListener('hashchange', on)
    navigate('danes', undefined, { replace: true }); await tick()
    expect(location.hash).toBe('#/danes'); expect(history.length).toBe(L0); expect(n).toBe(1)
    removeEventListener('hashchange', on)
  })
})

describe('G28, G29 — stanje zaslona v naslovu', () => {
  it('hashFor in replaceParams: brez novega vnosa in brez hashchange; prazen parameter izpade; drug zaslon se ne dotakne', async () => {
    expect(hashFor('prehrana', { dan: '2026-10-17' })).toBe('#/prehrana?dan=2026-10-17')
    expect(hashFor('prehrana', { dan: null })).toBe('#/prehrana')
    location.hash = '#/prehrana'; await tick()
    const L0 = history.length
    let n = 0; const on = () => { n++ }
    addEventListener('hashchange', on)
    replaceParams({ dan: '2026-10-17' }, 'prehrana')
    expect(location.hash).toBe('#/prehrana?dan=2026-10-17')
    replaceParams({ sec: 'x' }, 'nastavitve')   // ni ta zaslon
    expect(location.hash).toBe('#/prehrana?dan=2026-10-17')
    replaceParams({ dan: null }, 'prehrana')
    expect(location.hash).toBe('#/prehrana')
    await tick()
    expect(history.length).toBe(L0); expect(n).toBe(0)
    removeEventListener('hashchange', on)
  })
})

/* ---------- obvestila ---------- */
describe('G30–G32 — obvestila v vrsti, napaka ne izgine sama', () => {
  afterEach(() => { vi.useRealTimers(); while (store.getState().toasts?.length) store.dismissToast() })
  it('dva zapored sta oba vidna (prej je drugo prepisalo prvo); isto besedilo se ne podvoji; največ 3', () => {
    store.toast('Vožnja z Garmina: 837 kcal', 'info', 60_000)
    store.toast('Spanec, HRV in utrip: 3 dni z ure.', 'ok', 60_000)
    expect(store.getState().toasts!.map(t => t.msg)).toEqual(['Vožnja z Garmina: 837 kcal', 'Spanec, HRV in utrip: 3 dni z ure.'])
    expect(store.getState().toast!.msg).toBe('Spanec, HRV in utrip: 3 dni z ure.')
    store.toast('Vožnja z Garmina: 837 kcal', 'info', 60_000)
    expect(store.getState().toasts).toHaveLength(2)
    store.toast('Tretje', 'info', 60_000); store.toast('Četrto', 'info', 60_000)
    expect(store.getState().toasts).toHaveLength(store.MAX_TOASTS)
    const first = store.getState().toasts![0]!.id
    store.dismissToast(first)
    expect(store.getState().toasts!.some(t => t.id === first)).toBe(false)
  })
  it('napaka ostane, dokler je ne zapreš; uspeh izgine sam; Esc (brez id) zapre zadnje', () => {
    vi.useFakeTimers()
    store.toast('Ni prostora na napravi — obrok ni shranjen.', 'err', 4200)
    store.toast('Teža zabeležena.', 'ok', 4200)
    vi.advanceTimersByTime(60_000)
    expect(store.getState().toasts!.map(t => t.msg)).toEqual(['Ni prostora na napravi — obrok ni shranjen.'])
    store.dismissToast()
    expect(store.getState().toasts).toEqual([])
    expect(store.getState().toast).toBeNull()
  })
  it('obvestilo z gumbom ostane vsaj 8 s', () => {
    vi.useFakeTimers()
    store.toast('Nova različica je pripravljena.', 'info', 3000, { label: 'Osveži', run: () => undefined })
    vi.advanceTimersByTime(5000)
    expect(store.getState().toasts).toHaveLength(1)
    vi.advanceTimersByTime(3500)
    expect(store.getState().toasts).toHaveLength(0)
  })
})

/* ---------- usklajevanje ---------- */
describe('G07 — napaka usklajevanja z ukrepom', () => {
  const now = Date.parse('2026-10-18T14:30:00')
  const err = (kind: SyncStatus['kind'], at = now): SyncStatus => ({ state: 'error', at, msg: 'Oblak trenutno ni dosegljiv — poskusim znova.', kind })
  it('zavrnjen dostop: takoj, enkrat na dan, z gumbom za prijavo', () => {
    const r = syncNotice(err('denied', Date.parse('2026-10-18T14:02:00')), NOTICE_EMPTY, now, '2026-10-18')
    expect(r.err).toEqual({ denied: true, msg: 'Oblak ne sprejema sprememb od 14:02 — prijavi se znova. Podatki so na tej napravi.' })
    expect(syncNotice(err('denied'), r.mem, now + 60_000, '2026-10-18').err).toBeUndefined()
    expect(syncNotice(err('denied'), r.mem, now + 86_400_000, '2026-10-19').err).toBeDefined()
  })
  it('omrežje: šele po 10 min neprekinjeno (in s povezavo); uspeh ponastavi', () => {
    const a = syncNotice(err('network', now - 2 * 60_000), NOTICE_EMPTY, now, '2026-10-18')
    expect(a.err).toBeUndefined()
    const b = syncNotice({ state: 'pull', at: now }, a.mem, now + 1000, '2026-10-18')   // med poskusi ostane čas začetka
    const c = syncNotice(err('network', now + 9 * 60_000), b.mem, now - 2 * 60_000 + ERR_AFTER_MS + 1000, '2026-10-18')
    expect(c.err?.msg).toMatch(/^Oblak ne sprejema sprememb od 14:28\. Oblak trenutno ni dosegljiv/)
    expect(syncNotice(err('network', now - 20 * 60_000), NOTICE_EMPTY, now, '2026-10-18', false).err).toBeUndefined()   // brez povezave: pas zgoraj že pove
    const d = syncNotice({ state: 'idle', at: now }, a.mem, now, '2026-10-18')
    expect(d.mem.errSince).toBeNull()
    expect(syncNotice(err('clash'), NOTICE_EMPTY, now + ERR_AFTER_MS * 2, '2026-10-18').err).toBeUndefined()
  })
})

describe('G23 — skrajšana kopija v oblaku', () => {
  it('toCloud z veliko vadbami skrajša; povemo enkrat in v Nastavitvah', () => {
    const acts = Array.from({ length: 900 }, (_, i) => ride({ id: 'a' + i, notes: 'x'.repeat(1000) }))
    const r = toCloud({ profile: null, settings: null, activities: acts, plan: [], meals: [], checkins: [], tomb: {} }, 1, Date.parse(NOW))
    expect(r.level).toBeGreaterThanOrEqual(1)
    const t = trimmedOf(r.level)!
    expect(t.acts).toBeLessThanOrEqual(400)
    expect(trimmedOf(0)).toBeNull()
    const n = syncNotice({ state: 'idle', at: 1, trimmed: { acts: 400, mealDays: 120 } }, NOTICE_EMPTY, 1, TODAY)
    expect(n.trim).toBe('Oblak hrani zadnjih 400 vadb in 120 dni obrokov; vse ostane na tej napravi — izvozi kopijo.')
    expect(syncNotice({ state: 'idle', at: 2, trimmed: { acts: 400, mealDays: 120 } }, n.mem, 2, TODAY).trim).toBeUndefined()
    expect(syncNotice({ state: 'idle', at: 2 }, n.mem, 2, TODAY).mem.trimKey).toBe('400/120')   // ne vemo → ostane
    expect(cloudTrimText({ acts: 400, mealDays: 120 })).toContain('zadnjih 400 vadb in 120 dni obrokov')
    expect(cloudTrimText(null)).toBeNull()
  })
})

/* ---------- posodobitve, prijava, tema ---------- */
describe('G06 — nova različica z obvestilom', () => {
  it('po osvežitvi zaradi nove različice: »Posodobljeno na …«; brez spremembe nič', async () => {
    expect(updatedNoticeFor('3.49.0', '3.50.0')).toBe('Posodobljeno na različico 3.50.0.')
    expect(updatedNoticeFor(null, '3.50.0')).toBeNull()
    expect(updatedNoticeFor('3.50.0', '3.50.0')).toBeNull()
    expect(await checkForUpdate()).toBe('ni')   // brez service workerja (razvoj, preizkus)
    expect(updateCheckText('zadnja')).toBe('Imaš zadnjo različico.')
    expect(updateCheckText('nova')).toBe('Nova različica je pripravljena.')
  })
  it('prehod med zasloni ne uveljavi nove različice (prej tiha osvežitev 0,4 s po tapu)', () => {
    const s = src('src/app/sw.ts')
    expect(s).not.toMatch(/attempt\('nav'/)
    expect(s).toMatch(/onUpdateReady/)
  })
})

describe('G14 — Firebase ob zagonu samo s prijavo', () => {
  afterEach(() => { localStorage.removeItem(AUTH_FLAG) })
  it('odločitev: zastavica, račun ali seja → da; brez vsega → ne; ne vemo → da (kot prej)', () => {
    expect(shouldBootAuth({ hint: false, owner: false, idb: false })).toBe(false)
    expect(shouldBootAuth({ hint: true, owner: false, idb: false })).toBe(true)
    expect(shouldBootAuth({ hint: false, owner: true, idb: false })).toBe(true)
    expect(shouldBootAuth({ hint: false, owner: false, idb: true })).toBe(true)
    expect(shouldBootAuth({ hint: false, owner: false, idb: null })).toBe(true)
    expect(authHintSync()).toBe(false)
    markAuth(); expect(authHintSync()).toBe(true)
    localStorage.setItem(AUTH_FLAG, '0'); expect(authHintSync()).toBe(false)
    localStorage.setItem('firebase:authUser:k:[DEFAULT]', '{}'); expect(authHintSync()).toBe(true)
    localStorage.removeItem('firebase:authUser:k:[DEFAULT]')
  })
  it('zagon brez prijave: Firebase se ne naloži, prijava je znana (brez računa)', async () => {
    await repo.wipeAll()
    vi.stubGlobal('fetch', vi.fn(async () => new Response('', { status: 503 })))
    await store.boot()
    for (let i = 0; i < 30 && !store.getState().authKnown; i++) await new Promise(r => setTimeout(r, 10))
    expect(store.getState().authKnown).toBe(true)
    expect(store.getState().user).toBeNull()
    expect(FB.onAuth).not.toHaveBeenCalled()
    vi.unstubAllGlobals()
  })
})

describe('G43 — sonce/luna iz »Kot telefon«', () => {
  it('stalna izbira z razlago; iz stalne brez razlage', () => {
    expect(themeToggle('samodejno', false)).toEqual({ pref: 'svetlo', notice: 'Videz je zdaj stalno svetel. »Kot telefon« spet vklopiš v Nastavitvah → Videz.' })
    expect(themeToggle('samodejno', true).pref).toBe('temno')
    expect(themeToggle('temno', false)).toEqual({ pref: 'svetlo', notice: null })
  })
})

describe('G42 — dnevi v »Zadnjih 7 dni« zahodno od Greenwicha', () => {
  it('samo datum je polnoč UTC (v Los Angelesu še sobota); s T12:00 je lokalni dan', () => {
    const tz = process.env.TZ
    process.env.TZ = 'America/Los_Angeles'
    try {
      expect(new Date('2026-10-18').getDay()).toBe(6)   // stara pot: sobota
      expect(new Date('2026-10-18' + 'T12:00:00').getDay()).toBe(0)   // nedelja
    } finally { process.env.TZ = tz }
    expect(src('src/screens/Prehrana.tsx')).toMatch(/new Date\(w\.date \+ 'T12:00:00'\)\.getDay\(\)/)
  })
})

/* ---------- statično: CSS, manifest, index.html, paket ---------- */
describe('G01, G08, G19, G33, G34, G35 — CSS', () => {
  const css = src('src/styles/base.css'), tok = src('src/styles/tokens.css')
  it('G01 varno območje zgoraj: glava, pas brez povezave, zgornja vrstica, list', () => {
    expect(tok).toMatch(/--safe-top: env\(safe-area-inset-top, 0px\)/)
    expect(css).toMatch(/\.head \{ padding-top: calc\(16px \+ var\(--safe-top\)\); \}/)
    expect(css).toMatch(/\.offline \{ padding-top: calc\(7px \+ var\(--safe-top\)\); \}/)
    expect(css).toMatch(/\.dbar \{ height: calc\(62px \+ var\(--safe-top\)\); padding-top: var\(--safe-top\); \}/)
    expect(css).toMatch(/max-height: calc\(92dvh - var\(--safe-top\)\)/)
  })
  it('G08 tablica 600–899 px: stolpec do 560 px', () => {
    expect(css).toMatch(/@media \(min-width: 600px\) and \(max-width: 899px\) \{\s*\.screen > \.head, \.screen > \.scroll \{ padding-left: max\(18px, calc\(\(100% - 560px\) \/ 2\)\)/)
  })
  it('G19 pas brez povezave v eni vrstici', () => {
    expect(OFFLINE_BAR.length).toBeLessThanOrEqual(45)
    expect(css).toMatch(/\.offline \{ white-space: nowrap;/)
  })
  it('G33 razširjena površina dotika 40 px: glava, mikrofon, odtenki, summary', () => {
    expect(css).toMatch(/\.hbtn::after, \.mic::after, #n-videz button\[aria-pressed\]::after \{[^}]*min-width: 40px; min-height: 40px;/)
    expect(css).toMatch(/details\.more > summary::before[^{]*\{[^}]*height: 40px;/)
  })
  it('G34 »Preskoči na vsebino« in G35 osnova v rem', () => {
    expect(src('src/app/Shell.tsx')).toMatch(/className="skip-link" href="#vsebina"/)
    expect(src('src/app/Shell.tsx')).toMatch(/id="vsebina" tabIndex=\{-1\}/)
    expect(css).toMatch(/\.skip-link:focus \{ top:/)
    expect(css).toMatch(/html \{ font-size: 100%; \}/)
    expect(css).toMatch(/font-size: \.9375rem;/)
  })
})

describe('G15, G16, G40 — manifest in meta opis', () => {
  it('bližnjice: trening, obrok, plan; brez zaklepa pokončno', () => {
    const v = src('vite.config.ts')
    const urls = [...v.matchAll(/url: BASE \+ '(#\/[^']+)'/g)].map(m => m[1])
    expect(urls).toEqual(['#/vadba', '#/prehrana?opis=1', '#/plan'])
    expect(v).not.toMatch(/orientation: 'portrait'/)
  })
  it('meta opis ≤ 155 znakov', () => {
    const m = /<meta name="description" content="([^"]+)"/.exec(src('index.html'))!
    expect(m[1]!.length).toBeLessThanOrEqual(155)
  })
})

describe('G11 — začetni paket brez AI pozivov in pravil', () => {
  it('Danes, useAi, store in OverlayHost statično ne uvozijo actions, focus/coach in lista Pripomba', () => {
    expect(src('src/screens/Danes.tsx')).not.toMatch(/from '@\/domain\/ai\/actions'/)
    expect(src('src/ui/useAi.tsx')).not.toMatch(/from '@\/domain\/ai\/actions'/)
    expect(src('src/state/store.ts')).not.toMatch(/^import .*from '@\/domain\/focus\/coach'/m)
    expect(src('src/ui/OverlayHost.tsx')).not.toMatch(/^import .*FeedbackSheet/m)
    expect(src('src/ui/GoalCard.tsx')).toMatch(/from '@\/ui\/GoalSheetLazy'/)
    expect(src('src/ui/OffSeasonCard.tsx')).toMatch(/from '@\/ui\/GoalSheetLazy'/)
    expect(src('vite.config.ts')).toMatch(/return 'vendor'/)
  })
})
