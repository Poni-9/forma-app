// v3.48 — figure vaj brez fotografije (Blaž, 17. 10.: »sklece na kolenih, hoja … so čist narobe«): opornice so na tleh,
// gibanje je pravo; kardio in dvigi na prste imajo fotografije.
import { describe, it, expect } from 'vitest'
import { existsSync } from 'node:fs'
import { templateFor } from '../src/ui/figure/templates'
import { poseAt } from '../src/ui/figure/ExerciseFigure'
import { sideFk, FLOOR, type SidePose } from '../src/ui/figure/rig'
import { hasPhoto } from '../src/ui/figure/photos'

const at = (id: string, u: number) => sideFk(poseAt(templateFor(id), u) as SidePose)
const PH = Array.from({ length: 21 }, (_, i) => Math.min(0.999, i / 20))
const finite = (s: ReturnType<typeof sideFk>) => Object.values(s).every(p => Number.isFinite(p.x) && Number.isFinite(p.y))

describe('figure brez fotografije stojijo na tleh', () => {
  it('sklece na kolenih: kolena in dlani ves čas na tleh, golenici dvignjeni, zgoraj iztegnjene roke', () => {
    for (const u of PH) {
      const s = at('sklece-kolena', u)
      expect(finite(s)).toBe(true)
      expect(Math.abs(s.kneeL.y - (FLOOR + 2))).toBeLessThan(0.6)
      expect(Math.abs(s.wristL.y - (FLOOR + 3))).toBeLessThan(0.6)
      expect(s.ankleL.y).toBeLessThan(s.kneeL.y - 10)
    }
    const top = at('sklece-kolena', 0), bot = at('sklece-kolena', 0.5)
    expect(Math.hypot(top.wristL.x - top.shoulder.x, top.wristL.y - top.shoulder.y)).toBeGreaterThan(48)   // roke iztegnjene
    expect(bot.shoulder.y - top.shoulder.y).toBeGreaterThan(20)                                           // prsi gredo proti tlom
  })
  it('pike sklece: dlani in prsti na tleh, boki nad rameni, glava gre proti tlom', () => {
    for (const u of PH) {
      const s = at('pike', u)
      expect(Math.abs(s.wristL.y - (FLOOR + 3))).toBeLessThan(0.6)
      expect(Math.abs(s.ankleL.y - (FLOOR - 4))).toBeLessThan(0.6)
      expect(s.pelvis.y).toBeLessThan(s.shoulder.y)
    }
    expect(at('pike', 0.5).head.y - at('pike', 0).head.y).toBeGreaterThan(5)
  })
  it('burpee: v počepu in deski dlani na tleh, v deski stopala zadaj na tleh', () => {
    const sq = at('burpee', 0.16), pl = at('burpee', 0.4)
    expect(Math.abs(sq.wristL.y - (FLOOR + 3))).toBeLessThan(0.6)
    expect(Math.abs(pl.wristL.y - (FLOOR + 3))).toBeLessThan(0.6)
    expect(pl.ankleL.x).toBeLessThan(pl.pelvis.x - 40)
    expect(Math.max(pl.toeL.y, pl.ankleL.y)).toBeGreaterThan(FLOOR - 1)
    for (const u of PH) expect(finite(at('burpee', u))).toBe(true)
  })
  it('veslanje z elastiko: stoji (stopala na tleh), dlani v višini prsi, komolci gredo za telo', () => {
    for (const u of PH) { const s = at('veslanje-e', u); expect(Math.abs(s.ankleL.y - FLOOR)).toBeLessThan(0.6); expect(s.wristL.y).toBeLessThan(s.pelvis.y - 10) }
    const pull = at('veslanje-e', 0.5)
    expect(pull.elbowL.x).toBeLessThan(pull.shoulder.x)
  })
  it('drža čolnička: križ na tleh, ramena in iztegnjene noge od tal', () => {
    const s = at('coln', 0.25)
    expect(s.pelvis.y).toBeGreaterThan(FLOOR - 3)
    expect(s.shoulder.y).toBeLessThan(FLOOR - 8)
    expect(s.ankleL.y).toBeLessThan(FLOOR - 15)
  })
})

describe('fotografije namesto figur', () => {
  it('tek, hoja, kolo in dvigi na prste imajo fotografiji (začetni in končni položaj)', () => {
    for (const id of ['tek', 'hoja', 'kolo', 'prsti']) {
      expect(hasPhoto(id)).toBe(true)
      for (const i of [0, 1]) expect(existsSync(`public/vaje/${id}-${i}.webp`)).toBe(true)
    }
  })
})
