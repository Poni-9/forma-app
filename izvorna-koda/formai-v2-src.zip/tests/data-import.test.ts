import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach } from 'vitest'

const h = vi.hoisted(() => ({ json: {} as unknown, prompts: [] as string[] }))
vi.mock('../src/domain/ai/client', () => {
  class AiError extends Error { kind: string; constructor(kind: string, m: string) { super(m); this.kind = kind } }
  return {
    AiError,
    askText: async () => '',
    askJson: async (parts: { text?: string }[]) => { h.prompts.push(parts.map(p => p.text || '').join('\n')); return JSON.parse(JSON.stringify(h.json)) },
  }
})
vi.mock('../src/domain/ai/image', () => ({ fileToBase64Resized: async () => ({ data: 'AAAA', mime: 'image/jpeg', thumb: '' }), exifStamp: async () => null }))

import * as repo from '../src/data/repo'
import { getKV, setKV, pruneKV, KV, db, resetDbForTests } from '../src/data/db'
import { migrateFromV1, finishLegacyV1, carryIntervalsFromV1, repairAfterPreview } from '../src/data/migrate'
import { deriveFlags, isStravaArchive, isStravaFileText, aiAllowed, sourceLabel } from '../src/domain/import/provenance'
import { parseGpx, toActivity } from '../src/domain/import/parsers'
import { activityFromShot } from '../src/domain/ai/actions'
import { todayIso, addDays } from '../src/domain/training/load'
import type { Activity, Profile } from '../src/domain/types'

beforeEach(async () => { await repo.wipeAll(); localStorage.clear(); h.prompts.length = 0 })

describe('dvojniki pri hkratnem uvozu', () => {
  it('samodejni in ročni uvoz istih voženj hkrati → vsaka vožnja enkrat', async () => {
    const mk = (tag: string) => Array.from({ length: 5 }, (_, i) => ({ id: tag + i, source: 'intervals', originHint: 'GARMIN', sport: 'kolo', date: '2026-09-2' + i, start: `2026-09-2${i}T07:00:00.000Z`, name: 'Vožnja', durationMin: 90, distKm: 40, aiEligible: true, geoRetain: true, ext: { intervalsId: 'i' + i }, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() })) as Activity[]
    const [a, b] = await Promise.all([repo.addActivities(mk('auto')), repo.addActivities(mk('manual'))])
    expect(a.added + b.added).toBe(5)
    expect(await repo.allActivities()).toHaveLength(5)
    // isti zapis dvakrat v enem paketu
    await repo.wipeAll()
    const r = await repo.addActivities([...mk('x'), ...mk('y')])
    expect(r.added).toBe(5); expect(await repo.allActivities()).toHaveLength(5)
  })
  it('zaklep uvoza: drugi uvoz počaka prvega', async () => {
    const order: string[] = []
    const slow = repo.withImportLock(async () => { order.push('a1'); await new Promise(r => setTimeout(r, 20)); order.push('a2') })
    const fast = repo.withImportLock(async () => { order.push('b') })
    await Promise.all([slow, fast])
    expect(order).toEqual(['a1', 'a2', 'b'])
  })
})

describe('Stravin izvor: arhiv, GPX, posnetek zaslona → nikoli v AI', () => {
  it('Stravin izvoz (activities.csv + activities/…) je prepoznan, Garminov ne', () => {
    expect(isStravaArchive(['activities.csv', 'profile.csv', 'activities/12345678901.fit.gz', 'activities/12345678902.gpx', 'media/'])).toBe(true)
    expect(isStravaArchive(['export_123/activities.csv', 'export_123/activities/987.tcx.gz', 'export_123/bikes.csv'])).toBe(true)
    expect(isStravaArchive(['DI_CONNECT/DI-Connect-Fitness/x_summarizedActivities.json', 'DI_CONNECT/DI-Connect-Uploaded-Files/UploadedFiles_0-_Part1.zip'])).toBe(false)
    expect(isStravaArchive(['123_ACTIVITY.fit', 'Morning_Ride.gpx'])).toBe(false)
  })
  it('GPX iz Strave (creator StravaGPX) → originHint STRAVA, aiEligible false; sled ostane na napravi', async () => {
    const gpx = `<?xml version="1.0"?><gpx creator="StravaGPX Android" version="1.1" xmlns="http://www.topografix.com/GPX/1/1"><trk><name>Jutranja</name><trkseg>
      <trkpt lat="46.0" lon="14.0"><time>2026-09-20T07:00:00Z</time></trkpt><trkpt lat="46.01" lon="14.01"><time>2026-09-20T07:30:00Z</time></trkpt><trkpt lat="46.02" lon="14.02"><time>2026-09-20T08:00:00Z</time></trkpt></trkseg></trk></gpx>`
    expect(isStravaFileText(gpx)).toBe(true)
    const p = await parseGpx(new Blob([gpx]), 'jutranja.gpx')
    expect(p.originHint).toBe('STRAVA')
    const a = toActivity(p, 'file', null)
    expect(a.aiEligible).toBe(false); expect(aiAllowed(a)).toBe(false); expect(a.geoRetain).toBe(true)
    expect(sourceLabel(a)).toBe('Datoteka iz Strave')
    const own = toActivity({ ...p, originHint: null }, 'file', null)
    expect(own.aiEligible).toBe(true)
    expect(deriveFlags('archive', 'STRAVA').aiEligible).toBe(false)
    expect(deriveFlags('screenshot', 'STRAVA')).toEqual({ aiEligible: false, geoRetain: false, expiresAt: null })
  })
  it('posnetek zaslona: aplikacija Strava → trener ne vidi; datum v prihodnosti → danes; današnji datum je v pozivu', async () => {
    const p = { aiConsentAt: new Date().toISOString(), weightKg: 75 } as Profile
    const file = new File(['x'], 'shot.png', { type: 'image/png' })
    const today = todayIso()
    h.json = { app: 'strava', sport: 'kolo', datum: addDays(today, 30), trajanje_min: 90, razdalja_km: 40, ime: 'Morning Ride', zanesljivost: 'visoka' }
    const a = await activityFromShot(p, file)
    expect(h.prompts[0]).toContain(`Današnji datum je ${today}`)
    expect(h.prompts[0]).toMatch(/"app"/)
    expect(a.aiEligible).toBe(false); expect(a.originHint).toBe('STRAVA'); expect(aiAllowed(a)).toBe(false)
    expect(a.date).toBe(today); expect(a.notes).toMatch(/v prihodnosti/)
    h.json = { app: 'garmin', sport: 'kolo', datum: addDays(today, -2), trajanje_min: 60, ime: 'Vožnja', zanesljivost: 'srednja' }
    const g = await activityFromShot(p, file)
    expect(g.aiEligible).toBe(true); expect(g.date).toBe(addDays(today, -2)); expect(g.notes).toBeUndefined()
  })
})

describe('prva različica (localStorage): po prevzemu počisti, izbris na napravi ne uvozi znova', () => {
  const v1 = () => {
    localStorage.setItem('forma_trener_v1', JSON.stringify({ settings: { profile: { ime: 'Blaž', teza: 78 } }, icu: { athleteId: 'i1', apiKey: 'SKRIVNOST' }, geminiKey: 'AIza-STAR', rides: [{ id: 'r1', source: 'strava', date: '2026-09-20', dist: 40, time: 90, name: 'Strava ride' }] }))
    localStorage.setItem('kalorije_v1', JSON.stringify({ days: {} }))
    localStorage.setItem('forma_onb_done', '1'); localStorage.setItem('forma_chat', '[]'); localStorage.setItem('forma_stash_u1', '{}'); localStorage.setItem('formai_pwa_ne', '1')
    localStorage.setItem('formai.pilot', 'KODA')   // ključ nove različice ostane
  }
  it('Stravine vožnje in API ključi izginejo iz localStorage šele, ko so vsi koraki prevzema opravljeni', async () => {
    v1()
    expect((await migrateFromV1())?.ran).toBe(true)
    expect(await finishLegacyV1()).toBe(0)                  // repair in carry še nista tekla
    await repairAfterPreview(); await carryIntervalsFromV1()
    expect((await repo.loadSettings()).intervals?.apiKey).toBe('SKRIVNOST')
    expect(await finishLegacyV1()).toBe(6)
    for (const k of ['forma_trener_v1', 'kalorije_v1', 'forma_onb_done', 'forma_chat', 'forma_stash_u1', 'formai_pwa_ne']) expect(localStorage.getItem(k)).toBeNull()
    expect(localStorage.getItem('formai.pilot')).toBe('KODA')
    expect(localStorage.getItem('formai.app')).toBe('1')     // pristajalna stran še vedno ve, da je uporabnik
  })
  it('»Izbriši na napravi« pobriše tudi ključe prve različice → ob naslednjem zagonu se nič ne uvozi znova', async () => {
    v1()
    await repo.wipeAll()
    expect(localStorage.getItem('forma_trener_v1')).toBeNull()
    const r = await migrateFromV1()
    expect(r?.ran).toBe(false)
    expect(await repo.allActivities()).toHaveLength(0)
    expect(await carryIntervalsFromV1()).toBe(false)
  })
})

describe('shramba na napravi', () => {
  it('stari predpomnjeni odgovori AI in poskusi tras (nad 30 dni) se pobrišejo', async () => {
    const now = Date.parse('2026-09-25T12:00:00Z')
    for (const k of ['ai.daily.2026-07-01', 'ai.week.2026-06-29', 'routes.retry.2026-08-01', 'ai.daily.2026-09-20', 'routes.retry.2026-09-25', 'profile']) await setKV(k, 'x')
    expect(await pruneKV(now)).toBe(3)
    expect(await getKV('ai.daily.2026-07-01')).toBeUndefined()
    expect(await getKV('ai.daily.2026-09-20')).toBe('x')
    expect(await getKV(KV.profile)).toBe('x')
  })
  it('potekle Stravine vožnje se pobrišejo (vrne število — store nato uskladi)', async () => {
    const past = new Date(Date.now() - 1000).toISOString()
    await repo.addActivities([{ id: 'x', source: 'strava_api', sport: 'kolo', date: '2026-09-01', name: 'x', aiEligible: false, geoRetain: false, expiresAt: past, createdAt: past, updatedAt: past, distKm: 5 } as Activity])
    expect(await repo.purgeExpired()).toBe(1)
  })
  it('privzeti profil nima deficita (uvod ga nastavi samo za hujšanje)', () => {
    expect(repo.defaultProfile().deficit).toBe(0)
  })
})

describe('IndexedDB', () => {
  it('neuspelo odpiranje se ne zapomni — naslednji klic odpre bazo', async () => {
    const real = globalThis.indexedDB
    let fail = true
    resetDbForTests()
    ;(globalThis as Record<string, unknown>).indexedDB = { open: (...a: Parameters<IDBFactory['open']>) => { if (fail) { fail = false; throw new Error('blokirano') } return real.open(...a) } }
    try {
      await expect(db()).rejects.toThrow('blokirano')
      const d = await db()
      expect(d.objectStoreNames.contains('kv')).toBe(true)
    } finally { (globalThis as Record<string, unknown>).indexedDB = real; resetDbForTests() }
  })
})
