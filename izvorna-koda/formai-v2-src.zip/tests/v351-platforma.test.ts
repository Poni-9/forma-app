// v3.51 PLATFORMA: profil ob branju, premor iz oblaka, obvestila, shramba, spremembe načrta v oblaku in kopiji,
// izbris, odjava, pripombe ob povezavi, Plan iz naslova, pas brez povezave, CSS, manifest, pristajalna stran, paket.
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { readFileSync, existsSync, readdirSync, statSync } from 'node:fs'

vi.hoisted(() => { vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date('2026-10-21T10:00:00')) })
const FB = vi.hoisted(() => ({ signOutNow: vi.fn(async () => undefined) }))
vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: FB.signOutNow,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
const u = vi.hoisted(() => ({ undo: null as null | (() => unknown), msg: '' }))
vi.mock('../src/ui/Confirm', () => ({ undoToast: (msg: string, fn: () => unknown) => { u.msg = msg; u.undo = fn }, useHidden: () => new Set() }))
const F = vi.hoisted(() => ({ flush: vi.fn(async () => 0), pilot: vi.fn(async () => undefined) }))
vi.mock('../src/data/feedback', async orig => ({ ...(await orig<typeof import('../src/data/feedback')>()), flushFeedback: F.flush }))
vi.mock('../src/data/pilot', async orig => ({ ...(await orig<typeof import('../src/data/pilot')>()), flushPilot: F.pilot }))

import { normalizeProfile } from '../src/data/normalize'
import { fromCloud, toCloud } from '../src/data/sync'
import { parseBackup } from '../src/data/backup'
import { mergeChanges, mergeState, type SyncState } from '../src/data/merge'
import * as repo from '../src/data/repo'
import { setKV, getKV } from '../src/data/db'
import * as store from '../src/state/store'
import { PAUSE_MAX_DAYS, activePause } from '../src/domain/training/pause'
import { offlineMore, avatarLabel } from '../src/app/Shell'
import { planViewOf, PLAN_OUTSIDE } from '../src/screens/Plan'
import { vadbaRestText as restText } from '../src/screens/Vadba'
import { exportNote } from '../src/ui/PlatformRows'
import { watchOtherTabs, THEME_KEY } from '../src/ui/theme'
import { isChunkError } from '../src/app/chunk'
import { isImageFile, NOT_IMAGE } from '../src/ui/PhotoInput'
import type { Profile } from '../src/domain/types'

const src = (f: string) => readFileSync(new URL('../' + f, import.meta.url), 'utf8')
const T = '2026-10-21'
const NOW = '2026-10-21T08:00:00.000Z'
const prof = (o: Record<string, unknown> = {}) => ({ ...repo.defaultProfile(), name: 'Blaž', onboardingDone: true, createdAt: NOW, updatedAt: NOW, ...o }) as Profile
const empty = (o: Partial<SyncState> = {}): SyncState => ({ profile: null, settings: null, activities: [], plan: [], meals: [], checkins: [], tomb: {}, ...o })

describe('G02 + G14 — pokvarjen profil se popravi ob branju (baza, oblak, kopija)', () => {
  it('races ni seznam → [], premor s številko → null; veljaven profil ostane isti predmet', () => {
    const ok = prof({ races: [{ id: 'r1', name: 'Franja', date: '2027-06-13', prio: 'A' }], weekPause: { from: T, to: '2026-10-25', mode: 'vse' } })
    expect(normalizeProfile(ok)).toBe(ok)
    const bad = normalizeProfile(prof({ races: { a: 1 }, weekPause: { to: 20261030 }, sick: 'da', event: { name: 'X' }, gear: 'kolo', focus: { sports: 'tek', sessions: {} } }))
    expect(bad.races).toEqual([])
    expect(bad.weekPause).toBeNull()
    expect(bad.sick).toBeNull()
    expect(bad.event).toBeNull()
    expect(bad.gear).toEqual({ bikeOutdoor: true, trainer: false, noBike: false })
    expect(bad.focus!.sports).toEqual([]); expect(bad.focus!.sessions).toEqual([]); expect(bad.focus!.aims).toEqual([])
    // tekma brez id-ja in s prioriteto kot številko se popravi, brez datuma izpade
    const r = normalizeProfile(prof({ races: [{ name: 'B', date: '2027-05-01', prio: 2 }, { name: 'brez datuma' }] })).races!
    expect(r).toHaveLength(1); expect(r[0]).toMatchObject({ name: 'B', date: '2027-05-01', prio: 'C' }); expect(typeof r[0]!.id).toBe('string')
  })
  it('oblak in kopija vrneta normaliziran profil (prej `races: {a:1}` sesul pet zaslonov)', () => {
    const p = prof({ races: { a: 1 }, weekPause: { to: 20261030 } })
    const c = fromCloud({ profile: p } as never).profile!
    expect(c.races).toEqual([]); expect(c.weekPause).toBeNull()
    const b = parseBackup(JSON.stringify({ version: 2, profile: p })).state.profile!
    expect(b.races).toEqual([]); expect(b.weekPause).toBeNull()
  })
  it('G14: premor 60 dni iz oblaka/kopije se odreže na 14 dni', () => {
    const w = { from: '2026-10-20', to: '2026-12-22', mode: 'vse' }
    expect(activePause({ weekPause: w } as never, T)!.to).toBe('2026-12-22')            // stara pot: dva meseca
    const c = fromCloud({ profile: prof({ weekPause: w }) } as never).profile!
    expect(c.weekPause!.to).toBe('2026-11-02')
    expect(14).toBe(PAUSE_MAX_DAYS)
    const b = parseBackup(JSON.stringify({ version: 2, profile: prof({ weekPause: w }) })).state.profile!
    expect(b.weekPause!.to).toBe('2026-11-02')
  })
  it('baza: loadProfile popravi shranjen pokvarjen profil', async () => {
    await repo.wipeAll()
    await setKV('profile', prof({ races: { a: 1 } }))
    expect((await repo.loadProfile()).races).toEqual([])
  })
})

describe('G37 — spremembe načrta v oblaku in kopiji', () => {
  const a = [{ at: '2026-10-21T09:00:00.000Z', text: 'Premor do nedelje.', auto: false }, { at: '2026-10-20T09:00:00.000Z', text: 'Sestavljen teden.', auto: true }]
  const b = [{ at: '2026-10-21T09:00:00.000Z', text: 'Premor do nedelje.', auto: false }, { at: '2026-10-21T11:00:00.000Z', text: 'Prestavljeno na četrtek.', auto: true }]
  it('mergeChanges: unija brez dvojnikov, najnovejše prve, simetrično, največ 40', () => {
    const m = mergeChanges(a, b)
    expect(m.map(x => x.text)).toEqual(['Prestavljeno na četrtek.', 'Premor do nedelje.', 'Sestavljen teden.'])
    expect(mergeChanges(b, a)).toEqual(m)
    const many = Array.from({ length: 50 }, (_, i) => ({ at: `2026-10-${String(1 + (i % 28)).padStart(2, '0')}T${String(i % 24).padStart(2, '0')}:00:00.000Z`, text: `s${i}`, auto: true }))
    expect(mergeChanges(many, [])).toHaveLength(40)
  })
  it('toCloud nosi spremembe (prazne ne), fromCloud jih prebere, mergeState jih združi', () => {
    expect(toCloud(empty({ changes: a }), 1).payload.changes).toEqual(a)
    expect('changes' in toCloud(empty({ changes: [] }), 1).payload).toBe(false)
    expect(fromCloud({ changes: [...b, { at: 5 }] } as never).changes).toEqual(b)
    expect(mergeState(empty({ changes: a }), empty({ changes: b }), Date.now()).changes).toHaveLength(3)
  })
  it('izvoz in uvoz kopije: spremembe so zraven in se vrnejo na napravo', async () => {
    await repo.wipeAll()
    await setKV('plan.changes', a)
    const ex = await repo.exportAll()
    expect(ex.changes).toEqual(a)
    await setKV('plan.changes', [])
    const { restoreBackup } = await import('../src/data/backup')
    const r = await restoreBackup(parseBackup(JSON.stringify({ version: 2, profile: prof(), changes: b })))
    expect(r.changed).toBe(true)
    expect(((await getKV<unknown[]>('plan.changes')) || []).length).toBe(2)
  })
})

describe('G38 — besedilo izvoza pove, kaj je v datoteki', () => {
  it('brez sledi: našteje izjeme (podatki z ure, trase, GPS sledi); s sledmi sledi niso izjema', () => {
    expect(exportNote(false)).toMatch(/načrt s spremembami/)
    expect(exportNote(false)).toMatch(/brez ključa intervals\.icu, podatkov z ure, knjižnice tras in GPS sledi/)
    expect(exportNote(true)).not.toMatch(/in GPS sledi\.$/)
    expect(exportNote(true)).toMatch(/vadbe z GPS sledmi/)
  })
})

describe('G12 — napaka ostane, ko pridejo tri druga obvestila', () => {
  afterEach(() => { while (store.getState().toasts?.length) store.dismissToast() })
  it('izpade najstarejše, ki ni napaka', () => {
    store.toast('Oblak ne sprejema sprememb.', 'err')
    store.toast('A', 'info'); store.toast('B', 'ok'); store.toast('C', 'info')
    expect(store.getState().toasts!.map(t => `${t.kind}:${t.msg}`)).toEqual(['err:Oblak ne sprejema sprememb.', 'ok:B', 'info:C'])
  })
  it('trimToasts: samo napake → gre najstarejša, najnovejše ostane', () => {
    const t = (id: number, kind: 'err' | 'info') => ({ id, kind, msg: String(id) })
    expect(store.trimToasts([t(1, 'err'), t(2, 'err'), t(3, 'err'), t(4, 'info')]).map(x => x.id)).toEqual([2, 3, 4])
  })
})

describe('G05 — napaka shrambe ima sporočilo', () => {
  afterEach(() => { while (store.getState().toasts?.length) store.dismissToast() })
  it('QuotaExceededError → »Ni prostora na napravi …« (enkrat na 10 s); druga napaka ni napaka shrambe', () => {
    const q = Object.assign(new Error('Kvota presežena'), { name: 'QuotaExceededError' })
    expect(store.noteSaveFailed(q, 1_000_000)).toBe(true)
    expect(store.getState().toasts!.at(-1)).toMatchObject({ kind: 'err', msg: expect.stringMatching(/^Ni prostora na napravi — sprememba ni shranjena\./) })
    expect(store.noteSaveFailed(q, 1_005_000)).toBe(true)
    expect(store.getState().toasts!.filter(t => /Ni prostora/.test(t.msg))).toHaveLength(1)
    expect(store.saveFailedMsg(Object.assign(new Error('The play() request was interrupted'), { name: 'InvalidStateError' }))).toBeNull()
    expect(store.saveFailedMsg(Object.assign(new Error('The database connection is closing.'), { name: 'InvalidStateError' }))).toMatch(/Shramba na napravi ne deluje/)
    expect(store.saveFailedMsg(new Error('Failed to fetch'))).toBeNull()
  })
})

describe('G41 — »Razveljavi« premora potrdi', () => {
  afterEach(() => { while (store.getState().toasts?.length) store.dismissToast() })
  it('po razveljavitvi obvestilo »Premor razveljavljen …«', async () => {
    await repo.wipeAll(); localStorage.clear(); await store.reloadAll()
    await store.updateProfile(prof({ weekPause: null }))
    await store.setWeekPause('vse')
    expect(u.undo).toBeTruthy()
    await u.undo!()
    expect(store.getState().toasts!.at(-1)!.msg).toBe(store.UNDO_PAUSE_DONE)
    expect(store.UNDO_PAUSE_DONE).toMatch(/razveljavljen/)
  })
})

describe('G39 — »Izbriši na napravi« pobriše tudi ključe v brskalniku', () => {
  it('formai.auth, tema in obvestila gredo; tuji ključi ostanejo', async () => {
    localStorage.setItem('formai.auth', '1'); localStorage.setItem('formai.theme', 'svetlo'); localStorage.setItem('formai.syncNotice', '{}'); localStorage.setItem('drugo', 'x')
    sessionStorage.setItem('formai.chunkReload', '1')
    await repo.wipeAll()
    expect(localStorage.getItem('formai.auth')).toBeNull()
    expect(localStorage.getItem('formai.theme')).toBeNull()
    expect(localStorage.getItem('formai.syncNotice')).toBeNull()
    expect(sessionStorage.getItem('formai.chunkReload')).toBeNull()
    expect(localStorage.getItem('drugo')).toBe('x')
  })
})

describe('G40 — odjava brez povezave ne odjavi tiho', () => {
  afterEach(() => { while (store.getState().toasts?.length) store.dismissToast() })
  it('usklajevanje v napaki: ni odjave, obvestilo z »Odjavi vseeno«, ki odjavi', async () => {
    FB.signOutNow.mockClear()
    ;(store.getState() as { sync: unknown }).sync = { state: 'error', msg: 'Oblak ni dosegljiv' }
    await store.signOut()
    expect(FB.signOutNow).not.toHaveBeenCalled()
    const t = store.getState().toasts!.at(-1)!
    expect(t.msg).toBe(store.SIGNOUT_UNSYNCED)
    expect(t.kind).toBe('err')
    expect(t.action!.label).toBe('Odjavi vseeno')
    t.action!.run()
    await vi.waitFor(() => expect(FB.signOutNow).toHaveBeenCalledTimes(1))
  })
  it('usklajevanje izklopljeno (ni računa za oblak): odjava kot prej', async () => {
    FB.signOutNow.mockClear()
    ;(store.getState() as { sync: unknown }).sync = { state: 'off' }
    await store.signOut()
    expect(FB.signOutNow).toHaveBeenCalledTimes(1)
  })
})

describe('G31 — pripomba gre, ko se povezava vrne', () => {
  it('onlineFlush: po 2 s pošlje pripombe in odgovore testnega programa, največ enkrat na minuto', async () => {
    F.flush.mockClear(); F.pilot.mockClear()
    store.onlineFlush(10_000_000, 0)
    await vi.waitFor(() => expect(F.flush).toHaveBeenCalledTimes(1))
    expect(F.pilot).toHaveBeenCalledTimes(1)
    store.onlineFlush(10_030_000, 0)
    await new Promise(r => setTimeout(r, 20))
    expect(F.flush).toHaveBeenCalledTimes(1)
    store.onlineFlush(10_070_000, 0)
    await vi.waitFor(() => expect(F.flush).toHaveBeenCalledTimes(2))
  })
})

describe('G42, G44 — pas brez povezave in stanje usklajevanja v besedilu', () => {
  it('brez računa in ure ni obljube; z računom »Uskladim«; z uro »uvozim«', () => {
    expect(offlineMore({ user: null, intervals: null })).toBe('')
    expect(offlineMore({ user: { uid: 'u' }, intervals: null })).toBe('Uskladim, ko se povezava vrne.')
    expect(offlineMore({ user: null, intervals: { athleteId: 'i1' } })).toBe('Vožnje z ure uvozim, ko se povezava vrne.')
    expect(offlineMore({ user: { uid: 'u' }, intervals: { athleteId: 'i1' } })).toBe('Uskladim in uvozim, ko se povezava vrne.')
  })
  it('ime avatarja pove napako usklajevanja', () => {
    expect(avatarLabel('error', { uid: 'u' })).toBe('Nastavitve in profil — usklajevanje ne dela')
    expect(avatarLabel('idle', { uid: 'u' })).toBe('Nastavitve in profil — usklajeno')
    expect(avatarLabel('off', null)).toBe('Nastavitve in profil')
  })
})

describe('G24, G25 — Plan iz naslova', () => {
  it('neveljaven ali predaleč dan → »Ta teden« (in opozorilo pri predaleč); prej +16 dni »Naslednji«', () => {
    expect(planViewOf({ dan: 'abc' }, T)).toMatchObject({ view: 'ta', dan: null, outside: false, bad: true })
    expect(planViewOf({ dan: '2026-11-08' }, T)).toMatchObject({ view: 'ta', outside: true })
    expect(planViewOf({ dan: '2026-10-02' }, T)).toMatchObject({ view: 'ta', outside: true })
    expect(planViewOf({ dan: '2026-10-28' }, T)).toMatchObject({ view: 'naslednji', dan: '2026-10-28', outside: false })
    expect(planViewOf({ dan: '2026-10-14' }, T)).toMatchObject({ view: 'prejsnji' })
    expect(PLAN_OUTSIDE).toMatch(/prejšnji, ta in naslednji teden/)
  })
  it('?pogled=dva ostane po osvežitvi (prednost pred dnevom)', () => {
    expect(planViewOf({ pogled: 'dva' }, T).view).toBe('dva')
    expect(planViewOf({ pogled: 'dva', dan: '2026-10-28' }, T).view).toBe('dva')
    expect(planViewOf({ pogled: 'xyz' }, T).view).toBe('ta')
  })
  it('Plan piše pogled v naslov in ohrani ga pri izbiri dneva', () => {
    const s = src('src/screens/Plan.tsx')
    expect(s).toMatch(/replaceParams\(\{ pogled: k === 'ta' \? null : k \}, 'plan'\)/)
    expect(s).toMatch(/replaceParams\(\{ dan: date, sec: null \}, 'plan'\)/)
    expect(s).not.toMatch(/`#\/plan\?dan=\$\{date\}`/)
  })
})

describe('G43 — povezava na dan premora pove, kateri dan in zakaj', () => {
  const vadbaRestText = (d: Parameters<typeof restText>[0], t: string) => restText(d, t)?.replace(/\u00a0/g, ' ') ?? null
  it('jutrišnji premor: »Četrtek, 22. 10.: premor po tvoji izbiri — treninga ni.« (ne »Danes ni treninga«)', () => {
    expect(vadbaRestText({ kind: 'pocitek', title: 'Premor', date: '2026-10-22' }, T)).toBe('Četrtek, 22. 10.: premor po tvoji izbiri — treninga ni.')
    expect(vadbaRestText({ kind: 'pocitek', title: 'Premor — brez kolesa', date: T }, T)).toBe('Danes: premor po tvoji izbiri — treninga ni.')
    expect(vadbaRestText({ kind: 'pocitek', title: 'Počitek', date: '2026-10-24' }, T)).toBe('Sobota, 24. 10.: počitek — treninga ni.')
    expect(vadbaRestText({ kind: 'kolo', title: 'Z2', date: T }, T)).toBeNull()
    expect(vadbaRestText(null, T)).toBeNull()
  })
})

describe('G23 — tema iz drugega zavihka', () => {
  it('dogodek storage za formai.theme zamenja temo brez osvežitve', () => {
    watchOtherTabs()
    document.documentElement.dataset.theme = 'dark'
    localStorage.setItem(THEME_KEY, 'svetlo')
    window.dispatchEvent(new StorageEvent('storage', { key: THEME_KEY, newValue: 'svetlo' }))
    expect(document.documentElement.dataset.theme).toBe('light')
    window.dispatchEvent(new StorageEvent('storage', { key: THEME_KEY, newValue: 'temno' }))
    expect(document.documentElement.dataset.theme).toBe('dark')
    localStorage.removeItem(THEME_KEY)
  })
})

describe('G15, G28 — prepoznava napake prenosa in datoteke, ki ni slika', () => {
  it('isChunkError', () => {
    expect(isChunkError(new TypeError('Failed to fetch dynamically imported module: https://formai.si/assets/Plan-x.js'))).toBe(true)
    expect(isChunkError(new TypeError('Importing a module script failed.'))).toBe(true)
    expect(isChunkError(new TypeError('x is not iterable'))).toBe(false)
  })
  it('isImageFile: PDF in .txt ne, HEIC brez vrste da', () => {
    expect(isImageFile({ type: 'application/pdf', name: 'trening.pdf' })).toBe(false)
    expect(isImageFile({ type: 'text/plain', name: 'a.txt' })).toBe(false)
    expect(isImageFile({ type: '', name: 'IMG_1.HEIC' })).toBe(true)
    expect(isImageFile({ type: 'image/png', name: 'x' })).toBe(true)
    expect(NOT_IMAGE).toMatch(/^To ni slika/)
  })
})

/* ---------- statično: CSS, manifest, index.html, pristajalna stran, paket ---------- */
describe('CSS (G06, G09, G21, G22, G45, G19)', () => {
  const css = src('src/styles/base.css')
  it('G06: noben :focus-visible nima obrobe v limeti (var(--accent)) — svetla tema 1,3–1,5 : 1', () => {
    const bad = [...css.matchAll(/[^{}]*:focus-visible[^{]*\{[^}]*outline:[^;}]*var\(--accent\)[;\s}]/g)].map(m => m[0].trim().slice(0, 60))
    expect(bad).toEqual([])
  })
  it('G09: vsiljene barve — čip ima rob, izbran čip Highlight', () => {
    expect(css).toMatch(/@media \(forced-colors: active\) \{[\s\S]*?\.chip, \.seg button \{ border: 1px solid ButtonText; \}[\s\S]*?\.chip\.on, \.chip\[aria-pressed="true"\][^{]*\{[^}]*background: Highlight/)
  })
  it('G21: razmik med vrsticami majhnih čipov ≥ 14 px; G22: »Preveri posodobitve« 40 px', () => {
    expect(css).toMatch(/\.row:has\(> \.chip\.sm\.click\) \{ row-gap: 14px !important; \}/)
    expect(css).toMatch(/button\.lnk-hit \{[^}]*min-height: 40px;/)
  })
  it('G45: obvestila v časovnem vrstnem redu (order po id), G19: naslov lista h2', () => {
    expect(css).toMatch(/\.toast-stack \.toast-live:not\(:empty\) \{ display: contents; \}/)
    expect(src('src/ui/Toasts.tsx')).toMatch(/style=\{\{ order: t\.id \}\}/)
    expect(src('src/ui/WeekPauseSheet.tsx')).toMatch(/<h2 className="sheet-t">Ta teden …<\/h2>/)
  })
})

describe('Manifest in zagon (G32, G33, G34, G35)', () => {
  const v = src('vite.config.ts'), html = src('index.html')
  it('G32: slike zaslona (vsaj 2, ena »narrow«, ena »wide«), datoteke obstajajo', () => {
    const shots = [...v.matchAll(/\{ src: '(screens\/[^']+)', sizes: '(\d+)x(\d+)', type: 'image\/webp', form_factor: '(narrow|wide)'/g)]
    expect(shots.length).toBeGreaterThanOrEqual(2)
    expect(shots.some(m => m[4] === 'narrow')).toBe(true)
    expect(shots.some(m => m[4] === 'wide')).toBe(true)
    for (const m of shots) expect(existsSync(new URL('../public/' + m[1], import.meta.url))).toBe(true)
  })
  it('G33: tri bližnjice s tremi različnimi ikonami', () => {
    const icons = [...v.matchAll(/url: BASE \+ '#\/[^']+', icons: \[\{ src: '([^']+)'/g)].map(m => m[1])
    expect(icons).toHaveLength(3)
    expect(new Set(icons).size).toBe(3)
    for (const i of icons) expect(existsSync(new URL('../public/' + i, import.meta.url))).toBe(true)
  })
  it('G35: iOS zagonske slike (vsaj 3) in datoteke obstajajo', () => {
    const imgs = [...html.matchAll(/<link rel="apple-touch-startup-image" media="[^"]+" href="\/(icons\/splash-\d+x\d+\.png)"/g)].map(m => m[1])
    expect(imgs.length).toBeGreaterThanOrEqual(3)
    for (const i of imgs) expect(existsSync(new URL('../public/' + i, import.meta.url))).toBe(true)
  })
  it('G34: zagonski zaslon v svetli temi je svetel', () => {
    expect(src('landing/landing.css')).toMatch(/:root\[data-theme="light"\]:not\(\.is-land\) #root>\.boot0\{background:#F4F6F2/)
  })
})

describe('G01 — pristajalna stran omeni slike treningov', () => {
  it('razdelek Zasebnost: »slike obrokov in treningov, ki jih pošlješ«', () => {
    expect(src('landing/landing.html')).toMatch(/slike obrokov in treningov, ki jih pošlješ/)
  })
})

describe('G08 — začetni paket', () => {
  it('Danes, store in Shell ne uvozijo statično lenih delov (razčlenjevalniki, Vodnik, trase, AI odjemalec, listi, prevzemi)', () => {
    expect(src('src/domain/intervals/client.ts')).not.toMatch(/from '\.\.\/import\/parsers'/)
    expect(src('src/domain/ai/errors.ts')).not.toMatch(/from '\.\/client'/)
    const d = src('src/screens/Danes.tsx')
    for (const m of ['@/ui/Guide', '@/ui/RouteCard', '@/state/snap', '@/ui/LastWeekCard', '@/ui/FuelLog', '@/ui/WeighSheet', '@/ui/ReadinessSheet', '@/ui/SkipSheet', '@/ui/MoveDaySheet']) expect(d).not.toMatch(new RegExp(`from '${m}'`))
    expect(src('src/state/store.ts')).not.toMatch(/^import .*from '@\/data\/migrate'/m)
    expect(src('src/state/store.ts')).not.toMatch(/^import .*from '@\/data\/feedback'/m)
    expect(src('src/app/App.tsx')).toMatch(/from '@\/ui\/InstallSheetLazy'/)
  })
  it('po gradnji (če je dist): start-*.js ≤ 706 kB', () => {
    const root = process.cwd()
    const dirs = ['dist', ...readdirSync(root).filter(f => /^dist-\d+$/.test(f))]
    for (const d of dirs) {
      const a = `${root}/${d}/assets/`
      if (!existsSync(a)) continue
      for (const f of readdirSync(a)) if (/^start-.*\.js$/.test(f)) expect(statSync(a + f).size).toBeLessThanOrEqual(706_000)
    }
  })
})

beforeEach(() => { vi.setSystemTime(new Date('2026-10-21T10:00:00')) })
