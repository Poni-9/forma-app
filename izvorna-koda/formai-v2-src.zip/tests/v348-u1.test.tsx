// v3.48 U1 — zaslon Danes: tekma ni »olajšaj dan« ne »brez trdih intervalov«, utrujenost na dan počitka, olajšan dan
// po tvoji izbiri, tekma označena (Danes, Jutri, Plan), struktura vaj namesto odrezanega ogrevanja, kartica Jutri brez
// TSS, jutranji vnos v skupinah in »2 tapa« s spancem z ure, tekoča vadba.
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { readFileSync } from 'node:fs'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>() }))
vi.mock('@/state/store', () => ({
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  saveCheckin: vi.fn(async () => {}), savePlanDay: vi.fn(), savePlanDays: vi.fn(), toast: vi.fn(), setPlanDone: vi.fn(),
}))
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => ({ name: 'danes', params: {} }) }))

import { coachLine } from '@/screens/Danes'
import { easeDay, canEaseDay } from '@/domain/training/planner'
import { raceLock } from '@/domain/training/protect'
import { stepsFor } from '@/domain/training/workout'
import { workText } from '@/domain/training/zones'
import { drillGist, raceGist, sessLabel, sessColor } from '@/ui/SessBits'
import { TomorrowCard } from '@/ui/TomorrowCard'
import { Checkin } from '@/ui/Checkin'
import { runningDayId, RUN_KEY_SHARED } from '@/ui/runState'
import type { PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

const NOW = '2026-10-17T08:00:00.000Z'
const day = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: date + (o.kind || 'kolo'), date, kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, ...o })
const rest = (date: string): PlanDay => day(date, { kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, role: null })
const P = { sex: 'm', age: 30, heightCm: 180, weightKg: 75, ftp: 250, maxHr: 190, restHr: 50, gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: true }, strength: { on: false, equipment: 'none' }, onboardingDone: true, createdAt: NOW, updatedAt: NOW } as unknown as Profile
const race = day('2026-10-23', { title: 'Kronometer Vodice — 18 km', desc: 'Zajtrk 2–3 h prej (~2 g OH na kg). Ogrevanje 25 min s 3 × 2 min na pragu; enakomerno, zadnjih 5 min vse.', durationMin: 30, zone: 'dirka', role: 'dirka', raceId: 'r1', tssTarget: 45 })
const vo2 = day('2026-10-20', { title: 'VO2max 4 × 4 min', desc: '20 min ogrevanje s 3 kratkimi pospeški. 4 × 4 min pri 270–290 W (108–115 % FTP), vmes 4 min lahko. 10 min iztek.', durationMin: 75, zone: 'Z5', role: 'kljucna', target: { lo: 270, hi: 290 } })
// teden 19.–25. 10.: tekma v petek, prosti dnevi pon, sre, ned
const week = [rest('2026-10-19'), vo2, rest('2026-10-21'), day('2026-10-22', { title: 'Predaktivacija', role: 'lahka', durationMin: 45 }), race, day('2026-10-24', { title: 'Regeneracija', zone: 'Z1', role: 'regen' }), rest('2026-10-25')]

describe('A01/A14 Trener pravi: ne nasprotuje načrtu', () => {
  it('dolgo manj treninga (TSB ≥ 25) in VO2max: brez »brez trdih intervalov«; tekma: »tekma«', () => {
    expect(coachLine(30, { kind: 'kolo', role: 'kljucna', zone: 'Z5' }, 5, 5, 78)).not.toMatch(/brez trdih intervalov/)
    expect(coachLine(30, { kind: 'kolo', role: 'kljucna', zone: 'Z5' }, 5, 5, 78)).toMatch(/intervale začni malo pod razponom/)
    expect(coachLine(30, { kind: 'kolo', role: 'dirka', zone: 'dirka' }, 5, 5, 78)).toMatch(/tekma/)
    expect(coachLine(30, { kind: 'kolo', role: 'dirka' }, 5, 5, 78)).not.toMatch(/brez trdih intervalov/)
    // lahek dan po premoru ostane po starem
    expect(coachLine(30, { kind: 'kolo', role: 'lahka', zone: 'Z2' }, 5, 5, 78)).toMatch(/brez trdih intervalov/)
  })
  it('utrujenost na dan počitka in po opravljenem: ne »olajšaj dan«; na dan treninga da', () => {
    expect(coachLine(5, { kind: 'pocitek' }, 5, 5, 30)).not.toMatch(/olajšaj/)
    expect(coachLine(5, { kind: 'pocitek' }, 5, 5, 30)).toMatch(/počitek/)
    expect(coachLine(5, { kind: 'kolo', role: 'dolga', done: { at: NOW } }, 5, 5, 30)).not.toMatch(/olajšaj/)
    expect(coachLine(5, { kind: 'kolo', role: 'dolga', done: { at: NOW } }, 5, 5, 30)).toMatch(/opravljeno/)
    expect(coachLine(5, null, 5, 5, 30)).not.toMatch(/olajšaj/)
    expect(coachLine(5, { kind: 'kolo', role: 'dolga' }, 5, 5, 30)).toMatch(/olajšaj dan/)
    // na dan tekme tudi z nizko pripravljenostjo ne »olajšaj dan«
    expect(coachLine(5, { kind: 'kolo', role: 'dirka' }, 5, 5, 30)).not.toMatch(/olajšaj/)
  })
})

describe('A02/A47 Olajšaj dan', () => {
  it('na dan tekme in dan pred njo ni na voljo (tekma ne izgine)', () => {
    const lock = raceLock(week)
    expect(canEaseDay(race, lock)).toBe(false)
    expect(easeDay(week, '2026-10-23', lock)).toBeNull()
    expect(canEaseDay(week[3]!, lock)).toBe(false)
    expect(easeDay(week, '2026-10-22', lock)).toBeNull()
    // tekma iz profila (v načrtu je še navaden dan) — tudi
    const lockP = raceLock([], { races: [{ id: 'r1', name: 'K', date: '2026-10-23' }] } as never)
    expect(canEaseDay(day('2026-10-22'), lockP)).toBe(false)
    expect(canEaseDay(vo2, lock)).toBe(true)
  })
  it('olajšan dan: po tvoji izbiri, ne »Telo je dalo znak«', () => {
    const out = easeDay(week, '2026-10-20', raceLock(week))!
    const eased = out.find(d => d.date === '2026-10-20')!
    expect(eased.desc).not.toMatch(/Telo je dalo znak/)
    expect(eased.desc).toMatch(/po tvoji izbiri/)
    const moved = out.find(d => d.date !== '2026-10-20')
    if (moved) expect(moved.why).not.toMatch(/nizke pripravljenosti/)
  })
})

describe('A12/B33/A21 kartica treninga', () => {
  it('tekma: oznaka »Tekma«, barva poudarka; bistvo je tempo, ne zajtrk', () => {
    expect(sessLabel(race)).toBe('Tekma')
    expect(sessColor(race)).toBe('var(--accent-fg)')
    expect(sessLabel(vo2)).toBe('Kolo')
    expect(raceGist(race.desc)).toBe('Ogrevanje 25 min s 3 × 2 min na pragu; enakomerno, zadnjih 5 min vse.')
    expect(raceGist('Zajtrk 2–3 h prej (~2 g ogljikovih hidratov na kg), ogrevanje 15–20 min s 3 kratkimi pospeški. V zavetrini varčuj, dolge klance enakomerno.')).toBe('V zavetrini varčuj, dolge klance enakomerno.')
    expect(raceGist('Ogrevanje 25–30 min s 3 × 2 min na pragu. Prvih 5 min ~238 W, sredina 238–250 W, zadnjih 5 min vse.')).toMatch(/^Prvih 5 min/)
    expect(raceGist('Enakomerno do cilja.')).toBe('Enakomerno do cilja.')
  })
  it('intervali: struktura »4 × 4 min, vmes 4 min lahko« brez cilja, ki ga kaže vrstica cone', () => {
    const st = stepsFor(vo2, P)
    expect(drillGist(st, workText(P, vo2))).toBe('4 × 4 min, vmes 4 min lahko')
    expect(drillGist(st)).toMatch(/^4 × 4 min \(?.*270–290 W/)
    // enakomerna vožnja nima strukture
    expect(drillGist(stepsFor(day('2026-10-21', { durationMin: 90 }), P))).toBe('')
  })
})

let div: HTMLDivElement, root: Root
const render = async (el: React.ReactNode) => { await act(async () => { root.render(el) }) }
beforeEach(() => { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div) })
afterEach(async () => { await act(async () => root.unmount()); div.remove() })

describe('A12/A41 kartica Jutri', () => {
  it('tekma jutri: »tekma« v oznaki, pokal, brez TSS', async () => {
    await render(<TomorrowCard plan={[race]} today="2026-10-22" hour={9} />)
    expect(div.textContent).toContain('Jutri · petek · tekma')
    expect(div.textContent).not.toMatch(/TSS/)
    expect(div.querySelector('.tomorrow.race')).toBeTruthy()
    expect(div.querySelector('button')!.getAttribute('aria-label')).toMatch(/tekma/)
  })
  it('navaden dan: trajanje in beseda intenzivnosti, ne TSS', async () => {
    await render(<TomorrowCard plan={[day('2026-10-18', { tssTarget: 55 })]} today="2026-10-17" hour={9} />)
    expect(div.textContent).toContain('1 h · lahko')
    expect(div.textContent).not.toMatch(/TSS/)
    expect(div.querySelector('.tomorrow.race')).toBeNull()
  })
})

describe('A34/A35 jutranji vnos', () => {
  it('vrstice so skupine z imenom; s spancem z ure »2 tapa«', async () => {
    S.state = { today: '2026-10-17', checkinToday: null, settings: { wellnessOn: true }, wellness: [{ date: '2026-10-17', sleepH: 7.1 }], checkins: [] }
    await render(<Checkin compact />)
    const names = [...div.querySelectorAll('[role="group"]')].map(g => document.getElementById(g.getAttribute('aria-labelledby') || '')?.textContent)
    expect(names).toEqual(['Energija', 'Mišice'])
    expect(div.textContent).toContain('2 tapa')
    S.state = { ...S.state, settings: {}, wellness: null }
    await act(async () => { S.subs.forEach(f => f()) })
    expect([...div.querySelectorAll('[role="group"]')].map(g => document.getElementById(g.getAttribute('aria-labelledby') || '')?.textContent)).toEqual(['Energija', 'Mišice', 'Spanec'])
    expect(div.textContent).toContain('3 tapi')
  })
})

describe('A25 tekoča vadba', () => {
  it('isti ključ kot vodena vadba; nedokončana vadba vrne id dneva', () => {
    expect(readFileSync('src/screens/Vadba.tsx', 'utf8')).toContain(`export const RUN_KEY = '${RUN_KEY_SHARED}'`)
    sessionStorage.removeItem(RUN_KEY_SHARED)
    expect(runningDayId()).toBeNull()
    sessionStorage.setItem(RUN_KEY_SHARED, JSON.stringify({ v: 1, dayId: 'd1', finished: false }))
    expect(runningDayId()).toBe('d1')
    sessionStorage.setItem(RUN_KEY_SHARED, JSON.stringify({ v: 1, dayId: 'd1', finished: true }))
    expect(runningDayId()).toBeNull()
    sessionStorage.removeItem(RUN_KEY_SHARED)
  })
})
