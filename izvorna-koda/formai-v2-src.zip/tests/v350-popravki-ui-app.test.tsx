// v3.50 POPRAVKI-UI (REVIEW-UI U4, U5, U9): pravi App + pravi usmerjevalnik (router.ts, hash.ts) z lažno shrambo.
// U5: stanje zaslona v naslovu (replaceParams) in kasnejši izris App ne vržeta strani na višino prejšnjega obiska.
// U9: sprememba shrambe med prehodom zavihka — nov zaslon na vrhu, fokus na njegov naslov.
// U4: list »Trening s slike« (lazy v OverlayHost) — del kode se ne naloži → list z »Osveži«, ne pade cela aplikacija.
import 'fake-indexeddb/auto'
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>() }))
vi.mock('@/state/store', async () => {
  const { vi: v } = await import('vitest')
  const base: Record<string | symbol, unknown> = {
    useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
    getState: () => S.state,
    routePace: () => ({ k: 1, adj: { n: 0, adj: 1 } }),
    stateToday: () => ({ level: 0, legs: false, reasons: [] }),
    toast: v.fn(), dismissToast: v.fn(), boot: v.fn(async () => undefined), warmAuth: v.fn(),
    LAST_EXPORT_KEY: 'backup.lastExportAt', HELP_HINT_BEFORE: '2026-10-04',
  }
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' || typeof k === 'symbol' ? undefined : (t[k] = v.fn(async () => undefined))), has: (_t, k) => k !== 'then' })
})
vi.mock('@/ui/useAi', () => ({ useAi: () => ({ busy: false, signedIn: false, consent: false, run: async (fn: () => Promise<unknown>) => fn(), sheet: null }) }))
vi.mock('@/state/snap', () => ({ snapOf: () => ({}) }))
vi.mock('@/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
// del kode lista »Trening s slike« se ne naloži (nova objava brez service workerja, brez povezave …)
vi.mock('@/ui/PhotoTrainingSheet', () => { throw new Error('Failed to fetch dynamically imported module: /assets/PhotoTrainingSheet-old.js') })

import { App } from '@/app/App'
import { ErrorBoundary } from '@/app/ErrorBoundary'
import { replaceParams } from '@/app/hash'
import { openPhotoTraining, photoReq } from '@/ui/photoOpen'
import type { Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-21', YDAY = '2026-10-20'
const NOW = `${TODAY}T08:00:00.000Z`
const P = { sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, strength: { on: false, equipment: 'none' }, onboardingDone: true, hoursPerWeek: 8, goal: 'forma', createdAt: '2026-08-01T08:00:00.000Z', updatedAt: NOW } as unknown as Profile
const reset = () => {
  S.state = { ready: true, today: TODAY, plan: [], activities: [], recentMeals: [], mealsToday: [], checkins: [], checkinToday: null, weather: null, wellness: null, routeLib: null, routesBusy: false, icuDiag: null, icuErr: null, settings: { lang: 'sl', intervals: null, coach: { msgs: [], summary: null }, startDone: true, guideSeen: true, tests: [], installPromptDismissedAt: NOW }, toast: null, toasts: [], profile: P, user: null, authKnown: true, firstSync: null, changes: [], sync: { state: 'off' }, storageError: null, migration: null, accountClash: null }
}
const bump = async () => { await act(async () => { S.state = { ...S.state }; S.subs.forEach(f => f()) }) }
const flush = async (n = 10) => { for (let i = 0; i < n; i++) await act(async () => { await new Promise(r => setTimeout(r, 5)) }) }
let div: HTMLDivElement | null = null, root: Root | null = null
let Y = 0
const scrolls: [number, number][] = []
const tab = (label: string) => [...document.querySelectorAll('nav.tabs button')].find(b => (b.textContent || '').trim() === label) as HTMLButtonElement

beforeEach(() => {
  localStorage.clear(); sessionStorage.clear(); S.subs.clear(); reset(); scrolls.length = 0; Y = 0
  Object.defineProperty(window, 'scrollY', { configurable: true, get: () => Y })
  window.scrollTo = ((x: number, y: number) => { scrolls.push([x, y]); Y = y }) as never
  history.replaceState(null, '', '/#/danes')
  vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date(2026, 9, 21, 9, 0))
})
afterEach(async () => { if (root) { await act(async () => root!.unmount()); root = null } div?.remove(); document.body.innerHTML = ''; vi.useRealTimers() })

async function mount() {
  div = document.createElement('div'); div.id = 'root'; document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root!.render(<ErrorBoundary><App /></ErrorBoundary>) })
  await flush()
}
async function go(fn: () => void) { await act(async () => { fn() }); await flush(8) }

describe('U5 stanje v naslovu (replaceParams) in višina zaslona', () => {
  it('Prehrana ?dan=včeraj na 900 px → Plan → Prehrana (vrh) → izbereš včeraj → naslednji izris App ne skoči na 900 px', async () => {
    history.replaceState(null, '', `/#/prehrana?dan=${YDAY}`)
    await mount()
    Y = 900
    await go(() => tab('Plan').click())
    expect(location.hash).toBe('#/plan')
    await go(() => tab('Prehrana').click())
    expect(location.hash).toBe('#/prehrana')
    expect(scrolls[scrolls.length - 1]).toEqual([0, 0])
    scrolls.length = 0
    // tap na »včeraj« v traku dni (Prehrana) → replaceParams({ dan }) — brez hashchange
    await act(async () => { replaceParams({ dan: YDAY }, 'prehrana') })
    expect(location.hash).toBe(`#/prehrana?dan=${YDAY}`)
    await bump()
    expect(scrolls).toEqual([])
  })
  it('Nazaj (sistemski) še vedno vrne na višino, kjer si zaslon zapustil', async () => {
    await mount()
    Y = 640
    await go(() => tab('Plan').click())                       // nov vnos v zgodovini, Danes zapuščen na 640 px
    expect(location.hash).toBe('#/plan')
    expect(scrolls[scrolls.length - 1]).toEqual([0, 0])
    scrolls.length = 0
    const back = new Promise<void>(r => window.addEventListener('hashchange', () => r(), { once: true }))
    await act(async () => { history.back(); await back })
    await flush(8)
    expect(location.hash).toBe('#/danes')
    expect(scrolls[scrolls.length - 1]).toEqual([0, 640])
  })
})

describe('U9 startTransition: nujen izris App med prehodom', () => {
  it('Plan (zapuščen na 700 px) → Danes → tap Plan + sprememba shrambe med prehodom → Plan na vrhu, fokus na njegovem h1', async () => {
    history.replaceState(null, '', '/#/plan')
    await mount()
    Y = 700
    await go(() => tab('Danes').click())
    expect(location.hash).toBe('#/danes')
    Y = 0; scrolls.length = 0
    await act(async () => {
      tab('Plan').click()
      await new Promise<void>(r => window.addEventListener('hashchange', () => r(), { once: true }))
      S.state = { ...S.state }; S.subs.forEach(f => f())
    })
    await flush(30)
    expect(scrolls[scrolls.length - 1]).toEqual([0, 0])
    expect(scrolls).not.toContainEqual([0, 700])
    const a = document.activeElement as HTMLElement | null
    expect(a?.tagName).toBe('H1')
    expect(document.querySelector('main.screen')?.contains(a)).toBe(true)
  })
})

describe('U4 lazy list »Trening s slike« z mejo napake', () => {
  it('del kode se ne naloži (osvežitev že poskušena) → list »Tega dela ni bilo mogoče naložiti«, zavihki ostanejo; Zapri ga zapre', async () => {
    sessionStorage.setItem('formai.chunkReload', String(Date.now()))   // orReload je pred kratkim že osvežil
    await mount()
    expect(document.querySelector('nav.tabs')).toBeTruthy()
    const err = vi.spyOn(console, 'error').mockImplementation(() => undefined)
    await go(() => openPhotoTraining({ mode: 'done', dayId: null }))
    await flush(10)
    err.mockRestore()
    const t = document.body.textContent || ''
    expect(t).not.toMatch(/Nekaj se je podrlo/)
    expect(document.querySelector('nav.tabs')).toBeTruthy()
    expect(t).toMatch(/Tega dela ni bilo mogoče naložiti/)
    const close = [...document.querySelectorAll('.sheet button')].find(b => (b.textContent || '').trim() === 'Zapri') as HTMLButtonElement
    await go(() => close.click())
    expect(photoReq()).toBeNull()
    expect(document.body.textContent || '').not.toMatch(/Tega dela ni bilo mogoče naložiti/)
  })
})
