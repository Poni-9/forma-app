// Jutranji vnos: hitri tapi se ne povozijo; po tretjem tapu kartica ne izgine, strne se v vrstico z »uredi».
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), saved: [] as any[] }))
const emit = () => S.subs.forEach(f => f())
vi.mock('@/state/store', () => ({
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  // kot shramba: počasen zapis (IndexedDB), stanje se posodobi šele po njem
  saveCheckin: vi.fn(async (c: any) => { S.saved.push(c); await new Promise(r => setTimeout(r, 5)); S.state = { ...S.state, checkinToday: c }; emit() }),
}))

import { Checkin } from '@/ui/Checkin'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

let div: HTMLDivElement, root: Root
const chip = (label: string) => [...div.querySelectorAll('button')].find(b => b.textContent === label) as HTMLButtonElement

beforeEach(async () => {
  S.saved = []
  S.state = { today: '2026-09-25', checkinToday: null, settings: {}, wellness: null }
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root.render(<Checkin compact />) })
})
afterEach(async () => { await act(async () => root.unmount()); div.remove() })

describe('Checkin', () => {
  it('trije hitri tapi (preden se prvi shrani) — shranjeno je vse troje', async () => {
    await act(async () => { chip('Dobro').click(); chip('Malo').click(); chip('7 h').click() })
    await act(async () => { await new Promise(r => setTimeout(r, 40)) })
    const last = S.saved[S.saved.length - 1]
    expect(last).toMatchObject({ date: '2026-09-25', mood: 4, soreness: 2, sleepH: 7 })
    expect(S.state.checkinToday).toMatchObject({ mood: 4, soreness: 2, sleepH: 7 })
  })

  it('po izpolnitvi se strne v vrstico z »uredi« in se z njim spet odpre', async () => {
    await act(async () => { chip('Dobro').click(); chip('Malo').click(); chip('7 h').click() })
    await act(async () => { await new Promise(r => setTimeout(r, 40)) })
    expect(div.textContent).toContain('Jutro')
    expect(div.textContent).toContain('uredi')
    expect(chip('Odlično')).toBeUndefined()
    await act(async () => { chip('uredi').click() })
    expect(chip('Odlično')).toBeTruthy()
  })
})
