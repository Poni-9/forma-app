// v3.50 UVOZ-NAST (domena): branje datotek (pot brez časa, vzpon, moč iz FIT, imena, napake z razlogom, brez povezave,
// pokvarjen .zip), dvojniki ročnega vnosa, intervals.icu (napake povezave, okno uvoza, prekratke, diagnoza), razponi
// (utripi po vrsti, teža uteži), privzete beljakovine, lokacija z razlogom, samo trenažer.
import { describe, it, expect, vi, afterEach } from 'vitest'
import { parseGpx, parseTcx, parseFit, parseAny, toActivity, climbOf, guessSport, autoName, isAutoName, ImportError, IMPORT_WHY, whyOf, importFailText, setFitLoaderForTests } from '../src/domain/import/parsers'
import { parseArchive, ZIP_BAD } from '../src/domain/import/archive'
import { sameActivity, richer } from '../src/domain/import/dedupe'
import { athleteError, fetchAthlete, fetchActivities, importWindowDays, resetIcuPause, IcuError } from '../src/domain/intervals/client'
import { importDiagnosis, icuConnectPath, icuUploadPath } from '../src/domain/intervals/diagnosis'
import { profileErrors, hrOrderErrors } from '../src/domain/ranges'
import { proteinGkgOf } from '../src/domain/nutrition/energy'
import { askLocationWhy, LOC_MSG, placeNotFound } from '../src/domain/weather'
import { normalizeFocus, profileFromFocus } from '../src/domain/focus/model'
import type { Activity, Profile } from '../src/domain/types'

const sp = (s: string) => s.replace(/[  ⁠]/g, ' ')
afterEach(() => { vi.unstubAllGlobals(); setFitLoaderForTests?.(null) })

const gpx = (pts: string) => `<?xml version="1.0"?><gpx version="1.1" xmlns="http://www.topografix.com/GPX/1/1"><trk><name>Pot</name><trkseg>${pts}</trkseg></trk></gpx>`
const trk = (n: number, ele: (i: number) => number, time = true) => Array.from({ length: n }, (_, i) => `<trkpt lat="${(46.19 + i * 0.0003).toFixed(6)}" lon="${(14.49 + i * 0.0003).toFixed(6)}"><ele>${ele(i)}</ele>${time ? `<time>${new Date(Date.UTC(2026, 9, 20, 7, 0, i * 5)).toISOString()}</time>` : ''}</trkpt>`).join('')

describe('F07 GPX brez časa je pot, ne vožnja', () => {
  it('trkpt brez <time> → ImportError »route«, ne današnja vožnja brez trajanja', async () => {
    const e = await parseGpx(new Blob([gpx(trk(20, () => 300, false))]), 'pot.gpx').catch(x => x)
    expect(e).toBeInstanceOf(ImportError); expect((e as ImportError).why).toBe('route')
    expect(e.message).toMatch(/pot brez časa/)
  })
  it('samo točke poti (rtept, Komoot) → route; z časom je vožnja', async () => {
    const r = `<?xml version="1.0"?><gpx version="1.1"><rte><rtept lat="46.1" lon="14.4"/><rtept lat="46.2" lon="14.5"/></rte></gpx>`
    expect(((await parseGpx(new Blob([r]), 'komoot.gpx').catch(x => x)) as ImportError).why).toBe('route')
    const ok = await parseGpx(new Blob([gpx(trk(20, () => 300))]), 'voznja.gpx')
    expect(ok.durationMin).toBe(2); expect(ok.start).toBe('2026-10-20T07:00:00.000Z')
  })
})

describe('F08 vzpon z glajenjem', () => {
  it('ravnina s šumom ±2 m na točko: ≤ 20 m (prej 1 200 m)', async () => {
    const r = await parseGpx(new Blob([gpx(trk(600, i => 300 + (i % 2 ? 2 : -2)))]), 'ravno.gpx')
    expect(r.elevM).toBeLessThanOrEqual(20)
    expect(climbOf(Array.from({ length: 600 }, (_, i) => 300 + (i % 2 ? 2 : -2)))).toBeLessThanOrEqual(20)
  })
  it('pravi vzpon 0 → 500 m ostane ~500 m (tudi s šumom)', () => {
    const up = Array.from({ length: 1001 }, (_, i) => i * 0.5 + (i % 2 ? 1 : -1))
    expect(Math.abs(climbOf(up) - 500)).toBeLessThanOrEqual(15)
    // dva klanca po 100 m z dolino vmes: oba štejeta
    const hills = [...Array.from({ length: 50 }, (_, i) => i * 2), ...Array.from({ length: 50 }, (_, i) => 100 - i * 2), ...Array.from({ length: 50 }, (_, i) => i * 2)]
    expect(climbOf(hills)).toBeGreaterThan(180)
  })
})

describe('F09 vadba moči iz FIT ni kolo', () => {
  it('šport »training« / sub_sport strength_training → moč; brez hitrosti in razdalje ni »kolo«', () => {
    expect(guessSport(null, 'training')).toBe('moc')
    expect(guessSport(null, 'strength_training training')).toBe('moc')
    expect(guessSport(null, 'fitness_equipment')).toBe('moc')
    expect(guessSport(null, 'generic')).toBe('drugo')
    expect(guessSport(null, 'cycling')).toBe('kolo')
    expect(guessSport(null, null, 20)).toBe('kolo')
  })
  it('parseFit: Garminova »Strength« (sport training, sub_sport strength_training) → moc; ime »Moč 45 min«', async () => {
    const data = { sessions: [{ sport: 'training', sub_sport: 'strength_training', start_time: '2026-10-20T16:00:00Z', total_timer_time: 2700 }] }
    setFitLoaderForTests(async () => ({ default: class { parse(_b: unknown, cb: (e: unknown, d: unknown) => void) { cb(null, data) } } }))
    const r = await parseFit(new Blob([new Uint8Array([1, 2, 3])]), '12345678_ACTIVITY.fit')
    expect(r.sport).toBe('moc'); expect(r.name).toBe('Moč 45 min')
  })
})

describe('F24 imena iz športa in razdalje', () => {
  it('FIT iz arhiva »12345678_ACTIVITY« → »Kolo 62 km«; lastno ime ostane', async () => {
    const data = { sessions: [{ sport: 'cycling', start_time: '2026-10-19T07:00:00Z', total_timer_time: 7200, total_distance: 62.3 }] }
    setFitLoaderForTests(async () => ({ default: class { parse(_b: unknown, cb: (e: unknown, d: unknown) => void) { cb(null, data) } } }))
    const a = toActivity(await parseFit(new Blob([new Uint8Array([1])]), '12345678_ACTIVITY.fit'), 'archive', null)
    expect(a.name).toBe('Kolo 62 km')
    expect((await parseFit(new Blob([new Uint8Array([1])]), 'Jutranji Krvavec.fit')).name).toBe('Jutranji Krvavec')
  })
  it('TCX »1234567890« → »Tek 1,6 km«; vzorci imen ure', async () => {
    let s = '<?xml version="1.0"?><TrainingCenterDatabase><Activities><Activity Sport="Running"><Lap><Track>'
    for (let i = 0; i < 600; i++) s += `<Trackpoint><Time>${new Date(Date.UTC(2026, 9, 21, 6, 0, i)).toISOString()}</Time><DistanceMeters>${(i * 2.6).toFixed(1)}</DistanceMeters></Trackpoint>`
    s += '</Track></Lap></Activity></Activities></TrainingCenterDatabase>'
    expect((await parseTcx(new Blob([s]), '1234567890.tcx')).name).toBe('Tek 1,6 km')
    expect(isAutoName('2026-05-10-08-15-00')).toBe(true); expect(isAutoName('Vršič')).toBe(false)
    expect(autoName('tek', 8.24, 45)).toBe('Tek 8,2 km'); expect(autoName('moc', null, 45)).toBe('Moč 45 min')
  })
  it('intervals.icu brez imena: tek je »Tek 8,2 km«, ne »Vožnja«', async () => {
    resetIcuPause()
    vi.stubGlobal('fetch', async () => new Response(JSON.stringify([{ id: 1, type: 'Run', start_date_local: '2026-10-20T07:00:00', start_date: '2026-10-20T05:00:00Z', moving_time: 2700, distance: 8240, source: 'GARMIN_CONNECT' }]), { status: 200 }))
    const r = await fetchActivities({ athleteId: 'i1', apiKey: 'k' }, '2026-10-01', '2026-10-22')
    expect(r.activities[0]!.name).toBe('Tek 8,2 km')
  })
})

describe('F20 + G13 neberljiva datoteka: ime in razlog; .fit brez povezave', () => {
  it('nepodprta vrsta, prazen GPX, pokvarjen FIT: razlog po slovensko', async () => {
    const csv = await parseAny(new File(['a,b'], 'moja.csv')).catch(x => x)
    expect((csv as ImportError).why).toBe('unsupported')
    expect(importFailText([{ name: 'moja.csv', why: whyOf(csv) }])).toBe(`moja.csv: ${IMPORT_WHY.unsupported}.`)
    const empty = await parseGpx(new Blob([gpx('')]), 'voznja.gpx').catch(x => x)
    expect(whyOf(empty)).toBe('datoteka nima sledi')
    expect(importFailText([{ name: 'a.fit', why: 'x' }, { name: 'b.fit', why: 'y' }, { name: 'c.fit', why: 'z' }])).toBe('a.fit: x (in še 2).')
    expect(whyOf(new Error("Can't find end of central directory"))).toBe(IMPORT_WHY.invalid)
  })
  it('bralnik .fit ni na voljo (brez povezave) → offline-lib, ne »ni berljiva«', async () => {
    setFitLoaderForTests(async () => { throw new TypeError('Failed to fetch dynamically imported module') })
    const e = await parseFit(new Blob([new Uint8Array([1])]), 'voznja.fit').catch(x => x)
    expect((e as ImportError).why).toBe('offline-lib'); expect(e.message).toMatch(/rabim povezavo/)
  })
})

describe('F21 + G18 pokvarjen .zip', () => {
  it('slovensko, brez angleške napake knjižnice in povezave', async () => {
    const e = await parseArchive(new File(['to ni zip'], 'a.zip')).catch(x => x)
    expect(e).toBeInstanceOf(ImportError); expect(e.message).toBe(ZIP_BAD)
    expect(e.message).not.toMatch(/http|central directory/i)
  })
})

describe('F14 ročni vnos brez km + ista vožnja z ure', () => {
  const man = (o: Partial<Activity> = {}) => ({ source: 'manual' as const, start: null, durationMin: 90, date: '2026-10-20', sport: 'kolo' as const, distKm: null, ...o })
  const icu = (o: Partial<Activity> = {}) => ({ source: 'intervals' as const, start: '2026-10-20T07:00:00Z', durationMin: 92, date: '2026-10-20', sport: 'kolo' as const, distKm: 41.2, ...o })
  it('»90 min« ročno = 92 min z ure (isti dan, šport); »okoli 40 km« = 43 km', () => {
    expect(sameActivity(man(), icu())).toBe(true)
    expect(sameActivity(man({ durationMin: null, distKm: 40 }), icu({ distKm: 43 }))).toBe(true)
    expect(sameActivity(icu(), man())).toBe(true)
  })
  it('ni dvojnik: drugo trajanje, drug šport ali dan; znano mora ujemati', () => {
    expect(sameActivity(man({ durationMin: 30 }), icu())).toBe(false)
    expect(sameActivity(man({ sport: 'tek' }), icu())).toBe(false)
    expect(sameActivity(man({ date: '2026-10-19' }), icu())).toBe(false)
    expect(sameActivity(man({ distKm: 20 }), icu())).toBe(false)
    // dve datoteki brez razdalje ostaneta po starem pravilu
    expect(sameActivity({ ...man(), source: 'file' }, { ...icu(), start: null, distKm: 41.2 })).toBe(false)
  })
  it('bogatejši: z ure pred ročnim pri enakih podatkih', () => {
    const a = { id: 'm', source: 'manual', polyline: null } as unknown as Activity, b = { id: 'i', source: 'intervals', polyline: null } as unknown as Activity
    expect(richer(a, b).id).toBe('i'); expect(richer(b, a).id).toBe('i')
  })
})

describe('F11 + F19 napake povezave z intervals.icu', () => {
  it('401 brez »HTTP«, 5xx ni »preveri ključ«, 404 = Athlete ID ne obstaja', () => {
    const a = athleteError(401, 'i1')
    expect(a.kind).toBe('auth'); expect(a.message).not.toMatch(/HTTP/); expect(a.message).toMatch(/Athlete ID .* API ključ/)
    const s = athleteError(503, 'i1')
    expect(s.kind).toBe('network'); expect(s.message).not.toMatch(/Athlete ID|ključ|HTTP/); expect(s.message).toMatch(/čez nekaj minut/)
    expect(athleteError(404, 'i12345').message).toMatch(/Athlete ID i12345 ne obstaja/)
    expect(athleteError(418, 'i1').message).toMatch(/koda 418/)
  })
  it('fetchAthlete ob 500 vrže IcuError(network)', async () => {
    resetIcuPause()
    vi.stubGlobal('fetch', async () => new Response('', { status: 500 }))
    const e = await fetchAthlete({ athleteId: 'i1', apiKey: 'k' }).catch(x => x)
    expect(e).toBeInstanceOf(IcuError); expect(e.kind).toBe('network')
  })
})

describe('F13 okno samodejnega uvoza', () => {
  it('od zadnjega uspešnega uvoza + 3 dni, vsaj 21, največ 365', () => {
    expect(importWindowDays(null, '2026-10-22')).toBe(21)
    expect(importWindowDays('2026-10-15', '2026-10-22')).toBe(21)
    expect(importWindowDays('2026-09-12', '2026-10-22')).toBe(43)
    expect(importWindowDays('2025-01-01', '2026-10-22')).toBe(365)
    expect(importWindowDays('nekaj', '2026-10-22')).toBe(21)
  })
})

describe('F25 + F26 prekratke in diagnoza', () => {
  it('3-minutna vožnja: skippedShort 1, pravo število v diagnozi', async () => {
    resetIcuPause()
    vi.stubGlobal('fetch', async () => new Response(JSON.stringify([{ id: 2, type: 'Ride', start_date_local: '2026-10-20T07:00:00', moving_time: 180, distance: 900, source: 'GARMIN_CONNECT' }]), { status: 200 }))
    const r = await fetchActivities({ athleteId: 'i1', apiKey: 'k' }, '2026-10-01', '2026-10-22')
    expect(r.skippedShort).toBe(1)
    const d = importDiagnosis({ at: '', days: 21, total: 1, usable: 0, stravaStubs: 0, known: 0, short: r.skippedShort })!
    expect(d.text).toMatch(/prekratki/); expect(d.title).toBe('intervals.icu je vrnil 1 zapis, a nobenega uporabnega')
    expect(importDiagnosis({ at: '', days: 21, total: 5, usable: 0, stravaStubs: 0, known: 0, short: 2 })!.text).toMatch(/^2 sta prekratka/)
  })
  it('»2 vožnji sta s Strave — FORMAI ju ne vidi«; tekaču »vadba«; ena pot do nastavitve', () => {
    expect(importDiagnosis({ at: '', days: 365, total: 5, usable: 0, stravaStubs: 2, known: 0 })!.title).toBe('2 vožnji sta s Strave — FORMAI ju ne vidi')
    expect(importDiagnosis({ at: '', days: 365, total: 1, usable: 0, stravaStubs: 1, known: 0 })!.title).toBe('1 vožnja je s Strave — FORMAI jo ne vidi')
    expect(importDiagnosis({ at: '', days: 365, total: 0, usable: 0, stravaStubs: 0, known: 0 }, { noBike: true })!.title).toBe('intervals.icu v zadnjih 365 dneh nima nobene vadbe')
    const t = importDiagnosis({ at: '', days: 365, total: 0, usable: 0, stravaStubs: 0, known: 0 })!.text
    expect(t).toContain(icuConnectPath()); expect(t).not.toMatch(/okence/)
    expect(icuUploadPath()).toMatch(/^Settings → Connections → Garmin Connect/)
  })
})

describe('F18 + F31 razponi', () => {
  it('max utrip 150 pod pražnim 184 → sporočilo pri max utripu', () => {
    expect(profileErrors({ maxHr: '150', lthr: '184' })).toEqual({ maxHr: 'Max utrip mora biti višji od pražnega (184).' })
    expect(profileErrors({ restHr: '115', lthr: '110' }).restHr).toBe('Mirovni utrip mora biti nižji od pražnega (110).')
    expect(profileErrors({ maxHr: '190', lthr: '170', restHr: '50' })).toEqual({})
  })
  it('spremenjeno polje dobi sporočilo; nespremenjeno staro stanje ne blokira', () => {
    expect(hrOrderErrors({ maxHr: '190', lthr: '195', restHr: '50' }, ['lthr'])).toEqual({ lthr: 'Pražni utrip mora biti nižji od max utripa (190).' })
    expect(hrOrderErrors({ maxHr: '190', lthr: '195' }, ['ftp'])).toEqual({})
  })
  it('teža uteži: 9 999 kg ni mogoča', () => {
    expect(sp(String((profileErrors({ dumbbellKg: '9999' } as never) as Record<string, string>).dumbbellKg))).toBe('Teža uteži: od 1 do 60 kg.')
    expect(profileErrors({ dumbbellKg: '12,5' } as never)).toEqual({})
  })
})

describe('F15 privzete beljakovine', () => {
  const p = { sex: 'm', age: 30, heightCm: 180, weightKg: 78, goal: 'hitrejsi', deficit: 0, proteinGkg: null } as unknown as Profile
  it('brez izbire 1,7 g; pri hujšanju 2,0 g; izbira velja', () => {
    expect(proteinGkgOf(p, '2026-10-22')).toBe(1.7)
    expect(proteinGkgOf({ ...p, goal: 'shujsati' } as Profile, '2026-10-22')).toBe(2.0)
    expect(proteinGkgOf({ ...p, proteinGkg: 2.2 } as Profile, '2026-10-22')).toBe(2.2)
  })
})

describe('F34 lokacija z razlogom', () => {
  it('zavrnjeno dovoljenje → denied in besedilo s korakom', async () => {
    const orig = Object.getOwnPropertyDescriptor(navigator, 'geolocation')
    Object.defineProperty(navigator, 'geolocation', { configurable: true, value: { getCurrentPosition: (_ok: unknown, err: (e: { code: number }) => void) => err({ code: 1 }) } })
    try {
      const r = await askLocationWhy()
      expect(r).toEqual({ why: 'denied' })
      expect(LOC_MSG.denied).toMatch(/dovoli ga v nastavitvah brskalnika ali vpiši kraj/)
      expect(placeNotFound('Xyzqw')).toBe('Kraja »Xyzqw« ne najdem — poskusi z bližnjim večjim krajem (npr. Ljubljana).')
    } finally { if (orig) Object.defineProperty(navigator, 'geolocation', orig); else delete (navigator as { geolocation?: unknown }).geolocation }
  })
})

describe('H06 samo trenažer', () => {
  const NOW = '2026-10-19T08:00:00.000Z'
  const base = { sex: 'm', age: 60, heightCm: 178, weightKg: 80, gear: { bikeOutdoor: true, trainer: false, noBike: false }, strength: { on: false, equipment: 'none' }, onboardingDone: false, createdAt: NOW, updatedAt: NOW } as unknown as Profile
  const f = (wish: string) => normalizeFocus({ wish, sports: ['kolo'], aims: ['kondicija'], level: 2, sessions: [{ type: 'kolo', min: 60 }, { type: 'kolo', min: 60 }, { type: 'kolo', min: 90 }] }, { age: 60, now: NOW, by: 'pravila' })!
  it('»Kolo: Trenažer doma.« → kolo zunaj izklopljeno, trenažer vklopljen', () => {
    const g = profileFromFocus(f('Rad delam: kolo. Kolo: Trenažer doma.'), base, '2026-10-19', '2026-10-19').gear!
    expect(g.bikeOutdoor).toBe(false); expect(g.trainer).toBe(true)
    expect(profileFromFocus(f('Kolesarim. Vozim samo trenažer doma.'), { ...base, onboardingDone: true }, '2026-10-19', '2026-10-19').gear!.bikeOutdoor).toBe(false)
  })
  it('zunaj in trenažer → oboje; brez izbire ostane, kot je', () => {
    const g = profileFromFocus(f('Kolo: Zunaj po cesti, Trenažer doma.'), base, '2026-10-19', '2026-10-19').gear!
    expect(g.bikeOutdoor).toBe(true); expect(g.trainer).toBe(true)
    expect(profileFromFocus(f('Rad delam: kolo.'), base, '2026-10-19', '2026-10-19').gear!.bikeOutdoor).toBe(true)
  })
})
