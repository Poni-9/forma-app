import { describe, it, expect } from 'vitest'
import { buildWeek, weekContext, macroWeeks, strengthSession, easeDay, forecastForm, zoneMinutes, FRANJA_2027 } from '../src/domain/training/planner'
import { goalStatus, milestones, levelOf, suggestedTargetFtp, vo2maxFromP5, ftpPotential, raceWeightOf } from '../src/domain/training/goal'
import { raceWeight } from '../src/domain/nutrition/body'
import { rideFuel, dayMealPlan } from '../src/domain/nutrition/dayplan'
import { structureLines } from '../src/domain/training/workout'
import { dailyTarget, weightTrend, goalDeficit, fueling, dayDeficit, MAX_DEFICIT } from '../src/domain/nutrition/energy'
import { alerts } from '../src/domain/alerts'
import { sexFromV1 } from '../src/data/migrate'
import { stepsFor, totalSec } from '../src/domain/training/workout'
import type { Activity, PlanDay, Profile } from '../src/domain/types'

const now = new Date().toISOString()
const blaz = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 181, weightKg: 78, restHr: 55, maxHr: 200, ftp: null,
  gear: { bikeOutdoor: true, trainer: false, noBike: false, pullupBar: true }, level: 2, hoursPerWeek: 6,
  strength: { on: true, equipment: 'none' }, strengthDays: 3, goal: 'shujsati', deficit: 500, neat: 1.4, proteinGkg: 2.0, targetWeightKg: 72,
  onboardingDone: true, createdAt: now, updatedAt: now, ...o,
})
const act = (o: Partial<Activity>): Activity => ({ id: Math.random().toString(36).slice(2), source: 'manual', sport: 'kolo', date: '2026-09-10', name: 'x', aiEligible: true, geoRetain: true, createdAt: now, updatedAt: now, ...o })

describe('makrocikel do Franje 2027', () => {
  const franja = (o: Partial<Profile> = {}) => blaz({ ftp: 240, ftpDate: '2026-08-21', weightKg: 79, heightCm: 180, hoursPerWeek: 12, strengthDays: 2, event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', targetWeightKg: 72, targetFtp: 288, goal: 'dirka', ...o })
  it('faze po koledarju: osnova → gradnja → specifično → tapering → dirka → po dirki', () => {
    const p = franja()
    const w1 = weekContext(p, '2026-09-21')
    expect(w1.phase).toBe('osnova'); expect(w1.week).toBe(1); expect(w1.total).toBe(38); expect(w1.weeksToEvent).toBe(37)
    expect(w1.recovery).toBe(false); expect(w1.test).toBe(true)             // uvodni test: FTP star 31 dni
    expect(weekContext(p, '2027-01-04').phase).toBe('osnova')
    expect(weekContext(p, '2027-01-18').phase).toBe('gradnja')
    expect(weekContext(p, '2027-04-05').phase).toBe('specificno')
    expect(weekContext(p, '2027-05-31').phase).toBe('tapering')
    expect(weekContext(p, '2027-06-07').phase).toBe('dirka')
    expect(weekContext(p, '2027-06-14').phase).toBe('po')
    expect(weekContext(p, '2027-07-05').phase).toBe('osnova')              // sezona teče dalje
  })
  it('bloki 3 + 1: prvi razbremenilni teden 19. 10., testi vsakih 8 tednov', () => {
    const p = franja()
    const rec = macroWeeks(p, '2026-09-22').filter(w => w.recovery).map(w => w.weekStart)
    expect(rec[0]).toBe('2026-10-19')
    expect(rec).not.toContain('2026-05-31')
    const tests = macroWeeks(p, '2026-09-22').filter(w => w.test).map(w => w.weekStart)
    expect(tests).toEqual(['2026-09-21', '2026-11-16', '2027-01-11', '2027-03-08', '2027-05-03'])
    const h = macroWeeks(p, '2026-09-22').slice(0, 5).map(w => w.hours)
    expect(h).toEqual([9, 9, 10.5, 12, 6])                                  // rast iz ~10 h, nato razbremenitev
  })
  it('teden 1: pon počitek, tor VO2max 4 × 4 pri 259–276 W + jedro, čet test, sob dolga Z2, pet noge', () => {
    const w = buildWeek({ profile: franja(), activities: [], weekStart: '2026-09-21', notBefore: '2026-09-21' })
    const on = (d: string) => w.filter(x => x.date === d)
    expect(on('2026-09-21')[0]!.kind).toBe('pocitek')
    const tue = on('2026-09-22')
    expect(tue.find(x => x.kind === 'kolo')!.title).toBe('VO2max 4 × 4 min')
    expect(tue.find(x => x.kind === 'kolo')!.target).toEqual({ lo: 259, hi: 276 })
    expect(tue.find(x => x.kind === 'moc')!.title).toBe('Moč — jedro')
    expect(on('2026-09-24')[0]!.role).toBe('test')
    expect(on('2026-09-25').find(x => x.kind === 'moc')!.title).toBe('Moč — noge in jedro')
    expect(on('2026-09-26')[0]!.role).toBe('dolga')
    const bike = w.filter(d => d.kind === 'kolo' || d.kind === 'test').reduce((s, d) => s + d.durationMin, 0)
    expect(Math.abs(bike - 9 * 60)).toBeLessThanOrEqual(20)
    expect(w.some(d => d.optional)).toBe(false)                              // nič neobvezne hoje
  })
  it('teden 2: sweet spot 3 × 12 pri 211–223 W; razbremenilni teden brez ključnih sej', () => {
    const w2 = buildWeek({ profile: franja(), activities: [], weekStart: '2026-09-28', notBefore: '2026-09-28' })
    const ss = w2.find(d => d.title.startsWith('Sweet spot'))!
    expect(ss.title).toBe('Sweet spot 3 × 12 min'); expect(ss.target).toEqual({ lo: 211, hi: 223 })
    const rec = buildWeek({ profile: franja(), activities: [], weekStart: '2026-10-19', notBefore: '2026-10-19' })
    expect(rec.some(d => d.role === 'kljucna')).toBe(false)
    expect(rec.filter(d => d.kind === 'moc')).toHaveLength(1)
  })
  it('gradnja: prag in dolga s tempom; specifično: Kladje in skupinska; teden dirke z dirko v nedeljo', () => {
    const g = buildWeek({ profile: franja(), activities: [], weekStart: '2027-02-01', notBefore: '2027-02-01' })
    expect(g.some(d => d.title.startsWith('Prag'))).toBe(true)
    expect(g.some(d => d.title === 'Dolga Z2 + tempo')).toBe(true)
    const sp = buildWeek({ profile: franja(), activities: [], weekStart: '2027-04-12', notBefore: '2027-04-12' })
    expect(sp.some(d => d.title.startsWith('Kladje'))).toBe(true)
    expect(sp.some(d => d.title.startsWith('Skupinska'))).toBe(true)
    expect(sp.filter(d => d.kind === 'moc').length).toBeLessThanOrEqual(1)
    const race = buildWeek({ profile: franja(), activities: [], weekStart: '2027-06-07', notBefore: '2027-06-07' })
    const sun = race.find(d => d.date === '2027-06-13')!
    expect(sun.role).toBe('dirka'); expect(sun.title).toBe('Maraton Franja — 156 km')
    expect(race.find(d => d.date === '2027-06-11')!.title).toContain('polnjenje')
  })
  it('moč za kolesarja: jedro in noge, napredovanje +1 / +5 s', () => {
    const s = strengthSession('noge', blaz({ gear: { bikeOutdoor: true, trainer: false, noBike: false, dumbbells: true, dumbbellKg: 10 } }), [])
    expect(s.exercises.map(e => e.name)).toContain('Bolgarski počep')
    expect(s.exercises.find(e => e.name === 'Bolgarski počep')!.kg).toBe(10)
    const last = act({ sport: 'moc', name: 'Moč — jedro', date: '2026-09-15', exercises: [{ name: 'Deska', sets: 3, reps: '45–60 s' }, { name: 'Dvig nog leže', sets: 3, reps: '10–15' }] })
    const j = strengthSession('jedro', blaz(), [last])
    expect(j.exercises.find(e => e.name === 'Deska')!.reps).toBe('50–65 s')
    expect(j.exercises.find(e => e.name === 'Dvig nog leže')!.reps).toBe('11–16')
    expect(j.progressed).toBe(true)
  })
  it('olajšaj dan prestavi ključno sejo na prost dan', () => {
    const w = buildWeek({ profile: franja(), activities: [], weekStart: '2026-09-28', notBefore: '2026-09-28' })
    const out = easeDay(w, '2026-09-29')!
    const eased = out.find(d => d.date === '2026-09-29')!
    expect(eased.optional).toBe(true)
    const moved = out.find(d => d.date !== '2026-09-29')
    if (moved) { expect(moved.date > '2026-09-29').toBe(true); expect(moved.title).toBe('VO2max 4 × 4 min') }
  })
  it('napoved forme in 80/20', () => {
    const w = buildWeek({ profile: franja(), activities: [], weekStart: '2026-09-28', notBefore: '2026-09-28' })
    expect(forecastForm([], w, '2026-09-27')!.ctl).toBeGreaterThan(0)
    const z = zoneMinutes(w), all = z.Z1 + z.Z2 + z.Z3 + z.Z4 + z.Z5
    expect((z.Z1 + z.Z2) / all).toBeGreaterThan(0.75)
  })
  it('izvajalnik: vati iz načrta, 20 min ogrevanja, odmor 4 min; dolga s tempom ima bloka na koncu', () => {
    const p = franja()
    const w = buildWeek({ profile: p, activities: [], weekStart: '2026-09-28', notBefore: '2026-09-28' })
    const vo = w.find(d => d.title.startsWith('VO2max'))!
    const st = stepsFor(vo, p)
    expect(st.filter(s => s.kind === 'delo')).toHaveLength(4)
    expect(st[0]!.sec).toBe(1200)
    expect(st.find(s => s.kind === 'delo')!.target).toBe('259–276 W')
    expect(st.find(s => s.kind === 'lahko')!.sec).toBe(240)
    const g = buildWeek({ profile: p, activities: [], weekStart: '2027-02-01', notBefore: '2027-02-01' })
    const lt = g.find(d => d.title === 'Dolga Z2 + tempo')!
    const ls = stepsFor(lt, p)
    expect(ls.filter(s => s.kind === 'delo')).toHaveLength(2)
    expect(Math.abs(totalSec(ls) - lt.durationMin * 60)).toBeLessThanOrEqual(60)
  })
})

describe('pot do cilja: mejniki, raven, napoved', () => {
  const p = blaz({ ftp: 240, weightKg: 79, heightCm: 180, event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', targetWeightKg: 72, targetFtp: 288, goalStart: { date: '2026-09-22', ftp: 240, weightKg: 79 } })
  it('3,04 → 4,00 W/kg; mejniki dec 255 W/75 kg, mar 275 W/73 kg, Franja 288/72, leto 300/71', () => {
    const g = goalStatus(p, [], [], '2026-09-22')
    expect(g.wkg).toBe(3.04); expect(g.targetWkg).toBe(4); expect(g.weeksToEvent).toBe(38)
    const ms = milestones(p)
    expect(ms.map(m => [m.ftp, m.weight])).toEqual([[255, 75], [275, 73], [288, 72], [300, 71]])
    expect(ms[0]!.wkg).toBe(3.4)
    expect(levelOf(3.04)!.name).toBe('Povprečen amater')
    expect(levelOf(4.0)!.name).toBe('Top amater')
    expect(levelOf(4.5)!.name).toBe('Elitni amater')
  })
  it('pričakovano danes sledi krivulji, napoved iz dveh testov', () => {
    const g = goalStatus(p, [{ date: '2026-12-20', weightKg: 75 }], [], '2026-12-21')
    expect(g.expected!.ftp).toBeGreaterThanOrEqual(253); expect(g.expected!.ftp).toBeLessThanOrEqual(256)
    const t = [{ id: 'a', date: '2026-09-24', kind: 'ftp' as const, value: 253, unit: 'W' }, { id: 'b', date: '2026-11-19', kind: 'ftp' as const, value: 263, unit: 'W' }]
    const g2 = goalStatus({ ...p, ftp: 250 }, [{ date: '2026-11-19', weightKg: 77 }], t, '2026-11-20')
    expect(g2.projectedFtp).toBeGreaterThan(250)
    expect(g2.projectedWkg).not.toBeNull()
  })
  it('predlog ciljnega FTP +20 %, VO2max iz 5-min moči', () => {
    expect(suggestedTargetFtp(240)).toBe(288)
    expect(vo2maxFromP5(300, 79)).toBe(48)
  })
})

describe('deficit po fazi in dnevu (varovalke ostanejo)', () => {
  const p = blaz({ ftp: 240, weightKg: 79, heightCm: 180, event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', targetWeightKg: 72, deficit: 500 })
  const day = (o: Partial<PlanDay>): PlanDay => ({ id: 'd', date: '2026-09-23', kind: 'kolo', title: '', desc: '', durationMin: 120, zone: 'Z2', source: 'rules', createdAt: now, updatedAt: now, ...o })
  it('osnova: poln deficit; ključni dan pol; tapering nič; na ciljni teži nič', () => {
    expect(dayDeficit(p, [day({})], '2026-09-23').kcal).toBe(500)
    expect(dayDeficit(p, [day({ role: 'kljucna', zone: 'Z5' })], '2026-09-22').kcal).toBe(250)
    expect(dayDeficit(p, [day({ role: 'dolga', durationMin: 240 })], '2026-09-26').kcal).toBe(250)
    expect(dayDeficit(p, [], '2027-06-02').kcal).toBe(0)
    expect(dayDeficit(p, [], '2027-04-14').kcal).toBe(250)
    expect(dayDeficit({ ...p, weightKg: 72 }, [], '2026-12-02').kcal).toBe(0)
  })
  it('tla ostanejo: nikoli pod BMR / 1500, strop 750', () => {
    const t = dailyTarget(p, [], [], '2026-09-23')!
    expect(t.kcal).toBeGreaterThanOrEqual(t.floor)
    expect(t.maintenance - t.kcal).toBeLessThanOrEqual(MAX_DEFICIT)
    expect(t.deficit).toBe(500)
  })
  it('gorivo: intervali 60–80 g/h, dolga Z2 40–60 g/h, dirka 80–90 g/h', () => {
    expect(fueling({ kind: 'kolo', durationMin: 90, zone: 'Z5', role: 'kljucna' }, { weightKg: 79 })!.during).toContain('60–80 g')
    expect(fueling({ kind: 'kolo', durationMin: 240, zone: 'Z2', role: 'dolga' }, { weightKg: 79 })!.during).toContain('40–60 g')
    expect(fueling({ kind: 'kolo', durationMin: 310, zone: 'dirka', role: 'dirka' }, { weightKg: 79 })!.during).toContain('80–90 g')
  })
})

describe('osebna prehrana — varovalke ostanejo', () => {
  it('Blaž: 21 let, 78 kg, 181 cm, deficit 500', () => {
    const t = dailyTarget(blaz(), [], [])!
    expect(t.kcal).toBe(Math.round(Math.round(10 * 78 + 6.25 * 181 - 5 * 21 + 5) * 1.4) - 500)
    expect(t.proteinG).toBe(156)
  })
  it('deficit nad 750 se omeji; ročni cilj pod BMR se dvigne na tla', () => {
    expect(goalDeficit(blaz({ deficit: 2000 }))).toBe(MAX_DEFICIT)
    const t = dailyTarget(blaz({ kcalOverride: 900 }), [], [])!
    expect(t.kcal).toBe(t.floor)
    expect(t.clampedToFloor).toBe(true)
    expect(t.floor).toBeGreaterThanOrEqual(1500)
  })
  it('mladoletni: brez deficita tudi z nastavitvijo', () => {
    expect(goalDeficit(blaz({ age: 17, deficit: 750 }))).toBe(0)
    const t = dailyTarget(blaz({ age: 17, deficit: 750, kcalOverride: 600 }), [], [])!
    expect(t.minor).toBe(true)
    expect(t.kcal).toBeGreaterThanOrEqual(t.maintenance)
  })
  it('trend teže: 7-dnevno povprečje in sprememba na teden', () => {
    const c = Array.from({ length: 14 }, (_, i) => ({ date: `2026-09-${String(8 + i).padStart(2, '0')}`, weightKg: 80 - i * 0.1 }))
    const tr = weightTrend(c)!
    expect(tr.deltaWeek).toBeCloseTo(-0.7, 1)
    expect(tr.avg7).toBeCloseTo(79.0, 1)
  })
  it('gorivo: dolga vožnja ima OH med vožnjo, moč beljakovine po', () => {
    expect(fueling({ kind: 'kolo', durationMin: 150, zone: 'Z2' }, { weightKg: 78 })!.during).toMatch(/40–60 g/)
    expect(fueling({ kind: 'moc', durationMin: 40, zone: null }, { weightKg: 78 })!.after).toMatch(/beljakovin/)
  })
})

describe('opozorila in prevzem', () => {
  it('premalo hrane dva dni zapored → opozorilo', () => {
    const meals = ['2026-09-19', '2026-09-20'].map((date, i) => ({ id: 'm' + i, date, slot: 'kosilo' as const, name: 'x', kcal: 900, proteinG: 40, source: 'manual' as const, createdAt: now }))
    const a = alerts({ profile: blaz(), activities: [], plan: [], checkins: [], recentMeals: meals, today: '2026-09-21', hour: 12 })
    expect(a[0]!.kind).toBe('bad')
  })
  it('spol iz stare aplikacije', () => {
    expect(sexFromV1('moški')).toBe('m'); expect(sexFromV1('ženska')).toBe('z'); expect(sexFromV1('')).toBeNull()
  })
})

import { sameActivity } from '../src/domain/import/dedupe'
describe('dvojniki brez razdalje', () => {
  it('dve vadbi moči isti dan z različnim trajanjem nista dvojnik', () => {
    const a = act({ sport: 'moc', distKm: null, durationMin: 12 }), b = act({ sport: 'moc', distKm: null, durationMin: 42 })
    expect(sameActivity(a, b)).toBe(false)
    expect(sameActivity(a, act({ sport: 'moc', distKm: null, durationMin: 14 }))).toBe(true)
  })
})

import { sanitizeGaps, hasHiddenActivities, sanitizeList } from '../src/domain/ai/sanitize'
import { personalContext } from '../src/domain/ai/personal'
import { aiContext } from '../src/domain/ai/prompts'

describe('varovalka sanitizeGaps (nedotakljivo)', () => {
  const strava = act({ source: 'strava_api', aiEligible: false, geoRetain: false, date: '2026-09-20', distKm: 80, durationMin: 180 })
  const own = act({ date: '2026-09-19', distKm: 40, durationMin: 90 })
  it('s skritimi vožnjami odstrani stavke o premoru/neaktivnosti, ostalo ostane', () => {
    expect(hasHiddenActivities([own, strava])).toBe(true)
    expect(hasHiddenActivities([own])).toBe(false)
    const t = 'Dobro ti gre. Po premoru se vračaj postopoma. Ta teden si bil neaktiven.\n\nJutri lahka vožnja Z2.'
    const out = sanitizeGaps(t, true)
    expect(out).toBe('Dobro ti gre.\n\nJutri lahka vožnja Z2.')
    expect(sanitizeGaps(t, false)).toBe(t)
    expect(sanitizeList(['Dolgi premori med treningi', 'Premalo beljakovin'], true)).toEqual(['Premalo beljakovin'])
  })
  it('Strava vožnje nikoli v AI kontekst — niti prek moči ali kcal', () => {
    const p = blaz()
    const today = '2026-09-20'
    const stravaMoc = act({ source: 'strava_api', aiEligible: false, geoRetain: false, sport: 'moc', name: 'Strava moč', date: today, durationMin: 60, kcal: 900, exercises: [{ name: 'Sklece', sets: 3, reps: '10' }] })
    const ctx = aiContext([own, strava, stravaMoc], p, [])
    expect(ctx).not.toContain('80.0 km')
    expect(ctx).toContain('2 aktivnosti ni v tem povzetku')
    const pc = personalContext({ profile: p, activities: [own, strava, stravaMoc], plan: [], checkins: [], recentMeals: [], today })
    expect(pc).not.toContain('Strava moč')
    const withStrava = personalContext({ profile: p, activities: [own], plan: [], checkins: [], recentMeals: [], today })
    // kcal cilj v pozivu je enak, kot da Strava aktivnosti sploh ni
    expect(pc.match(/današnji cilj (\d+) kcal/)?.[1]).toBe(withStrava.match(/današnji cilj (\d+) kcal/)?.[1])
  })
})

describe('strop deficita velja tudi za ročni cilj', () => {
  it('NEAT 1.6 + ročni cilj 1600 → največ 750 pod porabo', () => {
    const p = blaz({ neat: 1.6, kcalOverride: 1600 })
    const t = dailyTarget(p, [], [])!
    expect(t.maintenance - t.kcal).toBeLessThanOrEqual(MAX_DEFICIT)
    expect(t.kcal).toBeGreaterThanOrEqual(1811)
  })
  it('z vožnjo: ročni cilj + poraba, deficit še vedno ≤ 750', () => {
    const p = blaz({ neat: 1.6, kcalOverride: 1500 })
    const ride = act({ date: '2026-09-20', durationMin: 120, kcal: 1000 })
    const t = dailyTarget(p, [ride], [])!
    expect(t.maintenance + 1000 - t.kcal).toBeLessThanOrEqual(MAX_DEFICIT)
  })
})

describe('samodejni cilji: najboljša teža in največji FTP', () => {
  const base = (o: Partial<Profile> = {}) => blaz({ ftp: 240, weightKg: 79, heightCm: 180, age: 21, hoursPerWeek: 12, event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', goalStart: { date: '2026-09-22', ftp: 240, weightKg: 79 }, targetWeightKg: null, targetFtp: null, ...o })
  it('najboljša teža: ocena maščobe iz BMI ~18 % → 10 % = 72 kg; izmerjena 14 % → 75,5 kg; nikoli pod BMI 20,5', () => {
    const rw = raceWeight(base())!
    expect(Math.round(rw.bf)).toBe(18); expect(rw.kg).toBe(72); expect(rw.measured).toBe(false)
    expect(raceWeight(base({ bodyFatPct: 14 }))!.kg).toBe(75.5)
    expect(raceWeight(base({ bodyFatPct: 14 }))!.measured).toBe(true)
    const lean = raceWeight(blaz({ weightKg: 68, heightCm: 180, age: 21, goalStart: null, bodyFatPct: 12 }))!
    expect(lean.kg).toBeGreaterThanOrEqual(66.5)                                   // BMI 20,5 pri 180 cm
    expect(raceWeight(base(), 8)!.limitedByTime).toBe(true)                        // 7 kg v 8 tednih ne gre
  })
  it('največji FTP: 3,0 W/kg pri 12 h → +20 % (288 W), realno 271; pri 10 h manj; pri 4 W/kg manj prostora', () => {
    const pot = ftpPotential(base(), '2026-09-22')!
    expect(pot.ideal).toBe(288); expect(pot.realistic).toBe(271); expect(pot.gainPct).toBe(20)
    expect(ftpPotential(base({ hoursPerWeek: 10 }), '2026-09-22')!.ideal).toBeLessThan(288)
    const strong = ftpPotential(base({ ftp: 300, weightKg: 75, goalStart: { date: '2026-09-22', ftp: 300, weightKg: 75 } }), '2026-09-22')!
    expect(strong.gainPct).toBe(10)
  })
  it('pot do cilja uporablja samodejna cilja: 288 W pri 72 kg = 4,00 W/kg; deficit se ustavi pri najboljši teži', () => {
    const g = goalStatus(base(), [], [], '2026-09-22')
    expect(g.targetFtp).toBe(288); expect(g.targetWeight).toBe(72); expect(g.targetWkg).toBe(4)
    expect(raceWeightOf(base(), '2026-09-22')!.kg).toBe(72)
    expect(goalDeficit(base({ deficit: 500, weightKg: 72 }))).toBe(0)
    expect(goalDeficit(base({ deficit: 500, weightKg: 76 }))).toBe(500)
  })
})

describe('vodenje prehrane in treninga', () => {
  const now2 = new Date().toISOString()
  const d = (o: Partial<PlanDay>): PlanDay => ({ id: 'x', date: '2026-09-26', kind: 'kolo', title: 'Dolga Z2', desc: '', durationMin: 240, zone: 'Z2', role: 'dolga', source: 'rules', createdAt: now2, updatedAt: now2, ...o })
  it('gorivo: dolga 4 h = 60 g/h, ~210 g; VO2max 75 min = 70 g/h; kratka Z2 samo voda', () => {
    const long = rideFuel(d({}))!
    expect(long.gph).toBe(60); expect(long.totalCarbs).toBe(210); expect(long.everyMin).toBe(20)
    expect(long.items[0]).toContain('2 × bidon')
    const vo = rideFuel(d({ title: 'VO2max 4 × 4 min', durationMin: 75, zone: 'Z5', role: 'kljucna' }))!
    expect(vo.gph).toBe(70); expect(vo.totalCarbs).toBe(55)
    // vse se sešteje: izotonik + gel ≥ skupaj; časovnica od 30. min, hrana v urniku
    expect(vo.items.join(' ')).toMatch(/1 × bidon domačega izotonika.*1 × bidon vode.*1 × gel/)
    expect(vo.schedule).toContain('Hrana: 0:30 gel')
    expect(vo.cues.map(c => c.atMin)).toEqual([30, 50])
    for (const o of [{ durationMin: 205 }, { durationMin: 240 }, { durationMin: 270 }, { durationMin: 300, role: 'dirka' as const }, { durationMin: 90, zone: 'Z4', role: 'kljucna' as const }, { durationMin: 120, role: 'lahka' as const }]) {
      const f = rideFuel(d(o))!
      expect(f.carriedCarbs).toBeGreaterThanOrEqual(f.totalCarbs - 10)
      expect(f.carriedCarbs).toBeLessThanOrEqual(f.totalCarbs + 30)
      expect(f.cues.every(c => c.atMin >= 30 && c.atMin <= o.durationMin - 15)).toBe(true)
    }
    expect(rideFuel(d({ durationMin: 205 }))!.cues.filter(c => /dolij/.test(c.text)).length).toBe(1)
    expect(rideFuel(d({ title: 'Z2', durationMin: 60, role: 'lahka' }))!.totalCarbs).toBe(0)
    expect(rideFuel(d({ kind: 'moc' }))).toBeNull()
    // komplet: kupljen izotonik + Frutabela + sendvič — dolga dobi sendvič in Frutabele, VO2max brez gela dobi Frutabelo
    const k = rideFuel(d({}), ['iso_kupljen', 'frutabela', 'sendvic'])!
    expect(k.items[0]).toContain('kupljenega izotonika'); expect(k.items.join(' ')).toMatch(/sendvič/); expect(k.items.join(' ')).toMatch(/750 ml izotonika \(kupi/)
    expect(k.carriedCarbs).toBeGreaterThanOrEqual(k.totalCarbs - 10)
    const k2 = rideFuel(d({ title: 'VO2max 4 × 4 min', durationMin: 75, zone: 'Z5', role: 'kljucna' }), ['iso_domaci', 'frutabela'])!
    expect(k2.items.join(' ')).toMatch(/Frutabela/); expect(k2.items.join(' ')).not.toMatch(/gel/)
    // brez izotonika: OH samo iz hrane, pijača voda
    const k3 = rideFuel(d({}), ['banana', 'frutabela', 'gel'])!
    expect(k3.items[0]).toMatch(/bidon vode/); expect(k3.carriedCarbs).toBeGreaterThanOrEqual(k3.totalCarbs - 10); expect(k3.cues.some(c => /vode/.test(c.text))).toBe(true)
  })
  it('obroki dneva: vsota ≈ cilj − gorivo na kolesu; beljakovine razdeljene; primer s količinami', () => {
    const t = { kcal: 3200, proteinG: 142, carbsG: 450 }
    const dp = dayMealPlan({ weightKg: 79, trainTime: 'popoldne' }, t, d({}))
    const sum = dp.slots.reduce((s, x) => s + x.kcal, 0) + (dp.onBike?.kcal || 0)
    expect(Math.abs(sum - 3200)).toBeLessThanOrEqual(40)
    expect(dp.slots.map(x => x.key)).toEqual(['zajtrk', 'kosilo', 'obnova', 'malica'])
    expect(dp.slots[0]!.example).toMatch(/ovseni kosmiči \d+ g/)
    const rest = dayMealPlan({ weightKg: 79, trainTime: 'popoldne' }, { kcal: 2300, proteinG: 142, carbsG: 250 }, null)
    expect(rest.onBike).toBeNull(); expect(rest.slots.map(x => x.key)).toEqual(['zajtrk', 'kosilo', 'malica', 'vecerja'])
  })
  it('izvajalnik: pregled strukture in namigi za občutek', () => {
    const p = blaz({ ftp: 240 })
    const w = buildWeek({ profile: { ...p, hoursPerWeek: 12, event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', ftpDate: '2026-09-20' } as Profile, activities: [], weekStart: '2026-09-28', notBefore: '2026-09-28' })
    const vo = w.find(x => x.title.startsWith('VO2max'))!
    const st = stepsFor(vo, p)
    expect(structureLines(st)).toContain('4 × 4 min pri 259–276 W, vmes 4 min lahko')
    expect(st.find(x => x.kind === 'delo')!.note).toMatch(/RPE 9/)
    const moc = w.find(x => x.kind === 'moc')!
    expect(stepsFor(moc, p).find(x => x.kind === 'vaja')!.note).toMatch(/Komolci|Zadnja noga/)
  })
})

import { trimChat, CHAT_KEEP, CHAT_FOLD } from '../src/domain/ai/actions'
describe('pogovor s trenerjem — spomin', () => {
  it('do 40 sporočil ostane vse, nad 40 gre najstarejših 20 v povzetek', () => {
    const m = (n: number) => Array.from({ length: n }, (_, i) => ({ role: i % 2 ? 'ai' as const : 'user' as const, text: `m${i}`, at: '' }))
    expect(trimChat(m(CHAT_KEEP)).fold).toBeNull()
    const t = trimChat(m(CHAT_KEEP + 2))
    expect(t.fold!.length).toBe(CHAT_FOLD); expect(t.fold![0]!.text).toBe('m0')
    expect(t.keep.length).toBe(CHAT_KEEP + 2 - CHAT_FOLD); expect(t.keep[0]!.text).toBe(`m${CHAT_FOLD}`)
  })
})
