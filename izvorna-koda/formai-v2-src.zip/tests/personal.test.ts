import { describe, it, expect } from 'vitest'
import { buildWeek, cycleInfo, strengthSession, easeDay, forecastForm, zoneMinutes } from '../src/domain/training/planner'
import { dailyTarget, weightTrend, goalDeficit, fueling, MAX_DEFICIT } from '../src/domain/nutrition/energy'
import { alerts } from '../src/domain/alerts'
import { sexFromV1 } from '../src/data/migrate'
import { stepsFor } from '../src/domain/training/workout'
import type { Activity, Profile } from '../src/domain/types'

const now = new Date().toISOString()
const blaz = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 181, weightKg: 78, restHr: 55, maxHr: 200, ftp: null,
  gear: { bikeOutdoor: true, trainer: false, noBike: false, pullupBar: true }, level: 2, hoursPerWeek: 6,
  strength: { on: true, equipment: 'none' }, strengthDays: 3, goal: 'shujsati', deficit: 500, neat: 1.4, proteinGkg: 2.0, targetWeightKg: 72,
  onboardingDone: true, createdAt: now, updatedAt: now, ...o,
})
const act = (o: Partial<Activity>): Activity => ({ id: Math.random().toString(36).slice(2), source: 'manual', sport: 'kolo', date: '2026-09-10', name: 'x', aiEligible: true, geoRetain: true, createdAt: now, updatedAt: now, ...o })

describe('osebni načrt', () => {
  it('3× moč potisk/poteg/noge, kolo, hoja ob počitku je neobvezna', () => {
    const w = buildWeek({ profile: blaz(), activities: [], weekStart: '2026-09-21', notBefore: '2026-09-21' })
    expect(w).toHaveLength(7)
    const moc = w.filter(d => d.kind === 'moc')
    expect(moc.map(d => d.title).sort()).toEqual(['Moč — noge', 'Moč — poteg', 'Moč — potisk'])
    expect(moc.every(d => (d.exercises || []).length >= 4)).toBe(true)
    expect(w.filter(d => d.kind === 'kolo').length).toBeGreaterThanOrEqual(2)
    expect(w.filter(d => d.optional).every(d => d.kind === 'pohod')).toBe(true)
    expect(w.some(d => d.title.startsWith('Sweet spot'))).toBe(true)
  })
  it('brez droga: poteg brez zgibov', () => {
    const s = strengthSession('poteg', blaz({ gear: { bikeOutdoor: true, trainer: false, noBike: false, pullupBar: false } }), [])
    expect(s.exercises.some(e => /zgib/i.test(e.name))).toBe(false)
  })
  it('napredovanje: +1 ponovitev in kg iz zadnje seje', () => {
    const last = act({ sport: 'moc', name: 'Moč — potisk', date: '2026-09-15', exercises: [{ name: 'Sklece', sets: 4, reps: '8–15', kg: null }, { name: 'Deska', sets: 3, reps: '45–60 s' }] })
    const s = strengthSession('potisk', blaz(), [last])
    expect(s.exercises.find(e => e.name === 'Sklece')!.reps).toBe('9–16')
    expect(s.exercises.find(e => e.name === 'Deska')!.reps).toBe('50–65 s')
    expect(s.progressed).toBe(true)
  })
  it('cikel: 4. teden je razbremenilni (−35 %), 5. teden prag, 12. test', () => {
    const p = blaz({ cycleStart: '2026-09-21' })
    expect(cycleInfo(p, '2026-10-12')!.recovery).toBe(true)
    const w1 = buildWeek({ profile: p, activities: [], weekStart: '2026-09-21', notBefore: '2026-09-21' })
    const w4 = buildWeek({ profile: p, activities: [], weekStart: '2026-10-12', notBefore: '2026-10-12' })
    const mins = (w: typeof w1) => w.filter(d => !d.optional && d.kind !== 'moc').reduce((s, d) => s + d.durationMin, 0)
    expect(mins(w4)).toBeLessThan(mins(w1) * 0.8)
    const w5 = buildWeek({ profile: p, activities: [], weekStart: '2026-10-19', notBefore: '2026-10-19' })
    expect(w5.some(d => d.title.startsWith('Prag 3 × 10'))).toBe(true)
    const w12 = buildWeek({ profile: p, activities: [], weekStart: '2026-12-07', notBefore: '2026-12-07' })
    expect(w12.some(d => d.title === '20-minutni test')).toBe(true)
  })
  it('olajšaj dan prestavi sejo na naslednji prost dan', () => {
    const w = buildWeek({ profile: blaz(), activities: [], weekStart: '2026-09-21', notBefore: '2026-09-21' })
    const today = w.find(d => d.kind !== 'pocitek' && !d.optional)!.date
    const out = easeDay(w, today)!
    const moved = out.find(d => d.date !== today)
    const eased = out.find(d => d.date === today)!
    expect(eased.optional).toBe(true)
    if (moved) expect(moved.date > today).toBe(true)
  })
  it('napoved forme in cone tedna', () => {
    const w = buildWeek({ profile: blaz(), activities: [], weekStart: '2026-09-21', notBefore: '2026-09-21' })
    const f = forecastForm([], w, '2026-09-20')!
    expect(f.ctl).toBeGreaterThan(0)
    const z = zoneMinutes(w)
    expect(z.Z2).toBeGreaterThan(z.Z3)
  })
  it('izvajalnik: sweet spot = 2 intervala s 5 min odmora', () => {
    const w = buildWeek({ profile: blaz({ ftp: 250 }), activities: [], weekStart: '2026-09-21', notBefore: '2026-09-21' })
    const ss = w.find(d => d.title.startsWith('Sweet spot'))!
    const st = stepsFor(ss, blaz({ ftp: 250 }))
    expect(st.filter(s => s.kind === 'delo')).toHaveLength(2)
    expect(st.find(s => s.kind === 'lahko')!.sec).toBe(300)
    expect(st.find(s => s.kind === 'delo')!.target).toMatch(/W/)
  })
})

describe('osebna prehrana — varovalke ostanejo', () => {
  it('Blaž: 21 let, 78 kg, 181 cm, deficit 500', () => {
    const t = dailyTarget(blaz(), [], [])!
    expect(t.kcal).toBe(Math.round(Math.round(10 * 78 + 6.25 * 181 - 5 * 21 + 5) * 1.4) - 500)
    expect(t.proteinG).toBe(156)
  })
  it('deficit nad 750 se omeji; ročni cilj pod BMR se dvigne na tla', () => {
    expect(goalDeficit(blaz({ deficit: 2000 }))).toBe(MAX_DEFICIT)
    const t = dailyTarget(blaz({ kcalOverride: 900 }), [], [])!
    expect(t.kcal).toBe(t.floor)
    expect(t.clampedToFloor).toBe(true)
    expect(t.floor).toBeGreaterThanOrEqual(1500)
  })
  it('mladoletni: brez deficita tudi z nastavitvijo', () => {
    expect(goalDeficit(blaz({ age: 17, deficit: 750 }))).toBe(0)
    const t = dailyTarget(blaz({ age: 17, deficit: 750, kcalOverride: 600 }), [], [])!
    expect(t.minor).toBe(true)
    expect(t.kcal).toBeGreaterThanOrEqual(t.maintenance)
  })
  it('trend teže: 7-dnevno povprečje in sprememba na teden', () => {
    const c = Array.from({ length: 14 }, (_, i) => ({ date: `2026-09-${String(8 + i).padStart(2, '0')}`, weightKg: 80 - i * 0.1 }))
    const tr = weightTrend(c)!
    expect(tr.deltaWeek).toBeCloseTo(-0.7, 1)
    expect(tr.avg7).toBeCloseTo(79.0, 1)
  })
  it('gorivo: dolga vožnja ima OH med vožnjo, moč beljakovine po', () => {
    expect(fueling({ kind: 'kolo', durationMin: 150, zone: 'Z2' }, { weightKg: 78 })!.during).toMatch(/60–90 g/)
    expect(fueling({ kind: 'moc', durationMin: 40, zone: null }, { weightKg: 78 })!.after).toMatch(/beljakovin/)
  })
})

describe('opozorila in prevzem', () => {
  it('premalo hrane dva dni zapored → opozorilo', () => {
    const meals = ['2026-09-19', '2026-09-20'].map((date, i) => ({ id: 'm' + i, date, slot: 'kosilo' as const, name: 'x', kcal: 900, proteinG: 40, source: 'manual' as const, createdAt: now }))
    const a = alerts({ profile: blaz(), activities: [], plan: [], checkins: [], recentMeals: meals, today: '2026-09-21', hour: 12 })
    expect(a[0]!.kind).toBe('bad')
  })
  it('spol iz stare aplikacije', () => {
    expect(sexFromV1('moški')).toBe('m'); expect(sexFromV1('ženska')).toBe('z'); expect(sexFromV1('')).toBeNull()
  })
})

import { sameActivity } from '../src/domain/import/dedupe'
describe('dvojniki brez razdalje', () => {
  it('dve vadbi moči isti dan z različnim trajanjem nista dvojnik', () => {
    const a = act({ sport: 'moc', distKm: null, durationMin: 12 }), b = act({ sport: 'moc', distKm: null, durationMin: 42 })
    expect(sameActivity(a, b)).toBe(false)
    expect(sameActivity(a, act({ sport: 'moc', distKm: null, durationMin: 14 }))).toBe(true)
  })
})

import { sanitizeGaps, hasHiddenActivities, sanitizeList } from '../src/domain/ai/sanitize'
import { personalContext } from '../src/domain/ai/personal'
import { aiContext } from '../src/domain/ai/prompts'

describe('varovalka sanitizeGaps (nedotakljivo)', () => {
  const strava = act({ source: 'strava_api', aiEligible: false, geoRetain: false, date: '2026-09-20', distKm: 80, durationMin: 180 })
  const own = act({ date: '2026-09-19', distKm: 40, durationMin: 90 })
  it('s skritimi vožnjami odstrani stavke o premoru/neaktivnosti, ostalo ostane', () => {
    expect(hasHiddenActivities([own, strava])).toBe(true)
    expect(hasHiddenActivities([own])).toBe(false)
    const t = 'Dobro ti gre. Po premoru se vračaj postopoma. Ta teden si bil neaktiven.\n\nJutri lahka vožnja Z2.'
    const out = sanitizeGaps(t, true)
    expect(out).toBe('Dobro ti gre.\n\nJutri lahka vožnja Z2.')
    expect(sanitizeGaps(t, false)).toBe(t)
    expect(sanitizeList(['Dolgi premori med treningi', 'Premalo beljakovin'], true)).toEqual(['Premalo beljakovin'])
  })
  it('Strava vožnje nikoli v AI kontekst — niti prek moči ali kcal', () => {
    const p = blaz()
    const today = '2026-09-20'
    const stravaMoc = act({ source: 'strava_api', aiEligible: false, geoRetain: false, sport: 'moc', name: 'Strava moč', date: today, durationMin: 60, kcal: 900, exercises: [{ name: 'Sklece', sets: 3, reps: '10' }] })
    const ctx = aiContext([own, strava, stravaMoc], p, [])
    expect(ctx).not.toContain('80.0 km')
    expect(ctx).toContain('2 aktivnosti ni v tem povzetku')
    const pc = personalContext({ profile: p, activities: [own, strava, stravaMoc], plan: [], checkins: [], recentMeals: [], today })
    expect(pc).not.toContain('Strava moč')
    const withStrava = personalContext({ profile: p, activities: [own], plan: [], checkins: [], recentMeals: [], today })
    // kcal cilj v pozivu je enak, kot da Strava aktivnosti sploh ni
    expect(pc.match(/današnji cilj (\d+) kcal/)?.[1]).toBe(withStrava.match(/današnji cilj (\d+) kcal/)?.[1])
  })
})

describe('strop deficita velja tudi za ročni cilj', () => {
  it('NEAT 1.6 + ročni cilj 1600 → največ 750 pod porabo', () => {
    const p = blaz({ neat: 1.6, kcalOverride: 1600 })
    const t = dailyTarget(p, [], [])!
    expect(t.maintenance - t.kcal).toBeLessThanOrEqual(MAX_DEFICIT)
    expect(t.kcal).toBeGreaterThanOrEqual(1811)
  })
  it('z vožnjo: ročni cilj + poraba, deficit še vedno ≤ 750', () => {
    const p = blaz({ neat: 1.6, kcalOverride: 1500 })
    const ride = act({ date: '2026-09-20', durationMin: 120, kcal: 1000 })
    const t = dailyTarget(p, [ride], [])!
    expect(t.maintenance + 1000 - t.kcal).toBeLessThanOrEqual(MAX_DEFICIT)
  })
})
