// v3.50 POPRAVKI-TR: ugotovitve REVIEW-TR R1–R10 (in UI U1 — premor ne pobriše lastnih treningov)
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.hoisted(() => { vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date('2026-10-21T10:00:00')) })
const u = vi.hoisted(() => ({ undo: null as null | (() => unknown), msg: '' }))
vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
vi.mock('../src/ui/Confirm', () => ({ undoToast: (msg: string, fn: () => unknown) => { u.msg = msg; u.undo = fn }, useHidden: () => new Set() }))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { bodyFatView } from '../src/domain/coach/bodyfat'
import { matchExercise, atOf } from '../src/domain/training/fromPhoto'
import { adaptToState, stateNow } from '../src/domain/training/state'
import { buildWeek, weekContext, storedBikeHours, planHours, FRANJA_2027 } from '../src/domain/training/planner'
import { BACK_TITLE_PAUSE, BACK_TITLE_RUN, PAUSE_TITLE, PHOTO_WHY, pausePeriod, pauseDays, ownDay, withOwn, planKey } from '../src/domain/training/pause'
import { raceMinutes } from '../src/domain/training/season'
import { addDays } from '../src/domain/training/load'
import type { Activity, PlanDay, Profile } from '../src/domain/types'

const NOW = '2026-10-21T08:00:00.000Z'
const P = (o: Partial<Profile> = {}): Profile => ({
  name: 'B', sex: 'm', age: 30, heightCm: 180, weightKg: 79, ftp: 240, ftpDate: '2026-09-20', maxHr: 195, restHr: 48, lthr: 184, level: 3,
  gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, hoursPerWeek: 9, hoursMode: 'own',
  strength: { on: true, equipment: 'home' }, strengthDays: 2, goal: 'dirka', deficit: 400, neat: 1.4, proteinGkg: 1.8,
  event: { ...FRANJA_2027 }, races: [], cycleStart: '2026-08-31', onboardingDone: true, aiConsentAt: NOW, aiConsentV: 2, createdAt: NOW, updatedAt: NOW, ...o,
} as Profile)
const ride = (date: string, min: number): Activity => ({ id: `a${date}-${min}`, source: 'manual', sport: 'kolo', date, name: 'x', durationMin: min, tss: Math.round(min * 0.7), aiEligible: true, geoRetain: true, createdAt: NOW, updatedAt: NOW } as Activity)
const RUN_FOCUS = { v: 1, mode: 'meri', wish: 'tek', sports: ['tek'], aims: ['kondicija'], muscles: [], days: 3, minutes: 50, level: 2, equipment: ['nic'], title: 'Tek', notes: [], at: NOW, by: 'pravila',
  sessions: [{ type: 'tek', cardio: 'intervali', min: 45, day: 0 }, { type: 'tek', cardio: 'lahko', min: 40, day: 2 }, { type: 'tek', cardio: 'dolgo', min: 70, day: 5 }] }

/* ---------------- shramba: premor in teden po njem (R1), lastni treningi (U1) ---------------- */
const prof = P({ age: 21, deficit: undefined, neat: undefined, proteinGkg: undefined, aiConsentAt: undefined, aiConsentV: undefined } as Partial<Profile>)
const W1 = '2026-10-26', W2 = '2026-11-02'
const wk = async (ws: string) => (await repo.allPlan()).filter(d => d.date >= ws && d.date <= addDays(ws, 6)).sort((a, b) => a.date.localeCompare(b.date))
const plan = () => repo.allPlan()
async function start(at: string) {
  vi.setSystemTime(new Date(`${at}T10:00:00`))
  await repo.wipeAll(); localStorage.clear(); await store.reloadAll()
  await store.updateProfile({ ...prof, weekPause: null })
  await store.ensureWeeks()
  u.undo = null
}
beforeEach(() => { vi.setSystemTime(new Date('2026-10-21T10:00:00')) })

describe('R1: teden po premoru, ki je že sestavljen, dobi prehod po premoru', () => {
  it('A: premor ves teden (pon 26. 10.) → teden 2. 11. ima ure kot pred premorom, ne polnih', async () => {
    await start(W1)
    const before = storedBikeHours(await wk(W2), W2)!
    await store.setWeekPause('vse')
    const p = store.getState().profile
    const after = await wk(W2)
    const want = planHours(p, [], W2, W1)
    expect(want.pause).toBe('kratek')
    expect(storedBikeHours(after, W2)).toBe(want.hours)
    expect(storedBikeHours(after, W2)!).toBeLessThan(before)
    expect(after.some(d => /Po premoru teden kot pred premorom/.test(d.why || ''))).toBe(true)
    // »Razveljavi« vrne teden, kot je bil
    await u.undo!()
    expect(storedBikeHours(await wk(W2), W2)).toBe(before)
  })
  it('B: premor podaljšan na 12 dni (sreda → ponedeljek) → 2. 11. lahka Z2 po premoru, ne VO2max', async () => {
    await start('2026-10-21')
    await store.setWeekPause('vse')                         // 21.–25. 10.
    vi.setSystemTime(new Date(`${W1}T10:00:00`)); await store.reloadAll()
    await store.ensureWeeks()                               // ponedeljek: sestavi 2. 11. (premor je takrat kratek)
    await store.setWeekPause('vse')                         // »Ta teden …« znova: 21. 10.–1. 11.
    const p = store.getState().profile
    expect(p.weekPause).toMatchObject({ from: '2026-10-21', to: '2026-11-01' })
    const w2 = await wk(W2)
    const first2 = w2.filter(d => d.date <= '2026-11-03' && (d.kind === 'kolo' || d.kind === 'test'))
    expect(first2.some(d => d.title === BACK_TITLE_PAUSE)).toBe(true)
    expect(first2.some(d => d.role === 'kljucna')).toBe(false)
    expect(w2.find(d => d.title === BACK_TITLE_PAUSE)?.why).toMatch(/^Po 12 dneh premora/)
  })
  it('C: preklic premora vrne tudi teden po njem (brez prehoda, ko premora ni bilo)', async () => {
    await start(W1)
    const before = storedBikeHours(await wk(W2), W2)
    await store.setWeekPause('vse')
    await store.endWeekPause()
    expect(store.getState().profile.weekPause).toBeNull()
    expect(storedBikeHours(await wk(W2), W2)).toBe(before)
  })
  it('obvestilo brez dvojne pike za datumom (»1. 11..«)', async () => {
    await start('2026-10-21')
    await store.setWeekPause('vse', { twoWeeks: true })
    // (v3.51 B45) dvotedenski premor: »Ta in naslednji teden: premor.« (prej »Ta teden: premor do nedelje, 1. 11.«)
    expect(u.msg).toMatch(/^Ta in naslednji teden: premor\. Treningi so umaknjeni/)
    expect(u.msg).not.toMatch(/\.\./)
  })
})

describe('U1: preklic ali sprememba premora ne pobriše treningov, ki si jih dodal sam', () => {
  const FRI = '2026-10-23'
  it('»Dodaj trening« na dan premora → »Prekliči premor« ga pusti, »Razveljavi« tudi', async () => {
    await start('2026-10-21')
    await store.setWeekPause('vse')
    const rest = (await plan()).find(d => d.date === FRI && d.title === PAUSE_TITLE)!
    // kot Plan → EditDay (applyDayEdit): isti id, vir 'rules', nova vsebina
    await store.savePlanDay({ ...rest, kind: 'kolo', title: 'Z2 vzdržljivost', desc: 'Moja vožnja s prijatelji.', durationMin: 60, zone: 'Z2', tssTarget: 39, role: null, why: null, optional: false, source: 'rules' })
    await store.endWeekPause()
    const mine = (await plan()).filter(d => d.date === FRI && d.id === rest.id)
    expect(mine.map(d => d.desc)).toEqual(['Moja vožnja s prijatelji.'])
    expect((await plan()).filter(d => d.date === FRI && d.kind === 'kolo')).toHaveLength(1)   // brez podvojene vožnje
    await u.undo!()
    expect(store.getState().profile.weekPause).toMatchObject({ from: '2026-10-21' })
    expect((await plan()).some(d => d.id === rest.id && d.desc === 'Moja vožnja s prijatelji.')).toBe(true)
  })
  it('trening s slike na dan premora → sprememba premora (brez treningov → brez kolesa) ga pusti', async () => {
    await start('2026-10-21')
    await store.setWeekPause('vse')
    const { addPhotoWorkout } = await import('../src/state/photoTraining')
    await addPhotoWorkout({ id: 'slika-x', date: FRI, kind: 'moc', title: 'Moč s slike', desc: '3 × 10 počep.', durationMin: 30, zone: null, tssTarget: 20, exercises: [{ name: 'Počep', sets: 3, reps: '10' }], role: 'moc', optional: false, why: PHOTO_WHY, source: 'ai', createdAt: NOW, updatedAt: NOW, done: null } as PlanDay, null)
    await store.setWeekPause('kolo')
    const fri = (await plan()).filter(d => d.date === FRI)
    expect(fri.some(d => d.title === 'Moč s slike')).toBe(true)
    expect(fri.filter(d => d.kind === 'moc')).toHaveLength(1)
  })
  it('premor brez kolesa: moč iz načrta se ob preklicu sestavi znova (ni podvojena)', async () => {
    await start('2026-10-21')
    await store.setWeekPause('kolo')
    const mocBefore = (await plan()).filter(d => d.date >= '2026-10-21' && d.date <= '2026-10-25' && d.kind === 'moc').length
    await store.endWeekPause()
    const mocAfter = (await plan()).filter(d => d.date >= '2026-10-21' && d.date <= '2026-10-25' && d.kind === 'moc').length
    expect(mocAfter).toBe(mocBefore)
  })
})

describe('U1: ownDay / withOwn', () => {
  const day = (o: Partial<PlanDay>): PlanDay => ({ id: 'x', date: '2026-10-23', kind: 'kolo', title: 'Z2 vzdržljivost', desc: '', durationMin: 60, source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o } as PlanDay)
  const pz = { weekPause: { from: '2026-10-21', to: '2026-10-25', mode: 'kolo' as const } }
  it('lastni: vožnja v premoru brez kolesa, s slike, jedro po želji, nova vsebina; ne: načrt, prilagoditve, po želji iz načrta', () => {
    const ref = new Set([planKey({ kind: 'moc', title: 'Moč — jedro' }), planKey({ kind: 'kolo', title: 'VO2max 5 × 4 min' })])
    expect(ownDay(day({}), pz, ref)).toBe(true)
    expect(ownDay(day({ kind: 'moc', title: 'Moč — jedro' }), pz, ref)).toBe(false)
    expect(ownDay(day({ kind: 'moc', title: 'Moja moč' }), pz, ref)).toBe(true)
    expect(ownDay(day({ kind: 'moc', title: 'Moč — jedro', optional: true, desc: 'Deska. Po želji — ne šteje v realizacijo tedna.' }), pz, ref)).toBe(true)
    expect(ownDay(day({ kind: 'moc', title: 'Moč s slike', source: 'ai', why: PHOTO_WHY }), pz, ref)).toBe(true)
    expect(ownDay(day({ date: '2026-10-27', title: 'VO2max 4 × 4 min' }), pz, ref)).toBe(false)     // številke ne štejejo
    expect(ownDay(day({ date: '2026-10-27', title: 'Lahek dan — Z1', optional: true }), pz, ref)).toBe(false)
    expect(ownDay(day({ date: '2026-10-27', byState: { date: '2026-10-21' } }), pz, ref)).toBe(false)
    expect(ownDay(day({ done: { at: NOW } }), pz, ref)).toBe(false)
  })
  it('withOwn: na dnevu lastnega zapisa odpadeta počitek in sestavljen zapis iste vrste', () => {
    const built = [day({ id: 'r', kind: 'pocitek', title: 'Premor' }), day({ id: 'b', date: '2026-10-24', title: 'Dolga Z2' }), day({ id: 'm', date: '2026-10-24', kind: 'moc', title: 'Moč — noge' })]
    const own = [day({ id: 'o1' }), day({ id: 'o2', date: '2026-10-24', kind: 'moc', title: 'Moja moč' })]
    expect(withOwn(built, own).map(d => d.id).sort()).toEqual(['b', 'o1', 'o2'])
  })
})

/* ---------------- domena ---------------- */
describe('R2: lestvica maščobe — en sam stavek o času ali razponu', () => {
  it('100 kg, 180 cm: čas do cilja, brez »si že v razponu«', () => {
    const v = bodyFatView({ sex: 'm', age: 30, heightCm: 180, weightKg: 100, bodyFatPct: null } as never)
    if (v.kind !== 'scale') throw new Error('ni lestvice')
    expect(v.months).not.toBeNull()
    expect(v.lines.some(l => /mesecev/.test(l))).toBe(true)
    expect(v.lines.some(l => /Si že v razponu/.test(l))).toBe(false)
  })
  it('vpisanih 11 %: »si že v razponu«, brez mesecev', () => {
    const v = bodyFatView({ sex: 'm', age: 30, heightCm: 180, weightKg: 70, bodyFatPct: 11 } as never)
    if (v.kind !== 'scale') throw new Error('ni lestvice')
    expect(v.months).toBeNull()
    expect(v.lines.some(l => /Si že v razponu/.test(l))).toBe(true)
  })
  it('brez višine in teže: poziv k vpisu', () => {
    const v = bodyFatView({ sex: 'z', age: 30, heightCm: null, weightKg: null, bodyFatPct: null } as never)
    if (v.kind !== 'scale') throw new Error('ni lestvice')
    expect(v.lines[0]).toMatch(/vpiši višino in težo/)
  })
})

describe('R3: raven 1 — prvi VO2max blago (4 × 4 min)', () => {
  const acts = (to: string) => { const out: Activity[] = []; for (let w = '2026-09-07'; w < to; w = addDays(w, 7)) for (const k of [1, 3, 5]) out.push(ride(addDays(w, k), 120)); return out }
  it('13.–20. teden: VO2max 4 × 4 min, ne 5 × 4 in ne 30/15', () => {
    const p = P({ level: 1, cycleStart: '2026-10-05', hoursPerWeek: 6, age: 21 })
    const keys: string[] = []
    for (let k = 12; k < 20; k++) {
      const ws = addDays('2026-10-05', 7 * k)
      const w = buildWeek({ profile: p, activities: acts(ws), weekStart: ws, notBefore: ws, today: ws })
      keys.push(...w.filter(d => d.role === 'kljucna' && /VO2max|30\/15/.test(d.title)).map(d => d.title))
    }
    expect(keys.length).toBeGreaterThan(0)
    expect(keys.every(t => t === 'VO2max 4 × 4 min')).toBe(true)
    const w13 = buildWeek({ profile: p, activities: acts('2026-12-28'), weekStart: '2026-12-28', notBefore: '2026-12-28', today: '2026-12-28' })
    expect(w13.find(d => /VO2max/.test(d.title))?.why).toMatch(/Prvi VO2max blago — 4 × 4 min/)
  })
  it('raven 2 ostane: blag VO2max od 5. tedna', () => {
    const p = P({ level: 2, cycleStart: '2026-10-05', hoursPerWeek: 6, age: 21 })
    const w = buildWeek({ profile: p, activities: acts('2026-11-02'), weekStart: '2026-11-02', notBefore: '2026-11-02', today: '2026-11-02' })
    expect(w.some(d => d.title === 'VO2max 4 × 4 min')).toBe(true)
  })
})

describe('R4: na dnu — jutri brez kolesa, ko kolesa ni', () => {
  const T = '2026-10-21'
  const twoDays = (): PlanDay[] => [
    { id: 'm', date: T, kind: 'moc', title: 'Moč — noge', desc: '', durationMin: 30, role: 'moc', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null },
    { id: 't', date: '2026-10-22', kind: 'tek', title: 'Tek — 5 × 3 min hitro', desc: '12 min lahkega teka, nato 5 × (3 min hitro / 2 min lahko).', durationMin: 45, zone: 'Z4', role: 'kljucna', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null },
  ] as PlanDay[]
  it('premor brez kolesa: jutrišnji trd tek → sprehod po želji, ne »Lahko vrtenje«', () => {
    const pk = P({ weekPause: { from: T, to: '2026-10-25', mode: 'kolo' } })
    const r = adaptToState(pk, twoDays(), T, { level: 3, legs: false, reasons: ['energija na tleh'] }, { now: NOW })!
    const tm = r.days.find(d => d.date === '2026-10-22')!
    expect(tm.kind).toBe('pohod')
    expect(r.lines.join(' ')).toMatch(/Jutri sprehod po želji/)
    expect(r.lines.join(' ')).not.toMatch(/vrtenje/)
    expect(stateNow([...twoDays().filter(d => !r.days.some(x => x.id === d.id)), ...r.days], T)!.lines.join(' ')).toMatch(/Jutri sprehod po želji namesto: Tek/)
  })
  it('načrt po meri brez kolesa (tek): danes in jutri sprehod, ne kolo', () => {
    const pr = P({ focus: RUN_FOCUS as never, event: null })
    const days = twoDays().map(d => (d.id === 'm' ? { ...d, kind: 'tek' as const, title: 'Tek — lahko 40 min', zone: 'Z2', role: 'lahka' as const } : d))
    const r2 = adaptToState(pr, days, T, { level: 2, legs: false, reasons: ['utrujen'] }, { now: NOW })!
    expect(r2.days.find(d => d.date === T)?.kind).toBe('pohod')
    const r3 = adaptToState(pr, twoDays(), T, { level: 3, legs: false, reasons: ['energija na tleh'] }, { now: NOW })!
    expect(r3.days.find(d => d.date === '2026-10-22')?.kind).toBe('pohod')
  })
  it('kolesar s kolesom: jutri lahko vrtenje kot prej', () => {
    const days = twoDays().map(d => (d.id === 't' ? { ...d, kind: 'kolo' as const, title: 'VO2max 5 × 4 min', zone: 'Z5' } : d))
    const r = adaptToState(P(), days, T, { level: 3, legs: false, reasons: ['energija na tleh'] }, { now: NOW })!
    expect(r.days.find(d => d.date === '2026-10-22')?.title).toBe('Lahko vrtenje')
  })
})

describe('R5: po 8+ dneh premora tudi tek prva dva dneva lahko', () => {
  it('tekač po 14 dneh premora: 2. in 3. 11. brez ključnega teka', () => {
    const p = P({ focus: RUN_FOCUS as never, event: null, goal: null as never, cycleStart: '2026-09-07', weekPause: { from: '2026-10-19', to: '2026-11-01', mode: 'vse' } })
    const w = buildWeek({ profile: p, activities: [], weekStart: '2026-11-02', notBefore: '2026-11-02', today: '2026-11-02' })
    const first2 = w.filter(d => d.date <= '2026-11-03' && d.kind === 'tek')
    expect(first2.length).toBeGreaterThan(0)
    expect(first2.some(d => d.role === 'kljucna' || /Z[45]/.test(d.zone || ''))).toBe(false)
    const easy = w.find(d => d.title === BACK_TITLE_RUN)!
    expect(easy).toMatchObject({ kind: 'tek', zone: 'Z2', role: 'lahka' })
    expect(easy.durationMin).toBeLessThanOrEqual(40)
    expect(easy.why).toMatch(/^Po dveh tednih premora/)
    // kasneje v tednu ključni tek ostane
    expect(w.some(d => d.date > '2026-11-03' && d.kind === 'tek' && d.role !== 'lahka')).toBe(true)
  })
})

describe('R6: angleška imena vaj s slike', () => {
  const T6: [string, string | null][] = [
    ['Leg curl', 'leg-curl'], ['Hamstring curl', 'leg-curl'], ['Lying leg curl', 'leg-curl'], ['Seated leg curl', 'leg-curl'],
    ['Upright row', null], ['Inverted row', null], ['T-bar row', null], ['Bench dips', 'dipi'], ['Dips', 'dipi'],
    ['Incline push-ups', 'sklece'], ['Leg swings', null], ['Nordic hamstring curl', null],
    // ostane kot prej
    ['Incline dumbbell press', 'incline-r'], ['Incline DB press', 'incline-r'], ['Bench press', 'bench'], ['Dumbbell curl', 'biceps-r'], ['Barbell curl', 'biceps-p'],
    ['Kettlebell swings', 'zamah'], ['KB swing', 'zamah'], ['Rowing', 'veslo'], ['Row 500 m', 'veslo'], ['Concept2', 'veslo'], ['Bent-over row', 'veslanje-p'],
    ['Seated cable row', 'kabel-v'], ['DB row', 'veslanje-r'], ['Push-ups', 'sklece'],
  ]
  it.each(T6)('%s → %s', (name, id) => { expect(matchExercise(name)?.id ?? null).toBe(id) })
})

describe('R7: % utripa s slike ni % FTP', () => {
  it.each([['90-95% HRmax', 'RPE 9'], ['80% max HR', 'RPE 7'], ['85 % maks. utripa', 'RPE 8'], ['75–80 % FCmax', 'RPE 7'], ['65 % MHR', 'lahko'], ['88 % srčnega utripa', 'RPE 8']])('%s → %s', (s, want) => {
    expect(atOf(s)).toBe(want)
  })
  it('% FTP in vati ostanejo', () => {
    expect(atOf('90-95% FTP')).toBe('90–95 % FTP')
    expect(atOf('105 %')).toBe('105–105 % FTP')
    expect(atOf('250-270 W')).toBe('250–270 W')
    expect(atOf('utrip 150-160')).toBe('utrip 150–160')
  })
})

describe('R8: bloki po lahkem začetku — brez podvojenega tedna, največ 4 obremenilni zapored', () => {
  const scan = (cs: string) => {
    const p = P({ cycleStart: cs, age: 21 })
    const seq: string[] = []
    let run = 0, maxRun = 0, lastR = -99, minGap = 99, dup = 0, startsWith2 = 0, prevBw = -1, prevRec = false
    const tests: number[] = []
    for (let k = 0, ws = cs; ws <= '2027-06-07'; k++, ws = addDays(ws, 7)) {
      const c = weekContext(p, ws)
      const load = !c.recovery && !c.easy && (c.phase === 'osnova' || c.phase === 'gradnja' || c.phase === 'specificno')
      if (c.recovery) { if (lastR >= 0) minGap = Math.min(minGap, k - lastR); lastR = k }
      run = load ? run + 1 : 0; maxRun = Math.max(maxRun, run)
      if (load && c.blockWeek === prevBw) dup++
      if (load && prevRec && c.blockWeek !== 1) startsWith2++
      if (c.test) tests.push(k)
      prevBw = load ? c.blockWeek : -1; prevRec = c.recovery && c.phase !== 'prehod'
      seq.push(c.easy ? 'e' : c.recovery ? (c.test ? 'T' : 'R') : c.phase === 'tapering' ? 't' : c.phase === 'dirka' ? 'D' : String(c.blockWeek))
    }
    const tgap = tests.slice(1).map((t, i) => t - tests[i]!)
    return { cs, maxRun, minGap, dup, startsWith2, tgap, seq: seq.join('') }
  }
  const starts: string[] = []
  for (let cs = '2026-05-04'; cs <= '2027-01-25'; cs = addDays(cs, 7)) starts.push(cs)
  it(`${starts.length} začetkov (4. 5. 2026–25. 1. 2027) in Blaž (31. 8., 21. 9. 2026)`, () => {
    expect(starts.length).toBeGreaterThanOrEqual(30)
    expect(starts).toContain('2026-08-31'); expect(starts).toContain('2026-09-21')
    const bad = starts.map(scan).filter(r => r.maxRun > 4 || r.minGap < 3 || r.dup > 0 || r.startsWith2 > 0 || r.tgap.some(g => g < 4 || g > 12))
    expect(bad).toEqual([])
  })
  it('Blaž (31. 8. 2026): 8. in 15. 3. 2027 nista oba »1. teden bloka«; 3. teden ostane ×1,12', () => {
    const p = P({ cycleStart: '2026-08-31', age: 21 })
    const a = weekContext(p, '2027-03-08'), b = weekContext(p, '2027-03-15')
    expect(a.blockWeek === 1 && b.blockWeek === 1).toBe(false)
    const third = Array.from({ length: 30 }, (_, k) => weekContext(p, addDays('2026-09-21', 7 * k))).find(c => c.blockWeek === 3 && !c.recovery && c.phase === 'gradnja')!
    expect(third.volume).toBeCloseTo(1.12, 2)
  })
})

describe('R9: besedilo po premoru iz dolžine premora', () => {
  const acts: Activity[] = []
  for (let ws = '2026-08-31'; ws <= '2026-10-19'; ws = addDays(ws, 7)) for (const k of [1, 3, 5]) acts.push(ride(addDays(ws, k), 160))
  it('8 dni (nedelja + naslednji teden): »Po 8 dneh premora«, ne »dveh tednih«', () => {
    const w = pausePeriod('2026-10-25', 'vse', { twoWeeks: true })
    expect(pauseDays(w)).toBe(8)
    const b = buildWeek({ profile: P({ weekPause: w, age: 21 }), activities: acts, weekStart: '2026-11-02', notBefore: '2026-11-02', today: '2026-11-02' })
    const whys = b.map(d => d.why || '').filter(x => /premor/i.test(x))
    expect(whys.length).toBeGreaterThan(0)
    expect(whys.some(x => /Po 8 dneh premora/.test(x))).toBe(true)
    expect(whys.some(x => /dveh tednih/.test(x))).toBe(false)
  })
  it('14 dni: »Po dveh tednih premora«', () => {
    const b = buildWeek({ profile: P({ weekPause: { from: '2026-10-19', to: '2026-11-01', mode: 'vse' }, age: 21 }), activities: acts, weekStart: '2026-11-02', notBefore: '2026-11-02', today: '2026-11-02' })
    expect(b.some(d => /^Po dveh tednih premora/.test(d.why || ''))).toBe(true)
  })
})

describe('R10: razlaga daljše dolge vožnje z dejanskim deležem dirke', () => {
  it('kolesarka 5 h: odstotek v razlagi = dolga / dirka', () => {
    const p = P({ name: 'K', sex: 'z', age: 35, heightCm: 168, weightKg: 62, ftp: 170, ftpDate: '2026-12-20', maxHr: 185, restHr: 52, lthr: 168, level: 2, gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: true }, hoursPerWeek: 5, strength: { on: false, equipment: 'home' }, strengthDays: 0, deficit: 0 })
    const race = raceMinutes(p.event!, p)
    const rows: { min: number; why: string }[] = []
    for (let ws = '2027-01-11'; ws <= '2027-05-24'; ws = addDays(ws, 7)) {
      const acts: Activity[] = []; for (let w = '2026-11-02'; w < ws; w = addDays(w, 7)) for (const k of [1, 3, 5]) acts.push(ride(addDays(w, k), 100))
      const long = buildWeek({ profile: p, activities: acts, weekStart: ws, notBefore: ws, today: ws }).find(d => d.role === 'dolga' && /% dirke, ki traja/.test(d.why || ''))
      if (long) rows.push({ min: long.durationMin, why: long.why! })
    }
    expect(rows.length).toBeGreaterThan(0)
    for (const r of rows) {
      expect(r.why).toContain(`~${Math.round((100 * r.min) / race)} % dirke`)
      expect(r.why).not.toMatch(/75 % njenega/)
    }
  })
})
