// v3.48 U2 — Plan in dogovor: urejanje dneva ne spremeni TSS, sezona iz ur načrta, ena vrstica o urah, teden tekme,
// dan polnjenja z OH, os sezone z mesecem »zdaj«, list cilja (ure, začetek), obvestilo ob tekmi, kolesarski dogovor
// kaže teden, ki ga bo načrt res imel.
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, afterEach, beforeAll, afterAll } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'plan', params: {} as Record<string, string> } }))
vi.mock('@/state/store', async () => {
  const { vi: v } = await import('vitest')
  const base: Record<string | symbol, unknown> = {
    useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
    getState: () => S.state,
  }
  // vse druge funkcije stanja so prazne (zaslon jih kliče samo ob tapu)
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' || typeof k === 'symbol' ? undefined : (t[k] = v.fn(async () => {}))), has: (_t, k) => k !== 'then' })
})
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => S.route }))
vi.mock('@/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import { applyDayEdit, plannedMacro, monthsOverview, hoursLine, Plan } from '@/screens/Plan'
import { monthMarks, SeasonChart, WeekRibbon, Ahead } from '@/ui/PlanHero'
import { inBuiltWeeks } from '@/ui/Races'
import { GoalSheet } from '@/ui/GoalSheet'
import { firstBikeWeek, Deal } from '@/screens/Sestavi'
import { CheckBtn } from '@/ui/primitives'
import { buildWeek, planHours } from '@/domain/training/planner'
import { normalizeFocus, profileFromFocus, usesAgreement } from '@/domain/focus/model'
import { addDays } from '@/domain/training/load'
import type { Activity, PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-17'   // sobota
beforeAll(() => { vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date(`${TODAY}T10:00:00`)) })
afterAll(() => { vi.useRealTimers() })

let div: HTMLDivElement | null = null, root: Root | null = null
async function render(el: ReactElement): Promise<HTMLDivElement> {
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root!.render(el) })
  return div
}
afterEach(async () => { if (root) await act(async () => root!.unmount()); div?.remove(); root = null; div = null })
const sp = (x: string) => x.replace(/[\u00a0\u202f\u2060]/g, ' ')
const txt = (d: Element) => sp(d.textContent || '')

const NOW = `${TODAY}T08:00:00.000Z`
const day = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: date + (o.kind || 'kolo') + (o.role || ''), date, kind: 'kolo', title: 'Z2 vzdržljivost', desc: 'Mirno v Z2.', durationMin: 60, zone: 'Z2', role: 'lahka', tssTarget: 42, source: 'rules', createdAt: NOW, updatedAt: NOW, ...o })
const rest = (date: string, title = 'Počitek'): PlanDay => day(date, { kind: 'pocitek', title, desc: 'Prosto.', durationMin: 0, zone: null, role: null, tssTarget: 0 })
const P = {
  sex: 'm', age: 30, heightCm: 180, weightKg: 75, ftp: 250, ftpDate: '2026-10-01', maxHr: 190, restHr: 50, level: 3, hoursPerWeek: 11, hoursMode: 'own',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true }, strength: { on: false, equipment: 'none' }, strengthDays: 0,
  onboardingDone: true, goal: 'dirka', createdAt: NOW, updatedAt: NOW,
} as unknown as Profile
const FRANJA = { name: 'Maraton Franja', date: '2027-06-13', distanceKm: 156, type: 'maraton' as const }
// zadnji trije tedni ~3,5 h na teden → načrt raste od tega (realityCap)
const ride = (date: string, min: number, tss = 50): Activity => ({ id: 'a' + date + min, source: 'manual', sport: 'kolo', date, name: 'Vožnja', durationMin: min, tss } as Activity)
const ACTS: Activity[] = ['2026-09-22', '2026-09-26', '2026-09-29', '2026-10-03', '2026-10-06', '2026-10-10'].map(d => ride(d, 105))
const state = (o: Record<string, unknown> = {}) => ({ ready: true, today: TODAY, profile: P, activities: ACTS, plan: [], checkins: [], weather: null, user: null, changes: [], settings: {}, sync: { state: 'ok' }, mealsToday: [], recentMeals: [], ...o })

describe('B06/B29 Uredi → Shrani', () => {
  const vo2 = day('2026-10-20', { title: 'VO2max 4 × 4 min', desc: '4 × 4 min trdo.', durationMin: 75, zone: 'Z5', role: 'kljucna', tssTarget: 68 })
  const form = (o: Partial<{ kind: PlanDay['kind']; title: string; dur: string; zone: string; desc: string }> = {}) => ({ kind: vo2.kind, title: vo2.title, dur: String(vo2.durationMin), zone: vo2.zone!, desc: vo2.desc, ...o })
  it('brez sprememb TSS ostane (prej 68 → 125)', () => {
    expect(applyDayEdit(vo2, form(), []).tssTarget).toBe(68)
    expect(applyDayEdit(vo2, form({ title: 'VO2max' }), []).tssTarget).toBe(68)
  })
  it('samo trajanje → TSS sorazmerno; druga cona → po coni', () => {
    expect(applyDayEdit(vo2, form({ dur: '150' }), []).tssTarget).toBe(136)
    expect(applyDayEdit(vo2, form({ zone: 'Z2' }), []).tssTarget).toBe(63)   // 75 min × 50/h
  })
  it('vožnja 6 h 30 ostane 6 h 30 (prej skrajšana na 6 h)', () => {
    const long = day('2026-10-24', { title: 'Dolga Z2', durationMin: 390, tssTarget: 250, role: 'dolga' })
    const d = applyDayEdit(long, { kind: 'kolo', title: long.title, dur: '390', zone: 'Z2', desc: long.desc }, [])
    expect(d.durationMin).toBe(390)
    expect(d.tssTarget).toBe(250)
    expect(applyDayEdit(long, { kind: 'kolo', title: long.title, dur: '600', zone: 'Z2', desc: long.desc }, []).durationMin).toBe(480)
  })
})

describe('B07 sezona in »Ure po mesecih« iz ur načrta', () => {
  const p = { ...P, event: FRANJA, cycleStart: '2026-09-21' } as Profile
  it('ure tedna = planHours (pretekli, ta in prihodnji tedni), ne zgornja meja faze', () => {
    const m = plannedMacro(p, ACTS, TODAY)
    expect(m.length).toBeGreaterThan(30)
    for (const w of m.slice(0, 10)) expect(w.hours).toBe(planHours(p, ACTS, w.weekStart, TODAY).hours)
    const now = m.find(w => w.weekStart === '2026-10-12')!
    expect(now.hours).toBeLessThan(8)   // zgornja meja faze je bila 9,5 h
    const oct = monthsOverview(m, '2026-10-12').find(x => x.ym === '2026-10')!
    expect(oct.now).toBe(true)
    expect(oct.lo).toBeLessThanOrEqual(now.hours)
  })
  it('stolpec tega tedna kaže iste ure; pri »Naslednji« tekoči teden ni bled, »zdaj« je nad piko tekme', async () => {
    S.state = state({ profile: p })
    const m = plannedMacro(p, ACTS, TODAY)
    const d = await render(<SeasonChart macro={m} profile={p} start="2026-10-19" today={TODAY} />)
    const bars = [...d.querySelectorAll('.pl-bar')]
    const i = m.findIndex(w => w.weekStart === '2026-10-12')
    expect(bars[i]!.classList.contains('past')).toBe(false)
    expect(bars[i]!.classList.contains('now')).toBe(true)
    expect(bars[i - 1]!.classList.contains('past')).toBe(true)
    // (v3.50) stolpci so en drsnik: ure izbranega tedna so v aria-valuetext (prej aria-label vsakega gumba)
    const sl = d.querySelector('[role="slider"]')!
    await act(async () => { sl.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowLeft', bubbles: true })) })
    expect(sl.getAttribute('aria-valuetext')).toContain(`${String(m[i]!.hours).replace('.', ',')} h`)
  })
})

describe('B23 os sezone', () => {
  it('mesec z »zdaj« ostane na osi (prej »SEP« brez »OKT«)', () => {
    const ws = ['2026-09-21', '2026-09-28', '2026-10-05', '2026-10-12', '2026-10-19']
    expect(monthMarks(ws, 3).map(x => x.label)).toContain('okt')
    expect(monthMarks([...ws, '2026-10-26', '2026-11-02', '2026-11-09'], 3).map(x => x.label)).toEqual(['okt', 'nov'])
  })
  it('ob trku ostane poznejši mesec, razen če je prejšnji mesec tisti z »zdaj«', () => {
    expect(monthMarks(['2026-09-21', '2026-09-28', '2026-10-05', '2026-10-12'], 0).map(x => x.label)).toEqual(['sep'])
    expect(monthMarks(['2026-09-28', '2026-10-05', '2026-10-12', '2026-10-19', '2026-10-26', '2026-11-02'], -1).map(x => x.label)).toEqual(['okt', 'nov'])
  })
})

describe('B08 ena vrstica o urah', () => {
  it('ta teden, rast do normalnega tedna in najtežji teden — brez drugih »ciljnih« ur', () => {
    const s = sp(hoursLine({ now: 4.5, normal: 11, to: 11, peak: 12.5, grows: true, from: '2026-12-21' }))
    expect(s).toBe('4,5 h ta teden — raste ~10 % na teden do 11 h (od 21. 12.), najtežji teden bloka ~12,5 h.')
    expect(sp(hoursLine({ now: 5.5, normal: 11, to: 11, peak: 12.5, grows: false, wk: 'ta teden (razbremenilni)' }))).toBe('5,5 h ta teden (razbremenilni) · normalen teden 11 h (najtežji ~12,5 h).')
    expect(sp(hoursLine({ now: 11, normal: 11, to: 11, peak: 12.5, grows: true }))).toBe('11 h ta teden (najtežji teden bloka ~12,5 h).')
  })
})

describe('Plan: teden tekme, »jutri«, polnjenje OH, krogi za bralnik, prejšnji teden, brez vsiljene dirke', () => {
  // tekma (cilj sezone) jutri v nedeljo; četrtek je polnjenje z OH
  const race = day('2026-10-18', { title: 'Kriterij — 80 km', kind: 'kolo', durationMin: 175, zone: 'dirka', role: 'dirka', tssTarget: 160 })
  const week = [rest('2026-10-12'), day('2026-10-13', { title: 'Pospeški 4 × 1 min', zone: 'Z5', role: 'kljucna', durationMin: 45, done: { at: NOW } as PlanDay['done'] }), day('2026-10-14', { durationMin: 45 }), day('2026-10-15', { title: 'Tempo dirke', zone: 'Z4', role: 'kljucna', durationMin: 50 }), rest('2026-10-16', 'Počitek + polnjenje OH'), day('2026-10-17', { title: 'Predaktivacija', durationMin: 45 }), race]
  const prof = { ...P, event: { name: 'Kriterij', date: '2026-10-18', distanceKm: 80 }, cycleStart: '2026-08-10' } as Profile
  async function open(title: string, d: HTMLDivElement) {
    const b = [...d.querySelectorAll('button.sec-h')].find(x => x.textContent?.includes(title)) as HTMLButtonElement
    await act(async () => { b.click() })
  }
  it('B31/B14/B10/B30: »Kriterij jutri«, treningi in tekma posebej, brez »cilj: okoli 80 %«, polnjenje OH, ime dneva na krogu', async () => {
    S.route = { name: 'plan', params: {} }
    S.state = state({ profile: prof, plan: week })
    const d = await render(<Plan />)
    expect(txt(d)).toContain('Kriterij jutri')
    expect(txt(d)).not.toContain('čez 1 dan')
    expect([...d.querySelectorAll('.pl-day')].some(x => x.getAttribute('aria-label')?.includes('počitek, polnjenje OH'))).toBe(true)
    await act(async () => { (d.querySelector('button.pl-past-t') as HTMLButtonElement).click() })
    expect(txt(d)).toContain('Počitek · polnjenje OH')
    await open('Teden v številkah', d)
    const t = txt(d)
    expect(t).toMatch(/Treningi 3 h 05 min · tekma 2 h 55 min/)
    expect(t).not.toContain('cilj tedna')
    expect(t).not.toContain('cilj: okoli 80')
    const check = [...d.querySelectorAll('button.check-hit')].map(b => b.getAttribute('aria-label'))
    expect(check.some(l => /^sobota, 17\. 10\.: Predaktivacija — označi kot opravljeno$/.test(sp(l || '')))).toBe(true)
  })
  it('B32: prejšnji teden — opravljeni TSS od načrtovanih', async () => {
    const last = [day('2026-10-06', { tssTarget: 80, done: { at: NOW, activityId: 'aX' } as PlanDay['done'] }), day('2026-10-08', { tssTarget: 100 }), day('2026-10-10', { tssTarget: 120 })]
    S.route = { name: 'plan', params: { dan: '2026-10-06' } }
    S.state = state({ profile: { ...P, event: FRANJA, cycleStart: '2026-09-21' }, plan: last, activities: [...ACTS, { ...ride('2026-10-06', 70, 64), id: 'aX' }] })
    const d = await render(<Plan />)
    expect(txt(d)).toContain('64 od 300 TSS opravljenih')
  })
  it('B35: hujšanje brez cilja — brez predloga dirke', async () => {
    S.route = { name: 'plan', params: {} }
    S.state = state({ profile: { ...P, goal: 'shujsati', event: null }, plan: [day('2026-10-17')] })
    const d = await render(<Plan />)
    expect(txt(d)).toContain('Načrt teče v 12-tedenskih ciklih. Imaš tekmo ali cilj z datumom? Dodaj ga.')
    expect(txt(d)).not.toContain('Franja')
  })
  it('B08/B46: v enem razdelku ena vrstica o urah, brez ponovljenega naslova in »raste od 7 h«', async () => {
    S.route = { name: 'plan', params: {} }
    const p = { ...P, event: FRANJA, cycleStart: '2026-09-21', baseHours: 5.8 } as Profile
    S.state = state({ profile: p, plan: [day('2026-10-17', { durationMin: 120 }), day('2026-10-18', { durationMin: 150 })] })
    const d = await render(<Plan />)
    await open('Ure na teden po mesecih', d)
    const t = txt(d)
    expect(t.match(/Ure na teden po mesecih/gi)!.length).toBe(1)
    const h = planHours(p, ACTS, '2026-10-12', TODAY).hours
    expect(t).toContain(`${String(h).replace('.', ',')} h ta teden — raste ~10 % na teden do 11 h`)
    await open('Teden v številkah', d)
    expect(txt(d)).not.toMatch(/raste od 7 h|cilj tedna/)
  })
})

describe('B10 trak in »2 tedna«: dan polnjenja z OH', () => {
  it('trak: »počitek, polnjenje OH« in »OH«; 2 tedna: »Počitek · polnjenje OH«; trajanja brez preloma', async () => {
    const days = Array.from({ length: 7 }, (_, i) => addDays('2026-10-12', i))
    const items = [rest('2026-10-16', 'Počitek + polnjenje OH'), day('2026-10-17', { durationMin: 105 })]
    const d = await render(<WeekRibbon days={days} items={items} today={TODAY} focus={TODAY} onPick={() => undefined} />)
    const carb = [...d.querySelectorAll('.pl-day')].find(x => x.getAttribute('aria-label')?.includes('polnjenje OH'))!
    expect(carb.classList.contains('carb')).toBe(true)
    expect(carb.textContent).toContain('OH')
    await act(async () => root!.unmount()); div!.remove()
    const a = await render(<Ahead items={[rest('2026-10-21', 'Počitek + polnjenje OH'), day('2026-10-17', { durationMin: 105 })]} preview={new Set()} today={TODAY} onPick={() => undefined} />)
    expect(a.textContent).toContain('Počitek · polnjenje OH')
    expect(a.querySelector('.ah-h span')!.textContent).toContain('1\u00a0h\u00a045\u00a0min')   // nedeljivi presledki
  })
})

describe('B30 krog »opravljeno« z imenom dneva', () => {
  it('bralnik zaslona sliši dan in vadbo', async () => {
    const d = await render(<CheckBtn on={false} label="torek, 20. 10.: Z2" />)
    expect(d.querySelector('button')!.getAttribute('aria-label')).toBe('torek, 20. 10.: Z2 — označi kot opravljeno')
  })
})

describe('B22 obvestilo ob tekmi', () => {
  it('»načrt je že prilagojen« samo za ta in naslednji teden (prej tudi za tekmo čez 13 dni)', () => {
    expect(inBuiltWeeks('2026-10-25', TODAY)).toBe(true)
    expect(inBuiltWeeks('2026-10-30', TODAY)).toBe(false)   // danes + 13
    expect(inBuiltWeeks('2026-10-26', TODAY)).toBe(false)
  })
})

describe('B16/B45 list cilja', () => {
  it('B16: ne »največ X h« in »vsaj ~14,5 h« hkrati — en stavek, kar zgradiš do tekme', async () => {
    S.state = state({ profile: { ...P, event: FRANJA, hoursMode: 'own', hoursPerWeek: 6 }, activities: [] })
    await render(<GoalSheet open onClose={() => undefined} />)
    const t = txt(document.body)   // list je v portalu
    expect(t).not.toMatch(/vsaj ~\d/)
    expect(t).toMatch(/Maraton Franja traja ~[\d,]+ h; do tekme varno zgradiš ~8 h na teden/)
  })
  it('B45: pri 3 h brez prazne vrstice »Načrt začne pri« in brez predloga nad izbranim', async () => {
    const many = Array.from({ length: 16 }, (_, k) => ride(addDays('2026-08-24', k * 3 + (k % 2)), 150))
    S.state = state({ profile: { ...P, event: FRANJA, hoursMode: 'own', hoursPerWeek: 3 }, activities: many })
    await render(<GoalSheet open onClose={() => undefined} />)
    const t = txt(document.body)
    expect(t).not.toContain('Načrt začne pri')
    expect(t).toContain('3 h že ta teden — manj, kot zdaj voziš.')
  })
})

describe('B04 kolesarski dogovor kaže teden, ki ga bo načrt res imel', () => {
  const f = normalizeFocus({
    wish: 'Kolo: zunaj. Maraton ali granfondo', sports: ['kolo'], aims: ['kondicija', 'vzdrzljivost', 'tekma'], level: 3, equipment: [],
    sessions: [{ type: 'kolo', cardio: 'intervali', min: 85 }, { type: 'kolo', cardio: 'tempo', min: 85 }, { type: 'kolo', cardio: 'lahko', min: 90 }, { type: 'kolo', cardio: 'dolgo', min: 135 }, { type: 'kolo', cardio: 'lahko', min: 85 }],
    offDays: [1, 3], notes: [],
  }, { age: 30, by: 'pravila' })!
  it('prvi teden = buildWeek naslednjega tedna s profilom iz dogovora', () => {
    expect(usesAgreement(f)).toBe(false)
    const w = firstBikeWeek(f, P, ACTS, TODAY)
    expect(w.weekStart).toBe('2026-10-19')
    const prof = { ...P, ...profileFromFocus(f, P, '2026-10-12', TODAY) } as Profile
    const ref = buildWeek({ profile: prof, activities: ACTS, weekStart: '2026-10-19', notBefore: '2026-10-19', checkins: [], today: TODAY })
    expect(w.days.map(x => `${x.date}|${x.kind}|${x.title}|${x.durationMin}`)).toEqual(ref.map(x => `${x.date}|${x.kind}|${x.title}|${x.durationMin}`))
    expect(w.event).toBe(false)
  })
  it('predlog: trak iz načrta, brez dogovorjenih sej in »Zakaj tako« o dnevih; besedilo brez datuma tekme', async () => {
    S.state = state({ profile: { ...P, event: null } })
    const d = await render(<Deal f={{ ...f, why: ['Težki dnevi (pon, sre) imajo vmes dan premora.'] }} />)
    const t = txt(d)
    expect(t).not.toContain('Kolo · intervali')
    expect(t).not.toContain('Težki dnevi (pon, sre)')
    expect(t).toContain('Kolesarski načrt v 12-tedenskih ciklih. Ko dodaš tekmo z datumom, se ji prilagodi.')
    const w = firstBikeWeek(f, { ...P, event: null } as Profile, ACTS, TODAY)
    const labels = [...d.querySelectorAll('.pl-day')].map(x => x.getAttribute('aria-label'))
    const train = w.days.filter(x => x.kind !== 'pocitek' && !x.optional)
    expect(train.length).toBeGreaterThan(0)
    for (const x of train) expect(labels.some(l => l?.includes(x.title))).toBe(true)
  })
  it('s tekmo z datumom: »Kolesarski načrt do tekme«', async () => {
    S.state = state({ profile: { ...P, event: FRANJA } })
    const d = await render(<Deal f={f} />)
    // v3.49 (C01, C03): z imenom in datumom tekme, brez »vati« (vati ima samo, kdor ima merilnik moči)
    expect(txt(d)).toContain('Kolesarski načrt do tekme Maraton Franja (13. 6. 2027): faze, vrh forme in teden dirke.')
  })
})
