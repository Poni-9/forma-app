import { describe, it, expect } from 'vitest'
import { pilotDue, afterAsk, cleanCode, pmfOf, QUESTIONS, type PilotState } from '../src/domain/pilot'

const add = (iso: string, n: number) => new Date(Date.parse(iso + 'T12:00:00Z') + n * 86_400_000).toISOString().slice(0, 10)

describe('testni program: en klik A–D, enkrat na teden', () => {
  const start = '2026-09-01'
  it('prvi teden nič; nato najprej »ali je načrt prav težak«, potem »ali veš, kaj narediti«', () => {
    expect(pilotDue({}, start, add(start, 6))).toBeNull()
    const q1 = pilotDue({}, start, add(start, 7))!
    expect(q1.q).toBe('plan_fit')
    expect(q1.options).toHaveLength(4)
    const s1 = afterAsk({}, q1.q, add(start, 7))
    expect(pilotDue(s1, start, add(start, 13))).toBeNull()                      // največ eno na teden
    expect(pilotDue(s1, start, add(start, 14))!.q).toBe('clarity')
  })
  it('vsa vprašanja imajo 4 odgovore in razlog; ključna so prva', () => {
    for (const q of QUESTIONS) { expect(q.options).toHaveLength(4); expect(q.why.length).toBeGreaterThan(5) }
    expect(QUESTIONS.slice(0, 5).map(q => q.q)).toEqual(['plan_fit', 'clarity', 'plan_block', 'value', 'pmf'])
  })
  it('20 tednov: vsak teden eno vprašanje, brez ponavljanja pred rokom; prehrana in trener samo, če ju uporablja', () => {
    let s: PilotState = {}
    const seen: string[] = []
    for (let w = 1; w <= 20; w++) {
      const d = add(start, w * 7)
      const q = pilotDue(s, start, d, { meals: false, coach: true })
      expect(q).not.toBeNull()
      seen.push(q!.q); s = afterAsk(s, q!.q, d)
    }
    expect(seen).not.toContain('nutrition')
    expect(seen).toContain('coach'); expect(seen).toContain('pmf'); expect(seen).toContain('pay')
    // plan_fit največ vsake 3 tedne
    const idx = seen.map((q, i) => (q === 'plan_fit' ? i : -1)).filter(i => i >= 0)
    for (let k = 1; k < idx.length; k++) expect(idx[k]! - idx[k - 1]!).toBeGreaterThanOrEqual(3)
  })
  it('preskok šteje (ne sprašuje takoj znova); »ne sprašuj več« = nikoli; brez začetka = nič', () => {
    const s = afterAsk({}, 'plan_fit', add(start, 8))
    expect(pilotDue(s, start, add(start, 9))).toBeNull()
    expect(pilotDue({ optOut: true }, start, '2027-01-01')).toBeNull()
    expect(pilotDue({}, null, '2027-01-01')).toBeNull()
  })
  it('koda povabila in PMF (brez tistih, ki je ne uporabljajo)', () => {
    expect(cleanCode(' kk-rog! ')).toBe('KK-ROG')
    expect(cleanCode('kk rog')).toBe('KK-ROG')
    expect(cleanCode('')).toBeNull()
    expect(cleanCode('A'.repeat(40))).toHaveLength(24)
    expect(pmfOf(['a', 'a', 'b', 'c', 'd'])).toEqual({ pct: 50, n: 4 })
    expect(pmfOf(['d'])).toBeNull()
  })
})
