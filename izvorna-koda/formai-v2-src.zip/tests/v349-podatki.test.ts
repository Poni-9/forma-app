// v3.49 PODATKI — zanesljivost podatkov in obrazcev: razponi testov in uvoza kopije, obrok brez imena, polna in
// blokirana shramba, dva zavihka, tehtanje (skok, izbris) in jutranji vnos (izbris z grobom), iskanje vadb,
// »Izbriši na napravi« pri prijavljenem.
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach } from 'vitest'

const FB = vi.hoisted(() => ({ user: null as null | { uid: string; email: string; name: string }, onSignOut: null as null | (() => Promise<void>) }))
vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => FB.user, signOutNow: async () => { await FB.onSignOut?.() },
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { resetDbForTests, db } from '../src/data/db'
import { todayIso, addDays } from '../src/domain/training/load'
import { parseBackup } from '../src/data/backup'
import { fromCloud } from '../src/data/sync'
import { normalizeMeal } from '../src/data/normalize'
import { mergeCheckins, mergeState, tombCheckin, type SyncState } from '../src/data/merge'
import { testError, testJump, TEST_RANGE, PROFILE_RANGE } from '../src/domain/ranges'
import { weighJump, swappedDigits, recentWeighs } from '../src/domain/weigh'
import { weightTrend } from '../src/domain/nutrition/energy'
import { filterActs } from '../src/screens/Aktivnosti'
import { frequentMeals } from '../src/screens/Prehrana'
import { _resetUndo } from '../src/ui/Confirm'
import type { Activity, DailyCheckin, MealEntry, TestEntry } from '../src/domain/types'

// shramba računa »danes« sama (todayIso); čiste funkcije dobijo datum izrecno (D)
const TODAY = todayIso()
const D = '2026-10-17'
const NOW = '2026-10-17T08:00:00.000Z'
const meal = (id: string, o: Partial<MealEntry> = {}): MealEntry => ({ id, date: TODAY, time: '08:00', slot: 'zajtrk', name: 'Ovseni kosmiči', grams: null, kcal: 400, proteinG: 20, carbsG: null, fatG: null, confidence: 'srednja', source: 'manual', thumb: null, createdAt: NOW, ...o })
const ftpTest = (id: string, date: string, value: number): TestEntry => ({ id, date, kind: 'ftp', value, unit: 'W' })
const lastToast = () => store.getState().toast?.msg ?? ''

beforeEach(async () => { _resetUndo(); FB.user = null; FB.onSignOut = null; await repo.wipeAll(); localStorage.clear(); await store.reloadAll() })

describe('D03 test FTP in mirovni utrip: razponi', () => {
  it('20-min test 5000 W in utrip 900 dobita sporočilo; 300 W ne', () => {
    expect(testError('ftp', 5000)).toBe('20-min test: od 60 do 630\u00a0W.')
    expect(testError('ftp', '2400')).toBe('20-min test: od 60 do 630\u00a0W.')
    expect(testError('rhr', 900)).toBe('Mirovni utrip: od 25 do 120.')
    expect(testError('ftp', 300)).toBeNull()
    expect(testError('p5', 5000)).toMatch(/^5-min test: od 80 do 800\u00a0W\.$/)
    // FTP iz najvišjega dovoljenega testa ostane v razponu profila (sicer bi profil kazal napako)
    expect(Math.round(TEST_RANGE.ftp[1] * 0.95)).toBeLessThanOrEqual(PROFILE_RANGE.ftp[1])
  })
  it('skok nad 15 % od zadnjega testa (ali FTP) vpraša, manjši ne', () => {
    expect(testJump('ftp', 340, 240, 228)).toBe('To je 42 % več od zadnjega testa (240 W). Shranim?')
    expect(testJump('ftp', 180, 240, null)).toBe('To je 25 % manj od zadnjega testa (240 W). Shranim?')
    expect(testJump('ftp', 260, 240, null)).toBeNull()
    expect(testJump('ftp', 330, null, 240)).toMatch(/^To je \d+ % več od tvojega FTP \(240 W\)\. Shranim\?$/)
    expect(testJump('rhr', 90, 50, null)).toBeNull()
    expect(testJump('ftp', 300, null, null)).toBeNull()
  })
  it('addTest z rezultatom izven razpona ne shrani testa in ne prepiše FTP', async () => {
    await store.updateProfile({ ftp: 240, ftpDate: '2026-09-01', weightKg: 75 })
    await store.addTest(ftpTest('x', TODAY, 5000))
    expect(store.getState().profile.ftp).toBe(240)
    expect((await repo.loadSettings()).tests || []).toEqual([])
    expect(lastToast()).toBe('20-min test: od 60 do 630\u00a0W.')
    await store.addTest({ id: 'r', date: TODAY, kind: 'rhr', value: 900, unit: 'bpm' })
    expect(store.getState().profile.restHr ?? null).toBeNull()
  })
})

describe('D09 obrok brez imena ne sesuje Prehrane', () => {
  const bare = { id: 'b1', date: TODAY, kcal: 300 } as unknown as MealEntry
  it('normalizeMeal: ime »Obrok«, obrok »drugo«, čas vpisa; veljaven obrok ostane isti predmet; neznan vir ostane', () => {
    const m = normalizeMeal(bare)
    expect(m).toMatchObject({ id: 'b1', name: 'Obrok', slot: 'drugo', kcal: 300, source: 'manual', createdAt: `${TODAY}T12:00:00.000Z` })
    const ok = meal('a')
    expect(normalizeMeal(ok)).toBe(ok)
    const odd = meal('o', { source: 'plan' as MealEntry['source'], slot: 'pred' as MealEntry['slot'] })
    expect(normalizeMeal(odd)).toBe(odd)
  })
  it('kopija, oblak in shramba vrnejo obrok z imenom; pogosti obroki ne vržejo', async () => {
    expect(parseBackup(JSON.stringify({ version: 2, meals: [bare] })).state.meals[0]!.name).toBe('Obrok')
    expect(fromCloud({ meals: [bare] }).meals[0]!.name).toBe('Obrok')
    // zapis, ki je že v bazi (star uvoz), se popravi ob branju
    await (await db()).put('meals', bare)
    const rows = await repo.mealsBetween(addDays(TODAY, -10), TODAY)
    expect(rows.map(m => m.name)).toEqual(['Obrok'])
    expect(() => frequentMeals([...rows, ...rows])).not.toThrow()
    expect((await repo.mealsOn(TODAY))[0]!.name).toBe('Obrok')
  })
})

describe('D12 uvoz kopije spoštuje razpone', () => {
  it('−45 min, 9 999 km, utrip 900, 5000 W → null (vadba ostane); 99 999 kcal in 7,6 kg izpuščena; profil 7,6 kg ven', () => {
    const p = parseBackup(JSON.stringify({
      version: 2,
      activities: [{ id: 'bad1', sport: 'kolo', date: '2026-10-15', name: 'Uvožena', durationMin: -45, avgHr: 900, avgPower: 5000, distKm: 9999, tss: 80, source: 'iz-nacrta', createdAt: NOW, updatedAt: NOW }],
      meals: [{ id: 'badm', date: '2026-10-16', slot: 'kosilo', name: 'Kosilo', kcal: 99999, createdAt: NOW }, meal('ok')],
      plan: [],
      checkins: [{ date: '2026-10-16', weightKg: 7.6 }, { date: '2026-10-15', weightKg: 7.6, mood: 4 }, { date: '2026-10-14', weightKg: 79.5 }],
      profile: { onboardingDone: true, weightKg: 7.6, ftp: 250, fieldAt: { weightKg: NOW, ftp: NOW } },
    }))
    const a = p.state.activities[0]!
    expect(a).toMatchObject({ id: 'bad1', durationMin: null, distKm: null, avgHr: null, avgPower: null, tss: 80, source: 'iz-nacrta' })
    expect(p.state.meals.map(m => m.id)).toEqual(['ok'])
    expect(p.state.checkins).toEqual([{ date: '2026-10-15', mood: 4 }, { date: '2026-10-14', weightKg: 79.5 }])
    expect(p.state.profile).not.toHaveProperty('weightKg')
    expect(p.state.profile!.fieldAt).toEqual({ ftp: NOW })
    expect(p.state.profile!.ftp).toBe(250)
    expect(p.info.skipped).toBe(8)   // 4 vrednosti vadbe + obrok + 2 tehtanji + teža v profilu
    expect(p.info.activities).toBe(1)
  })
  it('kopija brez napak nima »skipped« (predogled ostane kot prej)', () => {
    expect(parseBackup(JSON.stringify({ version: 2, meals: [meal('m')] })).info).not.toHaveProperty('skipped')
  })
})

describe('D07 polna shramba: jasno sporočilo, vnos ni izgubljen', () => {
  it('addMeal in saveCheckin ob QuotaExceededError povesta »Ni prostora« in zavrneta obet', async () => {
    const put = IDBObjectStore.prototype.put
    IDBObjectStore.prototype.put = function () { throw new DOMException('Disk full', 'QuotaExceededError') }
    try {
      await expect(store.addMeal(meal('q'))).rejects.toThrow()
      expect(lastToast()).toBe('Ni prostora na napravi — obrok ni shranjen. Sprosti prostor ali izvozi kopijo in poskusi znova.')
      expect(store.getState().toast?.kind).toBe('err')
      await expect(store.saveCheckin({ date: TODAY, mood: 4 })).rejects.toThrow()
      expect(lastToast()).toMatch(/^Ni prostora na napravi — vnos ni shranjen\./)
      expect(store.getState().checkinToday).toBeNull()
    } finally { IDBObjectStore.prototype.put = put }
    expect(store.storageFailMsg(new Error('x'), 'obrok ni shranjen')).toBe('Shramba na napravi ne dela — obrok ni shranjen. Poskusi znova ali osveži stran.')
  })
})

describe('D11 dva zavihka', () => {
  it('addTest sestavi seznam iz baze: test, ki ga je vpisal drug zavihek, ostane', async () => {
    await store.addTest(ftpTest('a', '2026-09-01', 240))
    // drug zavihek zapiše svoj test neposredno v bazo — ta zavihek ga v pomnilniku nima
    const cur = await repo.loadSettings()
    await repo.saveSettings({ ...cur, tests: [...(cur.tests || []), { id: 'p5', date: '2026-10-10', kind: 'p5', value: 300, unit: 'W' }] })
    expect(store.getState().settings.tests?.map(t => t.id)).toEqual(['a'])
    await store.addTest({ id: 'r', date: TODAY, kind: 'rhr', value: 48, unit: 'bpm' })
    expect((await repo.loadSettings()).tests!.map(t => t.id).sort()).toEqual(['a', 'p5', 'r'])
    await store.removeTest('r')
    expect((await repo.loadSettings()).tests!.map(t => t.id).sort()).toEqual(['a', 'p5'])
  })
  it('saveCheckin dopolni shranjeni vnos: teža z drugega zavihka (ali uvoda) ostane ob vpisu počutja', async () => {
    await repo.putCheckin({ date: TODAY, weightKg: 79.4 })
    await store.saveCheckin({ date: TODAY, mood: 4 })
    expect(await repo.getCheckin(TODAY)).toMatchObject({ date: TODAY, weightKg: 79.4, mood: 4 })
  })
  it('zapis drugega zavihka (BroadcastChannel) → ta zavihek prebere bazo znova; svoj zapis javi drugim', async () => {
    store.tabsListen()
    const other = new BroadcastChannel('formai')
    const heard: unknown[] = []
    other.onmessage = e => heard.push(e.data)
    try {
      await repo.putMeal(meal('iz-drugega'))
      expect(store.getState().mealsToday.map(m => m.id)).toEqual([])
      other.postMessage(1)
      await new Promise(r => setTimeout(r, 450))
      expect(store.getState().mealsToday.map(m => m.id)).toEqual(['iz-drugega'])
      await store.addMeal(meal('tu'))
      await new Promise(r => setTimeout(r, 30))
      expect(heard.length).toBeGreaterThan(0)
    } finally { other.close() }
  })
})

describe('B17 tehtanje: tipkarska napaka se ne shrani tiho', () => {
  const ci = (date: string, kg: number): DailyCheckin => ({ date, weightKg: kg })
  const week = [ci('2026-10-13', 79.6), ci('2026-10-15', 80.0), ci('2026-10-16', 79.8)]
  it('97 namesto 79: vprašanje z razliko, povprečjem in predlogom zamenjanih števk', () => {
    expect(weighJump(97, D, week)).toBe('To je 17,2 kg več kot tvoje povprečje (79,8 kg) — morda 79,0 kg? Je prav?')
    expect(weighJump(79.2, D, week)).toBeNull()
    expect(weighJump(83.5, D, week)).toBe('To je 3,7 kg več kot tvoje povprečje (79,8 kg). Je prav?')
    expect(weighJump(75, D, [ci('2026-09-01', 80)])).toBe('To je 5,0 kg manj kot zadnje tehtanje (80,0 kg). Je prav?')
    expect(weighJump(97, D, [], 79)).toMatch(/kot teža v profilu \(79,0 kg\) — morda 79,0 kg\?/)
    expect(weighJump(97, D, [])).toBeNull()
    // popravek istega dne: primerja z drugimi dnevi, ne s samim seboj
    expect(weighJump(79.5, D, [...week, ci(D, 97)])).toBeNull()
    expect(swappedDigits(68.4, 86)).toBe(86.4)
    expect(swappedDigits(77, 80)).toBeNull()
  })
})

describe('D18 izbris napačnega tehtanja in jutranjega vnosa', () => {
  it('izbris tehtanja: teža v profilu nazaj na zadnje veljavno, povprečje brez 97; »Razveljavi« vrne', async () => {
    await store.saveCheckin({ date: '2026-10-14', weightKg: 79.6 })
    await store.saveCheckin({ date: '2026-10-15', weightKg: 79.8, mood: 4 })
    await store.saveCheckin({ date: '2026-10-16', weightKg: 97 })
    expect(store.getState().profile.weightKg).toBe(85.5)   // (v3.49 CILJ, B34) pri 3 tehtanjih v 7 dneh je teža za izračun njihovo povprečje
    await store.removeWeigh('2026-10-16')
    expect(store.getState().profile.weightKg).toBe(79.8)
    expect(weightTrend(store.getState().checkins)!.avg7).toBe(79.7)
    expect(recentWeighs(store.getState().checkins).map(w => w.kg)).toEqual([79.8, 79.6])
    expect(await repo.getCheckin('2026-10-16')).toMatchObject({ weightKg: null })
    expect(await repo.getCheckin('2026-10-15')).toMatchObject({ weightKg: 79.8, mood: 4 })
  })
  it('izbris tehtanja (null) velja tudi na drugi napravi; grob jutranjega vnosa ga pobriše na obeh straneh', () => {
    const older: DailyCheckin = { date: '2026-10-10', weightKg: 95.2, mood: 3, updatedAt: '2026-10-10T07:00:00.000Z' }
    const del: DailyCheckin = { date: '2026-10-10', weightKg: null, mood: 3, updatedAt: '2026-10-11T07:00:00.000Z' }
    expect(mergeCheckins([older], [del])[0]!.weightKg).toBeNull()
    expect(mergeCheckins([del], [older])[0]!.weightKg).toBeNull()
    const t = Date.parse('2026-10-12T07:00:00.000Z')
    expect(mergeCheckins([older], [], { [tombCheckin('2026-10-10')]: t })).toEqual([])
    // vnos, vpisan po izbrisu, ostane
    const fresh: DailyCheckin = { date: '2026-10-10', mood: 5, updatedAt: '2026-10-12T08:00:00.000Z' }
    expect(mergeCheckins([older], [fresh], { [tombCheckin('2026-10-10')]: t })).toEqual([fresh])
    const st = (c: DailyCheckin[], tomb = {}): SyncState => ({ profile: null, settings: null, activities: [], plan: [], meals: [], checkins: c, tomb })
    expect(mergeState(st([older]), st([], { [tombCheckin('2026-10-10')]: t }), t + 1000).checkins).toEqual([])
  })
  it('izbris jutranjega vnosa: brez tehtanja gre cel vnos z grobom; s tehtanjem ostane teža', async () => {
    await store.saveCheckin({ date: TODAY, mood: 2, soreness: 4, sleepH: 6 })
    await store.removeCheckin(TODAY)
    expect(await repo.getCheckin(TODAY)).toBeUndefined()
    expect(store.getState().checkinToday).toBeNull()
    expect((await repo.getTomb())[tombCheckin(TODAY)]).toBeGreaterThan(0)
    // nov vnos istega dne po izbrisu ostane (tudi po združitvi z grobom)
    await new Promise(r => setTimeout(r, 5))
    await store.saveCheckin({ date: TODAY, mood: 4 })
    const tomb = await repo.getTomb()
    expect(mergeCheckins(store.getState().checkins, [], tomb).map(c => c.mood)).toEqual([4])

    await store.saveCheckin({ date: '2026-10-16', mood: 3, soreness: 2, sleepH: 7, weightKg: 79.8 })
    await store.removeCheckin('2026-10-16')
    expect(await repo.getCheckin('2026-10-16')).toMatchObject({ weightKg: 79.8, mood: null, soreness: null, sleepH: null })
  })
})

describe('D19 seznam vseh vadb: iskanje', () => {
  const act = (id: string, date: string, name: string, o: Partial<Activity> = {}): Activity => ({ id, source: 'manual', sport: 'kolo', date, name, aiEligible: true, geoRetain: false, createdAt: NOW, updatedAt: NOW, ...o })
  const list = [act('1', '2025-05-12', 'Krvavec'), act('2', '2025-05-30', 'Kladje čez Vršič'), act('3', '2026-05-03', 'Jutranji tek', { sport: 'tek' }), act('4', '2025-06-01', 'Rogla', { notes: 'nova kolesa' })]
  it('»maj 2025« vrne samo vadbe iz maja 2025; brez šumnikov najde po imenu; opomba in šport', () => {
    expect(filterActs(list, 'maj 2025').map(a => a.id)).toEqual(['1', '2'])
    expect(filterActs(list, 'vrsic').map(a => a.id)).toEqual(['2'])
    expect(filterActs(list, 'KLADJE').map(a => a.id)).toEqual(['2'])
    expect(filterActs(list, 'kolesa').map(a => a.id)).toEqual(['4'])
    expect(filterActs(list, 'tek maja').map(a => a.id)).toEqual(['3'])
    expect(filterActs(list, '12.5.').map(a => a.id)).toEqual(['1'])
    expect(filterActs(list, '  ').length).toBe(4)
  })
})

describe('D20 »Izbriši na napravi« pri prijavljenem', () => {
  it('najprej odjava (podatki še na napravi), nato izbris; oblak se ne briše', async () => {
    FB.user = { uid: 'u1', email: 'a@b.si', name: 'A' }
    await store.signIn()
    expect(store.getState().user?.uid).toBe('u1')
    await store.addMeal(meal('m1'))
    let mealsAtSignOut = -1
    FB.onSignOut = async () => { mealsAtSignOut = (await repo.allMeals()).length }
    expect(await store.wipeThisDevice()).toBe(true)
    expect(mealsAtSignOut).toBe(1)
    expect(await repo.allMeals()).toEqual([])
    expect(store.getState().user).toBeNull()
  })
  it('odjava ne uspe → nič se ne izbriše', async () => {
    FB.user = { uid: 'u1', email: 'a@b.si', name: 'A' }
    await store.signIn()
    await store.addMeal(meal('m1'))
    FB.onSignOut = async () => { throw new Error('offline') }
    expect(await store.wipeThisDevice()).toBe(false)
    expect((await repo.allMeals()).length).toBe(1)
    expect(lastToast()).toBe('Odjava ni uspela — podatkov na napravi nisem izbrisal. Poskusi znova.')
    FB.onSignOut = null
    await store.signOut()
  })
})

// zadnji: zagon z blokirano shrambo (boot teče enkrat na modul)
describe('D08 brskalnik blokira shrambo', () => {
  it('boot ne obvisi: ready in razlaga namesto logotipa', async () => {
    resetDbForTests()
    const open = indexedDB.open
    indexedDB.open = () => { throw new DOMException('The operation is insecure.', 'SecurityError') }
    try {
      await store.boot()
      expect(store.getState().ready).toBe(true)
      expect(store.getState().storageError).toBe('Brskalnik ne dovoli shranjevanja (zasebni način ali blokirani piškotki). FORMAI hrani podatke na napravi — dovoli shranjevanje za formai.si ali odpri v navadnem oknu.')
    } finally { indexedDB.open = open; resetDbForTests() }
    expect(store.storageBlockedMsg(new DOMException('x', 'QuotaExceededError'))).toMatch(/^Na napravi ni prostora/)
  })
})
