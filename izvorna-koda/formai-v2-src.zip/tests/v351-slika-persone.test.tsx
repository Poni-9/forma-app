// v3.51 SLIKA-PERSONE — zasloni: list »Trening s slike« (tekma, »Začni zdaj«, trajanje, pavza, slika sebe, privolitev),
// premor (brez kolesa, enodnevni), kartica dogovora in pretekli teden v premoru.
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), granted: 0, added: [] as unknown[] }))
const h = vi.hoisted(() => ({ json: {} as unknown }))
vi.mock('@/state/store', () => ({
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state, toast: () => undefined, signIn: async () => null, warmAuth: () => undefined,
  grantAiConsent: async () => { S.granted++ }, setWeekPause: async () => undefined, endWeekPause: async () => undefined, saveRaces: async () => undefined,
  setOffDays: async () => undefined, setSick: async () => undefined, endSick: async () => undefined, extendSick: async () => undefined,
}))
vi.mock('@/state/photoTraining', () => ({
  saveDoneShot: async () => ({ added: true, day: null }),
  addPhotoWorkout: async (d: { id: string }) => { S.added.push(d); return { day: d, replaced: null, undo: async () => undefined } },
  addSelfSessions: async () => undefined,
}))
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => ({ name: 'danes', params: {} }) }))
vi.mock('@/ui/useAi', () => ({ useAi: () => ({ busy: false, signedIn: true, consent: true, run: async (fn: () => Promise<unknown>) => fn(), sheet: null }) }))
vi.mock('@/domain/ai/client', () => {
  class AiError extends Error { kind: string; constructor(kind: string, m: string) { super(m); this.kind = kind } }
  return { AiError, askText: async () => '', askJson: async () => JSON.parse(JSON.stringify(h.json)) }
})
vi.mock('@/domain/ai/image', () => ({ fileToBase64Resized: async () => ({ data: 'AAAA', mime: 'image/jpeg', thumb: '' }), exifStamp: async () => null }))

import { PhotoTrainingSheet } from '@/ui/PhotoTrainingSheet'
import { WeekPauseSheet, WeekPauseCard } from '@/ui/WeekPauseSheet'
import { DealCard } from '@/ui/DealCard'
import { SELF_PHOTO_CONSENT_V } from '@/domain/ai/consent'
import type { PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-23'   // petek
const NOW = `${TODAY}T08:00:00.000Z`
const P = { sex: 'm', age: 30, heightCm: 182, weightKg: 78, ftp: 240, lthr: 184, maxHr: 195, restHr: 48, aiConsentAt: NOW, aiConsentV: 3, gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, strength: { on: false, equipment: 'none' }, onboardingDone: true } as unknown as Profile
const day = (o: Partial<PlanDay> & Pick<PlanDay, 'id' | 'date' | 'kind'>): PlanDay => ({ title: 'Z2 vzdržljivost', desc: '', durationMin: 60, source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })
const RACE = day({ id: 'r', date: TODAY, kind: 'kolo', title: 'Kronometer Vodice — 18 km', durationMin: 30, role: 'dirka', raceId: 'kv' })
const set = (o: Record<string, unknown> = {}) => { S.state = { today: TODAY, plan: [RACE], activities: [], profile: P, user: { uid: 'u' }, authKnown: true, settings: {}, toasts: [], ...o }; S.subs.forEach(f => f()) }
let div: HTMLDivElement | null = null, root: Root | null = null
async function render(el: ReactElement) { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div); await act(async () => { root!.render(el) }); await act(async () => { await new Promise(r => setTimeout(r, 0)) }); return document.body }
const sp = (x: string | null | undefined) => (x || '').replace(/[\u00a0\u202f\u2060]/g, ' ')
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(sp(b.textContent))) as HTMLButtonElement | undefined
const file = () => new File(['x'], 'p.jpg', { type: 'image/jpeg' })
const tick = () => act(async () => { await new Promise(r => setTimeout(r, 0)) })

beforeEach(() => { vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date(2026, 9, 23, 9, 0)); S.added.length = 0; S.granted = 0; set() })
afterEach(() => { act(() => root?.unmount()); div?.remove(); div = null; root = null; document.body.innerHTML = ''; vi.useRealTimers() })

describe('H01/A03/F16: posnetek Zwifta s kartice tekme', () => {
  it('tekma ni izbrana sama; namig pove, da jo izbereš; ob izbiri opozorilo', async () => {
    h.json = { app: 'zwift', sport: 'kolo', datum: TODAY, trajanje_min: 62, razdalja_km: 31.4, ime: 'Zwift — Watopia', zanesljivost: 'visoka' }
    const b = await render(<PhotoTrainingSheet req={{ mode: 'done', dayId: 'r', file: file() }} />)
    expect((b.querySelector('#ph-day') as HTMLSelectElement).value).toBe('')
    expect(sp(b.textContent)).toContain('Shranim jo kot dodatno. Če je bila to tekma »Kronometer Vodice — 18 km«, jo izberi zgoraj.')
    expect(btn(/^Shrani$/)).toBeTruthy()
    await act(async () => { const s = b.querySelector('#ph-day') as HTMLSelectElement; s.value = 'r'; s.dispatchEvent(new Event('change', { bubbles: true })) })
    expect(sp(b.textContent)).toContain('To je tekma — izberi jo samo, če je bila to res tvoja tekma.')
  })
  it('H02: razdalja, ki ne gre s časom, se ne shrani (trajanje vpisano šele v predogledu)', async () => {
    h.json = { app: 'garmin', sport: 'tek', datum: TODAY, trajanje_min: 0, razdalja_km: 300, zanesljivost: 'nizka' }
    set({ plan: [] })
    const b = await render(<PhotoTrainingSheet req={{ mode: 'done', file: file() }} />)
    const min = b.querySelector('#ph-min') as HTMLInputElement
    await act(async () => { const d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!; d.set!.call(min, '45'); min.dispatchEvent(new Event('input', { bubbles: true })) })
    await act(async () => { btn(/^Shrani$/)!.click() })
    expect(sp(b.querySelector('#ph-err')?.textContent)).toMatch(/Razdalja ne gre s tem časom \(400 km\/h\)/)
  })
})

describe('H06/H15/H37: trening s slike v načrt', () => {
  it('»Začni zdaj« samo za danes; na dan tekme vpraša', async () => {
    h.json = { vrsta: 'moc', naslov: 'WOD četrtek', vaje: [{ ime: 'Počep s palico', serije: 5, ponovitve: 5, kg: 80, pavza_s: 120 }] }
    const b = await render(<PhotoTrainingSheet req={{ mode: 'plan', date: TODAY, file: file() }} />)
    // H37: pavza s table je vidna
    expect(sp(b.textContent)).toContain('pavza 2 min')
    await act(async () => { const s = b.querySelector('#pt-day') as HTMLSelectElement; s.value = '2026-10-24'; s.dispatchEvent(new Event('change', { bubbles: true })) })
    expect(btn(/^Začni zdaj$/)).toBeUndefined()
    await act(async () => { const s = b.querySelector('#pt-day') as HTMLSelectElement; s.value = TODAY; s.dispatchEvent(new Event('change', { bubbles: true })) })
    await act(async () => { btn(/^Začni zdaj$/)!.click() })
    await tick()
    expect(sp(b.textContent)).toContain('Danes imaš tekmo »Kronometer Vodice — 18 km«. Res dodam še ta trening?')
    expect(S.added.length).toBe(0)
    await act(async () => { btn(/^Prekliči$/)!.click() })
    await tick()
    expect(S.added.length).toBe(0)
  })
  it('trajanje v polju krajše od korakov: namig in »uporabi«', async () => {
    h.json = { vrsta: 'tek', naslov: 'Intervali na stezi', minut: 50, koraki: [{ tip: 'ogrevanje', min: 15 }, { tip: 'ponovitve', ponovitve: 6, delo_s: 400, odmor_s: 180, intenzivnost: 'Z4' }, { tip: 'iztek', min: 10 }] }
    set({ plan: [] })
    const b = await render(<PhotoTrainingSheet req={{ mode: 'plan', date: TODAY, file: file() }} />)
    const hint = sp(b.textContent).match(/Koraki trajajo (\d+) min — v načrt gre \d+ min\./)
    expect(hint).toBeTruthy()
    await act(async () => { btn(/^uporabi \d+$/)!.click() })
    expect((b.querySelector('#pt-min') as HTMLInputElement).value).toBe(hint![1])
  })
})

describe('H17: predlog s slike sebe — gumb pove, koliko sej res gre v načrt', () => {
  it('3× predlagano, prosta 2 dneva → »2×« in razlog', async () => {
    h.json = { poudarki: ['Ramena so rahlo naprej — okrepi zgornji hrbet in zadnje rame.'], podrocje: 'drza', predlog: { naslov: 'Hrbet', krat_na_teden: 3, minut: 20, vaje: [{ ime: 'Superman' }, { ime: 'Deska' }] } }
    // 7 dni: trdi dnevi vsak drugi dan, prosta sta samo sobota in torek
    const hard = ['2026-10-23', '2026-10-25', '2026-10-26', '2026-10-28', '2026-10-29'].map((d, i) => day({ id: `h${i}`, date: d, kind: 'kolo', role: 'kljucna' }))
    set({ plan: hard })
    const b = await render(<PhotoTrainingSheet req={{ mode: 'self', file: file() }} />)
    const input = b.querySelector('input[type=file]') as HTMLInputElement
    await act(async () => { Object.defineProperty(input, 'files', { value: [file()], configurable: true }); input.dispatchEvent(new Event('change', { bubbles: true })) })
    await tick()
    expect(btn(/^Dodaj v načrt \(2×, po želji\)$/)).toBeTruthy()
    expect(sp(b.textContent)).toContain('V naslednjih 7 dneh sta prosta samo 2 dneva brez trdega treninga — dodam 2 seji.')
  })
})

describe('F14/H19: ponovna privolitev za sliko sebe pove, zakaj', () => {
  it('privolitev v2 + slika sebe → list z »Novo: slike sebe …«', async () => {
    const { useAi: realUseAi } = await vi.importActual<typeof import('@/ui/useAi')>('@/ui/useAi')
    set({ profile: { ...P, aiConsentV: 2 } })
    function Harness() {
      const ai = realUseAi()
      return <>{ai.sheet}<button type="button" onClick={() => void ai.run(async () => 1, { consentV: SELF_PHOTO_CONSENT_V })}>beri</button></>
    }
    const b = await render(<Harness />)
    await act(async () => { btn(/^beri$/)!.click() })
    await tick()
    expect(sp(b.textContent)).toContain('Novo: slike sebe za predlog vaj gredo v AI samo za branje in se ne shranijo — zato te vprašam znova.')
    expect(sp(b.textContent)).not.toContain('Claude (Anthropic) — zato te vprašam znova')
  })
  it('privolitev v1 + Claude → besedilo o Claudu ostane', async () => {
    const { useAi: realUseAi } = await vi.importActual<typeof import('@/ui/useAi')>('@/ui/useAi')
    set({ profile: { ...P, aiConsentV: 1 } })
    function Harness() {
      const ai = realUseAi()
      return <>{ai.sheet}<button type="button" onClick={() => void ai.run(async () => 1, { consentV: 2 })}>beri</button></>
    }
    const b = await render(<Harness />)
    await act(async () => { btn(/^beri$/)!.click() })
    await tick()
    expect(sp(b.textContent)).toContain('tvoj načrt bo sestavil Claude (Anthropic) — zato te vprašam znova.')
  })
})

describe('H08/H09/H42: premor »Ta teden …«', () => {
  it('brez kolesa (noBike, načrt brez voženj): ni izbire »Brez kolesa«', async () => {
    set({ plan: [day({ id: 'm', date: '2026-10-24', kind: 'moc', title: 'Moč' })], profile: { ...P, gear: { ...P.gear, noBike: true, bikeOutdoor: false, trainer: false } } })
    const b = await render(<WeekPauseSheet open onClose={() => undefined} />)
    expect(btn(/^Brez treningov/)).toBeTruthy()
    expect(btn(/^Brez kolesa/)).toBeUndefined()
    expect(b).toBeTruthy()
  })
  it('samo vožnje: »Brez kolesa« ne obljublja »moč, tek in hoja ostanejo«', async () => {
    set({ plan: [day({ id: 'a', date: TODAY, kind: 'kolo' }), day({ id: 'b', date: '2026-10-25', kind: 'kolo' })] })
    await render(<WeekPauseSheet open onClose={() => undefined} />)
    const t = sp(btn(/^Brez kolesa/)!.textContent)
    expect(t).toContain('V načrtu so do takrat samo vožnje, zato odpade vse')
    expect(t).not.toContain('Moč, tek in hoja ostanejo')
  })
  it('premor, ki se konča danes: »danes umaknjene«, brez »moč, tek in hoja ostanejo«, ko jih ni', async () => {
    set({ plan: [day({ id: 'p', date: TODAY, kind: 'pocitek', title: 'Premor' })], profile: { ...P, weekPause: { from: TODAY, to: TODAY, mode: 'kolo', at: NOW } } })
    const b = await render(<WeekPauseCard />)
    expect(sp(b.textContent)).toContain('Vožnje so danes umaknjene, tudi z ure.')
    expect(sp(b.textContent)).not.toContain('Moč, tek in hoja ostanejo')
  })
})

describe('H41: kartica dogovora v premoru', () => {
  it('ne »najtežji v bloku«, ampak premor', async () => {
    const focus = { title: 'Kolo za zdravje', sports: ['kolo'], aims: ['zdravje'], level: 2, sessions: [{ type: 'kolo', cardio: 'lahko', min: 60 }], muscles: [], notes: [], why: [], offDays: [], wish: '', by: 'pravila', at: NOW }
    // 3. teden bloka: začetek pred dvema tednoma
    const prof = { ...P, focus, cycleStart: '2026-10-05', weekPause: { from: '2026-10-19', to: '2026-10-25', mode: 'vse', at: NOW } }
    set({ profile: prof, plan: [] })
    const b = await render(<DealCard />)
    expect(sp(b.textContent)).not.toContain('najtežji v bloku')
    expect(sp(b.textContent)).toMatch(/Teden \d+ · premor do nedelje/)
  })
})

describe('H12: pretekli teden v 2. tednu premora', () => {
  it('»Ta teden: premor do nedelje, 15. 11.« namesto »lažji teden, ~3 h«', async () => {
    vi.setSystemTime(new Date(2026, 10, 9, 9, 0))
    const focus = { title: 'Kolo za zdravje', sports: ['kolo'], aims: ['zdravje'], level: 2, sessions: [{ type: 'kolo', cardio: 'lahko', min: 60 }, { type: 'kolo', cardio: 'lahko', min: 60 }], muscles: [], notes: [], why: [], offDays: [], wish: '', by: 'pravila', at: NOW }
    const prof = { ...P, focus, cycleStart: '2026-10-19', weekPause: { from: '2026-11-04', to: '2026-11-15', mode: 'kolo', at: NOW } }
    set({ today: '2026-11-09', profile: prof, plan: [day({ id: 'l', date: '2026-11-03', kind: 'kolo' }), day({ id: 'q', date: '2026-11-05', kind: 'pocitek', title: 'Premor' })] })
    const { LastWeekCard } = await import('@/ui/LastWeekCard')
    const b = await render(<LastWeekCard />)
    expect(sp(b.textContent)).toContain('Ta teden: premor do nedelje, 15. 11.')
    expect(sp(b.textContent)).not.toMatch(/Ta teden: [^.]*~\d/)
  })
})

describe('H29: Danes »Trener pravi« brez podvojenega trajanja', () => {
  it('»Jutri: Kolo — lahko, 1 h 05 min.« (prej »… 1 h 05 min, 1 h 05 min.«)', async () => {
    const { coachLine } = await import('@/screens/Danes')
    const t = sp(coachLine(0, { kind: 'pocitek' }, 1, 1, 80, { few: true, tomorrow: { kind: 'kolo', title: 'Kolo — lahko 1 h 05 min', durationMin: 65 } }))
    expect(t).toContain('Jutri: Kolo — lahko, 1 h 05 min.')
    expect(t).not.toMatch(/1 h 05 min, 1 h 05 min/)
  })
})
