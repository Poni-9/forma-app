import { describe, it, expect } from 'vitest'
import { readFileSync, statSync } from 'node:fs'
import { resolve } from 'node:path'

// Pisava Manrope z lastnega strežnika: brez Google Fonts, latin + latin-ext (č, š, ž), vnaprej naložena, nadomestna z merami.
const at = (...p: string[]) => resolve(process.cwd(), ...p)
const html = readFileSync(at('index.html'), 'utf8')
const faces = [...html.matchAll(/@font-face\s*\{([^}]*)\}/g)].map(m => m[1]!)
const inRange = (cp: number, range: string) => range.split(',').map(s => s.trim().replace(/^U\+/, '')).some(r => {
  const [a, b] = r.split('-').map(x => parseInt(x, 16)) as [number, number | undefined]
  return b === undefined ? cp === a : cp >= a && cp <= b
})

describe('pisava', () => {
  it('ni več Google Fonts', () => {
    expect(html).not.toMatch(/fonts\.(googleapis|gstatic)\.com/)
  })
  it('Manrope: spremenljiva 200–800, swap, obe datoteki obstajata', () => {
    const m = faces.filter(f => /font-family:\s*'Manrope';/.test(f))
    expect(m).toHaveLength(2)
    for (const f of m) {
      expect(f).toMatch(/font-weight:\s*200 800/)
      expect(f).toMatch(/font-display:\s*swap/)
      const file = f.match(/url\((\/fonts\/[^)]+)\)/)![1]!
      expect(statSync(at('public' + file)).size).toBeGreaterThan(10_000)
    }
  })
  it('č, š, ž in Č, Š, Ž pokrije latin-ext, osnovne črke latin', () => {
    const ext = faces.find(f => /Manrope-latin-ext/.test(f))!.match(/unicode-range:\s*([^;]+)/)![1]!
    const lat = faces.find(f => /Manrope-latin\.woff2/.test(f))!.match(/unicode-range:\s*([^;]+)/)![1]!
    for (const ch of 'čšžČŠŽćđ') expect(inRange(ch.codePointAt(0)!, ext), ch).toBe(true)
    for (const ch of 'aZ0 −') expect(inRange(ch.codePointAt(0)!, lat), ch).toBe(true)
  })
  it('obe datoteki sta vnaprej naloženi (crossorigin), nadomestna pisava ima popravljene mere', () => {
    expect(html).toMatch(/<link rel="preload" href="\/fonts\/Manrope-latin\.woff2" as="font" type="font\/woff2" crossorigin/)
    expect(html).toMatch(/<link rel="preload" href="\/fonts\/Manrope-latin-ext\.woff2" as="font" type="font\/woff2" crossorigin/)
    expect(faces.filter(f => /Manrope Fallback/.test(f) && /size-adjust/.test(f) && /ascent-override/.test(f)).length).toBeGreaterThanOrEqual(2)
    expect(readFileSync(at('src/styles/tokens.css'), 'utf8')).toMatch(/--font:\s*'Manrope', 'Manrope Fallback'/)
  })
})
