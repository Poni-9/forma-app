// v3.50 TRENER (zaslon): brez prijave brez dvojnikov (C14), hitra vprašanja tudi po prvem sporočilu (C32), »Prilagodi
// naslednji teden« v nedeljo (C30), dogovor samo z močjo brez klica AI (C11), lestvica za pas (C29), hitri gumbi
// mladoletnega doma brez opreme (C13, H23), pripis mladoletnemu (C28).
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>() }))
const h = vi.hoisted(() => ({ run: vi.fn(async (fn: () => Promise<unknown>, _o?: unknown) => fn()), toast: vi.fn() }))
vi.mock('@/state/store', () => ({
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  savePlanDays: vi.fn(), savePlanDay: vi.fn(), toast: h.toast, newCoachChat: vi.fn(), restorePlanDays: vi.fn(),
  updateSettings: vi.fn(async (x: Record<string, unknown>) => { S.state = { ...S.state, settings: { ...S.state.settings, ...x } }; S.subs.forEach(f => f()) }),
  setWeekPause: vi.fn(), endWeekPause: vi.fn(),
}))
vi.mock('@/app/router', () => ({ navigate: vi.fn(), useRoute: () => ({ name: 'trener', params: {} }) }))
vi.mock('@/app/Shell', () => ({ Head: () => null }))
vi.mock('@/ui/useAi', () => ({ useAi: () => ({ busy: false, signedIn: !!S.state.user, consent: true, run: h.run, sheet: null }) }))
vi.mock('@/state/snap', () => ({ snapOf: () => ({}) }))
vi.mock('@/data/db', () => ({ getKV: async () => undefined, setKV: async () => {} }))
vi.mock('@/ui/useDictation', () => ({ useDictation: () => ({ listening: false, canSpeak: false, toggle: () => {}, stop: () => {}, transcribing: false, level: 0 }) }))
vi.mock('@/ui/ListenBar', () => ({ ListenBar: () => null }))
vi.mock('@/ui/Confirm', () => ({ undoToast: vi.fn(), useHidden: () => new Set() }))

import { Trener } from '@/screens/Trener'
import { normalizeFocus } from '@/domain/focus/model'
import { todayIso } from '@/domain/training/load'
import { HONEST_NOTE_MINOR } from '@/domain/ai/sanitize'
import type { AgreedSession, Focus, PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

const NOW = '2026-10-18T08:00:00.000Z'
const base = { sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, strength: { on: false, equipment: 'none' }, onboardingDone: true, createdAt: NOW, updatedAt: NOW } as unknown as Profile
const focus = (sessions: AgreedSession[], o: Partial<Focus> = {}): Focus => normalizeFocus({ wish: 'po meri', sports: [...new Set(sessions.map(s => s.type))], aims: ['kondicija'], level: 1, equipment: ['fitnes'], sessions, ...o }, { now: NOW, by: 'pravila' })!
const day = (o: Partial<PlanDay>): PlanDay => ({ id: 'd' + o.date + (o.kind || ''), date: '2026-10-18', kind: 'kolo', title: 'Z2', desc: 'Enakomerno.', durationMin: 60, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o } as PlanDay)
type M = { role: 'user' | 'ai'; text: string; at: string; kind?: string; local?: boolean }
const reset = (o: { p?: Partial<Profile>; msgs?: M[]; plan?: PlanDay[]; today?: string; user?: boolean } = {}) => {
  S.state = { ready: true, today: o.today ?? '2026-10-18', plan: o.plan ?? [], activities: [], checkins: [], checkinToday: null, mealsToday: [], recentMeals: [], weather: null, wellness: [], settings: { coach: { msgs: o.msgs ?? [], summary: null } }, user: o.user === false ? null : { uid: 'u' }, authKnown: true, firstSync: true, profile: { ...base, ...o.p } }
  S.subs.forEach(f => f())
}

let div: HTMLDivElement, root: Root | null = null
async function mount() { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div); await act(async () => { root!.render(<Trener />) }) }
const flush = async () => { for (let i = 0; i < 6; i++) await act(async () => { await Promise.resolve() }) }
const btns = () => [...document.querySelectorAll('button')]
const btn = (re: RegExp) => btns().find(b => re.test(b.textContent || '')) as HTMLButtonElement | undefined

beforeEach(() => { h.run.mockClear(); h.toast.mockClear(); window.scrollTo = vi.fn() as never })
afterEach(async () => { if (root) { await act(async () => root!.unmount()); root = null; div.remove() } document.body.innerHTML = '' })

describe('C14 brez prijave brez dvojnikov', () => {
  it('dva tapa »Kaj naj danes naredim?« → en par, osvežen, z obvestilom', async () => {
    reset({ user: false, today: todayIso() })
    await mount()
    await act(async () => { btn(/^Kaj naj danes naredim\?$/)!.click() }); await flush()
    expect(S.state.settings.coach.msgs).toHaveLength(2)
    await act(async () => { btn(/^Kaj naj danes naredim\?$/)!.click() }); await flush()
    expect(S.state.settings.coach.msgs).toHaveLength(2)
    expect(h.toast).toHaveBeenCalledWith('Nasvet za danes je že v pogovoru — osvežen.', 'info')
    await act(async () => { btn(/^Pregled tedna$/)!.click() }); await flush()
    expect(S.state.settings.coach.msgs).toHaveLength(4)                 // drug odgovor se doda
    expect(h.run).not.toHaveBeenCalled()
  })
})

describe('C32 hitra vprašanja po prvem sporočilu', () => {
  it('pod zadnjim odgovorom do tri, ki jih še ni vprašal', async () => {
    reset({ msgs: [{ role: 'user', text: 'Koliko OH na dolgi vožnji v soboto?', at: NOW }, { role: 'ai', text: '60 g na uro.', at: NOW }] })
    await mount()
    const chips = [...document.querySelectorAll('.chat-more button')].map(b => b.textContent)
    expect(chips.length).toBeGreaterThanOrEqual(2)
    expect(chips.length).toBeLessThanOrEqual(3)
    expect(chips).not.toContain('Koliko OH na dolgi vožnji?')
  })
})

describe('C30 Prilagodi naslednji teden', () => {
  it('v nedeljo s sestavljenim naslednjim tednom; sredi tedna »Prilagodi teden«', async () => {
    const plan = [day({ date: '2026-10-18', kind: 'pocitek', title: 'Počitek', durationMin: 0 }), day({ date: '2026-10-20', title: 'VO2max' })]
    reset({ plan })
    await mount()
    expect(btn(/^Prilagodi naslednji teden$/)).toBeDefined()
    await act(async () => root!.unmount()); root = null; div.remove()
    reset({ plan: [day({ date: '2026-10-14' }), day({ date: '2026-10-16' }), day({ date: '2026-10-20' })], today: '2026-10-14' })
    await mount()
    expect(btn(/^Prilagodi teden$/)).toBeDefined()
    expect(btn(/naslednji/)).toBeUndefined()
  })
})

describe('C11 dogovor samo z močjo', () => {
  it('»Prilagodi teden« ne kliče AI — pove, da moč ostane po dogovoru', async () => {
    const f = focus([{ type: 'fitnes', part: 'zgornji', min: 60 }, { type: 'fitnes', part: 'spodnji', min: 60 }], { aims: ['moc'], level: 2 })
    reset({ p: { focus: f }, plan: [day({ date: '2026-10-14', kind: 'moc', title: 'Fitnes — zgornji del', zone: null }), day({ date: '2026-10-16', kind: 'moc', title: 'Fitnes — spodnji del', zone: null })], today: '2026-10-14' })
    await mount()
    await act(async () => { btn(/^Prilagodi teden$/)!.click() }); await flush()
    expect(h.run).not.toHaveBeenCalled()
    expect(h.toast.mock.calls[0]![0]).toMatch(/^Tvoj teden je moč po dogovoru in počitek — vadbe moči ostanejo/)
  })
})

describe('C29 lestvica za pas', () => {
  it('uporabnica pri ~34 %: cilj ~21–25 % in opomba o trebušnih mišicah', async () => {
    reset({ p: { sex: 'z', age: 34, heightCm: 165, weightKg: 72 }, msgs: [{ role: 'user', text: 'Kako izgubim maščobo okoli pasu?', at: NOW }, { role: 'ai', text: 'Primanjkljaj in moč.', at: NOW }] })
    await mount()
    const t = document.querySelector('.bf-card')!.textContent || ''
    expect(t).toContain('cilj ~21–25 %')
    expect(t).toContain('obrisi trebušnih mišic se pokažejo šele pri ~18–21 %')
  })
})

describe('C13 + H23 + C28 mladoletni doma brez opreme', () => {
  it('hitra vprašanja brez kilogramov, maščobe in teže', async () => {
    const f = focus([{ type: 'doma', part: 'celo', min: 30 }, { type: 'tek', cardio: 'lahko', min: 30 }], { equipment: ['nic'] })
    reset({ p: { age: 16, focus: f } })
    await mount()
    const chips = [...document.querySelectorAll('.chat-empty button')].map(b => b.textContent || '')
    expect(chips.length).toBeGreaterThan(2)
    expect(chips.join(' | ')).not.toMatch(/kg|maščob|teža/i)
  })
  it('pripis k odgovoru o videzu brez tempa teže', async () => {
    reset({ p: { age: 16 }, msgs: [{ role: 'user', text: 'Kdaj bom imel six pack?', at: NOW }, { role: 'ai', text: 'Zagotovim ti six-pack do poletja. Jej dovolj.', at: NOW }] })
    await mount()
    const t = document.querySelector('.msg.ai')!.textContent || ''
    expect(t).toContain(HONEST_NOTE_MINOR)
    expect(t).not.toMatch(/kg na teden/)
  })
})
