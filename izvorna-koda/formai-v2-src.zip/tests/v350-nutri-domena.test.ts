// v3.50 NUTRI-DOMENA — prehrana dneva brez zaslonov: razpored obrokov po dejanski seji (tudi tek, hribi, moč), gorivo iz
// ene tabele (Gorivo, opis seje, »Med«, trener), komplet za na kolo (strop, samo voda, brez gela, ki ga nimaš, dolivanje),
// primeri obrokov ne čez obrok, beljakovine skrčenih obrokov, ocena brez AI (kuhano/suho, nova živila, litri, kava),
// »prehitro« z enim pragom, dan dirke, zdrava ciljna teža. Varovalke ostanejo.
import { describe, it, expect } from 'vitest'
import {
  dailyTarget, fueling, targetParts, noDeficitDay, goalDeficit, weightTrend, MAX_DEFICIT, MIN_ABS_M, MIN_ABS_Z,
} from '../src/domain/nutrition/energy'
import {
  rideFuel, fuelEntry, dayMealPlan, adjustToEaten, gotBySlot, scaled, exampleFor, mealScheduleOf, restWindowsOf, qtyText,
  F, F_ALCOHOL, TPL, TPL_LF, FUEL_ITEMS, EXAMPLE_OVER_MAX,
} from '../src/domain/nutrition/dayplan'
import { fuelGph } from '../src/domain/nutrition/fuelrate'
import { dayMealsOf, nextSlotOf } from '../src/domain/nutrition/daymeals'
import { estimateMeal } from '../src/domain/nutrition/localMeal'
import { raceWeight, shownTargetWeight, targetWeightOf } from '../src/domain/nutrition/body'
import { milestones } from '../src/domain/training/goal'
import { alerts } from '../src/domain/alerts'
import { buildWeek, FRANJA_2027 } from '../src/domain/training/planner'
import type { Activity, MealEntry, PlanDay, Profile } from '../src/domain/types'

const NOW = '2026-10-17T08:00:00.000Z'
const DAY = '2026-10-21'   // sreda, osnovna faza — datum vedno izrecno
const P = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, ftpDate: '2026-09-20', maxHr: 200, restHr: 55,
  gear: { bikeOutdoor: true, trainer: false, noBike: false }, hoursPerWeek: 12, strength: { on: false, equipment: 'none' },
  goal: 'dirka', deficit: 400, neat: 1.4, proteinGkg: 1.8, event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', trainTime: 'popoldne',
  onboardingDone: true, createdAt: NOW, updatedAt: NOW, races: [], ...o,
} as Profile)
const day = (o: Partial<PlanDay>): PlanDay => ({ id: o.id || 'd1', date: DAY, kind: 'kolo', title: 'Dolga Z2', desc: '', durationMin: 180, zone: 'Z2', role: 'dolga', source: 'rules', createdAt: NOW, updatedAt: NOW, ...o } as PlanDay)
const meal = (slot: MealEntry['slot'], kcal: number, time: string, o: Partial<MealEntry> = {}): MealEntry => ({ id: `${slot}${time}`, date: DAY, slot, time, name: slot, kcal, source: 'manual', createdAt: NOW, ...o })
const ride = (durationMin: number, o: Record<string, unknown> = {}) => ({ kind: 'kolo' as const, durationMin, zone: 'Z2', role: 'dolga' as const, title: 'Dolga Z2', ...o })
const dmIn = (p: Profile, plan: PlanDay[], activities: Activity[] = [], meals: MealEntry[] = [], hour = 13) => {
  const target = dailyTarget(p, activities, plan, DAY, { today: DAY, hour })!
  return { p, target, plan, activities, meals, recentMeals: [], weather: null, day: DAY, today: DAY }
}

describe('D05 — »treniram zvečer«: načrtovana seja šteje do 23h', () => {
  const plan = [day({})]
  it('ob 21h pri »zvečer« še šteje, ob 23h ne; pri »popoldne« ob 21h ne', () => {
    const ev = dailyTarget(P({ trainTime: 'zvecer' }), [], plan, DAY, { today: DAY, hour: 21 })!
    expect(ev.plannedBurn).toBeGreaterThan(0)
    expect(ev.plannedDropped).toBe(0)
    const late = dailyTarget(P({ trainTime: 'zvecer' }), [], plan, DAY, { today: DAY, hour: 23 })!
    expect(late.plannedBurn).toBe(0)
    expect(late.plannedDropped).toBeGreaterThan(0)
    expect(dailyTarget(P(), [], plan, DAY, { today: DAY, hour: 21 })!.plannedDropped).toBeGreaterThan(0)
  })
})

describe('D06 + A11 — obroki po dejanski uri vožnje in po opravljeni vožnji', () => {
  it('vožnja z ure ob 9:05 (treniram popoldne): kosilo po vožnji, nobenega »pred vožnjo« v času', () => {
    const plan = [day({})]
    const act: Activity = { id: 'a1', source: 'intervals', sport: 'kolo', date: DAY, start: `${DAY}T09:05:00`, name: 'Dolga', durationMin: 185, kcal: 1900 } as Activity
    const dm = dayMealsOf(dmIn(P(), plan, [act], [], 13))
    expect(dm.rideDone).toBe(true)
    expect(dm.dp.slots.map(s => s.label)).toContain('Po vožnji — kosilo')
    for (const s of dm.dp.slots) expect(`${s.when}`).not.toMatch(/pred vožnjo/)
    expect(dm.dp.slots.find(s => s.slot === 'kosilo')!.label).toBe('Po vožnji — kosilo')
    expect(dm.dp.tip).toMatch(/za tabo/)
  })
  it('opravljeno brez ure: kosilo, ki je bilo »2–3 h pred vožnjo«, je zdaj »po vožnji« (tudi kot naslednji obrok)', () => {
    const plan = [day({ done: { at: `${DAY}T12:00:00Z` } })]
    const dm = dayMealsOf(dmIn(P(), plan, [], [meal('zajtrk', 600, '07:30')], 13))
    const k = dm.dp.slots.find(s => s.key === 'kosilo')!
    expect(k.when).toBe('po vožnji')
    expect(k.beforeRide).toBeFalsy()
    const next = nextSlotOf(dm.dp, [meal('zajtrk', 600, '07:30')], 13)!
    expect(next.when).not.toMatch(/pred vožnjo/)
  })
  it('»Pred« na Danes in v Vadbi: po vožnji iz istega razporeda (opts.rideDone)', () => {
    const sch = mealScheduleOf(P(), ride(120), { rideDone: true })
    expect(sch.plan.map(s => s[2]).join(' ')).not.toMatch(/pred vožnjo/)
    expect(sch.plan.find(s => s[0] === 'kosilo')![2]).toBe('po vožnji')
    // ura začetka ob 18h pri »zjutraj« → razpored zvečer
    expect(mealScheduleOf(P({ trainTime: 'zjutraj' }), ride(120), { startH: 18 }).t).toBe('zvecer')
  })
})

describe('A12 — dan samo z močjo: brez »takoj po kolesu«', () => {
  it('privzeto lahek obrok prej; z vožnjo istega dne kot prej', () => {
    const d = { kind: 'moc' as const, durationMin: 45, zone: null }
    expect(fueling(d, { weightKg: 79 })!.before).not.toMatch(/kolesu/)
    expect(fueling(d, { weightKg: 79 }, { withRide: true })!.before).toMatch(/takoj po kolesu/)
  })
})

describe('D08 — primer obroka ne več kot 15 % čez kalorije obroka', () => {
  it('vse predloge od 200 do 400 kcal in majhni obroki (100–199 kcal) s posebno predlogo', () => {
    for (const T of [TPL, TPL_LF]) for (const k of Object.keys(T)) {
      for (let kcal = 200; kcal <= 400; kcal += 10) expect(scaled(T[k]!, kcal).kcal, `${k} @${kcal}`).toBeLessThanOrEqual(kcal * EXAMPLE_OVER_MAX)
      for (let kcal = 100; kcal < 200; kcal += 10) expect(exampleFor(k, kcal, T === TPL_LF)!.kcal, `${k} @${kcal}`).toBeLessThanOrEqual(kcal * EXAMPLE_OVER_MAX)
    }
    // prej: večerja 240 kcal → primer 350 kcal (krompir, 2 jajci)
    expect(scaled(TPL.vecerja!, 240).kcal).toBeLessThanOrEqual(276)
  })
  it('ženska 60 kg pri hujšanju: primeri skupaj ne čez cilj za več kot 15 %', () => {
    const t = dailyTarget(P({ sex: 'z', age: 35, heightCm: 165, weightKg: 60, ftp: null, goal: 'shujsati', deficit: 500, event: null }), [], [], DAY, { today: DAY, hour: 9 })!
    const dp = dayMealPlan({ weightKg: 60, trainTime: 'popoldne' }, t, null)
    expect(dp.slots.reduce((s, x) => s + x.exampleKcal, 0)).toBeLessThanOrEqual(t.kcal * EXAMPLE_OVER_MAX)
    for (const s of dp.slots) expect(s.exampleKcal, s.key).toBeLessThanOrEqual(s.kcal * EXAMPLE_OVER_MAX)
  })
})

describe('D09 — beljakovine skrčenega obroka ne ostanejo po načrtu', () => {
  it('velik zajtrk: noben preostali obrok nima več kot 45 % kalorij iz beljakovin', () => {
    const t = dailyTarget(P(), [], [], DAY, { today: DAY, hour: 9 })!
    const dp = dayMealPlan({ weightKg: 79, trainTime: 'popoldne' }, t, null)
    const a = adjustToEaten(dp, [meal('zajtrk', 1500, '08:00')], t.kcal, { weightKg: 79 })
    for (const s of a.slots.filter(x => !x.got)) expect(s.proteinG * 4, `${s.key} ${s.kcal} kcal`).toBeLessThanOrEqual(s.kcal * 0.5)
  })
})

describe('D10 — ocena brez AI: grami žit brez pridevnika so kuhani, »suh«/»nekuhan« so suhi', () => {
  it('pravilo in primeri v aplikaciji imajo pridevnik', () => {
    const a = estimateMeal('testenine 100 g s tuno')!
    expect(a.items[0]!.qty).toBe('kuhanih 100 g')
    expect(a.items[0]!.kcal).toBe(154)
    expect(estimateMeal('testenine (suhe) 100 g')!.items[0]!.kcal).toBe(355)
    expect(estimateMeal('nekuhan riž 70 g')!.items[0]!.qty).toBe('suhih 70 g')
    expect(estimateMeal('ajdova kaša 240 g')!.items[0]!.kcal).toBe(276)
    expect(estimateMeal('polenta 300 g')!.items[0]!.qty).toBe('kuhanih 300 g')
    // primeri obrokov (recepti, načrt) vedno povedo »suh« pri žitih, ki imajo kuhano težo
    for (const k of ['riz', 'testenine', 'kuskus', 'ajda', 'jesprenj', 'polenta', 'rizb', 'testenineb']) expect(qtyText(k, 80), k).toMatch(/\(suh/)
  })
})

describe('D11 + D12 + H08 — ocena brez AI pozna vsakdanje jedi, litre in kavo z mlekom', () => {
  it('pica, pivo, maslo, čokolada, burek, sendvič, kava', () => {
    const a = estimateMeal('kos pice in pivo')!
    expect(a.items.map(i => i.key)).toEqual(['pica', 'pivo'])
    const b = estimateMeal('2 rezini kruha z maslom in sirom')!
    expect(b.items.map(i => i.key)).toEqual(['kruh', 'maslo', 'sir'])
    expect(b.unknown).toEqual([])
    expect(estimateMeal('čokolada 50 g')!.kcal).toBe(270)
    expect(estimateMeal('burek s sirom')!.items.map(i => i.key)).toEqual(['burek'])
    expect(estimateMeal('sendvič s šunko in jabolko')!.items.map(i => i.key)).toEqual(['sendvic', 'jabolko'])
    expect(estimateMeal('kava')!.unknown).toEqual([])
  })
  it('»pol litra«, »0,5 l«, kava z mlekom, hrenovke s pomfrijem, orehi, parmezan, kokakola', () => {
    expect(estimateMeal('pol litra mleka')!.items[0]!.amount).toBe(500)
    // (v3.51 H23) čokoladno mleko je kakav z mlekom (~75 kcal na 100 ml), ne mleko 1,5 %
    expect(estimateMeal('čokoladno mleko 0,5 l')!.items[0]).toMatchObject({ key: 'kakav', amount: 500 })
    const k = estimateMeal('kava z mlekom')!
    expect(k.kcal).toBeGreaterThanOrEqual(15); expect(k.kcal).toBeLessThanOrEqual(40)
    const h = estimateMeal('2 hrenovki, 200 g pomfrija')!
    expect(h.items.map(i => i.key)).toEqual(['hrenovka', 'pomfri']); expect(h.kcal).toBeGreaterThan(500)
    expect(estimateMeal('orehi 20 g')!.items[0]!.key).toBe('oreski')
    expect(estimateMeal('50 g parmezana')!.items[0]).toMatchObject({ key: 'sir', amount: 50 })
    expect(estimateMeal('kokakola 0,5 l')!.kcal).toBe(210)
    expect(estimateMeal('salama in majoneza')!.items.map(i => i.key)).toEqual(['salama', 'majoneza'])
    expect(estimateMeal('masline')).toBeNull()
  })
})

describe('E35 — tabela živil: kalorije in makri se ujemajo', () => {
  it('|kcal − (4 B + 4 OH + 9 M)| ≤ 5 % (razen pijač z alkoholom)', () => {
    for (const [k, f] of Object.entries(F)) {
      if (F_ALCOHOL.has(k)) continue
      expect(Math.abs(f.kcal - (4 * f.p + 4 * f.c + 9 * f.f)), `${k}: ${f.kcal} vs ${4 * f.p + 4 * f.c + 9 * f.f}`).toBeLessThanOrEqual(Math.max(1, f.kcal * 0.05))
    }
  })
})

describe('D13 — »teža pada prehitro«: en prag (0,5 kg na teden brez nihanja) in en nasvet', () => {
  const today = '2026-10-21'
  const series = (rate: number, wob: number) => Array.from({ length: 22 }, (_, i) => ({ date: new Date(Date.parse(today) - (21 - i) * 86400_000).toISOString().slice(0, 10), weightKg: +(80 + (rate / 7) * i + (i % 2 ? wob : -wob)).toFixed(2) }))
  const fast = (c: ReturnType<typeof series>) => alerts({ profile: P(), activities: [], plan: [], checkins: c as never, recentMeals: [], today }).filter(a => /Teža pada/.test(a.text))
  it('−0,64 kg na teden brez nihanja: opozorilo s 150–250 kcal (prej šele pod −0,7)', () => {
    const c = series(-0.64, 0)
    expect(weightTrend(c)!.deltaWeek).toBeCloseTo(-0.64, 2)
    const a = fast(c)
    expect(a).toHaveLength(1)
    expect(a[0]!.text).toMatch(/150–250 kcal/)
  })
  it('−0,55 kg na teden z nihanjem ±0,6 kg: brez opozorila', () => {
    const c = series(-0.55, 0.6)
    expect(weightTrend(c)!.noise!).toBeGreaterThan(0.1)
    expect(fast(c)).toHaveLength(0)
  })
})

describe('D16 — tek, pohod, moč: brez »vožnje« in »na kolesu«', () => {
  it('pohod 3 h kolesarja in razlaga cilja za dan s tekom', () => {
    const f = fueling({ kind: 'pohod', durationMin: 180, zone: null }, P())!
    expect(`${f.before} ${f.during} ${f.after}`).not.toMatch(/kolesu|vožnj/)
    expect(f.during).toMatch(/Deficit nikoli na poti/)
    const tek = fueling({ kind: 'tek', durationMin: 90, zone: 'Z2' }, P({ trainTime: 'zvecer' }))!
    expect(`${tek.before} ${tek.after}`).not.toMatch(/kolesu|vožnj/)
    const t = dailyTarget(P(), [], [day({ kind: 'tek', title: 'Tek', durationMin: 60 })], DAY, { today: DAY, hour: 9 })!
    expect(targetParts(t, P(), { garmin: true })).not.toMatch(/vožnja/)
    expect(targetParts(t, P(), { garmin: true })).toMatch(/ko trening pride z Garmina/)
    // dan z vožnjo ostane
    const t2 = dailyTarget(P(), [], [day({})], DAY, { today: DAY, hour: 9 })!
    expect(targetParts(t2, P(), { garmin: true })).toMatch(/ko vožnja pride z Garmina/)
  })
})

describe('D17 — tek, hribi, moč: obroki s terminom vadbe', () => {
  it('tek 90 min zvečer: malica pred tekom in večerja po teku', () => {
    const dp = dayMealPlan({ weightKg: 95, trainTime: 'zvecer' }, { kcal: 2900, proteinG: 166, carbsG: 350 }, day({ kind: 'tek', title: 'Tek', durationMin: 90 }))
    expect(dp.slots.map(s => s.key)).toEqual(expect.arrayContaining(['pred', 'obnova']))
    expect(dp.slots.map(s => s.label)).toEqual(expect.arrayContaining(['Malica pred tekom', 'Po teku — večerja']))
    expect(dp.tip).not.toMatch(/vožnj|kolesu/)
  })
  it('dan z močjo 45 min v Prehrani (dayMealsOf): kosilo pred vadbo, večerja po vadbi; kratka vadba doma ne', () => {
    const dm = dayMealsOf(dmIn(P(), [day({ kind: 'moc', title: 'Moč', durationMin: 45, zone: null, role: 'moc' })], [], [], 9))
    expect(dm.dp.slots.map(s => `${s.label} · ${s.when}`)).toEqual(expect.arrayContaining(['Kosilo · 2–3 h pred vadbo', 'Po vadbi — večerja · v 45 min po vadbi']))
    const short = dayMealsOf(dmIn(P(), [day({ kind: 'moc', title: 'Moč doma', durationMin: 25, zone: null, role: 'moc' })], [], [], 9))
    expect(short.dp.slots.map(s => s.key)).toEqual(['zajtrk', 'kosilo', 'malica', 'vecerja'])
  })
})

describe('D19 + D21 + D33 + D34 + D38 — komplet za na kolo', () => {
  it('D19: samo banane — največ 3, manjko je zapisan', () => {
    const rf = rideFuel(ride(180), ['banana'])!
    expect(rf.plan.find(x => x.key === 'banana')!.n).toBeLessThanOrEqual(3)
    expect(rf.items.join(' ')).toMatch(/manjka ~\d+ g/)
    expect(rf.missingCarbs).toBeGreaterThan(0)
  })
  it('D21: prazen komplet = samo voda; null = privzeti komplet', () => {
    const w = rideFuel(ride(180), [])!
    expect(w.carriedCarbs).toBe(0)
    expect(w.plan.every(x => x.key === 'voda')).toBe(true)
    expect(w.items.join(' ')).toMatch(/Samo voda/)
    expect(rideFuel(ride(180), null)!.plan.some(x => x.key === 'iso_domaci')).toBe(true)
  })
  it('D33: samo kupljen izotonik — brez gela, ki ga nimaš', () => {
    const rf = rideFuel(ride(150), ['iso_kupljen'])!
    expect(rf.plan.some(x => x.key === 'gel')).toBe(false)
    expect(rf.items.join(' ')).not.toMatch(/× gel/)
  })
  it('D34: dolivanje omeni tudi bidon vode; D38: sol z mero', () => {
    const rf = rideFuel(ride(300))!
    const refill = rf.items.find(x => /dolivanje/.test(x))!
    expect(refill).toMatch(/voda/)
    expect(refill).toMatch(/¼ žličke soli/)
    expect(FUEL_ITEMS.find(i => i.key === 'iso_domaci')!.desc).toMatch(/¼ žličke soli \(~1,5 g\)/)
    expect(rf.items.join(' ')).not.toMatch(/ščep/)
  })
})

describe('D20 — vpis »vse po načrtu« ne uči manjšega pitja', () => {
  it('predlagano = kar je v načrtu za vpis (faktor 1)', () => {
    for (const [min, t] of [[180, 20], [180, 12], [300, 20], [240, 32], [90, 25], [75, 18]] as const) {
      const rf = rideFuel(ride(min, { role: min < 150 ? 'lahka' : 'dolga' }), null, { tempC: t })!
      const all = Object.fromEntries(rf.plan.map(x => [x.key, x.n]))
      const e = fuelEntry(rf, all, 'Dolga')
      expect(e.fluidMl / e.planMl, `${min} min ${t} °C`).toBe(1)
    }
  })
})

describe('D23 — dan tekme: popoldanska malica ni »Pred startom«', () => {
  const race = { kind: 'kolo' as const, durationMin: 30, zone: 'dirka', role: 'dirka' as const, title: 'Kronometer' }
  const dp = dayMealPlan({ weightKg: 79, trainTime: 'popoldne' }, { kcal: 2800, proteinG: 142, carbsG: 400 }, race)
  it('malica ob 16h po kosilu po tekmi gre med pojedeno, ne v »Pred startom«', () => {
    const g = gotBySlot(dp, [meal('kosilo', 700, '13:00'), meal('malica', 310, '16:00')])
    expect(g.get('pred')).toBe(0)
  })
  it('z znano uro starta: malica pred startom šteje, po njem ne', () => {
    expect(gotBySlot(dp, [meal('malica', 200, '09:30')], { startH: 10 }).get('pred')).toBe(200)
    expect(gotBySlot(dp, [meal('malica', 200, '11:30')], { startH: 10 }).get('pred')).toBe(0)
  })
})

describe('D35 + D36 — dan dirke in kratka tekma', () => {
  it('na dan Franje »dan dirke«; noben razlog ne konča z »brez deficita«', () => {
    const p = P()
    expect(noDeficitDay(p, '2027-06-13')).toBe('dan dirke')
    for (const d of ['2027-06-08', '2027-06-11', '2027-06-12', '2027-06-13', '2027-06-14']) expect(noDeficitDay(p, d) ?? '', d).not.toMatch(/brez deficita$/)
  })
  it('kronometer 30 min: brez »ml na uro«', () => {
    const f = fueling({ kind: 'kolo', durationMin: 30, zone: 'dirka', role: 'dirka' }, { weightKg: 75 })!
    expect(f.during).not.toMatch(/ml na uro/)
    expect(f.during).toMatch(/nekaj požirkov/)
  })
})

describe('H33 + B43 — gorivo na uro iz ene tabele (Gorivo, »Med«, opis seje)', () => {
  it('»Med« na kolesu = rideFuel g/h; brez OH (Z2 80 min) »voda«, ne »0–30 g«', () => {
    const cases = [ride(80, { role: 'lahka', title: 'Z2' }), ride(120, { role: 'lahka', title: 'Z2' }), ride(240), ride(90, { zone: 'Z5', role: 'kljucna', title: 'VO2max' }), ride(300, { zone: 'dirka', role: 'dirka', title: 'Franja' }), ride(180, { title: 'Simulacija Franje' })]
    for (const d of cases) {
      const g = rideFuel(d)!.gph, f = fueling(d, P())!
      if (g) expect(f.during, d.title).toContain(`~${g} g`)
      else expect(f.during, d.title).toMatch(/Voda po žeji/)
    }
  })
  it('opisi sej v načrtu: g OH na uro je isto kot v Gorivu', () => {
    let checked = 0, long = 0
    for (const ws of ['2026-10-19', '2026-12-07', '2027-04-05', '2027-05-10', '2027-06-07']) {
      for (const d of buildWeek({ profile: P(), activities: [], weekStart: ws, notBefore: '2026-01-01' })) {
        if (d.kind !== 'kolo') continue
        // prej dolga »Gorivo: od 30. minute 50–60 g …« ob Gorivu 50 ali 60 g
        if (/Gorivo: od 30\. minute/.test(d.desc)) { expect(d.desc, d.title).toMatch(/Gorivo: od 30\. minute ~\d+ g/); long++ }
        const m = /~(\d+) g (?:OH|ogljikovih hidratov) na uro/.exec(d.desc)
        if (!m) continue
        expect(+m[1]!, `${d.date} ${d.title}: ${d.desc}`).toBe(rideFuel(d)!.gph)
        checked++
      }
    }
    expect(checked).toBeGreaterThan(3)
    expect(long).toBeGreaterThan(0)
  })
  it('ena tabela: dirka 85/70, simulacija 80, dolga 60/50, Z2 ≥ 90 min 40', () => {
    expect(fuelGph(ride(300, { role: 'dirka' }))).toBe(85)
    expect(fuelGph(ride(120, { role: 'dirka' }))).toBe(70)
    expect(fuelGph(ride(180, { title: 'Simulacija dirke' }))).toBe(80)
    expect(fuelGph(ride(180))).toBe(60)
    expect(fuelGph(ride(120))).toBe(50)
    expect(fuelGph(ride(95, { role: 'lahka', title: 'Z2' }))).toBe(40)
  })
})

describe('H31 — kratka lahka seja: brez kartice »Gorivo za ta trening«', () => {
  it('25-min tek, 30-min hoja in 30-min vadba doma: nič; 2 h kolesa in tekma ostaneta', () => {
    expect(fueling({ kind: 'tek', durationMin: 25, zone: null }, P())).toBeNull()
    expect(fueling({ kind: 'pohod', durationMin: 30, zone: null }, P())).toBeNull()
    expect(fueling({ kind: 'moc', durationMin: 30, zone: null }, P())).toBeNull()
    expect(fueling(ride(120), P())).not.toBeNull()
    expect(fueling({ kind: 'kolo', durationMin: 30, zone: 'dirka', role: 'dirka' }, P())).not.toBeNull()
  })
})

describe('A36 — gorivo: litri na 0,05 l, opomnik za hrano v odmoru', () => {
  it('75 min na pragu: »0,75 l«, ne »0,8 l«', () => {
    const rf = rideFuel(ride(75, { zone: 'Z4', role: 'kljucna', title: 'Prag' }))!
    expect(rf.fluidMl).toBe(750)
    expect(rf.schedule).toMatch(/~0,75 l/)
  })
  it('intervali: z lahkimi deli vadbe hrana pade v odmor, ne v interval', () => {
    const steps = [{ kind: 'ogrevanje', sec: 20 * 60 }, ...[0, 1, 2].flatMap(() => [{ kind: 'delo', sec: 10 * 60 }, { kind: 'lahko', sec: 5 * 60 }]), { kind: 'iztek', sec: 10 * 60 }]
    const win = restWindowsOf(steps)
    const rf = rideFuel(ride(75, { zone: 'Z4', role: 'kljucna', title: 'Prag' }), ['gel'], { restWindows: win })!
    const food = rf.cues.filter(c => c.solid)
    expect(food.length).toBeGreaterThan(1)
    for (const c of food) expect(win.some(w => c.atMin >= w.from && c.atMin <= w.to), `${c.atMin}`).toBe(true)
  })
})

describe('D02 + F01 + H28 + C12 — ciljna teža', () => {
  const Z = (o: Partial<Profile> = {}) => P({ sex: 'z', age: 35, heightCm: 165, weightKg: 60, ftp: null, goal: 'shujsati', deficit: null, event: null, ...o })
  it('hujšanje brez tekme: zdrav prvi mejnik (−10 %, ne pod ITM 21/22), ne tekmovalna maščoba', () => {
    expect(shownTargetWeight(Z(), false)).toBe(57)                                                   // prej 53
    expect(shownTargetWeight(Z({ age: 45, weightKg: 78 }), true)).toBe(70)                          // prej 57,5
    expect(shownTargetWeight(P({ age: 40, heightCm: 182, weightKg: 95, ftp: null, goal: 'shujsati', deficit: 500, event: null }), true)).toBe(85.5)   // prej 76,5
    // fitnes uporabnica 165 cm / 72 kg (C12): ne 58 kg po kolesarski formuli
    expect(shownTargetWeight(Z({ weightKg: 72 }), true)).toBe(65)
  })
  it('na zdravem mejniku ni več deficita', () => {
    expect(goalDeficit(Z({ weightKg: 57, goalStart: { date: '2026-09-01', ftp: null, weightKg: 60 } }), DAY)).toBe(0)
    expect(goalDeficit(Z({ weightKg: 59, goalStart: { date: '2026-09-01', ftp: null, weightKg: 60 } }), DAY)).toBe(500)
  })
  it('mladoletni z vpisano maščobo: brez najboljše teže in mejnikov hujšanja', () => {
    const m = P({ age: 16, heightCm: 175, weightKg: 70, bodyFatPct: 20, goalStart: { date: '2026-09-21', ftp: 200, weightKg: 70 } })
    expect(raceWeight(m, 30)).toBeNull()
    expect(targetWeightOf(m, DAY)).toBeNull()
    for (const x of milestones(m)) expect(x.weight === null || x.weight === 70, x.label).toBe(true)
  })
  it('kolesar brez deficita (U23): ciljne teže ni, mejniki teže ne padajo', () => {
    const u = P({ deficit: 0, weightKg: 70, heightCm: 180, goalStart: { date: '2026-09-21', ftp: 300, weightKg: 70 } })
    expect(targetWeightOf(u, DAY)).toBeNull()
    for (const x of milestones(u)) if (x.weight != null) expect(x.weight, x.label).toBeGreaterThanOrEqual(70)
  })
  it('kolesar s tekmo in deficitom: tekmovalna teža ostane (Blaž 79 → 72 kg)', () => {
    expect(targetWeightOf(P(), DAY)).toBe(raceWeight(P(), null)!.kg)
  })
})

describe('varovalke ostanejo', () => {
  it('nikoli pod BMR in 1500/1200 kcal, deficit največ 750, mladoletni brez deficita', () => {
    const m = dailyTarget(P({ deficit: 2000, kcalOverride: 900 }), [], [], DAY, { today: DAY, hour: 9 })!
    expect(m.kcal).toBeGreaterThanOrEqual(MIN_ABS_M)
    expect(m.maintenance - m.kcal).toBeLessThanOrEqual(MAX_DEFICIT)
    const z = dailyTarget(P({ sex: 'z', age: 30, heightCm: 160, weightKg: 50, deficit: 750, goal: 'shujsati', event: null }), [], [], DAY, { today: DAY, hour: 9 })!
    expect(z.kcal).toBeGreaterThanOrEqual(MIN_ABS_Z)
    expect(z.kcal).toBeGreaterThanOrEqual(z.floor)
    const minor = dailyTarget(P({ age: 16, deficit: 750, goal: 'shujsati', kcalOverride: 1400 }), [], [day({})], DAY, { today: DAY, hour: 9 })!
    expect(minor.deficit).toBe(0)
    expect(minor.kcal).toBeGreaterThanOrEqual(minor.maintenance)
    expect(goalDeficit(P({ age: 17, deficit: 500 }), DAY)).toBe(0)
  })
})
