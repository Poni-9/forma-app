import { describe, it, expect } from 'vitest'
import { buildWeek, weekContext, FRANJA_2027 } from '../src/domain/training/planner'
import { offSeasonNow, cyclePatch } from '../src/domain/training/goalChange'
import type { Profile } from '../src/domain/types'

const now = new Date().toISOString()
// Blaž: Franja 2027, off-season od ponedeljka 28. 9. (3 tedne); danes nedelja 4. 10. (1. teden off-seasona)
const blaz = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, restHr: 55, maxHr: 200, lthr: 184, ftp: 240, ftpDate: '2026-09-20',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, hoursPerWeek: 14, baseHours: null,
  strength: { on: true, equipment: 'gym', phases: ['osnova'] }, strengthDays: 2, goal: 'dirka', deficit: 400, neat: 1.4,
  event: { ...FRANJA_2027 }, cycleStart: '2026-09-28', offSeasonWeeks: 3, onboardingDone: true, createdAt: now, updatedAt: now, ...o,
})
const TODAY = '2026-10-04', WS = '2026-09-28'
const apply = (p: Profile, patch: Partial<Profile>): Profile => ({ ...p, ...patch })

describe('cilj sezone sredi off-seasona', () => {
  it('prepozna off-season: teden 1 od 3, ostaneta 3; po koncu ga ni', () => {
    expect(offSeasonNow(blaz(), TODAY)).toEqual({ week: 1, of: 3, left: 3 })
    expect(offSeasonNow(blaz(), '2026-10-12')).toEqual({ week: 3, of: 3, left: 1 })
    expect(offSeasonNow(blaz(), '2026-10-19')).toBeNull()
    expect(offSeasonNow(blaz({ offSeasonWeeks: 0 }), TODAY)).toBeNull()
    expect(weekContext(blaz(), WS).phase).toBe('prehod')
  })
  it('isti cilj + »končaj off-season«: osnova začne ta teden — načrt ni več hribi (prej je ostal off-season)', () => {
    const before = buildWeek({ profile: blaz(), activities: [], weekStart: WS, notBefore: WS })
    expect(before.some(d => /Hribi/.test(d.title))).toBe(true)
    const c = cyclePatch(blaz(), FRANJA_2027.date, TODAY, true)
    expect(c).toMatchObject({ keep: true, endedOff: true, firstWeek: true, patch: { cycleStart: WS, offSeasonWeeks: 0 } })
    const p = apply(blaz(), c.patch)
    expect(weekContext(p, WS).phase).not.toBe('prehod')
    const after = buildWeek({ profile: p, activities: [], weekStart: WS, notBefore: TODAY, firstWeek: c.firstWeek })
    expect(after.some(d => /Hribi — daljša tura/.test(d.title))).toBe(false)
    expect(after.some(d => d.kind === 'kolo')).toBe(true)
  })
  it('v 2. tednu off-seasona: končaj = minuli teden ostane off-season, od tega tedna osnova', () => {
    const c = cyclePatch(blaz({ cycleStart: '2026-09-21' }), FRANJA_2027.date, TODAY, true)
    expect(c.patch).toEqual({ cycleStart: '2026-09-21', offSeasonWeeks: 1 })
    expect(weekContext(apply(blaz({ cycleStart: '2026-09-21' }), c.patch), WS).phase).not.toBe('prehod')
  })
  it('nov cilj + »ostani«: off-season do konca (preostali tedni), potem osnova do novega cilja', () => {
    const c = cyclePatch(blaz({ cycleStart: '2026-09-21', offSeasonWeeks: 4 }), '2027-05-02', TODAY, false)
    expect(c).toMatchObject({ keep: false, endedOff: false, patch: { cycleStart: WS, offSeasonWeeks: 3 } })
    const p = apply(blaz({ event: { name: 'Nova', date: '2027-05-02', distanceKm: 100 } }), c.patch)
    expect(weekContext(p, WS).phase).toBe('prehod')
    expect(weekContext(p, '2026-10-19').phase).not.toBe('prehod')
  })
  it('isti cilj + »ostani«: nič se ne spremeni', () => {
    const c = cyclePatch(blaz(), FRANJA_2027.date, TODAY, false)
    expect(c).toMatchObject({ keep: true, endedOff: false, firstWeek: false, patch: { cycleStart: WS } })
    expect(c.patch.offSeasonWeeks).toBeUndefined()
  })
  it('izven off-seasona kot prej: isti cilj teče naprej, nov datum = nov makrocikel', () => {
    const p = blaz({ cycleStart: '2026-09-07', offSeasonWeeks: 0 })
    expect(cyclePatch(p, FRANJA_2027.date, TODAY, true)).toMatchObject({ keep: true, endedOff: false, firstWeek: false, patch: { cycleStart: '2026-09-07' } })
    expect(cyclePatch(p, '2027-05-02', TODAY, true)).toMatchObject({ keep: false, firstWeek: true, patch: { cycleStart: WS, offSeasonWeeks: 0 } })
  })
})
