import { describe, it, expect, vi, afterEach } from 'vitest'
import { activityFromGarmin, garminSport, garminLocalDate, sameRideAsIcu, enrichIcuWithGarmin, type GarminActivityRec } from '../src/domain/garmin/activities'
import { wellnessFromGarmin, mergeWellness, upsertWellnessDays } from '../src/domain/garmin/wellness'
import { cycleFromMct, cycleOn, cycleAdvice, phaseFromDay, phaseOf, upsertCycle, lateLuteal, CYCLE_TEXT } from '../src/domain/garmin/cycle'
import { recoveryOf, wellnessActive, type WellnessDay } from '../src/domain/wellness'
import { garminDevice, sourceLabel, aiAllowed } from '../src/domain/import/provenance'
import { actKey } from '../src/data/merge'
import { mergeActivities } from '../src/data/merge'
import type { Activity } from '../src/domain/types'

vi.mock('../src/data/firebase', () => ({ idToken: async () => 'tok', timeoutSignal: () => undefined }))

const NOW = '2026-10-26T10:00:00.000Z'
const p = { ftp: 250, lthr: 165, restHr: 50, maxHr: 190 }
// SPEC §3.1 primer (CYCLING) + details s strežnika
const rec: GarminActivityRec = {
  summaryId: 'x-123', activityId: 987654321, activityName: 'Vodice Kolesarjenje', activityType: 'ROAD_BIKING',
  startTimeInSeconds: 1792996800, startTimeOffsetInSeconds: 7200, durationInSeconds: 5400, distanceInMeters: 45230.5,
  activeKilocalories: 1120, deviceName: 'Edge 540', averageHeartRateInBeatsPerMinute: 142, maxHeartRateInBeatsPerMinute: 171,
  averageSpeedInMetersPerSecond: 8.376, totalElevationGainInMeters: 612.3,
  details: { avgWatts: 188.4, np: 205.2, maxHr: 172, avgCadence: 86, polyline: 'abc', hrZoneSec: [600, 2400, 1800, 600, 0, 0, 0] }, t: 1793000400000,
}

describe('v3.52 Garmin — aktivnosti', () => {
  it('povzetek + details → Activity z virom garmin, GARMIN_API, napravo, močjo in TSS iz NP', () => {
    const a = activityFromGarmin(rec, p, NOW)!
    expect(a.source).toBe('garmin'); expect(a.originHint).toBe('GARMIN_API'); expect(a.deviceName).toBe('Edge 540')
    expect(a.sport).toBe('kolo'); expect(a.trainer).toBe(false)
    expect(a.start).toBe('2026-10-26T06:40:00.000Z'); expect(a.date).toBe('2026-10-26')
    expect(a.durationMin).toBe(90); expect(a.distKm).toBe(45.2); expect(a.elevM).toBe(612); expect(a.kcal).toBe(1120)
    expect(a.avgHr).toBe(142); expect(a.maxHr).toBe(171); expect(a.avgPower).toBe(188); expect(a.deviceWatts).toBe(true)
    expect(a.speedKmh).toBe(30.2); expect(a.hrZoneSec).toEqual([600, 2400, 1800, 600, 0, 0, 0])
    // 1,5 h × (205/250)² × 100 = 101
    expect(a.tss).toBe(101)
    expect(a.ext).toEqual({ garminId: '987654321', garminSummaryId: 'x-123' })
    expect(a.aiEligible).toBe(true); expect(a.geoRetain).toBe(true); expect(a.polyline).toBe('abc'); expect(aiAllowed(a)).toBe(true)
    expect(garminDevice(a)).toBe('Garmin Edge 540'); expect(sourceLabel(a)).toBe('Garmin Edge 540')
    expect(a.name).toBe('Vodice Kolesarjenje')
  })
  it('lokalni datum iz zamika: vožnja ob 23:30 UTC z +2 h je naslednji dan', () => {
    expect(garminLocalDate(Date.UTC(2026, 9, 25, 23, 30) / 1000, 7200)).toBe('2026-10-26')
    expect(garminLocalDate(Date.UTC(2026, 9, 25, 23, 30) / 1000, 0)).toBe('2026-10-25')
  })
  it('brez details: ocena TSS iz utripa, deviceWatts false, ime samodejno; ročni vnos → GARMIN_API_MANUAL brez naprave', () => {
    const a = activityFromGarmin({ ...rec, details: null, activityName: undefined, manual: true, deviceName: 'unknown' }, p, NOW)!
    expect(a.originHint).toBe('GARMIN_API_MANUAL'); expect(a.deviceName).toBeNull(); expect(a.avgPower).toBeNull(); expect(a.deviceWatts).toBe(false)
    expect(a.polyline).toBeNull(); expect(a.hrZoneSec).toBeNull()
    expect(a.tss).toBeGreaterThan(50); expect(a.name).toBe('Kolo 45 km')
    expect(sourceLabel(a)).toBe('Garmin · ročni vnos'); expect(garminDevice(a)).toBe('Garmin')
  })
  it('šport iz activityType: znane vrednosti, varovalka po delih besede, indoor', () => {
    expect(garminSport('CYCLING')).toEqual({ sport: 'kolo', indoor: false })
    expect(garminSport('INDOOR_CYCLING')).toEqual({ sport: 'kolo', indoor: true })
    expect(garminSport('VIRTUAL_RIDE').indoor).toBe(true)
    expect(garminSport('TREADMILL_RUNNING')).toEqual({ sport: 'tek', indoor: true })
    expect(garminSport('TRAIL_RUNNING').sport).toBe('tek')
    expect(garminSport('HIKING').sport).toBe('pohod')
    expect(garminSport('STRENGTH_TRAINING').sport).toBe('moc'); expect(garminSport('YOGA').sport).toBe('moc')
    expect(garminSport('OPEN_WATER_SWIMMING').sport).toBe('plavanje')
    expect(garminSport('E_BIKE_FITNESS').sport).toBe('kolo'); expect(garminSport('SOME_NEW_RIDE').sport).toBe('kolo')
    expect(garminSport('MULTI_SPORT').sport).toBe('drugo'); expect(garminSport('').sport).toBe('drugo'); expect(garminSport(undefined).sport).toBe('drugo')
  })
  it('preskoči: brez začetka, starš MULTI_SPORT, prekratko (kolo < 5 min, pohod < 15 min); moč brez meje', () => {
    expect(activityFromGarmin({ ...rec, startTimeInSeconds: undefined }, p)).toBeNull()
    expect(activityFromGarmin({ ...rec, isParent: true }, p)).toBeNull()
    expect(activityFromGarmin({ ...rec, durationInSeconds: 200 }, p)).toBeNull()
    expect(activityFromGarmin({ ...rec, activityType: 'WALKING', durationInSeconds: 600 }, p)).toBeNull()
    expect(activityFromGarmin({ ...rec, activityType: 'STRENGTH_TRAINING', durationInSeconds: 200, distanceInMeters: undefined }, p)?.sport).toBe('moc')
  })
  it('brez activityId je ključ summaryId; brez obeh ext prazen, a zapis velja', () => {
    expect(activityFromGarmin({ ...rec, activityId: undefined }, p)!.ext).toEqual({ garminId: 's:x-123', garminSummaryId: 'x-123' })
    expect(activityFromGarmin({ ...rec, activityId: undefined, summaryId: undefined }, p)!.ext).toEqual({})
  })
  it('dedup z intervals.icu: ista vožnja (izvor GARMIN, start ±90 s) → obstoječi dobi id-je in manjkajočo moč, dvojnika ni', () => {
    const g = activityFromGarmin(rec, p, NOW)!
    const icu: Activity = { id: 'i1', source: 'intervals', originHint: 'GARMIN_CONNECT', sport: 'kolo', date: '2026-10-26', start: '2026-10-26T06:40:50.000Z', name: 'Vožnja', durationMin: 90, distKm: 45.2, avgHr: 142, deviceWatts: null, aiEligible: true, geoRetain: true, ext: { intervalsId: 'i1' }, createdAt: NOW, updatedAt: NOW }
    expect(sameRideAsIcu(g, icu)).toBe(true)
    expect(sameRideAsIcu(g, { ...icu, originHint: 'STRAVA' })).toBe(false)
    expect(sameRideAsIcu(g, { ...icu, start: '2026-10-26T06:45:00.000Z' })).toBe(false)
    expect(sameRideAsIcu(g, { ...icu, sport: 'tek' })).toBe(false)
    const m = enrichIcuWithGarmin(icu, g)!
    expect(m.id).toBe('i1'); expect(m.source).toBe('intervals'); expect(m.ext).toEqual({ intervalsId: 'i1', garminId: '987654321', garminSummaryId: 'x-123' })
    expect(m.avgPower).toBe(188); expect(m.deviceWatts).toBe(true); expect(m.avgHr).toBe(142); expect(m.polyline).toBe('abc')
    expect(enrichIcuWithGarmin(m, g)).toBeNull()   // drugič ni kaj spremeniti
    // ključ čez naprave: intervals.icu id ima prednost, samo Garmin → garmin:
    expect(actKey(m)).toBe('icu:i1'); expect(actKey(g)).toBe('garmin:987654321')
  })
  it('združevanje naprav: ista vožnja z Garmina na eni in iz intervals.icu na drugi napravi → ena', () => {
    const g = activityFromGarmin(rec, p, NOW)!
    const icu: Activity = { id: 'i1', source: 'intervals', originHint: 'GARMIN', sport: 'kolo', date: '2026-10-26', start: '2026-10-26T06:40:30.000Z', name: 'Vožnja', durationMin: 90, aiEligible: true, geoRetain: true, ext: { intervalsId: 'i1' }, createdAt: NOW, updatedAt: NOW }
    const r = mergeActivities([g], [icu], {}, Date.now())
    expect(r.list).toHaveLength(1)
    // dve različni vožnji istega vira ostaneta dve
    const g2 = { ...g, id: 'g2', ext: { garminId: '111' } }
    expect(mergeActivities([g], [g2], {}, Date.now()).list).toHaveLength(2)
  })
})

describe('v3.52 Garmin — zdravje', () => {
  const health = {
    dailies: [
      { summaryId: 'd1', calendarDate: '2026-10-25', durationInSeconds: 43200, restingHeartRateInBeatsPerMinute: 49, averageStressLevel: 31, t: 1 },
      { summaryId: 'd1', calendarDate: '2026-10-25', durationInSeconds: 86400, restingHeartRateInBeatsPerMinute: 47, averageStressLevel: 52, t: 2 },   // isti dan znova (cel dan) → zamenja
      { summaryId: 'd2', calendarDate: '2026-10-26', durationInSeconds: 30000, restingHeartRateInBeatsPerMinute: 46, averageStressLevel: -1, bodyBatteryHighestValue: 80 },
    ],
    sleeps: [
      { summaryId: 's1', calendarDate: '2026-10-25', startTimeInSeconds: 1761345000, startTimeOffsetInSeconds: 7200, durationInSeconds: 25920, remSleepInSeconds: 5000, overallSleepScore: { value: 83.4, qualifierKey: 'GOOD' } },
      // brez calendarDate: zaspal 25. 10. ob 23:00 lokalno, spal 7,5 h → jutro 26. 10.
      { summaryId: 's2', startTimeInSeconds: Date.UTC(2026, 9, 25, 21, 0) / 1000, startTimeOffsetInSeconds: 7200, durationInSeconds: 27000, overallSleepScore: { value: 71 } },
    ],
    hrv: [{ summaryId: 'h1', calendarDate: '2026-10-25', lastNightAvg: 61.26 }, { summaryId: 'h2', calendarDate: '2026-10-26', lastNightAvg: 58 }],
    // (popravki V7) stres šteje samo iz zapisa za cel dan (partial: false ali 86 400 s); Body Battery ob prebujanju → bbAtWake
    stress: [{ summaryId: 'st1', calendarDate: '2026-10-26', averageStressLevel: 44, bodyBatteryAtWake: 27, bodyBatteryMax: 61, partial: false }],
    now: 5,
  }
  it('dailies/sleeps/hrv/stress → dnevi; isti dan večkrat → zadnji; −1 stres → brez; Body Battery ob prebujanju pred max in dailies', () => {
    const d = wellnessFromGarmin(health)
    expect(d.map(x => x.date)).toEqual(['2026-10-25', '2026-10-26'])
    expect(d[0]).toEqual({ date: '2026-10-25', sleepH: 7.2, sleepScore: 83, hrv: 61.3, rhr: 47, stress: 52 })
    expect(d[1]).toEqual({ date: '2026-10-26', sleepH: 7.5, sleepScore: 71, hrv: 58, rhr: 46, stress: 44, bodyBattery: 27, bbAtWake: true })
    expect(wellnessFromGarmin(null)).toEqual([]); expect(wellnessFromGarmin({ dailies: [{ summaryId: 'x' }] as never })).toEqual([])
  })
  // (popravki V7) stres je VČERAJŠNJI cel dan (današnji je zjutraj šele delen)
  it('recoveryOf: včerajšnji stres ≥ 50 → −4 »včeraj visok stres«, Body Battery < 30 → −6 »Body Battery nizek«; pod mejo nič', () => {
    const base: WellnessDay[] = Array.from({ length: 10 }, (_, i) => ({ date: `2026-10-${String(10 + i).padStart(2, '0')}`, sleepH: 7.5, sleepScore: 80, hrv: 60, rhr: 48 }))
    const r = recoveryOf([...base, { date: '2026-10-25', sleepH: 7.5, sleepScore: 80, hrv: 60, rhr: 48, stress: 52 }, { date: '2026-10-26', sleepH: 7.5, sleepScore: 80, hrv: 60, rhr: 48, stress: 20, bodyBattery: 27 }], '2026-10-26')!
    expect(r.reasons).toEqual(['včeraj visok stres', 'Body Battery nizek']); expect(r.penalty).toBe(10); expect(r.stress).toBe(52); expect(r.bodyBattery).toBe(27)
    const ok = recoveryOf([...base, { date: '2026-10-25', sleepH: 7.5, sleepScore: 80, hrv: 60, rhr: 48, stress: 49 }, { date: '2026-10-26', sleepH: 7.5, sleepScore: 80, hrv: 60, rhr: 48, stress: 70, bodyBattery: 30 }], '2026-10-26')!
    expect(ok.reasons).toEqual([]); expect(ok.penalty).toBe(0)
    const none = recoveryOf([...base, { date: '2026-10-26', sleepH: 7.5, sleepScore: 80, hrv: 60, rhr: 48 }], '2026-10-26')!
    expect(none.stress).toBeUndefined(); expect(none.reasons).toEqual([])
  })
  it('združitev z intervals.icu: Garmin ima prednost po datumu, manjkajoča polja ostanejo; upsert obdrži zadnjih N dni', () => {
    const icu: WellnessDay[] = [{ date: '2026-10-25', sleepH: 7, sleepScore: 70, hrv: 55, rhr: 50 }, { date: '2026-10-24', sleepH: 6, sleepScore: null, hrv: null, rhr: 51 }]
    const g: WellnessDay[] = [{ date: '2026-10-25', sleepH: 7.2, sleepScore: null, hrv: 61, rhr: 47, stress: 40 }, { date: '2026-10-26', sleepH: 8, sleepScore: 90, hrv: 62, rhr: 46 }]
    const m = mergeWellness(icu, g)
    expect(m.map(x => x.date)).toEqual(['2026-10-24', '2026-10-25', '2026-10-26'])
    expect(m[1]).toEqual({ date: '2026-10-25', sleepH: 7.2, sleepScore: 70, hrv: 61, rhr: 47, stress: 40 })
    expect(mergeWellness(null, null)).toEqual([])
    expect(upsertWellnessDays(g, icu, 2).map(x => x.date)).toEqual(['2026-10-25', '2026-10-26'])
  })
  it('wellnessActive: intervals.icu ALI Garmin neposredno (health vklopljen in povezan)', () => {
    expect(wellnessActive({ wellnessOn: true })).toBe(true)
    expect(wellnessActive({ garmin: { connected: true, health: true } })).toBe(true)
    expect(wellnessActive({ garmin: { connected: false, health: true } })).toBe(false)
    expect(wellnessActive({ garmin: { connected: true } })).toBe(false)
    expect(wellnessActive(null)).toBe(false)
  })
})

describe('v3.52 Garmin — cikel (samo prikaz in pravila)', () => {
  const mct = { userId: 'u', summaryId: 'm1', calendarDate: '2026-10-26', periodStartDate: '2026-10-20', periodLength: 5, dayInCycle: 7, cycleLength: 28, predictedCycleLength: 28, isPredictedCycle: false, currentPhase: 2, currentPhaseType: 'FOLLICULAR', lengthOfCurrentPhase: 8, daysUntilNextPhase: 2 }
  it('mct zapis [DOMNEVA] → CycleDay; napačna shema → null, nič se ne sesuje', () => {
    expect(cycleFromMct(mct)).toEqual({ date: '2026-10-26', dayInCycle: 7, cycleLength: 28, periodLength: 5, phase: 'folikularna', predicted: false, periodStartDate: '2026-10-20' })
    expect(cycleFromMct({ calendarDate: '2026-10-26', dayInCycle: 2 })!.phase).toBe('menstrualna')          // faza iz dneva
    expect(cycleFromMct({ calendarDate: '2026-10-26', currentPhase: 4, isPredictedCycle: true })).toMatchObject({ phase: 'lutealna', predicted: true, dayInCycle: null })
    expect(cycleFromMct({ calendarDate: 'x' })).toBeNull(); expect(cycleFromMct(null)).toBeNull(); expect(cycleFromMct('nič')).toBeNull(); expect(cycleFromMct({ calendarDate: '2026-10-26' })).toBeNull()
    expect(phaseOf('MENSTRUAL')).toBe('menstrualna'); expect(phaseOf('OVULATION')).toBe('ovulacija'); expect(phaseOf('LUTEAL')).toBe('lutealna'); expect(phaseOf('???')).toBeNull(); expect(phaseOf(3)).toBe('ovulacija')
    expect([1, 5, 6, 13, 14, 15, 16, 28].map(d => phaseFromDay(d, 28, 5))).toEqual(['menstrualna', 'menstrualna', 'folikularna', 'ovulacija', 'ovulacija', 'ovulacija', 'lutealna', 'lutealna'])
  })
  it('cycleOn: zapis dneva; sicer izpeljava iz zadnjega (napoved), čez 35 dni nič', () => {
    const c = [cycleFromMct(mct)!]
    expect(cycleOn(c, '2026-10-26')!.predicted).toBe(false)
    const n = cycleOn(c, '2026-10-30')!
    expect(n).toMatchObject({ date: '2026-10-30', dayInCycle: 11, phase: 'folikularna', predicted: true })
    expect(cycleOn(c, '2026-11-17')).toMatchObject({ dayInCycle: 1, phase: 'menstrualna', periodStartDate: '2026-11-17' })
    expect(cycleOn(c, '2026-12-15')).toBeNull(); expect(cycleOn(null, '2026-10-26')).toBeNull(); expect(cycleOn(c, '2026-10-01')).toBeNull()
    expect(upsertCycle(c, [{ ...c[0]!, dayInCycle: 8 }]).length).toBe(1); expect(upsertCycle(c, [{ ...c[0]!, date: '2026-10-27' }], 1).map(x => x.date)).toEqual(['2026-10-27'])
  })
  it('pravila: menstrualna ali pozna lutealna + trd dan → »Olajšaj dan«; prehrana železo (menstrualna) / apetit (lutealna); brez kcal', () => {
    const hard = { kind: 'kolo' as const, role: 'kljucna' as const, zone: 'Z5', title: 'VO2max 5 × 4 min', optional: false }
    const easy = { kind: 'kolo' as const, role: 'lahka' as const, zone: 'Z2', title: 'Z2 60 min', optional: false }
    const at = (day: number, phase?: string) => [cycleFromMct({ calendarDate: '2026-10-26', dayInCycle: day, cycleLength: 28, periodLength: 5, ...(phase ? { currentPhaseType: phase } : {}) })!]
    const m = cycleAdvice(at(2), hard, '2026-10-26')
    expect(m.easeOffer).toBe(true); expect(m.nutritionNote).toBe(CYCLE_TEXT.ironNote); expect(m.coachNote).toBe(CYCLE_TEXT.menstrualCoach); expect(m.phase).toBe('menstrualna')
    expect(cycleAdvice(at(2), easy, '2026-10-26').easeOffer).toBe(false)
    const f = cycleAdvice(at(9), hard, '2026-10-26')
    expect(f).toMatchObject({ easeOffer: false, nutritionNote: null, coachNote: null, phase: 'folikularna' })
    const earlyL = cycleAdvice(at(18), hard, '2026-10-26')
    expect(earlyL).toMatchObject({ easeOffer: false, nutritionNote: CYCLE_TEXT.appetiteNote, coachNote: null, phase: 'lutealna' })
    const lateL = cycleAdvice(at(25), hard, '2026-10-26')
    expect(lateL).toMatchObject({ easeOffer: true, nutritionNote: CYCLE_TEXT.appetiteNote, coachNote: CYCLE_TEXT.lateLutealCoach })
    expect(lateLuteal(at(24)[0]!)).toBe(true); expect(lateLuteal(at(23)[0]!)).toBe(false)
    // lutealna brez dneva (samo faza) šteje kot občutljiva
    expect(cycleAdvice([cycleFromMct({ calendarDate: '2026-10-26', currentPhaseType: 'LUTEAL' })!], hard, '2026-10-26').easeOffer).toBe(true)
    // napoved dobi pripis
    expect(cycleAdvice(at(2), hard, '2026-10-27').coachNote).toBe(`${CYCLE_TEXT.menstrualCoach} ${CYCLE_TEXT.predicted}`)
    // brez podatkov nič
    expect(cycleAdvice(null, hard, '2026-10-26')).toEqual({ easeOffer: false, nutritionNote: null, coachNote: null, phase: null, dayInCycle: null, predicted: false })
    expect(cycleAdvice(at(2), null, '2026-10-26').easeOffer).toBe(false)
  })
})

describe('v3.52 Garmin — klient strežnika', () => {
  afterEach(() => vi.unstubAllGlobals())
  const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } })
  it('nosi Firebase žeton, bere items/now; napake po kodi strežnika so slovenske in razvrščene', async () => {
    const C = await import('../src/domain/garmin/client')
    const calls: { url: string; auth: string | null }[] = []
    vi.stubGlobal('fetch', vi.fn(async (url: string, init?: RequestInit) => {
      calls.push({ url, auth: (init?.headers as Record<string, string>)?.Authorization ?? null })
      if (url.includes('/garmin/activities')) return json({ items: [{ summaryId: 'a' }, null, 'x'], now: 123 })
      if (url.includes('/garmin/health')) return json({ dailies: [{ summaryId: 'd' }], stressDetails: [{ summaryId: 's' }], now: 5 })
      if (url.includes('/garmin/cycle')) return json({ mct: [{ calendarDate: '2026-10-26' }], now: 7 })
      if (url.includes('/garmin/status')) return json({ connected: true, userId: 42, permissions: ['ACTIVITY_EXPORT'], connectedAt: 1793000400000, lastPushAt: null })
      if (url.includes('/garmin/disconnect')) return json({ error: 'ni_povezave' }, 409)
      return json({ error: 'napaka' }, 500)
    }))
    // (popravki V6) odgovor nosi tudi more (paginacija); brez now → null (nikoli Date.now())
    expect(await C.fetchGarminActivities(100)).toEqual({ items: [{ summaryId: 'a' }], now: 123, more: false })
    expect(calls[0]!.url).toBe(`${(await import('../src/config')).PROXY}/garmin/activities?since=100`); expect(calls[0]!.auth).toBe('Bearer tok')
    const h = await C.fetchGarminHealth(0)
    expect(h.dailies).toEqual([{ summaryId: 'd' }]); expect(h.stress).toEqual([{ summaryId: 's' }]); expect(h.now).toBe(5)
    expect(await C.fetchGarminCycle(0)).toEqual({ mct: [{ calendarDate: '2026-10-26' }], now: 7, more: false })
    expect(await C.fetchGarminStatus()).toEqual({ connected: true, userId: '42', permissions: ['ACTIVITY_EXPORT'], connectedAt: '2026-10-26T07:40:00.000Z', lastPushAt: null })
    await expect(C.garminDisconnect()).resolves.toBeUndefined()   // 409 = že odklopljen → uspeh
    expect(C.garminErrOf(401, 'prijava_potrebna')).toMatchObject({ kind: 'auth' })
    expect(C.garminErrOf(409, 'ni_povezave')).toMatchObject({ kind: 'none', message: 'Garmin ni povezan — poveži ga znova.' })
    expect(C.garminErrOf(503, 'garmin_ni_nastavljen')).toMatchObject({ kind: 'off' })
    expect(C.garminErrOf(502, 'garmin_429').message).toMatch(/preveč zahtevkov/)
    expect(C.garminErrOf(502, 'garmin_401').message).toMatch(/poveži znova/)
    expect(C.garminErrOf(502, 'garmin_500').message).toBe('Garmin je vrnil napako (500).')
    expect(C.garminErrOf(500, 'napaka')).toMatchObject({ kind: 'network' })
    expect(C.garminErrMsg(new TypeError('Failed to fetch'))).toBe('Strežnik ni dosegljiv — preveri povezavo.')
    expect(C.garminAuthUrl('a b')).toMatch(/\/garmin\/auth\?t=a%20b$/)
  })
  it('garminLive bere /health → garmin; ob napaki false', async () => {
    const C = await import('../src/domain/garmin/client')
    C.resetGarminProbe()
    vi.stubGlobal('fetch', vi.fn(async () => json({ ok: true, icu: true, garmin: true })))
    expect(await C.garminLive()).toBe(true); expect(C.garminOn()).toBe(true)
    C.resetGarminProbe()
    vi.stubGlobal('fetch', vi.fn(async () => { throw new Error('x') }))
    expect(await C.garminLive()).toBe(false); expect(C.garminOn()).toBe(false)
  })
})
