import { describe, it, expect } from 'vitest'
import type { Profile } from '../src/domain/types'
import { normalizeFocus } from '../src/domain/focus/model'
import { scheduleWeek, buildFocusWeek } from '../src/domain/training/focusPlan'
import { composeWish, splitWish, visibleGroups, CHOICE_GROUPS, daysLine, atDays } from '../src/domain/focus/choices'
import { daysIn, offDaysIn, ruleQuestions, ruleProposal, ruleAdjust, wishSignals } from '../src/domain/focus/rules'
import { parseProposal, parseQuestions, proposalPrompt, focusContext } from '../src/domain/ai/focusAi'

const NOW = '2026-10-07T08:00:00.000Z'
const base: Profile = { sex: 'z', age: 29, heightCm: 168, weightKg: 64, gear: { bikeOutdoor: false, trainer: false, noBike: true }, strength: { on: false, equipment: 'none' }, onboardingDone: true, createdAt: NOW, updatedAt: NOW }
const sessions = [
  { type: 'fitnes', part: 'potisk', min: 55 }, { type: 'tek', cardio: 'intervali', min: 35 }, { type: 'fitnes', part: 'poteg', min: 55 },
  { type: 'tek', cardio: 'lahko', min: 40 }, { type: 'fitnes', part: 'noge', min: 50 },
]
const mk = (off: number[] | null, level = 2) => normalizeFocus({ wish: 'x', sports: ['fitnes', 'tek'], aims: ['moc'], level, equipment: ['fitnes'], sessions, offDays: off }, { age: 29, now: NOW, by: 'ai' })!

describe('izbire v 1. koraku (kot pri Claudu)', () => {
  it('izbire → želja in nazaj; svoje besede ostanejo; vrstni red po skupinah', () => {
    const picks = { delam: ['Tek', 'Fitnes'], postava: ['Six pack', 'Vitka in močna', 'Ne izgubiti mišic'], raven: ['Redno, več let'] }
    const w = composeWish(picks, ' Ob torkih nimam časa. ')
    expect(w).toBe('Rad delam: fitnes, tek. Izkušnje: redno, več let. Postava: vitka in močna, six pack, ne izgubiti mišic. Ob torkih nimam časa.')
    const back = splitWish(w)
    expect(back.text).toBe('Ob torkih nimam časa.')
    expect(back.picks).toEqual({ delam: ['Fitnes', 'Tek'], raven: ['Redno, več let'], postava: ['Vitka in močna', 'Six pack', 'Ne izgubiti mišic'] })
    expect(composeWish({}, '')).toBe('')
    expect(splitWish('Hočem six pack.')).toEqual({ picks: {}, text: 'Hočem six pack.' })
  })
  it('skupine se prilagodijo: kolesar ne vidi postave, fitnes ne vidi kolesa; skrite izbire ne gredo v željo', () => {
    expect(visibleGroups({}).map(g => g.id)).toEqual(['cilj', 'delam', 'raven'])
    expect(visibleGroups({ delam: ['Kolo'] }).map(g => g.id)).toEqual(['cilj', 'delam', 'raven', 'kolo'])
    expect(visibleGroups({ delam: ['Fitnes'] }).map(g => g.id)).toEqual(['cilj', 'delam', 'raven', 'postava'])
    expect(visibleGroups({ cilj: ['Več mišic in moči'], delam: ['Tek'] }).map(g => g.id)).toEqual(['cilj', 'delam', 'raven', 'postava', 'tek'])
    expect(composeWish({ delam: ['Kolo'], postava: ['Six pack'] }, '')).toBe('Rad delam: kolo.')
  })
  it('stare izbire (pred 13. 10.) se prevedejo v nove; česar ni, ostane v besedilu', () => {
    const old = splitWish('Postava: vitka in močna, manj maščobe. Rad delam: fitnes, doma, brez opreme, hribi. Še: ful kondicije, hitrejši na kolesu, samo zgornji del. Ob torkih ne.')
    expect(old.picks.cilj).toEqual(['Manj kilogramov', 'Boljša kondicija', 'Hitrejši in vzdržljivejši'])
    expect(old.picks.delam).toEqual(['Hribi in hoja', 'Vadba doma', 'Fitnes', 'Kolo'])
    expect(old.picks.postava).toEqual(['Vitka in močna', 'Samo zgornji del'])
    expect(old.text).toBe('Ob torkih ne.')
  })
  it('izbire razumejo tudi pravila brez AI (cilj, šport, postava)', () => {
    const all = Object.fromEntries(CHOICE_GROUPS.map(g => [g.id, [...g.opts]]))
    const s = wishSignals(composeWish(all, ''))
    expect(s.aims).toEqual(expect.arrayContaining(['definicija', 'moc', 'misice', 'hujsanje', 'kondicija', 'zdravje', 'vzdrzljivost', 'tekma']))
    expect(s.sports).toEqual(expect.arrayContaining(['fitnes', 'tek', 'kolo', 'hribi', 'doma']))
    expect(s.muscles).toContain('trebuh')
    expect(s.keepMuscle).toBe(true)
    expect(s.upperOnly).toBe(true)
    // kolesar s tekmo: ni teka; trenažer doma ni vadba doma; trail ni pohod
    const bike = wishSignals('Cilj: pripravljen na tekmo. Rad delam: kolo. Kolo: trenažer doma.')
    expect(bike.sports).toEqual(['kolo'])
    expect(bike.aims).toContain('tekma')
    expect(wishSignals('Rad delam: tek. Tek: po hribih (trail).').sports).toEqual(['tek'])
    expect(wishSignals('Postava: vitka in močna. Zgornji del naj bo močnejši.').upperOnly).toBe(false)
  })
})

describe('dnevi brez časa: iz besed', () => {
  it('izbira (okrajšave) in cele besede; »torej«, »pet dni«, »petkrat«, »četrt ure«, »sredi tedna« niso dnevi', () => {
    expect(daysIn('Tor, Čet', true)).toEqual([1, 3])
    expect(daysIn('pon, sre, ned', true)).toEqual([0, 2, 6])
    expect(daysIn('Vsi gredo', true)).toEqual([])
    expect(daysIn('ob torkih in četrtkih')).toEqual([1, 3])
    expect(daysIn('v ponedeljek, sredo in soboto')).toEqual([0, 2, 5])
    expect(daysIn('čez vikend')).toEqual([5, 6])
    expect(daysIn('torej pet dni, petkrat na teden, četrt ure, sredi tedna')).toEqual([])
    expect(daysIn('pet dni')).toEqual([])
    expect(daysIn('pet dni', true)).toEqual([4])   // v izbiri je »Pet« petek
  })
  it('»ne gre« velja za dan, ki mu je bližje kot »lahko«', () => {
    expect(offDaysIn('Ob torkih ne morem, ob petkih pa lahko.')).toEqual([1])
    expect(offDaysIn('Ob petkih pa ne morem.')).toEqual([4])
    expect(offDaysIn('V ponedeljek lahko, v sredo nimam časa.')).toEqual([2])
    expect(offDaysIn('Ob vikendih nisem doma.')).toEqual([5, 6])
    expect(offDaysIn('Hodim v fitnes ob torkih.')).toEqual([])
    expect(offDaysIn('Ne morem teči. Ob sobotah grem v hribe.')).toEqual([])
  })
})

describe('dnevi brez časa: dogovor in teden', () => {
  it('dogovor: največ toliko vadb, kolikor je dni; želeni dnevi brez dni »ne gre«; neveljavno izpade', () => {
    expect(mk([1, 3]).sessions).toHaveLength(5)
    expect(mk([0, 1, 3]).sessions).toHaveLength(4)
    expect(mk([0, 1, 2, 3, 4, 5, 6]).offDays).toHaveLength(6)   // vsaj en dan ostane
    expect(mk([0, 1, 2, 3, 4, 5, 6]).sessions).toHaveLength(1)
    expect(mk([9, -1, 2.5, 3, 3] as number[]).offDays).toEqual([3])
    expect(mk([]).offDays).toBeNull()
    const f = normalizeFocus({ sessions, sports: ['fitnes', 'tek'], level: 2, offDays: [1], preferDays: [1, 2, 4], strategy: '– Teden:  3× moč\n\n– Prehrana: beljakovine' }, { age: 29 })!
    expect(f.preferDays).toEqual([2, 4])
    expect(f.strategy).toBe('– Teden: 3× moč\n– Prehrana: beljakovine')   // vrstice strategije ostanejo
  })
  it('razpored: cel teden — ob dnevih brez časa ni vadbe, vse vadbe dobijo dan; brez dni »ne gre« ostane prost dan', () => {
    const f = mk([1, 3])
    const open = [0, 2, 4, 5, 6]
    const o = scheduleWeek(f.sessions, open, null, 7)
    expect(o[1]).toBeNull()
    expect(o[3]).toBeNull()
    expect(o.filter(x => x != null)).toHaveLength(5)
    const all = scheduleWeek(f.sessions, [0, 1, 2, 3, 4, 5, 6], null, 7)
    expect(all.filter(x => x == null).length).toBeGreaterThanOrEqual(2)
  })
  it('teden v načrtu: dan brez časa je počitek z razlago; vse vadbe so na drugih dneh', () => {
    const p: Profile = { ...base, focus: mk([1, 3]), cycleStart: '2026-10-05' }
    const wk = buildFocusWeek({ profile: p, activities: [], weekStart: '2026-10-12', notBefore: '2026-10-12' })
    expect(wk).toHaveLength(7)
    expect(wk[1]!.kind).toBe('pocitek')
    expect(wk[1]!.desc).toContain('nimaš časa')
    expect(wk[3]!.kind).toBe('pocitek')
    expect(wk.filter(d => d.kind !== 'pocitek')).toHaveLength(5)
  })
})

describe('dnevi brez časa: AI in pravila', () => {
  it('AI: »neGre« → dnevi; brez njega ali s praznim seznamom ostanejo prejšnji (popravek); poziv pozna dneve', () => {
    const raw = { odgovor: 'Ok.', sporti: ['fitnes', 'tek'], raven: 2, seje: sessions.map(s => ({ vrsta: s.type, del: s.part, kardio: s.cardio, min: s.min })) }
    expect(parseProposal({ ...raw, neGre: [1, 3] }, { wish: 'x' })!.focus.offDays).toEqual([1, 3])
    expect(parseProposal(raw, { wish: 'x', prevOff: [4] })!.focus.offDays).toEqual([4])
    expect(parseProposal({ ...raw, neGre: [] }, { wish: 'x', prevOff: [4] })!.focus.offDays).toEqual([4])   // AI izpusti → ostane; sprosti ga uporabnik z besedami
    expect(parseProposal({ ...raw, neGre: [2] }, { wish: 'x', prevOff: [4] })!.focus.offDays).toEqual([2, 4])
    const t = (proposalPrompt({ wish: 'x', basics: {}, qa: [], prev: mk([1, 3]), feedback: 'Več teka' })[0] as { text: string }).text
    expect(t).toContain('ne gre (neGre): tor, čet = [1, 3]')
    expect(daysLine([3, 1])).toBe('tor, čet')
    expect(focusContext({ focus: mk([1, 3]) })).toContain('Dnevi, ko nima časa (tja ne premikaj vadbe): tor, čet.')
    expect(focusContext({ focus: mk(null) })).not.toContain('nima časa')
    expect(atDays([6, 0, 2])).toBe('ob ponedeljkih, sredah in nedeljah')
    expect(atDays([4])).toBe('ob petkih')
  })
  it('AI vprašanje o dnevih obdrži vseh 7 dni in »vsi gredo«', () => {
    const q = parseQuestions({ vprasanja: [{ id: 'dnevi', vprasanje: 'Kateri dnevi ti ne gredo?', vec: true, moznosti: ['pon', 'tor', 'sre', 'čet', 'pet', 'sob', 'ned', 'vsi gredo'] }] })!
    expect(q.questions[0]!.options).toHaveLength(8)
  })
  it('vprašalnik brez AI: vprašanje »ne gre«, predlog brez vadb ob teh dneh; pogajanje »ob torkih ne morem« in nazaj', () => {
    const q = ruleQuestions('Fitnes in tek')
    expect(q.questions.find(x => x.id === 'nedni')!.options).toHaveLength(8)
    const qa = [{ id: 'dni', q: 'dni', a: '4' }, { id: 'cas', q: 'cas', a: '60 min' }, { id: 'kje', q: 'kje', a: 'V fitnesu' }, { id: 'kardio', q: 'kardio', a: 'Tek' }, { id: 'nedni', q: 'nedni', a: 'Tor, Čet' }]
    const p = ruleProposal('Rad delam: fitnes, tek.', qa, 29)
    expect(p.focus.offDays).toEqual([1, 3])
    expect(p.reply).toContain('Ob torkih in četrtkih ni vadbe.')
    expect(ruleProposal('Ob petkih pa ne morem.', [], 29).focus.offDays).toEqual([4])
    const a = ruleAdjust(p.focus, 'Ob sobotah tudi ne morem.', 29)!
    expect(a.offDays).toEqual([1, 3, 5])
    const b = ruleAdjust(a, 'Ob torkih pa lahko.', 29)!
    expect(b.offDays).toEqual([3, 5])
    expect(b.sessions).toHaveLength(p.focus.sessions.length)
  })
})
