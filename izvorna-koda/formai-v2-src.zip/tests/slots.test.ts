import { describe, it, expect } from 'vitest'
import { slotAt, timeForSlot, byTime, photoTime, SLOT_ACC } from '../src/domain/nutrition/slots'

describe('obrok po uri', () => {
  it('samodejno po času', () => {
    expect(['06:30', '09:59', '10:00', '12:00', '14:59', '15:30', '17:00', '19:46', '21:30', '02:00'].map(slotAt))
      .toEqual(['zajtrk', 'zajtrk', 'malica', 'kosilo', 'kosilo', 'malica', 'vecerja', 'vecerja', 'drugo', 'drugo'])
  })
  it('zajtrk izbran popoldne = vpis za nazaj → 7:30; isti obrok kot zdaj → zdaj', () => {
    expect(timeForSlot('zajtrk', '16:20')).toBe('07:30')
    expect(timeForSlot('kosilo', '19:46')).toBe('13:00')
    expect(timeForSlot('malica', '19:46')).toBe('16:00')
    expect(timeForSlot('malica', '13:10')).toBe('10:30')
    expect(timeForSlot('vecerja', '19:46')).toBe('19:46')
    expect(timeForSlot('drugo', '19:46')).toBe('19:46')
  })
  it('seznam dneva po uri, vpis brez ure na tipično uro obroka', () => {
    const e = (slot: 'zajtrk' | 'kosilo' | 'vecerja' | 'med_vadbo' | 'malica' | 'drugo', time: string | null, createdAt = '2026-09-24T10:00:00Z') => ({ slot, time, createdAt })
    const list = [e('vecerja', '19:00'), e('med_vadbo', '15:43'), e('zajtrk', null), e('kosilo', '12:00'), e('drugo', '17:00')].sort(byTime)
    expect(list.map(x => x.slot)).toEqual(['zajtrk', 'kosilo', 'med_vadbo', 'drugo', 'vecerja'])
  })
  it('»Dodaj …« v tožilniku', () => {
    expect(SLOT_ACC.vecerja).toBe('večerjo'); expect(SLOT_ACC.malica).toBe('malico'); expect(SLOT_ACC.zajtrk).toBe('zajtrk')
  })
})

describe('ura slike obroka', () => {
  const now = new Date(2026, 8, 24, 19, 46)
  it('EXIF istega dne → ura posnetka; drug dan → ne', () => {
    expect(photoTime('2026-09-24', '2026-09-24', { date: '2026-09-24', time: '12:07' }, null, now)).toBe('12:07')
    expect(photoTime('2026-09-24', '2026-09-24', { date: '2026-09-23', time: '12:07' }, null, now)).toBe('19:46')
  })
  it('slika iz galerije brez EXIF → čas datoteke, če je starejša od 5 min; sveža slika s kamero → zdaj', () => {
    expect(photoTime('2026-09-24', '2026-09-24', null, new Date(2026, 8, 24, 14, 5).getTime(), now)).toBe('14:05')
    expect(photoTime('2026-09-24', '2026-09-24', null, new Date(2026, 8, 24, 19, 44).getTime(), now)).toBe('19:46')
    expect(photoTime('2026-09-23', '2026-09-24', null, null, now)).toBeNull()
  })
})
