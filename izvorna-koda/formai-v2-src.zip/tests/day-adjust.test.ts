import { describe, it, expect } from 'vitest'
import { dayMealPlan, adjustToEaten } from '../src/domain/nutrition/dayplan'
import { targetParts, type DailyTarget } from '../src/domain/nutrition/energy'
import type { MealEntry, PlanDay } from '../src/domain/types'

const now = new Date().toISOString()
const ride: PlanDay = { id: 'd', date: '2026-09-24', kind: 'kolo', title: 'Sweet spot 3 × 12 min', desc: '', durationMin: 90, zone: 'Z3', role: 'kljucna', source: 'rules', createdAt: now, updatedAt: now }
const meal = (slot: MealEntry['slot'], kcal: number, id = slot + kcal): MealEntry => ({ id, date: '2026-09-24', slot, name: slot, kcal, source: 'manual', createdAt: now })
const P = { weightKg: 79, trainTime: 'popoldne' as const, fuelKit: ['iso_domaci', 'frutabela', 'gel'] }

describe('čez dan: preostali obroki se prilagodijo pojedenemu', () => {
  const tgt = { kcal: 3300, proteinG: 158, carbsG: 450 }
  const dp = dayMealPlan(P, tgt, ride, { tempC: 17 })
  it('nič pojedeno → načrt ostane', () => {
    const a = adjustToEaten(dp, [], 3300)
    expect(a.adjusted).toBeFalsy()
    expect(a.slots.map(x => x.kcal)).toEqual(dp.slots.map(x => x.kcal))
  })
  it('manjši zajtrk in kosilo → večerja in zvečer večja (največ 1,35 ×), manjkajoče pove', () => {
    const z = dp.slots.find(x => x.key === 'zajtrk')!, k = dp.slots.find(x => x.key === 'kosilo')!
    const a = adjustToEaten(dp, [meal('zajtrk', Math.round(z.kcal * 0.5)), meal('kosilo', Math.round(k.kcal * 0.5))], 3300)
    expect(a.adjusted).toBe(true)
    const o = a.slots.find(x => x.key === 'obnova')!, o0 = dp.slots.find(x => x.key === 'obnova')!
    expect(o.kcal).toBeGreaterThan(o0.kcal); expect(o.kcal).toBeLessThanOrEqual(Math.round(o0.kcal * 1.35 / 10) * 10 + 10)
    expect(a.slots.find(x => x.key === 'zajtrk')!.got).toBe(Math.round(z.kcal * 0.5))
    expect(a.short).toBeGreaterThan(0)
  })
  it('na kolesu popil manj od načrta → za obroke ostane več; velik zajtrk → ostali manjši', () => {
    const planBike = dp.onBike!.kcal
    const less = adjustToEaten(dp, [meal('med_vadbo', Math.round(planBike / 2)), meal('zajtrk', dp.slots[0]!.kcal)], 3300)
    const all = adjustToEaten(dp, [meal('med_vadbo', planBike), meal('zajtrk', dp.slots[0]!.kcal)], 3300)
    const dinner = (x: typeof less) => x.slots.find(s => s.key === 'obnova')!.kcal
    expect(dinner(less)).toBeGreaterThan(dinner(all))
    const big = adjustToEaten(dp, [meal('zajtrk', dp.slots[0]!.kcal + 600)], 3300)
    expect(dinner(big)).toBeLessThan(dp.slots.find(s => s.key === 'obnova')!.kcal)
  })
})

describe('razčlenitev cilja', () => {
  const t = (o: Partial<DailyTarget>): DailyTarget => ({ kcal: 3300, maintenance: 2541, burn: 0, plannedBurn: 0, plannedWas: 0, floor: 1815, proteinG: 158, carbsG: 450, fatG: 90, clampedToFloor: false, minor: false, deficit: 200, deficitNote: null, ...o })
  it('pred vožnjo po načrtu, po vožnji izmerjeno z razliko', () => {
    expect(targetParts(t({ plannedBurn: 1010 }), {})).toBe('osnova 2\u202F541 − deficit 200 + trening ~1\u202F010 po načrtu — popravim, ko vožnja pride z Garmina')
    expect(targetParts(t({ burn: 1230, plannedWas: 1010 }), {})).toBe('osnova 2\u202F541 − deficit 200 + trening 1\u202F230 izmerjeno (načrt 1\u202F010, +220)')
  })
})
