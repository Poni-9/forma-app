import { describe, it, expect } from 'vitest'
import { raceLock, raceDates, LOAD_RACE_MIN } from '../src/domain/training/protect'
import { CARB_LOAD_MIN } from '../src/domain/nutrition/energy'
import { readState, adaptToState } from '../src/domain/training/state'
import { moveTarget } from '../src/domain/training/missed'
import { moveKeyPlan } from '../src/domain/training/review'
import { easeDay, adaptAfterLoad } from '../src/domain/training/planner'
import { canMove, moveTargets } from '../src/domain/training/swap'
import type { DailyCheckin, PlanDay, Profile } from '../src/domain/types'

const NOW = '2026-10-03T08:00:00.000Z'
// tekma v ponedeljek naslednjega tedna — v tem tednu je ni v načrtu, je samo v profilu
const RACE = '2026-10-12'
const p = {
  sex: 'm', age: 30, weightKg: 75, heightCm: 180, ftp: 250, hoursPerWeek: 8, onboardingDone: true, createdAt: NOW, updatedAt: NOW,
  races: [{ id: 'r1', name: 'Kronometer Kranj', date: RACE, type: 'cestna', km: 120, elevM: 900, prio: 'B' }],
} as unknown as Profile
const day = (id: string, date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id, date, kind: 'kolo', title: 'Z2 vzdržljivost', desc: 'Enakomerno.', durationMin: 90, zone: 'Z2', tssTarget: 60, role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })
const ck = (o: Partial<DailyCheckin>, date: string): DailyCheckin => ({ date, ...o })
// teden 5.–11. 10.: sob dolga, ned predaktivacija (vloga »lahka« — prej jo je premik lahko vzel)
const week = [
  day('mon', '2026-10-05', { kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, tssTarget: 0, role: null }),
  day('tue', '2026-10-06', { title: 'VO2max 5 × 4 min', zone: 'Z5', role: 'kljucna' }),
  day('wed', '2026-10-07', { title: 'Z2', durationMin: 60 }),
  day('thu', '2026-10-08', { title: 'Prag 2 × 12 min', zone: 'Z4', role: 'kljucna' }),
  day('fri', '2026-10-09', { kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, tssTarget: 0, role: null }),
  day('sat', '2026-10-10', { title: 'Dolga Z2', role: 'dolga', durationMin: 180, tssTarget: 130 }),
  day('sun', '2026-10-11', { title: 'Predaktivacija 3 × 1 min', zone: 'Z5', durationMin: 40, tssTarget: 29 }),
]

describe('zaščita tekem pri premikih', () => {
  it('tekma iz profila: dan tekme in dan prej sta zaklenjena, tudi ko tekme ni v načrtu', () => {
    const lock = raceLock(week, p)
    expect(raceDates(week, p).has(RACE)).toBe(true)
    expect(lock.why(RACE)).toBe('dan tekme')
    expect(lock.why('2026-10-11')).toBe('dan pred tekmo')
    expect(lock.has('2026-10-09')).toBe(false)
    expect(lock.afterRace('2026-10-13')).toBe(true)
    // brez profila (samo načrt) tekme ni — prav to je bila napaka
    expect(raceLock(week).has('2026-10-11')).toBe(false)
  })
  it('polnjenje z OH 2 dni pred dolgo tekmo je zaklenjeno, pred kratko ne', () => {
    expect(LOAD_RACE_MIN).toBe(CARB_LOAD_MIN)
    const long = { ...p, races: [{ id: 'r2', name: 'Maraton', date: RACE, type: 'maraton', km: 160, elevM: 2500, prio: 'B' }] } as unknown as Profile
    expect(raceLock(week, long).why('2026-10-10')).toBe('polnjenje z OH pred tekmo')
    const short = { ...p, races: [{ id: 'r3', name: 'Kronometer', date: RACE, type: 'kronometer', km: 20, elevM: 50, prio: 'C' }] } as unknown as Profile
    expect(raceLock(week, short).has('2026-10-10')).toBe(false)
  })
  it('slabo jutro dva dni zapored v soboto: dolga vožnja ne gre na nedeljo (predaktivacija pred ponedeljkovo tekmo)', () => {
    const st = readState({ checkin: ck({ mood: 2 }, '2026-10-10'), yesterday: ck({ mood: 2 }, '2026-10-09') })
    expect(st.level).toBe(2); expect(st.legs).toBe(false)
    // brez tekme v profilu bi šla dolga na nedeljo (prej se je zgodilo tudi s tekmo)
    const noRace = adaptToState({ ...p, races: [] } as Profile, week, '2026-10-10', st, { now: NOW })!
    expect(noRace.days.find(d => d.date === '2026-10-11')?.title).toBe('Dolga Z2')
    const r = adaptToState(p, week, '2026-10-10', st, { now: NOW })!
    expect(r.days.find(d => d.date === '2026-10-11')).toBeUndefined()
    expect(r.lines.join(' ')).toMatch(/ta teden odpade/)
  })
  it('na dnu v petek: sobotna dolga ne gre na nedeljo', () => {
    const st = readState({ checkin: ck({ mood: 1 }, '2026-10-09') })
    const r = adaptToState(p, week, '2026-10-09', st, { now: NOW })
    expect(r?.days.some(d => d.date === '2026-10-11')).toBeFalsy()
  })
  it('zamujen ključni: ne na dan pred tekmo iz profila', () => {
    const w = week.map(d => d.id === 'sat' ? { ...d, title: 'Z2', role: 'lahka' as const, durationMin: 90 } : d)
    const missed = w.find(d => d.id === 'thu')!
    // brez profila bi šel na nedeljo (lahek dan kolesa, brez trdega dne ob njem)
    expect(moveTarget(w, missed, '2026-10-09')?.date).toBe('2026-10-10')
    const withRace = moveTarget(w, missed, '2026-10-09', raceLock(w, p))
    expect(withRace?.date === '2026-10-11').toBe(false)
  })
  it('moveKeyPlan in easeDay ne izbereta dneva pred tekmo; po pretežki vožnji tudi ne', () => {
    const key = week.find(d => d.id === 'thu')!
    const mk = moveKeyPlan(week, key, '2026-10-08', raceLock(week, p))
    expect(mk.days?.some(d => d.date === '2026-10-11') ?? false).toBe(false)
    const w2 = week.map(d => d.id === 'sun' ? { ...d, kind: 'pocitek' as const, title: 'Počitek', durationMin: 0, zone: null, tssTarget: 0, role: null } : d)
    const out = easeDay(w2, '2026-10-10', raceLock(w2, p))
    expect(out?.some(d => d.date === '2026-10-11' && d.kind !== 'pocitek') ?? false).toBe(false)
    const acts = [{ id: 'a', source: 'manual', sport: 'kolo', date: '2026-10-09', name: 'x', durationMin: 240, tss: 260, aiEligible: true, geoRetain: true, createdAt: NOW, updatedAt: NOW }]
    const w3 = week.map(d => d.id === 'fri' ? { ...d, kind: 'kolo' as const, title: 'Regeneracija', zone: 'Z1', role: 'regen' as const, durationMin: 45, tssTarget: 20 } : d)
    const la = adaptAfterLoad(p, w3, acts as never, '2026-10-09', '2026-10-09')
    expect(la?.days.some(d => d.date === '2026-10-11' && d.role === 'dolga') ?? false).toBe(false)
  })
  it('ročni premik: dan pred tekmo ni na izbiro in predaktivacije ni mogoče premakniti', () => {
    const lock = raceLock(week, p)
    const sat = week.find(d => d.id === 'sat')!
    expect(moveTargets(week, sat, '2026-10-05', '2026-10-18', lock).map(t => t.date)).not.toContain('2026-10-11')
    expect(canMove(week.find(d => d.id === 'sun')!, '2026-10-05', lock)).toBe(false)
    expect(lock.why('2026-10-10')).toBe('polnjenje z OH pred tekmo')   // 120 km tekma ≥ 150 min: sobota je polnjenje
    expect(canMove(week.find(d => d.id === 'wed')!, '2026-10-05', lock)).toBe(true)
  })
})
