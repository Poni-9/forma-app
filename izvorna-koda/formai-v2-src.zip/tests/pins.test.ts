import { describe, it, expect } from 'vitest'
import type { Profile, Focus } from '../src/domain/types'
import { normalizeFocus, tailsOf, trainingDays, weekLine } from '../src/domain/focus/model'
import { scheduleWeek, buildFocusWeek, weekWords, pinsWords } from '../src/domain/training/focusPlan'
import { pinsIn, notOnIn, offDaysIn, daysIn, restSportsIn, mentionsDays, applyDayWords, ruleProposal, ruleAdjust, daysReply, movesIn, keepDayStructure } from '../src/domain/focus/rules'
import { parseProposal, proposalPrompt, focusContext } from '../src/domain/ai/focusAi'
import { stepsFor } from '../src/domain/training/workout'

const NOW = '2026-10-07T08:00:00.000Z'
const base: Profile = { sex: 'z', age: 29, heightCm: 168, weightKg: 64, gear: { bikeOutdoor: false, trainer: false, noBike: true }, strength: { on: false, equipment: 'none' }, onboardingDone: true, createdAt: NOW, updatedAt: NOW }
const WISH = 'torek in petek fitnes, tek v istem dnevu, ostalo pa dej kolo al pa vadba doma'
const BLAZ = 'pondelk naj ne bo nc, torek petek fitnes s tekom vmes, pa nedelja kolo, ostalo po izbiri...'
const types = (f: Focus, d: number[]) => d.map(k => f.sessions[k]!.type)

describe('besede o dnevih', () => {
  it('dnevi v pogovornem jeziku; okrajšave; »pet« samo ob drugem dnevu', () => {
    expect(daysIn('pondelk naj ne bo nc, torek petek')).toEqual([0, 1, 4])
    expect(daysIn('tork in četrk, sobta')).toEqual([1, 3, 5])
    expect(daysIn('tor, pet')).toEqual([1, 4])
    expect(daysIn('pet dni na teden, pon in sre')).toEqual([0, 2])
    expect(daysIn('sredi tedna, torej pet krat')).toEqual([])
  })
  it('določene vadbe: fitnes + tek isti dan, kolo v nedeljo, trajanje in vrsta kardia', () => {
    const p = pinsIn(WISH)
    expect(p.filter(x => x.type === 'fitnes').map(x => x.day)).toEqual([1, 4])
    expect(p.filter(x => x.type === 'tek').map(x => [x.day, x.after])).toEqual([[1, true], [4, true]])
    expect(p.some(x => x.type === 'kolo' || x.type === 'doma')).toBe(false)   // »ostalo …« ni določen dan
    const b = pinsIn(BLAZ)
    expect(b.map(x => `${x.type}${x.day}`).sort()).toEqual(['fitnes1', 'fitnes4', 'kolo6', 'tek1', 'tek4'])
    expect(pinsIn('Hočem six pack.')).toEqual([])
    expect(pinsIn('ob sobotah dolg tek 90 min')[0]).toMatchObject({ type: 'tek', day: 5, min: 90, cardio: 'dolgo' })
    expect(pinsIn('fitnes v ponedeljek in četrtek, tek pa po fitnesu').filter(x => x.type === 'tek').map(x => [x.day, x.after])).toEqual([[0, true], [3, true]])
    expect(pinsIn('v nedeljo grem na kolo z družino')).toEqual([{ type: 'kolo', day: 6, min: null, cardio: 'lahko', after: false, only: false, add: false, instead: [] }])
    expect(pinsIn('fitnes v torek, četrtek in soboto').map(x => x.day)).toEqual([1, 3, 5])   // vejice v naštevanju
    expect(pinsIn('fitnes od ponedeljka do srede').map(x => x.day)).toEqual([0, 1, 2])
    expect(pinsIn('v soboto pet km teka').map(x => x.day)).toEqual([5])
    expect(pinsIn('ob sredah tek namesto kolesa')).toEqual([{ type: 'tek', day: 2, min: null, cardio: 'lahko', after: false, only: false, add: false, instead: ['kolo'] }])
    // »tek po fitnesu ob torkih«: določen je le tek (fitnes je sklic), po moči
    expect(pinsIn('tek po fitnesu ob torkih').map(x => [x.type, x.day, x.after])).toEqual([['tek', 1, true]])
    expect(pinsIn('dodaj še kolo ob sobotah')[0]).toMatchObject({ type: 'kolo', day: 5, add: true })
    expect(pinsIn('ob petkih delam doma')).toEqual([])
    expect(pinsIn('tek po fitnesu', { strengthDays: [1, 4] }).map(x => [x.day, x.after])).toEqual([[1, true], [4, true]])
    expect(pinsIn('do sobote hočem shujšati')).toEqual([])
    expect(pinsIn('ob torkih ne morem v fitnes')).toEqual([])
  })
  it('kje vadbe ne dela; dnevi brez časa po delih stavka; »sem doma« ni vadba doma', () => {
    expect(notOnIn('soboto nedeljo torek in cetrtek v fitnes ne hodim').get('fitnes')).toEqual([1, 3, 5, 6])
    expect(notOnIn('ob sredah nimam časa za tek').get('tek')).toEqual([2])
    expect(offDaysIn('ob sredah nimam časa za tek')).toEqual([])
    expect(offDaysIn(BLAZ)).toEqual([0])
    expect(offDaysIn('Ob torkih ne morem, ob petkih pa lahko.')).toEqual([1])
    expect(offDaysIn('Ob vikendih nisem doma.')).toEqual([5, 6])
    expect(offDaysIn('četrtek prost, petek počitek')).toEqual([3, 4])
    expect(offDaysIn('Hodim v fitnes ob torkih.')).toEqual([])
    expect(offDaysIn('ne morem v torek, sredo in petek')).toEqual([1, 2, 4])
    expect(offDaysIn('ne gre mi v torek')).toEqual([1])
    expect(offDaysIn('ob torkih ne morem tekat')).toEqual([])
    expect(notOnIn('ob torkih ne morem tekat').get('tek')).toEqual([1])
    expect(offDaysIn('čez konec tedna nisem doma')).toEqual([5, 6])
    expect(restSportsIn(WISH)).toEqual(['doma', 'kolo'])
    expect(restSportsIn(BLAZ)).toEqual([])
    expect(mentionsDays('več kardia')).toBe(false)
    expect(mentionsDays('ob petkih ne')).toBe(true)
  })
})

describe('model: seje z dnevi', () => {
  const sess = [{ type: 'tek', cardio: 'lahko', min: 30, day: 1 }, { type: 'fitnes', part: 'zgornji', min: 60, day: 1 }, { type: 'fitnes', part: 'spodnji', min: 60, day: 4 }, { type: 'kolo', cardio: 'lahko', min: 60 }]
  it('kardio pred močjo v seznamu je še vedno isti dan po moči; dva dneva vadbe + prosta seja = 3 dni', () => {
    const f = normalizeFocus({ sessions: sess, level: 2 }, { age: 29, now: NOW })!
    expect(f.sessions.map(s => s.day ?? null)).toEqual([null, 1, 4, null])
    expect(f.sessions[0]!.after).toBe(true)
    expect([...tailsOf(f.sessions).entries()]).toEqual([[0, 1]])
    expect(trainingDays(f.sessions)).toBe(3)
    expect(f.days).toBe(3)
    expect(weekLine(f)).toMatch(/^3 dnevi/)
  })
  it('tretja seja na isti dan in dan brez časa izgubita dan; vrsta seje velja tudi brez »sporti«', () => {
    const f = normalizeFocus({ sessions: [...sess, { type: 'doma', part: 'celo', min: 30, day: 1 }], sports: ['fitnes'], offDays: [4], level: 2 }, { age: 29 })!
    expect(f.sessions.map(s => s.day ?? null)).toEqual([null, 1, null, null, null])
    expect(f.sessions.map(s => !!s.after)).toEqual([true, false, false, false, false])
    expect(f.sports).toEqual(expect.arrayContaining(['fitnes', 'tek', 'kolo', 'doma']))
  })
  it('strop dni: najprej izpadejo nedoločene seje, določene ostanejo (s svojim kardiem)', () => {
    const many = [{ type: 'fitnes', part: 'zgornji', min: 50, day: 1 }, { type: 'tek', cardio: 'lahko', min: 25, day: 1 }, { type: 'fitnes', part: 'spodnji', min: 50, day: 4 }, { type: 'kolo', min: 60 }, { type: 'doma', min: 30 }, { type: 'tek', min: 30 }, { type: 'hribi', min: 120 }, { type: 'kolo', min: 90 }]
    const f = normalizeFocus({ sessions: many, level: 1 }, { age: 29 })!   // začetnik: 5 dni
    expect(trainingDays(f.sessions)).toBe(5)
    expect(f.sessions.filter(s => s.day != null)).toHaveLength(2)
    expect(f.sessions.filter(s => s.after)).toHaveLength(1)
    expect(f.sessions.map(s => s.type)).toEqual(['fitnes', 'tek', 'fitnes', 'kolo', 'doma', 'tek'])
  })
})

describe('razpored z določenimi dnevi', () => {
  const f = normalizeFocus({ sessions: [{ type: 'fitnes', part: 'zgornji', min: 60, day: 1 }, { type: 'tek', cardio: 'lahko', min: 20, day: 1 }, { type: 'fitnes', part: 'spodnji', min: 60, day: 4 }, { type: 'tek', cardio: 'lahko', min: 20, day: 4 }, { type: 'kolo', cardio: 'lahko', min: 60, day: 6 }, { type: 'doma', part: 'celo', min: 30 }], level: 2 }, { age: 29, now: NOW })!
  it('cel teden: določene na svojem dnevu, prosta seja vmes, kardio ni posebej, vsaj en prost dan', () => {
    const o = scheduleWeek(f.sessions, [0, 1, 2, 3, 4, 5, 6], null, 7)
    expect(f.sessions[o[1]!]!.type).toBe('fitnes'); expect(f.sessions[o[4]!]!.type).toBe('fitnes'); expect(f.sessions[o[6]!]!.type).toBe('kolo')
    expect(o.filter(x => x != null)).toHaveLength(4)
    expect(o.filter(x => x != null && f.sessions[x]!.type === 'tek')).toHaveLength(0)
    expect(weekWords(f)).toMatch(/tor fitnes zgornji del \+ tek · .*pet fitnes spodnji del \+ tek · .*ned kolo/)
    expect(pinsWords(f)).toBe('Fitnes ob torkih in petkih (+ tek isti dan), kolo ob nedeljah')
  })
  it('začetek sredi tedna: določena seja, katere dan je minil, se ne seli; dan brez časa izbije določen dan', () => {
    const o = scheduleWeek(f.sessions, [3, 4, 5, 6], null, 4)   // začetek v četrtek
    expect(o[1]).toBeNull(); expect(f.sessions[o[4]!]!.type).toBe('fitnes'); expect(f.sessions[o[6]!]!.type).toBe('kolo')
    expect(o.slice(0, 3).every(x => x == null)).toBe(true)
    const g = normalizeFocus({ ...f, offDays: [1] }, { age: 29 })!
    expect(g.sessions[0]!.day).toBeNull()
    expect(scheduleWeek(g.sessions, [0, 2, 3, 4, 5, 6], null, 7)[1]).toBeNull()
  })
  it('teden v načrtu: moč + tek je ena vadba (vaje, nato kardio), trajanje skupaj, ponedeljek počitek', () => {
    const p: Profile = { ...base, focus: f, cycleStart: '2026-10-05' }
    const wk = buildFocusWeek({ profile: p, activities: [], weekStart: '2026-10-12', notBefore: '2026-10-12' })
    const tue = wk[1]!
    expect(tue.kind).toBe('moc'); expect(tue.title).toMatch(/\+ tek 20 min$/); expect(tue.tail?.kind).toBe('tek'); expect(tue.durationMin).toBe(80)
    expect(wk[6]!.kind).toBe('kolo')
    expect(wk.filter(d => d.kind !== 'pocitek')).toHaveLength(4)
    const steps = stepsFor(tue, p)
    expect(steps.some(s => s.kind === 'vaja')).toBe(true)
    const tail = steps.findIndex(s => s.label === 'Po moči na kardio')
    expect(tail).toBeGreaterThan(0)
    const after = steps.slice(tail + 1, -1)
    expect(after.reduce((a, s) => a + s.sec, 0)).toBe(20 * 60)   // kardio traja, kolikor je dogovorjeno (brez ogrevanja)
    expect(after.some(s => s.kind === 'delo' && s.sec >= 14 * 60)).toBe(true)
    expect(steps[steps.length - 1]!.label).toBe('Raztezanje')
    expect(steps.slice(tail).every(s => s.kind !== 'ogrevanje')).toBe(true)
  })
})

describe('besede o dnevih na dogovor (brez AI in za AI)', () => {
  it('predlog brez AI iz Blaževih besed: pon prosto, fitnes + tek tor in pet, kolo ned; odgovor pove teden', () => {
    const r = ruleProposal(BLAZ, [], 29)
    const f = r.focus
    expect(f.offDays).toEqual([0])
    expect(f.sessions.filter(s => s.type === 'fitnes').map(s => s.day)).toEqual([1, 4])
    expect(f.sessions.filter(s => s.type === 'tek').map(s => s.after)).toEqual([true, true])
    expect(f.sessions.find(s => s.type === 'kolo')!.day).toBe(6)
    const o = scheduleWeek(f.sessions, [1, 2, 3, 4, 5, 6], null, 7)
    expect(types(f, o.filter((x): x is number => x != null))).toEqual(['fitnes', 'fitnes', 'kolo'])
    expect(r.reply).toContain('Fitnes ob torkih in petkih (+ tek isti dan), kolo ob nedeljah.')
    expect(r.reply).toContain('Ob ponedeljkih ni vadbe.')
    expect(r.reply).toMatch(/Teden: tor fitnes/)
  })
  it('»ostalo kolo ali vadba doma«: preostale seje so te vadbe', () => {
    const f = ruleProposal(WISH, [], 29).focus
    expect(f.sessions.filter(s => s.day == null && !s.after).map(s => s.type).sort()).toEqual(['doma', 'kolo'])
    expect(trainingDays(f.sessions)).toBe(4)
  })
  it('kardio: »kolo ob sobotah« premakne določeno kolo (ne podvoji), »dodaj še« doda; »tek namesto kolesa« kolo izbriše; »samo« izbriše tudi tek po moči', () => {
    const f = ruleProposal(BLAZ, [], 29).focus   // fitnes+tek tor, pet; kolo ned
    const a = applyDayWords(f, 'kolo ob sobotah', 29)!
    expect(a.sessions.filter(s => s.type === 'kolo').map(s => s.day)).toEqual([5])
    const b = applyDayWords(f, 'dodaj še kolo ob sobotah', 29)!
    expect(b.sessions.filter(s => s.type === 'kolo').map(s => s.day).sort()).toEqual([5, 6])
    const c = applyDayWords(f, 'ob nedeljah tek namesto kolesa', 29)!
    expect(c.sessions.some(s => s.type === 'kolo')).toBe(false)
    expect(c.sessions.filter(s => s.type === 'tek' && !s.after).map(s => s.day)).toEqual([6])
    const d = applyDayWords(f, 'tek samo ob sobotah', 29)!
    expect(d.sessions.filter(s => s.type === 'tek').map(s => [s.day, !!s.after])).toEqual([[5, false]])
    expect(d.sessions.filter(s => s.type === 'fitnes').map(s => s.day)).toEqual([1, 4])
    // »tek po fitnesu ob torkih« ne podre petkovega fitnesa
    const e = applyDayWords(ruleProposal('fitnes v torek in petek', [], 29).focus, 'tek po fitnesu ob torkih', 29)!
    expect(e.sessions.filter(s => s.type === 'fitnes').map(s => s.day)).toEqual([1, 4])
    expect(tailsOf(e.sessions).size).toBe(1)
    // premik z dveh dni: »iz torka in petka na sredo in četrtek«
    expect(movesIn('premakni fitnes iz torka in petka na sredo in četrtek')).toEqual([{ type: 'fitnes', from: [1, 4], to: [2, 3] }])
    const m = applyDayWords(f, 'premakni fitnes iz torka in petka na sredo in četrtek', 29)!
    expect(m.sessions.filter(s => s.type === 'fitnes').map(s => s.day)).toEqual([2, 3])
    expect(tailsOf(m.sessions).size).toBe(2)
  })
  it('pogajanje brez AI: »dodaj tek po fitnesu« da tek po vsaki moči (ne nov dan); »manj dni« dvakrat zapored izbriše prave seje', () => {
    const f = ruleProposal('fitnes v ponedeljek, sredo in petek, kolo v nedeljo', [], 29).focus
    const a = ruleAdjust(f, 'dodaj tek po fitnesu', 29)!
    expect(tailsOf(a.sessions).size).toBe(3)
    expect(trainingDays(a.sessions)).toBe(trainingDays(f.sessions))
    const b = ruleAdjust(a, 'manj dni', 29)!
    const c = ruleAdjust(b, 'manj dni', 29)!
    expect(trainingDays(c.sessions)).toBe(trainingDays(a.sessions) - 2)
    expect([...tailsOf(c.sessions).values()].every(i => c.sessions[i]!.type === 'fitnes')).toBe(true)
    expect(c.sessions.filter(s => s.after).length).toBe(tailsOf(c.sessions).size)
  })
  it('pogajanje: »v fitnes ne hodim …« premakne fitnes na ostale dni; dan brez časa in nazaj; prejšnji dnevi ostanejo', () => {
    const f0 = ruleProposal('Fitnes in tek.', [{ id: 'dni', q: 'dni', a: '4' }], 29).focus
    const a = ruleAdjust(f0, 'soboto nedeljo torek in cetrtek v fitnes ne hodim', 29)!
    const days = a.sessions.filter(s => s.type === 'fitnes').map(s => s.day)
    expect(days.length).toBeGreaterThan(0)
    days.forEach(d => expect([0, 2, 4]).toContain(d))
    expect(a.title).toBe(f0.title)
    const b = ruleAdjust(a, 'Ob sredah pa ne morem.', 29)!
    expect(b.offDays).toEqual([2])
    expect(b.sessions.find(s => s.day === 2)).toBeUndefined()
    const c = ruleAdjust(b, 'Ob sredah pa lahko.', 29)!
    expect(c.offDays).toBeNull()
    expect(ruleAdjust(c, 'krajše vadbe', 29)!.sessions.filter(s => s.type === 'fitnes').map(s => s.day)).toEqual(c.sessions.filter(s => s.type === 'fitnes').map(s => s.day))
    expect(ruleAdjust(c, 'blabla', 29)).toBeNull()
  })
  it('AI: »dan« pri seji se ohrani; dva na isti dan v obratnem vrstnem redu; prejšnji dnevi, ko jih AI izpusti; vrsta brez »sporti«', () => {
    const r = parseProposal({ odgovor: 'ok', sporti: ['fitnes'], raven: 2, seje: [
      { vrsta: 'tek', kardio: 'lahko', min: 30, dan: 1 }, { vrsta: 'Fitnes', del: 'zgornji', min: 60, dan: 1 },
      { vrsta: 'fitnes', del: 'spodnji', min: 60, dan: 1 }, { vrsta: 'fitnes', del: 'noge', min: 60, dan: 4 }] }, { wish: 'x' })!
    expect(r.focus.sessions.map(s => s.day ?? null)).toEqual([null, 1, null, 4])
    expect(r.focus.sessions[0]!.after).toBe(true)
    expect(r.focus.sessions).toHaveLength(4)
    const prev = r.focus
    const again = parseProposal({ odgovor: 'ok', seje: [{ vrsta: 'fitnes', del: 'zgornji', min: 50 }, { vrsta: 'fitnes', del: 'spodnji', min: 50 }, { vrsta: 'tek', kardio: 'lahko', min: 30 }] }, { wish: 'x', keepDays: prev.sessions })!
    expect(again.focus.sessions.map(s => s.day ?? null)).toEqual([1, null, 4])   // kardio po moči takoj za svojo močjo
    expect(again.focus.sessions[1]!.after).toBe(true)
    const po = parseProposal({ odgovor: 'ok', seje: [{ vrsta: 'fitnes', del: 'zgornji', min: 50, dan: 2 }, { vrsta: 'tek', kardio: 'lahko', min: 20, poMoci: true }] }, { wish: 'x' })!
    expect([...tailsOf(po.focus.sessions).entries()]).toEqual([[1, 0]])
    const fresh = parseProposal({ odgovor: 'ok', seje: [{ vrsta: 'fitnes', del: 'zgornji', min: 50, dan: 2 }, { vrsta: 'tek', min: 30 }] }, { wish: 'x', keepDays: prev.sessions })!
    expect(fresh.focus.sessions.map(s => s.day ?? null)).toEqual([2, null])
    const t = (proposalPrompt({ wish: 'x', basics: {}, qa: [], prev, feedback: 'Več teka' })[0] as { text: string }).text
    expect(t).toContain('dan=1')
    expect(t).toContain('Dneve ("dan") iz prejšnjega predloga ohrani')
    expect(focusContext({ focus: prev })).toContain('(vedno ob torkih)')
  })
  it('AI, ki dni ni upošteval: besede uporabnika veljajo (določene vadbe, odvečne izpadejo, manjkajoče se dodajo)', () => {
    const ai = parseProposal({ odgovor: 'ok', seje: [{ vrsta: 'fitnes', del: 'potisk', min: 60 }, { vrsta: 'fitnes', del: 'poteg', min: 60 }, { vrsta: 'fitnes', del: 'noge', min: 60 }, { vrsta: 'kolo', kardio: 'intervali', min: 60 }] }, { wish: 'x' })!.focus
    const f = applyDayWords(ai, BLAZ, 29)!
    expect(f.offDays).toEqual([0])
    expect(f.sessions.filter(s => s.type === 'fitnes').map(s => [s.part, s.day])).toEqual([['zgornji', 1], ['spodnji', 4]])
    expect(f.sessions.filter(s => s.type === 'tek').map(s => s.after)).toEqual([true, true])
    expect(weekWords(f)).toBe('tor fitnes zgornji del + tek · pet fitnes spodnji del + tek · ned kolo intervali')
    expect(f.sessions.find(s => s.type === 'kolo')).toMatchObject({ day: 6, cardio: 'intervali', min: 60 })
    expect(daysReply(f)).toContain('Ob ponedeljkih ni vadbe.')
    expect(applyDayWords(ai, 'več kardia', 29)).toBeNull()
  })
})

describe('»v fitnes ne hodim …« z določenimi dnevi', () => {
  it('fitnes s tekom isti dan se premakne skupaj s tekom; dan brez časa ostane', () => {
    const f = ruleProposal(BLAZ, [], 29).focus
    const a = applyDayWords(f, 'soboto nedeljo torek in cetrtek v fitnes ne hodim', 29)!
    expect(a.offDays).toEqual([0])
    expect(a.sessions.filter(s => s.type === 'fitnes').map(s => s.day)).toEqual([2, 4])
    expect(a.sessions.filter(s => s.type === 'tek').map(s => s.after)).toEqual([true, true])
    expect(a.sessions.find(s => s.type === 'kolo')!.day).toBe(6)
    expect(trainingDays(a.sessions)).toBe(3)
    expect(weekWords(a)).toBe('sre fitnes celo telo + tek · pet fitnes celo telo + tek · ned kolo')   // začetnik: celo telo
  })
})

describe('premik: »iz torka na sredo«', () => {
  it('izvorni dan ni cilj; prejšnji dnevi iz AI popravka ostanejo (keepDays vedno), besede jih spremenijo', () => {
    expect(pinsIn('premakni fitnes iz torka na sredo')).toEqual([])   // premik, ne določen dan
    expect(movesIn('premakni fitnes iz torka na sredo')).toEqual([{ type: 'fitnes', from: [1], to: [2] }])
    expect(pinsIn('fitnes ne v torek, ampak v sredo').map(p => p.day)).toEqual([2])
    const prev = ruleProposal(BLAZ, [], 29).focus
    const ai = parseProposal({ odgovor: 'ok', seje: [{ vrsta: 'fitnes', del: 'zgornji', min: 60 }, { vrsta: 'fitnes', del: 'spodnji', min: 60 }, { vrsta: 'tek', kardio: 'lahko', min: 20 }, { vrsta: 'kolo', kardio: 'lahko', min: 60 }] }, { wish: 'x', prevOff: prev.offDays, keepDays: prev.sessions })!.focus
    expect(ai.sessions.map(s => s.day ?? null)).toEqual([1, null, 4, 6])
    expect(ai.sessions[1]!.after).toBe(true)
    expect(ai.offDays).toEqual([0])
    const f = applyDayWords(ai, 'premakni fitnes iz torka na sredo', 29)!
    expect(f.sessions.filter(s => s.type === 'fitnes').map(s => s.day)).toEqual([2, 4])   // samo seja s torka
    expect(weekWords(f)).toBe('sre fitnes zgornji del + tek · pet fitnes spodnji del · ned kolo')
    expect(f.sessions.find(s => s.type === 'kolo')!.day).toBe(6)
  })
})

describe('dnevi ostanejo, ko uporabnik ne govori o dnevih', () => {
  it('AI ob »več kardia« spremeni dneve ali izpusti kardio po moči → prejšnja struktura velja', () => {
    const prev = ruleProposal(BLAZ, [], 29).focus   // fitnes tor+tek, fitnes pet+tek, kolo ned, pon prosto
    const ai = parseProposal({ odgovor: 'ok', neGre: [], seje: [{ vrsta: 'fitnes', del: 'zgornji', min: 60, dan: 0 }, { vrsta: 'fitnes', del: 'spodnji', min: 60, dan: 2 }, { vrsta: 'tek', kardio: 'lahko', min: 20 }, { vrsta: 'tek', kardio: 'intervali', min: 30 }, { vrsta: 'kolo', kardio: 'lahko', min: 60 }] }, { wish: 'x' })!.focus
    const f = keepDayStructure(prev, ai, 29)
    expect(f.offDays).toEqual([0])
    expect(f.sessions.filter(s => s.type === 'fitnes').map(s => s.day)).toEqual([1, 4])
    expect(f.sessions.filter(s => s.after)).toHaveLength(2)
    expect(f.sessions.find(s => s.type === 'kolo')!.day).toBe(6)
    expect(weekWords(f)).toMatch(/^tor fitnes zgornji del \+ tek · pet fitnes spodnji del \+ tek( intervali)? · ned kolo$/)
    expect(mentionsDays('več kardia')).toBe(false)
  })
})
