import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { todayIso, addDays, weekStartIso } from '../src/domain/training/load'
import { FRANJA_2027 } from '../src/domain/training/planner'
import type { PlanDay } from '../src/domain/types'

const NOW = '2026-10-03T08:00:00.000Z'
const day = (id: string, date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id, date, kind: 'kolo', title: 'Po občutku', desc: '', durationMin: 60, zone: 'Z2', tssTarget: 35, role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })

describe('off-season: hribi, ki jih je prej izbrala aplikacija', () => {
  beforeEach(async () => { await repo.wipeAll(); localStorage.clear(); await store.reloadAll() })
  const setup = async (o: Record<string, unknown> = {}) => {
    const t = todayIso(), ws = weekStartIso(t)
    await store.updateProfile({ onboardingDone: true, event: { ...FRANJA_2027 }, cycleStart: ws, offSeasonWeeks: 3, ...o })
    const d1 = addDays(t, 1), d2 = addDays(t, 2)
    await repo.upsertPlanDays([
      day('h1', d1, { kind: 'pohod', title: 'Hribi', role: 'lahka' }),
      day('s1', d2, { kind: 'pohod', title: 'Hribi namesto kolesa', swap: { kind: 'kolo', title: 'Po občutku', desc: '', durationMin: 60, zone: 'Z2', tssTarget: 35, role: 'lahka', target: null } }),
    ])
    await store.reloadAll()
    return { d1, d2 }
  }
  it('kdor ni izbral: hribi iz predloge → kolo po občutku; njegova zamenjava ostane; drugič nič', async () => {
    const { d1 } = await setup()
    expect(await store.offMixFix()).toBe(true)
    const plan = store.getState().plan
    expect(plan.find(d => d.id === 'h1')).toBeUndefined()
    expect(plan.filter(d => d.date >= todayIso()).some(d => d.kind === 'pohod' && !d.swap)).toBe(false)
    expect(plan.filter(d => d.date === d1).every(d => d.kind !== 'pohod')).toBe(true)
    expect(plan.find(d => d.id === 's1')?.kind).toBe('pohod')
    expect(await store.offMixFix()).toBe(false)
  })
  it('kdor je izbral hribe ali ni v off-seasonu: nič', async () => {
    await setup({ offMix: 'hribi' })
    expect(await store.offMixFix()).toBe(false)
    expect(store.getState().plan.some(d => d.id === 'h1')).toBe(true)
    await store.updateProfile({ offMix: null, offSeasonWeeks: 0 })
    expect(await store.offMixFix()).toBe(false)
  })
  it('izbira »Kolo in hribi« sestavi ta in naslednji teden znova', async () => {
    await setup()
    await store.setOffMix('mesano')
    expect(store.getState().profile.offMix).toBe('mesano')
    const next = addDays(weekStartIso(todayIso()), 7)
    const wk = store.getState().plan.filter(d => d.date >= next && d.date <= addDays(next, 6))
    expect(wk.filter(d => d.kind === 'pohod').length).toBe(2)
  })
})
