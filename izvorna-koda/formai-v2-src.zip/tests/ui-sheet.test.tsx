// Spodnji list: Esc zapre, gumb Nazaj (popstate) zapre list namesto zaslona, fokus gre v list in nazaj.
import { act, useState } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, afterEach, beforeEach } from 'vitest'
import { Sheet } from '@/ui/primitives'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

let div: HTMLDivElement, root: Root
const wait = (ms = 20) => act(async () => { await new Promise(r => setTimeout(r, ms)) })

function Page() {
  const [open, setOpen] = useState(false)
  return (<>
    <button id="open" onClick={() => setOpen(true)}>odpri</button>
    <Sheet open={open} onClose={() => setOpen(false)}><b>Tehtanje</b><button id="x" onClick={() => setOpen(false)}>zapri</button></Sheet>
  </>)
}
const dialog = () => document.querySelector('[role="dialog"]') as HTMLElement | null

beforeEach(async () => {
  history.replaceState(null, '', '#/danes')
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root.render(<Page />) })
})
afterEach(async () => { await act(async () => root.unmount()); div.remove() })

describe('Sheet', () => {
  it('ima vlogo dialoga, ime iz naslova in fokus; ob zaprtju se fokus vrne', async () => {
    const opener = div.querySelector('#open') as HTMLButtonElement
    opener.focus()
    await act(async () => { opener.click() })
    const d = dialog()!
    expect(d.getAttribute('aria-modal')).toBe('true')
    expect(d.getAttribute('aria-label')).toBe('Tehtanje')
    expect(d.contains(document.activeElement)).toBe(true)
    await act(async () => { (document.querySelector('#x') as HTMLButtonElement).click() })
    await wait()
    expect(dialog()).toBeNull()
    expect(document.activeElement).toBe(opener)
  })

  it('Esc zapre list', async () => {
    await act(async () => { (div.querySelector('#open') as HTMLButtonElement).click() })
    await act(async () => { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })) })
    expect(dialog()).toBeNull()
    await wait(50)                                  // zaprt list pospravi svoj vnos v zgodovini (history.back)
    expect(location.hash).toBe('#/danes')
  })

  it('Nazaj (popstate) zapre list, zaslon (naslov) ostane', async () => {
    await wait(50)
    await act(async () => { (div.querySelector('#open') as HTMLButtonElement).click() })
    // odprt list ima svoj vnos v zgodovini (isti naslov), zato Nazaj zapre list in ne zapusti zaslona
    expect((history.state as { formaiSheet?: unknown } | null)?.formaiSheet).toBeTruthy()
    expect(location.hash).toBe('#/danes')
    await act(async () => { history.back() })
    await wait(50)
    expect(dialog()).toBeNull()
    expect(location.hash).toBe('#/danes')
  })
})
