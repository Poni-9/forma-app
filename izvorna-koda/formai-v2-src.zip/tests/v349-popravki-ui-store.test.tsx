// v3.49 POPRAVKI-UI (REVIEW-UI, prava shramba): »Imam samo X min« → »Razveljavi« pusti moč istega dne (U1),
// autoMissed počaka na »si ga naredil?« in »Opravil« na prestavljenem dnevu vrne ciljni dan (U2),
// izbris edinega tehtanja vrne težo profila na izhodišče cilja ali pove, da ostane (U6).
import 'fake-indexeddb/auto'
import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
const U = vi.hoisted(() => ({ undo: null as null | (() => unknown), msg: '' }))
vi.mock('../src/ui/Confirm', async (orig) => {
  const m = await orig<typeof import('../src/ui/Confirm')>()
  return { ...m, undoToast: (msg: string, fn: () => unknown) => { U.msg = msg; U.undo = fn } }
})

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { SkipSheet } from '../src/ui/SkipSheet'
import { yesterdayUnmarked } from '../src/domain/training/missed'
import { addDays } from '../src/domain/training/load'
import { dm } from '../src/ui/format'
import type { PlanDay, Profile } from '../src/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-14'   // sreda
const NOW = `${TODAY}T08:00:00.000Z`
const prof = (o: Partial<Profile> = {}): Profile => ({
  ...repo.defaultProfile(), sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, ftpDate: '2026-09-14', lthr: 184,
  gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: true }, strength: { on: true, equipment: 'none' }, strengthDays: 2,
  hoursPerWeek: 8, goal: 'forma', deficit: 0, onboardingDone: true, cycleStart: '2026-09-21', createdAt: NOW, updatedAt: NOW, ...o,
} as Profile)
const day = (id: string, o: Partial<PlanDay>): PlanDay => ({ id, date: TODAY, kind: 'kolo', title: 'Kolo — lahko 1 h 30 min', desc: 'Lahko, Z2.', durationMin: 90, zone: 'Z2', role: 'lahka', tssTarget: 60, why: null, done: null, source: 'rules', createdAt: NOW, updatedAt: NOW, ...o } as PlanDay)
const rest = (id: string, date: string) => day(id, { date, kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, role: null, tssTarget: 0 })
const plan = () => store.getState().plan
const byId = (id: string) => plan().find(d => d.id === id)

let root: Root | null = null, host: HTMLDivElement | null = null
beforeEach(async () => {
  vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date(2026, 9, 14, 9, 0))
  U.undo = null; U.msg = ''
  await repo.wipeAll(); localStorage.clear()
  await repo.saveProfile(prof())
  await store.reloadAll()
})
afterEach(() => { if (root) act(() => root!.unmount()); root = null; host?.remove(); host = null; vi.useRealTimers() })

describe('U1 SkipSheet »Imam samo …« → Razveljavi', () => {
  it('po razveljavitvi ostane tudi moč istega dne', async () => {
    await repo.putPlanDays([day('k1', {}), day('m1', { kind: 'moc', title: 'Moč — jedro', desc: 'Jedro.', durationMin: 20, zone: null, role: 'moc', tssTarget: 16, exercises: [{ name: 'Deska', sets: 3, reps: '45 s' }] })])
    await store.reloadAll()
    host = document.createElement('div'); document.body.appendChild(host); root = createRoot(host)
    const kolo = byId('k1')!
    await act(async () => { root!.render(<SkipSheet day={kolo} canMove onClose={() => undefined} onMove={() => undefined} onSick={() => undefined} />) })
    const btn = (re: RegExp) => [...document.body.querySelectorAll('button')].find(b => re.test(b.textContent || ''))
    await act(async () => { btn(/Imam samo/)!.click() })
    await act(async () => { btn(/^45 min$/)!.click(); await new Promise(r => setTimeout(r, 200)) })
    expect(byId('k1')!.durationMin).toBe(45)
    expect(plan().filter(d => d.date === TODAY).map(d => d.id).sort()).toEqual(['k1', 'm1'])
    expect(U.undo).toBeTruthy()
    await act(async () => { await U.undo!(); await new Promise(r => setTimeout(r, 100)) })
    expect(byId('k1')!.durationMin).toBe(90)
    expect(plan().filter(d => d.date === TODAY).map(d => d.id).sort()).toEqual(['k1', 'm1'])
  })
})

describe('U2 autoMissed in »si ga naredil?«', () => {
  const Y = addDays(TODAY, -1)
  const week = () => [
    rest('mon', addDays(TODAY, -2)),
    day('vo2', { date: Y, title: 'VO2max 4 × 4 min', role: 'kljucna', zone: 'Z5', durationMin: 75, tssTarget: 80 }),
    day('wed', { title: 'Z2 lahko', durationMin: 60, tssTarget: 42 }),
    rest('thu', addDays(TODAY, 1)),
    day('fri', { date: addDays(TODAY, 2), title: 'Z2 lahko', durationMin: 60, tssTarget: 42 }),
    rest('sat', addDays(TODAY, 3)), rest('sun', addDays(TODAY, 4)),
  ]
  beforeEach(async () => {
    await repo.putPlanDays(week())
    await store.reloadAll()
    await store.boot()   // ready (autoMissed sicer ne teče); zagonski autoMissed čaka na usklajevanje (8 s), test je prej mimo
  })
  it('včerajšnji ključni trening brez kljukice počaka na odgovor; »Ne« ga prestavi; »Opravil« na prestavljenem vrne ciljni dan', async () => {
    expect(yesterdayUnmarked(store.getState())?.id).toBe('vo2')
    await store.autoMissed()
    // (prej: takoj prestavljen na sredo in vprašanje je izginilo)
    expect(byId('vo2')!.missed ?? null).toBeNull()
    expect(byId('wed')!.title).toBe('Z2 lahko')
    expect(yesterdayUnmarked(store.getState())?.id).toBe('vo2')
    // »Ne«
    await store.autoMissed('vo2')
    expect(byId('vo2')!.missed).toBe('moved')
    expect(byId('wed')!.title).toBe('VO2max 4 × 4 min')
    expect(byId('wed')!.adapt?.after).toBe(Y)
    expect(yesterdayUnmarked(store.getState())).toBeNull()
    expect(U.msg).toContain('Včerajšnji VO2max 4 × 4 min ni bil narejen → prestavljen na sredo.')
    // vendarle opravljen (Plan → »Opravil«): sreda spet po načrtu, dan ni več »prestavljen«
    await store.setPlanDone('vo2', true)
    expect(byId('vo2')!.done).toBeTruthy()
    expect(byId('vo2')!.missed ?? null).toBeNull()
    expect(byId('wed')!.title).toBe('Z2 lahko')
    expect(byId('wed')!.adapt?.off).toBe(true)
    expect(store.getState().toast?.msg).toBe('VO2max 4 × 4 min je bil vendarle narejen — sreda je spet po načrtu.')
    // drugič se ne prestavi: dan je opravljen
    await store.autoMissed('vo2')
    expect(byId('wed')!.title).toBe('Z2 lahko')
  })
  it('druge zamujene ključne seje (predvčerajšnjim) gredo naprej tudi, ko včerajšnja čaka', async () => {
    await store.updatePlanDays([day('mon', { date: addDays(TODAY, -2), title: 'Prag 2 × 20 min', role: 'kljucna', zone: 'Z4', durationMin: 80, tssTarget: 85 })])
    await store.autoMissed()
    expect(byId('mon')!.missed).toBe('moved')
    expect(byId('vo2')!.missed ?? null).toBeNull()
    expect(byId('wed')!.title).toBe('Prag 2 × 20 min')
  })
})

describe('U6 izbris edinega tehtanja', () => {
  it('teža v profilu nazaj na izhodišče cilja (uvod 79, tipkarska 97); brez izhodišča pove, da ostane', async () => {
    await store.updateProfile({ goalStart: { date: TODAY, ftp: 240, weightKg: 79 } })
    await store.saveCheckin({ date: TODAY, weightKg: 97 })
    expect(store.getState().profile.weightKg).toBe(97)
    await store.removeWeigh(TODAY)
    expect(store.getState().profile.weightKg).toBe(79)
    expect(U.msg).toBe(`Izbrisano tehtanje ${dm(TODAY)} (97 kg). Teža v profilu: 79 kg (izhodišče cilja).`)
    // »Razveljavi« vrne tehtanje in težo
    await U.undo!()
    expect(store.getState().profile.weightKg).toBe(97)
    // brez izhodišča: teža ostane, obvestilo to pove
    await store.updateProfile({ goalStart: null })
    await store.removeWeigh(TODAY)
    expect(store.getState().profile.weightKg).toBe(97)
    expect(U.msg).toBe(`Izbrisano tehtanje ${dm(TODAY)} (97 kg). Teža v profilu ostane 97 kg — popravi jo v Nastavitvah → Profil.`)
  })
})
