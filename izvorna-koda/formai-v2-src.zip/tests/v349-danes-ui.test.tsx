// v3.49 DANES (zasloni): »Trener pravi« na dan moči in teka, »Po jutranjem vnosu« na dan dolge Z2, Prvi koraki brez
// kilogramov pri vadbi z lastno težo, »Danes ne gre« → »Imam samo X min«, prvi trening na dan počitka, fotografije vaj
// se menjajo samo na zaslonu.
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), st: { level: 1, legs: false, reasons: ['malo energije'] } as any }))
vi.mock('@/state/store', () => ({
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  saveCheckin: vi.fn(async () => {}), savePlanDay: vi.fn(async () => {}), savePlanDays: vi.fn(async () => {}), restorePlanDays: vi.fn(async () => {}),
  toast: vi.fn(), setPlanDone: vi.fn(), updateSettings: vi.fn(async () => {}),
  stateToday: () => S.st, setStateMode: vi.fn(async () => {}), undoStateToday: vi.fn(async () => {}),
}))
const nav = vi.hoisted(() => ({ calls: [] as unknown[][] }))
vi.mock('@/app/router', () => ({ navigate: (...a: unknown[]) => { nav.calls.push(a) }, useRoute: () => ({ name: 'danes', params: {} }) }))

import * as store from '@/state/store'
import { coachLine } from '@/screens/Danes'
import { StateCard } from '@/ui/StateCard'
import { FirstSteps } from '@/ui/FirstSteps'
import { SkipSheet } from '@/ui/SkipSheet'
import { FirstTraining } from '@/ui/FirstTraining'
import { ExercisePhoto } from '@/ui/figure/ExercisePhoto'
import { stepsFor } from '@/domain/training/workout'
import type { Activity, Focus, PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

const NOW = '2026-10-17T08:00:00.000Z'
const TODAY = '2026-10-17'
const day = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: date + (o.kind || 'kolo'), date, kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, zone: 'Z2', role: 'lahka', tssTarget: 42, source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })
const P = { sex: 'm', age: 30, heightCm: 180, weightKg: 75, ftp: 250, maxHr: 190, restHr: 50, lthr: 172, gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: true }, strength: { on: false, equipment: 'none' }, onboardingDone: true, createdAt: NOW, updatedAt: NOW } as unknown as Profile
const app = (o: Record<string, unknown> = {}) => ({ profile: P, plan: [], activities: [], checkins: [], checkinToday: null, today: TODAY, settings: { startDone: false, intervals: null }, user: null, ...o })

let div: HTMLDivElement, root: Root
const render = async (el: React.ReactNode) => { await act(async () => { root.render(el) }) }
const text = () => document.body.textContent || ''
const button = (re: RegExp) => [...document.body.querySelectorAll('button')].find(b => re.test(b.textContent || '')) as HTMLButtonElement | undefined
beforeEach(() => { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div); nav.calls = []; vi.clearAllMocks() })
afterEach(async () => { await act(async () => root.unmount()); div.remove(); document.body.innerHTML = '' })

describe('A24: »Trener pravi« na dan moči in teka', () => {
  const moc = { kind: 'moc', role: 'moc', zone: null }
  it('svež na dan fitnesa: težke serije, ne »ostane lahek«', () => {
    const t = coachLine(15, moc, 5, 5, 78)
    expect(t).not.toMatch(/lahek|Z2/)
    expect(t).toBe('Svež si — dober dan za težke serije. Zadnji dve ponovitvi naj bosta težki.')
  })
  it('utrujen na dan fitnesa: serija manj, ista teža; tek: pogovorni tempo; kolo kot prej (Z2)', () => {
    expect(coachLine(-25, moc, 5, 5, 78)).toBe('Utrujenost je visoka — serija manj, ista teža, brez nove teže. Jej do cilja.')
    expect(coachLine(-25, { kind: 'tek', role: 'lahka', zone: 'Z2' }, 5, 5, 78)).toMatch(/ostani v pogovornem tempu/)
    expect(coachLine(-25, { kind: 'kolo', role: 'lahka', zone: 'Z2' }, 5, 5, 78)).toMatch(/ostani v Z2/)
    expect(coachLine(30, moc, 5, 5, 78)).not.toMatch(/intervalov/)
    expect(coachLine(-25, moc, 5, 5, 40)).not.toMatch(/olajšaj dan/)
    expect(coachLine(15, { kind: 'kolo', role: 'lahka', zone: 'Z2' }, 5, 5, 78)).toMatch(/ostane lahek/)
  })
})

describe('A23: »Po jutranjem vnosu« na dan dolge Z2', () => {
  it('blaga utrujenost in dolga Z2: skrajšaj in jej, brez »pol intervalov«', async () => {
    S.state = app({ plan: [day(TODAY, { title: 'Dolga Z2 1 h 45 min', durationMin: 105, role: 'dolga' })] })
    await render(<StateCard />)
    expect(text()).toMatch(/Po jutranjem vnosu/)
    expect(text()).toMatch(/Malo energije: drži se spodnjega dela Z2 in po potrebi skrajšaj na ~1 h 10 min\. Jej od 30\. minute\./)
    expect(text()).not.toMatch(/intervalov/)
  })
  it('ključni trening: kot prej (pol intervalov ali samo Z2)', async () => {
    S.state = app({ plan: [day(TODAY, { title: 'VO2max 4 × 4 min', durationMin: 75, role: 'kljucna', zone: 'Z5' })] })
    await render(<StateCard />)
    expect(text()).toMatch(/pol intervalov ali samo Z2/)
  })
})

describe('C16: Prvi koraki pri vadbi z lastno težo', () => {
  const focus = (o: Partial<Focus>): Focus => ({ wish: '', sports: ['doma'], aims: ['zdravje'], muscles: [], level: 1, equipment: ['nic'], limits: null, keepMuscle: false, sessions: [{ type: 'doma', part: 'celo', min: 30 }, { type: 'hribi', cardio: 'lahko', min: 30 }], offDays: null, notes: [], title: 'Več gibanja', mode: 'meri', by: 'pravila', at: NOW, ...o } as Focus)
  const custom = (f: Focus) => ({ ...P, goal: 'forma', focus: f, gear: { bikeOutdoor: false, trainer: false, noBike: true, powerMeter: null } }) as unknown as Profile
  const intervals = { intervals: { athleteId: 'i1', apiKey: 'k' } }
  it('doma brez opreme: »Prvi trening« z vpisom ponovitev, brez »kilogram«', async () => {
    S.state = app({ profile: custom(focus({})), settings: { startDone: false, ...intervals } })
    await render(<FirstSteps />)
    expect(text()).toMatch(/Prvi trening/)
    expect(text()).toMatch(/vpiši ponovitve/)
    expect(text()).not.toMatch(/kilogram/i)
  })
  it('vadba moči brez kg odkljuka korak (prej nikoli); v fitnesu ostane »s kilogrami«', async () => {
    const act1 = { id: 'a1', source: 'manual', sport: 'moc', date: '2026-10-16', name: 'Doma — celo telo', exercises: [{ name: 'Počep', sets: 3, reps: '12, 12, 12' }], aiEligible: true, geoRetain: false, createdAt: NOW, updatedAt: NOW } as Activity
    S.state = app({ profile: custom(focus({})), activities: [act1], settings: { startDone: false, ...intervals } })
    await render(<FirstSteps />)
    expect(text()).not.toMatch(/Prvi trening/)
    S.state = app({ profile: custom(focus({ sports: ['fitnes'], equipment: ['fitnes', 'nic'], sessions: [{ type: 'fitnes', part: 'celo', min: 60 }] })), settings: { startDone: false, ...intervals } })
    await act(async () => { S.subs.forEach(f => f()) })
    expect(text()).toMatch(/Prvi trening s kilogrami/)
  })
})

describe('A27: »Danes ne gre« → »Imam samo …«', () => {
  const vo2 = day(TODAY, { title: 'VO2max 4 × 4 min', desc: '20 min ogrevanje s 3 kratkimi pospeški. 4 × 4 min pri 270–290 W (108–115 % FTP), vmes 4 min lahko. 10 min iztek.', durationMin: 75, zone: 'Z5', role: 'kljucna', tssTarget: 80 })
  it('izbira minut: trening se skrajša in shrani, ponovitve ostanejo', async () => {
    S.state = app({ plan: [vo2] })
    const onClose = vi.fn()
    await render(<SkipSheet day={vo2} canMove onClose={onClose} onMove={() => undefined} onSick={() => undefined} />)
    const b = button(/Imam samo/)!
    expect(b.textContent).toMatch(/Ponovitve ostanejo, krajša sta ogrevanje in lahek del\./)
    await act(async () => { b.click() })
    const chips = [...document.body.querySelectorAll('.skip-mins button')].map(x => x.textContent)
    // (v3.50) samo dosežene minute: 20 in 30 sta dala 40 min (ponovitve ostanejo) — en čip »40 min« (A08)
    expect(chips).toEqual(['40 min', '45 min', '1 h'])
    await act(async () => { button(/^45 min$/)!.click() })
    const saved = vi.mocked(store.savePlanDay).mock.calls[0]![0] as PlanDay
    expect(saved).toMatchObject({ id: vo2.id, durationMin: 45 })
    expect(stepsFor(saved, P).filter(s => s.kind === 'delo')).toHaveLength(4)
    expect(onClose).toHaveBeenCalled()
  })
  it('kratek trening (25 min): brez »Imam samo«', async () => {
    const d = day(TODAY, { durationMin: 25 })
    S.state = app({ plan: [d] })
    await render(<SkipSheet day={d} canMove onClose={() => undefined} onMove={() => undefined} onSick={() => undefined} />)
    expect(button(/Imam samo/)).toBeUndefined()
  })
})

describe('C19: prvi dan počitek — kdaj je prvi trening', () => {
  it('ponedeljek: »začneva v ponedeljek« in vrstica, ki odpre Plan na ta dan', async () => {
    const mon = day('2026-10-19', { kind: 'moc', title: 'Fitnes — zgornji del', durationMin: 60, zone: null, role: 'moc' })
    await render(<FirstTraining day={mon} today={TODAY} />)
    expect(text()).toMatch(/Danes si odpočij — začneva v ponedeljek\./)
    expect(text()).toMatch(/Prvi trening · ponedeljek, 19\.\s10\./)
    expect(text()).toMatch(/Fitnes — zgornji del/)
    await act(async () => { button(/Prvi trening/)!.click() })
    expect(nav.calls[0]).toEqual(['plan', { dan: '2026-10-19' }])
  })
  it('sreda in jutri: tožilnik (»v sredo«); jutri brez vrstice (je na kartici Jutri)', async () => {
    await render(<FirstTraining day={day('2026-10-21', { kind: 'tek', title: 'Tek — lahko 25 min', durationMin: 25 })} today={TODAY} />)
    expect(text()).toMatch(/začneva v sredo/)
    await render(<FirstTraining day={day('2026-10-18', { kind: 'tek', title: 'Tek — lahko 25 min', durationMin: 25 })} today={TODAY} />)
    expect(text()).toMatch(/začneva jutri/)
    expect(button(/Prvi trening/)).toBeUndefined()
  })
})

describe('D17: fotografije vaj se menjajo samo, ko je ploščica na zaslonu', () => {
  it('izven zaslona brez razreda »on«, na zaslonu z njim; playing=false nikoli', async () => {
    const obs: ((e: { isIntersecting: boolean }[]) => void)[] = []
    const opts: (IntersectionObserverInit | undefined)[] = []
    class IO { constructor(cb: (e: { isIntersecting: boolean }[]) => void, o?: IntersectionObserverInit) { obs.push(cb); opts.push(o) } observe() {} disconnect() {} unobserve() {} takeRecords() { return [] } }
    vi.stubGlobal('IntersectionObserver', IO)
    try {
      await render(<ExercisePhoto id="pocep" label="Počep" />)
      const el = div.querySelector('.exph')!
      expect(el.classList.contains('on')).toBe(false)
      await act(async () => { obs.forEach(f => f([{ isIntersecting: true }])) })
      expect(el.classList.contains('on')).toBe(true)
      await act(async () => { obs.forEach(f => f([{ isIntersecting: false }])) })
      expect(el.classList.contains('on')).toBe(false)
      await render(<ExercisePhoto id="pocep" label="Počep" playing={false} />)
      await act(async () => { obs.forEach(f => f([{ isIntersecting: true }])) })
      expect(div.querySelector('.exph')!.classList.contains('on')).toBe(false)
      // galerija Vaj: samo pas na sredini zaslona
      opts.length = 0
      await render(<ExercisePhoto id="bench" label="Potisk" band />)
      expect(opts.at(-1)?.rootMargin).toBe('-35% 0px -35% 0px')
      // vaja brez fotografije (vektorska figura) v galeriji miruje: brez sličic (requestAnimationFrame)
      const raf = vi.spyOn(window, 'requestAnimationFrame')
      await render(<ExercisePhoto id="sklece-kolena" label="Sklece na kolenih" band />)
      await act(async () => { obs.forEach(f => f([{ isIntersecting: true }])) })
      expect(div.querySelector('svg.fig')).not.toBeNull()
      expect(raf).not.toHaveBeenCalled()
      // zunaj galerije (list vaje, vodena vadba) se figura giba
      await render(<ExercisePhoto id="sklece-kolena" label="Sklece na kolenih" />)
      await act(async () => { obs.forEach(f => f([{ isIntersecting: true }])) })
      expect(raf).toHaveBeenCalled()
      raf.mockRestore()
    } finally { vi.unstubAllGlobals() }
  })
})
