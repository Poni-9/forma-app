// v3.49 ZAPIS (zasloni) — »Zapusti vadbo« ponudi »Shrani, kar si naredil«, moč kaže na svoj zapis, zapis iz načrta na
// zaslonu »Opravljeno«, rezultat testa FTP takoj, »Si ga naredil?« za včeraj, »Krajše« pri »Opravil«, »Opravil« v Planu.
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'vadba', params: {} as Record<string, string> } }))
vi.mock('@/state/store', async () => {
  const { vi: v } = await import('vitest')
  const base: Record<string | symbol, unknown> = {
    useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
    getState: () => S.state,
    routePace: () => ({ k: 1, adj: { n: 0, adj: 1 } }),
  }
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' || typeof k === 'symbol' ? undefined : (t[k] = v.fn(async () => ({ added: 1, dupes: 0, upgraded: 0 })))), has: (_t, k) => k !== 'then' })
})
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => S.route }))
vi.mock('@/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '@/state/store'
import { Vadba, TestResult, RUN_KEY } from '@/screens/Vadba'
import { YesterdayRate } from '@/ui/YesterdayRate'
import { DoneMinutes } from '@/ui/DoneMinutes'
import { Plan } from '@/screens/Plan'
import type { Activity, PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-17', Y = '2026-10-16'
const NOW = `${TODAY}T08:00:00.000Z`
const P = { sex: 'm', age: 35, heightCm: 180, weightKg: 75, ftp: 250, ftpDate: '2026-09-01', gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true }, strength: { on: false, equipment: 'none' }, onboardingDone: true, hoursPerWeek: 8, goal: 'forma', createdAt: NOW, updatedAt: NOW } as unknown as Profile
const ride: PlanDay = { id: 'd1', date: TODAY, kind: 'kolo', title: 'Z2 vožnja', desc: 'Enakomerno v Z2.', durationMin: 60, zone: 'Z2', role: 'lahka', tssTarget: 42, source: 'rules', createdAt: NOW, updatedAt: NOW }
const gym: PlanDay = { id: 'm1', date: TODAY, kind: 'moc', title: 'Moč — jedro', desc: 'Jedro.', durationMin: 25, zone: null, role: 'moc', exercises: [{ name: 'Deska', sets: 2, reps: '40 s' }], source: 'rules', createdAt: NOW, updatedAt: NOW }
const test: PlanDay = { id: 't1', date: TODAY, kind: 'test', title: '20-minutni test FTP', desc: 'Test.', durationMin: 60, zone: 'test', role: 'test', tssTarget: 70, source: 'rules', createdAt: NOW, updatedAt: NOW }
const reset = (plan: PlanDay[], o: Record<string, unknown> = {}) => {
  S.state = { ready: true, today: TODAY, plan, activities: [], recentMeals: [], mealsToday: [], checkins: [], weather: null, routeLib: null, routesBusy: false, settings: { lang: 'sl', intervals: null }, toast: null, profile: P, user: null, changes: [], sync: { state: 'ok' }, ...o }
}
const fn = (k: string) => (store as unknown as Record<string, ReturnType<typeof vi.fn>>)[k]!

let div: HTMLDivElement, root: Root | null = null
async function render(el: ReactElement) {
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root!.render(el) })
  return div
}
const sp = (x: string | null | undefined) => (x || '').replace(/[  ⁠]/g, ' ')
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(sp(b.textContent))) as HTMLButtonElement | undefined
const tick = async (ms: number) => { await act(async () => { vi.advanceTimersByTime(ms) }) }
const flush = async () => { for (let i = 0; i < 6; i++) await act(async () => { await Promise.resolve() }) }
afterEach(async () => { if (root) { await act(async () => root!.unmount()); root = null } div?.remove(); document.body.innerHTML = ''; vi.useRealTimers() })

describe('Vadba', () => {
  beforeEach(() => {
    vi.useFakeTimers(); vi.setSystemTime(new Date(`${TODAY}T10:00:00`)); sessionStorage.clear(); localStorage.clear(); S.subs.clear()
    fn('setPlanDone').mockClear(); fn('addActivities').mockClear(); fn('updateProfile').mockClear()
  })
  async function startRun(day: PlanDay) {
    S.route = { name: 'vadba', params: { id: day.id } }
    await render(<Vadba />)
    await act(async () => { btn(/Začni trening/)!.click() })
  }

  it('A37 »Zapusti vadbo« po 10 min: »Shrani, kar si naredil« zapiše 10 min (prej samo »Prekini« brez shranjevanja)', async () => {
    reset([ride])
    await startRun(ride)
    await tick(10 * 60_000)
    await act(async () => { (document.querySelector('header button[aria-label="Zapusti vadbo"]') as HTMLButtonElement).click() })
    const sheet = document.querySelector('.sheet')!
    expect(sp(sheet.textContent)).toContain('Zapustiš trening?')
    expect([...sheet.querySelectorAll('button')].map(b => sp(b.textContent))).toEqual(['Nadaljuj trening', 'Shrani, kar si naredil (10:00)', 'Prekini brez oznake'])
    await act(async () => { btn(/Shrani, kar si naredil/)!.click() })
    await flush()
    expect(fn('setPlanDone')).toHaveBeenCalledWith('d1', true, null, 10)
    expect(div.textContent).toContain('Opravljeno')
  })

  it('A37 pod 5 min ostane vprašanje »Prekinem trening?« (2 min ni kaj shraniti)', async () => {
    reset([ride])
    await startRun(ride)
    await tick(2 * 60_000)
    await act(async () => { (document.querySelector('header button[aria-label="Zapusti vadbo"]') as HTMLButtonElement).click() })
    expect(sp(document.querySelector('.sheet')!.textContent)).toContain('Prekinem trening?')
    expect(btn(/Shrani, kar si naredil/)).toBeUndefined()
  })

  it('moč: dan kaže na zapis vadbe z vajami (brez dodatnega zapisa iz načrta)', async () => {
    reset([gym])
    await startRun(gym)
    // (v3.50) moč šteje serije: po obeh deskah (raztezanje) potrditev — prej po 5 s, zdaj bi to bil list »0 od 2 serij«
    await tick(7.5 * 60_000)
    await act(async () => { btn(/^Zaključi$/)!.click() })
    await act(async () => { ([...document.querySelectorAll('.sheet button')].find(b => b.textContent === 'Zaključi') as HTMLButtonElement).click() })
    await flush()
    const call = fn('setPlanDone').mock.calls[0]!
    expect(call[0]).toBe('m1'); expect(call[1]).toBe(true); expect(call[3]).toBe(8)
    const a = (fn('addActivities').mock.calls[0]![0] as Activity[])[0]!
    expect(call[2]).toBe(a.id)
    expect(a).toMatchObject({ sport: 'moc', source: 'manual' })
  })

  it('A03 brez ure: »Zapisano kot vadba iz načrta (31 min) — šteje v teden in formo«', async () => {
    reset([ride], { activities: [{ id: 'plan-d1-x', source: 'plan', planDayId: 'd1', sport: 'kolo', date: TODAY, name: 'Z2 vožnja', durationMin: 31, tss: 22 } as Activity] })
    await startRun(ride)
    await tick(31 * 60_000)
    await act(async () => { btn(/^Zaključi$/)!.click() })
    await act(async () => { ([...document.querySelectorAll('.sheet button')].find(b => b.textContent === 'Zaključi') as HTMLButtonElement).click() })
    await flush()
    expect(fn('setPlanDone')).toHaveBeenCalledWith('d1', true, null, 31)
    const t = sp(div.textContent)
    expect(t).toContain('Zapisano kot vadba iz načrta (31 min) — šteje v teden in formo.')
    expect(t).toContain('Vožnjo z ure uvozi kot datoteko (.fit, .gpx) — zamenja ta zapis.')
  })

  it('A29 po testu FTP: »Rezultat testa« na zaslonu »Opravljeno«', async () => {
    reset([test])
    await startRun(test)
    await tick(61 * 60_000)
    await flush()
    expect(div.textContent).toContain('Opravljeno')
    expect(div.textContent).toContain('Rezultat testa')
    expect(btn(/Vpiši rezultat/)).toBeTruthy()
    expect(sessionStorage.getItem(RUN_KEY)).toBeTruthy()
  })
})

describe('A29 rezultat testa', () => {
  beforeEach(() => { fn('updateProfile').mockClear(); fn('toast').mockClear() })
  it('brez merilnika moči: povprečni utrip zadnjih 15 min → pražni utrip (cone)', async () => {
    reset([test], { profile: { ...P, gear: { ...P.gear, powerMeter: false } } })
    await render(<TestResult />)
    const inp = document.getElementById('test-hr') as HTMLInputElement
    expect(document.querySelector('label[for="test-hr"]')!.textContent).toMatch(/Povprečni utrip/)
    await act(async () => {
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(inp, '176')
      inp.dispatchEvent(new Event('input', { bubbles: true }))
    })
    await act(async () => { btn(/^Shrani$/)!.click() })
    await flush()
    expect(fn('updateProfile')).toHaveBeenCalledWith({ lthr: 176 })
    expect(sp(div.textContent)).toContain('Nov pražni utrip 176 — cone in utrip v načrtu so posodobljeni.')   // (v3.50) A17
  })
  it('brez merilnika: utrip zunaj razpona se ne shrani', async () => {
    reset([test], { profile: { ...P, gear: { ...P.gear, powerMeter: false } } })
    await render(<TestResult />)
    const inp = document.getElementById('test-hr') as HTMLInputElement
    await act(async () => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(inp, '30'); inp.dispatchEvent(new Event('input', { bubbles: true })) })
    await act(async () => { btn(/^Shrani$/)!.click() })
    await flush()
    expect(fn('updateProfile')).not.toHaveBeenCalled()
    expect(fn('toast')).toHaveBeenCalledWith('Vpiši utrip med 80 in 220.', 'err')
  })
  it('z merilnikom: »Vpiši rezultat« odpre list »Vpiši test« (20-min test); po vpisu FTP pove novi FTP', async () => {
    reset([test])
    await render(<TestResult />)
    await act(async () => { btn(/Vpiši rezultat/)!.click() })
    // list je naložen šele ob odprtju (lazy) — počakaj nanj znotraj act
    for (let i = 0; i < 200 && !document.querySelector('.sheet'); i++) await act(async () => { await new Promise(r => setTimeout(r, 20)) })
    expect(document.querySelector('.sheet')?.textContent).toContain('Vpiši test')
    expect(document.querySelector('.sheet .chip.on')?.textContent).toBe('20-min test')
    await act(async () => root!.unmount()); root = null; div.remove()
    reset([test], { profile: { ...P, ftp: 247, ftpDate: TODAY } })
    await render(<TestResult />)
    expect(sp(div.textContent)).toContain('FTP 247 W — v vodeni vadbi takoj, v načrtu od naslednjega tedna.')   // (v3.50) A45
  })
})

describe('C05 včeraj in A30 »Krajše«', () => {
  beforeEach(() => { localStorage.clear(); fn('setPlanDone').mockClear() })
  const yday: PlanDay = { ...ride, id: 'y1', date: Y, title: 'Lahek tek', kind: 'tek', durationMin: 25 }
  it('C05 Danes: »Včeraj: Lahek tek — si ga naredil?« → »Da, opravil« ga označi', async () => {
    reset([yday])
    await render(<YesterdayRate />)
    expect(sp(div.textContent)).toContain('Včeraj: Lahek tek — si ga naredil?')
    await act(async () => { btn(/Da, opravil/)!.click() })
    expect(fn('setPlanDone')).toHaveBeenCalledWith('y1', true)
  })
  it('C05 »Ne« skrije vprašanje za ta dan', async () => {
    reset([yday])
    await render(<YesterdayRate />)
    await act(async () => { btn(/^Ne$/)!.click() })
    expect(div.textContent).toBe('')
    expect(localStorage.getItem(`formai.ydayAsk.${TODAY}`)).toBe('1')
    expect(fn('setPlanDone')).not.toHaveBeenCalled()
  })
  it('A30 »Opravil« brez ure: »Šteje 1 h 45 min — po načrtu« → »krajše?« → 45 min', async () => {
    const d: PlanDay = { ...ride, durationMin: 105, done: { at: NOW, activityId: null } }
    reset([d])
    await render(<DoneMinutes day={d} />)
    expect(sp(div.textContent)).toMatch(/Šteje 1 h 45 min — po načrtu/)
    await act(async () => { btn(/krajše\?/)!.click() })
    expect(sp(document.querySelector('.sheet')!.textContent)).toContain('Koliko si res naredil?')
    await act(async () => { btn(/^45 min$/)!.click() })
    expect(fn('setPlanDone')).toHaveBeenCalledWith('d1', true, null, 45)
  })
  it('A30 krajše shranjeno: »Šteje 31 min od 1 h 45 min«; »Vse po načrtu« vrne cel trening; povezana vožnja nima izbire', async () => {
    const d: PlanDay = { ...ride, durationMin: 105, done: { at: NOW, activityId: null, min: 31 } }
    reset([d])
    await render(<DoneMinutes day={d} />)
    expect(sp(div.textContent)).toMatch(/Šteje 31 min od 1 h 45 min/)
    await act(async () => { btn(/^spremeni$/)!.click() })
    await act(async () => { btn(/Vse po načrtu/)!.click() })
    expect(fn('setPlanDone')).toHaveBeenCalledWith('d1', true, null, null)
    await act(async () => root!.unmount()); root = null; div.remove()
    await render(<DoneMinutes day={{ ...d, done: { at: NOW, activityId: 'a1' } }} />)
    expect(div.textContent).toBe('')
  })
})

describe('C05 Plan: pretekli dan', () => {
  beforeEach(() => { vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date(`${TODAY}T10:00:00`)); fn('setPlanDone').mockClear() })
  it('pretekli neoznačen dan: »ni označeno« in »Opravil« namesto »Začni«', async () => {
    const past: PlanDay = { ...ride, id: 'p1', date: '2026-10-15', title: 'Z2 vzdržljivost' }
    S.route = { name: 'plan', params: { dan: '2026-10-15' } }
    reset([past, { ...ride, id: 't0' }])
    await render(<Plan />)
    const card = document.getElementById('dan-2026-10-15')!
    expect(sp(card.textContent)).toContain('ni označeno')
    expect(sp(card.textContent)).not.toContain('ni bilo')
    const b = [...card.querySelectorAll('button')].find(x => sp(x.textContent) === ' Opravil' || sp(x.textContent).trim() === 'Opravil') as HTMLButtonElement
    expect(b).toBeTruthy()
    expect([...card.querySelectorAll('button')].some(x => /Začni/.test(x.textContent || ''))).toBe(false)
    await act(async () => { b.click() })
    expect(fn('setPlanDone')).toHaveBeenCalledWith('p1', true)
  })
})
