import 'fake-indexeddb/auto'
import { describe, it, expect, vi, afterEach } from 'vitest'
import { IDBFactory } from 'fake-indexeddb'

/**
 * Dve napravi (telefon, računalnik), vsaka s svojo bazo, in en dokument v »oblaku« (Firestore v pomnilniku).
 * Preverja pravo pot: store → repo → sync → merge → oblak → druga naprava.
 */
type Doc = Record<string, unknown>
const cloud: Record<string, Doc> = {}
let writes = 0
const fakeCore = {
  fs: {},
  fsMod: {
    doc: (_fs: unknown, col: string, id: string) => ({ path: `${col}/${id}` }),
    runTransaction: async (_fs: unknown, fn: (tx: unknown) => Promise<void>) => {
      let pending: { path: string; data: Doc; opts: { mergeFields?: string[] } } | null = null
      const tx = {
        get: async (ref: { path: string }) => ({ exists: () => !!cloud[ref.path], data: () => JSON.parse(JSON.stringify(cloud[ref.path])) }),
        set: (ref: { path: string }, data: Doc, opts: { mergeFields?: string[] }) => { pending = { path: ref.path, data, opts } },
      }
      await fn(tx)
      const p = pending as unknown as { path: string; data: Doc; opts: { mergeFields?: string[] } } | null
      if (p) {
        writes++
        const cur = cloud[p.path] || {}
        // mergeFields: navedena polja se zamenjajo v celoti, druga ostanejo (stara aplikacija)
        const next: Doc = { ...cur }
        for (const f of p.opts?.mergeFields || Object.keys(p.data)) next[f] = JSON.parse(JSON.stringify(p.data[f]))
        cloud[p.path] = next
      }
    },
  },
}

async function device() {
  vi.resetModules()
  ;(globalThis as Record<string, unknown>).indexedDB = new IDBFactory()
  vi.doMock('../src/data/firebase', () => ({ core: async () => fakeCore }))
  const sync = await import('../src/data/sync')
  const repo = await import('../src/data/repo')
  const db = await import('../src/data/db')
  await db.db()          // baza te naprave je odprta s svojo tovarno
  sync.startSync('u1')
  await sync.syncNow()
  return { sync, repo }
}
const meal = (id: string, kcal = 500) => ({ id, date: '2026-09-24', slot: 'kosilo' as const, name: id, kcal, source: 'photo' as const, thumb: null, createdAt: new Date().toISOString() })
const ride = (id: string, icu: string, start: string) => ({ id, source: 'intervals' as const, sport: 'kolo' as const, date: start.slice(0, 10), start, name: 'Vožnja', aiEligible: true, geoRetain: true, ext: { intervalsId: icu }, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() })
const ids = async (r: { repo: typeof import('../src/data/repo') }) => (await r.repo.allMeals()).map(m => m.id).sort()

afterEach(() => { for (const k of Object.keys(cloud)) delete cloud[k] })

describe('telefon + računalnik: obroki ne izginejo', () => {
  it('računalnik s staro kopijo in novo vožnjo ne pobriše obrokov s telefona', async () => {
    cloud['formaSync/u1'] = { kalorije: { stara: 'aplikacija' } }       // polje stare aplikacije
    const pc = await device()
    await pc.repo.saveProfile({ ...pc.repo.defaultProfile(), name: 'Blaž', onboardingDone: true }); await pc.sync.touch(); await pc.sync.syncNow()

    const phone = await device()
    expect((await phone.repo.loadProfile()).name).toBe('Blaž')
    await phone.repo.putMeal(meal('zajtrk')); await phone.repo.putMeal(meal('kosilo')); await phone.sync.touch(); await phone.sync.syncNow()

    // računalnik se ni uskladil, medtem uvozi vožnjo (postane »novejši«) — prej je tu prepisal oblak
    await pc.repo.addActivities([ride('pc1', 'i1', '2026-09-24T14:00:00Z')]); await pc.sync.touch()
    await pc.sync.syncNow()
    expect(await ids(pc)).toEqual(['kosilo', 'zajtrk'])

    await phone.sync.syncNow()
    expect(await ids(phone)).toEqual(['kosilo', 'zajtrk'])
    expect((await phone.repo.allActivities()).map(a => a.ext?.intervalsId)).toEqual(['i1'])
    expect(cloud['formaSync/u1']!.kalorije).toEqual({ stara: 'aplikacija' })

    // ista vožnja, uvožena še na telefonu (drug lokalni id) → povsod ena
    await phone.repo.addActivities([ride('ph1', 'i1', '2026-09-24T14:00:00Z')])
    await phone.sync.touch(); await phone.sync.syncNow(); await pc.sync.syncNow(); await phone.sync.syncNow()
    expect((await phone.repo.allActivities())).toHaveLength(1)
    expect((await pc.repo.allActivities())).toHaveLength(1)

    // izbris na telefonu + nov obrok na računalniku hkrati → izbris velja, nov obrok ostane
    await phone.repo.deleteMeal('zajtrk'); await phone.sync.touch()
    await pc.repo.putMeal(meal('vecerja')); await pc.sync.touch()
    await Promise.all([phone.sync.syncNow(), pc.sync.syncNow()])
    for (let i = 0; i < 2; i++) { await phone.sync.syncNow(); await pc.sync.syncNow() }
    expect(await ids(phone)).toEqual(['kosilo', 'vecerja'])
    expect(await ids(pc)).toEqual(['kosilo', 'vecerja'])

    // mirovanje: brez sprememb ni zapisov (naprave se ne »prepirajo«)
    const w = writes
    for (let i = 0; i < 3; i++) { await phone.sync.syncNow(); await pc.sync.syncNow() }
    expect(writes).toBe(w)
    phone.sync.stopSync(); pc.sync.stopSync()
  })
})
