import 'fake-indexeddb/auto'
import { describe, it, expect, vi, afterEach } from 'vitest'
import { IDBFactory } from 'fake-indexeddb'

/**
 * Dve napravi (telefon, računalnik), vsaka s svojo bazo, in en dokument v »oblaku« (Firestore v pomnilniku).
 * Preverja pravo pot: store → repo → sync → merge → oblak → druga naprava.
 */
type Doc = Record<string, unknown>
const cloud: Record<string, Doc> = {}
let writes = 0, txs = 0
// poslušalci dokumenta (onSnapshot) — vklopljeni samo v testu »v živo«
const live = { on: false, subs: new Map<string, Set<(s: unknown) => void>>() }
const snapOf = (path: string) => ({ metadata: { fromCache: false, hasPendingWrites: false }, exists: () => !!cloud[path], get: (fp: string) => fp.split('.').reduce<unknown>((o, k) => (o as Record<string, unknown> | undefined)?.[k], cloud[path]) })
const notify = (path: string) => setTimeout(() => { for (const f of live.subs.get(path) || []) f(snapOf(path)) }, 0)
const fakeCore = {
  fs: {},
  fsMod: {
    doc: (_fs: unknown, col: string, id: string) => ({ path: `${col}/${id}` }),
    get onSnapshot() {
      if (!live.on) return undefined
      return (ref: { path: string }, _o: unknown, next: (s: unknown) => void) => {
        const set = live.subs.get(ref.path) || new Set(); set.add(next); live.subs.set(ref.path, set)
        setTimeout(() => next(snapOf(ref.path)), 0)
        return () => { set.delete(next) }
      }
    },
    runTransaction: async (_fs: unknown, fn: (tx: unknown) => Promise<void>) => {
      txs++
      let pending: { path: string; data: Doc; opts: { mergeFields?: string[] } } | null = null
      const tx = {
        get: async (ref: { path: string }) => ({ exists: () => !!cloud[ref.path], data: () => JSON.parse(JSON.stringify(cloud[ref.path])) }),
        set: (ref: { path: string }, data: Doc, opts: { mergeFields?: string[] }) => { pending = { path: ref.path, data, opts } },
      }
      await fn(tx)
      const p = pending as unknown as { path: string; data: Doc; opts: { mergeFields?: string[] } } | null
      if (p) {
        writes++
        const cur = cloud[p.path] || {}
        // mergeFields: navedena polja se zamenjajo v celoti, druga ostanejo (stara aplikacija)
        const next: Doc = { ...cur }
        for (const f of p.opts?.mergeFields || Object.keys(p.data)) next[f] = JSON.parse(JSON.stringify(p.data[f]))
        cloud[p.path] = next
        notify(p.path)
      }
    },
  },
}

async function device() {
  vi.resetModules()
  ;(globalThis as Record<string, unknown>).indexedDB = new IDBFactory()
  vi.doMock('../src/data/firebase', () => ({ core: async () => fakeCore }))
  const sync = await import('../src/data/sync')
  const repo = await import('../src/data/repo')
  const db = await import('../src/data/db')
  await db.db()          // baza te naprave je odprta s svojo tovarno
  sync.startSync('u1')
  await sync.syncNow()
  return { sync, repo }
}
const meal = (id: string, kcal = 500) => ({ id, date: '2026-09-24', slot: 'kosilo' as const, name: id, kcal, source: 'photo' as const, thumb: null, createdAt: new Date().toISOString() })
const ride = (id: string, icu: string, start: string) => ({ id, source: 'intervals' as const, sport: 'kolo' as const, date: start.slice(0, 10), start, name: 'Vožnja', aiEligible: true, geoRetain: true, ext: { intervalsId: icu }, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() })
const ids = async (r: { repo: typeof import('../src/data/repo') }) => (await r.repo.allMeals()).map(m => m.id).sort()

afterEach(() => { for (const k of Object.keys(cloud)) delete cloud[k]; live.on = false; live.subs.clear() })
const tick = (ms = 30) => new Promise(r => setTimeout(r, ms))

describe('poslušanje oblaka namesto prenašanja vsakih 20 s', () => {
  it('druga naprava dobi obrok sama (brez klica), mirno stanje ne prenaša dokumenta', async () => {
    live.on = true
    const pc = await device(); await tick()
    const phone = await device(); await tick()
    await phone.repo.putMeal(meal('malica')); await phone.sync.touch(); await phone.sync.syncNow()
    await tick(80)                                   // poslušalec na računalniku → sam uskladi
    expect(await ids(pc)).toEqual(['malica'])
    // nič novega nikjer: usklajevanje je le preverba, brez transakcije (prej vsakih 20 s cel dokument)
    await tick(); const before = txs
    await pc.sync.syncNow(); await phone.sync.syncNow(); await pc.sync.syncNow()
    expect(txs).toBe(before)
    // sprememba na računalniku → telefon jo dobi prek poslušalca
    await pc.repo.putMeal(meal('vecerja')); await pc.sync.touch(); await pc.sync.syncNow()
    await tick(80)
    expect(await ids(phone)).toEqual(['malica', 'vecerja'])
    pc.sync.stopSync(); phone.sync.stopSync()
  })
})

describe('telefon + računalnik: obroki ne izginejo', () => {
  it('računalnik s staro kopijo in novo vožnjo ne pobriše obrokov s telefona', async () => {
    cloud['formaSync/u1'] = { kalorije: { stara: 'aplikacija' } }       // polje stare aplikacije
    const pc = await device()
    await pc.repo.saveProfile({ ...pc.repo.defaultProfile(), name: 'Blaž', onboardingDone: true }); await pc.sync.touch(); await pc.sync.syncNow()

    const phone = await device()
    expect((await phone.repo.loadProfile()).name).toBe('Blaž')
    await phone.repo.putMeal(meal('zajtrk')); await phone.repo.putMeal(meal('kosilo')); await phone.sync.touch(); await phone.sync.syncNow()

    // računalnik se ni uskladil, medtem uvozi vožnjo (postane »novejši«) — prej je tu prepisal oblak
    await pc.repo.addActivities([ride('pc1', 'i1', '2026-09-24T14:00:00Z')]); await pc.sync.touch()
    await pc.sync.syncNow()
    expect(await ids(pc)).toEqual(['kosilo', 'zajtrk'])

    await phone.sync.syncNow()
    expect(await ids(phone)).toEqual(['kosilo', 'zajtrk'])
    expect((await phone.repo.allActivities()).map(a => a.ext?.intervalsId)).toEqual(['i1'])
    expect(cloud['formaSync/u1']!.kalorije).toEqual({ stara: 'aplikacija' })

    // ista vožnja, uvožena še na telefonu (drug lokalni id) → povsod ena
    await phone.repo.addActivities([ride('ph1', 'i1', '2026-09-24T14:00:00Z')])
    await phone.sync.touch(); await phone.sync.syncNow(); await pc.sync.syncNow(); await phone.sync.syncNow()
    expect((await phone.repo.allActivities())).toHaveLength(1)
    expect((await pc.repo.allActivities())).toHaveLength(1)

    // izbris na telefonu + nov obrok na računalniku hkrati → izbris velja, nov obrok ostane
    await phone.repo.deleteMeal('zajtrk'); await phone.sync.touch()
    await pc.repo.putMeal(meal('vecerja')); await pc.sync.touch()
    await Promise.all([phone.sync.syncNow(), pc.sync.syncNow()])
    for (let i = 0; i < 2; i++) { await phone.sync.syncNow(); await pc.sync.syncNow() }
    expect(await ids(phone)).toEqual(['kosilo', 'vecerja'])
    expect(await ids(pc)).toEqual(['kosilo', 'vecerja'])

    // mirovanje: brez sprememb ni zapisov (naprave se ne »prepirajo«)
    const w = writes
    for (let i = 0; i < 3; i++) { await phone.sync.syncNow(); await pc.sync.syncNow() }
    expect(writes).toBe(w)
    phone.sync.stopSync(); pc.sync.stopSync()
  })
})
