// v3.49 OBROKI — vsakodnevni vpis obrokov in »naslednji obrok«: termin po načrtu dneva (ne samo po uri), pogost obrok v
// svoj termin, dan tekme po startu, dolga jutranja vožnja, opozorila samo za cele dneve, večerni nasvet, »Si ga opravil?«,
// polje se po shranjevanju izprazni, brez AI ročni vpis z opisom, popravek shranjenega opisa, Prehrana čez polnoč.
import 'fake-indexeddb/auto'
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, afterEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'prehrana', params: {} as Record<string, string> }, added: [] as any[], done: [] as any[] }))
vi.mock('@/state/store', async (orig) => ({
  ...(await orig<typeof import('../src/state/store')>()),
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  addMeal: async (m: unknown) => { S.added.push(m) },
  setPlanDone: async (...a: unknown[]) => { S.done.push(a) },
}))
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => S.route, subscribeRoute: () => () => undefined }))

import * as repo from '../src/data/repo'
import { Prehrana, eveningHint, frequentMeals } from '@/screens/Prehrana'
import { MealInput } from '@/ui/MealInput'
import { dayMealPlan, adjustToEaten } from '../src/domain/nutrition/dayplan'
import { dayMealsOf, nextSlotOf, slotFor, repeatSlot } from '../src/domain/nutrition/daymeals'
import { dailyTarget } from '../src/domain/nutrition/energy'
import { raceSoon } from '../src/domain/nutrition/race'
import { alerts, dayLogged } from '../src/domain/alerts'
import { FRANJA_2027 } from '../src/domain/training/planner'
import type { MealEntry, PlanDay, Profile } from '../src/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const NOW = '2026-10-01T08:00:00.000Z'
const TODAY = '2026-10-17'
const P = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, restHr: 55, maxHr: 200, lthr: 184, ftp: 240, ftpDate: '2026-09-20',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, hoursPerWeek: 14, baseHours: null,
  strength: { on: false, equipment: 'home', phases: null }, strengthDays: 0, goal: 'dirka', deficit: 400, neat: 1.4,
  event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', onboardingDone: true, trainTime: 'popoldne', createdAt: NOW, updatedAt: NOW,
  races: [], ...o,
} as Profile)
const planDay = (date: string, min: number, o: Partial<PlanDay> = {}): PlanDay => ({ id: 'r' + date, date, kind: 'kolo', title: 'Dolga Z2', desc: '', durationMin: min, zone: 'Z2', role: 'dolga', source: 'rules', createdAt: NOW, updatedAt: NOW, ...o })
const ride = (min: number, o: Record<string, unknown> = {}) => ({ kind: 'kolo' as const, durationMin: min, zone: 'Z2', role: 'dolga' as const, title: 'Dolga Z2', ...o })
const meal = (date: string, slot: MealEntry['slot'], kcal: number, o: Partial<MealEntry> = {}): MealEntry => ({ id: `${date}-${slot}-${kcal}-${o.name || ''}-${o.time || ''}`, date, slot, name: o.name || slot, kcal, source: 'manual', createdAt: NOW, time: o.time ?? null, ...o })
const T = { kcal: 2900, proteinG: 142, carbsG: 380, deficit: 400 }
const PP = { weightKg: 79, trainTime: 'popoldne' as const }

/* ---------- domena ---------- */

describe('B01 — »naslednji obrok« ne obtiči na delno pojedenem obroku', () => {
  const rest = dayMealPlan(PP, T, null)
  const zaj = rest.slots.find(s => s.key === 'zajtrk')!
  it('zajtrk 600 / 730 in kosilo: ob 13:30 naslednji ni zajtrk (prej ves dan zajtrk)', () => {
    expect(zaj.kcal).toBe(730)
    const ms = [meal(TODAY, 'zajtrk', 600, { time: '07:30' }), meal(TODAY, 'kosilo', 800, { time: '13:00' })]
    expect(nextSlotOf(adjustToEaten(rest, ms, T.kcal), ms, 13.5)!.key).toBe('malica')
    expect(nextSlotOf(adjustToEaten(rest, ms, T.kcal), ms, 19)!.key).toBe('vecerja')
  })
  it('samo zajtrk 600: ob 13:30 kosilo; delno pojeden zajtrk (300) je naslednji samo v svojem času', () => {
    const z6 = [meal(TODAY, 'zajtrk', 600, { time: '07:30' })]
    expect(nextSlotOf(adjustToEaten(rest, z6, T.kcal), z6, 13.5)!.key).toBe('kosilo')
    expect(nextSlotOf(adjustToEaten(rest, z6, T.kcal), z6, 9)!.key).toBe('kosilo')       // 82 % pojedeno = zajtrk je bil
    const z3 = [meal(TODAY, 'zajtrk', 300, { time: '07:30' })]
    expect(nextSlotOf(adjustToEaten(rest, z3, T.kcal), z3, 9)!.key).toBe('zajtrk')
    expect(nextSlotOf(adjustToEaten(rest, z3, T.kcal), z3, 12)!.key).toBe('kosilo')
  })
  it('vožnja za nami: obrok pred njo ni več »naslednji«', () => {
    const p = P({ trainTime: 'zvecer' })
    const plan = [planDay(TODAY, 90, { done: { at: NOW } })]
    const target = dailyTarget(p, [], plan, TODAY, { today: TODAY, hour: 20 })!
    const ms = [meal(TODAY, 'zajtrk', 700, { time: '07:30' }), meal(TODAY, 'kosilo', 900, { time: '13:00' })]
    const dm = dayMealsOf({ p, target, plan, activities: [], meals: ms, recentMeals: [], weather: null, day: TODAY, today: TODAY })
    expect(dm.dp.slots.map(s => s.key)).toEqual(['zajtrk', 'kosilo', 'pred', 'obnova'])
    expect(nextSlotOf(dm.dp, ms, 18)!.key).toBe('obnova')
    // kosilo »2–3 h pred vožnjo« ostane na vrsti, če je bila vožnja (»popoldne«) opravljena že dopoldne
    const pp = P(), plan2 = [planDay(TODAY, 105, { done: { at: NOW } })]
    const dm2 = dayMealsOf({ p: pp, target: dailyTarget(pp, [], plan2, TODAY, { today: TODAY, hour: 12 })!, plan: plan2, activities: [], meals: ms.slice(0, 1), recentMeals: [], weather: null, day: TODAY, today: TODAY })
    expect(nextSlotOf(dm2.dp, ms.slice(0, 1), 12)!.key).toBe('kosilo')
  })
})

describe('B02 — dan tekme: obroki po startu, ne po »kdaj treniraš«', () => {
  const RD = '2027-06-13'
  const franja = planDay(RD, 310, { role: 'dirka', zone: 'dirka', title: 'Maraton Franja' })
  for (const trainTime of ['popoldne', 'zjutraj', 'zvecer'] as const) {
    it(`${trainTime}: zajtrk 3 h pred startom z vsaj 2 g OH na kg, pred startom, po tekmi, večerja`, () => {
      const p = P({ trainTime })
      const t = dailyTarget(p, [], [franja], RD, { today: RD, hour: 5 })!
      const dp = dayMealPlan(p, t, franja, { race: raceSoon(p, RD) })
      expect(dp.slots.map(s => s.key)).toEqual(['zajtrk', 'pred', 'obnova', 'vecerja'])
      expect(dp.slots.map(s => s.label)).toEqual(['Zajtrk pred tekmo', 'Pred startom', 'Po tekmi', 'Večerja'])
      expect(dp.slots[0]!.when).toBe('3 h pred startom')
      expect(dp.slots[0]!.carbsG).toBeGreaterThanOrEqual(2 * 79)
      for (const s of dp.slots) expect(`${s.label} ${s.when}`).not.toMatch(/pred vožnjo|2–3 h pred|45–60 min/)
      // malo vlaknin do starta, po tekmi normalno (v3.48); OH obrokov + na kolesu = OH dneva
      expect(dp.slots.map(s => !!s.lf)).toEqual([true, true, false, false])
      expect(dp.slots.reduce((a, s) => a + s.carbsG, 0) + (dp.onBike?.carbs || 0)).toBe(t.carbsG)
      for (const s of dp.slots) expect(s.carbsG * 4 + s.proteinG * 4).toBeLessThanOrEqual(s.kcal + 4)
      expect(dp.tip).toMatch(/zajtrk 3 h prej/)
    })
  }
  it('druga (kratka) tekma: zajtrk 2–3 h pred startom; »Na kolesu« je za obrokom pred startom', () => {
    const kron = { id: 'k', name: 'Kronometer Vodice', date: '2026-10-23', distanceKm: 20, type: 'kronometer' as const, prio: 'B' as const }
    const p = P({ races: [kron] })
    const d = planDay('2026-10-23', 30, { role: 'dirka', zone: 'dirka', title: 'Kronometer', raceId: 'k' })
    const t = dailyTarget(p, [], [d], '2026-10-23', { today: '2026-10-23', hour: 6 })!
    const dp = dayMealPlan(p, t, d, { race: raceSoon(p, '2026-10-23') })
    expect(dp.slots[0]!.when).toBe('2–3 h pred startom')
    expect(dp.slots.filter(s => s.beforeRide).map(s => s.key)).toEqual(['zajtrk', 'pred'])
  })
})

describe('B24 — dolga jutranja vožnja: zajtrk pred njo, kosilo po njej', () => {
  it('4 h zjutraj: zajtrk pred vožnjo · po vožnji kosilo · malica · večerja (prej »Po vožnji — zajtrk« in takoj kosilo)', () => {
    const dp = dayMealPlan({ ...PP, trainTime: 'zjutraj' }, { kcal: 4200, proteinG: 158, carbsG: 640 }, ride(240))
    expect(dp.slots.map(s => s.key)).toEqual(['zajtrk', 'obnova', 'malica', 'vecerja'])
    expect(dp.slots.map(s => s.label)).toEqual(['Zajtrk pred vožnjo', 'Po vožnji — kosilo', 'Malica', 'Večerja'])
    expect(dp.slots[0]!.beforeRide).toBe(true)
    expect(dp.slots[1]!.slot).toBe('kosilo')
    expect(dp.slots.reduce((a, s) => a + s.carbsG, 0) + (dp.onBike?.carbs || 0)).toBe(640)
    expect(dp.tip).toMatch(/zajtrk pred vožnjo in kosilo po njej/)
  })
  it('kratka jutranja vožnja ostane, kot je', () => {
    expect(dayMealPlan({ ...PP, trainTime: 'zjutraj' }, T, ride(105)).slots.map(s => s.key)).toEqual(['pred', 'obnova', 'kosilo', 'vecerja'])
  })
})

describe('B08 — obrok novega vpisa po načrtu dneva', () => {
  it('dan brez vožnje: kosilo ob 15:30 je kosilo, dokler ni vpisano (prej malica)', () => {
    const dp = dayMealPlan(PP, T, null)
    expect(slotFor('15:30', dp, [meal(TODAY, 'zajtrk', 550)])).toBe('kosilo')
    expect(slotFor('15:30', dp, [meal(TODAY, 'zajtrk', 550), meal(TODAY, 'kosilo', 900)])).toBe('malica')
    expect(slotFor('16:45', dp, [])).toBe('malica')
    expect(slotFor('08:00', dp, [])).toBe('zajtrk')
    expect(slotFor('08:00', null, [])).toBe('zajtrk')
  })
  it('večerna vožnja: malica pred njo ostane malica, večerja po njej ob 21:15 je večerja (prej večerja in »drugo«)', () => {
    const p = P({ trainTime: 'zvecer' })
    const ms = [meal(TODAY, 'zajtrk', 700), meal(TODAY, 'kosilo', 900)]
    const before = [planDay(TODAY, 90)], after = [planDay(TODAY, 90, { done: { at: NOW } })]
    const dmB = dayMealsOf({ p, target: dailyTarget(p, [], before, TODAY, { today: TODAY, hour: 17 })!, plan: before, activities: [], meals: ms, recentMeals: [], weather: null, day: TODAY, today: TODAY })
    const dmA = dayMealsOf({ p, target: dailyTarget(p, [], after, TODAY, { today: TODAY, hour: 21 })!, plan: after, activities: [], meals: ms, recentMeals: [], weather: null, day: TODAY, today: TODAY })
    expect(slotFor('17:00', dmB.dp, ms)).toBe('malica')
    expect(slotFor('19:30', dmB.dp, ms)).toBe('vecerja')
    expect(slotFor('17:00', dmB.dp, [...ms, meal(TODAY, 'malica', 250)])).toBe('vecerja')
    expect(slotFor('21:15', dmA.dp, ms)).toBe('vecerja')
    expect(slotFor('21:15', dmA.dp, [...ms, meal(TODAY, 'vecerja', 850)])).toBe('drugo')
  })
  it('dolga jutranja vožnja za nami: obrok ob 11:30 je kosilo po vožnji; dan tekme pred startom ne spremeni večerje', () => {
    const p = P({ trainTime: 'zjutraj' })
    const plan = [planDay(TODAY, 240, { done: { at: NOW } })]
    const dm = dayMealsOf({ p, target: dailyTarget(p, [], plan, TODAY, { today: TODAY, hour: 11 })!, plan, activities: [], meals: [meal(TODAY, 'zajtrk', 800)], recentMeals: [], weather: null, day: TODAY, today: TODAY })
    expect(slotFor('11:30', dm.dp, [meal(TODAY, 'zajtrk', 800)])).toBe('kosilo')
    const race = dayMealPlan(PP, T, ride(310, { role: 'dirka', zone: 'dirka' }))
    expect(slotFor('17:30', race, [meal(TODAY, 'zajtrk', 900)])).toBe('vecerja')
  })
})

describe('B09 — pogost obrok v svoj termin', () => {
  const dp = dayMealPlan(PP, T, null)
  it('zajtrk ob 13:10: še ni vpisan → zajtrk ob 7:30 (vpis za nazaj); že vpisan → zdajšnji obrok', () => {
    expect(repeatSlot('zajtrk', '13:10', [], dp)).toEqual({ slot: 'zajtrk', time: '07:30', back: true })
    expect(repeatSlot('zajtrk', '13:10', [meal(TODAY, 'zajtrk', 600)], dp)).toEqual({ slot: 'kosilo', time: '13:10', back: false })
    expect(repeatSlot('zajtrk', '08:10', [], dp)).toEqual({ slot: 'zajtrk', time: '08:10', back: false })
    // večerja ob 13:10 ni vpis za nazaj (njen čas šele pride), malica je lahko kadar koli
    expect(repeatSlot('vecerja', '13:10', [], dp)).toEqual({ slot: 'kosilo', time: '13:10', back: false })
    expect(repeatSlot('malica', '13:10', [], dp)).toEqual({ slot: 'malica', time: '13:10', back: false })
    // kosilo ob 15:30 (pozno kosilo po načrtu) ostane kosilo ob 15:30
    expect(repeatSlot('kosilo', '15:30', [meal(TODAY, 'zajtrk', 600)], dp)).toEqual({ slot: 'kosilo', time: '15:30', back: false })
  })
  it('pogosti obroki: običajni obrok tega imena, zdajšnji obrok na začetku', () => {
    const oats = (d: string, slot: MealEntry['slot'] = 'zajtrk') => meal(d, slot, 620, { name: 'Ovseni kosmiči', time: '07:30' })
    const recent = [oats('2026-10-10'), oats('2026-10-11'), oats('2026-10-12', 'kosilo'), meal('2026-10-11', 'kosilo', 900, { name: 'Riž s piščancem' }), meal('2026-10-12', 'kosilo', 900, { name: 'Riž s piščancem' }), oats('2026-10-13')]
    const f = frequentMeals(recent)
    expect(f.map(m => [m.name, m.slot])).toEqual([['Ovseni kosmiči', 'zajtrk'], ['Riž s piščancem', 'kosilo']])
    expect(frequentMeals(recent, 'kosilo').map(m => m.name)).toEqual(['Riž s piščancem', 'Ovseni kosmiči'])
  })
})

describe('B18 + B33 — opozorila samo za cele dneve (prazno = neznano, ne 0)', () => {
  const base = { profile: P(), activities: [], plan: [], checkins: [], today: TODAY, hour: 12 }
  it('dva dni samo zajtrk in kosilo (pozabljena večerja): ni rdečega opozorila, ampak vprašanje o večerji', () => {
    const ms = [['2026-10-16', 700, 700], ['2026-10-15', 650, 650]].flatMap(([d, z, k]) => [meal(d as string, 'zajtrk', z as number, { time: '07:30' }), meal(d as string, 'kosilo', k as number, { time: '13:00' })])
    const a = alerts({ ...base, recentMeals: ms })
    expect(a.some(x => x.kind === 'bad')).toBe(false)
    expect(a.find(x => /večerje/.test(x.text))).toMatchObject({ kind: 'info', text: 'Za petek in četrtek ni vpisane večerje — dodaj jo, da so številke prave.' })
  })
  it('dnevi s 4 obroki pod varno mejo → rdeče opozorilo ostane (varovalka nespremenjena)', () => {
    const ms = ['2026-10-16', '2026-10-15', '2026-10-14'].flatMap(d => (['zajtrk', 'kosilo', 'malica', 'vecerja'] as const).map(s => meal(d, s, 300, { proteinG: 30 })))
    expect(alerts({ ...base, recentMeals: ms })[0]).toMatchObject({ kind: 'bad', text: expect.stringMatching(/^Vnos 3 dni zapored pod varno mejo/) })
    // dva obroka z večerjo sta cel dan
    expect(dayLogged([meal(TODAY, 'kosilo', 900), meal(TODAY, 'vecerja', 900)])).toBe(true)
    expect(dayLogged([meal(TODAY, 'kosilo', 900), meal(TODAY, 'med_vadbo', 400, { time: '18:00' })])).toBe(false)
  })
  it('ročni vpisi brez beljakovin: ni opozorila »Beljakovine pod ciljem«; z znanimi beljakovinami ostane', () => {
    const days = ['2026-10-16', '2026-10-15', '2026-10-14']
    const blind = days.flatMap(d => (['zajtrk', 'kosilo', 'vecerja'] as const).map(s => meal(d, s, 850, { proteinG: null })))
    expect(alerts({ ...base, recentMeals: blind }).some(x => /Beljakovine/.test(x.text))).toBe(false)
    const low = days.flatMap(d => (['zajtrk', 'kosilo', 'vecerja'] as const).map(s => meal(d, s, 850, { proteinG: 25 })))
    expect(alerts({ ...base, recentMeals: low }).some(x => /^Beljakovine pod ciljem 3 dni zapored/.test(x.text))).toBe(true)
    // 2 od 3 obrokov z beljakovinami (67 % kalorij) ne zadošča; gorivo na kolesu šteje kot znano (0 g)
    const mixed = days.flatMap(d => [meal(d, 'zajtrk', 850, { proteinG: 25 }), meal(d, 'kosilo', 850, { proteinG: 25 }), meal(d, 'vecerja', 850, { proteinG: null })])
    expect(alerts({ ...base, recentMeals: mixed }).some(x => /Beljakovine/.test(x.text))).toBe(false)
    const fuel = days.flatMap(d => [...(['zajtrk', 'kosilo', 'vecerja'] as const).map(s => meal(d, s, 850, { proteinG: 25 })), meal(d, 'med_vadbo', 500, { proteinG: null })])
    expect(alerts({ ...base, recentMeals: fuel }).some(x => /^Beljakovine pod ciljem/.test(x.text))).toBe(true)
  })
})

describe('B23 — »ne jej na silo« šele po večerji ali ob 20:30, nikoli pred vožnjo', () => {
  it('ob 18:10 brez večerje ne, pred vožnjo ne; po večerji in pozno zvečer da', () => {
    const zk = [meal(TODAY, 'zajtrk', 700), meal(TODAY, 'kosilo', 800)]
    expect(eveningHint(18 + 10 / 60, zk, { plannedBurn: 983 })).toBe(false)
    expect(eveningHint(18 + 10 / 60, zk, { plannedBurn: 0 })).toBe(false)
    expect(eveningHint(21, [...zk, meal(TODAY, 'vecerja', 600)], { plannedBurn: 0 })).toBe(true)
    expect(eveningHint(20.6, zk, { plannedBurn: 0 })).toBe(true)
    expect(eveningHint(19, [...zk, meal(TODAY, 'vecerja', 600)], { plannedBurn: 500 })).toBe(false)
    expect(eveningHint(17, [...zk, meal(TODAY, 'vecerja', 600)], { plannedBurn: 0 })).toBe(false)
  })
})

/* ---------- zaslon ---------- */

let div: HTMLDivElement, root: Root
async function render(el: React.ReactElement) {
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root.render(el) })
  return text()
}
const text = () => (document.body.textContent || '').replace(/[\u00a0\u202f]/g, ' ')
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(b.textContent || '') || re.test(b.getAttribute('aria-label') || ''))
async function click(el: Element | undefined | null) { expect(el).toBeTruthy(); await act(async () => { (el as HTMLElement).click(); await new Promise(r => setTimeout(r, 0)) }) }
async function typeIn(el: Element | null, v: string) {
  expect(el).toBeTruthy()
  const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype
  await act(async () => { Object.getOwnPropertyDescriptor(proto, 'value')!.set!.call(el, v); el!.dispatchEvent(new Event('input', { bubbles: true })) })
}
afterEach(async () => { await act(async () => root?.unmount()); div?.remove(); vi.useRealTimers(); S.added.length = 0; S.done.length = 0; S.route = { name: 'prehrana', params: {} } })

function setState(o: { meals?: MealEntry[]; recent?: MealEntry[]; plan?: PlanDay[]; profile?: Profile; time?: string; today?: string } = {}) {
  const today = o.today || TODAY
  vi.useFakeTimers({ toFake: ['Date'] })
  vi.setSystemTime(new Date(`${today}T${o.time || '08:30'}:00`))
  const meals = o.meals || []
  S.state = { ready: true, settings: repo.defaultSettings(), changes: [], toast: null, sync: { state: 'off' }, authKnown: true, pro: false, wellness: null, checkinToday: null, today, profile: o.profile || P(), plan: o.plan || [planDay(today, 105)], activities: [], mealsToday: meals, recentMeals: [...(o.recent || []), ...meals], checkins: [], weather: null, user: null }
}

describe('Prehrana — vpis in naslednji obrok', () => {
  it('B09: tap na pogost zajtrk ob 13:10 ga vpiše kot zajtrk ob 7:30 (prej »Kosilo · 13:10«)', async () => {
    const oats = (d: string) => meal(d, 'zajtrk', 620, { name: 'Ovseni kosmiči z jogurtom', time: '07:30' })
    setState({ time: '13:10', recent: [oats('2026-10-14'), oats('2026-10-15')], plan: [] })
    await render(<Prehrana />)
    await click(document.querySelector('[aria-label="Pogosti obroki"] button'))
    expect(S.added[0]).toMatchObject({ name: 'Ovseni kosmiči z jogurtom', slot: 'zajtrk', time: '07:30', date: TODAY })
  })
  it('B08: »Dodaj …« ob 15:30 brez kosila je kosilo', async () => {
    setState({ time: '15:30', meals: [meal(TODAY, 'zajtrk', 550, { time: '07:30' })], plan: [] })
    expect(await render(<Prehrana />)).toMatch(/Dodaj kosilo/)
  })
  it('B25: ob 21:30 neopravljena vožnja — »Si ga opravil?« z gumbom, ki jo označi', async () => {
    setState({ time: '21:30', meals: [meal(TODAY, 'zajtrk', 700, { time: '07:30' })] })
    const t = await render(<Prehrana />)
    expect(t).toMatch(/Trening »Dolga Z2« še ni zabeležen, zato ga ne štejem v cilj \(−[\d ]+ kcal\)\. Si ga opravil\?/)
    await click(document.querySelector('.missed-ask button'))
    expect(S.done[0]).toEqual(['r' + TODAY, true])
    // označena (»Opravil«) šteje po načrtu tudi po 21h
    const p = P(), done = [planDay(TODAY, 105, { done: { at: NOW } })]
    expect(dailyTarget(p, [], done, TODAY, { today: TODAY, hour: 21.5 })!.estimatedBurn).toBeGreaterThan(0)
  })
  it('B25: pred 21h (vožnja še lahko pride) vprašanja ni', async () => {
    setState({ time: '20:30' })
    expect(await render(<Prehrana />)).not.toMatch(/Si ga opravil/)
  })
  it('B11: brez povezave opis gre v ročni vpis (ime = opis, razlaga), ne samo obvestilo', async () => {
    setState({ time: '12:30', plan: [] })
    const on = Object.getOwnPropertyDescriptor(Navigator.prototype, 'onLine')
    Object.defineProperty(navigator, 'onLine', { configurable: true, get: () => false })
    try {
      await render(<Prehrana />)
      await typeIn(document.querySelector('#meal-desc'), 'dve jajci in rezina kruha')
      await click(btn(/Oceni kalorije/))
      expect((document.querySelector('#meal-name') as HTMLInputElement)?.value).toBe('dve jajci in rezina kruha')
      // (v3.49 CILJ, B30) jajca in kruh so v tabeli živil — ročni vpis ima že oceno brez AI
      expect(text()).toMatch(/AI ta hip ni dosegljiv — spodaj je ocena brez AI/)
      expect(document.activeElement?.id).toBe('meal-kcal')
    } finally { delete (navigator as { onLine?: boolean }).onLine; if (on) Object.defineProperty(Navigator.prototype, 'onLine', on) }
  })
  it('B35: urejanje shranjenega vpisa iz opisa pokaže opis in »Oceni znova«', async () => {
    setState({ time: '12:30', plan: [], meals: [meal(TODAY, 'zajtrk', 300, { name: 'Jajca s kruhom', source: 'text', said: 'dve jajci in rezina kruha', time: '07:30' })] })
    await render(<Prehrana />)
    await click(btn(/^Uredi: Jajca s kruhom$/))
    expect((document.querySelector('#meal-desc2') as HTMLTextAreaElement)?.value).toBe('dve jajci in rezina kruha')
    expect(btn(/Oceni znova/)).toBeTruthy()
  })
  it('B02: na dan tekme »Na kolesu« enkrat (za obrokom pred startom), zajtrk pred tekmo', async () => {
    const event = { name: 'Maraton Franja', date: TODAY, distanceKm: 156 }
    setState({ time: '05:00', profile: P({ event }), plan: [planDay(TODAY, 310, { role: 'dirka', zone: 'dirka', title: 'Maraton Franja' })] })
    await render(<Prehrana />)
    await click(btn(/cel dan po načrtu/))
    const card = [...document.querySelectorAll('.card')].find(c => /po načrtu/.test(c.querySelector('h2')?.textContent || ''))!.textContent!
    expect(card.match(/Na kolesu/g)?.length).toBe(1)
    expect(card).toMatch(/Zajtrk pred tekmo · 3 h pred startom.*Pred startom.*Na kolesu.*Po tekmi/)
  })
  it('D05: Prehrana čez polnoč preskoči na nov dan (prej je ostala na včerajšnjem)', async () => {
    setState({ time: '23:57' })
    expect(await render(<Prehrana />)).toMatch(/Sobota, 17\. oktobra/)
    vi.setSystemTime(new Date('2026-10-18T00:05:00'))
    await act(async () => { S.state = { ...S.state, today: '2026-10-18', mealsToday: [], plan: [] }; S.subs.forEach(f => f()) })
    expect(text()).toMatch(/Nedelja, 18\. oktobra/)
    expect(text()).not.toMatch(/Vpis za soboto/)
  })
})

describe('B10 — po shranjevanju se polje »Dodaj obrok« izprazni', () => {
  it('MealInput: clearKey 0 → 1 izprazni besedilo', async () => {
    const el = (k: number) => <MealInput onText={() => undefined} onPhoto={() => undefined} clearKey={k} />
    await render(el(0))
    await typeIn(document.querySelector('#meal-desc'), 'dve jajci in rezina kruha')
    expect((document.querySelector('#meal-desc') as HTMLTextAreaElement).value).toBe('dve jajci in rezina kruha')
    await act(async () => { root.render(el(1)) })
    expect((document.querySelector('#meal-desc') as HTMLTextAreaElement).value).toBe('')
  })
})
