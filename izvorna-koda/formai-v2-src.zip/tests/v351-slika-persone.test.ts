// v3.51 SLIKA-PERSONE — trening s slike (posnetek, tabla, slika sebe) in poti person (F-H, A03, F14, F16). AI je prestrežen.
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach } from 'vitest'

const h = vi.hoisted(() => ({ json: {} as unknown, fail: null as null | { kind: string; msg: string } }))
vi.mock('../src/domain/ai/client', () => {
  class AiError extends Error { kind: string; constructor(kind: string, m: string) { super(m); this.kind = kind } }
  return {
    AiError,
    askText: async () => '',
    askJson: async () => { if (h.fail) throw new AiError(h.fail.kind, h.fail.msg); return JSON.parse(JSON.stringify(h.json)) },
  }
})
vi.mock('../src/domain/ai/image', () => ({ fileToBase64Resized: async () => ({ data: 'SLIKA', mime: 'image/jpeg', thumb: '' }), exifStamp: async () => null }))

import { doneFromPhoto, workoutFromPhoto, selfFromPhoto, NO_SHOT, NO_WORKOUT, NO_SELF, unsupportedText } from '../src/domain/ai/photoTraining'
import { AiError } from '../src/domain/ai/client'
import { pickDoneDay, shotErrors, raceLike, draftFromOut, durationNote, kgOf, selfFromOut, matchExercise, startNowWarn, unsupportedKind, type PhotoWorkout } from '../src/domain/training/fromPhoto'
import { sportOfType, titleWithDur, addDays } from '../src/domain/training/load'
import { stepsFor, structureLines } from '../src/domain/training/workout'
import { candidates, EXERCISES, exByName } from '../src/domain/training/exercises'
import { templateFor, TEMPLATES } from '../src/ui/figure/templates'
import { kindLabelOf } from '../src/ui/primitives'
import { localAdvice, localReview, type LocalCoachCtx } from '../src/domain/coach/local'
import { fueling, dailyTarget, proteinFoods, eveningSnack } from '../src/domain/nutrition/energy'
import { estimateMeal } from '../src/domain/nutrition/localMeal'
import { mealTypeFromText } from '../src/domain/nutrition/slots'
import { normalizeFocus, profileFromFocus } from '../src/domain/focus/model'
import { buildFocusWeek, otherSportKcal } from '../src/domain/training/focusPlan'
import { afterSick } from '../src/ui/SickSheet'
import { bikePauseOf, othersLeft } from '../src/ui/WeekPauseSheet'
import { introEmpty } from '../src/ui/PlanHero'
import { addSheetFor } from '../src/screens/Plan'
import { hrWord, stepAnnounce } from '../src/screens/Vadba'
import { buildWeek, weekContext, strongStart, FRANJA_2027 } from '../src/domain/training/planner'
import type { Activity, PlanDay, Profile } from '../src/domain/types'

const TODAY = '2026-10-23'   // petek
const NOW = `${TODAY}T08:00:00.000Z`
const P = { aiConsentAt: NOW, aiConsentV: 3, age: 30, sex: 'm', weightKg: 78, heightCm: 182, ftp: 250, lthr: 172, maxHr: 195, restHr: 50, gear: { bikeOutdoor: true, trainer: true, noBike: false }, onboardingDone: true } as unknown as Profile
const file = () => new File(['x'], 'slika.jpg', { type: 'image/jpeg' })
const day = (o: Partial<PlanDay> & Pick<PlanDay, 'id' | 'date' | 'kind'>): PlanDay => ({ title: o.kind === 'pocitek' ? 'Počitek' : 'Trening', desc: '', durationMin: 60, source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })
const act = (o: Partial<Activity>): Activity => ({ id: 'a1', source: 'screenshot', sport: 'kolo', date: TODAY, name: 'Vožnja', durationMin: 60, aiEligible: true, geoRetain: false, createdAt: NOW, updatedAt: NOW, ...o })

beforeEach(() => { h.json = {}; h.fail = null })

describe('H01/A03/F16: posnetek ne odkljuka tekme ali drugega športa sam', () => {
  const race = day({ id: 'r', date: TODAY, kind: 'kolo', title: 'Kronometer Vodice — 18 km', durationMin: 30, role: 'dirka', raceId: 'kv' })
  it('Zwift 62 min z vstopa na kartici tekme → dodatna vadba; brez vstopa (Uvoz) tudi 95-min vožnja ne', () => {
    expect(raceLike(race)).toBe(true)
    expect(pickDoneDay(act({ durationMin: 62, distKm: 31.4, name: 'Zwift — Watopia' }), [race], TODAY, 'r')).toBeNull()
    expect(pickDoneDay(act({ durationMin: 95, distKm: 41, name: 'Jutranja vožnja' }), [race], TODAY)).toBeNull()
    // trenažer brez imena aplikacije
    expect(pickDoneDay(act({ durationMin: 31, trainer: true }), [race], TODAY, 'r')).toBeNull()
  })
  it('prava tekma (32 min, zunaj) z vstopa na kartici tekme se odkljuka; brez vstopa ne', () => {
    expect(pickDoneDay(act({ durationMin: 32, name: 'Kronometer' }), [race], TODAY, 'r')?.id).toBe('r')
    expect(pickDoneDay(act({ durationMin: 32, name: 'Kronometer' }), [race], TODAY)).toBeNull()
  })
  it('test FTP in drug šport (hribi namesto kolesa) brez vstopa na tem dnevu ne; navadna vožnja istega dne da', () => {
    const test = day({ id: 't', date: TODAY, kind: 'test', title: 'Test FTP', durationMin: 60 })
    expect(pickDoneDay(act({ durationMin: 60 }), [test], TODAY)).toBeNull()
    const z2 = day({ id: 'k', date: TODAY, kind: 'kolo', title: 'Z2', durationMin: 60 })
    expect(pickDoneDay(act({ sport: 'pohod', durationMin: 70 }), [z2], TODAY)).toBeNull()
    expect(pickDoneDay(act({ sport: 'pohod', durationMin: 70 }), [z2], TODAY, 'k')?.id).toBe('k')
    expect(pickDoneDay(act({ durationMin: 55 }), [z2, race], TODAY)?.id).toBe('k')
  })
})

describe('H02: razdalja in vzpon glede na čas ob vsakem shranjevanju', () => {
  it('tek 45 min · 300 km in kolo 60 min · 2 500 m → napaka (tudi, ko trajanje vpišeš šele v predogledu)', () => {
    const e = shotErrors({ sport: 'tek', durationMin: 45, distKm: 300, elevM: null, avgHr: null, avgPower: null, kcal: null })
    expect(e.dist).toMatch(/Razdalja ne gre s tem časom \(400 km\/h\)/)
    expect(shotErrors({ sport: 'kolo', durationMin: 60, distKm: 30, elevM: 2500, avgHr: null, avgPower: null, kcal: null }).elev).toMatch(/Vzpon ne gre s tem časom/)
    expect(shotErrors({ sport: 'tek', durationMin: 45, distKm: 9, elevM: 100, avgHr: 150, avgPower: null, kcal: null })).toEqual({})
    // moč (joga s posnetka) in plavanje nimata tekaške meje — 300 km v 45 min vseeno ne gre
    expect(shotErrors({ sport: 'moc', durationMin: 45, distKm: 300, elevM: null, avgHr: null, avgPower: null, kcal: null }).dist).toBeTruthy()
    expect(shotErrors({ sport: 'plavanje', durationMin: 60, distKm: 30, elevM: null, avgHr: null, avgPower: null, kcal: null }).dist).toBeTruthy()
    expect(shotErrors({ sport: 'plavanje', durationMin: 60, distKm: 3, elevM: null, avgHr: null, avgPower: null, kcal: null })).toEqual({})
  })
})

describe('H07 (+F08): sportOfType po celih besedah', () => {
  it('joga ni tek, NordicSki ni hoja; jogging, Run, VirtualRun, TrailRun so tek', () => {
    expect(sportOfType('joga')).toBe('moc')
    expect(sportOfType('Yoga')).toBe('moc')
    expect(sportOfType('NordicSki')).toBe('drugo')
    expect(sportOfType('AlpineSki')).toBe('drugo')
    for (const t of ['jogging', 'Run', 'VirtualRun', 'TrailRun', 'tek']) expect(sportOfType(t), t).toBe('tek')
    expect(sportOfType('Nordic walking')).toBe('pohod')
    expect(sportOfType('Ride')).toBe('kolo')
  })
})

describe('H32/H33/H40: posnetek — ime, datum, neberljiv odgovor', () => {
  it('ime brez oznak, prihodnji datum po slovensko', async () => {
    h.json = { app: 'garmin', sport: 'kolo', datum: '2027-03-01', trajanje_min: 60, razdalja_km: 30, ime: '<b>**Jutranja**</b>', zanesljivost: 'visoka' }
    const a = await doneFromPhoto(P, file(), TODAY)
    expect(a.name).toBe('Jutranja')
    expect(a.notes).toContain('Datum s posnetka (1. 3. 2027) je v prihodnosti')
    expect(a.notes).not.toContain('2027-03-01')
  })
  it('odgovor, ki ni JSON: sporočilo lista z namigom; druge napake ostanejo', async () => {
    h.fail = { kind: 'parse', msg: 'AI odgovor ni bil v pričakovani obliki. Poskusi znova.' }
    await expect(doneFromPhoto(P, file(), TODAY)).rejects.toThrow(NO_SHOT)
    await expect(workoutFromPhoto(P, file())).rejects.toThrow(NO_WORKOUT)
    await expect(selfFromPhoto(P, file())).rejects.toThrow(NO_SELF)
    h.fail = { kind: 'network', msg: 'Ni povezave.' }
    await expect(doneFromPhoto(P, file(), TODAY)).rejects.toThrow('Ni povezave.')
    expect(AiError).toBeTruthy()
  })
})

describe('H14: plavanje in veslanje s slike', () => {
  it('trening je bil najden, a ni podprt — ne »Na sliki nisem našel treninga«', async () => {
    h.json = { vrsta: 'plavanje', naslov: 'Plavanje 10 × 100', koraki: [{ tip: 'ponovitve', ponovitve: 10, delo_s: 120, odmor_s: 20 }] }
    await expect(workoutFromPhoto(P, file())).rejects.toThrow(unsupportedText('Plavanja'))
    expect(unsupportedKind({ vrsta: 'veslo' })).toBe('Veslanja')
    expect(unsupportedText('Plavanja')).toBe('Plavanja še ne znam dodati v načrt — ko ga opraviš, ga vpiši ročno med vadbe (Aktivnosti).')
    // veslo kot vaja v WOD-u ostane moč
    h.json = { vrsta: 'veslo', vaje: [{ ime: 'Burpees', serije: 3, ponovitve: 10 }] }
    expect((await workoutFromPhoto(P, file())).kind).toBe('moc')
  })
})

describe('H15/H34/H18/H51: osnutek s slike', () => {
  const run: PhotoWorkout = { kind: 'tek', title: 'Intervali na stezi', minutes: 50, exercises: [], note: '',
    blocks: [{ kind: 'ogrevanje', min: 15, n: null, workS: null, restS: null, at: '' }, { kind: 'ponovitve', min: null, n: 6, workS: 400, restS: 180, at: 'RPE 8' }, { kind: 'iztek', min: 10, n: null, workS: null, restS: null, at: '' }] }
  it('trajanje v polju, krajše od korakov: povej, kaj gre v načrt (in ponudi vrednost)', () => {
    const n = durationNote(run)!
    expect(n.text).toMatch(/^Koraki trajajo \d+ min — v načrt gre \d+ min\.$/)
    expect(n.use).toBeGreaterThan(50)
    expect(durationNote({ ...run, minutes: 120 })).toBeNull()
    const moc: PhotoWorkout = { kind: 'moc', title: 'WOD', minutes: 20, blocks: [], note: '', exercises: Array.from({ length: 6 }, (_, i) => ({ name: `Vaja ${i}`, sets: 4, reps: '10', kg: null, rest: 90, lib: null })) }
    expect(durationNote(moc)!.text).toMatch(/^Vaje trajajo ~\d+ min — v načrt gre 20 min\.$/)
  })
  it('»20 lb« → 9 kg (prej prazno), »22,5« in »40 kg« ostaneta', () => {
    expect(kgOf('20 lb')).toBe(9)
    expect(kgOf('45 lbs')).toBe(20.5)
    expect(kgOf('22,5')).toBe(22.5)
    expect(kgOf('40 kg')).toBe(40)
    expect(draftFromOut({ vrsta: 'moc', vaje: [{ ime: 'Thrusters', serije: 3, ponovitve: 12, kg: '20 lb' }] })!.exercises[0]).toMatchObject({ kg: 9, name: 'Potisk s počepom', lib: 'thruster' })
  })
  it('predlog s slike sebe: brez naprave v fitnesu (Face pull na kablu)', () => {
    const s = selfFromOut({ poudarki: ['Ramena so rahlo naprej — okrepi zgornji hrbet.'], podrocje: 'drza', predlog: { vaje: [{ ime: 'Face pull' }, { ime: 'Superman' }] } })!
    expect(s.exercises.map(e => e.name).join(' ')).not.toMatch(/kablu/)
  })
  it('Wall ball, Thruster, Box jump so v knjižnici (tehnika, figura), načrt jih sam ne izbira', () => {
    for (const n of ['Wall balls', 'Thrusters', 'Box jumps', 'Box jump']) expect(matchExercise(n), n).not.toBeNull()
    const ids = ['wallball', 'thruster', 'boxjump']
    for (const id of ids) { const e = EXERCISES.find(x => x.id === id)!; expect(e.how.length).toBeGreaterThan(25); expect(templateFor(id)).not.toBe(TEMPLATES.pavza) }
    const c = candidates('kondicija', { where: 'fitnes', equip: ['fitnes', 'utezi', 'nic', 'drog', 'elastike'], level: 3, limits: [] })
    expect(c.some(e => ids.includes(e.id))).toBe(false)
  })
})

describe('H06: »Začni zdaj« na dan tekme ali trdega treninga vpraša', () => {
  it('tekma, opravljen ali trd trening → vprašanje; zamenjan trening ne šteje', () => {
    const r = day({ id: 'r', date: TODAY, kind: 'kolo', title: 'Kronometer Vodice — 18 km', durationMin: 30, role: 'dirka', raceId: 'kv' })
    expect(startNowWarn([r], TODAY)).toBe('Danes imaš tekmo »Kronometer Vodice — 18 km«. Res dodam še ta trening?')
    const k = day({ id: 'k', date: TODAY, kind: 'kolo', title: 'VO2max 5 × 4 min', role: 'kljucna' })
    expect(startNowWarn([k], TODAY)).toMatch(/Danes imaš že trd trening »VO2max 5 × 4 min«/)
    expect(startNowWarn([k], TODAY, 'k')).toBeNull()
    expect(startNowWarn([day({ id: 'z', date: TODAY, kind: 'kolo', title: 'Z2', role: 'lahka' })], TODAY)).toBeNull()
  })
})

describe('H16: tek s slike ni »Tek in hoja«', () => {
  it('privzeto »Tek«, »Tek in hoja« samo z »hoj«', () => {
    expect(kindLabelOf({ kind: 'tek', title: 'Intervali na stezi' })).toBe('Tek')
    expect(kindLabelOf({ kind: 'tek', title: 'Fartlek' })).toBe('Tek')
    expect(kindLabelOf({ kind: 'tek', title: 'Tek in hoja — 6 × 2 min teka' })).toBe('Tek in hoja')
  })
})

describe('H35/H36/H50: vodena vadba', () => {
  it('opomba s slike »AMRAP 10 min na koncu« je zadnji korak s časovnikom in v »Kaj te čaka«', () => {
    const d = day({ id: 'm', date: TODAY, kind: 'moc', title: 'WOD', desc: 'S slike: AMRAP 10 min na koncu: 10 × burpee, 15 × KB swing Med serijami 60 s.', durationMin: 40, exercises: [{ name: 'Počep', sets: 3, reps: '10', kg: 22.5 }] })
    const st = stepsFor(d, P)
    const fin = st.find(s => s.label === 'Na koncu s slike')!
    expect(fin.sec).toBe(600)
    expect(fin.reps).toMatch(/^AMRAP 10 min na koncu: 10 × burpee/)
    expect(st.indexOf(fin)).toBeLessThan(st.findIndex(s => s.label === 'Raztezanje'))
    expect(structureLines(st).join(' | ')).toContain('Na koncu s slike: AMRAP 10 min')
    // H36: decimalna vejica
    expect(st.find(s => s.label === 'Počep')!.reps).toBe('10 · 22,5 kg')
    // brez opombe ni koraka
    expect(stepsFor({ ...d, desc: 'Trening s slike.' }, P).some(s => s.label === 'Na koncu s slike')).toBe(false)
  })
  it('tek in hoja: ostanek hoje po zadnjem teku je del izteka (ena vrstica manj)', () => {
    const d = day({ id: 't', date: TODAY, kind: 'tek', title: 'Tek in hoja — 8 × 1 min teka', desc: '5 min hitre hoje, nato 8 × (1 min tek / 1 min 30 s hoja) v pogovornem tempu. Na koncu 5 min hoje.', durationMin: 30, zone: 'Z2', role: 'lahka' })
    const lines = structureLines(stepsFor(d, P))
    expect(lines.some(l => /hitra hoja$/.test(l))).toBe(false)
    expect(lines[lines.length - 1]).toMatch(/iztek \(hoja\)$/)
    expect(lines.length).toBe(3)
  })
  it('H27 (že v A23): bralnik »1 minuta 30 sekund«', () => {
    expect(stepAnnounce(2, 18, { kind: 'lahko', label: 'Hoja', sec: 90 })).toContain('1 minuta 30 sekund')
  })
})

describe('H29/H13/H49: trener brez AI', () => {
  const ctx = (o: Partial<LocalCoachCtx>): LocalCoachCtx => ({ profile: P, plan: [], activities: [], checkins: [], checkinToday: null, wellness: null, wellnessOn: false, mealsToday: [], recentMeals: [], weather: null, today: TODAY, ...o })
  it('trajanje ni podvojeno', () => {
    expect(titleWithDur('Kolo — lahko 1 h', 60)).toBe('Kolo — lahko, 1 h')
    expect(titleWithDur('Lahek tek — 20 min + 3 pospeški', 20)).toBe('Lahek tek — 20 min + 3 pospeški')
    expect(titleWithDur('Z2 vzdržljivost', 90)).toBe('Z2 vzdržljivost, 1 h 30 min')
    const plan = [day({ id: 'a', date: TODAY, kind: 'kolo', title: 'Z2', durationMin: 60 }), day({ id: 'b', date: addDays(TODAY, 1), kind: 'kolo', title: 'Kolo — lahko 1 h', durationMin: 60 })]
    const t = localAdvice(ctx({ plan }))
    expect(t).toContain('Jutri: Kolo — lahko, 1 h.')
    expect(t).not.toMatch(/1 h, 1 h/)
  })
  it('forma »še računam« pod 3 vadbami v 28 dneh (kot Danes); teža »zadnja vpisana« brez 3 tehtanj', () => {
    const acts = [act({ id: 'x1', date: addDays(TODAY, -10), durationMin: 60, tss: 50 })]
    const plan = [day({ id: 'a', date: TODAY, kind: 'kolo', title: 'Z2', durationMin: 60 })]
    const r = localReview(ctx({ plan, activities: acts, checkins: [{ date: addDays(TODAY, -2), weightKg: 95 } as never] }))
    expect(r).toContain('Forma: še računam — po 3 vadbah.')
    expect(r).not.toMatch(/forma [+−-]?\d/)
    expect(r).toContain('Teža 95 kg (zadnja vpisana)')
    expect(r).not.toContain('7-dnevno povprečje')
    expect(localAdvice(ctx({ plan, activities: acts }))).not.toMatch(/Forma [+−-]?\d/)
  })
})

describe('H03/H22: gorivo pri teku in primeri beljakovin', () => {
  it('polmaraton: »Med« iz tekaške tabele (geli), brez ploščic in kolesarskih ~70 g', () => {
    const f = fueling({ kind: 'tek', durationMin: 115, zone: null, role: 'dirka', title: 'Tekma: polmaraton' }, { weightKg: 58 })!
    expect(f.during).toMatch(/^Gel v 45\./)
    expect(f.during).not.toMatch(/ploščice|~70 g/)
  })
  it('vegan in brez laktoze: brez skute, jogurta in piščanca', () => {
    expect(proteinFoods('vegan')).toBe('tofu, sojin jogurt, leča, tempeh')
    expect(proteinFoods('brez laktoze')).not.toMatch(/jogurt|^skuta/)
    expect(proteinFoods(null)).toBe('skuta, jajca, jogurt, piščanec')
    const f = fueling({ kind: 'moc', durationMin: 60, zone: null }, { weightKg: 60 }, { prefs: 'Sem vegan.' })!
    expect(f.after).not.toMatch(/skuta|jajca|piščanec/)
    expect(eveningSnack('vegan')).not.toMatch(/skuta|kakav/)
  })
})

describe('H23/H44/H43: obrok brez AI', () => {
  it('2 žemlji in čokoladno mleko 0,5 l (prej 80 g kruha in mleko 1,5 %)', () => {
    const m = estimateMeal('2 žemlji s salamo, čokoladno mleko 0,5 l')!
    expect(m.kcal).toBeGreaterThanOrEqual(650)
    expect(m.items.find(i => i.key === 'belkruh')).toMatchObject({ name: 'žemlja', qty: '140 g' })
    expect(m.items.find(i => i.name === 'čokoladno mleko')).toBeTruthy()
  })
  it('kava z mlekom je skodelica', () => {
    expect(estimateMeal('kava z mlekom')!.items[0]!.qty).toBe('1 skodelica')
    expect(estimateMeal('2 kavi')!.items[0]!.qty).toBe('2 skodelici')
  })
  it('»Kosilo: …« izbere obrok', () => {
    expect(mealTypeFromText('Kosilo: 2 hrenovki, 200 g pomfrija')).toEqual({ slot: 'kosilo', rest: '2 hrenovki, 200 g pomfrija' })
    expect(mealTypeFromText('Večerja - riž')?.slot).toBe('vecerja')
    expect(mealTypeFromText('Prigrizek: jabolko')?.slot).toBe('drugo')
    expect(mealTypeFromText('2 hrenovki')).toBeNull()
  })
})

describe('H04/H05: načrt po meri — teden po polmaratonu, nogomet', () => {
  const MON = '2026-10-19'
  const base = { sex: 'z', age: 28, heightCm: 168, weightKg: 58, ftp: null, gear: { bikeOutdoor: false, trainer: false, noBike: true }, strength: { on: false, equipment: 'none' }, onboardingDone: false, createdAt: NOW, updatedAt: NOW } as unknown as Profile
  const f0 = normalizeFocus({ wish: 'Sem vegan. Ljubljanski maraton — polmaraton 25. 10. 2026.', sports: ['tek'], aims: ['kondicija', 'vzdrzljivost', 'tekma'], level: 3, offDays: [0, 2, 4],
    sessions: [{ type: 'tek', cardio: 'intervali', min: 60 }, { type: 'tek', cardio: 'tempo', min: 60 }, { type: 'tek', cardio: 'lahko', min: 60 }, { type: 'tek', cardio: 'dolgo', min: 90 }],
    race: { name: 'Ljubljanski maraton — polmaraton', date: '2026-10-25', distanceKm: null, sport: 'tek' } }, { by: 'pravila', now: NOW })!
  it('teden po polmaratonu: samo lahko (brez tempa in intervalov), dolga največ 60 min, manj kot 70 % dogovora', () => {
    const p = { ...base, ...profileFromFocus(f0, base, MON, MON) } as Profile
    const w2 = buildFocusWeek({ profile: p, activities: [], weekStart: addDays(MON, 7), notBefore: addDays(MON, 7), today: MON } as never)
    const after = w2.filter(d => d.date >= '2026-10-26' && d.date <= '2026-11-01' && d.kind !== 'pocitek')
    expect(after.length).toBeGreaterThan(0)
    for (const d of after) { expect(d.role === 'kljucna' || /Z3|Z4|Z5/.test(d.zone || ''), d.title).toBe(false); expect(d.durationMin, d.title).toBeLessThanOrEqual(60) }
    const agreed = f0.sessions.reduce((s, x) => s + x.min, 0)
    expect(after.reduce((s, d) => s + d.durationMin, 0)).toBeLessThanOrEqual(0.7 * agreed)
  })
  it('nogomet: dan s porabo (cilj višji kot na dan brez vadbe), trener ne reče »počitek … ne dodajaj«', () => {
    const b16 = { ...base, sex: 'm', age: 16, heightCm: 175, weightKg: 62, aiConsentAt: null } as unknown as Profile
    const f = normalizeFocus({ wish: 'Igram nogomet: treningi ob torkih in četrtkih, tekma v soboto. Fitnes bi hodil dvakrat na teden.', sports: ['fitnes'], aims: ['kondicija', 'misice'], level: 2, offDays: [1, 3, 5],
      sessions: [{ type: 'fitnes', part: 'celo', min: 60 }, { type: 'fitnes', part: 'celo', min: 60 }] }, { by: 'pravila', now: NOW })!
    const p = { ...b16, ...profileFromFocus(f, b16, MON, MON) } as Profile
    const w = buildFocusWeek({ profile: p, activities: [], weekStart: MON, notBefore: MON, today: MON } as never)
    const tue = w.find(d => d.date === '2026-10-20')!, wed = w.find(d => d.kind === 'pocitek' && !d.kcalBurn)!
    expect(tue.title).toBe('Nogomet')
    expect(tue.kcalBurn).toBe(otherSportKcal(p))
    expect(wed.kind).toBe('pocitek')
    const tT = dailyTarget(p, [], [tue], tue.date, { today: tue.date, hour: 8 })!, tW = dailyTarget(p, [], [wed], wed.date, { today: wed.date, hour: 8 })!
    expect(tT.kcal).toBeGreaterThan(tW.kcal + 300)
    const adv = localAdvice({ profile: p, plan: w, activities: [], checkins: [], checkinToday: null, wellness: null, wellnessOn: false, mealsToday: [], recentMeals: [], weather: null, today: '2026-10-20' })
    expect(adv).not.toMatch(/Danes je počitek/)
    expect(adv).toContain('Danes: nogomet — tvoj trening.')
  })
})

describe('H20/H08/H09/H42/H24/H39/H48: persone — besedila po tem, kar imaš', () => {
  it('po bolezni »vožnje« samo z vožnjami v načrtu', () => {
    expect(afterSick([day({ id: 'f', date: TODAY, kind: 'moc' }), day({ id: 'h', date: TODAY, kind: 'pohod' })], { gear: { noBike: true } } as never)).toBe('Po bolezni začni lahko — krajši trening, manjše teže.')
    expect(afterSick([day({ id: 'k', date: TODAY, kind: 'pocitek', sickPrev: [day({ id: 'k', date: TODAY, kind: 'kolo' })] })], P)).toBe('Po bolezni začni z lahkimi vožnjami.')
  })
  it('»Brez kolesa«: brez voženj ali brez kolesa ni smiselno; samo vožnje → nič ne ostane', () => {
    const sun = '2026-10-25'
    const bikes = [day({ id: 'a', date: TODAY, kind: 'kolo' }), day({ id: 'b', date: addDays(TODAY, 1), kind: 'kolo' })]
    expect(bikePauseOf(bikes, P, TODAY, sun)).toEqual({ bike: true, others: false })
    const mix = [...bikes, day({ id: 'm', date: addDays(TODAY, 2), kind: 'moc' })]
    expect(bikePauseOf(mix, P, TODAY, sun)).toEqual({ bike: true, others: true })
    expect(bikePauseOf([day({ id: 'm', date: TODAY, kind: 'moc' })], { gear: { noBike: true } }, TODAY, sun).bike).toBe(false)
    expect(othersLeft(bikes, TODAY, sun)).toBe(false)
    expect(othersLeft(mix, TODAY, sun)).toBe(true)
  })
  it('dogovor v nedeljo: tekoči teden pred začetkom brez treningov', () => {
    const p = { cycleStart: '2026-10-19' } as Profile
    expect(introEmpty(p, [day({ id: 'x', date: '2026-10-18', kind: 'pocitek' })], '2026-10-12')).toBe(true)
    expect(introEmpty(p, [day({ id: 'x', date: '2026-10-17', kind: 'tek' })], '2026-10-12')).toBe(false)
    expect(introEmpty(p, [], '2026-10-19')).toBe(false)
  })
  it('?dodaj=1: list za dodajanje — počitek tega dne ali nov zapis poleg; ne na tekmo in ne za nazaj', () => {
    const rest = day({ id: 'p', date: TODAY, kind: 'pocitek' })
    expect(addSheetFor([rest], TODAY, TODAY)?.id).toBe('p')
    const t = addSheetFor([day({ id: 'k', date: TODAY, kind: 'kolo' })], TODAY, TODAY)!
    expect([t.kind, t.id !== 'k', t.date]).toEqual(['pocitek', true, TODAY])
    expect(addSheetFor([day({ id: 'r', date: TODAY, kind: 'kolo', role: 'dirka', raceId: 'x' })], TODAY, TODAY)).toBeNull()
    expect(addSheetFor([rest], addDays(TODAY, -1), TODAY)).toBeNull()
  })
  it('brez ure in utripa: »občutek«', () => {
    expect(hrWord({ maxHr: null, lthr: null, focus: { wish: 'Nimam ure, samo telefon.' } } as never, false)).toBe('občutek')
    expect(hrWord({ maxHr: 190, lthr: null, focus: { wish: 'Nimam ure.' } } as never, false)).toBe('utrip ali občutek')
    expect(hrWord({ maxHr: null, lthr: null, focus: { wish: 'Tečem.' } } as never, false)).toBe('utrip ali občutek')
  })
  it('exByName pozna nove vaje (vodena vadba ima tehniko)', () => {
    expect(exByName('Skok na škatlo')?.how).toMatch(/mehak doskok/)
  })
})

describe('H26: treniran tekmovalec — lahek začetek s pragom', () => {
  it('raven 3+, 15 h, »raje trdo«: 2. teden sweet spot, 3. teden prag; brez »raje trdo« ostane brez ključnega', () => {
    const N = '2026-10-17T08:00:00.000Z'
    const base = { name: 'U', sex: 'm', age: 20, heightCm: 182, weightKg: 70, ftp: 320, ftpDate: '2026-10-10', maxHr: 200, restHr: 45, lthr: 180, level: 3, push: 'trdo',
      gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: true }, hoursPerWeek: 15, hoursMode: 'own', strength: { on: false, equipment: 'none' }, strengthDays: 0,
      goal: 'dirka', deficit: 0, neat: 1.4, proteinGkg: 1.8, event: { ...FRANJA_2027 }, races: [], cycleStart: '2026-10-19', onboardingDone: true, createdAt: N, updatedAt: N } as unknown as Profile
    expect(strongStart(base)).toBe(true)
    const bw = (p: Profile, ws: string) => buildWeek({ profile: p, activities: [], weekStart: ws, notBefore: ws, today: ws })
    expect(weekContext(base, '2026-10-26').easy).toBe(2)
    expect(bw(base, '2026-10-26').some(d => d.role === 'kljucna' && /Sweet spot/.test(d.title))).toBe(true)
    expect(bw(base, '2026-11-02').some(d => d.role === 'kljucna' && /Prag/.test(d.title))).toBe(true)
    expect(bw(base, '2026-10-19').some(d => d.role === 'kljucna')).toBe(false)
    expect(bw({ ...base, push: 'zmerno' } as Profile, '2026-10-26').some(d => d.role === 'kljucna')).toBe(false)
  })
})
