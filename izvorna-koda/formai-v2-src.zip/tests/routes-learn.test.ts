import { describe, it, expect } from 'vitest'
import { analyzeTrack, type RouteRec } from '../src/domain/routes/analyze'
import { needOf, suggestRoutes, paceAdj, workoutMinutes } from '../src/domain/routes/match'
import { dest, qualityOf, routePenalty, knownRoads } from '../src/domain/routes/brouter'
import type { LatLon } from '../src/domain/import/polyline'
import type { Activity, PlanDay } from '../src/domain/types'

function loop(km: number, center: LatLon = [46.19, 14.5]): { pts: LatLon[]; alt: number[] } {
  const n = Math.round(km * 1000 / 20), R = km / (2 * Math.PI), pts: LatLon[] = [], alt: number[] = []
  for (let i = 0; i <= n; i++) { pts.push(dest(center, R, (i / n) * 360)); alt.push(300) }
  return { pts, alt }
}
const rec = (id: string, km: number, o: Partial<RouteRec> = {}, center?: LatLon): RouteRec => {
  const t = loop(km, center)
  return { ...analyzeTrack({ id, source: 'voznja', name: id, date: '2026-09-10', rodeMin: Math.round(km * 2.2) }, t.pts, t.alt)!, ...o }
}
const now = new Date().toISOString()
const day = (o: Partial<PlanDay>): PlanDay => ({ id: 'd', date: '2026-09-24', kind: 'kolo', title: 'Z2 vzdržljivost', desc: '', durationMin: 90, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: now, updatedAt: now, ...o })
const P = { ftp: 240, weightKg: 79 }

describe('nove trase: kakovost iz oznak OpenStreetMap', () => {
  const head = ['Longitude', 'Latitude', 'Elevation', 'Distance', 'CostPerKm', 'ElevCost', 'TurnCost', 'NodeCost', 'InitialCost', 'WayTags', 'NodeTags', 'Time', 'Energy']
  const row = (m: number, way: string, node = '') => ['0', '0', '300', String(m), '', '', '', '', '', way, node, '', '']
  it('semaforji, makadam (tudi poljska pot brez oznake), naselja', () => {
    const q = qualityOf([head, row(2000, 'highway=tertiary surface=asphalt'), row(800, 'highway=path'), row(500, 'highway=track surface=gravel'), row(300, 'highway=track surface=asphalt'),
      row(1200, 'highway=residential', 'highway=traffic_signals'), row(100, 'highway=secondary', 'crossing=traffic_signals highway=crossing')])!
    expect(q.signals).toBe(2)
    expect(q.unpavedKm).toBe(1.3)
    expect(q.urbanKm).toBe(1.2)
    expect(qualityOf(undefined)).toBeUndefined()
  })
  it('kazen: semaforji in makadam slabši, znane ceste boljše', () => {
    const clean = routePenalty({ km: 45, q: { signals: 2, unpavedKm: 0, urbanKm: 2, cyclewayKm: 0, bigRoadKm: 0 } }, 3, false, null)
    const city = routePenalty({ km: 45, q: { signals: 46, unpavedKm: 3.4, urbanKm: 5, cyclewayKm: 3.8, bigRoadKm: 0 } }, 3, false, null)
    expect(city).toBeGreaterThan(clean + 3)
    expect(routePenalty({ km: 45, q: { signals: 2, unpavedKm: 0, urbanKm: 2, cyclewayKm: 0, bigRoadKm: 0 } }, 3, false, 0.8)).toBeLessThan(clean)
  })
  it('znane ceste: delež nove poti po tvojih vožnjah', () => {
    const mine = loop(30).pts
    const known = knownRoads([mine])
    expect(known(loop(30).pts)).toBeGreaterThan(0.95)
    expect(known(loop(30, [46.4, 14.9]).pts)).toBe(0)
  })
})

describe('izbor trase: tvoje pogoste poti in menjava', () => {
  const need = needOf(day({}), P)!
  it('pogosto prevožena tvoja trasa pred novo, čeprav je nova časovno točnejša', () => {
    const k = 1
    const mine = rec('moja', 38, { times: 8, date: '2026-09-15' })
    const nova = rec('nova', 40, { source: 'nova', date: '2026-09-24', quality: { signals: 12, unpavedKm: 0.5, urbanKm: 3, cyclewayKm: 0, bigRoadKm: 0 } })
    const s = suggestRoutes([mine, nova], need, P, '2026-09-24', k)
    expect(s[0]!.rec.id).toBe('moja')
  })
  it('ista pot kot včeraj gre nazaj — menjava med tvojimi', () => {
    const a = rec('a', 40, { times: 6, date: '2026-09-23' }), b = rec('b', 40, { times: 4, date: '2026-09-12' }, [46.2, 14.52])
    const s = suggestRoutes([a, b], need, P, '2026-09-24', 1)
    expect(s[0]!.rec.id).toBe('b')
  })
})

describe('dolžina trase se uči iz treningov', () => {
  it('treningi so trajali ~20 % dlje od ocene → naslednja ocena daljša (trasa krajša)', () => {
    const r1 = rec('act1', 45), r2 = rec('act2', 44)
    const d1 = day({ id: 'p1', date: '2026-09-22', title: 'Sweet spot 3 × 12 min', zone: 'Z3', role: 'kljucna', done: { at: now, activityId: 'act1' } })
    const d2 = day({ id: 'p2', date: '2026-09-24', title: 'Sweet spot 3 × 12 min', zone: 'Z3', role: 'kljucna', done: { at: now, activityId: 'act2' } })
    const est1 = workoutMinutes(r1.prof, needOf(d1, P)!, P, 1), est2 = workoutMinutes(r2.prof, needOf(d2, P)!, P, 1)
    const acts = [
      { id: 'act1', source: 'intervals', sport: 'kolo', date: '2026-09-22', name: 'x', durationMin: Math.round(est1 * 1.18), elapsedMin: Math.round(est1 * 1.24), aiEligible: true, geoRetain: true, createdAt: now, updatedAt: now },
      { id: 'act2', source: 'intervals', sport: 'kolo', date: '2026-09-24', name: 'x', durationMin: Math.round(est2 * 1.2), elapsedMin: Math.round(est2 * 1.26), aiEligible: true, geoRetain: true, createdAt: now, updatedAt: now },
    ] as Activity[]
    const a = paceAdj([r1, r2], acts, [d1, d2], P, 1, '2026-09-24')
    expect(a.n).toBe(2)
    expect(a.adj).toBeGreaterThan(1.2); expect(a.adj).toBeLessThan(1.3)
    // ena sama vožnja šteje pol (ne skoči takoj), brez podatkov 1
    expect(paceAdj([r2], acts, [d2], P, 1, '2026-09-24').adj).toBeLessThan(1.15)
    expect(paceAdj([], [], [], P, 1, '2026-09-24')).toEqual({ adj: 1, n: 0, last: null })
  })
})
