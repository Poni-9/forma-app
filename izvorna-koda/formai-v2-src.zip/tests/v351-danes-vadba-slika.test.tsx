// v3.51 DANES-VADBA — list »Trening s slike«: »Hribi« v obeh listih (A38), dnevi z veliko začetnico (A39), »Druga slika« (A40),
// oznaka polj brez »ponovitve ×« pri hribih (A46), vodena vadba z vpisanim ogrevanjem 10/100/10 (A14).
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>() }))
const h = vi.hoisted(() => ({ json: {} as unknown }))
vi.mock('@/state/store', () => ({
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state, toast: () => undefined,
}))
vi.mock('@/state/photoTraining', () => ({
  saveDoneShot: async () => ({ added: true, day: null }),
  addPhotoWorkout: async (d: { id: string }) => ({ day: d, replaced: null, undo: async () => undefined }),
  addSelfSessions: async () => undefined,
}))
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => ({ name: 'danes', params: {} }) }))
vi.mock('@/ui/useAi', () => ({ useAi: () => ({ busy: false, signedIn: true, consent: true, run: async (fn: () => Promise<unknown>) => fn(), sheet: null }) }))
vi.mock('@/domain/ai/client', () => {
  class AiError extends Error { kind: string; constructor(kind: string, m: string) { super(m); this.kind = kind } }
  return { AiError, askText: async () => '', askJson: async () => JSON.parse(JSON.stringify(h.json)) }
})
vi.mock('@/domain/ai/image', () => ({ fileToBase64Resized: async () => ({ data: 'AAAA', mime: 'image/jpeg', thumb: '' }), exifStamp: async () => null }))

import { PhotoTrainingSheet } from '@/ui/PhotoTrainingSheet'
import { stepsFor, structureLines } from '@/domain/training/workout'
import { draftToPlanDay, type PhotoWorkout } from '@/domain/training/fromPhoto'
import type { PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-23'
const NOW = `${TODAY}T08:00:00.000Z`
const P = { sex: 'm', age: 21, heightCm: 182, weightKg: 78, ftp: 240, lthr: 184, maxHr: 195, restHr: 48, aiConsentAt: NOW, aiConsentV: 2, gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, onboardingDone: true } as unknown as Profile
const day = (o: Partial<PlanDay> & Pick<PlanDay, 'id' | 'date' | 'kind'>): PlanDay => ({ title: 'Z2 vzdržljivost', desc: '', durationMin: 60, source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })
const reset = () => { S.state = { today: TODAY, plan: [day({ id: 'k', date: TODAY, kind: 'kolo' })], activities: [], profile: P, user: { uid: 'u' }, settings: {} }; S.subs.forEach(f => f()) }
let div: HTMLDivElement | null = null, root: Root | null = null
async function render(el: ReactElement) { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div); await act(async () => { root!.render(el) }); await act(async () => { await new Promise(r => setTimeout(r, 0)) }); return document.body }
const sp = (x: string | null | undefined) => (x || '').replace(/[  ⁠]/g, ' ')
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(sp(b.textContent))) as HTMLButtonElement | undefined
const file = () => new File(['x'], 'p.jpg', { type: 'image/jpeg' })

beforeEach(() => { vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date(2026, 9, 23, 9, 0)); reset() })
afterEach(() => { act(() => root?.unmount()); div?.remove(); div = null; root = null; document.body.innerHTML = ''; vi.useRealTimers() })

describe('A38/A40: opravljen trening s slike', () => {
  it('šport hoje je »Hribi« (kot v drugem listu in na Danes); »Druga slika« vrne na izbiro slike', async () => {
    h.json = { app: 'garmin', sport: 'kolo', datum: null, trajanje_min: 62, razdalja_km: 31.4, zanesljivost: 'visoka' }
    const b = await render(<PhotoTrainingSheet req={{ mode: 'done', dayId: 'k', file: file() }} />)
    expect(sp(b.textContent)).toMatch(/Preveri, kar sem prebral/)
    expect(btn(/^Hribi$/)).toBeTruthy()
    expect(btn(/^Hoja$/)).toBeUndefined()
    await act(async () => { btn(/^Druga slika$/)!.click() })
    expect(sp(b.textContent)).not.toMatch(/Preveri, kar sem prebral/)
    expect(sp(b.textContent)).toMatch(/Slikaj opravljen trening/)
  })
})

describe('A39/A46/A40/A14: trening s slike (hribi)', () => {
  it('dnevi »Ned 25. 10.«; »Koraki« brez »ponovitve ×«; vodena vadba 10 min ogrevanje · 100 min · 10 min iztek; »Druga slika«', async () => {
    h.json = { vrsta: 'pohod', naslov: 'Hribi', koraki: [{ tip: 'ogrevanje', min: 10 }, { tip: 'enakomerno', min: 100 }, { tip: 'iztek', min: 10 }] }
    const b = await render(<PhotoTrainingSheet req={{ mode: 'plan', date: TODAY, file: file() }} />)
    const opts = [...b.querySelectorAll('#pt-day option')].map(o => sp(o.textContent))
    expect(opts[0]).toMatch(/^Danes/)
    expect(opts.find(o => /25\. 10\./.test(o))).toMatch(/^Ned 25\. 10\./)
    expect(sp(b.textContent)).not.toMatch(/ponovitve × delo/)
    const struct = sp(b.querySelector('.ph-struct')?.textContent)
    expect(struct).toMatch(/10 min ogrevanje/)
    expect(struct).toMatch(/10 min iztek/)
    expect(struct).not.toMatch(/15 min ogrevanje/)
    await act(async () => { btn(/^Druga slika$/)!.click() })
    expect(sp(b.textContent)).toMatch(/Slikaj ali izberi sliko treninga|Trening s slike/)
    expect(b.querySelector('#pt-day')).toBeNull()
  })
  it('A14 domena: stepsFor po draftToPlanDay — ogrevanje in iztek kot vpisana (10/100/10)', () => {
    const w: PhotoWorkout = { kind: 'pohod', title: 'Hribi', minutes: null, exercises: [], blocks: [{ kind: 'ogrevanje', min: 10, n: null, workS: null, restS: null, at: '' }, { kind: 'enakomerno', min: 100, n: null, workS: null, restS: null, at: '' }, { kind: 'iztek', min: 10, n: null, workS: null, restS: null, at: '' }], note: null } as unknown as PhotoWorkout
    const st = stepsFor(draftToPlanDay(w, TODAY, P), P)
    expect(st.map(s => s.sec / 60)).toEqual([10, 100, 10])
    expect(structureLines(st)[0]).toMatch(/^10 min ogrevanje/)
  })
})
