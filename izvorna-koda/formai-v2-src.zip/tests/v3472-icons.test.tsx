import { describe, it, expect } from 'vitest'
import { renderToStaticMarkup } from 'react-dom/server'
import type { ComponentType, SVGProps } from 'react'
type Ico = ComponentType<SVGProps<SVGSVGElement>>
import * as I from '../src/ui/icons'
import { KindIcon } from '../src/ui/primitives'

/** v3.47.2: prenovljene ikone (Blaž, 17. 10.: »vse ikone mal popravi in izboljšaj«). */
describe('v3.47.2 — ikone', () => {
  const all = Object.entries(I).filter(([k]) => k.startsWith('Ico')) as [string, Ico][]
  it('vsaka ikona je SVG na mreži 24 × 24 in sprejme velikost', () => {
    expect(all.length).toBeGreaterThanOrEqual(45)
    for (const [k, C] of all) {
      const html = renderToStaticMarkup(<C width={15} height={15} />)
      expect(html, k).toMatch(/^<svg[^>]*viewBox="0 0 24 24"/)
      expect(html, k).toContain('width="15"')
    }
  })
  it('vsaka vrsta dneva ima svojo ikono: hribi niso zemljevid, test ni tarča, počitek ni srce', () => {
    const kinds = ['kolo', 'moc', 'tek', 'pohod', 'test', 'pocitek'] as const
    const html = kinds.map(k => renderToStaticMarkup(<KindIcon kind={k} />))
    expect(new Set(html).size).toBe(kinds.length)
    const r = (C: Ico) => renderToStaticMarkup(<C width={17} height={17} />)
    expect(html[3]).toBe(r(I.IcoMountain))
    expect(html[4]).toBe(r(I.IcoGauge))
    expect(html[5]).toBe(r(I.IcoRest))
    expect(html).not.toContain(r(I.IcoMap))
  })
})
