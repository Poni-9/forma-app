import { describe, it, expect, beforeEach, vi } from 'vitest'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { THEME_DEFAULT, THEME_KEY, THEME_BG, THEME_PREFS, themePref, resolveTheme, applyTheme, setThemePref, subscribeTheme, syncThemeMeta, watchSystemTheme, accentDeep, contrast, mixOver, LIGHT_SOFT } from '../src/ui/theme'

const read = (f: string) => readFileSync(resolve(process.cwd(), f), 'utf8')
const tokens = read('src/styles/tokens.css')
const LIGHT_SEL = ':root[data-theme="light"]:not(.is-land) {'
const lightBlock = tokens.slice(tokens.indexOf(LIGHT_SEL))
const darkBlock = tokens.slice(0, tokens.indexOf(LIGHT_SEL))
const tok = (block: string, name: string) => { const m = block.match(new RegExp(`--${name}:\\s*(#[0-9a-fA-F]{6})`)); if (!m) throw new Error(name); return m[1]! }
const L = (n: string) => tok(lightBlock, n)

function metas() {
  document.head.innerHTML = '<meta name="theme-color" content="#0F1216"><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">'
}
const meta = (n: string) => document.querySelector(`meta[name="${n}"]`)!.getAttribute('content')

beforeEach(() => { localStorage.clear(); metas(); document.documentElement.className = 'is-app'; delete document.documentElement.dataset.theme })

describe('videz: izbira teme', () => {
  it('privzeto temno (kot do zdaj); neveljavna vrednost → privzeto; tri izbire z imeni', () => {
    expect(THEME_DEFAULT).toBe('temno')
    expect(themePref()).toBe('temno')
    localStorage.setItem(THEME_KEY, 'roza'); expect(themePref()).toBe('temno')
    localStorage.setItem(THEME_KEY, 'svetlo'); expect(themePref()).toBe('svetlo')
    expect(THEME_PREFS.map(p => p[1])).toEqual(['Temno', 'Svetlo', 'Kot telefon'])
  })
  it('kot telefon sledi sistemu, ostali dve ne', () => {
    expect(resolveTheme('svetlo', false)).toBe('light')
    expect(resolveTheme('temno', true)).toBe('dark')
    expect(resolveTheme('samodejno', true)).toBe('light')
    expect(resolveTheme('samodejno', false)).toBe('dark')
  })
  it('izbira takoj velja, se shrani na napravo in zamenja barvo vrstice brskalnika in iPhona', () => {
    const f = vi.fn(); const off = subscribeTheme(f)
    setThemePref('svetlo')
    expect(localStorage.getItem(THEME_KEY)).toBe('svetlo')
    expect(document.documentElement.dataset.theme).toBe('light')
    expect(meta('theme-color')).toBe(THEME_BG.light)
    expect(meta('apple-mobile-web-app-status-bar-style')).toBe('default')
    expect(f).toHaveBeenCalledTimes(1)
    setThemePref('temno')
    expect(document.documentElement.dataset.theme).toBe('dark')
    expect(meta('theme-color')).toBe(THEME_BG.dark)
    expect(meta('apple-mobile-web-app-status-bar-style')).toBe('black-translucent')
    off(); setThemePref('svetlo'); expect(f).toHaveBeenCalledTimes(2)
  })
  it('pristajalna stran ostane temna tudi s svetlo temo', () => {
    document.documentElement.className = 'is-land'
    applyTheme('svetlo')
    expect(meta('theme-color')).toBe(THEME_BG.dark)
    document.documentElement.className = 'is-app'; syncThemeMeta()
    expect(meta('theme-color')).toBe(THEME_BG.light)
  })
  it('»Kot telefon«: ko telefon zamenja temo, jo zamenja tudi aplikacija', () => {
    let light = false
    const ls = new Set<() => void>()
    vi.stubGlobal('matchMedia', (q: string) => ({ get matches() { return q.includes('light') && light }, addEventListener: (_: string, f: () => void) => ls.add(f), removeEventListener: () => {} }))
    setThemePref('samodejno'); expect(document.documentElement.dataset.theme).toBe('dark')
    watchSystemTheme()
    light = true; ls.forEach(f => f())
    expect(document.documentElement.dataset.theme).toBe('light')
    setThemePref('temno'); light = false; ls.forEach(f => f()); light = true; ls.forEach(f => f())
    expect(document.documentElement.dataset.theme).toBe('dark')   // izbrano »temno« ostane temno
    vi.unstubAllGlobals()
  })
  it('index.html nastavi temo pred prvim izrisom z istim privzetkom in ključem', () => {
    const html = read('index.html')
    expect(html).toContain(`var th='${THEME_DEFAULT}';try{th=localStorage.getItem('${THEME_KEY}')||th}`)
    expect(html).toContain(`m.setAttribute('content','${THEME_BG.light}')`)
    expect(tok(darkBlock, 'bg')).toBe(THEME_BG.dark)
    expect(L('bg')).toBe(THEME_BG.light)
  })
})

describe('svetla tema: berljivost', () => {
  const surfaces = ['bg', 'bg-deep', 'card', 'raised'] as const
  it('besedilo (ink, ink-2, ink-3) in status (ok, warn, bad) ≥ 4,5 : 1 na vseh podlagah', () => {
    for (const t of ['ink', 'ink-2', 'ink-3', 'ok', 'warn', 'bad']) for (const s of surfaces) {
      expect(contrast(L(t), L(s)), `${t} na ${s}`).toBeGreaterThanOrEqual(4.5)
    }
  })
  it('poudarek za besedilo: vsi štirje odtenki zelene ≥ 4,5 : 1 na ozadju, beli in na mehki podlagi poudarka', () => {
    for (const a of ['#A3E635', '#84CC16', '#4ADE80', '#2DD4BF']) {
      const d = accentDeep(a)
      expect(contrast(d, THEME_BG.light), a).toBeGreaterThanOrEqual(4.5)
      expect(contrast(d, '#FFFFFF'), a).toBeGreaterThanOrEqual(4.5)
      expect(contrast(d, mixOver(a, THEME_BG.light, LIGHT_SOFT)), a).toBeGreaterThanOrEqual(4.5)
    }
    expect(accentDeep('#A3E635')).toBe(tok(darkBlock, 'accent-deep'))   // privzetek v tokens.css = izračun za limeto
    expect(accentDeep('ni barva')).toMatch(/^#[0-9A-F]{6}$/)
  })
  it('oznake v barvi vrste (72 % barve + črna) ≥ 4,5 : 1 na beli in na ozadju', () => {
    expect(lightBlock).toMatch(/--t-kolo-ink: color-mix\(in srgb, var\(--t-kolo\) 72%, #000\)/)
    const dark72 = (h: string) => '#' + [1, 3, 5].map(i => Math.round(parseInt(h.slice(i, i + 2), 16) * 0.72).toString(16).padStart(2, '0')).join('')
    for (const t of ['t-kolo', 't-moc', 't-tek', 't-poc']) {
      const c = dark72(tok(darkBlock, t))
      for (const s of ['#FFFFFF', THEME_BG.light, L('raised')]) expect(contrast(c, s), `${t} na ${s}`).toBeGreaterThanOrEqual(4.5)
    }
  })
  it('temna tema ostane, kot je bila (poudarek za besedilo = poudarek, prekrivne podlage bele)', () => {
    expect(darkBlock).toMatch(/--accent-fg: var\(--accent\);/)
    expect(darkBlock).toMatch(/--fg-rgb: 255, 255, 255;/)
    expect(darkBlock).toMatch(/--t-kolo-ink: var\(--t-kolo\);/)
    expect(darkBlock).toMatch(/color-scheme: dark;/)
    expect(lightBlock).toMatch(/color-scheme: light;/)
    expect(tokens).toMatch(/:root\[data-theme="light"\]:not\(\.is-land\)/)
  })
})
