import { describe, it, expect } from 'vitest'
import { buildWeek, weekBikeMinutes, macroWeeks, FRANJA_2027 } from '../src/domain/training/planner'
import { hoursAdvice } from '../src/domain/training/goal'
import type { Activity, Profile } from '../src/domain/types'

const now = new Date().toISOString()
const prof = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 181, weightKg: 78, restHr: 55, maxHr: 200, ftp: 240, ftpDate: '2026-09-20',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, pullupBar: true }, level: 3, hoursPerWeek: 12,
  strength: { on: false, equipment: 'none' }, strengthDays: 0, goal: 'dirka', deficit: 0, neat: 1.4, proteinGkg: 2.0,
  event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', onboardingDone: true, createdAt: now, updatedAt: now, ...o,
} as Profile)
/** vožnje: za vsak teden (ponedeljek) ure, razdeljene na 3 vožnje */
const rides = (weeks: [string, number][]): Activity[] => weeks.flatMap(([ws, h]) => [0, 2, 5].map(d => ({ id: ws + d, source: 'intervals', sport: 'kolo', date: new Date(new Date(ws).getTime() + d * 86400e3).toISOString().slice(0, 10), name: 'v', durationMin: Math.round((h * 60) / 3), aiEligible: true, geoRetain: true, createdAt: now, updatedAt: now } as unknown as Activity)))
const mondays = (from: string, n: number) => Array.from({ length: n }, (_, i) => new Date(new Date(from).getTime() + i * 7 * 86400e3).toISOString().slice(0, 10))

describe('ure na teden: »največ, kar gre«', () => {
  it('iz zgodovine: 1,3 × najdaljši teden (Blažu podobno: vrh 10,3 h, zadnje tedne ~3,5 h)', () => {
    const ws = mondays('2026-03-02', 28)   // do 7. 9.
    const acts = rides(ws.map((w, i) => [w, i === 20 ? 10.3 : i > 19 ? 3.5 : 5] as [string, number]))
    const a = hoursAdvice(acts, prof(), '2026-09-24')
    expect(a.basis).toBe('history'); expect(a.peak).toBe(10.3)
    expect(a.max).toBe(13.5); expect(a.limitedBy).toBe('history')
    expect(a.start).toBe(4)                                   // 1,2 × 3,5 = 4,2 → 4
  })
  it('brez voženj: vpisane ure × 1,3, največ 18 h; do 18 let največ 12 h', () => {
    expect(hoursAdvice([], prof({ hoursPerWeek: 14 }), '2026-09-24')).toMatchObject({ basis: 'stated', max: 18, limitedBy: 'cap' })
    expect(hoursAdvice([], prof({ hoursPerWeek: 10 }), '2026-09-24').max).toBe(13)
    expect(hoursAdvice([], prof({ hoursPerWeek: 14, age: 16 }), '2026-09-24')).toMatchObject({ max: 12, limitedBy: 'youth' })
    expect(hoursAdvice([], prof({ hoursPerWeek: null }), '2026-09-24')).toMatchObject({ basis: 'none', max: 10 })
  })
  it('dirka blizu: več, kot zraste do specifične faze, ni mogoče', () => {
    const a = hoursAdvice([], prof({ hoursPerWeek: 14, event: { name: 'Dirka', date: '2026-12-20' } }), '2026-09-24')
    expect(a.limitedBy).toBe('time'); expect(a.max).toBeLessThan(18)
  })
})

describe('načrt z velikim obsegom', () => {
  const minutes = (h: number, ws: string) => weekBikeMinutes(buildWeek({ profile: prof({ hoursPerWeek: h, baseHours: null }), activities: [], weekStart: ws, notBefore: ws }))
  // normalen teden gradnje (2. teden bloka, volumen 1,0), brez testa in razbremenitve
  const ws = macroWeeks(prof({ baseHours: null }), '2026-09-24').find(w => w.phase === 'gradnja' && w.blockWeek === 2 && !w.recovery && !w.test)!.weekStart
  const w3 = macroWeeks(prof({ baseHours: null }), '2026-09-24').find(w => w.phase === 'gradnja' && w.blockWeek === 3 && !w.recovery && !w.test)!.weekStart
  it('20 h: teden res doseže ~20 h (prej se je ustavil pri ~14,7 h)', () => {
    const m = minutes(20, ws)
    expect(m / 60).toBeGreaterThan(19); expect(m / 60).toBeLessThan(21)
    expect(minutes(18, ws) / 60).toBeGreaterThan(17.5)
    expect(minutes(18, w3) / 60).toBeGreaterThan(19)             // tretji teden bloka ~20 h
  })
  it('12 in 14 h ostaneta, kot sta bila', () => {
    expect(minutes(12, ws)).toBe(720)
    expect(minutes(14, ws)).toBe(840)
  })
})
