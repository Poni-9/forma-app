// v3.50 UVOZ-NAST (Nastavitve): privzete izbire označene, mladoletni brez čipov deficita, Enter shrani, utripi po vrsti,
// cikel kot razdelek, pravne povezave, izvoz z obvestilom in brez sledi, prostor na napravi, izbris s ponudbo kopije,
// pražni utrip brez povezave, teža uteži, odtenek 44 px.
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), persisted: false as boolean | null }))
const store = vi.hoisted(() => ({
  updateProfile: vi.fn(async () => {}), updateSettings: vi.fn(async () => {}), toast: vi.fn(), saveCheckin: vi.fn(async () => {}), markExported: vi.fn(async () => {}),
}))
const bk = vi.hoisted(() => ({ downloadBackup: vi.fn(async () => ({ name: 'formai-izvoz-2026-10-21.json', kb: 48 })) }))
vi.mock('@/state/store', () => ({
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  ...store,
  signIn: vi.fn(), signOut: vi.fn(), refreshWeather: vi.fn(), setStrength: vi.fn(), setWellnessOn: vi.fn(), removeWorkouts: vi.fn(), deleteAccountAll: vi.fn(), LAST_EXPORT_KEY: 'x',
  grantAiConsent: vi.fn(), revokeAiConsent: vi.fn(), wipeThisDevice: vi.fn(),
}))
vi.mock('@/app/Shell', () => ({ Head: () => null }))
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => ({ name: 'nastavitve', params: {} }) }))
vi.mock('@/ui/ClaudeAdmin', () => ({ ClaudeAdmin: () => null }))
vi.mock('@/ui/BackupImport', () => ({ BackupImport: () => null }))
vi.mock('@/ui/GoalCard', () => ({ GoalCard: () => null }))
vi.mock('@/ui/DealCard', () => ({ DealCard: () => null }))
vi.mock('@/data/db', () => ({ getKV: async () => undefined, storagePersisted: () => S.persisted, requestPersist: vi.fn(async () => true) }))
vi.mock('@/data/repo', () => ({ wipeAll: vi.fn() }))
vi.mock('@/data/backup', () => bk)
vi.mock('@/data/sync', () => ({ syncNow: vi.fn() }))
vi.mock('@/data/feedback', () => ({ fetchFeedbackList: async () => ({ error: 'x' }), flushFeedback: async () => 0, queuedFeedback: async () => 0, captureScreen: async () => null }))
vi.mock('@/ui/theme', () => ({ THEME_PREFS: [['samodejno', 'kot telefon']], themePref: () => 'samodejno', setThemePref: vi.fn(), subscribeTheme: () => () => {} }))

import { Nastavitve, storageLine, profileFormErrors, formOf } from '@/screens/Ostalo'
import type { Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const today = '2026-10-21'
const base = { sex: 'm', age: 30, heightCm: 180, weightKg: 78, maxHr: 190, restHr: 50, lthr: 184, ftp: 250, ftpDate: '2026-09-01', hoursPerWeek: 6, bodyFatPct: null, gear: { bikeOutdoor: true, trainer: false, noBike: false, dumbbells: true, dumbbellKg: 10 }, strength: { on: false, equipment: 'none' }, strengthDays: 0, goal: 'hitrejsi', deficit: 0, neat: null, proteinGkg: null, onboardingDone: true, trainTime: null, createdAt: 'x', updatedAt: 'x' } as unknown as Profile
const reset = (p: Partial<Profile> = {}, o: Record<string, unknown> = {}) => { S.state = { ready: true, today, plan: [], activities: [], checkins: [], recentMeals: [], weather: null, wellness: [], settings: { lang: 'sl', intervals: null }, sync: { state: 'off' }, user: null, pro: false, profile: { ...base, ...p }, ...o }; S.subs.forEach(f => f()) }

let div: HTMLDivElement, root: Root | null = null
async function mount() { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div); await act(async () => { root!.render(<Nastavitve />) }) }
const flush = async () => { for (let i = 0; i < 6; i++) await act(async () => { await Promise.resolve() }) }
const setVal = async (el: HTMLInputElement, v: string) => { await act(async () => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(el, v); el.dispatchEvent(new Event('input', { bubbles: true })) }) }
const sp = (x: string) => x.replace(/[  ⁠]/g, ' ')
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(sp(b.textContent || ''))) as HTMLButtonElement | undefined
const open = async (id: string) => { await act(async () => { (document.querySelector(`#${id} .sec-h`) as HTMLButtonElement).click() }) }
const group = (id: string) => [...document.querySelectorAll(`[role="group"][aria-labelledby="${id}"] button`)].map(b => `${sp(b.textContent || '')}:${b.getAttribute('aria-pressed')}${(b as HTMLButtonElement).disabled ? ':dis' : ''}`)

beforeEach(() => { reset(); Object.values(store).forEach(f => f.mockClear()); bk.downloadBackup.mockClear(); Element.prototype.scrollIntoView = vi.fn() })
afterEach(async () => { if (root) { await act(async () => root!.unmount()); root = null; div.remove() } document.body.innerHTML = '' })

describe('F15 + F16 Prehrana', () => {
  it('nov profil: označeni »zmerno · privzeto« in »1,7 g · privzeto«', async () => {
    await mount(); await open('n-prehrana')
    expect(group('lbl-neat')).toEqual(['sedeče:false', 'zmerno · privzeto:true', 'veliko hoje:false'])
    expect(group('lbl-protein')).toEqual(['1,6 g:false', '1,7 g · privzeto:true', '1,8 g:false', '2,0 g:false', '2,2 g:false'])
  })
  it('16 let: čipi deficita onemogočeni, »brez« označen, ena vrstica razlage', async () => {
    reset({ age: 16, deficit: 500 })
    await mount(); await open('n-prehrana')
    expect(group('lbl-deficit')).toEqual(['brez:true:dis', '300 · počasi:false:dis', '400:false:dis', '500 · zmerno:false:dis', '750 · največ:false:dis'])
    expect(document.body.textContent).toContain('Do 18. leta brez deficita — kalorije so za vzdrževanje in rast.')
  })
})

describe('F30 + F18 + F46 profil', () => {
  it('Enter (oddaja obrazca) shrani profil; ročni cilj kcal in kraj tudi', async () => {
    await mount(); await open('n-profil')
    await setVal(document.getElementById('pf-h') as HTMLInputElement, '181')
    await act(async () => { (document.getElementById('pf-h') as HTMLInputElement).form!.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true })) })
    await flush()
    expect(store.updateProfile).toHaveBeenCalledWith({ heightCm: 181 })
    await open('n-prehrana')
    const kcal = document.getElementById('pf-kcal') as HTMLInputElement
    await setVal(kcal, '2600')
    await act(async () => { kcal.form!.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true })) })
    await flush()
    expect(store.updateProfile).toHaveBeenCalledWith({ kcalOverride: 2600 })
  })
  it('max utrip 150 pod pražnim 184: sporočilo, ne shrani', () => {
    const init = formOf(base)
    expect(profileFormErrors(init, { ...init, maxHr: '150' })).toEqual({ maxHr: 'Max utrip mora biti višji od pražnega (184).' })
    // staro stanje (max pod pražnim že v profilu) ne blokira drugih sprememb
    const bad = formOf({ ...base, maxHr: 150 } as Profile)
    expect(profileFormErrors(bad, { ...bad, height: '181' })).toEqual({})
  })
  it('pražni utrip brez intervals.icu: »če veš« in razlaga', async () => {
    reset({ lthr: null })
    await mount(); await open('n-profil')
    expect((document.getElementById('pf-lthr') as HTMLInputElement).placeholder).toBe('če veš')
    expect(document.body.textContent).toContain('Pražni utrip = povprečje zadnjih 20 min 30-minutnega testa na vso moč')
    expect((document.getElementById('pf-bf') as HTMLInputElement).placeholder).toBe('ocena iz ITM')
  })
})

describe('F31 + F38 + F32 oprema, cikel, videz', () => {
  it('teža uteži 9 999 kg: sporočilo, se ne shrani', async () => {
    await mount(); await open('n-oprema')
    const el = document.getElementById('pf-dkg') as HTMLInputElement
    await setVal(el, '9999')
    await act(async () => { el.dispatchEvent(new FocusEvent('focusout', { bubbles: true })) })
    expect(sp(document.getElementById('pf-dkg-err')!.textContent || '')).toBe('Teža uteži: od 1 do 60 kg.')
    expect(store.updateProfile).not.toHaveBeenCalled()
  })
  it('brez dirke: »Cikel« je zaprt razdelek', async () => {
    await mount()
    const sec = document.getElementById('n-cikel')!
    expect(sec.querySelector('.sec-h')!.getAttribute('aria-expanded')).toBe('false')
    expect(sec.textContent).not.toMatch(/makrocikel/)
    await open('n-cikel')
    expect(sec.textContent).toContain('vsak četrti teden je lažji')
  })
  it('odtenek zelene: gumbi z imenom (cilj dotika v .accent-pick)', async () => {
    await mount(); await open('n-videz')
    const b = [...document.querySelectorAll('.accent-pick')]
    expect(b.map(x => x.textContent)).toEqual(['Limeta', 'Trava', 'Pomlad', 'Turkiz'])
  })
})

describe('G41 + G47 + G22 + G21 + F49 Pomoč in Podatki', () => {
  it('Pomoč: povezave na Zasebnost in Pogoje', async () => {
    await mount(); await open('n-pomoc')
    expect(document.querySelector('a[href="/zasebnost.html"]')).not.toBeNull()
    expect(document.querySelector('a[href="/pogoji.html"]')).not.toBeNull()
  })
  it('»Izvozi vse« prijavljenemu: obvestilo z imenom in velikostjo; privzeto brez sledi, kljukica jih doda; zadnji izvoz viden', async () => {
    reset({}, { user: { uid: 'u', email: 'a@b.si', name: 'A' } })
    await mount(); await open('n-podatki')
    expect(document.body.textContent).toContain('razen ključa intervals.icu in GPS sledi')
    expect(document.body.textContent).toContain('Zadnji izvoz: še nikoli.')
    await act(async () => { btn(/^Izvozi vse$/)!.click() }); await flush()
    expect(bk.downloadBackup).toHaveBeenCalledWith(today, { tracks: false })
    expect(sp(store.toast.mock.calls.at(-1)![0] as string)).toBe('Kopija shranjena: formai-izvoz-2026-10-21.json (48 KB).')
    await act(async () => { (document.querySelector('#n-podatki input[type="checkbox"]') as HTMLInputElement).click() })
    await act(async () => { btn(/^Izvozi vse$/)!.click() }); await flush()
    expect(bk.downloadBackup).toHaveBeenLastCalledWith(today, { tracks: true })
  })
  it('prostor na napravi in zaščita', () => {
    expect(sp(storageLine({ usage: 4_200_000, persisted: false }))).toBe('Na napravi: 4,2 MB · zaščiteno pred samodejnim brisanjem: ne')
    expect(storageLine({ usage: null, persisted: true })).toBe('zaščiteno pred samodejnim brisanjem: da')
    expect(storageLine({ usage: null, persisted: null })).toBe('')
  })
  it('»Izbriši na napravi« brez prijave: koliko se izgubi in »Najprej izvozi kopijo«', async () => {
    reset({}, { activities: [{ id: 'a', date: today, sport: 'kolo' }, { id: 'b', date: today, sport: 'tek' }] })
    await mount(); await open('n-podatki')
    await act(async () => { btn(/^Izbriši na napravi$/)!.click() })
    const dlg = document.querySelector('[role="dialog"]')!
    expect(sp(dlg.textContent || '')).toContain('Izbrišem 2 vadbi? Brez prijave je to edini izvod')
    await act(async () => { [...dlg.querySelectorAll('button')].find(b => b.textContent === 'Najprej izvozi kopijo')!.click() }); await flush()
    expect(bk.downloadBackup).toHaveBeenCalledTimes(1)
  })
})
