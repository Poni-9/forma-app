// v3.50 UVOZ-NAST (zasloni): popravek vadbe, ročni vnos (šport, napaka pod poljem, oznaka datuma, »vadba«), Uvoz
// (treningi na uro samo s kolesom, en blok, napake z imenom, ključ pokaži, napaka pod polji), list cilja (različno,
// skupine, napaka v polju, mladoletni), Prvi koraki brez ure za fitnes, poteg brez računa, zemljevid brez povezave,
// povzetek kopije brez ničel.
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, afterEach, beforeAll, afterAll } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'aktivnosti', params: {} as Record<string, string> } }))
vi.mock('@/state/store', async () => {
  const { vi: v } = await import('vitest')
  const base: Record<string | symbol, unknown> = {
    useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
    getState: () => S.state,
    addActivities: v.fn(async () => ({ added: 1, dupes: 0, upgraded: 0 })),
  }
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' || typeof k === 'symbol' ? undefined : (t[k] = v.fn(async () => {}))), has: (_t, k) => k !== 'then' })
})
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => S.route, parseHash: () => S.route, subscribeRoute: () => () => undefined }))
vi.mock('@/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
vi.mock('@/data/icuOauth', () => ({ icuOauthOn: () => false, probeIcuOauth: async () => false, startIcuOAuth: () => undefined }))
vi.mock('@/ui/overlays', () => ({ openHelp: vi.fn() }))

import * as store from '@/state/store'
import { ActivitySheet, applyEdit, editFormOf } from '@/ui/ActivitySheet'
import { Aktivnosti, defaultManualSport } from '@/screens/Aktivnosti'
import { Uvoz } from '@/screens/Uvoz'
import { GoalSheet } from '@/ui/GoalSheet'
import { GoalCard } from '@/ui/GoalCard'
import { FirstSteps, watchStepText } from '@/ui/FirstSteps'
import { ptrSkip } from '@/ui/PullRefresh'
import { mapErrText } from '@/ui/RouteMap'
import { backupSummary } from '@/ui/BackupImport'
import { estimateTss } from '@/domain/training/load'
import { normalizeFocus } from '@/domain/focus/model'
import { IMPORT_WHY } from '@/domain/import/parsers'
import type { Activity, PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-21'
beforeAll(() => { vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date(`${TODAY}T10:00:00`)); Element.prototype.scrollIntoView = vi.fn() })
afterAll(() => { vi.useRealTimers() })

let div: HTMLDivElement | null = null, root: Root | null = null
async function render(el: ReactElement): Promise<HTMLDivElement> {
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root!.render(el) })
  return div
}
afterEach(async () => { if (root) await act(async () => root!.unmount()); div?.remove(); root = null; div = null; vi.clearAllMocks(); document.body.innerHTML = '' })
const sp = (x: string) => x.replace(/[  ⁠]/g, ' ')
const txt = () => sp(document.body.textContent || '')
const btn = (label: string | RegExp) => [...document.body.querySelectorAll('button')].find(b => (typeof label === 'string' ? sp(b.textContent || '').trim() === label : label.test(sp(b.textContent || '')))) as HTMLButtonElement
const type = async (el: HTMLInputElement, v: string) => {
  await act(async () => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(el, v); el.dispatchEvent(new Event('input', { bubbles: true })) })
}
const click = async (b: HTMLElement) => { await act(async () => { b.click() }) }
const flush = async () => { for (let i = 0; i < 6; i++) await act(async () => { await Promise.resolve() }) }
const calls = (f: unknown) => (f as { mock: { calls: unknown[][] } }).mock.calls

const NOW = `${TODAY}T08:00:00.000Z`
const P = {
  sex: 'm', age: 30, heightCm: 180, weightKg: 78, ftp: 240, maxHr: 190, restHr: 50, lthr: 170, hoursPerWeek: 8,
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, strength: { on: false, equipment: 'none' }, strengthDays: 0,
  onboardingDone: true, goal: 'hitrejsi', trainTime: null, createdAt: NOW, updatedAt: NOW,
} as unknown as Profile
const state = (o: Record<string, unknown> = {}) => ({
  ready: true, today: TODAY, profile: P, settings: { lang: 'sl', intervals: null }, activities: [], plan: [], checkins: [], recentMeals: [], mealsToday: [],
  weather: null, wellness: null, sync: { state: 'off' }, user: null, icuDiag: null, icuWorkouts: null, icuErr: null, ...o,
})
const act0 = (o: Partial<Activity> = {}): Activity => ({ id: 'a1', source: 'manual', sport: 'kolo', date: TODAY, start: null, name: 'Vožnja', durationMin: 60, distKm: 25, elevM: null, avgHr: null, avgPower: null, kcal: null, speedKmh: 25, tss: 50, polyline: null, aiEligible: true, geoRetain: false, createdAt: NOW, updatedAt: NOW, ...o } as Activity)
const day = (o: Partial<PlanDay>): PlanDay => ({ id: 'd-' + (o.date || TODAY) + (o.kind || ''), date: TODAY, kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, role: 'z2', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o } as PlanDay)

describe('F10 popravek vadbe', () => {
  it('ročni vnos: »Uredi« → 60 → 90 min → shrani z novim trajanjem in obremenitvijo', async () => {
    S.state = state({ activities: [act0()] })
    await render(<ActivitySheet id="a1" onClose={() => undefined} onDelete={() => undefined} />)
    await click(btn('Uredi'))
    expect(txt()).toContain('Popravi, kar je narobe — šport, čas, razdalja ali datum.')
    await type(document.getElementById('ae-min') as HTMLInputElement, '90')
    await click(btn('Shrani popravek'))
    await flush()
    const saved = calls(store.saveActivity).at(-1)![0] as Activity
    expect(saved.durationMin).toBe(90)
    expect(saved.tss).toBe(estimateTss({ ...act0(), durationMin: 90, speedKmh: 16.7 }, P))
    expect(saved.tss).not.toBe(50)
  })
  it('moč, uvožena kot kolo: šport se popravi, razdalja pri moči odpade', () => {
    const a = act0({ source: 'file', sport: 'kolo', distKm: 3 })
    const n = applyEdit(a, { ...editFormOf(a), sport: 'moc' }, P)
    expect(n.sport).toBe('moc'); expect(n.distKm).toBeNull()
  })
  it('vožnja z intervals.icu se ne ureja tu (vir je ura)', async () => {
    S.state = state({ activities: [act0({ source: 'intervals' })] })
    await render(<ActivitySheet id="a1" onClose={() => undefined} onDelete={() => undefined} />)
    expect(btn('Uredi')).toBeUndefined()
  })
})

describe('F17 + F27 + F28 + F29 ročni vnos', () => {
  it('privzeti šport: današnji trening iz načrta, sicer zadnji ročni vnos, sicer dogovor', () => {
    expect(defaultManualSport({ plan: [day({ kind: 'tek' })], activities: [], today: TODAY, fallback: 'kolo' })).toBe('tek')
    expect(defaultManualSport({ plan: [], activities: [act0({ sport: 'pohod' })], today: TODAY, fallback: 'kolo' })).toBe('pohod')
    expect(defaultManualSport({ plan: [], activities: [], today: TODAY, fallback: 'moc' })).toBe('moc')
  })
  it('tekač z današnjim tekom: obrazec začne s »Tek«; prazen »Shrani« → napaka pod poljem in fokus v trajanje', async () => {
    S.route = { name: 'aktivnosti', params: { nova: '1' } }
    S.state = state({ plan: [day({ kind: 'tek' })] })
    await render(<Aktivnosti />)
    const dlg = document.querySelector('[role="dialog"]')!
    const chips = [...dlg.querySelectorAll('button[aria-pressed]')]
    expect(chips.find(b => b.getAttribute('aria-pressed') === 'true')!.textContent).toBe('Tek')
    await click(btn('Shrani'))
    expect(document.activeElement?.id).toBe('ak-min')
    expect(document.getElementById('ak-err')!.textContent).toBe('Vpiši trajanje (min) ali razdaljo (km).')
    expect(store.toast).not.toHaveBeenCalled()
    // oznaka »Datum« je povezana s poljem
    const lbl = [...dlg.querySelectorAll('label')].find(l => l.textContent === 'Datum')!
    expect(document.getElementById(lbl.htmlFor)?.getAttribute('type')).toBe('date')
    S.route = { name: 'aktivnosti', params: {} }
  })
  it('glava in prazno stanje: »vadba«, ne »aktivnost«/»treningov«', async () => {
    S.state = state()
    await render(<Aktivnosti />)
    expect(txt()).toContain('Še ni vadb'); expect(txt()).not.toContain('Še ni treningov')
    await act(async () => root!.unmount()); root = null; div!.remove()
    S.state = state({ activities: [act0(), act0({ id: 'a2', date: '2026-10-20' })] })
    await render(<Aktivnosti />)
    expect(txt()).toMatch(/2 vadbi/); expect(txt()).not.toMatch(/\d aktivnost/)
  })
})

describe('F12 + F22 + F23 + F41 + F28 Uvoz', () => {
  const icu = { athleteId: 'i1', apiKey: 'k', name: 'Blaž', pushWorkouts: true }
  it('načrt samo s tekom: ena vrstica namesto stikala, brez »Vadbe gredo na uro«', async () => {
    S.state = state({ settings: { lang: 'sl', intervals: icu }, plan: [day({ kind: 'tek', date: '2026-10-22' }), day({ kind: 'moc', date: '2026-10-24' })] })
    await render(<Uvoz />)
    expect(txt()).toContain('Na uro gredo samo kolesarski treningi (strukturirani, v utripu ali vatih). Tek in moč vodiš v aplikaciji.')
    expect(btn('vklopljeno')).toBeUndefined()
    expect(txt()).not.toContain('Vadbe gredo na uro')
  })
  it('s kolesom: en blok »Treningi na uro« s korakom »Upload planned workouts«, pot enaka povsod', async () => {
    S.state = state({ settings: { lang: 'sl', intervals: icu }, plan: [day({ kind: 'kolo', date: '2026-10-22' })] })
    await render(<Uvoz />)
    expect(btn('vklopljeno')).toBeTruthy()
    expect(txt()).not.toContain('Vadbe gredo na uro')
    expect(txt().match(/Upload planned workouts/g)).toHaveLength(1)
    expect(txt()).not.toMatch(/Nastavitve → Povezave|okence Garmin/)
    expect(txt()).toContain('Settings → Connections → Garmin Connect → Connect')
  })
  it('povezava: prazna polja → napaka pod polji in fokus; API ključ se da pokazati', async () => {
    S.state = state()
    await render(<Uvoz />)
    await click(btn(/Garmin ura ali števec/))
    await click(btn('Poveži in uvozi'))
    expect(document.getElementById('icu-err')!.textContent).toBe('Vpiši Athlete ID in API ključ.')
    expect(document.activeElement?.id).toBe('icu-id')
    const key = document.getElementById('icu-key') as HTMLInputElement
    expect(key.type).toBe('password')
    await click(btn('pokaži'))
    expect(key.type).toBe('text'); expect(btn('skrij').getAttribute('aria-pressed')).toBe('true')
  })
  it('F20: .csv → ime datoteke in razlog (ne »Nobene datoteke nisem mogel prebrati.«)', async () => {
    S.state = state()
    await render(<Uvoz />)
    await click(btn(/Imam datoteke ali arhiv/))
    const inp = document.querySelector('input[type="file"][multiple]') as HTMLInputElement
    Object.defineProperty(inp, 'files', { configurable: true, value: [new File(['a,b'], 'moja.csv')] })
    await act(async () => { inp.dispatchEvent(new Event('change', { bubbles: true })) })
    await flush()
    expect(calls(store.toast).at(-1)![0]).toBe(`moja.csv: ${IMPORT_WHY.unsupported}.`)
  })
})

describe('F35 + F36 + F37 + F01 list cilja', () => {
  it('»različno« ostane različno; skupine čipov imajo ime; Potrdi brez imena → napaka pod poljem in fokus', async () => {
    S.state = state()
    await render(<GoalSheet open onClose={() => undefined} />)
    const g = document.querySelector('[role="group"][aria-labelledby="gs-lbl-time"]')!
    expect(document.getElementById('gs-lbl-time')!.textContent).toBe('Kdaj treniraš')
    expect([...g.querySelectorAll('button')].map(b => `${b.textContent}:${b.getAttribute('aria-pressed')}`)).toEqual(['zjutraj:false', 'čez dan:false', 'zvečer:false', 'različno:true'])
    for (const id of ['gs-lbl-seasons', 'gs-lbl-hours', 'gs-lbl-str']) expect(document.querySelector(`[role="group"][aria-labelledby="${id}"]`)).not.toBeNull()
    await click(btn('Potrdi in sestavi načrt'))
    expect(document.activeElement?.id).toBe('gs-name')
    expect(document.getElementById('gs-err')!.textContent).toContain('Vpiši ime dirke.')
    expect(store.toast).not.toHaveBeenCalled()
    expect(document.querySelector('label[for="gs-date"]')).not.toBeNull()
  })
  it('Potrdi z »različno« shrani trainTime null', async () => {
    S.state = state()
    await render(<GoalSheet open onClose={() => undefined} />)
    await type(document.getElementById('gs-name') as HTMLInputElement, 'Maraton Franja')
    await act(async () => { const d = document.getElementById('gs-date') as HTMLInputElement; Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(d, '2027-06-13'); d.dispatchEvent(new Event('input', { bubbles: true })); d.dispatchEvent(new Event('change', { bubbles: true })) })
    ;(store.updateProfile as unknown as { mockResolvedValue: (v: unknown) => void }).mockResolvedValue(P)
    await click(btn('Potrdi in sestavi načrt'))
    await flush()
    expect((calls(store.updateProfile).at(-1)![0] as Partial<Profile>).trainTime).toBeNull()
  })
  it('16 let z vpisano maščobo: brez »najboljše teže« v listu in na kartici cilja', async () => {
    const minor = { ...P, age: 16, bodyFatPct: 20, weightKg: 70, event: { name: 'Franja', date: '2027-06-13', distanceKm: 156 }, goalStart: { date: TODAY, ftp: 240, weightKg: 70 }, goal: 'dirka' } as unknown as Profile
    S.state = state({ profile: minor })
    await render(<GoalSheet open onClose={() => undefined} />)
    expect(txt()).not.toContain('Najboljša teža'); expect(txt()).toContain('Do 18. leta ciljne teže in maščobe ne računam — cilj so vati in redni trening.')
    expect(txt()).not.toMatch(/ITM 20,5|BMI 20,5/)
    await act(async () => root!.unmount()); root = null; div!.remove()
    await render(<GoalCard full />)
    expect(txt()).not.toContain('Najboljša teža')
  })
})

describe('H27 + F39 Prvi koraki', () => {
  const NOWF = '2026-10-19T08:00:00.000Z'
  const fx = (sports: string[], sessions: { type: string; min: number; part?: string }[], wish = 'x') => normalizeFocus({ wish, sports, aims: ['kondicija'], level: 1, sessions }, { age: 30, now: NOWF, by: 'pravila' })!
  it('samo fitnes (in hoja brez ure): koraka »Poveži uro« ni; tek: »teki«; nikjer »Apple«', () => {
    expect(watchStepText({ focus: fx(['fitnes'], [{ type: 'fitnes', part: 'celo', min: 50 }, { type: 'fitnes', part: 'celo', min: 50 }]) })).toBeNull()
    expect(watchStepText({ focus: fx(['fitnes', 'hribi'], [{ type: 'fitnes', part: 'celo', min: 50 }, { type: 'hribi', min: 60 }]) })).toBeNull()
    const run = watchStepText({ focus: fx(['tek'], [{ type: 'tek', min: 30 }, { type: 'tek', min: 30 }]) })!
    expect(run).toMatch(/teki pridejo sami/); expect(run).not.toMatch(/Apple/)
    expect(watchStepText({ focus: fx(['fitnes'], [{ type: 'fitnes', part: 'celo', min: 50 }], 'Fitnes. Imam Garmin uro.') })).toMatch(/vadbe pridejo same/)
    expect(watchStepText({ focus: null } as never)).toMatch(/vožnje pridejo same/)
  })
  it('16-letnik v fitnesu: na Danes ni »Poveži uro«', async () => {
    S.state = state({ profile: { ...P, age: 16, focus: fx(['fitnes'], [{ type: 'fitnes', part: 'celo', min: 50 }, { type: 'fitnes', part: 'celo', min: 50 }]) } })
    await render(<FirstSteps />)
    expect(txt()).not.toContain('Poveži uro')
  })
})

describe('G20 + G13 + F47 drobno', () => {
  it('poteg brez računa in ure: »Ni kaj osvežiti«; brez povezave: »Brez povezave«', () => {
    expect(ptrSkip({ user: false, icu: false, online: true })).toBe('Ni kaj osvežiti — podatki so na napravi.')
    expect(ptrSkip({ user: true, icu: false, online: false })).toBe('Brez povezave — osvežim, ko se vrne.')
    expect(ptrSkip({ user: true, icu: false, online: true })).toBeNull()
  })
  it('zemljevid brez povezave: slovensko, ne »Failed to fetch dynamically imported module«', () => {
    expect(mapErrText(new TypeError('Failed to fetch dynamically imported module: https://x/leaflet.js'), true)).toMatch(/^Zemljevid rabi povezavo/)
    expect(mapErrText(new Error('x'), false)).toMatch(/^Zemljevid rabi povezavo/)
    expect(mapErrText(new Error('Map container is already initialized.'), true)).toBe('Zemljevida ni bilo mogoče naložiti.')
  })
  it('povzetek kopije brez ničel', () => {
    expect(sp(backupSummary({ activities: 1, meals: 0, plan: 0, checkins: 0, profile: true }))).toBe('1 vadba')
    expect(sp(backupSummary({ activities: 0, meals: 2, plan: 14, checkins: 0, profile: true }))).toBe('2 obroka, 14 dni načrta')
    expect(backupSummary({ activities: 0, meals: 0, plan: 0, checkins: 0, profile: true })).toBe('profil in nastavitve')
  })
})
