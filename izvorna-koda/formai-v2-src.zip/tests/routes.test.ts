import { describe, it, expect } from 'vitest'
import { analyzeTrack, cleanTrack, dedupeRoutes, homeOf, speedAt, climbSeconds, routeTitle, directionOf, type RouteRec } from '../src/domain/routes/analyze'
import { needOf, suggestRoutes } from '../src/domain/routes/match'
import { dest, toGpx, brouterWebUrl } from '../src/domain/routes/brouter'
import type { LatLon } from '../src/domain/import/polyline'
import type { PlanDay } from '../src/domain/types'

// sintetična sled: krog ~ n km okoli (46.19, 14.50); klanec na delu poti
function loop(km: number, climb: { from: number; to: number; gain: number } | null, jitter = 0): { pts: LatLon[]; alt: number[] } {
  const n = Math.round(km * 1000 / 20), R = (km / (2 * Math.PI)), pts: LatLon[] = [], alt: number[] = []
  for (let i = 0; i <= n; i++) {
    const a = (i / n) * 2 * Math.PI
    pts.push(dest([46.19 + jitter, 14.5], R, (a * 180) / Math.PI) as LatLon)
    const f = i / n
    let h = 300
    if (climb) { if (f >= climb.from && f <= climb.to) h += climb.gain * (f - climb.from) / (climb.to - climb.from); else if (f > climb.to) h += climb.gain * Math.max(0, 1 - (f - climb.to) / (1 - climb.to)) }
    alt.push(h)
  }
  return { pts, alt }
}
const rec = (id: string, km: number, climb: { from: number; to: number; gain: number } | null, date = '2026-09-10', rodeMin = Math.round(km * 2.2)): RouteRec => {
  const t = loop(km, climb)
  return analyzeTrack({ id, source: 'voznja', name: id, date, rodeMin }, t.pts, t.alt)!
}
const now = new Date().toISOString()
const day = (o: Partial<PlanDay>): PlanDay => ({ id: 'd', date: '2026-09-22', kind: 'kolo', title: 'Z2 vzdržljivost', desc: '', durationMin: 90, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: now, updatedAt: now, ...o })
const P = { ftp: 240, weightKg: 79 }

describe('trase: analiza sledi', () => {
  it('dolžina, vzpon, klanec in krog', () => {
    const r = rec('hrib', 30, { from: 0.4, to: 0.5, gain: 180 })
    expect(r.km).toBeGreaterThan(29); expect(r.km).toBeLessThan(31)
    expect(r.loop).toBe(true)
    expect(r.gainM).toBeGreaterThan(160); expect(r.gainM).toBeLessThan(200)
    expect(r.climbs.length).toBe(1)
    const c = r.climbs[0]!
    expect(c.km).toBeGreaterThan(2.5); expect(c.km).toBeLessThan(3.5)
    expect(c.grade).toBeGreaterThan(5); expect(c.grade).toBeLessThan(7)
    expect(rec('ravna', 30, null).climbs.length).toBe(0)
  })
  it('cleanTrack: null točke izpusti, višine zapolni', () => {
    const t = cleanTrack([null, 46.1, 46.2, null], [null, 14.1, 14.2, 14.3], [null, null, 310, 320])
    expect(t.pts.length).toBe(2); expect(t.alt).toEqual([310, 310])
  })
  it('združi ponovljene vožnje iste trase in najde dom', () => {
    const a = rec('a', 30, null, '2026-09-01'), b = rec('b', 30.4, null, '2026-09-15'), c = rec('c', 60, null)
    const d = dedupeRoutes([a, b, c])
    expect(d.length).toBe(2)
    expect(d.find(x => x.km < 40)!.times).toBe(2)
    expect(d.find(x => x.km < 40)!.date).toBe('2026-09-15')
    const h = homeOf([a.start, b.start, c.start])!
    expect(Math.abs(h[0] - a.start[0])).toBeLessThan(0.01)
  })
  it('fizika: 240 W na ravnem ~33–38 km/h, na 6 % ~14–16 km/h (88 kg); klanec 3 km pri 265 W ~10–13 min', () => {
    const flat = speedAt(240, 0, 88) * 3.6, hill = speedAt(240, 0.06, 88) * 3.6
    expect(flat).toBeGreaterThan(33); expect(flat).toBeLessThan(38)
    expect(hill).toBeGreaterThan(14); expect(hill).toBeLessThan(16)
    const t = climbSeconds({ km: 3, grade: 6 }, 265, 88)
    expect(t).toBeGreaterThan(600); expect(t).toBeLessThan(780)
  })
})

describe('trase: predlog za trening', () => {
  const flat = rec('ravna', 36, null), hilly = rec('hrib', 32, { from: 0.35, to: 0.45, gain: 200 }), long = rec('dolga', 85, { from: 0.5, to: 0.55, gain: 120 })
  it('VO2max → trasa s klancem in navodilo za ponovitve', () => {
    const need = needOf(day({ title: 'VO2max 4 × 4 min', zone: 'Z5', role: 'kljucna', durationMin: 75, target: { lo: 259, hi: 276 } }), P)!
    expect(need.need).toBe('vo2'); expect(need.reps).toBe(4); expect(need.workMin).toBe(4)
    const s = suggestRoutes([flat, hilly, long], need, P, '2026-09-22')
    expect(s[0]!.rec.id).toBe('hrib')
    expect(s[0]!.climb).not.toBeNull()
    expect(s[0]!.how).toMatch(/4× gor 4 min pri 259–276 W/)
  })
  it('Z2 → ravna, dolga → dolga', () => {
    const z2 = suggestRoutes([hilly, flat, long], needOf(day({ durationMin: 80 }), P)!, P, '2026-09-22')
    expect(z2[0]!.rec.id).toBe('ravna')
    const d = suggestRoutes([hilly, flat, long], needOf(day({ title: 'Dolga Z2', role: 'dolga', durationMin: 200 }), P)!, P, '2026-09-22')
    expect(d[0]!.rec.id).toBe('dolga')
  })
  it('moč in dirka nimata trase', () => {
    expect(needOf(day({ kind: 'moc' }), P)).toBeNull()
    expect(needOf(day({ role: 'dirka' }), P)).toBeNull()
  })
})

describe('trase: izvoz', () => {
  it('GPX 1.1 z višinami in povezava na brouter-web', () => {
    const g = toGpx('Test <1>', [[46.1, 14.5], [46.2, 14.6]], [300, 310])
    expect(g).toContain('<gpx version="1.1"'); expect(g).toContain('<ele>310</ele>'); expect(g).toContain('Test &lt;1&gt;')
    expect(brouterWebUrl([[46.1, 14.5], [46.2, 14.6]])).toContain('lonlats=14.50000,46.10000;14.60000,46.20000')
    const q = dest([46.19, 14.5], 10, 90)
    expect(q[0]).toBeCloseTo(46.19, 1); expect(q[1]).toBeGreaterThan(14.6)
  })
})

describe('trase: dom in imena', () => {
  it('start daleč od doma → nižje; Garminovo ime → opis s smerjo', () => {
    const near = rec('doma', 34, { from: 0.4, to: 0.5, gain: 160 })
    const t = loop(34, { from: 0.4, to: 0.5, gain: 160 }, 0.25)            // ~28 km severneje
    const far = analyzeTrack({ id: 'dalec', source: 'voznja', name: 'Radovljica Kolesarjenje', date: '2026-09-18', rodeMin: 75 }, t.pts, t.alt)!
    const need = needOf(day({ title: 'VO2max 4 × 4 min', zone: 'Z5', role: 'kljucna', durationMin: 75, target: { lo: 259, hi: 276 } }), P)!
    const s = suggestRoutes([far, near], need, P, '2026-09-22', undefined, near.start)
    expect(s[0]!.rec.id).toBe('doma')
    expect(s.find(x => x.rec.id === 'dalec')!.why).toMatch(/start \d+ km od doma/)
    expect(routeTitle({ ...near, name: 'Vodice Kolesarjenje' })).toMatch(/^\d+(,\d)? km krog proti /)
    expect(routeTitle({ ...near, name: 'Krvavec' })).toBe('Krvavec')
    expect(directionOf(near.poly)).not.toBeNull()
  })
})

