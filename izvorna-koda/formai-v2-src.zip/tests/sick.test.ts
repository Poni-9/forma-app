import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { sickify, unsickify, sickifyBuilt, inSick, sickPeriod, SICK_TITLE } from '../src/domain/training/sick'
import { noDeficitDay, dailyTarget } from '../src/domain/nutrition/energy'
import { canReceive } from '../src/domain/training/swap'
import { easeDay, buildWeek } from '../src/domain/training/planner'
import { aiSafePlan, aiSafeView } from '../src/domain/ai/safe'
import { todayIso, addDays, weekStartIso } from '../src/domain/training/load'
import type { PlanDay, Profile } from '../src/domain/types'

const today = todayIso()
const NOW = new Date().toISOString()
const d = (n: number) => addDays(today, n)
const day = (id: string, date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id, date, kind: 'kolo', title: 'Z2', desc: 'Enakomerno.', durationMin: 90, zone: 'Z2', role: 'lahka', tssTarget: 60, source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })
const profile: Profile = { sex: 'm', age: 30, weightKg: 75, heightCm: 180, ftp: 250, hoursPerWeek: 8, goal: 'shujsati', deficit: 500, neat: 1.4, proteinGkg: 1.8, gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true }, strength: { on: true, equipment: 'home' }, strengthDays: 2, onboardingDone: true, createdAt: NOW, updatedAt: NOW } as Profile

describe('bolan sem — domena', () => {
  const plan = [
    day('a', d(0), { title: 'VO2max 5 × 4', zone: 'Z5', role: 'kljucna' }), day('am', d(0), { kind: 'moc', title: 'Moč', zone: null, role: 'moc' }),
    day('b', d(1)), day('c', d(2), { done: { at: NOW, activityId: null } }), day('r', d(3), { title: 'Kronometer', role: 'dirka', raceId: 'x' }),
    day('e', d(4)),
  ]
  it('en počitek na dan, prejšnji zapisi shranjeni; opravljeno in tekma ostaneta', () => {
    const out = sickify(plan, { from: d(0), to: d(3) }, NOW)
    expect(out.map(x => `${x.date}:${x.id}:${x.kind}`)).toEqual([`${d(0)}:a:pocitek`, `${d(1)}:b:pocitek`])
    expect(out[0]!.title).toBe(SICK_TITLE)
    expect(out[0]!.sickPrev!.map(x => x.id)).toEqual(['a', 'am'])
    // ponovno: dnevi, ki so že počitek zaradi bolezni, ostanejo
    expect(sickify([...plan.filter(x => x.date !== d(0)), out[0]!], { from: d(0), to: d(0) }, NOW)).toEqual([])
  })
  it('»Spet zdrav« vrne prvotne zapise od danes naprej (z istimi id-ji)', () => {
    const sick = sickify(plan, { from: d(-1), to: d(1) }, NOW)
    const merged = [...plan.filter(x => !sick.some(s => s.date === x.date)), ...sick, day('old', d(-1), { kind: 'pocitek', title: SICK_TITLE, sickPrev: [day('old', d(-1))] })]
    const back = unsickify(merged, today, NOW)
    expect(back.map(x => x.id).sort()).toEqual(['a', 'am', 'b'])
    expect(back.every(x => !x.sickPrev)).toBe(true)
  })
  it('obdobje in deficit: v bolezni brez deficita, izven nje po načrtu (varovalke nespremenjene)', () => {
    const p = { ...profile, sick: sickPeriod(today, 2) }
    expect(p.sick).toEqual({ from: today, to: d(1) })
    expect(inSick(p, d(1))).toBe(true); expect(inSick(p, d(2))).toBe(false)
    expect(noDeficitDay(p, today)).toMatch(/bolezen/)
    const sickT = dailyTarget(p, [], [], today)!, okT = dailyTarget(p, [], [], d(2))!
    expect(sickT.deficit).toBe(0)
    expect(okT.deficit).toBeGreaterThan(0)
    expect(sickPeriod(today, 40).to).toBe(d(13))
  })
  it('na dan bolezni ni mogoče premakniti treninga in »olajšaj dan« ga ne izbere', () => {
    const rest = { ...day('s', d(1)), kind: 'pocitek' as const, title: SICK_TITLE, sickPrev: [day('s', d(1))] }
    expect(canReceive(rest, day('x', d(0)), today)).toBe(false)
    const week = [day('t', today, { title: 'Prag', zone: 'Z4', role: 'kljucna' }), rest]
    const eased = easeDay(week, today)!
    expect(eased.some(x => x.date === d(1))).toBe(false)
  })
  it('na novo sestavljen teden: dnevi bolezni so počitek, sestavljeno shranjeno', () => {
    const ws = weekStartIso(today)
    const p = { ...profile, sick: { from: ws, to: addDays(ws, 2) } }
    const wk = buildWeek({ profile: p, activities: [], weekStart: ws, notBefore: ws })
    const first3 = wk.filter(x => x.date <= addDays(ws, 2))
    expect(new Set(first3.map(x => x.date)).size).toBe(first3.length)       // en zapis na dan
    expect(first3.every(x => x.kind === 'pocitek')).toBe(true)
    expect(first3.some(x => x.sickPrev?.length)).toBe(true)
    expect(sickifyBuilt(wk, { sick: null }, NOW)).toBe(wk)
  })
  it('v AI gre samo »počitek« — brez razloga in brez shranjenih treningov; obdobje bolezni ne gre v profil za AI', () => {
    const rest = { ...day('s', today), kind: 'pocitek' as const, title: SICK_TITLE, desc: 'bolezen', sickPrev: [day('s', today)] }
    const safe = aiSafePlan([rest], [])[0]!
    expect(safe.title).toBe('Počitek'); expect(safe).not.toHaveProperty('sickPrev'); expect(JSON.stringify(safe)).not.toMatch(/bolez/i)
    const v = aiSafeView({ profile: { ...profile, sick: { from: today, to: today } }, activities: [], plan: [rest], today })
    expect(v.profile).not.toHaveProperty('sick')
  })
})

describe('bolan sem — v aplikaciji', () => {
  beforeEach(async () => { await repo.wipeAll(); localStorage.clear(); await store.reloadAll() })
  it('počitek za 2 dni → spet zdrav jutri vrne jutrišnji trening; +1 dan podaljša', async () => {
    await store.updateProfile({ ...profile })
    await store.savePlanDays([day('a', d(0)), day('b', d(1), { title: 'Prag', zone: 'Z4', role: 'kljucna' }), day('c', d(2))])
    await store.setSick(2)
    const st = store.getState()
    expect(st.profile.sick).toMatchObject({ from: today, to: d(1) })
    expect(st.plan.filter(x => x.date <= d(1)).every(x => x.kind === 'pocitek' && x.title === SICK_TITLE)).toBe(true)
    expect(st.plan.find(x => x.date === d(2))!.kind).toBe('kolo')
    await store.extendSick()
    expect(store.getState().profile.sick!.to).toBe(d(2))
    expect(store.getState().plan.find(x => x.date === d(2))!.kind).toBe('pocitek')
    await store.endSick()
    const after = store.getState()
    expect(after.profile.sick).toBeNull()                         // začelo se je danes → obdobje izgine
    expect(after.plan.find(x => x.date === d(1))!.title).toBe('Prag')
    expect(after.plan.find(x => x.date === today)!.kind).toBe('kolo')
  })
})
