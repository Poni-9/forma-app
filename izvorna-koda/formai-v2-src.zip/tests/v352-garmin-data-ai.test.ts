import 'fake-indexeddb/auto'
import { describe, it, expect, vi } from 'vitest'

/**
 * VAROVALKA v3.52: podatki o menstrualnem ciklu (Garmin Women's Health API) in surovi Garminovi zdravstveni podatki
 * (stres, Body Battery) NIKOLI ne gredo v AI poziv — ne neposredno ne posredno. Preizkus: vsak poziv (graditelji in
 * dejanja v src/domain/ai) je ENAK z vklopljenim ciklom in brez njega; poleg tega nobena beseda o ciklu/fazi/menstruaciji.
 */
const h = vi.hoisted(() => ({ calls: [] as string[], text: 'Dober nasvet.', json: {} as unknown }))
vi.mock('../src/domain/ai/client', () => {
  class AiError extends Error { kind: string; constructor(kind: string, m: string) { super(m); this.kind = kind } }
  const textOf = (parts: { text?: string }[]) => parts.map(p => p.text || '').join('\n')
  return {
    AiError,
    askText: async (parts: { text?: string }[]) => { h.calls.push(textOf(parts)); return h.text },
    askJson: async (parts: { text?: string }[]) => { h.calls.push(textOf(parts)); return JSON.parse(JSON.stringify(h.json)) },
  }
})
vi.mock('../src/data/firebase', () => ({ idToken: async () => null, timeoutSignal: () => undefined, core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }) }))

import * as A from '../src/domain/ai/actions'
import { aiContext, coachDailyPrompt, weeklyReviewPrompt, adaptPlanPrompt } from '../src/domain/ai/prompts'
import { personalContext } from '../src/domain/ai/personal'
import { snapOf } from '../src/state/snap'
import { localAdvice } from '../src/domain/coach/local'
import { todayIso, addDays, weekStartIso } from '../src/domain/training/load'
import { cycleAdvice, type CycleDay } from '../src/domain/garmin/cycle'
import type { AppState } from '../src/state/store'
import type { Activity, PlanDay, Profile } from '../src/domain/types'

const today = todayIso()
const NOW = new Date().toISOString()
const d = (n: number) => addDays(today, n)

const profile: Profile = {
  name: 'Testna', sex: 'z', age: 29, weightKg: 62, heightCm: 168, ftp: 190, hoursPerWeek: 7, goal: 'dirka', deficit: 0, neat: 1.4, proteinGkg: 1.8,
  gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: true, powerMeterAuto: true }, strength: { on: true, equipment: 'home' }, strengthDays: 2,
  event: { name: 'Maraton Franja', date: addDays(today, 180), distanceKm: 156 }, cycleStart: weekStartIso(addDays(today, -28)),
  aiConsentAt: '2026-10-15T08:00:00.000Z', aiConsentV: 2, onboardingDone: true, createdAt: NOW, updatedAt: NOW,
}
// vožnje z Garmina neposredno (vir garmin) — smejo v AI
const ride = (i: number): Activity => ({
  id: 'g' + i, source: 'garmin', originHint: 'GARMIN_API', deviceName: 'Edge 540', sport: 'kolo', date: d(-1 - i * 3), start: d(-1 - i * 3) + 'T07:00:00.000Z', name: 'Vožnja',
  distKm: 40 + i, durationMin: 90 + i, avgHr: 135, avgPower: 160, tss: 70 + i, deviceWatts: true, aiEligible: true, geoRetain: true, expiresAt: null, ext: { garminId: String(1000 + i) }, createdAt: NOW, updatedAt: NOW,
})
const ACTS = Array.from({ length: 12 }, (_, i) => ride(i))
const day = (id: string, date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id, date, kind: 'kolo', title: 'Z2 vzdržljivost', desc: 'Enakomerno v Z2.', durationMin: 90, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })
const PLAN = [day('p1', today, { title: 'VO2max 5 × 4 min', zone: 'Z5', role: 'kljucna', durationMin: 75 }), day('p2', d(1)), day('p3', d(2), { kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, role: null }), day('p4', d(4), { title: 'Dolga Z2', role: 'dolga', durationMin: 200 })]
// cikel z opaznimi številkami (menstrualna faza, 3. dan, cikel 31 dni) in Garminovo zdravje (stres 97, Body Battery 19)
const CYCLE: CycleDay[] = [{ date: today, dayInCycle: 3, cycleLength: 31, periodLength: 6, phase: 'menstrualna', predicted: false, periodStartDate: d(-2) }]
const appOf = (withCycle: boolean): AppState => ({
  ready: true, profile,
  settings: { lang: 'sl', tests: [], garmin: { connected: true, permissions: ['ACTIVITY_EXPORT', 'HEALTH_EXPORT', 'MCT_EXPORT'], health: true, cycle: withCycle } },
  activities: ACTS, plan: PLAN, mealsToday: [], recentMeals: [], checkinToday: null, checkins: [{ date: today, sleepH: 7, mood: 3, soreness: 2, weightKg: 62 }],
  weather: null, today, toast: null, migration: null, user: null, authKnown: true, sync: { state: 'off' }, pro: false, routeLib: null, routesBusy: false,
  icuWorkouts: null, icuDiag: null, firstSync: null, accountClash: null, icuErr: null, syncDeleted: null, changes: [], storageError: null,
  // (popravki V7) pripravljenost bere včerajšnji stres — tudi ta ne sme v AI
  wellness: withCycle ? [{ date: d(-1), sleepH: 6.5, sleepScore: 70, hrv: 60, rhr: 48, stress: 97 }, { date: today, sleepH: 6.1, sleepScore: 71, hrv: 61.3, rhr: 47, stress: 97, bodyBattery: 19, bbAtWake: true }] : null,
  cycle: withCycle ? CYCLE : null, garminBusy: false, garminErr: null,
} as unknown as AppState)

const norm = (t: string) => t.replace(/Ura: \d\d:\d\d/g, 'Ura: HH:MM')
async function allPrompts(app: AppState): Promise<string[]> {
  h.calls.length = 0; h.text = 'Kratek nasvet.'
  const s = snapOf(app)
  const ws = weekStartIso(today)
  const rawWeek = app.plan.filter(x => x.date >= ws && x.date <= addDays(ws, 6))
  const out: string[] = []
  out.push(aiContext(app.activities, app.profile, app.plan))
  out.push(personalContext({ profile: app.profile, activities: app.activities, plan: app.plan, checkins: app.checkins, recentMeals: [], tests: [], today }))
  out.push(coachDailyPrompt(s.extra || '', app.plan.filter(x => x.date === today), 'Kako naj danes treniram?', app.activities).map(p => ('text' in p ? p.text : '')).join('\n'))
  out.push(adaptPlanPrompt(s.extra || '', rawWeek, app.activities).map(p => ('text' in p ? p.text : '')).join('\n'))
  out.push(weeklyReviewPrompt(s.extra || '').map(p => ('text' in p ? p.text : '')).join('\n'))
  await A.dailyAdvice(s, true)
  await A.chat(s, 'Kako mi gre? Kaj naj jem?', { msgs: [], summary: null })
  await A.weeklyReview(s, true)
  h.json = { dnevi: rawWeek.map(x => ({ date: x.date, kind: x.kind, title: x.title, desc: x.desc, durationMin: x.durationMin, zone: x.zone, tssTarget: null })), povzetek: 'ok' }
  await A.adaptWeek(s, rawWeek)
  h.json = { predlogi: [] }
  await A.mealIdeas(s, 900, 60)
  h.json = { dnevi: [], nakup: [] }
  await A.weekMenu(s, 2000, 120, [])
  h.json = { tip: 'x', opis: 'x', ocene: {}, moci: [], sibkosti: [], fokus: 'x' }
  await A.athleteProfile(s)
  return [...out, ...h.calls].map(norm)
}

describe('v3.52 cikel in Garminovo zdravje NIKOLI v AI', () => {
  it('vsi pozivi so enaki z vklopljenim ciklom in brez; nobene besede o ciklu, fazi, menstruaciji; stres in Body Battery ne', async () => {
    const withC = await allPrompts(appOf(true)), without = await allPrompts(appOf(false))
    expect(withC.length).toBeGreaterThan(8)
    expect(withC).toEqual(without)
    const all = withC.join('\n')
    expect(all.length).toBeGreaterThan(2000)
    for (const w of [/menstru/i, /lutealn/i, /folikul/i, /ovulac/i, /\bcikl/i, /cycle/i, /dayInCycle/i, /mct\b/i, /body ?battery/i, /\bstres/i]) expect(all).not.toMatch(w)
    // »faza« je dovoljena samo kot faza treninga (osnova, gradnja …) — nikoli menstrualna/lutealna
    for (const line of all.split('\n')) if (/faz/i.test(line)) expect(line).not.toMatch(/menstru|luteal|folik|ovul|cikl/i)
  })
  it('pravila cikla so za UI: cycleAdvice da ponudbo in opombe, a trener brez AI (localAdvice) jih ne vplete sam', () => {
    const app = appOf(true)
    const adv = cycleAdvice(app.cycle, app.plan.find(x => x.date === today)!, today)
    expect(adv.easeOffer).toBe(true); expect(adv.nutritionNote).toMatch(/železa/)
    const txt = localAdvice({ profile: app.profile, plan: app.plan, activities: app.activities, checkins: app.checkins, checkinToday: app.checkins[0]!, wellness: app.wellness, wellnessOn: true, mealsToday: [], recentMeals: [], weather: null, today, foodPrefs: null })
    expect(txt).not.toMatch(/menstru|luteal|cikl/i)
  })
})
