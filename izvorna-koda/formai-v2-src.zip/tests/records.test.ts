import { describe, it, expect } from 'vitest'
import { records, yearTotals } from '../src/domain/training/records'
import type { Activity } from '../src/domain/types'

const NOW = '2026-10-03T08:00:00.000Z'
const a = (id: string, date: string, o: Partial<Activity> = {}): Activity => ({ id, source: 'intervals', sport: 'kolo', date, name: 'Vožnja ' + id, durationMin: 90, distKm: 40, elevM: 300, aiEligible: true, geoRetain: true, createdAt: NOW, updatedAt: NOW, ...o })

describe('rekordi in letni seštevki', () => {
  const list = [
    a('1', '2026-06-13', { distKm: 156, durationMin: 330, elevM: 1600 }),
    a('2', '2026-09-26', { distKm: 85, durationMin: 194, elevM: 2340 }),
    a('3', '2026-09-28', { distKm: 40, durationMin: 400 }),
    a('4', '2026-09-29', { distKm: 50, durationMin: 120 }),
    a('t', '2026-09-30', { sport: 'tek', distKm: 300, durationMin: 900, elevM: 9000 }),
    a('5', '2025-05-01', { distKm: 60, durationMin: 150, elevM: 500 }),
    a('6', '2025-11-01', { distKm: 70, durationMin: 160, elevM: 500 }),
  ]
  it('najdaljša, najdlje, največ vzpona, največji teden (samo kolo); »nov« iz zadnjih 14 dni', () => {
    const r = records(list, '2026-10-03')
    expect(r.distance).toMatchObject({ value: 156, date: '2026-06-13', fresh: false })
    expect(r.duration).toMatchObject({ value: 400, date: '2026-09-28', fresh: true })
    expect(r.climb).toMatchObject({ value: 2340, date: '2026-09-26', fresh: true })
    expect(r.week).toMatchObject({ weekStart: '2026-09-28', min: 520, km: 90, fresh: true })
    expect(records([], '2026-10-03')).toEqual({ distance: null, duration: null, climb: null, week: null })
  })
  it('letos do danes proti lani do istega dne', () => {
    const y = yearTotals(list, '2026-10-03')
    expect(y.year).toBe(2026)
    expect(y.now).toEqual({ n: 4, km: 331, min: 1044, elev: 4540 })
    expect(y.prev).toEqual({ n: 1, km: 60, min: 150, elev: 500 })
    expect(yearTotals([a('x', '2023-02-28')], '2024-02-29').prev.n).toBe(1)
  })
})
