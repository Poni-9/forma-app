// v3.50 PREMOR (domena): »Ta teden …« — premor do nedelje (brez treningov / brez kolesa), sestava tedna, ure po premoru,
// samodejni premiki, prehrana, lokalni trener, AI kontekst in prepoznava stavkov v klepetu.
import { describe, it, expect, vi } from 'vitest'

const h = vi.hoisted(() => ({ calls: [] as string[], json: null as unknown }))
vi.mock('../src/domain/ai/client', () => {
  class AiError extends Error { kind: string; constructor(kind: string, m: string) { super(m); this.kind = kind } }
  const textOf = (parts: { text?: string }[]) => parts.map(p => p.text || '').join('\n')
  return {
    AiError,
    askText: async (parts: { text?: string }[]) => { h.calls.push(textOf(parts)); return 'Odgovor modela.' },
    askJson: async (parts: { text?: string }[]) => { h.calls.push(textOf(parts)); return JSON.parse(JSON.stringify(h.json)) },
  }
})

import { pausePeriod, pauseify, pauseIntent, pauseLock, pauseLine, activePause, pauseWeeks, PAUSE_TITLE, PAUSE_TITLE_KOLO, BACK_TITLE_PAUSE, type WeekPause } from '../src/domain/training/pause'
import { buildWeek, planHours, easeDay, weekBikeMinutes, FRANJA_2027 } from '../src/domain/training/planner'
import { raceLock } from '../src/domain/training/protect'
import { missedKeys } from '../src/domain/training/missed'
import { adaptToState } from '../src/domain/training/state'
import { dailyTarget } from '../src/domain/nutrition/energy'
import { localAdvice, localReview, type LocalCoachCtx } from '../src/domain/coach/local'
import { aiContext } from '../src/domain/ai/prompts'
import { aiSafeView } from '../src/domain/ai/safe'
import * as A from '../src/domain/ai/actions'
import { addDays } from '../src/domain/training/load'
import type { Activity, PlanDay, Profile } from '../src/domain/types'

const NOW = '2026-10-21T08:00:00.000Z'
const T = '2026-10-21'                         // sreda; teden od 19. 10., nedelja 25. 10.
const W0 = '2026-10-19', W1 = '2026-10-26', W2 = '2026-11-02'
/** kolesar s Franjo, 9 h, moč doma 2×, načrt od 31. 8. (osnova: 19. 10. 1. teden bloka, 26. 10. 2., 2. 11. 3.) */
const P = (o: Partial<Profile> = {}): Profile => ({
  name: 'B', sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, ftpDate: '2026-09-20', maxHr: 195, restHr: 48, lthr: 184, level: 3,
  gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, hoursPerWeek: 9, hoursMode: 'own',
  strength: { on: true, equipment: 'home' }, strengthDays: 2, goal: 'dirka', deficit: 400, neat: 1.4, proteinGkg: 1.8,
  event: { ...FRANJA_2027 }, races: [], cycleStart: '2026-08-31', onboardingDone: true, aiConsentAt: NOW, aiConsentV: 2, createdAt: NOW, updatedAt: NOW, ...o,
} as Profile)
const ride = (date: string, min: number): Activity => ({ id: `a${date}-${min}`, source: 'manual', sport: 'kolo', date, name: 'x', durationMin: min, tss: Math.round(min * 0.7), aiEligible: true, geoRetain: true, createdAt: NOW, updatedAt: NOW } as Activity)
/** vožnje tor/čet/sob v tednih od `from` do `to` (ponedeljki), skupaj `h` ur na teden */
const weekly = (from: string, to: string, hrs: number): Activity[] => {
  const out: Activity[] = []
  for (let ws = from; ws <= to; ws = addDays(ws, 7)) for (const k of [1, 3, 5]) out.push(ride(addDays(ws, k), Math.round((hrs * 60) / 3)))
  return out
}
const ACTS = weekly('2026-08-31', '2026-10-12', 8)
const pause = (o: Partial<WeekPause> = {}): WeekPause => ({ from: T, to: '2026-10-25', mode: 'vse', ...o })
const week0 = (p: Profile = P()) => buildWeek({ profile: p, activities: ACTS, weekStart: W0, notBefore: T, today: T })
const inRange = (d: PlanDay, w: WeekPause) => d.date >= w.from && d.date <= w.to
const train = (d: PlanDay) => d.kind !== 'pocitek'

describe('obdobje premora', () => {
  it('od danes do nedelje; »še naslednji teden« do nedelje čez teden; največ 14 dni', () => {
    expect(pausePeriod(T, 'vse')).toEqual({ from: T, to: '2026-10-25', mode: 'vse' })
    expect(pausePeriod(T, 'kolo', { twoWeeks: true, reason: 'potovanje' })).toEqual({ from: T, to: '2026-11-01', mode: 'kolo', reason: 'potovanje' })
    const mon = pausePeriod('2026-10-19', 'vse', { twoWeeks: true })
    expect(mon.to).toBe('2026-11-01')                       // pon–ned čez teden = 14 dni
    expect(pausePeriod('2026-10-25', 'vse').to).toBe('2026-10-25')   // nedelja: samo danes
  })
  it('besedilo: »Ta teden: premor do nedelje (brez kolesa)«', () => {
    expect(pauseLine(pause({ mode: 'kolo' }), T)).toBe('Ta teden: premor do nedelje (brez kolesa)')
    expect(pauseLine(pause(), T)).toBe('Ta teden: premor do nedelje')
    expect(pauseLine(pause({ to: '2026-11-01' }), T)).toBe('Ta teden: premor do nedelje, 1. 11.')
    expect(pauseLine(pause({ to: '2026-10-25', from: '2026-10-25' }), '2026-10-25')).toBe('Danes: premor')
    expect(activePause(P({ weekPause: pause() }), '2026-10-26')).toBeNull()
    expect(activePause(P({ weekPause: pause() }), '2026-10-25')).not.toBeNull()
  })
})

describe('premor do nedelje zbriše treninge', () => {
  it('brez treningov: od danes do nedelje samo »Premor«, opravljeno ostane, pretekli dnevi ostanejo', () => {
    const w = pause()
    const plan = week0().map(d => (d.date === T && d.kind === 'kolo' ? { ...d, done: { at: NOW, activityId: null } } : d))
    const out = pauseify(plan, w, T, NOW)
    const after = [...plan.filter(d => !out.some(o => o.date === d.date) || d.done), ...out.filter(o => !o.done)]
    // danes je opravljeno: ostane (in nič drugega neopravljenega ta dan ni trening)
    expect(after.filter(d => d.date === T && d.done)).toHaveLength(1)
    const rest = after.filter(d => inRange(d, w) && d.date > T)
    expect(rest.length).toBeGreaterThan(0)
    expect(rest.every(d => d.kind === 'pocitek')).toBe(true)
    expect(rest.some(d => d.title === PAUSE_TITLE)).toBe(true)
    expect(out.every(d => d.date >= T)).toBe(true)
  })
  it('brez kolesa: vožnje in testi odpadejo, moč ostane (kolo na koncu moči tudi odpade)', () => {
    const w = pause({ mode: 'kolo' })
    const plan = week0()
    expect(plan.some(d => d.kind === 'moc' && inRange(d, w))).toBe(true)
    const withTail = plan.map(d => (d.kind === 'moc' ? { ...d, title: `${d.title} + kolo 30 min`, durationMin: d.durationMin + 30, tail: { kind: 'kolo' as const, title: 'Z2', desc: 'Z2', durationMin: 30 } } : d))
    const out = pauseify(withTail, w, T, NOW)
    expect(out.some(d => d.kind === 'kolo' || d.kind === 'test')).toBe(false)
    const moc = out.filter(d => d.kind === 'moc')
    expect(moc.length).toBe(withTail.filter(d => d.kind === 'moc' && inRange(d, w)).length)
    expect(moc.every(d => !d.tail && !/\+ kolo/.test(d.title))).toBe(true)
    expect(out.some(d => d.title === PAUSE_TITLE_KOLO)).toBe(true)
  })
  it('tekma ostane (premor ne briše tekme)', () => {
    const plan = [...week0(), { id: 'r1', date: '2026-10-25', kind: 'kolo', title: 'Tekma', desc: '', durationMin: 120, role: 'dirka', raceId: 'x', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null } as PlanDay]
    const out = pauseify(plan, pause(), T, NOW)
    expect(out.find(d => d.id === 'r1')).toBeTruthy()
  })
})

describe('sestava tedna v premoru (ensureWeeks, »Sestavi znova«)', () => {
  it('buildWeek s premorom: v premoru ni treninga; brez kolesa ostane moč', () => {
    const vse = week0(P({ weekPause: pause() }))
    expect(vse.filter(d => d.date >= T).some(train)).toBe(false)
    const kolo = week0(P({ weekPause: pause({ mode: 'kolo' }) }))
    expect(kolo.filter(d => d.date >= T).some(d => d.kind === 'kolo' || d.kind === 'test')).toBe(false)
    expect(kolo.filter(d => d.date >= T).some(d => d.kind === 'moc')).toBe(true)
  })
  it('naslednji teden v »še naslednji teden« je tudi prazen; brez premora ima treninge', () => {
    const p = P({ weekPause: pause({ to: '2026-11-01' }) })
    expect(buildWeek({ profile: p, activities: ACTS, weekStart: W1, notBefore: W1, today: T }).some(train)).toBe(false)
    expect(buildWeek({ profile: P(), activities: ACTS, weekStart: W1, notBefore: W1, today: T }).some(train)).toBe(true)
  })
  it('načrt po meri (dogovor) dobi premor tudi', () => {
    const f = { v: 1, mode: 'meri', wish: 'fitnes', sports: ['fitnes'], aims: ['moc'], muscles: [], days: 3, minutes: 45, level: 2, equipment: ['fitnes'], title: 'Moč', sessions: [{ type: 'fitnes', part: 'celo', min: 45 }, { type: 'fitnes', part: 'celo', min: 45 }, { type: 'fitnes', part: 'celo', min: 45 }], notes: [], at: NOW, by: 'pravila' }
    const p = P({ focus: f as never, event: null, cycleStart: W0 })
    const free = buildWeek({ profile: p, activities: [], weekStart: W0, notBefore: T, today: T })
    expect(free.some(d => d.date >= T && train(d))).toBe(true)
    const paused = buildWeek({ profile: { ...p, weekPause: pause() }, activities: [], weekStart: W0, notBefore: T, today: T })
    expect(paused.some(d => d.date >= T && train(d))).toBe(false)
  })
})

describe('samodejni premiki ne gredo na dan premora', () => {
  const p = P({ weekPause: pause({ from: '2026-10-22' }) })
  const week = (): PlanDay[] => [
    { id: 't', date: T, kind: 'kolo', title: 'Sweet spot 3 × 12 min', desc: '', durationMin: 90, zone: 'Z3', role: 'kljucna', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null },
    ...['2026-10-22', '2026-10-23', '2026-10-24', '2026-10-25'].map(date => ({ id: 'r' + date, date, kind: 'pocitek', title: PAUSE_TITLE, desc: '', durationMin: 0, source: 'rules', createdAt: NOW, updatedAt: NOW, done: null } as PlanDay)),
  ]
  it('»Olajšaj dan« ne prestavi seje na počitek premora (seja odpade)', () => {
    const free = easeDay(week(), T, raceLock(week(), P()))!
    expect(free.some(d => d.date > T)).toBe(true)                          // brez premora gre na prost dan
    const out = easeDay(week(), T, pauseLock(raceLock(week(), p), p))!
    expect(out.every(d => d.date === T)).toBe(true)
  })
  it('zamujen ključni ne gre na lahek dan v premoru', () => {
    const plan: PlanDay[] = [
      { id: 'k', date: '2026-10-20', kind: 'kolo', title: 'VO2max', desc: '', durationMin: 75, zone: 'Z5', role: 'kljucna', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null },
      { id: 'e', date: '2026-10-23', kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null },
    ]
    expect(missedKeys(plan, [], T, raceLock(plan, P()))[0]!.to?.date).toBe('2026-10-23')
    expect(missedKeys(plan, [], T, pauseLock(raceLock(plan, p), p))[0]!.to).toBeNull()
  })
  it('počutje v premoru brez kolesa: samodejno sprehod, ne »lahko vrtenje«', () => {
    const pk = P({ weekPause: pause({ mode: 'kolo' }) })
    const plan: PlanDay[] = [{ id: 'm', date: T, kind: 'moc', title: 'Moč — noge', desc: '', durationMin: 30, role: 'moc', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null }]
    const r = adaptToState(pk, plan, T, { level: 2, legs: false, reasons: ['slabo spal'] }, { now: NOW })!
    expect(r.mode).toBe('sprehod')
    expect(r.days.some(d => d.kind === 'kolo')).toBe(false)
    expect(adaptToState(P(), plan, T, { level: 2, legs: false, reasons: ['slabo spal'] }, { now: NOW })!.mode).toBe('vrtenje')
  })
})

describe('naslednji teden po premoru', () => {
  it('teden premora (7 dni) ne šteje kot dolg premor: naslednji teden ni 4 h in ni nad zadnjim obremenilnim pred premorom', () => {
    // premor ves teden 26. 10. (2. teden bloka), naslednji teden 2. 11. je 3. teden bloka (9,5 h)
    const acts = [...weekly('2026-08-31', '2026-10-19', 8)]
    const w = pause({ from: W1, to: '2026-11-01' })
    const before = planHours(P(), acts, W0, W0).hours              // zadnji obremenilni pred premorom (7,5 h)
    const hNew = planHours(P({ weekPause: w }), acts, W2, W2).hours
    const hOld = planHours(P(), acts, W2, W2).hours                 // brez zapisa o premoru: »po premoru« iz resnice
    expect(hNew).toBeGreaterThan(4)
    expect(hNew).toBeLessThanOrEqual(before)
    expect(hNew).toBeGreaterThanOrEqual(before - 0.5)
    expect(hOld).toBeLessThan(hNew)                                 // prej: teden premora je vlekel ure dol
    const b = buildWeek({ profile: P({ weekPause: w }), activities: acts, weekStart: W2, notBefore: W2, today: W2 })
    expect(weekBikeMinutes(b) / 60).toBeLessThanOrEqual(before * 1.1)
    expect(b.some(d => d.title === BACK_TITLE_PAUSE)).toBe(false)    // kratek premor: brez »lahko po premoru«
    expect(b.some(d => /Po premoru teden kot pred premorom/.test(d.why || ''))).toBe(true)
  })
  it('premor sredi tedna: naslednji teden je normalen teden (kot brez premora z vsemi vožnjami)', () => {
    const acts = [...ACTS, ride('2026-10-20', 90)]                  // pon–tor še vožnja, od srede premor
    const hPause = planHours(P({ weekPause: pause() }), acts, W1, W1).hours
    const hFull = planHours(P(), [...ACTS, ...weekly(W0, W0, 7.5)], W1, W1).hours
    expect(hPause).toBe(hFull)
    expect(planHours(P(), acts, W1, W1).hours).toBeLessThan(hPause)  // prej: 7,5 namesto 8,5 h
  })
  it('dva tedna premora: lažji prehod (~80 %), prva dva dneva lahka Z2 — ne 4 h', () => {
    const acts = [...ACTS, ride('2026-10-20', 90)]
    const p = P({ weekPause: pause({ to: '2026-11-01' }) })
    const ph = planHours(p, acts, W2, W2)
    expect(ph.hours).toBeGreaterThan(4)
    expect(ph.hours).toBeLessThan(planHours(P(), [...ACTS, ...weekly(W0, W1, 8)], W2, W2).hours)
    expect(ph.pause).toBe('dolg')
    expect(planHours(P(), acts, W2, W2).hours).toBe(4)              // prej: reset na 4 h
    const b = buildWeek({ profile: p, activities: acts, weekStart: W2, notBefore: W2, today: W2 })
    const first2 = b.filter(d => d.date <= '2026-11-03' && (d.kind === 'kolo' || d.kind === 'test'))
    expect(first2.every(d => d.role === 'lahka' && d.durationMin <= 60)).toBe(true)
    expect(b.some(d => d.title === BACK_TITLE_PAUSE)).toBe(true)
  })
  it('tedni premora so izpuščeni iz ur iz resnice', () => {
    expect([...pauseWeeks(P({ weekPause: pause({ to: '2026-11-01' }) }))]).toEqual([W0, W1])
    expect(pauseWeeks(P()).size).toBe(0)
  })
})

describe('prehrana, Danes, lokalni trener in AI vidijo premor', () => {
  const ctx = (p: Profile, plan: PlanDay[]): LocalCoachCtx => ({ profile: p, plan, activities: ACTS, checkins: [], checkinToday: null, wellness: null, wellnessOn: false, mealsToday: [], recentMeals: [], weather: null, today: T })
  it('dnevni cilj v premoru = dan brez treninga', () => {
    const plan = week0()
    const day = plan.filter(d => d.date === '2026-10-24')
    expect(day.some(d => d.kind === 'kolo')).toBe(true)
    const paused = pauseify(plan, pause(), T, NOW).filter(d => d.date === '2026-10-24')
    const p = P({ weekPause: pause() })
    const withRide = dailyTarget(p, [], day, '2026-10-24', { today: T, hour: 8 })!
    const rest = dailyTarget(p, [], paused, '2026-10-24', { today: T, hour: 8 })!
    const none = dailyTarget(p, [], [], '2026-10-24', { today: T, hour: 8 })!
    expect(rest.kcal).toBe(none.kcal)
    expect(rest.kcal).toBeLessThan(withRide.kcal)
  })
  it('lokalni trener: premor namesto »drži se načrta«, brez goriva za trening', () => {
    const p = P({ weekPause: pause() })
    const plan = [...week0().filter(d => d.date < T), ...pauseify(week0(), pause(), T, NOW)]
    const t = localAdvice(ctx(p, plan))
    expect(t).toContain('Ta teden: premor do nedelje')
    expect(t).not.toMatch(/Na kolesu:|Pred:|Gorivo/)
    expect(localReview(ctx(p, plan))).toMatch(/ne štejejo kot zaostanek/)
  })
  it('AI kontekst pove premor; razlog »bolan« ne gre v AI', () => {
    const p = P({ weekPause: { ...pause({ mode: 'kolo' }), reason: 'bolan' } })
    const v = aiSafeView({ profile: p, activities: ACTS, plan: [], today: T })
    expect(v.profile.weekPause?.reason ?? null).toBeNull()
    const c = aiContext(ACTS, v.profile, [])
    expect(c).toContain('PREMOR po uporabnikovi izbiri')
    expect(c).toContain('brez kolesa')
    expect(c).not.toMatch(/bolan/)
    expect(aiContext(ACTS, P({ weekPause: { ...pause(), reason: 'potovanje' } }), [])).toContain('razlog: potovanje')
  })
  it('klepet: ob »ta teden nočem nič« trener ne trdi, da je načrt spremenil — gumb je pod odgovorom', async () => {
    h.calls = []
    await A.chat({ profile: P(), activities: ACTS, plan: [], today: T }, 'Ta teden nočem nič več.', { msgs: [], summary: null })
    expect(h.calls[0]).toContain('»Uveljavi: ta teden brez treningov«')
    expect(h.calls[0]).toContain('Ne trdi, da si načrt spremenil')
    h.calls = []
    await A.chat({ profile: P(), activities: ACTS, plan: [], today: T }, 'Koliko OH na dolgi vožnji?', { msgs: [], summary: null })
    expect(h.calls[0]).not.toContain('Uveljavi:')
    expect(h.calls[0]).toContain('nikoli ne trdi, da si ga spremenil')
  })
  it('AI »Prilagodi teden« ne vrne treninga na dan premora', async () => {
    const p = P({ weekPause: pause() })
    const week: PlanDay[] = [
      { id: 'a', date: '2026-10-20', kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null },
      { id: 'b', date: '2026-10-22', kind: 'pocitek', title: PAUSE_TITLE, desc: '', durationMin: 0, source: 'rules', createdAt: NOW, updatedAt: NOW, done: null },
    ]
    h.json = { dnevi: [{ date: '2026-10-20', kind: 'kolo', title: 'Z2 lahko', desc: 'x', durationMin: 50, zone: 'Z2', tssTarget: 30 }, { date: '2026-10-22', kind: 'kolo', title: 'VO2max 5 × 4', desc: 'x', durationMin: 75, zone: 'Z5', tssTarget: 90 }], povzetek: 'ok' }
    const r = await A.adaptWeek({ profile: p, activities: ACTS, plan: week, today: '2026-10-20' }, week)
    expect(r.days.find(d => d.date === '2026-10-22')!.kind).toBe('pocitek')
    expect(r.days.find(d => d.date === '2026-10-20')!.title).toBe('Z2 lahko')
  })
})

describe('prepoznava stavkov v klepetu (na napravi)', () => {
  const POS: [string, 'vse' | 'kolo'][] = [
    ['Ta teden nočem nič.', 'vse'],
    ['ta teden ne bom treniral', 'vse'],
    ['Ta teden brez kolesa', 'kolo'],
    ['ne bom kolesaril ta teden', 'kolo'],
    ['Ta teden počivam.', 'vse'],
    ['preskoči ta teden', 'vse'],
    ['Ta teden ne želim nič', 'vse'],
    ['jaz ta teden ne bom nič na kolesu', 'kolo'],
    ['ta teden nočem več nič trenirat', 'vse'],
    ['do nedelje ne bom treniral', 'vse'],
    ['ta teden ne grem na kolo, tečem pa', 'kolo'],
    ['rad bi ta teden počival', 'vse'],
    ['ta teden si vzamem premor', 'vse'],
    ['ta tedn nocem nc trenirat', 'vse'],
    ['Ta teden ne bom več treniral, sem preveč utrujen', 'vse'],
    ['ta teden bom brez treningov', 'vse'],
  ]
  it.each(POS)('»%s« → premor (%s)', (t, mode) => {
    expect(pauseIntent(t)?.mode).toBe(mode)
  })
  const NEG = [
    'ta teden nočem počivati',
    'ne bom počival ta teden, hočem trenirat',
    'ali naj ta teden počivam?',
    'ta teden hočem več treninga',
    'ta teden bom več kolesaril',
    'naslednji teden ne bom treniral',
    'ta teden sem počival dva dni',
    'kaj naj danes naredim?',
    'ta teden sem bil trikrat na kolesu',
    'nočem nič',
  ]
  it.each(NEG)('»%s« → ni premor', t => {
    expect(pauseIntent(t)).toBeNull()
  })
  it('»ta in naslednji teden« → dva tedna', () => {
    expect(pauseIntent('ta in naslednji teden ne bom treniral')).toEqual({ mode: 'vse', twoWeeks: true })
  })
})
