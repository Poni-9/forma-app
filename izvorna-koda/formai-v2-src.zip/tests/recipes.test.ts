import { describe, it, expect } from 'vitest'
import { DISHES, dishesFor, exclusionsOf, dishOk, fitDish, dayRecipes, whyRecipe } from '../src/domain/nutrition/recipes'
import { dayMealPlan, F, TPL, qtyOf } from '../src/domain/nutrition/dayplan'

const kcalOf = (items: { key: string; qty: number }[]) => items.reduce((a, i) => a + (F[i.key]!.kcal * i.qty) / F[i.key]!.per, 0)

describe('recepti', () => {
  it('knjižnica: vsaka predloga ima vsaj 2 jedi, vse sestavine obstajajo, koraki in minute', () => {
    for (const tpl of Object.keys(TPL)) expect(DISHES.filter(d => d.tpl === tpl).length, tpl).toBeGreaterThanOrEqual(2)
    for (const d of DISHES) { expect(d.steps.length).toBeGreaterThan(0); expect(d.minutes).toBeGreaterThan(0); for (const [k] of d.items) expect(F[k], `${d.id}: ${String(k)}`).toBeTruthy() }
    expect(new Set(DISHES.map(d => d.id)).size).toBe(DISHES.length)
  })
  it('želje: vegetarijansko, brez laktoze, ne maram rib — jedi s tem izpadejo; če nič ne ostane, vse', () => {
    expect(exclusionsOf('vegetarijanec sem').contains).toEqual(['meso', 'riba'])
    // v3.49 (B13): »brez laktoze« ni »brez mleka« — mlečni izdelki brez laktoze ostanejo
    expect(exclusionsOf('brez laktoze, ne maram rib')).toMatchObject({ contains: ['riba'], lactoseFree: true })
    expect(exclusionsOf('ne maram brokolija').words).toEqual(['brokolija'])
    expect(dishesFor('kosilo', 'vegetarijanec').every(d => !d.contains.includes('meso') && !d.contains.includes('riba'))).toBe(true)
    // v3.50 (E02): tri veganska kosila s sojinimi koščki (bolonjska, golaž, ajdova kaša)
    expect(dishesFor('kosilo', 'vegan').map(d => d.id)).toEqual(['cicerika', 'tofu-riz', 'test-tofu', 'ricet', 'jota', 'kuskus-tofu', 'bolonjska-soj', 'golaz-soj', 'ajda-sojkos'])   // v3.48: lahko vegansko kosilo pred vožnjo; v3.49: ričet, jota, kuskus s tofujem
    expect(dishOk(DISHES.find(d => d.id === 'pisc-riz')!, exclusionsOf('ne maram piščanca'))).toBe(false)
    expect(dishesFor('pred', 'vegan, brez glutena').map(d => d.id)).toEqual(['sadje-pred', 'sok-pred'])   // za vsak obrok vsaj ena veganska jed brez glutena (v3.50 E17: tudi brez banane)
    for (const tpl of Object.keys(TPL)) expect(dishesFor(tpl, 'vegan, brez glutena').length, tpl).toBeGreaterThan(0)
    expect(dishesFor('kosilo', 'ne maram riža, krompirja, testenin, piščanca, tune, čičerike, tofuja, purana, lososa').length, 'besede popustijo, ko izločijo vse').toBeGreaterThan(0)
    expect(exclusionsOf('nisem vegetarijanec, rad imam ribe').contains).toEqual([])
    // v3.50 (E04): piščanec je živilo, ne vse meso — gre med besede (golaž in bolonjska ostaneta)
    expect(exclusionsOf('ne maram rib, piščanca, brokolija').contains).toEqual(['riba'])
    expect(exclusionsOf('ne maram rib, piščanca, brokolija').words).toEqual(['piščanca', 'brokolija'])
    expect(exclusionsOf('alergija na oreške, brez laktoze')).toMatchObject({ contains: ['oreski'], lactoseFree: true })
  })
  it('beljakovinski dodatek ne napihne kalorij: fižol v humusu za malico 290 kcal / 40 g ostane pod +15 %', () => {
    const h = fitDish(DISHES.find(x => x.id === 'humus-m')!, 290, 40, { deficit: true })
    expect(h.kcal).toBeLessThanOrEqual(290 * 1.15 + 5)
    const j = fitDish(DISHES.find(x => x.id === 'jogurt-m')!, 290, 40, { deficit: true })
    expect(j.kcal).toBeLessThanOrEqual(290 * 1.15 + 5)
    for (const d of DISHES) for (const [kc, p] of [[290, 40], [600, 50], [900, 30], [200, 10]] as const) {
      const r = fitDish(d, kc, p, { deficit: false })
      const minK = kcalOf(d.items.map(([key, q]) => ({ key: key as string, qty: qtyOf(key as string, q, 0.3) })))   // najmanjša jed (×0,3; kos ne pod 1)
      expect(r.kcal, `${d.id} ${kc}/${p}`).toBeLessThanOrEqual(Math.max(kc * 1.15 + 5, minK * 1.2 + 10))
      expect(r.ingredients.every(i => i.qty > 0)).toBe(true)
    }
  })
  it('jed pomerjena na obrok: kalorije blizu, beljakovine vsaj 90 % (beljakovinska sestavina gor, ogljikohidratna dol), pri primanjkljaju manj olja', () => {
    const d = DISHES.find(x => x.id === 'pisc-riz')!
    const r = fitDish(d, 700, 50, { deficit: false })
    expect(Math.abs(r.kcal - 700)).toBeLessThan(90)
    expect(r.p).toBeGreaterThanOrEqual(45)
    expect(Math.abs(kcalOf(r.ingredients) - r.kcal)).toBeLessThan(2)
    const hi = fitDish(d, 600, 70, { deficit: true })
    // realne porcije (16. 10.): piščanca največ 220 g na obrok — 70 g beljakovin v 600 kcal ni realno, ~60 je
    expect(hi.p).toBeGreaterThanOrEqual(55)
    expect(hi.ingredients.find(i => i.key === 'piscanec')!.qty).toBeLessThanOrEqual(220)
    expect(hi.ingredients.find(i => i.key === 'olje')!.qty).toBe(5)
    expect(hi.ingredients.find(i => i.key === 'piscanec')!.qty).toBeGreaterThan(r.ingredients.find(i => i.key === 'piscanec')!.qty * 0.9)
    expect(Math.abs(hi.kcal - 600)).toBeLessThan(120)
  })
  it('dan: vsak obrok dobi recept, dnevi se razlikujejo, »drug predlog« da drugo jed, besedilo zakaj iz številk', () => {
    const dp = dayMealPlan({ weightKg: 84, trainTime: 'popoldne' }, { kcal: 2400, proteinG: 160, carbsG: 280 }, null)
    const a = dayRecipes(dp, '2026-10-12', { deficit: true, keepMuscle: true, training: true })
    const b = dayRecipes(dp, '2026-10-13', { deficit: true, keepMuscle: true, training: true })
    expect(Object.keys(a)).toEqual(dp.slots.map(s => s.key))
    expect(Object.values(a).some((r, i) => r.dish !== Object.values(b)[i]!.dish)).toBe(true)
    const alt = dayRecipes(dp, '2026-10-12', { deficit: true, keepMuscle: true, training: true, alt: { kosilo: 1 } })
    expect(alt.kosilo!.dish).not.toBe(a.kosilo!.dish)
    for (const [k, r] of Object.entries(a)) { const sl = dp.slots.find(s => s.key === k)!; expect(Math.abs(r.kcal - sl.kcal), k).toBeLessThan(sl.kcal * 0.25 + 60); expect(r.steps.length).toBeGreaterThan(0); expect(r.why).toMatch(/beljakovin/) }
    expect(whyRecipe({ p: 40, c: 60, f: 10 }, { key: 'obnova', proteinG: 40 }, { deficit: false, keepMuscle: false, training: true })).toContain('obnovo po vadbi')
    const vege = dayRecipes(dp, '2026-10-12', { deficit: false, keepMuscle: false, training: false, prefs: 'vegetarijanec' })
    expect(Object.values(vege).every(r => !/piščan|tun|puran|losos/i.test(r.name))).toBe(true)
  })
})

describe('realne porcije in domače mere (16. 10.: »za jest naj bo realno … ne na hojladri«)', () => {
  it('velik obrok: nobena sestavina čez mero, manjko doda dodatek (kruh, banana, jogurt)', async () => {
    const { PORTION_MAX } = await import('@/domain/nutrition/recipes')
    const d = DISHES.find(x => x.id === 'skuta-z')!
    const r = fitDish(d, 800, 45, { deficit: false }, 90)
    for (const i of r.ingredients.filter(i => !i.side)) expect(i.qty, i.key).toBeLessThanOrEqual(PORTION_MAX[i.key] ?? Infinity)
    expect(r.ingredients.find(i => i.key === 'skuta')!.qty).toBeLessThanOrEqual(250)
    expect(r.ingredients.some(i => i.side)).toBe(true)
    expect(Math.abs(r.kcal - 800)).toBeLessThan(160)
    expect(r.steps.some(s => /^Zraven še: /.test(s))).toBe(false)   // dodatek je med sestavinami, ne kot korak
  })
  it('dodatek upošteva želje (brez glutena → ne kruh, brez laktoze → ne jogurt)', () => {
    const d = DISHES.find(x => x.id === 'pisc-riz')!
    const r = fitDish(d, 1100, 50, { deficit: false, prefs: 'brez glutena' }, 140)
    expect(r.ingredients.filter(i => i.side).every(i => i.key !== 'kruh')).toBe(true)
  })
  it('pred vožnjo ni stročnic in težke hrane; shake ni večerja', async () => {
    const { dayMealPlan } = await import('@/domain/nutrition/dayplan')
    const dp = dayMealPlan({ weightKg: 84, trainTime: 'popoldne' }, { kcal: 3300, proteinG: 168, carbsG: 410 }, { kind: 'kolo', durationMin: 150, zone: 'Z2', title: 'Kolo' } as never)
    const pre = dp.slots.find(s => s.beforeRide)!
    expect(pre).toBeTruthy()
    for (let day = 0; day < 20; day++) {
      const r = dayRecipes(dp, `2026-10-${String(1 + day).padStart(2, '0')}`, { deficit: true, keepMuscle: true, training: true })
      expect(r[pre.key]!.ingredients.some(i => i.key === 'fizol' || i.key === 'leca'), r[pre.key]!.name).toBe(false)
      for (const sl of dp.slots.filter(s => s.kcal > 600)) expect(r[sl.key]!.dish, sl.label).not.toBe('shake')
    }
  })
  it('raznolikost: ista osnova (riž, piščanec …) ne dvakrat v istem dnevu, če je druga jed', async () => {
    const { basesOf } = await import('@/domain/nutrition/recipes')
    const { dayMealPlan } = await import('@/domain/nutrition/dayplan')
    // Blažev dan (17. 10.): dolga vožnja, 3658 kcal — prej kosilo »Tofu z rižem« in po vožnji »Riž s piščancem«
    const dp = dayMealPlan({ weightKg: 84, trainTime: 'popoldne' }, { kcal: 3658, proteinG: 168, carbsG: 517 }, { kind: 'kolo', durationMin: 150, zone: 'Z2', title: 'Kolo', role: 'dolga' } as never)
    let repeats = 0
    for (let day = 1; day <= 30; day++) {
      const r = dayRecipes(dp, `2026-10-${String(day).padStart(2, '0')}`, { deficit: true, keepMuscle: true, training: true })
      const seen = new Set<string>()
      let dup = false
      for (const x of Object.values(r)) { const b = basesOf(DISHES.find(d => d.id === x.dish) || { items: [] }); for (const v of [b.carb, b.prot]) { if (v && seen.has(v)) dup = true; if (v) seen.add(v) } }
      if (dup) repeats++
    }
    expect(repeats).toBe(0)
    expect(basesOf({ items: [['riz', 100], ['piscanec', 150], ['zelenjava', 150]] })).toEqual({ carb: 'riz', prot: 'piscanec' })
  })
  it('domače mere: rezine kruha, žlice kosmičev, lonček skute, kuhan riž', async () => {
    const { qtyText } = await import('@/domain/nutrition/dayplan')
    expect(qtyText('kruh', 80)).toBe('polnozrnat kruh 80 g (2 rezini)')
    expect(qtyText('oves', 70)).toBe('ovseni kosmiči 70 g (≈ 7 žlic)')
    expect(qtyText('skuta', 250)).toBe('skuta 250 g (1 lonček)')
    expect(qtyText('riz', 100)).toBe('riž (suh) 100 g (kuhanega ≈ 260 g)')
    expect(qtyText('zelenjava', 200)).toBe('zelenjava 200 g')
  })
})
