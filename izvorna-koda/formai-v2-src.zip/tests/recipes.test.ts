import { describe, it, expect } from 'vitest'
import { DISHES, dishesFor, exclusionsOf, dishOk, fitDish, dayRecipes, whyRecipe } from '../src/domain/nutrition/recipes'
import { dayMealPlan, F, TPL, qtyOf } from '../src/domain/nutrition/dayplan'

const kcalOf = (items: { key: string; qty: number }[]) => items.reduce((a, i) => a + (F[i.key]!.kcal * i.qty) / F[i.key]!.per, 0)

describe('recepti', () => {
  it('knjižnica: vsaka predloga ima vsaj 2 jedi, vse sestavine obstajajo, koraki in minute', () => {
    for (const tpl of Object.keys(TPL)) expect(DISHES.filter(d => d.tpl === tpl).length, tpl).toBeGreaterThanOrEqual(2)
    for (const d of DISHES) { expect(d.steps.length).toBeGreaterThan(0); expect(d.minutes).toBeGreaterThan(0); for (const [k] of d.items) expect(F[k], `${d.id}: ${String(k)}`).toBeTruthy() }
    expect(new Set(DISHES.map(d => d.id)).size).toBe(DISHES.length)
  })
  it('želje: vegetarijansko, brez laktoze, ne maram rib — jedi s tem izpadejo; če nič ne ostane, vse', () => {
    expect(exclusionsOf('vegetarijanec sem').contains).toEqual(['meso', 'riba'])
    expect(exclusionsOf('brez laktoze, ne maram rib').contains).toEqual(expect.arrayContaining(['mleko', 'riba']))
    expect(exclusionsOf('ne maram brokolija').words).toEqual(['brokolija'])
    expect(dishesFor('kosilo', 'vegetarijanec').every(d => !d.contains.includes('meso') && !d.contains.includes('riba'))).toBe(true)
    expect(dishesFor('kosilo', 'vegan').map(d => d.id)).toEqual(['cicerika', 'tofu-riz'])
    expect(dishOk(DISHES.find(d => d.id === 'pisc-riz')!, exclusionsOf('ne maram piščanca'))).toBe(false)
    expect(dishesFor('pred', 'vegan, brez glutena').map(d => d.id)).toEqual(['sadje-pred'])   // za vsak obrok vsaj ena veganska jed brez glutena
    for (const tpl of Object.keys(TPL)) expect(dishesFor(tpl, 'vegan, brez glutena').length, tpl).toBeGreaterThan(0)
    expect(dishesFor('kosilo', 'ne maram riža, krompirja, testenin, piščanca, tune, čičerike, tofuja, purana, lososa').length, 'besede popustijo, ko izločijo vse').toBeGreaterThan(0)
    expect(exclusionsOf('nisem vegetarijanec, rad imam ribe').contains).toEqual([])
    expect(exclusionsOf('ne maram rib, piščanca, brokolija').contains).toEqual(expect.arrayContaining(['riba', 'meso']))
    expect(exclusionsOf('ne maram rib, piščanca, brokolija').words).toEqual(['brokolija'])
    expect(exclusionsOf('alergija na oreške, brez laktoze').contains).toEqual(expect.arrayContaining(['oreski', 'mleko']))
  })
  it('beljakovinski dodatek ne napihne kalorij: fižol v humusu za malico 290 kcal / 40 g ostane pod +15 %', () => {
    const h = fitDish(DISHES.find(x => x.id === 'humus-m')!, 290, 40, { deficit: true })
    expect(h.kcal).toBeLessThanOrEqual(290 * 1.15 + 5)
    const j = fitDish(DISHES.find(x => x.id === 'jogurt-m')!, 290, 40, { deficit: true })
    expect(j.kcal).toBeLessThanOrEqual(290 * 1.15 + 5)
    for (const d of DISHES) for (const [kc, p] of [[290, 40], [600, 50], [900, 30], [200, 10]] as const) {
      const r = fitDish(d, kc, p, { deficit: false })
      const minK = kcalOf(d.items.map(([key, q]) => ({ key: key as string, qty: qtyOf(key as string, q, 0.3) })))   // najmanjša jed (×0,3; kos ne pod 1)
      expect(r.kcal, `${d.id} ${kc}/${p}`).toBeLessThanOrEqual(Math.max(kc * 1.15 + 5, minK * 1.2 + 10))
      expect(r.ingredients.every(i => i.qty > 0)).toBe(true)
    }
  })
  it('jed pomerjena na obrok: kalorije blizu, beljakovine vsaj 90 % (beljakovinska sestavina gor, ogljikohidratna dol), pri primanjkljaju manj olja', () => {
    const d = DISHES.find(x => x.id === 'pisc-riz')!
    const r = fitDish(d, 700, 50, { deficit: false })
    expect(Math.abs(r.kcal - 700)).toBeLessThan(90)
    expect(r.p).toBeGreaterThanOrEqual(45)
    expect(Math.abs(kcalOf(r.ingredients) - r.kcal)).toBeLessThan(2)
    const hi = fitDish(d, 600, 70, { deficit: true })
    expect(hi.p).toBeGreaterThanOrEqual(60)
    expect(hi.ingredients.find(i => i.key === 'olje')!.qty).toBe(5)
    expect(hi.ingredients.find(i => i.key === 'piscanec')!.qty).toBeGreaterThan(r.ingredients.find(i => i.key === 'piscanec')!.qty * 0.9)
    expect(Math.abs(hi.kcal - 600)).toBeLessThan(120)
  })
  it('dan: vsak obrok dobi recept, dnevi se razlikujejo, »drug predlog« da drugo jed, besedilo zakaj iz številk', () => {
    const dp = dayMealPlan({ weightKg: 84, trainTime: 'popoldne' }, { kcal: 2400, proteinG: 160, carbsG: 280 }, null)
    const a = dayRecipes(dp, '2026-10-12', { deficit: true, keepMuscle: true, training: true })
    const b = dayRecipes(dp, '2026-10-13', { deficit: true, keepMuscle: true, training: true })
    expect(Object.keys(a)).toEqual(dp.slots.map(s => s.key))
    expect(Object.values(a).some((r, i) => r.dish !== Object.values(b)[i]!.dish)).toBe(true)
    const alt = dayRecipes(dp, '2026-10-12', { deficit: true, keepMuscle: true, training: true, alt: { kosilo: 1 } })
    expect(alt.kosilo!.dish).not.toBe(a.kosilo!.dish)
    for (const [k, r] of Object.entries(a)) { const sl = dp.slots.find(s => s.key === k)!; expect(Math.abs(r.kcal - sl.kcal), k).toBeLessThan(sl.kcal * 0.25 + 60); expect(r.steps.length).toBeGreaterThan(0); expect(r.why).toMatch(/beljakovin/) }
    expect(whyRecipe({ p: 40, c: 60, f: 10 }, { key: 'obnova', proteinG: 40 }, { deficit: false, keepMuscle: false, training: true })).toContain('obnovo po vadbi')
    const vege = dayRecipes(dp, '2026-10-12', { deficit: false, keepMuscle: false, training: false, prefs: 'vegetarijanec' })
    expect(Object.values(vege).every(r => !/piščan|tun|puran|losos/i.test(r.name))).toBe(true)
  })
})
