import 'fake-indexeddb/auto'
import { describe, it, expect, vi } from 'vitest'

const h = vi.hoisted(() => ({ json: {} as unknown, prompts: [] as string[] }))
vi.mock('../src/domain/ai/client', () => {
  class AiError extends Error { kind: string; constructor(kind: string, m: string) { super(m); this.kind = kind } }
  return {
    AiError,
    askText: async () => '',
    askJson: async (parts: { text?: string }[]) => { h.prompts.push(parts.map(p => p.text || '').join('\n')); return JSON.parse(JSON.stringify(h.json)) },
  }
})

import { mealFromText } from '../src/domain/ai/actions'
import type { Profile } from '../src/domain/types'

const NOW = new Date().toISOString()
const p: Profile = { sex: 'm', age: 21, weightKg: 78, heightCm: 180, ftp: 240, deficit: 0, gear: { bikeOutdoor: true, trainer: false, noBike: false }, strength: { on: false, equipment: 'none' }, aiConsentAt: NOW, onboardingDone: true, createdAt: NOW, updatedAt: NOW }
const at = (hh: number, mm = 0) => { const d = new Date(); d.setHours(hh, mm, 0, 0); return d }

describe('obrok iz opisa (besedilo ali glas)', () => {
  it('vsote iz postavk (ne iz modelove vsote), obrok iz opisa, opis in pravila v pozivu', async () => {
    h.json = {
      jed: 'Kruh s pašteto in bela kava',
      postavke: [
        { ime: 'kruh, polnozrnat', kolicina: '2 kosa (~80 g)', grami: 80, kcal: 190, beljakovine_g: 8, ogljikovi_hidrati_g: 34, mascobe_g: 2 },
        { ime: 'pašteta', kolicina: '30 g', grami: 30, kcal: 90, beljakovine_g: 3, ogljikovi_hidrati_g: 1, mascobe_g: 8 },
        { ime: 'kava z mlekom', kolicina: '200 ml', grami: 200, kcal: 60, beljakovine_g: 3, ogljikovi_hidrati_g: 5, mascobe_g: 3 },
      ],
      kcal: 999, beljakovine_g: 99, obrok: 'zajtrk', ura: '07:30', zanesljivost: 'srednja', vprasanje: null,
    }
    const m = await mealFromText(p, 'dva kosa kruha s pašteto in bela kava', 2000, 120, at(9, 15))
    expect(m.kcal).toBe(340)
    expect(m.proteinG).toBe(14)
    expect(m.carbsG).toBe(40)
    expect(m.fatG).toBe(13)
    expect(m.grams).toBe(310)
    expect(m.slot).toBe('zajtrk')
    expect(m.time).toBe('07:30')
    expect(m.source).toBe('text')
    expect(m.items).toHaveLength(3)
    expect(m.items![0]).toEqual({ name: 'kruh, polnozrnat', qty: '2 kosa (~80 g)', kcal: 190 })
    const prompt = h.prompts[h.prompts.length - 1]!
    expect(prompt).toContain('dva kosa kruha s pašteto in bela kava')
    expect(prompt).toContain('PRAVILA PREHRANE')
    expect(prompt).toContain('ostane 2000 kcal')
  })
  it('ura v prihodnosti in neveljaven obrok → zdaj in obrok po uri; negativne vrednosti se ne štejejo', async () => {
    h.json = { jed: 'Banana', postavke: [{ ime: 'banana', kcal: 105, beljakovine_g: -3, ogljikovi_hidrati_g: 27 }], obrok: 'med_vadbo', ura: '23:59', zanesljivost: '??', vprasanje: 'Kako velika?' }
    const m = await mealFromText(p, 'banana', null, null, at(10, 5))
    expect(m.time).toBe('10:05')
    expect(m.slot).toBe('malica')
    expect(m.kcal).toBe(105)
    expect(m.proteinG).toBe(null)
    expect(m.confidence).toBe('srednja')
    expect(m.question).toBe('Kako velika?')
  })
  it('brez privolitve ali brez opisa → napaka, brez klica AI', async () => {
    const n = h.prompts.length
    await expect(mealFromText({ ...p, aiConsentAt: null }, 'kruh', null, null)).rejects.toThrow()
    await expect(mealFromText(p, ' ', null, null)).rejects.toThrow()
    expect(h.prompts.length).toBe(n)
  })
})
