import { describe, it, expect } from 'vitest'
import { dayLabel, adaptText } from '../src/domain/ai/coachchat'
import { addToChat } from '../src/domain/ai/actions'
import { FUEL_ITEMS } from '../src/domain/nutrition/dayplan'
import type { PlanDay } from '../src/domain/types'

const day = (date: string, title: string, durationMin: number, kind: PlanDay['kind'] = 'kolo'): PlanDay => ({ id: date + kind, date, kind, title, desc: '', durationMin, zone: 'Z2', source: 'rules', createdAt: '', updatedAt: '', done: null } as unknown as PlanDay)

describe('pogovor s trenerjem', () => {
  it('ločilnik dneva: danes, včeraj, datum', () => {
    expect(dayLabel(new Date(2026, 8, 24, 10, 0).toISOString(), '2026-09-24')).toBe('danes')
    expect(dayLabel(new Date(2026, 8, 23, 22, 0).toISOString(), '2026-09-24')).toBe('včeraj')
    expect(dayLabel(new Date(2026, 8, 20, 8, 0).toISOString(), '2026-09-24')).toBe('20. 9.')
  })
  it('prilagoditev tedna: povzetek + samo spremenjeni dnevi, moč izpuščena', () => {
    const before = [day('2026-09-24', 'Sweet spot 3 × 12', 90), day('2026-09-26', 'Dolga Z2', 180), day('2026-09-26', 'Moč noge', 30, 'moc')]
    const after = [day('2026-09-24', 'Sweet spot 3 × 12', 90), day('2026-09-26', 'Dolga Z2', 150), day('2026-09-26', 'Moč noge', 30, 'moc')]
    const t = adaptText('Krajša sobota zaradi utrujenosti.', before, after)
    expect(t).toBe('Krajša sobota zaradi utrujenosti.\n\nSpremenjeno:\n– sob 26. 9.: Dolga Z2 · 2 h 30 min')
    expect(adaptText('Brez sprememb.', before, before)).toMatch(/Dnevi ostanejo/)
  })
  it('nasvet in pregled gresta v isti pogovor z oznako', async () => {
    const m = await addToChat({ msgs: [{ role: 'user', text: 'a', at: '2026-09-24T08:00:00Z' }], summary: null }, [{ role: 'user', text: 'Kaj naj danes naredim?', at: '2026-09-24T09:00:00Z' }, { role: 'ai', text: 'Z2 90 min.', at: '2026-09-24T09:00:05Z', kind: 'advice' }])
    expect(m.msgs).toHaveLength(3); expect(m.msgs[2]!.kind).toBe('advice'); expect(m.summary).toBeNull()
  })
  it('izbira goriva ima kratka imena v imenovalniku', () => {
    for (const it of FUEL_ITEMS) { expect(it.label).not.toMatch(/^bidon|ega\b|nov\b/); expect(it.label.length).toBeLessThan(22) }
    expect(FUEL_ITEMS.map(i => i.label)).toContain('domači izotonik')
  })
})
