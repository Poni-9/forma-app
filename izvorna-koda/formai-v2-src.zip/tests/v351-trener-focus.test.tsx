// v3.51 TRENER-FOCUS (zaslon Trener): premor ob Stravi (C01, C02), konec premora (C23), bolezen (B14), brez povezave (C28),
// hitra vprašanja ob premoru (C34), kamera namesto 4. čipa samo odraslim (C35, C36)
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>() }))
const h = vi.hoisted(() => ({ run: vi.fn(async (fn: () => Promise<unknown>) => fn()), setWeekPause: vi.fn(async () => ({})), endWeekPause: vi.fn(async () => {}), chat: vi.fn() }))
vi.mock('@/state/store', () => ({
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  savePlanDays: vi.fn(), savePlanDay: vi.fn(), saveCheckin: vi.fn(), updateSettings: vi.fn(async () => {}), toast: vi.fn(), newCoachChat: vi.fn(), restorePlanDays: vi.fn(),
  setPlanDone: vi.fn(), addCore: vi.fn(), setWeekPause: h.setWeekPause, endWeekPause: h.endWeekPause, setSick: vi.fn(), endSick: vi.fn(), extendSick: vi.fn(),
}))
vi.mock('@/app/router', () => ({ navigate: vi.fn(), useRoute: () => ({ name: 'trener', params: {} }) }))
vi.mock('@/app/Shell', () => ({ Head: () => null }))
vi.mock('@/ui/useAi', () => ({ useAi: () => ({ busy: false, signedIn: true, consent: true, run: h.run, sheet: null }) }))
vi.mock('@/state/snap', () => ({ snapOf: () => ({}) }))
vi.mock('@/data/db', () => ({ getKV: async () => undefined, setKV: async () => {} }))
vi.mock('@/ui/useDictation', () => ({ useDictation: () => ({ listening: false, canSpeak: true, toggle: () => {}, stop: () => {}, transcribing: false, level: 0 }) }))
vi.mock('@/ui/ListenBar', () => ({ ListenBar: () => null }))
vi.mock('@/ui/Confirm', () => ({ undoToast: vi.fn(), useHidden: () => new Set() }))
vi.mock('@/domain/ai/actions', async orig => { const m = await orig<typeof import('@/domain/ai/actions')>(); return { ...m, chat: h.chat } })

import { Trener, OFFLINE_ASK } from '@/screens/Trener'
import type { Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

const T = '2026-10-23'
const NOW = '2026-10-23T08:00:00.000Z'
const base = { sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, strength: { on: false, equipment: 'none' }, onboardingDone: true, createdAt: NOW, updatedAt: NOW } as unknown as Profile
const strava = { id: 's1', source: 'strava_api', sport: 'kolo', date: '2026-10-20', durationMin: 60, aiEligible: false, createdAt: NOW, updatedAt: NOW }
const reset = (msgs: any[], p: Partial<Profile> = {}, activities: any[] = []) => {
  S.state = { ready: true, today: T, plan: [], activities, checkins: [], recentMeals: [], weather: null, wellness: [], settings: { coach: { msgs, summary: null } }, user: { uid: 'u' }, authKnown: true, firstSync: true, profile: { ...base, ...p } }
  S.subs.forEach(f => f())
}
const pair = (q: string, a: string) => [{ role: 'user' as const, text: q, at: NOW }, { role: 'ai' as const, text: a, at: NOW }]

let div: HTMLDivElement, root: Root | null = null
async function mount() { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div); await act(async () => { root!.render(<Trener />) }) }
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(b.textContent || '') || re.test(b.getAttribute('aria-label') || '')) as HTMLButtonElement | undefined
const text = () => document.body.textContent || ''

beforeEach(() => { h.setWeekPause.mockClear(); h.endWeekPause.mockClear(); h.chat.mockReset(); window.scrollTo = vi.fn() as never; location.hash = '#/trener' })
afterEach(async () => { if (root) { await act(async () => root!.unmount()); root = null; div.remove() } document.body.innerHTML = ''; Object.defineProperty(navigator, 'onLine', { value: true, configurable: true }) })

describe('premor ob skritih vadbah (C01, C02)', () => {
  it('varovalka pobriše odgovor o premoru → pod njim vrstica aplikacije in gumb', async () => {
    reset(pair('Ta teden nočem nič.', 'Razumem. Premor uveljaviš z gumbom spodaj. Ta teden brez treningov je v redu.'), {}, [strava])
    await mount()
    expect(text()).toContain('Ta teden počiješ — tapni spodaj, da načrt to upošteva.')
    expect(btn(/^Uveljavi: ta teden brez treningov$/)).toBeTruthy()
  })
  it('brez skritih vadb ni dodatne vrstice', async () => {
    reset(pair('Ta teden nočem nič.', 'Razumem. Premor uveljaviš z gumbom spodaj.'))
    await mount()
    expect(text()).not.toContain('Ta teden počiješ')
  })
  it('odgovor iz načrta (brez AI) obdrži vrstico o premoru tudi s Stravo', async () => {
    reset([{ role: 'user', text: 'Pregled tedna', at: NOW, local: true }, { role: 'ai', text: 'Ta teden: premor do nedelje (brez kolesa) — po tvoji izbiri; izpuščeni treningi ne štejejo kot zaostanek.', at: NOW, kind: 'review', local: true }], {}, [strava])
    await mount()
    expect(text()).toContain('Ta teden: premor do nedelje (brez kolesa)')
  })
})

describe('konec premora, bolezen in hitra vprašanja (C23, B14, C34)', () => {
  const pz = { weekPause: { mode: 'vse', from: '2026-10-19', to: '2026-10-25', reason: null, at: NOW } } as Partial<Profile>
  it('»prekliči premor« ob veljavnem premoru → gumb »Prekliči premor«', async () => {
    reset(pair('Prekliči premor, vseeno bom treniral.', 'Prav, premor prekličeš z gumbom.'), pz)
    await mount()
    const b = btn(/^Prekliči premor$/)
    expect(b).toBeTruthy()
    await act(async () => { b!.click() })
    expect(h.endWeekPause).toHaveBeenCalled()
  })
  it('brez premora ni gumba »Prekliči premor«', async () => {
    reset(pair('Prekliči premor.', 'Premora nimaš.'))
    await mount()
    expect(btn(/^Prekliči premor$/)).toBeUndefined()
  })
  it('»ta teden sem bolan« → »Bolan sem« (ne premor)', async () => {
    reset(pair('Ta teden sem bolan.', 'Počivaj in pij veliko tekočine.'))
    await mount()
    expect(btn(/^Bolan sem$/)).toBeTruthy()
    expect(btn(/^Uveljavi:/)).toBeUndefined()
  })
  it('ob veljavnem premoru hitra vprašanja brez VO2max', async () => {
    reset(pair('Kaj jem?', 'Jej normalno.'), pz)
    await mount()
    expect(text()).not.toContain('Kako izpeljem VO2max intervale?')
    expect(text()).toContain('Kaj jem v tednu brez treninga?')
  })
})

describe('brez povezave in kamera (C28, C35, C36)', () => {
  it('brez povezave vprašanje ostane takoj, brez klica AI', async () => {
    reset([])
    Object.defineProperty(navigator, 'onLine', { value: false, configurable: true })
    await mount()
    const input = document.querySelector('input.field') as HTMLInputElement
    await act(async () => {
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(input, 'Kaj danes?')
      input.dispatchEvent(new Event('input', { bubbles: true }))
    })
    await act(async () => { (document.querySelector('form') as HTMLFormElement).requestSubmit() })
    expect(h.chat).not.toHaveBeenCalled()
    expect(text()).toContain(OFFLINE_ASK)
  })
  it('kamera v polju odraslemu, mladoletnemu ne; ni 4. čipa', async () => {
    reset([])
    await mount()
    expect(btn(/Predlog vaj s slike sebe/)).toBeTruthy()
    expect([...document.querySelectorAll('.quick .chip')].map(c => c.textContent)).not.toContain('Predlog s slike')
    await act(async () => root!.unmount()); root = null; div.remove()
    reset([], { age: 16 } as Partial<Profile>)
    await mount()
    expect(btn(/Predlog vaj s slike sebe/)).toBeUndefined()
  })
})
