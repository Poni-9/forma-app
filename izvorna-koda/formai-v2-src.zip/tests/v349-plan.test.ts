import { describe, it, expect } from 'vitest'
import { buildWeek, weekContext, planHours, FRANJA_2027 } from '../src/domain/training/planner'
import { buildFocusWeek, focusWeekContext } from '../src/domain/training/focusPlan'
import { stepsFor, type Step } from '../src/domain/training/workout'
import { addDays } from '../src/domain/training/load'
import { ruleProposal } from '../src/domain/focus/rules'
import { coachReview } from '../src/domain/focus/coach'
import { profileFromFocus, normalizeFocus } from '../src/domain/focus/model'
import type { Activity, Focus, PlanDay, Profile } from '../src/domain/types'

/* v3.49 PLAN: kakovost načrta — tekač začetnik (tek in hoja, napredovanje), moč v taperingu in pred dolgo vožnjo, pavze pri
   težkih počepih, razmik testov in prvi teden po lahkem začetku, po premoru brez intervalov, po tekmi A en teden, začetnica
   brez cilja (8 tednov osnove), začetek ob koncu tedna, načrt ne raste brez vadbe. */

const now = '2026-10-01T08:00:00.000Z'
const blank = { name: 'X', sex: 'm', age: 30, heightCm: 180, weightKg: 80, restHr: null, maxHr: null, lthr: null, ftp: null, ftpDate: null, goal: 'forma', gear: { bikeOutdoor: false, trainer: false, noBike: true, powerMeter: null }, hoursPerWeek: 4, hoursMode: 'own', strength: { on: false, equipment: 'none' }, strengthDays: 0, deficit: 0, neat: 1.4, proteinGkg: 1.6, event: null, races: [], level: 1, onboardingDone: true, createdAt: now, updatedAt: now } as unknown as Profile
const WED = '2026-10-14'                                   // sreda: načrt se začne ta ponedeljek (12. 10.)
const persona = (wish: string, qa: { id: string; q: string; a: string }[], base: Profile, today = WED): Profile => {
  const f = coachReview(ruleProposal(wish, qa, base.age).focus, { age: base.age }).focus
  return { ...base, ...profileFromFocus(f, base, addDays(today, -((new Date(today + 'T12:00:00Z').getUTCDay() + 6) % 7)), today) } as Profile
}
const qa3 = [{ id: 'dni', q: 'Koliko dni na teden?', a: '3' }, { id: 'cas', q: 'Koliko časa imaš za eno vadbo?', a: '30 min' }]
// tedni so prihodnost (danes = začetek), zato vsi štejejo, kot da bodo opravljeni
const wk = (p: Profile, k: number, today = WED, o: Partial<Parameters<typeof buildWeek>[0]> = {}) => { const w = addDays(p.cycleStart!, 7 * k); return buildWeek({ profile: p, activities: [], weekStart: w, notBefore: w, today, ...o }) }
const runs = (w: PlanDay[]) => w.filter(d => d.kind === 'tek')
const runSec = (s: Step[]) => s.filter(x => x.kind === 'delo').reduce((t, x) => t + x.sec, 0)
const longestRun = (s: Step[]) => Math.max(0, ...s.filter(x => x.kind === 'delo').map(x => x.sec))

describe('A06 + C14: tekač začetnik — tek in hoja, vsak teden več teka', () => {
  const p = persona('Cilj: kondicija. Rad delam: tek. Izkušnje: začenjam.', qa3, blank)
  it('tekač začetnik: 1. in 5. teden nista enaka; 9. teden ima več minut teka kot 1. teden', () => {
    const w1 = runs(wk(p, 0)), w5 = runs(wk(p, 4)), w9 = runs(wk(p, 8))
    expect(w1.length).toBeGreaterThan(0)
    expect(w1[0]!.title).not.toBe(w5[0]!.title)
    expect(runSec(stepsFor(w9[0]!, p))).toBeGreaterThan(runSec(stepsFor(w1[0]!, p)))
  })
  it('vodena vadba 1. tedna ima korake teka in hoje (hoja ni samo v opisu)', () => {
    const d = runs(wk(p, 0))[0]!
    expect(d.title).toMatch(/^Tek in hoja/)
    const st = stepsFor(d, p)
    expect(st.some(s => s.label === 'Hoja')).toBe(true)
    expect(st.filter(s => s.kind === 'delo').every(s => s.label.startsWith('Tek') && s.z === 'Z2')).toBe(true)
    // trajanje korakov = načrtovano trajanje
    expect(st.reduce((t, s) => t + s.sec, 0)).toBe(d.durationMin * 60)
  })
  it('kdor še ne teče (»Tek: začenjam s tekom«): 1. teden 1 min teka in 1 min 30 s hoje, v 4. tednu daljši deli; cilj 5 km je ime načrta', () => {
    const t = persona('Cilj: boljša kondicija, manj kilogramov. Rad delam: tek. Izkušnje: začenjam. Tek: začenjam s tekom. Rad bi pretekel 5 km brez ustavljanja. Nimam ure, samo telefon.', qa3, { ...blank, age: 38, weightKg: 92 } as Profile)
    expect(t.focus!.title).toBe('Do 5 km brez ustavljanja')
    const d1 = runs(wk(t, 0))[0]!, d4 = runs(wk(t, 3))[0]!
    expect(d1.title).toMatch(/hoja/)
    expect(d1.desc).toMatch(/\(1 min tek \/ 1 min 30 s hoja\)/)
    expect(longestRun(stepsFor(d4, t))).toBeGreaterThan(longestRun(stepsFor(d1, t)))
  })
  it('kdor že teče (»Tek: tečem do 10 km«): navaden lahek tek brez hoje', () => {
    const r = persona('Cilj: kondicija. Rad delam: tek. Izkušnje: občasno. Tek: tečem do 10 km.', qa3, blank)
    expect(runs(wk(r, 0)).every(d => !/hoja/i.test(d.title))).toBe(true)
  })
  it('zamujen teden (znano, da ni bilo vadbe) ne premakne stopnje naprej; »Opravil« brez ure jo premakne', () => {
    const w3 = (o: Partial<Parameters<typeof buildWeek>[0]>) => runs(wk(p, 2, addDays(p.cycleStart!, 14), o))[0]!.title
    const idle = w3({}), done = w3({ done: [{ date: addDays(p.cycleStart!, 2), kind: 'tek' }] })
    expect(idle).not.toBe(done)
    expect(done).toBe(runs(wk(p, 2))[0]!.title)
  })
})

describe('A31: hujšanje pri 95 kg — tek in hoja namesto 50 min neprekinjenega teka', () => {
  it('prvi teden: tek in hoja, teka največ ~15 min na vadbo, ostanek hitra hoja', () => {
    const g = persona('Cilj: manj kilogramov, mišice. Rad delam: fitnes, tek. Izkušnje: nekaj.', [{ id: 'dni', q: 'Koliko dni na teden?', a: '4' }, { id: 'cas', q: 'Koliko časa imaš za eno vadbo?', a: '60 min' }, { id: 'izkusnje', q: 'Izkušnje', a: 'nekaj izkušenj' }], { ...blank, weightKg: 95, age: 34 } as Profile)
    const r = runs(wk(g, 0))
    expect(r.length).toBeGreaterThan(0)
    for (const d of r) {
      expect(d.desc).toMatch(/hoja/)
      expect(runSec(stepsFor(d, g))).toBeLessThanOrEqual(15 * 60)
      expect(stepsFor(d, g).some(s => s.label === 'Hitra hoja')).toBe(true)
      // poraba za prehrano: hoja ni tek (prej bi se 50 min štelo kot 50 min teka, ~750 kcal)
      expect(d.kcalBurn!).toBeGreaterThan(0)
      expect(d.kcalBurn!).toBeLessThan(Math.round((9.5 * 95 * d.durationMin) / 60) * 0.75)
    }
  })
})

/* ---------- kolesar ---------- */
const P = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 30, heightCm: 180, weightKg: 75, ftp: 250, ftpDate: '2026-10-01', maxHr: 190, restHr: 50, lthr: 172,
  gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: true }, strength: { on: true, equipment: 'home' }, strengthDays: 2,
  hoursPerWeek: 10, baseHours: null, onboardingDone: true, createdAt: now, updatedAt: now, event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', level: 3, ...o,
} as Profile)
const T = '2026-10-17'
const bw = (p: Profile, ws: string, acts: Activity[] = [], today = T) => buildWeek({ profile: p, activities: acts, weekStart: ws, notBefore: ws, today })
const gymP = (o: Partial<Profile> = {}) => P({ strength: { on: true, equipment: 'gym' }, level: 4, hoursPerWeek: 14, event: { name: 'Dirka', date: '2027-04-18', distanceKm: 150 }, ...o })

describe('A07: kolesar s fitnesom — v taperingu in razbremenilnem tednu jedro, ne težke noge', () => {
  it('tapering: brez fitnesa — noge (težko)', () => {
    const p = gymP()
    expect(weekContext(p, '2027-04-05').phase).toBe('tapering')
    const m = bw(p, '2027-04-05').filter(d => d.kind === 'moc')
    expect(m.length).toBeGreaterThan(0)
    expect(m.every(d => d.title === 'Moč — jedro')).toBe(true)
  })
  it('razbremenilni teden: jedro', () => {
    const p = gymP()
    const ws = Array.from({ length: 12 }, (_, k) => addDays('2026-10-26', 7 * k)).find(w => weekContext(p, w).recovery && weekContext(p, w).phase !== 'prehod')!
    expect(bw(p, ws).filter(d => d.kind === 'moc').every(d => d.title === 'Moč — jedro')).toBe(true)
  })
})

describe('A08: »Fitnes — noge (težko)« — pavza 2–3 min, kot piše v opisu', () => {
  it('prva pavza pri počepu s palico ≥ 120 s; »Med serijami 2–3 min« = 150 s', () => {
    const p = gymP()
    const d = bw(p, '2026-11-02').concat(bw(p, '2026-11-09')).find(x => x.title === 'Fitnes — noge (težko)')!
    expect(d).toBeTruthy()
    const pauses = stepsFor(d, p).filter(s => s.kind === 'pavza' && s.label === 'Pavza')
    expect(pauses[0]!.sec).toBeGreaterThanOrEqual(120)
    expect(pauses[0]!.sec).toBe(150)
  })
  it('enonožne (»Med serijami 90 s«): hip thrust s palico najmanj 2 min, ostalo 90 s', () => {
    const p = gymP()
    const d = bw(p, '2026-11-02').concat(bw(p, '2026-11-09')).find(x => x.title === 'Fitnes — noge, hrbet, jedro')!
    const st = stepsFor(d, p)
    const after = (name: string) => st[st.findIndex(s => s.label === name) + 1]!
    expect(after('Hip thrust').sec).toBeGreaterThanOrEqual(120)
    expect(after('Stopanje na klop z ročkami').sec).toBe(90)
  })
})

describe('A09: po lahkem začetku ne najtežji teden bloka, test FTP ne dvakrat zapored, 30/15 ne v prvih 6 tednih', () => {
  const starts = ['2026-10-19', '2026-10-26', '2026-11-02', '2026-11-09']
  it('vsi začetki v 4 zaporednih tednih: ni dveh testov v 3 tednih; prvi teden po lahkem začetku ni 2. ali 3. teden bloka', () => {
    for (const s of starts) {
      const p = P({ cycleStart: s, ftpDate: '2026-10-01', hoursPerWeek: 11 })
      const weeks = Array.from({ length: 14 }, (_, k) => weekContext(p, addDays(s, 7 * k)))
      const tests = weeks.map((c, k) => (c.test ? k : -1)).filter(k => k >= 0)
      expect(tests.length).toBeGreaterThan(0)
      for (let i = 1; i < tests.length; i++) expect(tests[i]! - tests[i - 1]!).toBeGreaterThanOrEqual(4)
      const after = weeks[3]!
      expect(after.easy).toBe(0)
      expect(after.recovery || after.blockWeek === 1).toBe(true)
      expect(after.volume).toBeLessThanOrEqual(1)
      // test ni v najtežjem tednu bloka
      for (const c of weeks) if (c.test) expect(c.blockWeek === 3 && !c.recovery).toBe(false)
    }
  })
  it('po off-seasonu (U23, gradnja): 4. teden po lahkem začetku brez 30/15 in brez skoka na 19 h', () => {
    const u = P({ age: 20, ftp: 330, ftpDate: '2026-10-07', hoursPerWeek: 17, level: 4, strength: { on: true, equipment: 'gym' }, event: { name: 'DP U23', date: '2027-06-27', distanceKm: 160, type: 'cestna' }, races: [{ id: 'r1', name: 'VN Kranj', date: '2027-04-18', distanceKm: 150, prio: 'A', type: 'klanci', elevM: 2500 }], cycleStart: '2026-11-02', offSeasonWeeks: 2 })
    const c = weekContext(u, '2026-12-07')
    expect(c.phase).toBe('gradnja'); expect(c.easy).toBe(0)
    expect(c.blockWeek === 3 && !c.recovery).toBe(false)
    const w = bw(u, '2026-12-07')
    expect(w.some(d => d.title.startsWith('30/15'))).toBe(false)
    expect(planHours(u, [], '2026-12-07', T).hours).toBeLessThan(17)
  })
})

describe('A18: po premoru 3+ tednov ta in naslednji teden brez intervalov', () => {
  // treniral je do 19. 9. (3 × na teden), nato nič
  const acts: Activity[] = []
  for (let k = 0; k < 10; k++) for (const d of [1, 3, 5]) acts.push({ id: `p${k}${d}`, source: 'intervals', sport: 'kolo', date: addDays(addDays('2026-07-13', 7 * k), d), name: 'Vožnja', durationMin: 90, tss: 70, aiEligible: true, geoRetain: false } as Activity)
  const p = P({ cycleStart: '2026-08-03', ftpDate: '2026-10-01', hoursPerWeek: 9 })
  it('ta teden in naslednji: nobene cone Z4/Z5, razlaga pove zakaj', () => {
    for (const ws of ['2026-10-12', '2026-10-19']) {
      const w = buildWeek({ profile: p, activities: acts, weekStart: ws, notBefore: ws, today: '2026-10-13' })
      expect(planHours(p, acts, ws, '2026-10-13').base).toBe(0)
      if (weekContext(p, ws).recovery) continue
      expect(w.some(d => d.zone === 'Z4' || d.zone === 'Z5')).toBe(false)
      expect(w.some(d => /brez intervalov/.test(d.why || ''))).toBe(true)
    }
  })
})

describe('A19: moč za noge ne dan pred dolgo vožnjo', () => {
  for (const [name, eq] of [['doma', 'home'], ['fitnes', 'gym']] as const) {
    it(`${name}: dan pred dolgo nima moči za noge (osnova, gradnja, specifično)`, () => {
      const p = P({ strength: { on: true, equipment: eq }, strengthDays: 2, hoursPerWeek: 11 })
      for (const ws of ['2026-11-02', '2026-12-07', '2027-01-25', '2027-04-12', '2027-04-19']) {
        const w = bw(p, ws)
        const long = w.filter(d => d.role === 'dolga').map(d => d.date)
        for (const day of long) expect(w.some(d => d.kind === 'moc' && d.date === addDays(day, -1) && /noge/.test(d.title))).toBe(false)
      }
    })
  }
  it('noge so na trd dan (torek, s ključnim treningom)', () => {
    // (v3.50 B37) bloki po lahkem začetku se štejejo naprej — 2. 11. je zdaj razbremenilni teden (samo jedro); prvi obremenilni teden
    const p = P({ hoursPerWeek: 11 }), ws = ['2026-11-02', '2026-11-09', '2026-11-16'].find(x => !weekContext(p, x).recovery && !weekContext(p, x).test)!
    const w = bw(p, ws)
    const legs = w.find(d => d.kind === 'moc' && /noge/.test(d.title))!
    expect(w.some(d => d.date === legs.date && d.role === 'kljucna')).toBe(true)
  })
})

describe('A25: po enodnevni tekmi A (pod 5 h) en teden lahko, ne dva', () => {
  it('VN Kranj 150 km, 10 tednov do glavnega cilja → samo en teden »po«', () => {
    const u = P({ hoursPerWeek: 17, level: 4, event: { name: 'DP U23', date: '2027-06-27', distanceKm: 160, type: 'cestna' }, races: [{ id: 'r1', name: 'VN Kranj', date: '2027-04-18', distanceKm: 150, prio: 'A', type: 'klanci', elevM: 2500 }], cycleStart: '2026-11-02' })
    const po = ['2027-04-19', '2027-04-26', '2027-05-03'].filter(w => weekContext(u, w).phase === 'po')
    expect(po).toEqual(['2027-04-19'])
  })
  it('po glavnem cilju sezone ostaneta dva tedna', () => {
    const p = P({ event: { name: 'Glavna', date: '2027-04-18', distanceKm: 150 }, races: [{ id: 'r2', name: 'Jesen', date: '2027-09-12', distanceKm: 120, prio: 'A' }] })
    expect(['2027-04-19', '2027-04-26'].map(w => weekContext(p, w).phase)).toEqual(['po', 'po'])
  })
})

describe('A26: začetnica brez cilja — 8 tednov osnove, v gradnji sweet spot namesto praga', () => {
  const nov = P({ level: 1, event: null, races: [], hoursPerWeek: 4, cycleStart: '2026-10-12', ftp: null, ftpDate: null, gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, strength: { on: false, equipment: 'none' } })
  it('tedni 1–8 so osnova; v prvih 12 tednih noben ključni trening ni prag', () => {
    expect(Array.from({ length: 8 }, (_, k) => weekContext(nov, addDays('2026-10-12', 7 * k)).phase).every(x => x === 'osnova')).toBe(true)
    for (let k = 0; k < 12; k++) expect(bw(nov, addDays('2026-10-12', 7 * k)).some(d => /^Prag/.test(d.title))).toBe(false)
  })
})

describe('C17: začetek ob koncu tedna — 1. teden bloka se začne v ponedeljek', () => {
  const f = normalizeFocus({ sessions: [{ type: 'fitnes', part: 'celo', min: 50 }, { type: 'tek', cardio: 'lahko', min: 30 }, { type: 'fitnes', part: 'celo', min: 50 }], aims: ['zdravje'], level: 2 }, { now })!
  it('dogovor v soboto → cycleStart naslednji ponedeljek; 4. teden bloka je teden od 9. 11.', () => {
    const patch = profileFromFocus(f, blank, '2026-10-12', '2026-10-17')
    expect(patch.cycleStart).toBe('2026-10-19')
    expect(profileFromFocus(f, blank, '2026-10-12', '2026-10-14').cycleStart).toBe('2026-10-12')       // sreda: ta teden
    const p = { ...blank, ...patch } as Profile
    expect(focusWeekContext(p, '2026-11-09').recovery).toBe(true)
    expect(focusWeekContext(p, '2026-11-02').recovery).toBe(false)
  })
  it('uvodni dnevi: razlaga tedna in brez testa FTP (kolesar)', () => {
    const p = { ...blank, ...profileFromFocus(f, blank, '2026-10-12', '2026-10-17') } as Profile
    const w = buildFocusWeek({ profile: p, activities: [], weekStart: '2026-10-12', notBefore: '2026-10-17', today: '2026-10-17' })
    expect(w.find(d => d.why && /uvodni dnevi/.test(d.why))).toBeTruthy()
    const k = P({ cycleStart: '2026-10-19', ftpDate: '2026-01-01', event: { name: 'Blizu', date: '2026-12-13', distanceKm: 100 } })
    expect(weekContext(k, '2026-10-12').test).toBe(false)
    expect(weekContext(k, '2026-10-19').test).toBe(true)
  })
})

describe('C21: načrt ne raste, če prejšnji teden ni bilo nobene vadbe', () => {
  const f: Focus = { ...normalizeFocus({ sessions: [{ type: 'fitnes', part: 'celo', min: 50 }, { type: 'kolo', cardio: 'lahko', min: 60 }, { type: 'fitnes', part: 'celo', min: 50 }], aims: ['zdravje'], level: 2 }, { now })!, mode: 'meri' }
  const p = { ...blank, focus: f, cycleStart: '2026-10-19' } as Profile
  const bike = (w: PlanDay[]) => w.find(d => d.kind === 'kolo')!.durationMin
  // teden od 2. 11. (3. teden bloka) se sestavi 26. 10. — takrat je znan teden od 19. 10.
  const third = (o: Partial<Parameters<typeof buildFocusWeek>[0]> = {}) => buildFocusWeek({ profile: p, activities: [], weekStart: '2026-11-02', notBefore: '2026-11-02', today: '2026-10-26', ...o })
  it('0 vadb v 1. tednu → 3. teden ostane kot v dogovoru (ne 1,1 ×); razlaga pove zakaj', () => {
    const w = third()
    expect(bike(w)).toBe(60)
    expect(w.some(d => /ne raste/.test(d.why || ''))).toBe(true)
  })
  it('z vadbo (ura ali »Opravil« brez ure) raste kot prej', () => {
    const ride = { id: 'r', source: 'manual', sport: 'kolo', date: '2026-10-21', name: 'Vožnja', durationMin: 60, aiEligible: true, geoRetain: false } as Activity
    expect(bike(third({ activities: [ride] }))).toBe(65)
    expect(bike(third({ done: [{ date: '2026-10-20', kind: 'moc' }] }))).toBe(65)
  })
  it('kolesar po dogovoru brez ene vožnje: ure ostanejo na ravni 1. tedna', () => {
    const k = P({ level: 2, hoursPerWeek: 7, cycleStart: '2026-10-19', ftpDate: '2026-10-10', focus: { ...f, mode: 'kolo', aims: ['tekma'] } as Focus })
    const first = weekContext(k, '2026-10-19').hours
    const h = planHours(k, [], '2026-11-02', '2026-10-26')
    expect(h.idle).toBe(true)
    expect(h.hours).toBe(first)
    expect(planHours(k, [{ id: 'r', source: 'manual', sport: 'kolo', date: '2026-10-21', name: 'V', durationMin: 60, aiEligible: true, geoRetain: false } as Activity], '2026-11-02', '2026-10-26').idle).toBeFalsy()
    // brez dogovora (stari profili) in brez zgodovine: kot prej, brez stropa
    expect(planHours({ ...k, focus: null }, [], '2026-11-02', '2026-10-26').idle).toBeFalsy()
    expect(bw(k, '2026-11-02', [], '2026-10-26').some(d => /ni zapisane vožnje/.test(d.why || ''))).toBe(true)
  })
})
