// Izvajalnik treninga: čas iz ure (ne ponastavi se ob ponovnem branju načrta, teče v ozadju), napredek preživi
// osvežitev, moč se zapiše enkrat, zvok se ob odhodu zapre, zaklep zaslona se po vrnitvi zahteva znova.
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>() }))
const emit = () => S.subs.forEach(f => f())
const store = vi.hoisted(() => ({ setPlanDone: vi.fn(async () => {}), addActivities: vi.fn(async () => ({ added: 1, dupes: 0, upgraded: 0 })), toast: vi.fn() }))
vi.mock('@/state/store', () => ({
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  ...store,
  newRouteFor: vi.fn(), routePace: () => ({ k: 1, adj: { n: 0, adj: 1 } }),
}))

import { Vadba, RUN_KEY } from '@/screens/Vadba'
import { stepsFor, fmtClock } from '@/domain/training/workout'
import type { PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

const today = new Date().toISOString().slice(0, 10)
const profile = { sex: 'm', age: 35, heightCm: 180, weightKg: 75, ftp: 250, gear: { bikeOutdoor: true, trainer: false, noBike: false }, strength: { on: false, equipment: 'none' }, onboardingDone: true, createdAt: 'x', updatedAt: 'x' } as unknown as Profile
const ride: PlanDay = { id: 'd1', date: today, kind: 'kolo', title: 'Z2 vožnja', desc: 'Enakomerno v Z2.', durationMin: 60, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: 'x', updatedAt: 'x' }
const gym: PlanDay = { id: 'm1', date: today, kind: 'moc', title: 'Moč — jedro', desc: 'Jedro.', durationMin: 25, zone: null, role: 'moc', exercises: [{ name: 'Deska', sets: 2, reps: '40 s' }, { name: 'Mrtvi hrošč', sets: 2, reps: '10' }], source: 'rules', createdAt: 'x', updatedAt: 'x' }
const reset = (plan: PlanDay[]) => { S.state = { ready: true, today, plan, activities: [], recentMeals: [], weather: null, routeLib: null, routesBusy: false, settings: { lang: 'sl', intervals: null }, toast: null, profile } }

let div: HTMLDivElement, root: Root | null
const clock = () => div.querySelector('.num')?.textContent
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(b.textContent || '')) as HTMLButtonElement | undefined
async function mount(id: string) {
  location.hash = `#/vadba?id=${id}`
  div = document.createElement('div'); document.body.appendChild(div)
  root = createRoot(div)
  await act(async () => { root!.render(<Vadba />) })
}
async function unmount() { if (root) { await act(async () => root!.unmount()); root = null } div.remove() }
const tick = async (ms: number) => { await act(async () => { vi.advanceTimersByTime(ms) }) }
const flush = async () => { for (let i = 0; i < 6; i++) await act(async () => { await Promise.resolve() }) }

beforeEach(() => { vi.useFakeTimers(); sessionStorage.clear(); store.setPlanDone.mockClear(); store.addActivities.mockClear(); S.subs.clear() })
afterEach(async () => { await unmount(); vi.useRealTimers(); document.body.innerHTML = '' })

describe('Vadba — časovnik', () => {
  it('odštevanje ne skoči nazaj, ko se načrt znova prebere (nove identitete objektov)', async () => {
    reset([ride])
    const steps = stepsFor(ride, profile)
    await mount('d1')
    await act(async () => { btn(/Začni trening/)!.click() })
    expect(clock()).toBe(fmtClock(steps[0]!.sec))
    await tick(125_000)
    expect(clock()).toBe(fmtClock(steps[0]!.sec - 125))
    await act(async () => { S.state = { ...S.state, plan: S.state.plan.map((d: PlanDay) => ({ ...d })), profile: { ...S.state.profile } }; emit() })
    expect(clock()).toBe(fmtClock(steps[0]!.sec - 125))
  })

  it('teče iz ure: po dolgem premoru (telefon zaklenjen) ujame korake, ki so medtem minili', async () => {
    reset([ride])
    const steps = stepsFor(ride, profile)
    await mount('d1')
    await act(async () => { btn(/Začni trening/)!.click() })
    // brez intervalov (ozadje): ura se premakne čez prvi korak + 30 s, nato en tik
    vi.setSystemTime(Date.now() + (steps[0]!.sec + 30) * 1000)
    await tick(250)
    expect(div.textContent).toContain(`2 / ${steps.length}`)
    expect(clock()).toBe(fmtClock(steps[1]!.sec - 30))
  })

  it('napredek preživi osvežitev strani (sessionStorage) in čas teče naprej', async () => {
    reset([ride])
    const steps = stepsFor(ride, profile)
    await mount('d1')
    await act(async () => { btn(/Začni trening/)!.click() })
    await tick(60_000)
    expect(sessionStorage.getItem(RUN_KEY)).toBeTruthy()
    await unmount()
    vi.setSystemTime(Date.now() + 20_000)          // »osvežitev« traja 20 s
    await mount('d1')
    await tick(250)
    expect(clock()).toBe(fmtClock(steps[0]!.sec - 80))
    expect(btn(/Začni trening/)).toBeUndefined()   // ne začne znova s pregledom
  })
})

describe('Vadba — konec, zvok, zaklep zaslona', () => {
  it('moč se ob »Zaključi« zapiše kot aktivnost natanko enkrat', async () => {
    reset([gym])
    await mount('m1')
    await act(async () => { btn(/Začni trening/)!.click() })
    await tick(5_000)
    await act(async () => { btn(/^Zaključi$/)!.click() })        // odpre potrditev
    const confirmBtn = [...document.querySelectorAll('.sheet button')].find(b => b.textContent === 'Zaključi') as HTMLButtonElement
    expect(confirmBtn).toBeTruthy()
    await act(async () => { confirmBtn.click() })
    await flush()
    await tick(3_000); await flush()
    expect(store.setPlanDone).toHaveBeenCalledTimes(1)
    expect(store.setPlanDone).toHaveBeenCalledWith('m1', true)
    expect(store.addActivities).toHaveBeenCalledTimes(1)
    expect(div.textContent).toContain('Opravljeno')
    // ponovni izris (npr. osveženo stanje) ne zapiše še enkrat
    await act(async () => { S.state = { ...S.state, plan: [{ ...gym, done: { at: 'x' } }] }; emit() })
    await flush()
    expect(store.addActivities).toHaveBeenCalledTimes(1)
  })

  it('AudioContext se ob odhodu z zaslona zapre', async () => {
    const close = vi.fn(async () => {})
    class FakeCtx { state = 'running'; currentTime = 0; destination = {}; close = close; resume = vi.fn(async () => {})
      createOscillator() { return { frequency: { value: 0 }, connect: () => {}, start: () => {}, stop: () => {} } }
      createGain() { return { gain: { setValueAtTime: () => {}, exponentialRampToValueAtTime: () => {} }, connect: () => {} } } }
    ;(window as unknown as { AudioContext: unknown }).AudioContext = FakeCtx
    reset([ride])
    await mount('d1')
    await act(async () => { btn(/Začni trening/)!.click() })
    await unmount()
    expect(close).toHaveBeenCalledTimes(1)
    delete (window as unknown as { AudioContext?: unknown }).AudioContext
  })

  it('zaklep zaslona: ko ga brskalnik sprosti (ozadje), ga ob vrnitvi zahteva znova', async () => {
    let onRelease: (() => void) | null = null
    const request = vi.fn(async () => ({ release: vi.fn(async () => {}), addEventListener: (_t: string, f: () => void) => { onRelease = f } }))
    Object.defineProperty(navigator, 'wakeLock', { value: { request }, configurable: true })
    reset([ride])
    await mount('d1')
    await act(async () => { btn(/Začni trening/)!.click() })
    await flush()
    expect(request).toHaveBeenCalledTimes(1)
    await act(async () => { onRelease?.(); document.dispatchEvent(new Event('visibilitychange')) })
    await flush()
    expect(request).toHaveBeenCalledTimes(2)
    delete (navigator as unknown as { wakeLock?: unknown }).wakeLock
  })
})
