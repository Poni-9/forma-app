// v3.51 PLANER-PLAN (zasloni): Plan v tednu premora, »Spremeni« in »Dodaj trening«, izvozi, trak tedna, napredek, sezona,
// list »Ta teden …« in gumb pod odgovorom trenerja.
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeAll, afterAll, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'plan', params: {} as Record<string, string> }, ics: [] as unknown[][] }))
vi.mock('@/state/store', async () => {
  const { vi: v } = await import('vitest')
  const base: Record<string | symbol, unknown> = {
    useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
    getState: () => S.state,
    routePace: () => ({ k: 1, adj: { n: 0, adj: 1 } }),
    keepOwn: (b: unknown[]) => b,
  }
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' || typeof k === 'symbol' ? undefined : (t[k] = v.fn(async () => undefined))), has: (_t, k) => k !== 'then' })
})
vi.mock('@/app/router', () => ({ navigate: vi.fn(), useRoute: () => S.route }))
vi.mock('@/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
vi.mock('@/domain/training/ics', async (orig) => {
  const m = await orig<typeof import('@/domain/training/ics')>()
  return { ...m, downloadIcs: (...a: unknown[]) => { S.ics.push(a); return m.icsCount(a[0] as never) } }
})

import * as store from '@/state/store'
import { navigate } from '@/app/router'
import { Plan, applyDayEdit, dayFormError } from '@/screens/Plan'
import { SeasonChart, WeekRibbon, WeekProgress } from '@/ui/PlanHero'
import { PauseOffer, WeekPauseSheet } from '@/ui/WeekPauseSheet'
import { DayPlan } from '@/ui/DayPlan'
import { plannedMacro } from '@/domain/training/planner'
import { PAUSE_TITLE, PAUSE_TITLE_KOLO, PAUSE_DESC_KOLO, PAUSE_DESC, OWN_WHY } from '@/domain/training/pause'
import { addDays } from '@/domain/training/load'
import type { Activity, PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-21'   // sreda
const NOW = `${TODAY}T08:00:00.000Z`
const W0 = '2026-10-19'
beforeAll(() => { vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date(`${TODAY}T10:00:00`)) })
afterAll(() => { vi.useRealTimers() })

let div: HTMLDivElement | null = null, root: Root | null = null
async function render(el: ReactElement): Promise<HTMLDivElement> {
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root!.render(el) })
  return div
}
afterEach(async () => { if (root) await act(async () => root!.unmount()); div?.remove(); root = null; div = null; document.body.innerHTML = ''; S.ics = []; S.route = { name: 'plan', params: {} } })
const sp = (x: string | null | undefined) => (x || '').replace(/[\u00a0\u202f\u2060]/g, ' ')
const txt = (d: Element) => sp(d.textContent)
const fn = (k: string) => (store as unknown as Record<string, ReturnType<typeof vi.fn>>)[k]!
const btn = (re: RegExp, el: ParentNode = document) => [...el.querySelectorAll('button')].find(b => re.test(sp(b.textContent))) as HTMLButtonElement | undefined
const wait = () => act(async () => { await new Promise(r => setTimeout(r, 60)) })

const day = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: date + (o.kind || 'kolo') + (o.role || '') + (o.title || ''), date, kind: 'kolo', title: 'Z2 vzdržljivost', desc: 'Mirno utrip 149–164, kadenca 90+.', durationMin: 60, zone: 'Z2', role: 'lahka', tssTarget: 42, source: 'rules', createdAt: NOW, updatedAt: NOW, ...o })
const rest = (date: string, title = 'Počitek', desc = 'Prosto.'): PlanDay => day(date, { kind: 'pocitek', title, desc, durationMin: 0, zone: null, role: null, tssTarget: 0 })
const moc = (date: string, min = 30): PlanDay => day(date, { kind: 'moc', title: 'Moč — noge in jedro', desc: 'Noge.', durationMin: min, zone: null, role: 'moc', tssTarget: 30, exercises: [{ name: 'Deska', sets: 3, reps: '45 s' }] })
const BLAZ = {
  name: 'Blaž', sex: 'm', age: 21, heightCm: 180, weightKg: 79, restHr: 48, maxHr: 195, lthr: 184, ftp: 240, ftpDate: '2026-09-14', goal: 'dirka', level: 3,
  gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false, powerMeterAuto: true }, hoursPerWeek: 11, hoursMode: 'own', strength: { on: true, equipment: 'home' }, strengthDays: 2,
  deficit: 400, neat: 1.4, proteinGkg: 1.8, event: { name: 'Maraton Franja', date: '2027-06-13', distanceKm: 156, type: 'maraton', elevM: 1600, level: 'amater' },
  races: [], trainTime: 'popoldne', cycleStart: '2026-09-21', baseHours: 5.8, onboardingDone: true, createdAt: NOW, updatedAt: NOW,
} as unknown as Profile
const ride = (date: string, min: number): Activity => ({ id: 'a' + date + min, source: 'manual', sport: 'kolo', date, name: 'Vožnja', durationMin: min, tss: 50 } as Activity)
const ACTS: Activity[] = ['2026-09-22', '2026-09-26', '2026-09-29', '2026-10-03', '2026-10-06', '2026-10-10', '2026-10-13', '2026-10-17'].map(d => ride(d, 105))
const state = (o: Record<string, unknown> = {}) => ({ ready: true, today: TODAY, profile: BLAZ, activities: ACTS, plan: [], checkins: [], weather: null, user: null, changes: [], settings: {}, sync: { state: 'ok' }, mealsToday: [], recentMeals: [], routeLib: null, routesBusy: false, ...o })
/** teden premora brez kolesa od torka: pon počitek, tor–ned premor (torek še moč) */
const pauseWeek = (mode: 'kolo' | 'vse' = 'kolo') => [rest(W0), ...[1, 2, 3, 4, 5, 6].map(i => rest(addDays(W0, i), mode === 'kolo' ? PAUSE_TITLE_KOLO : PAUSE_TITLE, mode === 'kolo' ? PAUSE_DESC_KOLO : PAUSE_DESC)), ...(mode === 'kolo' ? [moc(addDays(W0, 1))] : [])]
const PAUSED = { ...BLAZ, weekPause: { from: '2026-10-20', to: '2026-10-25', mode: 'kolo' } } as Profile

describe('Plan v tednu premora', () => {
  it('B08 B27 brez »raste ~10 %« in brez »Na kolesu —«; vrstica premora z urami naslednjega tedna', async () => {
    S.route = { name: 'plan', params: { sec: 'pl-opravljeno' } }
    S.state = state({ profile: PAUSED, plan: pauseWeek('kolo') })
    const d = await render(<Plan />)
    expect(txt(d)).not.toMatch(/raste/)
    expect(txt(d)).not.toContain('Na kolesu —')
    expect(txt(d)).toMatch(/Ta teden brez kolesa \(premor\) · moč 30 min · naslednji teden ~\d/)
  })
  it('B28 trak in značka: »premor«, ne »počitek«; B39 čip premora tudi v »Naslednji«', async () => {
    S.state = state({ profile: { ...PAUSED, weekPause: { from: '2026-10-20', to: '2026-11-01', mode: 'kolo' } }, plan: [...pauseWeek('kolo'), ...[0, 1, 2].map(i => rest(addDays(W0, 7 + i), PAUSE_TITLE_KOLO, PAUSE_DESC_KOLO))] })
    const d = await render(<Plan />)
    const rib = [...d.querySelectorAll('.pl-day')].map(b => sp(b.getAttribute('aria-label')))
    expect(rib).toContain('sre 21.: premor')
    expect(rib).toContain('pon 19.: počitek')
    expect(txt(d)).toContain('DANES · PREMOR')
    await act(async () => { btn(/^Naslednji$/, d)!.click() })
    expect(btn(/^premor do nedelje, 1\. 11\. \(brez kolesa\)$/, d)).toBeTruthy()
  })
  it('B30 »v koledar« v tednu brez treningov: obvestilo, ni prenosa', async () => {
    S.state = state({ profile: { ...BLAZ, weekPause: { from: W0, to: '2026-10-25', mode: 'vse' } }, plan: pauseWeek('vse') })
    const d = await render(<Plan />)
    fn('toast').mockClear()
    await act(async () => { btn(/^v koledar$/, d)!.click() })
    expect(fn('toast')).toHaveBeenCalledWith('Ta teden ni treningov za koledar.', 'info')
  })
})

describe('Plan: izvozi, sezona, teden sredi tedna', () => {
  it('B31 »v koledar« brez preteklih dni tega tedna', async () => {
    S.state = state({ plan: [day(W0, { title: 'Z2 ponedeljek' }), day(TODAY), day('2026-10-24', { title: 'Dolga Z2', role: 'dolga', durationMin: 150 })] })
    const d = await render(<Plan />)
    await act(async () => { btn(/^v koledar$/, d)!.click() })
    const days = S.ics[0]![0] as PlanDay[]
    expect(days.map(x => x.date)).toEqual([TODAY, '2026-10-24'])
  })
  it('B40 »2 tedna« ima »v koledar« in »deli«', async () => {
    S.state = state({ plan: [day(TODAY), day('2026-10-28')] })
    const d = await render(<Plan />)
    await act(async () => { btn(/^2 tedna$/, d)!.click() })
    expect(btn(/^v koledar$/, d)).toBeTruthy()
    expect(btn(/^deli$/, d)).toBeTruthy()
    await act(async () => { btn(/^v koledar$/, d)!.click() })
    expect((S.ics[0]![0] as PlanDay[]).map(x => x.date)).toEqual([TODAY, '2026-10-28'])
  })
  it('B43 teden, sestavljen v petek: »(od petka)«', async () => {
    S.state = state({ plan: [day('2026-10-23'), day('2026-10-24', { title: 'Dolga Z2', role: 'dolga', durationMin: 120 })] })
    const d = await render(<Plan />)
    expect(txt(d)).toMatch(/teden \d+\/\d+ · 3 h \(od petka\)/)
  })
  it('B16 kolesar brez cilja: »Sezona po tednih« s 12-tedenskim ciklom', async () => {
    const nov = { ...BLAZ, event: null, races: [], goal: 'forma', level: 1, hoursPerWeek: 4, cycleStart: W0, baseHours: null } as unknown as Profile
    S.state = state({ profile: nov, activities: [], plan: [day(TODAY)] })
    const d = await render(<Plan />)
    expect(txt(d)).toContain('Sezona po tednih')
    expect(txt(d)).toContain('12-tedenski cikel · potegni po tednih')
    expect(txt(d)).toMatch(/Nastavi cilj|Dodaj cilj/)                       // kartica za cilj ostane
  })
  it('B41 »Odpri teden ›« pri naslednjem tednu sezone', async () => {
    const macro = plannedMacro(BLAZ, ACTS, TODAY)
    const onOpen = vi.fn()
    const d = await render(<SeasonChart macro={macro} profile={BLAZ} start={W0} today={TODAY} onOpen={onOpen} />)
    expect(btn(/Odpri teden/, d)).toBeUndefined()                         // ta teden že gledaš
    const bar = d.querySelector('[role="slider"]')!
    await act(async () => { bar.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true })) })
    await act(async () => { btn(/^Odpri teden ›$/, d)!.click() })
    expect(onOpen).toHaveBeenCalledWith('2026-10-26')
  })
})

describe('trak in napredek tedna', () => {
  it('B33 pod kolesom minute vožnje, ne vožnja + moč', async () => {
    const days = Array.from({ length: 7 }, (_, i) => addDays(W0, i))
    const d = await render(<WeekRibbon days={days} items={[day('2026-10-20', { title: 'VO2max 4 × 4 min', durationMin: 75, role: 'kljucna' }), moc('2026-10-20')]} today={TODAY} focus={TODAY} />)
    expect(sp(d.querySelectorAll('.pl-min')[1]!.textContent)).toBe('1:15')
  })
  it('B42 tekma ni trening: »0/1 treningov + tekma · 0 min od 45 min«', async () => {
    const items = [day('2026-10-23', { title: 'Kronometer Vodice — 18 km', durationMin: 30, zone: 'dirka', role: 'dirka', raceId: 'r1' }), day('2026-10-24', { title: 'Regeneracija', durationMin: 45, role: 'regen' })]
    const d = await render(<WeekProgress items={items} activities={[]} />)
    expect(txt(d)).toBe('0/1 treningov + tekma · 0 min od 45 min')
  })
  it('B26 dan tekme: brez »Trasa · predlog po meri treninga«', async () => {
    S.state = state()
    const d = await render(<DayPlan day={day('2026-10-23', { title: 'Kronometer Vodice — 18 km', durationMin: 30, zone: 'dirka', role: 'dirka', raceId: 'r1' })} />)
    expect(txt(d)).not.toContain('Trasa')
  })
})

describe('urejanje dneva', () => {
  it('B11 trajanje pod strukturo seje je napaka', () => {
    const desc = '20 min ogrevanje s 3 kratkimi pospeški · 4 × 4 min pri utripu nad 184, vmes 4 min lahko · 15 min iztek.'
    const f = { kind: 'kolo' as const, title: 'VO2max 4 × 4 min', dur: '30', zone: 'Z5', desc }
    expect(dayFormError(f, 'kljucna')).toMatch(/^Ta trening traja najmanj 40 min/)
    expect(dayFormError({ ...f, dur: '45' }, 'kljucna')).toBeNull()
    expect(dayFormError({ kind: 'kolo', dur: '30', title: 'Z2', desc: 'Mirno.' })).toBeNull()
  })
  it('B24 Uredi → Počitek: naslov »Počitek«, opis brez navodil treninga', () => {
    const vo2 = day(TODAY, { title: 'VO2max 4 × 4 min', desc: '20 min ogrevanje …', durationMin: 75, zone: 'Z5', role: 'kljucna' })
    const r = applyDayEdit(vo2, { kind: 'pocitek', title: vo2.title, dur: '75', zone: 'Z5', desc: vo2.desc }, [])
    expect(r.title).toBe('Počitek')
    expect(r.desc).toBe('Prosto — spanec in hrana sta del treninga.')
    expect(applyDayEdit(vo2, { kind: 'pocitek', title: 'Dopust', dur: '', zone: '', desc: 'Na morju.' }, []).title).toBe('Dopust')
  })
  it('B17 B25 »Spremeni«: »Dodaj še trening« na dnevu z vožnjo; na dan tekme ni »+ jedro po želji«', async () => {
    const race = day('2026-10-23', { title: 'Kronometer Vodice — 18 km', durationMin: 30, zone: 'dirka', role: 'dirka', raceId: 'r1' })
    S.state = state({ plan: [day(TODAY), race], profile: { ...BLAZ, races: [{ id: 'r1', name: 'Kronometer Vodice', date: '2026-10-23', prio: 'B', type: 'kronometer', distanceKm: 18 }] } })
    const d = await render(<Plan />)
    await act(async () => { btn(/^Spremeni/, d)!.click() })
    expect(btn(/^Dodaj še trening/)).toBeTruthy()
    expect(btn(/^\+ jedro po želji/)).toBeTruthy()
    await act(async () => { btn(/^Dodaj še trening/)!.click() })
    await wait()
    expect(document.body.textContent).toContain('Dodaj trening')
    fn('savePlanDay').mockClear()
    await act(async () => { btn(/^Shrani$/)!.click() })
    const saved = fn('savePlanDay').mock.calls[0]![0] as PlanDay
    expect(saved.date).toBe(TODAY)
    expect(saved.id).not.toBe(day(TODAY).id)                                // nov zapis — vožnja ostane
    expect(saved.why).toBe(OWN_WHY)
  })
  it('B25 dan tekme: v »Spremeni« ni »+ jedro po želji«', async () => {
    S.route = { name: 'plan', params: { dan: '2026-10-23' } }
    const race = day('2026-10-23', { title: 'Kronometer Vodice — 18 km', durationMin: 30, zone: 'dirka', role: 'dirka', raceId: 'r1' })
    S.state = state({ plan: [day(TODAY), race], profile: { ...BLAZ, races: [{ id: 'r1', name: 'Kronometer Vodice', date: '2026-10-23', prio: 'B', type: 'kronometer', distanceKm: 18 }] } })
    const d = await render(<Plan />)
    await act(async () => { btn(/^Spremeni/, d)!.click() })
    expect(btn(/^\+ jedro po želji/)).toBeUndefined()
    expect(btn(/^Dodaj še trening/)).toBeUndefined()
  })
  it('B21 B22 »Dodaj trening« na dnevu premora brez kolesa: privzeto moč; brez ure »Trening dodan.«', async () => {
    S.state = state({ profile: PAUSED, plan: pauseWeek('kolo') })
    const d = await render(<Plan />)
    await act(async () => { btn(/^Dodaj trening$/, d)!.click() })
    const on = [...document.querySelectorAll('.chip.on, .chip[aria-pressed="true"]')].map(c => sp(c.textContent))
    expect(on).toContain('Moč')
    expect(on).not.toContain('Kolo')
    fn('toast').mockClear()
    await act(async () => { btn(/^Shrani$/)!.click() })
    expect(fn('toast')).toHaveBeenCalledWith('Trening dodan.', 'ok')
  })
  it('B23 pretekli dan počitka: »Vpiši vadbo«, ne »Dodaj trening«', async () => {
    S.route = { name: 'plan', params: { dan: W0 } }
    S.state = state({ plan: [rest(W0), day(TODAY)] })
    const d = await render(<Plan />)
    expect(btn(/^Dodaj trening$/, d)).toBeUndefined()
    await act(async () => { btn(/^Vpiši vadbo$/, d)!.click() })
    expect(vi.mocked(navigate)).toHaveBeenCalledWith('aktivnosti', { nova: '1', datum: W0 })
  })
})

describe('list »Ta teden …« in gumb pod odgovorom trenerja', () => {
  it('B13 »ta in naslednji teden« ob enotedenskem premoru: gumb za podaljšanje (prej »velja«)', async () => {
    S.state = state({ profile: { ...BLAZ, weekPause: { from: TODAY, to: '2026-10-25', mode: 'vse' } } })
    const d = await render(<PauseOffer mode="vse" twoWeeks />)
    expect(d.querySelector('.pause-ok')).toBeNull()
    expect(btn(/^Uveljavi: še naslednji teden brez treningov$/, d)).toBeTruthy()
  })
  it('B20 veljaven način je označen (aria-current) in onemogočen (tap ga ne uveljavi znova), drugi ne', async () => {
    S.state = state({ profile: { ...BLAZ, weekPause: { from: TODAY, to: '2026-10-25', mode: 'kolo' } } })
    await render(<WeekPauseSheet open onClose={() => undefined} />)
    const cur = btn(/^Brez kolesa do nedelje.*velja/)   // (po združitvi) oznaka »✓ velja« (DANES-VADBA)!
    expect(cur.getAttribute('aria-current')).toBe('true')
    // (v3.51 POPRAVKI51-UI, U1) po združitvi je ostal samo disabled={busy} — tap je premor znova uveljavil
    expect(cur.disabled).toBe(true)
    const n0 = fn('setWeekPause').mock.calls.length
    await act(async () => { cur.click() })
    expect(fn('setWeekPause').mock.calls.length).toBe(n0)
    expect(btn(/^Brez treningov do nedelje/)!.getAttribute('aria-current')).toBeNull()
    expect(btn(/^Brez treningov do nedelje/)!.disabled).toBe(false)
    expect(document.body.textContent).toContain('Zdaj velja: premor do nedelje (brez kolesa).')
  })
  it('B07 tekma v času premora: list jo pokaže, »Odstrani tekmo« jo odstrani', async () => {
    S.state = state({ profile: { ...BLAZ, races: [{ id: 'r1', name: 'Kronometer Vodice', date: '2026-10-23', prio: 'B', type: 'kronometer', distanceKm: 18 }, { id: 'r2', name: 'Kasneje', date: '2026-12-01', prio: 'C' }] } })
    await render(<WeekPauseSheet open onClose={() => undefined} />)
    expect(sp(document.body.textContent)).toContain('V tem času je tekma Kronometer Vodice (petek, 23. 10.). Ostane — tudi predaktivacija dan prej.')
    expect(sp(document.body.textContent)).not.toContain('Kasneje')
    await act(async () => { btn(/^Odstrani tekmo$/)!.click() })
    expect((fn('saveRaces').mock.calls[0]![0] as { id: string }[]).map(r => r.id)).toEqual(['r2'])
  })
})
