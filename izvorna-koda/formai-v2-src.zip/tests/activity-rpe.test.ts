import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { mergeActivities } from '../src/data/merge'
import { monthSums, monthLine, byMonth } from '../src/screens/Aktivnosti'
import { hrZoneRows } from '../src/ui/ActivitySheet'
import { rpeWarn } from '../src/domain/coach/rpe'
import { todayIso, addDays } from '../src/domain/training/load'
import type { Activity, PlanDay } from '../src/domain/types'

const today = todayIso()
const NOW = new Date().toISOString()
const ride = (id: string, o: Partial<Activity> = {}): Activity => ({ id, source: 'intervals', originHint: 'GARMIN', sport: 'kolo', date: today, start: today + 'T07:00:00.000Z', name: 'Vožnja', durationMin: 90, distKm: 40, aiEligible: true, geoRetain: true, ext: { intervalsId: 'i-' + id }, createdAt: NOW, updatedAt: NOW, ...o })
const day = (id: string, o: Partial<PlanDay> = {}): PlanDay => ({ id, date: today, kind: 'kolo', title: 'Z2', desc: '', durationMin: 90, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })

beforeEach(async () => { await repo.wipeAll(); localStorage.clear(); await store.reloadAll() })

describe('kako je šlo (RPE)', () => {
  it('na vadbo, če je povezana; sicer na dan načrta; tap na isto stopnjo pobriše', async () => {
    await store.addActivities([ride('a1')])
    await store.savePlanDays([day('d1', { done: { at: NOW, activityId: 'a1' } }), day('d2', { date: addDays(today, -1), done: { at: NOW, activityId: null } })])
    await store.rateSession({ activityId: 'a1', dayId: 'd1' }, 8)
    expect(store.getState().activities.find(a => a.id === 'a1')!.rpe).toBe(8)
    expect(store.getState().plan.find(d => d.id === 'd1')!.rpe).toBeUndefined()
    await store.rateSession({ activityId: null, dayId: 'd2' }, 4)
    expect(store.getState().plan.find(d => d.id === 'd2')!.rpe).toBe(4)
    await store.rateSession({ activityId: 'a1' }, null)
    expect(store.getState().activities.find(a => a.id === 'a1')!.rpe).toBeNull()
  })
  it('ponoven uvoz iste vožnje (nove cone) ohrani občutek, opombo in preimenovanje', async () => {
    await store.addActivities([ride('a1')])
    const a = store.getState().activities[0]!
    await store.saveActivity({ ...a, rpe: 6, notes: 'veter', name: 'Krog okoli Bleda', named: true })
    const r = await repo.addActivities([ride('a1-novi', { ext: { intervalsId: 'i-a1' }, hrZoneSec: [600, 4000, 300, 0, 0, 0, 0], name: 'Kolesarjenje' })])
    expect(r.upgraded).toBe(1)
    const got = (await repo.allActivities())[0]!
    expect(got).toMatchObject({ rpe: 6, notes: 'veter', name: 'Krog okoli Bleda', named: true })
    expect(got.hrZoneSec).toBeTruthy()
  })
  it('bogatejši dvojnik iz drugega vira (datoteka s sledjo) ohrani, kar je vpisal uporabnik', async () => {
    await store.addActivities([ride('m1', { source: 'manual', ext: undefined, avgHr: 140 })])
    const a = store.getState().activities[0]!
    await store.saveActivity({ ...a, rpe: 9, notes: 'težke noge' })
    const r = await repo.addActivities([ride('f1', { source: 'file', ext: { fileName: 'x.fit' }, polyline: 'abc', avgHr: 141, avgPower: 180 })])
    expect(r.upgraded).toBe(1)
    const got = (await repo.allActivities())[0]!
    expect(got).toMatchObject({ id: 'm1', rpe: 9, notes: 'težke noge', polyline: 'abc' })
  })
  it('usklajevanje: občutek z druge naprave ostane, če ga novejša različica nima; izbris (null) velja', () => {
    const older = ride('a1', { rpe: 7, updatedAt: '2026-10-01T08:00:00.000Z' })
    const newer = ride('a1', { hrZoneSec: [1, 2, 3, 4], updatedAt: '2026-10-02T08:00:00.000Z' })
    expect(mergeActivities([older], [newer], {}, Date.now()).list[0]!.rpe).toBe(7)
    const cleared = ride('a1', { rpe: null, updatedAt: '2026-10-03T08:00:00.000Z' })
    expect(mergeActivities([older], [cleared], {}, Date.now()).list[0]!.rpe).toBeNull()
  })
  it('opozorilo upošteva tudi ocene na dnevih brez vadbe', () => {
    const plan = [day('x1', { date: addDays(today, -1), done: { at: NOW, activityId: null }, rpe: 8 }), day('x2', { date: addDays(today, -3), done: { at: NOW, activityId: null }, rpe: 10 })]
    expect(rpeWarn([], plan, today)).toMatch(/2× zdele težke/)
  })
})

describe('aktivnosti: seštevki meseca in cone', () => {
  it('seštevek iz vseh vadb meseca (ne le izrisanih)', () => {
    const list = [ride('a', { date: '2026-10-02', durationMin: 100, distKm: 40.4, elevM: 300 }), ride('b', { date: '2026-10-01', durationMin: 66, distKm: 13.7, elevM: 300 }), ride('c', { date: '2026-09-30', sport: 'moc', durationMin: 40, distKm: null })]
    const s = monthSums(list)
    const sp = (t: string) => t.replace(/\u00a0/g, ' ')
    expect(sp(monthLine(s.get('2026-10')!))).toBe('2 vadbi · 2 h 46 min · 54 km · 600 m')
    expect(sp(monthLine(s.get('2026-09')!))).toBe('1 vadba · 40 min')
    expect(byMonth(list.slice(0, 1)).map(g => g.key)).toEqual(['2026-10'])
  })
  it('cone utripa: minute z mejami ure, delež lahko · tempo · prag+', () => {
    const z = hrZoneRows({ hrZoneSec: [600, 3000, 600, 300, 60, 0, 0], hrZoneTop: [120, 140, 171, 180, 188, 195, 210] })!
    expect(z.rows.map(r => `${r.key} ${r.range} ${r.min}`)).toEqual(['Z1 do 120 10', 'Z2 121–140 50', 'Z3 141–171 10', 'Z4 172–180 5', 'Z5 181–188 1'])
    expect([z.easy, z.mid, z.hard, z.total]).toEqual([79, 13, 8, 76])
    expect(hrZoneRows({ hrZoneSec: [10, 0, 0, 0], hrZoneTop: null })).toBeNull()
  })
})
