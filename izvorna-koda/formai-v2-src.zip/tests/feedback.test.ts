import 'fake-indexeddb/auto'
import { describe, it, expect, vi, afterEach, beforeEach } from 'vitest'

const h = vi.hoisted(() => ({ token: null as string | null }))
vi.mock('../src/data/firebase', () => ({ idToken: async () => h.token }))

import { makeFeedback, sendFeedback, flushFeedback, queuedFeedback, trapErrors, recentErrors, FB_SHOT_MAX } from '../src/data/feedback'
import { getKV, setKV } from '../src/data/db'
import { APP_VERSION } from '../src/config'

afterEach(() => { vi.unstubAllGlobals() })
beforeEach(async () => { await setKV('feedback.queue', []); h.token = null })

describe('pripombe: priprava', () => {
  it('besedilo obrezano, posnetek samo data:image do meje, tehnični podatki in naprava (anonimna oznaka ostane ista)', async () => {
    const f = await makeFeedback({ kind: 'napaka', text: '  Gumb ne dela  ', shot: 'data:image/jpeg;base64,AAAA', route: 'danes' })
    expect(f).toMatchObject({ kind: 'napaka', text: 'Gumb ne dela', shot: 'data:image/jpeg;base64,AAAA' })
    expect(f.meta).toMatchObject({ v: APP_VERSION, route: 'danes' })
    expect(Array.isArray(f.meta.errs)).toBe(true)
    expect(f.anon).toMatch(/^[a-f0-9]{16}$/)
    expect((await makeFeedback({ kind: 'predlog', text: 'x', shot: null, route: 'plan' })).anon).toBe(f.anon)
    expect((await makeFeedback({ kind: 'nejasno', text: 'x', shot: 'javascript:alert(1)', route: 'plan' })).shot).toBeNull()
    expect((await makeFeedback({ kind: 'nejasno', text: 'x', shot: 'data:image/jpeg;base64,' + 'A'.repeat(FB_SHOT_MAX), route: 'plan' })).shot).toBeNull()
  })
  it('zadnje napake aplikacije (samo besedilo, največ 8)', () => {
    trapErrors()
    for (let i = 0; i < 10; i++) window.dispatchEvent(new ErrorEvent('error', { message: `napaka ${i}` }))
    const e = recentErrors()
    expect(e.length).toBe(8)
    expect(e[7]).toMatch(/napaka 9$/)
  })
})

describe('pripombe: pošiljanje in vrsta', () => {
  it('poslano: z žetonom, če si prijavljen; brez prijave brez glave Authorization', async () => {
    const f = vi.fn(async (_u: string, _i?: RequestInit) => new Response('{"ok":true}', { status: 200 }))
    vi.stubGlobal('fetch', f)
    const fb = await makeFeedback({ kind: 'nejasno', text: 'Kaj je forma?', shot: null, route: 'danes' })
    expect(await sendFeedback(fb)).toBe('poslano')
    expect(String(f.mock.calls[0]![0])).toMatch(/\/feedback$/)
    expect((f.mock.calls[0]![1]!.headers as Record<string, string>).Authorization).toBeUndefined()
    h.token = 'tok'
    await sendFeedback(fb)
    expect((f.mock.calls[1]![1]!.headers as Record<string, string>).Authorization).toBe('Bearer tok')
  })
  it('strežnik brez poti (404) ali brez povezave → v vrsto; flush pošlje, ko gre; 400 se zavrže', async () => {
    const fb = await makeFeedback({ kind: 'napaka', text: 'A', shot: null, route: 'plan' })
    vi.stubGlobal('fetch', vi.fn(async () => new Response('', { status: 404 })))
    expect(await sendFeedback(fb)).toBe('v vrsti')
    vi.stubGlobal('fetch', vi.fn(async () => { throw new TypeError('offline') }))
    expect(await sendFeedback({ ...fb, id: 'drugi' })).toBe('v vrsti')
    expect(await queuedFeedback()).toBe(2)
    vi.stubGlobal('fetch', vi.fn(async () => new Response('{"ok":true}', { status: 200 })))
    expect(await flushFeedback()).toBe(2)
    expect(await queuedFeedback()).toBe(0)
    vi.stubGlobal('fetch', vi.fn(async () => new Response('{"error":"prazno"}', { status: 400 })))
    expect(await sendFeedback(fb)).toBe('poslano')   // ni smisla ponavljati
    expect(await queuedFeedback()).toBe(0)
  })
  it('prevelik posnetek (413) → isto brez posnetka', async () => {
    const f = vi.fn()
      .mockResolvedValueOnce(new Response('', { status: 413 }))
      .mockResolvedValueOnce(new Response('{"ok":true}', { status: 200 }))
    vi.stubGlobal('fetch', f)
    const fb = await makeFeedback({ kind: 'napaka', text: 'B', shot: 'data:image/jpeg;base64,AAAA', route: 'plan' })
    expect(await sendFeedback(fb)).toBe('poslano')
    expect(JSON.parse(String(f.mock.calls[1]![1]!.body)).shot).toBeNull()
    expect(await getKV('feedback.queue')).toEqual([])
  })
})
