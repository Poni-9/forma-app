import 'fake-indexeddb/auto'
import { describe, it, expect, vi, afterEach, beforeEach } from 'vitest'

const h = vi.hoisted(() => ({ token: null as string | null }))
vi.mock('../src/data/firebase', () => ({ idToken: async () => h.token }))

import { makeFeedback, sendFeedback, flushFeedback, queuedFeedback, trapErrors, recentErrors, FB_SHOT_MAX, pilotParts, rowsFromPilot } from '../src/data/feedback'
import { getKV, setKV } from '../src/data/db'
import { APP_VERSION } from '../src/config'

afterEach(() => { vi.unstubAllGlobals() })
beforeEach(async () => { await setKV('feedback.queue', []); h.token = null })

describe('pripombe: priprava', () => {
  it('besedilo obrezano, posnetek samo data:image do meje, tehnični podatki in naprava (anonimna oznaka ostane ista)', async () => {
    const f = await makeFeedback({ kind: 'napaka', text: '  Gumb ne dela  ', shot: 'data:image/jpeg;base64,AAAA', route: 'danes' })
    expect(f).toMatchObject({ kind: 'napaka', text: 'Gumb ne dela', shot: 'data:image/jpeg;base64,AAAA' })
    expect(f.meta).toMatchObject({ v: APP_VERSION, route: 'danes' })
    expect(Array.isArray(f.meta.errs)).toBe(true)
    expect(f.anon).toMatch(/^[a-f0-9]{16}$/)
    expect((await makeFeedback({ kind: 'predlog', text: 'x', shot: null, route: 'plan' })).anon).toBe(f.anon)
    expect((await makeFeedback({ kind: 'nejasno', text: 'x', shot: 'javascript:alert(1)', route: 'plan' })).shot).toBeNull()
    expect((await makeFeedback({ kind: 'nejasno', text: 'x', shot: 'data:image/jpeg;base64,' + 'A'.repeat(FB_SHOT_MAX), route: 'plan' })).shot).toBeNull()
  })
  it('zadnje napake aplikacije (samo besedilo, največ 8)', () => {
    trapErrors()
    for (let i = 0; i < 10; i++) window.dispatchEvent(new ErrorEvent('error', { message: `napaka ${i}` }))
    const e = recentErrors()
    expect(e.length).toBe(8)
    expect(e[7]).toMatch(/napaka 9$/)
  })
})

describe('pripombe: pošiljanje in vrsta', () => {
  it('poslano: z žetonom, če si prijavljen; brez prijave brez glave Authorization', async () => {
    const f = vi.fn(async (_u: string, _i?: RequestInit) => new Response('{"ok":true}', { status: 200 }))
    vi.stubGlobal('fetch', f)
    const fb = await makeFeedback({ kind: 'nejasno', text: 'Kaj je forma?', shot: null, route: 'danes' })
    expect(await sendFeedback(fb)).toBe('poslano')
    expect(String(f.mock.calls[0]![0])).toMatch(/\/feedback$/)
    expect((f.mock.calls[0]![1]!.headers as Record<string, string>).Authorization).toBeUndefined()
    h.token = 'tok'
    await sendFeedback(fb)
    expect((f.mock.calls[1]![1]!.headers as Record<string, string>).Authorization).toBe('Bearer tok')
  })
  it('strežnik brez poti (404) ali brez povezave → v vrsto; flush pošlje, ko gre; 400 se zavrže', async () => {
    const fb = await makeFeedback({ kind: 'napaka', text: 'A', shot: null, route: 'plan' })
    vi.stubGlobal('fetch', vi.fn(async () => new Response('', { status: 404 })))
    expect(await sendFeedback(fb)).toBe('v vrsti')
    vi.stubGlobal('fetch', vi.fn(async () => { throw new TypeError('offline') }))
    expect(await sendFeedback({ ...fb, id: 'drugi' })).toBe('v vrsti')
    expect(await queuedFeedback()).toBe(2)
    vi.stubGlobal('fetch', vi.fn(async () => new Response('{"ok":true}', { status: 200 })))
    expect(await flushFeedback()).toBe(2)
    expect(await queuedFeedback()).toBe(0)
    vi.stubGlobal('fetch', vi.fn(async () => new Response('{"error":"prazno"}', { status: 400 })))
    expect(await sendFeedback(fb)).toBe('poslano')   // ni smisla ponavljati
    expect(await queuedFeedback()).toBe(0)
  })
  it('dve praznitvi hkrati pošljeta enkrat; pripomba, ki pride med praznjenjem, ostane v vrsti', async () => {
    const a = await makeFeedback({ kind: 'napaka', text: 'A', shot: null, route: 'plan' })
    vi.stubGlobal('fetch', vi.fn(async () => { throw new TypeError('offline') }))
    await sendFeedback(a)
    let release!: () => void
    const gate = new Promise<void>(r => { release = r })
    const f = vi.fn(async (u: string) => { if (String(u).endsWith('/feedback')) await gate; return new Response('{"ok":true}', { status: 200 }) })
    vi.stubGlobal('fetch', f)
    const p1 = flushFeedback(), p2 = flushFeedback()
    await new Promise(r => setTimeout(r, 20))
    vi.stubGlobal('fetch', vi.fn(async () => { throw new TypeError('offline') }))
    const b = await makeFeedback({ kind: 'predlog', text: 'B', shot: null, route: 'plan' })
    expect(await sendFeedback(b)).toBe('v vrsti')   // pride med praznjenjem
    vi.stubGlobal('fetch', f)
    release()
    expect(await p1).toBe(1); expect(await p2).toBe(1)
    expect(f.mock.calls.filter(c => String(c[0]).endsWith('/feedback')).length).toBe(1)
    expect(((await getKV('feedback.queue')) as { id: string }[]).map(x => x.id)).toEqual([b.id])
  })
  it('prevelik posnetek (413) → isto brez posnetka', async () => {
    const f = vi.fn()
      .mockResolvedValueOnce(new Response('', { status: 413 }))
      .mockResolvedValueOnce(new Response('{"ok":true}', { status: 200 }))
    vi.stubGlobal('fetch', f)
    const fb = await makeFeedback({ kind: 'napaka', text: 'B', shot: 'data:image/jpeg;base64,AAAA', route: 'plan' })
    expect(await sendFeedback(fb)).toBe('poslano')
    expect(JSON.parse(String(f.mock.calls[1]![1]!.body)).shot).toBeNull()
    expect(await getKV('feedback.queue')).toEqual([])
  })
})

describe('pripombe: strežnik še brez /feedback → besedilo prek testnega programa', () => {
  const route = (map: Record<string, number>) => vi.fn(async (u: string, _i?: RequestInit) => {
    const path = new URL(String(u)).pathname
    return new Response('{}', { status: map[path] ?? 500 })
  })
  it('kosi do 200 znakov, prvi z zaslonom; dolgo besedilo skrajšano; nazaj v eno pripombo', async () => {
    const f = await makeFeedback({ kind: 'napaka', text: 'A'.repeat(400), shot: 'data:image/jpeg;base64,AAAA', route: 'plan' })
    const parts = pilotParts(f)
    expect(parts.length).toBe(3)
    for (const p of parts) expect(p.length).toBeLessThanOrEqual(200)
    expect(parts[0]).toMatch(new RegExp(`^#${f.id} 1/3 \\[plan \\d+×\\d+ \\+posnetek\\] A`))
    expect(pilotParts({ ...f, text: 'B'.repeat(5000) }).length).toBe(6)
    const rows = rowsFromPilot(parts.reverse().map((a, i) => ({ anon: f.anon, q: 'pripomba_napaka', a, v: '3.29.1', at: 1000 + i })))
    expect(rows).toHaveLength(1)
    expect(rows[0]).toMatchObject({ id: `p:${f.anon}_${f.id}`, kind: 'napaka', text: 'A'.repeat(400), shotLater: true, at: 1000, meta: { route: 'plan' } })
    expect(rowsFromPilot([{ anon: 'x', q: 'pmf', a: 'b', v: '', at: 1 }])).toEqual([])   // vprašanja testnega programa niso pripombe
  })
  it('naprava in zadnje napake na koncu (za iskanje napake); emoji se ne razpolovi; dolgo besedilo skrajšano, konec ostane', async () => {
    const f = await makeFeedback({ kind: 'napaka', text: 'Ne dela 🚴', shot: null, route: 'danes' })
    const meta = { ...f.meta, ua: 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0 Mobile Safari/537.36', errs: ['08:00:01 prva', '08:00:02 druga', '08:00:03 tretja', '08:00:04 četrta ' + 'x'.repeat(200)] }
    const rows = rowsFromPilot(pilotParts({ ...f, meta }).map(a => ({ anon: f.anon, q: 'pripomba_napaka', a, v: '3.29.1', at: 5 })))
    expect(rows[0]!.text).toBe('Ne dela 🚴')
    expect(rows[0]!.meta.ua).toBe('Android · Chrome')
    expect(rows[0]!.meta.errs).toEqual(['druga', 'tretja', 'četrta ' + 'x'.repeat(73)])
    // emoji na meji kosa: vsak kos je veljaven UTF-16 in ≤ 200 znakov, stik vrne isto besedilo
    for (let pad = 0; pad < 4; pad++) {
      const g = { ...f, meta, text: 'a'.repeat(pad) + '🚴'.repeat(600) }
      const parts = pilotParts(g)
      expect(parts.length).toBeLessThanOrEqual(6)
      for (const p of parts) { expect(p.length).toBeLessThanOrEqual(200); expect(/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/.test(p)).toBe(false) }
      const back = rowsFromPilot(parts.map(a => ({ anon: f.anon, q: 'pripomba_napaka', a, v: '', at: 1 })))[0]!
      expect(back.text.endsWith('…')).toBe(true)
      expect(g.text.startsWith(back.text.slice(0, -1))).toBe(true)
      expect(back.meta.ua).toBe('Android · Chrome')
    }
  })
  it('vrsta naprave', async () => {
    const { shortUa } = await import('../src/data/feedback')
    expect(shortUa('Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1')).toBe('iOS · Safari')
    expect(shortUa('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0 Safari/537.36 Edg/129.0')).toBe('Windows · Edge')
    expect(shortUa('Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15')).toBe('Mac · Safari')
    expect(shortUa('Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/25.0 Chrome/121.0 Mobile Safari/537.36')).toBe('Android · Samsung')
    expect(shortUa('')).toBe('? · ?')
  })
  it('brez posnetka: poslano prek testnega programa, nič v vrsti', async () => {
    const f = route({ '/feedback': 404, '/pilot/answer': 200 })
    vi.stubGlobal('fetch', f)
    const fb = await makeFeedback({ kind: 'nejasno', text: 'Ne razumem forme', shot: null, route: 'danes' })
    expect(await sendFeedback(fb)).toBe('poslano')
    const pilot = f.mock.calls.filter(c => String(c[0]).endsWith('/pilot/answer')).map(c => JSON.parse(String(c[1]!.body)))
    expect(pilot).toHaveLength(1)
    expect(pilot[0]).toMatchObject({ anon: fb.anon, q: 'pripomba_nejasno', code: null })
    expect(pilot[0].a).toMatch(/\] Ne razumem forme ⟦/)
    expect(await getKV('feedback.queue')).toEqual([])
  })
  it('s posnetkom: besedilo takoj, posnetek čaka (ne šteje kot neposlano); ko strežnik ima /feedback, gre vse', async () => {
    let f = route({ '/feedback': 404, '/pilot/answer': 200 })
    vi.stubGlobal('fetch', f)
    const fb = await makeFeedback({ kind: 'napaka', text: 'Gumb ne dela', shot: 'data:image/jpeg;base64,AAAA', route: 'plan' })
    expect(await sendFeedback(fb)).toBe('poslano')
    expect(await queuedFeedback()).toBe(0)
    expect(((await getKV('feedback.queue')) as any[])[0].textSent).toBe(true)
    // strežnik še star: besedila ne pošlje znova
    f = route({ '/feedback': 404, '/pilot/answer': 200 }); vi.stubGlobal('fetch', f)
    await flushFeedback()
    expect(f.mock.calls.some(c => String(c[0]).endsWith('/pilot/answer'))).toBe(false)
    expect(((await getKV('feedback.queue')) as any[]).length).toBe(1)
    // posodobljen strežnik: cela pripomba s posnetkom
    f = route({ '/feedback': 200 }); vi.stubGlobal('fetch', f)
    expect(await flushFeedback()).toBe(1)
    expect(JSON.parse(String(f.mock.calls[0]![1]!.body)).shot).toBe('data:image/jpeg;base64,AAAA')
    expect(await getKV('feedback.queue')).toEqual([])
  })
  it('testni program tudi ne odgovori → vse v vrsto, znova kasneje', async () => {
    vi.stubGlobal('fetch', route({ '/feedback': 404, '/pilot/answer': 503 }))
    const fb = await makeFeedback({ kind: 'predlog', text: 'X', shot: null, route: 'plan' })
    expect(await sendFeedback(fb)).toBe('v vrsti')
    expect(await queuedFeedback()).toBe(1)
  })
})
