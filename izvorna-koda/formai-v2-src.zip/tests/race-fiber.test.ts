import { describe, it, expect } from 'vitest'
import { raceSoon, lowFiberDays, lowFiberRule } from '../src/domain/nutrition/race'
import { dayMealPlan, adjustToEaten } from '../src/domain/nutrition/dayplan'
import { dayDeficit } from '../src/domain/nutrition/energy'
import { FRANJA_2027 } from '../src/domain/training/planner'
import type { MealEntry, Profile } from '../src/domain/types'

const now = new Date().toISOString()
const P = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, restHr: 55, maxHr: 200, lthr: 184, ftp: 240, ftpDate: '2026-09-20',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, hoursPerWeek: 14, baseHours: null,
  strength: { on: false, equipment: 'home', phases: null }, strengthDays: 0, goal: 'dirka', deficit: 400, neat: 1.4,
  event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', onboardingDone: true, trainTime: 'popoldne', createdAt: now, updatedAt: now,
  races: [{ id: 'k', name: 'Kronometer Vodice', date: '2026-10-18', distanceKm: 40, prio: 'B' }], ...o,
})
const T = { kcal: 2800, proteinG: 140, carbsG: 380 }
const ride = { kind: 'kolo' as const, durationMin: 90, zone: 'Z2', role: 'lahka' as const, title: 'Z2' }
const HIGH_FIBER = /polnozrnat|ovseni|fižol|čičerika|zelenjava|oreški|sadje \(jabolko/

describe('malo vlaknin 2 dni pred tekmo', () => {
  it('okno: dan −2, −1 in dan tekme; ne dan −3 in ne dan po', () => {
    const p = P()
    expect(raceSoon(p, '2026-10-15')).toBeNull()
    expect(raceSoon(p, '2026-10-16')?.inDays).toBe(2)
    expect(raceSoon(p, '2026-10-17')?.inDays).toBe(1)
    expect(raceSoon(p, '2026-10-18')?.inDays).toBe(0)
    expect(raceSoon(p, '2026-10-19')).toBeNull()
    // tudi glavni cilj (Franja)
    expect(raceSoon(p, '2027-06-11')).toMatchObject({ inDays: 2, main: true })
  })
  it('obroki 2 dni prej so brez polnozrnatega, stročnic, zelenjave, oreškov; OH ostanejo', () => {
    const p = P()
    const normal = dayMealPlan(p, T, ride, {})
    const lf = dayMealPlan(p, T, ride, { race: raceSoon(p, '2026-10-16') })
    expect(normal.slots.some(s => HIGH_FIBER.test(s.example))).toBe(true)
    for (const s of lf.slots) expect(s.example).not.toMatch(HIGH_FIBER)
    expect(lf.tip).toMatch(/malo vlaknin/)
    expect(lf.slots.reduce((a, s) => a + s.carbsG, 0)).toBe(normal.slots.reduce((a, s) => a + s.carbsG, 0))
    // prilagoditev čez dan ohrani primere z malo vlakninami
    const meal: MealEntry = { id: 'z', date: '2026-10-16', slot: 'zajtrk', name: 'zajtrk', kcal: 900, source: 'manual', createdAt: now }
    for (const s of adjustToEaten(lf, [meal], T.kcal).slots) expect(s.example).not.toMatch(HIGH_FIBER)
  })
  it('na dan tekme malo vlaknin samo do starta, po tekmi normalno', () => {
    const p = P()
    const d = dayMealPlan(p, T, { ...ride, role: 'dirka' }, { race: raceSoon(p, '2026-10-18') })
    const i = d.slots.findIndex(s => s.key === 'obnova')
    expect(i).toBeGreaterThan(0)
    for (const s of d.slots.slice(0, i)) expect(s.lf).toBe(true)
    expect(d.slots[i]!.lf).toBeUndefined()
    expect(lowFiberRule(raceSoon(p, '2026-10-18')!)).toMatch(/Po tekmi jej normalno/)
  })
  it('druga tekma: dan prej in na dan tekme brez deficita, 2 dni prej deficit ostane', () => {
    const p = P()
    expect(dayDeficit(p, [], '2026-10-16').kcal).toBeGreaterThan(0)
    expect(dayDeficit(p, [], '2026-10-17')).toEqual({ kcal: 0, note: 'dan pred tekmo brez deficita' })
    expect(dayDeficit(p, [], '2026-10-18').kcal).toBe(0)
  })
  it('tedenski jedilnik dobi dneve z malo vlakninami', () => {
    expect(lowFiberDays(P(), '2026-10-12', '2026-10-18').map(x => x.date)).toEqual(['2026-10-16', '2026-10-17', '2026-10-18'])
    // tekma v ponedeljek naslednjega tedna: sobota in nedelja tega tedna
    expect(lowFiberDays(P({ races: [{ id: 'm', name: 'M', date: '2026-10-19', prio: 'C', distanceKm: null }] }), '2026-10-12', '2026-10-18').map(x => x.date)).toEqual(['2026-10-17', '2026-10-18'])
  })
})
