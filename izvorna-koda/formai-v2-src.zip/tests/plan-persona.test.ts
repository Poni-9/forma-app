import { describe, it, expect } from 'vitest'
import { coachReview, coachOptsFrom, planInputs, weekDiff, explicitDays } from '../src/domain/focus/coach'
import { composeWish, type Picks } from '../src/domain/focus/choices'
import { ruleProposal, ruleQuestions, wishSignals } from '../src/domain/focus/rules'
import { parseProposal } from '../src/domain/ai/focusAi'
import { scheduleWeek, weekWords } from '../src/domain/training/focusPlan'
import { trainingDays, isStrength, tailsOf, normalizeFocus } from '../src/domain/focus/model'
import { levelFrom, rangeIn, minutesRange, minutesIn, weekMinutesIn, daysRangeIn, explicitCounts, targetMix } from '../src/domain/focus/dose'
import type { Focus } from '../src/domain/types'

/**
 * PERSONE (Blaž, 13. 10.: »dober plan je najpomembnejša funkcija — za vsakogar, ne samo za fitnes«). Ista pot kot v
 * aplikaciji: izbire → vprašanja → predlog (pravila ali AI) → trener (coachReview) → razpored po dnevih.
 */
type QA = { id?: string; q: string; a: string }
function plan(picks: Picks, text: string, qa: QA[], o: { avail?: number[]; main?: 'kardio' | 'oboje' | 'moc'; push?: 'lahko' | 'zmerno' | 'trdo'; age?: number; ai?: unknown; current?: Focus } = {}) {
  const wish = composeWish(picks, text)
  const avail = o.avail ?? [0, 1, 2, 3, 4, 5, 6]
  const s = picks.delam || []
  const strength = s.includes('Fitnes') || s.includes('Vadba doma') || !!picks.cilj?.includes('Več mišic in moči')
  const cardio = s.some(x => x === 'Tek' || x === 'Kolo' || x === 'Hribi in hoja')
  const main = strength && cardio ? (o.main ?? 'oboje') : cardio ? 'kardio' : strength ? 'moc' : (o.main ?? 'oboje')
  const { opts, dose } = planInputs({ picks, wish, qa, age: o.age ?? 30, push: o.push ?? 'zmerno', main, avail })
  const noDays = [0, 1, 2, 3, 4, 5, 6].filter(d => !avail.includes(d))
  const base = o.ai ? parseProposal(o.ai, { wish, age: o.age ?? 30, prevOff: noDays })!.focus : ruleProposal(wish, qa, o.age ?? 30, { avail }).focus
  const rev = coachReview({ ...base, main }, opts)
  const f = rev.focus
  const open = [0, 1, 2, 3, 4, 5, 6].filter(d => !(f.offDays || []).includes(d))
  const order = scheduleWeek(f.sessions, open, f.preferDays, 7)
  const tails = tailsOf(f.sessions)
  const main_ = f.sessions.filter((_, i) => !tails.has(i))
  const sDays = order.map((k, d) => (k != null && isStrength(f.sessions[k]!) ? d : -1)).filter(d => d >= 0)
  return { f, why: rev.why, week: weekWords(f), dose, opts, n: trainingDays(f.sessions), s: main_.filter(isStrength).length, c: main_.filter(x => !isStrength(x)).length, sDays, order, qs: ruleQuestions(wish, { avail }).questions.map(q => q.id) }
}
const minGap = (days: number[]) => (days.length < 2 ? 7 : Math.min(...days.map((d, k) => (k + 1 < days.length ? days[k + 1]! - d : 7 - d + days[0]!))))

describe('odmerek iz besed', () => {
  it('razponi, čas, raven, izrecno število', () => {
    expect(rangeIn('3-4')).toEqual({ lo: 3, hi: 4 })
    expect(rangeIn('3 do 4')).toEqual({ lo: 3, hi: 4 })
    expect(minutesRange('60 do 75 minut')).toEqual({ lo: 60, hi: 75 })
    expect(minutesRange('1 h 30 min')).toEqual({ lo: 90, hi: 90 })
    expect(minutesRange('1 h')).toEqual({ lo: 60, hi: 60 })
    expect(minutesRange('1,5 ure')).toEqual({ lo: 90, hi: 90 })
    expect(minutesRange('45 min')).toEqual({ lo: 45, hi: 45 })
    expect(minutesIn('imam 60 do 75 minut za trening, 3-4 krat na teden')).toEqual({ lo: 60, hi: 75 })
    expect(minutesIn('3-4 krat na teden')).toBeNull()
    expect(daysRangeIn('3-4 krat na teden')).toEqual({ lo: 3, hi: 4 })
    expect(daysRangeIn('60 do 75 minut')).toBeNull()
    expect(levelFrom('Izkušnje: občasno.')).toBe(2)
    expect(levelFrom('Izkušnje: redno, več let.')).toBe(3)
    expect(levelFrom('', [{ q: 'Koliko zgibov narediš?', a: '5 do 8' }])).toBe(2)
    expect(levelFrom('naredim 12 zgibov')).toBe(3)
    expect(levelFrom('', [{ q: 'Koliko že treniraš?', a: 'Več kot 3 leta' }])).toBe(3)
    expect(levelFrom('', [{ q: 'Koliko km na teden pretečeš?', a: '10–25 km' }])).toBe(2)
    expect(levelFrom('Star sem 30 let in rad bi shujšal.')).toBeNull()
    expect(levelFrom('Rad delam: še ne vem.')).toBeNull()
    expect(explicitCounts('3x fitnes in dvakrat kolo, enkrat tek')).toEqual({ fitnes: 3, kolo: 2, tek: 1 })
    expect(explicitCounts('ponedeljek fitnes, trenažer')).toEqual({})
    expect(targetMix(4, { main: 'kardio', aims: [], strengthOk: true, cardioOk: true, level: 2 })).toEqual({ s: 1, c: 3 })
    expect(targetMix(4, { main: 'oboje', aims: [], strengthOk: true, cardioOk: true, level: 2 })).toEqual({ s: 2, c: 2 })
    expect(targetMix(5, { main: 'moc', aims: [], strengthOk: true, cardioOk: true, level: 2 })).toEqual({ s: 4, c: 1 })
    expect(targetMix(4, { main: 'kardio', aims: [], strengthOk: false, cardioOk: true, level: 2 })).toEqual({ s: 0, c: 4 })
  })
})

describe('persone', () => {
  it('Blaž: fitnes + kolo, bolj kardio, 3–4 dni, 60–75 min, 5–8 zgibov → raven 2, 4 vadbe, 1× moč + 3× kolo, vadbe ~70 min', () => {
    const r = plan({ cilj: ['Hitrejši in vzdržljivejši', 'Več mišic in moči'], delam: ['Fitnes', 'Kolo'] }, '', [
      { q: 'Koliko od teh 7 dni bi res treniral?', a: '3-4' }, { q: 'Koliko časa imaš za eno vadbo?', a: '60 do 75 minut' }, { q: 'Koliko zgibov narediš?', a: '5 do 8' },
    ], { main: 'kardio' })
    expect(r.f.level).toBe(2)
    expect(r.n).toBe(4)
    expect([r.s, r.c]).toEqual([1, 3])
    expect(r.f.sessions.filter(isStrength).every(x => x.min >= 65 && x.min <= 75)).toBe(true)
    expect(r.f.sessions.some(x => x.type === 'kolo' && x.cardio === 'dolgo')).toBe(true)
    expect(r.dose).toMatchObject({ level: 2, days: 4, range: { lo: 3, hi: 4 }, min: { lo: 60, hi: 75 }, mix: { s: 1, c: 3 } })
  })
  it('Blaž, oboje enako: 2× moč čim bolj narazen (ne pon + sre), 2× kolo vmes', () => {
    const r = plan({ cilj: ['Hitrejši in vzdržljivejši', 'Več mišic in moči'], delam: ['Fitnes', 'Kolo'], raven: ['Občasno'] }, '', [
      { q: 'Koliko od teh 7 dni bi res treniral?', a: '3-4' }, { q: 'Koliko časa imaš za eno vadbo?', a: '60 do 75 minut' },
    ], { main: 'oboje' })
    expect([r.s, r.c]).toEqual([2, 2])
    expect(minGap(r.sDays)).toBeGreaterThanOrEqual(3)
  })
  it('slab AI (brez ravni, 3 seje, 50 min) pri Blažu: trener popravi raven, doda 4. vadbo, podaljša na ~70 min', () => {
    const ai = { odgovor: 'Predlagam.', ime: 'Moč in kolo', sporti: ['fitnes', 'kolo'], cilji: ['misice', 'vzdrzljivost'], seje: [{ vrsta: 'fitnes', del: 'celo', min: 50 }, { vrsta: 'fitnes', del: 'celo', min: 50 }, { vrsta: 'kolo', kardio: 'lahko', min: 45 }] }
    const r = plan({ cilj: ['Hitrejši in vzdržljivejši', 'Več mišic in moči'], delam: ['Fitnes', 'Kolo'] }, '', [
      { q: 'Koliko od teh 7 dni bi res treniral?', a: '3-4' }, { q: 'Koliko časa imaš za eno vadbo?', a: '60 do 75 minut' }, { q: 'Koliko zgibov narediš?', a: '5 do 8' },
    ], { main: 'oboje', ai })
    expect(r.f.level).toBe(2)
    expect(r.n).toBe(4)
    expect([r.s, r.c]).toEqual([2, 2])
    // (v3.49 A21) cilj mišice: celo telo dvakrat (vsaka mišica 2× na teden), prej zgornji + spodnji
    expect(r.f.sessions.filter(isStrength).map(x => x.part)).toEqual(['celo', 'celo'])
    expect(r.f.sessions.every(x => x.min >= 60)).toBe(true)
    expect(minGap(r.sDays)).toBeGreaterThanOrEqual(3)
  })
  it('samo kolesar (redno, 4–5 dni, 6–8 h na teden): nobene moči, 5 voženj, 2 težki, dolga ob vikendu; vprašanja o kolesu, ne o fitnesu', () => {
    const r = plan({ cilj: ['Hitrejši in vzdržljivejši'], delam: ['Kolo'], raven: ['Redno, več let'], kolo: ['Zunaj po cesti', 'Merilnik moči'] }, '', [
      { id: 'dni', q: 'Koliko od teh 7 dni bi res treniral?', a: '4–5' }, { id: 'ure', q: 'Koliko ur na teden imaš za to?', a: '6–8 h' },
    ])
    expect(r.s).toBe(0)
    expect(r.n).toBe(5)
    expect(r.f.sessions.every(x => x.type === 'kolo')).toBe(true)
    expect(r.f.sessions.filter(x => x.cardio === 'intervali' || x.cardio === 'tempo').length).toBeLessThanOrEqual(2)
    const long = r.order.findIndex(k => k != null && r.f.sessions[k]!.cardio === 'dolgo')
    expect(long).toBeGreaterThanOrEqual(5)
    const tot = r.f.sessions.reduce((t, x) => t + x.min, 0)
    expect(tot).toBeGreaterThanOrEqual(5 * 60)
    expect(tot).toBeLessThanOrEqual(9 * 60)
    expect(r.qs).not.toContain('kje')
    expect(r.qs).not.toContain('poudarek')
    expect(r.qs).toContain('ure')
    expect(r.qs).toContain('kolocilj')
  })
  it('začetnik tekač (hujšanje, 3 dni, 45 min): 3 lahki teki ≤ 35 min, brez intervalov in brez moči', () => {
    const r = plan({ cilj: ['Boljša kondicija', 'Manj kilogramov'], delam: ['Tek'], raven: ['Začenjam'], tek: ['Začenjam s tekom'] }, '', [
      { q: 'Koliko od teh 7 dni bi res treniral?', a: '3' }, { q: 'Koliko časa imaš za eno vadbo?', a: '45 min' },
    ])
    expect(r.f.level).toBe(1)
    expect(r.n).toBe(3)
    expect(r.s).toBe(0)
    expect(r.f.sessions.every(x => x.type === 'tek' && x.cardio === 'lahko' && x.min <= 45)).toBe(true)
    expect(minGap(r.order.map((k, d) => (k != null ? d : -1)).filter(d => d >= 0))).toBeGreaterThanOrEqual(2)
  })
  it('začetnik v fitnesu (mišice, 3 dni, 1 h): 3× celo telo po 50 min, pon/sre/pet', () => {
    const r = plan({ cilj: ['Več mišic in moči'], delam: ['Fitnes'], raven: ['Začenjam'] }, '', [
      { q: 'Koliko od teh 7 dni bi res treniral?', a: '3' }, { q: 'Koliko časa imaš za eno vadbo?', a: '1 h' },
    ])
    expect(r.s).toBe(3)
    expect(r.c).toBe(0)
    expect(r.f.sessions.every(x => x.part === 'celo' && x.min === 50)).toBe(true)
    expect(minGap(r.sDays)).toBeGreaterThanOrEqual(2)
  })
  it('»še ne vem«, zdravje, 2 dni: ena moč + en kardio, ne dva dni zapored', () => {
    const r = plan({ cilj: ['Zdravje in počutje'], delam: ['Še ne vem'] }, '', [
      { q: 'Koliko od teh 7 dni bi res treniral?', a: '2' }, { q: 'Koliko časa imaš za eno vadbo?', a: '45 min' }, { q: 'Koliko že treniraš?', a: 'Začenjam' },
    ])
    expect(r.n).toBe(2)
    expect([r.s, r.c]).toEqual([1, 1])
    expect(minGap(r.order.map((k, d) => (k != null ? d : -1)).filter(d => d >= 0))).toBeGreaterThanOrEqual(3)
    expect(r.qs).toContain('kardio')   // »kaj ti je dostopno«
  })
  it('izkušen, vsak dan, ob vikendih daljše: 7 dni, en zelo lahek dan', () => {
    const r = plan({ cilj: ['Boljša kondicija', 'Več mišic in moči'], delam: ['Fitnes', 'Kolo', 'Hribi in hoja'], raven: ['Redno, več let'] }, 'Vsak dan, ob vikendih daljši trening.', [
      { q: 'Koliko časa imaš za eno vadbo?', a: '1 h' },
    ])
    expect(r.n).toBe(7)
    expect(r.f.sessions.some(x => !isStrength(x) && x.min <= 30)).toBe(true)
  })
  it('Blaževa pritožba (13. 10.): 2× fitnes + 1× tek ni več pon + sre fitnes in pet tek — fitnes narazen, med vadbami premor', () => {
    const ai = { odgovor: 'Predlagam.', ime: 'Moč in tek', raven: 2, sporti: ['fitnes', 'tek'], cilji: ['misice'], seje: [{ vrsta: 'fitnes', del: 'zgornji', min: 60 }, { vrsta: 'fitnes', del: 'spodnji', min: 60 }, { vrsta: 'tek', kardio: 'lahko', min: 40 }] }
    const r = plan({ cilj: ['Več mišic in moči'], delam: ['Fitnes', 'Tek'], raven: ['Občasno'] }, '', [{ q: 'Koliko od teh 7 dni bi res treniral?', a: '3' }], { main: 'oboje', ai })
    expect([r.s, r.c]).toEqual([2, 1])
    expect(minGap(r.sDays)).toBeGreaterThanOrEqual(3)
    // med vsemi vadbami vsaj dan premora (3 vadbe na 7 dni)
    expect(minGap(r.order.map((k, d) => (k != null ? d : -1)).filter(d => d >= 0))).toBeGreaterThanOrEqual(2)
  })
  it('izrecno »3x fitnes« ostane tudi pri »bolj kardio«', () => {
    const r = plan({ delam: ['Fitnes', 'Tek'], raven: ['Občasno'] }, 'Hočem 3x fitnes in tek.', [{ q: 'Koliko od teh 7 dni bi res treniral?', a: '4' }], { main: 'kardio' })
    expect(r.s).toBe(3)
    expect(r.c).toBe(1)
  })
  it('nov dogovor: sprememba glede na sedanji načrt je napisana', () => {
    const a = { sessions: [{ type: 'fitnes', part: 'celo', min: 60 }, { type: 'fitnes', part: 'celo', min: 60 }, { type: 'fitnes', part: 'celo', min: 60 }, { type: 'kolo', cardio: 'lahko', min: 60 }] } as Focus
    const b = { sessions: [{ type: 'fitnes', part: 'celo', min: 60 }, { type: 'kolo', cardio: 'lahko', min: 60 }, { type: 'kolo', cardio: 'lahko', min: 60 }, { type: 'kolo', cardio: 'dolgo', min: 120 }] } as Focus
    expect(weekDiff(a, b)).toBe('fitnes 3× → 1×, kolo 1× → 3×, skupaj 4 h → 5 h na teden')
    expect(weekDiff(a, a)).toBeNull()
  })
})

describe('pregled logike (13. 10.): lažni zadetki in robni primeri', () => {
  it('število dni: »3x fitnes« in »dva dni fitnes« niso dnevi; brez enote ni dni', () => {
    for (const t of ['Hočem 3x fitnes in 2x kolo', 'Daj dva dni fitnes, ostalo kolo', 'pet kilogramov manj', 'imam dva otroka', 'v 14 dni', '5x5 počep', '12x ponovitev', 'sedem kilogramov']) expect(explicitDays(t)).toBeNull()
    expect(explicitDays('raje 5 dni')).toBe(5)
    expect(explicitDays('4x na teden')).toBe(4)
    expect(explicitDays('petkrat na teden')).toBe(5)
    expect(explicitDays('tri dni')).toBe(3)
    expect(explicitDays('sedem dni')).toBe(7)
  })
  it('število po športu: cele besede', () => {
    expect(explicitCounts('Imam dve tekmi na mesec')).toEqual({})
    expect(explicitCounts('grem z en kolegom')).toEqual({})
    expect(explicitCounts('dva tečaja')).toEqual({})
    expect(explicitCounts('dva dni fitnes, ostalo kolo')).toEqual({ fitnes: 2 })
    expect(explicitCounts('3x fitnes in dvakrat kolo, enkrat tek')).toEqual({ fitnes: 3, kolo: 2, tek: 1 })
  })
  it('»3x fitnes in 2x kolo« brez dni = 5 vadb, kolo ostane', () => {
    const r = plan({ delam: ['Fitnes', 'Kolo'], raven: ['Občasno'] }, 'Hočem 3x fitnes in 2x kolo.', [])
    expect(r.n).toBe(5)
    expect([r.s, r.c]).toEqual([3, 2])
  })
  it('čas: del vadbe in tedenski čas nista čas na vadbo; »1 h 30 min« = 90', () => {
    expect(minutesIn('Dodaj 20 min teka po fitnesu')).toBeNull()
    expect(minutesIn('Na teden imam 4-5 h')).toBeNull()
    expect(weekMinutesIn('Na teden imam 4-5 h')).toEqual({ lo: 240, hi: 300 })
    expect(minutesIn('vadba naj traja 1 h 30 min')).toEqual({ lo: 90, hi: 90 })
    expect(minutesIn('imam uro in pol')).toEqual({ lo: 90, hi: 90 })
    expect(daysRangeIn('1-2 dni počitka')).toBeNull()
    const o = coachOptsFrom({ wish: 'x', qa: [{ q: 'Koliko časa imaš za eno vadbo?', a: '1 h' }], feedback: 'Dodaj 20 min teka po fitnesu', strengthOk: true, cardioOk: true })
    expect(o.minRange).toEqual({ lo: 60, hi: 60 })
    expect(o.raise).toBe(false)
    expect(o.asIs).toBe(true)
  })
  it('raven: želja po maratonu ni izkušnja; »rad bi 10 zgibov« ni; po dolgem premoru začetnik', () => {
    expect(levelFrom('Rad bi pretekel svoj prvi maraton.', [{ q: 'Koliko km na teden zdaj pretečeš?', a: 'Še ne tečem' }])).toBe(1)
    expect(levelFrom('Rad bi delal 10 zgibov.')).toBeNull()
    expect(levelFrom('Več let nisem nič treniral.')).toBe(1)
    expect(levelFrom('Tek: polmaraton ali več.')).toBe(3)
    expect(levelFrom('', [{ q: 'Koliko dni na teden lahko treniraš?', a: '4' }])).toBeNull()
  })
  it('signali: pomoč ni moč, tekočina ni tek, delo od doma ni vadba doma, ročke doma niso fitnes', () => {
    const a = wishSignals('Rad kolesarim. Ne rabim pomoči.')
    expect(a.aims).not.toContain('moc')
    expect(a.sports).toEqual(['kolo'])
    expect(wishSignals('Pijem dovolj tekočine, berem tekst, imam tečaj.').sports).toEqual([])
    expect(wishSignals('Delam od doma.').sports).toEqual([])
    expect(wishSignals('Rad delam: vadba doma. Ročke').sports).toEqual(['doma'])
    expect(wishSignals('imam otroka').muscles).toEqual([])
  })
  it('»raje lažje« ne krajša v vsakem krogu pogajanja', () => {
    const f = normalizeFocus({ wish: 'x', sports: ['fitnes', 'tek'], aims: ['kondicija'], level: 2, equipment: ['fitnes'], sessions: [{ type: 'fitnes', part: 'celo', min: 50 }, { type: 'tek', cardio: 'lahko', min: 40 }] })!
    const r1 = coachReview(f, { push: 'lahko', mix: { strengthOk: true, cardioOk: true } }).focus
    const r2 = coachReview(r1, { push: 'lahko' }).focus
    expect(r2.sessions.map(x => x.min)).toEqual(r1.sessions.map(x => x.min))
  })
  it('samo vadba doma + manj kilogramov + hoja: hoja ostane (vsaj 1 kardio)', () => {
    const r = plan({ cilj: ['Manj kilogramov'], delam: ['Vadba doma'], raven: ['Začenjam'] }, '', [{ q: 'Koliko od teh 7 dni bi res treniral?', a: '3' }, { q: 'Kaj ti je še dostopno?', a: 'Hoja ali pohod' }])
    expect(r.c).toBeGreaterThanOrEqual(1)
    expect(r.s).toBeGreaterThanOrEqual(1)
  })
  it('začetnik »vsak dan«: največ 5, razlaga se ujema s tednom', () => {
    const r = plan({ cilj: ['Boljša kondicija'], delam: ['Tek', 'Fitnes'], raven: ['Začenjam'] }, 'Vsak dan.', [])
    expect(r.n).toBe(5)
    expect(r.why.join(' ')).not.toMatch(/\b[67] vad/)
    expect(r.dose.days).toBe(5)
  })
  it('sedem dni: lahek dan ni edini intervalni trening; dan po dolgi seji ni intervalov', () => {
    const r = plan({ cilj: ['Hitrejši in vzdržljivejši'], delam: ['Tek'], raven: ['Redno, več let'] }, 'Vsak dan.', [{ q: 'Koliko časa imaš za eno vadbo?', a: '1 h' }])
    expect(r.n).toBe(7)
    expect(r.f.sessions.some(x => x.cardio === 'intervali' || x.cardio === 'tempo')).toBe(true)
    const days = r.order.map(k => (k != null ? r.f.sessions[k]! : null))
    for (let d = 0; d < 7; d++) { const a = days[d], b = days[(d + 1) % 7]; if (a?.cardio === 'dolgo' && b) expect(b.cardio === 'intervali' || b.cardio === 'tempo').toBe(false) }
    expect(r.why.join(' ')).not.toMatch(/\(\)|0 dni počitka/)
  })
  it('teki za začetnika so kratki (≤ 40 min), tudi ko ima uro časa', () => {
    const r = plan({ cilj: ['Boljša kondicija'], delam: ['Tek'], raven: ['Začenjam'] }, '', [{ q: 'Koliko od teh 7 dni bi res treniral?', a: '3-4' }, { q: 'Koliko časa imaš za eno vadbo?', a: '1 h' }])
    expect(r.f.sessions.every(x => x.min <= 40)).toBe(true)
  })
  it('polmaraton, 5 dni, izkušen: dva težka, dolga ob vikendu, dan po dolgi ni intervalov', () => {
    const r = plan({ cilj: ['Pripravljen na tekmo'], delam: ['Tek'], raven: ['Redno, več let'], tek: ['Polmaraton ali več'] }, '', [{ q: 'Koliko od teh 7 dni bi res treniral?', a: '5' }, { q: 'Koliko časa imaš za eno vadbo?', a: '1 h' }])
    expect(r.n).toBe(5)
    const days = r.order.map(k => (k != null ? r.f.sessions[k]! : null))
    const longDay = days.findIndex(x => x?.cardio === 'dolgo')
    expect(longDay).toBeGreaterThanOrEqual(5)
    const next = days[(longDay + 1) % 7]
    expect(next == null || next.cardio === 'lahko').toBe(true)
  })
})

describe('pregled logike, 2. krog', () => {
  it('čas + »4x na teden« v istem stavku je čas na vadbo; tedenski samo ob trajanju', () => {
    expect(minutesIn('Lahko 1 h, 4x na teden.')).toEqual({ lo: 60, hi: 60 })
    expect(minutesIn('Imam 45 min, 3x na teden')).toEqual({ lo: 45, hi: 45 })
    expect(minutesIn('Krajše vadbe, največ 45 min, 4x na teden')).toEqual({ lo: 45, hi: 45 })
    expect(weekMinutesIn('Lahko 1 h, 4x na teden.')).toBeNull()
    expect(weekMinutesIn('6 ur na teden')).toEqual({ lo: 360, hi: 360 })
    expect(minutesIn('Dolga vožnja naj bo 3 h')).toBeNull()
    expect(minutesIn('Tečem 10 km v 50 min')).toBeNull()
    expect(minutesIn('imam 1h30')).toEqual({ lo: 90, hi: 90 })
  })
  it('raven: »nisem še delal intervalov, tečem pa 5 let« je izkušen', () => {
    expect(levelFrom('', [{ q: 'Koliko že treniraš?', a: 'Nisem še delal intervalov, tečem pa 5 let.' }])).toBe(3)
    expect(levelFrom('', [{ q: 'Koliko že treniraš?', a: 'Več let nisem nič treniral.' }])).toBe(1)
  })
  it('šport najprej in glagoli: »fitnes 3x, kolo 2x«, »3x v fitnes in 2x na kolo«, »dvakrat na teden tečem, enkrat kolesarim«', () => {
    expect(explicitDays('Fitnes 3x, kolo 2x.')).toBeNull()
    expect(explicitCounts('Fitnes 3x, kolo 2x.')).toEqual({ fitnes: 3, kolo: 2 })
    expect(explicitDays('3x v fitnes in 2x na kolo')).toBeNull()
    expect(explicitCounts('3x v fitnes in 2x na kolo')).toEqual({ fitnes: 3, kolo: 2 })
    expect(explicitDays('Dvakrat na teden tečem, enkrat kolesarim')).toBeNull()
    expect(explicitCounts('Dvakrat na teden tečem, enkrat kolesarim')).toEqual({ tek: 2, kolo: 1 })
    expect(explicitDays('2 dni počitka')).toBeNull()
    expect(explicitDays('1 dan na teden prost')).toBeNull()
    expect(explicitDays('7x fitnes')).toBeNull()
  })
  it('odmerek za AI upošteva izrecno število; »tek po fitnesu« ni nov dan', () => {
    const r = plan({ delam: ['Fitnes', 'Kolo'], raven: ['Občasno'] }, 'Fitnes 3x, kolo 2x.', [])
    expect(r.dose.mix).toEqual({ s: 3, c: 2 })
    expect(r.n).toBe(5)
    const o = coachOptsFrom({ wish: '2x fitnes in 1x tek po fitnesu', qa: [], strengthOk: true, cardioOk: true })
    expect(o.wantDays).toBeNull()
  })
  it('signali: masaža, nogomet, »imam 100 kilogramov«', () => {
    expect(wishSignals('rad imam masažo').aims).not.toContain('misice')
    expect(wishSignals('igram nogomet').muscles).not.toContain('noge')
    expect(wishSignals('imam 100 kilogramov').aims).not.toContain('hujsanje')
    expect(wishSignals('rad bi 5 kilogramov manj').aims).toContain('hujsanje')
  })
  it('»raje lažje« s časom: razlaga pove pravo dolžino', () => {
    const r = plan({ cilj: ['Več mišic in moči'], delam: ['Fitnes'], raven: ['Občasno'] }, '', [{ q: 'Koliko od teh 7 dni bi res treniral?', a: '3' }, { q: 'Koliko časa imaš za eno vadbo?', a: '1 h' }], { push: 'lahko' })
    const m = r.f.sessions.filter(isStrength).map(x => x.min)
    expect(m.every(x => x === 50)).toBe(true)
    const w = r.why.join(' ')
    if (/podaljšal do ~/.test(w)) expect(w).toContain('~50 min')
    expect(w).toMatch(/manj naložen/)
  })
})

describe('Blažev posnetek (13. 10.): fitnes + kolo, tor in čet ne gre, AI brez ravni', () => {
  it('raven 2 iz vzgibov, 4 vadbe, kolo namesto teka, fitnes narazen, ~70 min', () => {
    const ai = { odgovor: 'Predlagam.', ime: 'Vitko, močno, v kondiciji', sporti: ['fitnes', 'tek'], cilji: ['definicija', 'hujsanje', 'misice', 'moc', 'kondicija'], seje: [{ vrsta: 'fitnes', del: 'potisk', min: 50 }, { vrsta: 'fitnes', del: 'poteg', min: 50 }, { vrsta: 'tek', kardio: 'lahko', min: 50 }] }
    const r = plan({ cilj: ['Boljša kondicija', 'Več mišic in moči'], delam: ['Fitnes', 'Kolo'], postava: ['Vitka in močna', 'Six pack'] }, '', [
      { q: 'Koliko treningov na teden realno treniraš?', a: '3-4' },
      { q: 'Koliko časa imaš zjutraj na voljo za posamezen trening v fitnesu?', a: '60 do 75 minut' },
      { q: 'Koliko čistih, pravilnih vzgibov zmoreš narediti v eni seriji ta trenutek?', a: '5 do 8 vzgibov' },
      { q: 'Kako in kje nameravaš vključiti kolesarjenje?', a: 'trenazer doma in zunaj kdaj ko lahko' },
      { q: 'Imaš kakšne poškodbe ali bolečine, zlasti v ramenih, komolcih ali zapestjih?', a: 'Brez poškodb' },
    ], { avail: [0, 2, 4, 5, 6], main: 'oboje', ai })
    expect(r.f.level).toBe(2)
    expect(r.n).toBe(4)
    expect(r.f.sessions.some(x => x.type === 'tek')).toBe(false)
    expect(r.f.sessions.filter(x => x.type === 'kolo').length).toBe(2)
    expect(minGap(r.sDays)).toBeGreaterThanOrEqual(3)
    expect(r.f.sessions.filter(isStrength).every(x => x.min === 70)).toBe(true)
    expect(r.order[1]).toBeNull(); expect(r.order[3]).toBeNull()
  })
  it('odgovor »3-4« se najde tudi pri drugače postavljenem vprašanju', () => {
    const o = coachOptsFrom({ wish: 'x', qa: [{ q: 'Kolikokrat bi šel?', a: '3-4' }, { q: 'Koliko časa imaš?', a: '1 h' }], strengthOk: true, cardioOk: true })
    expect(o.daysRange).toEqual({ lo: 3, hi: 4 })
    const o2 = coachOptsFrom({ wish: 'x', qa: [{ q: 'Kako pogosto lahko?', a: '3-4' }], strengthOk: true, cardioOk: true })
    expect(o2.daysRange).toEqual({ lo: 3, hi: 4 })
  })
})
