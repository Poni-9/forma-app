// v3.51 PREHRANA — ocena brez AI (meso, sestavljene jedi, juhe, napitki, količine, ulomki), obrok po uri (pozen zajtrk,
// zgodnje kosilo), premor »bolan«, litri goriva, kosilo pred vožnjo, recept za pozneje, razlaga cilja pri varni meji,
// kratka tekma, voda v načrtu, gorivo po teku, ženske oblike, opozorila, mejnik teže, pravila za AI, beljakovine
// mladoletnega, vpis goriva za nazaj, tehtanje (pas, pretekli dan), pohod, ✓ z ure, decimalke, Enter, »Nad varno mejo«.
import 'fake-indexeddb/auto'
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'prehrana', params: {} as Record<string, string> }, added: [] as any[], toasts: [] as string[], saved: [] as any[], removed: [] as string[] }))
vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
vi.mock('@/state/store', async (orig) => ({
  ...(await orig<typeof import('../src/state/store')>()),
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  addMeal: async (m: unknown) => { S.added.push(m) },
  removeMeal: async (id: string) => { S.removed.push(id) },
  saveCheckin: async (c: unknown) => { S.saved.push(c) },
  setPlanDone: async () => undefined,
  toast: (m: string) => { S.toasts.push(m) },
}))
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => S.route, subscribeRoute: () => () => undefined }))

import * as repo from '../src/data/repo'
import { Prehrana, targetRows, logTimeOf } from '@/screens/Prehrana'
import { WeighSheet } from '@/ui/WeighSheet'
import { FuelLogSheet } from '@/ui/FuelLog'
import { FuelTimeline } from '@/ui/FuelTimeline'
import { estimateMeal, LF } from '../src/domain/nutrition/localMeal'
import { rideFuel, fuelEntry, mealScheduleOf, l1 } from '../src/domain/nutrition/dayplan'
import { dayMealsOf, slotFor } from '../src/domain/nutrition/daymeals'
import { dailyTarget, fueling, proteinGkgOf, bmr, NUTRITION_RULES, MAX_DEFICIT, MIN_ABS_M, MIN_ABS_Z } from '../src/domain/nutrition/energy'
import { fuelGph, SHORT_RACE_FUEL } from '../src/domain/nutrition/fuelrate'
import { alerts } from '../src/domain/alerts'
import { addDays } from '../src/domain/training/load'
import { FRANJA_2027 } from '../src/domain/training/planner'
import type { Activity, MealEntry, PlanDay, Profile } from '../src/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const NOW = '2026-10-01T08:00:00.000Z'
const TODAY = '2026-10-17'   // sobota
const P = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, restHr: 55, maxHr: 200, lthr: 184, ftp: 240, ftpDate: '2026-09-20',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, hoursPerWeek: 14, baseHours: null,
  strength: { on: false, equipment: 'home', phases: null }, strengthDays: 0, goal: 'dirka', deficit: 400, neat: 1.4,
  event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', onboardingDone: true, trainTime: 'popoldne', createdAt: NOW, updatedAt: NOW,
  races: [], ...o,
} as Profile)
const planDay = (date: string, min: number, o: Partial<PlanDay> = {}): PlanDay => ({ id: 'r' + date + min, date, kind: 'kolo', title: 'Dolga Z2', desc: '', durationMin: min, zone: 'Z2', role: 'dolga', source: 'rules', createdAt: NOW, updatedAt: NOW, ...o })
const meal = (date: string, slot: MealEntry['slot'], kcal: number, o: Partial<MealEntry> = {}): MealEntry => ({ id: `${date}-${slot}-${kcal}-${o.name || ''}-${o.time || ''}`, date, slot, name: o.name || slot, kcal, source: 'manual', createdAt: NOW, time: o.time ?? null, ...o })
const act0 = (date: string, sport: Activity['sport'], min: number, at: string, o: Partial<Activity> = {}): Activity => ({ id: `a-${date}-${sport}-${at}`, source: 'fit', sport, date, start: new Date(`${date}T${at}:00`).toISOString(), durationMin: min, ...o } as Activity)

/* ---------- ocena brez AI ---------- */

// [opis, realno kcal od, do] — korpus revizorja (audit51/D/zz-d-meal.test.ts), tipične slovenske porcije
const C: [string, number, number][] = [
  ['2 jajci in kos kruha', 220, 300], ['ovseni kosmiči 60 g z mlekom in banano', 400, 500], ['kava z mlekom in rogljiček', 230, 330],
  ['jogurt z müslijem', 300, 400], ['skuta z jagodami', 250, 330], ['piščančji zrezek s krompirjem in solato', 400, 600],
  ['špageti bolonjeze', 550, 800], ['golaž s polento', 550, 750], ['jota', 280, 450], ['pica', 750, 1000], ['burek s sirom', 650, 850],
  ['kebab', 550, 800], ['hamburger in pomfri', 850, 1100], ['dunajski zrezek s pomfrijem', 800, 1100], ['čevapčiči z ajvarjem in lepinjo', 650, 900],
  ['kranjska klobasa z gorčico in kruhom', 500, 750], ['ričet', 350, 500], ['zelenjavna juha', 100, 200], ['goveja juha z rezanci', 180, 320],
  ['palačinke z nutello', 400, 550], ['2 palačinki z marmelado', 330, 450], ['kos potice', 250, 350], ['krof', 250, 330],
  ['sendvič s šunko in sirom', 400, 550], ['toast s šunko in sirom', 300, 420], ['solata s tuno in jajcem', 230, 350],
  ['riž s piščancem in zelenjavo', 450, 650], ['losos s krompirjem', 450, 600], ['svinjska pečenka s pire krompirjem', 600, 850],
  ['sarma', 400, 600], ['lazanja', 550, 750], ['kosmiči z mlekom', 300, 400], ['pol čokolade', 250, 300], ['tablica čokolade', 500, 560],
  ['2 piva', 380, 460], ['kozarec vina', 120, 170], ['jabolko in banana', 170, 200], ['sadna solata', 100, 180], ['2 jajci na oko s slanino', 300, 420],
  ['omleta s sirom', 280, 380], ['kruh z maslom in marmelado', 280, 380], ['2 kosa kruha z nutelo', 350, 450], ['proteinski šejk', 120, 220],
  ['beljakovinski napitek z mlekom', 220, 320], ['proteinska ploščica', 180, 250], ['smoothie z banano in jagodami', 180, 280],
  ['ajdovi žganci z ocvirki', 400, 600], ['ješprenj z zelenjavo', 300, 450], ['tortelini s smetano', 500, 700], ['svinjski zrezek in riž', 550, 750],
  ['postrv s krompirjem', 400, 550], ['200 g kuhanega riža', 230, 280], ['1 l mleka', 450, 500], ['kakav', 150, 220], ['polovica pice', 400, 500],
  ['dva kosa pice in kokakola', 650, 800], ['mlečni griz', 200, 320], ['rezina lubenice', 30, 70], ['pest oreškov', 150, 220],
  ['pašta fižol', 400, 600], ['musaka', 450, 650], ['jabolčni zavitek', 250, 350], ['tri rezine pice', 550, 750], ['skodelica čaja z medom', 30, 70],
  ['lešnikov namaz na kruhu', 280, 400], ['grški jogurt 200 g in med', 180, 250], ['jogurt med malico', 90, 140],
]
const kcalOf = (d: string) => estimateMeal(d)?.kcal ?? null
const amt = (d: string, key: string) => estimateMeal(d)!.items.filter(i => i.key === key).reduce((s, i) => s + i.amount, 0)

describe('D04, D15–D19, D21, D28–D33, D45 — ocena brez AI na 67 tipičnih opisih', () => {
  it('v ±20 % realne porcije: 67 od 67 (v3.50: 41 od 67)', () => {
    const out = C.filter(([d, lo, hi]) => { const k = kcalOf(d); return !(k != null && k >= lo * 0.8 && k <= hi * 1.2) }).map(([d]) => `${d}: ${kcalOf(d)}`)
    expect(out).toEqual([])
    expect(C.length).toBe(67)
  })
  it('D04 meso: dunajski zrezek, pečenka, čevapčiči, kranjska, postrv, slanina — pravo živilo, ne »Ne poznam«', () => {
    expect(estimateMeal('dunajski zrezek s pomfrijem')!.items.map(i => i.key)).toEqual(['paniran', 'pomfri'])
    expect(estimateMeal('dunajski zrezek s pomfrijem')!.unknown).toEqual([])
    expect(estimateMeal('svinjska pečenka')!.items[0]!.key).toBe('svinjina')
    expect(estimateMeal('čevapčiči')!.items[0]).toMatchObject({ key: 'cevapcici', amount: 200 })
    expect(estimateMeal('10 čevapčičev')!.items[0]!.amount).toBe(250)
    expect(estimateMeal('kranjska klobasa')!.items[0]).toMatchObject({ key: 'klobasa', amount: 180 })
    expect(estimateMeal('postrv')!.items[0]!.key).toBe('riba')
    expect(estimateMeal('goveji zrezek')!.items[0]!.key).toBe('govedina')
    expect(estimateMeal('piščančji zrezek')!.items[0]!.key).toBe('piscanec')
    expect(estimateMeal('ocvrt piščanec')!.items[0]!.key).toBe('paniran')
  })
  it('D15 sestavljene jedi: bolonjeze, lazanja, sarma, musaka, tortelini, rižota', () => {
    for (const [d, lo, hi] of [['špageti bolonjeze', 550, 800], ['lazanja', 550, 750], ['sarma', 400, 600], ['musaka', 450, 650], ['tortelini s smetano', 500, 700], ['rižota z gobami', 350, 550]] as const) {
      const k = kcalOf(d)!; expect(k, d).toBeGreaterThanOrEqual(lo * 0.8); expect(k, d).toBeLessThanOrEqual(hi * 1.2)
    }
  })
  it('D16 neznana beseda ob znanem živilu ne izgine tiho; ocvrto in praženo ima olje', () => {
    expect(estimateMeal('špageti carbonara')!.unknown).toEqual(['carbonara'])
    expect(estimateMeal('ovseni kosmiči 70 g, jogurt 200 g in banana')!.unknown).toEqual([])
    expect(estimateMeal('grški jogurt 200 g in med')!.unknown).toEqual([])
    expect(estimateMeal('čokoladno mleko 0,5 l')!.unknown).toEqual([])
    expect(estimateMeal('pražen krompir')!.items.map(i => i.key)).toEqual(['krompir', 'olje'])
    expect(estimateMeal('lešnikov namaz na kruhu')!.items.map(i => i.key)).toEqual(['namaz', 'kruh'])
  })
  it('D17 beljakovinski napitki in ploščice: ne null, B ≥ 20 g', () => {
    for (const d of ['proteinski šejk', 'beljakovinski napitek z mlekom', 'proteinska ploščica']) expect(estimateMeal(d)!.p, d).toBeGreaterThanOrEqual(20)
  })
  it('D18 »pol kg krompirja« = 500 g; D21 »polovica pice« in »1/2 pice« = pol pice', () => {
    expect(amt('pol kg krompirja', 'krompir')).toBe(500)
    expect(amt('pol kile krompirja', 'krompir')).toBe(500)
    expect(kcalOf('polovica pice')).toBe(438)
    expect(kcalOf('1/2 pice')).toBe(438)
    expect(kcalOf('½ pice')).toBe(438)
  })
  it('D19 pravo živilo: lubenica, griz, sadna solata, piščančja juha', () => {
    expect(estimateMeal('rezina lubenice')!.items[0]!.key).toBe('lubenica')
    expect(estimateMeal('mlečni griz')!.items[0]!.key).toBe('griz')
    expect(estimateMeal('sadna solata')!.items[0]!.key).toBe('sadje')
    expect(estimateMeal('piščančja juha')!.items[0]!.key).toBe('juha')
    expect(estimateMeal('pašta fižol')!.items[0]!.key).toBe('minestra')
  })
  it('D28 juhe; D29 čokolada; D30 »2x« in »šest«; D31 gorivo; D32 nutela, kakav, torta, sladoled; D33 rogljiček, krof, vino; D45 kivi', () => {
    expect(kcalOf('zelenjavna juha')).toBe(120)
    expect(estimateMeal('goveja juha z rezanci')!.items.map(i => i.key)).toEqual(['juha'])
    expect(kcalOf('mineštra')).toBe(400)
    expect(amt('pol čokolade', 'cokolada')).toBe(50)
    expect(amt('tablica čokolade', 'cokolada')).toBe(100)
    expect(amt('2x jogurt', 'jogurt')).toBe(300)
    expect(amt('jogurt 2x', 'jogurt')).toBe(300)
    expect(amt('šest jajc', 'jajce')).toBe(6)
    expect(kcalOf('gel')).toBe(100)
    expect(kcalOf('energijska ploščica')).toBe(200)
    expect(kcalOf('izotonik 0,5 l')).toBe(120)
    for (const d of ['2 kosa kruha z nutelo', 'kakav', 'torta', 'sladoled']) expect(estimateMeal(d), d).not.toBeNull()
    expect(estimateMeal('2 kosa kruha z nutelo')!.unknown).toEqual([])
    expect(amt('2 kepici sladoleda', 'sladoled')).toBe(120)
    expect(amt('rogljiček', 'pecivo')).toBe(60)
    expect(amt('krof', 'pecivo')).toBe(75)
    expect(amt('kozarec vina', 'vino')).toBe(150)
    expect(amt('2 kivija', 'sadje')).toBe(150)
    expect(estimateMeal('pomaranča in 2 kivija')!.items.map(i => i.name)).toEqual(['pomaranča', 'kivi'])
  })
  it('nova živila: kalorije in makri se ujemajo (4·B + 4·OH + 9·M v ±5 %)', () => {
    for (const [k, f] of Object.entries(LF)) expect(Math.abs(f.kcal - (4 * f.p + 4 * f.c + 9 * f.f)), k).toBeLessThanOrEqual(Math.max(1, f.kcal * 0.05))
  })
})

/* ---------- obrok po uri, cilj, gorivo (domena) ---------- */

describe('D01, D35 — obrok po uri', () => {
  const p = P({ deficit: 0 })
  const target = dailyTarget(p, [], [], TODAY, { today: TODAY, hour: 10 })!
  const dp = dayMealsOf({ p, target, plan: [], activities: [], meals: [], recentMeals: [], weather: null, day: TODAY, today: TODAY, hour: 10 }).dp
  it('D01: ob 10:40 brez zajtrka je zajtrk; z vpisanim zajtrkom malica', () => {
    expect(slotFor('10:40', dp, [])).toBe('zajtrk')
    expect(slotFor('10:40', dp, [{ slot: 'zajtrk' }])).toBe('malica')
    expect(slotFor('11:10', dp, [])).toBe('malica')
  })
  it('D35: ob 11:50 po zajtrku in brez kosila je kosilo', () => {
    expect(slotFor('11:50', dp, [{ slot: 'zajtrk' }])).toBe('kosilo')
    expect(slotFor('11:50', dp, [{ slot: 'zajtrk' }, { slot: 'kosilo' }])).toBe('malica')
    expect(slotFor('11:10', dp, [{ slot: 'zajtrk' }])).toBe('malica')
  })
})

describe('D03, D14, D22, varovalke — dnevni cilj', () => {
  it('D03: premor z razlogom »bolan« je dan brez deficita (kot »Bolan sem«)', () => {
    const p = P({ weekPause: { from: TODAY, to: addDays(TODAY, 3), mode: 'vse', reason: 'bolan' } })
    const t = dailyTarget(p, [], [], TODAY, { today: TODAY, hour: 9 })!
    expect(t.deficit).toBe(0)
    expect(t.deficitNote).toBe('bolezen')
    const t2 = dailyTarget(P({ weekPause: { from: TODAY, to: addDays(TODAY, 3), mode: 'vse', reason: 'potovanje' } }), [], [], TODAY, { today: TODAY, hour: 9 })!
    expect(t2.deficit).toBeGreaterThan(0)
  })
  it('D14: na zdravem mejniku (−10 %) razlog »prvi mejnik«, ne »najboljša teža«', () => {
    const p = P({ goal: 'shujsati', event: null, deficit: 400, weightKg: 70, goalStart: { date: '2026-08-01', ftp: null, weightKg: 78 } })
    const t = dailyTarget(p, [], [], TODAY, { today: TODAY, hour: 9 })!
    expect(t.deficit).toBe(0)
    expect(t.deficitNote).toMatch(/prvi mejnik teže je dosežen/)
  })
  it('D22: mladoletni s ciljem »shujšati« 1,7 g beljakovin na kg (brez deficita), odrasli 2,0', () => {
    expect(proteinGkgOf(P({ age: 16, goal: 'shujsati', deficit: 0 }), TODAY)).toBe(1.7)
    expect(proteinGkgOf(P({ age: 30, goal: 'shujsati', deficit: 0 }), TODAY)).toBe(2)
  })
  it('varovalke nedotaknjene: nikoli pod BMR in 1500/1200, deficit največ 750, mladoletni brez deficita', () => {
    const w = P({ sex: 'z', weightKg: 48, heightCm: 158, age: 30, deficit: 2000, neat: 1.2 })
    const tw = dailyTarget(w, [], [], TODAY, { today: TODAY, hour: 9 })!
    expect(tw.kcal).toBeGreaterThanOrEqual(Math.max(MIN_ABS_Z, bmr(w)!))
    expect(tw.deficit).toBeLessThanOrEqual(MAX_DEFICIT)
    const m = P({ weightKg: 60, heightCm: 168, deficit: 750, neat: 1.2 })
    expect(dailyTarget(m, [], [], TODAY, { today: TODAY, hour: 9 })!.kcal).toBeGreaterThanOrEqual(Math.max(MIN_ABS_M, bmr(m)!))
    const minor = dailyTarget(P({ age: 15, goal: 'shujsati', deficit: 500 }), [], [], TODAY, { today: TODAY, hour: 9 })!
    expect(minor.deficit).toBe(0)
    expect(minor.kcal).toBeGreaterThanOrEqual(minor.maintenance)
  })
})

describe('D08 — razlaga cilja se sešteje tudi pri varni meji', () => {
  const sum = (rows: { label: string; value: string }[]) => rows.slice(0, -1).reduce((s, r) => s + (r.value.startsWith('−') ? -1 : 1) * +r.value.replace(/[^\d]/g, ''), 0)
  const goal = (rows: { value: string }[]) => +rows[rows.length - 1]!.value.replace(/[^\d]/g, '')
  it('ženska 58 kg, deficit 750: vrstica »Dvig na varno mejo«, deficit »danes velja«', () => {
    const p = P({ sex: 'z', weightKg: 58, heightCm: 163, age: 30, deficit: 750, goal: 'shujsati', event: null, neat: 1.2 })
    const t = dailyTarget(p, [], [], TODAY, { today: TODAY, hour: 9 })!
    expect(t.clampedToFloor).toBe(true)
    const rows = targetRows(t, p)
    expect(rows.map(r => r.label)).toContain('Dvig na varno mejo')
    expect(sum(rows)).toBe(goal(rows))
    expect(rows.find(r => r.label === 'Deficit')!.note).toMatch(/^danes velja −[\d\u00A0\u202F ]+ \(varna meja\)$/)
  })
  it('ročni cilj pod varno mejo na dan vožnje: vrstice se seštejejo', () => {
    const p = P({ kcalOverride: 1400 })
    const t = dailyTarget(p, [], [planDay(TODAY, 180)], TODAY, { today: TODAY, hour: 9 })!
    expect(t.clampedToFloor).toBe(true)
    const rows = targetRows(t, p)
    expect(sum(rows)).toBe(goal(rows))
  })
})

describe('D05, D09, D10, D20 — gorivo', () => {
  it('D05: ista vožnja, isti litri v besedilu in na časovnici', async () => {
    const rf = rideFuel(planDay(TODAY, 180), null, { tempC: 20 })!
    const L = l1(rf.fluidMl)
    expect(rf.schedule).toContain(`~${L} l`)
    await render(<FuelTimeline rf={rf} minutes={180} />)
    expect(text()).toContain(`~${L} l`)
    expect(div.querySelector('.fuel-tl')!.getAttribute('aria-label')).toContain(`~${L} l`)
  })
  it('D09: kronometer 30 min — 0 g/h in isti stavek v Gorivu in »Med«', () => {
    const d = planDay(TODAY, 30, { role: 'dirka', zone: 'Z5', title: 'Kronometer' })
    expect(fuelGph(d)).toBe(0)
    expect(rideFuel(d)!.schedule).toBe(SHORT_RACE_FUEL)
    expect(fueling(d, P())!.during).toBe(SHORT_RACE_FUEL)
  })
  it('D10: vožnja 90 min pri 22 °C — za vpis predlagano toliko kot na kartici (ne 1,25 l)', () => {
    const rf = rideFuel(planDay(TODAY, 90, { role: 'lahka', title: 'Z2' }), null, { tempC: 22 })!
    const planMl = fuelEntry(rf, {}, 'Z2').planMl
    expect(planMl).toBeGreaterThanOrEqual(750)
    expect(planMl).toBeLessThanOrEqual(900)
  })
  it('D20: pravila za AI imajo številke iz tabele Goriva', () => {
    expect(NUTRITION_RULES).not.toMatch(/40–60 g|60–80 g/)
    expect(NUTRITION_RULES).toContain(`Z2 od 90 min ~${fuelGph({ kind: 'kolo', durationMin: 90, zone: 'Z2' })} g`)
    expect(NUTRITION_RULES).toContain('dirka ~70–85 g')
  })
})

describe('D06, D36 — razpored obrokov', () => {
  it('D06: vožnja z ure ob 14:00 — kosilo ob 11:30 ni »po vožnji«', () => {
    const p = P()
    const plan = [planDay(TODAY, 120)]
    const activities = [act0(TODAY, 'kolo', 120, '14:00')]
    const target = dailyTarget(p, activities, plan, TODAY, { today: TODAY, hour: 17 })!
    const dp = dayMealsOf({ p, target, plan, activities, meals: [meal(TODAY, 'kosilo', 900, { time: '11:30' })], recentMeals: [], weather: null, day: TODAY, today: TODAY, hour: 17 }).dp
    const k = dp.slots.find(s => s.key === 'kosilo')!
    expect(k.when).toBe('pred vožnjo')
    expect(dp.slots.filter(s => /po vožnji/.test(`${s.label} ${s.when}`)).map(s => s.key)).toEqual(['obnova'])
  })
  it('D36: pohod 3 h — »pred pohodom / po pohodu«, ne »vadba«', () => {
    const d = { kind: 'pohod' as const, durationMin: 180, zone: null }
    const sch = mealScheduleOf({ trainTime: 'popoldne' }, d)
    const all = sch.plan.map(s => `${s[1]} ${s[2]}`).join(' | ')
    expect(all).toMatch(/pred pohodom/)
    expect(all).toMatch(/Po pohodu/)
    expect(all).not.toMatch(/vadb/)
    const f = fueling(d as never, P())!
    expect(`${f.before} ${f.after}`).not.toMatch(/vadb/)
    expect(f.before).toMatch(/pred pohodom/)
  })
})

describe('D13, D23, D34 — opozorila', () => {
  const days = (n: number, f: (d: string) => MealEntry[]) => Array.from({ length: n }, (_, i) => f(addDays(TODAY, -1 - i))).flat()
  it('D34: »2 dneva zapored«', () => {
    const recentMeals = days(2, d => [meal(d, 'zajtrk', 200, { time: '07:00' }), meal(d, 'kosilo', 200, { time: '13:00' }), meal(d, 'vecerja', 200, { time: '19:00' })])
    const a = alerts({ profile: P(), activities: [], plan: [], checkins: [], recentMeals, today: TODAY })
    expect(a.map(x => x.text).join(' ')).toMatch(/Vnos 2 dneva zapored pod varno mejo/)
  })
  it('D13 + D23: mladoletni brez deficita — beljakovine in spanec brez »deficita« in »maščobe«', () => {
    const p = P({ age: 15, deficit: 0, goal: 'dirka', ftpDate: TODAY })
    const recentMeals = days(3, d => [meal(d, 'zajtrk', 800, { time: '07:00', proteinG: 5 }), meal(d, 'kosilo', 900, { time: '13:00', proteinG: 5 }), meal(d, 'vecerja', 900, { time: '19:00', proteinG: 5 })])
    const checkins = [1, 2, 3].map(i => ({ date: addDays(TODAY, -i), sleepH: 6 })) as never
    const t = alerts({ profile: p, activities: [], plan: [], checkins, recentMeals, today: TODAY }).map(x => x.text)
    const prot = t.find(x => /Beljakovine pod ciljem/.test(x))!, sleep = t.find(x => /Spanec/.test(x))!
    expect(prot).toMatch(/obnova počasnejša/)
    expect(prot).not.toMatch(/deficit/)
    expect(sleep).not.toMatch(/maščob/)
    expect(sleep).toMatch(/8–10 h/)
  })
  it('odrasli v deficitu: spanec omeni izgubo maščobe, beljakovine »v deficitu«', () => {
    const recentMeals = days(3, d => [meal(d, 'zajtrk', 800, { time: '07:00', proteinG: 5 }), meal(d, 'kosilo', 900, { time: '13:00', proteinG: 5 }), meal(d, 'vecerja', 900, { time: '19:00', proteinG: 5 })])
    const checkins = [1, 2, 3].map(i => ({ date: addDays(TODAY, -i), sleepH: 6 })) as never
    const t = alerts({ profile: P({ ftpDate: TODAY }), activities: [], plan: [], checkins, recentMeals, today: TODAY }).map(x => x.text).join(' ')
    expect(t).toMatch(/v deficitu gre mišica/)
    expect(t).toMatch(/7–9 h, sicer trpi obnova in izguba maščobe/)
  })
})

describe('D07 — recept »pojedeno« za obrok, ki je šele pred tabo', () => {
  it('večerja ob 10:40 dobi 19:00; kosilo ob 12:30 zdaj; pretekli dan tipična ura', () => {
    expect(logTimeOf('vecerja', '10:40')).toBe('19:00')
    expect(logTimeOf('kosilo', '12:30')).toBe('12:30')
    expect(logTimeOf('zajtrk', '13:00')).toBe('13:00')
    expect(logTimeOf('vecerja', null)).toBe('19:00')
  })
})

/* ---------- zaslon ---------- */

let div: HTMLDivElement, root: Root
async function render(el: React.ReactElement) {
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root.render(el) })
  return text()
}
const text = () => (document.body.textContent || '').replace(/[\u00A0\u202F]/g, ' ')
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(b.textContent || '') || re.test(b.getAttribute('aria-label') || ''))
async function click(el: Element | undefined | null) { expect(el).toBeTruthy(); await act(async () => { (el as HTMLElement).click(); await new Promise(r => setTimeout(r, 0)) }) }
async function typeIn(el: Element | null, v: string) {
  expect(el).toBeTruthy()
  const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype
  await act(async () => { Object.getOwnPropertyDescriptor(proto, 'value')!.set!.call(el, v); el!.dispatchEvent(new Event('input', { bubbles: true })) })
}
const planCard = () => [...document.querySelectorAll('.card')].find(c => /po načrtu/.test(c.querySelector('h2')?.textContent || ''))?.textContent?.replace(/[\u00A0\u202F]/g, ' ') || ''
afterEach(async () => {
  await act(async () => root?.unmount()); div?.remove(); vi.useRealTimers()
  S.added.length = 0; S.toasts.length = 0; S.saved.length = 0; S.removed.length = 0; S.route = { name: 'prehrana', params: {} }
  try { localStorage.clear() } catch { /* */ }
})
function setState(o: { meals?: MealEntry[]; plan?: PlanDay[]; profile?: Profile; time?: string; checkins?: any[]; activities?: Activity[]; checkinToday?: any } = {}) {
  vi.useFakeTimers({ toFake: ['Date'] })
  vi.setSystemTime(new Date(`${TODAY}T${o.time || '08:30'}:00`))
  const meals = o.meals || []
  S.state = { ready: true, settings: repo.defaultSettings(), changes: [], toast: null, sync: { state: 'off' }, authKnown: true, pro: false, wellness: null, checkinToday: o.checkinToday ?? null, today: TODAY, profile: o.profile || P(), plan: o.plan || [], activities: o.activities || [], mealsToday: meals, recentMeals: meals, checkins: o.checkins || [], weather: null, user: null }
}

describe('Prehrana — obrok, gumb in list (D02, D38, D40, D44, D43)', () => {
  it('D02: ob 10:40 brez vpisov gumb »Dodaj zajtrk« in list z izbranim zajtrkom', async () => {
    setState({ time: '10:40', profile: P({ deficit: 0 }) })
    const t = await render(<Prehrana />)
    expect(t).toMatch(/Dodaj zajtrk/)
    expect(t).not.toMatch(/Dodaj malico/)
    expect(planCard()).toMatch(/Zajtrk/)
    await click(btn(/Dodaj zajtrk/))
    expect(document.querySelector('.chip.on[aria-pressed="true"]')?.textContent).toBe('Zajtrk')
  })
  it('D43: čip »Nad varno mejo« namesto »Varno«', async () => {
    setState({ time: '09:00' })
    const t = await render(<Prehrana />)
    expect(t).toMatch(/Nad varno mejo/)
  })
  it('D40 + D44: beljakovine »12,5« z vejico, Enter v kalorijah shrani', async () => {
    setState({ time: '12:30' })
    await render(<Prehrana />)
    await click(btn(/^Dodaj /))
    await typeIn(document.querySelector('#meal-name'), 'skyr')
    await typeIn(document.querySelector('#meal-kcal'), '120')
    await typeIn(document.querySelector('#meal-prot'), '12,5')
    expect((document.querySelector('#meal-prot') as HTMLInputElement).inputMode).toBe('decimal')
    await act(async () => { document.querySelector('#meal-kcal')!.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true })); await new Promise(r => setTimeout(r, 0)) })
    expect(S.added).toHaveLength(1)
    expect(S.added[0]).toMatchObject({ name: 'skyr', kcal: 120, proteinG: 12.5 })
  })
  it('D38 + D39: po oceni iz tabele brez prijave ni še enega »Oceni brez AI«; polje »Kaj si pojedel«', async () => {
    setState({ time: '12:30' })
    await render(<Prehrana />)
    await typeIn(document.querySelector('#meal-desc'), 'pol čokolade')
    await click(btn(/Oceni kalorije/))
    expect(text()).toMatch(/Ocena iz tabele živil — brez prijave/)
    expect(btn(/Oceni brez AI/)).toBeFalsy()
    expect(document.querySelector('label[for="meal-name"]')!.textContent).toBe('Kaj si pojedel')
  })
})

describe('Prehrana — po treningu (D11, D27, D37)', () => {
  it('D11: po opravljenem dolgem teku brez »Vzemi:« in časovnice, samo vpis', async () => {
    const run = planDay(TODAY, 90, { kind: 'tek', title: 'Dolgi tek', zone: 'Z2', role: 'dolga' })
    setState({ time: '13:00', plan: [run], activities: [act0(TODAY, 'tek', 92, '08:00')], meals: [meal(TODAY, 'zajtrk', 500, { time: '07:00' })] })
    await render(<Prehrana />)
    await click(btn(/cel dan po načrtu/))
    const c = document.querySelector('.run-fuel')!.textContent!.replace(/[\u00A0\u202F]/g, ' ')
    expect(c).not.toMatch(/Vzemi:/)
    expect(c).toMatch(/ni vpisano/)
    expect(c).toMatch(/Načrt je bil ~\d+ g OH, [\d,]+ l\./)
    expect(document.querySelector('.run-fuel .fuel-tl')).toBeNull()
  })
  it('D27 + D37: vožnja z ure brez vpisa goriva — brez »ne jej na silo«, trening s ✓', async () => {
    setState({ time: '13:30', plan: [planDay(TODAY, 180)], activities: [act0(TODAY, 'kolo', 185, '08:00')] })
    await render(<Prehrana />)
    await click(btn(/cel dan po načrtu/))
    const c = planCard()
    expect(c).toMatch(/Gorivo na kolesu ni vpisano/)
    expect(c).not.toMatch(/ne jej na silo/)
    expect(c).toMatch(/Dolga Z2 · 3 h ✓/)
  })
})

describe('D12 — ženske oblike (profil sex: z)', () => {
  const Z = P({ sex: 'z', weightKg: 60, heightCm: 168 })
  const MALE = /lačen|\bsit\b|porabil\b|pojedel\b|\bjedel\b|popil\b/
  it('pozno zvečer, polje za opis in list', async () => {
    setState({ time: '23:30', profile: Z, meals: [meal(TODAY, 'kosilo', 800, { time: '13:00' })] })
    await render(<Prehrana />)
    expect(planCard()).toMatch(/Pozno je — če si lačna/)
    expect((document.querySelector('#meal-desc') as HTMLTextAreaElement).placeholder).toBe('Napiši ali povej, kaj si pojedla')
    await click(btn(/^Dodaj /))
    expect(document.querySelector('label[for="meal-name"]')!.textContent).toBe('Kaj si pojedla')
    expect(text()).not.toMatch(MALE)
  })
  it('po vožnji brez vpisa goriva: »vpiši, kaj si porabila«', async () => {
    setState({ time: '14:00', profile: Z, plan: [planDay(TODAY, 180, { done: { at: NOW } })], meals: [meal(TODAY, 'zajtrk', 600, { time: '07:00' })] })
    await render(<Prehrana />)
    expect(btn(/vpiši, kaj si porabila/)).toBeTruthy()
    expect(planCard()).not.toMatch(MALE)
  })
  it('gorivo pred vožnjo (fueling): »če si lačna«', () => {
    const f = fueling(planDay(TODAY, 120, { role: 'lahka', title: 'Z2' }), Z)!
    expect(`${f.before} ${f.during} ${f.after}`).not.toMatch(MALE)
    expect(fueling({ kind: 'tek', durationMin: 50, zone: 'Z2' } as never, Z)!.before).toMatch(/lačna/)
  })
})

describe('D24, D25 — vpis goriva za pretekli dan', () => {
  it('list ne reče »današnje«; vpis gre na uro vožnje z ure (14:00), ne na uro vpisa', async () => {
    const d = '2026-10-15'   // četrtek
    const day = planDay(d, 180)
    setState({ time: '09:00', activities: [act0(d, 'kolo', 180, '14:00')] })
    await render(<FuelLogSheet open onClose={() => undefined} day={day} rf={rideFuel(day)!} existing={null} />)
    expect(text()).not.toMatch(/današnje/)
    expect(text()).toMatch(/Šteje v kalorije četrtka/)
    await click(btn(/^Shrani$/))
    expect(S.added[0]).toMatchObject({ date: d, time: '14:00', slot: 'med_vadbo' })
    expect(S.toasts.join(' ')).toMatch(/šteje v kalorije četrtka/)
  })
  it('pretekli dan brez vožnje z ure: tipična ura (16:00), ne 9:00', async () => {
    const d = '2026-10-15'
    const day = planDay(d, 180)
    setState({ time: '09:00' })
    await render(<FuelLogSheet open onClose={() => undefined} day={day} rf={rideFuel(day)!} existing={null} />)
    await click(btn(/^Shrani$/))
    expect(S.added[0].time).toBe('16:00')
  })
})

describe('D26, D41, D42 — tehtanje', () => {
  it('D26: obseg pasu 5 cm se ne shrani', async () => {
    setState({ time: '07:00' })
    await render(<WeighSheet open onClose={() => undefined} />)
    await typeIn(document.getElementById('weigh-kg'), '79,5')
    await typeIn(document.getElementById('weigh-waist'), '5')
    await click(btn(/^Shrani$/))
    expect(S.saved).toHaveLength(0)
    expect(S.toasts).toContain('Obseg pasu vpiši v cm (40–200).')
  })
  it('D41: pri urejanju današnjega tehtanja prazen pas pas izbriše', async () => {
    const c = { date: TODAY, weightKg: 78.6, waistCm: 85 }
    setState({ time: '07:00', checkins: [c], checkinToday: c })
    await render(<WeighSheet open onClose={() => undefined} />)
    expect((document.getElementById('weigh-waist') as HTMLInputElement).value).toBe('85')
    await typeIn(document.getElementById('weigh-waist'), '')
    await click(btn(/^Shrani$/))
    expect(S.saved[0]).toMatchObject({ date: TODAY, weightKg: 78.6, waistCm: null })
  })
  it('D42: izbran pretekli dan s tehtanjem — polje dobi takratno težo in opombo', async () => {
    setState({ time: '07:00', checkins: [{ date: '2026-10-15', weightKg: 79.6, waistCm: 86 }] })
    await render(<WeighSheet open onClose={() => undefined} />)
    expect((document.getElementById('weigh-kg') as HTMLInputElement).value).toBe('')
    const dateInp = document.querySelector('input[type="date"]') as HTMLInputElement
    await typeIn(dateInp, '2026-10-15')
    expect((document.getElementById('weigh-kg') as HTMLInputElement).value).toBe('79,6')
    expect((document.getElementById('weigh-waist') as HTMLInputElement).value).toBe('86')
    expect(text()).toMatch(/Ta dan je že 79,6 kg — Shrani ga popravi\./)
  })
})
