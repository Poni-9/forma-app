// v3.51 UVOD-UVOZ (zasloni): osnutek uvoda (F03), en dan (F04), ponujen dan v odgovoru (F05), list cilja (F01, F02),
// Uvoz (F09, F10, F15, F17, F18), popravek vadbe (F11, F24, F26, F47), ročni vnos (F12, F23, F43, F44), vodnik (F41),
// Kako deluje (F42), gradnja (F38), pripomba (F36), Nastavitve (F13, F27, F28, F29, F30, F31).
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, afterEach, beforeEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), nav: [] as string[], route: { name: 'uvod', params: {} as Record<string, string> } }))
vi.mock('@/state/store', async () => {
  const { vi: v } = await import('vitest')
  const base: Record<string | symbol, unknown> = {
    useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
    getState: () => S.state,
    routePace: () => ({ k: 1, adj: { n: 0, adj: 1 } }),
    addActivities: v.fn(async () => ({ added: 1, dupes: 0, upgraded: 0 })),
    updateProfile: v.fn(async (patch: Record<string, unknown>) => ({ ...S.state.profile, ...patch })),
    LAST_EXPORT_KEY: 'x',
  }
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' || typeof k === 'symbol' ? undefined : (t[k] = v.fn(async () => {}))), has: (_t, k) => k !== 'then' })
})
vi.mock('@/app/router', () => ({ navigate: (to: string) => { S.nav.push(to) }, useRoute: () => S.route, parseHash: () => S.route, subscribeRoute: () => () => undefined }))
vi.mock('@/app/landing', () => ({ markApp: () => undefined, forgetApp: () => undefined }))
vi.mock('@/app/Shell', async (orig) => ({ ...(await orig<object>()), Head: () => null }))
vi.mock('@/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
vi.mock('@/data/icuOauth', () => ({ icuOauthOn: () => false, probeIcuOauth: async () => false, startIcuOAuth: () => undefined }))
vi.mock('@/data/db', () => ({ getKV: async () => undefined, storagePersisted: () => null, requestPersist: async () => false }))
vi.mock('@/data/repo', () => ({ wipeAll: vi.fn() }))
vi.mock('@/data/backup', () => ({ downloadBackup: vi.fn() }))
vi.mock('@/data/sync', () => ({ syncNow: vi.fn() }))
vi.mock('@/data/feedback', () => ({
  FB_KINDS: [['nejasno', 'Ni jasno'], ['napaka', 'Napaka'], ['predlog', 'Predlog']], FB_SHOT_MAX: 700000, FB_TEXT_MAX: 3000,
  makeFeedback: async (o: object) => ({ ...o, id: 'x', meta: {}, anon: 'a' }), sendFeedback: async () => 'poslano', captureScreen: async () => null,
  fetchFeedbackList: async () => ({ error: 'x' }), flushFeedback: async () => 0, queuedFeedback: async () => 0,
}))
vi.mock('@/ui/ClaudeAdmin', () => ({ ClaudeAdmin: () => null }))
vi.mock('@/ui/BackupImport', () => ({ BackupImport: () => null }))
vi.mock('@/ui/GoalCard', () => ({ GoalCard: () => null }))
vi.mock('@/ui/theme', () => ({ THEME_PREFS: [['samodejno', 'kot telefon']], themePref: () => 'samodejno', setThemePref: vi.fn(), subscribeTheme: () => () => {} }))
vi.mock('@/domain/import/archive', async (orig) => {
  const real = await orig<typeof import('@/domain/import/archive')>()
  const { vi: v } = await import('vitest')
  return { ...real, parseArchive: v.fn(real.parseArchive) }
})

import * as store from '@/state/store'
import { Sestavi, readDraft, writeDraft, draftAgo } from '@/screens/Sestavi'
import { GoalSheet } from '@/ui/GoalSheet'
import { Uvoz } from '@/screens/Uvoz'
import { Aktivnosti } from '@/screens/Aktivnosti'
import { ActivitySheet, applyEdit, editFormOf, NOTE_HINT } from '@/ui/ActivitySheet'
import { Guide } from '@/ui/Guide'
import { HelpSheet } from '@/ui/HelpSheet'
import { BuildShow } from '@/ui/BuildShow'
import { FeedbackSheet } from '@/ui/FeedbackSheet'
import { Nastavitve, strengthLine, queuedLine, weatherFailText } from '@/screens/Ostalo'
import { Prijava } from '@/screens/Prijava'
import { Pilot } from '@/screens/Pilot'
import { parseArchive } from '@/domain/import/archive'
import { raceWeightOf, ftpPotential } from '@/domain/training/goal'
import { normalizeFocus } from '@/domain/focus/model'
import { AI_SENT } from '@/domain/ai/consent'
import type { Activity, PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-23'   // petek
const NOW = `${TODAY}T08:00:00.000Z`
const NEW = { sex: 'm', age: 35, heightCm: 180, weightKg: 85, ftp: null, maxHr: null, restHr: null, gear: { bikeOutdoor: false, trainer: false, noBike: false }, strength: { on: false, equipment: 'none' }, onboardingDone: false, createdAt: NOW, updatedAt: NOW } as unknown as Profile
const P = { sex: 'm', age: 30, heightCm: 180, weightKg: 78, ftp: 240, maxHr: 190, restHr: 50, lthr: 170, hoursPerWeek: 8, gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, strength: { on: false, equipment: 'none' }, strengthDays: 0, onboardingDone: true, goal: 'hitrejsi', trainTime: null, createdAt: NOW, updatedAt: NOW } as unknown as Profile

let div: HTMLDivElement | null = null, root: Root | null = null
async function render(el: ReactElement): Promise<HTMLDivElement> {
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root!.render(el) })
  return div
}
async function unmount() { if (root) await act(async () => root!.unmount()); div?.remove(); root = null; div = null }
afterEach(async () => { await unmount(); vi.useRealTimers(); document.body.innerHTML = '' })
const sp = (x: string) => x.replace(/[   ⁠]/g, ' ')
const txt = (d: Element = document.body) => sp(d.textContent || '')
const btn = (label: string | RegExp, r: ParentNode = document) => [...r.querySelectorAll('button')].find(b => (typeof label === 'string' ? sp(b.textContent || '').trim() === label || b.getAttribute('aria-label') === label : label.test(sp(b.textContent || '')))) as HTMLButtonElement | undefined
async function click(label: string | RegExp, r: ParentNode = document) { const b = btn(label, r); if (!b) throw new Error(`ni gumba: ${label}`); await act(async () => { b.click() }) }
async function type(el: HTMLTextAreaElement | HTMLInputElement, v: string) {
  const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype
  await act(async () => { Object.getOwnPropertyDescriptor(proto, 'value')!.set!.call(el, v); el.dispatchEvent(new Event('input', { bubbles: true })) })
}
const flush = async () => { for (let i = 0; i < 8; i++) await act(async () => { await Promise.resolve() }) }
const calls = (f: unknown) => (f as { mock: { calls: unknown[][] } }).mock.calls
const state = (o: Record<string, unknown> = {}) => ({
  ready: true, today: TODAY, profile: NEW, activities: [], plan: [], checkins: [], weather: null, wellness: [], user: null, changes: [], pro: false,
  settings: { lang: 'sl', intervals: null, guideSeen: true }, sync: { state: 'off' }, mealsToday: [], recentMeals: [], icuDiag: null, icuWorkouts: null, icuErr: null, ...o,
})
const act0 = (o: Partial<Activity> = {}): Activity => ({ id: 'a1', source: 'manual', sport: 'kolo', date: TODAY, start: null, name: 'Kolo', durationMin: 40, distKm: 15, elevM: null, avgHr: null, avgPower: null, kcal: null, speedKmh: 22.5, tss: 47, polyline: null, aiEligible: true, geoRetain: false, createdAt: NOW, updatedAt: NOW, ...o } as Activity)
const day = (o: Partial<PlanDay>): PlanDay => ({ id: 'd-' + (o.date || TODAY) + (o.kind || ''), date: TODAY, kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, role: 'z2', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o } as PlanDay)
const days = async (...ds: string[]) => { for (const d of ds) await click(`${d}: nimam časa`) }
beforeEach(() => {
  vi.clearAllMocks()
  S.state = state(); S.nav = []; S.route = { name: 'uvod', params: {} }; sessionStorage.clear(); localStorage.clear()
  window.scrollTo = vi.fn() as unknown as typeof window.scrollTo
  Element.prototype.scrollIntoView = vi.fn()
})

/* ---------- uvod ---------- */
describe('F03 osnutek uvoda v localStorage', () => {
  const d = { again: false, picks: { delam: ['Tek'] }, text: 'Ob torkih nimam časa.', avail: [6], trainTime: null, push: 'zmerno' as const, main: 'oboje' as const, b: { sex: 'z' as const, age: '33', height: '', weight: '' } }
  it('ostane, ko se seja zapre (sessionStorage prazen); po 13 h ga ni več', () => {
    writeDraft(d)
    sessionStorage.clear()
    expect(readDraft(false)?.text).toBe('Ob torkih nimam časa.')
    expect(readDraft(false, Date.now() + 13 * 3600_000)).toBeNull()
    expect(localStorage.getItem('formai.uvod')).toBeNull()
    expect(draftAgo(0, 2 * 3600_000)).toBe('pred 2 h')
    expect(draftAgo(0, 20 * 60_000)).toBe('pred 20 min')
  })
  it('star osnutek: »Nadaljujem …« in »Začni znova« uvod izprazni', async () => {
    localStorage.setItem('formai.uvod', JSON.stringify({ v: 1, at: Date.now() - 2 * 3600_000, ...d }))
    const el = await render(<Sestavi />)
    expect((el.querySelector('#sest-wish') as HTMLTextAreaElement).value).toBe('Ob torkih nimam časa.')
    expect(txt()).toContain('Nadaljujem tvoj osnutek od prej (pred 2 h).')
    await click('Začni znova')
    expect((document.querySelector('#sest-wish') as HTMLTextAreaElement).value).toBe('')
    expect(txt()).not.toContain('Nadaljujem tvoj osnutek')
    expect(localStorage.getItem('formai.uvod')).toBeNull()
  })
  it('kontrola: svež osnutek (osvežitev) brez vrstice', async () => {
    writeDraft(d)
    await render(<Sestavi />)
    expect(txt()).not.toContain('Nadaljujem tvoj osnutek')
  })
})

describe('F04 en dan na teden', () => {
  it('samo nedelja: »Raje brez prijave« omogočen, opozorilo namesto blokade', async () => {
    await render(<Sestavi />)
    await click('Tek'); await click('Boljša kondicija')
    await days('nedelja')
    expect(btn('Raje brez prijave (vprašalnik brez AI)')!.disabled).toBe(false)
    expect(txt()).toContain('En dan na teden je premalo za hiter napredek, a dovolj za začetek — trener ga naredi najboljšega.')
    expect(txt()).not.toContain('Tapni vsaj dva dneva')
  })
})

describe('F05 ponujen dan, ki ga trener ne uporabi', () => {
  it('tekač začetnik, tor + čet + ned: odgovor pove prost dan s časom in »Več dni«', async () => {
    const d = await render(<Sestavi />)
    await click('Tek'); await click('Manj kilogramov'); await click('Začenjam')
    await days('torek', 'četrtek', 'nedelja')
    await click('Raje brez prijave (vprašalnik brez AI)')
    for (let g = 0; g < 10 && !txt(d).includes('Najin dogovor'); g++) {
      const cur = d.querySelector('.q-turn')!
      const opts = [...cur.querySelectorAll('.q-opts button')] as HTMLButtonElement[]
      const three = /dni bi res/.test(txt(cur)) ? opts.find(b => b.textContent?.trim() === '3') : null
      await act(async () => { (three || opts[0]!).click() })
      const next = btn('Naprej ›', cur)
      if (next) await act(async () => { next.click() })
    }
    const reply = [...d.querySelectorAll('.talk:not(.me)')].map(x => txt(x)).join(' ')
    expect(reply).toMatch(/Predlagam 2 dneva/)
    expect(reply).toMatch(/Ob (torkih|četrtkih|nedeljah) imaš čas, a je ta dan za obnovo — ko gre lepo, dodava vadbo \(»Več dni«\)\./)
  })
})

/* ---------- list cilja ---------- */
describe('F01 + F40 list cilja: dolžina in vzpon za vsak cilj', () => {
  const franja = { ...P, goal: 'dirka', event: { name: 'Maraton Franja', date: '2027-06-13', distanceKm: 156, type: 'maraton', elevM: 1600, level: 'amater' } } as unknown as Profile
  it('preimenovan cilj ne podeduje 156 km, »maraton« in 1 600 m; vpisana dolžina se shrani', async () => {
    S.state = state({ profile: franja })
    await render(<GoalSheet open onClose={() => undefined} />)
    expect((document.getElementById('gs-km') as HTMLInputElement).value).toBe('156')
    expect((document.getElementById('gs-elev') as HTMLInputElement).value).toBe('1600')
    await type(document.getElementById('gs-name') as HTMLInputElement, 'VN Kranj')
    expect((document.getElementById('gs-km') as HTMLInputElement).value).toBe('')
    await type(document.getElementById('gs-km') as HTMLInputElement, '82')
    await click(/^Potrdi/)
    await flush()
    const ev = (calls(store.updateProfile).at(-1)![0] as Partial<Profile>).event!
    expect(ev).toMatchObject({ name: 'VN Kranj', date: '2027-06-13', distanceKm: 82, elevM: null })
    expect(ev.type).toBeUndefined()
    expect(ev.level).toBeUndefined()
  })
  it('isto ime: vrsta, raven in vzpon ostanejo', async () => {
    S.state = state({ profile: franja })
    await render(<GoalSheet open onClose={() => undefined} />)
    await click(/^Potrdi/)
    await flush()
    expect((calls(store.updateProfile).at(-1)![0] as Partial<Profile>).event).toMatchObject({ name: 'Maraton Franja', distanceKm: 156, type: 'maraton', elevM: 1600, level: 'amater' })
  })
})

describe('F02 list cilja kaže iste številke kot kartica', () => {
  it('nespremenjen list: najboljša teža in FTP iz izhodišča cilja; Potrdi ga ne premakne', async () => {
    const p = { ...P, goal: 'dirka', weightKg: 79, bodyFatPct: 18, hoursPerWeek: 10, hoursMode: 'own', event: { name: 'Maraton Franja', date: '2027-06-13', distanceKm: 156 }, cycleStart: '2026-09-07', goalStart: { date: '2026-09-07', ftp: 240, weightKg: 79 } } as unknown as Profile
    // tehtanja zadnji teden: povprečje 79,9 kg (prej je list računal od tega in od danes)
    const checkins = Array.from({ length: 7 }, (_, i) => ({ date: `2026-10-${String(17 + i).padStart(2, '0')}`, weightKg: 79.9 }))
    S.state = state({ profile: p, checkins })
    await render(<GoalSheet open onClose={() => undefined} />)
    const rw = raceWeightOf(p, TODAY)!, pot = ftpPotential(p, TODAY)!
    expect(txt()).toContain(`${rw.kg.toFixed(1).replace('.', ',')} kg`)
    expect(txt()).toContain(`realno ${pot.realistic} W · največ ${pot.ideal} W`)
    await click(/^Potrdi/)
    await flush()
    const next = calls(store.updateProfile).at(-1)![0] as Partial<Profile>
    expect(next.goalStart).toEqual(p.goalStart)
    expect(next.cycleStart).toBe('2026-09-07')
  })
})

/* ---------- Uvoz ---------- */
const icu = { athleteId: 'i1', apiKey: 'k', name: 'Ana', pushWorkouts: false }
describe('F10 + F17 + F18 Uvoz z drugo uro', () => {
  it('vadbe z Wahooja: korak »Ura pošilja vožnje · Wahoo« je odkljukan, brez Garminovih navodil', async () => {
    S.state = state({ profile: P, settings: { lang: 'sl', intervals: icu }, activities: [act0({ source: 'intervals', originHint: 'WAHOO', date: '2026-10-04' })] })
    S.route = { name: 'uvoz', params: {} }
    await render(<Uvoz />)
    expect(txt()).toContain('Ura pošilja vožnje · Wahoo')
    expect(txt()).toContain('Zadnja: 4. 10.')
    expect(txt()).not.toContain('Garmin Connect')
  })
  it('Wahoo pot: tap na že označen »Ura / števec« ostane pri »tvoja ura«', async () => {
    S.state = state({ profile: P })
    await render(<Uvoz />)
    await click(/^Wahoo, Polar/)
    await click('Ura / števec')
    expect(txt()).toContain('tvoja ura')
    expect(txt()).not.toContain('Garmin Connect')
  })
  it('tekač (načrt brez kolesa): nikjer »vožnja«', async () => {
    const tek = { ...P, focus: normalizeFocus({ wish: 'Rad delam: tek.', sessions: [{ type: 'tek', cardio: 'lahko', min: 30 }, { type: 'tek', cardio: 'lahko', min: 30 }], aims: ['kondicija'] }, { by: 'pravila' }) } as unknown as Profile
    S.state = state({ profile: tek })
    await render(<Uvoz />)
    await click(/^Wahoo, Polar/)
    expect(txt()).toContain('Enkrat nastaviš, potem samo treniraš.')
    expect(txt()).not.toMatch(/vožnj|voziš/)
  })
})

describe('F09 + F19 Stravin arhiv', () => {
  it('po uvozu ostane opozorilo, da trener teh vadb ne sme uporabiti; gumb »Izberi .zip arhiv«', async () => {
    const parsed = [1, 2, 3].map(i => ({ sport: 'kolo', name: `Kolo ${i}`, start: null, date: '2026-09-0' + i, distKm: 30, durationMin: 60, elevM: null, avgHr: null, maxHr: null, avgPower: null, kcal: null, polyline: null, deviceName: null, fileName: `${i}.gpx`, originHint: 'STRAVA' }))
    ;(parseArchive as unknown as ReturnType<typeof vi.fn>).mockResolvedValueOnce({ parsed, failed: 0, found: 3, strava: true, fails: [] })
    S.state = state({ profile: P })
    await render(<Uvoz />)
    await click(/^Imam datoteke/)
    expect(btn(/Izberi \.zip arhiv/)).toBeTruthy()
    expect(btn(/Odloži/)).toBeUndefined()
    const input = document.querySelector('input[accept=".zip"]') as HTMLInputElement
    Object.defineProperty(input, 'files', { value: [new File(['x'], 'export.zip')], configurable: true })
    await act(async () => { input.dispatchEvent(new Event('change', { bubbles: true })) })
    await flush()
    expect(txt()).toContain('Stravin arhiv: 3 vadbe so zdaj na tej napravi, trener jih ne sme uporabiti (Stravina pravila).')
    expect(String(calls(store.toast).at(-1)![0])).toMatch(/^Stravin arhiv — .*trener jih ne sme uporabiti/)
  })
})

describe('F15 spuščanje datotek na Uvoz', () => {
  it('.gpx, spuščen na zaslon, se uvozi (brez odpiranja v brskalniku)', async () => {
    S.state = state({ profile: P })
    const el = await render(<Uvoz />)
    await click(/^Imam datoteke/)
    expect(txt()).toContain('povleci jih sem ali jih izberi')
    let gpx = '<?xml version="1.0"?><gpx version="1.1" xmlns="http://www.topografix.com/GPX/1/1"><trk><trkseg>'
    for (let i = 0; i < 120; i++) gpx += `<trkpt lat="${(46.19 + i * 0.0007).toFixed(5)}" lon="14.49"><time>${new Date(Date.UTC(2026, 9, 20, 7, 0, i * 10)).toISOString()}</time></trkpt>`
    gpx += '</trkseg></trk></gpx>'
    const file = new File([gpx], 'jutranja.gpx')
    const scroll = el.querySelector('.scroll')!
    const ev = new Event('drop', { bubbles: true, cancelable: true })
    Object.defineProperty(ev, 'dataTransfer', { value: { types: ['Files'], files: [file] } })
    await act(async () => { scroll.dispatchEvent(ev) })
    await flush()
    expect(ev.defaultPrevented).toBe(true)
    expect(calls(store.addActivities).length).toBe(1)
    expect((calls(store.addActivities)[0]![0] as Activity[])[0]!.distKm).toBeGreaterThan(5)
  })
})

/* ---------- popravek vadbe ---------- */
describe('F11 + F26 + F25 popravek vadbe', () => {
  it('Uredi → fokus v trajanje; 55 min → »Končano« shrani popravek', async () => {
    S.state = state({ profile: P, activities: [act0()] })
    await render(<ActivitySheet id="a1" onClose={() => undefined} onDelete={() => undefined} />)
    await click('Uredi')
    expect(document.activeElement?.id).toBe('ae-min')
    await type(document.getElementById('ae-min') as HTMLInputElement, '55')
    await click('Končano')
    await flush()
    expect(calls(store.saveActivity).some(c => (c[0] as Activity).durationMin === 55)).toBe(true)
  })
  it('Končano z napako v popravku: vpraša, ali ga zavržem', async () => {
    S.state = state({ profile: P, activities: [act0()] })
    let closed = false
    await render(<ActivitySheet id="a1" onClose={() => { closed = true }} onDelete={() => undefined} />)
    await click('Uredi')
    await type(document.getElementById('ae-dist') as HTMLInputElement, '300')
    await click('Končano')
    await flush()
    expect(txt()).toContain('Razdalja ne gre s tem časom')
    expect(txt()).toContain('Zavržem popravek?')
    expect(closed).toBe(false)
    expect(calls(store.saveActivity).length).toBe(0)
  })
  it('namig opombe po športu', async () => {
    S.state = state({ profile: P, activities: [act0({ sport: 'moc', distKm: null })] })
    await render(<ActivitySheet id="a1" onClose={() => undefined} onDelete={() => undefined} />)
    expect((document.getElementById('act-note') as HTMLTextAreaElement).placeholder).toBe(NOTE_HINT.moc)
    expect(NOTE_HINT.moc).not.toContain('veter')
  })
})

describe('F24 popravek: kalorije in moč', () => {
  const a = act0({ source: 'screenshot', durationMin: 90, distKm: 45, avgHr: 140, avgPower: 200, kcal: 900, speedKmh: 30 })
  it('90 → 45 min z nespremenjenimi kcal: 450 kcal; vpisane kcal in vati veljajo', () => {
    expect(applyEdit(a, { ...editFormOf(a), min: '45' }, P).kcal).toBe(450)
    expect(applyEdit(a, { ...editFormOf(a), min: '45', kcal: '600' }, P).kcal).toBe(600)
    expect(applyEdit(a, { ...editFormOf(a), power: '180' }, P).avgPower).toBe(180)
    expect(applyEdit(a, editFormOf(a), P).kcal).toBe(900)
  })
})

describe('F47 popravek športa odkljuka nov dan', () => {
  it('kolo → tek: kolesarski dan ni več opravljen, tek istega dne je odkljukan s to vadbo', async () => {
    const kolo = day({ kind: 'kolo', title: 'Z2', done: { at: NOW, activityId: 'a1' } } as Partial<PlanDay>)
    const tek = day({ kind: 'tek', title: 'Lahek tek', durationMin: 40, role: 'z2' })
    S.state = state({ profile: P, activities: [act0({ source: 'file' })], plan: [kolo, tek] })
    await render(<ActivitySheet id="a1" onClose={() => undefined} onDelete={() => undefined} />)
    await click('Uredi')
    await click('Tek')
    await type(document.getElementById('ae-dist') as HTMLInputElement, '7')
    await click('Shrani popravek')
    await flush()
    const done = calls(store.setPlanDone)
    expect(done).toContainEqual([kolo.id, false])
    expect(done).toContainEqual([tek.id, true, 'a1'])
    expect(String(calls(store.toast).at(-1)![0])).toContain('»Lahek tek«')
  })
})

/* ---------- ročni vnos ---------- */
describe('F12 + F23 + F43 + F44 ročni vnos', () => {
  it('moč iz današnjega načrta: vaje, ime in minute že ob odprtju; »?nova=1« izgine iz naslova', async () => {
    history.replaceState(null, '', '#/aktivnosti?nova=1')
    S.route = { name: 'aktivnosti', params: { nova: '1' } }
    const moc = day({ kind: 'moc', title: 'Moč — noge in jedro', durationMin: 40, role: 'moc', exercises: [{ name: 'Počep', sets: 3, reps: '10' }, { name: 'Deska', sets: 3, reps: '30 s' }] } as Partial<PlanDay>)
    S.state = state({ profile: P, plan: [moc] })
    await render(<Aktivnosti />)
    expect(location.hash).toBe('#/aktivnosti')
    const names = [...document.querySelectorAll('input[aria-label="Vaja"]')].map(x => (x as HTMLInputElement).value)
    expect(names).toEqual(['Počep', 'Deska'])
    expect((document.getElementById('ak-name') as HTMLInputElement).value).toBe('Moč — noge in jedro')
    expect((document.getElementById('ak-min') as HTMLInputElement).value).toBe('40')
  })
  it('9 999 kg: sporočilo pod vajami, vadba se ne shrani', async () => {
    S.route = { name: 'aktivnosti', params: { nova: '1' } }
    const moc = day({ kind: 'moc', title: 'Moč', durationMin: 40, role: 'moc', exercises: [{ name: 'Počep', sets: 3, reps: '10' }] } as Partial<PlanDay>)
    S.state = state({ profile: P, plan: [moc] })
    await render(<Aktivnosti />)
    await type(document.querySelector('input[aria-label="Kilogrami"]') as HTMLInputElement, '9999')
    await click('Shrani')
    expect(document.getElementById('ak-ex-err')!.textContent).toBe('Kilogrami: od 0 do 400.')
    expect(calls(store.addActivities).length).toBe(0)
  })
  it('kolo brez imena: »Kolo 42 km« (kot uvoz), ne »Vožnja«', async () => {
    S.route = { name: 'aktivnosti', params: { nova: '1' } }
    S.state = state({ profile: P })
    await render(<Aktivnosti />)
    await click('Kolo')
    await type(document.getElementById('ak-min') as HTMLInputElement, '90')
    await type(document.getElementById('ak-km') as HTMLInputElement, '42')
    await click('Shrani')
    await flush()
    expect((calls(store.addActivities)[0]![0] as Activity[])[0]!.name).toBe('Kolo 42 km')
  })
})

/* ---------- vodnik, Kako deluje, gradnja, pripomba ---------- */
describe('F41 + F42 vodnik in Kako deluje', () => {
  it('»Na kratko« brez povezane ure: ni »povezana ura ga odkljuka«', async () => {
    S.state = state({ profile: { ...P, onboardingDone: true }, settings: { lang: 'sl', intervals: null, guideSeen: false } })
    await render(<Guide open onClose={() => undefined} />)
    expect(txt()).toContain('Na kratko')
    expect(txt()).not.toContain('povezana ura')
    expect(txt()).toContain('tako načrt ve, kaj si naredil')
  })
  it('kontrola: s povezano uro ostane', async () => {
    S.state = state({ profile: P, settings: { lang: 'sl', intervals: icu, guideSeen: false } })
    await render(<Guide open onClose={() => undefined} />)
    expect(txt()).toContain('(povezana ura ga odkljuka sama)')
  })
  it('Kako deluje brez cilja z datumom: »Tvoj načrt po korakih«; s ciljem »Tvoj cilj po korakih«', async () => {
    S.state = state({ profile: P })
    await render(<HelpSheet term={null} />)
    expect(btn('Tvoj načrt po korakih')).toBeTruthy()
    await unmount()
    S.state = state({ profile: { ...P, event: { name: 'Franja', date: '2027-06-13' } } })
    await render(<HelpSheet term={null} />)
    expect(btn('Tvoj cilj po korakih')).toBeTruthy()
  })
})

describe('F38 gradnja, zadnji prizor', () => {
  const basics = { sex: 'm' as const, age: 30, heightCm: 180, weightKg: 75, avail: [0, 2, 4], trainTime: null, push: 'zmerno' as const, main: 'kardio' as const }
  async function toEnd() { for (let i = 0; i < 70; i++) await act(async () => { await vi.advanceTimersByTimeAsync(1000) }) }
  it('tekač brez moči: v telefonu ni zemljevida mišic; »12 tednov«', async () => {
    S.state = state({ profile: P })
    const f = normalizeFocus({ wish: 'Rad delam: tek.', sessions: [{ type: 'tek', cardio: 'lahko', min: 30 }, { type: 'tek', cardio: 'lahko', min: 30 }], aims: ['kondicija'] }, { by: 'pravila' })!
    vi.useFakeTimers()
    await render(<BuildShow focus={f} basics={basics} ai={false} again onSave={async () => {}} onDone={() => {}} />)
    await toEnd()
    const phone = document.querySelector('.bs-phone')!
    expect(phone).toBeTruthy()
    expect(phone.querySelector('.bodymap')).toBeNull()
    expect(txt(phone.querySelector('.bs-blocks')!)).toContain('12 tednov')
  })
  it('kolesar s tekmo: »Do tekme N tednov« (kot dnevnik)', async () => {
    S.state = state({ profile: P })
    const f = normalizeFocus({ wish: 'Rad delam: kolo.', sessions: [{ type: 'kolo', cardio: 'lahko', min: 60 }, { type: 'kolo', cardio: 'intervali', min: 60 }, { type: 'kolo', cardio: 'dolgo', min: 120 }], aims: ['tekma'] }, { by: 'pravila' })!
    vi.useFakeTimers()
    await render(<BuildShow focus={f} basics={basics} ai={false} again onSave={async () => {}} onDone={() => {}} event={{ name: 'Maraton Franja', date: '2027-06-13', distanceKm: 156 }} />)
    await toEnd()
    expect(txt(document.querySelector('.bs-phone .bs-blocks')!)).toMatch(/Do tekme \d+ tednov/)
  })
})

describe('F36 pripomba se ne zavrže tiho', () => {
  it('napisano besedilo → »Prekliči« vpraša »Zavržem napisano pripombo?«', async () => {
    await render(<FeedbackSheet shot={null} route="danes" />)
    await type(document.querySelector('#fb-text') as HTMLTextAreaElement, 'Gumb ne dela, ko …')
    await click('Prekliči')
    expect(txt()).toContain('Zavržem napisano pripombo?')
    await click('Nadaljuj pisanje')
    expect((document.querySelector('#fb-text') as HTMLTextAreaElement).value).toBe('Gumb ne dela, ko …')
  })
})

/* ---------- Nastavitve ---------- */
describe('F28 + F29 + F31 Nastavitve', () => {
  it('brez prijave: AI »dovoljena« z razlago; seznam po alinejah; »Kakšen tip si« pri Profilu, ne pri Prehrani', async () => {
    S.route = { name: 'nastavitve', params: { sec: 'n-racun' } }
    S.state = state({ profile: { ...P, aiConsentAt: NOW, aiConsentV: 3 } })
    await render(<Nastavitve />)
    expect(btn('dovoljena')).toBeTruthy()
    expect(txt()).toContain('Dovoljeno — AI dela, ko se prijaviš.')
    expect(document.querySelectorAll('.ai-lists .ai-ul')[0]!.querySelectorAll('li').length).toBe(AI_SENT.length)
    await click(/^Profil/)
    expect(document.getElementById('n-profil')!.querySelector('#lbl-push')).toBeTruthy()
    await click(/^Prehrana/)
    expect(document.getElementById('n-prehrana')!.querySelector('#lbl-push')).toBeNull()
  })
})

describe('F45 + F46 Nastavitve: lokacija in cikel', () => {
  it('»Lokacija naprave« zapiše »Moja lokacija« z veliko', async () => {
    const geo = { getCurrentPosition: (ok: (p: unknown) => void) => ok({ coords: { latitude: 46.19, longitude: 14.49 } }) }
    Object.defineProperty(navigator, 'geolocation', { value: geo, configurable: true })
    S.route = { name: 'nastavitve', params: { sec: 'n-vreme' } }
    S.state = state({ profile: P })
    await render(<Nastavitve />)
    await click('Lokacija naprave')
    await flush()
    expect(calls(store.updateProfile).at(-1)![0]).toMatchObject({ place: { name: 'Moja lokacija', lat: 46.19, lon: 14.49 } })
  })
  it('»Začni cikel znova« sestavi teden (z »Razveljavi«) — ne pošlje v Plan', async () => {
    S.route = { name: 'nastavitve', params: { sec: 'n-cikel' } }
    S.state = state({ profile: { ...P, cycleStart: '2026-09-07' } })
    await render(<Nastavitve />)
    await click('Začni znova ta teden')
    await click('Začni znova')
    await flush()
    expect(calls(store.updateProfile).at(-1)![0]).toEqual({ cycleStart: '2026-10-19' })
    expect(calls(store.rebuildFromToday).length).toBe(1)
    expect(calls(store.toast).some(c => /v Planu/.test(String(c[0])))).toBe(false)
  })
})

describe('F32 + F33 + F34 + F35 Prijava in Pilot', () => {
  it('Prijava: pravni povezavi z večjim ciljem in v novem zavihku', async () => {
    S.state = state({ authKnown: true })
    await render(<Prijava />)
    const a = [...document.querySelectorAll('a')].filter(x => /pogoji|zasebnostjo/.test(x.textContent || ''))
    expect(a).toHaveLength(2)
    for (const x of a) { expect(x.className).toContain('lnk-hit'); expect(x.getAttribute('target')).toBe('_blank') }
  })
  it('Pilot: »Koda« je oznaka polja, QR ima ime, kopiranje brez odložišča pove, kaj narediti', async () => {
    Object.defineProperty(navigator, 'clipboard', { value: undefined, configurable: true })
    ;(document as unknown as { execCommand: () => boolean }).execCommand = () => false
    S.state = state({ user: null })
    await render(<Pilot />)
    const input = document.getElementById('pilot-code') as HTMLInputElement
    expect(document.querySelector('label[for="pilot-code"]')!.textContent).toBe('Koda')
    await type(input, 'KK-ROG')
    await flush()
    expect(document.querySelector('[role="img"]')!.getAttribute('aria-label')).toBe('QR koda za formai.si/?pilot=KK-ROG')
    await click('Kopiraj povezavo')
    await flush()
    expect(String(calls(store.toast).at(-1)![0])).toBe('Kopiranje ni uspelo — označi povezavo zgoraj in jo kopiraj.')
  })
})

describe('F13 + F27 + F30 besedila Nastavitev', () => {
  it('moč 1×: en dan iz načrta, brez »petek«', () => {
    expect(strengthLine(false, 1, ['torek'])).toBe('Moč doma enkrat na teden (torek): noge in jedro, 20–30 min. Ko opraviš sejo, naslednja dvigne ponovitve.')
    expect(strengthLine(true, 1, [])).not.toMatch(/petek|torek/)
    expect(strengthLine(false, 2, ['ponedeljek', 'četrtek'])).toMatch(/ponedeljek.*četrtek/)
  })
  it('Oprema in moč 1× v Nastavitvah: dan iz načrta tega tedna', async () => {
    S.route = { name: 'nastavitve', params: { sec: 'n-oprema' } }
    S.state = state({ profile: { ...P, strength: { on: true, equipment: 'home' }, strengthDays: 1 }, plan: [day({ date: '2026-10-20', kind: 'moc', title: 'Moč' })] })
    await render(<Nastavitve />)
    const sec = txt(document.getElementById('n-oprema')!)
    expect(sec).toContain('Moč doma enkrat na teden (torek)')
    expect(sec).not.toContain('petek')
  })
  it('vreme brez povezave in pripombe v vrsti', () => {
    expect(weatherFailText(false)).toBe('Brez povezave vremena ne osvežim — poskusi, ko boš na spletu.')
    expect(weatherFailText(true)).toBe('Vremenska storitev ne odgovarja — poskusi čez nekaj minut.')
    expect([1, 2, 3, 5].map(n => sp(queuedLine(n)))).toEqual(['1 pripomba čaka', '2 pripombi čakata', '3 pripombe čakajo', '5 pripomb čaka'])
  })
})
