import { describe, it, expect } from 'vitest'
import { buildWeek, weekContext, canHike, hikeSwap, swapBack, coreOnDemand, FRANJA_2027 } from '../src/domain/training/planner'
import type { PlanDay, Profile, Race } from '../src/domain/types'

const now = new Date().toISOString()
const blaz = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, restHr: 55, maxHr: 200, lthr: 184, ftp: 240, ftpDate: '2026-09-20',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, hoursPerWeek: 14, baseHours: null,
  strength: { on: true, equipment: 'gym', phases: ['osnova'] }, strengthDays: 2, goal: 'dirka', deficit: 400, neat: 1.4,
  event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', onboardingDone: true, createdAt: now, updatedAt: now, ...o,
})
const week = (p: Profile, ws: string) => buildWeek({ profile: p, activities: [], weekStart: ws, notBefore: ws })
const race = (date: string, prio: Race['prio'], name = 'Tekma'): Race => ({ id: `r-${date}`, name, date, distanceKm: 60, prio })
const on = (w: PlanDay[], date: string) => w.filter(d => d.date === date)

describe('fitnes v osnovi, potem ne', () => {
  it('osnova do 10. 1. 2027 (teden 4. 1.), gradnja od 11. 1.', () => {
    expect(weekContext(blaz(), '2027-01-04').phase).toBe('osnova')
    expect(weekContext(blaz(), '2027-01-11').phase).toBe('gradnja')
  })
  it('osnova: 2 × fitnes s težkimi vajami za noge; gradnja: brez moči', () => {
    const w = week(blaz(), '2026-10-05')
    const gym = w.filter(d => d.kind === 'moc')
    expect(gym.map(d => d.title).sort()).toEqual(['Fitnes — noge (težko)', 'Fitnes — noge, hrbet, jedro'])
    expect(gym.find(d => d.title === 'Fitnes — noge (težko)')!.exercises!.map(e => e.name)).toContain('Polovični počep s palico')
    expect(week(blaz(), '2027-02-01').filter(d => d.kind === 'moc')).toHaveLength(0)
    // brez omejitve faz: moč tudi v gradnji (doma: jedro + noge)
    expect(week(blaz({ strength: { on: true, equipment: 'home', phases: null } }), '2027-02-01').filter(d => d.kind === 'moc').length).toBeGreaterThan(0)
  })
  it('jedro po želji: neobvezno, ne šteje v realizacijo', () => {
    const c = coreOnDemand(blaz(), [], '2027-02-03')
    expect(c.kind).toBe('moc'); expect(c.optional).toBe(true); expect(c.title).toBe('Moč — jedro')
  })
})

describe('hribi namesto kolesa', () => {
  it('Z2 in dolga da, ključni trening ne; nazaj na kolo z enim klikom', () => {
    const w = week(blaz(), '2026-10-05')
    const z2 = w.find(d => d.kind === 'kolo' && d.role === 'lahka')!, key = w.find(d => d.role === 'kljucna')!
    expect(canHike(z2)).toBe(true); expect(canHike(key)).toBe(false)
    const h = hikeSwap(z2, blaz())
    expect(h.kind).toBe('pohod'); expect(h.durationMin).toBeGreaterThanOrEqual(z2.durationMin)
    expect(h.desc).toMatch(/Z2/)
    const back = swapBack(h)
    expect(back.kind).toBe('kolo'); expect(back.title).toBe(z2.title); expect(back.durationMin).toBe(z2.durationMin); expect(back.swap).toBeNull()
  })
  it('v osnovi nedeljska Z2 ponudi hribe', () => {
    const sun = week(blaz(), '2026-10-05').find(d => d.date === '2026-10-11' && d.kind === 'kolo')
    expect(sun?.desc).toMatch(/hribe/)
  })
})

describe('druge tekme v sezoni', () => {
  const ws = '2026-10-12'   // pon 12. 10. … ned 18. 10.
  it('pomembna (B) v nedeljo: sobota predaktivacija, petek brez trdega, tekma z id-jem, teden lažji', () => {
    const base = week(blaz(), ws)
    const w = week(blaz({ races: [race('2026-10-18', 'B', 'Kronometer')] }), ws)
    const sun = on(w, '2026-10-18').find(d => d.kind === 'kolo')!
    expect(sun.role).toBe('dirka'); expect(sun.raceId).toBe('r-2026-10-18'); expect(sun.title).toContain('Kronometer')
    const sat = on(w, '2026-10-17').find(d => d.kind === 'kolo')!
    expect(sat.title).toMatch(/Predaktivacija/); expect(sat.role).toBe('lahka'); expect(sat.durationMin).toBeLessThanOrEqual(45)
    expect(on(w, '2026-10-16').every(d => d.role !== 'kljucna' && d.role !== 'test' && d.kind !== 'moc')).toBe(true)
    const bikeMin = (x: PlanDay[]) => x.filter(d => d.kind === 'kolo' && d.role !== 'dirka').reduce((s, d) => s + d.durationMin, 0)
    expect(bikeMin(w)).toBeLessThan(bikeMin(base))
    expect(w.some(d => /Tekma v nedeljo: Kronometer/.test(d.why || ''))).toBe(true)
  })
  it('za trening (C) v soboto: petek predaktivacija, nedelja lahka, največ ena ključna poleg tekme', () => {
    const w = week(blaz({ races: [race('2026-10-17', 'C')] }), ws)
    expect(on(w, '2026-10-17').find(d => d.kind === 'kolo')!.role).toBe('dirka')
    expect(on(w, '2026-10-16').find(d => d.kind === 'kolo')!.title).toMatch(/Predaktivacija/)
    const sun = on(w, '2026-10-18').find(d => d.kind === 'kolo')!
    expect(sun.role).toBe('lahka'); expect(sun.durationMin).toBeLessThanOrEqual(60)
    expect(w.filter(d => d.role === 'kljucna').length).toBeLessThanOrEqual(1)
  })
  it('tekma v ponedeljek naslednjega tedna: nedelja predaktivacija', () => {
    const w = week(blaz({ races: [race('2026-10-19', 'B')] }), ws)
    expect(on(w, '2026-10-18').find(d => d.kind === 'kolo')!.title).toMatch(/Predaktivacija/)
  })
  it('test FTP ne pade tik pred pomembno tekmo — premakne se vsaj 2 dni stran', () => {
    const p = blaz({ ftpDate: '2026-01-01', cycleStart: ws, races: [race('2026-10-17', 'B')] })
    const w = buildWeek({ profile: p, activities: [], weekStart: ws, notBefore: ws, firstWeek: true })
    const t = w.find(d => d.role === 'test')
    expect(t).toBeTruthy()
    expect(Math.abs(new Date('2026-10-17').getTime() - new Date(t!.date).getTime()) / 86400_000).toBeGreaterThanOrEqual(2)
  })
})
