// Čista logika zaslonov: urejanje dneva počisti stare vate/vlogo/razlago, uvod ne da deficita vsem,
// aktivnosti po mesecih.
import { describe, it, expect, vi } from 'vitest'

vi.mock('@/state/store', () => ({ useApp: () => ({}), getState: () => ({}), savePlanDay: vi.fn(), savePlanDays: vi.fn(), toast: vi.fn(), setPlanDone: vi.fn(), hikeInstead: vi.fn(), backToBike: vi.fn(), addCore: vi.fn(), addActivities: vi.fn(), removeActivity: vi.fn(), updateProfile: vi.fn(), updateSettings: vi.fn(), signIn: vi.fn(), saveCheckin: vi.fn(), saveRaces: vi.fn(), saveMainGoal: vi.fn(), startOffSeason: vi.fn(), declineOffSeason: vi.fn(), endOffSeason: vi.fn(), newRouteFor: vi.fn(), routePace: () => ({ k: 1, adj: { n: 0, adj: 1 } }), grantAiConsent: vi.fn() }))

import { applyDayEdit } from '@/screens/Plan'
import { onboardingDeficit } from '@/screens/Onboarding'
import { byMonth } from '@/screens/Aktivnosti'
import { formOf, profilePatch } from '@/screens/Ostalo'
import { menuDayLow, type MenuDay } from '@/screens/Prehrana'
import type { Activity, PlanDay, Profile } from '@/domain/types'

const key: PlanDay = { id: 'k', date: '2026-09-22', kind: 'kolo', title: 'VO2max 5 × 4 min', desc: '5 × 4 min pri 110 %.', durationMin: 75, zone: 'Z5', role: 'kljucna', target: { lo: 270, hi: 290 }, why: 'Ključna seja tedna.', kcalBurn: 900, source: 'rules', createdAt: 'x', updatedAt: 'x' }
const form = (p: Partial<{ kind: PlanDay['kind']; title: string; dur: string; zone: string; desc: string }>) => ({ kind: key.kind, title: key.title, dur: String(key.durationMin), zone: key.zone!, desc: key.desc, ...p })

describe('applyDayEdit', () => {
  it('samo naslov: vati, vloga in razlaga ostanejo', () => {
    const d = applyDayEdit(key, form({ title: 'VO2max' }), [])
    expect(d.target).toEqual(key.target)
    expect(d.role).toBe('kljucna')
    expect(d.why).toBe(key.why)
  })
  it('druga cona ali opis: stari vati, vloga in razlaga ne veljajo več', () => {
    for (const d of [applyDayEdit(key, form({ zone: 'Z2' }), []), applyDayEdit(key, form({ desc: 'Lahko po občutku.' }), [])]) {
      expect(d.target).toBeNull()
      expect(d.role).toBeNull()
      expect(d.why).toBeNull()
      expect(d.kcalBurn).toBeNull()
    }
  })
  it('spremenjen v počitek ni ključna seja', () => {
    const d = applyDayEdit(key, form({ kind: 'pocitek' }), [])
    expect(d.role).toBeNull()
    expect(d.target).toBeNull()
    expect(d.durationMin).toBe(0)
    expect(d.tssTarget).toBe(0)
    expect(d.zone).toBeNull()
  })
})

describe('onboardingDeficit', () => {
  it('400 kcal samo pri cilju »shujšati«, sicer 0', () => {
    expect(onboardingDeficit('shujsati', { deficit: 400, onboardingDone: false })).toBe(400)
    expect(onboardingDeficit('dirka', { deficit: 400, onboardingDone: false })).toBe(0)
    expect(onboardingDeficit('hitrejsi', { deficit: 400, onboardingDone: false })).toBe(0)
    expect(onboardingDeficit('forma', { deficit: 400, onboardingDone: false })).toBe(0)
    expect(onboardingDeficit(null, { deficit: 400, onboardingDone: false })).toBe(0)
  })
  it('ponovni uvod ohrani deficit, ki si ga že izbral', () => {
    expect(onboardingDeficit('shujsati', { deficit: 300, onboardingDone: true })).toBe(300)
  })
})

describe('byMonth', () => {
  const a = (id: string, date: string) => ({ id, date }) as Activity
  it('zaporedne skupine po mesecih z imenom meseca in letom', () => {
    const g = byMonth([a('1', '2026-09-20'), a('2', '2026-09-02'), a('3', '2026-08-30'), a('4', '2025-12-31')])
    expect(g.map(x => [x.label, x.items.length])).toEqual([['September 2026', 2], ['Avgust 2026', 1], ['December 2025', 1]])
  })
})

describe('profilePatch (Nastavitve → Profil)', () => {
  const p = { name: 'Blaž', sex: 'm', age: 21, heightCm: 180, weightKg: 79, maxHr: 200, restHr: 52, lthr: 184, ftp: 240, ftpDate: '2026-09-20', hoursPerWeek: 14, bodyFatPct: null } as unknown as Profile
  it('shrani samo spremenjena polja (FTP z druge naprave ostane)', () => {
    const init = formOf(p)
    expect(profilePatch(init, { ...init, weight: '78,5' }, p)).toEqual({ weightKg: 78.5 })
    expect(profilePatch(init, init, p)).toEqual({})
  })
  it('spremenjen FTP dobi današnji datum, izbrisan ohrani starega', () => {
    const init = formOf(p)
    const a = profilePatch(init, { ...init, ftp: '250' }, p)
    expect(a.ftp).toBe(250)
    expect(a.ftpDate).toMatch(/^\d{4}-\d{2}-\d{2}$/)
    expect(profilePatch(init, { ...init, ftp: '' }, p)).toEqual({ ftp: null, ftpDate: '2026-09-20' })
  })
})

describe('menuDayLow (tedenski jedilnik)', () => {
  const day = (x: Partial<MenuDay>) => ({ date: '2026-09-25', zajtrk: 'a', kosilo: 'b', malica: 'c', vecerja: 'd', kcal: 1900, proteinG: 120, ...x }) as MenuDay
  it('pod mejo ali z zastavico: ni priporočilo', () => {
    expect(menuDayLow(day({}), 2100)).toBe(true)
    expect(menuDayLow(day({ kcal: 2300, low: true }), 2100)).toBe(true)
    expect(menuDayLow(day({ kcal: 2300, belowFloor: true }), null)).toBe(true)
  })
  it('nad mejo ali že dopolnjen do meje: v redu', () => {
    expect(menuDayLow(day({ kcal: 2300 }), 2100)).toBe(false)
    expect(menuDayLow(day({ kcal: 2150, low: true, addKcal: 250 }), 2100)).toBe(false)
    expect(menuDayLow(day({ kcal: 0 }), 2100)).toBe(false)
  })
})
