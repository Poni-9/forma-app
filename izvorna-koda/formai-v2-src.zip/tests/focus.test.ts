import { describe, it, expect } from 'vitest'
import type { Activity, Focus, Profile } from '../src/domain/types'
import { normalizeFocus, profileFromFocus, modeOf, titleOf, weekLine, mixLine, isCustom } from '../src/domain/focus/model'
import { strengthWorkout, swapOptions, personalRecords, setsByMuscle, exByName, EXERCISES, limitsOf, candidates, equipFor } from '../src/domain/training/exercises'
import { scheduleWeek, buildFocusWeek, focusWeekContext } from '../src/domain/training/focusPlan'
import { buildWeek, weekContext } from '../src/domain/training/planner'
import { stepsFor } from '../src/domain/training/workout'

const NOW = '2026-10-07T08:00:00.000Z'
const base: Profile = { sex: 'm', age: 24, heightCm: 180, weightKg: 82, gear: { bikeOutdoor: false, trainer: false, noBike: true }, strength: { on: false, equipment: 'none' }, onboardingDone: true, createdAt: NOW, updatedAt: NOW }
/** primer iz Blaževega opisa: fitnes + malo teka, kondicija, zgornji del in trebuh, vitka a močna postava, mišice ostanejo */
const raw = {
  wish: 'Fitnes, malo teka, ful kondicije, samo zgornji del in six pack, vitka a močna postava, nočem izgubiti mišic pri hujšanju.',
  sports: ['fitnes', 'tek'], aims: ['definicija', 'hujsanje', 'kondicija', 'moc'], muscles: ['trebuh', 'prsa', 'roke'], level: 2, equipment: ['fitnes'],
  sessions: [
    { type: 'fitnes', part: 'potisk', min: 55 }, { type: 'tek', cardio: 'intervali', min: 35 }, { type: 'fitnes', part: 'poteg', min: 55 },
    { type: 'tek', cardio: 'lahko', min: 40 }, { type: 'fitnes', part: 'zgornji', min: 50 },
  ],
  notes: ['Trebušne mišice se vidijo pri nizkem deležu maščobe — za to šteje prehrana.'], title: 'Vitko, močno, v kondiciji',
}
const focus = () => normalizeFocus(raw, { age: 24, now: NOW, by: 'ai' })!
const custom = (f: Focus = focus()): Profile => ({ ...base, focus: f, cycleStart: '2026-10-05' })

describe('dogovor: preverjanje in varovalke', () => {
  it('veljaven dogovor: seje, mode po meri, mišice ostanejo (hujšanje + moč), ime', () => {
    const f = focus()
    expect(f.sessions).toHaveLength(5)
    expect(f.mode).toBe('meri')
    expect(f.keepMuscle).toBe(true)
    expect(f.title).toBe('Vitko, močno, v kondiciji')
    expect(f.days).toBe(5)
    expect(weekLine(f)).toBe('5 dni · ~4 h na teden')
    expect(mixLine(f)).toBe('Fitnes 3× · Tek 2×')
    expect(isCustom(custom(f))).toBe(true)
  })
  it('neveljavno → null; seja izven razpona se popravi; neznana vrsta izpade; začetnik največ 5 sej; teden do 20 h', () => {
    expect(normalizeFocus(null)).toBeNull()
    expect(normalizeFocus({ sessions: [{ type: 'joga', min: 30 }] })).toBeNull()
    const f = normalizeFocus({ sports: ['tek'], level: 1, sessions: Array.from({ length: 7 }, () => ({ type: 'tek', min: 999 })) })!
    expect(f.sessions).toHaveLength(5)
    expect(f.sessions.every(s => s.min <= 150)).toBe(true)
    const big = normalizeFocus({ sports: ['kolo'], level: 3, sessions: Array.from({ length: 7 }, () => ({ type: 'kolo', min: 300 })) })!
    expect(big.sessions.reduce((t, s) => t + s.min, 0)).toBeLessThanOrEqual(20 * 60)
    expect(big.mode).toBe('kolo')
  })
  it('pod 18 let brez hujšanja; v profil gre deficit 0', () => {
    const f = normalizeFocus(raw, { age: 16 })!
    expect(f.aims).not.toContain('hujsanje')
    const patch = profileFromFocus(f, { ...base, age: 16 }, '2026-10-05', '2026-10-07')
    expect(patch.deficit).toBe(0)
    expect(patch.goal).not.toBe('shujsati')
  })
  it('v profil: zmeren deficit pri ohranjanju mišic (350), beljakovine 2,0 g/kg, moč v fitnesu, ure, začetek bloka', () => {
    const patch = profileFromFocus(focus(), base, '2026-10-05', '2026-10-07')
    expect(patch).toMatchObject({ goal: 'shujsati', deficit: 350, proteinGkg: 2, hoursPerWeek: 4, strengthDays: 3, cycleStart: '2026-10-05', onboardingDone: true })
    expect(patch.strength).toMatchObject({ on: true, equipment: 'gym' })
  })
  it('kolesar s fitnesom: kolesarski način; ime iz ciljev', () => {
    expect(modeOf({ sessions: [{ type: 'kolo', min: 90 }, { type: 'kolo', min: 120 }, { type: 'fitnes', min: 45 }], aims: [] })).toBe('kolo')
    expect(titleOf({ sessions: [{ type: 'tek', min: 30 }], aims: ['kondicija'] })).toBe('Tek za kondicijo')
  })
})

describe('vaje in seje moči', () => {
  const opts = { where: 'fitnes' as const, equip: ['fitnes'] as const, level: 2 as const, aims: ['moc', 'definicija'] as const, muscles: ['trebuh', 'roke'] as const, min: 55, week: 1 }
  it('knjižnica: enolična imena in id-ji, vsaka vaja ima tehniko', () => {
    expect(new Set(EXERCISES.map(e => e.id)).size).toBe(EXERCISES.length)
    expect(new Set(EXERCISES.map(e => e.name)).size).toBe(EXERCISES.length)
    for (const e of EXERCISES) expect(e.how.length, e.name).toBeGreaterThan(25)
    expect(EXERCISES.length).toBeGreaterThanOrEqual(55)
  })
  it('fitnes, zgornji del s poudarkom roke in trebuh: potisk, poteg, roke in vaja za trebuh na koncu', () => {
    const w = strengthWorkout({ ...opts, part: 'zgornji' })
    const pats = w.exercises.map(e => exByName(e.name)!.pat)
    expect(pats).toContain('potiskV'); expect(pats).toContain('potegV')
    expect(pats.some(p => p === 'biceps' || p === 'triceps')).toBe(true)
    expect(pats[pats.length - 1]).toBe('trebuh')
    expect(w.exercises.length).toBeGreaterThanOrEqual(5)
    // moč: osnovna vaja 4 × 4–6 s pavzo 150 s
    expect(w.exercises[0]).toMatchObject({ sets: 4, reps: '4–6', rest: 150 })
  })
  it('doma brez opreme samo lastna teža; omejitev kolena izpusti izpadne korake in bolgarski počep; začetnik brez zahtevnih vaj', () => {
    const w = strengthWorkout({ ...opts, where: 'doma', equip: ['nic'], level: 1, part: 'spodnji', limits: 'boli me koleno', aims: ['zdravje'] })
    for (const e of w.exercises) {
      const d = exByName(e.name)!
      expect(d.eq, e.name).toBe('nic')
      expect(d.lvl, e.name).toBe(1)
      expect(d.avoid || [], e.name).not.toContain('koleno')
    }
    expect(limitsOf('Bolečine v križu in rami')).toEqual(['hrbet', 'rama'])
  })
  it('lažji teden: serija manj; izbor AI se upošteva, neveljavni id-ji izpadejo, manjkajoče dopolnijo pravila', () => {
    const a = strengthWorkout({ ...opts, part: 'potisk' }), b = strengthWorkout({ ...opts, part: 'potisk', light: true })
    expect(b.exercises[0]!.sets).toBe(a.exercises[0]!.sets - 1)
    const f = strengthWorkout({ ...opts, part: 'potisk', fixed: ['incline-r', 'ni-take', 'facepull', 'zgibi', 'triceps-k'] })
    // zgibi (hrbet) ne sodijo na dan potiska — izpadejo; premalo vaj za čas seje → manjkajoče vzorce dopolnijo pravila
    expect(f.exercises.slice(0, 3).map(e => e.name)).toEqual(['Potisk z ročkami na poševni klopi', 'Face pull na kablu', 'Iztegi za triceps na kablu'])
    expect(f.exercises.map(e => e.name)).not.toContain('Zgibi')
    expect(f.exercises.length).toBe(strengthWorkout({ ...opts, part: 'potisk' }).exercises.length)
    expect(new Set(f.exercises.map(e => e.name)).size).toBe(f.exercises.length)
    const home = strengthWorkout({ ...opts, part: 'potisk', where: 'doma', equip: ['nic'], fixed: ['bench', 'ohp'] })   // naprav doma ni
    expect(home.exercises.every(e => exByName(e.name)!.eq === 'nic')).toBe(true)
  })
  it('napredek: ko so bile vse serije na zgornji meji, je teža višja (ročke +2 kg, palica nad 40 kg +5 kg)', () => {
    const act = (name: string, kg: number, reps: string): Activity => ({ id: name, source: 'manual', sport: 'moc', date: '2026-10-01', name: 'Fitnes', aiEligible: true, geoRetain: false, createdAt: NOW, updatedAt: NOW, exercises: [{ name, sets: 3, reps, kg }] })
    const w = strengthWorkout({ ...opts, aims: ['misice'], part: 'potisk', fixed: ['incline-r', 'facepull', 'triceps-k'], activities: [act('Potisk z ročkami na poševni klopi', 20, '12, 12, 12')] })
    expect(w.exercises[0]).toMatchObject({ kg: 22.5 })
    expect(w.progressed).toEqual(['Potisk z ročkami na poševni klopi'])
    const w2 = strengthWorkout({ ...opts, aims: ['misice'], part: 'potisk', fixed: ['incline-r', 'facepull', 'triceps-k'], activities: [act('Potisk z ročkami na poševni klopi', 20, '12, 11, 9')] })
    expect(w2.exercises[0]).toMatchObject({ kg: 20 })
  })
  it('zamenjaj vajo: isti vzorec, druga oprema; v fitnesu tudi ročke', () => {
    const o = swapOptions('Potisk s palico na ravni klopi', { where: 'fitnes', equip: ['fitnes'], level: 2 })
    expect(o.length).toBeGreaterThan(1)
    expect(o.every(e => e.pat === 'potiskV')).toBe(true)
    expect(o.some(e => e.eq === 'utezi')).toBe(true)
    expect(candidates('potegN', { where: 'doma', equip: equipFor('doma', ['nic']), level: 3, limits: [] })).toEqual([])
  })
  it('osebni rekordi (ocenjeni 1RM) in serije po mišicah', () => {
    const a = (date: string, kg: number, reps: string): Activity => ({ id: date, source: 'manual', sport: 'moc', date, name: 'x', aiEligible: true, geoRetain: false, createdAt: NOW, updatedAt: NOW, exercises: [{ name: 'Počep s palico', sets: 3, reps, kg }] })
    const r = personalRecords([a('2026-09-01', 60, '8, 8, 8'), a('2026-10-01', 70, '5, 5, 5')])
    expect(r[0]).toMatchObject({ name: 'Počep s palico', kg: 70, date: '2026-10-01' })
    const m = setsByMuscle([{ name: 'Počep s palico', sets: 4 }, { name: 'Deska', sets: 3 }])
    expect(m).toMatchObject({ noge: 4, zadnjica: 2, trebuh: 3, prsa: 0 })
  })
})

describe('teden po meri', () => {
  it('razpored: 5 sej, izmenično moč in kardio, moč ne dva dni zapored na istih mišicah; dolgo na vikend', () => {
    const f = focus()
    const o = scheduleWeek(f.sessions, [0, 1, 2, 3, 4, 5, 6])
    const placed = o.filter(x => x != null)
    expect(placed).toHaveLength(5)
    for (let d = 1; d < 7; d++) {
      const a = o[d - 1], b = o[d]
      if (a == null || b == null) continue
      const sa = f.sessions[a]!, sb = f.sessions[b]!
      if (sa.type === 'fitnes' && sb.type === 'fitnes') expect([sa.part, sb.part].sort()).toEqual(['poteg', 'potisk'])
    }
    const long = scheduleWeek([{ type: 'fitnes', part: 'celo', min: 50 }, { type: 'hribi', min: 180 }, { type: 'fitnes', part: 'celo', min: 50 }], [0, 1, 2, 3, 4, 5, 6])
    expect(long.indexOf(1)).toBeGreaterThanOrEqual(5)
  })
  it('začetek sredi tedna: manj sej v preostale dni; želeni dnevi se upoštevajo', () => {
    const f = focus()
    const o = scheduleWeek(f.sessions, [3, 4, 5, 6])
    expect(o.filter(x => x != null).length).toBe(3)
    const p = scheduleWeek(f.sessions.slice(0, 3), [0, 1, 2, 3, 4, 5, 6], [1, 3, 5])
    expect([1, 3, 5].every(d => p[d] != null)).toBe(true)
  })
  it('skrajšan teden: vsaj en prost dan; največ 6 sej; nedelja in naslednji ponedeljek ne na istih mišicah', () => {
    const six = normalizeFocus({ sports: ['fitnes', 'tek'], level: 3, sessions: [
      { type: 'fitnes', part: 'potisk', min: 60 }, { type: 'tek', cardio: 'intervali', min: 35 }, { type: 'fitnes', part: 'poteg', min: 60 },
      { type: 'tek', cardio: 'lahko', min: 45 }, { type: 'fitnes', part: 'zgornji', min: 55 }, { type: 'tek', cardio: 'tempo', min: 30 }, { type: 'tek', cardio: 'lahko', min: 30 }] })!
    expect(six.sessions).toHaveLength(6)
    const wed = scheduleWeek(six.sessions, [2, 3, 4, 5, 6])
    expect(wed.filter(x => x != null).length).toBeLessThanOrEqual(4)
    expect([2, 3, 4, 5, 6].some(d => wed[d] == null)).toBe(true)
    expect(scheduleWeek(six.sessions, [0, 1, 2, 3, 4, 5, 6])[6]).toBeNull()
    const up = [{ type: 'fitnes', part: 'zgornji', min: 50 }, { type: 'tek', cardio: 'lahko', min: 40 }, { type: 'fitnes', part: 'zgornji', min: 50 }, { type: 'tek', cardio: 'lahko', min: 40 }] as const
    const o = scheduleWeek(up, [2, 3, 4, 5, 6])
    expect(o[6]).not.toBeNull()
    expect(up[o[6]!]!.type).toBe('tek')
  })
  it('ena različica iste vaje na sejo (ne sklece in sklece na kolenih hkrati)', () => {
    for (const week of [1, 2, 3]) {
      const w = strengthWorkout({ part: 'potisk', where: 'doma', equip: ['nic'], level: 3, aims: ['misice'], muscles: ['prsa'], min: 60, week })
      expect(w.exercises.filter(e => /^Sklece/.test(e.name)).length).toBeLessThanOrEqual(1)
    }
    const ai = strengthWorkout({ part: 'zgornji', where: 'fitnes', equip: ['fitnes'], level: 2, aims: ['moc'], muscles: [], min: 55, week: 1, fixed: ['sklece', 'sklece-kolena', 'zgibi', 'negativni', 'bench', 'kabel-v'] })
    expect(ai.exercises.map(e => e.name)).not.toContain('Sklece na kolenih')
    expect(ai.exercises.map(e => e.name)).not.toContain('Negativni zgibi')
  })
  it('odmerek: lastna teža več ponovitev, hujšanje z mišicami težke osnovne vaje', () => {
    const sk = strengthWorkout({ part: 'potisk', where: 'doma', equip: ['nic'], level: 2, aims: ['moc'], muscles: [], min: 40, week: 1, fixed: ['sklece', 'pike', 'sklece-noge'] })
    expect(sk.exercises.find(e => e.name === 'Sklece')!.reps).toBe('8–15')
    const cut = strengthWorkout({ part: 'potisk', where: 'fitnes', equip: ['fitnes'], level: 2, aims: ['definicija'], muscles: [], min: 50, week: 1, fixed: ['bench', 'incline-r', 'triceps-k'] })
    expect(cut.exercises[0]!.reps).toBe('6–10')
  })
  it('buildWeek za načrt po meri: 7 dni, fitnes z vajami, tek s cono, počitek, razlaga tedna; teden konteksta po meri', () => {
    const p = custom()
    const w = buildWeek({ profile: p, activities: [], weekStart: '2026-10-12', notBefore: '2026-10-12' })
    expect(w).toHaveLength(7)
    const gym = w.filter(d => d.kind === 'moc'), run = w.filter(d => d.kind === 'tek')
    expect(gym).toHaveLength(3); expect(run).toHaveLength(2)
    expect(gym.every(d => (d.exercises || []).length >= 4 && d.title.startsWith('Fitnes — '))).toBe(true)
    expect(run.some(d => /× \d min hitro/.test(d.title))).toBe(true)
    expect(w.filter(d => d.kind === 'pocitek')).toHaveLength(2)
    expect(w.find(d => d.kind !== 'pocitek')!.why).toMatch(/^Vitko, močno, v kondiciji · teden 2 \(rast\)/)
    expect(gym.some(d => /maščoba gre dol|mišice obdrži/.test(d.why || ''))).toBe(true)
    const cx = weekContext(p, '2026-10-12')
    expect(cx.custom).toBe(true); expect(cx.week).toBe(2); expect(cx.recovery).toBe(false)
  })
  it('4. teden bloka je lažji: manj serij in krajši kardio', () => {
    const p = custom()
    const hard = buildFocusWeek({ profile: p, activities: [], weekStart: '2026-10-19', notBefore: '2026-10-19' })
    const easy = buildFocusWeek({ profile: p, activities: [], weekStart: '2026-10-26', notBefore: '2026-10-26' })
    expect(focusWeekContext(p, '2026-10-26').recovery).toBe(true)
    const sets = (w: typeof hard) => w.filter(d => d.kind === 'moc').reduce((t, d) => t + (d.exercises || []).reduce((s, e) => s + e.sets, 0), 0)
    const runMin = (w: typeof hard) => w.filter(d => d.kind === 'tek').reduce((t, d) => t + d.durationMin, 0)
    expect(sets(easy)).toBeLessThan(sets(hard))
    expect(runMin(easy)).toBeLessThan(runMin(hard))
    expect(easy.some(d => /Lažji teden/.test(d.desc))).toBe(true)
  })
  it('izvajalnik: intervalni tek ima hitre dele in pavze, moč ima vaje s pavzo iz načrta', () => {
    const p = custom(normalizeFocus({ ...raw, level: 1 }, { age: 24 })!)
    const w = buildWeek({ profile: p, activities: [], weekStart: '2026-10-12', notBefore: '2026-10-12' })
    const iv = w.find(d => d.kind === 'tek' && /hitreje/.test(d.title))!
    const st = stepsFor(iv, p)
    expect(st.filter(s => s.kind === 'delo').length).toBeGreaterThanOrEqual(4)
    expect(st.some(s => s.label === 'Hoja')).toBe(true)
    const gym = w.find(d => d.kind === 'moc')!
    const gs = stepsFor(gym, p)
    expect(gs.filter(s => s.kind === 'vaja').length).toBe(gym.exercises!.reduce((t, e) => t + e.sets, 0))
  })
})
