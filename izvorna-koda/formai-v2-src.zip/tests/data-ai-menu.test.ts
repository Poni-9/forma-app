import 'fake-indexeddb/auto'
import { describe, it, expect, vi } from 'vitest'

const h = vi.hoisted(() => ({ json: {} as unknown, prompts: [] as string[] }))
vi.mock('../src/domain/ai/client', () => {
  class AiError extends Error { kind: string; constructor(kind: string, m: string) { super(m); this.kind = kind } }
  return {
    AiError,
    askText: async () => '',
    askJson: async (parts: { text?: string }[]) => { h.prompts.push(parts.map(p => p.text || '').join('\n')); return JSON.parse(JSON.stringify(h.json)) },
  }
})

import { weekMenu, addToChat, type Snapshot } from '../src/domain/ai/actions'
import { personalContext } from '../src/domain/ai/personal'
import { dailyTarget } from '../src/domain/nutrition/energy'
import { todayIso, addDays, weekStartIso } from '../src/domain/training/load'
import type { PlanDay, Profile } from '../src/domain/types'

const NOW = new Date().toISOString()
const today = todayIso(), ws = weekStartIso(today)
const profile: Profile = { sex: 'z', age: 28, weightKg: 58, heightCm: 165, ftp: 200, deficit: 500, goal: 'shujsati', targetWeightKg: 55, gear: { bikeOutdoor: true, trainer: false, noBike: false }, strength: { on: false, equipment: 'none' }, aiConsentAt: NOW, onboardingDone: true, createdAt: NOW, updatedAt: NOW }
const ride = (date: string, min: number): PlanDay => ({ id: 'p' + date, date, kind: 'kolo', title: 'Dolga Z2', desc: '', durationMin: min, zone: 'Z2', role: 'dolga', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null })

describe('jedilnik za teden: cilj po dnevu, varna meja', () => {
  it('cilj vsakega dne z načrtom tega dne (dan s treningom višji); dan pod varno mejo dobi dodatek in opozorilo', async () => {
    const plan = [ride(addDays(ws, 5), 240)]
    const s: Snapshot = { profile, activities: [], plan, today, extra: '' }
    // dan s treningom ima višji cilj — preverjeno na dnevih v prihodnosti (pretekli dan tega tedna brez vožnje šteje brez načrta)
    const plan2 = [ride(addDays(ws, 12), 240)]
    const restF = dailyTarget(profile, [], [], addDays(ws, 8), { today })!, longF = dailyTarget(profile, [], plan2, addDays(ws, 12), { today })!
    expect(longF.kcal).toBeGreaterThan(restF.kcal + 500)
    // vrstice v pozivu: enako kot weekMenu (danes = resnični danes)
    const rest = dailyTarget(profile, [], [], addDays(ws, 1), { today })!, long = dailyTarget(profile, [], plan, addDays(ws, 5), { today })!
    h.json = { dnevi: [
      { datum: addDays(ws, 1), zajtrk: 'Kaša', kosilo: 'Riž', malica: 'Jabolko', vecerja: 'Juha', kcal: 800, b: 60 },
      { datum: addDays(ws, 5), zajtrk: 'Kaša', kosilo: 'Testenine', malica: '', vecerja: 'Riž', kcal: long.kcal, b: 110 },
      { datum: addDays(ws, 6), zajtrk: 'Kaša', kosilo: 'Testenine', malica: 'Kruh', vecerja: 'Riž', kcal: 0, b: 0 },
    ], nakup: [] }
    const m = await weekMenu(s, 1234, 100, [])
    const prompt = h.prompts[h.prompts.length - 1]!
    expect(prompt).toContain(`${addDays(ws, 5)}: ${long.kcal} kcal (spodnja meja ${long.floor} kcal)`)
    expect(prompt).toContain(`${addDays(ws, 1)}: ${rest.kcal} kcal (spodnja meja ${rest.floor} kcal)`)
    expect(prompt).not.toContain('Osnovni dnevni cilj 1234')
    const low = m.days.find(d => d.date === addDays(ws, 1))!
    expect(low.low).toBe(true)
    expect(low.addKcal! % 50).toBe(0)
    expect(low.kcal).toBeGreaterThanOrEqual(rest.floor)
    expect(low.floorKcal).toBe(rest.floor); expect(low.targetKcal).toBe(rest.kcal)
    expect(low.malica).toMatch(/^Jabolko \+ dodatek do varne meje ~\d+ kcal/)
    const ok = m.days.find(d => d.date === addDays(ws, 5))!
    expect(ok.low).toBe(false); expect(ok.addKcal ?? null).toBeNull()
    const unknown = m.days.find(d => d.date === addDays(ws, 6))!
    expect(unknown.low).toBe(true); expect(unknown.addKcal ?? null).toBeNull()
    expect(m.lowDays).toEqual([addDays(ws, 1), addDays(ws, 6)])
    expect(m.note).toMatch(/varne meje/); expect(m.note).toMatch(/ni navedel kalorij/)
  })
})

describe('pogovor: strnitev samo ob uspešnem povzetku', () => {
  it('če povzetek ne uspe, se nič ne izgubi (ne skrajša)', async () => {
    const msgs = Array.from({ length: 40 }, (_, i) => ({ role: (i % 2 ? 'ai' : 'user') as 'ai' | 'user', text: 'm' + i, at: new Date(Date.UTC(2026, 8, 1, 0, i)).toISOString() }))
    const m = await addToChat({ msgs, summary: 'star' }, [{ role: 'user', text: 'novo', at: NOW }, { role: 'ai', text: 'odg', at: NOW }])
    // askText v tem preizkusu vrne prazen niz → povzetek »ni uspel«
    expect(m.msgs).toHaveLength(42); expect(m.summary).toBe('star'); expect(m.foldedTo ?? null).toBeNull()
  })
})

describe('osebni kontekst: hujšanje samo pri polnoletnem z deficitom', () => {
  const line = (o: Partial<Profile>) => personalContext({ profile: { ...profile, ...o }, activities: [], plan: [], checkins: [], recentMeals: [], today }).split('\n').find(l => l.startsWith('PREHRANA:'))!
  it('polnoleten z deficitom: 0,3–0,5 kg na teden', () => {
    expect(line({ age: 28, deficit: 500, weightKg: 70, targetWeightKg: 62 })).toMatch(/0,3–0,5 kg na teden/)
  })
  it('mladoleten: brez deficita, vzdrževanje; brez deficita: vzdrževanje; brez starosti: vzdrževanje', () => {
    const minor = line({ age: 16, deficit: 500, weightKg: 70, targetWeightKg: 62 })
    expect(minor).not.toMatch(/0,3–0,5|deficit \d/); expect(minor).toMatch(/mladoletni/); expect(minor).toMatch(/vzdržuje/)
    const none = line({ age: 30, deficit: 0, goal: 'dirka', weightKg: 70, targetWeightKg: null })
    expect(none).not.toMatch(/0,3–0,5/); expect(none).toMatch(/vzdrževanje/)
    const unknown = line({ age: null, deficit: 500 })
    expect(unknown).not.toMatch(/0,3–0,5/); expect(unknown).toMatch(/starost ni vpisana/)
  })
})
