import { describe, it, expect } from 'vitest'
import { formSeries, formReliable, historyDays, addDays, formBand } from '../src/domain/training/load'
import { goalStatus, hoursAdvice, weightSlope } from '../src/domain/training/goal'
import { FRANJA_2027 } from '../src/domain/training/planner'
import type { Activity, DailyCheckin, Profile } from '../src/domain/types'

const now = new Date().toISOString()
const ride = (date: string, tss: number, ext?: Activity['ext']): Activity => ({ id: date + tss, source: 'intervals', sport: 'kolo', date, name: 'v', durationMin: 120, tss, aiEligible: true, geoRetain: true, ...(ext ? { ext } : {}), createdAt: now, updatedAt: now } as Activity)

describe('forma (CTL/ATL) ne začne pri 0', () => {
  // 4 vožnje na teden po 100 TSS (~57 na dan), zgodovina le zadnjih n dni
  const hist = (n: number) => Array.from({ length: n }, (_, k) => addDays('2026-09-25', -n + k)).filter(d => [0, 2, 3, 6].includes(new Date(d + 'T12:00:00Z').getUTCDay())).map(d => ride(d, 100))
  it('nov uporabnik s 7 ali 14 dnevi ni »utrujen«: začetek = povprečni dnevni TSS', () => {
    for (const n of [7, 14, 28]) {
      const last = formSeries(hist(n), '2026-09-25').at(-1)!
      expect(last.ctl).toBeGreaterThan(40)
      expect(formBand(last.tsb).band).not.toBe('utrujen')
    }
  })
  it('začetno stanje iz intervals.icu pri najstarejši aktivnosti', () => {
    const acts = [ride('2026-09-20', 80, { icuCtl: 62, icuAtl: 70 }), ride('2026-09-22', 90)]
    const s = formSeries(acts, '2026-09-25')
    const first = s.find(x => x.date === '2026-09-20')!
    expect(first.ctl).toBeCloseTo(62, 5); expect(first.atl).toBeCloseTo(70, 5)
    expect(formReliable(acts, '2026-09-25')).toBe(true)
  })
  it('zanesljivost: vsaj 42 dni zgodovine', () => {
    expect(historyDays(hist(14), '2026-09-25')).toBeLessThan(42)
    expect(formReliable(hist(14), '2026-09-25')).toBe(false)
    expect(formReliable(hist(60), '2026-09-25')).toBe(true)
    expect(formReliable([], '2026-09-25')).toBe(false)
  })
  it('neveljaven datum ali TSS ne pokvari niza', () => {
    const s = formSeries([ride('2026-09-20', 80), { ...ride('', 50), date: '' }, { ...ride('2026-09-21', 0), tss: Number.NaN }], '2026-09-25')
    expect(s.length).toBeGreaterThan(0)
    expect(s.every(x => Number.isFinite(x.ctl) && Number.isFinite(x.atl))).toBe(true)
  })
})

describe('napoved teže in ur', () => {
  const p = { sex: 'm', age: 35, heightCm: 180, weightKg: 78, ftp: 250, gear: { bikeOutdoor: true, trainer: false, noBike: false }, strength: { on: false, equipment: 'none' }, onboardingDone: true, createdAt: now, updatedAt: now, event: { name: 'Franja', date: '2027-06-13' }, goalStart: { date: '2026-09-01', ftp: 250, weightKg: 78 } } as Profile
  it('dve tehtanji z razliko 1,6 kg nista trend (ne 139 kg na dan dirke)', () => {
    const ck: DailyCheckin[] = [{ date: '2026-09-12', weightKg: 77 }, { date: '2026-09-24', weightKg: 78.6 }]
    expect(goalStatus(p, ck, [], '2026-09-25').projectedWeight).toBeNull()
  })
  it('3+ tedne tehtanj: premica, največ ±0,5 kg na teden', () => {
    const ck = Array.from({ length: 25 }, (_, i) => ({ date: addDays('2026-09-01', i), weightKg: 80 - i * 0.2 }))   // −1,4 kg/teden → omejeno
    expect(weightSlope(ck, '2026-09-25')).toBe(-0.5)
    const g = goalStatus({ ...p, targetWeightKg: 45 }, ck, [], '2026-09-25')
    expect(g.projectedWeight).toBeCloseTo(g.weight! - 0.5 * g.weeksToEvent!, 0)
    expect(goalStatus({ ...p, targetWeightKg: 72 }, ck, [], '2026-09-25').projectedWeight).toBe(72)      // hujšanje ne pod ciljno težo
    const up = Array.from({ length: 22 }, (_, i) => ({ date: addDays('2026-09-03', i), weightKg: 75 + (i % 2) * 0.4 }))
    expect(Math.abs(weightSlope(up, '2026-09-25')!)).toBeLessThanOrEqual(0.5)
  })
  it('pretekla dirka ne omejuje predlaganih ur', () => {
    const acts = Array.from({ length: 20 }, (_, w) => [1, 3, 5].map(d => ride(addDays('2026-09-21', -7 * (w + 1) + d), 60))).flat().map(a => ({ ...a, durationMin: 150 }))
    const past = hoursAdvice(acts, { hoursPerWeek: 7, age: 35, event: { name: 'Pretekla', date: '2026-08-30' } }, '2026-09-25')
    const none = hoursAdvice(acts, { hoursPerWeek: 7, age: 35, event: null }, '2026-09-25')
    expect(past).toEqual(none)
    expect(past.limitedBy).not.toBe('time')
    expect(hoursAdvice(acts, { hoursPerWeek: 7, age: 35, event: { ...FRANJA_2027, date: '2026-11-15' } }, '2026-09-25').limitedBy).toBe('time')
  })
})
