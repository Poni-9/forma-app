// v3.50 POPRAVKI-UI (REVIEW-UI, zasloni z lažno shrambo): med premorom »Bolan sem« in »Spremeni premor« na Danes (U2),
// list »Ta teden …« po veljavnem premoru in brez »1. 11..« (U3), »Jedro po želji« enkrat ob dvojnem tapu (U11),
// »Ne« iz Prehrane velja tudi na Danes (U12), »Razveljavi« v skladu obvestil (U10), živi območji ostaneta v drevesu
// dostopnosti (U7), napaka »Ni povezave …« izgine ob vrnitvi povezave (U8).
// Shramba (U6, U8 usklajevanje, U12 autoMissed): tests/v350-popravki-ui-store.test.ts · App in usmerjevalnik (U4, U5, U9):
// tests/v350-popravki-ui-app.test.tsx · Predlog s slike (U11): tests/v350-popravki-ui-slika.test.tsx.
import 'fake-indexeddb/auto'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'danes', params: {} as Record<string, string> }, nav: [] as unknown[][] }))
vi.mock('@/state/store', async () => {
  const { vi: v } = await import('vitest')
  const base: Record<string | symbol, unknown> = {
    useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
    getState: () => S.state,
    routePace: () => ({ k: 1, adj: { n: 0, adj: 1 } }),
    stateToday: () => ({ level: 0, legs: false, reasons: [] }),
    toast: v.fn(),
    LAST_EXPORT_KEY: 'backup.lastExportAt',
  }
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' || typeof k === 'symbol' ? undefined : (t[k] = v.fn(async () => undefined))), has: (_t, k) => k !== 'then' })
})
vi.mock('@/app/router', () => ({ navigate: (...a: unknown[]) => { S.nav.push(a) }, useRoute: () => S.route }))
vi.mock('@/app/Shell', () => ({ Head: () => null }))
vi.mock('@/ui/useAi', () => ({ useAi: () => ({ busy: false, signedIn: false, consent: false, run: async (fn: () => Promise<unknown>) => fn(), sheet: null }) }))
vi.mock('@/state/snap', () => ({ snapOf: () => ({}) }))
vi.mock('@/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import { Danes } from '@/screens/Danes'
import { WeekPauseSheet, PauseOffer } from '@/ui/WeekPauseSheet'
import { YesterdayRate } from '@/ui/YesterdayRate'
import { Toasts } from '@/ui/Toasts'
import { UndoHost, undoToast, _resetUndo } from '@/ui/Confirm'
import { markNo, saidNo, noIdsOn } from '@/state/noAsk'
import * as store from '@/state/store'
import type { PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-21', YDAY = '2026-10-20'   // sreda
const NOW = `${TODAY}T08:00:00.000Z`
const P = { sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, ftpDate: '2026-09-14', lthr: 184, maxHr: 195, restHr: 48, gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, strength: { on: true, equipment: 'home' }, strengthDays: 2, onboardingDone: true, hoursPerWeek: 8, goal: 'forma', createdAt: '2026-08-01T08:00:00.000Z', updatedAt: NOW } as unknown as Profile
const day = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: date + (o.kind || 'kolo') + (o.title || ''), date, kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, zone: 'Z2', role: 'lahka', tssTarget: 42, source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })
const premor = (date: string) => day(date, { kind: 'pocitek', title: 'Premor', desc: 'Brez treningov — premor po tvoji izbiri.', durationMin: 0, zone: null, tssTarget: 0, role: null })
const rest = day(TODAY, { kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, tssTarget: 0, role: null })
const yRide = day(YDAY, { title: 'Tempo 3 × 10 min', role: 'kljucna', zone: 'Z3', durationMin: 75 })
const reset = (plan: PlanDay[], o: Record<string, unknown> = {}) => {
  S.state = { ready: true, today: TODAY, plan, activities: [], recentMeals: [], mealsToday: [], checkins: [], checkinToday: null, weather: null, wellness: null, routeLib: null, routesBusy: false, icuDiag: null, settings: { lang: 'sl', intervals: null, coach: { msgs: [], summary: null }, startDone: true, guideSeen: true, tests: [] }, toast: null, toasts: [], profile: P, user: null, authKnown: true, firstSync: null, changes: [], sync: { state: 'ok' }, ...o }
  S.subs.forEach(f => f())
}
const fn = (k: string) => (store as unknown as Record<string, ReturnType<typeof vi.fn>>)[k]!
let div: HTMLDivElement | null = null, root: Root | null = null
const flush = async () => { for (let i = 0; i < 6; i++) await act(async () => { await Promise.resolve() }) }
async function render(el: ReactElement) { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div); await act(async () => { root!.render(el) }); await flush(); return div }
const sp = (x: string | null | undefined) => (x || '').replace(/⁠/g, '').replace(/[  ]/g, ' ')
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(sp(b.textContent))) as HTMLButtonElement | undefined
const sheetText = () => sp([...document.querySelectorAll('.sheet')].map(e => e.textContent).join(' '))

beforeEach(() => { sessionStorage.clear(); localStorage.clear(); S.subs.clear(); S.nav = []; window.scrollTo = vi.fn() as never; vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date(2026, 9, 21, 9, 0)) })
afterEach(async () => { if (root) { await act(async () => root!.unmount()); root = null } div?.remove(); document.body.innerHTML = ''; vi.useRealTimers() })

describe('U2 Danes med premorom brez treningov', () => {
  it('kartica premora ima »Spremeni premor« (list »Ta teden …«) in »Bolan sem« (list bolezni)', async () => {
    reset([premor(TODAY), premor('2026-10-22')], { profile: { ...P, weekPause: { from: TODAY, to: '2026-10-25', mode: 'vse' } } })
    await render(<Danes />)
    expect(sp(document.body.textContent)).toMatch(/Premor · danes/)
    expect(btn(/^Spremeni premor$/)).toBeTruthy()
    await act(async () => { btn(/^Spremeni premor$/)!.click() })
    expect(sheetText()).toMatch(/Ta teden …/)
    expect(sheetText()).toMatch(/Zdaj velja: premor do nedelje\./)
    await act(async () => { btn(/^Zapri$/)!.click() })
    expect(btn(/^Bolan sem$/)).toBeTruthy()
    await act(async () => { btn(/^Bolan sem$/)!.click() })
    expect(sheetText()).toMatch(/Bolan sem — počitek/)
  })
  it('list brez onSick (Plan, trener): pri razlogu »bolan« gumb »Bolan sem« odpre list bolezni', async () => {
    reset([premor(TODAY)], { profile: { ...P, weekPause: { from: TODAY, to: '2026-10-25', mode: 'vse' } } })
    await render(<WeekPauseSheet open onClose={() => undefined} />)
    await act(async () => { btn(/^bolan$/)!.click() })
    expect(btn(/^Bolan sem$/)).toBeTruthy()
    await act(async () => { btn(/^Bolan sem$/)!.click() })
    expect(sheetText()).toMatch(/Bolan sem — počitek/)
  })
})

describe('U3 list »Ta teden …« z veljavnim premorom', () => {
  it('dvotedenski premor z razlogom: izbrano »Še naslednji teden« in razlog; sprememba načina ga ne skrajša; brez »1. 11..«', async () => {
    fn('setWeekPause').mockClear()
    reset([premor(TODAY)], { profile: { ...P, weekPause: { from: TODAY, to: '2026-11-01', mode: 'vse', reason: 'potovanje' } } })
    await render(<WeekPauseSheet open onClose={() => undefined} />)
    expect(sheetText()).toMatch(/Zdaj velja: premor do nedelje, 1\. 11\. Spodaj/)
    expect(sheetText()).not.toMatch(/11\.\./)
    expect(btn(/Še naslednji teden/)!.getAttribute('aria-pressed')).toBe('true')
    expect(btn(/^potovanje$/)!.getAttribute('aria-pressed')).toBe('true')
    expect(sheetText()).toMatch(/Brez kolesa do nedelje, 1\./)
    await act(async () => { btn(/Brez kolesa/)!.click() })
    await flush()
    expect(fn('setWeekPause').mock.calls[0]).toEqual(['kolo', { twoWeeks: true, reason: 'potovanje' }])
  })
  it('trener »ta teden nočem nič« med premorom brez kolesa: »Uveljavi …« obdrži razlog', async () => {
    fn('setWeekPause').mockClear()
    reset([premor(TODAY)], { profile: { ...P, weekPause: { from: TODAY, to: '2026-10-25', mode: 'kolo', reason: 'potovanje' } } })
    await render(<PauseOffer mode="vse" />)
    await act(async () => { btn(/^Uveljavi: ta teden brez treningov$/)!.click() })
    await flush()
    expect(fn('setWeekPause').mock.calls[0]).toEqual(['vse', { twoWeeks: false, reason: 'potovanje' }])
  })
  it('list ostane izrisan zaprt (Danes): ob odprtju po premoru, ki velja takrat', async () => {
    reset([premor(TODAY)])
    function Host({ open }: { open: boolean }) { return <WeekPauseSheet open={open} onClose={() => undefined} /> }
    await render(<Host open={false} />)
    await act(async () => { reset([premor(TODAY)], { profile: { ...P, weekPause: { from: TODAY, to: '2026-11-01', mode: 'kolo', reason: 'volja' } } }) })
    await act(async () => { root!.render(<Host open />) })
    expect(btn(/Še naslednji teden/)!.getAttribute('aria-pressed')).toBe('true')
    expect(btn(/^brez volje$/)!.getAttribute('aria-pressed')).toBe('true')
  })
})

describe('U11 Danes: »Jedro po želji (20 min)«', () => {
  it('dvojni tap → addCore enkrat', async () => {
    reset([rest])
    const addCore = fn('addCore')
    addCore.mockClear(); addCore.mockImplementation(() => new Promise(r => setTimeout(r, 40)))
    await render(<Danes />)
    const b = btn(/Jedro po želji/)!
    await act(async () => { b.click(); b.click(); await new Promise(r => setTimeout(r, 80)) })
    expect(addCore.mock.calls.length).toBe(1)
  })
})

describe('U12 »Ne« pri »Si ga opravil?« v Prehrani velja tudi na Danes', () => {
  it('zapis Prehrane (prejšnja oblika) → Danes naslednje jutro ne vpraša »Včeraj: … — si ga naredil?«', async () => {
    localStorage.setItem('formai.missedNo', JSON.stringify({ date: YDAY, ids: [yRide.id] }))
    reset([yRide])
    await render(<YesterdayRate />)
    expect(sp(document.body.textContent)).not.toMatch(/si ga naredil\?/)
  })
  it('skupen zapis: Prehrana (markNo) → Danes; »Ne« na Danes velja tudi naslednji dan (predvčerajšnjim)', async () => {
    markNo(yRide.id, YDAY)
    expect(saidNo(yRide.id)).toBe(true)
    expect(noIdsOn(YDAY)).toEqual([yRide.id])
    reset([yRide])
    await render(<YesterdayRate />)
    expect(sp(document.body.textContent)).not.toMatch(/si ga naredil\?/)
    await act(async () => root!.unmount()); root = null
    // »Ne« na Danes za torkov trening → v četrtek ga ne vpraša znova (prej ključ samo za današnji dan)
    localStorage.clear()
    const tue = day('2026-10-20', { title: 'Lahek tek', kind: 'tek', zone: 'Z2' })
    reset([tue])
    await render(<YesterdayRate />)
    await act(async () => { btn(/^Ne$/)!.click() })
    await act(async () => root!.unmount()); root = null
    vi.setSystemTime(new Date(2026, 9, 22, 9, 0))
    reset([tue], { today: '2026-10-22' })
    await render(<YesterdayRate />)
    expect(sp(document.body.textContent)).not.toMatch(/Torek: Lahek tek — si ga naredil\?/)
  })
})

describe('U10 »Razveljavi« v skladu obvestil', () => {
  it('UndoHost izriše obvestilo v .toast-stack (za napako, ki ostane vidna), ne čez njo', async () => {
    _resetUndo()
    reset([], { toasts: [{ id: 1, kind: 'err', msg: 'Oblak ne sprejema sprememb od 21:13 — prijavi se znova.' }] })
    await render(<><Toasts /><UndoHost /></>)
    await act(async () => { undoToast('Danes lahko. Tempo gre na petek.', () => undefined, { ms: 60_000 }) })
    const undo = document.querySelector('.toast.undo')
    expect(undo).toBeTruthy()
    expect(undo!.parentElement?.classList.contains('toast-stack')).toBe(true)
    expect(document.querySelector('.toast-stack')!.lastElementChild).toBe(undo)
    _resetUndo()
  })
})

describe('U7 prazni živi območji obvestil', () => {
  it('sta vedno izrisani; CSS jih ne skrije z display: none (bralnik zaslona)', async () => {
    reset([])
    await render(<Toasts />)
    expect([...document.querySelectorAll('.toast-live')].map(e => e.getAttribute('role'))).toEqual(['alert', 'status'])
    const css = readFileSync(resolve(process.cwd(), 'src/styles/base.css'), 'utf8')
    const rule = /\.toast-stack \.toast-live:empty\s*\{([^}]*)\}/.exec(css)
    expect(rule).toBeTruthy()
    expect(rule![1]).not.toMatch(/display:\s*none/)
    expect(rule![1]).toMatch(/clip-path: inset\(50%\)/)
  })
})

describe('U8 napaka »Ni povezave z internetom …« ob vrnitvi povezave', () => {
  it('dogodek online zapre to napako, druge ostanejo', async () => {
    const dismiss = fn('dismissToast')
    dismiss.mockClear()
    reset([], { toasts: [{ id: 7, kind: 'err', msg: 'Ni povezave z internetom — AI potrebuje povezavo. Poskusi, ko boš spet na spletu.' }, { id: 8, kind: 'err', msg: 'Vpiši utrip med 40 in 220.' }] })
    await render(<Toasts />)
    await act(async () => { window.dispatchEvent(new Event('online')) })
    expect(dismiss.mock.calls).toEqual([[7]])
  })
})
