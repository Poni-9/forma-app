// v3.51 TRENER-FOCUS — trener (klepet, premor, pozivi), načrt po meri (pogajanje brez AI), Claude prosti načrt
import { describe, it, expect, vi, beforeEach } from 'vitest'

const sent: string[] = []
vi.mock('@/domain/ai/client', async (orig) => {
  const m = await orig<typeof import('@/domain/ai/client')>()
  return {
    ...m,
    askText: vi.fn(async (parts: { text?: string }[]) => { sent.push(parts.map(p => p.text || '').join('\n')); return 'Razumem.' }),
    askJson: vi.fn(async (parts: { text?: string }[]) => { sent.push(parts.map(p => p.text || '').join('\n')); return (globalThis as any).__json ?? {} }),
  }
})
vi.mock('@/data/db', async (orig) => { const m = await orig<typeof import('@/data/db')>(); return { ...m, getKV: vi.fn(async (k: string) => ((globalThis as any).__kv || {})[k] ?? null), setKV: vi.fn(async () => {}) } })
vi.mock('@/domain/ai/image', async (orig) => { const m = await orig<typeof import('@/domain/ai/image')>(); return { ...m, fileToBase64Resized: vi.fn(async () => ({ data: 'AAAA', mime: 'image/jpeg', thumb: '' })), exifStamp: vi.fn(async () => null) } })

import { pauseIntent, pauseEndIntent, sickIntent } from '@/domain/training/pause'
import { looksIntent, bodyFatView } from '@/domain/coach/bodyfat'
import { exercisesIn } from '@/domain/coach/exmention'
import { localReview, localAdvice } from '@/domain/coach/local'
import { personalContext } from '@/domain/ai/personal'
import { aiContext, coachDailyPrompt, weeklyReviewPrompt, ADAPT_SCHEMA_HINT } from '@/domain/ai/prompts'
import { CLAUDE_SYSTEM } from '@/domain/ai/claudePlan'
import { strengthWorkout } from '@/domain/training/exercises'
import { chat, adaptWeek, fridgeMeals, mealIdeas, monthReview, weeklyReview, PAUSE_NOTHING } from '@/domain/ai/actions'
import { focusContext, needToKnow } from '@/domain/ai/focusAi'
import { adaptDone } from '@/domain/ai/coachchat'
import { quick, quickCustom } from '@/screens/Trener'
import { buildWeek } from '@/domain/training/planner'
import { addDays, weekStartIso } from '@/domain/training/load'
import { composeWish } from '@/domain/focus/choices'
import { ruleQuestions, ruleProposal, ruleAdjust, adjustNote } from '@/domain/focus/rules'
import { coachReview, planInputs } from '@/domain/focus/coach'
import { profileFromFocus } from '@/domain/focus/model'
import { sanitizeGaps } from '@/domain/ai/sanitize'

const NOW = '2026-10-23T10:00:00.000Z'
const blank: any = { name: 'X', sex: 'm', age: 30, heightCm: 180, weightKg: 80, restHr: null, maxHr: null, lthr: null, ftp: null, ftpDate: null, goal: 'forma', gear: { bikeOutdoor: false, trainer: false, noBike: true, powerMeter: null }, hoursPerWeek: 4, hoursMode: 'own', strength: { on: false, equipment: 'none' }, strengthDays: 0, deficit: 0, neat: 1.4, proteinGkg: 1.6, event: null, races: [], level: 1, onboardingDone: true, createdAt: '2026-10-01T08:00:00.000Z', updatedAt: '2026-10-01T08:00:00.000Z', aiConsentAt: NOW, aiConsentV: 3 }
const kolesar: any = { ...blank, sex: 'm', age: 40, heightCm: 178, weightKg: 82, ftp: 210, ftpDate: '2026-09-01', lthr: 165, maxHr: 182, goal: 'forma', gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, hoursPerWeek: 5, level: 2, cycleStart: '2026-10-05' }
const hujsa: any = { ...blank, sex: 'z', age: 45, heightCm: 168, weightKg: 78, goal: 'shujsati', deficit: 400, gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, level: 1, cycleStart: '2026-10-05' }
function weeksOf(p: any, today: string) {
  const ws = weekStartIso(today)
  return [-7, 0, 7].flatMap(k => buildWeek({ profile: p, activities: [], weekStart: addDays(ws, k), notBefore: addDays(ws, k), today: addDays(ws, k) } as any))
}
const lc = (p: any, plan: any[], today: string, activities: any[] = []): any => ({ profile: p, plan, activities, checkins: [], checkinToday: null, wellness: null, wellnessOn: false, mealsToday: [], recentMeals: [], weather: null, today })
function custom(o: { picks: Record<string, string[]>; text?: string; answers: Record<string, string>; base: any }) {
  const today = '2026-10-18'
  const wish = composeWish(o.picks, o.text || '')
  const qs = ruleQuestions(wish, { avail: null, today, event: null })
  const qa = qs.questions.map(q => ({ id: q.id, q: q.text, a: o.answers[q.id] ?? (q.options[0] || '') }))
  const pr = ruleProposal(wish, qa, o.base.age, { avail: null, today, body: o.base } as any)
  const { opts } = planInputs({ picks: o.picks, wish, qa, age: o.base.age, main: 'oboje', avail: null } as any)
  const rv = coachReview({ ...pr.focus, main: 'oboje' }, opts)
  return { wish, qa, f: rv.focus, p: { ...o.base, ...profileFromFocus(rv.focus, o.base, weekStartIso(today), today) } }
}
/** cela pot pogajanja brez AI kot v Sestavi: ruleAdjust → coachReview */
function negotiate(c: any, x: ReturnType<typeof custom>, fb: string) {
  const adj = ruleAdjust(x.f, fb, c.base.age)
  const { opts } = planInputs({ picks: c.picks, wish: x.wish, qa: x.qa, feedback: fb, age: c.base.age, main: 'oboje' } as any)
  return { adj, note: adj ? adjustNote(x.f, adj) : null, rev: coachReview({ ...(adj ?? x.f), main: 'oboje' }, opts).focus }
}
const DOMA = { picks: { cilj: ['Boljša kondicija', 'Zdravje in počutje'], delam: ['Vadba doma'], raven: ['Začenjam'] }, answers: { dni: '3', cas: '30 min', kje: 'Nič', nedni: 'Vsi gredo', poskodbe: 'Ne' }, base: { ...blank, sex: 'z', age: 45, heightCm: 168, weightKg: 66 } }
const MLAD = { picks: { cilj: ['Manj kilogramov', 'Več mišic in moči'], delam: ['Vadba doma'], raven: ['Začenjam'], postava: ['Six pack'] }, text: 'Rad bi shujšal in imel six pack.', answers: { dni: '3', cas: '30 min', kje: 'Nič', nedni: 'Vsi gredo', poskodbe: 'Ne' }, base: { ...blank, sex: 'm', age: 16, heightCm: 172, weightKg: 70 } }
const ZEN = { picks: { cilj: ['Manj kilogramov'], delam: ['Fitnes'], raven: ['Občasno'], postava: ['Vitka in močna'] }, answers: { dni: '4', cas: '45 min', poudarek: 'Noge in zadnjica', nedni: 'Vsi gredo', poskodbe: 'Ne' }, base: { ...blank, sex: 'z', age: 34, heightCm: 165, weightKg: 72 } }
const TEK = { picks: { cilj: ['Manj kilogramov', 'Boljša kondicija'], delam: ['Tek'], raven: ['Začenjam'], tek: ['Začenjam s tekom'] }, answers: { dni: '3', cas: '30 min', nedni: 'Vsi gredo', poskodbe: 'Ne' }, base: { ...blank, sex: 'm', age: 38, heightCm: 178, weightKg: 95 } }
const strava: any = { id: 's1', source: 'strava', sport: 'kolo', date: '2026-10-20', durationMin: 60, aiEligible: false, originHint: 'strava', createdAt: NOW, updatedAt: NOW }

beforeEach(() => { sent.length = 0; (globalThis as any).__json = undefined; (globalThis as any).__kv = undefined })

describe('premor v klepetu (C03, C22, C23, C32, B04, B14)', () => {
  it.each([
    ['Ta teden ne treniram', 'vse'],
    ['ta teden ne treniram, sem na morju', 'vse'],
    ['Ta teden nimam časa za trening', 'vse'],
    ['ta teden ne utegnem', 'vse'],
    ['Ta teden nič treningov', 'vse'],
    ['Ta teden počitek.', 'vse'],
    ['ta teden mi ni do treninga', 'vse'],
    ['ta teden grem na dopust', 'vse'],
    ['Ta teden sem na dopustu.', 'vse'],
    ['do nedelje me ne bo', 'vse'],
    ['pavza ta teden', 'vse'],
    ['Do nedelje sem na morju, kolo ostane doma.', 'kolo'],
    ['ta teden bom samo tekel', 'kolo'],
    ['ta teden bom samo tekel, kolo ne', 'kolo'],
  ] as const)('»%s« → %s', (t, mode) => {
    expect(pauseIntent(t)?.mode, t).toBe(mode)
  })
  it.each([
    'Ta teden ne bom treniral moči.', 'Ta teden izpustim moč.', 'Ta teden preskoči VO2max.', 'Ta teden ne bom vozil intervalov, samo Z2.',
    'Ta teden ne bom kolesaril zunaj, samo trenažer.', 'Ta teden ne bom vozil avta, hodim peš.', 'Ta teden ne bom več jedel sladkarij.',
    'Ta teden nočem več deficita.', 'Ta teden ne bom nič spremenil pri prehrani.', 'Ta teden ne morem več kot 3 ure.',
    'ta teden ne bom vadil, bom pa kolesaril', 'ta teden nimam časa za počitek', 'ta teden sem bil na dopustu', 'Ali naj ta teden počivam?',
    'ta teden ne bom vozil v službo', 'Ta teden sem bolan.',
  ])('»%s« → ni premor', t => {
    expect(pauseIntent(t), t).toBeNull()
  })
  it('dva tedna iz besed', () => {
    expect(pauseIntent('ta teden in naslednjega ne bom treniral')).toEqual({ mode: 'vse', twoWeeks: true })
    expect(pauseIntent('Dva tedna ne bom treniral')).toEqual({ mode: 'vse', twoWeeks: true })
    expect(pauseIntent('ta teden ne bom treniral')).toEqual({ mode: 'vse', twoWeeks: false })
  })
  it('konec premora in bolezen', () => {
    for (const t of ['prekliči premor', 'Ta teden pa vseeno treniram.', 'spet bom treniral', 'končaj premor', 'premor je mimo']) expect(pauseEndIntent(t), t).toBe(true)
    for (const t of ['ta teden nočem nič', 'kako dolg je premor?', 'Kaj danes?']) expect(pauseEndIntent(t), t).toBe(false)
    expect(sickIntent('Ta teden sem bolan.')).toBe(true)
    expect(sickIntent('Imam vročino')).toBe(true)
    expect(sickIntent('ta teden nočem nič')).toBe(false)
  })
})

describe('premor ob skritih vadbah — ločena pot (C01, C31, C23)', () => {
  // (v3.51 POPRAVKI51-TR, R10) brez opombe o nadomestnih besedah — premor samo kot dejstvo, vrstico doda aplikacija
  it('nov premor s Stravo: poziv brez opombe o besedah; sanitizeGaps ostane nespremenjen', async () => {
    await chat({ profile: kolesar, activities: [strava], plan: [], today: '2026-10-23' }, 'Ta teden nočem nič.', { msgs: [], summary: null })
    expect(sent[0]).not.toContain('OPOMBA O BESEDAH')
    expect(sent[0]).toContain('pod tvojim odgovorom je gumb »Uveljavi: ta teden brez treningov«')
    // varovalka še vedno pobriše stavke z »premor« (regex ni spremenjen)
    expect(sanitizeGaps('Razumem. Premor uveljaviš z gumbom spodaj.', true)).toBe('Razumem.')
    // besede, ki jih opomba predlaga, ostanejo
    expect(sanitizeGaps('Ta teden počiješ — teden brez kolesa je v redu.', true)).toBe('Ta teden počiješ — teden brez kolesa je v redu.')
  })
  it('brez skritih vadb ni opombe o besedah', async () => {
    await chat({ profile: kolesar, activities: [], plan: [], today: '2026-10-23' }, 'Ta teden nočem nič.', { msgs: [], summary: null })
    expect(sent[0]).not.toContain('OPOMBA O BESEDAH')
  })
  it('premor že velja: brez obljube gumba (C31), kontekst ob Stravi brez opombe o besedah', async () => {
    const p = { ...kolesar, weekPause: { mode: 'vse', from: '2026-10-19', to: '2026-10-25', reason: null, at: NOW } }
    await chat({ profile: p, activities: [strava], plan: [], today: '2026-10-23' }, 'Ta teden nočem nič.', { msgs: [], summary: null })
    expect(sent[0]).not.toContain('je gumb »Uveljavi')
    expect(sent[0]).toContain('premor po njegovi izbiri že velja (do nedelje)')
    expect(sent[0]).not.toContain('OPOMBA O BESEDAH')
  })
  it('»prekliči premor« ob veljavnem premoru: opomba o gumbu »Prekliči premor« (C23)', async () => {
    const p = { ...kolesar, weekPause: { mode: 'kolo', from: '2026-10-19', to: '2026-10-25', reason: null, at: NOW } }
    await chat({ profile: p, activities: [], plan: [], today: '2026-10-23' }, 'Prekliči premor, vseeno bom treniral.', { msgs: [], summary: null })
    expect(sent[0]).toContain('gumb »Prekliči premor«')
  })
})

describe('lestvica maščobe in vaje v odgovoru (C24, C25, C26, C37, C38)', () => {
  it('vprašanja o trebuhu dobijo lestvico, bolečina ne', () => {
    for (const q of ['Kako izgubim trebuh?', 'kako se znebim trebuha', 'Kako shujšam v trebuhu?', 'kako se znebim ljubezenskih ročajev', 'kdaj se mi bodo videle kocke', 'kako zmanjšam obseg pasu']) expect(looksIntent(q), q).toBe(true)
    for (const q of ['Boli me trebuh po teku', 'koliko jušnih kock v juho', 'Kaj danes?']) expect(looksIntent(q), q).toBe(false)
  })
  it('moški 17 % o pasu: že v razponu ploščatega trebuha, brez časa', () => {
    const v = bodyFatView({ sex: 'm', age: 30, heightCm: 180, weightKg: 75, bodyFatPct: 17 } as any, 75, 'kako izgubim maščobo okoli pasu?') as any
    expect(v.target).toEqual({ lo: 15, hi: 20 })
    expect(v.months).toBeNull()
    expect(v.lines[0]).toMatch(/Za ploščat trebuh si že v razponu/)
    expect(v.steps.join(' ')).not.toMatch(/naj pada/)
  })
  it('v razponu: »Teža naj ostane stabilna«, nad razponom »Teža naj pada«', () => {
    const v = bodyFatView({ sex: 'm', age: 30, heightCm: 180, weightKg: 75, bodyFatPct: 11 } as any, 75, 'six pack?') as any
    expect(v.steps.join(' ')).toMatch(/Teža naj ostane stabilna/)
    const w = bodyFatView({ sex: 'm', age: 30, heightCm: 180, weightKg: 90, bodyFatPct: 24 } as any, 90, 'six pack?') as any
    expect(w.steps.join(' ')).toMatch(/Teža naj pada 0,3–0,5 kg/)
  })
  it('vaje, ki jih odgovor odsvetuje, nimajo ploščic', () => {
    expect(exercisesIn('Danes brez počepov in izpadnih korakov — noge naj se spočijejo. Namesto tega deska.', 3).map(e => e.name)).toEqual(['Deska'])
    expect(exercisesIn('Ne delaj mrtvega dviga, dokler te boli hrbet.', 3)).toEqual([])
    expect(exercisesIn('Danes počep 3 × 10 in deska.', 3).map(e => e.name)).toEqual(['Počep', 'Deska'])
  })
})

describe('Claude prosti načrt: varovalke (C04, C10)', () => {
  it('16-letnik z bolečim hrbtom: mrtvi dvig in negativni zgibi izpadejo, težke serije po pravilih', () => {
    const w = strengthWorkout({ part: 'celo', where: 'fitnes', equip: ['fitnes'], level: 1, aims: ['moc'], muscles: [], min: 45, week: 1, limits: 'hrbet', minor: true, free: true, plan: [{ id: 'mrtvi', sets: 4, reps: '4–6', rest: 180, kg: 60 }, { id: 'negativni', sets: 4, reps: '5', rest: 120, kg: null }, { id: 'goblet', sets: 4, reps: '5', rest: 120, kg: 16 }] as any })
    const names = w.exercises.map(e => e.name)
    expect(names).not.toContain('Mrtvi dvig')
    expect(names.some(n => /Negativni/.test(n))).toBe(false)
    expect(names.length).toBeGreaterThan(0)
    for (const e of w.exercises) expect(Number(String(e.reps).match(/\d+/)?.[0] ?? 99)).toBeGreaterThanOrEqual(8)
  })
  it('odrasel brez omejitev: Claudove vaje in ponovitve ostanejo', () => {
    const w = strengthWorkout({ part: 'celo', where: 'fitnes', equip: ['fitnes'], level: 2, aims: ['moc'], muscles: [], min: 45, week: 1, free: true, plan: [{ id: 'mrtvi', sets: 4, reps: '4–6', rest: 180, kg: 60 }] as any })
    expect(w.exercises.map(e => `${e.name} ${e.sets}×${e.reps}`)).toEqual(['Mrtvi dvig 4×4–6'])
  })
  it('slike postave brez roka', () => {
    expect(CLAUDE_SYSTEM).not.toContain('v kakšnem času')
    expect(CLAUDE_SYSTEM).toContain('roka zanj ne obljubljaj')
  })
})

describe('pogajanje brez AI (C07, C18, C19, C20, C21, C30, C50)', () => {
  const fast = (f: any) => ({ ...f, sessions: f.sessions.map((s: any, i: number) => { if (i !== 2) return s; const { walk: _w, ...r } = s; return { ...r, cardio: 'intervali' } }) })
  it('»nočem nog« in »nočem intervalov« ne dodata nog ali intervalov', () => {
    const z = custom(ZEN)
    for (const t of ['nočem nog', 'ne maram treninga nog']) {
      const r = negotiate(ZEN, z, t)
      expect(r.rev.sessions.map(s => s.part), t).not.toContain('noge')
      expect(r.rev.sessions.map(s => s.part), t).not.toContain('spodnji')
      expect(r.note).toBe('Prav — brez vadbe za noge, moč je za zgornji del in trup.')
    }
    expect(negotiate(ZEN, z, 'nočem intervalov').rev.sessions.some(s => s.cardio === 'intervali')).toBe(false)
    const withInt = fast(z.f)
    const a = ruleAdjust(withInt, 'nočem intervalov', 34)!
    expect(a.sessions.some(s => s.cardio === 'intervali')).toBe(false)
    expect(adjustNote(withInt, a)).toBe('Prav — brez intervalov, ves kardio je lahek.')
  })
  it('dnevi z besedo in čas na vadbo brez športa so razumljeni (ne »Brez AI razumem …«)', () => {
    const z = custom(ZEN)
    expect(ruleAdjust(z.f, 'tri dni', 34)).not.toBeNull()
    expect(ruleAdjust(z.f, 'raje dva dni', 34)).not.toBeNull()
    const m = negotiate(ZEN, z, 'imam samo 30 minut')
    expect(m.adj).not.toBeNull()
    expect(m.note).toBe('Prav — vadbe so zdaj po 30 min.')
    expect(m.rev.sessions.every(s => s.min <= 30)).toBe(true)
    expect(ruleAdjust(z.f, 'uro na vadbo', 34)!.sessions.every(s => s.after || s.min === 60)).toBe(true)
  })
  it('pogosti stavki: ne maram teka, samo fitnes, tudi kolo, kardio na kolesu, dodaj moč', () => {
    const z = custom(ZEN)
    for (const t of ['ne maram teka', 'tek mi ne paše', 'samo fitnes']) expect(negotiate(ZEN, z, t).rev.sessions.some(s => s.type === 'tek'), t).toBe(false)
    expect(negotiate(ZEN, z, 'rad bi tudi kolo').rev.sessions.some(s => s.type === 'kolo')).toBe(true)
    const k = negotiate(ZEN, z, 'kardio raje na kolesu').rev.sessions
    expect(k.some(s => s.type === 'tek')).toBe(false)
    expect(k.some(s => s.type === 'kolo')).toBe(true)
    const t = custom(TEK)
    expect(negotiate(TEK, t, 'dodaj moč').rev.sessions.some(s => s.type === 'fitnes' || s.type === 'doma')).toBe(true)
  })
  it('tekač »brez teka«: namesto teka hoja (ne »Tako že je«)', () => {
    const t = custom(TEK)
    const r = negotiate(TEK, t, 'brez teka')
    expect(r.rev.sessions.some(s => s.type === 'tek')).toBe(false)
    expect(r.rev.sessions.length).toBe(t.f.sessions.length)
    expect(r.note).toMatch(/namesto teka je zdaj hoja/)
  })
  it('»tek naj bo 40 min«: teki ostanejo 40 min po trenerju', () => {
    const t = custom(TEK)
    expect(negotiate(TEK, t, 'tek naj bo 40 min').rev.sessions.filter(s => s.type === 'tek').every(s => s.min === 40)).toBe(true)
  })
  it('zdravje v pogajanju: omejitve, brez intervalov, pojasnilo z zdravnikom', () => {
    const withInt = fast(custom(ZEN).f)
    for (const say of ['imam visok pritisk', 'sem noseča']) {
      const a = ruleAdjust(withInt, say, 34)!
      expect(a, say).not.toBeNull()
      expect(a.sessions.some(s => s.cardio === 'intervali')).toBe(false)
      expect(a.notes.join(' ')).toMatch(/zdravnik/)
      expect(adjustNote(withInt, a)).toMatch(/Pred začetkom se posvetuj z zdravnikom/)
    }
    expect(ruleAdjust(withInt, 'imam visok pritisk', 34)!.limits).toMatch(/tlak/)
  })
  it('»naj bo lažje«: brez hitrih delov; brez njih vadbe krajše', () => {
    const z = custom(ZEN)
    const withInt = fast(z.f)
    for (const t of ['naj bo lažje', 'manj naporno', 'prenaporno je']) expect(ruleAdjust(withInt, t, 34)!.sessions.some(s => s.cardio === 'intervali' || s.cardio === 'tempo'), t).toBe(false)
    const sum = (f: any) => f.sessions.reduce((t: number, s: any) => t + s.min, 0)
    expect(sum(ruleAdjust(z.f, 'naj bo lažje', 34)!)).toBeLessThan(sum(z.f))
  })
})

describe('pregled tedna in nasvet brez AI (C09, C11, C33)', () => {
  it('ponedeljek: najprej pretekli teden (vse opravljeno)', () => {
    const plan: any[] = weeksOf(kolesar, '2026-10-26')
    for (const d of plan) if (d.date < '2026-10-26' && d.kind !== 'pocitek') d.done = { at: d.date + 'T18:00:00Z', activityId: null }
    const r = localReview(lc(kolesar, plan, '2026-10-26'))
    const n = plan.filter(d => d.date >= '2026-10-19' && d.date < '2026-10-26' && d.kind !== 'pocitek' && !d.optional).length
    expect(r).toContain(`Pretekli teden (od 19. 10.): ${n} od ${n} sej`)
    expect(aiContext([], kolesar, plan, false, '2026-10-26')).toContain('Pretekli teden (od 19. 10.')
  })
  it('kolesar: odkljukane vožnje brez ure štejejo čas iz načrta', () => {
    const plan: any[] = weeksOf(kolesar, '2026-10-23')
    for (const d of plan) if (d.date < '2026-10-23' && d.kind !== 'pocitek') d.done = { at: d.date + 'T18:00:00Z', activityId: null }
    expect(localReview(lc(kolesar, plan, '2026-10-23'))).not.toMatch(/na kolesu 0 min od/)
  })
  it('premor brez kolesa na dan tekme: »tekma ostane«', () => {
    const today = '2026-10-23'
    const p = { ...kolesar, weekPause: { mode: 'kolo', from: '2026-10-19', to: '2026-10-25', reason: null, at: NOW } }
    const plan: any[] = [{ id: 'r', date: today, kind: 'kolo', title: 'Kronometer Vodice — 18 km', durationMin: 30, role: 'dirka', raceId: 'r1', desc: '', why: '', zone: 'Z4', tssTarget: 40, source: 'plan', updatedAt: NOW }]
    expect(localAdvice(lc(p, plan, today))).toMatch(/premor do nedelje \(brez kolesa\) — tekma ostane, ostali dnevi brez kolesa\.\nDanes: Kronometer/)
  })
})

describe('AI pozivi po uporabniku (C05, C08, C12–C17, C41–C46)', () => {
  const today = '2026-10-23'
  it('kolesar brez tekme: brez dirke v personi in kontekstu, METODA brez taperinga in moči, brez »PREHRANA PRED TEKMO«', () => {
    const plan = weeksOf(kolesar, today)
    const ex = personalContext({ profile: kolesar, activities: [], plan, checkins: [], recentMeals: [], tests: [], weather: null, today })
    expect(ex).not.toMatch(/Cilj na dan dirke|največji možni FTP do dirke|PREHRANA PRED TEKMO|tapering|moč 2 × na teden/)
    expect(ex).toContain('moči ne dela')
    expect(ex).toMatch(/GLAVNI CILJ: boljša forma/)
    const ctx = aiContext([], kolesar, plan, false, today) + '\n\n' + ex
    const t = (coachDailyPrompt(ctx, [], 'Kaj danes?')[0] as any).text as string
    expect(t).not.toContain('do svoje dirke')
    expect(t).toContain('nima tekme z datumom')
    const rv = (weeklyReviewPrompt(ctx + '\nBREZ MERILNIKA MOČI')[0] as any).text as string
    expect(rv).not.toMatch(/faze do dirke/)
    expect(rv).toMatch(/\(ure, ključni seji, teža, utrip\)/)
  })
  it('kolesar s tekmo: dirka, tapering in najboljša teža ostanejo', () => {
    const p = { ...kolesar, goal: 'dirka', event: { name: 'Maraton Franja', date: '2027-06-13', distanceKm: 156 }, strength: { on: true, equipment: 'gym' } }
    const plan = weeksOf(p, today)
    const ex = personalContext({ profile: p, activities: [], plan, checkins: [], recentMeals: [], tests: [], weather: null, today })
    expect(ex).toMatch(/Cilj na dan dirke: \d+ W/)
    expect(ex).toContain('tapering')
    expect(ex).toContain('moč 2 × na teden')
    expect(ex).toContain('PREHRANA PRED TEKMO')
    expect(ex).toMatch(/najboljša teža \d+(,\d)? kg/)
    expect(ex).not.toMatch(/\d\.\d kg/)
    const t = (coachDailyPrompt(aiContext([], p, plan, false, today) + '\n\n' + ex, [], 'Kaj danes?')[0] as any).text as string
    expect(t).toContain('Športnik hoče postati res dober kolesar do svoje dirke')
  })
  it('kolesarka, ki hujša: brez »najboljše teže«, brez vprašajev, ženska persona', () => {
    const plan = weeksOf(hujsa, today)
    const ex = personalContext({ profile: hujsa, activities: [], plan, checkins: [], recentMeals: [], tests: [], weather: null, today })
    expect(ex).not.toMatch(/najboljša teža|\? W|\? kg/)
    expect(ex).toContain('FTP ni izmerjen')
    expect(ex).toMatch(/do prvega mejnika ~70 kg/)
    const t = (coachDailyPrompt(aiContext([], hujsa, plan, false, today) + '\n\n' + ex, [], 'Kaj danes?')[0] as any).text as string
    expect(t).toContain('Športnica nima tekme')
  })
  it('gorivo iz tabele aplikacije', () => {
    const ex = personalContext({ profile: kolesar, activities: [], plan: [], checkins: [], recentMeals: [], tests: [], weather: null, today })
    expect(ex).not.toMatch(/80–90 g/)
    expect(ex).toMatch(/dirka ~45–85 g/)
  })
  it('kolesar z visokim tlakom: omejitev v kontekstu, hitri gumb brez VO2max', () => {
    const p = { ...kolesar, focus: { title: 'Kolo', mode: 'kolo', sessions: [], aims: [], muscles: [], equipment: [], sports: ['kolo'], level: 2, days: 4, minutes: 60, wish: 'Imam visok krvni tlak.', limits: 'visok krvni tlak', notes: [], keepMuscle: false, by: 'pravila', at: NOW } }
    expect(aiContext([], p, weeksOf(p, today), false, today)).toMatch(/OMEJITVE \(povedal ob dogovoru\): visok krvni tlak\. ZDRAVJE:/)
    expect(quick(p)).not.toContain('Kako izpeljem VO2max intervale?')
    expect(quick(kolesar)).toContain('Kako izpeljem VO2max intervale?')
  })
  it('doma brez opreme: brez kilogramov; mladoletni brez primanjkljaja v personi', () => {
    const d = custom(DOMA)
    const plan = buildWeek({ profile: d.p, activities: [], weekStart: '2026-10-26', notBefore: '2026-10-26', today: '2026-10-26' } as any)
    const t = (coachDailyPrompt(aiContext([], d.p, plan, false, '2026-10-26'), plan.filter(x => x.date === '2026-10-26'))[0] as any).text as string
    expect(t).not.toMatch(/ponovitve in kilogram|kilogrami pri moči/)
    expect(t).toContain('MOČ BREZ UTEŽI')
    const m = custom(MLAD)
    const tm = (coachDailyPrompt(aiContext([], m.p, [], false, today), [])[0] as any).text as string
    expect(tm).toContain('MLADOLETEN')
    expect(tm).not.toContain('zmeren primanjkljaj (izračuna ga aplikacija)')
    expect((weeklyReviewPrompt(aiContext([], m.p, [], false, today))[0] as any).text).toMatch(/\(treningi, ponovitve, minute\)/)
  })
  it('shema prilagoditve: cone aplikacije; neznana cona ne gre v načrt', async () => {
    expect(ADAPT_SCHEMA_HINT).not.toContain('"C3"')
    const wk: any[] = [{ id: 'a', date: '2026-10-24', kind: 'kolo', title: 'Z2', durationMin: 60, desc: 'lahko', why: '', zone: 'Z2', tssTarget: 40, source: 'rules', updatedAt: NOW }]
    ;(globalThis as any).__json = { dnevi: [{ date: '2026-10-24', kind: 'kolo', title: 'Tempo', desc: 'tempo', durationMin: 60, zone: 'C3', tssTarget: 50 }], povzetek: 'Tempo.' }
    const r = await adaptWeek({ profile: kolesar, activities: [], plan: wk, today: '2026-10-23' }, wk)
    expect(r.days[0]!.zone).toBeNull()
  })
  it('ženske oblike v kontekstu po meri in vprašalnik o zdravju', () => {
    const z = custom(ZEN)
    const t = focusContext({ focus: { ...z.f, said: ['Rada bi več nog.'] }, sex: 'z' } as any)
    expect(t).toContain('Dogovor z uporabnico')
    expect(t).toContain('Kar je še povedala')
    expect(needToKnow('Cilj: manj kilogramov. Rad delam: fitnes.', { avail: null } as any)).toContain('zdravstvene težave')
  })
})

describe('več pozivov (C06, C27, C29, C45, C48, C49)', () => {
  const today = '2026-10-23'
  it('hladilnik: 16-letnik brez primanjkljaja, brez deficita vzdrževanje; predlogi »varčno«', async () => {
    const m = custom(MLAD)
    ;(globalThis as any).__json = { vidim: [], predlogi: [] }
    await fridgeMeals(m.p, new File(['x'], 'a.jpg', { type: 'image/jpeg' }), 800, 40, null, false)
    expect(sent[0]).toContain('Cilj uporabnika: rast in trening — brez primanjkljaja')
    await fridgeMeals({ ...blank, age: 40, deficit: 0, goal: 'forma' }, new File(['x'], 'a.jpg', { type: 'image/jpeg' }), 800, 40, null, false)
    expect(sent[1]).toContain('Cilj uporabnika: vzdrževanje teže')
    await mealIdeas({ profile: { ...blank, age: 52, sex: 'z' }, activities: [], plan: [], today }, 700, 40)
    expect(sent[2]).not.toContain('študentski')
  })
  it('mesečna ocena: kolesarka brez tekme — brez »do dirke«, z ženskimi oblikami', async () => {
    await monthReview({ profile: hujsa, activities: [], plan: [], today }, 'Oktober: 10 voženj.')
    expect(sent[0]).not.toContain('glede na mejnike do dirke')
    expect(sent[0]).toContain('ženski obliki')
  })
  it('prilagoditev med premorom: dnevi premora ne gredo v poziv; samo premor → brez klica', async () => {
    const p = { ...kolesar, weekPause: { mode: 'kolo', from: '2026-10-19', to: '2026-10-25', reason: null, at: NOW } }
    const wk: any[] = [{ id: 'a', date: '2026-10-24', kind: 'pocitek', title: 'Premor', durationMin: 0, desc: 'premor', why: '', zone: null, tssTarget: 0, source: 'plan', updatedAt: NOW }]
    await expect(adaptWeek({ profile: p, activities: [], plan: wk, today: '2026-10-23' }, wk)).rejects.toThrow(PAUSE_NOTHING)
    expect(sent.length).toBe(0)
    const p2 = { ...p, weekPause: { ...p.weekPause, to: '2026-10-24' } }
    const wk2: any[] = [...wk, { id: 'b', date: '2026-10-25', kind: 'kolo', title: 'Z2', durationMin: 90, desc: 'lahko', why: '', zone: 'Z2', tssTarget: 60, source: 'rules', updatedAt: NOW }]
    ;(globalThis as any).__json = { dnevi: [{ date: '2026-10-24', kind: 'kolo', title: 'Z2 vožnja', desc: 'lahko', durationMin: 90, zone: 'Z2', tssTarget: 60 }, { date: '2026-10-25', kind: 'kolo', title: 'Z2', desc: 'lahko', durationMin: 90, zone: 'Z2', tssTarget: 60 }], povzetek: 'Ok.' }
    const r = await adaptWeek({ profile: p2, activities: [], plan: wk2, today: '2026-10-23' }, wk2)
    expect(sent[0]).toMatch(/PREMOR po njegovi izbiri \(teh dni ne vračaj[^\n]*2026-10-24/)
    expect(sent[0]!.split('OBSTOJEČI TEDEN:')[1]).not.toContain('2026-10-24')
    expect(r.days.find(d => d.date === '2026-10-24')!.kind).toBe('pocitek')
  })
  it('pregled tedna: shranjen od torka z drugim odtisom ne velja, isti dan velja', async () => {
    ;(globalThis as any).__kv = { 'ai.week.2026-10-19': { text: 'Torkov pregled: 1 od 5.', at: '2026-10-20', sig: 'drug' } }
    expect(await weeklyReview({ profile: kolesar, activities: [], plan: [], today: '2026-10-25' }, false)).toBe('Razumem.')
    expect(sent.length).toBe(1)
    ;(globalThis as any).__kv = { 'ai.week.2026-10-19': { text: 'Nedeljski.', at: '2026-10-25', sig: 'x' } }
    expect(await weeklyReview({ profile: kolesar, activities: [], plan: [], today: '2026-10-25' }, false)).toBe('Nedeljski.')
    ;(globalThis as any).__kv = { 'ai.week.2026-10-19': 'Star zapis.' }
    expect(await weeklyReview({ profile: kolesar, activities: [], plan: [], today: '2026-10-25' }, false)).toBe('Razumem.')
  })
  it('nedelja, vse opravljeno, naslednji teden ni sestavljen: ni česa prilagoditi', () => {
    const d: any = { id: 'n', date: '2026-10-25', kind: 'kolo', title: 'Z2', durationMin: 90, done: { at: NOW, activityId: null } }
    expect(adaptDone([d], '2026-10-25')).toBe(true)
    expect(adaptDone([{ ...d, done: null }], '2026-10-25')).toBe(false)
    expect(adaptDone([d, { ...d, id: 'm', date: '2026-10-27', done: null }], '2026-10-25')).toBe(false)
  })
})

describe('hitri gumbi (C39)', () => {
  it('kondicija in zdravje brez hujšanja: brez »maščobe okoli pasu« in »Zakaj teža stoji?«', () => {
    const q = quickCustom(custom(DOMA).p.focus, false)
    expect(q).not.toContain('Kako izgubim maščobo okoli pasu?')
    expect(q).not.toContain('Zakaj teža stoji?')
    expect(quickCustom(custom(ZEN).p.focus, false)).toContain('Zakaj teža stoji?')
  })
})
