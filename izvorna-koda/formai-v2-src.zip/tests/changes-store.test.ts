import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { setKV } from '../src/data/db'
import { todayIso, addDays, weekStartIso } from '../src/domain/training/load'
import { FRANJA_2027 } from '../src/domain/training/planner'
import { freshChange, whenOf } from '../src/ui/ChangesCard'
import type { PlanDay } from '../src/domain/types'

const NOW = '2026-10-03T08:00:00.000Z'
const day = (id: string, date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id, date, kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, zone: 'Z2', tssTarget: 45, role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })

describe('spremembe načrta', () => {
  beforeEach(async () => { await repo.wipeAll(); localStorage.clear(); await setKV('plan.changes', []); await store.reloadAll() })
  it('zapis: najnovejša prva, isto v isti minuti enkrat, največ 40, preživi ponovno branje', async () => {
    await store.logChange('A')
    await store.logChange('A')
    await store.logChange('B', false)
    expect(store.getState().changes.map(c => [c.text, c.auto])).toEqual([['B', false], ['A', true]])
    for (let i = 0; i < 45; i++) await store.logChange(`x${i}`)
    expect(store.getState().changes.length).toBe(40)
    await store.reloadAll()
    expect(store.getState().changes[0]!.text).toBe('x44')
  })
  it('samodejne spremembe se zapišejo (off-season iz predloge), tvoji kliki z oznako »ti« (izbira, tekme)', async () => {
    const t = todayIso(), ws = weekStartIso(t)
    await store.updateProfile({ onboardingDone: true, event: { ...FRANJA_2027 }, cycleStart: ws, offSeasonWeeks: 3 })
    await repo.upsertPlanDays([day('h1', addDays(t, 1), { kind: 'pohod', title: 'Hribi' })]); await store.reloadAll()
    await store.offMixFix()
    expect(store.getState().changes[0]).toMatchObject({ auto: true })
    expect(store.getState().changes[0]!.text).toMatch(/hribe iz predloge/)
    await store.setOffMix('mesano')
    expect(store.getState().changes[0]).toMatchObject({ auto: false, text: expect.stringMatching(/kolo in hribi/) })
    await store.saveRaces([{ id: 'r1', name: 'Kronometer', date: addDays(t, 30), prio: 'B' } as never])
    expect(store.getState().changes[0]!.text).toMatch(/Tekme sezone/)
  })
  it('prikaz: »danes 8:05«, »včeraj …«, sicer datum; sveža = zadnja v dveh dneh', () => {
    const today = '2026-10-04'
    expect(whenOf('2026-10-04T08:05:00', today)).toBe('danes 8:05')
    expect(whenOf('2026-10-03T19:40:00', today)).toBe('včeraj 19:40')
    expect(whenOf('2026-09-30T10:00:00', today)).toBe('30. 9.')
    expect(freshChange([{ at: '2026-10-02T10:00:00.000Z', text: 'x', auto: true }], today)).not.toBeNull()
    expect(freshChange([{ at: '2026-09-30T10:00:00.000Z', text: 'x', auto: true }], today)).toBeNull()
    expect(freshChange([], today)).toBeNull()
  })
})
