// v3.50 RECEPTI (shramba): H01 — »Sem vegan« / »Ne prenašam laktoze« iz uvoda gre ob »Dogovorjeno« v prehranske želje;
// E05 — »drug predlog« je shranjen po dnevu (starejši od 7 dni odpadejo, nove želje ga pobrišejo).
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { addDays } from '../src/domain/training/load'
import { ruleProposal } from '../src/domain/focus/rules'
import { composeWish } from '../src/domain/focus/choices'
import { dayMealsOf, recipeCtxOf, recipesOf } from '../src/domain/nutrition/daymeals'
import { dailyTarget } from '../src/domain/nutrition/energy'

const agree = async (text: string) => {
  const today = store.getState().today
  const wish = composeWish({ cilj: ['Več energije in kondicije'], delam: ['Tek'], raven: ['Občasno'] }, text)
  const f = ruleProposal(wish, [{ id: 'dni', q: 'Koliko dni na teden?', a: '3' }], 34, { avail: [1, 3, 5], today }).focus
  return store.applyAgreement(f, { sex: 'z', age: 34, heightCm: 168, weightKg: 64 })
}

describe('H01 želje iz uvoda v prehranske želje', () => {
  beforeEach(async () => { await repo.wipeAll(); localStorage.clear(); await store.reloadAll() })
  it('»Sem vegan.« → prehranske želje »vegan«; recepti brez mleka, mesa, jajc', async () => {
    const p = await agree('Rada bi več tekla. Sem vegan.')
    expect(store.getState().settings.foodPrefs).toBe('vegan')
    const today = store.getState().today, plan = store.getState().plan
    const t = dailyTarget(p, [], plan.filter(d => d.date === today), today, { today, hour: 9 })!
    const dm = dayMealsOf({ p, target: t, plan, activities: [], meals: [], recentMeals: [], weather: null, day: today, today })
    const r = recipesOf(dm.dp, today, recipeCtxOf(p, t, store.getState().settings, dm.training), store.getState().settings)
    expect(Object.keys(r).length).toBeGreaterThan(2)
    for (const x of Object.values(r)) expect(x.ingredients.some(i => ['jogurt', 'skuta', 'mleko', 'kefir', 'sir', 'jajce', 'piscanec', 'med'].includes(i.key)), x.name).toBe(false)
  })
  it('»Ne prenašam laktoze« → »brez laktoze«; obstoječe želje ostanejo; brez besed o hrani nič', async () => {
    await agree('Ne prenašam laktoze, tečem rada zjutraj.')
    expect(store.getState().settings.foodPrefs).toBe('brez laktoze')
    await store.setFoodPrefs('ne maram rib')
    await agree('Sem vegan.')
    expect(store.getState().settings.foodPrefs).toBe('ne maram rib')
    await store.setFoodPrefs('')
    await agree('Hočem teči 10 km brez poškodb.')
    expect(store.getState().settings.foodPrefs ?? null).toBeNull()
  })
})

describe('E05 »drug predlog« v nastavitvah', () => {
  beforeEach(async () => { await repo.wipeAll(); localStorage.clear(); await store.reloadAll() })
  it('shrani za dan, starejše od 7 dni pobriše, nove želje ga pobrišejo', async () => {
    const today = store.getState().today
    await store.setRecipeAlt(addDays(today, -9), { kosilo: 1 })
    await store.setRecipeAlt(today, { kosilo: 2, zajtrk: 0 })
    expect(store.getState().settings.recipeAlt).toEqual({ [today]: { kosilo: 2 } })
    await store.setRecipeAlt(addDays(today, 1), { vecerja: 1 })
    expect(Object.keys(store.getState().settings.recipeAlt!).sort()).toEqual([today, addDays(today, 1)])
    await store.setFoodPrefs('vegetarijansko')
    expect(store.getState().settings.recipeAlt ?? null).toBeNull()
  })
})
