// v3.50 POPRAVKI-UI (REVIEW-UI U11): dvojni tap na »Dodaj v načrt (2×, po želji)« (Predlog s slike) zapiše enkrat.
// (»Jedro po želji (20 min)« na Danes: tests/v350-popravki-ui.test.tsx)
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>() }))
const h = vi.hoisted(() => ({ json: {} as unknown, self: [] as unknown[][] }))
vi.mock('@/state/store', () => ({
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state, toast: () => undefined,
}))
vi.mock('@/state/photoTraining', () => ({
  saveDoneShot: async () => ({ added: true, day: null }),
  addPhotoWorkout: async (d: unknown) => ({ day: d, replaced: null, undo: async () => undefined }),
  // zapis v IndexedDB traja (na telefonu nekaj 10 ms) — dovolj za drugi tap
  addSelfSessions: async (days: unknown[]) => { h.self.push(days); await new Promise(r => setTimeout(r, 40)) },
}))
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => ({ name: 'trener', params: {} }) }))
vi.mock('@/ui/useAi', () => ({ useAi: () => ({ busy: false, signedIn: true, consent: true, run: async (fn: () => Promise<unknown>) => fn(), sheet: null }) }))
vi.mock('@/domain/ai/client', () => {
  class AiError extends Error { kind: string; constructor(kind: string, m: string) { super(m); this.kind = kind } }
  return { AiError, askText: async () => '', askJson: async () => JSON.parse(JSON.stringify(h.json)) }
})
vi.mock('@/domain/ai/image', () => ({ fileToBase64Resized: async () => ({ data: 'AAAA', mime: 'image/jpeg', thumb: '' }), exifStamp: async () => null }))

import { PhotoTrainingSheet } from '@/ui/PhotoTrainingSheet'
import type { Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-21'
const NOW = `${TODAY}T08:00:00.000Z`
const P = { sex: 'm', age: 30, heightCm: 182, weightKg: 78, ftp: 250, aiConsentAt: NOW, aiConsentV: 3, gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: true }, onboardingDone: true } as unknown as Profile   // (po združitvi s POPRAVKI-NU N9) slika sebe zahteva privolitev v3
let div: HTMLDivElement | null = null, root: Root | null = null
async function render(el: ReactElement) { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div); await act(async () => { root!.render(el) }); return document.body }
const sp = (x: string | null | undefined) => (x || '').replace(/[  ⁠]/g, ' ')
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(sp(b.textContent))) as HTMLButtonElement | undefined

beforeEach(() => { h.self.length = 0; S.state = { today: TODAY, plan: [], activities: [], profile: P, user: { uid: 'u' }, settings: {} } })
afterEach(() => { act(() => root?.unmount()); div?.remove(); div = null; root = null; document.body.innerHTML = '' })

describe('Predlog s slike: »Dodaj v načrt (2×, po želji)«', () => {
  it('dvojni tap → addSelfSessions enkrat (prej dvakrat z istimi dnevi: 4 seje namesto 2)', async () => {
    h.json = { poudarki: ['Okrepi zgornji del hrbta in zadnje rame za boljšo držo.'], podrocje: 'drza', predlog: { na_teden: 2, minut: 15, vaje: [{ ime: 'Superman', serije: 3, ponovitve: 10 }] } }
    await render(<PhotoTrainingSheet req={{ mode: 'self' }} />)
    const input = document.querySelector('input[type=file]') as HTMLInputElement
    Object.defineProperty(input, 'files', { configurable: true, value: [new File(['x'], 'p.jpg', { type: 'image/jpeg' })] })
    await act(async () => { input.dispatchEvent(new Event('change', { bubbles: true })) })
    for (let i = 0; i < 5; i++) await act(async () => { await new Promise(r => setTimeout(r, 0)) })
    const b = btn(/Dodaj v načrt/)
    expect(b).toBeTruthy()
    await act(async () => { b!.click(); b!.click(); await new Promise(r => setTimeout(r, 80)) })
    expect(h.self.length).toBe(1)
  })
})
