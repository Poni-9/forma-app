import { describe, it, expect } from 'vitest'
import { cellsOfTrack } from '../src/domain/coverage/cells'
import { territoriesOf, territoryKey, territoryCenter, levelFor, streakDays, monthStats } from '../src/domain/coverage/territory'
import { addDays, todayIso } from '../src/domain/training/load'

describe('ozemlje (INTVL slog, osebno)', () => {
  it('grobe ploščice: ključ ↔ center, celice se združijo', () => {
    const k = territoryKey(46.1234, 14.5678); const [la, lo] = territoryCenter(k)
    expect(Math.abs(la - 46.123)).toBeLessThan(1e-3); expect(Math.abs(lo - 14.568)).toBeLessThan(1e-3)
    const cells = cellsOfTrack([[46.19, 14.49], [46.191, 14.4915], [46.1925, 14.493]])
    const terr = territoriesOf(cells)
    expect(terr.size).toBeGreaterThan(0); expect(terr.size).toBeLessThan(cells.size)
  })
  it('nivo raste s površino in ima napredek do naslednjega', () => {
    expect(levelFor(0).n).toBe(1); expect(levelFor(0.6).n).toBe(2); expect(levelFor(13).name).toBe('Kartograf')
    const l = levelFor(3.5); expect(l.pct).toBeGreaterThan(0); expect(l.pct).toBeLessThan(100); expect(l.nextKm2).toBe(5)
    expect(levelFor(999).nextKm2).toBeNull()
  })
  it('niz dni dovoli en prost dan, prekine pri dveh', () => {
    const t = todayIso()
    const a = (d: number) => ({ date: addDays(t, -d), source: 'file' as const })
    expect(streakDays([a(0), a(1), a(2)], t)).toBe(3)
    expect(streakDays([a(0), a(2), a(3)], t)).toBe(3)          // en prost dan vmes
    expect(streakDays([a(0), a(3), a(4)], t)).toBe(1)          // dva prosta dneva prekineta
    expect(streakDays([a(1), a(2)], t)).toBe(2)                // danes še nič → šteje od včeraj
    expect(streakDays([], t)).toBe(0)
  })
  it('mesečni cilj: vsaj 50 km, sicer +10 % prejšnjega meseca, zaokroženo na 10', () => {
    const t = '2026-09-15'
    const s = monthStats([{ date: '2026-08-10', distKm: 200, durationMin: 400 }, { date: '2026-09-02', distKm: 40, durationMin: 90 }], t)
    expect(s.km).toBe(40); expect(s.prevKm).toBe(200); expect(s.goalKm).toBe(220)
    expect(monthStats([], t).goalKm).toBe(50)
  })
})
