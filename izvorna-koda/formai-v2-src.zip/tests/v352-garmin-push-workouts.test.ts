import { describe, it, expect } from 'vitest'
import { garminWorkout, garminWorkoutsFor, workoutHash, workoutNameOf, garminSportOf, NAME_MAX, type GarminWorkout, type GarminWorkoutStep, type GarminRepeatStep } from '../src/domain/garmin/workouts'
import { icuWorkout } from '../src/domain/intervals/workouts'
import type { PlanDay, Profile } from '../src/domain/types'

const now = new Date().toISOString()
const base = { sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, lthr: 184, maxHr: 199, restHr: 52, strength: { on: false, equipment: 'home' }, onboardingDone: true, createdAt: now, updatedAt: now } as unknown as Profile
const hrOnly: Profile = { ...base, gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false } }
const withPm: Profile = { ...base, gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true } }
const day = (o: Partial<PlanDay>): PlanDay => ({ id: 'x', date: '2026-11-03', kind: 'kolo', title: 'Z2 vzdržljivost', desc: '', durationMin: 70, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: now, updatedAt: now, ...o })

/** Skupni čas treninga iz korakov (ponovitve × koraki v bloku). */
const totalOf = (w: GarminWorkout) => w.steps.reduce((s, x) => s + (x.type === 'WorkoutRepeatStep' ? x.repeatValue * x.steps.reduce((a, y) => a + y.durationValue, 0) : x.durationValue), 0)
const flat = (w: GarminWorkout): GarminWorkoutStep[] => w.steps.flatMap(x => (x.type === 'WorkoutRepeatStep' ? x.steps : [x]))
const orders = (w: GarminWorkout): number[] => w.steps.flatMap(x => (x.type === 'WorkoutRepeatStep' ? [x.stepOrder, ...x.steps.map(y => y.stepOrder)] : [x.stepOrder]))

describe('v3.52 Garmin Training API — trening iz dneva', () => {
  it('enakomerna Z2 vožnja brez merilnika: ogrevanje → delo → iztek, utrip v bpm iz LTHR, čas = načrt', () => {
    const w = garminWorkout(day({}), hrOnly)!
    expect(w.uid).toBe('formai-2026-11-03'); expect(w.date).toBe('2026-11-03')
    expect(w.workoutName).toBe('FORMAI · Z2 vzdržljivost'); expect(w.sport).toBe('CYCLING'); expect(w.workoutProvider).toBe('FORMAI')
    expect(w.steps.map(s => s.type)).toEqual(['WorkoutStep', 'WorkoutStep', 'WorkoutStep'])
    const [wu, main, cd] = w.steps as GarminWorkoutStep[]
    expect(wu).toMatchObject({ intensity: 'WARMUP', durationType: 'TIME', durationValue: 600, targetType: 'HEART_RATE', targetValueLow: 110, targetValueHigh: 147 })
    expect(main).toMatchObject({ intensity: 'ACTIVE', durationValue: 55 * 60, targetType: 'HEART_RATE', targetValueLow: 149, targetValueHigh: 164 })
    expect(cd).toMatchObject({ intensity: 'COOLDOWN', durationValue: 300 })
    expect(w.estimatedDurationInSecs).toBe(70 * 60); expect(totalOf(w)).toBe(70 * 60)
    expect(orders(w)).toEqual([1, 2, 3])
    expect(w.description).toContain('ogrevanje')
    expect(w.hash).toMatch(/^[0-9a-f]{8}$/)
  })
  it('intervali VO2max 4 × 4 min z merilnikom: blok REPEAT 4× (delo v vatih cilja dneva, odmor REST), čas = načrt', () => {
    const d = day({ title: 'VO2max 4 × 4 min', desc: '15 min ogrevanje, 4 × 4 min, vmes 4 min lahko, 10 min izvoz', zone: 'Z5', role: 'kljucna', durationMin: 75, target: { lo: 259, hi: 276 } })
    const w = garminWorkout(d, withPm)!
    const rep = w.steps.find(s => s.type === 'WorkoutRepeatStep') as GarminRepeatStep
    expect(rep).toBeTruthy(); expect(rep.repeatType).toBe('REPEAT_UNTIL_STEPS_CMPLT'); expect(rep.repeatValue).toBe(4)
    expect(rep.steps[0]).toMatchObject({ intensity: 'ACTIVE', durationValue: 240, targetType: 'POWER', targetValueLow: 259, targetValueHigh: 276 })
    expect(rep.steps[1]).toMatchObject({ intensity: 'REST', durationValue: 240, targetType: 'POWER', targetValueLow: 108, targetValueHigh: 132 })
    expect(totalOf(w)).toBe(75 * 60); expect(w.estimatedDurationInSecs).toBe(75 * 60)
    // stepOrder zaporedno čez vse korake, tudi v bloku
    const o = orders(w); expect(o).toEqual(o.map((_, i) => i + 1))
    // enak čas kot izvoz v intervals.icu
    expect(icuWorkout(d, withPm)!.movingTime).toBe(w.estimatedDurationInSecs)
  })
  it('intervali brez merilnika: delo v bpm (Z5 = 100–108 % LTHR), ne v vatih', () => {
    const w = garminWorkout(day({ title: 'VO2max 4 × 4 min', desc: '15 min ogrevanje, 4 × 4 min, vmes 4 min lahko, 10 min izvoz', zone: 'Z5', role: 'kljucna', durationMin: 75, target: { lo: 259, hi: 276 } }), hrOnly)!
    const rep = w.steps.find(s => s.type === 'WorkoutRepeatStep') as GarminRepeatStep
    expect(rep.steps[0]).toMatchObject({ targetType: 'HEART_RATE', targetValueLow: 184, targetValueHigh: 199 })
    expect(flat(w).every(s => s.targetType === 'HEART_RATE')).toBe(true)
    expect(totalOf(w)).toBe(75 * 60)
  })
  it('over-under 3 × (2 min pod + 1 min nad pragom): blok z dvema ACTIVE koraki brez odmora', () => {
    const d = day({ title: 'Over-under 3 × 9 min', desc: '15 min ogrevanje. 3 × 9 min, vmes 5 min. Vsak interval 3 × (2 min pri 223–233 W + 1 min pri 247–257 W). 10 min izvoz.', zone: 'Z4', role: 'kljucna', durationMin: 80, target: { lo: 223, hi: 257 } })
    const w = garminWorkout(d, withPm)!
    const reps = w.steps.filter(s => s.type === 'WorkoutRepeatStep') as GarminRepeatStep[]
    expect(reps.length).toBeGreaterThanOrEqual(1)
    expect(reps[0]!.repeatValue).toBe(3)
    expect(reps[0]!.steps.map(s => s.intensity)).toEqual(['ACTIVE', 'ACTIVE'])
    expect(reps[0]!.steps[0]).toMatchObject({ durationValue: 120, targetType: 'POWER', targetValueLow: 223, targetValueHigh: 233 })
    expect(reps[0]!.steps[1]).toMatchObject({ durationValue: 60, targetValueLow: 247, targetValueHigh: 257 })
    expect(totalOf(w)).toBe(80 * 60)
  })
  it('test FTP: korak Test z vati 100–110 % FTP (merilnik) ali 95–105 % LTHR (brez)', () => {
    const t = day({ kind: 'test', title: '20-minutni test FTP', role: 'test', durationMin: 60 })
    const a = garminWorkout(t, withPm)!
    const test = flat(a).find(s => s.description === 'Test')!
    expect(test).toMatchObject({ durationValue: 1200, targetType: 'POWER', targetValueLow: 240, targetValueHigh: 264 })
    expect(totalOf(a)).toBe(60 * 60)
    const b = garminWorkout(t, hrOnly)!
    expect(flat(b).find(s => s.description === 'Test')).toMatchObject({ targetType: 'HEART_RATE', targetValueLow: 175, targetValueHigh: 193 })
  })
  it('tek: sport RUNNING, cilji vedno utrip (tudi z merilnikom na kolesu)', () => {
    const w = garminWorkout(day({ kind: 'tek', title: 'Lahek tek', durationMin: 40, zone: 'Z2' }), withPm)!
    expect(w.sport).toBe('RUNNING')
    expect(flat(w).every(s => s.targetType === 'HEART_RATE')).toBe(true)
    expect(totalOf(w)).toBe(40 * 60)
  })
  it('brez LTHR in brez merilnika: odprti koraki (OPEN), ne izmišljeni bpm', () => {
    const p: Profile = { ...hrOnly, lthr: null, maxHr: null, restHr: null }
    const w = garminWorkout(day({}), p)!
    expect(flat(w).every(s => s.targetType === 'OPEN' && s.targetValueLow === undefined)).toBe(true)
  })
  it('šprinti »vse, kar gre« z merilnikom: cilj vsaj 150 % FTP', () => {
    const w = garminWorkout(day({ title: 'Z2 + šprinti', desc: 'Z2 vožnja. Na sredi 6 × 10 s šprint — vse, kar gre, vmes 4 min lahko.', durationMin: 90 }), withPm)!
    const rep = w.steps.find(s => s.type === 'WorkoutRepeatStep') as GarminRepeatStep
    expect(rep.repeatValue).toBe(6)
    expect(rep.steps[0]).toMatchObject({ durationValue: 10, targetType: 'POWER', targetValueLow: 360, targetValueHigh: 720 })
    expect(totalOf(w)).toBe(90 * 60)
  })
  it('počitek, moč, pohod, dirka → null (moč: Garminov katalog vaj ni potrjen)', () => {
    expect(garminWorkout(day({ kind: 'pocitek', title: 'Počitek', durationMin: 0 }), withPm)).toBeNull()
    expect(garminWorkout(day({ kind: 'moc', title: 'Moč — jedro', exercises: [{ name: 'Počep', sets: 3, reps: '10' }] }), withPm)).toBeNull()
    expect(garminWorkout(day({ kind: 'pohod', title: 'Hribi', durationMin: 120 }), withPm)).toBeNull()
    expect(garminWorkout(day({ role: 'dirka', title: 'Maraton Franja', desc: 'Ogrevanje 20 min.' }), withPm)).toBeNull()
    expect(garminWorkout(day({ raceId: 'r1', title: 'Tekma' }), withPm)).toBeNull()
    expect(garminSportOf({ kind: 'kolo' })).toBe('CYCLING'); expect(garminSportOf({ kind: 'tek' })).toBe('RUNNING'); expect(garminSportOf({ kind: 'moc' })).toBeNull()
  })
  it('ime: predpona FORMAI, največ 80 znakov; opis ≤ 500 znakov', () => {
    expect(workoutNameOf('Z2')).toBe('FORMAI · Z2')
    const long = workoutNameOf('x'.repeat(200))
    expect(long.length).toBeLessThanOrEqual(NAME_MAX); expect(long.endsWith('…')).toBe(true)
    const w = garminWorkout(day({ title: 'VO2max 4 × 4 min', desc: '15 min ogrevanje, 4 × 4 min, vmes 4 min lahko, 10 min izvoz', zone: 'Z5', role: 'kljucna', durationMin: 75, target: { lo: 259, hi: 276 } }), withPm)!
    expect(w.description.length).toBeLessThanOrEqual(500); expect(w.description).toContain('4 × 4 min')
  })
  it('hash: stabilen (isti dan dvakrat, drug datum ali id), drugačen ob drugi vsebini; brez uid/date/hash', () => {
    const a = garminWorkout(day({}), hrOnly)!, b = garminWorkout(day({ id: 'y', date: '2026-11-10', createdAt: '2000-01-01', updatedAt: '2000-01-01' }), hrOnly)!
    expect(a.hash).toBe(b.hash)
    expect(workoutHash(a)).toBe(a.hash)
    expect(workoutHash({ ...a, hash: 'zzz', uid: 'q', date: '1999-01-01' })).toBe(a.hash)
    const c = garminWorkout(day({ durationMin: 75 }), hrOnly)!
    expect(c.hash).not.toBe(a.hash)
    const d = garminWorkout(day({}), { ...hrOnly, lthr: 170 })!
    expect(d.hash).not.toBe(a.hash)
  })
})

describe('v3.52 Garmin — treningi za naslednjih 14 dni', () => {
  const T = '2026-11-02'
  const dd = (i: number) => { const d = new Date(T + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + i); return d.toISOString().slice(0, 10) }
  const plan: PlanDay[] = [
    day({ id: 'p0', date: dd(-1) }),                                                     // včeraj — ne
    day({ id: 'p1', date: dd(0) }),                                                      // danes
    day({ id: 'p2', date: dd(1), done: { at: now } }),                                   // opravljen — ne
    day({ id: 'p3', date: dd(2), kind: 'pocitek', title: 'Počitek', durationMin: 0 }),   // počitek — ne
    day({ id: 'p4', date: dd(3), role: 'dirka', title: 'Tekma' }),                       // dirka — ne
    day({ id: 'p5', date: dd(4), kind: 'moc', title: 'Moč', exercises: [{ name: 'Počep', sets: 3, reps: '10' }] }),
    day({ id: 'p5b', date: dd(4), kind: 'tek', title: 'Lahek tek', durationMin: 30 }),   // isti dan: tek gre, moč ne
    day({ id: 'p6', date: dd(5), kind: 'tek', title: 'Lahek tek', durationMin: 30 }),
    day({ id: 'p6b', date: dd(5), title: 'Z2', durationMin: 60 }),                       // isti dan tek + kolo: kolo ima prednost
    day({ id: 'p7', date: dd(13) }),                                                     // 14. dan — še
    day({ id: 'p8', date: dd(14) }),                                                     // 15. dan — ne
  ]
  it('brez včeraj, opravljenih, počitka, dirke, moči; en trening na dan; 14 dni', () => {
    const out = garminWorkoutsFor(plan, withPm, T)
    expect(out.map(w => w.date)).toEqual([dd(0), dd(4), dd(5), dd(13)])
    expect(out.map(w => w.sport)).toEqual(['CYCLING', 'RUNNING', 'CYCLING', 'CYCLING'])
    expect(out.find(w => w.date === dd(5))!.workoutName).toBe('FORMAI · Z2')
    expect(new Set(out.map(w => w.uid)).size).toBe(out.length)
    expect(garminWorkoutsFor(plan, withPm, T, 3).map(w => w.date)).toEqual([dd(0)])
  })
  it('premor »brez treningov« izpusti vse dni premora, »brez kolesa« samo kolo in test (tudi če načrt še ni prestavljen)', () => {
    const all: Profile = { ...withPm, weekPause: { from: dd(0), to: dd(6), mode: 'vse' } }
    expect(garminWorkoutsFor(plan, all, T).map(w => w.date)).toEqual([dd(13)])
    const bike: Profile = { ...withPm, weekPause: { from: dd(0), to: dd(6), mode: 'kolo' } }
    const out = garminWorkoutsFor(plan, bike, T)
    expect(out.map(w => [w.date, w.sport])).toEqual([[dd(4), 'RUNNING'], [dd(5), 'RUNNING'], [dd(13), 'CYCLING']])
    // premor, ki je mimo, ne vpliva
    const past: Profile = { ...withPm, weekPause: { from: dd(-10), to: dd(-2), mode: 'vse' } }
    expect(garminWorkoutsFor(plan, past, T).length).toBe(4)
  })
})
