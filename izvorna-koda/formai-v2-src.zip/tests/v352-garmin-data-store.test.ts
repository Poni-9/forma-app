import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

/**
 * v3.52 Garmin Connect neposredno — podatki v shrambi (store): prenos s strežnika, dedup z intervals.icu, zdravje in cikel
 * samo na napravi, izklop briše, odklop pusti vožnje. Strežnik je lažen (fetch).
 */
const FB = vi.hoisted(() => ({ user: { uid: 'u1', email: 'a@b.si', name: 'A' } as { uid: string; email: string | null; name: string | null } | null, token: 'tok' as string | null }))
vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => FB.user, signOutNow: async () => undefined,
  idToken: async () => FB.token, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
  timeoutSignal: () => undefined,
}))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { getKV, setKV } from '../src/data/db'
import { PROXY } from '../src/config'
import { todayIso, addDays } from '../src/domain/training/load'
import type { Activity } from '../src/domain/types'

const today = todayIso()
const NOW = new Date().toISOString()
const startSec = Math.floor(new Date(today + 'T06:40:00.000Z').getTime() / 1000)
const rec = (o: Record<string, unknown> = {}) => ({
  summaryId: 'x-1', activityId: 111, activityName: 'Vožnja', activityType: 'CYCLING', startTimeInSeconds: startSec, startTimeOffsetInSeconds: 7200, durationInSeconds: 5400,
  distanceInMeters: 45000, activeKilocalories: 1100, deviceName: 'Edge 540', averageHeartRateInBeatsPerMinute: 140, details: { avgWatts: 190, np: 205 }, t: 1000, ...o,
})
const icuRide: Activity = { id: 'i1', source: 'intervals', originHint: 'GARMIN', sport: 'kolo', date: addDays(today, -1), start: addDays(today, -1) + 'T07:00:30.000Z', name: 'Včeraj', durationMin: 60, distKm: 30, avgHr: 135, aiEligible: true, geoRetain: true, ext: { intervalsId: 'i1' }, createdAt: NOW, updatedAt: NOW }

type Srv = { items?: unknown[]; health?: Record<string, unknown>; mct?: unknown[]; status?: Record<string, unknown>; fail?: { status: number; error: string }; disconnectFail?: boolean }
const calls: string[] = []
const serve = (s: Srv) => vi.stubGlobal('fetch', vi.fn(async (url: string, init?: RequestInit) => {
  calls.push(url.replace(PROXY, '') + (init?.method ? ` ${init.method}` : ''))
  const json = (b: unknown, status = 200) => new Response(JSON.stringify(b), { status, headers: { 'Content-Type': 'application/json' } })
  expect((init?.headers as Record<string, string>).Authorization).toBe('Bearer tok')
  if (s.fail) return json({ error: s.fail.error }, s.fail.status)
  if (url.includes('/garmin/status')) return json(s.status ?? { connected: true, userId: 'g1', permissions: ['ACTIVITY_EXPORT', 'HEALTH_EXPORT', 'MCT_EXPORT', 'WORKOUT_IMPORT'], connectedAt: NOW, lastPushAt: null })
  // (popravki V6) dogovor s strežnikom: now = največji vrnjeni t (ob prazni strani since)
  if (url.includes('/garmin/activities')) { const since = +new URL(url).searchParams.get('since')!; const it = (s.items ?? []).filter(x => ((x as { t: number }).t ?? 0) > since); return json({ items: it, now: it.reduce((m: number, x) => Math.max(m, (x as { t: number }).t ?? 0), since) }) }
  if (url.includes('/garmin/health')) return json({ ...(s.health ?? {}), now: 6000 })
  if (url.includes('/garmin/cycle')) return json({ mct: s.mct ?? [], now: 7000 })
  if (url.includes('/garmin/disconnect')) return s.disconnectFail ? json({ error: 'napaka' }, 500) : json({ ok: true })
  return json({ error: 'napaka' }, 500)
}))
const connected = (o: Record<string, unknown> = {}) => store.updateSettings({ garmin: { connected: true, connectedAt: NOW, userId: 'g1', permissions: ['ACTIVITY_EXPORT', 'HEALTH_EXPORT', 'MCT_EXPORT'], health: true, cycle: true, pushWorkouts: true, pushCourses: true, ...o } })

beforeEach(async () => { await repo.wipeAll(); localStorage.clear(); calls.length = 0; FB.user = { uid: 'u1', email: 'a@b.si', name: 'A' }; FB.token = 'tok'; await store.reloadAll(); await store.signIn() })
afterEach(() => { vi.unstubAllGlobals() })

describe('syncGarmin', () => {
  it('brez povezave nič; brez prijave preskoči z razlogom (napaka za prikaz, brez obvestila)', async () => {
    serve({})
    expect(await store.syncGarmin(true)).toBeNull()
    await connected()
    FB.user = null; await store.wipeThisDevice().catch(() => undefined)   // odjava
    await connected()
    const r = await store.syncGarmin(true)
    expect(r?.skipped).toBe('Ni prijave.'); expect(store.getState().garminErr).toMatch(/prijavi se/)
    expect(calls).toEqual([])
  })
  it('vožnje → aktivnosti (vir garmin, Garmin Edge), dvojnik iz intervals.icu dobi id-je, zdravje in cikel na napravo; since se premakne', async () => {
    await store.addActivities([icuRide])
    const ySec = Math.floor(new Date(icuRide.start!).getTime() / 1000) - 20   // ±90 s od vožnje iz intervals.icu
    serve({
      items: [rec(), rec({ summaryId: 'x-2', activityId: 222, startTimeInSeconds: ySec, durationInSeconds: 3600, distanceInMeters: 30000, details: { avgWatts: 170 }, t: 2000 })],
      // (popravki V7) stres samo iz zapisa za cel dan (partial: false); bodyBatteryAtWake → bbAtWake
      health: { dailies: [{ summaryId: 'd', calendarDate: today, durationInSeconds: 30000, restingHeartRateInBeatsPerMinute: 47, averageStressLevel: 55, partial: false }], sleeps: [{ summaryId: 's', calendarDate: today, durationInSeconds: 27000, overallSleepScore: { value: 80 } }], hrv: [{ summaryId: 'h', calendarDate: today, lastNightAvg: 60 }], stress: [{ summaryId: 'st', calendarDate: today, bodyBatteryAtWake: 72 }] },
      mct: [{ calendarDate: today, dayInCycle: 3, cycleLength: 28, periodLength: 5, currentPhaseType: 'MENSTRUAL' }],
    })
    await connected()
    const r = await store.syncGarmin(true)
    expect(r).toMatchObject({ added: 1, upgraded: 1, healthDays: 1, cycleDays: 1, error: null, skipped: null })
    const s = store.getState()
    const g = s.activities.find(a => a.source === 'garmin')!
    expect(g.ext).toEqual({ garminId: '111', garminSummaryId: 'x-1' }); expect(g.deviceName).toBe('Edge 540'); expect(g.avgPower).toBe(190); expect(g.date).toBe(today)
    const i = s.activities.find(a => a.id === 'i1')!
    expect(i.source).toBe('intervals'); expect(i.ext).toEqual({ intervalsId: 'i1', garminId: '222', garminSummaryId: 'x-2' }); expect(i.avgPower).toBe(170); expect(i.deviceWatts).toBe(true)
    expect(s.activities.filter(a => a.sport === 'kolo')).toHaveLength(2)
    expect(s.wellness).toEqual([{ date: today, sleepH: 7.5, sleepScore: 80, hrv: 60, rhr: 47, stress: 55, bodyBattery: 72, bbAtWake: true }])
    expect(s.cycle).toEqual([{ date: today, dayInCycle: 3, cycleLength: 28, periodLength: 5, phase: 'menstrualna', predicted: false, periodStartDate: null }])
    expect(await getKV('garmin.since')).toBe(2000); expect(await getKV('garmin.healthSince')).toBe(6000); expect(await getKV('garmin.cycleSince')).toBe(7000)
    expect((await getKV<{ days: unknown[] }>('garmin.wellness'))!.days).toHaveLength(1)
    expect(await getKV('wellness.v1')).toBeUndefined()   // zdravje z Garmina ni pomešano s ključem intervals.icu
    expect(s.settings.garmin?.lastSyncAt).toBeTruthy(); expect(s.settings.garmin?.lastError ?? null).toBeNull(); expect(s.garminErr).toBeNull()
    expect(calls.filter(c => c.startsWith('/garmin/activities'))).toEqual(['/garmin/activities?since=0'])
    // znova: pravkar preverjeno; s force ponovno, a brez dvojnikov (since)
    expect((await store.syncGarmin(false))?.skipped).toBe('Pravkar preverjeno.')
    const r2 = await store.syncGarmin(true)
    expect(r2).toMatchObject({ added: 0, upgraded: 0 })
    expect(calls.filter(c => c.startsWith('/garmin/activities')).pop()).toBe('/garmin/activities?since=2000')
    expect(store.getState().activities.filter(a => a.sport === 'kolo')).toHaveLength(2)
  })
  it('isti zapis znova (t novejši, podrobnosti dodane) nadgradi obstoječega, ne podvoji; izbrisana (grob) se ne vrne', async () => {
    serve({ items: [rec({ details: null })] })
    await connected({ health: false, cycle: false })
    await store.syncGarmin(true)
    let g = store.getState().activities.find(a => a.source === 'garmin')!
    expect(g.avgPower).toBeNull(); expect(g.deviceWatts).toBe(false)
    serve({ items: [rec({ t: 3000, details: { avgWatts: 190, np: 205, polyline: 'pl' } })] })
    await store.syncGarmin(true)
    const acts = store.getState().activities.filter(a => a.source === 'garmin')
    expect(acts).toHaveLength(1); g = acts[0]!
    expect(g.avgPower).toBe(190); expect(g.deviceWatts).toBe(true); expect(g.polyline).toBe('pl')
    await store.removeActivity(g.id)
    serve({ items: [rec({ t: 4000 })] })
    await store.syncGarmin(true)
    expect(store.getState().activities.filter(a => a.source === 'garmin')).toHaveLength(0)
  })
  it('zdravje in cikel se NE prenašata brez vklopa ali brez dovoljenja', async () => {
    serve({ health: { dailies: [{ summaryId: 'd', calendarDate: today, restingHeartRateInBeatsPerMinute: 47 }] }, mct: [{ calendarDate: today, dayInCycle: 3 }], status: { connected: true, userId: 'g1', permissions: ['ACTIVITY_EXPORT', 'HEALTH_EXPORT'] } })
    await connected({ health: false, cycle: true, permissions: ['ACTIVITY_EXPORT', 'HEALTH_EXPORT'] })
    await store.syncGarmin(true)
    expect(await getKV('garmin.wellness')).toBeUndefined(); expect(await getKV('garmin.cycle')).toBeUndefined()
    expect(calls.some(c => c.startsWith('/garmin/health') || c.startsWith('/garmin/cycle'))).toBe(false)
  })
  it('napaka strežnika: slovensko v state.garminErr in settings.lastError; 409 (ni povezave) → connected: false', async () => {
    serve({ fail: { status: 500, error: 'napaka' } })
    await connected()
    const r = await store.syncGarmin(true)
    expect(r?.error).toMatch(/Strežnik/); expect(store.getState().garminErr).toBe(r!.error); expect(store.getState().settings.garmin?.lastError).toBe(r!.error)
    serve({ fail: { status: 409, error: 'ni_povezave' } })
    await store.syncGarmin(true)
    expect(store.getState().settings.garmin?.connected).toBe(false); expect(store.getState().garminErr).toBe('Garmin ni povezan — poveži ga znova.')
    serve({})
    await connected()
    await store.syncGarmin(true)
    expect(store.getState().garminErr).toBeNull(); expect(store.getState().settings.garmin?.lastError ?? null).toBeNull()
  })
})

describe('možnosti, odklop, vrnitev z Garmina', () => {
  const health = { dailies: [{ summaryId: 'd', calendarDate: today, restingHeartRateInBeatsPerMinute: 47 }] }
  it('izklop health briše dneve z Garmina (intervals.icu ostane); izklop cycle briše cikel', async () => {
    serve({ health, mct: [{ calendarDate: today, dayInCycle: 3 }] })
    await setKV('wellness.v1', { at: Date.now(), days: [{ date: addDays(today, -1), sleepH: 7, sleepScore: null, hrv: null, rhr: 50 }] })
    await store.updateSettings({ wellnessOn: true })
    await connected()
    await store.syncGarmin(true)
    expect(store.getState().wellness?.map(d => d.date)).toEqual([addDays(today, -1), today]); expect(store.getState().cycle).toHaveLength(1)
    await store.setGarminOpt('health', false)
    expect(store.getState().wellness?.map(d => d.date)).toEqual([addDays(today, -1)]); expect(await getKV('garmin.wellness')).toBeNull()
    await store.setGarminOpt('cycle', false)
    expect(store.getState().cycle).toBeNull(); expect(await getKV('garmin.cycle')).toBeNull()
    expect(store.getState().settings.garmin).toMatchObject({ health: false, cycle: false })
    // vklop prenese takoj
    await store.setGarminOpt('health', true)
    expect(store.getState().wellness?.map(d => d.date)).toEqual([addDays(today, -1), today])
  })
  it('vklop cikla brez dovoljenja MCT_EXPORT: nastavitev ostane, prenosa ni, obvestilo', async () => {
    serve({ mct: [{ calendarDate: today, dayInCycle: 3 }] })
    await connected({ cycle: false, permissions: ['ACTIVITY_EXPORT'] })
    await store.setGarminOpt('cycle', true)
    expect(store.getState().settings.garmin?.cycle).toBe(true); expect(store.getState().cycle).toBeNull()
    expect(store.getState().toast?.msg).toMatch(/ne deli podatkov o ciklu/)
  })
  it('odklop: strežnik, nastavitev null, zdravje in cikel stran — VOŽNJE OSTANEJO; ob napaki strežnika nič', async () => {
    serve({ items: [rec()], health, mct: [{ calendarDate: today, dayInCycle: 3 }] })
    await connected()
    await store.syncGarmin(true)
    expect(store.getState().activities.filter(a => a.source === 'garmin')).toHaveLength(1)
    serve({ disconnectFail: true })
    expect(await store.disconnectGarmin()).toBe(false)
    expect(store.getState().settings.garmin?.connected).toBe(true); expect(store.getState().cycle).toHaveLength(1)
    serve({})
    expect(await store.disconnectGarmin()).toBe(true)
    expect(calls).toContain('/garmin/disconnect POST')
    const s = store.getState()
    expect(s.settings.garmin).toBeNull(); expect(s.cycle).toBeNull(); expect(s.wellness).toBeNull()
    expect(s.activities.filter(a => a.source === 'garmin')).toHaveLength(1)
    expect(await getKV('garmin.since')).toBeNull(); expect(await getKV('garmin.cycle')).toBeNull()
    expect(s.toast?.msg).toMatch(/vožnje ostanejo/)
  })
  it('vrnitev ?garmin=ok: stanje s strežnika → nastavitve (dovoljenja), parameter ven, prvi prenos; ?garmin=err → obvestilo', async () => {
    serve({ items: [rec()] })
    history.replaceState(null, '', '/?garmin=ok&pilot=ABC#/uvoz')
    expect(await store.finishGarminConnect()).toBe(true)
    expect(location.search).toBe('?pilot=ABC'); expect(location.hash).toBe('#/uvoz')
    const g = store.getState().settings.garmin!
    expect(g).toMatchObject({ connected: true, userId: 'g1', permissions: ['ACTIVITY_EXPORT', 'HEALTH_EXPORT', 'MCT_EXPORT', 'WORKOUT_IMPORT'], pushWorkouts: true, pushCourses: true, health: false, cycle: false })
    await new Promise(r => setTimeout(r, 50))
    expect(store.getState().activities.filter(a => a.source === 'garmin')).toHaveLength(1)
    history.replaceState(null, '', '/?garmin=err')
    expect(await store.finishGarminConnect()).toBe(true)
    expect(store.getState().toast?.msg).toMatch(/ni uspela/); expect(location.search).toBe('')
    history.replaceState(null, '', '/')
    expect(await store.finishGarminConnect()).toBe(false)
  })
  it('garminAllows: neznana dovoljenja dovolijo, znana odločajo', () => {
    expect(store.garminAllows({ connected: true, permissions: null }, 'HEALTH_EXPORT')).toBe(true)
    expect(store.garminAllows({ connected: true, permissions: ['ACTIVITY_EXPORT'] }, 'HEALTH_EXPORT')).toBe(false)
    expect(store.garminAllows({ connected: false, permissions: null }, 'HEALTH_EXPORT')).toBe(false)
    expect(store.garminAllows(null, 'HEALTH_EXPORT')).toBe(false)
  })
})
