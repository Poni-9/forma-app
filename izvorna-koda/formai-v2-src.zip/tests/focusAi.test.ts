import { describe, it, expect } from 'vitest'
import type { Focus, Profile } from '../src/domain/types'
import { questionsPrompt, parseQuestions, proposalPrompt, parseProposal, exercisesPrompt, parseExercises, parseStrategy, libraryFor, focusContext } from '../src/domain/ai/focusAi'
import { ruleQuestions, ruleProposal, ruleAdjust, ruleStrategy, wishSignals } from '../src/domain/focus/rules'
import { normalizeFocus } from '../src/domain/focus/model'
import { aiContext, coachDailyPrompt, CUSTOM_MARK } from '../src/domain/ai/prompts'
import { EXERCISES } from '../src/domain/training/exercises'
import { loggedExercises } from '../src/screens/Vadba'

const NOW = '2026-10-07T08:00:00.000Z'
const base: Profile = { sex: 'm', age: 24, heightCm: 182, weightKg: 84, name: 'Blaž', gear: { bikeOutdoor: false, trainer: false, noBike: true }, strength: { on: true, equipment: 'gym' }, onboardingDone: true, createdAt: NOW, updatedAt: NOW }
const WISH = 'Hodim v fitnes, rad bi malo teka in ful kondicije. Six pack, vitka a močna postava — med hujšanjem ne izgubiti mišic. Samo zgornji del.'
const focus = (): Focus => normalizeFocus({
  wish: WISH, title: 'Vitek in močan', sports: ['fitnes', 'tek'], aims: ['definicija', 'kondicija', 'moc'], muscles: ['trebuh', 'ramena'], level: 2, equipment: ['fitnes'], keepMuscle: true,
  sessions: [{ type: 'fitnes', part: 'potisk', min: 60 }, { type: 'tek', cardio: 'intervali', min: 35 }, { type: 'fitnes', part: 'poteg', min: 60 }, { type: 'tek', cardio: 'lahko', min: 45 }],
}, { now: NOW, by: 'ai' })!

describe('AI pogovor: pozivi in razčlenjevanje', () => {
  it('pozivi: želja in osnovni podatki, nikoli ime; 1. in 2. krog', () => {
    const q1 = questionsPrompt({ wish: WISH, basics: { sex: 'm', age: 24, heightCm: 182, weightKg: 84 }, qa: [], round: 1 })[0] as { text: string }
    expect(q1.text).toContain('Six pack')
    expect(q1.text).toContain('24 let')
    expect(q1.text).not.toContain('Blaž')
    expect(q1.text).toContain('1. krog')
    const q2 = questionsPrompt({ wish: WISH, basics: {}, qa: [{ q: 'Koliko dni?', a: '5' }], round: 2 })[0] as { text: string }
    expect(q2.text).toContain('2. krog')
    expect(q2.text).toContain('Koliko dni? → 5')
    const p = proposalPrompt({ wish: WISH, basics: {}, qa: [], prev: focus(), feedback: 'Več kardia' })[0] as { text: string }
    expect(p.text).toContain('»Več kardia«')
    expect(p.text).toContain('Prejšnji predlog')
  })
  it('vprašanja: neveljavna izpadejo, največ 5, varni id-ji; brez vprašanj je dovolj', () => {
    const out = parseQuestions({ razumel: ' Hočeš  vitko postavo. ', vprasanja: [
      { id: 'dni!', vprasanje: 'Koliko dni na teden?', moznosti: ['3', '4', '4'], vec: false },
      { id: 'x', vprasanje: 'Brez možnosti?', moznosti: [] },
      ...Array.from({ length: 6 }, (_, i) => ({ id: `q${i}`, vprasanje: `Vprašanje številka ${i}?`, moznosti: ['a', 'b'] })),
    ], dovolj: false })!
    expect(out.understood).toBe('Hočeš vitko postavo.')
    expect(out.questions).toHaveLength(5)
    expect(out.questions[0]).toMatchObject({ id: 'dni', options: ['3', '4'], multi: false, other: true })
    expect(parseQuestions({ vprasanja: [] })!.enough).toBe(true)
    expect(parseQuestions('ni json')).toBeNull()
  })
  it('predlog: gre skozi varovalke (do 18 let brez hujšanja), hitri odgovori največ 5; smeti → null', () => {
    const raw = { odgovor: 'Predlagam **4 dni**.', ime: 'Vitek', sporti: ['fitnes', 'tek'], cilji: ['hujsanje', 'moc'], misice: ['trebuh'], raven: 2, oprema: ['fitnes'], seje: [{ vrsta: 'fitnes', del: 'zgornji', min: 60 }, { vrsta: 'tek', kardio: 'lahko', min: 40 }], hitri: ['a', 'b', 'c', 'd', 'e', 'f'] }
    const ok = parseProposal(raw, { wish: WISH, age: 24, now: NOW })!
    expect(ok.reply).toBe('Predlagam 4 dni.')
    expect(ok.focus.sessions).toHaveLength(2)
    expect(ok.focus.aims).toContain('hujsanje')
    expect(ok.quick).toHaveLength(5)
    expect(parseProposal(raw, { wish: WISH, age: 16 })!.focus.aims).not.toContain('hujsanje')
    expect(parseProposal({ odgovor: 'x', seje: [] }, { wish: WISH })).toBeNull()
  })
  it('izbor vaj: samo iz knjižnice (neznani id-ji izpadejo), manj kot 3 → pravila; knjižnica brez naprav doma', () => {
    const f = focus()
    const out = parseExercises({ seje: [{ i: 0, vaje: ['bench', 'ni-take', 'ohp', 'triceps-k'], zakaj: 'Potisk za ramena.' }, { i: 2, vaje: ['pulldown'] }, { i: 1, vaje: ['bench', 'ohp', 'dipi'] }] }, f)
    expect(out.sessions[0]!.ex).toEqual(['bench', 'ohp', 'triceps-k'])
    expect(out.sessions[0]!.why).toBe('Potisk za ramena.')
    expect(out.sessions[2]!.ex).toBeUndefined()
    expect(out.sessions[1]!.ex).toBeUndefined()   // tek nima vaj
    const home = { ...f, equipment: ['nic' as const], sessions: [{ type: 'doma' as const, part: 'celo' as const, min: 40 }] }
    const lib = libraryFor(home)
    expect(lib).not.toMatch(/— Potisk s palico na ravni klopi/)
    expect(lib.split('\n').every(l => EXERCISES.find(e => l.startsWith(e.id + ' '))?.eq === 'nic')).toBe(true)
    expect((exercisesPrompt(f, {})[0] as { text: string }).text).toContain('- 0: Fitnes, prsa, ramena, triceps, 60 min')
  })
  it('strategija: vrstice z »– «, brez markdowna, največ 8', () => {
    const f = parseStrategy({ strategija: '**Teden**: 3× moč\n- Prehrana: beljakovine\n' + Array.from({ length: 10 }, (_, i) => `– vrstica ${i}`).join('\n'), seje: ['Zakaj 0', 'Zakaj 1'] }, focus())
    const lines = f.strategy!.split('\n')
    expect(lines).toHaveLength(8)
    expect(lines[0]).toBe('– Teden: 3× moč')
    expect(lines[1]).toBe('– Prehrana: beljakovine')
    expect(f.sessions[1]!.why).toBe('Zakaj 1')
  })
})

describe('brez AI: vprašalnik, predlog in pogajanje po pravilih', () => {
  it('signali iz besed: six pack → trebuh, hujšanje z mišicami, samo zgornji del', () => {
    const s = wishSignals(WISH)
    expect(s.muscles).toContain('trebuh')
    expect(s.aims).toEqual(expect.arrayContaining(['hujsanje', 'definicija', 'kondicija']))
    expect(s.keepMuscle).toBe(true)
    expect(s.upperOnly).toBe(true)
  })
  it('predlog iz odgovorov: dnevi, čas, fitnes in tek; pogajanje: več kardia, manj dni', () => {
    const q = ruleQuestions(WISH)
    expect(q.questions.map(x => x.id)).toEqual(expect.arrayContaining(['dni', 'cas', 'kje', 'kardio', 'izkusnje', 'poskodbe']))
    const qa = [{ id: 'dni', q: 'dni', a: '5' }, { id: 'cas', q: 'cas', a: '60 min' }, { id: 'kje', q: 'kje', a: 'V fitnesu' }, { id: 'kardio', q: 'kardio', a: 'Tek' }, { id: 'izkusnje', q: 'izkusnje', a: 'Nekaj izkušenj' }, { id: 'poskodbe', q: 'poskodbe', a: 'Ne' }]
    const p = ruleProposal(WISH, qa, 24)
    expect(p.focus.sessions).toHaveLength(5)
    expect(p.focus.sessions.some(s => s.type === 'fitnes')).toBe(true)
    expect(p.focus.sessions.some(s => s.type === 'tek')).toBe(true)
    // samo zgornji del: brez seje za noge
    expect(p.focus.sessions.some(s => s.part === 'noge' || s.part === 'spodnji')).toBe(false)
    const more = ruleAdjust(p.focus, 'Več kardia', 24)!
    expect(more.sessions.filter(s => s.type === 'tek').length).toBeGreaterThan(p.focus.sessions.filter(s => s.type === 'tek').length)
    const less = ruleAdjust(p.focus, 'Manj dni', 24)!
    expect(less.sessions.length).toBe(p.focus.sessions.length - 1)
    expect(ruleAdjust(p.focus, 'kar nekaj', 24)).toBeNull()
    expect(ruleStrategy(p.focus, { kcal: 2250, proteinG: 168, deficit: 350 })).toContain('– ')
  })
})

describe('trener po meri', () => {
  it('kontekst AI: oznaka načrta po meri in dogovor; poziv brez vatov in dirke', () => {
    const p: Profile = { ...base, focus: focus() }
    const ctx = aiContext([], p, [])
    expect(ctx).toContain(CUSTOM_MARK)
    expect(ctx).toContain('Vitek in močan')
    expect(ctx).not.toContain('Blaž')
    const t = (coachDailyPrompt(ctx, [])[0] as { text: string }).text
    expect(t).toContain('osebni trener za fitnes, tek in kondicijo')
    expect(t).not.toContain('z vati za današnjo sejo')
    expect(focusContext(p)).toContain('Njegove besede')
    const cyc = (coachDailyPrompt(aiContext([], base, []), [])[0] as { text: string }).text
    expect(cyc).toContain('kolesarski trener')
  })
  it('vadba: zapisane so samo vaje, ki si jih delal, s ponovitvami po serijah in največ kg', () => {
    const day = { id: 'd', date: '2026-10-07', kind: 'moc' as const, title: 'Fitnes — potisk', desc: '', durationMin: 60, exercises: [{ name: 'Potisk s palico na ravni klopi', sets: 3, reps: '6–10', kg: 40 }, { name: 'Sklece', sets: 3, reps: '8–15' }] }
    const steps = [{ kind: 'vaja' as const, label: 'Potisk s palico na ravni klopi', sec: 0 }, { kind: 'pavza' as const, label: 'Pavza', sec: 90 }, { kind: 'vaja' as const, label: 'Potisk s palico na ravni klopi', sec: 0 }, { kind: 'vaja' as const, label: 'Sklece', sec: 0 }]
    const ex = loggedExercises({ day: day as never, steps, log: { 0: { kg: 40, reps: 10 }, 2: { kg: 42.5, reps: 8 } } })
    expect(ex).toEqual([{ name: 'Potisk s palico na ravni klopi', sets: 2, reps: '10, 8', kg: 42.5 }])
    expect(loggedExercises({ day: day as never, steps, log: {} })).toHaveLength(2)
  })
})
