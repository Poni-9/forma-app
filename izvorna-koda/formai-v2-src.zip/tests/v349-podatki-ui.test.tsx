// v3.49 PODATKI (zasloni): list testa in cilja z razponi, tehtanje s potrditvijo skoka, meja napake zaslona,
// izbris jutranjega vnosa, seznam vadb z iskanjem in »Pokaži več« brez ponovnega izrisa že prikazanih mesecev.
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, afterEach, beforeAll, afterAll } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'napredek', params: {} as Record<string, string> }, calls: { aiAllowed: 0 } }))
vi.mock('@/state/store', async () => {
  const { vi: v } = await import('vitest')
  const base: Record<string | symbol, unknown> = {
    useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
    getState: () => S.state,
    latestFtpTest: (tests: { kind: string; date: string; value: number }[]) => tests.filter(t => t.kind === 'ftp').sort((a, b) => a.date.localeCompare(b.date)).pop() ?? null,
  }
  // vse druge funkcije stanja so prazne (zaslon jih kliče samo ob tapu)
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' || typeof k === 'symbol' ? undefined : (t[k] = v.fn(async () => {}))), has: (_t, k) => k !== 'then' })
})
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => S.route, parseHash: () => S.route, subscribeRoute: () => () => undefined }))
vi.mock('@/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
vi.mock('@/ui/HelpSheet', () => ({ startFeedback: vi.fn(async () => {}) }))
vi.mock('@/ui/overlays', () => ({ openHelp: vi.fn() }))
vi.mock('@/ui/PilotPrompt', () => ({ PilotPrompt: () => null }))
vi.mock('@/ui/PullRefresh', () => ({ PullRefresh: () => null }))
vi.mock('@/domain/import/provenance', async (orig) => {
  const m = await orig<typeof import('../src/domain/import/provenance')>()
  return { ...m, aiAllowed: (a: Parameters<typeof m.aiAllowed>[0]) => { S.calls.aiAllowed++; return m.aiAllowed(a) } }
})

import * as store from '@/state/store'
import { TestSheet } from '@/screens/Napredek'
import { GoalSheet } from '@/ui/GoalSheet'
import { WeighSheet } from '@/ui/WeighSheet'
import { Shell } from '@/app/Shell'
import { Checkin } from '@/ui/Checkin'
import { Aktivnosti, PAGE } from '@/screens/Aktivnosti'
import { addDays } from '@/domain/training/load'
import type { Activity, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-17'
beforeAll(() => { vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date(`${TODAY}T10:00:00`)) })
afterAll(() => { vi.useRealTimers() })

let div: HTMLDivElement | null = null, root: Root | null = null
async function render(el: ReactElement): Promise<HTMLDivElement> {
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root!.render(el) })
  return div
}
afterEach(async () => { if (root) await act(async () => root!.unmount()); div?.remove(); root = null; div = null; vi.clearAllMocks() })
const sp = (x: string) => x.replace(/[  ⁠]/g, ' ')
const txt = () => sp(document.body.textContent || '')
const btn = (label: string) => [...document.body.querySelectorAll('button')].find(b => sp(b.textContent || '').trim() === label) as HTMLButtonElement
const type = async (el: HTMLInputElement, v: string) => {
  await act(async () => {
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(el, v)
    el.dispatchEvent(new Event('input', { bubbles: true }))
  })
}
const click = async (b: HTMLElement) => { await act(async () => { b.click() }) }

const NOW = `${TODAY}T08:00:00.000Z`
const P = {
  sex: 'm', age: 30, heightCm: 180, weightKg: 79.8, ftp: 228, ftpDate: '2026-09-01', maxHr: 190, restHr: 50, hoursPerWeek: 8, hoursMode: 'own',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true }, strength: { on: false, equipment: 'none' }, strengthDays: 0,
  onboardingDone: true, goal: 'dirka', createdAt: NOW, updatedAt: NOW, event: { name: 'Maraton Franja', date: '2027-06-13', distanceKm: 156 },
} as unknown as Profile
const state = (o: Record<string, unknown> = {}) => ({
  ready: true, today: TODAY, profile: P, settings: { lang: 'sl', intervals: null, tests: [{ id: 't1', date: '2026-09-01', kind: 'ftp', value: 240, unit: 'W' }] },
  activities: [], plan: [], checkins: [], checkinToday: null, recentMeals: [], mealsToday: [], weather: null, wellness: null, sync: { state: 'off' }, user: null, ...o,
})

describe('D03 Vpiši test: razpon in potrditev skoka', () => {
  it('5000 W: sporočilo pod poljem, test se ne shrani', async () => {
    S.state = state()
    await render(<TestSheet open onClose={() => undefined} />)
    await type(document.getElementById('test-val') as HTMLInputElement, '5000')
    await click(btn('Shrani'))
    expect(store.addTest).not.toHaveBeenCalled()
    expect(txt()).toContain('20-min test: od 60 do 630 W.')
    expect(document.getElementById('test-val')!.getAttribute('aria-invalid')).toBe('true')
  })
  it('340 W po zadnjem testu 240 W: najprej vprašanje, nato »Da, shrani« shrani', async () => {
    S.state = state()
    await render(<TestSheet open onClose={() => undefined} />)
    await type(document.getElementById('test-val') as HTMLInputElement, '340')
    await click(btn('Shrani'))
    expect(store.addTest).not.toHaveBeenCalled()
    expect(txt()).toContain('To je 42 % več od zadnjega testa (240 W). Shranim?')
    await click(btn('Da, shrani'))
    expect(store.addTest).toHaveBeenCalledTimes(1)
    expect((store.addTest as unknown as { mock: { calls: [{ value: number }][] } }).mock.calls[0]![0].value).toBe(340)
  })
})

describe('D04 Cilj sezone: razponi teže, FTP in maščobe', () => {
  it('7,6 kg in FTP 5000 W: sporočilo, »Potrdi« onemogočen, profil se ne spremeni', async () => {
    S.state = state({ profile: { ...P, ftp: null } })
    await render(<GoalSheet open onClose={() => undefined} />)
    await type(document.getElementById('gs-w') as HTMLInputElement, '7.6')
    await type(document.getElementById('gs-ftp') as HTMLInputElement, '5000')
    expect(txt()).toContain('FTP: od 50 do 600 W. Teža: od 30 do 250 kg.')
    const ok = btn('Potrdi in sestavi načrt')
    expect(ok.disabled).toBe(true)
    await click(ok)
    expect(store.updateProfile).not.toHaveBeenCalled()
    expect(store.saveCheckin).not.toHaveBeenCalled()
    expect(document.getElementById('gs-w')!.getAttribute('aria-invalid')).toBe('true')
  })
})

describe('B17 Tehtanje: 97 namesto 79', () => {
  const ci = (date: string, kg: number) => ({ date, weightKg: kg })
  it('ne shrani, dokler ne potrdiš; »Popravi« pusti popraviti', async () => {
    S.state = state({ checkins: [ci('2026-10-13', 79.6), ci('2026-10-15', 80.0), ci('2026-10-16', 79.8)] })
    await render(<WeighSheet open onClose={() => undefined} />)
    await type(document.getElementById('weigh-kg') as HTMLInputElement, '97')
    await click(btn('Shrani'))
    expect(store.saveCheckin).not.toHaveBeenCalled()
    expect(txt()).toContain('To je 17,2 kg več kot tvoje povprečje (79,8 kg) — morda 79,0 kg? Je prav?')
    await click(btn('Popravi'))
    expect(txt()).not.toContain('Je prav?')
    await type(document.getElementById('weigh-kg') as HTMLInputElement, '79')
    await click(btn('Shrani'))
    expect(store.saveCheckin).toHaveBeenCalledTimes(1)
  })
  it('potrjen skok se shrani; tehtanje tega dne se da izbrisati', async () => {
    S.state = state({ checkins: [ci('2026-10-15', 80.0), ci('2026-10-16', 79.8), ci(TODAY, 79.9)] })
    await render(<WeighSheet open onClose={() => undefined} />)
    await type(document.getElementById('weigh-kg') as HTMLInputElement, '85')
    await click(btn('Shrani'))
    await click(btn('Da, prav je'))
    expect(store.saveCheckin).toHaveBeenCalledTimes(1)
    await type(document.getElementById('weigh-kg') as HTMLInputElement, '79.9')
    await click(btn('Izbriši tehtanje 17. 10.'))
    expect(store.removeWeigh).toHaveBeenCalledWith(TODAY)
  })
})

describe('D10 napaka enega zaslona', () => {
  function Boom(): never { throw new Error("Cannot read properties of undefined (reading 'trim')") }
  it('zavihki ostanejo, slovensko sporočilo v main, podrobnosti skrite, »Poskusi znova« izriše znova', async () => {
    S.state = state(); S.route = { name: 'prehrana', params: {} }
    const err = vi.spyOn(console, 'error').mockImplementation(() => undefined)
    let boom = true
    function Maybe() { if (boom) Boom(); return <p>Prehrana dela</p> }
    try {
      await render(<Shell><Maybe /></Shell>)
      expect(document.querySelectorAll('nav.tabs button').length).toBe(5)
      const main = document.querySelector('main')!
      expect(sp(main.textContent || '')).toContain('Ta zaslon se ni naložil')
      expect(sp(main.textContent || '')).toContain('Drugi zavihki delajo — tvoji podatki so na napravi.')
      expect(main.querySelector('details pre')!.textContent).toContain("reading 'trim'")
      expect(main.querySelector('details')!.hasAttribute('open')).toBe(false)
      boom = false
      await click(btn('Poskusi znova'))
      expect(sp(main.textContent || '')).toContain('Prehrana dela')
    } finally { err.mockRestore(); S.route = { name: 'napredek', params: {} } }
  })
})

describe('D18 izbris jutranjega vnosa', () => {
  it('»uredi« → »izbriši« pokliče izbris današnjega vnosa', async () => {
    S.state = state({ checkinToday: { date: TODAY, mood: 4, soreness: 2, sleepH: 7 }, settings: {} })
    await render(<Checkin compact />)
    await click(btn('uredi'))
    await click(btn('izbriši'))
    expect(store.removeCheckin).toHaveBeenCalledWith(TODAY)
  })
})

describe('D19 seznam vseh vadb', () => {
  // trije meseci po 50 vadb: ob »Pokaži več« se prvi (že prikazan) mesec ne izriše znova
  const acts: Activity[] = []
  for (const [m, n] of [['2026-10', 50], ['2026-09', 50], ['2026-08', 50]] as const) for (let i = 0; i < n; i++) {
    const date = `${m}-${String(28 - (i % 28)).padStart(2, '0')}`
    acts.push({ id: `${m}-${i}`, source: 'manual', sport: 'kolo', date, name: i === 7 && m === '2026-08' ? 'Vršič čez Kranjsko Goro' : `Vožnja ${i}`, durationMin: 60, aiEligible: true, geoRetain: false, createdAt: NOW, updatedAt: NOW } as Activity)
  }
  acts.sort((a, b) => b.date.localeCompare(a.date) || a.id.localeCompare(b.id))
  it('»Pokaži več« izriše samo nove kartice; iskanje brez šumnikov', async () => {
    S.state = state({ activities: acts }); S.route = { name: 'aktivnosti', params: {} }
    try {
      await render(<Aktivnosti />)
      expect(document.querySelectorAll('.act-month .sess').length).toBe(PAGE)
      S.calls.aiAllowed = 0
      await click([...document.querySelectorAll('button')].find(b => /Pokaži več/.test(b.textContent || ''))!)
      expect(document.querySelectorAll('.act-month .sess').length).toBe(2 * PAGE)
      // starš prešteje vse (150), kartice: samo drugi mesec (dopolnjen) in tretji — ne prvih 50 znova
      expect(S.calls.aiAllowed).toBeLessThanOrEqual(150 + 2 * PAGE - 50)
      const q = document.querySelector('input[type=search]') as HTMLInputElement
      expect(q.placeholder).toBe('Išči vadbo (ime, opomba, mesec)')
      await type(q, 'vrsic')
      expect([...document.querySelectorAll('.act-month .sess b')].map(b => b.textContent)).toEqual(['Vršič čez Kranjsko Goro'])
      await type(q, 'avgust 2026')
      expect(document.querySelectorAll('.act-month .sess').length).toBe(50)
      await type(q, 'ni takega')
      expect(txt()).toContain('Nobena vadba ne ustreza »ni takega«.')
    } finally { S.route = { name: 'napredek', params: {} } }
  })
  it('PAGE ostane 60 (ena stran)', () => { expect(PAGE).toBe(60); expect(addDays(TODAY, 1)).toBe('2026-10-18') })
})
