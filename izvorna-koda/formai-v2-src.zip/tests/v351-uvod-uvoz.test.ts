// v3.51 UVOD-UVOZ (domena): GPX/TCX čas gibanja (F06), vati (F07), šport iz ure (F08), imena iz Stravinega arhiva
// (F20), kalorije TCX (F21), hitrost ročnega vnosa (F22), vaje (F23), prost dan s časom (F05), en dan na teden (F04).
import { describe, it, expect } from 'vitest'
import JSZip from 'jszip'
import { parseGpx, parseTcx, guessSport, movingMinOf, toActivity } from '../src/domain/import/parsers'
import { parseArchive, stravaNames, csvRows } from '../src/domain/import/archive'
import { manualActivityErrors, exerciseErrors } from '../src/domain/ranges'
import { coachReview, freeOpenDays } from '../src/domain/focus/coach'
import { normalizeFocus, trainingDays } from '../src/domain/focus/model'
import { ruleProposal } from '../src/domain/focus/rules'


/** GPX: 30 min vožnje (~30 km/h), 60 min na isti točki (kava), 30 min vožnje; po točko na 10 s */
function gpxWithStop(extra = ''): string {
  let s = '<?xml version="1.0"?><gpx version="1.1" xmlns="http://www.topografix.com/GPX/1/1" xmlns:gpxtpx="http://www.garmin.com/xmlschemas/TrackPointExtension/v1"><trk><name>Kava v Kranju</name><type>cycling</type><trkseg>'
  let lat = 46.19, t = Date.UTC(2026, 9, 18, 7, 0, 0)
  const pt = (pw: string) => { s += `<trkpt lat="${lat.toFixed(6)}" lon="14.490000"><ele>300</ele><time>${new Date(t).toISOString()}</time>${pw}</trkpt>` }
  // 30 km/h = 83 m na 10 s ≈ 0,00075° širine
  for (let i = 0; i < 180; i++) { pt(extra); lat += 0.00075; t += 10_000 }
  for (let i = 0; i < 360; i++) { pt(''); t += 10_000 }
  for (let i = 0; i <= 180; i++) { pt(extra); lat += 0.00075; t += 10_000 }
  return s + '</trkseg></trk></gpx>'
}
function tcx(o: { watts?: number; kcal?: number[]; stop?: boolean } = {}): string {
  let s = '<?xml version="1.0"?><TrainingCenterDatabase xmlns="http://www.garmin.com/xmlschemas/TrainingCenterDatabase/v2" xmlns:ns3="http://www.garmin.com/xmlschemas/ActivityExtension/v2"><Activities><Activity Sport="Biking">'
  const laps = o.kcal || [0]
  let d = 0, t = Date.UTC(2026, 9, 18, 7, 0, 0)
  laps.forEach((k, li) => {
    s += `<Lap StartTime="${new Date(t).toISOString()}">${k ? `<Calories>${k}</Calories>` : ''}<Track>`
    for (let i = 0; i < 360; i++) {
      const stopped = o.stop && li === 0 && i >= 180
      s += `<Trackpoint><Time>${new Date(t).toISOString()}</Time><DistanceMeters>${d.toFixed(1)}</DistanceMeters>${o.watts != null ? `<Extensions><ns3:TPX><ns3:Watts>${o.watts}</ns3:Watts></ns3:TPX></Extensions>` : ''}</Trackpoint>`
      if (!stopped) d += 83
      t += 10_000
    }
    s += '</Track></Lap>'
  })
  return s + '</Activity></Activities></TrainingCenterDatabase>'
}

describe('F06 GPX/TCX: čas gibanja brez postankov', () => {
  it('ura kave: 61 min gibanja, 121 min s postanki, hitrost ~30 km/h', async () => {
    const r = await parseGpx(new Blob([gpxWithStop()]), 'kava.gpx')
    expect(r.durationMin).toBe(60)
    expect(r.elapsedMin).toBe(120)
    const a = toActivity(r, 'file', null)
    expect(a.elapsedMin).toBe(120)
    expect(a.speedKmh!).toBeGreaterThan(28)
  })
  it('TCX: postanek po razdalji (DistanceMeters ostane enaka)', async () => {
    const r = await parseTcx(new Blob([tcx({ stop: true })]), 'stop.tcx')
    expect(r.durationMin).toBe(30)
    expect(r.elapsedMin).toBe(60)
  })
  it('brez razdalje med točkami (trenažer, moč) ali pod 0,5 km velja ves čas', () => {
    expect(movingMinOf([{ dt: 600, dm: null }, { dt: 600, dm: null }])).toBeNull()
    expect(movingMinOf([{ dt: 600, dm: 100 }])).toBeNull()
    expect(movingMinOf([{ dt: 600, dm: 5000 }, { dt: 3600, dm: 2 }])).toBe(10)
  })
  it('kontrola: vožnja brez postanka ostane, kot je (brez elapsedMin)', async () => {
    const r = await parseTcx(new Blob([tcx()]), 'brez.tcx')
    expect(r.durationMin).toBe(60)
    expect(r.elapsedMin).toBeUndefined()
  })
})

describe('F07 + F21 vati in kalorije iz datoteke', () => {
  it('TCX ns3:Watts → povprečna moč z merilnika; Lap Calories → kcal', async () => {
    const r = await parseTcx(new Blob([tcx({ watts: 210, kcal: [420, 400] })]), 'zwift.tcx')
    expect(r.avgPower).toBe(210)
    expect(r.deviceWatts).toBe(true)
    expect(r.kcal).toBe(820)
    expect(toActivity(r, 'file', null).deviceWatts).toBe(true)
  })
  it('GPX <power> → povprečna moč (le na polovici točk ali več)', async () => {
    const r = await parseGpx(new Blob([gpxWithStop('<extensions><power>230</power></extensions>')]), 'moc.gpx')
    // 361 od 721 točk ima vate (postanek brez) — dovolj za povprečje
    expect(r.avgPower).toBe(230)
    const none = await parseGpx(new Blob([gpxWithStop()]), 'brez.gpx')
    expect(none.avgPower).toBeNull()
  })
})

describe('F08 šport iz ure', () => {
  it('smučanje, tek na smučeh, rolanje, kajak, nogomet → drugo (ne kolo/tek/hoja)', () => {
    expect(guessSport(40, 'alpine_skiing', 30)).toBe('drugo')
    expect(guessSport(12, 'cross_country_skiing', 15)).toBe('drugo')
    expect(guessSport(20, 'inline_skating', 15)).toBe('drugo')
    expect(guessSport(7, 'paddling kayaking', 8)).toBe('drugo')
    expect(guessSport(6, 'soccer', 8)).toBe('drugo')
    expect(guessSport(10, 'NordicSki', 10)).toBe('drugo')
  })
  it('kontrola: brez vrste odloča hitrost; kolo, tek, hoja ostanejo', () => {
    expect(guessSport(25, null, 30)).toBe('kolo')
    expect(guessSport(25, 'cycling', 30)).toBe('kolo')
    expect(guessSport(10, 'running', 10)).toBe('tek')
    expect(guessSport(5, 'hiking', 10)).toBe('pohod')
  })
})

describe('F20 Stravin arhiv: imena iz activities.csv', () => {
  it('CSV z narekovaji in vejicami v imenu', () => {
    expect(csvRows('a,"b, c","d ""x"""\n1,2,3')).toEqual([['a', 'b, c', 'd "x"'], ['1', '2', '3']])
    const m = stravaNames('Activity ID,Activity Date,Activity Name,Activity Type,Activity Description,Filename\n1,"Oct 1, 2026","Jutranja na Vršič",Ride,"opis\nv dveh vrsticah",activities/1.gpx\n2,x,Tek ob Savi,Run,,activities/2.FIT.gz')
    expect(m.get('1.gpx')).toBe('Jutranja na Vršič')
    expect(m.get('2.fit.gz')).toBe('Tek ob Savi')
  })
  it('parseArchive: ime iz CSV namesto »Kolo 30 km«, izvor Strava', async () => {
    const zip = new JSZip()
    zip.file('activities.csv', 'Activity ID,Activity Name,Filename\n1,Jutranja na Vršič,activities/1.gpx\n')
    zip.file('activities/1.gpx', gpxWithStop().replace('<name>Kava v Kranju</name>', ''))
    const buf = await zip.generateAsync({ type: 'arraybuffer' })
    const r = await parseArchive(new File([buf], 'export.zip'))
    expect(r.strava).toBe(true)
    expect(r.parsed[0]!.name).toBe('Jutranja na Vršič')
    expect(r.parsed[0]!.originHint).toBe('STRAVA')
  })
})

describe('F22 ročni vnos: hitrost po športu', () => {
  it('300 km v 60 min (kolo) in maraton v 30 min (tek) → napaka pri razdalji', () => {
    expect(manualActivityErrors({ min: '60', dist: '300' }, 'kolo').dist).toBe('Razdalja ne gre s tem časom (300 km/h) — preveri km ali minute.')
    expect(manualActivityErrors({ min: '30', dist: '42' }, 'tek').dist).toMatch(/84 km\/h/)
  })
  it('kontrola: 30 km v 60 min je v redu; brez športa ni preverbe hitrosti', () => {
    expect(manualActivityErrors({ min: '60', dist: '30' }, 'kolo')).toEqual({})
    expect(manualActivityErrors({ min: '60', dist: '300' })).toEqual({})
  })
})

describe('F23 vaje ročnega vnosa', () => {
  it('9 999 kg in 12 serij → sporočilo; prazna vrstica in pravilne vrednosti ne', () => {
    expect(exerciseErrors([{ name: 'Počep', sets: '12', kg: '9999' }])).toEqual(['Serije: od 1 do 10.', 'Kilogrami: od 0 do 400.'])
    expect(exerciseErrors([{ name: '', sets: '99', kg: '9999' }, { name: 'Počep', sets: '4', kg: '80' }])).toEqual([])
  })
})

describe('F05 ponujen dan brez vadbe', () => {
  it('začetnik, tek, tor + čet + ned → prost dan s časom je poimenovan; »Zakaj tako« loči prost dan od dni brez časa', () => {
    // 2 teka, čas tor, čet, ned (prosti: pon, sre, pet, sob)
    const f = normalizeFocus({ wish: 'Rad delam: tek.', level: 1, offDays: [0, 2, 4, 5], sessions: [{ type: 'tek', cardio: 'lahko', min: 30 }, { type: 'tek', cardio: 'lahko', min: 30 }], aims: ['hujsanje'] }, { by: 'pravila' })!
    const rev = coachReview(f, { age: 35, asIs: true })
    expect(trainingDays(rev.focus.sessions)).toBe(2)
    const free = freeOpenDays(rev.focus)
    expect(free).toHaveLength(1)
    expect([1, 3, 6]).toContain(free[0])
    const rest = rev.why.find(l => /počitka na teden/.test(l))!
    expect(rest).toMatch(/^5 dni počitka na teden: ob \S+ prosto za obnovo, ob ponedeljkih, sredah, petkih in sobotah nimaš časa/)
  })
  it('pravila za začetnika s 3 dnevi: ponujen dan brez vadbe je med prostimi dnevi', () => {
    const prop = ruleProposal('Kaj želim: Manj kilogramov. Rad delam: Tek. Izkušnje: Začenjam.', [], 35, { avail: [1, 3, 6], today: '2026-10-23' })
    const rev = coachReview(prop.focus, { age: 35, levelHint: 1 })
    expect(freeOpenDays(rev.focus)).toHaveLength(3 - trainingDays(rev.focus.sessions))
  })
  it('kontrola: vsi dnevi s časom imajo vadbo → ni prostih dni', () => {
    const f = normalizeFocus({ wish: 'Rad delam: tek.', offDays: [0, 1, 2, 3, 5], sessions: [{ type: 'tek', cardio: 'lahko', min: 30 }, { type: 'tek', cardio: 'lahko', min: 30 }], aims: ['kondicija'] }, { by: 'pravila' })!
    expect(freeOpenDays(f)).toEqual([])
  })
})

describe('F04 en dan na teden', () => {
  it('pravila: ena vadba v nedeljo', () => {
    const prop = ruleProposal('Kaj želim: Boljša kondicija. Rad delam: Tek.', [], 35, { avail: [6], today: '2026-10-23' })
    expect(trainingDays(prop.focus.sessions)).toBe(1)
    expect(prop.focus.offDays).toEqual([0, 1, 2, 3, 4, 5])
  })
})

