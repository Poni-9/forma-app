import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { easyFeltHard } from '../src/domain/coach/rpe'
import { readState, painStreak } from '../src/domain/training/state'
import { estimateTss, todayIso, addDays } from '../src/domain/training/load'
import { lastWeekSummary } from '../src/domain/coach/local'
import { yesterdayToRate } from '../src/ui/YesterdayRate'
import { movedMissed } from '../src/ui/MovedCard'
import type { Activity, DailyCheckin, PlanDay } from '../src/domain/types'

const NOW = '2026-10-03T08:00:00.000Z'
const T = '2026-10-08'   // četrtek
const day = (id: string, date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id, date, kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, zone: 'Z2', tssTarget: 45, role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })
const act = (id: string, date: string, o: Partial<Activity> = {}): Activity => ({ id, source: 'manual', sport: 'kolo', date, name: 'Vožnja', durationMin: 60, aiEligible: true, geoRetain: true, createdAt: NOW, updatedAt: NOW, ...o })
const ck = (o: Partial<DailyCheckin>, date: string): DailyCheckin => ({ date, ...o })

describe('občutek vpliva na načrt', () => {
  it('dva lahka treninga »težko« v zadnjih 4 dneh štejeta; ključni »težko« ne', () => {
    const plan = [day('a', '2026-10-06', { done: { at: NOW, activityId: 'x1' } }), day('b', '2026-10-07', { done: { at: NOW, activityId: null }, rpe: 10 }), day('k', '2026-10-05', { role: 'kljucna', zone: 'Z4', done: { at: NOW, activityId: 'x2' } })]
    const acts = [act('x1', '2026-10-06', { rpe: 8 }), act('x2', '2026-10-05', { rpe: 10 })]
    expect(easyFeltHard(acts, plan, T)).toBe(2)
    expect(easyFeltHard(acts, plan, '2026-10-11')).toBe(1)          // okno 4 dni (7.–10.)
    expect(easyFeltHard(acts, plan, '2026-10-12')).toBe(0)
  })
  it('dobro jutro + dva lahka težka → stopnja 1 (nasvet); slabo jutro → stopnja višje', () => {
    const good = readState({ checkin: ck({ mood: 4, soreness: 1 }, T), easyHard: 2 })
    expect(good.level).toBe(1); expect(good.reasons.join(' ')).toMatch(/lahki treningi so bili težki \(2×\)/)
    expect(readState({ checkin: ck({ mood: 2 }, T), easyHard: 2 }).level).toBe(2)
    expect(readState({ checkin: null, easyHard: 3 }).level).toBe(0)                      // brez vnosa nič samodejnega
    expect(readState({ checkin: ck({ mood: 4 }, T), easyHard: 1 }).level).toBe(0)
  })
  it('bolečina 3 jutra zapored', () => {
    const c = [ck({ soreness: 5 }, '2026-10-06'), ck({ soreness: 5 }, '2026-10-07'), ck({ soreness: 5 }, T)]
    expect(painStreak(c, T)).toBe(3)
    expect(painStreak([...c.slice(0, 1), ck({ soreness: 4 }, '2026-10-07'), c[2]!], T)).toBe(1)
    expect(painStreak(c.slice(1), T)).toBe(2)
  })
})

describe('obremenitev iz občutka (brez ure)', () => {
  it('RPE nadomesti povprečje za šport, moč in utrip imata prednost', () => {
    const p = { ftp: 250, lthr: 165 } as never
    expect(estimateTss({ sport: 'moc', durationMin: 60 }, p)).toBe(70)
    expect(estimateTss({ sport: 'moc', durationMin: 60, rpe: 8 }, p)).toBe(77)
    expect(estimateTss({ sport: 'kolo', durationMin: 60, rpe: 4 }, p)).toBe(41)
    expect(estimateTss({ sport: 'kolo', durationMin: 60, avgPower: 200, rpe: 10 }, p)).toBe(71)   // moč šteje
  })
})

describe('Danes: včerajšnja ocena, prestavljeni, pretekli teden', () => {
  it('včerajšnja vadba brez ocene: najdaljša; ocenjena ali dan brez vadbe z oceno → nič', () => {
    const y = addDays(T, -1)
    const plan = [day('d1', y, { done: { at: NOW, activityId: 'a1' } })]
    expect(yesterdayToRate({ today: T, plan, activities: [act('a1', y, { name: 'Jutranja', durationMin: 90 }), act('a2', y, { durationMin: 20 })] })).toEqual({ title: 'Jutranja', activityId: 'a1', dayId: 'd1' })
    expect(yesterdayToRate({ today: T, plan, activities: [act('a1', y, { rpe: 6 })] })).toBeNull()
    expect(yesterdayToRate({ today: T, plan: [day('d2', y, { title: 'Moč', kind: 'moc', done: { at: NOW, activityId: null } })], activities: [] })).toEqual({ title: 'Moč', activityId: null, dayId: 'd2' })
    expect(yesterdayToRate({ today: T, plan: [], activities: [act('s', y, { durationMin: 10 })] })).toBeNull()   // pod 15 min ne sprašuje
  })
  it('prestavljeni zamujeni ključni tega tedna je viden, dokler ni opravljen', () => {
    const src = day('tue', '2026-10-06', { title: 'VO2max', role: 'kljucna', missed: 'moved' })
    const to = day('fri', '2026-10-09', { title: 'VO2max', role: 'kljucna', adapt: { after: '2026-10-06', prev: { kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, zone: 'Z2', tssTarget: 45, role: 'lahka', target: null, kcalBurn: null, why: null, optional: false } } })
    expect(movedMissed([src, to], T).map(x => x.to.id)).toEqual(['fri'])
    expect(movedMissed([src, { ...to, done: { at: NOW, activityId: null } }], T)).toEqual([])
    expect(movedMissed([src, to], '2026-10-12')).toEqual([])       // nov teden
  })
  it('pretekli teden: seje, ure, ključni, občutek', () => {
    const plan = [day('p1', '2026-09-29', { done: { at: NOW, activityId: 'r1' } }), day('p2', '2026-10-01', { role: 'kljucna', zone: 'Z4', title: 'Prag' }), day('p3', '2026-10-03', { done: { at: NOW, activityId: null }, rpe: 6, kind: 'moc', role: 'moc', title: 'Moč' }), day('p4', '2026-10-04', { kind: 'pocitek', title: 'Počitek', role: null })]
    const s = lastWeekSummary(plan, [act('r1', '2026-09-29', { durationMin: 75, rpe: 4 })], '2026-10-05')!
    expect(s.from).toBe('2026-09-28')
    expect(s.lines[0]).toMatch(/^2 od 3 sej · na kolesu 1 h 15 min od 2 h/)
    expect(s.lines[1]).toMatch(/Ključni in dolgi: 0 od 1 po načrtu \(Prag: ni bilo\)/)
    expect(s.lines[2]).toMatch(/Občutek povprečno »(lahko|srednje)« \(2 ocen\)/)
    expect(lastWeekSummary([], [], '2026-10-05')).toBeNull()
  })
})

describe('ocena ročne vadbe posodobi obremenitev', () => {
  beforeEach(async () => { await repo.wipeAll(); localStorage.clear(); await store.reloadAll() })
  it('ročni vnos brez utripa: TSS iz občutka; uvoz z utripom ostane', async () => {
    const t = todayIso()
    await store.addActivities([act('m1', t, { sport: 'moc', name: 'Moč', durationMin: 60, tss: 70 }), act('i1', t, { source: 'intervals', avgHr: 140, tss: 55, name: 'Z ure', start: t + 'T06:00:00.000Z', ext: { intervalsId: 'i1' } })])
    await store.rateSession({ activityId: 'm1' }, 8)
    await store.rateSession({ activityId: 'i1' }, 10)
    const by = new Map(store.getState().activities.map(a => [a.id, a]))
    expect(by.get('m1')).toMatchObject({ rpe: 8, tss: 77 })
    expect(by.get('i1')).toMatchObject({ rpe: 10, tss: 55 })
  })
})
