// v3.50 RECEPTI — kroženje jedi (E01, E02), »ne maram X« po živilu (E04, E19, E18), vegan brez medu (E16), »ne maram banan«
// (E17), »drug predlog« velja povsod (E05), OH na dan brez vadbe (E07, E08), realne porcije (E09–E13, E28, E33), mere (E14,
// E30), recept za več oseb (E15), nakupovalni seznam (E26, E27), slovnica (E29, E36), vegan beljakovine (E31, E32).
import 'fake-indexeddb/auto'
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, afterEach, beforeEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
const H = vi.hoisted(() => ({ json: {} as unknown, prompts: [] as string[] }))
vi.mock('../src/domain/ai/client', () => {
  class AiError extends Error { kind: string; constructor(kind: string, m: string) { super(m); this.kind = kind } }
  return { AiError, askText: async () => '', askJson: async (parts: { text?: string }[]) => { H.prompts.push(parts.map(p => p.text || '').join('\n')); return JSON.parse(JSON.stringify(H.json)) } }
})
const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'prehrana', params: {} as Record<string, string> }, alts: [] as any[] }))
vi.mock('@/state/store', async (orig) => ({
  ...(await orig<typeof import('../src/state/store')>()),
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  addMeal: async () => undefined,
  // »drug predlog« se shrani v nastavitve (kot v shrambi) — zaslon se znova izriše
  setRecipeAlt: async (date: string, alt: Record<string, number>) => {
    S.alts.push([date, alt])
    S.state = { ...S.state, settings: { ...S.state.settings, recipeAlt: { ...(S.state.settings.recipeAlt || {}), [date]: alt } } }
    S.subs.forEach(f => f())
  },
}))
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => S.route, subscribeRoute: () => () => undefined }))

import * as repo from '../src/data/repo'
import { Prehrana } from '@/screens/Prehrana'
import { DISHES, LF_DISHES, dayRecipes, dishesFor, exclusionsOf, recipeOkFor, fitDish, bestFits, whyRecipe, scaleText, scaleIngredients, shoppingList, shoppingGroups, plateG, foodPrefsFromWish, SMALL_MAIN_KCAL, type Recipe } from '../src/domain/nutrition/recipes'
import { F, dayMealPlan, measureOf, qtyText } from '../src/domain/nutrition/dayplan'
import { dayMealsOf, recipeCtxOf, recipesOf, recipesAhead } from '../src/domain/nutrition/daymeals'
import { dailyTarget } from '../src/domain/nutrition/energy'
import { FRANJA_2027 } from '../src/domain/training/planner'
import { dayRecipesAi, type Snapshot } from '../src/domain/ai/actions'
import type { PlanDay, Profile } from '../src/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const NOW = '2026-10-01T08:00:00.000Z'
const TODAY = '2026-10-19'
const P = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, restHr: 55, maxHr: 200, lthr: 184, ftp: 240, ftpDate: '2026-09-20',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, hoursPerWeek: 14, baseHours: null,
  strength: { on: false, equipment: 'home', phases: null }, strengthDays: 0, goal: 'dirka', deficit: 400, neat: 1.4,
  event: null, cycleStart: '2026-09-21', onboardingDone: true, trainTime: 'popoldne', createdAt: NOW, updatedAt: NOW,
  races: [], ...o,
} as Profile)
const day = (date: string, kind: PlanDay['kind'], min: number, o: Partial<PlanDay> = {}): PlanDay => ({ id: `${kind}${date}`, date, kind, title: kind === 'pocitek' ? 'Počitek' : 'Vožnja', desc: '', durationMin: min, zone: 'Z2', role: kind === 'pocitek' ? 'pocitek' : 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, ...o } as PlanDay)
const addD = (s: string, n: number) => new Date(Date.parse(s + 'T12:00:00Z') + n * 864e5).toISOString().slice(0, 10)
// teden kot v reviziji: počitek, lahka, ključna, počitek, lahka, dolga, lahka (popoldne)
const weekDay = (i: number, d: string): PlanDay => [day(d, 'pocitek', 0), day(d, 'kolo', 60), day(d, 'kolo', 75, { role: 'kljucna', zone: 'Z4' }), day(d, 'pocitek', 0), day(d, 'kolo', 60), day(d, 'kolo', 180, { role: 'dolga' }), day(d, 'kolo', 90)][i % 7]!
const restDay = (_i: number, d: string) => day(d, 'pocitek', 0)
const altDay = (i: number, d: string) => (i % 2 ? day(d, 'kolo', 120) : day(d, 'pocitek', 0))
function dayOf(p: Profile, plan: PlanDay[], d: string, prefs = '', settings0: Record<string, unknown> = {}) {
  const t = dailyTarget(p, [], plan, d, { today: d, hour: 9 })!
  const settings = { foodPrefs: prefs, dayMenus: null, ...settings0 }
  const dm = dayMealsOf({ p, target: t, plan, activities: [], meals: [], recentMeals: [], weather: null, day: d, today: d })
  return { t, dp: dm.dp, training: dm.training, r: recipesOf(dm.dp, d, recipeCtxOf(p, t, settings, dm.training), settings) }
}
/** 14 dni: po obroku (ključ) zaporedje jedi in recepti po dnevih */
function twoWeeks(prefs: string, pat: (i: number, d: string) => PlanDay = weekDay, p = P()) {
  const bySlot: Record<string, string[]> = {}
  const days: { dp: ReturnType<typeof dayOf>['dp']; r: Record<string, Recipe> }[] = []
  for (let i = 0; i < 14; i++) {
    const d = addD(TODAY, i)
    const { dp, r } = dayOf(p, [pat(i, d)], d, prefs)
    days.push({ dp, r })
    for (const s of dp.slots) if (r[s.key]) (bySlot[s.key] ||= []).push(r[s.key]!.dish)
  }
  return { bySlot, days, all: days.flatMap(x => Object.values(x.r)) }
}
const maxRepeat = (bySlot: Record<string, string[]>) => Math.max(...Object.values(bySlot).map(v => Math.max(...Object.values(v.reduce<Record<string, number>>((c, n) => ({ ...c, [n]: (c[n] || 0) + 1 }), {})))))
const inRow = (bySlot: Record<string, string[]>) => Object.values(bySlot).reduce((a, v) => a + v.filter((x, i) => i > 0 && x === v[i - 1]).length, 0)
const dish = (id: string) => [...DISHES, ...LF_DISHES].find(d => d.id === id)!
const qty = (r: Pick<Recipe, 'ingredients'>, key: string) => r.ingredients.filter(i => i.key === key && !i.side).reduce((a, i) => a + i.qty, 0)

/* ---------- E01, E02: kroženje ---------- */

describe('E01, E02 — kroženje jedi se ne zatika (14 dni)', () => {
  it('vsejedec: nobena jed več kot 4× v istem obroku v 14 dneh (prej polenta 6 od 13 zajtrkov)', () => {
    for (const pat of [weekDay, altDay, restDay]) {
      const { bySlot } = twoWeeks('', pat)
      expect(maxRepeat(bySlot), JSON.stringify(bySlot)).toBeLessThanOrEqual(4)
    }
  })
  it('ista jed dan za dnem v istem obroku: 7 profilov × 3 tedni skupaj največ 100-krat (prej 174), vsejedec ob tednu z enakimi dnevi največ 1-krat', () => {
    let n = 0
    for (const prefs of ['', 'vegan', 'vegetarijansko', 'brez laktoze', 'ne maram skute', 'ne maram piščanca', 'ne maram banan'])
      for (const pat of [weekDay, altDay, restDay]) n += inRow(twoWeeks(prefs, pat).bySlot)
    expect(n).toBeLessThanOrEqual(100)
    expect(inRow(twoWeeks('', restDay).bySlot)).toBeLessThanOrEqual(1)
  })
  it('vegan: nobena jed več kot 7× v istem obroku (prej 9×); kosilo ima vsaj 3 različne jedi', () => {
    for (const pat of [weekDay, altDay, restDay]) {
      const { bySlot } = twoWeeks('vegan', pat)
      expect(maxRepeat(bySlot), JSON.stringify(bySlot)).toBeLessThanOrEqual(7)
      expect(new Set(bySlot.kosilo).size, JSON.stringify(bySlot.kosilo)).toBeGreaterThanOrEqual(3)
    }
    // tri veganska kosila brez tofuja in stročnic (sojini koščki)
    expect(dishesFor('kosilo', 'vegan').length).toBeGreaterThanOrEqual(9)
    expect(dishesFor('kosilo', 'vegan').filter(d => !d.items.some(([k]) => k === 'tofu' || k === 'fizol' || k === 'leca')).map(d => d.id)).toEqual(['bolonjska-soj', 'golaz-soj', 'ajda-sojkos'])
  })
  it('vegetarijanec, brez laktoze, »ne maram piščanca«: največ 5× ista jed v obroku', () => {
    for (const prefs of ['vegetarijansko', 'brez laktoze', 'ne maram piščanca']) expect(maxRepeat(twoWeeks(prefs).bySlot), prefs).toBeLessThanOrEqual(5)
  })
  it('isti dan dvakrat zapored da isto (kroženje je stalno, ne naključno); »drug predlog« zamenja samo ta obrok', () => {
    const { dp } = dayOf(P(), [day(TODAY, 'pocitek', 0)], TODAY)
    const ctx = { deficit: true, keepMuscle: false, training: false }
    const a = dayRecipes(dp, TODAY, ctx), b = dayRecipes({ ...dp, slots: dp.slots.map(s => ({ ...s })) }, TODAY, ctx)
    expect(Object.values(b).map(r => r.dish)).toEqual(Object.values(a).map(r => r.dish))
    const c = dayRecipes(dp, TODAY, { ...ctx, alt: { kosilo: 1 } })
    expect(c.kosilo!.dish).not.toBe(a.kosilo!.dish)
    for (const k of Object.keys(a).filter(k => k !== 'kosilo')) expect(c[k]!.dish, k).toBe(a[k]!.dish)
  })
})

/* ---------- E04, E19, E18: želje po živilu ---------- */

describe('E04 — »ne maram X« izloči živilo, ne cele skupine', () => {
  it('»ne maram skute«: jogurt, kefir, mleko in sir ostanejo, skuta ne', () => {
    const z = dishesFor('zajtrk', 'ne maram skute').map(d => d.id)
    expect(z).toEqual(expect.arrayContaining(['jogurt-z', 'kasa', 'polenta-z']))
    expect(z).not.toContain('skuta-z')
    expect(exclusionsOf('ne maram skute').contains).toEqual([])
    // 14 dni: mlečne jedi so, skute ni nikjer (tudi ne kot dodatek)
    const { all } = twoWeeks('ne maram skute')
    expect(all.some(r => r.ingredients.some(i => i.key === 'jogurt'))).toBe(true)
    expect(all.some(r => r.ingredients.some(i => i.key === 'skuta'))).toBe(false)
    expect(all.some(r => /tofu/i.test(r.name))).toBe(false)   // prej: »ne maram skute« = brez mleka → tofu
  })
  it('»ne maram piščanca«: golaž, bolonjska in puran ostanejo; »ne maram tune«: losos in oslič ostaneta', () => {
    const k = dishesFor('kosilo', 'ne maram piščanca').map(d => d.id)
    expect(k).toEqual(expect.arrayContaining(['golaz', 'bolonjska', 'puran-kr', 'oslic-kr']))
    expect(k).not.toContain('pisc-riz')
    expect(k).not.toContain('ajda-pisc')
    const t = dishesFor('kosilo', 'ne maram tune').map(d => d.id)
    expect(t).toEqual(expect.arrayContaining(['losos-kr', 'oslic-kr']))
    expect(t).not.toContain('test-tuna')
    const { all } = twoWeeks('ne maram piščanca')
    expect(all.some(r => r.ingredients.some(i => i.key === 'piscanec'))).toBe(false)
  })
  it('skupina še vedno velja za besedo skupine: »brez mleka«, »ne jem rib«, »alergija na oreške«', () => {
    expect(exclusionsOf('brez mleka').contains).toContain('mleko')
    expect(exclusionsOf('ne jem rib').contains).toContain('riba')
    expect(exclusionsOf('alergija na oreške').contains).toContain('oreski')
    expect(dishesFor('zajtrk', 'brez mleka').some(d => d.contains.includes('mleko'))).toBe(false)
  })
  it('dodatek za beljakovine ne predlaga skute tistemu, ki je ne mara', () => {
    const w = whyRecipe({ p: 10, c: 40, f: 5 }, { key: 'malica', proteinG: 26 }, { deficit: false, keepMuscle: false, training: false, prefs: 'ne maram skute' })
    expect(w).toMatch(/dodaj jogurt\)/)
    expect(w).not.toMatch(/skut/)
  })
})

describe('E19 — rdeče meso, pescetarijanec, »nič mlečnega«, »nič mesa«', () => {
  it('»ne jem rdečega mesa« izloči golaž in bolonjsko, piščanec in puran ostaneta', () => {
    const ex = exclusionsOf('ne jem rdečega mesa')
    expect(ex.contains).not.toContain('meso')
    const k = dishesFor('kosilo', 'ne jem rdečega mesa').map(d => d.id)
    expect(k).toEqual(expect.arrayContaining(['pisc-riz', 'puran-kr', 'ajda-pisc']))
    expect(k).not.toContain('golaz')
    expect(k).not.toContain('bolonjska')
  })
  it('pescetarijanec: brez mesa, ribe ostanejo; »nič mlečnega«, »nič mesa« izločita', () => {
    expect(exclusionsOf('pescetarijanec').contains).toEqual(['meso'])
    expect(dishesFor('kosilo', 'pescetarijanec').map(d => d.id)).toEqual(expect.arrayContaining(['oslic-kr', 'test-tuna', 'losos-kr']))
    expect(dishesFor('kosilo', 'pescetarijanec').some(d => d.contains.includes('meso'))).toBe(false)
    expect(exclusionsOf('nič mlečnega').contains).toContain('mleko')
    expect(exclusionsOf('nič mesa').contains).toContain('meso')
    expect(exclusionsOf('perutnine ne jem').contains).not.toContain('meso')
    expect(dishesFor('kosilo', 'ne jem perutnine').map(d => d.id)).toEqual(expect.arrayContaining(['golaz', 'bolonjska']))
    expect(dishesFor('kosilo', 'ne jem perutnine').map(d => d.id)).not.toContain('pisc-riz')
  })
})

describe('E18 — AI recept: tunina, kurji file, jajčevec', () => {
  const ok = (prefs: string, ...ing: string[]) => recipeOkFor({ name: 'Obrok', ingredients: ing.map(text => ({ key: 'ai0', qty: 0, text })) }, prefs)
  it('tunina in kurji file ne gresta mimo, jajčevec ni jajce', () => {
    expect(ok('ne maram rib', 'tunina 120 g')).toBe(false)
    expect(ok('ne jem rib', 'solata s tunino')).toBe(false)
    expect(ok('vegetarijanec', 'kurji file 150 g')).toBe(false)
    expect(ok('vegetarijanec', 'kurja bedra 200 g')).toBe(false)
    expect(ok('brez jajc', 'jajčevec 200 g')).toBe(true)
    expect(ok('brez jajc', '2 jajci')).toBe(false)
    // »ne maram tune« (beseda): tunina izpade, losos ostane
    expect(ok('ne maram tune', 'tunina 100 g')).toBe(false)
    expect(ok('ne maram tune', 'losos 150 g')).toBe(true)
  })
})

/* ---------- E16, E17 ---------- */

describe('E16 — vegan brez medu', () => {
  it('jedi z medom dobijo marmelado (ime in koraki), AI recept z medom izpade', () => {
    for (const tpl of ['zajtrk', 'pred', 'malica']) for (const d of dishesFor(tpl, 'vegan')) {
      const r = fitDish(d, 400, 15, { deficit: false, prefs: 'vegan' })
      expect(r.ingredients.some(i => i.key === 'med'), `${d.id}`).toBe(false)
      expect(`${r.name} ${r.steps.join(' ')}`, d.id).not.toMatch(/(?<!\p{L})med(?:om|u)?(?!\p{L})/u)
    }
    expect(fitDish(dish('kruh-med'), 300, 8, { deficit: false, prefs: 'vegan' }).name).toBe('Kruh z marmelado in banano')
    expect(fitDish(dish('kruh-med'), 300, 8, { deficit: false }).name).toBe('Kruh z medom in banano')
    const ai = (name: string, ...ing: string[]) => recipeOkFor({ name, ingredients: ing.map(text => ({ key: 'ai0', qty: 0, text })) }, 'vegan')
    expect(ai('Kaša z medom', 'ovseni kosmiči 60 g')).toBe(false)
    expect(ai('Kaša', 'med 15 g')).toBe(false)
    expect(ai('Kaša', 'sojin napitek 300 ml', '1 žlička medu')).toBe(false)
    expect(ai('Kaša', 'sojin napitek 300 ml', 'javorjev sirup 10 g')).toBe(true)
  })
  it('poziv za AI recepte veganu pove »brez medu«; »ne maram piščanca« pove piščanca, ne vsega mesa', async () => {
    const profile = { ...P(), aiConsentAt: '2026-10-15T08:00:00.000Z', aiConsentV: 2 } as Profile
    const s: Snapshot = { profile, activities: [], plan: [], today: TODAY, extra: '' }
    H.json = { obroki: [] }
    const slots = [{ key: 'zajtrk', label: 'Zajtrk', when: 'zjutraj', kcal: 600, proteinG: 40, carbsG: 70 }]
    await dayRecipesAi(s, slots, 'vegan', null, { deficit: false, keepMuscle: false })
    expect(H.prompts[H.prompts.length - 1]).toMatch(/Brez [^.]*medu/)
    await dayRecipesAi(s, slots, 'ne maram piščanca', null, { deficit: false, keepMuscle: false })
    expect(H.prompts[H.prompts.length - 1]).toMatch(/Brez piščanca\./)
  })
})

describe('E17 — »ne maram banan« velja tudi, ko za obrok ni jedi brez banane', () => {
  it('vegan + »ne maram banan«: pred vožnjo jabolko in sok, nikjer banane (tudi v nakupu)', () => {
    expect(dishesFor('pred', 'vegan, ne maram banan').map(d => d.id)).toEqual(['sok-pred'])
    const plan = [0, 1, 2, 3, 4, 5, 6].map(i => weekDay(i, addD(TODAY, i)))
    const p = P()
    const ahead = recipesAhead({ p, plan, activities: [], meals: [], recentMeals: [], weather: null, today: TODAY, settings: { foodPrefs: 'vegan, ne maram banan' }, days: 7, targetOf: d => dailyTarget(p, [], plan.filter(x => x.date === d), d, { today: TODAY, hour: 9 }) })
    const rs = ahead.flatMap(a => a.recipes)
    expect(rs.length).toBeGreaterThan(20)
    expect(rs.some(r => r.ingredients.some(i => i.key === 'banana'))).toBe(false)
    expect(shoppingList(rs, 'vegan, ne maram banan').some(l => /banan/.test(l))).toBe(false)
  })
  it('ko je jed z banano edina, banano zamenja jabolko: ime »(brez banane)« in korak', () => {
    const r = fitDish(dish('sadje-pred'), 200, 3, { deficit: false, prefs: 'ne maram banan' })
    expect(r.ingredients.some(i => i.key === 'banana')).toBe(false)
    expect(r.ingredients.find(i => i.key === 'jabolko')!.qty).toBe(2)
    expect(r.name).toBe('Banana in jabolko (brez banane)')
    expect(r.steps[0]).toBe('Namesto banane vzemi jabolko.')
    // »besede popustijo«: samo jedi, kjer se da zamenjati (prej vse jedi obroka)
    const left = dishesFor('pred', 'ne maram banan, kruha, kosmičev, jogurta, soka')
    expect(left.length).toBeGreaterThan(0)
    expect(left.every(d => d.items.every(([k]) => k !== 'kruh' && k !== 'oves'))).toBe(true)
  })
})

/* ---------- E05: drug predlog ---------- */

describe('E05 — »drug predlog« se shrani za dan in velja povsod', () => {
  it('recipesOf z recipeAlt v nastavitvah = ista jed kot z alt v kontekstu (Danes ga ne poda)', () => {
    const p = P(), plan = [day(TODAY, 'pocitek', 0)]
    const base = dayOf(p, plan, TODAY)
    const withCtx = recipesOf(base.dp, TODAY, recipeCtxOf(p, base.t, { foodPrefs: '' }, base.training, { kosilo: 1 }), { dayMenus: null })
    const danes = dayOf(p, plan, TODAY, '', { recipeAlt: { [TODAY]: { kosilo: 1 } } })
    expect(withCtx.kosilo!.dish).not.toBe(base.r.kosilo!.dish)
    expect(danes.r.kosilo!.dish).toBe(withCtx.kosilo!.dish)
    // drug dan ni prizadet; nakupovalni seznam (recipesAhead) bere isto
    expect(dayOf(p, [day(addD(TODAY, 1), 'pocitek', 0)], addD(TODAY, 1), '', { recipeAlt: { [TODAY]: { kosilo: 1 } } }).r.kosilo!.dish).toBe(dayOf(p, [day(addD(TODAY, 1), 'pocitek', 0)], addD(TODAY, 1)).r.kosilo!.dish)
    const ahead = recipesAhead({ p, plan, activities: [], meals: [], recentMeals: [], weather: null, today: TODAY, settings: { foodPrefs: '', recipeAlt: { [TODAY]: { kosilo: 1 } } }, days: 1, targetOf: d => dailyTarget(p, [], plan.filter(x => x.date === d), d, { today: TODAY, hour: 9 }) })
    expect(ahead[0]!.recipes.map(r => r.dish)).toContain(withCtx.kosilo!.dish)
  })
})

/* ---------- E07, E08: OH ---------- */

describe('E07, E08 — ogljikovi hidrati na dan brez vadbe in pred tekmo', () => {
  it('dan brez vadbe: OH receptov največ 12 % nad ciljem dneva; nasvet ne našteva riža in testenin', () => {
    for (let i = 0; i < 7; i++) {
      const d = addD(TODAY, i)
      const { dp, r } = dayOf(P(), [day(d, 'pocitek', 0)], d)
      const c = Object.values(r).reduce((a, x) => a + x.c, 0), target = dp.slots.reduce((a, s) => a + s.carbsG, 0)
      expect(c, `${d}: ${Object.values(r).map(x => `${x.name} ${x.c}`).join(', ')}`).toBeLessThanOrEqual(target * 1.12)
      expect(dp.tip).not.toMatch(/testenin|riža/)
    }
  })
  it('»zakaj zate« ne reče »zato manj« ob 50 % preveč OH ali pred tekmo', () => {
    const ctx = { deficit: false, keepMuscle: false, training: false }
    const over = whyRecipe({ p: 30, c: 136, f: 9 }, { key: 'kosilo', proteinG: 32, carbsG: 90 }, ctx)
    expect(over).not.toMatch(/zato manj/)
    expect(over).toMatch(/136 g ogljikovih hidratov — več od cilja obroka \(90 g\)/)
    expect(whyRecipe({ p: 30, c: 92, f: 9 }, { key: 'kosilo', proteinG: 32, carbsG: 90 }, ctx)).toMatch(/dan brez vadbe, zato manj/)
    expect(whyRecipe({ p: 30, c: 148, f: 9 }, { key: 'kosilo', proteinG: 32, carbsG: 150, lf: true }, ctx)).toMatch(/148 g ogljikovih hidratov — polnjenje pred tekmo/)
    // dan pred Franjo: noben recept ne pravi »zato manj«
    const p = P({ event: { ...FRANJA_2027 } })
    const { r } = dayOf(p, [day('2027-06-12', 'pocitek', 0)], '2027-06-12')
    for (const x of Object.values(r)) expect(x.why, x.name).not.toMatch(/zato manj/)
  })
})

/* ---------- E09–E13, E28, E33: porcije ---------- */

describe('E09 — majhen glavni obrok ni skrčena jed', () => {
  it('kosilo ali večerja pod 300 kcal: majhen obrok (jogurt s sadjem, jajca s kruhom), ne »testenine 10 g«', () => {
    const dp = dayMealPlan({ weightKg: 58, trainTime: 'popoldne' }, { kcal: 1500, proteinG: 90, carbsG: 170 }, null)
    const small = { ...dp, slots: dp.slots.map(s => (s.key === 'vecerja' ? { ...s, kcal: 250, proteinG: 20, carbsG: 25 } : s)) }
    const r = dayRecipes(small, TODAY, { deficit: true, keepMuscle: false, training: false })
    expect(dish(r.vecerja!.dish).tpl).toBe('majhen')
    expect(SMALL_MAIN_KCAL).toBe(300)
    // od 300 kcal naprej: osnova jedi ne pod 40 g (suhe)
    for (const id of ['bolonjska', 'ricet', 'golaz', 'cicerika', 'pisc-riz']) {
      const f = fitDish(dish(id), 330, 30, { deficit: true })
      for (const k of ['testenine', 'jesprenj', 'polenta', 'riz']) if (f.ingredients.some(i => i.key === k)) expect(qty(f, k), `${id} ${k}`).toBeGreaterThanOrEqual(40)
    }
  })
})

describe('E10, E11 — realni krožniki in tofu', () => {
  it('kosilo 750 kcal: puran, oslič in krompir z jajci do 800 g (prej 935–985 g), krompir največ 350 g', () => {
    for (const id of ['puran-kr', 'oslic-kr', 'krompir-jajca', 'pec-pisc', 'losos-kr', 'tofu-zel']) {
      const r = fitDish(dish(id), 750, 45, { deficit: false })
      expect(plateG(r), `${id}: ${r.ingredients.map(i => i.text).join('; ')}`).toBeLessThanOrEqual(800)
      expect(qty(r, 'krompir')).toBeLessThanOrEqual(350)
    }
    expect(qty(fitDish(dish('oslic-kr'), 590, 44, { deficit: true }), 'krompir')).toBeLessThanOrEqual(350)
  })
  it('tofu največ zavitek (200 g)', () => {
    for (const id of ['tofu-z', 'tofu-zel', 'tofu-riz']) expect(qty(fitDish(dish(id), 750, 45, { deficit: false, prefs: 'vegan' }), 'tofu'), id).toBeLessThanOrEqual(200)
  })
})

describe('E12, E13 — brez drobiža po pomanjšanju; kosmiči niso juha', () => {
  it('curry z rižem pri 470 kcal: riž vsaj 40 g, čičerike največ 1,5 × osnove; oreški nikoli pod 10 g', () => {
    const c = fitDish(dish('cicerika'), 470, 23, { deficit: true })
    expect(qty(c, 'riz')).toBeGreaterThanOrEqual(40)
    expect(qty(c, 'fizol')).toBeLessThanOrEqual(250 * 1.5)
    for (const d of DISHES) for (const [kc, p] of [[258, 24], [400, 30], [600, 40]] as const) {
      const r = fitDish(d, kc, p, { deficit: false })
      const nuts = r.ingredients.find(i => i.key === 'oreski')
      if (nuts) expect(nuts.qty, `${d.id} ${kc}`).toBeGreaterThanOrEqual(10)
      const oats = r.ingredients.find(i => i.key === 'oves' && !i.side)
      if (oats) expect(oats.qty, `${d.id} ${kc}`).toBeGreaterThanOrEqual(20)
    }
  })
  it('kosmiči in kaša: napitek, mleko in jogurt največ 5 × kosmičev (prej 50 g v 550 g)', () => {
    for (const id of ['oves-noc', 'kasa-soj', 'sojjog-z', 'ajda-soj', 'jogurt-z', 'kasa'])
      for (const [kc, p] of [[540, 36], [720, 40], [400, 30]] as const) {
        const r = fitDish(dish(id), kc, p, { deficit: false, prefs: 'vegan' })
        const g = qty(r, 'oves') + qty(r, 'ajda'), l = qty(r, 'mleko') + qty(r, 'sojmleko') + qty(r, 'jogurt') + qty(r, 'sojjogurt')
        expect(l, `${id} ${kc}: ${r.ingredients.map(i => i.text).join('; ')}`).toBeLessThanOrEqual(g * 5)
      }
  })
})

describe('E28, E33 — pred dolgo vožnjo in po njej lahko', () => {
  it('zajtrk 1–2 h pred vožnjo: skute največ 150 g, oreškov 10 g', () => {
    const fits = bestFits(dishesFor('zajtrk'), { kcal: 600, proteinG: 36, carbsG: 80, beforeRide: true }, { deficit: false })
    for (const { fit } of fits) { expect(qty(fit, 'skuta'), fit.name).toBeLessThanOrEqual(150); expect(qty(fit, 'oreski'), fit.name).toBeLessThanOrEqual(10) }
  })
  it('po tekmi: obrok brez 300 g čičerike, z manj maščob (vsejedec in vegan)', () => {
    const p = P({ event: { ...FRANJA_2027 } })
    for (const prefs of ['', 'vegan', 'vegetarijansko']) {
      const { r } = dayOf(p, [day('2027-06-13', 'kolo', 330, { role: 'dirka' })], '2027-06-13', prefs)
      const ob = r.obnova!
      expect(ob, prefs).toBeTruthy()
      expect(qty(ob, 'fizol') + qty(ob, 'leca'), `${prefs}: ${ob.name}`).toBeLessThan(200)
      expect(ob.f, `${prefs}: ${ob.name}`).toBeLessThanOrEqual(25)
    }
  })
})

/* ---------- E14, E30: mere ---------- */

describe('E14, E30 — domače mere', () => {
  it('pol mere, kjer je pol; brez mere, kjer ni jasna', () => {
    expect(measureOf('kruh', 20)).toBe('½ rezine')
    expect(measureOf('kruh', 100)).toBe('2½ rezine')
    expect(measureOf('kruh', 80)).toBe('2 rezini')
    expect(measureOf('olje', 15)).toBe('1½ žlice')
    expect(measureOf('olje', 5)).toBe('½ žlice')
    expect(measureOf('sadje', 60)).toBeNull()
    expect(measureOf('sadje', 150)).toBe('1 kos')
    expect(measureOf('skuta', 160)).toBeNull()
    expect(measureOf('skuta', 250)).toBe('1 lonček')
  })
  it('lonček jogurta: v receptu »po 150 g«, v nakupu »velik lonček po 500 g«', () => {
    expect(qtyText('jogurt', 300)).toBe('grški jogurt 2 % 300 g (2 lončka po 150 g)')
    expect(shoppingList([{ ingredients: [{ key: 'jogurt', qty: 2200, text: '' }] }])).toEqual(['grški jogurt 2 %: 2,2 kg (5 velikih lončkov po 500 g)'])
  })
})

/* ---------- E15: recept za več oseb ---------- */

describe('E15 — AI recept za več oseb: ulomki in sklanjanje', () => {
  it('»1/2 čebule« ×3 = »1½ čebule«, »2 jajci« ×3 = »6 jajc«, žlice in rezine', () => {
    expect(scaleText('1/2 čebule', 3)).toBe('1½ čebule')
    expect(scaleText('1/2 čebule', 2)).toBe('1 čebula')
    expect(scaleText('2 jajci', 3)).toBe('6 jajc')
    expect(scaleText('kruh (1 rezina)', 2)).toBe('kruh (2 rezini)')
    expect(scaleText('kruh (2 rezini)', 3)).toBe('kruh (6 rezin)')
    expect(scaleText('1 žlička medu', 3)).toBe('3 žličke medu')
    expect(scaleText('olivno olje 1 žlica', 3)).toBe('olivno olje 3 žlice')
    expect(scaleText('½ žličke soli', 2)).toBe('1 žlička soli')
    expect(scaleText('mleko 1,5 % 250 ml', 3)).toBe('mleko 1,5 % 750 ml')
    expect(scaleText('ščep soli', 3)).toBe('ščep soli')
    expect(scaleText('paradižnikova omaka 1,5 kozarca', 2)).toBe('paradižnikova omaka 3 kozarci')
    expect(scaleIngredients({ ingredients: [{ key: 'ai0', qty: 0, text: '1 1/2 skodelice riža' }] }, 2)).toEqual(['3 skodelice riža'])
  })
})

/* ---------- E26, E27: nakupovalni seznam ---------- */

describe('E26 — nakupovalni seznam po oddelkih, zelenjava po vrstah', () => {
  it('pisc-riz: paprika, bučke, brokoli, čebula, česen — ne »zelenjava: …«; oddelki po vrsti', () => {
    const g = shoppingGroups([{ dish: 'pisc-riz', ingredients: [{ key: 'riz', qty: 90, text: '' }, { key: 'piscanec', qty: 150, text: '' }, { key: 'zelenjava', qty: 300, text: '' }, { key: 'cebula', qty: 100, text: '' }, { key: 'olje', qty: 10, text: '' }] }])
    expect(g.map(x => x.title)).toEqual(['Sadje in zelenjava', 'Meso in ribe', 'Kruh, kosmiči, riž in testenine', 'Verjetno imaš doma'])
    expect(g[0]!.items).toEqual(['brokoli: 100 g', 'bučke: 100 g', 'čebula: 90 g', 'česen: 20 g (≈ 1 glavica)', 'paprika: 100 g'])
    expect(g[3]!.items).toEqual(['olivno olje: 10 g'])
    // 7 dni po pravilih: nobena vrstica »zelenjava:« (vse jedi imajo vrste)
    const p = P(), plan = [0, 1, 2, 3, 4, 5, 6].map(i => weekDay(i, addD(TODAY, i)))
    const ahead = recipesAhead({ p, plan, activities: [], meals: [], recentMeals: [], weather: null, today: TODAY, settings: { foodPrefs: '' }, days: 7, targetOf: d => dailyTarget(p, [], plan.filter(x => x.date === d), d, { today: TODAY, hour: 9 }) })
    const l = shoppingList(ahead.flatMap(a => a.recipes))
    expect(l.some(x => /^zelenjava/.test(x)), l.join(' | ')).toBe(false)
    expect(l.some(x => /^čebula in česen/.test(x))).toBe(false)
  })
  it('vsaka jed z »zelenjavo« pove, katero', () => {
    for (const d of DISHES.filter(x => x.items.some(([k]) => k === 'zelenjava'))) expect(d.veg?.length, d.id).toBeGreaterThan(0)
  })
})

/* ---------- E29, E36: slovnica ---------- */

describe('E29, E36 — slovnica imen in korakov', () => {
  it('imena in koraki', () => {
    expect(dish('kruh-med').name).toBe('Kruh z medom in banano')
    expect(dish('ajda-jajce').name).toBe('Ajdova kaša z jajci in zelenjavo')
    expect(dish('juha-zel').name).toBe('Zelenjavna juha z jajci in kruhom')
    expect(dish('cicerika').name).toBe('Curry s čičeriko in rižem')
    for (const d of [...DISHES, ...LF_DISHES]) {
      expect(d.steps.join(' '), d.id).not.toMatch(/nariban jabolko/)
      // koraki ne povedo števila jajc (»ubij jajci« pri 3 jajcih za 1 osebo ali 9 za 3)
      expect(d.steps.join(' '), d.id).not.toMatch(/(?<!(?:z|s|razžvrkljanimi) )jajci(?!\p{L})/u)
    }
  })
})

/* ---------- E31, E32: vegan beljakovine ---------- */

describe('E31, E32 — vegan: sojin jogurt k malici, malice z beljakovinami', () => {
  it('zajtrk in malica: »sojin jogurt (150 g) ali kozarec sojinega napitka«, ne tofu', () => {
    const v = { deficit: false, keepMuscle: false, training: false, prefs: 'vegan' }
    for (const key of ['zajtrk', 'malica']) {
      const w = whyRecipe({ p: 12, c: 40, f: 7 }, { key, proteinG: 26 }, v)
      expect(w, key).toMatch(/dodaj sojin jogurt \(150 g\) ali kozarec sojinega napitka/)
      expect(w, key).not.toMatch(/tofu/)
    }
    expect(whyRecipe({ p: 20, c: 80, f: 7 }, { key: 'kosilo', proteinG: 40 }, v)).toMatch(/tofu/)
  })
  it('vegan 7 dni: malica ima vsaj 60 % beljakovin obroka vsaj 4 dni (prej nikoli čez 50 %)', () => {
    let ok = 0, n = 0
    const log: string[] = []
    for (let i = 0; i < 7; i++) {
      const d = addD(TODAY, i)
      const { dp, r } = dayOf(P(), [day(d, 'pocitek', 0)], d, 'vegan')
      const sl = dp.slots.find(s => s.key === 'malica')!
      if (!r.malica) continue
      n++; if (r.malica.p >= sl.proteinG * 0.6) ok++
      log.push(`${r.malica.name} ${r.malica.p}/${sl.proteinG}`)
    }
    expect(n).toBe(7)
    expect(ok, log.join(', ')).toBeGreaterThanOrEqual(4)
    expect(ok).toBeGreaterThanOrEqual(4)
  })
})

/* ---------- H01: želje iz uvoda ---------- */

describe('H01 — prehranske želje iz uvoda', () => {
  it('iz besedila želje samo stavki o hrani', () => {
    expect(foodPrefsFromWish('Rada bi shujšala 5 kg. Sem vegan. Tečem 3× na teden.')).toBe('vegan')
    expect(foodPrefsFromWish('Ne prenašam laktoze')).toBe('brez laktoze')
    expect(foodPrefsFromWish('Sem vegetarijanka, ne maram brokolija.')).toBe('vegetarijansko, ne maram brokolija')
    expect(foodPrefsFromWish('Imam alergijo na oreške')).toBe('imam alergijo na oreške')
    expect(foodPrefsFromWish('Ne maram teka v dežju, brez poškodb.')).toBeNull()
    expect(foodPrefsFromWish('Hočem hitreje na klanec')).toBeNull()
    expect(foodPrefsFromWish('celiakija')).toBe('brez glutena')
    expect(exclusionsOf(foodPrefsFromWish('Sem vegan.')).contains).toEqual(expect.arrayContaining(['meso', 'mleko', 'jajca', 'riba']))
  })
})

/* ---------- zaslon ---------- */

let div: HTMLDivElement, root: Root
async function render(el: React.ReactElement) {
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root.render(el) })
}
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(b.textContent || '') || re.test(b.getAttribute('aria-label') || ''))
async function click(el: Element | undefined | null) { expect(el).toBeTruthy(); await act(async () => { (el as HTMLElement).click(); await new Promise(r => setTimeout(r, 0)) }) }
async function unmount() { await act(async () => root?.unmount()); div?.remove() }
beforeEach(() => { try { localStorage.clear() } catch { /* */ } })
afterEach(async () => { await unmount(); vi.useRealTimers(); S.alts.length = 0; S.route = { name: 'prehrana', params: {} } })
function setState(o: { plan?: PlanDay[]; time?: string } = {}) {
  vi.useFakeTimers({ toFake: ['Date'] })
  vi.setSystemTime(new Date(`${TODAY}T${o.time || '08:30'}:00`))
  S.state = { ready: true, settings: { ...repo.defaultSettings(), foodPrefs: null }, changes: [], toast: null, sync: { state: 'off' }, authKnown: true, pro: false, wellness: null, checkinToday: null, today: TODAY, profile: P(), plan: o.plan || [], activities: [], mealsToday: [], recentMeals: [], checkins: [], weather: null, user: null }
}

describe('Prehrana — recepti in nakup (v3.50)', () => {
  it('E05: »drug predlog« se shrani za dan; ob vrnitvi na Prehrano in na Danes ostane ista jed', async () => {
    S.route = { name: 'prehrana', params: { recept: 'kosilo' } }
    setState()
    await render(<Prehrana />)
    const nameNow = () => document.querySelector('#recept-kosilo [aria-expanded] b')?.textContent
    const before = nameNow()
    await click(btn(/^drug predlog$/))
    expect(S.alts[0]).toEqual([TODAY, { kosilo: 1 }])
    const after = nameNow()
    expect(after).not.toBe(before)
    await unmount()
    await render(<Prehrana />)   // nazaj na Prehrano (prej spet prvotna jed)
    expect(nameNow()).toBe(after)
    // Danes: recipeCtxOf brez alt, nastavitve z recipeAlt
    const st = S.state
    const t = dailyTarget(st.profile, [], [], TODAY, { today: TODAY, hour: 9 })!
    const dm = dayMealsOf({ p: st.profile, target: t, plan: [], activities: [], meals: [], recentMeals: [], weather: null, day: TODAY, today: TODAY })
    expect(recipesOf(dm.dp, TODAY, recipeCtxOf(st.profile, t, st.settings, dm.training), st.settings).kosilo!.name).toBe(after)
  })
  it('E26, E27: seznam po oddelkih; kljukice ostanejo ob ponovnem odprtju', async () => {
    setState({ plan: [day(TODAY, 'kolo', 90)] })
    await render(<Prehrana />)
    await click(btn(/^nakupovalni seznam$/))
    expect([...document.querySelectorAll('.shop-group')].map(x => x.textContent)[0]).toBe('Sadje in zelenjava')
    const lines = () => [...document.querySelectorAll('.shop-list button')]
    const a = lines()[0]!.textContent, b = lines()[2]!.textContent
    await click(lines()[0]); await click(lines()[2])
    await click([...document.querySelectorAll('button')].filter(x => x.textContent === 'Zapri').pop())
    await unmount()
    await render(<Prehrana />)
    await click(btn(/^nakupovalni seznam$/))
    const pressed = lines().filter(x => x.getAttribute('aria-pressed') === 'true').map(x => x.textContent)
    expect(pressed).toEqual([a, b])
  })
})

// za poročilo: koliko je F tabela vplivala (živila sojini koščki in edamame imajo makre v ±5 %)
describe('nova živila', () => {
  it('sojini koščki in edamame: kcal ≈ 4·B + 4·OH + 9·M', () => {
    for (const k of ['sojkos', 'edamame']) { const f = F[k]!; expect(Math.abs(4 * f.p + 4 * f.c + 9 * f.f - f.kcal) / f.kcal, k).toBeLessThan(0.05) }
  })
})
