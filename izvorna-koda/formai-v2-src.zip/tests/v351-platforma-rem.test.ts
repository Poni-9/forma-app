// v3.51 PLATFORMA G07: velikosti pisave v rem (»Velikost pisave« brskalnika jih poveča). Pretvorba: scratchpad/audit51/impl-PLATFORMA/rem.py
import { describe, it, expect } from 'vitest'
import { readFileSync } from 'node:fs'
import { rem } from '../src/ui/rem'

const src = (f: string) => readFileSync(new URL('../' + f, import.meta.url), 'utf8')

describe('G07 — velikosti pisave v rem', () => {
  it('CSS in pristajalna stran: noben font-size v px', () => {
    for (const f of ['src/styles/base.css', 'src/styles/build.css', 'src/styles/motion.css', 'src/styles/tokens.css', 'landing/landing.css']) {
      expect(src(f).match(/font-size\s*:[^;}]*\d+(\.\d+)?px/g) ?? []).toEqual([])
    }
    expect(src('src/styles/base.css')).toMatch(/\.head \.nm \{ font-size: 1\.625rem;/)   // prej 26px
  })
  it('TSX: v slogu ni številke za fontSize (rem(N)); rem je točen (videz pri 16 px enak)', () => {
    for (const f of ['src/screens/Danes.tsx', 'src/screens/Prehrana.tsx', 'src/screens/Plan.tsx', 'src/screens/Ostalo.tsx', 'src/app/App.tsx']) {
      expect(src(f).match(/\bfontSize\s*:\s*\d/g) ?? []).toEqual([])
    }
    expect(rem(13)).toBe('0.8125rem'); expect(rem(12.5)).toBe('0.78125rem'); expect(rem(16)).toBe('1rem')
  })
})
