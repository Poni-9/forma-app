import { describe, it, expect } from 'vitest'
import { TEMPLATES, CRANK } from '@/ui/figure/templates'
import { sideFk, FLOOR, type SidePose } from '@/ui/figure/rig'

/** Blaž, 14. 10.: »stričko naj se bolj naravno premika« — tek, hoja in kolo iz biomehanike, ne nihalo med dvema pozama. */
const gen = (n: string) => (TEMPLATES[n] as { gen?: (u: number) => SidePose }).gen!

describe('Naravno gibanje figure', () => {
  it('tek in hoja: stopala ne gredo pod tla, pri teku je faza leta', () => {
    for (const n of ['tek', 'hoja']) {
      let under = 0, air = 0
      for (let i = 0; i < 200; i++) { const s = sideFk(gen(n)(i / 200)); const gap = FLOOR - Math.max(s.ankleL.y, s.toeL.y, s.ankleR.y, s.toeR.y); under = Math.min(under, gap); air = Math.max(air, gap) }
      expect(under).toBeGreaterThan(-3.5)
      if (n === 'tek') expect(air).toBeGreaterThan(2)
      else expect(air).toBeLessThan(2)
    }
  })
  it('zanka je gladka (konec = začetek), brez skokov med sličicami', () => {
    for (const n of ['tek', 'hoja', 'kolo']) {
      const g = gen(n)
      const a = sideFk(g(0)), b = sideFk(g(0.999999))
      expect(Math.hypot(a.ankleL.x - b.ankleL.x, a.ankleL.y - b.ankleL.y)).toBeLessThan(1.5)
      let maxStep = 0
      for (let i = 0; i < 120; i++) { const p = sideFk(g(i / 120)), q = sideFk(g((i + 1) / 120 % 1)); maxStep = Math.max(maxStep, Math.hypot(p.pelvis.x - q.pelvis.x, p.pelvis.y - q.pelvis.y)) }
      expect(maxStep).toBeLessThan(1.2)
    }
  })
  it('kolo: blazinica stopala kroži na pedalu okrog gonilke, koleno je vedno spredaj', () => {
    for (let i = 0; i < 40; i++) {
      const s = sideFk(gen('kolo')(i / 40))
      for (const [ank, toe, knee, hip] of [[s.ankleL, s.toeL, s.kneeL, s.hipL], [s.ankleR, s.toeR, s.kneeR, s.hipR]] as const) {
        const ball = { x: ank.x + (toe.x - ank.x) * (8 / 12), y: ank.y + (toe.y - ank.y) * (8 / 12) }
        expect(Math.abs(Math.hypot(ball.x - CRANK.x, ball.y - CRANK.y) - 11)).toBeLessThan(0.8)
        // koleno pred črto kolk–gleženj (ne upogiba se nazaj)
        const cross = (ank.x - hip.x) * (knee.y - hip.y) - (ank.y - hip.y) * (knee.x - hip.x)
        expect(cross).toBeLessThan(0)
      }
    }
  })
})
