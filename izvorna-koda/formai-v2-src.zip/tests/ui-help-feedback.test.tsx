// »Kako deluje« (izrazi, tap na izraz) in »Pripomba« (posnetek, vrsta, pošlji) — brez pravega strežnika.
import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const F = vi.hoisted(() => ({ sent: [] as any[], toasts: [] as string[], result: 'poslano' as 'poslano' | 'v vrsti' }))
vi.mock('@/state/store', () => ({ toast: (m: string) => { F.toasts.push(m) }, useApp: () => ({ profile: {}, checkins: [], settings: {}, today: '2026-10-04', plan: [], activities: [] }) }))
vi.mock('@/data/feedback', () => ({
  FB_KINDS: [['nejasno', 'Ni jasno'], ['napaka', 'Napaka'], ['predlog', 'Predlog']],
  FB_SHOT_MAX: 700000, FB_TEXT_MAX: 3000,
  makeFeedback: async (o: any) => ({ ...o, id: 'x', meta: {}, anon: 'a' }),
  sendFeedback: async (f: any) => { F.sent.push(f); return F.result },
  captureScreen: async () => 'data:image/jpeg;base64,BBBB',
}))
vi.mock('@/ui/Guide', () => ({ Guide: () => null }))

import { FeedbackSheet } from '@/ui/FeedbackSheet'
import { HelpSheet, Term, startFeedback } from '@/ui/HelpSheet'
import { useOverlays, closeFeedback, closeHelp } from '@/ui/overlays'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
let div: HTMLDivElement, root: Root
const btn = (t: string | RegExp) => [...document.querySelectorAll('button')].find(b => typeof t === 'string' ? b.textContent?.trim() === t : t.test(b.textContent || '')) as HTMLButtonElement
beforeEach(() => { closeFeedback(); closeHelp(); F.sent = []; F.toasts = []; F.result = 'poslano'; div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div) })
afterEach(async () => { await act(async () => root.unmount()); div.remove() })

function Probe() { const o = useOverlays(); return <span data-probe>{o.help ? `help:${o.help.term ?? ''}` : ''}{o.fb ? `fb:${o.fb.route}:${o.fb.shot ? 'shot' : 'none'}` : ''}</span> }

describe('Pripomba', () => {
  it('posnetek je viden in ga lahko odstraniš; brez besedila in slike ni pošiljanja; vrsta in besedilo gresta zraven', async () => {
    await act(async () => { root.render(<FeedbackSheet shot="data:image/jpeg;base64,AAAA" route="danes" />) })
    expect(document.querySelector('.fb-shot img')).not.toBeNull()
    await act(async () => btn('odstrani').click())
    expect(document.querySelector('.fb-shot img')).toBeNull()
    expect(btn('Pošlji').disabled).toBe(true)
    await act(async () => btn('Napaka').click())
    const ta = document.querySelector('#fb-text') as HTMLTextAreaElement
    await act(async () => { const set = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')!.set!; set.call(ta, 'Gumb Opravil ne dela'); ta.dispatchEvent(new Event('input', { bubbles: true })) })
    expect(btn('Pošlji').disabled).toBe(false)
    await act(async () => btn('Pošlji').click())
    expect(F.sent[0]).toMatchObject({ kind: 'napaka', text: 'Gumb Opravil ne dela', shot: null, route: 'danes' })
    expect(F.toasts[0]).toMatch(/poslana razvijalcu/)
  })
  it('brez povezave: »shranjena — pošljem, ko bo povezava«', async () => {
    F.result = 'v vrsti'
    await act(async () => { root.render(<FeedbackSheet shot="data:image/jpeg;base64,AAAA" route="plan" />) })
    await act(async () => btn('Pošlji').click())
    expect(F.toasts[0]).toMatch(/shranjena/)
  })
  it('gumb v glavi: najprej posnetek zaslona, nato list s posnetkom in zaslonom', async () => {
    await act(async () => { root.render(<Probe />) })
    location.hash = '#/plan'
    await act(async () => { await startFeedback() })
    expect(div.querySelector('[data-probe]')!.textContent).toBe('fb:plan:shot')
  })
})

describe('Kako deluje', () => {
  it('tap na izraz odpre razlago tega izraza (označen)', async () => {
    await act(async () => { root.render(<><Probe /><Term k="tss">TSS</Term></>) })
    await act(async () => btn('TSS').click())
    expect(div.querySelector('[data-probe]')!.textContent).toBe('help:tss')
    await act(async () => { root.render(<HelpSheet term="tss" />) })
    const hit = document.querySelector('.term-row.hit')
    expect(hit?.textContent).toMatch(/TSS — obremenitev/)
    expect(document.body.textContent).not.toMatch(/Kako deluje FORMAI/)   // z izrazom: samo »Kaj pomeni«
  })
  it('brez izraza: koraki »Kako deluje« in gumb za pripombo', async () => {
    await act(async () => { root.render(<HelpSheet term={null} />) })
    expect(document.querySelectorAll('.how li').length).toBeGreaterThanOrEqual(6)
    expect(btn('Pošlji pripombo')).toBeTruthy()
  })
})
