import { describe, it, expect, vi } from 'vitest'
import { garminCourse, thinEven, courseNameOf, COURSE_MAX_POINTS, COURSE_NAME_MAX } from '../src/domain/garmin/course'
import { encodePolyline, type LatLon } from '../src/domain/import/polyline'

vi.mock('../src/data/firebase', () => ({ idToken: async () => 'tok' }))
import { putGarminWorkouts, deleteGarminWorkouts, putGarminCourse, GarminPushError, garminErrorText } from '../src/domain/garmin/pushClient'
import { PROXY } from '../src/config'

/** Ravna sled proti severu: n točk, korak ~ stepM metrov. */
const line = (n: number, stepM = 40): LatLon[] => Array.from({ length: n }, (_, i) => [46.19 + (i * stepM) / 111_320, 14.49] as LatLon)

describe('v3.52 Garmin Courses API — trasa iz knjižnice', () => {
  it('točke iz kodirane sledi, višina iz profila na 50 m, dolžina, vzpon, ime z datumom', () => {
    const pts = line(26)   // 1000 m
    const prof = Array.from({ length: 21 }, (_, i) => 300 + i * 2)   // 300 … 340 m na vsakih 50 m
    const c = garminCourse({ poly: encodePolyline(pts), prof, km: 1, gainM: 40, name: 'Vodice krog' }, '2026-11-07')!
    expect(c.courseName).toBe('FORMAI · Vodice krog · 7. 11.')
    expect(c.coordinateSystem).toBe('WGS84'); expect(c.activityType).toBe('ROAD_CYCLING')
    expect(c.geoPoints.length).toBe(26)
    expect(c.geoPoints[0]).toEqual({ latitude: 46.19, longitude: 14.49, elevation: 300 })
    expect(c.geoPoints[25]!.elevation).toBeCloseTo(340, 0)
    // na sredini (500 m) je višina 320 m
    const mid = c.geoPoints[Math.round(25 / 2)]!
    expect(mid.elevation!).toBeGreaterThan(318); expect(mid.elevation!).toBeLessThan(322)
    expect(c.distanceInMeters).toBeGreaterThan(990); expect(c.distanceInMeters).toBeLessThan(1010)
    expect(c.elevationGainInMeters).toBe(40)
    expect(c.description).toContain('1,0 km'); expect(c.description).toContain('40 m vzpona')
  })
  it('razredčenje na ≤ 2000 točk, prva in zadnja ostaneta; brez profila brez višin; < 2 točki → null', () => {
    const pts = line(5000, 10)
    const c = garminCourse({ poly: encodePolyline(pts), prof: [], km: 50, gainM: 0, name: 'Dolga' }, '2026-11-07')!
    expect(c.geoPoints.length).toBe(COURSE_MAX_POINTS)
    expect(c.geoPoints[0]!.latitude).toBe(46.19)
    expect(c.geoPoints[COURSE_MAX_POINTS - 1]!.latitude).toBeCloseTo(pts[4999]![0], 5)
    expect(c.geoPoints.every(p => p.elevation === undefined)).toBe(true)
    expect(thinEven([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 4)).toEqual([1, 4, 7, 10])
    expect(thinEven([1, 2, 3], 10)).toEqual([1, 2, 3])
    expect(garminCourse({ poly: encodePolyline(line(1)), prof: [], km: 0, gainM: 0, name: 'x' }, '2026-11-07')).toBeNull()
    expect(garminCourse({ poly: '', prof: [], km: 0, gainM: 0, name: 'x' }, '2026-11-07')).toBeNull()
  })
  it('ime: največ 60 znakov, datum vedno na koncu (Garmin trase loči po imenu)', () => {
    const n = courseNameOf('Zelo dolgo ime trase čez tri hribe in nazaj domov po drugi poti', '2026-12-24')
    expect(n.length).toBeLessThanOrEqual(COURSE_NAME_MAX); expect(n.startsWith('FORMAI · ')).toBe(true); expect(n.endsWith(' · 24. 12.')).toBe(true)
    expect(courseNameOf('', '2026-01-05')).toBe('FORMAI · Trasa · 5. 1.')
  })
})

describe('v3.52 Garmin — klici strežnika (pushClient)', () => {
  const mk = (status: number, body: unknown) => vi.fn(async () => ({ ok: status < 400, status, json: async () => body })) as unknown as typeof fetch
  it('PUT /garmin/workouts z žetonom, največ 14, rezultat normaliziran', async () => {
    const f = mk(200, { created: 2, updated: '1', errors: [{ date: '2026-11-03', error: 'garmin_400' }] })
    const ws = Array.from({ length: 16 }, (_, i) => ({ uid: `formai-${i}`, date: `d${i}` })) as never[]
    const r = await putGarminWorkouts(ws, f)
    expect(r).toEqual({ created: 2, updated: 1, skipped: 0, removed: 0, errors: [{ date: '2026-11-03', error: 'garmin_400' }] })
    const [url, init] = (f as unknown as { mock: { calls: [string, RequestInit][] } }).mock.calls[0]!
    expect(url).toBe(`${PROXY}/garmin/workouts`); expect(init.method).toBe('PUT')
    expect((init.headers as Record<string, string>).Authorization).toBe('Bearer tok')
    expect(JSON.parse(init.body as string).workouts.length).toBe(14)
  })
  it('napake strežnika → GarminPushError s slovensko kodo in besedilom; ni omrežja; brez prijave', async () => {
    await expect(putGarminWorkouts([], mk(409, { error: 'ni_povezave' }))).rejects.toMatchObject({ name: 'GarminPushError', code: 'ni_povezave', status: 409, message: expect.stringMatching(/Garmin ni povezan/) })
    await expect(deleteGarminWorkouts(mk(503, { error: 'garmin_ni_nastavljen' }))).rejects.toMatchObject({ code: 'garmin_ni_nastavljen', message: expect.stringMatching(/strežniku še ni nastavljena/) })
    await expect(deleteGarminWorkouts(mk(502, { error: 'garmin_400' }))).rejects.toMatchObject({ code: 'garmin_400', message: expect.stringMatching(/napaka 400/) })
    await expect(deleteGarminWorkouts(mk(500, {}))).rejects.toMatchObject({ code: 'napaka', message: 'Pošiljanje na Garmin ni uspelo (strežnik 500).' })
    const dead = vi.fn(async () => { throw new TypeError('Failed to fetch') }) as unknown as typeof fetch
    await expect(deleteGarminWorkouts(dead)).rejects.toMatchObject({ code: 'omrezje', status: 0, message: expect.stringMatching(/ni omrežja/) })
    expect(garminErrorText('garmin_429', 502)).toMatch(/preveč zahtev/); expect(garminErrorText('garmin_401', 502)).toMatch(/poveži Garmin znova/)
    expect(new GarminPushError('x', 1, 'y')).toBeInstanceOf(Error)
  })
  it('DELETE vrne število; PUT /garmin/course vrne courseId, brez njega napaka', async () => {
    expect(await deleteGarminWorkouts(mk(200, { removed: 3 }))).toBe(3)
    const course = garminCourse({ poly: encodePolyline(line(3)), prof: [1, 2], km: 0.1, gainM: 1, name: 'k' }, '2026-11-07')!
    const f = mk(200, { courseId: 987 })
    expect(await putGarminCourse(course, f)).toEqual({ courseId: 987 })
    expect(JSON.parse(((f as unknown as { mock: { calls: [string, RequestInit][] } }).mock.calls[0]![1]).body as string).course.courseName).toBe(course.courseName)
    await expect(putGarminCourse(course, mk(200, {}))).rejects.toMatchObject({ message: expect.stringMatching(/brez courseId/) })
  })
})
