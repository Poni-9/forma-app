import { describe, it, expect } from 'vitest'
import { readinessOf } from '../src/domain/readiness'
import { formBand, titleNoDur } from '../src/domain/training/load'
import { fmtSleep } from '../src/domain/wellness'

describe('v3.47 — številke, ki se ne tepejo', () => {
  it('forma +31 po pavzi ni »pripravljenost 96«: svežina šteje do +15, nad +25 je »prepočit«', () => {
    // (v3.50) brez jutranjega vnosa pripravljenosti ni (H14) — tu nevtralen vnos (energija v redu, mišice brez bolečin)
    const c = { date: '2026-10-17', mood: 3 as const, soreness: 1 as const }
    expect(readinessOf(31, null, null)).toBeNull()
    expect(readinessOf(31, c, null)!.score).toBe(78)
    expect(readinessOf(31, c, null)!.reasons).toContain('dolgo brez rednega treninga — kondicija pada')
    expect(readinessOf(12, c, null)!.score).toBe(74)
    expect(readinessOf(-25, c, null)!.score).toBe(30)
    expect(formBand(31).band).toBe('prepočit')
    expect(formBand(12).band).toBe('svež')
  })
  it('spanec in trajanja v isti obliki (7 h 06 min)', () => {
    expect(fmtSleep(7.1)).toBe('7 h 06 min')
    expect(titleNoDur('Kolo — 3 × 1 min', 60)).toBe('Kolo — 3 × 1 min')
  })
})

describe('v3.47 — gorivo na kolesu', () => {
  it('hrana enakomerno čez vožnjo; vsota v povzetku = to, kar neseš; brez dolgega pripisa pri vodi', async () => {
    const { rideFuel } = await import('../src/domain/nutrition/dayplan')
    const day = { id: 'x', date: '2026-10-17', kind: 'kolo', title: 'Dolga Z2', desc: '', durationMin: 105, zone: 'Z2', role: 'dolga' } as never
    const f = rideFuel(day, ['banana'])!
    const solid = f.cues.filter(c => c.solid).map(c => c.atMin)
    expect(solid.length).toBeGreaterThanOrEqual(2)
    const gaps = solid.slice(1).map((t, i) => t - solid[i]!)
    expect(Math.max(...gaps) - Math.min(...gaps)).toBeLessThanOrEqual(5)
    expect(f.schedule).toContain(`Skupaj ~${f.carriedCarbs} g OH`)
    expect(f.items.join(' ')).not.toMatch(/izotonika nimaš/)
  })
})

describe('v3.47 — recepti dosežejo obroke', () => {
  it('dan z vožnjo: recepti skupaj v ±5 % ciljev obrokov (prej ~150 kcal pod ciljem — skrit primanjkljaj); dodatek ni dvakrat', async () => {
    const { dayRecipes } = await import('../src/domain/nutrition/recipes')
    const { dayMealPlan } = await import('../src/domain/nutrition/dayplan')
    const dp = dayMealPlan({ weightKg: 80, trainTime: 'popoldne' }, { kcal: 3124, proteinG: 142, carbsG: 443 }, { kind: 'kolo', durationMin: 105, zone: 'Z2', title: 'Kolo', role: 'dolga' } as never)
    const slots = dp.slots.reduce((t, s) => t + s.kcal, 0)
    let sum = 0
    for (let d = 1; d <= 20; d++) {
      const r = dayRecipes(dp, `2026-10-${String(d).padStart(2, '0')}`, { deficit: true, keepMuscle: true, training: true })
      sum += Object.values(r).reduce((t, x) => t + x.kcal, 0)
      for (const x of Object.values(r)) expect(x.steps.some(s => /^Zraven še/.test(s))).toBe(false)
    }
    expect(Math.abs(sum / 20 - slots)).toBeLessThan(slots * 0.05)
  })
})

describe('v3.47 — besedila treningov brez merilnika moči', () => {
  it('brez vatov za regeneracijo, »pri utripu«, kratki napori po občutku', async () => {
    const { buildWeek, macroWeeks } = await import('../src/domain/training/planner')
    const p = { name: 'T', sex: 'm', age: 30, heightCm: 180, weightKg: 75, ftp: 250, lthr: 172, hoursPerWeek: 9, level: 3, gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, strength: { on: false }, event: { name: 'Franja', date: '2027-06-13', distanceKm: 156 }, cycleStart: '2026-10-12', onboardingDone: true, createdAt: '', updatedAt: '' } as never
    const all = macroWeeks(p, '2026-10-17').slice(0, 30).flatMap(w => buildWeek({ profile: p, activities: [], weekStart: w.weekStart, notBefore: '2026-01-01' }))
    const text = all.map(d => `${d.title}: ${d.desc}`).join('\n')
    expect(all.length).toBeGreaterThan(50)
    expect(text).not.toMatch(/pri utrip \d/)
    const regen = all.filter(d => d.title === 'Regeneracija')
    for (const d of regen) expect(d.desc).not.toMatch(/\d\s?W\b/)
    expect(text).not.toMatch(/× [12] min pri utripu/)
  })
})
