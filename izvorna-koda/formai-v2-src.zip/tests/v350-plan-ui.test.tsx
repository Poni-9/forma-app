// v3.50 PLAN-UI — Plan, trak tedna, sezona, izvozi (.ics, .zwo, deli), premik dneva, olajšanje, »Kako deluje« brez merilnika.
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeAll, afterAll, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'plan', params: {} as Record<string, string> } }))
vi.mock('@/state/store', async () => {
  const { vi: v } = await import('vitest')
  const base: Record<string | symbol, unknown> = {
    useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
    getState: () => S.state,
    routePace: () => ({ k: 1, adj: { n: 0, adj: 1 } }),
  }
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' || typeof k === 'symbol' ? undefined : (t[k] = v.fn(async () => undefined))), has: (_t, k) => k !== 'then' })
})
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => S.route }))
vi.mock('@/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '@/state/store'
import { Plan, applyDayEdit, dayFormError, paras } from '@/screens/Plan'
import { Ahead, Horizon, SeasonChart, WeekRibbon, nearestBar } from '@/ui/PlanHero'
import { MoveDaySheet, movedText } from '@/ui/MoveDaySheet'
import { easeTexts } from '@/ui/ChangeDaySheet'
import { DayPlan } from '@/ui/DayPlan'
import { RacesCard } from '@/ui/Races'
import { weekToIcs, icsStartMinutes } from '@/domain/training/ics'
import { zwoFor, powerOf } from '@/domain/training/zwo'
import { weekText } from '@/domain/training/share'
import { moveTargets, blockedAfterRace } from '@/domain/training/swap'
import { raceLock } from '@/domain/training/protect'
import { stepsFor, totalSec } from '@/domain/training/workout'
import { easeDay, plannedMacro } from '@/domain/training/planner'
import { helpFor, TERMS } from '@/domain/glossary'
import { addDays } from '@/domain/training/load'
import { normalizeFocus, profileFromFocus } from '@/domain/focus/model'
import type { Activity, Focus, PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-18'   // nedelja
const NOW = `${TODAY}T08:00:00.000Z`
beforeAll(() => { vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date(`${TODAY}T10:00:00`)) })
afterAll(() => { vi.useRealTimers() })

let div: HTMLDivElement | null = null, root: Root | null = null
async function render(el: ReactElement): Promise<HTMLDivElement> {
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root!.render(el) })
  return div
}
afterEach(async () => { if (root) await act(async () => root!.unmount()); div?.remove(); root = null; div = null; document.body.innerHTML = '' })
const sp = (x: string | null | undefined) => (x || '').replace(/[  ⁠]/g, ' ')
const txt = (d: Element) => sp(d.textContent)
const fn = (k: string) => (store as unknown as Record<string, ReturnType<typeof vi.fn>>)[k]!
const setVal = (el: HTMLInputElement, v: string) => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(el, v); el.dispatchEvent(new Event('input', { bubbles: true })) }
const key = (el: Element, k: string) => el.dispatchEvent(new KeyboardEvent('keydown', { key: k, bubbles: true }))
/** jsdom nima PointerEvent: React posluša »pointerdown«/»pointermove«, MouseEvent nosi clientX, button, buttons */
const ptr = (el: Element, type: 'pointerdown' | 'pointermove', clientX: number) => el.dispatchEvent(new MouseEvent(type, { bubbles: true, clientX, button: 0, buttons: 1 }))

const day = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: date + (o.kind || 'kolo') + (o.role || '') + (o.title || ''), date, kind: 'kolo', title: 'Z2 vzdržljivost', desc: 'Mirno utrip 149–164, kadenca 90+.', durationMin: 60, zone: 'Z2', role: 'lahka', tssTarget: 42, source: 'rules', createdAt: NOW, updatedAt: NOW, ...o })
const rest = (date: string, title = 'Počitek'): PlanDay => day(date, { kind: 'pocitek', title, desc: 'Prosto.', durationMin: 0, zone: null, role: null, tssTarget: 0 })
const moc = (date: string): PlanDay => day(date, { kind: 'moc', title: 'Moč — jedro', desc: 'Jedro.', durationMin: 20, zone: null, role: 'moc', tssTarget: 15, exercises: [{ name: 'Deska', sets: 3, reps: '45 s' }] })
/** Blaž: brez merilnika (pametni trenažer), LTHR 184, FTP 240 iz prejšnjih meritev, trenira popoldne. */
const BLAZ = {
  name: 'Blaž', sex: 'm', age: 21, heightCm: 180, weightKg: 79, restHr: 48, maxHr: 195, lthr: 184, ftp: 240, ftpDate: '2026-09-14', goal: 'dirka', level: 3,
  gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false, powerMeterAuto: true }, hoursPerWeek: 11, hoursMode: 'own', strength: { on: true, equipment: 'home' }, strengthDays: 2,
  deficit: 400, neat: 1.4, proteinGkg: 1.8, event: { name: 'Maraton Franja', date: '2027-06-13', distanceKm: 156, type: 'maraton', elevM: 1600, level: 'amater' },
  races: [{ id: 'r1', name: 'Kronometer Vodice', date: '2026-10-23', distanceKm: 18, prio: 'B', type: 'kronometer' }], trainTime: 'popoldne', cycleStart: '2026-09-21', baseHours: 5.8, onboardingDone: true, createdAt: NOW, updatedAt: NOW,
} as unknown as Profile
const PM = { ...BLAZ, gear: { ...BLAZ.gear, powerMeter: true } } as Profile
const ride = (date: string, min: number, tss = 50): Activity => ({ id: 'a' + date + min, source: 'manual', sport: 'kolo', date, name: 'Vožnja', durationMin: min, tss } as Activity)
const ACTS: Activity[] = ['2026-09-22', '2026-09-26', '2026-09-29', '2026-10-03', '2026-10-06', '2026-10-10'].map(d => ride(d, 105))
const state = (o: Record<string, unknown> = {}) => ({ ready: true, today: TODAY, profile: BLAZ, activities: ACTS, plan: [], checkins: [], weather: null, user: null, changes: [], settings: {}, sync: { state: 'ok' }, mealsToday: [], recentMeals: [], routeLib: null, routesBusy: false, ...o })

/* ---------- izvozi ---------- */
describe('B16 .ics: ura po »kdaj treniraš«, moč po vožnji, tekma ob 8:00, brez opravljenih in brez razlage tedna', () => {
  const tue = '2026-10-27'
  const vo2 = day(tue, { title: 'VO2max 4 × 4 min', durationMin: 75, zone: 'Z5', role: 'kljucna', why: 'Osnova · razbremenilni teden · 5 h. Maraton Franja čez 33 tednov.' })
  const week = [moc(tue), vo2, day('2026-10-23', { title: 'Kronometer Vodice — 18 km', durationMin: 30, zone: 'dirka', role: 'dirka' }), day('2026-10-26', { done: { at: NOW } })]
  it('vožnja popoldne ob 16:30, moč 10 min po njej (prej obe ob 17:00 in 18:00 — prekrivanje)', () => {
    const ics = weekToIcs(week, { trainTime: 'popoldne' })
    expect(ics).toContain('DTSTART:20261027T163000')
    expect(ics).toContain('DTEND:20261027T174500')
    // moč: 10 min po koncu vožnje
    const ev = ics.split('BEGIN:VEVENT').slice(1)
    const m = ev.find(e => /SUMMARY:Moč/.test(e))!
    expect(m).toContain('DTSTART:20261027T175500')
    expect(m).toContain('DTEND:20261027T181500')
    expect(icsStartMinutes('zjutraj')).toBe(7 * 60); expect(icsStartMinutes('zvecer')).toBe(18 * 60 + 30); expect(icsStartMinutes(null)).toBe(17 * 60)
    expect(weekToIcs(week, { trainTime: 'zjutraj' })).toContain('DTSTART:20261027T070000')
  })
  it('tekma ob 8:00 kot »Tekma: …«; opravljeni dnevi izpuščeni; v opisu ni razlage tedna', () => {
    const ics = weekToIcs(week, { trainTime: 'popoldne' })
    expect(ics).toContain('SUMMARY:Tekma: Kronometer Vodice — 18 km')
    expect(ics).toContain('DTSTART:20261023T080000')
    expect(ics).not.toContain('UID:2026-10-26kolo')
    expect(ics).not.toContain('čez 33 tednov')
    expect(ics).not.toContain('Zakaj:')
  })
})

describe('B17/B18/B19 .zwo brez merilnika in zadnja ponovitev', () => {
  const t15 = day('2026-10-27', { title: '30/15 — 3 serije × 13', desc: '20 min ogrevanje s 3 kratkimi pospeški · 3 serije × 13 × (30 s zelo trdo, a enakomerno / 15 s lahko), med serijami 3 min lahko · ostanek Z2 (utrip 149–164), 15 min iztek. Vsaka 30-sekundna ponovitev enako trdo kot prva; če pade, končaj serijo. Brez merilnika moči: utrip pri kratkih naporih zaostaja — vozi po občutku.', durationMin: 90, zone: 'Z5', role: 'kljucna', target: null, why: 'Osnova · 5 h. Maraton Franja čez 33 tednov. Kratki intervali z mikro odmori.' })
  const anaer = day('2026-10-27', { title: '8 × 30 s vse, kar gre', desc: '20 min ogrevanje s 3 kratkimi pospeški · 8 × (30 s vse, kar gre / 4 min 30 s lahko) · ostanek Z2 (utrip 149–164), 15 min iztek. Vsaka ponovitev do konca.', durationMin: 90, zone: 'Z5', role: 'kljucna', target: null })
  const vo2 = day('2026-10-27', { title: 'VO2max 4 × 4 min', desc: '20 min ogrevanje s 3 kratkimi pospeški · 4 × 4 min pri utripu nad 184, vmes 4 min lahko · 15 min iztek. Enakomerno.', durationMin: 75, zone: 'Z5', role: 'kljucna', target: null })
  it('B18: 30/15 brez merilnika gre na trenažer pri 125 % FTP (prej 113 % kot 4-min VO2max); »vse, kar gre« brez ERG', () => {
    const z = zwoFor(t15, BLAZ)!
    const on = [...z.xml.matchAll(/<IntervalsT Repeat="(\d+)" OnDuration="30" OffDuration="15" OnPower="([\d.]+)"/g)]
    expect(on.length).toBeGreaterThan(0)
    for (const m of on) expect(+m[2]!).toBeGreaterThanOrEqual(1.2)
    const a = zwoFor(anaer, BLAZ)!
    expect(a.xml).toMatch(/<FreeRide Duration="30"/)
    expect(a.xml).not.toMatch(/Power="1.13"/)
    // z merilnikom kot prej: delež iz vatov v opisu
    const pm = day('2026-10-27', { ...t15, desc: t15.desc.replace('30 s zelo trdo, a enakomerno', '30 s pri 288–312 W (120–130 % FTP)'), target: { lo: 288, hi: 312 } })
    expect(zwoFor(pm, PM)!.xml).toMatch(/OnDuration="30" OffDuration="15" OnPower="1.25"/)
    expect(powerOf({ kind: 'delo', label: 'Interval 1/4', sec: 240, z: 'Z5', set: 1, sets: 4 }, { target: null }, BLAZ)).toBe(1.13)
  })
  it('B19: VO2max 4 × 4 je en blok Repeat="4" (prej 3 + ločen SteadyState), skupno trajanje nespremenjeno', () => {
    const z = zwoFor(vo2, BLAZ)!
    expect(z.xml).toMatch(/<IntervalsT Repeat="4" OnDuration="240" OffDuration="240"/)
    expect(z.xml).not.toMatch(/<SteadyState Duration="240"/)
    let t = 0
    for (const m of z.xml.matchAll(/<(Warmup|Cooldown|SteadyState|FreeRide) Duration="(\d+)"/g)) t += +m[2]!
    for (const m of z.xml.matchAll(/<IntervalsT Repeat="(\d+)" OnDuration="(\d+)" OffDuration="(\d+)"/g)) t += +m[1]! * (+m[2]! + +m[3]!)
    expect(t).toBe(totalSec(stepsFor(vo2, BLAZ).filter(s => s.sec > 0)))
    expect(t).toBe(75 * 60)
    // 30/15: vsaka serija 13 ×, ne 12 × + 1
    expect([...zwoFor(t15, BLAZ)!.xml.matchAll(/Repeat="(\d+)" OnDuration="30"/g)].map(m => m[1])).toEqual(['13', '13', '13'])
  })
  it('B17: opis v .zwo je samo opis treninga, brez razlage tedna (»čez 33 tednov«)', () => {
    const z = zwoFor(t15, BLAZ)!
    const desc = /<description>([^<]*)<\/description>/.exec(z.xml)![1]!
    expect(desc).not.toContain('čez 33 tednov')
    expect(desc).toContain('30 s zelo trdo')
  })
})

describe('B20 »deli«: brez merilnika utrip, ne vati', () => {
  const vo2 = day('2026-10-27', { title: 'VO2max 4 × 4 min', durationMin: 75, zone: 'Z5', role: 'kljucna', target: { lo: 259, hi: 276 } })
  it('Blaž (brez merilnika): »utrip nad 184«; z merilnikom vati kot prej; brez profila kot prej', () => {
    const t = weekText([vo2], '2026-10-26', BLAZ)
    expect(t).toContain('VO2max 4 × 4 min · 1 h 15 min · utrip nad 184')
    expect(t).not.toMatch(/\d W\b/)
    expect(weekText([vo2], '2026-10-26', PM)).toContain('259–276 W')
    expect(weekText([vo2], '2026-10-26')).toContain('259–276 W')
  })
})

describe('B25 »Kako deluje« brez merilnika', () => {
  it('test FTP = pražni utrip, FTP brez »95 % povprečne moči«; z merilnikom in brez podatkov o opremi kot prej', () => {
    const np = helpFor(BLAZ)
    expect(np.terms.find(t => t.k === 'test')!.d).not.toContain('% povprečne moči')
    expect(np.terms.find(t => t.k === 'test')!.d).toContain('pražni utrip')
    expect(np.terms.find(t => t.k === 'ftp')!.d).toContain('po utripu')
    expect(helpFor(PM).terms).toEqual(TERMS)
    expect(helpFor({ focus: null }).terms).toEqual(TERMS)
  })
})

/* ---------- premik in olajšanje ---------- */
describe('A06 premik: trd trening ne na dan po tekmi; B21 besedila', () => {
  const tempo = day('2026-10-20', { title: 'Tempo 3 × 10 min', durationMin: 75, zone: 'Z3', role: 'kljucna', tssTarget: 70 })
  const regen = day('2026-10-24', { title: 'Regeneracija', durationMin: 45, zone: 'Z1', role: 'regen', tssTarget: 20 })
  const plan = [tempo, day('2026-10-21'), rest('2026-10-22'), day('2026-10-23', { title: 'Kronometer Vodice — 18 km', durationMin: 30, zone: 'dirka', role: 'dirka', raceId: 'r1' }), regen, rest('2026-10-25'), rest('2026-10-28')]
  const lock = raceLock(plan, BLAZ)
  it('moveTargets za ključni trening ne ponudi sobote po tekmi; lahka seja jo sme', () => {
    expect(lock.afterRace('2026-10-24')).toBe(true)
    const t = moveTargets(plan, tempo, TODAY, '2026-10-31', lock).map(x => x.date)
    expect(t).not.toContain('2026-10-24')
    expect(t).toContain('2026-10-25')
    expect(moveTargets(plan, day('2026-10-21'), TODAY, '2026-10-31', lock).map(x => x.date)).toContain('2026-10-24')
    expect(blockedAfterRace(tempo, '2026-10-24', lock)).toBe(true)
    expect(blockedAfterRace(regen, '2026-10-24', lock)).toBe(false)
  })
  it('list: »Premakni: …«, »danes«/»jutri«, sobota pri »Ni na izbiro« z razlogom »dan po tekmi«', async () => {
    S.state = state({ plan: [...plan, day(TODAY, { title: 'Z2 + 4 × 30 s pospeški' }), rest('2026-10-19')] })
    await render(<MoveDaySheet day={tempo} onClose={() => undefined} />)
    const d = document.body
    const t = txt(d)
    expect(t).toContain('Premakni: Tempo 3 × 10 min')
    expect(t).not.toContain('Premakni Tempo')
    expect(t).toMatch(/danes\s*18\. 10\./)
    expect(t).toMatch(/jutri\s*19\. 10\./)
    expect(t).toContain('sob 24. 10. (dan po tekmi)')
    expect([...d.querySelectorAll('button')].some(b => /24\. 10\./.test(sp(b.textContent)))).toBe(false)
  })
  it('obvestilo brez spola: »Premaknjeno na sredo: Dolga Z2 — sobota je zdaj počitek.«', () => {
    const long = day('2026-10-24', { title: 'Dolga Z2', durationMin: 150, role: 'dolga' })
    expect(movedText(long, rest('2026-10-21'))).toBe('Premaknjeno na sredo: Dolga Z2 — sobota je zdaj počitek.')
    expect(movedText(long, regen)).toBe('Premaknjeno na soboto: Dolga Z2 — Regeneracija gre na soboto.')
    expect(movedText(long, rest('2026-10-21'))).not.toMatch(/premaknjen /)
  })
})

describe('A03 »Olajšaj dan«: podnapis in obvestilo po izidu (v nedeljo seja odpade)', () => {
  const tempo = (date: string) => day(date, { title: 'Tempo 3 × 10 min', zone: 'Z3', role: 'kljucna', durationMin: 75 })
  it('nedelja brez prostega dne: »… ta teden odpade« (prej »gre na prost dan tega tedna«)', () => {
    const week = [day('2026-10-13', { done: { at: NOW } }), rest('2026-10-14'), day('2026-10-15', { done: { at: NOW } }), rest('2026-10-16'), day('2026-10-17', { done: { at: NOW } }), tempo(TODAY)]
    const out = easeDay(week, TODAY, raceLock(week, BLAZ))!
    expect(out.length).toBe(1)
    const tx = easeTexts(tempo(TODAY), out, TODAY)
    expect(tx.sub).toBe('Danes samo lahko; Tempo 3 × 10 min ta teden odpade — bolje en manj kot bolezen.')
    expect(tx.sub).not.toContain('prost dan')
    expect(tx.toast).toBe('Danes lahko. Tempo 3 × 10 min ta teden odpade.')
  })
  it('s prostim dnem: »… gre na sredo«; lahka vožnja »Danes 30–45 min zelo lahko; …«', () => {
    const w2 = [tempo('2026-10-13'), rest('2026-10-14'), rest('2026-10-15')]
    const o2 = easeDay(w2, '2026-10-13', raceLock(w2, BLAZ))!
    expect(o2.length).toBe(2)
    const tx = easeTexts(tempo('2026-10-13'), o2, '2026-10-13')
    expect(tx.sub).toBe('Danes samo lahko; Tempo 3 × 10 min gre na sredo.')
    expect(tx.toast).toBe('Danes lahko. Tempo 3 × 10 min gre na sredo.')
    expect(easeTexts(day('2026-10-13'), o2, '2026-10-13').sub).toBe('Danes 30–45 min zelo lahko; Z2 vzdržljivost gre na sredo.')
  })
})

/* ---------- Plan: kartice, teden, glava ---------- */
describe('Plan: B32 kljukica prihodnjega dne, B31 trajanje, B23 brez treninga, B34 menjava tedna, B48 naslovi', () => {
  it('B32: kljukica za torek 20. 10. je onemogočena (»še ni na vrsti«), danes in pretekli dnevi ostanejo', async () => {
    S.route = { name: 'plan', params: {} }
    S.state = state({ plan: [day('2026-10-17', { title: 'Dolga Z2', durationMin: 150, role: 'dolga' }), day(TODAY), day('2026-10-20', { title: 'Z2 + 4 × 30 s pospeški' })] })
    const d = await render(<Plan />)
    await act(async () => { (d.querySelector('.seg button[aria-pressed="false"]:nth-child(3)') as HTMLButtonElement).click() })   // Naslednji
    const fut = [...d.querySelectorAll('button.check-hit')].find(b => /torek, 20\. 10\./.test(sp(b.getAttribute('aria-label')))) as HTMLButtonElement
    expect(fut).toBeTruthy()
    expect(fut.disabled).toBe(true)
    expect(sp(fut.getAttribute('aria-label'))).toBe('torek, 20. 10.: Z2 + 4 × 30 s pospeški — še ni na vrsti')
    fn('setPlanDone').mockClear()
    await act(async () => { fut.click() })
    expect(fn('setPlanDone')).not.toHaveBeenCalled()
  })
  it('B32: današnja kljukica deluje', async () => {
    S.route = { name: 'plan', params: {} }
    S.state = state({ plan: [day(TODAY)] })
    const d = await render(<Plan />)
    const now = [...d.querySelectorAll('button.check-hit')].find(b => /nedelja, 18\. 10\./.test(sp(b.getAttribute('aria-label')))) as HTMLButtonElement
    expect(now.disabled).toBe(false)
    expect(sp(now.getAttribute('aria-label'))).toContain('označi kot opravljeno')
  })
  it('B31: prazno trajanje je napaka, 0 min se ne shrani, 900 → 480, počitek brez trajanja ni napaka', () => {
    const d = day('2026-10-20', { title: 'Dolga Z2', durationMin: 150, role: 'dolga', tssTarget: 100 })
    const form = { kind: 'kolo' as const, title: d.title, dur: '', zone: 'Z2', desc: d.desc }
    expect(dayFormError(form)).toBe('Trajanje: od 10 do 480 min.')
    expect(dayFormError({ ...form, dur: '0' })).toBeTruthy()
    expect(dayFormError({ ...form, dur: '900' })).toBeTruthy()
    expect(dayFormError({ ...form, dur: '150' })).toBeNull()
    expect(dayFormError({ kind: 'pocitek', dur: '' })).toBeNull()
    expect(applyDayEdit(d, form, []).durationMin).toBe(150)       // prazno obdrži staro (prej 0 min, 0 TSS)
    expect(applyDayEdit(d, { ...form, dur: '900' }, []).durationMin).toBe(480)
    expect(applyDayEdit(d, { ...form, dur: '120' }, []).durationMin).toBe(120)
  })
  it('B31: v listu »Uredi dan« je ob praznem trajanju napaka in Shrani onemogočen', async () => {
    S.route = { name: 'plan', params: {} }
    const d0 = day(TODAY, { title: 'Dolga Z2', durationMin: 150, role: 'dolga' })
    S.state = state({ plan: [d0] })
    const d = await render(<Plan />)
    await act(async () => { ([...d.querySelectorAll('button')].find(b => /^Spremeni/.test(sp(b.textContent))) as HTMLButtonElement).click() })
    await act(async () => { ([...document.querySelectorAll('button')].find(b => /^Uredi/.test(sp(b.textContent))) as HTMLButtonElement).click() })
    await act(async () => { await new Promise(r => setTimeout(r, 60)) })   // možnost se izvede 30 ms po zaprtju lista
    const inp = document.getElementById('ed-dur') as HTMLInputElement
    expect(inp).toBeTruthy()
    await act(async () => { setVal(inp, '') })
    expect(sp(document.body.textContent)).toContain('Trajanje: od 10 do 480 min.')
    expect(inp.getAttribute('aria-invalid')).toBe('true')
    const save = [...document.querySelectorAll('button')].find(b => sp(b.textContent) === 'Shrani') as HTMLButtonElement
    expect(save.disabled).toBe(true)
    fn('savePlanDay').mockClear()
    await act(async () => { save.click() })
    expect(fn('savePlanDay')).not.toHaveBeenCalled()
  })
  it('B23: teden brez treninga nima »Teden v številkah · 0 / 0 opravljeno«', async () => {
    S.route = { name: 'plan', params: {} }
    S.state = state({ plan: [rest(TODAY)] })
    const d = await render(<Plan />)
    expect(txt(d)).not.toContain('0 / 0 opravljeno')
    expect(txt(d)).not.toContain('Teden v številkah')
  })
  it('B34: po ogledu prejšnjega tedna je ob vrnitvi na »Ta teden« izbran današnji dan (odprta kartica z »Spremeni«)', async () => {
    S.route = { name: 'plan', params: {} }
    S.state = state({ plan: [day('2026-10-06', { title: 'Z2 prejšnji' }), day(TODAY, { title: 'Z2 danes' })] })
    const d = await render(<Plan />)
    const seg = (n: number) => d.querySelector(`.seg button:nth-child(${n})`) as HTMLButtonElement
    await act(async () => { seg(1).click() })   // Prejšnji
    await act(async () => { (d.querySelector('[id="dan-2026-10-06"]') as HTMLButtonElement).click() })
    await act(async () => { seg(2).click() })   // Ta teden
    const card = d.querySelector('[id="dan-2026-10-18"]')!
    expect(card.textContent).toContain('Z2 danes')
    expect([...card.querySelectorAll('button')].some(b => /^Spremeni/.test(sp(b.textContent)))).toBe(true)
    expect(sp(d.querySelector('h1.nm')?.textContent)).toBe('Ta teden')
  })
  it('B48: kratki nazivi pogledov (»2 tedna«, »Naslednji«, »Prejšnji«) — ena vrstica tudi pri 360 px', async () => {
    S.route = { name: 'plan', params: {} }
    S.state = state({ plan: [day(TODAY)] })
    const d = await render(<Plan />)
    const seg = (n: number) => d.querySelector(`.seg button:nth-child(${n})`) as HTMLButtonElement
    await act(async () => { seg(4).click() })
    expect(sp(d.querySelector('h1.nm')?.textContent)).toBe('2 tedna')
    await act(async () => { seg(3).click() })
    expect(sp(d.querySelector('h1.nm')?.textContent)).toBe('Naslednji')
    await act(async () => { seg(1).click() })
    expect(sp(d.querySelector('h1.nm')?.textContent)).toBe('Prejšnji')
  })
})

describe('B28 dolg opis (vročina) v odstavkih; H39 Plan pred začetkom bloka', () => {
  const HEAT_DESC = 'Mirno utrip 149–164, kadenca 90+. Če si utrujen, skrajšaj — ne pospešuj. Prilagoditev na vročino (brez termometra): obleci se za ~10–15 °C topleje kot običajno (dolga majica + jopič ali pulover + dolge hlače). Vozi Z2 kot sicer; zadnjih 30–40 min naj ti bo vroče in se močno potiš, a še lahko govoriš. Utrip bo za isti tempo ~10 udarcev višji — tempa ne dvigaj. Pij po žeji z elektroliti; stehtaj se pred in po (izguba do ~2 % teže je v redu). Takoj nehaj in se ohladi ob glavobolu, vrtoglavici, slabosti, mrazenju, kurji koži ali zmedenosti. Če je zunaj nad 25 °C, vozi raje v najtoplejšem delu dneva v običajni opremi. Alternativa: 20–30 min savne ali tople kopeli takoj po lahki vožnji.'
  it('paras: vsak odstavek ≤ 260 znakov, skupaj isto besedilo; datum »13. 6.« ne prelomi', () => {
    const p = paras(HEAT_DESC)
    expect(HEAT_DESC.length).toBeGreaterThan(600)
    expect(p.length).toBeGreaterThanOrEqual(3)
    for (const x of p) expect(x.length).toBeLessThanOrEqual(260)
    expect(p.join(' ')).toBe(HEAT_DESC)
    expect(paras('Franja je 13. 6. Nato lahko.')).toEqual(['Franja je 13. 6. Nato lahko.'])
    expect(paras('Kratko.')).toEqual(['Kratko.'])
  })
  it('Plan: »Podrobnosti« dneva z vročino so v več odstavkih (prej en odstavek ~700 znakov)', async () => {
    S.route = { name: 'plan', params: {} }
    S.state = state({ plan: [day(TODAY, { title: 'Z2 vzdržljivost · vročina', desc: HEAT_DESC, durationMin: 90 })] })
    const d = await render(<Plan />)
    const ps = [...d.querySelectorAll('details.more p')]
    expect(ps.length).toBeGreaterThanOrEqual(3)
    for (const x of ps) expect(sp(x.textContent).length).toBeLessThan(380)
  })
  it('H39: načrt po meri, dogovor v nedeljo — Plan »Začneš v ponedeljek, 19. 10.« (ne »Teden 1«)', async () => {
    const f = normalizeFocus({ sports: ['fitnes', 'tek'], aims: ['misice'], sessions: [{ type: 'fitnes', min: 60 }, { type: 'fitnes', min: 60 }, { type: 'tek', min: 40 }], hoursPerWeek: 3, level: 2, title: 'Manj maščobe, več energije' } as unknown as Focus)
    const p = { ...BLAZ, event: null, races: [], ...profileFromFocus(f!, BLAZ, '2026-10-12', TODAY) } as Profile
    S.route = { name: 'plan', params: {} }
    S.state = state({ profile: p, plan: [rest(TODAY, 'Pred začetkom')] })
    const d = await render(<Plan />)
    expect(sp(d.querySelector('.head .hi')?.textContent)).toBe('Začneš v ponedeljek, 19. 10.')
    // naslednji teden je teden 1
    await act(async () => { (d.querySelector('.seg button:nth-child(3)') as HTMLButtonElement).click() })
    expect(sp(d.querySelector('.head .hi')?.textContent)).toMatch(/^Teden 1/)
  })
})

describe('B33 pretekli dan: brez »Kaj te čaka«, trase, goriva in prehrane', () => {
  it('torek 6. 10. kaže »Kako je bil zastavljen«, brez Trase in »Prehrana ta dan«', async () => {
    S.state = state({})
    const past = day('2026-10-06', { title: 'Z2 + 8 × 15 s šprint', desc: 'Mirno utrip 149–164. Na sredi 8 × 15 s šprint — vse, kar gre; vmes 4–5 min zelo lahko.', durationMin: 65 })
    const d = await render(<DayPlan day={past} />)
    const t = txt(d)
    expect(t).toContain('Kako je bil zastavljen')
    expect(t).not.toContain('Kaj te čaka')
    expect(t).not.toContain('Trasa')
    expect(t).not.toContain('Gorivo')
    expect(t).not.toContain('Prehrana ta dan')
    await act(async () => root!.unmount()); root = null; div!.remove()
    const d2 = await render(<DayPlan day={{ ...past, date: '2026-10-20' }} />)
    expect(txt(d2)).toContain('Kaj te čaka')
    expect(txt(d2)).toContain('Prehrana ta dan')
  })
})

/* ---------- trak, 2 tedna, sezona ---------- */
describe('B22 trak in »2 tedna«: kolo pred močjo, ne glede na vrstni red shrambe', () => {
  const days = Array.from({ length: 7 }, (_, i) => addDays('2026-10-12', i))
  it('torek z močjo (prvo v shrambi) in vožnjo: ikona in oznaka vožnje', async () => {
    const items = [moc('2026-10-13'), day('2026-10-13', { title: 'Z2 + 8 × 15 s šprint', durationMin: 65 })]
    const d = await render(<WeekRibbon days={days} items={items} today={TODAY} focus={TODAY} onPick={() => undefined} />)
    const tue = [...d.querySelectorAll('.pl-day')][1]!
    expect(sp(tue.getAttribute('aria-label'))).toBe('tor 13.: Z2 + 8 × 15 s šprint + Moč — jedro, ni označeno')
    expect((tue as HTMLElement).style.getPropertyValue('--c')).toBe('var(--t-kolo)')
    await act(async () => root!.unmount()); root = null; div!.remove()
    const a = await render(<Ahead items={[moc('2026-10-20'), day('2026-10-20', { title: 'Z2 + 8 × 15 s šprint', durationMin: 65 })]} preview={new Set()} today={TODAY} onPick={() => undefined} />)
    const row = [...a.querySelectorAll('.ah-day')].find(x => /20\. 10\./.test(sp(x.getAttribute('aria-label'))))!
    expect(sp(row.getAttribute('aria-label'))).toBe('Tor 20. 10.: Z2 + 8 × 15 s šprint + Moč — jedro')
    expect((row as HTMLElement).style.getPropertyValue('--c')).toBe('var(--t-kolo)')
  })
})

describe('B24/H39 »2 tedna« v nedeljo in B05 kolo in moč posebej', () => {
  it('en dan: »Ta teden · danes, 18. 10.« (prej »18. 10. – 18. 10.«); teden z močjo: »kolo 6 h · moč 50 min«', async () => {
    const items = [rest(TODAY), day('2026-10-19', { durationMin: 120 }), moc('2026-10-19'), day('2026-10-21', { durationMin: 240 }), day('2026-10-24', { kind: 'moc', title: 'Moč — noge', durationMin: 30, role: 'moc', exercises: [{ name: 'Počep', sets: 3, reps: '8' }] })]
    const a = await render(<Ahead items={items} preview={new Set()} today={TODAY} onPick={() => undefined} />)
    const heads = [...a.querySelectorAll('.ah-h span')].map(x => sp(x.textContent))
    expect(heads[0]).toBe('danes, 18. 10. · brez vadb')
    expect(heads[0]).not.toContain('18. 10. – 18. 10.')
    expect(heads[1]).toBe('19. 10. – 25. 10. · 4 vadbe · kolo 6 h · moč 50 min')
  })
})

describe('B29/G10 sezona in obzorje: en drsnik namesto 38 gumbov; H17 os od začetka bloka; B47 »zdaj« ob piki tekme; B41 cilj čez 80+ tednov', () => {
  it('nearestBar: indeks pod prstom', () => {
    expect(nearestBar(0, 380, 38)).toBe(0)
    expect(nearestBar(379, 380, 38)).toBe(37)
    expect(nearestBar(190, 380, 38)).toBe(19)
    expect(nearestBar(-5, 380, 38)).toBe(0)
    expect(nearestBar(500, 380, 38)).toBe(37)
    expect(nearestBar(10, 0, 5)).toBe(0)
  })
  it('sezona: role=slider s tipkovnico (→ izbere naslednji teden), brez gumbov .pl-bar; »zdaj« dvignjen ob tekmi B naslednji teden', async () => {
    const m = plannedMacro(BLAZ, ACTS, TODAY)
    expect(m.length).toBeGreaterThan(30)
    const d = await render(<SeasonChart macro={m} profile={BLAZ} start="2026-10-12" today={TODAY} />)
    expect(d.querySelectorAll('button.pl-bar').length).toBe(0)
    const sl = d.querySelector('[role="slider"]') as HTMLElement
    expect(sl).toBeTruthy()
    expect(d.querySelectorAll('[role="slider"]').length).toBe(1)
    const now = m.findIndex(w => w.weekStart === '2026-10-12')
    expect(sl.getAttribute('aria-valuenow')).toBe(String(now))
    expect(sp(sl.getAttribute('aria-valuetext'))).toContain('Teden od 12. 10.')
    expect(txt(d.querySelector('.pl-hz-info')!)).toContain('Ta teden')
    await act(async () => { key(sl, 'ArrowRight') })
    expect(sl.getAttribute('aria-valuenow')).toBe(String(now + 1))
    expect(sp(sl.getAttribute('aria-valuetext'))).toContain('tekma Kronometer Vodice')
    expect(txt(d.querySelector('.pl-hz-info')!)).toContain('Naslednji teden')
    await act(async () => { key(sl, 'Home') })
    expect(sl.getAttribute('aria-valuenow')).toBe('0')
    // stolpci ostanejo (barve, pretekli, zdaj)
    const bars = [...d.querySelectorAll('.pl-bar')]
    expect(bars.length).toBe(m.length)
    expect(bars[now]!.classList.contains('now')).toBe(true)
    expect(bars[now - 1]!.classList.contains('past')).toBe(true)
    // B47: tekma B je naslednji teden → »zdaj« dvignjen
    expect(d.querySelector('.pl-now')!.classList.contains('up')).toBe(true)
  })
  it('sezona: poteg po grafu izbere teden pod prstom', async () => {
    const m = plannedMacro(BLAZ, ACTS, TODAY)
    const d = await render(<SeasonChart macro={m} profile={BLAZ} start="2026-10-12" today={TODAY} />)
    const sl = d.querySelector('[role="slider"]') as HTMLElement
    sl.getBoundingClientRect = () => ({ left: 0, width: m.length * 10, top: 0, height: 92, right: m.length * 10, bottom: 92, x: 0, y: 0, toJSON: () => ({}) }) as DOMRect
    await act(async () => { ptr(sl, 'pointerdown', 55) })
    expect(sl.getAttribute('aria-valuenow')).toBe('5')
    await act(async () => { ptr(sl, 'pointermove', 125) })
    expect(sl.getAttribute('aria-valuenow')).toBe('12')
    expect(sp(sl.getAttribute('aria-valuetext'))).toContain(`Teden od ${m[12]!.weekStart.slice(8).replace(/^0/, '')}.`)
  })
  it('B41: cilj čez 115 tednov — pod grafom pove, da graf ne seže do cilja', async () => {
    const far = { ...BLAZ, event: { name: 'Marmotte', date: '2028-12-31', distanceKm: 174 }, races: [] } as Profile
    const m = plannedMacro(far, ACTS, TODAY)
    expect(m.length).toBe(80)
    const d = await render(<SeasonChart macro={m} profile={far} start="2026-10-12" today={TODAY} />)
    expect(txt(d)).toMatch(/Graf kaže prvih 80 tednov — Marmotte je čez 11\d tednov\./)
  })
  it('H17: obzorje načrta po meri — os na začetku bloka (19. 10., 16. 11.), ne na 12. 10. in 9. 11.; en drsnik', async () => {
    const f = normalizeFocus({ sports: ['fitnes', 'tek'], aims: ['misice'], sessions: [{ type: 'fitnes', min: 60 }, { type: 'fitnes', min: 60 }, { type: 'tek', min: 40 }], hoursPerWeek: 3, level: 2, title: 'Manj maščobe, več energije' } as unknown as Focus)
    const p = { ...BLAZ, event: null, races: [], ...profileFromFocus(f!, BLAZ, '2026-10-12', TODAY) } as Profile
    expect(p.cycleStart).toBe('2026-10-19')   // dogovor v nedeljo: blok od ponedeljka
    const d = await render(<Horizon profile={p} today={TODAY} />)
    const axis = [...d.querySelectorAll('.pl-axis span')].map(x => sp(x.textContent)).filter(Boolean)
    expect(axis.slice(0, 3)).toEqual(['19. 10.', '16. 11.', '14. 12.'])
    expect(axis).not.toContain('12. 10.')
    expect(d.querySelectorAll('[role="slider"]').length).toBe(1)
    expect(d.querySelectorAll('button.pl-bar').length).toBe(0)
  })
})

/* ---------- tekme ---------- */
describe('B35 off-season', () => {
  it('teden pred tekmo B čipa »sezona je končana« ni; sicer je, list pa pove, čez koliko tednov je cilj', async () => {
    S.state = state({})   // Kronometer Vodice 23. 10. čez 5 dni
    const d = await render(<RacesCard bare />)
    expect([...d.querySelectorAll('button')].some(b => /off-season/.test(sp(b.textContent)))).toBe(false)
    await act(async () => root!.unmount()); root = null; div!.remove()
    S.state = state({ profile: { ...BLAZ, races: [] } })
    const d2 = await render(<RacesCard bare />)
    const chip = [...d2.querySelectorAll('button')].find(b => /off-season/.test(sp(b.textContent))) as HTMLButtonElement
    expect(chip).toBeTruthy()
    await act(async () => { chip.click() })
    expect(sp(document.body.textContent)).toContain('Maraton Franja je čez 34 tednov. Off-season zdaj premakne osnovo za 2–6 tednov — res?')
  })
})
