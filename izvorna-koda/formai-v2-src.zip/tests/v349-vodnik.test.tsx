// v3.49 VODNIK — prvi dnevi: vodnik krajši in po tvojem tednu (brez »Vpiši vadbo«, »Pri teku«, kilogramov brez opreme,
// vatov brez merilnika), strategija brez »(deficitkalorije …)«, Prvi koraki (ura samo z res povezano uro, »Nimam ure«,
// tekme v Planu, brez podvojenega »Cilj sezone«), prvi dan brez obrazca jutranjega vnosa, opomnik za kopijo brez računa,
// »Samo telefon« brez slikanja ure, prazen račun z namigom, kje je načrt.
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach, beforeAll, afterAll } from 'vitest'

const S = vi.hoisted(() => ({
  state: null as any, subs: new Set<() => void>(), route: { name: 'danes', params: {} as Record<string, string> },
  nav: [] as [string, Record<string, string> | undefined][], kv: new Map<string, unknown>(), setKv: [] as [string, unknown][], persisted: null as boolean | null,
}))
vi.mock('@/state/store', async () => {
  const { vi: v } = await import('vitest')
  const base: Record<string | symbol, unknown> = {
    useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
    getState: () => S.state,
    LAST_EXPORT_KEY: 'backup.lastExportAt',
  }
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' || typeof k === 'symbol' ? undefined : (t[k] = v.fn(async () => {}))), has: (_t, k) => k !== 'then' })
})
vi.mock('@/app/router', () => ({ navigate: (n: string, p?: Record<string, string>) => { S.nav.push([n, p]) }, useRoute: () => S.route, parseHash: () => S.route }))
vi.mock('@/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
vi.mock('@/data/db', async (orig) => {
  const m = await orig<typeof import('../src/data/db')>()
  return { ...m, getKV: async (k: string) => S.kv.get(k), setKV: async (k: string, v: unknown) => { S.kv.set(k, v); S.setKv.push([k, v]) }, storagePersisted: () => S.persisted }
})
vi.mock('@/ui/overlays', () => ({ openHelp: vi.fn() }))

import { Guide } from '@/ui/Guide'
import { FirstSteps } from '@/ui/FirstSteps'
import { BackupNudge } from '@/ui/BackupNudge'
import { Checkin } from '@/ui/Checkin'
import { GoalCard } from '@/ui/GoalCard'
import { Prijava } from '@/screens/Prijava'
import { Uvoz } from '@/screens/Uvoz'
import { Plan } from '@/screens/Plan'
import { strategyLines, dealStrategy, normalizeFocus, STRAT_REPS } from '@/domain/focus/model'
import { ruleStrategy } from '@/domain/focus/rules'
import { noWatchIn, firstDayOf, backupNudgeDue, backupSnooze, seasonCardOn, BACKUP_SNOOZE_KEY } from '@/domain/start'
import { addDays } from '@/domain/training/load'
import type { Activity, Focus, PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-17', NOW = `${TODAY}T08:00:00.000Z`
beforeAll(() => { vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date(`${TODAY}T10:00:00`)) })
afterAll(() => { vi.useRealTimers() })

const day = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: date + (o.kind || 'kolo'), date, kind: 'kolo', title: 'Z2 — daljša vožnja', desc: 'Mirno pogovorni tempo.', durationMin: 60, zone: 'Z2', role: 'lahka', tssTarget: 42, source: 'rules', createdAt: NOW, updatedAt: NOW, ...o })
const BIKE = { sex: 'm', age: 35, heightCm: 180, weightKg: 79, ftp: null, goal: 'hitrejsi', level: 3, hoursPerWeek: 7, gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, strength: { on: false, equipment: 'none' }, onboardingDone: true, goalStart: { date: TODAY, ftp: null, weightKg: 79 }, createdAt: NOW, updatedAt: NOW } as unknown as Profile
const focusOf = (x: Record<string, unknown>): Focus => normalizeFocus({ level: 1, ...x }, { by: 'pravila' })!
// G: »več gibanja«, doma brez opreme in hoja; T: začetnik tekač, samo lahki teki, brez ure
const G = focusOf({ wish: 'Več gibanja, dvakrat na teden po 30 minut. Boli me hrbet.', sports: ['doma', 'hribi'], aims: ['zdravje'], equipment: ['nic'], sessions: [{ type: 'doma', part: 'celo', min: 30 }, { type: 'hribi', cardio: 'lahko', min: 30 }] })
const T = focusOf({ wish: 'Rad bi pretekel 5 km brez ustavljanja. Nimam ure, samo telefon.', sports: ['tek'], aims: ['kondicija', 'hujsanje'], sessions: [{ type: 'tek', cardio: 'lahko', min: 25 }, { type: 'tek', cardio: 'lahko', min: 25 }, { type: 'tek', cardio: 'lahko', min: 30 }] })
const custom = (f: Focus, o: Partial<Profile> = {}) => ({ ...BIKE, goal: 'forma', focus: f, gear: { ...BIKE.gear, noBike: !f.sports.includes('kolo') }, ...o }) as Profile
const reset = (o: Record<string, unknown> = {}) => {
  S.state = { ready: true, today: TODAY, plan: [day(TODAY)], activities: [], recentMeals: [], mealsToday: [], checkins: [], checkinToday: null, weather: null, wellness: null, routeLib: null, settings: { lang: 'sl', intervals: null, guideSeen: false }, profile: BIKE, user: null, authKnown: true, firstSync: null, sync: { state: 'off' }, changes: [], toast: null, ...o }
}

let div: HTMLDivElement | null = null, root: Root | null = null
async function render(el: ReactElement) {
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root!.render(el) })
  for (let i = 0; i < 4; i++) await act(async () => { await Promise.resolve() })
  return div
}
beforeEach(() => { S.nav = []; S.kv.clear(); S.setKv = []; S.persisted = null; S.route = { name: 'danes', params: {} }; S.subs.clear(); localStorage.clear(); reset() })
afterEach(async () => { if (root) await act(async () => root!.unmount()); div?.remove(); root = null; div = null; document.body.innerHTML = '' })
const sp = (x: string | null | undefined) => (x || '').replace(/[  ⁠]/g, ' ').replace(/\s+/g, ' ')
const text = () => sp(document.body.textContent)
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(sp(b.textContent).trim())) as HTMLButtonElement | undefined
const click = async (b: HTMLElement | undefined) => { expect(b).toBeTruthy(); await act(async () => { b!.click() }); for (let i = 0; i < 4; i++) await act(async () => { await Promise.resolve() }) }
/** vse tri korake vodnika (»Več« in »Naprej«) kot eno besedilo */
async function allSteps(): Promise<string> {
  const out: string[] = []
  if (btn(/^Več$/)) await click(btn(/^Več$/))
  for (let i = 0; i < 3; i++) { out.push(sp(document.querySelector('.sheet')?.textContent)); const n = btn(/^Naprej$/); if (!n) break; await click(n) }
  return out.join(' | ')
}

describe('C06 strategija: kalorije kot kazalec, primanjkljaj kot številka', () => {
  it('stara vrstica po pravilih »~2551 kcal na dan (deficit 400 kcal)« ni več »(deficitkalorije …)«', () => {
    const l = strategyLines('– Prehrana: ~2551 kcal na dan (deficit 400 kcal), beljakovine ~166 g — številke so v Prehrani in se prilagajajo treningu.')
    expect(l[0]).toBe('Prehrana: kalorije po dnevu so v Prehrani (na dan treninga več), primanjkljaj ~400 kcal, beljakovine ~166 g.')
    expect(l.join(' ')).not.toMatch(/deficitkalorije|2551/)
  })
  it('»deficit 350 kcal« od trenerja ostane (prej zlepljeno v »deficitkalorije«); vnos za ves dan je še vedno kazalec', () => {
    expect(strategyLines('– Prehrana: deficit 350 kcal, beljakovine 2 g/kg.')).toEqual(['Prehrana: deficit 350 kcal, beljakovine 2 g/kg.'])
    expect(strategyLines('– Prehrana: ~2300 kcal.')).toEqual(['Prehrana: kalorije po dnevu (v Prehrani; na dan treninga več).'])
  })
  it('nova strategija po pravilih: brez dnevne številke, primanjkljaj ostane', () => {
    const l = strategyLines(ruleStrategy(T, { kcal: 2551, proteinG: 166, deficit: 400 }))
    const pre = l.find(x => x.startsWith('Prehrana'))!
    expect(pre).toBe('Prehrana: kalorije po dnevu so v Prehrani (na dan treninga več), primanjkljaj ~400 kcal, beljakovine ~166 g.')
  })
})

describe('C15 strategija po tednu, ki ga dogovor res ima', () => {
  it('doma brez opreme: ponovitve, ne kilogrami; samo lahek kardio: brez »en hitrejši trening«', () => {
    const g = ruleStrategy(G, { kcal: null, proteinG: null, deficit: 0 })
    expect(g).not.toMatch(/vpisuj kilograme|teža višja/)
    expect(g).toContain('vpisuj ponovitve')
    const t = ruleStrategy(T, { kcal: null, proteinG: null, deficit: 0 })
    expect(t).not.toMatch(/hitrejši trening na teden/)
    const fast = focusOf({ wish: 'tek', sports: ['tek'], aims: ['kondicija'], sessions: [{ type: 'tek', cardio: 'intervali', min: 30 }, { type: 'tek', cardio: 'lahko', min: 30 }] })
    expect(ruleStrategy(fast, { kcal: null, proteinG: null, deficit: 0 })).toMatch(/en hitrejši trening na teden/)
  })
  it('shranjena stara vrstica (»vpisuj kilograme«) se v Mojem dogovoru pokaže po tednu', () => {
    const old = '– Moč: vpisuj kilograme — ko narediš vse ponovitve, je naslednjič teža višja. Tako mišice dobijo razlog, da ostanejo in rastejo.\n– Kardio: večinoma lahko, en hitrejši trening na teden — kondicija raste brez izčrpanosti.'
    const l = dealStrategy({ ...G, strategy: old })
    expect(l[0]).toBe(STRAT_REPS)
    expect(l.join(' ')).not.toMatch(/hitrejši trening na teden/)
    const gym = focusOf({ wish: 'fitnes', sports: ['fitnes'], aims: ['misice'], sessions: [{ type: 'fitnes', part: 'celo', min: 50 }] })
    expect(dealStrategy({ ...gym, strategy: old })[0]).toMatch(/vpisuj kilograme/)
  })
})

describe('C30 vodnik prvič na kratko', () => {
  it('en zaslon do 60 besed: današnji trening, »Opravil«, Prehrana in »Začniva«; »Več« odpre tri korake', async () => {
    await render(<Guide open onClose={() => undefined} />)
    const sheet = sp(document.querySelector('.sheet')?.textContent)
    const words = sheet.replace(/VečZačniva$|Več\s*Začniva$/, '').split(/\s+/).filter(w => /\p{L}|\d/u.test(w))
    expect(words.length).toBeLessThanOrEqual(60)
    expect(sheet).toMatch(/Danes: Z2 — daljša vožnja · 1 h\./)
    expect(sheet).toContain('Opravil')
    expect(sheet).toContain('Prehrani')
    expect(sheet).toMatch(/ne zdravniški nasvet/)
    expect(btn(/^Začniva$/)).toBeTruthy()
    await click(btn(/^Več$/))
    expect(text()).toContain('1 / 3')
  })
  it('dan počitka: pove naslednji trening', async () => {
    reset({ plan: [day(TODAY, { kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, role: null }), day(addDays(TODAY, 2), { title: 'Z2 + 6 × 10 s šprint', durationMin: 45 })] })
    await render(<Guide open onClose={() => undefined} />)
    expect(text()).toMatch(/Danes počitek\. Naslednji trening: ponedeljek, 19\. 10\. — Z2 \+ 6 × 10 s šprint\./)
  })
  it('odprt iz pomoči (že videl): takoj trije koraki', async () => {
    reset({ settings: { lang: 'sl', intervals: null, guideSeen: true } })
    await render(<Guide open onClose={() => undefined} />)
    expect(text()).toContain('1 / 3')
  })
})

describe('C08/C15 vodnik napoti na to, kar obstaja, in govori o tvojem tednu', () => {
  it('kolesar brez merilnika: brez »Vpiši vadbo«, brez vatov; »Opravil« in »krajše?«', async () => {
    await render(<Guide open onClose={() => undefined} />)
    const all = await allSteps()
    expect(all).not.toMatch(/Vpiši vadbo/)
    expect(all).toMatch(/Brez ure: po treningu tapni Opravil na Danes — krajšega popraviš s »krajše\?«/)
    expect(all).toMatch(/kaj te čaka \(utrip ali občutek, gorivo/)
    expect(all).not.toMatch(/\bvati\b|Tvoje cone/)
    expect(all).toMatch(/Plan → Tekme sezone/)
  })
  it('kolesar z merilnikom: vati ostanejo', async () => {
    reset({ profile: { ...BIKE, ftp: 250, gear: { ...BIKE.gear, powerMeter: true } } })
    await render(<Guide open onClose={() => undefined} />)
    expect(await allSteps()).toMatch(/kaj te čaka \(vati, gorivo/)
  })
  it('doma brez opreme in hoja (G): brez kilogramov, »Naprava zasedena«, »Pri teku« in »teže«', async () => {
    reset({ profile: custom(G), plan: [day(TODAY, { kind: 'moc', title: 'Vadba doma — celo telo', zone: null, role: 'moc', durationMin: 30 })] })
    await render(<Guide open onClose={() => undefined} />)
    const all = await allSteps()
    expect(all).not.toMatch(/kilogram|Naprava|Pri teku|teže|Vpiši vadbo|hitrejši/)
    expect(all).toContain('Vpiši ponovitve')
    expect(all).toContain('Pri hoji hodi hitro')
    expect(all).toContain('(več serij in minut)')
  })
  it('tekač brez ure (T): samo lahki teki — brez »en trening na teden je hitrejši«; brez intervals.icu', async () => {
    reset({ profile: custom(T), plan: [day(TODAY, { kind: 'tek', title: 'Tek — lahko 25 min', durationMin: 25 })] })
    await render(<Guide open onClose={() => undefined} />)
    expect(sp(document.querySelector('.sheet')?.textContent)).toMatch(/Danes: Tek — lahko · 25 min\./)
    expect(sp(document.querySelector('.sheet')?.textContent)).not.toMatch(/ura/)
    const all = await allSteps()
    expect(all).not.toMatch(/hitrejši|serij|intervals\.icu|Vpiši vadbo/)
    expect(all).toContain('Pri teku drži lahek tempo')
    expect(all).toContain('(več minut)')
    expect(all).toMatch(/Po treningu tapni Opravil na Danes/)
  })
})

describe('C26/C27/C25 Prvi koraki', () => {
  const steps = async () => { if (btn(/^še \d/)) await click(btn(/^še \d/)); return [...document.querySelectorAll('.fs-row')].map(b => b.getAttribute('aria-label') || '') }
  const prog = () => document.querySelector('.fs-prog')?.getAttribute('aria-label')
  it('ročni vnos ali ena datoteka .gpx ne odkljuka »Poveži uro«; vožnja iz intervals.icu jo', async () => {
    const act1 = (source: Activity['source']): Activity => ({ id: 'a-' + source, source, sport: 'kolo', date: TODAY, name: 'Vožnja', durationMin: 60 } as Activity)
    reset({ activities: [act1('manual'), act1('file')] })
    await render(<FirstSteps />)
    expect(await steps()).toContain('Poveži uro')
    await act(async () => root!.unmount()); div!.remove(); root = null
    reset({ activities: [act1('intervals')] })
    await render(<FirstSteps />)
    expect(prog()).toBe('1 od 2 opravljenih')
    expect(await steps()).toEqual(['Shrani na vse naprave'])
  })
  it('»Nimam ure, samo telefon«: namesto »Poveži uro« prvi korak »Opravil«', async () => {
    reset({ profile: custom(T) })
    await render(<FirstSteps />)
    const s = await steps()
    expect(s.join(' | ')).not.toMatch(/Poveži uro/)
    expect(s[0]).toBe('Po treningu tapni »Opravil«')
    await act(async () => root!.unmount()); div!.remove(); root = null
    reset({ profile: custom(T), plan: [day(TODAY, { kind: 'tek', done: { at: NOW } } as Partial<PlanDay>)] })
    await render(<FirstSteps />)
    expect(prog()).toBe('1 od 2 opravljenih')
    expect(await steps()).toEqual(['Shrani na vse naprave'])
  })
  it('»Dodaj tekme sezone« odpre razdelek tekem v Planu (prej vrh Plana)', async () => {
    reset({ profile: { ...BIKE, goal: 'shujsati' } })
    await render(<FirstSteps />)
    await steps()
    await click([...document.querySelectorAll('.fs-row')].find(b => b.getAttribute('aria-label') === 'Dodaj tekme sezone') as HTMLElement)
    expect(S.nav).toContainEqual(['plan', { sec: 'pl-tekme' }])
  })
  it('C20 kolesar brez cilja: »Cilj sezone« je ena vrstica na Danes, v Prvih korakih ga ni še enkrat', async () => {
    expect(seasonCardOn(BIKE)).toBe(true)
    await render(<><FirstSteps /><GoalCard compact /></>)
    expect((await steps()).join(' | ')).not.toMatch(/Dodaj tekme/)
    const card = document.querySelector('.goal-mini') as HTMLButtonElement
    expect(sp(card.textContent)).toBe('Cilj sezonenastavi ›Tekma z datumom (npr. Maraton Franja) — načrt, prehrana in trener delajo zanjo.')
    expect(text()).not.toMatch(/najboljšo težo in največji možni FTP izračunam sam/)
  })
  it('Plan z ?sec=pl-tekme: razdelek tekem je odprt', async () => {
    S.route = { name: 'plan', params: { sec: 'pl-tekme' } }
    await render(<Plan />)
    const sec = document.getElementById('pl-tekme')!
    expect(sec.querySelector('.sec-h')!.getAttribute('aria-expanded')).toBe('true')
  })
})

describe('C20 prvi dan po uvodu', () => {
  it('prvi dan: dogovor danes in še noben jutranji vnos; naslednji dan ali po vnosu prej ne', () => {
    expect(firstDayOf({ today: TODAY, profile: BIKE, checkins: [{ date: TODAY, weightKg: 79 } as never] })).toBe(true)
    expect(firstDayOf({ today: addDays(TODAY, 1), profile: BIKE, checkins: [] })).toBe(false)
    expect(firstDayOf({ today: TODAY, profile: BIKE, checkins: [{ date: addDays(TODAY, -3), mood: 4, soreness: 1 } as never] })).toBe(false)
  })
  it('jutranji vnos strnjen v eno vrstico (brez 15 izbir); »vpiši« odpre cel vnos', async () => {
    await render(<Checkin compact fold extra={<span>Teža 79,0 kg</span>} />)
    expect(document.querySelectorAll('.ci-row').length).toBe(0)
    expect(text()).toMatch(/Kako si danes\?/)
    expect(text()).toMatch(/Teža 79/)   // (v3.50 H36) vrstica teže s »stehtaj« je vidna tudi v zloženi kartici
    await click(btn(/^vpiši$/))
    expect(document.querySelectorAll('.ci-row').length).toBe(3)
    expect(text()).toMatch(/Teža 79/)
  })
})

describe('C24/D16 opomnik za varnostno kopijo brez računa', () => {
  it('pravilo: brez računa, po 7 dneh, brez izvoza v 30 dneh, ne med odlogom', () => {
    const o = { user: false, onboardingDone: true, start: addDays(TODAY, -8), today: TODAY, lastExport: null, until: null }
    expect(backupNudgeDue(o)).toBe(true)
    expect(backupNudgeDue({ ...o, user: true })).toBe(false)
    expect(backupNudgeDue({ ...o, start: addDays(TODAY, -3) })).toBe(false)
    expect(backupNudgeDue({ ...o, lastExport: `${addDays(TODAY, -10)}T10:00:00.000Z` })).toBe(false)
    expect(backupNudgeDue({ ...o, lastExport: `${addDays(TODAY, -40)}T10:00:00.000Z` })).toBe(true)
    expect(backupNudgeDue({ ...o, until: addDays(TODAY, 5) })).toBe(false)
    expect(backupNudgeDue({ ...o, until: TODAY })).toBe(true)
    expect(backupSnooze(TODAY, true)).toBe(addDays(TODAY, 30))
    expect(backupSnooze(TODAY, null)).toBe(addDays(TODAY, 30))
    expect(backupSnooze(TODAY, false)).toBe(addDays(TODAY, 14))
  })
  it('Danes po 8 dneh brez računa: kartica s prijavo in kopijo; »Kasneje« jo skrije za 14 dni, ko shramba ni zaščitena', async () => {
    reset({ profile: { ...BIKE, createdAt: `${addDays(TODAY, -8)}T09:00:00.000Z` } })
    S.persisted = false
    await render(<BackupNudge />)
    expect(text()).toMatch(/Tvoj načrt je samo na tej napravi/)
    expect(btn(/^Prijava z Googlom$/)).toBeTruthy()
    expect(btn(/^Izvozi kopijo$/)).toBeTruthy()
    await click(btn(/^Kasneje$/))
    expect(S.setKv).toContainEqual([BACKUP_SNOOZE_KEY, addDays(TODAY, 14)])
    expect(text()).not.toMatch(/samo na tej napravi/)
  })
  it('z računom ali prvi teden: brez kartice', async () => {
    reset({ profile: { ...BIKE, createdAt: `${addDays(TODAY, -8)}T09:00:00.000Z` }, user: { uid: 'u', name: 'B' } })
    await render(<BackupNudge />)
    expect(text()).toBe('')
    await act(async () => root!.unmount()); div!.remove(); root = null
    reset({ profile: { ...BIKE, createdAt: `${addDays(TODAY, -2)}T09:00:00.000Z` } })
    await render(<BackupNudge />)
    expect(text()).toBe('')
  })
})

describe('C27/C28 brez ure', () => {
  it('»Nimam ure«, »samo telefon« in »brez ure«; ne »Imam Garmin uro« ali »nimam ure na dan«', () => {
    expect(noWatchIn('Rad bi pretekel 5 km brez ustavljanja. Nimam ure, samo telefon.')).toBe(true)
    expect(noWatchIn('Treniram brez ure.')).toBe(true)
    expect(noWatchIn('Beležim samo s telefonom.')).toBe(true)
    expect(noWatchIn('Maraton Franja. Imam Garmin uro.')).toBe(false)
    expect(noWatchIn('Nimam ure na dan, največ 30 minut.')).toBe(false)
    expect(noWatchIn('Brez ure časa ne gre.')).toBe(false)
    expect(noWatchIn(null)).toBe(false)
  })
  it('Uvoz »Samo telefon« (tekač): najprej »Opravil« in »Vpiši ročno« (glavni gumb), posnetek drugi, brez »vožnje na uri« in arhiva', async () => {
    reset({ profile: custom(T) })
    await render(<Uvoz />)
    await click([...document.querySelectorAll('button')].find(b => /Samo telefon/.test(b.textContent || '')) as HTMLElement)
    const t = text()
    expect(t).toMatch(/1 · Brez ure/)
    expect(t).toMatch(/Po treningu tapni Opravil na Danes/)
    expect(t).not.toMatch(/vožnj|na uri ali v njeni aplikaciji|Vsa zgodovina/)
    expect(t.indexOf('Brez ure')).toBeLessThan(t.indexOf('Posnetek zaslona'))
    expect(btn(/^Vpiši ročno$/)!.className).toMatch(/\bprimary\b/)
    await click(btn(/^Vpiši ročno$/))
    expect(S.nav).toContainEqual(['aktivnosti', { nova: '1' }])
  })
})

describe('C32 prazen račun na drugi napravi', () => {
  it('namig, kje je načrt, »Uvozi kopijo« in »Sestavi nov načrt« — brez samodejnega uvoda', async () => {
    reset({ user: { uid: 'u', name: 'Blaž' }, firstSync: 'empty', profile: { ...BIKE, onboardingDone: false } })
    S.route = { name: 'prijava', params: {} }
    await render(<Prijava />)
    expect(text()).toMatch(/Na tem računu še ni načrta/)
    expect(text()).toMatch(/na drugi napravi brez prijave\? Načrt je na tisti napravi — tam se prijavi s tem računom/)
    expect(btn(/^Uvozi kopijo$/)).toBeTruthy()
    expect(S.nav).not.toContainEqual(['uvod', undefined])
    await click(btn(/^Sestavi nov načrt$/))
    expect(S.nav).toContainEqual(['uvod', undefined])
  })
})
