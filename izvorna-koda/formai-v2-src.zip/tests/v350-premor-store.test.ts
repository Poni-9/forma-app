// v3.50 PREMOR (shramba): »Ta teden …« se shrani v profil, treningi do nedelje odpadejo, ensureWeeks in »Sestavi znova«
// jih ne vrneta, »Razveljavi« vrne prejšnje dni, »Prekliči premor« sestavi preostale dni znova.
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach } from 'vitest'

// danes je sreda, 21. 10. 2026 (samo Date — fake-indexeddb rabi prave časovnike)
vi.hoisted(() => { vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date('2026-10-21T10:00:00')) })
const u = vi.hoisted(() => ({ undo: null as null | (() => unknown), msg: '' }))
vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
vi.mock('../src/ui/Confirm', () => ({ undoToast: (msg: string, fn: () => unknown) => { u.msg = msg; u.undo = fn }, useHidden: () => new Set() }))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { FRANJA_2027 } from '../src/domain/training/planner'
import { PAUSE_TITLE } from '../src/domain/training/pause'
import { todayIso } from '../src/domain/training/load'
import type { PlanDay, Profile } from '../src/domain/types'

const NOW = '2026-10-21T08:00:00.000Z'
const T = '2026-10-21', SUN = '2026-10-25'
const prof = {
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, ftpDate: '2026-09-20', maxHr: 195, restHr: 48, lthr: 184, level: 3,
  gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, hoursPerWeek: 9, hoursMode: 'own',
  strength: { on: true, equipment: 'home' }, strengthDays: 2, goal: 'dirka', event: { ...FRANJA_2027 }, races: [], cycleStart: '2026-08-31',
  onboardingDone: true, createdAt: NOW, updatedAt: NOW,
} as unknown as Profile
const inPause = (d: PlanDay) => d.date >= T && d.date <= SUN
const plan = async () => (await repo.allPlan()).sort((a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id))
const sig = (xs: PlanDay[]) => xs.map(d => `${d.id}|${d.date}|${d.kind}|${d.title}`).join(';')

beforeEach(async () => {
  vi.setSystemTime(new Date('2026-10-21T10:00:00'))
  await repo.wipeAll(); localStorage.clear(); await store.reloadAll()
  await store.updateProfile({ ...prof, weekPause: null })
  await store.ensureWeeks()
  u.undo = null
})

describe('premor do nedelje (shramba)', () => {
  it('danes je sreda (lažen čas)', () => { expect(todayIso()).toBe(T); expect(store.getState().today).toBe(T) })
  it('brez treningov: treningi do nedelje odpadejo, premor je v profilu (trajno), ensureWeeks in »Sestavi znova« jih ne vrneta', async () => {
    const before = await plan()
    expect(before.filter(inPause).some(d => d.kind !== 'pocitek')).toBe(true)
    await store.setWeekPause('vse', { reason: 'volja' })
    const p0 = await repo.loadProfile()
    expect(p0.weekPause).toMatchObject({ from: T, to: SUN, mode: 'vse', reason: 'volja' })
    const after = await plan()
    expect(after.filter(inPause).some(d => d.kind !== 'pocitek')).toBe(false)
    expect(after.filter(inPause).some(d => d.title === PAUSE_TITLE)).toBe(true)
    expect(after.filter(d => d.date > SUN).some(d => d.kind !== 'pocitek')).toBe(true)     // naslednji teden ostane
    expect(await store.ensureWeeks()).toBe(0)
    await store.rebuildFromToday()
    const again = await plan()
    expect(again.filter(inPause).some(d => d.kind !== 'pocitek')).toBe(false)
    expect(again.filter(d => d.date > SUN).some(d => d.kind !== 'pocitek')).toBe(true)
    expect(store.getState().changes[0]!.text).toMatch(/^Ta teden: premor do nedelje — treningi so umaknjeni\./)
  })
  it('brez kolesa: vožnje odpadejo, moč ostane', async () => {
    const before = await plan()
    const moc = before.filter(d => inPause(d) && d.kind === 'moc').length
    expect(moc).toBeGreaterThan(0)
    await store.setWeekPause('kolo')
    const after = await plan()
    expect(after.filter(inPause).some(d => d.kind === 'kolo' || d.kind === 'test')).toBe(false)
    expect(after.filter(d => inPause(d) && d.kind === 'moc').length).toBe(moc)
    expect(u.msg).toBe('Ta teden: premor do nedelje (brez kolesa). Vožnje so umaknjene — tudi z ure.')
  })
  it('»Razveljavi« vrne prejšnje dni in premor', async () => {
    const before = await plan()
    await store.setWeekPause('vse')
    expect(u.undo).toBeTruthy()
    await u.undo!()
    expect(sig(await plan())).toBe(sig(before))
    expect((await repo.loadProfile()).weekPause ?? null).toBeNull()
  })
  it('»Prekliči premor« isti dan: treningi do nedelje so spet v načrtu, premora ni', async () => {
    await store.setWeekPause('vse')
    await store.endWeekPause()
    const after = await plan()
    expect(after.filter(inPause).some(d => d.kind !== 'pocitek')).toBe(true)
    expect(after.filter(inPause).some(d => d.title === PAUSE_TITLE)).toBe(false)
    expect((await repo.loadProfile()).weekPause ?? null).toBeNull()
  })
  it('»Prekliči premor« naslednji dan: premor velja do včeraj (teden ne šteje kot dolg premor), od danes treningi', async () => {
    await store.setWeekPause('vse')
    vi.setSystemTime(new Date('2026-10-22T10:00:00'))
    await store.reloadAll()
    await store.endWeekPause()
    expect((await repo.loadProfile()).weekPause).toMatchObject({ from: T, to: T })
    const after = await plan()
    expect(after.filter(d => d.date >= '2026-10-22' && d.date <= SUN).some(d => d.kind !== 'pocitek')).toBe(true)
    expect(after.filter(d => d.date === T).every(d => d.kind === 'pocitek')).toBe(true)     // včeraj je ostal premor
  })
  it('»Spet zdrav« med premorom ne vrne treningov v dneve premora', async () => {
    await store.setSick(5)
    await store.setWeekPause('vse')
    await store.endSick()
    const after = await plan()
    expect(after.filter(inPause).some(d => d.kind !== 'pocitek')).toBe(false)
  })
  it('sprememba veljavnega premora: brez kolesa → še naslednji teden brez treningov', async () => {
    await store.setWeekPause('kolo')
    await store.setWeekPause('vse', { twoWeeks: true })
    const p0 = await repo.loadProfile()
    expect(p0.weekPause).toMatchObject({ from: T, to: '2026-11-01', mode: 'vse' })
    const after = await plan()
    expect(after.filter(d => d.date >= T && d.date <= '2026-11-01').some(d => d.kind !== 'pocitek')).toBe(false)
  })
})
