import { describe, it, expect } from 'vitest'
import { forecastFromHourly, summarizeHours, wxShort, WINDOWS } from '../src/domain/weather'

// Vodice 23. 9. 2026 po Open-Meteo: megla 03–08 h, jasno od 9 h, popoldne 17–18 °C — dnevna koda bi bila »megla«
const hours = (date: string, codes: number[], temps: number[]) => ({ time: codes.map((_, h) => `${date}T${String(h).padStart(2, '0')}:00`), weather_code: codes, temperature_2m: temps, precipitation_probability: codes.map(() => 0), wind_speed_10m: codes.map(() => 3) })
const codes = [0, 0, 1, 45, 45, 45, 45, 45, 45, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 1, 1, 3, 2, 3]
const temps = [7.6, 7.5, 6.1, 5.4, 4.9, 4.5, 4.4, 4.0, 5.2, 8.3, 11.2, 13.8, 15.5, 16.6, 17.3, 17.7, 17.8, 17.7, 17.0, 14.5, 12.4, 11.1, 10.4, 8.7]

describe('vreme v oknu treninga', () => {
  it('jutranja megla ne pokvari sončnega popoldneva', () => {
    const f = forecastFromHourly(hours('2026-09-23', codes, temps), { time: '2026-09-23T13:15', temperature_2m: 16.8, weather_code: 0 }, WINDOWS.popoldne!, 'popoldne')
    const d = f['2026-09-23']!
    expect(d.code).toBe(0); expect(d.tmin).toBe(17); expect(d.tmax).toBe(18)
    expect(wxShort(d)).toBe('jasno · 17–18 °C popoldne · zdaj 17 °C')
  })
  it('ko je okno mimo, veljajo naslednje 3 ure; zjutraj velja jutranje okno', () => {
    const f = forecastFromHourly(hours('2026-09-23', codes, temps), { time: '2026-09-23T19:10', temperature_2m: 14.5, weather_code: 1 }, WINDOWS.popoldne!, 'popoldne')
    expect(f['2026-09-23']!.tmin).toBe(11); expect(f['2026-09-23']!.tmax).toBe(15)
    const m = forecastFromHourly(hours('2026-09-23', codes, temps), null, WINDOWS.zjutraj!, 'dopoldne')['2026-09-23']!
    expect(m.code).toBe(45); expect(m.tmin).toBe(4)
  })
  it('dež prevlada, ko je verjetnost visoka', () => {
    const rows = [{ code: 3, t: 15, rain: 20, wind: 10 }, { code: 3, t: 15, rain: 40, wind: 12 }, { code: 61, t: 14, rain: 70, wind: 20 }]
    const d = summarizeHours('2026-09-24', rows, 'popoldne', null)
    expect(d.code).toBe(61); expect(d.rain).toBe(70); expect(d.wind).toBe(20)
    expect(wxShort(d)).toBe('rahel dež · 14–15 °C popoldne · dež 70 %')
  })
})
