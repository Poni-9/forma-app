import 'fake-indexeddb/auto'
import { describe, it, expect, vi, afterEach } from 'vitest'
import { IDBFactory } from 'fake-indexeddb'
import { toCloud, fromCloud, MAX_BYTES, HARD_MAX_BYTES, KEEP_HISTORY_DAYS } from '../src/data/sync'
import { stableStr, type SyncState } from '../src/data/merge'
import { buildWeek } from '../src/domain/training/planner'
import { defaultProfile } from '../src/data/repo'
import { addDays, weekStartIso, todayIso } from '../src/domain/training/load'

/**
 * Regresija (pregled 25. 9.): velikost dokumenta v oblaku in pisanje v krogu.
 *  - zastavica »trimmed« je povzročala, da združeno ≠ oblak → dve veliki napravi sta brez sprememb pisali znova in znova,
 *  - poslušalec je snapTs premaknil nazaj → naprava je zamudila zapis druge naprave (bližnjica),
 *  - načrt in jutranji vnosi so rasli brez meje (po 2 letih nad 950 kB → sinhronizacija odpove).
 */
type Doc = Record<string, unknown>
const cloud: Record<string, Doc> = {}
let writes = 0, txs = 0
const live = { on: false, subs: new Map<string, Set<(s: unknown) => void>>() }
const snapOf = (path: string) => ({ metadata: { fromCache: false, hasPendingWrites: false }, exists: () => !!cloud[path], get: (fp: string) => fp.split('.').reduce<unknown>((o, k) => (o as Record<string, unknown> | undefined)?.[k], cloud[path]) })
const notify = (path: string) => setTimeout(() => { for (const f of live.subs.get(path) || []) f(snapOf(path)) }, 0)
const fakeCore = {
  fs: {},
  fsMod: {
    doc: (_fs: unknown, col: string, id: string) => ({ path: `${col}/${id}` }),
    get onSnapshot() {
      if (!live.on) return undefined
      return (ref: { path: string }, _o: unknown, next: (s: unknown) => void) => {
        const set = live.subs.get(ref.path) || new Set(); set.add(next); live.subs.set(ref.path, set)
        setTimeout(() => next(snapOf(ref.path)), 0)
        return () => { set.delete(next) }
      }
    },
    runTransaction: async (_fs: unknown, fn: (tx: unknown) => Promise<void>) => {
      txs++
      let pending: { path: string; data: Doc; opts: { mergeFields?: string[] } } | null = null
      const tx = {
        get: async (ref: { path: string }) => ({ exists: () => !!cloud[ref.path], data: () => JSON.parse(JSON.stringify(cloud[ref.path])) }),
        set: (ref: { path: string }, data: Doc, opts: { mergeFields?: string[] }) => { pending = { path: ref.path, data, opts } },
      }
      await fn(tx)
      const p = pending as unknown as { path: string; data: Doc; opts: { mergeFields?: string[] } } | null
      if (p) {
        writes++
        const next: Doc = { ...(cloud[p.path] || {}) }
        for (const f of p.opts?.mergeFields || Object.keys(p.data)) next[f] = JSON.parse(JSON.stringify(p.data[f]))
        cloud[p.path] = next
        notify(p.path)
      }
    },
  },
}
async function device() {
  vi.resetModules()
  ;(globalThis as Record<string, unknown>).indexedDB = new IDBFactory()
  vi.doMock('../src/data/firebase', () => ({ core: async () => fakeCore }))
  const sync = await import('../src/data/sync')
  const repo = await import('../src/data/repo')
  const db = await import('../src/data/db')
  await db.db()
  return { sync, repo, db }
}
const tick = (ms = 30) => new Promise(r => setTimeout(r, ms))
afterEach(() => { for (const k of Object.keys(cloud)) delete cloud[k]; live.on = false; live.subs.clear() })

// ~1,9 kB na aktivnost (uvoz iz intervals.icu s conami) → 700 aktivnosti je nad MAX_BYTES
const bigActs = (n: number) => Array.from({ length: n }, (_, i) => {
  const d = new Date(Date.UTC(2025, 0, 1) + i * 86400_000 * 0.8)
  return { id: 'a' + i, source: 'intervals' as const, originHint: 'GARMIN', deviceName: 'Garmin Forerunner 255', sport: 'kolo' as const, date: d.toISOString().slice(0, 10), start: d.toISOString(), name: 'Jutranja vožnja po dolini ' + i,
    distKm: 55.3, durationMin: 123, elapsedMin: 131, elevM: 640, avgHr: 141, maxHr: 176, avgPower: null, speedKmh: 27, kcal: 1400, tss: 95, polyline: 'SLED' + i,
    hrZoneSec: [1200, 2400, 1800, 600, 120, 0, 0], hrZoneTop: [130, 150, 160, 170, 180, 190, 200], deviceWatts: false, trainer: false,
    aiEligible: true, geoRetain: true, expiresAt: null, ext: { intervalsId: 'i' + (100000 + i) }, createdAt: d.toISOString(), updatedAt: d.toISOString(), notes: 'x'.repeat(600) }
})
const utf8 = (x: unknown) => new TextEncoder().encode(JSON.stringify(x)).length

describe('brez pisanja v krogu (velika zgodovina, skrajšana kopija v oblaku)', () => {
  it('toCloud(združeno) je enak toCloud(iz oblaka) — brez zastavice trimmed, brez sledi in sličic', () => {
    const st: SyncState = { profile: null, settings: null, activities: bigActs(700) as never, plan: [], meals: [], checkins: [], tomb: {} }
    const out = toCloud(st, 5)
    expect(out.bytes).toBeLessThanOrEqual(MAX_BYTES)
    expect('trimmed' in out.payload).toBe(false)
    expect(JSON.stringify(out.payload)).not.toMatch(/SLED|"polyline"/)
    const back = fromCloud(JSON.parse(JSON.stringify(out.payload)))
    expect(stableStr(toCloud(back, 0).payload)).toBe(stableStr(toCloud(st, 0).payload))
  })

  it('dve veliki napravi brez sprememb izmenično usklajujeta → 0 zapisov', async () => {
    const A = await device()
    for (const a of bigActs(700)) await (await A.db.db()).put('activities', a as never)
    await A.sync.touch(); A.sync.startSync('u1'); await A.sync.syncNow()
    const B = await device()
    for (const a of bigActs(700)) await (await B.db.db()).put('activities', a as never)
    await B.sync.touch(); B.sync.startSync('u1'); await B.sync.syncNow()
    await A.sync.syncNow(); await B.sync.syncNow()
    const w0 = writes
    for (let i = 0; i < 4; i++) { await A.sync.syncNow(); await B.sync.syncNow() }
    expect(writes - w0).toBe(0)
    // na napravah ostane vse (tudi sledi)
    expect((await A.repo.allActivities()).length).toBe(700)
    expect((await A.repo.allActivities()).every(a => a.polyline)).toBe(true)
    A.sync.stopSync(); B.sync.stopSync()
  }, 60000)

  it('s poslušalcem: mirovanje brez zapisov, zaostala naprava ujame zadnji zapis (snapTs ne gre nazaj)', async () => {
    live.on = true
    const A = await device()
    for (const a of bigActs(700)) await (await A.db.db()).put('activities', a as never)
    await A.sync.touch(); A.sync.startSync('u1'); await A.sync.syncNow(); await tick(50)
    const B = await device()
    for (const a of bigActs(700)) await (await B.db.db()).put('activities', a as never)
    await B.sync.touch(); B.sync.startSync('u1'); await B.sync.syncNow(); await tick(300)
    const w0 = writes
    await tick(600)
    expect(writes - w0).toBe(0)
    const ts = (cloud['formaSync/u1'] as { v2: { _ts: number } }).v2._ts
    expect(await A.db.getKV<number>('sync2.remoteTs')).toBe(ts)
    expect(await B.db.getKV<number>('sync2.remoteTs')).toBe(ts)
    // »uskladi zdaj« gre mimo bližnjice (prebere oblak), a ne piše
    const t0 = txs
    await B.sync.syncNow()
    expect(txs).toBe(t0 + 1)
    expect(writes - w0).toBe(0)
    A.sync.stopSync(); B.sync.stopSync()
  }, 20000)
})

describe('rast dokumenta v oblaku', () => {
  it('načrt in jutranji vnosi: v oblaku samo zadnjih 400 dni; 3 leta zgodovine ostanejo pod mejo', () => {
    const p = { ...defaultProfile(), onboardingDone: true, sex: 'm' as const, age: 30, weightKg: 75, heightCm: 180, ftp: 250, hoursPerWeek: 8, event: { name: 'Maraton Franja', date: '2027-06-13', distanceKm: 156 }, cycleStart: '2025-09-01', strength: { on: true, equipment: 'home' as const }, strengthDays: 2 }
    const plan = []
    let ws = weekStartIso(addDays(todayIso(), -3 * 364))
    for (let w = 0; w < 3 * 52 + 3; w++) { plan.push(...buildWeek({ profile: p, activities: [], weekStart: ws, notBefore: ws })); ws = addDays(ws, 7) }
    const checkins = Array.from({ length: 3 * 365 }, (_, i) => ({ date: addDays(todayIso(), -i), soreness: 2 as const, sleepH: 7, mood: 4 as const, weightKg: 74.3, updatedAt: new Date().toISOString() }))
    const acts = bigActs(400).map((a, i) => ({ ...a, date: addDays(todayIso(), -i * 2) }))
    const meals = Array.from({ length: 120 * 5 }, (_, i) => ({ id: 'm' + i, date: addDays(todayIso(), -Math.floor(i / 5)), time: '12:30', slot: 'kosilo' as const, name: 'Piščančji file z rižem in solato', grams: 450, kcal: 650, proteinG: 45, carbsG: 70, fatG: 18, confidence: 'srednja' as const, source: 'photo' as const, thumb: 'SLIKA', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }))
    const st: SyncState = { profile: p, settings: { lang: 'sl' }, activities: acts as never, plan, meals, checkins, tomb: {} }
    const out = toCloud(st, 1)
    const cut = addDays(todayIso(), -KEEP_HISTORY_DAYS)
    expect(out.payload.plan.every(d => d.date >= cut)).toBe(true)
    expect(out.payload.checkins.every(c => c.date >= cut)).toBe(true)
    expect(out.payload.plan.length).toBeLessThan(plan.length)
    expect(utf8(out.payload)).toBe(out.bytes)
    expect(out.bytes).toBeLessThanOrEqual(MAX_BYTES)
    expect(out.bytes).toBeLessThan(HARD_MAX_BYTES)
    expect(JSON.stringify(out.payload)).not.toMatch(/SLIKA/)
  })
})
