import { describe, it, expect } from 'vitest'
import { dayMealPlan, adjustToEaten, rideFuel } from '../src/domain/nutrition/dayplan'
import { DISHES, LF_DISHES, dayRecipes, dishesFor, exclusionsOf, fitDish, whyRecipe, dishChoices } from '../src/domain/nutrition/recipes'
import { raceSoon, lowFiberDays } from '../src/domain/nutrition/race'
import { dayMealsOf, gotOf, nextSlotOf } from '../src/domain/nutrition/daymeals'
import { dailyTarget, noDeficitDay, targetParts, type DailyTarget } from '../src/domain/nutrition/energy'
import { FRANJA_2027 } from '../src/domain/training/planner'
import type { MealEntry, PlanDay, Profile } from '../src/domain/types'

const now = new Date().toISOString()
const P = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 180, weightKg: 80, restHr: 55, maxHr: 200, lthr: 184, ftp: 240, ftpDate: '2026-09-20',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, hoursPerWeek: 14, baseHours: null,
  strength: { on: false, equipment: 'home', phases: null }, strengthDays: 0, goal: 'dirka', deficit: 300, neat: 1.4,
  event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', onboardingDone: true, trainTime: 'popoldne', createdAt: now, updatedAt: now,
  races: [], ...o,
} as Profile)
const ride = (min: number, o: Record<string, unknown> = {}) => ({ kind: 'kolo' as const, durationMin: min, zone: 'Z2', role: 'dolga' as const, title: 'Dolga Z2', ...o })
const planDay = (date: string, min: number, o: Partial<PlanDay> = {}): PlanDay => ({ id: 'r' + date, date, kind: 'kolo', title: 'Dolga Z2', desc: '', durationMin: min, zone: 'Z2', role: 'dolga', source: 'rules', createdAt: now, updatedAt: now, ...o })
const meal = (slot: MealEntry['slot'], kcal: number, o: Partial<MealEntry> = {}): MealEntry => ({ id: slot + kcal + (o.time || ''), date: '2026-10-17', slot, name: slot, kcal, source: 'manual', createdAt: now, ...o })
const T = { kcal: 3124, proteinG: 142, carbsG: 443, deficit: 300 }
const PP = { weightKg: 80, trainTime: 'popoldne' as const }
const ctx = (prefs = '') => ({ deficit: true, keepMuscle: true, training: true, prefs })
// kratka tekma (kronometer 20 km ≈ 30 min), srednja (80 km ≈ 140 min), dolga (Franja 310 min)
const kron = { id: 'k', name: 'Kronometer Vodice', date: '2026-10-23', distanceKm: 20, type: 'kronometer' as const, prio: 'B' as const }
const mid = { id: 'm', name: 'Srednja', date: '2026-11-08', distanceKm: 80, prio: 'C' as const }
const HIGH_FIBER = ['kruh', 'sadje', 'oves', 'fizol', 'leca', 'zelenjava', 'solata', 'oreski', 'jabolko', 'cebula']

describe('v3.48 N1 — pred tekmo: malo vlaknin po željah, s pravimi jedmi', () => {
  const lfDay = () => dayMealPlan(PP, T, null, { race: raceSoon(P(), '2027-06-11') })
  it('C01: dnevi z malo vlakninami upoštevajo želje (vegetarijanec brez laktoze, vegan)', () => {
    const dp = lfDay()
    expect(dp.slots.every(s => s.lf)).toBe(true)
    for (let d = 1; d <= 10; d++) {
      const vl = dayRecipes(dp, `2027-06-${String(d).padStart(2, '0')}`, { ...ctx('vegetarijansko, brez laktoze'), deficit: false })
      expect(Object.keys(vl)).toEqual(dp.slots.map(s => s.key))
      for (const r of Object.values(vl)) for (const i of r.ingredients) expect(['piscanec', 'puran', 'tuna', 'losos', 'jogurt', 'skuta', 'mleko', 'kefir', 'sir'], `${r.name}: ${i.key}`).not.toContain(i.key)
      const vg = dayRecipes(dp, `2027-06-${String(d).padStart(2, '0')}`, { ...ctx('vegan'), deficit: false })
      for (const r of Object.values(vg)) for (const i of r.ingredients) expect(['piscanec', 'puran', 'tuna', 'losos', 'jogurt', 'skuta', 'mleko', 'jajce', 'sir'], `${r.name}: ${i.key}`).not.toContain(i.key)
    }
    // za vsak obrok je jed tudi za najstrožje želje
    for (const tpl of ['zajtrk', 'kosilo', 'obnova', 'vecerja', 'malica', 'pred']) expect(dishesFor(tpl, 'vegan, brez glutena, brez soje', LF_DISHES).length, tpl).toBeGreaterThan(0)
  })
  it('C02: noben dodatek ali sestavina ni polnozrnat kruh, sadje z lupino, zelenjava, stročnice ali oreški', () => {
    const dp = lfDay()
    for (const prefs of ['', 'vegetarijansko', 'vegan', 'brez laktoze', 'brez glutena'])
      for (let d = 1; d <= 10; d++)
        for (const r of Object.values(dayRecipes(dp, `2027-06-${String(d).padStart(2, '0')}`, { ...ctx(prefs), deficit: false })))
          for (const i of r.ingredients) expect(HIGH_FIBER, `${prefs}: ${r.name} ${i.text}`).not.toContain(i.key)
    for (const d of LF_DISHES) for (const [k] of d.items) expect(HIGH_FIBER, d.id).not.toContain(k)
  })
  it('C13/B11: recepti imajo pravo ime jedi in svoje korake (ne štirikrat »Malo vlaknin pred tekmo«); »drug predlog« deluje', () => {
    const dp = lfDay()
    const r = dayRecipes(dp, '2027-06-11', { ...ctx(), deficit: false })
    const names = Object.values(r).map(x => x.name)
    expect(new Set(names).size).toBe(names.length)
    for (const x of Object.values(r)) { expect(x.name).not.toMatch(/Malo vlaknin/); expect(x.steps.join(' ')).not.toMatch(/po navadni pripravi/) }
    const kos = dp.slots.find(s => s.key === 'kosilo')!
    expect(dishChoices(kos, { ...ctx(), deficit: false })).toBeGreaterThan(1)
    const alt = dayRecipes(dp, '2027-06-11', { ...ctx(), deficit: false, alt: { kosilo: 1 } })
    expect(alt.kosilo!.name).not.toBe(r.kosilo!.name)
  })
})

describe('v3.48 N1 — koliko dni malo vlaknin po dolžini tekme', () => {
  it('C11: pod 90 min samo na dan tekme, 90–150 min dan prej, od 150 min 2 dni prej', () => {
    const p = P({ races: [kron, mid] })
    expect(raceSoon(p, '2026-10-21')).toBeNull()
    expect(raceSoon(p, '2026-10-22')).toBeNull()
    expect(raceSoon(p, '2026-10-23')?.inDays).toBe(0)
    expect(raceSoon(p, '2026-11-06')).toBeNull()
    expect(raceSoon(p, '2026-11-07')?.inDays).toBe(1)
    expect(raceSoon(p, '2027-06-11')?.inDays).toBe(2)
    // dan pred kratko tekmo: obroki normalni (kot »Dan prej normalno« v fueling)
    const dp = dayMealPlan(PP, T, null, { race: raceSoon(p, '2026-10-22') })
    expect(dp.slots.every(s => !s.lf)).toBe(true)
    expect(lowFiberDays(p, '2026-10-19', '2026-10-25').map(x => x.date)).toEqual(['2026-10-23'])
    expect(lowFiberDays(p, '2026-11-02', '2026-11-08').map(x => x.date)).toEqual(['2026-11-07', '2026-11-08'])
    // dan pred tekmo in dan tekme ostaneta brez deficita tudi pri kratki tekmi
    expect(noDeficitDay(p, '2026-10-22')).toBe('dan pred tekmo brez deficita')
    expect(noDeficitDay(p, '2026-10-23')).toBe('dan tekme brez deficita')
  })
  it('C12: na dan tekme je obrok po tekmi normalen — tudi pri kronometru pod 45 min in brez tekme v planu', () => {
    const rs = raceSoon(P({ races: [kron] }), '2026-10-23')!
    const tt = dayMealPlan(PP, T, ride(30, { role: 'dirka', zone: 'dirka', title: 'Kronometer' }), { race: rs })
    const i = tt.slots.findIndex(s => s.key === 'obnova')
    expect(i).toBeGreaterThan(0)
    expect(tt.slots.slice(0, i).every(s => s.lf)).toBe(true)
    expect(tt.slots.slice(i).every(s => !s.lf)).toBe(true)
    const none = dayMealPlan(PP, T, null, { race: rs })
    expect(none.slots.at(-1)!.lf).toBeUndefined()
    expect(none.slots[0]!.lf).toBe(true)
  })
})

describe('v3.48 N1 — obroki čez dan', () => {
  const dp = dayMealPlan(PP, T, ride(105))
  it('C04: vpis v terminu, ki ga načrt nima (malica na dan vožnje), prilagodi preostale obroke', () => {
    expect(dp.slots.some(s => s.slot === 'malica')).toBe(false)
    const a = adjustToEaten(dp, [meal('malica', 650, { time: '10:30' })], 3124)
    expect(a.adjusted).toBe(true)
    const left = a.slots.reduce((s, x) => s + x.kcal, 0) + (a.onBike?.kcal || 0)
    expect(Math.abs(left - (3124 - 650))).toBeLessThanOrEqual(40)
  })
  it('C05/A18: »naslednji obrok« gleda uro — zvečer ni zajtrk; po kosilu ni zajtrk; dopoldanska malica ne preskoči kosila', () => {
    expect(nextSlotOf(dp, [], 18)!.key).not.toBe('zajtrk')
    expect(nextSlotOf(dp, [], 18)!.key).toBe('obnova')
    expect(nextSlotOf(dp, [], '08:15')!.key).toBe('zajtrk')
    const k = dp.slots.find(s => s.key === 'kosilo')!
    expect(nextSlotOf(dp, [meal('kosilo', k.kcal)], '19:00')!.key).toBe('obnova')
    expect(nextSlotOf(dp, [meal('kosilo', k.kcal)])!.key).toBe('obnova')
    // dan brez vožnje: malica ob 10:30 → naslednje je kosilo (ne malica, ne zajtrk)
    const rest = dayMealPlan(PP, { ...T, kcal: 2400 }, null)
    const ad = adjustToEaten(rest, [meal('malica', 200, { time: '10:30' })], 2400)
    expect(nextSlotOf(ad, [meal('malica', 200, { time: '10:30' })], '11:30')!.key).toBe('kosilo')
  })
  it('C06: nad ciljem obrok po vožnji ne pade na 0 (obnova), »ali nič« samo pri prigrizku', () => {
    const big = [meal('zajtrk', 1800), meal('kosilo', 1900)]
    const a = adjustToEaten(dp, big, 3124, { rideDone: false, weightKg: 80 })
    const o = a.slots.find(s => s.key === 'obnova')!
    expect(o.kcal).toBeGreaterThanOrEqual(250)
    expect(o.kcal).toBeGreaterThanOrEqual(400)   // ~0,3 g/kg beljakovin + 1 g/kg OH pri 80 kg
    expect(adjustToEaten(dp, big, 3124).slots.find(s => s.key === 'obnova')!.kcal).toBeGreaterThanOrEqual(250)
    const z = a.slots.find(s => s.key === 'malica')!   // »Zvečer«
    expect(z.kcal).toBeLessThan(150); expect(z.example).toMatch(/ali nič/)
    // glavni obrok nikoli »ali nič«
    const rest = dayMealPlan(PP, { ...T, kcal: 2400 }, null)
    const v = adjustToEaten(rest, [meal('zajtrk', 1500), meal('kosilo', 1400)], 2400).slots.find(s => s.key === 'vecerja')!
    expect(v.example).not.toMatch(/ali nič/)
  })
  it('C15: pretekli dan — dva obroka istega termina ne štejeta istega dvakrat', () => {
    const p = P({ trainTime: 'zjutraj' })
    const day = '2026-10-16', today = '2026-10-17'
    const plan = [planDay(day, 105, { done: { at: now } })]
    const target = dailyTarget(p, [], plan, day, { today, hour: 9 })!
    const meals = [meal('zajtrk', 300, { date: day, time: '06:30' }), meal('zajtrk', 900, { date: day, time: '10:00' })]
    const dm = dayMealsOf({ p, target, plan, activities: [], meals, recentMeals: [], weather: null, day, today })
    expect(dm.dp.slots.filter(s => s.slot === 'zajtrk').length).toBe(2)
    expect(dm.dp.slots.reduce((s, sl) => s + gotOf(sl, meals), 0)).toBe(1200)
  })
  it('C16: pozno zvečer brez vožnje — načrt brez goriva na kolesu in brez »po vožnji«', () => {
    const p = P(), day = '2026-10-17'
    const plan = [planDay(day, 105)]
    const target = dailyTarget(p, [], plan, day, { today: day, hour: 22 })!
    expect(target.plannedDropped).toBeGreaterThan(0)
    const dm = dayMealsOf({ p, target, plan, activities: [], meals: [], recentMeals: [], weather: null, day, today: day })
    expect(dm.dp.onBike).toBeNull()
    expect(dm.dp.slots.some(s => s.key === 'obnova')).toBe(false)
    expect(Math.abs(dm.dp.slots.reduce((s, x) => s + x.kcal, 0) - target.kcal)).toBeLessThanOrEqual(40)
    // ob 15h vožnja še pride: načrt z vožnjo
    const t15 = dailyTarget(p, [], plan, day, { today: day, hour: 15 })!
    expect(dayMealsOf({ p, target: t15, plan, activities: [], meals: [], recentMeals: [], weather: null, day, today: day }).dp.onBike).not.toBeNull()
  })
})

describe('v3.48 N1 — recepti po željah in pred vožnjo', () => {
  it('C08: za vegana in brez laktoze ne »jogurt ali skuto«; glavni obrok dobi nemlečen beljakovinski dodatek', () => {
    const sl = { key: 'malica', proteinG: 31 }
    for (const prefs of ['vegan', 'brez laktoze']) {
      const w = whyRecipe({ p: 19, c: 60, f: 10 }, sl, { deficit: false, keepMuscle: false, training: true, prefs })
      expect(w).not.toMatch(/jogurt|skut/); expect(w).toMatch(/tofu/)
    }
    expect(whyRecipe({ p: 19, c: 60, f: 10, ingredients: [{ key: 'fizol', qty: 200, text: '' }] }, sl, { deficit: false, keepMuscle: false, training: true, prefs: 'vegan' })).not.toMatch(/čičeriko/)
    expect(whyRecipe({ p: 19, c: 60, f: 10 }, sl, { deficit: false, keepMuscle: false, training: true })).toMatch(/jogurt ali skuto/)
    const r = fitDish(DISHES.find(d => d.id === 'cicerika')!, 1100, 70, { deficit: false, prefs: 'vegan' }, 150)
    expect(r.ingredients.filter(i => i.side).map(i => i.key)).toContain('tofu')
  })
  it('C09: kosilo pred vožnjo — največ 150 g zelenjave, brez stročnic, dodatek brez sadja z lupino in polnozrnatega kruha', () => {
    const dp = dayMealPlan(PP, T, ride(105))
    const pre = dp.slots.find(s => s.beforeRide)!
    for (const prefs of ['', 'vegetarijansko', 'vegan', 'vegetarijansko, brez laktoze'])
      for (let d = 1; d <= 14; d++) {
        const r = dayRecipes(dp, `2026-11-${String(d).padStart(2, '0')}`, ctx(prefs))[pre.key]!
        const veg = r.ingredients.filter(i => i.key === 'zelenjava' || i.key === 'solata' || i.key === 'sadje').reduce((s, i) => s + i.qty, 0)
        expect(veg, `${prefs} ${r.name}`).toBeLessThanOrEqual(150)
        expect(r.ingredients.some(i => i.key === 'fizol' || i.key === 'leca'), `${prefs} ${r.name}`).toBe(false)
        expect(r.ingredients.filter(i => i.side).some(i => i.key === 'sadje' || i.key === 'kruh'), `${prefs} ${r.name}`).toBe(false)
      }
  })
  it('C10: vegetarijanec in vegan — po vožnji vsaj 3 različne jedi v 14 dneh, riž ne dvakrat na dan', () => {
    const dp = dayMealPlan(PP, T, ride(105))
    for (const prefs of ['vegetarijansko', 'vegan']) {
      const after = new Set<string>()
      for (let d = 2; d <= 15; d++) {
        const r = dayRecipes(dp, `2026-11-${String(d).padStart(2, '0')}`, ctx(prefs))
        after.add(r.obnova!.name)
        expect(Object.values(r).filter(x => x.ingredients.some(i => i.key === 'riz' && !i.side)).length, `${prefs} 11-${d}`).toBeLessThanOrEqual(1)
      }
      expect(after.size, prefs).toBeGreaterThanOrEqual(3)
    }
  })
  it('C30: »ne jem svinjine« ne izloči piščanca in purana', () => {
    expect(exclusionsOf('ne jem svinjine').contains).not.toContain('meso')
    expect(dishesFor('kosilo', 'ne jem svinjine').map(d => d.id)).toEqual(expect.arrayContaining(['pisc-riz', 'puran-kr']))
    expect(exclusionsOf('ne jem mesa').contains).toContain('meso')
    expect(exclusionsOf('ne maram piščanca').contains).toContain('meso')
  })
  it('C37: recepti v tikanju (ne »pražite«, »pečite«)', () => {
    for (const d of [...DISHES, ...(LF_DISHES || [])]) for (const s of d.steps) expect(s, d.id).not.toMatch(/\b\p{L}+(?:ite|jte)\b/u)
  })
  it('C28: recepti se ob premiku ure (DST) ne ponovijo', () => {
    const tz = process.env.TZ
    process.env.TZ = 'Europe/Ljubljana'
    try {
      const dp = dayMealPlan(PP, T, ride(105))
      const a = dayRecipes(dp, '2027-03-27', ctx()), b = dayRecipes(dp, '2027-03-28', ctx())
      expect(Object.keys(a).some(k => a[k]!.dish !== b[k]!.dish)).toBe(true)
    } finally { if (tz == null) delete process.env.TZ; else process.env.TZ = tz }
  })
})

describe('v3.48 N1 — gorivo in besedila', () => {
  it('C14: opomnik pitja po dejanski potrebi (vročina več), pravilni ml; »⅓ bidona« le pri ~250 ml', () => {
    const drink = (tempC: number) => rideFuel(ride(180), null, { tempC })!.cues.filter(c => !c.solid)
    const ml = (t: string) => +(/~(\d+) ml/.exec(t)?.[1] || 0)
    const hot = drink(30), cool = drink(15)
    expect(hot.length).toBeGreaterThan(0); expect(cool.length).toBeGreaterThan(0)
    expect(ml(hot[0]!.text)).toBeGreaterThan(ml(cool[0]!.text))
    expect(ml(hot[0]!.text)).toBe(300)   // ~850 ml na uro → ~300 ml na 20 min
    expect(ml(cool[0]!.text)).toBe(150)
    for (const c of [...hot, ...cool]) expect(c.text).not.toMatch(/⅓ bidona/)
    expect(rideFuel(ride(180), null, { tempC: 25 })!.cues.find(c => !c.solid)!.text).toMatch(/⅓ bidona izotonika \(~250 ml, ~13 g OH\)/)
  })
  it('C26: opomniki goriva v tožilniku (»Pojej banano«), časovnica v imenovalniku', () => {
    const b = rideFuel(ride(105), ['banana'])!
    expect(b.cues[0]!.text).toMatch(/^Pojej banano /); expect(b.cues[0]!.short).toBe('banana')
    const f = rideFuel(ride(180), ['iso_domaci', 'frutabela'], { tempC: 17 })!
    expect(f.cues.find(c => c.solid)!.text).toMatch(/Pojej Frutabelo/)
  })
  it('C29: nasvet o deficitu samo, ko je deficit', () => {
    expect(dayMealPlan(PP, { ...T, deficit: 0 }, ride(300)).tip).not.toMatch(/Deficit|Primanjkljaj/)
    expect(dayMealPlan(PP, { ...T, deficit: 300 }, ride(300)).tip).toMatch(/Deficit ustvariš/)
    expect(dayMealPlan(PP, { ...T, deficit: 0 }, null, { workout: true }).tip).not.toMatch(/Primanjkljaj/)
  })
  it('C41: »popravim, ko vožnja pride z Garmina« samo z Garminom', () => {
    const t = { kcal: 3300, maintenance: 2541, burn: 0, plannedBurn: 1010, plannedWas: 0, floor: 1815, proteinG: 158, carbsG: 450, fatG: 90, clampedToFloor: false, minor: false, deficit: 0, deficitNote: null } as DailyTarget
    expect(targetParts(t, {}, { garmin: false })).not.toMatch(/Garmin/)
    expect(targetParts(t, {})).not.toMatch(/Garmin/)
    expect(targetParts(t, {}, { garmin: true })).toMatch(/pride z Garmina/)
  })
  it('C42: odšteto gorivo na kolesu = to, kar res neseš', () => {
    for (const kit of [['banana'], ['iso_domaci', 'frutabela', 'banana', 'gel'], null]) {
      const rf = rideFuel(ride(105), kit)!
      const dp = dayMealPlan({ ...PP, fuelKit: kit }, T, ride(105))
      expect(dp.onBike!.carbs).toBe(rf.carriedCarbs)
      expect(dp.onBike!.kcal).toBe(Math.round(rf.plan.reduce((s, x) => s + x.n * x.kcal, 0)))
      expect(Math.abs(dp.slots.reduce((s, x) => s + x.kcal, 0) + dp.onBike!.kcal - T.kcal)).toBeLessThanOrEqual(40)
    }
  })
})

