// v3.51 POPRAVKI51-TR — popravki po pregledu REVIEW-TR (R1–R3, R5–R15): pregled tedna, zdravje v pogajanju, premor in
// bolezen v klepetu, ločena pot za premor brez navodil o besedah, cikel brez cilja, tekme v pozivih, tekma po meri, vaje.
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach } from 'vitest'
import { readFileSync } from 'node:fs'
import { createHash } from 'node:crypto'

const sent: string[] = []
vi.mock('@/domain/ai/client', async (orig) => {
  const m = await orig<typeof import('@/domain/ai/client')>()
  return {
    ...m,
    askText: vi.fn(async (parts: { text?: string }[]) => { sent.push(parts.map(p => p.text || '').join('\n')); return 'Razumem.' }),
    askJson: vi.fn(async (parts: { text?: string }[]) => { sent.push(parts.map(p => p.text || '').join('\n')); return {} }),
  }
})
vi.mock('@/data/db', async (orig) => { const m = await orig<typeof import('@/data/db')>(); return { ...m, getKV: vi.fn(async () => null), setKV: vi.fn(async () => {}) } })

import { localReview, lastWeekSummary, type LocalCoachCtx } from '@/domain/coach/local'
import { standInFor } from '@/domain/training/standin'
import { ruleAdjust, adjustNote } from '@/domain/focus/rules'
import { normalizeFocus, profileFromFocus } from '@/domain/focus/model'
import { healthOf, healthSaid, HEALTH_SAY } from '@/domain/training/exercises'
import { pauseIntent, pauseEndIntent, sickIntent, ownDay, planKey, pauseAiLine } from '@/domain/training/pause'
import { aiContext, coachDailyPrompt, weeklyReviewPrompt, NO_RACE_MARK, raceAhead } from '@/domain/ai/prompts'
import { personalContext } from '@/domain/ai/personal'
import { chat, weeklyReview, monthReview, athleteProfile } from '@/domain/ai/actions'
import * as prompts from '@/domain/ai/prompts'
import { buildWeek, weekContext, NEW_COUNT_FROM } from '@/domain/training/planner'
import { buildFocusWeek } from '@/domain/training/focusPlan'
import { exercisesIn } from '@/domain/coach/exmention'
import { addDays, weekStartIso } from '@/domain/training/load'
import type { Activity, PlanDay, Profile } from '@/domain/types'

const TODAY = '2026-10-23'   // petek
const NOW = `${TODAY}T08:00:00.000Z`
const ws = weekStartIso(TODAY)
const prof = {
  name: 'B', sex: 'm', age: 30, heightCm: 180, weightKg: 75, ftp: 250, ftpDate: '2026-09-20', maxHr: 195, restHr: 48, lthr: 175, level: 3,
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true }, hoursPerWeek: 8, hoursMode: 'own',
  strength: { on: false, equipment: 'none' }, strengthDays: 0, goal: 'dirka', deficit: 300, neat: 1.4, proteinGkg: 1.8,
  event: null, races: [], cycleStart: '2026-08-31', onboardingDone: true, aiConsentAt: NOW, aiConsentV: 3, createdAt: NOW, updatedAt: NOW,
} as unknown as Profile
const day = (id: string, date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id, date, kind: 'kolo', title: 'Z2 vzdržljivost', desc: '', durationMin: 90, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })
const lctx = (plan: PlanDay[], acts: Activity[], today = TODAY): LocalCoachCtx => ({ profile: prof, plan, activities: acts, checkins: [], checkinToday: null, wellness: null, wellnessOn: false, mealsToday: [], recentMeals: [], weather: null, today })
const strava = { id: 's1', source: 'strava', originHint: 'strava', sport: 'kolo', date: addDays(TODAY, -2), name: 'Ride', durationMin: 120, aiEligible: false, geoRetain: false, createdAt: NOW, updatedAt: NOW } as unknown as Activity

const txt = (parts: readonly object[]): string => parts.map(p => ('text' in p ? String(p.text) : '')).join('\n')

beforeEach(() => { sent.length = 0 })

describe('R1 — pregled tedna brez AI: ročna kljukica z zapisom iz načrta se šteje enkrat, z minutami »Krajše«', () => {
  const d1 = day('d1', addDays(ws, 1), { done: { at: NOW } })
  const d2 = day('d2', addDays(ws, 3), { done: { at: NOW, min: 45 } })
  const plan = [d1, d2, day('d3', addDays(ws, 5))]
  const acts = [standInFor(d1, prof, null, NOW)!, standInFor(d2, prof, null, NOW)!]
  it('Pregled tedna: 90 + 45 = 2 h 15 min (prej 5 h 15 min)', () => {
    expect(acts.map(a => a.planDayId)).toEqual(['d1', 'd2'])
    const line = localReview(lctx(plan, acts)).split('\n').find(l => /Opravljeno/.test(l))!
    expect(line).toMatch(/na kolesu 2 h 15 min od 4 h 30 min/)
  })
  it('kljukica brez zapisa iz načrta šteje dejanske minute (done.min), ne načrtovanih', () => {
    const line = localReview(lctx(plan, [])).split('\n').find(l => /Opravljeno/.test(l))!
    expect(line).toMatch(/na kolesu 2 h 15 min od/)
  })
  it('ponedeljek »Pretekli teden« enako', () => {
    const r = lastWeekSummary(plan, acts, addDays(ws, 7))!
    expect(r.lines[0]).toMatch(/na kolesu 2 h 15 min od 4 h 30 min/)
  })
})

describe('R2, R3 — zdravje v pogajanju', () => {
  const fit = normalizeFocus({ wish: 'Rad bi bil močnejši.', sports: ['fitnes'], aims: ['moc'], level: 2, offDays: [],
    sessions: [{ type: 'fitnes', part: 'celo', min: 50 }, { type: 'tek', cardio: 'intervali', min: 30 }] }, { by: 'pravila', now: NOW })!
  const run = normalizeFocus({ wish: 'Rad bi bil hitrejši tekač.', sports: ['tek'], aims: ['kondicija'], level: 2, offDays: [],
    sessions: [{ type: 'tek', cardio: 'intervali', min: 40 }, { type: 'tek', cardio: 'lahko', min: 40 }, { type: 'tek', cardio: 'dolgo', min: 60 }] }, { by: 'pravila', now: NOW })!
  it('»Imam težave s srcem.«: oznaka, ki jo prepoznajo varovalke, opombe in AI vrstica ZDRAVJE', () => {
    const n = ruleAdjust(fit, 'Imam težave s srcem.', 40)!
    expect(healthOf(n.limits)).toEqual(['srce'])
    expect(n.notes.join(' ')).toContain('Pišeš, da imaš težave s srcem:')
    expect(n.notes.join(' ')).not.toContain('Pišeš, da :')
    expect(adjustNote(fit, n)).toMatch(/^Prav — ker imaš težave s srcem, je teden brez hitrih intervalov/)
    // varovalka v načrtu: brez intervalov
    expect(n.sessions.some(s => s.cardio === 'intervali')).toBe(false)
    const p = { ...prof, goal: 'forma', ...profileFromFocus(n, prof, '2026-10-26', TODAY) } as Profile
    const w = buildFocusWeek({ profile: p, activities: [], weekStart: '2026-10-26', notBefore: '2026-10-26', today: TODAY } as never)
    expect(w.some(d => /interval/i.test(d.title))).toBe(false)
    // kolesar z omejitvijo »srce« v dogovoru: vrstica ZDRAVJE v AI kontekstu
    const bike = { ...prof, focus: { sessions: [], aims: [], limits: 'srce', said: [] } } as unknown as Profile
    expect(aiContext([], bike, [], false, TODAY)).toMatch(/OMEJITVE \(povedal ob dogovoru\): srce\. ZDRAVJE:/)
  })
  it('vsaka oznaka zdravja se prebere nazaj sama vase (tudi v seznamu omejitev)', () => {
    for (const l of Object.keys(HEALTH_SAY)) {
      expect(healthOf(l), l).toEqual([l])
      expect(healthOf(`koleno, ${l}`), l).toEqual([l])
    }
  })
  it.each([
    'Nimam težav s srcem, daj mi kar intervale.', 'Nimam visokega pritiska.', 'Mama ima visok pritisk, jaz sem zdrav.', 'Nisem noseča.',
    'Nikoli nisem imel težav s srcem.', 'Brez astme sem, vse ok.', 'Moj oče ima sladkorno bolezen.', 'Žena je noseča, zato imam manj časa.',
  ])('»%s« → ni omejitve, intervali ostanejo', s => {
    const n = ruleAdjust(run, s, 30)
    expect(healthOf(n?.limits ?? null), s).toEqual([])
    expect(n === null || n.sessions.some(x => x.cardio === 'intervali'), s).toBe(true)
  })
  it.each([
    ['Imam visok pritisk.', 'visok krvni tlak'], ['Sem noseča.', 'nosečnost'], ['Imam astmo, ampak mama nima nič.', 'astma'],
    ['Mama je zdrava, jaz pa imam sladkorno bolezen.', 'sladkorna bolezen'], ['Ne smem šprintati zaradi astme.', 'astma'], ['Imam sinusno aritmijo.', 'srce'],
  ])('»%s« → %s', (s, l) => {
    expect(healthSaid(s)).toEqual([l])
    expect(healthOf(ruleAdjust(run, s, 30)!.limits)).toContain(l)
  })
  it('želja ob dogovoru: »Nimam težav s srcem« ni omejitev', () => {
    const f = normalizeFocus({ wish: 'Rad bi tekel hitreje. Nimam težav s srcem.', sports: ['tek'], aims: ['kondicija'], level: 2, offDays: [], sessions: [{ type: 'tek', cardio: 'lahko', min: 40 }] }, { by: 'pravila', now: NOW })!
    expect(f.limits).toBeNull()
    expect(f.notes.join(' ')).not.toMatch(/zdravnik/)
  })
})

describe('R5, R6, R11, R12, R13 — premor, preklic in bolezen v klepetu', () => {
  it.each([
    // R5: poročilo o preteklem in vprašanje
    'Ta teden sem samo tekel, kaj naj naredim naslednji teden?', 'Ta teden sem bila samo na sprehodih.', 'Ta teden sem samo tekla.',
    'Ta teden sem delal samo moč, je to ok?', 'Ta teden sem hodil samo v fitnes.', 'Ta teden samo tekla, kolo v servisu.',
    // R12: bolezen ni premor po izbiri
    'Ta teden sem bolan, zato ne bom treniral.', 'Ta teden sem prehlajen, ne bom vozil.', 'Bolna sem, ta teden nič.',
  ])('»%s« → ni premor', t => {
    expect(pauseIntent(t), t).toBeNull()
  })
  it.each([
    // R13: razlog z uro, službo ali »zunaj« ni delni premor
    ['Ta teden ne bom treniral, ker delam po 12 ur na dan.', 'vse'], ['Ta teden nimam časa, hodim v službo do 20h.', 'vse'],
    ['Ta teden ne bom treniral, ker moram vsak dan v službo.', 'vse'], ['Ta teden ne bom treniral, ker sem zunaj na terenu.', 'vse'],
    ['Ta teden ne bom treniral, ker sem 3 dni v Münchnu.', 'vse'],
    // R12: tuja bolezen je še vedno premor
    ['Moj brat je bolan, zato ta teden ne bom treniral.', 'vse'],
    // R5: odločitev ostane
    ['Ta teden bom samo tekel.', 'kolo'], ['Ta teden sem utrujen, zato bom samo hodil.', 'kolo'],
  ] as const)('»%s« → premor %s', (t, mode) => {
    expect(pauseIntent(t)?.mode, t).toBe(mode)
  })
  it('delni premor z vožnjo ostane delni', () => {
    for (const t of ['Ta teden ne bom vozil več kot 2 uri.', 'Ta teden ne bom kolesaril zunaj, samo trenažer.', 'Ta teden ne bom vozil v službo', 'Ta teden brez voženj 3 ure, samo kratke.'])
      expect(pauseIntent(t), t).toBeNull()
  })
  it.each([
    // R6: naslednji teden kot nasprotje
    ['Ta teden nočem nič, naslednji teden pa spet po planu.', false], ['Ta teden brez kolesa, od naslednjega tedna normalno.', false],
    ['Ta teden ne bom treniral, naslednji teden pa normalno.', false],
    ['Ta teden in še naslednjega ne bom treniral.', true], ['Ta teden ne bom treniral, naslednji teden tudi ne.', true],
    ['Ta in naslednji teden brez kolesa.', true], ['Dva tedna ne bom treniral.', true],
  ] as const)('»%s« → dva tedna: %s', (t, two) => {
    expect(pauseIntent(t)?.twoWeeks, t).toBe(two)
  })
  it.each([
    ['Ne prekliči premora, samo vprašam glede hrane.', false], ['Danes sem že vozil kolo v službo.', false],
    ['Ta teden sem spet kolesaril v službo, je to ok za premor.', false], ['Nočem preklicati premora.', false], ['Premor naj ostane, hvala.', false],
    ['Nikar ne končaj premora.', false],
    ['Prekliči premor, vseeno bom treniral.', true], ['Ta teden pa vseeno treniram.', true], ['spet bom kolesaril', true], ['Končaj premor.', true],
  ] as const)('preklic »%s« → %s', (t, v) => {
    expect(pauseEndIntent(t), t).toBe(v)
  })
  it.each([
    ['Nisem zbolel, samo utrujen sem.', false], ['Prejšnji teden sem bil bolan, zdaj sem v redu.', false], ['Moj brat je bolan, zato ta teden ne bom treniral.', false],
    ['Upam, da ne bom zbolela.', false], ['Včeraj sem bila bolna, danes je bolje.', false], ['Nimam vročine.', false], ['Brat ima gripo.', false],
    ['Ta teden sem bolan.', true], ['Bolna sem.', true], ['Zbolel sem.', true], ['Mislim, da sem zbolela.', true], ['Imam vročino.', true], ['Še vedno sem prehlajen.', true],
  ] as const)('bolezen »%s« → %s', (t, v) => {
    expect(sickIntent(t), t).toBe(v)
  })
})

describe('R10 — premor ob skritih vadbah: brez navodil o besedah v pozivih, varovalka nespremenjena', () => {
  const SUBST = /OPOMBA O BESEDAH|ne uporabljaj besed|počiješ|dnevi brez vadbe|(?<!Uveljavi: ta )teden brez kolesa/i
  const pz = { ...prof, weekPause: { from: addDays(TODAY, -4), to: addDays(TODAY, 2), mode: 'kolo', reason: null, at: NOW } } as unknown as Profile
  const pzVse = { ...prof, weekPause: { from: addDays(TODAY, -4), to: addDays(TODAY, 2), mode: 'vse', reason: null, at: NOW } } as unknown as Profile
  it('sanitizeGaps je nespremenjen (md5 regexa in funkcije)', () => {
    const s = readFileSync('src/domain/ai/sanitize.ts', 'utf8')
    const a = s.indexOf('export const AI_GAP_RX_V1'), end = '} catch { return txt }\n}'
    const b = s.indexOf(end, a) + end.length
    expect(createHash('md5').update(s.slice(a, b)).digest('hex')).toBe('e87ed48e7e257bbcc6235ecd9056b762')
  })
  it('modul pozivov nima več opombe o nadomestnih besedah', () => {
    expect(Object.keys(prompts)).not.toContain('PAUSE_WORDS_HIDDEN')
  })
  it('kontekst, nasvet za danes in pregled tedna: premor samo kot dejstvo', () => {
    for (const p of [pz, pzVse]) {
      const ctx = aiContext([strava], p, [], true, TODAY)
      expect(ctx).toContain(`uporabnik je sam izbral počitek od ${addDays(TODAY, -4)} do vključno ${addDays(TODAY, 2)}`)
      for (const t of [ctx, txt(coachDailyPrompt(ctx, [])), txt(weeklyReviewPrompt(ctx))]) expect(t).not.toMatch(SUBST)
    }
    expect(pauseAiLine(pz.weekPause!, TODAY)).not.toMatch(SUBST)
  })
  it('klepet: nov premor, premor velja, preklic, pregled tedna, mesečna ocena, profil — brez nadomestnih besed', async () => {
    const s0 = { profile: prof, activities: [strava], plan: [], today: TODAY } as never
    await chat(s0, 'Ta teden nočem nič.', { msgs: [], summary: null })
    await chat(s0, 'Ta teden ne bom nič na kolesu.', { msgs: [], summary: null })
    await chat({ profile: pz, activities: [strava], plan: [], today: TODAY } as never, 'Ta teden nočem nič.', { msgs: [], summary: null })
    await chat({ profile: pz, activities: [strava], plan: [], today: TODAY } as never, 'Prekliči premor.', { msgs: [], summary: null })
    await weeklyReview({ profile: pz, activities: [strava], plan: [], today: TODAY } as never, true)
    await monthReview({ profile: pz, activities: [strava], plan: [], today: TODAY } as never, 'mesec')
    await athleteProfile({ profile: pz, activities: [strava], plan: [], today: TODAY } as never)
    expect(sent).toHaveLength(7)
    for (const t of sent) expect(t).not.toMatch(SUBST)
    // gumb še vedno obljubljen (vrstico pod odgovorom doda aplikacija po varovalki)
    expect(sent[0]).toContain('pod tvojim odgovorom je gumb »Uveljavi: ta teden brez treningov«')
  })
})

describe('R7 — »Začni cikel znova«: stari test FTP iz načrta ni »lasten« trening', () => {
  it('ownDay: test z vlogo »test« ni lasten, test brez vloge (dodan sam v starejši različici) je', () => {
    const W1 = '2026-10-26'
    let old: Profile | null = null
    for (let k = 1; k < 40 && !old; k++) { const p = { ...prof, goal: 'forma', cycleStart: addDays(W1, -7 * k), ftpDate: '2026-01-01' } as Profile; if (weekContext(p, W1).test) old = p }
    const oldWeek = buildWeek({ profile: old!, activities: [], weekStart: W1, notBefore: W1, today: TODAY })
    const test = oldWeek.find(d => d.kind === 'test')!
    expect(test.role).toBe('test')
    const nu = { ...old!, cycleStart: W1 }
    const ref = new Set(buildWeek({ profile: nu, activities: [], weekStart: W1, notBefore: W1, today: TODAY }).map(planKey))
    expect(ref.has(planKey(test))).toBe(false)
    expect(ownDay(test, nu, ref)).toBe(false)
    expect(ownDay({ ...test, role: null }, nu, ref)).toBe(true)
  })
  it('Ostalo.restartCycle poda staro referenco', () => {
    expect(readFileSync('src/screens/Ostalo.tsx', 'utf8')).toMatch(/rebuildFromToday\(prof, \{ old: s0\.profile \}\)/)
  })
})

describe('R8 — cikel brez cilja: obstoječim se faza ne premakne', () => {
  const rec = (cycleStart: string, n: number) => weekContext({ ...prof, goal: 'forma', event: null, races: [], cycleStart, ftpDate: '2026-01-01' } as Profile, addDays(cycleStart, 7 * n))
  it('cikel od 1. 6. 2026: razbremenilni tedni 3, 7, 11, 15 kot pred v3.51 (prej 6, 10, 14)', () => {
    const r = Array.from({ length: 16 }, (_, n) => rec('2026-06-01', n).recovery)
    expect(r.map((x, n) => (x ? n : -1)).filter(n => n >= 0)).toEqual([3, 7, 11, 15])
  })
  it('cikel od 7. 9. (ob izdaji v drugem bloku): razbremenilni pri 3, 7, 11 — ne 6 obremenilnih zapored', () => {
    const r = Array.from({ length: 12 }, (_, n) => rec('2026-09-07', n).recovery)
    expect(r.map((x, n) => (x ? n : -1)).filter(n => n >= 0)).toEqual([3, 7, 11])
  })
  it('novejši cikel (od 21. 9.): bloki od konca lahkega začetka — test v 4. tednu, razbremenilni v 7.', () => {
    expect(NEW_COUNT_FROM).toBe('2026-09-21')
    for (const cs of ['2026-09-21', '2026-10-05', '2026-10-19', '2026-11-02']) {
      expect(rec(cs, 3).recovery, cs).toBe(false)
      expect(rec(cs, 3).test, cs).toBe(true)
      expect(rec(cs, 6).recovery, cs).toBe(true)
    }
  })
  it('najdaljši niz obremenilnih tednov ob prehodu: največ 3 (stari tedni do izdaje + novo štetje)', () => {
    // tedni do vključno 26. 10. sestavljeni po starem štetju (n % 4 === 3 razbremenilni), od 2. 11. po novem
    for (let k = 0; k < 20; k++) {
      const cs = addDays('2026-06-01', 7 * k)
      let run = 0, worst = 0
      for (let n = 3; n < 30; n++) {
        const wk = addDays(cs, 7 * n)
        const r = wk <= '2026-10-26' ? n % 4 === 3 : rec(cs, n).recovery
        run = r ? 0 : run + 1; worst = Math.max(worst, run)
      }
      expect(worst, cs).toBeLessThanOrEqual(3)
    }
  })
})

describe('R9 — tekme v pozivih: eno pravilo', () => {
  const pc = (p: Profile) => personalContext({ profile: p, activities: [], plan: [], checkins: [], recentMeals: [], today: TODAY } as never)
  it('cilj A samo v »races«: brez BREZ TEKME, persona do dirke', () => {
    const p = { ...prof, races: [{ id: 'a', name: 'Maraton Alpe', date: '2027-06-06', prio: 'A', distanceKm: 140, type: 'maraton' }] } as unknown as Profile
    expect(raceAhead(p, TODAY)).toBe(true)
    const ctx = aiContext([], p, [], false, TODAY)
    expect(ctx).not.toContain(NO_RACE_MARK)
    expect(txt(coachDailyPrompt(ctx, []))).toContain('do svoje dirke')
  })
  it('tekma B pri cilju forma: BREZ TEKME izpade, GLAVNI CILJ brez »brez tekme«', () => {
    const p = { ...prof, goal: 'forma', races: [{ id: 'b', name: 'Kronometer Vodice', date: '2026-11-08', prio: 'B', distanceKm: 20, type: 'kronometer' }] } as unknown as Profile
    expect(aiContext([], p, [], false, TODAY)).not.toContain(NO_RACE_MARK)
    expect(pc(p)).toMatch(/Tekme med potjo/)
    expect(pc(p)).not.toMatch(/brez tekme/)
  })
  it('cilj »dirka« brez datuma: »forma (tekma še ni izbrana)«, ne »priprava na dirko … ne govori o dirki«', () => {
    const line = aiContext([], prof, [], false, TODAY).split('\n').find(l => l.startsWith(NO_RACE_MARK))!
    expect(line).toContain('cilj je forma (tekma še ni izbrana) s kolesom')
    expect(line).not.toContain('priprava na dirko')
  })
  it('pretekla glavna dirka: mesečna ocena in profil brez »do dirke«', async () => {
    const p = { ...prof, event: { name: 'Franja', date: '2026-06-14', distanceKm: 156 } } as unknown as Profile
    expect(raceAhead(p, TODAY)).toBe(false)
    await monthReview({ profile: p, activities: [], plan: [], today: TODAY } as never, 'mesec')
    await athleteProfile({ profile: p, activities: [], plan: [], today: TODAY } as never)
    expect(sent[0]).toContain('glede na cilj iz konteksta')
    expect(sent[0]).not.toContain('cilj športnika je dirka iz konteksta')
    expect(sent[1]).toContain('za svoj cilj iz konteksta')
  })
})

describe('R14 — tekma po meri: teden okrevanja samo po dolgi tekmi', () => {
  const NOW0 = '2026-10-19T08:00:00.000Z'
  const week = (race: { name: string; date: string; distanceKm: number; sport: 'kolo' | 'tek' | 'hribi' }, sessions: { type: 'kolo' | 'tek'; cardio: 'intervali' | 'tempo' | 'lahko' | 'dolgo'; min: number }[]) => {
    const f = normalizeFocus({ wish: race.name, sports: [race.sport], aims: ['kondicija', 'tekma'], level: 3, offDays: [], sessions, race }, { by: 'pravila', now: NOW0 })!
    const p = { ...prof, ...profileFromFocus(f, prof, '2026-10-19', '2026-10-19') } as Profile
    return buildFocusWeek({ profile: p, activities: [], weekStart: '2026-10-26', notBefore: '2026-10-26', today: '2026-10-19' } as never).filter(d => d.kind !== 'pocitek')
  }
  const BIKE = [{ type: 'kolo', cardio: 'intervali', min: 60 }, { type: 'kolo', cardio: 'tempo', min: 60 }, { type: 'kolo', cardio: 'lahko', min: 60 }, { type: 'kolo', cardio: 'dolgo', min: 150 }] as const
  it('kronometer 20 km (40 min): po treh lahkih dneh spet dolga vožnja (prej ves teden lahko, dolga 1 h)', () => {
    const w = week({ name: 'Kronometer Vodice', date: '2026-10-25', distanceKm: 20, sport: 'kolo' }, [...BIKE])
    expect(w.filter(d => d.date <= '2026-10-28').every(d => d.zone === 'Z2')).toBe(true)
    expect(w.some(d => d.date >= '2026-10-29' && d.durationMin >= 120)).toBe(true)
  })
  it('polmaraton: teden po njem samo lahko (ostane)', () => {
    const w = week({ name: 'Ljubljanski polmaraton', date: '2026-10-25', distanceKm: 21.1, sport: 'tek' },
      [{ type: 'tek', cardio: 'intervali', min: 45 }, { type: 'tek', cardio: 'tempo', min: 45 }, { type: 'tek', cardio: 'dolgo', min: 90 }])
    expect(w.filter(d => d.date <= '2026-11-01').every(d => d.zone === 'Z2' || /lahk/i.test(d.title))).toBe(true)
  })
})

describe('R15 — »brez« ne skrije poznejše vaje', () => {
  it.each([
    ['Naredi sklece brez počitka med serijami in nato počepe 3 × 12.', ['Sklece', 'Počep']],
    ['Ogrevanje brez naglice in nato počep s palico 4 × 6.', ['Počep s palico']],
    ['Ogrevanje brez naglice, nato počep s palico 4 × 6.', ['Počep s palico']],
  ] as const)('»%s«', (s, names) => {
    const got = exercisesIn(s).map(e => e.name)
    for (const n of names) expect(got.some(g => g.startsWith(n)), `${s} → ${got.join(',')}`).toBe(true)
  })
  it('»brez počepov in izpadnih korakov« še vedno skrije obe', () => {
    expect(exercisesIn('Ta teden brez počepov in izpadnih korakov, delaj sklece.').map(e => e.name)).toEqual(['Sklece'])
  })
})
