// v3.50 PREMOR (zasloni): gumb »Uveljavi: ta teden brez …« pod odgovorom trenerja, kartica premora na Danes,
// »Ta teden …« v »Danes ne gre« in list s premorom.
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>() }))
const h = vi.hoisted(() => ({ run: vi.fn(async (fn: () => Promise<unknown>) => fn()), setWeekPause: vi.fn(async () => ({})), endWeekPause: vi.fn(async () => {}) }))
vi.mock('@/state/store', () => ({
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  savePlanDays: vi.fn(), savePlanDay: vi.fn(), saveCheckin: vi.fn(), updateSettings: vi.fn(async () => {}), toast: vi.fn(), newCoachChat: vi.fn(), restorePlanDays: vi.fn(),
  setPlanDone: vi.fn(), addCore: vi.fn(), setWeekPause: h.setWeekPause, endWeekPause: h.endWeekPause,
}))
vi.mock('@/app/router', () => ({ navigate: vi.fn(), useRoute: () => ({ name: 'trener', params: {} }) }))
vi.mock('@/app/Shell', () => ({ Head: () => null }))
vi.mock('@/ui/useAi', () => ({ useAi: () => ({ busy: false, signedIn: true, consent: true, run: h.run, sheet: null }) }))
vi.mock('@/state/snap', () => ({ snapOf: () => ({}) }))
vi.mock('@/data/db', () => ({ getKV: async () => undefined, setKV: async () => {} }))
vi.mock('@/ui/useDictation', () => ({ useDictation: () => ({ listening: false, canSpeak: false, toggle: () => {}, stop: () => {}, transcribing: false, level: 0 }) }))
vi.mock('@/ui/ListenBar', () => ({ ListenBar: () => null }))
vi.mock('@/ui/Confirm', () => ({ undoToast: vi.fn(), useHidden: () => new Set() }))

import { Trener } from '@/screens/Trener'
import { coachLine } from '@/screens/Danes'
import { WeekPauseCard, WeekPauseSheet } from '@/ui/WeekPauseSheet'
import { SkipSheet } from '@/ui/SkipSheet'
import type { PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

const T = '2026-10-21'
const NOW = '2026-10-21T08:00:00.000Z'
const base = { sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, strength: { on: false, equipment: 'none' }, onboardingDone: true, createdAt: NOW, updatedAt: NOW } as unknown as Profile
const reset = (msgs: { role: 'user' | 'ai'; text: string; at: string }[], p: Partial<Profile> = {}) => {
  S.state = { ready: true, today: T, plan: [], activities: [], checkins: [], recentMeals: [], weather: null, wellness: [], settings: { coach: { msgs, summary: null } }, user: { uid: 'u' }, authKnown: true, firstSync: true, profile: { ...base, ...p } }
  S.subs.forEach(f => f())
}
const pair = (q: string, at = NOW) => [{ role: 'user' as const, text: q, at }, { role: 'ai' as const, text: 'Razumem. Počitek je del treninga.', at }]

let div: HTMLDivElement, root: Root | null = null
async function mount(el: React.ReactElement) { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div); await act(async () => { root!.render(el) }) }
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(b.textContent || '')) as HTMLButtonElement | undefined
const click = async (b: HTMLElement | undefined) => { expect(b).toBeTruthy(); await act(async () => { b!.click() }) }

beforeEach(() => { reset(pair('Ta teden nočem nič več.')); h.setWeekPause.mockClear(); h.endWeekPause.mockClear(); window.scrollTo = vi.fn() as never; location.hash = '#/trener' })
afterEach(async () => { if (root) { await act(async () => root!.unmount()); root = null; div.remove() } document.body.innerHTML = '' })

describe('klepet s trenerjem: »ta teden nočem nič« → gumb', () => {
  it('pod odgovorom »Uveljavi: ta teden brez treningov« — tap uveljavi premor', async () => {
    await mount(<Trener />)
    const b = btn(/^Uveljavi: ta teden brez treningov$/)
    await click(b)
    expect(h.setWeekPause).toHaveBeenCalledWith('vse', { twoWeeks: false })
    expect(btn(/druge možnosti/)).toBeTruthy()
  })
  it('»ta teden ne bom nič na kolesu« → »Uveljavi: ta teden brez kolesa«', async () => {
    reset(pair('Ta teden ne bom nič na kolesu.'))
    await mount(<Trener />)
    await click(btn(/^Uveljavi: ta teden brez kolesa$/))
    expect(h.setWeekPause).toHaveBeenCalledWith('kolo', { twoWeeks: false })
  })
  it('»nočem počivati« in vprašanje iz prejšnjega tedna nimata gumba', async () => {
    reset(pair('Ta teden nočem počivati, hočem trenirat.'))
    await mount(<Trener />)
    expect(btn(/^Uveljavi:/)).toBeUndefined()
    await act(async () => root!.unmount()); root = null; div.remove()
    reset(pair('Ta teden nočem nič.', '2026-10-14T08:00:00.000Z'))
    await mount(<Trener />)
    expect(btn(/^Uveljavi:/)).toBeUndefined()
  })
  it('vprašanje ni šlo (preklic prijave): gumb za premor je vseeno tu — brez AI', async () => {
    reset([])
    h.run.mockImplementationOnce(async () => undefined)
    await mount(<Trener />)
    const input = document.querySelector('input.field') as HTMLInputElement
    await act(async () => {
      const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!
      set.call(input, 'ta teden ne grem na kolo')
      input.dispatchEvent(new Event('input', { bubbles: true }))
    })
    expect(btn(/^Uveljavi:/)).toBeUndefined()                         // med tipkanjem ne
    await act(async () => { (document.querySelector('form') as HTMLFormElement).requestSubmit() })
    await click(btn(/^Uveljavi: ta teden brez kolesa$/))
    expect(h.setWeekPause).toHaveBeenCalledWith('kolo', { twoWeeks: false })
  })
  it('premor že velja: »… — velja« in »spremeni«, brez gumba Uveljavi', async () => {
    reset(pair('Ta teden nočem nič.'), { weekPause: { from: T, to: '2026-10-25', mode: 'vse' } })
    await mount(<Trener />)
    expect(btn(/^Uveljavi:/)).toBeUndefined()
    expect(document.querySelector('.pause-ok')?.textContent).toContain('Ta teden: premor do nedelje — velja.')
    expect(btn(/^spremeni$/)).toBeTruthy()
  })
})

describe('Danes in list »Ta teden …«', () => {
  it('kartica premora: »Ta teden: premor do nedelje (brez kolesa)« in »Prekliči premor«', async () => {
    reset([], { weekPause: { from: T, to: '2026-10-25', mode: 'kolo' } })
    await mount(<WeekPauseCard />)
    expect(document.querySelector('.ttl')?.textContent).toBe('Ta teden: premor do nedelje (brez kolesa)')
    expect(btn(/^Dodaj trening$/)).toBeTruthy()
    await click(btn(/^Prekliči premor$/))
    expect(h.endWeekPause).toHaveBeenCalled()
  })
  it('brez premora kartice ni', async () => {
    reset([])
    await mount(<WeekPauseCard />)
    expect(div.textContent).toBe('')
  })
  it('»Danes ne gre« ponudi »Ta teden …«', async () => {
    const onWeek = vi.fn()
    const day = { id: 'd', date: T, kind: 'kolo', title: 'Z2', desc: 'Z2.', durationMin: 60, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null } as PlanDay
    await mount(<SkipSheet day={day} canMove onClose={() => {}} onMove={() => {}} onSick={() => {}} onWeek={onWeek} />)
    await click(btn(/^Ta teden …/))
    expect(onWeek).toHaveBeenCalled()
  })
  it('list: še naslednji teden in razlog, nato »Brez kolesa …« (en tap uveljavi)', async () => {
    reset([])
    const onClose = vi.fn()
    await mount(<WeekPauseSheet open onClose={onClose} />)
    expect(btn(/^Brez treningov do nedelje/)).toBeTruthy()
    await click(btn(/^Še naslednji teden$/))
    await click(btn(/^potovanje$/))
    await click(btn(/^Brez kolesa do nedelje, 1\.\s11\./))
    expect(h.setWeekPause).toHaveBeenCalledWith('kolo', { twoWeeks: true, reason: 'potovanje' })
    expect(onClose).toHaveBeenCalled()
  })
  it('»Trener pravi« v premoru: brez »drži se načrta«', () => {
    expect(coachLine(0, { kind: 'pocitek' }, 5, 10, 80, { pause: true })).toMatch(/^Ta teden premor po tvoji izbiri/)
  })
})
