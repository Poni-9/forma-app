// v3.50 POPRAVKI-UI (REVIEW-UI, prava shramba): »Brez — dodatna vadba« ne odkljuka treninga (U6), napaka usklajevanja
// izgine, ko usklajevanje spet dela (U8), »Ne« iz Prehrane ne zadrži prestavitve ključnega treninga (U12).
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const SY = vi.hoisted(() => ({ cb: null as null | ((s: unknown) => void) }))
vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
vi.mock('../src/data/sync', async () => {
  const real = await vi.importActual<Record<string, unknown>>('../src/data/sync')
  return { ...real, onSyncStatus: (cb: (s: unknown) => void) => { SY.cb = cb; return () => undefined } }
})
const U = vi.hoisted(() => ({ msg: '' }))
vi.mock('../src/ui/Confirm', async (orig) => {
  const m = await orig<typeof import('../src/ui/Confirm')>()
  return { ...m, undoToast: (msg: string) => { U.msg = msg } }
})

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { saveDoneShot } from '../src/state/photoTraining'
import { markNo } from '../src/state/noAsk'
import { addDays } from '../src/domain/training/load'
import type { Activity, PlanDay, Profile } from '../src/domain/types'

const TODAY = '2026-10-21'   // sreda
const NOW = `${TODAY}T08:00:00.000Z`
const day = (id: string, o: Partial<PlanDay>): PlanDay => ({ id, date: TODAY, kind: 'kolo', title: 'Z2 lahko', desc: 'Lahko, Z2.', durationMin: 60, zone: 'Z2', role: 'lahka', tssTarget: 42, why: null, done: null, source: 'rules', createdAt: NOW, updatedAt: NOW, ...o } as PlanDay)
const rest = (id: string, date: string) => day(id, { date, kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, role: null, tssTarget: 0 })
const byId = (id: string) => store.getState().plan.find(d => d.id === id)

beforeEach(async () => {
  vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date(2026, 9, 21, 18, 0))
  U.msg = ''
  await repo.wipeAll(); localStorage.clear(); await store.reloadAll()
  await store.updateProfile({ ...repo.defaultProfile(), onboardingDone: true, ftp: 240, weightKg: 79, sex: 'm', age: 21, heightCm: 180 } as Partial<Profile>)
})
afterEach(() => { vi.useRealTimers() })

describe('U6 »Slikaj opravljen trening« → »Brez — dodatna vadba«', () => {
  const key = day('k1', { title: 'VO2max 5 × 4 min', durationMin: 90, zone: 'Z5', role: 'kljucna', tssTarget: 95 })
  const shot = (o: Partial<Activity> = {}): Activity => ({ id: 'shot1', source: 'screenshot', sport: 'kolo', date: TODAY, start: null, name: 'Zwift — dodatna lahka vožnja', durationMin: 50, distKm: 20, tss: null, aiEligible: true, geoRetain: false, createdAt: NOW, updatedAt: NOW, ...o } as unknown as Activity)
  it('50 min dodatne vožnje, dayId null → vadba shranjena, ključni trening 90 min ostane neodkljukan', async () => {
    await store.savePlanDays([key])
    const r = await saveDoneShot(shot(), null)
    expect(r).toEqual({ added: true, day: null })
    expect(store.getState().activities.some(a => a.id === 'shot1')).toBe(true)
    expect(byId('k1')!.done).toBeNull()
  })
  it('izbran dan velja: dva kolesarska treninga istega dne → kljukica na izbranem, ne na tistem, ki ga izbere uvoz', async () => {
    await store.savePlanDays([key, day('z2', { title: 'Z2 lahko', durationMin: 50 })])
    // 55 min je bližje lahki vožnji (50) — uvoz bi odkljukal njo, izbran pa je ključni (55 min ≥ 40 % od 90)
    const r = await saveDoneShot(shot({ id: 'shot2', durationMin: 55, name: 'Zwift — VO2max, krajše' }), 'k1')
    expect(r.day?.id).toBe('k1')
    expect(byId('k1')!.done?.activityId).toBe('shot2')
    expect(byId('z2')!.done).toBeNull()
  })
})

describe('U8 obvestilo-napaka usklajevanja po okrevanju', () => {
  it('denied → napaka z »Prijava znova«; ko je usklajevanje spet »idle«, napaka izgine (druga obvestila ostanejo)', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('', { status: 503 })))
    try {
      await store.boot()
      for (let i = 0; i < 30 && !SY.cb; i++) await new Promise(r => setTimeout(r, 10))
      expect(SY.cb).toBeTruthy()
      const t0 = Date.now()
      SY.cb!({ state: 'error', kind: 'denied', at: t0, msg: 'Dostop zavrnjen' })
      const err = (store.getState().toasts || []).find(t => t.kind === 'err')
      expect(err?.action?.label).toBe('Prijava znova')
      store.toast('Vpiši utrip med 40 in 220.', 'err')
      SY.cb!({ state: 'pull', at: t0 + 5_000 })
      expect((store.getState().toasts || []).some(t => t.id === err!.id)).toBe(true)   // med usklajevanjem še velja
      SY.cb!({ state: 'idle', at: t0 + 8_000 })
      const left = (store.getState().toasts || []).filter(t => t.kind === 'err').map(t => t.msg)
      expect(left).toEqual(['Vpiši utrip med 40 in 220.'])
    } finally { vi.unstubAllGlobals() }
  })
  it('toast vrne id (za dismissToast)', () => {
    const id = store.toast('Shranjeno.', 'ok')
    expect(typeof id).toBe('number')
    expect((store.getState().toasts || []).some(t => t.id === id)).toBe(true)
    store.dismissToast(id)
    expect((store.getState().toasts || []).some(t => t.id === id)).toBe(false)
  })
})

describe('U12 »Ne« v Prehrani in prestavitev ključnega treninga', () => {
  const Y = addDays(TODAY, -1)
  const week = () => [
    rest('mon', addDays(TODAY, -2)),
    day('vo2', { date: Y, title: 'VO2max 4 × 4 min', role: 'kljucna', zone: 'Z5', durationMin: 75, tssTarget: 80 }),
    rest('wed', TODAY),
    day('thu', { date: addDays(TODAY, 1), title: 'Z2 lahko', durationMin: 60 }),
    rest('fri', addDays(TODAY, 2)), rest('sat', addDays(TODAY, 3)), rest('sun', addDays(TODAY, 4)),
  ]
  beforeEach(async () => {
    await repo.putPlanDays(week())
    await store.reloadAll()
    await store.boot()   // ready (autoMissed sicer ne teče)
  })
  it('brez odgovora čaka na »Včeraj … si ga naredil?«; z »Ne« iz Prehrane (včeraj zvečer) se prestavi takoj', async () => {
    await store.autoMissed()
    expect(byId('vo2')!.missed ?? null).toBeNull()
    markNo('vo2', Y)   // Prehrana včeraj: »Si ga opravil?« → Ne
    await store.autoMissed()
    expect(byId('vo2')!.missed).toBe('moved')
    expect(byId('thu')!.title).toBe('VO2max 4 × 4 min')
    expect(U.msg).toContain('Včerajšnji VO2max 4 × 4 min ni bil narejen → prestavljen na četrtek.')
  })
})
