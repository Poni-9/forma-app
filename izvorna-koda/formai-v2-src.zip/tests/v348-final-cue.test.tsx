// v3.48 — po pregledu kode: opomnik za hrano/pijačo čaka samo med kratkim delom intervala.
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>() }))
const store = vi.hoisted(() => ({ setPlanDone: vi.fn(async () => {}), addActivities: vi.fn(async () => ({ added: 1, dupes: 0, upgraded: 0 })), toast: vi.fn(), savePlanDay: vi.fn() }))
vi.mock('@/state/store', () => ({
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state, ...store, newRouteFor: vi.fn(), routePace: () => ({ k: 1, adj: { n: 0, adj: 1 } }),
}))
import { Vadba } from '@/screens/Vadba'
import type { PlanDay, Profile } from '@/domain/types'
;(globalThis as any).IS_REACT_ACT_ENVIRONMENT = true
const today = new Date().toISOString().slice(0, 10)
const profile = { sex: 'm', age: 35, heightCm: 180, weightKg: 75, ftp: 250, gear: { bikeOutdoor: true, trainer: false, noBike: false }, strength: { on: false, equipment: 'none' }, onboardingDone: true, createdAt: 'x', updatedAt: 'x' } as unknown as Profile
const long: PlanDay = { id: 'd1', date: today, kind: 'kolo', title: 'Z2 vzdržljivost', desc: 'Mirno v Z2, kadenca 90+. Od 30. minute ~40 g OH na uro.', durationMin: 120, zone: 'Z2', role: 'lahka', source: 'rules', createdAt: 'x', updatedAt: 'x' }
const race: PlanDay = { id: 'r1', date: today, kind: 'kolo', title: 'Dirka X — 120 km', desc: 'Zajtrk 3 h pred startom (2–3 g OH na kg). V zavetrini varčuj; jej in pij od začetka (60–90 g OH na uro).', durationMin: 210, zone: 'dirka', role: 'dirka', source: 'rules', createdAt: 'x', updatedAt: 'x' }
let div: HTMLDivElement, root: Root | null
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(b.textContent || '')) as HTMLButtonElement | undefined
const cue = () => [...document.querySelectorAll('button')].find(b => /tapni, ko je opravljeno/.test(b.textContent || ''))?.textContent ?? null
async function mount(id: string) { location.hash = `#/vadba?id=${id}`; div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div); await act(async () => { root!.render(<Vadba />) }) }
beforeEach(() => { vi.useFakeTimers(); sessionStorage.clear(); S.subs.clear() })
afterEach(async () => { if (root) { await act(async () => root!.unmount()); root = null } div.remove(); vi.useRealTimers(); document.body.innerHTML = '' })
const reset = (plan: PlanDay[]) => { S.state = { ready: true, today, plan, activities: [], recentMeals: [], weather: null, routeLib: null, routesBusy: false, settings: { lang: 'sl', intervals: null }, toast: null, profile } }
describe('v3.48 opomniki goriva med enakomernim delom in tekmo (prej šele v izteku)', () => {
  const at = async (t0: number, min: number) => { await act(async () => { vi.setSystemTime(t0 + min * 60_000); vi.advanceTimersByTime(300) }); return cue() }
  it('2 h Z2: opomnik se pokaže med vožnjo, ne šele v izteku', async () => {
    reset([long]); await mount('d1')
    const t0 = Date.now()
    await act(async () => { btn(/Začni trening/)!.click() })
    expect(await at(t0, 31)).not.toBeNull()
  })
  it('tekma: opomnik med korakom »Tekma« (brez časovnika)', async () => {
    reset([race]); await mount('r1')
    const t0 = Date.now()
    await act(async () => { btn(/Začni trening/)!.click() })
    expect(await at(t0, 40)).not.toBeNull()
  })
})
