import { describe, it, expect } from 'vitest'
import { effortOf, EFFORT } from '../src/domain/training/effort'
import { TERMS, HOW, termOf } from '../src/domain/glossary'
import { phaseLine, weekCounts, progressLines } from '../src/domain/training/plain'
import type { PlanDay } from '../src/domain/types'

const NOW = '2026-10-04T08:00:00.000Z'
const d = (o: Partial<PlanDay>): PlanDay => ({ id: Math.random().toString(36), date: '2026-10-05', kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, zone: 'Z2', tssTarget: 45, role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })

describe('preprosto povedano: intenzivnost z besedo', () => {
  it('cona → beseda in test govorjenja; intervali v pripisu; moč, hribi in počitek brez', () => {
    expect(effortOf(d({ zone: 'Z2' }))).toEqual({ w: 'lahko', sub: 'Z2', talk: 'še lahko govoriš v celih stavkih' })
    expect(effortOf(d({ zone: 'Z5', role: 'kljucna', target: { lo: 260, hi: 290 } as never }))).toMatchObject({ w: 'zelo težko', sub: 'Z5 · intervali' })
    expect(effortOf(d({ kind: 'test', zone: 'test', role: 'test' }))?.w).toBe('test')
    expect(effortOf(d({ kind: 'moc', zone: null }))).toBeNull()
    expect(effortOf(d({ kind: 'pohod' }))).toBeNull()
    expect(effortOf(d({ zone: 'Z9' as never }))).toBeNull()
    expect(Object.keys(EFFORT)).toEqual(['Z1', 'Z2', 'Z3', 'Z4', 'Z5'])
  })
})

describe('Kako deluje in izrazi', () => {
  it('vsak izraz ima enolično oznako in razlago brez kratic brez pojasnila; koraki omenijo pripombo in spremembe', () => {
    const keys = TERMS.map(t => t.k)
    expect(new Set(keys).size).toBe(keys.length)
    for (const t of TERMS) expect(t.d.length).toBeGreaterThan(40)
    expect(termOf('tss').d).toMatch(/Ena ura na polno/)
    expect(termOf('deficit').d).toMatch(/750/)   // varovalka: strop deficita
    expect(HOW.map(h => h.t).join(' ')).toMatch(/Nekaj ni jasno/)
    expect(HOW.map(h => h.d).join(' ')).toMatch(/Spremembe načrta/)
  })
})

describe('teden z besedami (Plan)', () => {
  it('faza v enem stavku: off-season po stopnjah, lahek začetek, razbremenilni, osnova', () => {
    expect(phaseLine({ phase: 'prehod', easy: 0, recovery: false, offStage: 'pocitek' })).toMatch(/kolo počiva/)
    expect(phaseLine({ phase: 'osnova', easy: 2, recovery: false })).toMatch(/^Lahek začetek/)
    expect(phaseLine({ phase: 'gradnja', easy: 0, recovery: true })).toMatch(/^Razbremenilni teden/)
    expect(phaseLine({ phase: 'osnova', easy: 0, recovery: false })).toMatch(/^Osnova: večinoma lahke/)
    expect(phaseLine({ phase: 'tapering', easy: 0, recovery: true })).toMatch(/^Pred dirko/)
  })
  it('kaj je v tednu: vožnje (ključne), moč, hribi, po želji; počitek ne šteje', () => {
    const w = [d({ role: 'kljucna' }), d({ role: 'dolga' }), d({}), d({ kind: 'moc', zone: null, role: 'moc' }), d({ kind: 'pocitek' }), d({ kind: 'pohod', optional: true })]
    expect(weekCounts(w)).toBe('3 vožnje (2 ključni), 1 × moč, 1 po želji')
    expect(weekCounts([d({})])).toBe('1 vožnja')
    expect(weekCounts([])).toBe('')
  })
})

describe('Napredek na kratko', () => {
  const goal = { event: { name: 'Maraton Franja' }, weeksToEvent: 36, daysToEvent: 252, ftp: 240, wkg: 3.0, expected: { wkg: 3.25 }, targetWkg: 4.04 }
  it('cilj (za načrtom), teža (stabilna / prehitro), doslednost', () => {
    const l = progressLines({ goal, weight: { avg7: 79.9, deltaWeek: 0.01 }, done: 10, planned: 13 })
    expect(l[0]).toBe('Do cilja (Maraton Franja) še 36 tednov. Moč na kilogram 3,00 W/kg, cilj 4,04 — malo za načrtom (po načrtu bi bil pri 3,25).')
    expect(l[1]).toBe('Teža 79,9 kg — stabilna.')
    expect(l[2]).toBe('Zadnje 4 tedne si naredil 10 od 13 treningov po načrtu (77 %) — dobro.')
    expect(progressLines({ goal, weight: { avg7: 79, deltaWeek: -0.9 }, done: 0, planned: 0 })[1]).toMatch(/prehitro .*jej malo več/)
  })
  it('brez FTP: kaj manjka; brez cilja in podatkov: nič', () => {
    expect(progressLines({ goal: { ...goal, ftp: null, wkg: null }, weight: null, done: 0, planned: 0 })[0]).toMatch(/Moči \(FTP\) še ne poznam/)
    expect(progressLines({ goal: { ...goal, event: null }, weight: null, done: 0, planned: 0 })).toEqual([])
  })
})
