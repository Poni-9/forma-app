// v3.50 PLANER (shramba): B04 zapis »Sestavil sem teden …« z urami iz sestavljenega tedna; B40 »Spet zdrav« po 3+ dneh lahko.
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { setKV } from '../src/data/db'
import { todayIso, addDays, weekStartIso, fmtDur } from '../src/domain/training/load'
import { weekBikeMinutes, FRANJA_2027 } from '../src/domain/training/planner'
import { BACK_TITLE } from '../src/domain/training/sick'
import type { PlanDay, Profile } from '../src/domain/types'

const NOW = '2026-10-03T08:00:00.000Z'
const today = todayIso()
const prof = { sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, ftpDate: today, maxHr: 195, restHr: 48, lthr: 184, gear: { bikeOutdoor: true, trainer: true, noBike: false }, strength: { on: false, equipment: 'none' }, hoursPerWeek: 7, onboardingDone: true, createdAt: NOW, updatedAt: NOW, event: { ...FRANJA_2027 }, cycleStart: addDays(weekStartIso(today), -14) } as unknown as Profile
const settle = () => new Promise(r => setTimeout(r, 30))

describe('B04 zapis sprememb = sestavljen teden', () => {
  beforeEach(async () => { await repo.wipeAll(); localStorage.clear(); await setKV('plan.changes', []); await store.reloadAll() })
  it('»Sestavil sem teden od …« pove minute na kolesu iz sestavljenega tedna (brez tekme), ne formule', async () => {
    await store.updateProfile(prof)
    expect(await store.ensureWeeks()).toBeGreaterThan(0)
    await settle()
    const next = addDays(weekStartIso(today), 7)
    const plan = await repo.allPlan()
    const mins = weekBikeMinutes(plan.filter(d => d.date >= next && d.date <= addDays(next, 6) && d.role !== 'dirka' && !d.raceId))
    expect(mins % 60).not.toBe(0)          // 1. teden bloka: ~5 h 30 min (prej »~5,5 h« iz formule)
    const texts = store.getState().changes.map(c => c.text)
    expect(texts.some(t => /^Sestavil sem teden od /.test(t) && t.includes(`~${fmtDur(mins)}.`))).toBe(true)
  })
})

describe('B40 »Spet zdrav« po bolezni', () => {
  beforeEach(async () => { await repo.wipeAll(); localStorage.clear(); await store.reloadAll() })
  it('bolan 3 dni: danes ključni trening postane lahka Z2', async () => {
    const day: PlanDay = { id: 'k1', date: today, kind: 'kolo', title: 'Sweet spot na ravnini 3 × 12 min', desc: '3 × 12 min.', durationMin: 90, zone: 'Z3', tssTarget: 81, role: 'kljucna', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null } as PlanDay
    await store.updateProfile({ ...prof, sick: { from: addDays(today, -3), to: addDays(today, 1) } })
    await store.savePlanDays([{ ...day, kind: 'pocitek', title: 'Počitek — bolezen', durationMin: 0, zone: null, tssTarget: 0, role: null, sickPrev: [day] } as PlanDay])
    await store.endSick()
    const back = (await repo.allPlan()).find(d => d.id === 'k1')!
    expect(back.title).toBe(BACK_TITLE)
    expect(back.role).toBe('lahka')
    expect(back.durationMin).toBeLessThanOrEqual(60)
  })
})
