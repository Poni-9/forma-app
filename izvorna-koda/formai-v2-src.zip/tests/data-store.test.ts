import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const fb = vi.hoisted(() => ({ signedOut: 0, deleteRes: { ok: true, reauth: false } as { ok: boolean; reauth: boolean; error?: string }, hooks: null as null | { before?: () => void; failed?: () => void; pilotId?: () => string | null | undefined }, pilot: null as string | null | undefined }))
vi.mock('../src/data/firebase', () => ({
  core: async () => null,
  onAuth: () => () => undefined,
  signInGoogle: async () => null,
  signOutNow: async () => { fb.signedOut++ },
  idToken: async () => null,
  proFromFirestore: async () => false,
  setAccountDeleteHooks: (h: typeof fb.hooks) => { fb.hooks = h },
  deleteAccount: async (pilotId?: string | null) => { fb.pilot = pilotId; fb.hooks?.before?.(); if (!fb.deleteRes.ok) fb.hooks?.failed?.(); return fb.deleteRes },
}))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { getKV, setKV, KV } from '../src/data/db'
import { resetIcuPause } from '../src/domain/intervals/client'
import { todayIso, addDays } from '../src/domain/training/load'
import type { Activity, PlanDay, Settings } from '../src/domain/types'

const today = todayIso()
const NOW = new Date().toISOString()
const ride = (id: string, o: Partial<Activity> = {}): Activity => ({ id, source: 'intervals', originHint: 'GARMIN', sport: 'kolo', date: today, start: today + 'T07:00:00.000Z', name: 'Vožnja', durationMin: 150, distKm: 60, aiEligible: true, geoRetain: true, ext: { intervalsId: 'i-' + id }, createdAt: NOW, updatedAt: NOW, ...o })
const day = (id: string, o: Partial<PlanDay> = {}): PlanDay => ({ id, date: today, kind: 'kolo', title: 'Dolga Z2', desc: '', durationMin: 240, role: 'dolga', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })
const planById = async (id: string) => (await repo.allPlan()).find(d => d.id === id)!

beforeEach(async () => { await repo.wipeAll(); localStorage.clear(); resetIcuPause(); await store.reloadAll() })
afterEach(() => { vi.unstubAllGlobals() })

describe('ročni uvoz: zaklep, grobovi, povezava z načrtom', () => {
  it('20-minutna vožnja NE odkljuka 4-urne dolge; 150-minutna jo (≥ 50 %)', async () => {
    await repo.upsertPlanDays([day('long')]); await store.reloadAll()
    await store.addActivities([ride('short', { durationMin: 20, distKm: 7, start: today + 'T06:00:00.000Z', ext: { intervalsId: 'i-short' } })])
    expect((await planById('long')).done ?? null).toBeNull()
    await store.addActivities([ride('real')])
    const d = await planById('long')
    expect(d.done?.activityId).toBe('real')
    expect(d.doneAt).toBeTruthy()
  })
  it('ročno odkljukan dan brez aktivnosti dobi aktivnost ob uvozu', async () => {
    await repo.upsertPlanDays([day('m', { date: addDays(today, -1), durationMin: 90, done: { at: NOW, activityId: null } })]); await store.reloadAll()
    await store.addActivities([ride('y', { date: addDays(today, -1), start: addDays(today, -1) + 'T07:00:00.000Z', durationMin: 95 })])
    const d = await planById('m')
    expect(d.done?.activityId).toBe('y'); expect(d.done?.at).toBe(NOW)
  })
  it('izbrisana vožnja iz intervals.icu se tudi pri ročnem uvozu ne vrne (grob)', async () => {
    await store.addActivities([ride('a1', { ext: { intervalsId: 'i77' } })])
    await store.removeActivity('a1')
    const r = await store.addActivities([ride('a2', { ext: { intervalsId: 'i77' } })])
    expect(r.added).toBe(0)
    expect(await repo.allActivities()).toHaveLength(0)
  })
})

describe('intervals.icu: napake niso tihe', () => {
  const connect = () => store.updateSettings({ intervals: { athleteId: '0', apiKey: '', token: 'tok' } })
  it('401 → autoSyncIntervals vrne null (ne »0 novih«), icuErr = auth; syncIntervals pove, kaj je narobe; uspeh počisti', async () => {
    await connect()
    vi.stubGlobal('fetch', vi.fn(async () => new Response('', { status: 401 })))
    expect(await store.autoSyncIntervals(true)).toBeNull()
    const e = store.getState().icuErr!
    expect(e.kind).toBe('auth'); expect(e.msg).toBe('intervals.icu zavrača dostop — poveži znova.'); expect(typeof e.at).toBe('number')
    expect(await getKV('icu.err')).toEqual(e)
    const r = await store.syncIntervals()
    expect(r).toEqual({ added: 0, error: 'intervals.icu zavrača dostop — poveži znova.', kind: 'auth' })
    vi.stubGlobal('fetch', vi.fn(async () => new Response('[]', { status: 200 })))
    expect(await store.autoSyncIntervals(true)).toBe(0)
    expect(store.getState().icuErr).toBeNull()
  })
  it('429 → kvota z »until«; omrežje → network', async () => {
    await connect()
    vi.stubGlobal('fetch', vi.fn(async () => new Response('', { status: 429, headers: { 'Retry-After': '120' } })))
    expect(await store.autoSyncIntervals(true)).toBeNull()
    expect(store.getState().icuErr).toMatchObject({ kind: 'quota' })
    expect(store.getState().icuErr!.until).toBeGreaterThan(Date.now())
    resetIcuPause()
    vi.stubGlobal('fetch', vi.fn(async () => { throw new TypeError('Failed to fetch') }))
    expect((await store.syncIntervals()).kind).toBe('network')
  })
})

describe('nastavitve: popravek na shranjenem stanju, pogovor', () => {
  it('zastarelo stanje zaslona ne prepiše žetona, ki ga je medtem prinesla sinhronizacija', async () => {
    // sinhronizacija zapiše nove nastavitve (žeton z druge naprave), zaslon jih še ni prebral
    const cur = await repo.loadSettings()
    await setKV(KV.settings, { ...cur, intervals: { athleteId: '0', apiKey: '', token: 'Z-DRUGE' }, fieldAt: { intervals: NOW } } as Settings)
    await store.updateSettings({ accentHex: '#84CC16' })
    const s = await repo.loadSettings()
    expect(s.intervals?.token).toBe('Z-DRUGE'); expect(s.accentHex).toBe('#84CC16')
    expect(s.fieldAt?.intervals).toBe(NOW)
  })
  it('»Nov pogovor« (uporabnik je videl sporočila) zabeleži clearedAt; newCoachChat tudi', async () => {
    await store.updateSettings({ coach: { msgs: [{ role: 'user', text: 'a', at: NOW }], summary: null } })
    await store.updateSettings({ coach: { msgs: [], summary: null } })
    expect((await repo.loadSettings()).coach?.clearedAt).toBeTruthy()
    await store.updateSettings({ coach: { msgs: [{ role: 'user', text: 'b', at: new Date(Date.now() + 1000).toISOString() }], summary: null } })
    await store.newCoachChat()
    const c = (await repo.loadSettings()).coach!
    expect(c.msgs).toEqual([]); expect(c.clearedAt! > NOW).toBe(true)
  })
  it('selitev starega pogovora na novi napravi (prazen seznam), ko je sinhronizacija že zapisala pogovor računa: NI izbris', async () => {
    // zaslon pogovora še ni videl (state.settings.coach je undefined), v shrambi pa je že pogovor z računa
    await store.reloadAll()
    expect(store.getState().settings.coach).toBeUndefined()
    const cur = await repo.loadSettings()
    await setKV(KV.settings, { ...cur, coach: { msgs: [{ role: 'user', text: 'z računa', at: NOW }, { role: 'ai', text: 'odgovor', at: NOW }], summary: 'zapiski' } } as Settings)
    await store.updateSettings({ coach: { msgs: [], summary: null } })
    const c = (await repo.loadSettings()).coach!
    expect(c.clearedAt ?? null).toBeNull()
    expect(c.msgs.map(m => m.text)).toEqual(['z računa', 'odgovor'])
    expect(c.summary).toBe('zapiski')
  })
})

describe('račun', () => {
  it('izbris računa: strežnik → odklop OAuth žetona → odjava → vse na napravi pobrisano (tudi ključi prve različice)', async () => {
    await store.updateSettings({ intervals: { athleteId: '0', apiKey: '', token: 'tok' }, pilot: { id: 'anon1' } })
    await repo.putMeal({ id: 'm1', date: today, slot: 'kosilo', name: 'x', kcal: 500, source: 'manual', createdAt: NOW })
    localStorage.setItem('forma_trener_v1', '{"rides":[]}')
    const f = vi.fn(async (_u: string, _i?: RequestInit) => new Response('', { status: 200 })); vi.stubGlobal('fetch', f)
    await store.boot()   // namesti kljuke za izbris
    fb.signedOut = 0
    const r = await store.deleteAccountAll()
    expect(r.ok).toBe(true)
    expect(fb.pilot).toBe('anon1')
    expect(f.mock.calls.some(([u, i]) => /disconnect-app/.test(String(u)) && i?.method === 'DELETE')).toBe(true)
    expect(fb.signedOut).toBe(1)
    expect(await repo.allMeals()).toHaveLength(0)
    expect((await repo.loadSettings()).intervals ?? null).toBeNull()
    expect(localStorage.getItem('forma_trener_v1')).toBeNull()
    expect(store.getState().user).toBeNull()
  })
  it('neuspel izbris: podatki ostanejo', async () => {
    await repo.putMeal({ id: 'm1', date: today, slot: 'kosilo', name: 'x', kcal: 500, source: 'manual', createdAt: NOW })
    fb.deleteRes = { ok: false, reauth: true, error: 'Za izbris računa potrdi prijavo z Googlom in poskusi znova.' }
    const r = await store.deleteAccountAll()
    expect(r).toEqual({ ok: false, reauth: true, error: 'Za izbris računa potrdi prijavo z Googlom in poskusi znova.' })
    expect(await repo.allMeals()).toHaveLength(1)
    fb.deleteRes = { ok: true, reauth: false }
  })
  it('drug račun: »Počisti in nadaljuj« pobriše podatke prejšnjega; »Odjava« jih pusti in odjavi', async () => {
    await repo.putMeal({ id: 'm1', date: today, slot: 'kosilo', name: 'x', kcal: 500, source: 'manual', createdAt: NOW })
    fb.signedOut = 0
    await store.cancelAccountSwitch()
    expect(fb.signedOut).toBe(1); expect(await repo.allMeals()).toHaveLength(1); expect(store.getState().accountClash).toBeNull()
    await store.acceptAccountSwitch()
    expect(await repo.allMeals()).toHaveLength(0)
    expect(store.getState().accountClash).toBeNull()
  })
  it('firstSync: boolean nadomestek', () => {
    expect(store.firstSyncDone({ firstSync: null })).toBe(false)
    expect(store.firstSyncDone({ firstSync: 'error' })).toBe(true)
    expect(store.firstSyncOk({ firstSync: 'error' })).toBe(false)
    expect(store.firstSyncOk({ firstSync: 'empty' })).toBe(true)
  })
})
