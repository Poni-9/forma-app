// v3.48 — po združitvi: kartica cilja (Napredek) pove začetek in polne ure po istem pravilu kot vrstica o urah na Planu.
import { describe, it, expect } from 'vitest'
import { plannedMacro, rampOf, planHours, targetHours } from '@/domain/training/planner'
import { weekStartIso, addDays as addDaysIso } from '@/domain/training/load'
import type { Activity, Profile } from '@/domain/types'

const TODAY = '2026-10-17'
const NOW = Date.parse(`${TODAY}T10:00:00`)
const P = {
  sex: 'm', age: 30, heightCm: 180, weightKg: 75, ftp: 250, ftpDate: '2026-10-01', maxHr: 190, restHr: 50, level: 3, hoursPerWeek: 11, hoursMode: 'own',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true }, strength: { on: false, equipment: 'none' }, strengthDays: 0,
  onboardingDone: true, goal: 'dirka', createdAt: NOW, updatedAt: NOW, cycleStart: '2026-09-21',
  event: { name: 'Maraton Franja', date: '2027-06-13', distanceKm: 156, type: 'maraton' },
} as unknown as Profile
const ride = (date: string, min: number): Activity => ({ id: 'a' + date, source: 'manual', sport: 'kolo', date, name: 'Vožnja', durationMin: min, tss: 50 } as Activity)
const ACTS = ['2026-09-22', '2026-09-26', '2026-09-29', '2026-10-03', '2026-10-06', '2026-10-10'].map(d => ride(d, 105))

describe('rampOf (kartica cilja = Plan)', () => {
  it('ta teden iz načrta, polne ure največ izbrane, od tedna, ko jih načrt res doseže', () => {
    const r = rampOf(P, ACTS, TODAY)
    expect(r.now).toBe(planHours(P, ACTS, weekStartIso(TODAY), TODAY).hours)
    expect(r.now).toBeLessThan(8)                       // ne zgornja meja faze (9,5 h)
    expect(r.to).toBeLessThanOrEqual(targetHours(P))
    expect(r.at).not.toBeNull()
    const w = plannedMacro(P, ACTS, TODAY).find(x => x.weekStart === r.at)!
    expect(w.hours).toBeGreaterThanOrEqual(r.to - 0.01)
    // pred tem tednom (brez razbremenilnih) načrt polnih ur še ne doseže
    const before = plannedMacro(P, ACTS, TODAY).filter(x => x.weekStart > weekStartIso(TODAY) && x.weekStart < r.at! && !x.recovery)
    expect(before.every(x => x.hours < r.to - 0.01)).toBe(true)
  })
})

describe('napoved ur je ista ves teden (S1) in je ne premakne vožnja v prihodnosti (N1)', () => {
  // stalno 6 h na teden: torek 1,5 h, četrtek 1,5 h, sobota 3 h
  const acts: Activity[] = []
  for (let ws = '2026-08-31'; ws <= '2026-10-19'; ws = addDaysIso(ws, 7)) acts.push(ride(addDaysIso(ws, 1), 90), ride(addDaysIso(ws, 3), 90), ride(addDaysIso(ws, 5), 180))
  const upTo = (d: string) => acts.filter(a => a.date <= d)
  it('ponedeljek in nedelja istega tedna: enak datum polnih ur in iste ure za tedne naprej', () => {
    const mon = rampOf(P, upTo('2026-10-19'), '2026-10-19'), sun = rampOf(P, upTo('2026-10-25'), '2026-10-25')
    expect(sun.at).toBe(mon.at)
    const h = (t: string) => plannedMacro(P, upTo(t), t).filter(w => w.weekStart >= '2026-11-02').slice(0, 6).map(w => w.hours)
    expect(h('2026-10-25')).toEqual(h('2026-10-19'))
  })
  it('ena vožnja z napačnim datumom (2027) ne zruši napovedi na 4 h', () => {
    const bad = [...upTo('2026-10-17'), ride('2027-02-01', 60)]
    const ok = upTo('2026-10-17')
    expect(planHours(P, bad, '2026-11-02', TODAY).hours).toBe(planHours(P, ok, '2026-11-02', TODAY).hours)
  })
})

describe('ciljna teža samo, ko je teža cilj (V1 po pregledu)', async () => {
  const { shownTargetWeight } = await import('@/domain/nutrition/body')
  const base = { sex: 'm', age: 40, heightCm: 180, weightKg: 76 } as unknown as Profile
  it('kolesar s ciljem z datumom ali hujšanje: izračunana; »forma«, načrt po meri in mladoletni: nič', () => {
    expect(shownTargetWeight({ ...base, goal: 'dirka', event: { name: 'Franja', date: '2027-06-13' } } as Profile, false, TODAY)).not.toBeNull()
    expect(shownTargetWeight({ ...base, goal: 'shujsati' } as Profile, true, TODAY)).not.toBeNull()
    expect(shownTargetWeight({ ...base, goal: 'forma' } as Profile, true, TODAY)).toBeNull()
    expect(shownTargetWeight({ ...base, goal: 'hitrejsi' } as Profile, false, TODAY)).toBeNull()
    expect(shownTargetWeight({ ...base, age: 17, goal: 'shujsati', bodyFatPct: 20 } as Profile, false, TODAY)).toBeNull()
    expect(shownTargetWeight({ ...base, goal: 'forma', targetWeightKg: 72 } as Profile, true, TODAY)).toBe(72)
  })
})
