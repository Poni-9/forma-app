// v3.50 UVOD (shramba): H38 — dogovor pozno zvečer: »Danes je že pozno — začneva …« z dnem prvega treninga (prej vedno
// »jutri«, jutri pa je bil počitek); H04 — FTP iz uvoda gre v profil.
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeAll, afterAll, beforeEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

const TUE = '2026-10-20'
beforeAll(() => { vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date(`${TUE}T23:57:00`)) })
afterAll(() => { vi.useRealTimers() })

describe('H38 + H04 dogovor ob 23:57', () => {
  let store: typeof import('../src/state/store')
  beforeEach(async () => {
    store = await import('../src/state/store')
    const repo = await import('../src/data/repo')
    await repo.wipeAll(); localStorage.clear(); await store.reloadAll()
  })
  it('prvi trening v četrtek: »začneva v četrtek«, ne »jutri«; FTP v profilu', async () => {
    const { ruleProposal } = await import('../src/domain/focus/rules')
    const { composeWish } = await import('../src/domain/focus/choices')
    expect(store.getState().today).toBe(TUE)
    // čas samo v četrtek in soboto → jutri (sreda) je počitek
    const wish = composeWish({ cilj: ['Zdravje in počutje'], delam: ['Vadba doma'], raven: ['Začenjam'] }, 'Dva dni na teden po pol ure.')
    const f = ruleProposal(wish, [{ id: 'kje', q: 'Kakšno opremo imaš doma?', a: 'Nič' }], 52, { avail: [3, 5], today: TUE }).focus
    await store.applyAgreement(f, { sex: 'z', age: 52, heightCm: 162, weightKg: 70, trainTime: null, ftp: 210, ftpDate: TUE })
    const today = store.getState().plan.find(d => d.date === TUE)!
    expect(today.desc).toBe('Danes je že pozno — začneva v četrtek.')
    expect(store.getState().profile.ftp).toBe(210)
    expect(store.getState().profile.ftpDate).toBe(TUE)
  })
  it('jutri trening: »začneva jutri« (kot prej)', async () => {
    const { ruleProposal } = await import('../src/domain/focus/rules')
    const { composeWish } = await import('../src/domain/focus/choices')
    const wish = composeWish({ cilj: ['Zdravje in počutje'], delam: ['Vadba doma'], raven: ['Začenjam'] }, 'Dva dni na teden po pol ure.')
    const f = ruleProposal(wish, [{ id: 'kje', q: 'Kakšno opremo imaš doma?', a: 'Nič' }], 52, { avail: [2, 4], today: TUE }).focus
    await store.applyAgreement(f, { sex: 'z', age: 52, heightCm: 162, weightKg: 70, trainTime: null })
    expect(store.getState().plan.find(d => d.date === TUE)!.desc).toBe('Danes je že pozno — začneva jutri.')
  })
})
