// v3.48 D2: past fokusa v listih in inert ozadje, fokus po izbrisu, naslovi (h1/h2), aria-pressed, avatar brez imena,
// imena zaslonov (naslov strani, pripomba), namestitev brez računa, Vaje (lazy, figure izven zaslona, kardio), ročni vnos moči.
import { act, useState, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { renderToStaticMarkup } from 'react-dom/server'
import { readFileSync } from 'node:fs'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>() }))
const store = vi.hoisted(() => ({
  toast: vi.fn(), addActivities: vi.fn(async () => ({ added: 1, upgraded: 0, dupes: 0 })), removeActivity: vi.fn(async () => {}), setPlanDone: vi.fn(async () => {}),
  saveActivity: vi.fn(async () => {}), rateSession: vi.fn(async () => {}), updateSettings: vi.fn(async () => {}),
  answerPilot: vi.fn(), skipPilot: vi.fn(), optOutPilot: vi.fn(), syncIntervals: vi.fn(),
}))
vi.mock('@/state/store', () => ({
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  ...store,
}))

import { Sheet, Option, Empty } from '@/ui/primitives'
import { Section } from '@/ui/Section'
import { Head, Shell, initialsOf } from '@/app/Shell'
import { SCREEN_NAME, pageTitle } from '@/ui/screenNames'
import { InstallSheet } from '@/ui/InstallSheet'
import { ExercisePhoto } from '@/ui/figure/ExercisePhoto'
import { ExerciseFigure } from '@/ui/figure/ExerciseFigure'
import { Vaje, CARDIO } from '@/screens/Vaje'
import { Aktivnosti, manualFields } from '@/screens/Aktivnosti'
import { UndoHost, deferDelete, useHidden, _resetUndo } from '@/ui/Confirm'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

const base = () => ({
  ready: true, today: '2026-10-17', user: null, sync: { state: 'off' }, toast: null, settings: {}, plan: [], activities: [], recentMeals: [], checkins: [],
  profile: { name: '', onboardingDone: true, createdAt: '2026-10-17T08:00:00.000Z', gear: {}, strength: {} },
})
const setState = (patch: Record<string, unknown>) => { S.state = { ...S.state, ...patch }; for (const f of S.subs) f() }
const wait = (ms = 20) => act(async () => { await new Promise(r => setTimeout(r, ms)) })
const tab = async (shift = false) => act(async () => { (document.activeElement || document.body).dispatchEvent(new KeyboardEvent('keydown', { key: 'Tab', shiftKey: shift, bubbles: true, cancelable: true })) })
const dialog = () => document.querySelector('[role="dialog"]') as HTMLElement | null
const byId = (id: string) => document.getElementById(id) as HTMLElement

let host: HTMLDivElement, root: Root
beforeEach(() => {
  S.state = base()
  history.replaceState(null, '', '#/danes')
  host = document.createElement('div'); host.id = 'root'; document.body.appendChild(host); root = createRoot(host)
})
afterEach(async () => { await act(async () => root.unmount()); host.remove(); _resetUndo(); document.body.innerHTML = '' })

describe('D06 — list: Tab ostane v listu, ozadje je inert', () => {
  function Page() {
    const [open, setOpen] = useState(false)
    return (<>
      <div className="app"><button id="open" onClick={() => setOpen(true)}>odpri</button></div>
      <div className="toast-host" />
      <Sheet open={open} onClose={() => setOpen(false)}><b>List</b><button id="a">prvi</button><input id="hid" type="hidden" /><button id="b" onClick={() => setOpen(false)}>zadnji</button></Sheet>
    </>)
  }
  it('z zadnjega na prvega, s Shift s prvega na zadnjega, od zunaj nazaj v list; po zaprtju ozadje spet dosegljivo', async () => {
    await act(async () => { root.render(<Page />) })
    byId('open').focus()
    await act(async () => { byId('open').click() })
    const d = dialog()!
    expect(host.querySelector('.app')!.hasAttribute('inert')).toBe(true)
    expect(host.querySelector('.toast-host')!.hasAttribute('inert')).toBe(false)   // obvestila bralnik še prebere
    for (let i = 0; i < 3; i++) { await tab(); expect(d.contains(document.activeElement)).toBe(true) }
    byId('b').focus(); await tab()
    expect(document.activeElement).toBe(byId('a'))
    await tab(true)
    expect(document.activeElement).toBe(byId('b'))
    const out = document.createElement('button'); document.body.appendChild(out); out.focus()
    await tab()
    expect(document.activeElement).toBe(byId('a'))
    await act(async () => { byId('b').click() })
    await wait()
    expect(dialog()).toBeNull()
    expect(host.querySelector('.app')!.hasAttribute('inert')).toBe(false)
    expect(document.activeElement).toBe(byId('open'))
  })
})

describe('D28 — po izbrisu v listu fokus na »Razveljavi«, ne na body', () => {
  function Page() {
    const [open, setOpen] = useState(false)
    const hidden = useHidden()
    return (<>
      {!hidden.has('act:1') && <button id="card" className="act-open" onClick={() => setOpen(true)}>Vožnja</button>}
      <UndoHost />
      <Sheet open={open} onClose={() => setOpen(false)}><b>Vožnja</b><button id="del" onClick={() => { setOpen(false); deferDelete('act:1', 'Izbrisano: Vožnja', () => {}) }}>Izbriši</button></Sheet>
    </>)
  }
  it('kartica, ki je list odprla, izgine → fokus na gumb »Razveljavi«', async () => {
    await act(async () => { root.render(<Page />) })
    byId('card').focus()
    await act(async () => { byId('card').click() })
    await act(async () => { byId('del').click() })
    await wait()
    expect(document.getElementById('card')).toBeNull()
    expect(document.activeElement?.textContent).toBe('Razveljavi')
  })
})

describe('naslovi in izbire (D19, D25, D27)', () => {
  it('Option z on ima aria-pressed, brez on ne', () => {
    expect(renderToStaticMarkup(<Option icon={null} title="Zunaj" on />)).toContain('aria-pressed="true"')
    expect(renderToStaticMarkup(<Option icon={null} title="Zunaj" on={false} />)).toContain('aria-pressed="false"')
    expect(renderToStaticMarkup(<Option icon={null} title="Garmin" />)).not.toContain('aria-pressed')
  })
  it('razdelek je naslov h2 z gumbom; prazno stanje ima h2', () => {
    const sec = renderToStaticMarkup(<Section id="n-profil" title="Profil" open={false} onToggle={() => {}}>x</Section>)
    expect(sec).toMatch(/<h2 class="sec-t"><button[^>]*aria-expanded="false"[^>]*>.*Profil.*<\/button><\/h2>/)
    const em = renderToStaticMarkup(<Empty icon={null} title="Še ni treningov" text="…" />)
    expect(em).toContain('<h2>Še ni treningov</h2>')
    expect(em).not.toContain('<h3')
  })
})

describe('D22 + D24 — avatar in namizna navigacija', () => {
  it('initialsOf: brez imena null (ne »F«), sicer začetnici', () => {
    expect(initialsOf('')).toBeNull()
    expect(initialsOf('   ')).toBeNull()
    expect(initialsOf(undefined)).toBeNull()
    expect(initialsOf('Blaž Gregorc')).toBe('BG')
    expect(initialsOf('ana')).toBe('A')
  })
  it('glava brez imena: ikona osebe; obema avatarjema isto ime; namizna navigacija z imenom in aria-current', async () => {
    history.replaceState(null, '', '#/plan')
    await act(async () => { root.render(<Shell><Head hi="Teden" nm="Plan" /></Shell>) })
    const avatars = [...host.querySelectorAll('button.avatar')]
    expect(avatars.length).toBe(2)
    for (const a of avatars) {
      expect(a.getAttribute('aria-label')).toBe('Nastavitve in profil')
      expect(a.querySelector('svg')).not.toBeNull()
      expect(a.textContent).toBe('')
    }
    const nav = host.querySelector('nav.dnav')!
    expect(nav.getAttribute('aria-label')).toBe('Glavna navigacija')
    const cur = [...nav.querySelectorAll('button')].filter(b => b.getAttribute('aria-current') === 'page').map(b => b.textContent)
    expect(cur).toEqual(['Plan'])
    await act(async () => { setState({ profile: { ...S.state.profile, name: 'Blaž Gregorc' } }) })
    expect(host.querySelector('header .avatar')!.textContent).toBe('BG')
  })
})

describe('D23 + D41 — imena zaslonov', () => {
  it('naslov strani po zaslonu', () => {
    expect(pageTitle('plan')).toBe('Plan · FORMAI')
    expect(pageTitle('danes')).toBe('Danes · FORMAI')
    expect(pageTitle('nekaj')).toBe('Danes · FORMAI')
  })
  it('vsaka pot iz App (in danes, vaje) ima ime z veliko začetnico — tudi v pripombi', () => {
    const src = readFileSync('src/app/App.tsx', 'utf8')
    const keys = new Set<string>(['danes', 'vaje'])
    for (const m of src.matchAll(/case '([a-z]+)':/g)) keys.add(m[1]!)
    const by = src.split('const BY_ROUTE')[1]!.split('> = {')[1]!.split('}')[0]!
    for (const m of by.matchAll(/([a-z]+):/g)) keys.add(m[1]!)
    expect(keys.size).toBeGreaterThan(12)
    for (const k of keys) expect(SCREEN_NAME[k], k).toMatch(/^[A-ZČŠŽ]/)
    expect(SCREEN_NAME.pilot).toBe('Pregled')
    expect(SCREEN_NAME.claude).toBe('Povabilo')
    expect(readFileSync('src/ui/FeedbackSheet.tsx', 'utf8')).toContain('SCREEN_NAME[route]')
  })
})

describe('D32 — namestitev ne obljublja sinhronizacije brez računa', () => {
  it('brez prijave: načrt ostane na napravi; s prijavo: sinhronizacija', async () => {
    await act(async () => { root.render(<InstallSheet open onClose={() => {}} />) })
    expect(dialog()!.textContent).toContain('Brez prijave ostane načrt na tej napravi')
    expect(dialog()!.textContent).not.toContain('sinhronizirata')
    await act(async () => { setState({ user: { uid: 'u', name: 'Blaž', email: 'b@x.si' } }) })
    expect(dialog()!.textContent).toContain('Načrt in prehrana se sinhronizirata sama.')
  })
})

describe('D09 + D37 — Vaje', () => {
  let ioCb: ((e: { isIntersecting: boolean }[]) => void) | null = null
  const origIO = (globalThis as any).IntersectionObserver
  afterEach(() => { (globalThis as any).IntersectionObserver = origIO; delete (window as any).matchMedia; vi.restoreAllMocks() })

  it('fotografije vaj se nalagajo lenobno', () => {
    const html = renderToStaticMarkup(<ExercisePhoto id="sklece" size={150} />)
    expect(html.match(/loading="lazy"/g)?.length).toBe(2)
    expect(renderToStaticMarkup(<ExercisePhoto id="sklece" lazy={false} />)).not.toContain('loading=')
  })
  it('figura izven zaslona ne teče (requestAnimationFrame šele, ko je vidna)', async () => {
    ;(globalThis as any).IntersectionObserver = class { constructor(cb: any) { ioCb = cb } observe() {} disconnect() {} }
    ;(window as any).matchMedia = () => ({ matches: false })
    const raf = vi.spyOn(window, 'requestAnimationFrame').mockImplementation(() => 1)
    const caf = vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => {})
    await act(async () => { root.render(<ExerciseFigure id="tek" size={150} />) })
    expect(raf).not.toHaveBeenCalled()
    await act(async () => { ioCb!([{ isIntersecting: true }]) })
    expect(raf).toHaveBeenCalled()
    await act(async () => { ioCb!([{ isIntersecting: false }]) })
    expect(caf).toHaveBeenCalled()
  })
  it('Tek, Hoja, Kolo so gumbi; tap odpre kratek opis', async () => {
    ;(window as any).matchMedia = () => ({ matches: true })   // zmanjšano gibanje: figure stojijo
    await act(async () => { root.render(<Vaje />) })
    expect(CARDIO.map(c => c.name)).toEqual(['Tek', 'Hoja', 'Kolo'])
    const t = byId('v-tek')
    expect(t.tagName).toBe('BUTTON')
    expect(byId('v-kolo').tagName).toBe('BUTTON')
    await act(async () => { t.click() })
    expect(dialog()!.getAttribute('aria-label')).toBe('Tek')
    expect(dialog()!.textContent).toContain('celih stavkih')
  })
})

describe('D44 — ročni vnos moči', () => {
  it('polja po športu', () => {
    expect(manualFields('moc')).toEqual({ dist: false, elev: false, power: false })
    expect(manualFields('plavanje')).toEqual({ dist: true, elev: false, power: false })
    expect(manualFields('kolo')).toEqual({ dist: true, elev: true, power: true })
  })
  it('pri Moči ni km, vzpona in vatov; ime vaje čez celo širino; vpisan km pri moči se ne shrani', async () => {
    history.replaceState(null, '', '#/aktivnosti?nova=1')
    await act(async () => { root.render(<Aktivnosti />) })
    const d = dialog()!
    expect(d.querySelector('#ak-km')).not.toBeNull()
    // pri kolesu vpiši km, nato preklopi na Moč
    const km = d.querySelector('#ak-km') as HTMLInputElement
    await act(async () => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(km, '9999'); km.dispatchEvent(new Event('input', { bubbles: true })) })
    const moc = [...d.querySelectorAll('button')].find(b => b.textContent === 'Moč')!
    await act(async () => { moc.click() })
    expect(d.querySelector('#ak-km')).toBeNull()
    expect(d.querySelector('#ak-elev')).toBeNull()
    expect(d.querySelector('#ak-w')).toBeNull()
    expect(d.querySelector('#ak-hr')).not.toBeNull()
    const row = d.querySelector('.exrow.ex2')!
    expect(row.querySelector('input.ex-name')).not.toBeNull()
    const min = d.querySelector('#ak-min') as HTMLInputElement
    await act(async () => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(min, '45'); min.dispatchEvent(new Event('input', { bubbles: true })) })
    const save = [...d.querySelectorAll('button')].find(b => b.textContent === 'Shrani')!
    await act(async () => { save.click() })
    expect(store.addActivities).toHaveBeenCalledTimes(1)
    const a = (store.addActivities.mock.calls[0] as unknown as [{ sport: string; distKm: unknown; durationMin: number }[]])[0][0]!
    expect(a).toMatchObject({ sport: 'moc', distKm: null, durationMin: 45 })
  })
})
