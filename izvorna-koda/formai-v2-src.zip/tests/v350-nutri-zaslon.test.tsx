// v3.50 NUTRI-ZASLON — Prehrana (dan): gorivo po vožnji v kratkem pogledu, preskočen obrok, beljakovine nad ciljem,
// razlaga cilja po vrsticah, tehtanje brez stare teže, slika in opis brez AI/prijave, »Ne« pri »Si ga opravil?«,
// pozna večerja, vpis za včeraj po polnoči, 7 dni, kopiranje brez odložišča in drobni popravki besedil.
import 'fake-indexeddb/auto'
import { act, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>(), route: { name: 'prehrana', params: {} as Record<string, string> }, added: [] as any[], done: [] as any[], toasts: [] as string[], signIns: 0, removed: [] as string[] }))
vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => { S.signIns++; return null }, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
vi.mock('@/state/store', async (orig) => ({
  ...(await orig<typeof import('../src/state/store')>()),
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  addMeal: async (m: unknown) => { S.added.push(m) },
  removeMeal: async (id: string) => { S.removed.push(id) },
  setPlanDone: async (...a: unknown[]) => { S.done.push(a) },
  toast: (m: string) => { S.toasts.push(m) },
}))
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => S.route, subscribeRoute: () => () => undefined }))

import * as repo from '../src/data/repo'
import { Prehrana, DayBalance, eveningHint, scaleDraft, targetRows } from '@/screens/Prehrana'
import { weightStable } from '@/screens/Danes'
import { WeighSheet } from '@/ui/WeighSheet'
import { Checkin } from '@/ui/Checkin'
import { BarChart } from '@/ui/charts'
import { copyText, fmtTime } from '@/ui/format'
import { dayMealPlan, adjustToEaten } from '../src/domain/nutrition/dayplan'
import { dayMealsOf, nextSlotOf, slotFor } from '../src/domain/nutrition/daymeals'
import { dailyTarget, type DailyTarget } from '../src/domain/nutrition/energy'
import { estimateMeal } from '../src/domain/nutrition/localMeal'
import { FRANJA_2027 } from '../src/domain/training/planner'
import type { MealEntry, PlanDay, Profile } from '../src/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const NOW = '2026-10-01T08:00:00.000Z'
const TODAY = '2026-10-17'   // sobota
const P = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, restHr: 55, maxHr: 200, lthr: 184, ftp: 240, ftpDate: '2026-09-20',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: false }, hoursPerWeek: 14, baseHours: null,
  strength: { on: false, equipment: 'home', phases: null }, strengthDays: 0, goal: 'dirka', deficit: 400, neat: 1.4,
  event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', onboardingDone: true, trainTime: 'popoldne', createdAt: NOW, updatedAt: NOW,
  races: [], ...o,
} as Profile)
const planDay = (date: string, min: number, o: Partial<PlanDay> = {}): PlanDay => ({ id: 'r' + date, date, kind: 'kolo', title: 'Dolga Z2', desc: '', durationMin: min, zone: 'Z2', role: 'dolga', source: 'rules', createdAt: NOW, updatedAt: NOW, ...o })
const meal = (date: string, slot: MealEntry['slot'], kcal: number, o: Partial<MealEntry> = {}): MealEntry => ({ id: `${date}-${slot}-${kcal}-${o.name || ''}-${o.time || ''}`, date, slot, name: o.name || slot, kcal, source: 'manual', createdAt: NOW, time: o.time ?? null, ...o })
const T = { kcal: 2141, proteinG: 150, carbsG: 250, deficit: 0 }
const PP = { weightKg: 79, trainTime: 'popoldne' as const }

/* ---------- domena ---------- */

describe('D03 — preskočen obrok ni več prihodnji', () => {
  const p = P({ deficit: 0 })
  const target = dailyTarget(p, [], [], TODAY, { today: TODAY, hour: 14 })!
  const ms = [meal(TODAY, 'kosilo', 745, { time: '13:00' })]
  const at = (hour: number | null, m: MealEntry[] = ms) => dayMealsOf({ p, target, plan: [], activities: [], meals: m, recentMeals: [], weather: null, day: TODAY, today: TODAY, hour })
  it('ob 14h brez vpisanega zajtrka: zajtrk »ni vpisan«, kalorije gredo v malico in večerjo (največ 1,35 ×)', () => {
    const base = at(null).dp, dp = at(14).dp
    const zaj = dp.slots.find(s => s.key === 'zajtrk')!
    expect(zaj.skipped).toBe(true)
    const open = (d: typeof dp) => d.slots.filter(s => s.key === 'malica' || s.key === 'vecerja').reduce((a, s) => a + s.kcal, 0)
    expect(open(dp)).toBeGreaterThan(open(base))
    const plan0 = dayMealPlan(p, target, null)
    expect(open(dp)).toBeLessThanOrEqual(Math.round(plan0.slots.filter(s => s.key === 'malica' || s.key === 'vecerja').reduce((a, s) => a + s.kcal, 0) * 1.35) + 20)
    expect(nextSlotOf(dp, ms, 14)!.key).toBe('malica')
  })
  it('brez enega vpisa dneva ne preskoči (nevpisano ne pomeni nepojedeno)', () => {
    expect(at(14, []).dp.slots.some(s => s.skipped)).toBe(false)
  })
})

describe('D04 — nad ciljem beljakovinski prigrizek, ne »Večerja 30 kcal«', () => {
  const rest = dayMealPlan(PP, T, null)
  const ms = [meal(TODAY, 'zajtrk', 600, { time: '07:30', proteinG: 30 }), meal(TODAY, 'kosilo', 1500, { time: '13:00', proteinG: 68 })]
  it('manjka 52 g beljakovin: večerja ~250 kcal z beljakovinami (skuta), malica je drobiž in ni »naslednji«', () => {
    const dp = adjustToEaten(rest, ms, T.kcal, { proteinLeft: 52 })
    const v = dp.slots.find(s => s.key === 'vecerja')!, m = dp.slots.find(s => s.key === 'malica')!
    expect(v.kcal).toBeGreaterThanOrEqual(250)
    expect(v.proteinG).toBeGreaterThanOrEqual(20)
    expect(v.example).toMatch(/skuta/)
    expect(m.kcal).toBeLessThan(120)
    expect(nextSlotOf(dp, ms, 15)!.key).toBe('vecerja')
  })
  it('beljakovine dosežene: brez prigrizka (večerja ostane drobiž)', () => {
    expect(adjustToEaten(rest, ms, T.kcal, { proteinLeft: 5 }).slots.find(s => s.key === 'vecerja')!.kcal).toBeLessThan(120)
  })
})

describe('D01 + D07 — po vožnji brez vpisa goriva', () => {
  it('fuelMissing in obroki največ 1,15 × (prej 1,35 ×)', () => {
    const ride = { kind: 'kolo' as const, durationMin: 180, zone: 'Z2', role: 'dolga' as const, title: 'Dolga Z2' }
    const T2 = { kcal: 3700, proteinG: 150, carbsG: 520, deficit: 0 }
    const dp0 = dayMealPlan(PP, T2, ride, { rideDone: true })
    const ms = [meal(TODAY, 'zajtrk', 700, { time: '07:30' })]
    const dp = adjustToEaten(dp0, ms, T2.kcal, { rideDone: true })
    expect(dp.fuelMissing).toBe(true)
    for (const s of dp.slots.filter(x => x.key !== 'zajtrk')) {
      const s0 = dp0.slots.find(x => x.key === s.key)!
      expect(s.kcal).toBeLessThanOrEqual(Math.round((s0.kcal * 1.15) / 10) * 10 + 10)
    }
    // z vpisanim gorivom ni »fuelMissing«
    expect(adjustToEaten(dp0, [...ms, meal(TODAY, 'med_vadbo', 600, { time: '10:00' })], T2.kcal, { rideDone: true }).fuelMissing).toBeFalsy()
  })
})

describe('D37 + H37 — pozna večerja', () => {
  const dp = dayMealPlan(PP, T, null)
  it('21:30 brez večerje je večerja, z vpisano večerjo »drugo«', () => {
    expect(slotFor('21:30', dp, [])).toBe('vecerja')
    expect(slotFor('21:30', dp, [{ slot: 'vecerja' }])).toBe('drugo')
    expect(slotFor('23:30', dp, [])).toBe('drugo')
  })
  it('ob 23h ni več predloga večerje (prej ob 23:58 »Večerja 502 kcal«); ob 21h je', () => {
    const ms = [meal(TODAY, 'kosilo', 800, { time: '13:00' })]
    expect(nextSlotOf(dp, ms, 21)!.key).toBe('vecerja')
    expect(nextSlotOf(dp, ms, 23)).toBeNull()
  })
})

describe('D29, D22, D28, D18, D46, D32, E46 — drobno', () => {
  it('D29: ×2 in nato ½ vrne prvotno količino (prej »100 g ×2 ×½«)', () => {
    const d = { kcal: '400', grams: '', prot: '', carb: '', fat: '', items: [{ name: 'riž', qty: '100 g', kcal: 400 }] }
    expect(scaleDraft(scaleDraft(d, 2), 0.5).items![0]!.qty).toBe('100 g')
    expect(scaleDraft(scaleDraft(d, 1.5), 0.5).items![0]!.qty).toBe('100 g ×¾')
    expect(scaleDraft(scaleDraft(d, 2), 1.5).items![0]!.qty).toBe('100 g ×3')
  })
  it('D22: »ne jej na silo« ob 20:30 samo, ko je vpisan vsaj en obrok', () => {
    expect(eveningHint(20.6, [], { plannedBurn: 0 })).toBe(false)
    expect(eveningHint(20.6, [{ slot: 'med_vadbo' }], { plannedBurn: 0 })).toBe(false)
    expect(eveningHint(20.6, [{ slot: 'kosilo' }], { plannedBurn: 0 })).toBe(true)
  })
  it('D18: razlaga cilja po vrsticah, »vzdrževanje« enkrat, brez »osnova«', () => {
    const t = { kcal: 3708, maintenance: 2541, burn: 0, plannedBurn: 1685, plannedWas: 0, floor: 1800, proteinG: 150, carbsG: 500, fatG: 90, clampedToFloor: false, minor: false, deficit: 200, deficitNote: 'dolga vožnja, zato pol', restIn: 318, kinds: ['kolo'] } as DailyTarget
    const rows = targetRows(t, {}, { garmin: true })
    expect(rows.map(r => r.label)).toEqual(['Vzdrževanje brez treninga', 'Deficit', 'Trening', 'Cilj'])
    expect(rows[2]!.value).toBe('+1 367')
    expect(rows[2]!.note).toMatch(/po načrtu ~1 685 — popravim, ko vožnja pride z Garmina · od tega 318 že v vzdrževanju/)
    expect(rows[3]!.value).toMatch(/^3 708/)
    expect(JSON.stringify(rows)).not.toMatch(/osnova/)
  })
  it('D46: neznan del opisa s predlogom (»z ajvarjem«, ne »ajvarjem«)', () => {
    expect(estimateMeal('2 rezini kruha z ajvarjem')!.unknown).toEqual(['z ajvarjem'])
    expect(estimateMeal('ajvar, kruh')!.unknown).toEqual(['ajvar'])
  })
  it('D32: tempo v okviru nihanja je »stabilna« (kot Napredek)', () => {
    expect(weightStable({ deltaWeek: -0.05, noise: 0.2 })).toBe(true)
    expect(weightStable({ deltaWeek: -0.05, noise: null })).toBe(true)
    expect(weightStable({ deltaWeek: -0.4, noise: 0.1 })).toBe(false)
  })
  it('D27: ura brez vodilne ničle', () => {
    expect(fmtTime('07:30')).toBe('7:30')
    expect(fmtTime('14:05')).toBe('14:05')
  })
  it('E46: brez odložišča execCommand; vrne, ali je uspelo', async () => {
    const cb = Object.getOwnPropertyDescriptor(navigator, 'clipboard')
    Object.defineProperty(navigator, 'clipboard', { configurable: true, value: undefined })
    const ex = (document as { execCommand?: unknown }).execCommand
    const calls: string[] = []
    ;(document as { execCommand: unknown }).execCommand = (c: string) => { calls.push(c); return true }
    try {
      expect(await copyText('a')).toBe(true)
      expect(calls).toEqual(['copy'])
      ;(document as { execCommand: unknown }).execCommand = () => false
      expect(await copyText('a')).toBe(false)
    } finally {
      ;(document as { execCommand?: unknown }).execCommand = ex
      if (cb) Object.defineProperty(navigator, 'clipboard', cb); else delete (navigator as { clipboard?: unknown }).clipboard
    }
  })
})

/* ---------- zaslon ---------- */

let div: HTMLDivElement, root: Root
async function render(el: React.ReactElement) {
  div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div)
  await act(async () => { root.render(el) })
  return text()
}
const text = () => (document.body.textContent || '').replace(/[  ]/g, ' ')
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(b.textContent || '') || re.test(b.getAttribute('aria-label') || ''))
async function click(el: Element | undefined | null) { expect(el).toBeTruthy(); await act(async () => { (el as HTMLElement).click(); await new Promise(r => setTimeout(r, 0)) }) }
async function typeIn(el: Element | null, v: string) {
  expect(el).toBeTruthy()
  const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype
  await act(async () => { Object.getOwnPropertyDescriptor(proto, 'value')!.set!.call(el, v); el!.dispatchEvent(new Event('input', { bubbles: true })) })
}
const planCard = () => [...document.querySelectorAll('.card')].find(c => /po načrtu/.test(c.querySelector('h2')?.textContent || ''))?.textContent?.replace(/[  ]/g, ' ') || ''
afterEach(async () => {
  await act(async () => root?.unmount()); div?.remove(); vi.useRealTimers()
  S.added.length = 0; S.done.length = 0; S.toasts.length = 0; S.removed.length = 0; S.signIns = 0; S.route = { name: 'prehrana', params: {} }
  try { localStorage.clear() } catch { /* */ }
})

function setState(o: { meals?: MealEntry[]; recent?: MealEntry[]; plan?: PlanDay[]; profile?: Profile; time?: string; today?: string; checkins?: any[]; activities?: any[] } = {}) {
  const today = o.today || TODAY
  vi.useFakeTimers({ toFake: ['Date'] })
  vi.setSystemTime(new Date(`${today}T${o.time || '08:30'}:00`))
  const meals = o.meals || []
  S.state = { ready: true, settings: repo.defaultSettings(), changes: [], toast: null, sync: { state: 'off' }, authKnown: true, pro: false, wellness: null, checkinToday: null, today, profile: o.profile || P(), plan: o.plan || [], activities: o.activities || [], mealsToday: meals, recentMeals: [...(o.recent || []), ...meals], checkins: o.checkins || [], weather: null, user: null }
}

describe('Prehrana — gorivo po vožnji (D01, D40, D07)', () => {
  it('po vožnji brez vpisa: kratki pogled ima »Na kolesu · ni vpisano« in »vpiši, kaj si porabil«, brez »Vzemi:«', async () => {
    setState({ time: '14:00', plan: [planDay(TODAY, 180, { done: { at: NOW } })], meals: [meal(TODAY, 'zajtrk', 700, { time: '07:00' })] })
    await render(<Prehrana />)
    const c = planCard()
    expect(c).toMatch(/Naslednji obrok po načrtu/)
    expect(c).toMatch(/Na kolesu · 3 hni vpisano/)
    expect(c).toMatch(/Načrt je bil ~\d+ g OH, [\d,]+ l\. Do vpisa obroki računajo, da na kolesu ni bilo nič\./)
    expect(btn(/vpiši, kaj si porabil/)).toBeTruthy()
    expect(c).not.toMatch(/Vzemi:/)
    expect(c).toMatch(/Gorivo na kolesu ni vpisano, zato obroki računajo, da na vožnji ni bilo nič — vpiši ga\./)
    await click(btn(/cel dan po načrtu/))
    expect(planCard()).not.toMatch(/Vzemi:/)
  })
})

describe('Prehrana — obroki dneva (D03, D04, H37, D42, D27, E34)', () => {
  it('D03: ob 14h po kosilu brez zajtrka — »Zajtrk … ni vpisan« z »vpiši«', async () => {
    setState({ time: '14:00', profile: P({ deficit: 0 }), meals: [meal(TODAY, 'kosilo', 745, { time: '13:00' })] })
    await render(<Prehrana />)
    await click(btn(/cel dan po načrtu/))
    expect(planCard()).toMatch(/Zajtrkni vpisan/)
    expect(planCard()).toMatch(/Če si ga jedel, ga vpiši — sicer gre v naslednje obroke\./)
  })
  it('D04: nad ciljem in manjkajo beljakovine — vrstica o beljakovinskem prigrizku, drobiž brez kalorij', async () => {
    setState({ time: '15:00', profile: P({ deficit: 0 }), meals: [meal(TODAY, 'zajtrk', 900, { time: '07:30', proteinG: 30 }), meal(TODAY, 'kosilo', 1800, { time: '13:00', proteinG: 40 })] })
    await render(<Prehrana />)
    expect(planCard()).toMatch(/Kalorije so za danes (presežene|dosežene), beljakovin manjka še \d+ g — zvečer skuta ali jogurt \(~250 kcal\)\. Šteje tedensko povprečje\./)
    expect(planCard()).toMatch(/skuta/)
  })
  it('H37: ob 23:30 brez predloga večerje — »Pozno je …«', async () => {
    setState({ time: '23:30', meals: [meal(TODAY, 'kosilo', 800, { time: '13:00' })] })
    await render(<Prehrana />)
    expect(planCard()).toMatch(/Pozno je — če si lačen, nekaj lahkega z beljakovinami/)
    expect(planCard()).not.toMatch(/Večerja ·/)
  })
  it('D42 + D27: po vpisanem kosilu »Dodaj obrok«, ne »Dodaj kosilo«; ura »7:30«', async () => {
    setState({ time: '14:20', meals: [meal(TODAY, 'zajtrk', 500, { time: '07:30' }), meal(TODAY, 'kosilo', 745, { time: '14:14' })] })
    const t = await render(<Prehrana />)
    expect(t).toMatch(/Dodaj obrok/)
    expect(t).not.toMatch(/Dodaj kosilo/)
    expect(t).toMatch(/Zajtrk · 7:30/)
  })
  it('E34: pretekli dan — recept brez »drug predlog«, »vpiši, da si to jedel«', async () => {
    setState({ time: '10:00' })
    S.route = { name: 'prehrana', params: { dan: '2026-10-15' } }
    await render(<Prehrana />)
    const r = document.querySelector('.slot-row [aria-expanded]')
    await click(r)
    expect(btn(/^drug predlog$/)).toBeFalsy()
    expect(btn(/vpiši, da si to jedel/)).toBeTruthy()
    expect(btn(/vpiši, ko poješ/)).toBeFalsy()
  })
})

describe('Prehrana — obroč, vrstica pod njim, večer, »Si ga opravil?« (D44, D28, D22, D45)', () => {
  it('D44: nad 110 % cilja obroč v barvi opozorila', async () => {
    setState({ time: '20:00', meals: [meal(TODAY, 'kosilo', 4500, { time: '13:00' })] })
    await render(<Prehrana />)
    expect(document.querySelector('.ring.over .ring-fill')?.getAttribute('stroke')).toBe('var(--warn)')
  })
  it('D28: nad ciljem pokaže manjkajoče beljakovine; točno na cilju »Na cilju«', async () => {
    expect(await render(<DayBalance remaining={-300} proteinLeft={40} past={false} logged />)).toBe('Nad ciljem za 300 kcal · še 40 g beljakovin')
    await act(async () => root.unmount()); div.remove()
    expect(await render(<DayBalance remaining={0} proteinLeft={0} past={false} logged />)).toBe('Na cilju · beljakovine dosežene')
  })
  it('D22: ob 20:40 brez vpisov »Danes ni vpisanih obrokov«, ne »ne jej na silo«', async () => {
    setState({ time: '20:40' })
    const t = await render(<Prehrana />)
    expect(t).toMatch(/Danes ni vpisanih obrokov — vpiši vsaj večerjo/)
    expect(t).not.toMatch(/Če si sit, ne jej na silo/)
  })
  it('D45: »Ne« zapre vprašanje (do konca dneva)', async () => {
    setState({ time: '21:30', meals: [meal(TODAY, 'zajtrk', 700, { time: '07:30' })], plan: [planDay(TODAY, 105)] })
    await render(<Prehrana />)
    expect(text()).toMatch(/Si ga opravil\?/)
    expect([...document.querySelectorAll('.missed-ask button')].map(b => b.textContent?.trim())).toEqual(['Opravljeno', 'Ne'])
    await click(btn(/^Ne$/))
    expect(text()).not.toMatch(/Si ga opravil\?/)
    expect(S.toasts).toContain('V redu — cilj je brez tega treninga.')
    // ob ponovnem odprtju zaslona isti dan ne vpraša znova
    await act(async () => root.unmount()); div.remove()
    expect(await render(<Prehrana />)).not.toMatch(/Si ga opravil\?/)
  })
})

describe('Prehrana — list vpisa (D24, D25, D26, D41, D29)', () => {
  it('D24: obvestilo z imenom za dvopičjem (»Dodano: …«)', async () => {
    const oats = (d: string) => meal(d, 'zajtrk', 620, { name: 'Testenine z bolonjsko omako', time: '07:30' })
    setState({ time: '08:00', recent: [oats('2026-10-14'), oats('2026-10-15')] })
    await render(<Prehrana />)
    await click(document.querySelector('[aria-label="Pogosti obroki"] button'))
    expect(S.toasts).toContain('Dodano: Testenine z bolonjsko omako.')
  })
  it('D25: »Uredi vnos« ima »Izbriši vnos«', async () => {
    setState({ time: '12:30', meals: [meal(TODAY, 'zajtrk', 300, { name: 'Jajca s kruhom', time: '07:30' })] })
    await render(<Prehrana />)
    await click(btn(/^Uredi: Jajca s kruhom$/))
    expect(btn(/^Izbriši vnos$/)).toBeTruthy()
  })
  it('D26: pretekli dan — list z datumom, ura prazna = »brez ure: 13:00«', async () => {
    setState({ time: '10:00' })
    S.route = { name: 'prehrana', params: { dan: '2026-10-16' } }
    await render(<Prehrana />)
    await click(btn(/ročno — kalorije in beljakovine/))
    expect(text()).toMatch(/Dodaj obrok · petek, 16\. 10\./)
    expect(text()).toMatch(/brez ure: 13:00/)
  })
  it('D41: po polnoči »Pozno? Vpiši za včeraj« shrani večerjo na včeraj', async () => {
    setState({ time: '00:15', today: '2026-10-18' })
    await render(<Prehrana />)
    await click(btn(/ročno — kalorije in beljakovine/))
    await click(btn(/Pozno\? Vpiši za včeraj/))
    expect(text()).toMatch(/Dodaj obrok · za včeraj/)
    await typeIn(document.querySelector('#meal-name'), 'Pica')
    await typeIn(document.querySelector('#meal-kcal'), '800')
    await click(btn(/^Shrani$/))
    expect(S.added[0]).toMatchObject({ date: '2026-10-17', slot: 'vecerja', name: 'Pica', kcal: 800 })
  })
})

describe('Prehrana — brez AI in brez prijave (H07, D15)', () => {
  it('H07: brez prijave »Oceni kalorije« takoj oceni iz tabele živil, brez Googlove prijave', async () => {
    setState({ time: '12:30' })
    await render(<Prehrana />)
    await typeIn(document.querySelector('#meal-desc'), 'skuta 250 g, banana')
    await click(btn(/Oceni kalorije/))
    expect(S.signIns).toBe(0)
    expect(text()).toMatch(/Ocena iz tabele živil — brez prijave\. Z Googlovo prijavo oceni AI tudi jedi/)
    expect(+(document.querySelector('#meal-kcal') as HTMLInputElement).value).toBeGreaterThan(200)
    expect(btn(/Oceni z AI \(prijava\)/)).toBeTruthy()
  })
  it('D15: slika brez povezave — list ročnega vpisa (slika ostane) z »Poskusi znova«', async () => {
    setState({ time: '12:30' })
    const on = Object.getOwnPropertyDescriptor(Navigator.prototype, 'onLine')
    Object.defineProperty(navigator, 'onLine', { configurable: true, get: () => false })
    try {
      await render(<Prehrana />)
      const inp = document.querySelector('input[type="file"]:not([capture])') as HTMLInputElement
      const f = new File([new Uint8Array([1, 2, 3])], 'kosilo.png', { type: 'image/png' })
      Object.defineProperty(inp, 'files', { configurable: true, value: [f] })
      await act(async () => { inp.dispatchEvent(new Event('change', { bubbles: true })); await new Promise(r => setTimeout(r, 0)) })
      await act(async () => { await new Promise(r => setTimeout(r, 0)) })
      expect(text()).toMatch(/AI ta hip ni dosegljiv — slika ostane ob vpisu/)
      expect(btn(/^Poskusi znova$/)).toBeTruthy()
      expect(document.activeElement?.id).toBe('meal-name')
    } finally { delete (navigator as { onLine?: boolean }).onLine; if (on) Object.defineProperty(Navigator.prototype, 'onLine', on) }
  })
})

describe('Prehrana — dan v naslovu, 7 dni, kopiranje (D30, D43, D31, E46)', () => {
  it('D30: sprememba »?dan=« pri odprtem zaslonu zamenja dan', async () => {
    setState({ time: '10:00' })
    S.route = { name: 'prehrana', params: { dan: '2026-10-16' } }
    expect(await render(<Prehrana />)).toMatch(/Petek, 16\. oktobra/)
    S.route = { name: 'prehrana', params: { dan: '2026-10-15' } }
    await act(async () => { S.state = { ...S.state }; S.subs.forEach(f => f()) })
    expect(text()).toMatch(/Četrtek, 15\. oktobra/)
    S.route = { name: 'prehrana', params: {} }
    await act(async () => { S.state = { ...S.state }; S.subs.forEach(f => f()) })
    expect(text()).toMatch(/Sobota, 17\. oktobra/)
  })
  it('D43 + D31: »2 dneva + danes«; graf bralniku po dnevih s ciljem; cilj s številko pod grafom', async () => {
    setState({ time: '09:00', meals: [meal(TODAY, 'zajtrk', 728, { time: '08:00' })], recent: [meal('2026-10-16', 'kosilo', 2400), meal('2026-10-15', 'kosilo', 2600)] })
    const t = await render(<Prehrana />)
    expect(t).toMatch(/povprečno 2 500 kcal · cilj [\d ]+ · 2 dneva \+ danes/)
    await click(btn(/Zadnjih 7 dni/))
    const svg = document.querySelector('svg[aria-label^="Pojedeno po dnevih"]')
    expect(svg?.getAttribute('aria-label')).toMatch(/pet 2 400 kcal od [\d ]+/)
    expect(svg?.querySelector('title')?.textContent).toBe('Pojedeno po dnevih; črtica = cilj tistega dne')
    // vsi dnevi z istim ciljem: ena številka (sicer »cilj: pon 2 400 · tor 2 141 …«)
    expect(document.querySelector('.week-refs')?.textContent).toMatch(/^cilj vsak dan 2\s141\skcal$/)
  })
  it('D31: dnevi z različnim ciljem — cilj po dnevih pod grafom', async () => {
    setState({ time: '09:00', plan: [planDay('2026-10-16', 180, { done: { at: NOW } })], recent: [meal('2026-10-16', 'kosilo', 2400), meal('2026-10-15', 'kosilo', 2600)] })
    await render(<Prehrana />)
    await click(btn(/Zadnjih 7 dni/))
    expect(document.querySelector('.week-refs')?.textContent).toMatch(/^cilj: ned\s2\s141.*pet\s[\d\s]+sob\s2\s141$/)
  })
  it('D31: BarChart brez label ostane po starem', async () => {
    await render(<BarChart bars={[{ label: 'a', value: 2 }]} />)
    expect(document.querySelector('svg')?.getAttribute('aria-label')).toMatch(/^Stolpčni graf/)
  })
  it('E46: »Kopiraj seznam« brez odložišča — obvestilo in besedilo za ročno kopiranje', async () => {
    setState({ time: '08:30', plan: [planDay(TODAY, 90)] })
    const cb = Object.getOwnPropertyDescriptor(navigator, 'clipboard')
    Object.defineProperty(navigator, 'clipboard', { configurable: true, value: undefined })
    const ex = (document as { execCommand?: unknown }).execCommand
    ;(document as { execCommand: unknown }).execCommand = () => false
    try {
      await render(<Prehrana />)
      await click(btn(/^nakupovalni seznam$/))
      await click(btn(/^Kopiraj seznam$/))
      expect(S.toasts).toContain('Kopiranje ni uspelo — označi besedilo in ga kopiraj ročno.')
      expect((document.querySelector('.copy-fallback') as HTMLTextAreaElement)?.value.split('\n').length).toBeGreaterThan(3)
    } finally {
      ;(document as { execCommand?: unknown }).execCommand = ex
      if (cb) Object.defineProperty(navigator, 'clipboard', cb); else delete (navigator as { clipboard?: unknown }).clipboard
    }
  })
})

describe('Tehtanje in jutranji vnos (D14 + A16, H36)', () => {
  it('D14/A16: brez današnjega tehtanja je polje prazno, zadnja teža je namig z datumom; »Shrani« s praznim ne zapiše', async () => {
    setState({ time: '07:00', checkins: [{ date: '2026-10-04', weightKg: 79.8 }] })
    await render(<WeighSheet open onClose={() => undefined} />)
    const inp = document.getElementById('weigh-kg') as HTMLInputElement
    expect(inp.value).toBe('')
    expect(inp.placeholder).toBe('79,8')
    expect(text()).toMatch(/Zadnjič 79,8 kg · 4\. 10\./)
    await click(btn(/^Shrani$/))
    expect(S.toasts).toContain('Vpiši realno težo.')
  })
  it('D14: današnje tehtanje se pri urejanju predizpolni', async () => {
    setState({ time: '07:00', checkins: [{ date: TODAY, weightKg: 78.6 }] })
    S.state = { ...S.state, checkinToday: { date: TODAY, weightKg: 78.6 } }
    await render(<WeighSheet open onClose={() => undefined} />)
    expect((document.getElementById('weigh-kg') as HTMLInputElement).value).toBe('78,6')
  })
  it('H36: zložen jutranji vnos (prvi dan) pokaže tudi vrstico teže s »stehtaj«', async () => {
    setState({ time: '07:00' })
    await render(<Checkin compact fold extra={<button type="button">stehtaj</button>} />)
    expect(text()).toMatch(/Kako si danes\?/)
    expect(btn(/^stehtaj$/)).toBeTruthy()
  })
})
