// v3.50 POPRAVKI-NU: popravki ugotovitev pregleda NU (N2–N17) — prehrana, AI, uvoz, intervals.
// Vsak test pade na kodi pred popravkom (370e621) in uspe po njem; varovalke (BMR, 1500/1200, mladoletni, 750, Strava,
// sanitizeGaps) so preverjene, da veljajo še naprej.
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach } from 'vitest'
import { readFileSync } from 'node:fs'
import { createHash } from 'node:crypto'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))
const ai = vi.hoisted(() => ({ out: null as unknown, calls: 0 }))
vi.mock('../src/domain/ai/client', async orig => {
  const m = await orig<typeof import('../src/domain/ai/client')>()
  return { ...m, askJson: vi.fn(async () => { ai.calls++; return ai.out }) }
})
vi.mock('../src/domain/ai/image', () => ({ fileToBase64Resized: async () => ({ data: 'AAAA', mime: 'image/jpeg', thumb: null }), exifStamp: async () => null }))

import { exclusionsOf, dishOk, dishesFor, shoppingGroups, foodPrefsFromWish, recipeOkFor, DISHES, type Dish, type Recipe } from '../src/domain/nutrition/recipes'
import { recipesAhead } from '../src/domain/nutrition/daymeals'
import { dailyTarget, bmr, tdee, goalDeficit, isMinor, MIN_ABS_M, MIN_ABS_Z, MAX_DEFICIT } from '../src/domain/nutrition/energy'
import { rideFuel } from '../src/domain/nutrition/dayplan'
import { estimateMeal } from '../src/domain/nutrition/localMeal'
import { targetWeightOf, shownTargetWeight, healthyTargetWeight, raceWeight, adultKnown, goalBasePatch } from '../src/domain/nutrition/body'
import { personalContext } from '../src/domain/ai/personal'
import { aiContext, coachDailyPrompt, NOAGE_MARK, LOOKS_RULE_NOAGE } from '../src/domain/ai/prompts'
import { honest, HONEST_NOTE, HONEST_NOTE_NOAGE, HONEST_NOTE_MINOR } from '../src/domain/ai/sanitize'
import { CONSENT_V, CLAUDE_CONSENT_V, SELF_PHOTO_CONSENT_V, hasConsent } from '../src/domain/ai/consent'
import { selfFromPhoto, workoutFromPhoto, senseShot, senseDraft, draftRawMinutes, tidySelf, SELF_BAN_MORE } from '../src/domain/ai/photoTraining'
import { draftFromOut, draftErrors, draftMinutes, cleanShot, selfFromOut } from '../src/domain/training/fromPhoto'
import { adaptTarget } from '../src/domain/ai/coachchat'
import { aiSafeView } from '../src/domain/ai/safe'
import { pausePeriod } from '../src/domain/training/pause'
import { FRANJA_2027 } from '../src/domain/training/planner'
import { guessSport } from '../src/domain/import/parsers'
import { sameActivity, apartInDay } from '../src/domain/import/dedupe'
import { importDiagnosis } from '../src/domain/intervals/diagnosis'
import { fixEmptyFuelKit } from '../src/data/migrate'
import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { getKV } from '../src/data/db'
import { resetIcuPause } from '../src/domain/intervals/client'
import type { Activity, PlanDay, Profile } from '../src/domain/types'

const NOW = '2026-10-20T08:00:00.000Z'
const TODAY = '2026-10-21'
const P = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, restHr: 55, maxHr: 200, lthr: 184, ftp: 240, ftpDate: '2026-09-20',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true }, hoursPerWeek: 12, baseHours: null,
  strength: { on: false, equipment: 'none', phases: null }, strengthDays: 0, goal: 'dirka', deficit: 400, neat: 1.4, proteinGkg: 1.8,
  event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', onboardingDone: true, trainTime: 'popoldne', createdAt: NOW, updatedAt: NOW,
  races: [], aiConsentAt: NOW, aiConsentV: 3, ...o,
} as Profile)
const D = (date: string, kind: PlanDay['kind'], min: number, o: Partial<PlanDay> = {}): PlanDay => ({ id: `${kind}${date}${min}`, date, kind, title: kind === 'pocitek' ? 'Počitek' : 'Vožnja', desc: '', durationMin: min, zone: 'Z2', role: kind === 'pocitek' ? 'pocitek' : 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, ...o } as PlanDay)
const addD = (s: string, n: number) => new Date(Date.parse(s + 'T12:00:00Z') + n * 864e5).toISOString().slice(0, 10)

/* ---------------- N2 + N3: alergije, »ne maram« in zelenjava ---------------- */
const MILK = ['skuta', 'jogurt', 'mleko', 'kefir', 'sir', 'maslo', 'smetana']
const GLUTEN = ['kruh', 'belkruh', 'testenine', 'testenineb', 'kuskus', 'oves', 'jesprenj', 'moka']
const FISH = ['tuna', 'losos', 'oslic']
const SOY = ['tofu', 'sojmleko', 'sojjogurt', 'sojkos', 'edamame']
/** 14 dni receptov po pravilih: 2 profila × 2 vzorca tedna */
function fortnight(prefs: string): Recipe[] {
  const out: Recipe[] = []
  const profiles = [P(), P({ sex: 'z', age: 30, weightKg: 62, heightCm: 168, goal: 'shujsati', deficit: 400, event: null })]
  const patterns: ((i: number) => PlanDay)[] = [
    i => (i % 2 ? D(addD(TODAY, i), 'kolo', 90) : D(addD(TODAY, i), 'pocitek', 0)),
    i => (i % 7 === 5 ? D(addD(TODAY, i), 'kolo', 240, { role: 'dolga' }) : i % 7 === 2 ? D(addD(TODAY, i), 'moc', 45, { role: 'moc' }) : D(addD(TODAY, i), 'kolo', 60)),
  ]
  for (const p of profiles) for (const pat of patterns) {
    const plan = Array.from({ length: 14 }, (_, i) => pat(i))
    const ahead = recipesAhead({ p, plan, activities: [], meals: [], recentMeals: [], weather: null, today: TODAY, settings: { foodPrefs: prefs, dayMenus: null }, days: 14, targetOf: d => dailyTarget(p, [], plan.filter(x => x.date === d), d, { today: TODAY, hour: 7 }) })
    for (const a of ahead) { expect(a.recipes.length, `${prefs} ${a.day}: obroki brez recepta`).toBeGreaterThanOrEqual(3); out.push(...a.recipes) }
  }
  return out
}
const keysOf = (rs: readonly Recipe[]) => new Set(rs.flatMap(r => r.ingredients.map(i => i.key)))
const textOf = (r: Recipe) => `${r.name} ${r.ingredients.map(i => i.text).join(' ')} ${r.steps.join(' ')}`.toLowerCase()

describe('N2 alergija na eno živilo izloči skupino; besede s 3 črkami', () => {
  it('»alergija na sir« (3 črke) izloči vse mlečno; »ne maram sir« samo jedi s sirom', () => {
    expect(exclusionsOf('alergija na sir')).toMatchObject({ contains: ['mleko'], words: ['sir'], hard: ['sir'] })
    const like = exclusionsOf('ne maram sir')
    expect(like.contains).toEqual([])
    expect(like.words).toEqual(['sir'])
    const sir = DISHES.filter(d => d.items.some(([k]) => k === 'sir'))
    expect(sir.length).toBeGreaterThan(2)
    expect(sir.every(d => !dishOk(d, like))).toBe(true)
    // jogurt in skuta ostaneta pri »ne maram sir«
    expect(DISHES.some(d => dishOk(d, like) && d.items.some(([k]) => k === 'jogurt'))).toBe(true)
  })
  it.each([
    ['alergija na sir', MILK, /(?<!\p{L})sir(?:a|u|om|i|ov|e)?(?!\p{L})|skut|kefir/u],
    ['alergija na skuto', MILK, /skut|(?<!\p{L})sir(?:a|u|om)?(?!\p{L})/u],
    ['Alergija na jogurt in kefir', MILK, /kefir|skut/u],
    ['alergija na kruh', GLUTEN, /kruh|testenin|kuskus|kosmič|ješprenj/u],
    ['ne prenašam testenin', GLUTEN, /testenin|kruh|kuskus/u],
    ['alergija na tuno', FISH, /(?<!\p{L})tun|losos|osli/u],
    ['ne smem lososa', FISH, /(?<!\p{L})tun|losos|osli/u],
    ['alergija na tofu', SOY, /tofu|sojin/u],
  ])('14 dni, %s: nobene sestavine iz skupine, nič v imenu, sestavinah ali korakih', (prefs, keys, rx) => {
    const rs = fortnight(prefs)
    const bad = [...keysOf(rs)].filter(k => keys.includes(k))
    expect(bad).toEqual([])
    expect(rs.filter(r => rx.test(textOf(r))).map(r => r.name)).toEqual([])
    expect(rs.every(r => recipeOkFor(r, prefs))).toBe(true)
  })
  it('»alergija na sir, skuto«: alergija velja za naštevanje', () => {
    expect(exclusionsOf('alergija na sir, skuto').hard).toEqual(['sir', 'skuto'])
  })
  it('kratke besede: »brez med«, »ne maram gob«, »ne maram por«; ne »med vožnjo«, ne »ali«', () => {
    expect(exclusionsOf('brez med').words).toEqual(['med'])
    expect(exclusionsOf('brez sladkarij med vožnjo').words).not.toContain('med')
    expect(exclusionsOf('ne maram gob').words).toContain('gob')
    expect(exclusionsOf('ne maram por').words).toEqual(['por'])
    expect(exclusionsOf('ne maram sira ali skute').words).toEqual(['sira', 'skute'])
    const ajda = DISHES.find(d => d.id === 'ajda-sojkos')!
    expect(dishOk(ajda, exclusionsOf('ne maram gob'))).toBe(false)
  })
  it('alergija ne popusti, ko izloči vse jedi obroka (»ne maram« popusti)', () => {
    const only: Dish = { id: 'x', name: 'Kaša s sirom', tpl: 'kosilo', items: [['ajda', 80], ['sir', 30]], steps: ['Skuhaj.'], minutes: 10, contains: [] }
    expect(dishesFor('kosilo', 'ne maram sira', [only])).toHaveLength(1)
    expect(dishesFor('kosilo', 'alergija na sir', [only])).toEqual([])
  })
})

describe('N3 zelenjava v korakih in `veg`, nakupovalni seznam', () => {
  const week = (prefs: string) => {
    const p = P()
    const plan = Array.from({ length: 7 }, (_, i) => (i % 2 ? D(addD(TODAY, i), 'kolo', 90) : D(addD(TODAY, i), 'pocitek', 0)))
    const recs = recipesAhead({ p, plan, activities: [], meals: [], recentMeals: [], weather: null, today: TODAY, settings: { foodPrefs: prefs, dayMenus: null }, days: 7, targetOf: d => dailyTarget(p, [], plan.filter(x => x.date === d), d, { today: TODAY, hour: 7 }) }).flatMap(a => a.recipes)
    return { recs, items: shoppingGroups(recs, prefs).flatMap(g => g.items) }
  }
  it.each([
    ['ne maram brokolija', /brokol/],
    ['ne maram gob', /gob|šampinjon/],
    ['ne maram paprike', /paprik/],
    ['ne maram bučk', /bučk|bučo/],
    ['alergija na zeleno', /(?<!\p{L})zelen[aeo]?(?!\p{L})(?!\s+solat)/u],
  ])('%s: ni v receptih (ime, koraki) in ne na seznamu', (prefs, rx) => {
    const { recs, items } = week(prefs)
    expect(recs.length).toBeGreaterThan(15)
    expect(recs.filter(r => rx.test(`${r.name} ${r.steps.join(' ')}`.toLowerCase())).map(r => r.name)).toEqual([])
    expect(items.filter(x => rx.test(x.toLowerCase()))).toEqual([])
  })
  it('»alergija na zeleno« ne izloči jedi z zelenjavo ali zeleno solato', () => {
    const ex = exclusionsOf('alergija na zeleno')
    expect(ex.words).toEqual(['zelena'])
    expect(dishOk(DISHES.find(d => d.id === 'pisc-riz')!, ex)).toBe(true)
    expect(dishOk(DISHES.find(d => d.id === 'tofu-kruh')!, ex)).toBe(true)
    expect(dishOk(DISHES.find(d => d.id === 'ricet')!, ex)).toBe(false)
  })
  it('seznam: vrsta zelenjave, ki je ne maraš, gre ven, grami k ostalim vrstam', () => {
    const r = { dish: 'losos-kr', ingredients: [{ key: 'zelenjava', qty: 200, text: 'zelenjava 200 g' }] }
    // (v3.51 E31) limona iz korakov je v »Začimbe in drobno«
    expect(shoppingGroups([r], 'ne maram brokolija').flatMap(g => g.items)).toEqual(['korenje: 200 g', 'limona'])
    expect(shoppingGroups([r], null).flatMap(g => g.items)).toEqual(['brokoli: 100 g', 'korenje: 100 g', 'limona'])
  })
})

/* ---------------- N4: dve vožnji istega dne ---------------- */
describe('N4 ročni vnos in vožnja z ure: ujemanje po uri dneva', () => {
  const loc = (h: number, m = 0) => new Date(2026, 9, 20, h, m).toISOString()
  const man = (createdAt: string) => ({ source: 'manual' as const, start: null, date: '2026-10-20', sport: 'kolo' as const, durationMin: 30, distKm: 12, createdAt })
  const watch = (h: number, m: number, min = 28) => ({ source: 'intervals' as const, start: loc(h, m), date: '2026-10-20', sport: 'kolo' as const, durationMin: min, distKm: 11.6 })
  it('večerni ročni vnos ni jutranja vožnja z ure; vnos takoj po vožnji je ista', () => {
    expect(sameActivity(man(loc(18, 30)), watch(6, 30))).toBe(false)
    expect(sameActivity(watch(6, 30), man(loc(18, 30)))).toBe(false)
    expect(apartInDay(man(loc(18, 30)), watch(6, 30))).toBe(true)
    // vožnja z ure se je začela po vpisu: druga vožnja
    expect(sameActivity(man(loc(7, 30)), watch(17, 0))).toBe(false)
    // vpis 20 min po koncu vožnje z ure: ista (F14)
    expect(sameActivity(man(loc(7, 20)), watch(6, 30))).toBe(true)
    // vpis za drug dan: ura vpisa ne pove nič, ostane pravilo F14
    expect(sameActivity({ ...man(new Date(2026, 9, 21, 19, 0).toISOString()) }, watch(6, 30))).toBe(true)
  })
  describe('shramba', () => {
    beforeEach(async () => { await repo.wipeAll(); localStorage.clear(); resetIcuPause(); await store.reloadAll() })
    it('ročni »Domov« zvečer, nato »V službo« z ure: dva zapisa, opomba ostane pri ročnem', async () => {
      const day = '2026-10-20'
      const evening = { id: 'man-pm', source: 'manual', sport: 'kolo', date: day, start: null, name: 'Domov', durationMin: 30, distKm: 12, rpe: 4, notes: 'domov iz službe', aiEligible: true, geoRetain: false, createdAt: loc(18, 30), updatedAt: loc(18, 30) } as Activity
      await store.addActivities([evening])
      const morning = { id: 'icu-am', source: 'intervals', originHint: 'GARMIN', sport: 'kolo', date: day, start: loc(6, 30), name: 'V službo', durationMin: 28, distKm: 11.6, avgHr: 130, aiEligible: true, geoRetain: true, ext: { intervalsId: 'i-am' }, createdAt: NOW, updatedAt: NOW } as Activity
      const r = await store.addActivities([morning])
      expect(r).toMatchObject({ added: 1, upgraded: 0 })
      const all = store.getState().activities.filter(a => a.date === day)
      expect(all).toHaveLength(2)
      expect(all.find(a => a.id === 'man-pm')).toMatchObject({ source: 'manual', notes: 'domov iz službe', rpe: 4 })
    })
  })
})

/* ---------------- N5 + N6: ocena brez AI ---------------- */
describe('N5 + N6 ocena obroka brez AI', () => {
  const g = (d: string, k: string) => estimateMeal(d)!.items.filter(i => i.key === k).reduce((s, i) => s + i.amount, 0)
  it('pica: »1 pica« je cela, kos samo s »kos«; nadev se ne šteje dvakrat', () => {
    expect(g('1 pica', 'pica')).toBe(350)
    expect(g('ena pica margerita', 'pica')).toBe(350)
    expect(g('dve pici', 'pica')).toBe(700)
    expect(g('pol pice', 'pica')).toBe(175)
    expect(g('2 kosa pice in pivo', 'pica')).toBe(240)
    expect(estimateMeal('pica s šunko in sirom')!.items.map(i => i.key)).toEqual(['pica'])
    expect(estimateMeal('sendvič s šunko, sirom in gobami')!.items.map(i => i.key)).toEqual(['sendvic'])
    expect(estimateMeal('pica s šunko in pivo')!.items.map(i => i.key)).toEqual(['pica', 'pivo'])
    expect(estimateMeal('burek s sirom in jogurt')!.items.map(i => i.key)).toEqual(['burek', 'jogurt'])
  })
  it('odstotek maščobe ni količina', () => {
    expect(g('mleko 1,5 % 250 ml', 'mleko')).toBe(250)
    expect(g('mleko 1,5 %', 'mleko')).toBe(250)
    expect(g('kozarec mleka 3,5 %', 'mleko')).toBe(250)
    expect(g('grški jogurt 2 % 200 g in banana', 'jogurt')).toBe(200)
    expect(g('jogurt 3,2 % 180 g', 'jogurt')).toBe(180)
    expect(g('0,5 l piva', 'pivo')).toBe(500)
  })
})

/* ---------------- N7 + N11 + N16: starost, mejnik, poziv ---------------- */
describe('N7 brez vpisane starosti ni odrasel', () => {
  const noAge = P({ age: null, bodyFatPct: 20, deficit: 500, goal: 'shujsati', event: null })
  it('ni ciljne teže, najboljše teže, mejnika ne deficita', () => {
    expect(adultKnown(noAge)).toBe(false)
    expect(targetWeightOf(noAge, TODAY)).toBeNull()
    expect(shownTargetWeight(noAge, false, TODAY)).toBeNull()
    expect(raceWeight(noAge)).toBeNull()
    expect(healthyTargetWeight(noAge)).toBeNull()
    expect(goalDeficit(noAge, TODAY)).toBe(0)
    // odrasel z isto maščobo: vse ostane
    const adult = { ...noAge, age: 30 }
    expect(targetWeightOf(adult, TODAY)).not.toBeNull()
    expect(raceWeight(adult)).not.toBeNull()
    expect(goalDeficit(adult, TODAY)).toBe(500)
  })
  it('AI: brez »najboljše teže«, brez tempa teže v personi; opomba o videzu brez tempa', () => {
    const p = P({ age: null, bodyFatPct: 18 })
    const pc = personalContext({ profile: p, activities: [], plan: [], checkins: [], recentMeals: [], today: TODAY })
    expect(pc).not.toMatch(/najboljša teža/)
    const ctx = aiContext([], p, [], false, TODAY)
    expect(ctx).toContain(NOAGE_MARK)
    const prompt = (coachDailyPrompt(ctx, [], 'Kdaj bom imel six pack?', [])[0] as { text: string }).text
    expect(prompt).toContain(LOOKS_RULE_NOAGE)
    expect(prompt).not.toMatch(/tempo teže 0,3–0,5/)
    expect(honest('Zagotovo boš do poletja imel six-pack.', { noAge: true })).toContain(HONEST_NOTE_NOAGE)
    expect(HONEST_NOTE_NOAGE).not.toMatch(/tempo teže/)
    // odrasel in mladoleten kot prej
    expect(aiContext([], P(), [], false, TODAY)).not.toContain(NOAGE_MARK)
    expect(honest('Zagotovo boš do poletja imel six-pack.')).toContain(HONEST_NOTE)
    expect(honest('Zagotovo boš do poletja imel six-pack.', { minor: true })).toContain(HONEST_NOTE_MINOR)
  })
})

describe('N11 izhodišče teže za mejnik se zapiše', () => {
  it('goalBasePatch: dopolni manjkajočo težo izhodišča; brez dirke ustvari izhodišče', () => {
    const gs = { date: '2026-09-01', ftp: 240, weightKg: null }
    expect(goalBasePatch(P({ weightKg: 91, goal: 'shujsati', goalStart: gs, event: null }), TODAY)).toEqual({ goalStart: { ...gs, weightKg: 91 } })
    expect(goalBasePatch(P({ weightKg: 91, goal: 'shujsati', goalStart: null, event: null, createdAt: '2026-08-15T10:00:00.000Z' }), TODAY)).toEqual({ goalStart: { date: '2026-08-15', ftp: 240, weightKg: 91 } })
    // že zapisano, brez cilja teže ali dirka brez izhodišča: nič
    expect(goalBasePatch(P({ goal: 'shujsati', goalStart: { ...gs, weightKg: 100 } }), TODAY)).toBeNull()
    expect(goalBasePatch(P({ goal: 'forma', deficit: 0, goalStart: gs }), TODAY)).toBeNull()
    expect(goalBasePatch(P({ goal: 'dirka', goalStart: null }), TODAY)).toBeNull()
  })
  describe('shramba', () => {
    beforeEach(async () => { await repo.wipeAll(); localStorage.clear(); await store.reloadAll() })
    it('teža pade s 100 na 91 kg: mejnik ostane 90 kg in deficit se ustavi', async () => {
      await store.updateProfile(P({ weightKg: 100, goal: 'shujsati', deficit: 500, event: null, goalStart: null }))
      expect(store.getState().profile.goalStart?.weightKg).toBe(100)
      await store.updateProfile({ weightKg: 91 })
      expect(targetWeightOf(store.getState().profile, TODAY)).toBe(90)
      await store.updateProfile({ weightKg: 89.5 })
      expect(goalDeficit(store.getState().profile, TODAY)).toBe(0)
    })
  })
})

it('N16 PREHRANA: presledek za podpičjem', () => {
  const pc = personalContext({ profile: P(), activities: [], plan: [], checkins: [], recentMeals: [], today: TODAY })
  const line = pc.split('\n').find(l => l.startsWith('PREHRANA:'))!
  expect(line).toContain('potem vzdrževanje; deficit')
})

/* ---------------- N8 + N9 + N13: slika ---------------- */
describe('N8 slika: nesmiselne kombinacije', () => {
  const shot = (o: Partial<Activity>) => cleanShot({ id: 'x', source: 'screenshot', sport: 'kolo', date: '2026-10-20', start: null, name: 'V', durationMin: 60, distKm: 30, elevM: 400, createdAt: '', updatedAt: '', ...o } as Activity)
  it('posnetek: hitrost po športu in vzpon na uro', () => {
    expect(senseShot(shot({ distKm: 300 }))).toMatchObject({ distKm: null, speedKmh: null })
    expect(senseShot(shot({ distKm: 30 }))).toMatchObject({ distKm: 30, speedKmh: 30 })
    expect(senseShot(shot({ distKm: 68 }))).toMatchObject({ distKm: 68 })
    expect(senseShot(shot({ sport: 'tek', distKm: 30 })).distKm).toBeNull()
    expect(senseShot(shot({ sport: 'tek', distKm: 12 })).distKm).toBe(12)
    expect(senseShot(shot({ elevM: 9000 })).elevM).toBeNull()
    expect(senseShot(shot({ elevM: 1500 })).elevM).toBe(1500)
  })
  it('trening s slike daljši od 8 ur: napaka v predogledu (ponovitve ali serije prazne)', () => {
    const w = draftFromOut({ vrsta: 'kolo', naslov: 'Intervali', minut: 90, vaje: [], koraki: [{ tip: 'ogrevanje', min: 15 }, { tip: 'ponovitve', ponovitve: 20, delo_s: 1800, odmor_s: 300, intenzivnost: 'RPE 8' }, { tip: 'iztek', min: 10 }] })!
    expect(draftErrors(w)).toEqual([])
    expect(draftRawMinutes(w)).toBeGreaterThan(480)
    const s = senseDraft(w)
    expect(s.blocks[1]!.n).toBeNull()
    expect(draftErrors(s).length).toBeGreaterThan(0)
    // smiseln trening ostane, kot je
    const ok = draftFromOut({ vrsta: 'kolo', minut: 75, vaje: [], koraki: [{ tip: 'ogrevanje', min: 15 }, { tip: 'ponovitve', ponovitve: 5, delo_s: 240, odmor_s: 180, intenzivnost: 'RPE 8' }, { tip: 'iztek', min: 10 }] })!
    expect(senseDraft(ok)).toEqual(ok)
    const m = draftFromOut({ vrsta: 'moc', minut: 30, vaje: Array.from({ length: 15 }, (_, i) => ({ ime: `Vaja ${i}`, serije: 10, ponovitve: 100, kg: 400, pavza_s: 600 })), koraki: [] })!
    expect(draftErrors(m)).toEqual([])
    const sm = senseDraft(m)
    expect(sm.exercises.some(e => e.sets == null)).toBe(true)
    expect(draftErrors(sm).length).toBeGreaterThan(0)
    const m3 = draftFromOut({ vrsta: 'moc', minut: 45, vaje: [{ ime: 'Počep', serije: 4, ponovitve: 8 }, { ime: 'Sklece', serije: 3, ponovitve: 12 }], koraki: [] })!
    expect(senseDraft(m3)).toEqual(m3)
    expect(draftMinutes(senseDraft(m3))).toBe(45)
  })
  it('workoutFromPhoto uporabi preverbo', async () => {
    ai.out = { vrsta: 'kolo', minut: 90, vaje: [], koraki: [{ tip: 'ponovitve', ponovitve: 20, delo_s: 1800, odmor_s: 300, intenzivnost: 'RPE 8' }] }
    const w = await workoutFromPhoto(P(), new File(['x'], 't.jpg', { type: 'image/jpeg' }))
    expect(draftErrors(w).length).toBeGreaterThan(0)
  })
})

describe('N9 slika sebe samo s trenutno privolitvijo', () => {
  const file = () => new File(['x'], 'jaz.jpg', { type: 'image/jpeg' })
  beforeEach(() => { ai.calls = 0; ai.out = { poudarki: ['Ramena so rahlo naprej — okrepi zgornji hrbet.'], podrocje: 'drza', predlog: { vaje: [] } } })
  it('privolitev v1 ali v2: list privolitve (napaka consent), AI se ne kliče', async () => {
    for (const v of [1, 2, null]) {
      await expect(selfFromPhoto(P({ age: 30, aiConsentAt: '2026-01-01T08:00:00.000Z', aiConsentV: v }), file())).rejects.toMatchObject({ kind: 'consent' })
    }
    expect(ai.calls).toBe(0)
  })
  it('privolitev v3: AI se kliče', async () => {
    const r = await selfFromPhoto(P({ age: 30, aiConsentV: CONSENT_V }), file())
    expect(ai.calls).toBe(1)
    expect(r.points).toEqual(['Ramena so rahlo naprej — okrepi zgornji hrbet.'])
  })
  it('različice: besedilo 3, Claude in narekovanje še vedno z 2', () => {
    expect(CONSENT_V).toBe(3)
    expect(SELF_PHOTO_CONSENT_V).toBe(3)
    expect(CLAUDE_CONSENT_V).toBe(2)
    expect(hasConsent({ aiConsentAt: NOW, aiConsentV: 2 }, CLAUDE_CONSENT_V)).toBe(true)
    expect(hasConsent({ aiConsentAt: NOW, aiConsentV: 2 }, SELF_PHOTO_CONSENT_V)).toBe(false)
    expect(hasConsent({ aiConsentAt: NOW, aiConsentV: 1 })).toBe(true)
  })
})

describe('N13 slika sebe: druga plast filtra', () => {
  const xs = ['Okoli pasu je več mehkega tkiva — okrepi jedro.', 'Videti je, da imaš nekaj odvečnih kil — dodaj kardio.', 'Trebušček je opazen — vaje za jedro pomagajo.', 'Postava je hruškasta — okrepi zgornji del.', 'Trebušne mišice se še ne vidijo — deska vsak dan.', 'Ramena so rahlo naprej — okrepi zgornji hrbet.', 'Si nekoliko okrogel v obrazu.', 'Leva rama je nižja od desne — vaje za ravnotežje.', 'Jedro je šibko — okrepi trebušne mišice z desko.']
  it('opisi maščobe in teže izpadejo, poudarki z vajo ostanejo', () => {
    const s = selfFromOut({ poudarki: xs, podrocje: 'jedro', predlog: { vaje: [] }, opomba: '' })!
    const t = tidySelf({ ...s, points: xs })
    expect(t.points).toEqual(['Ramena so rahlo naprej — okrepi zgornji hrbet.', 'Leva rama je nižja od desne — vaje za ravnotežje.', 'Jedro je šibko — okrepi trebušne mišice z desko.'])
    expect(SELF_BAN_MORE.test('Ramena so rahlo naprej — okrepi zgornji hrbet.')).toBe(false)
    expect(tidySelf({ ...s, title: 'Proti odvečnim kilam' }).title).toBe('Jedro')
  })
})

/* ---------------- N10: želje iz uvoda ---------------- */
describe('N10 prehranske želje iz uvoda', () => {
  it.each([
    ['Rad bi shujšal 5 kg. Ob petkih ne jem mesa.', null],
    ['Hočem več moči, brez mesa ob petkih.', null],
    ['Alergija na pelod, sicer zdrav.', null],
    ['Ne jem po 19h in ne jem zajtrka.', null],
    ['Sem vegan.', 'vegan'],
    ['Alergija na oreške.', 'alergija na oreške'],
    ['Ne maram brokolija.', 'ne maram brokolija'],
    ['Ne maram sira.', 'ne maram sira'],
  ])('»%s« → %s', (wish, want) => {
    expect(foodPrefsFromWish(wish)).toBe(want)
  })
  it('»Ne maram rib, sicer jem vse.«: samo ribe', () => {
    expect(exclusionsOf(foodPrefsFromWish('Ne maram rib, sicer jem vse.'))).toEqual({ contains: ['riba'], words: [] })
  })
  it('»sicer zdrav« ni živilo (polenta ostane)', () => {
    expect(exclusionsOf('alergija na pelod, sicer zdrav').words).toEqual(['pelod'])
  })
})

/* ---------------- N12: prazen komplet goriva iz v3.49 ---------------- */
describe('N12 fuelKit: [] iz v3.49 → privzeti komplet', () => {
  beforeEach(async () => { await repo.wipeAll(); localStorage.clear() })
  it('enkrat na napravo: [] → null (dolga vožnja spet z OH); nova izbira »samo voda« ostane', async () => {
    await repo.saveProfile(P({ fuelKit: [] }))
    expect(await fixEmptyFuelKit()).toBe(true)
    const p = await repo.loadProfile()
    expect(p.fuelKit).toBeNull()
    expect(await getKV('mig.fuelKit.v350')).toBe(true)
    const long = { kind: 'kolo' as const, durationMin: 240, zone: 'Z2', role: 'dolga' as const, title: 'Dolga Z2' }
    expect(rideFuel(long, p.fuelKit)!.carriedCarbs).toBeGreaterThan(100)
    // po prvem zagonu je [] izrecna izbira v3.50
    await repo.saveProfile({ ...p, fuelKit: [] })
    expect(await fixEmptyFuelKit()).toBe(false)
    expect((await repo.loadProfile()).fuelKit).toEqual([])
  })
})

/* ---------------- N14, N15, N17 ---------------- */
it('N14 nedelja z neopravljeno dolgo vožnjo: prilagodi današnji dan', () => {
  const sun = '2026-10-25'
  const plan = [D('2026-10-24', 'kolo', 90, { done: { at: NOW } }), D(sun, 'kolo', 240, { role: 'dolga' }), D('2026-10-26', 'pocitek', 0), D('2026-10-27', 'kolo', 75)]
  expect(adaptTarget(plan, sun)).toEqual({ days: [plan[1]], next: false })
  // opravljena: naslednji teden
  const done = [plan[0]!, { ...plan[1]!, done: { at: NOW } }, plan[2]!, plan[3]!]
  expect(adaptTarget(done, sun)).toEqual({ days: [plan[2], plan[3]], next: true })
})

it('N15 FIT: kardio naprave, dihanje, joga niso moč', () => {
  for (const h of ['elliptical fitness_equipment', 'stair_climbing fitness_equipment', 'indoor_rowing rowing', 'breathing training', 'cardio_training training', 'yoga training', 'pilates training']) {
    expect(guessSport(10, h, 8), h).toBe('drugo')
    expect(guessSport(null, h), h).toBe('drugo')
  }
  expect(guessSport(null, 'strength_training training')).toBe('moc')
  expect(guessSport(null, 'training')).toBe('moc')
  expect(guessSport(null, 'hiit training')).toBe('moc')
  expect(guessSport(null, 'indoor_cycling cycling')).toBe('kolo')
  expect(guessSport(10, 'treadmill running', 8)).toBe('tek')
})

it('N17 diagnoza intervals.icu: skloni', () => {
  expect(importDiagnosis({ at: '', days: 21, total: 6, usable: 0, stravaStubs: 0, known: 0, short: 5 })!.text).toBe('5 je prekratkih (pod 5 min, hoja pod 15 min), 1 je brez vrste športa.')
  expect(importDiagnosis({ at: '', days: 21, total: 5, usable: 0, stravaStubs: 0, known: 0, short: 2 })!.text).toBe('2 sta prekratka (pod 5 min, hoja pod 15 min), 3 so brez vrste športa.')
  expect(importDiagnosis({ at: '', days: 21, total: 1, usable: 0, stravaStubs: 1, known: 0 })!.text).toMatch(/^intervals\.icu jo je dobil s Strave, .* da bi jo dal drugim/)
  expect(importDiagnosis({ at: '', days: 21, total: 2, usable: 0, stravaStubs: 2, known: 0 })!.text).toMatch(/^intervals\.icu ju je dobil s Strave, .* da bi ju dal drugim/)
  expect(importDiagnosis({ at: '', days: 21, total: 7, usable: 0, stravaStubs: 7, known: 0 })!.text).toMatch(/^intervals\.icu jih je dobil s Strave, .* da bi jih dal drugim/)
})

/* ---------------- varovalke (nedotakljivo) ---------------- */
describe('varovalke veljajo', () => {
  it('dnevni cilj: nikoli pod BMR, 1500/1200, strop 750, mladoletni brez deficita', () => {
    const profiles = [P(), P({ sex: 'z', weightKg: 50, heightCm: 160, age: 30, deficit: 750, goal: 'shujsati', event: null }), P({ age: 16, deficit: 500, goal: 'shujsati' }), P({ sex: 'z', age: 17, weightKg: 55, heightCm: 165, kcalOverride: 1200 }), P({ kcalOverride: 900 }), P({ weightKg: 55, heightCm: 165, age: 70, deficit: 750, goal: 'shujsati', event: null, neat: 1.2 })]
    const plans = [[D(TODAY, 'pocitek', 0)], [D(TODAY, 'kolo', 60)], [D(TODAY, 'kolo', 300, { role: 'dolga' })], [D(TODAY, 'moc', 45, { role: 'moc' })]]
    for (const p of profiles) for (const plan of plans) for (const hour of [7, 22]) {
      const t = dailyTarget(p, [], plan, TODAY, { today: TODAY, hour })!
      expect(t.kcal).toBeGreaterThanOrEqual(bmr(p)!)
      expect(t.kcal).toBeGreaterThanOrEqual(p.sex === 'z' ? MIN_ABS_Z : MIN_ABS_M)
      expect(tdee(p)! - t.kcal).toBeLessThanOrEqual(MAX_DEFICIT)
      if (isMinor(p)) expect(t.kcal).toBeGreaterThanOrEqual(tdee(p)!)
    }
    // brez starosti ni cilja (ne ugibamo)
    expect(dailyTarget(P({ age: null }), [], [D(TODAY, 'kolo', 60)], TODAY, { today: TODAY, hour: 7 })).toBeNull()
  })
  it('Strava: posnetek s Strave ne gre v AI kontekst', () => {
    const strava = { id: 's1', source: 'screenshot', originHint: 'STRAVA', sport: 'kolo', date: '2026-10-20', start: null, name: 'Jutranja vožnja', durationMin: 95, distKm: 41, aiEligible: false, geoRetain: false, createdAt: NOW, updatedAt: NOW } as Activity
    const day = { ...D('2026-10-20', 'kolo', 90), done: { at: NOW, activityId: 's1' } } as PlanDay
    const p = P({ weekPause: { ...pausePeriod(TODAY, 'kolo'), reason: 'bolan' } } as Partial<Profile>)
    const v = aiSafeView({ profile: p, activities: [strava], plan: [day], today: TODAY })
    const ctx = aiContext(v.activities, v.profile, v.plan, v.hidden, TODAY)
    expect(/41 km|95 min|Jutranja/.test(ctx)).toBe(false)
  })
  it('sanitizeGaps je nespremenjen (izvorna koda)', () => {
    const s = readFileSync(`${process.cwd()}/src/domain/ai/sanitize.ts`, 'utf8')
    const i = s.indexOf('export function sanitizeGaps')
    let d = 0, k = s.indexOf('{', i)
    for (; k < s.length; k++) { if (s[k] === '{') d++; else if (s[k] === '}' && --d === 0) break }
    expect(createHash('md5').update(s.slice(i, k + 1)).digest('hex')).toBe('6add0ae318244bb327949158cad5076d')
  })
})
