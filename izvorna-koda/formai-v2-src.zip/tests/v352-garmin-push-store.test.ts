import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => 'tok', proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { getKV } from '../src/data/db'
import { todayIso, addDays } from '../src/domain/training/load'
import { encodePolyline, type LatLon } from '../src/domain/import/polyline'
import type { PlanDay } from '../src/domain/types'
import type { RouteRec } from '../src/domain/routes/analyze'

const NOW = '2026-10-03T08:00:00.000Z'
const day = (id: string, date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id, date, kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, zone: 'Z2', tssTarget: 45, role: 'lahka', source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })
type Call = { url: string; init: RequestInit }
let calls: Call[] = []
let reply: (c: Call) => { status: number; body: unknown } = () => ({ status: 200, body: {} })
const fetchMock = vi.fn(async (url: string, init: RequestInit) => { const c = { url, init }; calls.push(c); const r = reply(c); return { ok: r.status < 400, status: r.status, json: async () => r.body } })
const garmin = (o: Partial<NonNullable<import('../src/domain/types').Settings['garmin']>> = {}) => store.updateSettings({ garmin: { connected: true, permissions: ['ACTIVITY_EXPORT', 'WORKOUT_IMPORT', 'COURSE_IMPORT'], ...o } })

describe('v3.52 Garmin — pošiljanje treningov iz store', () => {
  beforeEach(async () => {
    await repo.wipeAll(); localStorage.clear(); await store.reloadAll()
    calls = []; reply = () => ({ status: 200, body: { created: 1, updated: 0, skipped: 0, removed: 0, errors: [] } })
    vi.stubGlobal('fetch', fetchMock)
    const t = todayIso()
    await store.updateProfile({ onboardingDone: true, ftp: 240, lthr: 184, gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true } })
    await repo.upsertPlanDays([day('a', t), day('b', addDays(t, 1), { kind: 'pocitek', title: 'Počitek', durationMin: 0 }), day('c', addDays(t, 2), { title: 'Sweet spot 3 × 12 min', zone: 'Z4', role: 'kljucna', durationMin: 90, target: { lo: 210, hi: 225 } })])
    await store.reloadAll()
  })
  afterEach(() => vi.unstubAllGlobals())

  it('brez povezave, z izklopom ali brez dovoljenja WORKOUT_IMPORT ni klica', async () => {
    expect(await store.pushGarminWorkouts(true)).toBeNull()
    await garmin({ pushWorkouts: false }); expect(await store.pushGarminWorkouts(true)).toBeNull()
    await garmin({ permissions: ['ACTIVITY_EXPORT'] }); expect(await store.pushGarminWorkouts(true)).toBeNull()
    expect(calls.length).toBe(0)
    expect(store.garminPushOn({ lang: 'sl', garmin: { connected: true, permissions: [] } })).toBe(true)   // dovoljenj še ne poznamo → poskusi
  })
  it('PUT /garmin/workouts z treningi naslednjih 14 dni (uid, date, hash), rezultat v KV in stanju; drugič brez spremembe ni klica', async () => {
    await garmin()
    const info = await store.pushGarminWorkouts(true)
    expect(calls.length).toBe(1)
    expect(calls[0]!.url).toMatch(/\/garmin\/workouts$/); expect(calls[0]!.init.method).toBe('PUT')
    expect((calls[0]!.init.headers as Record<string, string>).Authorization).toBe('Bearer tok')
    const body = JSON.parse(calls[0]!.init.body as string) as { workouts: { uid: string; date: string; hash: string; sport: string; steps: unknown[] }[] }
    expect(body.workouts.map(w => w.date)).toEqual([todayIso(), addDays(todayIso(), 2)])
    expect(body.workouts[0]!.uid).toBe(`formai-${todayIso()}`); expect(body.workouts[0]!.hash).toMatch(/^[0-9a-f]{8}$/); expect(body.workouts[0]!.sport).toBe('CYCLING')
    expect(info).toMatchObject({ n: 2, created: 1, updated: 0, removed: 0, errors: [], err: null })
    expect(store.getState().garminWorkouts).toEqual(info)
    expect(await getKV('garmin.workouts')).toEqual(info)
    expect(store.getState().toasts!.some(t => /Na Garmin: 1.poslan trening/.test(t.msg))).toBe(true)
    // samodejno: isti podpis → brez klica
    expect(await store.pushGarminWorkouts(false)).toEqual(info)
    expect(calls.length).toBe(1)
    // ročno vedno pošlje; strežnik javi »nič novega«
    reply = () => ({ status: 200, body: { created: 0, updated: 0, skipped: 2, removed: 0, errors: [] } })
    await store.pushGarminWorkouts(true)
    expect(calls.length).toBe(2)
    expect(store.getState().toasts!.some(t => /že enak načrtu \(2.treninga\)/.test(t.msg))).toBe(true)
  })
  it('napaka Garmina pri enem dnevu ni tiha: errors[] v stanju, err besedilo, obvestilo; podpis se ne shrani', async () => {
    await garmin()
    reply = () => ({ status: 200, body: { created: 1, updated: 0, skipped: 0, removed: 0, errors: [{ date: todayIso(), error: 'garmin_400' }] } })
    const info = await store.pushGarminWorkouts(false)
    expect(info!.errors).toEqual([{ date: todayIso(), error: 'garmin_400' }])
    expect(info!.err).toBe('1 trening Garmin ni sprejel: garmin_400')
    expect(store.getState().toasts!.some(t => t.kind === 'err' && /Garmin ni sprejel/.test(t.msg))).toBe(true)
    expect(await getKV('garmin.workouts.sig')).toBeUndefined()
  })
  it('napaka strežnika (409 ni_povezave): err slovensko, lastError v nastavitvah, ročno obvestilo', async () => {
    await garmin()
    reply = () => ({ status: 409, body: { error: 'ni_povezave' } })
    expect(await store.pushGarminWorkouts(true)).toBeNull()
    expect(store.getState().garminWorkouts!.err).toMatch(/Garmin ni povezan/)
    expect(store.getState().settings.garmin!.lastError).toMatch(/Garmin ni povezan/)
    expect(store.getState().toasts!.some(t => t.kind === 'err' && /Garmin ni povezan/.test(t.msg))).toBe(true)
  })
  it('removeGarminWorkouts: DELETE, število pobrisanih, podpis pobrisan', async () => {
    await garmin()
    await store.pushGarminWorkouts(true)
    reply = () => ({ status: 200, body: { removed: 2 } })
    expect(await store.removeGarminWorkouts()).toBe(2)
    expect(calls[1]!.init.method).toBe('DELETE')
    expect(store.getState().garminWorkouts).toMatchObject({ removed: 2, n: 0, err: null })
    expect(await getKV('garmin.workouts.sig')).toBeNull()
  })
  it('pushGarminCourse: podana trasa → PUT /garmin/course s courseName z datumom; brez povezave ali dovoljenja obvestilo', async () => {
    const pts: LatLon[] = [[46.19, 14.49], [46.191, 14.49], [46.192, 14.49]]
    const rec = { id: 'r1', source: 'voznja', name: 'Krog', date: null, km: 0.2, gainM: 3, rodeMin: null, loop: true, start: pts[0]!, poly: encodePolyline(pts), prof: [300, 301, 302, 303, 303], climbs: [], hilly: 0, times: 1 } as RouteRec
    const d = day('c', addDays(todayIso(), 2))
    expect(await store.pushGarminCourse(d, rec)).toBeNull()
    expect(store.getState().toasts!.some(t => /Garmin ni povezan/.test(t.msg))).toBe(true)
    await garmin({ permissions: ['WORKOUT_IMPORT'] })
    expect(await store.pushGarminCourse(d, rec)).toBeNull()
    expect(store.getState().toasts!.some(t => /nisi dovolil uvoza tras/.test(t.msg))).toBe(true)
    await garmin()
    reply = () => ({ status: 200, body: { courseId: 55 } })
    expect(await store.pushGarminCourse(d, rec)).toBe(55)
    const c = calls.find(x => /\/garmin\/course$/.test(x.url))!
    expect(c.init.method).toBe('PUT')
    const body = JSON.parse(c.init.body as string) as { course: { courseName: string; geoPoints: unknown[] } }
    expect(body.course.courseName).toMatch(/^FORMAI · Krog · \d+\. \d+\.$/); expect(body.course.geoPoints.length).toBe(3)
    expect(store.getState().toasts!.some(t => /je na Garminu/.test(t.msg))).toBe(true)
    // brez trase in brez knjižnice: obvestilo, brez klica
    const n = calls.length
    expect(await store.pushGarminCourse(d)).toBeNull()
    expect(calls.length).toBe(n)
  })
})
