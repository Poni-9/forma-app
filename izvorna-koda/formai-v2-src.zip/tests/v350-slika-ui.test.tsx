// v3.50 SLIKA (list »Trening s slike«, lažna shramba): predogled z izbranim dnem, ročna pot brez povezave, mladoletni.
import { act, useSyncExternalStore, type ReactElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>() }))
const h = vi.hoisted(() => ({ json: {} as unknown, nav: [] as [string, Record<string, string> | undefined][], saved: [] as unknown[], added: [] as unknown[] }))
vi.mock('@/state/store', () => ({
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state, toast: () => undefined,
}))
vi.mock('@/state/photoTraining', () => ({
  saveDoneShot: async (a: unknown, id: string | null) => { h.saved.push([a, id]); return { added: true, day: id ? S.state.plan.find((d: { id: string }) => d.id === id) : null } },
  addPhotoWorkout: async (d: { id: string }, rid: string | null) => { h.added.push([d, rid]); return { day: d, replaced: null, undo: async () => undefined } },
  addSelfSessions: async () => undefined,
}))
vi.mock('@/app/router', () => ({ navigate: (n: string, p?: Record<string, string>) => { h.nav.push([n, p]) }, useRoute: () => ({ name: 'danes', params: {} }) }))
vi.mock('@/ui/useAi', () => ({ useAi: () => ({ busy: false, signedIn: true, consent: true, run: async (fn: () => Promise<unknown>) => fn(), sheet: null }) }))
vi.mock('@/domain/ai/client', () => {
  class AiError extends Error { kind: string; constructor(kind: string, m: string) { super(m); this.kind = kind } }
  return { AiError, askText: async () => '', askJson: async () => JSON.parse(JSON.stringify(h.json)) }
})
vi.mock('@/domain/ai/image', () => ({ fileToBase64Resized: async () => ({ data: 'AAAA', mime: 'image/jpeg', thumb: '' }), exifStamp: async () => null }))

import { PhotoTrainingSheet } from '@/ui/PhotoTrainingSheet'
import type { PhotoReq } from '@/ui/photoOpen'
import type { PlanDay, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const TODAY = '2026-10-22', YDAY = '2026-10-21'
const NOW = `${TODAY}T08:00:00.000Z`
const P = { sex: 'm', age: 21, heightCm: 182, weightKg: 78, ftp: 250, lthr: 172, aiConsentAt: NOW, aiConsentV: 2, gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: true }, onboardingDone: true } as unknown as Profile
const day = (o: Partial<PlanDay> & Pick<PlanDay, 'id' | 'date' | 'kind'>): PlanDay => ({ title: 'Z2 vzdržljivost', desc: '', durationMin: 60, source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })
const reset = (o: Record<string, unknown> = {}) => {
  S.state = { today: TODAY, plan: [day({ id: 'k', date: TODAY, kind: 'kolo' }), day({ id: 't', date: YDAY, kind: 'tek', title: 'Lahek tek', durationMin: 40 })], activities: [], profile: P, user: { uid: 'u' }, settings: {}, ...o }
  S.subs.forEach(f => f())
}
let div: HTMLDivElement | null = null, root: Root | null = null
async function render(el: ReactElement) { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div); await act(async () => { root!.render(el) }); await act(async () => { await new Promise(r => setTimeout(r, 0)) }); return document.body }
const sp = (x: string | null | undefined) => (x || '').replace(/[  ⁠]/g, ' ')
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(sp(b.textContent))) as HTMLButtonElement | undefined
const file = () => new File(['x'], 'p.jpg', { type: 'image/jpeg' })
const sheet = (req: PhotoReq) => <PhotoTrainingSheet req={req} />

beforeEach(() => { h.nav.length = 0; h.saved.length = 0; h.added.length = 0; reset() })
afterEach(() => { act(() => root?.unmount()); div?.remove(); div = null; root = null; document.body.innerHTML = ''; Object.defineProperty(navigator, 'onLine', { value: true, configurable: true }) })

describe('list »Trening s slike«', () => {
  it('opravljen trening iz »Včeraj … si ga naredil?«: predogled izbere včerajšnji tek, »Shrani in odkljukaj« ga poveže', async () => {
    h.json = { app: 'garmin', sport: 'tek', datum: null, trajanje_min: 38, razdalja_km: 6.2, povprecni_utrip: 151, zanesljivost: 'visoka' }
    const b = await render(sheet({ mode: 'done', dayId: 't', file: file() }))
    expect(sp(b.textContent)).toMatch(/Preveri, kar sem prebral/)
    expect((b.querySelector('#ph-day') as HTMLSelectElement).value).toBe('t')
    expect(sp(b.textContent)).toMatch(/Odkljukam »Lahek tek«/)
    await act(async () => { btn(/Shrani in odkljukaj/)!.click() })
    const [a, id] = h.saved[0] as [{ date: string; durationMin: number }, string]
    expect(id).toBe('t'); expect(a.date).toBe(YDAY); expect(a.durationMin).toBe(38)
  })
  it('brez povezave: jasno sporočilo in »Vpiši ročno« z dnem (datum izbranega dne)', async () => {
    Object.defineProperty(navigator, 'onLine', { value: false, configurable: true })
    const b = await render(sheet({ mode: 'done', dayId: 't' }))
    expect(sp(b.textContent)).toMatch(/Ni povezave z internetom/)
    expect(btn(/^ ?Slikaj$/)).toBeUndefined()
    await act(async () => { btn(/Vpiši ročno/)!.click() })
    expect(h.nav[0]).toEqual(['aktivnosti', { nova: '1', datum: YDAY }])
  })
  it('trening s slike: predogled pokaže, kar bo vodila vodena vadba; »Dodaj v načrt« na izbrani dan', async () => {
    h.json = { vrsta: 'kolo', naslov: 'Zwift VO2', koraki: [{ tip: 'ogrevanje', min: 10 }, { tip: 'ponovitve', ponovitve: 5, delo_s: 180, odmor_s: 120, intenzivnost: 'RPE 9' }, { tip: 'iztek', min: 5 }] }
    const b = await render(sheet({ mode: 'plan', date: TODAY, file: file() }))
    expect(sp(b.textContent)).toMatch(/Vodena vadba:.*5 × 3 min/)
    expect(sp(b.textContent)).toMatch(/Namesto: Z2 vzdržljivost/)
    await act(async () => { btn(/Dodaj v načrt/)!.click() })
    const [d, rid] = h.added[0] as [PlanDay, string | null]
    expect(d.date).toBe(TODAY); expect(rid).toBeNull(); expect(d.desc).toMatch(/5 × \(3 min pri RPE 9 \/ 2 min lahko\)/)
  })
  it('slika sebe pod 18 let: samo besedilo in pot do Vaj, brez gumba za sliko', async () => {
    reset({ profile: { ...P, age: 16 } })
    const b = await render(sheet({ mode: 'self' }))
    expect(sp(b.textContent)).toMatch(/Za mlajše od 18 let ocene s slike ne delam — vaje za držo pa so v Vajah\./)
    expect(btn(/Slikaj/)).toBeUndefined()
    await act(async () => { btn(/Odpri Vaje/)!.click() })
    expect(h.nav[0]?.[0]).toBe('vaje')
  })
})
