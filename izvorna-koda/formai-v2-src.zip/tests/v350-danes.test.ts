// v3.50 DANES (domena): »Noge bolijo« → moč res brez nog (A01), »Imam samo …« samo dosežene minute (A08),
// pripravljenost brez vnosa je ni in »kondicija pada« (A09, H14), ena beseda za pripravljenost (H14), naslednja seja
// po vadbi (A34), gumb spodaj za hribe in napis (A30, A44), lokalni nasvet: tekma brez OH (A43), bolezen (H13),
// malo vadb (H35), neoznačeni dnevi tega tedna (H29), »nimam tekme« (H34), trak tedna kolo pred močjo (B22).
import { describe, it, expect, vi } from 'vitest'

// Danes.tsx (coachLine, routeSum) vleče shrambo in usmerjevalnik — tu ju ne rabimo
vi.mock('@/state/store', () => ({ useApp: () => null, getState: () => null, toast: vi.fn(), setPlanDone: vi.fn(), addCore: vi.fn() }))
vi.mock('@/app/router', () => ({ navigate: () => undefined, useRoute: () => ({ name: 'danes', params: {} }) }))

import { adaptToState, legFreeExercises } from '../src/domain/training/state'
import { shortOptions, shortChoices, shortenDay, nextSession, strengthFuel } from '../src/domain/training/danes'
import { readinessOf, readinessLabel } from '../src/domain/readiness'
import { pillDay, pillLabel } from '../src/ui/runState'
import { coachLine, routeSum } from '../src/screens/Danes'
import { localAdvice, type LocalCoachCtx } from '../src/domain/coach/local'
import { unmarkedRecent, yesterdayUnmarked } from '../src/domain/training/missed'
import { noRaceWish, seasonCardOn } from '../src/domain/start'
import { exLogOf } from '../src/ui/SessBits'
import type { Activity, PlanDay, Profile } from '../src/domain/types'

const TODAY = '2026-10-18'   // nedelja
const NOW = `${TODAY}T08:00:00.000Z`
const day = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: date + (o.kind || 'kolo') + (o.title || ''), date, kind: 'kolo', title: 'Z2', desc: '', durationMin: 60, zone: 'Z2', role: 'lahka', tssTarget: 42, source: 'rules', createdAt: NOW, updatedAt: NOW, done: null, ...o })
const rest = (date: string) => day(date, { kind: 'pocitek', title: 'Počitek', durationMin: 0, zone: null, role: null, tssTarget: 0 })
// Blaž iz posnetkov v3.49.0: brez merilnika, LTHR 184, FTP 240, moč doma
const P = { sex: 'm', age: 21, heightCm: 180, weightKg: 79, ftp: 240, lthr: 184, maxHr: 195, restHr: 48, gear: { bikeOutdoor: true, trainer: true, noBike: false, powerMeter: false }, strength: { on: true, equipment: 'home' }, strengthDays: 2, hoursPerWeek: 8, goal: 'forma', onboardingDone: true, createdAt: NOW, updatedAt: NOW } as unknown as Profile
const tempo = day(TODAY, { title: 'Tempo 3 × 10 min', desc: '20 min ogrevanje s 3 kratkimi pospeški · 3 × 10 min pri utrip 166–171 (≈ 182–204 W, brez merilnika po občutku), vmes 5 min lahko · 15 min iztek. Prvi malo trši trening sezone: enakomerno, pogovor še mogoč v kratkih stavkih.', durationMin: 75, zone: 'Z3', role: 'kljucna', tssTarget: 59, target: { lo: 182, hi: 204 } })
const noge = day(TODAY, { kind: 'moc', title: 'Moč — noge in jedro', desc: 'Počasi in s kontrolo. Noge za klance in stabilnost; ko dosežeš zgornjo mejo ponovitev, dodaj težo (nahrbtnik ali uteži).', durationMin: 30, zone: null, role: 'moc', tssTarget: 24, why: 'Noge za klance, zaščita pred poškodbami.', exercises: [{ name: 'Bolgarski počep', sets: 3, reps: '8–12', kg: null }, { name: 'Izpadni koraki', sets: 3, reps: '10–12', kg: null }, { name: 'Dvigi na prste', sets: 3, reps: '15–20', kg: null }, { name: 'Deska', sets: 3, reps: '45–60 s', kg: null }] })

describe('A01: »Noge bolijo« → moč brez vaj za noge', () => {
  it('dan moči: brez počepov, izpadnih korakov in dvigov na prste; naslov in »zakaj« o trupu; prvotno v prev', () => {
    const r = adaptToState(P, [tempo, noge], TODAY, { level: 3, legs: true, reasons: ['noge bolijo'] }, { now: NOW })!
    const m = r.days.find(d => d.kind === 'moc')!
    expect(m.exercises!.map(e => e.name)).toEqual(['Deska', 'Stranska deska', 'Dead bug'])
    expect(m.exercises!.some(e => /počep|izpadni|prste/i.test(e.name))).toBe(false)
    expect(m.title).toBe('Moč — samo jedro')
    expect(m.desc).toMatch(/^Noge počivajo\. Samo trup: deska, stranska deska, dead bug — brez počepov in izpadnih korakov\./)
    expect(m.why).toBe('Noge danes počivajo, trup lahko dela.')
    expect(m.optional).toBe(true)
    expect(m.durationMin).toBe(15)
    // »Vrni po načrtu« dobi prvotne vaje in naslov
    expect(m.byState?.prev?.exercises?.map(e => e.name)).toEqual(['Bolgarski počep', 'Izpadni koraki', 'Dvigi na prste', 'Deska'])
    expect(m.byState?.prev?.title).toBe('Moč — noge in jedro')
  })
  it('fitnes zgornji del ostane (brez nog), neznane vaje za noge po imenu odpadejo', () => {
    const r = legFreeExercises([{ name: 'Polovični počep s palico', sets: 4, reps: '5–8' }, { name: 'Potisk s palico na ravni klopi', sets: 3, reps: '6–8' }, { name: 'Poteg na prsi', sets: 3, reps: '8–10' }, { name: 'Dvig kolena na kablu (upogib kolka)', sets: 3, reps: '8–10' }, { name: 'Pallof press', sets: 3, reps: '10–12' }])
    expect(r.exercises.map(e => e.name)).toEqual(['Potisk s palico na ravni klopi', 'Poteg na prsi', 'Pallof press'])
    expect(r.coreOnly).toBe(false)
  })
})

describe('A08: »Imam samo …« samo minute, ki jih trening doseže', () => {
  it('Tempo 3 × 10 (75 min): 20, 30 in 45 so vsi dali 50 → izbiri 50 min in 1 h, spodnja meja 50', () => {
    expect(shortOptions(tempo)).toEqual([20, 30, 45, 60])
    expect(shortenDay(tempo, P, 20)!.min).toBe(50)
    const c = shortChoices(tempo, P)
    expect(c.mins).toEqual([50, 60])
    expect(c.floor).toBe(50)
  })
  it('dolga Z2 (120 min): vsaka želja je dosežena, brez spodnje meje', () => {
    const dolga = day(TODAY, { title: 'Dolga Z2', desc: 'Enakomerno Z2.', durationMin: 120, role: 'dolga' })
    const c = shortChoices(dolga, P)
    expect(c.mins).toEqual([30, 45, 60, 90])
    expect(c.floor).toBeNull()
  })
})

describe('A09/H14: pripravljenost', () => {
  it('brez jutranjega vnosa in brez ure je ni (prej »60« iz same forme); z vnosom je', () => {
    expect(readinessOf(2, null, null)).toBeNull()
    expect(readinessOf(31, null, null)).toBeNull()
    expect(readinessOf(2, { date: TODAY, mood: 4 }, null)!.score).toBeGreaterThan(0)
    expect(readinessOf(null, { date: TODAY, weightKg: 84 }, null)).toBeNull()
  })
  it('»kondicija pada«, ne »forma pada« (forma je na istem zaslonu +32); ena meja za besedo (dobra od 70)', () => {
    const r = readinessOf(32, { date: TODAY, mood: 3, soreness: 1 }, null)!
    expect(r.reasons[0]).toBe('dolgo brez rednega treninga — kondicija pada')
    expect(r.reasons.join()).not.toMatch(/forma/)
    expect(readinessLabel(63)).toBe('srednja')
    expect(readinessLabel(70)).toBe('dobra')
    expect(readinessLabel(44)).toBe('nizka')
  })
})

describe('A34: naslednja seja po končani vadbi', () => {
  it('po kolesu je najprej še današnja moč, šele nato torek', () => {
    const tue = day('2026-10-20', { title: 'Z2 + 4 × 30 s pospeški' })
    const n = nextSession([tempo, noge, tue], tempo)!
    expect(n.day.id).toBe(noge.id)
    expect(n.sameDay).toBe(true)
    // moč opravljena → naslednji dan
    const n2 = nextSession([tempo, { ...noge, done: { at: NOW } }, tue], tempo)!
    expect(n2.day.id).toBe(tue.id)
    expect(n2.sameDay).toBe(false)
  })
})

describe('A30/A44: gumb spodaj', () => {
  it('hribi namesto kolesa dobijo gumb »Začni hojo«; ob kolesu in moči »Začni kolo«, sicer »Začni trening«', () => {
    const hike = day(TODAY, { kind: 'pohod', title: 'Hribi', swap: { kind: 'kolo', title: 'Tempo', desc: '', durationMin: 75, zone: 'Z3', tssTarget: 59, role: 'kljucna', target: null } })
    expect(pillDay([hike], TODAY)?.id).toBe(hike.id)
    expect(pillLabel(hike)).toBe('Začni hojo')
    expect(pillLabel(tempo, { others: true })).toBe('Začni kolo')
    expect(pillLabel(tempo)).toBe('Začni trening')
    expect(pillLabel({ kind: 'kolo', optional: true })).toBe('Začni (po želji)')
    expect(pillLabel(tempo, { running: true })).toBe('Nadaljuj trening')
    // kolo pred hribi, ko sta oba
    expect(pillDay([hike, tempo], TODAY)?.id).toBe(tempo.id)
  })
})

describe('A43/H13/H35: lokalni nasvet »Trener pravi«', () => {
  const race = { kind: 'kolo', role: 'dirka', raceId: 'r1' }
  it('tekma brez OH (30-min kronometer): »samo voda«, ne »po urniku goriva«', () => {
    expect(coachLine(5, race, 5, 5, 78, { carbs: 0 })).not.toMatch(/urniku goriva/)
    expect(coachLine(5, race, 5, 5, 78, { carbs: 0 })).toMatch(/samo voda/)
    expect(coachLine(5, race, 5, 5, 78, { carbs: 60 })).toMatch(/urniku goriva/)
  })
  it('bolezen: počitek, tekočina, spanec — ne »drži se načrta«', () => {
    const t = coachLine(1, { kind: 'pocitek' }, 5, 5, null, { sick: true })
    expect(t).toMatch(/^Bolan si/)
    expect(t).not.toMatch(/pravem območju|Drži se načrta/)
  })
  it('manj kot 3 vadbe: na dan počitka »jutri X«, na dan treninga »začni mirno« — brez »pravem območju«', () => {
    const r = coachLine(1, { kind: 'pocitek' }, 1, 1, null, { tomorrow: { kind: 'tek', title: 'Tek in hoja', durationMin: 25 } })
    expect(r).toBe('Danes počitek. Jutri: Tek in hoja, 25 min. Spanec in hrana sta del treninga.')
    expect(coachLine(1, { kind: 'pocitek' }, 1, 1, null)).not.toMatch(/pravem območju/)
    expect(coachLine(1, { kind: 'tek', title: 'Tek in hoja', durationMin: 25, role: 'lahka' }, 1, 1, null)).toBe('Danes: Tek in hoja, 25 min. Začni mirno — spanec in hrana sta del treninga.')
    // z zgodovino kot prej
    expect(coachLine(1, { kind: 'pocitek' }, 5, 5, null)).toMatch(/pravem območju/)
  })
  it('zložena vrstica trase po stanju', () => {
    expect(routeSum(false, false, false)).toBe('poveži intervals.icu za predloge')
    expect(routeSum(true, false, true)).toBe('nariši novo traso')
    expect(routeSum(true, true, true)).toBe('predlog po meri treninga · GPX · na uro')
  })
})

describe('H13/H14: trener brez AI', () => {
  const ctx = (o: Partial<LocalCoachCtx> = {}): LocalCoachCtx => ({ profile: P, plan: [tempo], activities: [], checkins: [], checkinToday: null, wellness: null, wellnessOn: false, mealsToday: [], recentMeals: [], weather: null, today: TODAY, ...o })
  it('bolan: prva vrstica o počitku, brez »Danes: Tempo«', () => {
    const t = localAdvice(ctx({ profile: { ...P, sick: { from: '2026-10-17', to: '2026-10-21' } } as Profile }))
    expect(t).toMatch(/^Bolan si — danes samo počitek, tekočina in spanec/)
    expect(t).not.toMatch(/Danes: Tempo/)
  })
  it('pripravljenost 63 je »srednja« kot čip (prej »dobra« od 60)', () => {
    const acts: Activity[] = Array.from({ length: 12 }, (_, i) => ({ id: 'a' + i, source: 'manual', sport: 'kolo', date: `2026-10-${String(5 + i).padStart(2, '0')}`, durationMin: 60, tss: 40, name: 'Z2', aiEligible: true, geoRetain: false, createdAt: NOW, updatedAt: NOW } as unknown as Activity))
    const t = localAdvice(ctx({ activities: acts, checkinToday: { date: TODAY, mood: 3, soreness: 3, sleepH: 7 } }))
    const m = /Pripravljenost (\d+) — (\w+)/.exec(t)!
    expect(m).toBeTruthy()
    expect(m[2]).toBe(readinessLabel(+m[1]!))
  })
})

describe('H29: neoznačeni treningi tega tedna', () => {
  it('sreda: ponedeljkov tek brez kljukice je na seznamu (včeraj počitek)', () => {
    const wed = '2026-10-21'
    const mon = day('2026-10-19', { kind: 'tek', title: 'Tek in hoja', durationMin: 25 })
    const s = { today: wed, activities: [], plan: [mon, rest('2026-10-20'), day(wed, { kind: 'tek', title: 'Tek', durationMin: 25 })] }
    expect(yesterdayUnmarked(s)).toBeNull()
    expect(unmarkedRecent(s).map(d => d.id)).toEqual([mon.id])
  })
  it('včeraj in predvčerajšnjim: največ dve, od včeraj nazaj; prestavljen ključni (missed) in opravljen ne', () => {
    const d1 = day('2026-10-17', { title: 'Sobota Z2' }), d2 = day('2026-10-16', { title: 'Petek Z2' }), d3 = day('2026-10-15', { title: 'Četrtek Z2' })
    expect(unmarkedRecent({ today: TODAY, activities: [], plan: [d1, d2, d3] }).map(d => d.title)).toEqual(['Sobota Z2', 'Petek Z2'])
    expect(unmarkedRecent({ today: TODAY, activities: [], plan: [{ ...d1, missed: 'moved' }, { ...d2, done: { at: NOW } }, d3] }).map(d => d.title)).toEqual(['Četrtek Z2'])
    // ponedeljek: včeraj (nedelja prejšnjega tedna) še šteje
    expect(unmarkedRecent({ today: '2026-10-19', activities: [], plan: [day(TODAY, { title: 'Ned' })] }).map(d => d.title)).toEqual(['Ned'])
  })
})

describe('H34: kolesar brez tekme (zdravje)', () => {
  const focus = (wish: string, aims: string[]) => ({ v: 1, mode: 'kolo', wish, aims, sports: ['kolo'], muscles: [], level: 3, equipment: ['nic'], limits: null, sessions: [], offDays: null, notes: [], title: 'Kolo', by: 'pravila', at: NOW })
  it('»Nimam tekme, hočem ostati zdrav« → brez poziva k dirki; tekmovalec ga ima', () => {
    expect(noRaceWish({ focus: focus('Cilj: zdravje in počutje. Nimam tekme, hočem ostati zdrav in v formi.', ['tekma', 'zdravje']), races: null } as never)).toBe(true)
    expect(noRaceWish({ focus: focus('Rad bi bil hitrejši.', ['zdravje']), races: null } as never)).toBe(true)
    expect(noRaceWish({ focus: focus('Maraton Franja 2027.', ['tekma']), races: null } as never)).toBe(false)
    expect(noRaceWish({ focus: focus('Nimam tekme.', ['zdravje']), races: [{ id: 'r', name: 'K', date: '2026-11-01' }] } as never)).toBe(false)
    expect(noRaceWish({ focus: null, races: null } as never)).toBe(false)
    // kartica cilja sezone (kolesar s ciljem dirka) kot prej
    expect(seasonCardOn({ event: null, goal: 'dirka' } as never)).toBe(true)
  })
})

describe('A12: moč na dan brez vožnje — »Pred« brez »po kolesu«', () => {
  it('strengthFuel: samo moč → lahek obrok; z vožnjo istega dne ostane', () => {
    const f = { before: 'Nič posebnega — lahko takoj po kolesu.', during: 'Voda.', after: 'Beljakovine.' }
    expect(strengthFuel(f, noge, false)!.before).toBe('Lahek obrok 1–2 h prej (jogurt s sadjem, kruh z jajcem).')
    expect(strengthFuel(f, noge, true)!.before).toMatch(/po kolesu/)
    expect(strengthFuel(f, tempo, false)).toBe(f)
  })
  it('trener brez AI na dan samo z močjo: »Pred« brez »po kolesu«', () => {
    const t = localAdvice({ profile: P, plan: [{ ...noge, durationMin: 50 }], activities: [], checkins: [], checkinToday: null, wellness: null, wellnessOn: false, mealsToday: [], recentMeals: [], weather: null, today: TODAY })
    expect(t).toMatch(/Pred: (Lahek obrok 1–2 h prej|.*pred vadbo)/)   // (po združitvi) razpored obrokov tudi za moč (D17)
    expect(t).not.toMatch(/po kolesu/)
  })
})

describe('A22: zapis vaje iz vodene vadbe', () => {
  it('»11, 11, 11« je narejeno; načrt »8–12« ni', () => {
    expect(exLogOf([{ name: 'Bolgarski počep', sets: 3, reps: '11, 11, 11', kg: 12 }], 'bolgarski počep')?.reps).toBe('11, 11, 11')
    expect(exLogOf([{ name: 'Bolgarski počep', sets: 3, reps: '8–12' }], 'Bolgarski počep')).toBeNull()
    expect(exLogOf(null, 'Deska')).toBeNull()
  })
})
