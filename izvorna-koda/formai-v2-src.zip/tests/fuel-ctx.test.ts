import { describe, it, expect } from 'vitest'
import { rideFuel, fluidPerHour, fluidFactorOf, fuelEntry } from '../src/domain/nutrition/dayplan'
import type { MealEntry, PlanDay } from '../src/domain/types'

const now = new Date().toISOString()
const day = (o: Partial<PlanDay> = {}): PlanDay => ({ id: 'd1', date: '2026-09-24', kind: 'kolo', title: 'Sweet spot 3 × 12 min', desc: '', durationMin: 90, zone: 'Z3', role: 'kljucna', source: 'rules', createdAt: now, updatedAt: now, ...o })
const log = (date: string, fluidMl: number, planMl: number): MealEntry => ({ id: date, date, slot: 'med_vadbo', name: 'Na kolesu', kcal: 200, source: 'manual', createdAt: now, fluidMl, planMl })

describe('tekočina na kolesu po temperaturi in po tem, koliko spiješ', () => {
  it('hladno manj, vroče več', () => {
    expect(fluidPerHour(10, false)).toBe(350)
    expect(fluidPerHour(19, true)).toBe(600)
    expect(fluidPerHour(30, true)).toBe(900)
  })
  it('sweet spot 90 min pri 17 °C: en bidon izotonika, ne dva; OH iz trde hrane', () => {
    const f = rideFuel(day(), ['iso_domaci', 'frutabela', 'banana', 'gel'], { tempC: 17 })!
    expect(f.fluidMl).toBe(750)
    expect(f.plan.find(x => x.key === 'iso_domaci')?.n).toBe(1)
    expect(f.plan.some(x => x.key === 'voda')).toBe(false)
    expect(f.carriedCarbs).toBeGreaterThanOrEqual(f.totalCarbs - 10)
    expect(f.fluidNote).toContain('17 °C')
    const hot = rideFuel(day(), null, { tempC: 29 })!
    expect(hot.fluidMl).toBe(1350)
    expect(hot.bottles).toBe(2)
  })
  it('uči se: dvakrat spil ~polovico → naslednjič manj (a ne pod 70 %)', () => {
    expect(fluidFactorOf([], '2026-09-24')).toEqual({ f: 1, n: 0 })
    expect(fluidFactorOf([log('2026-09-24', 750, 1500)], '2026-09-24').f).toBe(0.75)
    expect(fluidFactorOf([log('2026-09-20', 750, 1500), log('2026-09-24', 700, 1400)], '2026-09-24').f).toBe(0.7)
    expect(fluidFactorOf([log('2026-06-01', 300, 1500)], '2026-09-24').n).toBe(0)       // starejše od 60 dni ne šteje
    const f = rideFuel(day(), null, { tempC: 20, fluidFactor: 0.75 })!
    expect(f.fluidMl).toBe(700)
    expect(f.fluidNote).toContain('koliko spiješ ti')
  })
  it('vpis »Na kolesu«: bidon in pol + Frutabela = kalorije, OH in tekočina', () => {
    const f = rideFuel(day(), ['iso_domaci', 'frutabela', 'gel'], { tempC: 17 })!
    const e = fuelEntry(f, { iso_domaci: 1.5, frutabela: 1, gel: 0 }, 'Sweet spot')
    expect(e.kcal).toBe(340)
    expect(e.carbsG).toBe(79)
    expect(e.fluidMl).toBe(1125)
    expect(e.planMl).toBe(f.fluidMl)
    expect(e.name).toBe('Na kolesu (Sweet spot): 1,5 × bidon domačega izotonika, 1 × Frutabela')
    expect(fuelEntry(f, {}, 'X').name).toContain('nič')
  })
})
