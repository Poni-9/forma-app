// v3.48 D2 (shramba): obvestilo »Novo: …« ne za nove uporabnike; tap obvestilo zapre.
import 'fake-indexeddb/auto'
import { describe, it, expect, vi } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => {}, idToken: async () => null,
  proFromFirestore: async () => false, setAccountDeleteHooks: () => {}, deleteAccount: async () => ({ ok: true, reauth: false }),
}))

import { helpHintFor, HELP_HINT_BEFORE, toast, dismissToast, getState } from '../src/state/store'

describe('D13 — »Novo: »?« zgoraj …«', () => {
  it('nov uporabnik (začel danes ali po v3.29) obvestila ne dobi; kdor je začel prej, ga dobi enkrat', () => {
    expect(HELP_HINT_BEFORE).toBe('2026-10-04')
    expect(helpHintFor({ onboardingDone: true, createdAt: new Date().toISOString() })).toBe(false)
    expect(helpHintFor({ onboardingDone: true, createdAt: '2026-10-04T10:00:00.000Z' })).toBe(false)
    expect(helpHintFor({ onboardingDone: true, createdAt: '2026-09-20T10:00:00.000Z' })).toBe(true)
    expect(helpHintFor({ onboardingDone: false, createdAt: '2026-09-20T10:00:00.000Z' })).toBe(false)
  })
  it('tap zapre obvestilo; zastarel id ne zapre novega', () => {
    toast('Prvo', 'info', 60_000)
    const first = getState().toast!.id
    toast('Drugo', 'info', 60_000)
    dismissToast(first)
    expect(getState().toast?.msg).toBe('Drugo')
    dismissToast(getState().toast!.id)
    expect(getState().toast).toBeNull()
  })
})
