// Časovnica goriva (trak, hrana po času, skupaj) in napredek tedna.
import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, beforeEach, afterEach } from 'vitest'
import { FuelTimeline, drinkLine } from '@/ui/FuelTimeline'
import { RateRow } from '@/ui/RateRow'
import { rideFuel } from '@/domain/nutrition/dayplan'
import { weekProgress } from '@/domain/training/share'
import type { PlanDay } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
let div: HTMLDivElement, root: Root
const render = async (el: React.ReactNode) => { await act(async () => { root.render(el) }) }
beforeEach(() => { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div) })
afterEach(async () => { await act(async () => root.unmount()); div.remove() })

const NOW = '2026-10-02T10:00:00.000Z'
const d = (date: string, o: Partial<PlanDay> = {}): PlanDay => ({ id: 'p' + date + (o.kind || 'kolo') + (o.title || ''), date, kind: 'kolo', title: 'Dolga Z2', desc: '', durationMin: 140, zone: 'Z2', tssTarget: 99, role: 'dolga', source: 'rules', createdAt: NOW, updatedAt: NOW, ...o })

describe('časovnica goriva', () => {
  it('oznaka za vsak opomnik, hrana po času, skupaj; bralnik zaslona dobi vse kot besedilo', async () => {
    const rf = rideFuel(d('2026-10-03'), ['domaci_izotonik', 'banana', 'frutabela'], { tempC: 20 })!
    expect(rf.cues.length).toBeGreaterThan(3)
    await render(<FuelTimeline rf={rf} minutes={140} />)
    expect(div.querySelectorAll('.track .cue').length).toBe(rf.cues.length)
    const food = rf.cues.filter(c => c.solid)
    expect(div.querySelectorAll('.foods .food-chip').length).toBe(food.length)
    const label = div.querySelector('[role=img]')!.getAttribute('aria-label')!
    expect(label).toMatch(/^Časovnica goriva: 0:30 /)
    expect(label).toContain(`~${rf.totalCarbs} g OH`)
    expect(div.textContent).toContain('2:20')
    expect(drinkLine(rf)).toMatch(/^Pij od začetka: .*\.$/)
    expect(drinkLine(rf)).not.toContain('Hrana:')
  })
  it('brez opomnikov (kratka ali lahka vožnja) ni časovnice', async () => {
    const rf = rideFuel(d('2026-10-03', { durationMin: 45, role: 'regen', zone: 'Z1' }), null, {})!
    await render(<FuelTimeline rf={rf} minutes={45} />)
    expect(div.innerHTML).toBe('')
  })
})

describe('občutek v eni vrsti', () => {
  it('pet stopenj, izbrana je najbližja vpisani vrednosti; ponoven tap pobriše', async () => {
    const picks: (number | null)[] = []
    await render(<RateRow value={7} onPick={v => picks.push(v)} />)
    const btns = [...div.querySelectorAll('button')]
    expect(btns.map(b => b.textContent)).toEqual(['lahkotno', 'lahko', 'srednje', 'težko', 'do konca'])
    expect(btns.filter(b => b.getAttribute('aria-pressed') === 'true').map(b => b.textContent)).toEqual(['srednje'])
    await act(async () => { btns[2]!.click() }); await act(async () => { btns[3]!.click() })
    expect(picks).toEqual([null, 8])
  })
})

describe('napredek tedna', () => {
  it('seje in minute: opravljeno z dejanskim časom vadbe, počitek in »po želji« ne štejeta', () => {
    const week = [
      d('2026-09-28', { kind: 'pocitek', title: 'Počitek', durationMin: 0 }),
      d('2026-09-29', { title: 'VO2max', durationMin: 75, done: { at: NOW, activityId: 'a1' } }),
      d('2026-09-30', { title: 'Z2', durationMin: 60, done: { at: NOW, activityId: null } }),
      d('2026-10-01', { title: 'Z2', durationMin: 90 }),
      d('2026-10-01', { kind: 'moc', title: 'Jedro', durationMin: 20, optional: true }),
    ]
    expect(weekProgress(week, [{ id: 'a1', durationMin: 82.4 }])).toEqual({ done: 2, total: 3, minDone: 142, minAll: 225 })
  })
})
