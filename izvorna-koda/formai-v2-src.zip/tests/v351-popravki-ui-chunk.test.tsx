// v3.51 POPRAVKI51-UI (U3): leni deli z mejo napake — neuspel prenos (brez povezave) ne podre zaslona ali aplikacije.
import { act, Component, type ReactNode } from 'react'
import { createRoot } from 'react-dom/client'
import { readdirSync, readFileSync, statSync } from 'node:fs'
import { join, relative } from 'node:path'
import { describe, it, expect, vi, beforeAll } from 'vitest'
;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
const ERR = 'Failed to fetch dynamically imported module: /assets/X.js'
vi.mock('@/ui/InstallSheet', () => { throw new Error(ERR) })
vi.mock('@/ui/RouteCard', () => { throw new Error(ERR) })
vi.mock('@/ui/FuelLog', () => { throw new Error(ERR) })
vi.mock('@/ui/LastWeekCard', () => { throw new Error(ERR) })
vi.mock('@/data/errlog', () => ({ noteError: () => undefined }))
vi.mock('@/state/store', () => ({ useApp: () => ({ today: '2026-10-19' }) }))   // ponedeljek: »Pretekli teden«
import { InstallSheet } from '@/ui/InstallSheetLazy'
import { RouteCard } from '@/ui/RouteCardLazy'
import { FuelLogCard } from '@/ui/FuelLogLazy'
import { LastWeekCard } from '@/ui/LastWeekCardLazy'

class Outer extends Component<{ children: ReactNode }, { e: string | null }> {
  state = { e: null as string | null }
  static getDerivedStateFromError(e: Error) { return { e: String(e.message) } }
  render() { return this.state.e ? <div id="outer">ZUNANJA MEJA: {this.state.e}</div> : this.props.children }
}
beforeAll(() => { Object.defineProperty(navigator, 'onLine', { configurable: true, get: () => false }); vi.spyOn(console, 'error').mockImplementation(() => undefined) })
async function show(el: ReactNode) {
  const d = document.createElement('div'); document.body.appendChild(d)
  const r = createRoot(d)
  await act(async () => { r.render(<Outer><section id="screen">{el}</section></Outer>) })
  for (let i = 0; i < 10; i++) await act(async () => { await new Promise(res => setTimeout(res, 5)) })
  const out = { outer: !!document.getElementById('outer'), text: (document.body.textContent || '').replace(/ /g, ' '), retry: [...document.querySelectorAll('button')].some(b => /Poskusi znova/.test(b.textContent || '')) }
  await act(async () => r.unmount()); d.remove(); document.body.innerHTML = ''
  return out
}
const DAY = { id: 'x', date: '2026-10-19', kind: 'kolo', title: 'Z2' } as never

describe('U3 neuspel prenos ostane lokalen', () => {
  it('InstallSheet (zunaj meje zaslona): list »Ni naloženo«, ne »Nekaj se je podrlo« za celo aplikacijo', async () => {
    const o = await show(<InstallSheet open onClose={() => undefined} />)
    expect(o.outer).toBe(false)
    expect(o.text).toContain('Daj FORMAI na zaslon')
    expect(o.text).toContain('Ni povezave')
    expect(o.retry).toBe(true)
  })
  it('RouteCard (trase na Danes): vrstica s »Poskusi znova«, zaslon ostane', async () => {
    const o = await show(<RouteCard day={DAY} compact />)
    expect(o.outer).toBe(false)
    expect(o.text).toContain('Trase — ni naloženo (ni povezave).')
    expect(o.retry).toBe(true)
  })
  it('FuelLogCard in LastWeekCard: brez kartice, zaslon ostane', async () => {
    const f = await show(<FuelLogCard day={DAY} rf={{} as never} meals={[]} />)
    expect([f.outer, f.text]).toEqual([false, ''])
    const l = await show(<LastWeekCard />)
    expect([l.outer, l.text]).toEqual([false, ''])
  })
})

/** vse datoteke .ts/.tsx v src */
function files(dir: string): string[] {
  return readdirSync(dir).flatMap(n => { const p = join(dir, n); return statSync(p).isDirectory() ? files(p) : /\.tsx?$/.test(n) ? [p] : [] })
}
describe('U3 vsak leni del ima mejo', () => {
  const SRC = join(__dirname, '..', 'src')
  const all = files(SRC).map(p => ({ p: relative(SRC, p).replace(/\\/g, '/'), s: readFileSync(p, 'utf8') }))
  it('React lazy( samo v retryLazy (app/chunk.ts) ali z lastnim nadomestkom ob napaki (.catch)', () => {
    const bad = all.filter(f => f.p !== 'app/chunk.ts' && /(^|[^.\w])lazy\s*(<[^>]*>)?\s*\(/.test(f.s))
      .filter(f => !/lazy\s*(<[^>]*>)?\s*\(\s*\(\)\s*=>\s*import\([^)]*\)[\s\S]{0,200}?\.catch\(/.test(f.s))
      .map(f => f.p)
    expect(bad).toEqual([])
  })
  it('retryLazy( samo z ChunkBoundary v isti datoteki (zasloni v App.tsx: orReload in ErrorBoundary)', () => {
    const bad = all.filter(f => f.p !== 'app/chunk.ts' && f.p !== 'app/App.tsx' && /retryLazy\(/.test(f.s) && !/<ChunkBoundary\b/.test(f.s)).map(f => f.p)
    expect(bad).toEqual([])
    expect(all.filter(f => /retryLazy\(/.test(f.s)).length).toBeGreaterThan(8)
  })
})
