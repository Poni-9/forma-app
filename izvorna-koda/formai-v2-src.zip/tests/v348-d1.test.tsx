// v3.48 D1: razponi (profil, ročni vnos, ročni cilj kcal), podrobnosti vadbe ob Esc, privolitev AI v Nastavitvah,
// en seznam »gre v AI / nikoli«, Kako deluje za načrt po meri, vodnik/dogovor brez ponavljanja, trener, obzorje.
import { act, useState, useSyncExternalStore } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

const S = vi.hoisted(() => ({ state: null as any, subs: new Set<() => void>() }))
const store = vi.hoisted(() => ({
  saveActivity: vi.fn(async (_a: unknown) => {}), rateSession: vi.fn(async () => {}), grantAiConsent: vi.fn(async () => {}), revokeAiConsent: vi.fn(async () => {}),
  updateProfile: vi.fn(async () => {}), updateSettings: vi.fn(async () => {}), toast: vi.fn(), saveCheckin: vi.fn(async () => {}),
}))
vi.mock('@/state/store', () => ({
  useApp: () => useSyncExternalStore((cb: () => void) => { S.subs.add(cb); return () => { S.subs.delete(cb) } }, () => S.state),
  getState: () => S.state,
  ...store,
  signIn: vi.fn(), signOut: vi.fn(), refreshWeather: vi.fn(), setStrength: vi.fn(), setWellnessOn: vi.fn(), removeWorkouts: vi.fn(), deleteAccountAll: vi.fn(), markExported: vi.fn(), LAST_EXPORT_KEY: 'x',
  savePlanDays: vi.fn(), newCoachChat: vi.fn(), restorePlanDays: vi.fn(), setOffDays: vi.fn(),
}))
vi.mock('@/app/Shell', () => ({ Head: () => null }))
vi.mock('@/ui/ClaudeAdmin', () => ({ ClaudeAdmin: () => null }))
vi.mock('@/ui/BackupImport', () => ({ BackupImport: () => null }))
vi.mock('@/ui/GoalCard', () => ({ GoalCard: () => null }))
vi.mock('@/ui/DealCard', () => ({ DealCard: () => null }))
vi.mock('@/data/db', () => ({ getKV: async () => undefined }))
vi.mock('@/data/repo', () => ({ wipeAll: vi.fn() }))
vi.mock('@/data/backup', () => ({ exportForFile: vi.fn() }))
vi.mock('@/data/sync', () => ({ syncNow: vi.fn() }))
vi.mock('@/data/feedback', () => ({ fetchFeedbackList: async () => ({ error: 'x' }), flushFeedback: async () => 0, queuedFeedback: async () => 0, captureScreen: async () => null }))
vi.mock('@/ui/theme', () => ({ THEME_PREFS: [['samodejno', 'kot telefon']], themePref: () => 'samodejno', setThemePref: vi.fn(), subscribeTheme: () => () => {} }))

import { profileErrors, manualActivityErrors, PROFILE_RANGE, rangeMsg } from '@/domain/ranges'
import { formOf, profilePatch, profileFormErrors, kcalOverrideNote, Nastavitve } from '@/screens/Ostalo'
import { ActivitySheet } from '@/ui/ActivitySheet'
import { PrivolitevSheet } from '@/screens/Privolitev'
import { AI_SENT, AI_NEVER } from '@/domain/ai/consent'
import { helpFor, HOW, TERMS } from '@/domain/glossary'
import { normalizeFocus, dealStrategy, weekLine } from '@/domain/focus/model'
import { notesFor, fitNotes, ruleStrategy } from '@/domain/focus/rules'
import { coachReview } from '@/domain/focus/coach'
import { quick } from '@/screens/Trener'
import { hzWeekLine } from '@/ui/PlanHero'
import type { Activity, Profile } from '@/domain/types'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

const today = new Date().toISOString().slice(0, 10)
const base = { sex: 'm', age: 30, heightCm: 180, weightKg: 78, maxHr: 190, restHr: 50, lthr: null, ftp: 250, ftpDate: '2026-09-01', hoursPerWeek: 6, bodyFatPct: null, gear: { bikeOutdoor: true, trainer: false, noBike: false, dumbbells: false, dumbbellKg: null }, strength: { on: false, equipment: 'none' }, strengthDays: 0, goal: 'hitrejsi', deficit: 0, neat: 1.4, proteinGkg: 1.8, onboardingDone: true, trainTime: null, createdAt: 'x', updatedAt: 'x' } as unknown as Profile
const reset = (p: Partial<Profile> = {}, acts: Activity[] = []) => { S.state = { ready: true, today, plan: [], activities: acts, checkins: [], recentMeals: [], weather: null, wellness: [], settings: { lang: 'sl', intervals: null }, sync: { state: 'off' }, user: null, pro: false, profile: { ...base, ...p } }; S.subs.forEach(f => f()) }

let div: HTMLDivElement, root: Root | null = null
async function mount(el: React.ReactElement) { div = document.createElement('div'); document.body.appendChild(div); root = createRoot(div); await act(async () => { root!.render(el) }) }
const flush = async () => { for (let i = 0; i < 5; i++) await act(async () => { await Promise.resolve() }) }
const setVal = async (el: HTMLInputElement | HTMLTextAreaElement, v: string) => {
  const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype
  await act(async () => { Object.getOwnPropertyDescriptor(proto, 'value')!.set!.call(el, v); el.dispatchEvent(new Event('input', { bubbles: true })) })
}
const btn = (re: RegExp) => [...document.querySelectorAll('button')].find(b => re.test(b.textContent || '')) as HTMLButtonElement | undefined

beforeEach(() => { reset(); Object.values(store).forEach(f => f.mockClear()); Element.prototype.scrollIntoView = vi.fn() })
afterEach(async () => { if (root) { await act(async () => root!.unmount()); root = null; div.remove() } document.body.innerHTML = '' })

describe('D01/D05 razponi profila', () => {
  it('7,6 kg, 18 cm in 300 let so tri napake; 76 kg ni napaka; prazno je v redu', () => {
    const e = profileErrors({ weight: '7,6', height: '18', age: '300' })
    expect(Object.keys(e).sort()).toEqual(['age', 'height', 'weight'])
    expect(e.weight).toBe('Teža: od 30 do 250 kg.')
    expect(e.height).toBe('Višina: od 120 do 230 cm.')
    expect(profileErrors({ weight: '76', height: '', age: '30' })).toEqual({})
    expect(rangeMsg('abc', PROFILE_RANGE.ftp)).toBe('FTP: od 50 do 600 W.')
  })
  it('Nastavitve: napačna vrednost se ne shrani (ne weightKg ne tehtanje); stara vrednost iz profila ne blokira', () => {
    const p = { ...base, ftpDate: '2026-09-20' }
    const init = formOf(p)
    const f = { ...init, weight: '7.6', height: '18', age: '300', name: 'Ana' }
    expect(Object.keys(profileFormErrors(init, f)).sort()).toEqual(['age', 'height', 'weight'])
    expect(profilePatch(init, f, p)).toEqual({ name: 'Ana' })
    expect(profilePatch(init, { ...init, weight: '76' }, p)).toEqual({ weightKg: 76 })
    // shranjena (stara) vrednost izven razpona: ni napake, dokler polja ne spremeniš
    const old = formOf({ ...p, weightKg: 7.6 })
    expect(profileFormErrors(old, { ...old, name: 'Ana' })).toEqual({})
  })
  it('Nastavitve: po odhodu iz polja sporočilo pod poljem, »Shrani profil« ne shrani', async () => {
    location.hash = '#/nastavitve?sec=n-profil'
    await mount(<Nastavitve />)
    const w = document.getElementById('pf-w') as HTMLInputElement
    await setVal(w, '7,6')
    expect(document.getElementById('pf-err')).toBeNull()            // med tipkanjem ni opozorila
    await act(async () => { w.dispatchEvent(new FocusEvent('focusout', { bubbles: true })) })
    expect(document.getElementById('pf-err')?.textContent).toBe('Teža: od 30 do 250 kg.')
    expect(w.getAttribute('aria-invalid')).toBe('true')
    expect(btn(/Shrani profil/)!.disabled).toBe(true)
    expect(store.updateProfile).not.toHaveBeenCalled()
    expect(store.saveCheckin).not.toHaveBeenCalled()
  })
})

describe('D02 ročni vnos vadbe', () => {
  it('−45 min, utrip 900 in 5000 W so napake; 60 min in utrip 140 ne', () => {
    expect(manualActivityErrors({ min: '-45' }).min).toBe('Trajanje: od 1 do 1440 min.')
    expect(manualActivityErrors({ hr: '900' }).hr).toBe('Utrip: od 30 do 230.')
    expect(manualActivityErrors({ power: 5000 }).power).toBe('Moč: od 0 do 2000 W.')
    expect(manualActivityErrors({ elev: '20000' }).elev).toBe('Vzpon: od 0 do 10 000 m.')
    expect(manualActivityErrors({ min: '60', hr: '140', dist: '', power: null })).toEqual({})
  })
})

describe('D15 ročni cilj kcal', () => {
  it('900 pove varno mejo, −500 je napaka, prazno je izračun', () => {
    const r = kcalOverrideNote(base, '900', today)
    expect(r.err).toBeNull()
    expect(r.note).toMatch(/^Pod varno mejo — velja \d/)
    expect(kcalOverrideNote(base, '-500', today).err).toBe('Ročni cilj: od 800 do 6000 kcal.')
    expect(kcalOverrideNote(base, '', today)).toEqual({ err: null, note: null })
    expect(kcalOverrideNote(base, '2800', today).note).toBeNull()
    expect(kcalOverrideNote({ ...base, age: 16 }, '2000', today).note).toMatch(/Do 18\. leta/)
  })
})

describe('D04 podrobnosti vadbe', () => {
  const act0 = { id: 'a1', source: 'manual', sport: 'kolo', date: today, start: null, name: 'Vožnja', distKm: 30, durationMin: 60, elevM: null, avgHr: null, avgPower: null, kcal: null, speedKmh: 30, tss: 50, polyline: null, createdAt: 'x', updatedAt: 'x' } as unknown as Activity
  function Host() { const [open, setOpen] = useState(true); return open ? <ActivitySheet id="a1" onClose={() => setOpen(false)} onDelete={() => {}} /> : <span id="closed" /> }
  it('Esc ne zavrže opombe', async () => {
    reset({}, [act0])
    history.replaceState(null, '', '#/aktivnosti')
    await mount(<Host />)
    await setVal(document.getElementById('act-note') as HTMLTextAreaElement, 'veter v prsi')
    await act(async () => { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })) })
    await flush()
    expect(document.getElementById('closed')).not.toBeNull()
    expect(store.saveActivity).toHaveBeenCalledTimes(1)
    expect(store.saveActivity.mock.calls[0]![0]).toMatchObject({ id: 'a1', notes: 'veter v prsi' })
  })
  it('»Končano« shrani ime in opombo v enem zapisu (prej je drugi zapis povozil ime)', async () => {
    reset({}, [act0])
    history.replaceState(null, '', '#/aktivnosti')
    await mount(<Host />)
    await setVal(document.getElementById('act-name') as HTMLInputElement, 'Vršič')
    await setVal(document.getElementById('act-note') as HTMLTextAreaElement, 'lepo')
    await act(async () => { btn(/Končano/)!.click() })
    await flush()
    const last = store.saveActivity.mock.calls.at(-1)![0]
    expect(last).toMatchObject({ name: 'Vršič', named: true, notes: 'lepo' })
  })
})

describe('D10/D31/D46 privolitev AI', () => {
  it('Nastavitve: vklop AI odpre list privolitve, privolitev se zapiše šele ob »Dovolim«; izklop je takojšen', async () => {
    location.hash = '#/nastavitve?sec=n-racun'
    await mount(<Nastavitve />)
    const chip = btn(/^izklopljena$/)!
    await act(async () => { chip.click() })
    expect(document.querySelector('[role="dialog"][aria-label="Kaj gre v umetno inteligenco"]')).not.toBeNull()
    expect(store.grantAiConsent).not.toHaveBeenCalled()
    await act(async () => { btn(/Dovolim analizo/)!.click() })
    await flush()
    expect(store.grantAiConsent).toHaveBeenCalledTimes(1)
    await act(async () => { root!.unmount() }); root = null; div.remove()
    reset({ aiConsentAt: '2026-10-01T00:00:00Z', aiConsentV: 2 } as Partial<Profile>)
    await mount(<Nastavitve />)
    await act(async () => { btn(/^vklopljena$/)!.click() })
    expect(store.revokeAiConsent).toHaveBeenCalledTimes(1)
    expect(document.querySelector('[role="dialog"]')).toBeNull()
  })
  it('isti seznam v listu privolitve (po alinejah) in v Nastavitvah — tudi slike za trenerja in GPS sled', async () => {
    expect(AI_SENT.join(' ')).toMatch(/priložiš trenerju/)
    expect(AI_NEVER.join(' ')).toMatch(/GPS sled/)
    await mount(<PrivolitevSheet open onClose={() => {}} onAccept={() => {}} />)
    const lis = [...document.querySelectorAll('[role="dialog"] li')].map(l => l.textContent)
    for (const t of [...AI_SENT, ...AI_NEVER]) expect(lis).toContain(t)
    await act(async () => { root!.unmount() }); root = null; div.remove()
    location.hash = '#/nastavitve?sec=n-racun'
    await mount(<Nastavitve />)
    const txt = document.querySelector('.ai-lists')!.textContent!
    for (const t of [...AI_SENT, ...AI_NEVER]) expect(txt).toContain(t)
  })
})

describe('D29/D30 Nastavitve → Prehrana', () => {
  it('skupine čipov imajo ime; »Kdaj treniraš« ima iste možnosti kot uvod in null = različno', async () => {
    location.hash = '#/nastavitve?sec=n-prehrana'
    await mount(<Nastavitve />)
    const g = document.querySelector('[role="group"][aria-labelledby="lbl-traintime"]')!
    expect(document.getElementById('lbl-traintime')!.textContent).toMatch(/Kdaj običajno treniraš/)
    expect([...g.querySelectorAll('button')].map(b => `${b.textContent}:${b.getAttribute('aria-pressed')}`)).toEqual(['zjutraj:false', 'čez dan:false', 'zvečer:false', 'različno:true'])
    expect(document.querySelector('[role="group"][aria-labelledby="lbl-deficit"]')).not.toBeNull()
    await act(async () => { [...g.querySelectorAll('button')][3]!.dispatchEvent(new MouseEvent('click', { bubbles: true })) })
    expect(store.updateProfile).toHaveBeenCalledWith({ trainTime: null })
  })
})

describe('D11 Kako deluje za načrt po meri', () => {
  const fit = normalizeFocus({ wish: 'fitnes', sports: ['fitnes'], aims: ['misice'], level: 1, sessions: [{ type: 'fitnes', part: 'celo', min: 50 }, { type: 'fitnes', part: 'celo', min: 50 }] }, { by: 'pravila' })!
  it('fitnes: brez FTP, W/kg, dirke in voženj; kolesar: kot prej; tapnjen izraz ostane', () => {
    const h = helpFor({ focus: fit })
    const all = [...h.how.map(x => `${x.t} ${x.d}`), ...h.terms.map(x => `${x.t} ${x.d}`)].join(' ')
    expect(all).not.toMatch(/FTP|W\/kg|dirk|vožnj|na kolesu/)
    expect(h.how).toHaveLength(HOW.length)
    expect(helpFor({ focus: null })).toEqual({ how: HOW, terms: TERMS })
    expect(helpFor({ focus: fit }, 'ftp').terms.some(t => t.k === 'ftp')).toBe(true)
  })
})

describe('D16/D17 vodnik in Moj dogovor brez ponavljanja tedna', () => {
  const f = normalizeFocus({ wish: 'kolo', sports: ['kolo'], aims: ['kondicija'], level: 2, sessions: [{ type: 'kolo', cardio: 'lahko', min: 90 }, { type: 'kolo', cardio: 'lahko', min: 90 }] }, { by: 'pravila' })!
  it('strategija po pravilih ne ponovi tedna; stara shranjena vrstica se ne pokaže', () => {
    const s = ruleStrategy(f, { kcal: 2400, proteinG: 140, deficit: 0 })
    expect(s).not.toContain(weekLine(f))
    expect(s).not.toMatch(/Bloki po 4 tedne/)
    const old = `– ${weekLine(f)}: Kolo 2×. Bloki po 4 tedne: 3 tedne rast, nato lažji teden.\n– Spanec 7–9 h.`
    expect(dealStrategy({ ...f, strategy: old })).toEqual(['Spanec 7–9 h.'])
  })
})

describe('B17/B18 pojasnila trenerja', () => {
  it('»kratkih intervalov« samo, ko teden ima intervale', () => {
    expect(notesFor(['kondicija'], [], [{ type: 'tek', cardio: 'lahko' }, { type: 'tek', cardio: 'lahko' }]).join(' ')).not.toMatch(/interval(?!i pridejo)/)
    expect(notesFor(['kondicija'], [], [{ type: 'tek', cardio: 'lahko' }])[0]).toMatch(/^Kondicijo zdaj gradiš/)
    expect(notesFor(['kondicija'], [], [{ type: 'tek', cardio: 'intervali' }])[0]).toMatch(/kratkih intervalov/)
    expect(fitNotes(['Kondicija raste najhitreje z mešanico lahkega kardia in kratkih intervalov.', 'drugo'], [{ type: 'kolo', cardio: 'lahko' }])).toEqual(['Kondicijo zdaj gradiš z rednim lahkim kardiem — intervali pridejo, ko je to navada.', 'drugo'])
  })
  it('začetnik: intervale zamenja lahek kardio → pojasnilo o kondiciji sledi', () => {
    const f = normalizeFocus({ wish: 'tek', sports: ['tek'], aims: ['kondicija'], level: 1, sessions: [{ type: 'tek', cardio: 'intervali', min: 30 }, { type: 'tek', cardio: 'lahko', min: 30 }], notes: ['Kondicija raste najhitreje z mešanico lahkega kardia in kratkih intervalov.'] }, { by: 'pravila' })!
    const r = coachReview(f, { age: 30 })
    expect(r.focus.sessions.some(s => s.cardio === 'intervali')).toBe(false)
    expect(r.focus.notes.join(' ')).not.toMatch(/kratkih intervalov/)
  })
  it('»40 dobrih minut trikrat« → dejanske minute in dnevi', () => {
    const f = normalizeFocus({ wish: 'fitnes', sports: ['fitnes'], aims: ['misice'], level: 1, sessions: [{ type: 'fitnes', part: 'celo', min: 90 }, { type: 'fitnes', part: 'celo', min: 90 }] }, { by: 'pravila' })!
    const why = coachReview(f, { age: 30 }).why.join(' ')
    expect(why).not.toMatch(/trikrat|40 dobrih/)
    expect(why).toMatch(/Vadbe sem skrajšal na mero začetnika, do 50.min — bolje 2× na teden/)
  })
})

describe('B39 hitra vprašanja trenerju', () => {
  it('brez merilnika in brez dirke: brez vatov, W/kg in dirke', () => {
    const q = quick({ gear: { ...base.gear, powerMeter: false }, event: null }).join(' | ')
    expect(q).not.toMatch(/vati|W\/kg|dirk/)
    expect(q).toMatch(/v kateri coni/)
    const q2 = quick({ gear: { ...base.gear, powerMeter: true }, event: { name: 'Franja', date: '2027-06-13' } }).join(' | ')
    expect(q2).toMatch(/s kakšnimi vati/)
    expect(q2).toMatch(/W\/kg/)
    expect(q2).toMatch(/na dirki \(Franja\)/)
  })
})

describe('B43 obzorje načrta po meri', () => {
  it('tek in hribi ločeno, brez »% obsega«', () => {
    const cx = { recovery: false, volume: 1 } as never
    expect(hzWeekLine({ n: { moc: 0, kolo: 0, tek: 3, hribi: 0 }, cx })).toBe('tek 3×')
    expect(hzWeekLine({ n: { moc: 2, kolo: 0, tek: 1, hribi: 1 }, cx: { recovery: true, volume: 0.7 } as never })).toBe('moč 2× · tek 1× · hribi 1× · lažji teden')
  })
})
