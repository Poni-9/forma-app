import 'fake-indexeddb/auto'
import { describe, it, expect, vi } from 'vitest'

const h = vi.hoisted(() => ({ json: {} as unknown, prompts: [] as string[] }))
vi.mock('../src/domain/ai/client', () => {
  class AiError extends Error { kind: string; constructor(kind: string, m: string) { super(m); this.kind = kind } }
  return {
    AiError,
    askText: async () => '',
    askJson: async (parts: { text?: string }[]) => { h.prompts.push(parts.map(p => p.text || '').join('\n')); return JSON.parse(JSON.stringify(h.json)) },
  }
})

import { dayRecipesAi, type Snapshot } from '../src/domain/ai/actions'
import { todayIso } from '../src/domain/training/load'
import type { Profile } from '../src/domain/types'

const NOW = new Date().toISOString()
const today = todayIso()
const profile: Profile = { sex: 'm', age: 28, weightKg: 80, heightCm: 180, ftp: 250, deficit: 400, goal: 'shujsati', gear: { bikeOutdoor: true, trainer: false, noBike: false }, strength: { on: true, equipment: 'gym' }, strengthDays: 2, aiConsentAt: NOW, onboardingDone: true, createdAt: NOW, updatedAt: NOW }
const s: Snapshot = { profile, activities: [], plan: [], today, extra: '' }
const slots = [
  { key: 'zajtrk', label: 'Zajtrk', when: 'zjutraj', kcal: 600, proteinG: 40, carbsG: 70 },
  { key: 'kosilo', label: 'Kosilo', when: 'opoldne', kcal: 800, proteinG: 48, carbsG: 90 },
  { key: 'malica', label: 'Malica', when: 'popoldne', kcal: 300, proteinG: 28, carbsG: 30 },
  { key: 'vecerja', label: 'Večerja', when: 'zvečer', kcal: 650, proteinG: 42, carbsG: 60 },
]
const meal = (key: string, o: Record<string, unknown> = {}) => ({ key, ime: `Jed ${key}`, sestavine: [{ ime: 'riž', kolicina: '80 g' }, { ime: 'piščanec', kolicina: '150 g' }, { ime: 'jajce', kolicina: '2 kosa' }], koraki: ['Skuhaj.', 'Postrezi.'], kcal: 600, b: 40, oh: 70, m: 15, minut: 20, zakaj: 'Beljakovine.', ...o })

describe('AI recepti dneva: varovalke', () => {
  it('poziv nosi obroke in želje; kalorije ±15 % se pomerijo (količine, vse številke), bolj zgrešeni in beljakovinsko prešibki izpadejo', async () => {
    h.json = { obroki: [
      meal('zajtrk'),                                                   // v redu
      meal('kosilo', { kcal: 1000, b: 60, oh: 110, m: 20 }),            // +25 % → ×0,8
      meal('malica', { kcal: 900, b: 60 }),                             // ×0,33 → izpade
      meal('vecerja', { kcal: 650, b: 20 }),                            // premalo beljakovin → izpade
    ] }
    const r = await dayRecipesAi(s, slots, 'brez laktoze', 'Fitnes — noge', { deficit: true, keepMuscle: true })
    const prompt = h.prompts[h.prompts.length - 1]!
    expect(prompt).toContain('kosilo: Kosilo (opoldne) — 800 kcal, beljakovine 48 g')
    expect(prompt).toContain('brez laktoze')
    expect(Object.keys(r).sort()).toEqual(['kosilo', 'zajtrk'])
    expect(r.zajtrk!.kcal).toBe(600); expect(r.zajtrk!.by).toBe('ai'); expect(r.zajtrk!.ingredients[2]!.text).toBe('jajce 2 kosa')
    expect(r.kosilo!.kcal).toBe(800); expect(r.kosilo!.p).toBe(48)
    expect(r.kosilo!.ingredients.map(i => i.text)).toEqual(['riž 65 g', 'piščanec 120 g', 'jajce 1,5 kosa'])
  })
  it('zdrži čudne oblike: koraki kot besedilo, sestavine kot nizi, prazen odgovor, null', async () => {
    h.json = { obroki: [meal('zajtrk', { koraki: '1. Skuhaj riž. 2. Dodaj piščanca.', sestavine: ['riž 80 g', 'piščanec 150 g'] }), { key: 'kosilo' }, 'x', null] }
    const r = await dayRecipesAi(s, slots, null, null, { deficit: false, keepMuscle: false })
    expect(Object.keys(r)).toEqual(['zajtrk'])
    expect(r.zajtrk!.steps).toEqual(['Skuhaj riž.', 'Dodaj piščanca.'])
    expect(r.zajtrk!.ingredients.map(i => i.text)).toEqual(['riž 80 g', 'piščanec 150 g'])
    h.json = null
    expect(await dayRecipesAi(s, slots, null, null, { deficit: false, keepMuscle: false })).toEqual({})
    h.json = { obroki: 'nič' }
    expect(await dayRecipesAi(s, slots, null, null, { deficit: false, keepMuscle: false })).toEqual({})
  })
})
