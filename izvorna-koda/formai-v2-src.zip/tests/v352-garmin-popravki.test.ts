// v3.52 POPRAVKI-APP — shramba (store + repo) z lažnim strežnikom: V2 (podrobnosti z Garmina pridejo v istem ali
// naslednjem paketu), V6 (since iz `now` odgovora, paginacija z `more`), izklop zdravja/odklop pobrišeta lokalno,
// ?garmin=err jasno obvestilo. Prva dva testa sta iz neodvisnega pregleda (review/app-checks.test.ts.txt).
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
const FB = vi.hoisted(() => ({ user: { uid: 'u1', email: 'a@b.si', name: 'A' } as { uid: string; email: string | null; name: string | null } | null, token: 'tok' as string | null }))
vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => FB.user, signOutNow: async () => undefined,
  idToken: async () => FB.token, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
  timeoutSignal: () => undefined,
}))
import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { getKV, setKV } from '../src/data/db'
import { PROXY } from '../src/config'
import { todayIso, addDays } from '../src/domain/training/load'
const today = todayIso()
const NOW = new Date().toISOString()
const startSec = Math.floor(new Date(today + 'T06:40:00.000Z').getTime() / 1000)
const rec = (o: Record<string, unknown> = {}) => ({
  summaryId: 'a9', activityId: 9, activityName: 'Vožnja', activityType: 'CYCLING', startTimeInSeconds: startSec, startTimeOffsetInSeconds: 7200, durationInSeconds: 5400,
  distanceInMeters: 45000, activeKilocalories: 1100, deviceName: 'Edge 540', averageHeartRateInBeatsPerMinute: 140, details: null, t: 1000, ...o,
})
type Page = Record<string, unknown>
/** Lažen strežnik: aktivnosti po t > since; zdravje in cikel po STRANEH (seznam odgovorov po vrsti klicev). */
const calls: string[] = []
const serve = (items: unknown[], o: { health?: Page[]; cycle?: Page[]; actPages?: Page[]; perms?: string[] } = {}) => vi.stubGlobal('fetch', vi.fn(async (url: string, init?: RequestInit) => {
  calls.push(url.replace(PROXY, '') + (init?.method ? ` ${init.method}` : ''))
  const json = (b: unknown, status = 200) => new Response(JSON.stringify(b), { status, headers: { 'Content-Type': 'application/json' } })
  if (url.includes('/garmin/status')) return json({ connected: true, userId: 'g1', permissions: o.perms ?? ['ACTIVITY_EXPORT'], connectedAt: NOW, lastPushAt: null })
  if (url.includes('/garmin/activities')) {
    if (o.actPages) return json(o.actPages[calls.filter(c => c.startsWith('/garmin/activities')).length - 1] ?? { items: [], now: null })
    // dogovor s strežnikom: now = največji vrnjeni t (ob prazni strani since)
    const since = +new URL(url).searchParams.get('since')!; const it = items.filter(x => ((x as { t: number }).t ?? 0) > since); return json({ items: it, now: it.reduce((m: number, x) => Math.max(m, (x as { t: number }).t ?? 0), since) })
  }
  if (url.includes('/garmin/health')) return json(o.health?.[calls.filter(c => c.startsWith('/garmin/health')).length - 1] ?? { now: null })
  if (url.includes('/garmin/cycle')) return json(o.cycle?.[calls.filter(c => c.startsWith('/garmin/cycle')).length - 1] ?? { mct: [], now: null })
  if (url.includes('/garmin/disconnect')) return json({ ok: true })
  if (url.includes('/garmin/workouts')) return json({ removed: 0, created: 0, updated: 0, skipped: 0, errors: [] })
  return json({ error: 'napaka' }, 500)
}))
const connect = (o: Record<string, unknown> = {}) => store.updateSettings({ garmin: { connected: true, connectedAt: NOW, userId: 'g1', permissions: ['ACTIVITY_EXPORT'], health: false, cycle: false, pushWorkouts: false, pushCourses: false, ...o } })
const sinceOf = (url: string) => +new URL(PROXY + url.split(' ')[0]!).searchParams.get('since')!
beforeEach(async () => { await repo.wipeAll(); localStorage.clear(); calls.length = 0; await store.reloadAll(); await store.signIn(); await store.updateProfile({ ftp: 250 }) })
afterEach(() => { vi.unstubAllGlobals() })

describe('V2: podrobnosti (moč, NP, sled) iz activityDetails', () => {
  it('1 — details pridejo v NASLEDNJEM syncu, brez polilinije (trenažer): moč, max utrip in TSS iz NP se prenesejo', async () => {
    await connect()
    serve([rec({ activityType: 'INDOOR_CYCLING' })])
    await store.syncGarmin(true)
    const before = store.getState().activities.find(a => a.source === 'garmin')!
    expect(before.avgPower).toBeNull(); expect(before.deviceWatts).toBe(false)
    serve([rec({ activityType: 'INDOOR_CYCLING', t: 3000, details: { avgWatts: 190, np: 205, maxHr: 170 } })])
    await store.syncGarmin(true)
    const g = store.getState().activities.filter(a => a.source === 'garmin')
    expect(g).toHaveLength(1)
    expect(g[0]!.id).toBe(before.id)
    expect(g[0]!.avgPower).toBe(190)   // prej: null (repo.addActivities refresh: `changed` samo ob polilinija/hrZoneSec/deviceWatts==null/elapsedMin)
    expect(g[0]!.maxHr).toBe(170); expect(g[0]!.deviceWatts).toBe(true)
    expect(g[0]!.tss).toBe(101)        // 1,5 h × (205/250)² × 100 — prej ocena iz utripa
  })
  it('2 — povzetek (a9) in details (a9-detail) v ISTI strani: details niso zavrženi kot dvojnik', async () => {
    await connect()
    serve([rec(), rec({ summaryId: 'a9-detail', t: 1500, details: { avgWatts: 190, np: 205, maxHr: 170, polyline: 'pl' } })])
    const r = await store.syncGarmin(true)
    expect(r?.added).toBe(1)
    const g = store.getState().activities.filter(a => a.source === 'garmin')
    expect(g).toHaveLength(1)
    expect(g[0]!.avgPower).toBe(190)   // prej: null (repo.addActivities seenExt po garminId obdrži prvega)
    expect(g[0]!.polyline).toBe('pl')
    expect(g[0]!.kcal).toBe(1100); expect(g[0]!.tss).toBe(101)
  })
  it('3 — details PRED povzetkom v isti strani in nato povzetek sam v naslednji: moč ostane, TSS ne pade nazaj v oceno', async () => {
    await connect()
    serve([rec({ summaryId: 'a9-detail', t: 900, details: { avgWatts: 190, np: 205 } }), rec()])
    await store.syncGarmin(true)
    serve([rec({ t: 4000, activityName: 'Vožnja (popravljena)' })])   // manuallyUpdatedActivities brez details
    await store.syncGarmin(true)
    const g = store.getState().activities.filter(a => a.source === 'garmin')
    expect(g).toHaveLength(1); expect(g[0]!.avgPower).toBe(190); expect(g[0]!.tss).toBe(101); expect(g[0]!.name).toBe('Vožnja (popravljena)')
  })
})

describe('V6: since iz `now` odgovora, paginacija z `more`', () => {
  const h = (date: string, t: number, more = false) => ({ dailies: [{ summaryId: 'd' + t, calendarDate: date, durationInSeconds: 86400, restingHeartRateInBeatsPerMinute: 47, t }], now: t, more })
  it('zdravje: more → naslednja stran s since = now; healthSince = now zadnje strani (ne Date.now())', async () => {
    await connect({ health: true, permissions: ['ACTIVITY_EXPORT', 'HEALTH_EXPORT'] })
    serve([], { health: [h(addDays(today, -2), 1100, true), h(addDays(today, -1), 1200, true), h(today, 1300)], perms: ['ACTIVITY_EXPORT', 'HEALTH_EXPORT'] })
    const r = await store.syncGarmin(true)
    expect(r?.error).toBeNull(); expect(r?.healthDays).toBe(3)
    const hc = calls.filter(c => c.startsWith('/garmin/health'))
    expect(hc.map(sinceOf)).toEqual([0, 1100, 1200])
    expect(await getKV('garmin.healthSince')).toBe(1300)
    expect(store.getState().wellness?.map(d => d.date)).toEqual([addDays(today, -2), addDays(today, -1), today])
  })
  it('zdravje brez `now` v odgovoru: since = največji t zapisov, ne ura naprave', async () => {
    await connect({ health: true, permissions: ['ACTIVITY_EXPORT', 'HEALTH_EXPORT'] })
    serve([], { health: [{ dailies: [{ summaryId: 'd', calendarDate: today, durationInSeconds: 86400, restingHeartRateInBeatsPerMinute: 47, t: 777 }] }], perms: ['ACTIVITY_EXPORT', 'HEALTH_EXPORT'] })
    await store.syncGarmin(true)
    expect(await getKV('garmin.healthSince')).toBe(777)
  })
  it('cikel: more → naslednja stran; cycleSince = now zadnje strani; largest 10 strani', async () => {
    await store.updateProfile({ sex: 'z' })
    await connect({ cycle: true, permissions: ['ACTIVITY_EXPORT', 'MCT_EXPORT'] })
    const mct = (date: string, t: number, more: boolean) => ({ mct: [{ summaryId: 'm' + t, calendarDate: date, dayInCycle: 3, cycleLength: 28, periodLength: 5, currentPhaseType: 'MENSTRUAL', t }], now: t, more })
    serve([], { cycle: [mct(addDays(today, -1), 2100, true), mct(today, 2200, false)], perms: ['ACTIVITY_EXPORT', 'MCT_EXPORT'] })
    const r = await store.syncGarmin(true)
    expect(r?.cycleDays).toBe(2)
    expect(calls.filter(c => c.startsWith('/garmin/cycle')).map(sinceOf)).toEqual([0, 2100])
    expect(await getKV('garmin.cycleSince')).toBe(2200)
    // neskončen `more` z istim now se ustavi (since se ne premakne)
    calls.length = 0
    serve([], { cycle: Array.from({ length: 20 }, () => ({ mct: [], now: 2200, more: true })), perms: ['ACTIVITY_EXPORT', 'MCT_EXPORT'] })
    await store.syncGarmin(true)
    expect(calls.filter(c => c.startsWith('/garmin/cycle'))).toHaveLength(1)
  })
  it('aktivnosti: more z manj kot 200 zapisi → naslednja stran; since = now (ne največji t, ne Date.now())', async () => {
    await connect()
    serve([], { actPages: [{ items: [rec({ t: 1000 })], now: 1000, more: true }, { items: [rec({ summaryId: 'b1', activityId: 10, startTimeInSeconds: startSec - 86400, t: 1200 })], now: 1250, more: false }] })
    const r = await store.syncGarmin(true)
    expect(r?.added).toBe(2)
    expect(calls.filter(c => c.startsWith('/garmin/activities')).map(sinceOf)).toEqual([0, 1000])
    expect(await getKV('garmin.since')).toBe(1250)
    // prazna stran brez now ne premakne since
    calls.length = 0
    serve([], { actPages: [{ items: [] }] })
    await store.syncGarmin(true)
    expect(await getKV('garmin.since')).toBe(1250)
  })
})

describe('izklop in odklop pobrišeta lokalno', () => {
  it('setGarminOpt(health, false) pobriše dneve z Garmina iz state.wellness in KV garmin.wellness', async () => {
    await connect({ health: true, permissions: ['ACTIVITY_EXPORT', 'HEALTH_EXPORT'] })
    serve([], { health: [{ dailies: [{ summaryId: 'd', calendarDate: today, durationInSeconds: 86400, restingHeartRateInBeatsPerMinute: 47, t: 5 }], now: 5 }], perms: ['ACTIVITY_EXPORT', 'HEALTH_EXPORT'] })
    await store.syncGarmin(true)
    expect(store.getState().wellness).toHaveLength(1)
    await store.setGarminOpt('health', false)
    expect(store.getState().wellness).toBeNull()
    expect(await getKV('garmin.wellness')).toBeFalsy()
    expect(store.getState().settings.garmin?.health).toBe(false)
  })
  it('disconnectGarmin pobriše KV garmin.workouts in state.garminWorkouts, vožnje ostanejo', async () => {
    await connect()
    serve([rec()])
    await store.syncGarmin(true)
    await setKV('garmin.workouts', { at: NOW, n: 2, created: 2, updated: 0, removed: 0, errors: [], err: null })
    await store.loadGarminWorkoutsInfo()
    expect(store.getState().garminWorkouts?.n).toBe(2)
    expect(await store.disconnectGarmin()).toBe(true)
    expect(await getKV('garmin.workouts')).toBeFalsy(); expect(store.getState().garminWorkouts).toBeNull()
    expect(store.getState().settings.garmin).toBeNull()
    expect(store.getState().activities.filter(a => a.source === 'garmin')).toHaveLength(1)
  })
})

describe('?garmin=err: jasno obvestilo', () => {
  it('finishGarminConnect ob napaki pove, kaj se je zgodilo in kaj narediti; razlog ostane v garminErr; parameter gre iz naslova', async () => {
    history.replaceState(null, '', '/?garmin=err#/uvoz')
    expect(await store.finishGarminConnect()).toBe(true)
    expect(store.getState().garminErr).toBe(store.GARMIN_CONNECT_ERR)
    expect(store.GARMIN_CONNECT_ERR).toMatch(/Garmin Connect ni uspela/); expect(store.GARMIN_CONNECT_ERR).toMatch(/Poveži z Garmin Connect/)
    expect(location.search).toBe('')
    history.replaceState(null, '', '/')
  })
})
