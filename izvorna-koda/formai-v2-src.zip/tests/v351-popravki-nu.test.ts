// v3.51 POPRAVKI51-NU — popravki iz REVIEW-NU (N1–N14) in REVIEW-TR R4 (nogomet dvojno = N3)
import { describe, it, expect } from 'vitest'
import { DISHES, LF_DISHES, exclusionsOf, dayRecipes, recipeOkFor, prefsOn, shoppingGroups, fitDish, foodPrefsFromWish, type Recipe } from '../src/domain/nutrition/recipes'
import { dayMealPlan, qtyText } from '../src/domain/nutrition/dayplan'
import { aiRecipeOk } from '../src/domain/nutrition/daymeals'
import { dailyTarget, targetParts, bmr, tdee, fueling, proteinFoods, eveningSnack, planNetKcal, MAX_DEFICIT, MIN_ABS_M, MIN_ABS_Z } from '../src/domain/nutrition/energy'
import { estimateMeal } from '../src/domain/nutrition/localMeal'
import { parseGpx, movingMinOf } from '../src/domain/import/parsers'
import type { Activity, PlanDay, Profile } from '../src/domain/types'

const now = '2026-10-20T08:00:00.000Z'
const MON = '2026-10-19', FRI = '2026-10-23', SAT = '2026-10-24'
const isFri = (d: string) => new Date(`${d}T12:00:00Z`).getUTCDay() === 5

/* ---------------- N1 — časovni del ne izbriše drugih želj ---------------- */
describe('N1: časovni del v istem stavku', () => {
  it('»ne jem mesa ob petkih in alergija na oreške«: alergija velja vse dni, meso samo ob petkih', () => {
    const t = 'ne jem mesa ob petkih in alergija na oreške'
    expect(prefsOn(t, MON)).toBe('alergija na oreške')
    expect(exclusionsOf(t, MON).contains).toEqual(['oreski'])
    expect(exclusionsOf(t, FRI).contains.sort()).toEqual(['meso', 'oreski'])
    expect(exclusionsOf(t).contains).toEqual(['oreski'])   // brez datuma (pravilo za AI)
  })
  it('vegan, celiakija in alergija ostanejo ob »zvečer«, »včasih«, »po 19h«', () => {
    expect(exclusionsOf('vegan in zvečer ne jem kruha', MON).vegan).toBe(true)
    expect(exclusionsOf('celiakija in zvečer ne jem sadja', MON).contains).toContain('gluten')
    expect(exclusionsOf('alergija na jajca in po 19h ne jem ogljikovih hidratov', MON).contains).toContain('jajca')
    // alergija s časovnim delom velja vse dni
    expect(exclusionsOf('zvečer alergija na jajca', MON).contains).toContain('jajca')
    expect(exclusionsOf('vegan in alergija na oreške ob petkih', MON).contains).toContain('oreski')
  })
  it('oklepaj: »vegetarijanka (ob petkih jem ribe)« — brez mesa vse dni, ribe samo ob petkih', () => {
    const t = 'vegetarijanka (ob petkih jem ribe)'
    expect(exclusionsOf(t, MON).contains.sort()).toEqual(['meso', 'riba'])
    expect(exclusionsOf(t, FRI).contains).toEqual(['meso'])
  })
  it('naštevanje ostane v isti želji: »ne jem mesa in rib ob petkih«, »ob petkih in sobotah«', () => {
    expect(exclusionsOf('ne jem mesa in rib ob petkih', MON).contains).toEqual([])
    expect(exclusionsOf('ne jem mesa in rib ob petkih', FRI).contains.sort()).toEqual(['meso', 'riba'])
    expect(exclusionsOf('ne jem mesa ob petkih in sobotah', SAT).contains).toEqual(['meso'])
    expect(exclusionsOf('ne jem mesa ob petkih in sobotah', MON).contains).toEqual([])
    expect(exclusionsOf('ne jem mesa ob petkih in sobotah', SAT).words).toEqual([])
    // brez časovnega dela nespremenjeno
    expect(prefsOn('brez laktoze, ne jem mesa ob petkih', '2026-10-26')).toBe('brez laktoze')
    expect(prefsOn('alergija na oreške, ne maram brokolija.')).toBe('alergija na oreške, ne maram brokolija')
  })
  it('AI recept »Piščanec z orehi« pri alergiji na oreške v ponedeljek zavrnjen', () => {
    const t = 'ne jem mesa ob petkih in alergija na oreške'
    const ai: Recipe = { dish: 'ai-kosilo', name: 'Piščanec z orehi', kcal: 700, p: 50, c: 70, f: 20, minutes: 20, ingredients: [{ key: 'ai0', qty: 0, text: 'orehi 30 g' }, { key: 'ai1', qty: 0, text: 'piščanec 150 g' }], steps: ['x'], why: '', by: 'ai' }
    expect(recipeOkFor(ai, t, MON)).toBe(false)
    expect(aiRecipeOk(ai, { key: 'kosilo', kcal: 700 } as never, undefined, t, MON)).toBe(false)
  })
  it('želje iz uvoda obdržijo alergijo ob časovnem delu', () => {
    expect(foodPrefsFromWish('Ne jem mesa ob petkih in alergija na oreške.')).toMatch(/alergija na oreške/)
    expect(foodPrefsFromWish('Hočem več moči, brez mesa ob petkih.')).toBeNull()
  })
})

/* ---------------- 14 dni: kombinirane želje s »in« ---------------- */
const ALL = [...DISHES, ...LF_DISHES]
const KEY_RE: Record<string, RegExp> = {
  meso: /^(piscanec|puran|govedina|mleto|sunka|hrenovka|salama)$/, riba: /^(tuna|losos|oslic)$/,
  mleko: /^(jogurt|skuta|mleko|kefir|sir|maslo|smetana)$/, gluten: /^(kruh|belkruh|testenine|testenineb|oves|kuskus|jesprenj|moka|musli|keksi|pecivo|pica|burek|sendvic)$/,
  oreski: /^(oreski|arasid)$/, jajca: /^jajce$/,
}
/** pri glutenu tudi besedilo (sojina omaka brez »brez glutena«) */
const GLU_TXT = /kruh|testenin|kosmi[čc]|kuskus|je[šs]prenj|\bmok[aeo]\b|sojin\p{L}* omak(?!\p{L}* brez glutena)/u
function days14(prefs: string) {
  const out: { date: string; r: Record<string, Recipe> }[] = []
  for (let i = 0; i < 14; i++) {
    const date = `2026-10-${String(12 + i).padStart(2, '0')}`
    const kcal = [2200, 2600, 3000][i % 3]!
    const dp = dayMealPlan({ weightKg: 72, trainTime: i % 2 ? 'popoldne' : 'zjutraj' }, { kcal, proteinG: 140, carbsG: Math.round(kcal * 0.5 / 4) }, i % 3 === 0 ? { kind: 'kolo', durationMin: 120, zone: 'Z2' } as never : null)
    out.push({ date, r: dayRecipes(dp, date, { deficit: i % 2 === 0, keepMuscle: true, training: i % 3 === 0, prefs }) })
  }
  return out
}
function leaks(prefs: string, groups: string[], fridayOnly: string[] = []) {
  const bad: string[] = []
  for (const { date, r } of days14(prefs)) for (const [slot, rec] of Object.entries(r)) {
    const dish = ALL.find(d => d.id === rec.dish)
    for (const g of [...groups, ...(isFri(date) ? fridayOnly : [])]) {
      if (dish?.contains.includes(g as never)) bad.push(`${date} ${slot} ${rec.dish} contains ${g}`)
      for (const i of rec.ingredients) if (KEY_RE[g]!.test(i.key)) bad.push(`${date} ${slot} ${rec.dish} ing ${i.key} (${g})`)
      if (g === 'gluten' && GLU_TXT.test([rec.name, ...rec.ingredients.map(i => i.text), ...rec.steps].join(' ').toLowerCase().replace(/\p{L}+ brez glutena/gu, ''))) bad.push(`${date} ${slot} ${rec.dish} text gluten`)
    }
  }
  return bad
}
describe('N1: 14 dni brez puščanja za kombinirane želje', () => {
  const CASES: [string, string[], string[]][] = [
    ['ne jem mesa ob petkih in alergija na oreške', ['oreski'], ['meso']],
    ['vegan in zvečer ne jem kruha', ['meso', 'riba', 'mleko', 'jajca'], []],
    ['celiakija in zvečer ne jem sadja', ['gluten'], []],
    ['alergija na mleko in ob petkih ne jem mesa', ['mleko'], ['meso']],
    ['vegetarijanka in ob vikendih ne jem kruha', ['meso', 'riba'], []],
    ['alergija na ribe in včasih ne jem jajc', ['riba'], []],
    ['brez glutena in ne jem mesa ob petkih', ['gluten'], ['meso']],
    ['alergija na jajca in po 19h ne jem ogljikovih hidratov', ['jajca'], []],
    ['vegan in alergija na oreške ob petkih', ['meso', 'riba', 'mleko', 'jajca', 'oreski'], []],
    ['pescetarijanec in zvečer brez mlečnih izdelkov', ['meso'], []],
    ['ne prenašam laktoze in alergija na oreške, zvečer ne jem kruha', ['oreski'], []],
    ['alergija na arašide pa ob petkih ne jem mesa', ['oreski'], ['meso']],
    ['celiakija ter vegetarijanec, zvečer ne jem sadja', ['gluten', 'meso', 'riba'], []],
  ]
  for (const [prefs, groups, fri] of CASES) it(prefs, () => { expect(leaks(prefs, groups, fri)).toEqual([]) })
})

/* ---------------- N2 — sojina omaka pri celiakiji ---------------- */
describe('N2: sojina omaka (pšenica) pri celiakiji', () => {
  it('14 dni vegan s celiakijo in vegetarijanka brez glutena: koraki in nakup brez navadne sojine omake', () => {
    for (const prefs of ['vegan, celiakija', 'vegetarijanka, brez glutena']) {
      const recs: Recipe[] = []
      for (let i = 0; i < 14; i++) {
        const date = `2026-10-${String(12 + i).padStart(2, '0')}`
        const dp = dayMealPlan({ weightKg: 62, trainTime: 'popoldne' }, { kcal: 2300 + (i % 3) * 300, proteinG: 120, carbsG: 300 }, null)
        recs.push(...Object.values(dayRecipes(dp, date, { deficit: false, keepMuscle: true, training: true, prefs })))
      }
      const bad = recs.filter(r => /sojin\p{L}* omak(?!\p{L}* brez glutena)/u.test(r.steps.join(' ')))
      expect(bad.map(r => r.dish)).toEqual([])
      const spice = shoppingGroups(recs, prefs).find(g => /Začimbe/.test(g.title))?.items || []
      expect(spice).not.toContain('sojina omaka')
      if (recs.some(r => /tamari/.test(r.steps.join(' ')))) expect(spice).toContain('sojina omaka brez glutena (tamari)')
    }
  })
  it('tofu z rižem: navadna sojina omaka pri veganu, tamari pri celiakiji', () => {
    const d = DISHES.find(x => x.id === 'tofu-riz')!
    expect(fitDish(d, 700, 40, { deficit: false, prefs: 'vegan' }).steps.join(' ')).toMatch(/sojine omake\./)
    expect(fitDish(d, 700, 40, { deficit: false, prefs: 'vegan, celiakija' }).steps.join(' ')).toMatch(/sojine omake brez glutena \(tamari\)/)
    expect(shoppingGroups([{ dish: 'tofu-riz', ingredients: [] }], 'vegan').find(g => /Začimbe/.test(g.title))?.items).toContain('sojina omaka')
  })
  it('AI recept: sojina omaka, griz, rezanci pri celiakiji zavrnjeni; tamari, koruzni zdrob in riževi rezanci gredo', () => {
    const r = (name: string, ...ing: string[]): Recipe => ({ dish: 'ai', name, kcal: 600, p: 40, c: 60, f: 15, minutes: 15, ingredients: ing.map((t, i) => ({ key: `ai${i}`, qty: 0, text: t })), steps: [], why: '', by: 'ai' })
    expect(recipeOkFor(r('Tofu z rižem', 'tofu 150 g', 'sojina omaka 15 ml'), 'celiakija')).toBe(false)
    expect(recipeOkFor(r('Tofu s sojino omako', 'tofu 150 g'), 'brez glutena')).toBe(false)
    expect(recipeOkFor(r('Mlečni griz', 'griz 60 g'), 'celiakija')).toBe(false)
    expect(recipeOkFor(r('Juha z rezanci', 'rezanci 50 g'), 'celiakija')).toBe(false)
    expect(recipeOkFor(r('Tofu z rižem', 'tofu 150 g', 'sojina omaka brez glutena 15 ml'), 'celiakija')).toBe(true)
    expect(recipeOkFor(r('Tofu z rižem', 'tofu 150 g', 'tamari 15 ml'), 'celiakija')).toBe(true)
    expect(recipeOkFor(r('Polenta', 'koruzni zdrob 70 g'), 'celiakija')).toBe(true)
    expect(recipeOkFor(r('Wok', 'riževi rezanci 80 g', 'tofu 150 g'), 'celiakija')).toBe(true)
    // brez celiakije sojina omaka ostane
    expect(recipeOkFor(r('Tofu z rižem', 'sojina omaka 15 ml'), 'vegan')).toBe(true)
  })
})

/* ---------------- N3, N4, N11 (R4) — dan nogometa ---------------- */
const P = (o: Partial<Profile> = {}): Profile => ({ sex: 'm', age: 35, heightCm: 180, weightKg: 75, ftp: 250, deficit: 500, neat: 1.4, gear: { bikeOutdoor: true, trainer: false, noBike: false }, strength: { on: false, equipment: 'none' }, onboardingDone: true, createdAt: now, updatedAt: now, ...o } as Profile)
const D = '2026-10-21'
const act = (o: Partial<Activity>): Activity => ({ id: 'a1', source: 'garmin', sport: 'drugo', date: D, name: 'Soccer', aiEligible: true, geoRetain: true, createdAt: now, updatedAt: now, ...o } as Activity)
const foot = (o: Partial<PlanDay> = {}): PlanDay => ({ id: 'f1', date: D, kind: 'pocitek', title: 'Nogomet', desc: 'Ta dan imaš nogomet', durationMin: 0, zone: null, tssTarget: 0, role: null, source: 'rules', createdAt: now, updatedAt: now, done: null, kcalBurn: 675, ...o } as PlanDay)
describe('N3/R4: nogomet z ure in dan nogometa se ne seštejeta', () => {
  it('ob 20h in po 21h: cilj kot samo izmerjen nogomet, nič »ni zabeleženo«', () => {
    const p = P(), a = act({ durationMin: 90, kcal: 800 })
    for (const hour of [20, 21.5]) {
      const only = dailyTarget(p, [a], [], D, { today: D, hour })!
      const both = dailyTarget(p, [a], [foot()], D, { today: D, hour })!
      expect(both.kcal).toBe(only.kcal)
      expect(both.plannedBurn).toBe(0)
      expect(both.plannedDropped || 0).toBe(0)
      expect(both.plannedWas).toBe(675)
    }
  })
  it('brez zabeležene tekme dan nogometa šteje (neto, z osnovo za 90 min)', () => {
    const p = P()
    const t = dailyTarget(p, [], [foot()], D, { today: D, hour: 9 })!
    const base = dailyTarget(p, [], [], D, { today: D, hour: 9 })!
    expect(t.plannedBurn).toBe(675)
    expect(t.restIn).toBeGreaterThan(100)
    expect(t.kcal - base.kcal).toBe(675 - t.restIn!)
    expect(planNetKcal(foot(), p)).toBe(675 - t.restIn!)
  })
})
describe('N4: bolan ali premor na dan nogometa', () => {
  it('»Bolan sem« in premor »vse« (bolan, potovanje): brez porabe nogometa', () => {
    const sick = P({ sick: { from: D, to: '2026-10-23' } } as Partial<Profile>)
    expect(dailyTarget(sick, [], [foot()], D, { today: D, hour: 9 })!.kcal).toBe(dailyTarget(sick, [], [], D, { today: D, hour: 9 })!.kcal)
    for (const reason of ['bolan', 'potovanje'] as const) {
      const pp = P({ weekPause: { from: D, to: '2026-10-25', mode: 'vse', reason } })
      expect(dailyTarget(pp, [], [foot()], D, { today: D, hour: 9 })!.kcal).toBe(dailyTarget(pp, [], [], D, { today: D, hour: 9 })!.kcal)
    }
  })
  it('premor samo brez kolesa: nogomet ostane', () => {
    const pk = P({ weekPause: { from: D, to: '2026-10-25', mode: 'kolo', reason: 'volja' } })
    expect(dailyTarget(pk, [], [foot()], D, { today: D, hour: 9 })!.plannedBurn).toBe(675)
  })
})
describe('N11: razlaga cilja na dan nogometa', () => {
  it('»trening … zabeležen«, ne »vožnja«', () => {
    const t = dailyTarget(P(), [], [foot()], D, { today: D, hour: 9 })!
    const s = targetParts(t, P())
    expect(s).toMatch(/popravim, ko bo trening zabeležen/)
    expect(s).not.toMatch(/vožnja/)
  })
})
describe('varovalke ostanejo (tudi dan nogometa, bolezen, ročni cilj)', () => {
  it('nikoli pod BMR in 1500/1200, deficit največ 750, mladoletni brez deficita', () => {
    const bad: string[] = []
    for (const sex of ['m', 'z'] as const) for (const age of [15, 17, 18, 30, 60]) for (const w of [45, 60, 90, 130]) for (const h of [150, 175, 195]) for (const def of [0, 300, 750, 2000]) for (const ov of [null, 900, 5000]) for (const pl of [[], [foot()]]) for (const pause of [null, 'bolan', 'sick']) {
      const p = P({ sex, age, weightKg: w, heightCm: h, deficit: def, kcalOverride: ov, goal: def ? 'shujsati' : 'vzdrzevati', ...(pause === 'bolan' ? { weekPause: { from: D, to: D, mode: 'vse', reason: 'bolan' } } : pause === 'sick' ? { sick: { from: D, to: D } } : {}) } as Partial<Profile>)
      const t = dailyTarget(p, [], pl, D, { today: D, hour: 9 })!
      const b = bmr(p)!, base = tdee(p)!
      const training = t.plannedBurn - (t.restIn || 0)
      if (t.kcal < b) bad.push(`<BMR ${sex}${age} ${w}`)
      if (t.kcal < (sex === 'z' ? MIN_ABS_Z : MIN_ABS_M)) bad.push(`<abs ${sex}${age} ${w}`)
      if (t.kcal < base + training - MAX_DEFICIT - 1) bad.push(`>750 ${sex}${age} ${w} ${def} ${ov}`)
      if (age < 18 && t.kcal < base + training - 1) bad.push(`minor deficit ${sex}${age} ${w}`)
      if (pause && t.deficit) bad.push(`bolan deficit ${sex}${age}`)
    }
    expect(bad.slice(0, 10)).toEqual([])
  })
})

/* ---------------- N8, N13 — primeri hrane in ženska oblika ---------------- */
describe('N8: primeri beljakovin in prigrizkov po alergijah in dietah', () => {
  it('alergije, pescetarijanec, vegan z alergijo na arašide', () => {
    expect(proteinFoods('alergija na mleko')).not.toMatch(/skuta|jogurt/)
    expect(proteinFoods('alergija na jajca')).not.toMatch(/jajc/)
    expect(proteinFoods('pescetarijanec')).not.toMatch(/piščan/)
    expect(proteinFoods('ne prenašam laktoze, alergija na jajca')).not.toMatch(/jajc/)
    expect(proteinFoods('vegan, alergija na sojo')).not.toMatch(/tofu|sojin|tempeh/)
    expect(eveningSnack('alergija na mleko')).not.toMatch(/skuta|(?<!sojin )jogurt|kakav/)
    expect(eveningSnack('ne prenašam laktoze, alergija na jajca')).not.toMatch(/jajc/)
    expect(eveningSnack('vegan, alergija na arašide')).not.toMatch(/arašid/)
    expect(eveningSnack('vegan, celiakija')).not.toMatch(/kruh/)
    for (const s of ['alergija na mleko', 'alergija na jajca', 'pescetarijanec', 'vegan, alergija na arašide']) expect(proteinFoods(s).split(', ')).toHaveLength(4)
  })
  it('brez posebnih želja nespremenjeno', () => {
    expect(proteinFoods(null)).toBe('skuta, jajca, jogurt, piščanec')
    expect(proteinFoods('vegan')).toBe('tofu, sojin jogurt, leča, tempeh')
    expect(proteinFoods('vegetarijanec')).toBe('skuta, jajca, jogurt, stročnice')
    expect(proteinFoods('brez laktoze')).toBe('jajca, piščanec, tuna, skuta brez laktoze')
    expect(eveningSnack(null)).toBe('skuta z banano, jogurt, kakav')
    expect(eveningSnack('vegan')).toBe('sojin jogurt z banano, kruh z arašidovim maslom')
  })
  it('moč: obrok pred in beljakovine po po željah', () => {
    const f = fueling({ kind: 'moc', durationMin: 60, zone: null }, { weightKg: 60 }, { prefs: 'vegan' })!
    expect(f.before).not.toMatch(/jogurt s sadjem|jajc/)
    const m = fueling({ kind: 'moc', durationMin: 60, zone: null }, { weightKg: 60 }, { prefs: 'alergija na mleko' })!
    expect(m.after).not.toMatch(/skuta|jogurt/)
    expect(m.before).not.toMatch(/jogurt/)
  })
  it('pred vadbo: celiakija brez kruha in kosmičev, vegan brez medu', () => {
    const z = (prefs?: string) => fueling({ kind: 'moc', durationMin: 60, zone: null }, { weightKg: 60, trainTime: 'zjutraj' } as never, { prefs })!.before
    expect(z()).toMatch(/kruh z medom ali banana/)
    expect(z('celiakija')).not.toMatch(/kruh/)
    expect(z('vegan')).not.toMatch(/medom/)
    const k = (prefs?: string) => fueling({ kind: 'kolo', durationMin: 120, zone: 'Z4', role: 'kljucna' }, { weightKg: 60, trainTime: 'zjutraj' } as never, { prefs })!.before
    expect(k()).toMatch(/kruh z medom ali banana/)
    expect(k('brez glutena')).not.toMatch(/kosmiči|kruh/)
  })
})
describe('N13: »ne treniraj lačna« pri ženskah', () => {
  it('kartica goriva brez moške oblike', () => {
    for (const trainTime of ['zjutraj', 'popoldne'] as const) {
      const f = fueling({ kind: 'kolo', durationMin: 120, zone: 'Z4', role: 'kljucna' }, { weightKg: 60, sex: 'z', trainTime } as never, {})!
      expect(f.before).not.toMatch(/lačen/)
    }
    const m = fueling({ kind: 'kolo', durationMin: 120, zone: 'Z4', role: 'kljucna' }, { weightKg: 75, sex: 'm', trainTime: 'zjutraj' } as never, {})!
    expect(m.before).not.toMatch(/lačna/)
    const z = fueling({ kind: 'kolo', durationMin: 120, zone: 'Z4', role: 'kljucna' }, { weightKg: 60, sex: 'z', trainTime: 'zjutraj' } as never, {})!
    expect(z.before).toMatch(/lačna/)
  })
})

/* ---------------- N6, N7, N9, N10, N12 — ocena obroka brez AI ---------------- */
const item = (d: string, key: string) => estimateMeal(d)?.items.find(i => i.key === key)
describe('ocena obroka brez AI', () => {
  it('N6: kocka čokolade 10 g, tablica 100 g', () => {
    expect(item('2 kocki čokolade', 'cokolada')?.qty).toBe('20 g')
    expect(item('3 kocke čokolade', 'cokolada')?.qty).toBe('30 g')
    expect(item('kocka čokolade', 'cokolada')?.qty).toBe('10 g')
    expect(item('tablica čokolade', 'cokolada')?.qty).toBe('100 g')
    expect(item('pol čokolade', 'cokolada')?.qty).toBe('50 g')
    expect(item('košček čokolade', 'cokolada')?.qty).toBe('10 g')
  })
  it('N7: pleskavica je jed ~200 g, čevapčič 25 g', () => {
    expect(item('1 pleskavica', 'cevapcici')).toMatchObject({ name: 'pleskavica', qty: '200 g' })
    expect(item('2 pleskavici', 'cevapcici')?.qty).toBe('400 g')
    expect(item('10 čevapčičev', 'cevapcici')?.qty).toBe('250 g')
  })
  it('N9: ledeni čaj je sladka pijača, čaj z medom nesladkan čaj', () => {
    expect(estimateMeal('ledeni čaj')!.kcal).toBeGreaterThan(100)
    expect(estimateMeal('ledeni čaj 0,5 l')!.kcal).toBeGreaterThan(150)
    expect(item('čaj z medom', 'caj')).toBeTruthy()
  })
  it('N10: »v četrtek jogurt« je cel jogurt, »četrt pice« četrtina', () => {
    expect(item('v četrtek jogurt', 'jogurt')?.qty).toBe('150 g')
    expect(item('četrt pice', 'pica')?.amount).toBeCloseTo(87.5, 0)
    expect(item('četrtina pice', 'pica')?.amount).toBeCloseTo(87.5, 0)
  })
  it('N12: »jajca na maslu« so jajca in maslo', () => {
    const m = estimateMeal('jajca na maslu')!
    expect(m.items.map(i => i.key).sort()).toEqual(['jajce', 'maslo'])
    expect(m.kcal).toBeGreaterThan(150)
    expect(estimateMeal('jajca na olju')!.items.map(i => i.key).sort()).toEqual(['jajce', 'olje'])
  })
})

/* ---------------- N14 — krompir pod 60 g ---------------- */
describe('N14: krompir pod 60 g brez »½ kosa«', () => {
  it('30 g samo grami, 80 g pol kosa', () => {
    expect(qtyText('krompir', 30)).toBe('krompir 30 g')
    expect(qtyText('krompir', 80)).toMatch(/½ kosa/)
  })
})

/* ---------------- N5 — čas gibanja na strmem vzponu ---------------- */
function gpx(build: (pt: (dLat: number, dEle: number) => void) => void, type = 'hiking'): string {
  let s = `<?xml version="1.0"?><gpx version="1.1" xmlns="http://www.topografix.com/GPX/1/1"><trk><name>Test</name><type>${type}</type><trkseg>`
  let lat = 46.3, ele = 1000, t = Date.UTC(2026, 6, 18, 6, 0, 0)
  const pt = (dLat: number, dEle: number) => { s += `<trkpt lat="${lat.toFixed(6)}" lon="13.830000"><ele>${ele.toFixed(1)}</ele><time>${new Date(t).toISOString()}</time></trkpt>`; lat += dLat / 111_000; ele += dEle; t += 10_000 }
  build(pt)
  return s + '</trkseg></trk></gpx>'
}
describe('N5: strm vzpon ni postanek', () => {
  it('pohod: 2 h po 4 km/h + 1 h strmo (1,2 km/h, +500 m) = 180 min gibanja', async () => {
    const x = gpx(pt => { for (let i = 0; i < 720; i++) pt(11, 0); for (let i = 0; i < 361; i++) pt(3.3, 500 / 360) })
    const r = await parseGpx(new File([x], 'triglav.gpx'))
    expect(r.durationMin).toBeGreaterThanOrEqual(175)
  })
  it('postanek z nemirno višino (±3 m) ostane postanek', async () => {
    let k = 0
    const noise = () => [3, -2, 1, -3, 2, -1][k++ % 6]!
    const x = gpx(pt => { for (let i = 0; i < 360; i++) pt(70, 0); for (let i = 0; i < 180; i++) pt(0.5, noise()); for (let i = 0; i < 361; i++) pt(70, 0) }, 'cycling')
    const r = await parseGpx(new File([x], 'kava.gpx'))
    expect(r.durationMin).toBeLessThanOrEqual(122)
    expect(r.elapsedMin).toBeGreaterThanOrEqual(149)
  })
  it('movingMinOf: brez višine kot prej', () => {
    expect(movingMinOf([{ dt: 600, dm: 5000 }, { dt: 3600, dm: 2 }])).toBe(10)
    expect(movingMinOf([{ dt: 600, dm: 5000 }, { dt: 1800, dm: 100, de: 300 }])).toBe(40)
  })
})
