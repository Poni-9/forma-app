import { describe, it, expect } from 'vitest'
import { normSaid, sameMealBefore } from '../src/domain/nutrition/same'
import type { MealEntry } from '../src/domain/types'

const m = (id: string, date: string, o: Partial<MealEntry> = {}): MealEntry => ({ id, date, time: '08:00', slot: 'zajtrk', name: 'Ovseni kosmiči z jogurtom', grams: null, kcal: 500, proteinG: 20, carbsG: 60, fatG: 12, confidence: 'srednja', source: 'text', thumb: null, createdAt: date + 'T08:00:00.000Z', ...o })

describe('isti obrok kot zadnjič (samo tvoji vpisi)', () => {
  it('poenoti velike črke, ločila, presledke', () => {
    expect(normSaid('  Ovseni kosmiči,  z jogurtom!  ')).toBe('ovseni kosmiči z jogurtom')
  })
  it('najde zadnjega z istim opisom ali imenom (tvoje popravljene številke); gorivo in prekratko ne', () => {
    const meals = [
      m('a', '2026-09-20', { said: 'kosmiči z jogurtom in banano', kcal: 480 }),
      m('b', '2026-09-28', { said: 'kosmiči z jogurtom in banano', kcal: 620, proteinG: 28 }),
      m('c', '2026-09-29', { name: 'Kosmiči z jogurtom in banano', kcal: 999, fuel: { gel: 1 } }),
    ]
    expect(sameMealBefore(meals, 'Kosmiči z jogurtom in banano.')?.id).toBe('b')
    expect(sameMealBefore(meals, 'ovseni kosmiči z jogurtom')?.id).toBe('b')         // po imenu (vsi trije imajo isto ime, gorivo izločeno)
    expect(sameMealBefore(meals, 'riž s piščancem')).toBeNull()
    expect(sameMealBefore(meals, 'jaj')).toBeNull()
  })
})
