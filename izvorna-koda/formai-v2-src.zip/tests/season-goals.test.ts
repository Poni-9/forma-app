import { describe, it, expect } from 'vitest'
import { buildWeek, weekContext, macroWeeks, FRANJA_2027 } from '../src/domain/training/planner'
import { raceTypeOf, raceMinutes, raceDemand, seasonGoals, ftpForWeek } from '../src/domain/training/season'
import type { PlanDay, Profile, Race } from '../src/domain/types'

const now = new Date().toISOString()
const P = (o: Partial<Profile> = {}): Profile => ({
  sex: 'm', age: 21, heightCm: 180, weightKg: 79, restHr: 55, maxHr: 200, lthr: 184, ftp: 240, ftpDate: '2026-09-20',
  gear: { bikeOutdoor: true, trainer: false, noBike: false, powerMeter: true }, hoursPerWeek: 14, baseHours: null,
  strength: { on: false, equipment: 'home', phases: null }, strengthDays: 0, goal: 'dirka', deficit: 0, neat: 1.4,
  event: { ...FRANJA_2027 }, cycleStart: '2026-09-21', onboardingDone: true, createdAt: now, updatedAt: now, ...o,
} as Profile)
const wk = (p: Profile, ws: string) => buildWeek({ profile: p, activities: [], weekStart: ws, notBefore: ws })
const A = (id: string, name: string, date: string, o: Partial<Race> = {}): Race => ({ id, name, date, prio: 'A', distanceKm: null, ...o })
const titles = (w: PlanDay[]) => w.map(d => d.title).join(' | ')

describe('tekma: vrsta, trajanje, napornost', () => {
  it('vrsta iz imena, dolžine in vzpona', () => {
    expect(raceTypeOf({ name: 'Vzpon na Vršič' })).toBe('vzpon')
    expect(raceTypeOf({ name: 'Dirka', distanceKm: 20, elevM: 900 })).toBe('vzpon')
    expect(raceTypeOf({ name: 'Kriterij Ljubljana' })).toBe('sprint')
    expect(raceTypeOf({ name: 'VN Domžale', distanceKm: 80, elevM: 200 })).toBe('sprint')
    expect(raceTypeOf({ name: 'Dirka', distanceKm: 120, elevM: 2400 })).toBe('klanci')
    expect(raceTypeOf({ name: 'Maraton Franja', distanceKm: 156 })).toBe('maraton')
    expect(raceTypeOf({ name: 'Kronometer Vodice' })).toBe('kronometer')
    expect(raceTypeOf({ name: 'VN Pokljuka', type: 'klanci' })).toBe('klanci')        // vpisano ima prednost
  })
  it('trajanje in napornost: dolga, hribovita, višji rang = več zvezdic', () => {
    expect(raceMinutes({ name: 'Franja', distanceKm: 156 })).toBe(310)
    const hard = raceDemand({ name: 'Dirka', distanceKm: 180, elevM: 3000, level: 'visji' })
    const easy = raceDemand({ name: 'Kriterij', distanceKm: 40 })
    expect(hard.stars).toBe(5); expect(hard.hilly).toBe(true); expect(hard.long).toBe(true)
    expect(easy.stars).toBeLessThanOrEqual(2)
    expect(raceMinutes({ name: 'Dirka', distanceKm: 180, elevM: 3000, level: 'visji' })).toBeLessThan(raceMinutes({ name: 'Dirka', distanceKm: 180, elevM: 3000 }))
  })
})

describe('sezona z več cilji', () => {
  const p = P({ races: [A('p', 'VN Pokljuka', '2027-04-18', { distanceKm: 20, elevM: 900 }), A('d', 'Dirka po Sloveniji', '2027-08-14', { distanceKm: 160, elevM: 2600, level: 'visji' })] })
  it('cilji po datumu; časovnica do zadnjega cilja; med cilji nikoli nazaj v osnovo', () => {
    expect(seasonGoals(p).map(g => g.id)).toEqual(['p', 'main', 'd'])
    const m = macroWeeks(p, '2026-09-22')
    expect(m[m.length - 1]!.weekStart).toBe('2027-08-09')
    const after = m.filter(w => w.weekStart > '2027-04-18')
    expect(after.some(w => w.phase === 'osnova')).toBe(false)
    expect(weekContext(p, '2027-04-19').phase).toBe('po')                  // teden po prvem cilju lahko
    expect(weekContext(p, '2027-04-12').phase).toBe('dirka')
    expect(weekContext(p, '2027-04-05').phase).toBe('tapering')
  })
  it('teden po počitku začne blok s 1. tednom, teden pred taperingom ni razbremenilni', () => {
    const m = macroWeeks(p, '2026-09-22').filter(w => w.weekStart > '2027-06-13')
    const firstBlock = m.find(w => w.phase === 'specificno' || w.phase === 'gradnja')!
    expect(firstBlock.blockWeek).toBe(1)
    const beforeTaper = m[m.findIndex(w => w.phase === 'tapering') - 1]!
    expect(beforeTaper.recovery).toBe(false)
  })
  it('specifični blok po vrsti dirke: vzpon, klanci, šprint, kronometer, maraton', () => {
    const vz = wk(p, '2027-03-29')                                             // pred Pokljuko (vzpon)
    expect(titles(vz)).toMatch(/Vzpon|3 dolgi klanci/)
    const kl = P({ event: null, races: [A('k', 'Dirka', '2027-06-20', { distanceKm: 120, elevM: 2400 })] })
    expect(titles(wk(kl, '2027-05-24')) + titles(wk(kl, '2027-05-31'))).toMatch(/Klanci|Over-under|razgibana/)
    const sp = P({ event: null, races: [A('s', 'Kriterij', '2027-06-20', { distanceKm: 50 })] })
    const spw = [wk(sp, '2027-05-17'), wk(sp, '2027-05-24'), wk(sp, '2027-05-31')].map(titles).join(' ')
    expect(spw).toMatch(/Napadi|Šprint iz zavetrja|40\/20/)
    expect(spw).toMatch(/30 s vse, kar gre|30\/15/)
    const tt = P({ event: null, races: [A('t', 'Kronometer', '2027-06-20', { distanceKm: 30 })] })
    expect(titles(wk(tt, '2027-05-24'))).toMatch(/Kronometer v aero/)
    expect(titles(wk(P(), '2027-04-19'))).toMatch(/Kladje/)                     // Franja ostane Franja
  })
  it('dolga vožnja pred dolgo dirko: vsaj ~80 % trajanja dirke (do 6 h 30)', () => {
    const long = P({ hoursPerWeek: 18, event: null, races: [A('l', 'Dolga dirka', '2027-06-20', { distanceKm: 200, elevM: 3000 })] })
    const race = raceMinutes({ name: 'x', distanceKm: 200, elevM: 3000 })
    const sat = wk(long, '2027-05-31').find(d => d.role === 'dolga')!
    expect(sat.durationMin).toBeGreaterThanOrEqual(Math.min(390, Math.round(race * 0.8)))
    expect(sat.durationMin).toBeLessThanOrEqual(390)
  })
  it('cilj v soboto: dirka v soboto, dan prej predaktivacija, nedelja lahko', () => {
    const w = wk(p, '2027-08-09')
    const sat = w.find(d => d.date === '2027-08-14')!
    expect(sat.role).toBe('dirka'); expect(sat.title).toContain('Dirka po Sloveniji')
    expect(w.find(d => d.date === '2027-08-13')!.title).toMatch(/Predaktivacija/)
    expect(w.find(d => d.date === '2027-08-15')!.role).toBe('regen')
  })
})

describe('off-season in lahek začetek', () => {
  const g = P({ age: 19, weightKg: 74.5, ftp: 400, ftpDate: '2026-09-10', hoursPerWeek: 17.5, cycleStart: '2026-09-28', offSeasonWeeks: 2 })
  it('off-season 4 tedne: počitek (vse po želji) → aktivni počitek (hribi, po občutku) → vrnitev (lahke vožnje); nikjer intervalov', () => {
    const o = P({ age: 19, ftp: 400, ftpDate: '2026-09-10', hoursPerWeek: 17.5, cycleStart: '2026-09-28', offSeasonWeeks: 4 })
    const ws = ['2026-09-28', '2026-10-05', '2026-10-12', '2026-10-19']
    const w = ws.map(x => wk(o, x))
    expect(ws.map(x => weekContext(o, x).offStage)).toEqual(['pocitek', 'aktivno', 'aktivno', 'vrnitev'])
    expect(w[0]!.filter(d => d.kind !== 'pocitek').every(d => d.optional)).toBe(true)          // počitek: nič obveznega
    expect(w[1]!.filter(d => d.kind === 'pohod').length).toBe(2)
    expect(w[3]!.filter(d => d.kind === 'kolo').length).toBeGreaterThanOrEqual(3)
    expect(w.flat().some(d => d.role === 'kljucna' || d.role === 'test' || d.kind === 'moc')).toBe(false)
    const h = (x: PlanDay[]) => x.filter(d => !d.optional).reduce((s, d) => s + d.durationMin, 0) / 60
    expect(h(w[1]!)).toBeGreaterThan(5.5); expect(h(w[1]!)).toBeLessThan(8.5)
    expect(h(w[3]!)).toBeGreaterThan(h(w[1]!) * 0.9)
    // po dolgem off-seasonu počasnejša gradnja: prvi lahki teden ~50 % ur
    expect(weekContext(o, '2026-10-26').easy).toBe(1)
    expect(weekContext(o, '2026-10-26').hours).toBeLessThanOrEqual(9)
    expect(ftpForWeek(o, '2026-10-26')).toBe(372)                                              // −7 %
    // dva tedna: prvi počitek, drugi aktivni
    expect(['2026-09-28', '2026-10-05'].map(x => weekContext(g, x).offStage)).toEqual(['pocitek', 'aktivno'])
  })
  it('po off-seasonu: trije lahki tedni od ~60 % ur, nato test; vati iz FTP −3 %, dokler ga ne izmeriš', () => {
    const e1 = weekContext(g, '2026-10-12'), e3 = weekContext(g, '2026-10-26')
    expect(e1.easy).toBe(1); expect(e1.hours).toBeLessThanOrEqual(11)
    expect(e3.easy === 3 || e3.recovery).toBe(true)
    expect(weekContext(g, '2026-11-02').test).toBe(true)
    expect(ftpForWeek(g, '2026-11-02')).toBe(388)
    expect(ftpForWeek({ ...g, ftpDate: '2026-11-05' }, '2026-11-09')).toBe(400)          // nov test po premoru
    const vo = wk(g, '2026-11-02').find(d => d.title.startsWith('VO2max'))!
    expect(vo.target!.lo).toBe(Math.round(388 * 1.08))
    expect(wk(g, '2026-11-02').find(d => d.kind !== 'pocitek' && d.kind !== 'moc')!.why).toMatch(/FTP po off-seasonu ~388 W/)
  })
})

describe('vročina pred poletnim ciljem', () => {
  it('zadnja dva tedna pred junijskim ciljem: lahke Z2 v toplejših oblačilih z navodili po občutku', () => {
    const w = [...wk(P(), '2027-05-24'), ...wk(P(), '2027-05-31')]
    const h = w.filter(d => /· vročina$/.test(d.title))
    expect(h.length).toBeGreaterThanOrEqual(2)
    expect(h.every(d => d.role === 'lahka' && d.durationMin <= 120)).toBe(true)
    expect(h[0]!.desc).toMatch(/brez termometra/)
    expect(h[0]!.desc).toMatch(/glavobol/)
    expect(w.some(d => d.role === 'kljucna' && /vročina/.test(d.title))).toBe(false)     // intervali ostanejo hladni
  })
  it('spomladanski cilj: brez vročinskih treningov', () => {
    const p = P({ event: { name: 'Spomladanska', date: '2027-04-18', distanceKm: 100 } })
    expect([...wk(p, '2027-03-29'), ...wk(p, '2027-04-05')].some(d => /vročina/.test(d.title))).toBe(false)
  })
})

import { ftpPotential, seasonsFactor, hoursFactor } from '../src/domain/training/goal'
describe('koliko napredka je še mogoče: sezone treninga, starost, ure', () => {
  const g = (o: Partial<Profile> = {}) => P({ age: 19, weightKg: 74.5, ftp: 400, hoursPerWeek: 17.5, trainingSeasons: 3, ...o })
  it('pri 5,4 W/kg je prostora malo; prva sezona več, osma manj', () => {
    const three = ftpPotential(g(), '2026-09-24')!, first = ftpPotential(g({ trainingSeasons: 1 }), '2026-09-24')!, many = ftpPotential(g({ trainingSeasons: 9 }), '2026-09-24')!
    expect(three.gainPct).toBeGreaterThanOrEqual(3); expect(three.gainPct).toBeLessThanOrEqual(5)
    expect(first.ideal).toBeGreaterThan(three.ideal); expect(many.ideal).toBeLessThan(three.ideal)
    expect(seasonsFactor(null)).toBe(1)
  })
  it('več ur pomaga manj in manj (ne pa nič): 12 h → 1, 17,5 h ≈ 1,17, 22 h ≈ 1,27, strop 1,35', () => {
    expect(hoursFactor(12)).toBe(1)
    expect(hoursFactor(17.5)).toBeCloseTo(1.17, 2)
    expect(hoursFactor(22)).toBeGreaterThan(hoursFactor(17.5))
    expect(hoursFactor(40)).toBe(1.35)
    expect(ftpPotential(g(), '2026-09-24', 22)!.ideal).toBeGreaterThan(ftpPotential(g(), '2026-09-24', 17.5)!.ideal)
  })
  it('Blaž (3,0 W/kg, 21 let): cilj ostane ~+20 %', () => {
    const b = ftpPotential(P({ goalStart: { date: '2026-09-22', ftp: 240, weightKg: 79 } }), '2026-09-24')!
    expect(b.ideal).toBeGreaterThanOrEqual(286); expect(b.ideal).toBeLessThanOrEqual(294)
  })
})

import { peakGoals, peakOf } from '../src/domain/training/season'
describe('veliko tekem A: vrh forme zdrži 2–3 tedne', () => {
  // glavni cilj 13. 6.; A 30. 5. (2 tedna prej) in A 27. 6. (2 tedna po) sta v isti formi; A 15. 8. je svoj vrh
  const p = P({ races: [A('a1', 'Tekma maj', '2027-05-30'), A('a2', 'Tekma junij', '2027-06-27'), A('a3', 'Tekma avgust', '2027-08-15', { distanceKm: 120, elevM: 2200 })] })
  it('glavni cilj je vedno vrh; bližnji cilji A se vozijo v isti formi', () => {
    expect(peakGoals(p).map(g => g.id)).toEqual(['main', 'a3'])
    expect(peakOf(p, 'a1')?.id).toBe('main'); expect(peakOf(p, 'a3')).toBeNull()
  })
  it('teden bližnjega cilja A ni tapering celega bloka — tekma kot B, načrt gre proti glavnemu vrhu', () => {
    expect(weekContext(p, '2027-05-24').phase).toBe('specificno')                  // teden tekme maj
    const w = wk(p, '2027-05-24')
    expect(w.find(d => d.date === '2027-05-30')!.role).toBe('dirka')
    expect(w.find(d => d.date === '2027-05-29')!.title).toMatch(/Predaktivacija/)
    expect(weekContext(p, '2027-06-07').phase).toBe('dirka')                        // Franja ostane vrh
    // po Franji: teden lahko, tekma junij v isti formi, nato blok proti avgustu
    expect(weekContext(p, '2027-06-14').phase).toBe('po')
    expect(wk(p, '2027-06-21').find(d => d.date === '2027-06-27')!.role).toBe('dirka')
    expect(weekContext(p, '2027-08-09').phase).toBe('dirka')
  })
  it('po zadnjem vrhu še cilj A v isti formi: vzdrževanje (specifično), ne nazaj v osnovo', () => {
    const q = P({ races: [A('z', 'Zadnja', '2027-07-04')] })                      // 3 tedne po Franji
    expect(peakGoals(q).map(g => g.id)).toEqual(['main'])
    expect(weekContext(q, '2027-06-14').phase).toBe('po')
    expect(weekContext(q, '2027-06-21').phase).toBe('specificno')
    expect(wk(q, '2027-06-28').find(d => d.date === '2027-07-04')!.role).toBe('dirka')
  })
})
