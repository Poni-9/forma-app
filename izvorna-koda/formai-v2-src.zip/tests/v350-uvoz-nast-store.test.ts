// v3.50 UVOZ-NAST (stanje): ročni vnos in ista vožnja z ure, izvoz brez GPS sledi, okno samodejnega uvoza,
// namig »Novo: ?« ne čez odprt list.
import 'fake-indexeddb/auto'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'

vi.mock('../src/data/firebase', () => ({
  core: async () => null, onAuth: () => () => undefined, signInGoogle: async () => null, signOutNow: async () => undefined,
  idToken: async () => null, proFromFirestore: async () => false, setAccountDeleteHooks: () => undefined, deleteAccount: async () => ({ ok: true }),
}))

import * as store from '../src/state/store'
import * as repo from '../src/data/repo'
import { setKV, getKV } from '../src/data/db'
import { exportForFile, backupText } from '../src/data/backup'
import { resetIcuPause } from '../src/domain/intervals/client'
import { todayIso, addDays } from '../src/domain/training/load'
import type { Activity } from '../src/domain/types'

const today = todayIso()
const NOW = new Date().toISOString()
// (v3.50 POPRAVKI-NU, N4) ročni vnos je vpisan po vožnji (ura dneva šteje): pol ure po koncu vožnje z ure (07:00–08:32)
const manual = (o: Partial<Activity> = {}): Activity => ({ id: 'man1', source: 'manual', sport: 'kolo', date: today, start: null, name: 'Vožnja', durationMin: 90, distKm: null, aiEligible: true, geoRetain: false, createdAt: today + 'T09:00:00.000Z', updatedAt: NOW, rpe: 7, notes: 'veter', ...o } as Activity)
const icu = (o: Partial<Activity> = {}): Activity => ({ id: 'icu1', source: 'intervals', originHint: 'GARMIN', sport: 'kolo', date: today, start: today + 'T07:00:00.000Z', name: 'Jutranja vožnja', durationMin: 92, distKm: 41.2, avgHr: 141, aiEligible: true, geoRetain: true, ext: { intervalsId: 'i-1' }, createdAt: NOW, updatedAt: NOW, ...o } as Activity)

beforeEach(async () => { await repo.wipeAll(); localStorage.clear(); resetIcuPause(); await store.reloadAll() })
afterEach(() => { vi.unstubAllGlobals() })

describe('F14 vožnja z ure zamenja ročni vnos (brez km)', () => {
  it('»90 min« ročno, nato ista vožnja z ure: en zapis, z ure, občutek in opomba ostaneta', async () => {
    await store.addActivities([manual()])
    const r = await store.addActivities([icu()])
    expect(r).toMatchObject({ added: 0, upgraded: 1 })
    const all = store.getState().activities
    expect(all).toHaveLength(1)
    expect(all[0]).toMatchObject({ id: 'man1', source: 'intervals', distKm: 41.2, durationMin: 92, rpe: 7, notes: 'veter' })
  })
  it('ročni vnos po vožnji z ure: »že vpisana«, nič se ne podvoji', async () => {
    await store.addActivities([icu()])
    const r = await store.addActivities([manual({ id: 'man2', distKm: 40 })])
    expect(r).toMatchObject({ added: 0, upgraded: 0 })
    expect(store.getState().activities.map(a => a.source)).toEqual(['intervals'])
  })
})

describe('G22 + G46 izvoz', () => {
  it('privzeto brez GPS sledi, z izbiro s sledmi; datoteka brez zamikov', async () => {
    await store.addActivities([icu({ polyline: '_p~iF~ps|U_ulLnnqC_mqNvxq`@', source: 'file', ext: {} })])
    const d = await exportForFile()
    expect((d.activities as Activity[])[0]!.polyline).toBeNull()
    expect(backupText(d)).not.toContain('_p~iF')
    expect(backupText(d)).not.toMatch(/\n /)
    const t = await exportForFile({ tracks: true })
    expect((t.activities as Activity[])[0]!.polyline).toBe('_p~iF~ps|U_ulLnnqC_mqNvxq`@')
    // naprava sled obdrži
    expect(store.getState().activities[0]!.polyline).toBe('_p~iF~ps|U_ulLnnqC_mqNvxq`@')
  })
})

describe('F13 okno samodejnega uvoza po premoru', () => {
  it('zadnji uspešen uvoz pred 40 dnevi → vprašamo 43 dni nazaj; po uspehu je zapisan današnji dan', async () => {
    await store.updateSettings({ intervals: { athleteId: 'i1', apiKey: 'k', name: 'x', pushWorkouts: false } })
    await setKV('icu.fullDone', true); await setKV('icu.okDay', addDays(today, -40))
    const urls: string[] = []
    vi.stubGlobal('fetch', async (u: string) => { urls.push(String(u)); return new Response(String(u).includes('/activities') ? '[]' : '{}', { status: 200 }) })
    await store.autoSyncIntervals(true)
    const act = urls.find(u => u.includes('/activities?'))!
    expect(act).toContain(`oldest=${addDays(today, -43)}`)
    expect(await getKV('icu.okDay')).toBe(today)
  })
  it('brez zapisa: 21 dni kot prej', async () => {
    await store.updateSettings({ intervals: { athleteId: 'i1', apiKey: 'k', name: 'x', pushWorkouts: false } })
    await setKV('icu.fullDone', true)
    const urls: string[] = []
    vi.stubGlobal('fetch', async (u: string) => { urls.push(String(u)); return new Response(String(u).includes('/activities') ? '[]' : '{}', { status: 200 }) })
    await store.autoSyncIntervals(true)
    expect(urls.find(u => u.includes('/activities?'))).toContain(`oldest=${addDays(today, -21)}`)
  })
})

describe('F48 namig »Novo: ?« počaka', () => {
  it('odprt list ali Uvoz/Nastavitve: počaka; sicer gre', () => {
    const doc = (sheet: boolean) => ({ querySelector: (s: string) => (sheet && s === '.sheet' ? ({} as Element) : null) }) as Pick<Document, 'querySelector'>
    expect(store.helpHintBlocked(doc(true), '#/danes')).toBe(true)
    expect(store.helpHintBlocked(doc(false), '#/uvoz')).toBe(true)
    expect(store.helpHintBlocked(doc(false), '#/nastavitve?sec=n-cilj')).toBe(true)
    expect(store.helpHintBlocked(doc(false), '#/danes')).toBe(false)
  })
})
