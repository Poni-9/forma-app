import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'
import { fileURLToPath, URL } from 'node:url'
import { readFileSync } from 'node:fs'

// Statični build za GitHub Pages (CNAME formai.si).
// BASE_PATH določa, kam se aplikacija objavi: '/v2/' med preizkušanjem ob živi stari aplikaciji,
// '/' takrat, ko v2 zamenja formai.si. Vse poti (sredstva, manifest, service worker) sledijo temu.
const BASE = process.env.BASE_PATH || '/'

/** Pristajalna stran (landing/*.html, *.css) se vstavi v index.html: statični HTML, hiter prvi izris, berljiv iskalnikom. */
const landing = () => ({
  name: 'formai-landing',
  transformIndexHtml(html: string) {
    const read = (f: string) => readFileSync(fileURLToPath(new URL('./landing/' + f, import.meta.url)), 'utf8')
    const css = read('landing.css').replace(/\/\*[\s\S]*?\*\//g, '').replace(/\s*\n\s*/g, '')
    return html.replace('/*LANDING_CSS*/', () => css).replace('<!--LANDING-->', () => read('landing.html').trim())
  },
})

type Chunk = { type: string; fileName: string; isEntry?: boolean; moduleIds?: string[]; imports?: string[] }
/**
 * Aplikacija je v svojem delu (src/app/start.tsx), ki ga vstop (main.tsx) uvozi šele v načinu aplikacije —
 * pristajalna stran ga zato ne prenese. Da v načinu aplikacije (#/…, nameščena, že uporabljena) ne čaka na
 * dodaten krog (vstop → šele nato aplikacija), index.html ta del in njegove odvisnosti zahteva takoj (modulepreload),
 * vendar samo, ko je skripta pred prvim izrisom izbrala »is-app«.
 */
const appPreload = () => ({
  name: 'formai-app-preload',
  apply: 'build' as const,
  transformIndexHtml: {
    order: 'post' as const,
    handler(html: string, ctx: { bundle?: Record<string, Chunk> }) {
      const b = ctx.bundle
      // del, v katerem je src/app/start.tsx (Rollup mu ne da facadeModuleId, ker iz njega uvažajo tudi zasloni)
      const start = b && Object.values(b).find(c => c.type === 'chunk' && (c.moduleIds || []).some(id => /[\\/]src[\\/]app[\\/]start\.tsx$/.test(id)))
      if (!b || !start) return html
      const files: string[] = []
      const walk = (f: string) => { if (files.includes(f) || !b[f]) return; files.push(f); for (const i of b[f]!.imports || []) walk(i) }
      for (const c of Object.values(b)) if (c.type === 'chunk' && c.isEntry) walk(c.fileName)   // vstop se naloži sam
      const loaded = files.length
      walk(start.fileName)
      files.splice(0, loaded)
      const urls = JSON.stringify(files.map(f => BASE + f))
      const js = `(function(){if(!document.documentElement.classList.contains('is-app'))return;${urls}.forEach(function(h){var l=document.createElement('link');l.rel='modulepreload';l.crossOrigin='';l.href=h;document.head.appendChild(l)})})()`
      return html.replace('</head>', () => `  <script>${js}</script>\n</head>`)
    },
  },
})

/** Veliki, redko rabljeni deli: zemljevid (Leaflet), branje .fit in arhivov (.zip). Ne v predpomnilnik ob namestitvi —
 *  ob prvi uporabi iz omrežja, nato iz predpomnilnika (imena imajo zgoščeno vrednost, zato se ne postarajo). */
const LAZY_LIBS = /\/assets\/(?:leaflet|fit-parser|jszip)[^/]*\.(?:js|css)$/

export default defineConfig({
  base: BASE,
  plugins: [
    react(),
    landing(),
    appPreload(),
    VitePWA({
      // Nova različica se namesti v ozadju in počaka; src/app/sw.ts jo uveljavi ob varnem trenutku
      // (skrita stran ali prehod na drug zaslon — nikoli med vadbo ali tipkanjem). Registracija samo v načinu aplikacije.
      registerType: 'prompt',
      injectRegister: false,
      // ikone manifesta brska brskalnik ob namestitvi — niso del lupine; brez podvojenih vnosov v predpomnilniku
      includeManifestIcons: false,
      manifest: {
        id: BASE,
        name: 'FORMAI',
        short_name: 'FORMAI',
        description: 'Osebni trener: kolo, moč doma, prehrana, teža in forma.',
        lang: 'sl',
        start_url: BASE,
        scope: BASE,
        display: 'standalone',
        orientation: 'portrait',
        background_color: '#07090C',
        theme_color: '#0F1216',
        categories: ['health', 'fitness', 'sports'],
        icons: [
          { src: 'icons/icon-192-v2.png', sizes: '192x192', type: 'image/png' },
          { src: 'icons/icon-512-v2.png', sizes: '512x512', type: 'image/png' },
          { src: 'icons/icon-maskable-512-v2.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
        ],
      },
      workbox: {
        // Aplikacija je lokalno-prva: lupina iz predpomnilnika, podatki v IndexedDB.
        // Lupina = index.html, vsi deli JS/CSS (zasloni, Firebase za prijavo brez omrežja), pisava, ikone SVG, manifest.
        globPatterns: ['**/*.{js,css,html,svg,woff2}', 'icons/apple-touch-icon.png'],
        // og.png je samo za deljenje povezave; Leaflet in razčlenjevalniki gredo v predpomnilnik šele ob uporabi (spodaj)
        globIgnores: ['og.png', 'assets/leaflet*', 'assets/fit-parser*', 'assets/jszip*'],
        navigateFallback: BASE + 'index.html',
        // pravne strani in stara podmapa /v2/ ostanejo prave datoteke, ne aplikacija
        navigateFallbackDenylist: [/^\/(zasebnost|pogoji|privacy|terms|kolesarski-trener)\.html/, /^\/v2\//],
        cleanupOutdatedCaches: true,
        // prva namestitev prevzame odprto stran takoj: deli, ki jih naloži pozneje, že pridejo iz predpomnilnika
        clientsClaim: true,
        runtimeCaching: [
          {
            urlPattern: LAZY_LIBS,
            handler: 'CacheFirst',
            options: { cacheName: 'lazy-libs', expiration: { maxEntries: 12, maxAgeSeconds: 60 * 60 * 24 * 120 } },
          },
          {
            // Ploščice zemljevida — omejeno, da ne napolnimo diska
            urlPattern: /^https:\/\/([a-c]\.)?tile\.openstreetmap\.org\/.*|^https:\/\/[a-d]\.basemaps\.cartocdn\.com\/.*/i,
            handler: 'CacheFirst',
            options: { cacheName: 'tiles', expiration: { maxEntries: 600, maxAgeSeconds: 60 * 60 * 24 * 30 } },
          },
        ],
      },
    }),
  ],
  resolve: {
    alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) },
  },
  build: {
    target: 'es2022',
    sourcemap: false,
    chunkSizeWarningLimit: 900,
    // brez ročnih delov: Rollup sam loči Leaflet, fit-file-parser in JSZip (prej je skupni del vezal zemljevid na razčlenjevalnike)
  },
  test: {
    environment: 'jsdom',
    include: ['tests/**/*.test.{ts,tsx}'],
  },
} as any)
