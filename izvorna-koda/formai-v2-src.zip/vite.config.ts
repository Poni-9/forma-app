import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'
import { fileURLToPath, URL } from 'node:url'

// Statični build za GitHub Pages (CNAME formai.si).
// BASE_PATH določa, kam se aplikacija objavi: '/v2/' med preizkušanjem ob živi stari aplikaciji,
// '/' takrat, ko v2 zamenja formai.si. Vse poti (sredstva, manifest, service worker) sledijo temu.
const BASE = process.env.BASE_PATH || '/'

export default defineConfig({
  base: BASE,
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['icons/*.png', 'icons/*.svg'],
      manifest: {
        id: BASE,
        name: 'FORMAI',
        short_name: 'FORMAI',
        description: 'Osebni trener: kolo, moč doma, prehrana, teža in forma.',
        lang: 'sl',
        start_url: BASE,
        scope: BASE,
        display: 'standalone',
        orientation: 'portrait',
        background_color: '#07090C',
        theme_color: '#0F1216',
        categories: ['health', 'fitness', 'sports'],
        icons: [
          { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png' },
          { src: 'icons/icon-maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
        ],
      },
      workbox: {
        // Aplikacija je lokalno-prva: lupina iz predpomnilnika, podatki v IndexedDB.
        globPatterns: ['**/*.{js,css,html,svg,png,woff2}'],
        navigateFallback: BASE + 'index.html',
        // pravne strani in stara podmapa /v2/ ostanejo prave datoteke, ne aplikacija
        navigateFallbackDenylist: [/^\/(zasebnost|pogoji|privacy|terms|kolesarski-trener)\.html/, /^\/v2\//],
        cleanupOutdatedCaches: true,
        runtimeCaching: [
          {
            // Google Fonts — stylesheet + font datoteke
            urlPattern: /^https:\/\/fonts\.(googleapis|gstatic)\.com\/.*/i,
            handler: 'CacheFirst',
            options: { cacheName: 'fonts', expiration: { maxEntries: 20, maxAgeSeconds: 60 * 60 * 24 * 365 } },
          },
          {
            // Ploščice zemljevida — omejeno, da ne napolnimo diska
            urlPattern: /^https:\/\/([a-c]\.)?tile\.openstreetmap\.org\/.*|^https:\/\/[a-d]\.basemaps\.cartocdn\.com\/.*/i,
            handler: 'CacheFirst',
            options: { cacheName: 'tiles', expiration: { maxEntries: 600, maxAgeSeconds: 60 * 60 * 24 * 30 } },
          },
        ],
      },
    }),
  ],
  resolve: {
    alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) },
  },
  build: {
    target: 'es2022',
    sourcemap: false,
    chunkSizeWarningLimit: 900,
    rollupOptions: {
      output: {
        manualChunks: {
          parsers: ['fit-file-parser', 'jszip'],
        },
      },
    },
  },
  test: {
    environment: 'jsdom',
    include: ['tests/**/*.test.ts'],
  },
} as any)
