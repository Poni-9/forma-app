/** Del kode manjka (nova različica ga je zamenjala) ali ni prišel: enkrat osveži stran, nato pokaži napako. */
const RELOAD_KEY = 'formai.chunkReload'
// (v3.50) skupno za zaslone (App) in liste, ki se prenesejo ob prvem odprtju (OverlayHost, cilj sezone)
export function orReload<T>(p: Promise<T>): Promise<T> {
  return p.catch((err: unknown) => {
    let last = 0
    try { last = Number(sessionStorage.getItem(RELOAD_KEY)) || 0 } catch { /* zasebni način */ }
    if (navigator.onLine === false || Date.now() - last < 60_000) throw err
    try { sessionStorage.setItem(RELOAD_KEY, String(Date.now())) } catch { /* zasebni način */ }
    location.reload()
    return new Promise<T>(() => { /* počakaj na ponovno nalaganje */ })
  })
}
