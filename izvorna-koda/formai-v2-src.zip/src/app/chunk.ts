import { createElement, lazy, type ComponentType } from 'react'
/** Del kode manjka (nova različica ga je zamenjala) ali ni prišel: enkrat osveži stran, nato pokaži napako. */
const RELOAD_KEY = 'formai.chunkReload'
// (v3.50) skupno za zaslone (App) in liste, ki se prenesejo ob prvem odprtju (OverlayHost, cilj sezone)
export function orReload<T>(p: Promise<T>): Promise<T> {
  return p.catch((err: unknown) => {
    let last = 0
    try { last = Number(sessionStorage.getItem(RELOAD_KEY)) || 0 } catch { /* zasebni način */ }
    if (navigator.onLine === false || Date.now() - last < 60_000) throw err
    try { sessionStorage.setItem(RELOAD_KEY, String(Date.now())) } catch { /* zasebni način */ }
    location.reload()
    return new Promise<T>(() => { /* počakaj na ponovno nalaganje */ })
  })
}

/** (v3.51) Napaka prenosa dela kode (ne napaka v kodi): brez povezave ali nova objava. */
export const isChunkError = (e: unknown): boolean =>
  /Failed to fetch dynamically imported module|Importing a module script failed|error loading dynamically imported module|ChunkLoadError|Loading chunk|Unable to preload CSS/i.test(String((e as Error | null)?.message || e))

/** (v3.51) rod poskusov: meja napake ga poveča ob »Poskusi znova«, ob vrnitvi povezave in ob novem obisku zaslona/lista */
let chunkGen = 0
export function retryChunks(): void { chunkGen++ }
/**
 * (v3.51) React.lazy, ki po neuspelem prenosu poskusi znova: lazy si zapomni zavrnjeno obljubo, zato je prej Plan
 * ostal »Ta zaslon se ni naložil« tudi po vrnitvi povezave in »Poskusi znova«, do osvežitve aplikacije.
 * Po neuspehu se nov lazy ustvari šele v novem rodu (retryChunks) — sicer bi React ob napaki izrisoval in prenašal v krogu.
 */
export function retryLazy<P extends object>(load: () => Promise<ComponentType<P>>): ComponentType<P> {
  let failed = false, made = chunkGen
  const make = () => { made = chunkGen; failed = false; return lazy(() => orReload(load()).then(c => ({ default: c }), (e: unknown) => { failed = true; throw e })) }
  let cur = make()
  return function RetryLazy(props: P) {
    if (failed && made !== chunkGen) cur = make()
    return createElement(cur as ComponentType<P>, props)
  }
}
