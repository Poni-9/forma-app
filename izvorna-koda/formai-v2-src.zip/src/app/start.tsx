import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { App, preloadRoute } from './App'
import { ErrorBoundary } from './ErrorBoundary'
import { registerServiceWorker } from './sw'

/** Zagon aplikacije. main.tsx ta modul uvozi šele v načinu aplikacije (pristajalna stran ga ne prenese). */
export function start(): void {
  // zaslon trenutne poti (npr. uvod po kliku na pristajalni strani) se prenaša vzporedno z branjem podatkov
  preloadRoute()
  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <ErrorBoundary>
        <App />
      </ErrorBoundary>
    </StrictMode>,
  )
  registerServiceWorker()
  // Predpomnilniki stare aplikacije (sw.js »formai-…«) niso več v rabi — počisti jih enkrat.
  try { if ('caches' in window) void caches.keys().then(ks => Promise.all(ks.filter(k => k.startsWith('formai-')).map(k => caches.delete(k)))) } catch { /* brez predpomnilnika */ }
}
