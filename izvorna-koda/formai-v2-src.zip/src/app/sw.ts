/**
 * Service worker: registracija (samo v načinu aplikacije) in varne posodobitve.
 *
 * Nova različica se namesti v ozadju in počaka (registerType 'prompt'). Uveljavi se (SKIP_WAITING → nov SW prevzame
 * stran → ponovno nalaganje) samo ob varnem trenutku:
 *  - ko je stran skrita (visibilitychange) ali
 *  - ob prehodu na DRUG zaslon (#/plan → #/prehrana),
 * in nikoli med vadbo (#/vadba), uvodom ali prijavo, med tipkanjem, pri odprtem listu (sheet), pri nedokončanem vnosu
 * in ne tik po dotiku (izbirnik datotek, kamera, okno za prijavo Google stran skrijejo — ponovni zagon bi jih prekinil).
 * Posodobitve preverja vsako uro in ob vrnitvi v aplikacijo.
 */
const HOUR = 60 * 60 * 1000
/** zasloni, kjer bi ponovni zagon izgubil delo: vadba teče, uvod in prijava imata stanje samo v pomnilniku */
const BUSY = new Set(['vadba', 'uvod', 'prijava'])
/** stran, skrita v tem času po dotiku, je najverjetneje odprla izbirnik datotek, kamero ali okno za prijavo */
const INPUT_GRACE_MS = 5000
/** po prehodu med zasloni počakaj, da se prejšnji zaslon pospravi (zapiranje lista, shranjevanje) */
const NAV_SETTLE_MS = 400

/** Ime zaslona iz naslova (#/plan?x=1 → plan; prazno → danes), enako kot router. */
export function routeOf(hash: string): string { return hash.replace(/^#\/?/, '').split('?')[0] || 'danes' }

/** Ali ima fokus polje, v katero se tipka (ali izbirnik datoteke)? */
export function isTyping(el: Element | null | undefined): boolean {
  if (!el) return false
  const tag = el.tagName
  if (tag === 'TEXTAREA' || tag === 'SELECT') return true
  if (tag === 'INPUT') return !/^(button|submit|reset|checkbox|radio|range|color|image)$/i.test((el as HTMLInputElement).type || 'text')
  return (el as HTMLElement).isContentEditable === true
}

export interface Moment {
  /** skrita stran ali prehod med zasloni */
  why: 'hidden' | 'nav'
  /** zaslon zdaj (pri prehodu: cilj) */
  route: string
  /** pri prehodu: zaslon, s katerega uporabnik odhaja */
  from?: string
  active: Element | null
  /** odprt spodnji list (obrazec, potrditev) */
  sheet: boolean
  /** na tem zaslonu je bilo nekaj natipkano (morda še ni shranjeno) */
  dirty: boolean
  /** ms od zadnjega dotika / tipke */
  sinceInput: number
}

/** Ali je zdaj varno zamenjati različico (stran se bo ponovno naložila)? */
export function safeToApply(m: Moment): boolean {
  if (BUSY.has(m.route) || (m.from !== undefined && BUSY.has(m.from))) return false
  if (isTyping(m.active) || m.sheet) return false
  if (m.why === 'nav') return m.from !== undefined && m.from !== m.route
  return !m.dirty && m.sinceInput >= INPUT_GRACE_MS
}

let reg: ServiceWorkerRegistration | null = null
let waiting: ServiceWorker | null = null
/** to okno je poslalo SKIP_WAITING — ob menjavi nadzornika se naloži znova */
let applying = false
/** drugo okno je uveljavilo novo različico: ta stran teče s staro kodo, znova naj se naloži ob varnem trenutku */
let stale = false
let dirty = false
let lastInput = 0
let lastCheck = 0

const now = () => Date.now()

function attempt(why: Moment['why'], from?: string, to?: string): void {
  if (!waiting && !stale) return
  const ok = safeToApply({
    why, from, route: to ?? routeOf(location.hash), active: document.activeElement,
    sheet: !!document.querySelector('.sheet'), dirty, sinceInput: now() - lastInput,
  })
  if (!ok) return
  if (stale) { location.reload(); return }
  applying = true
  waiting!.postMessage({ type: 'SKIP_WAITING' })
}

function found(sw: ServiceWorker): void {
  waiting = sw
  if (document.visibilityState === 'hidden') attempt('hidden')
}

function check(): void {
  if (!reg || now() - lastCheck < 60_000) return
  lastCheck = now()
  reg.update().catch(() => { /* brez omrežja: poskusi ob naslednji priložnosti */ })
}

function watch(r: ServiceWorkerRegistration): void {
  reg = r
  lastCheck = now()
  const sw = navigator.serviceWorker
  let controlled = !!sw.controller
  sw.addEventListener('controllerchange', () => {
    if (!controlled) { controlled = true; return }   // prva namestitev je le prevzela odprto stran (clientsClaim)
    if (applying) { location.reload(); return }
    stale = true
    if (document.visibilityState === 'hidden') attempt('hidden')
  })
  if (r.waiting && controlled) found(r.waiting)
  r.addEventListener('updatefound', () => {
    const inst = r.installing
    inst?.addEventListener('statechange', () => { if (inst.state === 'installed' && sw.controller) found(inst) })
  })
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') attempt('hidden'); else check() })
  addEventListener('hashchange', e => {
    const from = routeOf(new URL((e as HashChangeEvent).oldURL).hash), to = routeOf(location.hash)
    if (from === to) return
    dirty = false
    // malo pozneje: list prejšnjega zaslona se ob prehodu še zapira (popstate pride pred hashchange),
    // zapisi v IndexedDB s prejšnjega zaslona se končajo; če je uporabnik medtem šel naprej, odloči naslednji prehod
    setTimeout(() => { if (routeOf(location.hash) === to) attempt('nav', from, to) }, NAV_SETTLE_MS)
  })
  const mark = () => { lastInput = now() }
  document.addEventListener('pointerdown', mark, { capture: true, passive: true })
  document.addEventListener('keydown', mark, { capture: true, passive: true })
  document.addEventListener('input', e => { if (isTyping(e.target as Element)) dirty = true }, { capture: true, passive: true })
  setInterval(check, HOUR)
}

/** Registrira service worker po nalaganju strani (ne tekmuje z zagonom aplikacije za omrežje). */
export function registerServiceWorker(): void {
  if (!import.meta.env.PROD || !('serviceWorker' in navigator)) return
  const base = import.meta.env.BASE_URL
  const go = () => {
    navigator.serviceWorker.register(base + 'sw.js', { scope: base })
      .then(r => { if (r) watch(r) }, () => { /* brez SW aplikacija dela z omrežja */ })   // nekateri brskalniki/orodja vrnejo prazno
  }
  const later = () => { if ('requestIdleCallback' in window) requestIdleCallback(go, { timeout: 4000 }); else setTimeout(go, 1000) }
  if (document.readyState === 'complete') later(); else addEventListener('load', later, { once: true })
}
