import { Component, type ErrorInfo, type ReactNode } from 'react'
import { noteError } from '@/data/errlog'
import { startFeedback } from '@/ui/HelpSheet'
import { navigate } from './router'
import { parseHash } from './hash'
import { isChunkError, retryChunks } from './chunk'
import { SCREEN_NAME } from '@/ui/screenNames'
import { rem } from '@/ui/rem'

/**
 * Prazen zaslon je najslabši možen odziv na napako. Ta pokaže, kaj se je zgodilo, in izhod.
 * screen (v3.49): meja okoli enega zaslona — zavihki ostanejo, »Poskusi znova« izriše zaslon znova,
 * »Pošlji napako« odpre pripombo (z besedilom napake); tehnično besedilo je pod »Podrobnosti«.
 */
export class ErrorBoundary extends Component<{ children: ReactNode; screen?: boolean }, { err: Error | null; tries: number }> {
  // tries (v3.50): koliko »Poskusi znova« je spet padlo — po drugem še »Osveži aplikacijo« in »Na Danes«
  state = { err: null as Error | null, tries: 0 }
  static getDerivedStateFromError(err: Error) { return { err } }
  // (v3.51) zaslon se ni prenesel (brez povezave): ko se povezava vrne, poskusi znova sam
  private onOnline = () => { if (this.props.screen && this.state.err && isChunkError(this.state.err)) { retryChunks(); this.setState({ err: null }) } }
  componentDidMount() { retryChunks(); window.addEventListener('online', this.onOnline) }
  componentWillUnmount() { window.removeEventListener('online', this.onOnline) }
  componentDidCatch(err: Error, info: ErrorInfo) {
    console.error('FORMAI napaka', err, info.componentStack)
    noteError(`Zaslon: ${String(err?.message || err)}`)
  }
  render() {
    if (!this.state.err) return this.props.children
    const detail = String(this.state.err?.message || this.state.err)
    if (this.props.screen) {
      // (v3.50) ponovljena napaka (pokvarjen zapis): »Poskusi znova« vrne isto — ponudi osvežitev in pot na Danes
      // (v3.51) del kode se ni prenesel: vzrok je povezava (ne »drugi zavihki delajo« — tudi ti morda niso preneseni)
      const chunk = isChunkError(this.state.err)
      const off = chunk && typeof navigator !== 'undefined' && navigator.onLine === false
      const stuck = this.state.tries >= 2 && !off
      const name = parseHash().name
      const onDanes = name === 'danes'
      return (
      <div className="scroll">
        <div className="card" role="alert" style={{ maxWidth: 520, margin: '24px auto' }}>
          <h3>Ta zaslon se ni naložil</h3>
          <p style={{ fontSize: rem(13.5), marginTop: 6 }}>{off
            ? `Ni povezave — ${SCREEN_NAME[name] ?? 'ta zaslon'} še ni na napravi. Ko bo signal, tapni »Poskusi znova«. Tvoji podatki so na napravi.`
            : chunk ? 'Prenos ni uspel — tapni »Poskusi znova«. Tvoji podatki so na napravi.'
            : 'Drugi zavihki delajo — tvoji podatki so na napravi.'}</p>
          {stuck && <p style={{ fontSize: rem(13), marginTop: 6 }}>Napaka se ponavlja. Osveži aplikacijo; če ne pomaga, pošlji napako — zraven gre tehnično besedilo.</p>}
          <div className="row" style={{ gap: 8, marginTop: 12, flexWrap: 'wrap' }}>
            {stuck
              ? <button type="button" className="btn primary sm" onClick={() => location.reload()}>Osveži aplikacijo</button>
              : <button type="button" className="btn primary sm" onClick={() => { retryChunks(); this.setState(s => ({ err: null, tries: s.tries + 1 })) }}>Poskusi znova</button>}
            {stuck && !onDanes && <button type="button" className="btn ghost sm" onClick={() => navigate('danes')}>Na Danes</button>}
            <button type="button" className="btn ghost sm" onClick={() => void startFeedback()}>Pošlji napako</button>
          </div>
          <details style={{ marginTop: 12 }}>
            <summary className="muted" style={{ fontSize: rem(12), cursor: 'pointer' }}>Podrobnosti</summary>
            <pre style={{ fontSize: rem(11), color: 'var(--ink-3)', whiteSpace: 'pre-wrap', marginTop: 6, maxHeight: 140, overflow: 'auto' }}>{detail}</pre>
          </details>
        </div>
      </div>
      )
    }
    return (
      <div className="app" style={{ display: 'grid', placeItems: 'center', padding: 24 }}>
        <div className="card" style={{ maxWidth: 420, width: '100%' }}>
          <div className="brand" style={{ fontWeight: 800, marginBottom: 10 }}>FORM<span>AI</span></div>
          <h3>Nekaj se je podrlo</h3>
          <p style={{ fontSize: rem(13.5), marginTop: 6 }}>Tvoji podatki so na napravi in niso izgubljeni. Osveži stran; če se ponovi, mi pošlji spodnje besedilo.</p>
          <pre style={{ fontSize: rem(11), color: 'var(--ink-3)', whiteSpace: 'pre-wrap', marginTop: 10, maxHeight: 140, overflow: 'auto' }}>{detail}</pre>
          <div className="row" style={{ gap: 8, marginTop: 12 }}>
            <button className="btn primary sm" onClick={() => location.reload()}>Osveži</button>
            <button className="btn ghost sm" onClick={() => { location.hash = '#/danes'; this.setState({ err: null }) }}>Na začetek</button>
            <a className="btn ghost sm" href={`mailto:blaz.gregorc@formai.si?subject=FORMAI%20napaka&body=${encodeURIComponent(String(this.state.err?.stack || this.state.err))}`}>Pošlji</a>
          </div>
        </div>
      </div>
    )
  }
}
