import { Component, type ErrorInfo, type ReactNode } from 'react'

/** Prazen zaslon je najslabši možen odziv na napako. Ta pokaže, kaj se je zgodilo, in izhod. */
export class ErrorBoundary extends Component<{ children: ReactNode }, { err: Error | null }> {
  state = { err: null as Error | null }
  static getDerivedStateFromError(err: Error) { return { err } }
  componentDidCatch(err: Error, info: ErrorInfo) { console.error('FORMAI napaka', err, info.componentStack) }
  render() {
    if (!this.state.err) return this.props.children
    return (
      <div className="app" style={{ display: 'grid', placeItems: 'center', padding: 24 }}>
        <div className="card" style={{ maxWidth: 420, width: '100%' }}>
          <div className="brand" style={{ fontWeight: 800, marginBottom: 10 }}>FORM<span>AI</span></div>
          <h3>Nekaj se je podrlo</h3>
          <p style={{ fontSize: 13.5, marginTop: 6 }}>Tvoji podatki so na napravi in niso izgubljeni. Osveži stran; če se ponovi, mi pošlji spodnje besedilo.</p>
          <pre style={{ fontSize: 11, color: 'var(--ink-3)', whiteSpace: 'pre-wrap', marginTop: 10, maxHeight: 140, overflow: 'auto' }}>{String(this.state.err?.message || this.state.err)}</pre>
          <div className="row" style={{ gap: 8, marginTop: 12 }}>
            <button className="btn primary sm" onClick={() => location.reload()}>Osveži</button>
            <button className="btn ghost sm" onClick={() => { location.hash = '#/danes'; this.setState({ err: null }) }}>Na začetek</button>
            <a className="btn ghost sm" href={`mailto:blaz.gregorc@formai.si?subject=FORMAI%20napaka&body=${encodeURIComponent(String(this.state.err?.stack || this.state.err))}`}>Pošlji</a>
          </div>
        </div>
      </div>
    )
  }
}
