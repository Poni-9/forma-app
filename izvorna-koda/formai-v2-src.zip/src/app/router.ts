import { useEffect, useState } from 'react'

/** Minimalni hash router — deluje na GitHub Pages brez strežniških preusmeritev in v PWA. */
export type Route = { name: string; params: Record<string, string> }

export function parseHash(h: string = location.hash): Route {
  const raw = h.replace(/^#\/?/, '')
  const [path, q] = raw.split('?')
  const params: Record<string, string> = {}
  if (q) for (const kv of q.split('&')) { const [k, v] = kv.split('='); if (k) params[decodeURIComponent(k)] = decodeURIComponent(v || '') }
  return { name: path || 'danes', params }
}

/**
 * Višina zaslona ob prehodu: z navigate() (zavihek, gumb) se nov zaslon odpre na vrhu; z Nazaj/Naprej se vrne
 * na višino, kjer si ga zapustil (brskalnik je ne obnovi zanesljivo, ker je nov zaslon ob obnovi še kratek).
 */
let toTop = false
const saved = new Map<string, number>()
export function navigate(name: string, params?: Record<string, string>) {
  const q = params && Object.keys(params).length ? '?' + Object.entries(params).map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&') : ''
  const h = '#/' + name + q
  if (location.hash === h) return
  saved.set(location.hash, window.scrollY)
  toTop = true
  location.hash = h
}
/** Po prehodu: 'top' (nov zaslon), število (Nazaj na zapuščen zaslon) ali null (nič). Porabi zastavico. */
export function scrollAfterRoute(hash: string = location.hash): 'top' | number | null {
  if (toTop) { toTop = false; return 'top' }
  return saved.get(hash) ?? null
}

export function useRoute(): Route {
  const [r, setR] = useState<Route>(() => parseHash())
  useEffect(() => {
    const on = () => setR(parseHash())
    window.addEventListener('hashchange', on)
    return () => window.removeEventListener('hashchange', on)
  }, [])
  return r
}
