import { startTransition, useEffect, useState } from 'react'
import { parseHash, hashFor, type Route } from './hash'

/** Minimalni hash router — deluje na GitHub Pages brez strežniških preusmeritev in v PWA. */
export { parseHash, hashFor, replaceParams, type Route } from './hash'

/**
 * (v3.50) Znane poti; neznano (#/neznano, star naslov) App zamenja z Danes, velike črke (#/PLAN) s pravim imenom.
 * vec in analitika sta stari poti (App ju preusmeri na Napredek).
 */
const KNOWN = new Set(['danes', 'plan', 'prehrana', 'trener', 'napredek', 'nastavitve', 'uvoz', 'aktivnosti', 'vadba', 'uvod', 'prijava', 'vaje', 'pripombe', 'pilot', 'dogovor', 'claude', 'vec', 'analitika'])
export function normalizeRoute(name: string): string {
  const n = (name || '').toLowerCase()
  return KNOWN.has(n) ? n : 'danes'
}

/**
 * Višina zaslona ob prehodu: z navigate() (zavihek, gumb) se nov zaslon odpre na vrhu; z Nazaj/Naprej se vrne
 * na višino, kjer si ga zapustil (brskalnik je ne obnovi zanesljivo, ker je nov zaslon ob obnovi še kratek).
 */
let toTop = false
const saved = new Map<string, number>()
/** Zamenja naslov brez novega vnosa v zgodovini in sproži hashchange (kot location.hash = …). */
function replaceHash(h: string): void {
  const oldURL = location.href
  try { history.replaceState(history.state, '', h) } catch { location.replace(h); return }
  const ev = typeof HashChangeEvent === 'function' ? new HashChangeEvent('hashchange', { oldURL, newURL: location.href }) : new Event('hashchange')
  window.dispatchEvent(ev)
}
/**
 * (v3.51) Vnos v zgodovini, ki ga je dodal navigate(): pred njim je zaslon FORMAI. Brez oznake (povezava od drugod,
 * osvežitev) history.back() lahko pelje ven iz aplikacije — history.length šteje tudi tuje strani v zavihku.
 */
const FROM_APP = 'formaiFrom'
export const cameFromApp = (): boolean => { const s = history.state; return !!(s && typeof s === 'object' && (s as Record<string, unknown>)[FROM_APP]) }
/** replace (v3.50): brez novega vnosa v zgodovini (preusmeritve, zamenjava zavihka) */
export function navigate(name: string, params?: Record<string, string>, opts: { replace?: boolean } = {}) {
  const h = hashFor(name, params)
  if (location.hash === h) return
  saved.set(location.hash, window.scrollY)
  toTop = true
  if (opts.replace) replaceHash(h)
  else {
    location.hash = h
    try { history.replaceState({ ...(history.state && typeof history.state === 'object' ? history.state : {}), [FROM_APP]: 1 }, '') } catch { /* brez zgodovine */ }
  }
}

/**
 * (v3.50) Zavihki so vrstniki: prvi odhod z Danes doda en vnos, menjava med drugimi zavihki ga zamenja, Danes pa se
 * vrne nanj (history.back) — Nazaj (Android) z zavihka vrne na Danes in nato iz aplikacije (prej čez vse obiskane).
 */
const TAB_MARK = 'formaiTab'
const fromDanes = (): boolean => { const s = history.state; return !!(s && typeof s === 'object' && (s as Record<string, unknown>)[TAB_MARK]) }
export function navTab(name: string, tabs: readonly string[]): void {
  const cur = parseHash().name
  const onTab = tabs.includes(cur) && cur !== 'danes'
  // isti zavihek: na vrh (dan v Prehrani, teden v Planu ostaneta)
  if (cur === name) { window.scrollTo(0, 0); return }
  if (onTab && fromDanes()) {
    if (name === 'danes') { saved.set(location.hash, window.scrollY); toTop = true; history.back(); return }
    const st = history.state
    saved.set(location.hash, window.scrollY); toTop = true
    const oldURL = location.href
    history.replaceState(st, '', hashFor(name))
    window.dispatchEvent(typeof HashChangeEvent === 'function' ? new HashChangeEvent('hashchange', { oldURL, newURL: location.href }) : new Event('hashchange'))
    return
  }
  if (onTab) return navigate(name, undefined, { replace: true })
  navigate(name)
  // vnos, ki je nastal z Danes, si zapomni (Nazaj ga vrne na Danes)
  if (cur === 'danes' && name !== 'danes') { try { history.replaceState({ ...(history.state && typeof history.state === 'object' ? history.state : {}), [TAB_MARK]: 1 }, '') } catch { /* brez zgodovine */ } }
}

/** Po prehodu: 'top' (nov zaslon), število (Nazaj na zapuščen zaslon) ali null (nič). Porabi zastavico. */
export function scrollAfterRoute(hash: string = location.hash): 'top' | number | null {
  if (toTop) { toTop = false; return 'top' }
  return saved.get(hash) ?? null
}

/**
 * (v3.50) Bralnik zaslona: po prehodu fokus na naslov novega zaslona (h1), da bralnik pove, kje si — prej je ostal na
 * zavihku in menjava je bila tiha. Ne, če uporabnik že tipka, je odprt list ali je fokus že v zaslonu.
 * Zaslon, ki se še prenaša, počaka (največ ~1,5 s).
 */
export function focusScreen(doc: Document = document, tries = 90): void {
  const go = (left: number) => {
    const a = doc.activeElement as HTMLElement | null
    if (doc.querySelector('.sheet')) return
    if (a && a !== doc.body && (/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) || a.isContentEditable)) return
    const main = doc.querySelector<HTMLElement>('main.screen')
    const scope: ParentNode = main || doc
    const h = scope.querySelector<HTMLElement>('h1')
    if (main && a && main.contains(a) && a !== h) return
    if (!h) { if (left > 0) requestAnimationFrame(() => go(left - 1)); return }
    if (!h.hasAttribute('tabindex')) h.setAttribute('tabindex', '-1')
    try { h.focus({ preventScroll: true }) } catch { /* */ }
  }
  go(tries)
}

/**
 * (v3.50) Menjava zaslona kot prehod: dolgo izrisovanje novega zaslona se razdeli na kose, tap ne zamrzne.
 * hash in seq: naslov ob prehodu in števec prehodov — višina in fokus po prehodu se ravnata po njiju, ne po
 * location.hash med izrisom (stanje zaslona v naslovu, replaceParams, ni prehod; izris med prehodom ima še staro pot).
 */
export type RouteState = Route & { hash: string; seq: number }
let routeSeq = 0
export function useRoute(): RouteState {
  const [r, setR] = useState<RouteState>(() => ({ ...parseHash(), hash: location.hash, seq: routeSeq }))
  useEffect(() => {
    const on = () => { const next = { ...parseHash(), hash: location.hash, seq: ++routeSeq }; startTransition(() => setR(next)) }
    window.addEventListener('hashchange', on)
    return () => window.removeEventListener('hashchange', on)
  }, [])
  return r
}
