import { useEffect, useState } from 'react'

/** Minimalni hash router — deluje na GitHub Pages brez strežniških preusmeritev in v PWA. */
export type Route = { name: string; params: Record<string, string> }

export function parseHash(h: string = location.hash): Route {
  const raw = h.replace(/^#\/?/, '')
  const [path, q] = raw.split('?')
  const params: Record<string, string> = {}
  if (q) for (const kv of q.split('&')) { const [k, v] = kv.split('='); if (k) params[decodeURIComponent(k)] = decodeURIComponent(v || '') }
  return { name: path || 'danes', params }
}

export function navigate(name: string, params?: Record<string, string>) {
  const q = params && Object.keys(params).length ? '?' + Object.entries(params).map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&') : ''
  location.hash = '#/' + name + q
}

export function useRoute(): Route {
  const [r, setR] = useState<Route>(() => parseHash())
  useEffect(() => {
    const on = () => setR(parseHash())
    window.addEventListener('hashchange', on)
    return () => window.removeEventListener('hashchange', on)
  }, [])
  return r
}
