import { useEffect, useState } from 'react'
import { useRoute, navigate } from './router'
import { Shell } from './Shell'
import { useApp, boot, applyAccent, updateSettings } from '@/state/store'
import { isStandalone } from '@/ui/motion'
import { InstallSheet } from '@/ui/InstallSheet'
import { Onboarding } from '@/screens/Onboarding'
import { Danes } from '@/screens/Danes'
import { Plan } from '@/screens/Plan'
import { Prehrana } from '@/screens/Prehrana'
import { Trener } from '@/screens/Trener'
import { Uvoz } from '@/screens/Uvoz'
import { Aktivnosti } from '@/screens/Aktivnosti'
import { Napredek } from '@/screens/Napredek'
import { Vadba } from '@/screens/Vadba'
import { Nastavitve } from '@/screens/Ostalo'

/**
 * Osebna različica: brez pristajalne strani, cenika, demo načina in pravnih zaslonov.
 * Prvi zagon → nastavitev profila (uvod), potem vedno Danes.
 */
export function App() {
  const route = useRoute()
  const app = useApp()
  const [installOpen, setInstallOpen] = useState(false)

  useEffect(() => { void boot() }, [])
  useEffect(() => { if (app.settings.accentHex) applyAccent(app.settings.accentHex) }, [app.settings.accentHex])

  // Prvi obisk → nastavitev profila; opravljena → danes.
  useEffect(() => {
    if (!app.ready) return
    if (!app.profile.onboardingDone && route.name !== 'uvod') navigate('uvod')
    if (app.profile.onboardingDone && route.name === 'uvod') navigate('danes')
  }, [app.ready, app.profile.onboardingDone, route.name])

  // Namestitveni poziv: enkrat, po nastavitvi, na telefonu, če app ne teče kot nameščena
  useEffect(() => {
    if (!app.ready || !app.profile.onboardingDone || route.name !== 'danes') return
    if (isStandalone() || app.settings.installPromptDismissedAt || window.innerWidth >= 900) return
    const t = setTimeout(() => setInstallOpen(true), 1800)
    return () => clearTimeout(t)
  }, [app.ready, app.profile.onboardingDone, route.name, app.settings.installPromptDismissedAt])

  useEffect(() => { if (app.migration) console.info('FORMAI: prevzeto iz prve različice', app.migration) }, [app.migration])
  // stare poti (Več, Analitika) → Napredek
  useEffect(() => { if (route.name === 'vec' || route.name === 'analitika') navigate('napredek') }, [route.name])

  if (!app.ready) return <div className="app" style={{ display: 'grid', placeItems: 'center' }}><div className="brand boot" style={{ fontWeight: 800, fontSize: 18 }}>FORM<span>AI</span></div></div>

  switch (route.name) {
    case 'uvod': return <div className="app"><div className="page"><Onboarding start={route.params.korak} /></div></div>
    case 'prijava': return <div className="app"><div className="page" key={route.params.korak || ''}><Onboarding start={route.params.korak} /></div></div>
    case 'vadba': return <Vadba />
  }

  const today = app.plan.filter(d => d.date === app.today && d.kind !== 'pocitek' && !d.done && !d.optional).sort((a, b) => (a.kind === 'moc' ? 1 : 0) - (b.kind === 'moc' ? 1 : 0))[0]
  const pill = today && route.name === 'danes' ? { label: 'Začni trening', onClick: () => navigate('vadba', { id: today.id }) } : null

  let page
  switch (route.name) {
    case 'plan': page = <Plan />; break
    case 'prehrana': page = <Prehrana />; break
    case 'trener': page = <Trener />; break
    case 'uvoz': page = <Uvoz />; break
    case 'aktivnosti': page = <Aktivnosti />; break   // samo ročni vnos in seznam — brez zavihka
    case 'napredek': page = <Napredek />; break
    case 'nastavitve': page = <Nastavitve />; break
    default: page = <Danes />
  }
  return (<>
    <Shell pill={pill}>{page}</Shell>
    <InstallSheet open={installOpen} onClose={() => { setInstallOpen(false); void updateSettings({ installPromptDismissedAt: new Date().toISOString() }) }} />
  </>)
}
