import { useEffect, useState } from 'react'
import { useRoute, navigate } from './router'
import { Shell } from './Shell'
import { useApp, boot, applyAccent, updateSettings } from '@/state/store'
import { isStandalone } from '@/ui/motion'
import { InstallSheet } from '@/ui/InstallSheet'
import { Onboarding } from '@/screens/Onboarding'
import { Prijava } from '@/screens/Prijava'
import { isBareRoute, markApp, showApp, showLanding } from './landing'
import { Danes } from '@/screens/Danes'
import { Plan } from '@/screens/Plan'
import { Prehrana } from '@/screens/Prehrana'
import { Trener } from '@/screens/Trener'
import { Uvoz } from '@/screens/Uvoz'
import { Aktivnosti } from '@/screens/Aktivnosti'
import { Napredek } from '@/screens/Napredek'
import { Vadba } from '@/screens/Vadba'
import { Nastavitve } from '@/screens/Ostalo'
import { Pilot } from '@/screens/Pilot'

/**
 * Nov obiskovalec na formai.si vidi pristajalno stran (statični HTML v index.html) → »Sestavi moj načrt« (#/uvod,
 * 3 koraki) ali »Prijava« (#/prijava). Kdor aplikacijo že uporablja (profil, zastavica, nameščena), gre naravnost na Danes.
 */
export function App() {
  const route = useRoute()
  const app = useApp()
  const [installOpen, setInstallOpen] = useState(false)

  useEffect(() => { void boot() }, [])
  useEffect(() => { if (app.settings.accentHex) applyAccent(app.settings.accentHex) }, [app.settings.accentHex])

  // pristajalna stran: samo nov obiskovalec na golem naslovu (formai.si/), ne v nameščeni aplikaciji
  const landing = app.ready && !app.profile.onboardingDone && isBareRoute() && !isStandalone() && !!document.getElementById('land')
  useEffect(() => {
    if (!app.ready) return
    if (app.profile.onboardingDone) markApp()
    else if (landing) showLanding()
    else showApp()
  }, [app.ready, app.profile.onboardingDone, landing])

  // Prvi obisk (brez pristajalne strani) → uvod; opravljen → danes.
  useEffect(() => {
    if (!app.ready || landing) return
    if (!app.profile.onboardingDone && route.name !== 'uvod' && route.name !== 'prijava' && route.name !== 'pilot') navigate('uvod')   // pregled/QR tudi na novi napravi
    if (app.profile.onboardingDone && route.name === 'uvod') navigate('danes')
  }, [app.ready, app.profile.onboardingDone, route.name, landing])

  // Namestitveni poziv: enkrat, po nastavitvi, na telefonu, če app ne teče kot nameščena
  useEffect(() => {
    if (!app.ready || !app.profile.onboardingDone || route.name !== 'danes') return
    if (isStandalone() || app.settings.installPromptDismissedAt || window.innerWidth >= 900) return
    // ne na prvi dan in ne med vodnikom: novi uporabnik ima namestitev v »Prvih korakih«
    if (app.settings.guideSeen === false || (app.profile.goalStart?.date ?? app.profile.createdAt?.slice(0, 10) ?? '') >= app.today) return
    const t = setTimeout(() => setInstallOpen(true), 1800)
    return () => clearTimeout(t)
  }, [app.ready, app.profile.onboardingDone, route.name, app.settings.installPromptDismissedAt, app.settings.guideSeen, app.profile.goalStart?.date, app.profile.createdAt, app.today])

  useEffect(() => { if (app.migration) console.info('FORMAI: prevzeto iz prve različice', app.migration) }, [app.migration])
  // stare poti (Več, Analitika) → Napredek
  useEffect(() => { if (route.name === 'vec' || route.name === 'analitika') navigate('napredek') }, [route.name])

  if (!app.ready) return <div className="app" style={{ display: 'grid', placeItems: 'center' }}><div className="brand boot" style={{ fontWeight: 800, fontSize: 18 }}>FORM<span>AI</span></div></div>

  if (landing) return null
  switch (route.name) {
    case 'uvod': return <div className="app"><div className="page"><Onboarding start={route.params.korak} /></div></div>
    case 'prijava': return <div className="app"><div className="page"><Prijava /></div></div>
    case 'vadba': return <Vadba />
  }

  const today = app.plan.filter(d => d.date === app.today && d.kind !== 'pocitek' && d.kind !== 'pohod' && !d.done && !d.optional).sort((a, b) => (a.kind === 'moc' ? 1 : 0) - (b.kind === 'moc' ? 1 : 0))[0]
  const pill = today && route.name === 'danes' ? { label: 'Začni trening', onClick: () => navigate('vadba', { id: today.id }) } : null

  let page
  switch (route.name) {
    case 'plan': page = <Plan />; break
    case 'prehrana': page = <Prehrana />; break
    case 'trener': page = <Trener />; break
    case 'uvoz': page = <Uvoz />; break
    case 'aktivnosti': page = <Aktivnosti />; break   // samo ročni vnos in seznam — brez zavihka
    case 'napredek': page = <Napredek />; break
    case 'nastavitve': page = <Nastavitve />; break
    case 'pilot': page = <Pilot />; break   // pregled testnega programa (skrbnik)
    default: page = <Danes />
  }
  return (<>
    <Shell pill={pill}>{page}</Shell>
    <InstallSheet open={installOpen} onClose={() => { setInstallOpen(false); void updateSettings({ installPromptDismissedAt: new Date().toISOString() }) }} />
  </>)
}
