import { lazy, Suspense, useEffect, useState, type ComponentType } from 'react'
import { useRoute, navigate, parseHash } from './router'
import { Shell } from './Shell'
import { useApp, boot, applyAccent, updateSettings } from '@/state/store'
import { isStandalone } from '@/ui/motion'
import { InstallSheet } from '@/ui/InstallSheet'
import { AccountClash } from '@/ui/AccountClash'
import { UndoHost } from '@/ui/Confirm'
import { isBareRoute, markApp, showApp, showLanding } from './landing'
import { Danes } from '@/screens/Danes'

/* ---------- zasloni: Danes je privzeti in pride takoj, ostali ob prvi rabi ---------- */

/** Del kode manjka (nova različica ga je zamenjala) ali ni prišel: enkrat osveži stran, nato pokaži napako. */
const RELOAD_KEY = 'formai.chunkReload'
function orReload<T>(p: Promise<T>): Promise<T> {
  return p.catch((err: unknown) => {
    let last = 0
    try { last = Number(sessionStorage.getItem(RELOAD_KEY)) || 0 } catch { /* zasebni način */ }
    if (navigator.onLine === false || Date.now() - last < 60_000) throw err
    try { sessionStorage.setItem(RELOAD_KEY, String(Date.now())) } catch { /* zasebni način */ }
    location.reload()
    return new Promise<T>(() => { /* počakaj na ponovno nalaganje */ })
  })
}

type Lazy<P> = ComponentType<P> & { preload: () => Promise<unknown> }
/** Zaslon z React.lazy. Ko je že prenesen (vnaprej ob mirovanju), se izriše takoj, brez vmesnega nadomestka. */
function screen<P extends object>(load: () => Promise<ComponentType<P>>): Lazy<P> {
  let done: ComponentType<P> | null = null
  let pending: Promise<ComponentType<P>> | null = null
  const get = () => (pending ??= load().then(c => (done = c), (e: unknown) => { pending = null; throw e }))
  const L = lazy(() => orReload(get()).then(c => ({ default: c }))) as unknown as ComponentType<P>
  function Screen(props: P) {
    const [Ready] = useState(() => done)   // odločitev ob vstopu na zaslon — ista komponenta ves čas obiska
    return Ready ? <Ready {...props} /> : <L {...props} />
  }
  return Object.assign(Screen, { preload: () => get().catch(() => null) })
}

const Onboarding = screen(() => import('@/screens/Onboarding').then(m => m.Onboarding))
const Prijava = screen(() => import('@/screens/Prijava').then(m => m.Prijava))
const Vadba = screen(() => import('@/screens/Vadba').then(m => m.Vadba))
const Plan = screen(() => import('@/screens/Plan').then(m => m.Plan))
const Prehrana = screen(() => import('@/screens/Prehrana').then(m => m.Prehrana))
const Trener = screen(() => import('@/screens/Trener').then(m => m.Trener))
const Napredek = screen(() => import('@/screens/Napredek').then(m => m.Napredek))
const Nastavitve = screen(() => import('@/screens/Ostalo').then(m => m.Nastavitve))
const Uvoz = screen(() => import('@/screens/Uvoz').then(m => m.Uvoz))
const Aktivnosti = screen(() => import('@/screens/Aktivnosti').then(m => m.Aktivnosti))
const Pilot = screen(() => import('@/screens/Pilot').then(m => m.Pilot))

const BY_ROUTE: Record<string, { preload: () => Promise<unknown> }> = {
  uvod: Onboarding, prijava: Prijava, vadba: Vadba, plan: Plan, prehrana: Prehrana, trener: Trener,
  napredek: Napredek, nastavitve: Nastavitve, uvoz: Uvoz, aktivnosti: Aktivnosti, pilot: Pilot,
}
/** Zaslon poti začne prenašati takoj ob zagonu — vzporedno z branjem podatkov iz IndexedDB. */
export function preloadRoute(name: string = parseHash().name): void { void BY_ROUTE[name]?.preload() }
/** Po zagonu, ko brskalnik miruje, po vrsti: zavihki in vadba, da je vsak preklop takojšen. */
const WARM = [Plan, Prehrana, Trener, Napredek, Vadba, Nastavitve, Uvoz, Aktivnosti]
function idle(fn: () => void): number {
  if (typeof window.requestIdleCallback === 'function') return window.requestIdleCallback(fn, { timeout: 3000 })
  return window.setTimeout(fn, 300)   // Safari
}
function unidle(h: number): void {
  if (typeof window.cancelIdleCallback === 'function') window.cancelIdleCallback(h)
  else window.clearTimeout(h)
}

/** Enak videz kot zagonski zaslon v index.html in med branjem podatkov — brez skoka. */
function Splash() {
  return <div className="app" style={{ display: 'grid', placeItems: 'center' }}><div className="brand boot" style={{ fontWeight: 800, fontSize: 18 }}>FORM<span>AI</span></div></div>
}

/** Obvestila za vse poti (tudi uvod, prijava, vadba). Stalno živo območje, da ga bralnik zaslona prebere. */
function Toasts() {
  const t = useApp().toast
  return (
    <div className="toast-host" role="status" aria-live="polite">
      {t && <div key={t.id} className={`toast ${t.kind === 'err' ? 'err' : t.kind === 'ok' ? 'ok' : ''}`}>{t.msg}</div>}
    </div>
  )
}

/**
 * Nov obiskovalec na formai.si vidi pristajalno stran (statični HTML v index.html) → »Sestavi moj načrt« (#/uvod,
 * 3 koraki) ali »Prijava« (#/prijava). Kdor aplikacijo že uporablja (profil, zastavica, nameščena), gre naravnost na Danes.
 */
export function App() {
  const route = useRoute()
  const app = useApp()
  const [installOpen, setInstallOpen] = useState(false)

  useEffect(() => { void boot() }, [])
  useEffect(() => { if (app.settings.accentHex) applyAccent(app.settings.accentHex) }, [app.settings.accentHex])

  // pristajalna stran: samo nov obiskovalec na golem naslovu (formai.si/), ne v nameščeni aplikaciji
  const landing = app.ready && !app.profile.onboardingDone && isBareRoute() && !isStandalone() && !!document.getElementById('land')
  useEffect(() => {
    if (!app.ready) return
    if (app.profile.onboardingDone) markApp()
    else if (landing) showLanding()
    else showApp()
  }, [app.ready, app.profile.onboardingDone, landing])

  // Prvi obisk (brez pristajalne strani) → uvod; opravljen → danes.
  useEffect(() => {
    if (!app.ready || landing) return
    if (!app.profile.onboardingDone && route.name !== 'uvod' && route.name !== 'prijava' && route.name !== 'pilot') navigate('uvod')   // pregled/QR tudi na novi napravi
    if (app.profile.onboardingDone && route.name === 'uvod') navigate('danes')
  }, [app.ready, app.profile.onboardingDone, route.name, landing])

  // Namestitveni poziv: enkrat, po nastavitvi, na telefonu, če app ne teče kot nameščena
  useEffect(() => {
    if (!app.ready || !app.profile.onboardingDone || route.name !== 'danes') return
    if (isStandalone() || app.settings.installPromptDismissedAt || window.innerWidth >= 900) return
    // ne na prvi dan in ne med vodnikom: novi uporabnik ima namestitev v »Prvih korakih«
    if (app.settings.guideSeen === false || (app.profile.goalStart?.date ?? app.profile.createdAt?.slice(0, 10) ?? '') >= app.today) return
    const t = setTimeout(() => setInstallOpen(true), 1800)
    return () => clearTimeout(t)
  }, [app.ready, app.profile.onboardingDone, route.name, app.settings.installPromptDismissedAt, app.settings.guideSeen, app.profile.goalStart?.date, app.profile.createdAt, app.today])

  // zasloni vnaprej, ko uporabnik aplikacijo že uporablja (med uvodom ne — telefon ima takrat dovolj dela)
  useEffect(() => {
    if (!app.ready || !app.profile.onboardingDone) return
    let i = 0, h = 0, dead = false
    const next = () => { if (dead || i >= WARM.length) return; void WARM[i++]!.preload().then(() => { if (!dead) h = idle(next) }) }
    h = idle(next)
    return () => { dead = true; unidle(h) }
  }, [app.ready, app.profile.onboardingDone])

  useEffect(() => { if (app.migration) console.info('FORMAI: prevzeto iz prve različice', app.migration) }, [app.migration])
  // stare poti (Več, Analitika) → Napredek
  useEffect(() => { if (route.name === 'vec' || route.name === 'analitika') navigate('napredek') }, [route.name])

  if (landing) return null
  return (<>
    {app.ready ? <Screens route={route} installOpen={installOpen} closeInstall={() => { setInstallOpen(false); void updateSettings({ installPromptDismissedAt: new Date().toISOString() }) }} /> : <Splash />}
    <Toasts />
    <UndoHost />
    <AccountClash />
  </>)
}

function Screens({ route, installOpen, closeInstall }: { route: ReturnType<typeof useRoute>; installOpen: boolean; closeInstall: () => void }) {
  const app = useApp()
  switch (route.name) {
    case 'uvod': return <Suspense fallback={<Splash />}><div className="app"><div className="page"><Onboarding start={route.params.korak} /></div></div></Suspense>
    case 'prijava': return <Suspense fallback={<Splash />}><div className="app"><div className="page"><Prijava /></div></div></Suspense>
    case 'vadba': return <Suspense fallback={<Splash />}><Vadba /></Suspense>
  }

  const today = app.plan.filter(d => d.date === app.today && d.kind !== 'pocitek' && d.kind !== 'pohod' && !d.done && !d.optional).sort((a, b) => (a.kind === 'moc' ? 1 : 0) - (b.kind === 'moc' ? 1 : 0))[0]
  const pill = today && route.name === 'danes' ? { label: 'Začni trening', onClick: () => navigate('vadba', { id: today.id }) } : null

  let page
  switch (route.name) {
    case 'plan': page = <Plan />; break
    case 'prehrana': page = <Prehrana />; break
    case 'trener': page = <Trener />; break
    case 'uvoz': page = <Uvoz />; break
    case 'aktivnosti': page = <Aktivnosti />; break   // samo ročni vnos in seznam — brez zavihka
    case 'napredek': page = <Napredek />; break
    case 'nastavitve': page = <Nastavitve />; break
    case 'pilot': page = <Pilot />; break   // pregled testnega programa (skrbnik)
    default: page = <Danes />
  }
  return (<>
    {/* zavihki ostanejo na mestu, dokler se zaslon prenaša (samo prvič in samo, če še ni bil prenesen vnaprej) */}
    <Shell pill={pill}><Suspense fallback={<div className="scroll" aria-busy="true" />}>{page}</Suspense></Shell>
    <InstallSheet open={installOpen} onClose={closeInstall} />
  </>)
}
