import { Suspense, useEffect, useLayoutEffect, useState, type ComponentType } from 'react'
import { useRoute, navigate, parseHash, scrollAfterRoute, normalizeRoute, focusScreen } from './router'
import { Shell } from './Shell'
import { useApp, boot, applyAccent, updateSettings, toast, warmAuth } from '@/state/store'
import { Toasts } from '@/ui/Toasts'
import { onUpdateReady, applyUpdate, takeUpdatedNotice, setAppVersion } from './sw'
import { APP_VERSION } from '@/config'
import { isStandalone } from '@/ui/motion'
import { InstallSheet } from '@/ui/InstallSheetLazy'
import { AccountClash } from '@/ui/AccountClash'
import { UndoHost } from '@/ui/Confirm'
import { OverlayHost, preloadFeedback, preloadPhotoTraining } from '@/ui/OverlayHost'
import { retryLazy } from './chunk'
import { runningDayId, watchRunCopy, pillDay, pillLabel } from '@/ui/runState'
import { pageTitle } from '@/ui/screenNames'
import { isBareRoute, markApp, showApp, showLanding } from './landing'
import { Danes } from '@/screens/Danes'
import { rem } from '@/ui/rem'

/* ---------- zasloni: Danes je privzeti in pride takoj, ostali ob prvi rabi ---------- */

/* del kode manjka ali ni prišel: orReload (src/app/chunk.ts) enkrat osveži stran, nato pokaže napako */

type Lazy<P> = ComponentType<P> & { preload: () => Promise<unknown> }
/** Zaslon z React.lazy. Ko je že prenesen (vnaprej ob mirovanju), se izriše takoj, brez vmesnega nadomestka. */
function screen<P extends object>(load: () => Promise<ComponentType<P>>): Lazy<P> {
  let done: ComponentType<P> | null = null
  let pending: Promise<ComponentType<P>> | null = null
  const get = () => (pending ??= load().then(c => (done = c), (e: unknown) => { pending = null; throw e }))
  // (v3.51) po neuspelem prenosu (brez povezave) naslednji izris prenaša znova — prej do osvežitve aplikacije
  const L = retryLazy(get)
  function Screen(props: P) {
    const [Ready] = useState(() => done)   // odločitev ob vstopu na zaslon — ista komponenta ves čas obiska
    return Ready ? <Ready {...props} /> : <L {...props} />
  }
  return Object.assign(Screen, { preload: () => get().catch(() => null) })
}

const Onboarding = screen(() => import('@/screens/Onboarding').then(m => m.Onboarding))
const Sestavi = screen(() => import('@/screens/Sestavi').then(m => m.Sestavi))
const Prijava = screen(() => import('@/screens/Prijava').then(m => m.Prijava))
const Vadba = screen(() => import('@/screens/Vadba').then(m => m.Vadba))
const Plan = screen(() => import('@/screens/Plan').then(m => m.Plan))
const Prehrana = screen(() => import('@/screens/Prehrana').then(m => m.Prehrana))
const Trener = screen(() => import('@/screens/Trener').then(m => m.Trener))
const Napredek = screen(() => import('@/screens/Napredek').then(m => m.Napredek))
const Nastavitve = screen(() => import('@/screens/Ostalo').then(m => m.Nastavitve))
const Uvoz = screen(() => import('@/screens/Uvoz').then(m => m.Uvoz))
const Aktivnosti = screen(() => import('@/screens/Aktivnosti').then(m => m.Aktivnosti))
const Pilot = screen(() => import('@/screens/Pilot').then(m => m.Pilot))
const Pripombe = screen(() => import('@/screens/Pripombe').then(m => m.Pripombe))
const ClaudePovabilo = screen(() => import('@/screens/ClaudePovabilo').then(m => m.ClaudePovabilo))
const Vaje = screen(() => import('@/screens/Vaje').then(m => m.Vaje))

const BY_ROUTE: Record<string, { preload: () => Promise<unknown> }> = {
  uvod: Sestavi, dogovor: Sestavi, prijava: Prijava, vadba: Vadba, plan: Plan, prehrana: Prehrana, trener: Trener,
  napredek: Napredek, nastavitve: Nastavitve, uvoz: Uvoz, aktivnosti: Aktivnosti, pilot: Pilot, pripombe: Pripombe, claude: ClaudePovabilo,
}
/** Zaslon poti začne prenašati takoj ob zagonu — vzporedno z branjem podatkov iz IndexedDB. */
export function preloadRoute(name: string = parseHash().name): void { void BY_ROUTE[name]?.preload() }
/** Po zagonu, ko brskalnik miruje, po vrsti: zavihki in vadba, da je vsak preklop takojšen. */
// (v3.50) list Pripomba prvi (gumb je na vsakem zaslonu; majhen)
// (v3.51) Trening s slike takoj za njim — gumb je na glavni kartici Danes (prej zadnji, prvi tap 0,6 s brez odziva)
const WARM = [{ preload: preloadFeedback }, { preload: preloadPhotoTraining }, Plan, Prehrana, Trener, Napredek, Vadba, Nastavitve, Uvoz, Aktivnosti]
function idle(fn: () => void): number {
  if (typeof window.requestIdleCallback === 'function') return window.requestIdleCallback(fn, { timeout: 3000 })
  return window.setTimeout(fn, 300)   // Safari
}
function unidle(h: number): void {
  if (typeof window.cancelIdleCallback === 'function') window.cancelIdleCallback(h)
  else window.clearTimeout(h)
}

/** Enak videz kot zagonski zaslon v index.html in med branjem podatkov — brez skoka. */
function Splash() {
  return <div className="app" style={{ display: 'grid', placeItems: 'center' }}><div className="brand boot" style={{ fontWeight: 800, fontSize: rem(18) }}>FORM<span>AI</span></div></div>
}

/** (v3.49) Brskalnik ne dovoli shrambe (zasebni način, blokirani piškotki): razlaga in »Poskusi znova« namesto večnega logotipa. */
function StorageError({ msg }: { msg: string }) {
  return (
    <div className="app" style={{ display: 'grid', placeItems: 'center', padding: 24 }}>
      <div className="card" role="alert" style={{ maxWidth: 420, width: '100%' }}>
        <div className="brand" style={{ fontWeight: 800, marginBottom: 10 }}>FORM<span>AI</span></div>
        <h3>Podatkov ne morem shraniti</h3>
        <p style={{ fontSize: rem(13.5), marginTop: 6 }}>{msg}</p>
        <div className="row" style={{ gap: 8, marginTop: 12 }}><button type="button" className="btn primary sm" onClick={() => location.reload()}>Poskusi znova</button></div>
      </div>
    </div>
  )
}

/* obvestila (vse poti): src/ui/Toasts.tsx (v3.50: vrsta, napake v role="alert", zapiranje s tipkovnico) */

/**
 * Nov obiskovalec na formai.si vidi pristajalno stran (statični HTML v index.html) → »Sestavi moj načrt« (#/uvod,
 * 3 koraki) ali »Prijava« (#/prijava). Kdor aplikacijo že uporablja (profil, zastavica, nameščena), gre naravnost na Danes.
 */
export function App() {
  const route = useRoute()
  const app = useApp()
  const [installOpen, setInstallOpen] = useState(false)

  useEffect(() => { void boot() }, [])
  // (v3.49) tekoča vadba: kopija ob odhodu v ozadje — sistem lahko aplikacijo zapre, Vadba jo ponudi nadaljevati
  useEffect(() => watchRunCopy(), [])
  // nov zaslon (zavihek, gumb) se odpre na vrhu — prej je ostal na višini prejšnjega (npr. Napredek → Prehrana na sredini);
  // Nazaj vrne na višino, kjer si zaslon zapustil
  // (v3.50) ključ je prehod v stanju poti (route.seq, route.hash), ne location.hash med izrisom: replaceParams (?dan=, ?sec=)
  // ni prehod, izris med prehodom (sprememba shrambe) pa ima še star zaslon — prej skok na staro višino in fokus na <body>
  // (v3.50) po prehodu fokus na naslov novega zaslona — bralnik zaslona pove, kje si (ne ob Nazaj)
  useLayoutEffect(() => { const s = scrollAfterRoute(route.hash); if (s === 'top') { window.scrollTo(0, 0); focusScreen() } else if (s != null) window.scrollTo(0, s) }, [route.name, route.seq])  // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (app.settings.accentHex) applyAccent(app.settings.accentHex) }, [app.settings.accentHex])
  // (v3.50) neznana pot (#/neznano, #/DANES) → prava pot brez novega vnosa v zgodovini (prej Danes brez označenega zavihka)
  useEffect(() => { const n = normalizeRoute(route.name); if (n !== route.name) navigate(n, n === route.name.toLowerCase() ? route.params : undefined, { replace: true }) }, [route.name])  // eslint-disable-line react-hooks/exhaustive-deps
  // (v3.50) nova različica: obvestilo z »Osveži« (prej tiha osvežitev ob prehodu zaslona); po osvežitvi »Posodobljeno na …«
  useEffect(() => { setAppVersion(APP_VERSION); return onUpdateReady(() => toast('Nova različica je pripravljena.', 'info', 20_000, { label: 'Osveži', run: applyUpdate })) }, [])
  useEffect(() => { if (!app.ready) return; const m = takeUpdatedNotice(APP_VERSION); if (m) toast(m, 'ok', 6000) }, [app.ready])
  // (v3.50) Firebase se ob zagonu brez prijave ne naloži — vnaprej na zaslonu Prijava in ob dotiku gumba »Prijava …«
  useEffect(() => { if (route.name === 'prijava') warmAuth() }, [route.name])
  useEffect(() => {
    const on = (e: Event) => { const b = (e.target as Element | null)?.closest?.('button, a'); if (b && /prijav/i.test(b.textContent || '')) warmAuth() }
    document.addEventListener('pointerdown', on, { capture: true, passive: true })
    return () => document.removeEventListener('pointerdown', on, { capture: true })
  }, [])

  // pristajalna stran: samo nov obiskovalec na golem naslovu (formai.si/), ne v nameščeni aplikaciji
  const landing = app.ready && !app.profile.onboardingDone && isBareRoute() && !isStandalone() && !!document.getElementById('land')
  useEffect(() => {
    if (!app.ready) return
    if (app.profile.onboardingDone) markApp()
    else if (landing) showLanding()
    else showApp()
  }, [app.ready, app.profile.onboardingDone, landing])

  // naslov strani po zaslonu (v3.48): »Plan · FORMAI« — zavihki, zgodovina in bralnik zaslona povedo, kje si;
  // pristajalna stran obdrži svoj naslov (ThinkCard ga med razmislekom začasno prepiše in nato vrne)
  useEffect(() => { if (app.ready && !landing) document.title = pageTitle(route.name) }, [app.ready, landing, route.name])

  // Prvi obisk (brez pristajalne strani) → uvod; opravljen → danes.
  useEffect(() => {
    if (!app.ready || landing) return
    if (!app.profile.onboardingDone && route.name !== 'uvod' && route.name !== 'prijava' && route.name !== 'pilot' && route.name !== 'claude') navigate('uvod')   // pregled/QR in povabilo tudi na novi napravi
    if (app.profile.onboardingDone && route.name === 'uvod') navigate('danes')
  }, [app.ready, app.profile.onboardingDone, route.name, landing])

  // Namestitveni poziv: enkrat, po nastavitvi, na telefonu, če app ne teče kot nameščena
  useEffect(() => {
    if (!app.ready || !app.profile.onboardingDone || route.name !== 'danes') return
    if (isStandalone() || app.settings.installPromptDismissedAt || window.innerWidth >= 900) return
    // ne na prvi dan in ne med vodnikom: novi uporabnik ima namestitev v »Prvih korakih«
    if (app.settings.guideSeen === false || (app.profile.goalStart?.date ?? app.profile.createdAt?.slice(0, 10) ?? '') >= app.today) return
    const t = setTimeout(() => setInstallOpen(true), 1800)
    return () => clearTimeout(t)
  }, [app.ready, app.profile.onboardingDone, route.name, app.settings.installPromptDismissedAt, app.settings.guideSeen, app.profile.goalStart?.date, app.profile.createdAt, app.today])

  // zasloni vnaprej, ko uporabnik aplikacijo že uporablja (med uvodom ne — telefon ima takrat dovolj dela)
  useEffect(() => {
    if (!app.ready || !app.profile.onboardingDone) return
    let i = 0, h = 0, dead = false
    const next = () => { if (dead || i >= WARM.length) return; void WARM[i++]!.preload().then(() => { if (!dead) h = idle(next) }) }
    h = idle(next)
    return () => { dead = true; unidle(h) }
  }, [app.ready, app.profile.onboardingDone])

  useEffect(() => { if (app.migration) console.info('FORMAI: prevzeto iz prve različice', app.migration) }, [app.migration])
  // stare poti (Več, Analitika) → Napredek
  useEffect(() => { if (route.name === 'vec' || route.name === 'analitika') navigate('napredek', undefined, { replace: true }) }, [route.name])

  if (landing) return null
  return (<>
    {app.storageError ? <StorageError msg={app.storageError} /> : app.ready ? <Screens route={route} installOpen={installOpen} closeInstall={() => { setInstallOpen(false); void updateSettings({ installPromptDismissedAt: new Date().toISOString() }) }} /> : <Splash />}
    <Toasts />
    <UndoHost />
    <OverlayHost />
    <AccountClash />
  </>)
}

function Screens({ route, installOpen, closeInstall }: { route: ReturnType<typeof useRoute>; installOpen: boolean; closeInstall: () => void }) {
  const app = useApp()
  switch (route.name) {
    // uvod: pogovor s trenerjem (AI) → dogovor → sestavljanje; »hitro« (ali korak) = kratek vprašalnik brez prijave
    case 'uvod': return <Suspense fallback={<Splash />}><div className="app"><div className="page">{route.params.hitro || route.params.korak ? <Onboarding start={route.params.korak} /> : <Sestavi />}</div></div></Suspense>
    // nov dogovor za obstoječega uporabnika (Nastavitve → Spremeni dogovor)
    case 'dogovor': return <Suspense fallback={<Splash />}><div className="app"><div className="page"><Sestavi /></div></div></Suspense>
    case 'prijava': return <Suspense fallback={<Splash />}><div className="app"><div className="page"><Prijava /></div></div></Suspense>
    // povabilo v Claude trenerja (formai.si/#/claude?k=KODA)
    case 'claude': return <Suspense fallback={<Splash />}><div className="app"><div className="page"><ClaudePovabilo koda={route.params.k || ''} /></div></div></Suspense>
    case 'vadba': return <Suspense fallback={<Splash />}><Vadba /></Suspense>
  }

  // (v3.49) tudi olajšan dan po želji (kolo, tek), ko ni druge seje: »Začni (po želji)«
  const today = pillDay(app.plan, app.today)
  // nedokončana vadba tega dne (nazaj iz vadbe): »Nadaljuj trening« (v3.48)
  // (v3.50) ob drugi seji istega dne gumb pove, katero začne (»Začni kolo«; kartica moči ima »Začni moč«); hribi »Začni hojo«
  const others = !!today && app.plan.some(d => d.date === app.today && d.id !== today.id && d.kind !== 'pocitek' && !d.done && !d.optional)
  const pill = today && route.name === 'danes' ? { label: pillLabel(today, { running: runningDayId() === today.id, others }), onClick: () => navigate('vadba', { id: today.id }) } : null

  let page
  switch (route.name) {
    case 'plan': page = <Plan />; break
    case 'prehrana': page = <Prehrana />; break
    case 'trener': page = <Trener />; break
    case 'uvoz': page = <Uvoz />; break
    case 'aktivnosti': page = <Aktivnosti />; break   // samo ročni vnos in seznam — brez zavihka
    case 'napredek': page = <Napredek />; break
    case 'nastavitve': page = <Nastavitve />; break
    case 'pilot': page = <Pilot />; break   // pregled testnega programa (skrbnik)
    case 'pripombe': page = <Pripombe />; break   // pripombe uporabnikov (skrbnik)
    case 'vaje': page = <Vaje />; break   // knjižnica vaj z animacijami
    default: page = <Danes />
  }
  return (<>
    {/* zavihki ostanejo na mestu, dokler se zaslon prenaša (samo prvič in samo, če še ni bil prenesen vnaprej) */}
    <Shell pill={pill}><Suspense fallback={<div className="scroll" aria-busy="true" />}>{page}</Suspense></Shell>
    <InstallSheet open={installOpen} onClose={closeInstall} />
  </>)
}
