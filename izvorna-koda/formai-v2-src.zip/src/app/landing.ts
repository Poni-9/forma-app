/**
 * Pristajalna stran je statični HTML v index.html (#land) — hitra, berljiva brez JS, za iskalnike.
 * Aplikacija (#root) jo skrije, ko obiskovalec klikne »Sestavi moj načrt« / »Prijava« ali ko ta brskalnik
 * aplikacijo že uporablja (zastavica v localStorage, nameščena aplikacija, profil v IndexedDB).
 */
const KEY = 'formai.app'

/** Naslov brez poti aplikacije (formai.si/, formai.si/#kako …) — tu se novemu obiskovalcu pokaže pristajalna stran.
 *  Poti aplikacije so vedno »#/ime« (enako preverja skripta v index.html). */
export function isBareRoute(h: string = location.hash): boolean { return !/^#\/./.test(h) }

/** Ta brskalnik je aplikacijo že uporabljal: odslej formai.si odpre naravnost aplikacijo. */
export function markApp(): void {
  try { localStorage.setItem(KEY, '1') } catch { /* zasebni način */ }
  showApp()
  document.getElementById('land')?.remove()
}
export function forgetApp(): void { try { localStorage.removeItem(KEY) } catch { /* zasebni način */ } }

export function showApp(): void { const c = document.documentElement.classList; c.remove('is-land'); c.add('is-app') }
export function showLanding(): boolean {
  if (!document.getElementById('land')) return false
  const c = document.documentElement.classList; c.remove('is-app'); c.add('is-land')
  return true
}
