/**
 * Naslov aplikacije (#/ime?k=v) brez Reacta: branje, sestava in (v3.50) tiho pisanje stanja zaslona.
 * router.ts jih ponovno izvozi; zasloni za stanje v naslovu uvozijo replaceParams od tu.
 */
export type Route = { name: string; params: Record<string, string> }

/** (v3.50) pokvarjen % v naslovu (#/plan?x=%) ne vrže URIError — ostane surova vrednost */
const dec = (s: string): string => { try { return decodeURIComponent(s) } catch { return s } }

export function parseHash(h: string = location.hash): Route {
  const raw = h.replace(/^#\/?/, '')
  const [path, q] = raw.split('?')
  const params: Record<string, string> = {}
  if (q) for (const kv of q.split('&')) { const [k, v] = kv.split('='); if (k) params[dec(k)] = dec(v || '') }
  return { name: path || 'danes', params }
}

/** Naslov za pot in parametre (prazni parametri izpadejo). */
export function hashFor(name: string, params?: Record<string, string | null | undefined>): string {
  const e = params ? Object.entries(params).filter((x): x is [string, string] => x[1] != null && x[1] !== '') : []
  return '#/' + name + (e.length ? '?' + e.map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&') : '')
}

/**
 * (v3.50) Stanje zaslona v naslov (dan v Prehrani, odprt razdelek): brez novega vnosa in brez hashchange — zaslon se ne
 * izriše znova, osvežitev pa ga obnovi. null ali '' parameter odstrani.
 * name: samo, če je to še zaslon v naslovu (zaslon, ki se zapira, ne piše v naslov naslednjega).
 */
export function replaceParams(patch: Record<string, string | null | undefined>, name?: string): void {
  const h = location.hash
  const r = parseHash(h)
  if (name && r.name !== name) return
  const next = hashFor(r.name, { ...r.params, ...patch })
  if (next === h || (!h && next === '#/danes')) return
  try { history.replaceState(history.state, '', next) } catch { /* brez zgodovine */ }
}
