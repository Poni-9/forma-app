import { useSyncExternalStore, type ReactNode } from 'react'
import { navigate, useRoute } from './router'
import { useApp } from '@/state/store'
import { IcoHome, IcoCal, IcoFood, IcoChat, IcoChart, IcoPlay, IcoHelp, IcoFeedback, IcoSun, IcoMoon, IcoUser } from '@/ui/icons'
import { themePref, setThemePref, subscribeTheme, resolveTheme } from '@/ui/theme'
import { openHelp } from '@/ui/overlays'
import { startFeedback } from '@/ui/HelpSheet'
import { PilotPrompt } from '@/ui/PilotPrompt'
import { useOnline } from '@/ui/useOnline'
import { PullRefresh } from '@/ui/PullRefresh'

/** Pet zavihkov, nič »Več«: vse, kar rabiš vsak dan. Nastavitve in uvoz so za avatarjem. */
export const TABS = [
  { key: 'danes', label: 'Danes', Ico: IcoHome },
  { key: 'plan', label: 'Plan', Ico: IcoCal },
  { key: 'prehrana', label: 'Prehrana', Ico: IcoFood },
  { key: 'trener', label: 'Trener', Ico: IcoChat },
  { key: 'napredek', label: 'Napredek', Ico: IcoChart },
] as const

/** Namizje: zgornja vrstica namesto spodnje (dizajn, zaslon 13). */
const DESK_NAV = [
  { key: 'danes', label: 'Danes' }, { key: 'plan', label: 'Plan' }, { key: 'prehrana', label: 'Prehrana' }, { key: 'trener', label: 'Trener' },
  { key: 'napredek', label: 'Napredek' }, { key: 'nastavitve', label: 'Nastavitve' },
]
/** zasloni brez lastnega zavihka (nastavitve, uvoz, ročni vnos) → označen ni noben */
const MORE_KEYS = new Set(['vec', 'aktivnosti', 'analitika', 'nastavitve', 'uvoz', 'pripombe', 'pilot'])
/** Začetnici imena (»Blaž Gregorc« → »BG«); brez imena null → ikona osebe (v3.48: prej »F« iz »FA«). */
export function initialsOf(name: string | null | undefined): string | null {
  const s = (name || '').trim()
  if (!s) return null
  return s.split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase()
}
/** isto ime za oba avatarja (vrstica na namizju, glava na telefonu) — prej »Nastavitve« in »Profil« */
const AVATAR_LABEL = 'Nastavitve in profil'

export function Shell({ children, pill }: { children: ReactNode; pill?: { label: string; onClick: () => void } | null }) {
  const route = useRoute()
  const app = useApp()
  const online = useOnline()
  const active = MORE_KEYS.has(route.name) ? '' : route.name
  const initials = initialsOf(app.user?.name || app.profile.name)
  const syncDot = app.sync.state === 'error' ? 'var(--bad)' : app.user ? 'var(--ok)' : null
  return (
    <div className={`app ${pill ? 'has-pill' : 'has-tabs'}`}>
      <div className="dbar">
        <div className="lg brand">FORM<span>AI</span></div>
        <nav className="dnav" aria-label="Glavna navigacija">{DESK_NAV.map(n => <button key={n.key} className={route.name === n.key ? 'on' : ''} onClick={() => navigate(n.key)} aria-current={route.name === n.key ? 'page' : undefined}>{n.label}</button>)}</nav>
        <div style={{ marginLeft: 'auto' }} className="row">
          {pill && <button className="btn primary sm" onClick={pill.onClick}><IcoPlay />{pill.label}</button>}
          <HeadButtons />
          <button className="avatar" style={{ width: 34, height: 34, fontSize: 13, position: 'relative' }} onClick={() => navigate('nastavitve')} aria-label={AVATAR_LABEL}>
            {app.user?.photo ? <img src={app.user.photo} alt="" width={34} height={34} style={{ borderRadius: 999 }} referrerPolicy="no-referrer" /> : initials ?? <IcoUser width={18} height={18} aria-hidden="true" />}
            {syncDot && <span className={`dot ${app.sync.state === 'push' || app.sync.state === 'pull' ? 'syncing' : ''}`} style={{ position: 'absolute', right: -1, bottom: -1, background: syncDot, border: '2px solid var(--bg)', width: 10, height: 10 }} />}
          </button>
        </div>
      </div>
      {!online && <div className="offline" role="status">Brez povezave — vse je shranjeno na napravi, uskladim in uvozim, ko se povezava vrne.</div>}
      {/* ključ na poti: vsak zaslon pride z lastno vstopno animacijo */}
      <main className="screen page" key={route.name}>{children}</main>
      <nav className={`tabs ${pill ? 'with-pill' : ''}`} aria-label="Glavna navigacija">
        {pill && <button className="pill" onClick={pill.onClick}><IcoPlay />{pill.label}</button>}
        {TABS.map(t => <button key={t.key} className={`tab ${active === t.key ? 'on' : ''}`} onClick={() => navigate(t.key)} aria-current={active === t.key ? 'page' : undefined}><t.Ico on={active === t.key} />{t.label}</button>)}
      </nav>
      <PilotPrompt />
      <PullRefresh />
      {/* obvestila (toast) izriše App za vse poti — tudi uvod, prijavo in vadbo */}
    </div>
  )
}

/**
 * »?« (Kako deluje + izrazi), »Pripomba« (posnetek zaslona + besedilo/glas → razvijalcu) in svetlo/temno — na vsakem
 * zaslonu (16. 10.: svetla tema je bila samo v Nastavitvah → Videz in je uporabniki niso našli).
 */
export function HeadButtons() {
  const pref = useSyncExternalStore(subscribeTheme, themePref, themePref)
  const light = resolveTheme(pref) === 'light'
  return (<>
    <button type="button" className="hbtn" onClick={() => setThemePref(light ? 'temno' : 'svetlo')} aria-label={light ? 'Preklopi na temni videz' : 'Preklopi na svetli videz'} title={light ? 'Temno' : 'Svetlo'}>{light ? <IcoMoon width={20} height={20} /> : <IcoSun width={20} height={20} />}</button>
    <button type="button" className="hbtn" onClick={() => openHelp()} aria-label="Kako deluje — pomoč in izrazi" title="Kako deluje"><IcoHelp width={20} height={20} /></button>
    <button type="button" className="hbtn" onClick={() => void startFeedback()} aria-label="Pošlji pripombo ali napako" title="Pripomba"><IcoFeedback width={20} height={20} /></button>
  </>)
}

export function Head({ hi, nm, right }: { hi: string; nm: string; right?: ReactNode }) {
  const app = useApp()
  const initials = initialsOf(app.user?.name || app.profile.name)
  const syncDot = app.sync.state === 'error' ? 'var(--bad)' : app.user ? 'var(--ok)' : null
  return (
    <header className="head">
      <div style={{ minWidth: 0 }}><div className="hi">{hi}</div><h1 className="nm">{nm}</h1></div>
      <div className="head-act"><HeadButtons />
      {right ?? (
        <button className="avatar" style={{ position: 'relative' }} onClick={() => navigate('nastavitve')} aria-label={AVATAR_LABEL}>
          {app.user?.photo ? <img src={app.user.photo} alt="" width={38} height={38} style={{ borderRadius: 999 }} referrerPolicy="no-referrer" /> : initials ?? <IcoUser width={20} height={20} aria-hidden="true" />}
          {syncDot && <span className={`dot ${app.sync.state === 'push' || app.sync.state === 'pull' ? 'syncing' : ''}`} style={{ position: 'absolute', right: -1, bottom: -1, background: syncDot, border: '2px solid var(--bg)', width: 10, height: 10 }} />}
        </button>
      )}
      </div>
    </header>
  )
}
