import { useSyncExternalStore, type ReactNode } from 'react'
import { navigate, navTab, useRoute } from './router'
import { useApp, toast } from '@/state/store'
import { IcoHome, IcoCal, IcoFood, IcoChat, IcoChart, IcoPlay, IcoHelp, IcoFeedback, IcoSun, IcoMoon, IcoUser } from '@/ui/icons'
import { themePref, setThemePref, subscribeTheme, resolveTheme, themeToggle } from '@/ui/theme'
import { openHelp } from '@/ui/overlays'
import { startFeedback } from '@/ui/HelpSheet'
import { PilotPrompt } from '@/ui/PilotPrompt'
import { useOnline } from '@/ui/useOnline'
import { PullRefresh } from '@/ui/PullRefresh'
import { ErrorBoundary } from './ErrorBoundary'
import { parseHash } from './hash'
import { SCREEN_NAME } from '@/ui/screenNames'
import { rem } from '@/ui/rem'

/** Pet zavihkov, nič »Več«: vse, kar rabiš vsak dan. Nastavitve in uvoz so za avatarjem. */
export const TABS = [
  { key: 'danes', label: 'Danes', Ico: IcoHome },
  { key: 'plan', label: 'Plan', Ico: IcoCal },
  { key: 'prehrana', label: 'Prehrana', Ico: IcoFood },
  { key: 'trener', label: 'Trener', Ico: IcoChat },
  { key: 'napredek', label: 'Napredek', Ico: IcoChart },
] as const

/** Namizje: zgornja vrstica namesto spodnje (dizajn, zaslon 13). */
const DESK_NAV = [
  { key: 'danes', label: 'Danes' }, { key: 'plan', label: 'Plan' }, { key: 'prehrana', label: 'Prehrana' }, { key: 'trener', label: 'Trener' },
  { key: 'napredek', label: 'Napredek' }, { key: 'nastavitve', label: 'Nastavitve' },
]
const TAB_KEYS: readonly string[] = TABS.map(t => t.key)
const DESK_KEYS: readonly string[] = DESK_NAV.map(n => n.key)
/** (v3.50) pas brez povezave v eni vrstici (prej dve, 51 px nad vsakim zaslonom); podrobnost v title */
export const OFFLINE_BAR = 'Brez povezave — vse se shrani na napravi.'
/** (v3.51) drugi del pasu po stanju: brez računa in ure ni česa uskladiti (prej vedno »Uskladim in uvozim«) */
export function offlineMore(o: { user: unknown; intervals: unknown }): string {
  return o.user && o.intervals ? 'Uskladim in uvozim, ko se povezava vrne.' : o.user ? 'Uskladim, ko se povezava vrne.'
    : o.intervals ? 'Vožnje z ure uvozim, ko se povezava vrne.' : ''
}
/** zasloni brez lastnega zavihka (nastavitve, uvoz, ročni vnos) → označen ni noben */
const MORE_KEYS = new Set(['vec', 'aktivnosti', 'analitika', 'nastavitve', 'uvoz', 'pripombe', 'pilot'])
/** Začetnici imena (»Blaž Gregorc« → »BG«); brez imena null → ikona osebe (v3.48: prej »F« iz »FA«). */
export function initialsOf(name: string | null | undefined): string | null {
  const s = (name || '').trim()
  if (!s) return null
  return s.split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase()
}
/** isto ime za oba avatarja (vrstica na namizju, glava na telefonu) — prej »Nastavitve« in »Profil« */
const AVATAR_LABEL = 'Nastavitve in profil'
/** (v3.51) stanje usklajevanja tudi v imenu gumba (prej samo barva pike) */
export function avatarLabel(sync: string, user: unknown): string {
  return `${AVATAR_LABEL}${sync === 'error' ? ' — usklajevanje ne dela' : user ? ' — usklajeno' : ''}`
}
/** (v3.51) »Preskoči na vsebino«: na prvi del za glavo zaslona (prej na main, pred štirimi gumbi glave) */
export function skipToContent(doc: Document = document): void {
  const main = doc.getElementById('vsebina')
  if (!main) return
  const t = (main.querySelector('header.head')?.nextElementSibling as HTMLElement | null) ?? main
  if (!t.hasAttribute('tabindex')) { t.setAttribute('tabindex', '-1'); t.setAttribute('data-skip', '') }
  try { t.focus({ preventScroll: true }) } catch { /* */ }
}

export function Shell({ children, pill }: { children: ReactNode; pill?: { label: string; onClick: () => void } | null }) {
  const route = useRoute()
  const app = useApp()
  const online = useOnline()
  const active = MORE_KEYS.has(route.name) ? '' : route.name
  const initials = initialsOf(app.user?.name || app.profile.name)
  const syncDot = app.sync.state === 'error' ? 'var(--bad)' : app.user ? 'var(--ok)' : null
  const more = offlineMore({ user: app.user, intervals: app.settings.intervals })
  return (
    <div className={`app ${pill ? 'has-pill' : 'has-tabs'}`}>
      {/* (v3.50) tipkovnica: prvi Tab skoči čez glavo in trak tedna naravnost v vsebino */}
      <a className="skip-link" href="#vsebina" onClick={e => { e.preventDefault(); skipToContent() }}>Preskoči na vsebino</a>
      {/* (v3.51) vrstica na namizju je orientir (banner) — prej logotip in gumbi zunaj orientirjev */}
      <header className="dbar">
        <div className="lg brand">FORM<span>AI</span></div>
        <nav className="dnav" aria-label="Glavna navigacija">{DESK_NAV.map(n => <button key={n.key} className={route.name === n.key ? 'on' : ''} onClick={() => navTab(n.key, DESK_KEYS)} aria-current={route.name === n.key ? 'page' : undefined}>{n.label}</button>)}</nav>
        <div style={{ marginLeft: 'auto' }} className="row">
          {pill && <button className="btn primary sm" onClick={pill.onClick}><IcoPlay />{pill.label}</button>}
          <HeadButtons />
          <button className="avatar" style={{ width: 34, height: 34, fontSize: rem(13), position: 'relative' }} onClick={() => navigate('nastavitve')} aria-label={avatarLabel(app.sync.state, app.user)}>
            {app.user?.photo ? <img src={app.user.photo} alt="" width={34} height={34} style={{ borderRadius: 999 }} referrerPolicy="no-referrer" /> : initials ?? <IcoUser width={18} height={18} aria-hidden="true" />}
            {syncDot && <span className={`dot ${app.sync.state === 'push' || app.sync.state === 'pull' ? 'syncing' : ''}${app.sync.state === 'error' ? ' sync-err' : ''}`} style={{ position: 'absolute', right: -1, bottom: -1, background: syncDot, border: '2px solid var(--bg)', width: 10, height: 10 }} />}
          </button>
        </div>
      </header>
      {!online && <div className="offline" role="status" title={more || undefined}>{OFFLINE_BAR}{more && <span className="sr-only"> {more}</span>}</div>}
      {/* ključ na poti: vsak zaslon pride z lastno vstopno animacijo */}
      {/* (v3.49) napaka enega zaslona ne podre aplikacije: meja okoli zaslona, zavihki ostanejo */}
      <main className="screen page" key={route.name} id="vsebina" tabIndex={-1}><ErrorBoundary screen>{children}</ErrorBoundary></main>
      <nav className={`tabs ${pill ? 'with-pill' : ''}`} aria-label="Glavna navigacija">
        {pill && <button className="pill" onClick={pill.onClick}><IcoPlay />{pill.label}</button>}
        {TABS.map(t => <button key={t.key} className={`tab ${active === t.key ? 'on' : ''}`} onClick={() => navTab(t.key, TAB_KEYS)} aria-current={active === t.key ? 'page' : undefined}><t.Ico on={active === t.key} />{t.label}</button>)}
      </nav>
      <PilotPrompt />
      <PullRefresh />
      {/* obvestila (toast) izriše App za vse poti — tudi uvod, prijavo in vadbo */}
    </div>
  )
}

/**
 * »?« (Kako deluje + izrazi), »Pripomba« (posnetek zaslona + besedilo/glas → razvijalcu) in svetlo/temno — na vsakem
 * zaslonu (16. 10.: svetla tema je bila samo v Nastavitvah → Videz in je uporabniki niso našli).
 */
export function HeadButtons() {
  const pref = useSyncExternalStore(subscribeTheme, themePref, themePref)
  const light = resolveTheme(pref) === 'light'
  return (<>
    <button type="button" className="hbtn" onClick={() => { const t = themeToggle(pref, light); setThemePref(t.pref); if (t.notice) toast(t.notice, 'info', 7000) }} aria-label={light ? 'Preklopi na temni videz' : 'Preklopi na svetli videz'} title={light ? 'Temno' : 'Svetlo'}>{light ? <IcoMoon width={20} height={20} /> : <IcoSun width={20} height={20} />}</button>
    <button type="button" className="hbtn" onClick={() => openHelp()} aria-label="Kako deluje — pomoč in izrazi" title="Kako deluje"><IcoHelp width={20} height={20} /></button>
    <button type="button" className="hbtn" onClick={() => void startFeedback()} aria-label="Pošlji pripombo ali napako" title="Pripomba"><IcoFeedback width={20} height={20} /></button>
  </>)
}

export function Head({ hi, nm, right }: { hi: string; nm: string; right?: ReactNode }) {
  const app = useApp()
  const initials = initialsOf(app.user?.name || app.profile.name)
  const syncDot = app.sync.state === 'error' ? 'var(--bad)' : app.user ? 'var(--ok)' : null
  // (v3.51) bralnik zaslona po prehodu pove zaslon (»Danes — Živjo, Blaž«), ne samo pozdrava ali pogleda
  const scr = SCREEN_NAME[parseHash().name]
  const pre = scr && !nm.startsWith(scr) ? scr : null
  return (
    <header className="head">
      <div style={{ minWidth: 0 }}><div className="hi">{hi}</div><h1 className="nm" aria-label={pre ? `${pre} — ${nm}` : undefined}>{nm}</h1></div>
      <div className="head-act"><HeadButtons />
      {right ?? (
        <button className="avatar" style={{ position: 'relative' }} onClick={() => navigate('nastavitve')} aria-label={avatarLabel(app.sync.state, app.user)}>
          {app.user?.photo ? <img src={app.user.photo} alt="" width={38} height={38} style={{ borderRadius: 999 }} referrerPolicy="no-referrer" /> : initials ?? <IcoUser width={20} height={20} aria-hidden="true" />}
          {syncDot && <span className={`dot ${app.sync.state === 'push' || app.sync.state === 'pull' ? 'syncing' : ''}${app.sync.state === 'error' ? ' sync-err' : ''}`} style={{ position: 'absolute', right: -1, bottom: -1, background: syncDot, border: '2px solid var(--bg)', width: 10, height: 10 }} />}
        </button>
      )}
      </div>
    </header>
  )
}
