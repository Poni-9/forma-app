import type { ReactNode } from 'react'
import { navigate, useRoute } from './router'
import { useApp } from '@/state/store'
import { IcoHome, IcoCal, IcoFood, IcoChat, IcoChart, IcoPlay } from '@/ui/icons'
import { PilotPrompt } from '@/ui/PilotPrompt'

/** Pet zavihkov, nič »Več«: vse, kar rabiš vsak dan. Nastavitve in uvoz so za avatarjem. */
export const TABS = [
  { key: 'danes', label: 'Danes', Ico: IcoHome },
  { key: 'plan', label: 'Plan', Ico: IcoCal },
  { key: 'prehrana', label: 'Prehrana', Ico: IcoFood },
  { key: 'trener', label: 'Trener', Ico: IcoChat },
  { key: 'napredek', label: 'Napredek', Ico: IcoChart },
] as const

/** Namizje: zgornja vrstica namesto spodnje (dizajn, zaslon 13). */
const DESK_NAV = [
  { key: 'danes', label: 'Danes' }, { key: 'plan', label: 'Plan' }, { key: 'prehrana', label: 'Prehrana' }, { key: 'trener', label: 'Trener' },
  { key: 'napredek', label: 'Napredek' }, { key: 'nastavitve', label: 'Nastavitve' },
]
/** zasloni brez lastnega zavihka (nastavitve, uvoz, ročni vnos) → označen ni noben */
const MORE_KEYS = new Set(['vec', 'aktivnosti', 'analitika', 'nastavitve', 'uvoz'])

export function Shell({ children, pill }: { children: ReactNode; pill?: { label: string; onClick: () => void } | null }) {
  const route = useRoute()
  const app = useApp()
  const active = MORE_KEYS.has(route.name) ? '' : route.name
  const initials = (app.user?.name || app.profile.name || 'FA').split(/\s+/).map(s => s[0]).join('').slice(0, 2).toUpperCase()
  const syncDot = app.sync.state === 'error' ? 'var(--bad)' : app.user ? 'var(--ok)' : null
  return (
    <div className={`app ${pill ? 'has-pill' : 'has-tabs'}`}>
      <div className="dbar">
        <div className="lg brand">FORM<span>AI</span></div>
        <nav className="dnav">{DESK_NAV.map(n => <button key={n.key} className={route.name === n.key ? 'on' : ''} onClick={() => navigate(n.key)}>{n.label}</button>)}</nav>
        <div style={{ marginLeft: 'auto' }} className="row">
          {pill && <button className="btn primary sm" onClick={pill.onClick}><IcoPlay />{pill.label}</button>}
          <button className="avatar" style={{ width: 34, height: 34, fontSize: 13, position: 'relative' }} onClick={() => navigate('nastavitve')} aria-label="Nastavitve">
            {app.user?.photo ? <img src={app.user.photo} alt="" width={34} height={34} style={{ borderRadius: 999 }} referrerPolicy="no-referrer" /> : initials}
            {syncDot && <span className={`dot ${app.sync.state === 'push' || app.sync.state === 'pull' ? 'syncing' : ''}`} style={{ position: 'absolute', right: -1, bottom: -1, background: syncDot, border: '2px solid var(--bg)', width: 10, height: 10 }} />}
          </button>
        </div>
      </div>
      {/* ključ na poti: vsak zaslon pride z lastno vstopno animacijo */}
      <div className="screen page" key={route.name}>{children}</div>
      <nav className={`tabs ${pill ? 'with-pill' : ''}`} aria-label="Glavna navigacija">
        {pill && <button className="pill" onClick={pill.onClick}><IcoPlay />{pill.label}</button>}
        {TABS.map(t => <button key={t.key} className={`tab ${active === t.key ? 'on' : ''}`} onClick={() => navigate(t.key)} aria-current={active === t.key ? 'page' : undefined}><t.Ico on={active === t.key} />{t.label}</button>)}
      </nav>
      <PilotPrompt />
      {app.toast && <div key={app.toast.id} className={`toast ${app.toast.kind === 'err' ? 'err' : app.toast.kind === 'ok' ? 'ok' : ''}`} role="status">{app.toast.msg}</div>}
    </div>
  )
}

export function Head({ hi, nm, right }: { hi: string; nm: string; right?: ReactNode }) {
  const app = useApp()
  const initials = (app.user?.name || app.profile.name || 'FA').split(/\s+/).map(s => s[0]).join('').slice(0, 2).toUpperCase()
  const syncDot = app.sync.state === 'error' ? 'var(--bad)' : app.user ? 'var(--ok)' : null
  return (
    <div className="head">
      <div><div className="hi">{hi}</div><div className="nm">{nm}</div></div>
      {right ?? (
        <button className="avatar" style={{ position: 'relative' }} onClick={() => navigate('nastavitve')} aria-label="Profil">
          {app.user?.photo ? <img src={app.user.photo} alt="" width={38} height={38} style={{ borderRadius: 999 }} referrerPolicy="no-referrer" /> : initials}
          {syncDot && <span className={`dot ${app.sync.state === 'push' || app.sync.state === 'pull' ? 'syncing' : ''}`} style={{ position: 'absolute', right: -1, bottom: -1, background: syncDot, border: '2px solid var(--bg)', width: 10, height: 10 }} />}
        </button>
      )}
    </div>
  )
}
