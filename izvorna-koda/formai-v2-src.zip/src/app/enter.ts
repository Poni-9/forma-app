/**
 * Vstop v aplikacijo s pristajalne strani. Skripta v index.html pred prvim izrisom izbere »is-land« (nov obiskovalec
 * na golem naslovu) ali »is-app« (#/…, ?code= z intervals.icu, nameščena ali že uporabljena aplikacija).
 * Na pristajalni strani se aplikacija (React, stanje, Firebase …) NE naloži: šele ko obiskovalec vstopi
 * (#/uvod, #/prijava … s klikom na gumb ali z naslovom). Ko se prst ali miška približa gumbu za vstop,
 * se aplikacija začne prenašati vnaprej, da je klik takojšen.
 */
export const APP_HASH = /^#\/./
const INTENT = ['pointerover', 'pointerdown', 'touchstart', 'focusin'] as const

export interface Gate {
  /** prenese (in izvede) modul aplikacije — ponovljivo; ob napaki naslednji klic poskusi znova */
  load: () => Promise<unknown>
  /** zažene aplikacijo (izris v #root) — pokliče se enkrat */
  start: () => void
}

/** Zažene aplikacijo takoj (is-app) ali počaka na vstop s pristajalne strani (is-land). Vrne, ali je začela takoj. */
export function gate(g: Gate, doc: Document = document, win: Window = window): boolean {
  let started = false
  const intent = (e: Event) => {
    const t = e.target as Element | null
    if (!t || typeof t.closest !== 'function' || !t.closest('a[href^="#/"]')) return
    for (const k of INTENT) doc.removeEventListener(k, intent, true)
    void g.load().catch(() => { /* ob vstopu poskusi znova */ })
  }
  const onHash = () => { if (APP_HASH.test(win.location.hash)) go() }
  function go() {
    if (started) return
    started = true
    win.removeEventListener('hashchange', onHash)
    for (const k of INTENT) doc.removeEventListener(k, intent, true)
    g.start()
  }
  if (!doc.documentElement.classList.contains('is-land')) { go(); return true }
  win.addEventListener('hashchange', onHash)
  for (const k of INTENT) doc.addEventListener(k, intent, { capture: true, passive: true })
  return false
}
