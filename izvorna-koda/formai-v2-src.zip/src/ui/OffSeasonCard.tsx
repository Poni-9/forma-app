import { useState } from 'react'
import { useApp, endOffSeason, toast } from '@/state/store'
import { offSeasonNow } from '@/domain/training/goalChange'
import { weekContext } from '@/domain/training/planner'
import { addDays, weekStartIso } from '@/domain/training/load'
import { Btn, Card } from '@/ui/primitives'
import { GoalSheet } from '@/ui/GoalSheet'
import { dm } from '@/ui/format'

/**
 * Off-season na Danes (pod današnjim treningom): kje si, kdaj začne osnova in dve dejanji — »Spočit sem — začni z osnovo«
 * ali »Cilj sezone« (sprememba cilja tudi sredi off-seasona spremeni načrt).
 */
export function OffSeasonCard() {
  const app = useApp()
  const [goal, setGoal] = useState(false)
  const [busy, setBusy] = useState(false)
  const off = offSeasonNow(app.profile, app.today)
  if (!off) return null
  const cx = weekContext(app.profile, weekStartIso(app.today))
  const stage = cx.offStage === 'pocitek' ? 'počitek' : cx.offStage === 'vrnitev' ? 'vrnitev na kolo' : 'aktivni počitek'
  const baseFrom = addDays(app.profile.cycleStart || app.today, off.of * 7)
  const ev = app.profile.event?.date && app.profile.event.date >= app.today ? app.profile.event : null
  async function start() {
    if (busy) return
    setBusy(true); await endOffSeason(); setBusy(false)
    toast('Osnova začne ta teden — lahki tedni, nato test FTP.', 'ok', 6000)
  }
  return (
    <Card tight className="off-card">
      <div className="between" style={{ gap: 10, alignItems: 'baseline' }}>
        <h2 className="h4" style={{ fontSize: 11, margin: 0 }}>Off-season · {stage}</h2>
        <span className="muted" style={{ fontSize: 11.5, fontWeight: 700 }}>teden {off.week}/{off.of}</span>
      </div>
      <p style={{ fontSize: 12.5, marginTop: 4, color: 'var(--ink-2)' }}>Osnova{ev ? ` za ${ev.name}` : ''} začne {dm(baseFrom)} z lahkimi tedni. Če si spočit prej ali hočeš drug cilj, se načrt spremeni takoj.</p>
      <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
        <Btn sm disabled={busy} onClick={() => void start()}>Spočit sem — začni z osnovo</Btn>
        <Btn sm ghost onClick={() => setGoal(true)}>Cilj sezone</Btn>
      </div>
      {goal && <GoalSheet open onClose={() => setGoal(false)} />}
    </Card>
  )
}
