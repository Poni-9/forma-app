/**
 * VIDEZ (Blaž, 6. 10.: »da maš lahko še svetlo ali temno … da ni tako depresivno«): temno, svetlo ali kot telefon.
 * Izbira je na napravi (localStorage), ker jo skripta v index.html prebere pred prvim izrisom — brez bliska temne
 * strani pred svetlo. Pristajalna stran ostane temna (CSS: :root[data-theme="light"]:not(.is-land)).
 */
export type ThemePref = 'temno' | 'svetlo' | 'samodejno'
export type Theme = 'dark' | 'light'

export const THEME_KEY = 'formai.theme'
/** brez izbire: tako kot do zdaj (isto prebere skripta v index.html) */
export const THEME_DEFAULT: ThemePref = 'temno'
export const THEME_PREFS: readonly [ThemePref, string][] = [['temno', 'Temno'], ['svetlo', 'Svetlo'], ['samodejno', 'Kot telefon']]
/** barva vrstice brskalnika / stanja telefona (= --bg teme) */
export const THEME_BG: Record<Theme, string> = { dark: '#0F1216', light: '#F4F6F2' }

const isPref = (x: unknown): x is ThemePref => x === 'temno' || x === 'svetlo' || x === 'samodejno'
const mq = () => (typeof matchMedia === 'function' ? matchMedia('(prefers-color-scheme: light)') : null)

export function themePref(): ThemePref {
  try { const v = localStorage.getItem(THEME_KEY); return isPref(v) ? v : THEME_DEFAULT } catch { return THEME_DEFAULT }
}
export function resolveTheme(p: ThemePref, systemLight = !!mq()?.matches): Theme {
  return p === 'svetlo' || (p === 'samodejno' && systemLight) ? 'light' : 'dark'
}

/** Nastavi temo na <html> in barvo vrstice brskalnika (na pristajalni strani vedno temna). */
export function applyTheme(p: ThemePref = themePref()): Theme {
  const t = resolveTheme(p)
  const d = document.documentElement
  d.dataset.theme = t
  syncThemeMeta()
  return t
}
/** theme-color in iOS vrstica stanja (ta velja ob naslednjem zagonu nameščene aplikacije) po trenutni temi in strani. */
export function syncThemeMeta(): void {
  const d = document.documentElement
  const t: Theme = d.dataset.theme === 'light' && !d.classList.contains('is-land') ? 'light' : 'dark'
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', THEME_BG[t])
  document.querySelector('meta[name="apple-mobile-web-app-status-bar-style"]')?.setAttribute('content', t === 'light' ? 'default' : 'black-translucent')
}

const subs = new Set<() => void>()
export function setThemePref(p: ThemePref): void {
  try { localStorage.setItem(THEME_KEY, p) } catch { /* zasebni način: velja do zaprtja */ }
  applyTheme(p)
  subs.forEach(f => f())
}
export function subscribeTheme(f: () => void): () => void { subs.add(f); return () => { subs.delete(f) } }

let watching = false
/** »Kot telefon«: ko telefon zamenja temo (npr. zvečer), jo zamenja tudi aplikacija. */
export function watchSystemTheme(): void {
  const m = mq()
  if (watching || !m) return
  watching = true
  const on = () => { if (themePref() === 'samodejno') { applyTheme('samodejno'); subs.forEach(f => f()) } }
  if (m.addEventListener) m.addEventListener('change', on); else m.addListener?.(on)
}

/* ---------- odtenek zelene v svetli temi: besedilo in ikone v barvi poudarka morajo biti berljivi ----------
   Limeta na beli ima kontrast 1,5 : 1 — za besedilo rabimo temnejši odtenek istega tona (≥ 4,5 : 1 na ozadju
   in na mehki podlagi poudarka, npr. izbrani čip). Gumbi in polnila ostanejo v izbrani barvi. */
const hex2 = (h: string): [number, number, number] => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16)) as [number, number, number]
const toHex = (c: readonly number[]) => '#' + c.map(v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('').toUpperCase()
const lin = (c: number) => { const s = c / 255; return s <= 0.04045 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4 }
export const luminance = (h: string) => { const [r, g, b] = hex2(h); return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b) }
export const contrast = (a: string, b: string) => { const x = luminance(a), y = luminance(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05) }
/** barva a čez podlago b z deležem t (kot rgba(a, t) na b) */
export const mixOver = (a: string, b: string, t: number) => { const A = hex2(a), B = hex2(b); return toHex(A.map((v, i) => v * t + B[i]! * (1 - t))) }
function hsl(h: string): [number, number, number] {
  const [r, g, b] = hex2(h).map(v => v / 255) as [number, number, number]
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2
  if (mx === mn) return [0, 0, l]
  const d = mx - mn, s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn)
  const hh = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4
  return [hh / 6, s, l]
}
function fromHsl(h: number, s: number, l: number): string {
  if (!s) return toHex([l * 255, l * 255, l * 255])
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q
  const f = (t: number) => { if (t < 0) t += 1; if (t > 1) t -= 1; return t < 1 / 6 ? p + (q - p) * 6 * t : t < 1 / 2 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p }
  return toHex([f(h + 1 / 3) * 255, f(h) * 255, f(h - 1 / 3) * 255])
}
/** delež poudarka v mehki podlagi svetle teme (--accent-soft) */
export const LIGHT_SOFT = 0.18
/** Temnejši odtenek poudarka za besedilo v svetli temi: ≥ 4,5 : 1 na ozadju in na mehki podlagi poudarka. */
export function accentDeep(hex: string, bg = THEME_BG.light, min = 4.5): string {
  if (!/^#[0-9a-fA-F]{6}$/.test(hex)) return '#4D740E'
  const soft = mixOver(hex, bg, LIGHT_SOFT)
  const [h, s, l0] = hsl(hex)
  for (let l = l0; l > 0; l -= 0.01) {
    const c = fromHsl(h, s, l)
    if (contrast(c, bg) >= min && contrast(c, soft) >= min) return c
  }
  return '#1F2A10'
}
