import { useState } from 'react'
import { useApp } from '@/state/store'
import { goalStatus, levelOf, milestones, ftpPotential, raceWeightOf, fullHoursWeek, rampStart } from '@/domain/training/goal'
import { Guide } from '@/ui/Guide'
import { weekContext } from '@/domain/training/planner'
import { weekStartIso } from '@/domain/training/load'
import { Card, Btn, Track } from '@/ui/primitives'
import { GoalSheet } from '@/ui/GoalSheet'

const f2 = (x: number) => x.toFixed(2).replace('.', ',')
const kgf = (x: number | null) => (x == null ? '—' : Number.isInteger(x) ? String(x) : x.toFixed(1).replace('.', ','))
const fd = (iso: string) => `${+iso.slice(8)}. ${+iso.slice(5, 7)}. ${iso.slice(2, 4) === new Date().toISOString().slice(2, 4) ? '' : iso.slice(0, 4)}`.trim()
const MON = ['jan', 'feb', 'mar', 'apr', 'maj', 'jun', 'jul', 'avg', 'sep', 'okt', 'nov', 'dec']

/** Pot do cilja: odštevanje, W/kg zdaj → cilj, ali si na poti, raven. Brez cilja: poziv, da ga nastaviš. */
export function GoalCard({ full = false }: { full?: boolean }) {
  const app = useApp()
  const { profile: p, checkins, today, settings } = app
  const [open, setOpen] = useState(false)
  const [guide, setGuide] = useState(false)
  const g = goalStatus(p, checkins, settings.tests || [], today)
  const cx = weekContext(p, weekStartIso(today))

  if (!g.event) return (<>
    <Card accent style={{ marginTop: 12 }}>
      <h4 style={{ margin: 0 }}>Cilj sezone</h4>
      <p style={{ fontSize: 13, marginTop: 6 }}>Maraton Franja, 13. 6. 2027 (156 km). Vpiši FTP in težo — najboljšo težo in največji možni FTP izračunam sam, potem načrt, prehrana in AI trener delajo za ta cilj.</p>
      <Btn primary sm style={{ marginTop: 10 }} onClick={() => setOpen(true)}>Nastavi cilj</Btn>
    </Card>
    {open && <GoalSheet open onClose={() => setOpen(false)} />}
  </>)

  const lv = levelOf(g.wkg), tl = levelOf(g.targetWkg)
  const from = g.startWkg ?? g.wkg
  const pct = g.wkg && g.targetWkg && from != null && g.targetWkg > from ? ((g.wkg - from) / (g.targetWkg - from)) * 100 : 0
  const diff = g.wkg && g.expected?.wkg ? g.wkg - g.expected.wkg : null
  const status = diff == null ? null : diff >= 0.03 ? { t: 'pred načrtom', c: 'var(--ok)' } : diff <= -0.08 ? { t: 'za načrtom', c: 'var(--warn)' } : { t: 'na poti', c: 'var(--ok)' }
  const ms = full ? milestones(p) : []
  const potH = full ? ftpPotential(p, today)?.hours ?? null : null
  const fullAt = full ? fullHoursWeek(p, today) : null

  return (<>
    <Card style={{ marginTop: full ? 0 : 12 }}>
      <div className="between">
        <h4 style={{ margin: 0 }}>{g.event.name}{g.event.distanceKm ? ` · ${g.event.distanceKm} km` : ''}</h4>
        <span style={{ fontSize: 12, fontWeight: 800, color: 'var(--accent)' }}>{g.daysToEvent != null && g.daysToEvent > 13 ? `še ${g.weeksToEvent} tednov` : g.daysToEvent ? `še ${g.daysToEvent} dni` : 'danes'}</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr auto 1fr', gap: 10, alignItems: 'end', marginTop: 10 }}>
        <div><div style={{ fontSize: 28, fontWeight: 800, letterSpacing: '-.03em' }}>{g.wkg ? f2(g.wkg) : '—'}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>W/KG ZDAJ{lv ? ` · ${lv.name.toUpperCase()}` : ''}</div></div>
        <div className="muted" style={{ fontSize: 18, paddingBottom: 14 }}>→</div>
        <div style={{ textAlign: 'right' }}><div style={{ fontSize: 28, fontWeight: 800, letterSpacing: '-.03em', color: 'var(--accent)' }}>{g.targetWkg ? f2(g.targetWkg) : '—'}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>CILJ{tl ? ` · ${tl.name.toUpperCase()}` : ''}</div></div>
      </div>
      <div style={{ marginTop: 8 }}><Track pct={pct} color="var(--accent)" /></div>
      <div className="between muted" style={{ fontSize: 12, marginTop: 6, fontWeight: 600 }}>
        <span>{g.ftp ?? '—'} W · {kgf(g.weight)} kg</span>
        <span>{g.targetFtp ?? '—'} W · {kgf(g.targetWeight)} kg</span>
      </div>
      {full && (() => { const rw = raceWeightOf(p, today), pot = ftpPotential(p, today); return (rw || pot) ? (
        <div style={{ fontSize: 12.5, marginTop: 8, color: 'var(--ink-2)' }}>
          {rw && <>Najboljša teža zate <b style={{ color: 'var(--ink)' }}>{rw.kg.toFixed(1).replace('.', ',')} kg</b> ({rw.measured ? 'maščoba' : 'ocena maščobe iz BMI'} ~{Math.round(rw.bf)} % → ~{rw.targetBf} %). </>}
          {pot && <>Največji možni FTP do dirke <b style={{ color: 'var(--ink)' }}>{pot.ideal} W</b> (realno {pot.realistic} W, +{pot.gainPct} % pri {pot.hours} h/teden).</>}
        </div>) : null })()}
      {(status || g.projectedWkg) && (
        <div style={{ fontSize: 12.5, marginTop: 8, color: 'var(--ink-2)' }}>
          {status && <><b style={{ color: status.c }}>{status.t}</b> — danes bi bil po načrtu pri {f2(g.expected!.wkg!)} W/kg ({g.expected!.ftp} W, {g.expected!.weight} kg). </>}
          {g.projectedWkg ? <>Napoved iz testov in teže: <b style={{ color: 'var(--ink)' }}>{f2(g.projectedWkg)} W/kg</b> na dan dirke.</> : null}
        </div>
      )}
      {cx.structured && <div className="muted" style={{ fontSize: 12, marginTop: 8 }}>{cx.phaseName}{cx.total ? ` · teden ${cx.week}/${cx.total}` : ''}{cx.recovery ? ' · razbremenilni' : ''}{cx.test ? ' · test FTP' : ''} · {String(cx.hours).replace('.', ',')} h ta teden</div>}
      {full && ms.length > 0 && (
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12.5, marginTop: 12 }}>
          <thead><tr style={{ color: 'var(--ink-3)', fontSize: 11 }}><th style={{ textAlign: 'left', padding: '4px 0' }}>mejnik</th><th style={{ textAlign: 'right' }}>teža</th><th style={{ textAlign: 'right' }}>FTP</th><th style={{ textAlign: 'right' }}>W/kg</th></tr></thead>
          <tbody>
            {g.start && <tr style={{ borderTop: '1px solid var(--line)' }}><td style={{ padding: '6px 0' }}>izhodišče <span className="muted">{MON[+g.start.date.slice(5, 7) - 1]} {g.start.date.slice(2, 4)}</span></td><td style={{ textAlign: 'right' }}>{g.start.weightKg ?? '—'}</td><td style={{ textAlign: 'right' }}>{g.start.ftp ?? '—'}</td><td style={{ textAlign: 'right' }}>{g.startWkg ? f2(g.startWkg) : '—'}</td></tr>}
            {ms.map(m => { const past = m.date <= today; return (
              <tr key={m.label} style={{ borderTop: '1px solid var(--line)', fontWeight: m.label === g.event!.name ? 800 : 500 }}>
                <td style={{ padding: '6px 0' }}>{m.label} <span className="muted">{MON[+m.date.slice(5, 7) - 1]} {m.date.slice(2, 4)}</span>{past ? ' ✓' : ''}</td>
                <td style={{ textAlign: 'right' }}>{m.weight ?? '—'}</td><td style={{ textAlign: 'right' }}>{m.ftp ?? '—'}</td><td style={{ textAlign: 'right', color: m.label === g.event!.name ? 'var(--accent)' : undefined }}>{m.wkg ? f2(m.wkg) : '—'}</td>
              </tr>) })}
          </tbody>
        </table>
      )}
      {full && ms.length > 0 && <p className="muted" style={{ fontSize: 11.5, marginTop: 8 }}>Idealen scenarij: brez bolezni in poškodb, {potH ? `povprečno ${String(potH).replace('.', ',')} h na teden čez sezono${fullAt && p.hoursPerWeek ? ` (začetek ${String(rampStart(p) ?? 4).replace('.', ',')} h, ${p.hoursPerWeek} h od ${+fullAt.slice(8)}. ${+fullAt.slice(5, 7)}.)` : ''}` : '12–14 h na teden'}, spanec, gorivo. Vati rastejo najhitreje v gradnji, teža pada večinoma v osnovi. Pod ~0,5 kg na teden, sicer gredo vati.</p>}
      <div className="row" style={{ gap: 8, marginTop: 10 }}>
        <Btn ghost sm onClick={() => setOpen(true)}>Uredi cilj</Btn>
        <Btn ghost sm onClick={() => setGuide(true)}>Kako deluje</Btn>
        {!full && <span className="muted" style={{ fontSize: 11.5 }}>{fd(g.event.date)}</span>}
      </div>
    </Card>
    {open && <GoalSheet open onClose={() => setOpen(false)} />}
    {guide && <Guide open onClose={() => setGuide(false)} />}
  </>)
}
