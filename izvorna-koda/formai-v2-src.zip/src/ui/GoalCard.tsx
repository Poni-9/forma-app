import { useState } from 'react'
import { navigate } from '@/app/router'
import { useApp } from '@/state/store'
import { goalStatus, levelOf, milestones, ftpPotential, raceWeightOf, fullHoursWeek, rampStart } from '@/domain/training/goal'
import { Guide } from '@/ui/Guide'
import { weekContext } from '@/domain/training/planner'
import { addDays, weekStartIso } from '@/domain/training/load'
import { Card, Btn } from '@/ui/primitives'
import { GoalSheet } from '@/ui/GoalSheet'
import { count, dec, dmy, num, unit, W } from '@/ui/format'
import { IcoCheck } from '@/ui/icons'

const f2 = (x: number) => dec(x, 2)
const kgf = (x: number | null) => (x == null ? '—' : num(x))
const MON = ['jan', 'feb', 'mar', 'apr', 'maj', 'jun', 'jul', 'avg', 'sep', 'okt', 'nov', 'dec']

/** Pot do cilja: odštevanje, W/kg zdaj → cilj, ali si na poti, raven. Brez cilja: poziv, da ga nastaviš. */
export function GoalCard({ full = false, compact = false }: { full?: boolean; compact?: boolean }) {
  const app = useApp()
  const { profile: p, checkins, today, settings } = app
  const [open, setOpen] = useState(false)
  const [guide, setGuide] = useState(false)
  const g = goalStatus(p, checkins, settings.tests || [], today)
  const cx = weekContext(p, weekStartIso(today))
  const fd = (iso: string) => dmy(iso, today)
  // brez FTP: kdaj je prvi test (v načrtu ali po tednih naprej)
  const nextTest = app.plan.filter(d => (d.role === 'test' || d.kind === 'test') && d.date >= today).sort((a, b) => a.date.localeCompare(b.date))[0]
  const testWeek = !p.ftp && !nextTest ? Array.from({ length: 13 }, (_, k) => addDays(weekStartIso(today), 7 * k)).find(w => weekContext(p, w).test) ?? null : null

  if (!g.event) {
    // Franja kot predlog samo za tekmovalne cilje (hitrejši, dirka); pri hujšanju ali formi brez vsiljevanja dirke
    const race = !p.goal || p.goal === 'dirka' || p.goal === 'hitrejsi'
    if (!race && !full) return null
    return (<>
      <Card accent={race} style={{ marginTop: full ? 0 : 12 }}>
        <h2 className="h4" style={{ margin: 0 }}>{race ? 'Cilj sezone' : 'Cilj z datumom'}</h2>
        <p style={{ fontSize: 13, marginTop: 6 }}>{race
          ? 'Na primer Maraton Franja, 13. 6. 2027 (156 km). Vpiši dirko in težo (FTP, če ga veš) — najboljšo težo in največji možni FTP izračunam sam, potem načrt, prehrana in AI trener delajo za ta cilj.'
          : 'Imaš tekmo, pohod ali drug cilj z datumom? Dodaj ga — načrt se mu prilagodi. Brez njega teče ponavljajoč se cikel.'}</p>
        <Btn sm style={{ marginTop: 10 }} onClick={() => setOpen(true)}>{race ? 'Nastavi cilj' : 'Dodaj cilj'}</Btn>
      </Card>
      {open && <GoalSheet open onClose={() => setOpen(false)} />}
    </>)
  }

  // cilj je mimo: »končano« in poziv za nov cilj ali off-season (ne »danes« za vedno)
  if (g.event.date < today) return (<>
    <Card style={{ marginTop: full ? 0 : 12 }}>
      <div className="between">
        <h2 className="h4" style={{ margin: 0, minWidth: 0 }}>{g.event.name}{g.event.distanceKm ? ` · ${unit(num(g.event.distanceKm), 'km')}` : ''}</h2>
        <span style={{ fontSize: 12, fontWeight: 800, color: 'var(--ok)', flex: 'none', display: 'inline-flex', alignItems: 'center', gap: 4 }}><IcoCheck width={13} height={13} aria-hidden="true" />končano</span>
      </div>
      <p style={{ fontSize: 13, marginTop: 8 }}>Cilj je za tabo ({fd(g.event.date)}). Nastavi naslednjega — ali si privošči off-season: nekaj tednov počitka in vožnje po občutku (hribe ali druge športe izbereš sam), nato nova osnova.</p>
      <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
        <Btn sm onClick={() => setOpen(true)}>Nov cilj</Btn>
        <Btn ghost sm onClick={() => navigate('plan')}>Off-season v Planu</Btn>
      </div>
    </Card>
    {open && <GoalSheet open onClose={() => setOpen(false)} />}
  </>)

  const lv = levelOf(g.wkg), tl = levelOf(g.targetWkg)
  const from = g.startWkg ?? g.wkg
  const pct = g.wkg && g.targetWkg && from != null && g.targetWkg > from ? ((g.wkg - from) / (g.targetWkg - from)) * 100 : 0
  const diff = g.wkg && g.expected?.wkg ? g.wkg - g.expected.wkg : null
  const status = diff == null ? null : diff >= 0.03 ? { t: 'pred načrtom', c: 'var(--ok)' } : diff <= -0.08 ? { t: 'za načrtom', c: 'var(--warn)' } : { t: 'na poti', c: 'var(--ok)' }
  const ms = full ? milestones(p) : []
  const potH = full ? ftpPotential(p, today)?.hours ?? null : null
  const fullAt = full ? fullHoursWeek(p, today) : null
  const left = g.daysToEvent != null && g.daysToEvent > 13 ? `še ${count(g.weeksToEvent ?? 0, W.teden)}` : g.daysToEvent ? `še ${count(g.daysToEvent, W.dan)}` : 'danes'

  // Danes: ena kartica v eni potezi — kje si in koliko do cilja; podrobno (mejniki, teža, FTP) je v Napredku
  if (compact) return (
    <button type="button" className="card tight goal-mini" onClick={() => navigate('napredek')} aria-label={`${g.event.name}, ${left} — podrobno v Napredku`}>
      <span className="between" style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
        <b style={{ fontSize: 13.5, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{g.event.name}</b>
        <span style={{ fontSize: 12, fontWeight: 800, color: 'var(--accent)', flex: 'none' }}>{left}</span>
      </span>
      {g.ftp && g.wkg && g.targetWkg ? (<>
        <span className="muted" style={{ display: 'block', fontSize: 12.5, marginTop: 4 }}>Moč na kilogram: zdaj <b style={{ color: 'var(--ink)' }}>{f2(g.wkg)}</b>, cilj <b style={{ color: 'var(--accent)' }}>{f2(g.targetWkg)}</b> W/kg{status ? <> · <span style={{ color: status.c, fontWeight: 700 }}>{status.t}</span></> : null}</span>
        <span className="goalbar" style={{ display: 'block', marginTop: 10 }} aria-hidden="true"><i style={{ width: `${Math.max(3, Math.min(100, pct))}%` }} /></span>
      </>) : (
        <span className="muted" style={{ display: 'block', fontSize: 12.5, marginTop: 4 }}>{nextTest ? `Moč (FTP) izmeriš s testom ${fd(nextTest.date)} — potem pokažem pot do cilja.` : 'Moč (FTP) še ne poznam — potem pokažem pot do cilja.'}</span>
      )}
    </button>
  )

  return (<>
    <Card style={{ marginTop: full ? 0 : 12 }}>
      <div className="between" style={{ alignItems: 'baseline' }}>
        <h2 className="h4" style={{ margin: 0, minWidth: 0 }}>{g.event.name}{g.event.distanceKm ? ` · ${unit(num(g.event.distanceKm), 'km')}` : ''}</h2>
        <span style={{ fontSize: 12, fontWeight: 800, color: 'var(--accent)', flex: 'none' }}>{left}</span>
      </div>
      {/* datum dirke in kje v sezoni si — ena vrstica pod naslovom (namesto na dnu kartice in ob gumbih) */}
      <div className="muted" style={{ fontSize: 12, fontWeight: 600, marginTop: 3 }}>{fd(g.event.date)}{cx.structured ? ` · ${cx.phaseName}${cx.total ? `, teden ${cx.week}/${cx.total}` : ''}${cx.recovery ? ' · razbremenilni' : ''}${cx.test ? ' · test FTP' : ''} · ${unit(num(cx.hours), 'h')} ta teden` : ''}</div>
      {!g.ftp ? (
        <div style={{ fontSize: 13, marginTop: 8, color: 'var(--ink-2)' }}>
          FTP še ne poznam — izmeriš ga z 20-minutnim testom{nextTest ? <>, ki je v načrtu <b style={{ color: 'var(--ink)' }}>{fd(nextTest.date)}</b></> : testWeek ? <> v tednu od <b style={{ color: 'var(--ink)' }}>{fd(testWeek)}</b> (po lahkem začetku)</> : ' (Napredek → Vpiši test)'}. Takrat pokažem W/kg zdaj in na dan tekme{g.targetWeight ? `; najboljša teža zate ~${unit(kgf(g.targetWeight), 'kg')}` : ''}.
        </div>
      ) : (<>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, alignItems: 'end', marginTop: 12 }}>
        <div>
          <div style={{ fontSize: 36, fontWeight: 800, letterSpacing: '-.04em', lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>{g.wkg ? f2(g.wkg) : '—'}</div>
          <div className="muted" style={{ fontSize: 10.5, fontWeight: 800, letterSpacing: '.06em', marginTop: 4 }}>W/KG ZDAJ</div>
          {lv && <div className="muted" style={{ fontSize: 12, fontWeight: 600 }}>{lv.name}</div>}
        </div>
        <div style={{ textAlign: 'right' }}>
          <div className="grad-text" style={{ fontSize: 36, fontWeight: 800, letterSpacing: '-.04em', lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>{g.targetWkg ? f2(g.targetWkg) : '—'}</div>
          <div className="muted" style={{ fontSize: 10.5, fontWeight: 800, letterSpacing: '.06em', marginTop: 4 }}>CILJ</div>
          {tl && <div className="muted" style={{ fontSize: 12, fontWeight: 600 }}>{tl.name}</div>}
        </div>
      </div>
      {/* pot od izhodišča do cilja: gumb pokaže, kje si (na začetku ob levem robu) */}
      <div className="goalbar" style={{ marginTop: 12 }} role="img" aria-label={`${Math.round(Math.max(0, Math.min(100, pct)))}\u00a0% poti do cilja`}><i style={{ width: `${Math.max(3, Math.min(100, pct))}%` }} /></div>
      <div className="between muted" style={{ fontSize: 12, marginTop: 6, fontWeight: 600 }}>
        <span>{g.ftp != null ? unit(g.ftp, 'W') : '—'} · {unit(kgf(g.weight), 'kg')}</span>
        <span>{g.targetFtp != null ? unit(g.targetFtp, 'W') : '—'} · {unit(kgf(g.targetWeight), 'kg')}</span>
      </div>
      </>)}
      {full && (() => { const rw = raceWeightOf(p, today), pot = ftpPotential(p, today); return (rw || pot) ? (
        <div style={{ fontSize: 12.5, marginTop: 8, color: 'var(--ink-2)' }}>
          {rw && <>Najboljša teža zate <b style={{ color: 'var(--ink)' }}>{unit(dec(rw.kg, 1), 'kg')}</b> ({rw.measured ? 'maščoba' : 'ocena maščobe iz BMI'} ~{unit(Math.round(rw.bf), '%')} → ~{unit(num(rw.targetBf), '%')}). </>}
          {pot && <>Največji možni FTP do dirke <b style={{ color: 'var(--ink)' }}>{unit(pot.ideal, 'W')}</b> (realno {unit(pot.realistic, 'W')}, +{unit(num(pot.gainPct), '%')} pri {unit(num(pot.hours), 'h')}/teden).</>}
        </div>) : null })()}
      {(status || g.projectedWkg) && (
        <div style={{ fontSize: 12.5, marginTop: 8, color: 'var(--ink-2)' }}>
          {status && <><b style={{ color: status.c }}>{status.t}</b> — danes bi bil po načrtu pri {f2(g.expected!.wkg!)} W/kg ({g.expected!.ftp != null ? unit(g.expected!.ftp, 'W') : '—'}, {unit(kgf(g.expected!.weight), 'kg')}). </>}
          {g.projectedWkg ? <>Napoved iz testov in teže: <b style={{ color: 'var(--ink)' }}>{f2(g.projectedWkg)} W/kg</b> na dan dirke.</> : null}
        </div>
      )}
      {full && ms.length > 0 && (
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12.5, marginTop: 12 }}>
          <thead><tr style={{ color: 'var(--ink-3)', fontSize: 11 }}><th style={{ textAlign: 'left', padding: '4px 0' }}>mejnik</th><th style={{ textAlign: 'right' }}>teža</th><th style={{ textAlign: 'right' }}>FTP</th><th style={{ textAlign: 'right' }}>W/kg</th></tr></thead>
          <tbody>
            {g.start && <tr style={{ borderTop: '1px solid var(--line)' }}><td style={{ padding: '6px 0' }}>izhodišče <span className="muted">{MON[+g.start.date.slice(5, 7) - 1]} {g.start.date.slice(2, 4)}</span></td><td style={{ textAlign: 'right' }}>{kgf(g.start.weightKg)}</td><td style={{ textAlign: 'right' }}>{g.start.ftp ?? '—'}</td><td style={{ textAlign: 'right' }}>{g.startWkg ? f2(g.startWkg) : '—'}</td></tr>}
            {ms.map(m => { const past = m.date <= today; return (
              <tr key={m.label} style={{ borderTop: '1px solid var(--line)', fontWeight: m.label === g.event!.name ? 800 : 500 }}>
                <td style={{ padding: '6px 0' }}>{m.label} <span className="muted">{MON[+m.date.slice(5, 7) - 1]} {m.date.slice(2, 4)}</span>{past ? <IcoCheck width={12} height={12} aria-label="doseženo" style={{ marginLeft: 4, verticalAlign: -1, color: 'var(--ok)' }} /> : null}</td>
                <td style={{ textAlign: 'right' }}>{kgf(m.weight ?? null)}</td><td style={{ textAlign: 'right' }}>{m.ftp ?? '—'}</td><td style={{ textAlign: 'right', color: m.label === g.event!.name ? 'var(--accent)' : undefined }}>{m.wkg ? f2(m.wkg) : '—'}</td>
              </tr>) })}
          </tbody>
        </table>
      )}
      {full && ms.length > 0 && <p className="muted" style={{ fontSize: 11.5, marginTop: 8 }}>Idealen scenarij: brez bolezni in poškodb, {potH ? `povprečno ${unit(num(potH), 'h')} na teden čez sezono${fullAt && p.hoursPerWeek ? ` (začetek ${unit(num(rampStart(p) ?? 4), 'h')}, ${unit(num(p.hoursPerWeek), 'h')} od ${fd(fullAt)})` : ''}` : '12–14 h na teden'}, spanec, gorivo. Vati rastejo najhitreje v gradnji, teža pada večinoma v osnovi. Pod ~0,5 kg na teden, sicer gredo vati.</p>}
      <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
        <Btn ghost sm onClick={() => setOpen(true)}>Uredi cilj</Btn>
        <Btn ghost sm onClick={() => setGuide(true)}>Kako deluje</Btn>
      </div>
    </Card>
    {open && <GoalSheet open onClose={() => setOpen(false)} />}
    {guide && <Guide open onClose={() => setGuide(false)} />}
  </>)
}
