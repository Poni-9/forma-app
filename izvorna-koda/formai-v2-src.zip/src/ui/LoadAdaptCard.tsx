import { useMemo, useState } from 'react'
import { useApp, applyLoadAdapt, undoLoadAdaptOf, toast } from '@/state/store'
import { adaptAfterLoad } from '@/domain/training/planner'
import { addDays } from '@/domain/training/load'
import { Card, Btn } from '@/ui/primitives'
import { NBSP } from '@/ui/format'

/**
 * Po pretežki vožnji (npr. 3 h namesto 45 min regeneracije): koliko je bilo res, kaj to pomeni za dan za tem in gumb, ki ga
 * olajša (ključni trening gre na primeren lahki dan). Ko je že prilagojeno (samodejno ob uvozu z ure), »Vrni prvotni načrt«.
 */
export function LoadAdaptCard({ date, actionOnly = false }: { date: string; /** samo, ko je kaj za storiti (včerajšnja vožnja) */ actionOnly?: boolean }) {
  const app = useApp()
  const [busy, setBusy] = useState(false)
  const r = useMemo(() => adaptAfterLoad(app.profile, app.plan, app.activities, date, app.today), [app.profile, app.plan, app.activities, date, app.today])
  if (!r || (actionOnly && r.state !== 'predlog')) return null
  const watch = !!app.settings.intervals && app.settings.intervals.pushWorkouts !== false
  const next = addDays(date, 1) === app.today ? 'danes' : 'jutri'
  const title = date === app.today ? 'Po današnji vožnji' : 'Po včerajšnji vožnji'
  async function apply() {
    setBusy(true)
    const x = await applyLoadAdapt(date)
    setBusy(false)
    if (x?.state === 'predlog') toast(`Prilagojeno. ${x.text}`, 'ok', 7000)
  }
  async function undo() {
    setBusy(true)
    await undoLoadAdaptOf(date)
    setBusy(false)
    toast('Vrnjen prvotni načrt.', 'ok')
  }
  return (
    <Card tight className="adapt" style={{ marginTop: 8 }}>
      <div className="between" style={{ alignItems: 'baseline', gap: 10 }}>
        <h2 className="h4" style={{ margin: 0 }}>{title}</h2>
        <span className="muted" style={{ fontSize: 12, fontWeight: 700, flex: 'none' }}>{r.actual}{NBSP}TSS · načrt ~{r.planned}</span>
      </div>
      <p style={{ fontSize: 13.5, color: 'var(--ink)', marginTop: 6, lineHeight: 1.45 }}>{r.text}</p>
      {r.state === 'predlog' && (
        <div className="row" style={{ gap: 8, marginTop: 10 }}>
          <Btn primary sm disabled={busy} onClick={() => void apply()}>{next === 'danes' ? 'Olajšaj danes' : 'Prilagodi jutri'}</Btn>
          {watch && <span className="muted" style={{ fontSize: 11.5 }}>Trening na uri se posodobi sam.</span>}
        </div>
      )}
      {r.state === 'prilagojeno' && <button type="button" className="chip sm click" style={{ marginTop: 9 }} disabled={busy} onClick={() => void undo()}>Vrni prvotni načrt</button>}
    </Card>
  )
}
