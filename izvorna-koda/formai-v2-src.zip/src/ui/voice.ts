import { askText } from '@/domain/ai/client'

/**
 * GLAS → BESEDILO Z AI (Blaž, 14. 10.: »mikrofon dela v slovenščini zelo slabo … naj bo en dober AI za prepoznavo
 * glasu«). Posnetek (MediaRecorder) se pretvori v WAV 16 kHz mono in gre prek našega strežnika v Gemini, ki ga
 * dobesedno prepiše v slovenščino. Zvok se ne shrani nikjer — samo besedilo pride nazaj v polje.
 */
export const canRecord = (): boolean =>
  typeof window !== 'undefined' && typeof (window as unknown as { MediaRecorder?: unknown }).MediaRecorder === 'function' && !!navigator.mediaDevices?.getUserMedia

/** Posnetek (webm/opus, mp4/aac …) → WAV 16 kHz mono 16-bit (Gemini ga zanesljivo bere). */
export async function toWav16k(blob: Blob): Promise<string> {
  const AC = (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)
  const ctx = new AC()
  let buf: AudioBuffer
  try { buf = await ctx.decodeAudioData(await blob.arrayBuffer()) } finally { void ctx.close().catch(() => {}) }
  const rate = 16000
  const len = Math.max(1, Math.ceil(buf.duration * rate))
  const off = new OfflineAudioContext(1, len, rate)
  const src = off.createBufferSource()
  src.buffer = buf
  src.connect(off.destination)
  src.start()
  const out = (await off.startRendering()).getChannelData(0)
  const bytes = new ArrayBuffer(44 + out.length * 2)
  const v = new DataView(bytes)
  const str = (o: number, s: string) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)) }
  str(0, 'RIFF'); v.setUint32(4, 36 + out.length * 2, true); str(8, 'WAVE'); str(12, 'fmt ')
  v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true); v.setUint32(24, rate, true)
  v.setUint32(28, rate * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); str(36, 'data'); v.setUint32(40, out.length * 2, true)
  for (let i = 0; i < out.length; i++) { const x = Math.max(-1, Math.min(1, out[i]!)); v.setInt16(44 + i * 2, x < 0 ? x * 0x8000 : x * 0x7fff, true) }
  // base64 po kosih (velik niz naenkrat preseže sklad)
  const u8 = new Uint8Array(bytes)
  let bin = ''
  for (let i = 0; i < u8.length; i += 0x8000) bin += String.fromCharCode(...u8.subarray(i, i + 0x8000))
  return btoa(bin)
}

const PROMPT = [
  'Prepiši ta posnetek govora v SLOVENŠČINI dobesedno, s pravilnimi slovenskimi črkami (č, š, ž), ločili in velikimi začetnicami.',
  'Govorec pove, kaj si želi od trenerja ali kaj je jedel: fitnes, vadba doma, tek, kolo, hribi, dnevi v tednu, ure, minute, kilometri, kilogrami, hrana in količine.',
  'Številke piši s števkami (»3-krat na teden«, »45 min«, »200 g«). Ne dodajaj ničesar, česar ni rekel, in ne povzemaj.',
  'Vrni SAMO prepisano besedilo, brez narekovajev in pojasnil. Če na posnetku ni govora, vrni prazen odgovor.',
].join('\n')

/** WAV (base64) → besedilo. */
export async function transcribe(wavB64: string, hint?: string): Promise<string> {
  const t = await askText([{ text: hint ? `${PROMPT}\nKontekst polja: ${hint}` : PROMPT }, { inlineData: { mimeType: 'audio/wav', data: wavB64 } }], { temp: 0 })
  return t.replace(/^["»„“]+|["«“”]+$/g, '').replace(/\s+/g, ' ').trim()
}
