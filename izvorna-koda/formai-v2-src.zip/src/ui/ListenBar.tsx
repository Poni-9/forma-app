import { useEffect, useRef } from 'react'

/**
 * Vidno, da mikrofon posluša (Blaž, 13. 10.: »nikjer ni pikic, da bi vedel, ali dela«): utripajoči stolpci in besedilo
 * pod poljem, dokler narekovanje teče. Besedilo, ki ga sliši, se sproti piše v polje. Ob začetku se vrstica pomakne
 * v pogled (na telefonu je bila pod robom zaslona).
 */
export function ListenBar({ listening, onStop, value }: { listening: boolean; onStop?: () => void; /** besedilo polja: ko raste, vrstica ostane v pogledu */ value?: string }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!listening) return
    const calm = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
    ref.current?.scrollIntoView?.({ block: 'nearest', behavior: calm ? 'auto' : 'smooth' })
  }, [listening, value])
  if (!listening) return null
  return (
    <div ref={ref} className="listen-bar" role="status" aria-live="polite">
      <span className="listen-eq" aria-hidden="true"><i /><i /><i /><i /><i /></span>
      <span>Poslušam … govori</span>
      {onStop && <button type="button" className="chip sm click" onClick={onStop}>končaj</button>}
    </div>
  )
}
