import { useEffect, useRef, useState } from 'react'

/**
 * Vidno, da mikrofon posluša (Blaž, 13. 10.: »nikjer ni pikic, da bi vedel, ali dela«): stolpci in besedilo pod
 * poljem, dokler narekovanje teče. Z AI prepisom (14. 10.) stolpci sledijo glasnosti govora, teče čas, po koncu
 * »Pretvarjam govor v besedilo …«. Ob začetku se vrstica pomakne v pogled (na telefonu je bila pod robom zaslona).
 */
export function ListenBar({ listening, onStop, value, transcribing, level }: { listening: boolean; onStop?: () => void; /** besedilo polja: ko raste, vrstica ostane v pogledu */ value?: string; /** AI prepisuje posnetek */ transcribing?: boolean; /** glasnost 0–1 (AI snemanje) */ level?: number }) {
  const ref = useRef<HTMLDivElement>(null)
  const [t0, setT0] = useState(0)
  const [, tick] = useState(0)
  useEffect(() => {
    if (!listening && !transcribing) return
    const calm = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
    ref.current?.scrollIntoView?.({ block: 'nearest', behavior: calm ? 'auto' : 'smooth' })
  }, [listening, transcribing, value])
  useEffect(() => {
    if (!listening) return
    setT0(Date.now())
    const id = window.setInterval(() => tick(x => x + 1), 1000)
    return () => clearInterval(id)
  }, [listening])
  if (!listening && !transcribing) return null
  const live = level != null && listening
  const sec = t0 ? Math.floor((Date.now() - t0) / 1000) : 0
  return (
    <div ref={ref} className={`listen-bar${transcribing ? ' busy' : ''}`} role="status" aria-live="polite">
      {transcribing
        ? <span className="thinking" aria-hidden="true"><i /><i /><i /></span>
        : <span className={`listen-eq${live ? ' live' : ''}`} aria-hidden="true">{[0.55, 0.85, 1, 0.8, 0.6].map((k, i) => <i key={i} style={live ? { transform: `scaleY(${Math.max(0.18, Math.min(1, (level ?? 0) * k * 1.6))})` } : undefined} />)}</span>}
      <span>{transcribing ? 'Pretvarjam govor v besedilo …' : live ? <>Poslušam … govori <span className="listen-t" aria-hidden="true">{Math.floor(sec / 60)}:{String(sec % 60).padStart(2, '0')}</span></> : 'Poslušam … govori'}</span>
      {onStop && listening && <button type="button" className="chip sm click" onClick={onStop}>končaj</button>}
    </div>
  )
}
