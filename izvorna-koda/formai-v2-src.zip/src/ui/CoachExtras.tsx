import { useMemo } from 'react'
import { navigate } from '@/app/router'
import type { Profile } from '@/domain/types'
import { bodyFatView, scalePos } from '@/domain/coach/bodyfat'
import { exercisesIn } from '@/domain/coach/exmention'
import { ExercisePhoto } from '@/ui/figure/ExercisePhoto'
import { rem } from '@/ui/rem'

const pct = (x: number) => String(Math.round(x))

/**
 * (v3.49) Lestvica telesne maščobe pod odgovorom trenerja na vprašanje o videzu — narisana (CSS), brez slik z interneta
 * in brez AI. Zdaj (ocena ali vpisano), kje se obrisi trebuha tipično pokažejo, okvirni čas kot razpon in merljivi koraki.
 */
export function BodyFatCard({ profile, weightKg, ask }: { profile: Profile; weightKg: number | null; /** (v3.50) vprašanje — pas ali trebušne mišice */ ask?: string }) {
  const v = useMemo(() => bodyFatView(profile, weightKg, ask), [profile, weightKg, ask])
  if (v.kind !== 'scale') return <div className="coach-x bf-card"><p className="muted" style={{ margin: 0 }}>{v.text}</p></div>
  const n = v.bands.length
  const pos = v.now ? scalePos(v.now.pct, v.bands, v.top) : null
  const inT = (lo: number) => lo >= v.target.lo && lo < v.target.hi
  const cur = v.now ? v.bands.findIndex((b, i) => v.now!.pct < (b.hi ?? Infinity) || i === n - 1) : -1
  // oznaka »zdaj« ob robu ne gre čez kartico
  const shift = pos == null ? '' : pos < 0.14 ? 'translateX(-6px)' : pos > 0.86 ? 'translateX(calc(-100% + 6px))' : 'translateX(-50%)'
  return (
    <div className="coach-x bf-card" role="group" aria-label="Lestvica telesne maščobe">
      <div className="between" style={{ gap: 8 }}><b>Telesna maščoba — kaj se tipično vidi</b><span className="muted" style={{ fontSize: rem(11.5) }}>{v.sex === 'm' ? 'moški' : 'ženske'}</span></div>
      <div className="bf-scale" aria-hidden="true">
        {pos != null && <><span className="bf-pin" style={{ left: `${pos * 100}%`, transform: shift }}>zdaj</span><i className="bf-tick" style={{ left: `${pos * 100}%` }} /></>}
        <div className="bf-bar">{v.bands.map(b => <span key={b.lo} className={`bf-seg${inT(b.lo) ? ' tgt' : ''}`} />)}</div>
        <div className="bf-ticks">{v.bands.map(b => <span key={b.lo}>{b.hi == null ? `>${b.lo}` : `${b.lo}–${b.hi}`}</span>)}</div>
      </div>
      <div className="bf-leg">
        {v.now && <span><i className="bf-k now" />zdaj ~{pct(v.now.pct)} % ({v.now.measured ? 'vpisano' : 'ocena'})</span>}
        <span><i className="bf-k tgt" />cilj ~{v.target.lo}–{v.target.hi} %</span>
      </div>
      <ul className="bf-see">
        {v.bands.map((b, i) => <li key={b.lo} className={inT(b.lo) ? 'tgt' : i === cur ? 'cur' : ''}><b>{b.label}</b> {b.see}</li>)}
      </ul>
      {v.lines.map((l, i) => <p key={i} className={i ? 'muted' : ''}>{l}</p>)}
      <div className="bf-steps"><b>Kaj meriš</b><ul>{v.steps.map(s => <li key={s}>{s}</li>)}</ul></div>
    </div>
  )
}

/** (v3.49) Vaje iz knjižnice, ki jih omenja odgovor: do 3 ploščice; dotik odpre vajo v Vajah. Slike se naložijo leno. */
export function CoachExercises({ text }: { text: string }) {
  const list = useMemo(() => exercisesIn(text, 3), [text])
  if (!list.length) return null
  return (
    <div className="coach-x coach-ex" role="group" aria-label="Vaje iz odgovora">
      {list.map(e => (
        <button key={e.id} type="button" className="card vaja-tile coach-ex-t" onClick={() => navigate('vaje', { v: e.id })} aria-label={`${e.name} — kako se izvaja`}>
          <ExercisePhoto id={e.id} size={92} label={e.name} playing={false} />
          <b>{e.name}</b>
        </button>
      ))}
    </div>
  )
}
