import { useState } from 'react'
import { useApp, saveRaces, toast } from '@/state/store'
import type { Race } from '@/domain/types'
import { Btn, Card, Chip, Sheet } from '@/ui/primitives'

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
const dshort = (iso: string) => `${+iso.slice(8)}. ${+iso.slice(5, 7)}.${iso.slice(0, 4) !== new Date().getFullYear().toString() ? ` ${iso.slice(0, 4)}` : ''}`
const PRIO: Record<Race['prio'], { l: string; d: string }> = {
  B: { l: 'Pomembna', d: 'Dva dni prej brez trdega, dan prej samo predaktivacija, teden −20 %, dan po lahko.' },
  C: { l: 'Za trening', d: 'Brez počitka pred njo — nadomesti ključni trening tedna; dan prej in dan po lahko.' },
}

/**
 * Tekme sezone: glavni cilj (Cilj sezone) + druge tekme, ki jih dodaš kadarkoli. Načrt se jim prilagodi:
 * nikoli trd trening dan pred tekmo, dan po lahko; ta in naslednji teden takoj, kasnejši, ko pridejo na vrsto.
 */
export function RacesCard() {
  const app = useApp()
  const p = app.profile
  const [open, setOpen] = useState(false)
  const races = (p.races || []).slice().sort((a, b) => a.date.localeCompare(b.date))
  const up = races.filter(r => r.date >= app.today), past = races.filter(r => r.date < app.today)
  async function remove(r: Race) {
    if (!confirm(`Odstranim tekmo »${r.name}«?`)) return
    await saveRaces(races.filter(x => x.id !== r.id))
    toast('Tekma odstranjena — ta in naslednji teden sta sestavljena znova.', 'ok')
  }
  return (<>
    <Card tight style={{ marginBottom: 12 }}>
      <div className="between"><b style={{ fontSize: 13 }}>Tekme v sezoni</b><button className="chip sm click" onClick={() => setOpen(true)}>+ dodaj tekmo</button></div>
      <div className="stack" style={{ gap: 0, marginTop: 6 }}>
        {p.event?.date && <div className="between" style={{ padding: '7px 0', fontSize: 13 }}><span><b style={{ color: 'var(--ink)' }}>{p.event.name}</b>{p.event.distanceKm ? ` · ${p.event.distanceKm} km` : ''}</span><span className="row" style={{ gap: 6 }}><span className="muted" style={{ fontWeight: 700 }}>{dshort(p.event.date)}</span><Chip sm on>glavni cilj</Chip></span></div>}
        {up.map(r => (
          <div key={r.id} className="between" style={{ padding: '7px 0', fontSize: 13, borderTop: '1px solid var(--line)' }}>
            <span style={{ minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}><b style={{ color: 'var(--ink)' }}>{r.name}</b>{r.distanceKm ? ` · ${r.distanceKm} km` : ''}</span>
            <span className="row" style={{ gap: 6, flex: 'none' }}><span className="muted" style={{ fontWeight: 700 }}>{dshort(r.date)}</span><Chip sm>{PRIO[r.prio].l.toLowerCase()}</Chip><button className="chip sm click" aria-label={`Odstrani ${r.name}`} onClick={() => remove(r)}>×</button></span>
          </div>
        ))}
        {!up.length && <p className="muted" style={{ fontSize: 12, marginTop: 4 }}>Dodaj tekme med sezono (tudi čez vikend) — načrt poskrbi, da pred njimi nisi utrujen.</p>}
        {past.length > 0 && <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>Mimo: {past.map(r => `${r.name} (${dshort(r.date)})`).join(', ')}</div>}
      </div>
    </Card>
    {open && <RaceSheet onClose={() => setOpen(false)} />}
  </>)
}

function RaceSheet({ onClose }: { onClose: () => void }) {
  const app = useApp()
  const [f, setF] = useState({ name: '', date: '', km: '', prio: 'C' as Race['prio'] })
  async function save() {
    if (!f.name.trim() || !f.date) { toast('Vpiši ime in datum tekme.', 'err'); return }
    if (f.date < app.today) { toast('Datum mora biti danes ali kasneje.', 'err'); return }
    if (app.profile.event?.date === f.date) { toast('Na ta dan je glavni cilj — ta že ima svoj teden dirke.', 'err'); return }
    const km = f.km.trim() ? Math.max(1, Math.min(400, Math.round(+f.km.replace(',', '.')))) : null
    const r: Race = { id: uid(), name: f.name.trim().slice(0, 60), date: f.date, distanceKm: km, prio: f.prio }
    await saveRaces([...(app.profile.races || []), r])
    const days = Math.round((new Date(f.date).getTime() - new Date(app.today).getTime()) / 86400_000)
    toast(days <= 13 ? `${r.name} dodana — načrt je že prilagojen (dan prej predaktivacija, dan po lahko).` : `${r.name} dodana — teden tekme se prilagodi, ko pride na vrsto.`, 'ok', 7000)
    onClose()
  }
  return (
    <Sheet open onClose={onClose}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Dodaj tekmo</b>
      <p style={{ fontSize: 12.5, marginTop: 4 }}>Glavni cilj ostane {app.profile.event?.name || 'cilj sezone'}. Pred to tekmo ne bo trdega treninga, dan po njej bo lahek.</p>
      <div className="stack" style={{ gap: 10, marginTop: 12 }}>
        <div className="field"><label>Tekma</label><input value={f.name} onChange={e => setF({ ...f, name: e.target.value })} placeholder="npr. Maraton Treh src" autoFocus /></div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div className="field"><label>Datum</label><input type="date" min={app.today} value={f.date} onChange={e => setF({ ...f, date: e.target.value })} /></div>
          <div className="field"><label>Dolžina <span className="unit">km, če veš</span></label><input type="number" inputMode="numeric" value={f.km} onChange={e => setF({ ...f, km: e.target.value })} /></div>
        </div>
        <div className="field"><label>Kako pomembna</label>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>{(['B', 'C'] as const).map(k => <Chip key={k} sm on={f.prio === k} onClick={() => setF({ ...f, prio: k })}>{PRIO[k].l}</Chip>)}</div>
          <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>{PRIO[f.prio].d}</div>
        </div>
      </div>
      <Btn primary block style={{ marginTop: 14 }} onClick={save}>Dodaj in prilagodi načrt</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Prekliči</Btn>
    </Sheet>
  )
}
