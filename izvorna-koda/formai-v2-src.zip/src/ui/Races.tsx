import { useState } from 'react'
import { useApp, saveRaces, saveMainGoal, startOffSeason, declineOffSeason, endOffSeason, toast } from '@/state/store'
import type { Race, RaceType } from '@/domain/types'
import { RACE_TYPES, raceTypeOf, raceDemand, peakOf } from '@/domain/training/season'
import { weekContext } from '@/domain/training/planner'
import { addDays, fmtDur, weekStartIso } from '@/domain/training/load'
import { Btn, Card, Chip, Sheet } from '@/ui/primitives'
import { DateField } from '@/ui/DateField'

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
const dshort = (iso: string) => `${+iso.slice(8)}. ${+iso.slice(5, 7)}.${iso.slice(0, 4) !== new Date().getFullYear().toString() ? ` ${iso.slice(0, 4)}` : ''}`
const PRIO: Record<Race['prio'], { l: string; s: string; d: string }> = {
  A: { l: 'Cilj sezone', s: 'cilj A', d: 'Hočem biti najboljši: pred njo specifičen blok za to vrsto dirke in tapering, po njej teden lahko.' },
  B: { l: 'Pomembna', s: 'pomembna', d: 'Dva dni prej brez trdega, dan prej samo predaktivacija, teden −20 %, dan po lahko.' },
  C: { l: 'Za trening', s: 'za trening', d: 'Brez počitka pred njo — nadomesti ključni trening tedna; dan prej in dan po lahko.' },
}
const TYPES = Object.keys(RACE_TYPES) as RaceType[]
const dots = (n: number) => '●'.repeat(n) + '○'.repeat(5 - n)
type Editing = { kind: 'new' } | { kind: 'race'; race: Race } | { kind: 'main' }

/**
 * Cilji in tekme sezone: glavni cilj + drugi cilji A (vsak svoj vrh forme) + tekme B in C. Pri vsaki vrsta dirke,
 * dolžina, vzpon in rang → načrt pred njo trenira to, kar na njej odloča (klanci, šprint, ravnina, dolžina).
 */
export function RacesCard() {
  const app = useApp()
  const p = app.profile
  const [edit, setEdit] = useState<Editing | null>(null)
  const [off, setOff] = useState(false)
  const [all, setAll] = useState(false)
  const races = (p.races || []).slice().sort((a, b) => a.date.localeCompare(b.date))
  const up = races.filter(r => r.date >= app.today), past = races.filter(r => r.date < app.today)
  const ev = p.event?.date ? p.event : null
  const cx = weekContext(p, weekStartIso(app.today))
  // konec sezone? zadnja tekma v zadnjih 6 tednih, naslednje v 4 tednih ni, še nismo vprašali (ali pred več kot mesecem)
  const lastPast = [...past, ...(ev && ev.date < app.today ? [{ ...ev, id: 'main', prio: 'A' as const }] : [])].sort((a, b) => b.date.localeCompare(a.date))[0]
  const soon = [...up, ...(ev && ev.date >= app.today ? [ev] : [])].some(r => r.date <= addDays(app.today, 28))
  const asked = p.offSeasonAskedAt && p.offSeasonAskedAt > addDays(app.today, -30)
  const ask = cx.phase !== 'prehod' && !!lastPast && lastPast.date >= addDays(app.today, -42) && !soon && !asked
  async function remove(r: Race) {
    if (!confirm(`Odstranim tekmo »${r.name}«?`)) return
    await saveRaces(races.filter(x => x.id !== r.id))
    toast('Tekma odstranjena — ta in naslednji teden sta sestavljena znova.', 'ok')
  }
  const row = (name: string, date: string, r: { distanceKm?: number | null; elevM?: number | null; type?: RaceType | null; level?: 'amater' | 'visji' | null }, tag: string, strong: boolean, onEdit: () => void, onRemove?: () => void) => {
    const d = raceDemand({ name, ...r }), t = raceTypeOf({ name, ...r })
    return (
      <div key={name + date} style={{ padding: '8px 0', borderTop: '1px solid var(--line)', cursor: 'pointer' }} onClick={onEdit}>
        <div className="between" style={{ fontSize: 13, gap: 8 }}>
          <span style={{ minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}><b style={{ color: 'var(--ink)' }}>{name}</b></span>
          <span className="row" style={{ gap: 6, flex: 'none' }}>
            <span className="muted" style={{ fontWeight: 700 }}>{dshort(date)}</span>
            <Chip sm on={strong}>{tag}</Chip>
            {onRemove && <button className="chip sm click" aria-label={`Odstrani ${name}`} onClick={e => { e.stopPropagation(); void onRemove() }}>×</button>}
          </span>
        </div>
        <div className="muted" style={{ fontSize: 11.5, marginTop: 2 }}>{RACE_TYPES[t].l}{r.distanceKm ? ` · ${r.distanceKm} km` : ''}{r.elevM ? ` · ${r.elevM} m` : ''}{r.level === 'visji' ? ' · višji rang' : ''} · ~{fmtDur(d.min)} · napornost <span style={{ letterSpacing: 1, color: 'var(--ink-2)' }}>{dots(d.stars)}</span></div>
      </div>
    )
  }
  // vse prihodnje: glavni cilj + tekme, po datumu; v kartici samo naslednje 3 (ena vrstica), vse v seznamu
  type Item = { key: string; name: string; date: string; r: Parameters<typeof raceDemand>[0]; tag: string; strong: boolean; edit: () => void; remove?: () => void; peak?: string | null }
  const items: Item[] = [
    ...(ev && ev.date >= app.today ? [{ key: 'main', name: ev.name, date: ev.date, r: ev, tag: 'glavni cilj', strong: true, edit: () => setEdit({ kind: 'main' }) }] : []),
    ...up.map(r => ({ key: r.id, name: r.name, date: r.date, r, tag: PRIO[r.prio].s, strong: r.prio === 'A', edit: () => setEdit({ kind: 'race', race: r }), remove: () => remove(r), peak: r.prio === 'A' ? peakOf(p, r.id)?.name ?? null : null })),
  ].sort((a, b) => a.date.localeCompare(b.date))
  const nA = items.filter(x => x.strong).length, shown = items.slice(0, 3)
  const nextA = items.find(x => x.strong)
  if (nextA && !shown.includes(nextA)) shown[shown.length - 1] = nextA
  const line = (x: Item) => (
    <div key={x.key} className="between" style={{ padding: '7px 0', borderTop: '1px solid var(--line)', fontSize: 13, gap: 8, cursor: 'pointer' }} onClick={x.edit}>
      <span style={{ minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}><b style={{ color: 'var(--ink)' }}>{x.name}</b><span className="muted"> · {RACE_TYPES[raceTypeOf({ ...x.r, name: x.name })].l.toLowerCase()}</span></span>
      <span className="row" style={{ gap: 6, flex: 'none' }}><span className="muted" style={{ fontWeight: 700 }}>{dshort(x.date)}</span><Chip sm on={x.strong}>{x.tag}</Chip></span>
    </div>
  )
  const offBtns = (after?: () => void) => (
    <div className="row" style={{ gap: 7, flexWrap: 'wrap', marginTop: 10 }}>
      {[2, 3, 4, 6].map(w => <Btn key={w} sm primary={w === 4} ghost={w !== 4} onClick={async () => { await startOffSeason(w); after?.(); toast(`Off-season ${w} ${w < 5 ? 'tedne' : 'tednov'} — najprej počitek, nato hribi in vožnja po občutku, zadnji teden vrnitev.`, 'ok', 8000) }}>{w} {w === 2 ? 'tedna' : w < 5 ? 'tedne' : 'tednov'}</Btn>)}
    </div>
  )
  const offText = 'Po dolgi sezoni priporočam ~4 tedne: najprej počitek (kolo počiva, po želji sprehod ali hribi), nato aktivni počitek (hribi, vožnja po občutku, drugi športi), zadnji teden lahke vožnje. Nato lahki tedni osnove in počasna gradnja. FTP po premoru pade nekaj % — normalno, hitro se vrne.'
  return (<>
    {ask && (
      <Card tight accent style={{ marginBottom: 12 }}>
        <b style={{ fontSize: 13.5 }}>Je bila {lastPast!.name} ({dshort(lastPast!.date)}) zadnja tekma sezone?</b>
        <p style={{ fontSize: 12.5, marginTop: 4 }}>Potem začni off-season. {offText}</p>
        {offBtns()}
        <Btn sm ghost style={{ marginTop: 7 }} onClick={() => void declineOffSeason()}>Ne, sezona še traja</Btn>
      </Card>
    )}
    {cx.phase === 'prehod' && (
      <Card tight style={{ marginBottom: 12 }}>
        <div className="between"><b style={{ fontSize: 13 }}>Off-season · {cx.offStage === 'pocitek' ? 'počitek' : cx.offStage === 'vrnitev' ? 'vrnitev' : 'aktivni počitek'}</b><span className="muted" style={{ fontSize: 12, fontWeight: 700 }}>teden {cx.week}/{p.offSeasonWeeks}</span></div>
        <p style={{ fontSize: 12.5, marginTop: 4 }}>{cx.offStage === 'pocitek' ? 'Kolo počiva — vse je po želji.' : cx.offStage === 'vrnitev' ? 'Lahke vožnje brez struktur — navada nazaj.' : 'Hribi, vožnja po občutku, drugi športi — brez intervalov in brez ure.'} Osnova začne {dshort(addDays(p.cycleStart || app.today, (p.offSeasonWeeks || 0) * 7))} z lahkimi tedni.</p>
        <Btn sm ghost style={{ marginTop: 8 }} onClick={async () => { await endOffSeason(); toast('Osnova začne ta teden — lahki tedni, nato test FTP.', 'ok', 6000) }}>Spočit sem — začni z osnovo</Btn>
      </Card>
    )}
    <Card tight style={{ marginBottom: 12 }}>
      <div className="between"><b style={{ fontSize: 13 }}>Tekme sezone{items.length ? <span className="muted" style={{ fontWeight: 600 }}> · {nA} {nA === 1 ? 'cilj' : nA === 2 ? 'cilja' : nA <= 4 ? 'cilji' : 'ciljev'} A{items.length - nA ? `, ${items.length - nA} drugih` : ''}</span> : null}</b><button className="chip sm click" onClick={() => setEdit({ kind: 'new' })}>+ dodaj</button></div>
      <div className="stack" style={{ gap: 0, marginTop: 6 }}>
        {shown.map(line)}
        {!items.length && <p className="muted" style={{ fontSize: 12, marginTop: 6 }}>Dodaj tekme sezone — tudi šprinterske, vzpone in kronometre. Cilji A dobijo svoj vrh forme, B in C se prilagodi samo teden tekme.</p>}
      </div>
      <div className="row" style={{ gap: 7, flexWrap: 'wrap', marginTop: 8 }}>
        {items.length > shown.length || past.length ? <button className="chip sm click" onClick={() => setAll(true)}>vse tekme ({items.length}{past.length ? ` + ${past.length} mimo` : ''})</button> : null}
        {!ask && cx.phase !== 'prehod' && <button className="chip sm click" onClick={() => setOff(true)}>sezona je končana → off-season</button>}
      </div>
    </Card>
    {edit && <RaceSheet editing={edit} onClose={() => setEdit(null)} />}
    {all && (
      <Sheet open onClose={() => setAll(false)}>
        <div className="between"><b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Tekme sezone</b><button className="chip sm click" onClick={() => { setAll(false); setEdit({ kind: 'new' }) }}>+ dodaj</button></div>
        <p className="muted" style={{ fontSize: 12, marginTop: 4 }}>A = cilj sezone (svoj vrh forme: specifičen blok in tapering). Cilj A manj kot 5 tednov od drugega vrha se vozi v isti formi — prilagodi se samo teden tekme, kot pri B. Priporočam 2–3 cilje A na sezono.</p>
        <div className="stack" style={{ gap: 0, marginTop: 8 }}>
          {items.map(x => <div key={x.key}>{row(x.name, x.date, x.r, x.peak ? `A · forma ${x.peak}` : x.tag, x.strong, () => { setAll(false); x.edit() }, x.remove)}</div>)}
        </div>
        {past.length > 0 && <div className="muted" style={{ fontSize: 11.5, marginTop: 8 }}>Mimo: {past.map(r => `${r.name} (${dshort(r.date)})`).join(', ')}</div>}
        <Btn ghost block style={{ marginTop: 12 }} onClick={() => setAll(false)}>Zapri</Btn>
      </Sheet>
    )}
    {off && (
      <Sheet open onClose={() => setOff(false)}>
        <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Off-season</b>
        <p style={{ fontSize: 12.5, marginTop: 6 }}>Začne ta teden (po zadnji tekmi ali ko se odločiš). {offText}</p>
        {offBtns(() => setOff(false))}
        <Btn ghost block style={{ marginTop: 12 }} onClick={() => setOff(false)}>Prekliči</Btn>
      </Sheet>
    )}
  </>)
}

function RaceSheet({ editing, onClose }: { editing: Editing; onClose: () => void }) {
  const app = useApp()
  const p = app.profile
  const main = editing.kind === 'main'
  const src = editing.kind === 'race' ? editing.race : main && p.event ? { ...p.event, prio: 'A' as const, id: 'main' } : null
  const [f, setF] = useState({
    name: src?.name || '', date: src?.date || '', km: src?.distanceKm ? String(src.distanceKm) : '', elev: src?.elevM ? String(src.elevM) : '',
    prio: (src?.prio || 'C') as Race['prio'], type: (src?.type ?? null) as RaceType | null, level: (src?.level || 'amater') as 'amater' | 'visji',
  })
  const num = (v: string, max: number) => (v.trim() ? Math.max(1, Math.min(max, Math.round(+v.replace(',', '.')))) : null)
  const km = num(f.km, 400), elev = num(f.elev, 8000)
  const draft = { name: f.name || 'Tekma', distanceKm: km, elevM: elev, type: f.type, level: f.level }
  const auto = raceTypeOf({ ...draft, type: null }), type = f.type ?? auto, d = raceDemand(draft)
  async function save() {
    if (!f.name.trim() || !f.date) { toast('Vpiši ime in datum tekme.', 'err'); return }
    if (f.date < app.today) { toast('Datum mora biti danes ali kasneje.', 'err'); return }
    const base = { name: f.name.trim().slice(0, 60), date: f.date, distanceKm: km, elevM: elev, type: f.type, level: f.level }
    if (main) {
      await saveMainGoal(base)
      toast(`${base.name}: načrt je prilagojen (${RACE_TYPES[type].l.toLowerCase()}).`, 'ok', 6000); onClose(); return
    }
    if (p.event?.date === f.date) { toast('Na ta dan je glavni cilj — uredi ga s tapom nanj.', 'err'); return }
    const r: Race = { ...base, id: editing.kind === 'race' ? editing.race.id : uid(), prio: f.prio }
    const others = (p.races || []).filter(x => x.id !== r.id)
    await saveRaces([...others, r])
    const days = Math.round((new Date(f.date).getTime() - new Date(app.today).getTime()) / 86400_000)
    toast(editing.kind === 'race' ? `${r.name} posodobljena — načrt je prilagojen.` : f.prio === 'A'
      ? `${r.name} je cilj sezone — pred njo ${RACE_TYPES[type].l.toLowerCase()}: specifičen blok in tapering.`
      : days <= 13 ? `${r.name} dodana — načrt je že prilagojen (dan prej predaktivacija, dan po lahko).` : `${r.name} dodana — teden tekme se prilagodi, ko pride na vrsto.`, 'ok', 7000)
    onClose()
  }
  async function del() {
    if (editing.kind !== 'race' || !confirm(`Odstranim tekmo »${editing.race.name}«?`)) return
    await saveRaces((p.races || []).filter(x => x.id !== editing.race.id)); toast('Tekma odstranjena.', 'ok'); onClose()
  }
  return (
    <Sheet open onClose={onClose}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>{main ? 'Glavni cilj' : editing.kind === 'race' ? 'Uredi tekmo' : 'Dodaj tekmo'}</b>
      <p style={{ fontSize: 12.5, marginTop: 4 }}>Povej, kakšna je — načrt pred njo trenira to, kar na njej odloča (klanci, šprint, ravnina, dolžina).</p>
      <div className="stack" style={{ gap: 10, marginTop: 12 }}>
        <div className="field"><label>Tekma</label><input value={f.name} onChange={e => setF({ ...f, name: e.target.value })} placeholder="npr. VN Vodice" autoFocus={editing.kind === 'new'} /></div>
        <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr 1fr', gap: 10 }}>
          <div className="field"><label>Datum</label><DateField compact min={app.today} value={f.date} onChange={v => setF({ ...f, date: v })} label="Datum tekme" /></div>
          <div className="field"><label>Dolžina <span className="unit">km</span></label><input type="number" inputMode="numeric" value={f.km} onChange={e => setF({ ...f, km: e.target.value })} /></div>
          <div className="field"><label>Vzpon <span className="unit">m</span></label><input type="number" inputMode="numeric" value={f.elev} onChange={e => setF({ ...f, elev: e.target.value })} placeholder="če veš" /></div>
        </div>
        <div className="field"><label>Kakšna je {f.type == null && <span className="unit">predlog iz dolžine in vzpona</span>}</label>
          <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>{TYPES.map(t => <Chip key={t} sm on={type === t} onClick={() => setF({ ...f, type: t })}>{RACE_TYPES[t].l}</Chip>)}</div>
          <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>{RACE_TYPES[type].d}.</div>
        </div>
        <div className="field"><label>Rang</label>
          <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>
            <Chip sm on={f.level === 'amater'} onClick={() => setF({ ...f, level: 'amater' })}>Amaterska</Chip>
            <Chip sm on={f.level === 'visji'} onClick={() => setF({ ...f, level: 'visji' })}>Višji rang (UCI, U23, elite)</Chip>
          </div>
        </div>
        {!main && <div className="field"><label>Kako pomembna</label>
          <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>{(['A', 'B', 'C'] as const).map(k => <Chip key={k} sm on={f.prio === k} onClick={() => setF({ ...f, prio: k })}>{PRIO[k].l}</Chip>)}</div>
          <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>{PRIO[f.prio].d}</div>
        </div>}
        <div className="card tight" style={{ background: 'var(--raised)' }}>
          <div className="between" style={{ fontSize: 13 }}><span className="muted" style={{ fontWeight: 700 }}>Ocena</span><b>~{fmtDur(d.min)} · <span style={{ letterSpacing: 1 }}>{dots(d.stars)}</span></b></div>
          <div className="muted" style={{ fontSize: 11.5, marginTop: 3 }}>{d.long ? `Dolga — dolge vožnje pred njo do ~${fmtDur(Math.min(390, Math.round(d.min * 0.85 / 5) * 5))}. ` : ''}{d.hilly ? 'Veliko klancev — več dela na klancih. ' : ''}{f.level === 'visji' ? 'Višji rang — hitreje, več napadov: več VO2max in ponavljajočih se napadov. ' : ''}{!d.long && !d.hilly && f.level !== 'visji' ? 'Kratka in hitra — ostrina in pospeški.' : ''}</div>
        </div>
      </div>
      <Btn primary block style={{ marginTop: 14 }} onClick={save}>{editing.kind === 'new' ? 'Dodaj in prilagodi načrt' : 'Shrani in prilagodi načrt'}</Btn>
      {editing.kind === 'race' && <Btn ghost block style={{ marginTop: 9 }} onClick={del}>Odstrani tekmo</Btn>}
      <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Prekliči</Btn>
    </Sheet>
  )
}
