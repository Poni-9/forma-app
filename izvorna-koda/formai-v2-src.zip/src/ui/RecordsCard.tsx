import type { Activity } from '@/domain/types'
import { records, yearTotals } from '@/domain/training/records'
import { fmtDur } from '@/domain/training/load'
import { Card, Chip } from '@/ui/primitives'
import { dm, int, num, NBSP } from '@/ui/format'

/** Letos na kolesu (proti lani do istega dne) in osebni rekordi: najdaljša vožnja, najdlje na kolesu, največ vzpona, največji teden. */
export function RecordsCard({ acts, today }: { acts: readonly Activity[]; today: string }) {
  const r = records(acts, today), y = yearTotals(acts, today)
  if (!r.distance && !y.now.n) return null
  const diff = y.prev.km ? Math.round(((y.now.km - y.prev.km) / y.prev.km) * 100) : null
  const rows: { k: string; v: string; d: string; fresh: boolean }[] = []
  if (r.distance) rows.push({ k: 'Najdaljša vožnja', v: `${num(r.distance.value)}${NBSP}km`, d: dm(r.distance.date), fresh: r.distance.fresh })
  if (r.duration) rows.push({ k: 'Najdlje na kolesu', v: fmtDur(Math.round(r.duration.value)), d: dm(r.duration.date), fresh: r.duration.fresh })
  if (r.climb) rows.push({ k: 'Največ vzpona', v: `${int(r.climb.value)}${NBSP}m`, d: dm(r.climb.date), fresh: r.climb.fresh })
  if (r.week) rows.push({ k: 'Največji teden', v: fmtDur(r.week.min), d: `teden ${dm(r.week.weekStart)}`, fresh: r.week.fresh })
  return (
    <Card>
      <h2 className="h4" style={{ margin: 0 }}>Letos in rekordi</h2>
      {y.now.n > 0 && <>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginTop: 10 }}>
          <div><div style={{ fontSize: 20, fontWeight: 800 }}>{int(y.now.km)}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>km v {y.year}</div></div>
          <div><div style={{ fontSize: 20, fontWeight: 800 }}>{int(Math.round(y.now.min / 60))}{NBSP}h</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>na kolesu</div></div>
          <div><div style={{ fontSize: 20, fontWeight: 800 }}>{int(y.now.elev)}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>m vzpona</div></div>
        </div>
        <p className="muted" style={{ fontSize: 12, marginTop: 6 }}>{y.prev.n ? <>Lani do {dm(today)}: {int(y.prev.km)}{NBSP}km, {int(Math.round(y.prev.min / 60))}{NBSP}h{diff != null ? <> — <b style={{ color: diff >= 0 ? 'var(--ok)' : 'var(--ink-2)' }}>{diff >= 0 ? '+' : '−'}{Math.abs(diff)}{NBSP}%</b> km</> : null}.</> : `${y.now.n} voženj letos.`}</p>
      </>}
      {rows.length > 0 && <div className="zone-rows" style={{ marginTop: 10 }}>{rows.map(x => (
        <div key={x.k} className="between"><span>{x.k}{x.fresh ? <> <Chip sm on>nov</Chip></> : null}</span><span><b>{x.v}</b> <span className="muted">· {x.d}</span></span></div>
      ))}</div>}
    </Card>
  )
}
