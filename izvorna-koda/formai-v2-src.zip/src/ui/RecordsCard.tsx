import type { Activity, Sport } from '@/domain/types'
import { records, yearTotals, RECORDS_MIN } from '@/domain/training/records'
import { fmtDur } from '@/domain/training/load'
import { Card, Chip } from '@/ui/primitives'
import { count, dm, dmy, int, num, NBSP, W, type Forms } from '@/ui/format'
import { rem } from '@/ui/rem'

/** (v3.50) besedila po športu: kolo, tek, hoja (prej samo kolo — tekač je razdelek izgubil) */
const TXT: Partial<Record<Sport, { name: string; dist: string; dur: string; on: string; one: Forms }>> = {
  kolo: { name: 'kolo', dist: 'Najdaljša vožnja', dur: 'Najdlje na kolesu', on: 'na kolesu', one: W.voznja },
  tek: { name: 'tek', dist: 'Najdaljši tek', dur: 'Najdlje v teku', on: 'teka', one: ['tek', 'teka', 'teki', 'tekov'] },
  pohod: { name: 'hoja', dist: 'Najdaljša hoja', dur: 'Najdlje na poti', on: 'hoje', one: ['hoja', 'hoji', 'hoje', 'hoj'] },
}
const txtOf = (s: Sport) => TXT[s] ?? TXT.kolo!
/** (v3.51) ure pod 10 h z minutami (»1 h 30 min«, prej »2 h«), od 10 h cele ure */
const hTxt = (min: number) => (min > 0 && min < 600 ? fmtDur(Math.round(min)) : `${int(Math.round(min / 60))}${NBSP}h`)

/** Ali je kaj za pokazati (kartica sicer vrne null) — za zaprt razdelek v Napredku. */
export const recordsHas = (acts: readonly Activity[], today: string, sport: Sport = 'kolo') => !!records(acts, today, sport).distance || yearTotals(acts, today, sport).now.n > 0

/** (v3.50) povzetek zaprtega razdelka s številkami (prej »km letos, najdaljša vožnja, največ vzpona«) */
export function recordsSum(acts: readonly Activity[], today: string, sport: Sport = 'kolo'): string {
  const y = yearTotals(acts, today, sport).now
  if (!y.n) return `rekordi · ${txtOf(sport).name}`
  return [y.km ? `${int(y.km)}${NBSP}km` : '', `${hTxt(y.min)} letos`].filter(Boolean).join(' · ')
}

/** Letos (proti lani do istega dne) in osebni rekordi po športu: najdaljša, najdlje, največ vzpona, največji teden. */
export function RecordsCard({ acts, today, sport = 'kolo' }: { acts: readonly Activity[]; today: string; sport?: Sport }) {
  const r = records(acts, today, sport), y = yearTotals(acts, today, sport), t = txtOf(sport)
  if (!r.distance && !y.now.n) return null
  const diff = y.prev.km ? Math.round(((y.now.km - y.prev.km) / y.prev.km) * 100) : null
  const rows: { k: string; v: string; d: string; fresh: boolean }[] = []
  // (v3.51) rekord iz preteklih let z letnico (prej »14. 11.« brez leta)
  const dd = (iso: string) => dmy(iso, today)
  if (r.distance) rows.push({ k: t.dist, v: `${num(r.distance.value)}${NBSP}km`, d: dd(r.distance.date), fresh: r.distance.fresh })
  if (r.duration) rows.push({ k: t.dur, v: fmtDur(Math.round(r.duration.value)), d: dd(r.duration.date), fresh: r.duration.fresh })
  if (r.climb) rows.push({ k: 'Največ vzpona', v: `${int(r.climb.value)}${NBSP}m`, d: dd(r.climb.date), fresh: r.climb.fresh })
  if (r.week) rows.push({ k: 'Največji teden', v: fmtDur(r.week.min), d: `teden ${dd(r.week.weekStart)}`, fresh: r.week.fresh })
  // (v3.50) km in vzpon samo, ko jih je kaj (zapisi iz načrta nimajo razdalje — prej »0 km v 2026 · 0 m vzpona«)
  const tiles = [
    y.now.km > 0 ? { v: int(y.now.km), l: `km v ${y.year}` } : null,
    { v: hTxt(y.now.min), l: t.on },
    y.now.elev > 0 ? { v: int(y.now.elev), l: 'm vzpona' } : null,
  ].filter(Boolean) as { v: string; l: string }[]
  const nAll = acts.filter(a => a.sport === sport).length
  return (
    <Card>
      <h2 className="h4" style={{ margin: 0 }}>Letos in rekordi{sport !== 'kolo' ? ` · ${t.name}` : ''}</h2>
      {y.now.n > 0 && <>
        <div style={{ display: 'grid', gridTemplateColumns: `repeat(${tiles.length}, 1fr)`, gap: 8, marginTop: 10 }}>
          {tiles.map(x => <div key={x.l}><div style={{ fontSize: rem(20), fontWeight: 800 }}>{x.v}</div><div className="muted" style={{ fontSize: rem(11), fontWeight: 700 }}>{x.l}</div></div>)}
        </div>
        <p className="muted" style={{ fontSize: rem(12), marginTop: 6 }}>{y.prev.n ? <>Lani do {dm(today)}: {y.prev.km ? <>{int(y.prev.km)}{NBSP}km, </> : null}{int(Math.round(y.prev.min / 60))}{NBSP}h{diff != null && y.now.km ? <> — <b style={{ color: diff >= 0 ? 'var(--ok)' : 'var(--ink-2)' }}>{diff >= 0 ? '+' : '−'}{Math.abs(diff)}{NBSP}%</b> km</> : null}.</> : `${count(y.now.n, t.one)} letos.`}</p>
      </>}
      {rows.length > 0 ? <div className="zone-rows" style={{ marginTop: 10 }}>{rows.map(x => (
        <div key={x.k} className="between"><span>{x.k}{x.fresh ? <> <Chip sm on>nov</Chip></> : null}</span><span><b>{x.v}</b> <span className="muted">· {x.d}</span></span></div>
      ))}</div> : nAll < RECORDS_MIN ? <p className="muted" style={{ fontSize: rem(12), marginTop: 8 }}>Rekordi se pokažejo po {RECORDS_MIN} {sport === 'kolo' ? 'vožnjah' : sport === 'tek' ? 'tekih' : 'hojah'}.</p> : null}
    </Card>
  )
}
