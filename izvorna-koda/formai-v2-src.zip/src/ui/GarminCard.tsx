import { useEffect, useState } from 'react'
import { navigate } from '@/app/router'
import { useApp, connectGarmin, syncGarmin, disconnectGarmin, signIn, toast, setGarminOpt, pushGarminWorkouts, garminAllows } from '@/state/store'
import { garminLive, garminOn } from '@/domain/garmin/client'
import type { GarminSettings } from '@/domain/types'
import { Card, Btn } from '@/ui/primitives'
import { IcoCheck, IcoWarn } from '@/ui/icons'
import { useConfirm } from '@/ui/Confirm'
import { count, W } from '@/ui/format'
import { rem } from '@/ui/rem'

/**
 * (v3.52) Kartica »Garmin Connect« na Uvozu — neposredna povezava (brez intervals.icu): vožnje z ure pridejo same,
 * treningi iz načrta gredo na uro. Pokaže se, ko strežnik ima Garmin (garminLive) ali je povezava že vzpostavljena.
 * Stanje je v settings.garmin (usklajeno med napravami), prenos in napaka v state.garminBusy/garminErr.
 */

/** »zadnji prenos danes 7:12« / »zadnji prenos 24. 10. 7:12« / »še ni prenosa« */
export function lastSyncLine(iso: string | null | undefined, now: Date = new Date()): string {
  if (!iso) return 'še ni prenosa'
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return 'še ni prenosa'
  const hm = d.toLocaleTimeString('sl-SI', { hour: '2-digit', minute: '2-digit' })
  const sameDay = d.toDateString() === now.toDateString()
  return `zadnji prenos ${sameDay ? 'danes' : `${d.getDate()}. ${d.getMonth() + 1}.`} ${hm}`
}
/** Povezava rabi »Poveži znova«: strežnik je ni potrdil (connected false) ali napaka to naravnost pove. */
export function garminNeedsReconnect(g: GarminSettings | null | undefined, err: string | null | undefined): boolean {
  if (!g) return false
  if (!g.connected) return true
  return /poveži znova|poveži garmin znova/i.test(err || g.lastError || '')
}

export function GarminCard({ style }: { style?: React.CSSProperties }) {
  const app = useApp()
  const g = app.settings.garmin ?? null
  // gumb »Poveži« šele, ko strežnik potrdi, da ima Garminove ključe (ena poizvedba na zagon)
  const [live, setLive] = useState<boolean>(() => garminOn())
  useEffect(() => { let dead = false; void Promise.resolve().then(() => garminLive()).then(v => { if (!dead) setLive(v) }).catch(() => undefined); return () => { dead = true } }, [])
  const [busy, setBusy] = useState<string | null>(null)
  const { confirm, sheet } = useConfirm()
  if (!g && !live) return null
  const err = app.garminErr || g?.lastError || null
  const reconnect = garminNeedsReconnect(g, err)

  async function check() {
    setBusy('Preverjam Garmin …')
    try {
      const r = await syncGarmin(true)
      // napaka in nove vadbe so že v obvestilu (store); tu samo »nič novega« in preskok
      if (!r) return
      if (r.skipped) { toast(r.skipped, 'info', 5000); return }
      if (r.error) return
      if (!r.added && !r.upgraded) toast('Nove vožnje še ni — ura jo najprej pošlje v Garmin Connect (običajno nekaj minut po shranjeni vožnji).', 'info', 7000)
    } finally { setBusy(null) }
  }
  async function disconnect() {
    if (!(await confirm({ title: 'Odklopim Garmin Connect?', text: 'Tvoje vožnje ostanejo v aplikaciji. Treningi FORMAI gredo z ure; spanec, HRV, stres in cikel z Garmina se s te naprave izbrišejo.', ok: 'Odklopi' }))) return
    setBusy('Odklapljam …')
    try { await disconnectGarmin() } finally { setBusy(null) }
  }
  async function login() {
    setBusy('Prijava …')
    try { await signIn() } catch (e) { toast((e as Error)?.message || 'Prijava ni uspela.', 'err') } finally { setBusy(null) }
  }

  return (<>
    <Card accent className="page g-card" style={style}>
      <div className="between"><h2 className="h4" style={{ color: 'var(--accent-fg)' }}>Garmin Connect</h2>{g?.connected && !reconnect && <span className="chip sm g-ok"><IcoCheck width={12} height={12} aria-hidden="true" /> povezano</span>}</div>
      {g ? (<>
        <div className="g-status" style={{ marginTop: 8 }}>
          <b style={{ fontSize: rem(13.5) }}>{reconnect ? 'Povezava ne dela' : 'Povezano · Garmin'}</b>
          <div className="muted" style={{ fontSize: rem(12), marginTop: 2 }} role="status">{app.garminBusy ? 'Prenašam z Garmina …' : lastSyncLine(g.lastSyncAt)}</div>
        </div>
        {err && (
          <div role="alert" className="row g-err" style={{ gap: 8, alignItems: 'flex-start', marginTop: 8 }}>
            <IcoWarn width={15} height={15} aria-hidden="true" style={{ color: 'var(--warn)', flex: 'none', marginTop: 2 }} />
            <span style={{ fontSize: rem(12.5), lineHeight: 1.45, color: 'var(--ink-2)' }}>{err}</span>
          </div>
        )}
        <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
          {reconnect
            ? <Btn primary sm disabled={!!busy} onClick={() => void connectGarmin()}>Poveži znova</Btn>
            : <Btn sm disabled={!!busy || app.garminBusy} onClick={() => void check()}>{busy === 'Preverjam Garmin …' ? 'Preverjam …' : 'Preveri Garmin'}</Btn>}
          <Btn ghost sm onClick={() => navigate('nastavitve', { sec: 'n-garmin' })}>Nastavitve</Btn>
          <Btn ghost sm disabled={!!busy} onClick={() => void disconnect()}>{busy === 'Odklapljam …' ? 'Odklapljam …' : 'Odklopi'}</Btn>
        </div>
      </>) : (<>
        <p style={{ fontSize: rem(13), marginTop: 6 }}>Vožnje z ure pridejo same (Garmin → FORMAI). Treningi iz načrta gredo na uro. Brez intervals.icu.</p>
        {/* (v3.52 popravki) vrnitev z Garmina z napako (?garmin=err): razlog ostane na kartici, ne samo v obvestilu */}
        {app.garminErr && (
          <div role="alert" className="row g-err" style={{ gap: 8, alignItems: 'flex-start', marginTop: 8 }}>
            <IcoWarn width={15} height={15} aria-hidden="true" style={{ color: 'var(--warn)', flex: 'none', marginTop: 2 }} />
            <span style={{ fontSize: rem(12.5), lineHeight: 1.45, color: 'var(--ink-2)' }}>{app.garminErr}</span>
          </div>
        )}
        {app.user
          ? <Btn primary block style={{ marginTop: 12 }} disabled={!!busy} onClick={() => void connectGarmin()}>Poveži z Garmin Connect</Btn>
          : <Btn primary block style={{ marginTop: 12 }} disabled={!!busy} onClick={() => void login()}>Prijavi se, da povežeš Garmin</Btn>}
        <div className="muted" style={{ fontSize: rem(12), marginTop: 6 }}>Odpre se Garminova stran za prijavo; potrdiš, kaj FORMAI sme (vadbe, treningi, trase; zdravje in cikel po želji). Zgodovine Garmin ne pošilja — starejše vožnje uvozi iz arhiva.</div>
      </>)}
      <div className="muted" style={{ fontSize: rem(11.5), marginTop: 10 }}>
        {g ? 'Vožnje z ure pridejo same (Garmin → FORMAI). Treningi iz načrta gredo na uro.' : 'intervals.icu spodaj ostane za Wahoo, COROS, Zwift in zgodovino.'}
        {app.settings.intervals ? ' Ista vožnja z Garmina in intervals.icu se ne podvoji.' : ''}
        {g && app.garminWorkouts?.n ? ` Na uri: ${count(app.garminWorkouts.n, W.trening)}.` : ''}
      </div>
    </Card>
    {sheet}
  </>)
}

/** Ena vrstica s stikalom (kot »Spanec, HRV in mirovni utrip« v Nastavitvah): naslov, opis, stikalo; cilj dotika čez vso vrstico. */
function GarminToggle({ id, on, title, desc, onToggle, disabled }: { id: string; on: boolean; title: string; desc: string; onToggle: () => void; disabled?: boolean }) {
  return (
    <button type="button" id={id} className="between g-toggle" disabled={disabled} onClick={onToggle} aria-pressed={on}>
      <span><b style={{ fontSize: rem(14) }}>{title}</b><span className="muted" style={{ display: 'block', fontSize: rem(12), marginTop: 2 }}>{desc}</span></span>
      <span className={`switch ${on ? 'on' : ''}`} aria-hidden="true"><i /></span>
    </button>
  )
}

/** »Na uri: 9 treningov · zadnjič danes 7:12« / napaka / »Še ni poslano.« */
export function workoutsLine(w: { at: string; n: number; err: string | null } | null | undefined, now: Date = new Date()): string {
  if (!w) return 'Še ni poslano.'
  if (w.err) return `Napaka: ${w.err}`
  const d = new Date(w.at)
  const when = Number.isNaN(d.getTime()) ? '' : ` · zadnjič ${d.toDateString() === now.toDateString() ? 'danes' : `${d.getDate()}. ${d.getMonth() + 1}.`} ${d.toLocaleTimeString('sl-SI', { hour: '2-digit', minute: '2-digit' })}`
  return `Na uri: ${w.n ? count(w.n, W.trening) : 'ni treningov (v 14 dneh ni kolesa, testa ali teka)'}${when}`
}

/**
 * Nastavitve → Garmin: stikala (treningi na uro, trase, zdravje, cikel — cikel samo pri ženskah). Zdravje in cikel sta
 * izrecna privolitev; ob izklopu se podatki izbrišejo (store.setGarminOpt). Cikel NIKOLI ne gre v AI.
 */
export function GarminOpts({ onAiInfo }: { onAiInfo?: () => void }) {
  const app = useApp()
  const g = app.settings.garmin
  const [busy, setBusy] = useState<string | null>(null)
  if (!g) return null
  const female = app.profile.sex === 'z'
  const w = app.garminWorkouts ?? null
  const set = async (k: 'health' | 'cycle' | 'pushWorkouts' | 'pushCourses', on: boolean) => { setBusy(k); try { await setGarminOpt(k, on) } finally { setBusy(null) } }
  const pushOn = g.pushWorkouts !== false
  const noPerm = (p: 'WORKOUT_IMPORT' | 'COURSE_IMPORT' | 'HEALTH_EXPORT' | 'MCT_EXPORT') => g.connected && !garminAllows(g, p)
  return (
    <div className="g-opts">
      {!g.connected && <p style={{ fontSize: rem(12.5), marginTop: 6, color: 'var(--warn)', fontWeight: 600 }}>Povezava z Garminom ne dela — v Uvozu jo poveži znova.</p>}
      <div className="stack" style={{ gap: 0, marginTop: 6 }}>
        <GarminToggle id="g-push" on={pushOn} disabled={busy === 'pushWorkouts'} title="Treningi na uro (14 dni)" desc={`Naslednjih 14 dni načrta gre na uro kot strukturirani treningi (kolo, test, tek) — ob vsaki spremembi načrta samodejno. Izklop jih z ure pobriše.${noPerm('WORKOUT_IMPORT') ? ' Garminu nisi dovolil uvoza treningov — poveži znova in potrdi.' : ''}`} onToggle={() => void set('pushWorkouts', !pushOn)} />
        {pushOn && (
          <div className="muted g-sub" style={{ fontSize: rem(12) }} role="status">
            <span style={w?.err ? { color: 'var(--bad)' } : undefined}>{workoutsLine(w)}</span>
            {w?.errors?.length ? <ul className="g-errs">{w.errors.slice(0, 3).map(e => <li key={e.date}>{+e.date.slice(8)}. {+e.date.slice(5, 7)}.: {e.error}</li>)}</ul> : null}
            <button type="button" className="chip sm click" disabled={!!busy} onClick={async () => { setBusy('send'); try { await pushGarminWorkouts(true) } finally { setBusy(null) } }}>{busy === 'send' ? 'pošiljam …' : 'Pošlji znova'}</button>
          </div>
        )}
        <GarminToggle id="g-courses" on={g.pushCourses !== false} disabled={busy === 'pushCourses'} title="Trase dolgih voženj na uro" desc={`Na dnevu z vožnjo tapneš »Trasa na uro« — proga pride v Garmin Connect in na uro (Navigacija → Trase).${noPerm('COURSE_IMPORT') ? ' Garminu nisi dovolil uvoza tras — poveži znova in potrdi.' : ''}`} onToggle={() => void set('pushCourses', g.pushCourses === false)} />
        <GarminToggle id="g-health" on={g.health === true} disabled={busy === 'health'} title="Spanec, HRV, utrip in stres za pripravljenost" desc={`Z ure na naš strežnik (v tvojem računu) in na to napravo → jutranja pripravljenost in lažji dan po slabi noči. Ob izklopu se izbrišejo. V AI gre samo ocena pripravljenosti, nikoli surovi podatki.${noPerm('HEALTH_EXPORT') ? ' Garminu nisi dovolil deljenja zdravja — poveži znova in potrdi.' : ''}`} onToggle={() => void set('health', g.health !== true)} />
        {female && <GarminToggle id="g-cycle" on={g.cycle === true} disabled={busy === 'cycle'} title="Menstrualni cikel" desc={`Samo prikaz faze in nasvet (lažji trd dan, prehrana) — brez spreminjanja kalorij. Ostane na tej napravi; NIKOLI ne gre v AI. Ob izklopu se izbriše.${noPerm('MCT_EXPORT') ? ' Garminu nisi dovolil deljenja cikla — poveži znova in potrdi.' : ''}`} onToggle={() => void set('cycle', g.cycle !== true)} />}
      </div>
      <p className="muted" style={{ fontSize: rem(11.5), marginTop: 10 }}>Garmin podatke pošilja po shranjeni vožnji ali sinhronizaciji ure (običajno v nekaj minutah). {onAiInfo && <button type="button" className="lnk-hit g-lnk" onClick={onAiInfo}>Kaj gre v AI ›</button>}</p>
    </div>
  )
}
