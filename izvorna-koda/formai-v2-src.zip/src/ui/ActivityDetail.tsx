import { useEffect, useRef } from 'react'
import type { Activity } from '@/domain/types'
import { aiAllowed, sourceLabel, geoAllowed } from '@/domain/import/provenance'
import { decodePolyline, trackLengthKm } from '@/domain/import/polyline'
import { fmtDur } from '@/domain/training/load'
import { Sheet, Btn, Chip, kindColor, fmtDateLong } from '@/ui/primitives'
import 'leaflet/dist/leaflet.css'

/** Podrobnosti ene aktivnosti: karta sledi (če jo ima), številke, izvor, izbris. */
export function ActivityDetail({ a, onClose, onDelete }: { a: Activity | null; onClose: () => void; onDelete: (id: string) => void }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!a || !geoAllowed(a) || !ref.current) return
    let map: import('leaflet').Map | null = null
    ;(async () => {
      const Lf = (await import('leaflet')).default
      if (!ref.current) return
      map = Lf.map(ref.current, { zoomControl: false, attributionControl: false, dragging: false, scrollWheelZoom: false, touchZoom: false, doubleClickZoom: false })
      Lf.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 18, className: 'dark-tiles' }).addTo(map)
      const pts = decodePolyline(a.polyline as string)
      const pl = Lf.polyline(pts, { color: getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#A3E635', weight: 3 }).addTo(map)
      Lf.circleMarker(pts[0]!, { radius: 5, color: '#fff', fillColor: '#199e70', fillOpacity: 1, weight: 2 }).addTo(map)
      Lf.circleMarker(pts[pts.length - 1]!, { radius: 5, color: '#fff', fillColor: '#e5484d', fillOpacity: 1, weight: 2 }).addTo(map)
      setTimeout(() => { map?.invalidateSize(); map?.fitBounds(pl.getBounds().pad(0.1)) }, 60)
    })()
    return () => { map?.remove() }
  }, [a])
  if (!a) return null
  const km = a.polyline ? trackLengthKm(decodePolyline(a.polyline)) : null
  const stat = (l: string, v: string | number | null | undefined) => v == null || v === '' ? null : <div key={l}><div className="muted" style={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.06em' }}>{l}</div><b className="num" style={{ fontSize: 18 }}>{v}</b></div>
  return (
    <Sheet open={!!a} onClose={onClose}>
      <div className="row" style={{ gap: 10 }}>
        <span className="dot" style={{ background: kindColor(a.sport), width: 10, height: 10 }} />
        <div style={{ flex: 1, minWidth: 0 }}><b style={{ fontSize: 17, letterSpacing: '-.02em', display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.name}</b><div className="muted" style={{ fontSize: 12 }}>{fmtDateLong(a.date)}{a.start ? ` · ${new Date(a.start).toLocaleTimeString('sl-SI', { hour: '2-digit', minute: '2-digit' })}` : ''}</div></div>
      </div>
      {geoAllowed(a) && <div ref={ref} style={{ height: 180, borderRadius: 'var(--r-m)', overflow: 'hidden', marginTop: 12, background: '#0b0e12' }} />}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginTop: 14 }}>
        {stat('Razdalja', a.distKm != null ? `${a.distKm} km` : km != null ? `${km.toFixed(1)} km` : null)}
        {stat('Čas', fmtDur(a.durationMin))}
        {stat('Vzpon', a.elevM != null ? `${a.elevM} m` : null)}
        {stat('Utrip', a.avgHr != null ? `${a.avgHr}${a.maxHr ? ` / ${a.maxHr}` : ''}` : null)}
        {stat('Moč', a.avgPower != null ? `${a.avgPower} W` : null)}
        {stat('TSS', a.tss)}
        {stat('Hitrost', a.speedKmh != null ? `${a.speedKmh} km/h` : null)}
        {stat('Kalorije', a.kcal)}
      </div>
      <div className="row" style={{ gap: 6, marginTop: 12, flexWrap: 'wrap' }}>
        <Chip sm ok={aiAllowed(a)}>{sourceLabel(a)} · {aiAllowed(a) ? 'trener vidi' : 'trener ne vidi'}</Chip>
        {a.polyline && <Chip sm>sled · na karti</Chip>}
        {a.deviceName && <Chip sm>{a.deviceName}</Chip>}
      </div>
      {a.notes && <p style={{ fontSize: 12.5, marginTop: 10 }}>{a.notes}</p>}
      <div className="row" style={{ gap: 8, marginTop: 14 }}>
        <Btn ghost sm onClick={() => { if (confirm('Izbrišem to aktivnost?')) { onDelete(a.id); onClose() } }}>Izbriši</Btn>
        <Btn primary sm onClick={onClose} style={{ marginLeft: 'auto' }}>Zapri</Btn>
      </div>
    </Sheet>
  )
}
