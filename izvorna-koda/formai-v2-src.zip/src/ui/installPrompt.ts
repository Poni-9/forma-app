/**
 * (v3.51) Namestitveni poziv (Chrome, Edge): ujame se ob zagonu, list »Daj FORMAI na zaslon« pa se naloži šele ob
 * odprtju (prej je bil z dogodkom vred v začetnem paketu).
 */
export type DeferredPrompt = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> }
let deferred: DeferredPrompt | null = null
if (typeof window !== 'undefined') window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferred = e as DeferredPrompt })
/** (v3.51) brskalnik ponuja namestitev (Chrome, Edge — tudi na računalniku) */
export const canInstall = (): boolean => !!deferred
/** (v3.51) računalnik: širok zaslon (namestitev odpre aplikacijo v svojem oknu) */
export const isDesktop = (): boolean => typeof window !== 'undefined' && window.innerWidth >= 900
/** Pokaži sistemski poziv (enkrat — brskalnik ga ne ponovi). */
export async function promptInstall(): Promise<void> {
  const d = deferred
  if (!d) return
  try { await d.prompt(); await d.userChoice } catch { /* preklicano */ }
  deferred = null
}
