import { useEffect, useState } from 'react'
import type { TermKey } from '@/domain/glossary'

/**
 * Lista, ki ju odpreš od koder koli (glava vsakega zaslona, tap na izraz): »Kako deluje« (z izrazom) in »Pripomba«.
 * En gostitelj v App — zasloni samo pokličejo openHelp/openFeedback.
 */
type Help = { term: TermKey | null } | null
/** capturing (v3.50): posnetek zaslona se še zajema (list je odprt takoj, posnetek pride za njim) */
type Fb = { shot: string | null; route: string; capturing?: boolean } | null
let help: Help = null, fb: Fb = null
const subs = new Set<() => void>()
const emit = () => { for (const s of subs) s() }

export function openHelp(term: TermKey | null = null): void { help = { term }; emit() }
export function closeHelp(): void { help = null; emit() }
/** shot: posnetek zaslona (data: URL) — brez lista samega; route: zaslon, s katerega je pripomba */
export function openFeedback(o: { shot: string | null; route: string; capturing?: boolean }): void { fb = o; emit() }
export function closeFeedback(): void { fb = null; emit() }
/** (v3.50) Posnetek je prišel (ali ni uspel: null) — v odprt list, ki ga še čaka. */
export function setFeedbackShot(shot: string | null): void { if (!fb || !fb.capturing) return; fb = { ...fb, shot, capturing: false }; emit() }
/** Trenutno stanje listov (za preizkuse in za zajem v ozadju). */
export function overlayState(): { help: Help; fb: Fb } { return { help, fb } }

export function useOverlays(): { help: Help; fb: Fb } {
  const [, set] = useState(0)
  useEffect(() => { const f = () => set(x => x + 1); subs.add(f); return () => { subs.delete(f) } }, [])
  return { help, fb }
}
