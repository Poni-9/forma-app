import { useEffect, useState } from 'react'
import type { TermKey } from '@/domain/glossary'

/**
 * Lista, ki ju odpreš od koder koli (glava vsakega zaslona, tap na izraz): »Kako deluje« (z izrazom) in »Pripomba«.
 * En gostitelj v App — zasloni samo pokličejo openHelp/openFeedback.
 */
type Help = { term: TermKey | null } | null
type Fb = { shot: string | null; route: string } | null
let help: Help = null, fb: Fb = null
const subs = new Set<() => void>()
const emit = () => { for (const s of subs) s() }

export function openHelp(term: TermKey | null = null): void { help = { term }; emit() }
export function closeHelp(): void { help = null; emit() }
/** shot: posnetek zaslona (data: URL), zajet PRED odprtjem lista; route: zaslon, s katerega je pripomba */
export function openFeedback(o: { shot: string | null; route: string }): void { fb = o; emit() }
export function closeFeedback(): void { fb = null; emit() }

export function useOverlays(): { help: Help; fb: Fb } {
  const [, set] = useState(0)
  useEffect(() => { const f = () => set(x => x + 1); subs.add(f); return () => { subs.delete(f) } }, [])
  return { help, fb }
}
