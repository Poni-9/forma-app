import { Chip } from '@/ui/primitives'
import { RPE_LEVELS } from '@/domain/coach/rpe'

/**
 * »Kako je šlo?« v eni vrsti: pet stopenj občutka (RPE). Tap na izbrano stopnjo jo pobriše.
 * Izbrana je stopnja, ki je najbližje vpisani vrednosti (tudi starejši vpisi 1–10).
 */
export function RateRow({ value, onPick, label = 'Občutek' }: { value: number | null | undefined; onPick: (v: number | null) => void; label?: string }) {
  const cur = value == null ? null : RPE_LEVELS.reduce((b, x) => (Math.abs(x[0] - value) < Math.abs(b[0] - value) ? x : b))[0]
  return (
    <div className="ci-row rate" role="group" aria-label="Kako je šlo — občutek napora">
      <span className="muted">{label}</span>
      {RPE_LEVELS.map(([v, l]) => <Chip key={v} sm on={cur === v} onClick={() => onPick(cur === v ? null : v)}>{l}</Chip>)}
    </div>
  )
}
