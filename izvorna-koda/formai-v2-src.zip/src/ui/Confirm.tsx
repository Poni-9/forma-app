import { useCallback, useEffect, useRef, useState, useSyncExternalStore, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import { Btn, Sheet } from './primitives'

/* =====================================================================
   Potrditev v aplikaciji (namesto window.confirm) in obvestilo z »Razveljavi«.
   - Nepovratno (izbris vseh podatkov, računa): useConfirm → list z jasnim gumbom.
   - Izbris obroka, aktivnosti, testa: deferDelete → zapis takoj izgine, izbriše se čez 5 s, razen ob »Razveljavi«.
     Izbrisanega nikoli ne dodajamo nazaj (nagrobniki bi to preprečili) — samo zakasnimo izbris.
   - Sprememba načrta (Sestavi znova, AI prilagodi): undoToast s prejšnjimi dnevi.
   ===================================================================== */

export interface ConfirmOpts {
  title: string
  text?: ReactNode
  /** besedilo potrditvenega gumba (glagol: »Izbriši«, »Odstrani«) */
  ok: string
  cancel?: string
  /** rdeč gumb za uničujoča dejanja */
  danger?: boolean
}

const DANGER = { background: 'var(--bad)', color: 'var(--accent-ink)' }

export function ConfirmSheet({ open, title, text, ok, cancel = 'Prekliči', danger, onOk, onCancel }: ConfirmOpts & { open: boolean; onOk: () => void; onCancel: () => void }) {
  return (
    <Sheet open={open} onClose={onCancel} label={title}>
      <b style={{ display: 'block', fontSize: 17, letterSpacing: '-.02em' }}>{title}</b>
      {text ? <p style={{ fontSize: 13, marginTop: 6, lineHeight: 1.5 }}>{text}</p> : null}
      <Btn primary block style={{ marginTop: 16, ...(danger ? DANGER : null) }} onClick={onOk}>{ok}</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={onCancel}>{cancel}</Btn>
    </Sheet>
  )
}

/** `const { confirm, sheet } = useConfirm()` → `if (await confirm({ title, ok })) …`; `sheet` izriši v zaslonu. */
export function useConfirm(): { confirm: (o: ConfirmOpts) => Promise<boolean>; sheet: ReactNode } {
  const [req, setReq] = useState<ConfirmOpts | null>(null)
  const pend = useRef<((v: boolean) => void) | null>(null)
  useEffect(() => () => { pend.current?.(false); pend.current = null }, [])
  const confirm = useCallback((o: ConfirmOpts) => new Promise<boolean>(resolve => {
    pend.current?.(false)
    pend.current = resolve
    setReq(o)
  }), [])
  const done = (v: boolean) => { const r = pend.current; pend.current = null; setReq(null); r?.(v) }
  const sheet = <ConfirmSheet open={!!req} title={req?.title ?? ''} text={req?.text} ok={req?.ok ?? ''} cancel={req?.cancel} danger={req?.danger} onOk={() => done(true)} onCancel={() => done(false)} />
  return { confirm, sheet }
}

/* ---------- obvestilo z »Razveljavi« ---------- */
type Fn = () => unknown
interface UndoItem { id: number; msg: string; undo: Fn; expire?: Fn; ms: number }
let cur: UndoItem | null = null
let timer: ReturnType<typeof setTimeout> | null = null
let seq = 0, owner: number | null = null, hostSeq = 0
let snap: { item: UndoItem | null; owner: number | null } = { item: null, owner: null }
const subs = new Set<() => void>()
function emit() { snap = { item: cur, owner }; for (const f of subs) f() }
const subscribe = (f: () => void) => { subs.add(f); return () => { subs.delete(f) } }
const run = (f?: Fn) => { if (f) void Promise.resolve().then(f).catch(() => undefined) }

function settle(item: UndoItem | null, how: 'undo' | 'expire'): void {
  if (!item) return
  if (cur === item) { cur = null; if (timer) { clearTimeout(timer); timer = null } emit() }
  run(how === 'undo' ? item.undo : item.expire)
}

/**
 * Obvestilo z gumbom »Razveljavi«. Novo obvestilo zaključi prejšnje (njegov onExpire se izvede takoj).
 * Na zaslonu je vidno, kjer je izrisan <UndoHost /> (en naenkrat).
 */
export function undoToast(msg: string, undo: Fn, opts: { ms?: number; onExpire?: Fn } = {}): void {
  settle(cur, 'expire')
  const item: UndoItem = { id: ++seq, msg, undo, expire: opts.onExpire, ms: opts.ms ?? 5000 }
  cur = item
  timer = setTimeout(() => settle(item, 'expire'), item.ms)
  emit()
}

/* ---------- zakasnjen izbris ---------- */
const hidden = new Set<string>()
let hiddenSnap: ReadonlySet<string> = new Set()
const hidSubs = new Set<() => void>()
function setHidden(key: string, on: boolean) {
  if (on) hidden.add(key); else hidden.delete(key)
  hiddenSnap = new Set(hidden)
  for (const f of hidSubs) f()
}
const pending = new Map<string, () => Promise<void>>()

/**
 * Izbris z »Razveljavi«: `key` (npr. »meal:ID«) je takoj skrit (useHidden), `commit` (izbris v shrambi) teče po `ms`,
 * razen če uporabnik tapne »Razveljavi«. Ob zaprtju ali skritju aplikacije se čakajoči izbrisi izvedejo takoj.
 */
export function deferDelete(key: string, msg: string, commit: () => unknown, ms = 5000): void {
  if (pending.has(key)) return
  setHidden(key, true)
  let done = false
  const go = async () => {
    if (done) return
    done = true; pending.delete(key)
    try { await commit() } finally { setHidden(key, false) }
  }
  pending.set(key, go)
  wireFlush()
  undoToast(msg, () => { if (done) return; done = true; pending.delete(key); setHidden(key, false) }, { ms, onExpire: go })
}

/** Ključi, ki čakajo na izbris — seznami jih takoj skrijejo (in jih ne štejejo v vsote). */
export function useHidden(): ReadonlySet<string> {
  return useSyncExternalStore(f => { hidSubs.add(f); return () => { hidSubs.delete(f) } }, () => hiddenSnap, () => hiddenSnap)
}

/** Izvede vse čakajoče izbrise zdaj (aplikacija gre v ozadje ali se zapira). */
export function flushDeletes(): void {
  for (const go of [...pending.values()]) void go()
  if (cur && cur.expire) settle(cur, 'expire')
}
let wired = false
function wireFlush() {
  if (wired || typeof window === 'undefined') return
  wired = true
  window.addEventListener('pagehide', flushDeletes)
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flushDeletes() })
}

/**
 * Prikaz obvestila z »Razveljavi«. Lahko je izrisan na več mestih (zaslon in koren aplikacije) — prikaže se samo prvi.
 * Pozicija je enaka navadnemu obvestilu (razred .toast), gumb je dovolj velik za prst.
 */
export function UndoHost() {
  const me = useRef(0)
  if (!me.current) me.current = ++hostSeq
  const s = useSyncExternalStore(subscribe, () => snap, () => snap)
  useEffect(() => { if (owner == null) { owner = me.current; emit() } })
  useEffect(() => () => { if (owner === me.current) { owner = null; emit() } }, [])
  if (s.owner !== me.current || !s.item || typeof document === 'undefined') return null
  const item = s.item
  return createPortal(
    <div key={item.id} className="toast undo" role="status" aria-live="polite" style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '6px 6px 6px 16px', zIndex: 72, width: 'max-content' }}>
      <span style={{ minWidth: 0, flex: 1 }}>{item.msg}</span>
      <button type="button" className="btn xs" onClick={() => settle(item, 'undo')} style={{ flex: 'none', minHeight: 40, background: 'transparent', color: 'var(--accent)', padding: '8px 12px' }}>Razveljavi</button>
    </div>,
    document.body,
  )
}

/** samo za teste */
export function _resetUndo(): void {
  if (timer) clearTimeout(timer)
  timer = null; cur = null; pending.clear(); hidden.clear(); hiddenSnap = new Set(); emit()
  for (const f of hidSubs) f()
}
