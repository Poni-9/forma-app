import { useCallback, useEffect, useRef, useState, useSyncExternalStore, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import { Btn, Sheet } from './primitives'
import { rem } from '@/ui/rem'

/* =====================================================================
   Potrditev v aplikaciji (namesto window.confirm) in obvestilo z »Razveljavi«.
   - Nepovratno (izbris vseh podatkov, računa): useConfirm → list z jasnim gumbom.
   - Izbris obroka, aktivnosti, testa: deferDelete → zapis takoj izgine, izbriše se čez 5 s, razen ob »Razveljavi«.
     Izbrisanega nikoli ne dodajamo nazaj (nagrobniki bi to preprečili) — samo zakasnimo izbris.
   - Sprememba načrta (Sestavi znova, AI prilagodi): undoToast s prejšnjimi dnevi.
   ===================================================================== */

export interface ConfirmOpts {
  title: string
  text?: ReactNode
  /** besedilo potrditvenega gumba (glagol: »Izbriši«, »Odstrani«) */
  ok: string
  cancel?: string
  /** rdeč gumb za uničujoča dejanja */
  danger?: boolean
}

const DANGER = { background: 'var(--bad)', color: 'var(--accent-ink)' }

export function ConfirmSheet({ open, title, text, ok, cancel = 'Prekliči', danger, onOk, onCancel }: ConfirmOpts & { open: boolean; onOk: () => void; onCancel: () => void }) {
  return (
    <Sheet open={open} onClose={onCancel} label={title}>
      <h2 className="sheet-t">{title}</h2>
      {text ? <p style={{ fontSize: rem(13), marginTop: 6, lineHeight: 1.5 }}>{text}</p> : null}
      <Btn primary block style={{ marginTop: 16, ...(danger ? DANGER : null) }} onClick={onOk}>{ok}</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={onCancel}>{cancel}</Btn>
    </Sheet>
  )
}

/** `const { confirm, sheet } = useConfirm()` → `if (await confirm({ title, ok })) …`; `sheet` izriši v zaslonu. */
export function useConfirm(): { confirm: (o: ConfirmOpts) => Promise<boolean>; sheet: ReactNode } {
  const [req, setReq] = useState<ConfirmOpts | null>(null)
  const pend = useRef<((v: boolean) => void) | null>(null)
  useEffect(() => () => { pend.current?.(false); pend.current = null }, [])
  const confirm = useCallback((o: ConfirmOpts) => new Promise<boolean>(resolve => {
    pend.current?.(false)
    pend.current = resolve
    setReq(o)
  }), [])
  const done = (v: boolean) => { const r = pend.current; pend.current = null; setReq(null); r?.(v) }
  const sheet = <ConfirmSheet open={!!req} title={req?.title ?? ''} text={req?.text} ok={req?.ok ?? ''} cancel={req?.cancel} danger={req?.danger} onOk={() => done(true)} onCancel={() => done(false)} />
  return { confirm, sheet }
}

/* ---------- obvestilo z »Razveljavi« ---------- */
type Fn = () => unknown
interface UndoItem { id: number; msg: string; undo: Fn; expire?: Fn; ms: number }
let cur: UndoItem | null = null
let timer: ReturnType<typeof setTimeout> | null = null
let seq = 0, owner: number | null = null, hostSeq = 0
let snap: { item: UndoItem | null; owner: number | null } = { item: null, owner: null }
const subs = new Set<() => void>()
function emit() { snap = { item: cur, owner }; for (const f of subs) f() }
const subscribe = (f: () => void) => { subs.add(f); return () => { subs.delete(f) } }
const run = (f?: Fn) => { if (f) void Promise.resolve().then(f).catch(() => undefined) }

function settle(item: UndoItem | null, how: 'undo' | 'expire'): void {
  if (!item) return
  if (cur === item) { cur = null; if (timer) { clearTimeout(timer); timer = null } emit() }
  run(how === 'undo' ? item.undo : item.expire)
}

/**
 * Obvestilo z gumbom »Razveljavi«. Novo obvestilo zaključi prejšnje (njegov onExpire se izvede takoj).
 * Na zaslonu je vidno, kjer je izrisan <UndoHost /> (en naenkrat).
 */
export function undoToast(msg: string, undo: Fn, opts: { ms?: number; onExpire?: Fn } = {}): void {
  settle(cur, 'expire')
  const item: UndoItem = { id: ++seq, msg, undo, expire: opts.onExpire, ms: opts.ms ?? 5000 }
  cur = item
  timer = setTimeout(() => settle(item, 'expire'), item.ms)
  emit()
}
/**
 * (v3.51) Dokler je fokus ali kazalec na obvestilu, čas ne teče (WCAG 2.2.1); ko gre stran, ima še vsaj 4 s.
 * Prej je obvestilo izginilo po 8 s, tudi med tem, ko si ga s tipkovnico iskal.
 */
export function holdUndo(on: boolean): void {
  const item = cur
  if (!item) return
  if (timer) { clearTimeout(timer); timer = null }
  if (!on) timer = setTimeout(() => settle(item, 'expire'), Math.max(4000, Math.round(item.ms / 2)))
}
/** (v3.51) Ctrl+Z (⌘Z) razveljavi, dokler je obvestilo vidno — razen med tipkanjem v polje. */
export function undoKey(e: Pick<KeyboardEvent, 'key' | 'ctrlKey' | 'metaKey' | 'shiftKey' | 'altKey' | 'target'>): boolean {
  if (!cur || e.key.toLowerCase() !== 'z' || !(e.ctrlKey || e.metaKey) || e.shiftKey || e.altKey) return false
  const t = e.target as HTMLElement | null
  if (t && (/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName) || t.isContentEditable)) return false
  settle(cur, 'undo')
  return true
}
/** zadnja vrsta vnosa: tipkovnica → fokus na »Razveljavi« (z dotikom in miško fokus ostane, kjer je) */
let viaKeys = false
if (typeof document !== 'undefined') {
  document.addEventListener('keydown', e => { if (e.key === 'Tab' || e.key === 'Enter' || e.key === ' ') viaKeys = true }, true)
  document.addEventListener('pointerdown', () => { viaKeys = false }, true)
}

/* ---------- zakasnjen izbris ---------- */
const hidden = new Set<string>()
let hiddenSnap: ReadonlySet<string> = new Set()
const hidSubs = new Set<() => void>()
function setHidden(key: string, on: boolean) {
  if (on) hidden.add(key); else hidden.delete(key)
  hiddenSnap = new Set(hidden)
  for (const f of hidSubs) f()
}
const pending = new Map<string, () => Promise<void>>()

/**
 * Izbris z »Razveljavi«: `key` (npr. »meal:ID«) je takoj skrit (useHidden), `commit` (izbris v shrambi) teče po `ms`,
 * razen če uporabnik tapne »Razveljavi«. Ob zaprtju ali skritju aplikacije se čakajoči izbrisi izvedejo takoj.
 */
export function deferDelete(key: string, msg: string, commit: () => unknown, ms = 5000): void {
  if (pending.has(key)) return
  setHidden(key, true)
  let done = false
  const go = async () => {
    if (done) return
    done = true; pending.delete(key)
    try { await commit() } finally { setHidden(key, false) }
  }
  pending.set(key, go)
  wireFlush()
  undoToast(msg, () => { if (done) return; done = true; pending.delete(key); setHidden(key, false) }, { ms, onExpire: go })
}

/** Ključi, ki čakajo na izbris — seznami jih takoj skrijejo (in jih ne štejejo v vsote). */
export function useHidden(): ReadonlySet<string> {
  return useSyncExternalStore(f => { hidSubs.add(f); return () => { hidSubs.delete(f) } }, () => hiddenSnap, () => hiddenSnap)
}

/** Izvede vse čakajoče izbrise zdaj (aplikacija gre v ozadje ali se zapira). */
export function flushDeletes(): void {
  for (const go of [...pending.values()]) void go()
  if (cur && cur.expire) settle(cur, 'expire')
}
let wired = false
function wireFlush() {
  if (wired || typeof window === 'undefined') return
  wired = true
  window.addEventListener('pagehide', flushDeletes)
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flushDeletes() })
}

/**
 * Prikaz obvestila z »Razveljavi«. Lahko je izrisan na več mestih (zaslon in koren aplikacije) — prikaže se samo prvi.
 * Pozicija je enaka navadnemu obvestilu (razred .toast), gumb je dovolj velik za prst.
 */
export function UndoHost() {
  const me = useRef(0)
  if (!me.current) me.current = ++hostSeq
  const s = useSyncExternalStore(subscribe, () => snap, () => snap)
  useEffect(() => { if (owner == null) { owner = me.current; emit() } })
  useEffect(() => () => { if (owner === me.current) { owner = null; emit() } }, [])
  // (v3.51) dejanje s tipkovnico (npr. premor v listu): ko se list zapre, fokus na »Razveljavi« — prej 34 Tab daleč
  const btn = useRef<HTMLButtonElement | null>(null)
  const id = s.owner === me.current ? s.item?.id : undefined
  useEffect(() => {
    if (id == null || !viaKeys) return
    let n = 0
    const t = setInterval(() => {
      const a = document.activeElement as HTMLElement | null
      if (++n > 20 || !btn.current) { clearInterval(t); return }
      if (document.querySelector('.sheet')) return               // list se še zapira
      clearInterval(t)
      if (a && a !== document.body && (/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) || a.isContentEditable)) return
      btn.current.focus()
    }, 50)
    return () => clearInterval(t)
  }, [id])
  useEffect(() => {
    if (id == null) return
    const on = (e: KeyboardEvent) => { if (undoKey(e)) e.preventDefault() }
    document.addEventListener('keydown', on)
    return () => document.removeEventListener('keydown', on)
  }, [id])
  if (s.owner !== me.current || !s.item || typeof document === 'undefined') return null
  const item = s.item
  // (v3.50) v sklad obvestil (Toasts), kot zadnje: prej je stalo na istem mestu in prekrilo napako, ki ostane vidna
  const host = document.querySelector<HTMLElement>('.toast-stack') ?? document.body
  return createPortal(
    <div key={item.id} className="toast undo" role="status" aria-live="polite" style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '6px 6px 6px 16px', zIndex: 72, width: 'max-content' }}
      onPointerEnter={() => holdUndo(true)} onPointerLeave={() => holdUndo(false)} onFocus={() => holdUndo(true)} onBlur={() => holdUndo(false)}>
      <span style={{ minWidth: 0, flex: 1 }}>{item.msg}</span>
      <button ref={btn} type="button" className="btn xs" aria-keyshortcuts="Control+Z" onClick={() => settle(item, 'undo')} style={{ flex: 'none', minHeight: 40, background: 'transparent', color: 'var(--accent-fg)', padding: '8px 12px' }}>Razveljavi</button>
    </div>,
    host,
  )
}

/** samo za teste */
export function _resetUndo(): void {
  if (timer) clearTimeout(timer)
  timer = null; cur = null; pending.clear(); hidden.clear(); hiddenSnap = new Set(); emit()
  for (const f of hidSubs) f()
}
