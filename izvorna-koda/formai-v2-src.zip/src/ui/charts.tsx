import { useId } from 'react'

/* Lahki SVG grafi brez zunanjih knjižnic.
   Vsi so odzivni (viewBox + width 100 %) in vsi prenesejo prazno polje. */

const MON_SL = ['jan', 'feb', 'mar', 'apr', 'maj', 'jun', 'jul', 'avg', 'sep', 'okt', 'nov', 'dec']

/** Prazno stanje grafa — enak videz povsod. */
function NoData({ height, text = 'Ni dovolj podatkov' }: { height: number; text?: string }) {
  return (
    <div style={{ height, display: 'grid', placeItems: 'center', background: 'var(--raised)', borderRadius: 'var(--r-m)', color: 'var(--ink-3)', fontSize: 12, fontWeight: 700 }}>
      {text}
    </div>
  )
}

/** Lepe okrogle vrednosti za os Y (1 / 2 / 5 × 10ⁿ). */
function niceTicks(lo: number, hi: number, count = 4): number[] {
  if (!Number.isFinite(lo) || !Number.isFinite(hi) || hi <= lo) return []
  const raw = (hi - lo) / Math.max(1, count)
  const mag = Math.pow(10, Math.floor(Math.log10(raw)))
  const norm = raw / mag
  const step = (norm <= 1 ? 1 : norm <= 2 ? 2 : norm <= 5 ? 5 : 10) * mag
  const out: number[] = []
  for (let v = Math.ceil(lo / step) * step; v <= hi + step / 1000; v += step) out.push(Math.round(v * 100) / 100)
  return out
}

/** Številka za oznako: nad 10 zaokroženo, pod 10 z eno decimalko, vejica kot ločilo. */
function fmtVal(v: number): string {
  if (!Number.isFinite(v)) return '—'
  const r = Math.abs(v) >= 10 ? Math.round(v) : Math.round(v * 10) / 10
  return String(r).replace('.', ',')
}

/* ------------------------------------------------------------------ */
/* Forma: CTL / ATL / TSB                                              */
/* ------------------------------------------------------------------ */

export function FormChart({ data, height = 190 }: { data: { date: string; ctl: number; atl: number; tsb: number }[]; height?: number }) {
  const raw = useId()
  const uid = raw.replace(/[^a-zA-Z0-9]/g, '')

  if (data.length < 2) return <NoData height={height} />

  const W = 360, H = Math.max(140, height)
  const padL = 28, padR = 8, padT = 10, padB = 20
  const iw = W - padL - padR, ih = H - padT - padB

  let lo = 0, hi = 0
  for (const d of data) {
    lo = Math.min(lo, d.tsb, d.ctl, d.atl)
    hi = Math.max(hi, d.tsb, d.ctl, d.atl)
  }
  if (hi - lo < 10) hi = lo + 10
  const air = (hi - lo) * 0.08
  lo -= air
  hi += air

  const x = (i: number) => padL + (i / (data.length - 1)) * iw
  const y = (v: number) => padT + ih - ((v - lo) / (hi - lo)) * ih
  const y0 = Math.max(padT, Math.min(padT + ih, y(0)))

  const line = (pick: (d: { ctl: number; atl: number; tsb: number }) => number) =>
    data.map((d, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)} ${y(pick(d)).toFixed(1)}`).join(' ')

  const tsbLine = line(d => d.tsb)
  const area = `${tsbLine} L${x(data.length - 1).toFixed(1)} ${y0.toFixed(1)} L${x(0).toFixed(1)} ${y0.toFixed(1)} Z`

  const yTicks = niceTicks(lo, hi, 4)

  const xTicks: { i: number; label: string }[] = []
  for (let i = 0; i < data.length; i++) {
    const d = data[i]
    if (!d) continue
    const prev = data[i - 1]
    const m = d.date.slice(5, 7)
    if (!prev || prev.date.slice(5, 7) !== m) xTicks.push({ i, label: MON_SL[Number(m) - 1] ?? '' })
  }

  const last = data[data.length - 1]

  return (
    <div>
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} role="img" aria-label={`Graf forme za ${data.length} dni: kondicija, utrujenost in forma`} style={{ display: 'block', overflow: 'visible' }}>
        <title>Kondicija (CTL), utrujenost (ATL) in forma (TSB) skozi čas</title>
        <defs>
          <clipPath id={`${uid}-up`}><rect x={padL} y={padT} width={iw} height={Math.max(0, y0 - padT)} /></clipPath>
          <clipPath id={`${uid}-dn`}><rect x={padL} y={y0} width={iw} height={Math.max(0, padT + ih - y0)} /></clipPath>
        </defs>

        {yTicks.map(t => (
          <g key={`y${t}`}>
            <line x1={padL} y1={y(t)} x2={W - padR} y2={y(t)} stroke="var(--line)" strokeWidth="1" />
            <text x={padL - 5} y={y(t) + 3} textAnchor="end" fontSize="9" fontWeight="700" fill="var(--ink-3)">{fmtVal(t)}</text>
          </g>
        ))}

        <path d={area} fill="var(--ok)" opacity=".24" clipPath={`url(#${uid}-up)`} />
        <path d={area} fill="var(--bad)" opacity=".24" clipPath={`url(#${uid}-dn)`} />
        <line x1={padL} y1={y0} x2={W - padR} y2={y0} stroke="var(--ink-3)" strokeWidth="1" strokeDasharray="3 3" opacity=".7" />

        <path d={line(d => d.atl)} fill="none" stroke="var(--t-moc)" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" opacity=".9" />
        <path d={line(d => d.ctl)} fill="none" stroke="var(--t-kolo)" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />

        {last && <circle cx={x(data.length - 1)} cy={y(last.ctl)} r="3" fill="var(--t-kolo)" />}

        {xTicks.map(t => (
          <text key={`x${t.i}`} x={x(t.i)} y={H - 5} textAnchor="middle" fontSize="9" fontWeight="700" fill="var(--ink-3)">{t.label}</text>
        ))}
      </svg>

      <div className="row" style={{ gap: 14, flexWrap: 'wrap', marginTop: 8, fontSize: 11, fontWeight: 700, color: 'var(--ink-3)' }}>
        <span className="row" style={{ gap: 6 }}><i style={{ display: 'block', width: 14, height: 3, borderRadius: 2, background: 'var(--t-kolo)' }} />Kondicija (CTL)</span>
        <span className="row" style={{ gap: 6 }}><i style={{ display: 'block', width: 14, height: 2, borderRadius: 2, background: 'var(--t-moc)' }} />Utrujenost (ATL)</span>
        <span className="row" style={{ gap: 6 }}>
          <i style={{ display: 'block', width: 14, height: 8, borderRadius: 2, background: 'linear-gradient(var(--ok), var(--bad))', opacity: .45 }} />Forma (TSB)
        </span>
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Navpični stolpci                                                    */
/* ------------------------------------------------------------------ */

export function BarChart({ bars, height = 160, unit = '' }: { bars: { label: string; value: number; color?: string }[]; height?: number; unit?: string }) {
  if (!bars.length) return <NoData height={height} />

  const W = 360, H = Math.max(110, height)
  const padT = 14, padB = 18, padX = 4
  const iw = W - padX * 2, ih = H - padT - padB
  const slot = iw / bars.length
  const bw = Math.min(30, slot * 0.62)

  let max = 0
  for (const b of bars) max = Math.max(max, b.value)
  const scale = max > 0 ? ih / max : 0

  const every = bars.length > 8 ? 2 : 1
  const total = bars.reduce((s, b) => s + b.value, 0)

  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} role="img" aria-label={`Stolpčni graf, ${bars.length} stolpcev, skupaj ${fmtVal(total)}${unit ? ' ' + unit : ''}`} style={{ display: 'block', overflow: 'visible' }}>
      <title>{`Razporeditev po ${bars.length} kategorijah`}</title>
      <line x1={padX} y1={padT + ih} x2={W - padX} y2={padT + ih} stroke="var(--line)" strokeWidth="1" />
      {bars.map((b, i) => {
        const h = Math.max(b.value > 0 ? 2 : 0, b.value * scale)
        const cx = padX + slot * i + slot / 2
        const showLabel = (bars.length - 1 - i) % every === 0
        return (
          <g key={`${b.label}-${i}`}>
            <rect x={cx - bw / 2} y={padT + ih - h} width={bw} height={h} rx="3" fill={b.color || 'var(--t-kolo)'} opacity={b.value > 0 ? 1 : .35} />
            {b.value > 0 && <text x={cx} y={padT + ih - h - 4} textAnchor="middle" fontSize="9" fontWeight="800" fill="var(--ink-2)">{fmtVal(b.value)}</text>}
            {showLabel && <text x={cx} y={H - 5} textAnchor="middle" fontSize="9" fontWeight="700" fill="var(--ink-3)">{b.label}</text>}
          </g>
        )
      })}
    </svg>
  )
}

/* ------------------------------------------------------------------ */
/* Cone                                                                */
/* ------------------------------------------------------------------ */

const ZONE_COLORS = ['var(--t-poc)', 'var(--t-kolo)', 'var(--t-tek)', 'var(--warn)', 'var(--t-moc)', 'var(--bad)', 'var(--bad)']

export function ZoneBars({ zones }: { zones: { key: string; name: string; lo: number; hi: number; minutes: number }[] }) {
  if (!zones.length) return <NoData height={120} />

  let max = 0
  for (const z of zones) max = Math.max(max, z.minutes)
  const total = zones.reduce((s, z) => s + z.minutes, 0)

  return (
    <div className="stack" style={{ gap: 10 }} role="img" aria-label={`Razporeditev časa po ${zones.length} conah, skupaj ${Math.round(total)} minut`}>
      {zones.map((z, i) => {
        const pct = max > 0 ? (z.minutes / max) * 100 : 0
        const share = total > 0 ? Math.round((z.minutes / total) * 100) : 0
        return (
          <div key={z.key} style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
            <div className="between" style={{ fontSize: 12, fontWeight: 700 }}>
              <span><b style={{ color: ZONE_COLORS[i] ?? 'var(--t-poc)' }}>{z.key}</b> <span style={{ color: 'var(--ink-2)' }}>{z.name}</span></span>
              <span className="muted" style={{ fontWeight: 600 }}>{z.lo}–{z.hi}</span>
            </div>
            <div className="track"><i style={{ width: `${Math.max(0, Math.min(100, pct))}%`, background: ZONE_COLORS[i] ?? 'var(--t-poc)' }} /></div>
            <div className="muted" style={{ fontSize: 11, fontWeight: 600 }}>{z.minutes > 0 ? `${Math.round(z.minutes)} min · ${share} %` : 'brez zabeleženega časa'}</div>
          </div>
        )
      })}
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Točke + gladka črta (teža, spanec) z referenčno črto (cilj)         */
/* ------------------------------------------------------------------ */

export function DotLineChart({ points, line, reference, refLabel, height = 170, decimals = 1, unit = '', minZero = false, pointLabel = 'dnevno', lineLabel = '7-dnevno povprečje' }: {
  points: { date: string; v: number }[]; line?: { date: string; v: number }[]; reference?: number | null; refLabel?: string
  height?: number; decimals?: number; unit?: string; minZero?: boolean; pointLabel?: string; lineLabel?: string
}) {
  if (points.length < 2 && !(line && line.length >= 2)) return <NoData height={height} text="Za graf rabim vsaj dve meritvi" />
  const all = [...points, ...(line || [])]
  const dates = [...new Set(all.map(p => p.date))].sort()
  const d0 = new Date(dates[0]!).getTime(), d1 = new Date(dates[dates.length - 1]!).getTime()
  const span = Math.max(86400_000, d1 - d0)
  const W = 360, H = Math.max(130, height), padL = 32, padR = 8, padT = 10, padB = 20
  const iw = W - padL - padR, ih = H - padT - padB
  let lo = Math.min(...all.map(p => p.v), reference ?? Infinity), hi = Math.max(...all.map(p => p.v), reference ?? -Infinity)
  if (minZero) lo = Math.min(0, lo)
  if (hi - lo < 1) { hi += 0.5; lo -= 0.5 }
  const air = (hi - lo) * 0.1; lo -= air; hi += air
  const x = (date: string) => padL + ((new Date(date).getTime() - d0) / span) * iw
  const y = (v: number) => padT + ih - ((v - lo) / (hi - lo)) * ih
  const ticks = niceTicks(lo, hi, 4)
  const fmt = (v: number) => (decimals ? v.toFixed(decimals) : String(Math.round(v))).replace('.', ',')
  const xl = [dates[0]!, dates[Math.floor(dates.length / 2)]!, dates[dates.length - 1]!].filter((v, i, a) => a.indexOf(v) === i)
  const lp = line && line.length >= 2 ? line.map((p, i) => `${i ? 'L' : 'M'}${x(p.date).toFixed(1)} ${y(p.v).toFixed(1)}`).join(' ') : null
  const lastL = line && line.length ? line[line.length - 1]! : null
  return (
    <div>
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} role="img" aria-label={`Graf, ${points.length} meritev`} style={{ display: 'block', overflow: 'visible' }}>
        {ticks.map(t => (
          <g key={`y${t}`}>
            <line x1={padL} y1={y(t)} x2={W - padR} y2={y(t)} stroke="var(--line)" strokeWidth="1" />
            <text x={padL - 5} y={y(t) + 3} textAnchor="end" fontSize="9" fontWeight="700" fill="var(--ink-3)">{fmt(t)}</text>
          </g>
        ))}
        {reference != null && <line x1={padL} y1={y(reference)} x2={W - padR} y2={y(reference)} stroke="var(--ink-3)" strokeWidth="1.2" strokeDasharray="4 4" />}
        {points.map((p, i) => <circle key={i} cx={x(p.date)} cy={y(p.v)} r="2.6" fill="var(--ink-3)" opacity=".75" />)}
        {lp && <path d={lp} fill="none" stroke="var(--accent)" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />}
        {lastL && <circle cx={x(lastL.date)} cy={y(lastL.v)} r="3.2" fill="var(--accent)" />}
        {xl.map(d => <text key={d} x={x(d)} y={H - 5} textAnchor={d === dates[0] ? 'start' : d === dates[dates.length - 1] ? 'end' : 'middle'} fontSize="9" fontWeight="700" fill="var(--ink-3)">{`${+d.slice(8)}. ${+d.slice(5, 7)}.`}</text>)}
      </svg>
      <div className="row" style={{ gap: 14, flexWrap: 'wrap', marginTop: 8, fontSize: 11, fontWeight: 700, color: 'var(--ink-3)' }}>
        <span className="row" style={{ gap: 6 }}><i style={{ display: 'block', width: 7, height: 7, borderRadius: 9, background: 'var(--ink-3)' }} />{pointLabel}</span>
        {lp && <span className="row" style={{ gap: 6 }}><i style={{ display: 'block', width: 14, height: 3, borderRadius: 2, background: 'var(--accent)' }} />{lineLabel}</span>}
        {reference != null && <span className="row" style={{ gap: 6 }}><i style={{ display: 'block', width: 14, height: 0, borderTop: '1.5px dashed var(--ink-3)' }} />{refLabel || 'cilj'} {fmt(reference)}{unit ? ' ' + unit : ''}</span>}
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Naloženi stolpci (ure po športih na teden)                          */
/* ------------------------------------------------------------------ */

export function StackBars({ bars, legend, height = 150, unit = '' }: { bars: { label: string; parts: { v: number; color: string }[] }[]; legend: { label: string; color: string }[]; height?: number; unit?: string }) {
  const totals = bars.map(b => b.parts.reduce((s, p) => s + p.v, 0))
  if (!bars.length || Math.max(...totals) <= 0) return <NoData height={height} />
  const W = 360, H = Math.max(110, height), padL = 26, padR = 4, padT = 12, padB = 18
  const iw = W - padL - padR, ih = H - padT - padB
  const max = Math.max(...totals)
  const ticks = niceTicks(0, max, 3)
  const top = Math.max(max, ticks[ticks.length - 1] || max)
  const y = (v: number) => padT + ih - (v / top) * ih
  const slot = iw / bars.length, bw = Math.min(26, slot * 0.64)
  const every = bars.length > 8 ? 3 : 1
  return (
    <div>
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} role="img" aria-label={`Naloženi stolpci, ${bars.length} obdobij${unit ? ', ' + unit : ''}`} style={{ display: 'block', overflow: 'visible' }}>
        {ticks.map(t => (
          <g key={`y${t}`}>
            <line x1={padL} y1={y(t)} x2={W - padR} y2={y(t)} stroke="var(--line)" strokeWidth="1" />
            <text x={padL - 5} y={y(t) + 3} textAnchor="end" fontSize="9" fontWeight="700" fill="var(--ink-3)">{fmtVal(t)}</text>
          </g>
        ))}
        {bars.map((b, i) => {
          const cx = padL + slot * i + slot / 2
          let acc = 0
          return (
            <g key={i}>
              {b.parts.filter(p => p.v > 0).map((p, j) => {
                const y1 = y(acc + p.v), y0 = y(acc); acc += p.v
                return <rect key={j} x={cx - bw / 2} y={y1} width={bw} height={Math.max(0, y0 - y1 - 1.5)} rx="3" fill={p.color} />
              })}
              {(bars.length - 1 - i) % every === 0 && <text x={cx} y={H - 5} textAnchor="middle" fontSize="9" fontWeight="700" fill="var(--ink-3)">{b.label}</text>}
            </g>
          )
        })}
      </svg>
      <div className="row" style={{ gap: 14, flexWrap: 'wrap', marginTop: 8, fontSize: 11, fontWeight: 700, color: 'var(--ink-3)' }}>
        {legend.map(l => <span key={l.label} className="row" style={{ gap: 6 }}><i style={{ display: 'block', width: 9, height: 9, borderRadius: 3, background: l.color }} />{l.label}</span>)}
      </div>
    </div>
  )
}
