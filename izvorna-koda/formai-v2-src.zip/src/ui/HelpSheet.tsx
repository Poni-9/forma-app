import { useEffect, useRef, useState, type ReactNode } from 'react'
import { helpFor, type TermKey } from '@/domain/glossary'
import { useApp } from '@/state/store'
import { Btn, Sheet } from '@/ui/primitives'
import { Guide } from '@/ui/Guide'
import { closeHelp, openFeedback, openHelp, setFeedbackShot, overlayState } from '@/ui/overlays'
import { captureScreen } from '@/data/feedback'
import { parseHash } from '@/app/router'

/**
 * »Kako deluje« v 7 korakih + slovar izrazov. Odpre se z »?« v glavi ali s tapom na izraz (takrat se pomakne do
 * njega in ga označi). Iz lista: »Pošlji pripombo« in »Tvoj cilj po korakih« (vodnik s tvojimi številkami).
 */
export function HelpSheet({ term }: { term: TermKey | null }) {
  const [guide, setGuide] = useState(false)
  // načrt po meri brez kolesa: splošna različica (v3.48) — brez dirke, voženj, FTP in W/kg
  const { how, terms } = helpFor(useApp().profile, term)
  const hit = useRef<HTMLDivElement>(null)
  useEffect(() => { if (term && hit.current && typeof hit.current.scrollIntoView === 'function') hit.current.scrollIntoView({ block: 'center' }) }, [term])
  return (<>
    <Sheet open onClose={closeHelp} label={term ? 'Kaj pomeni' : 'Kako deluje'}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>{term ? 'Kaj pomeni' : 'Kako deluje FORMAI'}</b>
      {!term && (
        <ol className="how">
          {how.map((h, i) => <li key={i}><b>{h.t}</b><span>{h.d}</span></li>)}
        </ol>
      )}
      <h3 className="h4" style={{ marginTop: term ? 10 : 16 }}>Izrazi</h3>
      <div className="terms">
        {terms.map(x => (
          <div key={x.k} ref={x.k === term ? hit : undefined} className={`term-row${x.k === term ? ' hit' : ''}`}>
            <b>{x.t}</b><span>{x.d}</span>
          </div>
        ))}
      </div>
      <div className="row" style={{ gap: 8, marginTop: 14, flexWrap: 'wrap' }}>
        <Btn sm onClick={() => { closeHelp(); setTimeout(() => void startFeedback(), 60) }}>Pošlji pripombo</Btn>
        <Btn sm ghost onClick={() => setGuide(true)}>Tvoj cilj po korakih</Btn>
      </div>
      <Btn ghost block style={{ marginTop: 10 }} onClick={closeHelp}>Zapri</Btn>
    </Sheet>
    {guide && <Guide open onClose={() => setGuide(false)} />}
  </>)
}

/** Izraz v besedilu: tap → razlaga (list Kako deluje, pomaknjen na izraz). Ne uporabljaj znotraj drugega gumba. */
export function Term({ k, children, label }: { k: TermKey; children: ReactNode; label?: string }) {
  const name = label || (typeof children === 'string' ? children : 'izraz')
  return <button type="button" className="term" onClick={e => { e.stopPropagation(); openHelp(k) }} aria-label={`${name} — kaj pomeni?`}>{children}</button>
}

/**
 * Pripomba z gumba. (v3.50) List se odpre TAKOJ, posnetek zaslona (to, kar uporabnik vidi — brez lista) se zajame v
 * ozadju in pride v list, ko je gotov; prej je bilo na srednjem telefonu 6,7–8 s brez odziva, v svetli temi je posnetek
 * odpovedal. Dvojni tap ne zajema dvakrat.
 */
let shooting = false
const painted = () => new Promise<void>(r => { if (typeof requestAnimationFrame === 'function') requestAnimationFrame(() => setTimeout(r, 0)); else setTimeout(r, 16) })
export async function startFeedback(): Promise<void> {
  const route = parseHash().name || 'danes'
  openFeedback({ shot: null, route, capturing: true })
  if (shooting) return
  shooting = true
  try {
    await painted()
    const shot = overlayState().fb ? await captureScreen(15_000).catch(() => null) : null
    setFeedbackShot(shot)
  } finally { shooting = false }
}
