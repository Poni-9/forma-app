import { useEffect, useRef, useState, type ReactNode } from 'react'
import { HOW, TERMS, type TermKey } from '@/domain/glossary'
import { Btn, Sheet } from '@/ui/primitives'
import { Guide } from '@/ui/Guide'
import { closeHelp, openFeedback, openHelp } from '@/ui/overlays'
import { captureScreen } from '@/data/feedback'
import { parseHash } from '@/app/router'

/**
 * »Kako deluje« v 7 korakih + slovar izrazov. Odpre se z »?« v glavi ali s tapom na izraz (takrat se pomakne do
 * njega in ga označi). Iz lista: »Pošlji pripombo« in »Tvoj cilj po korakih« (vodnik s tvojimi številkami).
 */
export function HelpSheet({ term }: { term: TermKey | null }) {
  const [guide, setGuide] = useState(false)
  const hit = useRef<HTMLDivElement>(null)
  useEffect(() => { if (term && hit.current && typeof hit.current.scrollIntoView === 'function') hit.current.scrollIntoView({ block: 'center' }) }, [term])
  return (<>
    <Sheet open onClose={closeHelp} label={term ? 'Kaj pomeni' : 'Kako deluje'}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>{term ? 'Kaj pomeni' : 'Kako deluje FORMAI'}</b>
      {!term && (
        <ol className="how">
          {HOW.map((h, i) => <li key={i}><b>{h.t}</b><span>{h.d}</span></li>)}
        </ol>
      )}
      <h3 className="h4" style={{ marginTop: term ? 10 : 16 }}>Izrazi</h3>
      <div className="terms">
        {TERMS.map(x => (
          <div key={x.k} ref={x.k === term ? hit : undefined} className={`term-row${x.k === term ? ' hit' : ''}`}>
            <b>{x.t}</b><span>{x.d}</span>
          </div>
        ))}
      </div>
      <div className="row" style={{ gap: 8, marginTop: 14, flexWrap: 'wrap' }}>
        <Btn sm onClick={() => { closeHelp(); setTimeout(() => void startFeedback(), 60) }}>Pošlji pripombo</Btn>
        <Btn sm ghost onClick={() => setGuide(true)}>Tvoj cilj po korakih</Btn>
      </div>
      <Btn ghost block style={{ marginTop: 10 }} onClick={closeHelp}>Zapri</Btn>
    </Sheet>
    {guide && <Guide open onClose={() => setGuide(false)} />}
  </>)
}

/** Izraz v besedilu: tap → razlaga (list Kako deluje, pomaknjen na izraz). Ne uporabljaj znotraj drugega gumba. */
export function Term({ k, children, label }: { k: TermKey; children: ReactNode; label?: string }) {
  const name = label || (typeof children === 'string' ? children : 'izraz')
  return <button type="button" className="term" onClick={e => { e.stopPropagation(); openHelp(k) }} aria-label={`${name} — kaj pomeni?`}>{children}</button>
}

/** Pripomba z gumba: najprej posnetek zaslona (to, kar uporabnik vidi), nato list. */
let shooting = false
export async function startFeedback(): Promise<void> {
  if (shooting) return
  shooting = true
  const route = parseHash().name || 'danes'
  try {
    const shot = await captureScreen().catch(() => null)
    openFeedback({ shot, route })
  } finally { shooting = false }
}
