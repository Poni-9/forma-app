import { useState } from 'react'
import { useApp, setSick, endSick, extendSick } from '@/state/store'
import { Sheet, Btn, Card, Chip, KindIcon } from '@/ui/primitives'
import { addDays } from '@/domain/training/load'
import { dayGen, count, W } from '@/ui/format'

const DAYS = [1, 2, 3, 5] as const

/** »Bolan sem«: koliko dni počitka (od danes). Treningi se shranijo, prehrana je brez deficita. */
export function SickSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const app = useApp()
  const [n, setN] = useState<number>(2)
  const [busy, setBusy] = useState(false)
  return (
    <Sheet open={open} onClose={onClose} label="Bolan sem">
      <b style={{ display: 'block', fontSize: 17, letterSpacing: '-.02em' }}>Bolan sem — počitek</b>
      <p style={{ fontSize: 13, marginTop: 6, lineHeight: 1.5 }}>Treningi v teh dneh postanejo počitek in se shranijo — z »Spet zdrav« se vrnejo. Kalorije so ta čas brez deficita (telo rabi energijo za ozdravitev). Na uro gre spremenjeni teden sam.</p>
      <div className="row" role="group" aria-label="Koliko dni počitka" style={{ gap: 8, marginTop: 14, flexWrap: 'wrap' }}>
        {DAYS.map(d => <Chip key={d} on={n === d} onClick={() => setN(d)}>{count(d, W.dan)}</Chip>)}
      </div>
      <div className="muted" style={{ fontSize: 12, marginTop: 8 }}>Počitek do vključno {dayGen(addDays(app.today, n - 1))}. Lahko podaljšaš ali končaš prej.</div>
      <p className="muted" style={{ fontSize: 11.5, marginTop: 10 }}>FORMAI ni zdravniški nasvet. Ob vročini, bolečini v prsih, težkem dihanju ali če ne gre na bolje, se posvetuj z zdravnikom.</p>
      <Btn primary block style={{ marginTop: 16 }} disabled={busy} onClick={async () => { setBusy(true); await setSick(n); setBusy(false); onClose() }}>Počitek za {count(n, W.danT)}</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Prekliči</Btn>
    </Sheet>
  )
}

/** Danes med boleznijo: namesto treninga — do kdaj, kaj zdaj, »Spet zdrav« in »+1 dan«. */
export function SickCard() {
  const app = useApp()
  const s = app.profile.sick
  const [busy, setBusy] = useState(false)
  if (!s) return null
  return (
    <Card className="sess spot" style={{ marginTop: 12, ['--c' as string]: 'var(--t-poc)' }}>
      <div className="kbadge"><span className="ki"><KindIcon kind="pocitek" /></span>Bolezen · počitek</div>
      <div className="ttl">Počitek do {s.to === app.today ? 'konca dneva' : `vključno ${dayGen(s.to)}`}</div>
      <p style={{ fontSize: 13, marginTop: 6 }}>Spanec, tekočina, lahka hrana. Treningi so shranjeni in se vrnejo z »Spet zdrav«; kalorije so do takrat brez deficita.</p>
      <p className="muted" style={{ fontSize: 12, marginTop: 6 }}>Po bolezni začni z lahkimi vožnjami. Ob vročini, bolečini v prsih ali težkem dihanju se posvetuj z zdravnikom.</p>
      <div className="row" style={{ gap: 8, marginTop: 13, flexWrap: 'wrap' }}>
        <Btn primary sm disabled={busy} onClick={async () => { setBusy(true); await endSick(); setBusy(false) }}>Spet zdrav</Btn>
        <Btn ghost sm disabled={busy} onClick={async () => { setBusy(true); await extendSick(); setBusy(false) }}>+1 dan</Btn>
      </div>
    </Card>
  )
}
