import { Fragment, useMemo } from 'react'
import { mdBlocks, type Inline } from '@/domain/ai/md'

const inl = (c: Inline[]) => c.map((x, i) => (x.b ? <b key={i}>{x.t}</b> : <Fragment key={i}>{x.t}</Fragment>))

/**
 * (v3.49) Odgovor trenerja: krepko, naslovi (krepka vrstica) in seznami namesto surovih »**«, »###«, »* «.
 * Samo besedilo prek Reacta — oznake HTML in povezave se nikoli ne izvedejo (mdBlocks jih odstrani).
 */
export function CoachText({ text }: { text: string }) {
  const blocks = useMemo(() => mdBlocks(text), [text])
  return (
    <div className="md">
      {blocks.map((b, i) => !('items' in b) ? <p key={i} className={b.k === 'h' ? 'md-h' : undefined}>{inl(b.c)}</p>
        : b.k === 'ul' ? <ul key={i}>{b.items.map((it, j) => <li key={j}>{inl(it)}</li>)}</ul>
        : <ol key={i}>{b.items.map((it, j) => <li key={j}>{inl(it)}</li>)}</ol>)}
    </div>
  )
}
