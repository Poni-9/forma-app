import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import '@/styles/build.css'
import type { Focus, PlanDay, Profile } from '@/domain/types'
import { getState, toast } from '@/state/store'
import { askJson } from '@/domain/ai/client'
import { exercisesPrompt, parseExercises, strategyPrompt, parseStrategy, type Basics } from '@/domain/ai/focusAi'
import { ruleStrategy } from '@/domain/focus/rules'
import { profileFromFocus, AIM_LABEL, MUSCLE_NAME, EQUIP_LABEL, LEVEL_LABEL, weekLine, mixLine } from '@/domain/focus/model'
import { EXERCISES, equipFor, limitsOf, type Limit } from '@/domain/training/exercises'
import { buildWeek, weekContext } from '@/domain/training/planner'
import { addDays, weekStartIso, fmtDur } from '@/domain/training/load'
import { dailyTarget, bmr } from '@/domain/nutrition/energy'
import { kindColor, kindInk, DAYS_SL } from '@/ui/primitives'
import { IcoCheck } from '@/ui/icons'
import { TABS } from '@/app/Shell'
import { BodyMap } from '@/ui/BodyMap'
import { focusLevels } from '@/ui/DealCard'
import { int, num } from '@/ui/format'

/**
 * SESTAVLJANJE APLIKACIJE (Blaž: »da se aplikacija pred mano sestavi kot Transformerji — kakšno minuto, dve, kolikor
 * rabiš, da naložiš vse«). V okvirju telefona so najprej prazna mesta (načrt), nato vsak del pripelje svoje plošče,
 * ki se zavrtijo in zaklenejo (glava s ciljem, teden, prvi trening z vajami, obroč kalorij, 12 tednov, strategija,
 * zavihki). Vsak korak RES dela: energija iz njegovih podatkov, AI izbere vaje iz knjižnice in napiše strategijo,
 * sestavi se prvi teden. Najkrajši čas korakov je za pripoved (~1 min); brez AI ali ob napaki gredo vaje in strategija
 * po pravilih. Zmanjšano gibanje: brez animacij in kratko.
 */
type StageKey = 'cilji' | 'energija' | 'vaje' | 'teden' | 'bloki' | 'strategija' | 'zasloni'
interface Stage { key: StageKey; label: string; min: number }
const STAGES: Stage[] = [
  { key: 'cilji', label: 'Berem tvoje cilje', min: 7500 },
  { key: 'energija', label: 'Računam energijo in beljakovine', min: 8500 },
  { key: 'vaje', label: 'Izbiram vaje zate', min: 12000 },
  { key: 'teden', label: 'Sestavljam prvi teden', min: 9000 },
  { key: 'bloki', label: 'Načrtujem 12 tednov', min: 7500 },
  { key: 'strategija', label: 'Pišem tvojo strategijo', min: 10000 },
  { key: 'zasloni', label: 'Sestavljam aplikacijo', min: 8000 },
]
const AI_WAIT = 55_000
const TICK_MS = 1500
/** »Izpuščam vaje, ki obremenijo …« */
const LIMIT_ACC: Record<Limit, string> = { koleno: 'koleno', hrbet: 'hrbet', rama: 'ramo' }
const sleep = (ms: number) => new Promise<void>(r => setTimeout(r, ms))
const reduced = () => typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches
function timeout<T>(p: Promise<T>, ms: number): Promise<T> { return Promise.race([p, new Promise<T>((_, rej) => setTimeout(() => rej(new Error('čas')), ms))]) }
const clip = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1).trimEnd()} …` : s)
const dow = (iso: string) => (new Date(`${iso}T12:00:00`).getDay() + 6) % 7
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1)

export interface BuildShowProps {
  focus: Focus
  basics: Basics
  /** AI je na voljo (prijava, privolitev, odziva se) — sicer takoj pravila */
  ai: boolean
  /** shrani dogovor (profil, načrt) — teče med zaključno animacijo */
  onSave: (f: Focus) => Promise<void>
  /** po zaključku: v aplikacijo */
  onDone: () => void
}

export function BuildShow({ focus, basics, ai, onSave, onDone }: BuildShowProps) {
  const st = getState()
  const today = st.today
  const ws = weekStartIso(today)
  const calm = useRef(reduced()).current
  const fast = useRef(false)
  const [stage, setStage] = useState(-1)
  const [log, setLog] = useState<StageKey[]>([])
  const [exDone, setExDone] = useState<Focus | null>(null)
  const [strat, setStrat] = useState<string | null>(null)
  const [end, setEnd] = useState(false)
  const [out, setOut] = useState(false)
  const [failed, setFailed] = useState<Focus | null>(null)
  const [skipShown, setSkipShown] = useState(false)
  const [fit, setFit] = useState({ k: 1, wide: false })

  /* ---------- osnutek profila in prehrana (resnični izračun) ---------- */
  const draft: Profile = useMemo(() => {
    const clean = Object.fromEntries(Object.entries({ sex: basics.sex ?? null, age: basics.age, heightCm: basics.heightCm, weightKg: basics.weightKg }).filter(([, v]) => v != null)) as Partial<Profile>
    const base = { ...st.profile, ...clean }
    return { ...base, ...profileFromFocus(focus, base, ws, today) } as Profile
  }, [])   // eslint-disable-line react-hooks/exhaustive-deps
  const twoWeeks = (p: Profile): PlanDay[] => [
    ...buildWeek({ profile: p, activities: st.activities, weekStart: ws, notBefore: today }),
    ...buildWeek({ profile: p, activities: st.activities, weekStart: addDays(ws, 7), notBefore: addDays(ws, 7) }),
  ]
  const week0 = useMemo(() => twoWeeks(draft), [draft])   // eslint-disable-line react-hooks/exhaustive-deps
  const firstDay = week0.find(d => d.date >= today && d.kind !== 'pocitek')
  const nut = useMemo(() => {
    const rest = dailyTarget(draft, [], [], today, { today, hour: 8 })
    const train = firstDay ? dailyTarget(draft, [], week0.filter(d => d.date === firstDay.date), firstDay.date, { today, hour: 8 }) : null
    return { rest: rest?.kcal ?? null, train: train?.kcal ?? null, protein: rest?.proteinG ?? null, deficit: rest?.deficit ?? 0, maint: rest?.maintenance ?? null, floor: rest?.floor ?? null, bmr: bmr(draft) }
  }, [draft])   // eslint-disable-line react-hooks/exhaustive-deps
  const nutIn = { kcal: nut.rest, proteinG: nut.protein, deficit: nut.deficit }

  /* ---------- AI: izbor vaj in strategija (vzporedno, z rezervo po pravilih) ---------- */
  const strength = focus.sessions.some(s => s.type === 'fitnes' || s.type === 'doma')
  const jobs = useMemo(() => {
    const byRules = (): Focus => ({ ...focus, strategy: ruleStrategy(focus, nutIn) })
    const ex: Promise<Focus> = strength && ai
      ? timeout(askJson<unknown>(exercisesPrompt(focus, basics)), AI_WAIT).then(r => parseExercises(r, focus)).catch(() => focus)
      : Promise.resolve(focus)
    const sg: Promise<Focus> = ai
      ? timeout(askJson<unknown>(strategyPrompt(focus, basics, nutIn)), AI_WAIT).then(r => parseStrategy(r, focus)).then(f => (f.strategy ? f : byRules())).catch(byRules)
      : Promise.resolve(byRules())
    return { ex, sg }
  }, [])   // eslint-disable-line react-hooks/exhaustive-deps

  // teden z vajami, ki jih je izbral AI
  const [week, setWeek] = useState<PlanDay[]>(week0)
  useEffect(() => { void jobs.ex.then(f => { setExDone(f); setWeek(twoWeeks({ ...draft, focus: f })) }) }, [])   // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { void jobs.sg.then(f => setStrat(f.strategy ?? null)) }, [])   // eslint-disable-line react-hooks/exhaustive-deps

  /* ---------- potek ---------- */
  const merge = (ex: Focus, sg: Focus): Focus => ({
    ...focus,
    sessions: focus.sessions.map((s, i) => ({ ...s, ...(ex.sessions[i]?.ex ? { ex: ex.sessions[i]!.ex } : {}), why: ex.sessions[i]?.why || sg.sessions[i]?.why || s.why || null })),
    strategy: sg.strategy ?? null,
  })
  async function save(final: Focus, dead: () => boolean) {
    setFailed(null)
    const t = Date.now()
    try { await onSave(final) } catch {
      setFailed(final)
      toast('Načrta ni bilo mogoče shraniti. Poskusi znova.', 'err', 6000)
      return
    }
    const rest = (calm || fast.current ? 500 : 2400) - (Date.now() - t)
    if (rest > 0) await sleep(rest)
    if (dead()) return
    setOut(true)
    await sleep(calm ? 0 : 650)
    if (!dead()) onDone()
  }
  const deadRef = useRef(false)
  useEffect(() => {
    deadRef.current = false
    let dead = false
    void (async () => {
      for (let i = 0; i < STAGES.length; i++) {
        if (dead) return
        setStage(i)
        const s = STAGES[i]!
        const work = s.key === 'vaje' ? jobs.ex : s.key === 'strategija' ? jobs.sg : null
        const min = calm ? Math.min(1200, s.min) : s.min
        const t = Date.now()
        // najkrajši čas koraka (pripoved) — po »Preskoči« samo še čakanje na delo
        while (!dead && Date.now() - t < min && !fast.current) await sleep(100)
        if (work) await work
        if (dead) return
        setLog(l => [...l, s.key])
      }
      const [ex, sg] = await Promise.all([jobs.ex, jobs.sg])
      if (dead) return
      setEnd(true)
      await save(merge(ex, sg), () => dead)
    })()
    return () => { dead = true; deadRef.current = true }
  }, [])   // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { const t = setTimeout(() => setSkipShown(true), 6000); return () => clearTimeout(t) }, [])
  const [reelHold, setReelHold] = useState(true)
  const vajeOn = STAGES[stage]?.key === 'vaje'
  useEffect(() => {
    if (!vajeOn) return
    const t = setTimeout(() => setReelHold(false), fast.current ? 600 : 4800)
    return () => clearTimeout(t)
  }, [vajeOn])
  // okvir telefona se prilagodi zaslonu (telefon, ležeče, namizje: telefon levo, potek desno)
  useEffect(() => {
    const f = () => {
      const w = innerWidth, h = innerHeight, wide = w >= 900 && h >= 560
      const k = wide ? Math.min(1, (h - 64) / 700) : Math.min(1, (h - 214) / 700, (w - 28) / 380)
      setFit({ k: Math.max(0.5, Math.round(k * 1000) / 1000), wide })
    }
    f(); addEventListener('resize', f); return () => removeEventListener('resize', f)
  }, [])

  /* ---------- podatki za prikaz ---------- */
  const gymDay = week.find(d => d.date >= today && d.kind === 'moc') ?? null
  const heroDay = (strength ? gymDay : null) ?? week.find(d => d.date >= today && d.kind !== 'pocitek') ?? null
  const chosen = (heroDay?.exercises || []).slice(0, 4)
  const available = useMemo(() => {
    const eq = new Set([...(focus.sessions.some(s => s.type === 'fitnes') ? equipFor('fitnes', focus.equipment) : []), ...(focus.sessions.some(s => s.type === 'doma') ? equipFor('doma', focus.equipment) : [])])
    return EXERCISES.filter(e => eq.has(e.eq))
  }, [focus])
  // »reža«: vaje iz knjižnice se vrtijo, dokler AI (ali pravila) ne izbere
  const reel = useMemo(() => available.slice(0, 36), [available])
  const allEx = new Set(week.flatMap(d => (d.exercises || []).map(e => e.name)))
  const days7 = Array.from({ length: 7 }, (_, i) => addDays(today, i))
  const dayItems = (d: string) => week.filter(x => x.date === d && x.kind !== 'pocitek')
  const maxMin = Math.max(30, ...days7.map(d => dayItems(d).reduce((t, x) => t + x.durationMin, 0)))
  const blocks = useMemo(() => Array.from({ length: 12 }, (_, i) => weekContext(draft, addDays(ws, 7 * i))), [draft, ws])
  const aims = [...focus.aims.map(a => AIM_LABEL[a]), ...focus.muscles.slice(0, 2).map(m => MUSCLE_NAME[m])].slice(0, 4)
  // zemljevid mišic: poudarek sveti močno, kar trenirajo seje (moč po delih telesa, tek in kolo noge) zmerno
  const bodyLevels = useMemo(() => focusLevels(focus), [focus])
  const cardioN = week.filter(d => d.date >= today && d.date <= addDays(today, 6) && d.kind !== 'pocitek' && d.kind !== 'moc').length
  const ix = (k: StageKey) => STAGES.findIndex(s => s.key === k)
  const on = (k: StageKey) => stage >= ix(k)
  const now = (k: StageKey) => !end && STAGES[stage]?.key === k
  const cur = STAGES[Math.max(0, stage)]!
  // reža se vrti vsaj nekaj sekund, tudi če je AI vaje izbral že prej — nato se ustavi na izbranih
  const spin = now('vaje') && (!exDone || reelHold) && !calm

  function stageLabel(s: Stage): string {
    if (s.key === 'vaje' && !strength) return 'Nastavljam kardio in cone'
    return s.label
  }
  function resultLine(k: StageKey): string {
    switch (k) {
      case 'cilji': return `Cilji: ${aims.join(' · ') || focus.title}`
      case 'energija': return nut.rest ? `Energija: ~${int(nut.rest)} kcal${nut.train && nut.train !== nut.rest ? ` (dan vadbe ~${int(nut.train)})` : ''}${nut.protein ? `, beljakovine ${nut.protein} g` : ''}` : 'Energija: dopolni težo in višino za kalorije'
      case 'vaje': return strength ? `Vaje: ${allEx.size || chosen.length} izbranih iz ${available.length}` : `Kardio: ${cardioN} treningov na teden`
      case 'teden': return `Prvi teden: ${weekLine(focus)}`
      case 'bloki': return '12 tednov: 3 bloki, vsak 4. teden lažji'
      case 'strategija': return 'Strategija napisana'
      default: return 'Aplikacija sestavljena'
    }
  }
  /** kaj se ta trenutek dogaja (vrti se med korakom) — vse iz resničnih podatkov */
  function ticks(k: StageKey): string[] {
    switch (k) {
      case 'cilji': return [
        focus.wish ? `»${clip(focus.wish.replace(/\s+/g, ' '), 70)}«` : '',
        `Šport: ${mixLine(focus)}`,
        focus.aims.length ? `Cilji: ${focus.aims.map(a => AIM_LABEL[a]).join(', ')}` : '',
        focus.muscles.length ? `Poudarek: ${focus.muscles.map(m => MUSCLE_NAME[m]).join(', ')}` : '',
        focus.keepMuscle ? 'Med hujšanjem ohraniti mišice' : '',
        `Raven: ${LEVEL_LABEL[focus.level]}`,
        focus.limits ? `Pazim na: ${clip(focus.limits, 50)}` : '',
      ].filter(Boolean)
      case 'energija': return [
        nut.bmr ? `Bazalni metabolizem ~${int(nut.bmr)} kcal` : 'Brez teže in višine — kalorije dopolniš pozneje',
        nut.maint ? `Vzdrževanje brez vadbe ~${int(nut.maint)} kcal` : '',
        nut.bmr ? (nut.deficit > 0 ? `Primanjkljaj ${nut.deficit} kcal na dan${focus.keepMuscle ? ' — zmerno, da mišice ostanejo' : ''}` : basics.age != null && basics.age < 18 ? 'Do 18. leta brez primanjkljaja' : 'Brez primanjkljaja') : '',
        nut.protein ? `Beljakovine ${nut.protein} g na dan` : '',
        nut.floor ? `Varno dno ${int(nut.floor)} kcal — nikoli manj` : '',
        nut.train && nut.rest && nut.train !== nut.rest ? `Dan vadbe ~${int(nut.train)} kcal — gorivo pred vadbo` : '',
      ].filter(Boolean)
      case 'vaje': return strength ? [
        `Oprema: ${focus.equipment.map(e => EQUIP_LABEL[e]).join(', ')}`,
        `Knjižnica: ${available.length} vaj`,
        ...limitsOf(focus.limits).map(l => `Izpuščam vaje, ki obremenijo ${LIMIT_ACC[l]}`),
        ai ? (exDone ? 'AI je izbral vaje za tvoj cilj' : 'AI izbira vaje za tvoj cilj …') : 'Izbiram po pravilih za tvoj cilj',
        ...chosen.map(e => `✓ ${e.name} · ${e.sets} × ${e.reps}`),
      ] : week.filter(d => d.date >= today && d.kind !== 'pocitek').slice(0, 5).map(d => `${cap(DAYS_SL[dow(d.date)]!)} · ${d.title}`)
      case 'teden': return days7.flatMap(d => dayItems(d).map(x => `${cap(DAYS_SL[dow(d)]!)} · ${x.title} · ${fmtDur(x.durationMin)}`))
      case 'bloki': return ['Teden 1: nov blok — tehnika in navada', 'Teden 2–3: rast — malo več', 'Teden 4: lažji — telo se okrepi', 'Teden 5: nov blok — višje teže', 'Vsak blok se prilagodi temu, kar narediš']
      case 'strategija': return strat ? strat.split('\n').map(l => l.replace(/^[–-]\s*/, '').trim()).filter(Boolean).map(l => clip(l, 80)) : [ai ? 'AI piše strategijo zate …' : 'Pišem strategijo …']
      default: return TABS.map(t => `${t.label} ✓`)
    }
  }
  const pct = end ? 100 : Math.round(((Math.max(0, stage) + 0.5) / STAGES.length) * 100)

  // v body: .page ima animacijo s transform (fill both), ki bi fiksni položaj zaprla v stran
  return createPortal(
    <div className={`bs${calm ? ' calm' : ''}${end ? ' end' : ''}${out ? ' out' : ''}${fit.wide ? ' wide' : ''}`} aria-busy={!end}>
      <div className="bs-grid" aria-hidden="true" />
      <div className="bs-stagewrap" aria-hidden="true" style={{ ['--k' as string]: fit.k }}>
        <div className="bs-phone">
          <svg className="bs-outline" viewBox="0 0 380 700" preserveAspectRatio="none"><rect x="1" y="1" width="378" height="698" rx="38" /></svg>

          {/* glava: ime načrta in cilji */}
          <Part cls="bs-head" m="split" on={on('cilji')} now={now('cilji')} i={0}>
            <div className="bs-hl">
              <small>Tvoj načrt</small>
              <b><Decode text={focus.title} run={on('cilji')} delay={calm ? 0 : 1500} /></b>
              <div className="bs-aims">{aims.map((a, i) => <span key={a} className="bs-pill" style={{ animationDelay: `${2.3 + i * 0.3}s` }}>{a}</span>)}</div>
            </div>
            <BodyMap levels={bodyLevels} size={78} run={on('cilji') && !calm} delay={3.2} />
          </Part>

          {/* teden: dnevi se zavrtijo na mesto, stolpci zrastejo */}
          <Part cls="bs-week" m="none" on={on('teden')} now={now('teden')} i={1}>
            {days7.map((d, i) => {
              const items = dayItems(d)
              const min = items.reduce((t, x) => t + x.durationMin, 0)
              return (
                <div key={d} className={`bs-day${d === today ? ' today' : ''}`} style={{ animationDelay: `${0.25 + i * 0.14}s` }}>
                  <small>{DAYS_SL[dow(d)]}</small>
                  <span className="bs-col">
                    {items[0]
                      ? <i className="bs-bar" style={{ height: `${Math.max(22, Math.round((min / maxMin) * 100))}%`, background: kindColor(items[0].kind), animationDelay: `${1.2 + i * 0.14}s` }} />
                      : <i className="bs-rest" />}
                  </span>
                </div>
              )
            })}
          </Part>

          {/* prvi trening z vajami */}
          <Part cls="bs-hero" m="unfold" on={on('vaje')} now={now('vaje')} i={2} style={{ ['--c' as string]: heroDay ? kindColor(heroDay.kind) : 'var(--t-moc)', ['--ci' as string]: heroDay ? kindInk(heroDay.kind) : 'var(--t-moc-ink)' }}>
            <small className="bs-kicker">{heroDay ? `${heroDay.kind === 'moc' ? 'MOČ' : heroDay.kind === 'kolo' ? 'KOLO' : 'KARDIO'} · ${heroDay.date === today ? 'DANES' : DAYS_SL[dow(heroDay.date)]!.toUpperCase()}` : ''}</small>
            <b className="bs-ttl"><Decode text={heroDay?.title || ''} run={on('vaje')} delay={calm ? 0 : 1300} /></b>
            {strength ? (
              <div className={`bs-reelbox${spin ? ' spin' : ''}`}>
                {spin ? (
                  <div className="bs-reel">{[...reel, ...reel].map((e, i) => <span key={i}>{e.name}</span>)}</div>
                ) : (
                  <ul className="bs-ex">
                    {chosen.map((e, i) => <li key={e.name} style={{ animationDelay: `${0.15 + i * 0.3}s` }}><span>{e.name}</span><em>{e.sets} × {e.reps}{e.kg ? ` · ${num(e.kg)} kg` : ''}</em></li>)}
                  </ul>
                )}
              </div>
            ) : heroDay ? <p className="bs-desc">{fmtDur(heroDay.durationMin)} · {clip(heroDay.desc, 120)}</p> : null}
            <div className="bs-counter">{strength
              ? <>{available.length} vaj <span aria-hidden="true">→</span> <b>{exDone ? allEx.size || chosen.length : '…'}</b> zate</>
              : <>{cardioN} treningov · {weekLine(focus)}</>}</div>
          </Part>

          {/* obroč kalorij in 12 tednov */}
          <div className="bs-row">
            <Part cls="bs-ring" m="split" on={on('energija')} now={now('energija')} i={3}>
              <svg viewBox="0 0 100 100" className="bs-segs">
                {Array.from({ length: 16 }, (_, i) => <path key={i} d={arc(50, 50, 40, i * 22.5 + 2, i * 22.5 + 20.5)} style={{ animationDelay: `${1.1 + i * 0.09}s` }} />)}
              </svg>
              <div className="bs-ringmid"><b><CountUp to={nut.rest || 0} run={on('energija')} delay={calm ? 0 : 1200} /></b><small>{nut.rest ? 'kcal na dan' : 'kcal'}</small></div>
              <span className="bs-ringsub">{nut.protein ? <>beljakovine <CountUp to={nut.protein} run={on('energija')} delay={calm ? 0 : 1600} /> g</> : 'dopolni težo'}</span>
            </Part>
            <Part cls="bs-blocks" m="splitv" on={on('bloki')} now={now('bloki')} i={4}>
              <small>12 tednov</small>
              <div className="bs-bars">{blocks.map((c, i) => <i key={i} className={c.recovery ? 'easy' : ''} style={{ height: `${Math.round((c.volume / 1.08) * 100)}%`, animationDelay: `${1.1 + i * 0.13}s` }} />)}</div>
              <span className="bs-ringsub">vsak 4. teden lažji</span>
            </Part>
          </div>

          {/* strategija */}
          <Part cls="bs-strat" m="extend" on={on('strategija')} now={now('strategija')} i={5}>
            <small>Tvoja strategija</small>
            <Type text={(strat || '').split('\n').map(l => l.replace(/^[–-]\s*/, '').trim()).filter(Boolean).slice(0, 3).join('\n')} run={on('strategija') && !!strat} delay={calm ? 0 : 1100} />
          </Part>

          {/* zavihki */}
          <Part cls="bs-tabs" m="rise" on={on('zasloni')} now={now('zasloni')} i={6}>
            {TABS.map(({ key, label, Ico }, i) => <span key={key} style={{ animationDelay: `${1.0 + i * 0.22}s` }}><Ico width={19} height={19} /><small>{label}</small></span>)}
          </Part>
          <div className="bs-sweep" />
        </div>
      </div>

      <div className="bs-status" role="status" aria-live="polite">
        <div className="bs-now">
          {end ? <><IcoCheck width={18} height={18} aria-hidden="true" /> {failed ? 'Načrt je pripravljen — shranjevanje ni uspelo' : 'Tvoj FORMAI je pripravljen'}</>
            : <>{stageLabel(cur)}<span className="thinking" aria-hidden="true"><i /><i /><i /></span></>}
        </div>
        {!end && <Ticker items={ticks(cur.key)} />}
        <div className="bs-prog" aria-hidden="true"><i style={{ width: `${pct}%` }} /></div>
        <ul className="bs-log">{log.slice(fit.wide ? -7 : -3).map(k => <li key={k}><IcoCheck width={13} height={13} aria-hidden="true" /> {resultLine(k)}</li>)}</ul>
        {failed && <button type="button" className="btn primary block" style={{ marginTop: 12 }} onClick={() => void save(failed, () => deadRef.current)}>Poskusi znova</button>}
        {skipShown && !end && <button type="button" className="bs-skip" onClick={() => { fast.current = true; setSkipShown(false) }}>Preskoči animacijo</button>}
      </div>
    </div>,
    document.body,
  )
}

/** Del aplikacije: prazno mesto (načrt) → tarča → plošče priletijo in se zaklenejo → vsebina. */
function Part({ cls, m, on, now, i, style, children }: { cls: string; m: 'split' | 'splitv' | 'unfold' | 'extend' | 'rise' | 'none'; on: boolean; now: boolean; i: number; style?: React.CSSProperties; children: ReactNode }) {
  return (
    <div className={`bs-part ${cls} m-${m}${on ? ' on' : ''}${now ? ' now' : ''}`} style={{ ['--i' as string]: i, ...style }}>
      {m !== 'none' && <><i className="bs-plate a" /><i className="bs-plate b" /></>}
      <i className="bs-brk" />
      <div className="bs-in">{children}</div>
    </div>
  )
}

/** Vrstica »kaj delam zdaj«: menja se vsakih 1,5 s. */
function Ticker({ items }: { items: string[] }) {
  const [n, setN] = useState(0)
  const sig = items.join('|')
  useEffect(() => {
    setN(0)
    if (items.length < 2 || reduced()) return
    const id = setInterval(() => setN(x => x + 1), TICK_MS)
    return () => clearInterval(id)
  }, [sig])   // eslint-disable-line react-hooks/exhaustive-deps
  const t = items.length ? items[n % items.length]! : ''
  return <div className="bs-tickbox" aria-hidden="true"><div className="bs-tick" key={`${n}:${t}`}>{t}</div></div>
}

/** lok krožnega izseka (stopinje, 0 = zgoraj) */
function arc(cx: number, cy: number, r: number, a0: number, a1: number): string {
  const p = (a: number) => [cx + r * Math.sin((a * Math.PI) / 180), cy - r * Math.cos((a * Math.PI) / 180)]
  const [x0, y0] = p(a0), [x1, y1] = p(a1)
  return `M ${x0!.toFixed(2)} ${y0!.toFixed(2)} A ${r} ${r} 0 0 1 ${x1!.toFixed(2)} ${y1!.toFixed(2)}`
}

const GLYPHS = 'ABCČDEFGHIJKLMNOPRSŠTUVZŽ0123456789'
/** Besedilo se »razreši« iz naključnih znakov (kot da se sestavlja). */
function Decode({ text, run, delay = 0 }: { text: string; run: boolean; delay?: number }) {
  const [out, setOut] = useState('')
  useEffect(() => {
    if (!run) { setOut(''); return }
    if (reduced()) { setOut(text); return }
    let k = 0, id = 0
    const t = setTimeout(() => {
      id = window.setInterval(() => {
        k += 1
        const fixed = Math.floor(k / 2)
        setOut(text.split('').map((c, i) => (i < fixed || c === ' ' ? c : GLYPHS[(i * 7 + k * 3) % GLYPHS.length]!)).join(''))
        if (fixed >= text.length) clearInterval(id)
      }, 34)
    }, delay)
    return () => { clearTimeout(t); clearInterval(id) }
  }, [text, run])   // eslint-disable-line react-hooks/exhaustive-deps
  return <>{out}</>
}
/** Število šteje do cilja. */
function CountUp({ to, run, delay = 0 }: { to: number; run: boolean; delay?: number }) {
  const [v, setV] = useState(0)
  useEffect(() => {
    if (!run || !to) { setV(run ? to : 0); return }
    if (reduced()) { setV(to); return }
    let raf = 0
    const t = setTimeout(() => {
      const t0 = performance.now(), dur = 1900
      const tick = (x0: number) => { const x = Math.min(1, (x0 - t0) / dur); setV(Math.round(to * (1 - Math.pow(1 - x, 3)))); if (x < 1) raf = requestAnimationFrame(tick) }
      raf = requestAnimationFrame(tick)
    }, delay)
    return () => { clearTimeout(t); cancelAnimationFrame(raf) }
  }, [to, run])   // eslint-disable-line react-hooks/exhaustive-deps
  return <>{int(v)}</>
}
/** Besedilo se tipka. */
function Type({ text, run, delay = 0 }: { text: string; run: boolean; delay?: number }) {
  const [n, setN] = useState(0)
  useEffect(() => {
    if (!run) { setN(0); return }
    if (reduced()) { setN(text.length); return }
    let id = 0
    const t = setTimeout(() => { id = window.setInterval(() => setN(x => { if (x >= text.length) { clearInterval(id); return x } return x + 2 }), 26) }, delay)
    return () => { clearTimeout(t); clearInterval(id) }
  }, [text, run])   // eslint-disable-line react-hooks/exhaustive-deps
  return <p className="bs-type">{text.slice(0, n)}{run && n < text.length && <span className="bs-caret" />}</p>
}
