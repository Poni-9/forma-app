import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import '@/styles/build.css'
import type { AgreedSession, Focus, PlanDay, Profile } from '@/domain/types'
import { getState, toast } from '@/state/store'
import { askJson } from '@/domain/ai/client'
import { exercisesPrompt, parseExercises, strategyPrompt, parseStrategy, type Basics } from '@/domain/ai/focusAi'
import { ruleStrategy, wishSignals, daysIn } from '@/domain/focus/rules'
import { profileFromFocus, AIM_LABEL, MUSCLE_NAME, EQUIP_LABEL, LEVEL_LABEL, weekLine, isStrength, tailsOf, SPORT_LABEL, PART_NAME, CARDIO_LABEL } from '@/domain/focus/model'
import { EXERCISES, equipFor, limitsOf, exByName, type Limit } from '@/domain/training/exercises'
import { pinsWords } from '@/domain/training/focusPlan'
import { buildWeek, weekContext } from '@/domain/training/planner'
import { addDays, weekStartIso, fmtDur } from '@/domain/training/load'
import { dailyTarget, bmr } from '@/domain/nutrition/energy'
import { kindColor, kindInk, DAYS_SL } from '@/ui/primitives'
import { IcoCheck } from '@/ui/icons'
import { TABS } from '@/app/Shell'
import { BodyMap } from '@/ui/BodyMap'
import { focusLevels } from '@/ui/DealCard'
import { weekOf, sessionColor, SessionIcon } from '@/ui/WeekStrip'
import { DAY_OPTS, DAY_NAME } from '@/domain/focus/choices'
import { int, num } from '@/ui/format'

/**
 * SESTAVLJANJE APLIKACIJE (Blaž: »da se aplikacija pred mano sestavi — in da se res vidi, da je vezano na to, kar
 * aplikacija zares dela zame«). Sedem prizorov čez cel zaslon, vsak pokaže resnični izračun iz njegovih podatkov:
 * 1 njegove besede → cilji (označene besede, mišice), 2 njegov teden (dnevi, določeni dnevi, kardio po moči),
 * 3 energija (BMR → vzdrževanje → dan vadbe → primanjkljaj → beljakovine, iz teže, višine, starosti), 4 vaje
 * (knjižnica → oprema → omejitve → izbor AI ali po pravilih za prvi trening), 5 12 tednov (bloki), 6 strategija
 * (AI ali pravila, tipkana), 7 telefon: deli priletijo na mesto in aplikacija se prižge. Brez preskoka; zmanjšano
 * gibanje = isti prizori, kratko in na mestu. AI izbor vaj in strategija tečeta vzporedno od začetka (rezerva: pravila).
 */
type StageKey = 'cilji' | 'teden' | 'energija' | 'vaje' | 'bloki' | 'strategija' | 'zasloni'
interface Stage { key: StageKey; label: string; min: number }
const STAGES: Stage[] = [
  { key: 'cilji', label: 'Berem tvoje besede', min: 9500 },
  { key: 'teden', label: 'Sestavljam tvoj teden', min: 8500 },
  { key: 'energija', label: 'Računam tvojo energijo', min: 9500 },
  { key: 'vaje', label: 'Izbiram vaje zate', min: 10500 },
  { key: 'bloki', label: 'Načrtujem 12 tednov', min: 6500 },
  { key: 'strategija', label: 'Pišem tvojo strategijo', min: 9000 },
  { key: 'zasloni', label: 'Sestavljam aplikacijo', min: 8500 },
]
const AI_WAIT = 55_000
/** »Izpuščam vaje, ki obremenijo …« */
const LIMIT_ACC: Record<Limit, string> = { koleno: 'koleno', hrbet: 'hrbet', rama: 'ramo' }
const sleep = (ms: number) => new Promise<void>(r => setTimeout(r, ms))
const reduced = () => typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches
function timeout<T>(p: Promise<T>, ms: number): Promise<T> { return Promise.race([p, new Promise<T>((_, rej) => setTimeout(() => rej(new Error('čas')), ms))]) }
const clip = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1).trimEnd()} …` : s)
const dow = (iso: string) => (new Date(`${iso}T12:00:00`).getDay() + 6) % 7
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1)

export interface BuildShowProps {
  focus: Focus
  basics: Basics
  /** AI je na voljo (prijava, privolitev, odziva se) — sicer takoj pravila */
  ai: boolean
  /** shrani dogovor (profil, načrt) — teče med zaključno animacijo */
  onSave: (f: Focus) => Promise<void>
  /** po zaključku: v aplikacijo */
  onDone: () => void
}

export function BuildShow({ focus, basics, ai, onSave, onDone }: BuildShowProps) {
  const st = getState()
  const today = st.today
  const ws = weekStartIso(today)
  const calm = useRef(reduced()).current
  const [stage, setStage] = useState(-1)
  const [log, setLog] = useState<StageKey[]>([])
  const [exDone, setExDone] = useState<Focus | null>(null)
  const [strat, setStrat] = useState<string | null>(null)
  const [end, setEnd] = useState(false)
  const [out, setOut] = useState(false)
  const [failed, setFailed] = useState<Focus | null>(null)
  const [fit, setFit] = useState({ k: 1 })

  /* ---------- osnutek profila in prehrana (resnični izračun) ---------- */
  const draft: Profile = useMemo(() => {
    const clean = Object.fromEntries(Object.entries({ sex: basics.sex ?? null, age: basics.age, heightCm: basics.heightCm, weightKg: basics.weightKg }).filter(([, v]) => v != null)) as Partial<Profile>
    const base = { ...st.profile, ...clean }
    return { ...base, ...profileFromFocus(focus, base, ws, today) } as Profile
  }, [])   // eslint-disable-line react-hooks/exhaustive-deps
  const twoWeeks = (p: Profile): PlanDay[] => [
    ...buildWeek({ profile: p, activities: st.activities, weekStart: ws, notBefore: today }),
    ...buildWeek({ profile: p, activities: st.activities, weekStart: addDays(ws, 7), notBefore: addDays(ws, 7) }),
  ]
  const week0 = useMemo(() => twoWeeks(draft), [draft])   // eslint-disable-line react-hooks/exhaustive-deps
  const firstDay = week0.find(d => d.date >= today && d.kind !== 'pocitek')
  const nut = useMemo(() => {
    const rest = dailyTarget(draft, [], [], today, { today, hour: 8 })
    const train = firstDay ? dailyTarget(draft, [], week0.filter(d => d.date === firstDay.date), firstDay.date, { today, hour: 8 }) : null
    return { rest: rest?.kcal ?? null, train: train?.kcal ?? null, protein: rest?.proteinG ?? null, carbs: rest?.carbsG ?? null, fat: rest?.fatG ?? null, deficit: rest?.deficit ?? 0, maint: rest?.maintenance ?? null, floor: rest?.floor ?? null, bmr: bmr(draft), burn: train ? train.plannedBurn : 0 }
  }, [draft])   // eslint-disable-line react-hooks/exhaustive-deps
  const nutIn = { kcal: nut.rest, proteinG: nut.protein, deficit: nut.deficit }

  /* ---------- AI: izbor vaj in strategija (vzporedno, z rezervo po pravilih) ---------- */
  const strength = focus.sessions.some(isStrength)
  const jobs = useMemo(() => {
    const byRules = (): Focus => ({ ...focus, strategy: ruleStrategy(focus, nutIn) })
    const ex: Promise<Focus> = strength && ai
      ? timeout(askJson<unknown>(exercisesPrompt(focus, basics)), AI_WAIT).then(r => parseExercises(r, focus)).catch(() => focus)
      : Promise.resolve(focus)
    const sg: Promise<Focus> = ai
      ? timeout(askJson<unknown>(strategyPrompt(focus, basics, nutIn)), AI_WAIT).then(r => parseStrategy(r, focus)).then(f => (f.strategy ? f : byRules())).catch(byRules)
      : Promise.resolve(byRules())
    return { ex, sg }
  }, [])   // eslint-disable-line react-hooks/exhaustive-deps

  // teden z vajami, ki jih je izbral AI
  const [week, setWeek] = useState<PlanDay[]>(week0)
  useEffect(() => { void jobs.ex.then(f => { setExDone(f); setWeek(twoWeeks({ ...draft, focus: f })) }) }, [])   // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { void jobs.sg.then(f => setStrat(f.strategy ?? null)) }, [])   // eslint-disable-line react-hooks/exhaustive-deps

  /* ---------- potek ---------- */
  const merge = (ex: Focus, sg: Focus): Focus => ({
    ...focus,
    sessions: focus.sessions.map((s, i) => ({ ...s, ...(ex.sessions[i]?.ex ? { ex: ex.sessions[i]!.ex } : {}), why: ex.sessions[i]?.why || sg.sessions[i]?.why || s.why || null })),
    strategy: sg.strategy ?? null,
  })
  async function save(final: Focus, dead: () => boolean) {
    setFailed(null)
    const t = Date.now()
    try { await onSave(final) } catch {
      setFailed(final)
      toast('Načrta ni bilo mogoče shraniti. Poskusi znova.', 'err', 6000)
      return
    }
    const rest = (calm ? 500 : 2600) - (Date.now() - t)
    if (rest > 0) await sleep(rest)
    if (dead()) return
    setOut(true)
    await sleep(calm ? 0 : 650)
    if (!dead()) onDone()
  }
  const deadRef = useRef(false)
  useEffect(() => {
    deadRef.current = false
    let dead = false
    void (async () => {
      for (let i = 0; i < STAGES.length; i++) {
        if (dead) return
        setStage(i)
        const s = STAGES[i]!
        const work = s.key === 'vaje' ? jobs.ex : s.key === 'strategija' ? jobs.sg : null
        const min = calm ? Math.min(1400, s.min) : s.min
        const t = Date.now()
        while (!dead && Date.now() - t < min) await sleep(100)
        if (work) await work
        if (dead) return
        setLog(l => [...l, s.key])
      }
      const [ex, sg] = await Promise.all([jobs.ex, jobs.sg])
      if (dead) return
      setEnd(true)
      await save(merge(ex, sg), () => dead)
    })()
    return () => { dead = true; deadRef.current = true }
  }, [])   // eslint-disable-line react-hooks/exhaustive-deps

  // okvir telefona (zadnji prizor) se prilagodi zaslonu
  useEffect(() => {
    const f = () => { const k = Math.min(1, (innerHeight - 230) / 700, (innerWidth - 28) / 380); setFit({ k: Math.max(0.5, Math.round(k * 1000) / 1000) }) }
    f(); addEventListener('resize', f); return () => removeEventListener('resize', f)
  }, [])

  /* ---------- podatki za prikaz ---------- */
  const gymDay = week.find(d => d.date >= today && d.kind === 'moc') ?? null
  const heroDay = (strength ? gymDay : null) ?? week.find(d => d.date >= today && d.kind !== 'pocitek') ?? null
  const chosen = (heroDay?.exercises || []).slice(0, 6)
  const library = useMemo(() => {
    const eq = new Set([...(focus.sessions.some(s => s.type === 'fitnes') ? equipFor('fitnes', focus.equipment) : []), ...(focus.sessions.some(s => s.type === 'doma') ? equipFor('doma', focus.equipment) : [])])
    const withEq = EXERCISES.filter(e => eq.has(e.eq))
    const lim = limitsOf(focus.limits)
    const safe = withEq.filter(e => !(e.avoid || []).some(l => lim.includes(l)))
    const forLevel = safe.filter(e => e.lvl <= Math.min(3, focus.level + 1))
    const forMuscles = focus.muscles.length ? forLevel.filter(e => e.m.some(m => focus.muscles.includes(m))) : forLevel
    return { all: EXERCISES.length, withEq: withEq.length, safe: safe.length, forLevel: forLevel.length, forMuscles: forMuscles.length, lim }
  }, [focus])
  const allEx = new Set(week.flatMap(d => (d.exercises || []).map(e => e.name)))
  const days7 = Array.from({ length: 7 }, (_, i) => addDays(today, i))
  const dayItems = (d: string) => week.filter(x => x.date === d && x.kind !== 'pocitek')
  const maxMin = Math.max(30, ...days7.map(d => dayItems(d).reduce((t, x) => t + x.durationMin, 0)))
  const blocks = useMemo(() => Array.from({ length: 12 }, (_, i) => weekContext(draft, addDays(ws, 7 * i))), [draft, ws])
  const aims = [...focus.aims.map(a => AIM_LABEL[a]), ...focus.muscles.slice(0, 2).map(m => MUSCLE_NAME[m])].slice(0, 4)
  const bodyLevels = useMemo(() => focusLevels(focus), [focus])
  const cardioN = week.filter(d => d.date >= today && d.date <= addDays(today, 6) && d.kind !== 'pocitek' && d.kind !== 'moc').length
  const cur = STAGES[Math.max(0, stage)]!
  const stratLines = (strat || '').split('\n').map(l => l.replace(/^[–-]\s*/, '').trim()).filter(Boolean)

  function stageLabel(s: Stage): string {
    if (s.key === 'vaje' && !strength) return 'Nastavljam kardio in cone'
    return s.label
  }
  function resultLine(k: StageKey): string {
    switch (k) {
      case 'cilji': return `Cilji: ${aims.join(' · ') || focus.title}`
      case 'teden': return `Teden: ${weekLine(focus)}${pinsWords(focus) ? ` · ${pinsWords(focus).toLowerCase()}` : ''}`
      case 'energija': return nut.rest ? `Energija: ~${int(nut.rest)} kcal${nut.train && nut.train !== nut.rest ? ` (dan vadbe ~${int(nut.train)})` : ''}${nut.protein ? `, beljakovine ${nut.protein} g` : ''}` : 'Energija: dopolni težo in višino za kalorije'
      case 'vaje': return strength ? `Vaje: ${allEx.size || chosen.length} izbranih iz ${library.forLevel}` : `Kardio: ${cardioN} treningov na teden`
      case 'bloki': return '12 tednov: 3 bloki, vsak 4. teden lažji'
      case 'strategija': return `Strategija: ${stratLines.length} točk`
      default: return 'Aplikacija sestavljena'
    }
  }
  const pct = end ? 100 : Math.round(((Math.max(0, stage) + 0.5) / STAGES.length) * 100)

  // v body: .page ima animacijo s transform (fill both), ki bi fiksni položaj zaprla v stran
  return createPortal(
    <div className={`bs${calm ? ' calm' : ''}${end ? ' end' : ''}${out ? ' out' : ''}`} aria-busy={!end}>
      <div className="bs-grid" aria-hidden="true" />
      <div className="bs-top" aria-hidden="true">
        <span className="bs-step">{Math.max(1, stage + 1)} / {STAGES.length}</span>
        <span className="bs-brand">FORMAI</span>
      </div>

      <div className="bs-stage" aria-hidden="true">
        {cur.key === 'cilji' && <SceneCilji key="cilji" focus={focus} aims={aims} bodyLevels={bodyLevels} calm={calm} />}
        {cur.key === 'teden' && <SceneTeden key="teden" focus={focus} calm={calm} />}
        {cur.key === 'energija' && <SceneEnergija key="energija" focus={focus} basics={basics} nut={nut} calm={calm} />}
        {cur.key === 'vaje' && <SceneVaje key="vaje" focus={focus} strength={strength} library={library} heroDay={heroDay} chosen={chosen} exDone={!!exDone} ai={ai} week={week} today={today} calm={calm} />}
        {cur.key === 'bloki' && <SceneBloki key="bloki" blocks={blocks} calm={calm} />}
        {cur.key === 'strategija' && <SceneStrategija key="strategija" lines={stratLines} ai={ai} calm={calm} />}
        {cur.key === 'zasloni' && (
          <div className="bs-stagewrap" style={{ ['--k' as string]: fit.k }}>
            <div className="bs-phone">
              <svg className="bs-outline" viewBox="0 0 380 700" preserveAspectRatio="none"><rect x="1" y="1" width="378" height="698" rx="38" /></svg>
              <Part cls="bs-head" m="split" on i={0}>
                <div className="bs-hl">
                  <small>Tvoj načrt</small>
                  <b>{focus.title}</b>
                  <div className="bs-aims">{aims.map((a, i) => <span key={a} className="bs-pill" style={{ animationDelay: `${1.6 + i * 0.2}s` }}>{a}</span>)}</div>
                </div>
                <BodyMap levels={bodyLevels} size={78} both={false} run={!calm} delay={1.4} />
              </Part>
              <Part cls="bs-week" m="none" on i={1}>
                {days7.map((d, i) => {
                  const items = dayItems(d)
                  const min = items.reduce((t, x) => t + x.durationMin, 0)
                  return (
                    <div key={d} className={`bs-day${d === today ? ' today' : ''}`} style={{ animationDelay: `${0.5 + i * 0.12}s` }}>
                      <small>{DAYS_SL[dow(d)]}</small>
                      <span className="bs-col">
                        {items[0]
                          ? <i className="bs-bar" style={{ height: `${Math.max(22, Math.round((min / maxMin) * 100))}%`, background: kindColor(items[0].kind), animationDelay: `${1.3 + i * 0.12}s` }} />
                          : <i className="bs-rest" />}
                      </span>
                    </div>
                  )
                })}
              </Part>
              <Part cls="bs-hero" m="unfold" on i={2} style={{ ['--c' as string]: heroDay ? kindColor(heroDay.kind) : 'var(--t-moc)', ['--ci' as string]: heroDay ? kindInk(heroDay.kind) : 'var(--t-moc-ink)' }}>
                <small className="bs-kicker">{heroDay ? `${heroDay.kind === 'moc' ? 'MOČ' : heroDay.kind === 'kolo' ? 'KOLO' : 'KARDIO'} · ${heroDay.date === today ? 'DANES' : DAYS_SL[dow(heroDay.date)]!.toUpperCase()}` : ''}</small>
                <b className="bs-ttl">{heroDay?.title || ''}</b>
                {strength ? (
                  <ul className="bs-ex">{chosen.slice(0, 4).map((e, i) => <li key={e.name} style={{ animationDelay: `${1.5 + i * 0.2}s` }}><span>{e.name}</span><em>{e.sets} × {e.reps}{e.kg ? ` · ${num(e.kg)} kg` : ''}</em></li>)}</ul>
                ) : heroDay ? <p className="bs-desc">{fmtDur(heroDay.durationMin)} · {clip(heroDay.desc, 120)}</p> : null}
              </Part>
              <div className="bs-row">
                <Part cls="bs-ring" m="split" on i={3}>
                  <svg viewBox="0 0 100 100" className="bs-segs">
                    {Array.from({ length: 16 }, (_, i) => <path key={i} d={arc(50, 50, 40, i * 22.5 + 2, i * 22.5 + 20.5)} style={{ animationDelay: `${1.4 + i * 0.06}s` }} />)}
                  </svg>
                  <div className="bs-ringmid"><b>{nut.rest ? int(nut.rest) : '—'}</b><small>{nut.rest ? 'kcal na dan' : 'kcal'}</small></div>
                  <span className="bs-ringsub">{nut.protein ? <>beljakovine {nut.protein} g</> : 'dopolni težo'}</span>
                </Part>
                <Part cls="bs-blocks" m="splitv" on i={4}>
                  <small>12 tednov</small>
                  <div className="bs-bars">{blocks.map((c, i) => <i key={i} className={c.recovery ? 'easy' : ''} style={{ height: `${Math.round((c.volume / 1.08) * 100)}%`, animationDelay: `${1.4 + i * 0.09}s` }} />)}</div>
                  <span className="bs-ringsub">vsak 4. teden lažji</span>
                </Part>
              </div>
              <Part cls="bs-strat" m="extend" on i={5}>
                <small>Tvoja strategija</small>
                <p className="bs-type">{stratLines.slice(0, 3).join('\n')}</p>
              </Part>
              <Part cls="bs-tabs" m="rise" on i={6}>
                {TABS.map(({ key, label, Ico }, i) => <span key={key} style={{ animationDelay: `${1.6 + i * 0.18}s` }}><Ico width={19} height={19} /><small>{label}</small></span>)}
              </Part>
              <div className="bs-sweep" />
            </div>
          </div>
        )}
      </div>

      <div className="bs-status" role="status" aria-live="polite">
        <div className="bs-now">
          {end ? <><IcoCheck width={18} height={18} aria-hidden="true" /> {failed ? 'Načrt je pripravljen — shranjevanje ni uspelo' : 'Tvoj FORMAI je pripravljen'}</>
            : <>{stageLabel(cur)}<span className="thinking" aria-hidden="true"><i /><i /><i /></span></>}
        </div>
        <div className="bs-prog" aria-hidden="true"><i style={{ width: `${pct}%` }} /></div>
        <ul className="bs-log">{log.slice(-2).map(k => <li key={k}><IcoCheck width={13} height={13} aria-hidden="true" /> {resultLine(k)}</li>)}</ul>
        {failed && <button type="button" className="btn primary block" style={{ marginTop: 12 }} onClick={() => void save(failed, () => deadRef.current)}>Poskusi znova</button>}
      </div>
    </div>,
    document.body,
  )
}

/* ---------- prizori ---------- */
/**
 * Prizor: ko je vsebine več, kot je prostora (majhen zaslon), drsi za delom, ki se ravno pokaže (po njegovem zamiku),
 * ne takoj na dno — tako se vedno vidi, kar se dogaja, zgornji deli pa ne izginejo, preden jih vidiš.
 */
function Scene({ cls, children }: { cls: string; children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const el = ref.current
    if (!el) return
    const start = performance.now()
    const id = setInterval(() => {
      if (el.scrollHeight - el.clientHeight <= 4) return
      const t = (performance.now() - start) / 1000
      let target: HTMLElement | null = null
      for (const n of el.querySelectorAll<HTMLElement>('.bs-r')) { const d = parseFloat(n.style.animationDelay || '0'); if (d <= t + 0.25) target = n }
      if (!target) return
      const over = target.getBoundingClientRect().bottom - el.getBoundingClientRect().bottom + 10
      if (over > 2) el.scrollTo({ top: el.scrollTop + over, behavior: reduced() ? 'auto' : 'smooth' })
    }, 300)
    return () => clearInterval(id)
  }, [])
  return <div ref={ref} className={`bs-scene ${cls}`}>{children}</div>
}
/** Del prizora, ki se pokaže ob času d (sekunde od začetka prizora). */
function R({ d, cls, children }: { d: number; cls?: string; children: ReactNode }) {
  return <div className={`bs-r${cls ? ` ${cls}` : ''}`} style={{ animationDelay: `${d}s` }}>{children}</div>
}

/** 1 · njegove besede: citat se natipka, besede, ki jih aplikacija razume, se označijo, cilji priletijo, mišice zasvetijo */
function SceneCilji({ focus, aims, bodyLevels, calm }: { focus: Focus; aims: string[]; bodyLevels: ReturnType<typeof focusLevels>; calm: boolean }) {
  const text = clip(focus.wish.replace(/\s+/g, ' ').trim(), 230)
  const typeMs = calm ? 0 : Math.min(3200, 400 + text.length * 22)
  const marks = useMemo(() => markWords(text), [text])
  const t1 = typeMs / 1000
  const chips = [
    ...focus.sports.map(s => ({ k: `s-${s}`, t: SPORT_LABEL[s], c: 'c-sport' })),
    ...focus.aims.map(a => ({ k: `a-${a}`, t: AIM_LABEL[a], c: 'c-aim' })),
    ...focus.muscles.map(m => ({ k: `m-${m}`, t: MUSCLE_NAME[m], c: 'c-muscle' })),
    ...(focus.keepMuscle && focus.aims.includes('hujsanje') ? [{ k: 'keep', t: 'mišice ostanejo', c: 'c-aim' }] : []),
    ...(focus.offDays?.length ? [{ k: 'off', t: `ne gre: ${focus.offDays.map(d => DAY_OPTS[d]).join(', ')}`, c: 'c-day' }] : []),
    ...(focus.limits ? [{ k: 'lim', t: `pazim na: ${clip(focus.limits, 24)}`, c: 'c-limit' }] : []),
    { k: 'lvl', t: LEVEL_LABEL[focus.level], c: 'c-level' },
  ].slice(0, 9)
  void aims
  return (
    <Scene cls="sc-cilji">
      <R d={0}><div className="bs-sc-k">Tvoje besede</div></R>
      <div className="bs-quote">
        <TypeMarks text={text} marks={marks} run delay={calm ? 0 : 300} ms={22} markAt={t1 + 0.4} calm={calm} />
      </div>
      <R d={t1 + 1.3}><div className="bs-sc-k">Kar sem razumel</div></R>
      <div className="bs-chips">
        {chips.map((c, i) => <span key={c.k} className={`bs-chip ${c.c}`} style={{ animationDelay: `${t1 + 1.6 + i * 0.22}s` }}>{c.t}</span>)}
      </div>
      <div className="bs-body">
        <R d={t1 + 2.2}><BodyMap levels={bodyLevels} size={150} run={!calm} delay={t1 + 2.6} label={undefined} /></R>
        <R d={t1 + 3.2} cls="bs-body-note">{focus.muscles.length ? `Poudarek: ${focus.muscles.map(m => MUSCLE_NAME[m]).join(', ')}` : 'Uravnoteženo celo telo'}{focus.sessions.some(s => !isStrength(s)) ? ' · noge in srce s kardiem' : ''}</R>
      </div>
      <R d={t1 + 3.6} cls="bs-sc-sum"><b>{focus.title}</b></R>
    </Scene>
  )
}
/** besede, ki jih aplikacija razume (šport, cilj, mišica, dan, hujšanje …) — indeksi [od, do] v besedilu */
function markWords(text: string): [number, number][] {
  const out: [number, number][] = []
  const re = /[\p{L}\d]+/gu
  for (let m = re.exec(text); m; m = re.exec(text)) {
    const w = m[0]
    if (w.length < 3) continue
    const sig = wishSignals(w)
    const hit = sig.aims.length || sig.sports.length || sig.muscles.length || sig.keepMuscle || daysIn(w).length || /\d/.test(w)
    if (hit) out.push([m.index, m.index + w.length])
  }
  return out
}
/** Besedilo se natipka, nato se označene besede obarvajo. */
function TypeMarks({ text, marks, run, delay, ms, markAt, calm }: { text: string; marks: [number, number][]; run: boolean; delay: number; ms: number; markAt: number; calm: boolean }) {
  const [n, setN] = useState(calm ? text.length : 0)
  const [lit, setLit] = useState(calm)
  useEffect(() => {
    if (!run) return
    if (calm) { setN(text.length); setLit(true); return }
    let id = 0
    const t = setTimeout(() => { id = window.setInterval(() => setN(x => { if (x >= text.length) { clearInterval(id); return x } return x + 1 }), ms) }, delay)
    const t2 = setTimeout(() => setLit(true), markAt * 1000)
    return () => { clearTimeout(t); clearTimeout(t2); clearInterval(id) }
  }, [text, run])   // eslint-disable-line react-hooks/exhaustive-deps
  const shown = text.slice(0, n)
  const parts: ReactNode[] = []
  let at = 0
  marks.forEach(([a, b], i) => {
    if (a >= shown.length) return
    if (a > at) parts.push(shown.slice(at, a))
    parts.push(<mark key={i} className={lit ? 'on' : ''} style={{ transitionDelay: `${i * 0.12}s` }}>{shown.slice(a, Math.min(b, shown.length))}</mark>)
    at = Math.min(b, shown.length)
  })
  if (at < shown.length) parts.push(shown.slice(at))
  return <p className="bs-q">»{parts}{run && n < text.length && <span className="bs-caret" />}«</p>
}

/** 2 · njegov teden: dnevi pridejo eden za drugim (znaki sej, določeni dnevi, dnevi brez časa), nato seje z minutami */
function SceneTeden({ focus, calm }: { focus: Focus; calm: boolean }) {
  const week = useMemo(() => weekOf(focus), [focus])
  const tails = useMemo(() => tailsOf(focus.sessions), [focus])
  const pins = pinsWords(focus)
  const what = (s: AgreedSession) => (s.part ? PART_NAME[s.part] : s.cardio ? CARDIO_LABEL[s.cardio] : '')
  const mains = focus.sessions.map((s, i) => ({ s, i })).filter(x => !tails.has(x.i))
  const tailOf = new Map<number, AgreedSession>(); tails.forEach((m, t) => tailOf.set(m, focus.sessions[t]!))
  void calm
  return (
    <Scene cls="sc-teden">
      <R d={0}><div className="bs-sc-k">Tvoj teden</div></R>
      <div className="bs-wk">
        {week.map(({ s, t, no, pinned }, i) => (
          <div key={i} className={`bs-wd${no ? ' off' : ''}${s ? ' on' : ''}${pinned ? ' pin' : ''}`} style={{ animationDelay: `${0.5 + i * 0.28}s`, ...(s ? { ['--c' as string]: sessionColor(s) } : {}) }}>
            <small>{DAY_OPTS[i]}</small>
            <span className="bs-wi">{no ? '✕' : s ? <><SessionIcon s={s} size={22} />{t && <span className="bs-wi2" style={{ ['--c' as string]: sessionColor(t) }}><SessionIcon s={t} size={12} /></span>}</> : '·'}</span>
            <em>{no ? 'ne gre' : s ? SPORT_LABEL[s.type].toLowerCase() : 'prosto'}</em>
          </div>
        ))}
      </div>
      <R d={2.6} cls="bs-sc-line">{weekLine(focus)}{pins ? ` · ${pins}` : ''}{focus.offDays?.length ? ` · ne gre: ${focus.offDays.map(d => DAY_NAME[d]).join(', ')}` : ''}</R>
      <div className="bs-sess">
        {mains.map(({ s, i }, k) => (
          <div key={i} className="bs-sr" style={{ animationDelay: `${3.0 + k * 0.32}s`, ['--c' as string]: sessionColor(s) }}>
            <span className="bs-sic"><SessionIcon s={s} size={16} /></span>
            <span className="bs-stxt"><b>{SPORT_LABEL[s.type]}</b>{what(s) ? <span> · {what(s)}</span> : null}{tailOf.has(i) ? <span className="bs-tail"> + {SPORT_LABEL[tailOf.get(i)!.type].toLowerCase()} {tailOf.get(i)!.min} min</span> : null}</span>
            <span className="bs-smin">{s.day != null ? <i>{DAY_OPTS[s.day]}</i> : null}{s.min} min</span>
          </div>
        ))}
      </div>
      <R d={3.2 + mains.length * 0.32} cls="bs-sc-sum">Razpored se sproti prilagaja temu, kar narediš.</R>
    </Scene>
  )
}

/** 3 · energija: iz teže, višine, starosti in spola → BMR → vzdrževanje → dan vadbe → primanjkljaj → cilj, beljakovine */
function SceneEnergija({ focus, basics, nut, calm }: { focus: Focus; basics: Basics; nut: { rest: number | null; train: number | null; protein: number | null; carbs: number | null; fat: number | null; deficit: number; maint: number | null; floor: number | null; bmr: number | null; burn: number }; calm: boolean }) {
  const who = [basics.sex ? (basics.sex === 'm' ? 'moški' : 'ženska') : null, basics.age ? `${basics.age} let` : null, basics.heightCm ? `${basics.heightCm} cm` : null, basics.weightKg ? `${num(basics.weightKg)} kg` : null].filter(Boolean).join(' · ')
  const minor = basics.age != null && basics.age < 18
  if (!nut.bmr || !nut.rest) {
    return (
      <Scene cls="sc-energija">
        <R d={0}><div className="bs-sc-k">Tvoja energija</div></R>
        <R d={0.4} cls="bs-sc-line">Brez teže in višine kalorij ne računam. Dopolniš jih v Nastavitvah — potem se Prehrana nastavi po tvojem načrtu.</R>
      </Scene>
    )
  }
  const rows: { d: number; k: string; v: number; sign?: string; note?: string; big?: boolean }[] = [
    { d: 0.9, k: 'Bazalni metabolizem', v: nut.bmr, note: 'kar telo porabi v mirovanju' },
    ...(nut.maint ? [{ d: 2.0, k: 'Vzdrževanje brez vadbe', v: nut.maint, note: 'z vsakdanjim gibanjem' }] : []),
    ...(nut.burn ? [{ d: 3.0, k: 'Dan vadbe', v: nut.burn, sign: '+', note: 'gorivo za trening' }] : []),
    ...(nut.deficit > 0 ? [{ d: 4.0, k: 'Primanjkljaj', v: nut.deficit, sign: '−', note: focus.keepMuscle ? 'zmerno, da mišice ostanejo' : 'za maščobo dol' }] : minor ? [{ d: 4.0, k: 'Primanjkljaj', v: 0, note: 'do 18. leta nikoli' }] : []),
  ]
  const tEnd = rows[rows.length - 1]!.d + 1.2
  return (
    <Scene cls="sc-energija">
      <R d={0}><div className="bs-sc-k">Tvoja energija</div></R>
      <R d={0.3} cls="bs-sc-line">{who ? `Iz tvojih podatkov: ${who}` : 'Iz tvojih podatkov'}</R>
      <div className="bs-calc">
        {rows.map(r => (
          <div key={r.k} className="bs-cr" style={{ animationDelay: `${r.d}s` }}>
            <span className="bs-ck">{r.k}<small>{r.note}</small></span>
            <b className="bs-cv">{r.sign ? <i>{r.sign}</i> : null}<CountUp to={r.v} run delay={calm ? 0 : r.d * 1000 + 250} /> <small>kcal</small></b>
          </div>
        ))}
      </div>
      <div className="bs-res" style={{ animationDelay: `${tEnd}s` }}>
        <div className="bs-ringbig">
          <svg viewBox="0 0 100 100" className="bs-segs2">{Array.from({ length: 20 }, (_, i) => <path key={i} d={arc(50, 50, 42, i * 18 + 1.5, i * 18 + 16.5)} style={{ animationDelay: `${tEnd + 0.2 + i * 0.05}s` }} />)}</svg>
          <div className="bs-ringtxt"><b><CountUp to={nut.train ?? nut.rest} run delay={calm ? 0 : (tEnd + 0.4) * 1000} /></b><small>kcal na dan vadbe</small></div>
        </div>
        <div className="bs-macro">
          {nut.train && nut.train !== nut.rest ? <span style={{ animationDelay: `${tEnd + 0.9}s` }}><b>{int(nut.rest)}</b> kcal na dan počitka</span> : null}
          {nut.protein ? <span style={{ animationDelay: `${tEnd + 1.2}s` }}><b>{nut.protein} g</b> beljakovin{basics.weightKg ? ` (${(nut.protein / basics.weightKg).toFixed(1)} g na kg)` : ''}</span> : null}
          {nut.carbs ? <span style={{ animationDelay: `${tEnd + 1.5}s` }}><b>{nut.carbs} g</b> ogljikovih hidratov · <b>{nut.fat ?? '—'} g</b> maščob</span> : null}
          {nut.floor ? <span style={{ animationDelay: `${tEnd + 1.8}s` }}>varno dno <b>{int(nut.floor)} kcal</b> — nikoli manj</span> : null}
        </div>
      </div>
    </Scene>
  )
}

/** 4 · vaje: knjižnica → oprema → omejitve → raven → izbor (AI ali pravila) za prvi trening moči; brez moči: kardio seje */
function SceneVaje({ focus, strength, library, heroDay, chosen, exDone, ai, week, today, calm }: { focus: Focus; strength: boolean; library: { all: number; withEq: number; safe: number; forLevel: number; forMuscles: number; lim: Limit[] }; heroDay: PlanDay | null; chosen: NonNullable<PlanDay['exercises']>; exDone: boolean; ai: boolean; week: PlanDay[]; today: string; calm: boolean }) {
  void calm
  if (!strength) {
    const list = week.filter(d => d.date >= today && d.kind !== 'pocitek').slice(0, 5)
    return (
      <Scene cls="sc-vaje">
        <R d={0}><div className="bs-sc-k">Tvoji treningi</div></R>
        <R d={0.3} cls="bs-sc-line">Cone iz tvojih podatkov: pogovorni tempo, intervali, dolgo — vsak trening z opisom, kako naj se počutiš.</R>
        <div className="bs-exl">
          {list.map((d, i) => (
            <div key={d.id} className="bs-er" style={{ animationDelay: `${1 + i * 0.45}s`, ['--c' as string]: kindColor(d.kind) }}>
              <span className="bs-eday">{cap(DAYS_SL[dow(d.date)]!)}</span>
              <span className="bs-etxt"><b>{d.title}</b><small>{fmtDur(d.durationMin)}{d.zone ? ` · ${d.zone}` : ''}</small></span>
            </div>
          ))}
        </div>
      </Scene>
    )
  }
  // lijak: samo koraki, ki število res spremenijo (oprema, omejitve, raven, poudarek), na koncu izbor
  const steps: { t: string; n: number }[] = [{ t: 'Knjižnica vaj', n: library.all }]
  if (library.withEq !== library.all) steps.push({ t: `Tvoja oprema: ${focus.equipment.map(e => EQUIP_LABEL[e]).join(', ')}`, n: library.withEq })
  if (library.lim.length) steps.push({ t: `Brez vaj, ki obremenijo ${library.lim.map(l => LIMIT_ACC[l]).join(' in ')}`, n: library.safe })
  if (library.forLevel !== library.safe) steps.push({ t: `Za tvojo raven (${LEVEL_LABEL[focus.level]})`, n: library.forLevel })
  if (focus.muscles.length && library.forMuscles !== library.forLevel) steps.push({ t: `Za tvoj poudarek: ${focus.muscles.map(m => MUSCLE_NAME[m]).join(', ')}`, n: library.forMuscles })
  const funnel = steps.map((x, i) => ({ ...x, d: 0.5 + i * 0.9 }))
  const t0 = funnel[funnel.length - 1]!.d + 1.0
  const waiting = ai && !exDone
  return (
    <Scene cls="sc-vaje">
      <R d={0}><div className="bs-sc-k">Vaje zate</div></R>
      <div className="bs-funnel">
        {funnel.map(f => <div key={f.t} className="bs-fr" style={{ animationDelay: `${f.d}s` }}><span>{f.t}</span><b><CountUp to={f.n} run delay={calm ? 0 : f.d * 1000 + 200} /></b></div>)}
      </div>
      <R d={t0} cls="bs-sc-line">{waiting ? 'AI izbira vaje za tvoj cilj, poudarke in omejitve …' : ai ? 'AI je izbral vaje za tvoj cilj, poudarke in omejitve.' : 'Izbor po pravilih: osnovne večsklepne vaje najprej, poudarki, trebuh na koncu.'}</R>
      {heroDay && (
        <div className="bs-hero2" style={{ animationDelay: `${t0 + 0.5}s`, ['--c' as string]: kindColor(heroDay.kind) }}>
          <small>{heroDay.date === today ? 'Danes' : cap(DAYS_SL[dow(heroDay.date)]!)} · prvi trening moči</small>
          <b>{heroDay.title}</b>
          <ul className="bs-exl2">
            {chosen.map((e, i) => {
              const def = exByName(e.name)
              return (
                <li key={e.name} style={{ animationDelay: `${t0 + 1.0 + i * 0.42}s` }}>
                  <span className="bs-en"><b>{e.name}</b>{def ? <small>{def.m.slice(0, 3).map(m => MUSCLE_NAME[m]).join(', ')}</small> : null}</span>
                  <em>{e.sets} × {e.reps}{e.kg ? ` · ${num(e.kg)} kg` : ''}</em>
                </li>
              )
            })}
            {!chosen.length && <li style={{ animationDelay: `${t0 + 1}s` }}><span className="bs-en"><b>{waiting ? 'Vaje prihajajo …' : 'Vaje po pravilih'}</b></span></li>}
          </ul>
          {heroDay.tail && <div className="bs-tailrow" style={{ animationDelay: `${t0 + 1.2 + chosen.length * 0.42}s` }}>nato {heroDay.tail.title.replace(/ — /, ': ').toLowerCase()}</div>}
        </div>
      )}
    </Scene>
  )
}

/** 5 · 12 tednov: bloki po 4 tedne (navada, rast, rast, lažji) */
function SceneBloki({ blocks, calm }: { blocks: ReturnType<typeof weekContext>[]; calm: boolean }) {
  void calm
  return (
    <Scene cls="sc-bloki">
      <R d={0}><div className="bs-sc-k">Naslednjih 12 tednov</div></R>
      <div className="bs-blk">
        {blocks.map((c, i) => <div key={i} className="bs-bb" style={{ animationDelay: `${0.4 + i * 0.16}s` }}><i className={c.recovery ? 'easy' : ''} style={{ height: `${Math.round((c.volume / 1.08) * 100)}%` }} /><small>{i + 1}</small></div>)}
      </div>
      <div className="bs-blktxt">
        <R d={2.6}><b>Teden 1</b> navada in tehnika — kilograme vpisuj, naslednje vadbe jih prevzamejo</R>
        <R d={3.3}><b>Teden 2–3</b> rast — kjer narediš vse ponovitve, je teža višja</R>
        <R d={4.0}><b>Teden 4</b> lažji — telo se okrepi med počitkom</R>
        <R d={4.7}><b>Teden 5 →</b> nov blok z višjo težo; vsak blok se prilagodi temu, kar narediš</R>
      </div>
    </Scene>
  )
}

/** 6 · strategija: tipka se vrstica za vrstico (AI ali pravila) */
function SceneStrategija({ lines, ai, calm }: { lines: string[]; ai: boolean; calm: boolean }) {
  const text = lines.slice(0, 7).join('\n')
  return (
    <Scene cls="sc-strat">
      <R d={0}><div className="bs-sc-k">Tvoja strategija</div></R>
      {text
        ? <Type text={text} run delay={calm ? 0 : 500} />
        : <R d={0.4} cls="bs-sc-line">{ai ? 'AI piše strategijo iz tvojih besed, načrta in številk prehrane …' : 'Pišem strategijo …'}</R>}
    </Scene>
  )
}

/** Del aplikacije (zadnji prizor): plošče priletijo in se zaklenejo → vsebina. */
function Part({ cls, m, on, i, style, children }: { cls: string; m: 'split' | 'splitv' | 'unfold' | 'extend' | 'rise' | 'none'; on: boolean; i: number; style?: React.CSSProperties; children: ReactNode }) {
  return (
    <div className={`bs-part ${cls} m-${m}${on ? ' on' : ''}`} style={{ ['--i' as string]: i, ['--d' as string]: `${0.6 + i * 0.55}s`, ...style }}>
      {m !== 'none' && <><i className="bs-plate a" /><i className="bs-plate b" /></>}
      <i className="bs-brk" />
      <div className="bs-in">{children}</div>
    </div>
  )
}

/** lok krožnega izseka (stopinje, 0 = zgoraj) */
function arc(cx: number, cy: number, r: number, a0: number, a1: number): string {
  const p = (a: number) => [cx + r * Math.sin((a * Math.PI) / 180), cy - r * Math.cos((a * Math.PI) / 180)]
  const [x0, y0] = p(a0), [x1, y1] = p(a1)
  return `M ${x0!.toFixed(2)} ${y0!.toFixed(2)} A ${r} ${r} 0 0 1 ${x1!.toFixed(2)} ${y1!.toFixed(2)}`
}

/** Število šteje do cilja. */
function CountUp({ to, run, delay = 0 }: { to: number; run: boolean; delay?: number }) {
  const [v, setV] = useState(0)
  useEffect(() => {
    if (!run || !to) { setV(run ? to : 0); return }
    if (reduced()) { setV(to); return }
    let raf = 0
    const t = setTimeout(() => {
      const t0 = performance.now(), dur = 1400
      const tick = (x0: number) => { const x = Math.min(1, (x0 - t0) / dur); setV(Math.round(to * (1 - Math.pow(1 - x, 3)))); if (x < 1) raf = requestAnimationFrame(tick) }
      raf = requestAnimationFrame(tick)
    }, delay)
    return () => { clearTimeout(t); cancelAnimationFrame(raf) }
  }, [to, run])   // eslint-disable-line react-hooks/exhaustive-deps
  return <>{int(v)}</>
}
/** Besedilo se tipka. */
function Type({ text, run, delay = 0 }: { text: string; run: boolean; delay?: number }) {
  const [n, setN] = useState(0)
  useEffect(() => {
    if (!run) { setN(0); return }
    if (reduced()) { setN(text.length); return }
    let id = 0
    const t = setTimeout(() => { id = window.setInterval(() => setN(x => { if (x >= text.length) { clearInterval(id); return x } return x + 2 }), 22) }, delay)
    return () => { clearTimeout(t); clearInterval(id) }
  }, [text, run])   // eslint-disable-line react-hooks/exhaustive-deps
  const shown = text.slice(0, n)
  return <div className="bs-typed">{shown.split('\n').map((l, i) => <p key={i}>{l}</p>)}{run && n < text.length && <span className="bs-caret" />}</div>
}
