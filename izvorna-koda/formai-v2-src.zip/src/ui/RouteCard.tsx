import { useMemo, useState } from 'react'
import { useApp, newRouteFor, toast } from '@/state/store'
import { routesOf } from '@/data/routes'
import { needOf, suggestRoutes, paceFactor } from '@/domain/routes/match'
import { decodePolyline, haversineM, type LatLon } from '@/domain/import/polyline'
import { toGpx, brouterWebUrl } from '@/domain/routes/brouter'
import { STEP_M, type Climb } from '@/domain/routes/analyze'
import { fmtDur } from '@/domain/training/load'
import type { PlanDay } from '@/domain/types'
import { Card, Btn } from '@/ui/primitives'

const f1 = (x: number) => String(x).replace('.', ',')

/**
 * Trasa za dan: predlog iz tvojih voženj (Garmin prek intervals.icu) ali nova trasa (BRouter, OpenStreetMap).
 * Zemljevid sledi in profil višin brez zunanjih ploščic; GPX za Garmin/Stravo; povezava na poln zemljevid.
 */
export function RouteCard({ day, compact = false, inCard = true }: { day: PlanDay; compact?: boolean; inCard?: boolean }) {
  const app = useApp()
  const p = app.profile
  const key = `${day.id}|${day.title}|${day.durationMin}|${day.role}|${p.ftp}|${p.weightKg}`
  const need = useMemo(() => needOf(day, p), [key])  // eslint-disable-line react-hooks/exhaustive-deps
  const recs = useMemo(() => routesOf(app.routeLib), [app.routeLib])
  const list = useMemo(() => {
    if (!need) return []
    const k = paceFactor(recs, p)
    const pool = recs.filter(r => r.source === 'voznja' || r.date === day.date)
    const s = suggestRoutes(pool, need, p, app.today, k)
    return [...s.filter(x => x.rec.source === 'nova'), ...s.filter(x => x.rec.source !== 'nova').slice(0, 4)]
  }, [recs, need, app.today, day.date]) // eslint-disable-line react-hooks/exhaustive-deps
  const [i, setI] = useState(0)
  const [busy, setBusy] = useState(false)
  if (!need) return null

  const connected = !!app.settings.intervals?.apiKey
  const home = app.routeLib?.home
  const s = list.length ? list[i % list.length]! : null
  const wrap = (body: React.ReactNode) => inCard ? <Card tight style={{ marginTop: 12 }}>{body}</Card> : <div style={{ marginTop: 10 }}>{body}</div>

  async function gen() {
    setBusy(true)
    try { await newRouteFor(day, Date.now() % 1000); setI(0); toast('Nova trasa je pripravljena.', 'ok') }
    catch (e) { toast((e as Error).message || 'Trase ni bilo mogoče narediti.', 'err', 6000) }
    finally { setBusy(false) }
  }
  function gpx() {
    if (!s) return
    const pts = decodePolyline(s.rec.poly)
    const alt = elevAlong(pts, s.rec.prof)
    const blob = new Blob([toGpx(`FORMAI ${day.date} ${day.title}`, pts, alt)], { type: 'application/gpx+xml' })
    const url = URL.createObjectURL(blob), a = document.createElement('a')
    a.href = url; a.download = `formai-${day.date}-${s.rec.km}km.gpx`; document.body.appendChild(a); a.click(); a.remove()
    setTimeout(() => URL.revokeObjectURL(url), 5000)
  }
  const mapUrl = s ? (s.rec.source === 'nova' && s.rec.via ? brouterWebUrl(s.rec.via) : s.rec.icuId != null ? `https://intervals.icu/activities/${s.rec.icuId}` : null) : null

  if (!s) return wrap(<>
    <h4 style={{ fontSize: 11, margin: 0 }}>Trasa · {need.label}</h4>
    <p style={{ fontSize: 12.5, marginTop: 6 }}>{!connected ? 'Poveži intervals.icu (Več → Uvoz), da predlagam trase iz tvojih voženj z Garmina.' : app.routesBusy ? 'Nalagam tvoje trase iz intervals.icu …' : 'Še nimam tvojih tras — pridejo z naslednjimi vožnjami z Garmina.'}</p>
    {home && <Btn ghost sm style={{ marginTop: 8 }} disabled={busy} onClick={gen}>{busy ? 'Rišem traso …' : 'Nova trasa'}</Btn>}
  </>)

  return wrap(<>
    <div className="between">
      <h4 style={{ fontSize: 11, margin: 0 }}>Trasa · {need.label}</h4>
      {list.length > 1 && <span className="muted" style={{ fontSize: 11.5, fontWeight: 700 }}>{(i % list.length) + 1}/{list.length}</span>}
    </div>
    <div className="muted" style={{ fontSize: 11.5, fontWeight: 600, marginTop: 2 }}>{s.why}</div>
    <div style={{ display: 'grid', gridTemplateColumns: compact ? '1fr' : 'minmax(0, 1fr) minmax(0, 1.4fr)', gap: 10, marginTop: 8, alignItems: 'center' }}>
      <MiniMap poly={s.rec.poly} climb={s.climb} />
      <div>
        <b style={{ fontSize: 14, color: 'var(--ink)' }}>{s.rec.source === 'nova' ? 'Nova trasa' : s.rec.name}</b>
        <div className="muted" style={{ fontSize: 12, marginTop: 2 }}>{f1(s.rec.km)} km · {s.rec.gainM} m vzpona · ~{fmtDur(s.estMin)}{s.rec.loop ? ' · krog' : ''}</div>
        <Profile prof={s.rec.prof} climb={s.climb} />
      </div>
    </div>
    <p style={{ fontSize: 12.5, marginTop: 8, color: 'var(--ink-2)' }}>{s.how}</p>
    {s.estMin > need.minutes * 1.25 && <p style={{ fontSize: 12, marginTop: 4, color: 'var(--warn)' }}>Trasa je daljša od treninga (~{fmtDur(s.estMin)} proti {fmtDur(need.minutes)}) — po zadnjem intervalu se vrni po najkrajši poti ali izberi drugo.</p>}
    <div className="row" style={{ gap: 7, marginTop: 8, flexWrap: 'wrap' }}>
      {list.length > 1 && <Btn ghost sm onClick={() => setI(i + 1)}>Druga</Btn>}
      {home && <Btn ghost sm disabled={busy} onClick={gen}>{busy ? 'Rišem …' : 'Nova trasa'}</Btn>}
      <Btn ghost sm onClick={gpx}>GPX</Btn>
      {mapUrl && <a className="btn ghost sm" href={mapUrl} target="_blank" rel="noopener noreferrer" style={{ textDecoration: 'none' }}>Zemljevid</a>}
    </div>
    {!compact && <p className="muted" style={{ fontSize: 11, marginTop: 8 }}>GPX v Stravo: strava.com → Dashboard → My Routes → Create New Route → uvozi GPX. V Garmin: Garmin Connect → Proge → Uvozi, nato pošlji na napravo.{s.rec.source === 'nova' ? ' Nova trasa je z OpenStreetMap (BRouter) — pred vožnjo jo preglej na zemljevidu.' : ''}</p>}
  </>)
}

/** Višine vzdolž točk (iz profila vsakih 50 m). */
function elevAlong(pts: readonly LatLon[], prof: readonly number[]): number[] {
  let d = 0
  return pts.map((q, i) => { if (i) d += haversineM(pts[i - 1]!, q); return prof[Math.min(prof.length - 1, Math.round(d / STEP_M))] ?? NaN })
}

function MiniMap({ poly, climb }: { poly: string; climb: Climb | null }) {
  const pts = useMemo(() => decodePolyline(poly), [poly])
  if (pts.length < 2) return null
  const lat0 = pts.reduce((s, q) => s + q[0], 0) / pts.length
  const kx = Math.cos((lat0 * Math.PI) / 180)
  const xs = pts.map(q => q[1] * kx), ys = pts.map(q => -q[0])
  const minX = Math.min(...xs), maxX = Math.max(...xs), minY = Math.min(...ys), maxY = Math.max(...ys)
  const w = Math.max(maxX - minX, 1e-4), h = Math.max(maxY - minY, 1e-4), pad = Math.max(w, h) * 0.06
  const d = xs.map((x, j) => `${j ? 'L' : 'M'}${x.toFixed(5)} ${ys[j]!.toFixed(5)}`).join('')
  let seg = ''
  if (climb) {
    const near = (t: LatLon) => { let b = 0, bd = Infinity; pts.forEach((q, j) => { const e = (q[0] - t[0]) ** 2 + ((q[1] - t[1]) * kx) ** 2; if (e < bd) { bd = e; b = j } }); return b }
    const a = near(climb.foot), b = near(climb.top)
    const [lo, hi] = a <= b ? [a, b] : [b, a]
    seg = xs.slice(lo, hi + 1).map((x, j) => `${j ? 'L' : 'M'}${x.toFixed(5)} ${ys[lo + j]!.toFixed(5)}`).join('')
  }
  const r = Math.max(w, h) * 0.025
  return (
    <svg viewBox={`${minX - pad} ${minY - pad} ${w + 2 * pad} ${h + 2 * pad}`} preserveAspectRatio="xMidYMid meet" style={{ width: '100%', height: 130, background: 'var(--raised)', borderRadius: 'var(--r-m)' }} role="img" aria-label="Oris trase">
      <path d={d} fill="none" stroke="var(--t-kolo)" strokeWidth={2.5} strokeLinejoin="round" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
      {seg && <path d={seg} fill="none" stroke="var(--accent)" strokeWidth={4} strokeLinecap="round" vectorEffect="non-scaling-stroke" />}
      <circle cx={xs[0]} cy={ys[0]} r={r} fill="var(--ink)" stroke="var(--card)" strokeWidth={1.5} vectorEffect="non-scaling-stroke" />
    </svg>
  )
}

function Profile({ prof, climb }: { prof: number[]; climb: Climb | null }) {
  if (prof.length < 3) return null
  const n = Math.min(160, prof.length), step = (prof.length - 1) / (n - 1)
  const ys = Array.from({ length: n }, (_, j) => prof[Math.round(j * step)]!)
  const lo = Math.min(...ys), hi = Math.max(...ys), span = Math.max(20, hi - lo)
  const W = 300, H = 56
  const X = (j: number) => (j / (n - 1)) * W, Y = (v: number) => H - 4 - ((v - lo) / span) * (H - 10)
  const line = ys.map((v, j) => `${j ? 'L' : 'M'}${X(j).toFixed(1)} ${Y(v).toFixed(1)}`).join('')
  const totalKm = ((prof.length - 1) * STEP_M) / 1000
  let band: { x: number; w: number } | null = null
  if (climb) { const x0 = (climb.atKm / totalKm) * W, x1 = ((climb.atKm + climb.km) / totalKm) * W; band = { x: x0, w: Math.max(2, x1 - x0) } }
  return (
    <div style={{ marginTop: 6 }}>
      <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ width: '100%', height: 48, display: 'block' }} role="img" aria-label="Profil višin">
        {band && <rect x={band.x} y={0} width={band.w} height={H} fill="var(--accent)" opacity={0.18} />}
        <path d={`${line}L${W} ${H}L0 ${H}Z`} fill="var(--raised)" />
        <path d={line} fill="none" stroke="var(--ink-3)" strokeWidth={1.5} vectorEffect="non-scaling-stroke" />
      </svg>
      <div className="between muted" style={{ fontSize: 10.5, marginTop: 2 }}><span>{lo} m</span><span>{hi} m</span></div>
    </div>
  )
}
