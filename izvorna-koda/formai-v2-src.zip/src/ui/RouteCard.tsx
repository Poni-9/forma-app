import { useMemo, useState } from 'react'
import { useApp, newRouteFor, toast, routePace } from '@/state/store'
import { routesOf } from '@/data/routes'
import { needOf, suggestRoutes } from '@/domain/routes/match'
import { decodePolyline, haversineM, type LatLon } from '@/domain/import/polyline'
import { toGpx } from '@/domain/routes/brouter'
import { STEP_M, routeTitle, type Climb } from '@/domain/routes/analyze'
import { fmtDur } from '@/domain/training/load'
import { watchOf, watchSteps, courseName } from '@/domain/routes/watch'
import type { PlanDay } from '@/domain/types'
import { Card, Btn } from '@/ui/primitives'
import { RouteMap } from '@/ui/RouteMap'

const f1 = (x: number) => String(x).replace('.', ',')
const semaforji = (n: number) => (!n ? 'brez semaforjev' : `${n} ${n % 100 === 1 ? 'semafor' : n % 100 === 2 ? 'semaforja' : n % 100 === 3 || n % 100 === 4 ? 'semaforji' : 'semaforjev'}`)

/**
 * Trasa za dan: predlog iz tvojih voženj (Garmin prek intervals.icu) ali nova trasa (BRouter, OpenStreetMap).
 * Zemljevid sledi in profil višin brez zunanjih ploščic; GPX za Garmin/Stravo; povezava na poln zemljevid.
 */
export function RouteCard({ day, compact = false, inCard = true }: { day: PlanDay; compact?: boolean; inCard?: boolean }) {
  const app = useApp()
  const p = app.profile
  const key = `${day.id}|${day.title}|${day.durationMin}|${day.role}|${p.ftp}|${p.weightKg}`
  const need = useMemo(() => needOf(day, p), [key])  // eslint-disable-line react-hooks/exhaustive-deps
  const recs = useMemo(() => routesOf(app.routeLib), [app.routeLib])
  // tempo: umeritev na tvojih vožnjah × učenje iz zadnjih treningov (koliko dlje/krajše so dejansko trajali)
  const pace = useMemo(() => routePace(app.routeLib), [app.routeLib, app.activities, app.plan, p.ftp, p.weightKg]) // eslint-disable-line react-hooks/exhaustive-deps
  const list = useMemo(() => {
    if (!need) return []
    const pool = recs.filter(r => r.source === 'voznja' || r.date === day.date)
    const s = suggestRoutes(pool, need, p, app.today, pace.k, app.routeLib?.home ?? null)
    // tvoje pogoste poti najprej (menjava), nova trasa dneva le, ko je boljša — vedno pa na seznamu
    const own = s.filter(x => x.rec.source !== 'nova').slice(0, 4), nova = s.filter(x => x.rec.source === 'nova')
    return [...own, ...nova].sort((a, b) => a.score - b.score)
  }, [recs, need, app.today, day.date, pace.k]) // eslint-disable-line react-hooks/exhaustive-deps
  const [i, setI] = useState(0)
  // po »Nova trasa« pokaži prav novo (na seznamu je sicer za tvojimi pogostimi)
  const [pick, setPick] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  // navodila za uro: po »Na uro« (shared) ali ob prenosu GPX (file); ura iz tvojih voženj
  const [steps, setSteps] = useState<null | 'shared' | 'file'>(null)
  const [mapOpen, setMapOpen] = useState(false)
  const watch = useMemo(() => watchOf(app.activities), [app.activities])
  if (!need) return null

  const connected = !!app.settings.intervals?.apiKey
  const home = app.routeLib?.home
  const picked = pick ? list.findIndex(x => x.rec.id === pick) : -1
  const at = picked >= 0 ? picked : i % Math.max(1, list.length)
  const s = list.length ? list[at]! : null
  const wrap = (body: React.ReactNode) => inCard ? <Card tight style={{ marginTop: 12 }}>{body}</Card> : <div style={{ marginTop: 10 }}>{body}</div>

  async function gen() {
    setBusy(true)
    try { const r = await newRouteFor(day, Date.now() % 1000); setPick(r.id); toast('Nova trasa je pripravljena.', 'ok') }
    catch (e) { toast((e as Error).message || 'Trase ni bilo mogoče narediti.', 'err', 6000) }
    finally { setBusy(false) }
  }
  function gpxFile(): File | null {
    if (!s) return null
    const pts = decodePolyline(s.rec.poly)
    const alt = elevAlong(pts, s.rec.prof)
    const name = courseName(day.date, day.title)
    return new File([toGpx(name, pts, alt)], `formai-${day.date}-${s.rec.km}km.gpx`, { type: 'application/gpx+xml' })
  }
  function gpx() {
    const f = gpxFile(); if (!f) return
    const url = URL.createObjectURL(f), a = document.createElement('a')
    a.href = url; a.download = f.name; document.body.appendChild(a); a.click(); a.remove()
    setTimeout(() => URL.revokeObjectURL(url), 5000)
  }
  /** Na uro: telefon odpre meni deljenja → Garmin Connect uvozi GPX kot progo in jo pošlje na uro (~1 min). */
  const nav = typeof navigator !== 'undefined' ? (navigator as Partial<Pick<Navigator, 'share' | 'canShare'>>) : null
  const canShareFiles = !!(nav && typeof nav.share === 'function' && typeof nav.canShare === 'function' && (() => { try { return nav.canShare!({ files: [new File(['x'], 'x.gpx', { type: 'application/gpx+xml' })] }) } catch { return false } })())
  async function toWatch() {
    const f = gpxFile(); if (!f) return
    try { await nav!.share!({ files: [f], title: f.name }); setSteps('shared') }
    catch (e) { if ((e as Error)?.name !== 'AbortError') { gpx(); setSteps('file') } }
  }
  const diff = s ? s.estMin - need.minutes : 0
  const learned = pace.adj.n && Math.abs(pace.adj.adj - 1) >= 0.04
    ? `Čas je umerjen na tvojih zadnjih treningih (${pace.adj.n}): trajali so ~${Math.round(Math.abs(pace.adj.adj - 1) * 100)} % ${pace.adj.adj > 1 ? 'dlje' : 'manj'} od ocene, zato je trasa ${pace.adj.adj > 1 ? 'krajša' : 'daljša'}.` : ''
  const q = s?.rec.source === 'nova' ? s.rec.quality : undefined

  if (!s) return wrap(<>
    <h4 style={{ fontSize: 11, margin: 0 }}>Trasa · {need.label}</h4>
    <p style={{ fontSize: 12.5, marginTop: 6 }}>{!connected ? 'Poveži intervals.icu (Več → Uvoz), da predlagam trase iz tvojih voženj z Garmina.' : app.routesBusy ? 'Nalagam tvoje trase iz intervals.icu …' : 'Še nimam tvojih tras — pridejo z naslednjimi vožnjami z Garmina.'}</p>
    {home && <Btn ghost sm style={{ marginTop: 8 }} disabled={busy} onClick={gen}>{busy ? 'Rišem traso …' : 'Nova trasa'}</Btn>}
  </>)

  return wrap(<>
    <div className="between">
      <h4 style={{ fontSize: 11, margin: 0 }}>Trasa · {need.label}</h4>
      {list.length > 1 && <span className="muted" style={{ fontSize: 11.5, fontWeight: 700 }}>{at + 1}/{list.length}</span>}
    </div>
    <div className="muted" style={{ fontSize: 11.5, fontWeight: 600, marginTop: 2 }}>{s.why}{q ? ` · ${semaforji(q.signals)}${q.unpavedKm >= 0.3 ? ` · ${String(q.unpavedKm).replace('.', ',')} km makadama` : ''}` : ''}</div>
    <div style={{ display: 'grid', gridTemplateColumns: compact ? '1fr' : 'minmax(0, 1fr) minmax(0, 1.4fr)', gap: 10, marginTop: 8, alignItems: 'center' }}>
      <MiniMap poly={s.rec.poly} climb={s.climb} />
      <div>
        <b style={{ fontSize: 14, color: 'var(--ink)' }}>{routeTitle(s.rec)}</b>
        <div className="muted" style={{ fontSize: 12, marginTop: 2 }}>{f1(s.rec.km)} km · {s.rec.gainM} m vzpona · ~{fmtDur(s.estMin)}{s.rec.loop ? ' · krog' : ''}</div>
        <Profile prof={s.rec.prof} climb={s.climb} />
      </div>
    </div>
    <p style={{ fontSize: 12.5, marginTop: 8, color: 'var(--ink-2)' }}>{s.how}</p>
    <p style={{ fontSize: 12, marginTop: 4, color: Math.abs(diff) > need.minutes * 0.12 ? 'var(--warn)' : 'var(--ink-3)', fontWeight: 600 }}>{Math.abs(diff) <= 5 ? 'Domov prideš, ko se trening konča.' : diff > 0 ? `Domov prideš ~${diff} min po koncu treninga${diff > need.minutes * 0.12 ? ' — po zadnjem koraku se vrni po najkrajši poti ali vzemi drugo' : ''}.` : `Domov prideš ~${-diff} min pred koncem — zadnje minute dodaj krog okoli doma.`}</p>
    <div className="row" style={{ gap: 7, marginTop: 8, flexWrap: 'wrap' }}>
      {canShareFiles && <Btn primary sm onClick={toWatch}>Na uro</Btn>}
      {list.length > 1 && <Btn ghost sm onClick={() => { setPick(null); setI(at + 1) }}>Druga</Btn>}
      {home && <Btn ghost sm disabled={busy} onClick={gen}>{busy ? 'Rišem …' : 'Nova trasa'}</Btn>}
      <Btn ghost sm onClick={() => { gpx(); if (!canShareFiles) setSteps('file') }}>GPX</Btn>
      <button className="chip sm click" onClick={() => setSteps(steps ? null : canShareFiles ? 'shared' : 'file')}>{steps ? 'skrij navodila' : 'kako na uri?'}</button>
      <Btn ghost sm onClick={() => setMapOpen(true)}>Zemljevid</Btn>
    </div>
    {steps && (
      <div className="watch-steps" style={{ marginTop: 10, padding: '10px 12px', borderRadius: 12, background: 'var(--raised)', border: '1px solid var(--line)' }}>
        <b style={{ fontSize: 12.5 }}>Trening in proga hkrati na {watch.name ? watch.name.replace(/^Garmin\s+/i, '') : 'uri'}</b>
        <div className="muted" style={{ fontSize: 11.5, marginTop: 2 }}>Trening (koraki z vati/utripom) je na uri že sam prek intervals.icu. Progo pošlješ ti — Garmin samodejnega prenosa prog drugim aplikacijam trenutno ne dovoli.</div>
        <ol style={{ margin: '8px 0 0', paddingLeft: 18, fontSize: 12.5, lineHeight: 1.55, color: 'var(--ink-2)' }}>{watchSteps(watch, courseName(day.date, day.title), day.title, steps === 'shared').map((t, k) => <li key={k}>{t}</li>)}</ol>
      </div>)}
    <RouteMap open={mapOpen} onClose={() => setMapOpen(false)} poly={s.rec.poly} climb={s.climb} title={`${routeTitle(s.rec)} · ${f1(s.rec.km)} km`} />
    {learned && <p className="muted" style={{ fontSize: 11, marginTop: 6 }}>{learned}</p>}
    {!compact && <p className="muted" style={{ fontSize: 11, marginTop: 8 }}>{canShareFiles ? 'Na uro: v meniju deljenja izberi Garmin Connect → proga se uvozi in ob sinhronizaciji pride na uro. ' : 'Na telefonu je gumb »Na uro« (deli GPX v Garmin Connect). Na računalniku: GPX → connect.garmin.com → Courses → Import, nato »Send to Device«. '}Čas trase je izračunan po korakih treninga (ogrevanje, intervali, iztek), po tvojih dejanskih hitrostih.{s.rec.source === 'nova' ? ' Nova trasa je z OpenStreetMap (BRouter, profil za cestno kolo: brez makadama, čim manj semaforjev, po cestah, ki jih že voziš) — pred vožnjo jo preglej na zemljevidu.' : ''}</p>}
  </>)
}

/** Višine vzdolž točk (iz profila vsakih 50 m). */
function elevAlong(pts: readonly LatLon[], prof: readonly number[]): number[] {
  let d = 0
  return pts.map((q, i) => { if (i) d += haversineM(pts[i - 1]!, q); return prof[Math.min(prof.length - 1, Math.round(d / STEP_M))] ?? NaN })
}

function MiniMap({ poly, climb }: { poly: string; climb: Climb | null }) {
  const pts = useMemo(() => decodePolyline(poly), [poly])
  if (pts.length < 2) return null
  const lat0 = pts.reduce((s, q) => s + q[0], 0) / pts.length
  const kx = Math.cos((lat0 * Math.PI) / 180)
  const xs = pts.map(q => q[1] * kx), ys = pts.map(q => -q[0])
  const minX = Math.min(...xs), maxX = Math.max(...xs), minY = Math.min(...ys), maxY = Math.max(...ys)
  const w = Math.max(maxX - minX, 1e-4), h = Math.max(maxY - minY, 1e-4), pad = Math.max(w, h) * 0.06
  const d = xs.map((x, j) => `${j ? 'L' : 'M'}${x.toFixed(5)} ${ys[j]!.toFixed(5)}`).join('')
  let seg = ''
  if (climb) {
    const near = (t: LatLon) => { let b = 0, bd = Infinity; pts.forEach((q, j) => { const e = (q[0] - t[0]) ** 2 + ((q[1] - t[1]) * kx) ** 2; if (e < bd) { bd = e; b = j } }); return b }
    const a = near(climb.foot), b = near(climb.top)
    const [lo, hi] = a <= b ? [a, b] : [b, a]
    seg = xs.slice(lo, hi + 1).map((x, j) => `${j ? 'L' : 'M'}${x.toFixed(5)} ${ys[lo + j]!.toFixed(5)}`).join('')
  }
  const r = Math.max(w, h) * 0.025
  return (
    <svg viewBox={`${minX - pad} ${minY - pad} ${w + 2 * pad} ${h + 2 * pad}`} preserveAspectRatio="xMidYMid meet" style={{ width: '100%', height: 130, background: 'var(--raised)', borderRadius: 'var(--r-m)' }} role="img" aria-label="Oris trase">
      <path d={d} fill="none" stroke="var(--t-kolo)" strokeWidth={2.5} strokeLinejoin="round" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
      {seg && <path d={seg} fill="none" stroke="var(--accent)" strokeWidth={4} strokeLinecap="round" vectorEffect="non-scaling-stroke" />}
      <circle cx={xs[0]} cy={ys[0]} r={r} fill="var(--ink)" stroke="var(--card)" strokeWidth={1.5} vectorEffect="non-scaling-stroke" />
    </svg>
  )
}

function Profile({ prof, climb }: { prof: number[]; climb: Climb | null }) {
  if (prof.length < 3) return null
  const n = Math.min(160, prof.length), step = (prof.length - 1) / (n - 1)
  const ys = Array.from({ length: n }, (_, j) => prof[Math.round(j * step)]!)
  const lo = Math.min(...ys), hi = Math.max(...ys), span = Math.max(20, hi - lo)
  const W = 300, H = 56
  const X = (j: number) => (j / (n - 1)) * W, Y = (v: number) => H - 4 - ((v - lo) / span) * (H - 10)
  const line = ys.map((v, j) => `${j ? 'L' : 'M'}${X(j).toFixed(1)} ${Y(v).toFixed(1)}`).join('')
  const totalKm = ((prof.length - 1) * STEP_M) / 1000
  let band: { x: number; w: number } | null = null
  if (climb) { const x0 = (climb.atKm / totalKm) * W, x1 = ((climb.atKm + climb.km) / totalKm) * W; band = { x: x0, w: Math.max(2, x1 - x0) } }
  return (
    <div style={{ marginTop: 6 }}>
      <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ width: '100%', height: 48, display: 'block' }} role="img" aria-label="Profil višin">
        {band && <rect x={band.x} y={0} width={band.w} height={H} fill="var(--accent)" opacity={0.18} />}
        <path d={`${line}L${W} ${H}L0 ${H}Z`} fill="var(--raised)" />
        <path d={line} fill="none" stroke="var(--ink-3)" strokeWidth={1.5} vectorEffect="non-scaling-stroke" />
      </svg>
      <div className="between muted" style={{ fontSize: 10.5, marginTop: 2 }}><span>{lo} m</span><span>{hi} m</span></div>
    </div>
  )
}
