import { Suspense, type ComponentProps, type ComponentType } from 'react'
import { retryLazy } from '@/app/chunk'
import { ChunkBoundary } from '@/ui/ChunkBoundary'
import type { WeighSheet as W } from './WeighSheet'
import type { ReadinessSheet as R } from './ReadinessSheet'
import type { SkipSheet as S } from './SkipSheet'
import type { MoveDaySheet as M } from './MoveDaySheet'

/**
 * (v3.51) Listi z Danes (tehtanje, pripravljenost, »Danes ne gre«, prestavi) niso v začetnem paketu: prenesejo se ob
 * prvem odprtju (začetni paket 785 → pod 706 kB, G08). Isti vmesnik kot izvirni; zaprt list ne prenaša ničesar.
 */
function lazySheet<P extends { onClose: () => void; open?: boolean }>(load: () => Promise<ComponentType<P>>, label: string) {
  const L = retryLazy(load)
  return function SheetLazy(p: P) {
    if (p.open === false) return null
    return <ChunkBoundary onClose={p.onClose} label={label}><Suspense fallback={null}><L {...p} /></Suspense></ChunkBoundary>
  }
}
export const WeighSheet = lazySheet<ComponentProps<typeof W>>(() => import('./WeighSheet').then(m => m.WeighSheet), 'Tehtanje')
export const ReadinessSheet = lazySheet<ComponentProps<typeof R>>(() => import('./ReadinessSheet').then(m => m.ReadinessSheet), 'Pripravljenost')
export const SkipSheet = lazySheet<ComponentProps<typeof S>>(() => import('./SkipSheet').then(m => m.SkipSheet), 'Danes ne gre')
export const MoveDaySheet = lazySheet<ComponentProps<typeof M>>(() => import('./MoveDaySheet').then(m => m.MoveDaySheet), 'Prestavi trening')
