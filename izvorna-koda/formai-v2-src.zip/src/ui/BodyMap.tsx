import type { Muscle } from '@/domain/types'

/**
 * Telo od spredaj iz preprostih oblik (glava, ramena, prsa, šest kock trebuha, hrbet ob strani, roke, boki, noge).
 * Mišica z ravnjo > 0 zasveti v barvi poudarka (moč sija = raven 0–1). Za sestavljanje (cilji) in Napredek (serije na
 * mišico ta teden). Brez znaka ali maskote — samo zemljevid mišic.
 */
type Shape = { r: [number, number, number, number, number] } | { e: [number, number, number, number] }
const SHAPES: Record<Muscle, Shape[]> = {
  ramena: [{ e: [37, 45, 10, 8] }, { e: [83, 45, 10, 8] }],
  prsa: [{ r: [45, 38, 14, 20, 5] }, { r: [61, 38, 14, 20, 5] }],
  trebuh: [50, 61].flatMap(x => [62, 74, 86].map(y => ({ r: [x, y, 9, 10, 3] as [number, number, number, number, number] }))),
  hrbet: [{ r: [37, 58, 7, 30, 3.5] }, { r: [76, 58, 7, 30, 3.5] }],
  roke: [{ r: [24, 53, 10, 29, 5] }, { r: [86, 53, 10, 29, 5] }, { r: [20, 85, 9, 30, 4.5] }, { r: [91, 85, 9, 30, 4.5] }],
  zadnjica: [{ r: [46, 99, 28, 14, 6] }],
  noge: [{ r: [45, 116, 13, 42, 6] }, { r: [62, 116, 13, 42, 6] }, { r: [46, 162, 11, 38, 5] }, { r: [63, 162, 11, 38, 5] }],
}
const ORDER: Muscle[] = ['ramena', 'prsa', 'hrbet', 'roke', 'trebuh', 'zadnjica', 'noge']

function draw(s: Shape, k: number) {
  if ('e' in s) { const [cx, cy, rx, ry] = s.e; return <ellipse key={k} cx={cx} cy={cy} rx={rx} ry={ry} /> }
  const [x, y, w, h, rr] = s.r
  return <rect key={k} x={x} y={y} width={w} height={h} rx={rr} />
}

export function BodyMap({ levels, size = 96, run = true, delay = 0, label }: { levels: Partial<Record<Muscle, number>>; size?: number; run?: boolean; delay?: number; label?: string }) {
  const lit = ORDER.filter(m => (levels[m] ?? 0) > 0)
  return (
    <svg className={`bodymap${run ? ' run' : ''}`} viewBox="0 0 120 210" width={(size * 120) / 210} height={size} role={label ? 'img' : undefined} aria-label={label} aria-hidden={label ? undefined : true}>
      <g className="bm-base">
        <circle cx="60" cy="18" r="11" />
        <rect x="55" y="28" width="10" height="9" rx="3" />
        {ORDER.flatMap(m => SHAPES[m].map((s, k) => draw(s, k + ORDER.indexOf(m) * 10)))}
      </g>
      {lit.map((m, i) => (
        <g key={m} className="bm-on" style={{ ['--l' as string]: Math.min(1, Math.max(0.18, levels[m] ?? 0)), animationDelay: `${delay + i * 0.32}s` }}>
          {SHAPES[m].map((s, k) => draw(s, k))}
        </g>
      ))}
    </svg>
  )
}
