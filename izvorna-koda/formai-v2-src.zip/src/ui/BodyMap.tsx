import type { Muscle } from '@/domain/types'

/**
 * Telo od spredaj in od zadaj, narisano z mehkimi krivuljami (leva polovica, desna je zrcalna).
 * Mišica z ravnjo > 0 zasveti v barvi poudarka (raven 0–1). Za sestavljanje (cilji), Danes in Napredek.
 * Brez znaka ali maskote — samo zemljevid mišic.
 */
type Parts = { f?: string[]; b?: string[] }
const ABS = [63, 73, 83].map(y => `M51 ${y} h8 v7.5 h-8 z`)
const SHAPES: Record<Muscle, Parts> = {
  ramena: { f: ['M45 36 C37 36 30 40 29 49 C29 55 33 58 38 57 C41 52 44 46 47 40 Z'], b: ['M45 36 C37 36 30 40 29 49 C29 55 33 58 38 57 C41 52 44 46 47 40 Z'] },
  prsa: { f: ['M59 40 C54 38 49 39 46 42 C44 47 43 52 45 57 C50 61 56 60 59 58 Z'] },
  trebuh: { f: ABS },
  hrbet: { b: ['M59 36 C52 37 47 40 44 46 C41 56 42 68 47 80 C51 86 56 88 59 88 Z'] },
  roke: {
    f: ['M29 56 C26 62 25 72 26 80 C28 83 33 83 35 80 C37 72 38 64 38 58 Z', 'M26 85 C24 94 23 103 24 111 C26 114 31 114 33 111 C34 103 35 94 35 86 Z'],
    b: ['M29 56 C26 62 25 72 26 80 C28 83 33 83 35 80 C37 72 38 64 38 58 Z', 'M26 85 C24 94 23 103 24 111 C26 114 31 114 33 111 C34 103 35 94 35 86 Z'],
  },
  zadnjica: { b: ['M59 92 C50 90 43 93 41 100 C40 108 46 114 59 113 Z'] },
  noge: {
    f: ['M58 108 C50 106 43 108 41 114 C39 130 41 146 46 158 C51 161 56 159 58 155 C59 139 59 122 58 108 Z', 'M46 164 C43 175 43 189 46 201 C50 204 55 202 56 199 C57 187 57 173 55 164 Z'],
    b: ['M58 116 C50 114 43 116 41 122 C40 135 42 148 46 158 C51 161 56 159 58 155 C59 142 59 128 58 116 Z', 'M46 164 C43 175 43 189 46 201 C50 204 55 202 56 199 C57 187 57 173 55 164 Z'],
  },
}
const ORDER: Muscle[] = ['ramena', 'prsa', 'hrbet', 'roke', 'trebuh', 'zadnjica', 'noge']
/** samo spredaj: hrbet kot ozek trak ob trupu, zadnjica kot bok — da sta vidna tudi brez pogleda od zadaj */
const SIDE: Partial<Record<Muscle, string[]>> = {
  hrbet: ['M44 46 C41 56 42 68 45 80 L47 80 C45 68 45 56 47 44 Z'],
  zadnjica: ['M43 100 C41 106 42 112 45 114 L47 112 C45 108 45 104 46 100 Z'],
}
const TORSO = 'M46 38 C43 60 43 84 46 100 C46 106 52 110 59 110 L59 38 Z'
const LEGS = 'M44 106 C40 130 42 150 45 162 C42 176 42 190 46 203 L57 203 C57 185 58 170 56 160 L59 150 L59 106 Z'

function Half({ parts, view }: { parts: string[]; view: 'f' | 'b' }) {
  void view
  return <>{parts.map((d, i) => <path key={i} d={d} />)}</>
}
/** Ena polovica + zrcalna kopija okoli središča figure (x = 60). */
function Both({ d, off, view }: { d: string[]; off: number; view: 'f' | 'b' }) {
  return (
    <g transform={`translate(${off} 0)`}>
      <Half parts={d} view={view} />
      <g transform="translate(120 0) scale(-1 1)"><Half parts={d} view={view} /></g>
    </g>
  )
}

export function BodyMap({ levels, size = 96, run = true, delay = 0, label, both = true }: { levels: Partial<Record<Muscle, number>>; size?: number; run?: boolean; delay?: number; label?: string; /** spredaj in zadaj (sicer samo spredaj, za majhne kartice) */ both?: boolean }) {
  const lit = ORDER.filter(m => (levels[m] ?? 0) > 0)
  const body = (off: number) => (
    <g transform={`translate(${off} 0)`}>
      <circle cx="60" cy="17" r="10.5" />
      <rect x="55" y="26" width="10" height="11" rx="4" />
      <path d={TORSO} /><path d={LEGS} />
      <g transform="translate(120 0) scale(-1 1)"><path d={TORSO} /><path d={LEGS} /></g>
    </g>
  )
  const vw = both ? 250 : 120
  // samo spredaj: hrbet in zadnjica (zadaj) zasvetita kot obris ob strani — da se vidi, da sta v načrtu
  const front = (m: Muscle) => SHAPES[m].f ?? (both ? undefined : SIDE[m])
  return (
    <svg className={`bodymap${run ? ' run' : ''}`} viewBox={`0 0 ${vw} 210`} width={(size * vw) / 210} height={size} role={label ? 'img' : undefined} aria-label={label} aria-hidden={label ? undefined : true}>
      <g className="bm-sil">{body(0)}{both && body(130)}</g>
      <g className="bm-base">
        {ORDER.map(m => (
          <g key={m}>
            {front(m) && <Both d={front(m)!} off={0} view="f" />}
            {both && SHAPES[m].b && <Both d={SHAPES[m].b!} off={130} view="b" />}
          </g>
        ))}
      </g>
      {lit.map((m, i) => (
        <g key={m} className="bm-on" style={{ ['--l' as string]: Math.min(1, Math.max(0.22, levels[m] ?? 0)), animationDelay: `${delay + i * 0.32}s` }}>
          {front(m) && <Both d={front(m)!} off={0} view="f" />}
          {both && SHAPES[m].b && <Both d={SHAPES[m].b!} off={130} view="b" />}
        </g>
      ))}
    </svg>
  )
}
