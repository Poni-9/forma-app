import { Component, type ErrorInfo, type ReactNode } from 'react'
import { noteError } from '@/data/feedback'
import { Sheet, Btn } from '@/ui/primitives'

/**
 * (v3.50) Meja napake za list, ki se prenese ob prvem odprtju (Trening s slike, Pripomba, Cilj sezone): ko se del kode
 * ne naloži (brez povezave, nova objava brez service workerja), pokaže list z »Osveži« — prej je padla cela aplikacija
 * (»Nekaj se je podrlo«, brez zavihkov) oziroma zaslon.
 */
export class ChunkBoundary extends Component<{ children: ReactNode; onClose: () => void }, { err: boolean }> {
  state = { err: false }
  static getDerivedStateFromError() { return { err: true } }
  componentDidCatch(err: Error, info: ErrorInfo) {
    console.error('FORMAI list se ni naložil', err, info.componentStack)
    noteError(`List: ${String(err?.message || err)}`)
  }
  render() {
    if (!this.state.err) return this.props.children
    return (
      <Sheet open onClose={this.props.onClose} label="Ni naloženo">
        <b style={{ display: 'block', fontSize: 17, letterSpacing: '-.02em' }}>Tega dela ni bilo mogoče naložiti</b>
        <p style={{ fontSize: 13, marginTop: 6 }}>Preveri povezavo in osveži aplikacijo. Tvoji podatki so na napravi.</p>
        <Btn primary block style={{ marginTop: 14 }} onClick={() => location.reload()}>Osveži</Btn>
        <Btn ghost block style={{ marginTop: 9 }} onClick={this.props.onClose}>Zapri</Btn>
      </Sheet>
    )
  }
}
