import { Component, type ErrorInfo, type ReactNode } from 'react'
import { noteError } from '@/data/errlog'
import { Sheet, Btn } from '@/ui/primitives'
import { retryChunks } from '@/app/chunk'
import { rem } from '@/ui/rem'

/**
 * (v3.50) Meja napake za list, ki se prenese ob prvem odprtju (Trening s slike, Pripomba, Cilj sezone): ko se del kode
 * ne naloži (brez povezave, nova objava brez service workerja), pokaže list z »Osveži« — prej je padla cela aplikacija
 * (»Nekaj se je podrlo«, brez zavihkov) oziroma zaslon.
 */
/**
 * (v3.51) inline: kartica v zaslonu (trasa, gorivo po vožnji, pretekli teden, gradnja načrta) — namesto lista kratka
 * vrstica s »Poskusi znova« ('line') ali nič ('hide'); prej je neuspel prenos podrl cel zaslon Danes. Brez onClose.
 */
type Props = { children: ReactNode; label?: string } & ({ onClose: () => void; inline?: undefined } | { onClose?: undefined; inline: 'line' | 'hide' })
export class ChunkBoundary extends Component<Props, { err: boolean }> {
  state = { err: false }
  static getDerivedStateFromError() { return { err: true } }
  // (v3.51) ko se povezava vrne, poskusi znova sam (retryLazy prenaša znova)
  private onOnline = () => { if (this.state.err) { retryChunks(); this.setState({ err: false }) } }
  componentDidMount() { retryChunks(); window.addEventListener('online', this.onOnline) }
  componentWillUnmount() { window.removeEventListener('online', this.onOnline) }
  componentDidCatch(err: Error, info: ErrorInfo) {
    console.error('FORMAI list se ni naložil', err, info.componentStack)
    noteError(`List: ${String(err?.message || err)}`)
  }
  render() {
    if (!this.state.err) return this.props.children
    // (v3.51) pove, kaj se ni naložilo in da je vzrok povezava; »Poskusi znova« brez osvežitve
    const off = typeof navigator !== 'undefined' && navigator.onLine === false
    const { inline, onClose } = this.props
    if (inline === 'hide') return null
    if (inline || !onClose) return (
      <p className="muted chunk-line" role="status">
        {this.props.label ? <><b>{this.props.label}</b> — ni naloženo</> : 'Ni naloženo'}{off ? ' (ni povezave).' : '.'}{' '}
        <button type="button" className="chip sm click" onClick={() => { retryChunks(); this.setState({ err: false }) }}>Poskusi znova</button>
      </p>
    )
    return (
      <Sheet open onClose={onClose} label="Ni naloženo">
        <h2 className="sheet-t">{this.props.label || 'Tega dela ni bilo mogoče naložiti'}</h2>
        <p role="alert" style={{ fontSize: rem(13), marginTop: 6 }}>{off
          ? 'Ni povezave — tega dela še ni na napravi. Ko bo signal, tapni »Poskusi znova«. Tvoji podatki so na napravi.'
          : 'Tega dela ni bilo mogoče naložiti. Poskusi znova ali osveži aplikacijo. Tvoji podatki so na napravi.'}</p>
        <Btn primary block style={{ marginTop: 14 }} onClick={() => { retryChunks(); this.setState({ err: false }) }}>Poskusi znova</Btn>
        <Btn ghost block style={{ marginTop: 9 }} onClick={() => location.reload()}>Osveži</Btn>
        <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Zapri</Btn>
      </Sheet>
    )
  }
}
