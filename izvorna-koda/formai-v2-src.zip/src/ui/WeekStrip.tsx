import { fmtDur } from '@/domain/training/load'
import { useMemo, type ReactNode } from 'react'
import type { AgreedSession, Focus } from '@/domain/types'
import { scheduleWeek, pinsWords, weekWords } from '@/domain/training/focusPlan'
import { tailsOf, sportLabelOf, sessionWhat } from '@/domain/focus/model'
import { DAY_NAME, DAY_OPTS } from '@/domain/focus/choices'
import { IcoDumbbell, IcoRun, IcoBike, IcoMountain, IcoHome } from '@/ui/icons'
import { rem } from '@/ui/rem'

export function sessionColor(s: Pick<AgreedSession, 'type'>): string {
  return s.type === 'fitnes' || s.type === 'doma' ? 'var(--t-moc)' : s.type === 'kolo' ? 'var(--t-kolo)' : 'var(--t-tek)'
}
export function SessionIcon({ s, size = 17 }: { s: Pick<AgreedSession, 'type'>; size?: number }) {
  const p = { width: size, height: size, 'aria-hidden': true }
  return s.type === 'fitnes' ? <IcoDumbbell {...p} /> : s.type === 'doma' ? <IcoHome {...p} /> : s.type === 'kolo' ? <IcoBike {...p} /> : s.type === 'hribi' ? <IcoMountain {...p} /> : <IcoRun {...p} />
}
// (v3.49) hitra hoja in tek s hojo z besedami (prej »Hribi · lahko« tudi za 30 min hoje)
export const sessWhat = (s: AgreedSession) => sessionWhat(s)
export const sessName = (s: AgreedSession) => `${sportLabelOf(s)}${sessWhat(s) ? ` · ${sessWhat(s)}` : ''}`
const upper = (t: string) => t.charAt(0).toUpperCase() + t.slice(1)

/** Teden dogovora po dnevih: katera seja kdaj (kardio po moči kot drugi znak), določeni dnevi podčrtani, dnevi brez časa prečrtani. */
export function weekOf(f: Pick<Focus, 'sessions' | 'offDays' | 'preferDays'>) {
  const off = f.offDays || []
  const order = scheduleWeek(f.sessions, [0, 1, 2, 3, 4, 5, 6].filter(d => !off.includes(d)), f.preferDays, 7)
  const tailOf = new Map<number, number>(); tailsOf(f.sessions).forEach((i, j) => tailOf.set(i, j))
  return DAY_OPTS.map((_, i) => {
    const k = order[i]
    const s = k != null ? f.sessions[k]! : null
    const t = k != null && tailOf.has(k) ? f.sessions[tailOf.get(k)!]! : null
    return { s, t, no: off.includes(i), pinned: !!s && s.day === i }
  })
}

/**
 * Tvoj teden: 7 dni z znaki sej. onDay = tap dan, ko nimaš časa (dogovor, Moj dogovor). Bralnik zaslona dobi za
 * vsak dan: dan, seja (+ kardio isti dan), »določen dan« ali »ne gre«.
 */
export function WeekStrip({ f, onDay, busy, title = 'Tvoj teden', hint, note }: { f: Focus; onDay?: (d: number) => void; busy?: boolean; title?: string; hint?: string; note?: ReactNode }) {
  const week = useMemo(() => weekOf(f), [f])
  const pins = useMemo(() => pinsWords(f), [f])
  const words = useMemo(() => weekWords(f), [f])
  const off = f.offDays || []
  return (
    <div className="deal-wk">
      <div className="between" style={{ gap: 8 }}><b style={{ fontSize: rem(13), color: 'var(--ink)' }}>{title}</b>{onDay && <span className="muted" style={{ fontSize: rem(11.5), fontWeight: 700 }}>{hint ?? 'Tapni dan, ko nimaš časa'}</span>}</div>
      <div className="wk-pick" role="group" aria-label={onDay ? `${title} — tapni dan, ko nimaš časa` : title}>
        {week.map(({ s, t, no, pinned }, i) => {
          const state = no ? 'ne gre' : s ? `${sessName(s)}${t ? ` + ${sessName(t)}` : ''}${pinned ? ' (določen dan)' : ''}` : 'prosto'
          return (
            <button key={i} type="button" className={`wk-d${no ? ' off' : ''}${s ? ' on' : ''}${pinned ? ' pin' : ''}`} disabled={!onDay || busy} aria-pressed={onDay ? no : undefined} aria-label={`${DAY_NAME[i]}: ${state}`} title={`${upper(DAY_NAME[i]!)}: ${state}`}
              style={s ? { ['--c' as string]: sessionColor(s) } : undefined} onClick={() => onDay?.(i)}>
              <small>{DAY_OPTS[i]}</small>
              <span className="wk-i" aria-hidden="true">{no ? '✕' : s ? <><SessionIcon s={s} size={15} />{t && <span className="wk-i2" style={{ ['--c' as string]: sessionColor(t) }}><SessionIcon s={t} size={10} /></span>}</> : '·'}</span>
            </button>
          )
        })}
      </div>
      {/* teden je na traku (ikone, ✕, podčrtani določeni dnevi) — besedilo istega tedna je samo za bralnik zaslona
          (Blaž, 16. 10.: »kdo bo ta besedila bral«); vidna ostane ena vrstica */}
      <p className="wk-note" role="status" aria-live="polite">
        {note ?? <><span className="sr-only">{pins ? `${pins}. ` : ''}{off.length ? `Ne gre: ${off.map(x => DAY_NAME[x]).join(', ')}. ` : ''}{words ? `Teden: ${words}. ` : ''}</span>{f.sessions.some(x => x.day != null) ? 'Podčrtano: dan, ki si ga določil sam.' : ''}</>}
      </p>
    </div>
  )
}

/** Seznam sej dogovora: kardio z istim dnem kot moč je vrstica pod njo (»nato tek«), določen dan je oznaka ob seji. */
export function SessionList({ f }: { f: Pick<Focus, 'sessions'> }) {
  const tails = useMemo(() => tailsOf(f.sessions), [f.sessions])
  const tailOf = useMemo(() => { const m = new Map<number, number>(); tails.forEach((i, j) => m.set(i, j)); return m }, [tails])
  const row = (s: AgreedSession, i: number, tail: boolean) => (
    <div key={i} className={`deal-row${tail ? ' tail' : ''}`} style={{ ['--c' as string]: sessionColor(s) }}>
      <span className="deal-ic"><SessionIcon s={s} /></span>
      <span style={{ flex: 1, minWidth: 0 }}>{tail && <span className="muted">nato </span>}<b>{sportLabelOf(s)}</b>{sessWhat(s) ? <span className="muted"> · {sessWhat(s)}</span> : null}{s.what ? <span className="deal-what">{s.what}</span> : null}</span>
      {s.day != null && !tail && <span className="deal-day" title="določen dan">{DAY_OPTS[s.day]}</span>}
      <span className="muted" style={{ fontWeight: 700, fontSize: rem(12.5) }}>{fmtDur(s.min)}</span>
    </div>
  )
  return (
    <div className="deal-list">
      {f.sessions.map((s, i) => (tails.has(i) ? null : <div key={i} className="deal-grp">{row(s, i, false)}{tailOf.has(i) ? row(f.sessions[tailOf.get(i)!]!, tailOf.get(i)!, true) : null}</div>))}
    </div>
  )
}
