import { useMemo, type ReactNode } from 'react'
import type { AgreedSession, Focus } from '@/domain/types'
import { scheduleWeek, pinsWords } from '@/domain/training/focusPlan'
import { SPORT_LABEL, PART_NAME, CARDIO_LABEL, tailsOf } from '@/domain/focus/model'
import { DAY_NAME, DAY_OPTS } from '@/domain/focus/choices'
import { IcoDumbbell, IcoRun, IcoBike, IcoMap, IcoHome } from '@/ui/icons'

export function sessionColor(s: Pick<AgreedSession, 'type'>): string {
  return s.type === 'fitnes' || s.type === 'doma' ? 'var(--t-moc)' : s.type === 'kolo' ? 'var(--t-kolo)' : 'var(--t-tek)'
}
export function SessionIcon({ s, size = 17 }: { s: Pick<AgreedSession, 'type'>; size?: number }) {
  const p = { width: size, height: size, 'aria-hidden': true }
  return s.type === 'fitnes' ? <IcoDumbbell {...p} /> : s.type === 'doma' ? <IcoHome {...p} /> : s.type === 'kolo' ? <IcoBike {...p} /> : s.type === 'hribi' ? <IcoMap {...p} /> : <IcoRun {...p} />
}
export const sessWhat = (s: AgreedSession) => (s.part ? PART_NAME[s.part] : s.cardio ? CARDIO_LABEL[s.cardio] : '')
export const sessName = (s: AgreedSession) => `${SPORT_LABEL[s.type]}${sessWhat(s) ? ` · ${sessWhat(s)}` : ''}`
const upper = (t: string) => t.charAt(0).toUpperCase() + t.slice(1)

/** Teden dogovora po dnevih: katera seja kdaj (kardio po moči kot drugi znak), določeni dnevi podčrtani, dnevi brez časa prečrtani. */
export function weekOf(f: Pick<Focus, 'sessions' | 'offDays' | 'preferDays'>) {
  const off = f.offDays || []
  const order = scheduleWeek(f.sessions, [0, 1, 2, 3, 4, 5, 6].filter(d => !off.includes(d)), f.preferDays, 7)
  const tailOf = new Map<number, number>(); tailsOf(f.sessions).forEach((i, j) => tailOf.set(i, j))
  return DAY_OPTS.map((_, i) => {
    const k = order[i]
    const s = k != null ? f.sessions[k]! : null
    const t = k != null && tailOf.has(k) ? f.sessions[tailOf.get(k)!]! : null
    return { s, t, no: off.includes(i), pinned: !!s && s.day === i }
  })
}

/**
 * Tvoj teden: 7 dni z znaki sej. onDay = tap dan, ko nimaš časa (dogovor, Moj dogovor). Bralnik zaslona dobi za
 * vsak dan: dan, seja (+ kardio isti dan), »določen dan« ali »ne gre«.
 */
export function WeekStrip({ f, onDay, busy, title = 'Tvoj teden', hint, note }: { f: Focus; onDay?: (d: number) => void; busy?: boolean; title?: string; hint?: string; note?: ReactNode }) {
  const week = useMemo(() => weekOf(f), [f])
  const pins = useMemo(() => pinsWords(f), [f])
  const off = f.offDays || []
  return (
    <div className="deal-wk">
      <div className="between" style={{ gap: 8 }}><b style={{ fontSize: 13, color: 'var(--ink)' }}>{title}</b>{onDay && <span className="muted" style={{ fontSize: 11.5, fontWeight: 700 }}>{hint ?? 'Tapni dan, ko nimaš časa'}</span>}</div>
      <div className="wk-pick" role="group" aria-label={onDay ? `${title} — tapni dan, ko nimaš časa` : title}>
        {week.map(({ s, t, no, pinned }, i) => {
          const state = no ? 'ne gre' : s ? `${sessName(s)}${t ? ` + ${sessName(t)}` : ''}${pinned ? ' (določen dan)' : ''}` : 'prosto'
          return (
            <button key={i} type="button" className={`wk-d${no ? ' off' : ''}${s ? ' on' : ''}${pinned ? ' pin' : ''}`} disabled={!onDay || busy} aria-pressed={onDay ? no : undefined} aria-label={`${DAY_NAME[i]}: ${state}`} title={`${upper(DAY_NAME[i]!)}: ${state}`}
              style={s ? { ['--c' as string]: sessionColor(s) } : undefined} onClick={() => onDay?.(i)}>
              <small>{DAY_OPTS[i]}</small>
              <span className="wk-i" aria-hidden="true">{no ? '✕' : s ? <><SessionIcon s={s} size={15} />{t && <span className="wk-i2" style={{ ['--c' as string]: sessionColor(t) }}><SessionIcon s={t} size={10} /></span>}</> : '·'}</span>
            </button>
          )
        })}
      </div>
      <p className="wk-note" role="status" aria-live="polite">
        {note ?? <>{pins ? `${pins}. ` : ''}{off.length ? `Ne gre: ${off.map(x => DAY_NAME[x]).join(', ')}. ` : ''}{pins ? 'Ostalo je predlog — teden se sproti prilagaja temu, kar narediš.' : 'Razpored je predlog — teden se sproti prilagaja temu, kar narediš.'}</>}
      </p>
    </div>
  )
}

/** Seznam sej dogovora: kardio z istim dnem kot moč je vrstica pod njo (»nato tek«), določen dan je oznaka ob seji. */
export function SessionList({ f }: { f: Pick<Focus, 'sessions'> }) {
  const tails = useMemo(() => tailsOf(f.sessions), [f.sessions])
  const tailOf = useMemo(() => { const m = new Map<number, number>(); tails.forEach((i, j) => m.set(i, j)); return m }, [tails])
  const row = (s: AgreedSession, i: number, tail: boolean) => (
    <div key={i} className={`deal-row${tail ? ' tail' : ''}`} style={{ ['--c' as string]: sessionColor(s) }}>
      <span className="deal-ic"><SessionIcon s={s} /></span>
      <span style={{ flex: 1, minWidth: 0 }}>{tail && <span className="muted">nato </span>}<b>{SPORT_LABEL[s.type]}</b>{sessWhat(s) ? <span className="muted"> · {sessWhat(s)}</span> : null}</span>
      {s.day != null && !tail && <span className="deal-day" title="določen dan">{DAY_OPTS[s.day]}</span>}
      <span className="muted" style={{ fontWeight: 700, fontSize: 12.5 }}>{s.min} min</span>
    </div>
  )
  return (
    <div className="deal-list">
      {f.sessions.map((s, i) => (tails.has(i) ? null : <div key={i} className="deal-grp">{row(s, i, false)}{tailOf.has(i) ? row(f.sessions[tailOf.get(i)!]!, tailOf.get(i)!, true) : null}</div>))}
    </div>
  )
}
