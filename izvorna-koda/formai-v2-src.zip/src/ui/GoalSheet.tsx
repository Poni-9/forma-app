import { useState } from 'react'
import { useApp, updateProfile, saveCheckin, savePlanDays, toast } from '@/state/store'
import { buildWeek, FRANJA_2027, targetHours } from '@/domain/training/planner'
import { suggestedTargetFtp, levelOf } from '@/domain/training/goal'
import { weightTrend } from '@/domain/nutrition/energy'
import { addDays, todayIso, weekStartIso } from '@/domain/training/load'
import { Btn, Chip, Sheet } from '@/ui/primitives'

const num = (v: string) => (v.trim() === '' ? null : +v.replace(',', '.'))
const f2 = (x: number) => x.toFixed(2).replace('.', ',')

/**
 * Cilj sezone v enem koraku: dirka, izhodišče (FTP, teža), cilj (FTP, teža), ure.
 * Potrditev začne makrocikel ta ponedeljek in takoj sestavi ta teden.
 */
export function GoalSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const app = useApp()
  const p = app.profile
  const tr = weightTrend(app.checkins)
  const ev = p.event?.date ? p.event : FRANJA_2027
  const w0 = tr?.avg7 ?? p.weightKg ?? null
  const [f, setF] = useState({
    name: ev.name, date: ev.date, km: String(ev.distanceKm ?? 156),
    ftp: p.ftp ? String(p.ftp) : '', weight: w0 ? String(w0) : '',
    tFtp: String(p.targetFtp ?? suggestedTargetFtp(p.ftp) ?? ''), tW: String(p.targetWeightKg ?? ''),
    hours: String(p.hoursPerWeek && p.hoursPerWeek >= 12 ? Math.min(14, p.hoursPerWeek) : 12), str: String(p.strength.on ? Math.min(2, p.strengthDays ?? 2) : 0),
  })
  const ftp = num(f.ftp), weight = num(f.weight), tFtp = num(f.tFtp), tW = num(f.tW)
  const now = ftp && weight ? ftp / weight : null
  const goal = tFtp && (tW || weight) ? tFtp / (tW || weight!) : null
  const weeks = f.date ? Math.max(0, Math.round((new Date(f.date).getTime() - new Date(app.today).getTime()) / (7 * 86400_000))) : null
  const kgWeek = weight && tW && weeks ? (weight - tW) / Math.max(1, weeks * 0.68) : null
  const tooFast = kgWeek != null && kgWeek > 0.5

  async function save() {
    if (!f.name.trim() || !f.date) { toast('Vpiši dirko in datum.', 'err'); return }
    if (f.date <= app.today) { toast('Datum dirke mora biti v prihodnosti.', 'err'); return }
    const ws = weekStartIso(app.today)
    const next = {
      event: { name: f.name.trim().slice(0, 60), date: f.date, distanceKm: num(f.km) },
      ftp: ftp ?? p.ftp ?? null, ftpDate: ftp && ftp !== p.ftp ? todayIso() : p.ftpDate ?? null,
      weightKg: weight ?? p.weightKg ?? null, targetFtp: tFtp, targetWeightKg: tW,
      hoursPerWeek: num(f.hours) ?? targetHours(p), strengthDays: +f.str, strength: { ...p.strength, on: +f.str > 0 },
      goal: 'dirka' as const, cycleStart: ws, goalStart: { date: app.today, ftp: ftp ?? p.ftp ?? null, weightKg: weight ?? p.weightKg ?? null },
    }
    const prof = await updateProfile(next)
    if (weight && weight !== w0) { const prev = app.checkins.find(c => c.date === app.today); await saveCheckin({ ...(prev || { date: app.today }), date: app.today, weightKg: weight }) }
    // ta in naslednji teden takoj — opravljeni dnevi ostanejo
    const rain: Record<string, number> = {}
    if (app.weather) for (const k in app.weather) rain[k] = app.weather[k]!.rain
    const doneDates = new Set(app.plan.filter(d => d.done).map(d => d.date))
    const w1 = buildWeek({ profile: prof, activities: app.activities, weekStart: ws, rain, firstWeek: true, notBefore: app.today })
    const w2 = buildWeek({ profile: prof, activities: app.activities, weekStart: addDays(ws, 7), rain, notBefore: addDays(ws, 7) })
    await savePlanDays([...w1, ...w2].filter(d => !doneDates.has(d.date)))
    toast(`Cilj potrjen: ${next.event.name}. Načrt za ta in naslednji teden je sestavljen.`, 'ok', 6000)
    onClose()
  }

  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value })
  return (
    <Sheet open={open} onClose={onClose}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Cilj sezone</b>
      <p style={{ fontSize: 12.5, marginTop: 4 }}>Načrt bo makrocikel do tega dne: osnova → gradnja → specifično → tapering. Vse ostalo v aplikaciji se podredi temu.</p>
      <div className="stack" style={{ gap: 10, marginTop: 12 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div className="field"><label>Dirka</label><input value={f.name} onChange={set('name')} /></div>
          <div className="field"><label>Datum</label><input type="date" value={f.date} onChange={set('date')} /></div>
        </div>
        <div className="field"><label>Dolžina</label>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>{[['156', 'Velika · 156 km'], ['97', 'Mala · 97 km']].map(([v, l]) => <Chip key={v} sm on={f.km === v} onClick={() => setF({ ...f, km: v! })}>{l}</Chip>)}</div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div className="field"><label>FTP zdaj <span className="unit">W</span></label><input type="number" inputMode="numeric" value={f.ftp} onChange={set('ftp')} /></div>
          <div className="field"><label>Teža zdaj <span className="unit">kg</span></label><input type="number" inputMode="decimal" step={0.1} value={f.weight} onChange={set('weight')} /></div>
          <div className="field"><label>Ciljni FTP <span className="unit">W</span></label><input type="number" inputMode="numeric" value={f.tFtp} onChange={set('tFtp')} /></div>
          <div className="field"><label>Ciljna teža <span className="unit">kg</span></label><input type="number" inputMode="decimal" step={0.5} value={f.tW} onChange={set('tW')} /></div>
        </div>
        <div className="card tight" style={{ background: 'var(--raised)' }}>
          <div className="between" style={{ fontSize: 13 }}><span className="muted" style={{ fontWeight: 700 }}>Zdaj</span><b>{now ? `${f2(now)} W/kg` : '—'}{now && levelOf(now) ? <span className="muted" style={{ fontWeight: 600 }}> · {levelOf(now)!.name.toLowerCase()}</span> : null}</b></div>
          <div className="between" style={{ fontSize: 13, marginTop: 4 }}><span className="muted" style={{ fontWeight: 700 }}>Na dan dirke</span><b style={{ color: 'var(--accent)' }}>{goal ? `${f2(goal)} W/kg` : '—'}{goal && levelOf(goal) ? <span className="muted" style={{ fontWeight: 600 }}> · {levelOf(goal)!.name.toLowerCase()}</span> : null}</b></div>
          {weeks != null && <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>{weeks} tednov{kgWeek != null && kgWeek > 0 ? ` · hujšanje ~${kgWeek.toFixed(2).replace('.', ',')} kg na teden do konca gradnje` : ''}</div>}
          {tooFast && <div style={{ fontSize: 12, marginTop: 6, color: 'var(--warn)', fontWeight: 600 }}>Prehitro: več kot 0,5 kg na teden pomeni izgubo mišic in vatov. Ciljna teža naj bo višja ali pa jo dosežeš po dirki.</div>}
        </div>
        <div className="field"><label>Ure na kolesu v normalnem tednu</label>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>{['8', '10', '11', '12', '13', '14'].map(v => <Chip key={v} sm on={f.hours === v} onClick={() => setF({ ...f, hours: v })}>{v} h</Chip>)}</div>
          <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>Bloki 3 + 1: ~−12 % · normalno · ~+12 % · razbremenitev ~50 %. V osnovi začne nižje in raste. Za največji napredek 12–13 h.</div>
        </div>
        <div className="field"><label>Moč (jedro + noge)</label>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>{[['0', 'brez'], ['1', '1× · noge'], ['2', '2× · jedro + noge']].map(([v, l]) => <Chip key={v} sm on={f.str === v} onClick={() => setF({ ...f, str: v! })}>{l}</Chip>)}</div>
        </div>
      </div>
      <Btn primary block style={{ marginTop: 14 }} onClick={save}>Potrdi cilj in sestavi načrt</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Prekliči</Btn>
      <p className="muted" style={{ fontSize: 11, marginTop: 10 }}>⚕️ Načrt je trenerska usmeritev, ne zdravniški nasvet. Ob bolečini, bolezni ali zdravstvenih težavah se posvetuj z zdravnikom.</p>
    </Sheet>
  )
}
