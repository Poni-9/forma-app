import { useState } from 'react'
import { useApp, updateProfile, saveCheckin, savePlanDays, updateSettings, toast } from '@/state/store'
import { buildWeek, FRANJA_2027, targetHours } from '@/domain/training/planner'
import { ftpPotential, levelOf, raceWeightOf, hoursAdvice } from '@/domain/training/goal'
import { seasonGoals, raceMinutes } from '@/domain/training/season'
import { weightTrend } from '@/domain/nutrition/energy'
import { addDays, todayIso, weekStartIso } from '@/domain/training/load'
import type { Profile } from '@/domain/types'
import { Btn, Chip, Sheet } from '@/ui/primitives'

const num = (v: string) => (v.trim() === '' ? null : +v.replace(',', '.'))
const f1 = (x: number) => x.toFixed(1).replace('.', ',')
const f2 = (x: number) => x.toFixed(2).replace('.', ',')
/** Začetek načrta iz shranjenega baseHours (1,2 × dejanske ure, najmanj 4), zaokroženo na 0,5. */
const startFrom = (base: number | null) => (base == null ? null : Math.round(Math.max(4, base * 1.2) * 2) / 2)
const fh = (x: number) => String(Math.round(x * 2) / 2).replace('.', ',')

/**
 * Cilj sezone v enem koraku. Vpišeš samo, kar veš (dirka, FTP zdaj, teža zdaj, ure) —
 * najboljšo težo in največji možni FTP izračuna aplikacija sama. Potrditev začne makrocikel in sestavi dva tedna.
 */
export function GoalSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const app = useApp()
  const p = app.profile
  const tr = weightTrend(app.checkins)
  const ev = p.event?.date ? p.event : FRANJA_2027
  const w0 = tr?.avg7 ?? p.weightKg ?? null
  const [f, setF] = useState({
    name: ev.name, date: ev.date, km: String(ev.distanceKm ?? 156),
    ftp: p.ftp ? String(p.ftp) : '', weight: w0 ? String(w0) : '', bf: p.bodyFatPct ? String(p.bodyFatPct) : '',
    hours: String(p.hoursPerWeek ?? 12), str: String(p.strength.on ? Math.min(2, p.strengthDays ?? 2) : 0),
    time: p.trainTime || 'popoldne',
    // »največ, kar gre« (iz voženj) ali »sam določim« (koliko časa imaš)
    mode: (p.hoursMode ?? (p.hoursPerWeek ? 'own' : 'max')) as 'max' | 'own',
    start: String(startFrom(p.baseHours ?? null) ?? ''),
    seasons: p.trainingSeasons != null ? String(p.trainingSeasons) : '',
  })
  const ftp = num(f.ftp), weight = num(f.weight), bf = num(f.bf)
  const adv = hoursAdvice(app.activities, { hoursPerWeek: p.hoursPerWeek, age: p.age, event: f.date ? { name: f.name, date: f.date } : null }, app.today)
  const autoStart = adv.start
  const T = f.mode === 'max' ? adv.max : Math.max(3, Math.min(30, num(f.hours) || 12))
  // »načrt začne pri« → baseHours (rampCap = max(4; 1,2 × baseHours)); enako ali več od cilja = brez rampe
  const startH = Math.max(3, Math.min(num(f.start) || autoStart, T))
  const baseH = startH >= T ? null : +(startH / 1.2).toFixed(2)
  const reachWeeks = startH < T ? Math.ceil(Math.log(T / startH) / Math.log(1.1)) : 0
  // predogled z vpisanimi številkami, kot bi bile ob potrditvi
  const seasons = f.seasons ? +f.seasons : null
  const draft: Profile = { ...p, event: { ...(p.event || {}), name: f.name, date: f.date, distanceKm: num(f.km) }, ftp: ftp ?? p.ftp, weightKg: weight ?? p.weightKg, bodyFatPct: bf, hoursPerWeek: T, targetFtp: null, targetWeightKg: null, goalStart: { date: app.today, ftp: ftp ?? p.ftp ?? null, weightKg: weight ?? p.weightKg ?? null }, baseHours: baseH, cycleStart: weekStartIso(app.today), trainingSeasons: seasons }
  const rw = raceWeightOf(draft, app.today)
  const pot = ftpPotential(draft, app.today)
  // primerjava načinov: FTP ob cilju pri »največjem napredku« in pri tvojem času
  const potAt = (h: number) => ftpPotential({ ...draft, hoursPerWeek: h, baseHours: startH >= h ? null : +(startH / 1.2).toFixed(2) }, app.today)
  const potMax = potAt(adv.max), ownH = Math.max(3, Math.min(30, num(f.hours) || 12)), potOwn = potAt(ownH)
  // zahteve tekem: najdaljši cilj sezone → koliko ur v gradnji je smiselno (dolga vožnja ~85 % dirke)
  const longest = seasonGoals(draft).map(g => ({ g, min: raceMinutes(g) })).sort((a, b) => b.min - a.min)[0]
  const needH = longest && longest.min >= 150 ? Math.round(Math.max(8, Math.min(22, 2.5 * (longest.min / 60) + 3)) * 2) / 2 : null
  const now = ftp && weight ? ftp / weight : null
  const goal = pot && rw ? pot.ideal / rw.kg : null
  const real = pot && rw ? pot.realistic / rw.kg : null
  const weeks = f.date ? Math.max(0, Math.round((new Date(f.date).getTime() - new Date(app.today).getTime()) / (7 * 86400_000))) : null
  const kgWeek = weight && rw && weeks ? (weight - rw.kg) / Math.max(1, weeks * 0.68) : null

  async function save() {
    if (!f.name.trim() || !f.date) { toast('Vpiši dirko in datum.', 'err'); return }
    if (f.date <= app.today) { toast('Datum dirke mora biti v prihodnosti.', 'err'); return }
    if (!ftp || !weight) { toast('Vpiši FTP in težo — iz njiju izračunam vse ostalo.', 'err'); return }
    const ws = weekStartIso(app.today)
    const keep = !!p.cycleStart && p.event?.date === f.date && p.cycleStart <= ws
    const next: Partial<Profile> = {
      event: { ...(p.event || {}), name: f.name.trim().slice(0, 60), date: f.date, distanceKm: num(f.km) },
      ftp, ftpDate: ftp !== p.ftp ? todayIso() : p.ftpDate ?? null, weightKg: weight, bodyFatPct: bf,
      targetFtp: null, targetWeightKg: null,   // samodejno: najboljša teža in največji možni FTP
      hoursPerWeek: T ?? targetHours(p), hoursMode: f.mode, strengthDays: +f.str, strength: { ...p.strength, on: +f.str > 0 },
      // isti cilj (npr. samo druge ure ali FTP): makrocikel teče naprej, ne začne znova z lahkimi tedni
      trainTime: f.time as Profile['trainTime'], goal: 'dirka', cycleStart: keep ? p.cycleStart : ws, ...(keep ? {} : { offSeasonWeeks: 0 }), goalStart: { date: app.today, ftp, weightKg: weight }, trainingSeasons: seasons,
      baseHours: baseH,   // načrt raste od izbranega začetka (privzeto iz tega, kar res voziš)
    }
    const prof = await updateProfile(next)
    if (weight !== w0) { const prev = app.checkins.find(c => c.date === app.today); await saveCheckin({ ...(prev || { date: app.today }), date: app.today, weightKg: weight }) }
    const rain: Record<string, number> = {}
    if (app.weather) for (const k in app.weather) rain[k] = app.weather[k]!.rain
    const doneDates = new Set(app.plan.filter(d => d.done).map(d => d.date))
    const w1 = buildWeek({ profile: prof, activities: app.activities, weekStart: ws, rain, firstWeek: !keep, notBefore: app.today })
    const w2 = buildWeek({ profile: prof, activities: app.activities, weekStart: addDays(ws, 7), rain, notBefore: addDays(ws, 7) })
    await savePlanDays([...w1, ...w2].filter(d => !doneDates.has(d.date)))
    if (!p.event?.date) await updateSettings({ guideSeen: false })   // prvi cilj: vodnik »Kako deluje« se pokaže na Danes
    toast(`Cilj potrjen: ${next.event!.name}. Načrt za ta in naslednji teden je sestavljen.`, 'ok', 6000)
    onClose()
  }

  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value })
  return (
    <Sheet open={open} onClose={onClose}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Cilj sezone</b>
      <p style={{ fontSize: 12.5, marginTop: 4 }}>Vpiši, kar veš. Najboljšo težo in največji možni FTP izračunam sam — načrt, prehrana in AI trener se ravnajo po tem.</p>
      <div className="stack" style={{ gap: 10, marginTop: 12 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div className="field"><label>Dirka</label><input value={f.name} onChange={set('name')} /></div>
          <div className="field"><label>Datum</label><input type="date" value={f.date} onChange={set('date')} /></div>
        </div>
        <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>{[['156', 'Velika · 156 km'], ['97', 'Mala · 97 km']].map(([v, l]) => <Chip key={v} sm on={f.km === v} onClick={() => setF({ ...f, km: v! })}>{l}</Chip>)}</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
          <div className="field"><label>FTP zdaj <span className="unit">W</span></label><input type="number" inputMode="numeric" value={f.ftp} onChange={set('ftp')} /></div>
          <div className="field"><label>Teža <span className="unit">kg</span></label><input type="number" inputMode="decimal" step={0.1} value={f.weight} onChange={set('weight')} /></div>
          <div className="field"><label>Maščoba <span className="unit">%, če veš</span></label><input type="number" inputMode="decimal" step={0.5} value={f.bf} onChange={set('bf')} placeholder="ocena" /></div>
        </div>

        <div className="field"><label>Koliko sezon že resno treniraš</label>
          <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>{[['1', 'prva'], ['2', 'druga'], ['3', '3.–4.'], ['6', '5.–7.'], ['9', '8 ali več']].map(([v, l]) => <Chip key={v} sm on={f.seasons === v} onClick={() => setF({ ...f, seasons: f.seasons === v ? '' : v! })}>{l}</Chip>)}</div>
          <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>Po več letih treninga je prostora za napredek manj (profesionalec po desetih sezonah skoraj ne napreduje), v prvih sezonah veliko več. Do 20. leta telo še zori.</div>
        </div>

        <div className="card tight" style={{ background: 'var(--raised)' }}>
          <div className="between" style={{ fontSize: 13 }}><span className="muted" style={{ fontWeight: 700 }}>Najboljša teža zate</span><b style={{ color: 'var(--accent)' }}>{rw ? `${f1(rw.kg)} kg` : '—'}</b></div>
          {rw && <div className="muted" style={{ fontSize: 11.5, marginTop: 2 }}>{rw.measured ? 'Maščoba' : 'Ocena maščobe iz BMI'} ~{Math.round(rw.bf)} % → cilj ~{rw.targetBf} % (trenirani kolesarji 8–11 %); pusta masa {f1(rw.lbm)} kg ostane. Razpon {f1(rw.lo)}–{f1(rw.hi)} kg{rw.limitedByTime ? ' — omejeno s časom do dirke' : ''}.{kgWeek != null && kgWeek > 0 ? ` Tempo ~${f2(kgWeek)} kg na teden.` : ''}</div>}
          <div className="between" style={{ fontSize: 13, marginTop: 8 }}><span className="muted" style={{ fontWeight: 700 }}>FTP na dan dirke</span><b>{pot ? <>realno {pot.realistic} W · <span style={{ color: 'var(--accent)' }}>največ {pot.ideal} W</span></> : '—'}</b></div>
          {pot && <div className="muted" style={{ fontSize: 11.5, marginTop: 2 }}>+{pot.gainPct} % v {pot.weeks} tednih pri povprečno {f1(pot.hours)} h na teden{draft.baseHours != null ? ' (načrt raste od tvojih dejanskih ur)' : ''}{seasons ? `, ${seasons <= 1 ? 'prva sezona treninga' : seasons <= 2 ? 'druga sezona' : seasons <= 4 ? '3.–4. sezona' : seasons <= 7 ? '5.–7. sezona' : '8 ali več sezon'}` : ''}. Od 4 W/kg naprej in po več sezonah gre počasneje; genetskega stropa ne pozna nihče — pokažejo ga testi.</div>}
          <div className="between" style={{ fontSize: 13, marginTop: 8 }}><span className="muted" style={{ fontWeight: 700 }}>W/kg</span><b>{now ? f2(now) : '—'} → <span style={{ color: 'var(--accent)' }}>{goal ? f2(goal) : '—'}</span>{real ? <span className="muted" style={{ fontWeight: 600 }}> (realno {f2(real)})</span> : null}</b></div>
          {now && goal && <div className="muted" style={{ fontSize: 11.5, marginTop: 2 }}>{levelOf(now)?.name.toLowerCase()} → {levelOf(goal)?.name.toLowerCase()}</div>}
        </div>

        <div className="field"><label>Koliko ur na teden</label>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>
            <Chip sm on={f.mode === 'max'} onClick={() => setF({ ...f, mode: 'max' })}>Največji napredek · {fh(adv.max)} h</Chip>
            <Chip sm on={f.mode === 'own'} onClick={() => setF({ ...f, mode: 'own' })}>Po mojem času</Chip>
          </div>
          {potMax && potOwn && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginTop: 8 }}>
              <div className="card tight" style={{ background: 'var(--raised)', borderColor: f.mode === 'max' ? 'var(--accent)' : undefined }}><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>NAJVEČJI NAPREDEK</div><b style={{ fontSize: 14 }}>{fh(adv.max)} h → ~{potMax.realistic} W</b><div className="muted" style={{ fontSize: 11 }}>največ {potMax.ideal} W · ure določam sam in jih dvignem, ko zmoreš več</div></div>
              <div className="card tight" style={{ background: 'var(--raised)', borderColor: f.mode === 'own' ? 'var(--accent)' : undefined }}><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>PO TVOJEM ČASU</div><b style={{ fontSize: 14 }}>{fh(ownH)} h → ~{potOwn.realistic} W</b><div className="muted" style={{ fontSize: 11 }}>največ {potOwn.ideal} W · ure ostanejo, kot jih izbereš</div></div>
            </div>
          )}
          {needH && longest && <div style={{ fontSize: 12, marginTop: 8, color: 'var(--ink-2)' }}>Najdaljša tekma sezone: <b>{longest.g.name}</b> (~{fh(longest.min / 60)} h) — za dobro pripravo vsaj ~{fh(needH)} h na teden v gradnji in dolge vožnje do ~{fh(Math.min(6.5, longest.min * 0.85 / 60))} h.{T < needH ? ` Izbranih ${fh(T)} h je manj — dirko boš prevozil, a zadnja ura bo težka.` : ''}</div>}
          {f.mode === 'max' ? (
            <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>
              {adv.basis === 'history'
                ? `Iz tvojih voženj: najdaljši teden v zadnjem letu ${fh(adv.peak!)} h, povprečje leta ${fh(adv.yearAvg!)} h, zadnjih 8 tednov ${fh(adv.recent ?? 0)} h. Največ, kar varno zgradiš: ~1,3 × najdaljši teden`
                : adv.basis === 'stated' ? `Voženj še ne vidim (poveži uro v Nastavitve → Uvoz), zato iz tvojih vpisanih ${fh(p.hoursPerWeek!)} h × 1,3`
                : 'Brez voženj in vpisanih ur začnem z 10 h'}
              {adv.limitedBy === 'cap' ? `, omejeno na ${fh(adv.cap)} h (več, ko ga že voziš)` : adv.limitedBy === 'youth' ? ', do 18. leta največ 12 h' : adv.limitedBy === 'time' ? ' — do dirke več ne zraste (+10 % na teden)' : ''}.
              {` Tretji teden bloka ~${fh(T * 1.12)} h, vsak 4. teden ~${fh(T * 0.52)} h. Nad ~14 h je napredek na uro manjši.`}
            </div>
          ) : (<>
            <div className="row" style={{ gap: 7, flexWrap: 'wrap', marginTop: 8, alignItems: 'center' }}>
              {[6, 8, 10, 12, 14, 16, 18, 20, 25, 30].map(v => <Chip key={v} sm on={num(f.hours) === v} onClick={() => setF({ ...f, hours: String(v) })}>{v} h</Chip>)}
              <input type="number" inputMode="decimal" min={3} max={30} step={0.5} value={f.hours} onChange={set('hours')} aria-label="ur na teden" style={{ width: 74, padding: '6px 10px' }} />
            </div>
            <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>Toliko časa imaš v normalnem tednu (3–30 h). {T > 20 ? 'Za primerjavo: profesionalci WorldTour v pripravljalnem obdobju povprečno ~19 h na teden, najtežji teden ~22,5 h; 25–30 h le na pripravah. ' : ''}{T > adv.max + 0.25 ? `To je več od ${fh(adv.max)} h, kolikor kaže tvoja zgodovina — raste postopoma, pazi na spanec in utrujenost. ` : ''}Vsak 4. teden ~50 %.</div>
          </>)}
        </div>
        <div className="field"><label>Načrt začne pri</label>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>{[4, 5, 6, 7, 8, 10, 12, 14, 16, 20].filter(v => v <= T).map(v => <Chip key={v} sm on={startH === v} onClick={() => setF({ ...f, start: String(v) })}>{v} h</Chip>)}</div>
          <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>{adv.recent != null ? `Zadnjih 8 tednov voziš ~${fh(adv.recent)} h na teden (predlog ${fh(autoStart)} h). ` : `Predlog ${fh(autoStart)} h. `}{reachWeeks > 0 ? `Raste +10 % na teden; ${fh(T)} h dosežeš v ~${reachWeeks} tednih.` : `Brez postopne rasti — ${fh(T)} h že ta teden.`} Če začneš precej nad tem, kar res voziš, tvegaš bolezen ali poškodbo.</div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div className="field"><label>Kdaj treniraš</label>
            <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>{[['zjutraj', 'zjutraj'], ['popoldne', 'popoldne'], ['zvecer', 'zvečer']].map(([v, l]) => <Chip key={v} sm on={f.time === v} onClick={() => setF({ ...f, time: v! as typeof f.time })}>{l}</Chip>)}</div>
          </div>
          <div className="field"><label>Moč</label>
            <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>{[['0', 'brez'], ['1', '1×'], ['2', '2×']].map(([v, l]) => <Chip key={v} sm on={f.str === v} onClick={() => setF({ ...f, str: v! })}>{l}</Chip>)}</div>
          </div>
        </div>
      </div>
      <Btn primary block style={{ marginTop: 14 }} onClick={save}>Potrdi in sestavi načrt</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Prekliči</Btn>
      <p className="muted" style={{ fontSize: 11, marginTop: 10 }}>⚕️ Načrt je trenerska usmeritev, ne zdravniški nasvet. Teža nikoli pod BMI 20,5, hujšanje največ ~0,5 kg na teden. Ob bolečini, bolezni ali zdravstvenih težavah se posvetuj z zdravnikom.</p>
    </Sheet>
  )
}
