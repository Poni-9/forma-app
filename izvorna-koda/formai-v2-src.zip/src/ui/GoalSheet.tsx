import { useRef, useState } from 'react'
import { useApp, updateProfile, saveCheckin, savePlanDays, updateSettings, toast, keepOwn } from '@/state/store'
import { buildWeek, FRANJA_2027, targetHours } from '@/domain/training/planner'
import { ftpPotential, levelOf, raceWeightOf, hoursAdvice } from '@/domain/training/goal'
import { seasonGoals, raceMinutes } from '@/domain/training/season'
import { offSeasonNow, cyclePatch } from '@/domain/training/goalChange'
import { OFF_MIX, offMixOf } from '@/domain/training/offMix'
import { weightTrend } from '@/domain/nutrition/energy'
import { addDays, todayIso, weekStartIso } from '@/domain/training/load'
import type { Profile } from '@/domain/types'
import { Btn, Chip, Sheet, DecimalInput } from '@/ui/primitives'
import { DateField, fmtDateSl } from '@/ui/DateField'
import { HealthNote } from '@/ui/HealthNote'
import { profileErrors } from '@/domain/ranges'
import { plural } from '@/ui/format'
import { rem } from '@/ui/rem'

/**
 * (v3.51) Stari dogodek pod novim imenom: vrsta, vzpon in raven veljajo samo za isto dirko — »VN Kranj« ne podeduje
 * »maratona« in 1 600 m Franje (prej skrito v načrtu: trajanje dirke, dolge vožnje, gorivo). Vrsto nato določi ime.
 */
export function eventBase(ev: Profile['event'], name: string): Partial<NonNullable<Profile['event']>> {
  if (!ev) return {}
  if (ev.name.trim().toLowerCase() === name.trim().toLowerCase()) return ev
  const { type: _t, elevM: _e, level: _l, distanceKm: _d, ...rest } = ev
  void _t; void _e; void _l; void _d
  return rest
}
/** mestnik: v 1 tednu, v 2 tednih */
const V_TEDNIH = ['tednu', 'tednih', 'tednih', 'tednih'] as const

const num = (v: string) => (v.trim() === '' ? null : +v.replace(',', '.'))
const f1 = (x: number) => x.toFixed(1).replace('.', ',')
const f2 = (x: number) => x.toFixed(2).replace('.', ',')
/** Začetek načrta iz shranjenega baseHours (1,2 × dejanske ure, najmanj 4), zaokroženo na 0,5. */
const startFrom = (base: number | null) => (base == null ? null : Math.round(Math.max(4, base * 1.2) * 2) / 2)
const fh = (x: number) => String(Math.round(x * 2) / 2).replace('.', ',')

/**
 * Cilj sezone v enem koraku. Vpišeš samo, kar veš (dirka, FTP zdaj, teža zdaj, ure) —
 * najboljšo težo in največji možni FTP izračuna aplikacija sama. Potrditev začne makrocikel in sestavi dva tedna.
 */
export function GoalSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const app = useApp()
  const p = app.profile
  const tr = weightTrend(app.checkins)
  // brez cilja začnemo prazno — Franja je samo predlog (čip), ne privzeta vrednost
  const ev = p.event?.date ? p.event : null
  const w0 = tr?.avg7 ?? p.weightKg ?? null
  const [f, setF] = useState({
    name: ev?.name ?? '', date: ev?.date ?? '', km: ev?.distanceKm ? String(ev.distanceKm) : '', elev: ev?.elevM ? String(ev.elevM) : '',
    ftp: p.ftp ? String(p.ftp) : '', weight: w0 ? String(w0) : '', bf: p.bodyFatPct ? String(p.bodyFatPct) : '',
    hours: String(p.hoursPerWeek ?? 12), str: String(p.strength.on ? Math.min(2, p.strengthDays ?? 2) : 0),
    // (v3.50) »različno« ostane različno (prej je postalo »popoldne« in se tako shranilo)
    time: (p.trainTime ?? null) as Profile['trainTime'],
    // »največ, kar gre« (iz voženj) ali »sam določim« (koliko časa imaš)
    mode: (p.hoursMode ?? (p.hoursPerWeek ? 'own' : 'max')) as 'max' | 'own',
    start: String(startFrom(p.baseHours ?? null) ?? ''),
    seasons: p.trainingSeasons != null ? String(p.trainingSeasons) : '',
  })
  const f0 = useRef(f)
  // (v3.49) razponi kot v profilu: FTP 5000 W ali 7,6 kg se ne shrani (prej cilj 22 016 kcal in 14 g beljakovin)
  const errs = profileErrors({ ftp: f.ftp, weight: f.weight, bf: f.bf, ...(f.mode === 'own' ? { hours: f.hours } : {}) })
  const errText = Object.values(errs).join(' ')
  const fieldErr = [errs.ftp, errs.weight, errs.bf].filter(Boolean).join(' ')
  const ftp = errs.ftp ? null : num(f.ftp), weight = errs.weight ? null : num(f.weight), bf = errs.bf ? null : num(f.bf)
  // sredi off-seasona: potrditev cilja privzeto konča off-season (načrt se spremeni); lahko ostaneš do konca
  const offNow = offSeasonNow(p, app.today)
  const [endOff, setEndOff] = useState(true)
  const [missing, setMissing] = useState<{ k: 'name' | 'date' | 'weight'; id: string; t: string } | null>(null)
  // (v3.50) do 18. leta ni najboljše teže ne cilja maščobe — cilj so vati in redni trening
  const minor = !!p.age && p.age < 18
  const adv = hoursAdvice(app.activities, { hoursPerWeek: p.hoursPerWeek, age: p.age, event: f.date ? { name: f.name, date: f.date } : null }, app.today)
  const autoStart = adv.start
  const T = f.mode === 'max' ? adv.max : Math.max(3, Math.min(30, num(f.hours) || 12))
  // »načrt začne pri« → baseHours (rampCap = max(4; 1,2 × baseHours)); enako ali več od cilja = brez rampe
  const startH = Math.max(3, Math.min(num(f.start) || autoStart, T))
  const baseH = startH >= T ? null : +(startH / 1.2).toFixed(2)
  const reachWeeks = startH < T ? Math.ceil(Math.log(T / startH) / Math.log(1.1)) : 0
  // predogled z vpisanimi številkami, kot bi bile ob potrditvi
  const seasons = f.seasons ? +f.seasons : null
  // (v3.51) isti cilj z istim FTP in težo: izhodišče cilja (goalStart) in makrocikel ostaneta — list kaže iste številke kot
  // kartica cilja in potrditev brez sprememb jih ne premakne (prej 72,0 → 72,5 kg, 291 → 286 W samo z odprtjem in Potrdi)
  const sameGoal = !!p.event?.date && p.event.date === f.date && p.event.name.trim().toLowerCase() === f.name.trim().toLowerCase()
  const keepStart = sameGoal && !!p.goalStart && (ftp ?? p.ftp ?? null) === (p.ftp ?? null) && f.weight === (w0 ? String(w0) : '')
  const startOf = (ftpNow: number | null, wNow: number | null) => (keepStart ? p.goalStart! : { date: app.today, ftp: ftpNow, weightKg: wNow })
  const upTo = (v: string, max: number) => { const x = num(v); return x != null && x > 0 && x <= max ? Math.round(x) : null }
  const evOf = (name: string): NonNullable<Profile['event']> => ({ ...eventBase(p.event, name), name, date: f.date, distanceKm: upTo(f.km, 1000), elevM: upTo(f.elev, 10000) })
  // nič spremenjeno: tudi ure in začetek rampe ostanejo, kot so v profilu
  const pristine = sameGoal && JSON.stringify(f) === JSON.stringify(f0.current)
  const hoursNext = pristine && p.hoursPerWeek ? p.hoursPerWeek : T, baseNext = pristine ? p.baseHours ?? null : baseH
  const draft: Profile = { ...p, event: f.date ? evOf(f.name || 'Cilj') : null, ftp: ftp ?? p.ftp, weightKg: weight ?? p.weightKg, bodyFatPct: bf, hoursPerWeek: hoursNext, targetFtp: null, targetWeightKg: null, goalStart: startOf(ftp ?? p.ftp ?? null, weight ?? p.weightKg ?? null), baseHours: baseNext, ...cyclePatch(p, f.date, app.today, endOff).patch, trainingSeasons: seasons }
  const rw = raceWeightOf(draft, app.today)
  const pot = ftpPotential(draft, app.today)
  // primerjava načinov: FTP ob cilju pri »največjem napredku« in pri tvojem času
  const potAt = (h: number) => ftpPotential({ ...draft, hoursPerWeek: h, baseHours: startH >= h ? null : +(startH / 1.2).toFixed(2) }, app.today)
  const potMax = potAt(adv.max), ownH = Math.max(3, Math.min(30, num(f.hours) || 12)), potOwn = potAt(ownH)
  // zahteve tekem: najdaljši cilj sezone → koliko ur v gradnji je smiselno (dolga vožnja ~85 % dirke)
  const longest = seasonGoals(draft).map(g => ({ g, min: raceMinutes(g) })).sort((a, b) => b.min - a.min)[0]
  const needH = longest && longest.min >= 150 ? Math.round(Math.max(8, Math.min(22, 2.5 * (longest.min / 60) + 3)) * 2) / 2 : null
  const now = ftp && weight ? ftp / weight : null
  const goal = pot && rw ? pot.ideal / rw.kg : null
  const real = pot && rw ? pot.realistic / rw.kg : null
  const weeks = f.date ? Math.max(0, Math.round((new Date(f.date).getTime() - new Date(app.today).getTime()) / (7 * 86400_000))) : null
  const kgWeek = weight && rw && weeks ? (weight - rw.kg) / Math.max(1, weeks * 0.68) : null

  async function save() {
    if (errText) return
    // (v3.50) sporočilo pod poljem in fokus v polje (prej obvestilo za nekaj sekund, fokus na »Potrdi«)
    const miss = !f.name.trim() ? { k: 'name' as const, id: 'gs-name', t: 'Vpiši ime dirke.' }
      : !f.date ? { k: 'date' as const, id: 'gs-date', t: 'Izberi datum dirke.' }
      : f.date <= app.today ? { k: 'date' as const, id: 'gs-date', t: 'Datum dirke mora biti v prihodnosti.' }
      // FTP je neobvezen (»ne vem« — v načrtu je test); teža je nujna za W/kg (in najboljšo težo od 18. leta)
      : !weight ? { k: 'weight' as const, id: 'gs-w', t: minor ? 'Vpiši težo — iz nje izračunam W/kg.' : 'Vpiši težo — iz nje izračunam najboljšo težo in W/kg.' }
      : null
    if (miss) { setMissing(miss); document.getElementById(miss.id)?.focus(); return }
    setMissing(null)
    const ftpNext = ftp ?? p.ftp ?? null
    const ws = weekStartIso(app.today)
    const cyc = cyclePatch(p, f.date, app.today, endOff)
    const next: Partial<Profile> = {
      event: evOf(f.name.trim().slice(0, 60)),
      ftp: ftpNext, ftpDate: ftp != null && ftp !== p.ftp ? todayIso() : p.ftpDate ?? null, weightKg: weight, bodyFatPct: bf,
      targetFtp: null, targetWeightKg: null,   // samodejno: najboljša teža in največji možni FTP
      hoursPerWeek: hoursNext ?? targetHours(p), hoursMode: f.mode, strengthDays: +f.str, strength: { ...p.strength, on: +f.str > 0 },
      // isti cilj (npr. samo druge ure ali FTP): makrocikel teče naprej, ne začne znova z lahkimi tedni
      trainTime: f.time as Profile['trainTime'], goal: 'dirka', ...cyc.patch, goalStart: startOf(ftpNext, weight), trainingSeasons: seasons,
      baseHours: baseNext,   // načrt raste od izbranega začetka (privzeto iz tega, kar res voziš)
    }
    const prof = await updateProfile(next)
    if (weight !== w0) { const prev = app.checkins.find(c => c.date === app.today); await saveCheckin({ ...(prev || { date: app.today }), date: app.today, weightKg: weight }) }
    const rain: Record<string, number> = {}
    if (app.weather) for (const k in app.weather) rain[k] = app.weather[k]!.rain
    const doneDates = new Set(app.plan.filter(d => d.done).map(d => d.date))
    const w1 = buildWeek({ profile: prof, activities: app.activities, weekStart: ws, rain, firstWeek: cyc.firstWeek, notBefore: app.today, checkins: app.checkins })
    const w2 = buildWeek({ profile: prof, activities: app.activities, weekStart: addDays(ws, 7), rain, notBefore: addDays(ws, 7), checkins: app.checkins })
    // (v3.51) treningi, ki si jih dodal sam, ostanejo (prej jih je nov cilj pobrisal)
    await savePlanDays(keepOwn([...w1, ...w2].filter(d => !doneDates.has(d.date)), p, prof))
    if (!p.event?.date) await updateSettings({ guideSeen: false })   // prvi cilj: vodnik »Kako deluje« se pokaže na Danes
    toast(cyc.endedOff ? `Cilj potrjen: ${next.event!.name}. Off-season je končan — osnova začne ta teden z lahkimi tedni.` : `Cilj potrjen: ${next.event!.name}. Načrt za ta in naslednji teden je sestavljen.`, 'ok', 6000)
    onClose()
  }

  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => { setF({ ...f, [k]: e.target.value }); if (missing && missing.k === k) setMissing(null) }
  const bad = (k: keyof typeof errs) => (errs[k] || missing?.k === k ? { 'aria-invalid': true, 'aria-describedby': 'gs-err', style: { borderColor: 'var(--warn)' } } : {})
  const shownErr = [missing?.t, fieldErr].filter(Boolean).join(' ')
  return (
    <Sheet open={open} onClose={onClose}>
      <b style={{ fontSize: rem(17), letterSpacing: '-.02em' }}>Cilj sezone</b>
      <p style={{ fontSize: rem(12.5), marginTop: 4 }}>{minor ? 'Vpiši, kar veš. Največji možni FTP izračunam sam — načrt in AI trener se ravnata po tem.' : 'Vpiši, kar veš. Najboljšo težo in največji možni FTP izračunam sam — načrt, prehrana in AI trener se ravnajo po tem.'}</p>
      {offNow && (
        <div className="card tight" style={{ marginTop: 12, background: 'var(--raised)' }}>
          <b style={{ fontSize: rem(13) }}>Zdaj je off-season · teden {offNow.week} od {offNow.of}</b>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap', marginTop: 8 }}>
            <Chip sm on={endOff} onClick={() => setEndOff(true)}>Končaj off-season · začni z osnovo</Chip>
            <Chip sm on={!endOff} onClick={() => setEndOff(false)}>Ostani še {offNow.left} {offNow.left === 1 ? 'teden' : offNow.left === 2 ? 'tedna' : offNow.left <= 4 ? 'tedne' : 'tednov'}</Chip>
          </div>
          <div className="muted" style={{ fontSize: rem(11.5), marginTop: 6 }}>{endOff ? 'Načrt se spremeni že ta teden: lahki tedni osnove, nato test FTP in gradnja do cilja.' : `Do konca off-seasona ${OFF_MIX[offMixOf(app.profile)].active} (izbereš sam), potem osnova do cilja.`}</div>
        </div>
      )}
      <div className="stack" style={{ gap: 10, marginTop: 12 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          {/* (v3.51) ime brez »franj«: km in vzpon Franje (156 / 97 km) se pobrišeta — vpišeš ju za novo dirko */}
          <div className="field"><label htmlFor="gs-name">Dirka</label><input id="gs-name" value={f.name} onChange={e => { const v = e.target.value; const leave = /franj/i.test(f.name) && !/franj/i.test(v); setF({ ...f, name: v, ...(leave && (f.km === '156' || f.km === '97') ? { km: '', elev: '' } : {}) }); if (missing?.k === 'name') setMissing(null) }} placeholder="npr. Maraton Franja" {...(missing?.k === 'name' ? { 'aria-invalid': true, 'aria-describedby': 'gs-err', style: { borderColor: 'var(--warn)' } } : {})} /></div>
          <div className="field"><label htmlFor="gs-date">Datum</label><DateField id="gs-date" compact min={app.today} value={f.date} onChange={v => { setF({ ...f, date: v }); if (missing?.k === 'date') setMissing(null) }} label="Datum dirke" /></div>
        </div>
        {FRANJA_2027.date > app.today && f.name !== FRANJA_2027.name && (
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>
            <Chip sm onClick={() => setF({ ...f, name: FRANJA_2027.name, date: FRANJA_2027.date, km: String(FRANJA_2027.distanceKm) })}>{FRANJA_2027.name} · {fmtDateSl(FRANJA_2027.date, false)}</Chip>
          </div>
        )}
        {/franj/i.test(f.name) && <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>{[['156', 'Velika · 156 km'], ['97', 'Mala · 97 km']].map(([v, l]) => <Chip key={v} sm on={f.km === v} onClick={() => setF({ ...f, km: v! })}>{l}</Chip>)}</div>}
        {/* (v3.51) dolžina in vzpon za vsako dirko (prej samo čip pri Franji) */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, alignItems: 'end' }}>
          <div className="field"><label htmlFor="gs-km">Dolžina <span className="unit">km</span></label><DecimalInput id="gs-km" step={1} value={f.km} onChange={set('km')} placeholder="npr. 120" /></div>
          <div className="field"><label htmlFor="gs-elev">Vzpon <span className="unit">m, če veš</span></label><input id="gs-elev" type="number" inputMode="numeric" min={0} max={10000} value={f.elev} onChange={set('elev')} /></div>
        </div>
        <div className="muted" style={{ fontSize: rem(11.5), marginTop: -4 }}>Iz dolžine izračunam trajanje dirke in dolge vožnje.</div>
        {/* (v3.51) polja poravnana spodaj: dvovrstična oznaka »Maščoba %, če veš« pri 360 px ne zamakne polja */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, alignItems: 'end' }}>
          <div className="field"><label htmlFor="gs-ftp">FTP <span className="unit">W, če veš</span></label><input id="gs-ftp" type="number" inputMode="numeric" value={f.ftp} onChange={set('ftp')} placeholder="ne vem" {...bad('ftp')} /></div>
          <div className="field"><label htmlFor="gs-w">Teža <span className="unit">kg</span></label><DecimalInput id="gs-w" step={0.1} value={f.weight} onChange={set('weight')} {...bad('weight')} /></div>
          <div className="field"><label htmlFor="gs-bf">Maščoba <span className="unit">%, če veš</span></label><DecimalInput id="gs-bf" step={0.5} value={f.bf} onChange={set('bf')} placeholder="ocena" {...bad('bf')} /></div>
        </div>
        {shownErr && <div id="gs-err" role="alert" style={{ fontSize: rem(12), color: 'var(--warn)', marginTop: -4, lineHeight: 1.45 }}>{shownErr}</div>}
        {!f.ftp.trim() && !p.ftp && <div className="muted" style={{ fontSize: rem(11.5), marginTop: -4 }}>FTP ne veš? Pusti prazno — v načrtu je 20-minutni test, iz njega dobiš svoje cone. Do takrat voziš po utripu in občutku.</div>}

        {/* (v3.50) skupine čipov z imenom za bralnik (kot v Nastavitvah) */}
        <div className="field"><label id="gs-lbl-seasons">Koliko sezon že resno treniraš</label>
          <div className="row" role="group" aria-labelledby="gs-lbl-seasons" style={{ gap: 6, flexWrap: 'wrap' }}>{[['1', 'prva'], ['2', 'druga'], ['3', '3.–4.'], ['6', '5.–7.'], ['9', '8 ali več']].map(([v, l]) => <Chip key={v} sm on={f.seasons === v} onClick={() => setF({ ...f, seasons: f.seasons === v ? '' : v! })}>{l}</Chip>)}</div>
          <div className="muted" style={{ fontSize: rem(11.5), marginTop: 6 }}>Po več letih treninga je prostora za napredek manj (profesionalec po desetih sezonah skoraj ne napreduje), v prvih sezonah veliko več. Do 20. leta telo še zori.</div>
        </div>

        <div className="card tight" style={{ background: 'var(--raised)' }}>
          {/* (v3.50) do 18. leta ni najboljše teže ne cilja maščobe (prej 16-letnik: »70 kg, ~20 % → ~10 %«) */}
          {minor && <div className="muted" style={{ fontSize: rem(11.5) }}>Do 18. leta ciljne teže in maščobe ne računam — cilj so vati in redni trening.</div>}
          {!minor && <div className="between" style={{ fontSize: rem(13) }}><span className="muted" style={{ fontWeight: 700 }}>Najboljša teža zate</span><b style={{ color: 'var(--accent-fg)' }}>{rw ? `${f1(rw.kg)} kg` : '—'}</b></div>}
          {!minor && rw && <div className="muted" style={{ fontSize: rem(11.5), marginTop: 2 }}>{rw.measured ? 'Maščoba' : 'Ocena maščobe iz ITM'} ~{Math.round(rw.bf)} % → cilj ~{rw.targetBf} % (trenirani kolesarji 8–11 %); pusta masa {f1(rw.lbm)} kg ostane. Razpon {f1(rw.lo)}–{f1(rw.hi)} kg{rw.limitedByTime ? ' — omejeno s časom do dirke' : ''}.{kgWeek != null && kgWeek > 0 ? ` Tempo ~${f2(kgWeek)} kg na teden.` : ''}</div>}
          <div className="between" style={{ fontSize: rem(13), marginTop: minor ? 6 : 8 }}><span className="muted" style={{ fontWeight: 700 }}>FTP na dan dirke</span><b>{pot ? <>realno {pot.realistic} W · <span style={{ color: 'var(--accent-fg)' }}>največ {pot.ideal} W</span></> : '—'}</b></div>
          {pot && <div className="muted" style={{ fontSize: rem(11.5), marginTop: 2 }}>+{pot.gainPct} % v {pot.weeks} {plural(pot.weeks, V_TEDNIH)} pri povprečno {f1(pot.hours)} h na teden{draft.baseHours != null ? ' (načrt raste od tvojih dejanskih ur)' : ''}{seasons ? `, ${seasons <= 1 ? 'prva sezona treninga' : seasons <= 2 ? 'druga sezona' : seasons <= 4 ? '3.–4. sezona' : seasons <= 7 ? '5.–7. sezona' : '8 ali več sezon'}` : ''}. Od 4 W/kg naprej in po več sezonah gre počasneje; genetskega stropa ne pozna nihče — pokažejo ga testi.</div>}
          <div className="between" style={{ fontSize: rem(13), marginTop: 8 }}><span className="muted" style={{ fontWeight: 700 }}>W/kg</span><b>{now ? f2(now) : '—'} → <span style={{ color: 'var(--accent-fg)' }}>{goal ? f2(goal) : '—'}</span>{real ? <span className="muted" style={{ fontWeight: 600 }}> (realno {f2(real)})</span> : null}</b></div>
          {now && goal && <div className="muted" style={{ fontSize: rem(11.5), marginTop: 2 }}>{levelOf(now)?.name.toLowerCase()} → {levelOf(goal)?.name.toLowerCase()}</div>}
        </div>

        <div className="field"><label id="gs-lbl-hours">Koliko ur na teden</label>
          <div className="row" role="group" aria-labelledby="gs-lbl-hours" style={{ gap: 7, flexWrap: 'wrap' }}>
            <Chip sm on={f.mode === 'max'} onClick={() => setF({ ...f, mode: 'max' })}>Največji napredek · {fh(adv.max)} h</Chip>
            <Chip sm on={f.mode === 'own'} onClick={() => setF({ ...f, mode: 'own' })}>Po mojem času</Chip>
          </div>
          {potMax && potOwn && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginTop: 8 }}>
              <div className="card tight" style={{ background: 'var(--raised)', borderColor: f.mode === 'max' ? 'var(--accent)' : undefined }}><div className="muted" style={{ fontSize: rem(11), fontWeight: 700 }}>NAJVEČJI NAPREDEK</div><b style={{ fontSize: rem(14) }}>{fh(adv.max)} h → ~{potMax.realistic} W</b><div className="muted" style={{ fontSize: rem(11) }}>največ {potMax.ideal} W · ure določam sam in jih dvignem, ko zmoreš več</div></div>
              <div className="card tight" style={{ background: 'var(--raised)', borderColor: f.mode === 'own' ? 'var(--accent)' : undefined }}><div className="muted" style={{ fontSize: rem(11), fontWeight: 700 }}>PO TVOJEM ČASU</div><b style={{ fontSize: rem(14) }}>{fh(ownH)} h → ~{potOwn.realistic} W</b><div className="muted" style={{ fontSize: rem(11) }}>največ {potOwn.ideal} W · ure ostanejo, kot jih izbereš</div></div>
            </div>
          )}
          {/* (v3.48) več, kot zgradiš do dirke: en stavek (prej »največ 10 h« in »vsaj ~14,5 h« drug ob drugem) */}
          {needH && longest && (needH <= adv.max
            ? <div style={{ fontSize: rem(12), marginTop: 8, color: 'var(--ink-2)' }}>Najdaljša tekma sezone: <b>{longest.g.name}</b> (~{fh(longest.min / 60)} h) — za dobro pripravo vsaj ~{fh(needH)} h na teden v gradnji in dolge vožnje do ~{fh(Math.min(6.5, longest.min * 0.85 / 60))} h.{T < needH ? ` Izbranih ${fh(T)} h je manj — dirko boš prevozil, a zadnja ura bo težka.` : ''}</div>
            : <div style={{ fontSize: rem(12), marginTop: 8, color: 'var(--ink-2)' }}><b>{longest.g.name}</b> traja ~{fh(longest.min / 60)} h; do tekme varno zgradiš ~{fh(adv.max)} h na teden — dolge vožnje do ~{fh(Math.min(6.5, longest.min * 0.85 / 60))} h te bodo pripravile.</div>)}
          {f.mode === 'max' ? (
            <div className="muted" style={{ fontSize: rem(11.5), marginTop: 6 }}>
              {adv.basis === 'history'
                ? `Iz tvojih voženj: najdaljši teden v zadnjem letu ${fh(adv.peak!)} h, povprečje leta ${fh(adv.yearAvg!)} h, zadnjih 8 tednov ${fh(adv.recent ?? 0)} h. Največ, kar varno zgradiš: ~1,3 × najdaljši teden`
                : adv.basis === 'stated' ? `Voženj še ne vidim (poveži uro v Nastavitve → Ura in uvoz), zato iz tvojih vpisanih ${fh(p.hoursPerWeek!)} h × 1,3`
                : 'Brez voženj in vpisanih ur začnem z 10 h'}
              {adv.limitedBy === 'cap' ? `, omejeno na ${fh(adv.cap)} h (več, ko ga že voziš)` : adv.limitedBy === 'youth' ? ', do 18. leta največ 12 h' : adv.limitedBy === 'time' ? ' — do dirke več ne zraste (+10 % na teden)' : ''}.
              {` Tretji teden bloka ~${fh(T * 1.12)} h, vsak 4. teden ~${fh(T * 0.52)} h. Nad ~14 h je napredek na uro manjši.`}
            </div>
          ) : (<>
            <div className="row" style={{ gap: 7, flexWrap: 'wrap', marginTop: 8, alignItems: 'center' }}>
              {[6, 8, 10, 12, 14, 16, 18, 20, 25, 30].map(v => <Chip key={v} sm on={num(f.hours) === v} onClick={() => setF({ ...f, hours: String(v) })}>{v} h</Chip>)}
              <DecimalInput min={3} max={30} step={0.5} value={f.hours} onChange={set('hours')} aria-label="ur na teden" style={{ width: 74, padding: '6px 10px', ...(errs.hours ? { borderColor: 'var(--warn)' } : {}) }} aria-invalid={errs.hours ? true : undefined} />
            </div>
            {errs.hours && <div role="alert" style={{ fontSize: rem(12), color: 'var(--warn)', marginTop: 6 }}>{errs.hours}</div>}
            <div className="muted" style={{ fontSize: rem(11.5), marginTop: 6 }}>Toliko časa imaš v normalnem tednu (3–30 h). {T > 20 ? 'Za primerjavo: profesionalci WorldTour v pripravljalnem obdobju povprečno ~19 h na teden, najtežji teden ~22,5 h; 25–30 h le na pripravah. ' : ''}{T > adv.max + 0.25 ? `To je več od ${fh(adv.max)} h, kolikor kaže tvoja zgodovina — raste postopoma, pazi na spanec in utrujenost. ` : ''}Vsak 4. teden ~50 %.</div>
          </>)}
        </div>
        {/* (v3.48) do 4 h ni česa izbrati (začetek je vsaj 4 h): brez prazne vrstice, predlog nikoli nad izbranimi urami */}
        {T > 4 ? (
        <div className="field"><label id="gs-lbl-start">Načrt začne pri</label>
          <div className="row" role="group" aria-labelledby="gs-lbl-start" style={{ gap: 7, flexWrap: 'wrap' }}>{[4, 5, 6, 7, 8, 10, 12, 14, 16, 20].filter(v => v <= T).map(v => <Chip key={v} sm on={startH === v} onClick={() => setF({ ...f, start: String(v) })}>{v} h</Chip>)}</div>
          <div className="muted" style={{ fontSize: rem(11.5), marginTop: 6 }}>{adv.recent != null ? `Zadnjih 8 tednov voziš ~${fh(adv.recent)} h na teden (predlog ${fh(Math.min(autoStart, T))} h). ` : `Predlog ${fh(Math.min(autoStart, T))} h. `}{reachWeeks > 0 ? `Raste +10 % na teden; ${fh(T)} h dosežeš v ~${reachWeeks} ${plural(reachWeeks, V_TEDNIH)}.` : `Brez postopne rasti — ${fh(T)} h že ta teden.`} Če začneš precej nad tem, kar res voziš, tvegaš bolezen ali poškodbo.</div>
        </div>
        ) : (
          <div className="muted" style={{ fontSize: rem(11.5) }}>{fh(T)} h že ta teden{adv.recent != null && adv.recent > T + 0.25 ? ' — manj, kot zdaj voziš' : ''}.</div>
        )}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          {/* (v3.50) iste možnosti kot v uvodu in Nastavitvah: »čez dan« in »različno« (= brez nastavitve) */}
          <div className="field"><label id="gs-lbl-time">Kdaj treniraš</label>
            <div className="row" role="group" aria-labelledby="gs-lbl-time" style={{ gap: 6, flexWrap: 'wrap' }}>{([['zjutraj', 'zjutraj'], ['popoldne', 'čez dan'], ['zvecer', 'zvečer'], [null, 'različno']] as const).map(([v, l]) => <Chip key={l} sm on={(f.time ?? null) === v} onClick={() => setF({ ...f, time: v })}>{l}</Chip>)}</div>
          </div>
          <div className="field"><label id="gs-lbl-str">Moč</label>
            <div className="row" role="group" aria-labelledby="gs-lbl-str" style={{ gap: 6, flexWrap: 'wrap' }}>{[['0', 'brez'], ['1', '1×'], ['2', '2×']].map(([v, l]) => <Chip key={v} sm on={f.str === v} onClick={() => setF({ ...f, str: v! })}>{l}</Chip>)}</div>
          </div>
        </div>
      </div>
      <Btn primary block style={{ marginTop: 14 }} disabled={!!errText} onClick={save}>{offNow && endOff ? 'Potrdi, končaj off-season in sestavi načrt' : 'Potrdi in sestavi načrt'}</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Prekliči</Btn>
      <HealthNote>{minor ? 'Načrt je trenerska usmeritev, ne zdravniški nasvet. Do 18. leta brez hujšanja. Ob bolečini, bolezni ali zdravstvenih težavah se posvetuj z zdravnikom.' : 'Načrt je trenerska usmeritev, ne zdravniški nasvet. Teža nikoli pod ITM 20,5, hujšanje največ ~0,5 kg na teden. Ob bolečini, bolezni ali zdravstvenih težavah se posvetuj z zdravnikom.'}</HealthNote>
    </Sheet>
  )
}
