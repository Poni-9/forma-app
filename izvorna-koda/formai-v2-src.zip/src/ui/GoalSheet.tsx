import { useState } from 'react'
import { useApp, updateProfile, saveCheckin, savePlanDays, updateSettings, toast } from '@/state/store'
import { buildWeek, FRANJA_2027, targetHours } from '@/domain/training/planner'
import { ftpPotential, levelOf, raceWeightOf } from '@/domain/training/goal'
import { weightTrend } from '@/domain/nutrition/energy'
import { addDays, todayIso, weekStartIso } from '@/domain/training/load'
import type { Profile } from '@/domain/types'
import { Btn, Chip, Sheet } from '@/ui/primitives'

const num = (v: string) => (v.trim() === '' ? null : +v.replace(',', '.'))
const f1 = (x: number) => x.toFixed(1).replace('.', ',')
const f2 = (x: number) => x.toFixed(2).replace('.', ',')

/**
 * Cilj sezone v enem koraku. Vpišeš samo, kar veš (dirka, FTP zdaj, teža zdaj, ure) —
 * najboljšo težo in največji možni FTP izračuna aplikacija sama. Potrditev začne makrocikel in sestavi dva tedna.
 */
export function GoalSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const app = useApp()
  const p = app.profile
  const tr = weightTrend(app.checkins)
  const ev = p.event?.date ? p.event : FRANJA_2027
  const w0 = tr?.avg7 ?? p.weightKg ?? null
  const [f, setF] = useState({
    name: ev.name, date: ev.date, km: String(ev.distanceKm ?? 156),
    ftp: p.ftp ? String(p.ftp) : '', weight: w0 ? String(w0) : '', bf: p.bodyFatPct ? String(p.bodyFatPct) : '',
    hours: String(p.hoursPerWeek && p.hoursPerWeek >= 12 ? Math.min(14, p.hoursPerWeek) : 12), str: String(p.strength.on ? Math.min(2, p.strengthDays ?? 2) : 0),
    time: p.trainTime || 'popoldne',
  })
  const ftp = num(f.ftp), weight = num(f.weight), bf = num(f.bf)
  // predogled z vpisanimi številkami, kot bi bile ob potrditvi
  const draft: Profile = { ...p, event: { name: f.name, date: f.date, distanceKm: num(f.km) }, ftp: ftp ?? p.ftp, weightKg: weight ?? p.weightKg, bodyFatPct: bf, hoursPerWeek: num(f.hours), targetFtp: null, targetWeightKg: null, goalStart: { date: app.today, ftp: ftp ?? p.ftp ?? null, weightKg: weight ?? p.weightKg ?? null } }
  const rw = raceWeightOf(draft, app.today)
  const pot = ftpPotential(draft, app.today)
  const now = ftp && weight ? ftp / weight : null
  const goal = pot && rw ? pot.ideal / rw.kg : null
  const real = pot && rw ? pot.realistic / rw.kg : null
  const weeks = f.date ? Math.max(0, Math.round((new Date(f.date).getTime() - new Date(app.today).getTime()) / (7 * 86400_000))) : null
  const kgWeek = weight && rw && weeks ? (weight - rw.kg) / Math.max(1, weeks * 0.68) : null

  async function save() {
    if (!f.name.trim() || !f.date) { toast('Vpiši dirko in datum.', 'err'); return }
    if (f.date <= app.today) { toast('Datum dirke mora biti v prihodnosti.', 'err'); return }
    if (!ftp || !weight) { toast('Vpiši FTP in težo — iz njiju izračunam vse ostalo.', 'err'); return }
    const ws = weekStartIso(app.today)
    const next: Partial<Profile> = {
      event: { name: f.name.trim().slice(0, 60), date: f.date, distanceKm: num(f.km) },
      ftp, ftpDate: ftp !== p.ftp ? todayIso() : p.ftpDate ?? null, weightKg: weight, bodyFatPct: bf,
      targetFtp: null, targetWeightKg: null,   // samodejno: najboljša teža in največji možni FTP
      hoursPerWeek: num(f.hours) ?? targetHours(p), strengthDays: +f.str, strength: { ...p.strength, on: +f.str > 0 },
      trainTime: f.time as Profile['trainTime'], goal: 'dirka', cycleStart: ws, goalStart: { date: app.today, ftp, weightKg: weight },
    }
    const prof = await updateProfile(next)
    if (weight !== w0) { const prev = app.checkins.find(c => c.date === app.today); await saveCheckin({ ...(prev || { date: app.today }), date: app.today, weightKg: weight }) }
    const rain: Record<string, number> = {}
    if (app.weather) for (const k in app.weather) rain[k] = app.weather[k]!.rain
    const doneDates = new Set(app.plan.filter(d => d.done).map(d => d.date))
    const w1 = buildWeek({ profile: prof, activities: app.activities, weekStart: ws, rain, firstWeek: true, notBefore: app.today })
    const w2 = buildWeek({ profile: prof, activities: app.activities, weekStart: addDays(ws, 7), rain, notBefore: addDays(ws, 7) })
    await savePlanDays([...w1, ...w2].filter(d => !doneDates.has(d.date)))
    if (!p.event?.date) await updateSettings({ guideSeen: false })   // prvi cilj: vodnik »Kako deluje« se pokaže na Danes
    toast(`Cilj potrjen: ${next.event!.name}. Načrt za ta in naslednji teden je sestavljen.`, 'ok', 6000)
    onClose()
  }

  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value })
  return (
    <Sheet open={open} onClose={onClose}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Cilj sezone</b>
      <p style={{ fontSize: 12.5, marginTop: 4 }}>Vpiši, kar veš. Najboljšo težo in največji možni FTP izračunam sam — načrt, prehrana in AI trener se ravnajo po tem.</p>
      <div className="stack" style={{ gap: 10, marginTop: 12 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div className="field"><label>Dirka</label><input value={f.name} onChange={set('name')} /></div>
          <div className="field"><label>Datum</label><input type="date" value={f.date} onChange={set('date')} /></div>
        </div>
        <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>{[['156', 'Velika · 156 km'], ['97', 'Mala · 97 km']].map(([v, l]) => <Chip key={v} sm on={f.km === v} onClick={() => setF({ ...f, km: v! })}>{l}</Chip>)}</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
          <div className="field"><label>FTP zdaj <span className="unit">W</span></label><input type="number" inputMode="numeric" value={f.ftp} onChange={set('ftp')} /></div>
          <div className="field"><label>Teža <span className="unit">kg</span></label><input type="number" inputMode="decimal" step={0.1} value={f.weight} onChange={set('weight')} /></div>
          <div className="field"><label>Maščoba <span className="unit">%, če veš</span></label><input type="number" inputMode="decimal" step={0.5} value={f.bf} onChange={set('bf')} placeholder="ocena" /></div>
        </div>

        <div className="card tight" style={{ background: 'var(--raised)' }}>
          <div className="between" style={{ fontSize: 13 }}><span className="muted" style={{ fontWeight: 700 }}>Najboljša teža zate</span><b style={{ color: 'var(--accent)' }}>{rw ? `${f1(rw.kg)} kg` : '—'}</b></div>
          {rw && <div className="muted" style={{ fontSize: 11.5, marginTop: 2 }}>{rw.measured ? 'Maščoba' : 'Ocena maščobe iz BMI'} ~{Math.round(rw.bf)} % → cilj ~{rw.targetBf} % (trenirani kolesarji 8–11 %); pusta masa {f1(rw.lbm)} kg ostane. Razpon {f1(rw.lo)}–{f1(rw.hi)} kg{rw.limitedByTime ? ' — omejeno s časom do dirke' : ''}.{kgWeek != null && kgWeek > 0 ? ` Tempo ~${f2(kgWeek)} kg na teden.` : ''}</div>}
          <div className="between" style={{ fontSize: 13, marginTop: 8 }}><span className="muted" style={{ fontWeight: 700 }}>FTP na dan dirke</span><b>{pot ? <>realno {pot.realistic} W · <span style={{ color: 'var(--accent)' }}>največ {pot.ideal} W</span></> : '—'}</b></div>
          {pot && <div className="muted" style={{ fontSize: 11.5, marginTop: 2 }}>+{pot.gainPct} % v {pot.weeks} tednih pri {pot.hours} h na teden. Več ur ali več časa = več; od 4 W/kg naprej gre počasneje.</div>}
          <div className="between" style={{ fontSize: 13, marginTop: 8 }}><span className="muted" style={{ fontWeight: 700 }}>W/kg</span><b>{now ? f2(now) : '—'} → <span style={{ color: 'var(--accent)' }}>{goal ? f2(goal) : '—'}</span>{real ? <span className="muted" style={{ fontWeight: 600 }}> (realno {f2(real)})</span> : null}</b></div>
          {now && goal && <div className="muted" style={{ fontSize: 11.5, marginTop: 2 }}>{levelOf(now)?.name.toLowerCase()} → {levelOf(goal)?.name.toLowerCase()}</div>}
        </div>

        <div className="field"><label>Ure na kolesu v normalnem tednu</label>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>{['8', '10', '11', '12', '13', '14'].map(v => <Chip key={v} sm on={f.hours === v} onClick={() => setF({ ...f, hours: v })}>{v} h</Chip>)}</div>
          <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>Za največji napredek 12–14 h. Začne se nižje (~75 %) in raste; vsak 4. teden razbremenitev.</div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div className="field"><label>Kdaj treniraš</label>
            <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>{[['zjutraj', 'zjutraj'], ['popoldne', 'popoldne'], ['zvecer', 'zvečer']].map(([v, l]) => <Chip key={v} sm on={f.time === v} onClick={() => setF({ ...f, time: v! as typeof f.time })}>{l}</Chip>)}</div>
          </div>
          <div className="field"><label>Moč</label>
            <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>{[['0', 'brez'], ['1', '1×'], ['2', '2×']].map(([v, l]) => <Chip key={v} sm on={f.str === v} onClick={() => setF({ ...f, str: v! })}>{l}</Chip>)}</div>
          </div>
        </div>
      </div>
      <Btn primary block style={{ marginTop: 14 }} onClick={save}>Potrdi in sestavi načrt</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Prekliči</Btn>
      <p className="muted" style={{ fontSize: 11, marginTop: 10 }}>⚕️ Načrt je trenerska usmeritev, ne zdravniški nasvet. Teža nikoli pod BMI 20,5, hujšanje največ ~0,5 kg na teden. Ob bolečini, bolezni ali zdravstvenih težavah se posvetuj z zdravnikom.</p>
    </Sheet>
  )
}
