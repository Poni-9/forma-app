import { getState, saveCheckin, toast } from '@/state/store'
import type { PlanDay } from '@/domain/types'
import { Sheet } from '@/ui/primitives'

export type SkipReason = 'noge' | 'tla' | 'cas' | 'bolan'

/**
 * »Danes ne gre« — razlog odloči, kaj se zgodi (načrt posluša):
 * noge bolijo → jutranji vnos »Boli« (danes sprehod po želji, ključni kasneje), na tleh → »Na tleh« (počitek, jutri lažje),
 * ni časa ali vreme → premik na drug dan, bolan → Bolan sem. Brez AI; vse se da vrniti (Vrni po načrtu, Razveljavi).
 */
export function SkipSheet({ day, onClose, onMove, onSick, canMove }: { day: PlanDay; onClose: () => void; onMove: () => void; onSick: () => void; canMove: boolean }) {
  async function pick(r: SkipReason) {
    if (r === 'cas') { onClose(); onMove(); return }
    if (r === 'bolan') { onClose(); onSick(); return }
    const s = getState()
    const base = s.checkinToday && s.checkinToday.date === s.today ? s.checkinToday : { date: s.today }
    // jutranji vnos je vir resnice: prilagoditev naredi followState (po saveCheckin), kot da bi tapnil sam
    await saveCheckin({ ...base, date: s.today, ...(r === 'noge' ? { soreness: 5 } : { mood: 1 }) })
    onClose()
    toast(r === 'noge' ? 'Noge počivajo — načrt je prilagojen (spodaj).' : 'Danes počitek — načrt je prilagojen (spodaj).', 'ok')
  }
  const opt = (r: SkipReason, title: string, text: string, disabled = false) => (
    <button type="button" className="skip-opt" disabled={disabled} onClick={() => void pick(r)}>
      <b>{title}</b><small>{text}</small>
    </button>
  )
  return (
    <Sheet open onClose={onClose} label="Danes ne gre">
      <b style={{ display: 'block', fontSize: 17, letterSpacing: '-.02em' }}>Danes ne gre — zakaj?</b>
      <p style={{ fontSize: 13, marginTop: 4 }}>{day.title}. Glede na razlog prilagodim danes in naprej.</p>
      <div className="stack" style={{ gap: 8, marginTop: 14 }}>
        {opt('noge', 'Noge bolijo', 'Danes brez kolesa (sprehod po želji), ključni trening kasneje v tednu.')}
        {opt('tla', 'Na tleh sem', 'Danes počitek, jutri lažje.')}
        {opt('cas', 'Ni časa ali vreme', canMove ? 'Premakni na drug dan — kar je tam, pride sem.' : 'Tega dne ni mogoče premakniti (tekma ali dan pred njo).', !canMove)}
        {opt('bolan', 'Bolan sem', 'Počitek do zdravja, brez deficita kalorij; potem postopno nazaj.')}
      </div>
    </Sheet>
  )
}
