import { useMemo, useState } from 'react'
import { getState, saveCheckin, savePlanDay, toast } from '@/state/store'
import type { PlanDay } from '@/domain/types'
import { shortChoices, shortenDay } from '@/domain/training/danes'
import { hasDrills } from '@/domain/training/workout'
import { fmtDur } from '@/domain/training/load'
import { undoToast } from '@/ui/Confirm'
import { isRace } from '@/ui/SessBits'
import { Chip, Sheet } from '@/ui/primitives'
import { g } from '@/ui/gender'
import { rem } from '@/ui/rem'

export type SkipReason = 'noge' | 'tla' | 'cas' | 'bolan' | 'teden'

/**
 * »Danes ne gre« — razlog odloči, kaj se zgodi (načrt posluša):
 * noge bolijo → jutranji vnos »Boli« (danes sprehod po želji, ključni kasneje), na tleh → »Na tleh« (počitek, jutri lažje),
 * imam samo X min → krajše, jedro ostane (v3.49), ni časa ali vreme → premik na drug dan, bolan → Bolan sem.
 * Brez AI; vse se da vrniti (Vrni po načrtu, Razveljavi).
 * (v3.50) Dan tekme: tekme načrt ne spreminja — »Noge bolijo« in »Na tleh sem« tu ne obljubljata prilagoditve.
 * (v3.50) »Imam samo …« ponudi le minute, ki jih trening res doseže (prej 20, 30 in 45 → vsi 50 min).
 * (v3.50) »Ta teden …« (onWeek): ves teden brez treningov ali brez kolesa — ne samo danes.
 */
export function SkipSheet({ day, onClose, onMove, onSick, canMove, onWeek }: { day: PlanDay; onClose: () => void; onMove: () => void; onSick: () => void; canMove: boolean; onWeek?: () => void }) {
  const [short, setShort] = useState(false)
  const race = isRace(day)
  const choices = useMemo(() => shortChoices(day, getState().profile), [day])
  const mins = choices.mins
  const structured = hasDrills(day.desc) || hasDrills(day.title) || day.role === 'kljucna'
  async function pick(r: SkipReason) {
    if (r === 'cas') { onClose(); onMove(); return }
    if (r === 'bolan') { onClose(); onSick(); return }
    if (r === 'teden') { onClose(); onWeek?.(); return }
    const s = getState()
    const base = s.checkinToday && s.checkinToday.date === s.today ? s.checkinToday : { date: s.today }
    // jutranji vnos je vir resnice: prilagoditev naredi followState (po saveCheckin), kot da bi tapnil sam
    await saveCheckin({ ...base, date: s.today, ...(r === 'noge' ? { soreness: 5 } : { mood: 1 }) })
    onClose()
    toast(r === 'noge' ? 'Noge počivajo — načrt je prilagojen (spodaj).' : 'Danes počitek — načrt je prilagojen (spodaj).', 'ok')
  }
  /** (v3.49) »Imam samo X min«: krajši trening, ponovitve oz. glavne vaje ostanejo */
  async function shorten(m: number) {
    const r = shortenDay(day, getState().profile, m)
    if (!r) { toast('Krajše ne gre — ta trening rabi ves čas. Premakni ga na drug dan.', 'info'); return }
    // »Razveljavi« vrne samo ta zapis (restorePlanDays bi sestavil cel dan in pobrisal moč istega dne)
    const prev = getState().plan.find(d => d.id === day.id) ?? day
    await savePlanDay(r.day)
    onClose()
    const kept = day.kind === 'moc' ? ', glavne vaje ostanejo' : structured ? ', ponovitve ostanejo' : ''
    undoToast(r.min > m ? `Danes ${fmtDur(r.min)} — krajše ne gre, da ostanejo ${day.kind === 'moc' ? 'glavne vaje' : 'ponovitve'}.` : `Danes ${fmtDur(r.min)}${kept}.`, () => savePlanDay(prev), { ms: 7000 })
  }
  const opt = (r: SkipReason, title: string, text: string, disabled = false) => (
    <button type="button" className="skip-opt" disabled={disabled} onClick={() => void pick(r)}>
      <b>{title}</b><small>{text}</small>
    </button>
  )
  const keep = day.kind === 'moc' ? 'Glavne vaje ostanejo, manj serij.' : structured ? 'Ponovitve ostanejo, krajša sta ogrevanje in lahek del.' : 'Isti trening, krajše.'
  return (
    <Sheet open onClose={onClose} label="Danes ne gre">
      <b style={{ display: 'block', fontSize: rem(17), letterSpacing: '-.02em' }}>Danes ne gre — zakaj?</b>
      <p style={{ fontSize: rem(13), marginTop: 4 }}>{day.title}. {race ? 'Tekma je tvoja odločitev — načrt je ne spreminja.' : 'Glede na razlog prilagodim danes in naprej.'}</p>
      <div className="stack" style={{ gap: 8, marginTop: 14 }}>
        {race ? (
          <p className="muted race-note" style={{ fontSize: rem(12.5), margin: 0 }}>Če te bolijo noge ali si na tleh, začni mirneje in poslušaj telo. Če ne štartaš, tekmo pusti neoznačeno — načrt gre naprej po svoje.</p>
        ) : (<>
          {opt('noge', 'Noge bolijo', 'Danes brez kolesa (sprehod po želji), ključni trening kasneje v tednu.')}
          {opt('tla', 'Na tleh sem', 'Danes počitek, jutri lažje.')}
        </>)}
        {mins.length > 0 && (
          <div>
            <button type="button" className="skip-opt" aria-expanded={short} onClick={() => setShort(!short)}>
              <b>Imam samo …</b><small>{keep}</small>
            </button>
            {short && (<>
              <div className="skip-mins" role="group" aria-label="Koliko časa imaš">
                {mins.map(m => <Chip key={m} sm onClick={() => void shorten(m)}>{fmtDur(m)}</Chip>)}
              </div>
              {choices.floor != null && <p className="muted" style={{ fontSize: rem(11.5), margin: '6px 0 0 4px' }}>Krajše od {fmtDur(choices.floor)} ne gre — {day.kind === 'moc' ? 'glavne vaje rabijo svoj čas' : 'ponovitve rabijo svoj čas'}.</p>}
            </>)}
          </div>
        )}
        {opt('cas', 'Ni časa ali vreme', canMove ? 'Premakni na drug dan — kar je tam, pride sem.' : 'Tega dne ni mogoče premakniti (tekma ali dan pred njo).', !canMove)}
        {onWeek && opt('teden', 'Ta teden …', 'Do nedelje brez treningov ali brez kolesa — tudi na uri.')}
        {opt('bolan', g(getState().profile, 'Bolan sem', 'Bolna sem'), 'Počitek do zdravja, brez deficita kalorij; potem postopno nazaj.')}
      </div>
    </Sheet>
  )
}
