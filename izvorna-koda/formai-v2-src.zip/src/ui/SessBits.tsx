import type { PlanDay } from '@/domain/types'
import { num } from '@/ui/format'
import { titleNoDur } from '@/domain/training/load'

/**
 * NA HITRO, KAJ DANES (Blaž, 16. 10.: »preveč vsega napisano, kdo bo ta besedila bral … čim bolj vizualno, kaj imam
 * danes«): pri vadbi se vidi samo bistvo — naslov, številke, vaje kot ploščice in en stavek; dolgo besedilo (opis,
 * zakaj, oblačila) je pod »Podrobnosti«.
 */
/** prvi stavek opisa (do ~90 znakov) — bistvo vadbe v eni vrstici */
export function gist(desc: string | null | undefined, max = 90): string {
  const t = (desc || '').replace(/\s+/g, ' ').trim()
  if (!t) return ''
  const m = t.match(/^(.+?[.!?])(?=\s+[A-ZČŠŽ0-9]|$)/u)
  const first = (m ? m[1]! : t).trim()
  if (first.length <= max) return first
  const cut = first.slice(0, max - 1)
  return `${cut.slice(0, cut.lastIndexOf(' ') > 40 ? cut.lastIndexOf(' ') : cut.length).replace(/[,;:–-]\s*$/, '')} …`
}
/** ali ima opis več kot bistvo (potem »Podrobnosti«) */
export const hasMore = (desc: string | null | undefined) => (desc || '').replace(/\s+/g, ' ').trim().length > gist(desc).replace(/ …$/, '').length + 2

/**
 * naslov brez pripetega kardia (»Fitnes — zgornji del + kolo 33 min« → »Fitnes — zgornji del«), ko je kardio v svoji
 * vrstici, in brez trajanja, ki je že v ploščici (»Kolo — daljša vožnja 2 h 30 min« → »Kolo — daljša vožnja«)
 */
export const baseTitle = (d: Pick<PlanDay, 'title' | 'tail' | 'durationMin'>) => (d.tail ? titleNoDur(d.title.replace(/\s\+\s[^+]+$/, ''), d.durationMin - d.tail.durationMin) : titleNoDur(d.title, d.durationMin))

/** vaje kot ploščice: ime in serije × ponovitve (kg) — na prvi pogled, brez branja */
export function ExGrid({ exercises }: { exercises: NonNullable<PlanDay['exercises']> }) {
  return (
    <ol className="ex-grid" aria-label="Vaje">
      {exercises.map((e, i) => (
        <li key={i} className="ex-t">
          <span className="ex-n" aria-hidden="true">{i + 1}</span>
          <span className="ex-b"><b>{e.name}</b><small>{e.sets} × {e.reps}{e.kg ? ` · ${num(e.kg)} kg` : ''}</small></span>
        </li>
      ))}
    </ol>
  )
}
