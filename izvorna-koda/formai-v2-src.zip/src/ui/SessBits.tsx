import type { PlanDay } from '@/domain/types'
import { navigate } from '@/app/router'
import { exByName } from '@/domain/training/exercises'
import { num } from '@/ui/format'
import { titleNoDur } from '@/domain/training/load'
import { structureLines, type Step } from '@/domain/training/workout'
import { KindIcon, kindColor, kindInk, kindLabelOf } from '@/ui/primitives'
import { IcoTrophy } from '@/ui/icons'

/**
 * NA HITRO, KAJ DANES (Blaž, 16. 10.: »preveč vsega napisano, kdo bo ta besedila bral … čim bolj vizualno, kaj imam
 * danes«): pri vadbi se vidi samo bistvo — naslov, številke, vaje kot ploščice in en stavek; dolgo besedilo (opis,
 * zakaj, oblačila) je pod »Podrobnosti«.
 */
/** prvi stavek opisa (do ~90 znakov) — bistvo vadbe v eni vrstici */
export function gist(desc: string | null | undefined, max = 90): string {
  const t = (desc || '').replace(/\s+/g, ' ').trim()
  if (!t) return ''
  const m = t.match(/^(.+?[.!?])(?=\s+[A-ZČŠŽ0-9]|$)/u)
  const first = (m ? m[1]! : t).trim()
  if (first.length <= max) return first
  const cut = first.slice(0, max - 1)
  return `${cut.slice(0, cut.lastIndexOf(' ') > 40 ? cut.lastIndexOf(' ') : cut.length).replace(/[,;:–-]\s*$/, '')} …`
}
/** ali ima opis več kot bistvo (potem »Podrobnosti«) */
export const hasMore = (desc: string | null | undefined) => (desc || '').replace(/\s+/g, ' ').trim().length > gist(desc).replace(/ …$/, '').length + 2

/**
 * naslov brez pripetega kardia (»Fitnes — zgornji del + kolo 33 min« → »Fitnes — zgornji del«), ko je kardio v svoji
 * vrstici, in brez trajanja, ki je že v ploščici (»Kolo — daljša vožnja 2 h 30 min« → »Kolo — daljša vožnja«)
 */
export const baseTitle = (d: Pick<PlanDay, 'title' | 'tail' | 'durationMin'>) => (d.tail ? titleNoDur(d.title.replace(/\s\+\s[^+]+$/, ''), d.durationMin - d.tail.durationMin) : titleNoDur(d.title, d.durationMin))

type ExLog = { name: string; sets: number; reps: string; kg?: number | null }
/** (v3.50) zapis vaje iz vodene vadbe (»11, 11, 11«) — ko so ponovitve naštete po serijah, je to narejeno, ne načrt
 *  (v3.51) tudi ena serija (»9«) in serija brez vpisa (»—, 9«); razpon (»8–12«) je načrt */
export const exLogOf = (done: readonly ExLog[] | null | undefined, name: string): ExLog | null => {
  const l = exFind(done, name)
  return l && /\d/.test(l.reps) && /^\s*(?:\d+|—)(?:\s*,\s*(?:\d+|—))*\s*$/.test(l.reps) ? l : null
}
const exFind = (done: readonly ExLog[] | null | undefined, name: string): ExLog | null => done?.find(x => x.name.toLowerCase() === name.toLowerCase()) ?? null
/**
 * (v3.51) Moč, končana predčasno: koliko serij načrta je v zapisu vadbe (null, ko zapis ni iz tega načrta — nobena vaja
 * se ne ujema — ali je narejeno vse). Vaje brez zapisa so »ni narejeno«.
 */
export function exPartial(plan: readonly Pick<ExLog, 'name' | 'sets'>[] | null | undefined, done: readonly ExLog[] | null | undefined): { done: number; all: number } | null {
  if (!plan?.length || !done?.length || !plan.some(e => exFind(done, e.name))) return null
  const all = plan.reduce((s, e) => s + (e.sets || 0), 0)
  const got = plan.reduce((s, e) => s + Math.min(e.sets || 0, exFind(done, e.name)?.sets ?? 0), 0)
  return got < all ? { done: got, all } : null
}
/**
 * vaje kot ploščice: ime in serije × ponovitve (kg) — na prvi pogled, brez branja
 * (v3.50) ploščica je gumb: tap odpre vajo v knjižnici (kako se izvaja); po vodeni vadbi pokaže narejeno (»11, 11, 11«),
 * načrt (3 × 8–12) ostane v drobnem tisku.
 */
export function ExGrid({ exercises, done }: { exercises: NonNullable<PlanDay['exercises']>; done?: readonly ExLog[] | null }) {
  // (v3.51) zapis iz tega načrta (vsaj ena vaja se ujema): vaja brez zapisa ni bila narejena
  const fromPlan = !!done?.length && exercises.some(e => exFind(done, e.name))
  return (
    <ol className="ex-grid" aria-label="Vaje">
      {exercises.map((e, i) => {
        const id = exByName(e.name)?.id ?? null
        const log = exLogOf(done, e.name)
        const miss = fromPlan && !exFind(done, e.name)
        const plan = `${e.sets} × ${e.reps}${e.kg ? ` · ${num(e.kg)} kg` : ''}`
        const body = (<>
          <span className="ex-n" aria-hidden="true">{i + 1}</span>
          <span className="ex-b"><b>{e.name}</b>{log ? <small><span className="ex-done">narejeno {log.reps}{log.kg ? ` · ${num(log.kg)} kg` : ''}</span> · načrt {plan}</small> : miss ? <small><span className="ex-miss">ni narejeno</span> · načrt {plan}</small> : <small>{plan}</small>}</span>
        </>)
        return id
          ? <li key={i} className="ex-t ex-go"><button type="button" className="ex-btn" onClick={() => navigate('vaje', { v: id })} aria-label={`${e.name} — kako se izvaja`}>{body}</button></li>
          : <li key={i} className="ex-t">{body}</li>
      })}
    </ol>
  )
}

/* ---- dan tekme (v3.48): pokal, barva poudarka in »Tekma« namesto »Kolo« — na Danes, kartici Jutri in v Planu ---- */
type RaceKey = Pick<PlanDay, 'kind' | 'role' | 'raceId'> & { title?: string }
export const isRace = (d: Pick<PlanDay, 'role' | 'raceId'>): boolean => d.role === 'dirka' || !!d.raceId
/** barva vrste (ikona, trak); tekma: poudarek (v svetli temi temnejši, berljiv na beli) */
export const sessColor = (d: RaceKey): string => (isRace(d) ? 'var(--accent-fg)' : kindColor(d.kind))
/** barva oznake (besedilo) */
export const sessInk = (d: RaceKey): string => (isRace(d) ? 'var(--accent-fg)' : kindInk(d.kind))
export const sessLabel = (d: RaceKey): string => (isRace(d) ? 'Tekma' : kindLabelOf(d))
export function SessIcon({ d, size = 17 }: { d: RaceKey; size?: number }) {
  return isRace(d) ? <IcoTrophy width={size} height={size} /> : <KindIcon kind={d.kind} size={size} />
}

/**
 * Bistvo tekme (v3.48): tempo in taktika, ne zajtrk — prvi stavek opisa tekme je »Zajtrk 2–3 h prej …«, gorivo je v
 * kartici Gorivo, golo ogrevanje pa v Podrobnostih. Ostane prvi stavek s tempom; brez njega običajni gist.
 */
export function raceGist(desc: string | null | undefined): string {
  const t = (desc || '').replace(/\s+/g, ' ').trim()
  const parts = t.split(/(?<=[.!?])\s+(?=[A-ZČŠŽ])/u)
    .map(x => x.replace(/^Zajtrk[^,(]*(\([^)]*\))?[^,.]*(,\s*|\.$)/u, ''))
    .filter(x => x && !/^(Na kolesu|Dan prej)\b/u.test(x))
    .map(x => x.charAt(0).toUpperCase() + x.slice(1))
  // »Ogrevanje 25–30 min s 3 × 2 min na pragu.« ni tempo; »Ogrevanje 25 min; prvih 5 min ne prehitro …« je
  const pace = parts.find(x => !/^Ogrevanje\b/u.test(x) || x.includes(';')) ?? parts[0]
  return pace ? gist(pace) : gist(t)
}

/**
 * Struktura dela za dneve z vajami (v3.48): »4 × 4 min, vmes 4 min lahko« namesto prvega stavka opisa — ta je pri
 * intervalih ogrevanje in se je odrezal. Brez ogrevanja, izteka in Z2 vmes. `known` = cilj, ki ga že kaže vrstica
 * cone (◎) — tega v strukturi ne ponovimo. Prazno, ko seja nima vsaj dveh delov.
 */
export function drillGist(steps: readonly Step[], known?: string | null): string {
  // (v3.51) test FTP: test in iztek (brez ogrevanja) — prej prazno in opis odrezan (»… 20 …«)
  if (steps.some(s => s.kind === 'test')) return structureLines(steps.filter(s => s.kind === 'test' || s.kind === 'iztek')).join(' · ')
  if (steps.filter(s => s.kind === 'delo').length < 2) return ''
  const work = steps.filter(s => s.group != null).map(s => (known && s.target === known ? { ...s, target: null } : s))
  return structureLines(work).join(' · ')
}
