/**
 * (v3.51) Velikost pisave v rem: »Velikost pisave« brskalnika (Chrome, Android) poveča besedilo — prej 0 % besedila,
 * ker so bile velikosti v px. rem(13) = 0.8125rem = 13 px pri privzeti velikosti (videz enak na piko).
 * Številke v slogu (fontSize: 13) spreminja skripta rem.py (scratchpad/audit51/impl-PLATFORMA).
 */
export const rem = (px: number): string => `${px / 16}rem`
