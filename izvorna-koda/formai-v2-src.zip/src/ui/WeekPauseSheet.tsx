import { useState } from 'react'
import { useApp, setWeekPause, endWeekPause } from '@/state/store'
import { navigate } from '@/app/router'
import { Sheet, Btn, Card, Chip, KindIcon } from '@/ui/primitives'
import { SickSheet } from '@/ui/SickSheet'
import { IcoCheck } from '@/ui/icons'
import { addDays, weekStartIso } from '@/domain/training/load'
import { activePause, pauseDays, pauseLine, REASONS, type PauseMode, type PauseReason } from '@/domain/training/pause'
import { dm } from '@/ui/format'

/**
 * (v3.50) »Ta teden …«: brez treningov ali brez kolesa do nedelje (po želji še naslednji teden, razlog ni obvezen).
 * En tap uveljavi (z »Razveljavi«); ko premor velja, ga tu tudi prekličeš ali spremeniš. Dosegljivo z Danes
 * (Spremeni, Danes ne gre, dan počitka), s Plana (ta teden) in iz klepeta s trenerjem.
 */
export function WeekPauseSheet({ open, onClose, onSick }: { open: boolean; onClose: () => void; onSick?: () => void }) {
  const app = useApp()
  const cur = activePause(app.profile, app.today)
  const sun = addDays(weekStartIso(app.today), 6)
  // (v3.50) ob odprtju izbira po veljavnem premoru: dvotedenski ostane dvotedenski, razlog ostane (prej »Do nedelje« in
  // brez razloga — sprememba načina je premor tiho skrajšala na to nedeljo)
  const curTwo = !!cur && cur.to > sun, curReason = cur?.reason ?? null
  const [two, setTwo] = useState(curTwo)
  const [reason, setReason] = useState<PauseReason | null>(curReason)
  const [shown, setShown] = useState(open)
  if (open !== shown) { setShown(open); if (open) { setTwo(curTwo); setReason(curReason) } }
  const [busy, setBusy] = useState(false)
  // (v3.50) brez onSick (Plan, trener): »Bolan sem« odpre list tu — prej gumba ni bilo
  const [sickOpen, setSickOpen] = useState(false)
  const sick = onSick ?? (() => setSickOpen(true))
  const until = two ? `do nedelje, ${dm(addDays(sun, 7))}` : app.today === sun ? 'danes' : 'do nedelje'
  async function go(mode: PauseMode) {
    setBusy(true)
    try { await setWeekPause(mode, { twoWeeks: two, reason }) } finally { setBusy(false) }
    onClose()
  }
  async function cancel() {
    setBusy(true)
    try { await endWeekPause() } finally { setBusy(false) }
    onClose()
  }
  return (<>
    <Sheet open={open} onClose={onClose} label="Ta teden">
      <b style={{ display: 'block', fontSize: 17, letterSpacing: '-.02em' }}>Ta teden …</b>
      {cur
        ? <p style={{ fontSize: 13, marginTop: 6 }}><b>Zdaj velja: {pauseLine(cur, app.today).replace(/^(Ta teden|Danes): /, '').replace(/\.$/, '')}.</b> Spodaj ga spremeniš ali prekličeš.</p>
        : <p style={{ fontSize: 13, marginTop: 6, lineHeight: 1.5 }}>Povej, kaj ta teden gre — načrt se prilagodi, tudi na uri. Po premoru se nadaljuje kot običajno.</p>}
      <div className="row" role="group" aria-label="Koliko časa" style={{ gap: 6, marginTop: 12, flexWrap: 'wrap' }}>
        <Chip sm on={!two} onClick={() => setTwo(false)}>{app.today === sun ? 'Samo danes' : 'Do nedelje'}</Chip>
        <Chip sm on={two} onClick={() => setTwo(true)}>Še naslednji teden</Chip>
      </div>
      <div className="row" role="group" aria-label="Zakaj (ni obvezno)" style={{ gap: 6, marginTop: 8, flexWrap: 'wrap', alignItems: 'center' }}>
        <span className="muted" style={{ fontSize: 12 }}>Zakaj (ni obvezno):</span>
        {REASONS.map(r => <Chip key={r.k} sm on={reason === r.k} onClick={() => setReason(reason === r.k ? null : r.k)}>{r.t}</Chip>)}
      </div>
      {reason === 'bolan' && (
        <p className="muted" style={{ fontSize: 12, marginTop: 8 }}>
          Pri bolezni je bolje »Bolan sem« — takrat je prehrana brez deficita.{' '}
          <button type="button" className="chip sm click" onClick={() => { onClose(); sick() }}>Bolan sem</button>
        </p>
      )}
      <div className="stack" style={{ gap: 8, marginTop: 14 }}>
        <button type="button" className="skip-opt" disabled={busy} onClick={() => void go('vse')}>
          <b>Brez treningov {until}</b><small>Treningi do takrat odpadejo — tudi z ure. Sprehod po želji ni kršitev.</small>
        </button>
        <button type="button" className="skip-opt" disabled={busy} onClick={() => void go('kolo')}>
          <b>Brez kolesa {until}</b><small>Moč, tek in hoja ostanejo; vožnje odpadejo — tudi z ure.</small>
        </button>
      </div>
      {cur && <Btn block style={{ marginTop: 12 }} disabled={busy} onClick={() => void cancel()}>Prekliči premor</Btn>}
      <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Zapri</Btn>
    </Sheet>
    {!onSick && <SickSheet open={sickOpen} onClose={() => setSickOpen(false)} />}
  </>)
}

/** Danes v premoru: do kdaj, »Prekliči premor« in »Dodaj trening« (vadba po želji ni kršitev). compact = vrstica pod treningom (brez kolesa ostane moč). */
// (v3.50) onChange (»Spremeni premor« — list »Ta teden …«) in onSick (»Bolan sem«): med premorom brez treningov ni kartice
// počitka, zato sta bila oba nedosegljiva z Danes (»Bolan sem« pa v vsej aplikaciji)
export function WeekPauseCard({ compact = false, onChange, onSick }: { compact?: boolean; onChange?: () => void; onSick?: () => void }) {
  const app = useApp()
  const [busy, setBusy] = useState(false)
  const w = activePause(app.profile, app.today)
  if (!w) return null
  const cancel = async () => { setBusy(true); try { await endWeekPause() } finally { setBusy(false) } }
  if (compact) return (
    <Card tight className="pause-row">
      <span className="pause-row-t"><b>{pauseLine(w, app.today)}</b>{w.mode === 'kolo' ? <span className="muted"> · moč, tek in hoja ostanejo</span> : null}</span>
      <button type="button" className="chip sm click" disabled={busy} onClick={() => void cancel()}>Prekliči</button>
    </Card>
  )
  return (
    <Card className="sess spot" style={{ marginTop: 12, ['--c' as string]: 'var(--t-poc)' }}>
      <div className="kbadge"><span className="ki"><KindIcon kind="pocitek" /></span>Premor · danes</div>
      <div className="ttl">{pauseLine(w, app.today)}</div>
      <p style={{ fontSize: 13, marginTop: 6 }}>{w.mode === 'kolo' ? 'Vožnje so do takrat umaknjene, tudi z ure. Moč, tek in hoja ostanejo.' : 'Treningi so do takrat umaknjeni, tudi z ure.'} Sprehod ali vadba po želji ni kršitev.</p>
      <p className="muted" style={{ fontSize: 12, marginTop: 6 }}>{pauseDays(w) >= 8 ? 'Po premoru sta prva dva dneva lažja, nato po načrtu.' : 'Po premoru se načrt nadaljuje kot običajno.'}</p>
      <div className="row" style={{ gap: 6, marginTop: 12, flexWrap: 'wrap' }}>
        <Btn ghost sm disabled={busy} onClick={() => void cancel()}>Prekliči premor</Btn>
        <button type="button" className="chip sm click" onClick={() => navigate('plan', { dan: app.today })}>Dodaj trening</button>
        {onChange && <button type="button" className="chip sm click" onClick={onChange}>Spremeni premor</button>}
        {onSick && <button type="button" className="chip sm click" onClick={onSick}>Bolan sem</button>}
      </div>
    </Card>
  )
}

/** Plan (ta teden): čip »Ta teden …« oz. »premor do nedelje« — odpre list. */
export function WeekPauseChip() {
  const app = useApp()
  const [open, setOpen] = useState(false)
  const w = activePause(app.profile, app.today)
  return (<>
    <button type="button" className={`chip sm click${w ? ' on' : ''}`} onClick={() => setOpen(true)}>{w ? pauseLine(w, app.today).replace(/^(Ta teden|Danes): /, '') : 'Ta teden …'}</button>
    <WeekPauseSheet open={open} onClose={() => setOpen(false)} />
  </>)
}

/**
 * Pod odgovorom trenerja, ko si napisal »ta teden nočem nič« ali »ta teden brez kolesa«: gumb, ki premor uveljavi
 * (trener načrta ne spreminja sam). Ko premor že velja, pove to in ponudi spremembo.
 */
export function PauseOffer({ mode, twoWeeks = false }: { mode: PauseMode; twoWeeks?: boolean }) {
  const app = useApp()
  const [open, setOpen] = useState(false)
  const [busy, setBusy] = useState(false)
  const w = activePause(app.profile, app.today)
  const holds = !!w && (w.mode === 'vse' || w.mode === mode)
  const label = `Uveljavi: ${twoWeeks ? 'ta in naslednji teden' : 'ta teden'} ${mode === 'kolo' ? 'brez kolesa' : 'brez treningov'}`
  return (
    <div className="pause-offer">
      {/* (v3.50) sprememba veljavnega premora obdrži razlog */}
      {holds
        ? <span className="pause-ok"><IcoCheck width={14} height={14} aria-hidden="true" /> {pauseLine(w!, app.today)} — velja.</span>
        : <Btn primary sm disabled={busy} onClick={async () => { setBusy(true); try { await setWeekPause(mode, { twoWeeks, ...(w?.reason ? { reason: w.reason } : {}) }) } finally { setBusy(false) } }}>{label}</Btn>}
      <button type="button" className="chip sm click" onClick={() => setOpen(true)}>{holds ? 'spremeni' : 'druge možnosti'}</button>
      <WeekPauseSheet open={open} onClose={() => setOpen(false)} />
    </div>
  )
}
