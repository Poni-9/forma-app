import { useState } from 'react'
import { useApp, setWeekPause, endWeekPause, saveRaces, toast } from '@/state/store'
import { navigate } from '@/app/router'
import { Sheet, Btn, Card, Chip, KindIcon } from '@/ui/primitives'
import { SickSheet } from '@/ui/SickSheet'
import { IcoCheck } from '@/ui/icons'
import { addDays, weekStartIso } from '@/domain/training/load'
import { activePause, backDays, pauseLine, pausePeriod, pauseShort, REASONS, type PauseMode, type PauseReason } from '@/domain/training/pause'
import { dm, dayName, count, W } from '@/ui/format'
import { fmtDur } from '@/domain/training/load'
import { isRace } from '@/ui/SessBits'
import { g } from '@/ui/gender'
import type { PlanDay } from '@/domain/types'
import { rem } from '@/ui/rem'

/** (v3.51) ime tekme brez razdalje (»Kronometer Vodice — 18 km« → »Kronometer Vodice«) */
const raceName = (d: Pick<PlanDay, 'title'>) => d.title.replace(/\s+—\s+.*$/, '')
/** (v3.51) neopravljene tekme v obdobju premora — premor jih ne umakne (odstraniš jih v Planu) */
export function racesIn(plan: readonly PlanDay[], from: string, to: string): PlanDay[] {
  return plan.filter(d => d.date >= from && d.date <= to && isRace(d) && !d.done).sort((a, b) => a.date.localeCompare(b.date))
}
/** »Kronometer Vodice ostane — odstraniš ga v Planu.« (ena tekma) ali »Tekme ostanejo …« */
export function racesStay(rs: readonly PlanDay[]): string | null {
  if (!rs.length) return null
  return rs.length === 1 ? `${raceName(rs[0]!)} ostane — odstraniš ga v Planu.` : `Tekme (${rs.map(raceName).join(', ')}) ostanejo — odstraniš jih v Planu.`
}
/**
 * (v3.51) Kaj premor vzame, preden tapneš (kot pauseify): neopravljeni treningi v obdobju, ki jih način umakne — brez
 * treningov vse razen počitka, brez kolesa vožnje, teste in kolo na koncu moči. Tekme, opravljeno in bolezen ostanejo.
 */
export function pausePreview(plan: readonly PlanDay[], mode: PauseMode, from: string, to: string): { n: number; min: number; races: PlanDay[] } {
  let n = 0, min = 0
  // (v3.51) predaktivacija dan pred neopravljeno tekmo ostane (kot v pauseify) — prej jo je predogled štel med odpadle
  const raceDays = new Set(plan.filter(d => !d.done && isRace(d)).map(d => d.date))
  for (const d of plan) {
    if (d.date < from || d.date > to || d.done || isRace(d) || d.sickPrev || d.kind === 'pocitek') continue
    if (/^Predaktivacija\b/.test(d.title || '') && raceDays.has(addDays(d.date, 1))) continue
    if (mode === 'vse' || d.kind === 'kolo' || d.kind === 'test') { n++; min += d.durationMin || 0 }
    else if (d.tail?.kind === 'kolo') min += d.tail.durationMin || 0
  }
  return { n, min, races: racesIn(plan, from, to) }
}
/**
 * (v3.51) Ali ima »Brez kolesa« smisel: v obdobju je vsaj ena vožnja (ali kolo po moči) in kolo sploh imaš — prej
 * ponujen tudi osebi brez kolesa (»premor (brez kolesa)« na dan počitka). `others`: ostane še kaj (moč, tek, hoja) —
 * sicer »Brez kolesa« vzame vse in besedilo ne sme obljubiti »moč, tek in hoja ostanejo«.
 */
export function bikePauseOf(plan: readonly PlanDay[], p: { gear?: { noBike?: boolean } | null }, from: string, to: string): { bike: boolean; others: boolean } {
  const kolo = pausePreview(plan, 'kolo', from, to), vse = pausePreview(plan, 'vse', from, to)
  // obdobje brez shranjenih dni (teden še ni sestavljen): ne vemo — izbira ostane (razen brez kolesa)
  const unknown = !plan.some(d => d.date >= from && d.date <= to)
  return { bike: !p.gear?.noBike && (unknown || kolo.n > 0 || kolo.min > 0), others: unknown || vse.n > kolo.n }
}
/** (v3.51) Kaj ostane v premoru brez kolesa (kartica, vrstica): neopravljeni treningi, ki niso kolo, od danes do konca. */
export const othersLeft = (plan: readonly PlanDay[], from: string, to: string): boolean =>
  plan.some(d => d.date >= from && d.date <= to && !d.done && !d.sickPrev && !isRace(d) && d.kind !== 'pocitek' && d.kind !== 'kolo' && d.kind !== 'test')
const previewText = (q: { n: number; min: number }, again: boolean): string =>
  q.n ? `Odpade${again ? ' še' : ''} ${count(q.n, W.trening)} (${fmtDur(q.min)}).` : q.min ? `Odpade ${fmtDur(q.min)} kolesa po moči.` : 'Noben trening ne odpade.'

/**
 * (v3.50) »Ta teden …«: brez treningov ali brez kolesa do nedelje (po želji še naslednji teden, razlog ni obvezen).
 * En tap uveljavi (z »Razveljavi«); ko premor velja, ga tu tudi prekličeš ali spremeniš. Dosegljivo z Danes
 * (Spremeni, Danes ne gre, dan počitka), s Plana (ta teden) in iz klepeta s trenerjem.
 */
export function WeekPauseSheet({ open, onClose, onSick }: { open: boolean; onClose: () => void; onSick?: () => void }) {
  const app = useApp()
  const cur = activePause(app.profile, app.today)
  const sun = addDays(weekStartIso(app.today), 6)
  // (v3.50) ob odprtju izbira po veljavnem premoru: dvotedenski ostane dvotedenski, razlog ostane (prej »Do nedelje« in
  // brez razloga — sprememba načina je premor tiho skrajšala na to nedeljo)
  const curTwo = !!cur && cur.to > sun, curReason = cur?.reason ?? null
  const [two, setTwo] = useState(curTwo)
  const [reason, setReason] = useState<PauseReason | null>(curReason)
  const [shown, setShown] = useState(open)
  if (open !== shown) { setShown(open); if (open) { setTwo(curTwo); setReason(curReason) } }
  const [busy, setBusy] = useState(false)
  // (v3.50) brez onSick (Plan, trener): »Bolan sem« odpre list tu — prej gumba ni bilo
  const [sickOpen, setSickOpen] = useState(false)
  const sick = onSick ?? (() => setSickOpen(true))
  const until = two ? `do nedelje, ${dm(addDays(sun, 7))}` : app.today === sun ? 'danes' : 'do nedelje'
  // (v3.51) tekma v času premora: ostane (predaktivacija dan prej tudi) ali jo odstraniš — prej list o njej ni povedal nič
  const end = two ? addDays(sun, 7) : sun
  // (v3.51) brez že opravljene (današnje) tekme — prej »Ostane« in »Odstrani tekmo« zvečer po tekmi
  const races = (app.profile.races || []).filter(r => r.date >= app.today && r.date <= end && !app.plan.some(d => d.raceId === r.id && d.date === r.date && d.done))
  async function dropRace(id: string) {
    setBusy(true)
    try { await saveRaces((app.profile.races || []).filter(r => r.id !== id)); toast('Tekma je odstranjena.', 'ok') } finally { setBusy(false) }
  }
  /** (v3.51) ta način in trajanje že veljata — gumb pove to (prej dva enaka gumba, tap je premor znova »uveljavil«) */
  const isCur = (mode: PauseMode) => !!cur && cur.mode === mode && two === curTwo && reason === curReason
  const to = pausePeriod(app.today, 'vse', { twoWeeks: two }).to
  const pv = (m: PauseMode) => pausePreview(app.plan, m, app.today, to)
  const today1 = until === 'danes'
  const bp = bikePauseOf(app.plan, app.profile, app.today, to)
  async function go(mode: PauseMode) {
    setBusy(true)
    try { await setWeekPause(mode, { twoWeeks: two, reason }) } finally { setBusy(false) }
    onClose()
  }
  async function cancel() {
    setBusy(true)
    try { await endWeekPause() } finally { setBusy(false) }
    onClose()
  }
  return (<>
    <Sheet open={open} onClose={onClose} label="Ta teden">
      <h2 className="sheet-t">Ta teden …</h2>
      {cur
        ? <p style={{ fontSize: rem(13), marginTop: 6 }}><b>Zdaj velja: {pauseShort(cur, app.today).replace(/\.$/, '')}.</b> Spodaj ga spremeniš ali prekličeš.</p>
        : <p style={{ fontSize: rem(13), marginTop: 6, lineHeight: 1.5 }}>Povej, kaj ta teden gre — načrt se prilagodi, tudi na uri. Po premoru se nadaljuje kot običajno.</p>}
      <div className="row" role="group" aria-label="Koliko časa" style={{ gap: 6, marginTop: 12, flexWrap: 'wrap' }}>
        <Chip sm on={!two} onClick={() => setTwo(false)}>{app.today === sun ? 'Samo danes' : 'Do nedelje'}</Chip>
        <Chip sm on={two} onClick={() => setTwo(true)}>Še naslednji teden</Chip>
      </div>
      <div className="row" role="group" aria-label="Zakaj (ni obvezno)" style={{ gap: 6, marginTop: 8, flexWrap: 'wrap', alignItems: 'center' }}>
        <span className="muted" style={{ fontSize: rem(12) }}>Zakaj (ni obvezno):</span>
        {REASONS.map(r => <Chip key={r.k} sm on={reason === r.k} onClick={() => setReason(reason === r.k ? null : r.k)}>{r.k === 'bolan' ? g(app.profile, r.t, 'bolna') : r.t}</Chip>)}
      </div>
      {reason === 'bolan' && (
        <p className="muted" style={{ fontSize: rem(12), marginTop: 8 }}>
          Pri bolezni je bolje »{g(app.profile, 'Bolan sem', 'Bolna sem')}« — takrat je prehrana brez deficita.{' '}
          <button type="button" className="chip sm click" onClick={() => { onClose(); sick() }}>{g(app.profile, 'Bolan sem', 'Bolna sem')}</button>
        </p>
      )}
      <div className="stack" style={{ gap: 8, marginTop: 14 }}>
        {/* (v3.51) veljavni način označen (»velja«); v nedeljo brez »do takrat«; koliko odpade in da tekma ostane */}
        {(['vse', 'kolo'] as const).filter(m => m === 'vse' || bp.bike || cur?.mode === 'kolo' || (!!cur && !app.profile.gear?.noBike)).map(m => {
          const on = isCur(m)
          const q = pv(m)
          return (
            <button key={m} type="button" className={`skip-opt${on ? ' on' : ''}`} aria-pressed={on} aria-current={on || undefined} disabled={busy || on} onClick={() => void go(m)}>
              <b>{m === 'vse' ? 'Brez treningov' : 'Brez kolesa'} {until}{on ? <span className="pause-on"> ✓ velja</span> : null}</b>
              <small>{m === 'vse'
                ? (today1 ? 'Današnji trening odpade — tudi z ure. Sprehod po želji ni kršitev.' : 'Treningi do takrat odpadejo — tudi z ure. Sprehod po želji ni kršitev.')
                : !bp.others ? (today1 ? 'Drugega danes v načrtu ni — današnja vožnja odpade, tudi z ure. Sprehod po želji ni kršitev.' : 'V načrtu so do takrat samo vožnje, zato odpade vse — tudi z ure. Sprehod po želji ni kršitev.')
                : (today1 ? 'Moč, tek in hoja ostanejo; današnja vožnja odpade — tudi z ure.' : 'Moč, tek in hoja ostanejo; vožnje odpadejo — tudi z ure.')}</small>
              {!on && <small className="pause-pv">{previewText(q, !!cur)}</small>}
            </button>
          )
        })}
      </div>
      {races.map(r => (
        <div key={r.id} className="pause-race" role="group" aria-label={`Tekma ${r.name}`}>
          <p style={{ fontSize: rem(12.5), margin: 0 }}>V tem času je tekma <b>{r.name}</b> ({dayName(r.date)}, {dm(r.date)}). {r.date > app.today ? 'Ostane — tudi predaktivacija dan prej.' : 'Ostane.'}</p>
          <button type="button" className="chip sm click" disabled={busy} onClick={() => void dropRace(r.id)}>Odstrani tekmo</button>
        </div>
      ))}
      {cur && <Btn block style={{ marginTop: 12 }} disabled={busy} onClick={() => void cancel()}>Prekliči premor</Btn>}
      <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Zapri</Btn>
    </Sheet>
    {!onSick && <SickSheet open={sickOpen} onClose={() => setSickOpen(false)} />}
  </>)
}

/** Danes v premoru: do kdaj, »Prekliči premor« in »Dodaj trening« (vadba po želji ni kršitev). compact = vrstica pod treningom (brez kolesa ostane moč). */
// (v3.50) onChange (»Spremeni premor« — list »Ta teden …«) in onSick (»Bolan sem«): med premorom brez treningov ni kartice
// počitka, zato sta bila oba nedosegljiva z Danes (»Bolan sem« pa v vsej aplikaciji)
export function WeekPauseCard({ compact = false, onChange, onSick }: { compact?: boolean; onChange?: () => void; onSick?: () => void }) {
  const app = useApp()
  const [busy, setBusy] = useState(false)
  const w = activePause(app.profile, app.today)
  if (!w) return null
  const cancel = async () => { setBusy(true); try { await endWeekPause() } finally { setBusy(false) } }
  // (v3.51) tekma v premoru ostane — povej (prej »vožnje so umaknjene« pod kartico kolesarske tekme)
  const stay = racesStay(racesIn(app.plan, app.today, w.to))
  // (v3.51) »Moč, tek in hoja ostanejo« samo, ko je kaj od tega v načrtu; »danes« pri premoru, ki se konča danes
  const left = othersLeft(app.plan, app.today, w.to)
  const oneDay = w.to === app.today
  if (compact) return (
    <Card tight className="pause-row">
      <span className="pause-row-t"><b>{pauseLine(w, app.today)}</b>{w.mode === 'kolo' && left ? <span className="muted"> · moč, tek in hoja ostanejo</span> : null}{stay ? <span className="muted"> · {stay}</span> : null}</span>
      <button type="button" className="chip sm click" disabled={busy} onClick={() => void cancel()}>Prekliči premor</button>
    </Card>
  )
  return (
    <Card className="sess spot" style={{ marginTop: 12, ['--c' as string]: 'var(--t-poc)' }}>
      <div className="kbadge"><span className="ki"><KindIcon kind="pocitek" /></span>Premor · danes</div>
      <div className="ttl">{pauseLine(w, app.today)}</div>
      <p style={{ fontSize: rem(13), marginTop: 6 }}>{w.mode === 'kolo' ? `Vožnje so ${oneDay ? 'danes' : 'do takrat'} umaknjene, tudi z ure.${left ? ' Moč, tek in hoja ostanejo.' : ''}` : `Treningi so ${oneDay ? 'danes' : 'do takrat'} umaknjeni, tudi z ure.`} Sprehod ali vadba po želji ni kršitev.{stay ? ` ${stay}` : ''}</p>
      <p className="muted" style={{ fontSize: rem(12), marginTop: 6 }}>{/* (v3.51) kar načrt res naredi (pauseBuilt): trd trening prve dni po premoru postane lahek — lahki dnevi ostanejo (prej »lažja«, načrt po meri pa enak) */}{backDays(w) >= 2 ? 'Po premoru prva dva dneva brez trdega treninga, nato po načrtu.' : backDays(w) === 1 ? 'Po premoru prvi dan brez trdega treninga, nato po načrtu.' : 'Po premoru se načrt nadaljuje kot običajno.'}</p>
      <div className="row" style={{ gap: 6, marginTop: 12, flexWrap: 'wrap' }}>
        <Btn ghost sm disabled={busy} onClick={() => void cancel()}>Prekliči premor</Btn>
        <button type="button" className="chip sm click" onClick={() => navigate('plan', { dan: app.today, dodaj: '1' })}>Dodaj trening</button>
        {onChange && <button type="button" className="chip sm click" onClick={onChange}>Spremeni premor</button>}
        {onSick && <button type="button" className="chip sm click" onClick={onSick}>{g(app.profile, 'Bolan sem', 'Bolna sem')}</button>}
      </div>
    </Card>
  )
}

/** Plan (ta teden): čip »Ta teden …« oz. »premor do nedelje« — odpre list. */
export function WeekPauseChip() {
  const app = useApp()
  const [open, setOpen] = useState(false)
  const w = activePause(app.profile, app.today)
  return (<>
    <button type="button" className={`chip sm click${w ? ' on' : ''}`} onClick={() => setOpen(true)}>{w ? pauseShort(w, app.today) : 'Ta teden …'}</button>
    <WeekPauseSheet open={open} onClose={() => setOpen(false)} />
  </>)
}

/**
 * Pod odgovorom trenerja, ko si napisal »ta teden nočem nič« ali »ta teden brez kolesa«: gumb, ki premor uveljavi
 * (trener načrta ne spreminja sam). Ko premor že velja, pove to in ponudi spremembo.
 */
export function PauseOffer({ mode, twoWeeks = false }: { mode: PauseMode; twoWeeks?: boolean }) {
  const app = useApp()
  const [open, setOpen] = useState(false)
  const [busy, setBusy] = useState(false)
  const w = activePause(app.profile, app.today)
  // (v3.51) »ta in naslednji teden« ob enotedenskem premoru ne velja — gumb ga podaljša (prej »… — velja.« brez podaljšanja)
  const sun2 = addDays(weekStartIso(app.today), 13)
  const holds = !!w && (w.mode === 'vse' || w.mode === mode) && (!twoWeeks || w.to >= sun2)
  const label = `Uveljavi: ${twoWeeks ? (w && w.to < sun2 ? 'še naslednji teden' : 'ta in naslednji teden') : 'ta teden'} ${mode === 'kolo' ? 'brez kolesa' : 'brez treningov'}`
  return (
    <div className="pause-offer">
      {/* (v3.50) sprememba veljavnega premora obdrži razlog */}
      {holds
        ? <span className="pause-ok"><IcoCheck width={14} height={14} aria-hidden="true" /> {pauseLine(w!, app.today)} — velja.</span>
        : <Btn primary sm disabled={busy} onClick={async () => { setBusy(true); try { await setWeekPause(mode, { twoWeeks, ...(w?.reason ? { reason: w.reason } : {}) }) } finally { setBusy(false) } }}>{label}</Btn>}
      <button type="button" className="chip sm click" onClick={() => setOpen(true)}>{holds ? 'spremeni' : 'druge možnosti'}</button>
      <WeekPauseSheet open={open} onClose={() => setOpen(false)} />
    </div>
  )
}
