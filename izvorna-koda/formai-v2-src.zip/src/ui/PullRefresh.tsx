import { useEffect, useRef, useState } from 'react'
import { getState, syncIntervals, toast } from '@/state/store'
import { syncNow } from '@/data/sync'
import { icuReady } from '@/domain/intervals/client'
import { count, W } from '@/ui/format'
import { haptic } from '@/ui/haptic'

/** koliko px potega sproži osvežitev; poteg je »težji« od prsta (pol poti) */
export const PULL_TRIGGER = 64
const PULL_MAX = 96
const BUSY_ROUTES = new Set(['vadba', 'uvod', 'prijava'])

/**
 * Poteg navzdol na vrhu zaslona (nameščena aplikacija nima gumba za osvežitev): uskladi z oblakom in preveri nove
 * vožnje z ure. Samo dotik, samo ko je stran na vrhu, ne pri odprtem listu in ne med vadbo.
 */
export function PullRefresh() {
  const [pull, setPull] = useState(0)
  const [state, setState] = useState<'idle' | 'busy' | 'done'>('idle')
  const startY = useRef<number | null>(null)
  const pullRef = useRef(0)
  const busy = useRef(false)
  useEffect(() => {
    if (typeof window === 'undefined' || !('ontouchstart' in window)) return
    const route = () => location.hash.replace(/^#\/?/, '').split('?')[0] || 'danes'
    const onStart = (e: TouchEvent) => {
      startY.current = null
      if (busy.current || window.scrollY > 0 || document.querySelector('.sheet') || BUSY_ROUTES.has(route())) return
      const t = e.touches[0]; if (!t) return
      startY.current = t.clientY
    }
    const onMove = (e: TouchEvent) => {
      if (startY.current == null) return
      const t = e.touches[0]; if (!t) return
      const dy = t.clientY - startY.current
      if (dy <= 0 || window.scrollY > 0) { if (pullRef.current) { pullRef.current = 0; setPull(0) } return }
      const p = Math.min(PULL_MAX, dy * 0.5)
      if (p >= PULL_TRIGGER && pullRef.current < PULL_TRIGGER) haptic('tap')
      pullRef.current = p; setPull(p)
    }
    const onEnd = () => {
      if (startY.current == null) return
      startY.current = null
      const p = pullRef.current; pullRef.current = 0
      if (p < PULL_TRIGGER) { setPull(0); return }
      void refresh()
    }
    async function refresh() {
      busy.current = true; setState('busy'); setPull(PULL_TRIGGER)
      const t0 = Date.now()
      let added: number | null = null, err: string | null = null
      try {
        await syncNow({ quick: false })
        if (icuReady(getState().settings.intervals)) { const r = await syncIntervals(); added = r.added; err = r.kind && r.kind !== 'skipped' && r.error ? r.error : null }
      } catch { /* obvestilo spodaj */ }
      await new Promise(r => setTimeout(r, Math.max(0, 500 - (Date.now() - t0))))
      setState('done'); setPull(0)
      if (err) toast(err, 'err', 7000)
      else if (added) toast(`Osveženo — ${count(added, W.voznja)} z ure.`, 'ok', 3500)
      setTimeout(() => { setState('idle'); busy.current = false }, 700)
    }
    document.addEventListener('touchstart', onStart, { passive: true })
    document.addEventListener('touchmove', onMove, { passive: true })
    document.addEventListener('touchend', onEnd, { passive: true })
    document.addEventListener('touchcancel', onEnd, { passive: true })
    return () => { document.removeEventListener('touchstart', onStart); document.removeEventListener('touchmove', onMove); document.removeEventListener('touchend', onEnd); document.removeEventListener('touchcancel', onEnd) }
  }, [])
  const show = pull > 8 || state !== 'idle'
  if (!show) return null
  const ready = pull >= PULL_TRIGGER
  return (
    <div className={`ptr ${state}`} style={{ transform: `translate(-50%, ${Math.round(pull * 0.6) - 48}px)`, opacity: Math.min(1, pull / 40) }} role="status" aria-live="polite">
      <span className={`ptr-ico ${state === 'busy' ? 'spin' : ''}`} style={{ transform: state === 'idle' ? `rotate(${ready ? 180 : Math.round((pull / PULL_TRIGGER) * 180)}deg)` : undefined }} aria-hidden="true">{state === 'done' ? '✓' : '↓'}</span>
      {state === 'busy' ? 'Osvežujem …' : state === 'done' ? 'Osveženo' : ready ? 'Spusti za osvežitev' : 'Povleci za osvežitev'}
    </div>
  )
}
