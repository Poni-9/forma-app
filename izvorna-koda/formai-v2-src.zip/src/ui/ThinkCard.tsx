import { useEffect, useState } from 'react'
import { FigStage } from '@/ui/FigStage'
import type { FigSpec } from '@/domain/focus/tips'

/**
 * TRENER RAZMIŠLJA (Blaž, 14. 10.: »moraš kakšno animacijo dati … da razmišlja«; zvečer: »precej traja … tukaj bi
 * morala biti kakšna boljša animacija, da človek lažje počaka«). Claude z velikim premislekom lahko razmišlja minute:
 * kartica pokaže živ simbol, korake dela (iz njegovih podatkov — kaj trener ta hip tehta), čas in napredek po
 * resničnih časih zadnjih premislekov (»prejšnjič 1:48«), med čakanjem pa figuro, ki izvaja njegove športe, in
 * nasvete zanje (tap = naslednji). Zadnji korak (»Pišem …«) se prižge, ko strežnik sporoči, da model piše odgovor.
 * Zmanjšano gibanje: brez vrtenja in utripanja, figura stoji, nasveti se menjajo samo na tap.
 */
export interface Think {
  title: string; steps: string[]; writing: string; phase: 'misli' | 'pise'; at: number
  /** okvirni čas (s): srednji zadnjih premislekov na tej napravi ali okvirni za ta namen */
  est?: number
  /** zadnji resnični čas (s) — »prejšnjič 1:48« */
  last?: number | null
  /** nasveti, ki krožijo med čakanjem */
  tips?: string[]
  /** figure (njegovi športi), ki se menjajo med čakanjem */
  figs?: FigSpec[]
}

const STEP_MS = 7000
const TIP_MS = 9000
const mmss = (s: number) => `${Math.floor(s / 60)}:${String(Math.round(s) % 60).padStart(2, '0')}`

export function ThinkCard({ t, compact = false }: { t: Think; compact?: boolean }) {
  const [now, setNow] = useState(Date.now())
  const [calm] = useState(() => typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches)
  useEffect(() => { const id = window.setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(id) }, [])
  const sec = Math.max(0, Math.floor((now - t.at) / 1000))
  // koraki razmisleka se prižigajo po vrsti; zadnji ostane, dokler model ne začne pisati
  const cur = t.phase === 'pise' ? t.steps.length : Math.min(t.steps.length - 1, Math.floor((now - t.at) / STEP_MS))
  const all = [...t.steps, t.writing]
  // napredek: po okvirnem času do 90 %, nato počasi do 97 % (premislek traja dlje kot običajno); piše → skoraj konec
  const est = t.est && t.est > 5 ? t.est : null
  const frac = est ? (sec <= est ? 0.9 * (sec / est) : 0.9 + 0.07 * (1 - Math.exp(-(sec - est) / est))) : null
  const pct = frac == null ? null : Math.round(Math.max(t.phase === 'pise' ? 0.95 : 0.03, frac) * 100)
  const over = est != null && sec > est * 1.15 && t.phase === 'misli'
  // med čakanjem: figura (njegovi športi) in nasvet; tap na nasvet = naslednji
  const [tipIx, setTipIx] = useState(0)
  const tips = t.tips || []
  useEffect(() => {
    if (calm || tips.length < 2) return
    const id = window.setInterval(() => setTipIx(i => i + 1), TIP_MS)
    return () => clearInterval(id)
  }, [calm, tips.length])
  const figs = t.figs || []
  const fig = figs.length ? figs[Math.floor(sec / 12) % figs.length]! : null
  const tip = tips.length ? tips[tipIx % tips.length]! : null
  // obroč napredka okrog jedra (r = 19 → obseg 119,4)
  const C = 2 * Math.PI * 19
  const ring = pct == null ? null : C * (1 - pct / 100)
  // koraki kot trak: prejšnji (✓), trenutni (lesketa se), naslednji (bled) — kartica ne raste v nedogled
  const rows = [cur - 1, cur, cur + 1].filter(i => i >= 0 && i < all.length)
  const sub = t.phase === 'pise' ? 'Piše odgovor' : 'Razmišlja'
  return (
    <div className={`tk${compact ? ' compact' : ''}${t.phase === 'pise' ? ' writing' : ''}`}>
      {!compact && fig ? <FigStage fig={fig} size={142} chip={fig.label} clock={mmss(sec)} className="tk-stage" /> : null}
      <div role="status" aria-live="polite" className="tk-body">
        <div className="tk-head">
          <span className="tk-orb" aria-hidden="true">
            <svg viewBox="0 0 44 44">
              <circle className="tk-ring-bg" cx="22" cy="22" r="19" />
              {ring != null ? <circle className="tk-ring" cx="22" cy="22" r="19" strokeDasharray={C.toFixed(1)} strokeDashoffset={ring.toFixed(1)} /> : <circle className="tk-ring spin" cx="22" cy="22" r="19" strokeDasharray={`${(C * 0.28).toFixed(1)} ${C.toFixed(1)}`} />}
            </svg>
            <b />
          </span>
          <span className="tk-h">
            <b>{t.title}</b>
            <small aria-hidden="true">{sub}{compact || !fig ? ` · ${mmss(sec)}` : ''}{t.last ? ` · prejšnjič ${mmss(t.last)}` : ''}</small>
          </span>
        </div>
        <ol className="tk-steps">
          {rows.map(i => (
            <li key={i} className={i < cur ? 'done' : i === cur ? 'now' : 'next'} aria-current={i === cur ? 'step' : undefined} aria-hidden={i > cur ? true : undefined}>
              <span className="tk-dot" aria-hidden="true">{i < cur ? <svg viewBox="0 0 12 12"><path d="M2.5 6.2 5 8.6l4.6-5" /></svg> : null}</span>
              <span className="tk-txt">{all[i]}</span>
            </li>
          ))}
        </ol>
      </div>
      {tip && (compact || sec >= 3) ? (
        <button type="button" className="tk-tip" onClick={() => setTipIx(i => i + 1)} aria-label={`Nasvet: ${tip} Tapni za naslednjega.`}>
          <span className="tk-bulb" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.6 10.8c.7.5 1.1 1.3 1.1 2.2h5c0-.9.4-1.7 1.1-2.2A6 6 0 0 0 12 3Z" /></svg></span>
          <span className="tk-tipb">
            <small>Ali veš?</small>
            <span key={tipIx} className="tk-tiptxt">{tip}</span>
          </span>
          <span className="tk-next" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="m9 6 6 6-6 6" /></svg></span>
        </button>
      ) : null}
      {!compact && sec >= 20 && t.phase === 'misli' ? (
        <p className="tk-note">{over ? 'Tokrat premišlja dlje kot običajno. ' : ''}Pusti aplikacijo odprto, dokler trener razmišlja.</p>
      ) : null}
    </div>
  )
}
