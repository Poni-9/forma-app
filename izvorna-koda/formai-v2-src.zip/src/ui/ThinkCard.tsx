import { useEffect, useState } from 'react'
import { ExerciseFigure } from '@/ui/figure/ExerciseFigure'
import type { FigSpec } from '@/domain/focus/tips'

/**
 * TRENER RAZMIŠLJA (Blaž, 14. 10.: »moraš kakšno animacijo dati … da razmišlja«; zvečer: »precej traja … tukaj bi
 * morala biti kakšna boljša animacija, da človek lažje počaka«). Claude z velikim premislekom lahko razmišlja minute:
 * kartica pokaže živ simbol, korake dela (iz njegovih podatkov — kaj trener ta hip tehta), čas in napredek po
 * resničnih časih zadnjih premislekov (»prejšnjič 1:48«), med čakanjem pa figuro, ki izvaja njegove športe, in
 * nasvete zanje (tap = naslednji). Zadnji korak (»Pišem …«) se prižge, ko strežnik sporoči, da model piše odgovor.
 * Zmanjšano gibanje: brez vrtenja in utripanja, figura stoji, nasveti se menjajo samo na tap.
 */
export interface Think {
  title: string; steps: string[]; writing: string; phase: 'misli' | 'pise'; at: number
  /** okvirni čas (s): srednji zadnjih premislekov na tej napravi ali okvirni za ta namen */
  est?: number
  /** zadnji resnični čas (s) — »prejšnjič 1:48« */
  last?: number | null
  /** nasveti, ki krožijo med čakanjem */
  tips?: string[]
  /** figure (njegovi športi), ki se menjajo med čakanjem */
  figs?: FigSpec[]
}

const STEP_MS = 7000
const TIP_MS = 9000
const mmss = (s: number) => `${Math.floor(s / 60)}:${String(Math.round(s) % 60).padStart(2, '0')}`

export function ThinkCard({ t, compact = false }: { t: Think; compact?: boolean }) {
  const [now, setNow] = useState(Date.now())
  const [calm] = useState(() => typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches)
  useEffect(() => { const id = window.setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(id) }, [])
  const sec = Math.max(0, Math.floor((now - t.at) / 1000))
  // koraki razmisleka se prižigajo po vrsti; zadnji ostane, dokler model ne začne pisati
  const cur = t.phase === 'pise' ? t.steps.length : Math.min(t.steps.length - 1, Math.floor((now - t.at) / STEP_MS))
  const all = [...t.steps, t.writing]
  // napredek: po okvirnem času do 90 %, nato počasi do 97 % (premislek traja dlje kot običajno); piše → skoraj konec
  const est = t.est && t.est > 5 ? t.est : null
  const frac = est ? (sec <= est ? 0.9 * (sec / est) : 0.9 + 0.07 * (1 - Math.exp(-(sec - est) / est))) : null
  const pct = frac == null ? null : Math.round(Math.max(t.phase === 'pise' ? 0.95 : 0.03, frac) * 100)
  const over = est != null && sec > est * 1.15 && t.phase === 'misli'
  // med čakanjem: figura (njegovi športi) in nasvet; tap na nasvet = naslednji
  const [tipIx, setTipIx] = useState(0)
  const tips = t.tips || []
  useEffect(() => {
    if (calm || tips.length < 2) return
    const id = window.setInterval(() => setTipIx(i => i + 1), TIP_MS)
    return () => clearInterval(id)
  }, [calm, tips.length])
  const figs = t.figs || []
  const fig = figs.length ? figs[Math.floor(sec / 12) % figs.length]! : null
  const tip = tips.length ? tips[tipIx % tips.length]! : null
  const showSide = sec >= (compact ? 0 : 4) && (tip || fig)
  return (
    <div className={`think-card${compact ? ' compact' : ''}`}>
      <div role="status" aria-live="polite">
        <div className="think-top">
          <span className="think-orb" aria-hidden="true"><i /><i /><i /><b /></span>
          <span className="think-h">
            <b>{t.title}</b>
            <small aria-hidden="true">
              {t.phase === 'pise' ? 'piše · ' : ''}{mmss(sec)}
              {t.last ? <span className="think-last"> · prejšnjič {mmss(t.last)}</span> : null}
            </small>
          </span>
        </div>
        {pct != null ? <div className="think-prog" aria-hidden="true"><i style={{ width: `${pct}%` }} /></div> : null}
        <ol className="think-steps">
          {all.map((s, i) => (i > cur || (compact && i !== cur) ? null : (
            <li key={i} className={i < cur ? 'done' : 'now'} aria-current={i === cur ? 'step' : undefined}>
              <span className="think-dot" aria-hidden="true">{i < cur ? '✓' : ''}</span>
              <span className="think-txt">{s}</span>
            </li>
          )))}
        </ol>
      </div>
      {showSide ? (
        <div className="think-side">
          {fig ? <span className="think-fig" key={fig.label}><ExerciseFigure id={fig.id} fallback={fig.fallback} size={compact ? 64 : 78} label={fig.label} /><small>{fig.label}</small></span> : null}
          {tip ? (
            <button type="button" className="think-tip" onClick={() => setTipIx(i => i + 1)} aria-label={`Nasvet: ${tip} Tapni za naslednjega.`}>
              <small>Ali veš?</small>
              <span key={tipIx} className="think-tiptxt">{tip}</span>
            </button>
          ) : null}
        </div>
      ) : null}
      {sec >= 20 && t.phase === 'misli' ? (
        <p className="think-note">{over ? 'Tokrat premišlja dlje kot običajno. ' : ''}Pusti aplikacijo odprto, dokler trener razmišlja.</p>
      ) : null}
    </div>
  )
}
