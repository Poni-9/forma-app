import { useEffect, useState } from 'react'

/**
 * TRENER RAZMIŠLJA (Blaž, 14. 10.: »moraš kakšno animacijo dati … da razmišlja«). Claude z največjim premislekom lahko
 * razmišlja minute: kartica pokaže živ simbol, korake dela (iz njegovih podatkov — kaj trener ta hip tehta) in čas.
 * Koraki se prižigajo po vrsti; zadnji (»Pišem …«) se prižge, ko strežnik sporoči, da model piše odgovor.
 * Zmanjšano gibanje: brez vrtenja in utripanja, samo koraki.
 */
export interface Think { title: string; steps: string[]; writing: string; phase: 'misli' | 'pise'; at: number }

const STEP_MS = 7000

export function ThinkCard({ t }: { t: Think }) {
  const [now, setNow] = useState(Date.now())
  useEffect(() => { const id = window.setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(id) }, [])
  const sec = Math.max(0, Math.floor((now - t.at) / 1000))
  // koraki razmisleka se prižigajo po vrsti; zadnji ostane, dokler model ne začne pisati
  const cur = t.phase === 'pise' ? t.steps.length : Math.min(t.steps.length - 1, Math.floor((now - t.at) / STEP_MS))
  const all = [...t.steps, t.writing]
  return (
    <div className="think-card" role="status" aria-live="polite">
      <div className="think-top">
        <span className="think-orb" aria-hidden="true"><i /><i /><i /><b /></span>
        <span className="think-h">
          <b>{t.title}</b>
          <small aria-hidden="true">{t.phase === 'pise' ? 'piše · ' : ''}{Math.floor(sec / 60)}:{String(sec % 60).padStart(2, '0')}</small>
        </span>
      </div>
      <ol className="think-steps">
        {all.map((s, i) => (i > cur ? null : (
          <li key={i} className={i < cur ? 'done' : 'now'} aria-current={i === cur ? 'step' : undefined}>
            <span className="think-dot" aria-hidden="true">{i < cur ? '✓' : ''}</span>
            <span className="think-txt">{s}</span>
          </li>
        )))}
      </ol>
      {sec >= 45 && t.phase === 'misli' ? <p className="think-note">Temeljit premislek lahko traja nekaj minut — pusti aplikacijo odprto.</p> : null}
    </div>
  )
}
