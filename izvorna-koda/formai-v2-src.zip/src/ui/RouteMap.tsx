import { useEffect, useRef, useState } from 'react'
import { decodePolyline, haversineM, type LatLon } from '@/domain/import/polyline'
import type { Climb } from '@/domain/routes/analyze'
import { Sheet, Btn } from '@/ui/primitives'

/**
 * Zemljevid trase v aplikaciji (OpenStreetMap, Leaflet se naloži šele ob odprtju): točno ta sled, ki gre na uro —
 * start, smer vožnje (puščice), kilometri in klanec za intervale. Brez zunanjih strani, ki bi pot preračunale po svoje.
 */
export function RouteMap({ open, onClose, poly, climb, title }: { open: boolean; onClose: () => void; poly: string; climb: Climb | null; title: string }) {
  const box = useRef<HTMLDivElement>(null)
  const [err, setErr] = useState<string | null>(null)
  useEffect(() => {
    if (!open) return
    let map: { remove: () => void } | null = null, dead = false
    void (async () => {
      try {
        const mod = await import('leaflet')
        const L = ((mod as unknown as { default?: typeof mod }).default ?? mod) as typeof import('leaflet')
        await import('leaflet/dist/leaflet.css')
        if (dead || !box.current) return
        const pts = decodePolyline(poly)
        if (pts.length < 2) return
        const m = L.map(box.current, { zoomControl: true, attributionControl: true })
        map = m
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 18, attribution: '© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>' }).addTo(m)
        const css = getComputedStyle(document.documentElement)
        const col = css.getPropertyValue('--t-kolo').trim() || '#38bdf8', acc = css.getPropertyValue('--accent').trim() || '#a3e635'
        L.polyline(pts, { color: '#0b0e12', weight: 7, opacity: 0.55 }).addTo(m)
        const line = L.polyline(pts, { color: col, weight: 4, opacity: 0.95 }).addTo(m)
        if (climb) {
          const near = (t: LatLon) => pts.reduce((b, q, j) => ((q[0] - t[0]) ** 2 + (q[1] - t[1]) ** 2 < (pts[b]![0] - t[0]) ** 2 + (pts[b]![1] - t[1]) ** 2 ? j : b), 0)
          const a = near(climb.foot), b = near(climb.top)
          L.polyline(pts.slice(Math.min(a, b), Math.max(a, b) + 1), { color: acc, weight: 6, opacity: 1 }).addTo(m).bindTooltip('klanec za intervale')
        }
        // smer vožnje in kilometri: puščica vsakih ~5 km, oznaka vsakih 10 km
        let d = 0, nextArrow = 2500, nextKm = 10000
        for (let i = 1; i < pts.length; i++) {
          const p0 = pts[i - 1]!, p1 = pts[i]!
          d += haversineM(p0, p1)
          if (d >= nextArrow) {
            const ang = Math.atan2((p1[1] - p0[1]) * Math.cos((p1[0] * Math.PI) / 180), p1[0] - p0[0]) * 180 / Math.PI
            L.marker(p1, { interactive: false, icon: L.divIcon({ className: 'route-arrow', html: `<span style="transform:rotate(${ang.toFixed(0)}deg)">▲</span>`, iconSize: [16, 16] }) }).addTo(m)
            nextArrow += 5000
          }
          if (d >= nextKm) {
            L.marker(p1, { interactive: false, icon: L.divIcon({ className: 'route-km', html: `${Math.round(nextKm / 1000)} km`, iconSize: [40, 18] }) }).addTo(m)
            nextKm += 10000
          }
        }
        L.circleMarker(pts[0]!, { radius: 8, color: '#fff', weight: 3, fillColor: '#16a34a', fillOpacity: 1 }).addTo(m).bindTooltip('start in cilj', { permanent: false })
        m.fitBounds(line.getBounds(), { padding: [18, 18] })
        // zavihek se odpira z animacijo — ko ima končno velikost, še enkrat preračunaj in poravnaj
        setTimeout(() => { if (!dead) { m.invalidateSize(); m.fitBounds(line.getBounds(), { padding: [18, 18] }) } }, 350)
      } catch (e) { if (!dead) setErr((e as Error)?.message || 'Zemljevida ni bilo mogoče naložiti.') }
    })()
    return () => { dead = true; map?.remove() }
  }, [open, poly, climb])
  return (
    <Sheet open={open} onClose={onClose}>
      <b style={{ fontSize: 16, letterSpacing: '-.02em' }}>{title}</b>
      <div ref={box} style={{ height: '62vh', minHeight: 320, borderRadius: 'var(--r-m)', overflow: 'hidden', marginTop: 10, background: 'var(--raised)' }} />
      {err && <p style={{ fontSize: 12, color: 'var(--bad)', marginTop: 8 }}>{err}</p>}
      <p className="muted" style={{ fontSize: 11.5, marginTop: 8 }}>Točno ta sled gre na uro. Puščice kažejo smer, zelena pika je start. Brez povezave se zemljevid ne naloži.</p>
      <Btn ghost block style={{ marginTop: 8 }} onClick={onClose}>Zapri</Btn>
    </Sheet>
  )
}
