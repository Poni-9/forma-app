import { useState } from 'react'
import { useApp, stateToday, setStateMode, undoStateToday, toast } from '@/state/store'
import { stateNow, painStreak, type StateMode } from '@/domain/training/state'
import { isHardDay } from '@/domain/training/plandays'
import { Card, Chip } from '@/ui/primitives'

const MODES: [StateMode, string][] = [['sprehod', 'Sprehod'], ['pocitek', 'Počitek'], ['vrtenje', 'Lahko vrtenje']]

/**
 * Načrt posluša jutranji vnos: ko noge zelo bolijo ali si na dnu, je danes drugače (in na dnu tudi jutri) — kartica pove,
 * kaj in zakaj, in pusti izbrati sprehod, počitek ali lahko vrtenje; »Vrni po načrtu« vrne prvotni dan.
 * Pri blagi utrujenosti (stopnja 1) in trdem dnevu samo nasvet, brez spremembe.
 */
export function StateCard() {
  const app = useApp()
  const [busy, setBusy] = useState(false)
  const now = stateNow(app.plan, app.today)
  const st = stateToday(app)
  // bolečina več dni zapored ni več »utrujenost« — zdravstveni nasvet ostane tudi po »Vrni po načrtu«
  const pain = painStreak(app.checkinToday ? [...app.checkins.filter(c => c.date !== app.today), app.checkinToday] : app.checkins, app.today)
  const painNote = pain >= 3 ? <p className="state-pain">Noge bolijo že {pain} dni zapored. Če bolečina ne pojenja ali je ostra (koleno, tetiva, sklep), se posvetuj z zdravnikom ali fizioterapevtom — do takrat brez obremenitve nog.</p> : null
  if (!now) {
    const prio = (d: { kind: string; optional?: boolean }) => (d.kind === 'pocitek' ? 9 : d.optional ? 5 : d.kind === 'moc' ? 2 : 0)
    const main = [...app.plan.filter(d => d.date === app.today)].sort((a, b) => prio(a) - prio(b))[0]
    if (st.level !== 1 || !main || main.done || !isHardDay(main) || main.role === 'dirka') return painNote ? <Card tight className="state-card">{painNote}</Card> : null
    return (
      <Card tight className="state-card mild">
        <h2 className="h4" style={{ fontSize: 11, margin: 0 }}>Po jutranjem vnosu</h2>
        <p style={{ fontSize: 12.5, marginTop: 4, color: 'var(--ink-2)' }}>{cap(st.reasons.join(', '))}: ogrevanje 15–20 min. Če noge ne odprejo, naredi pol intervalov ali samo Z2. Če je huje, v jutranjem vnosu izberi mišice »Zelo« ali »Boli« — načrt se prilagodi.</p>
      </Card>
    )
  }
  async function pick(m: StateMode) {
    if (busy || now?.mode === m) return
    setBusy(true); await setStateMode(m); setBusy(false)
  }
  return (
    <Card tight className="state-card">
      <div className="between" style={{ gap: 10, alignItems: 'baseline' }}>
        <h2 className="h4" style={{ fontSize: 11, margin: 0 }}>Prilagojeno počutju</h2>
        {st.reasons.length > 0 && <span className="muted" style={{ fontSize: 11.5, fontWeight: 700, textAlign: 'right' }}>{st.reasons.join(' · ')}</span>}
      </div>
      <ul className="state-lines">{now.lines.map(l => <li key={l}>{l}</li>)}</ul>
      {painNote}
      {now.mode && (
        <div className="row" role="group" aria-label="Kaj danes namesto treninga" style={{ gap: 6, marginTop: 10, flexWrap: 'wrap' }}>
          {MODES.map(([m, l]) => <Chip key={m} sm on={now.mode === m} onClick={() => void pick(m)}>{l}</Chip>)}
        </div>
      )}
      <div className="row" style={{ gap: 8, marginTop: 10, alignItems: 'center', flexWrap: 'wrap' }}>
        <button type="button" className="chip sm click" disabled={busy} onClick={async () => { setBusy(true); await undoStateToday(); setBusy(false); toast('Danes po prvotnem načrtu.', 'ok') }}>Vrni po načrtu</button>
        <span className="muted" style={{ fontSize: 11.5 }}>Jutri spet po jutranjem vnosu.</span>
      </div>
    </Card>
  )
}
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1)
