/**
 * Fotografije vaj: dve sliki (začetni in končni položaj) iz javne domene (free-exercise-db, Unlicense —
 * https://github.com/yuhonas/free-exercise-db), obrezane na 3 : 2, WebP v public/vaje. Prikaz v zanki (prehod med
 * položajema) deluje kot oseba, ki vajo izvaja. Kar nima fotografij, kaže vektorska figura (ExerciseFigure).
 */
export const PHOTO_IDS: ReadonlySet<string> = new Set(['bench','biceps-p','biceps-r','bolgarski','bradlja','deadbug','deska','dipi','dvig-nog','facepull','goblet','hip-p','hip-r','hiper','incline-r','izpadni','izpadni-r','kabel-v','kabel-zasuk','kolena-vis','kolesarcki','koraki-e','krozni','leg-curl','leg-ext','metuljcek','most','most1','mrtvi','nadglavo-r','negativni','odrocenje','ohp','pallof','plezalec','pocep','pocep-p','potisk-r','presa','prsti-n','pulldown','razteg-e','rdl-p','rdl-r','sklece','sklece-noge','stopanje-r','stranska','superman','triceps-k','triceps-r','valjcek','veslanje-p','veslanje-r','veslo','zamah','zasuki-r','zgibi'])
export const hasPhoto = (id: string | null | undefined): id is string => !!id && PHOTO_IDS.has(id)
export const photoUrl = (id: string, i: 0 | 1) => `${import.meta.env.BASE_URL}vaje/${id}-${i}.webp`
/** pokončne fotografije (prikaz brez obrezovanja) */
export const PORTRAIT: ReadonlySet<string> = new Set(['kabel-zasuk'])
