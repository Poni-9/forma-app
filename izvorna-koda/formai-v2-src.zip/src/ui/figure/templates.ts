import { FLOOR, type FrontPose, type SidePose } from './rig'

/** Oprema in rekviziti ob figuri (narisani glede na sklepe). */
export type Equip =
  | 'dumbbells' | 'dumbbell-near' | 'barbell-hands' | 'barbell-shoulders' | 'barbell-hips' | 'kettlebell' | 'goblet' | 'plate-chest'
  | 'bar' | 'cable-top' | 'cable-mid' | 'cable-low' | 'band-low' | 'band-mid' | 'band-front' | 'band-legs'
  | 'bench-flat' | 'bench-incline' | 'bench-back' | 'bench-support' | 'box-feet' | 'box-back' | 'box-front' | 'chair' | 'bars-dip'
  | 'legpress' | 'legext' | 'legcurl' | 'pecdeck' | 'hyper' | 'calf' | 'erg' | 'wheel' | 'rope' | 'bike' | 'nofloor'

export interface Frame<P> { at: number; p: Partial<P> }
export interface SideTemplate { rig: 'side'; dur: number; frames: Frame<SidePose>[]; equip: Equip[]; note?: string }
export interface FrontTemplate { rig: 'front'; dur: number; frames: Frame<FrontPose>[]; equip: Equip[]; note?: string }
export type Template = SideTemplate | FrontTemplate

const STAND_Y = FLOOR - 66
const side = (dur: number, equip: Equip[], frames: Frame<SidePose>[]): SideTemplate => ({ rig: 'side', dur, frames, equip })
const front = (dur: number, equip: Equip[], frames: Frame<FrontPose>[]): FrontTemplate => ({ rig: 'front', dur, frames, equip })
/** gor-dol z dvema pozama: 0 → 0.5 → 1 (nazaj na začetek) */
function upDown<P extends SidePose | FrontPose>(a: Partial<P>, b: Partial<P>, holdA = 0, holdB = 0): Frame<P>[] {
  return [{ at: 0, p: a }, { at: holdA, p: a }, { at: 0.5 - holdB / 2, p: b }, { at: 0.5 + holdB / 2, p: b }, { at: 1 - holdA, p: a }].filter((f, i, arr) => i === 0 || f.at > arr[i - 1]!.at)
}

/* ---------------- stranske poze: osnovne ---------------- */
const stand: Partial<SidePose> = { px: 96, py: STAND_Y, t: 0 }
/** leže na hrbtu (glava levo) */
const supine = (py = FLOOR - 9): Partial<SidePose> => ({ px: 104, py, t: -90, n: 0 })
/** opora na rokah (glava desno) */
const prone = (py: number): Partial<SidePose> => ({ px: 92, py, t: 90 })

/* ---------------- vaje ---------------- */
export const TEMPLATES: Record<string, Template> = {
  /* --- lastna teža --- */
  sklece: side(2600, [], upDown({ ...prone(122), sL: 90, sR: 90, eL: 0, eR: 0, aL: 90, aR: 90 }, { ...prone(133), sL: 42, sR: 42, eL: 48, eR: 48, aL: 90, aR: 90 }, 0.05, 0.08)),
  'sklece-kolena': side(2600, [], upDown({ ...prone(118), hL: -8, hR: -8, kL: 95, kR: 95, sL: 90, sR: 90, eL: 0, eR: 0, aL: 60, aR: 60 }, { ...prone(129), hL: -8, hR: -8, kL: 95, kR: 95, sL: 42, sR: 42, eL: 48, eR: 48, aL: 60, aR: 60 }, 0.05, 0.08)),
  'sklece-noge': side(2600, ['box-feet'], upDown({ ...prone(112), px: 98, t: 100, sL: 100, sR: 100, eL: 0, eR: 0, aL: 90, aR: 90 }, { ...prone(123), px: 98, t: 100, sL: 50, sR: 50, eL: 50, eR: 50, aL: 90, aR: 90 }, 0.05, 0.08)),
  pike: side(2800, [], upDown({ ...prone(96), px: 100, t: 150, hL: 95, hR: 95, sL: 165, sR: 165, eL: 0, eR: 0, n: -10 }, { ...prone(108), px: 100, t: 150, hL: 95, hR: 95, sL: 140, sR: 140, eL: 60, eR: 60, n: -10 }, 0.05, 0.08)),
  pocep: side(2800, [], upDown({ ...stand, sL: 85, sR: 85, eL: 0, eR: 0 }, { ...stand, py: STAND_Y + 28, t: 28, hL: 100, hR: 100, kL: 108, kR: 108, aL: 20, aR: 20, sL: 95, sR: 95, eL: 0, eR: 0, n: -14 }, 0.05, 0.1)),
  izpadni: side(2800, [], upDown({ ...stand, hL: 20, hR: -8, kL: 25, kR: 10, sL: 20, sR: 20, eL: 70, eR: 70 }, { ...stand, py: STAND_Y + 22, hL: 75, hR: -28, kL: 92, kR: 85, aL: 0, aR: 70, sL: 20, sR: 20, eL: 70, eR: 70 }, 0.05, 0.1)),
  bolgarski: side(2800, ['box-back'], upDown({ ...stand, px: 88, hL: 25, hR: -35, kL: 25, kR: 95, aR: 90, sL: 20, sR: 20, eL: 70, eR: 70 }, { ...stand, px: 88, py: STAND_Y + 22, hL: 78, hR: -40, kL: 92, kR: 110, aL: 0, aR: 90, sL: 20, sR: 20, eL: 70, eR: 70, t: 10 }, 0.05, 0.1)),
  most: side(2600, [], upDown({ ...supine(FLOOR - 10), hL: 58, hR: 58, kL: 100, kR: 100, sL: 5, sR: 5 }, { ...supine(FLOOR - 32), t: -72, hL: 20, hR: 20, kL: 100, kR: 100, sL: 10, sR: 10 }, 0.05, 0.12)),
  most1: side(2800, [], upDown({ ...supine(FLOOR - 10), hL: 58, hR: 95, kL: 100, kR: 10, sL: 5, sR: 5 }, { ...supine(FLOOR - 32), t: -72, hL: 20, hR: 60, kL: 100, kR: 5, sL: 10, sR: 10 }, 0.05, 0.12)),
  deska: side(3600, [], upDown({ ...prone(124), sL: 95, sR: 95, eL: 95, eR: 95, aL: 90, aR: 90 }, { ...prone(125), sL: 95, sR: 95, eL: 95, eR: 95, aL: 90, aR: 90 })),
  stranska: front(3600, [], upDown({ px: 112, py: FLOOR - 30, lean: 76, abL: 110, abR: 170, eL: 95, eR: 0, wL: 4, wR: 4 }, { px: 112, py: FLOOR - 32, lean: 78, abL: 110, abR: 170, eL: 95, eR: 0, wL: 4, wR: 4 })),
  deadbug: side(3200, [], [
    { at: 0, p: { ...supine(), hL: 90, hR: 90, kL: 90, kR: 90, sL: 90, sR: 90 } },
    { at: 0.5, p: { ...supine(), hL: 20, hR: 90, kL: 10, kR: 90, sL: 90, sR: 170 } },
    { at: 1, p: { ...supine(), hL: 90, hR: 90, kL: 90, kR: 90, sL: 90, sR: 90 } },
  ]),
  'dvig-nog': side(3000, [], upDown({ ...supine(), hL: 8, hR: 8, kL: 0, kR: 0, sL: 0, sR: 0 }, { ...supine(), hL: 88, hR: 88, kL: 0, kR: 0, sL: 0, sR: 0 }, 0.05, 0.08)),
  kolesarcki: side(2400, [], [
    { at: 0, p: { ...supine(), t: -78, hL: 95, hR: 25, kL: 110, kR: 10, sL: 150, sR: 150, eL: 120, eR: 120, n: 25 } },
    { at: 0.5, p: { ...supine(), t: -78, hL: 25, hR: 95, kL: 10, kR: 110, sL: 150, sR: 150, eL: 120, eR: 120, n: 25 } },
    { at: 1, p: { ...supine(), t: -78, hL: 95, hR: 25, kL: 110, kR: 10, sL: 150, sR: 150, eL: 120, eR: 120, n: 25 } },
  ]),
  plezalec: side(1400, [], [
    { at: 0, p: { ...prone(120), sL: 90, sR: 90, eL: 0, eR: 0, hL: 0, hR: 85, kL: 0, kR: 110, aL: 90, aR: 60 } },
    { at: 0.5, p: { ...prone(120), sL: 90, sR: 90, eL: 0, eR: 0, hL: 85, hR: 0, kL: 110, kR: 0, aL: 60, aR: 90 } },
    { at: 1, p: { ...prone(120), sL: 90, sR: 90, eL: 0, eR: 0, hL: 0, hR: 85, kL: 0, kR: 110, aL: 90, aR: 60 } },
  ]),
  coln: side(3600, [], upDown({ ...supine(FLOOR - 14), t: -62, hL: 32, hR: 32, kL: 0, kR: 0, sL: 165, sR: 165, n: 20 }, { ...supine(FLOOR - 14), t: -60, hL: 30, hR: 30, kL: 0, kR: 0, sL: 165, sR: 165, n: 20 })),
  superman: side(3000, [], upDown({ ...prone(FLOOR - 8), px: 100, t: 90, sL: 170, sR: 170, hL: 0, hR: 0, aL: 40, aR: 40, n: -10 }, { ...prone(FLOOR - 12), px: 100, t: 78, sL: 180, sR: 180, hL: -22, hR: -22, aL: 40, aR: 40, n: -20 }, 0.05, 0.15)),
  dipi: side(2600, ['chair'], upDown({ px: 96, py: FLOOR - 40, t: -8, hL: 80, hR: 80, kL: 20, kR: 20, sL: -40, sR: -40, eL: 0, eR: 0 }, { px: 96, py: FLOOR - 26, t: -8, hL: 90, hR: 90, kL: 30, kR: 30, sL: -75, sR: -75, eL: 95, eR: 95 }, 0.05, 0.08)),
  prsti: side(2200, [], upDown({ ...stand, sL: 8, sR: 8 }, { ...stand, py: STAND_Y - 7, aL: 35, aR: 35, sL: 8, sR: 8 }, 0.05, 0.15)),
  burpee: side(3200, [], [
    { at: 0, p: { ...stand, sL: 10, sR: 10 } },
    { at: 0.22, p: { ...stand, py: STAND_Y + 30, t: 40, hL: 110, hR: 110, kL: 120, kR: 120, aL: 20, aR: 20, sL: 110, sR: 110, eL: 0, eR: 0, n: -20 } },
    { at: 0.48, p: { ...prone(122), sL: 90, sR: 90, eL: 0, eR: 0, aL: 90, aR: 90 } },
    { at: 0.72, p: { ...stand, py: STAND_Y + 30, t: 40, hL: 110, hR: 110, kL: 120, kR: 120, aL: 20, aR: 20, sL: 110, sR: 110, eL: 0, eR: 0, n: -20 } },
    { at: 0.9, p: { ...stand, py: STAND_Y - 24, sL: 175, sR: 175, aL: 40, aR: 40 } },
    { at: 1, p: { ...stand, sL: 10, sR: 10 } },
  ]),
  krozni: side(700, ['rope'], [
    { at: 0, p: { ...stand, sL: 12, sR: 12, eL: 70, eR: 70, kL: 8, kR: 8 } },
    { at: 0.5, p: { ...stand, py: STAND_Y - 12, sL: 14, sR: 14, eL: 76, eR: 76, aL: 35, aR: 35, kL: 4, kR: 4 } },
    { at: 1, p: { ...stand, sL: 12, sR: 12, eL: 70, eR: 70, kL: 8, kR: 8 } },
  ]),
  /* --- drog --- */
  zgibi: side(3000, ['bar', 'nofloor'], upDown<SidePose>({ px: 100, py: 118, t: 0, sL: 178, sR: 178, eL: 0, eR: 0, kL: 55, kR: 55, hL: 8, hR: 8, aL: 30, aR: 30 }, { px: 100, py: 92, t: 0, sL: 125, sR: 125, eL: 125, eR: 125, kL: 60, kR: 60, hL: 10, hR: 10, aL: 30, aR: 30, n: -12 }, 0.08, 0.1)),
  negativni: side(4000, ['bar', 'nofloor'], [
    { at: 0, p: { px: 100, py: 92, t: 0, sL: 125, sR: 125, eL: 125, eR: 125, kL: 60, kR: 60, hL: 10, hR: 10, aL: 30, aR: 30, n: -12 } },
    { at: 0.08, p: { px: 100, py: 92, t: 0, sL: 125, sR: 125, eL: 125, eR: 125, kL: 60, kR: 60, hL: 10, hR: 10, aL: 30, aR: 30, n: -12 } },
    { at: 0.8, p: { px: 100, py: 118, t: 0, sL: 178, sR: 178, eL: 0, eR: 0, kL: 55, kR: 55, hL: 8, hR: 8, aL: 30, aR: 30 } },
    { at: 1, p: { px: 100, py: 92, t: 0, sL: 125, sR: 125, eL: 125, eR: 125, kL: 60, kR: 60, hL: 10, hR: 10, aL: 30, aR: 30, n: -12 } },
  ]),
  'kolena-vis': side(2800, ['bar', 'nofloor'], upDown({ px: 100, py: 118, t: 0, sL: 178, sR: 178, hL: 5, hR: 5, kL: 10, kR: 10, aL: 30, aR: 30 }, { px: 100, py: 118, t: -6, sL: 176, sR: 176, hL: 100, hR: 100, kL: 100, kR: 100, aL: 30, aR: 30 }, 0.05, 0.1)),
  /* --- ročke --- */
  goblet: side(2800, ['goblet'], upDown({ ...stand, sL: 40, sR: 40, eL: 125, eR: 125 }, { ...stand, py: STAND_Y + 28, t: 24, hL: 100, hR: 100, kL: 108, kR: 108, aL: 20, aR: 20, sL: 45, sR: 45, eL: 125, eR: 125, n: -12 }, 0.05, 0.1)),
  'rdl-r': side(3000, ['dumbbells'], upDown({ ...stand, sL: 4, sR: 4 }, { ...stand, py: STAND_Y + 4, t: 70, hL: 85, hR: 85, kL: 18, kR: 18, aL: 0, aR: 0, sL: -2, sR: -2, n: -35 }, 0.05, 0.1)),
  'potisk-r': side(2600, ['bench-flat', 'dumbbells'], upDown({ ...supine(FLOOR - 36), px: 98, hL: 70, hR: 70, kL: 95, kR: 95, sL: 92, sR: 92, eL: 0, eR: 0 }, { ...supine(FLOOR - 36), px: 98, hL: 70, hR: 70, kL: 95, kR: 95, sL: 40, sR: 40, eL: 95, eR: 95 }, 0.05, 0.08)),
  'veslanje-r': side(2600, ['bench-support', 'dumbbell-near'], upDown({ px: 86, py: STAND_Y + 6, t: 72, hL: 80, hR: 100, kL: 16, kR: 100, aR: 90, sR: 80, sL: 6, eR: 0, eL: 0, n: -30 }, { px: 86, py: STAND_Y + 6, t: 72, hL: 80, hR: 100, kL: 16, kR: 100, aR: 90, sR: 80, sL: -30, eR: 0, eL: 115, n: -30 }, 0.05, 0.1)),
  'nadglavo-r': side(2600, ['dumbbells'], upDown({ ...stand, sL: 150, sR: 150, eL: 110, eR: 110 }, { ...stand, sL: 178, sR: 178, eL: 2, eR: 2 }, 0.05, 0.08)),
  odrocenje: front(2600, ['dumbbells'], upDown({ abL: 12, abR: 12, eL: 10, eR: 10 }, { abL: 92, abR: 92, eL: 10, eR: 10 }, 0.05, 0.1)),
  'biceps-r': side(2400, ['dumbbells'], upDown({ ...stand, sL: 6, sR: 6, eL: 10, eR: 10 }, { ...stand, sL: 12, sR: 12, eL: 140, eR: 140 }, 0.05, 0.1)),
  'triceps-r': side(2400, ['dumbbell-near'], upDown({ ...stand, sL: 176, sR: 176, eL: 4, eR: 4 }, { ...stand, sL: 176, sR: 176, eL: 125, eR: 125, n: 8 }, 0.05, 0.08)),
  'izpadni-r': side(2800, ['dumbbells'], upDown({ ...stand, hL: 20, hR: -8, kL: 25, kR: 10, sL: 4, sR: 4 }, { ...stand, py: STAND_Y + 22, hL: 75, hR: -28, kL: 92, kR: 85, aL: 0, aR: 70, sL: 4, sR: 4 }, 0.05, 0.1)),
  'stopanje-r': side(2800, ['box-front', 'dumbbells'], [
    { at: 0, p: { ...stand, px: 84, hL: 70, hR: 0, kL: 90, kR: 0, sL: 4, sR: 4 } },
    { at: 0.5, p: { ...stand, px: 104, py: STAND_Y - 30, hL: 5, hR: 40, kL: 5, kR: 70, aR: 30, sL: 4, sR: 4 } },
    { at: 0.62, p: { ...stand, px: 104, py: STAND_Y - 30, hL: 5, hR: 40, kL: 5, kR: 70, aR: 30, sL: 4, sR: 4 } },
    { at: 1, p: { ...stand, px: 84, hL: 70, hR: 0, kL: 90, kR: 0, sL: 4, sR: 4 } },
  ]),
  'hip-r': side(2600, ['bench-back', 'barbell-hips'], upDown({ px: 104, py: FLOOR - 16, t: -62, hL: 70, hR: 70, kL: 100, kR: 100, sL: 20, sR: 20, eL: 110, eR: 110, n: 25 }, { px: 104, py: FLOOR - 38, t: -82, hL: 12, hR: 12, kL: 100, kR: 100, sL: 20, sR: 20, eL: 110, eR: 110, n: 30 }, 0.05, 0.12)),
  'zasuki-r': front(2000, ['nofloor', 'plate-chest'], [
    { at: 0, p: { px: 100, py: 128, lean: -18, abL: 60, abR: 60, eL: 60, eR: 60, wL: 14, wR: 14, kL: 120, kR: 120, tw: -14 } },
    { at: 0.5, p: { px: 100, py: 128, lean: -18, abL: 60, abR: 60, eL: 60, eR: 60, wL: 14, wR: 14, kL: 120, kR: 120, tw: 14 } },
    { at: 1, p: { px: 100, py: 128, lean: -18, abL: 60, abR: 60, eL: 60, eR: 60, wL: 14, wR: 14, kL: 120, kR: 120, tw: -14 } },
  ]),
  zamah: side(1800, ['kettlebell'], upDown({ ...stand, px: 92, t: 55, hL: 70, hR: 70, kL: 25, kR: 25, sL: -25, sR: -25, py: STAND_Y + 4, n: -25 }, { ...stand, px: 92, t: -2, sL: 95, sR: 95, eL: 0, eR: 0 }, 0.04, 0.06)),
  /* --- elastike --- */
  'veslanje-e': side(2400, ['band-mid'], upDown({ px: 96, py: FLOOR - 44, t: -4, hL: 95, hR: 95, kL: 8, kR: 8, sL: 88, sR: 88, eL: 0, eR: 0 }, { px: 96, py: FLOOR - 44, t: -8, hL: 95, hR: 95, kL: 8, kR: 8, sL: 50, sR: 50, eL: 115, eR: 115 }, 0.05, 0.1)),
  'razteg-e': front(2400, ['band-front'], upDown<FrontPose>({ abL: 88, abR: 88, eL: 0, eR: 0, lean: 0 }, { abL: 96, abR: 96, eL: 0, eR: 0, lean: 0, tw: 0 }, 0.05, 0.1)),
  'biceps-e': side(2400, ['band-low'], upDown({ ...stand, sL: 6, sR: 6, eL: 10, eR: 10 }, { ...stand, sL: 12, sR: 12, eL: 140, eR: 140 }, 0.05, 0.1)),
  pallof: front(2600, ['band-mid'], upDown({ abL: 20, abR: 20, eL: 150, eR: 150, wL: 14, wR: 14, kL: 20, kR: 20 }, { abL: 40, abR: 40, eL: 10, eR: 10, wL: 14, wR: 14, kL: 20, kR: 20 }, 0.08, 0.2)),
  'koraki-e': front(1600, ['band-legs'], [
    { at: 0, p: { wL: 10, wR: 10, kL: 40, kR: 40, abL: 25, abR: 25, eL: 90, eR: 90, lean: 6 } },
    { at: 0.5, p: { wL: 10, wR: 32, kL: 40, kR: 40, abL: 25, abR: 25, eL: 90, eR: 90, lean: 6 } },
    { at: 1, p: { wL: 10, wR: 10, kL: 40, kR: 40, abL: 25, abR: 25, eL: 90, eR: 90, lean: 6 } },
  ]),
  /* --- fitnes --- */
  'pocep-p': side(3000, ['barbell-shoulders'], upDown({ ...stand, sL: 60, sR: 60, eL: 120, eR: 120 }, { ...stand, py: STAND_Y + 28, t: 26, hL: 100, hR: 100, kL: 108, kR: 108, aL: 20, aR: 20, sL: 60, sR: 60, eL: 120, eR: 120, n: -12 }, 0.05, 0.1)),
  presa: side(2800, ['legpress'], upDown({ px: 70, py: FLOOR - 40, t: -50, hL: 70, hR: 70, kL: 20, kR: 20, sL: -10, sR: -10, eL: 60, eR: 60, aL: 10, aR: 10 }, { px: 70, py: FLOOR - 40, t: -50, hL: 115, hR: 115, kL: 105, kR: 105, sL: -10, sR: -10, eL: 60, eR: 60, aL: 10, aR: 10 }, 0.05, 0.08)),
  mrtvi: side(3200, ['barbell-hands'], upDown({ ...stand, px: 92, py: STAND_Y + 14, t: 48, hL: 95, hR: 95, kL: 70, kR: 70, aL: 0, aR: 0, sL: -6, sR: -6, n: -30 }, { ...stand, px: 92, sL: 2, sR: 2 }, 0.06, 0.08)),
  'rdl-p': side(3000, ['barbell-hands'], upDown({ ...stand, sL: 4, sR: 4 }, { ...stand, py: STAND_Y + 4, t: 70, hL: 85, hR: 85, kL: 18, kR: 18, aL: 0, aR: 0, sL: -2, sR: -2, n: -35 }, 0.05, 0.1)),
  bench: side(2800, ['bench-flat', 'barbell-hands'], upDown({ ...supine(FLOOR - 36), px: 98, hL: 70, hR: 70, kL: 95, kR: 95, sL: 92, sR: 92, eL: 0, eR: 0 }, { ...supine(FLOOR - 36), px: 98, hL: 70, hR: 70, kL: 95, kR: 95, sL: 38, sR: 38, eL: 95, eR: 95 }, 0.05, 0.08)),
  'incline-r': side(2800, ['bench-incline', 'dumbbells'], upDown({ px: 98, py: FLOOR - 32, t: -50, hL: 85, hR: 85, kL: 85, kR: 85, sL: 92, sR: 92, eL: 0, eR: 0 }, { px: 98, py: FLOOR - 32, t: -50, hL: 85, hR: 85, kL: 85, kR: 85, sL: 40, sR: 40, eL: 95, eR: 95 }, 0.05, 0.08)),
  metuljcek: front(2600, ['pecdeck'], upDown({ py: 128, abL: 92, abR: 92, eL: 85, eR: 85, wL: 14, wR: 14, kL: 120, kR: 120 }, { py: 128, abL: 18, abR: 18, eL: 85, eR: 85, wL: 14, wR: 14, kL: 120, kR: 120 }, 0.05, 0.12)),
  pulldown: side(2600, ['cable-top'], upDown({ px: 96, py: FLOOR - 44, t: -6, hL: 95, hR: 95, kL: 95, kR: 95, sL: 165, sR: 165, eL: 0, eR: 0, n: -8 }, { px: 96, py: FLOOR - 44, t: -14, hL: 95, hR: 95, kL: 95, kR: 95, sL: 110, sR: 110, eL: 115, eR: 115, n: -8 }, 0.05, 0.1)),
  'kabel-v': side(2600, ['cable-mid'], upDown({ px: 92, py: FLOOR - 44, t: 2, hL: 95, hR: 95, kL: 12, kR: 12, sL: 88, sR: 88, eL: 0, eR: 0 }, { px: 92, py: FLOOR - 44, t: -8, hL: 95, hR: 95, kL: 12, kR: 12, sL: 45, sR: 45, eL: 120, eR: 120 }, 0.05, 0.1)),
  'veslanje-p': side(2600, ['barbell-hands'], upDown({ ...stand, px: 92, py: STAND_Y + 4, t: 62, hL: 78, hR: 78, kL: 22, kR: 22, aL: 0, aR: 0, sL: 10, sR: 10, eL: 0, eR: 0, n: -30 }, { ...stand, px: 92, py: STAND_Y + 4, t: 62, hL: 78, hR: 78, kL: 22, kR: 22, aL: 0, aR: 0, sL: -30, sR: -30, eL: 105, eR: 105, n: -30 }, 0.05, 0.1)),
  ohp: side(2600, ['barbell-hands'], upDown({ ...stand, sL: 125, sR: 125, eL: 125, eR: 125 }, { ...stand, sL: 178, sR: 178, eL: 2, eR: 2, n: -6 }, 0.05, 0.08)),
  facepull: side(2400, ['cable-top'], upDown({ ...stand, px: 88, t: 4, sL: 100, sR: 100, eL: 0, eR: 0 }, { ...stand, px: 88, t: 4, sL: 95, sR: 95, eL: 125, eR: 125 }, 0.05, 0.1)),
  'triceps-k': side(2200, ['cable-top'], upDown({ ...stand, px: 88, t: 6, sL: 15, sR: 15, eL: 120, eR: 120 }, { ...stand, px: 88, t: 6, sL: 12, sR: 12, eL: 8, eR: 8 }, 0.05, 0.1)),
  'biceps-p': side(2400, ['barbell-hands'], upDown({ ...stand, sL: 6, sR: 6, eL: 10, eR: 10 }, { ...stand, sL: 14, sR: 14, eL: 140, eR: 140 }, 0.05, 0.1)),
  'leg-curl': side(2400, ['legcurl'], upDown({ px: 96, py: FLOOR - 36, t: 92, hL: -4, hR: -4, kL: 5, kR: 5, sL: 100, sR: 100, eL: 90, eR: 90, aL: 20, aR: 20 }, { px: 96, py: FLOOR - 36, t: 92, hL: -4, hR: -4, kL: 115, kR: 115, sL: 100, sR: 100, eL: 90, eR: 90, aL: 20, aR: 20 }, 0.05, 0.1)),
  'leg-ext': side(2400, ['legext'], upDown({ px: 92, py: FLOOR - 46, t: -8, hL: 95, hR: 95, kL: 95, kR: 95, sL: -20, sR: -20, eL: 30, eR: 30, aL: 10, aR: 10 }, { px: 92, py: FLOOR - 46, t: -8, hL: 95, hR: 95, kL: 5, kR: 5, sL: -20, sR: -20, eL: 30, eR: 30, aL: 10, aR: 10 }, 0.05, 0.12)),
  'hip-p': side(2600, ['bench-back', 'barbell-hips'], upDown({ px: 104, py: FLOOR - 16, t: -62, hL: 70, hR: 70, kL: 100, kR: 100, sL: 20, sR: 20, eL: 110, eR: 110, n: 25 }, { px: 104, py: FLOOR - 38, t: -82, hL: 12, hR: 12, kL: 100, kR: 100, sL: 20, sR: 20, eL: 110, eR: 110, n: 30 }, 0.05, 0.12)),
  'prsti-n': side(2200, ['calf', 'barbell-shoulders'], upDown({ ...stand, sL: 60, sR: 60, eL: 120, eR: 120 }, { ...stand, py: STAND_Y - 8, aL: 38, aR: 38, sL: 60, sR: 60, eL: 120, eR: 120 }, 0.05, 0.15)),
  'kabel-zasuk': front(2200, ['cable-mid'], [
    { at: 0, p: { abL: 70, abR: 70, eL: 20, eR: 20, wL: 16, wR: 16, kL: 25, kR: 25, tw: -16, lean: -4 } },
    { at: 0.5, p: { abL: 70, abR: 70, eL: 20, eR: 20, wL: 16, wR: 16, kL: 25, kR: 25, tw: 16, lean: 4 } },
    { at: 1, p: { abL: 70, abR: 70, eL: 20, eR: 20, wL: 16, wR: 16, kL: 25, kR: 25, tw: -16, lean: -4 } },
  ]),
  bradlja: side(2800, ['bars-dip', 'nofloor'], upDown({ px: 100, py: 104, t: 0, sL: -15, sR: -15, eL: 0, eR: 0, hL: 6, hR: 6, kL: 10, kR: 10, aL: 30, aR: 30 }, { px: 100, py: 104, t: -5, sL: -15, sR: -15, eL: 0, eR: 0, hL: 100, hR: 100, kL: 100, kR: 100, aL: 30, aR: 30 }, 0.05, 0.1)),
  valjcek: side(3000, ['wheel'], upDown({ px: 92, py: FLOOR - 34, t: 20, hL: 70, hR: 70, kL: 100, kR: 100, aL: 90, aR: 90, sL: 100, sR: 100, eL: 0, eR: 0, n: -10 }, { px: 106, py: FLOOR - 22, t: 70, hL: 20, hR: 20, kL: 100, kR: 100, aL: 90, aR: 90, sL: 165, sR: 165, eL: 0, eR: 0, n: -20 }, 0.05, 0.1)),
  hiper: side(2800, ['hyper'], upDown({ px: 92, py: FLOOR - 50, t: 88, hL: 0, hR: 0, kL: 0, kR: 0, sL: 30, sR: 30, eL: 120, eR: 120, n: -10 }, { px: 92, py: FLOOR - 50, t: 88, hL: 70, hR: 70, kL: 0, kR: 0, sL: 30, sR: 30, eL: 120, eR: 120, n: -30 }, 0.05, 0.1)),
  veslo: side(2400, ['erg'], [
    { at: 0, p: { px: 118, py: FLOOR - 36, t: 20, hL: 120, hR: 120, kL: 125, kR: 125, aL: 20, aR: 20, sL: 95, sR: 95, eL: 0, eR: 0, n: -5 } },
    { at: 0.45, p: { px: 90, py: FLOOR - 36, t: -14, hL: 100, hR: 100, kL: 8, kR: 8, aL: 10, aR: 10, sL: 20, sR: 20, eL: 120, eR: 120 } },
    { at: 0.6, p: { px: 90, py: FLOOR - 36, t: -14, hL: 100, hR: 100, kL: 8, kR: 8, aL: 10, aR: 10, sL: 20, sR: 20, eL: 120, eR: 120 } },
    { at: 1, p: { px: 118, py: FLOOR - 36, t: 20, hL: 120, hR: 120, kL: 125, kR: 125, aL: 20, aR: 20, sL: 95, sR: 95, eL: 0, eR: 0, n: -5 } },
  ]),
  /* --- kardio in počitek --- */
  tek: side(760, [], [
    { at: 0, p: { ...stand, py: STAND_Y - 4, t: 6, hL: 55, hR: -20, kL: 40, kR: 85, aL: 10, aR: 40, sL: 45, sR: -35, eL: 90, eR: 90 } },
    { at: 0.5, p: { ...stand, py: STAND_Y - 4, t: 6, hL: -20, hR: 55, kL: 85, kR: 40, aL: 40, aR: 10, sL: -35, sR: 45, eL: 90, eR: 90 } },
    { at: 1, p: { ...stand, py: STAND_Y - 4, t: 6, hL: 55, hR: -20, kL: 40, kR: 85, aL: 10, aR: 40, sL: 45, sR: -35, eL: 90, eR: 90 } },
  ]),
  hoja: side(1200, [], [
    { at: 0, p: { ...stand, hL: 28, hR: -18, kL: 8, kR: 30, aL: 0, aR: 25, sL: 22, sR: -22, eL: 15, eR: 15 } },
    { at: 0.5, p: { ...stand, hL: -18, hR: 28, kL: 30, kR: 8, aL: 25, aR: 0, sL: -22, sR: 22, eL: 15, eR: 15 } },
    { at: 1, p: { ...stand, hL: 28, hR: -18, kL: 8, kR: 30, aL: 0, aR: 25, sL: 22, sR: -22, eL: 15, eR: 15 } },
  ]),
  kolo: side(900, ['bike'], [
    { at: 0, p: { px: 108, py: 96, t: 42, hL: 100, hR: 40, kL: 95, kR: 25, aL: 10, aR: 30, sL: 60, sR: 60, eL: 20, eR: 20, n: -30 } },
    { at: 0.5, p: { px: 108, py: 96, t: 42, hL: 40, hR: 100, kL: 25, kR: 95, aL: 30, aR: 10, sL: 60, sR: 60, eL: 20, eR: 20, n: -30 } },
    { at: 1, p: { px: 108, py: 96, t: 42, hL: 100, hR: 40, kL: 95, kR: 25, aL: 10, aR: 30, sL: 60, sR: 60, eL: 20, eR: 20, n: -30 } },
  ]),
  /** počitek: stoji, diha, roke sproščene (ramena se dvignejo z vdihom) */
  pavza: side(4000, [], upDown({ ...stand, sL: 6, sR: 6, eL: 8, eR: 8, kL: 3, kR: 3 }, { ...stand, py: STAND_Y - 2, sL: 10, sR: 10, eL: 12, eR: 12, n: -4 })),
}

/** vaje, ki nimajo svoje predloge, uporabijo najbližjo po vzorcu */
export function templateFor(id: string | null | undefined, fallback: 'pavza' | 'tek' | 'kolo' | 'hoja' = 'pavza'): Template {
  return (id && TEMPLATES[id]) || TEMPLATES[fallback]!
}
