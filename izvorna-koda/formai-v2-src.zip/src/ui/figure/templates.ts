import { FLOOR, L, SIDE0, sideFk, type FrontPose, type SidePose, type Pt } from './rig'

/** Oprema in rekviziti ob figuri (narisani glede na sklepe). */
export type Equip =
  | 'dumbbells' | 'dumbbell-near' | 'barbell-hands' | 'barbell-shoulders' | 'barbell-hips' | 'kettlebell' | 'goblet' | 'plate-chest'
  | 'bar' | 'cable-top' | 'cable-mid' | 'cable-low' | 'band-low' | 'band-mid' | 'band-front' | 'band-legs'
  | 'bench-flat' | 'bench-incline' | 'bench-back' | 'bench-support' | 'box-feet' | 'box-back' | 'box-front' | 'chair' | 'bars-dip'
  | 'legpress' | 'legext' | 'legcurl' | 'pecdeck' | 'hyper' | 'calf' | 'erg' | 'wheel' | 'rope' | 'bike' | 'nofloor'

export interface Frame<P> { at: number; p: Partial<P> }
export interface SideTemplate { rig: 'side'; dur: number; frames: Frame<SidePose>[]; equip: Equip[]; note?: string; /** ciklično gibanje iz biomehanike (tek, hoja, kolo) — poza ob fazi 0–1 */ gen?: (u: number) => SidePose }
export interface FrontTemplate { rig: 'front'; dur: number; frames: Frame<FrontPose>[]; equip: Equip[]; note?: string }
export type Template = SideTemplate | FrontTemplate

const STAND_Y = FLOOR - 66
const side = (dur: number, equip: Equip[], frames: Frame<SidePose>[]): SideTemplate => ({ rig: 'side', dur, frames, equip })
const front = (dur: number, equip: Equip[], frames: Frame<FrontPose>[]): FrontTemplate => ({ rig: 'front', dur, frames, equip })
/** gor-dol z dvema pozama: 0 → 0.5 → 1 (nazaj na začetek) */
function upDown<P extends SidePose | FrontPose>(a: Partial<P>, b: Partial<P>, holdA = 0, holdB = 0): Frame<P>[] {
  return [{ at: 0, p: a }, { at: holdA, p: a }, { at: 0.5 - holdB / 2, p: b }, { at: 0.5 + holdB / 2, p: b }, { at: 1 - holdA, p: a }].filter((f, i, arr) => i === 0 || f.at > arr[i - 1]!.at)
}

/* ---------------- naravno ciklično gibanje (tek, hoja, kolo) ----------------
 * Blaž, 14. 10.: »stričko naj se bolj naravno premika, zdaj je nerealno«. Prej sta bili pri teku, hoji in kolesu
 * samo dve pozi s premorom na koncu (nihalo). Zdaj: koti kolka, kolena in gležnja po fazi koraka (krivulje iz
 * biomehanike hoje in teka: dva vrha kolena — majhen ob doskoku, velik med zamahom), stopalo na tleh določa višino
 * medenice (pri hoji se zibje, pri teku je faza leta), roke nihajo nasprotno nogam. Kolo: stopala krožijo s
 * pedali (inverzna kinematika noge od sedeža do pedala), gleženj »pedalira«, trup se rahlo ziblje.
 */
const TAU = Math.PI * 2
const DEG = 180 / Math.PI
/** periodična zvonasta krivulja okrog c (širina w) na krogu faze 0–1 */
const bump = (x: number, c: number, w: number) => { const d = Math.abs(((x - c) % 1 + 1.5) % 1 - 0.5); return Math.exp(-(d * d) / (2 * w * w)) }
const wrap = (x: number) => ((x % 1) + 1) % 1
/** najnižja točka stopala (gleženj ali prsti) pri dani pozi */
const footLow = (p: SidePose, side: 'L' | 'R') => { const s = sideFk(p); return side === 'L' ? Math.max(s.ankleL.y, s.toeL.y) : Math.max(s.ankleR.y, s.toeR.y) }

interface Gait { hip: (f: number) => number; knee: (f: number) => number; ankle: (f: number) => number; arm: (f: number) => number; elbow: (f: number) => number; stance: number; flight: number; t: number; n: number; px: number }
/** višina medenice čez korak: iz stika s tlemi, nato zglajena (brez sunkov ob doskoku) — izračun enkrat na hod */
const PY_N = 240
const pyTables = new Map<Gait, number[]>()
function pyAt(g: Gait, u: number): number {
  let tab = pyTables.get(g)
  if (!tab) {
    const raw = Array.from({ length: PY_N }, (_, i) => gaitPoseRaw(g, i / PY_N).py)
    const sig = 0.035 * PY_N, R = Math.ceil(sig * 3)
    tab = raw.map((_, i) => { let a = 0, w = 0; for (let d = -R; d <= R; d++) { const k = Math.exp(-(d * d) / (2 * sig * sig)); a += raw[(i + d + PY_N) % PY_N]! * k; w += k } return a / w })
    pyTables.set(g, tab)
  }
  const x = wrap(u) * PY_N, i = Math.floor(x), f = x - i
  return tab[i % PY_N]! * (1 - f) + tab[(i + 1) % PY_N]! * f
}
function gaitPose(g: Gait, u: number): SidePose {
  return { ...gaitPose0(g, u), py: pyAt(g, u) }
}
function gaitPoseRaw(g: Gait, u: number): SidePose {
  const fL = wrap(u), fR = wrap(u + 0.5)
  const base: SidePose = { ...SIDE0, px: g.px, py: 0, t: g.t, n: g.n,
    hL: g.hip(fL), hR: g.hip(fR), kL: g.knee(fL), kR: g.knee(fR), aL: g.ankle(fL), aR: g.ankle(fR),
    sL: g.arm(fL), sR: g.arm(fR), eL: g.elbow(fL), eR: g.elbow(fR) }
  // medenica: stopalo, ki stoji, je na tleh (pri hoji vedno vsaj eno; pri teku vmes faza leta)
  const pinAt = (x: number): number => {
    const q = gaitPose0(g, x)
    // stopalo v opori je na tleh; noga v zamahu se tal sme komaj dotakniti (prsti ob odrivu), ne dviguje medenice
    const inL = wrap(x) < g.stance, inR = wrap(x + 0.5) < g.stance
    const lL = footLow(q, 'L'), lR = footLow(q, 'R')
    const low = Math.max(inL ? lL : lL - 2.5, inR ? lR : lR - 2.5, inL || inR ? -Infinity : Math.max(lL, lR))
    return FLOOR - low
  }
  const inAny = fL < g.stance || fR < g.stance
  if (inAny || g.flight <= 0) return { ...base, py: pinAt(u) }
  // faza leta: med koncem opore ene noge in doskokom druge — gladko med obema višinama + rahel dvig
  const start = fL >= g.stance && fL < 0.5 ? g.stance : 0.5 + g.stance
  const end = start === g.stance ? 0.5 : 1
  const k = (wrap(u) - start) / (end - start)
  const y = pinAt(start - 1e-4) + (pinAt(end) - pinAt(start - 1e-4)) * k - g.flight * Math.sin(Math.PI * k)
  return { ...base, py: y }
}
/** poza brez višine (py = 0) — samo za izračun stopal */
function gaitPose0(g: Gait, u: number): SidePose {
  const fL = wrap(u), fR = wrap(u + 0.5)
  return { ...SIDE0, px: g.px, py: 0, t: g.t, n: g.n, hL: g.hip(fL), hR: g.hip(fR), kL: g.knee(fL), kR: g.knee(fR), aL: g.ankle(fL), aR: g.ankle(fR), sL: g.arm(fL), sR: g.arm(fR), eL: g.elbow(fL), eR: g.elbow(fR) }
}
/** tek: doskok pri f = 0, opora do 0,36, odriv, zamah (peta proti zadnjici), noga naprej; roke nasprotno nogam */
const RUN: Gait = {
  hip: f => 12 + 30 * Math.cos(TAU * (f - 0.85)),
  knee: f => 14 + 30 * bump(f, 0.15, 0.07) + 96 * bump(f, 0.62, 0.12),
  // (v3.48) med zamahom prsti navzdol (stopalo v podaljšku golenice) — prej je stopalo zadaj kazalo navzgor
  ankle: f => 6 - 12 * bump(f, 0.16, 0.07) + 24 * bump(f, 0.4, 0.05) + 48 * bump(f, 0.6, 0.1),
  arm: f => 6 + 38 * Math.cos(TAU * (f - 0.37)),
  elbow: f => 86 + 14 * Math.cos(TAU * (f - 0.87)),
  stance: 0.36, flight: 3.5, t: 9, n: -3, px: 96,
}
/** hoja: opora 60 % koraka (dvojna opora), koleno se upogne pri zamahu, odriv s prsti; roke rahlo nihajo */
const WALK: Gait = {
  hip: f => 7 + 20 * Math.cos(TAU * (f - 0.95)),
  knee: f => 4 + 14 * bump(f, 0.14, 0.06) + 54 * bump(f, 0.72, 0.1),
  ankle: f => -6 * bump(f, 0.02, 0.04) - 5 * bump(f, 0.32, 0.1) + 20 * bump(f, 0.6, 0.05) + 16 * bump(f, 0.7, 0.07),
  arm: f => 1 + 19 * Math.cos(TAU * (f - 0.45)),
  elbow: f => 16 + 8 * Math.cos(TAU * (f - 0.95)),
  stance: 0.6, flight: 0, t: 3, n: 0, px: 96,
}
/** kolo: pedali krožijo okrog gonilke (enaka točka kot na risbi kolesa), noge jim sledijo (IK) */
export const CRANK: Pt = { x: 104, y: FLOOR - 15 }
const CRANK_R = 11
const SADDLE: Pt = { x: 88, y: 104 }
function legTo(hip: Pt, ankle: Pt, t: number, footAbs: number): { h: number; k: number; a: number } {
  const dx = ankle.x - hip.x, dy = ankle.y - hip.y
  const d = Math.min(Math.hypot(dx, dy), L.thigh + L.shin - 0.05)
  const base = Math.atan2(dx, dy) * DEG
  const cosA = (L.thigh * L.thigh + d * d - L.shin * L.shin) / (2 * L.thigh * d)
  const thigh = base + Math.acos(Math.max(-1, Math.min(1, cosA))) * DEG   // koleno naprej
  const knee = { x: hip.x + Math.sin(thigh / DEG) * L.thigh, y: hip.y + Math.cos(thigh / DEG) * L.thigh }
  const shin = Math.atan2(ankle.x - knee.x, ankle.y - knee.y) * DEG
  return { h: thigh + t, k: thigh - shin, a: shin + 90 - footAbs }
}
function bikePose(u: number): SidePose {
  const th = TAU * u
  const t = 42 + 1.2 * Math.sin(2 * th)
  const leg = (a: number) => {
    const pedal = { x: CRANK.x + CRANK_R * Math.sin(a), y: CRANK.y - CRANK_R * Math.cos(a) }
    // gleženj »pedalira«: zgoraj stopalo vodoravno, spodaj in zadaj prsti navzdol
    const foot = 80 + 7 * Math.cos(a) - 4 * Math.sin(a)
    const ankle = { x: pedal.x - Math.sin(foot / DEG) * 8, y: pedal.y - Math.cos(foot / DEG) * 8 }
    return legTo({ x: SADDLE.x, y: SADDLE.y + 0.5 * Math.sin(2 * th) }, ankle, t, foot)
  }
  const l = leg(th), r = leg(th + Math.PI)
  return { ...SIDE0, px: SADDLE.x, py: SADDLE.y + 0.5 * Math.sin(2 * th), t, n: -30, hL: l.h, kL: l.k, aL: l.a, hR: r.h, kR: r.k, aR: r.a, sL: 62, sR: 62, eL: 22, eR: 22 }
}


/* ---------------- poze iz točk (v3.48) ----------------
 * Blaž, 17. 10.: »sklece na kolenih, hoja … so čist narobe«. Figure, sestavljene iz kotov, so lebdele: kolena pri
 * sklecah na kolenih niso bila na tleh, stopala pri pike sklecah tudi ne. Zdaj se te vaje postavijo iz točk — dlani,
 * kolena in stopala so točno na tleh (ali ročaju) — in kote izračuna inverzna kinematika; gibanje se interpolira med
 * točkami, zato se dlan med sklecami ne premakne s tal.
 */
interface Pts {
  /** medenica (kolk) in kot trupa (kot v SidePose.t) */
  P: Pt; t: number; n?: number
  /** zapestje (absolutno) in stran komolca (+1 naprej, −1 nazaj) */
  wrist: Pt; elbow?: 1 | -1
  /** gleženj (absolutno), stran kolena in smer prstov (zaslonski kot: 90 = naprej, 0 = dol, 180 = gor) */
  ankle: Pt; knee?: 1 | -1; kneeAt?: Pt; toe?: number
}
/** kot smeri v zaslonu: dir(ang(v)) kaže v smer v (0 = dol, 90 = desno) */
const ang = (v: Pt) => Math.atan2(v.x, v.y) * DEG
const lerpPt = (a: Pt, b: Pt, k: number): Pt => ({ x: a.x + (b.x - a.x) * k, y: a.y + (b.y - a.y) * k })
/** dvočlenska IK: od a do c z dolžinama l1, l2; vrne zaslonska kota obeh členov */
function ik2(a: Pt, c: Pt, l1: number, l2: number, bend: number): [number, number] {
  const dx = c.x - a.x, dy = c.y - a.y
  const d = Math.max(Math.abs(l1 - l2) + 0.01, Math.min(Math.hypot(dx, dy), l1 + l2 - 0.01))
  const cosA = (l1 * l1 + d * d - l2 * l2) / (2 * l1 * d)
  const s1 = ang({ x: dx, y: dy }) + bend * Math.acos(Math.max(-1, Math.min(1, cosA))) * DEG
  const m = { x: a.x + Math.sin(s1 / DEG) * l1, y: a.y + Math.cos(s1 / DEG) * l1 }
  return [s1, ang({ x: c.x - m.x, y: c.y - m.y })]
}
/** poza iz točk (obe strani enaki — pri teh vajah se noge in roke gibljejo skupaj) */
function fromPts(q: Pts): SidePose {
  const sh = { x: q.P.x + Math.sin(q.t / DEG) * L.torso, y: q.P.y - Math.cos(q.t / DEG) * L.torso }
  const [u, f] = ik2(sh, q.wrist, L.upper, L.fore, q.elbow ?? -1)
  const [th, sn] = q.kneeAt ? [ang({ x: q.kneeAt.x - q.P.x, y: q.kneeAt.y - q.P.y }), ang({ x: q.ankle.x - q.kneeAt.x, y: q.ankle.y - q.kneeAt.y })] : ik2(q.P, q.ankle, L.thigh, L.shin, q.knee ?? 1)
  const h = th + q.t, k = th - sn, a = sn + 90 - (q.toe ?? 90), sA = u + q.t, e = f - u
  return { ...SIDE0, px: q.P.x, py: q.P.y, t: q.t, n: q.n ?? 0, hL: h, hR: h, kL: k, kR: k, aL: a, aR: a, sL: sA, sR: sA, eL: e, eR: e }
}
/** zanka med stanji iz točk (gladko); `lift` dvigne gleženj med prehodom (skok nazaj ali naprej) */
function ptsGen(states: { at: number; q: Pts; lift?: number }[]): (u: number) => SidePose {
  const st = states[states.length - 1]!.at < 1 ? [...states, { at: 1, q: states[0]!.q }] : states
  return (u: number) => {
    let i = 0
    while (i < st.length - 2 && st[i + 1]!.at <= u) i++
    const A = st[i]!, B = st[i + 1]!, k = smoothK((u - A.at) / Math.max(1e-6, B.at - A.at)), a = A.q, b = B.q
    const ankle = lerpPt(a.ankle, b.ankle, k)
    if (B.lift) ankle.y -= B.lift * Math.sin(Math.PI * k)
    return fromPts({
      P: lerpPt(a.P, b.P, k), t: a.t + (b.t - a.t) * k, n: (a.n ?? 0) + ((b.n ?? 0) - (a.n ?? 0)) * k,
      wrist: lerpPt(a.wrist, b.wrist, k), elbow: a.elbow, ankle, knee: a.knee, toe: (a.toe ?? 90) + ((b.toe ?? 90) - (a.toe ?? 90)) * k,
      kneeAt: a.kneeAt && b.kneeAt ? lerpPt(a.kneeAt, b.kneeAt, k) : undefined,
    })
  }
}
const smoothK = (x: number) => { const c = Math.max(0, Math.min(1, x)); return c * c * (3 - 2 * c) }
const GROUND = FLOOR + 2                                   // sklep, ki leži na tleh (debelina uda do črte tal)
const unitDeg = (deg: number): Pt => ({ x: Math.cos(deg / DEG), y: -Math.sin(deg / DEG) })   // smer pod kotom nad vodoravnico (desno)
const addK = (a: Pt, d: Pt, k: number): Pt => ({ x: a.x + d.x * k, y: a.y + d.y * k })
/** zgornji del in noge v ravni črti od opornice (koleno ali gleženj) pod kotom θ nad tlemi */
const lineFrom = (from: Pt, theta: number, legLen: number) => { const d = unitDeg(theta); const P = addK(from, d, legLen); return { P, S: addK(P, d, L.torso), t: 90 - theta } }

/** sklece na kolenih: kolena na tleh, golenici dvignjeni, telo od kolen do glave ravno; dlani na istem mestu */
const KNEE_PU = (() => {
  const K = { x: 58, y: GROUND }, shin = { x: -Math.cos(35 / DEG), y: -Math.sin(35 / DEG) }, ankle = addK(K, shin, L.shin)
  // zgoraj iztegnjene roke navpično: rama 49,5 nad dlanjo → kot telesa iz dolžine stegna in trupa
  const reach = 49.5, hand = FLOOR + 3
  const top = lineFrom(K, Math.asin(Math.min(0.95, (K.y - (hand - reach)) / (L.thigh + L.torso))) * DEG, L.thigh), bot = lineFrom(K, 12, L.thigh)
  const wrist = { x: top.S.x, y: hand }
  const q = (x: ReturnType<typeof lineFrom>): Pts => ({ P: x.P, t: x.t, n: -6, wrist, elbow: -1, ankle, kneeAt: K, toe: ang(shin) - 25 })
  return ptsGen([{ at: 0, q: q(top) }, { at: 0.06, q: q(top) }, { at: 0.46, q: q(bot) }, { at: 0.54, q: q(bot) }, { at: 0.94, q: q(top) }])
})()
/** pike sklece: dlani in prsti na tleh, boki visoko (črka V), glava se spusti proti tlom pred dlanmi */
const PIKE_PU = (() => {
  const ankle = { x: 42, y: FLOOR - 4 }, leg = L.thigh + L.shin
  const hip = (alpha: number): Pt => ({ x: ankle.x + Math.sin(alpha / DEG) * leg, y: ankle.y - Math.cos(alpha / DEG) * leg })
  // zgoraj: trup in iztegnjene roke v ravni črti od bokov do dlani (dlan tam, kjer jo doseže iztegnjena roka)
  const A0 = 32, P0 = hip(A0), reach = L.torso + 49.5, hand = FLOOR + 3
  const wrist = { x: P0.x + Math.sqrt(Math.max(0, reach * reach - (hand - P0.y) ** 2)), y: hand }
  // spodaj: komolci pokrčeni, glava nizko tik pred dlanmi; boki se po krogu (iztegnjene noge) pomaknejo naprej
  const headAt = { x: wrist.x - 8, y: FLOOR - 16 }
  let A1 = A0
  // boki ostanejo visoko: naprej največ za 7° (prej so pri glavi pred dlanmi padli v desko)
  while (A1 < A0 + 7 && Math.hypot(headAt.x - hip(A1).x, headAt.y - hip(A1).y) > L.torso + L.neck) A1 += 0.25
  const pose = (k: number): SidePose => {
    const P = hip(A0 + (A1 - A0) * k), aim = lerpPt(wrist, headAt, k)
    const v = { x: aim.x - P.x, y: aim.y - P.y }, l = Math.hypot(v.x, v.y)
    // zgoraj pogled med dlani (glava dvignjena), spodaj glava proti tlom
    return fromPts({ P, t: Math.atan2(v.x / l, -v.y / l) * DEG, n: -28 + 36 * k, wrist, elbow: -1, ankle, knee: 1, toe: 54 })
  }
  return (u: number) => pose(smoothK(u < 0.06 ? 0 : u < 0.46 ? (u - 0.06) / 0.4 : u < 0.54 ? 1 : u < 0.94 ? 1 - (u - 0.54) / 0.4 : 0))
})()
/** burpee: stoja → počep z dlanmi na tleh → skok nazaj v desko → nazaj v počep → skok gor z rokami nad glavo */
const BURPEE = (() => {
  const foot = { x: 96, y: FLOOR }, hand = { x: 126, y: FLOOR + 3 }
  const stand: Pts = { P: { x: 96, y: STAND_Y }, t: 0, wrist: { x: 100, y: STAND_Y - L.torso + 49 }, elbow: 1, ankle: foot, knee: 1, toe: 90 }
  const squat: Pts = { P: { x: 84, y: 148 }, t: 62, n: -18, wrist: hand, elbow: -1, ankle: foot, knee: 1, toe: 90 }
  const pl = lineFrom({ x: hand.x - 112 * Math.cos(22 / DEG), y: hand.y - 49 + 112 * Math.sin(22 / DEG) }, 22, L.thigh + L.shin)
  const plank: Pts = { P: pl.P, t: pl.t, n: -4, wrist: hand, elbow: -1, ankle: { x: hand.x - 112 * Math.cos(22 / DEG), y: hand.y - 49 + 112 * Math.sin(22 / DEG) }, knee: 1, toe: 54 }
  const jump: Pts = { P: { x: 96, y: STAND_Y - 10 }, t: 0, n: -6, wrist: { x: 118, y: STAND_Y - 10 - L.torso - 44 }, elbow: 1, ankle: { x: 96, y: FLOOR - 10 }, knee: 1, toe: 20 }
  return ptsGen([
    { at: 0, q: stand }, { at: 0.16, q: squat }, { at: 0.34, q: plank, lift: 10 }, { at: 0.44, q: plank }, { at: 0.6, q: squat, lift: 10 }, { at: 0.78, q: jump }, { at: 0.86, q: jump }, { at: 1, q: stand },
  ])
})()
/** veslanje z elastiko stoje: kolena rahlo pokrčena, iztegnjene roke → komolci ob telesu nazaj, dlani ob rebrih */
const BAND_ROW = (() => {
  const P = { x: 80, y: STAND_Y + 3 }, ankle = { x: 84, y: FLOOR }, S = { x: P.x, y: P.y - L.torso }
  const reach: Pts = { P, t: 2, wrist: { x: S.x + 48, y: S.y + 16 }, elbow: -1, ankle, knee: 1, toe: 90 }
  const pull: Pts = { P, t: -3, wrist: { x: S.x + 12, y: S.y + 25 }, elbow: -1, ankle, knee: 1, toe: 90 }
  return ptsGen([{ at: 0, q: reach }, { at: 0.06, q: reach }, { at: 0.44, q: pull }, { at: 0.56, q: pull }, { at: 0.94, q: reach }])
})()

/* ---------------- stranske poze: osnovne ---------------- */
const stand: Partial<SidePose> = { px: 96, py: STAND_Y, t: 0 }
/** leže na hrbtu (glava levo) */
const supine = (py = FLOOR - 9): Partial<SidePose> => ({ px: 104, py, t: -90, n: 0 })
/** opora na rokah (glava desno) */
const prone = (py: number): Partial<SidePose> => ({ px: 92, py, t: 90 })

/* ---------------- vaje ---------------- */
export const TEMPLATES: Record<string, Template> = {
  /* --- lastna teža --- */
  sklece: side(2600, [], upDown({ ...prone(122), sL: 90, sR: 90, eL: 0, eR: 0, aL: 90, aR: 90 }, { ...prone(133), sL: 42, sR: 42, eL: 48, eR: 48, aL: 90, aR: 90 }, 0.05, 0.08)),
  'sklece-kolena': { ...side(2600, [], [{ at: 0, p: KNEE_PU(0) }]), gen: KNEE_PU },
  'sklece-noge': side(2600, ['box-feet'], upDown({ ...prone(112), px: 98, t: 100, sL: 100, sR: 100, eL: 0, eR: 0, aL: 90, aR: 90 }, { ...prone(123), px: 98, t: 100, sL: 50, sR: 50, eL: 50, eR: 50, aL: 90, aR: 90 }, 0.05, 0.08)),
  pike: { ...side(2800, [], [{ at: 0, p: PIKE_PU(0) }]), gen: PIKE_PU },
  pocep: side(2800, [], upDown({ ...stand, sL: 85, sR: 85, eL: 0, eR: 0 }, { ...stand, py: STAND_Y + 28, t: 28, hL: 100, hR: 100, kL: 108, kR: 108, aL: 20, aR: 20, sL: 95, sR: 95, eL: 0, eR: 0, n: -14 }, 0.05, 0.1)),
  izpadni: side(2800, [], upDown({ ...stand, hL: 20, hR: -8, kL: 25, kR: 10, sL: 20, sR: 20, eL: 70, eR: 70 }, { ...stand, py: STAND_Y + 22, hL: 75, hR: -28, kL: 92, kR: 85, aL: 0, aR: 70, sL: 20, sR: 20, eL: 70, eR: 70 }, 0.05, 0.1)),
  bolgarski: side(2800, ['box-back'], upDown({ ...stand, px: 88, hL: 25, hR: -35, kL: 25, kR: 95, aR: 90, sL: 20, sR: 20, eL: 70, eR: 70 }, { ...stand, px: 88, py: STAND_Y + 22, hL: 78, hR: -40, kL: 92, kR: 110, aL: 0, aR: 90, sL: 20, sR: 20, eL: 70, eR: 70, t: 10 }, 0.05, 0.1)),
  most: side(2600, [], upDown({ ...supine(FLOOR - 10), hL: 58, hR: 58, kL: 100, kR: 100, sL: 5, sR: 5 }, { ...supine(FLOOR - 32), t: -72, hL: 20, hR: 20, kL: 100, kR: 100, sL: 10, sR: 10 }, 0.05, 0.12)),
  most1: side(2800, [], upDown({ ...supine(FLOOR - 10), hL: 58, hR: 95, kL: 100, kR: 10, sL: 5, sR: 5 }, { ...supine(FLOOR - 32), t: -72, hL: 20, hR: 60, kL: 100, kR: 5, sL: 10, sR: 10 }, 0.05, 0.12)),
  deska: side(3600, [], upDown({ ...prone(124), sL: 95, sR: 95, eL: 95, eR: 95, aL: 90, aR: 90 }, { ...prone(125), sL: 95, sR: 95, eL: 95, eR: 95, aL: 90, aR: 90 })),
  stranska: front(3600, [], upDown({ px: 112, py: FLOOR - 30, lean: 76, abL: 110, abR: 170, eL: 95, eR: 0, wL: 4, wR: 4 }, { px: 112, py: FLOOR - 32, lean: 78, abL: 110, abR: 170, eL: 95, eR: 0, wL: 4, wR: 4 })),
  deadbug: side(3200, [], [
    { at: 0, p: { ...supine(), hL: 90, hR: 90, kL: 90, kR: 90, sL: 90, sR: 90 } },
    { at: 0.5, p: { ...supine(), hL: 20, hR: 90, kL: 10, kR: 90, sL: 90, sR: 170 } },
    { at: 1, p: { ...supine(), hL: 90, hR: 90, kL: 90, kR: 90, sL: 90, sR: 90 } },
  ]),
  'dvig-nog': side(3000, [], upDown({ ...supine(), hL: 8, hR: 8, kL: 0, kR: 0, sL: 0, sR: 0 }, { ...supine(), hL: 88, hR: 88, kL: 0, kR: 0, sL: 0, sR: 0 }, 0.05, 0.08)),
  kolesarcki: side(2400, [], [
    { at: 0, p: { ...supine(), t: -78, hL: 95, hR: 25, kL: 110, kR: 10, sL: 150, sR: 150, eL: 120, eR: 120, n: 25 } },
    { at: 0.5, p: { ...supine(), t: -78, hL: 25, hR: 95, kL: 10, kR: 110, sL: 150, sR: 150, eL: 120, eR: 120, n: 25 } },
    { at: 1, p: { ...supine(), t: -78, hL: 95, hR: 25, kL: 110, kR: 10, sL: 150, sR: 150, eL: 120, eR: 120, n: 25 } },
  ]),
  plezalec: side(1400, [], [
    { at: 0, p: { ...prone(120), sL: 90, sR: 90, eL: 0, eR: 0, hL: 0, hR: 85, kL: 0, kR: 110, aL: 90, aR: 60 } },
    { at: 0.5, p: { ...prone(120), sL: 90, sR: 90, eL: 0, eR: 0, hL: 85, hR: 0, kL: 110, kR: 0, aL: 60, aR: 90 } },
    { at: 1, p: { ...prone(120), sL: 90, sR: 90, eL: 0, eR: 0, hL: 0, hR: 85, kL: 0, kR: 110, aL: 90, aR: 60 } },
  ]),
  // (v3.48) križ na tleh, ramena in iztegnjene noge ~15–20° od tal, roke ob ušesih (prej trup v V in noge na tleh)
  coln: side(3600, [], upDown({ ...supine(FLOOR - 1), t: -73, hL: 36, hR: 36, kL: 0, kR: 0, aL: 90, aR: 90, sL: 180, sR: 180, eL: 0, eR: 0, n: 12 }, { ...supine(FLOOR - 1), t: -71, hL: 38, hR: 38, kL: 0, kR: 0, aL: 90, aR: 90, sL: 180, sR: 180, eL: 0, eR: 0, n: 12 })),
  superman: side(3000, [], upDown({ ...prone(FLOOR - 8), px: 100, t: 90, sL: 170, sR: 170, hL: 0, hR: 0, aL: 40, aR: 40, n: -10 }, { ...prone(FLOOR - 12), px: 100, t: 78, sL: 180, sR: 180, hL: -22, hR: -22, aL: 40, aR: 40, n: -20 }, 0.05, 0.15)),
  dipi: side(2600, ['chair'], upDown({ px: 96, py: FLOOR - 40, t: -8, hL: 80, hR: 80, kL: 20, kR: 20, sL: -40, sR: -40, eL: 0, eR: 0 }, { px: 96, py: FLOOR - 26, t: -8, hL: 90, hR: 90, kL: 30, kR: 30, sL: -75, sR: -75, eL: 95, eR: 95 }, 0.05, 0.08)),
  prsti: side(2200, [], upDown({ ...stand, sL: 8, sR: 8 }, { ...stand, py: STAND_Y - 7, aL: 35, aR: 35, sL: 8, sR: 8 }, 0.05, 0.15)),
  burpee: { ...side(3200, [], [{ at: 0, p: BURPEE(0) }]), gen: BURPEE },
  krozni: side(700, ['rope'], [
    { at: 0, p: { ...stand, sL: 12, sR: 12, eL: 70, eR: 70, kL: 8, kR: 8 } },
    { at: 0.5, p: { ...stand, py: STAND_Y - 12, sL: 14, sR: 14, eL: 76, eR: 76, aL: 35, aR: 35, kL: 4, kR: 4 } },
    { at: 1, p: { ...stand, sL: 12, sR: 12, eL: 70, eR: 70, kL: 8, kR: 8 } },
  ]),
  /* --- drog --- */
  zgibi: side(3000, ['bar', 'nofloor'], upDown<SidePose>({ px: 100, py: 118, t: 0, sL: 178, sR: 178, eL: 0, eR: 0, kL: 55, kR: 55, hL: 8, hR: 8, aL: 30, aR: 30 }, { px: 100, py: 92, t: 0, sL: 125, sR: 125, eL: 125, eR: 125, kL: 60, kR: 60, hL: 10, hR: 10, aL: 30, aR: 30, n: -12 }, 0.08, 0.1)),
  negativni: side(4000, ['bar', 'nofloor'], [
    { at: 0, p: { px: 100, py: 92, t: 0, sL: 125, sR: 125, eL: 125, eR: 125, kL: 60, kR: 60, hL: 10, hR: 10, aL: 30, aR: 30, n: -12 } },
    { at: 0.08, p: { px: 100, py: 92, t: 0, sL: 125, sR: 125, eL: 125, eR: 125, kL: 60, kR: 60, hL: 10, hR: 10, aL: 30, aR: 30, n: -12 } },
    { at: 0.8, p: { px: 100, py: 118, t: 0, sL: 178, sR: 178, eL: 0, eR: 0, kL: 55, kR: 55, hL: 8, hR: 8, aL: 30, aR: 30 } },
    { at: 1, p: { px: 100, py: 92, t: 0, sL: 125, sR: 125, eL: 125, eR: 125, kL: 60, kR: 60, hL: 10, hR: 10, aL: 30, aR: 30, n: -12 } },
  ]),
  'kolena-vis': side(2800, ['bar', 'nofloor'], upDown({ px: 100, py: 118, t: 0, sL: 178, sR: 178, hL: 5, hR: 5, kL: 10, kR: 10, aL: 30, aR: 30 }, { px: 100, py: 118, t: -6, sL: 176, sR: 176, hL: 100, hR: 100, kL: 100, kR: 100, aL: 30, aR: 30 }, 0.05, 0.1)),
  /* --- ročke --- */
  goblet: side(2800, ['goblet'], upDown({ ...stand, sL: 40, sR: 40, eL: 125, eR: 125 }, { ...stand, py: STAND_Y + 28, t: 24, hL: 100, hR: 100, kL: 108, kR: 108, aL: 20, aR: 20, sL: 45, sR: 45, eL: 125, eR: 125, n: -12 }, 0.05, 0.1)),
  'rdl-r': side(3000, ['dumbbells'], upDown({ ...stand, sL: 4, sR: 4 }, { ...stand, py: STAND_Y + 4, t: 70, hL: 85, hR: 85, kL: 18, kR: 18, aL: 0, aR: 0, sL: -2, sR: -2, n: -35 }, 0.05, 0.1)),
  'potisk-r': side(2600, ['bench-flat', 'dumbbells'], upDown({ ...supine(FLOOR - 36), px: 98, hL: 70, hR: 70, kL: 95, kR: 95, sL: 92, sR: 92, eL: 0, eR: 0 }, { ...supine(FLOOR - 36), px: 98, hL: 70, hR: 70, kL: 95, kR: 95, sL: 40, sR: 40, eL: 95, eR: 95 }, 0.05, 0.08)),
  'veslanje-r': side(2600, ['bench-support', 'dumbbell-near'], upDown({ px: 86, py: STAND_Y + 6, t: 72, hL: 80, hR: 100, kL: 16, kR: 100, aR: 90, sR: 80, sL: 6, eR: 0, eL: 0, n: -30 }, { px: 86, py: STAND_Y + 6, t: 72, hL: 80, hR: 100, kL: 16, kR: 100, aR: 90, sR: 80, sL: -30, eR: 0, eL: 115, n: -30 }, 0.05, 0.1)),
  'nadglavo-r': side(2600, ['dumbbells'], upDown({ ...stand, sL: 150, sR: 150, eL: 110, eR: 110 }, { ...stand, sL: 178, sR: 178, eL: 2, eR: 2 }, 0.05, 0.08)),
  odrocenje: front(2600, ['dumbbells'], upDown({ abL: 12, abR: 12, eL: 10, eR: 10 }, { abL: 92, abR: 92, eL: 10, eR: 10 }, 0.05, 0.1)),
  'biceps-r': side(2400, ['dumbbells'], upDown({ ...stand, sL: 6, sR: 6, eL: 10, eR: 10 }, { ...stand, sL: 12, sR: 12, eL: 140, eR: 140 }, 0.05, 0.1)),
  'triceps-r': side(2400, ['dumbbell-near'], upDown({ ...stand, sL: 176, sR: 176, eL: 4, eR: 4 }, { ...stand, sL: 176, sR: 176, eL: 125, eR: 125, n: 8 }, 0.05, 0.08)),
  'izpadni-r': side(2800, ['dumbbells'], upDown({ ...stand, hL: 20, hR: -8, kL: 25, kR: 10, sL: 4, sR: 4 }, { ...stand, py: STAND_Y + 22, hL: 75, hR: -28, kL: 92, kR: 85, aL: 0, aR: 70, sL: 4, sR: 4 }, 0.05, 0.1)),
  'stopanje-r': side(2800, ['box-front', 'dumbbells'], [
    { at: 0, p: { ...stand, px: 84, hL: 70, hR: 0, kL: 90, kR: 0, sL: 4, sR: 4 } },
    { at: 0.5, p: { ...stand, px: 104, py: STAND_Y - 30, hL: 5, hR: 40, kL: 5, kR: 70, aR: 30, sL: 4, sR: 4 } },
    { at: 0.62, p: { ...stand, px: 104, py: STAND_Y - 30, hL: 5, hR: 40, kL: 5, kR: 70, aR: 30, sL: 4, sR: 4 } },
    { at: 1, p: { ...stand, px: 84, hL: 70, hR: 0, kL: 90, kR: 0, sL: 4, sR: 4 } },
  ]),
  'hip-r': side(2600, ['bench-back', 'barbell-hips'], upDown({ px: 104, py: FLOOR - 16, t: -62, hL: 70, hR: 70, kL: 100, kR: 100, sL: 20, sR: 20, eL: 110, eR: 110, n: 25 }, { px: 104, py: FLOOR - 38, t: -82, hL: 12, hR: 12, kL: 100, kR: 100, sL: 20, sR: 20, eL: 110, eR: 110, n: 30 }, 0.05, 0.12)),
  'zasuki-r': front(2000, ['nofloor', 'plate-chest'], [
    { at: 0, p: { px: 100, py: 128, lean: -18, abL: 60, abR: 60, eL: 60, eR: 60, wL: 14, wR: 14, kL: 120, kR: 120, tw: -14 } },
    { at: 0.5, p: { px: 100, py: 128, lean: -18, abL: 60, abR: 60, eL: 60, eR: 60, wL: 14, wR: 14, kL: 120, kR: 120, tw: 14 } },
    { at: 1, p: { px: 100, py: 128, lean: -18, abL: 60, abR: 60, eL: 60, eR: 60, wL: 14, wR: 14, kL: 120, kR: 120, tw: -14 } },
  ]),
  zamah: side(1800, ['kettlebell'], upDown({ ...stand, px: 92, t: 55, hL: 70, hR: 70, kL: 25, kR: 25, sL: -25, sR: -25, py: STAND_Y + 4, n: -25 }, { ...stand, px: 92, t: -2, sL: 95, sR: 95, eL: 0, eR: 0 }, 0.04, 0.06)),
  /* --- elastike --- */
  // (v3.48) stoje, elastika zataknjena v višini prsi pred tabo, komolci nazaj (prej sedel v zraku)
  'veslanje-e': { ...side(2400, ['band-mid'], [{ at: 0, p: BAND_ROW(0) }]), gen: BAND_ROW },
  'razteg-e': front(2400, ['band-front'], upDown<FrontPose>({ abL: 88, abR: 88, eL: 0, eR: 0, lean: 0 }, { abL: 96, abR: 96, eL: 0, eR: 0, lean: 0, tw: 0 }, 0.05, 0.1)),
  'biceps-e': side(2400, ['band-low'], upDown({ ...stand, sL: 6, sR: 6, eL: 10, eR: 10 }, { ...stand, sL: 12, sR: 12, eL: 140, eR: 140 }, 0.05, 0.1)),
  pallof: front(2600, ['band-mid'], upDown({ abL: 20, abR: 20, eL: 150, eR: 150, wL: 14, wR: 14, kL: 20, kR: 20 }, { abL: 40, abR: 40, eL: 10, eR: 10, wL: 14, wR: 14, kL: 20, kR: 20 }, 0.08, 0.2)),
  'koraki-e': front(1600, ['band-legs'], [
    { at: 0, p: { wL: 10, wR: 10, kL: 40, kR: 40, abL: 25, abR: 25, eL: 90, eR: 90, lean: 6 } },
    { at: 0.5, p: { wL: 10, wR: 32, kL: 40, kR: 40, abL: 25, abR: 25, eL: 90, eR: 90, lean: 6 } },
    { at: 1, p: { wL: 10, wR: 10, kL: 40, kR: 40, abL: 25, abR: 25, eL: 90, eR: 90, lean: 6 } },
  ]),
  /* --- fitnes --- */
  'pocep-p': side(3000, ['barbell-shoulders'], upDown({ ...stand, sL: 60, sR: 60, eL: 120, eR: 120 }, { ...stand, py: STAND_Y + 28, t: 26, hL: 100, hR: 100, kL: 108, kR: 108, aL: 20, aR: 20, sL: 60, sR: 60, eL: 120, eR: 120, n: -12 }, 0.05, 0.1)),
  presa: side(2800, ['legpress'], upDown({ px: 70, py: FLOOR - 40, t: -50, hL: 70, hR: 70, kL: 20, kR: 20, sL: -10, sR: -10, eL: 60, eR: 60, aL: 10, aR: 10 }, { px: 70, py: FLOOR - 40, t: -50, hL: 115, hR: 115, kL: 105, kR: 105, sL: -10, sR: -10, eL: 60, eR: 60, aL: 10, aR: 10 }, 0.05, 0.08)),
  mrtvi: side(3200, ['barbell-hands'], upDown({ ...stand, px: 92, py: STAND_Y + 14, t: 48, hL: 95, hR: 95, kL: 70, kR: 70, aL: 0, aR: 0, sL: -6, sR: -6, n: -30 }, { ...stand, px: 92, sL: 2, sR: 2 }, 0.06, 0.08)),
  'rdl-p': side(3000, ['barbell-hands'], upDown({ ...stand, sL: 4, sR: 4 }, { ...stand, py: STAND_Y + 4, t: 70, hL: 85, hR: 85, kL: 18, kR: 18, aL: 0, aR: 0, sL: -2, sR: -2, n: -35 }, 0.05, 0.1)),
  bench: side(2800, ['bench-flat', 'barbell-hands'], upDown({ ...supine(FLOOR - 36), px: 98, hL: 70, hR: 70, kL: 95, kR: 95, sL: 92, sR: 92, eL: 0, eR: 0 }, { ...supine(FLOOR - 36), px: 98, hL: 70, hR: 70, kL: 95, kR: 95, sL: 38, sR: 38, eL: 95, eR: 95 }, 0.05, 0.08)),
  'incline-r': side(2800, ['bench-incline', 'dumbbells'], upDown({ px: 98, py: FLOOR - 32, t: -50, hL: 85, hR: 85, kL: 85, kR: 85, sL: 92, sR: 92, eL: 0, eR: 0 }, { px: 98, py: FLOOR - 32, t: -50, hL: 85, hR: 85, kL: 85, kR: 85, sL: 40, sR: 40, eL: 95, eR: 95 }, 0.05, 0.08)),
  metuljcek: front(2600, ['pecdeck'], upDown({ py: 128, abL: 92, abR: 92, eL: 85, eR: 85, wL: 14, wR: 14, kL: 120, kR: 120 }, { py: 128, abL: 18, abR: 18, eL: 85, eR: 85, wL: 14, wR: 14, kL: 120, kR: 120 }, 0.05, 0.12)),
  pulldown: side(2600, ['cable-top'], upDown({ px: 96, py: FLOOR - 44, t: -6, hL: 95, hR: 95, kL: 95, kR: 95, sL: 165, sR: 165, eL: 0, eR: 0, n: -8 }, { px: 96, py: FLOOR - 44, t: -14, hL: 95, hR: 95, kL: 95, kR: 95, sL: 110, sR: 110, eL: 115, eR: 115, n: -8 }, 0.05, 0.1)),
  'kabel-v': side(2600, ['cable-mid'], upDown({ px: 92, py: FLOOR - 44, t: 2, hL: 95, hR: 95, kL: 12, kR: 12, sL: 88, sR: 88, eL: 0, eR: 0 }, { px: 92, py: FLOOR - 44, t: -8, hL: 95, hR: 95, kL: 12, kR: 12, sL: 45, sR: 45, eL: 120, eR: 120 }, 0.05, 0.1)),
  'veslanje-p': side(2600, ['barbell-hands'], upDown({ ...stand, px: 92, py: STAND_Y + 4, t: 62, hL: 78, hR: 78, kL: 22, kR: 22, aL: 0, aR: 0, sL: 10, sR: 10, eL: 0, eR: 0, n: -30 }, { ...stand, px: 92, py: STAND_Y + 4, t: 62, hL: 78, hR: 78, kL: 22, kR: 22, aL: 0, aR: 0, sL: -30, sR: -30, eL: 105, eR: 105, n: -30 }, 0.05, 0.1)),
  ohp: side(2600, ['barbell-hands'], upDown({ ...stand, sL: 125, sR: 125, eL: 125, eR: 125 }, { ...stand, sL: 178, sR: 178, eL: 2, eR: 2, n: -6 }, 0.05, 0.08)),
  facepull: side(2400, ['cable-top'], upDown({ ...stand, px: 88, t: 4, sL: 100, sR: 100, eL: 0, eR: 0 }, { ...stand, px: 88, t: 4, sL: 95, sR: 95, eL: 125, eR: 125 }, 0.05, 0.1)),
  'triceps-k': side(2200, ['cable-top'], upDown({ ...stand, px: 88, t: 6, sL: 15, sR: 15, eL: 120, eR: 120 }, { ...stand, px: 88, t: 6, sL: 12, sR: 12, eL: 8, eR: 8 }, 0.05, 0.1)),
  'biceps-p': side(2400, ['barbell-hands'], upDown({ ...stand, sL: 6, sR: 6, eL: 10, eR: 10 }, { ...stand, sL: 14, sR: 14, eL: 140, eR: 140 }, 0.05, 0.1)),
  'leg-curl': side(2400, ['legcurl'], upDown({ px: 96, py: FLOOR - 36, t: 92, hL: -4, hR: -4, kL: 5, kR: 5, sL: 100, sR: 100, eL: 90, eR: 90, aL: 20, aR: 20 }, { px: 96, py: FLOOR - 36, t: 92, hL: -4, hR: -4, kL: 115, kR: 115, sL: 100, sR: 100, eL: 90, eR: 90, aL: 20, aR: 20 }, 0.05, 0.1)),
  'leg-ext': side(2400, ['legext'], upDown({ px: 92, py: FLOOR - 46, t: -8, hL: 95, hR: 95, kL: 95, kR: 95, sL: -20, sR: -20, eL: 30, eR: 30, aL: 10, aR: 10 }, { px: 92, py: FLOOR - 46, t: -8, hL: 95, hR: 95, kL: 5, kR: 5, sL: -20, sR: -20, eL: 30, eR: 30, aL: 10, aR: 10 }, 0.05, 0.12)),
  'hip-p': side(2600, ['bench-back', 'barbell-hips'], upDown({ px: 104, py: FLOOR - 16, t: -62, hL: 70, hR: 70, kL: 100, kR: 100, sL: 20, sR: 20, eL: 110, eR: 110, n: 25 }, { px: 104, py: FLOOR - 38, t: -82, hL: 12, hR: 12, kL: 100, kR: 100, sL: 20, sR: 20, eL: 110, eR: 110, n: 30 }, 0.05, 0.12)),
  'prsti-n': side(2200, ['calf', 'barbell-shoulders'], upDown({ ...stand, sL: 60, sR: 60, eL: 120, eR: 120 }, { ...stand, py: STAND_Y - 8, aL: 38, aR: 38, sL: 60, sR: 60, eL: 120, eR: 120 }, 0.05, 0.15)),
  'kabel-zasuk': front(2200, ['cable-mid'], [
    { at: 0, p: { abL: 70, abR: 70, eL: 20, eR: 20, wL: 16, wR: 16, kL: 25, kR: 25, tw: -16, lean: -4 } },
    { at: 0.5, p: { abL: 70, abR: 70, eL: 20, eR: 20, wL: 16, wR: 16, kL: 25, kR: 25, tw: 16, lean: 4 } },
    { at: 1, p: { abL: 70, abR: 70, eL: 20, eR: 20, wL: 16, wR: 16, kL: 25, kR: 25, tw: -16, lean: -4 } },
  ]),
  bradlja: side(2800, ['bars-dip', 'nofloor'], upDown({ px: 100, py: 104, t: 0, sL: -15, sR: -15, eL: 0, eR: 0, hL: 6, hR: 6, kL: 10, kR: 10, aL: 30, aR: 30 }, { px: 100, py: 104, t: -5, sL: -15, sR: -15, eL: 0, eR: 0, hL: 100, hR: 100, kL: 100, kR: 100, aL: 30, aR: 30 }, 0.05, 0.1)),
  valjcek: side(3000, ['wheel'], upDown({ px: 92, py: FLOOR - 34, t: 20, hL: 70, hR: 70, kL: 100, kR: 100, aL: 90, aR: 90, sL: 100, sR: 100, eL: 0, eR: 0, n: -10 }, { px: 106, py: FLOOR - 22, t: 70, hL: 20, hR: 20, kL: 100, kR: 100, aL: 90, aR: 90, sL: 165, sR: 165, eL: 0, eR: 0, n: -20 }, 0.05, 0.1)),
  hiper: side(2800, ['hyper'], upDown({ px: 92, py: FLOOR - 50, t: 88, hL: 0, hR: 0, kL: 0, kR: 0, sL: 30, sR: 30, eL: 120, eR: 120, n: -10 }, { px: 92, py: FLOOR - 50, t: 88, hL: 70, hR: 70, kL: 0, kR: 0, sL: 30, sR: 30, eL: 120, eR: 120, n: -30 }, 0.05, 0.1)),
  veslo: side(2400, ['erg'], [
    { at: 0, p: { px: 118, py: FLOOR - 36, t: 20, hL: 120, hR: 120, kL: 125, kR: 125, aL: 20, aR: 20, sL: 95, sR: 95, eL: 0, eR: 0, n: -5 } },
    { at: 0.45, p: { px: 90, py: FLOOR - 36, t: -14, hL: 100, hR: 100, kL: 8, kR: 8, aL: 10, aR: 10, sL: 20, sR: 20, eL: 120, eR: 120 } },
    { at: 0.6, p: { px: 90, py: FLOOR - 36, t: -14, hL: 100, hR: 100, kL: 8, kR: 8, aL: 10, aR: 10, sL: 20, sR: 20, eL: 120, eR: 120 } },
    { at: 1, p: { px: 118, py: FLOOR - 36, t: 20, hL: 120, hR: 120, kL: 125, kR: 125, aL: 20, aR: 20, sL: 95, sR: 95, eL: 0, eR: 0, n: -5 } },
  ]),
  /* --- kardio in počitek --- */
  tek: { ...side(720, [], [{ at: 0, p: gaitPose(RUN, 0) }]), gen: u => gaitPose(RUN, u) },
  hoja: { ...side(1150, [], [{ at: 0, p: gaitPose(WALK, 0) }]), gen: u => gaitPose(WALK, u) },
  kolo: { ...side(860, ['bike'], [{ at: 0, p: bikePose(0) }]), gen: bikePose },
  /** počitek: stoji, diha, roke sproščene (ramena se dvignejo z vdihom) */
  pavza: side(4000, [], upDown({ ...stand, sL: 6, sR: 6, eL: 8, eR: 8, kL: 3, kR: 3 }, { ...stand, py: STAND_Y - 2, sL: 10, sR: 10, eL: 12, eR: 12, n: -4 })),
}

/** vaje, ki nimajo svoje predloge, uporabijo najbližjo po vzorcu */
export function templateFor(id: string | null | undefined, fallback: 'pavza' | 'tek' | 'kolo' | 'hoja' = 'pavza'): Template {
  return (id && TEMPLATES[id]) || TEMPLATES[fallback]!
}
