import { useEffect, useState } from 'react'
import { hasPhoto, photoUrl, PORTRAIT } from './photos'
import { ExerciseFigure } from './ExerciseFigure'

/**
 * Prikaz vaje: fotografiji začetnega in končnega položaja se izmenjujeta v zanki (oseba vajo izvaja ponovno in
 * ponovno); brez fotografij ali ob napaki nalaganja vektorska figura. `playing` false = samo začetni položaj.
 */
export function ExercisePhoto({ id, size = 300, label, playing = true, className, fallback = 'pavza', ratio = 2 / 3, vector = true, lazy = true }: {
  id?: string | null; size?: number; label?: string; playing?: boolean; className?: string; fallback?: 'pavza' | 'tek' | 'kolo' | 'hoja'
  /** višina / širina okvirja (fotografija se obreže) */
  ratio?: number
  /** brez fotografij: vektorska figura (true) ali nič (false) */
  vector?: boolean
  /** fotografija se naloži, ko pride blizu zaslona (v3.48: Vaje so naložile 116 slik naenkrat); vidne se naložijo takoj */
  lazy?: boolean
}) {
  const [err, setErr] = useState(false)
  useEffect(() => { setErr(false) }, [id])
  if (!hasPhoto(id) || err) return vector ? <ExerciseFigure id={id} size={Math.round(size * 0.8)} label={label} className={className} fallback={fallback} /> : null
  const portrait = PORTRAIT.has(id)
  return (
    <div className={`exph${playing ? ' on' : ''}${portrait ? ' portrait' : ''}${className ? ` ${className}` : ''}`} style={{ width: size, height: Math.round(size * (portrait ? 1.1 : ratio)) }} role="img" aria-label={label || 'Prikaz vaje'}>
      <img className="exph-a" src={photoUrl(id, 0)} alt="" decoding="async" loading={lazy ? 'lazy' : undefined} onError={() => setErr(true)} />
      <img className="exph-b" src={photoUrl(id, 1)} alt="" decoding="async" loading={lazy ? 'lazy' : undefined} onError={() => setErr(true)} />
      <i className="exph-dot" aria-hidden="true" />
    </div>
  )
}

/** vnaprej naloži fotografiji (npr. naslednje vaje med pavzo) */
export function preloadPhotos(id: string | null | undefined) {
  if (!hasPhoto(id)) return
  for (const i of [0, 1] as const) { const im = new Image(); im.src = photoUrl(id, i) }
}
