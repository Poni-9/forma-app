/**
 * Animirana figura vadbe (Blaž, 12. 10.: »da se vidi prava oseba s pravimi predmeti, kako točno delati, ponovno in
 * ponovno«). Brez slik in videov: artikulirana figura v stranskem (sagitalnem) ali sprednjem pogledu, sklepi z
 * naravnimi koti, oprema (ročke, palica, klop, drog, kabel, elastika, naprave) narisana kot vektorji.
 *
 * Stranski pogled: figura gleda v desno. Poza = položaj medenice, kot trupa in relativni koti sklepov (stopinje):
 *   t   — trup od navpičnice (0 pokonci, +90 glava v desno vodoravno, −90 glava v levo: leže na hrbtu)
 *   h   — upogib kolka (0 noga v liniji s trupom, + = koleno naprej)
 *   k   — upogib kolena (0 iztegnjeno, + = peta nazaj)
 *   s   — dvig rame (0 roka ob telesu, 90 naprej, 180 nad glavo)
 *   e   — upogib komolca (0 iztegnjeno, + = dlan naprej/gor)
 *   a   — gleženj (0 stopalo v podaljšku golenice navzdol … tu: 0 = stopalo ravno naprej, + = prsti dol)
 *   n   — vrat (nagib glave, + naprej)
 * Vse se zavrti s trupom, zato ista matematika velja stoje, leže, v opori in v visenju.
 */
export interface SidePose {
  px: number; py: number; t: number
  hL: number; hR: number; kL: number; kR: number
  sL: number; sR: number; eL: number; eR: number
  aL: number; aR: number; n: number
}
export interface FrontPose {
  px: number; py: number
  /** odmik rok od telesa v čelni ravnini (0 ob telesu, 90 vodoravno, 180 nad glavo) */
  abL: number; abR: number
  /** upogib komolca v čelni ravnini (+ = podlaket proti sredini/gor) */
  eL: number; eR: number
  /** razkorak (px od sredine) in upogib kolen (skrajšanje) */
  wL: number; wR: number; kL: number; kR: number
  /** zasuk trupa (px premika ramen) in nagib (deg) */
  tw: number; lean: number
}
export type Pose = SidePose | FrontPose
export const isFront = (p: Pose): p is FrontPose => 'abL' in p

export const L = { torso: 46, head: 10, neck: 15, thigh: 34, shin: 32, foot: 12, upper: 26, fore: 24, shoulderW: 15 } as const
export const FLOOR = 172

export type Pt = { x: number; y: number }
const rot = (v: Pt, deg: number): Pt => { const r = (deg * Math.PI) / 180, c = Math.cos(r), s = Math.sin(r); return { x: v.x * c - v.y * s, y: v.x * s + v.y * c } }
const add = (a: Pt, b: Pt, k = 1): Pt => ({ x: a.x + b.x * k, y: a.y + b.y * k })
const dir = (deg: number): Pt => ({ x: Math.sin((deg * Math.PI) / 180), y: Math.cos((deg * Math.PI) / 180) })

export interface SideSkeleton {
  pelvis: Pt; shoulder: Pt; neck: Pt; head: Pt
  hipL: Pt; kneeL: Pt; ankleL: Pt; toeL: Pt
  hipR: Pt; kneeR: Pt; ankleR: Pt; toeR: Pt
  elbowL: Pt; wristL: Pt; elbowR: Pt; wristR: Pt
  /** smer »naprej« (prsi) in »gor« (glava) v zaslonu */
  fwd: Pt; up: Pt
}
/** Neposredna kinematika stranskega pogleda. */
export function sideFk(p: SidePose): SideSkeleton {
  const R = (v: Pt) => rot(v, p.t)
  const pelvis = { x: p.px, y: p.py }
  const up = R({ x: 0, y: -1 }), fwd = R({ x: 1, y: 0 })
  const shoulder = add(pelvis, up, L.torso)
  const neck = add(shoulder, R(dir(180 - p.n)), L.neck * 0.45)
  const head = add(shoulder, R(dir(180 - p.n)), L.neck)
  const leg = (h: number, k: number, a: number) => {
    const hip = pelvis
    const knee = add(hip, R(dir(h)), L.thigh)
    const ankle = add(knee, R(dir(h - k)), L.shin)
    // stopalo: pravokotno na golenico naprej (+ a = prsti dol)
    const toe = add(ankle, R(dir(h - k + 90 - a)), L.foot)
    return { hip, knee, ankle, toe }
  }
  const arm = (s: number, e: number) => {
    const elbow = add(shoulder, R(dir(s)), L.upper)
    const wrist = add(elbow, R(dir(s + e)), L.fore)
    return { elbow, wrist }
  }
  const lL = leg(p.hL, p.kL, p.aL), lR = leg(p.hR, p.kR, p.aR), aL = arm(p.sL, p.eL), aR = arm(p.sR, p.eR)
  return { pelvis, shoulder, neck, head, hipL: lL.hip, kneeL: lL.knee, ankleL: lL.ankle, toeL: lL.toe, hipR: lR.hip, kneeR: lR.knee, ankleR: lR.ankle, toeR: lR.toe, elbowL: aL.elbow, wristL: aL.wrist, elbowR: aR.elbow, wristR: aR.wrist, fwd, up }
}

export interface FrontSkeleton {
  pelvis: Pt; shoulder: Pt; head: Pt
  shL: Pt; shR: Pt; elbowL: Pt; wristL: Pt; elbowR: Pt; wristR: Pt
  hipL: Pt; kneeL: Pt; ankleL: Pt; hipR: Pt; kneeR: Pt; ankleR: Pt
}
/** Neposredna kinematika sprednjega pogleda (gledalec gleda osebo od spredaj; »L« je na levi strani zaslona). */
export function frontFk(p: FrontPose): FrontSkeleton {
  const pelvis = { x: p.px, y: p.py }
  const lean = rot({ x: 0, y: -1 }, p.lean)
  const shoulder = add(pelvis, lean, L.torso)
  const head = add(shoulder, lean, L.neck)
  const shL = { x: shoulder.x - L.shoulderW + p.tw, y: shoulder.y }, shR = { x: shoulder.x + L.shoulderW + p.tw, y: shoulder.y }
  // roka: ab = odmik od telesa navzven; komolec se upogne proti sredini (gor pri odmiku 90)
  const arm = (sh: Pt, ab: number, e: number, sideSign: number) => {
    const u = { x: Math.sin((ab * Math.PI) / 180) * sideSign, y: Math.cos((ab * Math.PI) / 180) }
    const elbow = add(sh, u, L.upper)
    const fa = rot(u, -e * sideSign)
    const wrist = add(elbow, fa, L.fore)
    return { elbow, wrist }
  }
  const aL = arm(shL, p.abL, p.eL, -1), aR = arm(shR, p.abR, p.eR, 1)
  // noge sledijo nagibu trupa (stranska deska: telo vodoravno)
  const down = rot({ x: 0, y: 1 }, p.lean), across = rot({ x: 1, y: 0 }, p.lean)
  const leg = (w: number, k: number) => {
    const hip = add(pelvis, across, w * 0.35)
    const sh = 1 - Math.min(0.55, k / 220)   // skrajšanje pri upogibu
    const knee = add(add(hip, across, w * 0.35), down, L.thigh * sh)
    const ankle = add(add(hip, across, w * 0.6), down, L.thigh * sh + L.shin * sh)
    return { hip, knee, ankle }
  }
  const lL = leg(-p.wL, p.kL), lR = leg(p.wR, p.kR)
  return { pelvis, shoulder, head, shL, shR, elbowL: aL.elbow, wristL: aL.wrist, elbowR: aR.elbow, wristR: aR.wrist, hipL: lL.hip, kneeL: lL.knee, ankleL: lL.ankle, hipR: lR.hip, kneeR: lR.knee, ankleR: lR.ankle }
}

export const SIDE0: SidePose = { px: 96, py: FLOOR - L.thigh - L.shin, t: 0, hL: 0, hR: 0, kL: 0, kR: 0, sL: 0, sR: 0, eL: 0, eR: 0, aL: 0, aR: 0, n: 0 }
export const FRONT0: FrontPose = { px: 100, py: FLOOR - L.thigh - L.shin, abL: 8, abR: 8, eL: 0, eR: 0, wL: 9, wR: 9, kL: 0, kR: 0, tw: 0, lean: 0 }

/** gladka interpolacija (ease-in-out) med pozami */
export const smooth = (x: number) => x * x * (3 - 2 * x)
export function lerpPose<T extends Pose>(a: T, b: T, k: number): T {
  const out = { ...a } as Record<string, number>
  for (const key of Object.keys(a) as (keyof T)[]) out[key as string] = (a[key] as number) + ((b[key] as number) - (a[key] as number)) * k
  return out as unknown as T
}
