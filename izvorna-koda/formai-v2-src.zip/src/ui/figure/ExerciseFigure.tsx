import { useEffect, useMemo, useRef, useState } from 'react'
import { FLOOR, FRONT0, SIDE0, frontFk, sideFk, lerpPose, smooth, isFront, type Pose, type Pt, type SidePose, type FrontPose, type SideSkeleton, type FrontSkeleton } from './rig'
import { templateFor, CRANK, type Template, type Equip, type Frame } from './templates'

/**
 * Animirana figura, ki vajo izvaja ponovno in ponovno (zanka), z opremo. Ena SVG slika, kinematika v `rig.ts`,
 * poze v `templates.ts`. Pri zmanjšanem gibanju stoji v srednji pozi.
 */
export function ExerciseFigure({ id, fallback = 'pavza', size = 220, playing = true, className, label, fit = false }: {
  id?: string | null; fallback?: 'pavza' | 'tek' | 'kolo' | 'hoja'; size?: number; playing?: boolean; className?: string; label?: string
  /** (v3.50) okvir obrezan na telo: ležeča vaja (deska, hrošč) brez ~100 px praznine nad figuro (list vaje) */
  fit?: boolean
}) {
  const tpl = useMemo(() => templateFor(id, fallback), [id, fallback])
  const y0 = useMemo(() => (fit ? topOf(tpl) : 0), [tpl, fit])
  const [phase, setPhase] = useState(0)
  const t0 = useRef<number | null>(null)
  // izven zaslona brez animacije (v3.48): na Vajah je bilo 10 figur z requestAnimationFrame hkrati, tudi neviden
  const ref = useRef<SVGSVGElement>(null)
  const [seen, setSeen] = useState(() => typeof IntersectionObserver === 'undefined')
  useEffect(() => {
    const el = ref.current
    if (!el || typeof IntersectionObserver === 'undefined') return
    const io = new IntersectionObserver(es => { const e = es[es.length - 1]; if (e) setSeen(e.isIntersecting) }, { rootMargin: '80px' })
    io.observe(el)
    return () => io.disconnect()
  }, [])
  useEffect(() => {
    const reduce = typeof matchMedia !== 'undefined' && matchMedia('(prefers-reduced-motion: reduce)').matches
    if (reduce) { setPhase(0.25); return }
    if (!playing || !seen) return
    let raf = 0
    const tick = (t: number) => { if (t0.current == null) t0.current = t; setPhase(((t - t0.current) % tpl.dur) / tpl.dur); raf = requestAnimationFrame(tick) }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [tpl, playing, seen])
  useEffect(() => { t0.current = null }, [tpl])
  const pose = useMemo(() => poseAt(tpl, phase), [tpl, phase])
  return (
    <svg ref={ref} className={`fig${className ? ` ${className}` : ''}`} viewBox={`0 ${y0} 200 ${184 - y0}`} width={size} height={Math.round(size * ((184 - y0) / 200))} role="img" aria-label={label || 'Prikaz vaje'}>
      {isFront(pose) ? <FrontBody p={pose} equip={tpl.equip} /> : <SideBody p={pose} equip={tpl.equip} phase={phase} />}
    </svg>
  )
}

/** rekviziti, ki segajo nad telo (drog, kabel, ergometer …) — tam okvir ostane cel */
const TALL: readonly Equip[] = ['bar', 'bars-dip', 'cable-top', 'cable-mid', 'cable-low', 'band-mid', 'erg', 'pecdeck', 'bike', 'rope', 'legpress', 'legcurl', 'bench-incline']
/** (v3.50) zgornji rob telesa čez zanko (najvišja točka okostja − glava in rob), 0 = brez obreza */
export function topOf(tpl: Template): number {
  if (tpl.equip.some(e => TALL.includes(e))) return 0
  let top = 184
  for (const ph of [0, 0.25, 0.5, 0.75]) {
    const p = poseAt(tpl, ph)
    const s = (isFront(p) ? frontFk(p) : sideFk(p)) as unknown as Record<string, unknown>
    for (const v of Object.values(s)) {
      const q = v as Pt
      if (q && typeof q === 'object' && typeof q.y === 'number' && (Math.abs(q.x) > 1.5 || Math.abs(q.y) > 1.5)) top = Math.min(top, q.y)
    }
  }
  return Math.max(0, Math.min(120, Math.floor(top - 16)))
}

/** ista figura ob izbrani fazi (brez animacije) — za predogled in preverjanje gibanja */
export function ExerciseFigureAt({ id, fallback = 'pavza', phase, size = 220 }: { id?: string | null; fallback?: 'pavza' | 'tek' | 'kolo' | 'hoja'; phase: number; size?: number }) {
  const tpl = templateFor(id, fallback)
  const pose = poseAt(tpl, phase)
  return (
    <svg className="fig" viewBox="0 0 200 184" width={size} height={size * 0.92} role="img" aria-label="Prikaz vaje">
      {isFront(pose) ? <FrontBody p={pose} equip={tpl.equip} /> : <SideBody p={pose} equip={tpl.equip} phase={phase} />}
    </svg>
  )
}

/** poza ob fazi zanke 0–1 (gladko med sosednjima ključnima pozama) */
export function poseAt(tpl: Template, phase: number): Pose {
  if (tpl.rig === 'side' && tpl.gen) return tpl.gen(Math.max(0, Math.min(0.999999, phase)))
  const base = tpl.rig === 'side' ? SIDE0 : FRONT0
  const frames = (tpl.frames as Frame<Pose>[]).map(f => ({ at: f.at, p: { ...base, ...f.p } as Pose }))
  if (frames[frames.length - 1]!.at < 1) frames.push({ at: 1, p: frames[0]!.p })
  const u = Math.max(0, Math.min(0.999999, phase))
  let i = 0
  while (i < frames.length - 2 && frames[i + 1]!.at <= u) i++
  const a = frames[i]!, b = frames[i + 1]!
  const span = Math.max(1e-6, b.at - a.at)
  return lerpPose(a.p, b.p, smooth((u - a.at) / span))
}

/* ------------------------------------------------------------------ risanje ------------------------------------------------------------------ */
const P = (p: Pt) => `${p.x.toFixed(1)} ${p.y.toFixed(1)}`
const path = (...pts: Pt[]) => pts.map((p, i) => `${i ? 'L' : 'M'}${P(p)}`).join(' ')
const unit = (a: Pt, b: Pt): Pt => { const dx = b.x - a.x, dy = b.y - a.y, l = Math.hypot(dx, dy) || 1; return { x: dx / l, y: dy / l } }
const off = (p: Pt, d: Pt, k: number): Pt => ({ x: p.x + d.x * k, y: p.y + d.y * k })
const mid = (a: Pt, b: Pt): Pt => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 })

/** ud: debela črta z zaobljenimi konci (dva segmenta skozi sklep) */
function Limb({ a, b, c, w, cls }: { a: Pt; b: Pt; c?: Pt; w: number; cls: string }) {
  return <path className={cls} d={c ? path(a, b, c) : path(a, b)} strokeWidth={w} fill="none" strokeLinecap="round" strokeLinejoin="round" />
}

function Floor({ x, shadowW }: { x: number; shadowW: number }) {
  return <>
    <line className="fig-floor" x1="6" y1={FLOOR + 7} x2="194" y2={FLOOR + 7} />
    <ellipse className="fig-shadow" cx={x} cy={FLOOR + 7} rx={shadowW} ry="3.5" />
  </>
}

function SideBody({ p, equip, phase }: { p: SidePose; equip: Equip[]; phase: number }) {
  const s = sideFk(p)
  const has = (e: Equip) => equip.includes(e)
  const floor = !has('nofloor')
  const back: Pt = { x: -s.fwd.x, y: -s.fwd.y }
  const headTop = off(s.head, s.up, 10)
  const shadowX = (Math.min(s.ankleL.x, s.ankleR.x, s.wristL.x, s.pelvis.x) + Math.max(s.ankleL.x, s.ankleR.x, s.wristL.x, s.pelvis.x)) / 2
  // ročke, palice: krog (plošča) ob dlani
  const plate = (at: Pt, r: number, key: string) => <g key={key}><circle className="fig-plate" cx={at.x} cy={at.y} r={r} /><circle className="fig-plate-in" cx={at.x} cy={at.y} r={r * 0.38} /></g>
  const handle = (at: Pt, key: string) => <circle key={key} className="fig-handle" cx={at.x} cy={at.y} r="3.2" />
  const behind: React.ReactNode[] = [], front: React.ReactNode[] = []
  // --- rekviziti za figuro ---
  if (has('bar')) behind.push(<g key="bar"><line className="fig-steel" x1="34" y1="8" x2="34" y2={FLOOR + 7} /><line className="fig-steel" x1="166" y1="8" x2="166" y2={FLOOR + 7} /><line className="fig-steel-thick" x1="30" y1={s.wristL.y} x2="170" y2={s.wristL.y} /></g>)
  if (has('bars-dip')) behind.push(<g key="bars"><line className="fig-steel" x1={s.wristL.x} y1={s.wristL.y} x2={s.wristL.x} y2={FLOOR + 7} /><line className="fig-steel" x1={s.wristL.x + 30} y1={s.wristL.y} x2={s.wristL.x + 30} y2={FLOOR + 7} /><line className="fig-steel-thick" x1={s.wristL.x - 14} y1={s.wristL.y} x2={s.wristL.x + 44} y2={s.wristL.y} /></g>)
  if (has('cable-top') || has('cable-mid') || has('cable-low')) {
    const py = has('cable-top') ? 14 : has('cable-mid') ? s.wristL.y : FLOOR - 14
    const px = 182
    behind.push(<g key="cable"><line className="fig-steel-thick" x1={px} y1="6" x2={px} y2={FLOOR + 7} /><circle className="fig-pulley" cx={px} cy={py} r="5" /><line className="fig-cable" x1={px} y1={py} x2={s.wristL.x} y2={s.wristL.y} /><line className="fig-steel-thick" x1={s.wristL.x - 5} y1={s.wristL.y} x2={s.wristL.x + 5} y2={s.wristL.y} /></g>)
  }
  if (has('band-low')) { const a = mid(s.toeL, s.toeR); behind.push(<g key="band"><path className="fig-band" d={`M${P(a)} Q ${a.x + 6} ${(a.y + s.wristL.y) / 2} ${P(s.wristL)}`} /><path className="fig-band fig-far" d={`M${P(a)} Q ${a.x + 4} ${(a.y + s.wristR.y) / 2} ${P(s.wristR)}`} /></g>) }
  if (has('band-mid')) { const a = { x: 188, y: s.wristL.y + 4 }; behind.push(<g key="band"><line className="fig-steel" x1="188" y1="40" x2="188" y2={FLOOR + 7} /><path className="fig-band" d={`M${P(a)} Q ${(a.x + s.wristL.x) / 2} ${a.y + 6} ${P(s.wristL)}`} /></g>) }
  if (has('bench-flat') || has('bench-incline')) {
    const a = off(off(s.pelvis, s.up, -14), back, 9), b = off(off(s.head, s.up, 2), back, 9)
    behind.push(<g key="bench"><line className="fig-bench" x1={a.x} y1={a.y} x2={b.x} y2={b.y} /><line className="fig-steel" x1={a.x + (has('bench-incline') ? 12 : 8)} y1={a.y + 3} x2={a.x + 12} y2={FLOOR + 7} /><line className="fig-steel" x1={b.x + 12} y1={b.y + 3} x2={b.x + 12} y2={FLOOR + 7} /></g>)
    if (has('bench-incline')) { const c = off(off(s.pelvis, s.up, -14), back, 9), d = off(off(s.kneeL, s.up, 0), back, 9); behind.push(<line key="seat" className="fig-bench" x1={c.x} y1={c.y} x2={d.x - 4} y2={c.y} />) }
  }
  if (has('box-back')) behind.push(<rect key="bk" className="fig-box" x={s.ankleR.x - 16} y={s.ankleR.y + 3} width="30" height={Math.max(6, FLOOR + 7 - s.ankleR.y - 3)} rx="3" />)
  if (has('bench-support')) { const top = Math.min(s.wristR.y, s.kneeR.y) + 3; behind.push(<g key="bsup"><rect className="fig-box" x={Math.min(s.wristR.x, s.kneeR.x) - 14} y={top} width={Math.abs(s.wristR.x - s.kneeR.x) + 28} height="7" rx="3" /><line className="fig-steel" x1={Math.min(s.wristR.x, s.kneeR.x) - 6} y1={top + 7} x2={Math.min(s.wristR.x, s.kneeR.x) - 6} y2={FLOOR + 7} /><line className="fig-steel" x1={Math.max(s.wristR.x, s.kneeR.x) + 6} y1={top + 7} x2={Math.max(s.wristR.x, s.kneeR.x) + 6} y2={FLOOR + 7} /></g>) }
  if (has('bench-back')) behind.push(<rect key="bb" className="fig-box" x={s.shoulder.x - 50} y={Math.min(FLOOR - 4, s.shoulder.y + 2)} width="46" height={Math.max(6, FLOOR + 7 - Math.min(FLOOR - 4, s.shoulder.y + 2))} rx="3" />)
  if (has('box-feet')) behind.push(<rect key="bf" className="fig-box" x={s.ankleL.x - 14} y={s.ankleL.y + 2} width="28" height={Math.max(6, FLOOR + 7 - s.ankleL.y - 2)} rx="3" />)
  if (has('box-front')) behind.push(<rect key="bx" className="fig-box" x="98" y={FLOOR - 24} width="46" height="31" rx="3" />)
  if (has('chair')) behind.push(<rect key="ch" className="fig-box" x={s.wristL.x - 16} y={s.wristL.y + 2} width="32" height={Math.max(6, FLOOR + 7 - s.wristL.y - 2)} rx="3" />)
  if (has('legpress')) { const d = unit(s.kneeL, s.ankleL); const n = { x: -d.y, y: d.x }; const t = off(s.toeL, d, 2); behind.push(<g key="lp"><line className="fig-bench" x1={t.x + n.x * 26} y1={t.y + n.y * 26} x2={t.x - n.x * 26} y2={t.y - n.y * 26} /><line className="fig-bench" x1={off(s.pelvis, back, 9).x} y1={off(s.pelvis, back, 9).y} x2={off(s.head, back, 9).x} y2={off(s.head, back, 9).y} /><line className="fig-steel" x1={s.pelvis.x - 10} y1={s.pelvis.y + 8} x2={s.pelvis.x - 10} y2={FLOOR + 7} /></g>) }
  if (has('legext')) behind.push(<g key="le"><rect className="fig-box" x={s.pelvis.x - 22} y={s.pelvis.y + 8} width="50" height={FLOOR - 1 - s.pelvis.y} rx="3" /><line className="fig-bench" x1={off(s.pelvis, back, 9).x} y1={off(s.pelvis, back, 9).y} x2={off(s.head, back, 9).x} y2={off(s.head, back, 9).y} /><circle className="fig-pad" cx={s.ankleL.x} cy={s.ankleL.y} r="6" /></g>)
  if (has('legcurl')) behind.push(<g key="lc"><line className="fig-bench" x1={off(s.pelvis, back, 9).x - 10} y1={FLOOR - 28} x2={s.head.x + 6} y2={FLOOR - 28} /><line className="fig-steel" x1={s.head.x - 4} y1={FLOOR - 26} x2={s.head.x - 4} y2={FLOOR + 7} /><line className="fig-steel" x1={s.pelvis.x} y1={FLOOR - 26} x2={s.pelvis.x} y2={FLOOR + 7} /><circle className="fig-pad" cx={s.ankleL.x} cy={s.ankleL.y - 4} r="6" /></g>)
  if (has('hyper')) behind.push(<g key="hy"><rect className="fig-pad-box" x={s.pelvis.x - 14} y={s.pelvis.y + 6} width="24" height="10" rx="4" /><line className="fig-steel" x1={s.pelvis.x} y1={s.pelvis.y + 16} x2={s.pelvis.x} y2={FLOOR + 7} /><rect className="fig-pad-box" x={s.ankleL.x - 6} y={s.ankleL.y - 10} width="12" height="8" rx="3" /><line className="fig-steel" x1={s.ankleL.x} y1={s.ankleL.y - 2} x2={s.ankleL.x} y2={FLOOR + 7} /></g>)
  if (has('calf')) behind.push(<rect key="cf" className="fig-box" x={s.toeL.x - 10} y={FLOOR - 2} width="22" height="9" rx="2" />)
  if (has('erg')) behind.push(<g key="erg"><line className="fig-steel-thick" x1="30" y1={FLOOR - 30} x2="186" y2={FLOOR - 30} /><rect className="fig-box" x={s.pelvis.x - 10} y={s.pelvis.y + 6} width="20" height="6" rx="2" /><line className="fig-steel" x1="40" y1={FLOOR - 30} x2="40" y2={FLOOR + 7} /><line className="fig-steel" x1="176" y1={FLOOR - 30} x2="176" y2={FLOOR + 7} /><circle className="fig-pulley" cx="178" cy={FLOOR - 46} r="12" /><line className="fig-cable" x1="178" y1={FLOOR - 46} x2={s.wristL.x} y2={s.wristL.y} /><rect className="fig-pad-box" x={s.toeL.x - 4} y={s.toeL.y - 12} width="8" height="14" rx="2" /></g>)
  if (has('bike')) {
    const r = 20, cy = FLOOR - 13, w1 = { x: 56, y: cy }, w2 = { x: 158, y: cy }, crank = CRANK
    // napere se vrtijo z vrtenjem pedal (2 obrata kolesa na obrat pedal) — kolo res pelje
    const a = phase * 720
    const spokes = (w: Pt, k: string) => <g key={k} className="fig-spokes" transform={`rotate(${a.toFixed(1)} ${w.x} ${w.y})`}>{[0, 60, 120].map(d => { const rad = (d * Math.PI) / 180, dx = Math.cos(rad) * (r - 2), dy = Math.sin(rad) * (r - 2); return <line key={d} x1={w.x - dx} y1={w.y - dy} x2={w.x + dx} y2={w.y + dy} /> })}<circle cx={w.x} cy={w.y} r="2.6" /></g>
    // pedal pod blazinico stopala (2/3 stopala od gležnja) — gonilka ga drži na krogu
    const pedal = (ank: Pt, toe: Pt) => ({ x: ank.x + (toe.x - ank.x) * (8 / 12), y: ank.y + (toe.y - ank.y) * (8 / 12) })
    const pL = pedal(s.ankleL, s.toeL), pR = pedal(s.ankleR, s.toeR)
    const seat = { x: s.pelvis.x - 2, y: s.pelvis.y + 6 }, bar = { x: s.wristL.x - 4, y: s.wristL.y + 6 }
    behind.push(<g key="bike">
      <line className="fig-steel fig-far-crank" x1={crank.x} y1={crank.y} x2={pR.x} y2={pR.y} />
      <line className="fig-steel-thick fig-far-crank" x1={pR.x - 3} y1={pR.y} x2={pR.x + 3} y2={pR.y} />
      {spokes(w1, 's1')}{spokes(w2, 's2')}
      <circle className="fig-wheel" cx={w1.x} cy={w1.y} r={r} /><circle className="fig-wheel" cx={w2.x} cy={w2.y} r={r} />
      <path className="fig-frame" d={`M${P(w1)} L${P(crank)} L${P(seat)} L${P(w1)} M${P(crank)} L${P(bar)} L${P(w2)} M${P(seat)} L${P(bar)}`} />
      <line className="fig-steel-thick" x1={s.pelvis.x - 10} y1={seat.y} x2={s.pelvis.x + 6} y2={seat.y} />
      <line className="fig-steel-thick" x1={s.wristL.x - 8} y1={bar.y} x2={s.wristL.x + 8} y2={bar.y} />
      <circle className="fig-ring" cx={crank.x} cy={crank.y} r="6.5" />
      <line className="fig-steel" x1={crank.x} y1={crank.y} x2={pL.x} y2={pL.y} />
      <line className="fig-steel-thick" x1={pL.x - 3.5} y1={pL.y} x2={pL.x + 3.5} y2={pL.y} />
    </g>)
  }
  if (has('rope')) { const k = Math.sin(phase * Math.PI * 2); const top = headTop.y - 12 - 8 * k, bot = FLOOR + 5 + 4 * k; behind.push(<path key="rope" className="fig-band" d={`M${P(s.wristL)} C ${s.wristL.x + 46} ${top} ${s.wristL.x - 46} ${top} ${P(s.wristR)} M${P(s.wristL)} C ${s.wristL.x + 40} ${bot} ${s.wristL.x - 40} ${bot} ${P(s.wristR)}`} />) }
  if (has('wheel')) front.push(<g key="wh"><circle className="fig-wheel" cx={s.wristL.x} cy={s.wristL.y + 7} r="8" /><line className="fig-steel-thick" x1={s.wristL.x - 7} y1={s.wristL.y} x2={s.wristL.x + 7} y2={s.wristL.y} /></g>)
  // uteži ob dlaneh
  if (has('dumbbells')) { behind.push(plate(s.wristR, 7, 'dR')); front.push(plate(s.wristL, 7, 'dL')) }
  if (has('dumbbell-near')) front.push(plate(s.wristL, 7, 'dL'))
  if (has('barbell-hands')) front.push(plate(s.wristL, 13, 'bb'))
  if (has('barbell-shoulders')) front.push(plate(off(s.shoulder, back, 5), 13, 'bs'))
  if (has('barbell-hips')) front.push(plate(off(s.pelvis, s.fwd, 6), 12, 'bh'))
  if (has('dumbbell-hips')) front.push(plate(off(s.pelvis, s.fwd, 6), 7, 'dh'))
  if (has('goblet')) front.push(plate(mid(s.wristL, s.wristR), 7, 'gb'))
  if (has('kettlebell')) { const d = unit(s.elbowL, s.wristL); const at = off(s.wristL, d, 11); front.push(<g key="kb"><path className="fig-steel" d={`M${P(s.wristL)} L${P(at)}`} /><circle className="fig-plate" cx={at.x} cy={at.y} r="8" /></g>) }

  return <>
    {floor && <Floor x={shadowX} shadowW={34} />}
    {behind}
    {/* oddaljena stran (temneje), nato trup in glava, nato bližnja stran */}
    <Limb a={s.hipR} b={s.kneeR} c={s.ankleR} w={9} cls="fig-limb fig-far" />
    <Limb a={s.ankleR} b={s.toeR} w={7} cls="fig-limb fig-far" />
    <Limb a={s.shoulder} b={s.elbowR} c={s.wristR} w={8} cls="fig-limb fig-far" />
    <Limb a={off(s.pelvis, s.up, -4)} b={off(s.shoulder, s.up, -2)} w={15} cls="fig-torso" />
    <Limb a={s.shoulder} b={s.neck} w={7} cls="fig-limb" />
    <circle className="fig-head" cx={s.head.x} cy={s.head.y} r="10" />
    <Limb a={s.hipL} b={s.kneeL} c={s.ankleL} w={10} cls="fig-limb" />
    <Limb a={s.ankleL} b={s.toeL} w={7} cls="fig-limb" />
    <Limb a={s.shoulder} b={s.elbowL} c={s.wristL} w={9} cls="fig-limb" />
    {front}
    {handle(s.wristL, 'hL')}
  </>
}

function FrontBody({ p, equip }: { p: FrontPose; equip: Equip[] }) {
  const s = frontFk(p)
  const has = (e: Equip) => equip.includes(e)
  const floor = !has('nofloor')
  const plate = (at: Pt, r: number, key: string) => <g key={key}><rect className="fig-plate" x={at.x - r} y={at.y - r * 0.45} width={r * 2} height={r * 0.9} rx={r * 0.3} /><rect className="fig-plate-in" x={at.x - r * 0.3} y={at.y - r * 0.2} width={r * 0.6} height={r * 0.4} rx={r * 0.1} /></g>
  const behind: React.ReactNode[] = [], front: React.ReactNode[] = []
  if (has('pecdeck')) behind.push(<g key="pd"><rect className="fig-box" x={s.pelvis.x - 24} y={s.pelvis.y + 6} width="48" height={FLOOR + 1 - s.pelvis.y} rx="3" /><rect className="fig-pad-box" x={s.wristL.x - 5} y={s.wristL.y - 16} width="10" height="32" rx="4" /><rect className="fig-pad-box" x={s.wristR.x - 5} y={s.wristR.y - 16} width="10" height="32" rx="4" /><line className="fig-steel" x1={s.wristL.x} y1={s.wristL.y - 16} x2={s.shoulder.x} y2={s.shoulder.y - 34} /><line className="fig-steel" x1={s.wristR.x} y1={s.wristR.y - 16} x2={s.shoulder.x} y2={s.shoulder.y - 34} /></g>)
  if (has('cable-mid')) { const m = mid(s.wristL, s.wristR); behind.push(<g key="cb"><line className="fig-steel-thick" x1="190" y1="6" x2="190" y2={FLOOR + 7} /><circle className="fig-pulley" cx="190" cy={m.y} r="5" /><line className="fig-cable" x1="190" y1={m.y} x2={m.x} y2={m.y} /></g>) }
  if (has('band-mid')) { const m = mid(s.wristL, s.wristR); behind.push(<g key="bd"><line className="fig-steel" x1="190" y1="30" x2="190" y2={FLOOR + 7} /><path className="fig-band" d={`M190 ${m.y + 2} Q ${(190 + m.x) / 2} ${m.y + 8} ${P(m)}`} /></g>) }
  if (has('band-front')) front.push(<path key="bf" className="fig-band" d={`M${P(s.wristL)} Q ${(s.wristL.x + s.wristR.x) / 2} ${s.wristL.y + 10} ${P(s.wristR)}`} />)
  if (has('band-legs')) front.push(<path key="bl" className="fig-band" d={`M${s.kneeL.x} ${s.kneeL.y + 4} Q ${(s.kneeL.x + s.kneeR.x) / 2} ${s.kneeL.y + 10} ${s.kneeR.x} ${s.kneeR.y + 4}`} />)
  if (has('dumbbells')) { front.push(plate(s.wristL, 8, 'dL')); front.push(plate(s.wristR, 8, 'dR')) }
  if (has('plate-chest')) front.push(<circle key="pc" className="fig-plate" cx={mid(s.wristL, s.wristR).x} cy={mid(s.wristL, s.wristR).y} r="8" />)
  if (has('dumbbell-chest')) front.push(plate(mid(s.wristL, s.wristR), 7, 'dc'))
  const shoulderLine = <Limb a={s.shL} b={s.shR} w={14} cls="fig-torso" />
  return <>
    {floor && <Floor x={s.pelvis.x} shadowW={26} />}
    {behind}
    <Limb a={s.hipR} b={s.kneeR} c={s.ankleR} w={10} cls="fig-limb" />
    <Limb a={s.hipL} b={s.kneeL} c={s.ankleL} w={10} cls="fig-limb" />
    <Limb a={{ x: s.pelvis.x, y: s.pelvis.y - 4 }} b={{ x: s.shoulder.x, y: s.shoulder.y - 2 }} w={22} cls="fig-torso" />
    {shoulderLine}
    <Limb a={s.shoulder} b={{ x: s.head.x, y: s.head.y - 2 }} w={7} cls="fig-limb" />
    <circle className="fig-head" cx={s.head.x} cy={s.head.y - 4} r="10" />
    <Limb a={s.shL} b={s.elbowL} c={s.wristL} w={9} cls="fig-limb" />
    <Limb a={s.shR} b={s.elbowR} c={s.wristR} w={9} cls="fig-limb" />
    {front}
    <circle className="fig-handle" cx={s.wristL.x} cy={s.wristL.y} r="3.2" /><circle className="fig-handle" cx={s.wristR.x} cy={s.wristR.y} r="3.2" />
  </>
}

export type { SideSkeleton, FrontSkeleton }
