import { useState } from 'react'
import { navigate } from '@/app/router'
import { useApp, setOffDays, toast } from '@/state/store'
import type { Focus, Muscle } from '@/domain/types'
import { weekContext } from '@/domain/training/planner'
import { addDays, weekStartIso } from '@/domain/training/load'
import { weekLine, mixLine, aimsLine, trainingDays } from '@/domain/focus/model'
import { WeekStrip } from '@/ui/WeekStrip'
import { PART_MUSCLES } from '@/domain/training/exercises'
import { Card, Btn } from '@/ui/primitives'
import { BodyMap } from '@/ui/BodyMap'
import { dm, count, W } from '@/ui/format'
import { daysLine } from '@/domain/focus/choices'

/** Ravni za zemljevid mišic iz dogovora: poudarek polno, kar trenirajo seje zmerno. */
export function focusLevels(f: Pick<Focus, 'sessions' | 'muscles'>): Partial<Record<Muscle, number>> {
  const out: Partial<Record<Muscle, number>> = {}
  for (const s of f.sessions) {
    const ms: Muscle[] = s.type === 'fitnes' || s.type === 'doma' ? PART_MUSCLES[s.part || 'celo'] : ['noge', 'zadnjica']
    for (const m of ms) out[m] = Math.max(out[m] ?? 0, 0.3)
  }
  for (const m of f.muscles) out[m] = 1
  return out
}

/**
 * »Moj dogovor« (načrt po meri): ime, teden, cilji, kje v 12 tednih si; v polni obliki še strategija, pojasnila
 * in zemljevid mišic. »Spremeni dogovor« odpre pogovor s trenerjem (#/dogovor).
 */
export function DealCard({ full = false, style }: { full?: boolean; style?: React.CSSProperties }) {
  const app = useApp()
  const f = app.profile.focus
  if (!f) return null
  const ws = weekStartIso(app.today)
  const cx = weekContext(app.profile, ws)
  const start = app.profile.cycleStart || ws
  // 12 tednov od začetka trenutnega bloka (bloki po 4)
  const blockStart = addDays(ws, -7 * ((cx.blockWeek || 1) - 1))
  const weeks = Array.from({ length: 12 }, (_, i) => addDays(blockStart, 7 * i)).map(w => ({ w, c: weekContext(app.profile, w) }))
  const strat = (f.strategy || '').split('\n').map(l => l.replace(/^[–-]\s*/, '').trim()).filter(Boolean)
  return (
    <Card className="deal-card" style={{ marginTop: full ? 0 : 12, ...style }}>
      <div className="row" style={{ gap: 12, alignItems: 'flex-start' }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <h2 className="h4" style={{ margin: 0 }}>Moj dogovor</h2>
          <b style={{ display: 'block', fontSize: 19, letterSpacing: '-.02em', marginTop: 4, color: 'var(--ink)' }}>{f.title}</b>
          <p style={{ fontSize: 12.5, marginTop: 3 }}>{weekLine(f)} · {mixLine(f)}</p>
          {(f.aims.length > 0 || f.muscles.length > 0) && <p className="muted" style={{ fontSize: 12, marginTop: 2 }}>{aimsLine(f)}</p>}
          {!full && !!f.offDays?.length && <p className="muted" style={{ fontSize: 12, marginTop: 2 }}>Ne gre: {daysLine(f.offDays)}</p>}
        </div>
        <BodyMap levels={focusLevels(f)} size={full ? 104 : 80} both={full} run={false} label={f.muscles.length ? `Poudarek: ${f.muscles.join(', ')}` : undefined} />
      </div>
      <div className="deal-weeks" role="img" aria-label={`Teden ${cx.week} od začetka, ${cx.recovery ? 'lažji teden' : `${cx.blockWeek}. teden bloka`}; vsak 4. teden je lažji.`}>
        {weeks.map(({ w, c }) => <i key={w} className={`${c.recovery ? 'easy' : ''}${w === ws ? ' now' : ''}${w < ws ? ' past' : ''}`} style={{ height: `${Math.round((c.volume / 1.08) * 100)}%` }} />)}
      </div>
      <div className="muted" style={{ fontSize: 11.5, fontWeight: 700, marginTop: 6 }}>Teden {cx.week} · {cx.recovery ? 'lažji teden' : cx.blockWeek === 1 ? 'nov blok' : cx.blockWeek === 3 ? 'najtežji v bloku' : 'rast'} · od {dm(start)}</div>
      {full && strat.length > 0 && (
        <ul className="deal-notes" style={{ marginTop: 12 }}>{strat.slice(0, 7).map((l, i) => <li key={i}>{l}</li>)}</ul>
      )}
      {full && !strat.length && <p style={{ fontSize: 12.5, marginTop: 10 }}>{cx.phaseDesc}</p>}
      {full && f.notes.length > 0 && <p className="muted" style={{ fontSize: 12, marginTop: 8 }}>{f.notes.slice(0, 3).join(' ')}</p>}
      {full && f.mode === 'meri' && <OffDays f={f} />}
      <div className="row" style={{ gap: 8, marginTop: 12, flexWrap: 'wrap' }}>
        <Btn sm onClick={() => navigate('dogovor')}>Spremeni dogovor</Btn>
        {!full && <Btn ghost sm onClick={() => navigate('napredek')}>Napredek</Btn>}
      </div>
    </Card>
  )
}

/** Kdaj nimaš časa (Moj dogovor): teden z vadbami; tap dan → teden se razporedi znova; dogovor (vadbe) ostane. */
function OffDays({ f }: { f: Focus }) {
  const [busy, setBusy] = useState(false)
  const off = f.offDays || []
  async function tap(d: number) {
    if (busy) return
    const next = off.includes(d) ? off.filter(x => x !== d) : [...off, d]
    const n = trainingDays(f.sessions)
    if (7 - next.length < n) {
      toast(`Za ${count(n, W.vadba)} na teden rabiš vsaj ${count(n, W.danT)} — za manj vadb spremeni dogovor.`, 'err', 6000)
      return
    }
    setBusy(true)
    const ok = await setOffDays(next).catch(() => false)
    setBusy(false)
    toast(ok ? 'Shranjeno — teden je razporejen znova.' : 'Ni šlo — poskusi znova.', ok ? 'ok' : 'err')
  }
  return <WeekStrip f={f} onDay={d => void tap(d)} busy={busy} title="Tvoj teden" hint="tapni dan, ko nimaš časa" />
}
