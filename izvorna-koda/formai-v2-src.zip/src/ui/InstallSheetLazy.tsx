import { Suspense } from 'react'
import { retryLazy } from '@/app/chunk'
import { ChunkBoundary } from '@/ui/ChunkBoundary'

/** (v3.51) List »Daj FORMAI na zaslon« se naloži ob odprtju (poziv brskalnika ujame installPrompt.ts). Isti vmesnik. */
const L = retryLazy(() => import('./InstallSheet').then(m => m.InstallSheet))
export function InstallSheet(p: { open: boolean; onClose: () => void }) {
  if (!p.open) return null
  // (v3.51) neuspel prenos: list »Ni naloženo« (prej je padla cela aplikacija — list je zunaj meje zaslona)
  return <ChunkBoundary onClose={p.onClose} label="Daj FORMAI na zaslon"><Suspense fallback={null}><L {...p} /></Suspense></ChunkBoundary>
}
