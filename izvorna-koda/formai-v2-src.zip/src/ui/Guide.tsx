import { useState, type ReactNode } from 'react'
import { useApp, updateSettings } from '@/state/store'
import { goalStatus, ftpPotential, raceWeightOf, levelOf } from '@/domain/training/goal'
import { powerZones7 } from '@/domain/training/zones'
import { dailyTarget } from '@/domain/nutrition/energy'
import { rideFuel, fuelCtxOf } from '@/domain/nutrition/dayplan'
import { addDays, weekStartIso } from '@/domain/training/load'
import { Btn, Sheet, Progress } from '@/ui/primitives'

const f1 = (x: number) => x.toFixed(1).replace('.', ',')
const f2 = (x: number) => x.toFixed(2).replace('.', ',')

/** Vodnik »Kako deluje« — 3 kratki koraki s tvojimi številkami. Pokaže se enkrat po uvodu ali prvem cilju in kadar koli iz Danes. */
export function Guide({ open, onClose }: { open: boolean; onClose: () => void }) {
  const app = useApp()
  const { profile: p, checkins, settings, today, plan, activities } = app
  const [i, setI] = useState(0)
  const g = goalStatus(p, checkins, settings.tests || [], today)
  const rw = raceWeightOf(p, today)
  const pot = ftpPotential(p, today)
  const z = powerZones7(p)
  const zr = (k: string) => { const x = z?.find(q => q.key === k); return x ? `${x.lo}–${x.hi} W` : '' }
  const tp = plan.filter(d => d.date === today)
  const t = dailyTarget(p, activities.filter(a => a.date === today), tp, today)
  const longRide = plan.find(d => d.role === 'dolga' && d.date >= today)
  const lf = longRide ? rideFuel(longRide, p.fuelKit, fuelCtxOf(app.weather, app.recentMeals, longRide.date, today)) : null
  // tvoj dejanski teden iz načrta (ne predloga)
  const ws = weekStartIso(today)
  const week = ['pon', 'tor', 'sre', 'čet', 'pet', 'sob', 'ned'].map((n, k) => {
    const its = plan.filter(d => d.date === addDays(ws, k) && d.kind !== 'pocitek')
    const ride = its.find(d => d.kind === 'kolo' || d.kind === 'test'), moc = its.find(d => d.kind === 'moc')
    const key = !!ride && (ride.role === 'kljucna' || ride.role === 'dolga' || ride.role === 'test' || ride.role === 'dirka')
    const label = [ride?.title, moc ? `moč (${moc.title.replace(/^Moč\s*—\s*/, '')})` : null].filter(Boolean).join(' + ') || 'počitek'
    return { n, label, key, date: addDays(ws, k) }
  }).filter(w => w.date >= today)          // samo dnevi od danes naprej (načrt je lahko začel sredi tedna)
  const hasWeek = week.some(w => w.label !== 'počitek')
  const nextTest = plan.filter(d => (d.role === 'test' || d.kind === 'test') && d.date >= today).sort((a, b) => a.date.localeCompare(b.date))[0]
  const dl = (iso: string) => new Date(iso).toLocaleDateString('sl-SI', { weekday: 'long', day: 'numeric', month: 'numeric' })

  const B = ({ children }: { children: ReactNode }) => <b style={{ color: 'var(--ink)' }}>{children}</b>
  const steps: { t: string; body: ReactNode }[] = [
    { t: 'Tvoj načrt', body: <>
      {g.event
        ? <p>Cilj: <B>{g.event.name}</B> · {+g.event.date.slice(8)}. {+g.event.date.slice(5, 7)}. {g.event.date.slice(0, 4)}{g.weeksToEvent != null ? ` · še ${g.weeksToEvent} tednov` : ''}.{g.wkg && g.targetWkg ? <> Zdaj <B>{f2(g.wkg)} W/kg</B> → na dan tekme <b style={{ color: 'var(--accent)' }}>{f2(g.targetWkg)} W/kg</b>{levelOf(g.targetWkg) ? ` (${levelOf(g.targetWkg)!.name.toLowerCase()})` : ''}.</> : null}</p>
        : <p>Načrt teče v blokih po 4 tedne. Tekmo ali cilj z datumom dodaš kadar koli (Danes → Cilj sezone) — načrt se mu prilagodi.</p>}
      {hasWeek && <p>{week.length === 7 ? 'Ta teden' : 'Do nedelje'}: {week.map((w, k) => <span key={k}>{k ? ' · ' : ''}{w.n} {w.key ? <B>{w.label}</B> : w.label}</span>)}.</p>}
      <p>Krepko označeni treningi so ključni — teh ne izpusti. 80 % časa voziš lahko (Z2: pogovarjaš se v celih stavkih), 20 % težko. Trije tedni rastejo, četrti je lažji; pred tekmo manj (tapering).</p>
      {z && <p className="muted">Tvoje cone: Z2 {zr('Z2')} · Z3 {zr('Z3')} · prag {zr('Z4')} · VO2max {zr('Z5')}.</p>}
      {rw && pot && <p className="muted">Najboljša teža zate ~{f1(rw.kg)} kg, največji možni FTP do cilja ~{pot.ideal} W pri {pot.hours} h na teden — iz tvojih podatkov, spremeni se s testi in tehtanjem.</p>}
    </> },
    { t: 'Vsak dan', body: <>
      <p>Na Danes pritisni <B>Začni trening</B>: najprej vidiš, kaj te čaka (vati, gorivo, kaj vzeti s seboj), med vožnjo en korak naenkrat s piskom pred menjavo, po koncu, kaj pojesti.</p>
      <p>Zjutraj <B>3 dotiki</B> (energija, mišice, spanec) → pripravljenost. Ko je nizka, ponudi <B>Olajšaj dan</B> in sejo prestavi.{app.settings.wellnessOn ? ' Spanec, HRV in mirovni utrip pridejo sami z ure.' : ''}</p>
      <p>Vožnje z ure pridejo same prek intervals.icu in odkljukajo dan (Nastavitve → Uvoz). Brez ure: <B>Vpiši vadbo</B> na Danes.{nextTest ? ` Naslednji test FTP: ${dl(nextTest.date).replace(/\.$/, '')}.` : ''}</p>
    </> },
    { t: 'Hrana in trener', body: <>
      {t ? <p>Danes: <B>{t.kcal} kcal</B>, beljakovine {t.proteinG} g, ogljikovi hidrati {t.carbsG} g. Cilj se vsak dan premakne s treningom — na dan vožnje ješ več, na dan počitka manj.</p>
        : <p>Ko vpišeš višino, težo, starost in spol, dobiš dnevni cilj kalorij, ki se premika s treningom.</p>}
      <p>Na kolesu: {lf && lf.totalCarbs ? <>na dolgi vožnji ~{lf.gph} g ogljikovih hidratov na uro, </> : null}trdi treningi nad 75 min ~70 g/h, tekma ~85 g/h. Deficit samo pri obrokih, nikoli na kolesu.</p>
      <p>Pod <B>Trener</B> vprašaj karkoli — kaj danes, koliko jesti, ali si na poti do cilja. Odgovori s tvojimi vati, grami in datumi.</p>
      <p className="muted">Načrt je trenerska usmeritev, ne zdravniški nasvet. Ob bolečini, bolezni ali zdravstvenih težavah se posvetuj z zdravnikom.</p>
    </> },
  ]
  const last = i === steps.length - 1
  function close() { void updateSettings({ guideSeen: true }); setI(0); onClose() }
  return (
    <Sheet open={open} onClose={close}>
      <div className="between"><b style={{ fontSize: 17, letterSpacing: '-.02em' }}>{steps[i]!.t}</b><span className="muted" style={{ fontSize: 12, fontWeight: 700 }}>{i + 1} / {steps.length}</span></div>
      <div style={{ margin: '10px 0 12px' }}><Progress pct={((i + 1) / steps.length) * 100} /></div>
      <div className="stack" style={{ gap: 8, fontSize: 13.5, color: 'var(--ink-2)', lineHeight: 1.5 }}>{steps[i]!.body}</div>
      <div className="row" style={{ gap: 8, marginTop: 16 }}>
        {i > 0 && <Btn ghost onClick={() => setI(i - 1)}>Nazaj</Btn>}
        <Btn primary block onClick={() => (last ? close() : setI(i + 1))}>{last ? 'Začniva' : 'Naprej'}</Btn>
      </div>
    </Sheet>
  )
}
