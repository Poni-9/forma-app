import { useState, type ReactNode } from 'react'
import { useApp, updateSettings } from '@/state/store'
import { goalStatus, ftpPotential, raceWeightOf, levelOf } from '@/domain/training/goal'
import { powerZones7 } from '@/domain/training/zones'
import { dailyTarget } from '@/domain/nutrition/energy'
import { rideFuel, fuelCtxOf } from '@/domain/nutrition/dayplan'
import { addDays, weekStartIso } from '@/domain/training/load'
import { Btn, Sheet, Progress } from '@/ui/primitives'
import { HealthNote } from '@/ui/HealthNote'
import { count, dayName, dm, dmy, kcal, num, NBSP, W } from '@/ui/format'
import { isCustom, weekLine, mixLine } from '@/domain/focus/model'

const f1 = (x: number) => x.toFixed(1).replace('.', ',')
const f2 = (x: number) => x.toFixed(2).replace('.', ',')

/** Vodnik »Kako deluje« — 3 kratki koraki s tvojimi številkami. Pokaže se enkrat po uvodu ali prvem cilju in kadar koli iz Danes. */
export function Guide({ open, onClose }: { open: boolean; onClose: () => void }) {
  const app = useApp()
  const { profile: p, checkins, settings, today, plan, activities } = app
  const [i, setI] = useState(0)
  const g = goalStatus(p, checkins, settings.tests || [], today)
  const rw = raceWeightOf(p, today)
  const pot = ftpPotential(p, today)
  const z = powerZones7(p)
  const zr = (k: string) => { const x = z?.find(q => q.key === k); return x ? `${x.lo}–${x.hi} W` : '' }
  const tp = plan.filter(d => d.date === today)
  const t = dailyTarget(p, activities.filter(a => a.date === today), tp, today)
  const longRide = plan.find(d => d.role === 'dolga' && d.date >= today)
  const lf = longRide ? rideFuel(longRide, p.fuelKit, fuelCtxOf(app.weather, app.recentMeals, longRide.date, today)) : null
  // tvoj dejanski teden iz načrta (ne predloga)
  const ws = weekStartIso(today)
  const week = ['pon', 'tor', 'sre', 'čet', 'pet', 'sob', 'ned'].map((n, k) => {
    const its = plan.filter(d => d.date === addDays(ws, k) && d.kind !== 'pocitek')
    const ride = its.find(d => d.kind === 'kolo' || d.kind === 'test'), moc = its.find(d => d.kind === 'moc')
    const key = !!ride && (ride.role === 'kljucna' || ride.role === 'dolga' || ride.role === 'test' || ride.role === 'dirka')
    const label = [ride?.title, moc ? `moč (${moc.title.replace(/^Moč\s*—\s*/, '')})` : null].filter(Boolean).join(' + ') || 'počitek'
    return { n, label, key, date: addDays(ws, k) }
  }).filter(w => w.date >= today)          // samo dnevi od danes naprej (načrt je lahko začel sredi tedna)
  const hasWeek = week.some(w => w.label !== 'počitek')
  const nextTest = plan.filter(d => (d.role === 'test' || d.kind === 'test') && d.date >= today).sort((a, b) => a.date.localeCompare(b.date))[0]
  const dl = (iso: string) => `${dayName(iso)}, ${dm(iso)}`

  const B = ({ children }: { children: ReactNode }) => <b style={{ color: 'var(--ink)' }}>{children}</b>
  const f = isCustom(p) ? p.focus! : null
  // načrt po meri: tvoj teden z vsemi vrstami (fitnes, tek …), bloki po 4 tedne, kilogrami
  const weekAll = ['pon', 'tor', 'sre', 'čet', 'pet', 'sob', 'ned'].map((n, k) => {
    const d = addDays(ws, k), it = plan.find(x => x.date === d && x.kind !== 'pocitek' && !x.optional)
    return { n, label: it ? it.title : 'počitek', date: d }
  }).filter(w => w.date >= today)
  const strat = (f?.strategy || '').split('\n').map(l => l.replace(/^[–-]\s*/, '').trim()).filter(Boolean)
  const strength = !!f && f.sessions.some(x => x.type === 'fitnes' || x.type === 'doma')
  const cardio = !!f && f.sessions.some(x => x.type === 'tek' || x.type === 'kolo' || x.type === 'hribi')
  const customSteps: { t: string; body: ReactNode }[] = f ? [
    { t: 'Tvoj načrt', body: <>
      <p><B>{f.title}</B> · {weekLine(f)} ({mixLine(f)}).</p>
      {weekAll.some(w => w.label !== 'počitek') && <p>{weekAll.length === 7 ? 'Ta teden' : 'Do nedelje'}: {weekAll.map((w, k) => <span key={k}>{k ? ' · ' : ''}{w.n} {w.label === 'počitek' ? w.label : <B>{w.label}</B>}</span>)}.</p>}
      <p>Bloki po 4 tedne: trije tedni rastejo (več serij, teže in minut), četrti je lažji — telo se okrepi med počitkom.{f.keepMuscle ? ' Med hujšanjem težke serije ostanejo: tako telo mišice obdrži.' : ''}</p>
      {strat.length > 0 && <p className="muted">{strat.slice(0, 2).join(' ')}</p>}
    </> },
    { t: 'Vsak dan', body: <>
      {strength && <p>Na Danes pritisni <B>Začni trening</B>: vaja za vajo, serija za serijo, s pavzo na štoparici. Vpiši <B>kilograme in ponovitve</B> — ko narediš vse ponovitve, je naslednjič teža višja. Naprava zasedena? <B>Zamenjaj vajo</B>.</p>}
      {cardio && <p>{strength ? 'Pri teku' : 'Na Danes pritisni Začni trening — pri teku'} vidiš, kako hitro: lahko pomeni, da se še pogovarjaš v celih stavkih. Večina kardia je lahkega, en trening na teden je hitrejši.</p>}
      <p>Zjutraj <B>3 dotiki</B> (energija, mišice, spanec) → pripravljenost. Ko je nizka, naredi manj — ali dan premakni.{app.settings.wellnessOn ? ' Spanec, HRV in mirovni utrip pridejo sami z ure.' : ''}</p>
      <p>Treningi z ure pridejo sami prek intervals.icu (Nastavitve → Uvoz). Brez ure: <B>Opravil</B> ali <B>Vpiši vadbo</B> na Danes.</p>
    </> },
    { t: 'Hrana in trener', body: <>
      {t ? <p>Danes: <B>{kcal(t.kcal)}</B>, beljakovine <B>{t.proteinG}{NBSP}g</B>. Na dan vadbe ješ več, na dan počitka manj{t.deficit > 0 ? ' — primanjkljaj je zmeren, da mišice ostanejo' : ''}.</p>
        : <p>Ko vpišeš višino, težo, starost in spol, dobiš dnevni cilj kalorij, ki se premika s treningom.</p>}
      <p>Beljakovine razporedi čez dan — pri vsakem obroku nekaj (meso, ribe, jajca, skuta, jogurt, stročnice).</p>
      <p>Pod <B>Trener</B> vprašaj karkoli — o vajah, hrani, kako napreduješ. Dogovor spremeniš kadar koli: Nastavitve → <B>Moj dogovor</B>.</p>
      <HealthNote kind="both" style={{ marginTop: 0 }} />
    </> },
  ] : []
  const steps: { t: string; body: ReactNode }[] = f ? customSteps : [
    { t: 'Tvoj načrt', body: <>
      {g.event
        ? <p>Cilj: <B>{g.event.name}</B> · {dmy(g.event.date, '')}{g.weeksToEvent != null ? ` · še ${count(g.weeksToEvent, W.teden)}` : ''}.{g.wkg && g.targetWkg ? <> Zdaj <B>{f2(g.wkg)} W/kg</B> → na dan tekme <b style={{ color: 'var(--accent-fg)' }}>{f2(g.targetWkg)} W/kg</b>{levelOf(g.targetWkg) ? ` (${levelOf(g.targetWkg)!.name.toLowerCase()})` : ''}.</> : null}</p>
        : <p>Načrt teče v blokih po 4 tedne. Tekmo ali cilj z datumom dodaš kadar koli (Danes → Cilj sezone) — načrt se mu prilagodi.</p>}
      {hasWeek && <p>{week.length === 7 ? 'Ta teden' : 'Do nedelje'}: {week.map((w, k) => <span key={k}>{k ? ' · ' : ''}{w.n} {w.key ? <B>{w.label}</B> : w.label}</span>)}.</p>}
      <p>Krepko označeni treningi so ključni — teh ne izpusti. 80 % časa voziš lahko (Z2: pogovarjaš se v celih stavkih), 20 % težko. Trije tedni rastejo, četrti je lažji; pred tekmo manj (tapering).</p>
      {z && <p className="muted">Tvoje cone: Z2 {zr('Z2')} · Z3 {zr('Z3')} · prag {zr('Z4')} · VO2max {zr('Z5')}.</p>}
      {rw && pot && <p className="muted">Najboljša teža zate ~{f1(rw.kg)} kg, največji možni FTP do cilja ~{pot.ideal}{NBSP}W pri {num(pot.hours)}{NBSP}h na teden — iz tvojih podatkov, spremeni se s testi in tehtanjem.</p>}
    </> },
    { t: 'Vsak dan', body: <>
      <p>Na Danes pritisni <B>Začni trening</B>: najprej vidiš, kaj te čaka (vati, gorivo, kaj vzeti s seboj), med vožnjo en korak naenkrat s piskom pred menjavo, po koncu, kaj pojesti.</p>
      <p>Zjutraj <B>3 dotiki</B> (energija, mišice, spanec) → pripravljenost. Ko je nizka, ponudi <B>Olajšaj dan</B> in sejo prestavi.{app.settings.wellnessOn ? ' Spanec, HRV in mirovni utrip pridejo sami z ure.' : ''}</p>
      <p>Vožnje z ure pridejo same prek intervals.icu in odkljukajo dan (Nastavitve → Uvoz). Brez ure: <B>Vpiši vadbo</B> na Danes.{nextTest ? ` Naslednji test FTP: ${dl(nextTest.date)}` : ''}</p>
    </> },
    { t: 'Hrana in trener', body: <>
      {t ? <p>Danes: <B>{kcal(t.kcal)}</B>, beljakovine {t.proteinG}{NBSP}g, ogljikovi hidrati {t.carbsG}{NBSP}g. Cilj se vsak dan premakne s treningom — na dan vožnje ješ več, na dan počitka manj.</p>
        : <p>Ko vpišeš višino, težo, starost in spol, dobiš dnevni cilj kalorij, ki se premika s treningom.</p>}
      <p>Na kolesu: {lf && lf.totalCarbs ? <>na dolgi vožnji ~{lf.gph} g ogljikovih hidratov na uro, </> : null}trdi treningi nad 75 min ~70 g/h, tekma ~85 g/h. Deficit samo pri obrokih, nikoli na kolesu.</p>
      <p>Pod <B>Trener</B> vprašaj karkoli — kaj danes, koliko jesti, ali si na poti do cilja. Odgovori s tvojimi vati, grami in datumi.</p>
      <HealthNote kind="both" style={{ marginTop: 0 }} />
    </> },
  ]
  const last = i === steps.length - 1
  function close() { void updateSettings({ guideSeen: true }); setI(0); onClose() }
  return (
    <Sheet open={open} onClose={close}>
      <div className="between"><b style={{ fontSize: 17, letterSpacing: '-.02em' }}>{steps[i]!.t}</b><span className="muted" style={{ fontSize: 12, fontWeight: 700 }}>{i + 1} / {steps.length}</span></div>
      <div style={{ margin: '10px 0 12px' }}><Progress pct={((i + 1) / steps.length) * 100} /></div>
      <div className="stack" style={{ gap: 8, fontSize: 13.5, color: 'var(--ink-2)', lineHeight: 1.5 }}>{steps[i]!.body}</div>
      <div className="row" style={{ gap: 8, marginTop: 16 }}>
        {i > 0 && <Btn ghost onClick={() => setI(i - 1)}>Nazaj</Btn>}
        <Btn primary block onClick={() => (last ? close() : setI(i + 1))}>{last ? 'Začniva' : 'Naprej'}</Btn>
      </div>
    </Sheet>
  )
}
