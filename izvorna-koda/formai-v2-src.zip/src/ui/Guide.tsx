import { useState, type ReactNode } from 'react'
import { useApp, updateSettings } from '@/state/store'
import { goalStatus, ftpPotential, raceWeightOf, levelOf } from '@/domain/training/goal'
import { powerZones7 } from '@/domain/training/zones'
import { dailyTarget } from '@/domain/nutrition/energy'
import { rideFuel } from '@/domain/nutrition/dayplan'
import { addDays, weekStartIso } from '@/domain/training/load'
import { Btn, Sheet, Progress } from '@/ui/primitives'

const f1 = (x: number) => x.toFixed(1).replace('.', ',')
const f2 = (x: number) => x.toFixed(2).replace('.', ',')

/** Vodnik »Kako deluje« — 6 kratkih korakov s tvojimi številkami. Pokaže se po potrditvi cilja in kadarkoli iz Danes. */
export function Guide({ open, onClose }: { open: boolean; onClose: () => void }) {
  const app = useApp()
  const { profile: p, checkins, settings, today, plan, activities } = app
  const [i, setI] = useState(0)
  const g = goalStatus(p, checkins, settings.tests || [], today)
  const rw = raceWeightOf(p, today)
  const pot = ftpPotential(p, today)
  const z = powerZones7(p)
  const zr = (k: string) => { const x = z?.find(q => q.key === k); return x ? `${x.lo}–${x.hi} W` : '' }
  const tp = plan.filter(d => d.date === today)
  const t = dailyTarget(p, activities.filter(a => a.date === today), tp, today)
  const longRide = plan.find(d => d.role === 'dolga' && d.date >= today)
  const lf = longRide ? rideFuel(longRide) : null
  // tvoj dejanski teden iz načrta (ne predloga)
  const ws = weekStartIso(today)
  const week = ['pon', 'tor', 'sre', 'čet', 'pet', 'sob', 'ned'].map((n, k) => {
    const its = plan.filter(d => d.date === addDays(ws, k) && d.kind !== 'pocitek')
    const ride = its.find(d => d.kind === 'kolo' || d.kind === 'test'), moc = its.find(d => d.kind === 'moc')
    const key = !!ride && (ride.role === 'kljucna' || ride.role === 'dolga' || ride.role === 'test' || ride.role === 'dirka')
    const label = [ride?.title, moc ? `moč (${moc.title.replace(/^Moč\s*—\s*/, '')})` : null].filter(Boolean).join(' + ') || 'počitek'
    return { n, label, key }
  })
  const hasWeek = week.some(w => w.label !== 'počitek')
  const nextTest = plan.filter(d => (d.role === 'test' || d.kind === 'test') && d.date >= today).sort((a, b) => a.date.localeCompare(b.date))[0]
  const dl = (iso: string) => new Date(iso).toLocaleDateString('sl-SI', { weekday: 'long', day: 'numeric', month: 'numeric' })

  const steps: { t: string; body: ReactNode }[] = [
    { t: 'Tvoj cilj', body: <>
      <p><b style={{ color: 'var(--ink)' }}>{g.event?.name || 'Dirka'}</b>{g.event ? ` · ${g.event.date.slice(8)}. ${+g.event.date.slice(5, 7)}. ${g.event.date.slice(0, 4)}${g.weeksToEvent != null ? ` · še ${g.weeksToEvent} tednov` : ''}` : ''}.</p>
      <p>Zdaj <b style={{ color: 'var(--ink)' }}>{g.wkg ? f2(g.wkg) : '—'} W/kg</b>{levelOf(g.wkg) ? ` (${levelOf(g.wkg)!.name.toLowerCase()})` : ''} → na dan dirke <b style={{ color: 'var(--accent)' }}>{g.targetWkg ? f2(g.targetWkg) : '—'} W/kg</b>{levelOf(g.targetWkg) ? ` (${levelOf(g.targetWkg)!.name.toLowerCase()})` : ''}.</p>
      {rw && <p>Najboljša teža zate: <b style={{ color: 'var(--ink)' }}>{f1(rw.kg)} kg</b> — {rw.measured ? 'maščoba' : 'ocena maščobe'} ~{Math.round(rw.bf)} % → ~{rw.targetBf} %, mišice ostanejo.</p>}
      {pot && <p>Največji možni FTP do dirke: <b style={{ color: 'var(--ink)' }}>{pot.ideal} W</b> (realno {pot.realistic} W) pri {pot.hours} h na teden.</p>}
      <p className="muted">Izračunano iz tvoje teže, višine, starosti, FTP in ur. Ko se spremenijo (test, tehtanje), se spremeni tudi pot.</p>
    </> },
    { t: 'Tvoj teden (80 / 20)', body: <>
      {hasWeek
        ? <p>Ta teden: {week.map((w, k) => <span key={k}>{k ? ' · ' : ''}{w.n} {w.key ? <b style={{ color: 'var(--ink)' }}>{w.label}</b> : w.label}</span>)}.</p>
        : <p>Pon počitek · <b style={{ color: 'var(--ink)' }}>tor VO2max</b> + jedro · sre Z2 · <b style={{ color: 'var(--ink)' }}>čet sweet spot / prag</b> · pet regeneracija + noge · <b style={{ color: 'var(--ink)' }}>sob dolga Z2</b> · ned Z2.</p>}
      {z && <p>Tvoje cone: Z1 do {z[0]!.hi} W · Z2 {zr('Z2')} · Z3 {zr('Z3')} · prag {zr('Z4')} · VO2max {zr('Z5')}.</p>}
      <p>Krepko označeni treningi so ključni — teh ne izpusti. 80 % časa lahko (Z2 — pogovarjaš se v celih stavkih), 20 % težko. Trije tedni rastejo, četrti je razbremenilni. Zadnja dva tedna pred dirko manj (tapering).</p>
    </> },
    { t: 'Vsak trening', body: <>
      <p>Na Danes pritisni <b style={{ color: 'var(--ink)' }}>Začni trening</b>. Najprej vidiš, kaj te čaka, s kakšnimi vati, kaj vzeti s seboj in kaj pojesti prej.</p>
      <p>Med vožnjo: en korak naenkrat — vati, občutek (RPE), kadenca, pisk pred menjavo in opomnik, kdaj jesti in piti.</p>
      <p>Po koncu: kaj pojesti za obnovo in kaj sledi. Vožnja iz Garmina pride sama (intervals.icu) in odkljuka dan.</p>
    </> },
    { t: 'Prehrana', body: <>
      {t && <p>Danes: <b style={{ color: 'var(--ink)' }}>{t.kcal} kcal</b>, beljakovine {t.proteinG} g, OH {t.carbsG} g. Cilj se vsak dan prilagodi treningu — na dan vožnje ješ več, na dan počitka manj.</p>}
      <p>V Prehrani imaš razpored obrokov s količinami (kdaj in koliko), okoli vožnje več ogljikovih hidratov. Deficit ustvariš pri obrokih, nikoli na kolesu.</p>
      <p>Na kolesu: {lf && lf.totalCarbs ? <>na dolgi vožnji ~{lf.gph} g OH na uro (skupaj ~{lf.totalCarbs} g), </> : null}trdi treningi nad 75 min ~70 g/h, dirka ~85 g/h. Pred vsako vožnjo dobiš seznam (bidoni, gel, banana) in urnik; med vožnjo te opomnik opozori, kdaj jesti in piti.</p>
      <p>Tehtaj se zjutraj 3× na teden — ko dosežeš najboljšo težo, deficit sam preneha.</p>
    </> },
    { t: 'Jutro in testi', body: <>
      <p>Zjutraj 3 tapi (energija, mišice, spanec) → pripravljenost. Če je nizka, aplikacija ponudi <b style={{ color: 'var(--ink)' }}>Olajšaj dan</b> in sejo prestavi.</p>
      <p>Vsakih 8 tednov (v razbremenilnem tednu) 20-minutni test FTP. Vpišeš povprečje in vsi vati v načrtu se posodobijo.{nextTest ? ` Naslednji test: ${dl(nextTest.date).replace(/\.$/, '')}.` : ''}</p>
    </> },
    { t: 'Trener', body: <>
      <p>Pod <b style={{ color: 'var(--ink)' }}>Trener</b> vprašaj karkoli — kaj danes, koliko jesti, ali si na poti do cilja. Odgovori s tvojimi vati, grami in datumi.</p>
      <p className="muted">⚕️ Načrt je trenerska usmeritev, ne zdravniški nasvet. Ob bolečini, bolezni ali zdravstvenih težavah se posvetuj z zdravnikom.</p>
    </> },
  ]
  const last = i === steps.length - 1
  function close() { void updateSettings({ guideSeen: true }); setI(0); onClose() }
  return (
    <Sheet open={open} onClose={close}>
      <div className="between"><b style={{ fontSize: 17, letterSpacing: '-.02em' }}>{steps[i]!.t}</b><span className="muted" style={{ fontSize: 12, fontWeight: 700 }}>{i + 1} / {steps.length}</span></div>
      <div style={{ margin: '10px 0 12px' }}><Progress pct={((i + 1) / steps.length) * 100} /></div>
      <div className="stack" style={{ gap: 8, fontSize: 13.5, color: 'var(--ink-2)', lineHeight: 1.5 }}>{steps[i]!.body}</div>
      <div className="row" style={{ gap: 8, marginTop: 16 }}>
        {i > 0 && <Btn ghost onClick={() => setI(i - 1)}>Nazaj</Btn>}
        <Btn primary block onClick={() => (last ? close() : setI(i + 1))}>{last ? 'Začniva' : 'Naprej'}</Btn>
      </div>
    </Sheet>
  )
}
