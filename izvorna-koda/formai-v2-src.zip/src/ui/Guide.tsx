import { useState, type ReactNode } from 'react'
import { useApp, updateSettings } from '@/state/store'
import { goalStatus, ftpPotential, raceWeightOf, levelOf } from '@/domain/training/goal'
import { powerZones7, noPower } from '@/domain/training/zones'
import { dailyTarget } from '@/domain/nutrition/energy'
import { rideFuel, fuelCtxOf } from '@/domain/nutrition/dayplan'
import { addDays, weekStartIso, fmtDur, titleNoDur } from '@/domain/training/load'
import { Btn, Sheet, Progress } from '@/ui/primitives'
import { HealthNote } from '@/ui/HealthNote'
import { count, dayName, dm, dmy, kcal, num, NBSP, W } from '@/ui/format'
import { isCustom, weekLine, mixLine, dealStrategy, kgStrength, fastCardio } from '@/domain/focus/model'
import { noWatchIn, noRaceWish } from '@/domain/start'
import { rem } from '@/ui/rem'
import { wellnessActive } from '@/domain/wellness'
import type { Settings } from '@/domain/types'

/**
 * (v3.52) Pot z ure v aplikacijo: Garmin Connect neposredno je prva (Uvoz), intervals.icu ostane za druge ure in
 * zgodovino. S povezanim Garminom pove, da vožnje že pridejo same.
 */
export function watchPath(s: Pick<Settings, 'intervals' | 'garmin'>, rides = false): string {
  const what = rides ? 'Vožnje z ure pridejo same' : 'Treningi z ure pridejo sami'
  if (s.garmin?.connected) return `${what} prek Garmin Connect in odkljukajo dan.`
  if (s.intervals) return `${what} prek intervals.icu in odkljukajo dan (Nastavitve → Ura in uvoz).`
  return `Poveži Garmin Connect v Uvozu — ure ni treba več povezovati prek intervals.icu (Wahoo, COROS, Polar … še vedno prek intervals.icu). ${what} in odkljukajo dan.`
}

const f1 = (x: number) => x.toFixed(1).replace('.', ',')
const f2 = (x: number) => x.toFixed(2).replace('.', ',')

/**
 * Vodnik »Kako deluje« — 3 kratki koraki s tvojimi številkami. Pokaže se enkrat po uvodu ali prvem cilju in kadar koli iz Danes.
 * (v3.49) Prvič en kratek zaslon (današnji trening, »Opravil«, Prehrana); »Več« odpre tri korake (prej 3 zasloni, 260–300 besed).
 */
export function Guide({ open, onClose }: { open: boolean; onClose: () => void }) {
  const app = useApp()
  const { profile: p, checkins, settings, today, plan, activities } = app
  const [i, setI] = useState(0)
  const [short, setShort] = useState(() => settings.guideSeen === false)
  // (v3.49) kdor je napisal »Nimam ure«, mu ne govorimo o uri; brez merilnika moči ni vatov
  const noWatch = noWatchIn(p.focus?.wish) && !settings.intervals && !settings.garmin?.connected   // (v3.52) tudi Garmin Connect neposredno
  const watts = !noPower(p)
  const g = goalStatus(p, checkins, settings.tests || [], today)
  const rw = raceWeightOf(p, today)
  const pot = ftpPotential(p, today)
  const z = powerZones7(p)
  const zr = (k: string) => { const x = z?.find(q => q.key === k); return x ? `${x.lo}–${x.hi} W` : '' }
  const tp = plan.filter(d => d.date === today)
  const t = dailyTarget(p, activities.filter(a => a.date === today), tp, today)
  const longRide = plan.find(d => d.role === 'dolga' && d.date >= today)
  const lf = longRide ? rideFuel(longRide, p.fuelKit, fuelCtxOf(app.weather, app.recentMeals, longRide.date, today)) : null
  // tvoj dejanski teden iz načrta (ne predloga)
  const ws = weekStartIso(today)
  const week = ['pon', 'tor', 'sre', 'čet', 'pet', 'sob', 'ned'].map((n, k) => {
    const its = plan.filter(d => d.date === addDays(ws, k) && d.kind !== 'pocitek')
    const ride = its.find(d => d.kind === 'kolo' || d.kind === 'test'), moc = its.find(d => d.kind === 'moc')
    const key = !!ride && (ride.role === 'kljucna' || ride.role === 'dolga' || ride.role === 'test' || ride.role === 'dirka')
    const label = [ride?.title, moc ? `moč (${moc.title.replace(/^Moč\s*—\s*/, '')})` : null].filter(Boolean).join(' + ') || 'počitek'
    return { n, label, key, date: addDays(ws, k) }
  }).filter(w => w.date >= today)          // samo dnevi od danes naprej (načrt je lahko začel sredi tedna)
  const hasWeek = week.some(w => w.label !== 'počitek')
  const nextTest = plan.filter(d => (d.role === 'test' || d.kind === 'test') && d.date >= today).sort((a, b) => a.date.localeCompare(b.date))[0]
  const dl = (iso: string) => `${dayName(iso)}, ${dm(iso)}`

  const B = ({ children }: { children: ReactNode }) => <b style={{ color: 'var(--ink)' }}>{children}</b>
  const f = isCustom(p) ? p.focus! : null
  // načrt po meri: tvoj teden z vsemi vrstami (fitnes, tek …), bloki po 4 tedne, kilogrami
  const weekAll = ['pon', 'tor', 'sre', 'čet', 'pet', 'sob', 'ned'].map((n, k) => {
    const d = addDays(ws, k), it = plan.find(x => x.date === d && x.kind !== 'pocitek' && !x.optional)
    return { n, label: it ? it.title : 'počitek', date: d }
  }).filter(w => w.date >= today)
  // brez vrstice, ki ponovi teden in bloke (oboje je tik nad njo) — v3.48
  const strat = f ? dealStrategy(f) : []
  const strength = !!f && f.sessions.some(x => x.type === 'fitnes' || x.type === 'doma')
  const cardio = !!f && f.sessions.some(x => x.type === 'tek' || x.type === 'kolo' || x.type === 'hribi')
  // (v3.49) besede po tednu, ki ga dogovor res ima: kilogrami samo z opremo, »Naprava zasedena« samo v fitnesu,
  // šport po imenu (tek, vožnja, hoja), »en hitrejši trening« samo z intervali ali tempom (prej za vse enako)
  const kg = !!f && kgStrength(f)
  const gymOn = !!f && f.sessions.some(x => x.type === 'fitnes')
  const fast = !!f && fastCardio(f.sessions)
  const cWords = f ? ([['tek', 'teku'], ['kolo', 'vožnji'], ['hribi', 'hoji']] as const).filter(([t]) => f.sessions.some(x => x.type === t)).map(([, w]) => w) : []
  const cOnly = cWords.length === 1 && cWords[0] === 'hoji' ? 'Pri hoji hodi hitro, da se zadihaš, a še lahko govoriš.' : `Pri ${cWords.join(' in ')} drži lahek tempo — še se pogovarjaš v celih stavkih.`
  const gw = [strength ? 'serij' : null, kg ? 'teže' : null, cardio ? 'minut' : null].filter((x): x is string => !!x)
  const grow = gw.length > 1 ? `${gw.slice(0, -1).join(', ')} in ${gw[gw.length - 1]}` : gw[0] ?? ''
  const doneLine = (cap: boolean) => <>{cap ? 'Po' : 'po'} treningu tapni <B>Opravil</B> na Danes — krajšega popraviš s »krajše?«, pozabljenega te Danes vpraša naslednji dan.</>
  const customSteps: { t: string; body: ReactNode }[] = f ? [
    { t: 'Tvoj načrt', body: <>
      <p><B>{f.title}</B> · {weekLine(f)} ({mixLine(f)}).</p>
      {weekAll.some(w => w.label !== 'počitek') && <p>{weekAll.length === 7 ? 'Ta teden' : 'Do nedelje'}: {weekAll.map((w, k) => <span key={k}>{k ? ' · ' : ''}{w.n} {w.label === 'počitek' ? w.label : <B>{w.label}</B>}</span>)}.</p>}
      <p>Bloki po 4 tedne: trije tedni rastejo{grow ? ` (več ${grow})` : ''}, četrti je lažji — telo se okrepi med počitkom.{f.keepMuscle ? ' Med hujšanjem težke serije ostanejo: tako telo mišice obdrži.' : ''}</p>
      {strat.length > 0 && <p className="muted">{strat.slice(0, 2).join(' ')}</p>}
    </> },
    { t: 'Vsak dan', body: <>
      {strength && (kg
        ? <p>Na Danes pritisni <B>Začni trening</B>: vaja za vajo, serija za serijo, s pavzo na štoparici. Vpiši <B>kilograme in ponovitve</B> — ko narediš vse ponovitve, je naslednjič teža višja.{gymOn ? <> Naprava zasedena? <B>Zamenjaj vajo</B>.</> : null}</p>
        : <p>Na Danes pritisni <B>Začni trening</B>: vaja za vajo, serija za serijo, s pavzo na štoparici. Vpiši <B>ponovitve</B> — tako vidiš, kako napreduješ.</p>)}
      {cardio && <p>{strength ? '' : 'Na Danes pritisni Začni trening. '}{cOnly}{fast ? ' Večina kardia je lahkega, en trening na teden je hitrejši.' : ''}</p>}
      <p>Zjutraj <B>3 dotiki</B> (energija, mišice, spanec) → pripravljenost. Ko je nizka, naredi manj — ali dan premakni.{wellnessActive(app.settings) ? ' Spanec, HRV in mirovni utrip pridejo sami z ure.' : ''}</p>
      {/* (v3.49) brez »Vpiši vadbo na Danes« — takega gumba ni; »Opravil«, »krajše?« in »si ga naredil?« so */}
      <p>{noWatch ? doneLine(true) : <>{watchPath(settings)} Brez ure: {doneLine(false)}</>}</p>
    </> },
    { t: 'Hrana in trener', body: <>
      {t ? <p>Danes: <B>{kcal(t.kcal)}</B>, beljakovine <B>{t.proteinG}{NBSP}g</B>. Na dan vadbe ješ več, na dan počitka manj{t.deficit > 0 ? ' — deficit je zmeren, da mišice ostanejo' : ''}.</p>
        : <p>Ko vpišeš višino, težo, starost in spol, dobiš dnevni cilj kalorij, ki se premika s treningom.</p>}
      <p>Pod <B>Prehrana</B> ima vsak obrok dneva recept — kaj, koliko gramov in kako pripraviš, pomerjeno na tvoje kalorije in beljakovine. <B>Vpiši, ko poješ</B>, in vidiš, koliko še manjka.</p>
      <p>Pod <B>Trener</B> vprašaj karkoli — o vajah, hrani, kako napreduješ. Dogovor spremeniš kadar koli: Nastavitve → <B>Moj dogovor</B>.</p>
      <HealthNote kind="both" style={{ marginTop: 0 }} />
    </> },
  ] : []
  const steps: { t: string; body: ReactNode }[] = f ? customSteps : [
    { t: 'Tvoj načrt', body: <>
      {g.event
        ? <p>Cilj: <B>{g.event.name}</B> · {dmy(g.event.date, '')}{g.weeksToEvent != null ? ` · še ${count(g.weeksToEvent, W.teden)}` : ''}.{g.wkg && g.targetWkg ? <> Zdaj <B>{f2(g.wkg)} W/kg</B> → na dan tekme <b style={{ color: 'var(--accent-fg)' }}>{f2(g.targetWkg)} W/kg</b>{levelOf(g.targetWkg) ? ` (${levelOf(g.targetWkg)!.name.toLowerCase()})` : ''}.</> : null}</p>
        : <p>Načrt teče v blokih po 4 tedne. Tekmo ali cilj z datumom dodaš kadar koli (Plan → Tekme sezone) — načrt se mu prilagodi.</p>}
      {hasWeek && <p>{week.length === 7 ? 'Ta teden' : 'Do nedelje'}: {week.map((w, k) => <span key={k}>{k ? ' · ' : ''}{w.n} {w.key ? <B>{w.label}</B> : w.label}</span>)}.</p>}
      <p>Krepko označeni treningi so ključni — teh ne izpusti. 80 % časa voziš lahko (Z2: pogovarjaš se v celih stavkih), 20 % težko. Trije tedni rastejo, četrti je lažji; pred tekmo manj (tapering).</p>
      {z && watts && <p className="muted">Tvoje cone: Z2 {zr('Z2')} · Z3 {zr('Z3')} · prag {zr('Z4')} · VO2max {zr('Z5')}.</p>}
      {rw && pot && <p className="muted">Najboljša teža zate ~{f1(rw.kg)} kg, največji možni FTP do cilja ~{pot.ideal}{NBSP}W pri {num(pot.hours)}{NBSP}h na teden — iz tvojih podatkov, spremeni se s testi in tehtanjem.</p>}
    </> },
    { t: 'Vsak dan', body: <>
      <p>Na Danes pritisni <B>Začni trening</B>: najprej vidiš, kaj te čaka ({watts ? 'vati' : 'utrip ali občutek'}, gorivo, kaj vzeti s seboj), med vožnjo en korak naenkrat s piskom pred menjavo, po koncu, kaj pojesti.</p>
      <p>Zjutraj <B>3 dotiki</B> (energija, mišice, spanec) → pripravljenost. Ko je nizka, ponudi <B>Olajšaj dan</B> in sejo prestavi.{wellnessActive(app.settings) ? ' Spanec, HRV in mirovni utrip pridejo sami z ure.' : ''}</p>
      <p>{noWatch ? doneLine(true) : <>{watchPath(settings, true)} Brez ure: {doneLine(false)}</>}{nextTest ? ` Naslednji test FTP: ${dl(nextTest.date)}` : ''}</p>
    </> },
    { t: 'Hrana in trener', body: <>
      {t ? <p>Danes: <B>{kcal(t.kcal)}</B>, beljakovine {t.proteinG}{NBSP}g, ogljikovi hidrati {t.carbsG}{NBSP}g. Cilj se vsak dan premakne s treningom — na dan vožnje ješ več, na dan počitka manj.</p>
        : <p>Ko vpišeš višino, težo, starost in spol, dobiš dnevni cilj kalorij, ki se premika s treningom.</p>}
      {/* (v3.50) »nimam tekme, zdravje«: brez »tekma ~85 g/h« */}
      <p>Na kolesu: {lf && lf.totalCarbs ? <>na dolgi vožnji ~{lf.gph} g ogljikovih hidratov na uro, </> : null}trdi treningi nad 75 min ~70 g/h{g.event || !noRaceWish(p) ? ', tekma ~85 g/h' : ''}. Deficit samo pri obrokih, nikoli na kolesu.</p>
      <p>Pod <B>Prehrana</B> ima vsak obrok dneva recept (kaj, koliko, kako), pomerjen na tvoj dan. Pod <B>Trener</B> vprašaj karkoli — kaj danes, koliko jesti, ali si na poti do cilja. Odgovori s tvojimi {watts ? 'vati' : 'urami'}, grami in datumi.</p>
      <HealthNote kind="both" style={{ marginTop: 0 }} />
    </> },
  ]
  const last = i === steps.length - 1
  function close() { void updateSettings({ guideSeen: true }); setI(0); onClose() }
  if (short) {
    // (v3.49) prvič na kratko: kaj danes, kako ga odkljukaš, kje je hrana; ostalo pod »Več«
    const real = (d: (typeof plan)[number]) => d.kind !== 'pocitek' && !d.optional
    const now = plan.filter(d => d.date === today && real(d)).sort((a, b) => (a.kind === 'moc' ? 1 : 0) - (b.kind === 'moc' ? 1 : 0))[0]
    const next = now ? null : plan.filter(d => d.date > today && real(d)).sort((a, b) => a.date.localeCompare(b.date))[0]
    return (
      <Sheet open={open} onClose={close}>
        <b style={{ fontSize: rem(17), letterSpacing: '-.02em' }}>Na kratko</b>
        <div className="stack" style={{ gap: 8, marginTop: 10, fontSize: rem(13.5), color: 'var(--ink-2)', lineHeight: 1.5 }}>
          {now ? <p>Danes: <B>{titleNoDur(now.title, now.durationMin)}</B>{now.durationMin ? ` · ${fmtDur(now.durationMin)}` : ''}.</p>
            : next ? <p>Danes počitek. Naslednji trening: <B>{dl(next.date)}</B> — {next.title}.</p> : null}
          {/* (v3.51) »ura ga odkljuka« samo s povezano uro (intervals.icu) — prej vsem, ki niso napisali »nimam ure« */}
          <p>Ko trening narediš, tapni <B>Opravil</B>{settings.intervals || settings.garmin?.connected ? ' (povezana ura ga odkljuka sama)' : ' — tako načrt ve, kaj si naredil'}.</p>
          <p>Kalorije in recept za vsak obrok so v <B>Prehrani</B> — na dan treninga ješ več.</p>
          <HealthNote kind="both" style={{ marginTop: 0 }} />
        </div>
        <div className="row" style={{ gap: 8, marginTop: 16 }}>
          <Btn ghost onClick={() => { setI(0); setShort(false) }}>Več</Btn>
          <Btn primary block onClick={close}>Začniva</Btn>
        </div>
      </Sheet>
    )
  }
  return (
    <Sheet open={open} onClose={close}>
      <div className="between"><b style={{ fontSize: rem(17), letterSpacing: '-.02em' }}>{steps[i]!.t}</b><span className="muted" style={{ fontSize: rem(12), fontWeight: 700 }}>{i + 1} / {steps.length}</span></div>
      <div style={{ margin: '10px 0 12px' }}><Progress pct={((i + 1) / steps.length) * 100} /></div>
      <div className="stack" style={{ gap: 8, fontSize: rem(13.5), color: 'var(--ink-2)', lineHeight: 1.5 }}>{steps[i]!.body}</div>
      <div className="row" style={{ gap: 8, marginTop: 16 }}>
        {i > 0 && <Btn ghost onClick={() => setI(i - 1)}>Nazaj</Btn>}
        <Btn primary block onClick={() => (last ? close() : setI(i + 1))}>{last ? 'Začniva' : 'Naprej'}</Btn>
      </div>
    </Sheet>
  )
}
