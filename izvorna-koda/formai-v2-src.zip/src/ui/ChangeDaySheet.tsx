import type { PlanDay } from '@/domain/types'
import { Btn, Sheet } from '@/ui/primitives'
import { titleNoDur } from '@/domain/training/load'
import { dayAcc } from '@/ui/format'
import { rem } from '@/ui/rem'

export interface ChangeOpt { t: string; d: string; go: () => void }

/**
 * (v3.51) brez »bolje en manj kot bolezen« (ko nisi bolan, je bil stavek nejasen)
 * (v3.50 A03) »Olajšaj dan«: podnapis in obvestilo po izidu `easeDay` — kam gre seja ali da ta teden odpade (prej »gre na
 * prost dan tega tedna« tudi v nedeljo, ko je seja tiho odpadla; obvestilo samo »Danes lahko.«).
 */
export function easeTexts(main: Pick<PlanDay, 'title' | 'durationMin' | 'role'>, out: readonly Pick<PlanDay, 'date'>[] | null, today: string): { sub: string; toast: string } {
  const what = titleNoDur(main.title, main.durationMin)
  const to = out?.find(d => d.date !== today)?.date ?? null
  const hard = main.role === 'kljucna' || main.role === 'test' || main.role === 'dolga'
  return {
    sub: `${hard ? 'Danes samo lahko' : 'Danes 30–45 min zelo lahko'}; ${to ? `${what} gre na ${dayAcc(to)}.` : `${what} ta teden odpade — en trening manj ne škodi.`}`,
    toast: to ? `Danes lahko. ${what} gre na ${dayAcc(to)}.` : `Danes lahko. ${what} ta teden odpade.`,
  }
}

/**
 * »Spremeni« pri današnjem treningu: vse možnosti na enem mestu (prej šest gumbov in čipov pod treningom).
 * Vsaka z eno vrstico, kaj se zgodi.
 */
export function ChangeDaySheet({ day, opts, onClose, title = 'Spremeni današnji trening' }: { day: PlanDay; opts: ChangeOpt[]; onClose: () => void; title?: string }) {
  return (
    <Sheet open onClose={onClose} label={title}>
      <h2 className="sheet-t">{title}</h2>
      <p className="muted" style={{ fontSize: rem(12.5), marginTop: 3 }}>{day.title}</p>
      <div className="stack" style={{ gap: 8, marginTop: 12 }}>
        {opts.map(o => <button key={o.t} type="button" className="skip-opt" onClick={() => { onClose(); setTimeout(o.go, 30) }}><b>{o.t}</b><small>{o.d}</small></button>)}
      </div>
      <Btn ghost block style={{ marginTop: 12 }} onClick={onClose}>Prekliči</Btn>
    </Sheet>
  )
}
