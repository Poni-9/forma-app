import type { PlanDay } from '@/domain/types'
import { Btn, Sheet } from '@/ui/primitives'

export interface ChangeOpt { t: string; d: string; go: () => void }

/**
 * »Spremeni« pri današnjem treningu: vse možnosti na enem mestu (prej šest gumbov in čipov pod treningom).
 * Vsaka z eno vrstico, kaj se zgodi.
 */
export function ChangeDaySheet({ day, opts, onClose }: { day: PlanDay; opts: ChangeOpt[]; onClose: () => void }) {
  return (
    <Sheet open onClose={onClose} label="Spremeni današnji trening">
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Spremeni današnji trening</b>
      <p className="muted" style={{ fontSize: 12.5, marginTop: 3 }}>{day.title}</p>
      <div className="stack" style={{ gap: 8, marginTop: 12 }}>
        {opts.map(o => <button key={o.t} type="button" className="skip-opt" onClick={() => { onClose(); setTimeout(o.go, 30) }}><b>{o.t}</b><small>{o.d}</small></button>)}
      </div>
      <Btn ghost block style={{ marginTop: 12 }} onClick={onClose}>Prekliči</Btn>
    </Sheet>
  )
}
