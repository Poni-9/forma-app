import { useEffect, useState } from 'react'
import { useApp, answerPilot, skipPilot, optOutPilot, toast } from '@/state/store'
import { useRoute } from '@/app/router'
import { pilotDue, LETTERS, type PilotQuestion } from '@/domain/pilot'
import { Sheet } from './primitives'

/** Zasloni, kjer vprašanje ne sme zmotiti (trening, uvod, prijava, pregled). */
const QUIET = new Set(['vadba', 'uvod', 'prijava', 'pilot'])

/**
 * Tedensko vprašanje testnega programa: en klik (A–D), ob naključnem trenutku med uporabo (20–75 s po odprtju,
 * nikoli med treningom, vodnikom ali odprtim listom). Največ eno na teden; preskok šteje kot odgovor.
 */
export function PilotPrompt() {
  const app = useApp()
  const route = useRoute()
  const [open, setOpen] = useState<PilotQuestion | null>(null)
  const start = app.profile.goalStart?.date ?? app.profile.createdAt?.slice(0, 10) ?? null
  const use = { meals: app.recentMeals.length >= 3, coach: (app.settings.coach?.msgs?.length ?? 0) >= 2 }
  const due = app.ready && app.profile.onboardingDone && app.settings.guideSeen !== false ? pilotDue(app.settings.pilot, start, app.today, use) : null
  const dueQ = due?.q ?? null

  useEffect(() => {
    if (!dueQ || open) return
    let t = 0
    const tryShow = () => {
      const busy = document.visibilityState !== 'visible' || !!document.querySelector('.sheet') || QUIET.has(location.hash.replace(/^#\/?/, '').split('?')[0] || '')
      if (busy) { t = window.setTimeout(tryShow, 15_000); return }
      setOpen(due)
    }
    t = window.setTimeout(tryShow, 20_000 + Math.random() * 55_000)
    return () => clearTimeout(t)
  }, [dueQ])      // eslint-disable-line react-hooks/exhaustive-deps

  // med treningom ali uvodom se ne pokaže (tudi če je čas že potekel)
  if (!open || QUIET.has(route.name)) return null
  const q = open
  const pick = async (i: number) => { setOpen(null); await answerPilot(q.q, LETTERS[i]!); toast('Hvala! Odgovor gre naravnost v razvoj FORMAI.', 'ok') }
  return (
    <Sheet open onClose={() => { setOpen(null); void skipPilot(q.q) }}>
      <div className="muted" style={{ fontSize: 11, fontWeight: 800, letterSpacing: '.08em' }}>VPRAŠANJE TEDNA · EN KLIK</div>
      <b style={{ display: 'block', fontSize: 17, letterSpacing: '-.02em', marginTop: 6 }}>{q.text}</b>
      <div className="abcd" style={{ marginTop: 14 }}>
        {q.options.map((o, i) => (
          <button key={i} type="button" className="abcd-opt" onClick={() => void pick(i)}><span>{LETTERS[i]!.toUpperCase()}</span>{o}</button>
        ))}
      </div>
      <div className="between" style={{ marginTop: 12 }}>
        <button className="chip sm click" onClick={() => { setOpen(null); void skipPilot(q.q) }}>preskoči</button>
        <button className="chip sm click" onClick={() => { setOpen(null); void skipPilot(q.q); void optOutPilot() }}>ne sprašuj več</button>
      </div>
      <p className="muted" style={{ fontSize: 11, marginTop: 10 }}>Brez imena, e-pošte in podatkov o treningu. Največ eno vprašanje na teden. <a href="/zasebnost.html" target="_blank" rel="noopener" style={{ color: 'inherit' }}>Zasebnost</a></p>
    </Sheet>
  )
}
