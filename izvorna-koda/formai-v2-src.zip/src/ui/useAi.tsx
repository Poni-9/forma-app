import { useRef, useState, type ReactNode } from 'react'
import { useApp, signIn, grantAiConsent, toast } from '@/state/store'
import { PrivolitevSheet } from '@/screens/Privolitev'
import { aiErrorText, isConsentError, isAuthError, AiError } from '@/domain/ai/actions'

/**
 * Vrata do AI za zaslone: poskrbi za prijavo (AI teče prek strežnika s Firebase žetonom),
 * privolitev (GDPR) in prijazno sporočanje napak. Zaslon pokliče run(() => …) in izriše sheet.
 */
export function useAi() {
  const app = useApp()
  const [consentOpen, setConsentOpen] = useState(false)
  const [busy, setBusy] = useState(false)
  const pending = useRef<(() => Promise<void>) | null>(null)

  async function run<T>(fn: () => Promise<T>): Promise<T | undefined> {
    if (!app.user) {
      toast('AI teče prek tvojega računa — prijava traja sekundo.', 'info', 2500)
      const u = await signIn().catch((e: Error) => { toast(e.message, 'err'); return null })
      if (!u) return undefined
    }
    if (!app.profile.aiConsentAt) {
      pending.current = async () => { await run(fn) }
      setConsentOpen(true)
      return undefined
    }
    setBusy(true)
    try { return await fn() }
    catch (e) {
      if (isConsentError(e)) { pending.current = async () => { await run(fn) }; setConsentOpen(true); return undefined }
      if (isAuthError(e)) { toast(aiErrorText(e), 'err', 6000); return undefined }
      if (e instanceof AiError && e.kind === 'quota') { toast(aiErrorText(e), 'err', 9000); return undefined }
      toast(aiErrorText(e), 'err', 7000)
      return undefined
    } finally { setBusy(false) }
  }

  const sheet: ReactNode = (
    <PrivolitevSheet
      open={consentOpen}
      onClose={() => { setConsentOpen(false); pending.current = null }}
      onAccept={async () => { await grantAiConsent(); setConsentOpen(false); const p = pending.current; pending.current = null; if (p) await p() }}
    />
  )
  return { run, busy, sheet, signedIn: !!app.user, consent: !!app.profile.aiConsentAt }
}
