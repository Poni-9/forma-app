import { useEffect, useRef, useState, type ReactNode } from 'react'
import { useApp, getState, signIn, grantAiConsent, toast } from '@/state/store'
import { PrivolitevSheet } from '@/screens/Privolitev'
import { aiErrorText, isConsentError, isAuthError, AiError } from '@/domain/ai/actions'

type Pending = { fn: () => Promise<unknown>; resolve: (v: unknown) => void }
export const OFFLINE_AI = 'Ni povezave z internetom — AI potrebuje povezavo. Poskusi, ko boš spet na spletu.'

/**
 * Vrata do AI za zaslone: prijava (AI teče prek strežnika s Firebase žetonom), privolitev (GDPR) in prijazno
 * sporočanje napak. Prvič je to en tok: prijava → privolitev → odgovor — run() se razreši šele z odgovorom
 * (ali z undefined, če uporabnik odneha), zato klicatelj po njem normalno nadaljuje.
 *
 * Pomembno: fn naj stanje prebere ob klicu (getState()), ne iz izrisa — po privolitvi je profil nov:
 *   ai.run(() => dailyAdvice(snapOf(getState()), …))
 */
export function useAi() {
  const app = useApp()
  const [consentOpen, setConsentOpen] = useState(false)
  const [busy, setBusy] = useState(false)
  const pending = useRef<Pending | null>(null)
  const signing = useRef(false)
  // zaslon zaprt med privolitvijo: čakajoči klic se konča brez odgovora
  useEffect(() => () => { pending.current?.resolve(undefined); pending.current = null }, [])

  function askConsent<T>(fn: () => Promise<T>): Promise<T | undefined> {
    return new Promise<T | undefined>(resolve => {
      pending.current?.resolve(undefined)
      pending.current = { fn, resolve: resolve as (v: unknown) => void }
      setConsentOpen(true)
    })
  }

  type RunOpts = { quiet?: boolean; /** razlog, ko AI ne odgovori (zaslon ga pokaže v pogovoru) */ onError?: (msg: string) => void }
  async function call<T>(fn: () => Promise<T>, afterConsent = false, opts?: RunOpts): Promise<T | undefined> {
    setBusy(true)
    try { return await fn() }
    catch (e) {
      // privolitev preklicana drugje (druga naprava) → vprašaj znova; takoj po privolitvi ne zanki
      if (isConsentError(e) && !afterConsent) { setBusy(false); return askConsent(fn) }
      opts?.onError?.(aiErrorText(e))
      if (isAuthError(e)) { toast(aiErrorText(e), 'err', 6000); return undefined }
      if (e instanceof AiError && e.kind === 'quota') { toast(aiErrorText(e), 'err', 9000); return undefined }
      // tiho: zaslon ima svojo rezervo brez AI in to sam pove (npr. Sestaviva načrt)
      if (!opts?.quiet) toast(aiErrorText(e), 'err', 7000)
      return undefined
    } finally { setBusy(false) }
  }

  async function run<T>(fn: () => Promise<T>, opts?: RunOpts): Promise<T | undefined> {
    // brez interneta ne odpiraj prijave (prej: »Prijava ni uspela.«) — povej, kaj je narobe; vnos ostane, kjer je
    if (typeof navigator !== 'undefined' && navigator.onLine === false) { toast(OFFLINE_AI, 'err', 6000); opts?.onError?.(OFFLINE_AI); return undefined }
    if (import.meta.env.VITE_E2E === '1') return call(fn, false, opts)   // samo testna gradnja: brez prijave in privolitve
    if (!getState().user) {
      if (signing.current) return undefined        // Google okno je že odprto
      signing.current = true
      toast('AI teče prek tvojega računa — prijava traja sekundo.', 'info', 2500)
      const u = await signIn().catch((e: Error) => { toast(e.message, 'err'); return null }).finally(() => { signing.current = false })
      if (!u) return undefined
    }
    if (!getState().profile.aiConsentAt) return askConsent(fn)
    return call(fn, false, opts)
  }

  const sheet: ReactNode = (
    <PrivolitevSheet
      open={consentOpen}
      onClose={() => { setConsentOpen(false); const p = pending.current; pending.current = null; p?.resolve(undefined) }}
      onAccept={async () => {
        await grantAiConsent()
        setConsentOpen(false)
        const p = pending.current
        pending.current = null
        if (p) p.resolve(await call(p.fn, true))   // naravnost na odgovor — brez ponovne prijave ali lista
      }}
    />
  )
  return { run, busy, sheet, signedIn: !!app.user, consent: !!app.profile.aiConsentAt }
}
