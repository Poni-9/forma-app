import { useState } from 'react'
import { useApp } from '@/state/store'
import { navigate } from '@/app/router'
import { lastWeekSummary } from '@/domain/coach/local'
import { weekContext } from '@/domain/training/planner'
import { weekStartIso } from '@/domain/training/load'
import { Card } from '@/ui/primitives'
import { dm } from '@/ui/format'

const KEY = 'formai.lastWeek.'

/** Ponedeljek: kako je šel pretekli teden (seje, ure, ključni, občutek) in kaj je ta teden — brez AI, en pogled. */
export function LastWeekCard() {
  const app = useApp()
  const ws = weekStartIso(app.today)
  const [gone, setGone] = useState(() => { try { return localStorage.getItem(KEY + ws) === '1' } catch { return false } })
  if (app.today !== ws || gone) return null
  const s = lastWeekSummary(app.plan, app.activities, app.today)
  if (!s) return null
  const cx = weekContext(app.profile, ws)
  const hide = () => { try { localStorage.setItem(KEY + ws, '1') } catch { /* zasebni način */ } setGone(true) }
  return (
    <Card tight className="lastweek-card">
      <div className="between" style={{ gap: 10, alignItems: 'baseline' }}>
        <h2 className="h4" style={{ fontSize: 11, margin: 0 }}>Pretekli teden · od {dm(s.from)}</h2>
        <button type="button" className="chip sm click" onClick={hide}>skrij</button>
      </div>
      <ul className="state-lines">{s.lines.map(l => <li key={l}>{l}</li>)}</ul>
      <div className="row" style={{ gap: 8, marginTop: 8, alignItems: 'center', flexWrap: 'wrap' }}>
        {cx.structured && <span className="muted" style={{ fontSize: 12 }}>Ta teden: {cx.recovery ? 'razbremenilni' : cx.phaseName.toLowerCase()}, ~{String(cx.hours).replace('.', ',')} h.</span>}
        <button type="button" className="chip sm click" onClick={() => navigate('trener')}>Pregled s trenerjem</button>
      </div>
    </Card>
  )
}
