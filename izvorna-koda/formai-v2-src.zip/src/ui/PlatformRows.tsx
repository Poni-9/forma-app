import { useState } from 'react'
import { APP_VERSION } from '@/config'
import { useApp, toast } from '@/state/store'
import { checkForUpdate, applyUpdate } from '@/app/sw'
import { isStandalone } from '@/ui/motion'
import { InstallSheet } from '@/ui/InstallSheet'
import { Btn } from '@/ui/primitives'

/** (v3.50) Izid »Preveri posodobitve« → besedilo obvestila (nova različica dobi gumb »Osveži«). */
export function updateCheckText(r: 'nova' | 'zadnja' | 'offline' | 'ni'): string {
  return r === 'nova' ? 'Nova različica je pripravljena.' : r === 'zadnja' ? 'Imaš zadnjo različico.'
    : r === 'offline' ? 'Brez povezave — posodobitev zdaj ne morem preveriti.' : 'Posodobitev v tem brskalniku ni mogoče preveriti.'
}

/** (v3.50) Nastavitve, spodaj: različica in »Preveri posodobitve« (prej samo »FORMAI v…« brez dejanja). */
export function UpdateRow() {
  const [busy, setBusy] = useState(false)
  async function check() {
    if (busy) return
    setBusy(true)
    const r = typeof navigator !== 'undefined' && navigator.onLine === false ? 'offline' : await checkForUpdate().catch(() => 'offline' as const)
    setBusy(false)
    toast(updateCheckText(r), r === 'zadnja' ? 'ok' : 'info', r === 'nova' ? 20_000 : 4200, r === 'nova' ? { label: 'Osveži', run: applyUpdate } : undefined)
  }
  return (
    <div className="muted" style={{ fontSize: 11.5, padding: '0 4px 16px', textAlign: 'center' }}>
      FORMAI v{APP_VERSION} · <button type="button" className="lnk-hit" style={{ border: 0, background: 'none', font: 'inherit', cursor: 'pointer' }} onClick={() => void check()} aria-busy={busy}>{busy ? 'Preverjam …' : 'Preveri posodobitve'}</button>
    </div>
  )
}

/** (v3.50) Nastavitve → Pomoč: namestitev tudi po »Pozneje« (prej poziv enkrat, potem nikjer). Samo telefon v brskalniku. */
export function InstallRow() {
  const [open, setOpen] = useState(false)
  if (isStandalone() || (typeof window !== 'undefined' && window.innerWidth >= 900)) return null
  return (<>
    <Btn sm ghost onClick={() => setOpen(true)}>Namesti na telefon</Btn>
    {open && <InstallSheet open onClose={() => setOpen(false)} />}
  </>)
}

/** (v3.50) Oblak hrani skrajšano kopijo (veliko podatkov): povej, da druga naprava ne vidi vsega (prej tiho). */
export function cloudTrimText(t: { acts: number; mealDays: number } | null | undefined): string | null {
  return t ? `V oblaku je zadnjih ${t.acts} vadb in ${t.mealDays} dni obrokov — starejše so samo na tej napravi. Za vse izvozi kopijo.` : null
}
export function CloudTrimNote() {
  const s = cloudTrimText(useApp().sync?.trimmed)
  return s ? <p style={{ fontSize: 12.5, marginTop: 8, fontWeight: 600, color: 'var(--warn)' }}>{s}</p> : null
}
