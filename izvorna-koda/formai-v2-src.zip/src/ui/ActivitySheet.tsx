import { useState } from 'react'
import { useApp, saveActivity, rateSession } from '@/state/store'
import type { Activity } from '@/domain/types'
import { aiAllowed, sourceLabel } from '@/domain/import/provenance'
import { checkRide } from '@/domain/training/review'
import { fmtDur } from '@/domain/training/load'
import { Sheet, Btn, Chip, KindIcon, kindColor } from '@/ui/primitives'
import { RateRow } from '@/ui/RateRow'
import { RouteMap } from '@/ui/RouteMap'
import { IcoMap } from '@/ui/icons'
import { dayName, dmy, int, num, NBSP } from '@/ui/format'

const SPORT_LABEL: Record<string, string> = { kolo: 'Kolo', tek: 'Tek', pohod: 'Hoja', moc: 'Moč', plavanje: 'Plavanje', drugo: 'Drugo' }

/** Cone utripa vadbe: minute po conah (z mejami iz ure) in delež lahko · tempo · prag+ (kot v Napredku). */
export function hrZoneRows(a: Pick<Activity, 'hrZoneSec' | 'hrZoneTop'>): { rows: { key: string; range: string; min: number }[]; easy: number; mid: number; hard: number; total: number } | null {
  const z = a.hrZoneSec
  if (!z || z.length < 4) return null
  const total = z.reduce((s, v) => s + (v || 0), 0)
  if (total < 60) return null
  const top = a.hrZoneTop || []
  const rows = z.map((sec, i) => {
    const lo = i > 0 && top[i - 1] ? top[i - 1]! + 1 : null, hi = top[i] ?? null
    const range = lo == null ? (hi ? `do ${hi}` : '') : i === z.length - 1 || !hi ? `nad ${lo - 1}` : `${lo}–${hi}`
    return { key: `Z${i + 1}`, range, min: Math.round((sec || 0) / 60) }
  }).filter(r => r.min > 0)
  const e = (z[0] || 0) + (z[1] || 0), m = z[2] || 0, h = z.slice(3).reduce((s, v) => s + (v || 0), 0)
  return { rows, easy: Math.round((e / total) * 100), mid: Math.round((m / total) * 100), hard: Math.round((h / total) * 100), total: Math.round(total / 60) }
}

/**
 * Podrobnosti vadbe: številke, cone utripa, sled na zemljevidu, dan načrta, ki ga je pokrila (in kako), občutek (RPE),
 * opomba in ime. Vse spremembe se shranijo takoj (in v oblak); izbris z »Razveljavi« naredi seznam.
 */
export function ActivitySheet({ id, onClose, onDelete }: { id: string; onClose: () => void; onDelete: (a: Activity) => void }) {
  const app = useApp()
  const a = app.activities.find(x => x.id === id)
  const [name, setName] = useState(a?.name || '')
  const [note, setNote] = useState(a?.notes || '')
  const [map, setMap] = useState(false)
  if (!a) return null
  const day = app.plan.find(d => d.done?.activityId === a.id) || null
  const chk = day ? checkRide(day, a) : null
  const rpe = a.rpe ?? day?.rpe ?? null
  const zones = hrZoneRows(a)
  const ok = aiAllowed(a)
  const kpis: [string, string][] = ([
    a.distKm ? [`${num(a.distKm)}${NBSP}km`, 'razdalja'] : null,
    a.durationMin ? [fmtDur(a.durationMin), a.elapsedMin && a.elapsedMin - a.durationMin >= 5 ? `gibanje · s postanki ${fmtDur(a.elapsedMin)}` : 'čas'] : null,
    a.elevM ? [`${int(a.elevM)}${NBSP}m`, 'vzpon'] : null,
    a.avgHr ? [`${Math.round(a.avgHr)}${a.maxHr ? ` / ${Math.round(a.maxHr)}` : ''}`, a.maxHr ? 'utrip povp. / max' : 'povprečni utrip'] : null,
    a.avgPower ? [`${Math.round(a.avgPower)}${NBSP}W`, a.deviceWatts === false ? 'moč (ocena)' : 'povprečna moč'] : null,
    a.speedKmh || (a.distKm && a.durationMin) ? [`${num(a.speedKmh || (a.distKm! / (a.durationMin! / 60)))}${NBSP}km/h`, 'hitrost'] : null,
    a.tss ? [String(Math.round(a.tss)), 'TSS'] : null,
    a.kcal ? [`${int(a.kcal)}`, 'kcal'] : null,
  ] as ([string, string] | null)[]).filter((x): x is [string, string] => !!x)
  async function saveName() {
    const t = name.trim().slice(0, 60)
    if (!t || t === a!.name) { setName(a!.name); return }
    await saveActivity({ ...a!, name: t, named: true })
  }
  async function saveNote() {
    const t = note.trim().slice(0, 400)
    if (t === (a!.notes || '')) return
    const { notes: _n, ...rest } = a!
    void _n
    await saveActivity(t ? { ...a!, notes: t } : (rest as Activity))
  }
  const h = { fontSize: 10.5, fontWeight: 800, letterSpacing: '.08em', color: 'var(--ink-3)', textTransform: 'uppercase' as const, marginTop: 16 }
  return (
    <Sheet open onClose={onClose} label={`Vadba: ${a.name}`}>
      <div className="row" style={{ gap: 10, alignItems: 'center' }}>
        <span style={{ width: 34, height: 34, borderRadius: 10, display: 'grid', placeItems: 'center', flex: 'none', color: kindColor(a.sport), background: 'rgba(255,255,255,.06)' }}><KindIcon kind={a.sport} size={18} /></span>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: '.08em', color: kindColor(a.sport) }}>{(SPORT_LABEL[a.sport] || 'Vadba').toUpperCase()} · {dayName(a.date).toUpperCase()} {dmy(a.date, app.today)}</div>
          <b style={{ fontSize: 17, letterSpacing: '-.02em', display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.name}</b>
        </div>
      </div>

      {kpis.length > 0 && <div className="kpis act-kpis">{kpis.map(([v, l]) => <div key={l} className="kpi"><b>{v}</b><small>{l}</small></div>)}</div>}

      {day && <>
        <div style={h}>Načrt</div>
        <div style={{ fontSize: 13, marginTop: 4, color: 'var(--ink-2)' }}><b style={{ color: 'var(--ink)' }}>{day.title}</b> · {fmtDur(day.durationMin)}</div>
        {chk && <div style={{ fontSize: 12.5, fontWeight: 700, marginTop: 3, color: chk.status === 'ok' ? 'var(--ok)' : chk.status === 'delno' ? 'var(--warn)' : 'var(--bad)' }}>{chk.verdict}</div>}
      </>}

      {zones && <>
        <div className="between" style={{ ...h, display: 'flex' }}><span>Utrip po conah</span><span style={{ letterSpacing: 0, textTransform: 'none', fontWeight: 600 }}>{zones.total}{NBSP}min</span></div>
        <div style={{ display: 'flex', height: 10, borderRadius: 5, overflow: 'hidden', gap: 2, marginTop: 8 }} aria-hidden="true">
          {zones.easy > 0 && <i style={{ flex: zones.easy, background: 'var(--t-kolo)' }} />}{zones.mid > 0 && <i style={{ flex: zones.mid, background: 'var(--warn)' }} />}{zones.hard > 0 && <i style={{ flex: zones.hard, background: 'var(--t-moc)' }} />}
        </div>
        <div className="muted" style={{ fontSize: 11.5, marginTop: 5 }}>{zones.easy}{NBSP}% lahko (Z1–Z2) · {zones.mid}{NBSP}% tempo · {zones.hard}{NBSP}% prag in više</div>
        <div className="zone-rows">{zones.rows.map(r => <div key={r.key} className="between"><span><b>{r.key}</b>{r.range ? <span className="muted"> · {r.range}</span> : null}</span><span>{r.min}{NBSP}min</span></div>)}</div>
      </>}

      {a.exercises?.length ? <>
        <div style={h}>Vaje</div>
        {a.exercises.map((e, k) => <div key={k} className="between" style={{ fontSize: 13, padding: '3px 0' }}><b style={{ minWidth: 0 }}>{e.name}</b><span className="muted" style={{ flex: 'none' }}>{e.sets} × {e.reps}{e.kg ? ` · ${num(e.kg)}${NBSP}kg` : ''}</span></div>)}
      </> : null}

      <div style={h}>Kako je šlo?</div>
      <RateRow value={rpe} onPick={v => void rateSession({ activityId: a.id }, v)} label="Občutek" />

      <div className="field" style={{ marginTop: 16 }}>
        <label htmlFor="act-note">Opomba</label>
        <textarea id="act-note" rows={2} value={note} maxLength={400} placeholder="Npr. veter v prsi, noge težke od včeraj …" onChange={e => setNote(e.target.value)} onBlur={() => void saveNote()} style={{ resize: 'none', minHeight: 64 }} />
      </div>
      <div className="field" style={{ marginTop: 12 }}>
        <label htmlFor="act-name">Ime</label>
        <input id="act-name" value={name} maxLength={60} onChange={e => setName(e.target.value)} onBlur={() => void saveName()} onKeyDown={e => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur() }} />
      </div>

      <div className="row" style={{ gap: 6, marginTop: 14, flexWrap: 'wrap' }}>
        <Chip sm ok={ok}>{sourceLabel(a)} · {ok ? 'trener vidi' : 'trener ne vidi'}</Chip>
        {a.trainer && <Chip sm>trenažer</Chip>}
      </div>
      <div className="row" style={{ gap: 8, marginTop: 14, flexWrap: 'wrap' }}>
        {a.polyline && <Btn ghost sm onClick={() => setMap(true)}><IcoMap width={15} height={15} /> Zemljevid</Btn>}
        <Btn ghost sm onClick={() => { onClose(); onDelete(a) }}>Izbriši</Btn>
        <div className="grow" />
        <Btn sm onClick={async () => { await saveName(); await saveNote(); onClose() }}>Končano</Btn>
      </div>
      {a.polyline && <RouteMap open={map} onClose={() => setMap(false)} poly={a.polyline} climb={null} title={a.name} />}
    </Sheet>
  )
}
