import { useEffect, useState } from 'react'
import { useApp, getState, saveActivity, rateSession, setPlanDone, toast } from '@/state/store'
import { pickDoneDay } from '@/domain/training/fromPhoto'
import { useConfirm } from '@/ui/Confirm'
import type { Activity, Profile, Sport } from '@/domain/types'
import { aiAllowed, sourceLabel } from '@/domain/import/provenance'
import { checkRide } from '@/domain/training/review'
import { estimateTss, fmtDur, todayIso } from '@/domain/training/load'
import { manualActivityErrors, parseNum, ACTIVITY_RANGE } from '@/domain/ranges'
import { DateField } from '@/ui/DateField'
import { Sheet, Btn, Chip, KindIcon, kindColor, kindInk, DecimalInput } from '@/ui/primitives'
import { RateRow } from '@/ui/RateRow'
import { RouteMap } from '@/ui/RouteMap'
import { IcoMap } from '@/ui/icons'
import { dayName, dmy, int, num, NBSP } from '@/ui/format'
import { rem } from '@/ui/rem'

const SPORT_LABEL: Record<string, string> = { kolo: 'Kolo', tek: 'Tek', pohod: 'Hoja', moc: 'Moč', plavanje: 'Plavanje', drugo: 'Drugo' }
const SPORTS: Sport[] = ['kolo', 'tek', 'pohod', 'moc', 'plavanje', 'drugo']
/** (v3.51) namig opombe po športu (prej »veter v prsi« tudi pri moči in plavanju) */
export const NOTE_HINT: Record<string, string> = {
  kolo: 'Npr. veter v prsi, noge težke od včeraj …', tek: 'Npr. vroče, desno koleno čutim …', pohod: 'Npr. strm vzpon, kolena pri spustu …',
  moc: 'Npr. počep je šel lažje, rama boli …', plavanje: 'Npr. ramena utrujena, dihanje lažje …', drugo: 'Npr. kako je šlo …',
}
/** Polja ročnega vnosa po športu (v3.48): pri moči brez razdalje, vzpona in vatov; pri plavanju brez vzpona in vatov. (v3.50) tu, da ga uporablja tudi popravek vadbe */
export function manualFields(s: Sport): { dist: boolean; elev: boolean; power: boolean } {
  const noRide = s === 'moc' || s === 'plavanje'
  return { dist: s !== 'moc', elev: !noRide, power: !noRide }
}

/** (v3.50) Vadbe, ki jih lahko popraviš (z ure iz intervals.icu ne — tam jo popravi vir, uvoz bi jo vrnil). */
const EDITABLE = new Set<Activity['source']>(['manual', 'screenshot', 'file', 'archive'])
/** (v3.51) tudi kalorije in povprečna moč (napačno prebrane s posnetka) */
export interface EditForm { sport: Sport; date: string; min: string; dist: string; elev: string; hr: string; kcal?: string; power?: string }
export const editFormOf = (a: Activity): EditForm => ({ sport: a.sport, date: a.date, min: a.durationMin ? String(a.durationMin) : '', dist: a.distKm ? String(a.distKm).replace('.', ',') : '', elev: a.elevM ? String(a.elevM) : '', hr: a.avgHr ? String(a.avgHr) : '', kcal: a.kcal ? String(Math.round(a.kcal)) : '', power: a.avgPower ? String(Math.round(a.avgPower)) : '' })
/** (v3.51) obrazec popravka se razlikuje od vadbe (Končano, Esc ali Nazaj ga shrani) */
export const editDirty = (a: Activity, f: EditForm): boolean => JSON.stringify(editFormOf(a)) !== JSON.stringify({ ...editFormOf(a), ...f })
/** (v3.50) Popravljena vadba: nove številke, hitrost in obremenitev (TSS) znova. Polja, ki jih šport nima (km pri moči), gredo ven. */
export function applyEdit(a: Activity, f: EditForm, p: Profile): Activity {
  const fl = manualFields(f.sport)
  const n = (v: string | undefined) => { const x = parseNum(v); return x != null && x > 0 ? x : null }
  const durationMin = n(f.min) != null ? Math.round(n(f.min)!) : null
  const distKm = fl.dist ? n(f.dist) : null
  // (v3.51) kalorije: nespremenjene ob krajšem/daljšem trajanju sorazmerno (90 → 45 min: 900 → 450 kcal), vpisane veljajo
  const k0 = a.kcal ? Math.round(a.kcal) : null, kIn = f.kcal === undefined ? k0 : n(f.kcal)
  const kcal = kIn == null ? null : kIn === k0 && a.durationMin && durationMin && durationMin !== a.durationMin ? Math.round(kIn * durationMin / a.durationMin) : Math.round(kIn)
  const power = f.power === undefined ? a.avgPower ?? null : n(f.power) != null ? Math.round(n(f.power)!) : null
  const next: Activity = {
    ...a, sport: f.sport, date: f.date || a.date, durationMin, distKm, elevM: fl.elev ? (n(f.elev) != null ? Math.round(n(f.elev)!) : null) : null,
    avgHr: n(f.hr) != null ? Math.round(n(f.hr)!) : null, avgPower: fl.power ? power : null, kcal,
    speedKmh: distKm && durationMin ? +(distKm / (durationMin / 60)).toFixed(1) : null, updatedAt: new Date().toISOString(),
  }
  // z ure prebrana obremenitev ne velja več, ko se spremenijo številke
  next.tss = estimateTss(next, p)
  return next
}

/** Cone utripa vadbe: minute po conah (z mejami iz ure) in delež lahko · tempo · prag+ (kot v Napredku). */
export function hrZoneRows(a: Pick<Activity, 'hrZoneSec' | 'hrZoneTop'>): { rows: { key: string; range: string; min: number }[]; easy: number; mid: number; hard: number; total: number } | null {
  const z = a.hrZoneSec
  if (!z || z.length < 4) return null
  const total = z.reduce((s, v) => s + (v || 0), 0)
  if (total < 60) return null
  const top = a.hrZoneTop || []
  const rows = z.map((sec, i) => {
    const lo = i > 0 && top[i - 1] ? top[i - 1]! + 1 : null, hi = top[i] ?? null
    const range = lo == null ? (hi ? `do ${hi}` : '') : i === z.length - 1 || !hi ? `nad ${lo - 1}` : `${lo}–${hi}`
    return { key: `Z${i + 1}`, range, min: Math.round((sec || 0) / 60) }
  }).filter(r => r.min > 0)
  const e = (z[0] || 0) + (z[1] || 0), m = z[2] || 0, h = z.slice(3).reduce((s, v) => s + (v || 0), 0)
  return { rows, easy: Math.round((e / total) * 100), mid: Math.round((m / total) * 100), hard: Math.round((h / total) * 100), total: Math.round(total / 60) }
}

/**
 * Podrobnosti vadbe: številke, cone utripa, sled na zemljevidu, dan načrta, ki ga je pokrila (in kako), občutek (RPE),
 * opomba in ime. Vse spremembe se shranijo takoj (in v oblak); izbris z »Razveljavi« naredi seznam.
 */
export function ActivitySheet({ id, onClose, onDelete }: { id: string; onClose: () => void; onDelete: (a: Activity) => void }) {
  const app = useApp()
  const a = app.activities.find(x => x.id === id)
  const [name, setName] = useState(a?.name || '')
  const [note, setNote] = useState(a?.notes || '')
  const [map, setMap] = useState(false)
  const [ed, setEd] = useState<EditForm | null>(null)
  const [edNeed, setEdNeed] = useState(false)
  const { confirm, sheet: confirmSheet } = useConfirm()
  // (v3.51) po »Uredi« fokus v obrazec (prej je ostal na <body>, gumb »Uredi« je izginil)
  const edOpen = !!ed
  useEffect(() => { if (edOpen) { const el = document.getElementById('ae-min'); el?.focus({ preventScroll: true }); el?.scrollIntoView?.({ block: 'nearest' }) } }, [edOpen])
  if (!a) return null
  // (v3.49) zapis iz načrta: njegov dan (ocena gre nanj); preverbe vožnje ni — ni utripa ne moči
  const day = app.plan.find(d => d.done?.activityId === a.id) || (a.planDayId ? app.plan.find(d => d.id === a.planDayId) : null) || null
  const chk = day && !a.planDayId ? checkRide(day, a) : null
  const rpe = a.rpe ?? day?.rpe ?? null
  const zones = hrZoneRows(a)
  const ok = aiAllowed(a)
  const kpis: [string, string][] = ([
    a.distKm ? [`${num(a.distKm)}${NBSP}km`, 'razdalja'] : null,
    a.durationMin ? [fmtDur(a.durationMin), a.elapsedMin && a.elapsedMin - a.durationMin >= 5 ? `gibanje · s postanki ${fmtDur(a.elapsedMin)}` : 'čas'] : null,
    a.elevM ? [`${int(a.elevM)}${NBSP}m`, 'vzpon'] : null,
    a.avgHr ? [`${Math.round(a.avgHr)}${a.maxHr ? ` / ${Math.round(a.maxHr)}` : ''}`, a.maxHr ? 'utrip povp. / max' : 'povprečni utrip'] : null,
    a.avgPower ? [`${Math.round(a.avgPower)}${NBSP}W`, a.deviceWatts === false ? 'moč (ocena)' : 'povprečna moč'] : null,
    a.speedKmh || (a.distKm && a.durationMin) ? [`${num(a.speedKmh || (a.distKm! / (a.durationMin! / 60)))}${NBSP}km/h`, 'hitrost'] : null,
    a.tss ? [String(Math.round(a.tss)), 'TSS'] : null,
    a.kcal ? [`${int(a.kcal)}`, 'kcal'] : null,
  ] as ([string, string] | null)[]).filter((x): x is [string, string] => !!x)
  /**
   * Ime in opomba v enem zapisu iz svežega stanja (v3.48): tudi ob Esc, Nazaj in tapu na ozadje — prej sta se ob
   * Esc in Nazaj izgubila (list se zapre brez blur), »Končano« pa je z drugim zapisom povozil novo ime.
   */
  async function saveEdits() {
    const cur = getState().activities.find(x => x.id === id)
    if (!cur) return
    const t = name.trim().slice(0, 60), n = note.trim().slice(0, 400)
    if (!t) setName(cur.name)
    const nameCh = !!t && t !== cur.name, noteCh = n !== (cur.notes || '')
    if (!nameCh && !noteCh) return
    const { notes: _n, ...rest } = cur
    void _n
    await saveActivity({ ...(n ? { ...cur, notes: n } : (rest as Activity)), ...(nameCh ? { name: t, named: true } : {}) })
  }
  // (v3.51) odprt popravek: Končano, Esc, Nazaj in tap na ozadje ga shranijo (kot ime in opombo); z napako vpraša
  const close = async () => {
    if (ed && editDirty(a, ed)) {
      if (!(await saveFix())) {
        if (!(await confirm({ title: 'Zavržem popravek?', text: 'V popravku je napaka — popravi jo ali popravek zavrzi.', ok: 'Zavrzi', cancel: 'Popravi' }))) return
      }
    }
    void saveEdits(); onClose()
  }
  // (v3.50) popravek številk vadbe (napačno prebran posnetek, moč uvožena kot kolo, napačen datum) — prej samo izbris in nov vnos
  const editable = EDITABLE.has(a.source) && !a.planDayId
  const edFl = ed ? manualFields(ed.sport) : null
  // (v3.51) s športom še hitrost (300 km v 60 min ne gre); kalorije in moč v razponu
  const edErr = ed && edFl ? manualActivityErrors({ min: ed.min, hr: ed.hr, kcal: ed.kcal ?? '', ...(edFl.dist ? { dist: ed.dist } : {}), ...(edFl.elev ? { elev: ed.elev } : {}), ...(edFl.power ? { power: ed.power ?? '' } : {}) }, ed.sport) : {}
  async function saveFix(): Promise<boolean> {
    const cur = getState().activities.find(x => x.id === id)
    if (!cur || !ed) return true
    if (Object.keys(edErr).length) { document.getElementById(`ae-${Object.keys(edErr)[0]}`)?.focus(); return false }
    const next = applyEdit(cur, ed, getState().profile)
    if (!next.durationMin && !next.distKm) { setEdNeed(true); document.getElementById('ae-min')?.focus(); return false }
    await saveActivity(next)
    // drug dan ali šport: povezava z dnevom načrta ne velja več (dan ni več »opravljen« s to vadbo)
    const moved = next.date !== cur.date || next.sport !== cur.sport
    if (day && day.done?.activityId === cur.id && moved) await setPlanDone(day.id, false)
    // (v3.51) in nov dan v načrtu, ki ji ustreza, se odkljuka (prej sta ostala neopravljena oba)
    if (moved) {
      const s = getState(), nd = pickDoneDay(next, s.plan, s.today)
      if (nd) { await setPlanDone(nd.id, true, next.id); toast(`Popravljeno — v načrtu odkljukano: »${nd.title}«, ${dayName(nd.date)}.`, 'ok', 6000) }
    }
    setEd(null); setEdNeed(false)
    return true
  }
  const h = { fontSize: rem(10.5), fontWeight: 800, letterSpacing: '.08em', color: 'var(--ink-3)', textTransform: 'uppercase' as const, marginTop: 16 }
  // (v3.51) popravek, ki ga ni mogoče shraniti (napaka ali brez trajanja in razdalje): Esc, Nazaj in tap ob listu vprašajo
  // v listu (guard) — prej je Nazaj list vzel s sklada in šele nato vprašal; po »Popravi« list ni več reagiral na Esc in Nazaj
  const fixBad = !!ed && editDirty(a, ed) && (Object.keys(edErr).length > 0 || (() => { const n = applyEdit(a, ed, app.profile); return !n.durationMin && !n.distKm })())
  return (<>
    <Sheet open onClose={() => { if (fixBad) { setEd(null); void saveEdits(); onClose() } else void close() }} guard={fixBad ? 'Zavržem popravek? V njem je napaka.' : null} label={`Vadba: ${a.name}`}>
      <div className="row" style={{ gap: 10, alignItems: 'center' }}>
        <span style={{ width: 34, height: 34, borderRadius: 10, display: 'grid', placeItems: 'center', flex: 'none', color: kindColor(a.sport), background: 'rgba(var(--fg-rgb),.06)' }}><KindIcon kind={a.sport} size={18} /></span>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontSize: rem(11), fontWeight: 800, letterSpacing: '.08em', color: kindInk(a.sport) }}>{(SPORT_LABEL[a.sport] || 'Vadba').toUpperCase()} · {dayName(a.date).toUpperCase()} {dmy(a.date, app.today)}</div>
          <b style={{ fontSize: rem(17), letterSpacing: '-.02em', display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.name}</b>
        </div>
      </div>

      {kpis.length > 0 && <div className="kpis act-kpis">{kpis.map(([v, l]) => <div key={l} className="kpi"><b>{v}</b><small>{l}</small></div>)}</div>}

      {ed && (() => {
        const fl = manualFields(ed.sport)
        const msgs = [...Object.values(edErr), ...(edNeed ? [fl.dist ? 'Vpiši trajanje (min) ali razdaljo (km).' : 'Vpiši trajanje (min).'] : [])]
        const fx = (k: 'min' | 'dist' | 'elev' | 'hr' | 'kcal' | 'power') => {
          const bad = !!edErr[k] || (edNeed && (k === 'min' || k === 'dist'))
          return { id: `ae-${k}`, min: ACTIVITY_RANGE[k][0], max: ACTIVITY_RANGE[k][1], value: ed[k] ?? '', 'aria-invalid': bad || undefined, 'aria-describedby': bad ? 'ae-err' : undefined, style: bad ? { borderColor: 'var(--warn)' } : undefined,
            onChange: (e: React.ChangeEvent<HTMLInputElement>) => { setEd({ ...ed, [k]: e.target.value }); setEdNeed(false) } }
        }
        return (
          <div className="stack" style={{ gap: 10, marginTop: 14 }}>
            <p className="muted" style={{ fontSize: rem(12) }}>Popravi, kar je narobe — šport, čas, razdalja ali datum. Kalorije ob drugem trajanju preračunam, če jih ne spremeniš.</p>
            <div className="row" role="group" aria-label="Šport" style={{ gap: 7, flexWrap: 'wrap' }}>{SPORTS.map(s => <Chip key={s} sm on={ed.sport === s} onClick={() => setEd({ ...ed, sport: s })}>{SPORT_LABEL[s]}</Chip>)}</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <div className="field"><label htmlFor="ae-date">Datum</label><DateField id="ae-date" compact value={ed.date} max={todayIso()} onChange={v => setEd({ ...ed, date: v || ed.date })} label="Datum" /></div>
              <div className="field"><label htmlFor="ae-min">Trajanje <span className="unit">min</span></label><input type="number" inputMode="numeric" {...fx('min')} /></div>
              {fl.dist && <div className="field"><label htmlFor="ae-dist">Razdalja <span className="unit">km</span></label><DecimalInput step={0.1} {...fx('dist')} /></div>}
              {fl.elev && <div className="field"><label htmlFor="ae-elev">Vzpon <span className="unit">m</span></label><input type="number" inputMode="numeric" {...fx('elev')} /></div>}
              <div className="field"><label htmlFor="ae-hr">Povp. utrip</label><input type="number" inputMode="numeric" {...fx('hr')} /></div>
              {fl.power && <div className="field"><label htmlFor="ae-power">Povp. moč <span className="unit">W</span></label><input type="number" inputMode="numeric" {...fx('power')} /></div>}
              <div className="field"><label htmlFor="ae-kcal">Kalorije <span className="unit">kcal</span></label><input type="number" inputMode="numeric" {...fx('kcal')} /></div>
            </div>
            {msgs.length > 0 && <div id="ae-err" role="alert" style={{ fontSize: rem(12), color: 'var(--warn)', lineHeight: 1.45 }}>{msgs.join(' ')}</div>}
            <div className="row" style={{ gap: 8 }}><Btn primary sm onClick={() => void saveFix()}>Shrani popravek</Btn><Btn ghost sm onClick={() => { setEd(null); setEdNeed(false) }}>Prekliči</Btn></div>
          </div>)
      })()}

      {day && <>
        <div style={h}>Načrt</div>
        <div style={{ fontSize: rem(13), marginTop: 4, color: 'var(--ink-2)' }}><b style={{ color: 'var(--ink)' }}>{day.title}</b> · {fmtDur(day.durationMin)}</div>
        {chk && <div style={{ fontSize: rem(12.5), fontWeight: 700, marginTop: 3, color: chk.status === 'ok' ? 'var(--ok)' : chk.status === 'delno' ? 'var(--warn)' : 'var(--bad)' }}>{chk.verdict}</div>}
      </>}
      {a.planDayId && <p className="muted" style={{ fontSize: rem(12), marginTop: 8 }}>Zapis iz načrta (brez ure): čas po vodeni vadbi ali načrtu, obremenitev po načrtu. Ko pride vadba z ure, ga zamenja.</p>}

      {zones && <>
        <div className="between" style={{ ...h, display: 'flex' }}><span>Utrip po conah</span><span style={{ letterSpacing: 0, textTransform: 'none', fontWeight: 600 }}>{zones.total}{NBSP}min</span></div>
        <div style={{ display: 'flex', height: 10, borderRadius: 5, overflow: 'hidden', gap: 2, marginTop: 8 }} aria-hidden="true">
          {zones.easy > 0 && <i style={{ flex: zones.easy, background: 'var(--t-kolo)' }} />}{zones.mid > 0 && <i style={{ flex: zones.mid, background: 'var(--warn)' }} />}{zones.hard > 0 && <i style={{ flex: zones.hard, background: 'var(--t-moc)' }} />}
        </div>
        <div className="muted" style={{ fontSize: rem(11.5), marginTop: 5 }}>{zones.easy}{NBSP}% lahko (Z1–Z2) · {zones.mid}{NBSP}% tempo · {zones.hard}{NBSP}% prag in više</div>
        <div className="zone-rows">{zones.rows.map(r => <div key={r.key} className="between"><span><b>{r.key}</b>{r.range ? <span className="muted"> · {r.range}</span> : null}</span><span>{r.min}{NBSP}min</span></div>)}</div>
      </>}

      {a.exercises?.length ? <>
        <div style={h}>Vaje</div>
        {a.exercises.map((e, k) => <div key={k} className="between" style={{ fontSize: rem(13), padding: '3px 0' }}><b style={{ minWidth: 0 }}>{e.name}</b><span className="muted" style={{ flex: 'none' }}>{e.sets} × {e.reps}{e.kg ? ` · ${num(e.kg)}${NBSP}kg` : ''}</span></div>)}
      </> : null}

      <div style={h}>Kako je šlo?</div>
      <RateRow value={rpe} onPick={v => void rateSession({ activityId: a.id }, v)} label="Občutek" />

      <div className="field" style={{ marginTop: 16 }}>
        <label htmlFor="act-note">Opomba</label>
        <textarea id="act-note" rows={2} value={note} maxLength={400} placeholder={NOTE_HINT[a.sport] || NOTE_HINT.drugo} onChange={e => setNote(e.target.value)} onBlur={() => void saveEdits()} style={{ resize: 'none', minHeight: 64 }} />
      </div>
      <div className="field" style={{ marginTop: 12 }}>
        <label htmlFor="act-name">Ime</label>
        <input id="act-name" value={name} maxLength={60} onChange={e => setName(e.target.value)} onBlur={() => void saveEdits()} onKeyDown={e => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur() }} />
      </div>

      <div className="row" style={{ gap: 6, marginTop: 14, flexWrap: 'wrap' }}>
        <Chip sm ok={ok}>{sourceLabel(a)} · {ok ? 'trener vidi' : 'trener ne vidi'}</Chip>
        {a.trainer && <Chip sm>trenažer</Chip>}
      </div>
      <div className="row" style={{ gap: 8, marginTop: 14, flexWrap: 'wrap' }}>
        {a.polyline && <Btn ghost sm onClick={() => setMap(true)}><IcoMap width={15} height={15} /> Zemljevid</Btn>}
        {editable && !ed && <Btn ghost sm onClick={() => setEd(editFormOf(a))}>Uredi</Btn>}
        <Btn ghost sm onClick={() => { onClose(); onDelete(a) }}>Izbriši</Btn>
        <div className="grow" />
        <Btn sm onClick={() => void close()}>Končano</Btn>
      </div>
      {a.polyline && <RouteMap open={map} onClose={() => setMap(false)} poly={a.polyline} climb={null} title={a.name} />}
    </Sheet>
    {confirmSheet}
  </>)
}
