import type { Activity, PlanDay, Sport } from '@/domain/types'
import { fmtDur } from '@/domain/training/load'
import { kindColor } from '@/ui/primitives'
import { num, unit, NBSP } from '@/ui/format'
import { IcoCheck } from '@/ui/icons'

/** Vrsta športa za prikaz (aktivnost, ne načrt). */
export const SPORT_LABEL: Record<Sport, string> = { kolo: 'Kolo', tek: 'Tek', pohod: 'Hribi', moc: 'Moč', plavanje: 'Plavanje', drugo: 'Drugo' }
export const sportColor = (s: Sport): string => (s === 'plavanje' ? 'var(--t-tek)' : kindColor(s))

/** Kaj je bilo: trajanje · km · vzpon · utrip · TSS — samo, kar aktivnost ima. */
export function activityStats(a: Activity, max = 6): string {
  const m = a.durationMin && a.durationMin > 0 ? fmtDur(Math.round(a.durationMin)) : null
  const parts = [
    m,
    a.distKm && a.distKm > 0 ? unit(num(a.distKm), 'km') : null,
    a.elevM && a.elevM >= 20 ? unit(num(a.elevM, 0), 'm') : null,
    a.avgHr && a.avgHr > 0 ? `utrip${NBSP}${Math.round(a.avgHr)}` : null,
    a.tss && a.tss > 0 ? `${Math.round(a.tss)}${NBSP}TSS` : null,
    a.exercises?.length ? `${a.exercises.length}${NBSP}${a.exercises.length === 1 ? 'vaja' : a.exercises.length === 2 ? 'vaji' : a.exercises.length <= 4 ? 'vaje' : 'vaj'}` : null,
  ].filter(Boolean).slice(0, max)
  return parts.join(' · ')
}

/** Aktivnosti dneva, ki niso povezane z nobenim dnem načrta (dodatna vožnja, tek, hribi, moč …). */
export function extraActivities(acts: readonly Activity[], plan: readonly PlanDay[], date: string): Activity[] {
  const linked = new Set(plan.map(d => d.done?.activityId).filter(Boolean))
  return acts.filter(a => a.date === date && !linked.has(a.id)).sort((x, y) => (x.start || '').localeCompare(y.start || ''))
}

/**
 * Okvirček za opravljeno vadbo v Planu: barva športa, oznaka DODATNO (ni bila v načrtu), ime in številke.
 * `compact` = ena vrstica (pretekli dnevi); `onLink` = »poveži s treningom«, ko je ta dan še neopravljena seja iste vrste.
 */
export function ActivityBox({ a, compact = false, dayLabel, onLink, linkTitle }: { a: Activity; compact?: boolean; dayLabel?: string; onLink?: () => void; linkTitle?: string }) {
  const c = sportColor(a.sport)
  const stats = activityStats(a, compact ? 2 : 6)
  if (compact) return (
    <div className="card tight sess row" style={{ gap: 10, padding: '9px 12px', opacity: 0.85 }}>
      <span className="bar" style={{ background: c }} />
      {dayLabel && <span style={{ fontSize: 11, fontWeight: 800, letterSpacing: '.06em', color: c, width: 58, flex: 'none' }}>{dayLabel}</span>}
      <b className="clamp2" style={{ fontSize: 13, flex: 1, minWidth: 0 }}>{a.name}<span className="muted" style={{ fontWeight: 600 }}>{stats ? ` · ${stats}` : ''}</span></b>
      <IcoCheck width={14} height={14} aria-label="opravljeno" style={{ color: 'var(--accent)', flex: 'none' }} />
    </div>
  )
  return (
    <div className="card tight sess" style={{ marginTop: 0 }}>
      <div className="bar" style={{ background: c }} />
      <div style={{ paddingLeft: 6 }}>
        <div className="between">
          <span style={{ fontSize: 11, fontWeight: 800, letterSpacing: '.08em', color: c }}>{dayLabel ? `${dayLabel} · ` : ''}{SPORT_LABEL[a.sport].toUpperCase()} · OPRAVLJENO</span>
          <span className="muted" style={{ fontSize: 11, fontWeight: 700, flex: 'none' }}>ni bilo v načrtu</span>
        </div>
        <b style={{ display: 'block', fontSize: 15, marginTop: 2 }}>{a.name}</b>
        {stats && <span className="muted" style={{ display: 'block', fontSize: 12 }}>{stats}</span>}
        {onLink && <button type="button" className="chip sm click" style={{ marginTop: 8 }} onClick={onLink}>{linkTitle || 'to je bil trening iz načrta'}</button>}
      </div>
    </div>
  )
}
