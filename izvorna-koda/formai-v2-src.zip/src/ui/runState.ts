/**
 * TEKOČA VADBA ZUNAJ VADBE (v3.48): Danes in gumb spodaj vesta, da vadba teče (prej »Začni trening«, tap je nadaljeval
 * pri 13:03). Bere isti zapis kot vodena vadba (sessionStorage, Vadba.RUN_KEY) — brez uvoza Vadbe, da ostane v svojem
 * kosu (lazy). Ujemanje ključa preverja test.
 */
export const RUN_KEY_SHARED = 'formai.vadba.v1'

/** id dneva nedokončane vadbe v tem zavihku ali null */
export function runningDayId(): string | null {
  try {
    const r = JSON.parse(sessionStorage.getItem(RUN_KEY_SHARED) || 'null') as { v?: number; dayId?: string; finished?: boolean } | null
    return r && r.v === 1 && !r.finished && typeof r.dayId === 'string' ? r.dayId : null
  } catch { return null }
}
