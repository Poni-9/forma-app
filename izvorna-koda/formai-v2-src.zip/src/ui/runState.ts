/**
 * TEKOČA VADBA ZUNAJ VADBE (v3.48): Danes in gumb spodaj vesta, da vadba teče (prej »Začni trening«, tap je nadaljeval
 * pri 13:03). Bere isti zapis kot vodena vadba (sessionStorage, Vadba.RUN_KEY) — brez uvoza Vadbe, da ostane v svojem
 * kosu (lazy). Ujemanje ključa preverja test.
 *
 * (v3.49) Ko gre aplikacija v ozadje, gre kopija nedokončane vadbe v localStorage (s časom kopije). iOS in Android
 * aplikacijo v ozadju pogosto zapreta — sessionStorage takrat izgine, kopija pa ostane in Vadba ponudi nadaljevanje
 * (največ 12 h). Prej je bil ves napredek (korak, čas, vpisani kg) izgubljen.
 */
import type { PlanDay } from '@/domain/types'

export const RUN_KEY_SHARED = 'formai.vadba.v1'
/** kopija prekinjene vadbe (localStorage) */
export const RUN_SAVED_KEY = 'formai.vadba.shranjena'
/** starejše kopije ne ponudimo več (12 h) */
export const RUN_SAVED_MAX_MS = 12 * 3600_000

interface RunLike { v?: number; dayId?: string; finished?: boolean; savedAt?: number }

/** id dneva nedokončane vadbe v tem zavihku — ali prekinjene (zaprta aplikacija), ki jo lahko nadaljuješ — ali null */
export function runningDayId(now = Date.now()): string | null {
  try {
    const r = JSON.parse(sessionStorage.getItem(RUN_KEY_SHARED) || 'null') as RunLike | null
    if (r) return r.v === 1 && !r.finished && typeof r.dayId === 'string' ? r.dayId : null
  } catch { return null }
  return savedRun(now)?.dayId ?? null
}

/** Kopija prekinjene vadbe, če ni končana in ni starejša od 12 h; staro ali pokvarjeno pobriše. */
export function savedRun<T extends object = RunLike>(now = Date.now()): (T & { dayId: string; savedAt: number }) | null {
  try {
    const r = JSON.parse(localStorage.getItem(RUN_SAVED_KEY) || 'null') as (T & RunLike) | null
    if (!r) return null
    const ok = r.v === 1 && !r.finished && typeof r.dayId === 'string' && typeof r.savedAt === 'number' && now - r.savedAt <= RUN_SAVED_MAX_MS && r.savedAt <= now + 60_000
    if (!ok) { localStorage.removeItem(RUN_SAVED_KEY); return null }
    return r as T & { dayId: string; savedAt: number }
  } catch { return null }
}

/** Shrani kopijo (s časom) ali jo pobriše (null, končana vadba). */
export function saveRunCopy(r: RunLike | null, now = Date.now()): void {
  try {
    if (r && r.v === 1 && !r.finished) localStorage.setItem(RUN_SAVED_KEY, JSON.stringify({ ...r, savedAt: now }))
    else localStorage.removeItem(RUN_SAVED_KEY)
  } catch { /* brez shrambe */ }
}

/** Kopija tekoče vadbe iz sessionStorage, ko gre stran v ozadje ali se zapira (na katerem koli zaslonu). Vrne odjavo. */
export function watchRunCopy(): () => void {
  const copy = () => {
    try {
      const r = JSON.parse(sessionStorage.getItem(RUN_KEY_SHARED) || 'null') as RunLike | null
      if (r && r.v === 1 && !r.finished) saveRunCopy(r)
    } catch { /* brez shrambe */ }
  }
  const onVis = () => { if (document.visibilityState === 'hidden') copy() }
  document.addEventListener('visibilitychange', onVis)
  window.addEventListener('pagehide', copy)
  return () => { document.removeEventListener('visibilitychange', onVis); window.removeEventListener('pagehide', copy) }
}

/**
 * Dan za gumb spodaj na Danes: glavni neopravljen trening danes (kardio pred močjo). (v3.49) Brez njega tudi olajšan
 * dan po želji (»Lahek dan — Z1«, kolo ali tek) — vodena lahka vožnja s časovnikom in pitjem (prej ga ni bilo).
 * (v3.50) Hribi (»Hribi namesto kolesa«) dobijo gumb, ko ni druge seje — vodena vadba za hojo obstaja.
 */
export function pillDay<T extends Pick<PlanDay, 'date' | 'kind' | 'done' | 'optional'>>(plan: readonly T[], today: string): T | undefined {
  const todays = plan.filter(d => d.date === today && d.kind !== 'pocitek' && !d.done)
  return todays.filter(d => d.kind !== 'pohod' && !d.optional).sort((a, b) => (a.kind === 'moc' ? 1 : 0) - (b.kind === 'moc' ? 1 : 0))[0]
    ?? todays.find(d => d.kind === 'pohod' && !d.optional)
    ?? todays.find(d => d.optional && (d.kind === 'kolo' || d.kind === 'tek'))
}

/**
 * (v3.50) Napis gumba spodaj: »Začni trening«; ko je danes še druga seja (kolo in moč), pove, katero začne (»Začni kolo«),
 * na kartici moči je »Začni moč« — prej dva »Začni« na enem zaslonu. Hribi: »Začni hojo«.
 */
export function pillLabel(d: Pick<PlanDay, 'kind' | 'optional'>, o: { running?: boolean; others?: boolean } = {}): string {
  if (o.running) return 'Nadaljuj trening'
  const w = d.kind === 'pohod' ? 'hojo' : o.others ? (d.kind === 'kolo' ? 'kolo' : d.kind === 'tek' ? 'tek' : d.kind === 'moc' ? 'moč' : d.kind === 'test' ? 'test' : 'trening') : 'trening'
  return d.optional ? `Začni ${w === 'trening' ? '' : w + ' '}(po želji)` : `Začni ${w}`
}
