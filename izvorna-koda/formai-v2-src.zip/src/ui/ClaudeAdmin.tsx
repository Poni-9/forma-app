import { useEffect, useState } from 'react'
import { claudeAccess, newClaudeInvite, claudeInvitees, type ClaudeAccess } from '@/domain/ai/client'
import { toast } from '@/state/store'
import { Btn } from '@/ui/primitives'
import { rem } from '@/ui/rem'

/**
 * Claude trener v Nastavitvah: kdo ga ima (skrbnik ali povabilo) in — samo skrbnik — povezave za povabilo
 * (enkratne, za en račun) in seznam povabljenih. Ostali tega razdelka ne vidijo.
 */
export function ClaudeAdmin() {
  const [a, setA] = useState<ClaudeAccess | null>(null)
  const [link, setLink] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [who, setWho] = useState<{ email: string | null; t: number | null }[] | null>(null)
  useEffect(() => { let dead = false; void claudeAccess(true).then(v => { if (!dead) setA(v) }); return () => { dead = true } }, [])
  useEffect(() => { if (a?.skrbnik) void claudeInvitees().then(setWho) }, [a?.skrbnik])
  if (!a || (!a.ok && !a.skrbnik)) return null

  async function make() {
    setBusy(true)
    try { const k = await newClaudeInvite(); setLink(`${location.origin}/#/claude?k=${k}`) }
    catch (e) { toast((e as Error).message, 'err', 6000) }
    finally { setBusy(false) }
  }
  async function copy() {
    if (!link) return
    try { await navigator.clipboard.writeText(link); toast('Povezava kopirana.', 'ok') } catch { toast('Kopiranje ni uspelo — označi povezavo in jo kopiraj.', 'err') }
  }
  async function share() {
    if (!link) return
    try { await navigator.share({ title: 'FORMAI — Claude trener', text: 'Povabilo v FORMAI: tvoj načrt bo sestavil Claude.', url: link }) } catch { /* preklicano */ }
  }
  const canShare = typeof navigator !== 'undefined' && typeof navigator.share === 'function'
  return (
    <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid var(--line)' }}>
      <div className="between"><span style={{ fontSize: rem(13), fontWeight: 700 }}>Claude trener</span><span className="chip sm on">{a.ok ? 'vklopljen' : a.kljuc ? 'ni vklopljen' : 'strežnik brez ključa'}</span></div>
      <p className="muted" style={{ fontSize: rem(12), marginTop: 4 }}>{a.ok ? 'Tvoj načrt sestavlja Claude (Anthropic); ostali uporabniki imajo Gemini.' : 'Ključ Anthropic na strežniku še ni nastavljen — do takrat sestavlja Gemini.'}</p>
      {a.skrbnik && (<>
        <Btn sm style={{ marginTop: 10 }} disabled={busy} onClick={() => void make()}>{busy ? 'Ustvarjam …' : 'Nova povezava za povabilo'}</Btn>
        {link && (<>
          <input readOnly value={link} aria-label="Povezava za povabilo" onFocus={e => e.currentTarget.select()} style={{ width: '100%', marginTop: 8, fontSize: rem(12) }} />
          <div className="row" style={{ gap: 8, marginTop: 8 }}>
            <Btn sm primary onClick={() => void copy()}>Kopiraj</Btn>
            {canShare && <Btn sm ghost onClick={() => void share()}>Deli …</Btn>}
          </div>
          <p className="muted" style={{ fontSize: rem(11.5), marginTop: 6 }}>Povezava velja za en račun: kdor jo prvi odpre in se prijavi, dobi Claude trenerja.</p>
        </>)}
        {who && who.length > 0 && <p className="muted" style={{ fontSize: rem(11.5), marginTop: 8 }}>S povabilom: {who.map(w => w.email || 'račun brez e-pošte').join(', ')}</p>}
      </>)}
    </div>
  )
}
