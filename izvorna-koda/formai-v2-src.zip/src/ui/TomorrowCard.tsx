import { navigate } from '@/app/router'
import type { PlanDay } from '@/domain/types'
import { fmtDur, addDays } from '@/domain/training/load'
import { wxShort, wxBad, type DayWx } from '@/domain/weather'
import { kindLabel } from '@/ui/primitives'
import { dayName } from '@/ui/format'
import { effortOf } from '@/domain/training/effort'
import { isRace, sessColor, SessIcon } from '@/ui/SessBits'

/**
 * Jutri v eni vrstici pod današnjim treningom: kaj te čaka, koliko časa, vreme. Zvečer (od 17. ure) ali ko je današnje
 * opravljeno, je to glavna informacija dneva — kartica dobi barvo vrste treninga. Tap odpre dan v Planu.
 * Tekma: pokal, barva poudarka in »tekma« v oznaki; brez TSS, kot glavna kartica — intenzivnost z besedo (v3.48).
 */
export function TomorrowCard({ plan, today, weather, hour = new Date().getHours(), todayDone = false }: { plan: readonly PlanDay[]; today: string; weather?: Record<string, DayWx> | null; hour?: number; todayDone?: boolean }) {
  const date = addDays(today, 1)
  const days = plan.filter(d => d.date === date)
  if (!days.length) return null
  const prio = (d: PlanDay) => (d.kind === 'pocitek' ? 9 : d.optional ? 5 : d.kind === 'moc' ? 2 : 0)
  const [main, ...rest] = [...days].sort((a, b) => prio(a) - prio(b))
  if (!main) return null
  const rest2 = rest.filter(d => d.kind !== 'pocitek' && !d.optional)
  const wx = weather?.[date]
  const outdoor = main.kind === 'kolo' || main.kind === 'tek' || main.kind === 'pohod'
  const evening = hour >= 17 || todayDone
  const race = isRace(main)
  const c = main.kind === 'pocitek' || main.optional ? 'var(--t-poc)' : sessColor(main)
  const eff = race || main.optional ? null : effortOf(main)
  // (v3.51) dan premora »Ta teden …«: »Premor · brez kolesa« kot v Planu (prej »Počitek«)
  const pause = main.kind === 'pocitek' && /^Premor\b/.test(main.title)
  const meta = pause ? 'po tvoji izbiri' : main.kind === 'pocitek' ? 'dan brez treninga' : [main.durationMin > 0 ? fmtDur(main.durationMin) : null, eff ? eff.w : null, ...rest2.map(d => `+ ${kindLabel(d.kind).toLowerCase()} ${fmtDur(d.durationMin)}`)].filter(Boolean).join(' · ')
  return (
    <button type="button" className={`card tight tomorrow ${evening ? 'evening' : ''}${race ? ' race' : ''}`} style={{ ['--c' as string]: c }} onClick={() => navigate('plan', { dan: date })} aria-label={`Jutri, ${dayName(date)}: ${pause ? main.title.toLowerCase() : main.kind === 'pocitek' ? 'počitek' : `${race ? 'tekma, ' : ''}${main.title}`} — odpri v Planu`}>
      <span className="ki" aria-hidden="true"><SessIcon d={main} size={16} /></span>
      <span className="tx">
        <span className="lbl">Jutri · {dayName(date)}{race ? ' · tekma' : main.optional ? ' · po želji' : ''}</span>
        <b>{main.kind === 'pocitek' && !pause ? 'Počitek' : main.title}</b>
        <span className="muted">{meta}{outdoor && wx ? <span style={{ color: wxBad(wx) ? 'var(--warn)' : undefined }}> · {wxShort(wx)}</span> : null}</span>
      </span>
      <span className="chev" aria-hidden="true">›</span>
    </button>
  )
}
