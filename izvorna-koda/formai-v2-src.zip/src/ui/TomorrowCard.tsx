import { navigate } from '@/app/router'
import type { PlanDay } from '@/domain/types'
import { fmtDur, addDays } from '@/domain/training/load'
import { wxShort, wxBad, type DayWx } from '@/domain/weather'
import { KindIcon, kindColor, kindLabel } from '@/ui/primitives'
import { dayName, NBSP } from '@/ui/format'

/**
 * Jutri v eni vrstici pod današnjim treningom: kaj te čaka, koliko časa, vreme. Zvečer (od 17. ure) ali ko je današnje
 * opravljeno, je to glavna informacija dneva — kartica dobi barvo vrste treninga. Tap odpre dan v Planu.
 */
export function TomorrowCard({ plan, today, weather, hour = new Date().getHours(), todayDone = false }: { plan: readonly PlanDay[]; today: string; weather?: Record<string, DayWx> | null; hour?: number; todayDone?: boolean }) {
  const date = addDays(today, 1)
  const days = plan.filter(d => d.date === date)
  if (!days.length) return null
  const prio = (d: PlanDay) => (d.kind === 'pocitek' ? 9 : d.optional ? 5 : d.kind === 'moc' ? 2 : 0)
  const [main, ...rest] = [...days].sort((a, b) => prio(a) - prio(b))
  if (!main) return null
  const rest2 = rest.filter(d => d.kind !== 'pocitek' && !d.optional)
  const wx = weather?.[date]
  const outdoor = main.kind === 'kolo' || main.kind === 'tek' || main.kind === 'pohod'
  const evening = hour >= 17 || todayDone
  const c = main.kind === 'pocitek' || main.optional ? 'var(--t-poc)' : kindColor(main.kind)
  const meta = main.kind === 'pocitek' ? 'dan brez treninga' : [main.durationMin > 0 ? fmtDur(main.durationMin) : null, main.tssTarget && !main.optional ? `${main.tssTarget}${NBSP}TSS` : null, ...rest2.map(d => `+ ${kindLabel(d.kind).toLowerCase()} ${fmtDur(d.durationMin)}`)].filter(Boolean).join(' · ')
  return (
    <button type="button" className={`card tight tomorrow ${evening ? 'evening' : ''}`} style={{ ['--c' as string]: c }} onClick={() => navigate('plan', { dan: date })} aria-label={`Jutri, ${dayName(date)}: ${main.kind === 'pocitek' ? 'počitek' : main.title} — odpri v Planu`}>
      <span className="ki" aria-hidden="true"><KindIcon kind={main.kind} size={16} /></span>
      <span className="tx">
        <span className="lbl">Jutri · {dayName(date)}{main.optional ? ' · po želji' : ''}</span>
        <b>{main.kind === 'pocitek' ? 'Počitek' : main.title}</b>
        <span className="muted">{meta}{outdoor && wx ? <span style={{ color: wxBad(wx) ? 'var(--warn)' : undefined }}> · {wxShort(wx)}</span> : null}</span>
      </span>
      <span className="chev" aria-hidden="true">›</span>
    </button>
  )
}
