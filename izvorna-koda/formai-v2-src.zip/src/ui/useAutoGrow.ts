import { useLayoutEffect, type RefObject } from 'react'

/**
 * Višina polja sledi besedilu (Blaž, 13. 10.: »ne vidim, kaj sem napisal«): od ene vrstice do `max` px, šele nato drsnik.
 * Pri border-box mora višina vključiti obrobo, sicer manjkata 2 px in se pokaže drsnik.
 */
export function useAutoGrow(ref: RefObject<HTMLTextAreaElement | null>, value: string, max = 200) {
  useLayoutEffect(() => {
    const el = ref.current
    if (!el) return
    // CSS ima za polja obrok max-height 132 px — tu velja `max`
    el.style.maxHeight = `${max}px`
    el.style.height = 'auto'
    const full = el.scrollHeight + (el.offsetHeight - el.clientHeight)
    el.style.height = `${Math.min(full, max)}px`
    el.style.overflowY = full > max ? 'auto' : 'hidden'
    // med narekovanjem naj bo vidno zadnje, kar je slišal
    if (full > max) el.scrollTop = el.scrollHeight
  }, [ref, value, max])
}
