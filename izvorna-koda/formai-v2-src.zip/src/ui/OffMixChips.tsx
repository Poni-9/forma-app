import { useState } from 'react'
import { useApp, setOffMix, toast } from '@/state/store'
import { OFF_MIX, OFF_MIX_KEYS, offMixOf, type OffMix } from '@/domain/training/offMix'
import { Chip } from '@/ui/primitives'

/**
 * Kaj v off-seasonu — odloči uporabnik (prej je aplikacija sama dala hribe). Privzeto kolo po občutku (označeno);
 * izbira takoj sestavi ta in naslednji teden.
 */
export function OffMixChips() {
  const app = useApp()
  const [busy, setBusy] = useState(false)
  const cur = app.profile.offMix ?? null
  const shown = offMixOf(app.profile)
  async function pick(m: OffMix) {
    if (busy || cur === m) return
    setBusy(true); await setOffMix(m); setBusy(false)
    toast(`${OFF_MIX[m].toast} Ta in naslednji teden sta sestavljena znova.`, 'ok', 5000)
  }
  return (
    <div style={{ marginTop: 10 }}>
      <div className="muted" style={{ fontSize: 11.5, fontWeight: 700 }}>Kaj v off-seasonu — izbereš sam</div>
      <div className="row" role="group" aria-label="Kaj v off-seasonu" style={{ gap: 6, marginTop: 6, flexWrap: 'wrap' }}>
        {OFF_MIX_KEYS.map(m => <Chip key={m} sm on={shown === m} onClick={() => void pick(m)}>{OFF_MIX[m].label}</Chip>)}
      </div>
    </div>
  )
}
