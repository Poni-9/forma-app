import { useEffect, useState } from 'react'
import { useApp, saveCheckin, toast } from '@/state/store'
import { todayIso } from '@/domain/training/load'
import { Btn, Sheet, DecimalInput } from '@/ui/primitives'
import { DateField } from '@/ui/DateField'

/** Tehtanje (Danes in Napredek) — ločeno od zaslona Napredek, da se ta naloži šele ob odprtju. */
export function WeighSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const app = useApp()
  const c = app.checkinToday
  const last = [...app.checkins].reverse().find(x => x.weightKg)
  const [kg, setKg] = useState('')
  const [waist, setWaist] = useState('')
  const [date, setDate] = useState(todayIso())
  const init = () => { setKg(String(c?.weightKg ?? last?.weightKg ?? app.profile.weightKg ?? '')); setWaist(c?.waistCm ? String(c.waistCm) : ''); setDate(todayIso()) }
  async function save() {
    const v = +String(kg).replace(',', '.')
    if (!(v > 30 && v < 250)) { toast('Vpiši realno težo.', 'err'); return }
    const prev = app.checkins.find(x => x.date === date)
    await saveCheckin({ ...(prev || { date }), date, weightKg: +v.toFixed(1), waistCm: waist ? +String(waist).replace(',', '.') : prev?.waistCm ?? null })
    toast('Teža zabeležena.', 'ok'); onClose()
  }
  useEffect(() => { if (open) init() }, [open])   // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <Sheet open={open} onClose={onClose}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Tehtanje</b>
      <p style={{ fontSize: 12.5, marginTop: 6 }}>Zjutraj, po stranišču, pred zajtrkom — vedno enako. Šteje 7-dnevno povprečje.</p>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 12 }}>
        <div className="field"><label>Teža <span className="unit">kg</span></label><DecimalInput step={0.1} value={kg} onChange={e => setKg(e.target.value)} autoFocus /></div>
        <div className="field"><label>Datum</label><DateField compact value={date} max={todayIso()} onChange={v => setDate(v || todayIso())} label="Datum" /></div>
        <div className="field" style={{ gridColumn: '1 / -1' }}><label>Obseg pasu <span className="unit">cm, neobvezno</span></label><DecimalInput step={0.5} value={waist} onChange={e => setWaist(e.target.value)} placeholder="na popku, sproščeno" /></div>
      </div>
      <Btn primary block style={{ marginTop: 14 }} onClick={save}>Shrani</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Prekliči</Btn>
    </Sheet>
  )
}

