import { useEffect, useRef, useState } from 'react'
import { useApp, saveCheckin, toast, removeWeigh } from '@/state/store'
import { todayIso } from '@/domain/training/load'
import { weighJump } from '@/domain/weigh'
import { Btn, Sheet, DecimalInput } from '@/ui/primitives'
import { DateField } from '@/ui/DateField'
import { dm, NBSP } from '@/ui/format'
import { rem } from '@/ui/rem'

/** Tehtanje (Danes in Napredek) — ločeno od zaslona Napredek, da se ta naloži šele ob odprtju. */
export function WeighSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const app = useApp()
  const c = app.checkinToday
  const last = [...app.checkins].reverse().find(x => x.weightKg)
  const [kg, setKg] = useState('')
  const [waist, setWaist] = useState('')
  const [date, setDate] = useState(todayIso())
  // (v3.49) potrditev pri skoku nad 3 kg (97 namesto 79): besedilo vprašanja, dokler ga ne potrdiš ali popraviš
  const [ask, setAsk] = useState<string | null>(null)
  // (v3.50) polje je predizpolnjeno samo z današnjim tehtanjem (urejanje); sicer prazno z zadnjo težo kot namigom —
  // prej je »Shrani« brez tipkanja zapisal staro (tudi 14 dni staro) težo kot današnjo
  const init = () => { setKg(c?.weightKg != null ? String(c.weightKg) : ''); setWaist(c?.waistCm ? String(c.waistCm) : ''); setDate(todayIso()); filled.current = null }
  const hint = last?.weightKg ?? app.profile.weightKg ?? null
  const had = app.checkins.find(x => x.date === date && x.weightKg)
  // (v3.51) izbran pretekli dan s tehtanjem: polje dobi takratno težo (prej prazno in »Shrani« jo je tiho prepisal)
  const filled = useRef<{ kg: string; waist: string } | null>(null)
  const pickDate = (v: string) => {
    setDate(v); setAsk(null)
    const r = app.checkins.find(x => x.date === v && x.weightKg)
    if (r) { const f = { kg: String(r.weightKg), waist: r.waistCm ? String(r.waistCm) : '' }; filled.current = f; setKg(f.kg); setWaist(f.waist) }
    else if (filled.current && kg === filled.current.kg) { filled.current = null; setKg(''); setWaist('') }
  }
  async function save() {
    const v = +String(kg).replace(',', '.')
    if (!(v > 30 && v < 250)) { toast('Vpiši realno težo.', 'err'); return }
    const jump = weighJump(+v.toFixed(1), date, app.checkins, app.profile.weightKg)
    if (jump && ask !== jump) { setAsk(jump); return }
    // (v3.51) obseg pasu 40–200 cm (prej se je shranil tudi »5«)
    const w = String(waist).trim() ? +String(waist).replace(',', '.') : null
    if (w != null && !(w >= 40 && w <= 200)) { toast('Obseg pasu vpiši v cm (40–200).', 'err'); return }
    const prev = app.checkins.find(x => x.date === date)
    // (v3.51) pri tehtanju tega dne (polje je imelo njegov pas) prazno polje pas izbriše — prej je ostal stari
    try { await saveCheckin({ ...(prev || { date }), date, weightKg: +v.toFixed(1), waistCm: w ?? (prev?.weightKg != null ? null : prev?.waistCm ?? null) }) } catch { return }   // ni shranjeno: obvestilo je že pokazal store
    setAsk(null); toast('Teža zabeležena.', 'ok'); onClose()
  }
  // (v3.49) napačno tehtanje tega dne: izbris z »Razveljavi« (povprečje, cilj in kalorije se takoj popravijo)
  function remove() {
    if (!had?.weightKg) return
    void removeWeigh(had.date)
    onClose()
  }
  useEffect(() => { if (open) init() }, [open])   // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (open) setAsk(null) }, [open])
  return (
    <Sheet open={open} onClose={onClose}>
      <b style={{ fontSize: rem(17), letterSpacing: '-.02em' }}>Tehtanje</b>
      <p style={{ fontSize: rem(12.5), marginTop: 6 }}>Zjutraj, po stranišču, pred zajtrkom — vedno enako. Šteje 7-dnevno povprečje.</p>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 12 }}>
        <div className="field"><label htmlFor="weigh-kg">Teža <span className="unit">kg</span></label><DecimalInput id="weigh-kg" step={0.1} value={kg} onChange={e => { setKg(e.target.value); setAsk(null) }} placeholder={hint != null ? String(hint).replace('.', ',') : undefined} autoFocus />
          {had?.weightKg != null && date !== todayIso() ? <div className="muted" style={{ fontSize: rem(11.5), marginTop: 4 }}>Ta dan je že {String(had.weightKg).replace('.', ',')}{NBSP}kg — Shrani ga popravi.</div>
            : last?.weightKg != null && last.date !== date && <div className="muted" style={{ fontSize: rem(11.5), marginTop: 4 }}>Zadnjič {String(last.weightKg).replace('.', ',')}{NBSP}kg · {dm(last.date)}</div>}</div>
        <div className="field"><label>Datum</label><DateField compact value={date} max={todayIso()} onChange={v => pickDate(v || todayIso())} label="Datum" /></div>
        <div className="field" style={{ gridColumn: '1 / -1' }}><label htmlFor="weigh-waist">Obseg pasu <span className="unit">cm, neobvezno</span></label><DecimalInput id="weigh-waist" step={0.5} value={waist} onChange={e => setWaist(e.target.value)} placeholder="na popku, sproščeno" /></div>
      </div>
      {ask && <div role="alert" style={{ fontSize: rem(13), color: 'var(--ink)', fontWeight: 600, marginTop: 12 }}>{ask}</div>}
      <Btn primary block style={{ marginTop: 14 }} onClick={save}>{ask ? 'Da, prav je' : 'Shrani'}</Btn>
      {ask
        ? <Btn ghost block style={{ marginTop: 9 }} onClick={() => { setAsk(null); document.getElementById('weigh-kg')?.focus() }}>Popravi</Btn>
        : <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Prekliči</Btn>}
      {!ask && had?.weightKg != null && <Btn ghost sm style={{ marginTop: 9, alignSelf: 'center', display: 'block', marginInline: 'auto' }} onClick={remove}>Izbriši tehtanje {dm(had.date)}</Btn>}
    </Sheet>
  )
}
