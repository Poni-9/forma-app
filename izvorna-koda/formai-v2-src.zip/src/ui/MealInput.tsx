import { useEffect, useRef, useState } from 'react'
import { useDictation } from '@/ui/useDictation'
import { Btn } from '@/ui/primitives'
import { IcoCamera, IcoImage, IcoMic, IcoSpark } from '@/ui/icons'

/* Prepoznava govora brskalnika (Chrome/Android, Safari): tipi niso v standardni knjižnici. */
type Props = {
  /** opis obroka → AI oceni kalorije po sestavinah */
  onText: (text: string) => void
  /** slika obroka */
  onPhoto: (file: File) => void
  busy?: 'text' | 'photo' | null
  /** začetni opis (npr. »Popravi opis«) */
  initial?: string
  /** fokus v polje ob odprtju (z Danes: »Opiši obrok«) */
  autoFocus?: boolean
  onError?: (msg: string) => void
  /** vpis za drug dan (npr. »petek, 2. 10.«) — naslov pove, kam gre obrok */
  forDay?: string | null
}

/**
 * Dodaj obrok: napiši ali nareči, kaj si pojedel (AI oceni po sestavinah), ali ga slikaj. Ena kartica za oba načina;
 * slika se prilepi (Ctrl+V) ali povleče tudi sem. Narekovanje uporablja prepoznavo govora brskalnika (sl-SI) —
 * kjer je ni, ostane mikrofon na tipkovnici telefona.
 */
export function MealInput({ onText, onPhoto, busy = null, initial = '', autoFocus = false, onError, forDay = null }: Props) {
  const [text, setText] = useState(initial)
  const [over, setOver] = useState(false)
  const camRef = useRef<HTMLInputElement>(null)
  const galRef = useRef<HTMLInputElement>(null)
  const areaRef = useRef<HTMLTextAreaElement>(null)
  const { listening, canSpeak, toggle: toggleMic, stop: stopMic } = useDictation(text, setText, onError)
  const isBusy = !!busy

  useEffect(() => { setText(initial) }, [initial])
  useEffect(() => { if (autoFocus) areaRef.current?.focus() }, [autoFocus])
  // višina polja sledi besedilu (1–5 vrstic)
  useEffect(() => { const el = areaRef.current; if (!el) return; el.style.height = 'auto'; el.style.height = `${Math.min(el.scrollHeight, 132)}px` }, [text])

  // slika iz odložišča (Ctrl+V) kjer koli na zaslonu
  useEffect(() => {
    function onPaste(e: ClipboardEvent) {
      if (isBusy) return
      for (const it of Array.from(e.clipboardData?.items || [])) {
        if (it.kind !== 'file') continue
        const f = it.getAsFile()
        if (f && f.type.startsWith('image/')) { e.preventDefault(); onPhoto(f); return }
      }
    }
    document.addEventListener('paste', onPaste)
    return () => document.removeEventListener('paste', onPaste)
  }, [isBusy, onPhoto])

  function pick(el: HTMLInputElement | null) {
    const f = el?.files?.[0]
    if (el) el.value = ''
    if (f && f.type.startsWith('image/') && !isBusy) onPhoto(f)
  }

  function submit() {
    stopMic()
    const t = text.trim()
    if (t.length < 2 || isBusy) return
    onText(t)
  }

  return (
    <div
      className="card meal-in"
      style={{ borderColor: over ? 'var(--accent)' : undefined, background: over ? 'var(--accent-soft)' : undefined }}
      onDragOver={e => { e.preventDefault(); setOver(true) }}
      onDragLeave={() => setOver(false)}
      onDrop={e => { e.preventDefault(); setOver(false); const f = e.dataTransfer.files?.[0]; if (f && f.type.startsWith('image/') && !isBusy) onPhoto(f) }}
    >
      <div className="between" style={{ alignItems: 'baseline' }}>
        <h2 className="h4" style={{ margin: 0 }}>{forDay ? <>Vpis za {forDay}</> : 'Dodaj obrok'}</h2>
        {busy && <span className="muted" role="status" style={{ fontSize: 12, fontWeight: 700 }}>{busy === 'photo' ? 'Berem sliko …' : 'Ocenjujem …'}</span>}
      </div>
      <div className={`meal-text${listening ? ' live' : ''}`}>
        <label htmlFor="meal-desc" className="sr-only">Kaj si pojedel</label>
        <textarea
          id="meal-desc" ref={areaRef} rows={1} value={text} disabled={isBusy}
          placeholder={listening ? 'Poslušam …' : 'Napiši ali povej, kaj si pojedel'}
          onChange={e => setText(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit() } }}
          enterKeyHint="send" autoCapitalize="sentences"
        />
        {canSpeak && (
          <button type="button" className={`mic${listening ? ' on' : ''}`} onClick={toggleMic} disabled={isBusy} aria-pressed={listening} aria-label={listening ? 'Ustavi narekovanje' : 'Nareči obrok'}>
            <IcoMic width={18} height={18} />
          </button>
        )}
      </div>
      <div className="row" style={{ gap: 8, marginTop: 10 }}>
        <Btn primary sm disabled={isBusy || text.trim().length < 2} onClick={submit}><IcoSpark width={16} height={16} /> Oceni kalorije</Btn>
        <div className="grow" />
        <button type="button" className="btn ghost sm icon" disabled={isBusy} onClick={() => camRef.current?.click()} aria-label="Slikaj obrok" title="Slikaj obrok"><IcoCamera width={19} height={19} /></button>
        <button type="button" className="btn ghost sm icon" disabled={isBusy} onClick={() => galRef.current?.click()} aria-label="Slika iz galerije" title="Slika iz galerije"><IcoImage width={19} height={19} /></button>
      </div>
      <input ref={camRef} type="file" accept="image/*" capture="environment" hidden onChange={() => pick(camRef.current)} />
      <input ref={galRef} type="file" accept="image/*" hidden onChange={() => pick(galRef.current)} />
      <div className="muted" style={{ fontSize: 11.5, marginTop: 10 }}>Npr. »dva kosa kruha s pašteto in bela kava« — ali obrok slikaj. AI oceni kalorije po sestavinah, vsako številko lahko popraviš.</div>
    </div>
  )
}
