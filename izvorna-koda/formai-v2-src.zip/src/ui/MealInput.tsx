import { useEffect, useRef, useState } from 'react'
import { Btn } from '@/ui/primitives'
import { IcoCamera, IcoImage, IcoMic, IcoSpark } from '@/ui/icons'

/* Prepoznava govora brskalnika (Chrome/Android, Safari): tipi niso v standardni knjižnici. */
interface SpeechRec {
  lang: string; interimResults: boolean; continuous: boolean; maxAlternatives: number
  onresult: ((e: { resultIndex: number; results: ArrayLike<{ isFinal: boolean; 0: { transcript: string } }> }) => void) | null
  onend: (() => void) | null
  onerror: ((e: { error: string }) => void) | null
  start(): void; stop(): void; abort(): void
}
type SpeechCtor = new () => SpeechRec
const speechCtor = (): SpeechCtor | null => {
  if (typeof window === 'undefined') return null
  const w = window as unknown as { SpeechRecognition?: SpeechCtor; webkitSpeechRecognition?: SpeechCtor }
  return w.SpeechRecognition || w.webkitSpeechRecognition || null
}

type Props = {
  /** opis obroka → AI oceni kalorije po sestavinah */
  onText: (text: string) => void
  /** slika obroka */
  onPhoto: (file: File) => void
  busy?: 'text' | 'photo' | null
  /** začetni opis (npr. »Popravi opis«) */
  initial?: string
  /** fokus v polje ob odprtju (z Danes: »Opiši obrok«) */
  autoFocus?: boolean
  onError?: (msg: string) => void
}

/**
 * Dodaj obrok: napiši ali nareči, kaj si pojedel (AI oceni po sestavinah), ali ga slikaj. Ena kartica za oba načina;
 * slika se prilepi (Ctrl+V) ali povleče tudi sem. Narekovanje uporablja prepoznavo govora brskalnika (sl-SI) —
 * kjer je ni, ostane mikrofon na tipkovnici telefona.
 */
export function MealInput({ onText, onPhoto, busy = null, initial = '', autoFocus = false, onError }: Props) {
  const [text, setText] = useState(initial)
  const [listening, setListening] = useState(false)
  const [over, setOver] = useState(false)
  const camRef = useRef<HTMLInputElement>(null)
  const galRef = useRef<HTMLInputElement>(null)
  const areaRef = useRef<HTMLTextAreaElement>(null)
  const recRef = useRef<SpeechRec | null>(null)
  const baseRef = useRef('')
  const canSpeak = !!speechCtor()
  const isBusy = !!busy

  useEffect(() => { setText(initial) }, [initial])
  useEffect(() => { if (autoFocus) areaRef.current?.focus() }, [autoFocus])
  useEffect(() => () => { recRef.current?.abort() }, [])
  // višina polja sledi besedilu (1–5 vrstic)
  useEffect(() => { const el = areaRef.current; if (!el) return; el.style.height = 'auto'; el.style.height = `${Math.min(el.scrollHeight, 132)}px` }, [text])

  // slika iz odložišča (Ctrl+V) kjer koli na zaslonu
  useEffect(() => {
    function onPaste(e: ClipboardEvent) {
      if (isBusy) return
      for (const it of Array.from(e.clipboardData?.items || [])) {
        if (it.kind !== 'file') continue
        const f = it.getAsFile()
        if (f && f.type.startsWith('image/')) { e.preventDefault(); onPhoto(f); return }
      }
    }
    document.addEventListener('paste', onPaste)
    return () => document.removeEventListener('paste', onPaste)
  }, [isBusy, onPhoto])

  function pick(el: HTMLInputElement | null) {
    const f = el?.files?.[0]
    if (el) el.value = ''
    if (f && f.type.startsWith('image/') && !isBusy) onPhoto(f)
  }

  function toggleMic() {
    if (listening) { recRef.current?.stop(); return }
    const Ctor = speechCtor()
    if (!Ctor) return
    const rec = new Ctor()
    rec.lang = 'sl-SI'; rec.interimResults = true; rec.continuous = true; rec.maxAlternatives = 1
    baseRef.current = text.trim() ? text.trim() + ' ' : ''
    rec.onresult = e => {
      let said = ''
      for (let i = 0; i < e.results.length; i++) said += e.results[i]![0].transcript
      setText((baseRef.current + said).replace(/\s+/g, ' ').trimStart())
    }
    rec.onend = () => { setListening(false); recRef.current = null }
    rec.onerror = e => {
      setListening(false); recRef.current = null
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') onError?.('Dovoli mikrofon za formai.si v nastavitvah brskalnika — ali uporabi mikrofon na tipkovnici.')
      else if (e.error !== 'no-speech' && e.error !== 'aborted') onError?.('Narekovanje ni uspelo — poskusi znova ali napiši.')
    }
    recRef.current = rec
    try { rec.start(); setListening(true) } catch { setListening(false); recRef.current = null }
  }

  function submit() {
    recRef.current?.stop()
    const t = text.trim()
    if (t.length < 2 || isBusy) return
    onText(t)
  }

  return (
    <div
      className="card meal-in"
      style={{ borderColor: over ? 'var(--accent)' : undefined, background: over ? 'var(--accent-soft)' : undefined }}
      onDragOver={e => { e.preventDefault(); setOver(true) }}
      onDragLeave={() => setOver(false)}
      onDrop={e => { e.preventDefault(); setOver(false); const f = e.dataTransfer.files?.[0]; if (f && f.type.startsWith('image/') && !isBusy) onPhoto(f) }}
    >
      <div className="between" style={{ alignItems: 'baseline' }}>
        <h4 style={{ margin: 0 }}>Dodaj obrok</h4>
        {busy && <span className="muted" role="status" style={{ fontSize: 12, fontWeight: 700 }}>{busy === 'photo' ? 'Berem sliko …' : 'Ocenjujem …'}</span>}
      </div>
      <div className={`meal-text${listening ? ' live' : ''}`}>
        <label htmlFor="meal-desc" className="sr-only">Kaj si pojedel</label>
        <textarea
          id="meal-desc" ref={areaRef} rows={1} value={text} disabled={isBusy}
          placeholder={listening ? 'Poslušam …' : 'Napiši ali povej, kaj si pojedel'}
          onChange={e => setText(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit() } }}
          enterKeyHint="send" autoCapitalize="sentences"
        />
        {canSpeak && (
          <button type="button" className={`mic${listening ? ' on' : ''}`} onClick={toggleMic} disabled={isBusy} aria-pressed={listening} aria-label={listening ? 'Ustavi narekovanje' : 'Nareči obrok'}>
            <IcoMic width={18} height={18} />
          </button>
        )}
      </div>
      <div className="row" style={{ gap: 8, marginTop: 10 }}>
        <Btn primary sm disabled={isBusy || text.trim().length < 2} onClick={submit}><IcoSpark width={16} height={16} /> Oceni kalorije</Btn>
        <div className="grow" />
        <button type="button" className="btn ghost sm icon" disabled={isBusy} onClick={() => camRef.current?.click()} aria-label="Slikaj obrok" title="Slikaj obrok"><IcoCamera width={19} height={19} /></button>
        <button type="button" className="btn ghost sm icon" disabled={isBusy} onClick={() => galRef.current?.click()} aria-label="Slika iz galerije" title="Slika iz galerije"><IcoImage width={19} height={19} /></button>
      </div>
      <input ref={camRef} type="file" accept="image/*" capture="environment" hidden onChange={() => pick(camRef.current)} />
      <input ref={galRef} type="file" accept="image/*" hidden onChange={() => pick(galRef.current)} />
      <div className="muted" style={{ fontSize: 11.5, marginTop: 10 }}>Npr. »dva kosa kruha s pašteto in bela kava« — ali obrok slikaj. AI oceni kalorije po sestavinah, vsako številko lahko popraviš.</div>
    </div>
  )
}
