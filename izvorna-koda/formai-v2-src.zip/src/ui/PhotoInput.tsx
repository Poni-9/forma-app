import { useEffect, useRef, useState } from 'react'
import { Btn } from '@/ui/primitives'
import { IcoCamera, IcoUpload } from '@/ui/icons'

type Props = {
  onPick: (file: File) => void
  busy?: boolean
  label?: string
  hint?: string
}

/** Zajem slike: kamera, galerija, lepljenje in povleci-spusti. Ena slika naenkrat. */
export function PhotoInput({ onPick, busy, label = 'Dodaj sliko', hint = 'Slikaj, povleci sem ali prilepi (Ctrl+V).' }: Props) {
  const camRef = useRef<HTMLInputElement>(null)
  const galRef = useRef<HTMLInputElement>(null)
  const [over, setOver] = useState(false)

  function take(f: File | null | undefined) {
    if (!f || busy) return
    if (!f.type.startsWith('image/')) return
    onPick(f)
  }

  function fromInput(el: HTMLInputElement | null) {
    take(el?.files?.[0])
    if (el) el.value = ''  // isto sliko je treba znati izbrati dvakrat zapored
  }

  // Lepljenje ujamemo na dokumentu — brskalnik dogodek 'paste' pošlje samo aktivnemu elementu.
  useEffect(() => {
    function onPaste(e: ClipboardEvent) {
      if (busy) return
      const items = e.clipboardData?.items
      if (!items) return
      for (const it of Array.from(items)) {
        if (it.kind !== 'file') continue
        const f = it.getAsFile()
        if (f && f.type.startsWith('image/')) { e.preventDefault(); take(f); return }
      }
    }
    document.addEventListener('paste', onPaste)
    return () => document.removeEventListener('paste', onPaste)
  }, [busy, onPick])

  return (
    <div
      className="card"
      style={{ border: `1.5px dashed ${over ? 'var(--accent)' : 'var(--line)'}`, background: over ? 'var(--accent-soft)' : 'var(--card)', opacity: busy ? 0.6 : 1 }}
      onDragOver={e => { e.preventDefault(); setOver(true) }}
      onDragLeave={() => setOver(false)}
      onDrop={e => { e.preventDefault(); setOver(false); take(e.dataTransfer.files?.[0]) }}
      onPaste={e => { const f = e.clipboardData.files?.[0]; if (f) { e.preventDefault(); take(f) } }}
    >
      <div className="between">
        <b>{label}</b>
        {busy && <span className="muted" style={{ fontSize: 12 }}>Berem …</span>}
      </div>

      <input ref={camRef} type="file" accept="image/*" capture="environment" style={{ display: 'none' }} onChange={() => fromInput(camRef.current)} />
      <input ref={galRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={() => fromInput(galRef.current)} />

      <div className="row" style={{ gap: 8, marginTop: 12 }}>
        <Btn primary sm disabled={busy} onClick={() => camRef.current?.click()}><IcoCamera width={16} height={16} /> Slikaj</Btn>
        <Btn ghost sm disabled={busy} onClick={() => galRef.current?.click()}><IcoUpload width={16} height={16} /> Iz galerije</Btn>
      </div>

      <div className="muted" style={{ fontSize: 11.5, marginTop: 10 }}>{hint}</div>
    </div>
  )
}
