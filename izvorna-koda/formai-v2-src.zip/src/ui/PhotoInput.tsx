import { useEffect, useRef, useState } from 'react'
import { Btn } from '@/ui/primitives'
import { IcoCamera, IcoUpload } from '@/ui/icons'
import { rem } from '@/ui/rem'

type Props = {
  onPick: (file: File) => void
  busy?: boolean
  label?: string
  hint?: string
  /** »Slikaj« kot glavni gumb; false, kadar ima zaslon glavni gumb že drugje (npr. Prehrana v glavi) */
  primary?: boolean
}

/** (v3.51) datoteka, ki ni slika (PDF, .txt): povej, namesto da se tiho nič ne zgodi */
export const NOT_IMAGE = 'To ni slika — izberi fotografijo ali posnetek zaslona (JPG, PNG, HEIC).'
const IMG_EXT = /\.(jpe?g|png|gif|webp|heic|heif|avif|bmp)$/i
/** slika po vrsti ali, brez vrste (HEIC v nekaterih brskalnikih), po končnici */
export const isImageFile = (f: Pick<File, 'type' | 'name'>): boolean => (f.type ? f.type.startsWith('image/') : IMG_EXT.test(f.name || ''))
/** (v3.51) računalnik z miško (brez zaslona na dotik): »Slikaj« in »Iz galerije« odpreta isto okno — en gumb */
export function finePointer(): boolean {
  try { return typeof matchMedia === 'function' && matchMedia('(pointer: fine)').matches && !matchMedia('(any-pointer: coarse)').matches } catch { return false }
}
export const DESK_HINT = 'Izberi sliko — ali jo povleci sem oz. prilepi (Ctrl+V).'

/** Zajem slike: kamera, galerija, lepljenje in povleci-spusti. Ena slika naenkrat. */
const DEFAULT_HINT = 'Slikaj, povleci sem ali prilepi (Ctrl+V).'
export function PhotoInput({ onPick, busy, label = 'Dodaj sliko', hint = DEFAULT_HINT, primary = true }: Props) {
  const camRef = useRef<HTMLInputElement>(null)
  const galRef = useRef<HTMLInputElement>(null)
  const [over, setOver] = useState(false)
  const [bad, setBad] = useState<string | null>(null)
  const [desk] = useState(finePointer)

  function take(f: File | null | undefined) {
    if (!f || busy) return
    if (!isImageFile(f)) { setBad(/\.pdf$/i.test(f.name || '') || f.type === 'application/pdf' ? `${NOT_IMAGE} Pri PDF-ju pošlji posnetek zaslona.` : NOT_IMAGE); return }
    setBad(null)
    onPick(f)
  }

  function fromInput(el: HTMLInputElement | null) {
    take(el?.files?.[0])
    if (el) el.value = ''  // isto sliko je treba znati izbrati dvakrat zapored
  }

  // Lepljenje ujamemo na dokumentu — brskalnik dogodek 'paste' pošlje samo aktivnemu elementu.
  useEffect(() => {
    function onPaste(e: ClipboardEvent) {
      if (busy) return
      const items = e.clipboardData?.items
      if (!items) return
      for (const it of Array.from(items)) {
        if (it.kind !== 'file') continue
        const f = it.getAsFile()
        if (f && isImageFile(f)) { e.preventDefault(); take(f); return }
      }
    }
    document.addEventListener('paste', onPaste)
    return () => document.removeEventListener('paste', onPaste)
  }, [busy, onPick])

  return (
    <div
      className="card"
      style={{ border: `1.5px dashed ${over ? 'var(--accent)' : 'var(--line)'}`, background: over ? 'var(--accent-soft)' : 'var(--card)', opacity: busy ? 0.6 : 1 }}
      aria-busy={busy || undefined}
      onDragOver={e => { e.preventDefault(); setOver(true) }}
      onDragLeave={() => setOver(false)}
      onDrop={e => { e.preventDefault(); setOver(false); take(e.dataTransfer.files?.[0]) }}
      onPaste={e => { const f = e.clipboardData.files?.[0]; if (f) { e.preventDefault(); take(f) } }}
    >
      <div className="between">
        <b>{label}</b>
        {/* (v3.51) stalno živo območje: bralnik zaslona pove, da se slika bere */}
        <span className="muted" role="status" style={{ fontSize: rem(12) }}>{busy ? 'Berem sliko …' : ''}</span>
      </div>

      <input ref={camRef} type="file" accept="image/*" capture="environment" style={{ display: 'none' }} onChange={() => fromInput(camRef.current)} />
      <input ref={galRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={() => fromInput(galRef.current)} />

      <div className="row" style={{ gap: 8, marginTop: 12 }}>
        {desk
          ? <Btn primary={primary} sm disabled={busy} onClick={() => galRef.current?.click()}><IcoUpload width={16} height={16} /> Izberi sliko</Btn>
          : <>
            <Btn primary={primary} sm disabled={busy} onClick={() => camRef.current?.click()}><IcoCamera width={16} height={16} /> Slikaj</Btn>
            <Btn ghost sm disabled={busy} onClick={() => galRef.current?.click()}><IcoUpload width={16} height={16} /> Iz galerije</Btn>
          </>}
      </div>
      {bad && <p className="ph-err" role="alert" style={{ marginTop: 8 }}>{bad}</p>}

      {/* (v3.51) na računalniku namig za povleci-spusti in Ctrl+V tudi pri lastnem namigu (prej ga je povozil) */}
      <div className="muted" style={{ fontSize: rem(11.5), marginTop: 10 }}>{desk && hint !== DEFAULT_HINT ? `${DESK_HINT} ${hint}` : desk ? DESK_HINT : hint}</div>
    </div>
  )
}
