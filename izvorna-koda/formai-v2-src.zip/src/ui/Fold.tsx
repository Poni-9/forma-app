import { useState, type ReactNode } from 'react'
import { IcoChevDown } from '@/ui/icons'

const KEY = 'formai.fold.'
const read = (id: string): boolean => { try { return localStorage.getItem(KEY + id) === '1' } catch { return false } }
const write = (id: string, v: boolean) => { try { localStorage.setItem(KEY + id, v ? '1' : '0') } catch { /* zasebni način */ } }

/**
 * Zložljiva vrstica (Danes: Trasa, Gorivo): naslov + ena vrstica povzetka, vsebina ob tapu. Odprto/zaprto si zapomni
 * naprava — kdor gorivo bere vsak dan, ga ima odprtega.
 */
export function Fold({ id, title, sum, children }: { id: string; title: string; sum?: string | null; children: ReactNode }) {
  const [open, setOpen] = useState(() => read(id))
  return (
    <div className={`fold${open ? ' open' : ''}`}>
      <button type="button" className="fold-h" aria-expanded={open} onClick={() => { const v = !open; setOpen(v); write(id, v) }}>
        <span style={{ minWidth: 0 }}><b>{title}</b>{sum ? <small>{sum}</small> : null}</span>
        <IcoChevDown width={18} height={18} aria-hidden="true" className="chev" />
      </button>
      {open && <div className="fold-b">{children}</div>}
    </div>
  )
}
