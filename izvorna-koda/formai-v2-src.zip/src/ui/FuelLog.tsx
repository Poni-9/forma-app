import { useEffect, useState } from 'react'
import { addMeal, toast, useApp } from '@/state/store'
import { fuelEntry, fuelChoices, type RideFuel } from '@/domain/nutrition/dayplan'
import type { MealEntry, PlanDay } from '@/domain/types'
import { Sheet, Btn, Chip, Card, fmtKcal } from '@/ui/primitives'

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
const nn = (x: number) => String(x).replace('.', ',')

/** Vpis goriva za dan (obrok »Med vožnjo«, vezan na dan načrta). */
export function fuelLogOf(meals: readonly MealEntry[], day: Pick<PlanDay, 'id' | 'date'>): MealEntry | null {
  return meals.find(m => m.slot === 'med_vadbo' && m.date === day.date && m.forDay === day.id) || null
}

/**
 * »Na kolesu«: koliko si res popil in pojedel. Šteje v današnje kalorije (obrok »Med vožnjo«) in pove,
 * koliko tekočine ti predlagati naslednjič (popito / predlagano). Bidoni po pol, hrana po kosih.
 */
export function FuelLogSheet({ open, onClose, day, rf, existing, kit }: { open: boolean; onClose: () => void; day: PlanDay; rf: RideFuel; existing: MealEntry | null; kit?: string[] | null }) {
  const [more, setMore] = useState(false)
  const choices = fuelChoices(rf, kit)
  const planned = () => Object.fromEntries(rf.plan.map(it => [it.key, it.n])) as Record<string, number>
  const [got, setGot] = useState<Record<string, number>>(() => existing?.fuel || planned())
  useEffect(() => { if (open) setGot(existing?.fuel || planned()) }, [open]) // eslint-disable-line react-hooks/exhaustive-deps
  const e = fuelEntry(rf, got, day.title)
  // vpis gre na uro vožnje (začetek z Garmina), ne na uro, ko ga vpišeš — da je v seznamu dneva na pravem mestu
  const app = useApp()
  const ride = day.done?.activityId ? app.activities.find(a => a.id === day.done!.activityId) : null
  const rideTime = ride?.start ? new Date(ride.start).toTimeString().slice(0, 5) : null
  const step = (k: string, ml: number, d: number) => setGot(g => ({ ...g, [k]: Math.max(0, Math.round(((g[k] || 0) + d * (ml ? 0.5 : 1)) * 2) / 2) }))
  const all = (f: number) => setGot(Object.fromEntries(rf.plan.map(it => [it.key, f ? Math.round(it.n * f * 2) / 2 : 0])))
  async function save() {
    await addMeal({
      id: existing?.id || uid(), date: day.date, time: rideTime || existing?.time || new Date().toTimeString().slice(0, 5), slot: 'med_vadbo', name: e.name,
      grams: null, kcal: e.kcal, proteinG: null, carbsG: e.carbsG, fatG: null, confidence: 'srednja', source: 'manual', thumb: null,
      createdAt: existing?.createdAt || new Date().toISOString(), fluidMl: e.fluidMl, planMl: e.planMl, forDay: day.id, fuel: got,
    })
    toast(`Vpisano: ${fmtKcal(e.kcal)} kcal, ${nn(Math.round(e.fluidMl / 50) * 50 / 1000)} l — šteje v današnje kalorije.`, 'ok', 5000)
    onClose()
  }
  return (
    <Sheet open={open} onClose={onClose}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Na kolesu · {day.title}</b>
      <p style={{ fontSize: 12.5, marginTop: 6 }}>Koliko si res popil in pojedel? Šteje v današnje kalorije, iz tega pa se naučim, koliko tekočine ti predlagam naslednjič.</p>
      <div className="row" style={{ gap: 7, flexWrap: 'wrap', marginTop: 10 }}>
        <Chip sm onClick={() => all(1)}>vse po načrtu</Chip>
        <Chip sm onClick={() => all(0.5)}>približno pol</Chip>
        <Chip sm onClick={() => all(0)}>nič</Chip>
      </div>
      <div className="stack" style={{ gap: 0, marginTop: 10 }}>
        {choices.filter(it => it.n > 0 || more || (got[it.key] || 0) > 0).map(it => (
          <div key={it.key} className="between" style={{ padding: '9px 0', borderTop: '1px solid var(--line)', gap: 10 }}>
            <div style={{ minWidth: 0 }}>
              <b style={{ fontSize: 13.5, color: 'var(--ink)' }}>{it.name}</b>
              <div className="muted" style={{ fontSize: 11.5 }}>{it.n ? `načrt ${nn(it.n)}` : 'ni v načrtu'}{it.ml ? ` · ${it.ml} ml` : ''}{it.kcal ? ` · ${it.kcal} kcal na kos` : ''}</div>
            </div>
            <div className="row" style={{ gap: 6, flex: 'none' }}>
              <button className="chip sm click" aria-label={`manj: ${it.name}`} onClick={() => step(it.key, it.ml, -1)}>−</button>
              <b style={{ minWidth: 30, textAlign: 'center', fontSize: 15 }}>{nn(got[it.key] || 0)}</b>
              <button className="chip sm click" aria-label={`več: ${it.name}`} onClick={() => step(it.key, it.ml, 1)}>+</button>
            </div>
          </div>
        ))}
      </div>
      {!more && choices.some(it => it.n === 0 && !(got[it.key] || 0)) && <button className="chip sm click" style={{ marginTop: 8 }} onClick={() => setMore(true)}>+ kaj drugega (npr. Frutabela namesto gela, voda)</button>}
      <div className="muted" style={{ fontSize: 12, marginTop: 8 }}>Skupaj ~{fmtKcal(e.kcal)} kcal · {e.carbsG} g OH · {nn(Math.round(e.fluidMl / 50) * 50 / 1000)} l (predlagano {nn(Math.round(rf.fluidMl / 50) * 50 / 1000)} l)</div>
      <Btn primary block style={{ marginTop: 12 }} onClick={save}>Shrani</Btn>
      <Btn ghost block style={{ marginTop: 8 }} onClick={onClose}>Prekliči</Btn>
    </Sheet>
  )
}

/** Kartica po vožnji (Danes): en klik »vse po načrtu« ali natančen vpis. */
export function FuelLogCard({ day, rf, meals, kit }: { day: PlanDay; rf: RideFuel; meals: readonly MealEntry[]; kit?: string[] | null }) {
  const [open, setOpen] = useState(false)
  const ex = fuelLogOf(meals, day)
  if (!rf.plan.length) return null
  return (<>
    <Card tight style={{ marginTop: 12 }}>
      <div className="between" style={{ gap: 10 }}>
        <div style={{ minWidth: 0 }}>
          <h4 style={{ fontSize: 11, margin: 0 }}>Na kolesu</h4>
          <div style={{ fontSize: 12.5, marginTop: 4, color: 'var(--ink-2)' }}>{ex ? <>Vpisano: <b style={{ color: 'var(--ink)' }}>{fmtKcal(ex.kcal)} kcal</b>{ex.fluidMl != null ? ` · ${nn(Math.round(ex.fluidMl / 50) * 50 / 1000)} l` : ''} — šteje v današnje kalorije.</> : 'Koliko si popil in pojedel? Šteje v kalorije samo, če vpišeš.'}</div>
        </div>
        <Btn ghost sm onClick={() => setOpen(true)}>{ex ? 'Uredi' : 'Vpiši'}</Btn>
      </div>
    </Card>
    <FuelLogSheet open={open} onClose={() => setOpen(false)} day={day} rf={rf} existing={ex} kit={kit} />
  </>)
}
