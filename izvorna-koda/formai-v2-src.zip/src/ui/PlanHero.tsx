import { useMemo, useRef, useState, type ReactNode } from 'react'
import type { Activity, AgreedSession, PlanDay, Profile } from '@/domain/types'
import { addDays, fmtDur, weekStartIso, titleNoDur } from '@/domain/training/load'
import { weekContext, type PhaseKey, type WeekCtx } from '@/domain/training/planner'
import { seasonGoals } from '@/domain/training/season'
import { weekProgress } from '@/domain/training/share'
import { PAUSE_TITLE } from '@/domain/training/pause'
import { isStrength } from '@/domain/focus/model'
import { KindIcon, kindColor, DAYS_SL, MONTHS_SL } from '@/ui/primitives'
import { count, dm, num, NBSP, W } from '@/ui/format'
import { IcoCheck, IcoTrophy } from '@/ui/icons'

/**
 * PLAN NA PRVI POGLED (Blaž, 14. 10.: »ko kliknem plan, bi rad čim prej videl uporabne stvari in plan za dlje časa;
 * kolesar hoče videti celo sezono po tednih … žive barve in animacije kot na prvi strani«):
 * – trak tedna: 7 dni z barvo in ikono vadbe, opravljeno, danes; tap = ta dan,
 * – obzorje: naslednji tedni (načrt po meri: bloki po 4 tedne, moč in kardio) ali cela sezona do cilja (kolesar).
 */
const short = (m: number) => (m >= 60 ? (m % 60 ? `${Math.floor(m / 60)}:${String(Math.round(m % 60)).padStart(2, '0')}` : `${m / 60} h`) : `${m}′`)
/** dan tekme: pokal in barva poudarka (prej kot vsaka vožnja) */
const DayIcon = ({ d, size }: { d: Pick<PlanDay, 'kind' | 'role' | 'done'>; size: number }) => (d.done ? <IcoCheck width={size} height={size} /> : d.role === 'dirka' ? <IcoTrophy width={size} height={size} /> : <KindIcon kind={d.kind} size={size} />)
const dayColor = (d: Pick<PlanDay, 'kind' | 'role'>) => (d.role === 'dirka' ? 'var(--accent)' : kindColor(d.kind))
/** (v3.48) Dan počitka s polnjenjem OH pred dolgo tekmo — povsod viden, ne samo »Počitek«. */
export const isCarbRest = (d: Pick<PlanDay, 'kind' | 'title'>) => d.kind === 'pocitek' && /polnjenje/i.test(d.title)
/** (v3.50) dan premora »Ta teden …« je »Premor« (ne »Počitek«) */
export const restLabel = (d: Pick<PlanDay, 'kind' | 'title'>) => (isCarbRest(d) ? 'Počitek · polnjenje OH' : d.kind === 'pocitek' && d.title.startsWith(PAUSE_TITLE) ? d.title.replace(' — ', ' · ') : 'Počitek')
/** trajanje brez preloma (»1 h 45 / min« pri 320 px) */
const durNb = (m: number) => fmtDur(m).replace(/ /g, NBSP)
/** (v3.50) Glavna seja dneva: test, kolo, tek/hribi, nato moč — shramba vrača zapise po id-ju, ne po vrsti sestave. */
const KIND_RANK: Record<string, number> = { test: 0, kolo: 1, tek: 2, pohod: 2, moc: 3, pocitek: 4 }
export const mainFirst = (a: Pick<PlanDay, 'kind' | 'role'>, b: Pick<PlanDay, 'kind' | 'role'>) => (a.role === 'dirka' ? -1 : KIND_RANK[a.kind] ?? 3) - (b.role === 'dirka' ? -1 : KIND_RANK[b.kind] ?? 3)

/**
 * (v3.50 B29/G10) Vrstica stolpcev kot EN drsnik: tap ali vlečenje izbere teden pod prstom (stolpci so bili 6–7 px široki
 * gumbi — 38 postankov za tipkovnico), ← → Home End za tipkovnico, izbrani teden pove `aria-valuetext`.
 */
export function nearestBar(x: number, width: number, n: number): number {
  if (n <= 0 || width <= 0) return 0
  return Math.max(0, Math.min(n - 1, Math.floor((x / width) * n)))
}
function BarRow({ n, sel, onSel, label, valueText, tall, room, children }: { n: number; sel: number; onSel: (i: number) => void; label: string; valueText: string; tall?: boolean; /** prostor nad stolpci za dvignjen »zdaj« */ room?: boolean; children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null)
  const pick = (clientX: number) => { const r = ref.current?.getBoundingClientRect(); if (r) onSel(nearestBar(clientX - r.left, r.width, n)) }
  const onKey = (e: React.KeyboardEvent) => {
    const next = e.key === 'ArrowRight' || e.key === 'ArrowUp' ? sel + 1 : e.key === 'ArrowLeft' || e.key === 'ArrowDown' ? sel - 1 : e.key === 'Home' ? 0 : e.key === 'End' ? n - 1 : null
    if (next == null) return
    e.preventDefault(); onSel(Math.max(0, Math.min(n - 1, next)))
  }
  return (
    <div ref={ref} className={`pl-bars${tall ? ' tall' : ''}${room ? ' room' : ''}`} role="slider" tabIndex={0} aria-label={label} aria-valuemin={0} aria-valuemax={Math.max(0, n - 1)} aria-valuenow={sel} aria-valuetext={valueText}
      onPointerDown={e => { if (e.button === 0) { try { e.currentTarget.setPointerCapture?.(e.pointerId) } catch { /* brez zajema */ } pick(e.clientX) } }} onPointerMove={e => { if (e.buttons & 1) pick(e.clientX) }} onKeyDown={onKey}>
      {children}
    </div>
  )
}

/** Trak tedna; brez onPick je samo prikaz (dogovor: teden, kot ga bo imel načrt). */
export function WeekRibbon({ days, items, today, focus, onPick, label: groupLabel = 'Dnevi tega tedna' }: { days: string[]; items: readonly PlanDay[]; today: string; focus: string; onPick?: (d: string) => void; label?: string }) {
  return (
    <div className={`pl-ribbon${onPick ? '' : ' static'}`} role={onPick ? 'group' : 'list'} aria-label={groupLabel}>
      {days.map((d, i) => {
        const list = items.filter(x => x.date === d && x.kind !== 'pocitek' && !x.optional).sort(mainFirst)
        const min = list.reduce((t, x) => t + x.durationMin, 0)
        const done = list.length > 0 && list.every(x => x.done)
        const past = d < today
        const missed = past && list.some(x => !x.done)
        const main = list[0]
        const carb = !main && items.some(x => x.date === d && isCarbRest(x))
        const label = `${DAYS_SL[i]} ${+d.slice(8)}.: ${list.length ? list.map(x => x.title).join(' + ') : carb ? 'počitek, polnjenje OH' : 'počitek'}${done ? ', opravljeno' : missed ? ', ni označeno' : ''}`
        const cls = `pl-day${d === today ? ' today' : ''}${d === focus ? ' sel' : ''}${done ? ' done' : ''}${missed ? ' missed' : ''}${main ? '' : ' rest'}${carb ? ' carb' : ''}`
        const style = { ['--i' as string]: i, ['--c' as string]: main ? dayColor(main) : 'var(--t-poc)' }
        const body = (<>
          <span className="pl-dn">{d === today ? 'danes' : DAYS_SL[i]}</span>
          <span className="pl-dd">{+d.slice(8)}</span>
          <span className="pl-ico">{main ? (done ? <IcoCheck width={15} height={15} /> : <DayIcon d={main} size={15} />) : <i />}</span>
          <span className="pl-min">{main ? short(min) : carb ? 'OH' : ''}</span>
          {list.length > 1 && <span className="pl-more" aria-hidden="true">{list.slice(1, 3).map((x, j) => <i key={j} style={{ background: kindColor(x.kind) }} />)}</span>}
        </>)
        return onPick
          ? <button key={d} type="button" style={style} className={cls} onClick={() => onPick(d)} aria-label={label} aria-pressed={d === focus}>{body}</button>
          : <div key={d} role="listitem" style={style} className={cls} aria-label={label}>{body}</div>
      })}
    </div>
  )
}

/**
 * NASLEDNJA DVA TEDNA (16. 10., Blažev brat: »da lahko pogledaš 2 tedna naprej, kaj boš imel na treningu«): 14 dni od
 * danes v enem seznamu po tednih — vadba, trajanje, kardio po moči, vaje ali cona. Teden, ki še ni sestavljen, je
 * okviren (izračunan sproti iz dogovora, shrani se, ko pride na vrsto). Tap na dan odpre ta dan v tednu.
 */
const vaj = (n: number) => `${n} ${n === 1 ? 'vaja' : n === 2 ? 'vaji' : n <= 4 ? 'vaje' : 'vaj'}`
export function Ahead({ items, preview, today, onPick }: { items: readonly PlanDay[]; preview: ReadonlySet<string>; today: string; onPick: (d: string) => void }) {
  // od danes do konca tedna, v katerem je 14. dan (celi koledarski tedni — vsota tedna z vikendom)
  const last = addDays(weekStartIso(addDays(today, 13)), 6)
  const days: string[] = []
  for (let d = today; d <= last; d = addDays(d, 1)) days.push(d)
  const ws0 = weekStartIso(today)
  const groups: { key: string; label: string; days: string[] }[] = []
  for (const d of days) {
    const w = weekStartIso(d)
    const label = w === ws0 ? 'Ta teden' : w === addDays(ws0, 7) ? 'Naslednji teden' : 'Čez dva tedna'
    const g = groups.find(x => x.key === w)
    if (g) g.days.push(d); else groups.push({ key: w, label, days: [d] })
  }
  const tomorrow = addDays(today, 1)
  return (
    <div className="ahead">
      {groups.map((g, gi) => {
        const act = items.filter(x => g.days.includes(x.date) && x.kind !== 'pocitek' && !x.optional)
        // trajanje dneva že vsebuje kardio po moči (tail) — prej je bil ta štet dvakrat
        const total = act.reduce((t, x) => t + x.durationMin, 0)
        const rough = g.days.some(d => preview.has(d))
        // (v3.50) en dan (nedelja): »danes, 18. 10.« namesto »18. 10. – 18. 10.«; kolo in moč posebej (prej seštevek 6 h 50 pri 6 h kolesa)
        const span = g.days.length === 1 ? `${g.days[0] === today ? 'danes, ' : ''}${dm(g.days[0]!)}` : `${dm(g.days[0]!)} – ${dm(g.days[g.days.length - 1]!)}`
        const moc = act.filter(x => x.kind === 'moc').reduce((t, x) => t + x.durationMin, 0)
        const cardio = act.some(x => x.kind === 'tek' || x.kind === 'pohod') ? 'kardio' : 'kolo'
        const sum = !act.length ? 'brez vadb' : `${act.length}${NBSP}${act.length === 1 ? 'vadba' : act.length === 2 ? 'vadbi' : act.length <= 4 ? 'vadbe' : 'vadb'} · ${moc && moc < total ? `${cardio} ${durNb(total - moc)} · moč ${durNb(moc)}` : durNb(total)}`
        return (
          <section key={g.key} className="ah-wk" style={{ ['--i' as string]: gi }}>
            <div className="ah-h">
              <b>{g.label}</b>
              <span>{span} · {sum}{rough ? ' · okvirno' : ''}</span>
            </div>
            <ol className="ah-list">
              {g.days.map((d, di) => {
                const list = items.filter(x => x.date === d && x.kind !== 'pocitek').sort((a, b) => Number(!!a.optional) - Number(!!b.optional) || mainFirst(a, b))
                const main = list.find(x => !x.optional) ?? list[0]
                const rest0 = list.length ? null : items.find(x => x.date === d && x.kind === 'pocitek') ?? null
                const carb = !!rest0 && isCarbRest(rest0)
                const dow = (new Date(`${d}T12:00:00`).getDay() + 6) % 7
                const name = d === today ? 'Danes' : d === tomorrow ? 'Jutri' : DAYS_SL[dow]!.charAt(0).toUpperCase() + DAYS_SL[dow]!.slice(1)
                const label = `${name} ${dm(d)}: ${list.length ? list.map(x => x.title).join(' + ') : carb ? 'počitek, polnjenje OH' : 'počitek'}`
                const body = (<>
                  <span className="ah-date"><b>{name}</b><small>{dm(d)}</small></span>
                  <span className="ah-ico" aria-hidden="true">{main ? <DayIcon d={main} size={16} /> : <i />}</span>
                  <span className="ah-txt">
                    {list.length ? list.map(x => (
                      <span key={x.id} className={x.optional ? 'opt' : ''}>
                        <b>{titleNoDur(x.tail ? x.title.replace(/\s\+\s[^+]+$/, '') : x.title, x.durationMin - (x.tail?.durationMin || 0))}</b>
                        <small>{[durNb(x.durationMin - (x.tail?.durationMin || 0)), x.tail ? `nato ${titleNoDur(x.tail.title, x.tail.durationMin).replace(/ — /, ': ').toLowerCase()} ${durNb(x.tail.durationMin)}` : '', x.exercises?.length ? vaj(x.exercises.length) : x.zone || '', x.optional ? 'po želji' : '', x.done ? 'opravljeno' : ''].filter(Boolean).join(' · ')}</small>
                      </span>
                    )) : <span><b className="rest">{rest0 ? restLabel(rest0) : 'Počitek'}</b></span>}
                  </span>
                </>)
                const cls = `ah-day${d === today ? ' today' : ''}${main ? '' : ' rest'}${main?.done ? ' done' : ''}${carb ? ' carb' : ''}`
                const style = { ['--c' as string]: main ? dayColor(main) : 'var(--t-poc)', ['--j' as string]: di }
                return (
                  <li key={d}>
                    {preview.has(d)
                      ? <div className={`${cls} rough`} style={style} aria-label={`${label} (okvirno)`}>{body}</div>
                      : <button type="button" className={cls} style={style} onClick={() => onPick(d)} aria-label={label}>{body}<span className="ah-go" aria-hidden="true">›</span></button>}
                  </li>
                )
              })}
            </ol>
          </section>
        )
      })}
    </div>
  )
}

/** Napredek tedna v eni vrstici z barvnim trakom. */
export function WeekProgress({ items, activities }: { items: readonly PlanDay[]; activities: readonly Activity[] }) {
  const active = items.filter(d => d.kind !== 'pocitek' && !d.optional)
  if (!active.length) return null
  const done = active.filter(d => d.done)
  // isti izračun kot Danes (weekProgress): tudi delno shranjena vožnja šteje dejanski čas (v3.48)
  const { minAll, minDone } = weekProgress(items, activities)
  const pc = minAll ? Math.min(100, Math.round((minDone / minAll) * 100)) : 0
  return (
    <div className="pl-prog" role="group" aria-label={`Opravljeno ${done.length} od ${active.length} treningov, ${fmtDur(minDone)} od ${fmtDur(minAll)}`}>
      <span className="pl-prog-bar" aria-hidden="true"><i style={{ width: `${Math.max(pc, minDone ? 4 : 0)}%` }} /></span>
      <span className="pl-prog-tx" aria-hidden="true"><b>{done.length}/{active.length}</b> treningov · {minDone ? fmtDur(minDone) : '0 min'} od {fmtDur(minAll)}</span>
    </div>
  )
}

/* ---------- obzorje: načrt po meri (bloki) ---------- */
/** Minute po vrsti in število sej (moč, kolo, tek, hribi): tek in hribi ločeno (v3.48 — prej »tek/hribi« tudi pri samem teku). */
interface HzWeek { ws: string; cx: WeekCtx; moc: number; kolo: number; tek: number; hribi: number; n: { moc: number; kolo: number; tek: number; hribi: number } }
/**
 * (v3.50) plan: tedni, ki so že sestavljeni, štejejo minute iz načrta (kot napredek tedna »0 min od 1 h 15 min«) —
 * prej je trak iz dogovora × obseg pokazal »1 h 18 min« ob »1 h 15 min« (H16). Ostali tedni po dogovoru.
 */
export function customWeeks(p: Profile, from: string, n: number, plan: readonly PlanDay[] = []): HzWeek[] {
  const f = p.focus
  if (!f) return []
  const cnt = (t: (s: AgreedSession) => boolean) => f.sessions.filter(t).length
  const nn = { moc: cnt(isStrength), kolo: cnt(s => s.type === 'kolo'), tek: cnt(s => s.type === 'tek'), hribi: cnt(s => s.type === 'hribi') }
  return Array.from({ length: n }, (_, i) => {
    const ws = addDays(from, 7 * i)
    const cx = weekContext(p, ws)
    const days = plan.filter(d => d.date >= ws && d.date <= addDays(ws, 6))
    if (days.some(d => d.kind !== 'pocitek')) {
      const m = { moc: 0, kolo: 0, tek: 0, hribi: 0 }, c = { moc: 0, kolo: 0, tek: 0, hribi: 0 }
      const bikeTest = f.sessions.some(x => x.type === 'kolo')
      const key = (k: string): keyof typeof m => (k === 'moc' ? 'moc' : k === 'kolo' || (k === 'test' && bikeTest) ? 'kolo' : k === 'pohod' ? 'hribi' : 'tek')
      for (const d of days) {
        if (d.kind === 'pocitek' || d.optional) continue
        const tail = d.tail?.durationMin || 0
        m[key(d.kind)] += (d.durationMin || 0) - tail; c[key(d.kind)]++
        if (d.tail && tail) m[key(d.tail.kind)] += tail
      }
      return { ws, cx, ...m, n: c }
    }
    let moc = 0, kolo = 0, tek = 0, hribi = 0
    for (const s of f.sessions) {
      if (isStrength(s)) moc += Math.round(s.min * (cx.recovery ? 0.85 : 1))
      else if (s.type === 'kolo') kolo += Math.round(s.min * cx.volume)
      else if (s.type === 'hribi') hribi += Math.round(s.min * cx.volume)
      else tek += Math.round(s.min * cx.volume)
    }
    return { ws, cx, moc, kolo, tek, hribi, n: nn }
  })
}
/** Vrstica izbranega tedna: »1 h 45 min · tek 3×« — vrste s številom sej, brez »100 % obsega« (v3.48). */
export function hzWeekLine(w: Pick<HzWeek, 'n' | 'cx'>): string {
  const bits = [w.n.moc ? `moč ${w.n.moc}×` : '', w.n.kolo ? `kolo ${w.n.kolo}×` : '', w.n.tek ? `tek ${w.n.tek}×` : '', w.n.hribi ? `hribi ${w.n.hribi}×` : ''].filter(Boolean)
  return [...bits, w.cx.recovery ? 'lažji teden' : ''].filter(Boolean).join(' · ')
}

export function Horizon({ profile, today, onWeek, plan }: { profile: Profile; today: string; onWeek?: (ws: string) => void; plan?: readonly PlanDay[] }) {
  const ws0 = weekStartIso(today)
  const goals = seasonGoals(profile).filter(g => g.date >= today)
  // do cilja (če ga ima in je v 40 tednih), sicer 12 tednov = trije bloki
  const toGoal = goals[0] ? Math.ceil((new Date(weekStartIso(goals[0].date)).getTime() - new Date(ws0).getTime()) / (7 * 86400_000)) + 1 : 0
  const n = toGoal >= 4 && toGoal <= 40 ? toGoal : 12
  const weeks = useMemo(() => customWeeks(profile, ws0, n, plan), [profile, ws0, n, plan])
  const [sel, setSel] = useState(0)
  if (!weeks.length) return null
  const tot = (w: HzWeek) => w.moc + w.kolo + w.tek + w.hribi
  const max = Math.max(1, ...weeks.map(tot))
  const goalWeek = new Map(goals.map(g => [weekStartIso(g.date), g.name] as const))
  const w = weeks[sel]!
  const own = profile.focus?.block
  const wkLabel = (x: HzWeek) => `Teden od ${dm(x.ws)}: ${fmtDur(tot(x))}${x.cx.recovery ? ', lažji teden' : ''}${goalWeek.has(x.ws) ? `, cilj ${goalWeek.get(x.ws)}` : ''}`
  // (v3.50 H17) oznake osi na začetku bloka (blockWeek === 1), ne vsake 4 tedne od tekočega — dogovor sredi bloka jih je zamaknil
  const axisAt = new Set<number>()
  weeks.forEach((x, i) => {
    // uvodni teden pred začetkom bloka: oznaka na začetku bloka, ne na obeh sosednjih stolpcih
    const intro = !!profile.cycleStart && x.ws < profile.cycleStart
    if ((x.cx.blockWeek === 1 && !intro) || (i === 0 && weeks[1]?.cx.blockWeek !== 1)) axisAt.add(i)
  })
  return (
    <section className="pl-hz card" aria-label="Načrt za naslednje tedne">
      <div className="between"><b className="pl-hz-h">Naslednji tedni</b><span className="pl-hz-sub">{own && own.length ? `bloki po ${own.length} ${own.length === 1 ? 'teden' : own.length === 2 ? 'tedna' : own.length <= 4 ? 'tedni' : 'tednov'}` : 'bloki po 4 tedne · 4. lažji'} · potegni po tednih</span></div>
      <BarRow n={weeks.length} sel={sel} onSel={i => { setSel(i); onWeek?.(weeks[i]!.ws) }} label="Tedni — izberi teden" valueText={wkLabel(w)}>
        {weeks.map((x, i) => {
          const t = tot(x)
          return (
            <span key={x.ws} className={`pl-bar${i === sel ? ' sel' : ''}${x.cx.recovery ? ' easy' : ''}${goalWeek.has(x.ws) ? ' goal' : ''}${i === 0 ? ' now' : ''}`} style={{ ['--i' as string]: i, height: `${Math.max(14, Math.round((t / max) * 100))}%` }}>
              {x.kolo > 0 && <i style={{ flex: x.kolo, background: 'var(--t-kolo)' }} />}
              {x.tek + x.hribi > 0 && <i style={{ flex: x.tek + x.hribi, background: 'var(--t-tek)' }} />}
              {x.moc > 0 && <i style={{ flex: x.moc, background: 'var(--t-moc)' }} />}
              {i === 0 && <span className="pl-now">zdaj</span>}
            </span>
          )
        })}
      </BarRow>
      <div className="pl-axis" aria-hidden="true">{weeks.map((x, i) => <span key={x.ws}>{axisAt.has(i) ? dm(x.ws) : ''}</span>)}</div>
      <p className="pl-hz-info"><b>{sel === 0 ? 'Ta teden' : sel === 1 ? 'Naslednji teden' : `Teden od ${dm(w.ws)}`}</b> · {fmtDur(tot(w))}{hzWeekLine(w) ? ` · ${hzWeekLine(w)}` : ''}{goalWeek.has(w.ws) ? ` · cilj: ${goalWeek.get(w.ws)}` : ''}</p>
      <div className="pl-legend" aria-hidden="true">
        {weeks.some(x => x.kolo) && <span><i style={{ background: 'var(--t-kolo)' }} />kolo</span>}
        {weeks.some(x => x.tek + x.hribi) && <span><i style={{ background: 'var(--t-tek)' }} />{[weeks.some(x => x.tek) ? 'tek' : '', weeks.some(x => x.hribi) ? 'hribi' : ''].filter(Boolean).join(', ')}</span>}
        {weeks.some(x => x.moc) && <span><i style={{ background: 'var(--t-moc)' }} />moč</span>}
      </div>
    </section>
  )
}

/* ---------- sezona: kolesarski makrocikel do cilja ---------- */
const PH_COLOR: Record<PhaseKey, string> = { prehod: 'var(--t-poc)', osnova: 'var(--t-kolo)', gradnja: 'var(--ph-gradnja)', specificno: 'var(--t-moc)', tapering: 'var(--ok)', dirka: 'var(--accent)', po: 'var(--t-poc)' }
/**
 * Oznake mesecev na osi sezone: šele, ko je od prejšnje vsaj 3 stolpce (prej »SEPOKT«). (v3.48) Ob trku ostane poznejši
 * mesec — razen če je prejšnji mesec tisti z »zdaj« (prej je os izpustila »OKT«, v katerem je bil »ZDAJ«).
 */
export function monthMarks(weekStarts: readonly string[], now: number): { at: number; label: string }[] {
  const out: { at: number; label: string; m: number }[] = []
  const nowM = now >= 0 && weekStarts[now] ? +weekStarts[now]!.slice(5, 7) : null
  weekStarts.forEach((ws, i) => {
    const m = +ws.slice(5, 7)
    if (i > 0 && m === +weekStarts[i - 1]!.slice(5, 7)) return
    const last = out[out.length - 1]
    if (!last || i - last.at >= 3) out.push({ at: i, label: MONTHS_SL[m - 1]!.slice(0, 3), m })
    else if (last.m !== nowM) out[out.length - 1] = { at: i, label: MONTHS_SL[m - 1]!.slice(0, 3), m }
  })
  return out.map(({ at, label }) => ({ at, label }))
}
/** Sezona po tednih; ure tednov pride iz načrta (Plan: plannedMacro), ne iz zgornje meje faze. */
export function SeasonChart({ macro, profile, start, today }: { macro: readonly (WeekCtx & { weekStart: string })[]; profile: Profile; start: string; today: string }) {
  const goals = seasonGoals(profile)
  const goalWeek = new Map(goals.map(g => [weekStartIso(g.date), g.name] as const))
  const raceWeek = new Map<string, string[]>()
  for (const r of profile.races || []) { if (r.prio === 'A') continue; const k = weekStartIso(r.date); raceWeek.set(k, [...(raceWeek.get(k) || []), r.name]) }
  // »zdaj« je vedno teden današnjega dne; izbran je teden, ki ga gledaš (pri »Naslednji« je bil »zdaj« narobe)
  const ws0 = weekStartIso(today)
  const now = macro.findIndex(w => w.weekStart === ws0)
  const cur = Math.max(0, macro.findIndex(w => w.weekStart === start))
  const [sel, setSel] = useState(cur)
  const hoursOf = (x: WeekCtx & { weekStart: string }) => x.hours
  if (!macro.length) return null
  const max = Math.max(1, ...macro.map(hoursOf))
  const w = macro[Math.min(sel, macro.length - 1)]!
  const months = monthMarks(macro.map(x => x.weekStart), now)
  const phases = (['prehod', 'osnova', 'gradnja', 'specificno', 'tapering'] as PhaseKey[]).filter(k => macro.some(x => x.phase === k))
  const wkLabel = (x: WeekCtx & { weekStart: string }) => `Teden od ${dm(x.weekStart)}: ${x.phaseName}, ${num(hoursOf(x))} h${goalWeek.has(x.weekStart) ? `, cilj ${goalWeek.get(x.weekStart)}` : ''}${raceWeek.has(x.weekStart) ? `, tekma ${raceWeek.get(x.weekStart)!.join(', ')}` : ''}`
  // (v3.50 B47) »ZDAJ« više, ko ima ta ali sosednji teden piko tekme (prej jo je prekril)
  const nearFlag = now >= 0 && [macro[now - 1], macro[now], macro[now + 1]].some(x => x && (raceWeek.has(x.weekStart) || goalWeek.has(x.weekStart)))
  // (v3.50 B41) makro ima največ 80 tednov — pri cilju čez več kot 80 tednov povej, da graf ne seže do njega
  const lastWs = macro[macro.length - 1]!.weekStart
  const beyond = goals.find(g => weekStartIso(g.date) > lastWs)
  const weeksBeyond = beyond ? Math.round((new Date(`${weekStartIso(beyond.date)}T12:00:00`).getTime() - new Date(`${ws0}T12:00:00`).getTime()) / (7 * 86400_000)) : 0
  return (
    <section className="pl-hz pl-season card" aria-label="Sezona po tednih">
      <div className="between"><b className="pl-hz-h">Sezona po tednih</b><span className="pl-hz-sub">{goals[0] ? `${goals[0].name} · ${dm(goals[0].date)}` : ''}</span></div>
      <BarRow n={macro.length} sel={Math.min(sel, macro.length - 1)} onSel={setSel} label="Tedni sezone — izberi teden" valueText={wkLabel(w)} tall room={nearFlag}>
        {macro.map((x, i) => (
          // pretekel je teden pred tem tednom (prej pred izbranim: pri »Naslednji« je bil tekoči teden bled); »zdaj« nad piko tekme (v3.48)
          <span key={x.weekStart} className={`pl-bar${i === sel ? ' sel' : ''}${x.recovery || x.easy ? ' easy' : ''}${goalWeek.has(x.weekStart) ? ' goal' : ''}${x.weekStart < ws0 ? ' past' : ''}${i === now ? ' now' : ''}`}
            style={{ ['--i' as string]: i, height: goalWeek.has(x.weekStart) ? '100%' : `${Math.max(10, Math.round((hoursOf(x) / max) * 100))}%` }}>
            <i style={{ flex: 1, background: goalWeek.has(x.weekStart) ? 'var(--accent)' : PH_COLOR[x.phase] }} />
            {raceWeek.has(x.weekStart) && <span className="pl-flag b" aria-hidden="true" />}
            {goalWeek.has(x.weekStart) && <span className="pl-flag" aria-hidden="true" />}
            {i === now && <span className={`pl-now${nearFlag ? ' up' : ''}`}>zdaj</span>}
          </span>
        ))}
      </BarRow>
      <div className="pl-months" aria-hidden="true">{months.map(m => <span key={m.at} style={{ left: `${(m.at / macro.length) * 100}%` }}>{m.label}</span>)}</div>
      <p className="pl-hz-info"><b>{sel === now ? 'Ta teden' : sel === now + 1 ? 'Naslednji teden' : `Teden od ${dm(w.weekStart)}`}</b> · {w.phaseName.toLowerCase()} · {num(hoursOf(w))} h{w.recovery && w.phase !== 'prehod' ? ' · razbremenilni' : ''}{w.test ? ' · test FTP' : ''}{goalWeek.has(w.weekStart) ? ` · CILJ: ${goalWeek.get(w.weekStart)}` : ''}{raceWeek.has(w.weekStart) ? ` · tekma: ${raceWeek.get(w.weekStart)!.join(', ')}` : ''}</p>
      {beyond && <p className="pl-hz-info muted" style={{ marginTop: 4, fontSize: 11.5 }}>Graf kaže prvih {macro.length} tednov — {beyond.name} je čez {count(weeksBeyond, W.tedenT)}.</p>}
      <div className="pl-legend" aria-hidden="true">
        {phases.map(k => <span key={k}><i style={{ background: PH_COLOR[k] }} />{macro.find(x => x.phase === k)!.phaseName.toLowerCase()}</span>)}
        <span><i style={{ background: 'var(--accent)' }} />cilj</span>
      </div>
    </section>
  )
}
