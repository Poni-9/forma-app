import { useMemo, useState } from 'react'
import type { Activity, PlanDay, Profile } from '@/domain/types'
import { addDays, fmtDur, weekStartIso } from '@/domain/training/load'
import { weekContext, type PhaseKey, type WeekCtx } from '@/domain/training/planner'
import { seasonGoals } from '@/domain/training/season'
import { isStrength } from '@/domain/focus/model'
import { KindIcon, kindColor, DAYS_SL, MONTHS_SL } from '@/ui/primitives'
import { dm, num } from '@/ui/format'
import { IcoCheck } from '@/ui/icons'

/**
 * PLAN NA PRVI POGLED (Blaž, 14. 10.: »ko kliknem plan, bi rad čim prej videl uporabne stvari in plan za dlje časa;
 * kolesar hoče videti celo sezono po tednih … žive barve in animacije kot na prvi strani«):
 * – trak tedna: 7 dni z barvo in ikono vadbe, opravljeno, danes; tap = ta dan,
 * – obzorje: naslednji tedni (načrt po meri: bloki po 4 tedne, moč in kardio) ali cela sezona do cilja (kolesar).
 */
const short = (m: number) => (m >= 60 ? `${num(Math.round(m / 30) / 2)} h` : `${m}′`)

export function WeekRibbon({ days, items, today, focus, onPick }: { days: string[]; items: readonly PlanDay[]; today: string; focus: string; onPick: (d: string) => void }) {
  return (
    <div className="pl-ribbon" role="group" aria-label="Dnevi tega tedna">
      {days.map((d, i) => {
        const list = items.filter(x => x.date === d && x.kind !== 'pocitek' && !x.optional)
        const min = list.reduce((t, x) => t + x.durationMin, 0)
        const done = list.length > 0 && list.every(x => x.done)
        const past = d < today
        const missed = past && list.some(x => !x.done)
        const main = list[0]
        const label = `${DAYS_SL[i]} ${+d.slice(8)}.: ${list.length ? list.map(x => x.title).join(' + ') : 'počitek'}${done ? ', opravljeno' : missed ? ', ni bilo' : ''}`
        return (
          <button key={d} type="button" style={{ ['--i' as string]: i, ['--c' as string]: main ? kindColor(main.kind) : 'var(--t-poc)' }}
            className={`pl-day${d === today ? ' today' : ''}${d === focus ? ' sel' : ''}${done ? ' done' : ''}${missed ? ' missed' : ''}${main ? '' : ' rest'}`}
            onClick={() => onPick(d)} aria-label={label} aria-pressed={d === focus}>
            <span className="pl-dn">{d === today ? 'danes' : DAYS_SL[i]}</span>
            <span className="pl-dd">{+d.slice(8)}</span>
            <span className="pl-ico">{main ? (done ? <IcoCheck width={15} height={15} /> : <KindIcon kind={main.kind} size={15} />) : <i />}</span>
            <span className="pl-min">{main ? short(min) : ''}</span>
            {list.length > 1 && <span className="pl-more" aria-hidden="true">{list.slice(1, 3).map((x, j) => <i key={j} style={{ background: kindColor(x.kind) }} />)}</span>}
          </button>
        )
      })}
    </div>
  )
}

/**
 * NASLEDNJA DVA TEDNA (16. 10., Blažev brat: »da lahko pogledaš 2 tedna naprej, kaj boš imel na treningu«): 14 dni od
 * danes v enem seznamu po tednih — vadba, trajanje, kardio po moči, vaje ali cona. Teden, ki še ni sestavljen, je
 * okviren (izračunan sproti iz dogovora, shrani se, ko pride na vrsto). Tap na dan odpre ta dan v tednu.
 */
const vaj = (n: number) => `${n} ${n === 1 ? 'vaja' : n === 2 ? 'vaji' : n <= 4 ? 'vaje' : 'vaj'}`
const hasDur = (t: string) => /\d\s?(min|h)\b/.test(t)
export function Ahead({ items, preview, today, onPick }: { items: readonly PlanDay[]; preview: ReadonlySet<string>; today: string; onPick: (d: string) => void }) {
  const days = Array.from({ length: 14 }, (_, i) => addDays(today, i))
  const ws0 = weekStartIso(today)
  const groups: { key: string; label: string; days: string[] }[] = []
  for (const d of days) {
    const w = weekStartIso(d)
    const label = w === ws0 ? 'Ta teden' : w === addDays(ws0, 7) ? 'Naslednji teden' : 'Čez dva tedna'
    const g = groups.find(x => x.key === w)
    if (g) g.days.push(d); else groups.push({ key: w, label, days: [d] })
  }
  const tomorrow = addDays(today, 1)
  return (
    <div className="ahead">
      {groups.map((g, gi) => {
        const act = items.filter(x => g.days.includes(x.date) && x.kind !== 'pocitek' && !x.optional)
        const total = act.reduce((t, x) => t + x.durationMin + (x.tail?.durationMin || 0), 0)
        const rough = g.days.some(d => preview.has(d))
        return (
          <section key={g.key} className="ah-wk" style={{ ['--i' as string]: gi }}>
            <div className="ah-h">
              <b>{g.label}</b>
              <span>{dm(g.days[0]!)} – {dm(g.days[g.days.length - 1]!)} · {act.length ? `${act.length} ${act.length === 1 ? 'vadba' : act.length === 2 ? 'vadbi' : act.length <= 4 ? 'vadbe' : 'vadb'} · ${fmtDur(total)}` : 'brez vadb'}{rough ? ' · okvirno' : ''}</span>
            </div>
            <ol className="ah-list">
              {g.days.map((d, di) => {
                const list = items.filter(x => x.date === d && x.kind !== 'pocitek').sort((a, b) => Number(!!a.optional) - Number(!!b.optional))
                const main = list.find(x => !x.optional) ?? list[0]
                const dow = (new Date(`${d}T12:00:00`).getDay() + 6) % 7
                const name = d === today ? 'Danes' : d === tomorrow ? 'Jutri' : DAYS_SL[dow]!.charAt(0).toUpperCase() + DAYS_SL[dow]!.slice(1)
                const label = `${name} ${dm(d)}: ${list.length ? list.map(x => x.title).join(' + ') : 'počitek'}`
                const body = (<>
                  <span className="ah-date"><b>{name}</b><small>{dm(d)}</small></span>
                  <span className="ah-ico" aria-hidden="true">{main ? (main.done ? <IcoCheck width={15} height={15} /> : <KindIcon kind={main.kind} size={16} />) : <i />}</span>
                  <span className="ah-txt">
                    {list.length ? list.map(x => (
                      <span key={x.id} className={x.optional ? 'opt' : ''}>
                        <b>{x.title}</b>
                        <small>{[hasDur(x.title) ? '' : fmtDur(x.durationMin), x.tail ? `nato ${x.tail.title.replace(/ — /, ': ').toLowerCase()}${hasDur(x.tail.title) ? '' : ` ${fmtDur(x.tail.durationMin)}`}` : '', x.exercises?.length ? vaj(x.exercises.length) : x.zone || '', x.optional ? 'po želji' : '', x.done ? 'opravljeno' : ''].filter(Boolean).join(' · ')}</small>
                      </span>
                    )) : <span><b className="rest">Počitek</b></span>}
                  </span>
                </>)
                const cls = `ah-day${d === today ? ' today' : ''}${main ? '' : ' rest'}${main?.done ? ' done' : ''}`
                const style = { ['--c' as string]: main ? kindColor(main.kind) : 'var(--t-poc)', ['--j' as string]: di }
                return (
                  <li key={d}>
                    {preview.has(d)
                      ? <div className={`${cls} rough`} style={style} aria-label={`${label} (okvirno)`}>{body}</div>
                      : <button type="button" className={cls} style={style} onClick={() => onPick(d)} aria-label={label}>{body}<span className="ah-go" aria-hidden="true">›</span></button>}
                  </li>
                )
              })}
            </ol>
          </section>
        )
      })}
      {preview.size > 0 && <p className="muted ah-note">Okvirno: teden, ki še ni sestavljen, je izračunan iz tvojega dogovora. Dokončno ga sestavim, ko pride na vrsto — po tem, kar boš opravil, in po počutju.</p>}
    </div>
  )
}

/** Napredek tedna v eni vrstici z barvnim trakom. */
export function WeekProgress({ items, activities }: { items: readonly PlanDay[]; activities: readonly Activity[] }) {
  const active = items.filter(d => d.kind !== 'pocitek' && !d.optional)
  if (!active.length) return null
  const done = active.filter(d => d.done)
  const minAll = active.reduce((t, d) => t + d.durationMin, 0)
  const minDone = done.reduce((t, d) => { const a = d.done?.activityId ? activities.find(x => x.id === d.done!.activityId) : null; return t + (a?.durationMin ? Math.round(a.durationMin) : d.durationMin) }, 0)
  const pc = minAll ? Math.min(100, Math.round((minDone / minAll) * 100)) : 0
  return (
    <div className="pl-prog" role="group" aria-label={`Opravljeno ${done.length} od ${active.length} treningov, ${fmtDur(minDone)} od ${fmtDur(minAll)}`}>
      <span className="pl-prog-bar" aria-hidden="true"><i style={{ width: `${Math.max(pc, minDone ? 4 : 0)}%` }} /></span>
      <span className="pl-prog-tx" aria-hidden="true"><b>{done.length}/{active.length}</b> treningov · {minDone ? fmtDur(minDone) : '0 min'} od {fmtDur(minAll)}</span>
    </div>
  )
}

/* ---------- obzorje: načrt po meri (bloki) ---------- */
interface HzWeek { ws: string; cx: WeekCtx; moc: number; kolo: number; tek: number; n: number }
function customWeeks(p: Profile, from: string, n: number): HzWeek[] {
  const f = p.focus
  if (!f) return []
  return Array.from({ length: n }, (_, i) => {
    const ws = addDays(from, 7 * i)
    const cx = weekContext(p, ws)
    let moc = 0, kolo = 0, tek = 0
    for (const s of f.sessions) {
      if (isStrength(s)) moc += Math.round(s.min * (cx.recovery ? 0.85 : 1))
      else if (s.type === 'kolo') kolo += Math.round(s.min * cx.volume)
      else tek += Math.round(s.min * cx.volume)
    }
    return { ws, cx, moc, kolo, tek, n: f.sessions.filter(isStrength).length }
  })
}

export function Horizon({ profile, today, onWeek }: { profile: Profile; today: string; onWeek?: (ws: string) => void }) {
  const ws0 = weekStartIso(today)
  const goals = seasonGoals(profile).filter(g => g.date >= today)
  // do cilja (če ga ima in je v 40 tednih), sicer 12 tednov = trije bloki
  const toGoal = goals[0] ? Math.ceil((new Date(weekStartIso(goals[0].date)).getTime() - new Date(ws0).getTime()) / (7 * 86400_000)) + 1 : 0
  const n = toGoal >= 4 && toGoal <= 40 ? toGoal : 12
  const weeks = useMemo(() => customWeeks(profile, ws0, n), [profile, ws0, n])
  const [sel, setSel] = useState(0)
  if (!weeks.length) return null
  const tot = (w: HzWeek) => w.moc + w.kolo + w.tek
  const max = Math.max(1, ...weeks.map(tot))
  const goalWeek = new Map(goals.map(g => [weekStartIso(g.date), g.name] as const))
  const w = weeks[sel]!
  const own = profile.focus?.block
  return (
    <section className="pl-hz card" aria-label="Načrt za naslednje tedne">
      <div className="between"><b className="pl-hz-h">Naslednji tedni</b><span className="pl-hz-sub">{own ? `obseg po trenerju: ${own.map(v => `${Math.round(v * 100)} %`).join(' · ')}` : 'bloki po 4 tedne · 4. lažji'}</span></div>
      <div className="pl-bars" role="group" aria-label="Tedni">
        {weeks.map((x, i) => {
          const t = tot(x)
          return (
            <button key={x.ws} type="button" className={`pl-bar${i === sel ? ' sel' : ''}${x.cx.recovery ? ' easy' : ''}${goalWeek.has(x.ws) ? ' goal' : ''}`} style={{ ['--i' as string]: i, height: `${Math.max(14, Math.round((t / max) * 100))}%` }}
              onClick={() => { setSel(i); onWeek?.(x.ws) }} aria-label={`Teden od ${dm(x.ws)}: ${fmtDur(t)}${x.cx.recovery ? ', lažji teden' : ''}`} aria-pressed={i === sel}>
              {x.kolo > 0 && <i style={{ flex: x.kolo, background: 'var(--t-kolo)' }} />}
              {x.tek > 0 && <i style={{ flex: x.tek, background: 'var(--t-tek)' }} />}
              {x.moc > 0 && <i style={{ flex: x.moc, background: 'var(--t-moc)' }} />}
              {i === 0 && <span className="pl-now">zdaj</span>}
            </button>
          )
        })}
      </div>
      <div className="pl-axis" aria-hidden="true">{weeks.map((x, i) => <span key={x.ws}>{i % 4 === 0 ? dm(x.ws) : ''}</span>)}</div>
      <p className="pl-hz-info"><b>{sel === 0 ? 'Ta teden' : sel === 1 ? 'Naslednji teden' : `Teden od ${dm(w.ws)}`}</b> · {fmtDur(tot(w))}{w.moc ? ` · moč ${w.n}×` : ''}{w.kolo ? ` · kolo ${fmtDur(w.kolo)}` : ''}{w.tek ? ` · tek/hribi ${fmtDur(w.tek)}` : ''}{w.cx.recovery ? ' · lažji teden' : ` · ${Math.round(w.cx.volume * 100)} % obsega`}{goalWeek.has(w.ws) ? ` · cilj: ${goalWeek.get(w.ws)}` : ''}</p>
      <div className="pl-legend" aria-hidden="true">
        {weeks.some(x => x.kolo) && <span><i style={{ background: 'var(--t-kolo)' }} />kolo</span>}
        {weeks.some(x => x.tek) && <span><i style={{ background: 'var(--t-tek)' }} />tek, hribi</span>}
        {weeks.some(x => x.moc) && <span><i style={{ background: 'var(--t-moc)' }} />moč</span>}
      </div>
    </section>
  )
}

/* ---------- sezona: kolesarski makrocikel do cilja ---------- */
const PH_COLOR: Record<PhaseKey, string> = { prehod: 'var(--t-poc)', osnova: 'var(--t-kolo)', gradnja: 'var(--warn)', specificno: 'var(--t-moc)', tapering: 'var(--ok)', dirka: 'var(--accent)', po: 'var(--t-poc)' }
export function SeasonChart({ macro, profile, start }: { macro: readonly (WeekCtx & { weekStart: string })[]; profile: Profile; start: string }) {
  const goals = seasonGoals(profile)
  const goalWeek = new Map(goals.map(g => [weekStartIso(g.date), g.name] as const))
  const raceWeek = new Map<string, string[]>()
  for (const r of profile.races || []) { if (r.prio === 'A') continue; const k = weekStartIso(r.date); raceWeek.set(k, [...(raceWeek.get(k) || []), r.name]) }
  const cur = Math.max(0, macro.findIndex(w => w.weekStart === start))
  const [sel, setSel] = useState(cur)
  if (!macro.length) return null
  const max = Math.max(1, ...macro.map(w => w.hours))
  const w = macro[Math.min(sel, macro.length - 1)]!
  const months: { at: number; label: string }[] = []
  macro.forEach((x, i) => { const m = +x.weekStart.slice(5, 7); if (i === 0 || m !== +macro[i - 1]!.weekStart.slice(5, 7)) months.push({ at: i, label: MONTHS_SL[m - 1]!.slice(0, 3) }) })
  const phases = (['prehod', 'osnova', 'gradnja', 'specificno', 'tapering'] as PhaseKey[]).filter(k => macro.some(x => x.phase === k))
  return (
    <section className="pl-hz pl-season card" aria-label="Sezona po tednih">
      <div className="between"><b className="pl-hz-h">Sezona po tednih</b><span className="pl-hz-sub">{goals[0] ? `${goals[0].name} · ${dm(goals[0].date)}` : ''}</span></div>
      <div className="pl-bars tall" role="group" aria-label="Tedni sezone">
        {macro.map((x, i) => (
          <button key={x.weekStart} type="button" className={`pl-bar${i === sel ? ' sel' : ''}${x.recovery || x.easy ? ' easy' : ''}${goalWeek.has(x.weekStart) ? ' goal' : ''}${x.weekStart < start ? ' past' : ''}`}
            style={{ ['--i' as string]: i, height: goalWeek.has(x.weekStart) ? '100%' : `${Math.max(10, Math.round((x.hours / max) * 100))}%` }} onClick={() => setSel(i)}
            aria-label={`Teden od ${dm(x.weekStart)}: ${x.phaseName}, ${num(x.hours)} h${goalWeek.has(x.weekStart) ? `, cilj ${goalWeek.get(x.weekStart)}` : ''}`} aria-pressed={i === sel}>
            <i style={{ flex: 1, background: goalWeek.has(x.weekStart) ? 'var(--accent)' : PH_COLOR[x.phase] }} />
            {raceWeek.has(x.weekStart) && <span className="pl-flag b" aria-hidden="true" />}
            {goalWeek.has(x.weekStart) && <span className="pl-flag" aria-hidden="true" />}
            {i === cur && <span className="pl-now">zdaj</span>}
          </button>
        ))}
      </div>
      <div className="pl-months" aria-hidden="true">{months.map(m => <span key={m.at} style={{ left: `${(m.at / macro.length) * 100}%` }}>{m.label}</span>)}</div>
      <p className="pl-hz-info"><b>{sel === cur ? 'Ta teden' : `Teden od ${dm(w.weekStart)}`}</b> · {w.phaseName.toLowerCase()} · {num(w.hours)} h{w.recovery && w.phase !== 'prehod' ? ' · razbremenilni' : ''}{w.test ? ' · test FTP' : ''}{goalWeek.has(w.weekStart) ? ` · CILJ: ${goalWeek.get(w.weekStart)}` : ''}{raceWeek.has(w.weekStart) ? ` · tekma: ${raceWeek.get(w.weekStart)!.join(', ')}` : ''}</p>
      <div className="pl-legend" aria-hidden="true">
        {phases.map(k => <span key={k}><i style={{ background: PH_COLOR[k] }} />{macro.find(x => x.phase === k)!.phaseName.toLowerCase()}</span>)}
        <span><i style={{ background: 'var(--accent)' }} />cilj</span>
      </div>
    </section>
  )
}
