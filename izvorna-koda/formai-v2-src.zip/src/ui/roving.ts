import type { KeyboardEvent } from 'react'

/**
 * (v3.50) »Roving tabindex« za trak gumbov (teden na Danes): Tab ustavi samo na izbranem gumbu, puščice ← → (in
 * Home/End) premikajo med ostalimi — prej je bil trak 7 postankov Tab. Gumbi so neposredni otroci skupine.
 */
export function rovingTab(i: number, current: number): { tabIndex: 0 | -1 } {
  return { tabIndex: i === current ? 0 : -1 }
}
const KEYS: Record<string, (i: number, n: number) => number> = {
  ArrowRight: (i, n) => (i + 1) % n, ArrowDown: (i, n) => (i + 1) % n,
  ArrowLeft: (i, n) => (i - 1 + n) % n, ArrowUp: (i, n) => (i - 1 + n) % n,
  Home: () => 0, End: (_i, n) => n - 1,
}
/** onKeyDown na skupini: fokus na sosednji gumb (in ta postane postanek Tab). */
export function rovingKey(e: KeyboardEvent<HTMLElement>): void {
  const go = KEYS[e.key]
  if (!go) return
  const items = Array.from(e.currentTarget.children).filter((x): x is HTMLElement => x instanceof HTMLElement && x.matches('button:not(:disabled)'))
  const i = items.indexOf(e.target as HTMLElement)
  if (i < 0 || !items.length) return
  e.preventDefault()
  const next = items[go(i, items.length)]!
  for (const x of items) x.tabIndex = x === next ? 0 : -1
  next.focus()
}
