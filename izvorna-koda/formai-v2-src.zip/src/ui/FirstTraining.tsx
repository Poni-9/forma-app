import { navigate } from '@/app/router'
import type { PlanDay } from '@/domain/types'
import { addDays, fmtDur } from '@/domain/training/load'
import { baseTitle } from '@/ui/SessBits'
import { dayAcc, dayName, dm, NBSP } from '@/ui/format'
import { rem } from '@/ui/rem'

/**
 * (v3.49) Prvi dan je počitek: Danes pove, kdaj je prvi trening (tap odpre ta dan v Planu) — prej samo »Dan brez treninga«,
 * »Bolan sem« in »Jutri · Počitek«, prvega treninga ni bilo nikjer. Jutrišnji trening je že na kartici »Jutri«.
 */
export function FirstTraining({ day, today }: { day: PlanDay; today: string }) {
  const tomorrow = day.date === addDays(today, 1)
  const when = `${dayName(day.date)}, ${dm(day.date)}`
  return (<>
    <p style={{ fontSize: rem(13), marginTop: 6 }}>Danes si odpočij — začneva {tomorrow ? 'jutri' : `v ${dayAcc(day.date)}`}.</p>
    {!tomorrow && (
      <button type="button" className="first-train" onClick={() => navigate('plan', { dan: day.date })} aria-label={`Prvi trening: ${when}, ${baseTitle(day)}${day.durationMin ? `, ${fmtDur(day.durationMin)}` : ''} — odpri Plan`}>
        <span><small>Prvi trening · {when}</small><b>{baseTitle(day)}{day.durationMin ? <span className="muted"> · {fmtDur(day.durationMin).replace(/ /g, NBSP)}</span> : null}</b></span>
        <span className="muted" aria-hidden="true">›</span>
      </button>
    )}
  </>)
}
