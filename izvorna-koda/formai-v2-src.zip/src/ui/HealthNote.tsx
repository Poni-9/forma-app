import type { CSSProperties, ReactNode } from 'react'
import { IcoInfo } from './icons'

/**
 * Zdravstveno opozorilo — kratko, umirjeno, povsod enako. Mora biti ob vsakem cilju kalorij in ob načrtu treninga
 * (besedilo iz obstoječih opozoril v aplikaciji). Na enem zaslonu samo enkrat: kjer sta oba, uporabi `both`.
 */
export const HEALTH_TEXT = {
  plan: 'Plan je trenerska usmeritev, ne zdravniški nasvet. Ob bolečini, bolezni ali zdravstvenih težavah se posvetuj z zdravnikom.',
  food: 'Kalorije so ocena in prehranska usmeritev, ne zdravniški nasvet. Ob bolezni, poškodbi ali motnjah hranjenja se posvetuj z zdravnikom.',
  both: 'Plan in kalorije so usmeritev, ne zdravniški nasvet. Ob bolečini, bolezni, poškodbi ali motnjah hranjenja se posvetuj z zdravnikom.',
} as const

export function HealthNote({ kind = 'plan', children, center, style }: { kind?: keyof typeof HEALTH_TEXT; children?: ReactNode; center?: boolean; style?: CSSProperties }) {
  return (
    <p className="muted health-note" role="note" style={{ display: 'flex', gap: 6, alignItems: 'flex-start', justifyContent: center ? 'center' : undefined, textAlign: center ? 'center' : undefined, fontSize: 11.5, lineHeight: 1.45, marginTop: 10, ...style }}>
      <IcoInfo width={13} height={13} aria-hidden="true" style={{ flex: 'none', marginTop: 2 }} />
      <span>{children ?? HEALTH_TEXT[kind]}</span>
    </p>
  )
}
