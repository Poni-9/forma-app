import { useState } from 'react'
import { useApp, type PlanChange } from '@/state/store'
import { Card, Sheet, Btn } from '@/ui/primitives'
import { addDays } from '@/domain/training/load'

/** »danes 8:12«, »včeraj 19:40«, »3. 10.« */
export function whenOf(at: string, today: string): string {
  const d = new Date(at)
  if (Number.isNaN(d.getTime())) return ''
  const iso = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
  const hm = `${d.getHours()}:${String(d.getMinutes()).padStart(2, '0')}`
  return iso === today ? `danes ${hm}` : iso === addDays(today, -1) ? `včeraj ${hm}` : `${d.getDate()}. ${d.getMonth() + 1}.`
}
/** Sprememba v zadnjih dveh dneh (za vrstico nad dnevi v Planu). */
export function freshChange(list: readonly PlanChange[], today: string): PlanChange | null {
  const x = list[0]
  if (!x) return null
  return x.at.slice(0, 10) >= addDays(today, -2) ? x : null
}

/**
 * SPREMEMBE NAČRTA — kaj je aplikacija spremenila in zakaj (uporabnik: »težko razumeti, kaj se dogaja«).
 * compact: samo zadnja (če je sveža) v eni kartici nad dnevi; sicer zadnjih 5 in »vse«.
 */
export function ChangesCard({ compact = false, skipFresh = false }: { compact?: boolean; skipFresh?: boolean }) {
  const app = useApp()
  const [all, setAll] = useState(false)
  const list = app.changes
  const fresh = freshChange(list, app.today)
  // pod dnevi brez tiste, ki je že zgoraj (»Zadnja sprememba načrta«)
  const from = skipFresh && fresh ? 1 : 0
  const shown = compact ? (fresh ? [fresh] : []) : list.slice(from, from + 5)
  if (!shown.length) return null
  return (<>
    <Card tight className="changes-card" style={{ marginBottom: 12 }}>
      <div className="between" style={{ gap: 8 }}>
        <h2 className="h4" style={{ fontSize: 11, margin: 0 }}>{compact ? 'Zadnja sprememba načrta' : from ? 'Prejšnje spremembe načrta' : 'Spremembe načrta'}</h2>
        {list.length > shown.length && <button type="button" className="chip sm click" onClick={() => setAll(true)}>vse ({list.length})</button>}
      </div>
      <ul className="chg-list">
        {shown.map((c, i) => <li key={i}><span className="when">{whenOf(c.at, app.today)}{c.auto ? '' : ' · ti'}</span><span className={compact ? 'clamp2' : undefined}>{c.text}</span></li>)}
      </ul>
    </Card>
    {all && (
      <Sheet open onClose={() => setAll(false)} label="Spremembe načrta">
        <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Spremembe načrta</b>
        <p className="muted" style={{ fontSize: 12, marginTop: 4 }}>Kaj se je spremenilo in zakaj — od najnovejše. »ti« = sprememba po tvojem kliku; ostalo je naredila aplikacija sama (jutranji vnos, izpuščen trening, ura, nov teden).</p>
        <ul className="chg-list" style={{ marginTop: 10 }}>
          {list.map((c, i) => <li key={i}><span className="when">{whenOf(c.at, app.today)}{c.auto ? '' : ' · ti'}</span><span>{c.text}</span></li>)}
        </ul>
        <Btn ghost block style={{ marginTop: 12 }} onClick={() => setAll(false)}>Zapri</Btn>
      </Sheet>
    )}
  </>)
}
