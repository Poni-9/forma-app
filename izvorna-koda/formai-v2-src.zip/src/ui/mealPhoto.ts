/**
 * »Slikaj obrok« z Danes: kamera se odpre že na Danes (dotik uporabnika — brskalniki drugače ne dovolijo),
 * slika počaka tukaj, Prehrana jo ob odprtju prevzame in prebere.
 */
let queued: File | null = null

export function queueMealPhoto(f: File): void { queued = f }
export function takeMealPhoto(): File | null { const f = queued; queued = null; return f }
