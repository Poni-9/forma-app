import { useApp, updatePlanDays } from '@/state/store'
import { addDays, fmtDur, weekStartIso } from '@/domain/training/load'
import { moveTargets, swapDays } from '@/domain/training/swap'
import { raceLock } from '@/domain/training/protect'
import type { PlanDay } from '@/domain/types'
import { Sheet, KindIcon, kindColor } from '@/ui/primitives'
import { undoToast } from '@/ui/Confirm'
import { dayName, dm, dayAcc, NBSP } from '@/ui/format'

/**
 * »Premakni na drug dan«: seznam dni od danes do konca naslednjega tedna; tap zamenja vsebino obeh dni
 * (trening gre tja, kar je bilo tam, pride sem). Razveljavi v obvestilu.
 */
export function MoveDaySheet({ day, onClose }: { day: PlanDay; onClose: () => void }) {
  const app = useApp()
  const until = addDays(weekStartIso(app.today), 13)
  const lock = raceLock(app.plan, app.profile)
  const targets = moveTargets(app.plan, day, app.today, until, lock)
  // dnevi ob tekmi, ki jih ni na seznamu — da ne izgleda, kot da manjkajo po pomoti
  const locked = [...new Set(app.plan.filter(d => d.date >= app.today && d.date <= until && d.date !== day.date && lock.has(d.date)).map(d => d.date))].sort()
  async function move(partner: PlanDay) {
    const before = [day, partner]
    const [a, b] = swapDays(day, partner)
    await updatePlanDays([a, b])
    onClose()
    undoToast(`${day.title} je premaknjen na ${dayAcc(partner.date)}${partner.kind === 'pocitek' ? `; ${dayName(day.date)} je zdaj počitek.` : ` — ${partner.title} gre na ${dayAcc(day.date)}.`}`, () => updatePlanDays(before), { ms: 7000 })
  }
  return (
    <Sheet open onClose={onClose} label="Premakni trening">
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Premakni {day.title}</b>
      <p style={{ fontSize: 13, marginTop: 4 }}>Izberi dan. Kar je tam, pride na {dayAcc(day.date)}. Na uro gre spremenjeni teden sam.</p>
      <div className="stack" style={{ gap: 8, marginTop: 14 }}>
        {targets.length === 0 && <p className="muted" style={{ fontSize: 13 }}>Ni prostega dne do konca naslednjega tedna.</p>}
        {locked.length > 0 && <p className="muted" style={{ fontSize: 12, order: 99 }}>Ni na izbiro: {locked.map(d => `${dayName(d).slice(0, 3)} ${dm(d)} (${lock.why(d)})`).join(' · ')} — svežina za tekmo je pomembnejša.</p>}
        {targets.map(({ date, partner }) => (
          <button key={date} type="button" className="card tight row" style={{ gap: 12, width: '100%', textAlign: 'left', cursor: 'pointer', padding: '10px 12px' }} onClick={() => void move(partner)}>
            <span style={{ width: 54, flex: 'none' }}><b style={{ display: 'block', fontSize: 13 }}>{dayName(date).slice(0, 3)}</b><span className="muted" style={{ fontSize: 11.5, fontWeight: 600 }}>{dm(date)}</span></span>
            <span style={{ width: 28, height: 28, borderRadius: 9, display: 'grid', placeItems: 'center', flex: 'none', color: partner.kind === 'pocitek' ? 'var(--ink-3)' : kindColor(partner.kind), background: 'rgba(255,255,255,.06)' }}><KindIcon kind={partner.kind} size={15} /></span>
            <span style={{ flex: 1, minWidth: 0 }}>
              <b style={{ display: 'block', fontSize: 13.5, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', color: partner.kind === 'pocitek' ? 'var(--ink-2)' : 'var(--ink)' }}>{partner.kind === 'pocitek' ? 'Počitek' : partner.title}</b>
              <span className="muted" style={{ fontSize: 12 }}>{partner.kind === 'pocitek' ? `→ ${day.title} pride sem` : `${fmtDur(partner.durationMin)}${partner.tssTarget ? ` · ${partner.tssTarget}${NBSP}TSS` : ''} → zamenjata se`}</span>
            </span>
          </button>
        ))}
      </div>
      <button type="button" className="btn ghost block sm" style={{ marginTop: 12 }} onClick={onClose}>Prekliči</button>
    </Sheet>
  )
}
