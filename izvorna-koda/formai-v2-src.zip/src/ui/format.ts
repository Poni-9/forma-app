/* Slovenski zapis števil, enot, datumov in množine — en vir za vse zaslone. */

/** nedeljivi presledek: med številom in enoto ali znakom % */
export const NBSP = ' '
/** ozki nedeljivi presledek: tisočice (1 840) */
export const NNBSP = ' '
/** pravi minus (ne vezaj) */
export const MINUS = '−'

export type Forms = readonly [string, string, string, string]

/**
 * Slovenska množina po številu: oblike za 1, 2, 3–4 in 5+ (ter 0). Šteje zadnji dve mesti:
 * 101 kot 1, 102 kot 2, 103 kot 3, 111 kot 5+. plural(3, ['teden', 'tedna', 'tedni', 'tednov']) → 'tedni'.
 */
export function plural(n: number, forms: Forms): string {
  const k = Math.abs(Math.trunc(n)) % 100
  return k === 1 ? forms[0] : k === 2 ? forms[1] : k === 3 || k === 4 ? forms[2] : forms[3]
}

/** Število in samostalnik skupaj, brez preloma vmes: count(4, W.vaja) → »4 vaje«. */
export function count(n: number, forms: Forms): string {
  return `${n}${NBSP}${plural(n, forms)}`
}

/** Pogoste oblike. Imenovalnik: 1 teden · 2 tedna · 3 tedni · 5 tednov; tožilnik (čez …, za …) posebej. */
export const W = {
  teden: ['teden', 'tedna', 'tedni', 'tednov'],
  /** tožilnik: čez 3 tedne, za 4 tedne */
  tedenT: ['teden', 'tedna', 'tedne', 'tednov'],
  dan: ['dan', 'dneva', 'dnevi', 'dni'],
  /** tožilnik: čez 3 dni */
  danT: ['dan', 'dneva', 'dni', 'dni'],
  vaja: ['vaja', 'vaji', 'vaje', 'vaj'],
  vadba: ['vadba', 'vadbi', 'vadbe', 'vadb'],
  aktivnost: ['aktivnost', 'aktivnosti', 'aktivnosti', 'aktivnosti'],
  trening: ['trening', 'treninga', 'treningi', 'treningov'],
  /** rodilnik: brez 1 treninga, do 2 treningov */
  treningR: ['treninga', 'treningov', 'treningov', 'treningov'],
  voznja: ['vožnja', 'vožnji', 'vožnje', 'voženj'],
  korak: ['korak', 'koraka', 'koraki', 'korakov'],
  cilj: ['cilj', 'cilja', 'cilji', 'ciljev'],
  tekma: ['tekma', 'tekmi', 'tekme', 'tekem'],
  /** rodilnik: do 1 dejanja, do 10 dejanj */
  dejanjeR: ['dejanja', 'dejanj', 'dejanj', 'dejanj'],
  zapis: ['zapis', 'zapisa', 'zapisi', 'zapisov'],
  obrok: ['obrok', 'obroka', 'obroki', 'obrokov'],
} as const satisfies Record<string, Forms>

/** Tisočice z ozkim nedeljivim presledkom (»1 840«, »12 500«), minus kot »−«. */
export function int(n: number): string {
  if (!Number.isFinite(n)) return '—'
  const v = Math.round(n), s = String(Math.abs(v))
  let out = ''
  for (let i = 0; i < s.length; i++) { if (i > 0 && (s.length - i) % 3 === 0) out += NNBSP; out += s[i] }
  return (v < 0 ? MINUS : '') + out
}

/** Fiksno število decimalk z vejico: dec(72.46) → »72,5«, dec(-0.5, 2) → »−0,50«; −0 je »0«. */
export function dec(x: number, digits = 1): string {
  if (!Number.isFinite(x)) return '—'
  const s = Math.abs(x).toFixed(digits)
  return (x < 0 && Number(s) !== 0 ? MINUS : '') + s.replace('.', ',')
}

/** Do `max` decimalk brez odvečnih ničel: num(72) → »72«, num(72.25) → »72,3«, num(1840.5, 0) → »1 841«. */
export function num(x: number, max = 1): string {
  if (!Number.isFinite(x)) return '—'
  const f = 10 ** max, r = Math.round(x * f) / f
  const [i, frac] = String(Math.abs(r)).split('.') as [string, string | undefined]
  return (r < 0 ? MINUS : '') + int(+i) + (frac ? ',' + frac : '')
}

/** S predznakom: signed(0.5, 2) → »+0,50«, signed(-0.5, 2) → »−0,50«, signed(0) → »0,0«. */
export function signed(x: number, digits = 1): string {
  const s = dec(x, digits)
  return x > 0 && Number(Math.abs(x).toFixed(digits)) !== 0 ? '+' + s : s
}

/** Vrednost z enoto, brez preloma vmes: unit('72,5', 'kg') → »72,5 kg«. */
export function unit(v: string | number, u: string): string {
  return `${typeof v === 'number' ? num(v) : v}${NBSP}${u}`
}
export const kcal = (n: number): string => unit(int(n), 'kcal')
export const kg = (x: number, max = 1): string => unit(num(x, max), 'kg')
export const pct = (x: number): string => unit(Math.round(x), '%')

/* ---------- datumi ---------- */
const parts = (iso: string) => iso.slice(0, 10).split('-').map(Number) as [number, number, number]
const DOW_NOM = ['nedelja', 'ponedeljek', 'torek', 'sreda', 'četrtek', 'petek', 'sobota']
const DOW_ACC = ['nedeljo', 'ponedeljek', 'torek', 'sredo', 'četrtek', 'petek', 'soboto']
const dow = (iso: string) => { const [y, m, d] = parts(iso); return new Date(y, m - 1, d).getDay() }

/** »22. 9.« — dan in mesec brez vodilnih ničel (nedeljivi presledek vmes). */
export function dm(iso: string): string {
  const [, m, d] = parts(iso)
  return m && d ? `${d}.${NBSP}${m}.` : iso
}
/** »22. 9.« letos, sicer »22. 9. 2027«. */
export function dmy(iso: string, today: string = localToday()): string {
  const y = iso.slice(0, 4)
  return y === today.slice(0, 4) ? dm(iso) : `${dm(iso)}${NBSP}${y}`
}
/** Ime dneva v imenovalniku (»sreda«) — za »Naslednji: sreda, 24. 9.«. */
export function dayName(iso: string): string { return DOW_NOM[dow(iso)]! }
/** Ime dneva v tožilniku (»sredo«) — za »prestavljeno na sredo«. */
export function dayAcc(iso: string): string { return DOW_ACC[dow(iso)]! }
/** Ura »14:05« iz časovnega žiga (ms). */
export function hhmmOf(ms: number): string {
  const d = new Date(ms)
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}
function localToday(): string {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}

/**
 * Celica za CSV (ločilo ;): v narekovajih, narekovaji podvojeni. Besedilo, ki se začne z = + - @ (ali tabulatorjem, CR),
 * dobi spredaj ' — preglednica ga ne izvede kot formulo (CSV injection). Čista števila ostanejo števila.
 */
export function csvCell(x: unknown): string {
  let s = String(x ?? '')
  if (/^[=+\-@\t\r]/.test(s) && !/^-?\d+(?:[.,]\d+)?$/.test(s)) s = "'" + s
  return `"${s.replace(/"/g, '""')}"`
}

/**
 * Besedilo iz domene (npr. »zelenjava 270 g«, »3 × 12 min«): med številom in enoto nedeljivi presledek,
 * da se enota ne prelomi v novo vrstico; razpon (»40–45 g«) se ne prelomi za pomišljajem.
 */
export function nb(text: string): string {
  return text
    .replace(/(\d) (?=(?:g|kg|ml|dl|l|kcal|min|h|s|km|m|W|bpm|%)(?![\p{L}\d]))/gu, `$1${NBSP}`)
    .replace(/(\d)–(?=\d)/g, '$1–⁠')
}
