import { ExerciseFigure } from '@/ui/figure/ExerciseFigure'
import type { FigSpec } from '@/domain/focus/tips'

/**
 * ODER ZA FIGURO (Blaž, 14. 10.: »hude animacije, zdaj naredi, da bodo izgledale boljše — vidi se, da je na hitro
 * narejeno«). Figura ni več sama na prazni podlagi: dobi oder z mehkim sijem v barvi športa (kolo modro, tek
 * rožnato, moč oranžno, hoja zeleno), pri kardiu cesto, ki teče pod njo, in sapo vetra (gibanje naprej), pri moči
 * reflektor od zgoraj in sij na tleh. Oznaka športa je v čipu, menjava figure je mehak prelivni prehod.
 * Zmanjšano gibanje: oder miruje (brez teka ceste, vetra in sija), figura stoji v srednji pozi.
 */
const SPORT_C: Record<string, string> = { kolo: 'var(--t-kolo)', tek: 'var(--t-tek)', hoja: '#2f9e6a', moc: 'var(--t-moc)' }
const figKind = (f: FigSpec): 'kolo' | 'tek' | 'hoja' | 'moc' => (f.id ? 'moc' : f.fallback === 'kolo' ? 'kolo' : f.fallback === 'hoja' ? 'hoja' : 'tek')

export function FigStage({ fig, size = 150, chip, clock, className }: { fig: FigSpec; size?: number; chip?: React.ReactNode; clock?: string; className?: string }) {
  const kind = figKind(fig)
  const moving = kind !== 'moc'
  return (
    <div className={`fstage ${moving ? 'go' : 'gym'} k-${kind}${className ? ` ${className}` : ''}`} style={{ ['--sc' as string]: SPORT_C[kind], ['--fs' as string]: `${size}px` }} aria-hidden="true">
      <i className="fs-aura a" />
      <i className="fs-aura b" />
      {moving ? (
        <>
          <span className="fs-wind"><i /><i /><i /><i /></span>
          <span className="fs-lane"><i /></span>
        </>
      ) : (
        <>
          <span className="fs-spot" />
          <span className="fs-floor" />
        </>
      )}
      <span className="fs-fig" key={`${fig.id ?? ''}:${fig.fallback ?? ''}:${fig.label}`}>
        <ExerciseFigure id={fig.id ?? null} fallback={fig.fallback ?? 'pavza'} size={size} label={fig.label} />
      </span>
      {chip ? <span className="fs-chip"><i />{chip}</span> : null}
      {clock ? <span className="fs-clock">{clock}</span> : null}
    </div>
  )
}
