import type L from 'leaflet'
import { cellCenter } from '@/domain/coverage/cells'

/**
 * Pobarvano ozemlje v slogu INTVL: en <canvas> čez celoten zemljevid, na katerega ob vsakem
 * premiku narišemo vse celice kot majhne kvadratke. Pri oddaljevanju se kvadratki zlijejo v
 * osvojeno površino, pri približevanju se vidi mreža ~11 m. Deset tisoč celic se nariše v
 * nekaj milisekundah — brez enega samega Leaflet objekta na celico.
 */
export function createTerritoryLayer(Lf: typeof L, cells: Set<number>, color: string) {
  const Layer = Lf.Layer.extend({
    onAdd(map: L.Map) {
      const c = document.createElement('canvas')
      c.style.position = 'absolute'
      c.style.pointerEvents = 'none'
      c.className = 'leaflet-zoom-animated'
      this._c = c
      this._map = map
      map.getPanes().overlayPane!.appendChild(c)
      map.on('moveend zoomend resize', this._draw, this)
      map.on('zoomanim', this._anim, this)
      this._draw()
      return this
    },
    onRemove(map: L.Map) {
      map.off('moveend zoomend resize', this._draw, this)
      map.off('zoomanim', this._anim, this)
      this._c.remove()
    },
    _anim(e: L.ZoomAnimEvent) {
      // med animacijo približevanja kanvas samo skaliramo; narišemo znova, ko se ustali
      const scale = this._map.getZoomScale(e.zoom), off = this._map._latLngBoundsToNewLayerBounds(this._map.getBounds(), e.zoom, e.center).min
      Lf.DomUtil.setTransform(this._c, off, scale)
    },
    _draw() {
      const map: L.Map = this._map, c: HTMLCanvasElement = this._c
      const size = map.getSize()
      const dpr = Math.min(2, window.devicePixelRatio || 1)
      c.width = size.x * dpr; c.height = size.y * dpr
      c.style.width = size.x + 'px'; c.style.height = size.y + 'px'
      const tl = map.containerPointToLayerPoint([0, 0])
      Lf.DomUtil.setPosition(c, tl)
      const ctx = c.getContext('2d')!
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      ctx.clearRect(0, 0, size.x, size.y)
      const b = map.getBounds().pad(0.1)
      const z = map.getZoom()
      // velikost celice v pikslih: 1e-4° ≈ 11 m; pri majhnem zoomu narišemo večje ploščice, da se površina zlije
      const mPerPx = 40075016 * Math.cos(map.getCenter().lat * Math.PI / 180) / (256 * 2 ** z)
      const px = Math.max(2.2, 11.1 / mPerPx)
      ctx.fillStyle = color
      ctx.globalAlpha = px < 4 ? 0.85 : 0.62
      const glow = cells.size < 25_000 && px >= 4
      if (glow) { ctx.shadowColor = color; ctx.shadowBlur = Math.min(10, px * 0.8) }
      const step = cells.size > 120_000 ? Math.ceil(cells.size / 120_000) : 1
      let i = 0
      for (const k of cells) {
        if (step > 1 && (i++ % step)) continue
        const [la, lo] = cellCenter(k)
        if (la < b.getSouth() || la > b.getNorth() || lo < b.getWest() || lo > b.getEast()) continue
        const p = map.latLngToContainerPoint([la, lo])
        const r = px * 0.22
        const x = p.x - px / 2, y = p.y - px / 2
        ctx.beginPath()
        ctx.roundRect(x, y, px, px, r)
        ctx.fill()
      }
      ctx.shadowBlur = 0
      ctx.globalAlpha = 1
    },
    setCells(next: Set<number>) { cells = next; if (this._map) this._draw() },
  })
  return new (Layer as unknown as new () => L.Layer & { setCells(c: Set<number>): void })()
}
