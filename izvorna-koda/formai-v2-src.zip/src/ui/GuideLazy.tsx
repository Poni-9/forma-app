import { Suspense } from 'react'
import { retryLazy } from '@/app/chunk'
import { ChunkBoundary } from '@/ui/ChunkBoundary'

/**
 * (v3.51) Vodnik »Prvi koraki« (list) ni v začetnem paketu: prenese se ob prvem odprtju. Isti vmesnik kot Guide.
 * (začetni paket je po v3.50 spet zrasel na 785 kB — G08)
 */
const L = retryLazy(() => import('./Guide').then(m => m.Guide))
export function Guide(p: { open: boolean; onClose: () => void }) {
  if (!p.open) return null
  return <ChunkBoundary onClose={p.onClose} label="Prvi koraki"><Suspense fallback={null}><L {...p} /></Suspense></ChunkBoundary>
}
