import { useRef, useState } from 'react'
import { APP_VERSION } from '@/config'
import { toast } from '@/state/store'
import { FB_KINDS, FB_SHOT_MAX, FB_TEXT_MAX, makeFeedback, sendFeedback, type FbKind } from '@/data/feedback'
import { fileToBase64Resized } from '@/domain/ai/image'
import { useDictation } from '@/ui/useDictation'
import { Btn, Chip, Sheet } from '@/ui/primitives'
import { IcoImage, IcoMic } from '@/ui/icons'
import { closeFeedback } from '@/ui/overlays'

/** Imena zaslonov za pripombo (kaj je uporabnik gledal). */
const SCREEN: Record<string, string> = { danes: 'Danes', plan: 'Plan', prehrana: 'Prehrana', trener: 'Trener', napredek: 'Napredek', nastavitve: 'Nastavitve', uvoz: 'Uvoz', aktivnosti: 'Aktivnosti', vadba: 'Vadba', uvod: 'Uvod', prijava: 'Prijava' }

/**
 * Pripomba: vrsta (ni jasno / napaka / predlog), besedilo ali glas, posnetek zaslona (zajet pred odprtjem lista —
 * viden in ga lahko odstraniš ali zamenjaš s sliko iz galerije). Gre razvijalcu; brez povezave počaka v vrsti.
 */
export function FeedbackSheet({ shot: shot0, route }: { shot: string | null; route: string }) {
  const [kind, setKind] = useState<FbKind>('nejasno')
  const [text, setText] = useState('')
  const [shot, setShot] = useState<string | null>(shot0)
  const [busy, setBusy] = useState(false)
  const galRef = useRef<HTMLInputElement>(null)
  const { listening, canSpeak, toggle, stop } = useDictation(text, setText, m => toast(m, 'err', 6000))
  const where = SCREEN[route] || route

  async function pick(f: File | undefined) {
    if (!f || !f.type.startsWith('image/')) return
    try {
      const img = await fileToBase64Resized(f, 1280, 0.72)
      const url = `data:${img.mime};base64,${img.data}`
      if (url.length > FB_SHOT_MAX) { toast('Slika je prevelika — izberi manjšo ali pošlji brez nje.', 'err'); return }
      setShot(url)
    } catch { toast('Slike ni bilo mogoče prebrati.', 'err') }
  }
  async function send() {
    if (busy || (!text.trim() && !shot)) return
    stop(); setBusy(true)
    const f = await makeFeedback({ kind, text, shot, route })
    const r = await sendFeedback(f)
    setBusy(false)
    closeFeedback()
    toast(r === 'poslano' ? 'Hvala! Pripomba je poslana razvijalcu.' : 'Hvala! Pripomba je shranjena — pošljem jo, ko bo povezava s strežnikom.', 'ok', 6000)
  }

  return (
    <Sheet open onClose={closeFeedback} label="Pripomba">
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Pripomba ali napaka</b>
      <p className="muted" style={{ fontSize: 12.5, marginTop: 4 }}>Kaj ni jasno, kaj ne dela ali kaj bi spremenil? Napiši ali povej — gre naravnost razvijalcu.</p>
      <div className="row" role="group" aria-label="Vrsta pripombe" style={{ gap: 6, marginTop: 12, flexWrap: 'wrap' }}>
        {FB_KINDS.map(([k, l]) => <Chip key={k} sm on={kind === k} onClick={() => setKind(k)}>{l}</Chip>)}
      </div>
      <div className={`meal-text${listening ? ' live' : ''}`}>
        <label htmlFor="fb-text" className="sr-only">Pripomba</label>
        <textarea id="fb-text" rows={4} value={text} maxLength={FB_TEXT_MAX} onChange={e => setText(e.target.value)}
          placeholder={listening ? 'Poslušam …' : kind === 'napaka' ? 'Kaj si naredil in kaj se je zgodilo?' : kind === 'predlog' ? 'Kaj bi dodal ali spremenil?' : 'Česa ne razumeš?'} style={{ minHeight: 104 }} />
        {canSpeak && (
          <button type="button" className={`mic${listening ? ' on' : ''}`} style={{ top: 30 }} onClick={toggle} aria-pressed={listening} aria-label={listening ? 'Ustavi narekovanje' : 'Povej pripombo'}>
            <IcoMic width={18} height={18} />
          </button>
        )}
      </div>
      <div className="fb-shot">
        {shot ? (<>
          <img src={shot} alt={`Posnetek zaslona ${where}`} />
          <div style={{ minWidth: 0 }}>
            <b style={{ fontSize: 13 }}>Posnetek zaslona</b>
            <div className="muted" style={{ fontSize: 11.5, marginTop: 2 }}>{where} — tako, kot ga vidiš. Na njem so lahko tvoji podatki (npr. teža); vidi ga razvijalec (pri popravkih si pomaga z AI). Ko je rešeno, se izbriše.</div>
            <div className="row" style={{ gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
              <button type="button" className="chip sm click" onClick={() => setShot(null)}>odstrani</button>
              <button type="button" className="chip sm click" onClick={() => galRef.current?.click()}>druga slika</button>
            </div>
          </div>
        </>) : (
          <button type="button" className="chip click" onClick={() => galRef.current?.click()}><IcoImage width={16} height={16} /> Dodaj sliko (posnetek zaslona)</button>
        )}
      </div>
      <input ref={galRef} type="file" accept="image/*" hidden onChange={e => { const f = e.target.files?.[0]; e.target.value = ''; void pick(f) }} />
      <p className="muted" style={{ fontSize: 11, marginTop: 10 }}>Zraven gre: zaslon ({where}), različica {APP_VERSION}, vrsta naprave, zadnje napake aplikacije in tvoja e-pošta, če si prijavljen. <a href="zasebnost.html" target="_blank" rel="noopener">Zasebnost</a></p>
      <Btn primary block style={{ marginTop: 12 }} disabled={busy || (!text.trim() && !shot)} onClick={() => void send()}>{busy ? 'Pošiljam …' : 'Pošlji'}</Btn>
      <Btn ghost block style={{ marginTop: 8 }} onClick={closeFeedback}>Prekliči</Btn>
    </Sheet>
  )
}
