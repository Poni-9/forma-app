import { useState } from 'react'
import * as store from '@/state/store'
import { Sheet, Btn } from '@/ui/primitives'

/** Ob prijavi z drugim Googlovim računom, kot mu pripadajo podatki na tej napravi (store: accountClash). */
type Clash = { prevUid: string; prevEmail?: string } | null
/* Stanje in akcije doda podatkovni del (src/state/store.ts); do takrat varovalo — list se ne pokaže, gumba ne naredita nič. */
type ClashApi = { acceptAccountSwitch?: () => unknown; cancelAccountSwitch?: () => unknown }
const api = store as unknown as ClashApi

/** Rdeča podlaga s temnim besedilom: 4,8 : 1 (belo na --bad bi bilo le 3,9 : 1). */
const DANGER = { background: 'var(--bad)', color: 'var(--bg)' } as const

export function AccountClash() {
  const clash = (store.useApp() as ReturnType<typeof store.useApp> & { accountClash?: Clash }).accountClash
  const [busy, setBusy] = useState(false)
  if (!clash) return null
  const run = async (fn?: () => unknown) => {
    if (!fn || busy) return
    setBusy(true)
    try { await fn() } finally { setBusy(false) }
  }
  // odločitev je obvezna: dotik ob strani lista ga ne zapre
  return (
    <Sheet open onClose={() => { /* izbira je obvezna */ }}>
      <h3 style={{ fontSize: 18, letterSpacing: '-.02em' }}>Na tej napravi so podatki drugega računa</h3>
      <p style={{ fontSize: 14, marginTop: 8 }}>Da se računa ne pomešata, jih pred nadaljevanjem počisti s te naprave. Podatki drugega računa ostanejo v njegovem oblaku.</p>
      {clash.prevEmail && <p className="muted" style={{ fontSize: 12.5, marginTop: 6 }}>Drugi račun: {clash.prevEmail}</p>}
      <Btn block disabled={busy} style={{ ...DANGER, marginTop: 18 }} onClick={() => void run(api.acceptAccountSwitch)}>Počisti in nadaljuj</Btn>
      <Btn ghost block disabled={busy} style={{ marginTop: 9 }} onClick={() => void run(api.cancelAccountSwitch)}>Odjava</Btn>
    </Sheet>
  )
}
