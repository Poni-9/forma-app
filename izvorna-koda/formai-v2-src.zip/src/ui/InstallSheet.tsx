import { useEffect, useState } from 'react'
import { Sheet, Btn } from '@/ui/primitives'
import { IcoShare } from '@/ui/icons'
import { isIOS } from './motion'
import { useApp } from '@/state/store'
import { rem } from '@/ui/rem'

/** Zaslon 11 iz dizajna: »Daj FORMAI na zaslon«. Na Androidu/Chromu uporabi pravi namestitveni poziv, na iOS pokaže korake. */
// (v3.51) poziv brskalnika ujame installPrompt.ts že ob zagonu (ta list se naloži šele ob odprtju)
import { canInstall, isDesktop, promptInstall } from './installPrompt'
export { canInstall, isDesktop }

export function InstallSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const signedIn = !!useApp().user
  const [canPrompt, setCanPrompt] = useState(canInstall)
  useEffect(() => { const t = setInterval(() => setCanPrompt(canInstall()), 800); return () => clearInterval(t) }, [])
  const ios = isIOS()
  const desk = isDesktop() && !ios
  async function install() {
    await promptInstall()
    onClose()
  }
  return (
    <Sheet open={open} onClose={onClose}>
      <div className="row" style={{ gap: 13, marginBottom: 14 }}>
        <img src={import.meta.env.BASE_URL + 'icons/mark.svg'} alt="" width={46} height={46} style={{ borderRadius: '22.4%', flex: 'none', boxShadow: '0 4px 14px rgba(0,0,0,.4)' }} />
        <div style={{ flex: 1 }}><b style={{ fontSize: rem(17), letterSpacing: '-.02em' }}>{desk ? 'Namesti FORMAI na računalnik' : 'Daj FORMAI na zaslon'}</b><div className="muted" style={{ fontSize: rem(12.5), fontWeight: 600 }}>{desk ? 'Odpre se v svojem oknu, brez zavihkov brskalnika.' : 'Odpre se kot aplikacija — brez brskalnika'}</div></div>
      </div>
      {ios ? (
        <div className="stack" style={{ gap: 9, marginBottom: 15 }}>
          <div className="row" style={{ gap: 11 }}><div className="stepn">1</div><div style={{ fontSize: rem(13.5), fontWeight: 600 }}>Tapni <b>Deli</b> <IcoShare width={14} height={14} style={{ verticalAlign: -2 }} /> spodaj v Safariju</div></div>
          <div className="row" style={{ gap: 11 }}><div className="stepn">2</div><div style={{ fontSize: rem(13.5), fontWeight: 600 }}>Izberi <b>Dodaj na začetni zaslon</b></div></div>
          <div className="row" style={{ gap: 11 }}><div className="stepn">3</div><div style={{ fontSize: rem(13.5), fontWeight: 600 }}>Potrdi z <b>Dodaj</b></div></div>
        </div>
      ) : (
        <div className="stack" style={{ gap: 9, marginBottom: 15 }}>
          <div className="row" style={{ gap: 11 }}><div className="stepn">1</div><div style={{ fontSize: rem(13.5), fontWeight: 600 }}>{canPrompt ? (desk ? 'Klikni spodnji gumb' : 'Tapni spodnji gumb') : desk ? 'V naslovni vrstici klikni ikono' : 'V meniju brskalnika (⋮) izberi'} <b>{canPrompt ? '' : desk ? 'Namesti' : 'Dodaj na začetni zaslon'}</b></div></div>
          <div className="row" style={{ gap: 11 }}><div className="stepn">2</div><div style={{ fontSize: rem(13.5), fontWeight: 600 }}>Potrdi z <b>Namesti</b></div></div>
        </div>
      )}
      <div className="card tight" style={{ background: 'var(--raised)', border: 0, marginBottom: 14 }}>
        <div className="row" style={{ gap: 9 }}><span className="dot" style={{ background: 'var(--accent)' }} /><div style={{ fontSize: rem(12.5), color: 'var(--ink-2)', fontWeight: 600 }}>{/* sinhronizacija samo s prijavo (v3.48) */}{signedIn ? 'Isti račun na telefonu in računalniku. Načrt in prehrana se sinhronizirata sama.' : 'Brez prijave ostane načrt na tej napravi — prijavo dodaš v Nastavitvah.'}</div></div>
      </div>
      <Btn primary block onClick={install}>{canPrompt ? 'Namesti' : 'Razumem, dodam'}</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Pozneje</Btn>
    </Sheet>
  )
}
