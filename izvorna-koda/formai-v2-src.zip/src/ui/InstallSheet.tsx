import { useEffect, useState } from 'react'
import { Sheet, Btn } from '@/ui/primitives'
import { IcoShare } from '@/ui/icons'
import { isIOS } from './motion'

/** Zaslon 11 iz dizajna: »Daj FORMAI na zaslon«. Na Androidu/Chromu uporabi pravi namestitveni poziv, na iOS pokaže korake. */
let deferred: (Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> }) | null = null
if (typeof window !== 'undefined') window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferred = e as typeof deferred })

export function InstallSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [canPrompt, setCanPrompt] = useState(!!deferred)
  useEffect(() => { const t = setInterval(() => setCanPrompt(!!deferred), 800); return () => clearInterval(t) }, [])
  const ios = isIOS()
  async function install() {
    if (deferred) { try { await deferred.prompt(); await deferred.userChoice } catch { /* preklicano */ } deferred = null }
    onClose()
  }
  return (
    <Sheet open={open} onClose={onClose}>
      <div className="row" style={{ gap: 13, marginBottom: 14 }}>
        <img src={import.meta.env.BASE_URL + 'icons/mark.svg'} alt="" width={46} height={46} style={{ borderRadius: '22.4%', flex: 'none', boxShadow: '0 4px 14px rgba(0,0,0,.4)' }} />
        <div style={{ flex: 1 }}><b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Daj FORMAI na zaslon</b><div className="muted" style={{ fontSize: 12.5, fontWeight: 600 }}>Odpre se kot aplikacija — brez brskalnika</div></div>
      </div>
      {ios ? (
        <div className="stack" style={{ gap: 9, marginBottom: 15 }}>
          <div className="row" style={{ gap: 11 }}><div className="stepn">1</div><div style={{ fontSize: 13.5, fontWeight: 600 }}>Tapni <b>Deli</b> <IcoShare width={14} height={14} style={{ verticalAlign: -2 }} /> spodaj v Safariju</div></div>
          <div className="row" style={{ gap: 11 }}><div className="stepn">2</div><div style={{ fontSize: 13.5, fontWeight: 600 }}>Izberi <b>Dodaj na začetni zaslon</b></div></div>
          <div className="row" style={{ gap: 11 }}><div className="stepn">3</div><div style={{ fontSize: 13.5, fontWeight: 600 }}>Potrdi z <b>Dodaj</b></div></div>
        </div>
      ) : (
        <div className="stack" style={{ gap: 9, marginBottom: 15 }}>
          <div className="row" style={{ gap: 11 }}><div className="stepn">1</div><div style={{ fontSize: 13.5, fontWeight: 600 }}>{canPrompt ? 'Tapni spodnji gumb' : 'V meniju brskalnika (⋮) izberi'} <b>{canPrompt ? '' : 'Dodaj na začetni zaslon'}</b></div></div>
          <div className="row" style={{ gap: 11 }}><div className="stepn">2</div><div style={{ fontSize: 13.5, fontWeight: 600 }}>Potrdi z <b>Namesti</b></div></div>
        </div>
      )}
      <div className="card tight" style={{ background: 'var(--raised)', border: 0, marginBottom: 14 }}>
        <div className="row" style={{ gap: 9 }}><span className="dot" style={{ background: 'var(--accent)' }} /><div style={{ fontSize: 12.5, color: 'var(--ink-2)', fontWeight: 600 }}>Isti račun na telefonu in računalniku. Načrt in prehrana se sinhronizirata sama.</div></div>
      </div>
      <Btn primary block onClick={install}>{canPrompt ? 'Namesti' : 'Razumem, dodam'}</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Pozneje</Btn>
    </Sheet>
  )
}
