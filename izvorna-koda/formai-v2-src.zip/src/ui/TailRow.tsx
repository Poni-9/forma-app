import type { PlanDay } from '@/domain/types'
import { KindIcon, kindColor } from '@/ui/primitives'

/** Kardio po moči v istem dnevu (dogovor »tek v istem dnevu«): vrstica pod vajami na Danes in v Planu. */
export function TailRow({ tail }: { tail: NonNullable<PlanDay['tail']> }) {
  return (
    <div className="row" style={{ gap: 8, marginTop: 8, paddingTop: 8, borderTop: '1px solid var(--line)', alignItems: 'flex-start', fontSize: 13 }}>
      <span style={{ width: 24, height: 24, borderRadius: 8, display: 'grid', placeItems: 'center', flex: 'none', color: kindColor(tail.kind), background: 'rgba(var(--fg-rgb),.06)' }}><KindIcon kind={tail.kind} size={14} /></span>
      <span style={{ minWidth: 0 }}><b style={{ color: 'var(--ink)' }}>Nato {tail.title.replace(/ — /, ': ').toLowerCase()}</b><span className="muted" style={{ display: 'block', fontSize: 12, marginTop: 1 }}>{tail.desc}</span></span>
    </div>
  )
}
