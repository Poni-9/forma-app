import { useState } from 'react'
import { setPlanDone } from '@/state/store'
import { fmtDur } from '@/domain/training/load'
import { doneMinutes, minuteOptions } from '@/domain/training/standin'
import type { PlanDay } from '@/domain/types'
import { Btn, Chip, Sheet } from '@/ui/primitives'
import { rem } from '@/ui/rem'

/**
 * (v3.49) »Opravil« brez ure ni več vse ali nič: pod opravljenim treningom piše, koliko šteje (»po načrtu« ali »31 min
 * od 1 h 45 min«); »krajše?« odpre izbiro minut. Minute štejejo v teden, formo in kalorije (done.min).
 * Samo za dan brez povezane vadbe — vožnja z ure ima svoje minute.
 */
export function DoneMinutes({ day }: { day: PlanDay }) {
  const [open, setOpen] = useState(false)
  if (!day.done || day.done.activityId || !(day.durationMin > 0)) return null
  const m = doneMinutes(day), plan = day.durationMin
  const short = m < plan
  const pick = (x: number) => { setOpen(false); void setPlanDone(day.id, true, null, x >= plan ? null : x) }
  return (<>
    <div className="done-min">
      <span>Šteje <b>{fmtDur(m)}</b>{short ? ` od ${fmtDur(plan)}` : ' — po načrtu'}</span>
      <button type="button" className="chip sm click" onClick={() => setOpen(true)}>{short ? 'spremeni' : 'krajše?'}</button>
    </div>
    {open && (
      <Sheet open onClose={() => setOpen(false)} label="Koliko si naredil">
        <b style={{ display: 'block', fontSize: rem(17), letterSpacing: '-.02em' }}>Koliko si res naredil?</b>
        <p className="muted" style={{ fontSize: rem(12.5), marginTop: 4 }}>Šteje v teden, formo in kalorije.</p>
        <div className="row" style={{ gap: 7, flexWrap: 'wrap', marginTop: 12 }}>
          {minuteOptions(plan).map(x => <Chip key={x} sm on={x === m} onClick={() => pick(x)}>{fmtDur(x)}</Chip>)}
        </div>
        <Btn primary block style={{ marginTop: 14 }} onClick={() => pick(plan)}>Vse po načrtu ({fmtDur(plan)})</Btn>
        <Btn ghost block style={{ marginTop: 9 }} onClick={() => setOpen(false)}>Prekliči</Btn>
      </Sheet>
    )}
  </>)
}
