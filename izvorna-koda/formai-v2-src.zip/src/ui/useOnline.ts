import { useEffect, useState } from 'react'

/** Ali ima naprava povezavo (brskalnikova ocena; brez povezave je zanesljivo, »povezan« pa ne vedno). */
export function useOnline(): boolean {
  const [on, setOn] = useState(() => (typeof navigator === 'undefined' ? true : navigator.onLine !== false))
  useEffect(() => {
    const up = () => setOn(true), down = () => setOn(false)
    addEventListener('online', up); addEventListener('offline', down)
    return () => { removeEventListener('online', up); removeEventListener('offline', down) }
  }, [])
  return on
}
