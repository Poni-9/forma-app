import type { RideFuel } from '@/domain/nutrition/dayplan'
import { NBSP } from '@/ui/format'

const hm = (m: number) => `${Math.floor(m / 60)}:${String(Math.round(m % 60)).padStart(2, '0')}`
const l1 = (ml: number) => (ml / 1000).toFixed(1).replace('.', ',')

/** Pitje iz besedila časovnice: prvi stavek (»Pij od začetka: …«). */
export function drinkLine(rf: Pick<RideFuel, 'schedule'>): string {
  const i = rf.schedule.indexOf(' Hrana:')
  return (i > 0 ? rf.schedule.slice(0, i) : rf.schedule.split(' Skupaj')[0] || rf.schedule).trim()
}

/**
 * Časovnica goriva na kolesu: trak od starta do cilja z oznako vsakega opomnika (hrana = zelena, pitje = modra)
 * in kratek seznam, kaj pojesti kdaj (»0:30 banana«). Bralnik zaslona dobi vse kot besedilo.
 */
export function FuelTimeline({ rf, minutes }: { rf: RideFuel; minutes: number }) {
  if (!rf.cues.length || minutes <= 0) return null
  const food = rf.cues.filter(c => c.solid)
  const pct = (m: number) => `${Math.max(0, Math.min(100, (m / minutes) * 100))}%`
  const hours = Array.from({ length: Math.floor(minutes / 60) }, (_, i) => (i + 1) * 60).filter(m => m < minutes - 10)
  const label = `Časovnica goriva: ${food.map(c => `${hm(c.atMin)} ${c.short}`).join(', ') || 'samo pitje'}; pitje ${rf.everyMin ? `vsakih ${rf.everyMin} min` : 'po žeji'}. Skupaj ~${rf.totalCarbs} g OH in ~${l1(rf.fluidMl)} l tekočine.`
  return (
    <div className="fuel-tl" role="img" aria-label={label}>
      <div className="track" aria-hidden="true">
        <i className="fill" />
        {hours.map(m => <span key={m} className="tick" style={{ left: pct(m) }} />)}
        {rf.cues.map(c => <span key={c.atMin} className={`cue ${c.solid ? 'food' : 'drink'}`} style={{ left: pct(c.atMin) }} />)}
      </div>
      <div className="axis" aria-hidden="true"><span>start</span>{hours.map(m => <span key={m} style={{ left: pct(m) }}>{m / 60}{NBSP}h</span>)}<span className="end">{hm(minutes)}</span></div>
      {food.length > 0 && <div className="foods" aria-hidden="true">{food.map(c => <span key={c.atMin} className="food-chip"><b>{hm(c.atMin)}</b> {c.short}</span>)}</div>}
      <div className="legend" aria-hidden="true"><span><i className="cue food" /> hrana</span><span><i className="cue drink" /> pitje</span><span className="tot">~{rf.totalCarbs}{NBSP}g OH · ~{l1(rf.fluidMl)}{NBSP}l</span></div>
    </div>
  )
}
