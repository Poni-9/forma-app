import { createPortal } from 'react-dom'
import { useEffect, useId, useRef, useState, type ReactNode } from 'react'
import type { PlanKind } from '@/domain/types'
import { IcoCheck, IcoBike, IcoDumbbell, IcoRun, IcoTarget, IcoHeart, IcoMap } from './icons'

/* ---- barve tipov (iz tokenov) ---- */
export const kindColor = (k: PlanKind | string): string =>
  k === 'kolo' || k === 'test' ? 'var(--t-kolo)' : k === 'moc' ? 'var(--t-moc)' : k === 'tek' || k === 'pohod' ? 'var(--t-tek)' : 'var(--t-poc)'
/** Ikona vrste treninga (značka v kartici »junak«). */
export function KindIcon({ kind, size = 17 }: { kind: PlanKind | string; size?: number }) {
  const s = { width: size, height: size }
  return kind === 'kolo' ? <IcoBike {...s} /> : kind === 'moc' ? <IcoDumbbell {...s} /> : kind === 'tek' ? <IcoRun {...s} /> : kind === 'pohod' ? <IcoMap {...s} /> : kind === 'test' ? <IcoTarget {...s} /> : <IcoHeart {...s} />
}
export const kindLabel = (k: PlanKind): string =>
  ({ kolo: 'Kolo', tek: 'Tek in hoja', pohod: 'Hribi', moc: 'Moč', pocitek: 'Počitek', test: 'Test' })[k]

export function Card({ children, tight, accent, className = '', style, onClick, id }: { children: ReactNode; tight?: boolean; accent?: boolean; className?: string; style?: React.CSSProperties; onClick?: () => void; id?: string }) {
  return <div id={id} className={`card ${tight ? 'tight' : ''} ${accent ? 'accent' : ''} ${className}`} style={style} onClick={onClick}>{children}</div>
}

export function Chip({ children, on, sm, ok, onClick }: { children: ReactNode; on?: boolean; sm?: boolean; ok?: boolean; onClick?: () => void }) {
  const cls = `chip ${on ? 'on' : ''} ${sm ? 'sm' : ''} ${ok ? 'ok' : ''} ${onClick ? 'click' : ''}`
  return onClick ? <button type="button" className={cls} onClick={onClick}>{children}</button> : <span className={cls}>{children}</span>
}

export function Btn({ children, primary, ghost, block, sm, xs, disabled, onClick, type = 'button', style }: { children: ReactNode; primary?: boolean; ghost?: boolean; block?: boolean; sm?: boolean; xs?: boolean; disabled?: boolean; onClick?: () => void; type?: 'button' | 'submit'; style?: React.CSSProperties }) {
  return <button type={type} disabled={disabled} onClick={onClick} style={style} className={`btn ${primary ? 'primary' : ''} ${ghost ? 'ghost' : ''} ${block ? 'block' : ''} ${sm ? 'sm' : ''} ${xs ? 'xs' : ''}`}>{children}</button>
}

export function Option({ icon, title, sub, on, onClick, style }: { icon: ReactNode; title: string; sub?: string; on?: boolean; onClick?: () => void; style?: React.CSSProperties }) {
  return (
    <button type="button" className={`opt ${on ? 'on' : ''}`} onClick={onClick} style={style}>
      <div className="oi">{icon}</div>
      <div>{title}{sub && <small>{sub}</small>}</div>
    </button>
  )
}

export function Progress({ pct }: { pct: number }) { return <div className="prog"><i style={{ width: `${Math.max(0, Math.min(100, pct))}%` }} /></div> }

export function Ring({ size = 92, stroke = 9, pct, children }: { size?: number; stroke?: number; pct: number; children: ReactNode }) {
  const r = (size - stroke) / 2, c = 2 * Math.PI * r
  const p = Math.max(0, Math.min(1, pct))
  const gid = 'rg' + useId().replace(/[^a-zA-Z0-9]/g, '')
  return (
    <div className="ring" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        {/* limeta od svetle do temnejše v smeri polnjenja (svg je zasukan za −90°) */}
        <defs><linearGradient id={gid} x1="1" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#C6F270" /><stop offset="1" stopColor="#84CC16" /></linearGradient></defs>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,.07)" strokeWidth={stroke} />
        {p > 0.005 && <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={`url(#${gid})`} strokeWidth={stroke} strokeLinecap="round" strokeDasharray={`${c * p} ${c}`} style={{ filter: 'drop-shadow(0 0 6px rgba(163,230,53,.35))' }} />}
      </svg>
      <div className="mid">{children}</div>
    </div>
  )
}

export function Track({ pct, color }: { pct: number; color: string }) { return <div className="track"><i style={{ width: `${Math.max(0, Math.min(100, pct))}%`, background: color }} /></div> }

export function CheckBtn({ on, onClick }: { on: boolean; onClick?: () => void }) {
  return <button type="button" className={`check ${on ? '' : 'off'}`} onClick={onClick} aria-label={on ? 'Opravljeno' : 'Označi kot opravljeno'}>{on ? <IcoCheck width={14} height={14} /> : ''}</button>
}

export function Empty({ icon, title, text, children }: { icon: ReactNode; title: string; text: string; children?: ReactNode }) {
  return (
    <div className="card" style={{ padding: 0 }}>
      <div className="empty">
        <div className="ico">{icon}</div>
        <h3>{title}</h3><p>{text}</p>
        {children}
      </div>
    </div>
  )
}

/* ---- odprti listi: Esc, gumb Nazaj (Android/brskalnik) in fokus ---- */
type OpenSheet = { id: number; close: () => void; popped: boolean }
const openSheets: OpenSheet[] = []
let sheetSeq = 0, sheetWired = false
const HKEY = 'formaiSheet'
const sheetOf = (st: unknown): number | null => (st && typeof st === 'object' && HKEY in st ? Number((st as Record<string, unknown>)[HKEY]) : null)
/** Nazaj: zapri liste nad vnosom zgodovine, na katerega smo prišli (stari vnosi po osvežitvi zaprejo vse). */
function onSheetPop(e: PopStateEvent) {
  const cur = sheetOf(e.state)
  const keep = cur == null ? -1 : openSheets.findIndex(s => s.id === cur)
  while (openSheets.length > keep + 1) { const top = openSheets.pop()!; top.popped = true; top.close() }
}
function onSheetKey(e: KeyboardEvent) {
  if (e.key !== 'Escape' || e.defaultPrevented || !openSheets.length) return
  e.preventDefault()
  openSheets[openSheets.length - 1]!.close()
}

/**
 * Spodnji list. V portalu na <body>: zaslon (.page) ima animiran transform, ki bi sicer ujel position: fixed pod zavihke.
 * Esc in gumb Nazaj zapreta list (ne zapustita zaslona); fokus gre na list in se ob zaprtju vrne, od koder je prišel.
 */
export function Sheet({ open, onClose, children, label }: { open: boolean; onClose: () => void; children: ReactNode; /** ime za bralnike zaslona; privzeto prvi naslov v listu */ label?: string }) {
  if (!open) return null
  return <SheetBody onClose={onClose} label={label}>{children}</SheetBody>
}

function SheetBody({ onClose, children, label }: { onClose: () => void; children: ReactNode; label?: string }) {
  const ref = useRef<HTMLDivElement>(null)
  const closeRef = useRef(onClose)
  closeRef.current = onClose
  const [auto, setAuto] = useState<string | undefined>(undefined)
  useEffect(() => {
    const prev = document.activeElement instanceof HTMLElement ? document.activeElement : null
    const me: OpenSheet = { id: ++sheetSeq, close: () => closeRef.current(), popped: false }
    openSheets.push(me)
    if (!sheetWired) { window.addEventListener('popstate', onSheetPop); document.addEventListener('keydown', onSheetKey); sheetWired = true }
    // en vnos v zgodovini na odprt list: Nazaj zapre list, zaslon ostane (isti naslov → brez hashchange)
    try { const st = history.state; history.pushState({ ...(st && typeof st === 'object' ? st : {}), [HKEY]: me.id }, '') } catch { /* brez zgodovine */ }
    const el = ref.current
    if (el && !el.contains(document.activeElement)) el.focus({ preventScroll: true })
    if (el) { const h = el.querySelector('h1, h2, h3, h4, b, strong'); const t = h?.textContent?.trim(); if (t) setAuto(t.slice(0, 80)) }
    return () => {
      const i = openSheets.indexOf(me)
      if (i >= 0) openSheets.splice(i, 1)
      // zaprt z gumbom ali tapom: vnos lista odstranimo z Nazaj — šele po tem opravilu, da ne povozimo navigacije,
      // ki jo je sprožil klicatelj (npr. »Prekinem trening?« → Danes) ali lista, ki se je odprl namesto tega
      if (!me.popped) setTimeout(() => { if (sheetOf(history.state) === me.id) { try { history.back() } catch { /* */ } } }, 0)
      if (prev && prev.isConnected) { try { prev.focus({ preventScroll: true }) } catch { /* */ } }
    }
  }, [])
  return createPortal(<>
    <div className="veil" onClick={onClose} />
    <div ref={ref} className="sheet" role="dialog" aria-modal="true" aria-label={label || auto} tabIndex={-1} style={{ outline: 'none' }}><div className="grab" />{children}</div>
  </>, document.body)
}

export function Sparkline({ values, width = 130, height = 40 }: { values: number[]; width?: number; height?: number }) {
  if (values.length < 2) return <svg width="100%" height={height} />
  const min = Math.min(...values), max = Math.max(...values), span = max - min || 1
  const pts = values.map((v, i) => [2 + (i / (values.length - 1)) * (width - 4), height - 6 - ((v - min) / span) * (height - 12)] as const)
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(' ')
  const last = pts[pts.length - 1]!
  const id = 'sp' + Math.round(width * 7 + height)
  return (
    <svg viewBox={`0 0 ${width} ${height}`} width="100%" height={height} preserveAspectRatio="none" aria-hidden="true">
      <defs><linearGradient id={id} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="var(--accent)" stopOpacity=".35" /><stop offset="1" stopColor="var(--accent)" stopOpacity="0" /></linearGradient></defs>
      <path d={`${d} L${last[0].toFixed(1)} ${height} L2 ${height} Z`} fill={`url(#${id})`} />
      <path d={d} fill="none" stroke="var(--accent)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
    </svg>
  )
}

export const DAYS_SL = ['pon', 'tor', 'sre', 'čet', 'pet', 'sob', 'ned']
export const MONTHS_SL = ['januar', 'februar', 'marec', 'april', 'maj', 'junij', 'julij', 'avgust', 'september', 'oktober', 'november', 'december']
/** rodilnik za datume: »22. avgusta« */
export const MONTHS_GEN_SL = ['januarja', 'februarja', 'marca', 'aprila', 'maja', 'junija', 'julija', 'avgusta', 'septembra', 'oktobra', 'novembra', 'decembra']
export const DAYS_LONG_SL = ['Ponedeljek', 'Torek', 'Sreda', 'Četrtek', 'Petek', 'Sobota', 'Nedelja']
export function fmtDateLong(iso: string): string {
  const [y, m, d] = iso.split('-').map(Number) as [number, number, number]
  const dt = new Date(y, m - 1, d)
  return `${DAYS_LONG_SL[(dt.getDay() + 6) % 7]}, ${d}. ${MONTHS_GEN_SL[m - 1]}`
}
/** Števila po slovensko: skupine po tri z ozkim nedeljivim presledkom (1 840), minus kot »−«. */
export function fmtKcal(n: number): string {
  const v = Math.round(+n || 0), s = String(Math.abs(v))
  let out = ''
  for (let i = 0; i < s.length; i++) { if (i > 0 && (s.length - i) % 3 === 0) out += '\u202F'; out += s[i] }
  return (v < 0 ? '\u2212' : '') + out
}
