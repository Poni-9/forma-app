import { createPortal } from 'react-dom'
import { useEffect, useId, useRef, useState, type ReactNode, type InputHTMLAttributes } from 'react'
import type { PlanKind } from '@/domain/types'
import { IcoCheck, IcoBike, IcoDumbbell, IcoRun, IcoGauge, IcoRest, IcoMountain } from './icons'

/* ---- barve tipov (iz tokenov) ---- */
export const kindColor = (k: PlanKind | string): string =>
  k === 'kolo' || k === 'test' ? 'var(--t-kolo)' : k === 'moc' ? 'var(--t-moc)' : k === 'tek' || k === 'pohod' ? 'var(--t-tek)' : 'var(--t-poc)'
/** Barva vrste za BESEDILO (oznake): v svetli temi temnejša, da je berljiva; za ikone in grafe kindColor. */
export const kindInk = (k: PlanKind | string): string =>
  k === 'kolo' || k === 'test' ? 'var(--t-kolo-ink)' : k === 'moc' ? 'var(--t-moc-ink)' : k === 'tek' || k === 'pohod' ? 'var(--t-tek-ink)' : 'var(--t-poc-ink)'
/** Ikona vrste treninga (značka v kartici »junak«). */
export function KindIcon({ kind, size = 17 }: { kind: PlanKind | string; size?: number }) {
  const s = { width: size, height: size }
  return kind === 'kolo' ? <IcoBike {...s} /> : kind === 'moc' ? <IcoDumbbell {...s} /> : kind === 'tek' ? <IcoRun {...s} /> : kind === 'pohod' ? <IcoMountain {...s} /> : kind === 'test' ? <IcoGauge {...s} /> : <IcoRest {...s} />
}
export const kindLabel = (k: PlanKind): string =>
  ({ kolo: 'Kolo', tek: 'Tek in hoja', pohod: 'Hribi', moc: 'Moč', pocitek: 'Počitek', test: 'Test' })[k]
/** Oznaka vrste za dan: lahek sprehod (prilagoditev počutju) je »Hoja«, ne »Hribi«. */
export const kindLabelOf = (d: { kind: PlanKind; role?: string | null; title?: string }): string =>
  // (v3.50) »Hitra hoja« v parku ni »Hribi«
  d.kind === 'pohod' && (d.role === 'regen' || (/^Hitra hoja/i.test(d.title || '') && !/hrib|tur[ao]|planin/i.test(d.title || ''))) ? 'Hoja'
  // tek iz načrta po meri (»Tek — lahko 40 min«, »Tempo tek«, »Daljši lahek tek«) je tek; »Tek in hoja« ostane za
  // izmenični tek s hojo (v3.50: tudi, ko »tek« ni prva beseda)
  : d.kind === 'tek' && d.title && /(^|\s)tek\b/i.test(d.title) && !/hoj/i.test(d.title) ? 'Tek'
  : kindLabel(d.kind)

export function Card({ children, tight, accent, className = '', style, onClick, id }: { children: ReactNode; tight?: boolean; accent?: boolean; className?: string; style?: React.CSSProperties; onClick?: () => void; id?: string }) {
  return <div id={id} className={`card ${tight ? 'tight' : ''} ${accent ? 'accent' : ''} ${className}`} style={style} onClick={onClick}>{children}</div>
}

export function Chip({ children, on, sm, ok, onClick }: { children: ReactNode; on?: boolean; sm?: boolean; ok?: boolean; onClick?: () => void }) {
  const cls = `chip ${on ? 'on' : ''} ${sm ? 'sm' : ''} ${ok ? 'ok' : ''} ${onClick ? 'click' : ''}`
  // izbirni čip (on je podan) bralniku zaslona pove, ali je izbran
  return onClick ? <button type="button" className={cls} onClick={onClick} aria-pressed={on === undefined ? undefined : on}>{children}</button> : <span className={cls}>{children}</span>
}

export function Btn({ children, primary, ghost, block, sm, xs, disabled, onClick, type = 'button', style }: { children: ReactNode; primary?: boolean; ghost?: boolean; block?: boolean; sm?: boolean; xs?: boolean; disabled?: boolean; onClick?: () => void; type?: 'button' | 'submit'; style?: React.CSSProperties }) {
  return <button type={type} disabled={disabled} onClick={onClick} style={style} className={`btn ${primary ? 'primary' : ''} ${ghost ? 'ghost' : ''} ${block ? 'block' : ''} ${sm ? 'sm' : ''} ${xs ? 'xs' : ''}`}>{children}</button>
}

export function Option({ icon, title, sub, on, onClick, style }: { icon: ReactNode; title: string; sub?: string; on?: boolean; onClick?: () => void; style?: React.CSSProperties }) {
  return (
    // izbira (on je podan) bralniku zaslona pove, ali je izbrana — kot Chip (v3.48)
    <button type="button" className={`opt ${on ? 'on' : ''}`} onClick={onClick} style={style} aria-pressed={on === undefined ? undefined : on}>
      <div className="oi">{icon}</div>
      <div>{title}{sub && <small>{sub}</small>}</div>
    </button>
  )
}

export function Progress({ pct }: { pct: number }) { return <div className="prog"><i style={{ width: `${Math.max(0, Math.min(100, pct))}%` }} /></div> }

export function Ring({ size = 92, stroke = 9, pct, children, rest, over = false }: { size?: number; stroke?: number; pct: number; children: ReactNode; /** preostanek obarvan (ne siv): obroč živi tudi pri 0 */ rest?: boolean; /** (v3.50) cilj presežen (> 110 %): obroč v barvi opozorila, ne poln in zelen */ over?: boolean }) {
  const r = (size - stroke) / 2
  const p = Math.max(0, Math.min(1, pct))
  const gid = 'rg' + useId().replace(/[^a-zA-Z0-9]/g, '')
  if (over) return (
    <div className="ring over" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--warn)" strokeWidth={stroke} className="ring-fill" />
      </svg>
      <div className="mid">{children}</div>
    </div>
  )
  return (
    <div className="ring" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        {/* limeta od svetle do temnejše v smeri polnjenja (svg je zasukan za −90°); v svetli temi temnejši konec (žetoni --ring-*) */}
        <defs><linearGradient id={gid} x1="1" y1="0" x2="0" y2="1"><stop offset="0" stopColor="var(--ring-a)" /><stop offset="1" stopColor="var(--ring-b)" /></linearGradient></defs>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={rest ? 'rgba(var(--accent-rgb),.16)' : 'rgba(var(--fg-rgb),.07)'} strokeWidth={stroke} />
        {rest && p < 0.995 && <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(var(--accent-rgb),.45)" strokeWidth={2} strokeLinecap="round" pathLength={100} strokeDasharray="1.2 2.2" className="ring-rest" />}
        {p > 0.005 && <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={`url(#${gid})`} strokeWidth={stroke} strokeLinecap="round" pathLength={100} strokeDasharray={`${100 * p} 100`} className="ring-fill" style={{ filter: 'drop-shadow(0 0 6px var(--ring-glow))' }} />}
      </svg>
      <div className="mid">{children}</div>
    </div>
  )
}

export function Track({ pct, color }: { pct: number; color: string }) { return <div className="track"><i style={{ width: `${Math.max(0, Math.min(100, pct))}%`, background: color }} /></div> }

export function CheckBtn({ on, onClick, label, disabled = false }: { on: boolean; onClick?: () => void; /** (v3.48) dan in vadba za bralnik zaslona: »torek, 20. 10.: Z2« */ label?: string; /** (v3.50) prihodnji dan: kljukica še ni na vrsti */ disabled?: boolean }) {
  // gumb 44 × 44 (cilj dotika), viden krog 26 px; negativni rob ohrani postavitev
  const state = on ? 'opravljeno' : disabled ? 'še ni na vrsti' : 'označi kot opravljeno'
  return <button type="button" className="check-hit" onClick={onClick} disabled={disabled && !on} aria-label={label ? `${label} — ${state}` : on ? 'Opravljeno' : disabled ? 'Še ni na vrsti' : 'Označi kot opravljeno'} aria-pressed={on}><span className={`check ${on ? '' : 'off'}`} aria-hidden="true">{on ? <IcoCheck width={14} height={14} /> : ''}</span></button>
}

/**
 * Decimalno število, ki sprejme vejico (79,9) ali piko. type=number na slovenskih tipkovnicah vejice povsod ne sprejme
 * (Safari, Firefox) in kaže »79.9«. Prikaz z vejico; starš v e.target.value dobi vrednost s piko (obstoječe +vrednost deluje).
 */
export function DecimalInput({ value, onChange, ...rest }: Omit<InputHTMLAttributes<HTMLInputElement>, 'type' | 'inputMode'>) {
  const shown = value == null ? '' : String(value).replace('.', ',')
  return <input {...rest} type="text" inputMode="decimal" autoComplete="off" spellCheck={false} value={shown} onChange={e => {
    const v = e.target.value.replace(/\s/g, '').replace(',', '.')
    if (v !== '' && !/^\d*\.?\d*$/.test(v)) return          // črke in druga ločila ne
    e.target.value = v
    onChange?.(e)
  }} />
}

export function Empty({ icon, title, text, children }: { icon: ReactNode; title: string; text: string; children?: ReactNode }) {
  return (
    <div className="card" style={{ padding: 0 }}>
      <div className="empty">
        <div className="ico">{icon}</div>
        {/* h2 (v3.48): takoj pod naslovom zaslona (h1) — prej h3 */}
        <h2>{title}</h2><p>{text}</p>
        {children}
      </div>
    </div>
  )
}

/* ---- odprti listi: Esc, gumb Nazaj (Android/brskalnik) in fokus ---- */
type OpenSheet = { id: number; close: () => void; popped: boolean; el: HTMLElement | null }
const openSheets: OpenSheet[] = []
let sheetSeq = 0, sheetWired = false
const HKEY = 'formaiSheet'
const sheetOf = (st: unknown): number | null => (st && typeof st === 'object' && HKEY in st ? Number((st as Record<string, unknown>)[HKEY]) : null)
/** Nazaj: zapri liste nad vnosom zgodovine, na katerega smo prišli (stari vnosi po osvežitvi zaprejo vse). */
function onSheetPop(e: PopStateEvent) {
  const cur = sheetOf(e.state)
  const keep = cur == null ? -1 : openSheets.findIndex(s => s.id === cur)
  while (openSheets.length > keep + 1) { const top = openSheets.pop()!; top.popped = true; top.close() }
}
function onSheetKey(e: KeyboardEvent) {
  if (e.defaultPrevented || !openSheets.length) return
  const top = openSheets[openSheets.length - 1]!
  if (e.key === 'Tab') { if (top.el) trapTab(e, top.el); return }
  if (e.key !== 'Escape') return
  e.preventDefault()
  top.close()
}

const FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), summary, iframe, [tabindex]:not([tabindex="-1"]), [contenteditable="true"]'
/**
 * Tab ostane v listu (v3.48): z zadnjega na prvega, s Shift s prvega na zadnjega, od zunaj na prvega.
 * Skrito (display: none, zaprt details) ne šteje; vmes tipka dela kot sicer.
 */
export function trapTab(e: KeyboardEvent, el: HTMLElement): void {
  const all = Array.from(el.querySelectorAll<HTMLElement>(FOCUSABLE)).filter(x => !x.closest('[hidden], [inert]'))
  const vis = all.filter(x => x.getClientRects().length > 0)
  const list = vis.length ? vis : all   // brez postavitve (jsdom) ne vemo, kaj je vidno
  const a = document.activeElement
  const inside = a instanceof HTMLElement && a !== el && el.contains(a)
  if (!list.length) { e.preventDefault(); el.focus({ preventScroll: true }); return }
  const to = e.shiftKey ? (!inside || a === list[0] ? list[list.length - 1] : null) : (!inside || a === list[list.length - 1] ? list[0] : null)
  if (to) { e.preventDefault(); to.focus() }
}

/** Ozadje med odprtim listom (v3.48): vsebina #root je inert (bralnik zaslona, Tab, klik); obvestila ostanejo živa. */
let inerted: Element[] = []
function backdropInert(on: boolean): void {
  if (!on) { for (const c of inerted) c.removeAttribute('inert'); inerted = []; return }
  const root = typeof document !== 'undefined' ? document.getElementById('root') : null
  if (!root || inerted.length) return
  inerted = Array.from(root.children).filter(c => !c.classList.contains('toast-host') && !c.hasAttribute('inert'))
  for (const c of inerted) c.setAttribute('inert', '')
}

/**
 * Spodnji list. V portalu na <body>: zaslon (.page) ima animiran transform, ki bi sicer ujel position: fixed pod zavihke.
 * Esc in gumb Nazaj zapreta list (ne zapustita zaslona); fokus gre na list in se ob zaprtju vrne, od koder je prišel.
 */
export function Sheet({ open, onClose, children, label }: { open: boolean; onClose: () => void; children: ReactNode; /** ime za bralnike zaslona; privzeto prvi naslov v listu */ label?: string }) {
  if (!open) return null
  return <SheetBody onClose={onClose} label={label}>{children}</SheetBody>
}

function SheetBody({ onClose, children, label }: { onClose: () => void; children: ReactNode; label?: string }) {
  const ref = useRef<HTMLDivElement>(null)
  const closeRef = useRef(onClose)
  closeRef.current = onClose
  const [auto, setAuto] = useState<string | undefined>(undefined)
  // gumb, ki je list odprl — zajet že med izrisom: autoFocus polja v listu se zgodi pred useEffect,
  // zato bi bil document.activeElement v efektu že polje v listu (ob zaprtju odstranjeno → fokus na <body>)
  const [prev] = useState<HTMLElement | null>(() => {
    const a = typeof document !== 'undefined' ? document.activeElement : null
    return a instanceof HTMLElement && a !== document.body ? a : null
  })
  useEffect(() => {
    const me: OpenSheet = { id: ++sheetSeq, close: () => closeRef.current(), popped: false, el: ref.current }
    openSheets.push(me)
    backdropInert(true)
    if (!sheetWired) { window.addEventListener('popstate', onSheetPop); document.addEventListener('keydown', onSheetKey); sheetWired = true }
    // en vnos v zgodovini na odprt list: Nazaj zapre list, zaslon ostane (isti naslov → brez hashchange)
    try { const st = history.state; history.pushState({ ...(st && typeof st === 'object' ? st : {}), [HKEY]: me.id }, '') } catch { /* brez zgodovine */ }
    const el = ref.current
    if (el && !el.contains(document.activeElement)) el.focus({ preventScroll: true })
    if (el) { const h = el.querySelector('h1, h2, h3, h4, b, strong'); const t = h?.textContent?.trim(); if (t) setAuto(t.slice(0, 80)) }
    return () => {
      const i = openSheets.indexOf(me)
      if (i >= 0) openSheets.splice(i, 1)
      // zaprt z gumbom ali tapom: vnos lista odstranimo z Nazaj — šele po tem opravilu, da ne povozimo navigacije,
      // ki jo je sprožil klicatelj (npr. »Prekinem trening?« → Danes) ali lista, ki se je odprl namesto tega
      if (!me.popped) setTimeout(() => { if (sheetOf(history.state) === me.id) { try { history.back() } catch { /* */ } } }, 0)
      if (!openSheets.length) backdropInert(false)   // pred vračanjem fokusa: v inert ozadje fokus ne gre
      if (prev && prev.isConnected) { try { prev.focus({ preventScroll: true }) } catch { /* */ } }
      // gumb, ki je list odprl, je izginil (izbrisana kartica): fokus na »Razveljavi«, ne na <body> (v3.48)
      else if (prev) setTimeout(() => {
        const a = document.activeElement
        if (a && a !== document.body) return
        document.querySelector<HTMLElement>('.toast.undo button')?.focus({ preventScroll: true })
      }, 0)
    }
  }, [])
  return createPortal(<>
    <div className="veil" onClick={onClose} />
    <div ref={ref} className="sheet" role="dialog" aria-modal="true" aria-label={label || auto} tabIndex={-1} style={{ outline: 'none' }}><div className="grab" />{children}</div>
  </>, document.body)
}

export function Sparkline({ values, width = 130, height = 40 }: { values: number[]; width?: number; height?: number }) {
  if (values.length < 2) return <svg width="100%" height={height} />
  const min = Math.min(...values), max = Math.max(...values), span = max - min || 1
  const pts = values.map((v, i) => [2 + (i / (values.length - 1)) * (width - 4), height - 6 - ((v - min) / span) * (height - 12)] as const)
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(' ')
  const last = pts[pts.length - 1]!
  const id = 'sp' + Math.round(width * 7 + height)
  return (
    <svg viewBox={`0 0 ${width} ${height}`} width="100%" height={height} preserveAspectRatio="none" aria-hidden="true">
      <defs><linearGradient id={id} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="var(--accent)" stopOpacity=".35" /><stop offset="1" stopColor="var(--accent)" stopOpacity="0" /></linearGradient></defs>
      <path className="spark-fill" d={`${d} L${last[0].toFixed(1)} ${height} L2 ${height} Z`} fill={`url(#${id})`} />
      <path className="spark-line" pathLength={1} d={d} fill="none" stroke="var(--accent-fg)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
    </svg>
  )
}

export const DAYS_SL = ['pon', 'tor', 'sre', 'čet', 'pet', 'sob', 'ned']
export const MONTHS_SL = ['januar', 'februar', 'marec', 'april', 'maj', 'junij', 'julij', 'avgust', 'september', 'oktober', 'november', 'december']
/** rodilnik za datume: »22. avgusta« */
export const MONTHS_GEN_SL = ['januarja', 'februarja', 'marca', 'aprila', 'maja', 'junija', 'julija', 'avgusta', 'septembra', 'oktobra', 'novembra', 'decembra']
export const DAYS_LONG_SL = ['Ponedeljek', 'Torek', 'Sreda', 'Četrtek', 'Petek', 'Sobota', 'Nedelja']
export function fmtDateLong(iso: string): string {
  const [y, m, d] = iso.split('-').map(Number) as [number, number, number]
  const dt = new Date(y, m - 1, d)
  return `${DAYS_LONG_SL[(dt.getDay() + 6) % 7]}, ${d}. ${MONTHS_GEN_SL[m - 1]}`
}
/** Števila po slovensko: skupine po tri z ozkim nedeljivim presledkom (1 840), minus kot »−«. */
export function fmtKcal(n: number): string {
  const v = Math.round(+n || 0), s = String(Math.abs(v))
  let out = ''
  for (let i = 0; i < s.length; i++) { if (i > 0 && (s.length - i) % 3 === 0) out += '\u202F'; out += s[i] }
  return (v < 0 ? '\u2212' : '') + out
}
