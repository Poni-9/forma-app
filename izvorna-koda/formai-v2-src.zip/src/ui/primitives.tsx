import { createPortal } from 'react-dom'
import type { ReactNode } from 'react'
import type { PlanKind } from '@/domain/types'
import { IcoCheck } from './icons'

/* ---- barve tipov (iz tokenov) ---- */
export const kindColor = (k: PlanKind | string): string =>
  k === 'kolo' || k === 'test' ? 'var(--t-kolo)' : k === 'moc' ? 'var(--t-moc)' : k === 'tek' || k === 'pohod' ? 'var(--t-tek)' : 'var(--t-poc)'
export const kindLabel = (k: PlanKind): string =>
  ({ kolo: 'Kolo', tek: 'Tek in hoja', pohod: 'Hoja', moc: 'Moč', pocitek: 'Počitek', test: 'Test' })[k]

export function Card({ children, tight, accent, className = '', style, onClick }: { children: ReactNode; tight?: boolean; accent?: boolean; className?: string; style?: React.CSSProperties; onClick?: () => void }) {
  return <div className={`card ${tight ? 'tight' : ''} ${accent ? 'accent' : ''} ${className}`} style={style} onClick={onClick}>{children}</div>
}

export function Chip({ children, on, sm, ok, onClick }: { children: ReactNode; on?: boolean; sm?: boolean; ok?: boolean; onClick?: () => void }) {
  const cls = `chip ${on ? 'on' : ''} ${sm ? 'sm' : ''} ${ok ? 'ok' : ''} ${onClick ? 'click' : ''}`
  return onClick ? <button type="button" className={cls} onClick={onClick}>{children}</button> : <span className={cls}>{children}</span>
}

export function Btn({ children, primary, ghost, block, sm, xs, disabled, onClick, type = 'button', style }: { children: ReactNode; primary?: boolean; ghost?: boolean; block?: boolean; sm?: boolean; xs?: boolean; disabled?: boolean; onClick?: () => void; type?: 'button' | 'submit'; style?: React.CSSProperties }) {
  return <button type={type} disabled={disabled} onClick={onClick} style={style} className={`btn ${primary ? 'primary' : ''} ${ghost ? 'ghost' : ''} ${block ? 'block' : ''} ${sm ? 'sm' : ''} ${xs ? 'xs' : ''}`}>{children}</button>
}

export function Option({ icon, title, sub, on, onClick, style }: { icon: ReactNode; title: string; sub?: string; on?: boolean; onClick?: () => void; style?: React.CSSProperties }) {
  return (
    <button type="button" className={`opt ${on ? 'on' : ''}`} onClick={onClick} style={style}>
      <div className="oi">{icon}</div>
      <div>{title}{sub && <small>{sub}</small>}</div>
    </button>
  )
}

export function Progress({ pct }: { pct: number }) { return <div className="prog"><i style={{ width: `${Math.max(0, Math.min(100, pct))}%` }} /></div> }

export function Ring({ size = 92, stroke = 9, pct, children }: { size?: number; stroke?: number; pct: number; children: ReactNode }) {
  const r = (size - stroke) / 2, c = 2 * Math.PI * r
  const p = Math.max(0, Math.min(1, pct))
  return (
    <div className="ring" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--raised)" strokeWidth={stroke} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--accent)" strokeWidth={stroke} strokeLinecap="round" strokeDasharray={`${c * p} ${c}`} />
      </svg>
      <div className="mid">{children}</div>
    </div>
  )
}

export function Track({ pct, color }: { pct: number; color: string }) { return <div className="track"><i style={{ width: `${Math.max(0, Math.min(100, pct))}%`, background: color }} /></div> }

export function CheckBtn({ on, onClick }: { on: boolean; onClick?: () => void }) {
  return <button type="button" className={`check ${on ? '' : 'off'}`} onClick={onClick} aria-label={on ? 'Opravljeno' : 'Označi kot opravljeno'}>{on ? <IcoCheck width={14} height={14} /> : ''}</button>
}

export function Empty({ icon, title, text, children }: { icon: ReactNode; title: string; text: string; children?: ReactNode }) {
  return (
    <div className="card" style={{ padding: 0 }}>
      <div className="empty">
        <div className="ico">{icon}</div>
        <h3>{title}</h3><p>{text}</p>
        {children}
      </div>
    </div>
  )
}

/** Spodnji list. V portalu na <body>: zaslon (.page) ima animiran transform, ki bi sicer ujel position: fixed pod zavihke. */
export function Sheet({ open, onClose, children }: { open: boolean; onClose: () => void; children: ReactNode }) {
  if (!open) return null
  return createPortal(<>
    <div className="veil" onClick={onClose} />
    <div className="sheet" role="dialog" aria-modal="true"><div className="grab" />{children}</div>
  </>, document.body)
}

export function Sparkline({ values, width = 130, height = 40 }: { values: number[]; width?: number; height?: number }) {
  if (values.length < 2) return <svg width="100%" height={height} />
  const min = Math.min(...values), max = Math.max(...values), span = max - min || 1
  const pts = values.map((v, i) => [2 + (i / (values.length - 1)) * (width - 4), height - 6 - ((v - min) / span) * (height - 12)] as const)
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(' ')
  const last = pts[pts.length - 1]!
  const id = 'sp' + Math.round(width * 7 + height)
  return (
    <svg viewBox={`0 0 ${width} ${height}`} width="100%" height={height} preserveAspectRatio="none" aria-hidden="true">
      <defs><linearGradient id={id} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="var(--accent)" stopOpacity=".35" /><stop offset="1" stopColor="var(--accent)" stopOpacity="0" /></linearGradient></defs>
      <path d={`${d} L${last[0].toFixed(1)} ${height} L2 ${height} Z`} fill={`url(#${id})`} />
      <path d={d} fill="none" stroke="var(--accent)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
    </svg>
  )
}

export const DAYS_SL = ['pon', 'tor', 'sre', 'čet', 'pet', 'sob', 'ned']
export const MONTHS_SL = ['januar', 'februar', 'marec', 'april', 'maj', 'junij', 'julij', 'avgust', 'september', 'oktober', 'november', 'december']
export const DAYS_LONG_SL = ['Ponedeljek', 'Torek', 'Sreda', 'Četrtek', 'Petek', 'Sobota', 'Nedelja']
export function fmtDateLong(iso: string): string {
  const [y, m, d] = iso.split('-').map(Number) as [number, number, number]
  const dt = new Date(y, m - 1, d)
  return `${DAYS_LONG_SL[(dt.getDay() + 6) % 7]}, ${d}. ${MONTHS_SL[m - 1]}`
}
/** Števila po slovensko: skupine po tri z ozkim nedeljivim presledkom (1 840), minus kot »−«. */
export function fmtKcal(n: number): string {
  const v = Math.round(+n || 0), s = String(Math.abs(v))
  let out = ''
  for (let i = 0; i < s.length; i++) { if (i > 0 && (s.length - i) % 3 === 0) out += '\u202F'; out += s[i] }
  return (v < 0 ? '\u2212' : '') + out
}
