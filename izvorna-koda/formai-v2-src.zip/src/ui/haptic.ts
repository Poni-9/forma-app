/** Kratek tresljaj ob dejanju, ki nekaj zapiše (opravljeno, shranjen obrok, teža). Samo kjer naprava zna; nikoli napaka. */
export function haptic(kind: 'tap' | 'ok' | 'warn' = 'ok'): void {
  try {
    if (typeof navigator === 'undefined' || typeof navigator.vibrate !== 'function') return
    navigator.vibrate(kind === 'tap' ? [8] : kind === 'ok' ? [14, 40, 20] : [40, 60, 40])
  } catch { /* brez vibracije */ }
}
