import { useApp, undoMissed } from '@/state/store'
import { addDays, weekStartIso } from '@/domain/training/load'
import type { PlanDay } from '@/domain/types'
import { Card } from '@/ui/primitives'
import { dayAcc } from '@/ui/format'

const ADJ = ['Nedeljski', 'Ponedeljkov', 'Torkov', 'Sredin', 'Četrtkov', 'Petkov', 'Sobotni']
const adj = (iso: string) => ADJ[new Date(iso + 'T12:00:00Z').getUTCDay()] ?? ''

/** Zamujeni ključni treningi tega tedna (zadnji 3 dnevi), ki jih je aplikacija sama prestavila, in kam. */
export function movedMissed(plan: readonly PlanDay[], today: string): { src: PlanDay; to: PlanDay }[] {
  const ws = weekStartIso(today), end = addDays(ws, 6)
  const out: { src: PlanDay; to: PlanDay }[] = []
  for (const src of plan) {
    if (src.missed !== 'moved' || src.date >= today || src.date < ws || src.date < addDays(today, -3)) continue
    const to = plan.find(x => x.adapt?.after === src.date && x.adapt.prev && !x.adapt.off && !x.done && x.date >= today && x.date <= end)
    if (to) out.push({ src, to })
  }
  return out
}

/**
 * Načrt se je sam spremenil, ker trening ni bil narejen — to mora biti vidno tudi po tem, ko obvestilo izgine:
 * »Torkov VO2max ni bil narejen → na četrtek« z »Razveljavi« (četrtek spet po načrtu, zamujeni ostane izpuščen).
 */
export function MovedCard() {
  const app = useApp()
  const list = movedMissed(app.plan, app.today)
  if (!list.length) return null
  return (
    <Card tight className="moved-card">
      <h2 className="h4" style={{ fontSize: 11, margin: 0 }}>Načrt se je prilagodil</h2>
      {list.map(({ src, to }) => (
        <div key={src.id} className="between" style={{ gap: 10, marginTop: 6, alignItems: 'center' }}>
          <p style={{ fontSize: 12.5, color: 'var(--ink-2)', minWidth: 0 }}>{adj(src.date)} {src.title} ni bil narejen → {to.date === app.today ? 'danes' : `na ${dayAcc(to.date)}`}.</p>
          <button type="button" className="chip sm click" style={{ flex: 'none' }} onClick={() => void undoMissed(src.id)}>Razveljavi</button>
        </div>
      ))}
    </Card>
  )
}
