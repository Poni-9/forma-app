/**
 * Imena zaslonov po poti (v3.48): naslov zavihka brskalnika (»Plan · FORMAI«) in pripomba (kaj je uporabnik gledal).
 * Prej je imela pripomba svoj seznam brez Vaj, Pripomb, Pregleda, Dogovora in Povabila (»vaje« z malo).
 */
export const SCREEN_NAME: Record<string, string> = {
  danes: 'Danes', plan: 'Plan', prehrana: 'Prehrana', trener: 'Trener', napredek: 'Napredek', nastavitve: 'Nastavitve',
  uvoz: 'Uvoz', aktivnosti: 'Aktivnosti', vadba: 'Vadba', uvod: 'Uvod', prijava: 'Prijava', vaje: 'Vaje',
  pripombe: 'Pripombe', pilot: 'Pregled', dogovor: 'Dogovor', claude: 'Povabilo',
}

/** Naslov strani za pot; neznana pot je Danes (tako jo izriše tudi App). */
export const pageTitle = (route: string): string => `${SCREEN_NAME[route] || 'Danes'} · FORMAI`
