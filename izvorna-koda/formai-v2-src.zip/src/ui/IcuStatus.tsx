import { navigate } from '@/app/router'
import { Btn } from './primitives'
import { IcoWarn } from './icons'
import { hhmmOf } from './format'

/** Zadnja napaka povezave z intervals.icu (app.icuErr); null, ko je vse v redu. */
export interface IcuErr { at: number; kind: 'auth' | 'quota' | 'network' | 'other'; msg: string; /** do kdaj ne kličemo (kvota), če ga shramba pozna */ until?: number | null }

/** Iz stanja aplikacije (polje je lahko še brez tipa ali ga ni). */
export function icuErrOf(app: unknown): IcuErr | null {
  const e = (app as { icuErr?: unknown } | null)?.icuErr as IcuErr | null | undefined
  return e && typeof e === 'object' && typeof e.msg === 'string' ? e : null
}

/** Do kdaj počakamo pri kvoti: `until`, sicer »~N min« iz sporočila, sicer 15 min od napake. */
export function quotaUntil(e: IcuErr): number {
  if (e.until && e.until > 0) return e.until
  const m = /~?\s*(\d+)\s*min/.exec(e.msg)
  return (e.at || Date.now()) + (m ? +m[1]! : 15) * 60_000
}

/** Kratko, po slovensko — enako na Danes, v Uvozu in ob »Preveri Garmin«. */
export function icuErrText(e: IcuErr): string {
  if (e.kind === 'auth') return 'intervals.icu ne sprejme več povezave (odjava ali preklican dostop). Poveži znova, da vožnje spet pridejo same.'
  if (e.kind === 'quota') return `intervals.icu trenutno omejuje zahtevke — počakam do ${hhmmOf(quotaUntil(e))} in nato nadaljujem sam.`
  if (e.kind === 'network') {
    // shramba da celo poved (»intervals.icu ni dosegljiv — preveri povezavo.«) ali »intervals.icu: HTTP 503«
    const http = /HTTP (\d{3})/.exec(e.msg)
    return http ? `intervals.icu trenutno ne odgovarja (HTTP ${http[1]}) — poskusim znova ob naslednjem odprtju.` : e.msg || 'intervals.icu ni dosegljiv — preveri povezavo.'
  }
  return e.msg
}

/** Ali napako še pokažemo (kvota po izteku ne, omrežje le 12 h). */
export function icuErrActive(e: IcuErr | null, now = Date.now()): e is IcuErr {
  if (!e) return false
  if (e.kind === 'quota') return quotaUntil(e) > now
  if (e.kind === 'network') return now - e.at < 12 * 3600_000
  return true
}

/**
 * Rezultat ročnega uvoza: syncIntervals() → { added, error?, kind? } ali starejše število novih (autoSyncIntervals).
 * added null = uvoz se ni zgodil; skipped = ni tekel (že teče, brez povezave), error je tedaj le razlog.
 */
export function syncResult(r: unknown): { added: number | null; error: string | null; skipped: boolean } {
  if (typeof r === 'number') return { added: r, error: null, skipped: false }
  if (r && typeof r === 'object') {
    const o = r as { added?: unknown; error?: unknown; kind?: unknown }
    // kind 'skipped': uvoz ni tekel (že teče, brez interneta …) — to ni napaka povezave
    return { added: typeof o.added === 'number' ? o.added : null, error: typeof o.error === 'string' && o.error ? o.error : null, skipped: o.kind === 'skipped' }
  }
  return { added: null, error: null, skipped: false }
}

/** Kartica z napako povezave: pri odjavi »Poveži znova« (v Uvoz), pri kvoti do kdaj čakamo. */
export function IcuErrorCard({ err, onUvoz = true, style }: { err: IcuErr; onUvoz?: boolean; style?: React.CSSProperties }) {
  const warn = err.kind === 'auth' ? 'var(--bad)' : 'var(--warn)'
  return (
    <div className="card tight" role="status" style={{ borderColor: warn, ...style }}>
      <div className="row" style={{ gap: 10, alignItems: 'flex-start' }}>
        <IcoWarn width={17} height={17} aria-hidden="true" style={{ color: warn, flex: 'none', marginTop: 1 }} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <b style={{ fontSize: 13.5 }}>{err.kind === 'auth' ? 'Povezava z intervals.icu je prekinjena' : err.kind === 'quota' ? 'intervals.icu: počakam' : 'Uvoz iz intervals.icu ni uspel'}</b>
          <p style={{ fontSize: 12.5, marginTop: 3, lineHeight: 1.45 }}>{icuErrText(err)}</p>
          {err.kind === 'auth' && onUvoz && <Btn sm style={{ marginTop: 10 }} onClick={() => navigate('uvoz')}>Poveži znova</Btn>}
        </div>
      </div>
    </div>
  )
}
