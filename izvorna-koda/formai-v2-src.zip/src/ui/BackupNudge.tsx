import { useEffect, useState } from 'react'
import { useApp, signIn, toast, markExported, LAST_EXPORT_KEY } from '@/state/store'
import { getKV, setKV, storagePersisted } from '@/data/db'
import { downloadBackup } from '@/data/backup'
import { backupNudgeDue, backupSnooze, BACKUP_SNOOZE_KEY } from '@/domain/start'
import { Card, Btn } from '@/ui/primitives'

/**
 * (v3.49) Brez računa je vse samo na tej napravi: po 7 dneh uporabe opomnik na Danes — prijava ali kopija v datoteko.
 * »Kasneje« = 30 dni miru (14, ko brskalnik shrambe ne zaščiti). Prej le »Zadnji izvoz: še nikoli« v zaprtih Nastavitvah.
 */
export function BackupNudge() {
  const app = useApp()
  const [kv, setKv] = useState<{ last: string | null; until: string | null } | null>(null)
  const [busy, setBusy] = useState(false)
  useEffect(() => {
    let on = true
    Promise.all([getKV<string>(LAST_EXPORT_KEY), getKV<string>(BACKUP_SNOOZE_KEY)])
      .then(([last, until]) => { if (on) setKv({ last: last || null, until: until || null }) })
      .catch(() => undefined)   // shramba ne dela: brez opomnika (napako pove že shramba sama)
    return () => { on = false }
  }, [])
  const p = app.profile
  const start = p.createdAt?.slice(0, 10) || p.goalStart?.date || null
  if (!kv || !backupNudgeDue({ user: !!app.user, onboardingDone: !!p.onboardingDone, start, today: app.today, lastExport: kv.last, until: kv.until })) return null

  async function later() {
    const until = backupSnooze(app.today, storagePersisted())
    setKv(k => (k ? { ...k, until } : k))
    try { await setKV(BACKUP_SNOOZE_KEY, until) } catch { /* ostane skrit do osvežitve */ }
  }
  async function save() {
    setBusy(true)
    try {
      // (v3.50) brez zamikov in brez GPS sledi (kot »Izvozi vse« privzeto)
      await downloadBackup(app.today)
      await markExported()
      setKv(k => (k ? { ...k, last: new Date().toISOString() } : k))
      toast('Kopija je shranjena. Z »Uvozi kopijo« jo vrneš na to ali drugo napravo.', 'ok', 7000)
    } catch { toast('Kopije ni bilo mogoče shraniti — poskusi v Nastavitvah → Podatki.', 'err') } finally { setBusy(false) }
  }
  async function login() {
    try { await signIn() } catch (e) { toast((e as Error).message, 'err') }
  }
  return (
    <Card tight style={{ marginTop: 12 }}>
      <b style={{ fontSize: 13.5 }}>Tvoj načrt je samo na tej napravi</b>
      <p className="muted" style={{ fontSize: 12.5, marginTop: 4 }}>Ob čiščenju brskalnika ali izgubi telefona bi ga izgubil. Shrani ga: prijava z Googlom (isti načrt tudi na drugih napravah) ali kopija v datoteko.</p>
      <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
        <Btn primary sm onClick={() => void login()}>Prijava z Googlom</Btn>
        <Btn ghost sm disabled={busy} onClick={() => void save()}>Izvozi kopijo</Btn>
        <Btn ghost sm onClick={() => void later()}>Kasneje</Btn>
      </div>
    </Card>
  )
}
