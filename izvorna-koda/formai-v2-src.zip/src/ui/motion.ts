import { useEffect, useRef, useState } from 'react'

/** Številka, ki se prišteje do cilja — za formo, kalorije, kilometre. Spoštuje prefers-reduced-motion. */
export function useCountUp(target: number, ms = 700): number {
  const [v, setV] = useState(target)
  const from = useRef(target)
  useEffect(() => {
    const reduce = typeof matchMedia !== 'undefined' && matchMedia('(prefers-reduced-motion: reduce)').matches
    if (reduce || !Number.isFinite(target)) { setV(target); from.current = target; return }
    const start = performance.now(), a = from.current, d = target - a
    if (Math.abs(d) < 0.5) { setV(target); from.current = target; return }
    let raf = 0
    const step = (t: number) => {
      const k = Math.min(1, (t - start) / ms)
      const e = 1 - Math.pow(1 - k, 3)
      setV(a + d * e)
      if (k < 1) raf = requestAnimationFrame(step); else from.current = target
    }
    raf = requestAnimationFrame(step)
    return () => cancelAnimationFrame(raf)
  }, [target, ms])
  return v
}

/** Ali aplikacija teče kot nameščena PWA (standalone). */
export function isStandalone(): boolean {
  return (typeof matchMedia !== 'undefined' && matchMedia('(display-mode: standalone)').matches) || (navigator as unknown as { standalone?: boolean }).standalone === true
}
export function isIOS(): boolean { return /iphone|ipad|ipod/i.test(navigator.userAgent) }
