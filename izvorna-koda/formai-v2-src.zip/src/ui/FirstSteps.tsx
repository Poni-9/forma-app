import { useState } from 'react'
import { navigate } from '@/app/router'
import { useApp, updateSettings } from '@/state/store'
import { InstallSheet } from './InstallSheet'
import { isStandalone } from './motion'
import { IcoCheck } from './icons'
import { isCustom } from '@/domain/focus/model'

/**
 * »Prvi koraki« za nove uporabnike: kar uvod namenoma ne vpraša (ura, tekme, začetni zaslon, račun).
 * Vsak korak se odkljuka sam, ko je opravljen; kartico lahko skriješ. Ko je vse opravljeno, izgine.
 * Na kratko (Blaž, 16. 10.: »kdo bo ta besedila bral«): vidiš samo naslednji korak, ostale odpre »še N«.
 */
export function FirstSteps() {
  const app = useApp()
  const [install, setInstall] = useState(false)
  const [all, setAll] = useState(false)
  const s = app.settings, p = app.profile
  if (s.startDone) return null
  const phone = typeof window !== 'undefined' && window.innerWidth < 900
  // načrt po meri: ura za tek in kardio; prvi trening z vpisanimi kilogrami namesto tekem sezone
  const custom = isCustom(p)
  const gym = custom && !!p.focus?.sessions.some(x => x.type === 'fitnes' || x.type === 'doma')
  const items = [
    { k: 'ura', t: 'Poveži uro', d: custom ? 'Garmin, COROS, Polar, Apple … prek brezplačnega intervals.icu — teki in vadbe pridejo sami.' : 'Garmin, Wahoo, COROS, Polar … prek brezplačnega intervals.icu — vožnje pridejo same.', done: !!s.intervals || app.activities.length > 0, go: () => navigate('uvoz') },
    ...(custom
      ? (gym ? [{ k: 'kg', t: 'Prvi trening s kilogrami', d: 'Začni trening na Danes in vpiši kilograme — naslednji trening jih prevzame in dviguje.', done: app.activities.some(a => a.sport === 'moc' && a.exercises?.some(e => e.kg)), go: () => { const g = app.plan.filter(d => d.kind === 'moc' && d.date >= app.today && !d.done).sort((a, b) => a.date.localeCompare(b.date))[0]; if (g && g.date === app.today) navigate('vadba', { id: g.id }); else navigate('plan', { dan: g?.date ?? app.today }) } }] : [])
      : [{ k: 'tekme', t: 'Dodaj tekme sezone', d: 'Cilji A, B in C — načrt pripravi vrh forme za vsak cilj.', done: !!p.event?.date || (p.races || []).length > 0, go: () => navigate('plan') }]),
    ...(phone ? [{ k: 'zaslon', t: 'Dodaj na začetni zaslon', d: 'Odpre se kot aplikacija, brez brskalnika.', done: isStandalone(), go: () => setInstall(true) }] : []),
    { k: 'racun', t: 'Shrani na vse naprave', d: 'Prijava z Googlom: varnostna kopija in isti načrt na telefonu in računalniku.', done: !!app.user, go: () => navigate('nastavitve', { sec: 'n-racun' }) },
  ]
  const n = items.filter(i => i.done).length
  if (n === items.length) return null
  const next = items.find(i => !i.done)!
  const rest = items.length - n - 1
  const shown = all ? items : [next]
  return (<>
    <div className="card tight" style={{ marginTop: 12 }}>
      <div className="between">
        <h2 className="h4" style={{ margin: 0, display: 'flex', alignItems: 'center', gap: 8 }}>Prvi koraki<span className="fs-prog" role="img" aria-label={`${n} od ${items.length} opravljenih`}>{items.map(i => <i key={i.k} className={i.done ? 'on' : ''} />)}</span></h2>
        <button className="chip sm click" onClick={() => void updateSettings({ startDone: true })}>skrij</button>
      </div>
      <div className="stack" style={{ gap: 2, marginTop: 8 }}>
        {shown.map(it => (
          <button key={it.k} type="button" className="fs-row" onClick={it.done ? undefined : it.go} disabled={it.done} aria-label={it.done ? `${it.t} — opravljeno` : it.t}>
            <span className={`fs-dot ${it.done ? 'on' : ''}`}>{it.done ? <IcoCheck width={12} height={12} /> : null}</span>
            <span style={{ flex: 1, minWidth: 0 }}><b style={{ textDecoration: it.done ? 'line-through' : 'none', color: it.done ? 'var(--ink-3)' : 'var(--ink)' }}>{it.t}</b>{!it.done && <small>{it.d}</small>}</span>
            {!it.done && <span className="muted" aria-hidden="true">›</span>}
          </button>
        ))}
      </div>
      {rest > 0 && <button type="button" className="chip sm click" style={{ marginTop: 6 }} aria-expanded={all} onClick={() => setAll(!all)}>{all ? 'manj' : `še ${rest} ${rest === 1 ? 'korak' : rest === 2 ? 'koraka' : rest <= 4 ? 'koraki' : 'korakov'}`}</button>}
    </div>
    <InstallSheet open={install} onClose={() => { setInstall(false); void updateSettings({ installPromptDismissedAt: new Date().toISOString() }) }} />
  </>)
}
