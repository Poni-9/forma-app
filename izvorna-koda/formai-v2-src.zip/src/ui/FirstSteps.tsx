import { useState } from 'react'
import { navigate } from '@/app/router'
import { useApp, updateSettings, type AppState } from '@/state/store'
import { InstallSheet } from './InstallSheet'
import { isStandalone } from './motion'
import { IcoCheck } from './icons'
import { isCustom } from '@/domain/focus/model'
import { noWatchIn, seasonCardOn, noRaceWish } from '@/domain/start'
import type { Activity, FocusSport, Profile } from '@/domain/types'

/**
 * »Prvi koraki« za nove uporabnike: kar uvod namenoma ne vpraša (ura, tekme, začetni zaslon, račun).
 * Vsak korak se odkljuka sam, ko je opravljen; kartico lahko skriješ. Ko je vse opravljeno, izgine.
 * Na kratko (Blaž, 16. 10.: »kdo bo ta besedila bral«): vidiš samo naslednji korak, ostale odpre »še N«.
 */
export function FirstSteps() {
  const app = useApp()
  const [install, setInstall] = useState(false)
  const [all, setAll] = useState(false)
  const s = app.settings, p = app.profile
  if (s.startDone) return null
  const phone = typeof window !== 'undefined' && window.innerWidth < 900
  // načrt po meri: ura za tek in kardio; prvi trening z vpisanimi kilogrami namesto tekem sezone
  const custom = isCustom(p)
  const gym = custom && !!p.focus?.sessions.some(x => x.type === 'fitnes' || x.type === 'doma')
  // (v3.49) kilogrami samo v fitnesu ali z ročkami doma; z lastno težo korak »Prvi trening« (ponovitve), sicer ga ni mogoče odkljukati
  const withKg = gym && !!p.focus && (p.focus.sessions.some(x => x.type === 'fitnes') || p.focus.equipment.includes('utezi') || p.focus.equipment.includes('fitnes'))
  const goStrength = () => { const g = app.plan.filter(d => d.kind === 'moc' && d.date >= app.today && !d.done).sort((a, b) => a.date.localeCompare(b.date))[0]; if (g && g.date === app.today) navigate('vadba', { id: g.id }); else navigate('plan', { dan: g?.date ?? app.today }) }
  const ura = watchStepText(p)
  const items = [
    ...(ura ? [{ k: 'ura', t: 'Poveži uro', d: ura, done: !!s.intervals, go: () => navigate('uvoz') }] : []),   // kdaj je opravljen: tuneSteps
    ...(custom
      ? (withKg ? [{ k: 'kg', t: 'Prvi trening s kilogrami', d: 'Začni trening na Danes in vpiši kilograme — naslednji trening jih prevzame in dviguje.', done: app.activities.some(a => a.sport === 'moc' && a.exercises?.some(e => e.kg)), go: goStrength }]
        : gym ? [{ k: 'kg', t: 'Prvi trening', d: 'Začni trening na Danes in vpiši ponovitve — v Napredku vidiš, kako rasteš.', done: app.activities.some(a => a.sport === 'moc' && !!a.exercises?.some(e => e.sets > 0)) || app.plan.some(d => d.kind === 'moc' && !!d.done), go: goStrength }] : [])
      : [{ k: 'tekme', t: 'Dodaj tekme sezone', d: 'Cilji A, B in C — načrt pripravi vrh forme za vsak cilj.', done: !!p.event?.date || (p.races || []).length > 0, go: () => navigate('plan') }]),
    ...(phone ? [{ k: 'zaslon', t: 'Dodaj na začetni zaslon', d: 'Odpre se kot aplikacija, brez brskalnika.', done: isStandalone(), go: () => setInstall(true) }] : []),
    { k: 'racun', t: 'Shrani na vse naprave', d: 'Prijava z Googlom: varnostna kopija in isti načrt na telefonu in računalniku.', done: !!app.user, go: () => navigate('nastavitve', { sec: 'n-racun' }) },
  ]
  tuneSteps(items, app)
  const n = items.filter(i => i.done).length
  if (n === items.length) return null
  const next = items.find(i => !i.done)!
  const rest = items.length - n - 1
  const shown = all ? items : [next]
  return (<>
    <div className="card tight" style={{ marginTop: 12 }}>
      <div className="between">
        <h2 className="h4" style={{ margin: 0, display: 'flex', alignItems: 'center', gap: 8 }}>Prvi koraki<span className="fs-prog" role="img" aria-label={`${n} od ${items.length} opravljenih`}>{items.map(i => <i key={i.k} className={i.done ? 'on' : ''} />)}</span></h2>
        <button className="chip sm click" onClick={() => void updateSettings({ startDone: true })}>skrij</button>
      </div>
      <div className="stack" style={{ gap: 2, marginTop: 8 }}>
        {shown.map(it => (
          <button key={it.k} type="button" className="fs-row" onClick={it.done ? undefined : it.go} disabled={it.done} aria-label={it.done ? `${it.t} — opravljeno` : it.t}>
            <span className={`fs-dot ${it.done ? 'on' : ''}`}>{it.done ? <IcoCheck width={12} height={12} /> : null}</span>
            <span style={{ flex: 1, minWidth: 0 }}><b style={{ textDecoration: it.done ? 'line-through' : 'none', color: it.done ? 'var(--ink-3)' : 'var(--ink)' }}>{it.t}</b>{!it.done && <small>{it.d}</small>}</span>
            {!it.done && <span className="muted" aria-hidden="true">›</span>}
          </button>
        ))}
      </div>
      {rest > 0 && <button type="button" className="chip sm click" style={{ marginTop: 6 }} aria-expanded={all} onClick={() => setAll(!all)}>{all ? 'manj' : `še ${rest} ${rest === 1 ? 'korak' : rest === 2 ? 'koraka' : rest <= 4 ? 'koraki' : 'korakov'}`}</button>}
    </div>
    <InstallSheet open={install} onClose={() => { setInstall(false); void updateSettings({ installPromptDismissedAt: new Date().toISOString() }) }} />
  </>)
}

/** (v3.50) ura je omenjena v želji (znamka, »pametna ura«, »z uro«) — ne »3 ure na teden« */
const WATCH_WISH = /garmin|coros|polar|suunto|wahoo|zwift|apple watch|pametn\p{L}* ur|športn\p{L}* ur|\bz uro\b/iu
/**
 * (v3.50) Besedilo koraka »Poveži uro« po tem, kar dogovor vsebuje; null = koraka ni (samo fitnes ali hoja brez ure —
 * prej je 16-letnik v fitnesu bral »teki in vadbe pridejo sami«). Apple Watch ni med urami: z intervals.icu se ne
 * poveže neposredno.
 */
export function watchStepText(p: Pick<Profile, 'focus'>): string | null {
  if (!isCustom(p)) return 'Garmin, Wahoo, COROS, Polar … prek brezplačnega intervals.icu — vožnje pridejo same.'
  const f = p.focus!
  const has = (t: FocusSport) => f.sports.includes(t) || f.sessions.some(x => x.type === t)
  const words = [has('kolo') ? 'vožnje' : null, has('tek') ? 'teki' : null].filter((w): w is string => !!w)
  if (!words.length && !WATCH_WISH.test(f.wish || '')) return null
  if (has('hribi')) words.push('hoja')
  const what = !words.length ? 'vadbe pridejo same' : words.length === 1 && words[0] === 'vožnje' ? 'vožnje pridejo same' : words.length === 1 && words[0] === 'hoja' ? 'hoja pride sama' : `${words.join(' in ')} pridejo sami`
  return `Garmin, COROS, Polar, Suunto … prek brezplačnega intervals.icu — ${what}.`
}

type StepItem = { k: string; t: string; d: string; done: boolean; go: () => void }
/** Vadbe, ki so prišle z naprave (ne ročni vnos, ne zapis iz načrta). */
const FROM_DEVICE = new Set<Activity['source']>(['file', 'archive', 'screenshot', 'recorder'])
/**
 * (v3.49) »Poveži uro« se odkljuka samo z res povezano uro (intervals.icu) — ne z ročnim vnosom, posnetkom ali eno datoteko.
 * Pa vendar: vsaj 10 vadb iz datotek, arhiva ali posnetkov pomeni, da uporabnik svoje vadbe že dobiva — kartica se mu
 * po nadgradnji ne vrne. Kdor je napisal »Nimam ure« (in ure ni povezal), ima namesto nje »Po treningu tapni Opravil«.
 * »Dodaj tekme sezone« odpre razdelek tekem v Planu; izpade, ko je na Danes že kartica »Cilj sezone« (isti korak).
 */
function tuneSteps(items: StepItem[], app: AppState): void {
  const p = app.profile, s = app.settings
  const ura = items.findIndex(i => i.k === 'ura')
  if (ura >= 0) {
    items[ura]!.done = !!s.intervals || app.activities.some(a => a.source === 'intervals') || app.activities.filter(a => FROM_DEVICE.has(a.source)).length >= 10
    if (!items[ura]!.done && noWatchIn(p.focus?.wish)) {
      const next = app.plan.filter(d => d.kind !== 'pocitek' && !d.optional && !d.done && d.date >= app.today).sort((a, b) => a.date.localeCompare(b.date))[0]
      items[ura] = {
        k: 'opravil', t: 'Po treningu tapni »Opravil«', d: 'Tako načrt ve, kaj si naredil — šteje v teden, formo in kalorije.',
        done: app.plan.some(d => d.kind !== 'pocitek' && !!d.done),
        go: () => (next && next.date !== app.today ? navigate('plan', { dan: next.date }) : window.scrollTo({ top: 0, behavior: 'smooth' })),
      }
    }
  }
  const tekme = items.findIndex(i => i.k === 'tekme')
  if (tekme >= 0) {
    // (v3.50) tudi kdor je povedal, da nima tekme (zdravje) — brez poziva k dirki
    if ((seasonCardOn(p) && !(p.races || []).length) || noRaceWish(p)) items.splice(tekme, 1)
    else items[tekme]!.go = () => navigate('plan', { sec: 'pl-tekme' })
  }
}
