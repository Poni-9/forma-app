import { useEffect, useState } from 'react'

/**
 * (v3.50) List »Trening s slike« odpreš od koder koli (Danes, »Včeraj … si ga naredil?«, Uvoz, Plan, Trener, Profil) —
 * en gostitelj (OverlayHost) ga izriše. done = opravljen trening odkljuka dan; plan = trening s slike v načrt;
 * self = slika sebe → predlog vaj.
 */
export type PhotoMode = 'done' | 'plan' | 'self'
export interface PhotoReq {
  mode: PhotoMode
  /** dan načrta, ki naj se odkljuka (done) */
  dayId?: string | null
  /** dan, kamor gre trening (plan) */
  date?: string | null
  /** slika je že izbrana (Uvoz) — branje se začne takoj */
  file?: File | null
}
let cur: PhotoReq | null = null
let seq = 0
const subs = new Set<() => void>()
const emit = () => { for (const s of subs) s() }

export function openPhotoTraining(r: PhotoReq): void { cur = r; seq++; emit() }
export function closePhotoTraining(): void { cur = null; emit() }
/** Trenutni zahtevek (za preizkuse). */
export function photoReq(): PhotoReq | null { return cur }

/** Odprt list (in zaporedna številka — vsako odprtje je nov list s svežim stanjem). */
export function usePhotoTraining(): { req: PhotoReq | null; key: number } {
  const [, set] = useState(0)
  useEffect(() => { const f = () => set(x => x + 1); subs.add(f); return () => { subs.delete(f) } }, [])
  return { req: cur, key: seq }
}
