import { useRef } from 'react'
import { MONTHS_GEN_SL } from './primitives'
import { IcoCal } from './icons'

/** »13. junija 2027« — datum po slovensko, ne glede na jezik brskalnika. */
export function fmtDateSl(iso: string, withYear = true): string {
  const [y, m, d] = iso.split('-').map(Number) as [number, number, number]
  if (!y || !m || !d) return iso
  return `${d}. ${MONTHS_GEN_SL[m - 1]}${withYear ? ` ${y}` : ''}`
}

/** »13. 9. 2027« — kratko, za ozka polja. */
export function fmtDateNum(iso: string): string {
  const [y, m, d] = iso.split('-').map(Number) as [number, number, number]
  return y && m && d ? `${d}. ${m}. ${y}` : iso
}

/**
 * Polje za datum, ki vedno kaže slovenski zapis (brskalnik v angleščini bi sicer kazal mm/dd/yyyy).
 * Pod prikazom je pravi <input type="date">: dotik odpre sistemski izbirnik (telefon), klik ga odpre prek showPicker (računalnik).
 */
export function DateField({ value, onChange, min, max, placeholder = 'Izberi datum', label, compact }: { value: string | null | undefined; onChange: (iso: string) => void; min?: string; max?: string; placeholder?: string; label?: string; /** ozko polje: »13. 9. 2027« */ compact?: boolean }) {
  const ref = useRef<HTMLInputElement>(null)
  const open = () => { const el = ref.current as (HTMLInputElement & { showPicker?: () => void }) | null; try { el?.showPicker?.() } catch { el?.focus() } }
  return (
    <div className="datefield">
      <span className={value ? '' : 'ph'}>{value ? (compact ? fmtDateNum(value) : fmtDateSl(value)) : placeholder}</span>
      <IcoCal width={18} height={18} />
      <input ref={ref} type="date" value={value || ''} min={min} max={max} aria-label={label || placeholder} onChange={e => onChange(e.target.value)} onClick={open} />
    </div>
  )
}
