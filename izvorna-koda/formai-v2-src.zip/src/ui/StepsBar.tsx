import type { Step } from '@/domain/training/workout'
import { fmtStep } from '@/domain/training/workout'

/**
 * PROFIL VADBE (v3.47): koraki kot stolpci — širina = trajanje, višina in barva = cona. Intervali se vidijo na prvi
 * pogled (»Kolo — intervali« = zobje, lahka vožnja = ravna črta), brez branja seznama korakov. Bralnik zaslona dobi
 * seznam korakov kot besedilo.
 */
const H: Record<string, number> = { Z1: 0.28, Z2: 0.42, Z3: 0.6, Z4: 0.8, Z5: 0.95, max: 1 }
const C: Record<string, string> = { Z1: 'var(--z1)', Z2: 'var(--z2)', Z3: 'var(--z3)', Z4: 'var(--z4)', Z5: 'var(--z5)', max: 'var(--z5)' }
/** Barva cone (tudi obroč koraka v vodeni vadbi, v3.48). */
export const ZONE_C: Readonly<Record<string, string>> = C

export function StepsBar({ steps, height = 44 }: { steps: readonly Step[]; height?: number }) {
  const list = steps.filter(s => s.sec > 0)
  const total = list.reduce((t, s) => t + s.sec, 0)
  if (list.length < 2 || !total) return null
  const label = `Profil vadbe: ${list.map(s => `${fmtStep(s.sec)} ${s.kind === 'ogrevanje' ? 'ogrevanje' : s.kind === 'iztek' ? 'iztek' : s.label}${s.z ? ` (${s.z})` : ''}`).join(', ')}`
  return (
    <div className="steps-bar" role="img" aria-label={label} style={{ height }}>
      {list.map((s, i) => {
        const z = s.z ?? (s.kind === 'pavza' || s.kind === 'lahko' ? 'Z1' : 'Z2')
        return <i key={i} style={{ flexGrow: s.sec, height: `${Math.round((H[z] ?? 0.4) * 100)}%`, background: C[z] ?? 'var(--z2)' }} />
      })}
    </div>
  )
}
