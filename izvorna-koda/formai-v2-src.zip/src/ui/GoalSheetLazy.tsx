import { Suspense } from 'react'
import { retryLazy } from '@/app/chunk'
import { ChunkBoundary } from '@/ui/ChunkBoundary'

/**
 * (v3.50) List »Cilj sezone« (GoalSheet) za kartice na Danes: ni v začetnem paketu, prenese se ob prvem odprtju
 * (ali z Načrtom ob mirovanju). Isti vmesnik kot GoalSheet.
 */
// (v3.50) del kode se ne naloži: enkrat osveži, nato list z »Osveži« (prej je padel zaslon Danes)
// (v3.51) po neuspehu naslednji izris prenaša znova (prej do osvežitve)
const L = retryLazy(() => import('./GoalSheet').then(m => m.GoalSheet))
export function GoalSheet(p: { open: boolean; onClose: () => void }) {
  return <ChunkBoundary onClose={p.onClose} label="Cilj sezone"><Suspense fallback={null}><L {...p} /></Suspense></ChunkBoundary>
}
