import { lazy, Suspense } from 'react'
import { orReload } from '@/app/chunk'
import { ChunkBoundary } from '@/ui/ChunkBoundary'

/**
 * (v3.50) List »Cilj sezone« (GoalSheet) za kartice na Danes: ni v začetnem paketu, prenese se ob prvem odprtju
 * (ali z Načrtom ob mirovanju). Isti vmesnik kot GoalSheet.
 */
// (v3.50) del kode se ne naloži: enkrat osveži, nato list z »Osveži« (prej je padel zaslon Danes)
const L = lazy(() => orReload(import('./GoalSheet').then(m => ({ default: m.GoalSheet }))))
export function GoalSheet(p: { open: boolean; onClose: () => void }) {
  return <ChunkBoundary onClose={p.onClose}><Suspense fallback={null}><L {...p} /></Suspense></ChunkBoundary>
}
