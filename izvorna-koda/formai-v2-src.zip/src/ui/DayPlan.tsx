import { useMemo } from 'react'
import { useApp } from '@/state/store'
import { stepsFor, structureLines } from '@/domain/training/workout'
import { rideFuel, fuelCtxOf } from '@/domain/nutrition/dayplan'
import { dailyTarget } from '@/domain/nutrition/energy'
import type { PlanDay } from '@/domain/types'
import { RouteCard } from '@/ui/RouteCard'
import { checkRide } from '@/domain/training/review'
import { kcal, nb, NBSP } from '@/ui/format'
import { HealthNote } from '@/ui/HealthNote'

/** Načrt dneva v Planu: kaj te čaka (z vati), trasa, gorivo in koliko jesti ta dan. */
export function DayPlan({ day, food = true, note = false }: {
  day: PlanDay
  /** »Prehrana ta dan« samo enkrat na dan (pri prvem treningu dneva) */
  food?: boolean
  /** zdravstveno opozorilo ob kalorijah dneva (zaslon ga potem ne ponovi na dnu) */
  note?: boolean
}) {
  const app = useApp()
  const p = app.profile
  const ride = day.kind === 'kolo' || day.kind === 'test'
  const lines = useMemo(() => (ride ? structureLines(stepsFor(day, p)) : []), [day, p, ride])
  const rf = ride ? rideFuel(day, p.fuelKit, fuelCtxOf(app.weather, app.recentMeals, day.date, app.today)) : null
  const t = dailyTarget(p, app.activities.filter(a => a.date === day.date), app.plan.filter(d => d.date === day.date), day.date)
  const h = { fontSize: 10.5, fontWeight: 800, letterSpacing: '.08em', color: 'var(--ink-3)', textTransform: 'uppercase' as const, marginTop: 12 }
  const act = day.done?.activityId ? app.activities.find(a => a.id === day.done!.activityId) : null
  const chk = act ? checkRide(day, act) : null
  return (
    <div>
      {chk && <div style={{ marginTop: 10 }}>
        <div style={{ fontSize: 12.5, fontWeight: 700, color: chk.status === 'ok' ? 'var(--ok)' : chk.status === 'delno' ? 'var(--warn)' : 'var(--bad)' }}>{chk.verdict}</div>
        <div className="muted" style={{ fontSize: 12, marginTop: 2 }}>{chk.detail}</div>
      </div>}
      {lines.length > 0 && <>
        <div style={h}>Kaj te čaka</div>
        <ol style={{ margin: '4px 0 0 18px', padding: 0, fontSize: 12.5, color: 'var(--ink-2)', lineHeight: 1.55 }}>{lines.map((l, j) => <li key={j}>{nb(l)}</li>)}</ol>
      </>}
      {ride && !day.done && <RouteCard day={day} compact inCard={false} />}
      {rf && rf.totalCarbs > 0 && <>
        <div style={h}>Gorivo</div>
        <div style={{ fontSize: 12.5, marginTop: 4, color: 'var(--ink-2)' }}>{nb(rf.items.join(' · '))}</div>
        <div className="muted" style={{ fontSize: 12, marginTop: 3 }}>{nb(rf.schedule)}</div>
      </>}
      {t && food && <>
        <div style={h}>Prehrana ta dan</div>
        <div style={{ fontSize: 12.5, marginTop: 4, color: 'var(--ink-2)' }}>{kcal(t.kcal)} · beljakovine {t.proteinG}{NBSP}g · OH {t.carbsG}{NBSP}g{t.deficit > 0 ? ` · deficit ${kcal(t.deficit)}${t.deficitNote ? ` (${t.deficitNote})` : ''}` : t.deficitNote ? ` · ${t.deficitNote}` : ''}</div>
        {note && <HealthNote kind="both" style={{ marginTop: 8 }} />}
      </>}
    </div>
  )
}
