import { useMemo } from 'react'
import { useApp } from '@/state/store'
import { stepsFor, structureLines } from '@/domain/training/workout'
import { rideFuel } from '@/domain/nutrition/dayplan'
import { dailyTarget } from '@/domain/nutrition/energy'
import type { PlanDay } from '@/domain/types'
import { RouteCard } from '@/ui/RouteCard'

/** Načrt dneva v Planu: kaj te čaka (z vati), trasa, gorivo in koliko jesti ta dan. */
export function DayPlan({ day }: { day: PlanDay }) {
  const app = useApp()
  const p = app.profile
  const ride = day.kind === 'kolo' || day.kind === 'test'
  const lines = useMemo(() => (ride ? structureLines(stepsFor(day, p)) : []), [day, p, ride])
  const rf = ride ? rideFuel(day) : null
  const t = dailyTarget(p, app.activities.filter(a => a.date === day.date), app.plan.filter(d => d.date === day.date), day.date)
  const h = { fontSize: 10.5, fontWeight: 800, letterSpacing: '.08em', color: 'var(--ink-3)', textTransform: 'uppercase' as const, marginTop: 12 }
  return (
    <div>
      {lines.length > 0 && <>
        <div style={h}>Kaj te čaka</div>
        <ol style={{ margin: '4px 0 0 18px', padding: 0, fontSize: 12.5, color: 'var(--ink-2)', lineHeight: 1.55 }}>{lines.map((l, j) => <li key={j}>{l}</li>)}</ol>
      </>}
      {ride && !day.done && <RouteCard day={day} compact inCard={false} />}
      {rf && rf.totalCarbs > 0 && <>
        <div style={h}>Gorivo</div>
        <div style={{ fontSize: 12.5, marginTop: 4, color: 'var(--ink-2)' }}>{rf.items.join(' · ')}</div>
        <div className="muted" style={{ fontSize: 12, marginTop: 3 }}>{rf.schedule}</div>
      </>}
      {t && <>
        <div style={h}>Prehrana ta dan</div>
        <div style={{ fontSize: 12.5, marginTop: 4, color: 'var(--ink-2)' }}>{t.kcal} kcal · beljakovine {t.proteinG} g · OH {t.carbsG} g{t.deficit > 0 ? ` · deficit ${t.deficit} kcal${t.deficitNote ? ` (${t.deficitNote})` : ''}` : t.deficitNote ? ` · ${t.deficitNote}` : ''}</div>
      </>}
    </div>
  )
}
