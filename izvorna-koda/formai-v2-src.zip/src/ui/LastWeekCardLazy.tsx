import { Suspense } from 'react'
import { useApp } from '@/state/store'
import { weekStartIso } from '@/domain/training/load'
import { retryLazy } from '@/app/chunk'
import { ChunkBoundary } from '@/ui/ChunkBoundary'

/**
 * (v3.51) »Pretekli teden« je samo ob ponedeljkih — kartica (in povzetek tedna) ni v začetnem paketu. Isti vmesnik.
 */
const L = retryLazy(() => import('./LastWeekCard').then(m => m.LastWeekCard))
export function LastWeekCard() {
  const app = useApp()
  if (app.today !== weekStartIso(app.today)) return null
  // (v3.51) neuspel prenos: kartice ni (poskusi znova ob vrnitvi povezave) — prej je padel cel zaslon Danes
  return <ChunkBoundary inline="hide"><Suspense fallback={null}><L /></Suspense></ChunkBoundary>
}
