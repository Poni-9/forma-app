import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { navigate } from '@/app/router'
import { useApp, getState, toast, signIn, warmAuth } from '@/state/store'
import { saveDoneShot, addPhotoWorkout, addSelfSessions } from '@/state/photoTraining'
import { useAi } from '@/ui/useAi'
import { useOnline } from '@/ui/useOnline'
import { PhotoInput } from '@/ui/PhotoInput'
import { Sheet, Chip, Btn, DecimalInput } from '@/ui/primitives'
import { DateField } from '@/ui/DateField'
import { undoToast, useConfirm } from '@/ui/Confirm'
import { closePhotoTraining, type PhotoReq } from '@/ui/photoOpen'
import { doneFromPhoto, workoutFromPhoto, selfFromPhoto, selfAvailable, MINOR_SELF, NO_AGE_SELF } from '@/domain/ai/photoTraining'
import { SELF_PHOTO_CONSENT_V } from '@/domain/ai/consent'
import {
  doneDayOptions, pickDoneDay, fitsDay, shotErrors, draftErrors, draftToPlanDay, draftMinutes, replaceOptions, selfSessions,
  raceLike, durationNote, startNowWarn, matchExercise, defaultRest, fmtS, inLim, repsOf, atOf, PHOTO_LIMITS, type PhotoWorkout, type PhotoKind, type PhotoBlock, type SelfAdvice,
} from '@/domain/training/fromPhoto'
import { stepsFor, structureLines } from '@/domain/training/workout'
import { addDays, titleNoDur } from '@/domain/training/load'
import { dm, dayName } from '@/ui/format'
import type { Activity, PlanDay, Sport } from '@/domain/types'
import { rem } from '@/ui/rem'

/**
 * (v3.50) LIST »TRENING S SLIKE« — trije načini (Blaž: »da dam sliko in mi naredi trening« … »vse troje«):
 * done — posnetek opravljenega treninga (ura, Zwift, trenažer, fitnes naprava) → aktivnost in kljukica v načrtu;
 * plan — slika treninga (tabla, list, objava) → predogled, ki ga urediš → »Dodaj v načrt« ali »Začni zdaj«;
 * self — slika sebe → 2–3 poudarki in kratka seja po želji (samo odrasli).
 * Slika gre v AI samo po privolitvi in se ne shrani. Brez povezave: jasno sporočilo in ročna pot.
 */

const PRIVACY = 'Slika gre samo v branje (AI) in se ne shrani.'
/** prijavljen (ali prijava še ni znana); (v3.51) testna gradnja teče brez prijave kot useAi — sicer poti s sliko ni mogoče preveriti */
const canRead = (app: { user: unknown; authKnown: boolean }) => !!app.user || !app.authKnown || import.meta.env.VITE_E2E === '1'
// (v3.51) »Ned 25. 10.« z veliko začetnico kot »Danes«, »Jutri« v istem seznamu (v obvestilu z malo)
const dayLbl = (iso: string, today: string): string =>
  iso === today ? 'Danes' : iso === addDays(today, -1) ? 'Včeraj' : iso === addDays(today, 1) ? 'Jutri' : `${dayName(iso).charAt(0).toUpperCase()}${dayName(iso).slice(1, 3)} ${dm(iso)}`

export function PhotoTrainingSheet({ req }: { req: PhotoReq }) {
  const ai = useAi()
  const label = req.mode === 'done' ? 'Slikaj opravljen trening' : req.mode === 'plan' ? 'Trening s slike' : 'Predlog s slike'
  // (v3.51) prebrano s slike (predogled, popravki): Esc, Nazaj ali tap ob listu najprej vpraša
  const [dirty, setDirty] = useState(false)
  return (<>
    <Sheet open onClose={closePhotoTraining} label={label} guard={dirty ? (req.mode === 'self' ? 'Zavržem predlog s slike?' : 'Zavržem prebrani trening?') : null}>
      {req.mode === 'done' ? <DoneMode req={req} ai={ai} onDirty={setDirty} /> : req.mode === 'plan' ? <PlanMode req={req} ai={ai} onDirty={setDirty} /> : <SelfMode ai={ai} onDirty={setDirty} />}
    </Sheet>
    {ai.sheet}
  </>)
}
type Ai = ReturnType<typeof useAi>

/** Brez povezave: kaj se zgodi in ročna pot (namesto gumba za sliko). */
function Offline({ text, children }: { text: string; children?: ReactNode }) {
  return (
    <div className="ph-off" role="status">
      <b>Ni povezave z internetom</b>
      <p>{text}</p>
      {children}
    </div>
  )
}
/**
 * (v3.51) Brez prijave: najprej »Prijava z Googlom« (dotik gumba odpre Google takoj), šele nato izbira slike — prej je
 * izbrana slika šele sprožila prijavo, brskalnik je okno blokiral, preusmeritev pa je izgubila sliko in list.
 */
function SignInFirst() {
  useEffect(() => { warmAuth() }, [])
  return (
    <div style={{ marginTop: 12 }}>
      <p className="muted" style={{ fontSize: rem(12.5) }}>Branje slike teče prek AI in rabi prijavo.</p>
      <Btn primary block style={{ marginTop: 8 }} onClick={() => void signIn().catch(() => toast('Prijava ni uspela — poskusi znova.', 'err'))}>Prijava z Googlom</Btn>
    </div>
  )
}
/**
 * (v3.51) Branje slike ni uspelo: razlog v listu (role=alert) z »Poskusi znova« (ista slika) in ročno potjo — prej
 * obvestilo nad listom, list pa na začetku brez slike.
 */
function useRead(ai: Ai, consentV?: number) {
  const [err, setErr] = useState<string | null>(null)
  const last = useRef<File | null>(null)
  function read<T>(file: File, fn: () => Promise<T>): Promise<T | undefined> {
    last.current = file; setErr(null)
    // (v3.51) slika sebe: zahtevana različica privolitve gre v run — list pove, zakaj sprašuje znova (F14, H19)
    return ai.run(fn, { quiet: true, onError: m => setErr(m), ...(consentV ? { consentV } : {}) })
  }
  return { err, last, read }
}
function ReadErr({ msg, busy, onRetry, onManual, manualLabel = 'Vpiši ročno' }: { msg: string; busy: boolean; onRetry: () => void; onManual: () => void; manualLabel?: string }) {
  return (
    <div className="ph-off" role="alert" style={{ borderColor: 'var(--bad)' }}>
      <b>Branje ni uspelo</b>
      <p>{msg}</p>
      <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
        <Btn primary sm disabled={busy} onClick={onRetry}>{busy ? 'Berem …' : 'Poskusi znova'}</Btn>
        <Btn ghost sm onClick={onManual}>{manualLabel}</Btn>
      </div>
    </div>
  )
}
/** Ena slika naenkrat; isto sliko (Uvoz) prebere takoj ob odprtju. */
function usePickOnce(file: File | null | undefined, pick: (f: File) => void) {
  const done = useRef(false)
  useEffect(() => { if (file && !done.current) { done.current = true; pick(file) } }, [file]) // eslint-disable-line react-hooks/exhaustive-deps
}

/* ================= 1) opravljen trening ================= */
const SPORTS: { k: Sport; l: string }[] = [{ k: 'kolo', l: 'Kolo' }, { k: 'tek', l: 'Tek' }, { k: 'pohod', l: 'Hribi' }, { k: 'moc', l: 'Moč' }, { k: 'plavanje', l: 'Plavanje' }, { k: 'drugo', l: 'Drugo' }]
const isTest = (d: Pick<PlanDay, 'kind' | 'role'>) => d.kind === 'test' || d.role === 'test'
const raceNote = (d: Pick<PlanDay, 'kind' | 'role'>) => (isTest(d) ? 'To je test — izberi ga samo, če je bil to res ta test.' : 'To je tekma — izberi jo samo, če je bila to res tvoja tekma.')
type ShotKey = 'min' | 'dist' | 'elev' | 'hr' | 'power' | 'kcal'
const SHOT_ID: Record<ShotKey, string> = { min: 'ph-min', dist: 'ph-km', elev: 'ph-elev', hr: 'ph-hr', power: 'ph-w', kcal: 'ph-kcal' }

function DoneMode({ req, ai, onDirty }: { req: PhotoReq; ai: Ai; onDirty?: (d: boolean) => void }) {
  const app = useApp()
  const online = useOnline()
  const [shot, setShot] = useState<Activity | null>(null)
  useEffect(() => { onDirty?.(!!shot) }, [shot])  // eslint-disable-line react-hooks/exhaustive-deps
  const [dayId, setDayId] = useState<string | null>(null)
  const [touched, setTouched] = useState<Partial<Record<ShotKey, boolean>>>({})
  const [saving, setSaving] = useState(false)
  const pref = req.dayId ? app.plan.find(d => d.id === req.dayId) ?? null : null
  const manualDate = pref?.date ?? app.today
  const manual = () => { closePhotoTraining(); navigate('aktivnosti', { nova: '1', datum: manualDate }) }

  const rd = useRead(ai)
  async function pick(file: File) {
    const a = await rd.read(file, () => doneFromPhoto(getState().profile, file, getState().today))
    if (!a) return
    const s = getState()
    const d = pickDoneDay(a, s.plan, s.today, req.dayId)
    setDayId(d?.id ?? null)
    setShot(d ? { ...a, date: d.date } : a)
    setTouched({})
  }
  usePickOnce(req.file, f => { void pick(f) })

  if (!shot) return (<>
    <h2 className="sheet-t">Slikaj opravljen trening</h2>
    <p className="muted" style={{ fontSize: rem(13), marginTop: 4 }}>
      Zaslon ure, Zwifta, trenažerja ali fitnes naprave (tekalna steza, sobno kolo, veslo). Preberem čas, razdaljo in utrip{pref ? <> in odkljukam <b>{titleNoDur(pref.title, pref.durationMin)}</b></> : ' in odkljukam trening v načrtu'}.
    </p>
    {online ? (
      canRead(app) ? <div style={{ marginTop: 12 }}><PhotoInput onPick={f => void pick(f)} busy={ai.busy} label="Slikaj ali izberi posnetek" hint={`Posnetkov iz Strave ne nalagaj — trener jih ne sme uporabiti. ${PRIVACY}`} /></div> : <SignInFirst />
    ) : (
      <Offline text="Branje slike rabi AI. Trening lahko vpišeš ročno — dan je že izbran.">
        <Btn primary block sm style={{ marginTop: 10 }} onClick={manual}>Vpiši ročno</Btn>
      </Offline>
    )}
    {online && rd.err && <ReadErr msg={rd.err} busy={ai.busy} onRetry={() => { if (rd.last.current) void pick(rd.last.current) }} onManual={manual} />}
    {online && !rd.err && <button type="button" className="chip sm click" style={{ marginTop: 10 }} onClick={manual}>raje vpišem ročno</button>}
  </>)

  const opts = doneDayOptions(app.plan, app.today)
  const sel = dayId ? opts.find(d => d.id === dayId) ?? null : null
  const fits = !!sel && fitsDay(shot, sel)
  // (v3.51) tekma ali test istega dne se ne odkljuka sam — namig, da ga izbereš, ali opozorilo, ko je izbran
  const raceThere = !sel ? opts.find(d => d.date === shot.date && raceLike(d) && fitsDay(shot, d)) : undefined
  const err = shotErrors(shot)
  const shown = (Object.keys(err) as ShotKey[]).filter(k => touched[k])
  const fx = (k: ShotKey) => { const bad = shown.includes(k); return { onBlur: () => setTouched(t => (t[k] ? t : { ...t, [k]: true })), 'aria-invalid': bad || undefined, 'aria-describedby': bad ? 'ph-err' : undefined, style: bad ? { borderColor: 'var(--warn)' } : undefined } }
  const n = (v: string) => (v.trim() ? +v.replace(',', '.') : null)
  // posnetek iz Strave: shrani se, trener ga ne vidi (Stravina pravila)
  const strava = !shot.aiEligible

  async function save() {
    if (!shot) return
    const keys = Object.keys(err) as ShotKey[]
    if (keys.length) { setTouched(t => ({ ...t, ...Object.fromEntries(keys.map(k => [k, true])) })); document.getElementById(SHOT_ID[keys[0]!])?.focus(); return }
    setSaving(true)
    try {
      const r = await saveDoneShot(shot, fits ? sel!.id : null)
      closePhotoTraining()
      if (!r.added) toast('To vadbo že imaš — nič ni dodano dvakrat.', 'info', 6000)
      else if (r.day) toast(`Shranjeno — »${titleNoDur(r.day.title, r.day.durationMin)}« je odkljukan.`, 'ok', 6000)
      else toast(strava ? 'Vadba shranjena — trener je ne vidi (Strava).' : 'Vadba shranjena — trener jo vidi.', 'ok')
    } finally { setSaving(false) }
  }

  return (<>
    <h2 className="sheet-t">Preveri, kar sem prebral</h2>
    {shot.notes && <div className="muted" style={{ fontSize: rem(12), marginTop: 4, color: strava ? 'var(--warn)' : undefined }}>{shot.notes}</div>}
    <div className="row ph-kinds" style={{ gap: 7, flexWrap: 'wrap', margin: '12px 0' }}>{SPORTS.map(s => <Chip key={s.k} sm on={shot.sport === s.k} onClick={() => setShot({ ...shot, sport: s.k })}>{s.l}</Chip>)}</div>
    <div className="stack" style={{ gap: 10 }}>
      <div className="field"><label htmlFor="ph-day">Dan v načrtu</label>
        <select id="ph-day" value={dayId ?? ''} onChange={e => { const id = e.target.value || null; setDayId(id); const d = opts.find(x => x.id === id); if (d) setShot({ ...shot, date: d.date }) }} style={{ paddingLeft: 10 }}>
          {opts.map(d => <option key={d.id} value={d.id}>{dayLbl(d.date, app.today)} · {titleNoDur(d.title, d.durationMin)}{d.done ? ' (označeno)' : ''}</option>)}
          <option value="">Brez — dodatna vadba</option>
        </select>
        <span className="ph-hint" role="status" style={sel && !fits ? { color: 'var(--warn)' } : undefined}>
          {sel ? (fits ? `Odkljukam »${titleNoDur(sel.title, sel.durationMin)}«.${raceLike(sel) ? ` ${raceNote(sel)}` : ''}` : 'Ta vadba ne ustreza temu dnevu (druga vrsta ali prekratka) — shranim jo kot dodatno.')
            : raceThere ? `Shranim jo kot dodatno. ${isTest(raceThere) ? 'Če je bil to test' : 'Če je bila to tekma'} »${titleNoDur(raceThere.title, raceThere.durationMin)}«, ${isTest(raceThere) ? 'ga' : 'jo'} izberi zgoraj.` : 'Shranim jo kot dodatno vadbo.'}
        </span>
      </div>
      {!sel && <div className="field"><label htmlFor="ph-date">Datum</label><DateField id="ph-date" compact value={shot.date} max={app.today} onChange={v => setShot({ ...shot, date: v || app.today })} label="Datum" /></div>}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        <div className="field"><label htmlFor="ph-min">Trajanje <span className="unit">min</span></label><input id="ph-min" type="number" inputMode="numeric" min={PHOTO_LIMITS.min[0]} max={PHOTO_LIMITS.min[1]} value={shot.durationMin ?? ''} onChange={e => setShot({ ...shot, durationMin: n(e.target.value) })} {...fx('min')} /></div>
        <div className="field"><label htmlFor="ph-km">Razdalja <span className="unit">km</span></label><DecimalInput id="ph-km" step={0.1} value={shot.distKm ?? ''} onChange={e => setShot({ ...shot, distKm: n(e.target.value) })} {...fx('dist')} /></div>
        <div className="field"><label htmlFor="ph-hr">Povp. utrip</label><input id="ph-hr" type="number" inputMode="numeric" value={shot.avgHr ?? ''} onChange={e => setShot({ ...shot, avgHr: n(e.target.value) })} {...fx('hr')} /></div>
        <div className="field"><label htmlFor="ph-w">Povp. moč <span className="unit">W</span></label><input id="ph-w" type="number" inputMode="numeric" value={shot.avgPower ?? ''} onChange={e => setShot({ ...shot, avgPower: n(e.target.value) })} {...fx('power')} /></div>
        <div className="field"><label htmlFor="ph-elev">Vzpon <span className="unit">m</span></label><input id="ph-elev" type="number" inputMode="numeric" value={shot.elevM ?? ''} onChange={e => setShot({ ...shot, elevM: n(e.target.value) })} {...fx('elev')} /></div>
        <div className="field"><label htmlFor="ph-kcal">Kalorije <span className="unit">kcal</span></label><input id="ph-kcal" type="number" inputMode="numeric" value={shot.kcal ?? ''} onChange={e => setShot({ ...shot, kcal: n(e.target.value) })} {...fx('kcal')} /></div>
      </div>
      {shown.length > 0 && <div id="ph-err" role="alert" className="ph-err">{shown.map(k => err[k]).join(' ')}</div>}
      <div className="field"><label htmlFor="ph-name">Ime</label><input id="ph-name" value={shot.name} onChange={e => setShot({ ...shot, name: e.target.value })} /></div>
    </div>
    <Btn primary block style={{ marginTop: 14 }} disabled={saving} onClick={() => void save()}>{fits ? 'Shrani in odkljukaj' : 'Shrani'}</Btn>
    {/* (v3.51) napačno prebrano ali druga slika: nazaj na izbiro slike (prej le Prekliči in ponovno odpiranje z Danes) */}
    <Btn ghost block style={{ marginTop: 9 }} disabled={saving} onClick={() => { setShot(null); setDayId(null); setTouched({}) }}>Druga slika</Btn>
    <Btn ghost block style={{ marginTop: 9 }} onClick={closePhotoTraining}>Prekliči</Btn>
  </>)
}

/* ================= 2) trening s slike ================= */
const KINDS: { k: PhotoKind; l: string }[] = [{ k: 'moc', l: 'Moč' }, { k: 'kolo', l: 'Kolo' }, { k: 'tek', l: 'Tek' }, { k: 'pohod', l: 'Hribi' }]
type ExRow = { name: string; sets: string; reps: string; kg: string; rest: number | null; lib: string | null }
type BlkRow = { kind: PhotoBlock['kind']; min: string; n: string; work: string; rest: string; at: string }
/** »3 min«, »90 s«, »1:30«, »1 min 30 s«; samo število = minute. Sekunde ali null. */
export function parseDur(s: string): number | null {
  const t = s.trim().toLowerCase().replace(',', '.')
  if (!t) return null
  const c = /^(\d+):(\d{1,2})$/.exec(t); if (c) return +c[1]! * 60 + +c[2]!
  const m = /^(\d+(?:\.\d+)?)\s*min(?:\s*(\d+)\s*s)?$/.exec(t); if (m) return Math.round(+m[1]! * 60) + (m[2] ? +m[2] : 0)
  const sec = /^(\d+)\s*(s|sek\w*)$/.exec(t); if (sec) return +sec[1]!
  return /^\d+(\.\d+)?$/.test(t) ? Math.round(+t * 60) : null
}
const rowOfEx = (e: PhotoWorkout['exercises'][number]): ExRow => ({ name: e.name, sets: e.sets != null ? String(e.sets) : '', reps: e.reps, kg: e.kg != null ? String(e.kg).replace('.', ',') : '', rest: e.rest, lib: e.lib })
const rowOfBlk = (b: PhotoBlock): BlkRow => ({ kind: b.kind, min: b.min != null ? String(b.min) : '', n: b.n != null ? String(b.n) : '', work: b.workS != null ? fmtS(b.workS) : '', rest: b.restS != null ? fmtS(b.restS) : '', at: b.at })
const exOfRow = (r: ExRow): PhotoWorkout['exercises'][number] => ({ name: r.name.trim(), sets: inLim(r.sets, PHOTO_LIMITS.sets), reps: repsOf(r.reps), kg: r.kg.trim() ? inLim(r.kg.replace(',', '.'), PHOTO_LIMITS.kg, 0.5) : null, rest: r.rest, lib: r.lib })
const blkOfRow = (r: BlkRow): PhotoBlock => {
  const work = parseDur(r.work), rest = parseDur(r.rest)
  return { kind: r.kind, min: inLim(r.min, PHOTO_LIMITS.blockMin), n: r.kind === 'ponovitve' ? inLim(r.n, PHOTO_LIMITS.n) : null, workS: work != null ? inLim(work, PHOTO_LIMITS.workS) : null, restS: rest != null ? inLim(rest, PHOTO_LIMITS.offS) : null, at: atOf(r.at) }
}

function PlanMode({ req, ai, onDirty }: { req: PhotoReq; ai: Ai; onDirty?: (d: boolean) => void }) {
  const app = useApp()
  const online = useOnline()
  const [w, setW] = useState<PhotoWorkout | null>(null)
  useEffect(() => { onDirty?.(!!w) }, [w])  // eslint-disable-line react-hooks/exhaustive-deps
  const [ex, setEx] = useState<ExRow[]>([])
  const [blk, setBlk] = useState<BlkRow[]>([])
  const [mins, setMins] = useState('')
  const [date, setDate] = useState(req.date && req.date >= app.today ? req.date : app.today)
  const [replaceId, setReplaceId] = useState<string | null>(null)
  const [tried, setTried] = useState(false)
  const [saving, setSaving] = useState(false)
  const { confirm, sheet: confirmSheet } = useConfirm()
  // (v3.51) »Dodaj ročno« odpre list za dodajanje na ta dan (prej le Plan — še en tap)
  const manual = () => { closePhotoTraining(); navigate('plan', { dan: date, dodaj: '1' }) }

  const rd = useRead(ai)
  async function pick(file: File) {
    const r = await rd.read(file, () => workoutFromPhoto(getState().profile, file))
    if (!r) return
    setW(r); setEx(r.exercises.map(rowOfEx)); setBlk(r.blocks.map(rowOfBlk)); setMins(r.minutes != null ? String(r.minutes) : ''); setTried(false)
  }
  usePickOnce(req.file, f => { void pick(f) })

  // osnutek iz polj (kar je neveljavno, je prazno — napake spodaj)
  const draft = useMemo<PhotoWorkout | null>(() => (w ? { ...w, minutes: mins.trim() ? inLim(mins, PHOTO_LIMITS.min) ?? -1 : null, exercises: ex.map(exOfRow), blocks: blk.map(blkOfRow) } : null), [w, ex, blk, mins])
  const days = Array.from({ length: 14 }, (_, i) => addDays(app.today, i))
  const reps = replaceOptions(app.plan, date)
  const restDay = app.plan.some(d => d.date === date && d.kind === 'pocitek' && !d.done && !d.sickPrev)
  const doneThere = app.plan.filter(d => d.date === date && d.done && d.kind !== 'pocitek')
  useEffect(() => { if (replaceId && !reps.some(d => d.id === replaceId)) setReplaceId(null) }, [date]) // eslint-disable-line react-hooks/exhaustive-deps

  if (!w || !draft) return (<>
    <h2 className="sheet-t">Trening s slike</h2>
    <p className="muted" style={{ fontSize: rem(13), marginTop: 4 }}>Tabla v fitnesu, list od trenerja, objava z vajami ali posnetek iz druge aplikacije. Sestavim trening, ki ga urediš in dodaš v načrt — vodena vadba ga potem vodi (slike vaj, piski).</p>
    {online ? (
      canRead(app) ? <div style={{ marginTop: 12 }}><PhotoInput onPick={f => void pick(f)} busy={ai.busy} label="Slikaj ali izberi sliko treninga" hint={`Posnetkov iz Strave ne nalagaj. ${PRIVACY}`} /></div> : <SignInFirst />
    ) : (
      <Offline text="Branje slike rabi AI. Trening lahko dodaš ročno v Planu.">
        <Btn primary block sm style={{ marginTop: 10 }} onClick={manual}>Dodaj ročno</Btn>
      </Offline>
    )}
    {online && rd.err && <ReadErr msg={rd.err} busy={ai.busy} onRetry={() => { if (rd.last.current) void pick(rd.last.current) }} onManual={manual} manualLabel="Dodaj ročno" />}
    {online && !rd.err && <button type="button" className="chip sm click" style={{ marginTop: 10 }} onClick={manual}>raje dodam ročno</button>}
  </>)

  const p = app.profile
  const errs = [...draftErrors(draft), ...(ex.some(r => r.kg.trim() && inLim(r.kg.replace(',', '.'), PHOTO_LIMITS.kg) == null) ? ['Kilogrami: od 0 do 400.'] : []), ...(blk.some(r => r.rest.trim() && blkOfRow(r).restS == null) ? ['Odmor: od 0 s do 30 min.'] : [])]
  const shownErr = [...new Set(errs.filter(e => tried || !/Vpiši trajanje/.test(e)))]
  // (v3.51) napačno polje: aria-invalid in opis z napako (kot pri opravljenem treningu)
  const inv = (bad: boolean) => ({ 'aria-invalid': bad || undefined, 'aria-describedby': bad && shownErr.length ? 'pt-err' : undefined })
  const day = draftToPlanDay(draft.minutes === -1 ? { ...draft, minutes: null } : draft, date, p)
  const lines = draft.kind === 'moc' ? [] : structureLines(stepsFor(day, p)).slice(0, 6)
  const cardio = draft.kind !== 'moc'
  const durN = draft.minutes != null && draft.minutes > 0 ? durationNote(draft) : null
  const setKind = (k: PhotoKind) => {
    setW({ ...w, kind: k })
    if (k === 'moc' && !ex.length) setEx([{ name: '', sets: '3', reps: '10', kg: '', rest: null, lib: null }])
    if (k !== 'moc' && !blk.length) setBlk([{ kind: 'ogrevanje', min: '10', n: '', work: '', rest: '', at: '' }, { kind: 'ponovitve', min: '', n: '', work: '', rest: '', at: '' }, { kind: 'iztek', min: '5', n: '', work: '', rest: '', at: '' }])
  }
  const setE = (i: number, patch: Partial<ExRow>) => setEx(ex.map((r, j) => (j === i ? { ...r, ...patch } : r)))
  const setB = (i: number, patch: Partial<BlkRow>) => setBlk(blk.map((r, j) => (j === i ? { ...r, ...patch } : r)))
  // ime vaje po odhodu iz polja: iz knjižnice, če jo prepoznam (slika in tehnika v vodeni vadbi)
  const linkName = (i: number) => { const r = ex[i]; if (!r) return; const lib = matchExercise(r.name); setE(i, lib ? { name: lib.name, lib: lib.id } : { lib: null }) }

  async function add(start: boolean) {
    setTried(true)
    // (v3.51) fokus na prvo napačno polje (prej ostal na »Dodaj v načrt« — pri dolgem seznamu vaj ni bilo jasno, kaj je narobe)
    if (errs.length || !draft) { setTimeout(() => (document.querySelector<HTMLElement>('.sheet [aria-invalid="true"]') ?? document.getElementById('pt-min'))?.focus(), 0); return }
    // (v3.51) »Začni zdaj« velja za izbrani dan (samo danes) in »Poleg/Namesto«; na dan tekme ali trdega treninga vpraša
    const on = date
    if (start) {
      const warn = startNowWarn(getState().plan, on, replaceId)
      if (warn && !(await confirm({ title: 'Še en trening danes?', text: warn, ok: 'Dodaj in začni' }))) return
    }
    setSaving(true)
    try {
      const d = draftToPlanDay(draft, on, getState().profile)
      const r = await addPhotoWorkout(d, replaceId)
      closePhotoTraining()
      if (start) { navigate('vadba', { id: r.day.id }); return }
      undoToast(`Dodano v načrt: ${r.day.title} · ${dayLbl(on, app.today).toLowerCase()}${r.replaced && r.replaced.kind !== 'pocitek' ? ` (namesto »${titleNoDur(r.replaced.title, r.replaced.durationMin)}«)` : ''}.`, () => { void r.undo() }, { ms: 8000 })
    } finally { setSaving(false) }
  }

  return (<>
    <h2 className="sheet-t">Preveri trening s slike</h2>
    <div className="muted" style={{ fontSize: rem(12), marginTop: 4 }}>Kar ni bilo jasno, je prazno — dopolni ali popravi.</div>
    <div className="row ph-kinds" style={{ gap: 7, flexWrap: 'wrap', margin: '12px 0' }}>{KINDS.map(k => <Chip key={k.k} sm on={draft.kind === k.k} onClick={() => setKind(k.k)}>{k.l}</Chip>)}</div>
    <div className="stack" style={{ gap: 10 }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 110px', gap: 10 }}>
        <div className="field"><label htmlFor="pt-title">Naslov</label><input id="pt-title" value={w.title} onChange={e => setW({ ...w, title: e.target.value.slice(0, 60) })} /></div>
        <div className="field"><label htmlFor="pt-min">Trajanje <span className="unit">min</span></label><input id="pt-min" type="number" inputMode="numeric" min={PHOTO_LIMITS.min[0]} max={PHOTO_LIMITS.min[1]} value={mins} placeholder={String(draftMinutes({ ...draft, minutes: null }))} onChange={e => setMins(e.target.value)} {...inv(shownErr.some(e => /trajanj/i.test(e)))} /></div>
      </div>
      {durN && <div className="ph-hint" role="status">{durN.text} <button type="button" className="chip sm click" onClick={() => setMins(String(durN.use))}>uporabi {durN.use}</button></div>}
      {!cardio ? (
        <div className="field"><label>Vaje <span className="unit">ime · serije · ponovitve · kg</span></label>
          <div className="stack" style={{ gap: 6 }}>
            {ex.map((r, i) => (
              <div key={i} className="exrow ex2">
                <input className="ex-name" value={r.name} onChange={x => setE(i, { name: x.target.value })} onBlur={() => linkName(i)} placeholder="vaja" aria-label="Vaja" />
                <input value={r.sets} inputMode="numeric" onChange={x => setE(i, { sets: x.target.value })} aria-label="Serije" {...inv(!inLim(r.sets, PHOTO_LIMITS.sets))} />
                <input value={r.reps} onChange={x => setE(i, { reps: x.target.value })} placeholder="10 ali 30 s" aria-label="Ponovitve ali sekunde" {...inv(!repsOf(r.reps))} />
                <input value={r.kg} inputMode="decimal" onChange={x => setE(i, { kg: x.target.value })} placeholder="kg" aria-label="Kilogrami" />
                <button type="button" className="chip sm click" onClick={() => setEx(ex.filter((_, j) => j !== i))} aria-label={`Odstrani ${r.name || 'vajo'}`}>×</button>
                {r.name.trim() && <span className="ph-lib">{r.lib ? 'iz knjižnice — s sliko in tehniko' : 'ni v knjižnici — brez slike'}{r.rest != null ? ` · pavza ${fmtS(r.rest)}` : ''}</span>}
              </div>
            ))}
            {ex.length < PHOTO_LIMITS.ex && <button type="button" className="chip sm click ph-add" style={{ alignSelf: 'flex-start' }} onClick={() => setEx([...ex, { name: '', sets: '3', reps: '10', kg: '', rest: null, lib: null }])}>+ vaja</button>}
          </div>
        </div>
      ) : (
        // (v3.51) pomoč za polja samo, ko so med koraki ponovitve (pri hoji in enakomernem ni ponovitev)
        <div className="field"><label>Koraki{blk.some(b => b.kind === 'ponovitve') ? <> <span className="unit">ponovitve × delo / odmor · intenzivnost</span></> : null}</label>
          <div className="stack" style={{ gap: 6 }}>
            {blk.map((r, i) => (
              <div key={i} className={`ph-blk ${r.kind}`}>
                {r.kind === 'ponovitve' ? (<>
                  <input value={r.n} inputMode="numeric" onChange={x => setB(i, { n: x.target.value })} placeholder="5" aria-label="Ponovitve" {...inv(!inLim(r.n, PHOTO_LIMITS.n))} />
                  <span aria-hidden="true">×</span>
                  <input value={r.work} onChange={x => setB(i, { work: x.target.value })} placeholder="3 min" aria-label="Delo (min ali s)" {...inv(blkOfRow(r).workS == null)} />
                  <span aria-hidden="true">/</span>
                  <input value={r.rest} onChange={x => setB(i, { rest: x.target.value })} placeholder={(() => { const wk = parseDur(r.work); return wk ? fmtS(defaultRest(wk)) : 'odmor' })()} aria-label="Odmor (min ali s)" />
                  <input className="ph-at" value={r.at} onChange={x => setB(i, { at: x.target.value })} placeholder="RPE 8, 250–270 W ali tempo" aria-label="Intenzivnost" />
                </>) : r.kind === 'enakomerno' ? (<>
                  <span className="ph-k">Enakomerno</span>
                  <input value={r.min} inputMode="numeric" onChange={x => setB(i, { min: x.target.value })} placeholder="min" aria-label="Enakomerno (min)" />
                  <input className="ph-at" value={r.at} onChange={x => setB(i, { at: x.target.value })} placeholder="lahko ali tempo" aria-label="Intenzivnost" />
                </>) : (<>
                  <span className="ph-k">{r.kind === 'ogrevanje' ? 'Ogrevanje' : 'Iztek'}</span>
                  <input value={r.min} inputMode="numeric" onChange={x => setB(i, { min: x.target.value })} placeholder="min" aria-label={`${r.kind === 'ogrevanje' ? 'Ogrevanje' : 'Iztek'} (min)`} />
                </>)}
                <button type="button" className="chip sm click ph-x" onClick={() => setBlk(blk.filter((_, j) => j !== i))} aria-label="Odstrani korak">×</button>
              </div>
            ))}
            <div className="row ph-adds" style={{ gap: 6, flexWrap: 'wrap' }}>
              <button type="button" className="chip sm click" onClick={() => setBlk([...blk.filter(b => b.kind !== 'iztek'), { kind: 'ponovitve', min: '', n: '', work: '', rest: '', at: '' }, ...blk.filter(b => b.kind === 'iztek')])}>+ ponovitve</button>
              <button type="button" className="chip sm click" onClick={() => setBlk([...blk.filter(b => b.kind !== 'iztek'), { kind: 'enakomerno', min: '', n: '', work: '', rest: '', at: '' }, ...blk.filter(b => b.kind === 'iztek')])}>+ enakomerno</button>
            </div>
          </div>
          {lines.length > 0 && <div className="ph-struct"><b>Vodena vadba:</b> {lines.join(' · ')}</div>}
        </div>
      )}
      {w.note && <div className="muted" style={{ fontSize: rem(12) }}>S slike: {w.note}</div>}
      <div className="field"><label htmlFor="pt-day">Dan</label>
        <select id="pt-day" value={date} onChange={e => setDate(e.target.value)} style={{ paddingLeft: 10 }}>
          {days.map(d => { const t = app.plan.find(x => x.date === d && x.kind !== 'pocitek'); return <option key={d} value={d}>{dayLbl(d, app.today)}{t ? ` · ${titleNoDur(t.title, t.durationMin)}${t.done ? ' (opravljeno)' : ''}` : ''}</option> })}
        </select>
        {reps.length > 0 ? (
          <div className="row" role="group" aria-label="Kam v ta dan" style={{ gap: 6, flexWrap: 'wrap', marginTop: 6 }}>
            <Chip sm on={!replaceId} onClick={() => setReplaceId(null)}>Poleg</Chip>
            {reps.map(d => <Chip key={d.id} sm on={replaceId === d.id} onClick={() => setReplaceId(d.id)}>Namesto: {titleNoDur(d.title, d.durationMin)}</Chip>)}
          </div>
        ) : <span className="ph-hint">{restDay ? 'Namesto počitka.' : 'Nov trening ta dan.'}</span>}
        {doneThere.length > 0 && <span className="ph-hint">Opravljeno ta dan ostane, kot je.</span>}
      </div>
      {shownErr.length > 0 && <div id="pt-err" role="alert" className="ph-err">{shownErr.join(' ')}</div>}
    </div>
    <Btn primary block style={{ marginTop: 14 }} disabled={saving} onClick={() => void add(false)}>Dodaj v načrt</Btn>
    {date === app.today && <Btn ghost block style={{ marginTop: 9 }} disabled={saving} onClick={() => void add(true)}>Začni zdaj</Btn>}
    <Btn ghost block style={{ marginTop: 9 }} disabled={saving} onClick={() => { setW(null); setEx([]); setBlk([]); setMins(''); setTried(false) }}>Druga slika</Btn>
    <Btn ghost block style={{ marginTop: 9 }} onClick={closePhotoTraining}>Prekliči</Btn>
    {confirmSheet}
  </>)
}

/* ================= 3) slika sebe ================= */
function SelfMode({ ai, onDirty }: { ai: Ai; onDirty?: (d: boolean) => void }) {
  const app = useApp()
  const online = useOnline()
  const [adv, setAdv] = useState<SelfAdvice | null>(null)
  useEffect(() => { onDirty?.(!!adv) }, [adv])  // eslint-disable-line react-hooks/exhaustive-deps
  // (v3.50) zaklep: dvojni tap na »Dodaj v načrt« je zapisal seje dvakrat (zapis v IndexedDB traja)
  const [saving, setSaving] = useState(false)
  const lock = useRef(false)
  const rd = useRead(ai, SELF_PHOTO_CONSENT_V)
  const av = selfAvailable(app.profile)
  const vaje = () => { closePhotoTraining(); navigate('vaje') }
  const head = <h2 className="sheet-t">Predlog s slike</h2>
  if (av !== 'ok') return (<>
    {head}
    <p style={{ fontSize: rem(13), marginTop: 6 }}>{av === 'minor' ? MINOR_SELF : NO_AGE_SELF}</p>
    {av === 'minor'
      ? <Btn primary block sm style={{ marginTop: 12 }} onClick={vaje}>Odpri Vaje</Btn>
      : <Btn primary block sm style={{ marginTop: 12 }} onClick={() => { closePhotoTraining(); navigate('nastavitve', { sec: 'n-profil' }) }}>Odpri Profil</Btn>}
  </>)

  async function pick(file: File) {
    const r = await rd.read(file, () => selfFromPhoto(getState().profile, file))
    if (r) setAdv(r)
  }
  async function add() {
    if (!adv || lock.current) return
    const s = getState()
    const days = selfSessions(adv, s.plan, s.profile, s.today)
    if (!days.length) { toast('Ta teden ni prostega dneva brez trdega treninga — vaje najdeš v Vajah.', 'info', 6000); return }
    lock.current = true; setSaving(true)
    try { await addSelfSessions(days) } finally { lock.current = false; setSaving(false) }
    closePhotoTraining()
    const ds = days.map(d => dayLbl(d.date, s.today).toLowerCase())
    toast(`Dodano v načrt: ${adv.title}, ${ds.length > 1 ? `${ds.slice(0, -1).join(', ')} in ${ds[ds.length - 1]}` : ds[0]} — po želji.`, 'ok', 7000)
  }

  if (!adv) return (<>
    {head}
    <p className="muted" style={{ fontSize: rem(13), marginTop: 4 }}>Slikaj se v celoti — spredaj ali s strani, v oprijetih oblačilih, pri dobri svetlobi. Povem, kaj trenirati za držo, ravnotežje in moč. Brez ocene videza, teže ali maščobe.</p>
    {online
      ? canRead(app) ? <div style={{ marginTop: 12 }}><PhotoInput onPick={f => void pick(f)} busy={ai.busy} label="Slikaj ali izberi sliko" hint={`Grob vtis s slike, ne meritev. ${PRIVACY}`} /></div> : <SignInFirst />
      : <Offline text="Predlog s slike rabi AI — zdaj ni na voljo. Vaje za držo in jedro so v Vajah."><Btn primary block sm style={{ marginTop: 10 }} onClick={vaje}>Odpri Vaje</Btn></Offline>}
    {online && rd.err && <ReadErr msg={rd.err} busy={ai.busy} onRetry={() => { if (rd.last.current) void pick(rd.last.current) }} onManual={vaje} manualLabel="Odpri Vaje" />}
  </>)

  const has = adv.points.length > 0 || adv.exercises.length > 0
  // (v3.51) gumb pove, koliko sej res gre v načrt (prej »3×«, dodani 2) in zakaj manj
  const free = selfSessions(adv, app.plan, app.profile, app.today).length
  return (<>
    {head}
    {adv.points.length > 0 && (<>
      <div className="h4" style={{ marginTop: 10 }}>Kaj trenirati</div>
      <ul className="ph-points">{adv.points.map((t, i) => <li key={i}>{t}</li>)}</ul>
    </>)}
    {adv.note && <p className="muted" style={{ fontSize: rem(12.5), marginTop: 8 }}>{adv.note}</p>}
    {has && adv.exercises.length > 0 && (<>
      <div className="ph-plan"><b>Predlog:</b> {adv.perWeek}× na teden {adv.minutes} min — {adv.title.toLowerCase()}.</div>
      {/* brez povezave na Vaje (list bi ostal odprt nad drugim zaslonom) — Vaje so spodaj */}
      <ol className="ex-grid" aria-label="Vaje">{adv.exercises.map((e, i) => <li key={i} className="ex-t"><span className="ex-n" aria-hidden="true">{i + 1}</span><span className="ex-b"><b>{e.name}</b><small>{e.sets} × {e.reps}</small></span></li>)}</ol>
    </>)}
    <div className="muted" style={{ fontSize: rem(11.5), marginTop: 10 }}>Grob vtis s slike, ne meritev. Slika se ne shrani.</div>
    {has && adv.exercises.length > 0 && free > 0 && free < adv.perWeek && <div className="ph-hint" role="status" style={{ marginTop: 10 }}>V naslednjih 7 dneh {free === 1 ? 'je prost samo 1 dan' : `sta prosta samo ${free} dneva`} brez trdega treninga — {free === 1 ? 'dodam 1 sejo' : `dodam ${free} seji`}.</div>}
    {has && adv.exercises.length > 0
      ? <Btn primary block style={{ marginTop: 14 }} disabled={saving} onClick={() => void add()}>Dodaj v načrt ({free > 0 ? Math.min(free, adv.perWeek) : adv.perWeek}×, po želji)</Btn>
      : <Btn primary block style={{ marginTop: 14 }} onClick={() => setAdv(null)}>Poskusi z drugo sliko</Btn>}
    <Btn ghost block style={{ marginTop: 9 }} onClick={vaje}>Odpri Vaje</Btn>
  </>)
}
