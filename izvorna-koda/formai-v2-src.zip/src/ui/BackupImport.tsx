import { useRef, useState } from 'react'
import { restoreFromBackup, toast } from '@/state/store'
import { parseBackup, type ParsedBackup } from '@/data/backup'
import { Btn, Sheet } from '@/ui/primitives'
import { count, dmy, W } from '@/ui/format'

const PLAN_DNI = ['dan načrta', 'dneva načrta', 'dnevi načrta', 'dni načrta'] as const
const JUTRA = ['jutranji vnos', 'jutranja vnosa', 'jutranji vnosi', 'jutranjih vnosov'] as const

/**
 * »Uvozi kopijo«: izbereš datoteko iz »Izvozi vse«, vidiš, kaj je v njej, in potrdiš. Kopija se združi z napravo
 * (nič se ne izbriše). fresh = nova ali prazna naprava: profil in nastavitve iz kopije so privzeto vključeni.
 */
export function BackupImport({ fresh = false, label = 'Uvozi kopijo', block = false, primary = false, onDone }: { fresh?: boolean; label?: string; block?: boolean; primary?: boolean; onDone?: () => void }) {
  const input = useRef<HTMLInputElement>(null)
  const [pending, setPending] = useState<ParsedBackup | null>(null)
  const [withProfile, setWithProfile] = useState(fresh)
  const [busy, setBusy] = useState(false)
  async function pick(f: File | undefined) {
    if (!f) return
    try {
      const parsed = parseBackup(await f.text())
      setWithProfile(fresh && parsed.info.profile)
      setPending(parsed)
    } catch (e) { toast((e as Error).message, 'err', 7000) }
  }
  async function go() {
    if (!pending) return
    setBusy(true)
    try {
      const r = await restoreFromBackup(pending, { fromBackup: withProfile })
      setPending(null)
      const bits = [r.activities ? count(r.activities, W.vadba) : null, r.meals ? count(r.meals, W.obrok) : null, r.plan ? count(r.plan, PLAN_DNI) : null, r.checkins ? count(r.checkins, JUTRA) : null].filter(Boolean)
      const del = r.deleted ? ` ${r.deleted === 1 ? 'En zapis, ki si ga izbrisal po izvozu, ostane izbrisan' : `${r.deleted} zapisov, ki si jih izbrisal po izvozu, ostane izbrisanih`}.` : ''
      toast((bits.length ? `Uvoženo: ${bits.join(', ')}.` : r.changed ? 'Uvoženo — podatki so posodobljeni.' : 'Vse iz kopije je že na tej napravi.') + del, 'ok', 8000)
      onDone?.()
    } catch (e) { toast(`Uvoz ni uspel: ${(e as Error).message}`, 'err', 8000) } finally { setBusy(false) }
  }
  const i = pending?.info
  return (<>
    <Btn ghost={!primary} primary={primary} sm={!block} block={block} onClick={() => input.current?.click()}>{label}</Btn>
    <input ref={input} type="file" accept="application/json,.json" hidden onChange={e => { const f = e.target.files?.[0]; e.target.value = ''; void pick(f) }} />
    <Sheet open={!!pending} onClose={() => !busy && setPending(null)} label="Uvozi varnostno kopijo">
      <b style={{ display: 'block', fontSize: 17, letterSpacing: '-.02em' }}>Uvozi varnostno kopijo</b>
      {i && <p style={{ fontSize: 13, marginTop: 6, lineHeight: 1.5 }}>
        Kopija{i.exportedAt ? ` z dne ${dmy(i.exportedAt.slice(0, 10))}` : ''}: {[count(i.activities, W.vadba), count(i.meals, W.obrok), count(i.plan, PLAN_DNI), count(i.checkins, JUTRA)].join(', ')}.
        {' '}Združi se s tem, kar je na tej napravi — nič se ne izbriše, isti zapis ostane v novejši različici.
      </p>}
      {i?.profile && (
        <label className="row" style={{ gap: 10, marginTop: 12, fontSize: 13, alignItems: 'flex-start', cursor: 'pointer' }}>
          <input type="checkbox" checked={withProfile} onChange={e => setWithProfile(e.target.checked)} style={{ marginTop: 3, width: 18, height: 18, accentColor: 'var(--accent)' }} />
          <span>Profil in nastavitve iz kopije <span className="muted">(FTP, teža, cilj, tekme, povezava z uro). Brez kljukice velja novejša vrednost vsakega polja.</span></span>
        </label>
      )}
      <Btn primary block style={{ marginTop: 16 }} disabled={busy} onClick={() => void go()}>{busy ? 'Uvažam …' : 'Uvozi'}</Btn>
      <Btn ghost block style={{ marginTop: 9 }} disabled={busy} onClick={() => setPending(null)}>Prekliči</Btn>
    </Sheet>
  </>)
}
