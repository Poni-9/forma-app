import { useEffect, useRef, useState } from 'react'
import { getState } from '@/state/store'
import { hasConsent, CLAUDE_CONSENT_V } from '@/domain/ai/consent'
import { canRecord, toWav16k, transcribe } from './voice'

interface SpeechAlt { transcript: string; confidence: number }
interface SpeechResult { isFinal: boolean; length: number; [i: number]: SpeechAlt }
interface SpeechRec {
  lang: string; interimResults: boolean; continuous: boolean; maxAlternatives: number
  onresult: ((e: { resultIndex: number; results: ArrayLike<SpeechResult> }) => void) | null
  onend: (() => void) | null
  onerror: ((e: { error: string }) => void) | null
  start(): void; stop(): void; abort(): void
}
type SpeechCtor = new () => SpeechRec
export const speechCtor = (): SpeechCtor | null => {
  if (typeof window === 'undefined') return null
  const w = window as unknown as { SpeechRecognition?: SpeechCtor; webkitSpeechRecognition?: SpeechCtor }
  return w.SpeechRecognition || w.webkitSpeechRecognition || null
}
const isAndroid = () => typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent)
const join = (...parts: string[]) => parts.map(s => s.trim()).filter(Boolean).join(' ').replace(/\s+/g, ' ')

/** Največ zaporednih krogov brez govora (Android: krog ≈ 5–8 s tišine), nato se mikrofon sam ugasne. */
const SILENT_ROUNDS = 2
/** Najdaljše narekovanje v enem zamahu. */
const MAX_MS = 120_000

/**
 * Narekovanje (prepoznava govora brskalnika, sl-SI): besedilo se dopolnjuje za obstoječim; zvok ne gre k nam.
 * Kjer je brskalnik nima, `canSpeak` = false (ostane mikrofon na tipkovnici telefona).
 *
 * Zakaj v krogih (Blaž, 11. 10.: »mikrofon res slabo dela«): Chrome na Androidu v načinu `continuous` neha poslušati
 * ob prvem premoru in iste besede vrne dvakrat. Zato tam vsak krog posluša en stavek (`continuous = false`), ob koncu
 * kroga se besedilo potrdi in takoj začne nov krog — dokler uporabnik ne tapne znova, ne utihne za dva kroga ali
 * ne mine 2 min. Na namizju ostane neprekinjeno, a z istim nadaljevanjem po prekinitvi (Chrome neha po ~1 min).
 */
/** Glas prepiše AI (Gemini): prijavljen, privolitev za besedilo z glasom (različica 2), brskalnik zna snemati. */
const aiVoice = (): boolean => {
  if (!canRecord() || navigator.onLine === false) return false
  if (import.meta.env.VITE_E2E === '1') return true   // samo testna gradnja (prestrežen strežnik)
  const st = getState()
  return !!st.user && hasConsent(st.profile, CLAUDE_CONSENT_V)
}
/** Tišina po govoru, po kateri se snemanje samo ustavi. */
const SILENCE_MS = 2800

export function useDictation(text: string, setText: (t: string) => void, onError?: (msg: string) => void, hint?: string) {
  const [listening, setListening] = useState(false)
  // AI: snemanje → prepis (»Pretvarjam govor v besedilo …«); level = glasnost za stolpce
  const [transcribing, setTranscribing] = useState(false)
  const [level, setLevel] = useState(0)
  const media = useRef<{ rec: MediaRecorder; stream: MediaStream; ctx: AudioContext; raf: number; stop: () => void } | null>(null)
  const recRef = useRef<SpeechRec | null>(null)
  const want = useRef(false)                 // uporabnik hoče poslušati (dokler ne tapne znova)
  const base = useRef('')                    // besedilo pred narekovanjem
  const done = useRef('')                    // potrjeno v prejšnjih krogih
  const cur = useRef('')                     // ta krog (potrjeno + vmesno)
  const pushed = useRef(new Set<string>())   // kar smo sami nastavili — besedilo, ki ni od tu, je ročno tipkanje med narekovanjem
  const textRef = useRef(text); textRef.current = text
  const silent = useRef(0)
  const t0 = useRef(0)
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const canSpeak = !!speechCtor() || canRecord()

  useEffect(() => () => { want.current = false; if (timer.current) clearTimeout(timer.current); recRef.current?.abort(); media.current?.stop() }, [])

  /** AI: snemaj, dokler uporabnik ne tapne ali ne utihne (2,8 s po govoru) ali 2 min; nato prepis z Gemini. */
  async function startAi() {
    let stream: MediaStream
    try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } }) }
    catch (e) {
      const n = (e as { name?: string } | null)?.name
      onError?.(n === 'NotAllowedError' || n === 'SecurityError' ? 'Dovoli mikrofon za formai.si (ključavnica ob naslovu) — ali uporabi mikrofon na tipkovnici.' : 'Mikrofon ni na voljo — morda ga uporablja druga aplikacija.')
      return
    }
    const types = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg;codecs=opus']
    const mime = types.find(t => (MediaRecorder as unknown as { isTypeSupported?: (t: string) => boolean }).isTypeSupported?.(t)) || ''
    const rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined)
    const chunks: Blob[] = []
    rec.ondataavailable = e => { if (e.data.size) chunks.push(e.data) }
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
    const ctx = new AC()
    const an = ctx.createAnalyser(); an.fftSize = 512
    ctx.createMediaStreamSource(stream).connect(an)
    const data = new Uint8Array(an.fftSize)
    let spoke = false, quietSince = 0
    const t0 = Date.now()
    const tick = () => {
      an.getByteTimeDomainData(data)
      let sum = 0
      for (let i = 0; i < data.length; i++) { const x = (data[i]! - 128) / 128; sum += x * x }
      const rms = Math.sqrt(sum / data.length)
      setLevel(Math.min(1, rms * 6))
      const now = Date.now()
      if (rms > 0.045) { spoke = true; quietSince = 0 } else if (spoke && !quietSince) quietSince = now
      if ((spoke && quietSince && now - quietSince > SILENCE_MS) || now - t0 > MAX_MS) { stop(); return }
      if (media.current) media.current.raf = requestAnimationFrame(tick)
    }
    const stop = () => {
      const m = media.current; if (!m) return
      media.current = null
      cancelAnimationFrame(m.raf)
      try { if (m.rec.state !== 'inactive') m.rec.stop() } catch { /* že ustavljen */ }
      m.stream.getTracks().forEach(t => t.stop())
      void m.ctx.close().catch(() => {})
      setListening(false); setLevel(0)
    }
    rec.onstop = async () => {
      if (!spoke && Date.now() - t0 < 1500) return
      setTranscribing(true)
      try {
        const wav = await toWav16k(new Blob(chunks, { type: rec.mimeType || mime || 'audio/webm' }))
        const said = await transcribe(wav, hint)
        if (said) setText(join(textRef.current, said))
        else onError?.('Nisem slišal govora — poskusi znova bližje mikrofonu.')
      } catch { onError?.('Pretvorba govora v besedilo ni uspela — poskusi znova ali napiši.') }
      finally { setTranscribing(false) }
    }
    media.current = { rec, stream, ctx, raf: 0, stop }
    rec.start(250)
    setListening(true)
    try { navigator.vibrate?.(12) } catch { /* ni vibracije */ }
    media.current.raf = requestAnimationFrame(tick)
  }

  const push = (t: string) => { pushed.current.add(t); setText(t) }

  function finish() {
    want.current = false
    if (timer.current) { clearTimeout(timer.current); timer.current = null }
    setListening(false)
    const r = recRef.current; recRef.current = null
    try { r?.stop() } catch { /* že ustavljen */ }
  }

  function round() {
    const Ctor = speechCtor()
    if (!Ctor || !want.current) { finish(); return }
    const rec = new Ctor()
    rec.lang = 'sl-SI'; rec.interimResults = true; rec.maxAlternatives = 1
    rec.continuous = !isAndroid()
    cur.current = ''
    let heard = false
    rec.onresult = e => {
      // če je uporabnik medtem tipkal ali brisal (besedilo ni nobeno od naših), je njegovo besedilo nova podlaga
      if (pushed.current.size && !pushed.current.has(textRef.current)) {
        base.current = cur.current ? textRef.current.replace(cur.current, '') : textRef.current
        done.current = ''
      }
      let fin = '', interim = ''
      for (let i = 0; i < e.results.length; i++) {
        const r = e.results[i]!, t = r[0]?.transcript ?? ''
        if (r.isFinal) fin += t + ' '; else interim += t
      }
      cur.current = join(fin, interim)
      if (cur.current) heard = true
      // Android isti stavek včasih vrne še enkrat (nov krog) — pokažemo ga enkrat
      const dup = !!cur.current && done.current.endsWith(cur.current)
      push(join(base.current, done.current, dup ? '' : cur.current))
    }
    rec.onerror = e => {
      if (e.error === 'no-speech') return                   // sledi onend; šteje kot tih krog
      want.current = false
      if (e.error === 'aborted') return
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') onError?.('Dovoli mikrofon za formai.si (ključavnica ob naslovu) — ali uporabi mikrofon na tipkovnici.')
      else if (e.error === 'network') onError?.('Narekovanje potrebuje internet — poskusi znova ali napiši.')
      else if (e.error === 'audio-capture') onError?.('Mikrofon ni na voljo — morda ga uporablja druga aplikacija.')
      else if (e.error === 'language-not-supported') onError?.('Ta brskalnik ne zna slovenskega narekovanja — uporabi mikrofon na tipkovnici.')
      else onError?.('Narekovanje ni uspelo — poskusi znova ali napiši.')
    }
    rec.onend = () => {
      if (recRef.current !== rec) return                   // ustavil ga je uporabnik (finish)
      // kar je krog slišal, obvelja — tudi zadnji vmesni rezultat, ki ga Android ne potrdi vedno
      const c = cur.current
      if (c && !done.current.endsWith(c)) done.current = join(done.current, c)   // isti stavek dvakrat → enkrat
      cur.current = ''
      silent.current = heard ? 0 : silent.current + 1
      recRef.current = null
      if (want.current && silent.current < SILENT_ROUNDS && Date.now() - t0.current < MAX_MS) { timer.current = setTimeout(round, 150); return }
      finish()
    }
    recRef.current = rec
    try { rec.start() } catch { recRef.current = null; finish() }
  }

  function toggle() {
    if (media.current) { media.current.stop(); return }
    if (want.current || recRef.current) { finish(); return }
    if (transcribing) return
    if (aiVoice()) { void startAi(); return }
    if (!speechCtor()) { if (canRecord()) onError?.('Za narekovanje se prijavi in dovoli AI — ali uporabi mikrofon na tipkovnici.'); return }
    want.current = true; silent.current = 0; t0.current = Date.now()
    base.current = textRef.current.trim(); done.current = ''; cur.current = ''; pushed.current = new Set()
    setListening(true)
    try { navigator.vibrate?.(12) } catch { /* ni vibracije */ }
    round()
  }
  const stop = () => { if (media.current) media.current.stop(); else finish() }
  return { listening, canSpeak, toggle, stop, transcribing, level }
}
