import { useEffect, useRef, useState } from 'react'

interface SpeechRec {
  lang: string; interimResults: boolean; continuous: boolean; maxAlternatives: number
  onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null
  onend: (() => void) | null
  onerror: ((e: { error: string }) => void) | null
  start(): void; stop(): void; abort(): void
}
type SpeechCtor = new () => SpeechRec
export const speechCtor = (): SpeechCtor | null => {
  if (typeof window === 'undefined') return null
  const w = window as unknown as { SpeechRecognition?: SpeechCtor; webkitSpeechRecognition?: SpeechCtor }
  return w.SpeechRecognition || w.webkitSpeechRecognition || null
}

/**
 * Narekovanje (prepoznava govora brskalnika, sl-SI): besedilo se dopolnjuje za obstoječim; zvok ne gre k nam.
 * Kjer je brskalnik nima, `canSpeak` = false (ostane mikrofon na tipkovnici telefona).
 */
export function useDictation(text: string, setText: (t: string) => void, onError?: (msg: string) => void) {
  const [listening, setListening] = useState(false)
  const recRef = useRef<SpeechRec | null>(null)
  const baseRef = useRef('')
  const canSpeak = !!speechCtor()
  useEffect(() => () => { recRef.current?.abort() }, [])
  function toggle() {
    if (listening) { recRef.current?.stop(); return }
    const Ctor = speechCtor()
    if (!Ctor) return
    const rec = new Ctor()
    rec.lang = 'sl-SI'; rec.interimResults = true; rec.continuous = true; rec.maxAlternatives = 1
    baseRef.current = text.trim() ? text.trim() + ' ' : ''
    rec.onresult = e => {
      let said = ''
      for (let i = 0; i < e.results.length; i++) said += e.results[i]![0]!.transcript
      setText((baseRef.current + said).replace(/\s+/g, ' ').trimStart())
    }
    rec.onend = () => { setListening(false); recRef.current = null }
    rec.onerror = e => {
      setListening(false); recRef.current = null
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') onError?.('Dovoli mikrofon za formai.si v nastavitvah brskalnika — ali uporabi mikrofon na tipkovnici.')
      else if (e.error !== 'no-speech' && e.error !== 'aborted') onError?.('Narekovanje ni uspelo — poskusi znova ali napiši.')
    }
    recRef.current = rec
    try { rec.start(); setListening(true) } catch { setListening(false); recRef.current = null }
  }
  const stop = () => recRef.current?.stop()
  return { listening, canSpeak, toggle, stop }
}
