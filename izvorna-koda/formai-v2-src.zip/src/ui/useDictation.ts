import { useEffect, useRef, useState } from 'react'

interface SpeechAlt { transcript: string; confidence: number }
interface SpeechResult { isFinal: boolean; length: number; [i: number]: SpeechAlt }
interface SpeechRec {
  lang: string; interimResults: boolean; continuous: boolean; maxAlternatives: number
  onresult: ((e: { resultIndex: number; results: ArrayLike<SpeechResult> }) => void) | null
  onend: (() => void) | null
  onerror: ((e: { error: string }) => void) | null
  start(): void; stop(): void; abort(): void
}
type SpeechCtor = new () => SpeechRec
export const speechCtor = (): SpeechCtor | null => {
  if (typeof window === 'undefined') return null
  const w = window as unknown as { SpeechRecognition?: SpeechCtor; webkitSpeechRecognition?: SpeechCtor }
  return w.SpeechRecognition || w.webkitSpeechRecognition || null
}
const isAndroid = () => typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent)
const join = (...parts: string[]) => parts.map(s => s.trim()).filter(Boolean).join(' ').replace(/\s+/g, ' ')

/** Največ zaporednih krogov brez govora (Android: krog ≈ 5–8 s tišine), nato se mikrofon sam ugasne. */
const SILENT_ROUNDS = 2
/** Najdaljše narekovanje v enem zamahu. */
const MAX_MS = 120_000

/**
 * Narekovanje (prepoznava govora brskalnika, sl-SI): besedilo se dopolnjuje za obstoječim; zvok ne gre k nam.
 * Kjer je brskalnik nima, `canSpeak` = false (ostane mikrofon na tipkovnici telefona).
 *
 * Zakaj v krogih (Blaž, 11. 10.: »mikrofon res slabo dela«): Chrome na Androidu v načinu `continuous` neha poslušati
 * ob prvem premoru in iste besede vrne dvakrat. Zato tam vsak krog posluša en stavek (`continuous = false`), ob koncu
 * kroga se besedilo potrdi in takoj začne nov krog — dokler uporabnik ne tapne znova, ne utihne za dva kroga ali
 * ne mine 2 min. Na namizju ostane neprekinjeno, a z istim nadaljevanjem po prekinitvi (Chrome neha po ~1 min).
 */
export function useDictation(text: string, setText: (t: string) => void, onError?: (msg: string) => void) {
  const [listening, setListening] = useState(false)
  const recRef = useRef<SpeechRec | null>(null)
  const want = useRef(false)                 // uporabnik hoče poslušati (dokler ne tapne znova)
  const base = useRef('')                    // besedilo pred narekovanjem
  const done = useRef('')                    // potrjeno v prejšnjih krogih
  const cur = useRef('')                     // ta krog (potrjeno + vmesno)
  const pushed = useRef(new Set<string>())   // kar smo sami nastavili — besedilo, ki ni od tu, je ročno tipkanje med narekovanjem
  const textRef = useRef(text); textRef.current = text
  const silent = useRef(0)
  const t0 = useRef(0)
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const canSpeak = !!speechCtor()

  useEffect(() => () => { want.current = false; if (timer.current) clearTimeout(timer.current); recRef.current?.abort() }, [])

  const push = (t: string) => { pushed.current.add(t); setText(t) }

  function finish() {
    want.current = false
    if (timer.current) { clearTimeout(timer.current); timer.current = null }
    setListening(false)
    const r = recRef.current; recRef.current = null
    try { r?.stop() } catch { /* že ustavljen */ }
  }

  function round() {
    const Ctor = speechCtor()
    if (!Ctor || !want.current) { finish(); return }
    const rec = new Ctor()
    rec.lang = 'sl-SI'; rec.interimResults = true; rec.maxAlternatives = 1
    rec.continuous = !isAndroid()
    cur.current = ''
    let heard = false
    rec.onresult = e => {
      // če je uporabnik medtem tipkal ali brisal (besedilo ni nobeno od naših), je njegovo besedilo nova podlaga
      if (pushed.current.size && !pushed.current.has(textRef.current)) {
        base.current = cur.current ? textRef.current.replace(cur.current, '') : textRef.current
        done.current = ''
      }
      let fin = '', interim = ''
      for (let i = 0; i < e.results.length; i++) {
        const r = e.results[i]!, t = r[0]?.transcript ?? ''
        if (r.isFinal) fin += t + ' '; else interim += t
      }
      cur.current = join(fin, interim)
      if (cur.current) heard = true
      // Android isti stavek včasih vrne še enkrat (nov krog) — pokažemo ga enkrat
      const dup = !!cur.current && done.current.endsWith(cur.current)
      push(join(base.current, done.current, dup ? '' : cur.current))
    }
    rec.onerror = e => {
      if (e.error === 'no-speech') return                   // sledi onend; šteje kot tih krog
      want.current = false
      if (e.error === 'aborted') return
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') onError?.('Dovoli mikrofon za formai.si (ključavnica ob naslovu) — ali uporabi mikrofon na tipkovnici.')
      else if (e.error === 'network') onError?.('Narekovanje potrebuje internet — poskusi znova ali napiši.')
      else if (e.error === 'audio-capture') onError?.('Mikrofon ni na voljo — morda ga uporablja druga aplikacija.')
      else if (e.error === 'language-not-supported') onError?.('Ta brskalnik ne zna slovenskega narekovanja — uporabi mikrofon na tipkovnici.')
      else onError?.('Narekovanje ni uspelo — poskusi znova ali napiši.')
    }
    rec.onend = () => {
      if (recRef.current !== rec) return                   // ustavil ga je uporabnik (finish)
      // kar je krog slišal, obvelja — tudi zadnji vmesni rezultat, ki ga Android ne potrdi vedno
      const c = cur.current
      if (c && !done.current.endsWith(c)) done.current = join(done.current, c)   // isti stavek dvakrat → enkrat
      cur.current = ''
      silent.current = heard ? 0 : silent.current + 1
      recRef.current = null
      if (want.current && silent.current < SILENT_ROUNDS && Date.now() - t0.current < MAX_MS) { timer.current = setTimeout(round, 150); return }
      finish()
    }
    recRef.current = rec
    try { rec.start() } catch { recRef.current = null; finish() }
  }

  function toggle() {
    if (want.current || recRef.current) { finish(); return }
    if (!speechCtor()) return
    want.current = true; silent.current = 0; t0.current = Date.now()
    base.current = textRef.current.trim(); done.current = ''; cur.current = ''; pushed.current = new Set()
    setListening(true)
    try { navigator.vibrate?.(12) } catch { /* ni vibracije */ }
    round()
  }
  const stop = () => finish()
  return { listening, canSpeak, toggle, stop }
}
