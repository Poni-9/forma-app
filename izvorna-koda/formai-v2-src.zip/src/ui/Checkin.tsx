import { addDays } from '@/domain/training/load'
import { useId, useRef, useState, type ReactNode } from 'react'
import { useApp, getState, saveCheckin, removeCheckin } from '@/state/store'
import { Card, Chip } from '@/ui/primitives'
import type { DailyCheckin } from '@/domain/types'
import { sleepBucket, fmtSleep } from '@/domain/wellness'
import { IcoWatch } from '@/ui/icons'

const MOOD: [1 | 2 | 3 | 4 | 5, string][] = [[1, 'Na tleh'], [2, 'Slabo'], [3, 'V redu'], [4, 'Dobro'], [5, 'Odlično']]
const SORE: [1 | 2 | 3 | 4 | 5, string][] = [[1, 'Nič'], [2, 'Malo'], [3, 'Precej'], [4, 'Zelo'], [5, 'Boli']]
const SLEEP = [5, 6, 7, 8, 9]
const sleepLabel = (h: number) => `${h === 9 ? '9+' : h === 5 ? '≤5' : String(h)} h`

/**
 * Jutranji vnos: energija, mišice, spanec. Trije tapi, vpliva na pripravljenost, načrt in nasvet.
 * Ko je izpolnjen, se strne v eno vrstico z »uredi« (ne izgine — vidiš, kaj si vpisal).
 */
/** Ali je jutranji vnos izpolnjen (energija, mišice in spanec — spanec lahko pride z ure). */
export function checkinDone(s: { checkinToday: DailyCheckin | null; settings: { wellnessOn?: boolean }; wellness?: readonly { date: string; sleepH?: number | null }[] | null; today: string }): boolean {
  const c = s.checkinToday
  const watchSleep = s.settings.wellnessOn ? s.wellness?.find(d => d.date === s.today)?.sleepH ?? null : null
  return c?.mood != null && c?.soreness != null && (c?.sleepH != null || watchSleep != null)
}

/** extra: vrstica pod vnosom (Danes: teža in »Stehtaj«) — jutro je ena kartica, ne dve. */
export function Checkin({ compact, extra, fold }: { compact?: boolean; extra?: ReactNode; /** (v3.49) prvi dan po uvodu: ena vrstica, »vpiši« odpre vnos */ fold?: boolean }) {
  const app = useApp()
  const c = app.checkinToday
  // hitri tapi: vsak vpis gradi na zadnjem stanju in na še ne shranjenih tapih, da drug drugega ne povozita
  const pend = useRef<Partial<DailyCheckin>>({})
  const [editing, setEditing] = useState(false)
  const [sleepEdit, setSleepEdit] = useState(false)
  const uid = useId()
  async function set(patch: Partial<DailyCheckin>) {
    pend.current = { ...pend.current, ...patch }
    const s = getState()
    const base = s.checkinToday && s.checkinToday.date === s.today ? s.checkinToday : { date: s.today }
    await saveCheckin({ ...base, ...pend.current, date: s.today })
    for (const k of Object.keys(patch) as (keyof DailyCheckin)[]) if (pend.current[k] === patch[k]) delete pend.current[k]
  }
  // spanec z ure (intervals.icu), dokler ga ne vpišeš sam
  const watchSleep = app.settings.wellnessOn ? app.wellness?.find(d => d.date === app.today)?.sleepH ?? null : null
  const autoSleep = c?.sleepH == null && watchSleep != null ? sleepBucket(watchSleep) : null
  const done = c?.mood != null && c?.soreness != null && (c?.sleepH != null || autoSleep != null)
  // »Kot včeraj«: en tap, ko je danes še prazno in je včeraj vse vpisano (spanec z ure ostane z ure)
  const y = (app.checkins || []).find(x => x.date === addDays(app.today, -1))
  const asYesterday = !c?.mood && !c?.soreness && c?.sleepH == null && y?.mood != null && y?.soreness != null ? y : null

  // (v3.49) prvi dan po uvodu: ena vrstica namesto 15 izbir (uvod je pravkar končan); »vpiši« odpre cel vnos s tehtanjem
  if (fold && !done && !editing) return (
    <Card tight style={{ marginTop: 12 }}>
      <div className="between" style={{ gap: 10 }}>
        <div style={{ minWidth: 0, fontSize: 12.5, color: 'var(--ink-2)' }}>
          <h2 className="h4" style={{ fontSize: 11, margin: '0 0 2px' }}>Kako si danes?</h2>
          <span>Energija, mišice in spanec → pripravljenost. Od jutri vsako jutro, 3 tapi.</span>
        </div>
        <button type="button" className="chip sm click" style={{ flex: 'none' }} onClick={() => setEditing(true)}>vpiši</button>
      </div>
      {/* (v3.50) teža s »stehtaj« ostane vidna tudi v zloženi kartici (vodnik pravi »stehtaj se zjutraj«) */}
      {extra && <div className="ci-extra">{extra}</div>}
    </Card>
  )
  if (compact && done && !editing) {
    const mood = MOOD.find(m => m[0] === c!.mood)?.[1], sore = SORE.find(m => m[0] === c!.soreness)?.[1]
    const sleep = c!.sleepH != null ? sleepLabel(c!.sleepH) : watchSleep != null ? fmtSleep(watchSleep) : null
    return (
      <Card tight style={{ marginTop: 12 }}>
        <div className="between" style={{ gap: 10 }}>
          <div style={{ minWidth: 0, fontSize: 12.5, color: 'var(--ink-2)' }}>
            <h2 className="h4" style={{ fontSize: 11, margin: '0 0 2px' }}>Jutro</h2>
            <span>Energija <b style={{ color: 'var(--ink)' }}>{mood?.toLowerCase()}</b> · mišice <b style={{ color: 'var(--ink)' }}>{sore?.toLowerCase()}</b>{sleep ? <> · spanec <b style={{ color: 'var(--ink)' }}>{sleep}</b>{c!.sleepH == null && watchSleep != null ? <IcoWatch width={12} height={12} aria-label="z ure" style={{ marginLeft: 3, verticalAlign: -1 }} /> : null}</> : null}</span>
          </div>
          <button className="chip sm click" style={{ flex: 'none' }} onClick={() => setEditing(true)}>uredi</button>
        </div>
        {extra && <div className="ci-extra">{extra}</div>}
      </Card>
    )
  }
  // oznaka + pet enako širokih gumbov v eni vrsti (brez prelamljanja, večji dotik); vrsta je skupina z imenom —
  // bralnik zaslona prebere »Mišice, skupina · Nič« namesto samega »Nič« (v3.48)
  const row = (key: string, label: React.ReactNode, chips: React.ReactNode) => (
    <div className="ci-row" role="group" aria-labelledby={`${uid}-${key}`}><span className="muted" id={`${uid}-${key}`}>{label}</span>{chips}</div>
  )
  return (
    <Card tight style={{ marginTop: 12 }}>
      <div className="between"><h2 className="h4" style={{ fontSize: 11, margin: 0 }}>{done ? 'Jutro' : 'Kako si danes?'}</h2>{done ? (compact ? <span className="row" style={{ gap: 6 }}><button type="button" className="chip sm click" onClick={() => { setEditing(false); void removeCheckin(app.today) }} aria-label="Izbriši današnji jutranji vnos">izbriši</button><button className="chip sm click" onClick={() => setEditing(false)}>končano</button></span> : <span className="muted" style={{ fontSize: 11 }}>shranjeno</span>) : asYesterday ? <button type="button" className="chip sm click" onClick={() => void set({ mood: asYesterday.mood, soreness: asYesterday.soreness, ...(asYesterday.sleepH != null && watchSleep == null ? { sleepH: asYesterday.sleepH } : {}) })} title="Isto kot včeraj" aria-label={`Kot včeraj: ${MOOD.find(m => m[0] === asYesterday.mood)?.[1] ?? ''}, mišice ${SORE.find(m => m[0] === asYesterday.soreness)?.[1] ?? ''}`}>kot včeraj</button> : <span className="muted" style={{ fontSize: 11 }}>{watchSleep != null && c?.sleepH == null ? '2 tapa' : '3 tapi'}</span>}</div>
      {row('e', 'Energija', MOOD.map(([v, l]) => <Chip key={v} sm on={c?.mood === v} onClick={() => void set({ mood: v })}>{l}</Chip>))}
      {row('m', 'Mišice', SORE.map(([v, l]) => <Chip key={v} sm on={c?.soreness === v} onClick={() => void set({ soreness: v })}>{l}</Chip>))}
      {/* spanec: z ure ena vrstica (manj tapov); brez ure ali ob popravku vrsta izbir */}
      {watchSleep != null && c?.sleepH == null && !sleepEdit
        ? <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>Spanec z ure: <b style={{ color: 'var(--ink)' }}>{fmtSleep(watchSleep)}</b> <button type="button" className="chip sm click" style={{ marginLeft: 6 }} onClick={() => setSleepEdit(true)}>popravi</button></div>
        : row('s', watchSleep != null ? <>Spanec <IcoWatch width={12} height={12} aria-label="z ure" style={{ verticalAlign: -1 }} /></> : 'Spanec', SLEEP.map(h => <Chip key={h} sm on={c?.sleepH === h || autoSleep === h} onClick={() => void set({ sleepH: h })}>{sleepLabel(h)}</Chip>))}
      {watchSleep != null && c?.sleepH == null && sleepEdit && <div className="muted" style={{ fontSize: 11, marginTop: 6 }}>Z ure: {fmtSleep(watchSleep)}. Če ni prav, tapni svojo vrednost.</div>}
      {extra && <div className="ci-extra">{extra}</div>}
    </Card>
  )
}

export { readinessOf } from '@/domain/readiness'
