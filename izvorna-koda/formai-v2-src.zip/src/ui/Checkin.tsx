import { useRef, useState } from 'react'
import { useApp, getState, saveCheckin } from '@/state/store'
import { Card, Chip } from '@/ui/primitives'
import type { DailyCheckin } from '@/domain/types'
import { sleepBucket, fmtSleep, type Recovery } from '@/domain/wellness'
import { IcoWatch } from '@/ui/icons'

const MOOD: [1 | 2 | 3 | 4 | 5, string][] = [[1, 'Na tleh'], [2, 'Slabo'], [3, 'V redu'], [4, 'Dobro'], [5, 'Odlično']]
const SORE: [1 | 2 | 3 | 4 | 5, string][] = [[1, 'Nič'], [2, 'Malo'], [3, 'Precej'], [4, 'Zelo'], [5, 'Boli']]
const SLEEP = [5, 6, 7, 8, 9]
const sleepLabel = (h: number) => `${h === 9 ? '9+' : h === 5 ? '≤5' : String(h)} h`

/**
 * Jutranji vnos: energija, mišice, spanec. Trije tapi, vpliva na pripravljenost, načrt in nasvet.
 * Ko je izpolnjen, se strne v eno vrstico z »uredi« (ne izgine — vidiš, kaj si vpisal).
 */
export function Checkin({ compact }: { compact?: boolean }) {
  const app = useApp()
  const c = app.checkinToday
  // hitri tapi: vsak vpis gradi na zadnjem stanju in na še ne shranjenih tapih, da drug drugega ne povozita
  const pend = useRef<Partial<DailyCheckin>>({})
  const [editing, setEditing] = useState(false)
  async function set(patch: Partial<DailyCheckin>) {
    pend.current = { ...pend.current, ...patch }
    const s = getState()
    const base = s.checkinToday && s.checkinToday.date === s.today ? s.checkinToday : { date: s.today }
    await saveCheckin({ ...base, ...pend.current, date: s.today })
    for (const k of Object.keys(patch) as (keyof DailyCheckin)[]) if (pend.current[k] === patch[k]) delete pend.current[k]
  }
  // spanec z ure (intervals.icu), dokler ga ne vpišeš sam
  const watchSleep = app.settings.wellnessOn ? app.wellness?.find(d => d.date === app.today)?.sleepH ?? null : null
  const autoSleep = c?.sleepH == null && watchSleep != null ? sleepBucket(watchSleep) : null
  const done = c?.mood != null && c?.soreness != null && (c?.sleepH != null || autoSleep != null)

  if (compact && done && !editing) {
    const mood = MOOD.find(m => m[0] === c!.mood)?.[1], sore = SORE.find(m => m[0] === c!.soreness)?.[1]
    const sleep = c!.sleepH != null ? sleepLabel(c!.sleepH) : watchSleep != null ? fmtSleep(watchSleep) : null
    return (
      <Card tight style={{ marginTop: 12 }}>
        <div className="between" style={{ gap: 10 }}>
          <div style={{ minWidth: 0, fontSize: 12.5, color: 'var(--ink-2)' }}>
            <h4 style={{ fontSize: 11, margin: '0 0 2px' }}>Jutro</h4>
            <span>Energija <b style={{ color: 'var(--ink)' }}>{mood?.toLowerCase()}</b> · mišice <b style={{ color: 'var(--ink)' }}>{sore?.toLowerCase()}</b>{sleep ? <> · spanec <b style={{ color: 'var(--ink)' }}>{sleep}</b>{c!.sleepH == null && watchSleep != null ? <IcoWatch width={12} height={12} aria-label="z ure" style={{ marginLeft: 3, verticalAlign: -1 }} /> : null}</> : null}</span>
          </div>
          <button className="chip sm click" style={{ flex: 'none' }} onClick={() => setEditing(true)}>uredi</button>
        </div>
      </Card>
    )
  }
  // oznaka + pet enako širokih gumbov v eni vrsti (brez prelamljanja, večji dotik)
  const row = (label: React.ReactNode, chips: React.ReactNode) => (
    <div className="ci-row"><span className="muted">{label}</span>{chips}</div>
  )
  return (
    <Card tight style={{ marginTop: 12 }}>
      <div className="between"><h4 style={{ fontSize: 11, margin: 0 }}>{done ? 'Jutro' : 'Kako si danes?'}</h4>{done ? (compact ? <button className="chip sm click" onClick={() => setEditing(false)}>končano</button> : <span className="muted" style={{ fontSize: 11 }}>shranjeno</span>) : <span className="muted" style={{ fontSize: 11 }}>3 tapi</span>}</div>
      {row('Energija', MOOD.map(([v, l]) => <Chip key={v} sm on={c?.mood === v} onClick={() => void set({ mood: v })}>{l}</Chip>))}
      {row('Mišice', SORE.map(([v, l]) => <Chip key={v} sm on={c?.soreness === v} onClick={() => void set({ soreness: v })}>{l}</Chip>))}
      {row(watchSleep != null ? <>Spanec <IcoWatch width={12} height={12} aria-label="z ure" style={{ verticalAlign: -1 }} /></> : 'Spanec', SLEEP.map(h => <Chip key={h} sm on={c?.sleepH === h || autoSleep === h} onClick={() => void set({ sleepH: h })}>{sleepLabel(h)}</Chip>))}
      {watchSleep != null && c?.sleepH == null && <div className="muted" style={{ fontSize: 11, marginTop: 6 }}>Z ure: {fmtSleep(watchSleep)}. Če ni prav, tapni svojo vrednost.</div>}
    </Card>
  )
}

/** Pripravljenost 0–100 iz forme, bolečin, spanca in energije — in podatkov ure (spanec, HRV, mirovni utrip), če so vklopljeni. */
export function readinessOf(tsb: number | null, c: DailyCheckin | null, rec?: Recovery | null): { score: number; label: string; color: string; reasons: string[] } | null {
  if (tsb == null && !c && !rec) return null
  let r = 60 + Math.max(-30, Math.min(30, tsb ?? 0)) * 1.2
  const why: string[] = []
  if (rec) { r -= rec.penalty; why.push(...rec.reasons) }
  if (c?.soreness) { r -= (c.soreness - 1) * 8; if (c.soreness >= 3) why.push('boleče mišice') }
  if (c?.sleepH) { if (c.sleepH <= 5) { r -= 15; why.push('malo spanja') } else if (c.sleepH === 6) { r -= 7; why.push('kratek spanec') } else if (c.sleepH >= 8) r += 4 }
  if (c?.mood) { if (c.mood <= 2) { r -= 10; why.push('malo energije') } else if (c.mood >= 4) r += 5 }
  if (tsb != null && tsb < -20) why.push('visoka utrujenost')
  let score = Math.round(Math.max(5, Math.min(100, r)))
  // telo ima zadnjo besedo: jasni znaki z ure (HRV, utrip, spanec) prevladajo nad svežino iz treninga
  if (rec && rec.penalty >= 20) score = Math.min(score, 44)
  else if (rec && rec.penalty >= 12) score = Math.min(score, 59)
  return { score, label: score >= 70 ? 'dobra' : score >= 45 ? 'srednja' : 'nizka', color: score >= 70 ? 'var(--ok)' : score >= 45 ? 'var(--warn)' : 'var(--bad)', reasons: why }
}
