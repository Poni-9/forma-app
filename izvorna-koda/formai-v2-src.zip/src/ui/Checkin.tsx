import { useApp, saveCheckin } from '@/state/store'
import { Card, Chip } from '@/ui/primitives'
import type { DailyCheckin } from '@/domain/types'

const MOOD: [1 | 2 | 3 | 4 | 5, string][] = [[1, 'Na tleh'], [2, 'Slabo'], [3, 'V redu'], [4, 'Dobro'], [5, 'Odlično']]
const SORE: [1 | 2 | 3 | 4 | 5, string][] = [[1, 'Nič'], [2, 'Malo'], [3, 'Precej'], [4, 'Zelo'], [5, 'Boli']]
const SLEEP = [5, 6, 7, 8, 9]

/** Jutranji vnos: energija, mišice, spanec. Trije tapi, vpliva na pripravljenost, načrt in nasvet. */
export function Checkin({ compact }: { compact?: boolean }) {
  const app = useApp()
  const c = app.checkinToday
  const set = (patch: Partial<DailyCheckin>) => saveCheckin({ ...(c || { date: app.today }), date: app.today, ...patch })
  const done = c?.mood != null && c?.soreness != null && c?.sleepH != null
  if (compact && done) return null
  const row = (label: string, chips: React.ReactNode) => (
    <div className="row" style={{ gap: 6, marginTop: 8, flexWrap: 'wrap', alignItems: 'center' }}>
      <span className="muted" style={{ fontSize: 11.5, fontWeight: 700, width: 64 }}>{label}</span>{chips}
    </div>
  )
  return (
    <Card tight style={{ marginTop: 12 }}>
      <div className="between"><h4 style={{ fontSize: 11, margin: 0 }}>{done ? 'Jutro' : 'Kako si danes?'}</h4>{done ? <span className="muted" style={{ fontSize: 11 }}>shranjeno</span> : <span className="muted" style={{ fontSize: 11 }}>3 tapi</span>}</div>
      {row('Energija', MOOD.map(([v, l]) => <Chip key={v} sm on={c?.mood === v} onClick={() => set({ mood: v })}>{l}</Chip>))}
      {row('Mišice', SORE.map(([v, l]) => <Chip key={v} sm on={c?.soreness === v} onClick={() => set({ soreness: v })}>{l}</Chip>))}
      {row('Spanec', SLEEP.map(h => <Chip key={h} sm on={c?.sleepH === h} onClick={() => set({ sleepH: h })}>{h === 9 ? '9+' : h === 5 ? '≤5' : String(h)} h</Chip>))}
    </Card>
  )
}

/** Pripravljenost 0–100 iz forme, bolečin, spanca in energije. */
export function readinessOf(tsb: number | null, c: DailyCheckin | null): { score: number; label: string; color: string; reasons: string[] } | null {
  if (tsb == null && !c) return null
  let r = 60 + Math.max(-30, Math.min(30, tsb ?? 0)) * 1.2
  const why: string[] = []
  if (c?.soreness) { r -= (c.soreness - 1) * 8; if (c.soreness >= 3) why.push('boleče mišice') }
  if (c?.sleepH) { if (c.sleepH <= 5) { r -= 15; why.push('malo spanja') } else if (c.sleepH === 6) { r -= 7; why.push('kratek spanec') } else if (c.sleepH >= 8) r += 4 }
  if (c?.mood) { if (c.mood <= 2) { r -= 10; why.push('malo energije') } else if (c.mood >= 4) r += 5 }
  if (tsb != null && tsb < -20) why.push('visoka utrujenost')
  const score = Math.round(Math.max(5, Math.min(100, r)))
  return { score, label: score >= 70 ? 'dobra' : score >= 45 ? 'srednja' : 'nizka', color: score >= 70 ? 'var(--ok)' : score >= 45 ? 'var(--warn)' : 'var(--bad)', reasons: why }
}
