import { cellCenter } from '@/domain/coverage/cells'

/**
 * Deljiva slika karte pokritosti (slog INTVL) — PNG 1080×1350 za Instagram/FB.
 * Rišemo v OffscreenCanvas, če obstaja, sicer v navaden <canvas>.
 */

export interface ShareInput {
  cells: Set<number>
  km: number
  areaKm2: number
  territories: number
  level: { n: number; name: string }
  streak: number
  name?: string
  accentHex: string
}

const W = 1080
const H = 1350
const FONT = 'Manrope, system-ui, sans-serif'
const BG = '#0F1216'

// Okvir karte: 960×760, 60 px od levega roba, 200 px od vrha.
const MAP_X = 60
const MAP_Y = 200
const MAP_W = 960
const MAP_H = 760

// Nad to mejo vzorčimo celice, da izris ostane hiter; sij rišemo samo pri manjših množicah.
const SAMPLE_ABOVE = 60_000
const GLOW_BELOW = 20_000

type Canvas2D = OffscreenCanvasRenderingContext2D | CanvasRenderingContext2D

function hexToRgba(hex: string, alpha: number): string {
  const h = hex.replace('#', '')
  const full = h.length === 3 ? h.split('').map(c => c + c).join('') : h
  const n = parseInt(full, 16)
  if (!Number.isFinite(n) || full.length !== 6) return `rgba(255,255,255,${alpha})`
  const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255
  return `rgba(${r},${g},${b},${alpha})`
}

function makeCanvas(): { canvas: OffscreenCanvas | HTMLCanvasElement; ctx: Canvas2D } {
  if (typeof OffscreenCanvas !== 'undefined') {
    const canvas = new OffscreenCanvas(W, H)
    const ctx = canvas.getContext('2d')
    if (ctx) return { canvas, ctx }
  }
  const canvas = document.createElement('canvas')
  canvas.width = W
  canvas.height = H
  const ctx = canvas.getContext('2d')
  if (!ctx) throw new Error('Canvas 2D ni na voljo')
  return { canvas, ctx }
}

async function toBlob(canvas: OffscreenCanvas | HTMLCanvasElement): Promise<Blob> {
  if (canvas instanceof HTMLCanvasElement) {
    return new Promise<Blob>((resolve, reject) => {
      canvas.toBlob(b => (b ? resolve(b) : reject(new Error('toBlob ni uspel'))), 'image/png')
    })
  }
  return canvas.convertToBlob({ type: 'image/png' })
}

function fmtInt(n: number): string {
  return Math.round(n).toLocaleString('sl-SI')
}

function areaLabel(areaKm2: number): { value: string; unit: string } {
  if (areaKm2 >= 1) return { value: areaKm2.toLocaleString('sl-SI', { minimumFractionDigits: 1, maximumFractionDigits: 1 }), unit: 'km²' }
  return { value: fmtInt(areaKm2 * 100), unit: 'ha' }
}

function drawBackground(ctx: Canvas2D, accent: string): void {
  ctx.fillStyle = BG
  ctx.fillRect(0, 0, W, H)
  const glow = ctx.createRadialGradient(W / 2, H / 6, 0, W / 2, H / 6, W * 0.75)
  glow.addColorStop(0, hexToRgba(accent, 0.10))
  glow.addColorStop(1, hexToRgba(accent, 0))
  ctx.fillStyle = glow
  ctx.fillRect(0, 0, W, H / 3 + 200)
}

function drawMap(ctx: Canvas2D, cells: Set<number>, accent: string): void {
  const total = cells.size
  if (total === 0) return
  const step = total > SAMPLE_ABOVE ? Math.ceil(total / SAMPLE_ABOVE) : 1

  const pts: number[] = []
  let minLat = Infinity, maxLat = -Infinity, minLon = Infinity, maxLon = -Infinity
  let i = 0
  for (const key of cells) {
    if (i++ % step !== 0) continue
    const [lat, lon] = cellCenter(key)
    if (lat < minLat) minLat = lat
    if (lat > maxLat) maxLat = lat
    if (lon < minLon) minLon = lon
    if (lon > maxLon) maxLon = lon
    pts.push(lat, lon)
  }
  if (pts.length === 0) return

  const midLat = (minLat + maxLat) / 2
  const cosLat = Math.max(0.05, Math.cos((midLat * Math.PI) / 180))
  const spanLat = Math.max(maxLat - minLat, 1e-4)
  const spanLon = Math.max((maxLon - minLon) * cosLat, 1e-4)
  const scale = Math.min(MAP_W / spanLon, MAP_H / spanLat)

  const drawW = spanLon * scale, drawH = spanLat * scale
  const ox = MAP_X + (MAP_W - drawW) / 2
  const oy = MAP_Y + (MAP_H - drawH) / 2

  // Velikost ene celice v px (1e-4° ≈ ena stranica); vzorčene celice povečamo, da ni lukenj.
  const px = Math.max(2, 1e-4 * scale * Math.sqrt(step))
  const half = px / 2

  ctx.save()
  ctx.fillStyle = accent
  if (total < GLOW_BELOW) {
    ctx.shadowColor = accent
    ctx.shadowBlur = 12
  }
  for (let k = 0; k < pts.length; k += 2) {
    const lat = pts[k] ?? 0, lon = pts[k + 1] ?? 0
    const x = ox + (lon - minLon) * cosLat * scale
    const y = oy + (maxLat - lat) * scale
    ctx.fillRect(x - half, y - half, px, px)
  }
  ctx.restore()
}

function drawText(ctx: Canvas2D, inp: ShareInput): void {
  const accent = inp.accentHex
  ctx.textBaseline = 'alphabetic'

  if (inp.name) {
    const first = inp.name.trim().split(/\s+/)[0] ?? ''
    ctx.fillStyle = '#FFFFFF'
    ctx.font = `600 44px ${FONT}`
    ctx.textAlign = 'left'
    ctx.fillText(first, 60, 120)
  }

  // Glavna številka pod karto.
  const area = areaLabel(inp.areaKm2)
  const yBig = MAP_Y + MAP_H + 150
  ctx.fillStyle = '#FFFFFF'
  ctx.textAlign = 'left'
  ctx.font = `800 132px ${FONT}`
  ctx.fillText(area.value, 60, yBig)
  const bigW = ctx.measureText(area.value).width
  ctx.font = `600 48px ${FONT}`
  ctx.fillText(area.unit, 60 + bigW + 18, yBig)
  ctx.fillStyle = 'rgba(255,255,255,0.6)'
  ctx.font = `500 36px ${FONT}`
  ctx.fillText('pobarvano', 60, yBig + 52)

  // Vrsta statistik.
  const stats: [string, string][] = [
    [fmtInt(inp.km), 'km'],
    [fmtInt(inp.territories), 'ozemelj'],
    [fmtInt(inp.streak), 'dni zapored'],
  ]
  const yStat = yBig + 150
  const colW = (W - 120) / stats.length
  stats.forEach(([v, label], idx) => {
    const x = 60 + colW * idx
    ctx.fillStyle = '#FFFFFF'
    ctx.font = `700 56px ${FONT}`
    ctx.fillText(v, x, yStat)
    ctx.fillStyle = 'rgba(255,255,255,0.6)'
    ctx.font = `500 28px ${FONT}`
    ctx.fillText(label, x, yStat + 40)
  })

  // Spodnja vrstica.
  const yFoot = H - 60
  ctx.font = `600 30px ${FONT}`
  ctx.fillStyle = 'rgba(255,255,255,0.75)'
  ctx.textAlign = 'left'
  ctx.fillText(`NIVO ${inp.level.n} · ${inp.level.name}`, 60, yFoot)

  ctx.textAlign = 'right'
  ctx.font = `800 34px ${FONT}`
  const tail = ' · formai.si'
  ctx.font = `500 30px ${FONT}`
  const tailW = ctx.measureText(tail).width
  ctx.font = `800 34px ${FONT}`
  const aiW = ctx.measureText('AI').width
  const right = W - 60
  ctx.font = `500 30px ${FONT}`
  ctx.fillStyle = 'rgba(255,255,255,0.6)'
  ctx.fillText(tail, right, yFoot)
  ctx.font = `800 34px ${FONT}`
  ctx.fillStyle = accent
  ctx.fillText('AI', right - tailW, yFoot)
  ctx.fillStyle = '#FFFFFF'
  ctx.fillText('FORM', right - tailW - aiW, yFoot)
}

export async function renderShareCard(inp: ShareInput): Promise<Blob> {
  const { canvas, ctx } = makeCanvas()
  drawBackground(ctx, inp.accentHex)
  drawMap(ctx, inp.cells, inp.accentHex)
  drawText(ctx, inp)
  return toBlob(canvas)
}

function isAbort(e: unknown): boolean {
  return typeof e === 'object' && e !== null && 'name' in e && (e as { name?: unknown }).name === 'AbortError'
}

export async function shareCard(inp: ShareInput): Promise<'shared' | 'downloaded' | 'copied'> {
  const blob = await renderShareCard(inp)
  const area = areaLabel(inp.areaKm2)
  const title = 'Moja karta pokritosti — FORMAI'
  const text = `${area.value} ${area.unit} pobarvano · ${fmtInt(inp.km)} km · nivo ${inp.level.n} ${inp.level.name} · formai.si`

  if (typeof File !== 'undefined' && typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
    const file = new File([blob], 'formai-karta.png', { type: 'image/png' })
    const data: ShareData = { files: [file], title, text }
    if (typeof navigator.canShare === 'function' && navigator.canShare(data)) {
      try {
        await navigator.share(data)
        return 'shared'
      } catch (e) {
        if (isAbort(e)) return 'shared'
        // Deljenje ni uspelo — poskusimo naprej z odložiščem.
      }
    }
  }

  if (typeof ClipboardItem !== 'undefined' && navigator.clipboard && typeof navigator.clipboard.write === 'function') {
    try {
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })])
      return 'copied'
    } catch {
      // Odložišče ni dovoljeno — prenos.
    }
  }

  const url = URL.createObjectURL(blob)
  try {
    const a = document.createElement('a')
    a.href = url
    a.download = 'formai-karta.png'
    a.rel = 'noopener'
    document.body.appendChild(a)
    a.click()
    a.remove()
  } finally {
    setTimeout(() => URL.revokeObjectURL(url), 1000)
  }
  return 'downloaded'
}
