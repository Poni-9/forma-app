import { Suspense } from 'react'
import type { PlanDay } from '@/domain/types'
import { retryLazy } from '@/app/chunk'
import { ChunkBoundary } from '@/ui/ChunkBoundary'
import { rem } from '@/ui/rem'

/**
 * (v3.51) Trasa na Danes (v zloženem razdelku) ni v začetnem paketu: prenese se, ko razdelek odpreš. Isti vmesnik.
 */
const L = retryLazy(() => import('./RouteCard').then(m => m.RouteCard))
export function RouteCard(p: { day: PlanDay; compact?: boolean; inCard?: boolean }) {
  // (v3.51) neuspel prenos: vrstica »Trase — ni naloženo« s »Poskusi znova« — prej je padel cel zaslon Danes
  return <ChunkBoundary inline="line" label="Trase"><Suspense fallback={<p className="muted" role="status" style={{ fontSize: rem(12.5) }}>Nalagam trase …</p>}><L {...p} /></Suspense></ChunkBoundary>
}
