/* Ikone iz dizajna v2 — inline SVG, barva prek currentColor. */
import type { SVGProps } from 'react'

/** Ikone zavihkov imajo »on«: izbrani zavihek dobi mehko polnilo glavne oblike. */
type IP = SVGProps<SVGSVGElement> & { on?: boolean }
const soft = (on?: boolean) => (on ? { fill: 'currentColor', fillOpacity: 0.2 } : {})

const P = (p: SVGProps<SVGSVGElement>) => ({ viewBox: '0 0 24 24', width: 21, height: 21, fill: 'none', stroke: 'currentColor', strokeWidth: 1.7, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const, ...p })

/** kolo: cestno kolo z diamantnim okvirjem (sedlo, krmilo, vilice) — prej dva kroga in trikotnik, na 15 px kot očala (Blaž, 17. 10.) */
export const IcoBike = (p: SVGProps<SVGSVGElement>) => <svg {...P({ strokeWidth: 1.8, ...p })}><circle cx="5.5" cy="16.5" r="3.6" /><circle cx="18.5" cy="16.5" r="3.6" /><path d="M5.5 16.5L10 9.5h6.2M11.3 16.5L10 9.5M11.3 16.5l5.2-6.3M5.5 16.5h5.8M16.2 9.5l2.3 7M8.6 8.2h2.8M15.4 7.6l1.9-.3" /></svg>
/** trenažer: sobno kolo od strani (vztrajnik, sedež, krmilo) — prej zaslon s križcem, ni bilo jasno, kaj je */
export const IcoTrainer = (p: SVGProps<SVGSVGElement>) => <svg {...P({ strokeWidth: 1.8, ...p })}><circle cx="15.4" cy="15.8" r="3.4" /><path d="M4 20.6h16M6.8 20.6 9.6 8.6M7.8 8.6h3.8M8.9 11.6h5.4l2.4-5.2M15.4 6.4h3" /></svg>
/** tek: tekač v koraku (glava, roki, noga naprej in nazaj) — prej palični možic, na 15 px nečitljiv */
export const IcoRun = (p: SVGProps<SVGSVGElement>) => <svg {...P({ strokeWidth: 1.8, ...p })}><circle cx="15" cy="4.4" r="1.9" /><path d="M13.4 8.3l-3 5.2M13.4 8.3l2.7 2.6 3 .6M13.4 8.3 9.8 8.7 7.6 11.4M10.4 13.5l3.8 2.4-.9 4.9M10.4 13.5l-1.6 3.6-4 .4" /></svg>
/** tehtnica: osebna tehtnica s številčnico — prej tehtnica s skodelicama (pravo, ne teža) */
export const IcoScale = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><rect x="3.5" y="3.5" width="17" height="17" rx="4.5" /><path d="M7.6 10.4a4.6 4.6 0 0 1 8.8 0z" /><path d="M12 10.4l1.5-2.3" /></svg>
export const IcoTarget = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><circle cx="12" cy="12" r="8.4" /><circle cx="12" cy="12" r="4.4" /><circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none" /></svg>
/** test: merilnik (kazalec na lestvici) — test moči ali utripa; tarča ostane za cilje */
export const IcoGauge = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M4.4 17.6a8.6 8.6 0 1 1 15.2 0" /><path d="M12 14.6l3.6-4.4M7 12.2h1M12 6.7v1M16.9 8.3l-.7.7" /><circle cx="12" cy="14.6" r="1.5" fill="currentColor" stroke="none" /></svg>
/** počitek: luna z »z« — prej srce (enako kot »Forma in zdravje«) */
export const IcoRest = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M17.8 15.4A7.4 7.4 0 0 1 8.4 6a7.4 7.4 0 1 0 9.4 9.4z" /><path d="M14.2 3.6h4.2l-4.2 4.6h4.2" strokeWidth={1.5} /></svg>
export const IcoHeart = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M20.8 5.6a5 5 0 00-7.1 0L12 7.3l-1.7-1.7a5 5 0 10-7.1 7.1L12 21.4l8.8-8.7a5 5 0 000-7.1z" /></svg>
/** moč: ročka z zaobljenimi utežmi — prej same črte (»IHI«) */
export const IcoDumbbell = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><rect x="5" y="6.3" width="3.4" height="11.4" rx="1.4" /><rect x="15.6" y="6.3" width="3.4" height="11.4" rx="1.4" /><path d="M2.6 9.6v4.8M21.4 9.6v4.8M8.4 12h7.2" /></svg>
/** Trener: oblaček z iskrico (AI). */
export const IcoChat = ({ on, ...p }: IP) => <svg {...P(p)}><path d="M20.5 11.6a8.1 8.1 0 0 1-11.7 7.3L4 20.3l1.4-4.3a8.1 8.1 0 1 1 15.1-4.4z" {...soft(on)} /><path d="M12.3 7.6l.95 2.3 2.3.95-2.3.95-.95 2.3-.95-2.3-2.3-.95 2.3-.95z" fill="currentColor" strokeWidth={1.2} /></svg>
/** Danes: hiša z vrati. */
export const IcoHome = ({ on, ...p }: IP) => <svg {...P(p)}><path d="M4 10.4 12 3.8l8 6.6v8.6a1.8 1.8 0 0 1-1.8 1.8H5.8A1.8 1.8 0 0 1 4 19z" {...soft(on)} /><path d="M9.6 20.8v-5.1a1 1 0 0 1 1-1h2.8a1 1 0 0 1 1 1v5.1" /></svg>
/** Plan: koledar s tremi dnevi. */
export const IcoCal = ({ on, ...p }: IP) => <svg {...P(p)}><rect x="3.5" y="5" width="17" height="15.8" rx="3" {...soft(on)} /><path d="M8 3.2v3.6M16 3.2v3.6M3.5 10h17" /><circle cx="8.2" cy="14.4" r="1.05" fill="currentColor" stroke="none" /><circle cx="12" cy="14.4" r="1.05" fill="currentColor" stroke="none" /><circle cx="15.8" cy="14.4" r="1.05" fill="currentColor" stroke="none" /></svg>
/** Prehrana: vilice in nož (prej krožnik s predolgim priborom — »YOP«); izbrani zavihek napolni rezilo. */
export const IcoFood = ({ on, ...p }: IP) => <svg {...P(p)}><path d="M5.6 3.2v4.9a2.4 2.4 0 0 0 4.8 0V3.2M8 3.2v17.6" /><path d="M17.8 14.8V3.2c-2 .6-3.4 3-3.4 6.6v3.4c0 .9.7 1.6 1.6 1.6z" {...soft(on)} /><path d="M17.8 14.8v6" /></svg>
export const IcoMore = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><circle cx="5" cy="12" r="1.6" /><circle cx="12" cy="12" r="1.6" /><circle cx="19" cy="12" r="1.6" /></svg>
export const IcoShare = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M12 16V4M8 8l4-4 4 4" /><rect x="4" y="12" width="16" height="9" rx="2.5" /></svg>
export const IcoMap = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M3.4 6.4 9 4.4l6 2 5.6-2v13.2L15 19.6l-6-2-5.6 2z" /><path d="M9 4.4v13.2M15 6.4v13.2" /></svg>
/** hribi: dva vrhova s snežno mejo — prej zemljevid (ta ostane za gumb »Zemljevid«) */
export const IcoMountain = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M2.6 19.4 9.2 8.2l4.1 7 2.8-4.2 5.3 8.4z" /><path d="M6.9 12.1l1.3 1 1-.9 1.2 1.1 1-.6" /><circle cx="18.3" cy="5.2" r="1.6" /></svg>
/** Napredek: krivulja navzgor. */
export const IcoChart = ({ on, ...p }: IP) => <svg {...P(p)}>{on && <path d="M4.5 15.8l4.2-4.3 3.3 2.8 5.7-6.3V19H4.5z" fill="currentColor" fillOpacity={0.2} stroke="none" />}<path d="M3.5 19.8h17" /><path d="M4.5 15.8l4.2-4.3 3.3 2.8 5.7-6.3" /><circle cx="19.3" cy="6.4" r="1.7" fill="currentColor" stroke="none" /></svg>
export const IcoGear = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z" /></svg>
export const IcoList = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" /></svg>
export const IcoUpload = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M12 16V4M7 9l5-5 5 5" /><path d="M4 17v2a2 2 0 002 2h12a2 2 0 002-2v-2" /></svg>
/** Narekovanje: mikrofon. */
export const IcoMic = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><rect x="9" y="3" width="6" height="11.5" rx="3" /><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3M9 21h6" /></svg>
/** Oceni z AI: iskrica. */
export const IcoSpark = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M12 3.5l1.9 4.9 4.9 1.9-4.9 1.9L12 17.1l-1.9-4.9-4.9-1.9 4.9-1.9z" /><path d="M18.5 15.5l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z" /></svg>
export const IcoCamera = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M4.6 8h2.5l1.5-2.2a1.7 1.7 0 0 1 1.4-.8h4a1.7 1.7 0 0 1 1.4.8L16.9 8h2.5a1.9 1.9 0 0 1 1.9 1.9v8.2a1.9 1.9 0 0 1-1.9 1.9H4.6a1.9 1.9 0 0 1-1.9-1.9V9.9A1.9 1.9 0 0 1 4.6 8z" /><circle cx="12" cy="13.6" r="3.3" /></svg>
/** Slika iz galerije. */
export const IcoImage = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><rect x="3.2" y="4.5" width="17.6" height="15" rx="3" /><circle cx="8.8" cy="9.6" r="1.6" /><path d="M3.6 17.4l4.6-4.3a1.4 1.4 0 0 1 1.9 0l3.4 3.1 2.2-2a1.4 1.4 0 0 1 1.9 0l3.1 2.8" /></svg>
export const IcoWatch = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><rect x="6.2" y="6.4" width="11.6" height="11.2" rx="3.4" /><path d="M9 6.4l.6-3h4.8l.6 3M9 17.6l.6 3h4.8l.6-3M12 9.4V12l1.7 1.2M17.8 10.6h.9" /></svg>
export const IcoPhone = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><rect x="7" y="2.5" width="10" height="19" rx="2.5" /><path d="M11 18h2" /></svg>
export const IcoFile = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8z" /><path d="M14 3v5h5M9 13h6M9 17h6" /></svg>
export const IcoStrava = (p: SVGProps<SVGSVGElement>) => <svg viewBox="0 0 24 24" width={20} height={20} fill="currentColor" {...p}><path d="M12 2.6L6.2 13.2h3.5L12 8.7l2.3 4.5h3.5zM14.3 13.2L12 17.6l-2.3-4.4H6.4L12 23.4l5.6-10.2z" /></svg>
export const IcoPlay = (p: SVGProps<SVGSVGElement>) => <svg viewBox="0 0 24 24" width={12} height={12} fill="currentColor" {...p}><path d="M7 4l12 8-12 8z" /></svg>
export const IcoCheck = (p: SVGProps<SVGSVGElement>) => <svg {...P({ strokeWidth: 2.4, ...p })}><path d="M5 12l5 5L20 7" /></svg>
/** pokal: dan tekme (na traku tedna in v pregledu dveh tednov) */
export const IcoTrophy = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M7.6 4h8.8v4.8a4.4 4.4 0 0 1-8.8 0z" /><path d="M7.6 6H5.4a.9.9 0 0 0-.9 1c.2 2 1.4 3.5 3.5 3.8M16.4 6h2.2a.9.9 0 0 1 .9 1c-.2 2-1.4 3.5-3.5 3.8M12 13.2v3.4M8.6 20.4h6.8l-.7-2.6a1.6 1.6 0 0 0-1.5-1.2h-2.4a1.6 1.6 0 0 0-1.5 1.2z" /></svg>
export const IcoBack = (p: SVGProps<SVGSVGElement>) => <svg {...P({ strokeWidth: 2.2, ...p })}><path d="M15 5l-7 7 7 7" /></svg>
export const IcoPlus = (p: SVGProps<SVGSVGElement>) => <svg {...P({ strokeWidth: 2.2, ...p })}><path d="M12 5v14M5 12h14" /></svg>
/** zajtrk: skodelica s paro (kava, čaj) — prej skleda, ki je spominjala na nasmeh */
export const IcoBreakfast = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M4.6 10h11.2v5.4a4.6 4.6 0 0 1-4.6 4.6h-2a4.6 4.6 0 0 1-4.6-4.6z" /><path d="M15.8 11.4h1.4a2.6 2.6 0 0 1 0 5.2h-1.6M8 3.6c-.8.9.8 1.9 0 3.1M12 3.6c-.8.9.8 1.9 0 3.1" /></svg>
/** malica: jabolko z listom */
export const IcoSnack = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M12 8.2c-1.6-1.1-5.9-1.3-6.8 2.6-.9 3.7 1.4 9.6 4.4 9.6 1 0 1.5-.5 2.4-.5s1.4.5 2.4.5c3 0 5.3-5.9 4.4-9.6-.9-3.9-5.2-3.7-6.8-2.6z" /><path d="M12 8.2c0-1.8.5-3.2 1.6-4.3M14 5.6c.9-1.4 2.4-1.9 3.8-1.7-.3 1.5-1.7 2.6-3.8 1.7z" /></svg>
/** kosilo, večerja: skleda z žlico — prej pokrov (zvonec) */
export const IcoLunch = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M3.4 12h17.2a8.6 8.6 0 0 1-17.2 0z" /><path d="M14.8 12 19.6 4.8M9.4 20.4h5.2M8 4.6c-.8.9.8 1.9 0 3.1M11.6 4.6c-.8.9.8 1.9 0 3.1" /></svg>
/** med vožnjo: bidon s pokrovčkom — prej kozarec s slamico (kot koš) */
export const IcoDrink = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M8.2 8.4h7.6l.6 3-.6 3 .6 3v1.8a2 2 0 0 1-2 2H9.6a2 2 0 0 1-2-2v-1.8l.6-3-.6-3z" /><path d="M9.2 8.4V7a1.2 1.2 0 0 1 1.2-1.2h3.2A1.2 1.2 0 0 1 14.8 7v1.4M11.1 5.8V3.4h1.8v2.4M8.2 14.4h7.6" /></svg>
/** Pojasnilo (zdravstveno opozorilo, informacija). */
export const IcoInfo = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><circle cx="12" cy="12" r="9" /><path d="M12 11v5.2M12 7.7v.1" /></svg>
/** Opozorilo (pod varno mejo, Strava, napaka povezave). */
export const IcoWarn = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M10.3 4.3 2.9 17.3A2 2 0 0 0 4.6 20.3h14.8a2 2 0 0 0 1.7-3L13.7 4.3a2 2 0 0 0-3.4 0z" /><path d="M12 9.6v4.1M12 16.9v.1" /></svg>
/** Pomoč: krog z vprašajem (»Kako deluje«, slovar izrazov). */
export const IcoHelp = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><circle cx="12" cy="12" r="8.6" /><path d="M9.6 9.4a2.5 2.5 0 0 1 4.9.7c0 1.7-2.5 2.2-2.5 3.8" /><circle cx="12" cy="16.9" r=".95" fill="currentColor" stroke="none" /></svg>
/** Pripomba: oblaček s klicajem (napaka, nejasno, predlog → razvijalcu). */
export const IcoFeedback = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M20.5 12a8 8 0 0 1-11.6 7.2L4 20.5l1.4-4.4A8 8 0 1 1 20.5 12z" /><path d="M12.5 7.6v5" /><circle cx="12.5" cy="15.6" r=".95" fill="currentColor" stroke="none" /></svg>
/** Puščica dol (razširi). */
export const IcoChevDown = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M6 9l6 6 6-6" /></svg>
/** Videz: sonce (svetlo) in luna (temno) — stikalo v glavi vsakega zaslona. */
export const IcoSun = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><circle cx="12" cy="12" r="4.2" /><path d="M12 2.8v2M12 19.2v2M2.8 12h2M19.2 12h2M5.5 5.5l1.4 1.4M17.1 17.1l1.4 1.4M5.5 18.5l1.4-1.4M17.1 6.9l1.4-1.4" /></svg>
export const IcoMoon = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M19.6 14.6A8 8 0 0 1 9.4 4.4a8 8 0 1 0 10.2 10.2z" /></svg>
/** Oseba (glava in ramena) — avatar brez imena (v3.48). */
export const IcoUser = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><circle cx="12" cy="8.4" r="3.9" /><path d="M4.6 20.2a7.4 7.4 0 0 1 14.8 0" /></svg>
