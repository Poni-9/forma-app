/* Ikone iz dizajna v2 — inline SVG, barva prek currentColor. */
import type { SVGProps } from 'react'

const P = (p: SVGProps<SVGSVGElement>) => ({ viewBox: '0 0 24 24', width: 21, height: 21, fill: 'none', stroke: 'currentColor', strokeWidth: 1.7, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const, ...p })

export const IcoBike = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><circle cx="6" cy="17" r="3.2" /><circle cx="18" cy="17" r="3.2" /><path d="M6 17l4-8h5l3 8M10 9h6" /></svg>
export const IcoTrainer = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><rect x="3" y="6" width="12" height="9" rx="2" /><path d="M6 19h9M9 15v4M18 8v8M15 10h6" /></svg>
export const IcoRun = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M13 4.5a1.4 1.4 0 100-.1zM9 21l2-5-2.5-2.5L7 9l4-1.5 3 2.5 3 .8" /><path d="M6.5 12L5 9M14 14.5l1.5 3.5 2.5 2" /></svg>
export const IcoScale = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M12 4v16M6 20h12M3 9l4-4 4 4a4 4 0 01-8 0zM13 9l4-4 4 4a4 4 0 01-8 0z" /></svg>
export const IcoTarget = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><circle cx="12" cy="12" r="8" /><circle cx="12" cy="12" r="4" /><circle cx="12" cy="12" r="1" fill="currentColor" /></svg>
export const IcoHeart = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M20.8 5.6a5 5 0 00-7.1 0L12 7.3l-1.7-1.7a5 5 0 10-7.1 7.1L12 21.4l8.8-8.7a5 5 0 000-7.1z" /></svg>
export const IcoDumbbell = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M4 9v6M7 7v10M17 7v10M20 9v6M7 12h10" /></svg>
export const IcoChat = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M21 15a2 2 0 01-2 2H8l-5 4V5a2 2 0 012-2h14a2 2 0 012 2z" /></svg>
export const IcoHome = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M3 11l9-8 9 8" /><path d="M5 10v10h14V10" /></svg>
export const IcoCal = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><rect x="3" y="5" width="18" height="16" rx="3" /><path d="M8 3v4M16 3v4M3 11h18" /></svg>
export const IcoFood = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M6 3v8a3 3 0 006 0V3M9 11v10" /><path d="M17 3c-1.5 2-2 4-2 6s.5 3 2 3 2-1 2-3-.5-4-2-6zM17 12v9" /></svg>
export const IcoMore = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><circle cx="5" cy="12" r="1.6" /><circle cx="12" cy="12" r="1.6" /><circle cx="19" cy="12" r="1.6" /></svg>
export const IcoShare = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M12 16V4M8 8l4-4 4 4" /><rect x="4" y="12" width="16" height="9" rx="2.5" /></svg>
export const IcoMap = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M3 6l6-2 6 2 6-2v14l-6 2-6-2-6 2z" /><path d="M9 4v14M15 6v14" /></svg>
export const IcoChart = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M4 19h16M6 16V10M11 16V5M16 16v-7" /></svg>
export const IcoGear = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z" /></svg>
export const IcoList = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" /></svg>
export const IcoUpload = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M12 16V4M7 9l5-5 5 5" /><path d="M4 17v2a2 2 0 002 2h12a2 2 0 002-2v-2" /></svg>
export const IcoCamera = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M4 8h3l2-3h6l2 3h3v11H4z" /><circle cx="12" cy="13" r="3.5" /></svg>
export const IcoWatch = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><rect x="7" y="6" width="10" height="12" rx="3" /><path d="M9 6V3h6v3M9 18v3h6v-3M12 10v3l2 1" /></svg>
export const IcoPhone = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><rect x="7" y="2.5" width="10" height="19" rx="2.5" /><path d="M11 18h2" /></svg>
export const IcoFile = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8z" /><path d="M14 3v5h5M9 13h6M9 17h6" /></svg>
export const IcoStrava = (p: SVGProps<SVGSVGElement>) => <svg viewBox="0 0 24 24" width={20} height={20} fill="currentColor" {...p}><path d="M12 2.6L6.2 13.2h3.5L12 8.7l2.3 4.5h3.5zM14.3 13.2L12 17.6l-2.3-4.4H6.4L12 23.4l5.6-10.2z" /></svg>
export const IcoPlay = (p: SVGProps<SVGSVGElement>) => <svg viewBox="0 0 24 24" width={12} height={12} fill="currentColor" {...p}><path d="M7 4l12 8-12 8z" /></svg>
export const IcoCheck = (p: SVGProps<SVGSVGElement>) => <svg {...P({ strokeWidth: 2.4, ...p })}><path d="M5 12l5 5L20 7" /></svg>
export const IcoBack = (p: SVGProps<SVGSVGElement>) => <svg {...P({ strokeWidth: 2.2, ...p })}><path d="M15 5l-7 7 7 7" /></svg>
export const IcoPlus = (p: SVGProps<SVGSVGElement>) => <svg {...P({ strokeWidth: 2.2, ...p })}><path d="M12 5v14M5 12h14" /></svg>
export const IcoBreakfast = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M4 11h16a8 8 0 01-8 8 8 8 0 01-8-8zM8 7c0-1.5 1-2 2-2M13 7c0-1.5 1-2 2-2" /></svg>
export const IcoLunch = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M3 18h18M5 18a7 7 0 0114 0M9 11c0-2 1.5-3 3-3s3 1 3 3" /></svg>
export const IcoDrink = (p: SVGProps<SVGSVGElement>) => <svg {...P(p)}><path d="M7 8h10l-1.2 11.2A2 2 0 0113.8 21h-3.6a2 2 0 01-2-1.8zM6 8l1-3h10l1 3M13 4l2-1" /></svg>
