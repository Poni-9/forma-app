/**
 * (v3.51) Spolno zaznamovane oblike v besedilih aplikacije (ne AI): uporabnica (`sex === 'z'`) dobi žensko obliko,
 * vsi drugi (moški ali spol ni podan) moško — kot prej. Kjer gre, je ženska oblika brez spola (»Opravljeno«).
 * g(p, 'si ga naredil?', 'si ga naredila?')
 */
export type SexLike = { sex?: string | null } | null | undefined

/** Ali je uporabnica ženska (profil `sex: 'z'`). */
export const isF = (p: SexLike): boolean => p?.sex === 'z'

/** Moška ali ženska oblika po profilu. */
export function g(p: SexLike, m: string, f: string): string {
  return isF(p) ? f : m
}
