import { useLayoutEffect, useRef } from 'react'

/** zadnja prikazana vrednost po ključu (npr. »kcal:2026-10-17«) — ob vrnitvi na zaslon z isto številko brez štetja */
const lastShown = new Map<string, number>()

/**
 * (v3.49) Številka, ki se našteje do vrednosti — piše samo v svoj element (ref, requestAnimationFrame), brez stanja
 * zaslona. Prej je useCountUp v korenu Danes in Prehrane 1,1 s v vsaki sličici na novo izrisal cel zaslon (~66-krat,
 * 700–790 ms dolgih opravil na srednjem telefonu). Šteje ob spremembi; prvič (ključ še ni znan) od 0.
 * Spoštuje prefers-reduced-motion.
 */
export function CountUp({ value, ms = 1100, id, format = (n: number) => String(Math.round(n)) }: { value: number; ms?: number; id?: string; format?: (n: number) => string }) {
  const ref = useRef<HTMLSpanElement>(null)
  const shown = useRef<number | null>(null)
  const fmt = useRef(format)
  fmt.current = format
  useLayoutEffect(() => {
    const el = ref.current
    if (!el) return
    const put = (n: number) => { el.textContent = fmt.current(n); shown.current = n; if (id != null) lastShown.set(id, n) }
    const from = shown.current ?? (id != null ? lastShown.get(id) : undefined) ?? 0
    const reduce = typeof matchMedia !== 'undefined' && matchMedia('(prefers-reduced-motion: reduce)').matches
    if (reduce || !Number.isFinite(value) || Math.abs(value - from) < 0.5 || typeof requestAnimationFrame === 'undefined') { put(value); return }
    put(from)
    const start = performance.now(), d = value - from
    let raf = 0
    const step = () => {
      const k = Math.min(1, Math.max(0, (performance.now() - start) / ms)), e = 1 - Math.pow(1 - k, 3)
      put(k < 1 ? from + d * e : value)
      if (k < 1) raf = requestAnimationFrame(step)
    }
    raf = requestAnimationFrame(step)
    return () => cancelAnimationFrame(raf)
  }, [value, ms, id])
  return <span ref={ref} />
}
