import { Suspense, type ComponentProps } from 'react'
import { retryLazy } from '@/app/chunk'
import { ChunkBoundary } from '@/ui/ChunkBoundary'
import type { FuelLogCard as Card } from './FuelLog'

/** (v3.51) Kartica goriva po vožnji (samo po opravljeni vožnji) ni v začetnem paketu. Isti vmesnik. */
const L = retryLazy(() => import('./FuelLog').then(m => m.FuelLogCard))
export function FuelLogCard(p: ComponentProps<typeof Card>) {
  // (v3.51) neuspel prenos: kartice ni (poskusi znova ob vrnitvi povezave) — prej je padel cel zaslon Danes
  return <ChunkBoundary inline="hide"><Suspense fallback={null}><L {...p} /></Suspense></ChunkBoundary>
}
