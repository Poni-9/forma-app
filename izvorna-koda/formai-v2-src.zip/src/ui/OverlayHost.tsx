import { useOverlays } from '@/ui/overlays'
import { HelpSheet } from '@/ui/HelpSheet'
import { FeedbackSheet } from '@/ui/FeedbackSheet'

/** Gostitelj listov »Kako deluje« in »Pripomba« — en za vse zaslone (tudi uvod, prijava, vadba). */
export function OverlayHost() {
  const { help, fb } = useOverlays()
  return (<>
    {help && <HelpSheet key={`h-${help.term ?? ''}`} term={help.term} />}
    {fb && <FeedbackSheet shot={fb.shot} route={fb.route} />}
  </>)
}
