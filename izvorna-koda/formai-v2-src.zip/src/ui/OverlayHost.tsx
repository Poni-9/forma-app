import { lazy, Suspense } from 'react'
import { createPortal } from 'react-dom'
import { useOverlays, closeFeedback } from '@/ui/overlays'
import { HelpSheet } from '@/ui/HelpSheet'
import { usePhotoTraining, closePhotoTraining } from '@/ui/photoOpen'
import { ChunkBoundary } from '@/ui/ChunkBoundary'
import { orReload } from '@/app/chunk'

/** (v3.50) List »Pripomba« (z narekovanjem in branjem slik) ni v začetnem paketu: prenese se ob mirovanju ali ob prvem odprtju. */
const loadFeedback = () => import('@/ui/FeedbackSheet').then(m => ({ default: m.FeedbackSheet }))
// (v3.50) del kode se ne naloži: enkrat osveži (kot zasloni), nato list z »Osveži« (ChunkBoundary) — ne pade cela aplikacija
const FeedbackSheet = lazy(() => orReload(loadFeedback()))
export const preloadFeedback = (): Promise<unknown> => loadFeedback().catch(() => null)
/** (v3.50) List »Trening s slike« (AI, slike vaj) se prenese ob mirovanju (zadnji) ali ob prvem odprtju. */
const loadPhoto = () => import('@/ui/PhotoTrainingSheet').then(m => ({ default: m.PhotoTrainingSheet }))
const PhotoTrainingSheet = lazy(() => orReload(loadPhoto()))
export const preloadPhotoTraining = (): Promise<unknown> => loadPhoto().catch(() => null)

/**
 * Dokler se list še prenaša (prvič, preden ga je aplikacija prenesla ob mirovanju): isti videz takoj, da tap ni brez
 * odziva. Brez vnosa v zgodovino in fokusa (to naredi pravi list čez trenutek).
 */
function FeedbackWait() {
  return createPortal(<>
    <div className="veil" onClick={closeFeedback} />
    <div className="sheet" aria-busy="true"><div className="grab" />
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Pripomba ali napaka</b>
      <p className="muted" role="status" style={{ fontSize: 12.5, marginTop: 4 }}>Odpiram …</p>
    </div>
  </>, document.body)
}

/** Gostitelj listov »Kako deluje« in »Pripomba« — en za vse zaslone (tudi uvod, prijava, vadba). */
export function OverlayHost() {
  const { help, fb } = useOverlays()
  const photo = usePhotoTraining()
  return (<>
    {help && <HelpSheet key={`h-${help.term ?? ''}`} term={help.term} />}
    {fb && <ChunkBoundary onClose={closeFeedback}><Suspense fallback={<FeedbackWait />}><FeedbackSheet shot={fb.shot} route={fb.route} capturing={!!fb.capturing} /></Suspense></ChunkBoundary>}
    {photo.req && <ChunkBoundary key={photo.key} onClose={closePhotoTraining}><Suspense fallback={null}><PhotoTrainingSheet req={photo.req} /></Suspense></ChunkBoundary>}
  </>)
}
