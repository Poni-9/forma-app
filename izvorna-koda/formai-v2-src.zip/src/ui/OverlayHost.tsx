import { Suspense } from 'react'
import { createPortal } from 'react-dom'
import { useOverlays, closeFeedback } from '@/ui/overlays'
import { HelpSheet } from '@/ui/HelpSheet'
import { usePhotoTraining, closePhotoTraining } from '@/ui/photoOpen'
import { ChunkBoundary } from '@/ui/ChunkBoundary'
import { retryLazy } from '@/app/chunk'
import { rem } from '@/ui/rem'

/** (v3.50) List »Pripomba« (z narekovanjem in branjem slik) ni v začetnem paketu: prenese se ob mirovanju ali ob prvem odprtju. */
const loadFeedback = () => import('@/ui/FeedbackSheet').then(m => m.FeedbackSheet)
// (v3.50) del kode se ne naloži: enkrat osveži (kot zasloni), nato list z »Osveži« (ChunkBoundary) — ne pade cela aplikacija
// (v3.51) ob naslednjem odprtju (ali »Poskusi znova«) prenaša znova — prej do osvežitve aplikacije
const FeedbackSheet = retryLazy(loadFeedback)
export const preloadFeedback = (): Promise<unknown> => loadFeedback().catch(() => null)
/** (v3.50) List »Trening s slike« (AI, slike vaj) se prenese ob mirovanju (zadnji) ali ob prvem odprtju. */
const loadPhoto = () => import('@/ui/PhotoTrainingSheet').then(m => m.PhotoTrainingSheet)
const PhotoTrainingSheet = retryLazy(loadPhoto)
export const preloadPhotoTraining = (): Promise<unknown> => loadPhoto().catch(() => null)

/**
 * (v3.51) tudi »Trening s slike« (prej prazno 0,6 s ob prvem tapu na počasnem omrežju).
 * Dokler se list še prenaša (prvič, preden ga je aplikacija prenesla ob mirovanju): isti videz takoj, da tap ni brez
 * odziva. Brez vnosa v zgodovino in fokusa (to naredi pravi list čez trenutek).
 */
function SheetWait({ title, onClose }: { title: string; onClose: () => void }) {
  return createPortal(<>
    <div className="veil" onClick={onClose} />
    <div className="sheet" aria-busy="true"><div className="grab" />
      <b style={{ fontSize: rem(17), letterSpacing: '-.02em' }}>{title}</b>
      <p className="muted" role="status" style={{ fontSize: rem(12.5), marginTop: 4 }}>Odpiram …</p>
    </div>
  </>, document.body)
}

/** Gostitelj listov »Kako deluje« in »Pripomba« — en za vse zaslone (tudi uvod, prijava, vadba). */
export function OverlayHost() {
  const { help, fb } = useOverlays()
  const photo = usePhotoTraining()
  return (<>
    {help && <HelpSheet key={`h-${help.term ?? ''}`} term={help.term} />}
    {fb && <ChunkBoundary onClose={closeFeedback} label="Pripomba ali napaka"><Suspense fallback={<SheetWait title="Pripomba ali napaka" onClose={closeFeedback} />}><FeedbackSheet shot={fb.shot} route={fb.route} capturing={!!fb.capturing} /></Suspense></ChunkBoundary>}
    {photo.req && <ChunkBoundary key={photo.key} onClose={closePhotoTraining} label="Trening s slike"><Suspense fallback={<SheetWait title="Trening s slike" onClose={closePhotoTraining} />}><PhotoTrainingSheet req={photo.req} /></Suspense></ChunkBoundary>}
  </>)
}
