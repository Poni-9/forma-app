import { useMemo } from 'react'
import { useApp } from '@/state/store'
import { bikeWeeks, baselineHours, zoneSplit, keyCompliance, efTrend } from '@/domain/training/review'
import { weekContext } from '@/domain/training/planner'
import { addDays, weekStartIso } from '@/domain/training/load'
import { lthrOf } from '@/domain/training/load'
import { Card } from '@/ui/primitives'

const f1 = (x: number) => x.toFixed(1).replace('.', ',')

/**
 * Trening v resnici: kaj res delaš (Garmin prek intervals.icu), ne kaj piše v načrtu.
 * Ure na teden proti načrtu, 80/20 po utripu, ključni treningi, aerobna učinkovitost, merilnik moči.
 */
export function RealityCard() {
  const app = useApp()
  const { activities: acts, plan, today, profile: p } = app
  const d = useMemo(() => {
    const bw = bikeWeeks(acts, today, 8)
    const base = baselineHours(acts, today, 8)
    const zs = zoneSplit(acts.filter(a => a.date >= addDays(today, -28)))
    const kc = keyCompliance(plan, acts, addDays(today, -14), addDays(today, -1))
    const ef = efTrend(acts, today, 12)
    return { bw, base, zs, kc, ef }
  }, [acts, plan, today])
  const cx = weekContext(p, weekStartIso(today))
  if (!d.bw.full.length && !d.zs) return null
  const weeks = [...d.bw.full, { ...d.bw.current, partial: true } as typeof d.bw.current & { partial?: boolean }]
  const max = Math.max(cx.hours || 0, ...weeks.map(w => w.hours), 1)
  const efCh = d.ef.length >= 3 ? ((d.ef[d.ef.length - 1]!.ef - d.ef[0]!.ef) / d.ef[0]!.ef) * 100 : null
  const L = lthrOf(p)

  return (
    <Card>
      <h4 style={{ margin: 0 }}>Trening v resnici</h4>
      <p className="muted" style={{ fontSize: 11.5, marginTop: 2 }}>Iz tvojih voženj z Garmina (intervals.icu) — ne iz načrta.</p>

      {/* ure na teden */}
      <div className="between" style={{ marginTop: 12, fontSize: 12.5 }}>
        <b style={{ color: 'var(--ink)' }}>Ure na kolesu</b>
        <span className="muted">povprečno {d.base != null ? `${f1(d.base)} h` : '—'} · načrt ta teden {f1(cx.hours)} h</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 4, height: 106, marginTop: 10, position: 'relative' }} role="img" aria-label={`Ure na teden: ${weeks.map(w => f1(w.hours)).join(', ')}`}>
        {cx.hours > 0 && <div style={{ position: 'absolute', left: 0, right: 0, bottom: `${(cx.hours / max) * 70 + 14}px`, borderTop: '1px dashed var(--ink-3)' }} />}
        {weeks.map((w, i) => (
          <div key={w.weekStart} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2 }}>
            <span style={{ fontSize: 9.5, color: 'var(--ink-3)', fontWeight: 700 }}>{w.hours ? f1(w.hours) : ''}</span>
            <div style={{ width: '100%', maxWidth: 26, height: Math.max(2, (w.hours / max) * 70), borderRadius: '4px 4px 0 0', background: (w as { partial?: boolean }).partial ? 'var(--raised)' : 'var(--t-kolo)', border: (w as { partial?: boolean }).partial ? '1px dashed var(--t-kolo)' : 0 }} />
            <span style={{ fontSize: 9, color: 'var(--ink-3)' }}>{i === weeks.length - 1 ? 'zdaj' : `${+w.weekStart.slice(8)}.${+w.weekStart.slice(5, 7)}.`}</span>
          </div>
        ))}
      </div>
      {d.base != null && cx.hours > d.base * 1.5 && <p style={{ fontSize: 12, marginTop: 6, color: 'var(--warn)' }}>Načrt je {f1(cx.hours / d.base)}× več, kot zdaj res voziš. Skok nad ~1,3× na teden je recept za poškodbo — načrt naj raste postopno (+10 % na teden).</p>}

      {/* 80/20 */}
      {d.zs && <>
        <div className="between" style={{ marginTop: 14, fontSize: 12.5 }}><b style={{ color: 'var(--ink)' }}>Intenzivnost · 4 tedne</b><span className="muted">{d.zs.minutes} min z utripom</span></div>
        <div style={{ display: 'flex', height: 10, borderRadius: 5, overflow: 'hidden', gap: 2, marginTop: 8 }}>
          <i style={{ flex: d.zs.easy, background: 'var(--t-kolo)' }} /><i style={{ flex: d.zs.mid, background: 'var(--warn)' }} /><i style={{ flex: d.zs.hard, background: 'var(--t-moc)' }} />
        </div>
        <div className="muted" style={{ fontSize: 11.5, marginTop: 5 }}>{d.zs.easy} % lahko (Z1–Z2) · {d.zs.mid} % tempo · {d.zs.hard} % prag in više — cilj ~80 % lahko{d.zs.mid > 15 ? '. Veliko »sive cone«: lahko naj bo lažje, težko naj bo težje.' : '.'}</div>
      </>}

      {/* ključni treningi */}
      {d.kc.total > 0 && <>
        <div className="between" style={{ marginTop: 14, fontSize: 12.5 }}><b style={{ color: 'var(--ink)' }}>Ključni treningi · 2 tedna</b><span style={{ fontWeight: 800, color: d.kc.ok === d.kc.total ? 'var(--ok)' : 'var(--warn)' }}>{d.kc.ok} / {d.kc.total}</span></div>
        <div style={{ marginTop: 4 }}>{d.kc.items.map(i => (
          <div key={i.date + i.title} className="between" style={{ fontSize: 12, padding: '3px 0' }}>
            <span style={{ color: 'var(--ink-2)' }}>{+i.date.slice(8)}. {+i.date.slice(5, 7)}. · {i.title}</span>
            <span style={{ fontWeight: 700, color: i.status === 'ok' ? 'var(--ok)' : i.status === 'delno' ? 'var(--warn)' : 'var(--bad)' }}>{i.status === 'ok' ? 'opravljen' : i.status === 'delno' ? 'delno' : i.status === 'drugace' ? 'drugače' : 'ni'}</span>
          </div>))}</div>
      </>}

      {/* aerobna učinkovitost */}
      {efCh != null && <>
        <div className="between" style={{ marginTop: 14, fontSize: 12.5 }}><b style={{ color: 'var(--ink)' }}>Aerobna učinkovitost</b><span style={{ fontWeight: 800, color: efCh >= 0 ? 'var(--ok)' : 'var(--warn)' }}>{efCh >= 0 ? '+' : ''}{f1(efCh)} %</span></div>
        <div className="muted" style={{ fontSize: 11.5, marginTop: 3 }}>Hitrost na utrip na ravnih vožnjah: {f1(d.ef[0]!.ef)} → {f1(d.ef[d.ef.length - 1]!.ef)} km/h na 100 udarcev. Raste = baza se gradi (veter in skupina motita posamezne vožnje, šteje trend).</div>
      </>}

      {/* merilnik moči */}
      {p.gear.powerMeter === false && <p style={{ fontSize: 12, marginTop: 14, color: 'var(--ink-2)' }}><b style={{ color: 'var(--ink)' }}>Brez merilnika moči</b>{p.gear.powerMeterAuto ? ' (zaznano iz voženj)' : ''}: cilji so v utripu{L ? ` (pražni utrip ${L})` : ''} in občutku. Vati v načrtu so samo orientacija; merilnik moči (pedala ali gonilka) je največja nadgradnja.</p>}
    </Card>
  )
}
