import type { ReactNode } from 'react'
import { IcoChevDown } from '@/ui/icons'

/**
 * Razdelek nastavitev ali napredka kot ena vrstica (naslov + kratek povzetek); vsebina se odpre ob tapu
 * (Blaž, 11. 10.: čim manj okvirčkov — zaprto je ena vrstica, ne cela kartica).
 */
export function Section({ id, title, sum, open, onToggle, children, className }: { id?: string; title: string; sum?: ReactNode; open: boolean; onToggle: () => void; children: ReactNode; className?: string }) {
  return (
    <div id={id} className={`card sec${open ? ' open' : ''}${className ? ` ${className}` : ''}`}>
      {/* naslov razdelka (h2, v3.48): z bralnikom zaslona skok med razdelki; videz enak (.sec-t) */}
      <h2 className="sec-t">
        <button type="button" className="sec-h" aria-expanded={open} aria-controls={id ? `${id}-b` : undefined} onClick={onToggle}>
          <span style={{ minWidth: 0 }}><b>{title}</b>{sum ? <small>{sum}</small> : null}</span>
          <IcoChevDown width={18} height={18} aria-hidden="true" className="chev" />
        </button>
      </h2>
      {open && <div id={id ? `${id}-b` : undefined} className="sec-b">{children}</div>}
    </div>
  )
}
