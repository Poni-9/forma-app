import { navigate } from '@/app/router'
import type { DailyCheckin } from '@/domain/types'
import { fmtSleep, type Recovery } from '@/domain/wellness'
import { Btn, Sheet } from './primitives'
import { signed } from './format'
import { rem } from '@/ui/rem'

const MOOD = ['', 'na tleh', 'slaba', 'v redu', 'dobra', 'odlična']
const SORE = ['', 'brez bolečin', 'malo', 'precej', 'zelo', 'boli']

/**
 * Zakaj je pripravljenost taka: forma (utrujenost iz treninga), jutranji tapi in — če je vklopljeno — spanec, HRV
 * in mirovni utrip z ure v primerjavi s TVOJIM običajnim. Pri nizki ponudi lažji dan.
 */
export function ReadinessSheet({ open, onClose, ready, rec, tsb, checkin, wellnessOn, hasIntervals, garmin = false, device, onEase }: {
  open: boolean; onClose: () => void
  ready: { score: number; label: string; color: string; reasons: string[] }
  rec: Recovery | null; tsb: number | null; checkin: DailyCheckin | null
  wellnessOn: boolean; hasIntervals: boolean
  /** (v3.52) Garmin Connect je povezan neposredno: stres in Body Battery, vir »prek Garmin Connect« */
  garmin?: boolean
  /** ura, s katere so spanec/HRV/utrip (Garmin pripis), npr. »Garmin Forerunner 255« */
  device?: string | null
  onEase?: (() => void) | null
}) {
  const Row = ({ l, v, note, warn }: { l: string; v: string; note?: string; warn?: boolean }) => (
    <div className="between" style={{ padding: '9px 0', borderTop: '1px solid var(--line)', alignItems: 'flex-start' }}>
      <span className="muted" style={{ fontSize: rem(13), fontWeight: 600 }}>{l}</span>
      <span style={{ textAlign: 'right' }}><b style={{ fontSize: rem(13.5), color: warn ? 'var(--warn)' : 'var(--ink)' }}>{v}</b>{note && <div className="muted" style={{ fontSize: rem(11.5) }}>{note}</div>}</span>
    </div>
  )
  const hrvLow = rec?.hrvZ != null && rec.hrvZ < -0.75
  return (
    <Sheet open={open} onClose={onClose}>
      <div className="between">
        <b style={{ fontSize: rem(17), letterSpacing: '-.02em' }}>Pripravljenost {ready.score}</b>
        <span style={{ fontSize: rem(12), fontWeight: 800, color: ready.color }}>{ready.label}</span>
      </div>
      {/* (v3.50) pri dobri oceni (≥ 70) ni »nižja« — »Kaj vpliva« */}
      <p style={{ fontSize: rem(12.5), marginTop: 4 }}>{ready.reasons.length ? `${ready.score >= 70 ? 'Kaj vpliva' : 'Zakaj nižja'}: ${ready.reasons.join(', ')}.` : 'Nič ne kaže na utrujenost — drži se načrta.'}</p>
      <div style={{ marginTop: 10 }}>
        {tsb != null && <Row l="Forma iz treninga" v={signed(Math.round(tsb), 0)} note={tsb < -20 ? 'visoka utrujenost' : tsb >= 25 ? 'dolgo brez rednega treninga' : tsb > 10 ? 'svež' : 'v pravem območju'} warn={tsb < -20} />}
        {rec?.sleepH != null
          ? <Row l="Spanec (ura)" v={fmtSleep(rec.sleepH)} note={rec.sleepScore != null ? `ocena ${rec.sleepScore}/100` : undefined} warn={rec.sleepH < 6.5} />
          : checkin?.sleepH != null ? <Row l="Spanec" v={`${checkin.sleepH === 9 ? '9+' : checkin.sleepH === 5 ? '≤5' : checkin.sleepH} h`} warn={checkin.sleepH <= 6} /> : null}
        {rec?.hrv != null && <Row l="HRV (noč)" v={`${Math.round(rec.hrv)} ms`} note={rec.hrvBase ? `običajno ${rec.hrvBase.lo}–${rec.hrvBase.hi} ms` : 'običajno pokažem po 7 nočeh'} warn={hrvLow} />}
        {rec?.rhr != null && <Row l="Mirovni utrip" v={`${rec.rhr}`} note={rec.rhrBase ? `običajno ${rec.rhrBase.mean}${rec.rhrDelta ? ` (${signed(rec.rhrDelta, 0)})` : ''}` : undefined} warn={(rec.rhrDelta ?? 0) >= 4} />}
        {/* (v3.52) Garmin neposredno: povprečni stres VČERAJŠNJEGA dne in Body Battery (recoveryOf: ≥ 50 → −4, < 30 → −6); »ob prebujanju« samo, če jo je Garmin dal */}
        {rec?.stress != null && <Row l="Stres včeraj (Garmin)" v={`${Math.round(rec.stress)}`} note={rec.stress >= 50 ? 'visok — telo si še ni odpočilo' : rec.stress >= 26 ? 'zmeren' : 'nizek'} warn={rec.stress >= 50} />}
        {rec?.bodyBattery != null && <Row l="Body Battery" v={`${Math.round(rec.bodyBattery)}`} note={rec.bodyBatteryAtWake ? 'ob prebujanju' : 'najvišja danes'} warn={rec.bodyBattery < 30} />}
        {checkin?.mood != null && <Row l="Energija" v={MOOD[checkin.mood]!} warn={checkin.mood <= 2} />}
        {checkin?.soreness != null && <Row l="Mišice" v={SORE[checkin.soreness]!} warn={checkin.soreness >= 3} />}
      </div>
      {ready.score < 45 && onEase && <Btn primary block style={{ marginTop: 12 }} onClick={() => { onEase(); onClose() }}>Olajšaj dan</Btn>}
      {!wellnessOn && (hasIntervals || garmin) && (
        <div className="card tight" style={{ marginTop: 12, background: 'var(--raised)', border: 0 }}>
          <b style={{ fontSize: rem(13) }}>Spanec, HRV in mirovni utrip z ure</b>
          {/* (v3.52) z Garmin Connect neposredno: vklop v Nastavitve → Garmin (zdravje je izrecna privolitev) */}
          <p style={{ fontSize: rem(12), marginTop: 3 }}>{garmin ? 'Garmin jih pošlje neposredno (tudi stres in Body Battery). Ko jih vklopiš, je pripravljenost vsako jutro samodejna — brez tapanja.' : 'Garmin jih pošilja v intervals.icu. Ko jih vklopiš, je pripravljenost vsako jutro samodejna — brez tapanja.'}</p>
          <Btn sm style={{ marginTop: 8 }} onClick={() => { onClose(); navigate('nastavitve', { sec: garmin ? 'n-garmin' : 'n-ura' }) }}>Vklopi v Nastavitvah</Btn>
        </div>
      )}
      {wellnessOn && rec && (rec.sleepH != null || rec.hrv != null || rec.rhr != null || rec.stress != null || rec.bodyBattery != null) && <p className="muted" style={{ fontSize: rem(11), marginTop: 12 }}>{rec.stress != null || rec.bodyBattery != null ? 'Spanec, HRV, utrip, stres in Body Battery' : 'Spanec, HRV in mirovni utrip'}: {device ? `${device} · ` : garmin ? 'Garmin · ' : ''}{garmin && (rec.stress != null || rec.bodyBattery != null || !hasIntervals) ? 'prek Garmin Connect' : 'prek intervals.icu'}.</p>}
      <p className="muted" style={{ fontSize: rem(11), marginTop: 12 }}>Pripravljenost je usmeritev, ne diagnoza. Ob bolezni ali bolečini počivaj in se posvetuj z zdravnikom.</p>
    </Sheet>
  )
}
