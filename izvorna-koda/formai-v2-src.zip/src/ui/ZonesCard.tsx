import { useState } from 'react'
import type { Profile } from '@/domain/types'
import { hrZoneRows, powerZoneRows } from '@/domain/training/zwo'
import { noPower } from '@/domain/training/zones'
import { Card, Chip } from '@/ui/primitives'
import { NBSP } from '@/ui/format'

/**
 * Tvoje cone: utrip (po pražnem utripu, kot v načrtu in na uri prek intervals.icu) in moč (Coggan, iz FTP).
 * Brez merilnika moči je privzet utrip. Po vsakem testu ali spremembi v Nastavitvah se posodobi samo.
 */
export function ZonesCard({ p }: { p: Profile }) {
  const hr = hrZoneRows(p), pw = powerZoneRows(p)
  const [tab, setTab] = useState<'utrip' | 'moc'>(noPower(p) || !pw ? 'utrip' : 'moc')
  if (!hr && !pw) return null
  const show = tab === 'moc' && pw ? 'moc' : hr ? 'utrip' : 'moc'
  const rows = show === 'moc' ? pw! : hr!.rows
  const colors = ['var(--t-poc)', 'var(--t-kolo)', 'var(--warn)', 'var(--t-moc)', 'var(--bad)', 'var(--t-tek)', 'var(--t-tek)']
  return (
    <Card>
      <div className="between"><h2 className="h4" style={{ margin: 0 }}>Tvoje cone</h2>
        {hr && pw && <div className="row" role="group" aria-label="Cone po" style={{ gap: 6 }}><Chip sm on={show === 'utrip'} onClick={() => setTab('utrip')}>utrip</Chip><Chip sm on={show === 'moc'} onClick={() => setTab('moc')}>moč</Chip></div>}
      </div>
      <table className="zones">
        <caption className="sr-only">{show === 'moc' ? 'Cone moči v vatih' : 'Cone utripa v udarcih na minuto'}</caption>
        <tbody>{rows.map((r, i) => (
          <tr key={r.key}><th scope="row"><i style={{ background: colors[i] }} aria-hidden="true" />{r.key}</th><td>{r.name}</td><td className="num">{r.range}{NBSP}{show === 'moc' ? 'W' : 'bpm'}</td></tr>
        ))}</tbody>
      </table>
      <p className="muted" style={{ fontSize: 11.5, marginTop: 8 }}>{show === 'moc'
        ? `Iz FTP ${p.ftp}${NBSP}W — po vsakem testu se posodobijo vati v načrtu.`
        : `Iz pražnega utripa ${hr!.lthr}${hr!.estimated ? ' (ocena iz max in mirovnega — vpiši pravega v Nastavitvah, ko ga izmeriš)' : ''}; enako kot na uri prek intervals.icu.`}</p>
    </Card>
  )
}
