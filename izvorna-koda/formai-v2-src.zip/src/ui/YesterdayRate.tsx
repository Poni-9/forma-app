import { useEffect, useState } from 'react'
import { useApp, rateSession, setPlanDone, autoMissed } from '@/state/store'
import { addDays, titleNoDur } from '@/domain/training/load'
import { cleanRpe } from '@/domain/coach/rpe'
import { yesterdayUnmarked, unmarkedRecent } from '@/domain/training/missed'
import type { Activity, PlanDay } from '@/domain/types'
import { Btn, Card } from '@/ui/primitives'
import { RateRow } from '@/ui/RateRow'
import { dayName } from '@/ui/format'
import { IcoCheck, IcoCamera } from '@/ui/icons'
import { openPhotoTraining } from '@/ui/photoOpen'
import { saidNo, markNo } from '@/state/noAsk'

const KEY = 'formai.rpeAsk.'
/** (v3.49) »Ne« na »Si ga naredil?« — za ta dan */
const ASK_KEY = 'formai.ydayAsk.'
interface AppStateLike { today: string; activities: readonly Activity[]; plan: readonly PlanDay[] }

/** Včerajšnja vadba brez ocene (aktivnost ali opravljen dan načrta): kaj vprašati in kam zapisati. null = nič. */
export function yesterdayToRate(s: AppStateLike): { title: string; activityId: string | null; dayId: string | null } | null {
  const y = addDays(s.today, -1)
  const sports = new Set(['kolo', 'tek', 'pohod', 'moc', 'plavanje'])
  // (v3.49) zapis iz načrta ni vadba za oceno — ocena gre na dan načrta (spodaj)
  const acts = s.activities.filter((a: Activity) => a.date === y && sports.has(a.sport) && (a.durationMin || 0) >= 15 && !a.planDayId)
    .sort((a, b) => (b.durationMin || 0) - (a.durationMin || 0))
  for (const a of acts) {
    if (cleanRpe(a.rpe) != null) return null           // glavna vadba je že ocenjena
    const day = s.plan.find(d => d.done?.activityId === a.id) ?? null
    if (day && cleanRpe(day.rpe) != null) return null
    return { title: a.name || day?.title || 'vadba', activityId: a.id, dayId: day?.id ?? null }
  }
  const d = s.plan.find(x => x.date === y && x.done && !x.done.activityId && x.kind !== 'pocitek' && cleanRpe(x.rpe) == null)
  return d ? { title: d.title, activityId: null, dayId: d.id } : null
}

/** (v3.49) »Si ga naredil?« za včerajšnji trening brez kljukice — logika je v domeni (autoMissed jo upošteva). */
export { yesterdayUnmarked }

const read = (key: string) => { try { return localStorage.getItem(key) === '1' } catch { return false } }
/** (v3.50) »Ne« za včeraj po starem ključu (dan), za starejši dan s pripetim datumom */
const askKey = (today: string, date: string) => (date === addDays(today, -1) ? ASK_KEY + today : `${ASK_KEY}${today}:${date}`)
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1)

/**
 * »Kako je šlo včeraj?« — en tap. Občutek pove, česar ura ne (lahka vožnja, ki je bila težka) in vpliva na načrt
 * (dva lahka treninga »težko« → naslednji trdi dan lažje). Skrije se po oceni ali »ne zdaj« (za ta dan).
 * (v3.49) Pred tem: včerajšnji trening brez kljukice — »Da, opravil« ga označi (nato ocena), »Ne« skrije vprašanje
 * in ključni trening prestavi (autoMissed ga do odgovora ne prestavi).
 * (v3.50) Vprašanje tudi za starejše neoznačene dni tega tedna (največ 2 kartici): »Ponedeljek: Tek in hoja — si ga naredil?«.
 */
export function YesterdayRate() {
  const app = useApp()
  const [gone, setGone] = useState(() => read(KEY + app.today))
  const [noAsk, setNoAsk] = useState<Set<string>>(() => new Set())
  // (v3.49) »Ne« in »ne zdaj« veljata za dan ob izrisu — po polnoči z odprtim Danes se vprašanje za novi dan pokaže
  useEffect(() => { setGone(read(KEY + app.today)); setNoAsk(new Set()) }, [app.today])
  // (v3.50) »Ne« velja za ta dan načrta trajno, tudi če je bil odgovor v Prehrani (»Si ga opravil?«) — prej je vprašalo znova
  const open = unmarkedRecent(app).filter(d => !noAsk.has(d.id) && !read(askKey(app.today, d.date)) && !saidNo(d.id))
  if (open.length) {
    const yday = addDays(app.today, -1)
    return (<>
      {open.map(d => {
        const no = () => { try { localStorage.setItem(askKey(app.today, d.date), '1') } catch { /* zasebni način */ } markNo(d.id, d.date); setNoAsk(s => new Set(s).add(d.id)); void autoMissed(d.id) }
        return (
          <Card key={d.id} tight className="yday-rate">
            <h2 className="h4" style={{ fontSize: 11, margin: 0 }}>{d.date === yday ? 'Včeraj' : cap(dayName(d.date))}: {titleNoDur(d.title, d.durationMin)} — si ga naredil?</h2>
            <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
              <Btn ghost sm onClick={() => void setPlanDone(d.id, true)}><IcoCheck width={15} height={15} /> Da, opravil</Btn>
              {/* (v3.50) s posnetkom ure ali naprave: dejanski čas, razdalja in utrip namesto »po načrtu« */}
              <Btn ghost sm onClick={() => openPhotoTraining({ mode: 'done', dayId: d.id })}><IcoCamera width={15} height={15} /> Slikaj</Btn>
              <Btn ghost sm onClick={no}>Ne</Btn>
            </div>
          </Card>
        )
      })}
    </>)
  }
  const ask = yesterdayToRate(app)
  if (!ask || gone) return null
  const later = () => { try { localStorage.setItem(KEY + app.today, '1') } catch { /* zasebni način */ } setGone(true) }
  return (
    <Card tight className="yday-rate">
      <div className="between" style={{ gap: 10, alignItems: 'baseline' }}>
        <h2 className="h4" style={{ fontSize: 11, margin: 0 }}>Včeraj: {ask.title}</h2>
        <button type="button" className="chip sm click" onClick={later}>ne zdaj</button>
      </div>
      <RateRow label="Kako je šlo?" value={null} onPick={v => { if (v != null) void rateSession({ activityId: ask.activityId, dayId: ask.dayId }, v) }} />
    </Card>
  )
}
