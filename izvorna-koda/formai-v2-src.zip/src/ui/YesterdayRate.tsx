import { useState } from 'react'
import { useApp, rateSession } from '@/state/store'
import { addDays } from '@/domain/training/load'
import { cleanRpe } from '@/domain/coach/rpe'
import type { Activity, PlanDay } from '@/domain/types'
import { Card } from '@/ui/primitives'
import { RateRow } from '@/ui/RateRow'

const KEY = 'formai.rpeAsk.'
interface AppStateLike { today: string; activities: readonly Activity[]; plan: readonly PlanDay[] }

/** Včerajšnja vadba brez ocene (aktivnost ali opravljen dan načrta): kaj vprašati in kam zapisati. null = nič. */
export function yesterdayToRate(s: AppStateLike): { title: string; activityId: string | null; dayId: string | null } | null {
  const y = addDays(s.today, -1)
  const sports = new Set(['kolo', 'tek', 'pohod', 'moc', 'plavanje'])
  const acts = s.activities.filter((a: Activity) => a.date === y && sports.has(a.sport) && (a.durationMin || 0) >= 15)
    .sort((a, b) => (b.durationMin || 0) - (a.durationMin || 0))
  for (const a of acts) {
    if (cleanRpe(a.rpe) != null) return null           // glavna vadba je že ocenjena
    const day = s.plan.find(d => d.done?.activityId === a.id) ?? null
    if (day && cleanRpe(day.rpe) != null) return null
    return { title: a.name || day?.title || 'vadba', activityId: a.id, dayId: day?.id ?? null }
  }
  const d = s.plan.find(x => x.date === y && x.done && !x.done.activityId && x.kind !== 'pocitek' && cleanRpe(x.rpe) == null)
  return d ? { title: d.title, activityId: null, dayId: d.id } : null
}

/**
 * »Kako je šlo včeraj?« — en tap. Občutek pove, česar ura ne (lahka vožnja, ki je bila težka) in vpliva na načrt
 * (dva lahka treninga »težko« → naslednji trdi dan lažje). Skrije se po oceni ali »ne zdaj« (za ta dan).
 */
export function YesterdayRate() {
  const app = useApp()
  const [gone, setGone] = useState(() => { try { return localStorage.getItem(KEY + app.today) === '1' } catch { return false } })
  const ask = yesterdayToRate(app)
  if (!ask || gone) return null
  const later = () => { try { localStorage.setItem(KEY + app.today, '1') } catch { /* zasebni način */ } setGone(true) }
  return (
    <Card tight className="yday-rate">
      <div className="between" style={{ gap: 10, alignItems: 'baseline' }}>
        <h2 className="h4" style={{ fontSize: 11, margin: 0 }}>Včeraj: {ask.title}</h2>
        <button type="button" className="chip sm click" onClick={later}>ne zdaj</button>
      </div>
      <RateRow label="Kako je šlo?" value={null} onPick={v => { if (v != null) void rateSession({ activityId: ask.activityId, dayId: ask.dayId }, v) }} />
    </Card>
  )
}
