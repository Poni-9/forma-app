import { useEffect, useRef } from 'react'
import { useApp, dismissToast, type Toast } from '@/state/store'

/**
 * Obvestila za vse poti (tudi uvod, prijava, vadba). Stalni živi območji, da ju bralnik zaslona prebere:
 * (v3.50) napake v role="alert" (takoj), ostalo v role="status"; več obvestil eno nad drugim (prej je novo prepisalo
 * prejšnje); napaka ostane, dokler je ne zapreš (tap, × ali Esc); ikona in barva ločita napako od uspeha.
 */
const TOAST_ICON = { err: '✕', ok: '✓', info: 'i' } as const
export function Toasts() {
  const app = useApp()
  const list = app.toasts ?? (app.toast ? [app.toast] : [])
  // Esc zapre zadnje obvestilo, ko ni odprtega lista (list zapre Esc sam)
  useEffect(() => {
    const on = (e: KeyboardEvent) => { if (e.key === 'Escape' && !e.defaultPrevented && !document.querySelector('.sheet')) dismissToast() }
    document.addEventListener('keydown', on)
    return () => document.removeEventListener('keydown', on)
  }, [])
  // (v3.50) napaka »Ni povezave z internetom …« (npr. AI) izgine, ko je povezava spet tu (napake sicer ne izginejo same)
  const cur = useRef(list)
  cur.current = list
  useEffect(() => {
    const on = () => { for (const t of cur.current) if (t.kind === 'err' && /^Ni povezave z internetom/.test(t.msg)) dismissToast(t.id) }
    window.addEventListener('online', on)
    return () => window.removeEventListener('online', on)
  }, [])
  const item = (t: Toast) => (
    // tap zapre obvestilo (v3.48): prej je 9 s prekrivalo vsebino in ujelo tap
    // (v3.51) order: časovni vrstni red tudi med napakami in drugimi (prej napake vedno zgoraj, tudi starejše nad novejšimi)
    <div key={t.id} className={`toast${t.kind === 'info' ? '' : ` ${t.kind}`}`} data-kind={t.kind} style={{ order: t.id }} onClick={() => dismissToast(t.id)}>
      <span className="toast-ico" aria-hidden="true">{TOAST_ICON[t.kind]}</span>
      <span className="toast-msg">{t.msg}</span>
      {t.action && <button type="button" className="toast-act" onClick={e => { e.stopPropagation(); dismissToast(t.id); t.action!.run() }}>{t.action.label}</button>}
      <button type="button" className="toast-x" aria-label="Zapri obvestilo" onClick={e => { e.stopPropagation(); dismissToast(t.id) }}>×</button>
    </div>
  )
  return (
    <div className="toast-host">
      <div className="toast-stack">
        <div className="toast-live" role="alert">{list.filter(t => t.kind === 'err').map(item)}</div>
        <div className="toast-live" role="status" aria-live="polite">{list.filter(t => t.kind !== 'err').map(item)}</div>
      </div>
    </div>
  )
}
