import { useEffect, useRef, useState, type ReactNode } from 'react'
import { Head } from '@/app/Shell'
import { navigate } from '@/app/router'
import { useApp, addActivities, updateSettings, updateProfile, toast, pushWorkouts, removeWorkouts, setIcuDiag, setWellnessOn, ensureRoutes } from '@/state/store'
import { PhotoInput } from '@/ui/PhotoInput'
// (v3.50) posnetek gre v list »Slikaj opravljen trening«: isto branje, predogled in kljukica na dnevu načrta
import { openPhotoTraining } from '@/ui/photoOpen'
import { parseAny, toActivity, ACTIVITY_FILE_RE, IMPORT_WHY, ImportError, whyOf, importFailText } from '@/domain/import/parsers'
import { parseArchive } from '@/domain/import/archive'
import { estimateTss, addDays } from '@/domain/training/load'
import { fetchAthlete, fetchActivities, icuReady } from '@/domain/intervals/client'
import { importDiagnosis, ICU_SETTINGS_URL, icuConnectPath, icuUploadPath } from '@/domain/intervals/diagnosis'
import { icuWorkout } from '@/domain/intervals/workouts'
import type { Activity } from '@/domain/types'
import { Card, Chip, Btn, Option } from '@/ui/primitives'
import { IcoWatch, IcoPhone, IcoFile, IcoUpload, IcoCheck, IcoWarn } from '@/ui/icons'
import { icuOauthOn, probeIcuOauth, startIcuOAuth } from '@/data/icuOauth'
import { IcuErrorCard, icuErrActive, icuErrOf } from '@/ui/IcuStatus'
import { count, dm, plural, W } from '@/ui/format'
import { isCustom } from '@/domain/focus/model'
// (v3.49) isto pravilo kot izvoz v intervals.icu (domain/intervals/workouts): brez merilnika ali brez FTP cilji v utripu
import { noPower } from '@/domain/training/zones'
import { rem } from '@/ui/rem'
// (v3.52) Garmin Connect neposredno: kartica nad intervals.icu; »Spanec, HRV …« je vklopljen tudi prek Garmina
import { GarminCard } from '@/ui/GarminCard'
import { wellnessActive } from '@/domain/wellness'

type Device = 'garmin' | 'other' | 'phone' | 'files' | null
/** Kar je zadnji ročni uvoz pokazal o izvoru (Strava, neznano) — ostane na zaslonu, dokler ga ne skriješ. */
type OriginWarn = { strava: number; total: number; unknown: string[] }

/** Korak vodenih navodil (odkljuka se sam, ko je opravljen). */
function Step({ ok, t, children }: { ok: boolean; t: string; children?: ReactNode }) {
  return (
    <div className="row" style={{ gap: 10, alignItems: 'flex-start', padding: '8px 0', borderTop: '1px solid var(--line)' }}>
      <span className={`fs-dot ${ok ? 'on' : ''}`} style={{ marginTop: 1 }}>{ok ? <IcoCheck width={12} height={12} /> : null}</span>
      <div style={{ flex: 1, minWidth: 0 }}><b style={{ fontSize: rem(13.5) }}>{t}</b>{children && <div className="muted" style={{ fontSize: rem(12), marginTop: 2 }}>{children}</div>}</div>
    </div>
  )
}

/** (v3.51) Katera ura pošilja v intervals.icu: Garmin, ko je kaj z Garmina ali še nič; druga, ko so vadbe z druge ure. */
export function watchOf(acts: readonly Pick<Activity, 'source' | 'originHint'>[]): 'garmin' | 'other' {
  const icu = acts.filter(a => a.source === 'intervals' && a.originHint && !/STRAVA/i.test(a.originHint))
  return !icu.length || icu.some(a => /GARMIN/i.test(a.originHint || '')) ? 'garmin' : 'other'
}
/** vlečenje datotek (ne besedila ali slike s strani) */
const hasFiles = (e: { dataTransfer: DataTransfer | null }) => !!e.dataTransfer && Array.from(e.dataTransfer.types || []).includes('Files')
/** (v3.51) izvor iz intervals.icu → ime znamke (»WAHOO« → »Wahoo«); neznan izvor brez imena */
const BRANDS: Record<string, string> = { WAHOO: 'Wahoo', COROS: 'COROS', POLAR: 'Polar', SUUNTO: 'Suunto', ZWIFT: 'Zwift', HUAWEI: 'Huawei', AMAZFIT: 'Amazfit' }
const brandOf = (o: string | null | undefined) => { const s = String(o || '').toUpperCase(); return Object.entries(BRANDS).find(([k]) => s.includes(k))?.[1] ?? '' }

/** Zaslon za povezavo: eno vprašanje, nikoli mreža logotipov. Trije bloki za vse: Odslej samodejno / Vsa zgodovina / Samo ta vožnja. */
export function Uvoz() {
  const app = useApp()
  // »Poveži z intervals.icu« se pokaže, ko strežnik potrdi, da je OAuth odobren in nastavljen
  const [, setOauthKnown] = useState(false)
  useEffect(() => { void probeIcuOauth().then(() => setOauthKnown(true)) }, [])
  // (v3.51) s povezavo: Garmin ali druga ura po izvoru vadb (Wahoo, COROS …) — prej vedno »Garmin« in korak nikoli odkljukan
  // (v3.52) z Garmin Connect neposredno je ura Garmin
  const [dev, setDev] = useState<Device>(() => (app.settings.garmin ? 'garmin' : app.settings.intervals ? watchOf(app.activities) : null))
  // (v3.51) Stravin arhiv: koliko vadb trener ne sme uporabiti (ostane na zaslonu, dokler ga ne skriješ)
  const [archStrava, setArchStrava] = useState<number | null>(null)
  // (v3.51) spuščanje datotek na zaslon (namizje); na telefonu samo »izberi«
  const [drag, setDrag] = useState(false)
  const touch = typeof window !== 'undefined' && !!window.matchMedia?.('(hover: none)').matches
  const [busy, setBusy] = useState<string | null>(null)
  const [icuId, setIcuId] = useState(app.settings.intervals?.athleteId || '')
  const [icuKey, setIcuKey] = useState(app.settings.intervals?.apiKey || '')
  const [warn, setWarn] = useState<OriginWarn | null>(null)
  // ponovna povezava z osebnim ključem (žeton ali ključ ne velja več)
  const [rekey, setRekey] = useState(false)
  // (v3.50) napaka povezave pod polji; API ključ lahko pokažeš (prepisuješ ga s tuje strani)
  const [keyErr, setKeyErr] = useState<string | null>(null)
  const [showKey, setShowKey] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)
  const archRef = useRef<HTMLInputElement>(null)
  const icuErr = app.settings.intervals ? icuErrOf(app) : null
  const dropStyle = drag ? { border: '1.5px dashed var(--accent)', background: 'var(--accent-soft)' } : {}
  // načrt po meri brez kolesa: »vadbe«, ne »vožnje« (v3.48)
  const noBike = isCustom(app.profile) && !app.profile.focus?.sports.includes('kolo')
  // (v3.51) spust tudi na glavi, vrstici na namizju, zavihkih in robu strani — prej samo na .scroll, drugje je brskalnik
  // datoteko odprl in zapustil aplikacijo
  const dropRef = useRef<(list: FileList) => void>(() => undefined)
  dropRef.current = list => { setDrag(false); if (!busy) { if (!dev || dev === 'phone') setDev('files'); void onFiles(list) } }
  useEffect(() => {
    const over = (e: DragEvent) => { if (e.defaultPrevented || !hasFiles(e)) return; e.preventDefault(); if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy' }
    const drop = (e: DragEvent) => { if (e.defaultPrevented || !hasFiles(e)) return; e.preventDefault(); dropRef.current(e.dataTransfer!.files) }
    window.addEventListener('dragover', over); window.addEventListener('drop', drop)
    return () => { window.removeEventListener('dragover', over); window.removeEventListener('drop', drop) }
  }, [])

  async function onFiles(list: FileList | null) {
    if (!list?.length) return
    const files = Array.from(list)
    setBusy('Berem datoteke …')
    try {
      const acts: Activity[] = []
      // (v3.50) katera datoteka in zakaj (prej samo »Nobene datoteke nisem mogel prebrati.«)
      const fails: { name: string; why: string }[] = []
      for (const f of files) {
        if (/\.zip$/i.test(f.name)) { await onArchive(f); continue }
        if (!ACTIVITY_FILE_RE.test(f.name)) { fails.push({ name: f.name, why: IMPORT_WHY.unsupported }); continue }
        try { const p = await parseAny(f); acts.push(toActivity(p, 'file', null)) } catch (e) { fails.push({ name: f.name, why: whyOf(e) }) }
      }
      for (const a of acts) a.tss = estimateTss(a, app.profile)
      if (acts.length) {
        const r = await addActivities(acts)
        toast(`Uvoženih: ${r.added} · že imamo: ${r.dupes}${r.upgraded ? ` · dopolnjenih: ${r.upgraded}` : ''}${fails.length ? ` · neuspelih: ${fails.length} — ${importFailText(fails)}` : ''}`, 'ok', fails.length ? 9000 : 6000)
      } else if (fails.length) toast(fails.length > 1 ? `Nobene od ${fails.length} datotek nisem mogel prebrati — ${importFailText(fails)}` : importFailText(fails), 'err', 9000)
    } finally { setBusy(null); if (fileRef.current) fileRef.current.value = '' }
  }

  async function onArchive(f: File) {
    setBusy('Odpiram arhiv …')
    try {
      const { parsed, failed, found, fails, strava } = await parseArchive(f, p => setBusy(`Arhiv: ${p.done}/${p.found} …`))
      if (!found) { toast('V arhivu ni .FIT/.GPX/.TCX datotek. Če je to Stravin arhiv, poišči mapo »activities«.', 'err', 7000); return }
      const acts = parsed.map(p => toActivity(p, 'archive', null))
      for (const a of acts) a.tss = estimateTss(a, app.profile)
      const r = await addActivities(acts)
      toast(`${strava ? 'Stravin arhiv' : 'Arhiv'} — prebranih: ${parsed.length} · novih: ${r.added} · že imamo: ${r.dupes}${failed ? ` · neuspelih: ${failed}${fails.length ? ` — ${importFailText(fails)}` : ''}` : ''}${strava ? ' · trener jih ne sme uporabiti' : ''}`, 'ok', 8000)
      // (v3.51) Stravin arhiv: trener teh vadb ne vidi — pove naravnost (kot pri intervals.icu prek Strave)
      setArchStrava(strava && parsed.length ? parsed.length : null)
    } catch (e) { toast('Uvoz arhiva ni uspel: ' + (e instanceof ImportError ? e.message : (e as Error)?.message || ''), 'err', 9000) }
    finally { setBusy(null); if (archRef.current) archRef.current.value = '' }
  }

  async function connectIntervals() {
    // (v3.50) sporočilo pod poljem in fokus v prazno polje (prej obvestilo za 6 s, fokus na gumbu)
    if (!icuId.trim() || !icuKey.trim()) { setKeyErr('Vpiši Athlete ID in API ključ.'); document.getElementById(icuId.trim() ? 'icu-key' : 'icu-id')?.focus(); return }
    setKeyErr(null)
    setBusy('Preverjam intervals.icu …')
    try {
      const creds = { athleteId: icuId.trim(), apiKey: icuKey.trim() }
      const a = await fetchAthlete(creds)
      // nova povezava: treningi na uro šele, ko jih uporabnik vklopi (brez vprašanja ne pišemo v njegov koledar)
      const prev = app.settings.intervals
      await updateSettings({ intervals: { ...creds, name: a.name, pushWorkouts: prev ? prev.pushWorkouts : false } })
      const patch: Partial<typeof app.profile> = {}
      if (a.ftp && !app.profile.ftp) patch.ftp = a.ftp
      if (a.lthr && !app.profile.lthr) patch.lthr = a.lthr
      if (a.maxHr && !app.profile.maxHr) patch.maxHr = a.maxHr
      if (a.restHr && !app.profile.restHr) patch.restHr = a.restHr
      if (Object.keys(patch).length) await updateProfile(patch)
      setRekey(false)
      await syncIntervals(creds, true)
    } catch (e) { setKeyErr((e as Error)?.message || 'Povezava ni uspela.'); document.getElementById('icu-id')?.focus() }
    finally { setBusy(null) }
  }

  async function syncIntervals(creds = app.settings.intervals, first = false) {
    if (!creds) return
    setBusy('Uvažam iz intervals.icu …')
    try {
      const days = first ? 365 : 120
      const oldest = new Date(Date.now() - days * 86400_000).toISOString().slice(0, 10)
      const newest = new Date(Date.now() + 86400_000).toISOString().slice(0, 10)
      const known = app.activities.filter(a => a.source === 'intervals').length
      const r = await fetchActivities(creds, oldest, newest)
      const diag = { at: new Date().toISOString(), days, total: r.total, usable: r.activities.length, stravaStubs: r.stravaStubs, known, short: r.skippedShort }
      await setIcuDiag(diag)
      const advice = importDiagnosis(diag, { noBike })
      for (const a of r.activities) if (!a.tss) a.tss = estimateTss(a, app.profile)
      // sledi pobere knjižnica tras sama (enkrat na vožnjo, z dnevno kvoto intervals.icu) — tu jih ne vlečemo
      const res = await addActivities(r.activities)
      void ensureRoutes()
      const n = r.activities.length
      // Poštenost: uvoz »uspe«, trener pa morda ne vidi nič — to ostane na zaslonu (obvestilo bi ga prekrilo)
      const withData = r.stravaOrigin - r.stravaStubs
      setWarn(withData > 0 || r.unknownOrigins.length ? { strava: Math.max(0, withData), total: n, unknown: r.unknownOrigins } : null)
      if (!n) { toast(advice ? `${advice.title} — pojasnilo je spodaj.` : 'intervals.icu ni vrnil aktivnosti v tem obdobju.', advice?.tone === 'warn' ? 'err' : 'info', 8000); return }
      // (v3.50) prekratke vadbe se ne uvozijo — povemo, koliko jih je (prej tiho)
      toast(`intervals.icu — novih: ${res.added} · že imamo: ${res.dupes}${res.upgraded ? ` · posodobljenih: ${res.upgraded}` : ''}${r.skippedShort ? ` · prekratkih (pod 5 min): ${r.skippedShort}` : ''}`, 'ok', 6000)
    } catch (e) { toast((e as Error)?.message || 'Uvoz ni uspel.', 'err', 7000) }
    finally { setBusy(null) }
  }

  function reconnect() {
    if (icuOauthOn()) { startIcuOAuth(); return }
    setRekey(true)
  }

  const keyForm = (main: boolean) => (<>
    <ol style={{ margin: '10px 0 0', paddingLeft: 18, fontSize: rem(13), color: 'var(--ink-2)', lineHeight: 1.6 }}>
      {/* povezavi (v3.48): prej krepko besedilo — naslov si moral poiskati sam */}
      <li>Odpri <a className="lnk-hit" href="https://intervals.icu" target="_blank" rel="noreferrer"><b>intervals.icu ↗</b></a> in ustvari račun (brezplačno).</li>
      <li>V intervals.icu: <b>{icuConnectPath(dev === 'garmin')}</b>. <b>Neposredno</b>, ne prek Strave.</li>
      <li>V intervals.icu: <a className="lnk-hit" href={ICU_SETTINGS_URL} target="_blank" rel="noreferrer"><b>Settings → Developer Settings ↗</b></a> → kopiraj <b>Athlete ID</b> (i12345) in <b>API key</b>.</li>
    </ol>
    <div className="stack" style={{ gap: 8, marginTop: 12 }}>
      <div className="field"><label htmlFor="icu-id">Athlete ID</label><input id="icu-id" value={icuId} onChange={e => { setIcuId(e.target.value); setKeyErr(null) }} placeholder="i12345" autoCapitalize="off" autoCorrect="off" spellCheck={false} aria-invalid={(!!keyErr && !icuId.trim()) || undefined} aria-describedby={keyErr ? 'icu-err' : undefined} /></div>
      <div className="field"><label htmlFor="icu-key">API ključ</label>
        <div className="row" style={{ gap: 6 }}>
          <input id="icu-key" style={{ flex: 1, minWidth: 0 }} value={icuKey} onChange={e => { setIcuKey(e.target.value); setKeyErr(null) }} placeholder="…" type={showKey ? 'text' : 'password'} autoCapitalize="off" autoCorrect="off" autoComplete="off" spellCheck={false} aria-invalid={(!!keyErr && !icuKey.trim()) || undefined} aria-describedby={keyErr ? 'icu-err' : undefined} />
          <button type="button" className="chip sm click" aria-pressed={showKey} onClick={() => setShowKey(!showKey)}>{showKey ? 'skrij' : 'pokaži'}</button>
        </div>
      </div>
      {keyErr && <div id="icu-err" role="alert" style={{ fontSize: rem(12), color: 'var(--warn)', lineHeight: 1.45 }}>{keyErr}</div>}
    </div>
    <Btn primary={main} block sm style={{ marginTop: 12 }} disabled={!!busy} onClick={connectIntervals}>Poveži in uvozi</Btn>
  </>)

  return (<>
    <Head hi={noBike ? 'Vadbe' : 'Vožnje'} nm="Uvoz" />
    {/* (v3.51) datoteke ali arhiv spustiš kjer koli na zaslonu (prej jih je brskalnik odprl in zapustil aplikacijo) */}
    <div className="scroll"
      onDragOver={e => { if (hasFiles(e)) { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; if (!drag) setDrag(true) } }}
      onDragLeave={e => { if (!e.currentTarget.contains(e.relatedTarget as Node | null)) setDrag(false) }}
      onDrop={e => { if (!hasFiles(e)) return; e.preventDefault(); dropRef.current(e.dataTransfer.files) }}>
      {!dev ? (<>
        <h2 style={{ marginTop: 6 }}>{noBike ? 'S čim beležiš vadbe?' : 'S čim beležiš vožnje?'}</h2>
        <p style={{ marginTop: 7, fontSize: rem(14) }}>Izberi eno — pokažem ti samo to pot.</p>
        <div className="stack stagger" style={{ marginTop: 18, gap: 10 }}>
          <Option icon={<IcoWatch />} title="Garmin ura ali števec" sub="Odslej samodejno — enkrat nastaviš" onClick={() => setDev('garmin')} />
          <Option icon={<IcoWatch />} title="Wahoo, Polar, COROS, Suunto, Zwift" sub="Enako — prek intervals.icu" onClick={() => setDev('other')} />
          <Option icon={<IcoPhone />} title="Samo telefon" sub="»Opravil« na Danes ali ročni vnos — 5 sekund" onClick={() => setDev('phone')} />
          <Option icon={<IcoFile />} title="Imam datoteke ali arhiv" sub=".fit, .gpx, .tcx, .zip — tudi Strava arhiv" onClick={() => setDev('files')} />
        </div>
      </>) : (<>
        <div className="row" style={{ gap: 8, paddingBottom: 12, flexWrap: 'wrap' }}>
          {/* (v3.51) že izbrana druga ura (Wahoo …) ostane — prej je tap preklopil na Garminova navodila */}
          <Chip on={dev === 'garmin' || dev === 'other'} onClick={() => setDev(d => (d === 'other' ? d : 'garmin'))}>Ura / števec</Chip>
          <Chip on={dev === 'phone'} onClick={() => setDev('phone')}>Telefon</Chip>
          <Chip on={dev === 'files'} onClick={() => setDev('files')}>Datoteke</Chip>
        </div>

        {/* (v3.52) Garmin Connect neposredno — nad intervals.icu; kartica se pokaže, ko strežnik ima Garmin ali je povezava že tu */}
        {dev === 'garmin' && <GarminCard style={{ marginBottom: 12 }} />}
        {(dev === 'garmin' || dev === 'other') && (
          <Card accent={!app.settings.garmin} className="page" style={{ marginBottom: 12 }}>
            <h2 className="h4" style={{ color: 'var(--accent-fg)' }}>{app.settings.garmin && dev === 'garmin' ? 'Tudi prek intervals.icu' : '1 · Odslej samodejno'}</h2>
            {icuErrActive(icuErr) && (<>
              <IcuErrorCard err={icuErr} onUvoz={false} style={{ marginTop: 10, background: 'var(--card)' }} />
              {icuErr.kind === 'auth' && !rekey && <Btn primary block sm style={{ marginTop: 10 }} onClick={reconnect}>Poveži znova</Btn>}
            </>)}
            {app.settings.intervals && icuReady(app.settings.intervals) && !rekey ? (() => {
              // vodeni koraki s samodejnim zaznavanjem: kaj že dela, kaj še manjka
              const icu = app.activities.filter(a => a.source === 'intervals')
              const fromWatch = icu.some(a => a.originHint && !/STRAVA/i.test(a.originHint))
              const garmin = icu.some(a => /GARMIN/i.test(a.originHint || ''))
              const watchOk = dev === 'garmin' ? garmin : fromWatch
              const lastIcu = [...icu].sort((a, b) => b.date.localeCompare(a.date))[0]
              const rides = noBike ? 'vadbe' : 'vožnje'
              const brand = dev === 'other' ? brandOf(icu.filter(a => a.originHint && !/STRAVA/i.test(a.originHint)).sort((a, b) => b.date.localeCompare(a.date))[0]?.originHint) : ''
              return (
                <div style={{ marginTop: 8 }}>
                  {/* pri odjavi (preklican dostop) korak ni odkljukan — kartica zgoraj pove, kaj narediti */}
                  <Step ok={!(icuErrActive(icuErr) && icuErr.kind === 'auth')} t={`intervals.icu ${icuErrActive(icuErr) && icuErr.kind === 'auth' ? 'ni več povezan' : 'povezan'}${app.settings.intervals!.name ? ` · ${app.settings.intervals!.name}` : ''}`}>{app.settings.intervals!.token ? 'Z enim dotikom (OAuth).' : 'Z osebnim API ključem.'} <button className="chip sm click" disabled={!!busy} onClick={() => syncIntervals()}>Uvozi nove</button></Step>
                  <Step ok={watchOk} t={`${dev === 'garmin' ? 'Garmin' : 'Ura'} pošilja ${rides}${brand ? ` · ${brand}` : ''}`}>
                    {watchOk ? `Zadnja: ${lastIcu ? dm(lastIcu.date) : '—'}` : <>V intervals.icu: <b>{icuConnectPath(dev === 'garmin')}</b> — neposredno, ne prek Strave. Ko prva {noBike ? 'vadba' : 'vožnja'} pride, se tu odkljuka samo.</>}
                  </Step>
                  {/* (v3.50) »Vadbe gredo na uro« je del bloka »Treningi na uro« spodaj (prej ista nastavitev dvakrat z dvema imenoma) */}
                  <Step ok={wellnessActive(app.settings)} t="Spanec, HRV in mirovni utrip">
                    {wellnessActive(app.settings) ? `Vklopljeno${app.settings.wellnessOn ? '' : ' (prek Garmin Connect)'} — jutranja pripravljenost je samodejna.` : <>Neobvezno: samodejna jutranja pripravljenost. Ostane na tej napravi. <button className="chip sm click" onClick={() => void setWellnessOn(true)}>vklopi</button></>}
                  </Step>
                </div>)
            })() : (<>
              <p style={{ fontSize: rem(13), marginTop: 6 }}>{noBike ? 'Vsaka vadba, ki pride v intervals.icu iz ure, se pojavi tukaj — s sledjo za karto. Enkrat nastaviš, potem samo treniraš.' : 'Vsaka vožnja, ki pride v intervals.icu iz ure, se pojavi tukaj — s sledjo za karto. Enkrat nastaviš, potem samo voziš.'}</p>
              {icuOauthOn() && (<>
                <Btn primary block style={{ marginTop: 12 }} onClick={startIcuOAuth}>Poveži z intervals.icu</Btn>
                <div className="muted" style={{ fontSize: rem(12), marginTop: 6 }}>Če računa še nimaš, ga tam ustvariš brezplačno. Potem v intervals.icu poveži še {dev === 'garmin' ? 'Garmin' : 'svojo uro'} ({icuConnectPath(dev === 'garmin')}).</div>
              </>)}
              {icuOauthOn() ? (
                <details style={{ marginTop: 12 }} open={rekey || undefined}><summary className="muted" style={{ fontSize: rem(12.5), cursor: 'pointer', fontWeight: 700 }}>Raje z osebnim API ključem</summary>{keyForm(false)}</details>
              ) : keyForm(true)}
              {rekey && <button className="chip sm click" style={{ marginTop: 10 }} onClick={() => setRekey(false)}>prekliči</button>}
            </>)}
            {warn && (
              <div role="status" style={{ marginTop: 10, padding: '10px 12px', borderRadius: 12, border: `1px solid ${warn.strava ? 'var(--warn)' : 'var(--line)'}`, background: 'var(--raised)' }}>
                <div className="row" style={{ gap: 10, alignItems: 'flex-start' }}>
                  <IcoWarn width={16} height={16} aria-hidden="true" style={{ color: warn.strava ? 'var(--warn)' : 'var(--ink-3)', flex: 'none', marginTop: 2 }} />
                  <div style={{ flex: 1, minWidth: 0, fontSize: rem(12.5), lineHeight: 1.5, color: 'var(--ink-2)' }}>
                    {warn.strava > 0 && (warn.strava >= warn.total
                      ? <><b style={{ color: 'var(--warn)' }}>{warn.total === 1 ? 'Aktivnost' : warn.total === 2 ? 'Obe aktivnosti' : `${plural(warn.total, ['Vso', 'Vsi', 'Vse', 'Vseh'])} ${count(warn.total, W.aktivnost)}`} je v intervals.icu sinhronizirala Strava</b> — trener {plural(warn.total, ['je', 'ju', 'jih', 'jih'])} ne sme uporabiti. Poveži Garmin NEPOSREDNO z intervals.icu ({icuConnectPath()}), ne prek Strave.</>
                      : <><b style={{ color: 'var(--warn)' }}>{warn.strava} od {warn.total} {plural(warn.strava, ['je', 'sta', 'so', 'jih je'])} Stravinega izvora</b> — {plural(warn.strava, ['te', 'teh', 'teh', 'teh'])} trener ne sme uporabiti. Ostale vidi.</>)}
                    {warn.unknown.length > 0 && <div style={{ marginTop: warn.strava ? 6 : 0 }}>Izvor, ki ga ne poznam ({warn.unknown.join(', ')}) — za vsak primer ne gre v AI.</div>}
                  </div>
                  <button className="chip sm click" onClick={() => setWarn(null)} aria-label="Skrij opozorilo">skrij</button>
                </div>
              </div>
            )}
            {app.settings.intervals && (() => {
              const adv = importDiagnosis(app.icuDiag, { noBike })
              if (!adv) return null
              return (
                <div className="icu-diag" style={{ marginTop: 10, padding: '10px 12px', borderRadius: 12, border: `1px solid ${adv.tone === 'warn' ? 'var(--warn)' : 'var(--line)'}`, background: 'var(--raised)' }}>
                  <b style={{ fontSize: rem(13), color: adv.tone === 'warn' ? 'var(--warn)' : 'var(--ink)' }}>{adv.title}</b>
                  <div style={{ fontSize: rem(12.5), marginTop: 4, color: 'var(--ink-2)', lineHeight: 1.5 }}>{adv.text}</div>
                  <a className="chip sm click" style={{ marginTop: 8, display: 'inline-flex' }} href={ICU_SETTINGS_URL} target="_blank" rel="noreferrer">Odpri nastavitve intervals.icu ↗</a>
                </div>)
            })()}
            {app.settings.intervals && (() => {
              const icu = app.settings.intervals
              const on = icu.pushWorkouts !== false
              const w = app.icuWorkouts
              const when = w ? new Date(w.at).toLocaleString('sl-SI', { day: 'numeric', month: 'numeric', hour: '2-digit', minute: '2-digit' }) : null
              // (v3.50) na uro gredo samo kolesarski treningi: načrt s treningi, a brez kolesa v 14 dneh → ena vrstica namesto stikala
              const ahead = app.plan.filter(d => d.date >= app.today && d.date <= addDays(app.today, 13))
              const watchable = ahead.some(d => !!icuWorkout(d, app.profile))
              if (!watchable && ahead.some(d => d.kind !== 'pocitek') && !(on && w?.n)) return (
                <div className="muted" style={{ fontSize: rem(12), marginTop: 12, paddingTop: 10, borderTop: '1px solid var(--line)' }}><b style={{ color: 'var(--ink)' }}>Treningi na uro</b> · Na uro gredo samo kolesarski treningi (strukturirani, v utripu ali vatih). Tek in moč vodiš v aplikaciji.</div>)
              return (
                <div style={{ marginTop: 12, paddingTop: 10, borderTop: '1px solid var(--line)' }}>
                  <div className="between"><b style={{ fontSize: rem(13) }}>Treningi na uro</b><Chip sm on={on} onClick={() => updateSettings({ intervals: { ...icu, pushWorkouts: !on } }).then(async () => {
                    if (!on) { void pushWorkouts(true); return }
                    const n = await removeWorkouts()
                    if (n != null) toast(n ? `Iz koledarja pobrisano: ${count(n, W.trening)} — Garmin jih umakne z ure ob naslednji sinhronizaciji.` : 'V koledarju ni bilo naših treningov.', 'ok', 7000)
                  })}>{on ? 'vklopljeno' : 'izklopljeno'}</Chip></div>
                  <div className="muted" style={{ fontSize: rem(12), marginTop: 4 }}>Naslednjih 14 dni načrta gre v koledar intervals.icu kot strukturirani kolesarski treningi ({noPower(app.profile) || !app.profile.ftp ? 'cilji v utripu' : 'cilji v vatih'}), od tam jih Garmin sam prenese na uro. Ob vsaki spremembi načrta se pošlje samo; izklop jih pobriše iz koledarja.</div>
                  {/* (v3.50) korak »Naloži načrtovane vadbe« je tu (prej ločen korak »Vadbe gredo na uro« zgoraj) */}
                  <div className="row" style={{ gap: 8, alignItems: 'flex-start', marginTop: 8 }}>
                    <span className={`fs-dot ${icu.planUploadOk ? 'on' : ''}`} style={{ marginTop: 1 }}>{icu.planUploadOk ? <IcoCheck width={12} height={12} /> : null}</span>
                    <div className="muted" style={{ flex: 1, minWidth: 0, fontSize: rem(12) }}>{icu.planUploadOk ? 'Nalaganje na uro je urejeno — načrtovani treningi iz koledarja gredo na uro sami.' : <>V intervals.icu obkljukaj <b>{icuUploadPath(dev === 'garmin')}</b>. Brez tega ostanejo samo v koledarju. <button className="chip sm click" onClick={() => void updateSettings({ intervals: { ...icu, planUploadOk: true } })}>urejeno</button></>}</div>
                  </div>
                  {on && <div className="muted" style={{ fontSize: rem(12), marginTop: 6 }}>{w ? (w.err ? <span style={{ color: 'var(--bad)' }}>Napaka: {w.err}</span> : `Zadnjič ${when} · v koledarju: ${count(w.n, W.trening)}`) : 'Še ni poslano.'} <button className="chip sm click" onClick={() => pushWorkouts(true)}>pošlji zdaj</button></div>}
                </div>)
            })()}
            <div className="muted" style={{ fontSize: rem(11.5), marginTop: 10 }}>Če intervals.icu polniš prek Strave, trener teh {noBike ? 'vadb' : 'voženj'} ne sme uporabiti — to ti povem naravnost ob uvozu.</div>
          </Card>
        )}

        {/* (v3.49) samo telefon: najprej »Opravil« in ročni vnos (brez AI in prijave), posnetek drugi; arhiv in datoteke pod »Datoteke«
            (prej najprej »Slikaj povzetek vožnje na uri«, kar rabi AI in prijavo, ročni vnos drugotni, pod njim še arhiv) */}
        {dev === 'phone' && (<>
          <Card accent className="page" style={{ marginBottom: 12 }}>
            <h2 className="h4" style={{ color: 'var(--accent-fg)' }}>1 · Brez ure</h2>
            <p style={{ fontSize: rem(13), marginTop: 6 }}>Po treningu tapni <b>Opravil</b> na Danes — šteje v teden, formo in kalorije. Če si naredil drugače, {noBike ? 'vadbo' : 'vožnjo'} vpiši ročno (čas in razdalja).</p>
            <Btn primary block sm style={{ marginTop: 12 }} onClick={() => navigate('aktivnosti', { nova: '1' })}>Vpiši ročno</Btn>
          </Card>
          <Card style={{ marginBottom: 12 }}>
            <h2 className="h4">2 · Posnetek zaslona</h2>
            <p style={{ fontSize: rem(13), marginTop: 6 }}>Slikaj povzetek {noBike ? 'vadbe' : 'vožnje'} v aplikaciji, na uri, trenažerju ali fitnes napravi — trener prebere čas, razdaljo in utrip ter odkljuka trening v načrtu. Preveriš in shraniš.{app.user ? '' : ' Branje slike teče prek AI, zato rabi prijavo.'}</p>
            <div style={{ marginTop: 10 }}><PhotoInput onPick={file => openPhotoTraining({ mode: 'done', file })} busy={!!busy} label="Slikaj ali izberi posnetek" hint="Kar piše na sliki, preberem; kar ne, pustim prazno. Posnetkov iz Strave ne nalagaj — trener jih ne sme uporabiti." /></div>
          </Card>
          <button type="button" className="chip sm click" style={{ marginBottom: 14 }} onClick={() => setDev('files')}>Imaš datoteke ali arhiv? ›</button>
        </>)}

        {dev !== 'phone' && (<>
        <Card style={{ marginBottom: 12, ...dropStyle }}>
          <h2 className="h4">{dev === 'files' ? '1' : '2'} · Vsa zgodovina</h2>
          <p style={{ fontSize: rem(13), marginTop: 6 }}>Naloži arhiv: <b>Garmin</b> (Account → Export Your Data), <b>Strava</b> (Settings → My Account → Download or Delete → Request your archive) ali Connect izvoz. Pride po e-pošti v 24–48 h.</p>
          {/* (v3.51) Stravin arhiv: trener ga ne vidi — povemo vnaprej in po uvozu (ostane, dokler ne skriješ) */}
          <p className="muted" style={{ fontSize: rem(12), marginTop: 6 }}>Vadbe iz Stravinega arhiva ostanejo na tej napravi — trener jih ne sme uporabiti (Stravina pravila). Garminov arhiv tega nima.</p>
          {archStrava != null && (
            <div role="status" className="row" style={{ gap: 10, alignItems: 'flex-start', marginTop: 10, padding: '10px 12px', borderRadius: 12, border: '1px solid var(--warn)', background: 'var(--raised)' }}>
              <IcoWarn width={16} height={16} aria-hidden="true" style={{ color: 'var(--warn)', flex: 'none', marginTop: 2 }} />
              <div style={{ flex: 1, minWidth: 0, fontSize: rem(12.5), lineHeight: 1.5, color: 'var(--ink-2)' }}><b style={{ color: 'var(--warn)' }}>Stravin arhiv: {count(archStrava, W.vadba)}</b> {plural(archStrava, ['je', 'sta', 'so', 'je'])} zdaj na tej napravi, trener {plural(archStrava, ['je', 'ju', 'jih', 'jih'])} ne sme uporabiti (Stravina pravila). Garminov arhiv tega nima.</div>
              <button className="chip sm click" onClick={() => setArchStrava(null)} aria-label="Skrij opozorilo">skrij</button>
            </div>
          )}
          <input ref={archRef} type="file" accept=".zip" style={{ display: 'none' }} onChange={e => e.target.files?.[0] && onArchive(e.target.files[0])} />
          {/* (v3.51) »Izberi« (prej »Odloži« = prestavi na pozneje) */}
          <Btn ghost block sm style={{ marginTop: 12 }} disabled={!!busy} onClick={() => archRef.current?.click()}><IcoUpload width={16} height={16} /> Izberi .zip arhiv</Btn>
          <div className="muted" style={{ fontSize: rem(11.5), marginTop: 8 }}>Veliki arhivi (nad 200 MB) gredo bolje na računalniku{touch ? '' : ' — arhiv lahko tudi povlečeš sem'}. Dvojnike prepoznam sam.</div>
        </Card>

        <Card style={{ marginBottom: 12, ...dropStyle }}>
          <h2 className="h4">{dev === 'files' ? '2' : '3'} · {noBike ? 'Samo ta vadba' : 'Samo ta vožnja'}</h2>
          <p style={{ fontSize: rem(13), marginTop: 6 }}>Posamezne datoteke .fit, .gpx, .tcx (tudi .gz) — {touch ? 'izberi jih spodaj' : 'povleci jih sem ali jih izberi'}.</p>
          <input ref={fileRef} type="file" multiple accept=".fit,.gpx,.tcx,.gz,.zip" style={{ display: 'none' }} onChange={e => onFiles(e.target.files)} />
          <div className="row" style={{ gap: 8, marginTop: 12, flexWrap: 'wrap' }}>
            <Btn ghost sm disabled={!!busy} onClick={() => fileRef.current?.click()}><IcoFile width={16} height={16} /> Izberi datoteke</Btn>
            <Btn ghost sm onClick={() => navigate('aktivnosti', { nova: '1' })}>Ročni vnos</Btn>
            {/* seznam vseh vadb (podrobnosti, opomba, izbris) — prej samo prek ročnega vnosa (v3.48) */}
            <Btn ghost sm onClick={() => navigate('aktivnosti')}>Seznam vadb</Btn>
          </div>
        </Card>
        </>)}

        <div className="muted" style={{ fontSize: rem(12), textAlign: 'center', padding: '6px 0 14px' }}>Tvoje sledi ostanejo na tej napravi. V oblak gredo samo številke, nikoli pot.</div>
      </>)}
      {busy && <div className="toast" role="status">{busy}</div>}
    </div>
  </>)
}
