import { useEffect, useRef, useState } from 'react'
import { Head } from '@/app/Shell'
import { navigate } from '@/app/router'
import { useApp, addActivities, updateSettings, updateProfile, toast, pushWorkouts, removeWorkouts, setIcuDiag, setWellnessOn } from '@/state/store'
import { useAi } from '@/ui/useAi'
import { PhotoInput } from '@/ui/PhotoInput'
import { activityFromShot } from '@/domain/ai/actions'
import { parseAny, toActivity, ACTIVITY_FILE_RE } from '@/domain/import/parsers'
import { parseArchive } from '@/domain/import/archive'
import { estimateTss, todayIso } from '@/domain/training/load'
import { fetchAthlete, fetchActivities, fetchTrack, icuReady } from '@/domain/intervals/client'
import { importDiagnosis, ICU_SETTINGS_URL } from '@/domain/intervals/diagnosis'
import type { Activity, Sport } from '@/domain/types'
import { Card, Chip, Btn, Option, Sheet } from '@/ui/primitives'
import { IcoWatch, IcoPhone, IcoFile, IcoUpload, IcoCheck } from '@/ui/icons'
import { icuOauthOn, probeIcuOauth, startIcuOAuth } from '@/data/icuOauth'
import { DateField } from '@/ui/DateField'

type Device = 'garmin' | 'other' | 'phone' | 'files' | null
const SPORTS: { k: Sport; l: string }[] = [{ k: 'kolo', l: 'Kolo' }, { k: 'tek', l: 'Tek' }, { k: 'pohod', l: 'Hoja' }, { k: 'moc', l: 'Moč' }, { k: 'plavanje', l: 'Plavanje' }, { k: 'drugo', l: 'Drugo' }]

/** Zaslon za povezavo: eno vprašanje, nikoli mreža logotipov. Trije bloki za vse: Odslej samodejno / Vsa zgodovina / Samo ta vožnja. */
export function Uvoz() {
  const app = useApp()
  // »Poveži z intervals.icu« se pokaže, ko strežnik potrdi, da je OAuth odobren in nastavljen
  const [, setOauthKnown] = useState(false)
  useEffect(() => { void probeIcuOauth().then(() => setOauthKnown(true)) }, [])
  const ai = useAi()
  const [dev, setDev] = useState<Device>(app.settings.intervals ? 'garmin' : null)
  const [busy, setBusy] = useState<string | null>(null)
  const [icuId, setIcuId] = useState(app.settings.intervals?.athleteId || '')
  const [icuKey, setIcuKey] = useState(app.settings.intervals?.apiKey || '')
  const [shot, setShot] = useState<Activity | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)
  const archRef = useRef<HTMLInputElement>(null)

  async function onFiles(list: FileList | null) {
    if (!list?.length) return
    const files = Array.from(list)
    setBusy('Berem datoteke …')
    try {
      const acts: Activity[] = []
      let failed = 0
      for (const f of files) {
        if (/\.zip$/i.test(f.name)) { await onArchive(f); continue }
        if (!ACTIVITY_FILE_RE.test(f.name)) { failed++; continue }
        try { const p = await parseAny(f); acts.push(toActivity(p, 'file', null)) } catch { failed++ }
      }
      for (const a of acts) a.tss = estimateTss(a, app.profile)
      if (acts.length) {
        const r = await addActivities(acts)
        toast(`Uvoženih ${r.added} · ${r.dupes} že imamo${r.upgraded ? ` · ${r.upgraded} dopolnjenih` : ''}${failed ? ` · ${failed} neuspelih` : ''} ✓`, 'ok', 6000)
      } else if (failed) toast('Nobene datoteke nisem mogel prebrati.', 'err')
    } finally { setBusy(null); if (fileRef.current) fileRef.current.value = '' }
  }

  async function onArchive(f: File) {
    setBusy('Odpiram arhiv …')
    try {
      const { parsed, failed, found } = await parseArchive(f, p => setBusy(`Arhiv: ${p.done}/${p.found} …`))
      if (!found) { toast('V arhivu ni .FIT/.GPX/.TCX datotek. Če je to Stravin arhiv, poišči mapo »activities«.', 'err', 7000); return }
      const acts = parsed.map(p => toActivity(p, 'archive', null))
      for (const a of acts) a.tss = estimateTss(a, app.profile)
      const r = await addActivities(acts)
      toast(`Arhiv: ${parsed.length} prebranih · ${r.added} novih · ${r.dupes} že imamo${failed ? ` · ${failed} neuspelih` : ''} ✓`, 'ok', 8000)
    } catch (e) { toast('Uvoz arhiva ni uspel: ' + ((e as Error)?.message || ''), 'err') }
    finally { setBusy(null); if (archRef.current) archRef.current.value = '' }
  }

  async function connectIntervals() {
    if (!icuId.trim() || !icuKey.trim()) { toast('Vpiši Athlete ID in API ključ.', 'err'); return }
    setBusy('Preverjam intervals.icu …')
    try {
      const creds = { athleteId: icuId.trim(), apiKey: icuKey.trim() }
      const a = await fetchAthlete(creds)
      // nova povezava: treningi na uro šele, ko jih uporabnik vklopi (brez vprašanja ne pišemo v njegov koledar)
      const prev = app.settings.intervals
      await updateSettings({ intervals: { ...creds, name: a.name, pushWorkouts: prev ? prev.pushWorkouts : false } })
      const patch: Partial<typeof app.profile> = {}
      if (a.ftp && !app.profile.ftp) patch.ftp = a.ftp
      if (a.lthr && !app.profile.lthr) patch.lthr = a.lthr
      if (a.maxHr && !app.profile.maxHr) patch.maxHr = a.maxHr
      if (a.restHr && !app.profile.restHr) patch.restHr = a.restHr
      if (Object.keys(patch).length) await updateProfile(patch)
      await syncIntervals(creds, true)
    } catch (e) { toast((e as Error)?.message || 'Povezava ni uspela.', 'err', 7000) }
    finally { setBusy(null) }
  }

  async function syncIntervals(creds = app.settings.intervals, first = false) {
    if (!creds) return
    setBusy('Uvažam iz intervals.icu …')
    try {
      const days = first ? 365 : 120
      const oldest = new Date(Date.now() - days * 86400_000).toISOString().slice(0, 10)
      const newest = new Date(Date.now() + 86400_000).toISOString().slice(0, 10)
      const known = app.activities.filter(a => a.source === 'intervals').length
      const r = await fetchActivities(creds, oldest, newest)
      const diag = { at: new Date().toISOString(), days, total: r.total, usable: r.activities.length, stravaStubs: r.stravaStubs, known }
      await setIcuDiag(diag)
      const advice = importDiagnosis(diag)
      for (const a of r.activities) if (!a.tss) a.tss = estimateTss(a, app.profile)
      // sledi: samo za aktivnosti, ki smejo na karto, in največ 40 naenkrat (kvota API-ja)
      const withGeo = r.activities.filter(a => a.geoRetain && !a.polyline).slice(0, 40)
      let got = 0
      for (const a of withGeo) { if (!a.ext?.intervalsId) continue; setBusy(`Sledi ${++got}/${withGeo.length} …`); a.polyline = await fetchTrack(creds, a.ext.intervalsId).catch(() => null) }
      const res = await addActivities(r.activities)
      const n = r.activities.length
      if (!n) { toast(advice ? `${advice.title} — pojasnilo je spodaj.` : 'intervals.icu ni vrnil aktivnosti v tem obdobju.', advice?.tone === 'warn' ? 'err' : 'info', 8000); return }
      toast(`intervals.icu: ${res.added} novih · ${res.dupes} že imamo${res.upgraded ? ` · ${res.upgraded} posodobljenih` : ''} ✓`, 'ok', 6000)
      // Poštenost: uvoz »uspe«, trener pa morda ne vidi nič. (Stravine »stube« pojasni okence spodaj.)
      const withData = r.stravaOrigin - r.stravaStubs
      if (withData === n) setTimeout(() => toast(`⚠️ Vseh ${n} aktivnosti je v intervals.icu sinhronizirala Strava, zato jih trener ne sme uporabiti. Poveži Garmin NEPOSREDNO z intervals.icu (Settings → Garmin), ne prek Strave.`, 'err', 12000), 1200)
      else if (withData > 0) setTimeout(() => toast(`⚠️ ${withData} od ${n} je Stravinega izvora — teh trener ne sme uporabiti. Ostale vidi.`, 'err', 9000), 1200)
      if (r.unknownOrigins.length) setTimeout(() => toast(`ℹ️ Izvor, ki ga ne poznam (${r.unknownOrigins.join(', ')}) — za vsak primer ne gre v AI.`, 'info', 9000), 2600)
    } catch (e) { toast((e as Error)?.message || 'Uvoz ni uspel.', 'err', 7000) }
    finally { setBusy(null) }
  }

  async function fromShot(file: File) {
    setBusy('Berem posnetek …')
    const a = await ai.run(() => activityFromShot(app.profile, file))
    setBusy(null)
    if (a) setShot(a)
  }
  async function saveShot() {
    if (!shot) return
    const r = await addActivities([{ ...shot, tss: estimateTss(shot, app.profile) }])
    setShot(null)
    toast(r.added ? 'Aktivnost shranjena — trener jo vidi ✓' : 'To aktivnost že imaš.', r.added ? 'ok' : 'info')
  }

  const keyForm = (<>
    <ol style={{ margin: '10px 0 0', paddingLeft: 18, fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.6 }}>
      <li>Odpri <b>intervals.icu</b> in ustvari račun (brezplačno).</li>
      <li>V intervals.icu: <b>Settings → {dev === 'garmin' ? 'Garmin' : 'tvoja znamka'} → Connect</b>. <b>Neposredno</b>, ne prek Strave.</li>
      <li>V intervals.icu: <b>Settings → Developer Settings</b> → kopiraj <b>Athlete ID</b> (i12345) in <b>API key</b>.</li>
    </ol>
    <div className="stack" style={{ gap: 8, marginTop: 12 }}>
      <div className="field"><label>Athlete ID</label><input value={icuId} onChange={e => setIcuId(e.target.value)} placeholder="i12345" autoCapitalize="off" autoCorrect="off" /></div>
      <div className="field"><label>API ključ</label><input value={icuKey} onChange={e => setIcuKey(e.target.value)} placeholder="…" type="password" autoCapitalize="off" /></div>
    </div>
    <Btn primary block sm style={{ marginTop: 12 }} disabled={!!busy} onClick={connectIntervals}>Poveži in uvozi</Btn>
  </>)

  return (<>
    <Head hi="Vožnje" nm="Uvoz" />
    <div className="scroll">
      {!dev ? (<>
        <h2 style={{ marginTop: 6 }}>S čim beležiš vožnje?</h2>
        <p style={{ marginTop: 7, fontSize: 14 }}>Povem ti eno pot, ne štirih.</p>
        <div className="stack stagger" style={{ marginTop: 18, gap: 10 }}>
          <Option icon={<IcoWatch />} title="Garmin ura ali števec" sub="Odslej samodejno — enkrat nastaviš" onClick={() => setDev('garmin')} />
          <Option icon={<IcoWatch />} title="Wahoo, Polar, COROS, Suunto, Zwift" sub="Enako — prek intervals.icu" onClick={() => setDev('other')} />
          <Option icon={<IcoPhone />} title="Samo telefon" sub="Posnetek zaslona ali ročni vnos — 5 sekund" onClick={() => setDev('phone')} />
          <Option icon={<IcoFile />} title="Imam datoteke ali arhiv" sub=".fit, .gpx, .tcx, .zip — tudi Strava arhiv" onClick={() => setDev('files')} />
        </div>
      </>) : (<>
        <div className="row" style={{ gap: 8, paddingBottom: 12 }}>
          <Chip on={dev === 'garmin' || dev === 'other'} onClick={() => setDev('garmin')}>Ura / števec</Chip>
          <Chip on={dev === 'phone'} onClick={() => setDev('phone')}>Telefon</Chip>
          <Chip on={dev === 'files'} onClick={() => setDev('files')}>Datoteke</Chip>
        </div>

        {(dev === 'garmin' || dev === 'other') && (
          <Card accent className="page" style={{ marginBottom: 12 }}>
            <h4 style={{ color: 'var(--accent)' }}>1 · Odslej samodejno</h4>
            {app.settings.intervals && icuReady(app.settings.intervals) ? (() => {
              // vodeni koraki s samodejnim zaznavanjem: kaj že dela, kaj še manjka
              const icu = app.activities.filter(a => a.source === 'intervals')
              const fromWatch = icu.some(a => a.originHint && !/STRAVA/i.test(a.originHint))
              const garmin = icu.some(a => /GARMIN/i.test(a.originHint || ''))
              const watchOk = dev === 'garmin' ? garmin : fromWatch
              const Step = ({ ok, t, children }: { ok: boolean; t: string; children?: React.ReactNode }) => (
                <div className="row" style={{ gap: 10, alignItems: 'flex-start', padding: '8px 0', borderTop: '1px solid var(--line)' }}>
                  <span className={`fs-dot ${ok ? 'on' : ''}`} style={{ marginTop: 1 }}>{ok ? <IcoCheck width={12} height={12} /> : null}</span>
                  <div style={{ flex: 1, minWidth: 0 }}><b style={{ fontSize: 13.5 }}>{t}</b>{children && <div className="muted" style={{ fontSize: 12, marginTop: 2 }}>{children}</div>}</div>
                </div>)
              return (
                <div style={{ marginTop: 8 }}>
                  <Step ok t={`intervals.icu povezan${app.settings.intervals!.name ? ` · ${app.settings.intervals!.name}` : ''}`}>{app.settings.intervals!.token ? 'Z enim dotikom (OAuth).' : 'Z osebnim API ključem.'} <button className="chip sm click" onClick={() => syncIntervals()}>Uvozi nove</button></Step>
                  <Step ok={watchOk} t={dev === 'garmin' ? 'Garmin pošilja vožnje' : 'Ura pošilja vožnje'}>
                    {watchOk ? `Zadnja: ${[...icu].sort((a, b) => b.date.localeCompare(a.date))[0]?.date.split('-').reverse().slice(0, 2).map(Number).join('. ')}.` : <>V intervals.icu: <b>Settings → {dev === 'garmin' ? 'Garmin' : 'tvoja znamka'} → Connect</b> — neposredno, ne prek Strave. Ko prva vožnja pride, se tu odkljuka samo.</>}
                  </Step>
                  {app.settings.intervals!.pushWorkouts !== false && (
                    <Step ok={!!app.settings.intervals!.planUploadOk} t="Vadbe gredo na uro">
                      {app.settings.intervals!.planUploadOk ? 'Urejeno — načrtovane vadbe iz koledarja gredo na uro same.' : <>V intervals.icu: <b>Nastavitve → Povezave → {dev === 'garmin' ? 'Garmin Connect' : 'tvoja ura'}</b> → obkljukaj <b>»Naloži načrtovane vadbe«</b> (angl. »Upload planned workouts«). Brez tega ostanejo samo v koledarju. <button className="chip sm click" onClick={() => void updateSettings({ intervals: { ...app.settings.intervals!, planUploadOk: true } })}>urejeno</button></>}
                    </Step>)}
                  <Step ok={!!app.settings.wellnessOn} t="Spanec, HRV in mirovni utrip">
                    {app.settings.wellnessOn ? 'Vklopljeno — jutranja pripravljenost je samodejna.' : <>Neobvezno: samodejna jutranja pripravljenost. Ostane na tej napravi. <button className="chip sm click" onClick={() => void setWellnessOn(true)}>vklopi</button></>}
                  </Step>
                </div>)
            })() : (<>
              <p style={{ fontSize: 13, marginTop: 6 }}>Vsaka vožnja, ki pride v intervals.icu iz ure, se pojavi tukaj — s sledjo za karto. Enkrat nastaviš, potem samo voziš.</p>
              {icuOauthOn() && (<>
                <Btn primary block style={{ marginTop: 12 }} onClick={startIcuOAuth}>Poveži z intervals.icu</Btn>
                <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>Če računa še nimaš, ga tam ustvariš brezplačno. Potem v intervals.icu poveži še {dev === 'garmin' ? 'Garmin' : 'svojo uro'} (Settings → Connect).</div>
              </>)}
              {icuOauthOn() ? (
                <details style={{ marginTop: 12 }}><summary className="muted" style={{ fontSize: 12.5, cursor: 'pointer', fontWeight: 700 }}>Raje z osebnim API ključem</summary>{keyForm}</details>
              ) : keyForm}
            </>)}
            {app.settings.intervals && (() => {
              const adv = importDiagnosis(app.icuDiag)
              if (!adv) return null
              return (
                <div className="icu-diag" style={{ marginTop: 10, padding: '10px 12px', borderRadius: 12, border: `1px solid ${adv.tone === 'warn' ? 'var(--warn)' : 'var(--line)'}`, background: 'var(--raised)' }}>
                  <b style={{ fontSize: 13, color: adv.tone === 'warn' ? 'var(--warn)' : 'var(--ink)' }}>{adv.title}</b>
                  <div style={{ fontSize: 12.5, marginTop: 4, color: 'var(--ink-2)', lineHeight: 1.5 }}>{adv.text}</div>
                  <a className="chip sm click" style={{ marginTop: 8, display: 'inline-flex' }} href={ICU_SETTINGS_URL} target="_blank" rel="noreferrer">Odpri nastavitve intervals.icu ↗</a>
                </div>)
            })()}
            {app.settings.intervals && (() => {
              const on = app.settings.intervals.pushWorkouts !== false
              const w = app.icuWorkouts
              const when = w ? new Date(w.at).toLocaleString('sl-SI', { day: 'numeric', month: 'numeric', hour: '2-digit', minute: '2-digit' }) : null
              return (
                <div style={{ marginTop: 12, paddingTop: 10, borderTop: '1px solid var(--line)' }}>
                  <div className="between"><b style={{ fontSize: 13 }}>Treningi na uro</b><Chip sm on={on} onClick={() => updateSettings({ intervals: { ...app.settings.intervals!, pushWorkouts: !on } }).then(async () => {
                    if (!on) { void pushWorkouts(true); return }
                    const n = await removeWorkouts()
                    if (n != null) toast(n ? `${n} treningov pobrisanih iz koledarja — Garmin jih umakne z ure ob naslednji sinhronizaciji.` : 'V koledarju ni bilo naših treningov.', 'ok', 7000)
                  })}>{on ? 'vklopljeno' : 'izklopljeno'}</Chip></div>
                  <div className="muted" style={{ fontSize: 12, marginTop: 4 }}>Naslednjih 14 dni načrta gre v koledar intervals.icu kot strukturirani treningi ({app.profile.gear.powerMeter === false ? 'cilji v utripu' : 'cilji v vatih'}), od tam jih Garmin sam prenese na uro. V intervals.icu obkljukaj še <b>Nastavitve → Povezave → Garmin Connect → »Naloži načrtovane vadbe«</b> (angl. »Upload planned workouts«). Ob vsaki spremembi načrta se pošlje samo; izklop jih pobriše iz koledarja.</div>
                  {on && <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>{w ? (w.err ? <span style={{ color: 'var(--bad)' }}>Napaka: {w.err}</span> : `Zadnjič ${when} · ${w.n} treningov v koledarju`) : 'Še ni poslano.'} <button className="chip sm click" onClick={() => pushWorkouts(true)}>pošlji zdaj</button></div>}
                </div>)
            })()}
            <div className="muted" style={{ fontSize: 11.5, marginTop: 10 }}>Če intervals.icu polniš prek Strave, trener teh voženj ne sme uporabiti — to ti povem naravnost ob uvozu.</div>
          </Card>
        )}

        {dev === 'phone' && (<>
          <Card accent className="page" style={{ marginBottom: 12 }}>
            <h4 style={{ color: 'var(--accent)' }}>1 · Posnetek zaslona</h4>
            <p style={{ fontSize: 13, marginTop: 6 }}>Slikaj povzetek vožnje v katerikoli aplikaciji ali na uri — trener prebere razdaljo, čas, utrip, moč. Preveriš in shraniš.</p>
          </Card>
          <div style={{ marginBottom: 12 }}><PhotoInput onPick={fromShot} busy={!!busy || ai.busy} label="Slikaj ali izberi posnetek" hint="Deluje z Garminom, Stravo, Wahoojem, Zwiftom, uro … Kar piše na sliki, preberem; kar ne, pustim prazno." /></div>
          <div className="row" style={{ gap: 8, marginBottom: 12 }}><Btn ghost sm block onClick={() => navigate('aktivnosti', { nova: '1' })}>Raje vnesem ročno</Btn></div>
        </>)}

        <Card style={{ marginBottom: 12 }}>
          <h4>{dev === 'files' ? '1' : '2'} · Vsa zgodovina</h4>
          <p style={{ fontSize: 13, marginTop: 6 }}>Naloži arhiv: <b>Garmin</b> (Account → Export Your Data), <b>Strava</b> (Settings → My Account → Download or Delete → Request your archive) ali Connect izvoz. Pride po e-pošti v 24–48 h.</p>
          <input ref={archRef} type="file" accept=".zip" style={{ display: 'none' }} onChange={e => e.target.files?.[0] && onArchive(e.target.files[0])} />
          <Btn ghost block sm style={{ marginTop: 12 }} disabled={!!busy} onClick={() => archRef.current?.click()}><IcoUpload width={16} height={16} /> Odloži .zip arhiv</Btn>
          <div className="muted" style={{ fontSize: 11.5, marginTop: 8 }}>Veliki arhivi (nad 200 MB) gredo bolje na računalniku. Dvojnike prepoznam sam.</div>
        </Card>

        <Card style={{ marginBottom: 12 }}>
          <h4>{dev === 'files' ? '2' : '3'} · Samo ta vožnja</h4>
          <p style={{ fontSize: 13, marginTop: 6 }}>Posamezne datoteke .fit, .gpx, .tcx (tudi .gz) — odloži jih sem.</p>
          <input ref={fileRef} type="file" multiple accept=".fit,.gpx,.tcx,.gz,.zip" style={{ display: 'none' }} onChange={e => onFiles(e.target.files)} />
          <div className="row" style={{ gap: 8, marginTop: 12 }}>
            <Btn ghost sm disabled={!!busy} onClick={() => fileRef.current?.click()}><IcoFile width={16} height={16} /> Izberi datoteke</Btn>
            <Btn ghost sm onClick={() => navigate('aktivnosti', { nova: '1' })}>Ročni vnos</Btn>
          </div>
        </Card>

        <div className="muted" style={{ fontSize: 12, textAlign: 'center', padding: '6px 0 14px' }}>Tvoje sledi ostanejo na tej napravi. V oblak gredo samo številke, nikoli pot.</div>
      </>)}
      {busy && <div className="toast" role="status">{busy}</div>}
    </div>

    <Sheet open={!!shot} onClose={() => setShot(null)}>
      {shot && (<>
        <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Preveri, kar sem prebral</b>
        {shot.notes && <div className="muted" style={{ fontSize: 12, marginTop: 4 }}>{shot.notes}</div>}
        <div className="row" style={{ gap: 7, flexWrap: 'wrap', margin: '12px 0' }}>{SPORTS.map(s => <Chip key={s.k} sm on={shot.sport === s.k} onClick={() => setShot({ ...shot, sport: s.k })}>{s.l}</Chip>)}</div>
        <div className="stack" style={{ gap: 10 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <div className="field"><label>Datum</label><DateField compact value={shot.date} max={todayIso()} onChange={v => setShot({ ...shot, date: v || todayIso() })} label="Datum" /></div>
            <div className="field"><label>Trajanje <span className="unit">min</span></label><input type="number" inputMode="numeric" value={shot.durationMin ?? ''} onChange={e => setShot({ ...shot, durationMin: e.target.value ? +e.target.value : null })} /></div>
            <div className="field"><label>Razdalja <span className="unit">km</span></label><input type="number" inputMode="decimal" step={0.1} value={shot.distKm ?? ''} onChange={e => setShot({ ...shot, distKm: e.target.value ? +e.target.value : null })} /></div>
            <div className="field"><label>Vzpon <span className="unit">m</span></label><input type="number" inputMode="numeric" value={shot.elevM ?? ''} onChange={e => setShot({ ...shot, elevM: e.target.value ? +e.target.value : null })} /></div>
            <div className="field"><label>Povp. utrip</label><input type="number" inputMode="numeric" value={shot.avgHr ?? ''} onChange={e => setShot({ ...shot, avgHr: e.target.value ? +e.target.value : null })} /></div>
            <div className="field"><label>Povp. moč <span className="unit">W</span></label><input type="number" inputMode="numeric" value={shot.avgPower ?? ''} onChange={e => setShot({ ...shot, avgPower: e.target.value ? +e.target.value : null })} /></div>
          </div>
          <div className="field"><label>Ime</label><input value={shot.name} onChange={e => setShot({ ...shot, name: e.target.value })} /></div>
        </div>
        <Btn primary block style={{ marginTop: 14 }} onClick={saveShot}>Shrani</Btn>
        <Btn ghost block style={{ marginTop: 9 }} onClick={() => setShot(null)}>Prekliči</Btn>
      </>)}
    </Sheet>
    {ai.sheet}
  </>)
}
