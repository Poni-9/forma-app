import { useEffect, useState } from 'react'
import { Head } from '@/app/Shell'
import { useApp, signIn, toast } from '@/state/store'
import { fetchFeedbackList, fetchFeedbackShot, setFeedbackStatus, FB_KINDS, type FbRow } from '@/data/feedback'
import { Btn, Card, Chip, Sheet } from '@/ui/primitives'

const KIND = new Map(FB_KINDS)
const when = (ms: number | null) => (ms ? new Date(ms).toLocaleString('sl-SI', { day: 'numeric', month: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—')

/** Pripomba kot besedilo (za Clauda ali zapiske): vrsta, kdaj, kdo, zaslon, različica, naprava, napake, besedilo. */
export function feedbackText(r: FbRow): string {
  const m = r.meta || {}
  return [
    `[${KIND.get(r.kind) || r.kind}] ${when(r.at)} · ${r.email || `anonimno ${r.anon}`} · zaslon ${m.route || '?'} · v${m.v || '?'} · ${m.w || '?'}×${m.h || '?'}${m.online === false ? ' · brez povezave' : ''}`,
    m.ua ? `Naprava: ${m.ua}` : '',
    m.errs && m.errs.length ? `Napake: ${m.errs.join(' | ')}` : '',
    r.text ? `Besedilo: ${r.text}` : '(brez besedila)',
    r.hasShot ? 'Posnetek zaslona: da (FORMAI → Pripombe)' : r.shotLater ? 'Posnetek zaslona: še na napravi uporabnika (pride, ko bo strežnik posodobljen)' : '',
  ].filter(Boolean).join('\n')
}

/**
 * PRIPOMBE (samo skrbnik — strežnik preveri Google račun): kaj uporabniki sporočajo, s posnetki zaslona; »Rešeno«
 * odstrani posnetek in pripombo umakne iz seznama novih. Claude jih prebere tu (Blažev Chrome) in popravi.
 */
export function Pripombe() {
  const app = useApp()
  const [all, setAll] = useState(false)
  const [rows, setRows] = useState<FbRow[] | null>(null)
  const [err, setErr] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [shot, setShot] = useState<{ id: string; url: string | null } | null>(null)
  const load = async (a = all) => { setBusy(true); const r = await fetchFeedbackList(a); setBusy(false); if ('error' in r) setErr(r.error); else { setErr(null); setRows(r.rows) } }
  useEffect(() => { if (app.user) void load(all) }, [app.user, all])  // eslint-disable-line react-hooks/exhaustive-deps

  async function open(id: string) { setShot({ id, url: null }); const u = await fetchFeedbackShot(id); setShot({ id, url: u }) }
  async function mark(r: FbRow, status: 'novo' | 'reseno') {
    if (!(await setFeedbackStatus(r.id, status))) { toast('Ni uspelo — poskusi znova.', 'err'); return }
    toast(status === 'reseno' ? 'Označeno kot rešeno (posnetek je izbrisan).' : 'Nazaj med nove.', 'ok')
    void load()
  }
  async function copyAll() {
    const t = (rows || []).map(feedbackText).join('\n\n')
    try { await navigator.clipboard.writeText(t); toast('Kopirano — prilepi Claudu.', 'ok') } catch { toast('Kopiranje tu ni na voljo.', 'info') }
  }

  return (<>
    <Head hi="Kaj sporočajo uporabniki" nm="Pripombe" />
    <div className="scroll">
      {!app.user ? (
        <Card><p style={{ fontSize: 13 }}>Pripombe vidi samo skrbnik — prijavi se z Googlom.</p><Btn sm style={{ marginTop: 10 }} onClick={() => void signIn().catch(e => toast((e as Error).message, 'err'))}>Prijava z Googlom</Btn></Card>
      ) : (<>
        <div className="row" style={{ gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
          <Chip on={!all} onClick={() => setAll(false)}>Nove</Chip>
          <Chip on={all} onClick={() => setAll(true)}>Vse</Chip>
          <Btn ghost sm disabled={busy} onClick={() => void load()}>{busy ? 'Nalagam …' : 'Osveži'}</Btn>
          {rows && rows.length > 0 && <Btn ghost sm onClick={() => void copyAll()}>Kopiraj vse</Btn>}
        </div>
        {err && <Card tight><p style={{ fontSize: 13, color: 'var(--warn)' }}>{err}</p></Card>}
        {rows && !rows.length && !err && <Card tight><p className="muted" style={{ fontSize: 13 }}>{all ? 'Pripomb še ni.' : 'Ni novih pripomb.'}</p></Card>}
        <div className="stack" style={{ gap: 10 }}>
          {(rows || []).map(r => (
            <Card key={r.id} tight>
              <div className="between" style={{ gap: 8 }}>
                <span className="row" style={{ gap: 6 }}><Chip sm on={r.kind === 'napaka'}>{KIND.get(r.kind) || r.kind}</Chip>{r.status === 'reseno' && <Chip sm ok>rešeno</Chip>}</span>
                <span className="muted" style={{ fontSize: 11.5, fontWeight: 700 }}>{when(r.at)}</span>
              </div>
              <p style={{ fontSize: 13.5, marginTop: 8, whiteSpace: 'pre-wrap', color: 'var(--ink)' }}>{r.text || <span className="muted">(brez besedila — samo posnetek)</span>}</p>
              <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>{r.email || `anonimno · ${r.anon}`} · zaslon {r.meta?.route || '?'} · v{r.meta?.v || '?'} · {r.meta?.w}×{r.meta?.h}{r.meta?.errs?.length ? ` · napake: ${r.meta.errs.length}` : ''}</div>
              <div className="row" style={{ gap: 6, marginTop: 10, flexWrap: 'wrap' }}>
                {r.hasShot && <button type="button" className="chip sm click" onClick={() => void open(r.id)}>posnetek zaslona</button>}
                {r.shotLater && <span className="muted" style={{ fontSize: 11.5, alignSelf: 'center' }}>posnetek pride, ko bo strežnik posodobljen</span>}
                {r.status !== 'reseno' ? <button type="button" className="chip sm click" onClick={() => void mark(r, 'reseno')}>rešeno</button> : <button type="button" className="chip sm click" onClick={() => void mark(r, 'novo')}>nazaj med nove</button>}
                <button type="button" className="chip sm click" onClick={() => void navigator.clipboard?.writeText(feedbackText(r)).then(() => toast('Kopirano.', 'ok'), () => toast('Kopiranje ni na voljo.', 'info'))}>kopiraj</button>
              </div>
            </Card>
          ))}
        </div>
      </>)}
    </div>
    {shot && (
      <Sheet open onClose={() => setShot(null)} label="Posnetek zaslona">
        <b style={{ fontSize: 15 }}>Posnetek zaslona</b>
        {shot.url ? <img src={shot.url} alt="Posnetek zaslona iz pripombe" style={{ width: '100%', marginTop: 10, borderRadius: 12, boxShadow: '0 0 0 1px var(--line)' }} /> : <p className="muted" style={{ fontSize: 13, marginTop: 10 }}>Nalagam …</p>}
        <Btn ghost block style={{ marginTop: 12 }} onClick={() => setShot(null)}>Zapri</Btn>
      </Sheet>
    )}
  </>)
}
