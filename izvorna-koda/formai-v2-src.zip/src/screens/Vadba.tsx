import { FuelTimeline, drinkLine } from '@/ui/FuelTimeline'
import { useEffect, useMemo, useRef, useState } from 'react'
import { navigate, useRoute } from '@/app/router'
import { useApp, setPlanDone, addActivities, toast, rateSession, savePlanDay } from '@/state/store'
import { RateRow } from '@/ui/RateRow'
import { stepsFor, totalSec, fmtClock, structureLines, howOf, type Step } from '@/domain/training/workout'
import { exByName, swapOptions, lastDone, repsTopOf, kgStep, dose, MUSCLE_LABEL } from '@/domain/training/exercises'
import { rideFuel, fuelCtxOf } from '@/domain/nutrition/dayplan'
import { RouteCard } from '@/ui/RouteCard'
import { fueling } from '@/domain/nutrition/energy'
import { fmtDur } from '@/domain/training/load'
import { powerZones7, workText, noPower, zoneText } from '@/domain/training/zones'
import { deriveFlags } from '@/domain/import/provenance'
import { estimateTss } from '@/domain/training/load'
import type { Activity, PlanDay } from '@/domain/types'
import { Btn, Chip, KindIcon, kindColor, kindInk, kindLabelOf, Sheet } from '@/ui/primitives'
import { HealthNote } from '@/ui/HealthNote'
import { useConfirm } from '@/ui/Confirm'
import { count, dayName, dm, nb, num, plural, unit, W } from '@/ui/format'
import { IcoBack, IcoCheck, IcoDrink, IcoTarget } from '@/ui/icons'

/**
 * Stanje vadbe. Dan in koraki so ob začetku »zamrznjeni« (sinhronizacija ali ponovno branje načrta med vadbo
 * ne ponastavi časovnika). Čas je iz ure (Date.now()), ne iz štetja intervalov — teče naprej tudi, ko je telefon
 * zaklenjen ali je aplikacija v ozadju. Napredek je v sessionStorage: po osvežitvi strani vadba teče naprej.
 */
export interface Run {
  v: 1
  dayId: string
  day: PlanDay
  steps: Step[]
  /** trenutni korak */
  i: number
  /** pretečeni čas (ms) ob začetku trenutnega koraka */
  stepAt: number
  /** pretečeno do zadnjega zagona (ms) */
  acc: number
  /** Date.now() ob zadnjem zagonu; null = pavza */
  runFrom: number | null
  /** minute opomnikov za hrano, ki so že bili */
  cues: number[]
  /** opomnik, ki čaka na konec intervala */
  cue: string | null
  finished: boolean
  /** moč je že zapisana kot aktivnost (samo enkrat) */
  saved: boolean
  /** moč: kaj si naredil v seriji (indeks koraka → kg, ponovitve) */
  log?: Record<number, SetLog>
}
export interface SetLog { kg: number | null; reps: number | null }
/** Opravljene vaje iz vpisanih serij: ponovitve po serijah (»10, 10, 9«), največ kg; brez vpisa ostane načrt. */
export function loggedExercises(r: Pick<Run, 'day' | 'steps' | 'log'>): NonNullable<Activity['exercises']> {
  const logs = r.log || {}
  const any = Object.keys(logs).length > 0
  // z vpisi: samo vaje, ki si jih res delal (predčasen konec ne zapiše neopravljenih); brez vpisov: načrt
  return (r.day.exercises || []).filter(e => !any || r.steps.some((s, k) => s.kind === 'vaja' && s.label === e.name && logs[k])).map(e => {
    const ls = r.steps.map((s, k) => ({ s, k })).filter(x => x.s.kind === 'vaja' && x.s.label === e.name && logs[x.k]).map(x => logs[x.k]!)
    if (!ls.length) return { ...e }
    const kgs = ls.map(l => l.kg).filter((x): x is number => x != null && x > 0)
    const reps = ls.map(l => l.reps).filter((x): x is number => x != null)
    return { ...e, sets: ls.length, reps: reps.length ? reps.join(', ') : e.reps, kg: kgs.length ? Math.max(...kgs) : e.kg ?? null }
  })
}
export const RUN_KEY = 'formai.vadba.v1'
export const elapsedOf = (r: Pick<Run, 'acc' | 'runFrom'>, now: number): number => r.acc + (r.runFrom != null ? Math.max(0, now - r.runFrom) : 0)
/** pod tem deležem »Zaključi« vpraša: nadaljuj / shrani, kar si naredil / prekini brez oznake */
export const EARLY = 0.5
/** shraniti kot opravljeno se da šele po 5 min; obnova po treningu šele po 30 min */
const PARTIAL_SAVE_SEC = 5 * 60, RECOVERY_MIN_SEC = 30 * 60
function loadRun(): Run | null {
  try { const r = JSON.parse(sessionStorage.getItem(RUN_KEY) || 'null') as Run | null; return r && r.v === 1 && r.day && Array.isArray(r.steps) ? r : null } catch { return null }
}
function storeRun(r: Run | null) {
  try { if (r) sessionStorage.setItem(RUN_KEY, JSON.stringify(r)); else sessionStorage.removeItem(RUN_KEY) } catch { /* brez shrambe */ }
}
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
const STEP_KIND: Record<string, string> = { delo: 'Delo', lahko: 'Lahko', pavza: 'Pavza', vaja: 'Vaja', test: 'Test', ogrevanje: 'Ogrevanje' }
const stepKind = (k: string): string => STEP_KIND[k] ?? 'Iztek'
type Lock ={ release: () => Promise<void>; addEventListener?: (t: 'release', f: () => void) => void }

/**
 * Izvajalnik treninga — te pelje skozi cel trening:
 * pred začetkom pregled (kaj te čaka, vati, kaj vzeti s seboj, kaj pojesti), med treningom en korak naenkrat
 * z vati, občutkom (RPE) in kadenco, pisk ob menjavi, opomnik za hrano in pijačo; po koncu obnova in kaj sledi.
 * Zaslon ostane prižgan (Wake Lock). Ob koncu označi dan kot opravljen; moč zapiše kot aktivnost.
 */
export function Vadba() {
  const app = useApp()
  const route = useRoute()
  const { confirm, sheet: confirmSheet } = useConfirm()
  const [early, setEarly] = useState(false)
  // shranjena vadba (osvežitev strani) za ta dan — ali za katerikoli dan, če id ni podan
  const [run, setRunState] = useState<Run | null>(() => { const r = loadRun(); return r && (!route.params.id || r.dayId === route.params.id) ? r : null })
  const runRef = useRef<Run | null>(run)
  const setRun = (r: Run | null) => { runRef.current = r; storeRun(r); setRunState(r) }
  const [now, setNow] = useState(() => Date.now())
  const [fuelMsg, setFuelMsg] = useState<string | null>(null)
  // moč: vpis serije (kg in ponovitve) in zamenjava vaje
  const [setIn, setSetIn] = useState<{ kg: string; reps: number | null }>({ kg: '', reps: null })
  const [swapOpen, setSwapOpen] = useState(false)
  const liveDay = app.plan.find(d => d.id === route.params.id) || app.plan.find(d => d.date === app.today && d.kind !== 'pocitek') || null
  const day = run ? run.day : liveDay
  const liveSteps = useMemo(() => (liveDay ? stepsFor(liveDay, app.profile) : []), [liveDay, app.profile])
  const steps = run ? run.steps : liveSteps
  const fuel = useMemo(() => (day ? rideFuel(day, app.profile.fuelKit, fuelCtxOf(app.weather, app.recentMeals, day.date, app.today)) : null), [day, app.profile.fuelKit, app.weather, app.recentMeals, app.today])
  const z2 = powerZones7(app.profile)?.find(z => z.key === 'Z2')
  const food = useMemo(() => (day ? fueling(day, app.profile) : null), [day, app.profile])
  const nextDay = app.plan.filter(d => day && d.date > day.date && d.kind !== 'pocitek').sort((a, b) => a.date.localeCompare(b.date) || (a.kind === 'moc' ? 1 : -1))[0]
  const audio = useRef<AudioContext | null>(null)
  const lock = useRef<Lock | null>(null)
  const lastBeep = useRef('')
  const cueTimer = useRef<number | null>(null)
  const fuelRef = useRef(fuel)
  fuelRef.current = fuel

  function beep(freq: number, dur: number) {
    try {
      if (!audio.current) audio.current = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)()
      const ctx = audio.current
      if (ctx.state === 'suspended') void ctx.resume().catch(() => undefined)
      const o = ctx.createOscillator(), g = ctx.createGain()
      o.frequency.value = freq; o.connect(g); g.connect(ctx.destination)
      g.gain.setValueAtTime(0.0001, ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur)
      o.start(); o.stop(ctx.currentTime + dur)
    } catch { /* brez zvoka */ }
  }
  function showCue(text: string) {
    setFuelMsg(text); beep(660, 0.12); setTimeout(() => beep(990, 0.12), 180)
    try { navigator.vibrate?.([120, 80, 120]) } catch { /* brez vibracije */ }
    if (cueTimer.current) clearTimeout(cueTimer.current)
    cueTimer.current = window.setTimeout(() => setFuelMsg(null), 45_000)
  }
  const isWork = (s: Step | undefined) => !!s && (s.kind === 'delo' || s.kind === 'test')

  /** Premik na korak `to` (ali konec), ob pretečenem času `at`. Stranski učinki (pisk, opomnik) so zunaj posodobitve stanja. */
  function moveTo(r: Run, to: number, at: number, sound = true) {
    if (to >= r.steps.length) {
      // »Preskoči« čez zadnji korak na hitro ni opravljen trening — isto vprašanje kot pri »Zaključi«
      const all = totalSec(r.steps) * 1000
      if (!sound && r.day.kind !== 'moc' && all > 0 && at < all * EARLY) { setEarly(true); return }
      void finish(at); return
    }
    let next: Run = { ...r, i: Math.max(0, to), stepAt: at }
    if (next.cue && !isWork(next.steps[next.i])) { const c = next.cue; next = { ...next, cue: null }; setRun(next); showCue(c) }
    else setRun(next)
    if (sound) beep(1320, 0.25)
  }

  // časovnik: vsake 250 ms iz ure; ob vrnitvi iz ozadja ujame vse korake, ki so medtem minili
  useEffect(() => {
    if (!run || run.runFrom == null || run.finished) return
    const tick = () => {
      let r: Run | null = runRef.current
      if (!r || r.runFrom == null || r.finished) return
      const t = Date.now(), el = elapsedOf(r, t)
      let moved = 0
      for (;;) {
        const st = r.steps[r.i]
        if (!st || st.sec <= 0) break
        const end: number = r.stepAt + st.sec * 1000
        if (el < end) break
        if (r.i + 1 >= r.steps.length) { beep(1320, 0.25); void finish(end); return }
        r = { ...r, i: r.i + 1, stepAt: end }; moved++
      }
      // hrana in pijača po časovnici goriva; med delom počaka na odmor
      const f = fuelRef.current
      const due = f?.cues.filter(c => c.atMin * 60_000 <= el && !r!.cues.includes(c.atMin)) || []
      let show: string | null = null
      if (due.length) {
        const text = due[due.length - 1]!.text
        r = { ...r, cues: [...r.cues, ...due.map(c => c.atMin)] }
        if (isWork(r.steps[r.i])) r = { ...r, cue: text }; else show = text
      }
      if (r.cue && !isWork(r.steps[r.i])) { show = r.cue; r = { ...r, cue: null } }
      if (r !== runRef.current) setRun(r)
      if (moved) beep(1320, 0.25)
      if (show) showCue(show)
      // pisk 3, 2, 1 s pred koncem koraka (vsak samo enkrat)
      const st = r.steps[r.i]
      if (st && st.sec > 0) {
        const left = Math.ceil((r.stepAt + st.sec * 1000 - el) / 1000), key = `${r.i}:${left}`
        if (left >= 1 && left <= 3 && lastBeep.current !== key) { lastBeep.current = key; beep(880, 0.08) }
      }
      setNow(t)
    }
    tick()
    const h = window.setInterval(tick, 250)
    return () => clearInterval(h)
  }, [run?.runFrom, run?.finished])   // eslint-disable-line react-hooks/exhaustive-deps

  // zaslon naj ostane prižgan; brskalnik zaklep sprosti, ko gre stran v ozadje — ob vrnitvi ga zahtevamo znova
  const wantLock = !!run && run.runFrom != null && !run.finished
  useEffect(() => {
    if (!wantLock) return
    const nav = navigator as Navigator & { wakeLock?: { request(t: 'screen'): Promise<Lock> } }
    const request = () => {
      if (document.visibilityState !== 'visible' || lock.current || !nav.wakeLock) return
      nav.wakeLock.request('screen').then(l => { lock.current = l; l.addEventListener?.('release', () => { if (lock.current === l) lock.current = null }) }).catch(() => undefined)
    }
    request()
    const onVis = () => { if (document.visibilityState === 'visible') { request(); setNow(Date.now()) } }
    document.addEventListener('visibilitychange', onVis)
    return () => { document.removeEventListener('visibilitychange', onVis); lock.current?.release().catch(() => undefined); lock.current = null }
  }, [wantLock])

  // ob odhodu z zaslona: zvok zapri, opomnik počisti
  useEffect(() => () => {
    if (cueTimer.current) clearTimeout(cueTimer.current)
    void audio.current?.close().catch(() => undefined); audio.current = null
  }, [])

  // vpis serije: ob prihodu na serijo predlagaj kg in ponovitve (prejšnja serija te vaje, načrt, zadnja vadba)
  const runI = run?.i ?? -1, runDay = run?.dayId ?? '', runLabel = run ? run.steps[run.i]?.label ?? '' : ''
  useEffect(() => {
    const r = runRef.current
    const st = r?.steps[r.i]
    if (!r || !st || st.kind !== 'vaja' || r.day.kind !== 'moc') return
    const e = (r.day.exercises || []).find(x => x.name === st.label)
    const own = r.log?.[r.i]
    const prevK = Object.keys(r.log || {}).map(Number).filter(k => k < r.i && r.steps[k]?.label === st.label).sort((a, b) => b - a)[0]
    const prev = own ?? (prevK != null ? r.log![prevK] : null)
    const last = !prev && e && e.kg == null ? lastDone(st.label, app.activities) : null
    const kg = prev?.kg ?? e?.kg ?? last?.kg ?? null
    setSetIn({ kg: kg != null ? String(kg).replace('.', ',') : '', reps: prev?.reps ?? (e ? repsTopOf(e.reps) : null) })
  }, [runI, runDay, runLabel])   // eslint-disable-line react-hooks/exhaustive-deps

  /** Zamenjava vaje (naprava zasedena, ne ustreza): preostale serije te vaje in dan v načrtu. */
  function swapTo(name: string) {
    const r = runRef.current
    const st = r?.steps[r.i]
    if (!r || !st) return
    const old = st.label, d = exByName(name)
    const ds = d ? dose(d, f?.aims ?? [], f?.level ?? 2) : null
    const steps2 = r.steps.map((x, k) => (k >= r.i && x.kind === 'vaja' && x.label === old
      ? { ...x, label: name, reps: ds?.reps ?? (x.reps || '').replace(/ · [\d,.]+ kg$/, ''), sec: d?.time ? +(/(\d+)\s*s\b/.exec(ds?.reps || '')?.[1] ?? 30) : 0, note: `${howOf(name)} ${d?.time ? '' : 'Ko končaš serijo, tapni naprej.'}`.trim() }
      : x))
    // že narejene serije stare vaje ostanejo zapisane pod njenim imenom, preostale gredo novi
    const doneSets = Object.keys(r.log || {}).filter(k => +k < r.i && r.steps[+k]?.label === old).length
    const day2 = { ...r.day, exercises: (r.day.exercises || []).flatMap(e => (e.name === old
      ? [...(doneSets ? [{ ...e, sets: doneSets }] : []), { ...e, name, sets: Math.max(1, e.sets - doneSets), reps: ds?.reps ?? e.reps, kg: null, rest: ds?.rest ?? e.rest ?? null }]
      : [e])) }
    setRun({ ...r, steps: steps2, day: day2 })
    setSwapOpen(false)
    // dan v načrtu dobi novo vajo (Danes, Plan in zapis vadbe se ujemajo)
    const live = app.plan.find(x => x.id === r.dayId)
    if (live && !live.done) void savePlanDay({ ...live, exercises: day2.exercises })
    toast(`Zamenjano: ${name}.`, 'ok')
  }

  function start() {
    if (!audio.current) beep(1, 0.001)   // odklene zvok v dotiku (iOS)
    const r = runRef.current
    if (r) { if (r.runFrom == null && !r.finished) setRun({ ...r, runFrom: Date.now() }); return }
    if (!day || !steps.length) return
    const t = Date.now()
    setRun({ v: 1, dayId: day.id, day, steps, i: 0, stepAt: 0, acc: 0, runFrom: t, cues: [], cue: null, finished: false, saved: false })
    setNow(t)
  }
  function pause() { const r = runRef.current; if (!r || r.runFrom == null) return; const t = Date.now(); setRun({ ...r, acc: elapsedOf(r, t), runFrom: null }); setNow(t) }
  /** Naprej: pri seriji moči shrani vpis (kg, ponovitve); Preskoči (log = false) serije ne zapiše. */
  function next(log = false) {
    let r = runRef.current
    if (!r) return
    const st = r.steps[r.i]
    if (log && st && st.kind === 'vaja' && st.sec === 0 && r.day.kind === 'moc') {
      const v = setIn.kg.trim() ? +setIn.kg.replace(',', '.') : NaN
      r = { ...r, log: { ...(r.log || {}), [r.i]: { kg: Number.isFinite(v) && v > 0 ? Math.round(v * 4) / 4 : null, reps: setIn.reps } } }
      setRun(r)
    }
    moveTo(r, r.i + 1, elapsedOf(r, Date.now()), false)
  }
  function prev() { const r = runRef.current; if (r && r.i > 0) moveTo(r, r.i - 1, elapsedOf(r, Date.now()), false) }
  async function finish(at?: number) {
    const r = runRef.current
    if (!r || r.finished) return
    const el = at ?? elapsedOf(r, Date.now())
    const done: Run = { ...r, finished: true, acc: el, runFrom: null, i: Math.min(r.i, r.steps.length - 1) }
    setRun(done); setNow(Date.now())
    await setPlanDone(r.day.id, true)
    if (r.day.kind === 'moc' && !r.saved) {
      setRun({ ...done, saved: true })
      // moč se ne meri z uro — zapišemo jo iz izvajalnika, da šteje v obremenitev (samo enkrat)
      const t = new Date().toISOString()
      const a: Activity = { id: uid(), source: 'manual', sport: 'moc', date: app.today, start: t, name: r.day.title, durationMin: Math.max(10, Math.round(el / 60_000)), tss: null, polyline: null, exercises: loggedExercises(r), ...deriveFlags('manual'), createdAt: t, updatedAt: t }
      a.tss = estimateTss(a, app.profile)
      await addActivities([a])
    }
    // kolo: zaslon »Opravljeno« že pove, kako pride vožnja — brez ponovitve v obvestilu
    if (r.day.kind === 'moc') toast('Vadba zapisana med aktivnosti.', 'ok', 4000)
  }
  async function leave() {
    const r = runRef.current
    if (r && !r.finished && r.runFrom != null) {
      if (!(await confirm({ title: 'Prekinem trening?', text: 'Napredek tega treninga se ne shrani. Dan ostane neoznačen.', ok: 'Prekini', cancel: 'Nadaljuj trening' }))) return
      setRun(null)
    } else if (r?.finished) setRun(null)
    navigate('danes')
  }
  async function endNow() {
    const r = runRef.current
    if (!r) return
    const done = elapsedOf(r, Date.now()), all = totalSec(r.steps) * 1000
    // pod polovico: ne označi kar tako — 2 s »treninga« ni opravljen trening (moč ima korake brez časa: tam ne)
    if (r.day.kind !== 'moc' && all > 0 && done < all * EARLY) { setEarly(true); return }
    if (await confirm({ title: 'Zaključim trening zdaj?', text: 'Dan se označi kot opravljen s časom do zdaj.', ok: 'Zaključi' })) void finish()
  }
  function stopNoMark() { setEarly(false); setRun(null); navigate('danes'); toast('Trening prekinjen — dan ostane neoznačen.', 'info') }
  const exit = (to: 'danes' | 'uvoz') => { setRun(null); navigate(to) }

  if (!day || !steps.length) return (
    <div className="app" style={{ display: 'grid', placeItems: 'center', padding: 24 }}>
      <div className="card" style={{ textAlign: 'center' }}><h3>Danes ni treninga</h3><p style={{ marginTop: 6 }}>Poglej plan ali sestavi teden.</p><Btn primary sm style={{ marginTop: 12 }} onClick={() => navigate('plan')}>Odpri plan</Btn></div>
    </div>
  )

  const color = kindColor(day.kind)
  const total = totalSec(steps)
  const el = run ? elapsedOf(run, now) : 0
  const elapsed = Math.floor(el / 1000)
  const i = run ? run.i : 0
  const step: Step | undefined = steps[i]
  const left = step && step.sec > 0 ? Math.max(0, step.sec - Math.floor((el - (run?.stepAt ?? 0)) / 1000)) : 0
  const running = !!run && run.runFrom != null && !run.finished
  const pct = total ? Math.min(100, (elapsed / total) * 100) : 0
  const nextStep = steps[i + 1]
  // moč: serija, ki jo vpišeš (kg, ponovitve), in možne zamenjave vaje (ista skupina, druga oprema)
  const exNow = step && step.kind === 'vaja' && day.kind === 'moc' ? (day.exercises || []).find(e => e.name === step.label) ?? null : null
  const defNow = exNow ? exByName(exNow.name) : undefined
  const logSet = !!run && !run.finished && !!exNow && step!.sec === 0
  const weighted = !!exNow && (exNow.kg != null || !!defNow?.kg || defNow?.eq === 'fitnes')
  const f = app.profile.focus
  const swapCtx = { where: (f ? /^Doma/.test(day.title) : app.profile.strength.equipment !== 'gym') ? 'doma' as const : 'fitnes' as const, equip: f?.equipment ?? [...(app.profile.gear.dumbbells ? ['utezi' as const] : []), ...(app.profile.gear.pullupBar ? ['drog' as const] : [])], level: f?.level ?? 2, limits: f?.limits ?? null }
  const swaps = exNow && run && !run.finished ? swapOptions(exNow.name, swapCtx, (day.exercises || []).map(e => e.name)) : []

  return (
    <div className="app" style={{ background: 'var(--bg-deep)' }}>
      <header className="head">
        <button className="avatar" style={{ background: 'transparent' }} onClick={() => void leave()} aria-label="Nazaj"><IcoBack /></button>
        <div style={{ textAlign: 'center', minWidth: 0 }}><div className="hi" style={{ color: kindInk(day.kind) }}>{kindLabelOf(day).toUpperCase()}</div><h1 className="nm" style={{ fontSize: 16, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{day.title}</h1></div>
        <div style={{ width: 38, flex: 'none' }} />
      </header>
      <div className="track" style={{ margin: '0 18px' }}><i style={{ width: `${pct}%`, background: color }} /></div>

      <main className="scroll" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', textAlign: 'center', padding: '20px 18px 30px' }}>
        {run?.finished ? (
          <div className="page">
            <div className="check" style={{ width: 72, height: 72, margin: '0 auto' }}><IcoCheck width={34} height={34} /></div>
            <h2 style={{ marginTop: 16 }}>Opravljeno</h2>
            <p style={{ marginTop: 6 }}>{fmtClock(elapsed)} · {count(steps.length, W.korak)}</p>
            {(() => {
              const live = app.plan.find(d => d.id === day.id)
              const act = live?.done?.activityId ? app.activities.find(a => a.id === live.done!.activityId) : null
              return <div className="card tight" style={{ textAlign: 'left', marginTop: 16 }}><RateRow label="Kako je šlo?" value={act?.rpe ?? live?.rpe ?? null} onPick={v => void rateSession({ activityId: act?.id ?? null, dayId: day.id }, v)} /></div>
            })()}
            {day.kind === 'moc' && run.log && Object.keys(run.log).length > 0 && (
              <div className="card tight" style={{ textAlign: 'left', marginTop: 16 }}>
                <h2 className="h4" style={{ fontSize: 11 }}>Tvoje serije</h2>
                {loggedExercises(run).filter(e => Object.keys(run.log!).some(k => run.steps[+k]?.label === e.name)).map(e => {
                  const plan0 = (run.day.exercises || []).find(x => x.name === e.name)
                  const top = plan0 ? repsTopOf(plan0.reps) : null
                  const all = String(e.reps).split(',').map(x => +x.trim()).filter(x => Number.isFinite(x))
                  const up = !!e.kg && top != null && all.length > 0 && all.every(x => x >= top)
                  return <div key={e.name} className="between" style={{ fontSize: 13, padding: '5px 0', borderTop: '1px solid var(--line-soft)', gap: 10 }}><span style={{ fontWeight: 600, color: 'var(--ink)', minWidth: 0 }}>{e.name}</span><span style={{ flex: 'none', textAlign: 'right' }}><span className="muted">{e.reps}{e.kg ? ` · ${unit(num(e.kg), 'kg')}` : ''}</span>{up ? <b style={{ display: 'block', fontSize: 11.5, color: 'var(--ok)' }}>naslednjič več kg</b> : null}</span></div>
                })}
              </div>
            )}
            {food && elapsed >= RECOVERY_MIN_SEC && <div className="card tight" style={{ textAlign: 'left', marginTop: 16 }}><h2 className="h4" style={{ fontSize: 11 }}>Zdaj — obnova</h2><p style={{ fontSize: 13, marginTop: 4, color: 'var(--ink-2)' }}>{nb(food.after)}</p></div>}
            {day.kind !== 'moc' && <p className="muted" style={{ fontSize: 12.5, marginTop: 10 }}>Vožnja pride iz Garmina (intervals.icu) sama in se poveže s tem dnem. Brez ure jo uvozi kot datoteko.</p>}
            {nextDay && <p style={{ fontSize: 13, marginTop: 10 }}>Naslednji: <b style={{ color: 'var(--ink)' }}>{nextDay.title}</b> · {dayName(nextDay.date)}, {dm(nextDay.date)}</p>}
            <div className="row" style={{ gap: 8, justifyContent: 'center', marginTop: 20, flexWrap: 'wrap' }}><Btn primary onClick={() => exit('danes')}>Nazaj na Danes</Btn>{day.kind !== 'moc' && <Btn ghost onClick={() => exit('uvoz')}>Uvozi vožnjo</Btn>}</div>
          </div>
        ) : !run ? (
          <div className="page" style={{ textAlign: 'left', maxWidth: 520, margin: '0 auto', width: '100%' }}>
            {/* naslov je že v glavi — tu številke seje in cilj dela */}
            <div className="card sess spot" style={{ ['--c' as string]: color }}>
              <div className="kbadge"><span className="ki"><KindIcon kind={day.kind} /></span>{kindLabelOf(day)} · {count(steps.length, W.korak)}</div>
              <div className="kpis">
                <div className="kpi"><b>{fmtDur(day.kind === 'moc' && day.durationMin ? day.durationMin : Math.round(total / 60))}</b><small>trajanje</small></div>
                {day.tssTarget ? <div className="kpi"><b>{day.tssTarget}</b><small>TSS</small></div> : null}
                {day.exercises?.length ? <div className="kpi"><b>{day.exercises.length}</b><small>{plural(day.exercises.length, W.vaja)}</small></div> : null}
                {day.kind === 'kolo' && day.zone && /^Z[1-5]$/.test(day.zone) ? <div className="kpi"><b>{day.zone}</b><small>cona</small></div> : null}
              </div>
              {(day.target || (day.kind === 'kolo' && /Z2/.test(day.zone || '') && (noPower(app.profile) || z2))) && (
                <div className="row" style={{ gap: 8, marginTop: 12, fontSize: 13, fontWeight: 700, color: 'var(--ink)', alignItems: 'flex-start' }}>
                  <IcoTarget width={16} height={16} style={{ color, flex: 'none', marginTop: 2 }} />
                  <span>{day.target ? (noPower(app.profile) ? `delo: ${workText(app.profile, day)}` : `delo pri ${workText(app.profile, day)}`) : noPower(app.profile) ? `Z2 ${zoneText(app.profile, 'Z2')}` : `Z2 ${z2!.lo}–${z2!.hi} W`}</span>
                </div>
              )}
            </div>
            <div className="card tight" style={{ marginTop: 12 }}>
              <h2 className="h4" style={{ fontSize: 11 }}>Kaj te čaka</h2>
              <ol style={{ margin: '6px 0 0 18px', padding: 0, fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.6 }}>{structureLines(steps).map((l, j) => <li key={j}>{nb(l)}</li>)}</ol>
              {day.why && <p className="muted" style={{ fontSize: 12, marginTop: 8 }}>Zakaj: {day.why}</p>}
            </div>
            {(day.kind === 'kolo' || day.kind === 'test') && <RouteCard day={day} compact />}
            {day.kind === 'moc' ? (
              <div className="card tight" style={{ marginTop: 10 }}>
                <h2 className="h4" style={{ fontSize: 11 }}>Kako</h2>
                {(day.exercises || []).map((e, j) => <div key={j} style={{ fontSize: 12.5, marginTop: 6 }}><b style={{ color: 'var(--ink)' }}>{e.name}</b> <span className="muted">{e.sets} × {e.reps}</span><div style={{ color: 'var(--ink-2)' }}>{howOf(e.name)}</div></div>)}
              </div>
            ) : (<>
              {fuel && <div className="card tight" style={{ marginTop: 10 }}>
                <h2 className="h4" style={{ fontSize: 11 }}>Vzemi s seboj</h2>
                <ul style={{ margin: '6px 0 0 18px', padding: 0, fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.6 }}>{fuel.items.map((x, j) => <li key={j}>{nb(x)}</li>)}</ul>
                <p className="muted" style={{ fontSize: 12, marginTop: 6 }}>{nb(fuel.cues.length ? drinkLine(fuel) : fuel.schedule)}</p>
                <FuelTimeline rf={fuel} minutes={day.durationMin} />
              </div>}
              {food && <div className="card tight" style={{ marginTop: 10 }}><h2 className="h4" style={{ fontSize: 11 }}>Pred treningom</h2><p style={{ fontSize: 13, marginTop: 4, color: 'var(--ink-2)' }}>{nb(food.before)}</p></div>}
              <p className="muted" style={{ fontSize: 12, marginTop: 10 }}>Med treningom: vati in občutek za vsak korak, pisk 3 s pred menjavo{fuel?.cues.length ? `, opomnik (pisk in vibracija), kdaj jesti in piti — prvi v ${fuel.cues[0]!.atMin}. minuti, med intervalom počaka na odmor` : ''}. Zaslon ostane prižgan.</p>
            </>)}
            <Btn primary block style={{ marginTop: 14 }} onClick={start}>Začni trening</Btn>
            <HealthNote kind="plan" />
          </div>
        ) : step && (
          <div className="page run-view" key={i}>
            {fuelMsg && <button className="card tight" onClick={() => setFuelMsg(null)} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', width: '100%', textAlign: 'left', borderColor: 'var(--accent)', background: 'var(--accent-soft)', marginBottom: 12, fontSize: 13.5, fontWeight: 700, color: 'var(--ink)', cursor: 'pointer' }}><IcoDrink width={18} height={18} aria-hidden="true" style={{ color: 'var(--accent-fg)', flex: 'none', marginTop: 1 }} /><span>{fuelMsg} <span className="muted" style={{ fontWeight: 600, fontSize: 12 }}>· tapni, ko je opravljeno</span></span></button>}
            <Chip sm>{i + 1} / {steps.length}</Chip>
            {/* vrsta koraka nad imenom — ne, kadar je enaka imenu (»Ogrevanje« dvakrat) */}
            {stepKind(step.kind).toLowerCase() !== step.label.trim().toLowerCase() && <div className="muted" style={{ fontSize: 13, fontWeight: 700, marginTop: 14, letterSpacing: '.06em', textTransform: 'uppercase', color: kindInk(day.kind) }}>{stepKind(step.kind)}</div>}
            <h2 style={{ marginTop: stepKind(step.kind).toLowerCase() !== step.label.trim().toLowerCase() ? 6 : 14, fontSize: 28 }}>{step.label}</h2>
            {step.reps && <div style={{ fontSize: 18, fontWeight: 800, marginTop: 6 }}>{step.sets && step.sets > 1 ? `Serija ${step.set}/${step.sets} · ` : ''}{step.reps}</div>}
            {step.target && <div style={{ marginTop: 10 }}><Chip sm on>{step.target}</Chip></div>}
            {logSet && (
              <div className="setlog" role="group" aria-label="Kaj si naredil v tej seriji">
                <div className="setlog-f">
                  <span className="setlog-l">ponovitve</span>
                  <div className="stepper">
                    <button type="button" onClick={() => setSetIn(x => ({ ...x, reps: Math.max(0, (x.reps ?? 1) - 1) }))} aria-label="Ena ponovitev manj">−</button>
                    <b aria-live="polite">{setIn.reps ?? '—'}</b>
                    <button type="button" onClick={() => setSetIn(x => ({ ...x, reps: Math.min(99, (x.reps ?? 0) + 1) }))} aria-label="Ena ponovitev več">+</button>
                  </div>
                </div>
                {weighted && (
                  <div className="setlog-f">
                    <span className="setlog-l">kg</span>
                    <div className="stepper">
                      <button type="button" onClick={() => setSetIn(x => { const v = +x.kg.replace(',', '.') || 0; return { ...x, kg: String(Math.max(0, Math.round((v - kgStep(defNow, v)) * 4) / 4)).replace('.', ',') } })} aria-label="Manj kilogramov">−</button>
                      <input inputMode="decimal" value={setIn.kg} placeholder="—" onChange={e => setSetIn(x => ({ ...x, kg: e.target.value.replace(/[^\d,.]/g, '').slice(0, 6) }))} aria-label="Kilogrami" />
                      <button type="button" onClick={() => setSetIn(x => { const v = +x.kg.replace(',', '.') || 0; return { ...x, kg: String(Math.round((v + kgStep(defNow, v)) * 4) / 4).replace('.', ',') } })} aria-label="Več kilogramov">+</button>
                    </div>
                  </div>
                )}
              </div>
            )}
            {swaps.length > 0 && <button type="button" className="chip sm click" style={{ marginTop: 10 }} onClick={() => setSwapOpen(true)}>Zamenjaj vajo</button>}
            {step.sec ? (
              <div className={`stepring ${step.kind === 'delo' || step.kind === 'test' || step.kind === 'vaja' ? '' : 'easy'}`} style={{ ['--c' as string]: color }}>
                <svg viewBox="0 0 120 120" aria-hidden="true"><circle className="bg" cx="60" cy="60" r="54" /><circle className="fg" cx="60" cy="60" r="54" strokeDasharray={`${(2 * Math.PI * 54 * Math.max(0, Math.min(1, left / step.sec))).toFixed(2)} 400`} /></svg>
                <div className="num" role="timer" aria-live="off" style={{ fontSize: fmtClock(left).length > 5 ? 50 : 66, fontWeight: 800, letterSpacing: '-.04em', lineHeight: 1, color: left <= 5 ? color : 'var(--ink)', fontVariantNumeric: 'tabular-nums' }}>{fmtClock(left)}</div>
              </div>
            ) : logSet ? null : <div className="num" role="timer" aria-live="off" style={{ fontSize: 44, fontWeight: 800, lineHeight: 1, margin: '22px 0 10px' }}>—</div>}
            {step.note && <p style={{ fontSize: 13.5, maxWidth: 340, margin: logSet ? '16px auto 0' : '0 auto' }}>{step.note}</p>}
            {nextStep && <div className="muted" style={{ fontSize: 12.5, marginTop: 16 }}>Sledi: <b style={{ color: 'var(--ink-2)' }}>{nextStep.label}</b>{nextStep.sec ? ` · ${fmtClock(nextStep.sec)}` : ''}</div>}
            <div className="row" style={{ gap: 10, justifyContent: 'center', marginTop: 26 }}>
              <Btn ghost sm onClick={prev} disabled={i === 0}>‹ Nazaj</Btn>
              {step.sec === 0 ? <Btn primary onClick={() => next(true)}>{logSet ? 'Narejeno ›' : 'Naprej ›'}</Btn> : running ? <Btn primary onClick={pause}>Pavza</Btn> : <Btn primary onClick={start}>{elapsed ? 'Nadaljuj' : 'Začni'}</Btn>}
              <Btn ghost sm onClick={() => next()}>Preskoči ›</Btn>
            </div>
            <div className="muted" style={{ fontSize: 12, marginTop: 18 }}>Skupaj {fmtClock(elapsed)} od {fmtClock(total)}{!running ? ' · pavza' : ''}</div>
            <button className="chip sm click run-end" style={{ marginTop: 14 }} onClick={() => void endNow()}>Zaključi</button>
          </div>
        )}
      </main>
      {confirmSheet}
      {swapOpen && exNow && (
        <Sheet open onClose={() => setSwapOpen(false)} label="Zamenjaj vajo">
          <b style={{ display: 'block', fontSize: 17, letterSpacing: '-.02em' }}>Namesto: {exNow.name}</b>
          <p className="muted" style={{ fontSize: 12.5, marginTop: 4 }}>Ista mišična skupina, druga oprema. Velja za preostale serije in za ta dan v načrtu.</p>
          <div className="stack" style={{ gap: 8, marginTop: 12 }}>
            {swaps.map(o => (
              <button key={o.id} type="button" className="opt" onClick={() => swapTo(o.name)}>
                <div style={{ minWidth: 0 }}>{o.name}<small>{o.m.map(m => MUSCLE_LABEL[m]).join(', ')} · {o.how.split('. ')[0]}.</small></div>
              </button>
            ))}
          </div>
          <Btn ghost block style={{ marginTop: 12 }} onClick={() => setSwapOpen(false)}>Prekliči</Btn>
        </Sheet>
      )}
      {early && run && !run.finished && (
        <Sheet open onClose={() => setEarly(false)} label="Zaključim trening">
          <b style={{ display: 'block', fontSize: 17, letterSpacing: '-.02em' }}>Narejeno {Math.round(pct)} % treninga</b>
          <p style={{ fontSize: 13, marginTop: 6, lineHeight: 1.5 }}>{fmtClock(elapsed)} od {fmtClock(total)}. Za opravljeno šteje, ko narediš večji del — {elapsed >= PARTIAL_SAVE_SEC ? 'lahko pa shraniš, kar si naredil.' : 'za zdaj ga raje prekini brez oznake.'}</p>
          <Btn primary block style={{ marginTop: 16 }} onClick={() => setEarly(false)}>Nadaljuj trening</Btn>
          {elapsed >= PARTIAL_SAVE_SEC && <Btn ghost block style={{ marginTop: 9 }} onClick={() => { setEarly(false); void finish() }}>Shrani kot opravljeno ({fmtClock(elapsed)})</Btn>}
          <Btn ghost block style={{ marginTop: 9 }} onClick={stopNoMark}>Prekini brez oznake</Btn>
        </Sheet>
      )}
    </div>
  )
}
