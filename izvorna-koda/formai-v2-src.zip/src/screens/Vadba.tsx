import { useEffect, useMemo, useRef, useState } from 'react'
import { navigate, useRoute } from '@/app/router'
import { useApp, setPlanDone, addActivities, toast } from '@/state/store'
import { stepsFor, totalSec, fmtClock, type Step } from '@/domain/training/workout'
import { deriveFlags } from '@/domain/import/provenance'
import { estimateTss } from '@/domain/training/load'
import { Btn, Chip, kindColor, kindLabel } from '@/ui/primitives'
import { IcoBack, IcoCheck } from '@/ui/icons'

/**
 * Izvajalnik treninga: en korak naenkrat, velik časovnik, kaj sledi, pisk ob menjavi.
 * Zaslon ostane prižgan (Wake Lock). Ob koncu označi dan kot opravljen; moč zapiše kot aktivnost.
 */
export function Vadba() {
  const app = useApp()
  const route = useRoute()
  const day = app.plan.find(d => d.id === route.params.id) || app.plan.find(d => d.date === app.today && d.kind !== 'pocitek') || null
  const steps = useMemo(() => (day ? stepsFor(day, app.profile) : []), [day, app.profile])
  const [i, setI] = useState(0)
  const [left, setLeft] = useState(steps[0]?.sec || 0)
  const [running, setRunning] = useState(false)
  const [elapsed, setElapsed] = useState(0)
  const [finished, setFinished] = useState(false)
  const lock = useRef<{ release: () => Promise<void> } | null>(null)
  const audio = useRef<AudioContext | null>(null)
  const step: Step | undefined = steps[i]
  const total = totalSec(steps)

  useEffect(() => { setLeft(steps[i]?.sec || 0) }, [i, steps])

  // časovnik
  useEffect(() => {
    if (!running || !step) return
    const t = setInterval(() => {
      setElapsed(e => e + 1)
      if (step.sec > 0) setLeft(l => {
        if (l <= 4 && l > 1) beep(880, 0.08)
        if (l <= 1) { beep(1320, 0.25); next(); return 0 }
        return l - 1
      })
    }, 1000)
    return () => clearInterval(t)
  }, [running, step, i])

  // zaslon naj ostane prižgan
  useEffect(() => {
    if (!running) { lock.current?.release().catch(() => undefined); lock.current = null; return }
    const nav = navigator as Navigator & { wakeLock?: { request(t: 'screen'): Promise<{ release: () => Promise<void> }> } }
    nav.wakeLock?.request('screen').then(l => { lock.current = l }).catch(() => undefined)
    return () => { lock.current?.release().catch(() => undefined); lock.current = null }
  }, [running])

  function beep(freq: number, dur: number) {
    try {
      if (!audio.current) audio.current = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)()
      const ctx = audio.current, o = ctx.createOscillator(), g = ctx.createGain()
      o.frequency.value = freq; o.connect(g); g.connect(ctx.destination)
      g.gain.setValueAtTime(0.0001, ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur)
      o.start(); o.stop(ctx.currentTime + dur)
    } catch { /* brez zvoka */ }
  }
  function start() { if (!audio.current) beep(1, 0.001); setRunning(true) }
  function next() { if (i + 1 < steps.length) setI(i + 1); else finish() }
  function prev() { if (i > 0) setI(i - 1) }
  async function finish() {
    setRunning(false); setFinished(true)
    if (!day) return
    await setPlanDone(day.id, true)
    if (day.kind === 'moc') {
      // moč se ne meri z uro — zapišemo jo iz izvajalnika, da šteje v obremenitev
      const now = new Date().toISOString()
      const a = { id: Math.random().toString(36).slice(2, 10) + Date.now().toString(36), source: 'manual' as const, sport: 'moc' as const, date: app.today, start: now, name: day.title, durationMin: Math.max(10, Math.round(elapsed / 60)), tss: null as number | null, polyline: null, exercises: (day.exercises || []).map(e => ({ ...e })), ...deriveFlags('manual'), createdAt: now, updatedAt: now }
      a.tss = estimateTss(a, app.profile)
      await addActivities([a])
    }
    toast(day.kind === 'moc' ? 'Vadba zapisana. Dobro opravljeno. 💪' : 'Označeno kot opravljeno. Vožnjo uvozi z ure ali datoteke, da šteje v formo.', 'ok', 6000)
  }

  if (!day || !steps.length) return (
    <div className="app" style={{ display: 'grid', placeItems: 'center', padding: 24 }}>
      <div className="card" style={{ textAlign: 'center' }}><h3>Danes ni treninga</h3><p style={{ marginTop: 6 }}>Poglej plan ali sestavi teden.</p><Btn primary sm style={{ marginTop: 12 }} onClick={() => navigate('plan')}>Odpri plan</Btn></div>
    </div>
  )

  const color = kindColor(day.kind)
  const pct = total ? Math.min(100, (elapsed / total) * 100) : 0
  const nextStep = steps[i + 1]

  return (
    <div className="app" style={{ background: 'var(--bg-deep)' }}>
      <div className="head">
        <button className="avatar" style={{ background: 'transparent' }} onClick={() => { if (!running || confirm('Prekinem trening?')) navigate('danes') }} aria-label="Nazaj"><IcoBack /></button>
        <div style={{ textAlign: 'center' }}><div className="hi" style={{ color }}>{kindLabel(day.kind).toUpperCase()}</div><div className="nm" style={{ fontSize: 16 }}>{day.title}</div></div>
        <div style={{ width: 38 }} />
      </div>
      <div className="track" style={{ margin: '0 18px' }}><i style={{ width: `${pct}%`, background: color }} /></div>

      <div className="scroll" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', textAlign: 'center', padding: '20px 18px 30px' }}>
        {finished ? (
          <div className="page">
            <div className="check" style={{ width: 72, height: 72, margin: '0 auto' }}><IcoCheck width={34} height={34} /></div>
            <h2 style={{ marginTop: 16 }}>Opravljeno</h2>
            <p style={{ marginTop: 6 }}>{fmtClock(elapsed)} · {steps.length} korakov</p>
            <div className="row" style={{ gap: 8, justifyContent: 'center', marginTop: 20 }}><Btn primary onClick={() => navigate('danes')}>Nazaj na Danes</Btn>{day.kind !== 'moc' && <Btn ghost onClick={() => navigate('uvoz')}>Uvozi vožnjo</Btn>}</div>
          </div>
        ) : step && (
          <div className="page" key={i}>
            <Chip sm>{i + 1} / {steps.length}</Chip>
            <div className="muted" style={{ fontSize: 13, fontWeight: 700, marginTop: 14, letterSpacing: '.06em', textTransform: 'uppercase', color }}>{step.kind === 'delo' ? 'Delo' : step.kind === 'lahko' ? 'Lahko' : step.kind === 'pavza' ? 'Pavza' : step.kind === 'vaja' ? 'Vaja' : step.kind === 'test' ? 'Test' : step.kind === 'ogrevanje' ? 'Ogrevanje' : 'Iztek'}</div>
            <h1 style={{ marginTop: 6, fontSize: 28 }}>{step.label}</h1>
            {step.reps && <div style={{ fontSize: 18, fontWeight: 800, marginTop: 6 }}>{step.sets && step.sets > 1 ? `Serija ${step.set}/${step.sets} · ` : ''}{step.reps}</div>}
            {step.target && <Chip sm on>{step.target}</Chip>}
            <div className="num" style={{ fontSize: step.sec ? 84 : 44, fontWeight: 800, letterSpacing: '-.04em', lineHeight: 1, margin: '22px 0 10px', color: left <= 5 && step.sec ? color : 'var(--ink)' }}>
              {step.sec ? fmtClock(left) : '—'}
            </div>
            {step.note && <p style={{ fontSize: 13.5, maxWidth: 340, margin: '0 auto' }}>{step.note}</p>}
            {nextStep && <div className="muted" style={{ fontSize: 12.5, marginTop: 16 }}>Sledi: <b style={{ color: 'var(--ink-2)' }}>{nextStep.label}</b>{nextStep.sec ? ` · ${fmtClock(nextStep.sec)}` : ''}</div>}
            <div className="row" style={{ gap: 10, justifyContent: 'center', marginTop: 26 }}>
              <Btn ghost sm onClick={prev} disabled={i === 0}>‹ Nazaj</Btn>
              {step.sec === 0 ? <Btn primary onClick={next}>Naprej ›</Btn> : running ? <Btn primary onClick={() => setRunning(false)}>Pavza</Btn> : <Btn primary onClick={start}>{elapsed ? 'Nadaljuj' : 'Začni'}</Btn>}
              <Btn ghost sm onClick={next}>Preskoči ›</Btn>
            </div>
            <div className="muted" style={{ fontSize: 12, marginTop: 18 }}>Skupaj {fmtClock(elapsed)} od {fmtClock(total)}</div>
            <button className="chip sm click" style={{ marginTop: 14 }} onClick={() => { if (confirm('Zaključim trening zdaj?')) finish() }}>Zaključi</button>
          </div>
        )}
      </div>
    </div>
  )
}
