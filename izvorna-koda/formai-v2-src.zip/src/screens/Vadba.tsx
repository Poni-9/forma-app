import { FuelTimeline, drinkLine } from '@/ui/FuelTimeline'
import { lazy, Suspense, useEffect, useMemo, useRef, useState } from 'react'
import { navigate, useRoute } from '@/app/router'
import { useApp, setPlanDone, addActivities, toast, rateSession, savePlanDay, updateProfile, addTest, updatePlanDays } from '@/state/store'
import { isCustom } from '@/domain/focus/model'
import { PROFILE_RANGE } from '@/domain/ranges'
import type { TestSheet } from '@/screens/Napredek'
import { RateRow } from '@/ui/RateRow'
import { stepsFor, totalSec, fmtClock, structureLines, howOf, raceTarget, rescaleHr, type Step } from '@/domain/training/workout'
import { lthrOf } from '@/domain/training/load'
import { exByName, swapOptions, lastDone, repsTopOf, repsLoggedOf, kgStep, dose, MUSCLE_LABEL } from '@/domain/training/exercises'
import { rideFuel, fuelCtxOf } from '@/domain/nutrition/dayplan'
import { RouteCard } from '@/ui/RouteCard'
import { fueling } from '@/domain/nutrition/energy'
import { fmtDur, titleNoDur } from '@/domain/training/load'
import { nextSession } from '@/domain/training/danes'
import { StepsBar, ZONE_C } from '@/ui/StepsBar'
import { powerZones7, workText, noPower, zoneText } from '@/domain/training/zones'
import { deriveFlags } from '@/domain/import/provenance'
import { estimateTss } from '@/domain/training/load'
import type { Activity, PlanDay } from '@/domain/types'
import { Btn, Chip, kindColor, kindInk, Sheet } from '@/ui/primitives'
import { sessLabel, SessIcon } from '@/ui/SessBits'
import { effortOf } from '@/domain/training/effort'
import { HealthNote } from '@/ui/HealthNote'
import { ExerciseFigure } from '@/ui/figure/ExerciseFigure'
import { ExercisePhoto, preloadPhotos } from '@/ui/figure/ExercisePhoto'
import { hasPhoto } from '@/ui/figure/photos'
import { useConfirm } from '@/ui/Confirm'
import { count, dayName, dm, nb, num, plural, unit, plainOH, W, NBSP } from '@/ui/format'
import { plainTerms, firstKgHint } from '@/domain/start'
import { IcoBack, IcoCheck, IcoDrink, IcoTarget } from '@/ui/icons'
import { savedRun, saveRunCopy } from '@/ui/runState'

/**
 * Stanje vadbe. Dan in koraki so ob začetku »zamrznjeni« (sinhronizacija ali ponovno branje načrta med vadbo
 * ne ponastavi časovnika). Čas je iz ure (Date.now()), ne iz štetja intervalov — teče naprej tudi, ko je telefon
 * zaklenjen ali je aplikacija v ozadju. Napredek je v sessionStorage: po osvežitvi strani vadba teče naprej.
 * (v3.49) Ko sistem aplikacijo zapre, ostane kopija v localStorage (ui/runState) — ob vrnitvi »Nadaljuj« od prekinitve.
 */
export interface Run {
  v: 1
  dayId: string
  day: PlanDay
  steps: Step[]
  /** trenutni korak */
  i: number
  /** pretečeni čas (ms) ob začetku trenutnega koraka */
  stepAt: number
  /** pretečeno do zadnjega zagona (ms) */
  acc: number
  /** Date.now() ob zadnjem zagonu; null = pavza */
  runFrom: number | null
  /** minute opomnikov za hrano, ki so že bili */
  cues: number[]
  /** opomnik, ki čaka na konec intervala */
  cue: string | null
  finished: boolean
  /** moč je že zapisana kot aktivnost (samo enkrat) */
  saved: boolean
  /** moč: kaj si naredil v seriji (indeks koraka → kg, ponovitve) */
  log?: Record<number, SetLog>
}
export interface SetLog { kg: number | null; reps: number | null }
/** Opravljene vaje iz vpisanih serij: ponovitve po serijah (»10, 10, 9«), največ kg; brez vpisa ostane načrt. */
export function loggedExercises(r: Pick<Run, 'day' | 'steps' | 'log'>): NonNullable<Activity['exercises']> {
  const logs = r.log || {}
  const any = Object.keys(logs).length > 0
  // z vpisi: samo vaje, ki si jih res delal (predčasen konec ne zapiše neopravljenih); brez vpisov: načrt
  return (r.day.exercises || []).filter(e => !any || r.steps.some((s, k) => s.kind === 'vaja' && s.label === e.name && logs[k])).map(e => {
    const ls = r.steps.map((s, k) => ({ s, k })).filter(x => x.s.kind === 'vaja' && x.s.label === e.name && logs[x.k]).map(x => logs[x.k]!)
    if (!ls.length) return { ...e }
    const kgs = ls.map(l => l.kg).filter((x): x is number => x != null && x > 0)
    const reps = ls.map(l => l.reps).filter((x): x is number => x != null)
    return { ...e, sets: ls.length, reps: reps.length ? reps.join(', ') : e.reps, kg: kgs.length ? Math.max(...kgs) : e.kg ?? null }
  })
}
export const RUN_KEY = 'formai.vadba.v1'
const isWork = (s: Step | undefined) => !!s && (s.kind === 'delo' || s.kind === 'test')
/** (v3.48) opomnik za hrano/pijačo počaka samo med kratkim delom intervala (do 20 min); pri enakomerni vožnji, dolgem
 *  bloku in tekmi (korak brez časovnika) se pokaže takoj — prej 2 h Z2 ni dobila nobenega opomnika do izteka.
 *  (v3.50) Tudi med 20-minutnim testom: gel sredi testa je napačen nasvet in prekine osredotočenost (pokaže se v izteku). */
export const holdCue = (s: Step | undefined): boolean => isWork(s) && (s!.group != null || s!.kind === 'test') && s!.sec > 0 && s!.sec <= 20 * 60
/** (v3.50) moč: serije, ki štejejo za opravljene (vpisane ali na čas in mimo), in vse serije — za »Zaključi« */
export function setsOf(r: Pick<Run, 'steps' | 'i' | 'log'>): { done: number; all: number } {
  const all = r.steps.filter(s => s.kind === 'vaja').length
  const done = r.steps.filter((s, k) => s.kind === 'vaja' && ((k < r.i && s.sec > 0) || !!r.log?.[k])).length
  return { done, all }
}
/** (v3.50) vzorci z lastno težo, kjer dodaš nahrbtnik ali utež (opis seje: »dodaj nahrbtnik in vpiši kilograme«) */
const LOAD_PAT = new Set(['pocep', 'enonozno', 'meca', 'kolk', 'zadnjica'])
/** (v3.50) hribi: kaj vzeti s seboj (voda ~0,5 l na uro, prigrizek na uro) — rideFuel velja samo za kolo */
export function hikeItems(min: number): string[] | null {
  if (!(min >= 60)) return null
  const h = min / 60
  const l = String(Math.max(0.5, Math.round(h * 0.5 * 4) / 4)).replace('.', ',')
  const n = Math.max(1, Math.round(h))
  return [`~${l} l vode`, `${n} × prigrizek (banana, ploščica) — na vsako uro eden`]
}
/** (v3.50) bralnik zaslona ob menjavi koraka: »Korak 2 od 11: Z2 vzdržljivost, 8 minut, utrip 149 do 164« */
export function stepAnnounce(i: number, n: number, s: Step): string {
  const dur = s.sec >= 60 ? `${Math.round(s.sec / 60)} minut` : s.sec > 0 ? `${s.sec} sekund` : ''
  return `Korak ${i + 1} od ${n}: ${s.label}${s.reps ? `, ${s.reps}` : ''}${dur ? `, ${dur}` : ''}${s.target ? `, ${s.target.replace(/–/g, ' do ')}` : ''}`
}
export const elapsedOf = (r: Pick<Run, 'acc' | 'runFrom'>, now: number): number => r.acc + (r.runFrom != null ? Math.max(0, now - r.runFrom) : 0)
/** pod tem deležem »Zaključi« vpraša: nadaljuj / shrani, kar si naredil / prekini brez oznake */
export const EARLY = 0.5
/** shraniti kot opravljeno se da šele po 5 min; obnova po treningu šele po 30 min */
const PARTIAL_SAVE_SEC = 5 * 60, RECOVERY_MIN_SEC = 30 * 60
/** (v3.49) figura kolesarja/tekača se giblje samo prvih 8 s koraka — nato miruje (prej 60 izrisov na s ves čas vožnje) */
export const FIG_PLAY_MS = 8000
function loadRun(): Run | null {
  try { const r = JSON.parse(sessionStorage.getItem(RUN_KEY) || 'null') as Run | null; return r && r.v === 1 && r.day && Array.isArray(r.steps) ? r : null } catch { return null }
}
function storeRun(r: Run | null) {
  try { if (r) sessionStorage.setItem(RUN_KEY, JSON.stringify(r)); else sessionStorage.removeItem(RUN_KEY) } catch { /* brez shrambe */ }
}
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
const STEP_KIND: Record<string, string> = { delo: 'Delo', lahko: 'Lahko', pavza: 'Pavza', vaja: 'Vaja', test: 'Test', ogrevanje: 'Ogrevanje' }
/** Vrsta koraka nad imenom; enakomerna lahka vožnja (Z1/Z2 brez ponovitev) je »Enakomerno«, ne »Delo« (v3.48). */
const stepKind = (s: Step): string => (s.kind === 'delo' && s.sec === 0 ? s.label   // tekma: brez »Delo« nad »Tekma«
  : s.kind === 'delo' && s.group == null && (s.z === 'Z1' || s.z === 'Z2') ? 'Enakomerno' : STEP_KIND[s.kind] ?? 'Iztek')
type Lock ={ release: () => Promise<void>; addEventListener?: (t: 'release', f: () => void) => void }
/** list »Vpiši test« iz Napredka — naložen šele, ko ga odpreš (vodena vadba ne nosi celega Napredka) */
const TestSheetLazy = lazy<typeof TestSheet>(() => import('@/screens/Napredek').then(m => ({ default: m.TestSheet }))
  .catch(() => ({ default: () => <p className="muted" style={{ fontSize: 12.5, marginTop: 8 }}>Rezultat vpiši v Napredek → Vpiši test.</p> })))

/**
 * (v3.49) Po testu FTP rezultat takoj, na zaslonu »Opravljeno«: z merilnikom moč (list »Vpiši test« → FTP in vati),
 * brez merilnika povprečni utrip zadnjih 15 min (pražni utrip → cone). Prej je bil vpis na drugem zaslonu in pozabljen.
 */
export function TestResult() {
  const app = useApp()
  const p = app.profile
  const [open, setOpen] = useState(false)
  const [hr, setHr] = useState('')
  const [saved, setSaved] = useState<number | null>(null)
  const [lo, hi] = PROFILE_RANGE.lthr
  const ftpNow = p.ftp && p.ftpDate === app.today ? p.ftp : null
  async function saveHr() {
    const v = Math.round(+hr.replace(',', '.'))
    if (!(v >= lo && v <= hi)) { toast(`Vpiši utrip med ${lo} in ${hi}.`, 'err'); return }
    const was = lthrOf(p)
    await updateProfile({ lthr: v })
    // (v3.50) tudi kot zapis testa — trend pražnega utripa v Napredku → Testi (prej samo profil, brez zgodovine)
    await addTest({ id: uid(), date: app.today, kind: 'lthr', value: v, unit: 'bpm' })
    // (v3.50) neopravljeni dnevi od danes: utrip v opisu po novem pragu (prej tekma »utrip 184–188« ob novih conah 190)
    const re = app.plan.filter(d => d.date >= app.today && !d.done && d.desc && rescaleHr(d.desc, was, v) !== d.desc).map(d => ({ ...d, desc: rescaleHr(d.desc, was, v) }))
    if (re.length) await updatePlanDays(re)
    setSaved(v)
    toast(`Nov pražni utrip ${v} — cone in utrip v načrtu so posodobljeni.`, 'ok', 6000)
  }
  return (
    <div className="card tight" style={{ textAlign: 'left', marginTop: 16 }}>
      <h2 className="h4" style={{ fontSize: 11 }}>Rezultat testa</h2>
      {noPower(p) ? (saved != null ? <p style={{ fontSize: 13, marginTop: 4, color: 'var(--ink-2)' }}>Nov pražni utrip {saved} — cone in utrip v načrtu so posodobljeni.</p> : (<>
        <p style={{ fontSize: 13, marginTop: 4, color: 'var(--ink-2)' }}>Povprečni utrip zadnjih 15 min je tvoj pražni utrip — iz njega so cone.</p>
        <div className="row" style={{ gap: 8, marginTop: 8, alignItems: 'flex-end' }}>
          <div className="field" style={{ flex: '0 1 150px', margin: 0 }}><label htmlFor="test-hr">Povprečni utrip <span className="unit">zadnjih 15 min</span></label><input id="test-hr" type="number" inputMode="numeric" min={lo} max={hi} value={hr} placeholder={p.lthr ? String(p.lthr) : ''} onChange={e => setHr(e.target.value)} /></div>
          <Btn primary sm onClick={() => void saveHr()}>Shrani</Btn>
        </div>
      {/* (v3.50) kot obvestilo shrambe: vati v načrtu z naslednjim tednom (prej »vati v načrtu so po njem«) */}
      </>)) : ftpNow ? <p style={{ fontSize: 13, marginTop: 4, color: 'var(--ink-2)' }}>FTP {ftpNow}{NBSP}W — v vodeni vadbi takoj, v načrtu od naslednjega tedna.</p> : (<>
        <p style={{ fontSize: 13, marginTop: 4, color: 'var(--ink-2)' }}>Povprečna moč 20 minut → nov FTP in vati v načrtu.</p>
        <Btn primary sm style={{ marginTop: 8 }} onClick={() => setOpen(true)}>Vpiši rezultat</Btn>
      </>)}
      {open && <Suspense fallback={null}><TestSheetLazy open onClose={() => setOpen(false)} custom={isCustom(p)} strength={false} /></Suspense>}
    </div>
  )
}

/**
 * Izvajalnik treninga — te pelje skozi cel trening:
 * pred začetkom pregled (kaj te čaka, vati, kaj vzeti s seboj, kaj pojesti), med treningom en korak naenkrat
 * z vati, občutkom (RPE) in kadenco, pisk ob menjavi, opomnik za hrano in pijačo; po koncu obnova in kaj sledi.
 * Zaslon ostane prižgan (Wake Lock). Ob koncu označi dan kot opravljen; moč zapiše kot aktivnost.
 */
export function Vadba() {
  const app = useApp()
  const route = useRoute()
  const { confirm, sheet: confirmSheet } = useConfirm()
  // »Zaključi« pod polovico (true) ali »Zapusti vadbo« po 5 min ('leave', v3.49)
  const [early, setEarly] = useState<boolean | 'leave'>(false)
  // shranjena vadba (osvežitev strani) za ta dan — ali za katerikoli dan, če id ni podan
  const [run, setRunState] = useState<Run | null>(() => { const r = loadRun(); return r && (!route.params.id || r.dayId === route.params.id) ? r : null })
  const runRef = useRef<Run | null>(run)
  const setRun = (r: Run | null) => { runRef.current = r; storeRun(r); setRunState(r); if (!r || r.finished) saveRunCopy(null) }
  // (v3.49) prekinjena vadba (sistem je zaprl aplikacijo): kopija iz localStorage, ponudimo nadaljevanje
  const [saved, setSaved] = useState(() => { const s = run ? null : savedRun<Run>(); return s && (!route.params.id || s.dayId === route.params.id) && Array.isArray(s.steps) ? s : null })
  const [now, setNow] = useState(() => Date.now())
  // (v3.49) izris 1× na sekundo (prikazana sekunda), ne ob vsakem tiku (250 ms) — časovnik in pisk ostaneta natančna
  const shownSec = useRef(-1)
  const [fuelMsg, setFuelMsg] = useState<string | null>(null)
  // moč: vpis serije (kg in ponovitve) in zamenjava vaje
  const [setIn, setSetIn] = useState<{ kg: string; reps: number | null }>({ kg: '', reps: null })
  const [swapOpen, setSwapOpen] = useState(false)
  // (v3.50) povezava na vadbo, ki je ni več v načrtu (stara povezava, sestavljen nov teden): ne odpre tiho drugega treninga
  const todays = app.plan.find(d => d.date === app.today && d.kind !== 'pocitek') || null
  const liveDay = (route.params.id ? app.plan.find(d => d.id === route.params.id) : todays) || null
  const day = run ? run.day : liveDay
  const liveSteps = useMemo(() => (liveDay ? stepsFor(liveDay, app.profile) : []), [liveDay, app.profile])
  const steps = run ? run.steps : liveSteps
  const fuel = useMemo(() => (day ? rideFuel(day, app.profile.fuelKit, fuelCtxOf(app.weather, app.recentMeals, day.date, app.today)) : null), [day, app.profile.fuelKit, app.weather, app.recentMeals, app.today])
  const z2 = powerZones7(app.profile)?.find(z => z.key === 'Z2')
  const food = useMemo(() => (day ? fueling(day, app.profile) : null), [day, app.profile])
  // (v3.50) najprej še neopravljena seja istega dne (po kolesu še moč), šele nato naslednji dan (A34)
  const upNext = day ? nextSession(app.plan, day) : null
  const nextDay = upNext?.day
  const audio = useRef<AudioContext | null>(null)
  const lock = useRef<Lock | null>(null)
  const lastBeep = useRef('')
  const cueTimer = useRef<number | null>(null)
  const fuelRef = useRef(fuel)
  fuelRef.current = fuel

  function beep(freq: number, dur: number) {
    try {
      if (!audio.current) audio.current = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)()
      const ctx = audio.current
      if (ctx.state === 'suspended') void ctx.resume().catch(() => undefined)
      const o = ctx.createOscillator(), g = ctx.createGain()
      o.frequency.value = freq; o.connect(g); g.connect(ctx.destination)
      g.gain.setValueAtTime(0.0001, ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur)
      o.start(); o.stop(ctx.currentTime + dur)
    } catch { /* brez zvoka */ }
  }
  function showCue(text: string) {
    setFuelMsg(plainOH(text)); beep(660, 0.12); setTimeout(() => beep(990, 0.12), 180)
    try { navigator.vibrate?.([120, 80, 120]) } catch { /* brez vibracije */ }
    if (cueTimer.current) clearTimeout(cueTimer.current)
    cueTimer.current = window.setTimeout(() => setFuelMsg(null), 45_000)
  }
  /** Premik na korak `to` (ali konec), ob pretečenem času `at`. Stranski učinki (pisk, opomnik) so zunaj posodobitve stanja. */
  function moveTo(r: Run, to: number, at: number, sound = true) {
    if (to >= r.steps.length) {
      // »Preskoči« čez zadnji korak na hitro ni opravljen trening — isto vprašanje kot pri »Zaključi«
      const all = totalSec(r.steps) * 1000
      if (!sound && r.day.kind !== 'moc' && all > 0 && at < all * EARLY) { setEarly(true); return }
      // (v3.50) moč: pod polovico serij isti list (prej je 20 s »vadbe« zapisalo 10 min)
      if (!sound && r.day.kind === 'moc') { const q = setsOf(r); if (q.all > 0 && q.done < q.all * EARLY) { setEarly(true); return } }
      void finish(at); return
    }
    let next: Run = { ...r, i: Math.max(0, to), stepAt: at }
    if (next.cue && !holdCue(next.steps[next.i])) { const c = next.cue; next = { ...next, cue: null }; setRun(next); showCue(c) }
    else setRun(next)
    if (sound) beep(1320, 0.25)
  }

  // časovnik: vsake 250 ms iz ure; ob vrnitvi iz ozadja ujame vse korake, ki so medtem minili
  useEffect(() => {
    if (!run || run.runFrom == null || run.finished) return
    const tick = () => {
      let r: Run | null = runRef.current
      if (!r || r.runFrom == null || r.finished) return
      const t = Date.now(), el = elapsedOf(r, t)
      let moved = 0
      for (;;) {
        const st = r.steps[r.i]
        if (!st || st.sec <= 0) break
        const end: number = r.stepAt + st.sec * 1000
        if (el < end) break
        // (v3.49) konec v ozadju: shrani zadnji korak (prej »1 od 4 korakov« po zaklenjenem telefonu)
        if (r.i + 1 >= r.steps.length) { beep(1320, 0.25); void finish(end, r.i); return }
        r = { ...r, i: r.i + 1, stepAt: end }; moved++
      }
      // hrana in pijača po časovnici goriva; med delom počaka na odmor
      const f = fuelRef.current
      const due = f?.cues.filter(c => c.atMin * 60_000 <= el && !r!.cues.includes(c.atMin)) || []
      let show: string | null = null
      if (due.length) {
        const text = due[due.length - 1]!.text
        r = { ...r, cues: [...r.cues, ...due.map(c => c.atMin)] }
        if (holdCue(r.steps[r.i])) r = { ...r, cue: text }; else show = text
      }
      if (r.cue && !holdCue(r.steps[r.i])) { show = r.cue; r = { ...r, cue: null } }
      if (r !== runRef.current) setRun(r)
      if (moved) beep(1320, 0.25)
      if (show) showCue(show)
      // pisk 3, 2, 1 s pred koncem koraka (vsak samo enkrat)
      const st = r.steps[r.i]
      if (st && st.sec > 0) {
        const left = Math.ceil((r.stepAt + st.sec * 1000 - el) / 1000), key = `${r.i}:${left}`
        if (left >= 1 && left <= 3 && lastBeep.current !== key) { lastBeep.current = key; beep(880, 0.08) }
      }
      const sec = Math.floor(el / 1000)
      if (sec !== shownSec.current) { shownSec.current = sec; setNow(t) }
    }
    tick()
    const h = window.setInterval(tick, 250)
    return () => clearInterval(h)
  }, [run?.runFrom, run?.finished])   // eslint-disable-line react-hooks/exhaustive-deps

  // zaslon naj ostane prižgan; brskalnik zaklep sprosti, ko gre stran v ozadje — ob vrnitvi ga zahtevamo znova
  const wantLock = !!run && run.runFrom != null && !run.finished
  useEffect(() => {
    if (!wantLock) return
    const nav = navigator as Navigator & { wakeLock?: { request(t: 'screen'): Promise<Lock> } }
    const request = () => {
      if (document.visibilityState !== 'visible' || lock.current || !nav.wakeLock) return
      nav.wakeLock.request('screen').then(l => { lock.current = l; l.addEventListener?.('release', () => { if (lock.current === l) lock.current = null }) }).catch(() => undefined)
    }
    request()
    const onVis = () => { if (document.visibilityState === 'visible') { request(); setNow(Date.now()) } }
    document.addEventListener('visibilitychange', onVis)
    return () => { document.removeEventListener('visibilitychange', onVis); lock.current?.release().catch(() => undefined); lock.current = null }
  }, [wantLock])

  // (v3.49) prekinjena vadba za dan, ki je medtem opravljen (ura, druga naprava): kopija ne velja več
  const savedDone = !!saved && !!app.plan.find(d => d.id === saved.dayId)?.done
  useEffect(() => { if (savedDone) { saveRunCopy(null); setSaved(null) } }, [savedDone])

  // ob odhodu z zaslona: zvok zapri, opomnik počisti
  useEffect(() => () => {
    if (cueTimer.current) clearTimeout(cueTimer.current)
    void audio.current?.close().catch(() => undefined); audio.current = null
  }, [])

  // vpis serije: ob prihodu na serijo predlagaj kg in ponovitve (prejšnja serija te vaje, načrt, zadnja vadba)
  const runI = run?.i ?? -1, runDay = run?.dayId ?? '', runLabel = run ? run.steps[run.i]?.label ?? '' : ''
  useEffect(() => {
    const r = runRef.current
    const st = r?.steps[r.i]
    if (!r || !st || st.kind !== 'vaja' || r.day.kind !== 'moc') return
    const e = (r.day.exercises || []).find(x => x.name === st.label)
    const own = r.log?.[r.i]
    const prevK = Object.keys(r.log || {}).map(Number).filter(k => k < r.i && r.steps[k]?.label === st.label).sort((a, b) => b - a)[0]
    const prev = own ?? (prevK != null ? r.log![prevK] : null)
    const last = !prev ? lastDone(st.label, app.activities) : null
    const kg = prev?.kg ?? e?.kg ?? last?.kg ?? null
    // (v3.50) ponovitve: prejšnja serija te vaje, sicer zadnja vadba; brez zgodovine prazno (»—«) — prej zgornja meja načrta,
    // zato je »Narejeno« brez dotika zapisalo 12, 12, 12 in sprožilo napredovanje
    setSetIn({ kg: kg != null ? String(kg).replace('.', ',') : '', reps: prev?.reps ?? (last ? repsLoggedOf(last.reps) : null) })
  }, [runI, runDay, runLabel])   // eslint-disable-line react-hooks/exhaustive-deps

  /** Zamenjava vaje (naprava zasedena, ne ustreza): preostale serije te vaje in dan v načrtu. */
  function swapTo(name: string) {
    const r = runRef.current
    const st = r?.steps[r.i]
    if (!r || !st) return
    const old = st.label, d = exByName(name)
    const ds = d ? dose(d, f?.aims ?? [], f?.level ?? 2) : null
    const steps2 = r.steps.map((x, k) => (k >= r.i && x.kind === 'vaja' && x.label === old
      ? { ...x, label: name, reps: ds?.reps ?? (x.reps || '').replace(/ · [\d,.]+ kg$/, ''), sec: d?.time ? +(/(\d+)\s*s\b/.exec(ds?.reps || '')?.[1] ?? 30) : 0, note: `${howOf(name)} ${d?.time ? '' : 'Ko končaš serijo, tapni naprej.'}`.trim() }
      : x))
    // že narejene serije stare vaje ostanejo zapisane pod njenim imenom, preostale gredo novi
    const doneSets = Object.keys(r.log || {}).filter(k => +k < r.i && r.steps[+k]?.label === old).length
    const day2 = { ...r.day, exercises: (r.day.exercises || []).flatMap(e => (e.name === old
      ? [...(doneSets ? [{ ...e, sets: doneSets }] : []), { ...e, name, sets: Math.max(1, e.sets - doneSets), reps: ds?.reps ?? e.reps, kg: null, rest: ds?.rest ?? e.rest ?? null }]
      : [e])) }
    setRun({ ...r, steps: steps2, day: day2 })
    setSwapOpen(false)
    // dan v načrtu dobi novo vajo (Danes, Plan in zapis vadbe se ujemajo)
    const live = app.plan.find(x => x.id === r.dayId)
    if (live && !live.done) void savePlanDay({ ...live, exercises: day2.exercises })
    toast(`Zamenjano: ${name}.`, 'ok')
  }

  function start() {
    if (!audio.current) beep(1, 0.001)   // odklene zvok v dotiku (iOS)
    const r = runRef.current
    if (r) { if (r.runFrom == null && !r.finished) setRun({ ...r, runFrom: Date.now() }); return }
    if (!day || !steps.length) return
    const t = Date.now()
    setRun({ v: 1, dayId: day.id, day, steps, i: 0, stepAt: 0, acc: 0, runFrom: t, cues: [], cue: null, finished: false, saved: false })
    setNow(t)
    // nova vadba: stara kopija (prekinjena) ne velja več
    if (saved) { saveRunCopy(null); setSaved(null) }
  }
  /** (v3.49) prekinjena vadba: čas do prekinitve (zadnja kopija), čas zaprte aplikacije ne šteje (kot pavza) */
  const savedAtSec = saved ? Math.floor(elapsedOf(saved, saved.savedAt) / 1000) : 0
  function fromSaved(running: boolean): Run | null {
    if (!saved) return null
    const { savedAt, ...r } = saved
    const t = Date.now()
    setSaved(null)
    return { ...r, acc: elapsedOf(r, savedAt), runFrom: running ? t : null, cue: null }
  }
  function resumeSaved() {
    if (!audio.current) beep(1, 0.001)   // odklene zvok v dotiku (iOS)
    const r = fromSaved(true)
    if (r) { setRun(r); setNow(Date.now()) }
  }
  async function finishSaved() {
    const r = fromSaved(false)
    if (!r) return
    setRun(r)
    await finish(r.acc)
  }
  function dropSaved() { saveRunCopy(null); setSaved(null) }
  function pause() { const r = runRef.current; if (!r || r.runFrom == null) return; const t = Date.now(); setRun({ ...r, acc: elapsedOf(r, t), runFrom: null }); setNow(t) }
  /** Naprej: pri seriji moči shrani vpis (kg, ponovitve); Preskoči (log = false) serije ne zapiše. */
  function next(log = false) {
    let r = runRef.current
    if (!r) return
    const st = r.steps[r.i]
    if (log && st && st.kind === 'vaja' && st.sec === 0 && r.day.kind === 'moc') {
      const v = setIn.kg.trim() ? +setIn.kg.replace(',', '.') : NaN
      r = { ...r, log: { ...(r.log || {}), [r.i]: { kg: Number.isFinite(v) && v > 0 ? Math.round(v * 4) / 4 : null, reps: setIn.reps } } }
      setRun(r)
    }
    moveTo(r, r.i + 1, elapsedOf(r, Date.now()), false)
  }
  function prev() { const r = runRef.current; if (r && r.i > 0) moveTo(r, r.i - 1, elapsedOf(r, Date.now()), false) }
  async function finish(at?: number, atStep?: number) {
    const r = runRef.current
    if (!r || r.finished) return
    const el = at ?? elapsedOf(r, Date.now())
    const done: Run = { ...r, finished: true, acc: el, runFrom: null, i: Math.min(atStep ?? r.i, r.steps.length - 1) }
    setRun(done); setNow(Date.now())
    // dejanski čas (min): delno shranjena vožnja šteje toliko, kolikor si vozil, ne cel plan (v3.48)
    const min = Math.max(1, Math.round(el / 60_000))
    if (r.day.kind === 'moc' && !r.saved) {
      setRun({ ...done, saved: true })
      // moč se ne meri z uro — zapišemo jo iz izvajalnika, da šteje v obremenitev (samo enkrat)
      const t = new Date().toISOString()
      // (v3.49) datum = dan načrta (kopija z včeraj, konec čez polnoč): vadba pod pravim dnem, kot zapis iz načrta; prihodnji dan → danes
      const date = r.day.date < app.today ? r.day.date : app.today
      // (v3.50) trajanje = dejanski čas (prej najmanj 10 min: 20 s je štelo kot 10 min v teden in formo)
      const a: Activity = { id: uid(), source: 'manual', sport: 'moc', date, start: t, name: r.day.title, durationMin: min, tss: null, polyline: null, exercises: loggedExercises(r), ...deriveFlags('manual'), createdAt: t, updatedAt: t }
      a.tss = estimateTss(a, app.profile)
      // (v3.49) dan kaže na ta zapis (z vajami) — brez dodatnega zapisa iz načrta
      await setPlanDone(r.day.id, true, a.id, min)
      await addActivities([a])
    } else {
      // (v3.49) kolo, tek, hoja: brez povezane vožnje nastane zapis iz načrta z dejanskimi minutami (forma, ure, Napredek)
      await setPlanDone(r.day.id, true, null, min)
    }
    // kolo: zaslon »Opravljeno« že pove, kako pride vožnja — brez ponovitve v obvestilu
    if (r.day.kind === 'moc') toast('Vadba zapisana med aktivnosti.', 'ok', 4000)
  }
  async function leave() {
    const r = runRef.current
    if (r && !r.finished && r.runFrom != null) {
      // (v3.49) po 5 min isti list kot »Zaključi«: nadaljuj, shrani, kar si naredil, ali prekini brez oznake
      if (elapsedOf(r, Date.now()) >= PARTIAL_SAVE_SEC * 1000) { setEarly('leave'); return }
      if (!(await confirm({ title: 'Prekinem trening?', text: 'Napredek tega treninga se ne shrani. Dan ostane neoznačen.', ok: 'Prekini', cancel: 'Nadaljuj trening' }))) return
      setRun(null)
    } else if (r?.finished) setRun(null)
    navigate('danes')
  }
  async function endNow() {
    const r = runRef.current
    if (!r) return
    const done = elapsedOf(r, Date.now()), all = totalSec(r.steps) * 1000
    const open = r.steps.some(x => x.sec === 0 && x.kind === 'delo')
    // (v3.50) tekma: brez deleža (ogrevanje ni trening, prej »Narejeno 0 % treninga — 0:04 od 25:00«) — čas tekme v vprašanju
    if (open) {
      const st = r.steps[r.i]
      const raceSec = st && st.sec === 0 && st.kind === 'delo' ? Math.max(0, Math.floor((done - r.stepAt) / 1000)) : null
      if (await confirm({ title: raceSec != null ? 'Zaključim tekmo?' : 'Zaključim trening zdaj?', text: raceSec != null ? `Tekma je trajala ${fmtClock(raceSec, raceSec >= 3600)}. Dan se označi kot opravljen.` : `Dan se označi kot opravljen (${fmtDur(Math.max(1, Math.round(done / 60_000)))}).`, ok: 'Zaključi' })) void finish()
      return
    }
    // (v3.50) moč: serije, ne minute (prej »1 min od 25 min« iz časovnikov) — pod polovico serij isti list kot pri kolesu
    if (r.day.kind === 'moc') {
      const q = setsOf(r)
      if (q.all > 0 && q.done < q.all * EARLY) { setEarly(true); return }
      if (await confirm({ title: 'Zaključim trening zdaj?', text: `Dan se označi kot opravljen (${q.done} od ${q.all} serij).`, ok: 'Zaključi' })) void finish()
      return
    }
    // pod polovico: ne označi kar tako — 2 s »treninga« ni opravljen trening
    if (all > 0 && done < all * EARLY) { setEarly(true); return }
    // (v3.48) »… (10 min od 1 h 15 min)« — šteje čas do zdaj
    const minNow = fmtDur(Math.max(1, Math.round(done / 60_000)))
    if (await confirm({ title: 'Zaključim trening zdaj?', text: `Dan se označi kot opravljen (${minNow} od ${fmtDur(Math.round(all / 60_000))}).`, ok: 'Zaključi' })) void finish()
  }
  function stopNoMark() { setEarly(false); setRun(null); navigate('danes'); toast('Trening prekinjen — dan ostane neoznačen.', 'info') }
  const exit = (to: 'danes' | 'uvoz') => { setRun(null); navigate(to) }

  // fotografije naslednjih vaj vnaprej — hook mora biti pred pogojnim return (prej za njim: ko je dan izginil iz načrta,
  // »Rendered fewer hooks« in prazen zaslon) (v3.48)
  const iNow = run ? run.i : 0
  const nextVaje = day?.kind === 'moc' ? [steps[iNow + 1], steps[iNow + 2]].filter((x): x is Step => !!x && x.kind === 'vaja').map(x => x.label) : []
  useEffect(() => { for (const l of nextVaje) preloadPhotos(exByName(l)?.id) }, [nextVaje.join('|')])  // eslint-disable-line react-hooks/exhaustive-deps
  // (v3.50) namizje (trenažer ob računalniku): presledek = gumb na sredini (pavza, nadaljuj, narejeno), → naprej, ← prejšnji;
  // ne med tipkanjem v polje in ne ob odprtem listu. Vsak izris znova (sveži vpis serije).
  useEffect(() => {
    const on = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null
      if (e.altKey || e.ctrlKey || e.metaKey || (t && (/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName) || t.isContentEditable)) || document.querySelector('.sheet')) return
      const r = runRef.current, st = r?.steps[r.i]
      if (!r || r.finished || !st) return
      const openSt = st.sec === 0 && st.kind === 'delo'
      if (e.key === ' ') { e.preventDefault(); if (st.sec === 0 && !openSt) next(true); else if (r.runFrom != null) pause(); else start() }
      else if (e.key === 'ArrowRight' && !openSt) { e.preventDefault(); next() }
      else if (e.key === 'ArrowLeft') { e.preventDefault(); prev() }
    }
    window.addEventListener('keydown', on)
    return () => window.removeEventListener('keydown', on)
  })

  if (!day || !steps.length) {
    const gone = !day && !!route.params.id
    return (
      <div className="app" style={{ display: 'grid', placeItems: 'center', padding: 24 }}>
        <div className="card" style={{ textAlign: 'center' }}>
          <h1 style={{ fontSize: 16 }}>{gone ? 'Te vadbe ni več v načrtu' : 'Danes ni treninga'}</h1>
          <p style={{ marginTop: 6 }}>{gone ? 'Načrt se je medtem spremenil.' : 'Poglej plan ali sestavi teden.'}</p>
          <div className="row" style={{ gap: 8, marginTop: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
            {gone && todays && <Btn primary sm onClick={() => navigate('vadba', { id: todays.id }, { replace: true })}>Današnji trening</Btn>}
            <Btn primary={!(gone && todays)} ghost={gone && !!todays} sm onClick={() => navigate('plan')}>Odpri plan</Btn>
          </div>
        </div>
      </div>
    )
  }

  const color = kindColor(day.kind)
  const total = totalSec(steps)
  const el = run ? elapsedOf(run, now) : 0
  const elapsed = Math.floor(el / 1000)
  const i = run ? run.i : 0
  const step: Step | undefined = steps[i]
  const left = step && step.sec > 0 ? Math.max(0, step.sec - Math.floor((el - (run?.stepAt ?? 0)) / 1000)) : 0
  const running = !!run && run.runFrom != null && !run.finished
  // korak brez časovnika pri kardiu (tekma): štoparica do »Zaključi«, brez »od …« (v3.48)
  const open = !!step && step.sec === 0 && step.kind === 'delo'
  const hasOpen = steps.some(s => s.sec === 0 && s.kind === 'delo')
  // »od …« in vrstica napredka po »Preskoči«: začetek trenutnega koraka + preostali koraki (prej vedno celoten plan) (v3.48)
  const planned = run && !run.finished ? Math.round(run.stepAt / 1000) + totalSec(steps.slice(i)) : total
  const pct = hasOpen && open ? 100 : planned ? Math.min(100, (elapsed / planned) * 100) : 0
  const pctAll = total ? Math.min(100, (elapsed / total) * 100) : 0
  const long = Math.max(planned, total, elapsed) >= 3600
  const ringC = step?.z ? ZONE_C[step.z] ?? color : color
  const nextStep = steps[i + 1]
  // moč: serija, ki jo vpišeš (kg, ponovitve), in možne zamenjave vaje (ista skupina, druga oprema)
  const exNow = step && step.kind === 'vaja' && day.kind === 'moc' ? (day.exercises || []).find(e => e.name === step.label) ?? null : null
  const defNow = exNow ? exByName(exNow.name) : undefined
  const logSet = !!run && !run.finished && !!exNow && step!.sec === 0
  // figura: med vajo vaja sama; v pavzi naslednja vaja (predogled); pri kardiu tek/kolo/hoja
  const nextEx = nextStep && nextStep.kind === 'vaja' && day.kind === 'moc' ? exByName(nextStep.label) : undefined
  const figId = step && step.kind === 'vaja' ? defNow?.id ?? null : step && step.kind === 'pavza' ? nextEx?.id ?? null : null
  // (v3.49) tek in hoja: v koraku hoje figura hodi (prej je tekla tudi med hojo)
  const cardioFig = step && (step.kind === 'delo' || step.kind === 'lahko' || step.kind === 'ogrevanje' || step.kind === 'test') && day.kind !== 'moc' ? (day.kind === 'kolo' ? 'kolo' as const : day.kind === 'pohod' || /hoj/i.test(`${step.label} ${step.target ?? ''}`) ? 'hoja' as const : 'tek' as const) : null
  const loaded = !!exNow && (exNow.kg != null || !!defNow?.kg || defNow?.eq === 'fitnes')
  // (v3.50) noge z lastno težo (bolgarski, izpadni, prsti …): kg neobvezno — nahrbtnik ali utež, kot piše opis seje
  const weighted = loaded || (!!defNow && !defNow.time && LOAD_PAT.has(defNow.pat))
  const repsLo = exNow ? +(/(\d+)/.exec(exNow.reps)?.[1] ?? 10) : 10
  const sq = run ? setsOf(run) : { done: 0, all: 0 }
  const f = app.profile.focus
  const swapCtx = { where: (f ? /^Doma/.test(day.title) : app.profile.strength.equipment !== 'gym') ? 'doma' as const : 'fitnes' as const, equip: f?.equipment ?? [...(app.profile.gear.dumbbells ? ['utezi' as const] : []), ...(app.profile.gear.pullupBar ? ['drog' as const] : [])], level: f?.level ?? 2, limits: f?.limits ?? null }
  const swaps = exNow && run && !run.finished ? swapOptions(exNow.name, swapCtx, (day.exercises || []).map(e => e.name)) : []
  // (v3.49) figura se giblje prvih 8 s koraka, nato miruje — baterija in toplota telefona med 2–4 h vožnje
  const figPlay = running && el - (run?.stepAt ?? 0) < FIG_PLAY_MS
  // (v3.49) prekinjena vadba se ponudi samo, če dan še obstaja in ni opravljen
  const savedLive = saved ? app.plan.find(d => d.id === saved.dayId) : null
  const resumable = !run && !!saved && !!savedLive && !savedLive.done
  // (v3.49) kronometer: cilj dela je glavni del tempa (»nato pri utripu 184–188«), ne splošni prag
  const ttT = day.role === 'dirka' ? raceTarget(day.desc, app.profile) : null

  return (
    <div className="app" style={{ background: 'var(--bg-deep)' }}>
      <header className="head">
        <button className="avatar" style={{ background: 'transparent' }} onClick={() => void leave()} aria-label="Zapusti vadbo"><IcoBack /></button>
        <div style={{ textAlign: 'center', minWidth: 0 }}><div className="hi" style={{ color: kindInk(day.kind) }}>{sessLabel(day).toUpperCase()}</div><h1 className="nm" style={{ fontSize: 16, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{titleNoDur(day.title, day.durationMin)}</h1></div>
        <div style={{ width: 38, flex: 'none' }} />
      </header>
      <div className="track run-track" style={{ margin: '0 18px' }}><i style={{ width: `${pct}%`, background: color }} /></div>

      <main className="scroll run-main" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', textAlign: 'center', padding: '20px 18px 30px' }}>
        {/* (v3.50) menjava koraka za bralnik zaslona (časovnik je namenoma brez branja) */}
        <div className="sr-only" role="status" aria-live="polite">{run && !run.finished && step ? stepAnnounce(i, steps.length, step) : ''}</div>
        {run?.finished ? (
          <div className="page">
            <div className="check" style={{ width: 72, height: 72, margin: '0 auto' }}><IcoCheck width={34} height={34} /></div>
            <h2 style={{ marginTop: 16 }}>Opravljeno</h2>
            {/* delno: »5 od 10 korakov« (prej »10 korakov« tudi, ko si končal pri petem) (v3.48) */}
            <p style={{ marginTop: 6 }}>{fmtClock(elapsed)} · {i + 1 < steps.length ? `${i + 1} od ${steps.length} korakov` : count(steps.length, W.korak)}</p>
            {(() => {
              const live = app.plan.find(d => d.id === day.id)
              const act = live?.done?.activityId ? app.activities.find(a => a.id === live.done!.activityId) : null
              return <div className="card tight" style={{ textAlign: 'left', marginTop: 16 }}><RateRow label="Kako je šlo?" value={act?.rpe ?? live?.rpe ?? null} onPick={v => void rateSession({ activityId: act?.id ?? null, dayId: day.id }, v)} /></div>
            })()}
            {day.kind === 'test' && <TestResult />}
            {day.kind === 'moc' && run.log && Object.keys(run.log).length > 0 && (
              <div className="card tight" style={{ textAlign: 'left', marginTop: 16 }}>
                <h2 className="h4" style={{ fontSize: 11 }}>Tvoje serije</h2>
                {loggedExercises(run).filter(e => Object.keys(run.log!).some(k => run.steps[+k]?.label === e.name)).map(e => {
                  const plan0 = (run.day.exercises || []).find(x => x.name === e.name)
                  const top = plan0 ? repsTopOf(plan0.reps) : null
                  const all = String(e.reps).split(',').map(x => +x.trim()).filter(x => Number.isFinite(x))
                  const up = !!e.kg && top != null && all.length > 0 && all.every(x => x >= top)
                  return <div key={e.name} className="between" style={{ fontSize: 13, padding: '5px 0', borderTop: '1px solid var(--line-soft)', gap: 10 }}><span style={{ fontWeight: 600, color: 'var(--ink)', minWidth: 0 }}>{e.name}</span><span style={{ flex: 'none', textAlign: 'right' }}><span className="muted">{e.reps}{e.kg ? ` · ${unit(num(e.kg), 'kg')}` : ''}</span>{up ? <b style={{ display: 'block', fontSize: 11.5, color: 'var(--ok)' }}>naslednjič več kg</b> : null}</span></div>
                })}
              </div>
            )}
            {food && elapsed >= RECOVERY_MIN_SEC && <div className="card tight" style={{ textAlign: 'left', marginTop: 16 }}><h2 className="h4" style={{ fontSize: 11 }}>Zdaj — obnova</h2><p style={{ fontSize: 13, marginTop: 4, color: 'var(--ink-2)' }}>{nb(plainOH(food.after))}</p></div>}
            {/* »pride iz Garmina« samo s povezavo intervals.icu; sicer uvoz datoteke (v3.48) */}
            {day.kind !== 'moc' && (() => {
              // (v3.49) brez ure je vadba zapisana iz načrta z dejanskimi minutami; vožnja z ure jo zamenja
              const rec = app.activities.find(a => a.planDayId === day.id)
              const bike = day.kind === 'kolo' || day.kind === 'test'
              const t = rec
                ? `Zapisano kot vadba iz načrta (${fmtDur(rec.durationMin)}) — šteje v teden in formo. ${app.settings.intervals ? `${bike ? 'Vožnja' : 'Vadba'} pride iz Garmina (intervals.icu) sama in ta zapis zamenja.` : `${bike ? 'Vožnjo' : 'Vadbo'} z ure uvozi kot datoteko (.fit, .gpx) — zamenja ta zapis.`}`
                : app.settings.intervals ? 'Vožnja pride iz Garmina (intervals.icu) sama in se poveže s tem dnem. Brez ure jo uvozi kot datoteko.' : 'Vožnjo z ure ali kolesarskega računalnika uvozi kot datoteko (.fit, .gpx) — tako šteje v formo.'
              return <p className="muted" style={{ fontSize: 12.5, marginTop: 10 }}>{t}</p>
            })()}
            {nextDay && (upNext!.sameDay
              ? <p style={{ fontSize: 13, marginTop: 10 }}>Danes še: <b style={{ color: 'var(--ink)' }}>{nextDay.title}</b>{nextDay.durationMin ? ` · ${fmtDur(nextDay.durationMin)}` : ''}</p>
              : <p style={{ fontSize: 13, marginTop: 10 }}>Naslednji: <b style={{ color: 'var(--ink)' }}>{nextDay.title}</b> · {dayName(nextDay.date)}, {dm(nextDay.date)}</p>)}
            {/* (v3.50) z intervals.icu vožnja pride sama — ne »Uvozi vožnjo« (A41); brez povezave »Uvozi datoteko« */}
            <div className="row" style={{ gap: 8, justifyContent: 'center', marginTop: 20, flexWrap: 'wrap' }}><Btn primary onClick={() => exit('danes')}>Nazaj na Danes</Btn>{upNext?.sameDay && <Btn ghost onClick={() => { setRun(null); navigate('vadba', { id: upNext.day.id }) }}>Začni{upNext.day.kind === 'moc' ? ' moč' : ''}</Btn>}{day.kind !== 'moc' && !app.settings.intervals && <Btn ghost onClick={() => exit('uvoz')}>Uvozi datoteko</Btn>}</div>
          </div>
        ) : !run ? (
          <div className="page" style={{ textAlign: 'left', maxWidth: 520, margin: '0 auto', width: '100%' }}>
            {/* (v3.49) sistem je zaprl aplikacijo med vadbo: nadaljuj od prekinitve, shrani, kar si naredil, ali zavrzi */}
            {resumable && saved && (
              <div className="card tight run-resume" role="region" aria-label="Prekinjena vadba">
                <b>Vadba je bila prekinjena pri {fmtClock(savedAtSec, savedAtSec >= 3600)} (korak {Math.min(saved.i, saved.steps.length - 1) + 1} od {saved.steps.length}).</b>
                <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
                  <Btn primary sm onClick={resumeSaved}>Nadaljuj</Btn>
                  {savedAtSec >= PARTIAL_SAVE_SEC && <Btn ghost sm onClick={() => void finishSaved()}>Shrani, kar si naredil ({fmtClock(savedAtSec, savedAtSec >= 3600)})</Btn>}
                  <Btn ghost sm onClick={dropSaved}>Zavrzi</Btn>
                </div>
              </div>
            )}
            {/* naslov je že v glavi — tu številke seje in cilj dela */}
            <div className="card sess spot" style={{ ['--c' as string]: color }}>
              {/* značka: vrsta treninga (tekma s pokalom), ne »3 koraki« (v3.48) */}
              {/* značka: intenzivnost (vrsta je že v glavi — prej »KOLO« dvakrat); pri moči število vaj, pri tekmi »Tekma« */}
              <div className="kbadge"><span className="ki"><SessIcon d={day} /></span>{effortOf(day)?.w ?? (day.kind === 'moc' ? count(new Set(steps.filter(x => x.kind === 'vaja').map(x => x.label)).size || steps.length, W.vaja) : sessLabel(day))}</div>
              <div className="kpis">
                <div className="kpi"><b>{fmtDur((day.kind === 'moc' || hasOpen) && day.durationMin ? day.durationMin : Math.round(total / 60))}</b><small>trajanje</small></div>
                {/* (v3.50) začetnik brez ure pri načrtu po meri: brez TSS (žargon) */}
                {day.tssTarget && !plainTerms(app.profile, !!app.settings.intervals) ? <div className="kpi"><b>{day.tssTarget}</b><small>TSS</small></div> : null}
                {day.exercises?.length ? <div className="kpi"><b>{day.exercises.length}</b><small>{plural(day.exercises.length, W.vaja)}</small></div> : null}
                {day.kind === 'kolo' && day.zone && /^Z[1-5]$/.test(day.zone) ? <div className="kpi"><b>{day.zone}</b><small>{noPower(app.profile) ? zoneText(app.profile, day.zone as 'Z1') : 'cona'}</small></div> : null}
              </div>
              {(day.target || (day.kind === 'kolo' && /Z2/.test(day.zone || '') && !noPower(app.profile) && z2)) && (
                <div className="row" style={{ gap: 8, marginTop: 12, fontSize: 13, fontWeight: 700, color: 'var(--ink)', alignItems: 'flex-start' }}>
                  <IcoTarget width={16} height={16} style={{ color, flex: 'none', marginTop: 2 }} />
                  <span>{day.target ? (noPower(app.profile) ? `delo: ${ttT ?? workText(app.profile, day)}` : `delo pri ${ttT ?? workText(app.profile, day)}`) : noPower(app.profile) ? `Z2 ${zoneText(app.profile, 'Z2')}` : `Z2 ${z2!.lo}–${z2!.hi} W`}</span>
                </div>
              )}
            </div>
            <div className="card tight" style={{ marginTop: 12 }}>
              <h2 className="h4" style={{ fontSize: 11 }}>Kaj te čaka</h2>
              {day.kind !== 'moc' && <StepsBar steps={steps} />}
              <ol style={{ margin: '6px 0 0 18px', padding: 0, fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.6 }}>{structureLines(steps).map((l, j) => <li key={j}>{nb(l)}</li>)}</ol>
              {day.why && <p className="muted" style={{ fontSize: 12, marginTop: 8 }}>Zakaj: {day.why}</p>}
            </div>
            {(day.kind === 'kolo' || day.kind === 'test') && <RouteCard day={day} compact />}
            {day.kind === 'moc' ? (
              <div className="card tight" style={{ marginTop: 10 }}>
                <h2 className="h4" style={{ fontSize: 11 }}>Kako</h2>
                {(day.exercises || []).map((e, j) => { const d = exByName(e.name); return <div key={j} className="row" style={{ fontSize: 12.5, marginTop: 8, gap: 10, alignItems: 'flex-start' }}>{d && hasPhoto(d.id) ? <ExercisePhoto id={d.id} size={96} ratio={0.62} vector={false} label={e.name} className="fig-mini" /> : null}<div style={{ minWidth: 0, flex: 1 }}><b style={{ color: 'var(--ink)' }}>{e.name}</b> <span className="muted">{e.sets} × {e.reps}</span><div style={{ color: 'var(--ink-2)' }}>{howOf(e.name)}</div></div></div> })}
              </div>
            ) : (<>
              {fuel && <div className="card tight" style={{ marginTop: 10 }}>
                <h2 className="h4" style={{ fontSize: 11 }}>Vzemi s seboj</h2>
                <ul style={{ margin: '6px 0 0 18px', padding: 0, fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.6 }}>{fuel.items.map((x, j) => <li key={j}>{nb(plainOH(x))}</li>)}</ul>
                <p className="muted" style={{ fontSize: 12, marginTop: 6 }}>{nb(plainOH(fuel.cues.length ? drinkLine(fuel) : fuel.schedule))}</p>
                <FuelTimeline rf={fuel} minutes={day.durationMin} />
              </div>}
              {/* (v3.50) hribi: voda in prigrizek (opis »voda, nekaj za pojest«; gorivo na kolesu tu ne velja) */}
              {!fuel && day.kind === 'pohod' && hikeItems(day.durationMin) && <div className="card tight" style={{ marginTop: 10 }}>
                <h2 className="h4" style={{ fontSize: 11 }}>Vzemi s seboj</h2>
                <ul style={{ margin: '6px 0 0 18px', padding: 0, fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.6 }}>{hikeItems(day.durationMin)!.map((x, j) => <li key={j}>{nb(x)}</li>)}</ul>
              </div>}
              {food && <div className="card tight" style={{ marginTop: 10 }}><h2 className="h4" style={{ fontSize: 11 }}>Pred treningom</h2><p style={{ fontSize: 13, marginTop: 4, color: 'var(--ink-2)' }}>{nb(plainOH(food.before))}</p></div>}
              {/* (v3.49) vati samo na kolesu z merilnikom — tek in hoja nikoli; (v3.50) in samo z znanim FTP (sicer koraki v RPE) */}
              <p className="muted" style={{ fontSize: 12, marginTop: 10 }}>Med treningom: {(day.kind === 'kolo' || day.kind === 'test') && !noPower(app.profile) && !!app.profile.ftp ? 'vati' : 'utrip ali občutek'} za vsak korak · pisk pred menjavo{fuel?.cues.length ? ` · opomnik za hrano in pijačo od ${fuel.cues[0]!.atMin}. min` : ''} · zaslon ostane prižgan.</p>
            </>)}
            {/* (v3.49) »Začni trening« vedno na dnu zaslona — prej šele pod gorivom in prehrano (y 1392 px na 844 px) */}
            {/* ob prekinjeni vadbi je glavni gumb »Nadaljuj« zgoraj — tu samo »Začni znova« (nov začetek pobriše kopijo) */}
            <div className="run-start">{resumable ? <Btn ghost block onClick={start}>Začni znova</Btn> : <Btn primary block onClick={start}>Začni trening</Btn>}</div>
            <HealthNote kind="plan" />
          </div>
        ) : step && (
          <div className="page run-view" key={i}>
            {fuelMsg && <button className="card tight" onClick={() => setFuelMsg(null)} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', width: '100%', textAlign: 'left', borderColor: 'var(--accent)', background: 'var(--accent-soft)', marginBottom: 12, fontSize: 13.5, fontWeight: 700, color: 'var(--ink)', cursor: 'pointer' }}><IcoDrink width={18} height={18} aria-hidden="true" style={{ color: 'var(--accent-fg)', flex: 'none', marginTop: 1 }} /><span>{fuelMsg} <span className="muted" style={{ fontWeight: 600, fontSize: 12 }}>· tapni, ko je opravljeno</span></span></button>}
            <Chip sm>{i + 1} / {steps.length}</Chip>
            {/* vrsta koraka nad imenom — ne, kadar je enaka imenu (»Ogrevanje« dvakrat) */}
            {stepKind(step).toLowerCase() !== step.label.trim().toLowerCase() && <div className="muted" style={{ fontSize: 13, fontWeight: 700, marginTop: 14, letterSpacing: '.06em', textTransform: 'uppercase', color: kindInk(day.kind) }}>{stepKind(step)}</div>}
            <h2 style={{ marginTop: stepKind(step).toLowerCase() !== step.label.trim().toLowerCase() ? 6 : 14, fontSize: 28 }}>{step.label}</h2>
            {step.reps && <div style={{ fontSize: 18, fontWeight: 800, marginTop: 6 }}>{step.sets && step.sets > 1 ? `Serija ${step.set}/${step.sets} · ` : ''}{step.reps}</div>}
            {step.target && <div style={{ marginTop: 10 }}><Chip sm on>{step.target}</Chip></div>}
            {step.kind === 'vaja' && figId && hasPhoto(figId) && <div className="fig-stage"><ExercisePhoto id={figId} size={Math.min(360, Math.round(innerWidth * 0.86))} ratio={0.56} vector={false} label={`Kako: ${step.label}`} /></div>}
            {cardioFig && !step.sec ? null : cardioFig && <div className="fig-stage fig-cardio"><ExerciseFigure id={cardioFig} size={120} label={cardioFig} playing={figPlay} /></div>}
            {logSet && (
              <div className="setlog" role="group" aria-label="Kaj si naredil v tej seriji">
                <div className="setlog-f">
                  <span className="setlog-l">ponovitve</span>
                  <div className="stepper">
                    <button type="button" onClick={() => setSetIn(x => ({ ...x, reps: x.reps == null ? repsLo : Math.max(0, x.reps - 1) }))} aria-label="Ena ponovitev manj">−</button>
                    <b aria-live="polite">{setIn.reps ?? '—'}</b>
                    <button type="button" onClick={() => setSetIn(x => ({ ...x, reps: x.reps == null ? repsLo : Math.min(99, x.reps + 1) }))} aria-label="Ena ponovitev več">+</button>
                  </div>
                </div>
                {setIn.reps == null && <div className="setlog-hint" style={{ flexBasis: '100%' }}>Vpiši, koliko ponovitev si res naredil (načrt {exNow!.reps}).</div>}
                {weighted && (
                  <div className="setlog-f">
                    <span className="setlog-l">{loaded ? 'kg' : 'kg (nahrbtnik)'}</span>
                    <div className="stepper">
                      <button type="button" onClick={() => setSetIn(x => { const v = +x.kg.replace(',', '.') || 0; return { ...x, kg: String(Math.max(0, Math.round((v - kgStep(defNow, v)) * 4) / 4)).replace('.', ',') } })} aria-label="Manj kilogramov">−</button>
                      <input inputMode="decimal" value={setIn.kg} placeholder="—" onChange={e => setSetIn(x => ({ ...x, kg: e.target.value.replace(/[^\d,.]/g, '').slice(0, 6) }))} aria-label="Kilogrami" />
                      <button type="button" onClick={() => setSetIn(x => { const v = +x.kg.replace(',', '.') || 0; return { ...x, kg: String(Math.round((v + kgStep(defNow, v)) * 4) / 4).replace('.', ',') } })} aria-label="Več kilogramov">+</button>
                    </div>
                  </div>
                )}
                {/* (v3.50) prva teža: brez prejšnje teže in brez teže v načrtu namig, s čim začeti (prej prazen KG brez besede) */}
                {loaded && !setIn.kg && !(exNow!.kg != null) && <div className="setlog-hint" style={{ flexBasis: '100%' }}>{firstKgHint(exNow!.name)}</div>}
              </div>
            )}
            {swaps.length > 0 && <button type="button" className="chip sm click" style={{ marginTop: 10 }} onClick={() => setSwapOpen(true)}>Zamenjaj vajo</button>}
            {step.sec ? (
              <div className={`stepring ${step.kind === 'delo' || step.kind === 'test' || step.kind === 'vaja' ? '' : 'easy'}`} style={{ ['--c' as string]: ringC }}>
                <svg viewBox="0 0 120 120" aria-hidden="true"><circle className="bg" cx="60" cy="60" r="54" /><circle className="fg" cx="60" cy="60" r="54" strokeDasharray={`${(2 * Math.PI * 54 * Math.max(0, Math.min(1, left / step.sec))).toFixed(2)} 400`} /></svg>
                {step.kind === 'pavza' && figId && hasPhoto(figId) ? (
                  <div className="rest-mid">
                    <div className="num" role="timer" aria-live="off" style={{ fontSize: 46, fontWeight: 800, letterSpacing: '-.04em', lineHeight: 1, color: left <= 5 ? ringC : 'var(--ink)', fontVariantNumeric: 'tabular-nums' }}>{fmtClock(left)}</div>
                    <ExercisePhoto id={figId} size={150} ratio={0.6} vector={false} label={`Sledi: ${nextStep?.label ?? ''}`} />
                  </div>
                ) : <div className="num" role="timer" aria-live="off" style={{ fontSize: fmtClock(left).length > 5 ? 50 : 66, fontWeight: 800, letterSpacing: '-.04em', lineHeight: 1, color: left <= 5 ? ringC : 'var(--ink)', fontVariantNumeric: 'tabular-nums' }}>{fmtClock(left)}</div>}
              </div>
            ) : open ? (
              // tekma: štoparica od začetka koraka, teče do »Zaključi« (v3.48)
              <div className="num" role="timer" aria-live="off" style={{ fontSize: 56, fontWeight: 800, letterSpacing: '-.04em', lineHeight: 1, margin: '22px 0 10px', fontVariantNumeric: 'tabular-nums' }}>{fmtClock(Math.max(0, elapsed - Math.round((run?.stepAt ?? 0) / 1000)))}</div>
            ) : logSet ? null : <div className="num" role="timer" aria-live="off" style={{ fontSize: 44, fontWeight: 800, lineHeight: 1, margin: '22px 0 10px' }}>—</div>}
            {/* (v3.50) »aplikacija te opomni« samo, ko gorivo ima opomnike (lahka 75-min vožnja, tek in hribi jih nimajo) */}
            {step.note && <p style={{ fontSize: 13.5, maxWidth: 340, margin: logSet ? '16px auto 0' : '0 auto' }}>{plainOH(fuel?.cues.length ? step.note : step.note.replace(' Jej in pij po urniku — aplikacija te opomni.', ' Pij po žeji.'))}</p>}
            {nextStep && <div className="muted" style={{ fontSize: step.kind === 'pavza' ? 14 : 12.5, marginTop: 16 }}>Sledi: <b style={{ color: 'var(--ink)' }}>{nextStep.label}</b>{nextStep.reps ? <span> · {nextStep.sets && nextStep.sets > 1 ? `serija ${nextStep.set}/${nextStep.sets} · ` : ''}{nextStep.reps}</span> : null}{nextStep.sec ? ` · ${fmtClock(nextStep.sec)}` : ''}</div>}
            <div className="run-actions">
              <div className="row" style={{ gap: 10, justifyContent: 'center', marginTop: 26 }}>
                {/* »‹ Prejšnji« (prej »‹ Nazaj« — isto ime kot gumb v glavi, ki zapusti vadbo); ozek zaslon: samo puščici (v3.48) */}
                <button type="button" className="btn ghost sm" onClick={prev} disabled={i === 0} aria-label="Prejšnji korak"><span aria-hidden="true">‹</span><span className="ra-tx" aria-hidden="true"> Prejšnji</span></button>
                {step.sec === 0 && !open ? <Btn primary onClick={() => next(true)}>{logSet ? 'Narejeno ›' : 'Naprej ›'}</Btn> : running ? <Btn primary onClick={pause}>Pavza</Btn> : <Btn primary onClick={start}>{elapsed ? 'Nadaljuj' : 'Začni'}</Btn>}
                {open ? <Btn ghost sm onClick={() => void endNow()}>Zaključi</Btn> : <button type="button" className="btn ghost sm" onClick={() => next()} aria-label="Preskoči korak"><span className="ra-tx" aria-hidden="true">Preskoči </span><span aria-hidden="true">›</span></button>}
              </div>
              {/* ista oblika časa (»0:01:55 od 1:45:00«), »od« po preskoku iz preostalih korakov; tekma brez »od« (v3.48) */}
              {/* (v3.50) »od« je ves trening in se ne spreminja (prej po »Preskoči« 25:00 → 20:02); preskočeno se vidi v »še …«;
                  moč šteje serije, ne minut časovnikov (prej »0:03 od 19:32«) */}
              <div className="muted run-sum">Skupaj {fmtClock(elapsed, long)}{hasOpen || day.kind === 'moc' ? '' : ` od ${fmtClock(total, long)}`}{!hasOpen && day.kind !== 'moc' && planned < total - 30 ? ` · še ${fmtDur(Math.max(1, Math.round(Math.max(0, planned - elapsed) / 60)))}` : ''}{day.kind === 'moc' && sq.all ? ` · ${sq.done} od ${sq.all} serij` : ''}{!running ? ' · pavza' : ''}{!open && <button className="chip sm click run-end" onClick={() => void endNow()}>Zaključi</button>}</div>
              <div className="run-keys" aria-hidden="true">presledek: {step.sec === 0 && !open ? 'narejeno' : 'pavza'} · → naprej · ← nazaj</div>
            </div>
          </div>
        )}
      </main>
      {confirmSheet}
      {swapOpen && exNow && (
        <Sheet open onClose={() => setSwapOpen(false)} label="Zamenjaj vajo">
          <b style={{ display: 'block', fontSize: 17, letterSpacing: '-.02em' }}>Namesto: {exNow.name}</b>
          <p className="muted" style={{ fontSize: 12.5, marginTop: 4 }}>{swaps.every(o => o.pat === defNow?.pat) ? 'Ista mišična skupina, druga oprema.' : 'Ista mišica, druga vaja.'} Velja za preostale serije in za ta dan v načrtu.</p>
          <div className="stack" style={{ gap: 8, marginTop: 12 }}>
            {swaps.map(o => (
              <button key={o.id} type="button" className="opt" onClick={() => swapTo(o.name)}>
                <div style={{ minWidth: 0 }}>{o.name}<small>{o.m.map(m => MUSCLE_LABEL[m]).join(', ')} · {o.how.split('. ')[0]}.</small></div>
              </button>
            ))}
          </div>
          <Btn ghost block style={{ marginTop: 12 }} onClick={() => setSwapOpen(false)}>Prekliči</Btn>
        </Sheet>
      )}
      {early && run && !run.finished && (
        <Sheet open onClose={() => setEarly(false)} label={early === 'leave' ? 'Zapustim trening' : 'Zaključim trening'}>
          {early === 'leave' ? (<>
            {/* (v3.49) »Zapusti vadbo« po 5 min: kar si naredil, se ne izgubi */}
            <b style={{ display: 'block', fontSize: 17, letterSpacing: '-.02em' }}>Zapustiš trening?</b>
            <p style={{ fontSize: 13, marginTop: 6, lineHeight: 1.5 }}>Treniraš {fmtClock(elapsed, elapsed >= 3600)}. Kar si naredil, lahko shraniš — šteje v teden in formo.</p>
          </>) : day.kind === 'moc' ? (<>
            {/* (v3.50) moč: serije, ne minute */}
            <b style={{ display: 'block', fontSize: 17, letterSpacing: '-.02em' }}>Narejeno {sq.done} od {sq.all} serij</b>
            <p style={{ fontSize: 13, marginTop: 6, lineHeight: 1.5 }}>Za opravljeno šteje, ko narediš večji del — {sq.done ? 'lahko pa shraniš, kar si naredil.' : 'za zdaj ga raje prekini brez oznake.'}</p>
          </>) : (<>
            <b style={{ display: 'block', fontSize: 17, letterSpacing: '-.02em' }}>Narejeno {Math.round(pctAll)} % treninga</b>
            <p style={{ fontSize: 13, marginTop: 6, lineHeight: 1.5 }}>{fmtClock(elapsed, total >= 3600)} od {fmtClock(total)}. Za opravljeno šteje, ko narediš večji del — {elapsed >= PARTIAL_SAVE_SEC ? 'lahko pa shraniš, kar si naredil.' : 'za zdaj ga raje prekini brez oznake.'}</p>
          </>)}
          <Btn primary block style={{ marginTop: 16 }} onClick={() => setEarly(false)}>Nadaljuj trening</Btn>
          {(day.kind === 'moc' ? sq.done > 0 : elapsed >= PARTIAL_SAVE_SEC) && <Btn ghost block style={{ marginTop: 9 }} onClick={() => { setEarly(false); void finish() }}>{early === 'leave' || day.kind === 'moc' ? 'Shrani, kar si naredil' : 'Shrani kot opravljeno'} ({day.kind === 'moc' ? `${sq.done} od ${sq.all} serij` : fmtClock(elapsed)})</Btn>}
          <Btn ghost block style={{ marginTop: 9 }} onClick={stopNoMark}>Prekini brez oznake</Btn>
        </Sheet>
      )}
    </div>
  )
}
