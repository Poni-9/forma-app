import { useMemo, useState } from 'react'
import { Head } from '@/app/Shell'
import { EXERCISES, type ExDef } from '@/domain/training/exercises'
import { ExercisePhoto } from '@/ui/figure/ExercisePhoto'
import { Chip, Sheet, Btn } from '@/ui/primitives'
import { EQUIP_LABEL, MUSCLE_NAME } from '@/domain/focus/model'

/**
 * Knjižnica vaj (#/vaje): ploščica z animacijo ali fotografijo; tap odpre, kako se vaja izvaja (v3.47 — prej se ploščic
 * ni dalo tapniti, čeprav ima vsaka vaja opis). Filter po opremi; kardio figure (tek, hoja, kolo) na koncu, tudi tapljive.
 */
type EqF = 'vse' | 'nic' | 'utezi' | 'fitnes' | 'drugo'
const EQ_F: readonly [EqF, string][] = [['vse', 'Vse'], ['nic', 'Brez opreme'], ['utezi', 'Uteži'], ['fitnes', 'Fitnes'], ['drugo', 'Elastike, drog']]
const eqOf = (e: ExDef): EqF => (e.eq === 'nic' ? 'nic' : e.eq === 'utezi' ? 'utezi' : e.eq === 'fitnes' ? 'fitnes' : 'drugo')
const LVL = { 1: 'lažja', 2: 'srednja', 3: 'zahtevna' } as const
/** Kardio na koncu galerije: tap odpre kratko tehniko in cono (v3.48 — prej ploščice brez tapa, glava pa »tapni vajo«). */
export const CARDIO = [
  { id: 'tek', name: 'Tek', sub: 'Kardio · brez opreme', how: 'Kratek, lahkoten korak — stopalo pristane pod telesom, ne daleč pred njim. Ramena sproščena, roke pokrčene za približno 90°. Večino tekov teci lahko (Z2): še lahko govoriš v celih stavkih.' },
  { id: 'hoja', name: 'Hoja', sub: 'Kardio · brez opreme', how: 'Pokončno, pogled naprej, korak s pete čez stopalo na prste, roke nihajo ob telesu. Hitra hoja je lahek kardio (Z1–Z2); v klanec skrajšaj korak.' },
  { id: 'kolo', name: 'Kolo', sub: 'Kardio · kolo ali trenažer', how: 'Sedež tako visoko, da je koleno v spodnji točki rahlo pokrčeno. Vrti enakomerno, okoli 80–95 obratov na minuto, zgornji del telesa miren. Večina voženj je lahkih (Z2).' },
] as const
type Cardio = (typeof CARDIO)[number]

export function Vaje() {
  const [eq, setEq] = useState<EqF>('vse')
  const [open, setOpen] = useState<ExDef | null>(null)
  const [cardio, setCardio] = useState<Cardio | null>(null)
  const list = useMemo(() => EXERCISES.filter(e => eq === 'vse' || eqOf(e) === eq), [eq])
  return (<>
    <Head hi="Kako se izvaja — tapni vajo" nm="Vaje" />
    {/* fotografije: javna domena (free-exercise-db) */}
    <div className="scroll">
      <div className="row" role="group" aria-label="Oprema" style={{ gap: 6, paddingBottom: 12, flexWrap: 'wrap' }}>
        {EQ_F.map(([k, l]) => <Chip key={k} sm on={eq === k} onClick={() => setEq(k)}>{l}</Chip>)}
      </div>
      <div className="fig-gallery">
        {list.map(e => (
          <button key={e.id} type="button" className="card vaja-tile" id={`v-${e.id}`} onClick={() => setOpen(e)} aria-label={`${e.name} — kako se izvaja`}>
            <ExercisePhoto id={e.id} size={150} label={e.name} />
            <b>{e.name}</b>
          </button>
        ))}
        {eq === 'vse' && CARDIO.map(c => (
          <button key={c.id} type="button" className="card vaja-tile" id={`v-${c.id}`} onClick={() => setCardio(c)} aria-label={`${c.name} — kako se izvaja`}>
            <ExercisePhoto id={c.id} size={150} label={c.name} fallback={c.id} />
            <b>{c.name}</b>
          </button>
        ))}
      </div>
    </div>
    {open && (
      <Sheet open onClose={() => setOpen(null)} label={open.name}>
        <b style={{ fontSize: 18, letterSpacing: '-.02em', display: 'block' }}>{open.name}</b>
        <div className="muted" style={{ fontSize: 12.5, marginTop: 2 }}>{open.m.map(m => MUSCLE_NAME[m]).join(', ')} · {EQUIP_LABEL[open.eq]} · {LVL[open.lvl]}</div>
        <div style={{ display: 'grid', placeItems: 'center', marginTop: 12 }}><ExercisePhoto id={open.id} size={220} label={open.name} /></div>
        <p style={{ fontSize: 14, marginTop: 12, color: 'var(--ink)' }}>{open.how}</p>
        <Btn ghost block style={{ marginTop: 14 }} onClick={() => setOpen(null)}>Zapri</Btn>
      </Sheet>
    )}
    {cardio && (
      <Sheet open onClose={() => setCardio(null)} label={cardio.name}>
        <b style={{ fontSize: 18, letterSpacing: '-.02em', display: 'block' }}>{cardio.name}</b>
        <div className="muted" style={{ fontSize: 12.5, marginTop: 2 }}>{cardio.sub}</div>
        <div style={{ display: 'grid', placeItems: 'center', marginTop: 12 }}><ExercisePhoto id={cardio.id} size={220} label={cardio.name} fallback={cardio.id} /></div>
        <p style={{ fontSize: 14, marginTop: 12, color: 'var(--ink)' }}>{cardio.how}</p>
        <Btn ghost block style={{ marginTop: 14 }} onClick={() => setCardio(null)}>Zapri</Btn>
      </Sheet>
    )}
  </>)
}
