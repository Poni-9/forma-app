import { Head } from '@/app/Shell'
import { EXERCISES } from '@/domain/training/exercises'
import { ExerciseFigure } from '@/ui/figure/ExerciseFigure'
import { ExercisePhoto } from '@/ui/figure/ExercisePhoto'

/** Knjižnica vaj z animacijami (#/vaje) — vsaka vaja, kot jo kaže izvajalnik; tudi za pregled risb. */
export function Vaje() {
  return (<>
    <Head hi="Kako se izvaja" nm="Vaje" />
    {/* fotografije: javna domena (free-exercise-db) */}
    <div className="scroll">
      <div className="fig-gallery">
        {EXERCISES.map(e => (
          <div key={e.id} className="card" id={`v-${e.id}`}>
            <ExercisePhoto id={e.id} size={150} label={e.name} />
            <b style={{ display: 'block', color: 'var(--ink)', marginTop: 4 }}>{e.name}</b>
          </div>
        ))}
        {(['tek', 'hoja', 'kolo', 'pavza'] as const).map(k => (
          <div key={k} className="card" id={`v-${k}`}>
            <ExerciseFigure id={k} size={150} label={k} />
            <b style={{ display: 'block', color: 'var(--ink)', marginTop: 4 }}>{k}</b>
          </div>
        ))}
      </div>
    </div>
  </>)
}
