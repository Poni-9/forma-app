import { useEffect, useMemo, useState } from 'react'
import { Head } from '@/app/Shell'
import { useRoute, navigate, cameFromApp } from '@/app/router'
import { EXERCISES, type ExDef } from '@/domain/training/exercises'
import { ExercisePhoto } from '@/ui/figure/ExercisePhoto'
import { Chip, Sheet, Btn } from '@/ui/primitives'
import { EQUIP_LABEL, MUSCLE_NAME } from '@/domain/focus/model'
import type { Muscle } from '@/domain/types'
import { rem } from '@/ui/rem'

/**
 * Knjižnica vaj (#/vaje): ploščica z animacijo ali fotografijo; tap odpre, kako se vaja izvaja (v3.47 — prej se ploščic
 * ni dalo tapniti, čeprav ima vsaka vaja opis). Filter po opremi; kardio figure (tek, hoja, kolo) na koncu, tudi tapljive.
 */
type EqF = 'vse' | 'nic' | 'utezi' | 'fitnes' | 'drugo'
const EQ_F: readonly [EqF, string][] = [['vse', 'Vse'], ['nic', 'Brez opreme'], ['utezi', 'Uteži'], ['fitnes', 'Fitnes'], ['drugo', 'Elastike, drog']]
const eqOf = (e: ExDef): EqF => (e.eq === 'nic' ? 'nic' : e.eq === 'utezi' ? 'utezi' : e.eq === 'fitnes' ? 'fitnes' : 'drugo')
const LVL = { 1: 'lažja', 2: 'srednja', 3: 'zahtevna' } as const
/** (v3.50) kje je treba paziti (iz `avoid` vaje): »Previdno, če te boli: koleno.« */
const LIMIT_LABEL = { koleno: 'koleno', hrbet: 'hrbet', rama: 'rama' } as const
/** Kardio na koncu galerije: tap odpre kratko tehniko in cono (v3.48 — prej ploščice brez tapa, glava pa »tapni vajo«). */
export const CARDIO = [
  { id: 'tek', name: 'Tek', sub: 'Kardio · brez opreme', how: 'Kratek, lahkoten korak — stopalo pristane pod telesom, ne daleč pred njim. Ramena sproščena, roke pokrčene za približno 90°. Večino tekov teci lahko (Z2): še lahko govoriš v celih stavkih.' },
  { id: 'hoja', name: 'Hoja', sub: 'Kardio · brez opreme', how: 'Pokončno, pogled naprej, korak s pete čez stopalo na prste, roke nihajo ob telesu. Hitra hoja je lahek kardio (Z1–Z2); v klanec skrajšaj korak.' },
  { id: 'kolo', name: 'Kolo', sub: 'Kardio · kolo ali trenažer', how: 'Sedež tako visoko, da je koleno v spodnji točki rahlo pokrčeno. Vrti enakomerno, okoli 80–95 obratov na minuto, zgornji del telesa miren. Večina voženj je lahkih (Z2).' },
] as const
type Cardio = (typeof CARDIO)[number]
/** (v3.51) vaje z angleškim imenom: kaj pomeni po slovensko (na listu vaje in v iskanju) */
export const GLOSS: Record<string, string> = {
  'Pike sklece': 'sklece v obliki črke V — boki visoko',
  'Dead bug': 'mrtvi hrošč — leže na hrbtu, nasprotna roka in noga',
  'Superman': 'leže na trebuhu, dvig rok in nog',
  'Superman z vlekom': 'leže na trebuhu, dvig in vlek komolcev nazaj',
  'Burpee': 'počep, opora, sklek in poskok v enem',
  'Goblet počep': 'počep z utežjo pred prsmi',
  'Hip thrust z ročko': 'dvig bokov s hrbtom na klopi, z ročko',
  'Hip thrust s palico': 'dvig bokov s hrbtom na klopi, s palico',
  'Pallof press': 'protirotacijski potisk — trup se upira zasuku',
  'Face pull na kablu': 'poteg vrvi na kablu k obrazu',
}
/** (v3.51) iskanje brez šumnikov in velikih črk: »pocep« najde »Počep« */
export const fold = (t: string): string => t.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
const MUSCLE_F = Object.keys(MUSCLE_NAME) as Muscle[]
/** (v3.51) filter vaj: oprema, mišica in iskano besedilo (ime ali slovenska razlaga) */
export function filterEx(list: readonly ExDef[], o: { eq?: EqF; m?: Muscle | null; q?: string }): ExDef[] {
  const q = fold((o.q || '').trim())
  return list.filter(e => (!o.eq || o.eq === 'vse' || eqOf(e) === o.eq) && (!o.m || e.m.includes(o.m)) && (!q || fold(`${e.name} ${GLOSS[e.name] ?? ''}`).includes(q)))
}

export function Vaje() {
  const [eq, setEq] = useState<EqF>('vse')
  const [mus, setMus] = useState<Muscle | null>(null)
  const [q, setQ] = useState('')
  const [open, setOpen] = useState<ExDef | null>(null)
  const [cardio, setCardio] = useState<Cardio | null>(null)
  // (v3.49) #/vaje?v=<id> (ploščica pod odgovorom trenerja) odpre to vajo
  const route = useRoute(), want = route.params.v
  useEffect(() => {
    const e = want ? EXERCISES.find(x => x.id === want) : null
    const c = want && !e ? CARDIO.find(x => x.id === want) : null
    if (e) { setEq('vse'); setMus(null); setQ(''); setOpen(e) } else if (c) { setEq('vse'); setMus(null); setQ(''); setCardio(c) }
  }, [route])   // eslint-disable-line react-hooks/exhaustive-deps
  // (v3.50) po zaprtju lista naslov brez ?v= — osvežitev ali vrnitev lista ne odpre znova
  // (v3.51) zaprto z Nazaj (vnos zaslona, ne lista): oznaka »iz aplikacije« ostane — »‹ Nazaj« gre nazaj, od koder si prišel
  const close = () => {
    setOpen(null); setCardio(null)
    const st = history.state as Record<string, unknown> | null
    if (/^#\/vaje\?/.test(location.hash)) history.replaceState(st && typeof st === 'object' && !('formaiSheet' in st) ? st : null, '', `${location.pathname}${location.search}#/vaje`)
  }
  const list = useMemo(() => filterEx(EXERCISES, { eq, m: mus, q }), [eq, mus, q])
  const all = eq === 'vse' && !mus && !q.trim()
  // (v3.51) nazaj, od koder si prišel (ploščica na Danes, Pomoč) — prej samo gumb brskalnika
  // (v3.51) samo, ko je prejšnji vnos zaslon FORMAI; odprto s povezavo od drugod → Danes (prej ven iz aplikacije)
  const back = () => { if (cameFromApp()) history.back(); else navigate('danes') }
  return (<>
    <Head hi="Kako se izvaja — tapni vajo" nm="Vaje" />
    {/* fotografije: javna domena (free-exercise-db) */}
    <div className="scroll">
      <button type="button" className="chip sm click vaje-back" onClick={back}><span aria-hidden="true">‹</span> Nazaj</button>
      {/* (v3.51) iskanje in filter po mišici (prej 69 vaj samo po opremi) */}
      <div className="field vaje-q"><label htmlFor="vaje-q" className="sr-only">Išči vajo</label><input id="vaje-q" type="search" value={q} placeholder="Išči vajo …" onChange={e => setQ(e.target.value)} /></div>
      <div className="row" role="group" aria-label="Oprema" style={{ gap: 6, paddingBottom: 8, flexWrap: 'wrap' }}>
        {EQ_F.map(([k, l]) => <Chip key={k} sm on={eq === k} onClick={() => setEq(k)}>{l}</Chip>)}
      </div>
      <div className="row" role="group" aria-label="Mišica" style={{ gap: 6, paddingBottom: 12, flexWrap: 'wrap' }}>
        <Chip sm on={!mus} onClick={() => setMus(null)}>Vse mišice</Chip>
        {MUSCLE_F.map(m => <Chip key={m} sm on={mus === m} onClick={() => setMus(mus === m ? null : m)}>{MUSCLE_NAME[m]}</Chip>)}
      </div>
      {!list.length && <p className="muted" style={{ fontSize: rem(13), margin: '0 0 12px' }}>Ni vaje za ta izbor — spremeni iskanje ali filter.</p>}
      <div className="fig-gallery">
        {list.map(e => (
          <button key={e.id} type="button" className="card vaja-tile" id={`v-${e.id}`} onClick={() => setOpen(e)} aria-label={`${e.name} — kako se izvaja`}>
            {/* (v3.49) fotografije se menjajo samo v vrstici na sredini zaslona, figure mirujejo (prej vseh 62 ploščic — 80 % glavne niti) */}
            <ExercisePhoto id={e.id} size={150} label={e.name} band />
            <b>{e.name}</b>
          </button>
        ))}
        {all && CARDIO.map(c => (
          <button key={c.id} type="button" className="card vaja-tile" id={`v-${c.id}`} onClick={() => setCardio(c)} aria-label={`${c.name} — kako se izvaja`}>
            <ExercisePhoto id={c.id} size={150} label={c.name} fallback={c.id} band />
            <b>{c.name}</b>
          </button>
        ))}
      </div>
    </div>
    {open && (
      <Sheet open onClose={close} label={open.name}>
        <b style={{ fontSize: rem(18), letterSpacing: '-.02em', display: 'block' }}>{open.name}</b>
        {GLOSS[open.name] && <div style={{ fontSize: rem(13), marginTop: 2, color: 'var(--ink-2)' }}>Po slovensko: {GLOSS[open.name]}</div>}
        {/* (v3.50) »zahtevnost srednja« (prej samo »srednja«) */}
        <div className="muted" style={{ fontSize: rem(12.5), marginTop: 2 }}>{open.m.map(m => MUSCLE_NAME[m]).join(', ')} · {EQUIP_LABEL[open.eq]} · zahtevnost {LVL[open.lvl]}</div>
        <div style={{ display: 'grid', placeItems: 'center', marginTop: 12 }}><ExercisePhoto id={open.id} size={220} label={open.name} fit /></div>
        <p style={{ fontSize: rem(14), marginTop: 12, color: 'var(--ink)' }}>{open.how}</p>
        {/* (v3.50) opozorilo iz omejitev vaje (koleno, hrbet, rama) */}
        {open.avoid?.length ? <p className="muted" style={{ fontSize: rem(12.5), marginTop: 8 }}>Previdno, če te boli: {open.avoid.map(l => LIMIT_LABEL[l]).join(', ')}. Takrat vajo izpusti ali zamenjaj.</p> : null}
        <Btn ghost block style={{ marginTop: 14 }} onClick={close}>Zapri</Btn>
      </Sheet>
    )}
    {cardio && (
      <Sheet open onClose={close} label={cardio.name}>
        <b style={{ fontSize: rem(18), letterSpacing: '-.02em', display: 'block' }}>{cardio.name}</b>
        <div className="muted" style={{ fontSize: rem(12.5), marginTop: 2 }}>{cardio.sub}</div>
        <div style={{ display: 'grid', placeItems: 'center', marginTop: 12 }}><ExercisePhoto id={cardio.id} size={220} label={cardio.name} fallback={cardio.id} /></div>
        <p style={{ fontSize: rem(14), marginTop: 12, color: 'var(--ink)' }}>{cardio.how}</p>
        <Btn ghost block style={{ marginTop: 14 }} onClick={close}>Zapri</Btn>
      </Sheet>
    )}
  </>)
}
