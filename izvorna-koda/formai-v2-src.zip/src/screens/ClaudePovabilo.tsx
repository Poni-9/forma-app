import { useEffect, useState } from 'react'
import { navigate } from '@/app/router'
import { markApp } from '@/app/landing'
import { useApp, getState, signIn } from '@/state/store'
import { redeemClaudeInvite, claudeAccess } from '@/domain/ai/client'
import { Btn } from '@/ui/primitives'
import { IcoBack, IcoCheck } from '@/ui/icons'
import { rem } from '@/ui/rem'

/**
 * POVABILO V CLAUDE TRENERJA (Blaž, 14. 10.: »samo zame in za tistega, ki mu pošljem povezavo, ostali samo Gemini«).
 * Povezava formai.si/#/claude?k=KODA: prejemnik se prijavi z Googlom in povabilo unovči — odslej njegov načrt
 * (vprašanja, predlog, pogajanje, sestava) sestavlja Claude. Povabilo je enkratno (en račun).
 */
export function ClaudePovabilo({ koda }: { koda: string }) {
  const app = useApp()
  const [state, setState] = useState<'idle' | 'busy' | 'ok' | 'err'>('idle')
  const [msg, setMsg] = useState('')
  const [had, setHad] = useState(false)
  // že ima dostop (npr. odpre povezavo drugič): kar povej
  useEffect(() => { if (app.user) void claudeAccess(true).then(a => { if (a.ok) setHad(true) }) }, [app.user])

  async function accept() {
    setState('busy')
    try {
      if (!getState().user) await signIn()
      if (!getState().user) { setState('idle'); return }
      const r = await redeemClaudeInvite(koda)
      setMsg(r.kljuc ? '' : 'Strežnik trenerja še pripravljamo — do takrat načrt sestavlja Gemini, potem pa samodejno Claude.')
      setState('ok')
    } catch (e) {
      setMsg(e instanceof Error ? e.message : 'Povabila ni bilo mogoče potrditi.')
      setState('err')
    }
  }
  function start() {
    markApp()
    navigate(getState().profile.onboardingDone ? 'dogovor' : 'uvod')
  }

  const done = state === 'ok' || (had && state !== 'err')
  return (
    <main className="ob">
      <div className="between" style={{ marginBottom: 14, minHeight: 34 }}>
        <button className="avatar" style={{ background: 'transparent', width: 40, height: 40 }} onClick={() => navigate(app.profile.onboardingDone ? 'danes' : '')} aria-label="Nazaj"><IcoBack /></button>
      </div>
      <div className="brand" style={{ fontWeight: 800, fontSize: rem(15), letterSpacing: '.02em' }}>FORM<span>AI</span></div>
      <h1 style={{ marginTop: 14, fontSize: rem(22), lineHeight: 1.2 }}>Povabilo: Claude trener</h1>
      <p style={{ marginTop: 7, fontSize: rem(14) }}>Povabljen si v testni program. Tvoj načrt bo sestavljal <b>Claude</b> (Anthropic): z njim se pogovoriš, temeljito premisli in sestavi teden točno zate — dneve, vadbe, vaje s serijami in kilogrami ter strategijo.</p>
      <div className="card" style={{ marginTop: 18 }}>
        {done ? (<>
          <div className="row" style={{ gap: 8, alignItems: 'center' }}><IcoCheck width={20} height={20} aria-hidden="true" /><b>Claude trener je vklopljen za tvoj račun.</b></div>
          {msg && <p className="muted" style={{ fontSize: rem(12.5), marginTop: 8 }}>{msg}</p>}
          <Btn primary block style={{ marginTop: 14 }} onClick={start}>{app.profile.onboardingDone ? 'Sestavi nov načrt s Claudom' : 'Sestavi moj načrt'}</Btn>
        </>) : (<>
          <p style={{ fontSize: rem(13) }}>{app.user ? `Prijavljen si kot ${app.user.email || app.user.name || 'uporabnik'}. Povabilo velja za en račun.` : 'Za to se prijaviš z Googlom — povabilo velja za en račun.'}</p>
          {state === 'err' && <p role="alert" style={{ fontSize: rem(13), marginTop: 8, color: 'var(--bad, #e5484d)' }}>{msg}</p>}
          <Btn primary block style={{ marginTop: 14 }} disabled={state === 'busy'} onClick={() => void accept()}>{state === 'busy' ? 'Potrjujem …' : app.user ? 'Sprejmi povabilo' : 'Prijava z Googlom in sprejmi'}</Btn>
        </>)}
      </div>
      {/* povezava vidna kot povezava (podčrtana, v barvi poudarka) in večja tarča — v3.48 */}
      <p className="muted" style={{ fontSize: rem(11.5), marginTop: 12 }}>Kaj gre v AI in kdo obdeluje, piše v <a href="/zasebnost.html" className="lnk-hit">zasebnosti</a>. Pred prvim načrtom te aplikacija še enkrat vpraša za privolitev.</p>
    </main>
  )
}

