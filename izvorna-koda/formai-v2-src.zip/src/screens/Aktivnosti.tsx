import { memo, useEffect, useMemo, useState } from 'react'
import { Head } from '@/app/Shell'
import { navigate, useRoute } from '@/app/router'
import { replaceParams } from '@/app/hash'
import { autoName } from '@/domain/import/parsers'
import { useApp, getState, addActivities, removeActivity, setPlanDone, toast } from '@/state/store'
import { ActivitySheet, manualFields } from '@/ui/ActivitySheet'
import { rpeLabel } from '@/domain/coach/rpe'
import { aiAllowed, sourceLabel } from '@/domain/import/provenance'
import { estimateTss, fmtDur, todayIso } from '@/domain/training/load'
import type { Activity, PlanDay, Sport } from '@/domain/types'
import { sportOfKind } from '@/domain/training/standin'
import { Card, Chip, Btn, Sheet, Empty, KindIcon, kindColor, MONTHS_SL, DecimalInput } from '@/ui/primitives'
import { manualActivityErrors, exerciseErrors, ACTIVITY_RANGE, type ActivityKey } from '@/domain/ranges'
import { isCustom } from '@/domain/focus/model'
import { IcoBike, IcoUpload } from '@/ui/icons'
import { deriveFlags } from '@/domain/import/provenance'
import { DateField } from '@/ui/DateField'
import { deferDelete, useHidden } from '@/ui/Confirm'
import { count, dmy, int, num, unit, NBSP, W } from '@/ui/format'
import { rem } from '@/ui/rem'

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
const SPORTS: { k: Sport; l: string }[] = [{ k: 'kolo', l: 'Kolo' }, { k: 'tek', l: 'Tek' }, { k: 'pohod', l: 'Hoja' }, { k: 'moc', l: 'Moč' }, { k: 'plavanje', l: 'Plavanje' }, { k: 'drugo', l: 'Drugo' }]
// polja ročnega vnosa po športu: skupaj s popravkom vadbe v ActivitySheet (v3.50)
export { manualFields }
/** Toliko aktivnosti izrišemo naenkrat (leto voženj je lahko več sto kartic). */
export const PAGE = 60

/**
 * (v3.50) Privzeti šport ročnega vnosa: današnji trening iz načrta, sicer šport zadnjega ročnega vnosa, sicer prvi šport
 * dogovora. Prej vedno »Kolo« — tekač ali fitnes je ob vsakem vnosu najprej preklapljal.
 */
export function defaultManualSport(o: { plan: readonly PlanDay[]; activities: readonly Activity[]; today: string; fallback: Sport }): Sport {
  const d = o.plan.filter(x => x.date === o.today && !x.done).map(x => sportOfKind(x.kind)).find((s): s is Sport => !!s)
  if (d) return d
  const last = o.activities.filter(a => a.source === 'manual' && !a.planDayId).sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''))[0]
  return last?.sport ?? o.fallback
}
/** (v3.50) polje za napako (fokus gre v prvo napačno polje) */
const AK_ID: Record<ActivityKey, string> = { min: 'ak-min', dist: 'ak-km', elev: 'ak-elev', hr: 'ak-hr', power: 'ak-w', kcal: 'ak-kcal' }

/** Seštevek po mesecih (ključ »2026-10«) iz VSEH vadb, ne le izrisanih: število, minute, km, vzpon. */
export function monthSums(list: readonly Activity[]): Map<string, { n: number; min: number; km: number; elev: number }> {
  const out = new Map<string, { n: number; min: number; km: number; elev: number }>()
  for (const a of list) {
    const k = a.date.slice(0, 7), m = out.get(k) || { n: 0, min: 0, km: 0, elev: 0 }
    m.n++; m.min += a.durationMin || 0; m.km += a.distKm || 0; m.elev += a.elevM || 0
    out.set(k, m)
  }
  return out
}
/** Vrstica seštevka meseca: »3 vadbe · 2 h 46 min · 54 km · 600 m«. */
export function monthLine(m: { n: number; min: number; km: number; elev: number }): string {
  return [count(m.n, W.vadba), m.min ? fmtDur(Math.round(m.min)) : null, m.km >= 1 ? `${int(Math.round(m.km))}${NBSP}km` : null, m.elev >= 50 ? `${int(Math.round(m.elev))}${NBSP}m` : null].filter(Boolean).join(' · ')
}

/** Skupine po mesecih (seznam je že od najnovejše), npr. »September 2026«. */
export function byMonth(list: readonly Activity[]): { key: string; label: string; items: Activity[] }[] {
  const out: { key: string; label: string; items: Activity[] }[] = []
  for (const a of list) {
    const key = a.date.slice(0, 7)
    let g = out[out.length - 1]
    if (!g || g.key !== key) {
      const m = MONTHS_SL[+key.slice(5, 7) - 1] || ''
      g = { key, label: `${m.charAt(0).toUpperCase()}${m.slice(1)} ${key.slice(0, 4)}`, items: [] }
      out.push(g)
    }
    g.items.push(a)
  }
  return out
}

/** (v3.49) Iskanje brez šumnikov in velikih črk: »vrsic« najde »Vršič«. */
const fold = (s: string) => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd')
/** mesec v rodilniku (»12. maja 2025«) — iskanje po obeh oblikah */
const MONTHS_GEN = ['januarja', 'februarja', 'marca', 'aprila', 'maja', 'junija', 'julija', 'avgusta', 'septembra', 'oktobra', 'novembra', 'decembra']
const SPORT_WORDS: Record<string, string> = { kolo: 'kolo voznja', tek: 'tek', pohod: 'hoja pohod hribi', moc: 'moc', plavanje: 'plavanje', drugo: 'drugo' }
/**
 * (v3.49) Iskanje po vadbah: ime, opomba, mesec in leto (»maj 2025«), datum (»12. 5.«), šport. Vse besede morajo
 * biti najdene (»maj 2025« = samo maj 2025).
 */
export function filterActs<T extends Pick<Activity, 'date' | 'name' | 'sport'> & { notes?: string | null }>(list: readonly T[], q: string): T[] {
  const words = fold(q).split(/[\s,]+/).filter(Boolean)
  if (!words.length) return [...list]
  return list.filter(a => {
    const m = +a.date.slice(5, 7) - 1, d = +a.date.slice(8, 10)
    const hay = fold([a.name || '', a.notes || '', MONTHS_SL[m] || '', MONTHS_GEN[m] || '', a.date.slice(0, 4), `${d}.${m + 1}.`, a.date, SPORT_WORDS[a.sport] || ''].join(' '))
    return words.every(w => hay.includes(w.replace(/\.$/, '')))
  })
}

type Group = ReturnType<typeof byMonth>[number]
type Sum = ReturnType<typeof monthSums> extends Map<string, infer V> ? V : never
/**
 * (v3.49) En mesec seznama. Memo: »Pokaži več« izriše samo nove kartice (prej vsakič vse — 160 → 625 ms).
 * Skupina je iz vseh vadb (isti predmet, dokler se seznam ne spremeni), `shown` pove, koliko je vidnih.
 */
const MonthGroup = memo(function MonthGroup({ g, shown, sum, today, onOpen }: { g: Group; shown: number; sum: Sum | undefined; today: string; onOpen: (id: string) => void }) {
  return (
    <div className="act-month stack" style={{ gap: 9 }}>
      <h2 className="h4 act-head" style={{ fontSize: rem(11), margin: '6px 2px 0' }}><span>{g.label}</span>{sum ? <span className="sum">{monthLine(sum)}</span> : null}</h2>
      {g.items.slice(0, shown).map(a => {
        const ok = aiAllowed(a)
        return (
          <Card key={a.id} tight className="sess">
            <div className="bar" style={{ background: kindColor(a.sport) }} />
            <div className="row" style={{ gap: 12, paddingLeft: 4, alignItems: 'flex-start' }}>
              <button type="button" className="act-open" style={{ flex: 1, minWidth: 0 }} onClick={() => onOpen(a.id)} aria-label={`Odpri: ${a.name}, ${dmy(a.date, today)}`}>
                <div className="between"><b style={{ fontSize: rem(14), minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.name}</b><span className="muted" style={{ fontSize: rem(12), flex: 'none' }}>{dmy(a.date, today)}</span></div>
                <div className="muted" style={{ fontSize: rem(12) }}>{[a.distKm ? unit(num(a.distKm), 'km') : null, fmtDur(a.durationMin), a.elevM ? unit(num(a.elevM, 0), 'm') : null, a.avgHr ? `utrip ${a.avgHr}` : null, a.avgPower ? unit(a.avgPower, 'W') : null, a.tss ? unit(a.tss, 'TSS') : null].filter(Boolean).join(' · ')}</div>
                {a.exercises?.length ? <div className="muted" style={{ fontSize: rem(11.5), marginTop: 3 }}>{a.exercises.map(e => `${e.name} ${e.sets}×${e.reps}${e.kg ? ' @ ' + unit(num(e.kg), 'kg') : ''}`).join(' · ')}</div> : null}
                <div className="row" style={{ gap: 6, marginTop: 6, flexWrap: 'wrap' }}>
                  {!ok && <Chip sm>{sourceLabel(a)} · trener ne vidi</Chip>}
                  {a.planDayId && <Chip sm>iz načrta</Chip>}
                  {a.polyline && <Chip sm>sled</Chip>}
                  {a.originHint === 'STRAVA' && <Chip sm>Strava izvor</Chip>}
                  {rpeLabel(a.rpe) && <Chip sm>občutek: {rpeLabel(a.rpe)}</Chip>}
                  {a.notes && <Chip sm>opomba</Chip>}
                </div>
              </button>
            </div>
          </Card>
        )
      })}
    </div>
  )
})

export function Aktivnosti() {
  const app = useApp()
  const route = useRoute()
  const hidden = useHidden()
  const [open, setOpen] = useState(route.params.nova === '1')
  // (v3.51) »?nova=1« in »?datum=« iz naslova po odprtju stran — osvežitev ali Nazaj ne odpre spet praznega ročnega vnosa
  useEffect(() => { if (route.params.nova || route.params.datum) replaceParams({ nova: null, datum: null }, 'aktivnosti') }, [])   // eslint-disable-line react-hooks/exhaustive-deps
  const [limit, setLimit] = useState(PAGE)
  const [sport, setSport] = useState<Sport | 'vse'>('vse')
  const [q, setQ] = useState('')
  const [openId, setOpenId] = useState<string | null>(null)
  // načrt po meri brez kolesa: »vadbe«, ne »vožnje« (v3.48)
  const p = app.profile
  const noBike = isCustom(p) && !p.focus?.sports.includes('kolo')
  const s0 = p.focus?.sports[0]
  const emptyKind = !noBike ? 'kolo' : s0 === 'tek' ? 'tek' : s0 === 'hribi' ? 'pohod' : 'moc'
  // (v3.50) »Vpiši ročno« s slike: dan je že izbran (datum in šport tistega dne v načrtu)
  const day0 = /^\d{4}-\d{2}-\d{2}$/.test(route.params.datum || '') && route.params.datum! <= todayIso() ? route.params.datum! : todayIso()
  // sveže stanje (po shranitvi je današnja seja že opravljena — naslednji vnos je ne ponudi znova)
  const planFor = (sport: Sport, date: string) => (getState().plan ?? app.plan).find(d => d.date === date && !d.done && (d.kind === sport || (d.kind === 'test' && sport === 'kolo')))
  /** (v3.51) moč: vaje, ime in minute iz seje moči tistega dne (sicer ena prazna vrstica) — tudi ob odprtju in po shranitvi */
  const exFor = (date: string) => { const pd = planFor('moc', date); return (pd?.exercises || [{ name: '', sets: 3, reps: '8–12' }]).map(e => ({ name: e.name, sets: String(e.sets), reps: e.reps, kg: 'kg' in e && e.kg ? String(e.kg) : '' })) }
  const blankOf = (sport: Sport, date: string) => {
    const pd = sport === 'moc' ? planFor('moc', date) : null
    return { sport, date, name: pd?.title ?? '', dist: '', min: pd?.durationMin ? String(pd.durationMin) : '', elev: '', hr: '', power: '', kcal: '' }
  }
  const [f, setF] = useState(() => blankOf(defaultManualSport({ plan: app.plan, activities: app.activities, today: day0, fallback: emptyKind }), day0))
  const [ex, setEx] = useState<{ name: string; sets: string; reps: string; kg: string }[]>(() => (f.sport === 'moc' ? exFor(day0) : []))
  // (v3.50) »vpiši trajanje ali razdaljo« pod poljem, ne kot obvestilo
  const [needErr, setNeedErr] = useState(false)
  // aktivnost, ki čaka na izbris (»Razveljavi«), je takoj skrita
  const all = useMemo(() => app.activities.filter(a => !hidden.has('act:' + a.id)), [app.activities, hidden])
  const seen = all.filter(aiAllowed).length
  // filter po športu: samo športi, ki jih res imaš (in »Vse«, ko jih je več)
  const sportsHere = SPORTS.filter(s => all.some(a => a.sport === s.k))
  const acts = useMemo(() => filterActs(sport === 'vse' ? all : all.filter(a => a.sport === sport), q), [all, sport, q])
  const sums = useMemo(() => monthSums(acts), [acts])
  // (v3.49) skupine iz vseh vadb (isti predmeti ob »Pokaži več«), vidnih le prvih `limit`
  const allGroups = useMemo(() => byMonth(acts), [acts])
  const groups: { g: Group; shown: number }[] = []
  for (let i = 0, left = limit; i < allGroups.length && left > 0; i++) { const g = allGroups[i]!; groups.push({ g, shown: Math.min(left, g.items.length) }); left -= g.items.length }
  // ročni vnos: sporočilo pod poljem po odhodu iz polja ali ob »Shrani« (v3.48)
  const [aTouched, setATouched] = useState<Partial<Record<ActivityKey, boolean>>>({})
  const fl = manualFields(f.sport)
  // skrita polja (npr. km pri moči) se ne preverjajo in ne shranijo
  // (v3.51) s športom še hitrost (300 km v 60 min je tipkarska napaka)
  const aErr = manualActivityErrors({ min: f.min, hr: f.hr, kcal: f.kcal, ...(fl.dist ? { dist: f.dist } : {}), ...(fl.elev ? { elev: f.elev } : {}), ...(fl.power ? { power: f.power } : {}) }, f.sport)
  // (v3.51) vaje: serije 1–10, kilogrami 0–400 (prej 9 999 kg shranjeno, 12 serij tiho 8)
  const exErr = f.sport === 'moc' ? exerciseErrors(ex) : []
  const [exShown, setExShown] = useState(false)
  const aShown = (Object.keys(aErr) as ActivityKey[]).filter(k => aTouched[k])
  const ax = (k: ActivityKey) => {
    const bad = aShown.includes(k) || (needErr && (k === 'min' || k === 'dist'))
    return { min: ACTIVITY_RANGE[k][0], max: ACTIVITY_RANGE[k][1], onBlur: () => setATouched(t => (t[k] ? t : { ...t, [k]: true })), 'aria-invalid': bad || undefined, 'aria-describedby': bad ? 'ak-err' : undefined, style: bad ? { borderColor: 'var(--warn)' } : undefined }
  }
  function pickSport(s: Sport) {
    setF({ ...f, sport: s })
    if (s === 'moc' && !ex.length) {
      const pd = planFor('moc', f.date)
      setEx(exFor(f.date))
      if (pd && !f.name) setF(x => ({ ...x, sport: s, name: pd.title, min: x.min || String(pd.durationMin) }))
    }
  }

  async function save() {
    // razponi (v3.48): −45 min, utrip 900 ali 5000 W se ne shranijo in ne odkljukajo dneva načrta
    if (Object.keys(aErr).length) { setATouched(t => ({ ...t, ...Object.fromEntries(Object.keys(aErr).map(k => [k, true])) })); document.getElementById(AK_ID[Object.keys(aErr)[0] as ActivityKey])?.focus(); return }
    if (exErr.length) { setExShown(true); document.getElementById('ak-ex-err')?.scrollIntoView?.({ block: 'nearest' }); return }
    const min = +f.min || null
    if (!min && !(fl.dist && f.dist)) { setNeedErr(true); document.getElementById('ak-min')?.focus(); return }
    const now = new Date().toISOString()
    const pd = planFor(f.sport, f.date)
    const exercises = f.sport === 'moc' ? ex.filter(e => e.name.trim()).map(e => ({ name: e.name.trim().slice(0, 40), sets: Math.max(1, Math.min(10, parseInt(e.sets) || 3)), reps: (e.reps.trim() || '8–12').slice(0, 14), kg: e.kg ? +e.kg.replace(',', '.') || null : null })) : undefined
    const dist = fl.dist && f.dist ? +f.dist.replace(',', '.') || null : null
    // (v3.51) ime brez vpisa kot pri uvozu: »Kolo 42 km«, »Moč 40 min« (prej »Vožnja«, »Moč«)
    const a: Activity = { id: uid(), source: 'manual', sport: f.sport, date: f.date, start: null, name: f.name.trim() || (f.sport === 'moc' && pd ? pd.title : autoName(f.sport, dist, min)),
      distKm: dist, durationMin: min, elevM: fl.elev && f.elev ? +f.elev : null, avgHr: f.hr ? +f.hr : null, avgPower: fl.power && f.power ? +f.power : null, kcal: f.kcal ? +f.kcal : null,
      speedKmh: dist && min ? +(dist / (min / 60)).toFixed(1) : null, tss: null, polyline: null, exercises, ...deriveFlags('manual'), createdAt: now, updatedAt: now }
    a.tss = estimateTss(a, app.profile)
    const r = await addActivities([a])
    if (!r.added && !r.upgraded) { toast('Ta vadba je že vpisana (isti dan, šport in podobno trajanje).', 'info', 6000); return }
    if (pd) await setPlanDone(pd.id, true, a.id)
    setOpen(false); toast(pd ? `Shranjeno — »${pd.title}« označeno kot opravljeno.` : 'Vadba shranjena.', 'ok', 5000)
    // (v3.50) naslednji vnos začne s tem športom (prej spet »Kolo«)
    setF(blankOf(f.sport, todayIso())); setEx(f.sport === 'moc' ? exFor(todayIso()) : []); setATouched({}); setNeedErr(false); setExShown(false)
  }
  /** Izbris z »Razveljavi«: kartica takoj izgine, iz shrambe gre čez 5 s. */
  const remove = (a: Activity) => deferDelete('act:' + a.id, `Izbrisano: ${a.name}`, () => removeActivity(a.id))

  return (<>
    {/* (v3.50) povsod »vadba« (prej »40 aktivnosti« · »4 vadbe« · »Še ni treningov« · »Aktivnost shranjena«) */}
    <Head hi={`${count(all.length, W.vadba)}${seen < all.length ? ` · trener vidi ${seen}` : ''}`} nm="Aktivnosti" />
    <div className="scroll">
      {!all.length ? (
        <Empty icon={noBike ? <span style={{ color: 'var(--accent-fg)', display: 'inline-flex' }}><KindIcon kind={emptyKind} size={30} /></span> : <IcoBike width={30} height={30} style={{ color: 'var(--accent-fg)' }} />} title="Še ni vadb" text={noBike ? 'Poveži uro ali naloži datoteke — načrt se prilagodi temu, kar si res naredil.' : 'Poveži uro prek intervals.icu ali naloži datoteke — načrt se bo prilagodil temu, kar si res odpeljal.'}>
          <div className="row" style={{ gap: 8, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Btn primary sm onClick={() => navigate('uvoz')}>{noBike ? 'Uvozi vadbe' : 'Uvozi vožnje'}</Btn>
            <Btn ghost sm onClick={() => setOpen(true)}>Vpiši ročno</Btn>
          </div>
        </Empty>
      ) : (<>
        <div className="row" style={{ gap: 8, paddingBottom: 12 }}><Btn primary sm onClick={() => navigate('uvoz')}><IcoUpload width={16} height={16} /> Uvozi</Btn><Btn ghost sm onClick={() => setOpen(true)}>Ročno</Btn></div>
        {all.length > PAGE / 4 && (
          <div className="field" style={{ paddingBottom: 10 }}>
            <input type="search" value={q} onChange={e => { setQ(e.target.value); setLimit(PAGE) }} placeholder="Išči vadbo (ime, opomba, mesec)" aria-label="Išči vadbo (ime, opomba, mesec)" enterKeyHint="search" />
          </div>
        )}
        {sportsHere.length > 1 && (
          <div className="row" role="group" aria-label="Pokaži šport" style={{ gap: 6, paddingBottom: 12, flexWrap: 'wrap' }}>
            <Chip sm on={sport === 'vse'} onClick={() => { setSport('vse'); setLimit(PAGE) }}>Vse</Chip>
            {sportsHere.map(s => <Chip key={s.k} sm on={sport === s.k} onClick={() => { setSport(s.k); setLimit(PAGE) }}>{s.l}</Chip>)}
          </div>
        )}
        <div className="stack" style={{ gap: 9 }}>
          {groups.map(({ g, shown }) => <MonthGroup key={g.key} g={g} shown={shown} sum={sums.get(g.key)} today={app.today} onOpen={setOpenId} />)}
          {q.trim() && !acts.length && <p className="muted" style={{ fontSize: rem(13), textAlign: 'center', margin: '8px 0' }}>Nobena vadba ne ustreza »{q.trim()}«.</p>}
          {acts.length > limit && <Btn ghost sm style={{ alignSelf: 'center', marginTop: 4 }} onClick={() => setLimit(limit + PAGE)}>Pokaži več · še {acts.length - limit}</Btn>}
        </div>
      </>)}
    </div>
    {openId && <ActivitySheet id={openId} onClose={() => setOpenId(null)} onDelete={remove} />}
    <Sheet open={open} onClose={() => setOpen(false)} label="Ročni vnos">
      <b style={{ fontSize: rem(17), letterSpacing: '-.02em' }}>Ročni vnos</b>
      <div className="row" style={{ gap: 7, flexWrap: 'wrap', margin: '12px 0' }}>{SPORTS.map(s => <Chip key={s.k} sm on={f.sport === s.k} onClick={() => pickSport(s.k)}>{s.l}</Chip>)}</div>
      <div className="stack" style={{ gap: 10 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div className="field"><label htmlFor="ak-date">Datum</label><DateField id="ak-date" compact value={f.date} max={todayIso()} onChange={v => setF({ ...f, date: v })} label="Datum" /></div>
          <div className="field"><label htmlFor="ak-min">Trajanje <span className="unit">min</span></label><input id="ak-min" type="number" inputMode="numeric" value={f.min} onChange={e => { setF({ ...f, min: e.target.value }); setNeedErr(false) }} {...ax('min')} /></div>
          {/* pri moči in plavanju samo polja, ki tam kaj pomenijo (v3.48) */}
          {fl.dist && <div className="field"><label htmlFor="ak-km">Razdalja <span className="unit">km</span></label><DecimalInput id="ak-km" step={0.1} value={f.dist} onChange={e => { setF({ ...f, dist: e.target.value }); setNeedErr(false) }} {...ax('dist')} /></div>}
          {fl.elev && <div className="field"><label htmlFor="ak-elev">Vzpon <span className="unit">m</span></label><input id="ak-elev" type="number" inputMode="numeric" value={f.elev} onChange={e => setF({ ...f, elev: e.target.value })} {...ax('elev')} /></div>}
          <div className="field"><label htmlFor="ak-hr">Povp. utrip</label><input id="ak-hr" type="number" inputMode="numeric" value={f.hr} onChange={e => setF({ ...f, hr: e.target.value })} {...ax('hr')} /></div>
          {fl.power && <div className="field"><label htmlFor="ak-w">Povp. moč <span className="unit">W</span></label><input id="ak-w" type="number" inputMode="numeric" value={f.power} onChange={e => setF({ ...f, power: e.target.value })} {...ax('power')} /></div>}
          <div className="field"><label htmlFor="ak-kcal">Kalorije <span className="unit">z ure, neobvezno</span></label><input id="ak-kcal" type="number" inputMode="numeric" value={f.kcal} onChange={e => setF({ ...f, kcal: e.target.value })} {...ax('kcal')} /></div>
        </div>
        {(aShown.length > 0 || needErr) && <div id="ak-err" role="alert" style={{ fontSize: rem(12), color: 'var(--warn)', lineHeight: 1.45 }}>{[needErr ? (fl.dist ? 'Vpiši trajanje (min) ali razdaljo (km).' : 'Vpiši trajanje (min).') : null, ...aShown.map(k => aErr[k])].filter(Boolean).join(' ')}</div>}
        {f.sport === 'moc' && (
          <div className="field"><label>Vaje <span className="unit">ime · serije · ponovitve · kg</span></label>
            <div className="stack" style={{ gap: 6 }}>
              {ex.map((e, i) => (
                // ime čez celo širino, pod njim serije · ponovitve · kg (v3.48: prej 70 px — »Bolgarski počep« se ni videl)
                <div key={i} className="exrow ex2">
                  <input className="ex-name" value={e.name} onChange={x => setEx(ex.map((y, j) => j === i ? { ...y, name: x.target.value } : y))} placeholder="vaja" aria-label="Vaja" />
                  <input value={e.sets} inputMode="numeric" onChange={x => setEx(ex.map((y, j) => j === i ? { ...y, sets: x.target.value } : y))} aria-label="Serije" aria-invalid={(exShown && exerciseErrors([{ ...e, kg: '' }]).length > 0) || undefined} aria-describedby={exShown && exErr.length ? 'ak-ex-err' : undefined} />
                  <input value={e.reps} onChange={x => setEx(ex.map((y, j) => j === i ? { ...y, reps: x.target.value } : y))} aria-label="Ponovitve" />
                  <input value={e.kg} inputMode="decimal" placeholder="kg" onChange={x => setEx(ex.map((y, j) => j === i ? { ...y, kg: x.target.value } : y))} aria-label="Kilogrami" aria-invalid={(exShown && exerciseErrors([{ ...e, sets: '' }]).length > 0) || undefined} aria-describedby={exShown && exErr.length ? 'ak-ex-err' : undefined} />
                  <button className="chip sm click" onClick={() => setEx(ex.filter((_, j) => j !== i))} aria-label="Odstrani vajo">×</button>
                </div>
              ))}
              <button className="chip sm click" style={{ alignSelf: 'flex-start' }} onClick={() => setEx([...ex, { name: '', sets: '3', reps: '8–12', kg: '' }])}>+ vaja</button>
            </div>
            {exShown && exErr.length > 0 && <div id="ak-ex-err" role="alert" style={{ fontSize: rem(12), color: 'var(--warn)', lineHeight: 1.45, marginTop: 6 }}>{exErr.join(' ')}</div>}
            <div className="muted" style={{ fontSize: rem(11.5) }}>Vpiši, kar si res naredil — naslednja seja iste vrste dvigne ponovitve.</div>
          </div>
        )}
        <div className="field"><label htmlFor="ak-name">Ime <span className="unit">neobvezno</span></label><input id="ak-name" value={f.name} onChange={e => setF({ ...f, name: e.target.value })} placeholder="npr. Vršič" /></div>
      </div>
      <Btn primary block style={{ marginTop: 14 }} onClick={save}>Shrani</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={() => setOpen(false)}>Prekliči</Btn>
    </Sheet>
  </>)
}
