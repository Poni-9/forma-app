import { useState } from 'react'
import { Head } from '@/app/Shell'
import { navigate, useRoute } from '@/app/router'
import { useApp, addActivities, removeActivity, setPlanDone, toast } from '@/state/store'
import { aiAllowed, sourceLabel } from '@/domain/import/provenance'
import { estimateTss, fmtDur, todayIso } from '@/domain/training/load'
import type { Activity, Sport } from '@/domain/types'
import { Card, Chip, Btn, Sheet, Empty, kindColor } from '@/ui/primitives'
import { IcoBike, IcoUpload, IcoPlus } from '@/ui/icons'
import { deriveFlags } from '@/domain/import/provenance'
import { DateField } from '@/ui/DateField'

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
const SPORTS: { k: Sport; l: string }[] = [{ k: 'kolo', l: 'Kolo' }, { k: 'tek', l: 'Tek' }, { k: 'pohod', l: 'Hoja' }, { k: 'moc', l: 'Moč' }, { k: 'plavanje', l: 'Plavanje' }, { k: 'drugo', l: 'Drugo' }]

export function Aktivnosti() {
  const app = useApp()
  const route = useRoute()
  const [open, setOpen] = useState(route.params.nova === '1')
  const [f, setF] = useState({ sport: 'kolo' as Sport, date: todayIso(), name: '', dist: '', min: '', elev: '', hr: '', power: '', kcal: '' })
  const [ex, setEx] = useState<{ name: string; sets: string; reps: string; kg: string }[]>([])
  const seen = app.activities.filter(aiAllowed).length
  const planFor = (sport: Sport, date: string) => app.plan.find(d => d.date === date && !d.done && (d.kind === sport || (d.kind === 'test' && sport === 'kolo')))
  function pickSport(s: Sport) {
    setF({ ...f, sport: s })
    if (s === 'moc' && !ex.length) {
      const pd = planFor('moc', f.date)
      setEx((pd?.exercises || [{ name: '', sets: 3, reps: '8–12' }]).map(e => ({ name: e.name, sets: String(e.sets), reps: e.reps, kg: 'kg' in e && e.kg ? String(e.kg) : '' })))
      if (pd && !f.name) setF(x => ({ ...x, sport: s, name: pd.title, min: x.min || String(pd.durationMin) }))
    }
  }

  async function save() {
    const min = +f.min || null
    if (!min && !f.dist) { toast('Vpiši vsaj trajanje ali razdaljo.', 'err'); return }
    const now = new Date().toISOString()
    const pd = planFor(f.sport, f.date)
    const exercises = f.sport === 'moc' ? ex.filter(e => e.name.trim()).map(e => ({ name: e.name.trim().slice(0, 40), sets: Math.max(1, Math.min(8, parseInt(e.sets) || 3)), reps: (e.reps.trim() || '8–12').slice(0, 14), kg: e.kg ? +e.kg.replace(',', '.') || null : null })) : undefined
    const a: Activity = { id: uid(), source: 'manual', sport: f.sport, date: f.date, start: null, name: f.name.trim() || (f.sport === 'moc' && pd ? pd.title : ({ kolo: 'Vožnja', tek: 'Tek', pohod: 'Hoja', moc: 'Moč', plavanje: 'Plavanje', drugo: 'Aktivnost' })[f.sport]),
      distKm: f.dist ? +f.dist : null, durationMin: min, elevM: f.elev ? +f.elev : null, avgHr: f.hr ? +f.hr : null, avgPower: f.power ? +f.power : null, kcal: f.kcal ? +f.kcal : null,
      speedKmh: f.dist && min ? +((+f.dist) / (min / 60)).toFixed(1) : null, tss: null, polyline: null, exercises, ...deriveFlags('manual'), createdAt: now, updatedAt: now }
    a.tss = estimateTss(a, app.profile)
    const r = await addActivities([a])
    if (!r.added && !r.upgraded) { toast('Ta aktivnost je že vpisana (isti dan, šport in podobno trajanje).', 'info', 6000); return }
    if (pd) await setPlanDone(pd.id, true, a.id)
    setOpen(false); toast(pd ? `Shranjeno — »${pd.title}« označeno kot opravljeno.` : 'Aktivnost shranjena.', 'ok', 5000)
    setF({ sport: 'kolo', date: todayIso(), name: '', dist: '', min: '', elev: '', hr: '', power: '', kcal: '' }); setEx([])
  }

  return (<>
    <Head hi={`${app.activities.length} aktivnosti · trener vidi ${seen}`} nm="Aktivnosti" right={<button className="avatar" onClick={() => setOpen(true)} aria-label="Dodaj"><IcoPlus /></button>} />
    <div className="scroll">
      <div className="row" style={{ gap: 8, paddingBottom: 12 }}><Btn primary sm onClick={() => navigate('uvoz')}><IcoUpload width={16} height={16} /> Uvozi</Btn><Btn ghost sm onClick={() => setOpen(true)}>Ročno</Btn></div>
      {!app.activities.length ? (
        <Empty icon={<IcoBike width={30} height={30} style={{ color: 'var(--accent)' }} />} title="Še ni treningov" text="Poveži uro prek intervals.icu ali odloži datoteke — načrt se bo prilagodil temu, kar si res odpeljal.">
          <Btn primary sm onClick={() => navigate('uvoz')}>Uvozi vožnje</Btn>
        </Empty>
      ) : (
        <div className="stack" style={{ gap: 9 }}>
          {app.activities.map(a => {
            const ok = aiAllowed(a)
            return (
              <Card key={a.id} tight className="sess">
                <div className="bar" style={{ background: kindColor(a.sport) }} />
                <div className="row" style={{ gap: 12, paddingLeft: 4 }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div className="between"><b style={{ fontSize: 14, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.name}</b><span className="muted" style={{ fontSize: 12, flex: 'none' }}>{a.date.slice(8)}. {+a.date.slice(5, 7)}.</span></div>
                    <div className="muted" style={{ fontSize: 12 }}>{[a.distKm ? `${a.distKm} km` : null, fmtDur(a.durationMin), a.elevM ? `${a.elevM} m` : null, a.avgHr ? `utrip ${a.avgHr}` : null, a.avgPower ? `${a.avgPower} W` : null, a.tss ? `${a.tss} TSS` : null].filter(Boolean).join(' · ')}</div>
                    {a.exercises?.length ? <div className="muted" style={{ fontSize: 11.5, marginTop: 3 }}>{a.exercises.map(e => `${e.name} ${e.sets}×${e.reps}${e.kg ? ' @' + e.kg : ''}`).join(' · ')}</div> : null}
                    <div className="row" style={{ gap: 6, marginTop: 6, flexWrap: 'wrap' }}>
                      <Chip sm ok={ok}>{sourceLabel(a)} · {ok ? 'trener vidi' : 'trener ne vidi'}</Chip>
                      {a.polyline && <Chip sm>sled</Chip>}
                      {a.originHint === 'STRAVA' && <Chip sm>Strava izvor</Chip>}
                    </div>
                  </div>
                  <button className="chip sm click" onClick={() => { if (confirm('Izbrišem to aktivnost?')) removeActivity(a.id) }} aria-label="Izbriši">×</button>
                </div>
              </Card>
            )
          })}
        </div>
      )}
    </div>
    <Sheet open={open} onClose={() => setOpen(false)}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Ročni vnos</b>
      <div className="row" style={{ gap: 7, flexWrap: 'wrap', margin: '12px 0' }}>{SPORTS.map(s => <Chip key={s.k} sm on={f.sport === s.k} onClick={() => pickSport(s.k)}>{s.l}</Chip>)}</div>
      <div className="stack" style={{ gap: 10 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div className="field"><label>Datum</label><DateField compact value={f.date} max={todayIso()} onChange={v => setF({ ...f, date: v })} label="Datum" /></div>
          <div className="field"><label>Trajanje <span className="unit">min</span></label><input type="number" inputMode="numeric" value={f.min} onChange={e => setF({ ...f, min: e.target.value })} /></div>
          <div className="field"><label>Razdalja <span className="unit">km</span></label><input type="number" inputMode="decimal" step={0.1} value={f.dist} onChange={e => setF({ ...f, dist: e.target.value })} /></div>
          <div className="field"><label>Vzpon <span className="unit">m</span></label><input type="number" inputMode="numeric" value={f.elev} onChange={e => setF({ ...f, elev: e.target.value })} /></div>
          <div className="field"><label>Povp. utrip</label><input type="number" inputMode="numeric" value={f.hr} onChange={e => setF({ ...f, hr: e.target.value })} /></div>
          <div className="field"><label>Povp. moč <span className="unit">W</span></label><input type="number" inputMode="numeric" value={f.power} onChange={e => setF({ ...f, power: e.target.value })} /></div>
          <div className="field"><label>Kalorije <span className="unit">z ure, neobvezno</span></label><input type="number" inputMode="numeric" value={f.kcal} onChange={e => setF({ ...f, kcal: e.target.value })} /></div>
        </div>
        {f.sport === 'moc' && (
          <div className="field"><label>Vaje <span className="unit">ime · serije · ponovitve · kg</span></label>
            <div className="stack" style={{ gap: 6 }}>
              {ex.map((e, i) => (
                <div key={i} className="exrow" style={{ display: 'grid', gridTemplateColumns: '1fr 44px 70px 50px 26px', gap: 5 }}>
                  <input value={e.name} onChange={x => setEx(ex.map((y, j) => j === i ? { ...y, name: x.target.value } : y))} placeholder="vaja" />
                  <input value={e.sets} inputMode="numeric" onChange={x => setEx(ex.map((y, j) => j === i ? { ...y, sets: x.target.value } : y))} />
                  <input value={e.reps} onChange={x => setEx(ex.map((y, j) => j === i ? { ...y, reps: x.target.value } : y))} />
                  <input value={e.kg} inputMode="decimal" placeholder="kg" onChange={x => setEx(ex.map((y, j) => j === i ? { ...y, kg: x.target.value } : y))} />
                  <button className="chip sm click" onClick={() => setEx(ex.filter((_, j) => j !== i))} aria-label="Odstrani">×</button>
                </div>
              ))}
              <button className="chip sm click" style={{ alignSelf: 'flex-start' }} onClick={() => setEx([...ex, { name: '', sets: '3', reps: '8–12', kg: '' }])}>+ vaja</button>
            </div>
            <div className="muted" style={{ fontSize: 11.5 }}>Vpiši, kar si res naredil — naslednja seja iste vrste dvigne ponovitve.</div>
          </div>
        )}
        <div className="field"><label>Ime <span className="unit">neobvezno</span></label><input value={f.name} onChange={e => setF({ ...f, name: e.target.value })} placeholder="npr. Vršič" /></div>
      </div>
      <Btn primary block style={{ marginTop: 14 }} onClick={save}>Shrani</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={() => setOpen(false)}>Prekliči</Btn>
    </Sheet>
  </>)
}
