import { Fragment, useMemo, useState } from 'react'
import { Head } from '@/app/Shell'
import { navigate, useRoute } from '@/app/router'
import { useApp, addActivities, removeActivity, setPlanDone, toast } from '@/state/store'
import { ActivitySheet } from '@/ui/ActivitySheet'
import { rpeLabel } from '@/domain/coach/rpe'
import { aiAllowed, sourceLabel } from '@/domain/import/provenance'
import { estimateTss, fmtDur, todayIso } from '@/domain/training/load'
import type { Activity, Sport } from '@/domain/types'
import { Card, Chip, Btn, Sheet, Empty, kindColor, MONTHS_SL, DecimalInput } from '@/ui/primitives'
import { IcoBike, IcoUpload, IcoPlus } from '@/ui/icons'
import { deriveFlags } from '@/domain/import/provenance'
import { DateField } from '@/ui/DateField'
import { deferDelete, useHidden } from '@/ui/Confirm'
import { count, dmy, int, num, unit, NBSP, W } from '@/ui/format'

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
const SPORTS: { k: Sport; l: string }[] = [{ k: 'kolo', l: 'Kolo' }, { k: 'tek', l: 'Tek' }, { k: 'pohod', l: 'Hoja' }, { k: 'moc', l: 'Moč' }, { k: 'plavanje', l: 'Plavanje' }, { k: 'drugo', l: 'Drugo' }]
/** Toliko aktivnosti izrišemo naenkrat (leto voženj je lahko več sto kartic). */
export const PAGE = 60

/** Seštevek po mesecih (ključ »2026-10«) iz VSEH vadb, ne le izrisanih: število, minute, km, vzpon. */
export function monthSums(list: readonly Activity[]): Map<string, { n: number; min: number; km: number; elev: number }> {
  const out = new Map<string, { n: number; min: number; km: number; elev: number }>()
  for (const a of list) {
    const k = a.date.slice(0, 7), m = out.get(k) || { n: 0, min: 0, km: 0, elev: 0 }
    m.n++; m.min += a.durationMin || 0; m.km += a.distKm || 0; m.elev += a.elevM || 0
    out.set(k, m)
  }
  return out
}
/** Vrstica seštevka meseca: »3 vadbe · 2 h 46 min · 54 km · 600 m«. */
export function monthLine(m: { n: number; min: number; km: number; elev: number }): string {
  return [count(m.n, W.vadba), m.min ? fmtDur(Math.round(m.min)) : null, m.km >= 1 ? `${int(Math.round(m.km))}${NBSP}km` : null, m.elev >= 50 ? `${int(Math.round(m.elev))}${NBSP}m` : null].filter(Boolean).join(' · ')
}

/** Skupine po mesecih (seznam je že od najnovejše), npr. »September 2026«. */
export function byMonth(list: readonly Activity[]): { key: string; label: string; items: Activity[] }[] {
  const out: { key: string; label: string; items: Activity[] }[] = []
  for (const a of list) {
    const key = a.date.slice(0, 7)
    let g = out[out.length - 1]
    if (!g || g.key !== key) {
      const m = MONTHS_SL[+key.slice(5, 7) - 1] || ''
      g = { key, label: `${m.charAt(0).toUpperCase()}${m.slice(1)} ${key.slice(0, 4)}`, items: [] }
      out.push(g)
    }
    g.items.push(a)
  }
  return out
}

export function Aktivnosti() {
  const app = useApp()
  const route = useRoute()
  const hidden = useHidden()
  const [open, setOpen] = useState(route.params.nova === '1')
  const [limit, setLimit] = useState(PAGE)
  const [sport, setSport] = useState<Sport | 'vse'>('vse')
  const [openId, setOpenId] = useState<string | null>(null)
  const [f, setF] = useState({ sport: 'kolo' as Sport, date: todayIso(), name: '', dist: '', min: '', elev: '', hr: '', power: '', kcal: '' })
  const [ex, setEx] = useState<{ name: string; sets: string; reps: string; kg: string }[]>([])
  // aktivnost, ki čaka na izbris (»Razveljavi«), je takoj skrita
  const all = useMemo(() => app.activities.filter(a => !hidden.has('act:' + a.id)), [app.activities, hidden])
  const seen = all.filter(aiAllowed).length
  // filter po športu: samo športi, ki jih res imaš (in »Vse«, ko jih je več)
  const sportsHere = SPORTS.filter(s => all.some(a => a.sport === s.k))
  const acts = useMemo(() => (sport === 'vse' ? all : all.filter(a => a.sport === sport)), [all, sport])
  const sums = useMemo(() => monthSums(acts), [acts])
  const groups = useMemo(() => byMonth(acts.slice(0, limit)), [acts, limit])
  const planFor = (sport: Sport, date: string) => app.plan.find(d => d.date === date && !d.done && (d.kind === sport || (d.kind === 'test' && sport === 'kolo')))
  function pickSport(s: Sport) {
    setF({ ...f, sport: s })
    if (s === 'moc' && !ex.length) {
      const pd = planFor('moc', f.date)
      setEx((pd?.exercises || [{ name: '', sets: 3, reps: '8–12' }]).map(e => ({ name: e.name, sets: String(e.sets), reps: e.reps, kg: 'kg' in e && e.kg ? String(e.kg) : '' })))
      if (pd && !f.name) setF(x => ({ ...x, sport: s, name: pd.title, min: x.min || String(pd.durationMin) }))
    }
  }

  async function save() {
    const min = +f.min || null
    if (!min && !f.dist) { toast('Vpiši vsaj trajanje ali razdaljo.', 'err'); return }
    const now = new Date().toISOString()
    const pd = planFor(f.sport, f.date)
    const exercises = f.sport === 'moc' ? ex.filter(e => e.name.trim()).map(e => ({ name: e.name.trim().slice(0, 40), sets: Math.max(1, Math.min(8, parseInt(e.sets) || 3)), reps: (e.reps.trim() || '8–12').slice(0, 14), kg: e.kg ? +e.kg.replace(',', '.') || null : null })) : undefined
    const dist = f.dist ? +f.dist.replace(',', '.') || null : null
    const a: Activity = { id: uid(), source: 'manual', sport: f.sport, date: f.date, start: null, name: f.name.trim() || (f.sport === 'moc' && pd ? pd.title : ({ kolo: 'Vožnja', tek: 'Tek', pohod: 'Hoja', moc: 'Moč', plavanje: 'Plavanje', drugo: 'Aktivnost' })[f.sport]),
      distKm: dist, durationMin: min, elevM: f.elev ? +f.elev : null, avgHr: f.hr ? +f.hr : null, avgPower: f.power ? +f.power : null, kcal: f.kcal ? +f.kcal : null,
      speedKmh: dist && min ? +(dist / (min / 60)).toFixed(1) : null, tss: null, polyline: null, exercises, ...deriveFlags('manual'), createdAt: now, updatedAt: now }
    a.tss = estimateTss(a, app.profile)
    const r = await addActivities([a])
    if (!r.added && !r.upgraded) { toast('Ta aktivnost je že vpisana (isti dan, šport in podobno trajanje).', 'info', 6000); return }
    if (pd) await setPlanDone(pd.id, true, a.id)
    setOpen(false); toast(pd ? `Shranjeno — »${pd.title}« označeno kot opravljeno.` : 'Aktivnost shranjena.', 'ok', 5000)
    setF({ sport: 'kolo', date: todayIso(), name: '', dist: '', min: '', elev: '', hr: '', power: '', kcal: '' }); setEx([])
  }
  /** Izbris z »Razveljavi«: kartica takoj izgine, iz shrambe gre čez 5 s. */
  const remove = (a: Activity) => deferDelete('act:' + a.id, `Izbrisano: ${a.name}`, () => removeActivity(a.id))

  return (<>
    <Head hi={`${count(all.length, W.aktivnost)} · trener vidi ${seen}`} nm="Aktivnosti" right={<button className="avatar" onClick={() => setOpen(true)} aria-label="Dodaj aktivnost"><IcoPlus /></button>} />
    <div className="scroll">
      {!all.length ? (
        <Empty icon={<IcoBike width={30} height={30} style={{ color: 'var(--accent-fg)' }} />} title="Še ni treningov" text="Poveži uro prek intervals.icu ali odloži datoteke — načrt se bo prilagodil temu, kar si res odpeljal.">
          <div className="row" style={{ gap: 8, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Btn primary sm onClick={() => navigate('uvoz')}>Uvozi vožnje</Btn>
            <Btn ghost sm onClick={() => setOpen(true)}>Vpiši ročno</Btn>
          </div>
        </Empty>
      ) : (<>
        <div className="row" style={{ gap: 8, paddingBottom: 12 }}><Btn primary sm onClick={() => navigate('uvoz')}><IcoUpload width={16} height={16} /> Uvozi</Btn><Btn ghost sm onClick={() => setOpen(true)}>Ročno</Btn></div>
        {sportsHere.length > 1 && (
          <div className="row" role="group" aria-label="Pokaži šport" style={{ gap: 6, paddingBottom: 12, flexWrap: 'wrap' }}>
            <Chip sm on={sport === 'vse'} onClick={() => { setSport('vse'); setLimit(PAGE) }}>Vse</Chip>
            {sportsHere.map(s => <Chip key={s.k} sm on={sport === s.k} onClick={() => { setSport(s.k); setLimit(PAGE) }}>{s.l}</Chip>)}
          </div>
        )}
        <div className="stack" style={{ gap: 9 }}>
          {groups.map(g => (
            <Fragment key={g.key}>
              <h2 className="h4 act-head" style={{ fontSize: 11, margin: '6px 2px 0' }}><span>{g.label}</span>{sums.get(g.key) ? <span className="sum">{monthLine(sums.get(g.key)!)}</span> : null}</h2>
              {g.items.map(a => {
                const ok = aiAllowed(a)
                return (
                  <Card key={a.id} tight className="sess">
                    <div className="bar" style={{ background: kindColor(a.sport) }} />
                    <div className="row" style={{ gap: 12, paddingLeft: 4, alignItems: 'flex-start' }}>
                      <button type="button" className="act-open" style={{ flex: 1, minWidth: 0 }} onClick={() => setOpenId(a.id)} aria-label={`Odpri: ${a.name}, ${dmy(a.date, app.today)}`}>
                        <div className="between"><b style={{ fontSize: 14, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.name}</b><span className="muted" style={{ fontSize: 12, flex: 'none' }}>{dmy(a.date, app.today)}</span></div>
                        <div className="muted" style={{ fontSize: 12 }}>{[a.distKm ? unit(num(a.distKm), 'km') : null, fmtDur(a.durationMin), a.elevM ? unit(num(a.elevM, 0), 'm') : null, a.avgHr ? `utrip ${a.avgHr}` : null, a.avgPower ? unit(a.avgPower, 'W') : null, a.tss ? unit(a.tss, 'TSS') : null].filter(Boolean).join(' · ')}</div>
                        {a.exercises?.length ? <div className="muted" style={{ fontSize: 11.5, marginTop: 3 }}>{a.exercises.map(e => `${e.name} ${e.sets}×${e.reps}${e.kg ? ' @ ' + unit(num(e.kg), 'kg') : ''}`).join(' · ')}</div> : null}
                        <div className="row" style={{ gap: 6, marginTop: 6, flexWrap: 'wrap' }}>
                          <Chip sm ok={ok}>{sourceLabel(a)} · {ok ? 'trener vidi' : 'trener ne vidi'}</Chip>
                          {a.polyline && <Chip sm>sled</Chip>}
                          {a.originHint === 'STRAVA' && <Chip sm>Strava izvor</Chip>}
                          {rpeLabel(a.rpe) && <Chip sm>občutek: {rpeLabel(a.rpe)}</Chip>}
                          {a.notes && <Chip sm>opomba</Chip>}
                        </div>
                      </button>
                      <button className="chip sm click" onClick={() => remove(a)} aria-label={`Izbriši: ${a.name}, ${dmy(a.date, app.today)}`}>×</button>
                    </div>
                  </Card>
                )
              })}
            </Fragment>
          ))}
          {acts.length > limit && <Btn ghost sm style={{ alignSelf: 'center', marginTop: 4 }} onClick={() => setLimit(limit + PAGE)}>Pokaži več · še {acts.length - limit}</Btn>}
        </div>
      </>)}
    </div>
    {openId && <ActivitySheet id={openId} onClose={() => setOpenId(null)} onDelete={remove} />}
    <Sheet open={open} onClose={() => setOpen(false)} label="Ročni vnos">
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Ročni vnos</b>
      <div className="row" style={{ gap: 7, flexWrap: 'wrap', margin: '12px 0' }}>{SPORTS.map(s => <Chip key={s.k} sm on={f.sport === s.k} onClick={() => pickSport(s.k)}>{s.l}</Chip>)}</div>
      <div className="stack" style={{ gap: 10 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div className="field"><label>Datum</label><DateField compact value={f.date} max={todayIso()} onChange={v => setF({ ...f, date: v })} label="Datum" /></div>
          <div className="field"><label htmlFor="ak-min">Trajanje <span className="unit">min</span></label><input id="ak-min" type="number" inputMode="numeric" value={f.min} onChange={e => setF({ ...f, min: e.target.value })} /></div>
          <div className="field"><label htmlFor="ak-km">Razdalja <span className="unit">km</span></label><DecimalInput id="ak-km" step={0.1} value={f.dist} onChange={e => setF({ ...f, dist: e.target.value })} /></div>
          <div className="field"><label htmlFor="ak-elev">Vzpon <span className="unit">m</span></label><input id="ak-elev" type="number" inputMode="numeric" value={f.elev} onChange={e => setF({ ...f, elev: e.target.value })} /></div>
          <div className="field"><label htmlFor="ak-hr">Povp. utrip</label><input id="ak-hr" type="number" inputMode="numeric" value={f.hr} onChange={e => setF({ ...f, hr: e.target.value })} /></div>
          <div className="field"><label htmlFor="ak-w">Povp. moč <span className="unit">W</span></label><input id="ak-w" type="number" inputMode="numeric" value={f.power} onChange={e => setF({ ...f, power: e.target.value })} /></div>
          <div className="field"><label htmlFor="ak-kcal">Kalorije <span className="unit">z ure, neobvezno</span></label><input id="ak-kcal" type="number" inputMode="numeric" value={f.kcal} onChange={e => setF({ ...f, kcal: e.target.value })} /></div>
        </div>
        {f.sport === 'moc' && (
          <div className="field"><label>Vaje <span className="unit">ime · serije · ponovitve · kg</span></label>
            <div className="stack" style={{ gap: 6 }}>
              {ex.map((e, i) => (
                <div key={i} className="exrow" style={{ display: 'grid', gridTemplateColumns: '1fr 44px 70px 50px 26px', gap: 5 }}>
                  <input value={e.name} onChange={x => setEx(ex.map((y, j) => j === i ? { ...y, name: x.target.value } : y))} placeholder="vaja" aria-label="Vaja" />
                  <input value={e.sets} inputMode="numeric" onChange={x => setEx(ex.map((y, j) => j === i ? { ...y, sets: x.target.value } : y))} aria-label="Serije" />
                  <input value={e.reps} onChange={x => setEx(ex.map((y, j) => j === i ? { ...y, reps: x.target.value } : y))} aria-label="Ponovitve" />
                  <input value={e.kg} inputMode="decimal" placeholder="kg" onChange={x => setEx(ex.map((y, j) => j === i ? { ...y, kg: x.target.value } : y))} aria-label="Kilogrami" />
                  <button className="chip sm click" onClick={() => setEx(ex.filter((_, j) => j !== i))} aria-label="Odstrani vajo">×</button>
                </div>
              ))}
              <button className="chip sm click" style={{ alignSelf: 'flex-start' }} onClick={() => setEx([...ex, { name: '', sets: '3', reps: '8–12', kg: '' }])}>+ vaja</button>
            </div>
            <div className="muted" style={{ fontSize: 11.5 }}>Vpiši, kar si res naredil — naslednja seja iste vrste dvigne ponovitve.</div>
          </div>
        )}
        <div className="field"><label htmlFor="ak-name">Ime <span className="unit">neobvezno</span></label><input id="ak-name" value={f.name} onChange={e => setF({ ...f, name: e.target.value })} placeholder="npr. Vršič" /></div>
      </div>
      <Btn primary block style={{ marginTop: 14 }} onClick={save}>Shrani</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={() => setOpen(false)}>Prekliči</Btn>
    </Sheet>
  </>)
}
