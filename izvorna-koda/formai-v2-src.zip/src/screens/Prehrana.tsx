import { FuelTimeline, drinkLine } from '@/ui/FuelTimeline'
import { useEffect, useMemo, useRef, useState } from 'react'
import { Head } from '@/app/Shell'
import { navigate, useRoute } from '@/app/router'
import { useApp, getState, addMeal, removeMeal, setMenu, toast } from '@/state/store'
import { snapOf } from '@/state/snap'
import { useAi } from '@/ui/useAi'
import { MealInput } from '@/ui/MealInput'
import { useCountUp } from '@/ui/motion'
import { mealFromPhoto, mealFromText, fridgeMeals, mealIdeas, weekMenu, type Suggestion } from '@/domain/ai/actions'
import { dailyTarget, sumMeals, profileComplete, targetParts } from '@/domain/nutrition/energy'
import { addDays, weekStartIso } from '@/domain/training/load'
import type { MealEntry, WeekMenu } from '@/domain/types'
import { aiAllowed } from '@/domain/import/provenance'
import { dayMealPlan, rideFuel, fuelCtxOf, adjustToEaten } from '@/domain/nutrition/dayplan'
import { raceSoon } from '@/domain/nutrition/race'
import { FuelLogSheet, fuelLogOf } from '@/ui/FuelLog'
import { slotAt, timeForSlot, byTime, photoTime, hhmm, TYPICAL, SLOT_ACC } from '@/domain/nutrition/slots'
import { Card, Chip, Ring, Track, Btn, Sheet, Empty, fmtKcal, fmtDateLong, DAYS_SL } from '@/ui/primitives'
import { BarChart } from '@/ui/charts'
import { HealthNote } from '@/ui/HealthNote'
import { deferDelete, useHidden } from '@/ui/Confirm'
import { takeMealPhoto } from '@/ui/mealPhoto'
import { NBSP, nb, num, dayName, dm } from '@/ui/format'
import { sameMealBefore, normSaid } from '@/domain/nutrition/same'
import { IcoBreakfast, IcoLunch, IcoDrink, IcoFood, IcoPlus, IcoBack, IcoCamera, IcoWarn, IcoCheck, IcoInfo, IcoSpark } from '@/ui/icons'
import { isCustom } from '@/domain/focus/model'

const SLOTS: { key: MealEntry['slot']; label: string; Ico: typeof IcoFood }[] = [
  { key: 'zajtrk', label: 'Zajtrk', Ico: IcoBreakfast }, { key: 'malica', label: 'Malica', Ico: IcoBreakfast }, { key: 'kosilo', label: 'Kosilo', Ico: IcoLunch },
  { key: 'med_vadbo', label: 'Med vožnjo', Ico: IcoDrink }, { key: 'vecerja', label: 'Večerja', Ico: IcoLunch }, { key: 'drugo', label: 'Drugo', Ico: IcoFood },
]
/** Načrt po meri: »Med vadbo« namesto »Med vožnjo«. */
const slotsFor = (custom: boolean) => (custom ? SLOTS.map(s => (s.key === 'med_vadbo' ? { ...s, label: 'Med vadbo' } : s)) : SLOTS)
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
type Draft = { id: string | null; slot: MealEntry['slot']; name: string; kcal: string; prot: string; carb: string; fat: string; grams: string; thumb: string | null; conf: MealEntry['confidence']; source: MealEntry['source']; time: string | null; createdAt: string | null; /** ročno izbran obrok / ura — potem se drugo ne spreminja samo */ slotSet?: boolean; timeSet?: boolean; /** opis z besedilom/glasom: ocena po sestavinah, morebitno vprašanje AI in opis za »Oceni znova« */ items?: MealEntry['items']; question?: string | null; desc?: string; /** številke iz tvojega obroka z istim opisom (datum) — brez nove AI ocene */ prevFrom?: string }
/** Nov vpis: obrok po uri (danes zdaj), za pretekli dan kosilo ob tipični uri. */
const empty = (isToday: boolean): Draft => { const t = isToday ? hhmm() : null; return { id: null, slot: t ? slotAt(t) : 'kosilo', name: '', kcal: '', prot: '', carb: '', fat: '', grams: '', thumb: null, conf: null, source: 'manual', time: t, createdAt: null } }
/** Hitri popravek količine: pol, za polovico več, dvojno — preračuna kalorije, grame, makrohranila in sestavine. */
const QTY: [number, string, string][] = [[0.5, '½', 'Pol količine'], [1.5, '1½', 'Za polovico več'], [2, '2×', 'Dvojna količina']]
export function scaleDraft<T extends { kcal: string; grams: string; prot: string; carb: string; fat: string; items?: MealEntry['items'] }>(d: T, f: number): T {
  const sc = (v: string) => (v.trim() === '' || !Number.isFinite(+v.replace(',', '.')) ? v : String(Math.round(+v.replace(',', '.') * f)))
  const tag = f === 0.5 ? '½' : f === 1.5 ? '1½' : `${f}`
  return { ...d, kcal: sc(d.kcal), grams: sc(d.grams), prot: sc(d.prot), carb: sc(d.carb), fat: sc(d.fat), items: d.items ? d.items.map(it => ({ ...it, kcal: Math.round(it.kcal * f), qty: `${it.qty ? it.qty + ' ' : ''}×${tag}` })) : d.items }
}
const fromMeal = (m: MealEntry): Draft => ({ id: m.id, slot: m.slot, name: m.name, kcal: String(m.kcal), prot: m.proteinG != null ? String(m.proteinG) : '', carb: m.carbsG != null ? String(m.carbsG) : '', fat: m.fatG != null ? String(m.fatG) : '', grams: m.grams != null ? String(m.grams) : '', thumb: m.thumb || null, conf: m.confidence || null, source: m.source, time: m.time || null, createdAt: m.createdAt, slotSet: true, timeSet: !!m.time, items: m.items || null })
/** Vrstica, ki je v resnici gumb (dostopno s tipkovnico), a izgleda kot besedilo. */
const ROW_BTN: React.CSSProperties = { background: 'none', border: 0, padding: 0, margin: 0, textAlign: 'left', font: 'inherit', color: 'inherit', cursor: 'pointer' }
export type MenuDay = WeekMenu['days'][number] & { belowFloor?: boolean }
/**
 * Dan jedilnika pod spodnjo varno mejo — nikoli ga ne ponudimo kot načrt dneva. Zastavica iz AI dejanja
 * (low/belowFloor), razen če je dan že dopolnjen (addKcal); sicer primerjava z mejo.
 */
export function menuDayLow(x: MenuDay, floor: number | null): boolean {
  const topped = (x.addKcal ?? 0) > 0
  return (!!(x.low || x.belowFloor) && !topped) || (floor != null && x.kcal > 0 && x.kcal < floor)
}

export function Prehrana() {
  const app = useApp()
  const SL = slotsFor(isCustom(app.profile))
  const ai = useAi()
  const route = useRoute()
  const hidden = useHidden()
  const { profile: p, today, plan, activities, settings } = app
  const [day, setDay] = useState<string>(route.params.dan && route.params.dan <= today ? route.params.dan : today)
  const isToday = day === today
  // obrok, ki čaka na izbris (»Razveljavi«), je takoj skrit in ne šteje
  const visible = (m: MealEntry) => !hidden.has('meal:' + m.id)
  const meals = (isToday ? app.mealsToday : app.recentMeals.filter(m => m.date === day)).filter(visible)
  const target = dailyTarget(p, activities.filter(a => a.date === day), plan.filter(d => d.date === day), day)
  // Za AI: cilj brez aktivnosti, ki jih AI ne sme videti (Strava) — niti posredno prek porabe kalorij
  const aiTarget = dailyTarget(p, activities.filter(a => a.date === day && aiAllowed(a)), plan.filter(d => d.date === day), day)
  const eaten = sumMeals(meals)
  const shownKcal = useCountUp(eaten.kcal)
  const [open, setOpen] = useState(false)
  const [d, setD] = useState<Draft>(() => empty(isToday))
  const nowSlot = isToday ? slotAt(hhmm()) : 'kosilo'
  /** izbira obroka: drug obrok kot zdaj (zajtrk popoldne) = vpis za nazaj → tipična ura, da gre v seznamu tja */
  const pickSlot = (slot: MealEntry['slot']) => setD(x => ({ ...x, slot, slotSet: true, time: x.timeSet ? x.time : isToday ? timeForSlot(slot, hhmm()) : TYPICAL[slot] }))
  /** ura: obrok se ji prilagodi, razen če si ga izbral sam */
  const pickTime = (time: string) => setD(x => ({ ...x, time, timeSet: true, slot: x.slotSet ? x.slot : slotAt(time) }))
  const [photoBusy, setPhotoBusy] = useState(false)
  const [textBusy, setTextBusy] = useState(false)
  const [ideas, setIdeas] = useState<{ title: string; seen?: string[]; list: Suggestion[] } | null>(null)
  const [menuOpen, setMenuOpen] = useState(false)
  const [busy, setBusy] = useState<string | null>(null)
  // načrt obrokov: danes najprej samo naslednji obrok (uporabnik: preveč naenkrat), cel dan ob tapu
  const [allMeals, setAllMeals] = useState(false)
  const [fuelOpen, setFuelOpen] = useState(false)
  // glavna vožnja dneva in gorivo zanjo (temperatura v oknu treninga, koliko običajno spiješ)
  const mainRide = plan.filter(x => x.date === day && (x.kind === 'kolo' || x.kind === 'test') && !x.optional).sort((a, b) => b.durationMin - a.durationMin)[0] || null
  const fctx = fuelCtxOf(app.weather, app.recentMeals, day, today)
  const rfDay = mainRide ? rideFuel(mainRide, p.fuelKit, fctx) : null
  const fuelLog = mainRide ? fuelLogOf(meals, mainRide) : null
  const evening = isToday && new Date().getHours() >= 18
  const fridgeRef = useRef<HTMLInputElement>(null)
  const remaining = target ? target.kcal - eaten.kcal : null
  const todayMain = plan.filter(x => x.date === today && x.kind !== 'pocitek' && !x.optional && !x.done).sort((a, b) => (a.kind === 'moc' ? 1 : 0) - (b.kind === 'moc' ? 1 : 0))[0]

  const frequent = useMemo(() => {
    const m = new Map<string, { n: number; meal: MealEntry }>()
    for (const x of app.recentMeals) { const k = x.name.trim().toLowerCase(); const e = m.get(k); if (e) { e.n++; e.meal = x } else m.set(k, { n: 1, meal: x }) }
    return [...m.values()].filter(x => x.n >= 2).sort((a, b) => b.n - a.n).slice(0, 6).map(x => x.meal)
  }, [app.recentMeals])

  const last7 = Array.from({ length: 7 }, (_, i) => addDays(today, -6 + i))
  const bars = last7.map(x => { const k = (x === today ? app.mealsToday : app.recentMeals.filter(m => m.date === x)).filter(visible).reduce((s, m) => s + m.kcal, 0); return { label: DAYS_SL[(new Date(x).getDay() + 6) % 7]!, value: k, color: x === day ? 'var(--accent-fg)' : 'var(--t-kolo)' } })
  const logged = bars.filter(b => b.value > 0)
  const avgKcal = logged.length ? Math.round(logged.reduce((s, b) => s + b.value, 0) / logged.length) : 0
  const menu = settings.menu && settings.menu.weekStart === weekStartIso(today) ? settings.menu : null
  const menuDay = (menu?.days.find(x => x.date === day) || null) as MenuDay | null
  /** Spodnja varna meja dneva jedilnika (BMR / 1500 / 1200 + načrtovan trening). */
  const floorOf = (x: MenuDay) => x.floorKcal ?? dailyTarget(p, [], plan.filter(q => q.date === x.date), x.date)?.floor ?? null
  const topped = (x: MenuDay) => (x.addKcal ?? 0) > 0
  const below = (x: MenuDay) => menuDayLow(x, floorOf(x))

  async function save() {
    const k = Math.round(+d.kcal || 0)
    if (!d.name.trim() || !k) { toast('Vpiši vsaj ime in kalorije.', 'err'); return }
    const orig = d.id ? meals.find(m => m.id === d.id) : undefined     // ohrani polja, ki jih obrazec ne kaže (vpis goriva)
    await addMeal({ ...(orig || {}), id: d.id || uid(), date: day, time: d.time || (isToday ? hhmm() : TYPICAL[d.slot]), slot: d.slot, name: d.name.trim(), grams: d.grams ? +d.grams : null, kcal: k, proteinG: d.prot ? +d.prot : null, carbsG: d.carb ? +d.carb : null, fatG: d.fat ? +d.fat : null, confidence: d.conf, source: d.source, thumb: d.thumb, items: d.items && d.items.length ? d.items : null, said: d.desc ? normSaid(d.desc) : orig?.said ?? null, createdAt: d.createdAt || new Date().toISOString() })
    setOpen(false)
    toast(d.id ? 'Popravljeno.' : 'Dodano.', 'ok')
  }
  async function fromPhoto(file: File) {
    setPhotoBusy(true)
    // profil ob klicu (po privolitvi je nov), ne iz izrisa
    const m = await ai.run(() => mealFromPhoto(getState().profile, file, aiTarget ? aiTarget.kcal - eaten.kcal : null, aiTarget ? aiTarget.proteinG - eaten.p : null))
    setPhotoBusy(false)
    if (!m) return
    // ura posnetka (EXIF ali čas datoteke iz galerije) → obrok po uri; brez tega zdaj
    const time = photoTime(day, today, m.photo, file.lastModified || null)
    const { photo: _ph, ...meal } = m
    void _ph
    setD({ ...fromMeal({ ...meal, date: day, time, slot: time ? slotAt(time) : meal.slot }), id: null, slotSet: false, timeSet: !!time })
    setOpen(true)
  }
  /** Opis z besedilom ali glasom → AI oceni po sestavinah → preveri in shrani (vse številke je mogoče popraviti). */
  async function fromText(desc: string, force = false) {
    // isto kot zadnjič: tvoje številke (morda popravljene), brez nove ocene — AI ocena se lahko vsakič razlikuje
    const prev = force ? null : sameMealBefore([...app.mealsToday, ...app.recentMeals], desc)
    if (prev) {
      const time = isToday ? hhmm() : TYPICAL[prev.slot]
      setD({ ...fromMeal({ ...prev, date: day, time, thumb: null }), id: null, createdAt: null, slot: isToday ? slotAt(time!) : prev.slot, slotSet: false, timeSet: false, desc, prevFrom: prev.date, question: null })
      setOpen(true)
      return
    }
    setTextBusy(true)
    const m = await ai.run(() => mealFromText(getState().profile, desc, aiTarget ? aiTarget.kcal - eaten.kcal : null, aiTarget ? aiTarget.proteinG - eaten.p : null))
    setTextBusy(false)
    if (!m) return
    const { question, aiSlot, ...meal } = m
    // za pretekli dan: obrok in ura iz opisa ali tipična ura obroka
    const time = isToday ? meal.time || hhmm() : aiSlot ? TYPICAL[meal.slot] : null
    setD({ ...fromMeal({ ...meal, date: day, time, slot: aiSlot ? meal.slot : time ? slotAt(time) : 'kosilo' }), id: null, slotSet: aiSlot, timeSet: isToday && !!meal.time && meal.time !== hhmm(), question, desc })
    setOpen(true)
  }
  // »Slikaj obrok« na Danes: slika je že izbrana, tu jo preberemo
  useEffect(() => { const f = takeMealPhoto(); if (f) void fromPhoto(f) }, [])   // eslint-disable-line react-hooks/exhaustive-deps
  async function fridge(file: File) {
    setBusy('fridge')
    const r = await ai.run(() => fridgeMeals(getState().profile, file, aiTarget ? aiTarget.kcal - eaten.kcal : null, aiTarget ? aiTarget.proteinG - eaten.p : null, todayMain?.title || null))
    setBusy(null)
    if (r) setIdeas({ title: 'Kaj naj skuham', seen: r.seen, list: r.ideas })
  }
  async function suggest() {
    if (!target || !aiTarget) return
    setBusy('ideas')
    const r = await ai.run(() => mealIdeas(snapOf(getState()), Math.max(300, aiTarget.kcal - eaten.kcal), aiTarget.proteinG - eaten.p))
    setBusy(null)
    if (r) setIdeas({ title: 'Predlogi za preostanek dneva', list: r })
  }
  async function makeMenu() {
    if (!target || !aiTarget) return
    setBusy('menu')
    const base = dailyTarget(p, [], [], today)
    const r = await ai.run(() => weekMenu(snapOf(getState()), base ? base.kcal : aiTarget.kcal, aiTarget.proteinG, frequent.map(f => f.name)))
    setBusy(null)
    if (r) { await setMenu(r); setMenuOpen(true); toast('Jedilnik in nakupovalni seznam sta pripravljena.', 'ok') }
  }
  async function logIdea(s: Suggestion) {
    await addMeal({ id: uid(), date: day, time: isToday ? hhmm() : TYPICAL[nowSlot], slot: nowSlot, name: s.name, grams: null, kcal: s.kcal, proteinG: s.proteinG, carbsG: s.carbsG, fatG: s.fatG, confidence: 'srednja', source: 'suggest', thumb: null, createdAt: new Date().toISOString() })
    toast(`${s.name} vpisano.`, 'ok')
  }
  async function repeat(m: MealEntry) {
    await addMeal({ ...m, id: uid(), date: day, time: isToday ? hhmm() : TYPICAL[m.slot], slot: isToday ? nowSlot : m.slot, thumb: null, createdAt: new Date().toISOString(), fluidMl: null, planMl: null, forDay: null, fuel: null })
    toast(`${m.name} dodano.`, 'ok')
  }
  /** Izbris z »Razveljavi«: obrok takoj izgine, iz shrambe gre čez 5 s. */
  const remove = (m: MealEntry) => deferDelete('meal:' + m.id, `Izbrisano: ${m.name}`, () => removeMeal(m.id))
  const busyIs = (k: string) => busy === k && ai.busy

  // seznam dneva po času (kot je bilo pojedeno), ne po vrsti obroka
  const timeline = [...meals].sort(byTime).map(m => ({ m, g: SL.find(s => s.key === m.slot) || SL[SL.length - 1]! }))
  const menuLines = (x: MenuDay) => ([['Zajtrk', x.zajtrk], ['Kosilo', x.kosilo], ['Malica', x.malica], ['Večerja', x.vecerja]] as const).filter(y => y[1])

  return (<>
    <Head hi={fmtDateLong(day)} nm="Prehrana" />
    <div className="scroll">
      <div className="cols">
      <div className="col">
      <div className="between" style={{ marginBottom: 12 }}>
        <button className="chip sm click" disabled={day <= addDays(today, -90)} onClick={() => day > addDays(today, -90) && setDay(addDays(day, -1))}><IcoBack width={13} height={13} /> prejšnji</button>
        {!isToday && <button className="chip sm click on" onClick={() => setDay(today)}>danes</button>}
        <button className="chip sm click" disabled={isToday} style={{ opacity: isToday ? 0.35 : 1 }} onClick={() => !isToday && setDay(addDays(day, 1))}>naslednji <IcoBack width={13} height={13} style={{ transform: 'scaleX(-1)' }} /></button>
      </div>

      {!profileComplete(p) ? (
        <Empty icon={<IcoFood width={30} height={30} style={{ color: 'var(--ok)' }} />} title="Za kalorije rabim tvoj profil" text="Višina, teža, starost in spol. Brez tega ti številke ne pokažem — raje prazno kot narobe.">
          <Btn sm onClick={() => navigate('nastavitve')}>Izpolni profil</Btn>
        </Empty>
      ) : target && (
        <Card className="page">
          <div className="ring-wrap">
            <Ring size={118} stroke={11} pct={eaten.kcal / target.kcal}><div><b className="num">{fmtKcal(Math.round(shownKcal))}</b><small>od {fmtKcal(target.kcal)}{NBSP}kcal</small></div></Ring>
            <div className="macro">
              <div className="m"><div className="t"><span>Beljakovine</span><span>{Math.round(eaten.p)} / {target.proteinG}{NBSP}g</span></div><Track pct={eaten.p / target.proteinG * 100} color="var(--accent)" /></div>
              <div className="m"><div className="t"><span>Ogljikovi hidrati</span><span>{Math.round(eaten.c)} / {target.carbsG}{NBSP}g</span></div><Track pct={eaten.c / Math.max(1, target.carbsG) * 100} color="var(--ink-3)" /></div>
              <div className="m"><div className="t"><span>Maščobe</span><span>{Math.round(eaten.f)} / {target.fatG}{NBSP}g</span></div><Track pct={eaten.f / Math.max(1, target.fatG) * 100} color="var(--ink-3)" /></div>
            </div>
          </div>
          <div className="between" style={{ marginTop: 15, paddingTop: 13, borderTop: '1px solid var(--line)' }}>
            <div style={{ fontSize: 12, color: 'var(--ink-3)', fontWeight: 600, minWidth: 0 }}>
              <DayBalance remaining={remaining} proteinLeft={Math.round(target.proteinG - eaten.p)} past={day < today} logged={meals.length > 0} />
            </div>
            <Chip sm ok={!target.clampedToFloor}>{target.minor ? 'Vzdrževanje' : target.clampedToFloor ? 'Spodnja meja' : 'Varno'}</Chip>
          </div>
          {target.clampedToFloor && !target.minor && <div className="muted" style={{ fontSize: 11.5, marginTop: 8 }}>Cilj je na spodnji varni meji ({fmtKcal(target.floor)}{NBSP}kcal) — nižje ne gre, tudi če bi izračun tako pokazal.</div>}
          <details className="more">
            <summary>Kako je izračunan cilj</summary>
            <div>Cilj = {targetParts(target, p)}.{target.deficit > 0 ? ` Deficit danes ${fmtKcal(target.deficit)}${NBSP}kcal${target.deficitNote ? ` (${target.deficitNote})` : ''} — samo pri obrokih, nikoli ${SL === SLOTS ? 'na kolesu' : 'med vadbo'}.` : target.deficitNote ? ` Brez deficita: ${target.deficitNote}.` : ''}</div>
          </details>
          {evening && remaining != null && remaining > 600 && <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>Če si sit, ne jej na silo — zvečer raje nekaj z beljakovinami in OH (skuta z banano, jogurt, kakav). Šteje tedensko povprečje, ne en dan.{mainRide?.done && !fuelLog && rfDay?.totalCarbs ? ' Vpiši tudi, kaj si popil in pojedel na kolesu — tudi to so kalorije.' : ''}</div>}
          <HealthNote kind="food" />
        </Card>
      )}

      <div style={{ marginTop: 12 }}>
        <MealInput forDay={isToday ? null : `${dayName(day).toLowerCase()}, ${dm(day)}`} onText={t => void fromText(t)} onPhoto={f => void fromPhoto(f)} busy={photoBusy ? 'photo' : textBusy ? 'text' : null} autoFocus={route.params.opis === '1'} onError={msg => toast(msg, 'err', 7000)} />
      </div>

      <div className="between" style={{ margin: '17px 0 10px' }}><h2 className="h4" style={{ margin: 0 }}>{isToday ? 'Danes' : fmtDateLong(day)}</h2><span className="row" style={{ gap: 8 }}><span className="muted" style={{ fontSize: 12, fontWeight: 700 }}>{fmtKcal(eaten.kcal)}{NBSP}kcal · {Math.round(eaten.p)}{NBSP}g B</span><button className="chip sm click" onClick={() => { setD(empty(isToday)); setOpen(true) }}><IcoPlus width={12} height={12} /> vpiši</button></span></div>
      <div className="stack stagger" style={{ gap: 9 }}>
        {timeline.map(({ m, g }) => (
          <Card key={m.id} tight className="row" style={{ gap: 12 }}>
            {m.thumb ? <img src={m.thumb} alt="" width={36} height={36} style={{ borderRadius: 'var(--r-s)', objectFit: 'cover', flex: 'none' }} /> : <div style={{ width: 36, height: 36, borderRadius: 'var(--r-s)', background: 'var(--raised)', display: 'grid', placeItems: 'center', flex: 'none', color: 'var(--ink-2)' }}><g.Ico width={18} height={18} /></div>}
            <button type="button" style={{ ...ROW_BTN, flex: 1, minWidth: 0 }} aria-label={`Uredi: ${m.name}`} onClick={() => { if (m.forDay && mainRide && m.forDay === mainRide.id && rfDay) { setFuelOpen(true); return } setD(fromMeal(m)); setOpen(true) }}>
              <b style={{ fontSize: 14, display: 'block' }}>{g.label}{m.time ? <span className="muted" style={{ fontWeight: 600, fontSize: 12 }}> · {m.time}</span> : null}</b>
              <span className="muted clamp2" style={{ fontSize: 12 }}>{m.name}{m.grams ? ` · ${m.grams}${NBSP}g` : ''}{m.proteinG != null ? ` · B ${m.proteinG}${NBSP}g` : ''}{m.confidence === 'nizka' ? ' · ocena' : ''}</span>
            </button>
            <b style={{ fontSize: 14, flex: 'none' }}>{fmtKcal(m.kcal)}</b>
            <button className="chip sm click" onClick={() => remove(m)} aria-label={`Izbriši: ${m.name}`}>×</button>
          </Card>
        ))}
        <button type="button" className="card tight row" style={{ gap: 12, borderStyle: 'dashed', color: 'var(--ink-3)', cursor: 'pointer', textAlign: 'left', width: '100%' }} onClick={() => { setD(empty(isToday)); setOpen(true) }}>
          <div style={{ width: 36, height: 36, borderRadius: 'var(--r-s)', border: '1px dashed var(--line)', display: 'grid', placeItems: 'center', flex: 'none' }}><IcoPlus width={16} height={16} /></div>
          <div style={{ flex: 1, minWidth: 0 }}><b style={{ fontSize: 14, color: 'var(--ink-2)' }}>Dodaj {isToday ? SLOT_ACC[nowSlot] : 'obrok'}</b><div style={{ fontSize: 12 }}>{isToday && remaining != null && remaining > 0 ? `Ostane ti ${fmtKcal(remaining)}${NBSP}kcal` : 'Vpiši, kar si pojedel'}</div></div>
        </button>
      </div>

      </div>
      <div className="col">
      {target && (() => {
        const main = mainRide
        // čez dan: preostali obroki se prilagodijo pojedenemu in vpisanemu gorivu na kolesu
        const dp0 = dayMealPlan(p, target, main, { ...fctx, race: raceSoon(p, day) })
        // vožnja je za nami (označena ali pripeljana z ure): nevpisano gorivo na kolesu šteje 0, ne »po načrtu«
        const rideDone = !!main && (!!main.done || activities.some(a => a.date === day && a.sport === 'kolo' && (a.durationMin || 0) >= main.durationMin * 0.5))
        const dp = isToday ? adjustToEaten(dp0, meals, target.kcal, { rideDone }) : dp0
        const rf = rfDay
        const bySlot = (sl: string) => meals.filter(m => m.slot === sl).reduce((a, m) => a + m.kcal, 0)
        const gotOf = (sl: (typeof dp.slots)[number]) => sl.got ?? bySlot(sl.slot)
        const next = dp.slots.find(sl => gotOf(sl) < sl.kcal * 0.85) ?? null
        const short = isToday && !allMeals
        const slots = short ? (next ? [next] : []) : dp.slots
        const bikeShown = !!dp.onBike && !!main && (!short || !rideDone)
        return (
          <Card style={{ marginTop: 12 }}>
            <div className="between"><h2 className="h4" style={{ margin: 0 }}>{short ? 'Naslednji obrok po načrtu' : isToday ? 'Danes jej po načrtu' : 'Načrt obrokov za ta dan'}</h2><span className="muted" style={{ fontSize: 12, fontWeight: 700, flex: 'none' }}>{short ? `dan ${fmtKcal(dp.total)}${NBSP}kcal` : `${fmtKcal(dp.total)}${NBSP}kcal`}</span></div>
            {short && !next && <p style={{ fontSize: 12.5, marginTop: 8, color: 'var(--ink-2)' }}>Vsi obroki po načrtu so za danes pojedeni.</p>}
            {dp.race && <div style={{ marginTop: 8, padding: '9px 11px', borderRadius: 12, background: 'var(--raised)', border: '1px solid var(--line)', fontSize: 12.5, color: 'var(--ink-2)' }}><b style={{ color: 'var(--warn)' }}>Malo vlaknin pred tekmo</b><div style={{ marginTop: 3 }}>{nb(dp.tip)}</div></div>}
            <div className="stack" style={{ gap: 0, marginTop: 8 }}>
              {slots.map(sl => { const got = gotOf(sl); return (
                <div key={sl.key} style={{ padding: '9px 0', borderTop: '1px solid var(--line)' }}>
                  <div className="between" style={{ fontSize: 13 }}><b style={{ color: 'var(--ink)', minWidth: 0 }}>{sl.label} <span className="muted" style={{ fontWeight: 600, fontSize: 11.5 }}>· {sl.when}</span></b><span style={{ fontWeight: 800, flex: 'none', color: got >= sl.kcal * 0.85 ? 'var(--ok)' : 'var(--ink)' }}>{got ? `${fmtKcal(got)} / ` : ''}{fmtKcal(sl.kcal)}{NBSP}kcal</span></div>
                  <div className="muted" style={{ fontSize: 12, marginTop: 2 }}>~{sl.proteinG}{NBSP}g beljakovin · ~{sl.carbsG}{NBSP}g ogljikovih hidratov</div>
                  <div style={{ fontSize: 12.5, marginTop: 3, color: 'var(--ink-2)' }}>npr. {nb(sl.example)}</div>
                </div>) })}
              {bikeShown && dp.onBike && main && <div style={{ padding: '9px 0', borderTop: '1px solid var(--line)' }}>
                <div className="between" style={{ fontSize: 13 }}><b style={{ color: 'var(--ink)', minWidth: 0 }}>Na kolesu <span className="muted" style={{ fontWeight: 600, fontSize: 11.5 }}>· {main.title}</span></b><span style={{ fontWeight: 800, flex: 'none' }}>{dp.onBike.carbs}{NBSP}g OH</span></div>
                {rf && <>
                  <div style={{ fontSize: 12.5, marginTop: 3, color: 'var(--ink-2)' }}>Vzemi: {nb(rf.items.join(' · '))}</div>
                  <div className="muted" style={{ fontSize: 12, marginTop: 3 }}>{nb(rf.cues.length ? drinkLine(rf) : rf.schedule)} V dnevnem cilju je že upoštevano — v pojedeno se šteje, ko vpišeš, koliko si res porabil.</div>
                  <FuelTimeline rf={rf} minutes={main.durationMin} />
                  <div className="row" style={{ gap: 8, marginTop: 6, alignItems: 'center' }}>
                    <button className="chip sm click" onClick={() => setFuelOpen(true)}>{fuelLog ? 'uredi vpis' : 'vpiši, kaj si porabil'}</button>
                    {fuelLog && <span className="muted" style={{ fontSize: 12 }}>vpisano {fmtKcal(fuelLog.kcal)}{NBSP}kcal{fuelLog.fluidMl != null ? ` · ${num(Math.round(fuelLog.fluidMl / 50) * 50 / 1000, 2)}${NBSP}l` : ''}</span>}
                  </div>
                </>}
              </div>}
            </div>
            {isToday && <button type="button" className="chip sm click" style={{ marginTop: 10 }} aria-expanded={allMeals} onClick={() => setAllMeals(!allMeals)}>{allMeals ? 'samo naslednji obrok' : `cel dan po načrtu · ${dp.slots.length} ${dp.slots.length === 1 ? 'obrok' : dp.slots.length === 2 ? 'obroka' : dp.slots.length <= 4 ? 'obroki' : 'obrokov'} ›`}</button>}
            {dp.adjusted && <p style={{ fontSize: 12, marginTop: 8, color: 'var(--ink-2)' }}>Preostali obroki so prilagojeni temu, kar si danes že pojedel{meals.some(m => m.slot === 'med_vadbo') ? ' in porabil na kolesu' : ''}.{dp.short ? ` Do cilja manjka še ~${fmtKcal(dp.short)}${NBSP}kcal — če si sit, ne jej na silo.` : ''}</p>}
            <p className="muted" style={{ fontSize: 11.5, marginTop: 8 }}>{dp.race ? '' : `${nb(dp.tip)} `}Količine so okvirne — obroke vpiši ali slikaj, da vidiš, koliko še manjka.</p>
          </Card>
        )
      })()}

      {frequent.length > 0 && (
        <Card tight style={{ marginTop: 12 }}>
          <h2 className="h4" style={{ fontSize: 11 }}>Pogosto · en tap</h2>
          <div className="row" style={{ gap: 6, flexWrap: 'wrap', marginTop: 8 }}>
            {frequent.map(m => <button key={m.id} className="chip sm click" onClick={() => repeat(m)} style={{ maxWidth: '100%' }}><IcoPlus width={12} height={12} /><span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', minWidth: 0 }}>{m.name}</span><span className="muted">{fmtKcal(m.kcal)}</span></button>)}
          </div>
        </Card>
      )}

      {target && isToday && (
        <div className="row" style={{ gap: 8, marginTop: 12, flexWrap: 'wrap' }}>
          <Btn ghost sm disabled={ai.busy} onClick={suggest}>{busyIs('ideas') ? 'Razmišljam …' : 'Predlagaj obrok'}</Btn>
          <Btn ghost sm disabled={ai.busy} onClick={() => fridgeRef.current?.click()}><IcoCamera width={14} height={14} /> {busyIs('fridge') ? 'Gledam …' : 'Slikaj hladilnik'}</Btn>
          <input ref={fridgeRef} type="file" accept="image/*" capture="environment" style={{ display: 'none' }} onChange={e => { const f = e.target.files?.[0]; e.target.value = ''; if (f) void fridge(f) }} />
        </div>
      )}

      {menuDay ? (
        <button type="button" className="card tight" style={{ marginTop: 12, width: '100%', textAlign: 'left', cursor: 'pointer', display: 'block', borderColor: below(menuDay) ? 'var(--warn)' : undefined }} onClick={() => setMenuOpen(true)}>
          <div className="between"><h2 className="h4" style={{ fontSize: 11, margin: 0 }}>Jedilnik · {fmtKcal(menuDay.kcal)}{NBSP}kcal</h2><span className="muted" style={{ fontSize: 12, fontWeight: 700, flex: 'none' }}>teden in nakup ›</span></div>
          {below(menuDay) ? (
            // pod varno mejo: ne ponujamo ga kot načrt za ta dan
            <div className="row" style={{ gap: 8, marginTop: 8, alignItems: 'flex-start' }}>
              <IcoWarn width={15} height={15} aria-hidden="true" style={{ color: 'var(--warn)', flex: 'none', marginTop: 2 }} />
              <span style={{ fontSize: 12.5, color: 'var(--ink-2)' }}>Jedilnik za ta dan je pod tvojo varno mejo{floorOf(menuDay) ? ` (${fmtKcal(floorOf(menuDay)!)}${NBSP}kcal)` : ''} — ne jej po njem. Drži se načrta obrokov zgoraj ali sestavi jedilnik znova.</span>
            </div>
          ) : menuLines(menuDay).map(([l, t]) => <div key={l} style={{ fontSize: 12.5, marginTop: 5 }}><span className="muted">{l}</span> <span style={{ color: 'var(--ink)' }}>{t}</span></div>)}
        </button>
      ) : target && app.user && isToday ? (
        <div style={{ marginTop: 8 }}><Btn ghost sm disabled={ai.busy} onClick={makeMenu}>{busyIs('menu') ? 'Sestavljam jedilnik …' : 'Jedilnik za teden + nakupovalni seznam'}</Btn></div>
      ) : null}

      <Card style={{ marginTop: 14 }}>
        <div className="between"><h2 className="h4" style={{ margin: 0 }}>Zadnjih 7 dni</h2><span className="muted" style={{ fontSize: 11.5, fontWeight: 700 }}>{logged.length ? `povprečno ${fmtKcal(avgKcal)}${NBSP}kcal` : 'ni vnosov'}</span></div>
        <div style={{ marginTop: 10 }}><BarChart bars={bars} height={130} unit="kcal" /></div>
        {target && logged.length > 0 && <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>Cilj brez treninga {fmtKcal(dailyTarget(p, [], [], day)?.kcal || target.kcal)}{NBSP}kcal · zabeleženih {logged.length}/7 dni. Kar ni zabeleženo, trener ne vidi.</div>}
      </Card>
      </div>
      </div>
    </div>

    <Sheet open={open} onClose={() => setOpen(false)}>
      <div className="row" style={{ gap: 12 }}>
        {d.thumb && <img src={d.thumb} alt="" width={48} height={48} style={{ borderRadius: 'var(--r-s)', objectFit: 'cover' }} />}
        <div><b style={{ fontSize: 17, letterSpacing: '-.02em' }}>{d.id ? 'Uredi vnos' : d.source === 'photo' || d.source === 'text' ? 'Preveri in shrani' : 'Dodaj obrok'}</b>{d.conf && <div className="muted" style={{ fontSize: 12 }}>zanesljivost ocene: {d.conf}{d.grams ? ` · ${d.grams}${NBSP}g` : ''}</div>}</div>
      </div>
      {d.prevFrom && !d.id && (
        <div className="row prev-same" style={{ gap: 8, alignItems: 'center', marginTop: 10, flexWrap: 'wrap' }}>
          <span style={{ fontSize: 12.5, color: 'var(--ink-2)', flex: 1, minWidth: 160 }}>Kot zadnjič ({dm(d.prevFrom)}) — tvoje številke, brez nove ocene.</span>
          <button type="button" className="chip sm click" disabled={textBusy} onClick={() => { const t = d.desc || d.name; setOpen(false); void fromText(t, true) }}>Oceni z AI</button>
        </div>
      )}
      <div className="row" style={{ gap: 7, flexWrap: 'wrap', margin: '12px 0' }}>
        {SL.map(s => <Chip key={s.key} sm on={d.slot === s.key} onClick={() => pickSlot(s.key)}>{s.label}</Chip>)}
      </div>
      <div className="row" style={{ gap: 10, alignItems: 'center', margin: '-4px 0 12px' }}>
        <label className="muted" htmlFor="meal-time" style={{ fontSize: 12.5, fontWeight: 700 }}>Ura</label>
        <input id="meal-time" className="time-inp" type="time" value={d.time || ''} onChange={e => e.target.value && pickTime(e.target.value)} />
        <span className="muted" style={{ fontSize: 11.5 }}>{isToday && d.time && d.slot !== slotAt(hhmm()) && d.slot !== 'drugo' && d.slot !== 'med_vadbo' && !d.id ? 'vpis za nazaj' : 'obrok se ravna po uri'}</span>
      </div>
      <div className="stack" style={{ gap: 10 }}>
        {d.items && d.items.length > 0 && (
          <div>
            <div className="muted" style={{ fontSize: 11, fontWeight: 800, letterSpacing: '.06em', textTransform: 'uppercase' }}>Ocena po sestavinah</div>
            <div className="meal-items">{d.items.map((it, i) => <div key={i}><span>{it.name}{it.qty ? <span className="muted"> · {it.qty}</span> : null}</span><span>{fmtKcal(it.kcal)}{NBSP}kcal</span></div>)}</div>
          </div>
        )}
        {d.question && (
          <div className="row" style={{ gap: 8, alignItems: 'flex-start', padding: '10px 12px', borderRadius: 'var(--r-s)', background: 'var(--raised)' }}>
            <IcoInfo width={15} height={15} aria-hidden="true" style={{ color: 'var(--accent-fg)', flex: 'none', marginTop: 2 }} />
            <span style={{ fontSize: 12.5, color: 'var(--ink-2)' }}>{d.question} Dopiši v opis spodaj in oceni znova, ali popravi številke.</span>
          </div>
        )}
        {d.source === 'text' && !d.id && d.desc != null && (
          <div className="field"><label htmlFor="meal-desc2">Opis</label>
            <textarea id="meal-desc2" rows={2} value={d.desc} onChange={e => setD({ ...d, desc: e.target.value })} style={{ background: 'var(--card)', border: '1px solid var(--line)', borderRadius: 'var(--r-m)', padding: '12px 14px', color: 'var(--ink)', fontSize: 15, lineHeight: 1.45, resize: 'none', outline: 'none', width: '100%' }} />
            <div style={{ marginTop: 8 }}><Btn ghost sm disabled={textBusy || ai.busy || (d.desc || '').trim().length < 2} onClick={() => void fromText(d.desc || '')}><IcoSpark width={14} height={14} /> {textBusy ? 'Ocenjujem …' : 'Oceni znova'}</Btn></div>
          </div>
        )}
        <div className="field"><label htmlFor="meal-name">Kaj si jedel</label><input id="meal-name" value={d.name} onChange={e => setD({ ...d, name: e.target.value })} placeholder="npr. skuta z jagodami" autoFocus={!d.thumb && !d.id} /></div>
        {+d.kcal > 0 && (
          <div className="row" role="group" aria-label="Količina obroka" style={{ gap: 6, alignItems: 'center' }}>
            <span className="muted" style={{ fontSize: 12, fontWeight: 700, marginRight: 2 }}>Količina</span>
            {QTY.map(([f, l, al]) => <button key={l} type="button" className="chip sm click" aria-label={al} onClick={() => setD(scaleDraft(d, f))}>{l}</button>)}
          </div>
        )}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div className="field"><label htmlFor="meal-kcal">Kalorije <span className="unit">kcal</span></label><input id="meal-kcal" type="number" inputMode="numeric" value={d.kcal} onChange={e => setD({ ...d, kcal: e.target.value })} /></div>
          <div className="field"><label htmlFor="meal-grams">Grami <span className="unit">neobvezno</span></label><input id="meal-grams" type="number" inputMode="numeric" value={d.grams} onChange={e => setD({ ...d, grams: e.target.value })} /></div>
          <div className="field"><label htmlFor="meal-prot">Beljakovine <span className="unit">g</span></label><input id="meal-prot" type="number" inputMode="numeric" value={d.prot} onChange={e => setD({ ...d, prot: e.target.value })} /></div>
          <div className="field"><label htmlFor="meal-carb">Ogljikovi h. <span className="unit">g</span></label><input id="meal-carb" type="number" inputMode="numeric" value={d.carb} onChange={e => setD({ ...d, carb: e.target.value })} /></div>
          <div className="field"><label htmlFor="meal-fat">Maščobe <span className="unit">g</span></label><input id="meal-fat" type="number" inputMode="numeric" value={d.fat} onChange={e => setD({ ...d, fat: e.target.value })} /></div>
        </div>
      </div>
      <Btn primary block style={{ marginTop: 14 }} onClick={save}>Shrani</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={() => setOpen(false)}>Prekliči</Btn>
    </Sheet>

    <Sheet open={!!ideas} onClose={() => setIdeas(null)}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>{ideas?.title}</b>
      {ideas?.seen && ideas.seen.length > 0 && <p style={{ fontSize: 12, marginTop: 6 }}>Vidim: {ideas.seen.join(', ')}</p>}
      <div className="stack" style={{ gap: 10, marginTop: 12 }}>
        {(ideas?.list || []).map((s, i) => (
          <Card key={i} tight>
            <div className="between"><b style={{ fontSize: 14.5, minWidth: 0 }}>{s.name}</b><b style={{ fontSize: 13, flex: 'none' }}>{fmtKcal(s.kcal)}{NBSP}kcal</b></div>
            <p style={{ fontSize: 12.5, marginTop: 4 }}>{s.desc}</p>
            <div className="muted" style={{ fontSize: 11.5, marginTop: 4 }}>B {s.proteinG}{NBSP}g · OH {s.carbsG}{NBSP}g · M {s.fatG}{NBSP}g{s.minutes ? ` · ${s.minutes}${NBSP}min` : ''}{s.missing ? ` · manjka: ${s.missing}` : ''}</div>
            <button className="chip sm click" style={{ marginTop: 8 }} onClick={() => logIdea(s)}><IcoPlus width={12} height={12} /> vpiši, ko poješ</button>
          </Card>
        ))}
      </div>
      <Btn ghost block style={{ marginTop: 12 }} onClick={() => setIdeas(null)}>Zapri</Btn>
    </Sheet>

    <Sheet open={menuOpen && !!menu} onClose={() => setMenuOpen(false)}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Jedilnik za teden</b>
      {menu?.note && <p style={{ fontSize: 12.5, marginTop: 6 }}>{menu.note}</p>}
      <div className="stack" style={{ gap: 8, marginTop: 12 }}>
        {(menu?.days || []).map(x0 => { const x = x0 as MenuDay, low = below(x), f = floorOf(x); return (
          <Card key={x.date} tight style={low ? { borderColor: 'var(--warn)' } : undefined}>
            <div className="between" style={{ alignItems: 'flex-start' }}><b style={{ fontSize: 13.5, minWidth: 0 }}>{fmtDateLong(x.date)}{x.date === today ? ' · danes' : ''}</b><span className="muted" style={{ fontSize: 12, fontWeight: 700, flex: 'none' }}>{fmtKcal(x.kcal)}{NBSP}kcal · B {x.proteinG}{NBSP}g</span></div>
            {low ? (
              <div style={{ marginTop: 6 }}>
                <span className="chip sm" style={{ color: 'var(--warn)' }}><IcoWarn width={12} height={12} aria-hidden="true" /> pod varno mejo</span>
                <div className="muted" style={{ fontSize: 11.5, lineHeight: 1.45, marginTop: 5 }}>Premalo za ta dan{f ? ` (meja ${fmtKcal(f)}${NBSP}kcal)` : ''}{NBSP}— ni priporočilo; dodaj obrok ali sestavi znova.</div>
              </div>
            ) : topped(x) ? <div className="muted" style={{ fontSize: 11.5, marginTop: 4 }}>Dopolnjeno do varne meje: pri malici ~{fmtKcal(x.addKcal!)}{NBSP}kcal več, kot je predlagal AI.</div> : null}
            <div style={low ? { opacity: 0.55 } : undefined}>
              {menuLines(x).map(([l, t]) => <div key={l} style={{ fontSize: 12.5, marginTop: 4 }}><span className="muted">{l}</span> <span style={{ color: 'var(--ink)' }}>{t}</span></div>)}
            </div>
          </Card>) })}
      </div>
      {menu && menu.shopping.length > 0 && (<>
        <h2 className="h4" style={{ marginTop: 16 }}>Nakupovalni seznam</h2>
        <div className="stack" style={{ gap: 6, marginTop: 8 }}>
          {menu.shopping.map((s, i) => (
            <button key={i} type="button" className="row" onClick={() => setMenu({ ...menu, bought: { ...menu.bought, [i]: !menu.bought[i] } })} aria-pressed={!!menu.bought[i]} style={{ gap: 10, textAlign: 'left', background: 'none', border: 0, padding: '6px 0', color: 'var(--ink)', cursor: 'pointer' }}>
              <span className={`check ${menu.bought[i] ? '' : 'off'}`} style={{ width: 22, height: 22, flex: 'none' }}>{menu.bought[i] ? <IcoCheck width={13} height={13} /> : null}</span>
              <span style={{ fontSize: 13.5, textDecoration: menu.bought[i] ? 'line-through' : 'none', color: menu.bought[i] ? 'var(--ink-3)' : 'var(--ink)' }}>{s}</span>
            </button>
          ))}
        </div>
      </>)}
      <div className="row" style={{ gap: 8, marginTop: 14 }}>
        <Btn ghost sm disabled={ai.busy} onClick={makeMenu}>{busyIs('menu') ? 'Sestavljam …' : 'Sestavi znova'}</Btn>
        <Btn ghost sm onClick={() => { void navigator.clipboard?.writeText((menu?.shopping || []).join('\n')).then(() => toast('Seznam kopiran.', 'ok')) }}>Kopiraj seznam</Btn>
      </div>
      <HealthNote kind="food" />
      <Btn ghost block style={{ marginTop: 10 }} onClick={() => setMenuOpen(false)}>Zapri</Btn>
    </Sheet>
    {mainRide && rfDay && <FuelLogSheet open={fuelOpen} onClose={() => setFuelOpen(false)} day={mainRide} rf={rfDay} existing={fuelLog} kit={p.fuelKit} />}
    {ai.sheet}
  </>)
}

/**
 * Vrstica pod obročem: danes »Še 303 kcal · 20 g beljakovin«; pretekli dan »303 kcal pod ciljem« (ne »še«, dan je mimo);
 * presežene beljakovine »beljakovine dosežene« (ne »0 g«); pretekli dan brez vpisov ne kaže primanjkljaja.
 */
export function DayBalance({ remaining, proteinLeft, past, logged }: { remaining: number | null; proteinLeft: number; past: boolean; logged: boolean }) {
  const B = ({ children }: { children: React.ReactNode }) => <b style={{ color: 'var(--ink)' }}>{children}</b>
  const prot = proteinLeft > 0 ? `${proteinLeft}${NBSP}g beljakovin${past ? ' manj' : ''}` : 'beljakovine dosežene'
  if (remaining == null) return null
  if (past && !logged) return <>Za ta dan ni vpisanih obrokov</>
  if (remaining < 0) return <>Nad ciljem za <B>{fmtKcal(-remaining)}{NBSP}kcal</B>{proteinLeft <= 0 ? ' · beljakovine dosežene' : ''}</>
  if (past) return <><B>{fmtKcal(remaining)}{NBSP}kcal</B> pod ciljem · {prot}</>
  return <>Še <B>{fmtKcal(remaining)}{NBSP}kcal</B> · {prot}</>
}
