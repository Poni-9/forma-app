import { useMemo, useRef, useState } from 'react'
import { Head } from '@/app/Shell'
import { navigate, useRoute } from '@/app/router'
import { useApp, addMeal, removeMeal, setMenu, toast } from '@/state/store'
import { snapOf } from '@/state/snap'
import { useAi } from '@/ui/useAi'
import { PhotoInput } from '@/ui/PhotoInput'
import { useCountUp } from '@/ui/motion'
import { mealFromPhoto, fridgeMeals, mealIdeas, weekMenu, type Suggestion } from '@/domain/ai/actions'
import { dailyTarget, sumMeals, profileComplete, targetParts } from '@/domain/nutrition/energy'
import { addDays, weekStartIso } from '@/domain/training/load'
import type { MealEntry } from '@/domain/types'
import { aiAllowed } from '@/domain/import/provenance'
import { dayMealPlan, rideFuel, fuelCtxOf, adjustToEaten } from '@/domain/nutrition/dayplan'
import { FuelLogSheet, fuelLogOf } from '@/ui/FuelLog'
import { Card, Chip, Ring, Track, Btn, Sheet, Empty, fmtKcal, fmtDateLong, DAYS_SL } from '@/ui/primitives'
import { BarChart } from '@/ui/charts'
import { IcoBreakfast, IcoLunch, IcoDrink, IcoFood, IcoPlus, IcoBack, IcoCamera } from '@/ui/icons'

const SLOTS: { key: MealEntry['slot']; label: string; Ico: typeof IcoFood }[] = [
  { key: 'zajtrk', label: 'Zajtrk', Ico: IcoBreakfast }, { key: 'malica', label: 'Malica', Ico: IcoBreakfast }, { key: 'kosilo', label: 'Kosilo', Ico: IcoLunch },
  { key: 'med_vadbo', label: 'Med vožnjo', Ico: IcoDrink }, { key: 'vecerja', label: 'Večerja', Ico: IcoLunch }, { key: 'drugo', label: 'Drugo', Ico: IcoFood },
]
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
type Draft = { id: string | null; slot: MealEntry['slot']; name: string; kcal: string; prot: string; carb: string; fat: string; grams: string; thumb: string | null; conf: MealEntry['confidence']; source: MealEntry['source']; time: string | null; createdAt: string | null }
const empty = (slot: MealEntry['slot']): Draft => ({ id: null, slot, name: '', kcal: '', prot: '', carb: '', fat: '', grams: '', thumb: null, conf: null, source: 'manual', time: null, createdAt: null })
const fromMeal = (m: MealEntry): Draft => ({ id: m.id, slot: m.slot, name: m.name, kcal: String(m.kcal), prot: m.proteinG != null ? String(m.proteinG) : '', carb: m.carbsG != null ? String(m.carbsG) : '', fat: m.fatG != null ? String(m.fatG) : '', grams: m.grams != null ? String(m.grams) : '', thumb: m.thumb || null, conf: m.confidence || null, source: m.source, time: m.time || null, createdAt: m.createdAt })

export function Prehrana() {
  const app = useApp()
  const ai = useAi()
  const route = useRoute()
  const { profile: p, today, plan, activities, settings } = app
  const [day, setDay] = useState<string>(route.params.dan && route.params.dan <= today ? route.params.dan : today)
  const isToday = day === today
  const meals = isToday ? app.mealsToday : app.recentMeals.filter(m => m.date === day)
  const target = dailyTarget(p, activities.filter(a => a.date === day), plan.filter(d => d.date === day), day)
  // Za AI: cilj brez aktivnosti, ki jih AI ne sme videti (Strava) — niti posredno prek porabe kalorij
  const aiTarget = dailyTarget(p, activities.filter(a => a.date === day && aiAllowed(a)), plan.filter(d => d.date === day), day)
  const eaten = sumMeals(meals)
  const shownKcal = useCountUp(eaten.kcal)
  const [open, setOpen] = useState(false)
  const [d, setD] = useState<Draft>(() => empty(nextSlot(meals)))
  const [photoBusy, setPhotoBusy] = useState(false)
  const [ideas, setIdeas] = useState<{ title: string; seen?: string[]; list: Suggestion[] } | null>(null)
  const [menuOpen, setMenuOpen] = useState(false)
  const [busy, setBusy] = useState<string | null>(null)
  const [fuelOpen, setFuelOpen] = useState(false)
  // glavna vožnja dneva in gorivo zanjo (temperatura v oknu treninga, koliko običajno spiješ)
  const mainRide = plan.filter(x => x.date === day && (x.kind === 'kolo' || x.kind === 'test') && !x.optional).sort((a, b) => b.durationMin - a.durationMin)[0] || null
  const fctx = fuelCtxOf(app.weather, app.recentMeals, day, today)
  const rfDay = mainRide ? rideFuel(mainRide, p.fuelKit, fctx) : null
  const fuelLog = mainRide ? fuelLogOf(meals, mainRide) : null
  const evening = isToday && new Date().getHours() >= 18
  const fridgeRef = useRef<HTMLInputElement>(null)
  const camRef = useRef<HTMLInputElement>(null)
  const remaining = target ? target.kcal - eaten.kcal : null
  const todayMain = plan.filter(x => x.date === today && x.kind !== 'pocitek' && !x.optional && !x.done).sort((a, b) => (a.kind === 'moc' ? 1 : 0) - (b.kind === 'moc' ? 1 : 0))[0]

  const frequent = useMemo(() => {
    const m = new Map<string, { n: number; meal: MealEntry }>()
    for (const x of app.recentMeals) { const k = x.name.trim().toLowerCase(); const e = m.get(k); if (e) { e.n++; e.meal = x } else m.set(k, { n: 1, meal: x }) }
    return [...m.values()].filter(x => x.n >= 2).sort((a, b) => b.n - a.n).slice(0, 6).map(x => x.meal)
  }, [app.recentMeals])

  const last7 = Array.from({ length: 7 }, (_, i) => addDays(today, -6 + i))
  const bars = last7.map(x => { const k = (x === today ? app.mealsToday : app.recentMeals.filter(m => m.date === x)).reduce((s, m) => s + m.kcal, 0); return { label: DAYS_SL[(new Date(x).getDay() + 6) % 7]!, value: k, color: x === day ? 'var(--accent)' : 'var(--t-kolo)' } })
  const logged = bars.filter(b => b.value > 0)
  const avgKcal = logged.length ? Math.round(logged.reduce((s, b) => s + b.value, 0) / logged.length) : 0
  const menu = settings.menu && settings.menu.weekStart === weekStartIso(today) ? settings.menu : null
  const menuDay = menu?.days.find(x => x.date === day) || null

  async function save() {
    const k = Math.round(+d.kcal || 0)
    if (!d.name.trim() || !k) { toast('Vpiši vsaj ime in kalorije.', 'err'); return }
    const orig = d.id ? meals.find(m => m.id === d.id) : undefined     // ohrani polja, ki jih obrazec ne kaže (vpis goriva)
    await addMeal({ ...(orig || {}), id: d.id || uid(), date: day, time: d.time || (isToday ? new Date().toTimeString().slice(0, 5) : null), slot: d.slot, name: d.name.trim(), grams: d.grams ? +d.grams : null, kcal: k, proteinG: d.prot ? +d.prot : null, carbsG: d.carb ? +d.carb : null, fatG: d.fat ? +d.fat : null, confidence: d.conf, source: d.source, thumb: d.thumb, createdAt: d.createdAt || new Date().toISOString() })
    setOpen(false)
    toast(d.id ? 'Popravljeno.' : 'Dodano.', 'ok')
  }
  async function fromPhoto(file: File) {
    setPhotoBusy(true)
    const m = await ai.run(() => mealFromPhoto(p, file, aiTarget ? aiTarget.kcal - eaten.kcal : null, aiTarget ? aiTarget.proteinG - eaten.p : null))
    setPhotoBusy(false)
    if (!m) return
    setD({ ...fromMeal({ ...m, date: day }), id: null })
    setOpen(true)
  }
  async function fridge(file: File) {
    setBusy('fridge')
    const r = await ai.run(() => fridgeMeals(p, file, aiTarget ? aiTarget.kcal - eaten.kcal : null, aiTarget ? aiTarget.proteinG - eaten.p : null, todayMain?.title || null))
    setBusy(null)
    if (r) setIdeas({ title: 'Kaj naj skuham', seen: r.seen, list: r.ideas })
  }
  async function suggest() {
    if (!target || !aiTarget) return
    setBusy('ideas')
    const r = await ai.run(() => mealIdeas(snapOf(app), Math.max(300, aiTarget.kcal - eaten.kcal), aiTarget.proteinG - eaten.p))
    setBusy(null)
    if (r) setIdeas({ title: 'Predlogi za preostanek dneva', list: r })
  }
  async function makeMenu() {
    if (!target || !aiTarget) return
    setBusy('menu')
    const base = dailyTarget(p, [], [], today)
    const r = await ai.run(() => weekMenu(snapOf(app), base ? base.kcal : aiTarget.kcal, aiTarget.proteinG, frequent.map(f => f.name)))
    setBusy(null)
    if (r) { await setMenu(r); setMenuOpen(true); toast('Jedilnik in nakupovalni seznam sta pripravljena.', 'ok') }
  }
  async function logIdea(s: Suggestion) {
    await addMeal({ id: uid(), date: day, time: isToday ? new Date().toTimeString().slice(0, 5) : null, slot: nextSlot(meals), name: s.name, grams: null, kcal: s.kcal, proteinG: s.proteinG, carbsG: s.carbsG, fatG: s.fatG, confidence: 'srednja', source: 'suggest', thumb: null, createdAt: new Date().toISOString() })
    toast(`${s.name} vpisano.`, 'ok')
  }
  async function repeat(m: MealEntry) {
    await addMeal({ ...m, id: uid(), date: day, time: isToday ? new Date().toTimeString().slice(0, 5) : null, slot: nextSlot(meals), thumb: null, createdAt: new Date().toISOString() })
    toast(`${m.name} dodano.`, 'ok')
  }

  const groups = SLOTS.map(s => ({ ...s, items: meals.filter(m => m.slot === s.key) })).filter(g => g.items.length)

  return (<>
    <Head hi={fmtDateLong(day)} nm="Prehrana" right={<button className="btn primary sm" style={{ borderRadius: 'var(--r-full)', padding: '10px 14px', gap: 8, fontSize: 14 }} disabled={photoBusy || ai.busy} onClick={() => camRef.current?.click()} aria-label="Slikaj obrok"><IcoCamera width={18} height={18} /> {photoBusy ? 'Berem …' : 'Slikaj obrok'}</button>} />
    <input ref={camRef} type="file" accept="image/*" capture="environment" style={{ display: 'none' }} onChange={e => { const f = e.target.files?.[0]; e.target.value = ''; if (f) void fromPhoto(f) }} />
    <div className="scroll">
      <div className="between" style={{ marginBottom: 12 }}>
        <button className="chip sm click" onClick={() => day > addDays(today, -90) && setDay(addDays(day, -1))}><IcoBack width={13} height={13} /> prejšnji</button>
        {!isToday && <button className="chip sm click on" onClick={() => setDay(today)}>danes</button>}
        <button className="chip sm click" disabled={isToday} style={{ opacity: isToday ? 0.35 : 1 }} onClick={() => !isToday && setDay(addDays(day, 1))}>naslednji <IcoBack width={13} height={13} style={{ transform: 'scaleX(-1)' }} /></button>
      </div>

      {!profileComplete(p) ? (
        <Empty icon={<IcoFood width={30} height={30} style={{ color: 'var(--ok)' }} />} title="Za kalorije rabim tvoj profil" text="Višina, teža, starost in spol. Brez tega ti številke ne pokažem — raje prazno kot narobe.">
          <Btn primary sm onClick={() => navigate('nastavitve')}>Izpolni profil</Btn>
        </Empty>
      ) : target && (
        <Card className="page">
          <div className="ring-wrap">
            <Ring size={118} stroke={11} pct={eaten.kcal / target.kcal}><div><b className="num">{fmtKcal(Math.round(shownKcal))}</b><small>od {fmtKcal(target.kcal)} kcal</small></div></Ring>
            <div className="macro">
              <div className="m"><div className="t"><span>Beljakovine</span><span>{Math.round(eaten.p)} / {target.proteinG} g</span></div><Track pct={eaten.p / target.proteinG * 100} color="var(--accent)" /></div>
              <div className="m"><div className="t"><span>Ogljikovi hidrati</span><span>{Math.round(eaten.c)} / {target.carbsG} g</span></div><Track pct={eaten.c / Math.max(1, target.carbsG) * 100} color="var(--ink-3)" /></div>
              <div className="m"><div className="t"><span>Maščobe</span><span>{Math.round(eaten.f)} / {target.fatG} g</span></div><Track pct={eaten.f / Math.max(1, target.fatG) * 100} color="var(--ink-3)" /></div>
            </div>
          </div>
          <div className="between" style={{ marginTop: 15, paddingTop: 13, borderTop: '1px solid var(--line)' }}>
            <div style={{ fontSize: 12, color: 'var(--ink-3)', fontWeight: 600 }}>
              {remaining != null && remaining >= 0 ? <>Še <b style={{ color: 'var(--ink)' }}>{fmtKcal(remaining)} kcal</b> · {Math.max(0, Math.round(target.proteinG - eaten.p))} g beljakovin</> : <>Nad ciljem za <b style={{ color: 'var(--ink)' }}>{fmtKcal(-(remaining || 0))} kcal</b></>}
            </div>
            <Chip sm ok={!target.clampedToFloor}>{target.minor ? 'Vzdrževanje' : target.clampedToFloor ? 'Spodnja meja' : 'Varno'}</Chip>
          </div>
          <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>Cilj = {targetParts(target, p)}.</div>
          {target.clampedToFloor && !target.minor && <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>Cilj je na spodnji varni meji ({fmtKcal(target.floor)} kcal) — nižje ne gre, tudi če bi izračun tako pokazal.</div>}
          {target.deficit > 0 || target.deficitNote ? <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>Deficit danes {target.deficit} kcal{target.deficitNote ? ` (${target.deficitNote})` : ''} — samo pri obrokih, nikoli na kolesu.</div> : null}
          {evening && remaining != null && remaining > 600 && <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>Če si sit, ne jej na silo — zvečer raje nekaj z beljakovinami in OH (skuta z banano, jogurt, kakav). Šteje tedensko povprečje, ne en dan.{mainRide?.done && !fuelLog && rfDay?.totalCarbs ? ' Vpiši tudi, kaj si popil in pojedel na kolesu — tudi to so kalorije.' : ''}</div>}
        </Card>
      )}

      {target && (() => {
        const main = mainRide
        // čez dan: preostali obroki se prilagodijo pojedenemu in vpisanemu gorivu na kolesu
        const dp0 = dayMealPlan(p, target, main, fctx)
        const dp = isToday ? adjustToEaten(dp0, meals, target.kcal) : dp0
        const rf = rfDay
        const bySlot = (sl: string) => meals.filter(m => m.slot === sl).reduce((a, m) => a + m.kcal, 0)
        return (
          <Card style={{ marginTop: 12 }}>
            <div className="between"><h4 style={{ margin: 0 }}>{isToday ? 'Danes jej po načrtu' : 'Načrt obrokov za ta dan'}</h4><span className="muted" style={{ fontSize: 12, fontWeight: 700 }}>{fmtKcal(dp.total)} kcal</span></div>
            <div className="stack" style={{ gap: 0, marginTop: 8 }}>
              {dp.slots.map(sl => { const got = sl.got ?? bySlot(sl.slot); return (
                <div key={sl.key} style={{ padding: '9px 0', borderTop: '1px solid var(--line)' }}>
                  <div className="between" style={{ fontSize: 13 }}><b style={{ color: 'var(--ink)' }}>{sl.label} <span className="muted" style={{ fontWeight: 600, fontSize: 11.5 }}>· {sl.when}</span></b><span style={{ fontWeight: 800, color: got >= sl.kcal * 0.85 ? 'var(--ok)' : 'var(--ink)' }}>{got ? `${fmtKcal(got)} / ` : ''}{fmtKcal(sl.kcal)} kcal</span></div>
                  <div className="muted" style={{ fontSize: 12, marginTop: 2 }}>~{sl.proteinG} g beljakovin · ~{sl.carbsG} g OH</div>
                  <div style={{ fontSize: 12.5, marginTop: 3, color: 'var(--ink-2)' }}>npr. {sl.example}</div>
                </div>) })}
              {dp.onBike && main && <div style={{ padding: '9px 0', borderTop: '1px solid var(--line)' }}>
                <div className="between" style={{ fontSize: 13 }}><b style={{ color: 'var(--ink)' }}>Na kolesu <span className="muted" style={{ fontWeight: 600, fontSize: 11.5 }}>· {main.title}</span></b><span style={{ fontWeight: 800 }}>{dp.onBike.carbs} g OH</span></div>
                {rf && <>
                  <div style={{ fontSize: 12.5, marginTop: 3, color: 'var(--ink-2)' }}>Vzemi: {rf.items.join(' · ')}</div>
                  <div className="muted" style={{ fontSize: 12, marginTop: 3 }}>{rf.schedule} V dnevnem cilju je že upoštevano — v pojedeno se šteje, ko vpišeš, koliko si res porabil.</div>
                  <div className="row" style={{ gap: 8, marginTop: 6, alignItems: 'center' }}>
                    <button className="chip sm click" onClick={() => setFuelOpen(true)}>{fuelLog ? 'uredi vpis' : 'vpiši, kaj si porabil'}</button>
                    {fuelLog && <span className="muted" style={{ fontSize: 12 }}>vpisano {fmtKcal(fuelLog.kcal)} kcal{fuelLog.fluidMl != null ? ` · ${String(Math.round(fuelLog.fluidMl / 50) * 50 / 1000).replace('.', ',')} l` : ''}</span>}
                  </div>
                </>}
              </div>}
            </div>
            {dp.adjusted && <p style={{ fontSize: 12, marginTop: 8, color: 'var(--ink-2)' }}>Preostali obroki so prilagojeni temu, kar si danes že pojedel{meals.some(m => m.slot === 'med_vadbo') ? ' in porabil na kolesu' : ''}.{dp.short ? ` Do cilja manjka še ~${fmtKcal(dp.short)} kcal — če si sit, ne jej na silo.` : ''}</p>}
            <p className="muted" style={{ fontSize: 11.5, marginTop: 8 }}>{dp.tip} Količine so okvirne — obroke vpiši ali slikaj, da vidiš, koliko še manjka.</p>
          </Card>
        )
      })()}

      <div style={{ marginTop: 12 }}>
        <PhotoInput onPick={fromPhoto} busy={photoBusy || ai.busy} label="Slikaj obrok" hint="Če je na sliki tehtnica, preberem grame z nje. Sicer ocenim porcijo. Vsako številko lahko popraviš." />
      </div>

      {frequent.length > 0 && (
        <Card tight style={{ marginTop: 12 }}>
          <h4 style={{ fontSize: 11 }}>Pogosto · en tap</h4>
          <div className="row" style={{ gap: 6, flexWrap: 'wrap', marginTop: 8 }}>
            {frequent.map(m => <button key={m.id} className="chip sm click" onClick={() => repeat(m)} style={{ maxWidth: '100%' }}><IcoPlus width={12} height={12} /><span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 170 }}>{m.name}</span><span className="muted">{fmtKcal(m.kcal)}</span></button>)}
          </div>
        </Card>
      )}

      {target && isToday && (
        <div className="row" style={{ gap: 8, marginTop: 12, flexWrap: 'wrap' }}>
          <Btn ghost sm disabled={ai.busy} onClick={suggest}>{busy === 'ideas' ? 'Razmišljam …' : 'Predlagaj obrok'}</Btn>
          <Btn ghost sm disabled={ai.busy} onClick={() => fridgeRef.current?.click()}><IcoCamera width={14} height={14} /> {busy === 'fridge' ? 'Gledam …' : 'Slikaj hladilnik'}</Btn>
          <input ref={fridgeRef} type="file" accept="image/*" capture="environment" style={{ display: 'none' }} onChange={e => { const f = e.target.files?.[0]; e.target.value = ''; if (f) void fridge(f) }} />
        </div>
      )}

      {menuDay ? (
        <Card tight style={{ marginTop: 12, cursor: 'pointer' }} onClick={() => setMenuOpen(true)}>
          <div className="between"><h4 style={{ fontSize: 11, margin: 0 }}>Jedilnik · {fmtKcal(menuDay.kcal)} kcal</h4><span className="muted" style={{ fontSize: 12, fontWeight: 700 }}>teden in nakup ›</span></div>
          {([['Zajtrk', menuDay.zajtrk], ['Kosilo', menuDay.kosilo], ['Malica', menuDay.malica], ['Večerja', menuDay.vecerja]] as const).filter(x => x[1]).map(([l, t]) => <div key={l} style={{ fontSize: 12.5, marginTop: 5 }}><span className="muted">{l}</span> <span style={{ color: 'var(--ink)' }}>{t}</span></div>)}
        </Card>
      ) : target && app.user && isToday ? (
        <div style={{ marginTop: 8 }}><Btn ghost sm disabled={ai.busy} onClick={makeMenu}>{busy === 'menu' ? 'Sestavljam jedilnik …' : 'Jedilnik za teden + nakupovalni seznam'}</Btn></div>
      ) : null}


      <div className="between" style={{ margin: '17px 0 10px' }}><h4 style={{ margin: 0 }}>{isToday ? 'Danes' : fmtDateLong(day)}</h4><span className="row" style={{ gap: 8 }}><span className="muted" style={{ fontSize: 12, fontWeight: 700 }}>{fmtKcal(eaten.kcal)} kcal · {Math.round(eaten.p)} g B</span><button className="chip sm click" onClick={() => { setD(empty(nextSlot(meals))); setOpen(true) }}><IcoPlus width={12} height={12} /> vpiši</button></span></div>
      <div className="stack stagger" style={{ gap: 9 }}>
        {groups.map(g => g.items.map(m => (
          <Card key={m.id} tight className="row" style={{ gap: 12 }}>
            {m.thumb ? <img src={m.thumb} alt="" width={36} height={36} style={{ borderRadius: 'var(--r-s)', objectFit: 'cover', flex: 'none' }} /> : <div style={{ width: 36, height: 36, borderRadius: 'var(--r-s)', background: 'var(--raised)', display: 'grid', placeItems: 'center', flex: 'none', color: 'var(--ink-2)' }}><g.Ico width={18} height={18} /></div>}
            <div style={{ flex: 1, minWidth: 0, cursor: 'pointer' }} onClick={() => { if (m.forDay && mainRide && m.forDay === mainRide.id && rfDay) { setFuelOpen(true); return } setD(fromMeal(m)); setOpen(true) }}>
              <b style={{ fontSize: 14 }}>{g.label}{m.time ? <span className="muted" style={{ fontWeight: 600, fontSize: 12 }}> · {m.time}</span> : null}</b>
              <div className="muted" style={{ fontSize: 12, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{m.name}{m.grams ? ` · ${m.grams} g` : ''}{m.proteinG != null ? ` · B ${m.proteinG} g` : ''}{m.confidence === 'nizka' ? ' · ocena' : ''}</div>
            </div>
            <b style={{ fontSize: 14 }}>{fmtKcal(m.kcal)}</b>
            <button className="chip sm click" onClick={() => { if (confirm(`Izbrišem »${m.name}«?`)) void removeMeal(m.id) }} aria-label="Izbriši">×</button>
          </Card>
        )))}
        <button type="button" className="card tight row" style={{ gap: 12, borderStyle: 'dashed', color: 'var(--ink-3)', cursor: 'pointer', textAlign: 'left', width: '100%' }} onClick={() => { setD(empty(nextSlot(meals))); setOpen(true) }}>
          <div style={{ width: 36, height: 36, borderRadius: 'var(--r-s)', border: '1px dashed var(--line)', display: 'grid', placeItems: 'center', flex: 'none', fontSize: 17 }}>＋</div>
          <div style={{ flex: 1, minWidth: 0 }}><b style={{ fontSize: 14, color: 'var(--ink-2)' }}>Dodaj {SLOTS.find(s => s.key === nextSlot(meals))?.label.toLowerCase() || 'obrok'}</b><div style={{ fontSize: 12 }}>{remaining != null && remaining > 0 ? `Ostane ti ${fmtKcal(remaining)} kcal` : 'Vpiši, kar si pojedel'}</div></div>
        </button>
      </div>

      <Card style={{ marginTop: 14 }}>
        <div className="between"><h4 style={{ margin: 0 }}>Zadnjih 7 dni</h4><span className="muted" style={{ fontSize: 11.5, fontWeight: 700 }}>{logged.length ? `povprečno ${fmtKcal(avgKcal)} kcal` : 'ni vnosov'}</span></div>
        <div style={{ marginTop: 10 }}><BarChart bars={bars} height={130} unit="kcal" /></div>
        {target && logged.length > 0 && <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>Cilj brez treninga {fmtKcal(dailyTarget(p, [], [], day)?.kcal || target.kcal)} kcal · zabeleženih {logged.length}/7 dni. Kar ni zabeleženo, trener ne vidi.</div>}
      </Card>
      <div className="muted" style={{ fontSize: 11.5, padding: '12px 4px 6px' }}>FORMAI daje prehranske usmeritve, ne medicinskih nasvetov. Ob bolezni, poškodbi ali motnjah hranjenja se posvetuj z zdravnikom.</div>
    </div>

    <Sheet open={open} onClose={() => setOpen(false)}>
      <div className="row" style={{ gap: 12 }}>
        {d.thumb && <img src={d.thumb} alt="" width={48} height={48} style={{ borderRadius: 'var(--r-s)', objectFit: 'cover' }} />}
        <div><b style={{ fontSize: 17, letterSpacing: '-.02em' }}>{d.id ? 'Uredi vnos' : d.source === 'photo' ? 'Preveri in shrani' : 'Dodaj obrok'}</b>{d.conf && <div className="muted" style={{ fontSize: 12 }}>zanesljivost ocene: {d.conf}{d.grams ? ` · ${d.grams} g` : ''}</div>}</div>
      </div>
      <div className="row" style={{ gap: 7, flexWrap: 'wrap', margin: '12px 0' }}>
        {SLOTS.map(s => <Chip key={s.key} sm on={d.slot === s.key} onClick={() => setD({ ...d, slot: s.key })}>{s.label}</Chip>)}
      </div>
      <div className="stack" style={{ gap: 10 }}>
        <div className="field"><label>Kaj si jedel</label><input value={d.name} onChange={e => setD({ ...d, name: e.target.value })} placeholder="npr. skuta z jagodami" autoFocus={!d.thumb && !d.id} /></div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div className="field"><label>Kalorije <span className="unit">kcal</span></label><input type="number" inputMode="numeric" value={d.kcal} onChange={e => setD({ ...d, kcal: e.target.value })} /></div>
          <div className="field"><label>Grami <span className="unit">neobvezno</span></label><input type="number" inputMode="numeric" value={d.grams} onChange={e => setD({ ...d, grams: e.target.value })} /></div>
          <div className="field"><label>Beljakovine <span className="unit">g</span></label><input type="number" inputMode="numeric" value={d.prot} onChange={e => setD({ ...d, prot: e.target.value })} /></div>
          <div className="field"><label>Ogljikovi h. <span className="unit">g</span></label><input type="number" inputMode="numeric" value={d.carb} onChange={e => setD({ ...d, carb: e.target.value })} /></div>
          <div className="field"><label>Maščobe <span className="unit">g</span></label><input type="number" inputMode="numeric" value={d.fat} onChange={e => setD({ ...d, fat: e.target.value })} /></div>
        </div>
      </div>
      <Btn primary block style={{ marginTop: 14 }} onClick={save}>Shrani</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={() => setOpen(false)}>Prekliči</Btn>
    </Sheet>

    <Sheet open={!!ideas} onClose={() => setIdeas(null)}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>{ideas?.title}</b>
      {ideas?.seen && ideas.seen.length > 0 && <p style={{ fontSize: 12, marginTop: 6 }}>Vidim: {ideas.seen.join(', ')}</p>}
      <div className="stack" style={{ gap: 10, marginTop: 12 }}>
        {(ideas?.list || []).map((s, i) => (
          <Card key={i} tight>
            <div className="between"><b style={{ fontSize: 14.5 }}>{s.name}</b><b style={{ fontSize: 13 }}>{fmtKcal(s.kcal)} kcal</b></div>
            <p style={{ fontSize: 12.5, marginTop: 4 }}>{s.desc}</p>
            <div className="muted" style={{ fontSize: 11.5, marginTop: 4 }}>B {s.proteinG} g · OH {s.carbsG} g · M {s.fatG} g{s.minutes ? ` · ${s.minutes} min` : ''}{s.missing ? ` · manjka: ${s.missing}` : ''}</div>
            <button className="chip sm click" style={{ marginTop: 8 }} onClick={() => logIdea(s)}><IcoPlus width={12} height={12} /> vpiši, ko poješ</button>
          </Card>
        ))}
      </div>
      <Btn ghost block style={{ marginTop: 12 }} onClick={() => setIdeas(null)}>Zapri</Btn>
    </Sheet>

    <Sheet open={menuOpen && !!menu} onClose={() => setMenuOpen(false)}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Jedilnik za teden</b>
      <div className="stack" style={{ gap: 8, marginTop: 12 }}>
        {(menu?.days || []).map(x => (
          <Card key={x.date} tight>
            <div className="between"><b style={{ fontSize: 13.5 }}>{fmtDateLong(x.date)}{x.date === today ? ' · danes' : ''}</b><span className="muted" style={{ fontSize: 12, fontWeight: 700 }}>{fmtKcal(x.kcal)} kcal · B {x.proteinG} g</span></div>
            {([['Zajtrk', x.zajtrk], ['Kosilo', x.kosilo], ['Malica', x.malica], ['Večerja', x.vecerja]] as const).filter(y => y[1]).map(([l, t]) => <div key={l} style={{ fontSize: 12.5, marginTop: 4 }}><span className="muted">{l}</span> <span style={{ color: 'var(--ink)' }}>{t}</span></div>)}
          </Card>
        ))}
      </div>
      {menu && menu.shopping.length > 0 && (<>
        <h4 style={{ marginTop: 16 }}>Nakupovalni seznam</h4>
        <div className="stack" style={{ gap: 6, marginTop: 8 }}>
          {menu.shopping.map((s, i) => (
            <button key={i} type="button" className="row" onClick={() => setMenu({ ...menu, bought: { ...menu.bought, [i]: !menu.bought[i] } })} style={{ gap: 10, textAlign: 'left', background: 'none', border: 0, padding: '6px 0', color: 'var(--ink)', cursor: 'pointer' }}>
              <span className={`check ${menu.bought[i] ? '' : 'off'}`} style={{ width: 22, height: 22, flex: 'none' }}>{menu.bought[i] ? '✓' : ''}</span>
              <span style={{ fontSize: 13.5, textDecoration: menu.bought[i] ? 'line-through' : 'none', color: menu.bought[i] ? 'var(--ink-3)' : 'var(--ink)' }}>{s}</span>
            </button>
          ))}
        </div>
      </>)}
      <div className="row" style={{ gap: 8, marginTop: 14 }}>
        <Btn ghost sm disabled={ai.busy} onClick={makeMenu}>{busy === 'menu' ? 'Sestavljam …' : 'Sestavi znova'}</Btn>
        <Btn ghost sm onClick={() => { void navigator.clipboard?.writeText((menu?.shopping || []).join('\n')).then(() => toast('Seznam kopiran.', 'ok')) }}>Kopiraj seznam</Btn>
      </div>
      <Btn ghost block style={{ marginTop: 10 }} onClick={() => setMenuOpen(false)}>Zapri</Btn>
    </Sheet>
    {mainRide && rfDay && <FuelLogSheet open={fuelOpen} onClose={() => setFuelOpen(false)} day={mainRide} rf={rfDay} existing={fuelLog} kit={p.fuelKit} />}
    {ai.sheet}
  </>)
}

function nextSlot(meals: readonly MealEntry[]): MealEntry['slot'] {
  const h = new Date().getHours()
  const has = (s: MealEntry['slot']) => meals.some(m => m.slot === s)
  if (h < 10 && !has('zajtrk')) return 'zajtrk'
  if (h < 15 && !has('kosilo')) return 'kosilo'
  if (h >= 17 && !has('vecerja')) return 'vecerja'
  if (h >= 15 && h < 17 && !has('malica')) return 'malica'
  return has('zajtrk') ? (has('kosilo') ? 'vecerja' : 'kosilo') : 'zajtrk'
}
