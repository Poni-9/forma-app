import { FuelTimeline, drinkLine, l1 } from '@/ui/FuelTimeline'
import { Fragment, useEffect, useMemo, useRef, useState } from 'react'
import { Head } from '@/app/Shell'
import { navigate, useRoute } from '@/app/router'
import { replaceParams } from '@/app/hash'
import { useApp, getState, addMeal, removeMeal, setMenu, setFoodPrefs, setDayMenu, setPlanDone, setRecipeAlt, toast, dismissToast } from '@/state/store'
import { snapOf } from '@/state/snap'
import { noIdsOn, markNo } from '@/state/noAsk'
import { useAi } from '@/ui/useAi'
import { MealInput } from '@/ui/MealInput'
import { CountUp } from '@/ui/CountUp'
import { mealFromPhoto, mealFromText, fridgeMeals, mealIdeas, weekMenu, dayRecipesAi, type Suggestion } from '@/domain/ai/actions'
import { dailyTarget, sumMeals, profileComplete, planNetKcal, trainingIn, eveningSnack, type DailyTarget } from '@/domain/nutrition/energy'
import { weekBalance } from '@/domain/nutrition/week'
import { estimateMeal } from '@/domain/nutrition/localMeal'
import { matchesPlanned } from '@/domain/training/plandays'
import { addDays, weekStartIso, fmtDur, titleNoDur } from '@/domain/training/load'
import { gist } from '@/ui/SessBits'
import type { MealEntry, Profile, WeekMenu } from '@/domain/types'
import { aiAllowed } from '@/domain/import/provenance'
import { rideFuel, runFuel, fuelCtxOf, RUN_FUEL_MIN, type MealSlotPlan } from '@/domain/nutrition/dayplan'
import { dishChoices, MIN_RECIPE_KCAL, scaleIngredients, scaleSteps, shoppingGroups, shopGotOf, prefsNote, hasTimedPrefs, type Recipe } from '@/domain/nutrition/recipes'
import { dayMealsOf, gotOf as gotOfSlot, nextSlotOf, recipeCtxOf, recipesOf, recipesAhead, slotFor, repeatSlot, TINY_KCAL } from '@/domain/nutrition/daymeals'
import { FuelLogSheet, fuelLogOf } from '@/ui/FuelLog'
import { slotAt, timeForSlot, byTime, photoTime, hhmm, TYPICAL, SLOT_ACC, mealTypeFromText } from '@/domain/nutrition/slots'
import { Card, Chip, Ring, Track, Btn, Sheet, Empty, DecimalInput, fmtKcal, fmtDateLong, DAYS_SL } from '@/ui/primitives'
import { g } from '@/ui/gender'
import { fileToBase64Resized, exifStamp } from '@/domain/ai/image'
import { BarChart } from '@/ui/charts'
import { HealthNote } from '@/ui/HealthNote'
import { Section } from '@/ui/Section'
import { deferDelete, useHidden } from '@/ui/Confirm'
import { takeMealPhoto } from '@/ui/mealPhoto'
import { NBSP, nb, num, dayAcc, dayName, dm, fmtTime, copyText, count, W } from '@/ui/format'
import { sameMealBefore, normSaid } from '@/domain/nutrition/same'
import { IcoBreakfast, IcoSnack, IcoLunch, IcoDrink, IcoFood, IcoPlus, IcoBack, IcoCamera, IcoWarn, IcoCheck, IcoInfo, IcoSpark, IcoChevDown } from '@/ui/icons'
import { isCustom } from '@/domain/focus/model'
import { rem } from '@/ui/rem'

const SLOTS: { key: MealEntry['slot']; label: string; Ico: typeof IcoFood }[] = [
  { key: 'zajtrk', label: 'Zajtrk', Ico: IcoBreakfast }, { key: 'malica', label: 'Malica', Ico: IcoSnack }, { key: 'kosilo', label: 'Kosilo', Ico: IcoLunch },
  { key: 'med_vadbo', label: 'Med vožnjo', Ico: IcoDrink }, { key: 'vecerja', label: 'Večerja', Ico: IcoLunch }, { key: 'drugo', label: 'Drugo', Ico: IcoFood },
]
/** Načrt po meri: »Med vadbo« namesto »Med vožnjo«. */
/** barva obroka (po uri dneva): zajtrk sonce, kosilo zelena, malica oranžna, večerja vijolična, med vadbo kolo */
const slotColor = (k: string): string => ({ zajtrk: '#F2B544', kosilo: '#199e70', malica: '#d95926', pred: '#d95926', vecerja: '#8b6cf0', obnova: '#8b6cf0', zvecer: '#5b7cfa', med_vadbo: 'var(--t-kolo)' } as Record<string, string>)[k] || 'var(--ink-3)'
const slotsFor = (custom: boolean) => (custom ? SLOTS.map(s => (s.key === 'med_vadbo' ? { ...s, label: 'Med vadbo' } : s)) : SLOTS)
const SLOT_NAME: Record<MealEntry['slot'], string> = { zajtrk: 'zajtrk', malica: 'malica', kosilo: 'kosilo', med_vadbo: 'obrok med vožnjo', vecerja: 'večerja', drugo: 'drugo' }
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
type Draft = { id: string | null; slot: MealEntry['slot']; name: string; kcal: string; prot: string; carb: string; fat: string; grams: string; thumb: string | null; conf: MealEntry['confidence']; source: MealEntry['source']; time: string | null; createdAt: string | null; /** ročno izbran obrok / ura — potem se drugo ne spreminja samo */ slotSet?: boolean; timeSet?: boolean; /** opis z besedilom/glasom: ocena po sestavinah, morebitno vprašanje AI in opis za »Oceni znova« */ items?: MealEntry['items']; question?: string | null; desc?: string; /** številke iz tvojega obroka z istim opisom (datum) — brez nove AI ocene */ prevFrom?: string; /** (v3.49) vpis iz polja »Dodaj obrok« (opis ali slika) — po shranjevanju se polje izprazni */ fromInput?: boolean; /** (v3.49) AI ni odgovoril — opis je prenesen v ročni vpis */ aiDown?: boolean; /** (v3.49) ocena brez AI iz tabele živil: deli opisa, ki jih tabela ne pozna */ local?: string[]; /** (v3.50) slika obroka brez ocene (AI ni odgovoril ali ni prijave) — »Poskusi znova« */ photoDown?: 'ai' | 'login'; /** (v3.50) brez prijave: ocena iz tabele živil, AI ob prijavi */ noLogin?: boolean; /** (v3.50) vpis po polnoči za včeraj */ yesterday?: boolean }
/** (v3.49) Ocena brez AI (tabela živil) v obrazec: kalorije, makri in sestavine, nizka zanesljivost. */
export function localDraft(desc: string): Pick<Draft, 'kcal' | 'prot' | 'carb' | 'fat' | 'items' | 'conf' | 'local'> | null {
  const e = estimateMeal(desc)
  return e ? { kcal: String(e.kcal), prot: String(e.p), carb: String(e.c), fat: String(e.f), items: e.items.map(i => ({ name: i.name, qty: i.qty, kcal: i.kcal })), conf: 'nizka', local: e.unknown } : null
}
/** Nov vpis: obrok po uri (danes zdaj), za pretekli dan kosilo ob tipični uri. */
const empty = (isToday: boolean): Draft => { const t = isToday ? hhmm() : null; return { id: null, slot: t ? slotAt(t) : 'kosilo', name: '', kcal: '', prot: '', carb: '', fat: '', grams: '', thumb: null, conf: null, source: 'manual', time: t, createdAt: null } }
/** Hitri popravek količine: pol, za polovico več, dvojno — preračuna kalorije, grame, makrohranila in sestavine. */
const QTY: [number, string, string][] = [[0.5, '½', 'Pol količine'], [1.5, '1½', 'Za polovico več'], [2, '2×', 'Dvojna količina']]
/** (v3.50) oznaka skupnega faktorja količine: ¼, ½, ¾, 1½, 2, 2¼ … (×1 = brez oznake) */
const FRAC: Record<number, string> = { 0.25: '¼', 0.5: '½', 0.75: '¾' }
const qtyTag = (f: number) => { const w = Math.floor(f + 1e-9), r = Math.round((f - w) * 100) / 100; return FRAC[r] ? `${w || ''}${FRAC[r]}` : num(f, 2) }
const TAG_RE = / ?×(\d*[¼½¾]|\d+(?:,\d+)?)$/
const tagVal = (t: string) => { const m = /^(\d*)([¼½¾])?$/.exec(t); return m && (m[1] || m[2]) ? (+(m[1] || 0)) + (m[2] === '¼' ? 0.25 : m[2] === '½' ? 0.5 : m[2] === '¾' ? 0.75 : 0) : +t.replace(',', '.') }
/** (v3.50) količina sestavine s skupnim faktorjem: »100 g ×2« in nato ½ → »100 g« (prej »100 g ×2 ×½«) */
export function scaleQty(qty: string | null | undefined, f: number): string {
  const q = qty || ''
  const m = TAG_RE.exec(q)
  const base = m ? q.slice(0, m.index) : q
  const tot = Math.round((m ? tagVal(m[1]!) : 1) * f * 100) / 100
  return Math.abs(tot - 1) < 0.01 ? base : `${base ? base + ' ' : ''}×${qtyTag(tot)}`
}
export function scaleDraft<T extends { kcal: string; grams: string; prot: string; carb: string; fat: string; items?: MealEntry['items'] }>(d: T, f: number): T {
  const sc = (v: string) => (v.trim() === '' || !Number.isFinite(+v.replace(',', '.')) ? v : String(Math.round(+v.replace(',', '.') * f)))
  return { ...d, kcal: sc(d.kcal), grams: sc(d.grams), prot: sc(d.prot), carb: sc(d.carb), fat: sc(d.fat), items: d.items ? d.items.map(it => ({ ...it, kcal: Math.round(it.kcal * f), qty: scaleQty(it.qty, f) })) : d.items }
}
// (v3.49) vpis iz opisa: opis, kot je shranjen (said), je spet v obrazcu — popraviš ga in oceniš znova
const fromMeal = (m: MealEntry): Draft => ({ id: m.id, slot: m.slot, name: m.name, kcal: String(m.kcal), prot: m.proteinG != null ? String(m.proteinG) : '', carb: m.carbsG != null ? String(m.carbsG) : '', fat: m.fatG != null ? String(m.fatG) : '', grams: m.grams != null ? String(m.grams) : '', thumb: m.thumb || null, conf: m.confidence || null, source: m.source, time: m.time || null, createdAt: m.createdAt, slotSet: true, timeSet: !!m.time, items: m.items || null, ...(m.source === 'text' && m.said ? { desc: m.said } : {}) })
/** (v3.48) ročni vpis: kalorije 1–5 000, grami in makri ne negativni, makri ne več kot gre v kalorije (prej −900 kcal → »Še 4 024 kcal«) */
export function draftError(d: Pick<Draft, 'name' | 'kcal' | 'prot' | 'carb' | 'fat' | 'grams'>): string | null {
  const n = (v: string) => (v.trim() === '' ? 0 : +v.replace(',', '.'))
  const k = Math.round(n(d.kcal) || 0)
  if (!d.name.trim() || !k) return 'Vpiši vsaj ime in kalorije.'
  if (!(k >= 1 && k <= 5000)) return 'Kalorije morajo biti med 1 in 5 000.'
  const [p, c, f, g] = [d.prot, d.carb, d.fat, d.grams].map(n) as [number, number, number, number]
  if (![p, c, f, g].every(x => Number.isFinite(x) && x >= 0)) return 'Grami, beljakovine, OH in maščobe ne morejo biti negativni.'
  // (v3.50) brez žargona »makri«
  if (p * 4 + c * 4 + f * 9 > k * 2 + 100) return 'Beljakovine, OH in maščobe dajo več kalorij od vpisanih — preveri številke.'
  return null
}
/** (v3.48) pogosti obroki: brez goriva na kolesu (vpis goriva ni obrok za ponovitev)
 *  (v3.49) slot = običajni obrok tega imena (najpogostejši), ne zadnji; `now` (obrok zdaj) da ta obrok na začetek */
export function frequentMeals(recent: readonly MealEntry[], now?: MealEntry['slot'] | null): MealEntry[] {
  const m = new Map<string, { n: number; meal: MealEntry; slots: Map<MealEntry['slot'], number> }>()
  for (const x of recent) {
    if (x.slot === 'med_vadbo' || x.fuel || x.forDay) continue
    const k = x.name.trim().toLowerCase(); const e = m.get(k) || { n: 0, meal: x, slots: new Map() }
    e.n++; e.meal = x; e.slots.set(x.slot, (e.slots.get(x.slot) || 0) + 1); m.set(k, e)
  }
  const usual = (s: Map<MealEntry['slot'], number>) => [...s.entries()].sort((a, b) => b[1] - a[1])[0]![0]
  const top = [...m.values()].filter(x => x.n >= 2).sort((a, b) => b.n - a.n).slice(0, 6).map(x => ({ ...x.meal, slot: usual(x.slots) }))
  return now ? [...top].sort((a, b) => (a.slot === now ? 0 : 1) - (b.slot === now ? 0 : 1)) : top
}
/**
 * (v3.49) »Kot včeraj«: včerajšnji vpisi v istem obroku (isti zajtrk vsak dan), brez goriva na kolesu; prazno, če je
 * danes v tem obroku že vpisano isto.
 */
export function yesterdaySame(recent: readonly MealEntry[], today: readonly Pick<MealEntry, 'slot' | 'name'>[], day: string, slot: MealEntry['slot']): MealEntry[] {
  if (slot === 'med_vadbo') return []
  const y = addDays(day, -1)
  const ys = recent.filter(m => m.date === y && m.slot === slot && !m.fuel && !m.forDay).sort(byTime).slice(0, 3)
  const same = (a: string, b: string) => a.trim().toLowerCase() === b.trim().toLowerCase()
  return ys.length && ys.every(m => today.some(t => t.slot === slot && same(t.name, m.name))) ? [] : ys
}
/**
 * (v3.49) »Če si sit, ne jej na silo« šele, ko je večerja vpisana ali je ura 20:30 (prej ob 18h pred večerjo in pred
 * vožnjo — razumljeno kot »preskoči večerjo«), in nikoli, ko vožnja dneva še čaka.
 */
export function eveningHint(hour: number, meals: readonly Pick<MealEntry, 'slot'>[], t: Pick<DailyTarget, 'plannedBurn'>): boolean {
  if (hour < 18 || t.plannedBurn > 0) return false
  // (v3.50) brez vpisanega obroka ne (prej ob 20:30 »ne jej na silo« tudi pri »Še 2 141 kcal« brez enega vpisa)
  if (!meals.some(m => m.slot !== 'med_vadbo')) return false
  return hour >= 20.5 || meals.some(m => m.slot === 'vecerja')
}
/**
 * (v3.50) »Kako je izračunan cilj« po vrsticah s številko na desni (prej ena vrstica s 170 znaki in dvakrat »osnova«:
 * »osnova 2 541 … − osnova med treningom 318 (je že v osnovi)«). Trening je ena vrstica: brez porabe, ki je za čas
 * treninga že v vzdrževanju.
 */
export function targetRows(t: DailyTarget, p: Pick<Profile, 'kcalOverride'>, opts: { garmin?: boolean } = {}): { label: string; value: string; note?: string }[] {
  const f = (n: number) => fmtKcal(n)
  const own = !!p.kcalOverride && !t.minor
  const rows: { label: string; value: string; note?: string }[] = []
  if (own && !t.overrideOff) rows.push({ label: 'Tvoj cilj', value: f(p.kcalOverride!) })
  else {
    rows.push({ label: 'Vzdrževanje brez treninga', value: f(t.maintenance), ...(own && t.overrideOff ? { note: `tvoj cilj ${f(p.kcalOverride!)} danes ne velja` } : {}) })
    if (t.deficit) rows.push({ label: 'Deficit', value: `−${f(t.deficit)}`, ...(t.deficitNote ? { note: t.deficitNote } : {}) })
  }
  const bike = !t.kinds?.length || t.kinds.every(k => k === 'kolo' || k === 'test')
  const what = bike ? 'vožnja' : 'trening'
  const tr = trainingIn(t)
  const gross = t.burn + t.plannedBurn + (t.estimatedBurn || 0)
  if (gross > 0) {
    const bits: string[] = []
    if (t.burn) { const d = t.plannedWas ? t.burn - t.plannedWas : 0; bits.push(`izmerjeno ${f(t.burn)}${t.plannedWas && Math.abs(d) >= 50 ? ` (načrt ${f(t.plannedWas)}, ${d > 0 ? '+' : '−'}${f(Math.abs(d))})` : ''}`) }
    if (t.plannedBurn) bits.push(`po načrtu ~${f(t.plannedBurn)} — ${opts.garmin ? `popravim, ko ${what} pride z Garmina` : `popravim, ko bo ${what} ${bike ? 'zabeležena' : 'zabeležen'}`}`)
    if (t.estimatedBurn) bits.push(`po načrtu ~${f(t.estimatedBurn)} (${what} nima podatka o porabi)`)
    if (t.restIn && t.restIn >= 10) bits.push(`od tega ${f(t.restIn)} že v vzdrževanju`)
    rows.push({ label: 'Trening', value: `+${f(tr)}`, note: bits.join(' · ') })
  } else if (t.plannedDropped) rows.push({ label: 'Trening', value: '0', note: `načrtovanih ~${f(t.plannedDropped)} ni bilo zabeleženih` })
  // (v3.51) dvig na varno mejo je svoja vrstica — vrstice se seštejejo v cilj (prej »Deficit −750 … Cilj 1 237«)
  if (t.clampedToFloor) {
    const pre = (own && !t.overrideOff ? p.kcalOverride! : t.maintenance - (t.deficit || 0)) + tr
    const up = t.kcal - (t.carbLoad || 0) - pre
    if (up > 0) {
      const dRow = rows.find(r => r.label === 'Deficit')
      const eff = Math.max(0, t.deficit - up)
      if (dRow) dRow.note = `danes velja ${eff ? `−${f(eff)}` : '0'} (varna meja)`
      rows.push({ label: 'Dvig na varno mejo', value: `+${f(up)}` })
    }
  }
  if (t.carbLoad) rows.push({ label: 'Polnjenje z OH', value: `+${f(t.carbLoad)}` })
  rows.push({ label: 'Cilj', value: `${f(t.kcal)}${NBSP}kcal`, ...(t.clampedToFloor ? { note: 'dvignjeno na varno mejo' } : {}) })
  return rows
}
/** (v3.51) ura vpisa recepta: zdaj, razen če je obrok šele pred tabo (večerja ob 10:40 → 19:00); pretekli dan tipična ura */
export function logTimeOf(slot: MealEntry['slot'], now: string | null): string {
  if (!now) return TYPICAL[slot]
  return slot !== 'drugo' && slot !== 'med_vadbo' && TYPICAL[slot] > now && slotAt(now) !== slot ? TYPICAL[slot] : now
}
/** (v3.48) barva pojedenega pri obroku: zeleno 85–120 % obroka, čez to opozorilo (prej zeleno tudi »1 500 / 740« in »0 kcal«) */
export function slotTone(got: number, kcal: number): string {
  if (!(got > 0)) return 'var(--ink)'
  if (got > Math.max(kcal * 1.2, kcal + 100)) return 'var(--warn)'
  return got >= kcal * 0.85 ? 'var(--ok)' : 'var(--ink)'
}
/** (v3.50) »Ne« pri »Si ga opravil?«: vprašanje za ta trening ne visi več — skupen zapis z Danes (»Včeraj … si ga naredil?«) in autoMissed */
export function readNoAsk(day: string): string[] { return noIdsOn(day) }
/** (v3.48) ena meja za listanje in povezavo ?dan= — obroki so naloženi 90 dni nazaj */
const MIN_DAY = -90, MAX_DAY = 14
/** Vrstica, ki je v resnici gumb (dostopno s tipkovnico), a izgleda kot besedilo. */
const ROW_BTN: React.CSSProperties = { background: 'none', border: 0, padding: 0, margin: 0, textAlign: 'left', font: 'inherit', color: 'inherit', cursor: 'pointer' }
export type MenuDay = WeekMenu['days'][number] & { belowFloor?: boolean }
/**
 * Dan jedilnika pod spodnjo varno mejo — nikoli ga ne ponudimo kot načrt dneva. Zastavica iz AI dejanja
 * (low/belowFloor), razen če je dan že dopolnjen (addKcal); sicer primerjava z mejo.
 */
export function menuDayLow(x: MenuDay, floor: number | null): boolean {
  const topped = (x.addKcal ?? 0) > 0
  return (!!(x.low || x.belowFloor) && !topped) || (floor != null && x.kcal > 0 && x.kcal < floor)
}

export function Prehrana() {
  const app = useApp()
  const SL = slotsFor(isCustom(app.profile))
  const ai = useAi()
  const route = useRoute()
  const hidden = useHidden()
  const { profile: p, today, plan, activities, settings } = app
  // dan: nazaj do 90 dni (vpisi), naprej do 14 dni (načrt obrokov in recepti za jutri — iz Plana)
  const okDay = (x?: string | null): x is string => !!x && /^\d{4}-\d{2}-\d{2}$/.test(x) && x <= addDays(today, MAX_DAY) && x >= addDays(today, MIN_DAY)
  const [day, setDay] = useState<string>(okDay(route.params.dan) ? route.params.dan : today)
  // (v3.50) »?dan=« v naslovu sledi tudi pri odprtem zaslonu (nazaj/naprej v brskalniku) — prej samo ob prvem izrisu
  useEffect(() => { const x = route.params.dan; setDay(okDay(x) ? x : today) }, [route.params.dan])   // eslint-disable-line react-hooks/exhaustive-deps
  const isToday = day === today
  const future = day > today
  // (v3.49) Prehrana, odprta čez polnoč: če je bil izbran »danes«, gre na nov dan (prej je jutranji zajtrk šel na včeraj)
  const prevToday = useRef(today)
  useEffect(() => { const was = prevToday.current; if (was === today) return; prevToday.current = today; setDay(x => (x === was ? today : x)) }, [today])
  // (v3.50) izbran dan v naslov (brez novega vnosa): osvežitev ali posodobitev ga ne izgubi
  useEffect(() => { replaceParams({ dan: day === today ? null : day }, 'prehrana') }, [day, today])
  // obrok, ki čaka na izbris (»Razveljavi«), je takoj skrit in ne šteje
  const visible = (m: MealEntry) => !hidden.has('meal:' + m.id)
  // (v3.49) izračuni zaslona samo ob spremembi podatkov (prej ob vsakem znaku v listu in v vsaki sličici štetja)
  const meals = useMemo(() => (isToday ? app.mealsToday : app.recentMeals.filter(m => m.date === day)).filter(visible), [isToday, app.mealsToday, app.recentMeals, day, hidden])   // eslint-disable-line react-hooks/exhaustive-deps
  const hourNow = new Date().getHours()
  const dayActs = useMemo(() => activities.filter(a => a.date === day), [activities, day])
  const dayPlan = useMemo(() => plan.filter(d => d.date === day), [plan, day])
  const target = useMemo(() => dailyTarget(p, dayActs, dayPlan, day, { today, hour: hourNow }), [p, dayActs, dayPlan, day, today, hourNow])
  // Za AI: cilj brez aktivnosti, ki jih AI ne sme videti (Strava) — niti posredno prek porabe kalorij
  const aiTarget = useMemo(() => dailyTarget(p, dayActs.filter(aiAllowed), dayPlan, day, { today, hour: hourNow }), [p, dayActs, dayPlan, day, today, hourNow])
  const eaten = sumMeals(meals)
  // (v3.49) štetje v svojem elementu — zaslon se med štetjem ne izrisuje znova
  const shownKcal = <CountUp value={eaten.kcal} id={`kcal:${day}`} format={n => fmtKcal(Math.round(n))} />
  // isti izračun kot na Danes (daymeals.ts): glavna vožnja, vožnja za nami, obroki prilagojeni pojedenemu
  // (v3.50) z uro: nevpisan obrok, katerega čas je mimo, ni več prihodnji (kalorije gredo v naslednje obroke)
  const dayMeals = useMemo(() => (target ? dayMealsOf({ p, target, plan, activities, meals, recentMeals: app.recentMeals, weather: app.weather, day, today, hour: isToday ? hourNow : null }) : null), [p, target, plan, activities, meals, app.recentMeals, app.weather, day, today, isToday, hourNow])
  /** (v3.49) obrok za uro po načrtu dneva (pozno kosilo, malica pred večerno vožnjo, večerja po vožnji), ne samo po uri */
  const slotOfTime = (time: string) => (future ? slotAt(time) : slotFor(time, dayMeals?.dp ?? null, meals))
  const [open, setOpen] = useState(false)
  const [d, setD] = useState<Draft>(() => empty(isToday))
  const nowSlot = isToday ? slotOfTime(hhmm()) : 'kosilo'
  const fresh = (): Draft => { const x = empty(isToday); return x.time ? { ...x, slot: slotOfTime(x.time) } : x }
  // (v3.49) po shranjenem vpisu iz opisa ali slike se polje »Dodaj obrok« izprazni
  const [clearKey, setClearKey] = useState(0)
  /** izbira obroka: drug obrok kot zdaj (zajtrk popoldne) = vpis za nazaj → tipična ura, da gre v seznamu tja */
  const pickSlot = (slot: MealEntry['slot']) => setD(x => ({ ...x, slot, slotSet: true, time: x.timeSet ? x.time : isToday ? (slot === nowSlot ? hhmm() : timeForSlot(slot, hhmm())) : TYPICAL[slot] }))
  /** ura: obrok se ji prilagodi, razen če si ga izbral sam */
  const pickTime = (time: string) => setD(x => ({ ...x, time, timeSet: true, slot: x.slotSet ? x.slot : slotOfTime(time) }))
  const [photoBusy, setPhotoBusy] = useState(false)
  const [textBusy, setTextBusy] = useState(false)
  const [ideas, setIdeas] = useState<{ title: string; seen?: string[]; list: Suggestion[] } | null>(null)
  const [menuOpen, setMenuOpen] = useState(false)
  const [busy, setBusy] = useState<string | null>(null)
  // načrt obrokov: danes najprej samo naslednji obrok (uporabnik: preveč naenkrat), cel dan ob tapu
  const [allMeals, setAllMeals] = useState(false)
  const [fuelOpen, setFuelOpen] = useState(false)
  // recepti: »drug predlog« po obroku, odprt recept, prehranske želje
  // (v3.50) »drug predlog« je shranjen po dnevu (Danes, Plan in nakupovalni seznam kažejo isto jed) — prej samo do odhoda
  const altSaved = settings.recipeAlt?.[day]
  const alt = useMemo<Record<string, number>>(() => (altSaved && typeof altSaved === 'object' ? altSaved : {}), [altSaved])
  const setAlt = (f: (a: Record<string, number>) => Record<string, number>) => { void setRecipeAlt(day, f(alt)) }
  // (v3.49) »recept ›« z Danes: Prehrana se odpre na tem receptu (odprt in v pogledu)
  const wantRecipe = route.params.recept || null
  const [openRecipe, setOpenRecipe] = useState<string | null>(wantRecipe)
  useEffect(() => {
    if (!wantRecipe) return
    const t = setTimeout(() => document.getElementById(`recept-${wantRecipe}`)?.scrollIntoView?.({ block: 'start', behavior: 'smooth' }), 60)
    return () => clearTimeout(t)
  }, [wantRecipe])
  // (v3.49) recept za več oseb (kuhaš za družino ali za dva dni) in nakupovalni seznam iz receptov (brez AI)
  const [persons, setPersons] = useState(1)
  const [shopOpen, setShopOpen] = useState(false)
  const [shopDays, setShopDays] = useState(7)
  // (v3.50) kljukice ostanejo (na tej napravi); (v3.51) 7 dni od dneva, ko si začel — prej so se pobrisale v ponedeljek
  const shopKey = 'formai.shop'
  const [shopGot, setShopGot0] = useState<Record<string, boolean>>({})
  const [shopFrom, setShopFrom] = useState(today)
  const setShopGot = (f: (g: Record<string, boolean>) => Record<string, boolean>) => setShopGot0(g => { const n = f(g); try { localStorage.setItem(shopKey, JSON.stringify({ from: shopFrom, got: n })) } catch { /* zasebni način */ } return n })
  // kljukica po imenu živila (ostane, ko se količina spremeni)
  const shopK = (x: string) => x.split(':')[0]!.trim()
  const openShop = () => { let v: unknown = null; try { v = JSON.parse(localStorage.getItem(shopKey) || 'null') } catch { /* prazno */ } const s0 = shopGotOf(v, today); setShopFrom(s0.from); setShopGot0(s0.got); setShopOpen(true) }
  const [prefsOpen, setPrefsOpen] = useState(false)
  const [prefsText, setPrefsText] = useState(settings.foodPrefs || '')
  const aiMenu = settings.dayMenus?.[day] || null
  // glavna vožnja dneva in gorivo zanjo (temperatura v oknu treninga, koliko običajno spiješ)
  const mainRide = plan.filter(x => x.date === day && (x.kind === 'kolo' || x.kind === 'test') && !x.optional).sort((a, b) => b.durationMin - a.durationMin)[0] || null
  const fctx = fuelCtxOf(app.weather, app.recentMeals, day, today)
  const rfDay = mainRide ? rideFuel(mainRide, p.fuelKit, fctx) : null
  const fuelLog = mainRide ? fuelLogOf(meals, mainRide) : null
  // (v3.49) dolg tek: gorivo na teku (gel in voda) z vpisom — isto kot »Med« na Danes (prej ga Prehrana ni imela)
  const mainRun = mainRide ? null : plan.filter(x => x.date === day && x.kind === 'tek' && !x.optional && x.durationMin >= RUN_FUEL_MIN).sort((a, b) => b.durationMin - a.durationMin)[0] || null
  const rfRun = mainRun ? runFuel(mainRun, fctx) : null
  const runLog = mainRun ? fuelLogOf(meals, mainRun) : null
  const runDone = !!mainRun && (!!mainRun.done || dayActs.some(a => matchesPlanned(a, mainRun)))
  const [runOpen, setRunOpen] = useState(false)
  const nowH = new Date().getHours() + new Date().getMinutes() / 60
  const evening = isToday && !!target && eveningHint(nowH, meals, target)
  const fridgeRef = useRef<HTMLInputElement>(null)
  const [week7, setWeek7] = useState(false)
  const remaining = target ? target.kcal - eaten.kcal : null
  const todayMain = plan.filter(x => x.date === today && x.kind !== 'pocitek' && !x.optional && !x.done).sort((a, b) => (a.kind === 'moc' ? 1 : 0) - (b.kind === 'moc' ? 1 : 0))[0]
  // (v3.49) seja, ki ni zabeležena in po 21h ne šteje več v cilj — vprašamo, ali je bila (prej je cilj tiho padel)
  const [noAsk, setNoAsk] = useState<string[]>(() => readNoAsk(today))
  const missed = isToday && target && (target.plannedDropped || 0) > 0
    ? plan.filter(x => x.date === today && x.kind !== 'pocitek' && !x.optional && !x.done && !noAsk.includes(x.id) && !activities.some(a => a.date === today && matchesPlanned(a, x))).sort((a, b) => b.durationMin - a.durationMin).slice(0, 2)
    : []
  const notDone = (id: string) => { setNoAsk([...noAsk, id]); markNo(id, today); toast('V redu — cilj je brez tega treninga.', 'ok') }

  const frequent = useMemo(() => frequentMeals(app.recentMeals, isToday ? nowSlot : null), [app.recentMeals, isToday, nowSlot])
  // recepti: AI za ta dan (če obrok ni bistveno drugačen od takrat), sicer knjižnica po pravilih — vsak dan druga jed
  // (v3.49) izračun samo ob spremembi (prej ob vsakem znaku v listu vpisa)
  const rctx = useMemo(() => (target && dayMeals ? recipeCtxOf(p, target, settings, dayMeals.training, alt) : null), [p, target, settings, dayMeals, alt])
  const recipes = useMemo(() => (dayMeals && rctx ? recipesOf(dayMeals.dp, day, rctx, settings) : {} as Record<string, Recipe>), [dayMeals, rctx, day, settings])
  const dishN = useMemo((): Record<string, number> => (dayMeals && rctx ? Object.fromEntries(dayMeals.dp.slots.map(sl => [sl.key, dishChoices(sl, rctx)])) : {}), [dayMeals, rctx])
  // (v3.49) »Kot včeraj«: včerajšnji obrok v zdajšnjem terminu z enim tapom (pogosti so šele od 2 enakih imen naprej)
  const ySame = isToday ? yesterdaySame(app.recentMeals, meals, day, nowSlot) : []
  const sameName = (a: string, b: string) => a.trim().toLowerCase() === b.trim().toLowerCase()
  const freqShown = frequent.filter(f => !ySame.some(y => sameName(y.name, f.name)))
  // (v3.49) nakupovalni seznam iz receptov po pravilih za naslednje dni — brez AI in prijave
  // (v3.50) po oddelkih trgovine, zelenjava po vrstah; »drug predlog« iz nastavitev (za vse dni)
  const shopG = useMemo(() => (shopOpen ? shoppingGroups(recipesAhead({ p, plan, activities, meals: app.mealsToday, recentMeals: app.recentMeals, weather: app.weather, today, settings, days: shopDays, targetOf: d => dailyTarget(p, activities.filter(a => a.date === d), plan.filter(x => x.date === d), d) }).flatMap(x => x.recipes), settings.foodPrefs) : []), [shopOpen, shopDays, p, plan, activities, app.mealsToday, app.recentMeals, app.weather, today, settings])
  const shop = useMemo(() => shopG.flatMap(g => g.items), [shopG])
  // (v3.50) AI jedilnik tega tedna ima svoj seznam — pove, da obstaja (prej se seznama nista poznala)
  const menuThisWeek = !!settings.menu && settings.menu.weekStart === weekStartIso(today) && (settings.menu.shopping || []).length > 0

  // (v3.49) vsak dan s svojim ciljem (s treningom tistega dne, kot ga je kazal obroč) — prej »cilj brez treninga«
  const week = useMemo(() => Array.from({ length: 7 }, (_, i) => addDays(today, -6 + i)).map(x => ({
    date: x,
    eaten: (x === today ? app.mealsToday : app.recentMeals.filter(m => m.date === x)).filter(visible).reduce((s, m) => s + m.kcal, 0),
    target: profileComplete(p) ? dailyTarget(p, activities.filter(a => a.date === x), plan.filter(d => d.date === x), x, { today, hour: hourNow })?.kcal ?? null : null,
  })), [p, activities, plan, app.mealsToday, app.recentMeals, today, hourNow, hidden])   // eslint-disable-line react-hooks/exhaustive-deps
  // (v3.50) dan po lokalnem koledarju (T12:00) — samo datum je polnoč UTC in je zahodno od Greenwicha še prejšnji dan
  const bars = week.map(w => ({ label: DAYS_SL[(new Date(w.date + 'T12:00:00').getDay() + 6) % 7]!, value: w.eaten, ref: w.target, color: w.date === day ? 'var(--accent-fg)' : w.target && w.eaten > w.target * 1.1 ? 'var(--warn)' : 'var(--t-kolo)' }))
  const logged = bars.filter(b => b.value > 0)
  // (v3.48) povprečje brez današnjega dneva (še ni končan — en zajtrk ni »povprečno 728 kcal«)
  const past = bars.slice(0, -1).filter(b => b.value > 0)
  const todayKcal = bars[bars.length - 1]!.value
  const wb = weekBalance(week.slice(0, -1))
  // (v3.50) graf bralniku zaslona po dnevih s ciljem (prej »Stolpčni graf, 7 stolpcev, skupaj …«)
  const weekLabel = `Pojedeno po dnevih: ${bars.map(b => `${b.label} ${b.value ? `${fmtKcal(b.value)} kcal` : 'ni vpisa'}${b.ref ? ` od ${fmtKcal(b.ref)}` : ''}`).join(', ')}`
  const avgKcal = wb.avgEaten
  const menu = settings.menu && settings.menu.weekStart === weekStartIso(today) ? settings.menu : null
  const menuDay = (menu?.days.find(x => x.date === day) || null) as MenuDay | null
  /** Spodnja varna meja dneva jedilnika (BMR / 1500 / 1200 + načrtovan trening). */
  const floorOf = (x: MenuDay) => x.floorKcal ?? dailyTarget(p, [], plan.filter(q => q.date === x.date), x.date)?.floor ?? null
  const topped = (x: MenuDay) => (x.addKcal ?? 0) > 0
  const below = (x: MenuDay) => menuDayLow(x, floorOf(x))

  // (v3.51) zapora: dva Enterja (samoponavljanje) ali Enter in »Shrani«, preden se list zapre, sta dala dva obroka
  const savingRef = useRef(false)
  async function save() {
    if (savingRef.current) return
    savingRef.current = true
    try { await saveNow() } finally { savingRef.current = false }
  }
  async function saveNow() {
    const err = draftError(d)
    if (err) { toast(err, 'err'); return }
    const k = Math.round(+d.kcal)
    // (v3.51) decimalke z vejico (»12,5 g« z deklaracije)
    const dec = (v: string) => Math.round(+v.replace(',', '.') * 10) / 10
    const orig = d.id ? meals.find(m => m.id === d.id) : undefined     // ohrani polja, ki jih obrazec ne kaže (vpis goriva)
    // (v3.50) po polnoči »za včeraj«: obrok gre na prejšnji dan
    await addMeal({ ...(orig || {}), id: d.id || uid(), date: d.yesterday && !d.id ? addDays(day, -1) : day, time: d.time || (isToday ? hhmm() : TYPICAL[d.slot]), slot: d.slot, name: d.name.trim(), grams: d.grams ? +d.grams : null, kcal: k, proteinG: d.prot ? dec(d.prot) : null, carbsG: d.carb ? dec(d.carb) : null, fatG: d.fat ? dec(d.fat) : null, confidence: d.conf, source: d.source, thumb: d.thumb, items: d.items && d.items.length ? d.items : null, said: d.desc ? normSaid(d.desc) : orig?.said ?? null, createdAt: d.createdAt || new Date().toISOString() })
    setOpen(false)
    if (d.fromInput) setClearKey(x => x + 1)
    // (v3.51) obrok je vpisan brez AI: napaka AI (»AI zdaj ne more odgovoriti …«) ni več za reševati — zapri jo (ne tistih z gumbom)
    if (d.aiDown || d.photoDown || d.noLogin) for (const t of getState().toasts ?? []) if (t.kind === 'err' && !t.action) dismissToast(t.id)
    toast(d.id ? 'Popravljeno.' : d.yesterday ? 'Vpisano za včeraj.' : 'Dodano.', 'ok')
  }
  // (v3.50) zadnja slika obroka — »Poskusi znova«, ko AI ni odgovoril
  const lastPhoto = useRef<File | null>(null)
  async function fromPhoto(file: File) {
    lastPhoto.current = file
    let failed = false
    // profil ob klicu (po privolitvi je nov), ne iz izrisa; (v3.50) »ocenjujem« šele po privolitvi
    const m = await ai.run(() => { setPhotoBusy(true); return mealFromPhoto(getState().profile, file, aiTarget ? aiTarget.kcal - eaten.kcal : null, aiTarget ? aiTarget.proteinG - eaten.p : null) }, { onError: () => { failed = true } })
    setPhotoBusy(false)
    if (!m) {
      // (v3.50) AI ni odgovoril ali prijave ni: ročni vpis s sliko (prej se ni zgodilo nič in slika je bila izgubljena)
      if (failed || (!getState().user && import.meta.env.VITE_E2E !== '1')) await photoManual(file, failed ? 'ai' : 'login')
      return
    }
    // ura posnetka (EXIF ali čas datoteke iz galerije) → obrok po uri; brez tega zdaj
    const time = photoTime(day, today, m.photo, file.lastModified || null)
    const { photo: _ph, ...meal } = m
    void _ph
    setD({ ...fromMeal({ ...meal, date: day, time, slot: time ? slotOfTime(time) : meal.slot }), id: null, slotSet: false, timeSet: !!time, fromInput: true })
    setOpen(true)
  }
  /** (v3.50) slika brez AI: list ročnega vpisa s sličico in uro posnetka */
  async function photoManual(file: File, why: 'ai' | 'login') {
    let thumb: string | null = null, time: string | null = null
    try { thumb = (await fileToBase64Resized(file, 110, 0.7)).thumb } catch { /* brez sličice (brskalnik ne riše) */ }
    try { time = photoTime(day, today, await exifStamp(file), file.lastModified || null) } catch { time = null }
    const x = fresh()
    setD({ ...x, ...(time ? { time, slot: slotOfTime(time), timeSet: true } : {}), thumb, aiDown: true, photoDown: why, fromInput: true })
    setOpen(true)
  }
  /**
   * Opis z besedilom ali glasom → AI oceni po sestavinah → preveri in shrani (vse številke je mogoče popraviti).
   * (v3.49) keep: popravek shranjenega vpisa (»Oceni znova« pri urejanju) — ista vrstica, obrok in ura ostaneta.
   * Ko AI ne odgovori (brez povezave, napaka strežnika), se opis prenese v ročni vpis.
   */
  // (v3.51) »Kosilo: …« izbere obrok (in uro, kot ob tapu na obrok); ime brez predpone
  const typed = (desc: string, x: Draft): Draft => {
    const pre = mealTypeFromText(desc)
    if (!pre || x.slotSet) return x
    return { ...x, slot: pre.slot, slotSet: true, name: x.name.replace(/^\s*(zajtrk|malica|kosilo|ve[čc]erja|prigrizek)\s*[:–—-]\s*/i, '') || x.name, time: x.timeSet ? x.time : isToday ? (pre.slot === nowSlot ? hhmm() : timeForSlot(pre.slot, hhmm())) : TYPICAL[pre.slot] }
  }
  async function fromText(desc: string, force = false, keep?: Draft) {
    // isto kot zadnjič: tvoje številke (morda popravljene), brez nove ocene — AI ocena se lahko vsakič razlikuje
    const prev = force || keep ? null : sameMealBefore([...app.mealsToday, ...app.recentMeals], desc)
    if (prev) {
      const time = isToday ? hhmm() : TYPICAL[prev.slot]
      setD({ ...fromMeal({ ...prev, date: day, time, thumb: null }), id: null, createdAt: null, slot: isToday ? slotOfTime(time!) : prev.slot, slotSet: false, timeSet: false, desc, prevFrom: prev.date, question: null, fromInput: true })
      setOpen(true)
      return
    }
    // (v3.50) brez prijave: takoj ocena iz tabele živil (prej Googlova prijava ali »Prijava ni uspela«, opis je obtičal
    // v polju); AI z gumbom v listu. Brez povezave gre po starem (AI ni dosegljiv → ročni vpis z oceno brez AI).
    if (!force && !keep && !getState().user && import.meta.env.VITE_E2E !== '1' && !(typeof navigator !== 'undefined' && navigator.onLine === false)) {
      setD(typed(desc, { ...fresh(), name: desc.trim().slice(0, 120), noLogin: true, fromInput: true, ...localDraft(desc) }))
      setOpen(true)
      return
    }
    let failed = false
    // (v3.50) »Ocenjujem …« šele, ko AI res dela — ne med odprtim listom privolitve
    const m = await ai.run(() => { setTextBusy(true); return mealFromText(getState().profile, desc, aiTarget ? aiTarget.kcal - eaten.kcal : null, aiTarget ? aiTarget.proteinG - eaten.p : null) }, { onError: () => { failed = true } })
    setTextBusy(false)
    if (!m) {
      // (v3.49) brez AI: opis gre v ročni vpis (prej samo obvestilo, obroka ni bilo) — ne pri popravku shranjenega
      // (v3.49) s tabelo živil že ocenjen (ocena brez AI), če prepozna živila v opisu
      if (failed && !keep) { setD(typed(desc, { ...fresh(), name: desc.trim().slice(0, 120), aiDown: true, fromInput: true, ...localDraft(desc) })); setOpen(true) }
      // (v3.50) prijava preklicana ali ni uspela: ocena iz tabele živil (prej je opis obtičal v polju)
      else if (!keep && !getState().user && import.meta.env.VITE_E2E !== '1') { setD(typed(desc, { ...fresh(), name: desc.trim().slice(0, 120), noLogin: true, fromInput: true, ...localDraft(desc) })); setOpen(true) }
      return
    }
    const { question, aiSlot, ...meal } = m
    if (keep) {
      setD({ ...fromMeal({ ...meal, date: day, time: keep.time, slot: keep.slot }), id: keep.id, createdAt: keep.createdAt, slotSet: true, timeSet: keep.timeSet, thumb: keep.thumb, question, desc })
      setOpen(true)
      return
    }
    // za pretekli dan: obrok in ura iz opisa ali tipična ura obroka
    const time = isToday ? meal.time || hhmm() : aiSlot ? TYPICAL[meal.slot] : null
    setD(typed(desc, { ...fromMeal({ ...meal, date: day, time, slot: aiSlot ? meal.slot : time ? slotOfTime(time) : 'kosilo' }), id: null, slotSet: aiSlot, timeSet: isToday && !!meal.time && meal.time !== hhmm(), question, desc, fromInput: true }))
    setOpen(true)
  }
  // »Slikaj obrok« na Danes: slika je že izbrana, tu jo preberemo
  useEffect(() => { const f = takeMealPhoto(); if (f) void fromPhoto(f) }, [])   // eslint-disable-line react-hooks/exhaustive-deps
  async function fridge(file: File) {
    setBusy('fridge')
    const r = await ai.run(() => fridgeMeals(getState().profile, file, aiTarget ? aiTarget.kcal - eaten.kcal : null, aiTarget ? aiTarget.proteinG - eaten.p : null, todayMain?.title || null))
    setBusy(null)
    if (r) setIdeas({ title: 'Kaj naj skuham', seen: r.seen, list: r.ideas })
  }
  async function suggest() {
    if (!target || !aiTarget) return
    setBusy('ideas')
    const r = await ai.run(() => mealIdeas(snapOf(getState()), Math.max(300, aiTarget.kcal - eaten.kcal), aiTarget.proteinG - eaten.p))
    setBusy(null)
    if (r) setIdeas({ title: 'Predlogi za preostanek dneva', list: r })
  }
  async function makeMenu() {
    if (!target || !aiTarget) return
    setBusy('menu')
    const base = dailyTarget(p, [], [], today)
    const r = await ai.run(() => weekMenu(snapOf(getState()), base ? base.kcal : aiTarget.kcal, aiTarget.proteinG, frequent.map(f => f.name)))
    setBusy(null)
    if (r) { await setMenu(r); setMenuOpen(true); toast('Jedilnik in nakupovalni seznam sta pripravljena.', 'ok') }
  }
  /** Recepti za obroke dneva z AI (shranjeni za ta dan); obroki brez uporabnega recepta ostanejo po pravilih. */
  async function makeRecipes(slots: readonly MealSlotPlan[]) {
    if (!target || !aiTarget) return
    setBusy('recipes')
    const r = await ai.run(() => dayRecipesAi(snapOf(getState()), slots, getState().settings.foodPrefs || null, todayMain?.title || null, { deficit: target.deficit > 0, keepMuscle: !!p.focus?.keepMuscle }))
    setBusy(null)
    if (!r) return
    const n = Object.keys(r).length
    if (!n) { toast('AI ni vrnil uporabnih receptov — veljajo recepti po pravilih.', 'err', 6000); return }
    await setDayMenu(day, r)
    setAlt(a => Object.fromEntries(Object.entries(a).filter(([k]) => !(k in r))))   // AI recept se pokaže tudi, če si prej prosil za drug predlog
    toast(n === slots.length ? `Recepti za ${isToday ? 'danes' : 'ta dan'} so pripravljeni.` : `AI recepti za ${n} od ${slots.length} obrokov; ostali po pravilih.`, 'ok')
  }
  async function logRecipe(sl: MealSlotPlan, r: Recipe) {
    // (v3.51) obrok, ki je šele pred tabo (večerja ob 10:40), dobi svojo tipično uro; obvestilo z »Razveljavi«
    const id = uid()
    await addMeal({ id, date: day, time: logTimeOf(sl.slot, isToday ? hhmm() : null), slot: sl.slot, name: r.name, grams: null, kcal: r.kcal, proteinG: r.p, carbsG: r.c, fatG: r.f, confidence: 'srednja', source: 'suggest', thumb: null, createdAt: new Date().toISOString() })
    toast(`Vpisano: ${r.name}.`, 'ok', 6000, { label: 'Razveljavi', run: () => { void removeMeal(id) } })
  }
  async function logIdea(s: Suggestion) {
    await addMeal({ id: uid(), date: day, time: isToday ? hhmm() : TYPICAL[nowSlot], slot: nowSlot, name: s.name, grams: null, kcal: s.kcal, proteinG: s.proteinG, carbsG: s.carbsG, fatG: s.fatG, confidence: 'srednja', source: 'suggest', thumb: null, createdAt: new Date().toISOString() })
    toast(`Vpisano: ${s.name}.`, 'ok')
  }
  /** (v3.49) pogost obrok gre v svoj običajni obrok (zajtrk ostane zajtrk, za nazaj ob tipični uri), ne v zdajšnjega */
  async function repeat(m: MealEntry) {
    const r = isToday ? repeatSlot(m.slot, hhmm(), meals, dayMeals?.dp ?? null) : { slot: m.slot, time: TYPICAL[m.slot], back: false }
    await addMeal({ ...m, id: uid(), date: day, time: r.time, slot: r.slot, thumb: null, createdAt: new Date().toISOString(), fluidMl: null, planMl: null, forDay: null, fuel: null })
    toast(r.back ? `Vpisano kot ${SLOT_NAME[r.slot]} (${fmtTime(r.time)}): ${m.name}. Tapni vrstico, če je bilo drugače.` : `Dodano: ${m.name}.`, 'ok', r.back ? 6000 : undefined)
  }
  /** (v3.49) »Kot včeraj«: isti obrok kot včeraj v tem terminu, ura zdaj */
  async function sameAsYesterday(ms: readonly MealEntry[]) {
    for (const m of ms) await addMeal({ ...m, id: uid(), date: day, time: hhmm(), slot: nowSlot, thumb: null, createdAt: new Date().toISOString(), fluidMl: null, planMl: null, forDay: null, fuel: null })
    toast(`Kot včeraj dodano: ${ms.map(m => m.name).join(' + ')}.`, 'ok')
  }
  // (v3.50) kopiranje z rezervo: brez odložišča obvestilo in besedilo v polju za ročno kopiranje (prej tiho nič)
  const [copyFail, setCopyFail] = useState<{ where: 'menu' | 'shop'; text: string } | null>(null)
  async function copyList(t: string, where: 'menu' | 'shop') {
    const ok = await copyText(t)
    setCopyFail(ok ? null : { where, text: t })
    toast(ok ? 'Seznam kopiran.' : 'Kopiranje ni uspelo — označi besedilo in ga kopiraj ročno.', ok ? 'ok' : 'err', ok ? undefined : 6000)
  }
  /** (v3.51) seznam deli (WhatsApp, partner), kjer telefon to zna; sicer kopira */
  async function shareList(t: string, where: 'menu' | 'shop') {
    const nav = typeof navigator !== 'undefined' ? (navigator as Navigator & { share?: (d: { title?: string; text?: string }) => Promise<void> }) : null
    if (nav?.share) { try { await nav.share({ title: 'Nakupovalni seznam', text: t }); return } catch (e) { if ((e as { name?: string })?.name === 'AbortError') return } }
    await copyList(t, where)
  }
  /** Izbris z »Razveljavi«: obrok takoj izgine, iz shrambe gre čez 5 s. */
  const remove = (m: MealEntry) => deferDelete('meal:' + m.id, `Izbrisano: ${m.name}`, () => removeMeal(m.id))
  const busyIs = (k: string) => busy === k && ai.busy

  // seznam dneva po času (kot je bilo pojedeno), ne po vrsti obroka
  const timeline = [...meals].sort(byTime).map(m => ({ m, g: SL.find(s => s.key === m.slot) || SL[SL.length - 1]! }))
  const menuLines = (x: MenuDay) => ([['Zajtrk', x.zajtrk], ['Kosilo', x.kosilo], ['Malica', x.malica], ['Večerja', x.vecerja]] as const).filter(y => y[1])

  return (<>
    <Head hi={fmtDateLong(day)} nm="Prehrana" />
    <div className="scroll">
      <div className="cols">
      <div className="col">
      <div className="between" style={{ marginBottom: 12 }}>
        <button className="chip sm click" disabled={day <= addDays(today, MIN_DAY)} onClick={() => day > addDays(today, MIN_DAY) && setDay(addDays(day, -1))}><IcoBack width={13} height={13} /> prejšnji</button>
        {!isToday && <button className="chip sm click on" onClick={() => setDay(today)}>danes</button>}
        <button className="chip sm click" disabled={day >= addDays(today, MAX_DAY)} onClick={() => day < addDays(today, MAX_DAY) && setDay(addDays(day, 1))}>naslednji <IcoBack width={13} height={13} style={{ transform: 'scaleX(-1)' }} /></button>
      </div>

      {!profileComplete(p) ? (
        <Empty icon={<IcoFood width={30} height={30} style={{ color: 'var(--ok)' }} />} title="Za kalorije rabim tvoj profil" text="Višina, teža, starost in spol. Brez tega ti številke ne pokažem — raje prazno kot narobe.">
          <Btn sm onClick={() => navigate('nastavitve', { sec: 'n-profil' })}>Izpolni profil</Btn>
        </Empty>
      ) : target && (
        <Card className="page nut-hero">
          {future ? (
            // (v3.48) dan šele pride: samo cilj, brez obroča »0 od …«
            <div className="nut-goal">
              <div className="muted" style={{ fontSize: rem(11), fontWeight: 800, letterSpacing: '.06em', textTransform: 'uppercase' }}>Cilj tega dne</div>
              <div style={{ marginTop: 4 }}><b className="num" style={{ fontSize: rem(30), fontWeight: 800, letterSpacing: '-.03em' }}>{fmtKcal(target.kcal)}</b><span className="muted" style={{ fontSize: rem(13), fontWeight: 700 }}>{NBSP}kcal</span></div>
              <div style={{ fontSize: rem(12.5), fontWeight: 700, color: 'var(--ink-2)', marginTop: 4 }}>B {target.proteinG}{NBSP}g · OH {target.carbsG}{NBSP}g · M {target.fatG}{NBSP}g</div>
            </div>
          ) : (
          <div className="ring-wrap">
            {/* obroč: pojedeno sveti v limeti, kar ostane je rahlo obarvano — ne siv krog (Blaž, 14. 10.: »brez življenja«) */}
            <Ring size={122} stroke={12} pct={eaten.kcal / target.kcal} rest over={eaten.kcal > target.kcal * 1.1}><div><b className="num">{shownKcal}</b><small>od {fmtKcal(target.kcal)}{NBSP}kcal</small></div></Ring>
            <div className="macro">
              {([['Beljakovine', 'Beljakovine', eaten.p, target.proteinG, 'var(--m-b)'], ['Ogljikovi hidrati', 'OH', eaten.c, Math.max(1, target.carbsG), 'var(--m-oh)'], ['Maščobe', 'Maščobe', eaten.f, Math.max(1, target.fatG), 'var(--m-m)']] as const).map(([l, ls, got, goal, col], i) => (
                <div key={l} className="m" style={{ ['--i' as string]: i, ['--c' as string]: col }}><div className="t"><span><i className="m-dot" aria-hidden="true" />{ls !== l ? <><span className="m-l">{l}</span><span className="m-s">{ls}</span></> : l}</span><span>{Math.round(got)} / {goal}{NBSP}g</span></div><Track pct={got / goal * 100} color={col} /></div>
              ))}
            </div>
          </div>
          )}
          <div className="between" style={{ marginTop: 15, paddingTop: 13, borderTop: '1px solid var(--line)' }}>
            <div style={{ fontSize: rem(12), color: 'var(--ink-3)', fontWeight: 600, minWidth: 0 }}>
              {!future && <DayBalance remaining={remaining} proteinLeft={Math.round(target.proteinG - eaten.p)} past={day < today} logged={meals.length > 0} />}
            </div>
            {/* (v3.51) »Varno« sam ni povedal, kaj je varno: cilj je nad spodnjo varno mejo */}
            <span title={target.minor || target.clampedToFloor ? undefined : `Cilj je nad spodnjo varno mejo (${fmtKcal(target.floor)} kcal) — razlaga pod »Kako je izračunan cilj«.`}><Chip sm ok={!target.clampedToFloor}>{target.minor ? 'Vzdrževanje' : target.clampedToFloor ? 'Spodnja meja' : 'Nad varno mejo'}</Chip></span>
          </div>
          {target.clampedToFloor && !target.minor && <div className="muted" style={{ fontSize: rem(11.5), marginTop: 8 }}>Cilj je na spodnji varni meji ({fmtKcal(target.floor)}{NBSP}kcal) — nižje ne gre, tudi če bi izračun tako pokazal.{target.deficit > 0 ? ' Če je tako pogosto, v Nastavitvah zmanjšaj deficit.' : ''}</div>}
          {missed.map(x => (
            <div key={x.id} className="row missed-ask">
              <span>Trening »{titleNoDur(x.title, x.durationMin)}« še ni zabeležen, zato ga ne štejem v cilj (−{fmtKcal(missed.length === 1 ? target.plannedDropped! : planNetKcal(x, p))}{NBSP}kcal). {p.sex === 'z' ? 'Si ga opravila?' : 'Si ga opravil?'}</span>
              <Btn ghost sm onClick={() => { void setPlanDone(x.id, true).then(() => toast('Zabeleženo — trening spet šteje v cilj.', 'ok')) }}><IcoCheck width={15} height={15} /> Opravljeno</Btn>
              {/* (v3.50) »Ne«: vprašanje ne visi do polnoči */}
              <Btn ghost sm onClick={() => notDone(x.id)}>Ne</Btn>
            </div>
          ))}
          <details className="more">
            <summary>Kako je izračunan cilj</summary>
            <dl className="target-rows">{targetRows(target, p, { garmin: !!settings.intervals }).map((r, i, all) => (
              <div key={r.label} className={i === all.length - 1 ? 'tot' : undefined}><dt>{r.label}{r.note ? <small>{r.note}</small> : null}</dt><dd className="num">{r.value}</dd></div>
            ))}</dl>
            <div>{target.deficit > 0 ? `Deficit je samo pri obrokih, nikoli ${SL !== SLOTS || (target.kinds?.length && !target.kinds.every(k => k === 'kolo' || k === 'test')) ? 'med vadbo' : 'na kolesu'}.` : target.deficitNote ? `Brez deficita: ${target.deficitNote}.` : ''}</div>
          </details>
          {/* (v3.50) zvečer brez enega vpisa: ne »ne jej na silo«, ampak vpiši */}
          {isToday && nowH >= 20.5 && !meals.some(m => m.slot !== 'med_vadbo') && <div className="muted" style={{ fontSize: rem(11.5), marginTop: 6 }}>Danes ni vpisanih obrokov — vpiši vsaj večerjo, sicer trener misli, da nisi {p.sex === 'z' ? 'jedla' : 'jedel'}.</div>}
          {evening && remaining != null && remaining > 600 && <div className="muted" style={{ fontSize: rem(11.5), marginTop: 6 }}>Če si {g(p, 'sit', 'sita')}, ne jej na silo — zvečer raje nekaj z beljakovinami in OH ({eveningSnack(settings.foodPrefs)}). Šteje tedensko povprečje, ne en dan.{mainRide?.done && !fuelLog && rfDay?.totalCarbs ? ` Vpiši tudi, kaj si ${g(p, 'popil in pojedel', 'popila in pojedla')} na kolesu — tudi to so kalorije.` : ''}</div>}
          <HealthNote kind="food" />
        </Card>
      )}

      {future ? (
        <p className="muted" style={{ fontSize: rem(12.5), margin: '12px 0 0' }}>Načrt obrokov za {dayAcc(day)}, {dm(day)} — kaj in koliko jesti glede na trening tega dne. Vpisuješ, ko bo dan tu.</p>
      ) : (
      <div style={{ marginTop: 12 }}>
        <MealInput sex={p.sex} forDay={isToday ? null : `${dayAcc(day)}, ${dm(day)}`} onText={t => void fromText(t)} onPhoto={f => void fromPhoto(f)} busy={photoBusy ? 'photo' : textBusy ? 'text' : null} autoFocus={route.params.opis === '1'} onError={msg => toast(msg, 'err', 7000)} clearKey={clearKey} />
        {ySame.length > 0 && <div className="row" style={{ gap: 6, flexWrap: 'wrap', marginTop: 8 }}>
          <button type="button" className="chip sm click" onClick={() => void sameAsYesterday(ySame)} style={{ maxWidth: '100%' }} aria-label={`Kot včeraj: ${ySame.map(m => m.name).join(' + ')} — dodaj`}><IcoPlus width={12} height={12} /><span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', minWidth: 0 }}>Kot včeraj: {ySame.map(m => m.name).join(' + ')}</span><span className="muted">{fmtKcal(ySame.reduce((a, m) => a + m.kcal, 0))}{NBSP}kcal</span></button>
        </div>}
        {/* kar ješ pogosto: en tap, brez posebne kartice */}
        {freqShown.length > 0 && <div className="row" style={{ gap: 6, flexWrap: 'wrap', marginTop: 8 }} aria-label="Pogosti obroki">
          {freqShown.slice(0, 4).map(m => <button key={m.id} type="button" className="chip sm click" onClick={() => repeat(m)} style={{ maxWidth: '100%' }}><IcoPlus width={12} height={12} /><span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', minWidth: 0 }}>{m.name}</span><span className="muted">{fmtKcal(m.kcal)}{NBSP}kcal</span></button>)}
        </div>}
      </div>
      )}

      {!future && <div className="between" style={{ margin: '17px 0 10px' }}><h2 className="h4" style={{ margin: 0 }}>{isToday ? 'Danes' : fmtDateLong(day)}</h2><span className="muted" style={{ fontSize: rem(12), fontWeight: 700 }}>{fmtKcal(eaten.kcal)}{NBSP}kcal · {Math.round(eaten.p)}{NBSP}g B</span></div>}
      {!future && <div className="stack stagger" style={{ gap: 9 }}>
        {timeline.map(({ m, g }) => (
          <Card key={m.id} tight className="row meal-row" style={{ gap: 12 }}>
            {m.thumb ? <img src={m.thumb} alt="" width={36} height={36} style={{ borderRadius: 'var(--r-s)', objectFit: 'cover', flex: 'none' }} /> : <div className="meal-ico" style={{ ['--c' as string]: slotColor(m.slot) }}><g.Ico width={18} height={18} /></div>}
            <button type="button" style={{ ...ROW_BTN, flex: 1, minWidth: 0 }} aria-label={`Uredi: ${m.name}`} onClick={() => { if (m.forDay && mainRide && m.forDay === mainRide.id && rfDay) { setFuelOpen(true); return } if (m.forDay && mainRun && m.forDay === mainRun.id && rfRun) { setRunOpen(true); return } setD(fromMeal(m)); setOpen(true) }}>
              <b style={{ fontSize: rem(14), display: 'block' }}>{g.label}{m.time ? <span className="muted" style={{ fontWeight: 600, fontSize: rem(12) }}> · {fmtTime(m.time)}</span> : null}</b>
              <span className="muted clamp2" style={{ fontSize: rem(12) }}>{m.name}{m.grams ? ` · ${m.grams}${NBSP}g` : ''}{m.proteinG != null ? ` · B ${m.proteinG}${NBSP}g` : ''}{m.confidence === 'nizka' ? ' · ocena' : ''}</span>
            </button>
            <b style={{ fontSize: rem(14), flex: 'none' }}>{fmtKcal(m.kcal)}<span className="muted" style={{ fontSize: rem(11.5), fontWeight: 700 }}>{NBSP}kcal</span></b>
            <button className="chip sm click icon-x" onClick={() => remove(m)} aria-label={`Izbriši: ${m.name}`}>×</button>
          </Card>
        ))}
        {/* (v3.50) obrok zdaj je že vpisan (kosilo ob 14:14): »Dodaj obrok«, ne še enkrat »Dodaj kosilo« */}
        <button type="button" className="card tight row" style={{ gap: 12, borderStyle: 'dashed', color: 'var(--ink-3)', cursor: 'pointer', textAlign: 'left', width: '100%' }} onClick={() => { setD(fresh()); setOpen(true) }}>
          <div style={{ width: 36, height: 36, borderRadius: 'var(--r-s)', border: '1px dashed var(--line)', display: 'grid', placeItems: 'center', flex: 'none' }}><IcoPlus width={16} height={16} /></div>
          <div style={{ flex: 1, minWidth: 0 }}><b style={{ fontSize: rem(14), color: 'var(--ink-2)' }}>Dodaj {isToday && !(nowSlot !== 'drugo' && meals.some(m => m.slot === nowSlot)) ? SLOT_ACC[nowSlot] : 'obrok'}</b><div style={{ fontSize: rem(12) }}>ročno — kalorije in beljakovine</div></div>
        </button>
      </div>}

      </div>
      <div className="col">
      {target && dayMeals && (() => {
        const dm = dayMeals
        const { dp, main, rideDone } = dm
        const dayTraining = plan.filter(x => x.date === day && x.kind !== 'pocitek' && !x.optional)
        const rf = rfDay
        const gotOf = (sl: MealSlotPlan) => gotOfSlot(sl, meals)
        const next = nextSlotOf(dp, meals, isToday ? nowH : null)
        // (v3.48) koliko si danes nad ciljem (sporočilo namesto »Vsi obroki pojedeni«)
        const over = isToday && remaining != null && remaining < 0 ? -remaining : 0
        // (v3.49) recept z Danes, ki ni naslednji obrok: cel dan, da je recept viden
        const short = isToday && !allMeals && !(!!wantRecipe && openRecipe === wantRecipe && next?.key !== wantRecipe && dp.slots.some(x => x.key === wantRecipe))
        const slots = short ? (next ? [next] : []) : dp.slots
        // (v3.48) kratki pogled: »Na kolesu« samo, ko je vožnja na vrsti (obrok pred njo ali po njej), ne takoj za zajtrkom
        const rideNext = !next || !!next.beforeRide || next.key === 'obnova'
        // (v3.50) po vožnji brez vpisa goriva »Na kolesu« tudi v kratkem pogledu (prej samo v celem dnevu — edina pot, da gorivo šteje)
        const fuelAsk = rideDone && !fuelLog && !!rf && rf.plan.length > 0
        const bikeShown = !!dp.onBike && !!main && (!short || (!rideDone && rideNext) || fuelAsk)
        // (v3.49) »Na kolesu« enkrat, za zadnjim obrokom pred vožnjo (dan tekme ima dva: zajtrk in pred startom)
        // (v3.50) po vožnji pred obrokom po njej, v kratkem pogledu na vrhu
        const bikeAfter = rideDone ? null : [...slots].reverse().find(x => x.beforeRide)?.key ?? null
        const bikeBefore = slots.find(x => x.key === 'obnova' && (short || rideDone))?.key ?? (rideDone && short ? slots[0]?.key ?? null : null)
        const bikePlaced = slots.some(x => x.key === bikeAfter || x.key === bikeBefore)
        // (v3.50) nevpisan obrok, katerega čas je mimo, in drobiž nad ciljem (pod 120 kcal) — brez številke kalorij
        const tinyOf = (sl: MealSlotPlan) => !sl.skipped && sl.kcal < TINY_KCAL && sl.key !== 'obnova' && sl.key !== 'pred'
        const pLeft = Math.round(target.proteinG - eaten.p)
        const pastDay = day < today
        const recipeOf = (sl: MealSlotPlan): Recipe | null => (sl.skipped || (tinyOf(sl) && !gotOf(sl)) ? null : recipes[sl.key] ?? null)
        // »drug predlog« le, če je za obrok več jedi (po željah)
        const canAlt = (sl: MealSlotPlan) => (dishN[sl.key] ?? 0) > 1 || (recipeOf(sl)?.by === 'ai' && (dishN[sl.key] ?? 0) > 0)
        // AI piše recepte za obroke, ki še niso pojedeni in niso drobiž
        const aiSlots = dp.slots.filter(sl => gotOf(sl) < sl.kcal * 0.85 && sl.kcal >= MIN_RECIPE_KCAL && !sl.skipped)
        // »Na kolesu« med obrokom pred vožnjo in po njej (prej čisto na koncu, za »Zvečer«)
        const bikeEl = bikeShown && dp.onBike && main ? (<div style={{ padding: '9px 0', borderTop: '1px solid var(--line)' }}>
                <div className="between" style={{ fontSize: rem(13) }}><b style={{ color: 'var(--ink)', minWidth: 0 }}>Na kolesu <span className="muted" style={{ fontWeight: 600, fontSize: rem(11.5) }}>· {fmtDur(main.durationMin)}</span></b><span style={{ fontWeight: 800, flex: 'none', ...(rideDone && !fuelLog ? { color: 'var(--warn)' } : {}) }}>{rideDone ? (fuelLog ? `${fmtKcal(fuelLog.kcal)}${NBSP}kcal` : 'ni vpisano') : `${rf ? rf.carriedCarbs : dp.onBike.carbs}${NBSP}g OH`}</span></div>
                {/* (v3.50) po vožnji brez »Vzemi:« in časovnice — pomemben je samo vpis */}
                {rf && rideDone && <>
                  {!fuelLog && <div style={{ fontSize: rem(12.5), marginTop: 3, color: 'var(--ink-2)' }}>Načrt je bil ~{rf.carriedCarbs}{NBSP}g OH, {l1(rf.fluidMl)}{NBSP}l. Do vpisa obroki računajo, da na kolesu ni bilo nič.</div>}
                  <div className="row" style={{ gap: 8, marginTop: 6, alignItems: 'center' }}>
                    <button className="chip sm click" onClick={() => setFuelOpen(true)}>{fuelLog ? 'uredi vpis' : `vpiši, kaj si ${g(p, 'porabil', 'porabila')}`}</button>
                    {fuelLog && <span className="muted" style={{ fontSize: rem(12) }}>vpisano {fmtKcal(fuelLog.kcal)}{NBSP}kcal{fuelLog.fluidMl != null ? ` · ${num(Math.round(fuelLog.fluidMl / 50) * 50 / 1000, 2)}${NBSP}l` : ''}</span>}
                  </div>
                </>}
                {rf && !rideDone && <>
                  <div style={{ fontSize: rem(12.5), marginTop: 3, color: 'var(--ink-2)' }}>Vzemi: {nb(rf.items.join(' · '))}</div>
                  <div className="muted" style={{ fontSize: rem(12), marginTop: 3 }}>{nb(rf.cues.length ? drinkLine(rf) : rf.schedule)}</div>
                  <FuelTimeline rf={rf} minutes={main.durationMin} />
                  <div className="row" style={{ gap: 8, marginTop: 6, alignItems: 'center' }}>
                    <button className="chip sm click" onClick={() => setFuelOpen(true)}>{fuelLog ? 'uredi vpis' : `vpiši, kaj si ${g(p, 'porabil', 'porabila')}`}</button>
                    {fuelLog && <span className="muted" style={{ fontSize: rem(12) }}>vpisano {fmtKcal(fuelLog.kcal)}{NBSP}kcal{fuelLog.fluidMl != null ? ` · ${num(Math.round(fuelLog.fluidMl / 50) * 50 / 1000, 2)}${NBSP}l` : ''}</span>}
                  </div>
                </>}
              </div>) : null
        return (
          <Card style={{ marginTop: 12 }}>
            <div className="between"><h2 className="h4" style={{ margin: 0 }}>{short ? 'Naslednji obrok po načrtu' : isToday ? 'Danes jej po načrtu' : 'Načrt obrokov za ta dan'}</h2><span className="muted" style={{ fontSize: rem(12), fontWeight: 700, flex: 'none' }}>{short ? `dan ${fmtKcal(dp.total)}${NBSP}kcal` : `${fmtKcal(dp.total)}${NBSP}kcal`}</span></div>
            {/* obroki so pomerjeni na trening tega dne — povezava Prehrana → Plan */}
            {dayTraining.length > 0 && <button type="button" style={{ ...ROW_BTN, display: 'block', width: '100%', marginTop: 2, padding: '7px 0', minHeight: 34, fontSize: rem(12.5), color: 'var(--ink-2)' }} onClick={() => navigate('plan', { dan: day })} aria-label={`Trening tega dne v Planu: ${dayTraining.map(x => x.title).join(', ')}`}>
              Pomerjeno na {isToday ? 'današnji' : 'ta'} trening: <b style={{ color: 'var(--ink)' }}>{dayTraining.map(x => `${titleNoDur(x.title, x.durationMin)} · ${fmtDur(x.durationMin)}${x.done || dayActs.some(a => matchesPlanned(a, x)) ? ' ✓' : ''}`).join(' · ')}</b> <span style={{ color: 'var(--accent-fg)', fontWeight: 700 }}>plan ›</span>
            </button>}
            {short && (over > 0 || !next) && <p style={{ fontSize: rem(12.5), marginTop: 8, color: 'var(--ink-2)' }}>{over > 0 ? `Danes si že nad ciljem (+${fmtKcal(over)}${NBSP}kcal).${next?.key === 'obnova' ? ' Ostane samo obnova po vožnji.' : !next ? ' Jutri spet normalno po načrtu.' : ''}` : dp.slots.every(sl => gotOf(sl) > 0 && gotOf(sl) >= sl.kcal * 0.85) ? 'Vsi obroki po načrtu so za danes pojedeni.' : nowH >= 22 ? `Pozno je — če si ${g(p, 'lačen', 'lačna')}, nekaj lahkega z beljakovinami (jogurt, skuta). Jutri spet po načrtu.` : 'Za danes ni več obrokov po načrtu.'}</p>}
            {/* (v3.50) kalorije dosežene, beljakovin manjka: beljakovinski prigrizek, ne »Večerja 30 kcal« */}
            {isToday && remaining != null && remaining < 200 && pLeft >= 20 && <p style={{ fontSize: rem(12.5), marginTop: 8, color: 'var(--ink-2)' }}>Kalorije so za danes {remaining < 0 ? 'presežene' : 'dosežene'}, beljakovin manjka še {pLeft}{NBSP}g — zvečer skuta ali jogurt (~250{NBSP}kcal). Šteje tedensko povprečje.</p>}
            {dp.race && <div style={{ marginTop: 8, padding: '9px 11px', borderRadius: 12, background: 'var(--raised)', border: '1px solid var(--line)', fontSize: rem(12.5), color: 'var(--ink-2)' }}><b style={{ color: 'var(--warn)' }}>Malo vlaknin pred tekmo</b><div style={{ marginTop: 3 }}>{nb(dp.tip)}</div></div>}
            <div className="stack" style={{ gap: 0, marginTop: 8 }}>
              {slots.map(sl => { const got = gotOf(sl); const r = recipeOf(sl); const openR = openRecipe === sl.key; const tiny = !got && tinyOf(sl); return (<Fragment key={sl.key}>
                {sl.key === bikeBefore ? bikeEl : null}
                <div className="slot-row" id={`recept-${sl.key}`} style={{ padding: '9px 0', borderTop: '1px solid var(--line)', ['--c' as string]: slotColor(sl.label === 'Zvečer' ? 'zvecer' : sl.key) }}>
                  <div className="between" style={{ fontSize: rem(13) }}><b style={{ color: 'var(--ink)', minWidth: 0, display: 'inline-flex', alignItems: 'center', gap: 7 }}><i className="m-dot" aria-hidden="true" />{sl.label}{sl.when && !(sl.key === 'zajtrk' && sl.when === 'zjutraj') ? <span className="muted" style={{ fontWeight: 600, fontSize: rem(11.5) }}> · {sl.when}</span> : null}</b>{sl.skipped ? <span className="muted" style={{ fontWeight: 700, flex: 'none' }}>ni vpisan</span> : tiny ? <span className="muted" style={{ fontWeight: 800, flex: 'none' }} aria-label="po želji">—</span> : <span style={{ fontWeight: 800, flex: 'none', color: slotTone(got, sl.kcal) }}>{got ? `${fmtKcal(got)} / ${fmtKcal(sl.kcal)}` : fmtKcal(r ? r.kcal : sl.kcal)}{NBSP}kcal</span>}</div>
                  {sl.skipped ? (
                    <div className="row" style={{ gap: 8, marginTop: 3, alignItems: 'center', flexWrap: 'wrap' }}>
                      <span style={{ fontSize: rem(12.5), color: 'var(--ink-2)', flex: 1, minWidth: 160 }}>{p.sex === 'z' ? 'Če si ga jedla' : 'Če si ga jedel'}, ga vpiši — sicer gre v naslednje obroke.</span>
                      <button type="button" className="chip sm click" onClick={() => { setD({ ...fresh(), slot: sl.slot, slotSet: true, time: TYPICAL[sl.slot] }); setOpen(true) }}><IcoPlus width={12} height={12} /> vpiši</button>
                    </div>
                  ) : r ? (<>
                    <button type="button" style={{ ...ROW_BTN, display: 'block', width: '100%', marginTop: 4 }} aria-expanded={openR} onClick={() => setOpenRecipe(openR ? null : sl.key)}>
                      <span className="between" style={{ display: 'flex', gap: 8 }}>
                        <span style={{ minWidth: 0 }}><b style={{ fontSize: rem(14), color: 'var(--ink)' }}>{r.name}</b><span className="muted" style={{ fontSize: rem(12) }}> · {r.minutes}{NBSP}min{r.by === 'ai' ? ' · AI' : ''}</span></span>
                        <IcoChevDown width={16} height={16} aria-hidden="true" style={{ flex: 'none', color: 'var(--ink-3)', transform: openR ? 'rotate(180deg)' : 'none', transition: 'transform .2s' }} />
                      </span>
                      <span className="muted" style={{ display: 'block', fontSize: rem(12), marginTop: 2 }}>B {r.p}{NBSP}g · OH {r.c}{NBSP}g · M {r.f}{NBSP}g{got ? ` · jed ${fmtKcal(r.kcal)}${NBSP}kcal` : ''}</span>
                    </button>
                    {openR && (
                      <div className="recipe" style={{ marginTop: 8 }}>
                        <div className="between recipe-head"><div className="h4" style={{ fontSize: rem(10.5), margin: 0 }}>Sestavine</div>
                          <div className="row recipe-persons" role="group" aria-label="Količine za koliko oseb">{[1, 2, 3, 4].map(n => <button key={n} type="button" className={`chip sm click${persons === n ? ' on' : ''}`} aria-pressed={persons === n} onClick={() => setPersons(n)}>{n}</button>)}<span className="muted">{persons === 1 ? 'oseba' : persons === 2 ? 'osebi' : 'osebe'}</span></div>
                        </div>
                        <ul className="recipe-ing">{scaleIngredients(r, persons, settings.foodPrefs).map((t, i) => <li key={i}>{t}</li>)}</ul>
                        {persons > 1 && <p className="muted" style={{ fontSize: rem(12), marginTop: 4 }}>Količine za {persons} {persons === 2 ? 'osebi' : 'osebe'}. Tvoj obrok je ena porcija: {fmtKcal(r.kcal)}{NBSP}kcal · B {r.p}{NBSP}g.</p>}
                        <div className="h4" style={{ fontSize: rem(10.5), margin: '8px 0 0' }}>Priprava · {r.minutes}{NBSP}min</div>
                        <ol className="recipe-steps">{scaleSteps(r.steps, persons).map((st, i) => <li key={i}>{st}</li>)}</ol>
                        <p className="muted" style={{ fontSize: rem(12), marginTop: 8 }}><b style={{ color: 'var(--ink-2)' }}>Zakaj zate:</b> {r.why}</p>
                        <div className="row recipe-acts" style={{ gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
                          {/* (v3.50) pretekli dan: za nazaj ni »drug predlog« in »vpiši, ko poješ« */}
                          {canAlt(sl) && !pastDay && <button type="button" className="chip sm click" onClick={() => { if (!alt[sl.key]) toast(isToday ? 'Za danes velja ta jed — tudi na Danes in v nakupovalnem seznamu.' : 'Za ta dan velja ta jed — tudi v Planu in nakupovalnem seznamu.', 'ok'); setAlt(a => ({ ...a, [sl.key]: (a[sl.key] || 0) + 1 })) }}>drug predlog</button>}
                          {!got && <button type="button" className="chip sm click" onClick={() => void logRecipe(sl, r)}><IcoPlus width={12} height={12} /> {pastDay ? (p.sex === 'z' ? 'vpiši, da si to jedla' : 'vpiši, da si to jedel') : 'pojedeno — vpiši'}</button>}
                        </div>
                      </div>
                    )}
                  </>) : <div style={{ fontSize: rem(12.5), marginTop: 3, color: 'var(--ink-2)' }}>npr. {nb(sl.example)}</div>}
                </div>{sl.key === bikeAfter ? bikeEl : null}</Fragment>) })}
              {!bikePlaced && bikeEl}
              {mainRun && rfRun && (<div className="run-fuel" style={{ padding: '9px 0', borderTop: '1px solid var(--line)' }}>
                <div className="between" style={{ fontSize: rem(13) }}><b style={{ color: 'var(--ink)', minWidth: 0 }}>Na teku <span className="muted" style={{ fontWeight: 600, fontSize: rem(11.5) }}>· {fmtDur(mainRun.durationMin)}</span></b><span style={{ fontWeight: 800, flex: 'none', ...(runDone && !runLog ? { color: 'var(--warn)' } : {}) }}>{runDone ? (runLog ? `${fmtKcal(runLog.kcal)}${NBSP}kcal` : 'ni vpisano') : `${rfRun.carriedCarbs}${NBSP}g OH`}</span></div>
                {/* (v3.51) po teku kot po kolesu: brez »Vzemi:« in časovnice, samo vpis */}
                {runDone ? (!runLog && <div style={{ fontSize: rem(12.5), marginTop: 3, color: 'var(--ink-2)' }}>Načrt je bil ~{rfRun.carriedCarbs}{NBSP}g OH, {l1(rfRun.fluidMl)}{NBSP}l.</div>) : <>
                <div style={{ fontSize: rem(12.5), marginTop: 3, color: 'var(--ink-2)' }}>Vzemi: {nb(rfRun.items.join(' · '))}</div>
                <div className="muted" style={{ fontSize: rem(12), marginTop: 3 }}>{nb(rfRun.schedule)}</div>
                <FuelTimeline rf={rfRun} minutes={mainRun.durationMin} /></>}
                <div className="row" style={{ gap: 8, marginTop: 6, alignItems: 'center' }}>
                  <button className="chip sm click" onClick={() => setRunOpen(true)}>{runLog ? 'uredi vpis' : `vpiši, kaj si ${g(p, 'porabil', 'porabila')}`}</button>
                  {runLog && <span className="muted" style={{ fontSize: rem(12) }}>vpisano {fmtKcal(runLog.kcal)}{NBSP}kcal{runLog.fluidMl != null ? ` · ${num(Math.round(runLog.fluidMl / 50) * 50 / 1000, 2)}${NBSP}l` : ''}</span>}
                </div>
              </div>)}
            </div>
            <div className="row" style={{ gap: 6, marginTop: 10, flexWrap: 'wrap' }}>
              {isToday && <button type="button" className="chip sm click" aria-expanded={allMeals} onClick={() => setAllMeals(!allMeals)}>{allMeals ? 'samo naslednji obrok' : `cel dan po načrtu · ${dp.slots.length} ${dp.slots.length === 1 ? 'obrok' : dp.slots.length === 2 ? 'obroka' : dp.slots.length <= 4 ? 'obroki' : 'obrokov'} ›`}</button>}
              {app.user && day >= today && aiSlots.length > 0 && <button type="button" className="chip sm click" disabled={ai.busy} onClick={() => void makeRecipes(aiSlots)}><IcoSpark width={12} height={12} /> {busyIs('recipes') ? 'Pišem recepte …' : aiMenu ? 'AI recepti znova' : 'AI recepti zate'}</button>}
              {day >= today && <button type="button" className="chip sm click" onClick={openShop}>nakupovalni seznam</button>}
              <button type="button" className="chip sm click" onClick={() => { setPrefsText(settings.foodPrefs || ''); setPrefsOpen(true) }}>{settings.foodPrefs ? `želje: ${settings.foodPrefs.slice(0, 22)}${settings.foodPrefs.length > 22 ? '…' : ''}` : 'prehranske želje'}</button>
            </div>
            {/* (v3.50) razlog po vzroku: pri 0 kcal pojedenega in nevpisanem gorivu ni »prilagojeni pojedenemu« */}
            {dp.adjusted && <p style={{ fontSize: rem(12), marginTop: 8, color: 'var(--ink-2)' }}>{[
              meals.some(m => m.slot !== 'med_vadbo') ? `Preostali obroki so prilagojeni pojedenemu${meals.some(m => m.slot === 'med_vadbo') ? ' in gorivu na kolesu' : ''}.` : meals.length ? 'Preostali obroki so prilagojeni gorivu na kolesu.' : '',
              dp.fuelMissing ? 'Gorivo na kolesu ni vpisano, zato obroki računajo, da na vožnji ni bilo nič — vpiši ga.' : '',
              // (v3.51) z nevpisanim gorivom manjko ni zaradi hrane (obroki so do vpisa omejeni) — brez »ne jej na silo«
              dp.short && !dp.fuelMissing ? `Do cilja manjka še ~${fmtKcal(dp.short)}${NBSP}kcal — če si ${g(p, 'sit', 'sita')}, ne jej na silo.` : '',
            ].filter(Boolean).join(' ')}</p>}
            {/* na hitro: vidno samo bistvo nasveta za ta dan; razlaga pod »Zakaj tako« */}
            {!dp.race && gist(dp.tip) && <p style={{ fontSize: rem(12.5), marginTop: 8, color: 'var(--ink-2)' }}><b style={{ color: 'var(--ink)' }}>Nasvet:</b> {nb(gist(dp.tip, 140))}</p>}
            <details className="more" style={{ marginTop: 6 }}>
              <summary>Zakaj tako</summary>
              {/* (v3.48) brez ponovljenega nasveta nad njim (prej 410 znakov): samo ostanek nasveta in kratka razlaga */}
              <p className="muted" style={{ fontSize: rem(12), marginTop: 6 }}>{(() => { if (dp.race) return ''; const t = dp.tip.replace(/\s+/g, ' ').trim(), g = gist(t, 140); return t.startsWith(g) ? (t.slice(g.length).trim() ? `${nb(t.slice(g.length).trim())} ` : '') : `${nb(t)} ` })()}{bikeShown && dp.onBike ? `Hrana na kolesu je že v dnevnem cilju — šteje, ko vpišeš, kar si ${g(p, 'porabil', 'porabila')}. ` : ''}Recepti so pomerjeni na tvoje kalorije in beljakovine, vsak dan druga jed. Obroke vpiši ali slikaj.</p>
            </details>
          </Card>
        )
      })()}

      {target && isToday && (
        <div className="row" style={{ gap: 8, marginTop: 12, flexWrap: 'wrap' }}>
          <Btn ghost sm disabled={ai.busy} onClick={suggest}>{busyIs('ideas') ? 'Razmišljam …' : 'Predlagaj obrok'}</Btn>
          <Btn ghost sm disabled={ai.busy} onClick={() => fridgeRef.current?.click()}><IcoCamera width={14} height={14} /> {busyIs('fridge') ? 'Gledam …' : 'Slikaj hladilnik'}</Btn>
          <input ref={fridgeRef} type="file" accept="image/*" capture="environment" style={{ display: 'none' }} onChange={e => { const f = e.target.files?.[0]; e.target.value = ''; if (f) void fridge(f) }} />
        </div>
      )}

      {menuDay ? (
        <button type="button" className="card tight" style={{ marginTop: 12, width: '100%', textAlign: 'left', cursor: 'pointer', display: 'block', borderColor: below(menuDay) ? 'var(--warn)' : undefined }} onClick={() => setMenuOpen(true)}>
          <div className="between"><h2 className="h4" style={{ fontSize: rem(11), margin: 0 }}>Jedilnik · {fmtKcal(menuDay.kcal)}{NBSP}kcal</h2><span className="muted" style={{ fontSize: rem(12), fontWeight: 700, flex: 'none' }}>teden in nakup ›</span></div>
          {below(menuDay) ? (
            // pod varno mejo: ne ponujamo ga kot načrt za ta dan
            <div className="row" style={{ gap: 8, marginTop: 8, alignItems: 'flex-start' }}>
              <IcoWarn width={15} height={15} aria-hidden="true" style={{ color: 'var(--warn)', flex: 'none', marginTop: 2 }} />
              <span style={{ fontSize: rem(12.5), color: 'var(--ink-2)' }}>Jedilnik za ta dan je pod tvojo varno mejo{floorOf(menuDay) ? ` (${fmtKcal(floorOf(menuDay)!)}${NBSP}kcal)` : ''} — ne jej po njem. Drži se načrta obrokov zgoraj ali sestavi jedilnik znova.</span>
            </div>
          ) : menuLines(menuDay).map(([l, t]) => <div key={l} style={{ fontSize: rem(12.5), marginTop: 5 }}><span className="muted">{l}</span> <span style={{ color: 'var(--ink)' }}>{t}</span></div>)}
        </button>
      ) : target && app.user && isToday ? (
        <div style={{ marginTop: 8 }}><Btn ghost sm disabled={ai.busy} onClick={makeMenu}>{busyIs('menu') ? 'Sestavljam jedilnik …' : 'Jedilnik za teden + nakupovalni seznam'}</Btn></div>
      ) : null}

      <div style={{ marginTop: 14 }}>
      {/* (v3.50) povprečje in število dni iz istih dni (brez današnjega) + »danes« (prej »povprečno … · 4/7 dni« iz 3 dni) */}
      <Section id="h-7dni" title="Zadnjih 7 dni" sum={past.length ? `povprečno ${fmtKcal(avgKcal)}${NBSP}kcal${wb.avgTarget ? ` · cilj ${fmtKcal(wb.avgTarget)}` : ''} · ${count(past.length, W.dan)}${todayKcal ? ' + danes' : ''}` : todayKcal ? `danes do zdaj ${fmtKcal(todayKcal)}${NBSP}kcal` : 'ni vnosov'} open={week7} onToggle={() => setWeek7(o => !o)}>
        <div style={{ marginTop: 2 }}><BarChart bars={bars} height={130} unit="kcal" title="Pojedeno po dnevih; črtica = cilj tistega dne" label={weekLabel} /></div>
        {bars.some(b => b.ref) && <div className="muted week-refs">{bars.every(b => b.ref === bars[0]!.ref) ? <>cilj vsak dan {fmtKcal(bars[0]!.ref!)}{NBSP}kcal</> : <>cilj: {bars.map((b, i) => <span key={i}>{b.label}{NBSP}{b.ref ? fmtKcal(b.ref) : '—'}</span>)}</>}</div>}
        {target && logged.length > 0 && <div className="muted" style={{ fontSize: rem(11.5), marginTop: 6 }}>{wb.diff != null && past.length ? `${Math.abs(wb.diff) < 25 ? 'Na cilju teh dni' : `${fmtKcal(Math.abs(wb.diff))}${NBSP}kcal ${wb.diff < 0 ? 'pod' : 'nad'} ciljem teh dni`} (povprečno ${fmtKcal(wb.avgTarget!)}${NBSP}kcal). ` : ''}Črtica = cilj tistega dne (s treningom), oranžno = več kot 10 % nad njim · zabeleženih {logged.length}/7 dni.{todayKcal > 0 && past.length ? ' Povprečje je brez današnjega dneva, ki še ni končan.' : ''} Kar ni zabeleženo, trener ne vidi.</div>}
      </Section>
      </div>
      </div>
      </div>
    </div>

    <Sheet open={open} onClose={() => setOpen(false)}>
      <div className="row" style={{ gap: 12 }}>
        {d.thumb && <img src={d.thumb} alt="" width={48} height={48} style={{ borderRadius: 'var(--r-s)', objectFit: 'cover' }} />}
        {/* (v3.50) vpis za drug dan pove, za kateri dan (prej list »Dodaj obrok« za soboto brez datuma) */}
        <div><b style={{ fontSize: rem(17), letterSpacing: '-.02em' }}>{d.id ? 'Uredi vnos' : d.source === 'photo' || d.source === 'text' ? 'Preveri in shrani' : 'Dodaj obrok'}{!d.id && (d.yesterday || !isToday) ? <span className="muted" style={{ fontWeight: 700, fontSize: rem(13.5) }}> · {d.yesterday ? 'za včeraj' : `${dayName(day)}, ${dm(day)}`}</span> : null}</b>{d.conf && <div className="muted" style={{ fontSize: rem(12) }}>zanesljivost ocene: {d.conf}{d.grams ? ` · ${d.grams}${NBSP}g` : ''}</div>}</div>
      </div>
      {d.prevFrom && !d.id && (
        <div className="row prev-same" style={{ gap: 8, alignItems: 'center', marginTop: 10, flexWrap: 'wrap' }}>
          <span style={{ fontSize: rem(12.5), color: 'var(--ink-2)', flex: 1, minWidth: 160 }}>Kot zadnjič ({dm(d.prevFrom)}) — tvoje številke, brez nove ocene.</span>
          <button type="button" className="chip sm click" disabled={textBusy} onClick={() => { const t = d.desc || d.name; setOpen(false); void fromText(t, true) }}>Oceni z AI</button>
        </div>
      )}
      <div className="row" style={{ gap: 7, flexWrap: 'wrap', margin: '12px 0' }}>
        {SL.map(s => <Chip key={s.key} sm on={d.slot === s.key} onClick={() => pickSlot(s.key)}>{s.label}</Chip>)}
      </div>
      <div className="row" style={{ gap: 10, alignItems: 'center', margin: '-4px 0 12px' }}>
        <label className="muted" htmlFor="meal-time" style={{ fontSize: rem(12.5), fontWeight: 700 }}>Ura</label>
        <input id="meal-time" className="time-inp" type="time" value={d.time || ''} onChange={e => e.target.value && pickTime(e.target.value)} />
        <span className="muted" style={{ fontSize: rem(11.5) }}>{!d.time ? `brez ure: ${fmtTime(TYPICAL[d.slot])}` : isToday && !d.yesterday && d.slot !== nowSlot && d.slot !== 'drugo' && d.slot !== 'med_vadbo' && !d.id ? 'vpis za nazaj' : 'obrok se ravna po uri'}</span>
      </div>
      {/* (v3.50) po polnoči: pozna večerja gre lahko na včeraj (prej samo nov dan kot »Drugo · 00:15«) */}
      {isToday && !d.id && new Date().getHours() < 3 && (
        <div className="row" style={{ gap: 8, alignItems: 'center', margin: '-4px 0 12px' }}>
          <Chip sm on={!!d.yesterday} onClick={() => setD(x => { const on = !x.yesterday; const yv = app.recentMeals.some(m => m.date === addDays(day, -1) && m.slot === 'vecerja'); return { ...x, yesterday: on, slot: on ? (yv ? 'drugo' : 'vecerja') : slotOfTime(x.time || hhmm()), slotSet: on } })}>Pozno? Vpiši za včeraj</Chip>
        </div>
      )}
      {/* (v3.51) Enter v polju shrani (na namizju prej samo z miško) */}
      <div className="stack" style={{ gap: 10 }} onKeyDown={e => { const t = e.target as HTMLInputElement; if (e.key === 'Enter' && t.tagName === 'INPUT' && t.type !== 'time') { e.preventDefault(); if (!e.repeat) void save() } }}>
        {d.aiDown && (
          <div className="row" role="status" style={{ gap: 8, alignItems: 'flex-start', padding: '10px 12px', borderRadius: 'var(--r-s)', background: 'var(--raised)' }}>
            <IcoInfo width={15} height={15} aria-hidden="true" style={{ color: 'var(--accent-fg)', flex: 'none', marginTop: 2 }} />
            <span style={{ fontSize: rem(12.5), color: 'var(--ink-2)', flex: 1 }}>{d.photoDown ? (d.photoDown === 'ai' ? 'AI ta hip ni dosegljiv — slika ostane ob vpisu. Vpiši ime in kalorije ali poskusi znova.' : 'Slike brez prijave AI ne oceni — slika ostane ob vpisu. Vpiši ime in kalorije ali se prijavi in poskusi znova.') : d.local ? 'AI ta hip ni dosegljiv — spodaj je ocena brez AI iz tabele živil. Preveri količine ali prekliči in oceni pozneje (opis ostane v polju).' : 'AI ta hip ni dosegljiv — vpiši kalorije sam ali prekliči in oceni pozneje (opis ostane v polju).'}
              {d.photoDown && lastPhoto.current && <><br /><button type="button" className="chip sm click" style={{ marginTop: 6 }} disabled={photoBusy} onClick={() => { const f = lastPhoto.current; setOpen(false); if (f) void fromPhoto(f) }}>Poskusi znova</button></>}</span>
          </div>
        )}
        {/* (v3.50) brez prijave: ocena iz tabele živil, AI z enim tapom (prijava) */}
        {d.noLogin && !d.id && (
          <div className="row" role="status" style={{ gap: 8, alignItems: 'flex-start', padding: '10px 12px', borderRadius: 'var(--r-s)', background: 'var(--raised)' }}>
            <IcoInfo width={15} height={15} aria-hidden="true" style={{ color: 'var(--accent-fg)', flex: 'none', marginTop: 2 }} />
            <span style={{ fontSize: rem(12.5), color: 'var(--ink-2)', flex: 1 }}>{d.local ? 'Ocena iz tabele živil — brez prijave.' : 'V tabeli živil tega ne najdem — vpiši kalorije ročno.'} Z Googlovo prijavo oceni AI tudi jedi, ki jih tabela ne pozna.
              <br /><button type="button" className="chip sm click" style={{ marginTop: 6 }} disabled={textBusy || ai.busy} onClick={() => { const t = d.name; setOpen(false); void fromText(t, true) }}><IcoSpark width={12} height={12} /> Oceni z AI (prijava)</button></span>
          </div>
        )}
        {d.items && d.items.length > 0 && (
          <div>
            <div className="muted" style={{ fontSize: rem(11), fontWeight: 800, letterSpacing: '.06em', textTransform: 'uppercase' }}>{d.local ? 'Ocena brez AI · tabela živil' : 'Ocena po sestavinah'}</div>
            <div className="meal-items">{d.items.map((it, i) => <div key={i}><span>{it.name}{it.qty ? <span className="muted"> · {it.qty}</span> : null}</span><span>{fmtKcal(it.kcal)}{NBSP}kcal</span></div>)}</div>
            {d.local && d.local.length > 0 && <div className="muted" style={{ fontSize: rem(12), marginTop: 4 }}>Ne poznam: {d.local.map(x => `»${x}«`).join(', ')} — te kalorije dodaj ročno.</div>}
          </div>
        )}
        {d.question && (
          <div className="row" style={{ gap: 8, alignItems: 'flex-start', padding: '10px 12px', borderRadius: 'var(--r-s)', background: 'var(--raised)' }}>
            <IcoInfo width={15} height={15} aria-hidden="true" style={{ color: 'var(--accent-fg)', flex: 'none', marginTop: 2 }} />
            <span style={{ fontSize: rem(12.5), color: 'var(--ink-2)' }}>{d.question} Dopiši v opis spodaj in oceni znova, ali popravi številke.</span>
          </div>
        )}
        {/* (v3.49) tudi pri urejanju shranjenega vpisa iz opisa: popravi opis (»tri jajca«, »pol«) in oceni znova */}
        {d.source === 'text' && d.desc != null && (
          <div className="field"><label htmlFor="meal-desc2">Opis</label>
            <textarea id="meal-desc2" rows={2} value={d.desc} onChange={e => setD({ ...d, desc: e.target.value })} style={{ background: 'var(--card)', border: '1px solid var(--line)', borderRadius: 'var(--r-m)', padding: '12px 14px', color: 'var(--ink)', fontSize: rem(15), lineHeight: 1.45, resize: 'none', outline: 'none', width: '100%' }} />
            <div style={{ marginTop: 8 }}><Btn ghost sm disabled={textBusy || ai.busy || (d.desc || '').trim().length < 2} onClick={() => void fromText(d.desc || '', false, d.id ? d : undefined)}><IcoSpark width={14} height={14} /> {textBusy ? 'Ocenjujem …' : 'Oceni znova'}</Btn></div>
          </div>
        )}
        <div className="field"><label htmlFor="meal-name">Kaj si {g(p, 'pojedel', 'pojedla')}</label><input id="meal-name" value={d.name} onChange={e => setD({ ...d, name: e.target.value })} placeholder="npr. skuta z jagodami" autoFocus={(!d.thumb && !d.id && !d.aiDown) || !!d.photoDown} /></div>
        {/* (v3.49) brez AI (brez prijave ali povezave): oceni iz tabele živil, ki jo uporabljajo recepti */}
        {/* (v3.51) po oceni iz tabele (brez prijave, AI ni odgovoril) ni še enega gumba za isto oceno */}
        {!d.id && d.source === 'manual' && d.name.trim().length >= 3 && !d.local && !d.noLogin && (
          <div><button type="button" className="chip sm click" onClick={() => { const x = localDraft(d.name); if (x) setD({ ...d, ...x }); else toast('V tabeli živil tega ne najdem — vpiši npr. »ovseni kosmiči 70 g, jogurt 200 g« ali kalorije sam.', 'info', 6000) }}>Oceni brez AI (tabela živil)</button></div>
        )}
        {+d.kcal > 0 && (
          <div className="row" role="group" aria-label="Količina obroka" style={{ gap: 6, alignItems: 'center' }}>
            <span className="muted" style={{ fontSize: rem(12), fontWeight: 700, marginRight: 2 }}>Količina</span>
            {QTY.map(([f, l, al]) => <button key={l} type="button" className="chip sm click" aria-label={al} onClick={() => setD(scaleDraft(d, f))}>{l}</button>)}
          </div>
        )}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div className="field"><label htmlFor="meal-kcal">Kalorije <span className="unit">kcal</span></label><input id="meal-kcal" type="number" inputMode="numeric" min={1} value={d.kcal} onChange={e => setD({ ...d, kcal: e.target.value })} autoFocus={!!d.aiDown && !d.photoDown} /></div>
          <div className="field"><label htmlFor="meal-grams">Grami <span className="unit">neobvezno</span></label><input id="meal-grams" type="number" inputMode="numeric" min={0} value={d.grams} onChange={e => setD({ ...d, grams: e.target.value })} /></div>
          <div className="field"><label htmlFor="meal-prot">Beljakovine <span className="unit">g</span></label><DecimalInput id="meal-prot" value={d.prot} onChange={e => setD({ ...d, prot: e.target.value })} /></div>
          <div className="field"><label htmlFor="meal-carb">Ogljikovi h. <span className="unit">g</span></label><DecimalInput id="meal-carb" value={d.carb} onChange={e => setD({ ...d, carb: e.target.value })} /></div>
          <div className="field"><label htmlFor="meal-fat">Maščobe <span className="unit">g</span></label><DecimalInput id="meal-fat" value={d.fat} onChange={e => setD({ ...d, fat: e.target.value })} /></div>
        </div>
      </div>
      <Btn primary block style={{ marginTop: 14 }} onClick={save}>Shrani</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={() => setOpen(false)}>Prekliči</Btn>
      {/* (v3.50) izbris iz lista (z »Razveljavi«), ne samo »×« v seznamu */}
      {d.id && (() => { const m = meals.find(x => x.id === d.id); return m ? <Btn ghost sm style={{ marginTop: 9, display: 'block', marginInline: 'auto' }} onClick={() => { setOpen(false); remove(m) }}>Izbriši vnos</Btn> : null })()}
    </Sheet>

    <Sheet open={!!ideas} onClose={() => setIdeas(null)}>
      <b style={{ fontSize: rem(17), letterSpacing: '-.02em' }}>{ideas?.title}</b>
      {ideas?.seen && ideas.seen.length > 0 && <p style={{ fontSize: rem(12), marginTop: 6 }}>Vidim: {ideas.seen.join(', ')}</p>}
      <div className="stack" style={{ gap: 10, marginTop: 12 }}>
        {(ideas?.list || []).map((s, i) => (
          <Card key={i} tight>
            <div className="between"><b style={{ fontSize: rem(14.5), minWidth: 0 }}>{s.name}</b><b style={{ fontSize: rem(13), flex: 'none' }}>{fmtKcal(s.kcal)}{NBSP}kcal</b></div>
            <p style={{ fontSize: rem(12.5), marginTop: 4 }}>{s.desc}</p>
            <div className="muted" style={{ fontSize: rem(11.5), marginTop: 4 }}>B {s.proteinG}{NBSP}g · OH {s.carbsG}{NBSP}g · M {s.fatG}{NBSP}g{s.minutes ? ` · ${s.minutes}${NBSP}min` : ''}{s.missing ? ` · manjka: ${s.missing}` : ''}</div>
            <button className="chip sm click" style={{ marginTop: 8 }} onClick={() => logIdea(s)}><IcoPlus width={12} height={12} /> vpiši, ko poješ</button>
          </Card>
        ))}
      </div>
      <Btn ghost block style={{ marginTop: 12 }} onClick={() => setIdeas(null)}>Zapri</Btn>
    </Sheet>

    <Sheet open={menuOpen && !!menu} onClose={() => { setMenuOpen(false); setCopyFail(null) }}>
      <b style={{ fontSize: rem(17), letterSpacing: '-.02em' }}>Jedilnik za teden</b>
      {menu?.note && <p style={{ fontSize: rem(12.5), marginTop: 6 }}>{menu.note}</p>}
      <div className="stack" style={{ gap: 8, marginTop: 12 }}>
        {(menu?.days || []).map(x0 => { const x = x0 as MenuDay, low = below(x), f = floorOf(x); return (
          <Card key={x.date} tight style={low ? { borderColor: 'var(--warn)' } : undefined}>
            <div className="between" style={{ alignItems: 'flex-start' }}><b style={{ fontSize: rem(13.5), minWidth: 0 }}>{fmtDateLong(x.date)}{x.date === today ? ' · danes' : ''}</b><span className="muted" style={{ fontSize: rem(12), fontWeight: 700, flex: 'none' }}>{fmtKcal(x.kcal)}{NBSP}kcal · B {x.proteinG}{NBSP}g</span></div>
            {low ? (
              <div style={{ marginTop: 6 }}>
                <span className="chip sm" style={{ color: 'var(--warn)' }}><IcoWarn width={12} height={12} aria-hidden="true" /> pod varno mejo</span>
                <div className="muted" style={{ fontSize: rem(11.5), lineHeight: 1.45, marginTop: 5 }}>Premalo za ta dan{f ? ` (meja ${fmtKcal(f)}${NBSP}kcal)` : ''}{NBSP}— ni priporočilo; dodaj obrok ali sestavi znova.</div>
              </div>
            ) : topped(x) ? <div className="muted" style={{ fontSize: rem(11.5), marginTop: 4 }}>Dopolnjeno do varne meje: pri malici ~{fmtKcal(x.addKcal!)}{NBSP}kcal več, kot je predlagal AI.</div> : null}
            <div style={low ? { opacity: 0.55 } : undefined}>
              {menuLines(x).map(([l, t]) => <div key={l} style={{ fontSize: rem(12.5), marginTop: 4 }}><span className="muted">{l}</span> <span style={{ color: 'var(--ink)' }}>{t}</span></div>)}
            </div>
          </Card>) })}
      </div>
      {menu && menu.shopping.length > 0 && (<>
        <h2 className="h4" style={{ marginTop: 16 }}>Nakupovalni seznam</h2>
        <div className="stack" style={{ gap: 6, marginTop: 8 }}>
          {menu.shopping.map((s, i) => (
            <button key={i} type="button" className="row" onClick={() => setMenu({ ...menu, bought: { ...menu.bought, [i]: !menu.bought[i] } })} aria-pressed={!!menu.bought[i]} style={{ gap: 10, textAlign: 'left', background: 'none', border: 0, padding: '6px 0', color: 'var(--ink)', cursor: 'pointer' }}>
              <span className={`check ${menu.bought[i] ? '' : 'off'}`} style={{ width: 22, height: 22, flex: 'none' }}>{menu.bought[i] ? <IcoCheck width={13} height={13} /> : null}</span>
              <span style={{ fontSize: rem(13.5), textDecoration: menu.bought[i] ? 'line-through' : 'none', color: menu.bought[i] ? 'var(--ink-3)' : 'var(--ink)' }}>{s}</span>
            </button>
          ))}
        </div>
      </>)}
      {copyFail?.where === 'menu' && <textarea className="copy-fallback" readOnly rows={5} value={copyFail.text} aria-label="Seznam za ročno kopiranje" onFocus={e => e.currentTarget.select()} />}
      <div className="row" style={{ gap: 8, marginTop: 14 }}>
        <Btn ghost sm disabled={ai.busy} onClick={makeMenu}>{busyIs('menu') ? 'Sestavljam …' : 'Sestavi znova'}</Btn>
        <Btn ghost sm onClick={() => void copyList((menu?.shopping || []).join('\n'), 'menu')}>Kopiraj seznam</Btn>
      </div>
      <HealthNote kind="food" />
      <Btn ghost block style={{ marginTop: 10 }} onClick={() => { setMenuOpen(false); setCopyFail(null) }}>Zapri</Btn>
    </Sheet>
    <Sheet open={prefsOpen} onClose={() => setPrefsOpen(false)} label="Prehranske želje">
      <b style={{ fontSize: rem(17), letterSpacing: '-.02em' }}>Prehranske želje</b>
      <p style={{ fontSize: rem(13), marginTop: 4 }}>Recepti (po pravilih in z AI) jih upoštevajo: npr. »vegetarijansko«, »brez laktoze«, »ne maram rib«, »brez jajc«. »Brez laktoze« pomeni mlečne izdelke brez laktoze, »brez mleka« jedi brez mlečnih izdelkov, »ne maram skute« pa izloči samo skuto.</p>
      <div className="field" style={{ marginTop: 12 }}><label htmlFor="food-prefs">Kaj ne ješ ali ne maraš</label>
        <textarea id="food-prefs" rows={2} value={prefsText} maxLength={200} onChange={e => setPrefsText(e.target.value)} placeholder="npr. brez laktoze, ne maram rib" style={{ background: 'var(--card)', border: '1px solid var(--line)', borderRadius: 'var(--r-m)', padding: '12px 14px', color: 'var(--ink)', fontSize: rem(15), lineHeight: 1.45, resize: 'none', outline: 'none', width: '100%' }} />
      </div>
      {/* (v3.51) kaj recepti ne upoštevajo (sladkorna bolezen, keto) in del, ki velja samo na nekatere dni */}
      {prefsNote(prefsText) && <p className="muted" style={{ fontSize: rem(12.5), marginTop: 8, color: 'var(--warn)' }}>{prefsNote(prefsText)}</p>}
      {hasTimedPrefs(prefsText) && <p className="muted" style={{ fontSize: rem(12.5), marginTop: 8 }}>Del z dnem (npr. »ob petkih ne jem mesa«) velja samo na ta dan.</p>}
      <Btn primary block style={{ marginTop: 14 }} onClick={() => { void setFoodPrefs(prefsText); setPrefsOpen(false); toast('Shranjeno — recepti se ravnajo po tem.', 'ok') }}>Shrani</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={() => setPrefsOpen(false)}>Prekliči</Btn>
    </Sheet>
    {mainRide && rfDay && <FuelLogSheet open={fuelOpen} onClose={() => setFuelOpen(false)} day={mainRide} rf={rfDay} existing={fuelLog} kit={p.fuelKit} />}
    {mainRun && rfRun && <FuelLogSheet open={runOpen} onClose={() => setRunOpen(false)} day={mainRun} rf={rfRun} existing={runLog} run />}
    <Sheet open={shopOpen} onClose={() => { setShopOpen(false); setCopyFail(null) }} label="Nakupovalni seznam">
      <b style={{ fontSize: rem(17), letterSpacing: '-.02em' }}>Nakupovalni seznam</b>
      <p style={{ fontSize: rem(12.5), marginTop: 6 }}>Iz receptov po načrtu za {shopDays} dni od danes (danes samo, kar še ni pojedeno) — brez AI in prijave. Kar že imaš doma, odkljukaj; kljukice ostanejo 7 dni.</p>
      {menuThisWeek && <p className="muted" style={{ fontSize: rem(12), marginTop: 6 }}>Če ješ po AI jedilniku tega tedna, je njegov seznam v »Jedilnik za teden«. <button type="button" className="chip sm click" onClick={() => { setShopOpen(false); setMenuOpen(true) }}>seznam iz AI jedilnika ›</button></p>}
      <div className="row shop-days" style={{ gap: 7, marginTop: 10 }}>{[3, 7].map(n => <Chip key={n} sm on={shopDays === n} onClick={() => setShopDays(n)}>{n} dni</Chip>)}</div>
      <div className="stack shop-list" style={{ gap: 6, marginTop: 10 }}>
        {shopG.length ? shopG.map(g => (<Fragment key={g.title}>
          <div className="h4 shop-group" style={{ fontSize: rem(10.5), margin: '8px 0 0' }}>{g.title}</div>
          {g.items.map(x => (
            <button key={x} type="button" className="row" onClick={() => setShopGot(s => ({ ...s, [shopK(x)]: !s[shopK(x)] }))} aria-pressed={!!shopGot[shopK(x)]} style={{ gap: 10, textAlign: 'left', background: 'none', border: 0, padding: '6px 0', color: 'var(--ink)', cursor: 'pointer' }}>
              <span className={`check ${shopGot[shopK(x)] ? '' : 'off'}`} style={{ width: 22, height: 22, flex: 'none' }}>{shopGot[shopK(x)] ? <IcoCheck width={13} height={13} /> : null}</span>
              <span style={{ fontSize: rem(13.5), textDecoration: shopGot[shopK(x)] ? 'line-through' : 'none', color: shopGot[shopK(x)] ? 'var(--ink-3)' : 'var(--ink)' }}>{x}</span>
            </button>
          ))}
        </Fragment>)) : <p className="muted" style={{ fontSize: rem(12.5) }}>Za te dni ni receptov po načrtu.</p>}
      </div>
      <div className="row" style={{ gap: 8, marginTop: 14 }}>
        <Btn ghost sm disabled={!shop.length} onClick={() => void shareList(shop.filter(x => !shopGot[shopK(x)]).join('\n'), 'shop')}>Deli seznam</Btn>
        <Btn ghost sm disabled={!shop.length} onClick={() => void copyList(shop.filter(x => !shopGot[shopK(x)]).join('\n'), 'shop')}>Kopiraj seznam</Btn>
      </div>
      {copyFail?.where === 'shop' && <textarea className="copy-fallback" readOnly rows={5} value={copyFail.text} aria-label="Seznam za ročno kopiranje" onFocus={e => e.currentTarget.select()} />}
      <Btn ghost block style={{ marginTop: 10 }} onClick={() => { setShopOpen(false); setCopyFail(null) }}>Zapri</Btn>
    </Sheet>
    {ai.sheet}
  </>)
}

/**
 * Vrstica pod obročem: danes »Še 303 kcal · 20 g beljakovin«; pretekli dan »303 kcal pod ciljem« (ne »še«, dan je mimo);
 * presežene beljakovine »beljakovine dosežene« (ne »0 g«); pretekli dan brez vpisov ne kaže primanjkljaja.
 */
export function DayBalance({ remaining, proteinLeft, past, logged, future = false, proteinG = 0 }: { remaining: number | null; proteinLeft: number; past: boolean; logged: boolean; /** dan šele pride: cilj, ne »še« */ future?: boolean; proteinG?: number }) {
  const B = ({ children }: { children: React.ReactNode }) => <b style={{ color: 'var(--ink)' }}>{children}</b>
  const prot = proteinLeft > 0 ? `${proteinLeft}${NBSP}g beljakovin${past ? ' manj' : ''}` : 'beljakovine dosežene'
  if (remaining == null) return null
  if (future) return <>Cilj tega dne: <B>{fmtKcal(remaining)}{NBSP}kcal</B> · {proteinG}{NBSP}g beljakovin</>
  if (past && !logged) return <>Za ta dan ni vpisanih obrokov</>
  // (v3.50) nad ciljem tudi manjkajoče beljakovine (prej skrite); točno na cilju »Na cilju«, ne »Še 0 kcal«
  const protOver = proteinLeft > 0 ? (past ? `${proteinLeft}${NBSP}g beljakovin manj` : `še ${proteinLeft}${NBSP}g beljakovin`) : 'beljakovine dosežene'
  if (remaining < 0) return <>Nad ciljem za <B>{fmtKcal(-remaining)}{NBSP}kcal</B> · {protOver}</>
  if (remaining === 0) return <><B>Na cilju</B> · {protOver}</>
  if (past) return <><B>{fmtKcal(remaining)}{NBSP}kcal</B> pod ciljem · {prot}</>
  return <>Še <B>{fmtKcal(remaining)}{NBSP}kcal</B> · {prot}</>
}
