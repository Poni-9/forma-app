import { lazy, Suspense, useEffect, useMemo, useRef, useState } from 'react'
import { navigate } from '@/app/router'
import { markApp } from '@/app/landing'
import { useApp, getState, applyAgreement } from '@/state/store'
import { useAi } from '@/ui/useAi'
import { askJson } from '@/domain/ai/client'
import { questionsPrompt, parseQuestions, proposalPrompt, parseProposal, type QA, type QuestionsOut, type ProposalOut, type Basics } from '@/domain/ai/focusAi'
import { ruleQuestions, ruleProposal, ruleAdjust } from '@/domain/focus/rules'
import { SPORT_LABEL, PART_NAME, CARDIO_LABEL, weekLine, aimsLine } from '@/domain/focus/model'
import type { AgreedSession, Focus } from '@/domain/types'
import { useDictation } from '@/ui/useDictation'
import { Btn, Chip, DecimalInput, Progress } from '@/ui/primitives'
import { IcoBack, IcoMic, IcoDumbbell, IcoRun, IcoBike, IcoMap, IcoHome, IcoSpark } from '@/ui/icons'
import { startFeedback } from '@/ui/HelpSheet'
import { toast } from '@/state/store'

const BuildShow = lazy(() => import('@/ui/BuildShow').then(m => ({ default: m.BuildShow })))

/**
 * SESTAVIVA TVOJ NAČRT (Blaž, 7. 10.): uporabnik pove, kaj želi (besedilo ali glas), AI vpraša naprej — vsakič nova
 * vprašanja iz tega, kar je rekel — nato predlaga realen teden in se z njim pogaja (več, manj, drugače). Ko sta
 * dogovorjena, se aplikacija pred njim sestavi (BuildShow). Brez AI (napaka, limit) gre naprej po pravilih.
 */
type Step = 'zelja' | 'vprasanja' | 'dogovor' | 'gradnja'
const EXAMPLES = ['Fitnes in malo teka', 'Vitka, a močna postava', 'Six pack', 'Ful kondicije', 'Hujšati, a ohraniti mišice', 'Samo zgornji del', 'Hitrejši na kolesu', 'Doma, brez opreme']
const num = (v: string, lo: number, hi: number) => { const x = +v.replace(',', '.'); return v.trim() !== '' && Number.isFinite(x) && x >= lo && x <= hi ? x : null }

export function sessionColor(s: Pick<AgreedSession, 'type'>): string {
  return s.type === 'fitnes' || s.type === 'doma' ? 'var(--t-moc)' : s.type === 'kolo' ? 'var(--t-kolo)' : 'var(--t-tek)'
}
export function SessionIcon({ s, size = 17 }: { s: Pick<AgreedSession, 'type'>; size?: number }) {
  const p = { width: size, height: size, 'aria-hidden': true }
  return s.type === 'fitnes' ? <IcoDumbbell {...p} /> : s.type === 'doma' ? <IcoHome {...p} /> : s.type === 'kolo' ? <IcoBike {...p} /> : s.type === 'hribi' ? <IcoMap {...p} /> : <IcoRun {...p} />
}
const what = (s: AgreedSession) => (s.part ? PART_NAME[s.part] : s.cardio ? CARDIO_LABEL[s.cardio] : '')

export function Sestavi() {
  const app = useApp()
  const p0 = app.profile
  const ai = useAi()
  const again = p0.onboardingDone
  const [step, setStep] = useState<Step>('zelja')
  const [wish, setWish] = useState(p0.focus?.wish || '')
  const [b, setB] = useState(() => ({ sex: p0.sex, age: p0.age ? String(p0.age) : '', height: p0.heightCm ? String(p0.heightCm) : '', weight: p0.weightKg ? String(p0.weightKg) : '' }))
  const basics: Basics = { sex: b.sex, age: num(b.age, 12, 99), heightCm: num(b.height, 120, 230), weightKg: num(b.weight, 30, 250) }
  const [round, setRound] = useState<1 | 2>(1)
  const [qs, setQs] = useState<QuestionsOut | null>(null)
  const [ans, setAns] = useState<Record<string, { picks: string[]; text: string }>>({})
  const [qa, setQa] = useState<QA[]>([])
  const [prop, setProp] = useState<ProposalOut | null>(null)
  const [talk, setTalk] = useState<{ who: 'ti' | 'trener'; text: string }[]>([])
  const [say, setSay] = useState('')
  const [busy, setBusy] = useState<string | null>(null)
  const [noAi, setNoAi] = useState(false)
  const [declined, setDeclined] = useState(false)
  const [byRules, setByRules] = useState(false)
  const top = useRef<HTMLDivElement>(null)
  const wishDict = useDictation(wish, setWish, m => toast(m, 'err', 6000))
  const sayDict = useDictation(say, setSay, m => toast(m, 'err', 6000))
  useEffect(() => { window.scrollTo(0, 0) }, [step, round])

  /** AI klic z vrati (prijava, privolitev). null = AI ni odgovoril (napaka, limit) → naprej po pravilih. */
  async function viaAi<T>(fn: () => Promise<T>): Promise<T | null> {
    if (noAi) return null
    const r = await ai.run(fn, { quiet: true })
    if (r !== undefined) return r
    setNoAi(true)
    return null
  }

  /** rules = kratek vprašalnik brez prijave in brez AI (vprašanja, predlog in sestava po pravilih). */
  async function startQuestions(rules = false) {
    setDeclined(false)
    setBusy('Berem, kar si napisal …')
    let parsed: QuestionsOut | null = null
    let fallback = noAi || rules
    if (rules) setByRules(true)
    if (!fallback) {
      const r = await ai.run(() => askJson<unknown>(questionsPrompt({ wish, basics, qa: [], round: 1 })), { quiet: true })
      if (r === undefined) {
        const st = getState()
        // ni prijave ali privolitve: ostani tu in povej, kaj sta možnosti
        if (import.meta.env.VITE_E2E !== '1' && (!st.user || !st.profile.aiConsentAt)) { setBusy(null); setDeclined(true); return }
        fallback = true
      } else parsed = parseQuestions(r)
      if (!parsed || !parsed.questions.length) fallback = true
    }
    setBusy(null)
    if (fallback) setNoAi(true)
    setQs(!fallback && parsed ? parsed : ruleQuestions(wish)); setAns({}); setRound(1); setQa([]); setStep('vprasanja')
  }

  const answered = !!qs && qs.questions.every(q => (ans[q.id]?.picks.length || 0) > 0 || (ans[q.id]?.text.trim().length || 0) > 0)
  async function submitAnswers() {
    if (!qs) return
    const add: QA[] = qs.questions.map(q => ({ id: q.id, q: q.text, a: [...(ans[q.id]?.picks || []), ans[q.id]?.text.trim() || ''].filter(Boolean).join(', ') }))
    const all = [...qa, ...add]
    setQa(all)
    if (round === 1 && !qs.enough && !noAi) {
      setBusy('Še nekaj bi rad vedel …')
      const r = await viaAi(() => askJson<unknown>(questionsPrompt({ wish, basics, qa: all, round: 2 })))
      const q2 = r ? parseQuestions(r) : null
      setBusy(null)
      if (q2 && q2.questions.length) { setQs(q2); setAns({}); setRound(2); return }
    }
    await propose(all, null)
  }

  async function propose(all: QA[], feedback: string | null) {
    setBusy(feedback ? 'Popravljam predlog …' : 'Sestavljam predlog tedna …')
    if (feedback) setTalk(t => [...t, { who: 'ti', text: feedback }])
    const r = await viaAi(() => askJson<unknown>(proposalPrompt({ wish, basics, qa: all, prev: prop?.focus ?? null, feedback })))
    let next = r ? parseProposal(r, { wish, age: basics.age }) : null
    if (!next) {
      if (feedback && prop) {
        const adj = ruleAdjust(prop.focus, feedback, basics.age)
        next = adj ? { reply: `Popravil sem: ${weekLine(adj)}.`, focus: adj, quick: prop.quick } : { ...prop, reply: 'Brez AI razumem samo hitre odgovore spodaj (več kardia, manj dni …).' }
      } else next = ruleProposal(wish, all, basics.age)
    }
    setBusy(null)
    setProp(next)
    setTalk(t => [...t, { who: 'trener', text: next!.reply }])
    setSay('')
    setStep('dogovor')
  }

  async function save(final: Focus) {
    await applyAgreement(final, { sex: basics.sex ?? null, age: basics.age, heightCm: basics.heightCm, weightKg: basics.weightKg })
  }
  function done() {
    markApp()
    navigate('danes')
  }

  const back = () => {
    if (busy) return
    if (step === 'dogovor') setStep(qs ? 'vprasanja' : 'zelja')
    else if (step === 'vprasanja') setStep('zelja')
    else if (again) navigate('nastavitve')
    else navigate('')
  }
  const stepIx = step === 'zelja' ? 1 : step === 'vprasanja' ? 2 : 3
  const sexOk = !!b.sex
  const wishOk = wish.trim().length >= 8

  if (step === 'gradnja' && prop) {
    return (
      <Suspense fallback={<div className="ob" />}>
        <BuildShow focus={prop.focus} basics={basics} ai={!noAi} onSave={save} onDone={done} />
      </Suspense>
    )
  }

  return (
    <main className="ob sest" ref={top}>
      <div className="between" style={{ marginBottom: 14, minHeight: 34 }}>
        <button className="avatar" style={{ background: 'transparent', width: 40, height: 40 }} onClick={back} aria-label="Nazaj"><IcoBack /></button>
        {!again && !app.user && step === 'zelja'
          ? <button className="chip sm click" onClick={() => navigate('prijava')}>Že imam račun</button>
          : <div className="muted" style={{ fontSize: 12, fontWeight: 700 }}>{stepIx} / 3</div>}
      </div>
      <Progress pct={(stepIx / 3) * 100} />

      {step === 'zelja' && (<>
        <h2>{again ? 'Kaj bi spremenil?' : 'Kaj si želiš?'}</h2>
        <p style={{ marginTop: 7, fontSize: 14 }}>Povej s svojimi besedami: kaj želiš s svojim telesom, kaj rad počneš, koliko časa imaš, kaj te moti. Bolj ko poveš, bolj bo načrt tvoj.</p>
        <div className={`meal-text${wishDict.listening ? ' live' : ''}`} style={{ marginTop: 14 }}>
          <label htmlFor="sest-wish" className="sr-only">Kaj si želiš</label>
          <textarea id="sest-wish" rows={5} value={wish} maxLength={900} onChange={e => setWish(e.target.value)} style={{ minHeight: 132, maxHeight: 240, overflowY: 'auto' }}
            placeholder={wishDict.listening ? 'Poslušam …' : 'npr. Hodim v fitnes, rad bi malo teka in ful kondicije. Želim vitko, a močno postavo in six pack — med hujšanjem pa ne izgubiti mišic.'} />
          {wishDict.canSpeak && <button type="button" className={`mic${wishDict.listening ? ' on' : ''}`} style={{ top: 30 }} onClick={wishDict.toggle} aria-pressed={wishDict.listening} aria-label={wishDict.listening ? 'Ustavi narekovanje' : 'Povej, kaj si želiš'}><IcoMic width={18} height={18} /></button>}
        </div>
        <div className="row" style={{ gap: 6, flexWrap: 'wrap', marginTop: 10 }} aria-label="Primeri">
          {EXAMPLES.map(x => <button key={x} type="button" className="chip sm click" onClick={() => setWish(w => (w.trim() ? `${w.trim().replace(/[.,;]?$/, ',')} ${x.toLowerCase()}` : x))}>+ {x}</button>)}
        </div>
        <div className="card tight" style={{ marginTop: 16 }}>
          <b style={{ fontSize: 13.5 }}>O tebi</b>
          <p className="muted" style={{ fontSize: 12, marginTop: 2 }}>Za realen načrt in kalorije. Ostane v aplikaciji; AI dobi samo številke, brez imena.</p>
          <div className="row" style={{ gap: 7, marginTop: 10 }}>{([['m', 'Moški'], ['z', 'Ženska']] as const).map(([v, l]) => <Chip key={v} sm on={b.sex === v} onClick={() => setB({ ...b, sex: v })}>{l}</Chip>)}</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, marginTop: 10 }}>
            <div className="field"><label htmlFor="s-age">Starost</label><input id="s-age" type="number" inputMode="numeric" value={b.age} onChange={e => setB({ ...b, age: e.target.value })} /></div>
            <div className="field"><label htmlFor="s-h">Višina <span className="unit">cm</span></label><input id="s-h" type="number" inputMode="numeric" value={b.height} onChange={e => setB({ ...b, height: e.target.value })} /></div>
            <div className="field"><label htmlFor="s-w">Teža <span className="unit">kg</span></label><DecimalInput id="s-w" min={30} max={250} step={0.1} value={b.weight} onChange={e => setB({ ...b, weight: e.target.value })} /></div>
          </div>
          {basics.age != null && basics.age < 18 && <p style={{ fontSize: 12, marginTop: 8 }}>Do 18. leta ne načrtujem hujšanja — kalorije so vedno za vzdrževanje.</p>}
        </div>
        {declined && (
          <div className="card tight" role="status" style={{ marginTop: 12 }}>
            <p style={{ fontSize: 13 }}>Pogovor s trenerjem teče prek AI — za to se prijaviš z Googlom in dovoliš obdelavo. Raje brez tega? Spodaj izberi vprašalnik brez AI: vprašanja so stalna, načrt je še vedno po tvojih odgovorih.</p>
          </div>
        )}
        {busy && <div style={{ marginTop: 12 }}><Thinking label={busy} /></div>}
        <div className="grow" style={{ minHeight: 18 }} />
        <Btn primary block disabled={!wishOk || !!busy} onClick={() => void startQuestions()}><IcoSpark width={17} height={17} /> {busy ? 'Trener razmišlja …' : 'Naprej'}</Btn>
        {!sexOk && wishOk && <p className="muted" style={{ fontSize: 11.5, marginTop: 6, textAlign: 'center' }}>Brez spola in teže kalorij ne pokažem — izpolniš lahko tudi pozneje.</p>}
        {!app.user && <button type="button" className="ob-fb" style={{ marginTop: 8 }} disabled={!wishOk || !!busy} onClick={() => void startQuestions(true)}>Raje brez prijave (vprašalnik brez AI)</button>}
      </>)}

      {step === 'vprasanja' && qs && (<>
        <h2>{round === 1 ? 'Še nekaj vprašanj' : 'Samo še to'}</h2>
        {qs.understood && <div className="talk" style={{ marginTop: 12 }}><span className="talk-who">Trener</span>{qs.understood}</div>}
        {noAi && <p className="muted" style={{ fontSize: 12, marginTop: 8 }}>{byRules ? 'Vprašalnik brez AI — načrt bo po tvojih odgovorih.' : 'AI se trenutno ne odziva — vprašanja so iz vprašalnika, načrt bo vseeno po tvojih odgovorih.'}</p>}
        <div className="stack" style={{ marginTop: 14, gap: 10 }}>
          {qs.questions.map(q => {
            const a = ans[q.id] || { picks: [], text: '' }
            const toggle = (o: string) => setAns({ ...ans, [q.id]: { ...a, picks: q.multi ? (a.picks.includes(o) ? a.picks.filter(x => x !== o) : [...a.picks, o]) : a.picks[0] === o ? [] : [o] } })
            return (
              <div key={q.id} className="card tight q-card" role="group" aria-label={q.text}>
                <b style={{ fontSize: 14.5, lineHeight: 1.35 }}>{q.text}</b>
                {q.multi && <span className="muted" style={{ fontSize: 11.5, display: 'block', marginTop: 2 }}>lahko izbereš več</span>}
                <div className="row" style={{ gap: 6, flexWrap: 'wrap', marginTop: 10 }}>{q.options.map(o => <Chip key={o} sm on={a.picks.includes(o)} onClick={() => toggle(o)}>{o}</Chip>)}</div>
                {q.other && <input className="q-other" value={a.text} maxLength={160} onChange={e => setAns({ ...ans, [q.id]: { ...a, text: e.target.value } })} placeholder="ali napiši po svoje" aria-label={`${q.text} — svoj odgovor`} />}
              </div>
            )
          })}
        </div>
        {busy && <div style={{ marginTop: 12 }}><Thinking label={busy} /></div>}
        <div className="grow" style={{ minHeight: 18 }} />
        <Btn primary block disabled={!answered || !!busy} onClick={() => void submitAnswers()}>{busy ? 'Trener razmišlja …' : 'Naprej'}</Btn>
      </>)}

      {step === 'dogovor' && prop && (<>
        <h2>Najin dogovor</h2>
        <div className="stack" style={{ marginTop: 12, gap: 8 }}>
          {talk.slice(-5).map((t, i) => <div key={i} className={`talk${t.who === 'ti' ? ' me' : ''}`}>{t.who === 'trener' && <span className="talk-who">Trener</span>}{t.text}</div>)}
          {busy && <Thinking label={busy} />}
        </div>
        <Deal f={prop.focus} />
        {again && <p className="muted" style={{ fontSize: 12, marginTop: 8 }}>Nov dogovor zamenja tvoj sedanji načrt od danes naprej. Opravljeni treningi ostanejo.</p>}
        <p className="muted" style={{ fontSize: 12.5, marginTop: 14 }}>Ti odločaš. Kaj bi spremenil?</p>
        <div className="row" style={{ gap: 6, flexWrap: 'wrap', marginTop: 8 }}>
          {(prop.quick.length ? prop.quick : ['Več kardia', 'Več moči', 'Manj dni', 'Krajše vadbe']).map(x => <button key={x} type="button" className="chip sm click" disabled={!!busy} onClick={() => void propose(qa, x)}>{x}</button>)}
        </div>
        <div className={`meal-text${sayDict.listening ? ' live' : ''}`}>
          <label htmlFor="sest-say" className="sr-only">Kaj bi spremenil</label>
          <textarea id="sest-say" rows={2} value={say} maxLength={400} onChange={e => setSay(e.target.value)} placeholder={sayDict.listening ? 'Poslušam …' : 'npr. raje 4 dni, več teka, brez nog'} style={{ paddingRight: 96 }} />
          {sayDict.canSpeak && <button type="button" className={`mic${sayDict.listening ? ' on' : ''}`} style={{ right: 52 }} onClick={sayDict.toggle} aria-pressed={sayDict.listening} aria-label={sayDict.listening ? 'Ustavi narekovanje' : 'Povej, kaj bi spremenil'}><IcoMic width={18} height={18} /></button>}
          <button type="button" className="mic send" disabled={!say.trim() || !!busy} onClick={() => { sayDict.stop(); void propose(qa, say.trim()) }} aria-label="Pošlji trenerju">→</button>
        </div>
        <div className="grow" style={{ minHeight: 18 }} />
        <Btn primary block disabled={!!busy} style={{ marginTop: 16 }} onClick={() => setStep('gradnja')}>Dogovorjeno — sestavi moj načrt</Btn>
      </>)}

      <button type="button" className="ob-fb" onClick={() => void startFeedback()}>Nekaj ni jasno? Pošlji pripombo</button>
      {ai.sheet}
    </main>
  )
}

function Thinking({ label }: { label: string }) {
  return <div className="talk think" role="status" aria-live="polite"><span className="talk-who">Trener</span>{label}<span className="thinking" aria-hidden="true"><i /><i /><i /></span></div>
}

/** Predlog tedna: ime, teden, cilji, seje, pojasnila. */
export function Deal({ f }: { f: Focus }) {
  const notes = useMemo(() => f.notes.slice(0, 4), [f.notes])
  return (
    <div className="card deal" style={{ marginTop: 14 }}>
      <div className="h4">Predlog</div>
      <h3 style={{ fontSize: 20, marginTop: 4, letterSpacing: '-.02em' }}>{f.title}</h3>
      <p style={{ fontSize: 13, marginTop: 4 }}>{weekLine(f)}{f.aims.length || f.muscles.length ? ` · ${aimsLine(f)}` : ''}</p>
      <div className="deal-list">
        {f.sessions.map((s, i) => (
          <div key={i} className="deal-row" style={{ ['--c' as string]: sessionColor(s) }}>
            <span className="deal-ic"><SessionIcon s={s} /></span>
            <span style={{ flex: 1, minWidth: 0 }}><b>{SPORT_LABEL[s.type]}</b>{what(s) ? <span className="muted"> · {what(s)}</span> : null}</span>
            <span className="muted" style={{ fontWeight: 700, fontSize: 12.5 }}>{s.min} min</span>
          </div>
        ))}
      </div>
      {notes.length > 0 && <ul className="deal-notes">{notes.map((n, i) => <li key={i}>{n}</li>)}</ul>}
    </div>
  )
}
