import { Fragment, lazy, Suspense, useEffect, useMemo, useRef, useState } from 'react'
import { navigate } from '@/app/router'
import { markApp } from '@/app/landing'
import { useApp, getState, applyAgreement } from '@/state/store'
import { useAi } from '@/ui/useAi'
import { askJson } from '@/domain/ai/client'
import { questionsPrompt, parseQuestions, proposalPrompt, parseProposal, type QA, type QuestionsOut, type ProposalOut, type Basics, type AiQuestion } from '@/domain/ai/focusAi'
import { ruleQuestions, ruleProposal, ruleAdjust, applyDayWords, daysReply, daysIn, mentionsDays, keepDayStructure } from '@/domain/focus/rules'
import { coachReview, planInputs, weekDiff } from '@/domain/focus/coach'
import { CHOICE_GROUPS, visibleGroups, picksStrength, picksCardio, composeWish, splitWish, DAY_AT, DAY_OPTS, DAY_NAME, type Picks } from '@/domain/focus/choices'
import { useAutoGrow } from '@/ui/useAutoGrow'
import { ListenBar } from '@/ui/ListenBar'
import { weekLine, mixLine, aimsLine, normalizeFocus, trainingDays, usesAgreement } from '@/domain/focus/model'
import type { Focus } from '@/domain/types'
import { useDictation } from '@/ui/useDictation'
import { Btn, Chip, DecimalInput, Progress } from '@/ui/primitives'
import { IcoBack, IcoMic, IcoSpark } from '@/ui/icons'
import { WeekStrip, SessionList, sessName } from '@/ui/WeekStrip'
import { startFeedback } from '@/ui/HelpSheet'
import { toast } from '@/state/store'
export { sessionColor, SessionIcon } from '@/ui/WeekStrip'

const BuildShow = lazy(() => import('@/ui/BuildShow').then(m => ({ default: m.BuildShow })))

/**
 * SESTAVIVA TVOJ NAČRT (Blaž, 7. 10.): uporabnik izbere in/ali pove s svojimi besedami, kaj želi (besedilo ali glas),
 * AI vpraša naprej — vsakič nova vprašanja iz tega, kar je rekel, eno za drugim z izbirami kot v pogovoru — nato
 * predlaga realen teden in se z njim pogaja (več, manj, drugače, dnevi brez časa). Ko sta dogovorjena, se aplikacija
 * pred njim sestavi (BuildShow). Brez AI (napaka, limit) gre naprej po pravilih.
 */
type Step = 'zelja' | 'vprasanja' | 'dogovor' | 'gradnja'
type Ans = Record<string, { picks: string[]; text: string }>
const answerOf = (a: Ans, q: AiQuestion) => [...(a[q.id]?.picks || []), a[q.id]?.text.trim() || ''].filter(Boolean).join(', ')
const num = (v: string, lo: number, hi: number) => { const x = +v.replace(',', '.'); return v.trim() !== '' && Number.isFinite(x) && x >= lo && x <= hi ? x : null }

export function Sestavi() {
  const app = useApp()
  const p0 = app.profile
  const ai = useAi()
  const again = p0.onboardingDone
  const [step, setStep] = useState<Step>('zelja')
  // izbire (kot pri Claudu) in svoje besede → ena želja za AI in vprašalnik
  const init = useMemo(() => splitWish(p0.focus?.wish || ''), []) // eslint-disable-line react-hooks/exhaustive-deps
  const [picks, setPicks] = useState<Picks>(init.picks)
  const [text, setText] = useState(init.text)
  const wish = composeWish(picks, text)
  const [b, setB] = useState(() => ({ sex: p0.sex, age: p0.age ? String(p0.age) : '', height: p0.heightCm ? String(p0.heightCm) : '', weight: p0.weightKg ? String(p0.weightKg) : '' }))
  // kdaj ima čas (Blaž, 11. 10.: »to mora nujno zvedeti«): dnevi s časom so okvir načrta; ostali dnevi so brez vadbe
  const [avail, setAvail] = useState<number[]>(() => (p0.focus ? [0, 1, 2, 3, 4, 5, 6].filter(d => !(p0.focus!.offDays || []).includes(d)) : []))
  const [trainTime, setTrainTime] = useState<'zjutraj' | 'popoldne' | 'zvecer' | null>(p0.trainTime ?? null)
  // kakšen tip si: raje manj naložen, zmerno ali trdo (Blaž, 11. 10.) — načrt in trener se prilagodita
  const [push, setPush] = useState<'lahko' | 'zmerno' | 'trdo'>(p0.push ?? 'zmerno')
  // kaj mu je glavno (Blaž, 11. 10.: »hoče bolj kolo, fitnesa ima preveč«) — razmerje sej
  const [main, setMain] = useState<'kardio' | 'oboje' | 'moc'>(p0.focus?.main ?? 'oboje')
  // glavno iz izbir: samo kardio ali samo moč se ve samo; vprašamo le, ko je izbral oboje
  const both = picksStrength(picks) && picksCardio(picks)
  const mainEff: 'kardio' | 'oboje' | 'moc' = both ? main : picksCardio(picks) ? 'kardio' : picksStrength(picks) ? 'moc' : main
  const basics: Basics = { sex: b.sex, age: num(b.age, 12, 99), heightCm: num(b.height, 120, 230), weightKg: num(b.weight, 30, 250), avail, trainTime, push, main: mainEff }
  const noDays = [0, 1, 2, 3, 4, 5, 6].filter(d => !avail.includes(d))
  const [round, setRound] = useState<1 | 2>(1)
  const [qs, setQs] = useState<QuestionsOut | null>(null)
  const [ans, setAns] = useState<Ans>({})
  const [doneIds, setDoneIds] = useState<string[]>([])          // potrjeni odgovori v tem krogu (vprašanje za vprašanjem)
  const [hist, setHist] = useState<QA[]>([])              // prejšnji krogi
  const [qaAll, setQaAll] = useState<QA[]>([])            // vsi odgovori (za predlog in pogajanje)
  const [prop, setProp] = useState<ProposalOut | null>(null)
  const [base, setBase] = useState<Focus | null>(null)   // predlog pred spremembo dni (da se vadbe vrnejo, ko dan spet gre)
  const [dayNote, setDayNote] = useState<string | null>(null)
  const [talk, setTalk] = useState<{ who: 'ti' | 'trener'; text: string }[]>([])
  const [say, setSay] = useState('')
  const [busy, setBusy] = useState<string | null>(null)
  const [noAi, setNoAi] = useState(false)
  const [aiWhy, setAiWhy] = useState<string | null>(null)      // zakaj AI nazadnje ni odgovoril (pokaže se v pogovoru)
  const [retry, setRetry] = useState<string | null>(null)      // sprememba, ki jo AI ni obdelal — »Poskusi znova z AI«
  const [declined, setDeclined] = useState(false)
  const [byRules, setByRules] = useState(false)
  const top = useRef<HTMLDivElement>(null)
  const curRef = useRef<HTMLDivElement>(null)
  const wishRef = useRef<HTMLTextAreaElement>(null), sayRef = useRef<HTMLTextAreaElement>(null)
  const wishDict = useDictation(text, setText, m => toast(m, 'err', 6000))
  const sayDict = useDictation(say, setSay, m => toast(m, 'err', 6000))
  useAutoGrow(wishRef, text, 220)
  useAutoGrow(sayRef, say, 200)
  useEffect(() => { window.scrollTo(0, 0) }, [step, round])
  const curIx = qs ? qs.questions.findIndex(q => !doneIds.includes(q.id)) : -1
  // naslednje vprašanje pride na vrsto: pokaži ga in nanj premakni fokus (bralnik zaslona ga prebere)
  useEffect(() => {
    const el = curRef.current
    if (step !== 'vprasanja' || curIx < 0 || !el || (curIx === 0 && round === 1)) return
    const calm = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
    el.scrollIntoView({ block: 'nearest', behavior: calm ? 'auto' : 'smooth' })
    el.focus({ preventScroll: true })
  }, [step, curIx, round])

  /**
   * AI klic z vrati (prijava, privolitev). null = AI ni odgovoril (napaka, limit) → naprej po pravilih; razlog ostane
   * v aiWhy (pokaže se v pogovoru). retry: pri pogajanju AI poskusi znova vsakič — ena napaka ga ne ugasne za vso sejo.
   */
  async function viaAi<T>(fn: () => Promise<T>, retry = false): Promise<{ r: T | null; why: string | null }> {
    if (noAi && !retry) return { r: null, why: aiWhy }
    let why: string | null = null
    const r = await ai.run(fn, { quiet: true, onError: m => { why = m } })
    if (r !== undefined) { setNoAi(false); setAiWhy(null); return { r, why: null } }
    setNoAi(true)
    setAiWhy(why)
    return { r: null, why }
  }

  /** rules = kratek vprašalnik brez prijave in brez AI (vprašanja, predlog in sestava po pravilih). */
  async function startQuestions(rules = false) {
    setDeclined(false)
    setBusy('Berem tvoje želje …')
    let parsed: QuestionsOut | null = null
    let fallback = noAi || rules
    if (rules) setByRules(true)
    if (!fallback) {
      const r = await ai.run(() => askJson<unknown>(questionsPrompt({ wish, basics, qa: [], round: 1 })), { quiet: true, onError: m => setAiWhy(m) })
      if (r === undefined) {
        const st = getState()
        // ni prijave ali privolitve: ostani tu in povej, kaj sta možnosti
        if (import.meta.env.VITE_E2E !== '1' && (!st.user || !st.profile.aiConsentAt)) { setBusy(null); setDeclined(true); return }
        fallback = true
      } else { parsed = parseQuestions(r); setAiWhy(null) }
      if (!parsed || !parsed.questions.length) fallback = true
    }
    setBusy(null)
    if (fallback) setNoAi(true)
    setQs(!fallback && parsed ? parsed : ruleQuestions(wish, { avail })); setAns({}); setDoneIds([]); setRound(1); setHist([]); setQaAll([]); setStep('vprasanja')
  }

  /** Izbira pri vprašanju: ena možnost odgovori takoj, pri več možnostih potrdi »Naprej«. */
  function pick(q: AiQuestion, o: string) {
    if (busy) return
    const a = ans[q.id] || { picks: [], text: '' }
    const picksNow = q.multi ? (a.picks.includes(o) ? a.picks.filter(x => x !== o) : [...a.picks, o]) : [o]
    const next = { ...ans, [q.id]: { ...a, picks: picksNow } }
    setAns(next)
    if (!q.multi) commit(q, next)
  }
  function commit(q: AiQuestion, a: Ans = ans) {
    if (busy || !qs || !answerOf(a, q)) return
    const d = [...doneIds.filter(x => x !== q.id), q.id]
    setDoneIds(d)
    if (qs.questions.every(x => d.includes(x.id))) void submitAnswers(a)
  }
  /** tap na svoj odgovor: vprašanje spet odpre (ko odgovoriš, gre naprej od tam) */
  function reopen(id: string) { if (!busy) setDoneIds(d => d.filter(x => x !== id)) }

  async function submitAnswers(a: Ans = ans) {
    if (!qs) return
    const add: QA[] = qs.questions.map(q => ({ id: q.id, q: q.text, a: answerOf(a, q) }))
    const all = [...hist, ...add]
    setQaAll(all)
    if (round === 1 && !qs.enough && !noAi) {
      setBusy('Še nekaj bi rad vedel …')
      const { r } = await viaAi(() => askJson<unknown>(questionsPrompt({ wish, basics, qa: all, round: 2 })))
      const q2 = r ? parseQuestions(r) : null
      setBusy(null)
      if (q2 && q2.questions.length) { setHist(all); setQs(q2); setAns({}); setDoneIds([]); setRound(2); return }
    }
    await propose(all, null)
  }

  async function propose(all: QA[], feedback: string | null) {
    setBusy(feedback ? 'Popravljam predlog …' : 'Sestavljam predlog tedna …')
    if (feedback) setTalk(t => [...t, { who: 'ti', text: feedback }])
    setRetry(null)
    // vse dosedanje pripombe gredo zraven (Blaž, 11. 10.: »ne posluša, ko mu povem«) — prej je AI videl samo zadnjo
    // + kar je povedal ob prejšnjem dogovoru (želja in pripombe) — velja, dokler ne reče drugače
    const history = [...(again && p0.focus ? [p0.focus.wish, ...(p0.focus.said || [])] : []), ...(feedback ? talk.filter(t => t.who === 'ti').map(t => t.text) : [])].filter(x => x && x !== wish)
    // ODMEREK iz njegovih besed (Blaž, 13. 10.: »dober plan je najpomembnejša funkcija«): raven (izbira, zgibi …),
    // dnevi (»3-4«), čas na vadbo (»60 do 75 minut«), razmerje moč : kardio po cilju in izbirah — gre AI-ju v poziv in
    // trenerju (coachReview) v preverbo
    const { opts, dose } = planInputs({ picks, wish, qa: all, feedback, age: basics.age, push, main: mainEff, everyDay: !!prop?.focus.everyDay, avail })
    const current = again && p0.focus ? p0.focus : null
    const { r, why: aiErr } = await viaAi(() => askJson<unknown>(proposalPrompt({ wish, basics, qa: all, prev: prop?.focus ?? current, feedback, history, current, dose })), !!feedback)
    // določeni dnevi in dnevi brez časa iz prejšnjega predloga ostanejo, če jih AI v popravku izpusti (uporabnikove
    // nove besede o dnevih jih spodaj spremenijo)
    // dnevi brez časa iz 1. koraka veljajo vedno (tudi če jih AI izpusti); pri popravku še dnevi iz prejšnjega predloga
    // »vsak dan« ostane tudi v pogajanju, dokler ne reče drugih dni
    const wantDays = opts.wantDays ?? (opts.asIs && prop?.focus.everyDay ? 7 : null)
    let next = r ? parseProposal(r, { wish, age: basics.age, prevOff: feedback ? [...(prop?.focus.offDays || []), ...noDays] : noDays, keepDays: feedback ? prop?.focus.sessions : null, everyDay: wantDays === 7 }) : null
    const why = r && !next ? 'AI je odgovoril, a predlog ni bil uporaben' : aiErr
    if (next) {
      // uporabnik ni govoril o dnevih (»več kardia«): dnevi iz prejšnjega predloga ostanejo, tudi če jih je AI spremenil
      if (feedback && prop && !mentionsDays(feedback)) next = { ...next, focus: keepDayStructure(prop.focus, next.focus, basics.age) }
      // besede o dnevih (»fitnes torek in petek«, »ob torkih ne morem«) veljajo tudi, če jih AI ni upošteval
      const fixed = applyDayWords(next.focus, feedback ?? wish, basics.age)
      if (fixed && daysDiffer(next.focus, fixed)) next = { ...next, focus: fixed, reply: `${next.reply} ${daysReply(fixed)}`.trim() }
      else if (!next.reply) next = { ...next, reply: `Predlagam ${weekLine(next.focus)}. ${daysReply(next.focus)}` }
      // uporabnik je govoril o dnevih ali AI v odgovoru omenja dan, ki ga v dogovoru ni (»premaknil na ponedeljek«): povej prave dneve
      else if ((feedback && mentionsDays(feedback)) || replyDaysOff(next.reply, next.focus)) next = { ...next, reply: `${next.reply} ${daysReply(next.focus)}`.trim() }
    } else {
      const note = why ? `AI ni odgovoril: ${why.replace(/\.?$/, '.')} ` : ''
      if (feedback && prop) {
        const adj = ruleAdjust(prop.focus, feedback, basics.age)
        next = adj
          ? { reply: `${note}Medtem sem popravil po pravilih. ${daysReply(adj)}`, focus: adj, quick: prop.quick }
          : { ...prop, reply: `${note}Brez AI razumem dneve (»ob torkih ne morem«, »fitnes torek in petek«, »tek v istem dnevu«) in hitre odgovore spodaj — ali poskusi znova z AI.` }
        setRetry(feedback)
      } else next = ruleProposal(wish, all, basics.age, { avail })
    }
    // trener razmisli: preveč vadb za raven (razen če je število dni izrecno njegovo), delitev moči, lažji kardio po moči
    // za začetnika, razmik med težkimi dnevi, napredovanje (zakaj tako)
    next = { ...next, focus: { ...next.focus, main: mainEff } }
    const before = next.focus
    const rev = coachReview(next.focus, opts)
    // predlog po pravilih: odgovor iz pregledanega tedna (sicer bi govoril o 4 dneh, trener pa jih da 5);
    // AI: njegov odgovor + kaj je trener spremenil
    const ruled = !r || next.focus.by === 'pravila'
    const coachDiff = weekDiff(before, rev.focus)
    next = { ...next, focus: rev.focus, reply: ruled && !feedback
      ? `Predlagam ${weekLine(rev.focus)}: ${mixLine(rev.focus)}. ${daysReply(rev.focus)} Zakaj tako, piše spodaj — če želiš drugače, povej.`.replace(/\s+/g, ' ').trim()
      : rev.changed.length && rev.why[0] ? `${next.reply} Še kot trener: ${rev.why[0]}${coachDiff ? ` (${coachDiff}.)` : ''}`.trim() : next.reply }
    // vsaka sprememba na očeh (Blaž, 13. 10.: »sploh mu nisem rekel, da ne bo tako, kot je zdaj«)
    const was = feedback ? prop?.focus : current
    if (was) { const d = weekDiff(was, next.focus); next = { ...next, reply: `${next.reply} ${d ? `${feedback ? 'Spremenil' : 'Glede na sedanji načrt'}: ${d}.` : feedback ? '' : 'Glede na sedanji načrt: isti teden.'}`.trim() } }
    setBusy(null)
    setProp(next)
    setBase(null)
    setDayNote(null)
    setTalk(t => [...t, { who: 'trener', text: next!.reply }])
    setSay('')
    setStep('dogovor')
  }

  /** Dan brez časa (tap v tednu): vadbe gredo na druge dni; če jih je več kot dni, zadnja izpade (in se vrne, ko dan spet gre). */
  function toggleDay(d: number) {
    if (!prop || busy) return
    const from = base || prop.focus
    const cur = prop.focus.offDays || []
    const was = cur.includes(d)
    const off = was ? cur.filter(x => x !== d) : [...cur, d]
    if (off.length > 6) return
    const f0 = normalizeFocus({ ...from, offDays: off }, { age: basics.age, by: from.by, now: from.at })
    if (!f0) return
    const f = coachReview(f0, { age: basics.age, wantDays: trainingDays(f0.sessions) }).focus   // »zakaj tako« za nov razpored (število vadb ostane)
    if (!base) setBase(prop.focus)
    const key = (x: Focus['sessions'][number]) => `${x.type}|${x.part ?? ''}|${x.cardio ?? ''}|${x.min}`
    const diff = (a: Focus['sessions'], b: Focus['sessions']) => { const n = new Map<string, number>(); b.forEach(y => n.set(key(y), (n.get(key(y)) || 0) + 1)); return a.filter(x => { const k = key(x), c = n.get(k) || 0; if (c > 0) { n.set(k, c - 1); return false } return true }) }
    const lost = diff(prop.focus.sessions, f.sessions), back = diff(f.sessions, prop.focus.sessions)
    const unpinned = prop.focus.sessions.filter(x => x.day === d)
    setProp({ ...prop, focus: f })
    const reply = was
      ? `Prav — ${DAY_AT[d]} spet lahko.${back.length ? ` ${back.map(sessName).join(', ')} ${back.length === 1 ? 'je' : back.length === 2 ? 'sta' : 'so'} spet v tednu.` : ''}`
      : `Prav — ${DAY_AT[d]} ni vadbe.${lost.length ? ` Vse vadbe ne gredo več v teden, zato sem izpustil: ${lost.map(sessName).join(', ')}.` : unpinned.length ? ` ${unpinned.map(sessName).join(' + ')} gre na drug dan.` : ' Vadbe razporedim na druge dni.'}`
    // odgovor trenerja pod tednom (kjer je prst), ne v pogovoru zgoraj — da se kartica ne premakne
    setDayNote(reply)
  }

  async function save(final: Focus) {
    // trener si zapomni, kar je povedal (prejšnja želja, pripombe) — velja tudi v pogovoru in pri prilagoditvah
    const said = [...new Set([...(again && p0.focus ? [p0.focus.wish, ...(p0.focus.said || [])] : []), ...talk.filter(t => t.who === 'ti').map(t => t.text)].map(x => x.trim()).filter(x => x && x !== final.wish))].slice(-12)
    final = { ...final, said: said.length ? said : null }
    await applyAgreement(final, { sex: basics.sex ?? null, age: basics.age, heightCm: basics.heightCm, weightKg: basics.weightKg, trainTime, push })
  }
  function done() {
    markApp()
    navigate('danes')
  }

  const back = () => {
    if (busy) return
    if (step === 'dogovor') setStep(qs ? 'vprasanja' : 'zelja')
    else if (step === 'vprasanja') setStep('zelja')
    else if (again) navigate('nastavitve')
    else navigate('')
  }
  const stepIx = step === 'zelja' ? 1 : step === 'vprasanja' ? 2 : 3
  const sexOk = !!b.sex
  const anyPick = Object.values(picks).some(a => a.length > 0)
  const wishOk = anyPick || text.trim().length >= 8
  const availOk = avail.length >= 2
  const toggleAvail = (d: number) => setAvail(a => (a.includes(d) ? a.filter(x => x !== d) : [...a, d].sort((x, y) => x - y)))
  const togglePick = (g: string, o: string) => setPicks(p => {
    const single = CHOICE_GROUPS.find(x => x.id === g)?.single
    const cur = p[g] || []
    // »Še ne vem« izključi športe in obratno
    const next = cur.includes(o) ? cur.filter(x => x !== o) : single ? [o] : g === 'delam' ? (o === 'Še ne vem' ? [o] : [...cur.filter(x => x !== 'Še ne vem'), o]) : [...cur, o]
    return { ...p, [g]: next }
  })

  if (step === 'gradnja' && prop) {
    return (
      <Suspense fallback={<div className="ob" />}>
        <BuildShow focus={prop.focus} basics={basics} ai={!noAi} onSave={save} onDone={done} />
      </Suspense>
    )
  }

  return (
    <main className="ob sest" ref={top}>
      <div className="between" style={{ marginBottom: 14, minHeight: 34 }}>
        <button className="avatar" style={{ background: 'transparent', width: 40, height: 40 }} onClick={back} aria-label="Nazaj"><IcoBack /></button>
        {!again && !app.user && step === 'zelja'
          ? <button className="chip sm click" onClick={() => navigate('prijava')}>Že imam račun</button>
          : <div className="muted" style={{ fontSize: 12, fontWeight: 700 }}>{stepIx} / 3</div>}
      </div>
      <Progress pct={(stepIx / 3) * 100} />

      {step === 'zelja' && (<>
        <h2>{again ? 'Kaj bi spremenil?' : 'Kaj si želiš?'}</h2>
        <p style={{ marginTop: 7, fontSize: 14 }}>Izberi, kar velja zate, ali povej po svoje. Trener te potem vpraša, kar še rabi — in skupaj se dogovorita za teden.</p>
        <div className="pick-groups">
          {visibleGroups(picks).map(g => (
            <div key={g.id} className="pick-g" role="group" aria-labelledby={`pg-${g.id}`}>
              <div id={`pg-${g.id}`} className="pick-l">{g.label}</div>
              <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>{g.opts.map(o => <Chip key={o} sm on={!!picks[g.id]?.includes(o)} onClick={() => togglePick(g.id, o)}>{o}</Chip>)}</div>
            </div>
          ))}
        </div>
        <label htmlFor="sest-wish" className="pick-l" style={{ display: 'block', marginTop: 18 }}>Po svoje <span className="muted" style={{ fontWeight: 600 }}>(neobvezno)</span></label>
        <div className={`meal-text${wishDict.listening ? ' live' : ''}`} style={{ marginTop: 6 }}>
          <textarea id="sest-wish" ref={wishRef} rows={3} value={text} maxLength={700} onChange={e => setText(e.target.value)} style={{ minHeight: 92 }}
            placeholder={wishDict.listening ? 'Poslušam …' : 'npr. Ob torkih nimam časa. Do poletja 5 kg manj, a brez izgube moči.'} />
          {wishDict.canSpeak && <button type="button" className={`mic${wishDict.listening ? ' on' : ''}`} style={{ top: 26 }} onClick={wishDict.toggle} aria-pressed={wishDict.listening} aria-label={wishDict.listening ? 'Ustavi narekovanje' : 'Povej, kaj si želiš'}><IcoMic width={18} height={18} /></button>}
        </div>
        <ListenBar listening={wishDict.listening} onStop={wishDict.stop} value={text} />
        <div className="card tight" style={{ marginTop: 16 }}>
          <b style={{ fontSize: 13.5 }}>Kdaj imaš čas za vadbo?</b>
          <p className="muted" style={{ fontSize: 12, marginTop: 2 }}>Tapni dneve, ko realno lahko treniraš. Trener načrtuje samo nanje — in tako, da je med težkimi vadbami dan premora.</p>
          <div className="wk-pick" role="group" aria-label="Dnevi, ko imaš čas" style={{ marginTop: 10 }}>
            {DAY_OPTS.map((d, i) => <button key={d} type="button" className={`wk-d${avail.includes(i) ? ' on pin' : ''}`} aria-pressed={avail.includes(i)} aria-label={`${DAY_NAME[i]}: ${avail.includes(i) ? 'imam čas' : 'nimam časa'}`} style={avail.includes(i) ? { ['--c' as string]: 'var(--accent-fg)' } : undefined} onClick={() => toggleAvail(i)}><small>{d}</small><span className="wk-i" aria-hidden="true">{avail.includes(i) ? '✓' : '·'}</span></button>)}
          </div>
          <div className="row" style={{ gap: 6, marginTop: 8, flexWrap: 'wrap', alignItems: 'center' }}>
            <button type="button" className="chip sm click" onClick={() => setAvail(avail.length === 7 ? [] : [0, 1, 2, 3, 4, 5, 6])}>{avail.length === 7 ? 'počisti' : 'vsak dan'}</button>
            <span className="muted" style={{ fontSize: 12 }}>{avail.length ? `${avail.length} ${avail.length === 1 ? 'dan' : avail.length === 2 ? 'dneva' : avail.length <= 4 ? 'dnevi' : 'dni'} na teden` : 'izberi vsaj dva dneva'}</span>
          </div>
          <div className="row" style={{ gap: 6, marginTop: 10, flexWrap: 'wrap', alignItems: 'center' }} role="group" aria-label="Kdaj čez dan">
            <span className="muted" style={{ fontSize: 12, fontWeight: 700 }}>Običajno:</span>
            {([['zjutraj', 'zjutraj'], ['popoldne', 'čez dan'], ['zvecer', 'zvečer'], [null, 'različno']] as const).map(([v, l]) => <Chip key={l} sm on={trainTime === v} onClick={() => setTrainTime(v)}>{l}</Chip>)}
          </div>
          {both && <div className="row" style={{ gap: 6, marginTop: 8, flexWrap: 'wrap', alignItems: 'center' }} role="group" aria-label="Kaj ti je glavno">
            <span className="muted" style={{ fontSize: 12, fontWeight: 700 }}>Glavno:</span>
            {([['kardio', 'bolj kardio'], ['oboje', 'oboje enako'], ['moc', 'bolj moč']] as const).map(([v, l]) => <Chip key={v} sm on={main === v} onClick={() => setMain(v)}>{l}</Chip>)}
          </div>}
          <div className="row" style={{ gap: 6, marginTop: 8, flexWrap: 'wrap', alignItems: 'center' }} role="group" aria-label="Kakšen tip si">
            <span className="muted" style={{ fontSize: 12, fontWeight: 700 }}>Kakšen tip si:</span>
            {([['lahko', 'raje lažje'], ['zmerno', 'zmerno'], ['trdo', 'raje trdo']] as const).map(([v, l]) => <Chip key={v} sm on={push === v} onClick={() => setPush(v)}>{l}</Chip>)}
          </div>
        </div>
        <div className="card tight" style={{ marginTop: 12 }}>
          <b style={{ fontSize: 13.5 }}>O tebi</b>
          <p className="muted" style={{ fontSize: 12, marginTop: 2 }}>Za realen načrt in kalorije. Ostane v aplikaciji; AI dobi samo številke, brez imena.</p>
          <div className="row" style={{ gap: 7, marginTop: 10 }}>{([['m', 'Moški'], ['z', 'Ženska']] as const).map(([v, l]) => <Chip key={v} sm on={b.sex === v} onClick={() => setB({ ...b, sex: v })}>{l}</Chip>)}</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, marginTop: 10 }}>
            <div className="field"><label htmlFor="s-age">Starost</label><input id="s-age" type="number" inputMode="numeric" value={b.age} onChange={e => setB({ ...b, age: e.target.value })} /></div>
            <div className="field"><label htmlFor="s-h">Višina <span className="unit">cm</span></label><input id="s-h" type="number" inputMode="numeric" value={b.height} onChange={e => setB({ ...b, height: e.target.value })} /></div>
            <div className="field"><label htmlFor="s-w">Teža <span className="unit">kg</span></label><DecimalInput id="s-w" min={30} max={250} step={0.1} value={b.weight} onChange={e => setB({ ...b, weight: e.target.value })} /></div>
          </div>
          {basics.age != null && basics.age < 18 && <p style={{ fontSize: 12, marginTop: 8 }}>Do 18. leta ne načrtujem hujšanja — kalorije so vedno za vzdrževanje.</p>}
        </div>
        {declined && (
          <div className="card tight" role="status" style={{ marginTop: 12 }}>
            <p style={{ fontSize: 13 }}>Pogovor s trenerjem teče prek AI — za to se prijaviš z Googlom in dovoliš obdelavo. Raje brez tega? Spodaj izberi vprašalnik brez AI: vprašanja so stalna, načrt je še vedno po tvojih odgovorih.</p>
          </div>
        )}
        {busy && <div style={{ marginTop: 12 }}><Thinking label={busy} /></div>}
        <div className="grow" style={{ minHeight: 18 }} />
        <Btn primary block disabled={!wishOk || !availOk || !!busy} onClick={() => void startQuestions()}><IcoSpark width={17} height={17} /> {busy ? 'Trener razmišlja …' : 'Naprej'}</Btn>
        {!wishOk && <p className="muted" style={{ fontSize: 11.5, marginTop: 6, textAlign: 'center' }}>Izberi kaj zgoraj ali napiši, kaj želiš.</p>}
        {wishOk && !availOk && <p className="muted" style={{ fontSize: 11.5, marginTop: 6, textAlign: 'center' }}>Tapni vsaj dva dneva, ko imaš čas — brez tega trener ne more narediti realnega tedna.</p>}
        {!sexOk && wishOk && <p className="muted" style={{ fontSize: 11.5, marginTop: 6, textAlign: 'center' }}>Brez spola in teže kalorij ne pokažem — izpolniš lahko tudi pozneje.</p>}
        {!app.user && <button type="button" className="ob-fb" style={{ marginTop: 8 }} disabled={!wishOk || !availOk || !!busy} onClick={() => void startQuestions(true)}>Raje brez prijave (vprašalnik brez AI)</button>}
      </>)}

      {step === 'vprasanja' && qs && (<>
        <h2>{round === 1 ? 'Še nekaj vprašanj' : 'Samo še to'}</h2>
        {noAi && <p className="muted" style={{ fontSize: 12, marginTop: 8 }}>{byRules ? 'Vprašalnik brez AI — načrt bo po tvojih odgovorih.' : `AI se trenutno ne odziva${aiWhy ? ` (${aiWhy.replace(/\.$/, '')})` : ''} — vprašanja so iz vprašalnika, načrt bo vseeno po tvojih odgovorih.`}</p>}
        <div className="stack chat" style={{ marginTop: 12, gap: 8 }}>
          {hist.map((x, i) => <Fragment key={`h${i}`}><div className="talk">{i === 0 && <span className="talk-who">Trener</span>}{x.q}</div><div className="talk me">{x.a}</div></Fragment>)}
          {qs.understood && <div className="talk"><span className="talk-who">Trener</span>{qs.understood}</div>}
          {qs.questions.slice(0, curIx < 0 ? qs.questions.length : curIx + 1).map((q, i) => {
            const a = ans[q.id] || { picks: [], text: '' }
            const who = i === 0 && !qs.understood && !hist.length
            const cur = i === curIx
            // vprašanje ostane isti element (se ne pojavi znova), pod njim izbire ali tvoj odgovor
            return (
              <Fragment key={q.id}>
                <div className="talk" id={`qt-${q.id}`}>{who && <span className="talk-who">Trener</span>}{q.text}{cur && q.multi && <span className="q-hint"> · lahko izbereš več</span>}</div>
                {cur ? (
                  <div className="q-turn" ref={curRef} tabIndex={-1} role="group" aria-labelledby={`qt-${q.id}`}>
                    <div className="q-opts">{q.options.map(o => <Chip key={o} sm on={a.picks.includes(o)} onClick={() => pick(q, o)}>{o}</Chip>)}</div>
                    {q.other && (
                      <div className="q-own">
                        <input className="q-other" value={a.text} maxLength={160} enterKeyHint="send" onChange={e => setAns({ ...ans, [q.id]: { ...a, text: e.target.value } })}
                          onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); commit(q) } }} placeholder="ali napiši po svoje" aria-label={`${q.text} — svoj odgovor`} />
                      </div>
                    )}
                    {(q.multi || a.text.trim().length > 0) && <Btn primary sm disabled={!answerOf(ans, q) || !!busy} style={{ marginTop: 2 }} onClick={() => commit(q)}>Naprej ›</Btn>}
                  </div>
                ) : (
                  <button type="button" className="talk me q-ans" disabled={!!busy} onClick={() => reopen(q.id)} aria-label={`Tvoj odgovor: ${answerOf(ans, q)}. Tapni, da ga spremeniš.`}>{answerOf(ans, q)}</button>
                )}
              </Fragment>
            )
          })}
          {busy && <Thinking label={busy} />}
        </div>
        <div className="grow" style={{ minHeight: 18 }} />
        {curIx < 0 && !busy && <Btn primary block style={{ marginTop: 16 }} onClick={() => (prop ? setStep('dogovor') : void submitAnswers())}>{prop ? 'Nazaj na predlog' : 'Naprej'}</Btn>}
      </>)}

      {step === 'dogovor' && prop && (<>
        <h2>Najin dogovor</h2>
        <div className="stack" style={{ marginTop: 12, gap: 8 }}>
          {talk.slice(-5).map((t, i) => <div key={i} className={`talk${t.who === 'ti' ? ' me' : ''}`}>{t.who === 'trener' && <span className="talk-who">Trener</span>}{t.text}</div>)}
          {busy && <Thinking label={busy} />}
        </div>
        <Deal f={prop.focus} onDay={busy ? undefined : toggleDay} note={dayNote} />
        {again && <p className="muted" style={{ fontSize: 12, marginTop: 8 }}>Nov dogovor zamenja tvoj sedanji načrt od danes naprej. Opravljeni treningi ostanejo.</p>}
        <p className="muted" style={{ fontSize: 12.5, marginTop: 14 }}>Ti odločaš. Kaj bi spremenil?</p>
        <div className="row" style={{ gap: 6, flexWrap: 'wrap', marginTop: 8 }}>
          {retry && <button type="button" className="chip sm click on" disabled={!!busy} onClick={() => void propose(qaAll, retry)}>↻ Poskusi znova z AI</button>}
          {(prop.quick.length ? prop.quick : ['Več kardia', 'Več moči', 'Manj dni', 'Krajše vadbe']).map(x => <button key={x} type="button" className="chip sm click" disabled={!!busy} onClick={() => void propose(qaAll, x)}>{x}</button>)}
        </div>
        <div className={`meal-text${sayDict.listening ? ' live' : ''}`}>
          <label htmlFor="sest-say" className="sr-only">Kaj bi spremenil</label>
          <textarea id="sest-say" ref={sayRef} rows={2} value={say} maxLength={400} onChange={e => setSay(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); if (say.trim() && !busy) { sayDict.stop(); void propose(qaAll, say.trim()) } } }} enterKeyHint="send" placeholder={sayDict.listening ? 'Poslušam …' : 'npr. raje 4 dni, več teka, brez nog'} style={{ paddingRight: 96 }} />
          {sayDict.canSpeak && <button type="button" className={`mic${sayDict.listening ? ' on' : ''}`} style={{ right: 52 }} onClick={sayDict.toggle} aria-pressed={sayDict.listening} aria-label={sayDict.listening ? 'Ustavi narekovanje' : 'Povej, kaj bi spremenil'}><IcoMic width={18} height={18} /></button>}
          <button type="button" className="mic send" disabled={!say.trim() || !!busy} onClick={() => { sayDict.stop(); void propose(qaAll, say.trim()) }} aria-label="Pošlji trenerju">→</button>
        </div>
        <ListenBar listening={sayDict.listening} onStop={sayDict.stop} value={say} />
        <div className="grow" style={{ minHeight: 18 }} />
        <Btn primary block disabled={!!busy} style={{ marginTop: 16 }} onClick={() => { if (say.trim()) { sayDict.stop(); void propose(qaAll, say.trim()) } else setStep('gradnja') }}>{say.trim() ? 'Pošlji spremembo' : 'Dogovorjeno — sestavi moj načrt'}</Btn>
      </>)}

      <button type="button" className="ob-fb" onClick={() => void startFeedback()}>Nekaj ni jasno? Pošlji pripombo</button>
      {ai.sheet}
    </main>
  )
}

function Thinking({ label }: { label: string }) {
  return <div className="talk think" role="status" aria-live="polite"><span className="talk-who">Trener</span>{label}<span className="thinking" aria-hidden="true"><i /><i /><i /></span></div>
}

/** Odgovor trenerja omenja dan, ki ga v dogovoru ni (ne kot določen dan ne kot dan brez časa). */
function replyDaysOff(reply: string, f: Focus): boolean {
  const have = new Set<number>([...f.sessions.map(s => s.day).filter((d): d is number => d != null), ...(f.offDays || [])])
  return daysIn(reply).some(d => !have.has(d))
}
/** Ali se dnevi (določene seje, dnevi brez časa) med dvema dogovoroma razlikujejo. */
function daysDiffer(a: Focus, b: Focus): boolean {
  const k = (f: Focus) => [...f.sessions.map(s => `${s.type}:${s.day ?? '-'}`).sort(), 'off:' + (f.offDays || []).join(','), 'n:' + trainingDays(f.sessions)].join('|')
  return k(a) !== k(b)
}

/** Predlog tedna: ime, teden, cilji, seje (kardio isti dan pod močjo), razpored po dnevih (tap = ta dan nimam časa), pojasnila. */
export function Deal({ f, onDay, note }: { f: Focus; onDay?: (d: number) => void; note?: string | null }) {
  const notes = useMemo(() => f.notes.slice(0, 4), [f.notes])
  return (
    <div className="card deal" style={{ marginTop: 14 }}>
      <div className="h4">Predlog</div>
      <h3 style={{ fontSize: 20, marginTop: 4, letterSpacing: '-.02em' }}>{f.title}</h3>
      <p style={{ fontSize: 13, marginTop: 4 }}>{weekLine(f)}{f.aims.length || f.muscles.length ? ` · ${aimsLine(f)}` : ''}</p>
      <SessionList f={f} />
      {usesAgreement(f) ? (
        <WeekStrip f={f} onDay={onDay} busy={!onDay} note={note ? <><b>Trener:</b> {note}</> : undefined} />
      ) : (
        <p className="muted" style={{ fontSize: 12, marginTop: 10 }}>Cilj je tekma, zato je to kolesarski načrt do nje (faze, vati, teden dirke) — dnevi, ko nimaš časa, ostanejo prosti; trening premakneš v Planu.</p>
      )}
      {f.why && f.why.length > 0 && (
        <div className="deal-why">
          <div className="h4" style={{ fontSize: 10.5, margin: '12px 0 4px' }}>Zakaj tako</div>
          <ul className="deal-notes" style={{ marginTop: 0 }}>{f.why.map((n, i) => <li key={i}>{n}</li>)}</ul>
        </div>
      )}
      {notes.length > 0 && <ul className="deal-notes">{notes.map((n, i) => <li key={i}>{n}</li>)}</ul>}
    </div>
  )
}
