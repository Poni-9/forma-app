import { Fragment, lazy, Suspense, useEffect, useMemo, useRef, useState } from 'react'
import { navigate } from '@/app/router'
import { markApp } from '@/app/landing'
import { useApp, getState, applyAgreement, type AppState } from '@/state/store'
import { useAi } from '@/ui/useAi'
import { askJson, askClaude, claudeReady, claudeAccess, claudeTypical, claudeLast, AiError, type ClaudeRequest, type ClaudeProgress } from '@/domain/ai/client'
import { questionsRequest, proposalRequest, parseClaudeQuestions, parseClaudeProposal, CLAUDE_EFFORT, CLAUDE_EST_S, type PlanCtx } from '@/domain/ai/claudePlan'
import { sportsIn, tipsFor, figsFor } from '@/domain/focus/tips'
import { hasConsent, CONSENT_V } from '@/domain/ai/actions'
import { hasHiddenActivities } from '@/domain/ai/sanitize'
import { fileToBase64Resized } from '@/domain/ai/image'
import { makeFeedback, sendFeedback } from '@/data/feedback'
import { aiSafeView } from '@/domain/ai/safe'
import { addDays, fmtDur, weekStartIso } from '@/domain/training/load'
import { buildWeek, weekContext, weekMinutes } from '@/domain/training/planner'
import { ThinkCard, type Think } from '@/ui/ThinkCard'
import { questionsPrompt, parseQuestions, proposalPrompt, parseProposal, type QA, type QuestionsOut, type ProposalOut, type Basics, type AiQuestion } from '@/domain/ai/focusAi'
import { ruleQuestions, ruleProposal, ruleAdjust, applyDayWords, daysReply, daysIn, mentionsDays, keepDayStructure } from '@/domain/focus/rules'
import { coachReview, planInputs, weekDiff } from '@/domain/focus/coach'
import { CHOICE_GROUPS, visibleGroups, picksStrength, picksCardio, composeWish, splitWish, atDays, DAY_AT, DAY_OPTS, DAY_NAME, type Picks } from '@/domain/focus/choices'
import { useAutoGrow } from '@/ui/useAutoGrow'
import { ListenBar } from '@/ui/ListenBar'
import { weekLine, mixLine, aimsLine, normalizeFocus, trainingDays, usesAgreement, isStrength, profileFromFocus } from '@/domain/focus/model'
import type { Activity, Focus, PlanDay, Profile } from '@/domain/types'
import { useDictation } from '@/ui/useDictation'
import { Btn, Chip, DecimalInput, Progress } from '@/ui/primitives'
import { IcoBack, IcoMic, IcoSpark, IcoImage } from '@/ui/icons'
import { WeekStrip, SessionList, sessName } from '@/ui/WeekStrip'
import { WeekRibbon } from '@/ui/PlanHero'
import { startFeedback } from '@/ui/HelpSheet'
import { toast } from '@/state/store'
import { profileErrors } from '@/domain/ranges'
import { count, dm, W } from '@/ui/format'
export { sessionColor, SessionIcon } from '@/ui/WeekStrip'

const BuildShow = lazy(() => import('@/ui/BuildShow').then(m => ({ default: m.BuildShow })))

/**
 * SESTAVIVA TVOJ NAČRT (Blaž, 7. 10.): uporabnik izbere in/ali pove s svojimi besedami, kaj želi (besedilo ali glas),
 * AI vpraša naprej — vsakič nova vprašanja iz tega, kar je rekel, eno za drugim z izbirami kot v pogovoru — nato
 * predlaga realen teden in se z njim pogaja (več, manj, drugače, dnevi brez časa). Ko sta dogovorjena, se aplikacija
 * pred njim sestavi (BuildShow). Brez AI (napaka, limit) gre naprej po pravilih.
 */
type Step = 'zelja' | 'vprasanja' | 'dogovor' | 'gradnja'
type Ans = Record<string, { picks: string[]; text: string }>
const answerOf = (a: Ans, q: AiQuestion) => [...(a[q.id]?.picks || []), a[q.id]?.text.trim() || ''].filter(Boolean).join(', ')
const num = (v: string, lo: number, hi: number) => { const x = +v.replace(',', '.'); return v.trim() !== '' && Number.isFinite(x) && x >= lo && x <= hi ? x : null }
/** (v3.48) Kolesarski načrt (s tekmo) ne sledi dogovorjenim sejam: v odgovoru brez »Teden: …«, samo dnevi brez časa (pravi teden je v predlogu). */
const daysSaid = (f: Focus) => (usesAgreement(f) ? daysReply(f) : f.offDays?.length ? `${atDays(f.offDays).replace(/^o/, 'O')} ni vadbe.` : '')
/**
 * (v3.48) Kolesarski načrt: prvi poln teden, kot ga bo načrt res imel — isti profil kot ob »Dogovorjeno« (profileFromFocus)
 * in isti sestavljalnik (buildWeek kot rebuildFromToday). Danes ponedeljek → ta teden, sicer naslednji.
 */
export function firstBikeWeek(f: Focus, p: Profile, acts: readonly Activity[], today: string, checkins: AppState['checkins'] = [], weather: AppState['weather'] = null): { weekStart: string; days: PlanDay[]; event: boolean; easy: boolean } {
  const ws0 = weekStartIso(today)
  const prof = { ...p, ...profileFromFocus(f, p, ws0, today) } as Profile
  const ws = today === ws0 ? ws0 : addDays(ws0, 7)
  const rain: Record<string, number> = {}
  if (weather) for (const k in weather) rain[k] = weather[k]!.rain
  const cx = weekContext(prof, ws)
  return { weekStart: ws, days: buildWeek({ profile: prof, activities: acts, weekStart: ws, rain, notBefore: ws, checkins, today }), event: !!cx.event && cx.weeksToEvent != null && cx.weeksToEvent >= 0, easy: cx.easy > 0 }
}

export function Sestavi() {
  const app = useApp()
  const p0 = app.profile
  const ai = useAi()
  const again = p0.onboardingDone
  const [step, setStep] = useState<Step>('zelja')
  // izbire (kot pri Claudu) in svoje besede → ena želja za AI in vprašalnik
  const init = useMemo(() => splitWish(p0.focus?.wish || ''), []) // eslint-disable-line react-hooks/exhaustive-deps
  const [picks, setPicks] = useState<Picks>(init.picks)
  const [text, setText] = useState(init.text)
  const wish = composeWish(picks, text)
  const [b, setB] = useState(() => ({ sex: p0.sex, age: p0.age ? String(p0.age) : '', height: p0.heightCm ? String(p0.heightCm) : '', weight: p0.weightKg ? String(p0.weightKg) : '' }))
  // kdaj ima čas (Blaž, 11. 10.: »to mora nujno zvedeti«): dnevi s časom so okvir načrta; ostali dnevi so brez vadbe
  const [avail, setAvail] = useState<number[]>(() => (p0.focus ? [0, 1, 2, 3, 4, 5, 6].filter(d => !(p0.focus!.offDays || []).includes(d)) : []))
  const [trainTime, setTrainTime] = useState<'zjutraj' | 'popoldne' | 'zvecer' | null>(p0.trainTime ?? null)
  // kakšen tip si: raje manj naložen, zmerno ali trdo (Blaž, 11. 10.) — načrt in trener se prilagodita
  const [push, setPush] = useState<'lahko' | 'zmerno' | 'trdo'>(p0.push ?? 'zmerno')
  // kaj mu je glavno (Blaž, 11. 10.: »hoče bolj kolo, fitnesa ima preveč«) — razmerje sej
  const [main, setMain] = useState<'kardio' | 'oboje' | 'moc'>(p0.focus?.main ?? 'oboje')
  // glavno iz izbir: samo kardio ali samo moč se ve samo; vprašamo le, ko je izbral oboje
  const both = picksStrength(picks) && picksCardio(picks)
  const mainEff: 'kardio' | 'oboje' | 'moc' = both ? main : picksCardio(picks) ? 'kardio' : picksStrength(picks) ? 'moc' : main
  // Claude trener (povabilo): prva stran je odprta — po svoje, s sliko; izbire in dnevi so neobvezni (Blaž, 14. 10.)
  const [claudeOn, setClaudeOn] = useState(false)
  useEffect(() => { if (app.user || import.meta.env.VITE_E2E === '1') void claudeAccess().then(a => setClaudeOn(a.ok)) }, [app.user])
  const [imgs, setImgs] = useState<{ mime: string; data: string; thumb: string }[]>([])
  // brez označenih dni: pri Claudu vsi dnevi (trener vpraša ali sklepa iz besed), sicer je izbira obvezna
  const daysPicked = avail.length > 0
  const availEff = claudeOn && !daysPicked ? [0, 1, 2, 3, 4, 5, 6] : avail
  const basics: Basics = { sex: b.sex, age: num(b.age, 12, 99), heightCm: num(b.height, 120, 230), weightKg: num(b.weight, 30, 250), avail: availEff, trainTime, push, main: mainEff }
  // »O tebi« (v3.48): vrednost izven razpona dobi sporočilo (ob odhodu iz polja) — prej je tiho izginila in kalorij ni bilo
  const [bTouched, setBTouched] = useState<Partial<Record<'age' | 'height' | 'weight', boolean>>>({})
  const bErr = profileErrors({ age: b.age, height: b.height, weight: b.weight })
  const bShown = (['age', 'height', 'weight'] as const).filter(k => bTouched[k] && bErr[k])
  const bFx = (k: 'age' | 'height' | 'weight') => {
    const bad = bShown.includes(k)
    return { onBlur: () => setBTouched(t => (t[k] ? t : { ...t, [k]: true })), 'aria-invalid': bad || undefined, 'aria-describedby': bad ? 's-err' : undefined, style: bad ? { borderColor: 'var(--warn)' } : undefined }
  }
  /** Naprej iz prvega koraka: z napačno številko ostani in jo pokaži. */
  const goQuestions = (rules = false) => {
    if (Object.keys(bErr).length) { setBTouched({ age: true, height: true, weight: true }); return }
    void startQuestions(rules)
  }
  const noDays = [0, 1, 2, 3, 4, 5, 6].filter(d => !availEff.includes(d))
  const [round, setRound] = useState(1)
  // kdo sprašuje: Claude sam odloči, koliko krogov rabi (do 6); Gemini dva kroga; vprašalnik brez AI enega
  const [qsBy, setQsBy] = useState<'claude' | 'ai' | 'pravila'>('ai')
  const MAX_ROUNDS = 6
  const [qs, setQs] = useState<QuestionsOut | null>(null)
  const [ans, setAns] = useState<Ans>({})
  const [doneIds, setDoneIds] = useState<string[]>([])          // potrjeni odgovori v tem krogu (vprašanje za vprašanjem)
  const [hist, setHist] = useState<QA[]>([])              // prejšnji krogi
  const [qaAll, setQaAll] = useState<QA[]>([])            // vsi odgovori (za predlog in pogajanje)
  const [prop, setProp] = useState<ProposalOut | null>(null)
  const [base, setBase] = useState<Focus | null>(null)   // predlog pred spremembo dni (da se vadbe vrnejo, ko dan spet gre)
  const [dayNote, setDayNote] = useState<string | null>(null)
  const [talk, setTalk] = useState<{ who: 'ti' | 'trener'; text: string }[]>([])
  const [say, setSay] = useState('')
  const [busy, setBusy] = useState<string | null>(null)
  const [think, setThink] = useState<Think | null>(null)        // Claude razmišlja: kartica s koraki in časom
  // Claude ni odgovoril: brez tihega preklopa na Gemini (Blaž, 14. 10.: »pogovarja se pametno, na koncu pa naredi
  // kar en plan« — predlog je bil od rezerve) — uporabnik izbere: znova s Claudom ali naprej z Gemini
  const [claudeFail, setClaudeFail] = useState<{ why: string; retry: () => void; gemini: () => void } | null>(null)
  const [useGemini, setUseGemini] = useState(false)
  const failClaude = (why: string | null, retry: () => void, gemini: () => void) => { setBusy(null); setClaudeFail({ why: why || 'ni odgovoril', retry: () => { setClaudeFail(null); retry() }, gemini: () => { setClaudeFail(null); setUseGemini(true); gemini() } }) }
  // MANJŠA SPREMEMBA (Blaž, 14. 10.: »samo kakšno spremembo narediti, ne celega načrta, samo malo«): ko načrt že ima,
  // pove samo, kaj spremeniti — brez novih vprašanj; trener spremeni samo to, ostalo (dnevi, vaje, vsebina) ostane
  const [quickMode, setQuickMode] = useState(false)
  const [quick, setQuick] = useState('')
  const quickRef = useRef<HTMLTextAreaElement>(null)
  const [noAi, setNoAi] = useState(false)
  const [aiWhy, setAiWhy] = useState<string | null>(null)      // zakaj AI nazadnje ni odgovoril (pokaže se v pogovoru)
  const [retry, setRetry] = useState<string | null>(null)      // sprememba, ki jo AI ni obdelal — »Poskusi znova z AI«
  const [declined, setDeclined] = useState(false)
  const [byRules, setByRules] = useState(false)
  const top = useRef<HTMLDivElement>(null)
  const curRef = useRef<HTMLDivElement>(null)
  const wishRef = useRef<HTMLTextAreaElement>(null), sayRef = useRef<HTMLTextAreaElement>(null)
  const wishDict = useDictation(text, setText, m => toast(m, 'err', 6000), 'kaj si želi od načrta: cilji, športi, dnevi, čas')
  const sayDict = useDictation(say, setSay, m => toast(m, 'err', 6000), 'sprememba predloga tedna')
  const quickDict = useDictation(quick, setQuick, m => toast(m, 'err', 6000), 'manjša sprememba sedanjega načrta')
  useAutoGrow(wishRef, text, 220)
  useAutoGrow(sayRef, say, 200)
  useAutoGrow(quickRef, quick, 160)
  useEffect(() => { window.scrollTo(0, 0) }, [step, round])
  const curIx = qs ? qs.questions.findIndex(q => !doneIds.includes(q.id)) : -1
  // naslednje vprašanje pride na vrsto: pokaži ga in nanj premakni fokus (bralnik zaslona ga prebere)
  useEffect(() => {
    const el = curRef.current
    if (step !== 'vprasanja' || curIx < 0 || !el || (curIx === 0 && round === 1)) return
    const calm = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
    el.scrollIntoView({ block: 'nearest', behavior: calm ? 'auto' : 'smooth' })
    el.focus({ preventScroll: true })
  }, [step, curIx, round])

  /**
   * AI klic z vrati (prijava, privolitev). null = AI ni odgovoril (napaka, limit) → naprej po pravilih; razlog ostane
   * v aiWhy (pokaže se v pogovoru). retry: pri pogajanju AI poskusi znova vsakič — ena napaka ga ne ugasne za vso sejo.
   */
  async function viaAi<T>(fn: () => Promise<T>, retry = false): Promise<{ r: T | null; why: string | null }> {
    if (noAi && !retry) return { r: null, why: aiWhy }
    let why: string | null = null
    const r = await ai.run(fn, { quiet: true, onError: m => { why = m } })
    if (r !== undefined) { setNoAi(false); setAiWhy(null); return { r, why: null } }
    setNoAi(true)
    setAiWhy(why)
    return { r: null, why }
  }

  /** Vse, kar Claude trener sme vedeti (stanje prebere ob klicu — po prijavi ali privolitvi je profil nov). */
  const ctxOf = (x: Pick<PlanCtx, 'qa'> & Partial<PlanCtx>): PlanCtx => {
    const st = getState()
    return { today: st.today, profile: st.profile, basics, picks, text, wish, activities: st.activities, plan: st.plan, checkins: st.checkins, daysPicked, ...(imgs.length ? { images: imgs.map(i => ({ mime: i.mime, data: i.data })) } : {}), ...x }
  }
  /** Koraki razmisleka za kartico — iz tega, kar trener ta hip res dobi (želje, treningi, dnevi, odgovori). */
  type ThinkKind = 'vprasanja' | 'vprasanja2' | 'predlog' | 'popravek'
  function thinkOf(kind: ThinkKind, fb?: string): Think {
    const st = getState()
    const n = aiSafeView({ profile: st.profile, activities: st.activities, plan: st.plan, today: st.today }).activities.filter(a => a.date <= st.today && a.date >= addDays(st.today, -120)).length
    const chosen = CHOICE_GROUPS.flatMap(g => picks[g.id] || []).slice(0, 4).map(x => x.toLowerCase())
    const acts = n ? `Pregledujem tvojih ${n} ${n === 1 ? 'trening' : n === 2 ? 'treninga' : n <= 4 ? 'treninge' : 'treningov'} zadnjih mesecev` : null
    const at = Date.now()
    // med čakanjem: napredek po resničnih časih, figura izvaja njegove športe, nasveti zanje (Blaž, 14. 10.)
    const said = [wish, ...hist.map(q => q.a), ...qaAll.map(q => q.a), ...talk.filter(x => x.who === 'ti').map(x => x.text), fb || ''].join(' ')
    const tags = sportsIn(said)
    const purpose = kind === 'vprasanja' || kind === 'vprasanja2' ? 'vprasanja' as const : 'predlog' as const
    const step = kind === 'popravek' ? 'popravek' as const : purpose
    const extra = { est: claudeTypical(purpose, CLAUDE_EFFORT[step]) ?? CLAUDE_EST_S[step], last: claudeLast(purpose, CLAUDE_EFFORT[step]), tips: tipsFor(tags, at), figs: figsFor(tags, said) }
    // brez označenih dni (Claude: neobvezno) ne »0 dnevi na teden« (v3.48)
    if (kind === 'vprasanja') return { ...extra, title:'Trener razmišlja', at, phase: 'misli', writing: 'Pripravljam vprašanja zate', steps: [chosen.length ? `Berem tvoje želje: ${chosen.join(', ')}` : 'Berem tvoje želje', acts || (avail.length ? `Gledam, koliko časa imaš (${count(avail.length, W.dan)} na teden)` : 'Preberem, kdaj imaš čas'), 'Premislim, kaj še rabim vedeti'] }
    if (kind === 'vprasanja2') return { ...extra, title: 'Trener razmišlja', at, phase: 'misli', writing: 'Pripravljam še zadnja vprašanja', steps: ['Berem tvoje odgovore', 'Premislim, ali vem dovolj za najboljši načrt'] }
    if (kind === 'popravek') return { ...extra, title: 'Trener razmišlja', at, phase: 'misli', writing: 'Pišem popravljen načrt', steps: [`Berem tvojo pripombo: »${(fb || '').slice(0, 70)}${(fb || '').length > 70 ? ' …' : ''}«`, 'Premislim, kaj spremeniti', 'Preverjam, da ostalo ostane dobro'] }
    return {
      ...extra, title: 'Trener razmišlja', at, phase: 'misli', writing: 'Pišem tvoj predlog tedna',
      steps: [
        'Berem vse, kar si mi povedal',
        ...(acts ? [acts] : []),
        noDays.length ? `Upoštevam, da ${atDays(noDays)} nimaš časa` : 'Imaš čas vsak dan — izbiram najboljše dni',
        both ? 'Tehtam razmerje moč : kardio' : 'Izbiram vrsto in intenzivnost vsake vadbe',
        'Razporejam težke in lahke dni',
        'Preverjam obnovo med vadbami',
        'Načrtujem 4-tedenski blok',
      ],
    }
  }

  /** kar je povedal ob prejšnjem dogovoru in v tem pogovoru (velja, dokler ne reče drugače) */
  const saidSoFar = (extra: readonly string[] = []) => [...(again && p0.focus ? [p0.focus.wish, ...(p0.focus.said || [])] : []), ...talk.filter(t => t.who === 'ti').map(t => t.text), ...extra].filter(x => x && x !== wish)

  /**
   * CLAUDE TRENER (Blaž, 14. 10.: »naj to dela Claude … naj res dobro pomisli«): ko ga strežnik ima, vprašanja, predlog
   * in pogajanje naredi Claude. ok = odgovor; off = ni na voljo ali napaka → Gemini; no = prijava ali privolitev
   * zavrnjena ali dnevna meja → tudi Gemini ne bo šel (brez AI).
   */
  async function viaClaude(req: () => ClaudeRequest, kind: ThinkKind, retry = false, feedback?: string, gem = false): Promise<{ s: 'ok'; r: unknown } | { s: 'off' | 'no' | 'skip'; why: string | null }> {
    // skip = Claude ni na voljo ali je uporabnik izbral Gemini → Gemini brez besed; off = Claude je poskusil in ni uspel
    if (gem || useGemini || byRules || (noAi && !retry) || !(await claudeReady())) return { s: 'skip', why: null }
    setClaudeFail(null)
    const box: { why: string | null; kind: string | null } = { why: null, kind: null }
    // strežnik sporoča fazo: premišlja → piše (kartica pokaže korake razmisleka in čas — premislek lahko traja minute)
    const onProgress: ClaudeProgress = p => { if (p.faza === 'pise') setThink(t => (t && t.phase !== 'pise' ? { ...t, phase: 'pise' } : t)) }
    const r = await ai.run(() => { setThink(thinkOf(kind, feedback)); return askClaude<unknown>(req(), { onProgress }).catch((e: unknown) => { box.kind = e instanceof AiError ? e.kind : null; throw e }) }, { quiet: true, consentV: CONSENT_V, onError: m => { box.why = m } })
      .finally(() => setThink(null))
    if (r !== undefined) { setNoAi(false); setAiWhy(null); return { s: 'ok', r } }
    // brez napake = prijava ali privolitev ni bila dana; kdor je zavrnil samo novo besedilo (Claude), gre na Gemini
    if (box.why == null) return { s: getState().user && hasConsent(getState().profile) ? 'skip' : 'no', why: null }
    return { s: box.kind === 'quota' || box.kind === 'auth' ? 'no' : 'off', why: box.why }
  }

  /** rules = kratek vprašalnik brez prijave in brez AI (vprašanja, predlog in sestava po pravilih). */
  async function startQuestions(rules = false, gem = false) {
    setQuickMode(false)
    setDeclined(false)
    setBusy('Berem tvoje želje …')
    let parsed: QuestionsOut | null = null
    let fallback = noAi || rules
    if (rules) setByRules(true)
    if (!fallback) {
      // Claude trener (ko ga strežnik ima); sicer ali ob napaki Gemini
      const c = await viaClaude(() => questionsRequest(ctxOf({ qa: [] }), 1), 'vprasanja', false, undefined, gem)
      if (c.s === 'off') { failClaude(c.why, () => void startQuestions(), () => void startQuestions(false, true)); return }
      if (c.s === 'ok') {
        parsed = parseClaudeQuestions(c.r, hasHiddenActivities(getState().activities))
        if (parsed?.questions.length) setQsBy('claude')
        // trener ve dovolj: naravnost na predlog
        if (parsed && !parsed.questions.length && parsed.enough) { setQs(null); setAns({}); setDoneIds([]); setRound(1); setHist([]); setQaAll([]); await propose([], null); return }
      }
      if (c.s === 'no') {
        const st = getState()
        // ni prijave ali privolitve: ostani tu in povej, kaj sta možnosti
        if (import.meta.env.VITE_E2E !== '1' && (!st.user || !hasConsent(st.profile))) { setBusy(null); setDeclined(true); return }
        setAiWhy(c.why)
        fallback = true
      } else if (!parsed?.questions.length) {
        setBusy('Berem tvoje želje …')
        const r = await ai.run(() => askJson<unknown>(questionsPrompt({ wish, basics, qa: [], round: 1 })), { quiet: true, onError: m => setAiWhy(m) })
        if (r === undefined) {
          const st = getState()
          if (import.meta.env.VITE_E2E !== '1' && (!st.user || !hasConsent(st.profile))) { setBusy(null); setDeclined(true); return }
          fallback = true
        } else { parsed = parseQuestions(r); setAiWhy(null); setQsBy('ai') }
      }
      if (!parsed || !parsed.questions.length) fallback = true
    }
    setBusy(null)
    if (fallback) setNoAi(true)
    if (fallback) setQsBy('pravila')
    setQs(!fallback && parsed ? parsed : ruleQuestions(wish, { avail })); setAns({}); setDoneIds([]); setRound(1); setHist([]); setQaAll([]); setStep('vprasanja')
  }

  /** Izbira pri vprašanju: ena možnost odgovori takoj, pri več možnostih potrdi »Naprej«. */
  function pick(q: AiQuestion, o: string) {
    if (busy) return
    const a = ans[q.id] || { picks: [], text: '' }
    const picksNow = q.multi ? (a.picks.includes(o) ? a.picks.filter(x => x !== o) : [...a.picks, o]) : [o]
    const next = { ...ans, [q.id]: { ...a, picks: picksNow } }
    setAns(next)
    if (!q.multi) commit(q, next)
  }
  function commit(q: AiQuestion, a: Ans = ans) {
    if (busy || !qs || !answerOf(a, q)) return
    const d = [...doneIds.filter(x => x !== q.id), q.id]
    setDoneIds(d)
    if (qs.questions.every(x => d.includes(x.id))) void submitAnswers(a)
  }
  /** tap na svoj odgovor: vprašanje spet odpre (ko odgovoriš, gre naprej od tam) */
  function reopen(id: string) { if (!busy) setDoneIds(d => d.filter(x => x !== id)) }

  async function submitAnswers(a: Ans = ans, gem = false) {
    if (!qs) return
    const add: QA[] = qs.questions.map(q => ({ id: q.id, q: q.text, a: answerOf(a, q) }))
    const all = [...hist, ...add]
    setQaAll(all)
    // Claude sprašuje, dokler sam ne reče, da ve dovolj (največ 6 krogov); Gemini en dodatni krog
    const more = !qs.enough && !noAi && (qsBy === 'claude' ? round < MAX_ROUNDS : qsBy === 'ai' && round === 1)
    if (more) {
      setBusy('Še nekaj bi rad vedel …')
      let q2: QuestionsOut | null = null
      const next = round + 1
      const c = qsBy === 'claude' ? await viaClaude(() => questionsRequest(ctxOf({ qa: all }), next), 'vprasanja2', false, undefined, gem) : { s: 'skip' as const, why: null }
      if (c.s === 'off') { failClaude(c.why, () => void submitAnswers(a), () => void propose(all, null, true)); return }
      if (c.s === 'ok') q2 = parseClaudeQuestions(c.r, hasHiddenActivities(getState().activities))
      else if (c.s === 'skip' && round === 1 && qsBy !== 'claude') { const { r } = await viaAi(() => askJson<unknown>(questionsPrompt({ wish, basics, qa: all, round: 2 }))); q2 = r ? parseQuestions(r) : null; if (q2) setQsBy('ai') }
      setBusy(null)
      if (q2 && q2.questions.length) { setHist(all); setQs(q2); setAns({}); setDoneIds([]); setRound(next); return }
    }
    await propose(all, null)
  }

  async function propose(all: QA[], feedback: string | null, gem = false) {
    setBusy(feedback ? 'Popravljam predlog …' : 'Sestavljam predlog tedna …')
    // ponovni poskus iste pripombe: v pogovoru samo enkrat
    if (feedback) setTalk(t => (t.length && t[t.length - 1]!.who === 'ti' && t[t.length - 1]!.text === feedback ? t : [...t, { who: 'ti', text: feedback }]))
    setRetry(null)
    // vse dosedanje pripombe gredo zraven (Blaž, 11. 10.: »ne posluša, ko mu povem«) — prej je AI videl samo zadnjo
    // + kar je povedal ob prejšnjem dogovoru (želja in pripombe) — velja, dokler ne reče drugače
    const history = feedback ? saidSoFar() : [...(again && p0.focus ? [p0.focus.wish, ...(p0.focus.said || [])] : [])].filter(x => x && x !== wish)
    // ODMEREK iz njegovih besed (Blaž, 13. 10.: »dober plan je najpomembnejša funkcija«): raven (izbira, zgibi …),
    // dnevi (»3-4«), čas na vadbo (»60 do 75 minut«), razmerje moč : kardio po cilju in izbirah — gre AI-ju v poziv in
    // trenerju (coachReview) v preverbo
    const { opts, dose } = planInputs({ picks, wish, qa: all, feedback, age: basics.age, push, main: mainEff, everyDay: !!prop?.focus.everyDay, avail })
    const current = again && p0.focus ? p0.focus : null
    const wantDays = opts.wantDays ?? (opts.asIs && prop?.focus.everyDay ? 7 : null)
    // CLAUDE: dobi vse podatke in odloči sam (število, razmerje, vsebino, dneve); aplikacija sestavi točno njegov teden —
    // preveri samo varovalke (normalizeFocus). Brez popravkov po pravilih: njegov teden, njegova razlaga.
    // dnevi brez časa: iz 1. koraka vedno, pri popravku še tisti, ki jih je tapnil v tednu (trener jih vidi kot dneve brez časa)
    const offNow = feedback ? [...new Set([...noDays, ...(prop?.focus.offDays || [])])] : noDays
    const cl = await viaClaude(() => proposalRequest(ctxOf({ qa: all, prev: prop?.focus ?? current, feedback, history, current, basics: { ...basics, avail: avail.filter(d => !offNow.includes(d)) } })),
      feedback ? 'popravek' : 'predlog', !!feedback, feedback ?? undefined, gem)
    const byClaude = cl.s === 'ok' ? parseClaudeProposal(cl.r, { wish, age: basics.age, offDays: offNow, everyDay: wantDays === 7, hidden: hasHiddenActivities(getState().activities) }) : null
    if (cl.s === 'off' || (cl.s === 'ok' && !byClaude)) { failClaude(cl.s === 'ok' ? 'odgovor ni bil uporaben' : cl.why, () => void propose(all, feedback), () => void propose(all, feedback, true)); return }
    if (byClaude) {
      const f = { ...byClaude.focus, main: mainEff }
      // česa aplikacija ne zna: povej uporabniku in sporoči kot predlog za izboljšavo (brez osebnih podatkov)
      const miss = byClaude.missing || []
      if (miss.length) void reportMissing(miss)
      const reply = `${byClaude.reply || `Predlagam ${weekLine(f)}. ${daysSaid(f)}`}${miss.length ? ` Tega aplikacija še ne zna: ${miss.join('; ')} — sporočil sem kot predlog za izboljšavo.` : ''}`
      show({ ...byClaude, focus: f, reply }, feedback, current)
      return
    }
    if (cl.s === 'no') { setNoAi(true); setAiWhy(cl.why) }
    setBusy(feedback ? 'Popravljam predlog …' : 'Sestavljam predlog tedna …')
    // osnova pri spremembi: zadnji predlog ali (manjša sprememba) sedanji načrt
    const basef = prop?.focus ?? current
    const { r, why: aiErr } = cl.s === 'no' ? { r: null, why: cl.why } : await viaAi(() => askJson<unknown>(proposalPrompt({ wish, basics, qa: all, prev: prop?.focus ?? current, feedback, history, current, dose })), !!feedback)
    // določeni dnevi in dnevi brez časa iz prejšnjega predloga ostanejo, če jih AI v popravku izpusti (uporabnikove
    // nove besede o dnevih jih spodaj spremenijo)
    // dnevi brez časa iz 1. koraka veljajo vedno (tudi če jih AI izpusti); pri popravku še dnevi iz prejšnjega predloga
    // »vsak dan« ostane tudi v pogajanju, dokler ne reče drugih dni
    let next = r ? parseProposal(r, { wish, age: basics.age, prevOff: feedback ? [...(prop?.focus.offDays || []), ...noDays] : noDays, keepDays: feedback ? basef?.sessions : null, everyDay: wantDays === 7 }) : null
    const why = r && !next ? 'AI je odgovoril, a predlog ni bil uporaben' : aiErr
    if (next) {
      // uporabnik ni govoril o dnevih (»več kardia«): dnevi iz prejšnjega predloga ostanejo, tudi če jih je AI spremenil
      if (feedback && basef && !mentionsDays(feedback)) next = { ...next, focus: keepDayStructure(basef, next.focus, basics.age) }
      // besede o dnevih (»fitnes torek in petek«, »ob torkih ne morem«) veljajo tudi, če jih AI ni upošteval
      const fixed = applyDayWords(next.focus, feedback ?? wish, basics.age)
      if (fixed && daysDiffer(next.focus, fixed)) next = { ...next, focus: fixed, reply: `${next.reply} ${daysSaid(fixed)}`.trim() }
      else if (!next.reply) next = { ...next, reply: `Predlagam ${weekLine(next.focus)}. ${daysSaid(next.focus)}` }
      // uporabnik je govoril o dnevih ali AI v odgovoru omenja dan, ki ga v dogovoru ni (»premaknil na ponedeljek«): povej prave dneve
      else if ((feedback && mentionsDays(feedback)) || replyDaysOff(next.reply, next.focus)) next = { ...next, reply: `${next.reply} ${daysSaid(next.focus)}`.trim() }
    } else {
      const note = why ? `AI ni odgovoril: ${why.replace(/\.?$/, '.')} ` : ''
      if (feedback && basef) {
        const adj = ruleAdjust(basef, feedback, basics.age)
        next = adj
          ? { reply: `${note}Medtem sem popravil po pravilih. ${daysSaid(adj)}`, focus: adj, quick: prop?.quick ?? [] }
          : { quick: prop?.quick ?? [], focus: basef, reply: `${note}Brez AI razumem dneve (»ob torkih ne morem«, »fitnes torek in petek«, »tek v istem dnevu«) in hitre odgovore spodaj — ali poskusi znova z AI.` }
        setRetry(feedback)
      } else next = ruleProposal(wish, all, basics.age, { avail })
    }
    // trener razmisli: preveč vadb za raven (razen če je število dni izrecno njegovo), delitev moči, lažji kardio po moči
    // za začetnika, razmik med težkimi dnevi, napredovanje (zakaj tako)
    next = { ...next, focus: { ...next.focus, main: mainEff } }
    const before = next.focus
    const rev = coachReview(next.focus, opts)
    // predlog po pravilih: odgovor iz pregledanega tedna (sicer bi govoril o 4 dneh, trener pa jih da 5);
    // AI: njegov odgovor + kaj je trener spremenil
    const ruled = !r || next.focus.by === 'pravila'
    const coachDiff = weekDiff(before, rev.focus)
    next = { ...next, focus: rev.focus, reply: ruled && !feedback
      ? (usesAgreement(rev.focus)
        ? `Predlagam ${weekLine(rev.focus)}: ${mixLine(rev.focus)}. ${daysReply(rev.focus)} Zakaj tako, piše spodaj — če želiš drugače, povej.`
        : `Predlagam kolesarski načrt, ${weekLine(rev.focus).split(' · ')[1]}. ${daysSaid(rev.focus)} Prvi teden je spodaj — če želiš drugače, povej.`).replace(/\s+/g, ' ').trim()
      : rev.changed.length && rev.why[0] ? `${next.reply} Še kot trener: ${rev.why[0]}${coachDiff ? ` (${coachDiff}.)` : ''}`.trim() : next.reply }
    show(next, feedback, current)
  }

  /** Predlog na zaslon; vsaka sprememba na očeh (Blaž, 13. 10.: »sploh mu nisem rekel, da ne bo tako, kot je zdaj«). */
  function show(next: ProposalOut, feedback: string | null, current: Focus | null) {
    const was = feedback ? (prop?.focus ?? current) : current
    if (was) { const d = weekDiff(was, next.focus); next = { ...next, reply: `${next.reply} ${d ? `${feedback ? 'Spremenil' : 'Glede na sedanji načrt'}: ${d}.` : feedback ? '' : 'Glede na sedanji načrt: isti teden.'}`.trim() } }
    setBusy(null)
    setProp(next)
    setBase(null)
    setDayNote(null)
    setTalk(t => [...t, { who: 'trener', text: next!.reply }])
    setSay('')
    setStep('dogovor')
  }

  /** Dan brez časa (tap v tednu): vadbe gredo na druge dni; če jih je več kot dni, zadnja izpade (in se vrne, ko dan spet gre). */
  function toggleDay(d: number) {
    if (!prop || busy) return
    const from = base || prop.focus
    const cur = prop.focus.offDays || []
    const was = cur.includes(d)
    const off = was ? cur.filter(x => x !== d) : [...cur, d]
    if (off.length > 6) return
    const f0 = normalizeFocus({ ...from, offDays: off }, { age: basics.age, by: from.by, now: from.at })
    if (!f0) return
    // »zakaj tako« za nov razpored (število vadb ostane); teden od Claude ostane njegov — seja z dneva gre na drug dan
    const f = from.by === 'claude' ? f0 : coachReview(f0, { age: basics.age, wantDays: trainingDays(f0.sessions) }).focus
    if (!base) setBase(prop.focus)
    const key = (x: Focus['sessions'][number]) => `${x.type}|${x.part ?? ''}|${x.cardio ?? ''}|${x.min}`
    const diff = (a: Focus['sessions'], b: Focus['sessions']) => { const n = new Map<string, number>(); b.forEach(y => n.set(key(y), (n.get(key(y)) || 0) + 1)); return a.filter(x => { const k = key(x), c = n.get(k) || 0; if (c > 0) { n.set(k, c - 1); return false } return true }) }
    const lost = diff(prop.focus.sessions, f.sessions), back = diff(f.sessions, prop.focus.sessions)
    const unpinned = prop.focus.sessions.filter(x => x.day === d)
    setProp({ ...prop, focus: f })
    const reply = was
      ? `Prav — ${DAY_AT[d]} spet lahko.${back.length ? ` ${back.map(sessName).join(', ')} ${back.length === 1 ? 'je' : back.length === 2 ? 'sta' : 'so'} spet v tednu.` : ''}`
      : `Prav — ${DAY_AT[d]} ni vadbe.${lost.length ? ` Vse vadbe ne gredo več v teden, zato sem izpustil: ${lost.map(sessName).join(', ')}.` : unpinned.length ? ` ${unpinned.map(sessName).join(' + ')} gre na drug dan.` : ' Vadbe razporedim na druge dni.'}`
    // odgovor trenerja pod tednom (kjer je prst), ne v pogovoru zgoraj — da se kartica ne premakne
    setDayNote(reply)
  }

  async function save(final: Focus) {
    // trener si zapomni, kar je povedal (prejšnja želja, pripombe) — velja tudi v pogovoru in pri prilagoditvah
    const said = [...new Set([...(again && p0.focus ? [p0.focus.wish, ...(p0.focus.said || [])] : []), ...talk.filter(t => t.who === 'ti').map(t => t.text)].map(x => x.trim()).filter(x => x && x !== final.wish))].slice(-12)
    final = { ...final, said: said.length ? said : null }
    await applyAgreement(final, { sex: basics.sex ?? null, age: basics.age, heightCm: basics.heightCm, weightKg: basics.weightKg, trainTime, push })
  }
  function done() {
    markApp()
    navigate('danes')
  }

  /** Manjša sprememba: trener dobi sedanji načrt in pripombo — brez vprašanj (popravek spremeni samo, kar je rekel). */
  async function quickChange() {
    const t = quick.trim()
    if (!p0.focus || !t || busy) return
    quickDict.stop()
    setQuickMode(true)
    setQs(null); setHist([]); setQaAll([]); setProp(null); setTalk([]); setRetry(null)
    await propose([], t)
  }
  /**
   * Potrditev manjše spremembe: kar je ostalo enako, obdrži vaje s serijami, vsebino in razlog iz sedanjega načrta
   * (brez ponovne sestave in brez čakanja). Če je nova vadba moči brez vaj, jih trener dodela ob sestavljanju.
   */
  async function applyQuick() {
    if (!prop || !p0.focus || busy) return
    const old = p0.focus.sessions
    const used = new Set<number>()
    const full = (x: Focus['sessions'][number]) => `${x.type}|${x.part ?? ''}|${x.cardio ?? ''}|${x.min}|${x.day ?? '-'}`
    const loose = (x: Focus['sessions'][number]) => `${x.type}|${x.part ?? ''}`
    // ista vsebina: trener jo je vrnil enako (ali skoraj enako) — če jo je spremenil, je to sprememba, ki jo je želel
    const words = (t: string | null | undefined) => new Set((t || '').toLowerCase().split(/[^a-zčšžćđ0-9]+/).filter(w => w.length > 2))
    const same = (a: string | null | undefined, b: string | null | undefined) => { if (!a || !b) return true; const A = words(a), B = words(b); let n = 0; A.forEach(w => { if (B.has(w)) n++ }); return n / Math.max(1, new Set([...A, ...B]).size) >= 0.5 }
    const sessions = prop.focus.sessions.map(x => {
      let i = old.findIndex((o, j) => !used.has(j) && full(o) === full(x))
      // moč premaknjena na drug dan ali krajša: iste vaje ostanejo
      if (i < 0 && isStrength(x)) i = old.findIndex((o, j) => !used.has(j) && loose(o) === loose(x))
      if (i < 0) return x
      const o = old[i]!
      if (isStrength(x) && !same(x.what, o.what)) return x
      used.add(i)
      return isStrength(x)
        ? { ...x, ex: x.ex ?? o.ex ?? null, plan: x.plan ?? o.plan ?? null, what: o.what || x.what || null, why: o.why || x.why || null }
        : { ...x, what: x.what || o.what || null, why: x.why || o.why || null }
    })
    const final: Focus = { ...prop.focus, sessions, strategy: prop.focus.strategy ?? p0.focus.strategy ?? null }
    // nova vadba moči brez vaj in trener je na voljo: sestavljanje (trener izbere vaje in serije)
    if (claudeOn && prop.focus.by === 'claude' && sessions.some(x => isStrength(x) && !x.plan?.length && !x.ex?.length)) { setProp({ ...prop, focus: final }); setStep('gradnja'); return }
    setBusy('Posodabljam načrt …')
    try {
      await save(final)
      toast('Načrt je posodobljen — ostalo je ostalo, kot je bilo.', 'ok', 5000)
      done()
    } catch {
      setBusy(null)
      toast('Načrta ni bilo mogoče shraniti. Poskusi znova.', 'err', 6000)
    }
  }

  const back = () => {
    if (busy) return
    if (step === 'dogovor') setStep(qs ? 'vprasanja' : 'zelja')
    else if (step === 'vprasanja') setStep('zelja')
    else if (again) navigate('nastavitve')
    else navigate('')
  }
  const stepIx = step === 'zelja' ? 1 : step === 'vprasanja' ? 2 : 3
  const sexOk = !!b.sex
  const anyPick = Object.values(picks).some(a => a.length > 0)
  const wishOk = claudeOn ? anyPick || imgs.length > 0 || text.trim().length >= 3 : anyPick || text.trim().length >= 8
  const availOk = claudeOn || avail.length >= 2
  async function addImages(files: FileList | null) {
    if (!files?.length) return
    const out: typeof imgs = []
    for (const f of [...files].slice(0, 3 - imgs.length)) {
      try { const r = await fileToBase64Resized(f, 1024, 0.82); out.push(r) } catch (e) { toast((e as Error).message || 'Slike ni bilo mogoče dodati.', 'err') }
    }
    setImgs(x => [...x, ...out].slice(0, 3))
  }
  const toggleAvail = (d: number) => setAvail(a => (a.includes(d) ? a.filter(x => x !== d) : [...a, d].sort((x, y) => x - y)))
  const togglePick = (g: string, o: string) => setPicks(p => {
    const single = CHOICE_GROUPS.find(x => x.id === g)?.single
    const cur = p[g] || []
    // »Še ne vem« izključi športe in obratno
    const next = cur.includes(o) ? cur.filter(x => x !== o) : single ? [o] : g === 'delam' ? (o === 'Še ne vem' ? [o] : [...cur.filter(x => x !== 'Še ne vem'), o]) : [...cur, o]
    return { ...p, [g]: next }
  })

  const pickGroups = (
    <div className="pick-groups">
      {visibleGroups(picks).map(g => (
        <div key={g.id} className="pick-g" role="group" aria-labelledby={`pg-${g.id}`}>
          <div id={`pg-${g.id}`} className="pick-l">{g.label}</div>
          <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>{g.opts.map(o => <Chip key={o} sm on={!!picks[g.id]?.includes(o)} onClick={() => togglePick(g.id, o)}>{o}</Chip>)}</div>
        </div>
      ))}
    </div>
  )

  if (step === 'gradnja' && prop) {
    return (
      <Suspense fallback={<div className="ob" />}>
        <BuildShow focus={prop.focus} basics={basics} ai={!noAi} claude={prop.focus.by === 'claude' ? ctxOf({ qa: qaAll, history: saidSoFar(), current: again ? p0.focus : null }) : null} onSave={save} onDone={done} />
      </Suspense>
    )
  }

  return (
    <main className="ob sest" ref={top}>
      <div className="between" style={{ marginBottom: 14, minHeight: 34 }}>
        <button className="avatar" style={{ background: 'transparent', width: 40, height: 40 }} onClick={back} aria-label="Nazaj"><IcoBack /></button>
        {!again && !app.user && step === 'zelja'
          ? <button className="chip sm click" onClick={() => navigate('prijava')}>Že imam račun</button>
          : <div className="muted" style={{ fontSize: 12, fontWeight: 700 }}>{stepIx} / 3</div>}
      </div>
      <Progress pct={(stepIx / 3) * 100} />

      {step === 'zelja' && (<>
        {/* naslov koraka je h1 zaslona (v3.48), videz h2 */}
        <h1 className="h2">{again ? 'Kaj bi spremenil?' : 'Kaj si želiš?'}</h1>
        {again && p0.focus && (<>
          <div className="card tight sest-quick" style={{ marginTop: 12 }}>
            <b style={{ fontSize: 14 }}>Samo manjša sprememba</b>
            <p className="muted" style={{ fontSize: 12.5, marginTop: 2 }}>Napiši, kaj naj trener spremeni — vse ostalo ostane, kot je. Brez novih vprašanj.</p>
            <div className={`meal-text${quickDict.listening ? ' live' : ''}`} style={{ marginTop: 8 }}>
              <label htmlFor="sest-quick" className="sr-only">Kaj naj trener spremeni</label>
              <textarea id="sest-quick" ref={quickRef} rows={2} value={quick} maxLength={600} onChange={e => setQuick(e.target.value)} placeholder={quickDict.listening ? 'Poslušam …' : 'npr. V četrtek namesto teka kolo. Sobotna vožnja naj bo 2 h.'} style={{ paddingRight: 52 }} />
              {quickDict.canSpeak && <button type="button" className={`mic${quickDict.listening ? ' on' : ''}`} onClick={quickDict.toggle} aria-pressed={quickDict.listening} aria-label={quickDict.listening ? 'Ustavi narekovanje' : 'Povej, kaj naj trener spremeni'}><IcoMic width={18} height={18} /></button>}
            </div>
            <ListenBar listening={quickDict.listening} onStop={quickDict.stop} value={quick} transcribing={quickDict.transcribing} level={quickDict.level} />
            {quickMode && (think ? <div style={{ marginTop: 10 }}><ThinkCard t={think} /></div> : busy && <div style={{ marginTop: 10 }}><Thinking label={busy} /></div>)}
            {quickMode && claudeFail && <ClaudeFailCard f={claudeFail} />}
            <Btn primary block disabled={!quick.trim() || !!busy} style={{ marginTop: 10 }} onClick={() => void quickChange()}>Spremeni samo to</Btn>
          </div>
          <p className="sest-or" role="separator">ali sestavi nov dogovor od začetka</p>
        </>)}
        {claudeOn
          ? <p style={{ marginTop: 7, fontSize: 14 }}>Povej po svoje — kaj želiš doseči, kaj rad delaš, kdaj imaš čas, karkoli ti je pomembno. Lahko dodaš sliko (npr. postavo, ki si jo želiš). Trener te potem vpraša, kar še rabi.</p>
          : <p style={{ marginTop: 7, fontSize: 14 }}>Izberi, kar velja zate, ali povej po svoje. Trener te potem vpraša, kar še rabi — in skupaj se dogovorita za teden.</p>}
        {!claudeOn && pickGroups}
        <label htmlFor="sest-wish" className="pick-l" style={{ display: 'block', marginTop: claudeOn ? 16 : 18 }}>{claudeOn ? 'Povej po svoje' : <>Po svoje <span className="muted" style={{ fontWeight: 600 }}>(neobvezno)</span></>}</label>
        <div className={`meal-text${wishDict.listening ? ' live' : ''}`} style={{ marginTop: 6 }}>
          <textarea id="sest-wish" ref={wishRef} rows={claudeOn ? 5 : 3} value={text} maxLength={claudeOn ? 3000 : 700} onChange={e => setText(e.target.value)} style={{ minHeight: claudeOn ? 140 : 92 }}
            placeholder={wishDict.listening ? 'Poslušam …' : claudeOn ? 'npr. Rad bi bil vitek in močan, six pack. Fitnes v ponedeljek in petek, po fitnesu kratek tek, ob vikendih kolo. Ob sredah ne morem.' : 'npr. Ob torkih nimam časa. Do poletja 5 kg manj, a brez izgube moči.'} />
          {wishDict.canSpeak && <button type="button" className={`mic${wishDict.listening ? ' on' : ''}`} style={{ top: 26 }} onClick={wishDict.toggle} aria-pressed={wishDict.listening} aria-label={wishDict.listening ? 'Ustavi narekovanje' : 'Povej, kaj si želiš'}><IcoMic width={18} height={18} /></button>}
        </div>
        <ListenBar listening={wishDict.listening} onStop={wishDict.stop} value={text} transcribing={wishDict.transcribing} level={wishDict.level} />
        {claudeOn && (
          <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap', alignItems: 'center' }}>
            {imgs.map((im, i) => (
              <span key={i} className="sest-img"><img src={im.thumb} alt={`Priložena slika ${i + 1}`} width={56} height={56} /><button type="button" onClick={() => setImgs(x => x.filter((_, j) => j !== i))} aria-label={`Odstrani sliko ${i + 1}`}>×</button></span>
            ))}
            {imgs.length < 3 && <label className="chip sm click sest-addimg"><IcoImage width={14} height={14} aria-hidden="true" /> Dodaj sliko<input type="file" accept="image/*" multiple onChange={e => { void addImages(e.target.files); e.target.value = '' }} /></label>}
            <span className="muted" style={{ fontSize: 11.5 }}>npr. postava, ki si jo želiš</span>
          </div>
        )}
        {claudeOn && <details className="sest-more"><summary>Hitre izbire <span className="muted">(neobvezno)</span></summary>{pickGroups}</details>}
        <div className="card tight" style={{ marginTop: 16 }}>
          <b style={{ fontSize: 13.5 }}>Kdaj imaš čas za vadbo?{claudeOn && <span className="muted" style={{ fontWeight: 600 }}> (neobvezno)</span>}</b>
          <p className="muted" style={{ fontSize: 12, marginTop: 2 }}>Tapni dneve, ko realno lahko treniraš. Trener načrtuje samo nanje — in tako, da je med težkimi vadbami dan premora.</p>
          <div className="wk-pick" role="group" aria-label="Dnevi, ko imaš čas" style={{ marginTop: 10 }}>
            {DAY_OPTS.map((d, i) => <button key={d} type="button" className={`wk-d${avail.includes(i) ? ' on pin' : ''}`} aria-pressed={avail.includes(i)} aria-label={`${DAY_NAME[i]}: ${avail.includes(i) ? 'imam čas' : 'nimam časa'}`} style={avail.includes(i) ? { ['--c' as string]: 'var(--accent-fg)' } : undefined} onClick={() => toggleAvail(i)}><small>{d}</small><span className="wk-i" aria-hidden="true">{avail.includes(i) ? '✓' : '·'}</span></button>)}
          </div>
          <div className="row" style={{ gap: 6, marginTop: 8, flexWrap: 'wrap', alignItems: 'center' }}>
            <button type="button" className="chip sm click" onClick={() => setAvail(avail.length === 7 ? [] : [0, 1, 2, 3, 4, 5, 6])}>{avail.length === 7 ? 'počisti' : 'vsak dan'}</button>
            <span className="muted" style={{ fontSize: 12 }}>{avail.length ? `${avail.length} ${avail.length === 1 ? 'dan' : avail.length === 2 ? 'dneva' : avail.length <= 4 ? 'dnevi' : 'dni'} na teden` : claudeOn ? 'lahko tudi poveš ali te trener vpraša' : 'izberi vsaj dva dneva'}</span>
          </div>
          <div className="row" style={{ gap: 6, marginTop: 10, flexWrap: 'wrap', alignItems: 'center' }} role="group" aria-label="Kdaj čez dan">
            <span className="muted" style={{ fontSize: 12, fontWeight: 700 }}>Običajno:</span>
            {([['zjutraj', 'zjutraj'], ['popoldne', 'čez dan'], ['zvecer', 'zvečer'], [null, 'različno']] as const).map(([v, l]) => <Chip key={l} sm on={trainTime === v} onClick={() => setTrainTime(v)}>{l}</Chip>)}
          </div>
          {both && <div className="row" style={{ gap: 6, marginTop: 8, flexWrap: 'wrap', alignItems: 'center' }} role="group" aria-label="Kaj ti je glavno">
            <span className="muted" style={{ fontSize: 12, fontWeight: 700 }}>Glavno:</span>
            {([['kardio', 'bolj kardio'], ['oboje', 'oboje enako'], ['moc', 'bolj moč']] as const).map(([v, l]) => <Chip key={v} sm on={main === v} onClick={() => setMain(v)}>{l}</Chip>)}
          </div>}
          <div className="row" style={{ gap: 6, marginTop: 8, flexWrap: 'wrap', alignItems: 'center' }} role="group" aria-label="Kakšen tip si">
            <span className="muted" style={{ fontSize: 12, fontWeight: 700 }}>Kakšen tip si:</span>
            {([['lahko', 'raje lažje'], ['zmerno', 'zmerno'], ['trdo', 'raje trdo']] as const).map(([v, l]) => <Chip key={v} sm on={push === v} onClick={() => setPush(v)}>{l}</Chip>)}
          </div>
        </div>
        <div className="card tight" style={{ marginTop: 12 }}>
          <b style={{ fontSize: 13.5 }}>O tebi</b>
          <p className="muted" style={{ fontSize: 12, marginTop: 2 }}>Za realen načrt in kalorije. Ostane v aplikaciji; AI dobi samo številke, brez imena.</p>
          <div className="row" style={{ gap: 7, marginTop: 10 }}>{([['m', 'Moški'], ['z', 'Ženska']] as const).map(([v, l]) => <Chip key={v} sm on={b.sex === v} onClick={() => setB({ ...b, sex: v })}>{l}</Chip>)}</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, marginTop: 10 }}>
            <div className="field"><label htmlFor="s-age">Starost</label><input id="s-age" type="number" inputMode="numeric" min={12} max={99} value={b.age} onChange={e => setB({ ...b, age: e.target.value })} {...bFx('age')} /></div>
            <div className="field"><label htmlFor="s-h">Višina <span className="unit">cm</span></label><input id="s-h" type="number" inputMode="numeric" min={120} max={230} value={b.height} onChange={e => setB({ ...b, height: e.target.value })} {...bFx('height')} /></div>
            <div className="field"><label htmlFor="s-w">Teža <span className="unit">kg</span></label><DecimalInput id="s-w" min={30} max={250} step={0.1} value={b.weight} onChange={e => setB({ ...b, weight: e.target.value })} {...bFx('weight')} /></div>
          </div>
          {bShown.length > 0 && <div id="s-err" role="alert" style={{ fontSize: 12, color: 'var(--warn)', marginTop: 8, lineHeight: 1.45 }}>{bShown.map(k => bErr[k]).join(' ')}</div>}
          {basics.age != null && basics.age < 18 && <p style={{ fontSize: 12, marginTop: 8 }}>Do 18. leta ne načrtujem hujšanja — kalorije so vedno za vzdrževanje.</p>}
        </div>
        {declined && (
          <div className="card tight" role="status" style={{ marginTop: 12 }}>
            <p style={{ fontSize: 13 }}>Pogovor s trenerjem teče prek AI — za to se prijaviš z Googlom in dovoliš obdelavo. Raje brez tega? Spodaj izberi vprašalnik brez AI: vprašanja so stalna, načrt je še vedno po tvojih odgovorih.</p>
          </div>
        )}
        {!quickMode && (think ? <div style={{ marginTop: 12 }}><ThinkCard t={think} /></div> : busy && <div style={{ marginTop: 12 }}><Thinking label={busy} /></div>)}
        {!quickMode && claudeFail && <ClaudeFailCard f={claudeFail} />}
        <div className="grow" style={{ minHeight: 18 }} />
        <Btn primary block disabled={!wishOk || !availOk || !!busy || bShown.length > 0} onClick={() => goQuestions()}><IcoSpark width={17} height={17} /> {busy ? 'Trener razmišlja …' : 'Naprej'}</Btn>
        {bShown.length > 0 && <p className="muted" style={{ fontSize: 11.5, marginTop: 6, textAlign: 'center' }}>Popravi številko pri »O tebi« ali polje izprazni — izpolniš lahko tudi pozneje.</p>}
        {!wishOk && <p className="muted" style={{ fontSize: 11.5, marginTop: 6, textAlign: 'center' }}>Izberi kaj zgoraj ali napiši, kaj želiš.</p>}
        {wishOk && !availOk && <p className="muted" style={{ fontSize: 11.5, marginTop: 6, textAlign: 'center' }}>Tapni vsaj dva dneva, ko imaš čas — brez tega trener ne more narediti realnega tedna.</p>}
        {!sexOk && wishOk && <p className="muted" style={{ fontSize: 11.5, marginTop: 6, textAlign: 'center' }}>Brez spola in teže kalorij ne pokažem — izpolniš lahko tudi pozneje.</p>}
        {!app.user && <button type="button" className="ob-fb" style={{ marginTop: 8 }} disabled={!wishOk || !availOk || !!busy || bShown.length > 0} onClick={() => goQuestions(true)}>Raje brez prijave (vprašalnik brez AI)</button>}
      </>)}

      {step === 'vprasanja' && qs && (<>
        <h1 className="h2">{round === 1 ? 'Še nekaj vprašanj' : 'Samo še to'}</h1>
        {noAi && <p className="muted" style={{ fontSize: 12, marginTop: 8 }}>{byRules ? 'Vprašalnik brez AI — načrt bo po tvojih odgovorih.' : `AI se trenutno ne odziva${aiWhy ? ` (${aiWhy.replace(/\.$/, '')})` : ''} — vprašanja so iz vprašalnika, načrt bo vseeno po tvojih odgovorih.`}</p>}
        <div className="stack chat" style={{ marginTop: 12, gap: 8 }}>
          {hist.map((x, i) => <Fragment key={`h${i}`}><div className="talk">{i === 0 && <span className="talk-who">Trener</span>}{x.q}</div><div className="talk me">{x.a}</div></Fragment>)}
          {qs.understood && <div className="talk"><span className="talk-who">Trener</span>{qs.understood}</div>}
          {qs.questions.slice(0, curIx < 0 ? qs.questions.length : curIx + 1).map((q, i) => {
            const a = ans[q.id] || { picks: [], text: '' }
            const who = i === 0 && !qs.understood && !hist.length
            const cur = i === curIx
            // vprašanje ostane isti element (se ne pojavi znova), pod njim izbire ali tvoj odgovor
            return (
              <Fragment key={q.id}>
                <div className="talk" id={`qt-${q.id}`}>{who && <span className="talk-who">Trener</span>}{q.text}{cur && q.multi && <span className="q-hint"> · lahko izbereš več</span>}</div>
                {cur ? (
                  <div className="q-turn" ref={curRef} tabIndex={-1} role="group" aria-labelledby={`qt-${q.id}`}>
                    <div className="q-opts">{q.options.map(o => <Chip key={o} sm on={a.picks.includes(o)} onClick={() => pick(q, o)}>{o}</Chip>)}</div>
                    {q.other && (
                      <div className="q-own">
                        <input className="q-other" value={a.text} maxLength={160} enterKeyHint="send" onChange={e => setAns({ ...ans, [q.id]: { ...a, text: e.target.value } })}
                          onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); commit(q) } }} placeholder={q.options.length ? 'ali napiši po svoje' : 'napiši odgovor'} aria-label={`${q.text} — svoj odgovor`} />
                      </div>
                    )}
                    {(q.multi || a.text.trim().length > 0) && <Btn primary sm disabled={!answerOf(ans, q) || !!busy} style={{ marginTop: 2 }} onClick={() => commit(q)}>Naprej ›</Btn>}
                  </div>
                ) : (
                  <button type="button" className="talk me q-ans" disabled={!!busy} onClick={() => reopen(q.id)} aria-label={`Tvoj odgovor: ${answerOf(ans, q)}. Tapni, da ga spremeniš.`}>{answerOf(ans, q)}</button>
                )}
              </Fragment>
            )
          })}
          {think ? <ThinkCard t={think} /> : busy && <Thinking label={busy} />}
          {claudeFail && <ClaudeFailCard f={claudeFail} />}
        </div>
        <div className="grow" style={{ minHeight: 18 }} />
        {curIx < 0 && !busy && <Btn primary block style={{ marginTop: 16 }} onClick={() => (prop ? setStep('dogovor') : void submitAnswers())}>{prop ? 'Nazaj na predlog' : 'Naprej'}</Btn>}
      </>)}

      {step === 'dogovor' && prop && (<>
        <h1 className="h2">Najin dogovor</h1>
        <div className="stack" style={{ marginTop: 12, gap: 8 }}>
          {talk.slice(-5).map((t, i) => <div key={i} className={`talk${t.who === 'ti' ? ' me' : ''}`}>{t.who === 'trener' && <span className="talk-who">Trener</span>}{t.text}</div>)}
          {think ? <ThinkCard t={think} /> : busy && <Thinking label={busy} />}
          {claudeFail && <ClaudeFailCard f={claudeFail} />}
        </div>
        <Deal f={prop.focus} onDay={busy ? undefined : toggleDay} note={dayNote} byLabel={claudeOn ? (prop.focus.by === 'claude' ? 'sestavil Claude' : prop.focus.by === 'ai' ? 'sestavil Gemini' : 'po pravilih') : null} />
        {again && <p className="muted" style={{ fontSize: 12, marginTop: 8 }}>Nov dogovor zamenja tvoj sedanji načrt od danes naprej. Opravljeni treningi ostanejo.</p>}
        <p className="muted" style={{ fontSize: 12.5, marginTop: 14 }}>Ti odločaš. Kaj bi spremenil?</p>
        <div className="row" style={{ gap: 6, flexWrap: 'wrap', marginTop: 8 }}>
          {retry && <button type="button" className="chip sm click on" disabled={!!busy} onClick={() => void propose(qaAll, retry)}>↻ Poskusi znova z AI</button>}
          {(prop.quick.length ? prop.quick : ['Več kardia', 'Več moči', 'Manj dni', 'Krajše vadbe']).map(x => <button key={x} type="button" className="chip sm click" disabled={!!busy} onClick={() => void propose(qaAll, x)}>{x}</button>)}
        </div>
        <div className={`meal-text${sayDict.listening ? ' live' : ''}`}>
          <label htmlFor="sest-say" className="sr-only">Kaj bi spremenil</label>
          <textarea id="sest-say" ref={sayRef} rows={2} value={say} maxLength={400} onChange={e => setSay(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); if (say.trim() && !busy) { sayDict.stop(); void propose(qaAll, say.trim()) } } }} enterKeyHint="send" placeholder={sayDict.listening ? 'Poslušam …' : 'npr. raje 4 dni, več teka, brez nog'} style={{ paddingRight: 96 }} />
          {sayDict.canSpeak && <button type="button" className={`mic${sayDict.listening ? ' on' : ''}`} style={{ right: 52 }} onClick={sayDict.toggle} aria-pressed={sayDict.listening} aria-label={sayDict.listening ? 'Ustavi narekovanje' : 'Povej, kaj bi spremenil'}><IcoMic width={18} height={18} /></button>}
          <button type="button" className="mic send" disabled={!say.trim() || !!busy} onClick={() => { sayDict.stop(); void propose(qaAll, say.trim()) }} aria-label="Pošlji trenerju">→</button>
        </div>
        <ListenBar listening={sayDict.listening} onStop={sayDict.stop} value={say} transcribing={sayDict.transcribing} level={sayDict.level} />
        <div className="grow" style={{ minHeight: 18 }} />
        <Btn primary block disabled={!!busy} style={{ marginTop: 16 }} onClick={() => { if (say.trim()) { sayDict.stop(); void propose(qaAll, say.trim()) } else if (quickMode) void applyQuick(); else setStep('gradnja') }}>{say.trim() ? 'Pošlji spremembo' : quickMode ? 'Dogovorjeno — posodobi načrt' : 'Dogovorjeno — sestavi moj načrt'}</Btn>
      </>)}

      <button type="button" className="ob-fb" onClick={() => void startFeedback()}>Nekaj ni jasno? Pošlji pripombo</button>
      {ai.sheet}
    </main>
  )
}

/** Trener razmišlja: po 8 s še pretečeni čas (Claude premišlja do 2 min — da se vidi, da dela). */
/**
 * Česa aplikacija ne zna (trener bi rad): enkrat na napravo gre med pripombe kot »predlog« — razvijalec (in Claude
 * pri popravkih) vidi, kaj manjka. Brez uporabnikovih besed in podatkov — samo trenerjev splošen opis.
 */
async function reportMissing(items: readonly string[]) {
  const KEY = 'formai.ne-zna'
  let seen: string[] = []
  try { seen = JSON.parse(localStorage.getItem(KEY) || '[]') as string[] } catch { seen = [] }
  const fresh = items.filter(x => !seen.includes(x))
  if (!fresh.length) return
  try {
    const f = await makeFeedback({ kind: 'predlog', text: `[Claude trener — aplikacija tega ne zna]\n${fresh.map(x => `– ${x}`).join('\n')}`, shot: null, route: 'dogovor' })
    await sendFeedback(f)
    localStorage.setItem(KEY, JSON.stringify([...seen, ...fresh].slice(-60)))
  } catch { /* gre ob naslednji priložnosti */ }
}

/** Claude ni odgovoril: uporabnik izbere — znova s Claudom ali naprej z Gemini (nikoli tiho). */
function ClaudeFailCard({ f }: { f: { why: string; retry: () => void; gemini: () => void } }) {
  return (
    <div className="card tight claude-fail" role="alert">
      <b style={{ fontSize: 14 }}>Claude tokrat ni odgovoril</b>
      <p style={{ fontSize: 12.5, marginTop: 4 }}>{f.why.replace(/\.?$/, '.')} Lahko poskusiš znova — ali nadaljuješ z Gemini (hitreje, a manj premišljeno).</p>
      <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
        <Btn primary sm onClick={f.retry}>Poskusi znova s Claudom</Btn>
        <Btn ghost sm onClick={f.gemini}>Nadaljuj z Gemini</Btn>
      </div>
    </div>
  )
}

function Thinking({ label }: { label: string }) {
  const [sec, setSec] = useState(0)
  useEffect(() => {
    setSec(0)
    const t0 = Date.now()
    const id = window.setInterval(() => setSec(Math.floor((Date.now() - t0) / 1000)), 1000)
    return () => clearInterval(id)
  }, [label])
  return <div className="talk think" role="status" aria-live="polite"><span className="talk-who">Trener</span>{label}<span className="thinking" aria-hidden="true"><i /><i /><i /></span>{sec >= 8 ? <span className="think-t" aria-hidden="true">{Math.floor(sec / 60)}:{String(sec % 60).padStart(2, '0')}</span> : null}</div>
}

/** Odgovor trenerja omenja dan, ki ga v dogovoru ni (ne kot določen dan ne kot dan brez časa). */
function replyDaysOff(reply: string, f: Focus): boolean {
  const have = new Set<number>([...f.sessions.map(s => s.day).filter((d): d is number => d != null), ...(f.offDays || [])])
  return daysIn(reply).some(d => !have.has(d))
}
/** Ali se dnevi (določene seje, dnevi brez časa) med dvema dogovoroma razlikujejo. */
function daysDiffer(a: Focus, b: Focus): boolean {
  const k = (f: Focus) => [...f.sessions.map(s => `${s.type}:${s.day ?? '-'}`).sort(), 'off:' + (f.offDays || []).join(','), 'n:' + trainingDays(f.sessions)].join('|')
  return k(a) !== k(b)
}

/** (v3.48) Kolesarski načrt v dogovoru: prvi teden iz sestavljalnika (prej dogovorjene seje »pon intervali · sre tempo«, ki jih načrt ni imel). */
function BikeWeek({ f }: { f: Focus }) {
  const app = useApp()
  const w = useMemo(() => firstBikeWeek(f, app.profile, app.activities, app.today, app.checkins, app.weather), [f, app.profile, app.activities, app.today, app.checkins, app.weather])
  const days = Array.from({ length: 7 }, (_, i) => addDays(w.weekStart, i))
  return (
    <div className="deal-wk">
      <div className="h4" style={{ fontSize: 10.5, margin: '0 0 8px' }}>{w.weekStart === weekStartIso(app.today) ? 'Ta teden' : `Prvi teden · od ${dm(w.weekStart)}`} · {fmtDur(weekMinutes(w.days))}</div>
      <WeekRibbon days={days} items={w.days} today={app.today} focus="" label="Prvi teden načrta" />
      <p className="muted" style={{ fontSize: 12, marginTop: 4 }}>{w.event ? 'Kolesarski načrt do tekme: faze, vati in teden dirke.' : 'Kolesarski načrt v 12-tedenskih ciklih. Ko dodaš tekmo z datumom, se ji prilagodi.'}{w.easy ? ' Prvi trije tedni so lahki.' : ''}{f.offDays?.length ? ' Dnevi, ko nimaš časa, ostanejo prosti.' : ''} Trening premakneš v Planu.</p>
    </div>
  )
}

/** Predlog tedna: ime, teden, cilji, seje (kardio isti dan pod močjo), razpored po dnevih (tap = ta dan nimam časa), pojasnila. */
export function Deal({ f, onDay, note, byLabel }: { f: Focus; onDay?: (d: number) => void; note?: string | null; /** kdo je sestavil (vidi uporabnik s Claude trenerjem) */ byLabel?: string | null }) {
  const notes = useMemo(() => f.notes.slice(0, f.by === 'claude' ? 10 : 4), [f.notes, f.by])
  return (
    <div className="card deal" style={{ marginTop: 14 }}>
      <div className="between"><div className="h4">Predlog</div>{byLabel && <span className={`chip sm${f.by === 'claude' ? ' on' : ''}`}>{byLabel}</span>}</div>
      <h2 style={{ fontSize: 20, marginTop: 4, letterSpacing: '-.02em', lineHeight: 1.5 }}>{f.title}</h2>
      {/* kolesarski načrt (s tekmo) ne sledi dogovorjenim sejam: namesto njih teden, ki ga bo načrt res imel (v3.48) */}
      <p style={{ fontSize: 13, marginTop: 4 }}>{usesAgreement(f) ? weekLine(f) : weekLine(f).split(' · ')[1]}{f.aims.length || f.muscles.length ? ` · ${aimsLine(f)}` : ''}</p>
      {usesAgreement(f) ? (<>
        <SessionList f={f} />
        <WeekStrip f={f} onDay={onDay} busy={!onDay} note={note ? <><b>Trener:</b> {note}</> : undefined} />
      </>) : <BikeWeek f={f} />}
      {usesAgreement(f) && f.why && f.why.length > 0 && (
        <div className="deal-why">
          <div className="h4" style={{ fontSize: 10.5, margin: '12px 0 4px' }}>Zakaj tako</div>
          <ul className="deal-notes" style={{ marginTop: 0 }}>{f.why.map((n, i) => <li key={i}>{n}</li>)}</ul>
        </div>
      )}
      {notes.length > 0 && <ul className="deal-notes">{notes.map((n, i) => <li key={i}>{n}</li>)}</ul>}
    </div>
  )
}
