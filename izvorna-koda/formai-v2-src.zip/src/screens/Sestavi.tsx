import { Fragment, lazy, Suspense, useEffect, useMemo, useRef, useState } from 'react'
import { navigate } from '@/app/router'
import { markApp } from '@/app/landing'
import { useApp, getState, applyAgreement } from '@/state/store'
import { useAi } from '@/ui/useAi'
import { askJson } from '@/domain/ai/client'
import { questionsPrompt, parseQuestions, proposalPrompt, parseProposal, type QA, type QuestionsOut, type ProposalOut, type Basics, type AiQuestion } from '@/domain/ai/focusAi'
import { ruleQuestions, ruleProposal, ruleAdjust } from '@/domain/focus/rules'
import { CHOICE_GROUPS, composeWish, splitWish, DAY_AT, DAY_NAME, DAY_OPTS, type Picks } from '@/domain/focus/choices'
import { SPORT_LABEL, PART_NAME, CARDIO_LABEL, weekLine, aimsLine, normalizeFocus } from '@/domain/focus/model'
import { scheduleWeek } from '@/domain/training/focusPlan'
import type { AgreedSession, Focus } from '@/domain/types'
import { useDictation } from '@/ui/useDictation'
import { Btn, Chip, DecimalInput, Progress } from '@/ui/primitives'
import { IcoBack, IcoMic, IcoDumbbell, IcoRun, IcoBike, IcoMap, IcoHome, IcoSpark } from '@/ui/icons'
import { startFeedback } from '@/ui/HelpSheet'
import { toast } from '@/state/store'

const BuildShow = lazy(() => import('@/ui/BuildShow').then(m => ({ default: m.BuildShow })))

/**
 * SESTAVIVA TVOJ NAČRT (Blaž, 7. 10.): uporabnik izbere in/ali pove s svojimi besedami, kaj želi (besedilo ali glas),
 * AI vpraša naprej — vsakič nova vprašanja iz tega, kar je rekel, eno za drugim z izbirami kot v pogovoru — nato
 * predlaga realen teden in se z njim pogaja (več, manj, drugače, dnevi brez časa). Ko sta dogovorjena, se aplikacija
 * pred njim sestavi (BuildShow). Brez AI (napaka, limit) gre naprej po pravilih.
 */
type Step = 'zelja' | 'vprasanja' | 'dogovor' | 'gradnja'
type Ans = Record<string, { picks: string[]; text: string }>
const answerOf = (a: Ans, q: AiQuestion) => [...(a[q.id]?.picks || []), a[q.id]?.text.trim() || ''].filter(Boolean).join(', ')
const num = (v: string, lo: number, hi: number) => { const x = +v.replace(',', '.'); return v.trim() !== '' && Number.isFinite(x) && x >= lo && x <= hi ? x : null }

export function sessionColor(s: Pick<AgreedSession, 'type'>): string {
  return s.type === 'fitnes' || s.type === 'doma' ? 'var(--t-moc)' : s.type === 'kolo' ? 'var(--t-kolo)' : 'var(--t-tek)'
}
export function SessionIcon({ s, size = 17 }: { s: Pick<AgreedSession, 'type'>; size?: number }) {
  const p = { width: size, height: size, 'aria-hidden': true }
  return s.type === 'fitnes' ? <IcoDumbbell {...p} /> : s.type === 'doma' ? <IcoHome {...p} /> : s.type === 'kolo' ? <IcoBike {...p} /> : s.type === 'hribi' ? <IcoMap {...p} /> : <IcoRun {...p} />
}
const what = (s: AgreedSession) => (s.part ? PART_NAME[s.part] : s.cardio ? CARDIO_LABEL[s.cardio] : '')
const sessName = (s: AgreedSession) => `${SPORT_LABEL[s.type]}${what(s) ? ` · ${what(s)}` : ''}`
const upper = (t: string) => t.charAt(0).toUpperCase() + t.slice(1)

export function Sestavi() {
  const app = useApp()
  const p0 = app.profile
  const ai = useAi()
  const again = p0.onboardingDone
  const [step, setStep] = useState<Step>('zelja')
  // izbire (kot pri Claudu) in svoje besede → ena želja za AI in vprašalnik
  const init = useMemo(() => splitWish(p0.focus?.wish || ''), []) // eslint-disable-line react-hooks/exhaustive-deps
  const [picks, setPicks] = useState<Picks>(init.picks)
  const [text, setText] = useState(init.text)
  const wish = composeWish(picks, text)
  const [b, setB] = useState(() => ({ sex: p0.sex, age: p0.age ? String(p0.age) : '', height: p0.heightCm ? String(p0.heightCm) : '', weight: p0.weightKg ? String(p0.weightKg) : '' }))
  const basics: Basics = { sex: b.sex, age: num(b.age, 12, 99), heightCm: num(b.height, 120, 230), weightKg: num(b.weight, 30, 250) }
  const [round, setRound] = useState<1 | 2>(1)
  const [qs, setQs] = useState<QuestionsOut | null>(null)
  const [ans, setAns] = useState<Ans>({})
  const [doneIds, setDoneIds] = useState<string[]>([])          // potrjeni odgovori v tem krogu (vprašanje za vprašanjem)
  const [hist, setHist] = useState<QA[]>([])              // prejšnji krogi
  const [qaAll, setQaAll] = useState<QA[]>([])            // vsi odgovori (za predlog in pogajanje)
  const [prop, setProp] = useState<ProposalOut | null>(null)
  const [base, setBase] = useState<Focus | null>(null)   // predlog pred spremembo dni (da se vadbe vrnejo, ko dan spet gre)
  const [dayNote, setDayNote] = useState<string | null>(null)
  const [talk, setTalk] = useState<{ who: 'ti' | 'trener'; text: string }[]>([])
  const [say, setSay] = useState('')
  const [busy, setBusy] = useState<string | null>(null)
  const [noAi, setNoAi] = useState(false)
  const [declined, setDeclined] = useState(false)
  const [byRules, setByRules] = useState(false)
  const top = useRef<HTMLDivElement>(null)
  const curRef = useRef<HTMLDivElement>(null)
  const wishDict = useDictation(text, setText, m => toast(m, 'err', 6000))
  const sayDict = useDictation(say, setSay, m => toast(m, 'err', 6000))
  useEffect(() => { window.scrollTo(0, 0) }, [step, round])
  const curIx = qs ? qs.questions.findIndex(q => !doneIds.includes(q.id)) : -1
  // naslednje vprašanje pride na vrsto: pokaži ga in nanj premakni fokus (bralnik zaslona ga prebere)
  useEffect(() => {
    const el = curRef.current
    if (step !== 'vprasanja' || curIx < 0 || !el || (curIx === 0 && round === 1)) return
    const calm = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
    el.scrollIntoView({ block: 'nearest', behavior: calm ? 'auto' : 'smooth' })
    el.focus({ preventScroll: true })
  }, [step, curIx, round])

  /** AI klic z vrati (prijava, privolitev). null = AI ni odgovoril (napaka, limit) → naprej po pravilih. */
  async function viaAi<T>(fn: () => Promise<T>): Promise<T | null> {
    if (noAi) return null
    const r = await ai.run(fn, { quiet: true })
    if (r !== undefined) return r
    setNoAi(true)
    return null
  }

  /** rules = kratek vprašalnik brez prijave in brez AI (vprašanja, predlog in sestava po pravilih). */
  async function startQuestions(rules = false) {
    setDeclined(false)
    setBusy('Berem tvoje želje …')
    let parsed: QuestionsOut | null = null
    let fallback = noAi || rules
    if (rules) setByRules(true)
    if (!fallback) {
      const r = await ai.run(() => askJson<unknown>(questionsPrompt({ wish, basics, qa: [], round: 1 })), { quiet: true })
      if (r === undefined) {
        const st = getState()
        // ni prijave ali privolitve: ostani tu in povej, kaj sta možnosti
        if (import.meta.env.VITE_E2E !== '1' && (!st.user || !st.profile.aiConsentAt)) { setBusy(null); setDeclined(true); return }
        fallback = true
      } else parsed = parseQuestions(r)
      if (!parsed || !parsed.questions.length) fallback = true
    }
    setBusy(null)
    if (fallback) setNoAi(true)
    setQs(!fallback && parsed ? parsed : ruleQuestions(wish)); setAns({}); setDoneIds([]); setRound(1); setHist([]); setQaAll([]); setStep('vprasanja')
  }

  /** Izbira pri vprašanju: ena možnost odgovori takoj, pri več možnostih potrdi »Naprej«. */
  function pick(q: AiQuestion, o: string) {
    if (busy) return
    const a = ans[q.id] || { picks: [], text: '' }
    const picksNow = q.multi ? (a.picks.includes(o) ? a.picks.filter(x => x !== o) : [...a.picks, o]) : [o]
    const next = { ...ans, [q.id]: { ...a, picks: picksNow } }
    setAns(next)
    if (!q.multi) commit(q, next)
  }
  function commit(q: AiQuestion, a: Ans = ans) {
    if (busy || !qs || !answerOf(a, q)) return
    const d = [...doneIds.filter(x => x !== q.id), q.id]
    setDoneIds(d)
    if (qs.questions.every(x => d.includes(x.id))) void submitAnswers(a)
  }
  /** tap na svoj odgovor: vprašanje spet odpre (ko odgovoriš, gre naprej od tam) */
  function reopen(id: string) { if (!busy) setDoneIds(d => d.filter(x => x !== id)) }

  async function submitAnswers(a: Ans = ans) {
    if (!qs) return
    const add: QA[] = qs.questions.map(q => ({ id: q.id, q: q.text, a: answerOf(a, q) }))
    const all = [...hist, ...add]
    setQaAll(all)
    if (round === 1 && !qs.enough && !noAi) {
      setBusy('Še nekaj bi rad vedel …')
      const r = await viaAi(() => askJson<unknown>(questionsPrompt({ wish, basics, qa: all, round: 2 })))
      const q2 = r ? parseQuestions(r) : null
      setBusy(null)
      if (q2 && q2.questions.length) { setHist(all); setQs(q2); setAns({}); setDoneIds([]); setRound(2); return }
    }
    await propose(all, null)
  }

  async function propose(all: QA[], feedback: string | null) {
    setBusy(feedback ? 'Popravljam predlog …' : 'Sestavljam predlog tedna …')
    if (feedback) setTalk(t => [...t, { who: 'ti', text: feedback }])
    const r = await viaAi(() => askJson<unknown>(proposalPrompt({ wish, basics, qa: all, prev: prop?.focus ?? null, feedback })))
    let next = r ? parseProposal(r, { wish, age: basics.age, prevOff: feedback ? prop?.focus.offDays : null }) : null
    if (!next) {
      if (feedback && prop) {
        const adj = ruleAdjust(prop.focus, feedback, basics.age)
        next = adj ? { reply: `Popravil sem: ${weekLine(adj)}.`, focus: adj, quick: prop.quick } : { ...prop, reply: 'Brez AI razumem samo hitre odgovore spodaj (več kardia, manj dni …).' }
      } else next = ruleProposal(wish, all, basics.age)
    }
    setBusy(null)
    setProp(next)
    setBase(null)
    setDayNote(null)
    setTalk(t => [...t, { who: 'trener', text: next!.reply }])
    setSay('')
    setStep('dogovor')
  }

  /** Dan brez časa (tap v tednu): vadbe gredo na druge dni; če jih je več kot dni, zadnja izpade (in se vrne, ko dan spet gre). */
  function toggleDay(d: number) {
    if (!prop || busy) return
    const from = base || prop.focus
    const cur = prop.focus.offDays || []
    const was = cur.includes(d)
    const off = was ? cur.filter(x => x !== d) : [...cur, d]
    if (off.length > 6) return
    const f = normalizeFocus({ ...from, offDays: off }, { age: basics.age, by: from.by, now: from.at })
    if (!f) return
    if (!base) setBase(prop.focus)
    const lost = prop.focus.sessions.slice(f.sessions.length), back = f.sessions.slice(prop.focus.sessions.length)
    setProp({ ...prop, focus: f })
    const reply = was
      ? `Prav — ${DAY_AT[d]} spet lahko.${back.length ? ` ${back.map(sessName).join(', ')} ${back.length === 1 ? 'je' : back.length === 2 ? 'sta' : 'so'} spet v tednu.` : ''}`
      : `Prav — ${DAY_AT[d]} ni vadbe.${lost.length ? ` Vse vadbe ne gredo več v teden, zato sem izpustil: ${lost.map(sessName).join(', ')}.` : ' Vadbe razporedim na druge dni.'}`
    // odgovor trenerja pod tednom (kjer je prst), ne v pogovoru zgoraj — da se kartica ne premakne
    setDayNote(reply)
  }

  async function save(final: Focus) {
    await applyAgreement(final, { sex: basics.sex ?? null, age: basics.age, heightCm: basics.heightCm, weightKg: basics.weightKg })
  }
  function done() {
    markApp()
    navigate('danes')
  }

  const back = () => {
    if (busy) return
    if (step === 'dogovor') setStep(qs ? 'vprasanja' : 'zelja')
    else if (step === 'vprasanja') setStep('zelja')
    else if (again) navigate('nastavitve')
    else navigate('')
  }
  const stepIx = step === 'zelja' ? 1 : step === 'vprasanja' ? 2 : 3
  const sexOk = !!b.sex
  const anyPick = Object.values(picks).some(a => a.length > 0)
  const wishOk = anyPick || text.trim().length >= 8
  const togglePick = (g: string, o: string) => setPicks(p => ({ ...p, [g]: p[g]?.includes(o) ? p[g]!.filter(x => x !== o) : [...(p[g] || []), o] }))

  if (step === 'gradnja' && prop) {
    return (
      <Suspense fallback={<div className="ob" />}>
        <BuildShow focus={prop.focus} basics={basics} ai={!noAi} onSave={save} onDone={done} />
      </Suspense>
    )
  }

  return (
    <main className="ob sest" ref={top}>
      <div className="between" style={{ marginBottom: 14, minHeight: 34 }}>
        <button className="avatar" style={{ background: 'transparent', width: 40, height: 40 }} onClick={back} aria-label="Nazaj"><IcoBack /></button>
        {!again && !app.user && step === 'zelja'
          ? <button className="chip sm click" onClick={() => navigate('prijava')}>Že imam račun</button>
          : <div className="muted" style={{ fontSize: 12, fontWeight: 700 }}>{stepIx} / 3</div>}
      </div>
      <Progress pct={(stepIx / 3) * 100} />

      {step === 'zelja' && (<>
        <h2>{again ? 'Kaj bi spremenil?' : 'Kaj si želiš?'}</h2>
        <p style={{ marginTop: 7, fontSize: 14 }}>Izberi, kar velja zate, ali povej po svoje. Trener te potem vpraša, kar še rabi — in skupaj se dogovorita za teden.</p>
        <div className="pick-groups">
          {CHOICE_GROUPS.map(g => (
            <div key={g.id} className="pick-g" role="group" aria-labelledby={`pg-${g.id}`}>
              <div id={`pg-${g.id}`} className="pick-l">{g.label}</div>
              <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>{g.opts.map(o => <Chip key={o} sm on={!!picks[g.id]?.includes(o)} onClick={() => togglePick(g.id, o)}>{o}</Chip>)}</div>
            </div>
          ))}
        </div>
        <label htmlFor="sest-wish" className="pick-l" style={{ display: 'block', marginTop: 18 }}>Po svoje <span className="muted" style={{ fontWeight: 600 }}>(neobvezno)</span></label>
        <div className={`meal-text${wishDict.listening ? ' live' : ''}`} style={{ marginTop: 6 }}>
          <textarea id="sest-wish" rows={3} value={text} maxLength={700} onChange={e => setText(e.target.value)} style={{ minHeight: 92, maxHeight: 220, overflowY: 'auto' }}
            placeholder={wishDict.listening ? 'Poslušam …' : 'npr. Ob torkih nimam časa. Do poletja 5 kg manj, a brez izgube moči.'} />
          {wishDict.canSpeak && <button type="button" className={`mic${wishDict.listening ? ' on' : ''}`} style={{ top: 26 }} onClick={wishDict.toggle} aria-pressed={wishDict.listening} aria-label={wishDict.listening ? 'Ustavi narekovanje' : 'Povej, kaj si želiš'}><IcoMic width={18} height={18} /></button>}
        </div>
        <div className="card tight" style={{ marginTop: 16 }}>
          <b style={{ fontSize: 13.5 }}>O tebi</b>
          <p className="muted" style={{ fontSize: 12, marginTop: 2 }}>Za realen načrt in kalorije. Ostane v aplikaciji; AI dobi samo številke, brez imena.</p>
          <div className="row" style={{ gap: 7, marginTop: 10 }}>{([['m', 'Moški'], ['z', 'Ženska']] as const).map(([v, l]) => <Chip key={v} sm on={b.sex === v} onClick={() => setB({ ...b, sex: v })}>{l}</Chip>)}</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, marginTop: 10 }}>
            <div className="field"><label htmlFor="s-age">Starost</label><input id="s-age" type="number" inputMode="numeric" value={b.age} onChange={e => setB({ ...b, age: e.target.value })} /></div>
            <div className="field"><label htmlFor="s-h">Višina <span className="unit">cm</span></label><input id="s-h" type="number" inputMode="numeric" value={b.height} onChange={e => setB({ ...b, height: e.target.value })} /></div>
            <div className="field"><label htmlFor="s-w">Teža <span className="unit">kg</span></label><DecimalInput id="s-w" min={30} max={250} step={0.1} value={b.weight} onChange={e => setB({ ...b, weight: e.target.value })} /></div>
          </div>
          {basics.age != null && basics.age < 18 && <p style={{ fontSize: 12, marginTop: 8 }}>Do 18. leta ne načrtujem hujšanja — kalorije so vedno za vzdrževanje.</p>}
        </div>
        {declined && (
          <div className="card tight" role="status" style={{ marginTop: 12 }}>
            <p style={{ fontSize: 13 }}>Pogovor s trenerjem teče prek AI — za to se prijaviš z Googlom in dovoliš obdelavo. Raje brez tega? Spodaj izberi vprašalnik brez AI: vprašanja so stalna, načrt je še vedno po tvojih odgovorih.</p>
          </div>
        )}
        {busy && <div style={{ marginTop: 12 }}><Thinking label={busy} /></div>}
        <div className="grow" style={{ minHeight: 18 }} />
        <Btn primary block disabled={!wishOk || !!busy} onClick={() => void startQuestions()}><IcoSpark width={17} height={17} /> {busy ? 'Trener razmišlja …' : 'Naprej'}</Btn>
        {!wishOk && <p className="muted" style={{ fontSize: 11.5, marginTop: 6, textAlign: 'center' }}>Izberi kaj zgoraj ali napiši, kaj želiš.</p>}
        {!sexOk && wishOk && <p className="muted" style={{ fontSize: 11.5, marginTop: 6, textAlign: 'center' }}>Brez spola in teže kalorij ne pokažem — izpolniš lahko tudi pozneje.</p>}
        {!app.user && <button type="button" className="ob-fb" style={{ marginTop: 8 }} disabled={!wishOk || !!busy} onClick={() => void startQuestions(true)}>Raje brez prijave (vprašalnik brez AI)</button>}
      </>)}

      {step === 'vprasanja' && qs && (<>
        <h2>{round === 1 ? 'Še nekaj vprašanj' : 'Samo še to'}</h2>
        {noAi && <p className="muted" style={{ fontSize: 12, marginTop: 8 }}>{byRules ? 'Vprašalnik brez AI — načrt bo po tvojih odgovorih.' : 'AI se trenutno ne odziva — vprašanja so iz vprašalnika, načrt bo vseeno po tvojih odgovorih.'}</p>}
        <div className="stack chat" style={{ marginTop: 12, gap: 8 }}>
          {hist.map((x, i) => <Fragment key={`h${i}`}><div className="talk">{i === 0 && <span className="talk-who">Trener</span>}{x.q}</div><div className="talk me">{x.a}</div></Fragment>)}
          {qs.understood && <div className="talk"><span className="talk-who">Trener</span>{qs.understood}</div>}
          {qs.questions.slice(0, curIx < 0 ? qs.questions.length : curIx + 1).map((q, i) => {
            const a = ans[q.id] || { picks: [], text: '' }
            const who = i === 0 && !qs.understood && !hist.length
            const cur = i === curIx
            // vprašanje ostane isti element (se ne pojavi znova), pod njim izbire ali tvoj odgovor
            return (
              <Fragment key={q.id}>
                <div className="talk" id={`qt-${q.id}`}>{who && <span className="talk-who">Trener</span>}{q.text}{cur && q.multi && <span className="q-hint"> · lahko izbereš več</span>}</div>
                {cur ? (
                  <div className="q-turn" ref={curRef} tabIndex={-1} role="group" aria-labelledby={`qt-${q.id}`}>
                    <div className="q-opts">{q.options.map(o => <Chip key={o} sm on={a.picks.includes(o)} onClick={() => pick(q, o)}>{o}</Chip>)}</div>
                    {q.other && (
                      <div className="q-own">
                        <input className="q-other" value={a.text} maxLength={160} enterKeyHint="send" onChange={e => setAns({ ...ans, [q.id]: { ...a, text: e.target.value } })}
                          onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); commit(q) } }} placeholder="ali napiši po svoje" aria-label={`${q.text} — svoj odgovor`} />
                      </div>
                    )}
                    {(q.multi || a.text.trim().length > 0) && <Btn primary sm disabled={!answerOf(ans, q) || !!busy} style={{ marginTop: 2 }} onClick={() => commit(q)}>Naprej ›</Btn>}
                  </div>
                ) : (
                  <button type="button" className="talk me q-ans" disabled={!!busy} onClick={() => reopen(q.id)} aria-label={`Tvoj odgovor: ${answerOf(ans, q)}. Tapni, da ga spremeniš.`}>{answerOf(ans, q)}</button>
                )}
              </Fragment>
            )
          })}
          {busy && <Thinking label={busy} />}
        </div>
        <div className="grow" style={{ minHeight: 18 }} />
        {curIx < 0 && !busy && <Btn primary block style={{ marginTop: 16 }} onClick={() => (prop ? setStep('dogovor') : void submitAnswers())}>{prop ? 'Nazaj na predlog' : 'Naprej'}</Btn>}
      </>)}

      {step === 'dogovor' && prop && (<>
        <h2>Najin dogovor</h2>
        <div className="stack" style={{ marginTop: 12, gap: 8 }}>
          {talk.slice(-5).map((t, i) => <div key={i} className={`talk${t.who === 'ti' ? ' me' : ''}`}>{t.who === 'trener' && <span className="talk-who">Trener</span>}{t.text}</div>)}
          {busy && <Thinking label={busy} />}
        </div>
        <Deal f={prop.focus} onDay={busy ? undefined : toggleDay} note={dayNote} />
        {again && <p className="muted" style={{ fontSize: 12, marginTop: 8 }}>Nov dogovor zamenja tvoj sedanji načrt od danes naprej. Opravljeni treningi ostanejo.</p>}
        <p className="muted" style={{ fontSize: 12.5, marginTop: 14 }}>Ti odločaš. Kaj bi spremenil?</p>
        <div className="row" style={{ gap: 6, flexWrap: 'wrap', marginTop: 8 }}>
          {(prop.quick.length ? prop.quick : ['Več kardia', 'Več moči', 'Manj dni', 'Krajše vadbe']).map(x => <button key={x} type="button" className="chip sm click" disabled={!!busy} onClick={() => void propose(qaAll, x)}>{x}</button>)}
        </div>
        <div className={`meal-text${sayDict.listening ? ' live' : ''}`}>
          <label htmlFor="sest-say" className="sr-only">Kaj bi spremenil</label>
          <textarea id="sest-say" rows={2} value={say} maxLength={400} onChange={e => setSay(e.target.value)} placeholder={sayDict.listening ? 'Poslušam …' : 'npr. raje 4 dni, več teka, brez nog'} style={{ paddingRight: 96 }} />
          {sayDict.canSpeak && <button type="button" className={`mic${sayDict.listening ? ' on' : ''}`} style={{ right: 52 }} onClick={sayDict.toggle} aria-pressed={sayDict.listening} aria-label={sayDict.listening ? 'Ustavi narekovanje' : 'Povej, kaj bi spremenil'}><IcoMic width={18} height={18} /></button>}
          <button type="button" className="mic send" disabled={!say.trim() || !!busy} onClick={() => { sayDict.stop(); void propose(qaAll, say.trim()) }} aria-label="Pošlji trenerju">→</button>
        </div>
        <div className="grow" style={{ minHeight: 18 }} />
        <Btn primary block disabled={!!busy} style={{ marginTop: 16 }} onClick={() => setStep('gradnja')}>Dogovorjeno — sestavi moj načrt</Btn>
      </>)}

      <button type="button" className="ob-fb" onClick={() => void startFeedback()}>Nekaj ni jasno? Pošlji pripombo</button>
      {ai.sheet}
    </main>
  )
}

function Thinking({ label }: { label: string }) {
  return <div className="talk think" role="status" aria-live="polite"><span className="talk-who">Trener</span>{label}<span className="thinking" aria-hidden="true"><i /><i /><i /></span></div>
}

/** Predlog tedna: ime, teden, cilji, seje, razpored po dnevih (tap = ta dan nimam časa), pojasnila. */
export function Deal({ f, onDay, note }: { f: Focus; onDay?: (d: number) => void; note?: string | null }) {
  const notes = useMemo(() => f.notes.slice(0, 4), [f.notes])
  const off = f.offDays || []
  const order = useMemo(() => scheduleWeek(f.sessions, [0, 1, 2, 3, 4, 5, 6].filter(d => !(f.offDays || []).includes(d)), f.preferDays, 7), [f])
  return (
    <div className="card deal" style={{ marginTop: 14 }}>
      <div className="h4">Predlog</div>
      <h3 style={{ fontSize: 20, marginTop: 4, letterSpacing: '-.02em' }}>{f.title}</h3>
      <p style={{ fontSize: 13, marginTop: 4 }}>{weekLine(f)}{f.aims.length || f.muscles.length ? ` · ${aimsLine(f)}` : ''}</p>
      <div className="deal-list">
        {f.sessions.map((s, i) => (
          <div key={i} className="deal-row" style={{ ['--c' as string]: sessionColor(s) }}>
            <span className="deal-ic"><SessionIcon s={s} /></span>
            <span style={{ flex: 1, minWidth: 0 }}><b>{SPORT_LABEL[s.type]}</b>{what(s) ? <span className="muted"> · {what(s)}</span> : null}</span>
            <span className="muted" style={{ fontWeight: 700, fontSize: 12.5 }}>{s.min} min</span>
          </div>
        ))}
      </div>
      {f.mode === 'meri' ? (
        <div className="deal-wk">
          <div className="between" style={{ gap: 8 }}><b style={{ fontSize: 13 }}>Tvoj teden</b>{onDay && <span className="muted" style={{ fontSize: 11.5, fontWeight: 700 }}>Tapni dan, ko nimaš časa</span>}</div>
          <div className="wk-pick" role="group" aria-label={onDay ? 'Tvoj teden — tapni dan, ko nimaš časa' : 'Tvoj teden'}>
            {DAY_OPTS.map((d, i) => {
              const s = order[i] != null ? f.sessions[order[i]!] : null
              const no = off.includes(i)
              const state = no ? 'ne gre' : s ? sessName(s) : 'prosto'
              return (
                <button key={i} type="button" className={`wk-d${no ? ' off' : ''}${s ? ' on' : ''}`} disabled={!onDay} aria-pressed={onDay ? no : undefined} aria-label={`${DAY_NAME[i]}: ${state}`} title={`${upper(DAY_NAME[i]!)}: ${state}`}
                  style={s ? { ['--c' as string]: sessionColor(s) } : undefined} onClick={() => onDay?.(i)}>
                  <small>{d}</small>
                  <span className="wk-i" aria-hidden="true">{no ? '✕' : s ? <SessionIcon s={s} size={15} /> : '·'}</span>
                </button>
              )
            })}
          </div>
          <p className="wk-note" role="status" aria-live="polite">{note ? <><b>Trener:</b> {note}</> : `${off.length ? `Ne gre: ${off.map(x => DAY_NAME[x]).join(', ')}. ` : ''}Razpored je predlog — teden se sproti prilagaja temu, kar narediš.`}</p>
        </div>
      ) : (
        <p className="muted" style={{ fontSize: 12, marginTop: 10 }}>Kolesarski načrt ima svoj tedenski ritem z dolgo vožnjo ob vikendu — trening na dan, ko ne moreš, premakneš v Planu.</p>
      )}
      {notes.length > 0 && <ul className="deal-notes">{notes.map((n, i) => <li key={i}>{n}</li>)}</ul>}
    </div>
  )
}
