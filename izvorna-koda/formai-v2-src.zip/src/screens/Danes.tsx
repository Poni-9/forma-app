import { useEffect, useMemo, useState } from 'react'
import { navigate } from '@/app/router'
import { Head } from '@/app/Shell'
import { useApp, setPlanDone, savePlanDays, savePlanDay, toast } from '@/state/store'
import type { PlanDay } from '@/domain/types'
import { snapOf } from '@/state/snap'
import { useAi } from '@/ui/useAi'
import { formSeries, formBand, fmtDur, addDays, weekStartIso } from '@/domain/training/load'
import { dailyTarget, profileComplete, sumMeals, weightTrend, fueling, activityKcal } from '@/domain/nutrition/energy'
import { buildWeek, easeDay, weekContext } from '@/domain/training/planner'
import { GoalCard } from '@/ui/GoalCard'
import { alerts } from '@/domain/alerts'
import { aiAllowed } from '@/domain/import/provenance'
import { wxShort, wxBad } from '@/domain/weather'
import { zoneText } from '@/domain/training/zones'
import { cachedDailyAdvice, dailyAdvice, adaptWeek } from '@/domain/ai/actions'
import { sanitizeGaps, hasHiddenActivities } from '@/domain/ai/sanitize'
import { Card, Chip, Ring, Sparkline, Empty, Btn, Track, kindColor, kindLabel, fmtDateLong, fmtKcal, DAYS_SL } from '@/ui/primitives'
import { Checkin, readinessOf } from '@/ui/Checkin'
import { WeighSheet } from '@/screens/Napredek'
import { IcoBike, IcoFood, IcoChat, IcoCheck, IcoScale, IcoCamera, IcoCal } from '@/ui/icons'

export function Danes() {
  const app = useApp()
  const ai = useAi()
  const { profile: p, plan, activities, mealsToday, today, checkinToday, weather } = app
  const ws = weekStartIso(today)
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(ws, i))
  const week = plan.filter(d => d.date >= ws && d.date <= addDays(ws, 6))
  const todayPlan = plan.filter(d => d.date === today)
  // najprej kolo/test, potem moč; neobvezno in počitek na koncu
  const prio = (d: PlanDay) => (d.kind === 'pocitek' ? 9 : d.optional ? 5 : d.kind === 'moc' ? 2 : 0)
  const ordered = [...todayPlan].sort((a, b) => prio(a) - prio(b))
  const main = ordered[0] || null
  const extra = ordered.filter(d => d !== main && d.kind === 'moc')
  const series = useMemo(() => formSeries(activities, today), [activities, today])
  const last = series[series.length - 1]
  const band = last ? formBand(last.tsb) : null
  const spark = series.slice(-28).map(x => x.tsb)
  const todaysActs = activities.filter(a => a.date === today)
  const target = dailyTarget(p, todaysActs, todayPlan, today)
  const eaten = sumMeals(mealsToday)
  const tr = weightTrend(app.checkins)
  const ready = readinessOf(last ? last.tsb : null, checkinToday)
  const cx = weekContext(p, ws)
  const firstName = (p.name || '').split(/\s+/)[0]
  const [aiLine, setAiLine] = useState<string | null>(null)
  const [weigh, setWeigh] = useState(false)
  const [busy, setBusy] = useState<string | null>(null)
  useEffect(() => { void cachedDailyAdvice(today).then(t => setAiLine(t ? sanitizeGaps(t, hasHiddenActivities(activities)) : null)) }, [today, activities.length, plan.length])
  const al = useMemo(() => alerts({ profile: p, activities, plan, checkins: app.checkins, recentMeals: app.recentMeals, today }), [p, activities, plan, app.checkins, app.recentMeals, today])
  const fuel = main && !main.optional ? fueling(main, p) : null
  const wx = weather?.[today]
  const seen = activities.filter(aiAllowed).length
  const outdoor = main && (main.kind === 'kolo' || main.kind === 'tek' || main.kind === 'pohod')

  async function buildThisWeek() {
    const rain: Record<string, number> = {}
    if (weather) for (const k in weather) rain[k] = weather[k]!.rain
    const days = buildWeek({ profile: p, activities, weekStart: ws, rain, firstWeek: !plan.length, notBefore: today })
    const doneDates = new Set(week.filter(d => d.done).map(d => d.date))
    await savePlanDays(days.filter(d => !doneDates.has(d.date)))
    toast('Teden je sestavljen.', 'ok')
  }
  async function ease() {
    const out = easeDay(week, today)
    if (!out) return
    for (const d of out) await savePlanDay(d)
    toast(out.length > 1 ? 'Danes lahko — seja je prestavljena.' : 'Danes lahko.', 'ok')
  }
  async function aiDay() {
    setBusy('adapt')
    const r = await ai.run(() => adaptWeek(snapOf(app), week, 'Prilagodi DANES in preostanek tedna glede na jutranje počutje, spanec in vreme. Opravljenih dni ne spreminjaj. Če je pripravljenost nizka, danes olajšaj in kakovostno sejo prestavi; tedenski volumen ohrani, če se da.'))
    setBusy(null)
    if (r) { await savePlanDays(r.days.filter(d => !d.done)); toast(r.summary, 'ok', 8000) }
  }
  async function advice() {
    setBusy('advice')
    const t = await ai.run(() => dailyAdvice(snapOf(app), !!aiLine))
    setBusy(null)
    if (t) setAiLine(t)
  }

  return (<>
    <Head hi={fmtDateLong(today)} nm={firstName ? `Živjo, ${firstName}` : 'Živjo'} />
    <div className="scroll">
      <div className="between" style={{ marginBottom: 8 }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ink-3)' }}>{cx.structured ? `${cx.phaseName.toUpperCase()} · TEDEN ${cx.week}${cx.total ? '/' + cx.total : ''}${cx.recovery ? ' · RAZBREMENILNI' : ''}` : 'TA TEDEN'}</div>
        {ready && <Chip sm><span className="dot" style={{ background: ready.color }} />pripravljenost {ready.score}</Chip>}
      </div>
      <div className="week">
        {weekDays.map((d, i) => {
          const items = plan.filter(x => x.date === d && x.kind !== 'pocitek' && !x.optional)
          const isToday = d === today, past = d < today
          return (
            <button key={d} type="button" className={`day ${isToday ? 'today' : ''} ${past ? 'past' : ''}`} onClick={() => navigate('plan', { dan: d })}>
              <div className="dn">{DAYS_SL[i]}</div><div className="dd">{+d.slice(8)}</div>
              <div className="dots">{items.length ? items.slice(0, 2).map((k, j) => <i key={j} style={{ background: isToday ? 'rgba(15,18,22,.6)' : k.done ? 'var(--accent)' : kindColor(k.kind) }} />) : <i style={{ background: isToday ? 'rgba(15,18,22,.6)' : 'var(--t-poc)', opacity: .5 }} />}</div>
            </button>
          )
        })}
      </div>

      <GoalCard />

      <div style={{ marginTop: 12 }}><Checkin compact /></div>

      {al.length > 0 && (
        <div className="stack" style={{ gap: 8, marginTop: 12 }}>
          {al.map((a, i) => (
            <button key={i} type="button" className="card tight row" onClick={() => a.to && navigate(a.to)} style={{ gap: 10, textAlign: 'left', width: '100%', cursor: a.to ? 'pointer' : 'default', alignItems: 'flex-start' }}>
              <span className="dot" style={{ background: a.kind === 'bad' ? 'var(--bad)' : a.kind === 'warn' ? 'var(--warn)' : 'var(--ink-3)', marginTop: 6, flex: 'none' }} />
              <span style={{ fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.45 }}>{a.text}</span>
            </button>
          ))}
        </div>
      )}

      {!week.length ? (
        <div style={{ marginTop: 12 }}>
          <Empty icon={<IcoCal width={30} height={30} style={{ color: 'var(--accent)' }} />} title="Ta teden še ni sestavljen" text={`${String(cx.hours).replace('.', ',')} h na kolesu · ${cx.recovery ? 'razbremenilni teden' : 'VO2max v torek, prag v četrtek, dolga Z2 v soboto'}${p.strength.on && p.strengthDays ? ` · moč ${Math.min(2, p.strengthDays)}×` : ''}. Sestavi se takoj, brez AI.`}>
            <Btn primary sm onClick={buildThisWeek}>Sestavi teden</Btn>
          </Empty>
        </div>
      ) : main && main.kind !== 'pocitek' ? (
        <Card className="sess" style={{ marginTop: 12 }}>
          <div className="bar" style={{ background: main.optional ? 'var(--t-poc)' : kindColor(main.kind) }} />
          <div style={{ paddingLeft: 6 }}>
            <div className="between">
              <div className="kind" style={{ color: main.optional ? 'var(--ink-3)' : kindColor(main.kind) }}>{main.optional ? 'Počitek · hoja po želji' : `${kindLabel(main.kind)} · danes`}</div>
              {main.done ? <Chip sm on>opravljeno</Chip> : null}
            </div>
            <div className="ttl">{main.title}</div>
            <p style={{ fontSize: 13, marginTop: 6 }}>{main.desc}</p>
            <div className="meta" style={{ flexWrap: 'wrap' }}>
              {main.durationMin > 0 && <span>{fmtDur(main.durationMin)}</span>}
              {main.tssTarget && !main.optional ? <><span>·</span><span>{main.tssTarget} TSS</span></> : null}
              {main.target ? <><span>·</span><span>intervali {main.target.lo}–{main.target.hi} W</span></> : main.kind === 'kolo' && main.zone && /^Z[1-5]$/.test(main.zone) && !main.desc.includes(zoneText(p, main.zone as 'Z2')) ? <><span>·</span><span>{main.zone} · {zoneText(p, main.zone as 'Z2')}</span></> : null}
              {main.exercises?.length ? <><span>·</span><span>{main.exercises.length} vaj</span></> : null}
            </div>
            {main.exercises?.length ? (
              <div style={{ marginTop: 10, paddingTop: 10, borderTop: '1px solid var(--line)' }}>
                {main.exercises.map((e, j) => <div key={j} className="between" style={{ fontSize: 13, padding: '3px 0' }}><span style={{ fontWeight: 600, color: 'var(--ink)' }}>{e.name}</span><span className="muted">{e.sets} × {e.reps}{e.kg ? ` · ${e.kg} kg` : ''}</span></div>)}
              </div>
            ) : null}
            {outdoor && wx && <div style={{ fontSize: 12, marginTop: 8, fontWeight: 600, color: wxBad(wx) ? 'var(--warn)' : 'var(--ink-3)' }}>{wxShort(wx)}{wxBad(wx) && main.kind === 'kolo' ? (p.gear.trainer ? ' — raje trenažer' : ' — premakni ali se dobro obleci') : ''}</div>}
            {main.why && !main.done && <div className="muted" style={{ fontSize: 12, marginTop: 8 }}>{main.why}</div>}
            {!main.done && (
              <div className="row" style={{ gap: 8, marginTop: 13, flexWrap: 'wrap' }}>
                <Btn ghost sm onClick={() => setPlanDone(main.id, true)}><IcoCheck width={15} height={15} /> Opravil</Btn>
                {!main.optional && ready && ready.score < 45 && <Btn ghost sm onClick={ease}>Olajšaj dan</Btn>}
                {!main.optional && ready && ready.score < 60 && app.user && <Btn ghost sm disabled={ai.busy} onClick={aiDay}>{busy === 'adapt' ? 'Prilagajam …' : 'AI prilagodi'}</Btn>}
              </div>
            )}
            {main.done && <button className="chip sm click" style={{ marginTop: 12 }} onClick={() => setPlanDone(main.id, false)}>razveljavi</button>}
          </div>
        </Card>
      ) : (
        <Card className="sess" style={{ marginTop: 12 }}>
          <div className="bar" style={{ background: 'var(--t-poc)' }} />
          <div style={{ paddingLeft: 6 }}><div className="kind" style={{ color: 'var(--t-poc)' }}>Počitek · danes</div><div className="ttl">Dan brez treninga</div><p style={{ fontSize: 13, marginTop: 6 }}>Hoja, raztezanje, spanec. Prilagoditev se zgodi med počitkom.</p></div>
        </Card>
      )}

      {extra.map(x => (
        <Card key={x.id} tight className="sess" style={{ marginTop: 8 }}>
          <div className="bar" style={{ background: kindColor(x.kind) }} />
          <div className="between" style={{ paddingLeft: 6, gap: 10 }}>
            <div style={{ minWidth: 0 }}>
              <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: '.08em', color: kindColor(x.kind) }}>+ {kindLabel(x.kind).toUpperCase()} · {x.durationMin} MIN</div>
              <b style={{ fontSize: 14 }}>{x.title}</b>
              {x.exercises?.length ? <div className="muted" style={{ fontSize: 12 }}>{x.exercises.map(e => `${e.name} ${e.sets}×${e.reps}`).join(' · ')}</div> : null}
            </div>
            {x.done ? <Chip sm on>opravljeno</Chip> : <Btn ghost sm onClick={() => navigate('vadba', { id: x.id })}>Začni</Btn>}
          </div>
        </Card>
      ))}

      {fuel && !main?.done && (
        <Card tight style={{ marginTop: 12 }}>
          <h4 style={{ fontSize: 11 }}>Gorivo za ta trening</h4>
          <div className="stack" style={{ gap: 6, marginTop: 6 }}>
            {([['Pred', fuel.before], ['Med', fuel.during], ['Po', fuel.after]] as const).map(([l, t]) => <div key={l} style={{ display: 'grid', gridTemplateColumns: '38px 1fr', gap: 8, fontSize: 12.5 }}><b style={{ color: 'var(--ink)' }}>{l}</b><span style={{ color: 'var(--ink-2)' }}>{t}</span></div>)}
          </div>
        </Card>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 12 }}>
        <Card tight style={{ cursor: 'pointer' }} onClick={() => navigate('analitika')}>
          <h4 style={{ fontSize: 11 }}>Forma</h4>
          {last && series.length > 3 ? (<>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 2 }}>
              <b style={{ fontSize: 26, fontWeight: 800, letterSpacing: '-.03em' }}>{last.tsb > 0 ? '+' : ''}{Math.round(last.tsb)}</b>
              <span style={{ fontSize: 11, color: band!.color === 'ok' ? 'var(--ok)' : band!.color === 'bad' ? 'var(--bad)' : band!.color === 'warn' ? 'var(--warn)' : 'var(--t-kolo)', fontWeight: 700 }}>{band!.band}</span>
            </div>
            <div style={{ marginTop: 5 }}><Sparkline values={spark} /></div>
            <div className="muted" style={{ fontSize: 11, fontWeight: 600, marginTop: 2 }}>kondicija {Math.round(last.ctl)} · utrujenost {Math.round(last.atl)}</div>
          </>) : (<p style={{ fontSize: 12, marginTop: 4 }}>Po nekaj aktivnostih pokažem formo.</p>)}
        </Card>
        <Card tight style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }} onClick={() => navigate('prehrana')}>
          {target ? (<>
            <Ring pct={eaten.kcal / target.kcal}><div><b style={{ fontSize: 19 }}>{fmtKcal(eaten.kcal)}</b><small>od {fmtKcal(target.kcal)}</small></div></Ring>
            <div style={{ fontSize: 11, color: 'var(--ink-3)', fontWeight: 700, marginTop: 3 }}>KALORIJE · ŠE {fmtKcal(Math.max(0, target.kcal - eaten.kcal))}</div>
          </>) : (<>
            <IcoFood style={{ color: 'var(--ok)' }} /><div style={{ fontSize: 12, color: 'var(--ink-2)', marginTop: 6, textAlign: 'center' }}>Dopolni profil za kalorije</div>
          </>)}
        </Card>
      </div>

      {target && (
        <Card tight style={{ marginTop: 12 }}>
          <div className="between" style={{ fontSize: 13 }}><span className="muted" style={{ fontWeight: 600 }}>Beljakovine</span><b>{Math.round(eaten.p)} / {target.proteinG} g</b></div>
          <div style={{ marginTop: 6 }}><Track pct={eaten.p / target.proteinG * 100} color="var(--accent)" /></div>
          {todaysActs.length > 0 && <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>Danes porabljeno na treningu ~{fmtKcal(todaysActs.reduce((s, a) => s + activityKcal(a, p), 0))} kcal — že vključeno v cilj.</div>}
          <div className="muted" style={{ fontSize: 11, marginTop: 6 }}>Ocene kalorij so približki. Pred večjimi spremembami prehrane ali ob zdravstvenih težavah se posvetuj z zdravnikom.</div>
        </Card>
      )}

      <Card tight style={{ marginTop: 12 }}>
        <div className="between">
          <div>
            <h4 style={{ fontSize: 11 }}>Teža</h4>
            {tr ? (<>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}><b style={{ fontSize: 22, fontWeight: 800 }}>{tr.avg7.toFixed(1).replace('.', ',')} kg</b>{tr.deltaWeek != null && <span style={{ fontSize: 12, fontWeight: 700, color: tr.deltaWeek < -0.75 ? 'var(--warn)' : tr.deltaWeek < 0 ? 'var(--ok)' : 'var(--ink-3)' }}>{tr.deltaWeek > 0 ? '+' : ''}{tr.deltaWeek.toFixed(2).replace('.', ',')} / teden</span>}</div>
              <div className="muted" style={{ fontSize: 11.5, fontWeight: 600 }}>7-dnevno povprečje{p.targetWeightKg ? ` · cilj ${p.targetWeightKg} kg, še ${Math.max(0, tr.avg7 - p.targetWeightKg).toFixed(1).replace('.', ',')}` : ''}</div>
            </>) : <div className="muted" style={{ fontSize: 12.5 }}>Stehtaj se zjutraj — trend pokažem po nekaj dneh.</div>}
          </div>
          <Btn sm onClick={() => setWeigh(true)}><IcoScale width={16} height={16} /> Stehtaj</Btn>
        </div>
      </Card>

      <div className="card tight hover" style={{ marginTop: 12, display: 'flex', gap: 11, alignItems: 'flex-start' }}>
        <div style={{ width: 30, height: 30, borderRadius: 'var(--r-s)', background: 'var(--accent-soft)', display: 'grid', placeItems: 'center', flex: 'none', color: 'var(--accent)' }}><IcoChat width={16} height={16} /></div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="between"><b style={{ fontSize: 13 }}>Trener pravi</b><button className="chip sm click" onClick={() => navigate('trener')}>vprašaj ›</button></div>
          <p style={{ fontSize: 13, marginTop: 4, whiteSpace: 'pre-wrap' }}>{aiLine || coachLine(last?.tsb ?? null, main, seen, activities.length, ready?.score ?? null)}</p>
          {app.user && <button className="chip sm click" style={{ marginTop: 8 }} disabled={ai.busy} onClick={advice}>{busy === 'advice' ? 'Razmišljam …' : aiLine ? 'osveži nasvet' : 'AI nasvet za danes'}</button>}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginTop: 12 }}>
        <Btn ghost sm onClick={() => navigate('prehrana', { foto: '1' })}><IcoCamera width={15} height={15} /> Obrok</Btn>
        <Btn ghost sm onClick={() => navigate('aktivnosti', { nova: '1' })}><IcoBike width={15} height={15} /> Vaja</Btn>
        <Btn ghost sm onClick={() => navigate('napredek')}><IcoScale width={15} height={15} /> Napredek</Btn>
      </div>

      <div className="muted" style={{ fontSize: 11, padding: '12px 4px 0' }}>Plan je trenerska usmeritev, ne zdravniški nasvet. Poslušaj telo; ob bolečini, bolezni ali zdravstvenih težavah se posvetuj z zdravnikom.</div>

      {!profileComplete(p) && (
        <div style={{ marginTop: 12 }}>
          <Empty icon={<IcoFood width={30} height={30} style={{ color: 'var(--ok)' }} />} title="Za kalorije rabim tvoj profil" text="Višina, teža, starost in spol. Brez tega ti številke ne pokažem.">
            <Btn primary sm onClick={() => navigate('nastavitve')}>Izpolni profil</Btn>
          </Empty>
        </div>
      )}
    </div>
    <WeighSheet open={weigh} onClose={() => setWeigh(false)} />
    {ai.sheet}
  </>)
}

function coachLine(tsb: number | null, main: { kind: string; optional?: boolean } | null, aiSeen: number, total: number, ready: number | null): string {
  if (!total) return 'Ko vpišeš ali uvoziš prve treninge, začnem pisati konkretne nasvete namesto splošnih.'
  if (aiSeen === 0) return `Vidim ${total} aktivnosti, a nobena ni iz vira, ki ga smem uporabiti. Poveži uro neposredno z intervals.icu ali naloži datoteke.`
  if (ready != null && ready < 45) return 'Telo danes kaže utrujenost. Lahka hoja in zgoden spanec naredita več kot trd trening — olajšaj dan.'
  if (tsb == null) return 'Še računam formo — po nekaj dneh bo tu konkreten nasvet.'
  if (tsb < -20) return main?.kind === 'pocitek' || main?.optional ? 'Utrujenost je visoka — današnji počitek je del načrta, ne luknja v njem.' : 'Utrujenost je visoka — danes ostani v Z2, tudi če se počutiš dobro. Jej do cilja.'
  if (tsb > 10) return main?.kind === 'kolo' ? 'Svež si. Če je danes kakovosten dan, ga izkoristi — to je pravi trenutek.' : 'Svež si — dober čas za kakovostno sejo ta teden.'
  return 'Forma je v pravem območju. Drži se načrta, ne dodajaj. Beljakovine do cilja.'
}
