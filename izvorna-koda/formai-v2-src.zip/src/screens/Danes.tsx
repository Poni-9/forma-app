import { FuelTimeline, drinkLine } from '@/ui/FuelTimeline'
import { weekProgress } from '@/domain/training/share'
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { navigate } from '@/app/router'
import { Head } from '@/app/Shell'
import { useApp, getState, setPlanDone, savePlanDays, savePlanDay, toast, moveKeyToLater, syncIntervals, syncGarmin, hikeInstead, backToBike, restorePlanDays, undoLoadAdaptOf, rateSession, addCore } from '@/state/store'
import { RateRow } from '@/ui/RateRow'
import { DoneMinutes } from '@/ui/DoneMinutes'
import { SickSheet, SickCard } from '@/ui/SickSheet'
import { canMove } from '@/domain/training/swap'
import { StateCard } from '@/ui/StateCard'
import { YesterdayRate } from '@/ui/YesterdayRate'
import { FirstTraining } from '@/ui/FirstTraining'
import { firstTraining, strengthFuel } from '@/domain/training/danes'
import { MovedCard } from '@/ui/MovedCard'
import { LastWeekCard } from '@/ui/LastWeekCardLazy'
import { OffSeasonCard } from '@/ui/OffSeasonCard'
import { inSick } from '@/domain/training/sick'
import { activePause, pauseLock, inPause } from '@/domain/training/pause'
import { WeekPauseSheet, WeekPauseCard } from '@/ui/WeekPauseSheet'
import { importDiagnosis } from '@/domain/intervals/diagnosis'
import { icuReady } from '@/domain/intervals/client'
import type { PlanDay, Profile } from '@/domain/types'
import { useAi } from '@/ui/useAi'
import { formSeries, formBand, formReliable, fmtDur, addDays, weekStartIso, titleWithDur } from '@/domain/training/load'
import { dailyTarget, sumMeals, weightTrend, fueling, activityKcal, lossTooFast, isMinor } from '@/domain/nutrition/energy'
import { shownTargetWeight, adultKnown } from '@/domain/nutrition/body'
import { buildWeek, easeDay, canEaseDay, weekContext, canHike } from '@/domain/training/planner'
import { OFF_MIX, offMixOf } from '@/domain/training/offMix'
import { GoalCard } from '@/ui/GoalCard'
import { isCustom, weekLine, mixLine } from '@/domain/focus/model'
import { FirstSteps } from '@/ui/FirstSteps'
import { BackupNudge } from '@/ui/BackupNudge'
import { firstDayOf } from '@/domain/start'
import { Guide } from '@/ui/GuideLazy'
import { rideFuel, fuelCtxOf, restWindowsOf } from '@/domain/nutrition/dayplan'
import { dayMealsOf, nextSlotOf, recipeCtxOf, recipesOf } from '@/domain/nutrition/daymeals'
import { raceSoon, whenSl } from '@/domain/nutrition/race'
import { FuelLogCard } from '@/ui/FuelLogLazy'
import { RouteCard } from '@/ui/RouteCardLazy'
import { LoadAdaptCard } from '@/ui/LoadAdaptCard'
import { TomorrowCard } from '@/ui/TomorrowCard'
import { checkRide, moveKeyPlan } from '@/domain/training/review'
import { raceLock } from '@/domain/training/protect'
import { alerts, unmarkedSessions, daysSinceWeigh } from '@/domain/alerts'
import { aiAllowed } from '@/domain/import/provenance'
import { wxShort, wxBad, clothing } from '@/domain/weather'
import { zoneText, workText, workZone } from '@/domain/training/zones'
import { cachedDailyAdvice, dailyAdvice, adaptWeek, adviceSig } from '@/domain/ai/daily'
import { sanitizeGaps, hasHiddenActivities, honest } from '@/domain/ai/sanitize'
import { plainAi } from '@/domain/ai/md'
import { Card, Chip, Ring, Sparkline, Empty, Btn, Track, KindIcon, kindColor, kindInk, kindLabel, fmtDateLong, fmtKcal, DAYS_SL } from '@/ui/primitives'
import { TailRow } from '@/ui/TailRow'
import { ExGrid, exLogOf, exPartial, gist, hasMore, baseTitle, drillGist, raceGist, isRace, sessColor, sessInk, sessLabel, SessIcon } from '@/ui/SessBits'
import { runningDayId } from '@/ui/runState'
import { StepsBar } from '@/ui/StepsBar'
import { stepsFor, descShown, type Step } from '@/domain/training/workout'
import { g } from '@/ui/gender'
import { Checkin, readinessOf, checkinDone } from '@/ui/Checkin'
import { recoveryOf, fmtSleep, wellnessActive } from '@/domain/wellness'
// (v3.52) Garmin Connect neposredno: pripravljenost tudi z Garmina; cikel samo prikaz in namig (NIKOLI v AI); »Preveri Garmin« brez intervals.icu
import { cycleAdvice, PHASE_LABEL } from '@/domain/garmin/cycleRules'
import { watchOf } from '@/domain/routes/watch'
import { routesOf } from '@/data/routes'
import { exByName } from '@/domain/training/exercises'
// (v3.51) listi se prenesejo ob prvem odprtju (G08)
import { WeighSheet, ReadinessSheet, SkipSheet, MoveDaySheet } from '@/ui/DanesSheetsLazy'
import { CountUp } from '@/ui/CountUp'
import { HealthNote } from '@/ui/HealthNote'
import { undoToast, useHidden } from '@/ui/Confirm'
import { IcuErrorCard, icuErrActive, icuErrOf, icuErrText, syncResult } from '@/ui/IcuStatus'
import { count, dec, dm, dayAcc, dayName, nb, num, plural, signed, unit, NBSP, W, withoutFuelLine, plainOH } from '@/ui/format'
import { IcoFood, IcoChat, IcoCheck, IcoScale, IcoCal, IcoWatch, IcoTarget, IcoChevDown, IcoTrophy, IcoCamera } from '@/ui/icons'
// (v3.50) trening s slike: odkljukaj s posnetkom, dodaj s slike
import { openPhotoTraining } from '@/ui/photoOpen'
import { effortOf } from '@/domain/training/effort'
import { needOf } from '@/domain/routes/match'
import { openHelp } from '@/ui/overlays'
import { Fold } from '@/ui/Fold'
import { ChangeDaySheet, easeTexts, type ChangeOpt } from '@/ui/ChangeDaySheet'
import { rovingTab, rovingKey } from '@/ui/roving'
import { rem } from '@/ui/rem'

/** Forma z besedo: kaj pomeni zate (številke kondicije in utrujenosti so v Napredku). */
const FORM_WORD: Record<string, string> = { 'prepočit': 'dolgo brez treninga — začni postopno', 'svež': 'spočit — pravi čas za trd trening', 'dober': 'v pravem območju', 'produktiven': 'malo utrujen od treninga — normalno', 'utrujen': 'precej utrujen — več počitka' }
/** (v3.51) uporabnica: ženske oblike opisa forme */
const FORM_WORD_F: Record<string, string> = { ...FORM_WORD, 'svež': 'spočita — pravi čas za trd trening', 'produktiven': 'malo utrujena od treninga — normalno', 'utrujen': 'precej utrujena — več počitka' }

/** Gumb, ki izgleda kot besedilo (vrstica z opozorilom, povezava v kartici). */
const TEXT_BTN: React.CSSProperties = { display: 'block', width: '100%', textAlign: 'left', background: 'none', border: 0, padding: 0, cursor: 'pointer', font: 'inherit' }

export function Danes() {
  const app = useApp()
  const [checking, setChecking] = useState(false)
  const ai = useAi()
  const hidden = useHidden()
  const { profile: p, plan, activities, today, checkinToday, weather } = app
  // obrok, ki čaka na izbris (»Razveljavi«), ne šteje več
  const mealsToday = useMemo(() => app.mealsToday.filter(m => !hidden.has('meal:' + m.id)), [app.mealsToday, hidden])
  const ws = weekStartIso(today)
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(ws, i))
  const week = plan.filter(d => d.date >= ws && d.date <= addDays(ws, 6))
  const todayPlan = plan.filter(d => d.date === today)
  // najprej kolo/test, potem moč; neobvezno in počitek na koncu
  const prio = (d: PlanDay) => (d.kind === 'pocitek' ? 9 : d.optional ? 5 : d.kind === 'moc' ? 2 : 0)
  const ordered = [...todayPlan].sort((a, b) => prio(a) - prio(b))
  // (v3.51) dan počitka s sejo po želji (»Jedro po želji«): kartica počitka ostane (z »Dodaj trening«, »Bolan sem« …),
  // seja po želji je pod njo kot dodatna — prej je kartico počitka zamenjala
  const restMain = todayPlan.some(d => d.kind !== 'pocitek' && !d.optional) ? null : todayPlan.find(d => d.kind === 'pocitek') ?? null
  const main = restMain ?? ordered[0] ?? null
  const extra = ordered.filter(d => d !== main && d.kind === 'moc')
  const series = useMemo(() => formSeries(activities, today), [activities, today])
  // manj kot 6 tednov zgodovine (in brez začetnega stanja iz intervals.icu): forma je le groba ocena
  const formEst = useMemo(() => !formReliable(activities, today), [activities, today])
  const last = series[series.length - 1]
  const band = last ? formBand(last.tsb) : null
  const spark = series.slice(-28).map(x => x.tsb)
  const hasForm = !!last && series.length > 3 && activities.length > 0
  // (v3.50) manj kot 3 vadbe v 28 dneh: forma je »še računam« (ne »dober +1 · premalo zgodovine«), trener brez »pravem območju«
  const few = activities.filter(a => a.date >= addDays(today, -28) && a.date <= today).length < 3
  const todaysActs = activities.filter(a => a.date === today)
  const target = dailyTarget(p, todaysActs, todayPlan, today)
  // (v3.51) po opravljeni današnji tekmi brez »Malo vlaknin … do starta«
  const raceNear0 = raceSoon(p, today)
  const raceNear = raceNear0 && raceNear0.inDays === 0 && todayPlan.some(d => isRace(d) && d.done) ? null : raceNear0
  const eaten = sumMeals(mealsToday)
  // naslednji obrok po načrtu z receptom (isti izračun kot na Prehrani) — povezava Danes → Prehrana
  const nextMeal = useMemo(() => {
    if (!target) return null
    // (v3.50) z uro: nevpisan obrok, katerega čas je mimo, ni več v načrtu (isto kot Prehrana)
    const hour = new Date().getHours()
    const dm = dayMealsOf({ p, target, plan, activities, meals: mealsToday, recentMeals: app.recentMeals, weather, day: today, today, hour })
    // (v3.51) seja je za nami: obrok »pred« (»Zajtrk pred tekmo«, »Zajtrk pred vožnjo«) ni več naslednji
    const dp = dm.dp.rideDone ? { ...dm.dp, slots: dm.dp.slots.filter(x => x.key !== 'pred' && !/\bpred\b/i.test(x.label)) } : dm.dp
    const sl = nextSlotOf(dp, mealsToday, hour)   // zvečer ni »naslednji obrok« zajtrk (v3.48)
    if (!sl) return null
    const r = recipesOf(dp, today, recipeCtxOf(p, target, app.settings, dm.training), app.settings)[sl.key] ?? null
    return r ? { slot: sl, r } : null
  }, [target, plan, activities, today, p, weather, app.recentMeals, mealsToday, app.settings])
  const tr = weightTrend(app.checkins)
  // številka se našteje (živa aplikacija) — (v3.49) v svojem elementu, zaslon se med štetjem ne izrisuje znova
  const shownKcal = <CountUp value={eaten.kcal} id={`kcal:${today}`} format={n => fmtKcal(Math.round(n))} />
  // teža kot vrstica jutranje kartice (Blaž, 11. 10.: manj okvirčkov) — enak podatek kot prej v svoji kartici
  const dw = daysSinceWeigh(app.checkins, today)
  // (v3.48) ciljna teža kot v Napredku (ročna ali izračunana); prehitro nad 0,5 kg na teden (varovalka)
  const goalKg = shownTargetWeight(p, isCustom(p), today)
  const weightRow = (
    <div className="between" style={{ gap: 10 }}>
      <div style={{ minWidth: 0, fontSize: rem(12.5), color: 'var(--ink-2)' }}>
        {tr ? (<>Teža <b style={{ color: 'var(--ink)' }}>{unit(dec(tr.avg7, 1), 'kg')}</b>{tr.deltaWeek != null && !(dw != null && dw >= 7) ? <span style={{ fontWeight: 700, color: lossTooFast(-tr.deltaWeek) ? 'var(--warn)' : weightStable(tr) ? 'var(--ink-3)' : tr.deltaWeek < 0 ? 'var(--ok)' : 'var(--ink-3)' }}> · {weightStable(tr) ? 'stabilna' : <>{signed(tr.deltaWeek, 2)}{NBSP}kg/teden</>}</span> : null}{goalKg ? <span className="muted"> · cilj {unit(num(goalKg), 'kg')}</span> : null}{dw != null && dw >= 7 ? <span style={{ fontWeight: 700, color: 'var(--warn)' }}> · zadnje tehtanje pred {dw} dnevi</span> : null}</>) : <>Teža — stehtaj se zjutraj, trend pokažem po nekaj dneh.</>}
      </div>
      <button type="button" className="chip sm click" style={{ flex: 'none' }} onClick={() => setWeigh(true)}><IcoScale width={12} height={12} /> stehtaj</button>
    </div>
  )
  // (v3.52) podatki z ure prek intervals.icu ALI Garmin Connect neposredno
  const wellOn = wellnessActive(app.settings)
  const rec = useMemo(() => (wellOn ? recoveryOf(app.wellness, today, checkinToday?.sleepH ?? null) : null), [wellOn, app.wellness, today, checkinToday?.sleepH])
  // Garmin pripis v razlagi pripravljenosti: ura (ne Edge števec — ta ne meri spanca)
  const watchName = useMemo(() => { const w = watchOf(app.activities); return w.name && !w.edge ? (/^garmin\b/i.test(w.name) ? w.name.replace(/^garmin\b/i, 'Garmin') : `Garmin ${w.name}`) : null }, [app.activities])
  const ready = readinessOf(last ? last.tsb : null, checkinToday, rec)
  // (v3.52) cikel z Garmina (samo pri vklopu): faza in zmeren namig — prikaz in pravila, NIKOLI v AI
  const cyc = useMemo(() => (p.sex === 'z' && app.settings.garmin?.cycle && app.cycle?.length ? cycleAdvice(app.cycle, main, today) : null), [p.sex, app.settings.garmin?.cycle, app.cycle, main, today])
  const cx = weekContext(p, ws)
  // načrt po meri (fitnes, tek, kondicija): drugačna glava, kartica dogovora namesto cilja sezone
  const custom = isCustom(p)
  const firstName = (p.name || '').split(/\s+/)[0]
  const [aiLine, setAiLine] = useState<string | null>(null)
  // (v3.49) nasvet velja za dan, kot je bil ob nastanku; po spremembi treninga ali počutja lokalna vrstica + »osveži nasvet«
  const sig = adviceSig({ plan, today, checkinToday })
  const [stale, setStale] = useState(false)
  const [weigh, setWeigh] = useState(false)
  const [busy, setBusy] = useState<string | null>(null)
  useEffect(() => { void cachedDailyAdvice(today, sig).then(c => { setStale(!!c?.stale); setAiLine(c && !c.stale ? plainAi(honest(sanitizeGaps(c.text, hasHiddenActivities(activities)), { minor: isMinor(p), noAge: !isMinor(p) && !adultKnown(p) })) : null) }) }, [today, activities.length, plan.length, sig])
  const al = useMemo(() => alerts({ profile: p, activities, plan, checkins: app.checkins, recentMeals: app.recentMeals, today }), [p, activities, plan, app.checkins, app.recentMeals, today])
  const fuel0 = main && !main.optional ? fueling(main, p, { prefs: app.settings.foodPrefs }) : null
  // (v3.50) dan samo z močjo (brez vožnje): »Pred« ne predpostavlja kolesa (besedilo goriva je v energy.ts — tu samo kartica)
  const rideToday = todayPlan.some(x => (x.kind === 'kolo' || x.kind === 'test') && x.id !== main?.id)
  const fuel = strengthFuel(fuel0, main, rideToday)
  const eff = main ? effortOf(main) : null
  const routeOk = !!main && !main.optional && !main.done && (main.kind === 'kolo' || main.kind === 'test') && !!needOf(main, p)
  const [guide, setGuide] = useState(false)
  const [readyOpen, setReadyOpen] = useState(false)
  const [sickOpen, setSickOpen] = useState(false)
  const [skipDay, setSkipDay] = useState<PlanDay | null>(null)
  // jutranji vnos: ob odprtju neizpolnjen → pod treningom (ostane tam, tudi ko ga izpolniš); izpolnjen → spodaj
  // (v3.49) prvi dan po uvodu: spodaj in v eni vrstici (prvi zaslon je krajši; »vpiši« ga odpre)
  const firstDay = useMemo(() => firstDayOf(getState()), [today])   // eslint-disable-line react-hooks/exhaustive-deps
  const ciTop = useMemo(() => !checkinDone(getState()) && !firstDay, [today])   // eslint-disable-line react-hooks/exhaustive-deps
  const [moveDay, setMoveDay] = useState<PlanDay | null>(null)
  const [changeOpen, setChangeOpen] = useState(false)
  const sick = inSick(p, today)
  // (v3.50) »Ta teden …«: premor do nedelje (brez treningov ali brez kolesa)
  const pause = activePause(p, today)
  const [pauseOpen, setPauseOpen] = useState(false)
  // (v3.50) »Jedro po želji«: zaklep proti dvojnemu tapu (prej dve seji jedra)
  const [coreBusy, setCoreBusy] = useState(false)
  const coreLock = useRef(false)
  const addCoreOnce = async () => {
    if (coreLock.current) return
    coreLock.current = true; setCoreBusy(true)
    try { await addCore(today); toast('Jedro dodano — po želji, ne šteje v realizacijo.', 'ok') } finally { coreLock.current = false; setCoreBusy(false) }
  }
  // (v3.50) za lokalni nasvet: jutrišnja glavna seja (kot na kartici Jutri)
  const tomorrowMain = useMemo(() => [...plan.filter(d => d.date === addDays(today, 1))].sort((a, b) => prio(a) - prio(b))[0] ?? null, [plan, today])   // eslint-disable-line react-hooks/exhaustive-deps
  // vodnik »Kako deluje« se pokaže enkrat: po uvodu ali po prvem cilju (guideSeen === false)
  useEffect(() => { if (app.ready && app.settings.guideSeen === false) setGuide(true) }, [app.ready, app.settings.guideSeen])
  const wx = weather?.[today]
  const seen = activities.filter(aiAllowed).length
  const outdoor = main && (main.kind === 'kolo' || main.kind === 'tek' || main.kind === 'pohod')
  // »Olajšaj dan« zna olajšati samo vožnjo (easeDay) — pri moči, teku ali hribih ga ne ponujamo; ne na dan tekme in dan pred njo (v3.48)
  const canEase = !!main && canEaseDay(main, raceLock(plan, p))
  // (v3.50 A03) podnapis »Olajšaj dan« po izidu: kam gre seja ali da ta teden odpade
  const easeTx = canEase && main ? easeTexts(main, easeDay(week, today, pauseLock(raceLock(plan, p), p)), today) : null
  // kartica treninga (v3.48): tekma je označena kot tekma; pri vajah struktura namesto odrezanega ogrevanja; cilj enkrat
  const race = !!main && isRace(main)
  // (v3.51) brez merilnika: utrip dela po trenutnih conah, »pri utripu«, brez »≈ … W«
  const full = main ? plainOH(descShown(fuel && !main.done ? withoutFuelLine(main.desc) : main.desc, p, main)) : ''
  const steps = main && !main.done && (main.kind === 'kolo' || main.kind === 'tek' || main.kind === 'test') ? stepsFor(main, p) : []
  // (v3.51) hrana na kolesu v lahkih delih (ogrevanje, odmori) — kot vodena vadba; prej gel ob 0:30 sredi 20-minutnega testa
  const rf = main && !main.optional ? rideFuel(main, p.fuelKit, { ...fuelCtxOf(weather, app.recentMeals, main.date, today), restWindows: restWindowsOf(steps) }) : null
  const { line: zoneLine, known: zoneT } = main && !race ? zoneLineOf(main, p, steps) : { line: null, known: null }
  const g0 = gist(full)
  // struktura, ko prvi stavek ne pove dela (ogrevanje, odrezan) ali je ključni trening; »Lahko …; na sredi 4 × 30 s …« ostane
  const drills = main && (main.target || main.role === 'kljucna' || / …$/.test(g0) || /^(\d+\s*min\s+ogrevanj|ogrevanje\b)/i.test(g0)) ? drillGist(steps, zoneT) : ''
  const lead = race ? raceGist(full) : drills || g0
  // med tekočo vadbo (nazaj iz vadbe) kartica pove »v teku«, gumb spodaj »Nadaljuj trening« (v3.48)
  const running = !!main && runningDayId() === main.id
  const icuErr = app.settings.intervals ? icuErrOf(app) : null
  // (v3.49) danes počitek, še brez treninga (res nov uporabnik — ne po bolezni ali v off-seasonu): kdaj je prvi
  const firstTrain = !main || main.kind === 'pocitek' ? firstTraining(plan, today, { activities, profile: p }) : null

  const wide = useWide()
  const reports = (<>
    <LastWeekCard />
    {al.length > 0 && (
      <Card tight className="alerts-card">
        <h2 className="h4" style={{ fontSize: rem(11), margin: 0 }}>Opozorila</h2>
        {al.map((a, i) => (
          <button key={i} type="button" className="alert-row" onClick={() => a.to && navigate(a.to)} style={{ cursor: a.to ? 'pointer' : 'default' }}>
            <span className="dot" style={{ background: a.kind === 'bad' ? 'var(--bad)' : a.kind === 'warn' ? 'var(--warn)' : 'var(--ink-3)' }} />
            <span>{a.text}</span>
          </button>
        ))}
      </Card>
    )}
    {/* (v3.50) prvi koraki in opomnik za kopijo pod opozorili */}
    <FirstSteps />
    <BackupNudge />
  </>)

  async function buildThisWeek() {
    const rain: Record<string, number> = {}
    if (weather) for (const k in weather) rain[k] = weather[k]!.rain
    const doneDates = new Set(week.filter(d => d.done).map(d => d.date))
    const days = buildWeek({ profile: p, activities, weekStart: ws, rain, firstWeek: !plan.length, notBefore: today, done: week.filter(d => d.done).map(d => ({ date: d.date, kind: d.kind })) })
    await savePlanDays(days.filter(d => !doneDates.has(d.date)))
    toast('Teden je sestavljen.', 'ok')
  }
  /** Prejšnji (neopravljeni) dnevi za te datume — za »Razveljavi«. */
  const before = (dates: Set<string>) => getState().plan.filter(d => dates.has(d.date) && !d.done)
  async function ease() {
    const out = easeDay(week, today, pauseLock(raceLock(getState().plan, getState().profile), getState().profile))
    if (!out) return
    const prev = before(new Set(out.map(d => d.date)))
    for (const d of out) await savePlanDay(d)
    // (v3.50 A03) obvestilo pove, kam je šla seja — ali da ta teden odpade (prej »Danes lahko.« brez razloga)
    undoToast(main ? easeTexts(main, out, today).toast : 'Danes lahko.', () => restorePlanDays(prev, out.map(d => d.date)))
  }
  async function aiDay() {
    setBusy('adapt')
    // (v3.51) kontekst za AI (snap) se naloži ob klicu — ni v začetnem paketu
    const r = await ai.run(async () => {
      const { snapOf } = await import('@/state/snap')
      const s = getState(), w0 = weekStartIso(s.today)
      return adaptWeek(snapOf(s), s.plan.filter(d => d.date >= w0 && d.date <= addDays(w0, 6)), 'Prilagodi DANES in preostanek tedna glede na jutranje počutje, spanec in vreme. Opravljenih dni ne spreminjaj. Če je pripravljenost nizka, danes olajšaj in kakovostno sejo prestavi; tedenski volumen ohrani, če se da.')
    })
    setBusy(null)
    if (!r) return
    const changed = r.days.filter(d => !d.done)
    const prev = before(new Set(changed.map(d => d.date)))
    await savePlanDays(changed)
    undoToast(r.summary, () => restorePlanDays(prev, changed.map(d => d.date)), { ms: 9000 })
  }
  async function advice() {
    setBusy('advice')
    const t = await ai.run(async () => { const { snapOf } = await import('@/state/snap'); const s = getState(); return dailyAdvice(snapOf(s), !!aiLine, adviceSig(s)) })
    setBusy(null)
    if (t) { setAiLine(plainAi(t)); setStale(false) }
  }
  async function checkGarmin() {
    // (v3.52) Garmin Connect neposredno: prenos z našega strežnika (napaka in nove vadbe so v obvestilu iz store)
    if (getState().settings.garmin?.connected) {
      setChecking(true)
      const r = await syncGarmin(true).finally(() => setChecking(false))
      if (!r) return
      if (r.skipped) { toast(r.skipped, 'info', 5000); return }
      if (!r.error && !r.added && !r.upgraded) toast('Nove vožnje še ni — ura jo najprej pošlje v Garmin Connect (običajno nekaj minut po shranjeni vožnji).', 'info', 7000)
      return
    }
    const c = getState().settings.intervals
    if (!icuReady(c)) { toast('Povezava z intervals.icu ni dokončana — uredi jo v Uvozu.', 'info'); return }
    const t0 = Date.now()
    setChecking(true)
    const r = syncResult(await syncIntervals())
    setChecking(false)
    // prava napaka (odjava, kvota, omrežje) — ne »vožnje še ni«; razložena, s »počakam do …« pri kvoti
    const err = icuErrOf(getState()), fresh = err && err.at >= t0 - 1000 ? err : null
    if (fresh && !r.skipped) { toast(icuErrText(fresh), 'err', 9000); return }
    if (r.error) { toast(r.error, r.skipped ? 'info' : 'err', r.skipped ? 5000 : 9000); return }
    const n = r.added
    if (n == null) { toast(navigator.onLine === false ? 'Ni povezave z internetom — preverim, ko bo.' : 'Preverjanje že teče — poglej čez minuto.', 'info'); return }
    if (n === 0) {
      const adv = importDiagnosis(getState().icuDiag)
      toast(adv && adv.tone === 'warn' ? `${adv.title}. Pojasnilo: Nastavitve → Ura in uvoz.` : 'Nove vožnje še ni — Garmin jo najprej pošlje v intervals.icu (običajno v nekaj minutah po shranjeni vožnji).', adv && adv.tone === 'warn' ? 'err' : 'info', 8000)
    }
  }

  return (<>
    <Head hi={fmtDateLong(today)} nm={firstName ? `Živjo, ${firstName}` : 'Živjo'} />
    <div className="scroll">
      <div className="cols">
      <div className="col">
      <div className="between" style={{ marginBottom: 8, gap: 10 }}>
        {/* faza in teden sta tudi v kartici cilja — tu kratko, v eni vrstici */}
        {/* ozek telefon (320 px): »Teden 4/38« namesto »Teden 4 od 38«, da gre v eno vrstico (v3.48) */}
        <div className="clamp2" style={{ fontSize: rem(12.5), fontWeight: 700, color: 'var(--ink-3)', minWidth: 0 }}>{custom ? (p.cycleStart && p.cycleStart > today ? `Začneš ${p.cycleStart === addDays(today, 1) ? 'jutri' : `v${NBSP}${dayAcc(p.cycleStart)}`} · ${cx.phaseName}` : `Teden${NBSP}${cx.week} · ${cx.recovery ? 'lažji teden' : cx.phaseName}`) : cx.structured ? <>Teden{NBSP}{cx.week}{cx.total ? <><span className="wk-od"> od{NBSP}</span><span className="wk-sl">/</span>{cx.total}</> : null} · {cx.easy ? 'lahek začetek' : cx.recovery && cx.phase !== 'prehod' ? 'razbremenilni' : cx.phase === 'dirka' ? 'dirka' : cx.phaseName.toLowerCase()}</> : 'Ta teden'}</div>
        {ready && <Chip sm onClick={() => setReadyOpen(true)}><span className="dot" style={{ background: ready.color }} />pripravljenost {ready.score}{rec ? <IcoWatch width={13} height={13} aria-label="z ure" style={{ marginLeft: -2 }} /> : null}</Chip>}
      </div>
      {/* (v3.52) cikel: diskretna vrstica pod pripravljenostjo — faza (in napoved), ob občutljivi fazi zmeren namig; brez besed o zdravju */}
      {cyc?.phase && <div className="cyc-line muted" role="note">{PHASE_LABEL[cyc.phase]}{cyc.dayInCycle ? ` · ${cyc.dayInCycle}. dan` : ''}{cyc.predicted && !cyc.coachNote ? ' (napoved)' : ''}{cyc.coachNote ? ` — ${cyc.coachNote.replace(/^[^—]+—\s*/, '')}` : ''}</div>}
      {/* (v3.50) en postanek Tab (danes), puščice med dnevi */}
      <div className="week" role="group" aria-label="Ta teden" onKeyDown={rovingKey}>
        {weekDays.map((d, i) => {
          const items = plan.filter(x => x.date === d && x.kind !== 'pocitek' && !x.optional)
          const isToday = d === today, past = d < today
          const allDone = items.length > 0 && items.every(k => k.done)
          // ime gumba pove, kaj je na dnevu (prej samo datum; vrsto je nosila le barvna pika) (v3.48)
          // (v3.51) dan premora »Ta teden …«: »premor« in obrobljena pika (kot Plan) — prej kot navaden počitek
          const paused = !items.length && plan.some(x => x.date === d) && inPause(p, d)
          const what = items.length ? items.map(k => sessLabel(k).toLowerCase()).join(' in ') : paused ? 'premor' : plan.some(x => x.date === d) ? 'počitek' : ''
          return (
            <button key={d} type="button" {...rovingTab(i, Math.max(0, weekDays.indexOf(today)))} className={`day ${isToday ? 'today' : ''} ${past ? 'past' : ''}`} onClick={() => navigate('plan', { dan: d })} aria-label={`${dayName(d)}, ${dm(d)}${what ? `: ${what}` : ''}${allDone ? ', opravljeno' : ''}`}>
              <div className="dn">{DAYS_SL[i]}</div><div className="dd">{+d.slice(8)}</div>
              <div className="dots">{allDone ? <IcoCheck className="day-ok" width={12} height={12} aria-hidden="true" /> : items.some(k => isRace(k) && !k.done) ? <IcoTrophy className="day-race" width={12} height={12} aria-hidden="true" /> : items.length ? items.slice(0, 2).map((k, j) => <i key={j} style={{ background: isToday ? 'rgba(15,18,22,.6)' : k.done ? 'var(--accent)' : kindColor(k.kind) }} />) : <i style={paused ? { background: 'transparent', boxShadow: `inset 0 0 0 1.5px ${isToday ? 'rgba(15,18,22,.6)' : 'var(--t-poc)'}` } : { background: isToday ? 'rgba(15,18,22,.6)' : 'var(--t-poc)', opacity: .5 }} />}</div>
            </button>
          )
        })}
      </div>

      {week.length > 0 && (() => {
        const wp = weekProgress(week, activities)
        if (!wp.total) return null
        const pc = wp.minAll ? Math.min(100, Math.round((wp.minDone / wp.minAll) * 100)) : 0
        const um = unmarkedSessions(week, today)
        return (
          <button type="button" className="wk-prog" onClick={() => navigate('plan')} aria-label={`Ta teden: ${wp.done} od ${wp.total} treningov, ${fmtDur(wp.minDone)} od ${fmtDur(wp.minAll)}${um ? `, ${um} ${unmarkedWord(um)}` : ''} — odpri Plan`}>
            <span className="bar" aria-hidden="true"><i style={{ width: `${Math.max(pc, wp.minDone ? 3 : 0)}%` }} /></span>
            <span className="tx" aria-hidden="true"><b>{wp.done}/{wp.total}</b> treningov · {wp.minDone ? fmtDur(wp.minDone) : '0 min'} od {fmtDur(wp.minAll)}{um ? <span className="wk-um"> · {um} {unmarkedWord(um)}</span> : null}</span>
          </button>
        )
      })()}

      {/* najprej konkretno: današnji trening takoj pod tednom; razlogi za spremembo (počutje, zamujeni) tik pod njim */}
      {!week.length ? (
        <div style={{ marginTop: 12 }}>
          <Empty icon={<IcoCal width={30} height={30} style={{ color: 'var(--accent-fg)' }} />} title="Ta teden še ni sestavljen" text={custom && p.focus ? `${weekLine(p.focus)} · ${mixLine(p.focus)}. Sestavi se takoj, brez AI.` : `${num(cx.hours)} h · ${cx.phase === 'prehod' ? `off-season: ${OFF_MIX[offMixOf(p)].active}` : cx.easy ? 'lahek začetek: Z2, šprinti, kadenca, tempo' : cx.recovery ? 'razbremenilni teden' : 'VO2max v torek, prag v četrtek, šprinti v sredo, dolga v soboto'}${p.strength.on && p.strengthDays ? ` · moč ${Math.min(2, p.strengthDays)}×` : ''}. Sestavi se takoj, brez AI.`}>
            <Btn primary sm onClick={buildThisWeek}>Sestavi teden</Btn>
          </Empty>
        </div>
      ) : sick ? (
        <SickCard />
      ) : pause && (!main || main.kind === 'pocitek') ? (
        <WeekPauseCard onChange={() => setPauseOpen(true)} onSick={() => setSickOpen(true)} />
      ) : main && main.kind !== 'pocitek' ? (
        <Card className="sess spot" style={{ marginTop: 12, ['--c' as string]: main.optional ? 'var(--t-poc)' : sessColor(main) }}>
          <div>
            <div className="between">
              <div className={`kbadge${race ? ' race' : ''}`} style={race ? { color: sessInk(main) } : undefined}><span className="ki"><SessIcon d={main} /></span>{sessLabel(main)} · {main.optional ? 'po želji' : 'danes'}</div>
              {main.done ? <Chip sm on>{partialLine(main, activities) ?? 'opravljeno'}</Chip> : running ? <Chip sm on>v teku</Chip> : null}
            </div>
            {/* (v3.51) naslov: bralnik zaslona po naslovih skoči na današnji trening */}<h2 className="ttl">{baseTitle(main)}</h2>
            {/* glavne številke seje: velike, na prvi pogled */}
            <div className="kpis">
              {main.durationMin > 0 && <div className="kpi"><b>{fmtDur(main.durationMin)}</b><small>trajanje</small></div>}
              {/* intenzivnost z besedo; tap → kaj pomenijo cone (cela ploščica je gumb — dovolj velik cilj dotika) */}
              {eff ? (eff.sub.startsWith('Z')
                ? <button type="button" className="kpi kpi-btn" onClick={() => openHelp('cona')} aria-label={`${eff.w}, cona ${eff.sub} — kaj pomenijo cone?`}><b>{eff.w}</b><small>{eff.sub}</small></button>
                : <div className="kpi"><b>{eff.w}</b><small>{eff.sub}</small></div>) : null}
              {main.exercises?.length ? <div className="kpi"><b>{main.exercises.length}</b><small>{plural(main.exercises.length, W.vaja)}</small></div> : null}
            </div>
            {/* profil vadbe, ko ima strukturo (intervali, tempo) — vidiš jo brez branja */}
            {steps.filter(x => x.kind === 'delo').length >= 2 ? <StepsBar steps={steps} height={34} /> : null}
            {/* »Tempo:« samo, ko ni vrstice s cono — sicer intenzivnost trikrat (v3.48) */}
            {eff && !main.done && !zoneLine && !/utrip|\d\s?W\b|% FTP/.test(main.desc || '') && <div className="talk">Tempo: {eff.talk}.</div>}
            {(() => {
              // na hitro (Blaž, 16. 10.: »kdo bo ta besedila bral«): en stavek, vaje kot ploščice; ostalo pod »Podrobnosti«
              // struktura vaj ali tempo tekme namesto prvega stavka: cel opis je pod »Podrobnosti« (v3.48)
              const fullMore = race || drills ? full.trim().length > 0 : hasMore(full)
              const more = fullMore || !!main.tail?.desc || !!main.why || (outdoor && wx && main.kind !== 'moc' && !main.done)
              return (<>
                {lead && <p className="sess-gist">{nb(lead)}</p>}
                {zoneLine && <div className="row" style={{ gap: 8, marginTop: 8, fontSize: rem(13), fontWeight: 700, color: 'var(--ink)', alignItems: 'flex-start' }}><IcoTarget width={16} height={16} style={{ color: 'var(--c)', flex: 'none', marginTop: 2 }} /><span>{zoneLine}</span></div>}
                {main.exercises?.length ? <ExGrid exercises={main.exercises} done={main.done?.activityId ? activities.find(a => a.id === main.done!.activityId)?.exercises ?? null : null} /> : null}
                {main.tail && <TailRow tail={main.tail} brief />}
                {outdoor && wx && <div style={{ fontSize: rem(12), marginTop: 8, fontWeight: 600, color: wxBad(wx) ? 'var(--warn)' : 'var(--ink-3)' }}>{wxShort(wx)}{wxBad(wx) && main.kind === 'kolo' ? (p.gear.trainer ? ' — raje trenažer' : ' — premakni ali se dobro obleci') : ''}</div>}
                {/* (v3.50) po opravljenem »Podrobnosti« ostanejo (opis je bil odrezan z »…«, podrobnosti pa so izginile) — brez oblačil */}
                {more && (
                  <details className="more">
                    <summary>Podrobnosti</summary>
                    <div>
                      {fullMore && <p style={{ margin: 0 }}>{nb(full)}</p>}
                      {main.tail?.desc && <p style={{ margin: '6px 0 0' }}><b style={{ color: 'var(--ink-2)' }}>Nato:</b> {main.tail.desc}</p>}
                      {outdoor && wx && main.kind !== 'moc' && !main.done && <p style={{ margin: '6px 0 0' }}><b style={{ color: 'var(--ink-2)' }}>Obleci:</b> {clothing(wx)}.</p>}
                      {main.why && <p style={{ margin: '6px 0 0' }}><b style={{ color: 'var(--ink-2)' }}>Zakaj:</b> {main.why}</p>}
                    </div>
                  </details>
                )}
              </>)
            })()}
            {/* nizka pripravljenost pri treningu: razlogi z ure IN iz jutranjega vnosa (prej samo z ure) (v3.48) */}
            {ready && ready.score < 60 && ready.reasons.length > 0 && !main.done && !main.optional && <button type="button" onClick={() => setReadyOpen(true)} style={{ ...TEXT_BTN, fontSize: rem(12), marginTop: 8, color: 'var(--warn)', fontWeight: 600 }}>Pripravljenost {ready.score}: {[...new Set(ready.reasons)].map(r => (/span/.test(r) && rec?.sleepH != null && checkinToday?.sleepH == null ? `${r} (${fmtSleep(rec.sleepH)})` : r)).join(', ')}. {race ? 'Začni mirneje in poslušaj telo.' : ready.score < 45 ? 'Danes raje lažje.' : canEase ? 'Če se ne počutiš dobro, olajšaj dan.' : 'Če se ne počutiš dobro, naredi manj.'}</button>}
            {/* (v3.52) trd dan v občutljivi fazi cikla: namig ob »Olajšaj dan« (pod Spremeni) — brez spreminjanja načrta samo od sebe */}
            {cyc?.easeOffer && canEase && !main.done && <button type="button" className="cyc-ease" onClick={() => setChangeOpen(true)} style={{ ...TEXT_BTN, fontSize: rem(12), marginTop: 8, color: 'var(--ink-2)', fontWeight: 600 }}>Trd dan v {cyc.phase === 'menstrualna' ? 'menstrualni' : 'pozni lutealni'} fazi — če se ne počutiš dobro, ga olajšaj (Spremeni → Olajšaj dan).</button>}
            {!main.done && (
              <>
              {/* dva gumba (Blaž, 11. 10.: čim manj tipk): opravil in spremeni — vse drugo (Garmin, olajšaj, AI, nazaj) je pod »Spremeni« */}
              <div className="row" style={{ gap: 8, marginTop: 13, flexWrap: 'wrap' }}>
                <Btn ghost sm onClick={() => setPlanDone(main.id, true)}><IcoCheck width={15} height={15} /> {g(p, 'Opravil', 'Opravljeno')}</Btn>
                <Btn ghost sm disabled={checking || (busy === 'adapt' && ai.busy)} onClick={() => setChangeOpen(true)}>{checking ? 'Preverjam Garmin …' : busy === 'adapt' && ai.busy ? 'Prilagajam …' : 'Spremeni'} <IcoChevDown width={15} height={15} aria-hidden="true" /></Btn>
              </div>
              {/* (v3.50) posnetek ure, Zwifta ali naprave → vadba in kljukica (brez ure in intervals.icu) */}
              <button type="button" className="chip sm click ph-shot" onClick={() => openPhotoTraining({ mode: 'done', dayId: main.id })}><IcoCamera width={14} height={14} aria-hidden="true" /> Slikaj opravljen trening</button>
              {(main.swap || (main.adapt?.prev && !main.adapt.off)) && <div className="muted" style={{ fontSize: rem(11.5), marginTop: 6 }}>{main.swap ? 'Namesto kolesa — ' : 'Samodejno prilagojeno — '}prvotni trening vrneš pod »Spremeni«.</div>}
              {/* (v3.51) zvečer, ko trening ne gre več v dan (do 22h): »Danes ne gre« (premakni, skrajšaj) — prej samo »Začni trening« */}
              {!race && !main.optional && !main.byState && tooLate(main.durationMin, new Date()) && <div className="late-row"><span>Za {fmtDur(main.durationMin)} je danes že pozno.</span><button type="button" className="chip sm click" onClick={() => setSkipDay(main)}>Danes ne gre ›</button></div>}
              </>
            )}
            {main.done && (() => {
              const act = main.done?.activityId ? activities.find(a => a.id === main.done!.activityId) : null
              const c = act ? checkRide(main, act) : null
              if (!c) return null
              const key = main.role === 'kljucna' || main.role === 'test'
              const plan0 = key && c.status !== 'ok' ? moveKeyPlan(week, main, today, raceLock(plan, app.profile)) : null
              const mv = plan0?.days ?? null
              const nextKey = key && c.status !== 'ok' && !mv ? plan.filter(d => d.date > today && (d.role === 'kljucna' || d.role === 'test') && !d.done).sort((a, b) => a.date.localeCompare(b.date))[0] : null
              return (
                <div style={{ marginTop: 10, paddingTop: 10, borderTop: '1px solid var(--line)' }}>
                  <div style={{ fontSize: rem(13), fontWeight: 700, color: c.status === 'ok' ? 'var(--ok)' : c.status === 'delno' ? 'var(--warn)' : 'var(--bad)' }}>{c.verdict}</div>
                  <div className="muted" style={{ fontSize: rem(12), marginTop: 2 }}>{c.detail}</div>
                  {mv && <Btn ghost sm style={{ marginTop: 8 }} onClick={async () => { const to = await moveKeyToLater(main.id); toast(to ? `${main.title} je prestavljen na ${dayAcc(to)}. Danes šteje kot ${mv[0].title}.` : 'Ta teden ni več prostega lahkega dne — izpusti ga.', to ? 'ok' : 'info', 7000) }}>Prestavi na {dayAcc(mv[1].date)}</Btn>}
                  {key && c.status !== 'ok' && !mv && <div className="muted" style={{ fontSize: rem(12), marginTop: 6 }}>{plan0?.reason || 'Izpusti ga — naslednji ključni trening pride po načrtu.'}{nextKey ? ` Naslednji ključni: ${nextKey.title}, ${dayName(nextKey.date)}, ${dm(nextKey.date)}` : ''}</div>}
                </div>)
            })()}
            {/* (v3.51) po testu: rezultat in kaj se je spremenilo (prej samo »opravljeno«) */}
            {main.done && (main.kind === 'test' || main.role === 'test') && (() => { const t = testLine(app.settings.tests ?? [], today); return t ? <div className="test-res" style={{ marginTop: 10, fontSize: rem(13), fontWeight: 700, color: 'var(--ink)' }}>{t}</div> : null })()}
            {main.done && (() => {
              // kako je šlo: en tap — gre na vadbo (če je povezana) ali na dan načrta
              const act = main.done?.activityId ? activities.find(a => a.id === main.done!.activityId) : null
              return <div style={{ marginTop: 10 }}><RateRow label="Kako je šlo?" value={act?.rpe ?? main.rpe ?? null} onPick={v => void rateSession({ activityId: act?.id ?? null, dayId: main.id }, v)} /></div>
            })()}
            {/* (v3.49) brez ure: koliko šteje (po načrtu ali krajše) */}
            {main.done && <DoneMinutes day={main} />}
            {main.done && <button className="chip sm click" style={{ marginTop: 12 }} onClick={() => setPlanDone(main.id, false)}>razveljavi</button>}
          </div>
        </Card>
      ) : (
        <Card className="sess spot" style={{ marginTop: 12, ['--c' as string]: 'var(--t-poc)' }}>
          {/* (v3.49) prvi dan počitek: kdaj je prvi trening; »Bolan sem« tudi takrat (bolezen ne čaka prvega treninga) */}
          <div><div className="kbadge"><span className="ki"><KindIcon kind="pocitek" /></span>Počitek · danes</div><h2 className="ttl">Dan brez treninga</h2>
            {firstTrain ? <FirstTraining day={firstTrain} today={today} /> : <p style={{ fontSize: rem(13), marginTop: 6 }}>Hoja, raztezanje, spanec. Prilagoditev se zgodi med počitkom.</p>}
            {/* (v3.50) pot do treninga tudi z Danes: »Dodaj trening« (Plan, ta dan) in »Jedro po želji« — prej samo »Bolan sem« */}
            <div className="row" style={{ gap: 6, marginTop: 10, flexWrap: 'wrap' }}>
              <button type="button" className="chip sm click" onClick={() => navigate('plan', { dan: today })}>Dodaj trening</button>
              <button type="button" className="chip sm click" onClick={() => openPhotoTraining({ mode: 'plan', date: today })}>Trening s slike</button>
              {!todayPlan.some(x => x.kind === 'moc') && <button type="button" className="chip sm click" disabled={coreBusy} onClick={() => void addCoreOnce()}>Jedro po želji (20 min)</button>}
              <button type="button" className="chip sm click" onClick={() => setPauseOpen(true)}>Ta teden …</button>
              <button type="button" className="chip sm click" onClick={() => setSickOpen(true)}>{g(p, 'Bolan sem', 'Bolna sem')}</button>
            </div></div>
        </Card>
      )}

      {extra.map(x => (
        <Card key={x.id} tight className="sess" style={{ marginTop: 8 }}>
          <div className="bar" style={{ background: kindColor(x.kind) }} />
          {/* dodatna moč (v3.48): »20 min«, razpon ponovitev se ne prelomi, »Opravil« tudi brez vodene vadbe */}
          <div className="between" style={{ paddingLeft: 6, gap: 10, flexWrap: 'wrap' }}>
            <div style={{ minWidth: 0, flex: '1 1 170px' }}>
              <div style={{ fontSize: rem(11), fontWeight: 800, letterSpacing: '.08em', color: kindInk(x.kind) }}>+ {kindLabel(x.kind).toUpperCase()} · {fmtDur(x.durationMin)}</div>
              <b style={{ fontSize: rem(14) }}>{x.title}</b>
              {/* (v3.50) ime vaje je gumb (kako se izvaja); po vodeni vadbi narejene ponovitve namesto načrta */}
              {x.exercises?.length ? (() => { const log = x.done?.activityId ? activities.find(a => a.id === x.done!.activityId)?.exercises ?? null : null; return (
                <div className="muted" style={{ fontSize: rem(12) }}>{x.exercises.map((e, i) => { const id = exByName(e.name)?.id, l = exLogOf(log, e.name); const miss = !!log?.length && x.exercises!.some(z => log.some(q => q.name.toLowerCase() === z.name.toLowerCase())) && !log.some(q => q.name.toLowerCase() === e.name.toLowerCase()); const t = nb(l ? `${e.name} ${l.reps}` : miss ? `${e.name} — ni narejeno` : `${e.name} ${e.sets}×${e.reps}`); return <span key={i}>{i ? ' · ' : ''}{id ? <button type="button" className="ex-lnk" onClick={() => navigate('vaje', { v: id })} aria-label={`${e.name} — kako se izvaja`}>{t}</button> : t}</span> })}</div>) })() : null}
            </div>
            {/* (v3.50) »Začni moč« — gumb spodaj začne kolo, da nista dva »Začni« */}
            {x.done ? <Chip sm on>{partialLine(x, activities) ?? 'opravljeno'}</Chip> : <div className="row" style={{ gap: 6, flex: 'none' }}><Btn ghost sm onClick={() => navigate('vadba', { id: x.id })}>Začni moč</Btn><Btn ghost sm onClick={() => setPlanDone(x.id, true)}><IcoCheck width={15} height={15} /> {g(p, 'Opravil', 'Opravljeno')}</Btn></div>}
          </div>
        </Card>
      ))}

      {pause && !sick && main && main.kind !== 'pocitek' && <WeekPauseCard compact />}
      <StateCard />
      <MovedCard />
      <OffSeasonCard />
      {/* (v3.50) »Včeraj: … — si ga naredil?« takoj pod treningom (odloča o prestavitvi ključnega) — prej pod Prvimi koraki in opomnikom za kopijo */}
      <YesterdayRate />
      {/* jutranji vnos: neizpolnjen takoj pod treningom (spremeni lahko današnji dan), izpolnjen čisto spodaj */}
      {ciTop && <div style={{ marginTop: 12 }}><Checkin compact extra={weightRow} /></div>}

      <LoadAdaptCard date={addDays(today, -1)} actionOnly />
      <LoadAdaptCard date={today} />

      {week.length > 0 && <TomorrowCard plan={plan} today={today} weather={weather} todayDone={!main || main.kind === 'pocitek' || !!main.done} />}

      {(routeOk || (fuel && !main?.done)) && main && (
        <Card tight className="for-day">
          {/* (v3.50) zložena vrstica pove stanje: brez povezave ali brez tras ne obljublja predloga, GPX in ure */}
          {routeOk && <Fold id="trasa" title="Trasa za ta trening" sum={routeSum(icuReady(app.settings.intervals), routesOf(app.routeLib).length > 0, !!app.routeLib?.home)}><RouteCard day={main} inCard={false} /></Fold>}
          {fuel && !main.done && (
            <Fold id="gorivo" title="Gorivo za ta trening" sum={rf ? `${rf.bottles} ${rf.bottles === 1 ? 'bidon' : rf.bottles === 2 ? 'bidona' : rf.bottles <= 4 ? 'bidoni' : 'bidonov'}${rf.totalCarbs > 0 ? ` · ~${rf.carriedCarbs} g ogljikovih hidratov` : ' · samo voda'}` : 'pred, med in po treningu'}>
              <div className="stack" style={{ gap: 6 }}>
                {([['Pred', fuel.before], ['Med', rf && rf.cues.length ? drinkLine(rf) : rf ? rf.schedule : fuel.during], ['Vzemi', rf ? rf.items.join(' · ') : ''], ['Po', fuel.after]] as const).filter(([, t]) => t).map(([l, t]) => <div key={l} style={{ display: 'grid', gridTemplateColumns: '46px 1fr', gap: 8, fontSize: rem(12.5) }}><b style={{ color: 'var(--ink)' }}>{l}</b><span style={{ color: 'var(--ink-2)' }}>{nb(plainOH(t))}</span></div>)}
              </div>
              {rf && <FuelTimeline rf={rf} minutes={main.durationMin} />}
            </Fold>
          )}
        </Card>
      )}
      {main && !main.optional && main.done && (main.kind === 'kolo' || main.kind === 'test') && rf && rf.totalCarbs > 0 && <FuelLogCard day={main} rf={rf} meals={mealsToday} kit={p.fuelKit} />}

      {/* poročila in opomniki šele pod treningom */}
      {icuErrActive(icuErr) && <div style={{ marginTop: 12 }}><IcuErrorCard err={icuErr} /></div>}
      {/* (v3.51) širok zaslon (≥ 1200 px): poročila in opomniki v desnem stolpcu (prej levo ~900 px dlje kot desno) */}
      {!wide && reports}
      {!ciTop && <div style={{ marginTop: 12 }}><Checkin compact fold={firstDay} extra={weightRow} /></div>}

      </div>
      <div className="col">
      {/* dogovor je na Planu (Blaž, 16. 10.: na Danes samo, kaj danes, in teden) */}
      {!custom && <GoalCard compact />}

      {/* forma šele, ko jo je iz česa izračunati; brez nje kalorije, beljakovine in naslednji obrok v eni kartici */}
      {hasForm ? (
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 12 }}>
        <div style={{ position: 'relative', display: 'flex' }}>
        <button type="button" className="card tight" style={{ textAlign: 'left', width: '100%', cursor: 'pointer' }} onClick={() => navigate('napredek', { sec: 'p-motor' })} aria-label={`Forma${few ? ': še računam' : band ? `: ${band.band}` : ''} — odpri Napredek`}>
          <h2 className="h4" style={{ fontSize: rem(11) }}>Forma</h2>
          {/* (v3.50) pod 3 vadbami v 28 dneh ni »dober +1 · premalo zgodovine« — »še računam« */}
          {last && series.length > 3 && few ? (<>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 2 }}><b style={{ fontSize: rem(18), fontWeight: 800, letterSpacing: '-.03em', color: 'var(--ink-2)' }}>še računam</b></div>
            <div style={{ marginTop: 5 }}><Sparkline values={spark} /></div>
            <div className="muted" style={{ fontSize: rem(11), fontWeight: 600, marginTop: 2 }}>po 3 vadbah pokažem formo</div>
          </>) : last && series.length > 3 ? (<>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 2 }}>
              <b style={{ fontSize: rem(22), fontWeight: 800, letterSpacing: '-.03em', color: band!.color === 'ok' ? 'var(--ok)' : band!.color === 'bad' ? 'var(--bad)' : band!.color === 'warn' ? 'var(--warn)' : 'var(--ink)' }}>{band!.band}</b>
              <span className="muted" style={{ fontSize: rem(11.5), fontWeight: 700 }}>{signed(Math.round(last.tsb), 0)}</span>
            </div>
            <div style={{ marginTop: 5 }}><Sparkline values={spark} /></div>
            <div className="muted" style={{ fontSize: rem(11), fontWeight: 600, marginTop: 2 }}>{formEst ? 'ocena · premalo zgodovine' : (p.sex === 'z' ? FORM_WORD_F : FORM_WORD)[band!.band] ?? ''}</div>
          </>) : (<p style={{ fontSize: rem(12), marginTop: 4 }}>Po nekaj aktivnostih pokažem formo.</p>)}
        </button>
        <button type="button" className="tile-help" onClick={() => openHelp('forma')} aria-label="Kaj je forma?">?</button>
        </div>
        <button type="button" className="card tight" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', width: '100%', cursor: 'pointer' }} onClick={() => navigate(target ? 'prehrana' : 'nastavitve')} aria-label={target ? 'Kalorije — odpri Prehrano' : 'Za kalorije izpolni profil — odpri Nastavitve'}>
          {target ? (<>
            <Ring rest pct={eaten.kcal / target.kcal}><div><b className="num" style={{ fontSize: rem(19) }}>{shownKcal}</b><small>od {fmtKcal(target.kcal)}</small></div></Ring>
            <div className="kc-left" style={{ fontSize: rem(11), color: 'var(--ink-3)', fontWeight: 700, marginTop: 3 }}><span className="kc-l">KALORIJE · </span>ŠE {fmtKcal(Math.max(0, target.kcal - eaten.kcal))}</div>
          </>) : (<>
            <IcoFood style={{ color: 'var(--ok)' }} /><div style={{ fontSize: rem(12.5), color: 'var(--ink)', fontWeight: 700, marginTop: 6, textAlign: 'center' }}>Za kalorije izpolni profil</div><div className="muted" style={{ fontSize: rem(11), marginTop: 2, textAlign: 'center' }}>višina, teža, starost, spol</div>
          </>)}
        </button>
      </div>
      ) : target ? null : (
        <button type="button" className="card tight" style={{ display: 'flex', alignItems: 'center', gap: 12, width: '100%', marginTop: 12, cursor: 'pointer', textAlign: 'left' }} onClick={() => navigate('nastavitve')} aria-label="Za kalorije izpolni profil — odpri Nastavitve">
          <IcoFood style={{ color: 'var(--ok)', flex: 'none' }} /><span><b style={{ fontSize: rem(13) }}>Za kalorije izpolni profil</b><small className="muted" style={{ display: 'block', fontSize: rem(11.5) }}>višina, teža, starost, spol</small></span>
        </button>
      )}
      {/* eno opozorilo na zaslonu, tik pod številom kalorij: velja za kalorije in za današnji trening */}
      {target && hasForm && <HealthNote kind="both" style={{ margin: '10px 4px 0' }} />}

      {target && (
        <Card tight style={{ marginTop: 12 }}>
          {!hasForm && (
            <button type="button" className="food-top" onClick={() => navigate('prehrana')} aria-label="Kalorije — odpri Prehrano">
              <Ring rest pct={eaten.kcal / target.kcal}><div><b className="num" style={{ fontSize: rem(19) }}>{shownKcal}</b><small>od {fmtKcal(target.kcal)}</small></div></Ring>
              <span className="food-top-t"><small>KALORIJE</small><b>še {fmtKcal(Math.max(0, target.kcal - eaten.kcal))}{NBSP}kcal</b></span>
            </button>
          )}
          <div className="between" style={{ fontSize: rem(13) }}><span className="muted" style={{ fontWeight: 600 }}>Beljakovine</span><b>{Math.round(eaten.p)} / {target.proteinG}{NBSP}g</b></div>
          <div style={{ marginTop: 6 }}><Track pct={eaten.p / target.proteinG * 100} color="var(--accent)" /></div>
          {todaysActs.length > 0 && <div className="muted" style={{ fontSize: rem(11.5), marginTop: 6 }}>Danes porabljeno na treningu ~{fmtKcal(todaysActs.reduce((s, a) => s + activityKcal(a, p), 0))}{NBSP}kcal — že vključeno v cilj.</div>}
          {nextMeal && <button type="button" style={{ ...TEXT_BTN, display: 'block', width: '100%', textAlign: 'left', fontSize: rem(12.5), marginTop: 0, padding: '11px 0', color: 'var(--ink-2)' }} onClick={() => navigate('prehrana', { recept: nextMeal.slot.key })} aria-label={`Naslednji obrok: ${nextMeal.slot.label}, ${nextMeal.r.name} — odpri Prehrano`}><b style={{ color: 'var(--ink)' }}>{nextMeal.slot.label}{nextMeal.slot.when && !(nextMeal.slot.key === 'zajtrk' && nextMeal.slot.when === 'zjutraj') ? ` · ${nextMeal.slot.when}` : ''}:</b> {nextMeal.r.name} <span className="muted">· {fmtKcal(nextMeal.r.kcal)}{NBSP}kcal · B {nextMeal.r.p}{NBSP}g · recept{NBSP}›</span></button>}
          {raceNear && <button type="button" style={{ ...TEXT_BTN, fontSize: rem(12), marginTop: 8, color: 'var(--ink-2)' }} onClick={() => navigate('prehrana')}><b style={{ color: 'var(--warn)' }}>Malo vlaknin</b> · {raceNear.inDays === 0 ? `${raceNear.name} je danes — do starta brez polnozrnatega, stročnic in solate.` : `${raceNear.name} je ${whenSl(raceNear.inDays)}: bel kruh, riž, testenine, krompir brez lupine; brez polnozrnatega, stročnic, solate in oreškov.`}</button>}
        </Card>
      )}

      {target && !hasForm && <HealthNote kind="both" style={{ margin: '10px 4px 0' }} />}

      {(aiLine || activities.length > 0 || app.user) && <div className="card tight hover" style={{ marginTop: 12, display: 'flex', gap: 11, alignItems: 'flex-start' }}>
        <div style={{ width: 30, height: 30, borderRadius: 'var(--r-s)', background: 'var(--accent-soft)', display: 'grid', placeItems: 'center', flex: 'none', color: 'var(--accent-fg)' }}><IcoChat width={16} height={16} /></div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="between"><b style={{ fontSize: rem(13) }}>Trener pravi</b><button className="chip sm click" onClick={() => navigate('trener')}>vprašaj ›</button></div>
          <ClampText text={aiLine || coachLine(last?.tsb ?? null, main, seen, activities.length, ready?.score ?? null, { sick, few, carbs: rf ? rf.totalCarbs : null, tomorrow: tomorrowMain, pause: !!pause && (!main || main.kind === 'pocitek'), f: p.sex === 'z', nextHard: nextHardOf(plan, today) })}>
            {stale && !aiLine && app.user && <span className="muted" style={{ fontSize: rem(12), alignSelf: 'center' }}>Načrt se je spremenil — osveži nasvet.</span>}
            {app.user && <button className="chip sm click" disabled={ai.busy} onClick={advice}>{busy === 'advice' && ai.busy ? 'Razmišljam …' : aiLine || stale ? 'osveži nasvet' : 'AI nasvet za danes'}</button>}
          </ClampText>
        </div>
      </div>}


      {!target && <HealthNote kind="plan" style={{ padding: '0 4px', marginTop: 12 }} />}
      {wide && reports}

      </div>
      </div>
    </div>
    <WeighSheet open={weigh} onClose={() => setWeigh(false)} />
    {guide && <Guide open onClose={() => setGuide(false)} />}
    <SickSheet open={sickOpen} onClose={() => setSickOpen(false)} />
    <WeekPauseSheet open={pauseOpen} onClose={() => setPauseOpen(false)} onSick={() => setSickOpen(true)} />
    {skipDay && <SkipSheet day={skipDay} canMove={canMove(skipDay, today, raceLock(plan, p))} onClose={() => setSkipDay(null)} onMove={() => setMoveDay(skipDay)} onSick={() => setSickOpen(true)} onWeek={() => setPauseOpen(true)} />}
    {moveDay && <MoveDaySheet day={moveDay} onClose={() => setMoveDay(null)} />}
    {changeOpen && main && <ChangeDaySheet day={main} onClose={() => setChangeOpen(false)} opts={[
      ...((main.kind === 'kolo' || main.kind === 'test') && (app.settings.intervals || app.settings.garmin?.connected) ? [{ t: 'Preveri Garmin', d: 'Preverim, ali je nova vožnja z ure že tu.', go: () => { void checkGarmin() } }] : []),
      ...(!main.optional && ready && ready.score < 60 && app.user ? [{ t: 'AI prilagodi dan', d: 'Po počutju, spancu in vremenu.', go: () => { void aiDay() } }] : []),
      ...(main.swap ? [{ t: 'Nazaj na kolo', d: 'Kot je bilo v načrtu.', go: () => { void backToBike(main.id).then(() => toast('Nazaj na kolo.', 'ok')) } }] : []),
      ...(main.adapt?.prev && !main.adapt.off ? [{ t: 'Vrni prvotni trening', d: 'Samodejna prilagoditev se razveljavi.', go: () => { void undoLoadAdaptOf(main.adapt!.after).then(() => toast('Vrnjen prvotni načrt.', 'ok')) } }] : []),
      ...(canMove(main, today, raceLock(plan, p)) ? [{ t: 'Premakni na drug dan', d: 'Zamenjaš z dnem tega ali naslednjega tedna.', go: () => setMoveDay(main) }] : []),
      ...(!main.byState ? [{ t: 'Danes ne gre', d: 'Noge, čas, vreme — povej zakaj, prilagodim.', go: () => setSkipDay(main) }] : []),
      { t: 'Ta teden …', d: pause ? 'Premor velja — spremeni ali prekliči.' : 'Brez treningov ali brez kolesa do nedelje.', go: () => setPauseOpen(true) },
      { t: 'Trening s slike', d: 'Tabla v fitnesu, list ali objava — dodam v načrt.', go: () => openPhotoTraining({ mode: 'plan', date: today }) },
      ...(canHike(main) ? [{ t: 'Hribi namesto kolesa', d: 'Enako lahko, peš — samo danes.', go: () => { void hikeInstead(main.id).then(() => toast('Hribi namesto kolesa — trening za danes gre z ure.', 'ok')) } }] : []),
      ...(canEase && easeTx ? [{ t: 'Olajšaj dan', d: cyc?.easeOffer ? `${cyc.phase === 'menstrualna' ? 'Menstrualna' : 'Pozna lutealna'} faza in trd dan — lahko olajšaš. ${easeTx.sub}` : easeTx.sub, go: () => { void ease() } }] : []),
      { t: g(p, 'Bolan sem', 'Bolna sem'), d: 'Počitek nekaj dni, prehrana brez deficita.', go: () => setSickOpen(true) },
    ] satisfies ChangeOpt[]} />}
    {readyOpen && ready && <ReadinessSheet open onClose={() => setReadyOpen(false)} ready={ready} rec={rec} tsb={last ? last.tsb : null} checkin={checkinToday} wellnessOn={wellOn} hasIntervals={!!app.settings.intervals} garmin={!!app.settings.garmin?.connected} device={watchName} onEase={canEase ? () => { void ease() } : null} />}
    {ai.sheet}
  </>)
}

/** Dolgo besedilo AI: tri vrstice in »Preberi vse«. Gumbi (children) so v isti vrstici pod besedilom. */
function ClampText({ text, children }: { text: string; children?: React.ReactNode }) {
  const ref = useRef<HTMLParagraphElement>(null)
  const [open, setOpen] = useState(false)
  const [over, setOver] = useState(false)
  useLayoutEffect(() => {
    const el = ref.current
    if (!el || open) return
    const check = () => setOver(el.scrollHeight > el.clientHeight + 2)
    check()
    window.addEventListener('resize', check)
    return () => window.removeEventListener('resize', check)
  }, [text, open])
  useEffect(() => { setOpen(false) }, [text])
  const clamp: React.CSSProperties = open ? {} : { display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden' }
  return (<>
    <p ref={ref} style={{ fontSize: rem(13), marginTop: 4, whiteSpace: 'pre-wrap', ...clamp }}>{text}</p>
    {(over || open || children) && (
      <div className="row" style={{ gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
        {(over || open) && <button type="button" className="chip sm click" aria-expanded={open} onClick={() => setOpen(!open)}>{open ? 'Skrij' : 'Preberi vse'}</button>}
        {children}
      </div>
    )}
  </>)
}

/**
 * Vrstica cilja (◎) na kartici treninga in cilj, ki ga ta vrstica že pove (`known` — v strukturi vaj ga ne ponovimo).
 * (v3.48) »intervali« samo pri ključnem treningu, Z2 vožnja s tempom »tempo« (cona Z3, ne Z4), drugo (predaktivacija)
 * »pospeški«; kratki napori brez merilnika po občutku kot koraki (»RPE 9 · po občutku«), ne »utrip nad 184«.
 */
export function zoneLineOf(main: PlanDay, p: Profile, steps: readonly Step[]): { line: string | null; known: string | null } {
  const zoneOf = main.zone && /^Z[1-5]$/.test(main.zone) ? zoneText(p, main.zone as 'Z2') : null
  const feelT = steps.find(s => s.kind === 'delo' && s.group != null && /po občutku/.test(s.target || ''))?.target ?? null
  const word = main.role === 'kljucna' ? 'intervali' : workZone(main.zone) === 'Z3' ? 'tempo' : 'pospeški'
  const known = main.target ? feelT ?? workText(p, main)
    : main.kind === 'kolo' && zoneOf && !main.desc.includes(zoneOf) ? (feelT && /^Z[45]$/.test(main.zone || '') ? feelT : zoneOf) : null
  if (!known) return { line: null, known: null }
  return { line: main.target || known === feelT ? `${word} ${known}` : `${main.zone} · ${known}`, known }
}

/** (v3.50) zložena vrstica »Trasa za ta trening« po stanju: povezava, trase, dom (za »Nova trasa«) */
/** (v3.50) tempo teže v okviru nihanja (ali pod 0,1 kg na teden) je »stabilna« — isto kot Napredek (prej −0,05 zeleno) */
export function weightStable(tr: { deltaWeek: number | null; noise?: number | null }): boolean {
  return tr.deltaWeek != null && Math.abs(tr.deltaWeek) <= Math.max(0.1, tr.noise ?? 0.05)
}
export function routeSum(connected: boolean, hasRoutes: boolean, home: boolean): string {
  if (!connected) return home ? 'poveži uro ali nariši novo' : 'poveži intervals.icu za predloge'
  if (!hasRoutes) return home ? 'nariši novo traso' : 'tvoje trase še prihajajo z ure'
  return 'predlog po meri treninga · GPX · na uro'
}

/** (v3.50) kar lokalni nasvet še upošteva: bolezen, malo vadb (< 3 v 28 dneh), OH na tekmi, jutrišnja seja */
export interface CoachOpts { sick?: boolean; few?: boolean; carbs?: number | null; tomorrow?: { kind: string; title: string; durationMin?: number } | null; /** (v3.50) premor »Ta teden …« in danes brez treninga */ pause?: boolean
  /** (v3.51) uporabnica: ženske oblike (»Dolgo si trenirala manj«) */ f?: boolean
  /** (v3.51) prvi trd trening v 14 dneh (»v torek, 27. 10.«) — po dolgem premoru nasvet ne sme reči »dva tedna brez trdih« */ nextHard?: string | null }
/** Lokalni nasvet »Trener pravi« (brez AI) — iz forme, današnjega dne in pripravljenosti. */
export function coachLine(tsb: number | null, main: { kind: string; title?: string; durationMin?: number; optional?: boolean; role?: string | null; zone?: string | null; raceId?: string | null; done?: unknown } | null, aiSeen: number, total: number, ready: number | null, o: CoachOpts = {}): string {
  // (v3.50) bolezen: počitek, tekočina, spanec — ne »drži se načrta« (H13)
  const f = !!o.f
  const tr = f ? 'Dolgo si trenirala manj' : 'Dolgo si treniral manj', sv = f ? 'Sveža si' : 'Svež si'
  if (o.sick) return f ? 'Bolna si — danes samo počitek, tekočina in spanec. Ko si zdrava, tapni »Spet zdrava«.' : 'Bolan si — danes samo počitek, tekočina in spanec. Ko si zdrav, tapni »Spet zdrav«.'
  // (v3.50) premor po tvoji izbiri: brez »drži se načrta« in brez priganjanja
  if (o.pause) return 'Ta teden premor po tvoji izbiri — danes brez treninga. Sprehod po želji, spanec in hrana; po premoru greva naprej postopno.'
  if (!total) return 'Nasvet za danes iz tvojega načrta in počutja — tapni spodaj.'
  if (aiSeen === 0) return `Vidim ${count(total, W.aktivnost)}, a nobena ni iz vira, ki ga smem uporabiti. Poveži uro neposredno z intervals.icu ali naloži datoteke.`
  const done = !!main && main.kind !== 'pocitek' && !!main.done
  // dan tekme: nikoli »brez trdih intervalov« ali »olajšaj dan« (v3.48); (v3.50) kratka tekma brez OH: »samo voda«, ne »po urniku goriva«
  if (main && (main.role === 'dirka' || main.raceId) && !done) return o.carbs === 0 ? 'Danes je tekma. Zajtrk 2–3 h prej, ogrej se po načrtu, prvih 5 minut ne prehitro. Tako kratka: med tekmo samo voda.' : 'Danes je tekma. Ogrej se po načrtu, prvih 5 minut ne prehitro, jej po urniku goriva.'
  // (v3.50) manj kot 3 vadbe: brez »forma v pravem območju« — danes počitek in jutri X, ali »začni mirno« (H35)
  const few = o.few ?? total < 3
  if (few && !done && (ready == null || ready >= 45)) {
    const tm = o.tomorrow
    const tmTxt = tm ? (tm.kind === 'pocitek' ? 'Jutri: počitek.' : `Jutri: ${titleWithDur(tm.title, tm.durationMin)}.`) : ''
    if (!main || main.kind === 'pocitek') return `Danes počitek. ${tmTxt} Spanec in hrana sta del treninga.`.replace(/\s+/g, ' ').trim()
    if (!main.optional) return `Danes: ${main.title ? titleWithDur(main.title, main.durationMin) : `trening po načrtu${main.durationMin ? `, ${fmtDur(main.durationMin)}` : ''}`}. Začni mirno — spanec in hrana sta del treninga.`
  }
  // utrujenost: »olajšaj dan« samo, ko je danes še trening (ne na dan počitka ali po opravljenem) (v3.48)
  // (v3.49) moč (fitnes, doma) in tek dobijo svoj nasvet — ne »ostani v Z2«, »trening ostane lahek«, »olajšaj dan«
  const train = !!main && main.kind !== 'pocitek' && !main.optional
  const moc = train && main!.kind === 'moc'
  const easyZ = train && (main!.kind === 'tek' || main!.kind === 'pohod') ? 'v pogovornem tempu' : 'v Z2'
  if (ready != null && ready < 45) return done ? 'Danes opravljeno, telo pa je utrujeno — jej do cilja in zgodaj spat.'
    : !train ? 'Telo danes kaže utrujenost — dober dan za počitek: sprehod, voda, zgodaj spat.'
    : moc ? 'Telo danes kaže utrujenost — serija manj z isto težo ali danes počitek. Zgoden spanec naredi več kot nova teža.'
    : 'Telo danes kaže utrujenost. Lahka hoja in zgoden spanec naredita več kot trd trening — olajšaj dan.'
  if (tsb == null) return 'Še računam formo — po nekaj dneh bo tu konkreten nasvet.'
  // opravljeno danes: nasvet za ostanek dneva, ne »izkoristi kakovosten dan«
  if (done) return tsb < -20 ? 'Danes opravljeno. Utrujenost je visoka — jej do cilja, pij in zgodaj spat.' : 'Danes opravljeno. Zdaj obrok z beljakovinami in ogljikovimi hidrati, zvečer spanec.'
  // dolgo manj treninga in danes trd dan po načrtu: nasvet ne sme nasprotovati načrtu (prej »brez trdih intervalov«) (v3.48)
  if (tsb >= 25 && main?.role === 'test') return `${tr} — test začni previdno; nižja številka je zdaj prava izhodiščna točka.`
  if (tsb >= 25 && main && !main.optional && (main.role === 'kljucna' || main.zone === 'Z4' || main.zone === 'Z5')) return `${tr} — danes intervale začni malo pod razponom in končaj, če zadnjega ne zmoreš.`
  // (v3.51) trd trening v načrtu kmalu: kdaj in kako, ne »dva tedna brez trdih intervalov« (nasprotovalo je načrtu)
  if (tsb >= 25) return moc ? `${tr} — danes teža kot zadnjič ali malo manj, tehnika pred kilogrami.` : o.nextHard ? `${tr} — začni postopno. Prvi trd trening (${o.nextHard}) začni malo pod razponom.` : `${tr} — začni postopno. Prva dva tedna brez trdih intervalov na silo.`
  if (tsb < -20) return !train ? 'Utrujenost je visoka — današnji počitek je del načrta, ne luknja v njem.' : moc ? 'Utrujenost je visoka — serija manj, ista teža, brez nove teže. Jej do cilja.' : `Utrujenost je visoka — danes ostani ${easyZ}, tudi če se počutiš dobro. Jej do cilja.`
  // svež: ključni dan izkoristi; lahek dan ostane lahek (prej »izkoristi kakovosten dan« ob lahki Z2); moč: težke serije
  if (tsb > 10) return main?.role === 'kljucna' || main?.role === 'test' ? `${sv} — danes je ključni trening. Pravi trenutek, da ga narediš dobro.` : moc ? `${sv} — dober dan za težke serije. Zadnji dve ponovitvi naj bosta težki.` : train ? `${sv}. Današnji trening ostane lahek — moči prihrani za ključni dan.` : `${sv} — dober čas za kakovostno sejo ta teden.`
  return 'Forma je v pravem območju. Drži se načrta, ne dodajaj. Beljakovine do cilja.'
}

/** »1 neoznačena«, »2 neoznačeni«, »3 neoznačene«, »5 neoznačenih« (seja) */
function unmarkedWord(n: number): string { return n === 1 ? 'neoznačena' : n === 2 ? 'neoznačeni' : n <= 4 ? 'neoznačene' : 'neoznačenih' }

/** (v3.51) prvi trd trening (ključni, Z4/Z5, test) v naslednjih 14 dneh: »v torek, 27. 10.« — null, ko ga ni */
export function nextHardOf(plan: readonly PlanDay[], today: string): string | null {
  const d = plan.filter(x => x.date > today && x.date <= addDays(today, 14) && !x.done && !x.optional && x.kind !== 'pocitek' && (x.role === 'kljucna' || x.role === 'test' || x.zone === 'Z4' || x.zone === 'Z5'))
    .sort((a, b) => a.date.localeCompare(b.date))[0]
  return d ? `${d.date <= addDays(today, 6) ? `v ${dayAcc(d.date)}` : dayAcc(d.date)}, ${dm(d.date)}` : null
}
/** (v3.51) moč, končana predčasno: »delno · 2 od 8 serij« (zapis vadbe z vajami iz tega dne); sicer null */
export function partialLine(d: Pick<PlanDay, 'exercises' | 'done'>, activities: readonly { id: string; exercises?: { name: string; sets: number; reps: string }[] | null }[]): string | null {
  const log = d.done?.activityId ? activities.find(a => a.id === d.done!.activityId)?.exercises ?? null : null
  const q = exPartial(d.exercises, log)
  return q ? `delno · ${q.done} od ${q.all} ${plural(q.all, W.serija)}` : null
}
/** (v3.51) zvečer (od 20h) trening ne gre več v dan: trajanje je daljše od časa do 22h */
export function tooLate(min: number, now: Date): boolean {
  const h = now.getHours() + now.getMinutes() / 60
  return h >= 20 && min > 0 && min / 60 > Math.max(0, 22 - h)
}
/** (v3.51) današnji test: »Pražni utrip 190 (prej 184) · cone so posodobljene« ali »FTP 252 W (prej 240 W) · …« */
export function testLine(tests: readonly { date: string; kind: string; value: number }[], today: string): string | null {
  const t = [...tests].reverse().find(x => x.date === today && (x.kind === 'lthr' || x.kind === 'ftp'))
  if (!t) return null
  const prev = [...tests].reverse().find(x => x.kind === t.kind && x.date < today)
  if (t.kind === 'lthr') return `Pražni utrip ${t.value}${prev ? ` (prej ${prev.value})` : ''} · cone so posodobljene`
  const ftp = (v: number) => Math.round(v * 0.95)
  return `FTP ${ftp(t.value)}${NBSP}W${prev ? ` (prej ${ftp(prev.value)}${NBSP}W)` : ''} · vati so posodobljeni`
}
/** (v3.51) širok zaslon za razporeditev Danes v dva uravnotežena stolpca */
function useWide(q = '(min-width: 1200px)'): boolean {
  const mq = typeof window !== 'undefined' && typeof window.matchMedia === 'function' ? window.matchMedia(q) : null
  const [on, setOn] = useState(() => !!mq?.matches)
  useEffect(() => {
    if (!mq) return
    const f = () => setOn(mq.matches)
    mq.addEventListener?.('change', f)
    return () => mq.removeEventListener?.('change', f)
  }, [q])   // eslint-disable-line react-hooks/exhaustive-deps
  return on
}
