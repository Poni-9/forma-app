import { FuelTimeline, drinkLine } from '@/ui/FuelTimeline'
import { weekProgress } from '@/domain/training/share'
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { navigate } from '@/app/router'
import { Head } from '@/app/Shell'
import { useApp, getState, setPlanDone, savePlanDays, savePlanDay, toast, moveKeyToLater, syncIntervals, hikeInstead, backToBike, restorePlanDays, undoLoadAdaptOf, rateSession } from '@/state/store'
import { RateRow } from '@/ui/RateRow'
import { SickSheet, SickCard } from '@/ui/SickSheet'
import { SkipSheet } from '@/ui/SkipSheet'
import { MoveDaySheet } from '@/ui/MoveDaySheet'
import { canMove } from '@/domain/training/swap'
import { StateCard } from '@/ui/StateCard'
import { YesterdayRate } from '@/ui/YesterdayRate'
import { MovedCard } from '@/ui/MovedCard'
import { LastWeekCard } from '@/ui/LastWeekCard'
import { OffSeasonCard } from '@/ui/OffSeasonCard'
import { inSick } from '@/domain/training/sick'
import { importDiagnosis } from '@/domain/intervals/diagnosis'
import { icuReady } from '@/domain/intervals/client'
import type { PlanDay } from '@/domain/types'
import { snapOf } from '@/state/snap'
import { useAi } from '@/ui/useAi'
import { formSeries, formBand, formReliable, fmtDur, addDays, weekStartIso } from '@/domain/training/load'
import { dailyTarget, sumMeals, weightTrend, fueling, activityKcal } from '@/domain/nutrition/energy'
import { buildWeek, easeDay, weekContext, canHike } from '@/domain/training/planner'
import { OFF_MIX, offMixOf } from '@/domain/training/offMix'
import { GoalCard } from '@/ui/GoalCard'
import { FirstSteps } from '@/ui/FirstSteps'
import { Guide } from '@/ui/Guide'
import { rideFuel, fuelCtxOf } from '@/domain/nutrition/dayplan'
import { raceSoon, whenSl } from '@/domain/nutrition/race'
import { FuelLogCard } from '@/ui/FuelLog'
import { RouteCard } from '@/ui/RouteCard'
import { LoadAdaptCard } from '@/ui/LoadAdaptCard'
import { TomorrowCard } from '@/ui/TomorrowCard'
import { checkRide, moveKeyPlan } from '@/domain/training/review'
import { raceLock } from '@/domain/training/protect'
import { alerts, unmarkedSessions, daysSinceWeigh } from '@/domain/alerts'
import { aiAllowed } from '@/domain/import/provenance'
import { wxShort, wxBad, clothing } from '@/domain/weather'
import { zoneText, workText } from '@/domain/training/zones'
import { cachedDailyAdvice, dailyAdvice, adaptWeek } from '@/domain/ai/actions'
import { sanitizeGaps, hasHiddenActivities } from '@/domain/ai/sanitize'
import { Card, Chip, Ring, Sparkline, Empty, Btn, Track, KindIcon, kindColor, kindLabel, fmtDateLong, fmtKcal, DAYS_SL, kindLabelOf } from '@/ui/primitives'
import { Checkin, readinessOf, checkinDone } from '@/ui/Checkin'
import { recoveryOf, fmtSleep } from '@/domain/wellness'
import { ReadinessSheet } from '@/ui/ReadinessSheet'
import { watchOf } from '@/domain/routes/watch'
import { WeighSheet } from '@/ui/WeighSheet'
import { HealthNote } from '@/ui/HealthNote'
import { undoToast, useHidden } from '@/ui/Confirm'
import { IcuErrorCard, icuErrActive, icuErrOf, icuErrText, syncResult } from '@/ui/IcuStatus'
import { queueMealPhoto } from '@/ui/mealPhoto'
import { count, dec, dm, dayAcc, dayName, nb, num, plural, signed, unit, NBSP, W, withoutFuelLine, plainOH } from '@/ui/format'
import { IcoBike, IcoFood, IcoChat, IcoCheck, IcoScale, IcoCamera, IcoCal, IcoWatch, IcoMic, IcoTarget, IcoChevDown } from '@/ui/icons'
import { effortOf } from '@/domain/training/effort'
import { needOf } from '@/domain/routes/match'
import { openHelp } from '@/ui/overlays'
import { Fold } from '@/ui/Fold'
import { ChangeDaySheet, type ChangeOpt } from '@/ui/ChangeDaySheet'

/** Forma z besedo: kaj pomeni zate (številke kondicije in utrujenosti so v Napredku). */
const FORM_WORD: Record<string, string> = { 'svež': 'spočit — pravi čas za trd trening', 'dober': 'v pravem območju', 'produktiven': 'malo utrujen od treninga — normalno', 'utrujen': 'precej utrujen — več počitka' }

/** Gumb, ki izgleda kot besedilo (vrstica z opozorilom, povezava v kartici). */
const TEXT_BTN: React.CSSProperties = { display: 'block', width: '100%', textAlign: 'left', background: 'none', border: 0, padding: 0, cursor: 'pointer', font: 'inherit' }

export function Danes() {
  const app = useApp()
  const [checking, setChecking] = useState(false)
  const ai = useAi()
  const hidden = useHidden()
  const { profile: p, plan, activities, today, checkinToday, weather } = app
  // obrok, ki čaka na izbris (»Razveljavi«), ne šteje več
  const mealsToday = useMemo(() => app.mealsToday.filter(m => !hidden.has('meal:' + m.id)), [app.mealsToday, hidden])
  const ws = weekStartIso(today)
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(ws, i))
  const week = plan.filter(d => d.date >= ws && d.date <= addDays(ws, 6))
  const todayPlan = plan.filter(d => d.date === today)
  // najprej kolo/test, potem moč; neobvezno in počitek na koncu
  const prio = (d: PlanDay) => (d.kind === 'pocitek' ? 9 : d.optional ? 5 : d.kind === 'moc' ? 2 : 0)
  const ordered = [...todayPlan].sort((a, b) => prio(a) - prio(b))
  const main = ordered[0] || null
  const extra = ordered.filter(d => d !== main && d.kind === 'moc')
  const series = useMemo(() => formSeries(activities, today), [activities, today])
  // manj kot 6 tednov zgodovine (in brez začetnega stanja iz intervals.icu): forma je le groba ocena
  const formEst = useMemo(() => !formReliable(activities, today), [activities, today])
  const last = series[series.length - 1]
  const band = last ? formBand(last.tsb) : null
  const spark = series.slice(-28).map(x => x.tsb)
  const todaysActs = activities.filter(a => a.date === today)
  const target = dailyTarget(p, todaysActs, todayPlan, today)
  const raceNear = raceSoon(p, today)
  const eaten = sumMeals(mealsToday)
  const tr = weightTrend(app.checkins)
  const rec = useMemo(() => (app.settings.wellnessOn ? recoveryOf(app.wellness, today, checkinToday?.sleepH ?? null) : null), [app.settings.wellnessOn, app.wellness, today, checkinToday?.sleepH])
  // Garmin pripis v razlagi pripravljenosti: ura (ne Edge števec — ta ne meri spanca)
  const watchName = useMemo(() => { const w = watchOf(app.activities); return w.name && !w.edge ? (/^garmin\b/i.test(w.name) ? w.name.replace(/^garmin\b/i, 'Garmin') : `Garmin ${w.name}`) : null }, [app.activities])
  const ready = readinessOf(last ? last.tsb : null, checkinToday, rec)
  const cx = weekContext(p, ws)
  const firstName = (p.name || '').split(/\s+/)[0]
  const [aiLine, setAiLine] = useState<string | null>(null)
  const [weigh, setWeigh] = useState(false)
  const [busy, setBusy] = useState<string | null>(null)
  useEffect(() => { void cachedDailyAdvice(today).then(t => setAiLine(t ? sanitizeGaps(t, hasHiddenActivities(activities)) : null)) }, [today, activities.length, plan.length])
  const al = useMemo(() => alerts({ profile: p, activities, plan, checkins: app.checkins, recentMeals: app.recentMeals, today }), [p, activities, plan, app.checkins, app.recentMeals, today])
  const fuel = main && !main.optional ? fueling(main, p) : null
  const eff = main ? effortOf(main) : null
  const routeOk = !!main && !main.optional && !main.done && (main.kind === 'kolo' || main.kind === 'test') && !!needOf(main, p)
  const rf = main && !main.optional ? rideFuel(main, p.fuelKit, fuelCtxOf(weather, app.recentMeals, main.date, today)) : null
  const [guide, setGuide] = useState(false)
  const [readyOpen, setReadyOpen] = useState(false)
  const [sickOpen, setSickOpen] = useState(false)
  const [skipDay, setSkipDay] = useState<PlanDay | null>(null)
  // jutranji vnos: ob odprtju neizpolnjen → pod treningom (ostane tam, tudi ko ga izpolniš); izpolnjen → spodaj
  const ciTop = useMemo(() => !checkinDone(getState()), [today])   // eslint-disable-line react-hooks/exhaustive-deps
  const [moveDay, setMoveDay] = useState<PlanDay | null>(null)
  const [changeOpen, setChangeOpen] = useState(false)
  const sick = inSick(p, today)
  // vodnik »Kako deluje« se pokaže enkrat: po uvodu ali po prvem cilju (guideSeen === false)
  useEffect(() => { if (app.ready && app.settings.guideSeen === false) setGuide(true) }, [app.ready, app.settings.guideSeen])
  const wx = weather?.[today]
  const seen = activities.filter(aiAllowed).length
  const outdoor = main && (main.kind === 'kolo' || main.kind === 'tek' || main.kind === 'pohod')
  // »Olajšaj dan« zna olajšati samo vožnjo (easeDay) — pri moči, teku ali hribih ga ne ponujamo
  const canEase = !!main && (main.kind === 'kolo' || main.kind === 'test') && !main.optional && !main.done
  const icuErr = app.settings.intervals ? icuErrOf(app) : null
  const photoRef = useRef<HTMLInputElement>(null)

  async function buildThisWeek() {
    const rain: Record<string, number> = {}
    if (weather) for (const k in weather) rain[k] = weather[k]!.rain
    const days = buildWeek({ profile: p, activities, weekStart: ws, rain, firstWeek: !plan.length, notBefore: today })
    const doneDates = new Set(week.filter(d => d.done).map(d => d.date))
    await savePlanDays(days.filter(d => !doneDates.has(d.date)))
    toast('Teden je sestavljen.', 'ok')
  }
  /** Prejšnji (neopravljeni) dnevi za te datume — za »Razveljavi«. */
  const before = (dates: Set<string>) => getState().plan.filter(d => dates.has(d.date) && !d.done)
  async function ease() {
    const out = easeDay(week, today, raceLock(getState().plan, getState().profile))
    if (!out) return
    const prev = before(new Set(out.map(d => d.date)))
    for (const d of out) await savePlanDay(d)
    undoToast(out.length > 1 ? 'Danes lahko — seja je prestavljena.' : 'Danes lahko.', () => restorePlanDays(prev, out.map(d => d.date)))
  }
  async function aiDay() {
    setBusy('adapt')
    const r = await ai.run(() => {
      const s = getState(), w0 = weekStartIso(s.today)
      return adaptWeek(snapOf(s), s.plan.filter(d => d.date >= w0 && d.date <= addDays(w0, 6)), 'Prilagodi DANES in preostanek tedna glede na jutranje počutje, spanec in vreme. Opravljenih dni ne spreminjaj. Če je pripravljenost nizka, danes olajšaj in kakovostno sejo prestavi; tedenski volumen ohrani, če se da.')
    })
    setBusy(null)
    if (!r) return
    const changed = r.days.filter(d => !d.done)
    const prev = before(new Set(changed.map(d => d.date)))
    await savePlanDays(changed)
    undoToast(r.summary, () => restorePlanDays(prev, changed.map(d => d.date)), { ms: 9000 })
  }
  async function advice() {
    setBusy('advice')
    const t = await ai.run(() => dailyAdvice(snapOf(getState()), !!aiLine))
    setBusy(null)
    if (t) setAiLine(t)
  }
  async function checkGarmin() {
    const c = getState().settings.intervals
    if (!icuReady(c)) { toast('Povezava z intervals.icu ni dokončana — uredi jo v Uvozu.', 'info'); return }
    const t0 = Date.now()
    setChecking(true)
    const r = syncResult(await syncIntervals())
    setChecking(false)
    // prava napaka (odjava, kvota, omrežje) — ne »vožnje še ni«; razložena, s »počakam do …« pri kvoti
    const err = icuErrOf(getState()), fresh = err && err.at >= t0 - 1000 ? err : null
    if (fresh && !r.skipped) { toast(icuErrText(fresh), 'err', 9000); return }
    if (r.error) { toast(r.error, r.skipped ? 'info' : 'err', r.skipped ? 5000 : 9000); return }
    const n = r.added
    if (n == null) { toast(navigator.onLine === false ? 'Ni povezave z internetom — preverim, ko bo.' : 'Preverjanje že teče — poglej čez minuto.', 'info'); return }
    if (n === 0) {
      const adv = importDiagnosis(getState().icuDiag)
      toast(adv && adv.tone === 'warn' ? `${adv.title}. Pojasnilo: Nastavitve → Uvoz.` : 'Nove vožnje še ni — Garmin jo najprej pošlje v intervals.icu (običajno v nekaj minutah po shranjeni vožnji).', adv && adv.tone === 'warn' ? 'err' : 'info', 8000)
    }
  }

  return (<>
    <Head hi={fmtDateLong(today)} nm={firstName ? `Živjo, ${firstName}` : 'Živjo'} />
    <div className="scroll">
      <div className="cols">
      <div className="col">
      <div className="between" style={{ marginBottom: 8, gap: 10 }}>
        {/* faza in teden sta tudi v kartici cilja — tu kratko, v eni vrstici */}
        <div className="clamp2" style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--ink-3)', minWidth: 0 }}>{cx.structured ? `Teden${NBSP}${cx.week}${cx.total ? ` od${NBSP}${cx.total}` : ''} · ${cx.easy ? 'lahek začetek' : cx.recovery && cx.phase !== 'prehod' ? 'razbremenilni' : cx.phase === 'dirka' ? 'dirka' : cx.phaseName.toLowerCase()}` : 'Ta teden'}</div>
        {ready && <Chip sm onClick={() => setReadyOpen(true)}><span className="dot" style={{ background: ready.color }} />pripravljenost {ready.score}{rec ? <IcoWatch width={13} height={13} aria-label="z ure" style={{ marginLeft: -2 }} /> : null}</Chip>}
      </div>
      <div className="week">
        {weekDays.map((d, i) => {
          const items = plan.filter(x => x.date === d && x.kind !== 'pocitek' && !x.optional)
          const isToday = d === today, past = d < today
          return (
            <button key={d} type="button" className={`day ${isToday ? 'today' : ''} ${past ? 'past' : ''}`} onClick={() => navigate('plan', { dan: d })} aria-label={`${dayName(d)}, ${dm(d)}`}>
              <div className="dn">{DAYS_SL[i]}</div><div className="dd">{+d.slice(8)}</div>
              <div className="dots">{items.length ? items.slice(0, 2).map((k, j) => <i key={j} style={{ background: isToday ? 'rgba(15,18,22,.6)' : k.done ? 'var(--accent)' : kindColor(k.kind) }} />) : <i style={{ background: isToday ? 'rgba(15,18,22,.6)' : 'var(--t-poc)', opacity: .5 }} />}</div>
            </button>
          )
        })}
      </div>

      {week.length > 0 && (() => {
        const wp = weekProgress(week, activities)
        if (!wp.total) return null
        const pc = wp.minAll ? Math.min(100, Math.round((wp.minDone / wp.minAll) * 100)) : 0
        const um = unmarkedSessions(week, today)
        return (
          <button type="button" className="wk-prog" onClick={() => navigate('plan')} aria-label={`Ta teden: ${wp.done} od ${wp.total} treningov, ${fmtDur(wp.minDone)} od ${fmtDur(wp.minAll)}${um ? `, ${um} ${unmarkedWord(um)}` : ''} — odpri Plan`}>
            <span className="bar" aria-hidden="true"><i style={{ width: `${Math.max(pc, wp.minDone ? 3 : 0)}%` }} /></span>
            <span className="tx" aria-hidden="true"><b>{wp.done}/{wp.total}</b> treningov · {wp.minDone ? fmtDur(wp.minDone) : '0 min'} od {fmtDur(wp.minAll)}{um ? <span className="wk-um"> · {um} {unmarkedWord(um)}</span> : null}</span>
          </button>
        )
      })()}

      {/* najprej konkretno: današnji trening takoj pod tednom; razlogi za spremembo (počutje, zamujeni) tik pod njim */}
      {!week.length ? (
        <div style={{ marginTop: 12 }}>
          <Empty icon={<IcoCal width={30} height={30} style={{ color: 'var(--accent)' }} />} title="Ta teden še ni sestavljen" text={`${num(cx.hours)} h · ${cx.phase === 'prehod' ? `off-season: ${OFF_MIX[offMixOf(p)].active}` : cx.easy ? 'lahek začetek: Z2, šprinti, kadenca, tempo' : cx.recovery ? 'razbremenilni teden' : 'VO2max v torek, prag v četrtek, šprinti v sredo, dolga v soboto'}${p.strength.on && p.strengthDays ? ` · moč ${Math.min(2, p.strengthDays)}×` : ''}. Sestavi se takoj, brez AI.`}>
            <Btn primary sm onClick={buildThisWeek}>Sestavi teden</Btn>
          </Empty>
        </div>
      ) : sick ? (
        <SickCard />
      ) : main && main.kind !== 'pocitek' ? (
        <Card className="sess spot" style={{ marginTop: 12, ['--c' as string]: main.optional ? 'var(--t-poc)' : kindColor(main.kind) }}>
          <div>
            <div className="between">
              <div className="kbadge"><span className="ki"><KindIcon kind={main.kind} /></span>{kindLabelOf(main)} · {main.optional ? 'po želji' : 'danes'}</div>
              {main.done ? <Chip sm on>opravljeno</Chip> : null}
            </div>
            <div className="ttl">{main.title}</div>
            {/* glavne številke seje: velike, na prvi pogled */}
            <div className="kpis">
              {main.durationMin > 0 && <div className="kpi"><b>{fmtDur(main.durationMin)}</b><small>trajanje</small></div>}
              {/* intenzivnost z besedo; tap → kaj pomenijo cone (cela ploščica je gumb — dovolj velik cilj dotika) */}
              {eff ? (eff.sub.startsWith('Z')
                ? <button type="button" className="kpi kpi-btn" onClick={() => openHelp('cona')} aria-label={`${eff.w}, cona ${eff.sub} — kaj pomenijo cone?`}><b>{eff.w}</b><small>{eff.sub}</small></button>
                : <div className="kpi"><b>{eff.w}</b><small>{eff.sub}</small></div>) : null}
              {main.exercises?.length ? <div className="kpi"><b>{main.exercises.length}</b><small>{plural(main.exercises.length, W.vaja)}</small></div> : null}
            </div>
            {eff && !main.done && <div className="talk">Tempo: {eff.talk}.</div>}
            <p style={{ fontSize: 13, marginTop: 12 }}>{nb(plainOH(fuel && !main.done ? withoutFuelLine(main.desc) : main.desc))}</p>
            {main.target ? <div className="row" style={{ gap: 8, marginTop: 10, fontSize: 13, fontWeight: 700, color: 'var(--ink)', alignItems: 'flex-start' }}><IcoTarget width={16} height={16} style={{ color: 'var(--c)', flex: 'none', marginTop: 2 }} /><span>intervali {workText(p, main)}</span></div>
              : main.kind === 'kolo' && main.zone && /^Z[1-5]$/.test(main.zone) && !main.desc.includes(zoneText(p, main.zone as 'Z2')) ? <div className="row" style={{ gap: 8, marginTop: 10, fontSize: 13, fontWeight: 700, color: 'var(--ink)', alignItems: 'flex-start' }}><IcoTarget width={16} height={16} style={{ color: 'var(--c)', flex: 'none', marginTop: 2 }} /><span>{main.zone} · {zoneText(p, main.zone as 'Z2')}</span></div> : null}
            {main.exercises?.length ? (
              <div style={{ marginTop: 10, paddingTop: 10, borderTop: '1px solid var(--line)' }}>
                {main.exercises.map((e, j) => <div key={j} className="between" style={{ fontSize: 13, padding: '3px 0' }}><span style={{ fontWeight: 600, color: 'var(--ink)' }}>{e.name}</span><span className="muted" style={{ flex: 'none' }}>{e.sets} × {e.reps}{e.kg ? ` · ${unit(num(e.kg), 'kg')}` : ''}</span></div>)}
              </div>
            ) : null}
            {outdoor && wx && <div style={{ fontSize: 12, marginTop: 8, fontWeight: 600, color: wxBad(wx) ? 'var(--warn)' : 'var(--ink-3)' }}>{wxShort(wx)}{wxBad(wx) && main.kind === 'kolo' ? (p.gear.trainer ? ' — raje trenažer' : ' — premakni ali se dobro obleci') : ''}</div>}
            {outdoor && wx && main.kind !== 'moc' && !main.done && <div className="muted" style={{ fontSize: 12, marginTop: 3 }}><b style={{ color: 'var(--ink-2)' }}>Obleci:</b> {clothing(wx)}.</div>}
            {main.why && !main.done && <div className="muted" style={{ fontSize: 12, marginTop: 8 }}><b style={{ color: 'var(--ink-2)' }}>Zakaj:</b> {main.why}</div>}
            {rec && rec.reasons.length > 0 && ready && ready.score < 60 && !main.done && !main.optional && <button type="button" onClick={() => setReadyOpen(true)} style={{ ...TEXT_BTN, fontSize: 12, marginTop: 8, color: 'var(--warn)', fontWeight: 600 }}>Ura: {rec.reasons.join(', ')}{rec.sleepH != null ? ` (${fmtSleep(rec.sleepH)} spanca)` : ''}. {ready.score < 45 ? 'Danes raje lažje.' : canEase ? 'Če se ne počutiš dobro, olajšaj dan.' : 'Če se ne počutiš dobro, naredi manj.'}</button>}
            {!main.done && (
              <>
              <div className="row" style={{ gap: 8, marginTop: 13, flexWrap: 'wrap' }}>
                <Btn ghost sm onClick={() => setPlanDone(main.id, true)}><IcoCheck width={15} height={15} /> Opravil</Btn>
                {(main.kind === 'kolo' || main.kind === 'test') && app.settings.intervals && <Btn ghost sm disabled={checking} onClick={checkGarmin}>{checking ? 'Preverjam …' : 'Preveri Garmin'}</Btn>}
                {canEase && ready && ready.score < 45 && <Btn ghost sm onClick={ease}>Olajšaj dan</Btn>}
                {!main.optional && ready && ready.score < 60 && app.user && <Btn ghost sm disabled={ai.busy} onClick={aiDay}>{busy === 'adapt' && ai.busy ? 'Prilagajam …' : 'AI prilagodi'}</Btn>}
                <Btn ghost sm onClick={() => setChangeOpen(true)}>Spremeni <IcoChevDown width={15} height={15} aria-hidden="true" /></Btn>
              </div>
              {/* razveljavitev samodejne spremembe ostane na očeh */}
              {(main.swap || (main.adapt?.prev && !main.adapt.off)) && (
                <div className="row" style={{ gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
                  {main.swap && <button type="button" className="chip sm click" onClick={async () => { await backToBike(main.id); toast('Nazaj na kolo.', 'ok') }}>Nazaj na kolo</button>}
                  {main.adapt?.prev && !main.adapt.off && <button type="button" className="chip sm click" onClick={async () => { await undoLoadAdaptOf(main.adapt!.after); toast('Vrnjen prvotni načrt.', 'ok') }}>Vrni prvotni trening</button>}
                </div>
              )}
              </>
            )}
            {main.done && (() => {
              const act = main.done?.activityId ? activities.find(a => a.id === main.done!.activityId) : null
              const c = act ? checkRide(main, act) : null
              if (!c) return null
              const key = main.role === 'kljucna' || main.role === 'test'
              const plan0 = key && c.status !== 'ok' ? moveKeyPlan(week, main, today, raceLock(plan, app.profile)) : null
              const mv = plan0?.days ?? null
              const nextKey = key && c.status !== 'ok' && !mv ? plan.filter(d => d.date > today && (d.role === 'kljucna' || d.role === 'test') && !d.done).sort((a, b) => a.date.localeCompare(b.date))[0] : null
              return (
                <div style={{ marginTop: 10, paddingTop: 10, borderTop: '1px solid var(--line)' }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: c.status === 'ok' ? 'var(--ok)' : c.status === 'delno' ? 'var(--warn)' : 'var(--bad)' }}>{c.verdict}</div>
                  <div className="muted" style={{ fontSize: 12, marginTop: 2 }}>{c.detail}</div>
                  {mv && <Btn ghost sm style={{ marginTop: 8 }} onClick={async () => { const to = await moveKeyToLater(main.id); toast(to ? `${main.title} je prestavljen na ${dayAcc(to)}. Danes šteje kot ${mv[0].title}.` : 'Ta teden ni več prostega lahkega dne — izpusti ga.', to ? 'ok' : 'info', 7000) }}>Prestavi na {dayAcc(mv[1].date)}</Btn>}
                  {key && c.status !== 'ok' && !mv && <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>{plan0?.reason || 'Izpusti ga — naslednji ključni trening pride po načrtu.'}{nextKey ? ` Naslednji ključni: ${nextKey.title}, ${dayName(nextKey.date)}, ${dm(nextKey.date)}` : ''}</div>}
                </div>)
            })()}
            {main.done && (() => {
              // kako je šlo: en tap — gre na vadbo (če je povezana) ali na dan načrta
              const act = main.done?.activityId ? activities.find(a => a.id === main.done!.activityId) : null
              return <div style={{ marginTop: 10 }}><RateRow label="Kako je šlo?" value={act?.rpe ?? main.rpe ?? null} onPick={v => void rateSession({ activityId: act?.id ?? null, dayId: main.id }, v)} /></div>
            })()}
            {main.done && <button className="chip sm click" style={{ marginTop: 12 }} onClick={() => setPlanDone(main.id, false)}>razveljavi</button>}
          </div>
        </Card>
      ) : (
        <Card className="sess spot" style={{ marginTop: 12, ['--c' as string]: 'var(--t-poc)' }}>
          <div><div className="kbadge"><span className="ki"><KindIcon kind="pocitek" /></span>Počitek · danes</div><div className="ttl">Dan brez treninga</div><p style={{ fontSize: 13, marginTop: 6 }}>Hoja, raztezanje, spanec. Prilagoditev se zgodi med počitkom.</p>
            <button type="button" className="chip sm click" style={{ marginTop: 10 }} onClick={() => setSickOpen(true)}>Bolan sem</button></div>
        </Card>
      )}

      {extra.map(x => (
        <Card key={x.id} tight className="sess" style={{ marginTop: 8 }}>
          <div className="bar" style={{ background: kindColor(x.kind) }} />
          <div className="between" style={{ paddingLeft: 6, gap: 10 }}>
            <div style={{ minWidth: 0 }}>
              <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: '.08em', color: kindColor(x.kind) }}>+ {kindLabel(x.kind).toUpperCase()} · {x.durationMin}{NBSP}MIN</div>
              <b style={{ fontSize: 14 }}>{x.title}</b>
              {x.exercises?.length ? <div className="muted" style={{ fontSize: 12 }}>{x.exercises.map(e => `${e.name} ${e.sets}×${e.reps}`).join(' · ')}</div> : null}
            </div>
            {x.done ? <Chip sm on>opravljeno</Chip> : <Btn ghost sm onClick={() => navigate('vadba', { id: x.id })}>Začni</Btn>}
          </div>
        </Card>
      ))}

      <StateCard />
      <MovedCard />
      <OffSeasonCard />
      {/* jutranji vnos: neizpolnjen takoj pod treningom (spremeni lahko današnji dan), izpolnjen čisto spodaj */}
      {ciTop && <div style={{ marginTop: 12 }}><Checkin compact /></div>}

      <LoadAdaptCard date={addDays(today, -1)} actionOnly />
      <LoadAdaptCard date={today} />

      {week.length > 0 && <TomorrowCard plan={plan} today={today} weather={weather} todayDone={!main || main.kind === 'pocitek' || !!main.done} />}

      {(routeOk || (fuel && !main?.done)) && main && (
        <Card tight className="for-day">
          {routeOk && <Fold id="trasa" title="Trasa za ta trening" sum="predlog po meri treninga · GPX · na uro"><RouteCard day={main} inCard={false} /></Fold>}
          {fuel && !main.done && (
            <Fold id="gorivo" title="Gorivo za ta trening" sum={rf ? `${rf.bottles} ${rf.bottles === 1 ? 'bidon' : rf.bottles === 2 ? 'bidona' : rf.bottles <= 4 ? 'bidoni' : 'bidonov'}${rf.totalCarbs > 0 ? ` · ~${rf.totalCarbs} g ogljikovih hidratov` : ' · samo voda'}` : 'pred, med in po treningu'}>
              <div className="stack" style={{ gap: 6 }}>
                {([['Pred', fuel.before], ['Med', rf && rf.cues.length ? drinkLine(rf) : rf ? rf.schedule : fuel.during], ['Vzemi', rf ? rf.items.join(' · ') : ''], ['Po', fuel.after]] as const).filter(([, t]) => t).map(([l, t]) => <div key={l} style={{ display: 'grid', gridTemplateColumns: '46px 1fr', gap: 8, fontSize: 12.5 }}><b style={{ color: 'var(--ink)' }}>{l}</b><span style={{ color: 'var(--ink-2)' }}>{nb(plainOH(t))}</span></div>)}
              </div>
              {rf && <FuelTimeline rf={rf} minutes={main.durationMin} />}
            </Fold>
          )}
        </Card>
      )}
      {main && !main.optional && main.done && (main.kind === 'kolo' || main.kind === 'test') && rf && rf.totalCarbs > 0 && <FuelLogCard day={main} rf={rf} meals={mealsToday} kit={p.fuelKit} />}

      <FirstSteps />


      {/* poročila in opomniki šele pod treningom */}
      {icuErrActive(icuErr) && <div style={{ marginTop: 12 }}><IcuErrorCard err={icuErr} /></div>}
      <YesterdayRate />
      <LastWeekCard />
      {al.length > 0 && (
        <Card tight className="alerts-card">
          <h2 className="h4" style={{ fontSize: 11, margin: 0 }}>Opozorila</h2>
          {al.map((a, i) => (
            <button key={i} type="button" className="alert-row" onClick={() => a.to && navigate(a.to)} style={{ cursor: a.to ? 'pointer' : 'default' }}>
              <span className="dot" style={{ background: a.kind === 'bad' ? 'var(--bad)' : a.kind === 'warn' ? 'var(--warn)' : 'var(--ink-3)' }} />
              <span>{a.text}</span>
            </button>
          ))}
        </Card>
      )}
      {!ciTop && <div style={{ marginTop: 12 }}><Checkin compact /></div>}

      </div>
      <div className="col">
      <GoalCard compact />

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 12 }}>
        <div style={{ position: 'relative', display: 'flex' }}>
        <button type="button" className="card tight" style={{ textAlign: 'left', width: '100%', cursor: 'pointer' }} onClick={() => navigate('napredek')} aria-label={`Forma${band ? `: ${band.band}` : ''} — odpri Napredek`}>
          <h2 className="h4" style={{ fontSize: 11 }}>Forma</h2>
          {last && series.length > 3 ? (<>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 2 }}>
              <b style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-.03em', color: band!.color === 'ok' ? 'var(--ok)' : band!.color === 'bad' ? 'var(--bad)' : band!.color === 'warn' ? 'var(--warn)' : 'var(--ink)' }}>{band!.band}</b>
              <span className="muted" style={{ fontSize: 11.5, fontWeight: 700 }}>{signed(Math.round(last.tsb), 0)}</span>
            </div>
            <div style={{ marginTop: 5 }}><Sparkline values={spark} /></div>
            <div className="muted" style={{ fontSize: 11, fontWeight: 600, marginTop: 2 }}>{formEst ? 'ocena · premalo zgodovine' : FORM_WORD[band!.band] ?? ''}</div>
          </>) : (<p style={{ fontSize: 12, marginTop: 4 }}>Po nekaj aktivnostih pokažem formo.</p>)}
        </button>
        <button type="button" className="tile-help" onClick={() => openHelp('forma')} aria-label="Kaj je forma?">?</button>
        </div>
        <button type="button" className="card tight" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', width: '100%', cursor: 'pointer' }} onClick={() => navigate(target ? 'prehrana' : 'nastavitve')} aria-label={target ? 'Kalorije — odpri Prehrano' : 'Za kalorije izpolni profil — odpri Nastavitve'}>
          {target ? (<>
            <Ring pct={eaten.kcal / target.kcal}><div><b style={{ fontSize: 19 }}>{fmtKcal(eaten.kcal)}</b><small>od {fmtKcal(target.kcal)}</small></div></Ring>
            <div style={{ fontSize: 11, color: 'var(--ink-3)', fontWeight: 700, marginTop: 3 }}>KALORIJE · ŠE {fmtKcal(Math.max(0, target.kcal - eaten.kcal))}</div>
          </>) : (<>
            <IcoFood style={{ color: 'var(--ok)' }} /><div style={{ fontSize: 12.5, color: 'var(--ink)', fontWeight: 700, marginTop: 6, textAlign: 'center' }}>Za kalorije izpolni profil</div><div className="muted" style={{ fontSize: 11, marginTop: 2, textAlign: 'center' }}>višina, teža, starost, spol</div>
          </>)}
        </button>
      </div>

      {/* eno opozorilo na zaslonu, tik pod številom kalorij: velja za kalorije in za današnji trening */}
      {target && <HealthNote kind="both" style={{ margin: '10px 4px 0' }} />}

      {target && (
        <Card tight style={{ marginTop: 12 }}>
          <div className="between" style={{ fontSize: 13 }}><span className="muted" style={{ fontWeight: 600 }}>Beljakovine</span><b>{Math.round(eaten.p)} / {target.proteinG}{NBSP}g</b></div>
          <div style={{ marginTop: 6 }}><Track pct={eaten.p / target.proteinG * 100} color="var(--accent)" /></div>
          {todaysActs.length > 0 && <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>Danes porabljeno na treningu ~{fmtKcal(todaysActs.reduce((s, a) => s + activityKcal(a, p), 0))}{NBSP}kcal — že vključeno v cilj.</div>}
          {raceNear && <button type="button" style={{ ...TEXT_BTN, fontSize: 12, marginTop: 8, color: 'var(--ink-2)' }} onClick={() => navigate('prehrana')}><b style={{ color: 'var(--warn)' }}>Malo vlaknin</b> · {raceNear.inDays === 0 ? `${raceNear.name} je danes — do starta brez polnozrnatega, stročnic in solate.` : `${raceNear.name} je ${whenSl(raceNear.inDays)}: bel kruh, riž, testenine, krompir brez lupine; brez polnozrnatega, stročnic, solate in oreškov.`}</button>}
        </Card>
      )}

      <Card tight style={{ marginTop: 12 }}>
        <div className="between">
          <div style={{ minWidth: 0 }}>
            <h2 className="h4" style={{ fontSize: 11 }}>Teža</h2>
            {tr ? (<>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, flexWrap: 'wrap' }}><b style={{ fontSize: 22, fontWeight: 800 }}>{unit(dec(tr.avg7, 1), 'kg')}</b>{tr.deltaWeek != null && <span style={{ fontSize: 12, fontWeight: 700, color: tr.deltaWeek < -0.75 ? 'var(--warn)' : tr.deltaWeek < 0 ? 'var(--ok)' : 'var(--ink-3)' }}>{signed(tr.deltaWeek, 2)}{NBSP}kg/teden</span>}</div>
              <div className="muted" style={{ fontSize: 11.5, fontWeight: 600 }}>7-dnevno povprečje{p.targetWeightKg ? ` · cilj ${unit(num(p.targetWeightKg), 'kg')}, še ${unit(dec(Math.max(0, tr.avg7 - p.targetWeightKg), 1), 'kg')}` : ''}</div>
              {(() => { const dw = daysSinceWeigh(app.checkins, today); return dw != null && dw >= 7 ? <div style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--warn)', marginTop: 2 }}>Zadnje tehtanje pred {dw} dnevi — stehtaj se zjutraj.</div> : null })()}
            </>) : <div className="muted" style={{ fontSize: 12.5 }}>Stehtaj se zjutraj — trend pokažem po nekaj dneh.</div>}
          </div>
          <Btn sm onClick={() => setWeigh(true)}><IcoScale width={16} height={16} /> Stehtaj</Btn>
        </div>
      </Card>

      <div className="card tight hover" style={{ marginTop: 12, display: 'flex', gap: 11, alignItems: 'flex-start' }}>
        <div style={{ width: 30, height: 30, borderRadius: 'var(--r-s)', background: 'var(--accent-soft)', display: 'grid', placeItems: 'center', flex: 'none', color: 'var(--accent)' }}><IcoChat width={16} height={16} /></div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="between"><b style={{ fontSize: 13 }}>Trener pravi</b><button className="chip sm click" onClick={() => navigate('trener')}>vprašaj ›</button></div>
          <ClampText text={aiLine || coachLine(last?.tsb ?? null, main, seen, activities.length, ready?.score ?? null)}>
            {app.user && <button className="chip sm click" disabled={ai.busy} onClick={advice}>{busy === 'advice' && ai.busy ? 'Razmišljam …' : aiLine ? 'osveži nasvet' : 'AI nasvet za danes'}</button>}
          </ClampText>
        </div>
      </div>

      <div className="quick3">
        <button type="button" className="qa" onClick={() => photoRef.current?.click()}><IcoCamera width={20} height={20} /><span>Slikaj obrok</span></button>
        <button type="button" className="qa" onClick={() => navigate('prehrana', { opis: '1' })}><IcoMic width={20} height={20} /><span>Opiši obrok</span></button>
        <button type="button" className="qa" onClick={() => navigate('aktivnosti', { nova: '1' })}><IcoBike width={20} height={20} /><span>Vpiši vadbo</span></button>
      </div>
      {/* kamera se odpre tu (dotik), slika gre v Prehrano, ki jo prebere */}
      <input ref={photoRef} type="file" accept="image/*" capture="environment" hidden onChange={e => { const f = e.target.files?.[0]; e.target.value = ''; if (f) { queueMealPhoto(f); navigate('prehrana') } }} />

      {!target && <HealthNote kind="plan" style={{ padding: '0 4px', marginTop: 12 }} />}

      </div>
      </div>
    </div>
    <WeighSheet open={weigh} onClose={() => setWeigh(false)} />
    {guide && <Guide open onClose={() => setGuide(false)} />}
    <SickSheet open={sickOpen} onClose={() => setSickOpen(false)} />
    {skipDay && <SkipSheet day={skipDay} canMove={canMove(skipDay, today, raceLock(plan, p))} onClose={() => setSkipDay(null)} onMove={() => setMoveDay(skipDay)} onSick={() => setSickOpen(true)} />}
    {moveDay && <MoveDaySheet day={moveDay} onClose={() => setMoveDay(null)} />}
    {changeOpen && main && <ChangeDaySheet day={main} onClose={() => setChangeOpen(false)} opts={[
      ...(canMove(main, today, raceLock(plan, p)) ? [{ t: 'Premakni na drug dan', d: 'Izbereš dan tega ali naslednjega tedna — kar je tam, pride na danes.', go: () => setMoveDay(main) }] : []),
      ...(!main.byState ? [{ t: 'Danes ne gre', d: 'Bolijo noge, ni časa, slabo vreme … — povej zakaj in prilagodim.', go: () => setSkipDay(main) }] : []),
      ...(canHike(main) ? [{ t: 'Hribi namesto kolesa', d: 'Enak lahek trening peš v hribe — samo danes.', go: () => { void hikeInstead(main.id).then(() => toast('Hribi namesto kolesa — trening za danes gre z ure.', 'ok')) } }] : []),
      ...(canEase ? [{ t: 'Olajšaj dan', d: 'Krajše in lažje; težji trening gre na drug dan tega tedna.', go: () => { void ease() } }] : []),
      { t: 'Bolan sem', d: 'Počitek za nekaj dni, prehrana brez deficita — treningi ostanejo shranjeni.', go: () => setSickOpen(true) },
    ] satisfies ChangeOpt[]} />}
    {readyOpen && ready && <ReadinessSheet open onClose={() => setReadyOpen(false)} ready={ready} rec={rec} tsb={last ? last.tsb : null} checkin={checkinToday} wellnessOn={!!app.settings.wellnessOn} hasIntervals={!!app.settings.intervals} device={watchName} onEase={canEase ? () => { void ease() } : null} />}
    {ai.sheet}
  </>)
}

/** Dolgo besedilo AI: tri vrstice in »Preberi vse«. Gumbi (children) so v isti vrstici pod besedilom. */
function ClampText({ text, children }: { text: string; children?: React.ReactNode }) {
  const ref = useRef<HTMLParagraphElement>(null)
  const [open, setOpen] = useState(false)
  const [over, setOver] = useState(false)
  useLayoutEffect(() => {
    const el = ref.current
    if (!el || open) return
    const check = () => setOver(el.scrollHeight > el.clientHeight + 2)
    check()
    window.addEventListener('resize', check)
    return () => window.removeEventListener('resize', check)
  }, [text, open])
  useEffect(() => { setOpen(false) }, [text])
  const clamp: React.CSSProperties = open ? {} : { display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden' }
  return (<>
    <p ref={ref} style={{ fontSize: 13, marginTop: 4, whiteSpace: 'pre-wrap', ...clamp }}>{text}</p>
    {(over || open || children) && (
      <div className="row" style={{ gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
        {(over || open) && <button type="button" className="chip sm click" aria-expanded={open} onClick={() => setOpen(!open)}>{open ? 'Skrij' : 'Preberi vse'}</button>}
        {children}
      </div>
    )}
  </>)
}

function coachLine(tsb: number | null, main: { kind: string; optional?: boolean } | null, aiSeen: number, total: number, ready: number | null): string {
  if (!total) return 'Ko vpišeš ali uvoziš prve treninge, začnem pisati konkretne nasvete namesto splošnih.'
  if (aiSeen === 0) return `Vidim ${count(total, W.aktivnost)}, a nobena ni iz vira, ki ga smem uporabiti. Poveži uro neposredno z intervals.icu ali naloži datoteke.`
  if (ready != null && ready < 45) return 'Telo danes kaže utrujenost. Lahka hoja in zgoden spanec naredita več kot trd trening — olajšaj dan.'
  if (tsb == null) return 'Še računam formo — po nekaj dneh bo tu konkreten nasvet.'
  if (tsb < -20) return main?.kind === 'pocitek' || main?.optional ? 'Utrujenost je visoka — današnji počitek je del načrta, ne luknja v njem.' : 'Utrujenost je visoka — danes ostani v Z2, tudi če se počutiš dobro. Jej do cilja.'
  if (tsb > 10) return main?.kind === 'kolo' ? 'Svež si. Če je danes kakovosten dan, ga izkoristi — to je pravi trenutek.' : 'Svež si — dober čas za kakovostno sejo ta teden.'
  return 'Forma je v pravem območju. Drži se načrta, ne dodajaj. Beljakovine do cilja.'
}

/** »1 neoznačena«, »2 neoznačeni«, »3 neoznačene«, »5 neoznačenih« (seja) */
function unmarkedWord(n: number): string { return n === 1 ? 'neoznačena' : n === 2 ? 'neoznačeni' : n <= 4 ? 'neoznačene' : 'neoznačenih' }
