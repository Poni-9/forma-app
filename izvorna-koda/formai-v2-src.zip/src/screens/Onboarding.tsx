import { useMemo, useState } from 'react'
import { navigate } from '@/app/router'
import { useApp, updateProfile, savePlanDays, toast, signIn, saveCheckin } from '@/state/store'
import type { Profile } from '@/domain/types'
import { buildWeek, weekMinutes, firstPlanWeekStart } from '@/domain/training/planner'
import { fmtDur, todayIso } from '@/domain/training/load'
import { Btn, Option, Progress, Chip, kindColor, DAYS_SL } from '@/ui/primitives'
import { IcoBike, IcoTrainer, IcoRun, IcoScale, IcoTarget, IcoHeart, IcoDumbbell, IcoChat, IcoBack, IcoWatch, IcoPhone, IcoFile } from '@/ui/icons'

/** 8 korakov iz dizajna v2: cilj · oprema · forma · o tebi · moč · vir podatkov · račun · prvi teden. */
const STEPS = ['cilj', 'oprema', 'forma', 'o-tebi', 'moc', 'podatki', 'racun', 'teden'] as const
type Step = typeof STEPS[number]

export function Onboarding({ start }: { start?: string }) {
  const app = useApp()
  const [i, setI] = useState(Math.max(0, STEPS.indexOf((start as Step) || 'cilj')))
  const [p, setP] = useState<Profile>(() => ({ ...app.profile }))
  const [signing, setSigning] = useState(false)
  const step = STEPS[i]!
  const pct = ((i + 1) / STEPS.length) * 100
  const patch = (x: Partial<Profile>) => setP(prev => ({ ...prev, ...x }))

  const back = () => (i === 0 ? (app.profile.onboardingDone ? navigate('danes') : undefined) : setI(i - 1))
  const next = () => setI(Math.min(STEPS.length - 1, i + 1))

  const startWs = firstPlanWeekStart(todayIso())
  const week = useMemo(() => buildWeek({ profile: { ...p, onboardingDone: true, cycleStart: p.cycleStart || startWs }, activities: app.activities, weekStart: startWs, firstWeek: true }), [p, app.activities, startWs])

  async function finish() {
    await updateProfile({ ...p, onboardingDone: true, cycleStart: p.cycleStart || startWs })
    if (p.weightKg) await saveCheckin({ date: todayIso(), weightKg: p.weightKg })
    await savePlanDays(week)
    toast('Načrt je pripravljen. Dober začetek! 🚀', 'ok')
    navigate('danes')
  }

  return (
    <div className="ob">
      {step !== 'teden' && (
        <div className="between" style={{ marginBottom: 14 }}>
          <button className="avatar" style={{ background: 'transparent', width: 34, height: 34 }} onClick={back} aria-label="Nazaj"><IcoBack /></button>
          <div className="muted" style={{ fontSize: 12, fontWeight: 700 }}>{i + 1} / {STEPS.length}</div>
        </div>
      )}
      <Progress pct={pct} />

      {step === 'cilj' && (<>
        <h2>Kaj hočeš doseči?</h2>
        <p style={{ marginTop: 7, fontSize: 14 }}>Načrt bo sestavljen okoli tega odgovora.</p>
        <div className="stack" style={{ marginTop: 20, gap: 10 }}>
          <Option icon={<IcoBike />} title="Hitrejši na kolesu" sub="Več moči, boljša vzdržljivost" on={p.goal === 'hitrejsi'} onClick={() => patch({ goal: 'hitrejsi' })} />
          <Option icon={<IcoScale />} title="Shujšati" sub="Varen deficit, brez izgube moči" on={p.goal === 'shujsati'} onClick={() => patch({ goal: 'shujsati' })} />
          <Option icon={<IcoTarget />} title="Priprava na dirko ali maraton" sub="Vrhunec točno na dan D" on={p.goal === 'dirka'} onClick={() => patch({ goal: 'dirka' })} />
          <Option icon={<IcoHeart />} title="Ostati v formi in zdrav" sub="Brez dirk, samo redno" on={p.goal === 'forma'} onClick={() => patch({ goal: 'forma' })} />
        </div>
        {p.goal === 'dirka' && (
          <div className="field" style={{ marginTop: 14 }}><label>Datum dirke</label><input type="date" value={p.raceDate || ''} onChange={e => patch({ raceDate: e.target.value || null })} /></div>
        )}
        <div className="grow" />
        <Btn primary block disabled={!p.goal} onClick={next}>Naprej</Btn>
      </>)}

      {step === 'oprema' && (<>
        <h2>S čim treniraš?</h2>
        <p style={{ marginTop: 7, fontSize: 14 }}>Če kolesa nimaš, dobiš načrt za tek in hojo. Vse ostalo ostane enako.</p>
        <div className="stack" style={{ marginTop: 20, gap: 10 }}>
          <Option icon={<IcoBike />} title="Kolo — zunaj" sub="Cestno, gravel ali gorsko" on={p.gear.bikeOutdoor} onClick={() => patch({ gear: { ...p.gear, bikeOutdoor: !p.gear.bikeOutdoor, noBike: false } })} />
          <Option icon={<IcoTrainer />} title="Kolo — trenažer" sub="Zwift, Rouvy ali brez zaslona" on={p.gear.trainer} onClick={() => patch({ gear: { ...p.gear, trainer: !p.gear.trainer, noBike: false } })} />
          <Option icon={<IcoRun />} title="Nimam kolesa" sub="Načrt za tek in hojo" on={p.gear.noBike} onClick={() => patch({ gear: { bikeOutdoor: false, trainer: false, noBike: true } })} />
        </div>
        <div className="card tight" style={{ marginTop: 14, display: 'flex', gap: 11, alignItems: 'flex-start' }}>
          <div style={{ width: 28, height: 28, borderRadius: 'var(--r-s)', background: 'var(--accent-soft)', display: 'grid', placeItems: 'center', flex: 'none', color: 'var(--accent)' }}><IcoHeart width={15} height={15} /></div>
          <p style={{ fontSize: 12.5 }}>Izbereš lahko več stvari. Če imaš kolo pozimi na trenažerju in poleti zunaj, to upoštevam.</p>
        </div>
        <div className="grow" />
        <Btn primary block disabled={!(p.gear.bikeOutdoor || p.gear.trainer || p.gear.noBike)} onClick={next}>Naprej</Btn>
      </>)}

      {step === 'forma' && (<>
        <h2>V kakšni formi si zdaj?</h2>
        <p style={{ marginTop: 7, fontSize: 14 }}>Brez tega ti lahko dam samo splošen načrt. S tem dobiš svojega.</p>
        <div className="stack" style={{ marginTop: 18, gap: 8 }}>
          {([[1, 'Začenjam', 'Manj kot 2 h na teden'], [2, 'Rekreativno', '2–5 h, brez strukture'], [3, 'Redno treniram', '5–10 h, poznam cone'], [4, 'Tekmujem', 'Več kot 10 h, imam FTP']] as const).map(([lvl, t, s]) => (
            <Option key={lvl} icon={<b style={{ fontSize: 13 }}>{lvl}</b>} title={t} sub={s} on={p.level === lvl} onClick={() => patch({ level: lvl, hoursPerWeek: p.hoursPerWeek || ({ 1: 2, 2: 4, 3: 7, 4: 11 })[lvl] })} style={{ padding: '12px 14px' }} />
          ))}
        </div>
        <div className="field" style={{ marginTop: 14 }}>
          <label>Ur na teden, ki jih res imaš <span className="unit">(vključno z močjo)</span></label>
          <input type="number" inputMode="decimal" min={1} max={25} step={0.5} value={p.hoursPerWeek ?? ''} onChange={e => patch({ hoursPerWeek: e.target.value ? +e.target.value : null })} placeholder="npr. 5" />
        </div>
        <div className="grow" />
        <div className="muted" style={{ fontSize: 11.5, textAlign: 'center', marginBottom: 10 }}>V prvi teden vključim 20-minutni test, da dobim tvoje cone natančno.</div>
        <Btn primary block disabled={!p.level} onClick={next}>Naprej</Btn>
      </>)}

      {step === 'o-tebi' && (<>
        <h2>Nekaj o tebi</h2>
        <p style={{ marginTop: 7, fontSize: 14 }}>Za kalorije potrebujem višino, težo, starost in spol. Brez tega ti številk ne pokažem — raje prazno kot narobe.</p>
        <div className="stack" style={{ marginTop: 18, gap: 12 }}>
          <div className="field"><label>Ime</label><input value={p.name || ''} onChange={e => patch({ name: e.target.value })} placeholder="Kako naj te kličem?" autoComplete="given-name" /></div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <div className="field"><label>Starost</label><input type="number" inputMode="numeric" min={12} max={99} value={p.age ?? ''} onChange={e => patch({ age: e.target.value ? +e.target.value : null })} /></div>
            <div className="field"><label>Spol</label>
              <select value={p.sex || ''} onChange={e => patch({ sex: (e.target.value as any) || null })}><option value="">—</option><option value="m">Moški</option><option value="z">Ženska</option></select></div>
            <div className="field"><label>Višina <span className="unit">cm</span></label><input type="number" inputMode="numeric" min={120} max={230} value={p.heightCm ?? ''} onChange={e => patch({ heightCm: e.target.value ? +e.target.value : null })} /></div>
            <div className="field"><label>Teža <span className="unit">kg</span></label><input type="number" inputMode="decimal" min={30} max={250} step={0.1} value={p.weightKg ?? ''} onChange={e => patch({ weightKg: e.target.value ? +e.target.value : null })} /></div>
            <div className="field"><label>Max utrip <span className="unit">neobvezno</span></label><input type="number" inputMode="numeric" min={120} max={230} value={p.maxHr ?? ''} onChange={e => patch({ maxHr: e.target.value ? +e.target.value : null })} /></div>
            <div className="field"><label>Ciljna teža <span className="unit">kg, neobvezno</span></label><input type="number" inputMode="decimal" min={35} max={200} step={0.5} value={p.targetWeightKg ?? ''} onChange={e => patch({ targetWeightKg: e.target.value ? +e.target.value : null })} /></div>
            <div className="field"><label>FTP <span className="unit">W, neobvezno</span></label><input type="number" inputMode="numeric" min={50} max={600} value={p.ftp ?? ''} onChange={e => patch({ ftp: e.target.value ? +e.target.value : null, ftpDate: e.target.value ? todayIso() : null })} /></div>
          </div>
        </div>
        {p.age != null && p.age < 18 && <div className="card tight" style={{ marginTop: 12 }}><p style={{ fontSize: 12.5 }}>Do 18. leta ne načrtujem hujšanja — cilj kalorij je vedno vzdrževanje. Hujšanje v tem obdobju sodi pod zdravniški nadzor, ne v aplikacijo.</p></div>}
        <div className="grow" />
        <Btn primary block onClick={next}>Naprej</Btn>
        <Btn ghost block style={{ marginTop: 9 }} onClick={next}>Izpolnim pozneje</Btn>
      </>)}

      {step === 'moc' && (<>
        <Chip sm>Neobvezno</Chip>
        <h2 style={{ marginTop: 11 }}>Dodaš moč?</h2>
        <p style={{ marginTop: 7, fontSize: 14 }}>Moč za kolesarja: jedro in noge, 20–30 minut, po kolesu. Stabilen trup in močne noge za klance — ne bodybuilding. Ponovitve rastejo same.</p>
        <div className="card" style={{ marginTop: 18, padding: 16 }}>
          <div className="between">
            <div className="row" style={{ gap: 12 }}>
              <div style={{ width: 40, height: 40, borderRadius: 'var(--r-s)', background: 'var(--raised)', display: 'grid', placeItems: 'center', color: 'var(--t-moc)' }}><IcoDumbbell /></div>
              <div><b style={{ fontSize: 15 }}>Moč</b><div className="muted" style={{ fontSize: 12, fontWeight: 600 }}>{Math.min(2, p.strengthDays ?? 2)} × 20–30 min na teden</div></div>
            </div>
            <button type="button" aria-label="Vklopi moč" onClick={() => patch({ strength: { ...p.strength, on: !p.strength.on } })}
              style={{ width: 48, height: 28, borderRadius: 'var(--r-full)', background: p.strength.on ? 'var(--accent)' : 'var(--raised)', position: 'relative', flex: 'none', border: 0, cursor: 'pointer' }}>
              <div style={{ position: 'absolute', top: 3, left: p.strength.on ? 23 : 3, width: 22, height: 22, borderRadius: 'var(--r-full)', background: p.strength.on ? 'var(--accent-ink)' : 'var(--ink-3)', transition: 'left .15s' }} />
            </button>
          </div>
          {p.strength.on && (
            <div style={{ marginTop: 14, paddingTop: 13, borderTop: '1px solid var(--line)' }}>
              <div className="muted" style={{ fontSize: 11, fontWeight: 700, letterSpacing: '.06em', marginBottom: 8 }}>KOLIKOKRAT NA TEDEN</div>
              <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>
                {[1, 2].map(n => <Chip key={n} sm on={Math.min(2, p.strengthDays ?? 2) === n} onClick={() => patch({ strengthDays: n })}>{n}×</Chip>)}
              </div>
              <div className="muted" style={{ fontSize: 11, fontWeight: 700, letterSpacing: '.06em', margin: '12px 0 8px' }}>DOMA IMAM</div>
              <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>
                <Chip sm on={!!p.gear.dumbbells} onClick={() => patch({ gear: { ...p.gear, dumbbells: !p.gear.dumbbells } })}>Uteži</Chip>
              </div>
            </div>
          )}
        </div>
        <div className="card tight" style={{ marginTop: 10, display: 'flex', gap: 11, alignItems: 'flex-start' }}>
          <div style={{ width: 28, height: 28, borderRadius: 'var(--r-s)', background: 'var(--raised)', display: 'grid', placeItems: 'center', flex: 'none', color: 'var(--ink-2)' }}><IcoChat width={15} height={15} /></div>
          <p style={{ fontSize: 12.5 }}>Moč lahko kadarkoli izklopiš v Nastavitvah. Načrt se prilagodi isti dan.</p>
        </div>
        <div className="grow" />
        <Btn primary block onClick={next}>Naprej</Btn>
        {p.strength.on && <Btn ghost block style={{ marginTop: 9 }} onClick={() => { patch({ strength: { ...p.strength, on: false }, strengthDays: 0 }); next() }}>Brez moči, samo kolo</Btn>}
      </>)}

      {step === 'podatki' && (<>
        <h2>S čim beležiš vožnje?</h2>
        <p style={{ marginTop: 7, fontSize: 14 }}>Povem ti najkrajšo pot, da trener vidi, kar res odpelješ. Nastaviš lahko tudi pozneje.</p>
        <div className="stack" style={{ marginTop: 18, gap: 10 }}>
          <Option icon={<IcoWatch />} title="Garmin ura ali števec" sub="Samodejno prek intervals.icu — enkrat nastaviš" onClick={() => { next(); }} />
          <Option icon={<IcoWatch />} title="Wahoo, Polar, COROS, Suunto" sub="Enako — prek intervals.icu" onClick={() => { next(); }} />
          <Option icon={<IcoPhone />} title="Samo telefon" sub="Posnetek zaslona ali ročni vnos — 5 sekund" onClick={() => { next(); }} />
          <Option icon={<IcoFile />} title="Imam datoteke (.fit, .gpx, .zip)" sub="Odloži jih kadar koli v aplikacijo" onClick={() => { next(); }} />
        </div>
        <div className="card tight" style={{ marginTop: 12 }}><p style={{ fontSize: 12.5 }}>Strava? Njene vožnje lahko uvoziš iz svojega Strava arhiva (Nastavitve → Prenesi arhiv). Neposredna povezava s Stravo trenerju ne sme pokazati ničesar — zato je ne ponujam.</p></div>
        <div className="grow" />
        <Btn ghost block onClick={next}>Preskoči</Btn>
      </>)}

      {step === 'racun' && (<>
        <h2>Najprej tvoj račun</h2>
        <p style={{ marginTop: 7, fontSize: 14 }}>Z računom je isti načrt na telefonu in računalniku. Podatki o vožnjah in sledi ostanejo na tvoji napravi.</p>
        {app.user ? (
          <div className="card accent" style={{ marginTop: 18 }}>
            <div className="row" style={{ gap: 12 }}>
              {app.user.photo ? <img src={app.user.photo} alt="" width={40} height={40} style={{ borderRadius: 999 }} referrerPolicy="no-referrer" /> : <div className="avatar">{(app.user.name || '?').slice(0, 2).toUpperCase()}</div>}
              <div style={{ flex: 1, minWidth: 0 }}><b style={{ fontSize: 14 }}>Prijavljen kot {app.user.name || 'Google račun'}</b><div className="muted" style={{ fontSize: 12, overflow: 'hidden', textOverflow: 'ellipsis' }}>{app.user.email}</div></div>
            </div>
          </div>
        ) : (
          <div className="card" style={{ marginTop: 18 }}>
            <b style={{ fontSize: 14 }}>Prijava z Googlom</b>
            <p style={{ fontSize: 12.5, marginTop: 4 }}>Ena sekunda. Brez gesla, brez e-poštne potrditve. AI trener teče prek tvojega računa.</p>
            <Btn primary block sm style={{ marginTop: 12 }} disabled={signing} onClick={async () => { setSigning(true); try { const u = await signIn(); if (u) next() } catch (e) { toast((e as Error).message, 'err') } finally { setSigning(false) } }}>{signing ? 'Odpiram prijavo …' : 'Prijava z Googlom'}</Btn>
          </div>
        )}
        <div className="grow" />
        <Btn primary block onClick={next}>{app.user ? 'Naprej' : 'Nadaljuj brez računa (samo ta naprava)'}</Btn>
        {!app.user && <div className="muted" style={{ fontSize: 11.5, textAlign: 'center', marginTop: 9 }}>Račun lahko dodaš kadar koli v Nastavitvah.</div>}
      </>)}

      {step === 'teden' && (<>
        <Chip on sm>Načrt je pripravljen</Chip>
        <h2 style={{ marginTop: 10 }}>Tvoj prvi teden</h2>
        <p style={{ marginTop: 6, fontSize: 14 }}>Bloki 3 + 1: osnova → gradnja → specifično · {fmtDur(weekMinutes(week))} ta teden. Cilj (dirko) nastaviš na Danes.</p>
        <div className="stack" style={{ marginTop: 16, gap: 8 }}>
          {week.map(d => {
            const [y, m, dd] = d.date.split('-').map(Number) as [number, number, number]
            const dow = DAYS_SL[(new Date(y, m - 1, dd).getDay() + 6) % 7]
            return (
              <div key={d.id} className="card tight row" style={{ gap: 12 }}>
                <span className="dot" style={{ background: d.optional ? 'var(--t-poc)' : kindColor(d.kind) }} />
                <div style={{ flex: 1, minWidth: 0 }}><b style={{ fontSize: 14 }}>{dow!.charAt(0).toUpperCase() + dow!.slice(1)} · {d.title}</b><div className="muted" style={{ fontSize: 12 }}>{d.kind === 'pocitek' ? d.desc : `${fmtDur(d.durationMin)}${d.optional ? ' · po želji' : d.zone && d.zone !== 'test' ? ' · ' + d.zone : ''}${d.exercises ? ` · ${d.exercises.length} vaj` : ''}`}</div></div>
              </div>
            )
          })}
        </div>
        <div className="grow" />
        <Btn primary block style={{ marginTop: 12 }} onClick={finish}>Začni</Btn>
        <div style={{ textAlign: 'center', fontSize: 11, color: 'var(--ink-3)', marginTop: 9 }}>Načrt lahko kadarkoli spremeniš.</div>
      </>)}
    </div>
  )
}
