import { useEffect, useMemo, useRef, useState } from 'react'
import { navigate } from '@/app/router'
import { markApp } from '@/app/landing'
import { useApp, getState, updateProfile, updateSettings, savePlanDays, toast, signIn, saveCheckin } from '@/state/store'
import type { Profile, PlanDay } from '@/domain/types'
import { buildWeek, weekMinutes, weekContext, FRANJA_2027 } from '@/domain/training/planner'
import { addDays, fmtDur, weekStartIso } from '@/domain/training/load'
import { Btn, Option, Progress, Chip, kindColor, DAYS_SL } from '@/ui/primitives'
import { DateField, fmtDateSl } from '@/ui/DateField'
import { IcoBike, IcoTrainer, IcoScale, IcoTarget, IcoHeart, IcoDumbbell, IcoBack, IcoCheck } from '@/ui/icons'

/**
 * Uvod v treh korakih: cilj · čas · o tebi. Takoj za tem prvih 7 dni načrta.
 * Vse ostalo (ura, moč v podrobnostih, gorivo, tekme B/C) aplikacija vpraša takrat, ko je potrebno.
 */
const STEPS = ['cilj', 'cas', 'o-tebi'] as const
type Step = typeof STEPS[number] | 'teden'

const num = (v: string, lo: number, hi: number) => { const x = +v.replace(',', '.'); return v.trim() !== '' && Number.isFinite(x) && x >= lo && x <= hi ? x : null }
const HOURS = [3, 5, 7, 10, 14, 18]
const SEASONS: [number, string][] = [[1, 'prva'], [2, 'druga'], [3, '3.–4.'], [6, '5.–7.'], [9, '8 ali več']]
const rides = (h: number) => (h < 5 ? '2–3 vožnje' : h < 8 ? '3–4 vožnje' : h < 12 ? '4–5 voženj' : '5–6 voženj')

export function Onboarding({ start }: { start?: string }) {
  const app = useApp()
  const p0 = app.profile
  const [i, setI] = useState(Math.max(0, STEPS.indexOf((start as typeof STEPS[number]) || 'cilj')))
  const [done, setDone] = useState(false)
  const wasDone = useRef(p0.onboardingDone).current
  const step: Step = done ? 'teden' : STEPS[i]!
  const today = app.today
  const [f, setF] = useState(() => ({
    goal: (p0.onboardingDone ? p0.goal : null) as Profile['goal'] | null,
    race: p0.event?.name || '', date: p0.event?.date || '', km: p0.event?.distanceKm ? String(p0.event.distanceKm) : '',
    hours: p0.hoursPerWeek ? String(p0.hoursPerWeek) : '', seasons: p0.trainingSeasons ?? null as number | null,
    outdoor: p0.gear.bikeOutdoor, trainer: p0.gear.trainer, strength: p0.strength.on,
    name: p0.name || '', age: p0.age ? String(p0.age) : '', sex: p0.sex, height: p0.heightCm ? String(p0.heightCm) : '',
    weight: p0.weightKg ? String(p0.weightKg) : '', ftp: p0.ftp ? String(p0.ftp) : '',
  }))
  const patch = (x: Partial<typeof f>) => setF(prev => ({ ...prev, ...x }))
  const hours = num(f.hours, 2, 30)
  const age = num(f.age, 12, 99), height = num(f.height, 120, 230), weight = num(f.weight, 30, 250), ftp = num(f.ftp, 50, 600)
  const raceOk = f.goal !== 'dirka' || (f.race.trim().length > 1 && !!f.date && f.date > today)
  const ws = weekStartIso(today)

  /** osnutek profila iz odgovorov — iz njega je sestavljen prvi teden (shrani se šele ob »Začni«) */
  const draft: Profile = useMemo(() => {
    const seasons = f.seasons
    const h = hours ?? 7
    const level = (h <= 3 ? 1 : seasons != null && seasons >= 3 && h >= 10 ? 4 : seasons != null && seasons <= 1 ? 2 : 3) as Profile['level']
    return {
      ...p0,
      name: f.name.trim() || p0.name, age, sex: f.sex, heightCm: height, weightKg: weight,
      ftp: ftp ?? p0.ftp ?? null, ftpDate: ftp && ftp !== p0.ftp ? today : p0.ftpDate ?? null,
      goal: f.goal || 'hitrejsi',
      event: f.goal === 'dirka' ? { ...(p0.event || {}), name: f.race.trim().slice(0, 60), date: f.date, distanceKm: num(f.km, 1, 400) } : p0.onboardingDone ? p0.event ?? null : null,
      raceDate: f.goal === 'dirka' ? f.date : null,
      hoursPerWeek: h, hoursMode: 'own', level, trainingSeasons: seasons,
      gear: { ...p0.gear, bikeOutdoor: f.outdoor, trainer: f.trainer, noBike: false },
      strength: { ...p0.strength, on: f.strength }, strengthDays: f.strength ? 2 : 0,
      goalStart: { date: today, ftp: ftp ?? p0.ftp ?? null, weightKg: weight },
      cycleStart: ws, offSeasonWeeks: 0, baseHours: null, onboardingDone: true,
    }
  }, [f, hours, age, height, weight, ftp, p0, today, ws])

  // prvih 7 dni: preostanek tega tedna + začetek naslednjega
  const days: PlanDay[] = useMemo(() => {
    if (step !== 'teden') return []
    const w1 = buildWeek({ profile: draft, activities: app.activities, weekStart: ws, firstWeek: true, notBefore: today })
    const w2 = buildWeek({ profile: draft, activities: app.activities, weekStart: addDays(ws, 7), notBefore: addDays(ws, 7) })
    return [...w1, ...w2]
  }, [step, draft, app.activities, ws, today])
  const next7 = days.filter(d => d.date >= today && d.date < addDays(today, 7)).sort((a, b) => a.date.localeCompare(b.date) || (a.kind === 'moc' ? 1 : 0) - (b.kind === 'moc' ? 1 : 0))
  // en dan = ena vrstica (kolo + moč skupaj)
  const byDay = Array.from({ length: 7 }, (_, k) => addDays(today, k)).map(date => ({ date, items: next7.filter(d => d.date === date) })).filter(x => x.items.length)
  const easyStart = step === 'teden' && weekContext(draft, ws).easy > 0
  const why = easyStart
    ? `Prvi trije tedni so lažji (Z2, kratki šprinti${draft.strength.on ? ' in moč' : ''}), da se telo navadi na redni trening. Nato pridejo intervali${draft.ftp ? '' : ' in 20-minutni test FTP, iz katerega dobiš svoje cone'}.`
    : next7.find(d => d.kind !== 'pocitek' && !d.optional && d.why)?.why

  const back = () => (done ? setDone(false) : i === 0 ? (p0.onboardingDone ? navigate('danes') : navigate('')) : setI(i - 1))
  const next = () => (i < STEPS.length - 1 ? setI(i + 1) : setDone(true))
  useEffect(() => { window.scrollTo(0, 0) }, [i, done])

  // prijava na koncu: če ima račun že načrt, ga ne prepišemo z osnutkom
  const [signing, setSigning] = useState(false)
  const [waitSync, setWaitSync] = useState(false)
  useEffect(() => {
    if (!waitSync || !app.firstSync) return
    setWaitSync(false)
    if (getState().profile.onboardingDone) { toast('Na tem računu že imaš načrt — nadaljuješ, kjer si ostal.', 'ok', 6000); markApp(); navigate('danes') }
  }, [waitSync, app.firstSync])

  async function finish() {
    if (!wasDone && getState().profile.onboardingDone) { markApp(); navigate('danes'); return }   // račun je medtem prinesel načrt
    await updateProfile(draft)
    if (weight) await saveCheckin({ date: today, weightKg: weight })
    await savePlanDays(days.filter(d => d.date >= today))
    await updateSettings({ guideSeen: false })   // na Danes se enkrat pokaže »Kako deluje« (3 koraki)
    markApp()
    toast('Načrt je pripravljen. Dober začetek!', 'ok')
    navigate('danes')
  }

  const title = (t: string, sub: string) => (<><h2>{t}</h2><p style={{ marginTop: 7, fontSize: 14 }}>{sub}</p></>)

  return (
    <div className="ob">
      <div className="between" style={{ marginBottom: 14, minHeight: 34 }}>
        <button className="avatar" style={{ background: 'transparent', width: 40, height: 40 }} onClick={back} aria-label="Nazaj"><IcoBack /></button>
        {step === 'cilj' && !p0.onboardingDone && !app.user
          ? <button className="chip sm click" onClick={() => navigate('prijava')}>Že imam račun</button>
          : step !== 'teden' ? <div className="muted" style={{ fontSize: 12, fontWeight: 700 }}>{i + 1} / {STEPS.length}</div> : null}
      </div>
      {step !== 'teden' && <Progress pct={((i + 1) / STEPS.length) * 100} />}

      {step === 'cilj' && (<>
        {title('Za kaj treniraš?', 'Načrt bo sestavljen okoli tega. Spremeniš ga lahko kadar koli.')}
        <div className="stack" style={{ marginTop: 18, gap: 10 }}>
          <Option icon={<IcoTarget />} title="Tekma ali cilj z datumom" sub="Maraton, dirka, vzpon — forma na vrhu točno takrat" on={f.goal === 'dirka'} onClick={() => patch({ goal: 'dirka' })} />
          {f.goal === 'dirka' && (
            <div className="card tight stack" style={{ gap: 10 }}>
              <div className="field"><label>Tekma</label><input value={f.race} onChange={e => patch({ race: e.target.value })} placeholder="npr. Maraton Franja" autoComplete="off" /></div>
              <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 10 }}>
                <div className="field"><label>Datum</label><DateField value={f.date} min={addDays(today, 1)} onChange={v => patch({ date: v })} label="Datum tekme" /></div>
                <div className="field"><label>Dolžina <span className="unit">km</span></label><input type="number" inputMode="numeric" value={f.km} onChange={e => patch({ km: e.target.value })} placeholder="neobvezno" /></div>
              </div>
              {FRANJA_2027.date > today && f.race !== FRANJA_2027.name && (
                <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>
                  <Chip sm onClick={() => patch({ race: FRANJA_2027.name, date: FRANJA_2027.date, km: String(FRANJA_2027.distanceKm) })}>{FRANJA_2027.name} · {fmtDateSl(FRANJA_2027.date, false)}</Chip>
                </div>
              )}
              {f.date && f.date <= today && <div style={{ fontSize: 12, color: 'var(--warn)' }}>Datum mora biti v prihodnosti.</div>}
              <div className="muted" style={{ fontSize: 11.5 }}>Druge tekme sezone (A, B, C) dodaš kasneje v Planu — načrt se prilagodi vsem.</div>
            </div>
          )}
          <Option icon={<IcoBike />} title="Hitrejši na kolesu" sub="Več moči in vzdržljivosti, brez datuma" on={f.goal === 'hitrejsi'} onClick={() => patch({ goal: 'hitrejsi' })} />
          <Option icon={<IcoScale />} title="Shujšati, moč ostane" sub="Varen deficit, nikoli na račun treninga" on={f.goal === 'shujsati'} onClick={() => patch({ goal: 'shujsati' })} />
          <Option icon={<IcoHeart />} title="Forma in zdravje" sub="Redno, brez pritiska" on={f.goal === 'forma'} onClick={() => patch({ goal: 'forma' })} />
        </div>
        <div className="grow" style={{ minHeight: 18 }} />
        <Btn primary block disabled={!f.goal || !raceOk} onClick={next}>Naprej</Btn>
      </>)}

      {step === 'cas' && (<>
        {title('Koliko časa imaš?', 'Ure na teden, ki jih res imaš (skupaj z močjo). Načrt začne lažje in raste postopoma.')}
        <div className="field" style={{ marginTop: 18 }}>
          <label>Ur na teden</label>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>
            {HOURS.map(h => <Chip key={h} on={hours === h} onClick={() => patch({ hours: String(h) })}>{h} h</Chip>)}
          </div>
          {hours != null && <div className="muted" style={{ fontSize: 12 }}>{String(hours).replace('.', ',')} h ≈ {rides(hours)}{f.strength ? ' + 2× moč' : ''} na teden.</div>}
        </div>
        <div className="field" style={{ marginTop: 16 }}>
          <label>Katera sezona resnega treninga je to?</label>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>
            {SEASONS.map(([v, l]) => <Chip key={v} on={f.seasons === v} onClick={() => patch({ seasons: v })}>{l}</Chip>)}
          </div>
          <div className="muted" style={{ fontSize: 12 }}>V prvih sezonah napreduješ hitreje — upoštevam pri ciljih.</div>
        </div>
        <div className="field" style={{ marginTop: 16 }}>
          <label>Kje voziš</label>
          <div className="stack" style={{ gap: 8 }}>
            <Option icon={<IcoBike />} title="Zunaj" sub="Cestno, gravel ali gorsko" on={f.outdoor} onClick={() => patch({ outdoor: !f.outdoor })} style={{ padding: '12px 14px' }} />
            <Option icon={<IcoTrainer />} title="Trenažer" sub="Pozimi ali ko dežuje" on={f.trainer} onClick={() => patch({ trainer: !f.trainer })} style={{ padding: '12px 14px' }} />
          </div>
        </div>
        <button type="button" className={`opt ${f.strength ? 'on' : ''}`} style={{ marginTop: 10, padding: '12px 14px' }} onClick={() => patch({ strength: !f.strength })} aria-pressed={f.strength}>
          <div className="oi"><IcoDumbbell /></div>
          <div style={{ flex: 1 }}>Moč 2× na teden<small>20–30 min doma: jedro in noge za klance</small></div>
          <span className={`switch ${f.strength ? 'on' : ''}`} aria-hidden="true"><i /></span>
        </button>
        <div className="grow" style={{ minHeight: 18 }} />
        <Btn primary block disabled={hours == null || f.seasons == null || !(f.outdoor || f.trainer)} onClick={next}>Naprej</Btn>
      </>)}

      {step === 'o-tebi' && (<>
        {title('Še nekaj o tebi', 'Za kalorije in vate. Brez tega kalorij ne pokažem — raje prazno kot narobe.')}
        <div className="stack" style={{ marginTop: 18, gap: 12 }}>
          <div className="field"><label>Ime <span className="unit">neobvezno</span></label><input value={f.name} onChange={e => patch({ name: e.target.value })} placeholder="Kako naj te kličem?" autoComplete="given-name" /></div>
          <div className="field"><label>Spol</label>
            <div className="row" style={{ gap: 7 }}>{([['m', 'Moški'], ['z', 'Ženska']] as const).map(([v, l]) => <Chip key={v} on={f.sex === v} onClick={() => patch({ sex: v })}>{l}</Chip>)}</div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
            <div className="field"><label>Starost</label><input type="number" inputMode="numeric" min={12} max={99} value={f.age} onChange={e => patch({ age: e.target.value })} /></div>
            <div className="field"><label>Višina <span className="unit">cm</span></label><input type="number" inputMode="numeric" min={120} max={230} value={f.height} onChange={e => patch({ height: e.target.value })} /></div>
            <div className="field"><label>Teža <span className="unit">kg</span></label><input type="number" inputMode="decimal" min={30} max={250} step={0.1} value={f.weight} onChange={e => patch({ weight: e.target.value })} /></div>
          </div>
          <div className="field"><label>FTP <span className="unit">W, neobvezno</span></label><input type="number" inputMode="numeric" min={50} max={600} value={f.ftp} onChange={e => patch({ ftp: e.target.value })} placeholder="ne vem" />
            <div className="muted" style={{ fontSize: 12 }}>Ne veš? V načrtu je 20-minutni test — iz njega dobiš svoje cone. Do takrat voziš po utripu in občutku.</div>
          </div>
        </div>
        {age != null && age < 18 && <div className="card tight" style={{ marginTop: 12 }}><p style={{ fontSize: 12.5 }}>Do 18. leta ne načrtujem hujšanja — cilj kalorij je vedno vzdrževanje. Hujšanje v tem obdobju sodi pod zdravniški nadzor, ne v aplikacijo.</p></div>}
        <div className="grow" style={{ minHeight: 18 }} />
        <Btn primary block onClick={next}>Pokaži moj teden</Btn>
        <Btn ghost block style={{ marginTop: 9 }} onClick={next}>Izpolnim pozneje</Btn>
      </>)}

      {step === 'teden' && (<>
        <div style={{ alignSelf: 'flex-start' }}><Chip on sm><IcoCheck width={13} height={13} /> Načrt je pripravljen</Chip></div>
        <h2 style={{ marginTop: 10 }}>Tvojih prvih 7 dni</h2>
        <p style={{ marginTop: 6, fontSize: 14 }}>
          {fmtDur(weekMinutes(next7))} · lahek začetek: prvi trije tedni so mirnejši, potem načrt raste.{draft.event ? ` Cilj: ${draft.event.name}, ${fmtDateSl(draft.event.date)}.` : ''}
        </p>
        <div className="stack" style={{ marginTop: 14, gap: 8 }}>
          {byDay.map(({ date, items }) => {
            const [y, m, dd] = date.split('-').map(Number) as [number, number, number]
            const dow = DAYS_SL[(new Date(y, m - 1, dd).getDay() + 6) % 7]!
            const main = items[0]!, rest = main.kind === 'pocitek'
            const extra = items.slice(1).filter(d => d.kind !== 'pocitek')
            return (
              <div key={date} className="card tight row" style={{ gap: 12, opacity: rest ? 0.7 : 1 }}>
                <div style={{ width: 34, textAlign: 'center', flex: 'none' }}><div className="muted" style={{ fontSize: 10.5, fontWeight: 800, textTransform: 'uppercase' }}>{dow}</div><b style={{ fontSize: 15 }}>{dd}.</b></div>
                <span className="dot" style={{ background: main.optional ? 'var(--t-poc)' : kindColor(main.kind), flex: 'none' }} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <b style={{ fontSize: 14 }}>{rest ? 'Počitek' : main.title}</b>
                  {!rest && <div className="muted" style={{ fontSize: 12 }}>{fmtDur(main.durationMin)}{main.optional ? ' · po želji' : main.zone && main.zone !== 'test' ? ' · ' + main.zone : ''}{main.exercises ? ` · ${main.exercises.length} vaj` : ''}</div>}
                  {extra.map(x => <div key={x.id} style={{ fontSize: 12, marginTop: 2, color: 'var(--ink-2)' }}><span className="dot" style={{ background: kindColor(x.kind), width: 6, height: 6, marginRight: 6, verticalAlign: 1 }} />+ {x.title} · {fmtDur(x.durationMin)}</div>)}
                </div>
              </div>
            )
          })}
        </div>
        {why && <p className="muted" style={{ fontSize: 12.5, marginTop: 10 }}>{why}</p>}

        {!p0.onboardingDone && (app.user ? (
          <div className="card tight row" style={{ marginTop: 14, gap: 10 }}>
            <IcoCheck width={16} height={16} style={{ color: 'var(--ok)', flex: 'none' }} />
            <p style={{ fontSize: 12.5 }}>Prijavljen kot <b style={{ color: 'var(--ink)' }}>{app.user.name || app.user.email}</b> — načrt bo na vseh tvojih napravah.</p>
          </div>
        ) : (
          <div className="card tight" style={{ marginTop: 14 }}>
            <b style={{ fontSize: 13.5 }}>Shrani na vse naprave</b>
            <p style={{ fontSize: 12.5, marginTop: 3 }}>S prijavo z Googlom je isti načrt na telefonu in računalniku. Brez gesla. Lahko tudi pozneje.</p>
            <Btn sm style={{ marginTop: 10 }} disabled={signing || waitSync} onClick={async () => { setSigning(true); try { const u = await signIn(); if (u) setWaitSync(true) } catch (e) { toast((e as Error).message, 'err') } finally { setSigning(false) } }}>{signing ? 'Odpiram prijavo …' : waitSync ? 'Preverjam račun …' : 'Prijava z Googlom'}</Btn>
          </div>
        ))}
        <div className="grow" style={{ minHeight: 16 }} />
        <Btn primary block style={{ marginTop: 14 }} disabled={waitSync} onClick={finish}>Začni</Btn>
        <div style={{ textAlign: 'center', fontSize: 11, color: 'var(--ink-3)', marginTop: 9 }}>Načrt je trenerska usmeritev, ne zdravniški nasvet.</div>
      </>)}
    </div>
  )
}
