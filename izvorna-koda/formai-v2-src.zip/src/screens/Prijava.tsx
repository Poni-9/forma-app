import { useEffect, useState } from 'react'
import { navigate } from '@/app/router'
import { markApp } from '@/app/landing'
import { useApp, getState, signIn, toast, retrySync } from '@/state/store'
import { BackupImport } from '@/ui/BackupImport'
import { Btn } from '@/ui/primitives'
import { IcoBack, IcoCheck } from '@/ui/icons'

/**
 * »Že imam račun«: prijava z Googlom, nato počakamo na prvo usklajevanje z oblakom.
 * Račun z načrtom → Danes; račun brez načrta → uvod (Sestavi; prijava ostane).
 */
export function Prijava() {
  const app = useApp()
  const [busy, setBusy] = useState(false)
  const waiting = !!app.user && !app.firstSync
  // prvo usklajevanje ni uspelo: to NI prazen račun — ne pošiljaj v uvod, ponudi ponovni poskus
  const failed = !!app.user && app.firstSync === 'error'
  const [retrying, setRetrying] = useState(false)
  // (v3.49) prazen račun: namig, kje je načrt (druga naprava brez prijave), namesto samodejnega uvoda — prej je uporabnik
  // mislil, da je načrt izgubljen, in sestavil novega. Ko se druga naprava prijavi, načrt pride sem sam (poslušalec oblaka).
  const empty = !!app.user && !!app.firstSync && app.firstSync !== 'error' && !app.profile.onboardingDone

  useEffect(() => {
    if (!app.user || !app.firstSync || app.firstSync === 'error') return
    if (app.profile.onboardingDone) { markApp(); toast(`Dobrodošel nazaj${app.profile.name ? ', ' + app.profile.name.split(/\s+/)[0] : ''}.`, 'ok'); navigate('danes') }
  }, [app.user, app.firstSync, app.profile.onboardingDone])

  async function go() {
    setBusy(true)
    try { await signIn() } catch (e) { toast((e as Error).message, 'err') } finally { setBusy(false) }
  }

  return (
    <main className="ob">
      <div className="between" style={{ marginBottom: 14, minHeight: 34 }}>
        <button className="avatar" style={{ background: 'transparent', width: 40, height: 40 }} onClick={() => (history.length > 1 ? history.back() : navigate(''))} aria-label="Nazaj"><IcoBack /></button>
      </div>
      <div className="brand" style={{ fontWeight: 800, fontSize: 15, letterSpacing: '.02em' }}>FORM<span>AI</span></div>
      <h1 style={{ marginTop: 14, fontSize: 22, lineHeight: 1.2 }}>Prijava</h1>
      <p style={{ marginTop: 7, fontSize: 14 }}>Z Googlovim računom, ki si ga uporabil prej. Načrt, obroki in vožnje se naložijo sami.</p>
      <div className="card" style={{ marginTop: 20 }}>
        {empty ? (
          <div>
            <b style={{ fontSize: 14 }}>Na tem računu še ni načrta</b>
            <div className="muted" style={{ fontSize: 12.5, marginTop: 4 }}>Si ga sestavil na drugi napravi brez prijave? Načrt je na tisti napravi — tam se prijavi s tem računom (Nastavitve → Račun) in prenese se sem sam. Ali uvozi kopijo iz »Izvozi vse«.</div>
            <div className="row" style={{ gap: 8, marginTop: 12, flexWrap: 'wrap' }}>
              <Btn primary sm onClick={() => navigate('uvod')}>Sestavi nov načrt</Btn>
              <BackupImport fresh label="Uvozi kopijo" onDone={() => { if (getState().profile.onboardingDone) { markApp(); navigate('danes') } }} />
            </div>
          </div>
        ) : failed ? (
          <div>
            <b style={{ fontSize: 14 }}>Tvojih podatkov trenutno ne morem naložiti</b>
            <div className="muted" style={{ fontSize: 12.5, marginTop: 4 }}>{app.sync.msg || 'Povezava z oblakom ni uspela.'} Poskusim znova sam, lahko pa tudi zdaj.</div>
            <Btn block style={{ marginTop: 12 }} disabled={retrying} onClick={async () => { setRetrying(true); await retrySync(); setRetrying(false) }}>{retrying ? 'Poskušam …' : 'Poskusi znova'}</Btn>
          </div>
        ) : waiting ? (
          <div className="row" style={{ gap: 12 }}>
            <IcoCheck width={18} height={18} style={{ color: 'var(--ok)', flex: 'none' }} />
            <div><b style={{ fontSize: 14 }}>Prijavljen kot {app.user!.name || app.user!.email}</b><div className="muted" style={{ fontSize: 12.5, marginTop: 2 }}>Nalagam tvoje podatke …</div></div>
          </div>
        ) : (<>
          <Btn primary block disabled={busy || !app.authKnown} onClick={go}>{busy ? 'Odpiram prijavo …' : !app.authKnown ? 'Pripravljam …' : 'Prijava z Googlom'}</Btn>
          <p className="muted" style={{ fontSize: 12, marginTop: 10, textAlign: 'center' }}>Brez gesla in brez e-poštne potrditve.</p>
        </>)}
      </div>
      {!app.user && (
        <div className="card tight" style={{ marginTop: 12 }}>
          <b style={{ fontSize: 13.5 }}>Brez računa, a imaš varnostno kopijo?</b>
          <div className="muted" style={{ fontSize: 12.5, marginTop: 2 }}>Datoteka iz »Izvozi vse« (Nastavitve → Podatki) — profil, načrt, vadbe in obroki se naložijo iz nje.</div>
          <div style={{ marginTop: 10 }}><BackupImport fresh label="Uvozi kopijo" onDone={() => { if (getState().profile.onboardingDone) { markApp(); navigate('danes') } }} /></div>
        </div>
      )}
      <div className="grow" />
      {!empty && <Btn ghost block onClick={() => navigate('uvod')}>Nimam računa — sestavi mi načrt</Btn>}
      <div className="muted" style={{ fontSize: 11.5, textAlign: 'center', marginTop: 10 }}>
        S prijavo se strinjaš s <a href="/pogoji.html" style={{ textDecoration: 'underline' }}>pogoji</a> in <a href="/zasebnost.html" style={{ textDecoration: 'underline' }}>zasebnostjo</a>.
      </div>
    </main>
  )
}
