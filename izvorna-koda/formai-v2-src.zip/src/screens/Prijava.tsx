import { useEffect, useState } from 'react'
import { navigate } from '@/app/router'
import { markApp } from '@/app/landing'
import { useApp, signIn, toast } from '@/state/store'
import { Btn } from '@/ui/primitives'
import { IcoBack, IcoCheck } from '@/ui/icons'

/**
 * »Že imam račun«: prijava z Googlom, nato počakamo na prvo usklajevanje z oblakom.
 * Račun z načrtom → Danes; račun brez načrta → uvod v treh korakih (prijava ostane).
 */
export function Prijava() {
  const app = useApp()
  const [busy, setBusy] = useState(false)
  const waiting = !!app.user && !app.firstSync

  useEffect(() => {
    if (!app.user || !app.firstSync) return
    if (app.profile.onboardingDone) { markApp(); toast(`Dobrodošel nazaj${app.profile.name ? ', ' + app.profile.name.split(/\s+/)[0] : ''}.`, 'ok'); navigate('danes') }
    else { toast('Na tem računu še ni načrta — sestaviva ga v treh korakih.', 'info', 6000); navigate('uvod') }
  }, [app.user, app.firstSync, app.profile.onboardingDone])

  async function go() {
    setBusy(true)
    try { await signIn() } catch (e) { toast((e as Error).message, 'err') } finally { setBusy(false) }
  }

  return (
    <div className="ob">
      <div className="between" style={{ marginBottom: 14, minHeight: 34 }}>
        <button className="avatar" style={{ background: 'transparent', width: 40, height: 40 }} onClick={() => (history.length > 1 ? history.back() : navigate(''))} aria-label="Nazaj"><IcoBack /></button>
      </div>
      <div className="brand" style={{ fontWeight: 800, fontSize: 15, letterSpacing: '.02em' }}>FORM<span>AI</span></div>
      <h2 style={{ marginTop: 14 }}>Prijava</h2>
      <p style={{ marginTop: 7, fontSize: 14 }}>Z Googlovim računom, ki si ga uporabil prej. Načrt, obroki in vožnje se naložijo sami.</p>
      <div className="card" style={{ marginTop: 20 }}>
        {waiting ? (
          <div className="row" style={{ gap: 12 }}>
            <IcoCheck width={18} height={18} style={{ color: 'var(--ok)', flex: 'none' }} />
            <div><b style={{ fontSize: 14 }}>Prijavljen kot {app.user!.name || app.user!.email}</b><div className="muted" style={{ fontSize: 12.5, marginTop: 2 }}>Nalagam tvoje podatke …</div></div>
          </div>
        ) : (<>
          <Btn primary block disabled={busy || !app.authKnown} onClick={go}>{busy ? 'Odpiram prijavo …' : !app.authKnown ? 'Pripravljam …' : 'Prijava z Googlom'}</Btn>
          <p className="muted" style={{ fontSize: 12, marginTop: 10, textAlign: 'center' }}>Brez gesla in brez e-poštne potrditve.</p>
        </>)}
      </div>
      <div className="grow" />
      <Btn ghost block onClick={() => navigate('uvod')}>Nimam računa — sestavi mi načrt</Btn>
      <div className="muted" style={{ fontSize: 11.5, textAlign: 'center', marginTop: 10 }}>
        S prijavo se strinjaš s <a href="/pogoji.html" style={{ textDecoration: 'underline' }}>pogoji</a> in <a href="/zasebnost.html" style={{ textDecoration: 'underline' }}>zasebnostjo</a>.
      </div>
    </div>
  )
}
