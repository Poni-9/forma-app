import { Sheet, Btn } from '@/ui/primitives'

/**
 * Privolitev za AI obdelavo.
 * Ne kliče store-a — samo pove, kaj gre v model, in sproži onAccept.
 * Zapis privolitve (profile.aiConsentAt) je naloga klicatelja.
 */
export function PrivolitevSheet({ open, onClose, onAccept }: { open: boolean; onClose: () => void; onAccept: () => void }) {
  return (
    <Sheet open={open} onClose={onClose}>
      <h3 style={{ fontSize: 17, margin: '2px 0 10px' }}>Kaj gre v umetno inteligenco</h3>

      <div className="stack" style={{ gap: 10 }}>
        <Row
          title="Kaj pošljemo"
          text="Datum, trajanje, razdaljo, višinske metre, utrip, moč, kadenco in tvoje zapiske. Pri prehrani tudi fotografijo obroka, ki jo daš v oceno."
        />
        <Row
          title="Kaj ne pošljemo"
          text="Tvojega imena, e-naslova in natančne poti. GPS sled ne zapusti naprave nikoli. Aktivnosti Stravinega izvora v analizo ne gredo."
        />
        <Row
          title="Kdo obdeluje in kako prekličeš"
          text="Google Gemini prek našega strežnika v EU, na plačljivem nivoju, kjer se vsebina ne uporablja za učenje modelov. Privolitev prekličeš z enim klikom v Nastavitvah — takoj in brez posledic za ostalo aplikacijo."
        />
      </div>

      <div className="stack" style={{ gap: 8, marginTop: 16 }}>
        <Btn primary block onClick={onAccept}>Dovolim analizo z umetno inteligenco</Btn>
        <Btn ghost block onClick={onClose}>Ne zdaj</Btn>
      </div>

      <div className="muted" style={{ fontSize: 12, marginTop: 12, textAlign: 'center' }}>
        Privolitev prekličeš v Nastavitvah.
      </div>
    </Sheet>
  )
}

function Row({ title, text }: { title: string; text: string }) {
  return (
    <div style={{ borderLeft: '2px solid var(--accent)', paddingLeft: 12 }}>
      <b style={{ fontSize: 13.5 }}>{title}</b>
      <p style={{ fontSize: 12.5, marginTop: 3, lineHeight: 1.5 }}>{text}</p>
    </div>
  )
}
