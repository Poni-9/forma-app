import { Sheet, Btn } from '@/ui/primitives'

/**
 * Privolitev za AI obdelavo.
 * Ne kliče store-a — samo pove, kaj gre v model, in sproži onAccept.
 * Zapis privolitve (profile.aiConsentAt) je naloga klicatelja.
 */
export function PrivolitevSheet({ open, onClose, onAccept }: { open: boolean; onClose: () => void; onAccept: () => void }) {
  return (
    <Sheet open={open} onClose={onClose} label="Kaj gre v umetno inteligenco">
      <h3 style={{ fontSize: 17, margin: '2px 0 10px' }}>Kaj gre v umetno inteligenco</h3>

      <div className="stack" style={{ gap: 10 }}>
        <Row
          title="Kaj pošljemo"
          text="Številke profila (starost, spol, višina, teža, FTP, utrip), povzetek treningov in načrta, jutranje vnose (počutje, mišice, spanec), besedilo tvojih vprašanj in pogovora ter slike in opise obrokov, ki jih pošlješ v oceno."
        />
        <Row
          title="Kaj ne pošljemo"
          text="Imena, e-naslova, natančne poti (GPS sled ne zapusti naprave), voženj Stravinega izvora ter spanca in HRV z ure."
        />
        <Row
          title="Kdo obdeluje in kako prekličeš"
          text="Google Gemini na plačljivem nivoju, kjer se vsebina ne uporablja za učenje modelov. Klici gredo prek našega strežnika v EU (Google Cloud, Belgija); Google ne jamči regije obdelave. Privolitev prekličeš v Nastavitvah — takoj in brez posledic za ostalo aplikacijo."
        />
      </div>

      <div className="stack" style={{ gap: 8, marginTop: 16 }}>
        <Btn primary block onClick={onAccept}>Dovolim analizo z umetno inteligenco</Btn>
        <Btn ghost block onClick={onClose}>Ne zdaj</Btn>
      </div>
    </Sheet>
  )
}

function Row({ title, text }: { title: string; text: string }) {
  return (
    <div style={{ borderLeft: '2px solid var(--accent)', paddingLeft: 12 }}>
      <b style={{ fontSize: 13.5 }}>{title}</b>
      <p style={{ fontSize: 12.5, marginTop: 3, lineHeight: 1.5 }}>{text}</p>
    </div>
  )
}
