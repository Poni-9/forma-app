import { Sheet, Btn } from '@/ui/primitives'

/**
 * Privolitev za AI obdelavo.
 * Ne kliče store-a — samo pove, kaj gre v model, in sproži onAccept.
 * Zapis privolitve (profile.aiConsentAt) je naloga klicatelja.
 */
export function PrivolitevSheet({ open, onClose, onAccept, renew }: { open: boolean; onClose: () => void; onAccept: () => void; /** privolitev je bila dana za starejše besedilo */ renew?: boolean }) {
  return (
    <Sheet open={open} onClose={onClose} label="Kaj gre v umetno inteligenco">
      <h3 style={{ fontSize: 17, margin: '2px 0 10px' }}>Kaj gre v umetno inteligenco</h3>
      {renew && <p style={{ fontSize: 12.5, margin: '-4px 0 10px' }}><b>Novo:</b> tvoj načrt bo sestavil Claude (Anthropic) — zato te vprašam znova.</p>}

      <div className="stack" style={{ gap: 10 }}>
        <Row
          title="Kaj pošljemo"
          text="Številke profila (starost, spol, višina, teža, FTP, utrip), povzetek treningov in načrta, jutranje vnose (počutje, mišice, spanec), besedilo tvojih vprašanj in pogovora, posnetek glasu, ko narekuješ (samo za prepis v besedilo, ne shrani se), slike in opise obrokov, ki jih pošlješ v oceno, ter slike, ki jih priložiš trenerju (npr. postava, ki si jo želiš)."
        />
        <Row
          title="Kaj ne pošljemo"
          text="Imena, e-naslova, natančne poti (GPS sled ne zapusti naprave), voženj Stravinega izvora ter spanca in HRV z ure."
        />
        <Row
          title="Kdo obdeluje in kako prekličeš"
          text="Google Gemini; uporabnikom s povabilom načrt (vprašanja, predlog tedna, vaje in strategijo) sestavi Anthropic Claude — oba prek plačljivega API-ja, kjer se vsebina ne uporablja za učenje modelov; Anthropic jo praviloma izbriše v 30 dneh. Klici gredo prek našega strežnika v EU (Google Cloud, Belgija); ponudnika lahko obdelujeta tudi zunaj EU (npr. v ZDA), kar varujejo standardne pogodbene klavzule EU. Privolitev prekličeš v Nastavitvah — takoj in brez posledic za ostalo aplikacijo."
        />
      </div>

      <div className="stack" style={{ gap: 8, marginTop: 16 }}>
        <Btn primary block onClick={onAccept}>Dovolim analizo z umetno inteligenco</Btn>
        <Btn ghost block onClick={onClose}>Ne zdaj</Btn>
      </div>
    </Sheet>
  )
}

function Row({ title, text }: { title: string; text: string }) {
  return (
    <div style={{ borderLeft: '2px solid var(--accent)', paddingLeft: 12 }}>
      <b style={{ fontSize: 13.5 }}>{title}</b>
      <p style={{ fontSize: 12.5, marginTop: 3, lineHeight: 1.5 }}>{text}</p>
    </div>
  )
}
