import { Sheet, Btn } from '@/ui/primitives'
import { AI_SENT, AI_NEVER, AI_WHO } from '@/domain/ai/consent'
import { rem } from '@/ui/rem'

/**
 * Privolitev za AI obdelavo.
 * Ne kliče store-a — samo pove, kaj gre v model, in sproži onAccept.
 * Zapis privolitve (profile.aiConsentAt) je naloga klicatelja.
 * Seznami so iz domain/ai/consent (isti kot v Nastavitvah), po alinejah (v3.48: prej dva dolga odstavka).
 */
/** (v3.51) zakaj ponovna privolitev: Claude (načrt) ali slika sebe (predlog vaj) */
export type RenewWhy = 'claude' | 'self'
export function PrivolitevSheet({ open, onClose, onAccept, renew }: { open: boolean; onClose: () => void; onAccept: () => void; /** privolitev je bila dana za starejše besedilo (true = Claude) */ renew?: boolean | RenewWhy }) {
  return (
    <Sheet open={open} onClose={onClose} label="Kaj gre v umetno inteligenco">
      <h3 style={{ fontSize: rem(17), margin: '2px 0 10px' }}>Kaj gre v umetno inteligenco</h3>
      {renew && <p style={{ fontSize: rem(12.5), margin: '-4px 0 10px' }}><b>Novo:</b> {renew === 'self' ? 'slike sebe za predlog vaj gredo v AI samo za branje in se ne shranijo — zato te vprašam znova.' : 'tvoj načrt bo sestavil Claude (Anthropic) — zato te vprašam znova.'}</p>}

      <div className="stack" style={{ gap: 10 }}>
        <Row title="Gre v AI" items={AI_SENT} />
        <Row title="Nikoli ne gre v AI" items={AI_NEVER} />
        <Row title="Kdo obdeluje in kako prekličeš" items={AI_WHO} />
      </div>

      <div className="stack" style={{ gap: 8, marginTop: 16 }}>
        <Btn primary block onClick={onAccept}>Dovolim analizo z umetno inteligenco</Btn>
        <Btn ghost block onClick={onClose}>Ne zdaj</Btn>
      </div>
    </Sheet>
  )
}

function Row({ title, items }: { title: string; items: readonly string[] }) {
  return (
    <div style={{ borderLeft: '2px solid var(--accent)', paddingLeft: 12 }}>
      <b style={{ fontSize: rem(13.5) }}>{title}</b>
      <ul style={{ fontSize: rem(12.5), margin: '3px 0 0', paddingLeft: 16, lineHeight: 1.5, color: 'var(--ink-2)' }}>{items.map(t => <li key={t}>{t}</li>)}</ul>
    </div>
  )
}
