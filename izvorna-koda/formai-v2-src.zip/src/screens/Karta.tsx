import { useEffect, useMemo, useRef, useState } from 'react'
import { Head } from '@/app/Shell'
import { navigate } from '@/app/router'
import { useApp, toast } from '@/state/store'
import { geoAllowed } from '@/domain/import/provenance'
import { decodePolyline, trackLengthKm } from '@/domain/import/polyline'
import { cellsOfPolyline, unionCells, coverageAreaKm2 } from '@/domain/coverage/cells'
import { territoriesOf, levelFor, streakDays, monthStats } from '@/domain/coverage/territory'
import { createTerritoryLayer } from '@/ui/TerritoryLayer'
import { shareCard } from '@/ui/shareCard'
import { useCountUp } from '@/ui/motion'
import { Card, Chip, Btn, Empty, Track, fmtKcal } from '@/ui/primitives'
import { IcoMap, IcoShare } from '@/ui/icons'
import 'leaflet/dist/leaflet.css'

/**
 * Karta pokritosti — trajna, osebna, nikoli se ne resetira. Pobarvano ozemlje v slogu INTVL,
 * a brez nasprotnikov: nihče ti ga ne more vzeti. Vse lokalno; nobena koordinata ne zapusti naprave.
 */
export function Karta() {
  const app = useApp()
  const ref = useRef<HTMLDivElement>(null)
  const mapRef = useRef<import('leaflet').Map | null>(null)
  const layerRef = useRef<{ setCells(c: Set<number>): void; remove(): void } | null>(null)
  const [ready, setReady] = useState(false)
  const [linesOn, setLinesOn] = useState(false)
  const tracks = useMemo(() => app.activities.filter(geoAllowed), [app.activities])
  const stats = useMemo(() => {
    const all = unionCells(tracks.map(a => cellsOfPolyline(a.polyline as string)))
    const km = tracks.reduce((s, a) => s + trackLengthKm(decodePolyline(a.polyline as string)), 0)
    const area = coverageAreaKm2(all)
    return { cells: all, km, area, n: tracks.length, terr: territoriesOf(all).size, level: levelFor(area), streak: streakDays(app.activities, app.today), month: monthStats(app.activities, app.today) }
  }, [tracks, app.activities, app.today])
  const shownArea = useCountUp(stats.area >= 1 ? stats.area : stats.area * 100)
  const accent = app.settings.accentHex || '#A3E635'

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      if (!ref.current) return
      const Lf = (await import('leaflet')).default
      if (cancelled || !ref.current) return
      if (!mapRef.current) {
        const m = Lf.map(ref.current, { zoomControl: false, attributionControl: true, preferCanvas: true })
        // CARTO od 2026 zahteva API ključ za vse plasti; OSM ploščice so brez ključa, temno jih naredi CSS filter (.dark-tiles)
        Lf.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap', className: 'dark-tiles' }).addTo(m)
        // vsebnik ob montaži pogosto še nima velikosti (skrit zavihek, animacija) — ob prvi pravi velikosti prilagodi pogled
        const ro = new ResizeObserver(() => { m.invalidateSize(); const b = (m as unknown as { __fit?: import('leaflet').LatLngBounds }).__fit; if (b && b.isValid() && m.getSize().x > 0) { m.fitBounds(b.pad(0.08)); (m as unknown as { __fit?: unknown }).__fit = undefined } })
        ro.observe(ref.current)
        ;(m as unknown as { __ro?: ResizeObserver }).__ro = ro
        Lf.control.zoom({ position: 'bottomright' }).addTo(m)
        mapRef.current = m
      }
      const m = mapRef.current
      if (layerRef.current) { layerRef.current.remove(); layerRef.current = null }
      m.eachLayer(l => { const o = (l as unknown as { options?: { __formai?: boolean } }).options; if (o && o.__formai) m.removeLayer(l) })
      if (!tracks.length) { m.setView([46.15, 14.99], 8); setReady(true); return }
      const layer = createTerritoryLayer(Lf, stats.cells, accent)
      layer.addTo(m)
      layerRef.current = layer as unknown as { setCells(c: Set<number>): void; remove(): void }
      const bounds = Lf.latLngBounds([])
      for (const a of tracks) {
        const pts = decodePolyline(a.polyline as string)
        if (linesOn) Lf.polyline(pts, { color: accent, weight: 1.5, opacity: .45, __formai: true } as unknown as import('leaflet').PolylineOptions).addTo(m)
        for (const p of pts) bounds.extend(p)
      }
      if (bounds.isValid()) {
        if (m.getSize().x > 0) m.fitBounds(bounds.pad(0.08))
        else (m as unknown as { __fit?: import('leaflet').LatLngBounds }).__fit = bounds   // počakaj na pravo velikost
      }
      setReady(true)
    })()
    return () => { cancelled = true }
  }, [tracks, stats.cells, accent, linesOn])

  useEffect(() => () => { if (mapRef.current) { (mapRef.current as unknown as { __ro?: ResizeObserver }).__ro?.disconnect(); mapRef.current.remove(); mapRef.current = null } }, [])

  async function share() {
    try {
      const r = await shareCard({ cells: stats.cells, km: stats.km, areaKm2: stats.area, territories: stats.terr, level: { n: stats.level.n, name: stats.level.name }, streak: stats.streak, name: app.profile.name, accentHex: accent })
      toast(r === 'shared' ? 'Deljeno ✓' : r === 'copied' ? 'Slika kopirana — prilepi jo, kamor hočeš.' : 'Slika prenesena ✓', 'ok')
    } catch { toast('Deljenje ni uspelo.', 'err') }
  }

  const areaLabel = stats.area >= 1 ? `${shownArea.toFixed(1)} km²` : `${Math.round(shownArea)} ha`
  const monthPct = stats.month.goalKm ? Math.min(100, (stats.month.km / stats.month.goalKm) * 100) : 0

  return (<>
    <Head hi={tracks.length ? `nivo ${stats.level.n} · ${stats.level.name}` : 'Karta'} nm="Pokritost" right={
      <button className="avatar" onClick={share} aria-label="Deli" disabled={!tracks.length}><IcoShare width={18} height={18} /></button>
    } />
    <div className="scroll" style={{ padding: 0, display: 'flex', flexDirection: 'column' }}>
      <div style={{ position: 'relative', flex: 1, minHeight: 340 }}>
        <div ref={ref} style={{ position: 'absolute', inset: 0, background: '#0b0e12' }} />
        {tracks.length > 0 && (
          <div style={{ position: 'absolute', left: 12, top: 12, zIndex: 400 }} className="row">
            <Chip sm on={!linesOn} onClick={() => setLinesOn(false)}>Ozemlje</Chip>
            <Chip sm on={linesOn} onClick={() => setLinesOn(true)}>+ poti</Chip>
          </div>
        )}
        {!ready && <div className="muted" style={{ position: 'absolute', left: 14, bottom: 12, fontSize: 12 }}>Nalagam karto …</div>}
      </div>
      <div style={{ padding: '12px 18px 16px' }} className="stagger">
        {!tracks.length ? (
          <Empty icon={<IcoMap width={30} height={30} style={{ color: 'var(--accent)' }} />} title="Karta je še prazna" text="Vsaka sled iz datoteke, arhiva ali intervals.icu (Garmin neposredno) jo pobarva. Pobarvano ostane za vedno.">
            <Btn primary sm onClick={() => navigate('uvoz')}>Uvozi vožnje</Btn>
          </Empty>
        ) : (<>
          <Card tight>
            <div className="between">
              <div><h4>Pobarvano</h4><b className="num" style={{ fontSize: 26, letterSpacing: '-.03em' }}>{areaLabel}</b><div className="muted" style={{ fontSize: 12 }}>{fmtKcal(stats.terr)} ozemelj · {fmtKcal(stats.cells.size)} celic</div></div>
              <div className="stack" style={{ gap: 6, alignItems: 'flex-end' }}><Chip sm on>{Math.round(stats.km)} km</Chip><Chip sm>{stats.n} sledi</Chip></div>
            </div>
            <div style={{ marginTop: 12 }}>
              <div className="between" style={{ fontSize: 12, fontWeight: 700, color: 'var(--ink-2)' }}><span>Nivo {stats.level.n} · {stats.level.name}</span><span className="muted">{stats.level.nextKm2 != null ? `do nivoja ${stats.level.n + 1}: ${stats.level.nextKm2} km²` : 'najvišji nivo'}</span></div>
              <div style={{ marginTop: 6 }}><Track pct={stats.level.pct} color="var(--accent)" /></div>
            </div>
          </Card>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 10 }}>
            <Card tight>
              <h4>Niz</h4>
              <b className="num" style={{ fontSize: 24 }}>{stats.streak}</b>
              <div className="muted" style={{ fontSize: 12 }}>{stats.streak === 1 ? 'dan zapored' : stats.streak >= 2 && stats.streak <= 4 ? 'dnevi zapored' : 'dni zapored'}</div>
              <div className="muted" style={{ fontSize: 11, marginTop: 4 }}>en prost dan ga ne prekine</div>
            </Card>
            <Card tight>
              <h4>{new Date(app.today).toLocaleDateString('sl-SI', { month: 'long' })}</h4>
              <b className="num" style={{ fontSize: 24 }}>{Math.round(stats.month.km)}<span className="muted" style={{ fontSize: 13, fontWeight: 600 }}> / {stats.month.goalKm} km</span></b>
              <div style={{ marginTop: 6 }}><Track pct={monthPct} color="var(--t-kolo)" /></div>
              <div className="muted" style={{ fontSize: 11, marginTop: 4 }}>{stats.month.prevKm ? `prejšnji mesec ${Math.round(stats.month.prevKm)} km` : 'cilj: začni s 50 km'}</div>
            </Card>
          </div>
          <Btn ghost block sm style={{ marginTop: 10 }} onClick={share}><IcoShare width={16} height={16} /> Deli sliko karte</Btn>
          <div className="muted" style={{ fontSize: 11.5, marginTop: 10, textAlign: 'center' }}>Pobarvano ostane za vedno. Nihče ti ga ne more vzeti. Sledi nikoli ne zapustijo naprave.</div>
        </>)}
      </div>
    </div>
  </>)
}
