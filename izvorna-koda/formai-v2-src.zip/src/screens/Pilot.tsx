import { useEffect, useMemo, useState } from 'react'
import { Head } from '@/app/Shell'
import { useApp, signIn, toast } from '@/state/store'
import { fetchPilotSummary, type PilotRow } from '@/data/pilot'
import { QUESTIONS, LETTERS, questionOf, pmfOf, cleanCode } from '@/domain/pilot'
import { APP_URL } from '@/config'
import { Btn, Card, Track } from '@/ui/primitives'

/**
 * Pregled testnega programa (za razvijalca): koliko ljudi, ali je aplikacija nepogrešljiva (PMF), ali je načrt prav težak,
 * odgovori A–D po vprašanjih (z razlogom, kaj izboljšajo), kode povabil, izvoz CSV in QR povezava. Podatke vrne strežnik samo skrbniku.
 */
export function Pilot() {
  const app = useApp()
  const [rows, setRows] = useState<PilotRow[] | null>(null)
  const [err, setErr] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const load = async () => { setBusy(true); const r = await fetchPilotSummary(); setBusy(false); if ('error' in r) setErr(r.error); else { setErr(null); setRows(r.rows) } }
  useEffect(() => { if (app.user) void load() }, [app.user])

  const agg = useMemo(() => {
    if (!rows) return null
    // zadnji odgovor vsakega uporabnika na vsako vprašanje (ponovljeno vprašanje šteje najnovejši odgovor)
    const last = new Map<string, PilotRow>()
    for (const r of [...rows].sort((a, b) => (a.at ?? 0) - (b.at ?? 0))) last.set(`${r.anon}|${r.q}`, r)
    const by = (q: string) => [...last.values()].filter(r => r.q === q).map(r => r.a)
    const users = new Set(rows.map(r => r.anon))
    const codes = new Map<string, Set<string>>()
    for (const r of rows) { const c = r.code || '(brez kode)'; if (!codes.has(c)) codes.set(c, new Set()); codes.get(c)!.add(r.anon) }
    const pay = by('pay'), fit = by('plan_fit')
    return {
      users: users.size, codes, by,
      pmf: pmfOf(by('pmf')),
      payYes: pay.filter(a => a !== 'a').length, payN: pay.length,
      fitOk: fit.length ? Math.round((fit.filter(a => a === 'a').length / fit.length) * 100) : null,
    }
  }, [rows])

  const csv = () => {
    if (!rows) return
    const esc = (x: unknown) => `"${String(x ?? '').replace(/"/g, '""')}"`
    const lines = ['cas;oznaka;koda;vprasanje;odgovor;besedilo;dan;razlicica', ...rows.map(r => { const q = questionOf(r.q), i = LETTERS.indexOf(r.a as 'a'); return [r.at ? new Date(r.at).toISOString() : '', r.anon, r.code || '', r.q, r.a, q && i >= 0 ? q.options[i] : '', r.day ?? '', r.v].map(esc).join(';') })]
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['\ufeff' + lines.join('\n')], { type: 'text/csv;charset=utf-8' })); a.download = `formai-testni-program-${app.today}.csv`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000)
  }

  return (<>
    <Head hi="Testni program" nm="Pregled" />
    <div className="scroll">
      {!app.user ? (
        <Card><p style={{ fontSize: 13.5 }}>Pregled je samo za skrbnika — prijavi se z Googlom.</p><Btn primary sm style={{ marginTop: 10 }} onClick={() => void signIn()}>Prijava z Googlom</Btn></Card>
      ) : err ? (
        <Card><p style={{ fontSize: 13.5 }}>{err}</p><Btn sm style={{ marginTop: 10 }} disabled={busy} onClick={load}>Poskusi znova</Btn></Card>
      ) : !agg ? (
        <Card><p className="muted">{busy ? 'Nalagam …' : 'Ni podatkov.'}</p></Card>
      ) : (<>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10 }}>
          <Card tight><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>LJUDJE</div><b style={{ fontSize: 24 }}>{agg.users}</b><div className="muted" style={{ fontSize: 11 }}>ki so odgovorili</div></Card>
          <Card tight><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>NEPOGREŠLJIVA</div><b style={{ fontSize: 24, color: agg.pmf && agg.pmf.pct >= 40 ? 'var(--ok)' : undefined }}>{agg.pmf ? `${agg.pmf.pct}\u00a0%` : '—'}</b><div className="muted" style={{ fontSize: 11 }}>»zelo razočaran« · cilj ≥ 40 %{agg.pmf ? ` · ${agg.pmf.n}` : ''}</div></Card>
          <Card tight><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>NAČRT RAVNO PRAV</div><b style={{ fontSize: 24 }}>{agg.fitOk != null ? `${agg.fitOk}\u00a0%` : '—'}</b><div className="muted" style={{ fontSize: 11 }}>zadnji teden</div></Card>
          <Card tight><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>BI PLAČAL</div><b style={{ fontSize: 24 }}>{agg.payYes}</b><div className="muted" style={{ fontSize: 11 }}>od {agg.payN} · cilj ≥ 20</div></Card>
        </div>
        {QUESTIONS.map(q => {
          const ans = agg.by(q.q)
          if (!ans.length) return null
          const n = ans.length
          return (
            <Card key={q.q} style={{ marginTop: 12 }}>
              <div className="between" style={{ alignItems: 'flex-start' }}><b style={{ fontSize: 14 }}>{q.text}</b><span className="muted" style={{ fontSize: 12, flex: 'none' }}>{n}</span></div>
              <div className="muted" style={{ fontSize: 11.5, marginTop: 2 }}>Izboljša: {q.why}</div>
              <div className="stack" style={{ gap: 6, marginTop: 8 }}>{q.options.map((o, i) => { const k = ans.filter(a => a === LETTERS[i]).length; return (
                <div key={i}><div className="between" style={{ fontSize: 12.5 }}><span>{LETTERS[i]!.toUpperCase()} · {o}</span><b>{Math.round((k / n) * 100)}{'\u00a0'}% <span className="muted" style={{ fontWeight: 600 }}>({k})</span></b></div><Track pct={(k / n) * 100} color="var(--t-kolo)" /></div>) })}</div>
            </Card>)
        })}
        <Card style={{ marginTop: 12 }}>
          <h4>Kode povabil</h4>
          <div className="stack" style={{ gap: 4, marginTop: 8 }}>{[...agg.codes.entries()].sort((a, b) => b[1].size - a[1].size).map(([c, u]) => <div key={c} className="between" style={{ fontSize: 13 }}><span>{c}</span><b>{u.size}</b></div>)}</div>
        </Card>
        <div className="row" style={{ gap: 8, marginTop: 12 }}>
          <Btn ghost sm disabled={busy} onClick={load}>{busy ? 'Nalagam …' : 'Osveži'}</Btn>
          <Btn ghost sm disabled={!rows?.length} onClick={csv}>Izvozi CSV</Btn>
        </div>
      </>)}
      <QrCard />
    </div>
  </>)
}

/** Povezava s kodo povabila in QR (za klub, trgovino, znance): formai.si/?pilot=KODA. */
function QrCard() {
  const [code, setCode] = useState('')
  const [svg, setSvg] = useState<string | null>(null)
  const c = cleanCode(code)
  const url = c ? `${APP_URL}/?pilot=${c}` : null
  useEffect(() => {
    if (!url) { setSvg(null); return }
    let dead = false
    void import('qrcode-generator').then(m => {
      const qr = (m.default || m)(0, 'M'); qr.addData(url); qr.make()
      if (!dead) setSvg(qr.createSvgTag({ cellSize: 6, margin: 3, scalable: true }))
    })
    return () => { dead = true }
  }, [url])
  const download = () => { if (!svg || !c) return; const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml' })); a.download = `formai-povabilo-${c}.svg`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000) }
  return (
    <Card style={{ marginTop: 12 }}>
      <h4>Povabilo s kodo (QR)</h4>
      <p style={{ fontSize: 12.5, marginTop: 4 }}>Koda pove, od kod so prišli (klub, trgovina, znanec). Vidiš jo v pregledu zgoraj.</p>
      <div className="field" style={{ marginTop: 10 }}><label>Koda</label><input value={code} onChange={e => setCode(e.target.value)} placeholder="npr. KK-ROG" autoCapitalize="characters" /></div>
      {url && (<>
        <div style={{ background: '#fff', borderRadius: 16, padding: 12, marginTop: 12, maxWidth: 220 }} dangerouslySetInnerHTML={{ __html: svg || '' }} />
        <div className="muted" style={{ fontSize: 12, marginTop: 8, wordBreak: 'break-all' }}>{url}</div>
        <div className="row" style={{ gap: 8, marginTop: 10 }}>
          <Btn sm onClick={() => { void navigator.clipboard?.writeText(url).then(() => toast('Povezava kopirana.', 'ok')) }}>Kopiraj povezavo</Btn>
          <Btn ghost sm disabled={!svg} onClick={download}>Prenesi QR</Btn>
        </div>
      </>)}
    </Card>
  )
}
