import { useEffect, useMemo, useState } from 'react'
import { Head } from '@/app/Shell'
import { useApp, signIn, toast } from '@/state/store'
import { fetchPilotSummary, type PilotRow } from '@/data/pilot'
import { PILOT_PREFIX } from '@/data/feedback'
import { QUESTIONS, LETTERS, questionOf, pmfOf, cleanCode } from '@/domain/pilot'
import { APP_URL } from '@/config'
import { Btn, Card, Track } from '@/ui/primitives'
import { csvCell } from '@/ui/format'

/**
 * Pregled testnega programa (za razvijalca): koliko ljudi, ali je aplikacija nepogrešljiva (PMF), ali je načrt prav težak,
 * odgovori A–D po vprašanjih (z razlogom, kaj izboljšajo), kode povabil, izvoz CSV in QR povezava. Podatke vrne strežnik samo skrbniku.
 */
export function Pilot() {
  const app = useApp()
  const [rows, setRows] = useState<PilotRow[] | null>(null)
  const [err, setErr] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const load = async () => { setBusy(true); const r = await fetchPilotSummary(); setBusy(false); if ('error' in r) setErr(r.error); else { setErr(null); setRows(r.rows.filter(x => !x.q.startsWith(PILOT_PREFIX))) } }   // pripombe gredo v Pripombe, ne v statistiko
  useEffect(() => { if (app.user) void load() }, [app.user])

  const agg = useMemo(() => {
    if (!rows) return null
    // zadnji odgovor vsakega uporabnika na vsako vprašanje (ponovljeno vprašanje šteje najnovejši odgovor)
    const last = new Map<string, PilotRow>()
    for (const r of [...rows].sort((a, b) => (a.at ?? 0) - (b.at ?? 0))) last.set(`${r.anon}|${r.q}`, r)
    const by = (q: string) => [...last.values()].filter(r => r.q === q).map(r => r.a)
    const users = new Set(rows.map(r => r.anon))
    const codes = new Map<string, Set<string>>()
    for (const r of rows) { const c = r.code || '(brez kode)'; if (!codes.has(c)) codes.set(c, new Set()); codes.get(c)!.add(r.anon) }
    const pay = by('pay'), fit = by('plan_fit')
    return {
      users: users.size, codes, by,
      pmf: pmfOf(by('pmf')),
      payYes: pay.filter(a => a !== 'a').length, payN: pay.length,
      fitOk: fit.length ? Math.round((fit.filter(a => a === 'a').length / fit.length) * 100) : null,
    }
  }, [rows])

  const csv = () => {
    if (!rows) return
    // vsaka celica skozi csvCell: koda povabila je vnos uporabnika (=HYPERLINK(…) ne sme postati formula)
    const lines = ['cas;oznaka;koda;vprasanje;odgovor;besedilo;dan;razlicica', ...rows.map(r => { const q = questionOf(r.q), i = LETTERS.indexOf(r.a as 'a'); return [r.at ? new Date(r.at).toISOString() : '', r.anon, r.code || '', r.q, r.a, q && i >= 0 ? q.options[i] : '', r.day ?? '', r.v].map(csvCell).join(';') })]
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['\ufeff' + lines.join('\n')], { type: 'text/csv;charset=utf-8' })); a.download = `formai-testni-program-${app.today}.csv`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000)
  }

  return (<>
    <Head hi="Testni program" nm="Pregled" />
    <div className="scroll">
      {!app.user ? (
        <Card><p style={{ fontSize: 13.5 }}>Pregled je samo za skrbnika — prijavi se z Googlom.</p><Btn primary sm style={{ marginTop: 10 }} onClick={() => void signIn()}>Prijava z Googlom</Btn></Card>
      ) : err ? (
        <Card><p style={{ fontSize: 13.5 }}>{err}</p><Btn sm style={{ marginTop: 10 }} disabled={busy} onClick={load}>Poskusi znova</Btn></Card>
      ) : !agg ? (
        <Card><p className="muted">{busy ? 'Nalagam …' : 'Ni podatkov.'}</p></Card>
      ) : (<>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10 }}>
          <Card tight><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>LJUDJE</div><b style={{ fontSize: 24 }}>{agg.users}</b><div className="muted" style={{ fontSize: 11 }}>ki so odgovorili</div></Card>
          <Card tight><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>NEPOGREŠLJIVA</div><b style={{ fontSize: 24, color: agg.pmf && agg.pmf.pct >= 40 ? 'var(--ok)' : undefined }}>{agg.pmf ? `${agg.pmf.pct}\u00a0%` : '—'}</b><div className="muted" style={{ fontSize: 11 }}>»zelo razočaran« · cilj ≥ 40{'\u00a0'}%{agg.pmf ? ` · ${agg.pmf.n}` : ''}</div></Card>
          <Card tight><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>NAČRT RAVNO PRAV</div><b style={{ fontSize: 24 }}>{agg.fitOk != null ? `${agg.fitOk}\u00a0%` : '—'}</b><div className="muted" style={{ fontSize: 11 }}>zadnji teden</div></Card>
          <Card tight><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>BI PLAČAL</div><b style={{ fontSize: 24 }}>{agg.payYes}</b><div className="muted" style={{ fontSize: 11 }}>od {agg.payN} · cilj ≥ 20</div></Card>
        </div>
        {QUESTIONS.map(q => {
          const ans = agg.by(q.q)
          if (!ans.length) return null
          const n = ans.length
          return (
            <Card key={q.q} style={{ marginTop: 12 }}>
              <div className="between" style={{ alignItems: 'flex-start' }}><b style={{ fontSize: 14 }}>{q.text}</b><span className="muted" style={{ fontSize: 12, flex: 'none' }}>{n}</span></div>
              <div className="muted" style={{ fontSize: 11.5, marginTop: 2 }}>Izboljša: {q.why}</div>
              <div className="stack" style={{ gap: 6, marginTop: 8 }}>{q.options.map((o, i) => { const k = ans.filter(a => a === LETTERS[i]).length; return (
                <div key={i}><div className="between" style={{ fontSize: 12.5 }}><span>{LETTERS[i]!.toUpperCase()} · {o}</span><b>{Math.round((k / n) * 100)}{'\u00a0'}% <span className="muted" style={{ fontWeight: 600 }}>({k})</span></b></div><Track pct={(k / n) * 100} color="var(--t-kolo)" /></div>) })}</div>
            </Card>)
        })}
        <Card style={{ marginTop: 12 }}>
          <h2 className="h4">Kode povabil</h2>
          <div className="stack" style={{ gap: 4, marginTop: 8 }}>{[...agg.codes.entries()].sort((a, b) => b[1].size - a[1].size).map(([c, u]) => <div key={c} className="between" style={{ fontSize: 13 }}><span>{c}</span><b>{u.size}</b></div>)}</div>
        </Card>
        <div className="row" style={{ gap: 8, marginTop: 12 }}>
          <Btn ghost sm disabled={busy} onClick={load}>{busy ? 'Nalagam …' : 'Osveži'}</Btn>
          <Btn ghost sm disabled={!rows?.length} onClick={csv}>Izvozi CSV</Btn>
        </div>
      </>)}
      <QrCard />
    </div>
  </>)
}

/** QR kot PNG (za WhatsApp, Messenger, tisk): moduli narisani neposredno, bel rob, spodaj napis. */
type Qr = { getModuleCount(): number; isDark(r: number, c: number): boolean; createSvgTag(o: { cellSize: number; margin: number; scalable: boolean }): string }
async function makeQr(url: string): Promise<Qr> {
  const m = await import('qrcode-generator')
  const qr = ((m as unknown as { default?: unknown }).default || m) as unknown as (t: number, e: string) => Qr & { addData(d: string): void; make(): void }
  const q = qr(0, 'M'); q.addData(url); q.make(); return q
}
function qrPng(qr: Qr, label: string): Promise<Blob | null> {
  const n = qr.getModuleCount(), cell = 20, pad = cell * 4, S = n * cell + pad * 2, H = S + 64
  const cv = document.createElement('canvas'); cv.width = S; cv.height = H
  const g = cv.getContext('2d'); if (!g) return Promise.resolve(null)
  g.fillStyle = '#fff'; g.fillRect(0, 0, S, H); g.fillStyle = '#000'
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (qr.isDark(r, c)) g.fillRect(pad + c * cell, pad + r * cell, cell, cell)
  g.fillStyle = '#0B0E12'; g.font = '800 40px Manrope, system-ui, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(label, S / 2, S + 22)
  return new Promise(res => cv.toBlob(b => res(b), 'image/png'))
}

/** Povezava s kodo povabila in QR (za klub, trgovino, znance): formai.si/?pilot=KODA. */
function QrCard() {
  const [code, setCode] = useState('')
  const [qr, setQr] = useState<Qr | null>(null)
  const c = cleanCode(code)
  const url = c ? `${APP_URL}/?pilot=${c}` : null
  useEffect(() => {
    if (!url) { setQr(null); return }
    let dead = false
    void makeQr(url).then(q => { if (!dead) setQr(q) })
    return () => { dead = true }
  }, [url])
  const svg = qr ? qr.createSvgTag({ cellSize: 6, margin: 3, scalable: true }) : null
  const label = c ? `formai.si · ${c}` : ''
  const save = (b: Blob, name: string) => { const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000) }
  const downloadPng = async () => { if (!qr || !c) return; const b = await qrPng(qr, label); if (b) save(b, `formai-povabilo-${c}.png`) }
  const downloadSvg = () => { if (!svg || !c) return; save(new Blob([svg], { type: 'image/svg+xml' }), `formai-povabilo-${c}.svg`) }
  const canShare = typeof navigator !== 'undefined' && typeof navigator.share === 'function'
  const share = async () => {
    if (!url) return
    // besedilo iz potrjene pristajalne strani; v aplikaciji za sporočila ga lahko pred pošiljanjem spremeniš
    try { await navigator.share({ title: 'FORMAI', text: 'FORMAI — kolo in prehrana, en načrt. Zgodnji dostop je brezplačen.', url }) } catch { /* preklic */ }
  }
  return (
    <Card style={{ marginTop: 12 }}>
      <h2 className="h4">Povabilo s kodo (QR)</h2>
      <p style={{ fontSize: 12.5, marginTop: 4 }}>Koda pove, od kod so prišli (klub, trgovina, znanec). Vidiš jo v pregledu zgoraj.</p>
      <div className="field" style={{ marginTop: 10 }}><label>Koda</label><input value={code} onChange={e => setCode(e.target.value)} placeholder="npr. KK-ROG" autoCapitalize="characters" /></div>
      {url && (<>
        <div style={{ background: '#fff', borderRadius: 16, padding: 12, marginTop: 12, maxWidth: 220 }} dangerouslySetInnerHTML={{ __html: svg || '' }} />
        <div className="muted" style={{ fontSize: 12, marginTop: 8, wordBreak: 'break-all' }}>{url}</div>
        <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
          {canShare && <Btn primary sm onClick={() => void share()}>Deli povezavo</Btn>}
          <Btn sm onClick={() => { void navigator.clipboard?.writeText(url).then(() => toast('Povezava kopirana.', 'ok')) }}>Kopiraj povezavo</Btn>
          <Btn ghost sm disabled={!qr} onClick={() => void downloadPng()}>QR (PNG)</Btn>
          <Btn ghost sm disabled={!svg} onClick={downloadSvg}>QR za tisk (SVG)</Btn>
        </div>
      </>)}
    </Card>
  )
}
