import { Fragment, useEffect, useLayoutEffect, useRef, useState } from 'react'
import { Head } from '@/app/Shell'
import { navigate } from '@/app/router'
import { useApp, getState, savePlanDays, updateSettings, toast } from '@/state/store'
import { useAi } from '@/ui/useAi'
import { snapOf } from '@/state/snap'
import { aiAllowed } from '@/domain/import/provenance'
import { weekStartIso, addDays, todayIso } from '@/domain/training/load'
import { dayLabel, adaptText } from '@/domain/ai/coachchat'
import { dailyAdvice, chat, addToChat, loadLegacyChat, clearLegacyChat, weeklyReview, adaptWeek, type ChatMsg, type ChatMemory } from '@/domain/ai/actions'
import { Card, Chip, Btn } from '@/ui/primitives'
import { IcoChat } from '@/ui/icons'
import { FREE_AI_PER_DAY } from '@/config'
import { sanitizeGaps, hasHiddenActivities } from '@/domain/ai/sanitize'

const quick = (ev?: string) => ['Kaj danes in s kakšnimi vati?', 'Sem na poti do cilja v W/kg?', 'Koliko OH na dolgi vožnji?', 'Kako izpeljem VO2max intervale?', 'Zakaj teža stoji?', `Kaj me bo na dirki${ev ? ` (${ev})` : ''} najbolj omejilo?`]
const KIND_LABEL: Record<NonNullable<ChatMsg['kind']>, string> = { advice: 'Nasvet za danes', review: 'Pregled tedna', adapt: 'Teden prilagojen' }
type Mode = 'advice' | 'chat' | 'review' | 'adapt'

const memNow = (): ChatMemory => { const c = getState().settings.coach; return { msgs: c?.msgs || [], summary: c?.summary ?? null } }

/**
 * Trener = en pogovor kot v aplikaciji za sporočila: vse (vprašanja, nasvet za danes, pregled tedna, prilagoditev)
 * je v eni časovnici, najnovejše spodaj, tik nad vrstico za pisanje. Po odgovoru je tvoje vprašanje na vrhu zaslona,
 * odgovor pa se bere od začetka.
 */
export function Trener() {
  const app = useApp()
  const ai = useAi()
  const saved = app.settings.coach?.msgs || []
  const summary = app.settings.coach?.summary ?? null
  const [pending, setPending] = useState<ChatMsg | null>(null)
  const msgs: ChatMsg[] = pending ? [...saved, pending] : saved
  const [q, setQ] = useState('')
  const [thinking, setThinking] = useState<Mode | null>(null)
  const [confirmNew, setConfirmNew] = useState(false)
  const listRef = useRef<HTMLDivElement>(null)
  // kam se pomakne po naslednjem izrisu: 'pair' = zadnje vprašanje na vrh (ob odprtju in po odgovoru), 'bottom' = na dno (med čakanjem)
  const scrollTo = useRef<'pair' | 'bottom' | null>('pair')
  const first = useRef(true)

  const seen = app.activities.filter(aiAllowed).length
  const hidden = hasHiddenActivities(app.activities)
  const busy = ai.busy || !!thinking

  // enkratna selitev starega lokalnega pogovora v sinhronizirane nastavitve
  useEffect(() => { if (app.settings.coach === undefined) void loadLegacyChat().then(async old => { await updateSettings({ coach: { msgs: old.slice(-40), summary: null } }); await clearLegacyChat() }) }, [app.settings.coach])
  useEffect(() => { if (!confirmNew) return; const t = setTimeout(() => setConfirmNew(false), 4000); return () => clearTimeout(t) }, [confirmNew])

  useLayoutEffect(() => {
    const el = listRef.current, how = scrollTo.current
    if (!el || !how) return
    const lastIsAi = msgs[msgs.length - 1]?.role === 'ai'
    if (how === 'pair' && !lastIsAi && !first.current) return          // počakaj, da je odgovor izrisan
    const atMount = first.current
    first.current = false; scrollTo.current = null
    const go = () => {
      if (!el.isConnected) return
      // aplikacija se pomika kot dokument (okno); zgoraj je na namizju lepljiva vrstica z zavihki
      const bar = document.querySelector<HTMLElement>('.dbar')
      const off = (bar && getComputedStyle(bar).position !== 'static' ? bar.getBoundingClientRect().height : 0) + 10
      if (how === 'bottom') { window.scrollTo({ top: document.documentElement.scrollHeight, behavior: 'smooth' }); return }
      const users = el.querySelectorAll<HTMLElement>('.msg.user')
      const target = users[users.length - 1]
      // zadnje vprašanje na vrh vidnega dela (odgovor se bere od začetka); kratek pogovor se ustavi na dnu
      window.scrollTo({ top: target ? Math.max(0, target.getBoundingClientRect().top + window.scrollY - off) : document.documentElement.scrollHeight })
    }
    // ob odprtju zaslona počakaj, da se postavitev umiri (vstopna animacija)
    if (atMount) setTimeout(go, 90)
    else requestAnimationFrame(go)
  }, [msgs.length, thinking])

  /** Eno vprašanje v pogovor: vse (tudi shranjevanje) je v enem opravilu, da deluje tudi po privolitvi. */
  async function converse(label: string, mode: Mode, produce: () => Promise<ChatMemory>): Promise<boolean> {
    if (busy) return false
    const at = new Date().toISOString()
    const ok = await ai.run(async () => {
      scrollTo.current = 'bottom'
      setPending({ role: 'user', text: label, at }); setThinking(mode)
      try {
        const next = await produce()
        scrollTo.current = 'pair'
        await updateSettings({ coach: next })
        return true
      } finally { setPending(null); setThinking(null) }
    })
    if (!ok && scrollTo.current === 'bottom') scrollTo.current = null
    return !!ok
  }
  const reply = (label: string, at: string, text: string, kind?: ChatMsg['kind']): Promise<ChatMemory> =>
    addToChat(memNow(), [{ role: 'user', text: label, at }, { role: 'ai', text, at: new Date().toISOString(), ...(kind ? { kind } : {}) }])
  const hasToday = (k: ChatMsg['kind'], from: string) => saved.some(m => m.kind === k && todayIso(new Date(m.at)) >= from)

  async function send(text?: string) {
    const question = (text ?? q).trim()
    if (!question || busy) return
    setQ('')
    const ok = await converse(question, 'chat', () => chat(snapOf(getState()), question, memNow()))
    if (!ok && text === undefined) setQ(question)   // vprašanje se ne izgubi
  }
  function advice() {
    const label = 'Kaj naj danes naredim?', at = new Date().toISOString(), force = hasToday('advice', app.today)
    void converse(label, 'advice', async () => reply(label, at, await dailyAdvice(snapOf(getState()), force), 'advice'))
  }
  function review() {
    const label = 'Pregled tedna', at = new Date().toISOString(), force = hasToday('review', weekStartIso(app.today))
    void converse(label, 'review', async () => reply(label, at, await weeklyReview(snapOf(getState()), force), 'review'))
  }
  function adapt() {
    const ws = weekStartIso(app.today)
    const week = app.plan.filter(d => d.date >= ws && d.date <= addDays(ws, 6))
    if (!week.length) { toast('Ta teden še ni sestavljen — najprej ga sestavi v Planu.', 'info'); navigate('plan'); return }
    const label = 'Prilagodi ta teden', at = new Date().toISOString()
    void converse(label, 'adapt', async () => {
      const r = await adaptWeek(snapOf(getState()), week)
      await savePlanDays(r.days)
      return reply(label, at, adaptText(r.summary, week, r.days), 'adapt')
    })
  }
  function newChat() {
    if (!confirmNew) { setConfirmNew(true); return }
    setConfirmNew(false)
    void updateSettings({ coach: { msgs: [], summary: null } })
  }

  return (<>
    <Head hi={`trener vidi ${seen} od ${app.activities.length} aktivnosti`} nm="Trener" />
    <div className="scroll chat-page">
      {!ai.signedIn && (
        <Card accent className="stagger" style={{ marginBottom: 12 }}>
          <div className="row" style={{ gap: 12 }}>
            <div style={{ width: 40, height: 40, borderRadius: 'var(--r-s)', background: 'var(--accent)', display: 'grid', placeItems: 'center', color: 'var(--accent-ink)', flex: 'none' }}><IcoChat /></div>
            <div><b style={{ fontSize: 15 }}>AI trener teče prek tvojega računa</b><div className="muted" style={{ fontSize: 12.5, fontWeight: 600 }}>Prijava z Googlom · {FREE_AI_PER_DAY} AI klicev na dan</div></div>
          </div>
          <Btn primary block sm style={{ marginTop: 12 }} onClick={advice}>Prijava z Googlom in prvi nasvet</Btn>
        </Card>
      )}
      {app.activities.length > 0 && seen < app.activities.length && (
        <div className="muted" style={{ fontSize: 12, padding: '0 4px 10px' }}>{app.activities.length - seen} aktivnosti trener ne sme uporabiti (Stravin ali neznan izvor). Datoteke, Garmin prek intervals.icu, posnetki in ročni vnosi štejejo.</div>
      )}
      {!ai.consent && ai.signedIn && <div className="muted" style={{ fontSize: 12, padding: '0 4px 10px' }}>Pred prvim nasvetom te vprašam za privolitev — kaj gre v AI in kaj ne.</div>}

      <div className="chat" ref={listRef}>
        {(saved.length > 0 || summary) && (
          <div className="between" style={{ gap: 10 }}>
            <span className="muted" style={{ fontSize: 12 }}>{summary ? 'Trener si zapomni tudi starejše pogovore.' : 'Pogovor se shrani — nadaljuješ, kjer si končal.'}</span>
            <button className="chip sm click" onClick={newChat} disabled={busy}>{confirmNew ? 'res pobrišem?' : 'nov pogovor'}</button>
          </div>
        )}
        {msgs.length === 0 && (
          <div className="chat-empty">
            <b style={{ fontSize: 15 }}>Vprašaj trenerja</b>
            <p style={{ fontSize: 13, marginTop: 4 }}>Odgovori so vedno tukaj, najnovejši spodaj — tik nad vrstico za pisanje. Tudi »Kaj naj danes naredim?«, »Pregled tedna« in »Prilagodi ta teden« odgovorijo tukaj.</p>
            <div className="row" style={{ gap: 6, flexWrap: 'wrap', marginTop: 10 }}>{quick(app.profile.event?.name).map(t => <Chip key={t} sm onClick={() => void send(t)}>{t}</Chip>)}</div>
          </div>
        )}
        {msgs.map((m, i) => {
          const day = dayLabel(m.at, app.today)
          const prev = i > 0 ? dayLabel(msgs[i - 1]!.at, app.today) : null
          return (
            <Fragment key={`${m.at}-${i}`}>
              {day !== prev && <div className="day">{day}</div>}
              <div className={`msg ${m.role}`}>
                {m.role === 'ai' && m.kind && <b className="kind">{KIND_LABEL[m.kind]}</b>}
                {m.role === 'ai' ? sanitizeGaps(m.text, hidden) : m.text}
              </div>
            </Fragment>)
        })}
        {thinking && <div className="msg ai typing"><span className="thinking"><i /><i /><i /></span>{thinking === 'adapt' ? <span className="muted" style={{ marginLeft: 8, fontSize: 12.5 }}>prilagajam teden …</span> : null}</div>}
      </div>

      {/* vrstica za pisanje: vedno na vidiku, tik pod zadnjim odgovorom; bližnjice odgovorijo v isti pogovor */}
      <div className="composer">
        <div className="quick">
          <Chip sm onClick={advice}>Kaj naj danes naredim?</Chip>
          <Chip sm onClick={review}>Pregled tedna</Chip>
          <Chip sm onClick={adapt}>Prilagodi ta teden</Chip>
        </div>
        <form className="row" style={{ gap: 8 }} onSubmit={e => { e.preventDefault(); void send() }}>
          <input className="field" value={q} onChange={e => setQ(e.target.value)} placeholder="Vprašaj trenerja …" enterKeyHint="send" style={{ flex: 1, background: 'var(--card)', border: '1px solid var(--line)', borderRadius: 'var(--r-full)', padding: '11px 14px', color: 'var(--ink)', fontSize: 15 }} />
          <Btn sm type="submit" disabled={busy || !q.trim()}>Pošlji</Btn>
        </form>
      </div>
    </div>
    {ai.sheet}
  </>)
}
