import { Fragment, useEffect, useLayoutEffect, useRef, useState } from 'react'
import { Head } from '@/app/Shell'
import { navigate } from '@/app/router'
import { useApp, getState, savePlanDays, updateSettings, toast, newCoachChat, restorePlanDays } from '@/state/store'
import { useAi } from '@/ui/useAi'
import { snapOf } from '@/state/snap'
import { aiAllowed } from '@/domain/import/provenance'
import { weekStartIso, addDays, todayIso } from '@/domain/training/load'
import { dayLabel, adaptText } from '@/domain/ai/coachchat'
import { dailyAdvice, chat, addToChat, loadLegacyChat, clearLegacyChat, weeklyReview, adaptWeek, CHAT_HARD_MAX, type ChatMsg, type ChatMemory } from '@/domain/ai/actions'
import { localAdvice, localReview, type LocalCoachCtx } from '@/domain/coach/local'
import { Card, Chip, Btn } from '@/ui/primitives'
import { IcoChat, IcoMic } from '@/ui/icons'
import { useDictation } from '@/ui/useDictation'
import { FREE_AI_PER_DAY } from '@/config'
import { sanitizeGaps, hasHiddenActivities } from '@/domain/ai/sanitize'
import { HealthNote } from '@/ui/HealthNote'
import { undoToast } from '@/ui/Confirm'
import { count, plural, W } from '@/ui/format'
import type { PlanDay } from '@/domain/types'

const quick = (ev?: string) => ['Kaj danes in s kakšnimi vati?', 'Sem na poti do cilja v W/kg?', 'Koliko OH na dolgi vožnji?', 'Kako izpeljem VO2max intervale?', 'Zakaj teža stoji?', `Kaj me bo na dirki${ev ? ` (${ev})` : ''} najbolj omejilo?`]
const KIND_LABEL: Record<NonNullable<ChatMsg['kind']>, string> = { advice: 'Nasvet za danes', review: 'Pregled tedna', adapt: 'Teden prilagojen' }
type Mode = 'advice' | 'chat' | 'review' | 'adapt'

const memNow = (): ChatMemory => { const c = getState().settings.coach; return { msgs: c?.msgs || [], summary: c?.summary ?? null } }
/** Podatki za odgovor iz načrta (brez AI) — stanje ob kliku. */
const localCtx = (): LocalCoachCtx => { const s = getState(); return { profile: s.profile, plan: s.plan, activities: s.activities, checkins: s.checkins, checkinToday: s.checkinToday, wellness: s.wellness, wellnessOn: !!s.settings.wellnessOn, mealsToday: s.mealsToday, recentMeals: s.recentMeals, weather: s.weather, today: s.today } }

/**
 * Trener = en pogovor kot v aplikaciji za sporočila: vse (vprašanja, nasvet za danes, pregled tedna, prilagoditev)
 * je v eni časovnici, najnovejše spodaj, tik nad vrstico za pisanje. Po odgovoru je tvoje vprašanje na vrhu zaslona,
 * odgovor pa se bere od začetka.
 */
export function Trener() {
  const app = useApp()
  const ai = useAi()
  const saved = app.settings.coach?.msgs || []
  const summary = app.settings.coach?.summary ?? null
  const [pending, setPending] = useState<ChatMsg | null>(null)
  const msgs: ChatMsg[] = pending ? [...saved, pending] : saved
  const [q, setQ] = useState('')
  // narekovanje vprašanja (prepoznava govora brskalnika, sl-SI) — kjer je ni, ostane mikrofon na tipkovnici
  const dict = useDictation(q, setQ, m => toast(m, 'err', 6000))
  const [thinking, setThinking] = useState<Mode | null>(null)
  const [confirmNew, setConfirmNew] = useState(false)
  const listRef = useRef<HTMLDivElement>(null)
  // kam se pomakne po naslednjem izrisu: 'pair' = zadnje vprašanje na vrh (ob odprtju in po odgovoru), 'bottom' = na dno (med čakanjem)
  const scrollTo = useRef<'pair' | 'bottom' | null>('pair')
  const first = useRef(true)

  const seen = app.activities.filter(aiAllowed).length
  const hidden = hasHiddenActivities(app.activities)
  const busy = ai.busy || !!thinking

  // enkratna selitev starega lokalnega pogovora v sinhronizirane nastavitve — šele po prvem usklajevanju (sicer bi
  // prazen lokalni pogovor povozil tistega z druge naprave) in samo, če stari pogovor sploh obstaja
  const migrated = useRef(false)
  const fs = app.firstSync as unknown
  const synced = app.user ? fs === true || fs === 'ok' || fs === 'empty' : app.authKnown
  useEffect(() => {
    if (migrated.current || !synced || app.settings.coach !== undefined) return
    migrated.current = true
    void loadLegacyChat().then(async old => {
      if (!old.length || getState().settings.coach !== undefined) return
      await updateSettings({ coach: { msgs: old.slice(-40), summary: null } })
      await clearLegacyChat()
    })
  }, [synced, app.settings.coach])
  useEffect(() => { if (!confirmNew) return; const t = setTimeout(() => setConfirmNew(false), 4000); return () => clearTimeout(t) }, [confirmNew])

  useLayoutEffect(() => {
    const el = listRef.current, how = scrollTo.current
    if (!el || !how) return
    const lastIsAi = msgs[msgs.length - 1]?.role === 'ai'
    if (how === 'pair' && !lastIsAi && !first.current) return          // počakaj, da je odgovor izrisan
    const atMount = first.current
    first.current = false; scrollTo.current = null
    const go = () => {
      if (!el.isConnected) return
      // aplikacija se pomika kot dokument (okno); zgoraj je na namizju lepljiva vrstica z zavihki
      const bar = document.querySelector<HTMLElement>('.dbar')
      const off = (bar && getComputedStyle(bar).position !== 'static' ? bar.getBoundingClientRect().height : 0) + 10
      if (how === 'bottom') { window.scrollTo({ top: document.documentElement.scrollHeight, behavior: 'smooth' }); return }
      const users = el.querySelectorAll<HTMLElement>('.msg.user')
      const target = users[users.length - 1]
      // zadnje vprašanje na vrh vidnega dela (odgovor se bere od začetka); kratek pogovor se ustavi na dnu
      window.scrollTo({ top: target ? Math.max(0, target.getBoundingClientRect().top + window.scrollY - off) : document.documentElement.scrollHeight })
    }
    // ob odprtju zaslona počakaj, da se postavitev umiri (vstopna animacija)
    if (atMount) setTimeout(go, 90)
    else requestAnimationFrame(go)
  }, [msgs.length, thinking])

  /** Eno vprašanje v pogovor: vse (tudi shranjevanje) je v enem opravilu, da deluje tudi po privolitvi. */
  async function converse(label: string, mode: Mode, produce: () => Promise<ChatMemory>): Promise<boolean> {
    if (busy) return false
    const at = new Date().toISOString()
    const ok = await ai.run(async () => {
      scrollTo.current = 'bottom'
      setPending({ role: 'user', text: label, at }); setThinking(mode)
      try {
        const next = await produce()
        scrollTo.current = 'pair'
        await updateSettings({ coach: next })
        return true
      } finally { setPending(null); setThinking(null) }
    })
    if (!ok && scrollTo.current === 'bottom') scrollTo.current = null
    return !!ok
  }
  const reply = (label: string, at: string, text: string, kind?: ChatMsg['kind']): Promise<ChatMemory> =>
    addToChat(memNow(), [{ role: 'user', text: label, at }, { role: 'ai', text, at: new Date().toISOString(), ...(kind ? { kind } : {}) }])
  const hasToday = (k: ChatMsg['kind'], from: string) => saved.some(m => m.kind === k && todayIso(new Date(m.at)) >= from)

  async function send(text?: string) {
    const question = (text ?? q).trim()
    if (!question || busy) return
    setQ('')
    const ok = await converse(question, 'chat', () => chat(snapOf(getState()), question, memNow()))
    if (!ok && text === undefined) setQ(question)   // vprašanje se ne izgubi
  }
  /**
   * Odgovor iz načrta, ko AI ne odgovori (ponudnik ustavljen, brez prijave ali privolitve): v isti pogovor, označen,
   * brez klica AI (tudi brez povzetka) — in nikoli v kontekst modela.
   */
  async function addLocal(label: string, kind: 'advice' | 'review', text: string) {
    const at = new Date().toISOString(), c = getState().settings.coach
    scrollTo.current = 'pair'
    const msgs: ChatMsg[] = [...(c?.msgs || []), { role: 'user', text: label, at, local: true }, { role: 'ai', text, at, kind, local: true }]
    await updateSettings({ coach: { ...(c || {}), msgs: msgs.slice(-CHAT_HARD_MAX), summary: c?.summary ?? null } })
  }
  /** Brez prijave hitra gumba odgovorita iz načrta (brez okna za prijavo); prijava z AI je v kartici zgoraj (signIn = true). */
  async function advice(signIn = false) {
    if (busy) return
    const label = 'Kaj naj danes naredim?', at = new Date().toISOString(), force = hasToday('advice', app.today)
    if (!signIn && !getState().user) { await addLocal(label, 'advice', localAdvice(localCtx())); return }
    const ok = await converse(label, 'advice', async () => reply(label, at, await dailyAdvice(snapOf(getState()), force), 'advice'))
    if (!ok) await addLocal(label, 'advice', localAdvice(localCtx()))
  }
  async function review() {
    if (busy) return
    const label = 'Pregled tedna', at = new Date().toISOString(), force = hasToday('review', weekStartIso(app.today))
    if (!getState().user) { await addLocal(label, 'review', localReview(localCtx())); return }
    const ok = await converse(label, 'review', async () => reply(label, at, await weeklyReview(snapOf(getState()), force), 'review'))
    if (!ok) await addLocal(label, 'review', localReview(localCtx()))
  }
  function adapt() {
    const thisWeek = () => { const s = getState(), ws = weekStartIso(s.today); return s.plan.filter(d => d.date >= ws && d.date <= addDays(ws, 6)) }
    if (!thisWeek().length) { toast('Ta teden še ni sestavljen — najprej ga sestavi v Planu.', 'info'); navigate('plan'); return }
    const label = 'Prilagodi ta teden', at = new Date().toISOString()
    let prev: PlanDay[] | null = null
    let written: string[] = []
    void converse(label, 'adapt', async () => {
      const week = thisWeek()
      const r = await adaptWeek(snapOf(getState()), week)
      // prejšnji (neopravljeni) dnevi za »Razveljavi«
      const dates = new Set(r.days.map(d => d.date))
      prev = getState().plan.filter(d => dates.has(d.date) && !d.done)
      written = r.days.map(d => d.date)
      await savePlanDays(r.days)
      return reply(label, at, adaptText(r.summary, week, r.days), 'adapt')
    }).then(ok => { const p = prev, ds = written; if (ok && p) undoToast('Teden je prilagojen — spremembe so v Planu.', () => restorePlanDays(p, ds), { ms: 8000 }) })
  }
  function newChat() {
    if (!confirmNew) { setConfirmNew(true); return }
    setConfirmNew(false)
    // izrecen »nov pogovor«: sinhronizacija ga prenese kot izbris (prazen seznam sam po sebi ne briše drugih naprav)
    void newCoachChat()
  }

  return (<>
    <Head hi={`trener vidi ${seen} od ${app.activities.length} aktivnosti`} nm="Trener" />
    <div className="scroll chat-page">
      {!ai.signedIn && (
        <Card accent className="stagger" style={{ marginBottom: 12 }}>
          <div className="row" style={{ gap: 12 }}>
            <div style={{ width: 40, height: 40, borderRadius: 'var(--r-s)', background: 'var(--accent)', display: 'grid', placeItems: 'center', color: 'var(--accent-ink)', flex: 'none' }}><IcoChat /></div>
            <div><b style={{ fontSize: 15 }}>AI trener teče prek tvojega računa</b><div className="muted" style={{ fontSize: 12.5, fontWeight: 600 }}>Prijava z Googlom · {FREE_AI_PER_DAY ? `dnevno do ${FREE_AI_PER_DAY} AI ${plural(FREE_AI_PER_DAY, W.dejanjeR)}` : 'AI brez omejitve'}</div></div>
          </div>
          <Btn primary block sm style={{ marginTop: 12 }} onClick={() => void advice(true)}>Prijava z Googlom in prvi nasvet</Btn>
          <div className="muted" style={{ fontSize: 11.5, marginTop: 8 }}>Brez prijave »Kaj naj danes naredim?« in »Pregled tedna« odgovorita iz tvojega načrta.</div>
        </Card>
      )}
      {app.activities.length > 0 && seen < app.activities.length && (
        <div className="muted" style={{ fontSize: 12, padding: '0 4px 10px' }}>{count(app.activities.length - seen, W.aktivnost)} trener ne sme uporabiti (Stravin ali neznan izvor). Datoteke, Garmin prek intervals.icu, posnetki in ročni vnosi štejejo.</div>
      )}
      {!ai.consent && ai.signedIn && <div className="muted" style={{ fontSize: 12, padding: '0 4px 10px' }}>Pred prvim nasvetom te vprašam za privolitev — kaj gre v AI in kaj ne.</div>}

      <div className="chat" ref={listRef}>
        {(saved.length > 0 || summary) && (
          <div className="between" style={{ gap: 10 }}>
            <span className="muted" style={{ fontSize: 12 }}>{summary ? 'Trener si zapomni tudi starejše pogovore.' : 'Pogovor se shrani — nadaljuješ, kjer si končal.'}</span>
            <button className="chip sm click" onClick={newChat} disabled={busy}>{confirmNew ? 'res pobrišem?' : 'nov pogovor'}</button>
          </div>
        )}
        {msgs.length === 0 && (
          <div className="chat-empty">
            <b style={{ fontSize: 15 }}>Vprašaj trenerja</b>
            <p style={{ fontSize: 13, marginTop: 4 }}>Odgovori so vedno tukaj, najnovejši spodaj — tik nad vrstico za pisanje. Tudi »Kaj naj danes naredim?«, »Pregled tedna« in »Prilagodi ta teden« odgovorijo tukaj.</p>
            <div className="row" style={{ gap: 6, flexWrap: 'wrap', marginTop: 10 }}>{quick(app.profile.event?.name).map(t => <Chip key={t} sm onClick={() => void send(t)}>{t}</Chip>)}</div>
          </div>
        )}
        {msgs.map((m, i) => {
          const day = dayLabel(m.at, app.today)
          const prev = i > 0 ? dayLabel(msgs[i - 1]!.at, app.today) : null
          return (
            <Fragment key={`${m.at}-${i}`}>
              {day !== prev && <div className="day">{day}</div>}
              <div className={`msg ${m.role}`}>
                {m.role === 'ai' && m.kind && <b className="kind">{KIND_LABEL[m.kind]}{m.local ? <span className="local"> · iz načrta, brez AI</span> : null}</b>}
                {m.role === 'ai' ? sanitizeGaps(m.text, hidden) : m.text}
              </div>
            </Fragment>)
        })}
        {thinking && <div className="msg ai typing"><span className="thinking"><i /><i /><i /></span>{thinking === 'adapt' ? <span className="muted" style={{ marginLeft: 8, fontSize: 12.5 }}>prilagajam teden …</span> : null}</div>}
      </div>

      {/* nasveti trenerja so o treningu in hrani — opozorilo tik nad vrstico za pisanje */}
      <HealthNote kind="both" style={{ marginTop: 14, padding: '0 2px' }} />
      {/* vrstica za pisanje: vedno na vidiku, tik pod zadnjim odgovorom; bližnjice odgovorijo v isti pogovor */}
      {/* senca v barvi ozadja zapre režo pod vrstico (nad zavihki), da besedilo ne kuka izpod nje */}
      <div className="composer" style={{ boxShadow: '0 12px 0 var(--bg)' }}>
        <div className="quick">
          <Chip sm onClick={() => void advice()}>Kaj naj danes naredim?</Chip>
          <Chip sm onClick={() => void review()}>Pregled tedna</Chip>
          <Chip sm onClick={adapt}>Prilagodi ta teden</Chip>
        </div>
        <form className="row" style={{ gap: 8 }} onSubmit={e => { e.preventDefault(); dict.stop(); void send() }}>
          <div className={`ask${dict.listening ? ' live' : ''}`}>
            <input className="field" value={q} onChange={e => setQ(e.target.value)} placeholder={dict.listening ? 'Poslušam …' : 'Vprašaj trenerja …'} enterKeyHint="send" />
            {dict.canSpeak && <button type="button" className={`mic${dict.listening ? ' on' : ''}`} onClick={dict.toggle} disabled={busy} aria-pressed={dict.listening} aria-label={dict.listening ? 'Ustavi narekovanje' : 'Nareči vprašanje'}><IcoMic width={17} height={17} /></button>}
          </div>
          <Btn sm type="submit" disabled={busy || !q.trim()}>Pošlji</Btn>
        </form>
      </div>
    </div>
    {ai.sheet}
  </>)
}
