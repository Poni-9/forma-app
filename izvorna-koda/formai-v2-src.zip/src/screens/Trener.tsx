import { Fragment, useEffect, useLayoutEffect, useRef, useState } from 'react'
import { Head } from '@/app/Shell'
import { navigate } from '@/app/router'
import { useApp, getState, savePlanDays, updateSettings, toast, newCoachChat, restorePlanDays, endWeekPause } from '@/state/store'
import { useAi } from '@/ui/useAi'
import { snapOf } from '@/state/snap'
import { aiAllowed } from '@/domain/import/provenance'
import { weekStartIso, addDays, todayIso } from '@/domain/training/load'
import { dayLabel, adaptText, adaptTarget, adaptDone } from '@/domain/ai/coachchat'
import { dailyAdvice, chat, addToChat, loadLegacyChat, clearLegacyChat, weeklyReview, adaptWeek, adviceSig, CHAT_HARD_MAX, PAUSE_NOTHING, type ChatMsg, type ChatMemory } from '@/domain/ai/actions'
import { localAdvice, localReview, type LocalCoachCtx } from '@/domain/coach/local'
import { Card, Chip, Btn } from '@/ui/primitives'
import { IcoChat, IcoMic, IcoCamera } from '@/ui/icons'
import { useDictation } from '@/ui/useDictation'
import { FREE_AI_PER_DAY } from '@/config'
import { sanitizeGaps, hasHiddenActivities, honest } from '@/domain/ai/sanitize'
import { looksIntent } from '@/domain/coach/bodyfat'
import { weightTrend, isMinor } from '@/domain/nutrition/energy'
import { CoachText } from '@/ui/CoachText'
import { BodyFatCard, CoachExercises } from '@/ui/CoachExtras'
import { HealthNote } from '@/ui/HealthNote'
import { undoToast } from '@/ui/Confirm'
import { count, plural, W } from '@/ui/format'
import type { Focus, PlanDay, Profile } from '@/domain/types'
import { noPower } from '@/domain/training/zones'
import { isCustom, isStrength, kgStrength } from '@/domain/focus/model'
import { ListenBar } from '@/ui/ListenBar'
import { PauseOffer } from '@/ui/WeekPauseSheet'
// (v3.50) slika sebe → predlog vaj (ločen list, poziv v domain/ai/photoTraining.ts)
import { openPhotoTraining } from '@/ui/photoOpen'
import { pauseIntent, pauseEndIntent, sickIntent, activePause, inPause, type WeekPause } from '@/domain/training/pause'
import { selfAvailable } from '@/domain/ai/photoTraining'
import { healthOf } from '@/domain/training/exercises'
import { SickSheet } from '@/ui/SickSheet'
import { g } from '@/ui/gender'
import { rem } from '@/ui/rem'

/**
 * Kolesar: vati samo z merilnikom (ali brez podatka), W/kg in dirka samo s ciljem z datumom (v3.48); (v3.50) mladoletnemu brez teže.
 * (v3.51) z zdravstveno omejitvijo (tlak, srce …) brez VO2max intervalov (C40) — načrt jih nima.
 */
export const quick = (p: Pick<Profile, 'gear' | 'event'> & Partial<Pick<Profile, 'age' | 'focus'>>) => {
  const ev = p.event?.name
  const watts = !noPower(p)
  const health = healthOf(p.focus?.limits).length > 0
  return [watts ? 'Kaj danes in s kakšnimi vati?' : 'Kaj danes in v kateri coni?', ev && watts ? 'Sem na poti do cilja v W/kg?' : 'Kako hitreje do cilja?', 'Koliko OH na dolgi vožnji?', health ? 'Kako varno treniram z mojo omejitvijo?' : 'Kako izpeljem VO2max intervale?', isMinor(p) ? 'Koliko spanja rabim?' : 'Zakaj teža stoji?', ...(ev ? [`Kaj me bo na dirki (${ev}) najbolj omejilo?`] : [])]
}
/** (v3.51) Ob premoru (ponudba ali že velja) drugačna hitra vprašanja — ne »Kako izpeljem VO2max intervale?« (C34). */
export const PAUSE_QUICK = ['Kaj jem v tednu brez treninga?', 'Kako se vrnem po premoru?', 'Koliko spanja rabim?']
/** (v3.51) Brez povezave vprašanje ostane v pogovoru takoj (prej 7 s čakanja na tri poskuse) — C28. */
export const OFFLINE_ASK = 'Ni povezave — vprašanje počaka tu. Brez povezave odgovorita »Kaj naj danes naredim?« in »Pregled tedna« iz načrta.'
const offline = () => typeof navigator !== 'undefined' && navigator.onLine === false
/** (v3.51) Vrstica aplikacije pod odgovorom o premoru — ne gre skozi varovalko (ni AI) in nima besed, ki jih ta briše (C01). */
export function pauseAppLine(mode: WeekPause['mode'], twoWeeks: boolean): string {
  return `${twoWeeks ? 'Ta in naslednji teden počiješ' : 'Ta teden počiješ'}${mode === 'kolo' ? ' (brez kolesa)' : ''} — tapni spodaj, da načrt to upošteva.`
}
/**
 * Načrt po meri: vprašanja o moči, trebuhu, hrani in kondiciji. (v3.50) Kilogrami samo z utežmi (brez opreme ponovitve),
 * maščoba okoli pasu in teža nikoli do 18. leta (prej 16-letnik doma brez opreme: »Koliko kg …«, »Zakaj teža stoji?«).
 */
export const quickCustom = (f: (Pick<Focus, 'sessions' | 'equipment'> & Partial<Pick<Focus, 'aims'>>) | null | undefined, minor: boolean): string[] => {
  const strength = !!f?.sessions.some(isStrength)
  const kg = !!f && kgStrength(f)
  // (v3.51) maščoba okoli pasu in teža samo pri hujšanju ali definiciji (C39) — prej tudi kondiciji in zdravju
  const cut = !minor && !!f?.aims?.some(a => a === 'hujsanje' || a === 'definicija')
  return [
    ...(kg ? ['Koliko kg danes pri osnovnih vajah?', 'Kdaj dvignem težo?'] : strength ? ['Koliko ponovitev danes pri osnovnih vajah?', 'Kdaj preidem na težjo različico vaje?'] : []),
    ...(strength && cut ? ['Kako izgubim maščobo okoli pasu?'] : []),
    'Koliko beljakovin danes in iz česa?', 'Kako izboljšam kondicijo hitreje?',
    cut ? 'Zakaj teža stoji?' : minor ? 'Koliko spanja rabim?' : 'Kako se raztegnem po vadbi?',
  ]
}
const questionsFor = (p: Profile) => (isCustom(p) ? quickCustom(p.focus, isMinor(p)) : quick(p))
const KIND_LABEL: Record<NonNullable<ChatMsg['kind']>, string> = { advice: 'Nasvet za danes', review: 'Pregled tedna', adapt: 'Teden prilagojen' }
type Mode = 'advice' | 'chat' | 'review' | 'adapt'

const memNow = (): ChatMemory => { const c = getState().settings.coach; return { msgs: c?.msgs || [], summary: c?.summary ?? null } }
/** Podatki za odgovor iz načrta (brez AI) — stanje ob kliku. */
const localCtx = (): LocalCoachCtx => { const s = getState(); return { profile: s.profile, plan: s.plan, activities: s.activities, checkins: s.checkins, checkinToday: s.checkinToday, wellness: s.wellness, wellnessOn: !!s.settings.wellnessOn, mealsToday: s.mealsToday, recentMeals: s.recentMeals, weather: s.weather, today: s.today, foodPrefs: s.settings.foodPrefs ?? null } }

/**
 * Trener = en pogovor kot v aplikaciji za sporočila: vse (vprašanja, nasvet za danes, pregled tedna, prilagoditev)
 * je v eni časovnici, najnovejše spodaj, tik nad vrstico za pisanje. Po odgovoru je tvoje vprašanje na vrhu zaslona,
 * odgovor pa se bere od začetka.
 */
export function Trener() {
  const app = useApp()
  const ai = useAi()
  const saved = app.settings.coach?.msgs || []
  const summary = app.settings.coach?.summary ?? null
  const [pending, setPending] = useState<ChatMsg | null>(null)
  const msgs: ChatMsg[] = pending ? [...saved, pending] : saved
  const [q, setQ] = useState('')
  // narekovanje vprašanja (prepoznava govora brskalnika, sl-SI) — kjer je ni, ostane mikrofon na tipkovnici
  const dict = useDictation(q, setQ, m => toast(m, 'err', 6000), 'vprašanje trenerju')
  const [thinking, setThinking] = useState<Mode | null>(null)
  // (v3.49) vprašanje, na katero AI ni odgovoril, ostane v pogovoru (sivo) s »Poskusi znova« — prej je izginilo
  const [failed, setFailed] = useState<{ text: string; why: string } | null>(null)
  // (v3.50) vprašanje, ki ni šlo (preklic prijave): premor »ta teden nočem nič« se uveljavi tudi brez AI
  const [held, setHeld] = useState<string | null>(null)
  const [confirmNew, setConfirmNew] = useState(false)
  const listRef = useRef<HTMLDivElement>(null)
  // kam se pomakne po naslednjem izrisu: 'pair' = zadnje vprašanje na vrh (ob odprtju in po odgovoru), 'bottom' = na dno (med čakanjem)
  const scrollTo = useRef<'pair' | 'bottom' | null>('pair')
  const first = useRef(true)

  const seen = app.activities.filter(aiAllowed).length
  // teža za lestvico maščobe: 7-dnevno povprečje tehtanj, sicer profil
  const weightNow = weightTrend(app.checkins)?.avg7 ?? app.profile.weightKg ?? null
  const hidden = hasHiddenActivities(app.activities)
  const busy = ai.busy || !!thinking
  // (v3.50) v nedeljo in ko je tekoči teden mimo: naslednji teden (če je sestavljen)
  const adaptLabel = adaptTarget(app.plan, app.today)?.next ? 'Prilagodi naslednji teden' : 'Prilagodi teden'
  const minor = isMinor(app.profile)
  // (v3.50) »ta teden nočem nič«: pod odgovorom gumb »Uveljavi: ta teden brez …« — samo pri zadnjem takem vprašanju tega tedna
  const ws0 = weekStartIso(app.today)
  let offerAt = -1
  for (let i = saved.length - 1; i > 0 && offerAt < 0; i--) {
    const m = saved[i]!, q0 = saved[i - 1]!
    if (m.role === 'ai' && !m.kind && q0.role === 'user' && todayIso(new Date(q0.at)) >= ws0 && pauseIntent(q0.text)) offerAt = i
  }
  // (v3.51) »prekliči premor« ob veljavnem premoru (C23) in »ta teden sem bolan« (B14): zadnji odgovor dobi gumb
  const pzNow = activePause(app.profile, app.today)
  const lastAsk = saved.length > 1 && saved[saved.length - 1]!.role === 'ai' && !saved[saved.length - 1]!.kind ? saved[saved.length - 2]! : null
  const endAt = pzNow && lastAsk?.role === 'user' && !pauseIntent(lastAsk.text) && pauseEndIntent(lastAsk.text) ? saved.length - 1 : -1
  const sickAt = lastAsk?.role === 'user' && todayIso(new Date(lastAsk.at)) === app.today && sickIntent(lastAsk.text) ? saved.length - 1 : -1
  const [sickOpen, setSickOpen] = useState(false)
  const [ending, setEnding] = useState(false)
  // hitra vprašanja ob premoru (C34)
  const pauseQ = !!pzNow || (offerAt >= 0 && offerAt === saved.length - 1)
  const photoOk = selfAvailable(app.profile) === 'ok'

  // enkratna selitev starega lokalnega pogovora v sinhronizirane nastavitve — šele po prvem usklajevanju (sicer bi
  // prazen lokalni pogovor povozil tistega z druge naprave) in samo, če stari pogovor sploh obstaja
  const migrated = useRef(false)
  const fs = app.firstSync as unknown
  const synced = app.user ? fs === true || fs === 'ok' || fs === 'empty' : app.authKnown
  useEffect(() => {
    if (migrated.current || !synced || app.settings.coach !== undefined) return
    migrated.current = true
    void loadLegacyChat().then(async old => {
      if (!old.length || getState().settings.coach !== undefined) return
      await updateSettings({ coach: { msgs: old.slice(-40), summary: null } })
      await clearLegacyChat()
    })
  }, [synced, app.settings.coach])
  useEffect(() => { if (!confirmNew) return; const t = setTimeout(() => setConfirmNew(false), 4000); return () => clearTimeout(t) }, [confirmNew])

  useLayoutEffect(() => {
    const el = listRef.current, how = scrollTo.current
    if (!el || !how) return
    const lastIsAi = msgs[msgs.length - 1]?.role === 'ai'
    if (how === 'pair' && !lastIsAi && !first.current) return          // počakaj, da je odgovor izrisan
    const atMount = first.current
    first.current = false; scrollTo.current = null
    const go = () => {
      if (!el.isConnected) return
      // aplikacija se pomika kot dokument (okno); zgoraj je na namizju lepljiva vrstica z zavihki
      const bar = document.querySelector<HTMLElement>('.dbar')
      const off = (bar && getComputedStyle(bar).position !== 'static' ? bar.getBoundingClientRect().height : 0) + 10
      if (how === 'bottom') { window.scrollTo({ top: document.documentElement.scrollHeight, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' }); return }
      const users = el.querySelectorAll<HTMLElement>('.msg.user')
      const target = users[users.length - 1]
      // zadnje vprašanje na vrh vidnega dela (odgovor se bere od začetka); kratek pogovor se ustavi na dnu
      window.scrollTo({ top: target ? Math.max(0, target.getBoundingClientRect().top + window.scrollY - off) : document.documentElement.scrollHeight })
    }
    // ob odprtju zaslona počakaj, da se postavitev umiri (vstopna animacija)
    if (atMount) setTimeout(go, 90)
    else requestAnimationFrame(go)
  }, [msgs.length, thinking])

  /** Eno vprašanje v pogovor: vse (tudi shranjevanje) je v enem opravilu, da deluje tudi po privolitvi. */
  async function converse(label: string, mode: Mode, produce: () => Promise<ChatMemory>, onError?: (msg: string) => void): Promise<boolean> {
    if (busy) return false
    const at = new Date().toISOString()
    const ok = await ai.run(async () => {
      scrollTo.current = 'bottom'
      setPending({ role: 'user', text: label, at }); setThinking(mode)
      try {
        const next = await produce()
        scrollTo.current = 'pair'
        await updateSettings({ coach: next })
        return true
      } finally { setPending(null); setThinking(null) }
    }, onError ? { onError, quiet: true } : undefined)
    if (!ok && scrollTo.current === 'bottom') scrollTo.current = null
    return !!ok
  }
  const reply = (label: string, at: string, text: string, kind?: ChatMsg['kind']): Promise<ChatMemory> =>
    addToChat(memNow(), [{ role: 'user', text: label, at }, { role: 'ai', text, at: new Date().toISOString(), ...(kind ? { kind } : {}) }])
  const hasToday = (k: ChatMsg['kind'], from: string) => saved.some(m => m.kind === k && todayIso(new Date(m.at)) >= from)

  /** `keep`: ob neuspehu brez razloga (preklic prijave ali privolitve) gre vprašanje nazaj v polje — iz polja in pri »Poskusi znova« (v3.49), ne s hitrih gumbov. */
  async function send(text?: string, keep = text === undefined) {
    const question = (text ?? q).trim()
    if (!question || busy) return
    setQ(''); setFailed(null)
    if (offline()) { setFailed({ text: question, why: OFFLINE_ASK }); return }
    const err = { why: '' }
    const ok = await converse(question, 'chat', () => chat(snapOf(getState()), question, memNow()), m => { err.why = m })
    if (!ok && err.why) setFailed({ text: question, why: err.why })
    else if (!ok && keep) { setQ(question); setHeld(question) }   // vprašanje se ne izgubi
  }
  /**
   * Odgovor iz načrta, ko AI ne odgovori (ponudnik ustavljen, brez prijave ali privolitve): v isti pogovor, označen,
   * brez klica AI (tudi brez povzetka) — in nikoli v kontekst modela.
   */
  async function addLocal(label: string, kind: 'advice' | 'review', text: string) {
    const at = new Date().toISOString(), s = getState(), c = s.settings.coach
    scrollTo.current = 'pair'
    const old = c?.msgs || []
    // (v3.50) isti odgovor iz načrta je že zadnji v pogovoru (danes) → osveži ga namesto dvojnika (prej vsak tap nov par)
    const q0 = old[old.length - 2], a0 = old[old.length - 1]
    const same = !!q0 && !!a0 && !!q0.local && !!a0.local && a0.kind === kind && q0.text === label && todayIso(new Date(a0.at)) === s.today
    const msgs: ChatMsg[] = [...(same ? old.slice(0, -2) : old), { role: 'user', text: label, at, local: true }, { role: 'ai', text, at, kind, local: true }]
    await updateSettings({ coach: { ...(c || {}), msgs: msgs.slice(-CHAT_HARD_MAX), summary: c?.summary ?? null } })
    if (same) toast(kind === 'advice' ? 'Nasvet za danes je že v pogovoru — osvežen.' : 'Pregled tedna je že v pogovoru — osvežen.', 'info')
  }
  /** Brez prijave hitra gumba odgovorita iz načrta (brez okna za prijavo); prijava z AI je v kartici zgoraj (signIn = true). */
  async function advice(signIn = false) {
    if (busy) return
    const label = 'Kaj naj danes naredim?', at = new Date().toISOString(), force = hasToday('advice', app.today)
    // (v3.51) brez povezave takoj iz načrta (C28)
    if ((!signIn && !getState().user) || offline()) { await addLocal(label, 'advice', localAdvice(localCtx())); return }
    const ok = await converse(label, 'advice', async () => { const s = getState(); return reply(label, at, await dailyAdvice(snapOf(s), force, adviceSig(s)), 'advice') })
    if (!ok) await addLocal(label, 'advice', localAdvice(localCtx()))
  }
  async function review() {
    if (busy) return
    const label = 'Pregled tedna', at = new Date().toISOString(), force = hasToday('review', weekStartIso(app.today))
    if (!getState().user || offline()) { await addLocal(label, 'review', localReview(localCtx())); return }
    const ok = await converse(label, 'review', async () => reply(label, at, await weeklyReview(snapOf(getState()), force), 'review'))
    if (!ok) await addLocal(label, 'review', localReview(localCtx()))
  }
  function adapt() {
    const s0 = getState(), t0 = adaptTarget(s0.plan, s0.today)
    if (!t0) { toast('Ta teden še ni sestavljen — najprej ga sestavi v Planu.', 'info'); navigate('plan'); return }
    // (v3.51) vse opravljeno, naslednji teden še ni sestavljen: brez klica AI za opravljene dni (C49)
    if (adaptDone(s0.plan, s0.today)) { toast('Ta teden je opravljen. Naslednji teden še ni sestavljen — sestavi ga v Planu, nato ga lahko prilagodiš.', 'info', 7000); navigate('plan'); return }
    // (v3.51) preostanek tedna je premor: ni česa prilagoditi (C27)
    if (t0.days.every(d => d.kind === 'moc' || inPause(s0.profile, d.date)) && t0.days.some(d => inPause(s0.profile, d.date))) { toast(PAUSE_NOTHING, 'info', 7000); return }
    // (v3.50) dogovor brez kardia (samo moč): AI nima česa prilagoditi — moč ostane po dogovoru (prej klic AI s samimi dnevi počitka)
    const f = s0.profile.focus
    if (isCustom(s0.profile) && f && !f.sessions.some(x => !isStrength(x))) { toast('Tvoj teden je moč po dogovoru in počitek — vadbe moči ostanejo, kot so dogovorjene. Če ti dan ne gre, ga na Danes prestavi ali olajšaj.', 'info', 7000); return }
    const label = adaptLabel, at = new Date().toISOString()
    let prev: PlanDay[] | null = null
    let written: string[] = []
    void converse(label, 'adapt', async () => {
      // (v3.50) samo dnevi od danes naprej (ali naslednji teden v nedeljo in ko je ta mimo)
      const s = getState(), t = adaptTarget(s.plan, s.today) ?? t0
      const week = t.days
      const nws = addDays(weekStartIso(s.today), 7)
      const r = await adaptWeek(snapOf(s), week, t.next ? `To je NASLEDNJI teden (od ponedeljka ${+nws.slice(8)}. ${+nws.slice(5, 7)}.) — tekoči teden je mimo; prilagodi ga stanju zdaj.` : undefined)
      // prejšnji (neopravljeni) dnevi za »Razveljavi«
      const dates = new Set(r.days.map(d => d.date))
      prev = getState().plan.filter(d => dates.has(d.date) && !d.done)
      written = r.days.map(d => d.date)
      await savePlanDays(r.days)
      return reply(label, at, adaptText(r.summary, week, r.days), 'adapt')
    }).then(ok => { const p = prev, ds = written; if (ok && p) undoToast('Teden je prilagojen — spremembe so v Planu.', () => restorePlanDays(p, ds), { ms: 8000 }) })
  }
  function newChat() {
    if (!confirmNew) { setConfirmNew(true); return }
    setConfirmNew(false)
    // izrecen »nov pogovor«: sinhronizacija ga prenese kot izbris (prazen seznam sam po sebi ne briše drugih naprav)
    void newCoachChat()
  }

  return (<>
    <Head hi="pozna tvoj načrt in počutje" nm="Trener" />
    <div className="scroll chat-page">
      {!ai.signedIn && (
        <Card accent className="stagger" style={{ marginBottom: 12 }}>
          <div className="row" style={{ gap: 12 }}>
            <div style={{ width: 40, height: 40, borderRadius: 'var(--r-s)', background: 'var(--accent)', display: 'grid', placeItems: 'center', color: 'var(--accent-ink)', flex: 'none' }}><IcoChat /></div>
            <div><b style={{ fontSize: rem(15) }}>AI trener teče prek tvojega računa</b><div className="muted" style={{ fontSize: rem(12.5), fontWeight: 600 }}>Prijava z Googlom · {FREE_AI_PER_DAY ? `dnevno do ${FREE_AI_PER_DAY} AI ${plural(FREE_AI_PER_DAY, W.dejanjeR)}` : 'AI brez omejitve'}</div></div>
          </div>
          <Btn primary block sm style={{ marginTop: 12 }} onClick={() => void advice(true)}>Prijava z Googlom in prvi nasvet</Btn>
          <div className="muted" style={{ fontSize: rem(11.5), marginTop: 8 }}>Brez prijave »Kaj naj danes naredim?« in »Pregled tedna« odgovorita iz tvojega načrta.</div>
        </Card>
      )}
      {app.activities.length > 0 && seen < app.activities.length && (
        <div className="muted" style={{ fontSize: rem(12), padding: '0 4px 10px' }}>{count(app.activities.length - seen, W.aktivnost)} trener ne sme uporabiti (Stravin ali neznan izvor). Datoteke, Garmin prek intervals.icu, posnetki in ročni vnosi štejejo.</div>
      )}
      {!ai.consent && ai.signedIn && <div className="muted" style={{ fontSize: rem(12), padding: '0 4px 10px' }}>Pred prvim nasvetom te vprašam za privolitev — kaj gre v AI in kaj ne.</div>}

      <div className="chat" ref={listRef}>
        {(saved.length > 0 || summary) && (
          <div className="between" style={{ gap: 10 }}>
            <span className="muted" style={{ fontSize: rem(12) }}>{summary ? 'Zapomni si tudi starejše pogovore.' : ''}</span>
            <button className="chip sm click" onClick={newChat} disabled={busy}>{confirmNew ? 'res pobrišem?' : 'nov pogovor'}</button>
          </div>
        )}
        {msgs.length === 0 && (
          <div className="chat-empty">
            <b style={{ fontSize: rem(15) }}>Vprašaj trenerja</b>
            <p style={{ fontSize: rem(13), marginTop: 4 }}>Vprašaj o treningu, hrani ali počitku — odgovor pride sem, najnovejši spodaj.</p>
            <div className="row" style={{ gap: 6, flexWrap: 'wrap', marginTop: 10 }}>{questionsFor(app.profile).map(t => <Chip key={t} sm onClick={() => void send(t)}>{t}</Chip>)}</div>
          </div>
        )}
        {msgs.map((m, i) => {
          const day = dayLabel(m.at, app.today)
          const prev = i > 0 ? dayLabel(msgs[i - 1]!.at, app.today) : null
          // (v3.49) odgovor: brez surovega markdowna in zagotovil; pod njim lestvica maščobe (vprašanje o videzu) in vaje iz knjižnice
          // (v3.51) odgovor iz načrta (brez AI) ne gre skozi varovalko (C02): sestavi ga aplikacija iz vseh aktivnosti, zato ne
          // more trditi neaktivnosti, ki je ni — prej je uporabnik s Stravo izgubil vrstico »Ta teden: premor …«
          const cleaned = m.role === 'ai' && !m.local ? sanitizeGaps(m.text, hidden) : m.text
          const text = m.role === 'ai' ? honest(cleaned, { minor, noAge: !minor && !(app.profile.age != null && app.profile.age >= 18) }) : m.text
          const asked = i > 0 ? msgs[i - 1]! : null
          const look = m.role === 'ai' && !m.kind && asked?.role === 'user' && looksIntent(asked.text)
          // (v3.51) varovalka je pobrisala del odgovora o premoru (C01): pod njim vrstica aplikacije, da gumb ni brez razlage
          const pi = i === offerAt && asked ? pauseIntent(asked.text) : null
          const appLine = pi && hidden && (cleaned !== m.text || cleaned.length < 20) && !(pzNow && (pzNow.mode === 'vse' || pzNow.mode === pi.mode)) ? pauseAppLine(pi.mode, pi.twoWeeks) : null
          return (
            <Fragment key={`${m.at}-${i}`}>
              {day !== prev && <div className="day">{day}</div>}
              <div className={`msg ${m.role}`}>
                {m.role === 'ai' && m.kind && <b className="kind">{KIND_LABEL[m.kind]}{m.local ? <span className="local"> · iz načrta, brez AI</span> : null}</b>}
                {m.role === 'ai' ? <CoachText text={text} /> : text}
              </div>
              {look && <BodyFatCard profile={app.profile} weightKg={weightNow} ask={asked!.text} />}
              {m.role === 'ai' && <CoachExercises text={text} />}
              {appLine && <div className="muted pause-app" role="note">{appLine}</div>}
              {pi && <PauseOffer mode={pi.mode} twoWeeks={pi.twoWeeks} />}
              {i === endAt && (
                <div className="pause-offer">
                  <Btn primary sm disabled={ending} onClick={async () => { setEnding(true); try { await endWeekPause() } finally { setEnding(false) } }}>Prekliči premor</Btn>
                  <span className="muted" style={{ fontSize: rem(12) }}>preostali dnevi se sestavijo znova</span>
                </div>
              )}
              {i === sickAt && (
                <div className="pause-offer">
                  <Btn primary sm onClick={() => setSickOpen(true)}>{g(app.profile, 'Bolan sem', 'Bolna sem')}</Btn>
                  <span className="muted" style={{ fontSize: rem(12) }}>načrt počaka in se po bolezni nadaljuje lažje</span>
                </div>
              )}
            </Fragment>)
        })}
        {/* (v3.50) hitra vprašanja tudi po prvem sporočilu: do tri, ki jih še ni vprašal (prej samo v praznem pogovoru) */}
        {msgs.length > 0 && msgs[msgs.length - 1]!.role === 'ai' && !thinking && !failed && (() => {
          const nq = (s: string) => s.trim().toLowerCase().replace(/[?!.\s]+$/, '')
          const asked = msgs.filter(m => m.role === 'user').map(m => nq(m.text))
          const more = (pauseQ ? PAUSE_QUICK : questionsFor(app.profile)).filter(t => !asked.some(a => a.startsWith(nq(t)))).slice(0, 3)
          return more.length ? <div className="row chat-more" style={{ gap: 6, flexWrap: 'wrap' }} aria-label="Lahko vprašaš še">{more.map(t => <Chip key={t} sm onClick={() => void send(t)}>{t}</Chip>)}</div> : null
        })()}
        {failed && !pending && (<>
          <div className="msg user failed">{failed.text}</div>
          <div className="msg-fail" role="status">{failed.why}<button type="button" className="chip sm click" disabled={busy} onClick={() => { const f = failed; setFailed(null); void send(f.text, true) }}>Poskusi znova</button></div>
          {/* (v3.50) premor se uveljavi tudi brez AI (prepoznava na napravi) */}
          {(() => { const pi = pauseIntent(failed.text); return pi ? <PauseOffer mode={pi.mode} twoWeeks={pi.twoWeeks} /> : null })()}
        </>)}
        {!failed && held && held === q && (() => { const pi = pauseIntent(held); return pi ? <PauseOffer mode={pi.mode} twoWeeks={pi.twoWeeks} /> : null })()}
        {thinking && <div className="msg ai typing"><span className="thinking"><i /><i /><i /></span>{thinking === 'adapt' ? <span className="muted" style={{ marginLeft: 8, fontSize: rem(12.5) }}>prilagajam teden …</span> : null}</div>}
      </div>

      {/* nasveti trenerja so o treningu in hrani — opozorilo tik nad vrstico za pisanje */}
      <HealthNote kind="both" style={{ marginTop: 14, padding: '0 2px' }} />
      {/* vrstica za pisanje: vedno na vidiku, tik pod zadnjim odgovorom; bližnjice odgovorijo v isti pogovor */}
      {/* senca v barvi ozadja zapre režo pod vrstico (nad zavihki), da besedilo ne kuka izpod nje */}
      <div className="composer" style={{ boxShadow: '0 12px 0 var(--bg)' }}>
        <div className="quick">
          <Chip sm onClick={() => void advice()}>Kaj naj danes naredim?</Chip>
          <Chip sm onClick={() => void review()}>Pregled tedna</Chip>
          <Chip sm onClick={adapt}>{adaptLabel}</Chip>
        </div>
        <form className="row" style={{ gap: 8 }} onSubmit={e => { e.preventDefault(); dict.stop(); void send() }}>
          {/* (v3.51) »Predlog s slike« kot kamera v polju (C36: 4. čip je zlomil vrstico) in samo, ko je na voljo (C35: ne do 18. leta) */}
          <div className={`ask${dict.listening ? ' live' : ''}${photoOk ? (dict.canSpeak ? ' two' : ' one') : ''}`}>
            <input className="field" value={q} onChange={e => setQ(e.target.value)} placeholder={dict.listening ? 'Poslušam …' : 'Vprašaj trenerja …'} enterKeyHint="send" />
            {photoOk && <button type="button" className="cam" onClick={() => openPhotoTraining({ mode: 'self' })} disabled={busy} aria-label="Predlog vaj s slike sebe" title="Predlog vaj s slike sebe"><IcoCamera width={17} height={17} /></button>}
            {dict.canSpeak && <button type="button" className={`mic${dict.listening ? ' on' : ''}`} onClick={dict.toggle} disabled={busy} aria-pressed={dict.listening} aria-label={dict.listening ? 'Ustavi narekovanje' : 'Nareči vprašanje'}><IcoMic width={17} height={17} /></button>}
          </div>
          <Btn sm type="submit" disabled={busy || !q.trim()}>Pošlji</Btn>
        </form>
        <ListenBar listening={dict.listening} onStop={dict.stop} value={q} transcribing={dict.transcribing} level={dict.level} />
      </div>
    </div>
    {ai.sheet}
    {sickAt >= 0 && <SickSheet open={sickOpen} onClose={() => setSickOpen(false)} />}
  </>)
}
