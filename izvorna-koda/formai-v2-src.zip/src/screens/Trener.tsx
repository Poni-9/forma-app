import { useEffect, useRef, useState } from 'react'
import { Head } from '@/app/Shell'
import { navigate } from '@/app/router'
import { useApp, savePlanDays, updateSettings, toast } from '@/state/store'
import { useAi } from '@/ui/useAi'
import { snapOf } from '@/state/snap'
import { aiAllowed } from '@/domain/import/provenance'
import { formSeries, formBand, weekStartIso, addDays } from '@/domain/training/load'
import { dailyAdvice, cachedDailyAdvice, chat, loadLegacyChat, clearLegacyChat, weeklyReview, adaptWeek, type ChatMsg } from '@/domain/ai/actions'
import { Card, Chip, Btn } from '@/ui/primitives'
import { IcoChat, IcoCal } from '@/ui/icons'
import { FREE_AI_PER_DAY } from '@/config'
import { sanitizeGaps, hasHiddenActivities } from '@/domain/ai/sanitize'

const quick = (ev?: string) => ['Kaj danes in s kakšnimi vati?', 'Sem na poti do cilja v W/kg?', 'Koliko OH na dolgi vožnji?', 'Kako izpeljem VO2max intervale?', 'Zakaj teža stoji?', `Kaj me bo na dirki${ev ? ` (${ev})` : ''} najbolj omejilo?`]

export function Trener() {
  const app = useApp()
  const ai = useAi()
  const [advice, setAdvice] = useState<string | null>(null)
  const [review, setReview] = useState<string | null>(null)
  // pogovor živi v nastavitvah (sinhroniziran med napravami); med čakanjem na odgovor pokažemo vprašanje takoj
  const saved = app.settings.coach?.msgs || []
  const [pending, setPending] = useState<ChatMsg | null>(null)
  const msgs: ChatMsg[] = pending ? [...saved, pending] : saved
  const [q, setQ] = useState('')
  const [thinking, setThinking] = useState<'advice' | 'chat' | 'review' | 'adapt' | null>(null)
  const endRef = useRef<HTMLDivElement>(null)

  const seen = app.activities.filter(aiAllowed).length
  const series = formSeries(app.activities, app.today)
  const last = series[series.length - 1]
  const snap = snapOf(app)

  const hidden = hasHiddenActivities(app.activities)
  useEffect(() => { void cachedDailyAdvice(app.today).then(t => setAdvice(t ? sanitizeGaps(t, hidden) : null)) }, [app.today, hidden])
  // enkratna selitev starega lokalnega pogovora v sinhronizirane nastavitve
  useEffect(() => { if (app.settings.coach === undefined) void loadLegacyChat().then(async old => { await updateSettings({ coach: { msgs: old.slice(-40), summary: null } }); await clearLegacyChat() }) }, [app.settings.coach])
  useEffect(() => { endRef.current?.scrollIntoView({ block: 'nearest' }) }, [msgs.length, thinking])
  useEffect(() => { const t = setTimeout(() => endRef.current?.scrollIntoView({ block: 'end' }), 60); return () => clearTimeout(t) }, [])

  async function getAdvice(force = false) {
    setThinking('advice')
    const t = await ai.run(() => dailyAdvice(snap, force))
    setThinking(null)
    if (t) setAdvice(t)
  }
  async function send(text?: string) {
    const question = (text ?? q).trim()
    if (!question) return
    setQ('')
    setPending({ role: 'user', text: question, at: new Date().toISOString() })
    setThinking('chat')
    const next = await ai.run(() => chat(snap, question, { msgs: saved, summary: app.settings.coach?.summary ?? null }))
    setThinking(null)
    if (next) await updateSettings({ coach: next })
    setPending(null)
  }
  async function getReview() {
    setThinking('review')
    const t = await ai.run(() => weeklyReview(snap))
    setThinking(null)
    if (t) setReview(t)
  }
  async function adapt() {
    const ws = weekStartIso(app.today)
    const week = app.plan.filter(d => d.date >= ws && d.date <= addDays(ws, 6))
    if (!week.length) { toast('Ta teden še ni sestavljen — najprej ga sestavi v Planu.', 'info'); navigate('plan'); return }
    setThinking('adapt')
    const r = await ai.run(() => adaptWeek(snap, week))
    setThinking(null)
    if (r) { await savePlanDays(r.days); toast(r.summary, 'ok', 8000) }
  }

  return (<>
    <Head hi={`trener vidi ${seen} od ${app.activities.length} aktivnosti`} nm="Trener" />
    <div className="scroll">
      {!ai.signedIn && (
        <Card accent className="stagger" style={{ marginBottom: 12 }}>
          <div className="row" style={{ gap: 12 }}>
            <div style={{ width: 40, height: 40, borderRadius: 'var(--r-s)', background: 'var(--accent)', display: 'grid', placeItems: 'center', color: 'var(--accent-ink)', flex: 'none' }}><IcoChat /></div>
            <div><b style={{ fontSize: 15 }}>AI trener teče prek tvojega računa</b><div className="muted" style={{ fontSize: 12.5, fontWeight: 600 }}>Prijava z Googlom · {FREE_AI_PER_DAY} AI klicev na dan</div></div>
          </div>
          <Btn primary block sm style={{ marginTop: 12 }} onClick={() => getAdvice()}>Prijava z Googlom in prvi nasvet</Btn>
        </Card>
      )}
      <Card style={{ marginBottom: 12 }}>
        <div className="between"><h4>Pogovor</h4>{(msgs.length > 0 || app.settings.coach?.summary) && <button className="chip sm click" onClick={() => updateSettings({ coach: { msgs: [], summary: null } })}>nov pogovor</button>}</div>
        <div className="stack" style={{ gap: 8, marginTop: 10 }}>
          {msgs.length === 0 && <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>{quick(app.profile.event?.name).map(t => <Chip key={t} sm onClick={() => send(t)}>{t}</Chip>)}</div>}
          {msgs.map((m, i) => (
            <div key={i} style={{ alignSelf: m.role === 'user' ? 'flex-end' : 'flex-start', maxWidth: '88%', background: m.role === 'user' ? 'var(--accent-soft)' : 'var(--raised)', color: 'var(--ink)', borderRadius: 'var(--r-m)', padding: '10px 13px', fontSize: 13.5, lineHeight: 1.5, whiteSpace: 'pre-wrap' }} className="page">{m.role === 'ai' ? sanitizeGaps(m.text, hidden) : m.text}</div>
          ))}
          {thinking === 'chat' && <div className="thinking" style={{ padding: '6px 4px' }}><i /><i /><i /></div>}
          <div ref={endRef} />
        </div>
      </Card>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 12 }}>
        <Card tight style={{ cursor: 'pointer' }} className="hover" onClick={() => !ai.busy && adapt()}>
          <div className="row" style={{ gap: 8 }}><IcoCal width={18} height={18} style={{ color: 'var(--accent)' }} /><b style={{ fontSize: 13 }}>Prilagodi ta teden</b></div>
          <p style={{ fontSize: 12, marginTop: 6 }}>{thinking === 'adapt' ? 'Prilagajam …' : 'Po formi in opravljenem. Opravljeni dnevi ostanejo.'}</p>
        </Card>
        <Card tight style={{ cursor: 'pointer' }} className="hover" onClick={() => !ai.busy && getReview()}>
          <div className="row" style={{ gap: 8 }}><IcoChat width={18} height={18} style={{ color: 'var(--accent)' }} /><b style={{ fontSize: 13 }}>Pregled tedna</b></div>
          <p style={{ fontSize: 12, marginTop: 6 }}>{thinking === 'review' ? 'Pišem …' : 'Kaj je bilo dobro, kaj manjka, kaj naprej.'}</p>
        </Card>
      </div>
      {review && <Card className="page" style={{ marginBottom: 12 }}><h4>Pregled tedna</h4><p style={{ fontSize: 13.5, marginTop: 8, lineHeight: 1.55, color: 'var(--ink)', whiteSpace: 'pre-wrap' }}>{review}</p></Card>}

      {app.activities.length > 0 && seen < app.activities.length && (
        <div className="muted" style={{ fontSize: 12, padding: '4px 4px 14px' }}>{app.activities.length - seen} aktivnosti trener ne sme uporabiti (Stravin ali neznan izvor). Datoteke, Garmin prek intervals.icu, posnetki in ročni vnosi štejejo.</div>
      )}
      {!ai.consent && ai.signedIn && <div className="muted" style={{ fontSize: 12, padding: '4px 4px 14px' }}>Pred prvim nasvetom te vprašam za privolitev — kaj gre v AI in kaj ne.</div>}
      <Card style={{ marginBottom: 12 }}>
        <div className="between">
          <h4>Nasvet za danes</h4>
          {advice && <button className="chip sm click" onClick={() => getAdvice(true)} disabled={ai.busy}>osveži</button>}
        </div>
        {advice ? <p style={{ fontSize: 14, marginTop: 8, lineHeight: 1.55, color: 'var(--ink)' }}>{advice}</p>
          : thinking === 'advice' ? <div className="thinking" style={{ marginTop: 10 }}><i /><i /><i /></div>
          : <>
            <p style={{ fontSize: 13, marginTop: 6 }}>{last ? `Forma ${last.tsb > 0 ? '+' : ''}${Math.round(last.tsb)} (${formBand(last.tsb).band}). ` : ''}{seen ? 'Trener pogleda formo, zadnje vožnje in današnji plan, in pove, kaj narediti.' : 'Ko uvoziš prve vožnje, bodo nasveti konkretni. Vprašaš lahko že zdaj.'}</p>
            <Btn primary={ai.signedIn} ghost={!ai.signedIn} sm style={{ marginTop: 12 }} disabled={ai.busy} onClick={() => getAdvice()}>Kaj naj danes naredim?</Btn>
          </>}
      </Card>
      {/* vrstica za vprašanje: vedno na vidiku, tudi na telefonu */}
      <form className="composer row" style={{ gap: 8 }} onSubmit={e => { e.preventDefault(); void send() }}>
        <input className="field" value={q} onChange={e => setQ(e.target.value)} placeholder="Vprašaj trenerja …" enterKeyHint="send" style={{ flex: 1, background: 'var(--card)', border: '1px solid var(--line)', borderRadius: 'var(--r-full)', padding: '11px 14px', color: 'var(--ink)', fontSize: 15 }} />
        <Btn sm type="submit" disabled={ai.busy || !q.trim()}>Pošlji</Btn>
      </form>
    </div>
    {ai.sheet}
  </>)
}
