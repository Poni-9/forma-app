import { useState } from 'react'
import { Head } from '@/app/Shell'
import { navigate } from '@/app/router'
import { useApp, getState, updateProfile, updateSettings, toast, signIn, signOut, grantAiConsent, revokeAiConsent, checkPro, saveCheckin, refreshWeather, setStrength } from '@/state/store'
import { exportAll, wipeAll } from '@/data/repo'
import { deleteAccount } from '@/data/firebase'
import { syncNow } from '@/data/sync'
import { geocode, askLocation } from '@/domain/weather'
import { MAX_DEFICIT, bmr, tdee, dailyTarget, isMinor } from '@/domain/nutrition/energy'
import { weekContext, macroWeeks } from '@/domain/training/planner'
import { GoalCard } from '@/ui/GoalCard'
import { weekStartIso, todayIso, addDays } from '@/domain/training/load'
import { Card, Chip, Btn } from '@/ui/primitives'
import { FUEL_ITEMS, DEFAULT_KIT } from '@/domain/nutrition/dayplan'
import { FREE_AI_PER_DAY } from '@/config'


const num = (v: string) => (v === '' ? null : +String(v).replace(',', '.'))

/* ---------- Nastavitve ---------- */
export function Nastavitve() {
  const app = useApp()
  const p = app.profile
  const [f, setF] = useState({ name: p.name || '', age: p.age ?? '', sex: p.sex || '', height: p.heightCm ?? '', weight: p.weightKg ?? '', maxHr: p.maxHr ?? '', restHr: p.restHr ?? '', lthr: p.lthr ?? '', ftp: p.ftp ?? '', hours: p.hoursPerWeek ?? '', bf: p.bodyFatPct ?? '' })
  const [g, setG] = useState({ kcal: p.kcalOverride ?? '', dkg: p.gear.dumbbellKg ?? '' })
  const [place, setPlace] = useState(p.place?.name || '')
  const [busy, setBusy] = useState(false)
  const b = bmr(p), maint = tdee(p), tgt = dailyTarget(p, [], [], app.today)
  const cx = weekContext(p, weekStartIso(app.today))

  async function saveProfile() {
    const w = num(String(f.weight))
    await updateProfile({ name: f.name || undefined, age: num(String(f.age)), sex: (f.sex as 'm' | 'z' | '') || null, heightCm: num(String(f.height)), weightKg: w, maxHr: num(String(f.maxHr)), restHr: num(String(f.restHr)), lthr: num(String(f.lthr)), ftp: num(String(f.ftp)), ftpDate: num(String(f.ftp)) !== p.ftp ? todayIso() : p.ftpDate, hoursPerWeek: num(String(f.hours)), bodyFatPct: num(String(f.bf)) })
    if (w && w !== p.weightKg) { const prev = app.checkins.find(c => c.date === app.today); await saveCheckin({ ...(prev || { date: app.today }), date: app.today, weightKg: w }) }
    toast('Profil shranjen.', 'ok')
  }
  async function saveKcal() {
    await updateProfile({ kcalOverride: num(String(g.kcal)) })
    toast('Shranjeno.', 'ok')
  }
  async function savePlace() {
    if (!place.trim()) { await updateProfile({ place: null }); return }
    setBusy(true)
    try { const r = await geocode(place.trim()); if (!r) { toast('Kraja ne najdem.', 'err'); return } await updateProfile({ place: r }); setPlace(r.name); toast('Vreme: ' + r.name, 'ok') }
    catch { toast('Vreme ni dosegljivo.', 'err') } finally { setBusy(false) }
  }
  async function useLocation() {
    const loc = await askLocation()
    if (!loc) { toast('Lokacija ni na voljo.', 'err'); return }
    await updateProfile({ place: { name: 'moja lokacija', ...loc } }); setPlace('moja lokacija'); toast('Vreme nastavljeno.', 'ok')
  }
  // konec osnove (zadnji teden faze) — za »samo v osnovi (do …)«
  const baseLast = [...macroWeeks(p, app.today)].reverse().find(w => w.phase === 'osnova')
  const baseEnd = baseLast ? (() => { const d = addDays(baseLast.weekStart, 6); return `${+d.slice(8)}. ${+d.slice(5, 7)}.` })() : null
  const syncLabel = app.sync.state === 'off' ? 'brez sinhronizacije' : app.sync.state === 'push' ? 'pošiljam …' : app.sync.state === 'pull' ? 'usklajujem …' : app.sync.state === 'error' ? `napaka: ${app.sync.msg || ''}` : app.sync.at ? `usklajeno ${new Date(app.sync.at).toLocaleTimeString('sl-SI', { hour: '2-digit', minute: '2-digit' })}` : 'usklajeno'
  const ACCENTS = [['#A3E635', 'Limeta'], ['#84CC16', 'Trava'], ['#4ADE80', 'Pomlad'], ['#2DD4BF', 'Turkiz']] as const

  return (<>
    <Head hi="Profil, cilji, podatki" nm="Nastavitve" />
    <div className="scroll">

      {/* račun */}
      <Card style={{ marginBottom: 12 }}>
        <h4>Račun in AI</h4>
        {app.user ? (<>
          <div className="row" style={{ gap: 12, marginTop: 10 }}>
            {app.user.photo ? <img src={app.user.photo} alt="" width={40} height={40} style={{ borderRadius: 999 }} referrerPolicy="no-referrer" /> : <div className="avatar">{(app.user.name || app.user.email || '?').slice(0, 2).toUpperCase()}</div>}
            <div style={{ flex: 1, minWidth: 0 }}><b style={{ fontSize: 14 }}>{app.user.name || 'Google račun'}</b><div className="muted" style={{ fontSize: 12, overflow: 'hidden', textOverflow: 'ellipsis' }}>{app.user.email}</div></div>
            <Chip sm on={app.pro}>{app.pro ? 'AI brez omejitve' : `AI ${FREE_AI_PER_DAY}/dan`}</Chip>
          </div>
          <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
            <span className={`chip sm ${app.sync.state === 'push' || app.sync.state === 'pull' ? 'syncing' : ''}`}><span className="dot" style={{ background: app.sync.state === 'error' ? 'var(--bad)' : 'var(--ok)' }} />{syncLabel}</span>
            <button className="chip sm click" onClick={() => syncNow().then(ch => toast(getState().sync.state === 'error' ? (getState().sync.msg || 'Usklajevanje ni uspelo.') : ch ? 'Usklajeno — dodano, kar je bilo na drugi napravi.' : 'Usklajeno.', getState().sync.state === 'error' ? 'err' : 'ok'))}>uskladi zdaj</button>
            <span className="muted" style={{ fontSize: 11 }}>v3.20 · hitrejši preklop zaslonov</span>
          </div>
          {!app.pro && <p style={{ fontSize: 12, marginTop: 10 }}>Za AI brez dnevne omejitve: Firebase konzola → projekt c-vaje → Firestore → zbirka <b>proUsers</b> → dokument <b style={{ userSelect: 'all' }}>{app.user.uid}</b> → polje <b>pro</b> = true.</p>}
          <div className="row" style={{ gap: 8, marginTop: 10 }}>
            <Btn ghost sm onClick={signOut}>Odjava</Btn>
            <Btn ghost sm onClick={() => { void navigator.clipboard?.writeText(app.user!.uid).then(() => toast('UID kopiran.', 'ok')) }}>Kopiraj UID</Btn>
            <Btn ghost sm onClick={() => checkPro().then(ok => toast(ok ? 'AI brez omejitve je vklopljen.' : 'Še ni vklopljen.', ok ? 'ok' : 'info'))}>Preveri</Btn>
          </div>
        </>) : (<>
          <p style={{ fontSize: 13, marginTop: 6 }}>Prijava vklopi AI trenerja, slikanje obrokov in sinhronizacijo telefon ↔ računalnik. Sledi in slike ostanejo na napravi.</p>
          <Btn primary block sm style={{ marginTop: 12 }} disabled={busy} onClick={async () => { setBusy(true); try { await signIn() } catch (e) { toast((e as Error).message, 'err') } finally { setBusy(false) } }}>Prijava z Googlom</Btn>
        </>)}
        <div className="between" style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid var(--line)' }}>
          <span style={{ fontSize: 13, fontWeight: 700 }}>AI obdelava</span>
          <Chip sm on={!!p.aiConsentAt} onClick={() => p.aiConsentAt ? revokeAiConsent() : grantAiConsent().then(() => toast('AI vklopljena.', 'ok'))}>{p.aiConsentAt ? 'vklopljena' : 'izklopljena'}</Chip>
        </div>
        <p style={{ fontSize: 12, marginTop: 6 }}>V AI gredo spol, starost, teža, utrip, FTP, aktivnosti (brez GPS in imen), prehranski cilj in fotografija obroka. Nikoli ime, e-pošta, kraj ali Stravine vožnje.</p>
      </Card>

      {/* profil */}
      <Card style={{ marginBottom: 12 }}>
        <h4>Profil</h4>
        <div className="stack" style={{ gap: 10, marginTop: 10 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <div className="field"><label>Ime</label><input value={f.name} onChange={e => setF({ ...f, name: e.target.value })} /></div>
            <div className="field"><label>Spol</label><select value={f.sex} onChange={e => setF({ ...f, sex: e.target.value })}><option value="">—</option><option value="m">Moški</option><option value="z">Ženska</option></select></div>
            <div className="field"><label>Starost</label><input type="number" inputMode="numeric" value={f.age} onChange={e => setF({ ...f, age: e.target.value })} /></div>
            <div className="field"><label>Višina <span className="unit">cm</span></label><input type="number" inputMode="numeric" value={f.height} onChange={e => setF({ ...f, height: e.target.value })} /></div>
            <div className="field"><label>Teža <span className="unit">kg</span></label><input type="number" inputMode="decimal" step={0.1} value={f.weight} onChange={e => setF({ ...f, weight: e.target.value })} /></div>
            <div className="field"><label>Ure na kolesu <span className="unit">normalen teden</span></label><input type="number" inputMode="decimal" step={0.5} value={f.hours} onChange={e => setF({ ...f, hours: e.target.value })} /></div>
            <div className="field"><label>Max utrip</label><input type="number" inputMode="numeric" value={f.maxHr} onChange={e => setF({ ...f, maxHr: e.target.value })} /></div>
            <div className="field"><label>Mirovni utrip</label><input type="number" inputMode="numeric" value={f.restHr} onChange={e => setF({ ...f, restHr: e.target.value })} /></div>
            <div className="field"><label>Pražni utrip (LTHR)</label><input type="number" inputMode="numeric" value={f.lthr} onChange={e => setF({ ...f, lthr: e.target.value })} placeholder="iz intervals.icu" /></div>
            <div className="field"><label>FTP <span className="unit">W</span></label><input type="number" inputMode="numeric" value={f.ftp} onChange={e => setF({ ...f, ftp: e.target.value })} /></div>
            <div className="field"><label>Maščoba <span className="unit">%, če veš</span></label><input type="number" inputMode="decimal" step={0.5} value={f.bf} onChange={e => setF({ ...f, bf: e.target.value })} placeholder="ocena iz BMI" /></div>
          </div>
          <Btn block sm onClick={saveProfile}>Shrani profil</Btn>
        </div>
      </Card>

      {/* cilj sezone */}
      <div style={{ marginBottom: 12 }}><GoalCard full /></div>

      {/* prehrana */}
      <Card style={{ marginBottom: 12 }}>
        <h4>Prehrana</h4>
        <div className="field" style={{ marginTop: 10 }}><label>Deficit na dan <span className="unit">samo izven kolesa, do ciljne teže</span></label>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>{([[0, 'brez'], [300, '300 · počasi'], [400, '400'], [500, '500 · zmerno'], [MAX_DEFICIT, `${MAX_DEFICIT} · največ`]] as const).map(([v, l]) => <Chip key={v} sm on={(p.deficit ?? 0) === v} onClick={() => updateProfile({ deficit: v })}>{l}</Chip>)}</div>
          <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>Na ključne dni in ob dolgi vožnji pol, v specifični fazi pol, v taperingu nič. Na ciljni teži se deficit ustavi.</div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 10, marginTop: 10, alignItems: 'end' }}>
          <div className="field"><label>Ročni cilj <span className="unit">kcal, prazno = izračun</span></label><input type="number" inputMode="numeric" value={g.kcal} onChange={e => setG({ ...g, kcal: e.target.value })} /></div>
          <Btn sm onClick={saveKcal}>Shrani</Btn>
        </div>
        <div className="field" style={{ marginTop: 10 }}><label>Kdaj običajno treniraš <span className="unit">razpored obrokov</span></label>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>{([['zjutraj', 'zjutraj'], ['popoldne', 'popoldne'], ['zvecer', 'zvečer']] as const).map(([v, l]) => <Chip key={v} sm on={(p.trainTime || 'popoldne') === v} onClick={() => updateProfile({ trainTime: v })}>{l}</Chip>)}</div>
        </div>
        <div className="field" style={{ marginTop: 10 }}><label>Gibanje izven treninga</label>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>{([[1.3, 'sedeče'], [1.4, 'zmerno'], [1.5, 'veliko hoje']] as const).map(([v, l]) => <Chip key={v} sm on={p.neat === v} onClick={() => updateProfile({ neat: v })}>{l}</Chip>)}</div>
        </div>
        <div className="field" style={{ marginTop: 10 }}><label>Beljakovine na kg</label>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>{([[1.6, '1,6 g'], [1.8, '1,8 g'], [2.0, '2,0 g'], [2.2, '2,2 g']] as const).map(([v, l]) => <Chip key={v} sm on={p.proteinGkg === v} onClick={() => updateProfile({ proteinGkg: v })}>{l}</Chip>)}</div>
        </div>
        <div className="field" style={{ marginTop: 12 }}><label>Kaj imaš za na kolo</label>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>{FUEL_ITEMS.map(it => { const kit = p.fuelKit && p.fuelKit.length ? p.fuelKit : DEFAULT_KIT; const on = kit.includes(it.key); return <Chip key={it.key} sm on={on} onClick={() => updateProfile({ fuelKit: on ? kit.filter(k => k !== it.key) : [...kit, it.key] })}>{it.label}</Chip> })}</div>
          <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>Gorivo za vožnjo sestavim iz tega, kar označiš: dolge vožnje dobijo pravo hrano, intervali gele, lahke vožnje banane in Frutabele. Količine so v gramih OH na kos (Frutabela 30 g ≈ 19 g OH, gel ≈ 25 g, banana ≈ 25 g, bidon izotonika ≈ 40–45 g).</div>
        </div>
        <p style={{ fontSize: 12.5, marginTop: 10 }}>
          {b && maint && tgt ? <>Bazalna poraba {b} kcal · vzdrževanje {maint} kcal · cilj na dan brez treninga <b style={{ color: 'var(--ink)' }}>{tgt.kcal} kcal</b>, beljakovine {tgt.proteinG} g. Trening doda svojo porabo. Cilj nikoli ne pade pod bazalno porabo in {p.sex === 'z' ? '1200' : '1500'} kcal{isMinor(p) ? '; do 18. leta brez deficita' : ''}.</> : 'Za izračun izpolni starost, spol, višino in težo.'}
        </p>
      </Card>

      {/* oprema in moč */}
      <Card style={{ marginBottom: 12 }}>
        <h4>Oprema in moč</h4>
        <div className="row" style={{ gap: 7, flexWrap: 'wrap', marginTop: 10 }}>
          <Chip sm on={p.gear.bikeOutdoor} onClick={() => updateProfile({ gear: { ...p.gear, bikeOutdoor: !p.gear.bikeOutdoor, noBike: false } })}>Kolo zunaj</Chip>
          <Chip sm on={p.gear.trainer} onClick={() => updateProfile({ gear: { ...p.gear, trainer: !p.gear.trainer, noBike: false } })}>Trenažer</Chip>
          <Chip sm on={p.gear.powerMeter === true} onClick={() => updateProfile({ gear: { ...p.gear, powerMeter: p.gear.powerMeter === true ? false : true, powerMeterAuto: false } })}>Merilnik moči</Chip>
          <Chip sm on={!!p.gear.dumbbells} onClick={() => updateProfile({ gear: { ...p.gear, dumbbells: !p.gear.dumbbells } })}>Uteži</Chip>
        </div>
        {p.gear.dumbbells && <div className="field" style={{ marginTop: 10 }}><label>Teža uteži <span className="unit">kg</span></label><input type="number" inputMode="decimal" value={g.dkg} onChange={e => setG({ ...g, dkg: e.target.value })} onBlur={() => updateProfile({ gear: { ...p.gear, dumbbellKg: num(String(g.dkg)) } })} /></div>}
        <div className="field" style={{ marginTop: 12 }}><label>Moč na teden</label>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>{([[0, 'brez'], [1, '1×'], [2, '2×']] as const).map(([v, l]) => <Chip key={v} sm on={(p.strength.on ? Math.min(2, p.strengthDays ?? 2) : 0) === v} onClick={() => setStrength({ on: v > 0 }, v)}>{l}</Chip>)}</div>
        </div>
        {p.strength.on && (<>
          <div className="field" style={{ marginTop: 10 }}><label>Kje</label>
            <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>
              <Chip sm on={p.strength.equipment !== 'gym'} onClick={() => setStrength({ equipment: 'home' })}>doma</Chip>
              <Chip sm on={p.strength.equipment === 'gym'} onClick={() => setStrength({ equipment: 'gym' })}>fitnes</Chip>
            </div>
          </div>
          <div className="field" style={{ marginTop: 10 }}><label>Kdaj</label>
            <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>
              <Chip sm on={!p.strength.phases?.length} onClick={() => setStrength({ phases: null })}>vso sezono</Chip>
              <Chip sm on={!!p.strength.phases?.length && p.strength.phases.length === 1 && p.strength.phases[0] === 'osnova'} onClick={() => setStrength({ phases: ['osnova'] })}>samo v osnovi{baseEnd ? ` (do ${baseEnd})` : ''}</Chip>
            </div>
          </div>
        </>)}
        <p style={{ fontSize: 12.5, marginTop: 8 }}>{p.strength.equipment === 'gym'
          ? 'Fitnes: torek noge težko (polovični počep, nožna preša na eni nogi, romunski mrtvi dvig …), petek enonožne vaje + hrbet in jedro, ~50 min. Kilograme vpiši — naslednja seja jih prevzame.'
          : 'Moč doma: jedro (torek, po VO2max) in noge + jedro (petek), 20–30 min. Ko opraviš sejo, naslednja dvigne ponovitve. Uteži dodajo težo bolgarskim počepom.'} Jedro po želji dodaš kadarkoli v Planu (»+ jedro po želji« pri dnevu).</p>
      </Card>

      {/* cikel brez dogodka */}
      {!p.event && (
        <Card style={{ marginBottom: 12 }}>
          <h4>Cikel brez dirke</h4>
          <p style={{ fontSize: 13, marginTop: 6 }}>{cx.structured ? <>Zdaj: <b style={{ color: 'var(--ink)' }}>{cx.phaseName}</b>, teden {cx.week}/{cx.total}{cx.recovery ? ' (razbremenilni)' : ''}. {cx.phaseDesc}</> : 'Osnova 4 tedne → gradnja 4 → specifično 4, vsak 4. teden razbremenilni. Z dirko (Cilj sezone) postane makrocikel do nje.'}</p>
          <div className="row" style={{ gap: 8, marginTop: 10 }}>
            <Btn ghost sm onClick={() => updateProfile({ cycleStart: weekStartIso(app.today) }).then(() => toast('Cikel začet ta ponedeljek. Sestavi teden znova v Planu.', 'ok', 6000))}>{p.cycleStart ? 'Začni znova ta teden' : 'Začni ta teden'}</Btn>
            {p.cycleStart && <Btn ghost sm onClick={() => updateProfile({ cycleStart: null })}>Prekini</Btn>}
          </div>
        </Card>
      )}

      {/* vreme */}
      <Card style={{ marginBottom: 12 }}>
        <h4>Vreme za načrt</h4>
        <p style={{ fontSize: 12.5, marginTop: 6 }}>Dolga vožnja gre na najbolj suh dan; ob dežju opozorilo na Danes. Kraj ne gre v AI.</p>
        <div className="row" style={{ gap: 8, marginTop: 10 }}>
          <input className="field" value={place} onChange={e => setPlace(e.target.value)} placeholder="kraj, npr. Vodice" style={{ flex: 1, background: 'var(--card)', border: '1px solid var(--line)', borderRadius: 'var(--r-s)', padding: '11px 13px', color: 'var(--ink)', outline: 'none' }} />
          <Btn sm disabled={busy} onClick={savePlace}>Shrani</Btn>
        </div>
        <div className="row" style={{ gap: 8, marginTop: 8 }}>
          <Btn ghost sm onClick={useLocation}>Lokacija naprave</Btn>
          {p.place && <Btn ghost sm onClick={() => refreshWeather(true).then(w => toast(w ? 'Vreme osveženo.' : 'Vreme ni dosegljivo.', w ? 'ok' : 'err'))}>Osveži</Btn>}
        </div>
      </Card>

      {/* povezave */}
      <Card style={{ marginBottom: 12 }}>
        <h4>Ura in uvoz</h4>
        <p style={{ fontSize: 13, marginTop: 6 }}>intervals.icu: {app.settings.intervals ? <b style={{ color: 'var(--ink)' }}>{app.settings.intervals.name || app.settings.intervals.athleteId}</b> : 'ni povezan'}</p>
        <div className="row" style={{ gap: 8, marginTop: 10 }}><Btn ghost sm onClick={() => navigate('uvoz')}>Uredi uvoz</Btn>{app.settings.intervals && <Btn ghost sm onClick={() => { void updateSettings({ intervals: null }); toast('intervals.icu odklopljen.', 'info') }}>Odklopi</Btn>}</div>
      </Card>

      <Card style={{ marginBottom: 12 }}>
        <h4>Odtenek zelene</h4>
        <div className="row" style={{ gap: 9, marginTop: 10 }}>{ACCENTS.map(([hex, name]) => <button key={hex} title={name} aria-label={name} onClick={() => updateSettings({ accentHex: hex })} style={{ width: 32, height: 32, borderRadius: 999, border: 0, background: hex, outline: app.settings.accentHex === hex ? '2px solid var(--ink-2)' : '2px solid transparent', outlineOffset: 3, cursor: 'pointer' }} />)}</div>
      </Card>

      <Card style={{ marginBottom: 12 }}>
        <h4>Podatki</h4>
        <p style={{ fontSize: 13, marginTop: 6 }}>Vse je na tej napravi (IndexedDB), s prijavo tudi v oblaku — brez sledi in slik. Izvoz je popoln (JSON).</p>
        <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
          <Btn ghost sm onClick={async () => { const d = await exportAll(); const bl = new Blob([JSON.stringify(d, null, 1)], { type: 'application/json' }); const a = document.createElement('a'); a.href = URL.createObjectURL(bl); a.download = `formai-izvoz-${app.today}.json`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000) }}>Izvozi vse</Btn>
          <Btn ghost sm onClick={async () => { if (confirm('Izbrišem VSE podatke na tej napravi? Tega ni mogoče razveljaviti.')) { await wipeAll(); location.hash = '#/uvod'; location.reload() } }}>Izbriši na napravi</Btn>
          {app.user && <Btn ghost sm onClick={async () => {
            if (!confirm('Izbrišem račun in podatke v oblaku? Lokalni podatki ostanejo, dokler jih ne izbrišeš posebej.')) return
            const r = await deleteAccount()
            if (r.ok) { toast('Račun in podatki v oblaku izbrisani.', 'ok'); await signOut() }
            else if (r.reauth) toast('Google zahteva svežo prijavo. Odjavi se, prijavi znova in ponovi izbris.', 'err', 8000)
            else toast('Izbris ni uspel.', 'err', 8000)
          }}>Izbriši račun</Btn>}
        </div>
      </Card>
      <div className="muted" style={{ fontSize: 11.5, padding: '0 4px 16px' }}>FORMAI je osebno orodje, ne medicinski nasvet. Ob bolezni, poškodbi ali bolečini v prsih prekini in poišči zdravnika.</div>
    </div>
  </>)
}
