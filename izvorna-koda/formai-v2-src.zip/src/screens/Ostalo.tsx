import { useEffect, useState } from 'react'
import { Head } from '@/app/Shell'
import { navigate } from '@/app/router'
import { useApp, getState, updateProfile, updateSettings, toast, signIn, signOut, grantAiConsent, revokeAiConsent, saveCheckin, refreshWeather, setStrength, setWellnessOn, removeWorkouts, deleteAccountAll } from '@/state/store'
import { exportAll, wipeAll } from '@/data/repo'
import { syncNow } from '@/data/sync'
import { geocode, askLocation } from '@/domain/weather'
import { MAX_DEFICIT, bmr, tdee, dailyTarget, isMinor } from '@/domain/nutrition/energy'
import { weekContext, macroWeeks } from '@/domain/training/planner'
import type { Profile } from '@/domain/types'
import { GoalCard } from '@/ui/GoalCard'
import { weekStartIso, todayIso, addDays } from '@/domain/training/load'
import { Card, Chip, Btn, fmtKcal } from '@/ui/primitives'
import { FUEL_ITEMS, DEFAULT_KIT } from '@/domain/nutrition/dayplan'
import { FREE_AI_PER_DAY, APP_VERSION } from '@/config'
import { forgetApp } from '@/app/landing'
import { fmtSleep } from '@/domain/wellness'
import { disconnectApp } from '@/domain/intervals/client'
import { HealthNote } from '@/ui/HealthNote'
import { useConfirm } from '@/ui/Confirm'
import { count, dm, nb, plural, NBSP, W } from '@/ui/format'

const num = (v: string) => (v.trim() === '' ? null : +v.replace(',', '.'))
const str = (v: number | string | null | undefined) => (v == null ? '' : String(v))
/** Obrazec profila kot besedilo (tako kot ga ureja uporabnik). */
export const formOf = (p: Profile) => ({ name: p.name || '', age: str(p.age), sex: p.sex || '', height: str(p.heightCm), weight: str(p.weightKg), maxHr: str(p.maxHr), restHr: str(p.restHr), lthr: str(p.lthr), ftp: str(p.ftp), hours: str(p.hoursPerWeek), bf: str(p.bodyFatPct) })
type Form = ReturnType<typeof formOf>
/** Samo polja, ki jih je uporabnik spremenil (glede na obrazec ob odprtju) — ostala ostanejo, kot so v profilu. */
export function profilePatch(init: Form, f: Form, p: Pick<Profile, 'ftpDate'>): Partial<Profile> {
  const ch = (k: keyof Form) => f[k] !== init[k]
  const patch: Partial<Profile> = {}
  if (ch('name')) patch.name = f.name.trim() || undefined
  if (ch('age')) patch.age = num(f.age)
  if (ch('sex')) patch.sex = (f.sex as 'm' | 'z' | '') || null
  if (ch('height')) patch.heightCm = num(f.height)
  if (ch('weight')) patch.weightKg = num(f.weight)
  if (ch('maxHr')) patch.maxHr = num(f.maxHr)
  if (ch('restHr')) patch.restHr = num(f.restHr)
  if (ch('lthr')) patch.lthr = num(f.lthr)
  if (ch('ftp')) { patch.ftp = num(f.ftp); patch.ftpDate = patch.ftp ? todayIso() : p.ftpDate ?? null }
  if (ch('hours')) patch.hoursPerWeek = num(f.hours)
  if (ch('bf')) patch.bodyFatPct = num(f.bf)
  return patch
}

/* ---------- Nastavitve ---------- */
export function Nastavitve() {
  const app = useApp()
  const p = app.profile
  const { confirm, sheet: confirmSheet } = useConfirm()
  // shranimo samo polja, ki jih je uporabnik spremenil — ostalo (npr. FTP z druge naprave) ostane, kot je
  const [init, setInit] = useState<Form>(() => formOf(p))
  const [f, setF] = useState<Form>(init)
  useEffect(() => {
    const next = formOf(p)
    setF(cur => { const o = { ...cur }; for (const k of Object.keys(next) as (keyof Form)[]) if (cur[k] === init[k]) o[k] = next[k]; return o })
    setInit(next)
  }, [p])   // eslint-disable-line react-hooks/exhaustive-deps
  const [g, setG] = useState({ kcal: str(p.kcalOverride), dkg: str(p.gear.dumbbellKg) })
  const [place, setPlace] = useState(p.place?.name || '')
  const [busy, setBusy] = useState(false)
  const b = bmr(p), maint = tdee(p), tgt = dailyTarget(p, [], [], app.today)
  const cx = weekContext(p, weekStartIso(app.today))
  const dirty = (Object.keys(f) as (keyof Form)[]).some(k => f[k] !== init[k])

  async function saveProfile() {
    const patch = profilePatch(init, f, p)
    if (!Object.keys(patch).length) { toast('Ni sprememb.', 'info'); return }
    await updateProfile(patch)
    const w = patch.weightKg
    if (w) { const s = getState(), prev = s.checkins.find(c => c.date === s.today); await saveCheckin({ ...(prev || { date: s.today }), date: s.today, weightKg: w }) }
    const nf = formOf(getState().profile)   // »72,5« → »72.5«: obrazec ni več »spremenjen«
    setInit(nf); setF(nf)
    toast('Profil shranjen.', 'ok')
  }
  async function saveKcal() {
    await updateProfile({ kcalOverride: num(g.kcal) })
    toast('Shranjeno.', 'ok')
  }
  async function savePlace() {
    if (!place.trim()) { await updateProfile({ place: null }); return }
    setBusy(true)
    try { const r = await geocode(place.trim()); if (!r) { toast('Kraja ne najdem.', 'err'); return } await updateProfile({ place: r }); setPlace(r.name); toast('Vreme: ' + r.name, 'ok') }
    catch { toast('Vreme ni dosegljivo.', 'err') } finally { setBusy(false) }
  }
  async function useLocation() {
    const loc = await askLocation()
    if (!loc) { toast('Lokacija ni na voljo.', 'err'); return }
    await updateProfile({ place: { name: 'moja lokacija', ...loc } }); setPlace('moja lokacija'); toast('Vreme nastavljeno.', 'ok')
  }
  /** Odklop: najprej naši treningi iz koledarja intervals.icu (da jih Garmin umakne z ure), šele nato povezava. */
  async function disconnectIcu() {
    const c = getState().settings.intervals
    if (!c) return
    if (!(await confirm({ title: 'Odklopim intervals.icu?', text: 'Najprej iz koledarja intervals.icu pobrišem treninge FORMAI (Garmin jih nato umakne z ure). Vožnje, ki so že tu, ostanejo; spanec in HRV z ure se s te naprave izbrišeta.', ok: 'Odklopi' }))) return
    setBusy(true)
    try {
      const n = await removeWorkouts()
      if (n == null && !(await confirm({ title: 'Treningov iz koledarja nisem mogel pobrisati', text: 'Povezava morda ne dela več. Če odklopiš zdaj, jih pobriši v koledarju intervals.icu sam.', ok: 'Odklopi vseeno', danger: true }))) return
      if (c.token) await disconnectApp(c).catch(() => undefined)
      await updateSettings({ intervals: null })
      if (getState().settings.wellnessOn) await setWellnessOn(false)
      toast(n ? `intervals.icu odklopljen. Iz koledarja pobrisano: ${count(n, W.trening)}.` : 'intervals.icu odklopljen.', 'info', 6000)
    } finally { setBusy(false) }
  }
  async function restartCycle() {
    if (p.cycleStart && !(await confirm({ title: 'Začnem cikel znova ta teden?', text: 'Cikel (osnova → gradnja → specifično) se začne ta ponedeljek od začetka. Teden potem sestavi znova v Planu.', ok: 'Začni znova' }))) return
    await updateProfile({ cycleStart: weekStartIso(app.today) })
    toast('Cikel začet ta ponedeljek. Sestavi teden znova v Planu.', 'ok', 6000)
  }
  async function stopCycle() {
    if (!(await confirm({ title: 'Prekinem cikel?', text: 'Načrt ne bo več sledil fazam cikla, dokler ga ne začneš znova ali ne nastaviš dirke.', ok: 'Prekini cikel' }))) return
    await updateProfile({ cycleStart: null })
    toast('Cikel prekinjen.', 'info')
  }
  async function wipeDevice() {
    if (!(await confirm({ title: 'Izbrišem vse podatke na tej napravi?', text: 'Tega ni mogoče razveljaviti.', ok: 'Izbriši vse', danger: true }))) return
    await wipeAll(); forgetApp(); location.hash = '#/uvod'; location.reload()
  }
  async function deleteAcc() {
    if (!(await confirm({ title: 'Izbrišem račun in vse podatke?', text: 'Izbrišejo se račun, podatki v oblaku in podatki na tej napravi, treningi FORMAI pa iz koledarja intervals.icu. Tega ni mogoče razveljaviti.', ok: 'Izbriši račun', danger: true }))) return
    const r = await deleteAccountAll()
    if (r.ok) { forgetApp(); location.hash = '#/uvod'; location.reload() }
    else if (r.reauth) toast('Google zahteva svežo prijavo — prijavi se znova in ponovi izbris.', 'err', 8000)
    else toast(r.error || 'Izbris ni uspel.', 'err', 8000)
  }
  // konec osnove (zadnji teden faze) — za »samo v osnovi (do …)«
  const baseLast = [...macroWeeks(p, app.today)].reverse().find(w => w.phase === 'osnova')
  const baseEnd = baseLast ? dm(addDays(baseLast.weekStart, 6)) : null
  const syncLabel = app.sync.state === 'off' ? 'brez sinhronizacije' : app.sync.state === 'push' ? 'pošiljam …' : app.sync.state === 'pull' ? 'usklajujem …' : app.sync.state === 'error' ? `napaka: ${app.sync.msg || ''}` : app.sync.at ? `usklajeno ${new Date(app.sync.at).toLocaleTimeString('sl-SI', { hour: '2-digit', minute: '2-digit' })}` : 'usklajeno'
  const ACCENTS = [['#A3E635', 'Limeta'], ['#84CC16', 'Trava'], ['#4ADE80', 'Pomlad'], ['#2DD4BF', 'Turkiz']] as const
  const setField = (k: keyof Form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value })

  return (<>
    <Head hi="Profil, cilji, podatki" nm="Nastavitve" />
    <div className="scroll">

      {/* račun */}
      <Card style={{ marginBottom: 12 }}>
        <h2 className="h4">Račun in AI</h2>
        {app.user ? (<>
          <div className="row" style={{ gap: 12, marginTop: 10 }}>
            {app.user.photo ? <img src={app.user.photo} alt="" width={40} height={40} style={{ borderRadius: 999, flex: 'none' }} referrerPolicy="no-referrer" /> : <div className="avatar">{(app.user.name || app.user.email || '?').slice(0, 2).toUpperCase()}</div>}
            <div style={{ flex: 1, minWidth: 0 }}><b style={{ fontSize: 14 }}>{app.user.name || 'Google račun'}</b><div className="muted" style={{ fontSize: 12, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{app.user.email}</div></div>
          </div>
          <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
            <span className={`chip sm ${app.sync.state === 'push' || app.sync.state === 'pull' ? 'syncing' : ''}`}><span className="dot" style={{ background: app.sync.state === 'error' ? 'var(--bad)' : 'var(--ok)' }} />{syncLabel}</span>
            <button className="chip sm click" onClick={() => syncNow().then(ch => toast(getState().sync.state === 'error' ? (getState().sync.msg || 'Usklajevanje ni uspelo.') : ch ? 'Usklajeno — dodano, kar je bilo na drugi napravi.' : 'Usklajeno.', getState().sync.state === 'error' ? 'err' : 'ok'))}>uskladi zdaj</button>
            <Chip sm on={app.pro || !FREE_AI_PER_DAY}>{app.pro || !FREE_AI_PER_DAY ? 'AI brez omejitve' : `Dnevno do ${FREE_AI_PER_DAY} AI ${plural(FREE_AI_PER_DAY, W.dejanjeR)}`}</Chip>
          </div>
          <div className="row" style={{ gap: 8, marginTop: 12 }}>
            <Btn ghost sm onClick={signOut}>Odjava</Btn>
          </div>
        </>) : (<>
          <p style={{ fontSize: 13, marginTop: 6 }}>Prijava vklopi AI trenerja, slikanje obrokov in sinhronizacijo telefon ↔ računalnik. Sledi in slike ostanejo na napravi.</p>
          <Btn primary block sm style={{ marginTop: 12 }} disabled={busy} onClick={async () => { setBusy(true); try { await signIn() } catch (e) { toast((e as Error).message, 'err') } finally { setBusy(false) } }}>Prijava z Googlom</Btn>
        </>)}
        <div className="between" style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid var(--line)' }}>
          <span style={{ fontSize: 13, fontWeight: 700 }}>AI obdelava</span>
          <Chip sm on={!!p.aiConsentAt} onClick={() => p.aiConsentAt ? revokeAiConsent() : grantAiConsent().then(() => toast('AI vklopljena.', 'ok'))}>{p.aiConsentAt ? 'vklopljena' : 'izklopljena'}</Chip>
        </div>
        <p style={{ fontSize: 12, marginTop: 6 }}>V AI gredo številke profila (starost, spol, višina, teža, FTP, utrip), povzetek treningov, jutranji vnosi, tvoja vprašanja in slike obrokov, ki jih pošlješ. Nikoli ime, e-pošta, Stravine vožnje ali spanec in HRV z ure.</p>
      </Card>

      {/* profil */}
      <Card style={{ marginBottom: 12 }}>
        <h2 className="h4">Profil</h2>
        <div className="stack" style={{ gap: 10, marginTop: 10 }}>
          {/* polja v vrsti poravnana spodaj: dvovrstična oznaka (»Ure na kolesu …«) ne zamakne polja */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, alignItems: 'end' }}>
            <div className="field"><label htmlFor="pf-name">Ime</label><input id="pf-name" value={f.name} onChange={setField('name')} autoComplete="given-name" /></div>
            <div className="field"><label htmlFor="pf-sex">Spol</label><select id="pf-sex" value={f.sex} onChange={setField('sex')} style={{ paddingLeft: 10 }}><option value="">—</option><option value="m">Moški</option><option value="z">Ženska</option></select></div>
            <div className="field"><label htmlFor="pf-age">Starost</label><input id="pf-age" type="number" inputMode="numeric" value={f.age} onChange={setField('age')} /></div>
            <div className="field"><label htmlFor="pf-h">Višina <span className="unit">cm</span></label><input id="pf-h" type="number" inputMode="numeric" value={f.height} onChange={setField('height')} /></div>
            <div className="field"><label htmlFor="pf-w">Teža <span className="unit">kg</span></label><input id="pf-w" type="number" inputMode="decimal" step={0.1} value={f.weight} onChange={setField('weight')} /></div>
            <div className="field"><label htmlFor="pf-hours">Ure na teden <span className="unit">kolo</span></label><input id="pf-hours" type="number" inputMode="decimal" step={0.5} value={f.hours} onChange={setField('hours')} /></div>
            <div className="field"><label htmlFor="pf-max">Max utrip</label><input id="pf-max" type="number" inputMode="numeric" value={f.maxHr} onChange={setField('maxHr')} /></div>
            <div className="field"><label htmlFor="pf-rest">Mirovni utrip</label><input id="pf-rest" type="number" inputMode="numeric" value={f.restHr} onChange={setField('restHr')} /></div>
            <div className="field"><label htmlFor="pf-lthr">Pražni utrip (LTHR)</label><input id="pf-lthr" type="number" inputMode="numeric" value={f.lthr} onChange={setField('lthr')} placeholder="iz intervals.icu" /></div>
            <div className="field"><label htmlFor="pf-ftp">FTP <span className="unit">W</span></label><input id="pf-ftp" type="number" inputMode="numeric" value={f.ftp} onChange={setField('ftp')} placeholder="ne vem" /></div>
            <div className="field"><label htmlFor="pf-bf">Maščoba <span className="unit">%, če veš</span></label><input id="pf-bf" type="number" inputMode="decimal" step={0.5} value={f.bf} onChange={setField('bf')} placeholder="ocena iz BMI" /></div>
          </div>
          <Btn block sm disabled={!dirty} onClick={saveProfile}>Shrani profil</Btn>
        </div>
      </Card>

      {/* cilj sezone */}
      <div style={{ marginBottom: 12 }}><GoalCard full /></div>

      {/* prehrana */}
      <Card style={{ marginBottom: 12 }}>
        <h2 className="h4">Prehrana</h2>
        <div className="field" style={{ marginTop: 10 }}><label>Deficit na dan <span className="unit">samo izven kolesa, do ciljne teže</span></label>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>{([[0, 'brez'], [300, '300 · počasi'], [400, '400'], [500, '500 · zmerno'], [MAX_DEFICIT, `${MAX_DEFICIT} · največ`]] as const).map(([v, l]) => <Chip key={v} sm on={(p.deficit ?? 0) === v} onClick={() => updateProfile({ deficit: v })}>{l}</Chip>)}</div>
          <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>Na ključne dni in ob dolgi vožnji pol, v specifični fazi pol, v taperingu nič. Na ciljni teži se deficit ustavi.</div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 10, marginTop: 10, alignItems: 'end' }}>
          <div className="field"><label htmlFor="pf-kcal">Ročni cilj <span className="unit">kcal, prazno = izračun</span></label><input id="pf-kcal" type="number" inputMode="numeric" value={g.kcal} onChange={e => setG({ ...g, kcal: e.target.value })} /></div>
          <Btn sm onClick={saveKcal}>Shrani</Btn>
        </div>
        <div className="field" style={{ marginTop: 10 }}><label>Kdaj običajno treniraš <span className="unit">razpored obrokov</span></label>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>{([['zjutraj', 'zjutraj'], ['popoldne', 'popoldne'], ['zvecer', 'zvečer']] as const).map(([v, l]) => <Chip key={v} sm on={(p.trainTime || 'popoldne') === v} onClick={() => updateProfile({ trainTime: v })}>{l}</Chip>)}</div>
        </div>
        <div className="field" style={{ marginTop: 10 }}><label>Gibanje izven treninga</label>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>{([[1.3, 'sedeče'], [1.4, 'zmerno'], [1.5, 'veliko hoje']] as const).map(([v, l]) => <Chip key={v} sm on={p.neat === v} onClick={() => updateProfile({ neat: v })}>{l}</Chip>)}</div>
        </div>
        <div className="field" style={{ marginTop: 10 }}><label>Beljakovine na kg</label>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>{([[1.6, '1,6 g'], [1.8, '1,8 g'], [2.0, '2,0 g'], [2.2, '2,2 g']] as const).map(([v, l]) => <Chip key={v} sm on={p.proteinGkg === v} onClick={() => updateProfile({ proteinGkg: v })}>{l}</Chip>)}</div>
        </div>
        <div className="field" style={{ marginTop: 12 }}><label>Kaj imaš za na kolo</label>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>{FUEL_ITEMS.map(it => { const kit = p.fuelKit && p.fuelKit.length ? p.fuelKit : DEFAULT_KIT; const on = kit.includes(it.key); return <Chip key={it.key} sm on={on} onClick={() => updateProfile({ fuelKit: on ? kit.filter(k => k !== it.key) : [...kit, it.key] })}>{it.label}</Chip> })}</div>
          <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>{nb('Gorivo za vožnjo sestavim iz tega, kar označiš: dolge vožnje dobijo pravo hrano, intervali gele, lahke vožnje banane in Frutabele. Količine so v gramih OH na kos (Frutabela 30 g ≈\u00a019 g OH, gel ≈\u00a025 g, banana ≈\u00a025 g, bidon izotonika ≈\u00a040–45\u00a0g).')}</div>
        </div>
        <p style={{ fontSize: 12.5, marginTop: 10 }}>
          {b && maint && tgt ? <>Bazalna poraba {fmtKcal(b)}{NBSP}kcal · vzdrževanje {fmtKcal(maint)}{NBSP}kcal · cilj na dan brez treninga <b style={{ color: 'var(--ink)' }}>{fmtKcal(tgt.kcal)}{NBSP}kcal</b>, beljakovine {tgt.proteinG}{NBSP}g. Trening doda svojo porabo. Cilj nikoli ne pade pod bazalno porabo in {p.sex === 'z' ? fmtKcal(1200) : fmtKcal(1500)}{NBSP}kcal{isMinor(p) ? '; do 18. leta brez deficita' : ''}.</> : 'Za izračun izpolni starost, spol, višino in težo.'}
        </p>
        {/* eno opozorilo na zaslonu: velja za cilj kalorij tukaj in za načrt v kartici cilja */}
        <HealthNote kind="both" />
      </Card>

      {/* oprema in moč */}
      <Card style={{ marginBottom: 12 }}>
        <h2 className="h4">Oprema in moč</h2>
        <div className="row" style={{ gap: 7, flexWrap: 'wrap', marginTop: 10 }}>
          <Chip sm on={p.gear.bikeOutdoor} onClick={() => updateProfile({ gear: { ...p.gear, bikeOutdoor: !p.gear.bikeOutdoor, noBike: false } })}>Kolo zunaj</Chip>
          <Chip sm on={p.gear.trainer} onClick={() => updateProfile({ gear: { ...p.gear, trainer: !p.gear.trainer, noBike: false } })}>Trenažer</Chip>
          <Chip sm on={p.gear.powerMeter === true} onClick={() => updateProfile({ gear: { ...p.gear, powerMeter: p.gear.powerMeter === true ? false : true, powerMeterAuto: false } })}>Merilnik moči</Chip>
          <Chip sm on={!!p.gear.dumbbells} onClick={() => updateProfile({ gear: { ...p.gear, dumbbells: !p.gear.dumbbells } })}>Uteži</Chip>
        </div>
        {p.gear.dumbbells && <div className="field" style={{ marginTop: 10 }}><label htmlFor="pf-dkg">Teža uteži <span className="unit">kg</span></label><input id="pf-dkg" type="number" inputMode="decimal" value={g.dkg} onChange={e => setG({ ...g, dkg: e.target.value })} onBlur={() => updateProfile({ gear: { ...getState().profile.gear, dumbbellKg: num(g.dkg) } })} /></div>}
        <div className="field" style={{ marginTop: 12 }}><label>Moč na teden</label>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>{([[0, 'brez'], [1, '1×'], [2, '2×']] as const).map(([v, l]) => <Chip key={v} sm on={(p.strength.on ? Math.min(2, p.strengthDays ?? 2) : 0) === v} onClick={() => setStrength({ on: v > 0 }, v)}>{l}</Chip>)}</div>
        </div>
        {p.strength.on && (<>
          <div className="field" style={{ marginTop: 10 }}><label>Kje</label>
            <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>
              <Chip sm on={p.strength.equipment !== 'gym'} onClick={() => setStrength({ equipment: 'home' })}>doma</Chip>
              <Chip sm on={p.strength.equipment === 'gym'} onClick={() => setStrength({ equipment: 'gym' })}>fitnes</Chip>
            </div>
          </div>
          <div className="field" style={{ marginTop: 10 }}><label>Kdaj</label>
            <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>
              <Chip sm on={!p.strength.phases?.length} onClick={() => setStrength({ phases: null })}>vso sezono</Chip>
              <Chip sm on={!!p.strength.phases?.length && p.strength.phases.length === 1 && p.strength.phases[0] === 'osnova'} onClick={() => setStrength({ phases: ['osnova'] })}>samo v osnovi{baseEnd ? ` (do ${baseEnd})` : ''}</Chip>
            </div>
          </div>
        </>)}
        <p style={{ fontSize: 12.5, marginTop: 8 }}>{p.strength.equipment === 'gym'
          ? 'Fitnes: torek noge težko (polovični počep, nožna preša na eni nogi, romunski mrtvi dvig …), petek enonožne vaje + hrbet in jedro, ~50 min. Kilograme vpiši — naslednja seja jih prevzame.'
          : 'Moč doma: jedro (torek, po VO2max) in noge + jedro (petek), 20–30 min. Ko opraviš sejo, naslednja dvigne ponovitve. Uteži dodajo težo bolgarskim počepom.'} Jedro po želji dodaš kadarkoli v Planu (»+ jedro po želji« pri dnevu).</p>
      </Card>

      {/* cikel brez dogodka */}
      {!p.event && (
        <Card style={{ marginBottom: 12 }}>
          <h2 className="h4">Cikel brez dirke</h2>
          <p style={{ fontSize: 13, marginTop: 6 }}>{cx.structured ? <>Zdaj: <b style={{ color: 'var(--ink)' }}>{cx.phaseName}</b>, teden {cx.week}/{cx.total}{cx.recovery ? ' (razbremenilni)' : ''}. {cx.phaseDesc}</> : 'Osnova 4 tedne → gradnja 4 → specifično 4, vsak 4. teden razbremenilni. Z dirko (Cilj sezone) postane makrocikel do nje.'}</p>
          <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
            <Btn ghost sm onClick={restartCycle}>{p.cycleStart ? 'Začni znova ta teden' : 'Začni ta teden'}</Btn>
            {p.cycleStart && <Btn ghost sm onClick={stopCycle}>Prekini</Btn>}
          </div>
        </Card>
      )}

      {/* vreme */}
      <Card style={{ marginBottom: 12 }}>
        <h2 className="h4">Vreme za načrt</h2>
        <p style={{ fontSize: 12.5, marginTop: 6 }}>Dolga vožnja gre na najbolj suh dan; ob dežju opozorilo na Danes. Kraj ne gre v AI.</p>
        <div className="row" style={{ gap: 8, marginTop: 10 }}>
          <div className="field" style={{ flex: 1, minWidth: 0 }}><input value={place} onChange={e => setPlace(e.target.value)} placeholder="kraj, npr. Vodice" aria-label="Kraj za vreme" /></div>
          <Btn sm disabled={busy} onClick={savePlace}>Shrani</Btn>
        </div>
        <div className="row" style={{ gap: 8, marginTop: 8 }}>
          <Btn ghost sm onClick={useLocation}>Lokacija naprave</Btn>
          {p.place && <Btn ghost sm onClick={() => refreshWeather(true).then(w => toast(w ? 'Vreme osveženo.' : 'Vreme ni dosegljivo.', w ? 'ok' : 'err'))}>Osveži</Btn>}
        </div>
      </Card>

      {/* povezave */}
      <Card style={{ marginBottom: 12 }}>
        <h2 className="h4">Ura in uvoz</h2>
        <p style={{ fontSize: 13, marginTop: 6 }}>intervals.icu: {app.settings.intervals ? <b style={{ color: 'var(--ink)' }}>{app.settings.intervals.name || app.settings.intervals.athleteId}</b> : 'ni povezan'}</p>
        <div className="row" style={{ gap: 8, marginTop: 10 }}><Btn ghost sm onClick={() => navigate('uvoz')}>Uredi uvoz</Btn>{app.settings.intervals && <Btn ghost sm disabled={busy} onClick={disconnectIcu}>{busy ? 'Odklapljam …' : 'Odklopi'}</Btn>}</div>
        {app.settings.intervals && (() => {
          const on = !!app.settings.wellnessOn
          const last = on ? [...(app.wellness || [])].reverse().find(d => d.sleepH != null || d.hrv != null || d.rhr != null) : null
          return (
            <div style={{ marginTop: 14, paddingTop: 12, borderTop: '1px solid var(--line)' }}>
              <button type="button" className="between" style={{ width: '100%', background: 'none', border: 0, padding: 0, textAlign: 'left', cursor: 'pointer', gap: 12 }} onClick={() => void setWellnessOn(!on)} aria-pressed={on}>
                <span><b style={{ fontSize: 14 }}>Spanec, HRV in mirovni utrip</b><span className="muted" style={{ display: 'block', fontSize: 12, marginTop: 2 }}>Z ure prek intervals.icu → samodejna jutranja pripravljenost in lažji dan po slabi noči.</span></span>
                <span className={`switch ${on ? 'on' : ''}`} aria-hidden="true"><i /></span>
              </button>
              <p className="muted" style={{ fontSize: 11.5, marginTop: 8 }}>Zdravstveni podatki: ostanejo samo na tej napravi — ne gredo v oblak in ne v AI. Ob izklopu se takoj izbrišejo.</p>
              {on && <p style={{ fontSize: 12.5, marginTop: 6 }}>{last ? <>Zadnje ({dm(last.date)}): {[last.sleepH != null ? `spanec ${fmtSleep(last.sleepH)}` : null, last.hrv != null ? `HRV ${Math.round(last.hrv)}${NBSP}ms` : null, last.rhr != null ? `utrip ${last.rhr}` : null].filter(Boolean).join(' · ')}</> : 'Še ni podatkov — v Garmin Connect mora biti vklopljeno deljenje z intervals.icu (tudi »Wellness«).'}</p>}
            </div>
          )
        })()}
      </Card>

      <Card style={{ marginBottom: 12 }}>
        <h2 className="h4">Odtenek zelene</h2>
        <div className="row" style={{ gap: 9, marginTop: 10 }}>{ACCENTS.map(([hex, name]) => <button key={hex} title={name} aria-label={name} aria-pressed={app.settings.accentHex === hex} onClick={() => updateSettings({ accentHex: hex })} style={{ width: 32, height: 32, borderRadius: 999, border: 0, background: hex, outline: app.settings.accentHex === hex ? '2px solid var(--ink-2)' : '2px solid transparent', outlineOffset: 3, cursor: 'pointer' }} />)}</div>
      </Card>

      <Card style={{ marginBottom: 12 }}>
        <h2 className="h4">Podatki</h2>
        <p style={{ fontSize: 13, marginTop: 6 }}>Vse je shranjeno na tej napravi, s prijavo tudi v oblaku — brez sledi in slik. Izvoz vsebuje vse podatke (datoteka JSON).</p>
        <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
          <Btn ghost sm onClick={async () => { const d = await exportAll(); const bl = new Blob([JSON.stringify(d, null, 1)], { type: 'application/json' }); const a = document.createElement('a'); a.href = URL.createObjectURL(bl); a.download = `formai-izvoz-${app.today}.json`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000) }}>Izvozi vse</Btn>
          <Btn ghost sm onClick={wipeDevice}>Izbriši na napravi</Btn>
          {app.user && <Btn ghost sm onClick={deleteAcc}>Izbriši račun</Btn>}
        </div>
      </Card>
      <div className="muted" style={{ fontSize: 11.5, padding: '0 4px 16px', textAlign: 'center' }}>FORMAI v{APP_VERSION}</div>
    </div>
    {confirmSheet}
  </>)
}
