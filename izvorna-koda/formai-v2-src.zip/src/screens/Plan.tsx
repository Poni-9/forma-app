import { useState } from 'react'
import { Head } from '@/app/Shell'
import { navigate, useRoute } from '@/app/router'
import { useApp, setPlanDone, savePlanDays, savePlanDay, toast } from '@/state/store'
import { snapOf } from '@/state/snap'
import { useAi } from '@/ui/useAi'
import { addDays, fmtDur, weekStartIso } from '@/domain/training/load'
import { buildWeek, weekMinutes, cycleInfo, forecastForm, zoneMinutes } from '@/domain/training/planner'
import { downloadIcs } from '@/domain/training/ics'
import { adaptWeek } from '@/domain/ai/actions'
import { wxShort, wxBad } from '@/domain/weather'
import type { PlanDay, PlanKind } from '@/domain/types'
import { Card, Chip, CheckBtn, Btn, Track, Sheet, kindColor, kindLabel, DAYS_SL, Empty } from '@/ui/primitives'
import { IcoCal, IcoPlay } from '@/ui/icons'

const KINDS: { k: PlanKind; l: string }[] = [{ k: 'kolo', l: 'Kolo' }, { k: 'moc', l: 'Moč' }, { k: 'tek', l: 'Tek' }, { k: 'pohod', l: 'Hoja' }, { k: 'pocitek', l: 'Počitek' }]
const ZONES = ['', 'Z1', 'Z2', 'Z3', 'Z4', 'Z5', 'test']

export function Plan() {
  const app = useApp()
  const ai = useAi()
  const route = useRoute()
  const [view, setView] = useState<'ta' | 'naslednji'>(route.params.dan && route.params.dan > addDays(weekStartIso(app.today), 6) ? 'naslednji' : 'ta')
  const [edit, setEdit] = useState<PlanDay | null>(null)
  const [busy, setBusy] = useState(false)
  const ws = weekStartIso(app.today)
  const start = view === 'ta' ? ws : addDays(ws, 7)
  const days = Array.from({ length: 7 }, (_, i) => addDays(start, i))
  const items = app.plan.filter(d => d.date >= start && d.date <= addDays(start, 6))
  const active = items.filter(d => d.kind !== 'pocitek' && !d.optional)
  const done = active.filter(d => d.done).length
  const minsDone = active.filter(d => d.done).reduce((s, d) => s + d.durationMin, 0)
  const minsAll = weekMinutes(active)
  const tssAll = active.reduce((s, d) => s + (d.tssTarget || 0), 0)
  const focus = route.params.dan || app.today
  const cy = cycleInfo(app.profile, start)
  const fc = view === 'ta' && items.length ? forecastForm(app.activities, items, app.today) : null
  const zm = zoneMinutes(items)
  const zTotal = Object.values(zm).reduce((s, x) => s + x, 0)
  const easy = zm.Z1 + zm.Z2

  async function generate() {
    const rain: Record<string, number> = {}
    if (app.weather) for (const k in app.weather) rain[k] = app.weather[k]!.rain
    const week = buildWeek({ profile: app.profile, activities: app.activities, weekStart: start, rain, firstWeek: !app.plan.length, notBefore: view === 'ta' ? app.today : start })
    const doneDates = new Set(items.filter(d => d.done).map(d => d.date))
    await savePlanDays(week.filter(d => !doneDates.has(d.date)))
    toast(view === 'ta' ? 'Ta teden je sestavljen.' : 'Naslednji teden je sestavljen.', 'ok')
  }
  async function adapt() {
    if (!items.length) return
    setBusy(true)
    const r = await ai.run(() => adaptWeek(snapOf(app), items))
    setBusy(false)
    if (r) { await savePlanDays(r.days.filter(d => !d.done)); toast(r.summary, 'ok', 8000) }
  }

  return (<>
    <Head hi={app.profile.event?.date ? `Do ${app.profile.event.name} ${Math.max(0, Math.round((new Date(app.profile.event.date).getTime() - new Date(app.today).getTime()) / 86400_000))} dni` : cy ? `${cy.phase.name} · teden ${cy.week}/${cy.length}` : 'Načrt'} nm={view === 'ta' ? 'Ta teden' : 'Naslednji teden'} />
    <div className="scroll">
      <div className="row" style={{ gap: 8, paddingBottom: 12 }}>
        <Chip on={view === 'ta'} onClick={() => setView('ta')}>Ta teden</Chip>
        <Chip on={view === 'naslednji'} onClick={() => setView('naslednji')}>Naslednji</Chip>
        {cy?.recovery && <Chip sm>razbremenilni</Chip>}
      </div>
      {cy && <div style={{ marginBottom: 12 }}><Track pct={cy.week / cy.length * 100} color="var(--accent)" /><div className="muted" style={{ fontSize: 11.5, marginTop: 6, fontWeight: 600 }}>{cy.phase.desc}</div></div>}
      {!items.length ? (
        <Empty icon={<IcoCal width={30} height={30} style={{ color: 'var(--accent)' }} />} title={view === 'ta' ? 'Ta teden še ni sestavljen' : 'Naslednji teden še ni sestavljen'} text="Načrt sestavim iz profila, cikla, vremena in tega, kar si že opravil — brez čakanja.">
          <Btn primary sm onClick={generate}>Sestavi teden</Btn>
        </Empty>
      ) : (<>
        <Card tight style={{ marginBottom: 12 }}>
          <div className="between" style={{ marginBottom: 8 }}><b style={{ fontSize: 13 }}>Opravljeno</b><span style={{ fontSize: 13, fontWeight: 800, color: 'var(--accent)' }}>{done} / {active.length}</span></div>
          <Track pct={active.length ? (done / active.length) * 100 : 0} color="var(--accent)" />
          <div className="between muted" style={{ fontSize: 12, marginTop: 8 }}><span>{minsDone ? fmtDur(minsDone) : '0 min'} od {fmtDur(minsAll)} · {tssAll} TSS</span>{fc && <span>forma v nedeljo ≈ {fc.tsb > 0 ? '+' : ''}{fc.tsb}</span>}</div>
          {zTotal > 0 && (
            <div style={{ marginTop: 10 }}>
              <div style={{ display: 'flex', height: 8, borderRadius: 4, overflow: 'hidden', gap: 2 }}>
                {(['Z1', 'Z2', 'Z3', 'Z4', 'Z5'] as const).map((z, i) => zm[z] > 0 && <i key={z} style={{ flex: zm[z], background: ['var(--t-poc)', 'var(--t-kolo)', 'var(--t-tek)', 'var(--warn)', 'var(--t-moc)'][i] }} />)}
              </div>
              <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>{Math.round(easy / zTotal * 100)} % lahko (Z1–Z2) · {Math.round((zTotal - easy) / zTotal * 100)} % težko — cilj je okoli 80 / 20.</div>
            </div>
          )}
        </Card>
        <div className="stack" style={{ gap: 10 }}>
          {days.map((date, i) => {
            const list = items.filter(x => x.date === date)
            if (!list.length) return null
            return list.map(d => {
              const open = focus === date
              const past = date < app.today
              const wx = app.weather?.[date]
              const outdoor = d.kind === 'kolo' || d.kind === 'tek' || d.kind === 'pohod'
              return (
                <Card key={d.id} tight className="sess" style={{ borderColor: open ? 'var(--line)' : undefined, opacity: d.optional && !open ? 0.8 : 1 }}>
                  <div className="bar" style={{ background: d.optional ? 'var(--t-poc)' : kindColor(d.kind) }} />
                  <div className="row" style={{ gap: 12, alignItems: 'flex-start' }}>
                    {d.kind !== 'pocitek' ? <CheckBtn on={!!d.done} onClick={() => setPlanDone(d.id, !d.done)} /> : <div style={{ width: 26, height: 26, flex: 'none' }} />}
                    <div style={{ flex: 1, minWidth: 0, cursor: 'pointer' }} onClick={() => navigate('plan', { dan: date })}>
                      <div className="between">
                        <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: '.08em', color: d.optional ? 'var(--ink-3)' : kindColor(d.kind) }}>{DAYS_SL[i]!.toUpperCase()} {+date.slice(8)}. · {kindLabel(d.kind).toUpperCase()}</div>
                        {d.optional ? <span className="muted" style={{ fontSize: 11, fontWeight: 700 }}>po želji</span> : past && !d.done && d.kind !== 'pocitek' ? <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--warn)' }}>ni označeno</span> : null}
                      </div>
                      <b style={{ fontSize: 15 }}>{d.title}</b>
                      <div className="muted" style={{ fontSize: 12 }}>{d.kind === 'pocitek' ? d.desc : `${fmtDur(d.durationMin)}${d.tssTarget && !d.optional ? ` · ${d.tssTarget} TSS` : ''}${d.exercises?.length ? ` · ${d.exercises.length} vaj` : ''}`}</div>
                      {outdoor && wx && !d.done && <div style={{ fontSize: 11.5, marginTop: 3, fontWeight: 600, color: wxBad(wx) ? 'var(--warn)' : 'var(--ink-3)' }}>{wxShort(wx)}</div>}
                      {open && d.kind !== 'pocitek' && (
                        <div style={{ marginTop: 8, fontSize: 13, color: 'var(--ink-2)' }}>
                          {d.desc}
                          {d.exercises && <div style={{ marginTop: 8 }}>{d.exercises.map((e, j) => <div key={j} className="between" style={{ fontSize: 13, padding: '3px 0', borderTop: j ? '1px solid var(--line)' : 0 }}><b style={{ color: 'var(--ink)' }}>{e.name}</b><span className="muted">{e.sets} × {e.reps}{e.kg ? ` · ${e.kg} kg` : ''}</span></div>)}</div>}
                          {d.why && <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>Zakaj: {d.why}</div>}
                        </div>
                      )}
                    </div>
                  </div>
                  {open && (
                    <div className="row" style={{ gap: 8, marginTop: 10, paddingLeft: 38, flexWrap: 'wrap' }}>
                      {d.kind !== 'pocitek' && !d.done && !d.optional && <Btn primary sm onClick={() => navigate('vadba', { id: d.id })}><IcoPlay width={14} height={14} /> Začni</Btn>}
                      <Btn ghost sm onClick={() => setEdit(d)}>Uredi</Btn>
                    </div>
                  )}
                </Card>
              )
            })
          })}
        </div>
        <div className="row" style={{ gap: 8, marginTop: 14, flexWrap: 'wrap' }}>
          <Btn ghost sm onClick={generate}>Sestavi znova</Btn>
          {app.user && <Btn ghost sm disabled={ai.busy} onClick={adapt}>{busy ? 'Prilagajam …' : 'AI prilagodi teden'}</Btn>}
          <Btn ghost sm onClick={() => downloadIcs(items, `formai-${start}.ics`)}>V koledar</Btn>
        </div>
        <p className="muted" style={{ fontSize: 11.5, marginTop: 10 }}>Sestavi znova ohrani opravljene dni. Hoja ob počitku je neobvezna in ne šteje v realizacijo.</p>
        <p className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>⚕️ Plan je trenerska <b>usmeritev, ne zdravniški nasvet</b>. Poslušaj telo; ob bolečini, bolezni ali zdravstvenih težavah se posvetuj z zdravnikom.</p>
      </>)}
    </div>
    {edit && <EditDay day={edit} onClose={() => setEdit(null)} />}
    {ai.sheet}
  </>)
}

type ExRow = { name: string; sets: string; reps: string; kg: string }
function EditDay({ day, onClose }: { day: PlanDay; onClose: () => void }) {
  const [d, setD] = useState({ kind: day.kind, title: day.title, dur: String(day.durationMin || ''), zone: day.zone || '', desc: day.desc })
  const [ex, setEx] = useState<ExRow[]>((day.exercises || []).map(e => ({ name: e.name, sets: String(e.sets), reps: e.reps, kg: e.kg ? String(e.kg) : '' })))
  async function save() {
    const kind = d.kind as PlanKind
    const exercises = kind === 'moc' ? ex.filter(e => e.name.trim()).map(e => ({ name: e.name.trim().slice(0, 40), sets: Math.max(1, Math.min(8, parseInt(e.sets) || 3)), reps: (e.reps.trim() || '8–12').slice(0, 14), kg: e.kg ? +e.kg.replace(',', '.') || null : null })) : undefined
    const dur = kind === 'pocitek' ? 0 : Math.max(0, Math.min(360, parseInt(d.dur) || 0))
    const h = dur / 60
    const tss = kind === 'kolo' ? Math.round(h * (d.zone === 'Z5' ? 100 : d.zone === 'Z4' || d.zone === 'test' ? 85 : d.zone === 'Z3' ? 70 : 50)) : kind === 'tek' ? Math.round(h * 78) : kind === 'moc' ? Math.round(h * 60) : kind === 'pohod' ? Math.round(h * 40) : 0
    await savePlanDay({ ...day, kind, title: d.title.trim() || day.title, durationMin: dur, zone: d.zone || null, desc: d.desc.trim(), exercises, tssTarget: tss, optional: kind === day.kind ? day.optional : false, source: 'rules' })
    toast('Dan shranjen.', 'ok'); onClose()
  }
  const set = (i: number, k: keyof ExRow, v: string) => setEx(ex.map((e, j) => (j === i ? { ...e, [k]: v } : e)))
  return (
    <Sheet open onClose={onClose}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Uredi dan</b>
      <div className="row" style={{ gap: 7, flexWrap: 'wrap', margin: '12px 0' }}>{KINDS.map(k => <Chip key={k.k} sm on={d.kind === k.k} onClick={() => setD({ ...d, kind: k.k })}>{k.l}</Chip>)}</div>
      <div className="stack" style={{ gap: 10 }}>
        <div className="field"><label>Naslov</label><input value={d.title} onChange={e => setD({ ...d, title: e.target.value })} /></div>
        {d.kind !== 'pocitek' && <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div className="field"><label>Trajanje <span className="unit">min</span></label><input type="number" inputMode="numeric" value={d.dur} onChange={e => setD({ ...d, dur: e.target.value })} /></div>
          <div className="field"><label>Cona</label><select value={d.zone} onChange={e => setD({ ...d, zone: e.target.value })}>{ZONES.map(z => <option key={z} value={z}>{z || '—'}</option>)}</select></div>
        </div>}
        <div className="field"><label>Opis</label><textarea value={d.desc} onChange={e => setD({ ...d, desc: e.target.value })} rows={3} /></div>
        {d.kind === 'moc' && (
          <div className="field"><label>Vaje <span className="unit">ime · serije · ponovitve · kg</span></label>
            <div className="stack" style={{ gap: 6 }}>
              {ex.map((e, i) => (
                <div key={i} className="exrow" style={{ display: 'grid', gridTemplateColumns: '1fr 44px 70px 50px 26px', gap: 5 }}>
                  <input value={e.name} onChange={x => set(i, 'name', x.target.value)} placeholder="vaja" />
                  <input value={e.sets} inputMode="numeric" onChange={x => set(i, 'sets', x.target.value)} style={{ textAlign: 'center' }} />
                  <input value={e.reps} onChange={x => set(i, 'reps', x.target.value)} style={{ textAlign: 'center' }} />
                  <input value={e.kg} inputMode="decimal" onChange={x => set(i, 'kg', x.target.value)} placeholder="kg" style={{ textAlign: 'center' }} />
                  <button className="chip sm click" onClick={() => setEx(ex.filter((_, j) => j !== i))} aria-label="Odstrani">×</button>
                </div>
              ))}
              <button className="chip sm click" style={{ alignSelf: 'flex-start' }} onClick={() => setEx([...ex, { name: '', sets: '3', reps: '8–12', kg: '' }])}>+ vaja</button>
            </div>
          </div>
        )}
      </div>
      <Btn primary block style={{ marginTop: 14 }} onClick={save}>Shrani</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Prekliči</Btn>
    </Sheet>
  )
}
