import { useEffect, useState } from 'react'
import { Head } from '@/app/Shell'
import { navigate, useRoute } from '@/app/router'
import { useApp, setPlanDone, savePlanDays, savePlanDay, toast, hikeInstead, backToBike, addCore } from '@/state/store'
import { snapOf } from '@/state/snap'
import { useAi } from '@/ui/useAi'
import { addDays, fmtDur, weekStartIso } from '@/domain/training/load'
import { buildWeek, weekMinutes, weekBikeMinutes, weekContext, macroWeeks, forecastForm, zoneMinutes, canHike, type PhaseKey } from '@/domain/training/planner'
import { seasonGoals } from '@/domain/training/season'
import { RacesCard } from '@/ui/Races'
import { GoalSheet } from '@/ui/GoalSheet'
import { fullHoursWeek, rampStart } from '@/domain/training/goal'
import { DayPlan } from '@/ui/DayPlan'
import { downloadIcs } from '@/domain/training/ics'
import { adaptWeek } from '@/domain/ai/actions'
import { wxShort, wxBad, clothing } from '@/domain/weather'
import type { PlanDay, PlanKind } from '@/domain/types'
import { Card, Chip, CheckBtn, Btn, Track, Sheet, kindColor, kindLabel, DAYS_SL, Empty } from '@/ui/primitives'
import { IcoCal, IcoPlay } from '@/ui/icons'

const KINDS: { k: PlanKind; l: string }[] = [{ k: 'kolo', l: 'Kolo' }, { k: 'test', l: 'Test' }, { k: 'pohod', l: 'Hribi' }, { k: 'moc', l: 'Moč' }, { k: 'pocitek', l: 'Počitek' }]
const PH_COLOR: Record<PhaseKey, string> = { prehod: 'var(--t-poc)', osnova: 'var(--t-kolo)', gradnja: 'var(--warn)', specificno: 'var(--t-moc)', tapering: 'var(--ok)', dirka: 'var(--accent)', po: 'var(--t-poc)' }
const ZONES = ['', 'Z1', 'Z2', 'Z3', 'Z4', 'Z5', 'test']

export function Plan() {
  const app = useApp()
  const ai = useAi()
  const route = useRoute()
  const [view, setView] = useState<'ta' | 'naslednji'>(route.params.dan && route.params.dan > addDays(weekStartIso(app.today), 6) ? 'naslednji' : 'ta')
  const [edit, setEdit] = useState<PlanDay | null>(null)
  const [busy, setBusy] = useState(false)
  const [goalOpen, setGoalOpen] = useState(false)
  // ob odprtju skoči na današnji (ali izbrani) dan — v nedeljo ni treba skrolati čez cel teden
  useEffect(() => { const t = setTimeout(() => document.getElementById(`dan-${route.params.dan || app.today}`)?.scrollIntoView({ block: 'start' }), 80); return () => clearTimeout(t) }, [])  // eslint-disable-line react-hooks/exhaustive-deps
  const ws = weekStartIso(app.today)
  const start = view === 'ta' ? ws : addDays(ws, 7)
  const days = Array.from({ length: 7 }, (_, i) => addDays(start, i))
  const items = app.plan.filter(d => d.date >= start && d.date <= addDays(start, 6))
  const active = items.filter(d => d.kind !== 'pocitek' && !d.optional)
  const done = active.filter(d => d.done).length
  // opravljeno: dejanski čas povezane vožnje (ne načrtovani), sicer načrtovani
  const minsDone = active.filter(d => d.done).reduce((s, d) => { const a = d.done?.activityId ? app.activities.find(x => x.id === d.done!.activityId) : null; return s + (a?.durationMin ? Math.round(a.durationMin) : d.durationMin) }, 0)
  const minsAll = weekMinutes(active)
  const tssAll = active.reduce((s, d) => s + (d.tssTarget || 0), 0)
  const focus = route.params.dan || app.today
  const cx = weekContext(app.profile, start)
  const macro = macroWeeks(app.profile, app.today)
  const maxH = Math.max(1, ...macro.map(w => w.hours))
  // tedni s cilji sezone (A) in drugimi tekmami (oznake na časovnici)
  const goals = seasonGoals(app.profile)
  const goalWeeks = new Map(goals.map(g => [weekStartIso(g.date), g.name] as const))
  const raceWeeks = new Map<string, string[]>()
  for (const r of app.profile.races || []) { if (r.prio === 'A') continue; const k = weekStartIso(r.date); raceWeeks.set(k, [...(raceWeeks.get(k) || []), r.name]) }
  const fullAt = fullHoursWeek(app.profile, app.today)
  const bikeAll = weekBikeMinutes(active)
  const fc = view === 'ta' && items.length ? forecastForm(app.activities, items, app.today) : null
  const zm = zoneMinutes(items)
  const zTotal = Object.values(zm).reduce((s, x) => s + x, 0)
  const easy = zm.Z1 + zm.Z2

  async function generate() {
    const rain: Record<string, number> = {}
    if (app.weather) for (const k in app.weather) rain[k] = app.weather[k]!.rain
    const week = buildWeek({ profile: app.profile, activities: app.activities, weekStart: start, rain, firstWeek: !app.plan.length, notBefore: view === 'ta' ? app.today : start })
    const doneDates = new Set(items.filter(d => d.done).map(d => d.date))
    await savePlanDays(week.filter(d => !doneDates.has(d.date)))
    toast(view === 'ta' ? 'Ta teden je sestavljen.' : 'Naslednji teden je sestavljen.', 'ok')
  }
  async function adapt() {
    if (!items.length) return
    setBusy(true)
    const r = await ai.run(() => adaptWeek(snapOf(app), items))
    setBusy(false)
    if (r) { await savePlanDays(r.days.filter(d => !d.done)); toast(r.summary, 'ok', 8000) }
  }

  return (<>
    <Head hi={cx.event && cx.weeksToEvent != null && cx.weeksToEvent >= 0 ? `${cx.phaseName} · ${cx.event.name} čez ${Math.max(0, Math.round((new Date(cx.event.date).getTime() - new Date(app.today).getTime()) / 86400_000))} dni` : cx.structured ? `${cx.phaseName} · teden ${cx.week}/${cx.total}` : 'Načrt'} nm={view === 'ta' ? 'Ta teden' : 'Naslednji teden'} />
    <div className="scroll">
      <div className="row" style={{ gap: 8, paddingBottom: 12 }}>
        <Chip on={view === 'ta'} onClick={() => setView('ta')}>Ta teden</Chip>
        <Chip on={view === 'naslednji'} onClick={() => setView('naslednji')}>Naslednji</Chip>
        {cx.recovery && <Chip sm>razbremenilni</Chip>}
        {cx.test && <Chip sm>test FTP</Chip>}
      </div>
      {macro.length > 0 ? (
        <Card tight style={{ marginBottom: 12 }}>
          <div className="between" style={{ fontSize: 12, fontWeight: 700, gap: 8 }}><span style={{ minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{goals.length > 1 ? `Sezona · ${goals.length} ${goals.length === 2 ? 'cilja' : goals.length <= 4 ? 'cilji' : 'ciljev'} · naslednji ${cx.event?.name}` : `Pot do dirke · ${cx.event?.name}`}</span><span className="muted" style={{ flex: 'none' }}>teden {cx.week}/{cx.total}</span></div>
          <div style={{ display: 'flex', gap: 2, marginTop: 8, alignItems: 'flex-end', height: 26 }} role="img" aria-label={`Makrocikel: ${macro.length} tednov, zdaj ${cx.phaseName}, teden ${cx.week}`}>
            {macro.map(w => <i key={w.weekStart} title={`${w.weekStart.slice(8)}. ${+w.weekStart.slice(5, 7)}. · ${w.phaseName}${w.easy ? ' · lahek začetek' : ''}${w.recovery && w.phase !== 'prehod' ? ' · razbremenilni' : ''}${w.test ? ' · test' : ''} · ${w.hours} h${goalWeeks.has(w.weekStart) ? ` · CILJ: ${goalWeeks.get(w.weekStart)}` : ''}${raceWeeks.has(w.weekStart) ? ` · tekma: ${raceWeeks.get(w.weekStart)!.join(', ')}` : ''}`}
              style={{ flex: 1, height: goalWeeks.has(w.weekStart) ? '100%' : `${Math.max(12, Math.round((w.hours / maxH) * 100))}%`, background: goalWeeks.has(w.weekStart) ? 'var(--accent)' : PH_COLOR[w.phase], opacity: w.weekStart < start ? 0.35 : w.recovery || w.easy ? 0.55 : 1, borderRadius: 2, outline: w.weekStart === start ? '2px solid var(--ink)' : 'none', outlineOffset: 1, boxShadow: raceWeeks.has(w.weekStart) ? 'inset 0 4px 0 var(--ink)' : undefined }} />)}
          </div>
          <div className="row" style={{ gap: 10, flexWrap: 'wrap', marginTop: 8 }}>
            {(['prehod', 'osnova', 'gradnja', 'specificno'] as PhaseKey[]).filter(k => macro.some(w => w.phase === k)).map(k => {
              // pri več ciljih: faza do prvega cilja (kasneje se gradnja in specifično ponavljata pred vsakim)
              const first = goals[0] ? weekStartIso(goals[0].date) : null
              const inSeg = macro.filter(w => w.phase === k && (!first || w.weekStart <= first || k === 'prehod'))
              const last = (inSeg.length ? inSeg : macro.filter(w => w.phase === k)).slice(-1)[0]!
              const to = addDays(last.weekStart, 6)
              return <span key={k} className="muted" style={{ fontSize: 11, fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: 5 }}><i style={{ width: 8, height: 8, borderRadius: 2, background: PH_COLOR[k], display: 'inline-block' }} />{last.phaseName} do {+to.slice(8)}. {+to.slice(5, 7)}.</span>
            })}
            <span className="muted" style={{ fontSize: 11, fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: 5 }}><i style={{ width: 8, height: 8, borderRadius: 2, background: 'var(--accent)', display: 'inline-block' }} />{goals.length > 1 ? 'cilji A' : 'cilj'}</span>
            {raceWeeks.size > 0 && <span className="muted" style={{ fontSize: 11, fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: 5 }}><i style={{ width: 8, height: 8, borderRadius: 2, background: 'var(--t-poc)', boxShadow: 'inset 0 3px 0 var(--ink)', display: 'inline-block' }} />tekma B/C</span>}
          </div>
          <div className="muted" style={{ fontSize: 11.5, marginTop: 6, fontWeight: 600 }}>{cx.phaseDesc}</div>
        </Card>
      ) : (
        <Card tight style={{ marginBottom: 12 }}>
          <p style={{ fontSize: 13 }}>Brez cilja je načrt ponavljajoč se 12-tedenski cikel. Nastavi dirko (npr. Franja, 13. 6. 2027) in načrt postane makrocikel do nje.</p>
          <Btn primary sm style={{ marginTop: 8 }} onClick={() => setGoalOpen(true)}>Nastavi cilj</Btn>
        </Card>
      )}
      <RacesCard />
      {!items.length ? (
        <Empty icon={<IcoCal width={30} height={30} style={{ color: 'var(--accent)' }} />} title={view === 'ta' ? 'Ta teden še ni sestavljen' : 'Naslednji teden še ni sestavljen'} text="Načrt sestavim iz profila, cikla, vremena in tega, kar si že opravil — brez čakanja.">
          <Btn primary sm onClick={generate}>Sestavi teden</Btn>
        </Empty>
      ) : (<>
        <Card tight style={{ marginBottom: 12 }}>
          <div className="between" style={{ marginBottom: 8 }}><b style={{ fontSize: 13 }}>Opravljeno</b><span style={{ fontSize: 13, fontWeight: 800, color: 'var(--accent)' }}>{done} / {active.length}</span></div>
          <Track pct={active.length ? (done / active.length) * 100 : 0} color="var(--accent)" />
          <div className="between muted" style={{ fontSize: 12, marginTop: 8 }}><span>{minsDone ? fmtDur(minsDone) : '0 min'} od {fmtDur(minsAll)} · {tssAll} TSS</span>{fc && <span>forma v nedeljo ≈ {fc.tsb > 0 ? '+' : ''}{fc.tsb}</span>}</div>
          <div className="muted" style={{ fontSize: 12, marginTop: 4 }}>Na kolesu {fmtDur(bikeAll)} · cilj tedna {String(cx.hours).replace('.', ',')} h{cx.recovery ? ' (razbremenilni)' : ''}{app.profile.baseHours != null && cx.hours < (app.profile.hoursPerWeek || 0) ? ` · raste od ${String(rampStart(app.profile) ?? 4).replace('.', ',')} h (+10 % na teden) do ${app.profile.hoursPerWeek} h${fullAt && fullAt > start ? ` (od ${+fullAt.slice(8)}. ${+fullAt.slice(5, 7)}.)` : ''}` : ''}</div>
          {zTotal > 0 && (
            <div style={{ marginTop: 10 }}>
              <div style={{ display: 'flex', height: 8, borderRadius: 4, overflow: 'hidden', gap: 2 }}>
                {(['Z1', 'Z2', 'Z3', 'Z4', 'Z5'] as const).map((z, i) => zm[z] > 0 && <i key={z} style={{ flex: zm[z], background: ['var(--t-poc)', 'var(--t-kolo)', 'var(--t-tek)', 'var(--warn)', 'var(--t-moc)'][i] }} />)}
              </div>
              <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>{Math.round(easy / zTotal * 100)} % lahko (Z1–Z2) · {Math.round((zTotal - easy) / zTotal * 100)} % težko — cilj je okoli 80 / 20.</div>
            </div>
          )}
        </Card>
        <div className="stack" style={{ gap: 10 }}>
          {days.map((date, i) => {
            const list = items.filter(x => x.date === date).sort((a, b) => (a.kind === 'moc' ? 1 : 0) - (b.kind === 'moc' ? 1 : 0))
            if (!list.length) return null
            return list.map((d, j) => {
              const open = focus === date
              const past = date < app.today
              const wx = app.weather?.[date]
              const outdoor = d.kind === 'kolo' || d.kind === 'tek' || d.kind === 'pohod'
              // pretekli dnevi v eni vrstici — da današnji dan ni skrit pod celim tednom
              if (past && !open) return (
                <div key={d.id} id={j === 0 ? `dan-${date}` : undefined} className="card tight sess row" style={{ gap: 10, padding: '9px 12px', cursor: 'pointer', opacity: 0.75, scrollMarginTop: 8 }} onClick={() => navigate('plan', { dan: date })}>
                  <div className="bar" style={{ background: d.optional ? 'var(--t-poc)' : kindColor(d.kind) }} />
                  <span style={{ fontSize: 11, fontWeight: 800, letterSpacing: '.06em', color: d.optional ? 'var(--ink-3)' : kindColor(d.kind), width: 58, flex: 'none' }}>{DAYS_SL[i]!.toUpperCase()} {+date.slice(8)}.</span>
                  <b style={{ fontSize: 13, flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{d.kind === 'pocitek' ? 'Počitek' : d.title}</b>
                  <span className="muted" style={{ fontSize: 11.5, fontWeight: 700, flex: 'none' }}>{d.kind === 'pocitek' ? '' : d.done ? '✓' : d.optional ? 'po želji' : 'ni označeno'}</span>
                </div>
              )
              return (
                <Card key={d.id} id={j === 0 ? `dan-${date}` : undefined} tight className="sess" style={{ borderColor: open ? 'var(--line)' : undefined, opacity: d.optional && !open ? 0.8 : 1, scrollMarginTop: 8 }}>
                  <div className="bar" style={{ background: d.optional ? 'var(--t-poc)' : kindColor(d.kind) }} />
                  <div className="row" style={{ gap: 12, alignItems: 'flex-start' }}>
                    {d.kind !== 'pocitek' ? <CheckBtn on={!!d.done} onClick={() => setPlanDone(d.id, !d.done)} /> : <div style={{ width: 26, height: 26, flex: 'none' }} />}
                    <div style={{ flex: 1, minWidth: 0, cursor: 'pointer' }} onClick={() => navigate('plan', { dan: date })}>
                      <div className="between">
                        <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: '.08em', color: d.optional ? 'var(--ink-3)' : kindColor(d.kind) }}>{DAYS_SL[i]!.toUpperCase()} {+date.slice(8)}. · {kindLabel(d.kind).toUpperCase()}</div>
                        {d.optional ? <span className="muted" style={{ fontSize: 11, fontWeight: 700 }}>po želji</span> : past && !d.done && d.kind !== 'pocitek' ? <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--warn)' }}>ni označeno</span> : null}
                      </div>
                      <b style={{ fontSize: 15 }}>{d.title}</b>
                      <div className="muted" style={{ fontSize: 12 }}>{d.kind === 'pocitek' ? d.desc : `${fmtDur(d.durationMin)}${d.tssTarget && !d.optional ? ` · ${d.tssTarget} TSS` : ''}${d.exercises?.length ? ` · ${d.exercises.length} vaj` : ''}`}</div>
                      {outdoor && wx && !d.done && <div style={{ fontSize: 11.5, marginTop: 3, fontWeight: 600, color: wxBad(wx) ? 'var(--warn)' : 'var(--ink-3)' }}>{wxShort(wx)}{open ? <span className="muted" style={{ fontWeight: 500 }}> · obleci: {clothing(wx)}</span> : null}</div>}
                      {open && d.kind !== 'pocitek' && (
                        <div style={{ marginTop: 8, fontSize: 13, color: 'var(--ink-2)' }}>
                          {d.desc}
                          {d.exercises && <div style={{ marginTop: 8 }}>{d.exercises.map((e, j) => <div key={j} className="between" style={{ fontSize: 13, padding: '3px 0', borderTop: j ? '1px solid var(--line)' : 0 }}><b style={{ color: 'var(--ink)' }}>{e.name}</b><span className="muted">{e.sets} × {e.reps}{e.kg ? ` · ${e.kg} kg` : ''}</span></div>)}</div>}
                          {d.why && <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>Zakaj: {d.why}</div>}
                          <div onClick={e => e.stopPropagation()} style={{ cursor: 'default' }}><DayPlan day={d} /></div>
                        </div>
                      )}
                    </div>
                  </div>
                  {open && (
                    <div className="row" style={{ gap: 8, marginTop: 10, paddingLeft: 38, flexWrap: 'wrap' }}>
                      {d.kind !== 'pocitek' && d.kind !== 'pohod' && !d.done && !d.optional && <Btn primary sm onClick={() => navigate('vadba', { id: d.id })}><IcoPlay width={14} height={14} /> Začni</Btn>}
                      {date >= app.today && canHike(d) && <Btn ghost sm onClick={async () => { await hikeInstead(d.id); toast('Hribi namesto kolesa — trening za ta dan gre z ure.', 'ok') }}>Hribi namesto kolesa</Btn>}
                      {d.swap && !d.done && <Btn ghost sm onClick={async () => { await backToBike(d.id); toast('Nazaj na kolo.', 'ok') }}>Nazaj na kolo</Btn>}
                      {date >= app.today && j === list.length - 1 && !list.some(x => x.kind === 'moc') && <Btn ghost sm onClick={async () => { await addCore(date); toast('Jedro dodano — po želji, ne šteje v realizacijo.', 'ok') }}>+ jedro po želji</Btn>}
                      <Btn ghost sm onClick={() => setEdit(d)}>Uredi</Btn>
                    </div>
                  )}
                </Card>
              )
            })
          })}
        </div>
        <div className="row" style={{ gap: 8, marginTop: 14, flexWrap: 'wrap' }}>
          <Btn ghost sm onClick={generate}>Sestavi znova</Btn>
          {app.user && <Btn ghost sm disabled={ai.busy} onClick={adapt}>{busy ? 'Prilagajam …' : 'AI prilagodi teden'}</Btn>}
          <Btn ghost sm onClick={() => downloadIcs(items, `formai-${start}.ics`)}>V koledar</Btn>
        </div>
        <p className="muted" style={{ fontSize: 11.5, marginTop: 10 }}>Sestavi znova ohrani opravljene dni. Vati so iz tvojega FTP — po vsakem testu se posodobijo.</p>
        <p className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>⚕️ Plan je trenerska <b>usmeritev, ne zdravniški nasvet</b>. Poslušaj telo; ob bolečini, bolezni ali zdravstvenih težavah se posvetuj z zdravnikom.</p>
      </>)}
    </div>
    {edit && <EditDay day={edit} onClose={() => setEdit(null)} />}
    {goalOpen && <GoalSheet open onClose={() => setGoalOpen(false)} />}
    {ai.sheet}
  </>)
}

type ExRow = { name: string; sets: string; reps: string; kg: string }
function EditDay({ day, onClose }: { day: PlanDay; onClose: () => void }) {
  const [d, setD] = useState({ kind: day.kind, title: day.title, dur: String(day.durationMin || ''), zone: day.zone || '', desc: day.desc })
  const [ex, setEx] = useState<ExRow[]>((day.exercises || []).map(e => ({ name: e.name, sets: String(e.sets), reps: e.reps, kg: e.kg ? String(e.kg) : '' })))
  async function save() {
    const kind = d.kind as PlanKind
    const exercises = kind === 'moc' ? ex.filter(e => e.name.trim()).map(e => ({ name: e.name.trim().slice(0, 40), sets: Math.max(1, Math.min(8, parseInt(e.sets) || 3)), reps: (e.reps.trim() || '8–12').slice(0, 14), kg: e.kg ? +e.kg.replace(',', '.') || null : null })) : undefined
    const dur = kind === 'pocitek' ? 0 : Math.max(0, Math.min(360, parseInt(d.dur) || 0))
    const h = dur / 60
    const tss = kind === 'kolo' ? Math.round(h * (d.zone === 'Z5' ? 100 : d.zone === 'Z4' || d.zone === 'test' ? 85 : d.zone === 'Z3' ? 70 : 50)) : kind === 'tek' ? Math.round(h * 78) : kind === 'moc' ? Math.round(h * 60) : kind === 'pohod' ? Math.round(h * 40) : 0
    await savePlanDay({ ...day, kind, title: d.title.trim() || day.title, durationMin: dur, zone: d.zone || null, desc: d.desc.trim(), exercises, tssTarget: tss, optional: kind === day.kind ? day.optional : false, source: 'rules' })
    toast('Dan shranjen.', 'ok'); onClose()
  }
  const set = (i: number, k: keyof ExRow, v: string) => setEx(ex.map((e, j) => (j === i ? { ...e, [k]: v } : e)))
  return (
    <Sheet open onClose={onClose}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Uredi dan</b>
      <div className="row" style={{ gap: 7, flexWrap: 'wrap', margin: '12px 0' }}>{KINDS.map(k => <Chip key={k.k} sm on={d.kind === k.k} onClick={() => setD({ ...d, kind: k.k })}>{k.l}</Chip>)}</div>
      <div className="stack" style={{ gap: 10 }}>
        <div className="field"><label>Naslov</label><input value={d.title} onChange={e => setD({ ...d, title: e.target.value })} /></div>
        {d.kind !== 'pocitek' && <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div className="field"><label>Trajanje <span className="unit">min</span></label><input type="number" inputMode="numeric" value={d.dur} onChange={e => setD({ ...d, dur: e.target.value })} /></div>
          <div className="field"><label>Cona</label><select value={d.zone} onChange={e => setD({ ...d, zone: e.target.value })}>{ZONES.map(z => <option key={z} value={z}>{z || '—'}</option>)}</select></div>
        </div>}
        <div className="field"><label>Opis</label><textarea value={d.desc} onChange={e => setD({ ...d, desc: e.target.value })} rows={3} /></div>
        {d.kind === 'moc' && (
          <div className="field"><label>Vaje <span className="unit">ime · serije · ponovitve · kg</span></label>
            <div className="stack" style={{ gap: 6 }}>
              {ex.map((e, i) => (
                <div key={i} className="exrow" style={{ display: 'grid', gridTemplateColumns: '1fr 44px 70px 50px 26px', gap: 5 }}>
                  <input value={e.name} onChange={x => set(i, 'name', x.target.value)} placeholder="vaja" />
                  <input value={e.sets} inputMode="numeric" onChange={x => set(i, 'sets', x.target.value)} style={{ textAlign: 'center' }} />
                  <input value={e.reps} onChange={x => set(i, 'reps', x.target.value)} style={{ textAlign: 'center' }} />
                  <input value={e.kg} inputMode="decimal" onChange={x => set(i, 'kg', x.target.value)} placeholder="kg" style={{ textAlign: 'center' }} />
                  <button className="chip sm click" onClick={() => setEx(ex.filter((_, j) => j !== i))} aria-label="Odstrani">×</button>
                </div>
              ))}
              <button className="chip sm click" style={{ alignSelf: 'flex-start' }} onClick={() => setEx([...ex, { name: '', sets: '3', reps: '8–12', kg: '' }])}>+ vaja</button>
            </div>
          </div>
        )}
      </div>
      <Btn primary block style={{ marginTop: 14 }} onClick={save}>Shrani</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Prekliči</Btn>
    </Sheet>
  )
}
