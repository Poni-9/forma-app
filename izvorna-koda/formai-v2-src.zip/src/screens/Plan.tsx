import { useEffect, useState } from 'react'
import { Head } from '@/app/Shell'
import { navigate, useRoute } from '@/app/router'
import { useApp, getState, setPlanDone, savePlanDays, savePlanDay, toast, hikeInstead, backToBike, addCore, restorePlanDays, undoLoadAdaptOf } from '@/state/store'
import { snapOf } from '@/state/snap'
import { useAi } from '@/ui/useAi'
import { addDays, fmtDur, weekStartIso } from '@/domain/training/load'
import { buildWeek, weekMinutes, weekBikeMinutes, weekContext, macroWeeks, forecastForm, zoneMinutes, canHike, type PhaseKey } from '@/domain/training/planner'
import { seasonGoals } from '@/domain/training/season'
import { RacesCard } from '@/ui/Races'
import { GoalSheet } from '@/ui/GoalSheet'
import { MoveDaySheet } from '@/ui/MoveDaySheet'
import { canMove } from '@/domain/training/swap'
import { raceLock } from '@/domain/training/protect'
import { zwoFor } from '@/domain/training/zwo'
import { fullHoursWeek, rampStart } from '@/domain/training/goal'
import { DayPlan } from '@/ui/DayPlan'
import { ActivityBox, activityStats, extraActivities } from '@/ui/ActivityBox'
import { dailyTarget } from '@/domain/nutrition/energy'
import { downloadIcs } from '@/domain/training/ics'
import { weekText } from '@/domain/training/share'
import { adaptWeek } from '@/domain/ai/actions'
import { wxShort, wxBad, clothing } from '@/domain/weather'
import type { PlanDay, PlanKind } from '@/domain/types'
import { Card, Chip, CheckBtn, Btn, Track, Sheet, kindColor, kindInk, DAYS_SL, Empty, kindLabelOf } from '@/ui/primitives'
import { bestPlanMatch } from '@/domain/training/plandays'
import { HealthNote } from '@/ui/HealthNote'
import { undoToast } from '@/ui/Confirm'
import { count, dm, num, pct, signed, unit, NBSP, W, withoutFuelLine, plainOH } from '@/ui/format'
import { IcoCal, IcoCheck, IcoPlay } from '@/ui/icons'
import { ChangesCard } from '@/ui/ChangesCard'
import { Term } from '@/ui/HelpSheet'
import { phaseLine, weekCounts } from '@/domain/training/plain'
import { effortOf } from '@/domain/training/effort'
import { isCustom } from '@/domain/focus/model'
import { DealCard } from '@/ui/DealCard'

const KINDS: { k: PlanKind; l: string }[] = [{ k: 'kolo', l: 'Kolo' }, { k: 'tek', l: 'Tek' }, { k: 'test', l: 'Test' }, { k: 'pohod', l: 'Hribi' }, { k: 'moc', l: 'Moč' }, { k: 'pocitek', l: 'Počitek' }]
const PH_COLOR: Record<PhaseKey, string> = { prehod: 'var(--t-poc)', osnova: 'var(--t-kolo)', gradnja: 'var(--warn)', specificno: 'var(--t-moc)', tapering: 'var(--ok)', dirka: 'var(--accent-fg)', po: 'var(--t-poc)' }
const ZONES = ['', 'Z1', 'Z2', 'Z3', 'Z4', 'Z5', 'test']
/** Dan kot gumb, ki izgleda kot vsebina kartice. */
const DAY_BTN: React.CSSProperties = { display: 'block', width: '100%', background: 'none', border: 0, padding: 0, margin: 0, textAlign: 'left', font: 'inherit', color: 'inherit', cursor: 'pointer' }
const blk: React.CSSProperties = { display: 'block' }
/** Na dan najprej kolo/hribi, moč za njim. */
const mocLast = (a: PlanDay, b: PlanDay) => (a.kind === 'moc' ? 1 : 0) - (b.kind === 'moc' ? 1 : 0)

export function Plan() {
  const app = useApp()
  const ai = useAi()
  const route = useRoute()
  const [view, setView] = useState<'prejsnji' | 'ta' | 'naslednji'>(route.params.dan && route.params.dan > addDays(weekStartIso(app.today), 6) ? 'naslednji' : route.params.dan && route.params.dan < weekStartIso(app.today) ? 'prejsnji' : 'ta')
  const [edit, setEdit] = useState<PlanDay | null>(null)
  const [move, setMove] = useState<PlanDay | null>(null)
  const [busy, setBusy] = useState(false)
  const [goalOpen, setGoalOpen] = useState(false)
  // izbrani dan: v naslovu (#/plan?dan=…) brez novega vnosa v zgodovino — Nazaj gre z Načrta, ne po dnevih
  const [focus, setFocus] = useState(route.params.dan || app.today)
  useEffect(() => { if (route.params.dan) setFocus(route.params.dan) }, [route.params.dan])
  function pickDay(date: string) {
    setFocus(date)
    try { history.replaceState(history.state, '', `#/plan?dan=${date}`) } catch { /* brez zgodovine */ }
  }
  // ob odprtju skoči na današnji (ali izbrani) dan — v nedeljo ni treba skrolati čez cel teden
  useEffect(() => { const t = setTimeout(() => document.getElementById(`dan-${route.params.dan || app.today}`)?.scrollIntoView({ block: 'start' }), 80); return () => clearTimeout(t) }, [])  // eslint-disable-line react-hooks/exhaustive-deps
  const ws = weekStartIso(app.today)
  const start = view === 'ta' ? ws : view === 'naslednji' ? addDays(ws, 7) : addDays(ws, -7)
  const days = Array.from({ length: 7 }, (_, i) => addDays(start, i))
  const items = app.plan.filter(d => d.date >= start && d.date <= addDays(start, 6))
  // dan tekme, dan pred njo in polnjenje z OH se ne premikajo (tudi kadar je tekma že v naslednjem tednu)
  const lock = raceLock(app.plan, app.profile)
  const active = items.filter(d => d.kind !== 'pocitek' && !d.optional)
  const done = active.filter(d => d.done).length
  // opravljeno: dejanski čas povezane vožnje (ne načrtovani), sicer načrtovani
  const minsDone = active.filter(d => d.done).reduce((s, d) => { const a = d.done?.activityId ? app.activities.find(x => x.id === d.done!.activityId) : null; return s + (a?.durationMin ? Math.round(a.durationMin) : d.durationMin) }, 0)
  const minsAll = weekMinutes(active)
  const tssAll = active.reduce((s, d) => s + (d.tssTarget || 0), 0)
  const cx = weekContext(app.profile, start)
  const custom = isCustom(app.profile)
  const macro = custom ? [] : macroWeeks(app.profile, app.today)
  const maxH = Math.max(1, ...macro.map(w => w.hours))
  // tedni s cilji sezone (A) in drugimi tekmami (oznake na časovnici)
  const goals = seasonGoals(app.profile)
  const goalWeeks = new Map(goals.map(g => [weekStartIso(g.date), g.name] as const))
  const raceWeeks = new Map<string, string[]>()
  for (const r of app.profile.races || []) { if (r.prio === 'A') continue; const k = weekStartIso(r.date); raceWeeks.set(k, [...(raceWeeks.get(k) || []), r.name]) }
  const fullAt = fullHoursWeek(app.profile, app.today)
  const bikeAll = weekBikeMinutes(active)
  const fc = view === 'ta' && items.length ? forecastForm(app.activities, items, app.today) : null
  const zm = zoneMinutes(items)
  const zTotal = Object.values(zm).reduce((s, x) => s + x, 0)
  const easy = zm.Z1 + zm.Z2
  const daysToEvent = cx.event ? Math.max(0, Math.round((new Date(cx.event.date).getTime() - new Date(app.today).getTime()) / 86400_000)) : 0
  // zdravstveno opozorilo enkrat na zaslon: ob kalorijah odprtega dne (v njegovi kartici), sicer pod tednom
  const focusFirst = items.filter(x => x.date === focus).sort(mocLast)[0]
  const noteInDay = !!focusFirst && focusFirst.kind !== 'pocitek'
    && !!dailyTarget(app.profile, app.activities.filter(a => a.date === focus), app.plan.filter(d => d.date === focus), focus)

  /** Prejšnji (neopravljeni) dnevi teh datumov — »Razveljavi« jih shrani nazaj. */
  const before = (dates: Set<string>) => getState().plan.filter(d => dates.has(d.date) && !d.done)
  async function generate() {
    const rain: Record<string, number> = {}
    if (app.weather) for (const k in app.weather) rain[k] = app.weather[k]!.rain
    const week = buildWeek({ profile: app.profile, activities: app.activities, weekStart: start, rain, firstWeek: !app.plan.length, notBefore: view === 'ta' ? app.today : start })
    const doneDates = new Set(items.filter(d => d.done).map(d => d.date))
    const next = week.filter(d => !doneDates.has(d.date))
    const prev = before(new Set(next.map(d => d.date)))
    await savePlanDays(next)
    const msg = view === 'ta' ? 'Ta teden je sestavljen' : 'Naslednji teden je sestavljen'
    if (prev.length) undoToast(`${msg} znova.`, () => restorePlanDays(prev, next.map(d => d.date)))
    else toast(`${msg}.`, 'ok')
  }
  async function adapt() {
    if (!items.length) return
    setBusy(true)
    const r = await ai.run(() => { const s = getState(); return adaptWeek(snapOf(s), s.plan.filter(d => d.date >= start && d.date <= addDays(start, 6))) })
    setBusy(false)
    if (!r) return
    const changed = r.days.filter(d => !d.done)
    const prev = before(new Set(changed.map(d => d.date)))
    await savePlanDays(changed)
    undoToast(r.summary, () => restorePlanDays(prev, changed.map(d => d.date)), { ms: 9000 })
  }

  /** Teden kot besedilo: deljenje (telefon) ali odložišče (računalnik) — brez imena, teže in kalorij. */
  /** Trening za trenažer (.zwo): samo s trenažerjem, prihodnja neopravljena vožnja ali test (ne dirka). */
  const trainerOk = (d: PlanDay) => !!app.profile.gear?.trainer && (d.kind === 'kolo' || d.kind === 'test') && !d.done && d.role !== 'dirka' && d.date >= app.today
  function downloadZwo(d: PlanDay) {
    const z = zwoFor(d, app.profile)
    if (!z) return
    const a = document.createElement('a')
    a.href = URL.createObjectURL(new Blob([z.xml], { type: 'application/xml' })); a.download = z.name; a.click()
    setTimeout(() => URL.revokeObjectURL(a.href), 5000)
    toast('Trening za trenažer je prenesen (.zwo). Uvoziš ga v aplikacijo, ki bere .zwo — v Zwiftu v mapo Documents/Zwift/Workouts.', 'ok', 8000)
  }
  async function shareWeek() {
    const text = weekText(items, start)
    const nav = navigator as Partial<Pick<Navigator, 'share' | 'clipboard'>>
    try {
      if (typeof nav.share === 'function') { await nav.share({ title: 'FORMAI · teden', text }); return }
    } catch (e) { if ((e as { name?: string })?.name === 'AbortError') return }
    try { await nav.clipboard?.writeText(text); toast('Teden je kopiran — prilepi ga v sporočilo.', 'ok') } catch { toast('Deljenje tu ni na voljo.', 'info') }
  }

  return (<>
    <Head hi={custom ? `${cx.phaseName} · teden ${cx.week}` : cx.event && cx.weeksToEvent != null && cx.weeksToEvent >= 0 ? `${cx.event.name} ${daysToEvent > 13 ? `čez ${count(Math.round(daysToEvent / 7), W.tedenT)}` : daysToEvent ? `čez ${count(daysToEvent, W.danT)}` : 'danes'}` : cx.structured ? `${cx.phaseName} · teden ${cx.week}/${cx.total}` : 'Načrt'} nm={view === 'ta' ? 'Ta teden' : view === 'naslednji' ? 'Naslednji teden' : 'Prejšnji teden'} />
    <div className="scroll">
      <div className="row" style={{ gap: 8, paddingBottom: 12, flexWrap: 'wrap' }}>
        {/* prejšnji teden: pregled, kaj je bilo (opravljeno, ni bilo, prestavljeno) — brez sestavljanja */}
        <Chip on={view === 'prejsnji'} onClick={() => setView('prejsnji')}>Prejšnji</Chip>
        <Chip on={view === 'ta'} onClick={() => setView('ta')}>Ta teden</Chip>
        <Chip on={view === 'naslednji'} onClick={() => setView('naslednji')}>Naslednji</Chip>
        {cx.recovery && <Chip sm>{custom ? 'lažji teden' : 'razbremenilni'}</Chip>}
        {cx.test && <Chip sm>test FTP</Chip>}
      </div>
      {/* najprej z besedami, kaj je ta teden in zakaj; zadnja sprememba načrta (če je sveža) — nato dnevi */}
      {items.length > 0 && view !== 'prejsnji' && (
        <p className="week-plain">{phaseLine(cx)}{weekCounts(items) ? <> {view === 'ta' ? 'Ta' : 'Naslednji'} teden: <b>{weekCounts(items)}</b> · {fmtDur(minsAll)}.</> : null}</p>
      )}
      {view === 'ta' && <ChangesCard compact />}
      <div className="cols plan">
      <div className="col">
      {!items.length ? (
        <Empty icon={<IcoCal width={30} height={30} style={{ color: 'var(--accent-fg)' }} />} title={view === 'ta' ? 'Ta teden še ni sestavljen' : view === 'naslednji' ? 'Naslednji teden še ni sestavljen' : 'Za prejšnji teden ni načrta'} text={view === 'prejsnji' ? 'Načrt se je začel pozneje — tu ni ničesar za pogledati.' : 'Načrt sestavim iz profila, cikla, vremena in tega, kar si že opravil — brez čakanja.'}>
          {view !== 'prejsnji' && <Btn primary sm onClick={generate}>Sestavi teden</Btn>}
        </Empty>
      ) : (<>
        <div className="stack" style={{ gap: 10 }}>
          {days.map((date, i) => {
            const list = items.filter(x => x.date === date).sort(mocLast)
            // vse, kar si ta dan res naredil, a ni bilo v načrtu (dodatna vožnja, tek, hribi, moč): svoj okvirček
            const extra = extraActivities(app.activities, items, date)
            if (!list.length && !extra.length) return null
            const open = focus === date, past = date < app.today
            const dayLabel = `${DAYS_SL[i]!.toUpperCase()} ${+date.slice(8)}.`
            const extraBoxes = extra.map(a => {
              // »to je bil trening iz načrta«: ta dan še neopravljena seja iste vrste (tudi krajša od 40 %)
              const cand = list.filter(x => !x.done && !x.optional && x.kind !== 'pocitek' && (x.kind === a.sport || (x.kind === 'test' && a.sport === 'kolo')))
              const link = bestPlanMatch(a, cand) ?? cand[0] ?? null
              return past && !open
                ? <ActivityBox key={a.id} a={a} compact dayLabel={dayLabel} />
                : <ActivityBox key={a.id} a={a} dayLabel={!list.length ? dayLabel : undefined} onLink={link ? () => { void setPlanDone(link.id, true, a.id); toast(`${a.name} je zdaj ${link.title}.`, 'ok') } : undefined} linkTitle={link ? `to je bil ${link.title}` : undefined} />
            })
            if (!list.length) return <div key={date} id={`dan-${date}`} className="stack" style={{ gap: 10, scrollMarginTop: 8 }}>{extraBoxes}</div>
            // en glavni gumb na dan: »Začni« samo pri prvem neopravljenem treningu
            const firstStart = list.find(x => x.kind !== 'pocitek' && x.kind !== 'pohod' && !x.done && !x.optional)?.id
            const cards = list.map((d, j) => {
              const wx = app.weather?.[date]
              const outdoor = d.kind === 'kolo' || d.kind === 'tek' || d.kind === 'pohod'
              // povezana vožnja/vadba: kaj je bilo v resnici (trajanje, km, utrip, TSS)
              const act = d.done?.activityId ? app.activities.find(a => a.id === d.done!.activityId) : null
              const real = act ? activityStats(act, past && !open ? 2 : 6) : ''
              // pretekli dnevi v eni vrstici — da današnji dan ni skrit pod celim tednom
              if (past && !open) return (
                <button key={d.id} id={j === 0 ? `dan-${date}` : undefined} type="button" className="card tight sess row" style={{ gap: 10, padding: '9px 12px', cursor: 'pointer', opacity: 0.75, scrollMarginTop: 8, width: '100%', textAlign: 'left' }} onClick={() => pickDay(date)} aria-label={`${dayLabel} ${d.kind === 'pocitek' ? 'počitek' : d.title} — odpri`}>
                  <span className="bar" style={{ background: d.optional ? 'var(--t-poc)' : kindColor(d.kind) }} />
                  <span style={{ fontSize: 11, fontWeight: 800, letterSpacing: '.06em', color: d.optional ? 'var(--ink-3)' : kindInk(d.kind), width: 58, flex: 'none' }}>{dayLabel}</span>
                  <b className="clamp2" style={{ fontSize: 13, flex: 1, minWidth: 0 }}>{d.kind === 'pocitek' ? 'Počitek' : d.title}{real ? <span className="muted" style={{ fontWeight: 600 }}> · {real}</span> : null}</b>
                  <span className="muted" style={{ fontSize: 11.5, fontWeight: 700, flex: 'none', display: 'inline-flex', alignItems: 'center' }}>{d.kind === 'pocitek' ? '' : d.done ? <IcoCheck width={14} height={14} aria-label="opravljeno" style={{ color: 'var(--accent-fg)' }} /> : d.optional ? 'po želji' : d.missed === 'moved' ? 'prestavljeno' : 'ni bilo'}</span>
                </button>
              )
              return (
                <Card key={d.id} id={j === 0 ? `dan-${date}` : undefined} tight className={`sess ${date === app.today && !d.optional && d.kind !== 'pocitek' ? 'spot' : ''}`} style={{ borderColor: open && date !== app.today ? 'var(--line)' : undefined, opacity: d.optional && !open ? 0.8 : 1, scrollMarginTop: 8, ['--c' as string]: kindColor(d.kind) }}>
                  <div className="bar" style={{ background: d.optional ? 'var(--t-poc)' : kindColor(d.kind) }} />
                  <div className="row" style={{ gap: 12, alignItems: 'flex-start' }}>
                    {d.kind !== 'pocitek' ? <CheckBtn on={!!d.done} onClick={() => setPlanDone(d.id, !d.done)} /> : <div style={{ width: 26, height: 26, flex: 'none' }} />}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <button type="button" style={DAY_BTN} onClick={() => pickDay(date)} aria-expanded={open}>
                        <span className="between" style={{ display: 'flex' }}>
                          <span style={{ fontSize: 11, fontWeight: 800, letterSpacing: '.08em', color: d.optional ? 'var(--ink-3)' : kindInk(d.kind) }}>{dayLabel} · {kindLabelOf(d).toUpperCase()}</span>
                          {d.optional ? <span className="muted" style={{ fontSize: 11, fontWeight: 700, flex: 'none' }}>po želji</span> : past && !d.done && d.kind !== 'pocitek' ? <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--warn)', flex: 'none' }}>{d.missed === 'moved' ? 'prestavljeno' : 'ni bilo'}</span> : null}
                        </span>
                        <b style={{ ...blk, fontSize: 15 }}>{d.title}</b>
                        <span className="muted" style={{ ...blk, fontSize: 12 }}>{d.kind === 'pocitek' ? d.desc : `${fmtDur(d.durationMin)}${effortOf(d) ? ` · ${effortOf(d)!.w} (${effortOf(d)!.sub})` : ''}${d.exercises?.length ? ` · ${count(d.exercises.length, W.vaja)}` : ''}${open && d.tssTarget && !d.optional ? ` · ${d.tssTarget}${NBSP}TSS` : ''}`}</span>
                        {real && <span style={{ ...blk, fontSize: 12, marginTop: 2, fontWeight: 600, color: 'var(--ink-2)' }}><IcoCheck width={12} height={12} aria-hidden="true" style={{ color: 'var(--accent-fg)', verticalAlign: '-1px', marginRight: 4 }} />{act!.name} · {real}</span>}
                        {outdoor && wx && !d.done && <span style={{ ...blk, fontSize: 11.5, marginTop: 3, fontWeight: 600, color: wxBad(wx) ? 'var(--warn)' : 'var(--ink-3)' }}>{wxShort(wx)}{open ? <span className="muted" style={{ fontWeight: 500 }}> · obleci: {clothing(wx)}</span> : null}</span>}
                      </button>
                      {open && d.kind !== 'pocitek' && (
                        <div style={{ marginTop: 8, fontSize: 13, color: 'var(--ink-2)' }}>
                          {/* gorivo je spodaj (Gorivo) — stavek »… piše v Gorivu« bi bil podvojen */}
                          {plainOH(d.kind === 'kolo' || d.kind === 'test' ? withoutFuelLine(d.desc) : d.desc)}
                          {d.exercises && <div style={{ marginTop: 8 }}>{d.exercises.map((e, k) => <div key={k} className="between" style={{ fontSize: 13, padding: '3px 0', borderTop: k ? '1px solid var(--line)' : 0 }}><b style={{ color: 'var(--ink)', minWidth: 0 }}>{e.name}</b><span className="muted" style={{ flex: 'none' }}>{e.sets} × {e.reps}{e.kg ? ` · ${unit(num(e.kg), 'kg')}` : ''}</span></div>)}</div>}
                          {d.why && <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>Zakaj: {d.why}</div>}
                          <DayPlan day={d} food={j === 0} note={j === 0 && noteInDay} />
                        </div>
                      )}
                    </div>
                  </div>
                  {open && (
                    <div style={{ paddingLeft: 38, marginTop: 10 }}>
                      <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
                        {d.kind !== 'pocitek' && d.kind !== 'pohod' && !d.done && !d.optional && <Btn primary={d.id === firstStart} ghost={d.id !== firstStart} sm onClick={() => navigate('vadba', { id: d.id })}><IcoPlay width={14} height={14} /> Začni</Btn>}
                        <Btn ghost sm onClick={() => setEdit(d)}>{d.kind === 'pocitek' && !d.sickPrev && !d.done ? 'Dodaj trening' : 'Uredi'}</Btn>
                        {canMove(d, app.today, lock) && <Btn ghost sm onClick={() => setMove(d)}>Premakni</Btn>}
                      </div>
                      {/* druge možnosti za ta dan: manjši čipi */}
                      {((date >= app.today && canHike(d)) || (d.swap && !d.done) || (d.adapt?.prev && !d.adapt.off && !d.done) || (date >= app.today && j === list.length - 1 && !list.some(x => x.kind === 'moc') && !d.sickPrev) || trainerOk(d)) && (
                        <div className="row" style={{ gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
                          {d.adapt?.prev && !d.adapt.off && !d.done && <button type="button" className="chip sm click" onClick={async () => { await undoLoadAdaptOf(d.adapt!.after); toast('Vrnjen prvotni načrt.', 'ok') }}>Vrni prvotni trening</button>}
                          {date >= app.today && canHike(d) && <button type="button" className="chip sm click" onClick={async () => { await hikeInstead(d.id); toast('Hribi namesto kolesa — trening za ta dan gre z ure.', 'ok') }}>Hribi namesto kolesa</button>}
                          {d.swap && !d.done && <button type="button" className="chip sm click" onClick={async () => { await backToBike(d.id); toast('Nazaj na kolo.', 'ok') }}>Nazaj na kolo</button>}
                          {trainerOk(d) && <button type="button" className="chip sm click" onClick={() => downloadZwo(d)}>.zwo za trenažer</button>}
                          {date >= app.today && j === list.length - 1 && !list.some(x => x.kind === 'moc') && !d.sickPrev && <button type="button" className="chip sm click" onClick={async () => { await addCore(date); toast('Jedro dodano — po želji, ne šteje v realizacijo.', 'ok') }}>+ jedro po želji</button>}
                        </div>
                      )}
                    </div>
                  )}
                </Card>
              )
            })
            return <div key={date} className="stack" style={{ gap: 10 }}>{cards}{extraBoxes}</div>
          })}
        </div>
        <div className="row" style={{ gap: 8, marginTop: 14, flexWrap: 'wrap' }}>
          {view !== 'prejsnji' && <Btn ghost sm onClick={generate}>Sestavi znova</Btn>}
          {view !== 'prejsnji' && app.user && <Btn ghost sm disabled={ai.busy} onClick={adapt}>{busy && ai.busy ? 'Prilagajam …' : 'AI prilagodi teden'}</Btn>}
          {view !== 'prejsnji' && <Btn ghost sm onClick={() => downloadIcs(items, `formai-${start}.ics`)}>V koledar</Btn>}
          <Btn ghost sm onClick={() => void shareWeek()}>Deli</Btn>
        </div>
        {view !== 'prejsnji' && <p className="muted" style={{ fontSize: 11.5, marginTop: 10 }}>Sestavi znova ohrani opravljene dni. {custom ? 'Kilogrami so iz tvojih zadnjih vadb — ko narediš vse ponovitve, je teža višja.' : 'Vati so iz tvojega FTP — po vsakem testu se posodobijo.'}</p>}
      </>)}
      {/* eno opozorilo na zaslonu: velja za načrt in za kalorije pri dnevu (če ga ni že v odprtem dnevu) */}
      {!noteInDay && <HealthNote kind={items.length ? 'both' : 'plan'} style={{ padding: '0 2px' }} />}
      </div>
      <div className="col side">
      {custom ? <DealCard style={{ marginTop: 0, marginBottom: 12 }} /> : macro.length > 0 ? (
        <Card tight style={{ marginBottom: 12 }}>
          <div className="between" style={{ fontSize: 12, fontWeight: 700, gap: 8 }}><span style={{ minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{goals.length > 1 ? `Sezona · ${count(goals.length, W.cilj)} · naslednji ${cx.event?.name}` : `Pot do dirke · ${cx.event?.name}`}</span><span className="muted" style={{ flex: 'none' }}>teden {cx.week}/{cx.total}</span></div>
          <div style={{ display: 'flex', gap: 2, marginTop: 8, alignItems: 'flex-end', height: 26 }} role="img" aria-label={`Makrocikel: ${count(macro.length, W.teden)}, zdaj ${cx.phaseName}, teden ${cx.week}`}>
            {macro.map(w => <i key={w.weekStart} title={`${dm(w.weekStart)} · ${w.phaseName}${w.easy ? ' · lahek začetek' : ''}${w.recovery && w.phase !== 'prehod' ? ' · razbremenilni' : ''}${w.test ? ' · test' : ''} · ${num(w.hours)} h${goalWeeks.has(w.weekStart) ? ` · CILJ: ${goalWeeks.get(w.weekStart)}` : ''}${raceWeeks.has(w.weekStart) ? ` · tekma: ${raceWeeks.get(w.weekStart)!.join(', ')}` : ''}`}
              style={{ flex: 1, height: goalWeeks.has(w.weekStart) ? '100%' : `${Math.max(12, Math.round((w.hours / maxH) * 100))}%`, background: goalWeeks.has(w.weekStart) ? 'var(--accent-fg)' : PH_COLOR[w.phase], opacity: w.weekStart < start ? 0.35 : w.recovery || w.easy ? 0.55 : 1, borderRadius: 2, outline: w.weekStart === start ? '2px solid var(--ink)' : 'none', outlineOffset: 1, boxShadow: raceWeeks.has(w.weekStart) ? 'inset 0 4px 0 var(--ink)' : undefined }} />)}
          </div>
          <div className="row" style={{ gap: 10, flexWrap: 'wrap', marginTop: 8 }}>
            {(['prehod', 'osnova', 'gradnja', 'specificno'] as PhaseKey[]).filter(k => macro.some(w => w.phase === k)).map(k => {
              // pri več ciljih: faza do prvega cilja (kasneje se gradnja in specifično ponavljata pred vsakim)
              const first = goals[0] ? weekStartIso(goals[0].date) : null
              const inSeg = macro.filter(w => w.phase === k && (!first || w.weekStart <= first || k === 'prehod'))
              const last = (inSeg.length ? inSeg : macro.filter(w => w.phase === k)).slice(-1)[0]!
              const to = addDays(last.weekStart, 6)
              return <span key={k} className="muted" style={{ fontSize: 11, fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: 5 }}><i style={{ width: 8, height: 8, borderRadius: 2, background: PH_COLOR[k], display: 'inline-block' }} />{last.phaseName} do {dm(to)}</span>
            })}
            <span className="muted" style={{ fontSize: 11, fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: 5 }}><i style={{ width: 8, height: 8, borderRadius: 2, background: 'var(--accent)', display: 'inline-block' }} />{goals.length > 1 ? 'cilji A' : 'cilj'}</span>
            {raceWeeks.size > 0 && <span className="muted" style={{ fontSize: 11, fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: 5 }}><i style={{ width: 8, height: 8, borderRadius: 2, background: 'var(--t-poc)', boxShadow: 'inset 0 3px 0 var(--ink)', display: 'inline-block' }} />tekma B/C</span>}
          </div>
          <div className="muted" style={{ fontSize: 11.5, marginTop: 6, fontWeight: 600 }}>{cx.phaseDesc}</div>
        </Card>
      ) : (
        <Card tight style={{ marginBottom: 12 }}>
          <p style={{ fontSize: 13 }}>Brez cilja je načrt ponavljajoč se 12-tedenski cikel. Nastavi dirko (npr. Franja, 13. 6. 2027) in načrt postane makrocikel do nje.</p>
          <Btn sm style={{ marginTop: 10 }} onClick={() => setGoalOpen(true)}>Nastavi cilj</Btn>
        </Card>
      )}
      {view === 'ta' && <ChangesCard skipFresh />}
      {(!custom || (app.profile.races || []).length > 0) && <RacesCard />}
      {items.length > 0 && (
        <Card tight style={{ marginBottom: 12 }}>
          <div className="between" style={{ marginBottom: 8 }}><b style={{ fontSize: 13 }}>Opravljeno</b><span style={{ fontSize: 13, fontWeight: 800, color: 'var(--accent-fg)' }}>{done} / {active.length}</span></div>
          <Track pct={active.length ? (done / active.length) * 100 : 0} color="var(--accent)" />
          <div className="between muted" style={{ fontSize: 12, marginTop: 8, alignItems: 'flex-start' }}><span>{minsDone ? fmtDur(minsDone) : `0${NBSP}min`} od {fmtDur(minsAll)} · obremenitev {tssAll}{NBSP}<Term k="tss">TSS</Term></span>{fc && <span style={{ flex: 'none' }}><Term k="forma">forma</Term> v nedeljo ≈ {signed(fc.tsb, 0)}</span>}</div>
          {custom ? <div className="muted" style={{ fontSize: 12, marginTop: 4 }}>{(() => { const g = active.filter(d => d.kind === 'moc').length, c = active.filter(d => d.kind !== 'moc'); return [g ? `moč ${g}×` : '', c.length ? `kardio ${fmtDur(c.reduce((t, d) => t + d.durationMin, 0))}` : ''].filter(Boolean).join(' · ') })()}{cx.recovery ? ' · lažji teden' : ''}</div> : <div className="muted" style={{ fontSize: 12, marginTop: 4 }}>Na kolesu {fmtDur(bikeAll)} · cilj tedna {unit(num(cx.hours), 'h')}{cx.recovery ? ' (razbremenilni)' : ''}{app.profile.baseHours != null && cx.hours < (app.profile.hoursPerWeek || 0) ? ` · raste od ${unit(num(rampStart(app.profile) ?? 4), 'h')} (+10${NBSP}% na teden) do ${unit(num(app.profile.hoursPerWeek || 0), 'h')}${fullAt && fullAt > start ? ` (od ${dm(fullAt)})` : ''}` : ''}</div>}
          {zTotal > 0 && (
            <div style={{ marginTop: 10 }}>
              <div style={{ display: 'flex', height: 8, borderRadius: 4, overflow: 'hidden', gap: 2 }}>
                {(['Z1', 'Z2', 'Z3', 'Z4', 'Z5'] as const).map((z, i) => zm[z] > 0 && <i key={z} style={{ flex: zm[z], background: ['var(--t-poc)', 'var(--t-kolo)', 'var(--t-tek)', 'var(--warn)', 'var(--t-moc)'][i] }} />)}
              </div>
              <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>{pct(easy / zTotal * 100)} lahko (<Term k="cona">Z1–Z2</Term>) · {pct((zTotal - easy) / zTotal * 100)} težje — cilj: okoli 80 % lahko.</div>
            </div>
          )}
        </Card>
      )}
      </div>
      </div>
    </div>
    {edit && <EditDay day={edit} add={edit.kind === 'pocitek' && !edit.sickPrev && !edit.done} onClose={() => setEdit(null)} />}
    {move && <MoveDaySheet day={move} onClose={() => setMove(null)} />}
    {goalOpen && <GoalSheet open onClose={() => setGoalOpen(false)} />}
    {ai.sheet}
  </>)
}

type ExRow = { name: string; sets: string; reps: string; kg: string }
export type DayForm = { kind: PlanKind; title: string; dur: string; zone: string; desc: string }
/**
 * Urejen dan: druga vrsta, cona ali opis = drug trening — stari vati intervalov, vloga (ključni …) in razlaga
 * ne veljajo več; dan, spremenjen v počitek, ni ključna seja.
 */
export function applyDayEdit(day: PlanDay, d: DayForm, ex: ExRow[]): PlanDay {
  const kind = d.kind
  const exercises = kind === 'moc' ? ex.filter(e => e.name.trim()).map(e => ({ name: e.name.trim().slice(0, 40), sets: Math.max(1, Math.min(8, parseInt(e.sets) || 3)), reps: (e.reps.trim() || '8–12').slice(0, 14), kg: e.kg ? +e.kg.replace(',', '.') || null : null })) : undefined
  const dur = kind === 'pocitek' ? 0 : Math.max(0, Math.min(360, parseInt(d.dur) || 0))
  const h = dur / 60
  const tss = kind === 'kolo' ? Math.round(h * (d.zone === 'Z5' ? 100 : d.zone === 'Z4' || d.zone === 'test' ? 85 : d.zone === 'Z3' ? 70 : 50)) : kind === 'tek' ? Math.round(h * 78) : kind === 'moc' ? Math.round(h * 60) : kind === 'pohod' ? Math.round(h * 40) : 0
  const zone = kind === 'pocitek' ? null : d.zone || null
  const desc = d.desc.trim()
  const redefined = kind !== day.kind || zone !== (day.zone || null) || desc !== day.desc.trim()
  const role: PlanDay['role'] = kind === 'pocitek' ? null : !redefined ? day.role ?? null : kind === 'test' ? 'test' : kind === 'moc' ? 'moc' : null
  return {
    ...day, kind, title: d.title.trim() || day.title, durationMin: dur, zone, desc, exercises, tssTarget: tss,
    optional: kind === day.kind ? day.optional : false, source: 'rules', role,
    ...(redefined ? { target: null, why: null } : {}),
    ...(redefined || dur !== day.durationMin ? { kcalBurn: null } : {}),
    ...(kind !== day.kind ? { swap: null } : {}),
  }
}
/** Dan počitka → nov trening: privzeto lahka vožnja (Z2, 60 min), vse je mogoče spremeniti. */
export const ADD_DEFAULT: DayForm = { kind: 'kolo', title: 'Z2 vzdržljivost', dur: '60', zone: 'Z2', desc: 'Enakomerno v Z2 — pogovorni tempo, kadenca 85–95.' }
/** Načrt po meri: nov trening je lahek tek ali moč (ne vožnja). */
const ADD_RUN: DayForm = { kind: 'tek', title: 'Lahek tek', dur: '40', zone: 'Z2', desc: 'Pogovorni tempo — še lahko govoriš v celih stavkih.' }
const ADD_GYM: DayForm = { kind: 'moc', title: 'Moč po želji', dur: '45', zone: '', desc: 'Vaje vpiši spodaj — kilograme vpiši med vadbo.' }
function EditDay({ day, onClose, add = false }: { day: PlanDay; onClose: () => void; add?: boolean }) {
  const p0 = getState().profile
  const def = isCustom(p0) ? (p0.focus!.sessions.some(x => x.type === 'tek') || !p0.strength.on ? ADD_RUN : ADD_GYM) : ADD_DEFAULT
  const [d, setD] = useState<DayForm>(add ? def : { kind: day.kind, title: day.title, dur: String(day.durationMin || ''), zone: day.zone || '', desc: day.desc })
  const [ex, setEx] = useState<ExRow[]>((day.exercises || []).map(e => ({ name: e.name, sets: String(e.sets), reps: e.reps, kg: e.kg ? String(e.kg) : '' })))
  async function save() {
    await savePlanDay(applyDayEdit(day, d, ex))
    toast(add ? 'Trening dodan — na uro gre sam.' : 'Dan shranjen.', 'ok'); onClose()
  }
  const set = (i: number, k: keyof ExRow, v: string) => setEx(ex.map((e, j) => (j === i ? { ...e, [k]: v } : e)))
  return (
    <Sheet open onClose={onClose} label={add ? 'Dodaj trening' : 'Uredi dan'}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>{add ? 'Dodaj trening' : 'Uredi dan'}</b>
      <div className="row" style={{ gap: 7, flexWrap: 'wrap', margin: '12px 0' }}>{KINDS.map(k => <Chip key={k.k} sm on={d.kind === k.k} onClick={() => setD({ ...d, kind: k.k })}>{k.l}</Chip>)}</div>
      <div className="stack" style={{ gap: 10 }}>
        <div className="field"><label htmlFor="ed-title">Naslov</label><input id="ed-title" value={d.title} onChange={e => setD({ ...d, title: e.target.value })} /></div>
        {d.kind !== 'pocitek' && <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div className="field"><label htmlFor="ed-dur">Trajanje <span className="unit">min</span></label><input id="ed-dur" type="number" inputMode="numeric" value={d.dur} onChange={e => setD({ ...d, dur: e.target.value })} /></div>
          <div className="field"><label htmlFor="ed-zone">Cona</label><select id="ed-zone" value={d.zone} onChange={e => setD({ ...d, zone: e.target.value })} style={{ paddingLeft: 10 }}>{ZONES.map(z => <option key={z} value={z}>{z || '—'}</option>)}</select></div>
        </div>}
        <div className="field"><label htmlFor="ed-desc">Opis</label><textarea id="ed-desc" value={d.desc} onChange={e => setD({ ...d, desc: e.target.value })} rows={3} /></div>
        {d.kind === 'moc' && (
          <div className="field"><label>Vaje <span className="unit">ime · serije · ponovitve · kg</span></label>
            <div className="stack" style={{ gap: 6 }}>
              {ex.map((e, i) => (
                <div key={i} className="exrow" style={{ display: 'grid', gridTemplateColumns: '1fr 44px 70px 50px 26px', gap: 5 }}>
                  <input value={e.name} onChange={x => set(i, 'name', x.target.value)} placeholder="vaja" aria-label="Vaja" />
                  <input value={e.sets} inputMode="numeric" onChange={x => set(i, 'sets', x.target.value)} style={{ textAlign: 'center' }} aria-label="Serije" />
                  <input value={e.reps} onChange={x => set(i, 'reps', x.target.value)} style={{ textAlign: 'center' }} aria-label="Ponovitve" />
                  <input value={e.kg} inputMode="decimal" onChange={x => set(i, 'kg', x.target.value)} placeholder="kg" style={{ textAlign: 'center' }} aria-label="Kilogrami" />
                  <button className="chip sm click" onClick={() => setEx(ex.filter((_, j) => j !== i))} aria-label="Odstrani vajo">×</button>
                </div>
              ))}
              <button className="chip sm click" style={{ alignSelf: 'flex-start' }} onClick={() => setEx([...ex, { name: '', sets: '3', reps: '8–12', kg: '' }])}>+ vaja</button>
            </div>
          </div>
        )}
      </div>
      <Btn primary block style={{ marginTop: 14 }} onClick={save}>Shrani</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Prekliči</Btn>
    </Sheet>
  )
}
