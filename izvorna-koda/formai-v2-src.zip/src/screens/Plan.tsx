import { useEffect, useState, useMemo } from 'react'
import { Head } from '@/app/Shell'
import { navigate, useRoute } from '@/app/router'
import { useApp, getState, setPlanDone, savePlanDays, savePlanDay, toast, hikeInstead, backToBike, addCore, restorePlanDays, undoLoadAdaptOf } from '@/state/store'
import { snapOf } from '@/state/snap'
import { useAi } from '@/ui/useAi'
import { addDays, fmtDur, weekStartIso, titleNoDur } from '@/domain/training/load'
import { buildWeek, weekBikeMinutes, weekContext, planHours, forecastForm, zoneMinutes, canHike, targetHours, type WeekCtx, plannedMacro, defaultZ2 } from '@/domain/training/planner'
import { RacesCard, askOffSeason } from '@/ui/Races'
import { Section } from '@/ui/Section'
import { GoalSheet } from '@/ui/GoalSheet'
import { MoveDaySheet } from '@/ui/MoveDaySheet'
import { canMove } from '@/domain/training/swap'
import { raceLock } from '@/domain/training/protect'
import { zwoFor } from '@/domain/training/zwo'
import { DayPlan } from '@/ui/DayPlan'
import { ActivityBox, activityStats, extraActivities } from '@/ui/ActivityBox'
import { dailyTarget } from '@/domain/nutrition/energy'
import { downloadIcs } from '@/domain/training/ics'
import { weekText } from '@/domain/training/share'
import { adaptWeek } from '@/domain/ai/actions'
import { wxShort, wxBad, clothing } from '@/domain/weather'
import type { PlanDay, PlanKind } from '@/domain/types'
import { Card, Chip, CheckBtn, Btn, Sheet, DAYS_SL, Empty } from '@/ui/primitives'
import { TailRow } from '@/ui/TailRow'
import { bestPlanMatch } from '@/domain/training/plandays'
import { HealthNote } from '@/ui/HealthNote'
import { undoToast } from '@/ui/Confirm'
import { count, dayAcc, dayName, dm, num, pct, signed, unit, NBSP, W, withoutFuelLine, plainOH } from '@/ui/format'
import { IcoCal, IcoCheck, IcoPlay, IcoChevDown } from '@/ui/icons'
import { ChangeDaySheet } from '@/ui/ChangeDaySheet'
// (v3.50) »Dodaj trening → S slike«
import { openPhotoTraining } from '@/ui/photoOpen'
import { ChangesCard, whenOf } from '@/ui/ChangesCard'
import { Term } from '@/ui/HelpSheet'
import { effortOf } from '@/domain/training/effort'
import { isCustom } from '@/domain/focus/model'
import { noRaceWish, plainTerms } from '@/domain/start'
import { DealCard } from '@/ui/DealCard'
import { WeekPauseChip } from '@/ui/WeekPauseSheet'
import { WeekRibbon, WeekProgress, Horizon, SeasonChart, Ahead, restLabel } from '@/ui/PlanHero'
import { ExGrid, gist, hasMore, baseTitle, isRace, raceGist, sessColor, sessInk, sessLabel, SessIcon } from '@/ui/SessBits'

const KINDS: { k: PlanKind; l: string }[] = [{ k: 'kolo', l: 'Kolo' }, { k: 'tek', l: 'Tek' }, { k: 'test', l: 'Test' }, { k: 'pohod', l: 'Hribi' }, { k: 'moc', l: 'Moč' }, { k: 'pocitek', l: 'Počitek' }]
const ZONES = ['', 'Z1', 'Z2', 'Z3', 'Z4', 'Z5', 'test']
/** Dan kot gumb, ki izgleda kot vsebina kartice. */
const DAY_BTN: React.CSSProperties = { display: 'block', width: '100%', background: 'none', border: 0, padding: 0, margin: 0, textAlign: 'left', font: 'inherit', color: 'inherit', cursor: 'pointer' }
const blk: React.CSSProperties = { display: 'block' }
const MON_SL = ['januar', 'februar', 'marec', 'april', 'maj', 'junij', 'julij', 'avgust', 'september', 'oktober', 'november', 'december']
/**
 * Ure na teden po mesecih do cilja (Blaž, 11. 10.: »koliko ur bom imel februarja — je 13,5 h že ta številka?«):
 * za vsak mesec razpon ur rednih tednov (lažji tedni posebej), faza in oznaka tedna, ki teče.
 */
export function monthsOverview(macro: readonly (WeekCtx & { weekStart: string })[], start: string) {
  const m = new Map<string, { ym: string; hi: number; lo: number; easy: number | null; phases: string[]; now: boolean; weeks: number }>()
  for (const w of macro) {
    const ym = w.weekStart.slice(0, 7)
    const x = m.get(ym) ?? { ym, hi: 0, lo: Infinity, easy: null, phases: [], now: false, weeks: 0 }
    x.weeks++
    if (w.recovery) x.easy = x.easy == null ? w.hours : Math.min(x.easy, w.hours)
    else { x.hi = Math.max(x.hi, w.hours); x.lo = Math.min(x.lo, w.hours) }
    if (!x.phases.includes(w.phaseName)) x.phases.push(w.phaseName)
    if (w.weekStart === start) x.now = true
    m.set(ym, x)
  }
  return [...m.values()].map(x => ({ ...x, lo: x.lo === Infinity ? x.easy ?? 0 : x.lo, hi: x.hi || x.easy || 0 }))
}
/**
 * (v3.48) Ena vrstica o urah povsod na Planu (prej 4,5 / 7 / 9,5 / 11 / 12,5 h na istem zaslonu): ure tega tedna iz
 * načrta, normalen teden (izbrane ure) in najtežji teden bloka. »Raste« samo, ko načrt do normalnega tedna še raste.
 */
export function hoursLine(o: { now: number; normal: number; to: number; peak: number; grows: boolean; from?: string | null; wk?: string }): string {
  const h = (x: number) => unit(num(x), 'h')
  const wk = o.wk ?? 'ta teden'
  if (o.grows && o.to > o.now + 0.24) return `${h(o.now)} ${wk} — raste ~10${NBSP}% na teden do ${h(o.to)}${o.from ? ` (od ${dm(o.from)})` : ''}${o.peak > o.to + 0.24 ? `, najtežji teden bloka ~${h(o.peak)}` : ''}.`
  const normal = Math.abs(o.normal - o.now) > 0.24 ? ` · normalen teden ${h(o.normal)}` : ''
  return `${h(o.now)} ${wk}${normal}${o.peak > Math.max(o.normal, o.now) + 0.24 ? ` (najtežji ${normal ? '' : 'teden bloka '}~${h(o.peak)})` : ''}.`
}
export { plannedMacro }
/**
 * (v3.50 B28) Dolg opis (npr. vročina ~700 znakov) pod »Podrobnosti« v odstavkih po stavkih, vsak do ~260 znakov —
 * prej en kos. Stavek se konča s piko za črko (ali »Z2.«), ne za datumom (»13. 6.«).
 */
export function paras(t: string, max = 260): string[] {
  const out: string[] = []
  for (const x of t.trim().split(/(?<=(?:[^\s\d]|[A-Za-z]\d)[.!?])\s+(?=[A-ZČŠŽĆĐ])/)) {
    const last = out[out.length - 1]
    if (last != null && last.length + x.length + 1 <= max) out[out.length - 1] = `${last} ${x}`
    else out.push(x)
  }
  return out
}
/** Na dan najprej kolo/hribi, moč za njim. */
const mocLast = (a: PlanDay, b: PlanDay) => (a.kind === 'moc' ? 1 : 0) - (b.kind === 'moc' ? 1 : 0)

export function Plan() {
  const app = useApp()
  const ai = useAi()
  const route = useRoute()
  const [view, setView] = useState<'prejsnji' | 'ta' | 'naslednji' | 'dva'>(route.params.dan && route.params.dan > addDays(weekStartIso(app.today), 6) ? 'naslednji' : route.params.dan && route.params.dan < weekStartIso(app.today) ? 'prejsnji' : 'ta')
  const [edit, setEdit] = useState<PlanDay | null>(null)
  const [move, setMove] = useState<PlanDay | null>(null)
  const [change, setChange] = useState<PlanDay | null>(null)   // »Spremeni« za dan (vse možnosti v enem listu)
  const [busy, setBusy] = useState(false)
  const [goalOpen, setGoalOpen] = useState(false)
  // stranski razdelki (pot do dirke, spremembe, tekme, opravljeno) so zaprti — ena vrstica; odprt je eden
  // (v3.49) #/plan?sec=pl-tekme (Prvi koraki → »Dodaj tekme sezone«): razdelek odprt in v pogledu (prej vrh Plana, razdelek zaprt)
  const [openSec, setOpenSec] = useState<string | null>(route.params.sec || null)
  const toggleSec = (id: string) => setOpenSec(o => (o === id ? null : id))
  useEffect(() => { const id = route.params.sec; if (!id) return; setOpenSec(id); const t = setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches ? 'auto' : 'smooth', block: 'start' }), 80); return () => clearTimeout(t) }, [route.params.sec])
  // izbrani dan: v naslovu (#/plan?dan=…) brez novega vnosa v zgodovino — Nazaj gre z Načrta, ne po dnevih
  const [focus, setFocus] = useState(route.params.dan || app.today)
  useEffect(() => {
    const d = route.params.dan
    if (!d) return
    setFocus(d)
    // povezava na dan v drugem tednu (npr. iz Danes ali Napredka), ko je Plan že odprt: pokaži tisti teden
    setView(d > addDays(weekStartIso(app.today), 6) ? 'naslednji' : d < weekStartIso(app.today) ? 'prejsnji' : 'ta')
  }, [route.params.dan])  // eslint-disable-line react-hooks/exhaustive-deps
  function pickDay(date: string) {
    setFocus(date)
    try { history.replaceState(history.state, '', `#/plan?dan=${date}`) } catch { /* brez zgodovine */ }
  }
  // pretekli dnevi tega tedna so zloženi (Blaž, 14. 10.: »zgoraj je polno starih podatkov«) — tap v traku jih odpre
  const [pastOpen, setPastOpen] = useState(false)
  function jumpDay(date: string) {
    pickDay(date)
    if (date < app.today) setPastOpen(true)
    setTimeout(() => document.getElementById(`dan-${date}`)?.scrollIntoView({ block: 'center', behavior: matchMedia?.('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' }), 60)
  }
  // ob odprtju z izbranim dnem (iz Danes, Napredka) skoči nanj; sicer ostane vrh (trak tedna in obzorje na prvi pogled)
  useEffect(() => { if (!route.params.dan) return; const t = setTimeout(() => document.getElementById(`dan-${route.params.dan}`)?.scrollIntoView({ block: 'start' }), 80); return () => clearTimeout(t) }, [])  // eslint-disable-line react-hooks/exhaustive-deps
  const ws = weekStartIso(app.today)
  const start = view === 'ta' || view === 'dva' ? ws : view === 'naslednji' ? addDays(ws, 7) : addDays(ws, -7)
  // naslednja dva tedna (14 dni od danes): shranjeni dnevi + okviren teden, ki še ni sestavljen (ne shrani se)
  const ahead = useMemo(() => {
    if (view !== 'dva') return null
    // cele koledarske tedne (prej se je tretji teden končal v petek, vsota tedna pa je izpustila vikend)
    const to = addDays(weekStartIso(addDays(app.today, 13)), 6)
    const stored = app.plan.filter(d => d.date >= app.today && d.date <= to)
    const extra: PlanDay[] = []
    const preview = new Set<string>()
    for (const w of [ws, addDays(ws, 7), addDays(ws, 14)]) {
      if (w > to || stored.some(d => d.date >= w && d.date <= addDays(w, 6))) continue
      for (const d of buildWeek({ profile: app.profile, activities: app.activities, weekStart: w, notBefore: w < app.today ? app.today : w, checkins: app.checkins })) {
        if (d.date >= app.today && d.date <= to) { extra.push(d); preview.add(d.date) }
      }
    }
    return { items: [...stored, ...extra], preview }
  }, [view, app.plan, app.today, app.profile, app.activities, app.checkins, ws])
  /** (v3.50) Menjava tedna: izbran dan je v tem tednu (danes oz. prvi dan) — prej je ostal dan drugega tedna in današnja kartica je bila zaprta. */
  function showView(k: typeof view) {
    setView(k)
    const ws0 = weekStartIso(app.today)
    const f = k === 'ta' || k === 'dva' ? app.today : k === 'naslednji' ? addDays(ws0, 7) : addDays(ws0, -7)
    if (weekStartIso(focus) !== weekStartIso(f)) pickDay(f)
  }
  /** dan iz pregleda dveh tednov: odpri njegov teden in skoči nanj */
  function openFromAhead(d: string) {
    setView(d > addDays(ws, 6) ? 'naslednji' : 'ta')
    jumpDay(d)
  }
  const days = Array.from({ length: 7 }, (_, i) => addDays(start, i))
  const items = app.plan.filter(d => d.date >= start && d.date <= addDays(start, 6))
  // dan tekme, dan pred njo in polnjenje z OH se ne premikajo (tudi kadar je tekma že v naslednjem tednu)
  const lock = raceLock(app.plan, app.profile)
  const active = items.filter(d => d.kind !== 'pocitek' && !d.optional)
  const done = active.filter(d => d.done).length
  const tssAll = active.reduce((s, d) => s + (d.tssTarget || 0), 0)
  // (v3.48) prejšnji teden: obremenitev iz opravljenega (povezana vožnja ali načrtovana, če je dan označen), ne načrtovana
  const tssDone = active.filter(d => d.done).reduce((s, d) => { const a = d.done?.activityId ? app.activities.find(x => x.id === d.done!.activityId) : null; return s + Math.round(a?.tss ?? d.tssTarget ?? 0) }, 0)
  const custom = isCustom(app.profile)
  // (v3.50) začetnik ali »nimam ure« pri načrtu po meri brez ure: »lahko« brez »(Z2)« in brez TSS
  const plain = plainTerms(app.profile, !!app.settings.intervals)
  // ure tedna, kot so res v načrtu (rast od tega, kar voziš) — prej zgornja meja faze (9,5 h pri 1 h 45 min v načrtu)
  const cx = (() => { const c = weekContext(app.profile, start); return custom ? c : { ...c, hours: planHours(app.profile, app.activities, start, app.today, app.plan).hours } })()
  // (v3.48) sezona in ure po mesecih iz ur načrta, ne iz zgornje meje faze
  const macro = useMemo(() => (custom ? [] : plannedMacro(app.profile, app.activities, app.today, app.plan)), [custom, app.profile, app.activities, app.today, app.plan])
  const months = macro.length ? monthsOverview(macro, start) : []
  // (v3.48) ena vrstica o urah: tedni naprej (brez cilja 12 tednov), normalen teden = izbrane ure, najtežji teden bloka
  const fut = custom ? [] : macro.length ? macro.filter(w => w.weekStart > start) : Array.from({ length: 12 }, (_, k) => { const w = addDays(start, 7 * (k + 1)); return { ...weekContext(app.profile, w), weekStart: w, hours: planHours(app.profile, app.activities, w, app.today, app.plan).hours } })
  const load = fut.filter(w => !w.recovery && w.phase !== 'tapering' && w.phase !== 'dirka' && w.phase !== 'po' && w.phase !== 'prehod')
  const peakH = Math.max(cx.hours, ...fut.filter(w => !w.recovery).map(w => w.hours))
  const normalH = targetHours(app.profile)
  const toH = Math.min(normalH, Math.max(cx.hours, ...load.map(w => w.hours)))
  const fullAt = load.find(w => w.hours >= toH - 0.01)?.weekStart ?? null
  const wkWord = view === 'naslednji' ? 'naslednji teden' : view === 'prejsnji' ? 'prejšnji teden' : 'ta teden'
  const grows = !cx.recovery && cx.phase !== 'tapering' && cx.phase !== 'dirka' && cx.phase !== 'po' && cx.phase !== 'prehod'
  const hLine = hoursLine({ now: cx.hours, normal: normalH, to: toH, peak: peakH, grows, from: fullAt, wk: `${wkWord}${cx.recovery ? ' (razbremenilni)' : ''}` })
  const bikeAll = weekBikeMinutes(active)
  // (v3.48) teden tekme: treningi in tekma posebej (prej »Na kolesu 6 h 55 min · cilj tedna 4,5 h« z dirko v vsoti)
  const raceMin = weekBikeMinutes(active.filter(d => d.role === 'dirka'))
  const raceWeek = raceMin > 0 || cx.phase === 'tapering' || cx.phase === 'dirka'
  const fc = view === 'ta' && items.length ? forecastForm(app.activities, items, app.today) : null
  const zm = zoneMinutes(items, app.profile)
  const zTotal = Object.values(zm).reduce((s, x) => s + x, 0)
  const easy = zm.Z1 + zm.Z2
  const daysToEvent = cx.event ? Math.max(0, Math.round((new Date(cx.event.date).getTime() - new Date(app.today).getTime()) / 86400_000)) : 0
  // (v3.50 H39) dogovor ob koncu tedna: do ponedeljka uvodni dnevi — ne »Teden 1« v nedeljo in spet v ponedeljek (načrt po meri, brez cilja z datumom)
  const preStart = (view === 'ta' || view === 'dva') && !!app.profile.cycleStart && start < app.profile.cycleStart && (custom || !cx.event)
  // zdravstveno opozorilo enkrat na zaslon: ob kalorijah odprtega dne (v njegovi kartici), sicer pod tednom
  const focusFirst = items.filter(x => x.date === focus).sort(mocLast)[0]
  const noteInDay = !!focusFirst && focusFirst.kind !== 'pocitek' && focus >= app.today
    && !!dailyTarget(app.profile, app.activities.filter(a => a.date === focus), app.plan.filter(d => d.date === focus), focus)

  /** Prejšnji (neopravljeni) dnevi teh datumov — »Razveljavi« jih shrani nazaj. */
  const before = (dates: Set<string>) => getState().plan.filter(d => dates.has(d.date) && !d.done)
  async function generate() {
    const rain: Record<string, number> = {}
    if (app.weather) for (const k in app.weather) rain[k] = app.weather[k]!.rain
    const week = buildWeek({ profile: app.profile, activities: app.activities, weekStart: start, rain, firstWeek: !app.plan.length, notBefore: view === 'ta' ? app.today : start, done: items.filter(d => d.done).map(d => ({ date: d.date, kind: d.kind })) })
    const doneDates = new Set(items.filter(d => d.done).map(d => d.date))
    const next = week.filter(d => !doneDates.has(d.date))
    const prev = before(new Set(next.map(d => d.date)))
    await savePlanDays(next)
    const msg = view === 'ta' ? 'Ta teden je sestavljen' : 'Naslednji teden je sestavljen'
    if (prev.length) undoToast(`${msg} znova.`, () => restorePlanDays(prev, next.map(d => d.date)))
    else toast(`${msg}.`, 'ok')
  }
  async function adapt() {
    if (!items.length) return
    setBusy(true)
    const r = await ai.run(() => { const s = getState(); return adaptWeek(snapOf(s), s.plan.filter(d => d.date >= start && d.date <= addDays(start, 6))) })
    setBusy(false)
    if (!r) return
    const changed = r.days.filter(d => !d.done)
    const prev = before(new Set(changed.map(d => d.date)))
    await savePlanDays(changed)
    undoToast(r.summary, () => restorePlanDays(prev, changed.map(d => d.date)), { ms: 9000 })
  }

  /** Teden kot besedilo: deljenje (telefon) ali odložišče (računalnik) — brez imena, teže in kalorij. */
  /** Trening za trenažer (.zwo): samo s trenažerjem, prihodnja neopravljena vožnja ali test (ne dirka). */
  const trainerOk = (d: PlanDay) => !!app.profile.gear?.trainer && (d.kind === 'kolo' || d.kind === 'test') && !d.done && d.role !== 'dirka' && d.date >= app.today
  async function downloadZwo(d: PlanDay) {
    const z = zwoFor(d, app.profile)
    if (!z) return
    // (v3.50) na telefonu »Deli« datoteko (Zwift Companion, Datoteke, pošta …) — mape Documents/Zwift/Workouts tam ni
    const nav = navigator as Partial<Pick<Navigator, 'share' | 'canShare'>>
    try {
      const file = typeof File === 'function' ? new File([z.xml], z.name, { type: 'application/xml' }) : null
      if (file && typeof nav.share === 'function' && nav.canShare?.({ files: [file] })) { await nav.share({ files: [file], title: d.title }); return }
    } catch (e) { if ((e as { name?: string })?.name === 'AbortError') return }
    const a = document.createElement('a')
    a.href = URL.createObjectURL(new Blob([z.xml], { type: 'application/xml' })); a.download = z.name; a.click()
    setTimeout(() => URL.revokeObjectURL(a.href), 5000)
    toast('Trening (.zwo) je prenesen. Na računalniku ga daš v Documents/Zwift/Workouts, na telefonu ga pošlji v aplikacijo, ki bere .zwo.', 'ok', 8000)
  }
  async function shareWeek() {
    const text = weekText(items, start, app.profile)
    const nav = navigator as Partial<Pick<Navigator, 'share' | 'clipboard'>>
    try {
      if (typeof nav.share === 'function') { await nav.share({ title: 'FORMAI · teden', text }); return }
    } catch (e) { if ((e as { name?: string })?.name === 'AbortError') return }
    try { await nav.clipboard?.writeText(text); toast('Teden je kopiran — prilepi ga v sporočilo.', 'ok') } catch { toast('Deljenje tu ni na voljo.', 'info') }
  }

  return (<>
    <Head hi={preStart ? `Začneš v ${dayAcc(app.profile.cycleStart!)}, ${dm(app.profile.cycleStart!)}` : custom ? `Teden ${cx.week}${cx.recovery ? ' · lažji teden' : ''}` : cx.event && cx.weeksToEvent != null && cx.weeksToEvent >= 0 ? `${cx.event.name} ${daysToEvent > 13 ? `čez ${count(Math.round(daysToEvent / 7), W.tedenT)}` : daysToEvent === 1 ? 'jutri' : daysToEvent ? `čez ${count(daysToEvent, W.danT)}` : 'danes'}` : cx.structured ? `${cx.phaseName} · teden ${cx.week}/${cx.total}` : 'Načrt'} nm={view === 'ta' ? 'Ta teden' : view === 'naslednji' ? 'Naslednji' : view === 'dva' ? '2 tedna' : 'Prejšnji'} />
    <div className="scroll">
      {/* pogled v eni vrstici (segmenti) — prej sta bili dve vrstici čipov */}
      <div className="seg" role="group" aria-label="Kateri teden">
        {/* prejšnji teden: pregled, kaj je bilo (opravljeno, ni bilo, prestavljeno) — brez sestavljanja */}
        {([['prejsnji', 'Prejšnji'], ['ta', 'Ta teden'], ['naslednji', 'Naslednji'], ['dva', '2 tedna']] as const).map(([k, t]) => (
          <button key={k} type="button" className={view === k ? 'on' : ''} aria-pressed={view === k} onClick={() => showView(k)}>{t}</button>
        ))}
      </div>
      {/* (v3.50) »Ta teden …« (premor do nedelje) v glavi tekočega tedna */}
      {(cx.recovery || cx.test || view === 'ta') && (
        <div className="row" style={{ gap: 8, marginTop: -4, paddingBottom: 10, flexWrap: 'wrap' }}>
          {cx.recovery && <Chip sm>{custom ? 'lažji teden' : 'razbremenilni'}</Chip>}
          {cx.test && <Chip sm>test FTP</Chip>}
          {view === 'ta' && <WeekPauseChip />}
        </div>
      )}
      {view === 'dva' && ahead ? (<>
        <Ahead items={ahead.items} preview={ahead.preview} today={app.today} onPick={openFromAhead} />
        {custom ? <Horizon profile={app.profile} today={app.today} plan={app.plan} /> : macro.length > 0 ? <SeasonChart key={start} macro={macro} profile={app.profile} start={start} today={app.today} /> : null}
      </>) : (<>
      {/* na prvi pogled: trak tedna (barva in ikona vadbe, opravljeno, danes), napredek, nato obzorje (tedni ali sezona) */}
      {items.length > 0 && <WeekRibbon days={days} items={items} today={app.today} focus={focus} onPick={jumpDay} />}
      {items.length > 0 && view !== 'naslednji' && <WeekProgress items={items} activities={app.activities} />}
      {view !== 'prejsnji' && (custom ? <Horizon profile={app.profile} today={app.today} plan={app.plan} /> : macro.length > 0 ? <SeasonChart key={start} macro={macro} profile={app.profile} start={start} today={app.today} /> : null)}
      <div className="cols plan">
      <div className="col">
      {!items.length ? (
        <Empty icon={<IcoCal width={30} height={30} style={{ color: 'var(--accent-fg)' }} />} title={view === 'ta' ? 'Ta teden še ni sestavljen' : view === 'naslednji' ? 'Naslednji teden še ni sestavljen' : 'Za prejšnji teden ni načrta'} text={view === 'prejsnji' ? 'Načrt se je začel pozneje — tu ni ničesar za pogledati.' : 'Načrt sestavim iz profila, cikla, vremena in tega, kar si že opravil — brez čakanja.'}>
          {view !== 'prejsnji' && <Btn primary sm onClick={generate}>Sestavi teden</Btn>}
        </Empty>
      ) : (<>
        <div className="stack" style={{ gap: 10 }}>
          {(() => {
            // ta teden: pretekli dnevi zloženi v eno vrstico (odpre jih tap ali izbran pretekli dan v traku)
            const pastDates = view === 'ta' ? days.filter(d => d < app.today) : []
            const pastItems = items.filter(x => pastDates.includes(x.date) && x.kind !== 'pocitek' && !x.optional)
            const showPast = pastOpen || pastDates.includes(focus)
            if (!pastItems.length) return null
            const pd = pastItems.filter(x => x.done).length
            return <button type="button" className="pl-past-t" onClick={() => setPastOpen(!showPast)} aria-expanded={showPast}><span>Pretekli dnevi tega tedna</span><span className="muted">{pd}/{pastItems.length} opravljeno <IcoChevDown width={14} height={14} aria-hidden="true" style={{ transform: showPast ? 'rotate(180deg)' : undefined, verticalAlign: '-2px' }} /></span></button>
          })()}
          {days.filter(date => view !== 'ta' || date >= app.today || pastOpen || (focus < app.today && days.includes(focus))).map(date => {
            const i = days.indexOf(date)
            const list0 = items.filter(x => x.date === date).sort(mocLast)
            // pretekli dan: opravljena vadba nadomesti neopravljeno iste vrste (prej dvakrat »PON 12.«: ni bilo + opravljeno)
            const doneKinds = new Set(list0.filter(x => x.done).map(x => x.kind))
            const list = date < app.today ? list0.filter(x => x.done || !doneKinds.has(x.kind)) : list0
            // vse, kar si ta dan res naredil, a ni bilo v načrtu (dodatna vožnja, tek, hribi, moč): svoj okvirček
            const extra = extraActivities(app.activities, items, date)
            if (!list.length && !extra.length) return null
            const open = focus === date, past = date < app.today
            const dayLabel = `${DAYS_SL[i]!.toUpperCase()} ${+date.slice(8)}.`
            const extraBoxes = extra.map(a => {
              // »to je bil trening iz načrta«: ta dan še neopravljena seja iste vrste (tudi krajša od 40 %)
              const cand = list.filter(x => !x.done && !x.optional && x.kind !== 'pocitek' && (x.kind === a.sport || (x.kind === 'test' && a.sport === 'kolo')))
              const link = bestPlanMatch(a, cand) ?? cand[0] ?? null
              return past && !open
                ? <ActivityBox key={a.id} a={a} compact dayLabel={dayLabel} />
                : <ActivityBox key={a.id} a={a} dayLabel={!list.length ? dayLabel : undefined} onLink={link ? () => { void setPlanDone(link.id, true, a.id); toast(`${a.name} je zdaj ${link.title}.`, 'ok') } : undefined} linkTitle={link ? `to je bil ${link.title}` : undefined} />
            })
            if (!list.length) return <div key={date} id={`dan-${date}`} className="stack" style={{ gap: 10, scrollMarginTop: 8 }}>{extraBoxes}</div>
            // en glavni gumb na dan: »Začni« samo pri prvem neopravljenem treningu
            const firstStart = list.find(x => x.kind !== 'pocitek' && x.kind !== 'pohod' && !x.done && !x.optional)?.id
            const cards = list.map((d, j) => {
              const wx = app.weather?.[date]
              const outdoor = d.kind === 'kolo' || d.kind === 'tek' || d.kind === 'pohod'
              // povezana vožnja/vadba: kaj je bilo v resnici (trajanje, km, utrip, TSS)
              const act = d.done?.activityId ? app.activities.find(a => a.id === d.done!.activityId) : null
              const real = act ? activityStats(act, past && !open ? 2 : 6) : ''
              // pretekli dnevi in dnevi počitka v eni vrstici — da so treningi na očeh
              if ((past || d.kind === 'pocitek') && !open) return (
                <button key={d.id} id={j === 0 ? `dan-${date}` : undefined} type="button" className="card tight sess row" style={{ gap: 10, padding: '9px 12px', cursor: 'pointer', opacity: 0.75, scrollMarginTop: 8, width: '100%', textAlign: 'left' }} onClick={() => pickDay(date)} aria-label={`${dayLabel} ${d.kind === 'pocitek' ? restLabel(d).toLowerCase() : d.title} — odpri`}>
                  <span className="bar" style={{ background: d.optional ? 'var(--t-poc)' : sessColor(d) }} />
                  <span style={{ fontSize: 11, fontWeight: 800, letterSpacing: '.06em', color: d.optional ? 'var(--ink-3)' : sessInk(d), width: 58, flex: 'none' }}>{dayLabel}</span>
                  {/* dan polnjenja z OH ni samo »Počitek« (v3.48) */}
                  <b className="clamp2" style={{ fontSize: 13, flex: 1, minWidth: 0 }}>{d.kind === 'pocitek' ? restLabel(d) : d.title}{real ? <span className="muted" style={{ fontWeight: 600 }}> · {real}</span> : null}</b>
                  <span className="muted" style={{ fontSize: 11.5, fontWeight: 700, flex: 'none', display: 'inline-flex', alignItems: 'center' }}>{d.kind === 'pocitek' ? '' : d.done ? <IcoCheck width={14} height={14} aria-label="opravljeno" style={{ color: 'var(--accent-fg)' }} /> : d.optional ? 'po želji' : d.missed === 'moved' ? 'prestavljeno' : 'ni označeno'}</span>
                </button>
              )
              return (
                <Card key={d.id} id={j === 0 ? `dan-${date}` : undefined} tight className={`sess pl-card ${date === app.today && !d.optional && d.kind !== 'pocitek' ? 'spot' : d.kind !== 'pocitek' && !d.optional && !past ? 'tint' : ''}`} style={{ opacity: d.optional && !open ? 0.8 : 1, scrollMarginTop: 8, ['--c' as string]: sessColor(d), ['--i' as string]: i }}>
                  <div className="bar" style={{ background: d.optional ? 'var(--t-poc)' : sessColor(d) }} />
                  <div className="row" style={{ gap: 12, alignItems: 'flex-start' }}>
                    {/* (v3.50) prihodnji dan: kljukica še ni na vrsti (prej »opravljeno« čez dva dni) */}
                    {d.kind !== 'pocitek' ? <CheckBtn on={!!d.done} disabled={date > app.today} onClick={() => setPlanDone(d.id, !d.done)} label={`${dayName(date)}, ${dm(date)}: ${titleNoDur(d.title, d.durationMin)}`} /> : <div style={{ width: 26, height: 26, flex: 'none' }} />}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <button type="button" style={DAY_BTN} onClick={() => pickDay(date)} aria-expanded={open}>
                        <span className="between" style={{ display: 'flex' }}>
                          {/* dan tekme: »TEKMA« s pokalom v barvi poudarka (prej »KOLO«) (v3.48) */}
                          <span className={`kbadge sm${isRace(d) ? ' race' : ''}`} style={{ color: d.optional ? 'var(--ink-3)' : sessInk(d) }}>{d.kind !== 'pocitek' && <span className="ki" aria-hidden="true"><SessIcon d={d} size={13} /></span>}{date === app.today ? 'DANES' : dayLabel} · {sessLabel(d).toUpperCase()}</span>
                          {d.optional ? <span className="muted" style={{ fontSize: 11, fontWeight: 700, flex: 'none' }}>po želji</span> : past && !d.done && d.kind !== 'pocitek' ? <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--warn)', flex: 'none' }}>{d.missed === 'moved' ? 'prestavljeno' : 'ni označeno'}</span> : null}
                        </span>
                        <b style={{ ...blk, fontSize: 15 }}>{open ? baseTitle(d) : titleNoDur(d.title, d.durationMin)}</b>
                        <span className="muted" style={{ ...blk, fontSize: 12 }}>{d.kind === 'pocitek' ? d.desc : `${fmtDur(d.durationMin)}${effortOf(d) ? ` · ${effortOf(d)!.w}${plain && /^Z\d/.test(effortOf(d)!.sub) ? '' : ` (${effortOf(d)!.sub})`}` : ''}${d.exercises?.length ? ` · ${count(d.exercises.length, W.vaja)}` : ''}${open && d.tssTarget && !d.optional && !plain ? ` · ${d.tssTarget}${NBSP}TSS` : ''}`}</span>
                        {real && <span style={{ ...blk, fontSize: 12, marginTop: 2, fontWeight: 600, color: 'var(--ink-2)' }}><IcoCheck width={12} height={12} aria-hidden="true" style={{ color: 'var(--accent-fg)', verticalAlign: '-1px', marginRight: 4 }} />{act!.name} · {real}</span>}
                        {outdoor && wx && !d.done && <span style={{ ...blk, fontSize: 11.5, marginTop: 3, fontWeight: 600, color: wxBad(wx) ? 'var(--warn)' : 'var(--ink-3)' }}>{wxShort(wx)}{open ? <span className="muted" style={{ fontWeight: 500 }}> · obleci: {clothing(wx)}</span> : null}</span>}
                      </button>
                      {open && d.kind !== 'pocitek' && (
                        <div style={{ marginTop: 6, fontSize: 13, color: 'var(--ink-2)' }}>
                          {/* na hitro (Blaž, 16. 10.): en stavek, vaje kot ploščice, kardio v vrstici; opis in »zakaj« pod Podrobnosti.
                              gorivo je spodaj (Gorivo) — stavek »… piše v Gorivu« bi bil podvojen */}
                          {(() => {
                            const full = plainOH(d.kind === 'kolo' || d.kind === 'test' ? withoutFuelLine(d.desc) : d.desc)
                            // tekma: bistvo je tempo, zajtrk in ves opis pod »Podrobnosti« (kot na Danes, v3.48)
                            const lead = isRace(d) ? raceGist(full) : gist(full)
                            const fullMore = isRace(d) ? full.trim().length > 0 : hasMore(full)
                            return (<>
                              {lead && <p className="sess-gist" style={{ marginTop: 0 }}>{lead}</p>}
                              {d.exercises?.length ? <ExGrid exercises={d.exercises} /> : null}
                              {d.tail && <TailRow tail={d.tail} brief />}
                              {(fullMore || d.why || d.tail?.desc) && (
                                <details className="more">
                                  <summary>Podrobnosti</summary>
                                  <div>
                                    {fullMore && paras(full).map((x, k) => <p key={k} style={{ margin: k ? '6px 0 0' : 0 }}>{x}</p>)}
                                    {d.tail?.desc && <p style={{ margin: '6px 0 0' }}><b style={{ color: 'var(--ink-2)' }}>Nato:</b> {d.tail.desc}</p>}
                                    {d.why && <p style={{ margin: '6px 0 0' }}><b style={{ color: 'var(--ink-2)' }}>Zakaj:</b> {d.why}</p>}
                                  </div>
                                </details>
                              )}
                            </>)
                          })()}
                          <DayPlan day={d} food={j === 0} note={j === 0 && noteInDay} />
                        </div>
                      )}
                    </div>
                  </div>
                  {open && (
                    <div style={{ paddingLeft: 38, marginTop: 10 }}>
                      {/* dva gumba (Blaž, 11. 10.: čim manj tipk): začni in spremeni — vse drugo je v listu »Spremeni« */}
                      <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
                        {/* (v3.49) pretekli dan: »Opravil« (brez ure pozabljena kljukica), ne »Začni« — tudi za že prestavljen (setPlanDone vrne ciljni dan) */}
                        {past && d.kind !== 'pocitek' && !d.done
                          ? <Btn ghost sm onClick={() => void setPlanDone(d.id, true)}><IcoCheck width={15} height={15} /> Opravil</Btn>
                          : d.kind !== 'pocitek' && d.kind !== 'pohod' && !d.done && !d.optional && <Btn primary={d.id === firstStart} ghost={d.id !== firstStart} sm onClick={() => navigate('vadba', { id: d.id })}><IcoPlay width={14} height={14} /> Začni</Btn>}
                        {d.kind === 'pocitek' && !d.sickPrev && !d.done
                          ? <Btn ghost sm onClick={() => setEdit(d)}>Dodaj trening</Btn>
                          : <Btn ghost sm onClick={() => setChange(d)}>Spremeni <IcoChevDown width={15} height={15} aria-hidden="true" /></Btn>}
                      </div>
                    </div>
                  )}
                </Card>
              )
            })
            return <div key={date} className="stack" style={{ gap: 10 }}>{cards}{extraBoxes}</div>
          })}
        </div>
        {/* redke možnosti kot drobni čipi (ne gumbi): teden znova, AI, koledar, deli */}
        <div className="row" style={{ gap: 6, marginTop: 14, marginBottom: 12, flexWrap: 'wrap' }}>
          {view !== 'prejsnji' && app.user && <button type="button" className="chip sm click" disabled={ai.busy} onClick={adapt}>{busy && ai.busy ? 'Prilagajam …' : 'AI prilagodi teden'}</button>}
          {view !== 'prejsnji' && <button type="button" className="chip sm click" onClick={generate}>sestavi znova</button>}
          {view !== 'prejsnji' && <button type="button" className="chip sm click" onClick={() => openPhotoTraining({ mode: 'plan', date: days.find(x => x >= app.today) ?? app.today })}>trening s slike</button>}
          {view !== 'prejsnji' && <button type="button" className="chip sm click" onClick={() => downloadIcs(items, `formai-${start}.ics`, { trainTime: app.profile.trainTime })}>v koledar</button>}
          <button type="button" className="chip sm click" onClick={() => void shareWeek()}>deli</button>
        </div>
      </>)}
      {/* eno opozorilo na zaslonu: velja za načrt in za kalorije pri dnevu (če ga ni že v odprtem dnevu) */}
      {!noteInDay && <HealthNote kind={items.length ? 'both' : 'plan'} style={{ padding: '0 2px' }} />}
      </div>
      <div className="col side">
      {/* stolpci tednov so že v »Naslednji tedni« — v dogovoru na Planu jih ni dvakrat */}
      {custom ? <DealCard bars={view === 'prejsnji'} style={{ marginTop: 0, marginBottom: 12 }} /> : macro.length > 0 ? (
        <Section id="pl-pot" title="Ure na teden po mesecih" sum={`teden ${cx.week}/${cx.total} · ${unit(num(cx.hours), 'h')}${Math.abs(normalH - cx.hours) > 0.24 ? ` · normalen ${unit(num(normalH), 'h')}` : ''}`} open={openSec === 'pl-pot'} onToggle={() => toggleSec('pl-pot')}>
          <div className="muted" style={{ fontSize: 11.5, marginTop: 2, fontWeight: 600 }}>{cx.phaseDesc}</div>
          {/* ure po mesecih: kdaj koliko — da veš, ali je današnja številka že končna (brez ponovljenega naslova, v3.48) */}
          {months.length > 1 && (
            <div style={{ marginTop: 10 }}>
              <p className="muted" style={{ fontSize: 12, margin: '0 0 6px' }}>{hLine} Lažji teden v oklepaju.</p>
              <div className="stack" style={{ gap: 0 }}>
                {months.map(x => (
                  <div key={x.ym} className="between" style={{ fontSize: 12.5, padding: '5px 0', borderTop: '1px solid var(--line-soft)', fontWeight: x.now ? 800 : 500 }}>
                    <span style={{ minWidth: 0 }}>{MON_SL[+x.ym.slice(5, 7) - 1]} {x.ym.slice(0, 4)}{x.now ? <span style={{ color: 'var(--accent-fg)' }}> · zdaj</span> : null}<span className="muted" style={{ fontWeight: 600 }}> · {x.phases.join(' → ').toLowerCase()}</span></span>
                    <span style={{ flex: 'none' }}>{x.lo < x.hi - 0.24 ? `${num(x.lo)}–${num(x.hi)}` : num(x.hi)}{NBSP}h{x.easy != null && x.easy < x.lo - 0.24 ? <span className="muted"> ({num(x.easy)})</span> : null}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </Section>
      ) : (() => {
        // dirka kot predlog samo za tekmovalne cilje — pri hujšanju ali formi brez vsiljevanja (kot GoalCard, v3.48)
        // (v3.50) »nimam tekme, zdravje«: brez »Nastavi dirko« (kot kartica cilja na Danes)
        const noRace = noRaceWish(app.profile)
        const race = (!app.profile.goal || app.profile.goal === 'dirka' || app.profile.goal === 'hitrejsi') && !noRace
        return (
          <Card tight style={{ marginBottom: 12 }}>
            <p style={{ fontSize: 13 }}>{race ? 'Brez cilja je načrt ponavljajoč se 12-tedenski cikel. Nastavi dirko (npr. Franja, 13. 6. 2027) in načrt postane makrocikel do nje.' : noRace ? 'Brez tekme načrt teče v 12-tedenskih ciklih za formo in zdravje. Cilj z datumom lahko dodaš kadar koli.' : 'Načrt teče v 12-tedenskih ciklih. Imaš tekmo ali cilj z datumom? Dodaj ga.'}</p>
            <Btn sm style={{ marginTop: 10 }} onClick={() => setGoalOpen(true)}>{race ? 'Nastavi cilj' : 'Dodaj cilj'}</Btn>
          </Card>
        )
      })()}
      {/* številke tedna brez ponavljanja vrstice napredka zgoraj (»0/1 · 0 min od 1 h 45 min« je bilo dvakrat):
          obremenitev, forma v nedeljo, kolo ali moč/kardio in razmerje lahko : težje */}
      {/* (v3.50) teden brez treninga: razdelka ni (prej »0 / 0 opravljeno«) */}
      {items.length > 0 && active.length > 0 && (!custom || done > 0 || zTotal > 0) && (
        <Section id="pl-opravljeno" title="Teden v številkah" sum={[plain ? `${fmtDur(active.reduce((t, d) => t + d.durationMin, 0))} · ${count(active.length, W.vadba)}` : tssAll ? (view === 'prejsnji' ? `${tssDone} od ${tssAll}${NBSP}TSS opravljenih` : `${tssAll}${NBSP}TSS`) : '', zTotal ? `${pct(easy / zTotal * 100)} lahko` : ''].filter(Boolean).join(' · ') || `${done} / ${active.length} opravljeno`} open={openSec === 'pl-opravljeno'} onToggle={() => toggleSec('pl-opravljeno')}>
          {/* prejšnji teden: opravljeno od načrtovanega (prej »obremenitev 356 TSS« pri 0/7 opravljenih, v3.48); (v3.50) brez TSS in forme za začetnika brez ure */}
          {!plain && <div className="between muted" style={{ fontSize: 12, marginTop: 4, alignItems: 'flex-start' }}><span>{view === 'prejsnji' ? <>{tssDone} od {tssAll}{NBSP}<Term k="tss">TSS</Term> opravljenih</> : <>obremenitev {tssAll}{NBSP}<Term k="tss">TSS</Term></>}</span>{fc && <span style={{ flex: 'none' }}><Term k="forma">forma</Term> {fc.race ? 'na startu' : 'v nedeljo'} ≈ {signed(fc.tsb, 0)}</span>}</div>}
          {/* ure: ista vrstica kot v »Ure na teden po mesecih«; teden tekme: treningi in tekma posebej, brez rasti (v3.48) */}
          {custom ? <div className="muted" style={{ fontSize: 12, marginTop: 4 }}>{(() => { const g = active.filter(d => d.kind === 'moc').length, c = active.filter(d => d.kind !== 'moc'); return [g ? `moč ${g}×` : '', c.length ? `kardio ${fmtDur(c.reduce((t, d) => t + d.durationMin, 0))}` : ''].filter(Boolean).join(' · ') })()}{cx.recovery ? ' · lažji teden' : ''}</div> : <div className="muted" style={{ fontSize: 12, marginTop: 4 }}>{raceMin > 0 ? `${bikeAll > raceMin ? `Treningi ${fmtDur(bikeAll - raceMin)} · tekma` : 'Tekma'} ${fmtDur(raceMin)}` :`Na kolesu ${fmtDur(bikeAll)} · ${hLine}`}</div>}
          {zTotal > 0 && (
            <div style={{ marginTop: 10 }}>
              <div style={{ display: 'flex', height: 8, borderRadius: 4, overflow: 'hidden', gap: 2 }}>
                {(['Z1', 'Z2', 'Z3', 'Z4', 'Z5'] as const).map((z, i) => zm[z] > 0 && <i key={z} style={{ flex: zm[z], background: ['var(--z1)', 'var(--z2)', 'var(--z3)', 'var(--z4)', 'var(--z5)'][i] }} />)}
              </div>
              <div className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>{pct(easy / zTotal * 100)} lahko{plain ? '' : <> (<Term k="cona">Z1–Z2</Term>)</>} · {pct((zTotal - easy) / zTotal * 100)} težje{raceWeek ? '.' : ' — cilj: okoli 80 % lahko.'}</div>
            </div>
          )}
        </Section>
      )}
      {(!custom || (app.profile.races || []).length > 0) && (() => {
        const up = (app.profile.races || []).filter(r => r.date >= app.today).sort((a, b) => a.date.localeCompare(b.date))
        const ev = app.profile.event?.date && app.profile.event.date >= app.today ? app.profile.event : null
        const next = [...(ev ? [{ name: ev.name, date: ev.date }] : []), ...up].sort((a, b) => a.date.localeCompare(b.date))[0]
        // vprašanje o koncu sezone in off-season morata biti vidna → razdelek odprt
        const must = askOffSeason(app.profile, app.today) || cx.phase === 'prehod'
        return <Section id="pl-tekme" className="nav-target" title="Tekme sezone" sum={next ? `naslednja ${next.name} · ${dm(next.date)}` : 'dodaj tekme — cilji A, B, C'} open={must || openSec === 'pl-tekme'} onToggle={() => toggleSec('pl-tekme')}><RacesCard bare /></Section>
      })()}
      {/* samo prvi zapis (»Načrt: …«) ni sprememba — razdelek pride, ko se načrt res spremeni */}
      {view === 'ta' && (app.changes.length > 1 || (app.changes.length === 1 && !/^Načrt: /.test(app.changes[0]!.text))) && (
        <Section id="pl-spremembe" title="Spremembe načrta" sum={`${count(app.changes.length, W.zapis)} · zadnja ${whenOf(app.changes[0]!.at, app.today)}`} open={openSec === 'pl-spremembe'} onToggle={() => toggleSec('pl-spremembe')}><ChangesCard /></Section>
      )}
      </div>
      </div>
      </>)}
    </div>
    {edit && <EditDay day={edit} add={edit.kind === 'pocitek' && !edit.sickPrev && !edit.done} onClose={() => setEdit(null)} />}
    {change && (() => {
      const d = change, date = d.date
      const list = app.plan.filter(x => x.date === date)
      const j = list.findIndex(x => x.id === d.id)
      return <ChangeDaySheet day={d} title="Spremeni ta dan" onClose={() => setChange(null)} opts={[
        { t: 'Uredi', d: 'Vrsta, trajanje, opis ali vaje tega dne.', go: () => setEdit(d) },
        ...(canMove(d, app.today, lock) ? [{ t: 'Premakni na drug dan', d: 'Izbereš dan — kar je tam, pride sem.', go: () => setMove(d) }] : []),
        ...(date >= app.today && canHike(d) ? [{ t: 'Hribi namesto kolesa', d: 'Enako lahko, peš — samo ta dan.', go: () => { void hikeInstead(d.id).then(() => toast('Hribi namesto kolesa — trening za ta dan gre z ure.', 'ok')) } }] : []),
        ...(d.swap && !d.done ? [{ t: 'Nazaj na kolo', d: 'Kot je bilo v načrtu.', go: () => { void backToBike(d.id).then(() => toast('Nazaj na kolo.', 'ok')) } }] : []),
        ...(d.adapt?.prev && !d.adapt.off && !d.done ? [{ t: 'Vrni prvotni trening', d: 'Samodejna prilagoditev se razveljavi.', go: () => { void undoLoadAdaptOf(d.adapt!.after).then(() => toast('Vrnjen prvotni načrt.', 'ok')) } }] : []),
        ...(trainerOk(d) ? [{ t: '.zwo za trenažer', d: 'Datoteka za Zwift, TrainerRoad ali drug trenažer.', go: () => { void downloadZwo(d) } }] : []),
        ...(date >= app.today && j === list.length - 1 && !list.some(x => x.kind === 'moc') && !d.sickPrev ? [{ t: '+ jedro po želji', d: 'Kratka vadba za trebuh in hrbet — ne šteje v realizacijo.', go: () => { void addCore(date).then(() => toast('Jedro dodano — po želji, ne šteje v realizacijo.', 'ok')) } }] : []),
      ]} />
    })()}
    {move && <MoveDaySheet day={move} onClose={() => setMove(null)} />}
    {goalOpen && <GoalSheet open onClose={() => setGoalOpen(false)} />}
    {ai.sheet}
  </>)
}

type ExRow = { name: string; sets: string; reps: string; kg: string }
export type DayForm = { kind: PlanKind; title: string; dur: string; zone: string; desc: string }
/**
 * Urejen dan: druga vrsta, cona ali opis = drug trening — stari vati intervalov, vloga (ključni …) in razlaga
 * ne veljajo več; dan, spremenjen v počitek, ni ključna seja.
 */
/** (v3.50) Trajanje vadbe: 10–480 min; prazno ali 0 je napaka (prej shranjena vožnja z 0 min, »Kolo · —«, 0 TSS; 900 tiho → 480). */
export const DUR_MIN = 10, DUR_MAX = 480
export function dayFormError(d: Pick<DayForm, 'kind' | 'dur'>): string | null {
  if (d.kind === 'pocitek') return null
  const n = parseInt(d.dur)
  return Number.isFinite(n) && n >= DUR_MIN && n <= DUR_MAX ? null : `Trajanje: od ${DUR_MIN} do ${DUR_MAX} min.`
}
export function applyDayEdit(day: PlanDay, d: DayForm, ex: ExRow[]): PlanDay {
  const kind = d.kind
  const exercises = kind === 'moc' ? ex.filter(e => e.name.trim()).map(e => ({ name: e.name.trim().slice(0, 40), sets: Math.max(1, Math.min(8, parseInt(e.sets) || 3)), reps: (e.reps.trim() || '8–12').slice(0, 14), kg: e.kg ? +e.kg.replace(',', '.') || null : null })) : undefined
  // (v3.48) do 8 h kot hribi (prej 360: »Shrani« brez sprememb je 6 h 30 skrajšal na 6 h); (v3.50) prazno ali 0 obdrži staro trajanje
  const n = parseInt(d.dur)
  const dur = kind === 'pocitek' ? 0 : Math.max(DUR_MIN, Math.min(DUR_MAX, Number.isFinite(n) && n > 0 ? n : day.durationMin || 60))
  const h = dur / 60
  const zone = kind === 'pocitek' ? null : d.zone || null
  // (v3.48) ista vrsta in cona: TSS načrta ostane (samo trajanje → sorazmerno); prej je »Shrani« brez sprememb VO2max 68 → 125
  const same = kind === day.kind && zone === (day.zone || null) && day.tssTarget != null
  const tss = same && dur === day.durationMin ? day.tssTarget!
    : same && day.durationMin > 0 ? Math.round(day.tssTarget! * dur / day.durationMin)
    : kind === 'kolo' ? Math.round(h * (d.zone === 'Z5' ? 100 : d.zone === 'Z4' || d.zone === 'test' ? 85 : d.zone === 'Z3' ? 70 : 50)) : kind === 'tek' ? Math.round(h * 78) : kind === 'moc' ? Math.round(h * 60) : kind === 'pohod' ? Math.round(h * 40) : 0
  const desc = d.desc.trim()
  const redefined = kind !== day.kind || zone !== (day.zone || null) || desc !== day.desc.trim()
  const role: PlanDay['role'] = kind === 'pocitek' ? null : !redefined ? day.role ?? null : kind === 'test' ? 'test' : kind === 'moc' ? 'moc' : null
  return {
    ...day, kind, title: d.title.trim() || day.title, durationMin: dur, zone, desc, exercises, tssTarget: tss,
    optional: kind === day.kind ? day.optional : false, source: 'rules', role,
    ...(redefined ? { target: null, why: null } : {}),
    ...(redefined || dur !== day.durationMin ? { kcalBurn: null } : {}),
    ...(kind !== day.kind ? { swap: null } : {}),
  }
}
/** Dan počitka → nov trening: privzeto lahka vožnja (Z2, 60 min), vse je mogoče spremeniti. */
export const ADD_DEFAULT: DayForm = { kind: 'kolo', title: 'Z2 vzdržljivost', dur: '60', zone: 'Z2', desc: 'Enakomerno v Z2 — pogovorni tempo, kadenca 85–95.' }
/** Načrt po meri: nov trening je lahek tek ali moč (ne vožnja). */
const ADD_RUN: DayForm = { kind: 'tek', title: 'Lahek tek', dur: '40', zone: 'Z2', desc: 'Pogovorni tempo — še lahko govoriš v celih stavkih.' }
const ADD_GYM: DayForm = { kind: 'moc', title: 'Moč po želji', dur: '45', zone: '', desc: 'Vaje vpiši spodaj — kilograme vpiši med vadbo.' }
function EditDay({ day, onClose, add = false }: { day: PlanDay; onClose: () => void; add?: boolean }) {
  const p0 = getState().profile
  // (v3.50 B50) kolesar: ista predloga in cona kot Z2 v načrtu (utrip/vati), ne splošno »kadenca 85–95«
  const z2 = isCustom(p0) ? null : defaultZ2(p0, 60)
  const def = isCustom(p0) ? (p0.focus!.sessions.some(x => x.type === 'tek') || !p0.strength.on ? ADD_RUN : ADD_GYM) : z2 ? { ...ADD_DEFAULT, title: z2.title, desc: z2.desc } : ADD_DEFAULT
  const [d, setD] = useState<DayForm>(add ? def : { kind: day.kind, title: day.title, dur: String(day.durationMin || ''), zone: day.zone || '', desc: day.desc })
  const [ex, setEx] = useState<ExRow[]>((day.exercises || []).map(e => ({ name: e.name, sets: String(e.sets), reps: e.reps, kg: e.kg ? String(e.kg) : '' })))
  // (v3.50) trajanje 10–480 min: napaka pod poljem, Shrani onemogočen (prej vožnja z 0 min brez opozorila)
  const durErr = dayFormError(d)
  async function save() {
    if (durErr) return
    await savePlanDay(applyDayEdit(day, d, ex))
    toast(add ? 'Trening dodan — na uro gre sam.' : 'Dan shranjen.', 'ok'); onClose()
  }
  const set = (i: number, k: keyof ExRow, v: string) => setEx(ex.map((e, j) => (j === i ? { ...e, [k]: v } : e)))
  return (
    <Sheet open onClose={onClose} label={add ? 'Dodaj trening' : 'Uredi dan'}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>{add ? 'Dodaj trening' : 'Uredi dan'}</b>
      {/* (v3.50) trening s table, lista ali objave: AI ga prebere, predogled urediš */}
      {add && day.date >= getState().today && <button type="button" className="chip sm click" style={{ marginTop: 8 }} onClick={() => { onClose(); openPhotoTraining({ mode: 'plan', date: day.date }) }}>S slike — tabla, list ali objava</button>}
      <div className="row" style={{ gap: 7, flexWrap: 'wrap', margin: '12px 0' }}>{KINDS.map(k => <Chip key={k.k} sm on={d.kind === k.k} onClick={() => setD({ ...d, kind: k.k })}>{k.l}</Chip>)}</div>
      <div className="stack" style={{ gap: 10 }}>
        <div className="field"><label htmlFor="ed-title">Naslov</label><input id="ed-title" value={d.title} onChange={e => setD({ ...d, title: e.target.value })} /></div>
        {d.kind !== 'pocitek' && <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div className="field"><label htmlFor="ed-dur">Trajanje <span className="unit">min</span></label><input id="ed-dur" type="number" inputMode="numeric" min={DUR_MIN} max={DUR_MAX} value={d.dur} onChange={e => setD({ ...d, dur: e.target.value })} aria-invalid={!!durErr} aria-describedby={durErr ? 'ed-dur-err' : undefined} />{durErr && <span id="ed-dur-err" className="ed-err" role="alert">{durErr}</span>}</div>
          <div className="field"><label htmlFor="ed-zone">Cona</label><select id="ed-zone" value={d.zone} onChange={e => setD({ ...d, zone: e.target.value })} style={{ paddingLeft: 10 }}>{ZONES.map(z => <option key={z} value={z}>{z || '—'}</option>)}</select></div>
        </div>}
        <div className="field"><label htmlFor="ed-desc">Opis</label><textarea id="ed-desc" value={d.desc} onChange={e => setD({ ...d, desc: e.target.value })} rows={3} /></div>
        {d.kind === 'moc' && (
          <div className="field"><label>Vaje <span className="unit">ime · serije · ponovitve · kg</span></label>
            <div className="stack" style={{ gap: 6 }}>
              {ex.map((e, i) => (
                // ime čez celo širino, pod njim serije · ponovitve · kg (v3.48, kot ročni vnos — prej 70 px za ime)
                <div key={i} className="exrow ex2">
                  <input className="ex-name" value={e.name} onChange={x => set(i, 'name', x.target.value)} placeholder="vaja" aria-label="Vaja" />
                  <input value={e.sets} inputMode="numeric" onChange={x => set(i, 'sets', x.target.value)} style={{ textAlign: 'center' }} aria-label="Serije" />
                  <input value={e.reps} onChange={x => set(i, 'reps', x.target.value)} style={{ textAlign: 'center' }} aria-label="Ponovitve" />
                  <input value={e.kg} inputMode="decimal" onChange={x => set(i, 'kg', x.target.value)} placeholder="kg" style={{ textAlign: 'center' }} aria-label="Kilogrami" />
                  <button className="chip sm click" onClick={() => setEx(ex.filter((_, j) => j !== i))} aria-label="Odstrani vajo">×</button>
                </div>
              ))}
              <button className="chip sm click" style={{ alignSelf: 'flex-start' }} onClick={() => setEx([...ex, { name: '', sets: '3', reps: '8–12', kg: '' }])}>+ vaja</button>
            </div>
          </div>
        )}
      </div>
      <Btn primary block style={{ marginTop: 14 }} onClick={save} disabled={!!durErr}>Shrani</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Prekliči</Btn>
    </Sheet>
  )
}

