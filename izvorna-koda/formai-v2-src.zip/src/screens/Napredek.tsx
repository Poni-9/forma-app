import { useEffect, useMemo, useState } from 'react'
import { Head } from '@/app/Shell'
import { useApp, saveCheckin, addTest, removeTest, updateSettings, toast } from '@/state/store'
import { snapOf } from '@/state/snap'
import { useAi } from '@/ui/useAi'
import { weightTrend, dailyTarget } from '@/domain/nutrition/energy'
import { formSeries, addDays, weekStartIso, fmtDur, todayIso } from '@/domain/training/load'
import { weekContext } from '@/domain/training/planner'
import { vo2maxFromP5 } from '@/domain/training/goal'
import { GoalCard } from '@/ui/GoalCard'
import { RealityCard } from '@/ui/RealityCard'
import { monthReview } from '@/domain/ai/actions'
import { sanitizeGaps, hasHiddenActivities } from '@/domain/ai/sanitize'
import { aiAllowed } from '@/domain/import/provenance'
import type { Activity, TestEntry } from '@/domain/types'
import { Card, Chip, Btn, Sheet, Track, fmtKcal } from '@/ui/primitives'
import { DotLineChart, StackBars } from '@/ui/charts'
import { IcoScale, IcoPlus } from '@/ui/icons'

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
const MON = ['januar', 'februar', 'marec', 'april', 'maj', 'junij', 'julij', 'avgust', 'september', 'oktober', 'november', 'december']
/** Testi za kolesarja (offer) + stari zapisi, ki jih samo še prikažemo. */
export const TESTS: { kind: TestEntry['kind']; label: string; unit: string; hint: string; milestones?: number[]; offer?: boolean }[] = [
  { kind: 'ftp', label: '20-min test', unit: 'W', hint: 'Povprečna moč 20 minut po ogrevanju. FTP = 95 % te številke — vati v načrtu se posodobijo.', offer: true },
  { kind: 'p5', label: '5-min največja moč', unit: 'W', hint: 'Povprečna moč 5 minut vse, kar gre (po ogrevanju, na spočite noge). Iz nje ocenim VO2max.', offer: true },
  { kind: 'rhr', label: 'Utrip v mirovanju', unit: 'bpm', hint: 'Zjutraj v postelji, 1 minuto. Nižje = boljši motor; +5 nad običajnim = utrujenost.', offer: true },
  { kind: 'deska', label: 'Deska — max', unit: 's', hint: 'Do porušitve položaja. Močan trup = stabilnost na kolesu.', milestones: [60, 90, 120, 180, 240], offer: true },
  { kind: 'zgibi', label: 'Zgibi — max v seriji', unit: 'pon.', hint: '' },
  { kind: 'sklece', label: 'Sklece — max v seriji', unit: 'pon.', hint: '' },
  { kind: 'pocep', label: 'Počepi v 2 minutah', unit: 'pon.', hint: '' },
]
const n1 = (v: number) => v.toFixed(1).replace('.', ',')
const fmtD = (iso: string) => `${+iso.slice(8)}. ${+iso.slice(5, 7)}.`

export function Napredek() {
  const app = useApp()
  const ai = useAi()
  const { profile: p, checkins, activities, plan, recentMeals, today, settings } = app
  const [wOpen, setWOpen] = useState(false)
  const [tOpen, setTOpen] = useState(false)
  const [busy, setBusy] = useState<string | null>(null)
  const tr = weightTrend(checkins)

  /* ---- teža ---- */
  const w90 = useMemo(() => checkins.filter(c => c.weightKg && c.date >= addDays(today, -90)).map(c => ({ date: c.date, v: c.weightKg as number })), [checkins, today])
  const avg90 = useMemo(() => w90.map(pt => { const win = w90.filter(q => q.date <= pt.date && q.date > addDays(pt.date, -7)); return { date: pt.date, v: +(win.reduce((s, q) => s + q.v, 0) / win.length).toFixed(2) } }), [w90])
  const target = p.targetWeightKg || null
  const rate = tr?.deltaWeek ?? null
  const weeksTo = target && tr && rate != null && rate < -0.05 && tr.avg7 > target ? Math.ceil((tr.avg7 - target) / -rate) : null
  const waist = checkins.filter(c => c.waistCm).map(c => ({ date: c.date, v: c.waistCm as number }))

  /* ---- doslednost 28 dni ---- */
  const from28 = addDays(today, -27)
  const planned = plan.filter(d => d.date >= from28 && d.date < today && d.kind !== 'pocitek' && !d.optional)
  const doneN = planned.filter(d => d.done).length
  const foodDays = new Set(recentMeals.filter(m => m.date >= from28).map(m => m.date)).size
  const acts28 = activities.filter(a => a.date >= from28)
  let streak = 0
  for (let i = recentMeals.some(m => m.date === today) ? 0 : 1; i < 120; i++) { if (recentMeals.some(m => m.date === addDays(today, -i))) streak++; else break }

  /* ---- motor ---- */
  const series = useMemo(() => formSeries(activities, today), [activities, today])
  const ctlNow = series.length ? series[series.length - 1]!.ctl : 0
  const ctl6 = series.length > 42 ? series[series.length - 43]!.ctl : 0
  const wkg = p.ftp && (tr?.avg7 || p.weightKg) ? p.ftp / (tr?.avg7 || p.weightKg!) : null
  const weeks = Array.from({ length: 12 }, (_, i) => addDays(weekStartIso(today), -7 * (11 - i)))
  const hoursBars = weeks.map(ws => {
    const a = activities.filter(x => x.date >= ws && x.date <= addDays(ws, 6))
    const h = (f: (s: string) => boolean) => +(a.filter(x => f(x.sport)).reduce((s, x) => s + (x.durationMin || 0), 0) / 60).toFixed(1)
    return { label: fmtD(ws), parts: [{ v: h(s => s === 'kolo'), color: 'var(--t-kolo)' }, { v: h(s => s === 'moc'), color: 'var(--t-moc)' }, { v: h(s => s !== 'kolo' && s !== 'moc'), color: 'var(--t-poc)' }] }
  })

  /* ---- moč po vajah ---- */
  const byEx = useMemo(() => {
    const m = new Map<string, { name: string; list: { date: string; sets: number; reps: string; kg?: number | null }[] }>()
    for (const a of [...activities].filter(x => x.sport === 'moc' && x.exercises?.length).sort((x, y) => x.date.localeCompare(y.date)))
      for (const e of a.exercises!) { const k = e.name.toLowerCase(); if (!m.has(k)) m.set(k, { name: e.name, list: [] }); m.get(k)!.list.push({ date: a.date, sets: e.sets, reps: e.reps, kg: e.kg }) }
    return [...m.values()].sort((a, b) => b.list.length - a.list.length).slice(0, 8)
  }, [activities])
  const mocN = activities.filter(a => a.sport === 'moc' && a.date >= from28).length

  /* ---- testi in mejniki ---- */
  const tests = [...(settings.tests || [])].sort((a, b) => b.date.localeCompare(a.date))
  const miles = TESTS.filter(t => t.milestones).map(t => {
    const last = tests.find(x => x.kind === t.kind); if (!last) return null
    const ms = t.milestones!, next = ms.find(m => m > last.value) ?? null
    return { t, value: last.value, next, level: ms.filter(m => m <= last.value).length, of: ms.length }
  }).filter(Boolean) as { t: typeof TESTS[number]; value: number; next: number | null; level: number; of: number }[]

  /* ---- meseci ---- */
  const ym = today.slice(0, 7), prevYm = addDays(today.slice(0, 8) + '01', -1).slice(0, 7)
  const month = (m: string, acts: readonly Activity[] = activities) => {
    const a = acts.filter(x => x.date.slice(0, 7) === m), k = a.filter(x => x.sport === 'kolo')
    const w = checkins.filter(c => c.weightKg && c.date.slice(0, 7) === m).sort((x, y) => x.date.localeCompare(y.date))
    const md = [...new Set(recentMeals.filter(x => x.date.slice(0, 7) === m).map(x => x.date))]
    const kc = md.map(d => recentMeals.filter(x => x.date === d).reduce((s, x) => s + x.kcal, 0))
    return { m, n: a.length, min: a.reduce((s, x) => s + (x.durationMin || 0), 0), km: Math.round(k.reduce((s, x) => s + (x.distKm || 0), 0)), elev: Math.round(k.reduce((s, x) => s + (x.elevM || 0), 0)), tss: Math.round(a.reduce((s, x) => s + (x.tss || 0), 0)), moc: a.filter(x => x.sport === 'moc').length, w0: w[0]?.weightKg ?? null, w1: w[w.length - 1]?.weightKg ?? null, kcal: kc.length ? Math.round(kc.reduce((s, x) => s + x, 0) / kc.length) : null, foodDays: md.length }
  }
  const mNow = month(ym), mPrev = month(prevYm)
  // AI dobi samo aktivnosti, ki jih sme videti (Strava in neznani izvori NIKOLI v poziv)
  const hidden = hasHiddenActivities(activities)
  const aiActs = activities.filter(aiAllowed)
  const mText = (x: ReturnType<typeof month>) => `${MON[+x.m.slice(5, 7) - 1]} ${x.m.slice(0, 4)}: ${x.n} vaj, ${fmtDur(x.min)}, ${x.km} km, ${x.elev} m vzpona, ${x.tss} TSS, moč ${x.moc}×; teža ${x.w0 != null ? `${x.w0} → ${x.w1} kg` : 'ni podatka'}; prehrana ${x.kcal ? `povprečno ${x.kcal} kcal (${x.foodDays} dni)` : 'ni zabeležena'}.`
  const review = settings.monthReviews?.[ym]
  const cx = weekContext(p, weekStartIso(today))
  const tgt = dailyTarget(p, [], [], today)

  async function doMonth() {
    setBusy('month')
    const t = await ai.run(() => monthReview(snapOf(app), `${mText(month(ym, aiActs))}\nPrejšnji mesec — ${mText(month(prevYm, aiActs))}`))
    setBusy(null)
    if (t) await updateSettings({ monthReviews: { ...(settings.monthReviews || {}), [ym]: { at: new Date().toISOString(), text: t } } })
  }

  return (<>
    <Head hi="W/kg · teža · motor" nm="Napredek" />
    <div className="scroll">
      <div className="stack" style={{ gap: 12 }}>

        <GoalCard full />

        <RealityCard />

        {/* TEŽA */}
        <Card>
          <div className="between"><h4 style={{ margin: 0 }}>Teža</h4><Btn sm onClick={() => setWOpen(true)}><IcoScale width={16} height={16} /> Stehtaj se</Btn></div>
          {tr ? (<>
            <div className="row" style={{ gap: 18, marginTop: 10, flexWrap: 'wrap' }}>
              <div><div style={{ fontSize: 28, fontWeight: 800, letterSpacing: '-.03em' }}>{n1(tr.avg7)} <span style={{ fontSize: 14, color: 'var(--ink-3)' }}>kg</span></div><div className="muted" style={{ fontSize: 11.5, fontWeight: 700 }}>7-DNEVNO POVPREČJE</div></div>
              <div><div style={{ fontSize: 18, fontWeight: 800, color: rate == null ? 'var(--ink-3)' : rate < -0.7 ? 'var(--warn)' : rate < 0 ? 'var(--ok)' : 'var(--ink)' }}>{rate == null ? '—' : `${rate > 0 ? '+' : ''}${rate.toFixed(2).replace('.', ',')} kg`}</div><div className="muted" style={{ fontSize: 11.5, fontWeight: 700 }}>NA TEDEN</div></div>
              {target && <div><div style={{ fontSize: 18, fontWeight: 800 }}>{n1(Math.max(0, tr.avg7 - target))} kg</div><div className="muted" style={{ fontSize: 11.5, fontWeight: 700 }}>DO CILJA {n1(target)}</div></div>}
            </div>
            <div style={{ marginTop: 12 }}><DotLineChart points={w90} line={avg90} reference={target} refLabel="cilj" unit="kg" /></div>
            <p className="muted" style={{ fontSize: 12.5, marginTop: 10 }}>
              {rate == null ? 'Tehtaj se zjutraj, vsak dan ali vsaj 3× na teden — po dveh tednih pokažem tempo.'
                : rate < -0.7 ? 'Izgubljaš več kot 0,7 kg na teden — prehitro, gre tudi mišica in z njo vati. Dodaj 200–300 kcal na dan.'
                : rate < -0.05 ? `Tempo je pravi.${weeksTo ? ` Pri tem tempu je cilj dosežen čez ~${weeksTo} tednov (${fmtD(addDays(today, weeksTo * 7))}).` : ''}`
                : target && tr.avg7 > target ? 'Teža stoji. Preveri, ali res zabeležiš vse obroke (tudi pijače in prigrizke), in dodaj 20 min hoje na dan.'
                : 'Teža je stabilna.'}
              {tgt ? ` Dnevni cilj brez treninga ${fmtKcal(tgt.kcal)} kcal, beljakovine ${tgt.proteinG} g.` : ''}
            </p>
            {waist.length >= 2 && <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>Pas: {n1(waist[0]!.v)} → <b style={{ color: 'var(--ink)' }}>{n1(waist[waist.length - 1]!.v)} cm</b> ({waist[waist.length - 1]!.v - waist[0]!.v > 0 ? '+' : ''}{n1(waist[waist.length - 1]!.v - waist[0]!.v)} cm) — pas pove več kot tehtnica, ko hkrati gradiš mišice.</div>}
          </>) : <p style={{ fontSize: 13, marginTop: 8 }}>Še ni tehtanja. Stehtaj se zjutraj, po stranišču, pred zajtrkom — vedno enako. Šteje 7-dnevno povprečje, ne posamezen dan.</p>}
        </Card>

        {/* DOSLEDNOST */}
        <Card tight>
          <h4 style={{ fontSize: 11 }}>Doslednost · zadnjih 28 dni</h4>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, textAlign: 'center', marginTop: 8 }}>
            <div><div style={{ fontSize: 20, fontWeight: 800 }}>{planned.length ? Math.round(doneN / planned.length * 100) + ' %' : '—'}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>sej po planu</div></div>
            <div><div style={{ fontSize: 20, fontWeight: 800 }}>{foodDays}/28</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>dni s hrano{streak >= 3 ? ` · niz ${streak}` : ''}</div></div>
            <div><div style={{ fontSize: 20, fontWeight: 800 }}>{Math.round(acts28.reduce((s, a) => s + (a.durationMin || 0), 0) / 60)} h</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>{acts28.length} vaj</div></div>
          </div>
        </Card>

        {/* MOTOR */}
        <Card>
          <h4 style={{ margin: 0 }}>Motor</h4>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginTop: 10 }}>
            <div><div style={{ fontSize: 20, fontWeight: 800, color: 'var(--t-kolo)' }}>{Math.round(ctlNow)}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>kondicija{series.length > 42 ? ` · ${ctlNow - ctl6 >= 0 ? '+' : ''}${Math.round(ctlNow - ctl6)} v 6 t.` : ''}</div></div>
            <div><div style={{ fontSize: 20, fontWeight: 800 }}>{p.ftp ? `${p.ftp} W` : '—'}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>FTP{p.ftpDate ? ` · ${fmtD(p.ftpDate)}` : ''}</div></div>
            <div><div style={{ fontSize: 20, fontWeight: 800 }}>{wkg ? wkg.toFixed(2).replace('.', ',') : '—'}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>W/kg</div></div>
          </div>
          <p className="muted" style={{ fontSize: 12, margin: '8px 0 12px' }}>Hujšanje dvigne W/kg tudi brez dodatnih vatov — 3 kg manj pri istem FTP je kot +10 W v klanec.{cx.structured ? ` ${cx.phaseName}, teden ${cx.week}${cx.total ? '/' + cx.total : ''}.` : ''}</p>
          <StackBars bars={hoursBars} legend={[{ label: 'kolo', color: 'var(--t-kolo)' }, { label: 'moč', color: 'var(--t-moc)' }, { label: 'tek/hoja', color: 'var(--t-poc)' }]} unit="ure" />
        </Card>

        {/* MOČ — samo, če jo treniraš */}
        {(p.strength.on || mocN > 0) && <Card>
          <div className="between"><h4 style={{ margin: 0 }}>Moč</h4><span className="muted" style={{ fontSize: 12, fontWeight: 700 }}>{mocN} vadb v 28 dneh</span></div>
          {miles.length > 0 && <div className="stack" style={{ gap: 10, marginTop: 10 }}>
            {miles.map(m => (
              <div key={m.t.kind}>
                <div className="between" style={{ fontSize: 13 }}><b>{m.t.label.split(' — ')[0]}</b><span className="muted" style={{ fontWeight: 700 }}>{m.value} {m.t.unit}{m.next ? ` · naslednji mejnik ${m.next}` : ' · vsi mejniki'}</span></div>
                <div style={{ marginTop: 5 }}><Track pct={m.level / m.of * 100} color="var(--t-moc)" /></div>
              </div>
            ))}
          </div>}
          {byEx.length ? (
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13, marginTop: 12 }}>
              <thead><tr style={{ color: 'var(--ink-3)', fontSize: 11 }}><th style={{ textAlign: 'left', padding: '4px 0' }}>vaja</th><th style={{ textAlign: 'right' }}>prvič</th><th style={{ textAlign: 'right' }}>zadnjič</th><th style={{ textAlign: 'right' }}>×</th></tr></thead>
              <tbody>{byEx.map(e => { const a = e.list[0]!, z = e.list[e.list.length - 1]!, f = (x: typeof a) => `${x.sets}×${x.reps}${x.kg ? ' @' + x.kg : ''}`; return (
                <tr key={e.name} style={{ borderTop: '1px solid var(--line)' }}><td style={{ padding: '7px 0', fontWeight: 600 }}>{e.name}</td><td className="muted" style={{ textAlign: 'right' }}>{f(a)}</td><td style={{ textAlign: 'right', fontWeight: 800 }}>{f(z)}</td><td className="muted" style={{ textAlign: 'right' }}>{e.list.length}</td></tr>) })}</tbody>
            </table>
          ) : <p style={{ fontSize: 13, marginTop: 8 }}>Ko moč opraviš z vodeno vadbo (Začni trening) ali vpišeš vaje, se tu vidi napredek po vajah.</p>}
        </Card>}

        {/* TESTI */}
        <Card>
          <div className="between"><h4 style={{ margin: 0 }}>Testi</h4><Btn sm onClick={() => setTOpen(true)}><IcoPlus width={15} height={15} /> Vpiši</Btn></div>
          {tests.length ? (
            <div className="stack" style={{ gap: 0, marginTop: 8 }}>
              {tests.slice(0, 12).map(t => { const T = TESTS.find(x => x.kind === t.kind)!; return (
                <div key={t.id} className="between" style={{ padding: '8px 0', borderTop: '1px solid var(--line)', fontSize: 13 }}>
                  <span><span className="muted">{fmtD(t.date)}</span> · {T.label}</span>
                  <span className="row" style={{ gap: 8 }}><b>{t.value} {t.unit}</b>{t.kind === 'ftp' && <span className="muted">FTP {Math.round(t.value * .95)}</span>}{t.kind === 'p5' && (tr?.avg7 || p.weightKg) ? <span className="muted">VO2max ~{vo2maxFromP5(t.value, (tr?.avg7 || p.weightKg)!)}</span> : null}<button className="chip sm click" onClick={() => { if (confirm('Izbrišem ta test?')) void removeTest(t.id) }} aria-label="Izbriši">×</button></span>
                </div>) })}
            </div>
          ) : <p style={{ fontSize: 13, marginTop: 8 }}>20-min test FTP je v načrtu vsakih 8 tednov (v razbremenilnem tednu). 5-min test pove, kje je tvoj VO2max — ponovi ga v isti razbremenitvi.</p>}
        </Card>

        {/* MESEC */}
        <Card>
          <h4 style={{ margin: 0 }}>{MON[+ym.slice(5, 7) - 1]!.charAt(0).toUpperCase() + MON[+ym.slice(5, 7) - 1]!.slice(1)}</h4>
          <p style={{ fontSize: 13, marginTop: 8, color: 'var(--ink)' }}>{mText(mNow)}</p>
          <p className="muted" style={{ fontSize: 12, marginTop: 6 }}>Prej — {mText(mPrev)}</p>
          {review && <p style={{ fontSize: 13.5, marginTop: 10, lineHeight: 1.55, color: 'var(--ink)', whiteSpace: 'pre-wrap' }}>{sanitizeGaps(review.text, hidden)}</p>}
          <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
            <Btn ghost sm disabled={ai.busy} onClick={doMonth}>{busy === 'month' ? 'Pišem …' : review ? 'Osveži oceno meseca' : 'AI ocena meseca'}</Btn>
            <Btn ghost sm onClick={() => { void navigator.clipboard?.writeText(`${mText(mNow)}\n${review ? review.text : ''}`).then(() => toast('Kopirano.', 'ok')) }}>Kopiraj</Btn>
          </div>
        </Card>

      </div>
    </div>

    <WeighSheet open={wOpen} onClose={() => setWOpen(false)} />
    <TestSheet open={tOpen} onClose={() => setTOpen(false)} />
    {ai.sheet}
  </>)
}

/* ---------- tehtanje ---------- */
export function WeighSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const app = useApp()
  const c = app.checkinToday
  const last = [...app.checkins].reverse().find(x => x.weightKg)
  const [kg, setKg] = useState('')
  const [waist, setWaist] = useState('')
  const [date, setDate] = useState(todayIso())
  const init = () => { setKg(String(c?.weightKg ?? last?.weightKg ?? app.profile.weightKg ?? '')); setWaist(c?.waistCm ? String(c.waistCm) : ''); setDate(todayIso()) }
  async function save() {
    const v = +String(kg).replace(',', '.')
    if (!(v > 30 && v < 250)) { toast('Vpiši realno težo.', 'err'); return }
    const prev = app.checkins.find(x => x.date === date)
    await saveCheckin({ ...(prev || { date }), date, weightKg: +v.toFixed(1), waistCm: waist ? +String(waist).replace(',', '.') : prev?.waistCm ?? null })
    toast('Teža zabeležena.', 'ok'); onClose()
  }
  useEffect(() => { if (open) init() }, [open])   // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <Sheet open={open} onClose={onClose}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Tehtanje</b>
      <p style={{ fontSize: 12.5, marginTop: 6 }}>Zjutraj, po stranišču, pred zajtrkom — vedno enako. Šteje 7-dnevno povprečje.</p>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 12 }}>
        <div className="field"><label>Teža <span className="unit">kg</span></label><input type="number" inputMode="decimal" step={0.1} value={kg} onChange={e => setKg(e.target.value)} autoFocus /></div>
        <div className="field"><label>Datum</label><input type="date" value={date} max={todayIso()} onChange={e => setDate(e.target.value || todayIso())} /></div>
        <div className="field" style={{ gridColumn: '1 / -1' }}><label>Obseg pasu <span className="unit">cm, neobvezno</span></label><input type="number" inputMode="decimal" step={0.5} value={waist} onChange={e => setWaist(e.target.value)} placeholder="na popku, sproščeno" /></div>
      </div>
      <Btn primary block style={{ marginTop: 14 }} onClick={save}>Shrani</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Prekliči</Btn>
    </Sheet>
  )
}

/* ---------- test ---------- */
function TestSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [kind, setKind] = useState<TestEntry['kind']>('ftp')
  const [val, setVal] = useState('')
  const [date, setDate] = useState(todayIso())
  const T = TESTS.find(t => t.kind === kind)!
  async function save() {
    const v = +String(val).replace(',', '.')
    if (!(v > 0)) { toast('Vpiši rezultat.', 'err'); return }
    await addTest({ id: uid(), date, kind, value: v, unit: T.unit })
    setVal(''); onClose()
  }
  return (
    <Sheet open={open} onClose={onClose}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Vpiši test</b>
      <div className="row" style={{ gap: 7, flexWrap: 'wrap', margin: '12px 0' }}>{TESTS.filter(t => t.offer).map(t => <Chip key={t.kind} sm on={kind === t.kind} onClick={() => setKind(t.kind)}>{t.label.split(' — ')[0]}</Chip>)}</div>
      <p style={{ fontSize: 12.5 }}>{T.hint}</p>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 12 }}>
        <div className="field"><label>Rezultat <span className="unit">{T.unit}</span></label><input type="number" inputMode="decimal" value={val} onChange={e => setVal(e.target.value)} autoFocus /></div>
        <div className="field"><label>Datum</label><input type="date" value={date} max={todayIso()} onChange={e => setDate(e.target.value || todayIso())} /></div>
      </div>
      <Btn primary block style={{ marginTop: 14 }} onClick={save}>Shrani</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Prekliči</Btn>
    </Sheet>
  )
}
