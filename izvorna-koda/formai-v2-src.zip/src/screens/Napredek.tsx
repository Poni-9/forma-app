import { useEffect, useMemo, useState } from 'react'
import { hrZoneRows, powerZoneRows } from '@/domain/training/zwo'
import { Head } from '@/app/Shell'
import { navigate } from '@/app/router'
import { parseHash, replaceParams } from '@/app/hash'
import { useApp, getState, addTest, removeTest, updateSettings, toast, latestFtpTest, removeWeigh } from '@/state/store'
import { testError, testJump } from '@/domain/ranges'
import { snapOf } from '@/state/snap'
import { useAi } from '@/ui/useAi'
import { weightTrend, dailyTarget, lossTooFast, goalDeficit, isMinor, MAX_DEFICIT } from '@/domain/nutrition/energy'
import { shownTargetWeight } from '@/domain/nutrition/body'
import { recentWeighs } from '@/domain/weigh'
import { daysSinceWeigh } from '@/domain/alerts'
import { formSeries, formReliable, addDays, weekStartIso, fmtDur, todayIso } from '@/domain/training/load'
import { weekContext } from '@/domain/training/planner'
import { vo2maxFromP5 } from '@/domain/training/goal'
import { GoalCard } from '@/ui/GoalCard'
import { ZonesCard } from '@/ui/ZonesCard'
import { RecordsCard, recordsHas, recordsSum } from '@/ui/RecordsCard'
import { RealityCard, realityHas, realitySum } from '@/ui/RealityCard'
import { recordSport } from '@/domain/training/records'
import { Section } from '@/ui/Section'
import { monthReview } from '@/domain/ai/actions'
import { sanitizeGaps, hasHiddenActivities } from '@/domain/ai/sanitize'
import { aiAllowed, hasGarminData } from '@/domain/import/provenance'
import type { Activity, Profile, TestEntry } from '@/domain/types'
import { Card, Chip, Btn, Sheet, Track, fmtKcal, DecimalInput } from '@/ui/primitives'
import { DotLineChart, FormChart, StackBars } from '@/ui/charts'
import { WeighSheet } from '@/ui/WeighSheet'
import { IcoScale, IcoPlus } from '@/ui/icons'
import { DateField } from '@/ui/DateField'
import { DealCard } from '@/ui/DealCard'
import { BodyMap } from '@/ui/BodyMap'
import { isCustom, isStrength } from '@/domain/focus/model'
import { personalRecords, setsByMuscle, MUSCLE_LABEL } from '@/domain/training/exercises'
import { HealthNote } from '@/ui/HealthNote'
import { deferDelete, useHidden } from '@/ui/Confirm'
import { copyText, count, dec, dm, dmy, int, num, pct, plural, signed, unit, NBSP, W } from '@/ui/format'

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
const MON = ['januar', 'februar', 'marec', 'april', 'maj', 'junij', 'julij', 'avgust', 'september', 'oktober', 'november', 'december']
/** Testi za kolesarja (offer) + stari zapisi, ki jih samo še prikažemo. */
export const TESTS: { kind: TestEntry['kind']; label: string; unit: string; hint: string; milestones?: number[]; offer?: boolean }[] = [
  { kind: 'ftp', label: '20-min test', unit: 'W', hint: 'Povprečna moč 20 minut po ogrevanju. FTP = 95 % te številke — vati v načrtu se posodobijo.', offer: true },
  { kind: 'p5', label: '5-min največja moč', unit: 'W', hint: 'Povprečna moč 5 minut vse, kar gre (po ogrevanju, na spočite noge). Iz nje ocenim VO2max.', offer: true },
  { kind: 'rhr', label: 'Utrip v mirovanju', unit: 'bpm', hint: 'Zjutraj v postelji, 1 minuto. Nižje = boljši motor; +5 nad običajnim = utrujenost.', offer: true },
  // (v3.50) test brez merilnika moči (vodena vadba): pražni utrip kot zapis — trend je viden tu (ni na izbiro za ročni vpis)
  { kind: 'lthr', label: 'Pražni utrip (test)', unit: 'bpm', hint: 'Povprečni utrip zadnjih 15 min 20-minutnega testa brez merilnika — iz njega so cone utripa.' },
  { kind: 'deska', label: 'Deska — max', unit: 's', hint: 'Do porušitve položaja. Močan trup = stabilnost pri vsaki vaji (in na kolesu).', milestones: [60, 90, 120, 180, 240], offer: true },
  { kind: 'zgibi', label: 'Zgibi — max v seriji', unit: 'pon.', hint: 'Največ zgibov v eni seriji: spodaj roke iztegnjene, zgoraj brada nad drogom, brez zibanja.', milestones: [1, 5, 10, 15, 20] },
  { kind: 'sklece', label: 'Sklece — max v seriji', unit: 'pon.', hint: 'Največ sklec v eni seriji: telo ravno od glave do pet, prsi skoraj do tal.', milestones: [10, 20, 30, 40, 50] },
  { kind: 'pocep', label: 'Počepi v 2 minutah', unit: 'pon.', hint: 'Koliko počepov narediš v 2 minutah, do vzporedno, brez uteži.', milestones: [40, 60, 80, 100] },
]
const n1 = (v: number) => dec(v, 1)
const fmtD = dm

/**
 * Testi, ki jih ponudimo: kolesar FTP in 5 min; načrt po meri po športih dogovora (v3.48): utrip v mirovanju vedno,
 * telesni testi samo z močjo v dogovoru, FTP in 5 min s kolesom.
 */
export const offeredTests = (custom: boolean, bike: boolean, strength = true) => TESTS.filter(t => (custom ? ['rhr', ...(strength ? ['deska', 'zgibi', 'sklece', 'pocep'] : []), ...(bike ? ['ftp', 'p5'] : [])].includes(t.kind) : t.offer))
/** (v3.48) moč v dogovoru (fitnes ali doma) — kartica Mišice in testi moči samo takrat (ali ko si moč že delal) */
export const agreedStrength = (p: Pick<Profile, 'focus'>): boolean => !!p.focus?.sessions?.some(isStrength)
export const showMuscles = (p: Pick<Profile, 'focus'>, msTotal: number): boolean => msTotal > 0 || (isCustom(p) && agreedStrength(p))
/**
 * (v3.48) doslednost: dni od začetka (prvi dan 1), največ 28 — prej »0/28 dni s hrano« že prvi dan.
 * (v3.50) firstActivity: uvožena zgodovina pred začetkom — okno vadb je cela 4 tedna (prej »0 h · 0 vadb« ob »4 vadbe v 28 dneh«)
 */
export function consistencyDays(p: Pick<Profile, 'createdAt' | 'goalStart'>, today: string, firstActivity?: string | null): number {
  const starts = [p.createdAt, p.goalStart?.date].map(x => (x || '').slice(0, 10)).filter(x => /^\d{4}-\d{2}-\d{2}$/.test(x)).sort()
  if (!starts[0] || (firstActivity && firstActivity < starts[0])) return 28
  const d = Math.round((new Date(today).getTime() - new Date(starts[0]).getTime()) / 86400_000) + 1
  return Math.max(1, Math.min(28, d))
}
/**
 * (v3.48) Tempo teže: prehitro je nad 0,5 kg na teden (ista meja kot varovalka in kartica cilja), nad 0,7 kg močneje.
 * Prej »Tempo je pravi« in zeleno pri −0,6 kg na teden.
 */
/**
 * (v3.49) Tempo iz naklona tehtanj 3 tednov (weightTrend): pod 4 tehtanji ni tempa; »gre gor« in »stoji« samo zunaj
 * nihanja (noise); »pravi« samo, ko je vsaj 60 % potrebnega tempa do cilja (do tekme ali v 12 tednih, največ 0,5 kg
 * na teden) — prej »Tempo je pravi« pri −0,06 kg in cilj »čez ~132 tednov (28. 4.)« brez letnice.
 */
export const PACE_WEEKS = 12
/** (v3.50) na cilju: ±0,5 kg od ciljne teže (dnevno nihanje) */
export const HOLD_KG = 0.5
/** (v3.50) smer cilja teže — prej je bilo vse, kar ni hujšanje, »Tempo je pravi« ob vsakem padcu (tudi cilj 85 kg pri 79,9) */
export function goalDir(avg7: number, target: number | null | undefined): 'lose' | 'gain' | 'hold' | null {
  if (!target) return null
  return avg7 > target + HOLD_KG ? 'lose' : avg7 < target - HOLD_KG ? 'gain' : 'hold'
}
export function weightPace(x: { stale: boolean; dw: number | null; rate: number | null; target: number | null; avg7: number; weeksTo?: number | null; today: string; noise?: number | null; nPace?: number; event?: { name: string; date: string } | null; canMore?: boolean }): { text: string; color: string } {
  const { stale, dw, rate, target, avg7, today } = x
  const noise = Math.max(0.05, x.noise ?? 0)
  const dir = goalDir(avg7, target)
  // (v3.50) cilj nad trenutno težo ali na cilju: padec teže ni »Tempo je pravi« (prehitro izgubo spodaj opozorimo kot prej)
  if (!stale && rate != null && !lossTooFast(-rate) && (dir === 'gain' || dir === 'hold')) {
    const band = Math.max(0.1, noise), wobble = Math.abs(rate) >= 0.05 ? ` (${signed(rate, 2)} kg na teden je v okviru nihanja)` : ''
    if (dir === 'hold') {
      if (rate <= -Math.max(0.3, noise)) return { text: `Si na cilju, teža pa pada (${signed(rate, 2)} kg na teden) — jej do vzdrževanja.`, color: 'var(--warn)' }
      if (rate >= Math.max(0.3, noise)) return { text: `Si na cilju, teža pa raste (${signed(rate, 2)} kg na teden) — preveri, ali res zabeležiš vse obroke.`, color: 'var(--ink)' }
      return { text: 'Si na cilju — drži težo (±0,5 kg).', color: 'var(--ok)' }
    }
    if (rate <= -band) return { text: `Teža pada (${signed(rate, 2)} kg na teden), cilj je višje — dodaj 200–300 kcal na dan.`, color: 'var(--warn)' }
    if (rate > 0.5) return { text: `Pridobivaš ${num(rate, 2)} kg na teden — nad 0,5 kg gre večinoma v maščobo. Jej 150–250 kcal manj na dan.`, color: 'var(--warn)' }
    if (rate >= band) {
      const wk = Math.ceil((target! - avg7) / rate)
      return { text: `Tempo je pravi — teža raste proti cilju.${wk <= 520 ? ` Pri tem tempu je cilj dosežen ~${dmy(addDays(today, wk * 7), today)}.` : ''}`, color: 'var(--ok)' }
    }
    return { text: `Teža je stabilna${wobble}. Cilj je višje — za rast rabiš ~200–300 kcal več na dan in redno moč.`, color: 'var(--ink)' }
  }
  const lose = dir === 'lose'
  const evW = x.event?.date ? Math.floor((Date.parse(x.event.date) - Date.parse(today)) / (7 * 86400_000)) : 0
  const byEvent = !!x.event && evW >= 2
  const need = lose ? Math.min(0.5, (avg7 - target!) / (byEvent ? evW : PACE_WEEKS)) : 0
  const weeksTo = lose && rate != null && rate < 0 ? Math.ceil((avg7 - target!) / -rate) : null
  const reach = weeksTo && weeksTo <= 520 ? dmy(addDays(today, weeksTo * 7), today) : null
  const needTxt = `${byEvent ? `do ${dmy(x.event!.date, today)} (${x.event!.name})` : `za cilj v ${PACE_WEEKS} tednih`} bi rabil ~${num(need, 2)} kg na teden`
  const fix = `Preveri, ali res zabeležiš vse obroke (tudi pijače in prigrizke)${x.canMore ? ', ali v Nastavitvah izberi večji deficit' : ''}.`
  // prepočasi: pod 60 % potrebnega tempa; »zanesljivo« prepočasi, ko tudi z nihanjem ne pride do tja
  const slow = lose && rate != null && -rate < 0.6 * need && !lossTooFast(-rate)
  const surelySlow = slow && -rate + noise < 0.6 * need
  const color = rate == null ? 'var(--ink-3)' : lossTooFast(-rate) ? 'var(--warn)' : slow ? 'var(--ink)' : rate < 0 ? 'var(--ok)' : 'var(--ink)'
  const text = stale ? `Zadnje tehtanje pred ${dw} dnevi — stehtaj se zjutraj, da pokažem tempo.`
    : rate == null ? ((x.nPace ?? 0) < 4 ? `Za tempo rabim vsaj 4 tehtanja v 3 tednih — zdaj ${x.nPace ?? 0}. Teža niha ±0,5 kg na dan (voda, sol, OH), zato en dan ne pove nič.` : 'Tempo pokažem, ko bodo tehtanja vsaj 10 dni narazen — teža niha ±0,5 kg na dan.')
    : rate < -0.7 ? 'Izgubljaš več kot 0,7 kg na teden — prehitro, gre tudi mišica in z njo vati. Dodaj 200–300 kcal na dan.'
    : lossTooFast(-rate) ? `Izgubljaš ${num(-rate, 2)} kg na teden — več kot 0,5 kg je prehitro, gredo vati. Dodaj 150–250 kcal na dan.`
    : rate > noise && rate >= 0.2 ? (lose ? `Teža gre gor (+${num(rate, 2)} kg na teden). ${fix}` : 'Teža rahlo gre gor.')
    : surelySlow ? `${rate < -0.05 ? `Izgubljaš ${num(-rate, 2)} kg na teden` : 'Teža stoji'} — ${needTxt}.${reach ? ` Pri tem tempu je cilj dosežen šele ~${reach}.` : ''} ${fix}`
    : slow ? `Teža je stabilna${Math.abs(rate) >= 0.05 ? ` (${signed(rate, 2)} kg na teden je v okviru nihanja)` : ''}. ${needTxt[0]!.toUpperCase()}${needTxt.slice(1)}.`
    : rate < -0.05 ? `Tempo je pravi.${reach ? ` Pri tem tempu je cilj dosežen ~${reach}.` : ''}`
    : Math.abs(rate) <= Math.max(0.1, noise) ? `Teža je stabilna${Math.abs(rate) >= 0.05 ? ` (${signed(rate, 2)} kg na teden je v okviru nihanja)` : ''}.`
    : 'Teža rahlo gre gor.'
  return { text, color }
}

/**
 * (v3.50) Stavek pod kondicijo: »Hujšanje dvigne W/kg …« samo, ko je do ciljne teže še vsaj 1 kg in nisi mladoleten
 * (prej vsakemu kolesarju, tudi 16-letniku in tistemu na cilju).
 */
export function motorNote(x: { custom: boolean; minor: boolean; target: number | null; avg7: number | null }): string {
  if (x.custom) return 'Kondicija raste z rednimi treningi — šteje, da ne izpuščaš, ne posamezen trd dan.'
  if (!x.minor && x.target && x.avg7 != null && x.avg7 - x.target >= 1) return 'Hujšanje dvigne W/kg tudi brez dodatnih vatov — 3 kg manj pri istem FTP je kot +10 W v klanec.'
  return 'Vati rastejo z rednimi ključnimi treningi — kondicija naj počasi raste, forma naj pred tekmo pride v plus.'
}
/** (v3.50) Kje v načrtu si: pri dogovoru »Teden 4 dogovora.« (prej ime načrta kot faza: »Tek, teden 4.«) */
export function phaseLine(cx: Pick<ReturnType<typeof weekContext>, 'custom' | 'phaseName' | 'week' | 'total' | 'recovery'>): string {
  if (cx.custom) return cx.recovery ? `Lažji teden (${cx.week}.).` : `Teden ${cx.week} dogovora.`
  return `${cx.phaseName}, teden ${cx.week}${cx.total ? '/' + cx.total : ''}.`
}

export function Napredek() {
  const app = useApp()
  const ai = useAi()
  const { profile: p, checkins, activities, plan, recentMeals, today, settings } = app
  const custom = isCustom(p)
  const bike = !custom || !!p.focus?.sports.includes('kolo')
  const strength = !custom || agreedStrength(p)
  // (v3.50) »Letos in rekordi« po glavnem športu (tekač in pohodnik ga prej nista imela)
  const recSp = useMemo(() => recordSport(activities, today, bike), [activities, today, bike])
  const [wOpen, setWOpen] = useState(false)
  const [allTests, setAllTests] = useState(false)
  const [allEx, setAllEx] = useState(false)
  const [tk, setTk] = useState<TestEntry['kind'] | null>(null)
  const [tOpen, setTOpen] = useState(false)
  const [busy, setBusy] = useState<string | null>(null)
  // podrobni razdelki so zaprti (ena vrstica); odprt je največ en
  // (v3.50) ?sec= odpre razdelek in ga drži v naslovu (brez novega vnosa) — po osvežitvi ostane odprt
  const [openSec, setOpenSec] = useState<string | null>(() => parseHash().params.sec || null)
  const toggleSec = (id: string) => setOpenSec(o => o === id ? null : id)
  useEffect(() => { replaceParams({ sec: openSec }, 'napredek') }, [openSec])
  const pendingDel = useHidden()
  const [wList, setWList] = useState(false)
  const weighs = recentWeighs(checkins, 14)
  const tr = weightTrend(checkins)

  /* ---- teža ---- */
  const w90 = useMemo(() => checkins.filter(c => c.weightKg && c.date >= addDays(today, -90)).map(c => ({ date: c.date, v: c.weightKg as number })), [checkins, today])
  const avg90 = useMemo(() => w90.map(pt => { const lo = addDays(pt.date, -7), win = w90.filter(q => q.date <= pt.date && q.date > lo); return { date: pt.date, v: +(win.reduce((s, q) => s + q.v, 0) / win.length).toFixed(2) } }), [w90])
  // (v3.48) ciljna teža kot v kartici cilja: ročna ali izračunana (prej samo ročna)
  const target = shownTargetWeight(p, custom, today)
  // tempo samo iz svežih tehtanj (zadnje pred ≥ 7 dnevi → tempa ne kažem; prej »+0,10 kg/teden« iz meritev izpred 13 dni)
  const dw = daysSinceWeigh(checkins, today)
  const stale = dw != null && dw >= 7
  const rate = stale ? null : tr?.deltaWeek ?? null
  const waist = checkins.filter(c => c.waistCm).map(c => ({ date: c.date, v: c.waistCm as number }))
  // (v3.48) eno tehtanje v oknu ni »7-dnevno povprečje«
  const n7 = tr ? checkins.filter(c => c.weightKg && c.weightKg > 30 && c.date <= tr.lastDate && c.date > addDays(tr.lastDate, -7)).length : 0
  // (v3.49) potreben tempo do tekme (cilj sezone) ali v 12 tednih; večji deficit samo, če še gre (strop 750, ne pod 18)
  const pace = tr ? weightPace({ stale, dw, rate, target, avg7: tr.avg7, today, noise: tr.noise, nPace: tr.nPace, event: !custom && p.event?.date && p.event.date > today ? p.event : null, canMore: !isMinor(p) && goalDeficit(p, today) < MAX_DEFICIT }) : null

  /* ---- doslednost 28 dni (v3.48: od začetka, dokler ni 28 dni) ---- */
  const from28 = addDays(today, -27)
  const firstAct = useMemo(() => activities.reduce<string | null>((m, a) => (!m || a.date < m ? a.date : m), null), [activities])
  const spanC = consistencyDays(p, today, firstAct), fromC = addDays(today, -(spanC - 1))
  // hrana šele od začetka (pred njim je ni bilo kam vpisati)
  const spanF = consistencyDays(p, today), fromF = addDays(today, -(spanF - 1))
  const planned = plan.filter(d => d.date >= fromC && d.date < today && d.kind !== 'pocitek' && !d.optional)
  const doneN = planned.filter(d => d.done).length
  const foodDays = new Set(recentMeals.filter(m => m.date >= fromF).map(m => m.date)).size
  const acts28 = activities.filter(a => a.date >= from28)
  // (v3.50) pod 3 vadbami v 28 dneh kondicija »še računam« (kot ploščica Forma na Danes, H35)
  const few = activities.filter(a => a.date >= from28 && a.date <= today).length < 3
  const actsC = activities.filter(a => a.date >= fromC)
  const mealDays = useMemo(() => new Set(recentMeals.map(m => m.date)), [recentMeals])
  let streak = 0
  for (let i = mealDays.has(today) ? 0 : 1; i < 120; i++) { if (mealDays.has(addDays(today, -i))) streak++; else break }

  /* ---- motor ---- */
  const series = useMemo(() => formSeries(activities, today), [activities, today])
  const ctlNow = series.length ? series[series.length - 1]!.ctl : 0
  const ctl6 = series.length > 42 ? series[series.length - 43]!.ctl : 0
  const formEst = useMemo(() => !formReliable(activities, today), [activities, today])
  const wkg = p.ftp && (tr?.avg7 || p.weightKg) ? p.ftp / (tr?.avg7 || p.weightKg!) : null
  const weeks = Array.from({ length: 12 }, (_, i) => addDays(weekStartIso(today), -7 * (11 - i)))
  const hoursBars = weeks.map(ws => {
    const we = addDays(ws, 6), a = activities.filter(x => x.date >= ws && x.date <= we)
    const h = (f: (s: string) => boolean) => +(a.filter(x => f(x.sport)).reduce((s, x) => s + (x.durationMin || 0), 0) / 60).toFixed(1)
    // (v3.50) plavanje in »drugo« niso »tek/hoja«
    return { label: fmtD(ws), parts: [{ v: h(s => s === 'kolo'), color: 'var(--t-kolo)' }, { v: h(s => s === 'moc'), color: 'var(--t-moc)' }, { v: h(s => s === 'tek' || s === 'pohod'), color: 'var(--t-tek)' }, { v: h(s => s === 'plavanje' || s === 'drugo'), color: 'var(--t-poc)' }] }
  })
  const barsLegend = [{ label: 'kolo', color: 'var(--t-kolo)' }, { label: 'moč', color: 'var(--t-moc)' }, { label: 'tek, hoja', color: 'var(--t-tek)' }, { label: 'plavanje, drugo', color: 'var(--t-poc)' }].filter((_, j) => hoursBars.some(b => b.parts[j]!.v > 0))
  const barsTot = hoursBars.map(b => b.parts.reduce((t, x) => t + x.v, 0))
  const barsAria = `Ure vadbe na teden, zadnjih 12 tednov: ta teden ${unit(dec(barsTot[barsTot.length - 1] ?? 0, 1), 'h')}, največ ${unit(dec(Math.max(0, ...barsTot), 1), 'h')}`

  /* ---- moč po vajah ---- */
  const byEx = useMemo(() => {
    const m = new Map<string, { name: string; list: { date: string; sets: number; reps: string; kg?: number | null }[] }>()
    for (const a of [...activities].filter(x => x.sport === 'moc' && x.exercises?.length).sort((x, y) => x.date.localeCompare(y.date)))
      for (const e of a.exercises!) { const k = e.name.toLowerCase(); if (!m.has(k)) m.set(k, { name: e.name, list: [] }); m.get(k)!.list.push({ date: a.date, sets: e.sets, reps: e.reps, kg: e.kg }) }
    return [...m.values()].sort((a, b) => b.list.length - a.list.length)
  }, [activities])
  // (v3.50) 8 najpogostejših, ostale s »vse vaje« (prej so izginile brez obvestila)
  const exShown = allEx ? byEx : byEx.slice(0, 8)
  const mocN = activities.filter(a => a.sport === 'moc' && a.date >= from28).length
  /* ---- mišice ta teden (serije na mišico, zadnjih 7 dni) in rekordi ---- */
  const from7 = addDays(today, -6)
  const muscleSets = useMemo(() => setsByMuscle(activities.filter(a => a.sport === 'moc' && a.date >= from7).flatMap(a => (a.exercises || []).map(e => ({ name: e.name, sets: e.sets })))), [activities, from7])
  const msTotal = Object.values(muscleSets).reduce((t, x) => t + x, 0)
  const prs = useMemo(() => personalRecords(activities).slice(0, 6), [activities])

  /* ---- testi in mejniki ---- */
  // test, ki čaka na izbris (»Razveljavi«), je takoj skrit
  const tests = [...(settings.tests || [])].filter(t => !pendingDel.has('test:' + t.id)).sort((a, b) => b.date.localeCompare(a.date))
  // (v3.50) trend testa (tudi pražni utrip iz vodenega testa brez merilnika, A18): vrste z vsaj dvema rezultatoma
  const trendKinds = TESTS.map(t => t.kind).filter(k => tests.filter(x => x.kind === k).length >= 2)
  const tKind = tk && trendKinds.includes(tk) ? tk : tests.find(x => trendKinds.includes(x.kind))?.kind ?? null
  const tPts = tKind ? tests.filter(x => x.kind === tKind).map(x => ({ date: x.date, v: x.value })).sort((a, b) => a.date.localeCompare(b.date)) : []
  const TT = tKind ? TESTS.find(t => t.kind === tKind)! : null
  const miles = TESTS.filter(t => t.milestones).map(t => {
    const last = tests.find(x => x.kind === t.kind); if (!last) return null
    const ms = t.milestones!, next = ms.find(m => m > last.value) ?? null
    return { t, value: last.value, next, level: ms.filter(m => m <= last.value).length, of: ms.length }
  }).filter(Boolean) as { t: typeof TESTS[number]; value: number; next: number | null; level: number; of: number }[]

  /* ---- meseci ---- */
  const ym = today.slice(0, 7), prevYm = addDays(today.slice(0, 8) + '01', -1).slice(0, 7)
  const month = (m: string, acts: readonly Activity[] = activities) => {
    // (v3.50) km in vzpon glavnega športa (tekač prej ni imel km)
    const a = acts.filter(x => x.date.slice(0, 7) === m), k = a.filter(x => x.sport === recSp)
    const w = checkins.filter(c => c.weightKg && c.date.slice(0, 7) === m).sort((x, y) => x.date.localeCompare(y.date))
    // (v3.48) današnji dan še ni končan — ne gre v povprečje meseca
    const md = [...new Set(recentMeals.filter(x => x.date.slice(0, 7) === m && x.date !== today).map(x => x.date))]
    const kc = md.map(d => recentMeals.filter(x => x.date === d).reduce((s, x) => s + x.kcal, 0))
    return { m, n: a.length, min: a.reduce((s, x) => s + (x.durationMin || 0), 0), km: Math.round(k.reduce((s, x) => s + (x.distKm || 0), 0)), elev: Math.round(k.reduce((s, x) => s + (x.elevM || 0), 0)), tss: Math.round(a.reduce((s, x) => s + (x.tss || 0), 0)), moc: a.filter(x => x.sport === 'moc').length, w0: w[0]?.weightKg ?? null, w1: w[w.length - 1]?.weightKg ?? null, kcal: kc.length ? Math.round(kc.reduce((s, x) => s + x, 0) / kc.length) : null, foodDays: md.length }
  }
  const mNow = month(ym), mPrev = month(prevYm)
  // AI dobi samo aktivnosti, ki jih sme videti (Strava in neznani izvori NIKOLI v poziv)
  const hidden = hasHiddenActivities(activities)
  const aiActs = activities.filter(aiAllowed)
  const mText = (x: ReturnType<typeof month>) => `${MON[+x.m.slice(5, 7) - 1]} ${x.m.slice(0, 4)}: ${count(x.n, W.vadba)}, ${fmtDur(x.min)}${x.km ? `, ${unit(num(x.km), 'km')}${recSp === 'tek' ? ' teka' : recSp === 'pohod' ? ' hoje' : ''}${x.elev ? `, ${unit(num(x.elev), 'm')} vzpona` : ''}` : ''}, ${int(x.tss)}${NBSP}TSS, moč ${x.moc}×; teža ${x.w0 != null ? `${num(x.w0)} → ${unit(num(x.w1 ?? x.w0), 'kg')}` : 'ni podatka'}; prehrana ${x.kcal ? `povprečno ${unit(num(x.kcal), 'kcal')} (${count(x.foodDays, W.dan)})` : 'ni zabeležena'}.`
  const review = settings.monthReviews?.[ym]
  const cx = weekContext(p, weekStartIso(today))
  const tgt = dailyTarget(p, [], [], today)


  async function doMonth() {
    setBusy('month')
    const t = await ai.run(() => monthReview(snapOf(getState()), `${mText(month(ym, aiActs))}\nPrejšnji mesec — ${mText(month(prevYm, aiActs))}`))
    setBusy(null)
    if (t) await updateSettings({ monthReviews: { ...(settings.monthReviews || {}), [ym]: { at: new Date().toISOString(), text: t } } })
  }

  return (<>
    <Head hi={custom ? 'Moč · teža · kondicija' : 'W/kg · teža · motor'} nm="Napredek" />
    <div className="scroll">
      <div className="stack" style={{ gap: 12 }}>
        {/* »Na kratko« je ponavljal kartice spodaj (cilj, W/kg, teža, doslednost) — brez njega (Blaž: manj besedila) */}
        <div className="cols gap">
        <div className="col">
        <div id="p-cilj" className="nav-target">{custom ? <DealCard full /> : <GoalCard full />}</div>

        {bike && realityHas(activities, today) && (
          <Section id="p-res" title="Trening v resnici" sum={realitySum(activities, today)} open={openSec === 'p-res'} onToggle={() => toggleSec('p-res')}><RealityCard /></Section>
        )}

        {/* MIŠICE: serije na mišico ta teden (zemljevid) — načrt po meri ali kdor dela moč z vajami */}
        {showMuscles(p, msTotal) && (
          <Card id="p-misice" className="nav-target">
            <div className="between"><h2 className="h4" style={{ margin: 0 }}>Mišice · zadnjih 7 dni</h2><span className="muted" style={{ fontSize: 12, fontWeight: 700 }}>{msTotal ? count(Math.round(msTotal), W.serija) : ''}</span></div>
            {msTotal ? (
              <div className="row" style={{ gap: 16, marginTop: 10, alignItems: 'center' }}>
                <BodyMap levels={Object.fromEntries(Object.entries(muscleSets).map(([m, n]) => [m, Math.min(1, n / 10)]))} size={150} run={false} label="Serije na mišico v zadnjih 7 dneh" />
                <div style={{ flex: 1, minWidth: 0, display: 'grid', gap: 5 }}>
                  {(Object.entries(muscleSets) as [keyof typeof MUSCLE_LABEL, number][]).sort((a, b) => b[1] - a[1]).map(([m, n]) => (
                    <div key={m} className="between" style={{ fontSize: 13 }}><span style={{ color: n ? 'var(--ink)' : 'var(--ink-3)', fontWeight: 600 }}>{MUSCLE_LABEL[m]}</span><b style={{ color: n >= 10 ? 'var(--accent-fg)' : n ? 'var(--ink)' : 'var(--ink-3)', fontWeight: 800 }}>{num(n, 1)}</b></div>
                  ))}
                </div>
              </div>
            ) : <p style={{ fontSize: 13, marginTop: 8 }}>Ko opraviš vadbo moči (Začni trening), tu zasvetijo mišice, ki si jih treniral — 10 serij na mišico na teden je dober cilj za rast.</p>}
            {msTotal > 0 && <p className="muted" style={{ fontSize: 12, marginTop: 10 }}>10–20 serij na mišico na teden gradi mišice; manj jih ohranja. Pomožne mišice štejejo pol serije. Svetlejše = več serij.</p>}
          </Card>
        )}

        </div>
        <div className="col">
        {/* TEŽA */}
        <Card id="p-teza" className="nav-target">
          <div className="between"><h2 className="h4" style={{ margin: 0 }}>Teža</h2><Btn sm onClick={() => setWOpen(true)}><IcoScale width={16} height={16} /> Stehtaj se</Btn></div>
          {tr ? (<>
            <div className="row" style={{ gap: 18, marginTop: 10, flexWrap: 'wrap' }}>
              <div><div style={{ fontSize: 28, fontWeight: 800, letterSpacing: '-.03em' }}>{n1(tr.avg7)} <span style={{ fontSize: 14, color: 'var(--ink-3)' }}>kg</span></div><div className="muted" style={{ fontSize: 11.5, fontWeight: 700 }}>{/* (v3.50) staro tehtanje: do kdaj velja (prej »7-DNEVNO POVPREČJE« 14 dni po tehtanju) */}{stale ? (n7 > 1 ? `POVPREČJE DO ${fmtD(tr.lastDate)}` : `TEHTANJE ${fmtD(tr.lastDate)}`) : n7 > 1 ? '7-DNEVNO POVPREČJE' : 'ZADNJE TEHTANJE'}</div></div>
              <div><div style={{ fontSize: 18, fontWeight: 800, color: pace!.color }}>{rate == null ? '—' : unit(signed(rate, 2), 'kg')}</div><div className="muted" style={{ fontSize: 11.5, fontWeight: 700 }}>NA TEDEN</div></div>
              {/* (v3.50) cilj višje: »+5,1 kg«; na cilju (±0,5): »NA CILJU« (prej »0,0 kg DO CILJA 85,0«); cilj kot drugod (»72«, ne »72,0«) */}
              {target && <div><div style={{ fontSize: 18, fontWeight: 800 }}>{goalDir(tr.avg7, target) === 'hold' ? unit(num(target, 1), 'kg') : goalDir(tr.avg7, target) === 'gain' ? unit('+' + n1(target - tr.avg7), 'kg') : unit(n1(tr.avg7 - target), 'kg')}</div><div className="muted" style={{ fontSize: 11.5, fontWeight: 700 }}>{goalDir(tr.avg7, target) === 'hold' ? 'NA CILJU' : `DO CILJA ${num(target, 1)}`}</div></div>}
            </div>
            {/* graf šele z dvema meritvama (prej velik prazen okvir »Za graf rabim vsaj dve meritvi«) */}
            {w90.length >= 2 && <div style={{ marginTop: 12 }}><DotLineChart points={w90} line={avg90} reference={target} refLabel="cilj" unit="kg" title="Teža" until={today} /></div>}
            <p className="muted" style={{ fontSize: 12.5, marginTop: 10 }}>
              {pace!.text}
              {tgt ? ` Dnevni cilj brez treninga ${fmtKcal(tgt.kcal)}${NBSP}kcal, beljakovine ${tgt.proteinG}${NBSP}g.` : ''}
            </p>
            {tgt && <HealthNote kind="food" />}
            {waist.length >= 2 && <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>Pas: {n1(waist[0]!.v)} → <b style={{ color: 'var(--ink)' }}>{unit(n1(waist[waist.length - 1]!.v), 'cm')}</b> ({unit(signed(waist[waist.length - 1]!.v - waist[0]!.v, 1), 'cm')}) — pas pove več kot tehtnica, ko hkrati gradiš mišice.</div>}
            {/* (v3.49) napačno tehtanje (97 namesto 79) se da izbrisati — povprečje, cilj in kalorije se popravijo */}
            {weighs.length > 0 && <div style={{ marginTop: 8 }}><button type="button" className="chip sm click" aria-expanded={wList} onClick={() => setWList(!wList)}>{wList ? 'Skrij tehtanja' : 'Zadnja tehtanja ›'}</button></div>}
            {wList && weighs.length > 0 && <div className="stack" style={{ gap: 0, marginTop: 6 }}>{weighs.map(c => (
              <div key={c.date} className="between" style={{ padding: '7px 0', borderTop: '1px solid var(--line)', fontSize: 13, alignItems: 'center' }}>
                <span className="muted">{fmtD(c.date)}</span>
                <span className="row" style={{ gap: 8, flex: 'none' }}><b>{unit(n1(c.kg), 'kg')}</b><button className="chip sm click icon-x" onClick={() => void removeWeigh(c.date)} aria-label={`Izbriši tehtanje ${fmtD(c.date)}, ${n1(c.kg)} kg`}>×</button></span>
              </div>))}</div>}
          </>) : <p style={{ fontSize: 13, marginTop: 8 }}>Še ni tehtanja. Stehtaj se zjutraj, po stranišču, pred zajtrkom — vedno enako. Šteje 7-dnevno povprečje, ne posamezen dan.</p>}
        </Card>

        {/* DOSLEDNOST */}
        <Card tight>
          <h2 className="h4" style={{ fontSize: 11 }}>Doslednost · {spanC < 28 ? 'od začetka' : 'zadnjih 28 dni'}</h2>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, textAlign: 'center', marginTop: 8 }}>
            <div><div style={{ fontSize: 20, fontWeight: 800 }}>{planned.length ? pct(doneN / planned.length * 100) : '—'}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>sej po planu</div></div>
            <div><div style={{ fontSize: 20, fontWeight: 800 }}>{foodDays}/{spanF}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>dni s hrano{streak >= 3 ? ` · niz ${streak}` : ''}</div></div>
            <div><div style={{ fontSize: 20, fontWeight: 800 }}>{unit(Math.round(actsC.reduce((s, a) => s + (a.durationMin || 0), 0) / 60), 'h')}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>{count(actsC.length, W.vadba)}</div></div>
          </div>

          {/* seznam vseh vadb: podrobnosti, opomba, občutek, izbris (v3.48 — prej samo prek Uvoz → Ročni vnos) */}
          <div style={{ textAlign: 'right', marginTop: 8 }}><button type="button" className="chip sm click" onClick={() => navigate('aktivnosti')}>Vse vadbe ›</button></div>
        </Card>

        {/* MOTOR / KONDICIJA — zaprto: ena vrstica s kondicijo (in FTP) */}
        <Section id="p-motor" title={custom ? 'Kondicija' : 'Motor'} sum={!activities.length ? 'še brez vadb' : `kondicija ${few ? 'še računam' : Math.round(ctlNow)}${custom && !bike ? ` · ${count(acts28.length, W.vadba)} v 28 dneh` : p.ftp ? ` · FTP ${unit(p.ftp, 'W')}${wkg ? ` · ${dec(wkg, 2)} W/kg` : ''}` : ''}`} open={openSec === 'p-motor'} onToggle={() => toggleSec('p-motor')}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginTop: 10 }}>
            {/* (v3.50) pod 3 vadbami »še računam« (kot Danes); sprememba »v 6 tednih« v svoji vrstici (prej »v 6 t.«) */}
            <div><div style={{ fontSize: 20, fontWeight: 800, color: few ? 'var(--ink-3)' : 'var(--t-kolo-ink)' }}>{few ? '—' : Math.round(ctlNow)}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>kondicija{few ? ' · še računam' : formEst ? ' · ocena' : ''}</div>{!few && !formEst && series.length > 42 && <div className="muted" style={{ fontSize: 11, fontWeight: 600 }}>{signed(Math.round(ctlNow - ctl6), 0)} v 6 tednih</div>}</div>
            {custom && !bike ? (<>
              <div><div style={{ fontSize: 20, fontWeight: 800 }}>{fmtDur(Math.round(acts28.reduce((t, a) => t + (a.durationMin || 0), 0) / 4))}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>na teden · 4 tedne</div></div>
              <div><div style={{ fontSize: 20, fontWeight: 800 }}>{acts28.length}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>{plural(acts28.length, W.vadba)} v 28 dneh</div></div>
            </>) : (<>
              <div><div style={{ fontSize: 20, fontWeight: 800 }}>{p.ftp ? unit(p.ftp, 'W') : '—'}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>FTP{p.ftpDate ? ` · ${fmtD(p.ftpDate)}` : ''}</div></div>
              <div><div style={{ fontSize: 20, fontWeight: 800 }}>{wkg ? dec(wkg, 2) : '—'}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>W/kg</div></div>
            </>)}
          </div>
          <p className="muted" style={{ fontSize: 12, margin: '8px 0 12px' }}>{motorNote({ custom, minor: isMinor(p), target, avg7: tr?.avg7 ?? null })}{cx.structured ? ` ${phaseLine(cx)}` : ''}</p>
          {/* (v3.48) graf forme: kondicija, utrujenost in forma zadnjih 90 dni */}
          {series.length >= 2 && <div style={{ marginBottom: 14 }}><FormChart data={series.slice(-90)} height={170} />{formEst && <p className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>Ocena — za točno formo rabim vsaj 6 tednov vadb.</p>}</div>}
          <h3 className="h4" style={{ fontSize: 12, margin: '0 0 6px' }}>Ure na teden · 12 tednov</h3>
          <StackBars bars={hoursBars} legend={barsLegend} unit="h" label={barsAria} />
        </Section>

        {recordsHas(activities, today, recSp) && <Section id="p-rekordi" title="Letos in rekordi" sum={recordsSum(activities, today, recSp)} open={openSec === 'p-rekordi'} onToggle={() => toggleSec('p-rekordi')}><RecordsCard acts={activities} today={today} sport={recSp} /></Section>}
        {(hrZoneRows(p) || powerZoneRows(p)) && <Section id="p-cone" title="Tvoje cone" sum={powerZoneRows(p) && hrZoneRows(p) ? 'utrip in moč' : powerZoneRows(p) ? 'moč (W)' : 'utrip (bpm)'} open={openSec === 'p-cone'} onToggle={() => toggleSec('p-cone')}><ZonesCard p={p} /></Section>}

        {/* MOČ — samo, če jo treniraš */}
        {(p.strength.on || mocN > 0) && <Section id="p-moc" title="Moč" sum={mocN ? `${count(mocN, W.vadba)} v 28 dneh${prs.some(r => r.kg) ? ' · rekordi' : ''}${byEx.length ? ' · po vajah' : ''}` : 'še brez vadb moči'} open={openSec === 'p-moc'} onToggle={() => toggleSec('p-moc')}>
          {prs.some(r => r.kg) && (
            <div style={{ marginTop: 10 }}>
              <div className="muted" style={{ fontSize: 11, fontWeight: 800, letterSpacing: '.06em', textTransform: 'uppercase' }}>Rekordi</div>
              {prs.filter(r => r.kg).slice(0, 5).map(r => (
                <div key={r.name} className="between" style={{ fontSize: 13, padding: '5px 0', borderTop: '1px solid var(--line-soft)' }}>
                  <span style={{ fontWeight: 600, minWidth: 0 }}>{r.name}</span>
                  <span style={{ flex: 'none', textAlign: 'right' }}><b>{unit(num(r.kg!), 'kg')}{r.reps ? ` × ${r.reps}` : ''}</b>{r.e1rm ? <span className="muted" style={{ fontSize: 11.5 }}> · 1RM ~{unit(num(r.e1rm), 'kg')}</span> : null}<span className="muted" style={{ fontSize: 11.5 }}> · {fmtD(r.date)}</span></span>
                </div>
              ))}
            </div>
          )}
          {miles.length > 0 && <div className="stack" style={{ gap: 10, marginTop: 10 }}>
            {miles.map(m => (
              <div key={m.t.kind}>
                <div className="between" style={{ fontSize: 13 }}><b>{m.t.label.split(' — ')[0]}</b><span className="muted" style={{ fontWeight: 700 }}>{unit(num(m.value), m.t.unit)}{m.next ? ` · naslednji mejnik ${m.next}` : ' · vsi mejniki'}</span></div>
                <div style={{ marginTop: 5 }}><Track pct={m.level / m.of * 100} color="var(--t-moc)" /></div>
              </div>
            ))}
          </div>}
          {byEx.length ? (<>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13, marginTop: 12 }}>
              <thead><tr style={{ color: 'var(--ink-3)', fontSize: 11 }}><th style={{ textAlign: 'left', padding: '4px 0' }}>vaja</th><th style={{ textAlign: 'right' }}>prvič</th><th style={{ textAlign: 'right' }}>zadnjič</th><th style={{ textAlign: 'right' }}>×</th></tr></thead>
              <tbody>{exShown.map(e => { const a = e.list[0]!, z = e.list[e.list.length - 1]!, f = (x: typeof a) => `${x.sets}×${x.reps}${x.kg ? ' @' + x.kg : ''}`; return (
                <tr key={e.name} style={{ borderTop: '1px solid var(--line)' }}><td style={{ padding: '7px 0', fontWeight: 600 }}>{e.name}</td><td className="muted" style={{ textAlign: 'right' }}>{f(a)}</td><td style={{ textAlign: 'right', fontWeight: 800 }}>{f(z)}</td><td className="muted" style={{ textAlign: 'right' }}>{e.list.length}</td></tr>) })}</tbody>
            </table>
            {byEx.length > 8 && <div style={{ marginTop: 6 }}><button type="button" className="chip sm click" aria-expanded={allEx} onClick={() => setAllEx(!allEx)}>{allEx ? 'manj vaj' : `vse vaje (${byEx.length})`}</button></div>}
          </>) : <p style={{ fontSize: 13, marginTop: 8 }}>Ko moč opraviš z vodeno vadbo (Začni trening) ali vpišeš vaje, se tu vidi napredek po vajah.</p>}
        </Section>}

        {/* TESTI */}
        <Section id="p-testi" title="Testi" sum={tests.length ? `zadnji ${fmtD(tests[0]!.date)} · ${TESTS.find(x => x.kind === tests[0]!.kind)?.label.split(' — ')[0] ?? ''}` : !custom || (bike && !strength) ? 'FTP in 5-min test' : strength ? `${bike ? 'FTP, ' : ''}deska, zgibi, sklece, počepi` : 'utrip v mirovanju'} open={openSec === 'p-testi'} onToggle={() => toggleSec('p-testi')}>
          <div className="between" style={{ marginTop: 2 }}><span className="muted" style={{ fontSize: 12 }}>{tests.length ? `${count(tests.length, W.test)}` : 'še brez testov'}</span><Btn sm onClick={() => setTOpen(true)}><IcoPlus width={15} height={15} /> Vpiši</Btn></div>
          {TT && tPts.length >= 2 && <div className="test-trend" style={{ marginTop: 10 }}>
            {trendKinds.length > 1 && <div className="row" role="group" aria-label="Trend testa" style={{ gap: 6, flexWrap: 'wrap', marginBottom: 8 }}>{trendKinds.map(k => <Chip key={k} sm on={k === tKind} onClick={() => setTk(k)}>{TESTS.find(t => t.kind === k)!.label.split(' — ')[0]}</Chip>)}</div>}
            <DotLineChart points={tPts} unit={TT.unit} decimals={0} title={TT.label} pointLabel={TT.label.split(' — ')[0]!} height={120} />
            <p className="muted" style={{ fontSize: 12, marginTop: 4 }}>{TT.label.split(' — ')[0]}: {unit(num(tPts[0]!.v), TT.unit)} → <b style={{ color: 'var(--ink)' }}>{unit(num(tPts[tPts.length - 1]!.v), TT.unit)}</b> · {count(tPts.length, W.test)} od {fmtD(tPts[0]!.date)}</p>
          </div>}
          {tests.length ? (
            <div className="stack" style={{ gap: 0, marginTop: 8 }}>
              {(allTests ? tests : tests.slice(0, 12)).map(t => { const T = TESTS.find(x => x.kind === t.kind)!; return (
                <div key={t.id} className="between" style={{ padding: '8px 0', borderTop: '1px solid var(--line)', fontSize: 13, alignItems: 'center' }}>
                  <span style={{ minWidth: 0 }}><span className="muted">{fmtD(t.date)}</span> · {T.label}</span>
                  <span className="row" style={{ gap: 8, flex: 'none' }}><b>{unit(num(t.value), t.unit)}</b>{t.kind === 'ftp' && <span className="muted">FTP {Math.round(t.value * .95)}</span>}{t.kind === 'p5' && (tr?.avg7 || p.weightKg) ? <span className="muted">VO2max ~{vo2maxFromP5(t.value, (tr?.avg7 || p.weightKg)!)}</span> : null}<button className="chip sm click icon-x" onClick={() => deferDelete('test:' + t.id, `Izbrisan test: ${T.label.split(' — ')[0]}`, () => removeTest(t.id))} aria-label={`Izbriši test ${T.label.split(' — ')[0]} ${fmtD(t.date)}`}>×</button></span>
                </div>) })}
              {/* (v3.50) vsi testi (prej samo zadnjih 12, brez obvestila) */}
              {tests.length > 12 && <div style={{ marginTop: 6 }}><button type="button" className="chip sm click" aria-expanded={allTests} onClick={() => setAllTests(!allTests)}>{allTests ? 'manj testov' : `pokaži vse (${tests.length})`}</button></div>}
            </div>
          ) : <p style={{ fontSize: 13, marginTop: 8 }}>{custom && strength ? 'Vsakih nekaj tednov ponovi iste teste (deska, zgibi, sklece, počepi v 2 minutah) — tako vidiš napredek s številkami, ne le z občutkom. Najbolje v lažjem tednu.' : custom && !bike ? 'Vsakih nekaj tednov izmeri utrip v mirovanju — zjutraj v postelji, 1 minuto. Nižji utrip pomeni boljšo kondicijo.' : '20-min test FTP je v načrtu vsakih 8 tednov (v razbremenilnem tednu). 5-min test pove, kje je tvoj VO2max — ponovi ga v isti razbremenitvi.'}</p>}
        </Section>

        {/* MESEC */}
        <Section id="p-mesec" title={`Ta mesec · ${MON[+ym.slice(5, 7) - 1]!}`} sum={mNow.n ? `${count(mNow.n, W.vadba)}, ${fmtDur(mNow.min)}${review ? ' · AI ocena' : ''}` : `še brez vadb${review ? ' · AI ocena' : ''}`} open={openSec === 'p-mesec'} onToggle={() => toggleSec('p-mesec')}>
          <p style={{ fontSize: 13, marginTop: 8, color: 'var(--ink)' }}>{mText(mNow)}</p>
          <p className="muted" style={{ fontSize: 12, marginTop: 6 }}>Prej — {mText(mPrev)}</p>
          {review && <p style={{ fontSize: 13.5, marginTop: 10, lineHeight: 1.55, color: 'var(--ink)', whiteSpace: 'pre-wrap' }}>{sanitizeGaps(review.text, hidden)}</p>}
          {!mNow.n && !mNow.foodDays && !review && <p className="muted" style={{ fontSize: 12, marginTop: 6 }}>Ta mesec še ni česa oceniti — po prvi vadbi ali vpisanem dnevu.</p>}
          <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
            {!app.user && (mNow.n > 0 || mNow.foodDays > 0) && <Btn ghost sm onClick={() => navigate('nastavitve', { sec: 'n-racun' })}>Prijava za AI oceno</Btn>}
            {/* (v3.50) AI ocena samo prijavljenim (prej klik → »Prijava ni uspela«) in samo, ko je kaj oceniti */}
            {app.user && (mNow.n > 0 || mNow.foodDays > 0) && <Btn ghost sm disabled={ai.busy} onClick={doMonth}>{busy === 'month' && ai.busy ? 'Pišem …' : review ? 'Osveži oceno meseca' : 'AI ocena meseca'}</Btn>}
            <Btn ghost sm onClick={() => { void copyText(`${mText(mNow)}\n${review ? sanitizeGaps(review.text, hidden) : ''}`).then(ok => toast(ok ? 'Kopirano.' : 'Kopiranje ni uspelo — označi besedilo in ga kopiraj ročno.', ok ? 'ok' : 'err', ok ? undefined : 6000)) }}>Kopiraj</Btn>
          </div>
        </Section>
        </div>
        </div>
        {hasGarminData(app.activities) && <p className="muted" style={{ fontSize: 11, textAlign: 'center', margin: '2px 0 0' }}>Forma, obremenitev in ocene so izračunani delno iz podatkov naprav Garmin (prek intervals.icu).</p>}

      </div>
    </div>

    <WeighSheet open={wOpen} onClose={() => setWOpen(false)} />
    <TestSheet open={tOpen} onClose={() => setTOpen(false)} custom={custom} bike={bike} strength={strength} />
    {ai.sheet}
  </>)
}

/* ---------- test ---------- */
export function TestSheet({ open, onClose, custom = false, bike = true, strength = true }: { open: boolean; onClose: () => void; custom?: boolean; bike?: boolean; strength?: boolean }) {
  const offer = offeredTests(custom, bike, strength)
  const app = useApp()
  const [kind, setKind] = useState<TestEntry['kind']>(offer[0]?.kind ?? 'ftp')
  const [val, setVal] = useState('')
  const [date, setDate] = useState(todayIso())
  // (v3.49) razpon po vrsti testa (sporočilo pod poljem) in potrditev velikega skoka FTP
  const [touched, setTouched] = useState(false)
  const [ask, setAsk] = useState<string | null>(null)
  const T = TESTS.find(t => t.kind === kind)!
  const err = testError(kind, val)
  const shownErr = touched ? err : null
  async function save() {
    const v = +String(val).replace(',', '.')
    if (!(v > 0)) { toast('Vpiši rezultat.', 'err'); return }
    if (err) { setTouched(true); return }
    const jump = testJump(kind, v, latestFtpTest(app.settings.tests || [])?.value, app.profile.ftp)
    if (jump && ask !== jump) { setAsk(jump); return }
    try { await addTest({ id: uid(), date, kind, value: v, unit: T.unit }) } catch { return }   // ni shranjeno: obvestilo je že pokazal store
    setVal(''); setAsk(null); setTouched(false); onClose()
  }
  return (
    <Sheet open={open} onClose={onClose}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Vpiši test</b>
      <div className="row" style={{ gap: 7, flexWrap: 'wrap', margin: '12px 0' }}>{offer.map(t => <Chip key={t.kind} sm on={kind === t.kind} onClick={() => { setKind(t.kind); setAsk(null) }}>{t.label.split(' — ')[0]}</Chip>)}</div>
      <p style={{ fontSize: 12.5 }}>{T.hint}</p>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 12 }}>
        <div className="field"><label htmlFor="test-val">Rezultat <span className="unit">{T.unit}</span></label><DecimalInput id="test-val" value={val} onChange={e => { setVal(e.target.value); setAsk(null) }} onBlur={() => setTouched(true)} autoFocus aria-invalid={shownErr ? true : undefined} aria-describedby={shownErr ? 'test-err' : undefined} style={shownErr ? { borderColor: 'var(--warn)' } : undefined} /></div>
        <div className="field"><label>Datum</label><DateField compact value={date} max={todayIso()} onChange={v => setDate(v || todayIso())} label="Datum" /></div>
      </div>
      {shownErr && <div id="test-err" role="alert" style={{ fontSize: 12, color: 'var(--warn)', marginTop: 8 }}>{shownErr}</div>}
      {ask && <div role="alert" style={{ fontSize: 12.5, color: 'var(--ink)', marginTop: 10, fontWeight: 600 }}>{ask}</div>}
      <Btn primary block style={{ marginTop: 14 }} onClick={save}>{ask ? 'Da, shrani' : 'Shrani'}</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Prekliči</Btn>
    </Sheet>
  )
}
