import { useMemo, useState } from 'react'
import { hrZoneRows, powerZoneRows } from '@/domain/training/zwo'
import { Head } from '@/app/Shell'
import { navigate } from '@/app/router'
import { useApp, getState, addTest, removeTest, updateSettings, toast } from '@/state/store'
import { snapOf } from '@/state/snap'
import { useAi } from '@/ui/useAi'
import { weightTrend, dailyTarget, lossTooFast } from '@/domain/nutrition/energy'
import { shownTargetWeight } from '@/domain/nutrition/body'
import { daysSinceWeigh } from '@/domain/alerts'
import { formSeries, formReliable, addDays, weekStartIso, fmtDur, todayIso } from '@/domain/training/load'
import { weekContext } from '@/domain/training/planner'
import { vo2maxFromP5 } from '@/domain/training/goal'
import { GoalCard } from '@/ui/GoalCard'
import { ZonesCard } from '@/ui/ZonesCard'
import { RecordsCard, recordsHas } from '@/ui/RecordsCard'
import { RealityCard, realityHas } from '@/ui/RealityCard'
import { Section } from '@/ui/Section'
import { monthReview } from '@/domain/ai/actions'
import { sanitizeGaps, hasHiddenActivities } from '@/domain/ai/sanitize'
import { aiAllowed, hasGarminData } from '@/domain/import/provenance'
import type { Activity, Profile, TestEntry } from '@/domain/types'
import { Card, Chip, Btn, Sheet, Track, fmtKcal, DecimalInput } from '@/ui/primitives'
import { DotLineChart, FormChart, StackBars } from '@/ui/charts'
import { WeighSheet } from '@/ui/WeighSheet'
import { IcoScale, IcoPlus } from '@/ui/icons'
import { DateField } from '@/ui/DateField'
import { DealCard } from '@/ui/DealCard'
import { BodyMap } from '@/ui/BodyMap'
import { isCustom, isStrength } from '@/domain/focus/model'
import { personalRecords, setsByMuscle, MUSCLE_LABEL } from '@/domain/training/exercises'
import { HealthNote } from '@/ui/HealthNote'
import { deferDelete, useHidden } from '@/ui/Confirm'
import { count, dec, dm, int, num, pct, plural, signed, unit, NBSP, W } from '@/ui/format'

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
const MON = ['januar', 'februar', 'marec', 'april', 'maj', 'junij', 'julij', 'avgust', 'september', 'oktober', 'november', 'december']
/** Testi za kolesarja (offer) + stari zapisi, ki jih samo še prikažemo. */
export const TESTS: { kind: TestEntry['kind']; label: string; unit: string; hint: string; milestones?: number[]; offer?: boolean }[] = [
  { kind: 'ftp', label: '20-min test', unit: 'W', hint: 'Povprečna moč 20 minut po ogrevanju. FTP = 95 % te številke — vati v načrtu se posodobijo.', offer: true },
  { kind: 'p5', label: '5-min največja moč', unit: 'W', hint: 'Povprečna moč 5 minut vse, kar gre (po ogrevanju, na spočite noge). Iz nje ocenim VO2max.', offer: true },
  { kind: 'rhr', label: 'Utrip v mirovanju', unit: 'bpm', hint: 'Zjutraj v postelji, 1 minuto. Nižje = boljši motor; +5 nad običajnim = utrujenost.', offer: true },
  { kind: 'deska', label: 'Deska — max', unit: 's', hint: 'Do porušitve položaja. Močan trup = stabilnost pri vsaki vaji (in na kolesu).', milestones: [60, 90, 120, 180, 240], offer: true },
  { kind: 'zgibi', label: 'Zgibi — max v seriji', unit: 'pon.', hint: 'Največ zgibov v eni seriji: spodaj roke iztegnjene, zgoraj brada nad drogom, brez zibanja.', milestones: [1, 5, 10, 15, 20] },
  { kind: 'sklece', label: 'Sklece — max v seriji', unit: 'pon.', hint: 'Največ sklec v eni seriji: telo ravno od glave do pet, prsi skoraj do tal.', milestones: [10, 20, 30, 40, 50] },
  { kind: 'pocep', label: 'Počepi v 2 minutah', unit: 'pon.', hint: 'Koliko počepov narediš v 2 minutah, do vzporedno, brez uteži.', milestones: [40, 60, 80, 100] },
]
const n1 = (v: number) => dec(v, 1)
const fmtD = dm

/**
 * Testi, ki jih ponudimo: kolesar FTP in 5 min; načrt po meri po športih dogovora (v3.48): utrip v mirovanju vedno,
 * telesni testi samo z močjo v dogovoru, FTP in 5 min s kolesom.
 */
export const offeredTests = (custom: boolean, bike: boolean, strength = true) => TESTS.filter(t => (custom ? ['rhr', ...(strength ? ['deska', 'zgibi', 'sklece', 'pocep'] : []), ...(bike ? ['ftp', 'p5'] : [])].includes(t.kind) : t.offer))
/** (v3.48) moč v dogovoru (fitnes ali doma) — kartica Mišice in testi moči samo takrat (ali ko si moč že delal) */
export const agreedStrength = (p: Pick<Profile, 'focus'>): boolean => !!p.focus?.sessions?.some(isStrength)
export const showMuscles = (p: Pick<Profile, 'focus'>, msTotal: number): boolean => msTotal > 0 || (isCustom(p) && agreedStrength(p))
/** (v3.48) doslednost: dni od začetka (prvi dan 1), največ 28 — prej »0/28 dni s hrano« že prvi dan */
export function consistencyDays(p: Pick<Profile, 'createdAt' | 'goalStart'>, today: string): number {
  const starts = [p.createdAt, p.goalStart?.date].map(x => (x || '').slice(0, 10)).filter(x => /^\d{4}-\d{2}-\d{2}$/.test(x)).sort()
  if (!starts[0]) return 28
  const d = Math.round((new Date(today).getTime() - new Date(starts[0]).getTime()) / 86400_000) + 1
  return Math.max(1, Math.min(28, d))
}
/**
 * (v3.48) Tempo teže: prehitro je nad 0,5 kg na teden (ista meja kot varovalka in kartica cilja), nad 0,7 kg močneje.
 * Prej »Tempo je pravi« in zeleno pri −0,6 kg na teden.
 */
export function weightPace(x: { stale: boolean; dw: number | null; rate: number | null; target: number | null; avg7: number; weeksTo: number | null; today: string }): { text: string; color: string } {
  const { stale, dw, rate, target, avg7, weeksTo, today } = x
  const color = rate == null ? 'var(--ink-3)' : lossTooFast(-rate) ? 'var(--warn)' : rate < 0 ? 'var(--ok)' : 'var(--ink)'
  const text = stale ? `Zadnje tehtanje pred ${dw} dnevi — stehtaj se zjutraj, da pokažem tempo.`
    : rate == null ? 'Tehtaj se zjutraj, vsak dan ali vsaj 3× na teden — po dveh tednih pokažem tempo.'
    : rate < -0.7 ? 'Izgubljaš več kot 0,7 kg na teden — prehitro, gre tudi mišica in z njo vati. Dodaj 200–300 kcal na dan.'
    : lossTooFast(-rate) ? `Izgubljaš ${num(-rate, 2)} kg na teden — več kot 0,5 kg je prehitro, gredo vati. Dodaj 150–250 kcal na dan.`
    : rate < -0.05 ? `Tempo je pravi.${weeksTo ? ` Pri tem tempu je cilj dosežen čez ~${count(weeksTo, W.tedenT)} (${fmtD(addDays(today, weeksTo * 7))}).` : ''}`
    : rate > 0.05 ? (target && avg7 > target ? 'Teža gre gor. Preveri, ali res zabeležiš vse obroke (tudi pijače in prigrizke).' : 'Teža rahlo gre gor.')
    : target && avg7 > target ? 'Teža stoji. Preveri, ali res zabeležiš vse obroke (tudi pijače in prigrizke), in dodaj 20 min hoje na dan.'
    : 'Teža je stabilna.'
  return { text, color }
}

export function Napredek() {
  const app = useApp()
  const ai = useAi()
  const { profile: p, checkins, activities, plan, recentMeals, today, settings } = app
  const custom = isCustom(p)
  const bike = !custom || !!p.focus?.sports.includes('kolo')
  const strength = !custom || agreedStrength(p)
  const [wOpen, setWOpen] = useState(false)
  const [tOpen, setTOpen] = useState(false)
  const [busy, setBusy] = useState<string | null>(null)
  // podrobni razdelki so zaprti (ena vrstica); odprt je največ en
  const [openSec, setOpenSec] = useState<string | null>(null)
  const toggleSec = (id: string) => setOpenSec(o => o === id ? null : id)
  const pendingDel = useHidden()
  const tr = weightTrend(checkins)

  /* ---- teža ---- */
  const w90 = useMemo(() => checkins.filter(c => c.weightKg && c.date >= addDays(today, -90)).map(c => ({ date: c.date, v: c.weightKg as number })), [checkins, today])
  const avg90 = useMemo(() => w90.map(pt => { const lo = addDays(pt.date, -7), win = w90.filter(q => q.date <= pt.date && q.date > lo); return { date: pt.date, v: +(win.reduce((s, q) => s + q.v, 0) / win.length).toFixed(2) } }), [w90])
  // (v3.48) ciljna teža kot v kartici cilja: ročna ali izračunana (prej samo ročna)
  const target = shownTargetWeight(p, custom, today)
  // tempo samo iz svežih tehtanj (zadnje pred ≥ 7 dnevi → tempa ne kažem; prej »+0,10 kg/teden« iz meritev izpred 13 dni)
  const dw = daysSinceWeigh(checkins, today)
  const stale = dw != null && dw >= 7
  const rate = stale ? null : tr?.deltaWeek ?? null
  const weeksTo = target && tr && rate != null && rate < -0.05 && tr.avg7 > target ? Math.ceil((tr.avg7 - target) / -rate) : null
  const waist = checkins.filter(c => c.waistCm).map(c => ({ date: c.date, v: c.waistCm as number }))
  // (v3.48) eno tehtanje v oknu ni »7-dnevno povprečje«
  const n7 = tr ? checkins.filter(c => c.weightKg && c.weightKg > 30 && c.date <= tr.lastDate && c.date > addDays(tr.lastDate, -7)).length : 0
  const pace = tr ? weightPace({ stale, dw, rate, target, avg7: tr.avg7, weeksTo, today }) : null

  /* ---- doslednost 28 dni (v3.48: od začetka, dokler ni 28 dni) ---- */
  const from28 = addDays(today, -27)
  const spanC = consistencyDays(p, today), fromC = addDays(today, -(spanC - 1))
  const planned = plan.filter(d => d.date >= fromC && d.date < today && d.kind !== 'pocitek' && !d.optional)
  const doneN = planned.filter(d => d.done).length
  const foodDays = new Set(recentMeals.filter(m => m.date >= fromC).map(m => m.date)).size
  const acts28 = activities.filter(a => a.date >= from28)
  const actsC = activities.filter(a => a.date >= fromC)
  const mealDays = useMemo(() => new Set(recentMeals.map(m => m.date)), [recentMeals])
  let streak = 0
  for (let i = mealDays.has(today) ? 0 : 1; i < 120; i++) { if (mealDays.has(addDays(today, -i))) streak++; else break }

  /* ---- motor ---- */
  const series = useMemo(() => formSeries(activities, today), [activities, today])
  const ctlNow = series.length ? series[series.length - 1]!.ctl : 0
  const ctl6 = series.length > 42 ? series[series.length - 43]!.ctl : 0
  const formEst = useMemo(() => !formReliable(activities, today), [activities, today])
  const wkg = p.ftp && (tr?.avg7 || p.weightKg) ? p.ftp / (tr?.avg7 || p.weightKg!) : null
  const weeks = Array.from({ length: 12 }, (_, i) => addDays(weekStartIso(today), -7 * (11 - i)))
  const hoursBars = weeks.map(ws => {
    const we = addDays(ws, 6), a = activities.filter(x => x.date >= ws && x.date <= we)
    const h = (f: (s: string) => boolean) => +(a.filter(x => f(x.sport)).reduce((s, x) => s + (x.durationMin || 0), 0) / 60).toFixed(1)
    return { label: fmtD(ws), parts: [{ v: h(s => s === 'kolo'), color: 'var(--t-kolo)' }, { v: h(s => s === 'moc'), color: 'var(--t-moc)' }, { v: h(s => s !== 'kolo' && s !== 'moc'), color: 'var(--t-tek)' }] }
  })

  /* ---- moč po vajah ---- */
  const byEx = useMemo(() => {
    const m = new Map<string, { name: string; list: { date: string; sets: number; reps: string; kg?: number | null }[] }>()
    for (const a of [...activities].filter(x => x.sport === 'moc' && x.exercises?.length).sort((x, y) => x.date.localeCompare(y.date)))
      for (const e of a.exercises!) { const k = e.name.toLowerCase(); if (!m.has(k)) m.set(k, { name: e.name, list: [] }); m.get(k)!.list.push({ date: a.date, sets: e.sets, reps: e.reps, kg: e.kg }) }
    return [...m.values()].sort((a, b) => b.list.length - a.list.length).slice(0, 8)
  }, [activities])
  const mocN = activities.filter(a => a.sport === 'moc' && a.date >= from28).length
  /* ---- mišice ta teden (serije na mišico, zadnjih 7 dni) in rekordi ---- */
  const from7 = addDays(today, -6)
  const muscleSets = useMemo(() => setsByMuscle(activities.filter(a => a.sport === 'moc' && a.date >= from7).flatMap(a => (a.exercises || []).map(e => ({ name: e.name, sets: e.sets })))), [activities, from7])
  const msTotal = Object.values(muscleSets).reduce((t, x) => t + x, 0)
  const prs = useMemo(() => personalRecords(activities).slice(0, 6), [activities])

  /* ---- testi in mejniki ---- */
  // test, ki čaka na izbris (»Razveljavi«), je takoj skrit
  const tests = [...(settings.tests || [])].filter(t => !pendingDel.has('test:' + t.id)).sort((a, b) => b.date.localeCompare(a.date))
  const miles = TESTS.filter(t => t.milestones).map(t => {
    const last = tests.find(x => x.kind === t.kind); if (!last) return null
    const ms = t.milestones!, next = ms.find(m => m > last.value) ?? null
    return { t, value: last.value, next, level: ms.filter(m => m <= last.value).length, of: ms.length }
  }).filter(Boolean) as { t: typeof TESTS[number]; value: number; next: number | null; level: number; of: number }[]

  /* ---- meseci ---- */
  const ym = today.slice(0, 7), prevYm = addDays(today.slice(0, 8) + '01', -1).slice(0, 7)
  const month = (m: string, acts: readonly Activity[] = activities) => {
    const a = acts.filter(x => x.date.slice(0, 7) === m), k = a.filter(x => x.sport === 'kolo')
    const w = checkins.filter(c => c.weightKg && c.date.slice(0, 7) === m).sort((x, y) => x.date.localeCompare(y.date))
    // (v3.48) današnji dan še ni končan — ne gre v povprečje meseca
    const md = [...new Set(recentMeals.filter(x => x.date.slice(0, 7) === m && x.date !== today).map(x => x.date))]
    const kc = md.map(d => recentMeals.filter(x => x.date === d).reduce((s, x) => s + x.kcal, 0))
    return { m, n: a.length, min: a.reduce((s, x) => s + (x.durationMin || 0), 0), km: Math.round(k.reduce((s, x) => s + (x.distKm || 0), 0)), elev: Math.round(k.reduce((s, x) => s + (x.elevM || 0), 0)), tss: Math.round(a.reduce((s, x) => s + (x.tss || 0), 0)), moc: a.filter(x => x.sport === 'moc').length, w0: w[0]?.weightKg ?? null, w1: w[w.length - 1]?.weightKg ?? null, kcal: kc.length ? Math.round(kc.reduce((s, x) => s + x, 0) / kc.length) : null, foodDays: md.length }
  }
  const mNow = month(ym), mPrev = month(prevYm)
  // AI dobi samo aktivnosti, ki jih sme videti (Strava in neznani izvori NIKOLI v poziv)
  const hidden = hasHiddenActivities(activities)
  const aiActs = activities.filter(aiAllowed)
  const mText = (x: ReturnType<typeof month>) => `${MON[+x.m.slice(5, 7) - 1]} ${x.m.slice(0, 4)}: ${count(x.n, W.vadba)}, ${fmtDur(x.min)}${x.km ? `, ${unit(num(x.km), 'km')}, ${unit(num(x.elev), 'm')} vzpona` : ''}, ${int(x.tss)}${NBSP}TSS, moč ${x.moc}×; teža ${x.w0 != null ? `${num(x.w0)} → ${unit(num(x.w1 ?? x.w0), 'kg')}` : 'ni podatka'}; prehrana ${x.kcal ? `povprečno ${unit(num(x.kcal), 'kcal')} (${count(x.foodDays, W.dan)})` : 'ni zabeležena'}.`
  const review = settings.monthReviews?.[ym]
  const cx = weekContext(p, weekStartIso(today))
  const tgt = dailyTarget(p, [], [], today)


  async function doMonth() {
    setBusy('month')
    const t = await ai.run(() => monthReview(snapOf(getState()), `${mText(month(ym, aiActs))}\nPrejšnji mesec — ${mText(month(prevYm, aiActs))}`))
    setBusy(null)
    if (t) await updateSettings({ monthReviews: { ...(settings.monthReviews || {}), [ym]: { at: new Date().toISOString(), text: t } } })
  }

  return (<>
    <Head hi={custom ? 'Moč · teža · kondicija' : 'W/kg · teža · motor'} nm="Napredek" />
    <div className="scroll">
      <div className="stack" style={{ gap: 12 }}>
        {/* »Na kratko« je ponavljal kartice spodaj (cilj, W/kg, teža, doslednost) — brez njega (Blaž: manj besedila) */}
        <div className="cols gap">
        <div className="col">
        <div id="p-cilj" className="nav-target">{custom ? <DealCard full /> : <GoalCard full />}</div>

        {bike && realityHas(activities, today) && (
          <Section id="p-res" title="Trening v resnici" sum="ure na kolesu, 80/20, ključni treningi" open={openSec === 'p-res'} onToggle={() => toggleSec('p-res')}><RealityCard /></Section>
        )}

        {/* MIŠICE: serije na mišico ta teden (zemljevid) — načrt po meri ali kdor dela moč z vajami */}
        {showMuscles(p, msTotal) && (
          <Card id="p-misice" className="nav-target">
            <div className="between"><h2 className="h4" style={{ margin: 0 }}>Mišice · zadnjih 7 dni</h2><span className="muted" style={{ fontSize: 12, fontWeight: 700 }}>{msTotal ? count(Math.round(msTotal), W.serija) : ''}</span></div>
            {msTotal ? (
              <div className="row" style={{ gap: 16, marginTop: 10, alignItems: 'center' }}>
                <BodyMap levels={Object.fromEntries(Object.entries(muscleSets).map(([m, n]) => [m, Math.min(1, n / 10)]))} size={150} run={false} label="Serije na mišico v zadnjih 7 dneh" />
                <div style={{ flex: 1, minWidth: 0, display: 'grid', gap: 5 }}>
                  {(Object.entries(muscleSets) as [keyof typeof MUSCLE_LABEL, number][]).sort((a, b) => b[1] - a[1]).map(([m, n]) => (
                    <div key={m} className="between" style={{ fontSize: 13 }}><span style={{ color: n ? 'var(--ink)' : 'var(--ink-3)', fontWeight: 600 }}>{MUSCLE_LABEL[m]}</span><b style={{ color: n >= 10 ? 'var(--accent-fg)' : n ? 'var(--ink)' : 'var(--ink-3)', fontWeight: 800 }}>{num(n, 1)}</b></div>
                  ))}
                </div>
              </div>
            ) : <p style={{ fontSize: 13, marginTop: 8 }}>Ko opraviš vadbo moči (Začni trening), tu zasvetijo mišice, ki si jih treniral — 10 serij na mišico na teden je dober cilj za rast.</p>}
            {msTotal > 0 && <p className="muted" style={{ fontSize: 12, marginTop: 10 }}>10–20 serij na mišico na teden gradi mišice; manj jih ohranja. Pomožne mišice štejejo pol serije. Svetlejše = več serij.</p>}
          </Card>
        )}

        </div>
        <div className="col">
        {/* TEŽA */}
        <Card id="p-teza" className="nav-target">
          <div className="between"><h2 className="h4" style={{ margin: 0 }}>Teža</h2><Btn sm onClick={() => setWOpen(true)}><IcoScale width={16} height={16} /> Stehtaj se</Btn></div>
          {tr ? (<>
            <div className="row" style={{ gap: 18, marginTop: 10, flexWrap: 'wrap' }}>
              <div><div style={{ fontSize: 28, fontWeight: 800, letterSpacing: '-.03em' }}>{n1(tr.avg7)} <span style={{ fontSize: 14, color: 'var(--ink-3)' }}>kg</span></div><div className="muted" style={{ fontSize: 11.5, fontWeight: 700 }}>{n7 > 1 ? '7-DNEVNO POVPREČJE' : 'ZADNJE TEHTANJE'}</div></div>
              <div><div style={{ fontSize: 18, fontWeight: 800, color: pace!.color }}>{rate == null ? '—' : unit(signed(rate, 2), 'kg')}</div><div className="muted" style={{ fontSize: 11.5, fontWeight: 700 }}>NA TEDEN</div></div>
              {target && <div><div style={{ fontSize: 18, fontWeight: 800 }}>{unit(n1(Math.max(0, tr.avg7 - target)), 'kg')}</div><div className="muted" style={{ fontSize: 11.5, fontWeight: 700 }}>DO CILJA {n1(target)}</div></div>}
            </div>
            {/* graf šele z dvema meritvama (prej velik prazen okvir »Za graf rabim vsaj dve meritvi«) */}
            {w90.length >= 2 && <div style={{ marginTop: 12 }}><DotLineChart points={w90} line={avg90} reference={target} refLabel="cilj" unit="kg" /></div>}
            <p className="muted" style={{ fontSize: 12.5, marginTop: 10 }}>
              {pace!.text}
              {tgt ? ` Dnevni cilj brez treninga ${fmtKcal(tgt.kcal)}${NBSP}kcal, beljakovine ${tgt.proteinG}${NBSP}g.` : ''}
            </p>
            {tgt && <HealthNote kind="food" />}
            {waist.length >= 2 && <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>Pas: {n1(waist[0]!.v)} → <b style={{ color: 'var(--ink)' }}>{unit(n1(waist[waist.length - 1]!.v), 'cm')}</b> ({unit(signed(waist[waist.length - 1]!.v - waist[0]!.v, 1), 'cm')}) — pas pove več kot tehtnica, ko hkrati gradiš mišice.</div>}
          </>) : <p style={{ fontSize: 13, marginTop: 8 }}>Še ni tehtanja. Stehtaj se zjutraj, po stranišču, pred zajtrkom — vedno enako. Šteje 7-dnevno povprečje, ne posamezen dan.</p>}
        </Card>

        {/* DOSLEDNOST */}
        <Card tight>
          <h2 className="h4" style={{ fontSize: 11 }}>Doslednost · {spanC < 28 ? 'od začetka' : 'zadnjih 28 dni'}</h2>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, textAlign: 'center', marginTop: 8 }}>
            <div><div style={{ fontSize: 20, fontWeight: 800 }}>{planned.length ? pct(doneN / planned.length * 100) : '—'}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>sej po planu</div></div>
            <div><div style={{ fontSize: 20, fontWeight: 800 }}>{foodDays}/{spanC}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>dni s hrano{streak >= 3 ? ` · niz ${streak}` : ''}</div></div>
            <div><div style={{ fontSize: 20, fontWeight: 800 }}>{unit(Math.round(actsC.reduce((s, a) => s + (a.durationMin || 0), 0) / 60), 'h')}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>{count(actsC.length, W.vadba)}</div></div>
          </div>

          {/* seznam vseh vadb: podrobnosti, opomba, občutek, izbris (v3.48 — prej samo prek Uvoz → Ročni vnos) */}
          <div style={{ textAlign: 'right', marginTop: 8 }}><button type="button" className="chip sm click" onClick={() => navigate('aktivnosti')}>Vse vadbe ›</button></div>
        </Card>

        {/* MOTOR / KONDICIJA — zaprto: ena vrstica s kondicijo (in FTP) */}
        <Section id="p-motor" title={custom ? 'Kondicija' : 'Motor'} sum={!activities.length ? 'še brez vadb' : `kondicija ${Math.round(ctlNow)}${custom && !bike ? ` · ${count(acts28.length, W.vadba)} v 28 dneh` : p.ftp ? ` · FTP ${unit(p.ftp, 'W')}${wkg ? ` · ${dec(wkg, 2)} W/kg` : ''}` : ''}`} open={openSec === 'p-motor'} onToggle={() => toggleSec('p-motor')}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginTop: 10 }}>
            <div><div style={{ fontSize: 20, fontWeight: 800, color: 'var(--t-kolo-ink)' }}>{Math.round(ctlNow)}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>kondicija{formEst ? ' · ocena' : series.length > 42 ? ` · ${signed(Math.round(ctlNow - ctl6), 0)} v 6 t.` : ''}</div></div>
            {custom && !bike ? (<>
              <div><div style={{ fontSize: 20, fontWeight: 800 }}>{fmtDur(Math.round(acts28.reduce((t, a) => t + (a.durationMin || 0), 0) / 4))}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>na teden · 4 tedne</div></div>
              <div><div style={{ fontSize: 20, fontWeight: 800 }}>{acts28.length}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>{plural(acts28.length, W.vadba)} v 28 dneh</div></div>
            </>) : (<>
              <div><div style={{ fontSize: 20, fontWeight: 800 }}>{p.ftp ? unit(p.ftp, 'W') : '—'}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>FTP{p.ftpDate ? ` · ${fmtD(p.ftpDate)}` : ''}</div></div>
              <div><div style={{ fontSize: 20, fontWeight: 800 }}>{wkg ? dec(wkg, 2) : '—'}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>W/kg</div></div>
            </>)}
          </div>
          <p className="muted" style={{ fontSize: 12, margin: '8px 0 12px' }}>{custom ? 'Kondicija raste z rednimi treningi — šteje, da ne izpuščaš, ne posamezen trd dan.' : 'Hujšanje dvigne W/kg tudi brez dodatnih vatov — 3 kg manj pri istem FTP je kot +10 W v klanec.'}{cx.structured ? ` ${cx.phaseName}, teden ${cx.week}${cx.total ? '/' + cx.total : ''}.` : ''}</p>
          {/* (v3.48) graf forme: kondicija, utrujenost in forma zadnjih 90 dni */}
          {series.length >= 2 && <div style={{ marginBottom: 14 }}><FormChart data={series.slice(-90)} height={170} />{formEst && <p className="muted" style={{ fontSize: 11.5, marginTop: 6 }}>Ocena — za točno formo rabim vsaj 6 tednov vadb.</p>}</div>}
          <StackBars bars={hoursBars} legend={[{ label: 'kolo', color: 'var(--t-kolo)' }, { label: 'moč', color: 'var(--t-moc)' }, { label: 'tek/hoja', color: 'var(--t-tek)' }]} unit="ure" />
        </Section>

        {recordsHas(activities, today) && <Section id="p-rekordi" title="Letos in rekordi" sum="km letos, najdaljša vožnja, največ vzpona" open={openSec === 'p-rekordi'} onToggle={() => toggleSec('p-rekordi')}><RecordsCard acts={activities} today={today} /></Section>}
        {(hrZoneRows(p) || powerZoneRows(p)) && <Section id="p-cone" title="Tvoje cone" sum={powerZoneRows(p) && hrZoneRows(p) ? 'utrip in moč' : powerZoneRows(p) ? 'moč (W)' : 'utrip (bpm)'} open={openSec === 'p-cone'} onToggle={() => toggleSec('p-cone')}><ZonesCard p={p} /></Section>}

        {/* MOČ — samo, če jo treniraš */}
        {(p.strength.on || mocN > 0) && <Section id="p-moc" title="Moč" sum={mocN ? `${count(mocN, W.vadba)} v 28 dneh${prs.some(r => r.kg) ? ' · rekordi' : ''}${byEx.length ? ' · po vajah' : ''}` : 'še brez vadb moči'} open={openSec === 'p-moc'} onToggle={() => toggleSec('p-moc')}>
          {prs.some(r => r.kg) && (
            <div style={{ marginTop: 10 }}>
              <div className="muted" style={{ fontSize: 11, fontWeight: 800, letterSpacing: '.06em', textTransform: 'uppercase' }}>Rekordi</div>
              {prs.filter(r => r.kg).slice(0, 5).map(r => (
                <div key={r.name} className="between" style={{ fontSize: 13, padding: '5px 0', borderTop: '1px solid var(--line-soft)' }}>
                  <span style={{ fontWeight: 600, minWidth: 0 }}>{r.name}</span>
                  <span style={{ flex: 'none', textAlign: 'right' }}><b>{unit(num(r.kg!), 'kg')}{r.reps ? ` × ${r.reps}` : ''}</b>{r.e1rm ? <span className="muted" style={{ fontSize: 11.5 }}> · 1RM ~{unit(num(r.e1rm), 'kg')}</span> : null}<span className="muted" style={{ fontSize: 11.5 }}> · {fmtD(r.date)}</span></span>
                </div>
              ))}
            </div>
          )}
          {miles.length > 0 && <div className="stack" style={{ gap: 10, marginTop: 10 }}>
            {miles.map(m => (
              <div key={m.t.kind}>
                <div className="between" style={{ fontSize: 13 }}><b>{m.t.label.split(' — ')[0]}</b><span className="muted" style={{ fontWeight: 700 }}>{unit(num(m.value), m.t.unit)}{m.next ? ` · naslednji mejnik ${m.next}` : ' · vsi mejniki'}</span></div>
                <div style={{ marginTop: 5 }}><Track pct={m.level / m.of * 100} color="var(--t-moc)" /></div>
              </div>
            ))}
          </div>}
          {byEx.length ? (
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13, marginTop: 12 }}>
              <thead><tr style={{ color: 'var(--ink-3)', fontSize: 11 }}><th style={{ textAlign: 'left', padding: '4px 0' }}>vaja</th><th style={{ textAlign: 'right' }}>prvič</th><th style={{ textAlign: 'right' }}>zadnjič</th><th style={{ textAlign: 'right' }}>×</th></tr></thead>
              <tbody>{byEx.map(e => { const a = e.list[0]!, z = e.list[e.list.length - 1]!, f = (x: typeof a) => `${x.sets}×${x.reps}${x.kg ? ' @' + x.kg : ''}`; return (
                <tr key={e.name} style={{ borderTop: '1px solid var(--line)' }}><td style={{ padding: '7px 0', fontWeight: 600 }}>{e.name}</td><td className="muted" style={{ textAlign: 'right' }}>{f(a)}</td><td style={{ textAlign: 'right', fontWeight: 800 }}>{f(z)}</td><td className="muted" style={{ textAlign: 'right' }}>{e.list.length}</td></tr>) })}</tbody>
            </table>
          ) : <p style={{ fontSize: 13, marginTop: 8 }}>Ko moč opraviš z vodeno vadbo (Začni trening) ali vpišeš vaje, se tu vidi napredek po vajah.</p>}
        </Section>}

        {/* TESTI */}
        <Section id="p-testi" title="Testi" sum={tests.length ? `zadnji ${fmtD(tests[0]!.date)} · ${TESTS.find(x => x.kind === tests[0]!.kind)?.label.split(' — ')[0] ?? ''}` : !custom || (bike && !strength) ? 'FTP in 5-min test' : strength ? `${bike ? 'FTP, ' : ''}deska, zgibi, sklece, počepi` : 'utrip v mirovanju'} open={openSec === 'p-testi'} onToggle={() => toggleSec('p-testi')}>
          <div className="between" style={{ marginTop: 2 }}><span className="muted" style={{ fontSize: 12 }}>{tests.length ? `${count(tests.length, W.test)}` : 'še brez testov'}</span><Btn sm onClick={() => setTOpen(true)}><IcoPlus width={15} height={15} /> Vpiši</Btn></div>
          {tests.length ? (
            <div className="stack" style={{ gap: 0, marginTop: 8 }}>
              {tests.slice(0, 12).map(t => { const T = TESTS.find(x => x.kind === t.kind)!; return (
                <div key={t.id} className="between" style={{ padding: '8px 0', borderTop: '1px solid var(--line)', fontSize: 13, alignItems: 'center' }}>
                  <span style={{ minWidth: 0 }}><span className="muted">{fmtD(t.date)}</span> · {T.label}</span>
                  <span className="row" style={{ gap: 8, flex: 'none' }}><b>{unit(num(t.value), t.unit)}</b>{t.kind === 'ftp' && <span className="muted">FTP {Math.round(t.value * .95)}</span>}{t.kind === 'p5' && (tr?.avg7 || p.weightKg) ? <span className="muted">VO2max ~{vo2maxFromP5(t.value, (tr?.avg7 || p.weightKg)!)}</span> : null}<button className="chip sm click icon-x" onClick={() => deferDelete('test:' + t.id, `Izbrisan test: ${T.label.split(' — ')[0]}`, () => removeTest(t.id))} aria-label={`Izbriši test ${T.label.split(' — ')[0]} ${fmtD(t.date)}`}>×</button></span>
                </div>) })}
            </div>
          ) : <p style={{ fontSize: 13, marginTop: 8 }}>{custom && strength ? 'Vsakih nekaj tednov ponovi iste teste (deska, zgibi, sklece, počepi v 2 minutah) — tako vidiš napredek s številkami, ne le z občutkom. Najbolje v lažjem tednu.' : custom && !bike ? 'Vsakih nekaj tednov izmeri utrip v mirovanju — zjutraj v postelji, 1 minuto. Nižji utrip pomeni boljšo kondicijo.' : '20-min test FTP je v načrtu vsakih 8 tednov (v razbremenilnem tednu). 5-min test pove, kje je tvoj VO2max — ponovi ga v isti razbremenitvi.'}</p>}
        </Section>

        {/* MESEC */}
        <Section id="p-mesec" title={MON[+ym.slice(5, 7) - 1]!.charAt(0).toUpperCase() + MON[+ym.slice(5, 7) - 1]!.slice(1)} sum={mNow.n ? `${count(mNow.n, W.vadba)}, ${fmtDur(mNow.min)}${review ? ' · AI ocena' : ''}` : `ta mesec še brez vadb${review ? ' · AI ocena' : ''}`} open={openSec === 'p-mesec'} onToggle={() => toggleSec('p-mesec')}>
          <p style={{ fontSize: 13, marginTop: 8, color: 'var(--ink)' }}>{mText(mNow)}</p>
          <p className="muted" style={{ fontSize: 12, marginTop: 6 }}>Prej — {mText(mPrev)}</p>
          {review && <p style={{ fontSize: 13.5, marginTop: 10, lineHeight: 1.55, color: 'var(--ink)', whiteSpace: 'pre-wrap' }}>{sanitizeGaps(review.text, hidden)}</p>}
          <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
            <Btn ghost sm disabled={ai.busy} onClick={doMonth}>{busy === 'month' && ai.busy ? 'Pišem …' : review ? 'Osveži oceno meseca' : 'AI ocena meseca'}</Btn>
            <Btn ghost sm onClick={() => { void navigator.clipboard?.writeText(`${mText(mNow)}\n${review ? sanitizeGaps(review.text, hidden) : ''}`).then(() => toast('Kopirano.', 'ok')) }}>Kopiraj</Btn>
          </div>
        </Section>
        </div>
        </div>
        {hasGarminData(app.activities) && <p className="muted" style={{ fontSize: 11, textAlign: 'center', margin: '2px 0 0' }}>Forma, obremenitev in ocene so izračunani delno iz podatkov naprav Garmin (prek intervals.icu).</p>}

      </div>
    </div>

    <WeighSheet open={wOpen} onClose={() => setWOpen(false)} />
    <TestSheet open={tOpen} onClose={() => setTOpen(false)} custom={custom} bike={bike} strength={strength} />
    {ai.sheet}
  </>)
}

/* ---------- test ---------- */
export function TestSheet({ open, onClose, custom = false, bike = true, strength = true }: { open: boolean; onClose: () => void; custom?: boolean; bike?: boolean; strength?: boolean }) {
  const offer = offeredTests(custom, bike, strength)
  const [kind, setKind] = useState<TestEntry['kind']>(offer[0]?.kind ?? 'ftp')
  const [val, setVal] = useState('')
  const [date, setDate] = useState(todayIso())
  const T = TESTS.find(t => t.kind === kind)!
  async function save() {
    const v = +String(val).replace(',', '.')
    if (!(v > 0)) { toast('Vpiši rezultat.', 'err'); return }
    await addTest({ id: uid(), date, kind, value: v, unit: T.unit })
    setVal(''); onClose()
  }
  return (
    <Sheet open={open} onClose={onClose}>
      <b style={{ fontSize: 17, letterSpacing: '-.02em' }}>Vpiši test</b>
      <div className="row" style={{ gap: 7, flexWrap: 'wrap', margin: '12px 0' }}>{offer.map(t => <Chip key={t.kind} sm on={kind === t.kind} onClick={() => setKind(t.kind)}>{t.label.split(' — ')[0]}</Chip>)}</div>
      <p style={{ fontSize: 12.5 }}>{T.hint}</p>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 12 }}>
        <div className="field"><label htmlFor="test-val">Rezultat <span className="unit">{T.unit}</span></label><DecimalInput id="test-val" value={val} onChange={e => setVal(e.target.value)} autoFocus /></div>
        <div className="field"><label>Datum</label><DateField compact value={date} max={todayIso()} onChange={v => setDate(v || todayIso())} label="Datum" /></div>
      </div>
      <Btn primary block style={{ marginTop: 14 }} onClick={save}>Shrani</Btn>
      <Btn ghost block style={{ marginTop: 9 }} onClick={onClose}>Prekliči</Btn>
    </Sheet>
  )
}
