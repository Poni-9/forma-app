import { useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import type { Sport } from '@/domain/types'
import { Head } from '@/app/Shell'
import { navigate } from '@/app/router'
import { useApp } from '@/state/store'
import { formSeries, formBand, readiness, fmtDur, addDays, weekStartIso } from '@/domain/training/load'
import { hrZones5, powerZones7 } from '@/domain/training/zones'
import { aiAllowed } from '@/domain/import/provenance'
import { Card, Chip, Btn, Empty } from '@/ui/primitives'
import { FormChart, BarChart, ZoneBars } from '@/ui/charts'
import { IcoChart } from '@/ui/icons'

type Range = 7 | 28 | 90

const SPORT_L: Record<Sport, string> = { kolo: 'Kolo', tek: 'Tek', pohod: 'Hoja', moc: 'Moč', plavanje: 'Plavanje', drugo: 'Drugo' }
const SPORT_C: Record<Sport, string> = {
  kolo: 'var(--t-kolo)', tek: 'var(--t-tek)', pohod: 'var(--t-tek)',
  moc: 'var(--t-moc)', plavanje: 'var(--t-poc)', drugo: 'var(--t-poc)',
}

const bandColor = (c: 'ok' | 'kolo' | 'warn' | 'bad'): string =>
  c === 'ok' ? 'var(--ok)' : c === 'bad' ? 'var(--bad)' : c === 'warn' ? 'var(--warn)' : 'var(--t-kolo)'

/** Kratek zapis števila: brez decimalk nad 10, sicer ena decimalka z vejico. */
function num(v: number | null | undefined): string {
  if (v == null || !Number.isFinite(v)) return '—'
  const r = Math.abs(v) >= 10 ? Math.round(v) : Math.round(v * 10) / 10
  return String(r).replace('.', ',')
}

function Stat({ label, value, sub, color }: { label: string; value: string; sub?: string; color?: string }) {
  return (
    <Card tight>
      <h4 style={{ fontSize: 11, color: 'var(--ink-3)', fontWeight: 800, letterSpacing: '.06em', textTransform: 'uppercase' }}>{label}</h4>
      <div style={{ fontSize: 26, fontWeight: 800, letterSpacing: '-.03em', marginTop: 3, color: color || 'var(--ink)' }}>{value}</div>
      {sub && <div className="muted" style={{ fontSize: 11, fontWeight: 600, marginTop: 2 }}>{sub}</div>}
    </Card>
  )
}

function Section({ title, sub, children }: { title: string; sub?: string; children: ReactNode }) {
  return (
    <Card>
      <div className="between" style={{ marginBottom: 12 }}>
        <b style={{ fontSize: 15, letterSpacing: '-.02em' }}>{title}</b>
        {sub && <span className="muted" style={{ fontSize: 11, fontWeight: 700 }}>{sub}</span>}
      </div>
      {children}
    </Card>
  )
}

export function AnalitikaFull() {
  const app = useApp()
  const { profile: p, activities, checkinToday, today } = app
  const [range, setRange] = useState<Range>(90)

  /* ---- forma ---- */
  const series = useMemo(() => formSeries(activities.filter(a => a.sport !== 'moc' || a.tss), today), [activities, today])
  const last = series[series.length - 1] ?? null
  const chart = useMemo(() => series.slice(-90).map(s => ({ date: s.date, ctl: s.ctl, atl: s.atl, tsb: s.tsb })), [series])
  const band = last ? formBand(last.tsb) : null
  const ready = last ? readiness(last.tsb, checkinToday?.soreness ?? null) : null

  /* ---- izbrano obdobje ---- */
  const from = addDays(today, -(range - 1))
  const inRange = useMemo(() => activities.filter(a => a.date >= from && a.date <= today), [activities, from, today])

  const sum = useMemo(() => {
    let min = 0, km = 0, elev = 0, tss = 0
    for (const a of inRange) {
      min += a.durationMin || 0
      km += a.distKm || 0
      elev += a.elevM || 0
      tss += a.tss || 0
    }
    return { min, km, elev, tss, count: inRange.length }
  }, [inRange])

  /* ---- tedenski obseg ---- */
  const weeks = range === 7 ? 4 : range === 28 ? 8 : 12
  const weekBars = useMemo(() => {
    const ws0 = weekStartIso(today)
    const out: { label: string; value: number; color?: string }[] = []
    for (let i = weeks - 1; i >= 0; i--) {
      const s = addDays(ws0, -7 * i)
      const e = addDays(s, 6)
      let min = 0
      for (const a of activities) if (a.date >= s && a.date <= e) min += a.durationMin || 0
      out.push({ label: `${+s.slice(8)}.${+s.slice(5, 7)}.`, value: Math.round((min / 60) * 10) / 10, color: 'var(--t-kolo)' })
    }
    return out
  }, [activities, today, weeks])

  /* ---- razporeditev po športih ---- */
  const sportBars = useMemo(() => {
    const by = new Map<Sport, number>()
    for (const a of inRange) by.set(a.sport, (by.get(a.sport) || 0) + (a.durationMin || 0))
    return [...by.entries()]
      .filter(e => e[1] > 0)
      .sort((a, b) => b[1] - a[1])
      .map(([s, min]) => ({ label: SPORT_L[s], value: Math.round((min / 60) * 10) / 10, color: SPORT_C[s] }))
  }, [inRange])

  /* ---- rekordi ---- */
  const rec = useMemo(() => {
    let ride = 0, elev = 0, tss = 0
    for (const a of inRange) {
      if (a.sport === 'kolo' && (a.distKm || 0) > ride) ride = a.distKm || 0
      if ((a.elevM || 0) > elev) elev = a.elevM || 0
      if ((a.tss || 0) > tss) tss = a.tss || 0
    }
    const days = [...new Set(inRange.map(a => a.date))].sort()
    let best = 0, run = 0, prev = ''
    for (const d of days) {
      run = prev && addDays(prev, 1) === d ? run + 1 : 1
      if (run > best) best = run
      prev = d
    }
    return { ride, elev, tss, streak: best }
  }, [inRange])

  /* ---- cone (ocena po povprečni moči oziroma povprečnem utripu) ---- */
  const zones = useMemo(() => {
    const pw = powerZones7(p)
    const zs = pw ?? hrZones5(p)
    if (!zs) return null
    const byPower = !!pw
    const rows = zs.map(z => ({ key: z.key, name: z.name, lo: z.lo, hi: z.hi, minutes: 0 }))
    for (const a of inRange) {
      const v = byPower ? a.avgPower : a.avgHr
      const min = a.durationMin || 0
      if (!v || !min) continue
      let idx = rows.findIndex(z => v >= z.lo && v <= z.hi)
      if (idx < 0) idx = v < (rows[0]?.lo ?? 0) ? 0 : rows.length - 1
      const r = rows[idx]
      if (r) r.minutes += min
    }
    return { rows, byPower }
  }, [p, inRange])

  /* ---- kaj sme trener videti ---- */
  const seen = activities.filter(aiAllowed).length
  const totalActs = activities.length

  if (!totalActs) {
    return (<>
      <Head hi="Trendi in številke" nm="Analitika" />
      <div className="scroll">
        <Empty icon={<IcoChart width={30} height={30} style={{ color: 'var(--accent)' }} />} title="Ni še kaj analizirati" text="Ko uvoziš prve treninge, tu dobiš formo, obseg, cone in rekorde.">
          <div className="row" style={{ gap: 8 }}>
            <Btn primary sm onClick={() => navigate('uvoz')}>Uvozi vožnje</Btn>
            <Btn ghost sm onClick={() => navigate('aktivnosti', { nova: '1' })}>Vnesi ročno</Btn>
          </div>
        </Empty>
      </div>
    </>)
  }

  return (<>
    <Head hi={`${totalActs} aktivnosti · trener vidi ${seen}`} nm="Analitika" />
    <div className="scroll">
      <div className="stack" style={{ gap: 12 }}>

        {/* 1) kartice na vrhu */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <Stat
            label="Forma"
            value={last ? `${last.tsb > 0 ? '+' : ''}${Math.round(last.tsb)}` : '—'}
            sub={band ? band.band : 'še ni podatka'}
            color={band ? bandColor(band.color) : undefined}
          />
          <Stat label="Kondicija" value={last ? num(last.ctl) : '—'} sub="CTL · 42 dni" color="var(--t-kolo)" />
          <Stat label="Utrujenost" value={last ? num(last.atl) : '—'} sub="ATL · 7 dni" color="var(--t-moc)" />
          <Stat
            label="Pripravljenost"
            value={ready == null ? '—' : `${ready} %`}
            sub={checkinToday?.soreness ? `vključeno počutje ${checkinToday.soreness}/5` : 'brez današnjega počutja'}
            color={ready == null ? undefined : ready >= 70 ? 'var(--ok)' : ready >= 45 ? 'var(--warn)' : 'var(--bad)'}
          />
        </div>

        {/* 2) graf forme */}
        <Section title="Forma" sub={chart.length > 1 ? `zadnjih ${chart.length} dni` : undefined}>
          <FormChart data={chart} />
          <p className="muted" style={{ fontSize: 12, marginTop: 10 }}>
            Kondicija raste počasi in pada počasi, utrujenost oboje hitro. Forma je razlika med njima — nad ničlo si spočit, pod njo gradiš.
          </p>
        </Section>

        {/* 3) izbirnik obdobja */}
        <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
          <span className="muted" style={{ fontSize: 11, fontWeight: 800, letterSpacing: '.06em', textTransform: 'uppercase' }}>Obdobje</span>
          <Chip sm on={range === 7} onClick={() => setRange(7)}>7 dni</Chip>
          <Chip sm on={range === 28} onClick={() => setRange(28)}>28 dni</Chip>
          <Chip sm on={range === 90} onClick={() => setRange(90)}>90 dni</Chip>
        </div>

        <Card tight>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, textAlign: 'center' }}>
            <div><div style={{ fontSize: 18, fontWeight: 800, letterSpacing: '-.02em' }}>{sum.count}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>aktivnosti</div></div>
            <div><div style={{ fontSize: 18, fontWeight: 800, letterSpacing: '-.02em' }}>{sum.min ? fmtDur(sum.min) : '—'}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>skupaj</div></div>
            <div><div style={{ fontSize: 18, fontWeight: 800, letterSpacing: '-.02em' }}>{sum.tss ? Math.round(sum.tss) : '—'}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>TSS</div></div>
            <div><div style={{ fontSize: 18, fontWeight: 800, letterSpacing: '-.02em' }}>{sum.km ? `${num(sum.km)} km` : '—'}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>razdalja</div></div>
            <div><div style={{ fontSize: 18, fontWeight: 800, letterSpacing: '-.02em' }}>{sum.elev ? `${Math.round(sum.elev)} m` : '—'}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>višinci</div></div>
            <div><div style={{ fontSize: 18, fontWeight: 800, letterSpacing: '-.02em' }}>{sum.count ? num(sum.min / 60 / (range / 7)) : '—'}</div><div className="muted" style={{ fontSize: 11, fontWeight: 700 }}>ur na teden</div></div>
          </div>
        </Card>

        {/* 4) tedenski obseg */}
        <Section title="Tedenski obseg" sub={`ure · zadnjih ${weeks} tednov`}>
          <BarChart bars={weekBars} unit="ur" />
        </Section>

        {/* 5) razporeditev po športih */}
        <Section title="Po športih" sub={`ure · zadnjih ${range} dni`}>
          {sportBars.length ? <BarChart bars={sportBars} height={150} unit="ur" /> : <p className="muted" style={{ fontSize: 13 }}>V izbranem obdobju ni aktivnosti s trajanjem.</p>}
        </Section>

        {/* 6) rekordi */}
        <Section title="Rekordi" sub={`zadnjih ${range} dni`}>
          <div className="stack" style={{ gap: 9 }}>
            <div className="between" style={{ fontSize: 13 }}><span className="muted" style={{ fontWeight: 600 }}>Najdaljša vožnja</span><b>{rec.ride ? `${num(rec.ride)} km` : '—'}</b></div>
            <div className="between" style={{ fontSize: 13 }}><span className="muted" style={{ fontWeight: 600 }}>Največ višinskih metrov</span><b>{rec.elev ? `${Math.round(rec.elev)} m` : '—'}</b></div>
            <div className="between" style={{ fontSize: 13 }}><span className="muted" style={{ fontWeight: 600 }}>Najvišji TSS</span><b>{rec.tss ? Math.round(rec.tss) : '—'}</b></div>
            <div className="between" style={{ fontSize: 13 }}><span className="muted" style={{ fontWeight: 600 }}>Najdaljši niz dni zapored</span><b>{rec.streak ? `${rec.streak} ${rec.streak === 1 ? 'dan' : rec.streak === 2 ? 'dneva' : rec.streak < 5 ? 'dnevi' : 'dni'}` : '—'}</b></div>
          </div>
        </Section>

        {/* 7) cone */}
        <Section title={zones ? (zones.byPower ? 'Cone moči' : 'Cone utripa') : 'Cone'} sub={zones ? `zadnjih ${range} dni` : undefined}>
          {zones ? (<>
            <ZoneBars zones={zones.rows} />
            <p className="muted" style={{ fontSize: 12, marginTop: 10 }}>
              {zones.byPower
                ? `Cone po Cogganu iz FTP ${p.ftp} W. Čas je ocena: vsaka aktivnost šteje v cono svoje povprečne moči.`
                : `Cone iz maksimalnega utripa ${p.maxHr}${p.restHr ? ` in mirovnega ${p.restHr}` : ''}. Čas je ocena: vsaka aktivnost šteje v cono svojega povprečnega utripa.`}
            </p>
          </>) : (<>
            <p style={{ fontSize: 13 }}>Za cone potrebujem vsaj eno od dvojega: FTP (moč) ali maksimalni utrip. Z mirovnim utripom so cone utripa še natančnejše.</p>
            <div className="row" style={{ gap: 8, marginTop: 12 }}><Btn primary sm onClick={() => navigate('nastavitve')}>Dopolni profil</Btn></div>
          </>)}
        </Section>

        {/* 8) kaj trener sme videti */}
        <Card tight>
          <div className="between" style={{ fontSize: 13 }}>
            <b>Trener vidi {seen} od {totalActs} aktivnosti</b>
            <Chip sm ok={seen === totalActs}>{totalActs > 0 ? `${Math.round((seen / totalActs) * 100)} %` : '0 %'}</Chip>
          </div>
          {seen !== totalActs && (
            <p className="muted" style={{ fontSize: 12, marginTop: 8 }}>
              Razliko delajo aktivnosti iz Strave in viri, ki jih pravila ne dovolijo v AI poziv — te vidiš ti, trener pa jih ne dobi.
              Če želiš, da štejejo, poveži uro neposredno z intervals.icu ali naloži datoteke.
            </p>
          )}
          {seen !== totalActs && (
            <div className="row" style={{ gap: 8, marginTop: 10 }}><Btn ghost sm onClick={() => navigate('uvoz')}>Uredi vire</Btn></div>
          )}
        </Card>

      </div>
    </div>
  </>)
}
