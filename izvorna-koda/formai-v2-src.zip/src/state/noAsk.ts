/**
 * (v3.50) »Ne« pri »Si ga opravil?« (Prehrana) in »Si ga naredil?« (Danes): en zapis po id-ju dneva načrta za oba zaslona
 * in za autoMissed — prej je Prehrana pisala svoj ključ, Danes je naslednje jutro vprašal znova, prestavitev ključnega
 * treninga pa je čakala na odgovor. V brskalniku (kot prej), zadnjih 21 dni.
 */
const KEY = 'formai.missedNo'
const KEEP_DAYS = 21
type Rec = Record<string, string>   // id dneva → datum dneva

function load(): Rec {
  try {
    const v = JSON.parse(localStorage.getItem(KEY) || 'null') as { date?: unknown; ids?: unknown; no?: unknown } | null
    if (!v || typeof v !== 'object') return {}
    const out: Rec = {}
    // zapis Prehrane pred tem popravkom: { date, ids }
    if (typeof v.date === 'string' && Array.isArray(v.ids)) for (const id of v.ids) if (typeof id === 'string') out[id] = v.date
    if (v.no && typeof v.no === 'object') for (const [id, d] of Object.entries(v.no as Record<string, unknown>)) if (typeof d === 'string') out[id] = d
    return out
  } catch { return {} }
}

/** Ali je bil za ta dan načrta odgovor »Ne«. */
export function saidNo(id: string): boolean { return id in load() }
/** Id-ji dni z odgovorom »Ne« na datum `date`. */
export function noIdsOn(date: string): string[] { return Object.entries(load()).filter(([, d]) => d === date).map(([id]) => id) }
/** Zapiše »Ne« za dan načrta (`date` = datum dneva); starejši od 21 dni izpadejo. */
export function markNo(id: string, date: string): void {
  const from = new Date(Date.parse(date + 'T12:00:00Z') - KEEP_DAYS * 86_400_000).toISOString().slice(0, 10)
  const no = Object.fromEntries(Object.entries({ ...load(), [id]: date }).filter(([, d]) => d >= from))
  try { localStorage.setItem(KEY, JSON.stringify({ no })) } catch { /* zasebni način: velja do zaprtja zaslona */ }
}
/** (v3.51) »Razveljavi« po »Ne«: zapis za ta dan izbriši (vprašanje se vrne). */
export function unmarkNo(id: string): void {
  const rest = Object.fromEntries(Object.entries(load()).filter(([k]) => k !== id))
  try { localStorage.setItem(KEY, JSON.stringify({ no: rest })) } catch { /* zasebni način */ }
}
