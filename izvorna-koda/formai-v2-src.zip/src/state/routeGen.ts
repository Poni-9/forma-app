/**
 * (v3.52 LENO) Nova trasa za dan — risanje z BRouterjem (profil za cestno kolo, krogi čez klance). Ni v začetnem
 * paketu: store.newRouteFor ga naloži ob prvi novi trasi (gumb »Nova trasa« ali autoRoutes). Koda je ista kot prej
 * v store.ts; stanje bere in piše prek store (state, set, routePace).
 */
import type { PlanDay } from '@/domain/types'
import { loadRouteLib, addGenerated, routesOf, libSig, type RouteLib } from '@/data/routes'
import { needOf, suggestRoutes, workoutMinutes } from '@/domain/routes/match'
import { makeLoop, routedToRec, knownRoads } from '@/domain/routes/brouter'
import { climbTurnPoint, type RouteRec } from '@/domain/routes/analyze'
import { climbCandidates, pickClimbLoop, intervalStops, viaOf } from '@/domain/routes/climbLoop'
import { haversineM, decodePolyline, type LatLon } from '@/domain/import/polyline'
import { state, set, routePace } from './store'

/** Ceste, ki jih že voziš (iz sledi voženj na tej napravi) — da nove trase niso naključne. */
let knownCache: { sig: string; f: (pts: readonly LatLon[]) => number } | null = null
function knownOf(lib: RouteLib): (pts: readonly LatLon[]) => number {
  const sig = libSig(lib)
  if (!knownCache || knownCache.sig !== sig) knownCache = { sig, f: knownRoads(lib.raw.filter(r => r.source === 'voznja').map(r => decodePolyline(r.poly))) }
  return knownCache.f
}

/**
 * Nova trasa za dan (BRouter, profil za cestno kolo): 4 smeri, izbere najboljšo za trening (brez makadama,
 * malo semaforjev in naselij, po cestah, ki jih že voziš, za Z2 ravno); za intervale čez tvoj najboljši klanec.
 * Dolžina tako, da ocenjeni čas ustreza treningu.
 */
export async function newRouteFor(day: PlanDay, seed: number, replace = false): Promise<RouteRec> {
  const lib = state.routeLib || await loadRouteLib()
  const home = lib.home
  if (!home) throw new Error('Za novo traso rabim vsaj eno vožnjo z Garmina (začetek poti). Ko pride prva, poskusi znova.')
  const need = needOf(day, state.profile)
  if (!need) throw new Error('Za ta dan ni vožnje.')
  const p = state.profile, recs = routesOf(lib), k = routePace(lib).k, known = knownOf(lib)
  const hard = need.need === 'vo2' || need.need === 'prag' || need.need === 'test'
  const mass = (p.weightKg || 75) + 9
  let rec: RouteRec | null = null
  const est = (prof: number[]) => workoutMinutes(prof, need, p, k)
  if (need.need === 'vo2' || need.need === 'prag') {
    // krog čez 2–4 različne podobne klance iz tvojih voženj: vsak interval na svojem klancu (brez gor–dol po istem)
    let use = pickClimbLoop(climbCandidates(recs, need, p, home, 20), need.reps, 4)
    for (let attempt = 0; use.length >= 2 && attempt < 3 && !rec; attempt++) {
      try {
        const { routed, via } = await makeLoop(home, need.minutes, est, { seed, wantFlat: false, via: viaOf(use), known })
        const r0 = routedToRec(routed, via, `Nova trasa · ${need.label} · ${use.length} klanci`, day.date)
        if (!r0) break
        r0.intervals = intervalStops(routed.pts, use, need.reps)
        const t = suggestRoutes([r0], need, p, state.today, k, home)[0]
        const q = routed.q
        const rough = !!q && (q.unpavedKm > 0.5 || q.urbanKm > r0.km * 0.3)
        if (t && Math.abs(t.estMin - need.minutes) / need.minutes <= 0.2 && !rough) { rec = r0; break }
        // prekratko → raje en klanec s ponovitvami ali krog prave dolžine; predolgo ali slabe ceste → en klanec manj
        if ((t && t.estMin < need.minutes * 0.8) || use.length <= 2) break
        use = use.slice(0, -1)
      } catch { break }
    }
  }
  if (!rec && hard) {
    // klanec do ~15 km od doma: tja v ogrevanju, ponovitve do točke, kjer se interval izteče (ne nujno do vrha), domov v izvozu
    const best = suggestRoutes(recs.filter(r => r.source === 'voznja'), need, p, state.today, k, home).find(s => s.climb && haversineM(home, s.climb.foot) < 15000)
    if (best?.climb) {
      const W = need.workW || (p.ftp || 200)
      const turn = climbTurnPoint(best.rec.poly, best.climb, W, mass, need.need === 'test' ? 20 : need.workMin || 10)
      try {
        const { routed, via } = await makeLoop(home, need.minutes, est, { seed, wantFlat: false, via: [best.climb.foot, turn], known })
        rec = routedToRec(routed, via, `Nova trasa · ${need.label}`, day.date)
        // če s klancem ne pride v čas (±15 %), raje raven krog prave dolžine — intervale narediš na ravnem
        if (rec) { const t = suggestRoutes([rec], need, p, state.today, k, home)[0]; if (t && Math.abs(t.estMin - need.minutes) / need.minutes > 0.15) rec = null }
      } catch { rec = null }
    }
  }
  if (!rec) {
    const { routed, via: pts } = await makeLoop(home, need.minutes, est, { seed, wantFlat: need.need === 'z2' || need.need === 'regen', known })
    rec = routedToRec(routed, pts, `Nova trasa · ${need.label}`, day.date)
  }
  if (!rec) throw new Error('Trasa je prekratka — poskusi znova.')
  const l2 = await addGenerated(rec, replace ? day.date : undefined)
  set({ routeLib: l2 })
  return rec
}
