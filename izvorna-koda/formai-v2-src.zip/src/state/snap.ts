import type { AppState } from './store'
import type { Snapshot } from '@/domain/ai/actions'
import { personalContext } from '@/domain/ai/personal'
import { aiSafeView } from '@/domain/ai/safe'
import { routesOf } from '@/data/routes'

/**
 * Posnetek stanja za AI: splošni kontekst + osebni (cilji, prehrana, teža, počutje, vreme).
 * Zgrajen iz AI-safe pogleda: samo aktivnosti, ki smejo v AI (nikoli Strava — tudi posredno ne), načrt brez
 * kljukic, ki kažejo na skrito aktivnost, trase samo iz dovoljenih voženj; o skritih aktivnostih samo »da/ne«.
 * Podatki z ure (spanec, HRV, mirovni utrip) v AI ne gredo.
 */
export function snapOf(app: AppState): Snapshot {
  const v = aiSafeView({ profile: app.profile, activities: app.activities, plan: app.plan, today: app.today })
  const ok = new Set(v.activities.map(a => a.id))
  const routes = routesOf(app.routeLib).filter(r => r.source !== 'voznja' || ok.has(r.id))
  return {
    profile: v.profile, activities: v.activities, plan: v.plan, today: app.today, hidden: v.hidden,
    extra: personalContext({ profile: v.profile, activities: v.activities, plan: v.plan, checkins: app.checkins, recentMeals: app.recentMeals, tests: app.settings.tests, weather: app.weather, today: app.today, routes, home: app.routeLib?.home ?? null }),
  }
}
