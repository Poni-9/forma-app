import type { AppState } from './store'
import type { Snapshot } from '@/domain/ai/actions'
import { personalContext } from '@/domain/ai/personal'
import { routesOf } from '@/data/routes'

/** Posnetek stanja za AI: splošni kontekst + osebni (cilji, prehrana, teža, počutje, vreme). */
export function snapOf(app: AppState): Snapshot {
  return {
    profile: app.profile, activities: app.activities, plan: app.plan, today: app.today,
    extra: personalContext({ profile: app.profile, activities: app.activities, plan: app.plan, checkins: app.checkins, recentMeals: app.recentMeals, tests: app.settings.tests, weather: app.weather, today: app.today, routes: routesOf(app.routeLib), home: app.routeLib?.home ?? null }),
  }
}
