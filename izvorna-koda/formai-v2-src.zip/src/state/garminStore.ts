/**
 * (v3.52 LENO) Garmin Connect neposredno — del shrambe, ki NI v začetnem paketu: store.ts ga naloži (import())
 * šele, ko je Garmin povezan (settings.garmin.connected) ali ob vrnitvi z Garmina (?garmin=…), ali ob prvem klicu
 * katerega od ovojev (connectGarmin, syncGarmin, pushGarminWorkouts …). Imena in podpisi so isti kot v store.ts —
 * UI kliče ovoje v store.ts, ta modul nikoli neposredno. Čiste sinhrone funkcije (garminAllows, garminPushOn,
 * garminPreview, combinedWellness) ostanejo v store.ts.
 *
 * Vožnje, zdravje in cikel pridejo z Garmina na NAŠ strežnik (push), aplikacija jih od tam prevzame (GET /garmin/*).
 * Ključi na napravi: garmin.since (ms zadnjega zapisa aktivnosti), garmin.healthSince, garmin.cycleSince, garmin.autoAt
 * (zadnji samodejni prenos), garmin.wellness ({ at, days } — dnevi z ure SAMO z Garmina; v state.wellness združeni z
 * intervals.icu, Garmin ima prednost), garmin.cycle (CycleDay[] — NIKOLI v AI, NIKOLI v oblak), garmin.statusAt.
 * Nastavitve (settings.garmin) se usklajujejo med napravami, podatki ne — vsaka naprava jih prevzame s strežnika sama.
 */
import type { Activity, GarminSettings, PlanDay } from '@/domain/types'
import * as repo from '@/data/repo'
import type { WellnessDay } from '@/domain/wellness'
import { startGarminConnect, garminReturnParam, fetchGarminStatus, fetchGarminActivities, fetchGarminHealth, fetchGarminCycle, garminDisconnect, garminErrMsg, nextSince, GarminError, GARMIN_PAGE, type GarminStatus } from '@/domain/garmin/client'
import { activityFromGarmin, sameRideAsIcu, enrichIcuWithGarmin } from '@/domain/garmin/activities'
import { wellnessFromGarmin, upsertWellnessDays } from '@/domain/garmin/wellness'
import { cycleFromMct, upsertCycle, type CycleDay } from '@/domain/garmin/cycle'
import { garminWorkoutsFor, type GarminWorkout } from '@/domain/garmin/workouts'
import { garminCourse } from '@/domain/garmin/course'
import { putGarminWorkouts, deleteGarminWorkouts, putGarminCourse, GarminPushError } from '@/domain/garmin/pushClient'
import type { RouteRec as GarminRouteRec } from '@/domain/routes/analyze'
import { plural, count, W, NBSP } from '@/ui/format'
import { adaptAfterLoad } from '@/domain/training/planner'
import { loadRouteLib, routesOf } from '@/data/routes'
import { needOf, suggestRoutes } from '@/domain/routes/match'
import { getKV, setKV } from '@/data/db'
import { tombAct, stableStr } from '@/data/merge'
import { dailyTarget, activityKcal } from '@/domain/nutrition/energy'
import {
  state, set, toast, updateSettings, linkToPlan, dropStandIns, autoAdapt, touch, deriveFromRides, autoMissed, routePace,
  combinedWellness, garminAllows, garminPushOn, GARMIN_CONNECT_ERR, G_WELL, G_CYCLE, GW_KEY, type GarminSyncResult, type GarminWorkoutsInfo,
} from './store'

/* ---------- (v3.52) Garmin Connect neposredno — podatki ---------- */
const G_SINCE = 'garmin.since', G_HEALTH_SINCE = 'garmin.healthSince', G_CYCLE_SINCE = 'garmin.cycleSince', G_AUTO_AT = 'garmin.autoAt', G_STATUS_AT = 'garmin.statusAt'
/** (v3.52 popravki) največ strani na tip v enem prenosu (more) */
const GARMIN_PAGES = 10
let garminSyncBusy = false

/** Napaka Garmina za prikaz (state.garminErr) in v nastavitvah (lastError — tudi na drugi napravi). */
async function setGarminErr(msg: string | null): Promise<void> {
  if (msg !== state.garminErr) set({ garminErr: msg })
  const g = state.settings.garmin
  if (g && (g.lastError ?? null) !== msg) await updateSettings(cur => ({ garmin: cur.garmin ? { ...cur.garmin, lastError: msg } : cur.garmin }))
}

/** »Poveži z Garmin Connect« (gumb na Uvozu): preusmeritev na strežnik → Garmin. Brez prijave obvestilo. */
export async function connectGarmin(): Promise<void> {
  try { await startGarminConnect() } catch (e) { toast(garminErrMsg(e), 'err', 8000) }
}

/**
 * Ob zagonu: vrnitev z Garmina (?garmin=ok|err) → stanje s strežnika v nastavitve (usklajene med napravami), obvestilo,
 * parameter ven iz naslova, prvi prenos. Vrne true, če je bila to vrnitev z Garmina.
 */
export async function finishGarminConnect(): Promise<boolean> {
  const r = garminReturnParam()
  if (!r) return false
  // (v3.52 popravki) jasno: kaj se je zgodilo in kaj narediti; razlog ostane na kartici (garminErr), ne samo v obvestilu
  if (r === 'err') { set({ garminErr: GARMIN_CONNECT_ERR }); toast(GARMIN_CONNECT_ERR, 'err', 10000); return true }
  try {
    const st = await fetchGarminStatus()
    if (!st.connected) { toast('Garmin povezave ni potrdil — poskusi znova.', 'err', 8000); return true }
    const prev = state.settings.garmin
    await updateSettings({ garmin: { connected: true, connectedAt: st.connectedAt || new Date().toISOString(), userId: st.userId, permissions: st.permissions, pushWorkouts: prev?.pushWorkouts ?? true, pushCourses: prev?.pushCourses ?? true, health: prev?.health ?? false, cycle: prev?.cycle ?? false, lastSyncAt: null, lastError: null } })
    set({ garminErr: null })
    await setKV(G_SINCE, 0); await setKV(G_HEALTH_SINCE, 0); await setKV(G_CYCLE_SINCE, 0); await setKV(G_STATUS_AT, Date.now())
    toast('Povezano z Garmin Connect — vožnje pridejo same, ko jih ura sinhronizira. Zgodovine Garmin ne pošilja: starejše vožnje uvozi iz arhiva ali prek intervals.icu.', 'ok', 9000)
    void syncGarmin(true)
  } catch (e) { toast(garminErrMsg(e), 'err', 8000) }
  return true
}

/** Stanje s strežnika v nastavitve (dovoljenja, prekinjena povezava »broken«) — največ enkrat na dan, ali ročno. */
export async function refreshGarminStatus(force = false): Promise<GarminStatus | null> {
  const g = state.settings.garmin
  if (!g?.connected || !state.user) return null
  if (!force && Date.now() - ((await getKV<number>(G_STATUS_AT)) || 0) < 24 * 3600_000) return null
  await setKV(G_STATUS_AT, Date.now())
  const st = await fetchGarminStatus()
  const patch: Partial<GarminSettings> = {}
  if (st.permissions && stableStr(st.permissions) !== stableStr(g.permissions)) patch.permissions = st.permissions
  if (st.userId && st.userId !== g.userId) patch.userId = st.userId
  if (Object.keys(patch).length) await updateSettings(cur => ({ garmin: cur.garmin ? { ...cur.garmin, ...patch } : cur.garmin }))
  if (!st.connected) {
    // strežnik povezave nima več (deregistracija pri Garminu, izbris) — nastavitev ostane, a brez »povezano«
    await updateSettings(cur => ({ garmin: cur.garmin ? { ...cur.garmin, connected: false } : cur.garmin }))
    await setGarminErr('Garmin je povezavo prekinil — poveži znova.')
  } else if (st.broken) await setGarminErr('Garmin je prekinil povezavo (žeton ne velja) — poveži znova.')
  return st
}

/**
 * Prenos s strežnika: aktivnosti (vedno), zdravje (ob vklopu health) in cikel (ob vklopu cycle + MCT_EXPORT).
 * Ob zagonu in ob vrnitvi v aplikacijo, največ na 10 min (force: takoj). Dedup z intervals.icu: ista vožnja z Garmina
 * prek intervals.icu (start ±90 s) ne postane dvojnik — obstoječi zapis dobi Garminove id-je in manjkajoče podatke.
 * Napaka → state.garminErr in settings.garmin.lastError (nikoli tiho); obvestilo samo pri ročnem.
 */
export async function syncGarmin(force = false): Promise<GarminSyncResult | null> {
  const g = state.settings.garmin
  if (!g?.connected) return null
  if (garminSyncBusy) return { added: 0, upgraded: 0, healthDays: 0, cycleDays: 0, error: null, skipped: 'Prenos z Garmina že teče.' }
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return { added: 0, upgraded: 0, healthDays: 0, cycleDays: 0, error: null, skipped: 'Ni povezave z internetom.' }
  if (!state.user) { if (state.authKnown) await setGarminErr('Garmin deluje s prijavo — prijavi se.'); return { added: 0, upgraded: 0, healthDays: 0, cycleDays: 0, error: null, skipped: 'Ni prijave.' } }
  const last = (await getKV<number>(G_AUTO_AT)) || 0
  if (!force && Date.now() - last < 10 * 60_000) return { added: 0, upgraded: 0, healthDays: 0, cycleDays: 0, error: null, skipped: 'Pravkar preverjeno.' }
  garminSyncBusy = true; set({ garminBusy: true })
  const res: GarminSyncResult = { added: 0, upgraded: 0, healthDays: 0, cycleDays: 0, error: null, skipped: null }
  const freshDates: string[] = []
  try {
    await setKV(G_AUTO_AT, Date.now())
    await refreshGarminStatus(force).catch(() => null)
    if (!state.settings.garmin?.connected) return res
    // 1) aktivnosti — po straneh (t > since), vsaka stran v zaklepu uvoza (isti kot intervals.icu in datoteke)
    // (v3.52 popravki) since = `now` odgovora (največji vrnjeni t), nikoli Date.now(); ob `more` naslednja stran (največ GARMIN_PAGES)
    let since = (await getKV<number>(G_SINCE)) || 0
    for (let page = 0; page < GARMIN_PAGES; page++) {
      const r = await fetchGarminActivities(since)
      const next = nextSince(since, r, r.items)
      if (!r.items.length) { const moved = next !== since; if (moved) { since = next; await setKV(G_SINCE, since) } if (!r.more || !moved) break; continue }
      await repo.withImportLock(async () => {
        const before = new Set(state.activities.map(a => a.id))
        const tomb = await repo.getTomb()
        const all0 = state.activities
        const cands: Activity[] = []
        let enriched = 0
        for (const rec of r.items) {
          const a = activityFromGarmin(rec, state.profile)
          if (!a || tomb[tombAct(a)]) continue
          // ista vožnja je že prišla prek intervals.icu (izvor GARMIN): brez dvojnika, obstoječi dobi Garminove id-je in podatke
          const twin = all0.find(e => sameRideAsIcu(a, e))
          if (twin) { const m = enrichIcuWithGarmin(twin, a); if (m) { await repo.putActivity(m); enriched++ }; continue }
          cands.push(a)
        }
        res.upgraded += enriched
        if (cands.length) {
          await dropStandIns(cands)
          const out = await repo.addActivities(cands)
          res.added += out.added; res.upgraded += out.upgraded
        }
        if (cands.length || enriched) {
          const all = await repo.allActivities()
          set({ activities: all }); void touch()
          const fresh = all.filter(a => !before.has(a.id))
          await linkToPlan(fresh)
          freshDates.push(...fresh.map(a => a.date))
          const ride = fresh.find(a => a.date === state.today && a.sport === 'kolo')
          const t = ride ? dailyTarget(state.profile, state.activities.filter(a => a.date === state.today), state.plan.filter(d => d.date === state.today), state.today) : null
          if (ride && t && adaptAfterLoad(state.profile, state.plan, state.activities, state.today, state.today)?.state !== 'predlog') {
            const f = (n: number) => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ' '), k = activityKcal(ride, state.profile), d = t.plannedWas ? t.burn - t.plannedWas : 0
            toast(`Vožnja z Garmina: ${f(k)} kcal${t.plannedWas && Math.abs(d) >= 50 ? ` (načrt ${f(t.plannedWas)}, ${d > 0 ? '+' : '−'}${f(Math.abs(d))})` : ''} → današnji cilj ${f(t.kcal)} kcal. Na Danes vpiši, kaj si popil in pojedel na kolesu.`, 'info', 10000)
          } else if (fresh.length) toast(`Garmin: ${fresh.length}${NBSP}${plural(fresh.length, ['nova vadba', 'novi vadbi', 'nove vadbe', 'novih vadb'])}.`, 'info', 5000)
        }
      })
      const moved = next !== since
      since = next
      if (moved) await setKV(G_SINCE, since)
      if (!(r.more || r.items.length >= GARMIN_PAGE) || !moved) break
    }
    // 2) zdravje (izrecna privolitev) — samo na napravi; po straneh (more)
    if (state.settings.garmin?.health === true && garminAllows(state.settings.garmin, 'HEALTH_EXPORT')) {
      let hs = (await getKV<number>(G_HEALTH_SINCE)) || 0
      for (let page = 0; page < GARMIN_PAGES; page++) {
        const h = await fetchGarminHealth(hs)
        const recs = [...(h.dailies || []), ...(h.sleeps || []), ...(h.hrv || []), ...(h.stress || [])]
        const days = wellnessFromGarmin(h)
        if (days.length) {
          const prev = await getKV<{ at: number; days: WellnessDay[] }>(G_WELL)
          await setKV(G_WELL, { at: Date.now(), days: upsertWellnessDays(prev?.days, days) })
          set({ wellness: await combinedWellness() })
          res.healthDays += days.length
        }
        const next = nextSince(hs, h, recs)
        const moved = next !== hs
        hs = next
        if (moved) await setKV(G_HEALTH_SINCE, hs)
        if (!h.more || !moved) break
      }
    }
    // 3) cikel (izrecna privolitev + dovoljenje MCT_EXPORT) — samo na napravi, NIKOLI v AI; po straneh (more)
    if (state.settings.garmin?.cycle === true && garminAllows(state.settings.garmin, 'MCT_EXPORT')) {
      let cs = (await getKV<number>(G_CYCLE_SINCE)) || 0
      for (let page = 0; page < GARMIN_PAGES; page++) {
        const c = await fetchGarminCycle(cs)
        const fresh = c.mct.map(cycleFromMct).filter((x): x is CycleDay => !!x)
        if (fresh.length) {
          const next = upsertCycle(await getKV<CycleDay[]>(G_CYCLE), fresh)
          await setKV(G_CYCLE, next); set({ cycle: next })
          res.cycleDays += fresh.length
        }
        const next = nextSince(cs, c, c.mct as { t?: unknown }[])
        const moved = next !== cs
        cs = next
        if (moved) await setKV(G_CYCLE_SINCE, cs)
        if (!c.more || !moved) break
      }
    }
    await setGarminErr(null)
    if (res.added || res.upgraded || res.healthDays || res.cycleDays || force) await updateSettings(cur => ({ garmin: cur.garmin ? { ...cur.garmin, lastSyncAt: new Date().toISOString() } : cur.garmin }))
  } catch (e) {
    res.error = garminErrMsg(e)
    await setGarminErr(res.error)
    if (e instanceof GarminError && e.kind === 'none') await updateSettings(cur => ({ garmin: cur.garmin ? { ...cur.garmin, connected: false } : cur.garmin }))
    if (force) toast(res.error, 'err', 8000)
  } finally { garminSyncBusy = false; set({ garminBusy: false }) }
  if (freshDates.length) { await autoAdapt(freshDates); await deriveFromRides(); await autoMissed() }
  return res
}

/**
 * »Odklopi Garmin«: strežnik odjavi pri Garminu in pobriše žetone ter podatke; na napravi gredo stran zdravje z Garmina
 * in cikel, settings.garmin = null (na vseh napravah). VOŽNJE OSTANEJO — so uporabnikove (kot pri intervals.icu).
 * Ob napaki strežnika (omrežje) nič ne pobriše in pove.
 */
export async function disconnectGarmin(): Promise<boolean> {
  try { await garminDisconnect() } catch (e) { toast(garminErrMsg(e), 'err', 8000); return false }
  // treningi na uri so pobrisani že na strežniku (disconnect pobriše garminWorkouts); lokalno stanje stran
  await setKV(GW_KEY, null).catch(() => undefined); set({ garminWorkouts: null })
  await clearGarminLocal('health'); await clearGarminLocal('cycle')
  for (const k of [G_SINCE, G_HEALTH_SINCE, G_CYCLE_SINCE, G_AUTO_AT, G_STATUS_AT]) await setKV(k, null)
  await updateSettings({ garmin: null })
  set({ garminErr: null, wellness: await combinedWellness() })
  toast('Garmin je odklopljen. Tvoje vožnje ostanejo v aplikaciji.', 'ok', 7000)
  return true
}
/** Pred izbrisom računa: Garminu povemo, da soglasja ni več (SPEC §1.7) — strežnik pobriše žetone; napaka ne ustavi izbrisa. */
export async function garminBeforeAccountDelete(): Promise<void> {
  if (!state.settings.garmin?.connected) return
  await garminDisconnect().catch(() => undefined)
  await clearGarminLocal('health'); await clearGarminLocal('cycle')
}
async function clearGarminLocal(what: 'health' | 'cycle'): Promise<void> {
  if (what === 'health') { await setKV(G_WELL, null); await setKV(G_HEALTH_SINCE, 0); set({ wellness: await combinedWellness() }) }
  else { await setKV(G_CYCLE, null); await setKV(G_CYCLE_SINCE, 0); set({ cycle: null }) }
}
/**
 * Možnosti Garmina: health (spanec, HRV, utrip, stres), cycle (menstrualni cikel), pushWorkouts, pushCourses.
 * Vklop health/cycle takoj prenese podatke; izklop jih na tej napravi izbriše. Pošiljanje na uro ureja PUSH (pushGarminWorkouts).
 */
export async function setGarminOpt(key: 'health' | 'cycle' | 'pushWorkouts' | 'pushCourses', on: boolean): Promise<void> {
  if (!state.settings.garmin) return
  await updateSettings(cur => ({ garmin: cur.garmin ? { ...cur.garmin, [key]: on } : cur.garmin }))
  // izklop pošiljanja treningov: naši prihodnji treningi gredo z ure; vklop jih pošlje
  if (key === 'pushWorkouts') { if (on) void pushGarminWorkouts(true); else await removeGarminWorkouts().catch(() => null); return }
  if (key === 'health' || key === 'cycle') {
    if (!on) { await clearGarminLocal(key); return }
    await setKV(key === 'health' ? G_HEALTH_SINCE : G_CYCLE_SINCE, 0)
    if (key === 'cycle' && !garminAllows(state.settings.garmin, 'MCT_EXPORT')) { toast('Garmin za ta račun ne deli podatkov o ciklu — v Garmin Connect preveri dovoljenja za FORMAI.', 'info', 9000); return }
    if (key === 'health' && !garminAllows(state.settings.garmin, 'HEALTH_EXPORT')) { toast('Garmin za ta račun ne deli zdravja — v Garmin Connect preveri dovoljenja za FORMAI.', 'info', 9000); return }
    const r = await syncGarmin(true)
    if (r && !r.error && !r.skipped) {
      if (key === 'health') toast(r.healthDays ? `Spanec, HRV, utrip in stres z Garmina: ${r.healthDays} ${plural(r.healthDays, ['dan', 'dneva', 'dni', 'dni'])}.` : 'Garmin še ni poslal zdravja — pride ob naslednji sinhronizaciji ure.', r.healthDays ? 'ok' : 'info', 8000)
      else toast(r.cycleDays ? 'Podatki o ciklu so na tej napravi — v AI nikoli ne gredo.' : 'Garmin še ni poslal podatkov o ciklu — pridejo ob naslednji sinhronizaciji ure.', 'info', 8000)
    }
  }
}

/* ---------- (v3.52) Garmin Connect neposredno — treningi na uro ---------- */
const GW_SIG_KEY = 'garmin.workouts.sig'
let garminPushBusy = false
/** Besedilo napake pošiljanja (GarminPushError ali druga). */
const garminPushMsg = (e: unknown): string => (e instanceof GarminPushError ? e.message : (e as Error)?.message || 'Pošiljanje na Garmin ni uspelo.')

/**
 * Treningi naslednjih 14 dni → Garmin (strežnik → Training API). Sproži se skupaj s pošiljanjem v intervals.icu
 * (schedulePushWorkouts: po sestavi, prestavitvi, premoru; ob zagonu, če je staro). Brez spremembe od zadnjega
 * uspešnega pošiljanja (isti podpis, < 24 h) ni klica. manual = gumb v Nastavitvah (obvestilo tudi ob »nič novega«).
 * Napaka Garmina pri posameznem dnevu NI tiha: v errors[] in v obvestilu.
 */
export async function pushGarminWorkouts(manual = false): Promise<GarminWorkoutsInfo | null> {
  if (!garminPushOn() || garminPushBusy || (typeof navigator !== 'undefined' && navigator.onLine === false)) return null
  const desired: GarminWorkout[] = garminWorkoutsFor(state.plan, state.profile, state.today, 14)
  const sig = stableStr({ from: state.today, h: desired.map(w => [w.date, w.hash]) })
  if (!manual) {
    const last = await getKV<{ sig: string; at: number }>(GW_SIG_KEY)
    if (last && last.sig === sig && Date.now() - last.at < 24 * 3600_000 && !state.garminWorkouts?.err) return state.garminWorkouts ?? null
  }
  garminPushBusy = true
  try {
    const r = await putGarminWorkouts(desired, undefined, state.today)
    const info: GarminWorkoutsInfo = { at: new Date().toISOString(), n: desired.length, created: r.created, updated: r.updated, removed: r.removed, errors: r.errors, err: r.errors.length ? `${r.errors.length}${NBSP}${plural(r.errors.length, ['trening', 'treninga', 'treningi', 'treningov'])} Garmin ni sprejel: ${r.errors[0]!.error}` : null }
    await setKV(GW_KEY, info); set({ garminWorkouts: info })
    if (!r.errors.length) await setKV(GW_SIG_KEY, { sig, at: Date.now() })
    const changed = r.created + r.updated
    if (manual || r.errors.length) toast(r.errors.length
      ? info.err!
      : changed || r.removed
        ? `Na Garmin: ${changed ? `${changed}${NBSP}${plural(changed, ['poslan trening', 'poslana treninga', 'poslani treningi', 'poslanih treningov'])}` : ''}${changed && r.removed ? ', ' : ''}${r.removed ? `${r.removed}${NBSP}${plural(r.removed, ['pobrisan', 'pobrisana', 'pobrisani', 'pobrisanih'])}` : ''} — ura jih dobi ob naslednji sinhronizaciji z Garmin Connect.`
        : desired.length ? `Garmin Connect je že enak načrtu (${count(desired.length, W.trening)}).` : 'V naslednjih 14 dneh ni treninga za uro (kolo, test, tek) — nič za poslati.', r.errors.length ? 'err' : 'ok', 7000)
    return info
  } catch (e) {
    const info: GarminWorkoutsInfo = { at: new Date().toISOString(), n: desired.length, created: 0, updated: 0, removed: 0, errors: [], err: garminPushMsg(e) }
    await setKV(GW_KEY, info); set({ garminWorkouts: info })
    if (e instanceof GarminPushError && (e.code === 'ni_povezave' || e.code === 'garmin_401' || e.code === 'garmin_403')) await updateSettings(s => ({ garmin: s.garmin ? { ...s.garmin, lastError: info.err } : s.garmin })).catch(() => undefined)
    if (manual) toast(info.err!, 'err', 7000)
    return null
  } finally { garminPushBusy = false }
}

/** Izklop »treningov na uro«, odklop ali premor brez treningov: naši prihodnji treningi pri Garminu stran. Vrne število pobrisanih ali null ob napaki. */
export async function removeGarminWorkouts(): Promise<number | null> {
  if (!state.settings.garmin?.connected || garminPushBusy) return null
  garminPushBusy = true
  try {
    const removed = await deleteGarminWorkouts(undefined, state.today)
    const info: GarminWorkoutsInfo = { at: new Date().toISOString(), n: 0, created: 0, updated: 0, removed, errors: [], err: null }
    await setKV(GW_KEY, info); set({ garminWorkouts: info })
    await setKV(GW_SIG_KEY, null)
    return removed
  } catch (e) {
    toast(garminPushMsg(e), 'err', 7000)
    return null
  } finally { garminPushBusy = false }
}

/**
 * Trasa dneva na Garmin (Courses API) — ročno, gumb na dnevu z vožnjo (UI v 2. valu). Brez podane trase vzame najboljši
 * predlog iz tvojih voženj za ta dan. Vrne courseId ali null (napaka je v obvestilu).
 */
export async function pushGarminCourse(day: PlanDay, rec?: GarminRouteRec | null): Promise<string | number | null> {
  const g = state.settings.garmin
  if (!g?.connected) { toast('Garmin ni povezan — poveži ga v Nastavitvah.', 'err', 6000); return null }
  if (g.pushCourses === false) { toast('Pošiljanje tras na Garmin je izklopljeno (Nastavitve → Garmin).', 'info', 6000); return null }
  if (g.permissions?.length && !g.permissions.includes('COURSE_IMPORT')) { toast('Garminu nisi dovolil uvoza tras (Courses) — poveži Garmin znova in potrdi trase.', 'err', 7000); return null }
  let r = rec ?? null
  if (!r) {
    const lib = state.routeLib || await loadRouteLib()
    const need = needOf(day, state.profile)
    if (!need) { toast('Za ta dan ni vožnje — trase ni kaj poslati.', 'info', 6000); return null }
    const recs = routesOf(lib).filter(x => x.source === 'voznja' || x.date === day.date)
    r = suggestRoutes(recs, need, state.profile, state.today, routePace(lib).k, lib.home)[0]?.rec ?? null
    if (!r) { toast('Ni trase za ta dan — najprej jo izberi na kartici »Trasa za ta trening«.', 'info', 7000); return null }
  }
  const course = garminCourse(r, day.date)
  if (!course) { toast('Trasa nima sledi — na Garmin ne gre.', 'err', 6000); return null }
  try {
    const { courseId } = await putGarminCourse(course)
    toast(`Trasa »${course.courseName}« je na Garminu — ura jo dobi ob naslednji sinhronizaciji (Navigacija → Trase).`, 'ok', 7000)
    return courseId
  } catch (e) {
    toast(garminPushMsg(e), 'err', 7000)
    return null
  }
}
