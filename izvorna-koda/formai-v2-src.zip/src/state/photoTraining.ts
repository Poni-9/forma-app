import type { Activity, PlanDay } from '@/domain/types'
import { getState, addActivities, setPlanDone, savePlanDay, updatePlanDays, restorePlanDays, logChange } from './store'
import { estimateTss } from '@/domain/training/load'
import { fitsDay, placeWorkout } from '@/domain/training/fromPhoto'

/**
 * (v3.50) Shranjevanje treninga s slike. Shrani se samo rezultat (aktivnost ali dan načrta) — slika nikoli.
 */

/**
 * Opravljen trening s posnetka: aktivnost (vir 'screenshot') na datum izbranega dne in kljukica na tem dnevu — če mu
 * ustreza (ista vrsta ali vzdržljivostni nadomestek). Prava vadba zamenja »Opravil« brez ure (zapis iz načrta odpade),
 * dvojnik (ista vadba že vpisana ali z ure) se ne shrani in ne odkljuka ničesar. dayId null = dodatna vadba (brez kljukice).
 */
export async function saveDoneShot(a: Activity, dayId: string | null): Promise<{ added: boolean; day: PlanDay | null }> {
  const s = getState()
  const d = dayId ? s.plan.find(x => x.id === dayId) ?? null : null
  const target = d && !d.done?.activityId && fitsDay(a, d) ? d : null
  const act: Activity = { ...a, date: target ? target.date : a.date, updatedAt: new Date().toISOString() }
  act.tss = estimateTss(act, s.profile)
  const before = new Map(s.plan.map(x => [x.id, x.done] as const))
  const r = await addActivities([act])
  if (!r.added) return { added: false, day: null }
  // uvoz sam odkljuka dan iste vrste (linkToPlan); nadomestek (hribi namesto kolesa) poveže ta korak
  let linked = getState().plan.find(x => x.done?.activityId === act.id) ?? null
  // (v3.50) izbira v listu velja: »Brez — dodatna vadba« (ali dan, ki mu vadba ne ustreza) ne odkljuka ničesar, izbran dan
  // dobi kljukico — povezavo uvoza z drugim dnem razvežemo (prej je 50 min dodatne vožnje odkljukalo ključni trening)
  if (linked && linked.id !== target?.id) {
    await updatePlanDays([{ ...linked, done: before.get(linked.id) ?? null }])
    linked = null
  }
  if (!linked && target) { await setPlanDone(target.id, true, act.id); linked = getState().plan.find(x => x.id === target.id && x.done?.activityId === act.id) ?? null }
  return { added: true, day: linked }
}

/**
 * Trening s slike v načrt: zamenja počitek tega dne ali izbran neopravljen trening (»Namesto«), sicer gre poleg.
 * Opravljeno ostane. Vrne zapisani dan in razveljavitev (prejšnji zapisi tega dne).
 */
export async function addPhotoWorkout(day: PlanDay, replaceId: string | null = null): Promise<{ day: PlanDay; replaced: PlanDay | null; undo: () => Promise<void> }> {
  const { write, prev, replaced } = placeWorkout(getState().plan, day, { replaceId })
  await savePlanDay(write)
  void logChange(`Trening s slike: ${write.title} (${write.durationMin} min)${replaced && replaced.kind !== 'pocitek' ? ` namesto »${replaced.title}«` : ''}.`, false)
  return { day: getState().plan.find(x => x.id === write.id) ?? write, replaced, undo: () => restorePlanDays(prev, [write.date]) }
}

/** Seje predloga s slike sebe (neobvezne, kot »Jedro po želji«): samo te zapise, drugi zapisi istih dni ostanejo. */
export async function addSelfSessions(days: PlanDay[]): Promise<void> {
  if (!days.length) return
  await updatePlanDays(days)
  void logChange(`Predlog s slike: ${days[0]!.title} ${days.length}× (po želji).`, false)
}
