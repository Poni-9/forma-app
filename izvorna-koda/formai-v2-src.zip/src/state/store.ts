import { useSyncExternalStore } from 'react'
import type { Activity, DailyCheckin, Focus, GarminSettings, MealEntry, PlanDay, Profile, Race, Settings, TestEntry, WeekMenu } from '@/domain/types'
import * as repo from '@/data/repo'
import { goalBasePatch } from '@/domain/nutrition/body'
import { todayIso, addDays, weekStartIso, estimateTss, formSeries, fmtDur } from '@/domain/training/load'
import { fetchActivities, fetchAthlete, fetchEvents, createEvents, updateEvent, deleteEvent, fetchWellness, icuReady, setIcuQuotaStore, icuBudget, icuErrorKind, disconnectApp, IcuError, importWindowDays, type IcuErrKind, type IcuQuota } from '@/domain/intervals/client'
import type { WellnessDay } from '@/domain/wellness'
import { finishIcuOAuth } from '@/data/icuOauth'
// (v3.52 LENO) Garmin Connect neposredno: samo tipi in predogled treninga — prenos, odklop in pošiljanje so v ./garminStore (ni v začetnem paketu)
import type { GarminStatus } from '@/domain/garmin/client'
import type { CycleDay } from '@/domain/garmin/cycleRules'
import { garminWorkout, type GarminWorkout } from '@/domain/garmin/workouts'
import { capturePilotCode, flushPilot, sendPilot } from '@/data/pilot'
import { afterAsk, type PilotQ } from '@/domain/pilot'
import { APP_VERSION, PROXY } from '@/config'
import { plural, count, W, NBSP, dayGen, dayAcc, dm } from '@/ui/format'
import { icuWorkout, workoutDiff, type IcuWorkout } from '@/domain/intervals/workouts'
import type { IcuDiag } from '@/domain/intervals/diagnosis'
import { powerMeterFrom, baselineHours, moveKeySession } from '@/domain/training/review'
import { missedKeys, applyMissed, yesterdayUnmarked } from '@/domain/training/missed'
import { easyFeltHard } from '@/domain/coach/rpe'
import { raceLock } from '@/domain/training/protect'
import { undoToast } from '@/ui/Confirm'
import { hoursAdvice } from '@/domain/training/goal'
import { buildWeek, weekContext, weekBikeMinutes, hikeSwap, swapBack, coreOnDemand, adaptAfterLoad, undoLoadAdapt, type LoadAdapt } from '@/domain/training/planner'
import { offSeasonNow } from '@/domain/training/goalChange'
import { OFF_MIX } from '@/domain/training/offMix'
import { loadRouteLib, fillRouteLib, routesOf, libSig, ROUTE_STREAMS_PER_RUN, type RouteLib } from '@/data/routes'
import { needOf, suggestRoutes, paceFactor, paceAdj } from '@/domain/routes/match'
import type { RouteRec } from '@/domain/routes/analyze'
import { haversineM } from '@/domain/import/polyline'
import { getKV, setKV, pruneKV, requestPersist, KV } from '@/data/db'
import { trapErrors } from '@/data/errlog'
// (v3.51) pošiljanje pripomb ni v začetnem paketu
const flushFeedback = (): Promise<number> => import('@/data/feedback').then(m => m.flushFeedback())
import { accentDeep } from '@/ui/theme'
import { profileFromFocus, weekLine, mixLine, trainingDays, isCustom } from '@/domain/focus/model'
import { startsTomorrow } from '@/domain/training/danes'
import { CONSENT_V } from '@/domain/ai/consent'
import { daysLine } from '@/domain/focus/choices'
import { core, onAuth, signInGoogle, signOutNow, idToken, proFromFirestore, setAccountDeleteHooks, deleteAccount as deleteAccountOnServer, type AuthUser } from '@/data/firebase'
import { startSync, stopSync, touch as syncTouch, onSyncStatus, pushNow, syncNow, syncOwner, forgetRemote, type SyncStatus, type FirstSyncResult } from '@/data/sync'
import { syncNotice, NOTICE_EMPTY, type NoticeMem } from '@/data/syncNotice'
import { saidNo } from './noAsk'
import { markAuth, authHintSync, idbSession, shouldBootAuth } from '@/data/authHint'
import { tombTest, tombAct, stableStr, mergeCoach } from '@/data/merge'
import { restoreBackup, type ParsedBackup } from '@/data/backup'
import { sickify, unsickify, sickPeriod } from '@/domain/training/sick'
import { pausePeriod, pauseify, pauseLock, pauseLine, activePause, ownDay, withOwn, planKey, pauseStart, PAUSE_MAX_DAYS, type PauseMode, type PauseReason, type WeekPause } from '@/domain/training/pause'
import { readState, adaptToState, undoState, load3, type StateMode, type StateRead } from '@/domain/training/state'
import { readinessOf } from '@/domain/readiness'
import { recoveryOf, wellnessActive, mergeWellness } from '@/domain/wellness'
import { aiAllowed } from '@/domain/import/provenance'
import { bestPlanMatch } from '@/domain/training/plandays'
import { isStandIn, sportOfKind, realOn, standInFor, standInChanged, standInsToDrop, standInsToAdd } from '@/domain/training/standin'
import { dailyTarget, activityKcal, calcWeightKg } from '@/domain/nutrition/energy'
import { foodPrefsFromWish } from '@/domain/nutrition/recipes'
import { forecast, cachedForecast, windowOf, WINDOW_NAMES, type Forecast } from '@/domain/weather'
import { haptic } from '@/ui/haptic'
import { testError } from '@/domain/ranges'

/** En vir resnice za UI. Piše se prek akcij, ki hkrati posodobijo IndexedDB, sprožijo sinhronizacijo in izris. */
export interface AppState {
  ready: boolean
  profile: Profile
  settings: Settings
  activities: Activity[]
  /** načrt za trenutni teden ± 2 tedna */
  plan: PlanDay[]
  mealsToday: MealEntry[]
  /** obroki zadnjih 90 dni (zgodovina, pogosti obroki, graf) */
  recentMeals: MealEntry[]
  checkinToday: DailyCheckin | null
  /** vsi jutranji vnosi (teža, spanec, počutje) */
  checkins: DailyCheckin[]
  weather: Forecast | null
  today: string
  /** zadnje obvestilo (za staro rabo); vsa vidna so v toasts */
  toast: Toast | null
  /** (v3.50) vidna obvestila, najstarejše prvo (največ MAX_TOASTS) */
  toasts?: Toast[]
  migration: { activities: number; meals: number; plan: number } | null
  user: AuthUser | null
  /** null = še ne vemo (Firebase se nalaga) */
  authKnown: boolean
  sync: SyncStatus
  /** neomejen AI (proUsers/{uid}.pro na strežniku) */
  pro: boolean
  /** knjižnica tras (samo na tej napravi) */
  routeLib: RouteLib | null
  routesBusy: boolean
  /** treningi na uro: zadnje pošiljanje v koledar intervals.icu */
  icuWorkouts: IcuWorkoutsInfo | null
  /** zadnji uvoz iz intervals.icu: koliko je vrnil, koliko uporabnih, koliko Stravinih (za pošteno pojasnilo) */
  icuDiag: IcuDiag | null
  /**
   * Prvo usklajevanje z oblakom po prijavi: null = še teče (ali ni prijave); 'ok' = račun ima podatke (prevzeti);
   * 'empty' = račun je bil prazen (ta naprava je poslala svoje); 'error' = ni uspelo (NI prazen račun — ne začni uvoda).
   * Za staro rabo kot boolean: firstSyncDone(state).
   */
  firstSync: FirstSyncResult | null
  /** spanec, HRV, mirovni utrip z ure (intervals.icu) — samo na tej napravi, samo ob vklopu */
  wellness: WellnessDay[] | null
  /** prijava z drugim računom, kot mu pripadajo podatki na tej napravi — sinhronizacija čaka na odločitev */
  accountClash: AccountClash | null
  /** zadnja napaka povezave z intervals.icu (null = zadnji uvoz je uspel) */
  icuErr: IcuErrState | null
  /** dokument v oblaku je bil izbrisan na drugi napravi — sinhronizacija ustavljena, odjavljen */
  syncDeleted: { at: number } | null
  /** spremembe načrta: kaj je aplikacija (ali ti) spremenila in zakaj — Plan → Spremembe načrta (samo ta naprava) */
  changes: PlanChange[]
  /** (v3.49) shramba na napravi se ne odpre (zasebni način, blokirani piškotki) — App pokaže razlago namesto logotipa */
  storageError: string | null
  /** (v3.52) menstrualni cikel z Garmina (Women's Health API) — samo prikaz in pravila, NIKOLI v AI, samo na tej napravi */
  cycle: CycleDay[] | null
  /** (v3.52) prenos z Garmina teče / zadnja napaka Garmina (null = v redu) */
  garminBusy: boolean
  garminErr: string | null
}
/** (v3.50) Gumb v obvestilu: npr. »Osveži« (nova različica), »Prijava znova« (oblak zavrača). */
export interface ToastAction { label: string; run: () => void }
export interface Toast { msg: string; kind: 'ok' | 'err' | 'info'; id: number; action?: ToastAction }
/** Ena sprememba načrta za »Spremembe načrta«: auto = aplikacija sama (ne tvoj klik). */
export interface PlanChange { at: string; text: string; auto: boolean }
export interface IcuWorkoutsInfo { at: string; n: number; changed: number; removed: number; err: string | null }
/** Drug račun na isti napravi: prevUid = račun, ki mu pripadajo lokalni podatki. */
export interface AccountClash { prevUid: string; prevEmail?: string }
/** Napaka intervals.icu za prikaz: auth = poveži znova, quota = počakaj (until), network = ni omrežja, other. */
export interface IcuErrState { at: number; kind: IcuErrKind; msg: string; until?: number | null }

/** (v3.52 LENO) izvoženo za ./garminStore (živa vez — vedno trenutno stanje); UI bere prek useApp/getState */
export let state: AppState = {
  ready: false, profile: repo.defaultProfile(), settings: repo.defaultSettings(), activities: [], plan: [], mealsToday: [], recentMeals: [], checkinToday: null, checkins: [], weather: null,
  today: todayIso(), toast: null, toasts: [], migration: null, user: null, authKnown: false, sync: { state: 'off' }, pro: false, routeLib: null, routesBusy: false, icuWorkouts: null, icuDiag: null, firstSync: null, wellness: null,
  accountClash: null, icuErr: null, syncDeleted: null, changes: [], storageError: null,
  cycle: null, garminBusy: false, garminErr: null,
}
const subs = new Set<() => void>()
function emit() { for (const s of subs) s() }
export function set(patch: Partial<AppState>) { state = { ...state, ...patch }; emit() }

export function useApp(): AppState {
  return useSyncExternalStore(cb => { subs.add(cb); return () => subs.delete(cb) }, () => state, () => state)
}
export function getState() { return state }
/** Prvo usklajevanje po prijavi je končano (uspešno ali ne) — nadomestek za nekdanji boolean firstSync. */
export function firstSyncDone(s: Pick<AppState, 'firstSync'> = state): boolean { return s.firstSync != null }
/** Prvo usklajevanje je uspelo (račun ima podatke ali je bil prazen). */
export function firstSyncOk(s: Pick<AppState, 'firstSync'> = state): boolean { return s.firstSync === 'ok' || s.firstSync === 'empty' }

/* ---------- zagon ---------- */
let booted = false
/** (v3.51) vsi enkratni prevzemi (prva različica, predogled, intervals.icu, gorivo) so opravljeni in ključev prve različice ni več */
export async function migrationsDone(): Promise<boolean> {
  for (const k of [KV.migrated, 'repair.icu.v1', 'repair.preview.v1', 'mig.fuelKit.v350']) if (!(await getKV<boolean>(k))) return false
  try {
    for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i) || ''; if (/^(forma_|formai_)/.test(k) || k === 'kalorije_v1' || k === 'kolesarski_trener_v1') return false }
  } catch { /* zasebni način */ }
  return true
}
/**
 * (v3.51) Napaka shrambe → slovensko sporočilo z ukrepom (null = ni napaka shrambe). Prej se pri polni shrambi ni
 * zgodilo nič: list ostane odprt, nobenega sporočila, samo napaka v konzoli.
 */
export function saveFailedMsg(e: unknown): string | null {
  const n = String((e as { name?: unknown } | null)?.name || ''), m = String((e as Error | null)?.message || '')
  if (n === 'QuotaExceededError' || /quota/i.test(m)) return 'Ni prostora na napravi — sprememba ni shranjena. Sprosti prostor ali izvozi kopijo in poskusi znova.'
  // InvalidStateError meče tudi drugo (predvajanje, celozaslonski način) — samo, če gre za bazo
  if ((n === 'InvalidStateError' || n === 'UnknownError') && /database|transaction|object ?store|idb|connection is clos/i.test(m)) return 'Shramba na napravi ne deluje — sprememba ni shranjena. Osveži aplikacijo in poskusi znova.'
  return null
}
let saveFailedAt = 0
/** Obvestilo o napaki shrambe (največ enkrat na 10 s — ena napaka sproži več zavrnitev). Vrne true, če je bila napaka shrambe. */
export function noteSaveFailed(e: unknown, now = Date.now()): boolean {
  const msg = saveFailedMsg(e)
  if (!msg) return false
  if (now - saveFailedAt > 10_000) { saveFailedAt = now; toast(msg, 'err') }
  return true
}
let onlineFlushAt = 0
/** (v3.51) Ob vrnitvi povezave: čakajoče pripombe in odgovori testnega programa (z zamikom 2 s, največ enkrat na minuto). */
export function onlineFlush(now = Date.now(), delay = 2000): void {
  if (now - onlineFlushAt < 60_000) return
  onlineFlushAt = now
  window.setTimeout(() => { void flushPilot().catch(() => undefined); void flushFeedback().catch(() => 0) }, delay)
}
// Samodejni uvozi in izpeljave šele po prvem usklajevanju z oblakom: naprava s staro kopijo najprej
// prevzame podatke drugih naprav, šele nato kaj spreminja (največ 8 s čakanja, npr. brez povezave).
let openGate: () => void = () => undefined
const synced = new Promise<void>(r => { openGate = r })
/** Začetek v3.29 (»?« in pripomba v glavi): kdor je začel pozneje, ju pozna od prvega dne. */
export const HELP_HINT_BEFORE = '2026-10-04'
/** (v3.48) Obvestilo »Novo: »?« zgoraj …« samo uporabnikom, ki so začeli pred v3.29 — nov uporabnik ga ne dobi. */
export function helpHintFor(p: Pick<Profile, 'onboardingDone' | 'createdAt'>): boolean {
  return p.onboardingDone && !!p.createdAt && p.createdAt.slice(0, 10) < HELP_HINT_BEFORE
}
/** (v3.50) Namig »Novo: »?« …« počaka: odprt list (cilj, uvoz) ali zaslon Uvoz/Nastavitve bi ga prekril. */
export function helpHintBlocked(doc: Pick<Document, 'querySelector'>, hash: string): boolean {
  return !!doc.querySelector('.sheet') || /^#\/?(uvoz|nastavitve)/.test(hash)
}
export async function boot() {
  if (booted) return; booted = true
  // pripombe: zadnje napake aplikacije gredo zraven (samo besedilo napake)
  trapErrors()
  // (v3.51) polna ali pokvarjena shramba pri katerem koli dejanju (premor, obrok, kljukica): povej, da ni shranjeno
  window.addEventListener('unhandledrejection', e => noteSaveFailed((e as PromiseRejectionEvent).reason))
  // (v3.51) pripomba in odgovori testnega programa gredo, ko se povezava vrne (prej šele ob naslednjem zagonu)
  window.addEventListener('online', () => onlineFlush())
  // kvota intervals.icu: premor po 429 in dnevna poraba preživita ponovni zagon
  void setIcuQuotaStore({ load: () => getKV<IcuQuota>('icu.quota'), save: q => setKV('icu.quota', q) })
  // izbris računa (tudi z zaslona, ki kliče firebase.deleteAccount neposredno): pred izbrisom ustavi sinhronizacijo
  setAccountDeleteHooks({
    before: () => stopSync(),
    failed: () => { const u = state.user; if (u && !state.accountClash) beginSync(u) },
    pilotId: () => state.settings.pilot?.id ?? null,
  })
  // (v3.51) prevzemi so enkratni: ko so opravljeni, se modul ne naloži (ni v začetnem paketu)
  const M = (await migrationsDone().catch(() => false)) ? null : await import('@/data/migrate').catch(() => null)
  const mig = M ? await M.migrateFromV1().catch(() => null) : null
  const fixed = M ? await M.repairAfterPreview().catch(() => [] as string[]) : []
  const icuCarried = M ? await M.carryIntervalsFromV1().catch(() => false) : false
  // ključi prve različice (Stravine vožnje, API ključi) po uspešnem prevzemu stran — sicer bi ostali za vedno
  if (M) await M.finishLegacyV1().catch(() => 0)
  // (v3.50) prazen komplet goriva iz v3.49 = privzeti komplet (ne »samo voda«)
  if (M) await M.fixEmptyFuelKit().catch(() => false)
  const purged = await repo.purgeExpired().catch(() => 0)
  void pruneKV().catch(() => 0)
  // (v3.49) brskalnik ne dovoli shrambe (SecurityError, zasebni način): razlaga in »Poskusi znova« namesto večnega logotipa
  try { await reloadAll() } catch (e) { set({ ready: true, storageError: storageBlockedMsg(e) }); return }
  tabsListen()
  if (purged) void touch()     // potekle (Strava §6.2) naj izginejo tudi iz oblaka
  set({ ready: true, migration: mig && mig.ran && (mig.activities || mig.meals || mig.plan) ? mig : null })
  // (v3.50) starejši profil brez izhodišča teže: zapiši ga zdaj, da se mejnik ne premika s težo
  if (state.profile.onboardingDone && goalBasePatch(state.profile, state.today)) void updateProfile({})
  // enkrat na napravo: kje je razlaga in kako sporočiš, kaj ni jasno (v3.29); novemu uporabniku »Novo« ne velja (v3.48)
  void getKV<number>('hint.help').then(seen => {
    if (seen || !state.profile.onboardingDone) return
    void setKV('hint.help', 1)
    if (!helpHintFor(state.profile)) return
    // (v3.50) ne čez odprt list (cilj, uvoz) in ne na Uvozu ali v Nastavitvah — počaka, dokler ni prosto (največ ~2 min)
    const hint = (n: number): void => {
      if (n > 40) return
      if (helpHintBlocked(document, location.hash)) { window.setTimeout(() => hint(n + 1), 3000); return }
      toast('Novo: »?« zgoraj razloži, kako aplikacija deluje in kaj pomenijo izrazi; oblaček pošlje pripombo s posnetkom zaslona.', 'info', 9000)
    }
    window.setTimeout(() => hint(0), 2500)
  }).catch(() => undefined)
  window.setTimeout(() => openGate(), 8000)
  // (v3.49) stare kljukice brez ure dobijo zapis iz načrta (po usklajevanju — zapisi druge naprave so že tu)
  // (v3.50) ena veriga: teden se sestavi šele po zapisih iz načrta (prej sta tekmovala — »~4,5 h« v zapisu, »5 h« v Planu)
  const standIns = synced.then(() => ensureStandIns().then(n => { if (n) void touch() }).catch(() => 0))
  void standIns.then(() => deriveFromRides()).then(() => autoMissed())
  if (fixed.length) toast('Počiščeno po preizkusu: ' + fixed.join(', ') + '.', 'info', 6000)
  void refreshWeather(false)
  if (icuCarried) toast('Povezava z intervals.icu je prenesena iz stare aplikacije — vožnje se uvažajo same.', 'info', 7000)
  // testni program: koda povabila iz povezave (?pilot=…) v nastavitve; neposlani odgovori znova
  { const code = capturePilotCode(); if (code && state.settings.pilot?.code !== code) void updateSettings({ pilot: { ...(state.settings.pilot || {}), code } }) }
  void flushPilot()
  // pripombe, ki so čakale (brez povezave ali strežnik še brez poti), po usklajevanju — z žetonom, če si prijavljen
  void synced.then(() => flushFeedback()).catch(() => 0)
  // vrnitev z intervals.icu (»Poveži z intervals.icu«): koda → žeton prek strežnika
  void finishIcuOAuth().then(async r => {
    if (!r) return
    if ('error' in r) { toast(r.error, 'err', 8000); return }
    await updateSettings({ intervals: { athleteId: r.athleteId, apiKey: '', token: r.token, name: r.name || 'intervals.icu', pushWorkouts: false } })
    const ath = await fetchAthlete({ athleteId: r.athleteId, apiKey: '', token: r.token }).catch(() => null)
    if (ath) {
      const p0 = state.profile, patch: Partial<Profile> = {}
      if (ath.ftp && !p0.ftp) patch.ftp = ath.ftp
      if (ath.lthr && !p0.lthr) patch.lthr = ath.lthr
      if (ath.maxHr && !p0.maxHr) patch.maxHr = ath.maxHr
      if (ath.restHr && !p0.restHr) patch.restHr = ath.restHr
      if (Object.keys(patch).length) await updateProfile(patch)
    }
    toast(`Povezano z intervals.icu${r.name ? ` (${r.name})` : ''} — uvažam vožnje …`, 'ok', 6000)
    await setKV('icu.fullDone', false)
    void autoSyncIntervals(true)
  })
  // (v3.52) vrnitev z Garmina (?garmin=ok|err) in prenos z našega strežnika — po prvem usklajevanju (prijava je takrat znana)
  // (LENO) del kode za Garmin se prenese samo, ko je Garmin povezan (tudi šele po usklajevanju) ali ob vrnitvi z Garmina
  void getKV<CycleDay[]>(G_CYCLE).then(c => { if (c?.length && state.settings.garmin?.cycle) set({ cycle: c }) })
  void synced.then(() => { if (!garminInPlay()) return; return finishGarminConnect().then(ok => (ok ? undefined : syncGarmin(false))) }).catch(() => undefined)
  // samodejni uvoz iz intervals.icu: ob zagonu in ob vrnitvi v aplikacijo (največ na 3 ure)
  // enkrat: ponovno preberi leto voženj iz intervals.icu (cone utripa, merilnik moči)
  if (!(await getKV<boolean>('icu.zones.v1'))) { await setKV('icu.fullDone', false); await setKV('icu.autoAt', 0); await setKV('icu.zones.v1', true) }
  void loadRouteLib().then(l => set({ routeLib: l }))
  void getKV<IcuWorkoutsInfo>('icu.workouts').then(i => { if (i) set({ icuWorkouts: i }) })
  void loadGarminWorkoutsInfo()   // (v3.52) zadnje pošiljanje na Garmin
  void getKV<IcuDiag>('icu.diag').then(d => { if (d) set({ icuDiag: d }) })
  void getKV<IcuErrState>('icu.err').then(e => { if (e && typeof e.msg === 'string' && !state.icuErr) set({ icuErr: e }) })
  void combinedWellness().then(w => { if (w?.length) set({ wellness: w }) })   // (v3.52) intervals.icu + Garmin neposredno
  void standIns.then(() => agreementFix().catch(() => false)).then(() => ensureWeeks()).then(() => offMixFix().catch(() => false)).then(() => autoSyncIntervals()).then(() => ensureRoutes()).then(() => autoRoutes()).then(() => schedulePushWorkouts(4000, true))
  // ob vrnitvi v aplikacijo (telefon po vožnji): najprej uskladi z oblakom, nato preveri nove vožnje — največ na 10 min
  // polnoč: osveži »danes« — (v3.49) tudi takoj ob vrnitvi v aplikacijo (prej do minute na včerajšnjem dnevu)
  const dayCheck = () => { const t = todayIso(); if (t !== state.today) { set({ today: t }); void reloadAll().then(() => ensureWeeks()).then(() => autoMissed()) } }
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') { dayCheck(); void syncNow({ quick: true }).then(() => autoSyncIntervals()).then(() => (garminInPlay() ? syncGarmin(false) : null)).then(() => ensureRoutes()).then(() => autoRoutes()).then(() => schedulePushWorkouts(4000, true)) } })
  setInterval(dayCheck, 60_000)
  // račun in sinhronizacija — asinhrono, aplikacija dela tudi brez
  // enako stanje (npr. »usklajeno« → »usklajeno«): samo nova ura, brez ponovnega izrisa zaslona
  onSyncStatus(s => { if (s.state === state.sync.state && (s.msg || '') === (state.sync.msg || '') && s.trimmed === state.sync.trimmed) state = { ...state, sync: s }; else set({ sync: s }); noticeSync(s) })
  // (v3.50) Firebase samo, če je na tej napravi prijava (ali je bila) — brez računa se ob zagonu ne prenaša
  void wantAuth().then(yes => { if (yes) startAuth(); else void onUser(null) })
}

/** (v3.50) Poslušanje prijave (naloži Firebase) — ob zagonu s prijavo ali ob »Prijava z Googlom«. */
let authOn = false
function startAuth(): void { if (authOn) return; authOn = true; onAuth(u => { void onUser(u) }) }
/**
 * (v3.50) Firebase vnaprej, ko se uporabnik pripravlja na prijavo (zaslon Prijava, dotik gumba »Prijava …«): okno za
 * prijavo z Googlom se odpre v istem dotiku (brskalnik sicer pojavno okno po čakanju blokira → preusmeritev).
 */
export function warmAuth(): void { if (!authOn) void core().catch(() => null) }
async function wantAuth(): Promise<boolean> {
  if (authHintSync()) return true
  const owner = !!(await syncOwner().catch(() => null))
  return shouldBootAuth({ hint: false, owner, idb: owner ? true : await idbSession() })
}

/* ---------- (v3.50) opozorila usklajevanja: napaka z ukrepom (prej samo rdeča pika), skrajšana kopija v oblaku ---------- */
const NOTICE_KEY = 'formai.syncNotice'
let noticeMem: NoticeMem | null = null
/** (v3.50) vidna napaka usklajevanja — izgine sama, ko usklajevanje spet dela (prej je ostala z »Prijava znova«) */
let syncErrToast: number | null = null
function noticeSync(s: SyncStatus): void {
  if ((s.state === 'idle' || s.state === 'off') && syncErrToast != null) { dismissToast(syncErrToast); syncErrToast = null }
  if (!noticeMem) { try { const v = JSON.parse(localStorage.getItem(NOTICE_KEY) || '{}'); noticeMem = { ...NOTICE_EMPTY, errDay: typeof v.errDay === 'string' ? v.errDay : null, trimKey: typeof v.trimKey === 'string' ? v.trimKey : null } } catch { noticeMem = NOTICE_EMPTY } }
  const r = syncNotice(s, noticeMem, Date.now(), todayIso(), typeof navigator === 'undefined' || navigator.onLine !== false)
  if (r.mem !== noticeMem) { noticeMem = r.mem; try { localStorage.setItem(NOTICE_KEY, JSON.stringify({ errDay: r.mem.errDay, trimKey: r.mem.trimKey })) } catch { /* zasebni način */ } }
  if (r.err) syncErrToast = toast(r.err.msg, 'err', 9000, r.err.denied ? { label: 'Prijava znova', run: () => void signIn().catch(e => toast((e as Error).message, 'err')) } : { label: 'Podrobnosti', run: () => { location.hash = '#/nastavitve?sec=n-racun' } })
  if (r.trim) toast(r.trim, 'info', 10_000, { label: 'Podatki', run: () => { location.hash = '#/nastavitve?sec=n-podatki' } })
}

/* ---------- račun in sinhronizacija ---------- */
let authSeq = 0
/** Prijava/odjava: podatki na napravi pripadajo enemu računu — drug račun se ne združi brez odločitve (accountClash). */
async function onUser(u: AuthUser | null): Promise<void> {
  const seq = ++authSeq
  set({ user: u, authKnown: true })
  if (!u) { stopSync(); set({ pro: false, firstSync: null, accountClash: null }); openGate(); return }
  markAuth()
  const owner = await syncOwner().catch(() => null)
  if (seq !== authSeq) return
  if (owner && owner.uid !== u.uid) {
    stopSync()
    set({ accountClash: clashOf(owner), firstSync: null })
    openGate()
    return
  }
  set({ accountClash: null, syncDeleted: null })
  beginSync(u)
  void checkPro()
}
const clashOf = (o: { uid: string; email: string | null } | null): AccountClash => ({ prevUid: o?.uid || '', ...(o?.email ? { prevEmail: o.email } : {}) })

function beginSync(u: AuthUser): void {
  set({ firstSync: null })
  startSync(u.uid, () => { void reloadAll() }, r => { openGate(); void reloadAll().then(() => set({ firstSync: r })) }, {
    email: u.email,
    onDeleted: () => { void onCloudDeleted() },
    onClash: () => { void syncOwner().then(o => set({ accountClash: clashOf(o), firstSync: null })) },
  })
}

/** Dokument v oblaku je izbrisan na drugi napravi: sinhronizacija je ustavljena, odjava; podatki na napravi ostanejo. */
async function onCloudDeleted(): Promise<void> {
  await forgetRemote().catch(() => undefined)
  set({ syncDeleted: { at: Date.now() }, firstSync: null })
  await signOutNow()
  set({ user: null, pro: false })
  toast('Račun je bil izbrisan na drugi napravi — odjavljen si. Podatki na tej napravi ostanejo, dokler jih ne izbrišeš.', 'info', 10000)
}

export async function reloadAll() {
  const today = todayIso()
  const ws = weekStartIso(today)
  const [profile, settings, activities, plan, mealsToday, recentMeals, checkinToday, checkins, changes] = await Promise.all([
    repo.loadProfile(), repo.loadSettings(), repo.allActivities(), repo.planBetween(addDays(ws, -14), addDays(ws, 20)), repo.mealsOn(today),
    repo.mealsBetween(addDays(today, -90), today), repo.getCheckin(today), repo.allCheckins(), getKV<PlanChange[]>(CHANGES_KEY).catch(() => null),
  ])
  set({ profile, settings, activities, plan, mealsToday, recentMeals, checkinToday: checkinToday || null, checkins, today, changes: Array.isArray(changes) ? changes : [] })
  // (v3.49) vožnja z ure in zapis iz načrta za isti dan (z dveh naprav): zapis iz načrta odpade
  if (activities.some(isStandIn) && await dropStandIns()) void touch()
}

/* ---------- spremembe načrta (uporabnik 4. 10.: »težko razumeti, kaj in kako se dogaja«) ---------- */
const CHANGES_KEY = 'plan.changes'
/**
 * Zapiši spremembo načrta (poleg obvestila, ki po nekaj sekundah izgine): Plan → Spremembe načrta. Zadnjih 40;
 * isto besedilo v isti minuti se ne podvoji.
 */
export async function logChange(text: string, auto = true): Promise<void> {
  const t = text.replace(/\s+/g, ' ').trim().slice(0, 320)
  if (!t) return
  const at = new Date().toISOString()
  const list = [{ at, text: t, auto }, ...state.changes.filter(x => !(x.text === t && Date.parse(at) - Date.parse(x.at) < 60_000))].slice(0, 40)
  set({ changes: list })
  await setKV(CHANGES_KEY, list).catch(() => undefined)
}

/**
 * Obnovitev iz varnostne kopije: združi z napravo (nič se ne izbriše), osveži stanje, pošlje v oblak (če si prijavljen)
 * in dopolni tedna načrta. fromBackup: profil in nastavitve iz kopije (nova naprava).
 */
export async function restoreFromBackup(b: ParsedBackup, opts: { fromBackup?: boolean } = {}) {
  const r = await restoreBackup(b, opts)
  await reloadAll()
  if (state.settings.accentHex) applyAccent(state.settings.accentHex)
  // (v3.49) kopija iz starejše različice: opravljeni dnevi brez ure dobijo zapis iz načrta
  if ((await ensureStandIns().catch(() => 0)) || r.changed) void touch()
  if (state.profile.onboardingDone) await ensureWeeks().catch(() => 0)
  return r
}
/**
 * »Bolan sem«: počitek za `days` dni od danes. Treningi v tem obdobju postanejo počitek (shranjeni v dnevu), prehrana
 * je brez deficita; na uro gre spremenjeni teden sam. Razveljavi v obvestilu.
 */
export async function setSick(days: number): Promise<void> {
  const prev = state.profile.sick ?? null
  const period = { ...sickPeriod(state.today, days), at: new Date().toISOString() }
  await updateProfile({ sick: period })
  const out = sickify(state.plan, period, new Date().toISOString())
  if (out.length) await savePlanDays(out)
  void logChange(`Bolan: počitek do vključno ${dayGen(period.to)} — treningi v tem času so počitek, prehrana brez deficita.`, false)
  undoToast(`Počitek do vključno ${dayGen(period.to)} — treningi so shranjeni, prehrana brez deficita. Hitro ozdravi.`, async () => {
    const back = unsickify(state.plan, period.from, new Date().toISOString())
    if (back.length) await savePlanDays(back)
    await updateProfile({ sick: prev })
    await repause(new Set(back.map(d => d.date)), period.at)
  }, { ms: 8000 })
}
/** Bolezen traja dlje: še en dan počitka (obdobje ostane od istega začetka). */
export async function extendSick(): Promise<void> {
  const s = state.profile.sick
  if (!s || s.to < state.today) return
  const period = { ...s, to: addDays(s.to, 1) }
  await updateProfile({ sick: period })
  const out = sickify(state.plan, period, new Date().toISOString())
  if (out.length) await savePlanDays(out)
  toast(`Počitek do vključno ${dayGen(period.to)}.`, 'ok')
}
/** »Spet zdrav«: od danes naprej vrne shranjene treninge; obdobje bolezni se konča včeraj (prehrana spet po načrtu). */
export async function endSick(): Promise<void> {
  const s = state.profile.sick
  if (!s) return
  // (v3.50) po 3+ dneh bolezni prva dva dneva nazaj lahko
  const back = unsickify(state.plan, state.today, new Date().toISOString(), s.from)
  if (back.length) await savePlanDays(back)
  await updateProfile({ sick: s.from >= state.today ? null : { ...s, to: addDays(state.today, -1) } })
  // (v3.50) vrnjeni treningi ne prekrijejo premora »Ta teden …«
  await repause(new Set(back.map(d => d.date)), s.at)
  if (back.length) void logChange('Spet zdrav: treningi od danes so vrnjeni po načrtu.', false)
  toast(back.length ? 'Dobrodošel nazaj. Treningi so vrnjeni — prve dni vozi lažje, če se ne počutiš povsem dobro.' : 'Dobrodošel nazaj.', 'ok', 7000)
}
/* ---------- (v3.50) »Ta teden …«: premor do nedelje — brez treningov ali brez kolesa ---------- */
/**
 * Premor od danes do nedelje (twoWeeks: še naslednji teden, največ 14 dni): neopravljeni treningi v tem času odpadejo
 * (brez kolesa: vožnje in testi, moč, tek in hoja ostanejo), na uro gre spremenjeni teden sam. Shrani se v profil
 * (sinhronizacija), zato ga »Sestavi znova«, nov teden in samodejni premiki ne vrnejo. »Razveljavi« vrne prejšnje dni.
 */
export async function setWeekPause(mode: PauseMode, o: { twoWeeks?: boolean; reason?: PauseReason | null } = {}): Promise<WeekPause> {
  const prevPause = state.profile.weekPause ?? null
  const now = new Date().toISOString()
  // premor, ki velja ali se je končal včeraj, se nadaljuje: začetek ostane prvotni (dolžina šteje za prehod po njem), skupaj
  // največ 14 dni; sprememba veljavnega (brez kolesa → brez treningov, še naslednji teden …) sestavi preostale dni znova
  const keep = prevPause && prevPause.from <= state.today && prevPause.to >= addDays(state.today, -1) ? prevPause : null
  const act = keep && keep.to >= state.today ? keep : null
  const w: WeekPause = { ...pausePeriod(state.today, mode, o), at: now }
  if (keep) {
    w.from = keep.from
    // (v3.51) čez 14 dni od začetka: nov del od danes (prvi del ostane v `since` za ure in prehod) — prej je »Še naslednji
    // teden« tiho skrajšal na 14. dan (list je obljubil »do nedelje, 1. 11.«, shranilo se je 27. 10.)
    if (w.to > addDays(w.from, PAUSE_MAX_DAYS - 1)) { w.from = state.today; w.since = pauseStart(keep) }
    else if (keep.since) w.since = keep.since
  }
  // (v3.50) teden po premoru, ki je že sestavljen (ensureWeeks sestavi tudi naslednji teden), se sestavi znova — dobi prehod
  // po premoru (ure kot pred premorom, po 8+ dneh prva dva dneva lahko); prej je ostal tak kot pred premorom
  const prof = { ...state.profile, weekPause: w }
  const tail = afterPauseEnd(w)
  const out = act
    ? pauseRebuild(prof, [w.to, act.to, tail, afterPauseEnd(act)].filter((x): x is string => !!x).sort().pop()!)
    : [...pauseify(state.plan, w, state.today, now), ...(tail ? pauseRebuild(prof, tail, state.profile, addDays(w.to, 1)) : [])]
  const dates = new Set(out.map(d => d.date))
  const prev = state.plan.filter(d => dates.has(d.date) && !d.done)
  await updateProfile({ weekPause: w })
  if (out.length) await savePlanDays(out)
  const line = pauseLine(w, state.today)
  void logChange(`${line} — ${mode === 'kolo' ? 'vožnje so umaknjene, moč, tek in hoja ostanejo' : 'treningi so umaknjeni'}.${tail ? ' Teden po premoru je sestavljen znova — brez skoka na poln obseg.' : ''}`, false)
  // (v3.50) brez dvojne pike za datumom (»do nedelje, 1. 11..«)
  undoToast(`${line.replace(/\.$/, '')}. ${mode === 'kolo' ? 'Vožnje so umaknjene' : 'Treningi so umaknjeni'} — tudi z ure.`, async () => {
    await updateProfile({ weekPause: prevPause })
    if (dates.size) await restorePlanDays(prev, dates)
    toast(UNDO_PAUSE_DONE, 'ok')   // (v3.51) potrditev (prej obvestilo samo izginilo)
  }, { ms: 8000 })
  return w
}
/** (v3.51) potrditev po »Razveljavi« premora */
export const UNDO_PAUSE_DONE = 'Premor razveljavljen — treningi so spet v načrtu, tudi na uri.'
/**
 * (v3.50) Po vrnitvi treningov (»Spet zdrav«, razveljavitev bolezni) velja premor, ki še teče.
 * (v3.51) Samo na vrnjenih dneh (`dates`) — prej je pobrisal tudi trening, ki si ga med premorom dodal na drug dan. Če je bil
 * premor nastavljen pred boleznijo, so vrnjeni dnevi že taki, kot so bili v premoru (tudi tvoj dodan trening) — ni česa umakniti.
 */
async function repause(dates: ReadonlySet<string>, sickAt?: string | null): Promise<void> {
  const w = activePause(state.profile, state.today)
  if (!w || !dates.size || (w.at && sickAt && w.at < sickAt)) return
  const out = pauseify(state.plan.filter(d => dates.has(d.date)), w, state.today, new Date().toISOString())
  if (out.length) await savePlanDays(out)
}
/**
 * (v3.51) EN mehanizem za vsako ponovno sestavo (»sestavi znova«, tekme, cilj, moč, dnevi, off-season, premor): treningi, ki
 * si jih dodal sam (»Dodaj trening«, s slike, jedro po želji), ostanejo — prej so ostali samo ob spremembi premora.
 * `built` = na novo sestavljeni dnevi, `old` = profil, s katerim so bili sestavljeni shranjeni dnevi (pred spremembo).
 * Prepozna jih ownDay; referenca so ključi, ki bi jih planer sestavil s starim ali novim profilom (ti niso tvoji).
 */
export function keepOwn(built: readonly PlanDay[], old: Profile = state.profile, prof: Profile = state.profile): PlanDay[] {
  const dates = new Set(built.map(d => d.date))
  const cand = state.plan.filter(d => dates.has(d.date) && !d.done)
  if (!cand.length) return [...built]
  const ref = new Set(built.map(planKey))
  const done = state.plan.filter(d => d.done).map(d => ({ date: d.date, kind: d.kind }))
  for (const ws of new Set([...dates].map(weekStartIso))) {
    for (const p of old === prof ? [old] : [old, prof]) {
      for (const nb of new Set([ws, ws < state.today ? state.today : ws])) {
        for (const d of buildWeek({ profile: p, activities: state.activities, weekStart: ws, notBefore: nb, checkins: state.checkins, done, today: state.today })) ref.add(planKey(d))
      }
    }
  }
  return withOwn(built, cand.filter(d => ownDay(d, old, ref)))
}
/** (v3.50) Nedelja tedna po premoru, če je ta teden že v shrambi (sicer null — sestavi ga ensureWeeks, že s premorom). */
function afterPauseEnd(w: Pick<WeekPause, 'to'>): string | null {
  const ws = weekStartIso(addDays(w.to, 1)), end = addDays(ws, 6)
  return state.plan.some(d => d.date >= ws && d.date <= end) ? end : null
}
/**
 * Dnevi od `from0` (privzeto danes; od jutri, če je danes že opravljeno) do `to`, sestavljeni znova s profilom `prof`
 * (opravljeni ostanejo). (v3.50) Treningi, ki jih je uporabnik dodal sam (»Dodaj trening«, s slike, jedro po želji), ostanejo
 * — prepozna jih ownDay glede na profil pred spremembo `old` (prej jih je preklic ali sprememba premora pobrisala).
 */
function pauseRebuild(prof: Profile, to: string, old: Profile = state.profile, from0?: string): PlanDay[] {
  const rain: Record<string, number> = {}
  if (state.weather) for (const k in state.weather) rain[k] = state.weather[k]!.rain
  const doneDates = new Set(state.plan.filter(d => d.done).map(d => d.date))
  const from = from0 ?? (doneDates.has(state.today) ? addDays(state.today, 1) : state.today)
  const done = state.plan.filter(d => d.done).map(d => ({ date: d.date, kind: d.kind }))
  const out: PlanDay[] = []
  for (let ws = weekStartIso(from); ws <= to; ws = addDays(ws, 7)) {
    const inp = { activities: state.activities, weekStart: ws, rain, notBefore: from > ws ? from : ws, checkins: state.checkins, done }
    const keep = (d: PlanDay) => d.date >= from && d.date <= to && d.date >= ws && d.date <= addDays(ws, 6) && !doneDates.has(d.date)
    const built = buildWeek({ ...inp, profile: prof }).filter(keep)
    const ref = new Set(buildWeek({ ...inp, profile: old }).map(planKey))
    out.push(...withOwn(built, state.plan.filter(d => keep(d) && ownDay(d, old, ref))))
  }
  return out
}
/**
 * »Prekliči premor«: velja do včeraj (tedni premora ne štejejo kot dolg premor), preostali dnevi do konca premora se
 * sestavijo znova po načrtu (opravljeni ostanejo). »Razveljavi« premor vrne.
 */
export async function endWeekPause(): Promise<void> {
  const w = state.profile.weekPause
  if (!w || w.to < state.today) return
  const old = state.profile
  // (v3.50) tudi teden po premoru (če je že sestavljen s prehodom po premoru) — premor se je končal prej
  const tail = afterPauseEnd(w)
  // (v3.51) premor, podaljšan danes (nov del od danes): prvi del ostane do včeraj
  const start = pauseStart(w)
  const prof = await updateProfile({ weekPause: start >= state.today ? null : { ...w, from: w.from >= state.today ? start : w.from, to: addDays(state.today, -1) } })
  const out = pauseRebuild(prof, tail && tail > w.to ? tail : w.to, old)
  const dates = new Set(out.map(d => d.date))
  const prev = state.plan.filter(d => dates.has(d.date) && !d.done)
  if (out.length) await savePlanDays(out)
  void logChange('Premor je preklican — preostali dnevi so spet po načrtu.', false)
  // (v3.50) »Razveljavi« vrne prejšnje dni (tudi treninge, ki si jih dodal sam) — prej znova premor čez vse
  undoToast('Premor je preklican — treningi so spet v načrtu.', async () => {
    await updateProfile({ weekPause: w })
    if (dates.size) await restorePlanDays(prev, dates)
    toast('Premor spet velja — treningi so umaknjeni, tudi z ure.', 'ok')   // (v3.51) potrditev
  }, { ms: 8000 })
}
/** Zadnji izvoz na tej napravi (opomnik za varnostno kopijo, ko ni prijave). */
export const LAST_EXPORT_KEY = 'backup.lastExportAt'
export async function markExported(): Promise<void> { await setKV(LAST_EXPORT_KEY, new Date().toISOString()) }

/* ---------- samodejni uvoz iz intervals.icu ---------- */
let icuBusy = false
/** Napaka intervals.icu → stanje za prikaz (odjava, kvota, omrežje, drugo). */
function icuErrOf(e: unknown): IcuErrState {
  const kind = icuErrorKind(e)
  const until = e instanceof IcuError && e.until ? e.until : null
  const raw = (e as Error)?.message || ''
  const msg = kind === 'auth' ? 'intervals.icu zavrača dostop — poveži znova.'
    : kind === 'network' ? (raw || 'intervals.icu ni dosegljiv — preveri povezavo.')
    : raw || (kind === 'quota' ? 'intervals.icu: preveč zahtevkov — poskusim znova kasneje.' : 'Uvoz iz intervals.icu ni uspel.')
  return { at: Date.now(), kind, msg, ...(until ? { until } : {}) }
}
/** Zadnja napaka intervals.icu (null = vse v redu); shrani se na napravi, da jo UI pokaže tudi po ponovnem zagonu. */
async function setIcuErr(e: IcuErrState | null): Promise<void> {
  if (stableStr(e) === stableStr(state.icuErr)) return
  set({ icuErr: e })
  await setKV('icu.err', e).catch(() => undefined)
}

interface IcuRun { added: number; error: IcuErrState | null; skipped: string | null }
/**
 * Uvoz iz intervals.icu (samodejni in ročni). Isti zaklep kot ročni uvoz datotek (dvojnikov ni), izbrisane vožnje
 * se ne vrnejo (grob), napaka se razvrsti (odjava, kvota, omrežje) v state.icuErr — nikoli tiho.
 */
async function runIcuImport(force: boolean): Promise<IcuRun> {
  const c = state.settings.intervals
  if (!icuReady(c)) return { added: 0, error: null, skipped: 'Povezava z intervals.icu ni nastavljena.' }
  if (icuBusy) return { added: 0, error: null, skipped: 'Uvoz iz intervals.icu že teče.' }
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return { added: 0, error: null, skipped: 'Ni povezave z internetom.' }
  const last = (await getKV<number>('icu.autoAt')) || 0
  if (!force && Date.now() - last < 10 * 60_000) return { added: 0, error: null, skipped: 'Pravkar preverjeno.' }
  // samodejno preverjanje v ozadju ne porabi več kot dnevni proračun te naprave (ročno »Preveri Garmin« gre vedno)
  if (!force && icuBudget(c).left <= 0) return { added: 0, error: null, skipped: 'Današnja kvota intervals.icu je porabljena — preverim jutri ali ročno.' }
  icuBusy = true
  let added = 0, error: IcuErrState | null = null
  let freshDates: string[] = []
  try {
    await setKV('icu.autoAt', Date.now())
    await repo.withImportLock(async () => {
      const full = !(await getKV<boolean>('icu.fullDone'))
      const today = todayIso()
      // (v3.50) okno od zadnjega uspešnega uvoza (po premoru več kot 3 tedne), ne vedno 21 dni
      const days = full ? 365 : importWindowDays(await getKV<string>('icu.okDay'), today)
      const r = await fetchActivities(c, addDays(today, -days), addDays(today, 1))
      for (const a of r.activities) if (!a.tss) a.tss = estimateTss(a, state.profile)
      await setIcuDiag({ at: new Date().toISOString(), days, total: r.total, usable: r.activities.length, stravaStubs: r.stravaStubs, known: state.activities.filter(a => a.source === 'intervals').length, short: r.skippedShort })
      if (!full && days > 60) toast(`Dolgo te ni bilo — uvažam vadbe zadnjih ${Math.round(days / 7)} tednov.`, 'info', 6000)
      // sledi ne shranjujemo pri vožnjah — trase gradi knjižnica tras (ensureRoutes), samo na tej napravi
      const before = new Set(state.activities.map(a => a.id))
      // vožnja, ki si jo izbrisal (na tej ali drugi napravi), se ne uvozi znova
      const tomb = await repo.getTomb()
      const cands = r.activities.filter(a => !tomb[tombAct(a)])
      // (v3.49) vožnja z ure zamenja zapis iz načrta istega dne in športa (pred primerjavo dvojnikov — ni »dvojnik«)
      await dropStandIns(cands)
      const res = await repo.addActivities(cands)
      added = res.added
      if (full) await setKV('icu.fullDone', true)
      await setKV('icu.okDay', today)
      if (res.added || res.upgraded) {
        const all = await repo.allActivities()
        set({ activities: all }); void touch()
        const fresh = all.filter(a => !before.has(a.id))
        await linkToPlan(fresh)
        freshDates = fresh.map(a => a.date)
        // današnja vožnja: koliko je res porabila proti načrtu → dnevni cilj se je že prilagodil; vprašaj za gorivo
        const ride = fresh.find(a => a.date === state.today && a.sport === 'kolo')
        const t = ride ? dailyTarget(state.profile, state.activities.filter(a => a.date === state.today), state.plan.filter(d => d.date === state.today), state.today) : null
        if (ride && t && adaptAfterLoad(state.profile, state.plan, state.activities, state.today, state.today)?.state !== 'predlog') {
          const f = (n: number) => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '\u202F'), k = activityKcal(ride, state.profile), d = t.plannedWas ? t.burn - t.plannedWas : 0
          toast(`Vožnja z Garmina: ${f(k)} kcal${t.plannedWas && Math.abs(d) >= 50 ? ` (načrt ${f(t.plannedWas)}, ${d > 0 ? '+' : '−'}${f(Math.abs(d))})` : ''} → današnji cilj ${f(t.kcal)} kcal. Na Danes vpiši, kaj si popil in pojedel na kolesu.`, 'info', 10000)
        } else if (res.added) toast(`intervals.icu: ${res.added}${NBSP}${plural(res.added, ['nova vožnja', 'novi vožnji', 'nove vožnje', 'novih voženj'])}.`, 'info', 5000)
      }
    })
    await setIcuErr(null)
    await autoAdapt(freshDates)
    if (state.settings.wellnessOn) await refreshWellness(false)
    // pražni in max utrip iz intervals.icu, če jih še nimamo (največ enkrat na dan)
    const p0 = state.profile
    if ((!p0.lthr || !p0.maxHr) && Date.now() - ((await getKV<number>('icu.athleteAt')) || 0) > 86400_000) {
      await setKV('icu.athleteAt', Date.now())
      const ath = await fetchAthlete(c).catch(() => null)
      if (ath) {
        const patch: Partial<Profile> = {}
        if (ath.lthr && !p0.lthr) patch.lthr = ath.lthr
        if (ath.maxHr && !p0.maxHr) patch.maxHr = ath.maxHr
        if (ath.restHr && !p0.restHr) patch.restHr = ath.restHr
        if (Object.keys(patch).length) await updateProfile(patch)
      }
    }
  } catch (e) {
    error = icuErrOf(e)
    await setIcuErr(error)
  } finally { icuBusy = false }
  await deriveFromRides()
  return { added, error, skipped: null }
}

/**
 * Nove vožnje iz intervals.icu brez klikanja: ob odprtju aplikacije, največ na 10 min (force: takoj).
 * Prvič leto nazaj (zgodovina za formo in napredek), nato zadnje 3 tedne.
 * Vrne število novih; null, ko uvoz ni tekel ALI ni uspel (napaka je v state.icuErr — ni »nove vožnje še ni«).
 */
export async function autoSyncIntervals(force = false): Promise<number | null> {
  const r = await runIcuImport(force)
  await autoMissed()
  return r.skipped || r.error ? null : r.added
}

/**
 * Ključni trening, ki je mimo in ni bil narejen (ali je bila namesto njega lahka vožnja): sam gre na naslednji lahek dan
 * tega tedna (nikoli ob drug trd dan ali tekmo), sicer ta teden odpade. Enkrat na sejo (oznaka missed), z obvestilom.
 * Teče po uvozu z ure (da včerajšnja vožnja že pride) in ob zagonu.
 * (v3.49) Včerajšnji trening brez kljukice počaka: Danes najprej vpraša »si ga naredil?« — prestavi se po »Ne«
 * (`answered` = ta dan) ali naslednji dan; prej je ob zagonu izginil izpod vprašanja (brez ure ravno ključni).
 */
let missedBusy = false
export async function autoMissed(answered?: string): Promise<void> {
  if (missedBusy || !state.ready || !state.profile.onboardingDone) return
  missedBusy = true
  try {
    // eno sejo naenkrat — po vsaki shranitvi znova (prestavljena seja zasede lahek dan, ki ga naslednja ne sme dobiti)
    const skipped: string[] = []
    let moved: { text: string; src: PlanDay; to: PlanDay } | null = null
    const ask = yesterdayUnmarked(state)
    // (v3.50) »Ne« je že odgovor (tudi iz Prehrane, »Si ga opravil?«) — ne čakaj na vprašanje na Danes
    const wait = ask && ask.id !== answered && !saidNo(ask.id) ? ask.id : null
    for (let guard = 0; guard < 7; guard++) {
      // (v3.50) ne na dan premora »Ta teden …«
      const m = missedKeys(state.plan, state.activities, state.today, pauseLock(raceLock(state.plan, state.profile), state.profile)).find(x => x.day.id !== wait)
      if (!m) break
      await updatePlanDays(applyMissed(m))
      if (m.to) moved = { text: m.text, src: m.day, to: m.to }
      else skipped.push(m.text)
    }
    // eno obvestilo: prestavitev z »Razveljavi« (izpuščene v isti vrstici), sicer samo izpuščene
    for (const t of [...(moved ? [moved.text] : []), ...skipped]) void logChange(t)
    if (moved) {
      const { src } = moved
      undoToast([moved.text, ...skipped.map(t => t.replace(/ — ta teden ga ni kam prestaviti.*$/, ' — izpuščen.'))].join(' '), () => undoMissed(src.id), { ms: 10000 })
    } else if (skipped.length) toast(skipped.join(' '), 'info', 9000)
  } finally { missedBusy = false }
}
/** Dnevi, ki so dobili vsebino prestavljenega treninga `src` in še niso opravljeni — nazaj na svojo prejšnjo vsebino. */
const movedBack = (src: PlanDay, now: string): PlanDay[] =>
  state.plan.filter(d => d.adapt?.after === src.date && d.adapt.prev && !d.adapt.off && !d.done).map(d => ({ ...d, ...d.adapt!.prev!, updatedAt: now, adapt: { after: src.date, off: true } }))
/** Razveljavi samodejno prestavitev zamujenega ključnega treninga: ciljni dan dobi nazaj svojo vsebino, zamujeni ostane izpuščen. */
export async function undoMissed(srcId: string): Promise<void> {
  const s0 = state.plan.find(d => d.id === srcId)
  if (!s0) return
  const now = new Date().toISOString()
  const back = movedBack(s0, now)
  await updatePlanDays([...back, { ...s0, missed: 'skipped' as const, updatedAt: now }])
  const to = back[0]
  void logChange(to ? `Razveljavil si prestavitev: ${s0.title} ostane izpuščen, ${dayAccOf(to.date)} je spet po načrtu.` : `${s0.title} ostane izpuščen.`, false)
  toast(to ? `${s0.title} ostane izpuščen — ${dayAccOf(to.date)} je spet po načrtu.` : `${s0.title} ostane izpuščen.`, 'ok')
}
/** »5. 10.« za spremembe načrta */
const dshortOf = (iso: string) => `${+iso.slice(8, 10)}. ${+iso.slice(5, 7)}.`
const dayAccOf = (iso: string) => ['nedelja', 'ponedeljek', 'torek', 'sreda', 'četrtek', 'petek', 'sobota'][new Date(iso + 'T12:00:00Z').getUTCDay()] ?? ''

/**
 * Ročno »Preveri Garmin« / »Uvozi nove«: { added } ali { added, error, kind } — ob napaki pove, kaj je narobe
 * (npr. »intervals.icu zavrača dostop — poveži znova« namesto »Nove vožnje še ni«).
 */
export async function syncIntervals(): Promise<{ added: number; error?: string; kind?: IcuErrKind | 'skipped' }> {
  const r = await runIcuImport(true)
  if (r.error) return { added: r.added, error: r.error.msg, kind: r.error.kind }
  if (r.skipped) return { added: 0, error: r.skipped, kind: 'skipped' }
  return { added: r.added }
}

/* ---------- spanec, HRV, mirovni utrip (intervals.icu) ---------- */
const WELL_KEY = 'wellness.v1'
let wellBusy = false
/** Zadnjih 35 dni (28 za tvoje običajno + teden) — samo ob vklopu, največ na 30 min, samo na tej napravi. */
export async function refreshWellness(force = true): Promise<number | null> {
  const c = state.settings.intervals
  if (!icuReady(c) || !state.settings.wellnessOn || wellBusy) return null
  const prev = await getKV<{ at: number; days: WellnessDay[] }>(WELL_KEY)
  if (!force && prev && Date.now() - prev.at < 30 * 60_000) return prev.days.length
  wellBusy = true
  try {
    const days = await fetchWellness(c, addDays(state.today, -35), state.today)
    await setKV(WELL_KEY, { at: Date.now(), days })
    set({ wellness: await combinedWellness(days) })   // (v3.52) + dnevi z Garmina neposredno
    return days.length
  } catch (e) {
    if (icuErrorKind(e) === 'auth') await setIcuErr(icuErrOf(e))
    if (force) toast((e as Error).message, 'err')
    return null
  }
  finally { wellBusy = false }
}
/** Vklop/izklop: ob izklopu se podatki z ure takoj izbrišejo s te naprave. */
export async function setWellnessOn(on: boolean): Promise<void> {
  await updateSettings({ wellnessOn: on })
  if (on) { const n = await refreshWellness(true); if (n != null) toast(n ? `Spanec, HRV in utrip: ${n} dni z ure.` : 'intervals.icu še nima spanca ali HRV — v Garmin Connect preveri, da se »Wellness« deli z intervals.icu.', n ? 'ok' : 'info', 8000) }
  else { await setKV(WELL_KEY, null); set({ wellness: await combinedWellness(null) }) }   // (v3.52) dnevi z Garmina neposredno ostanejo
}

/** Zadnji izid uvoza (za pojasnilo v Uvozu in na Danes), hrani se na napravi. */
export async function setIcuDiag(d: IcuDiag): Promise<void> {
  await setKV('icu.diag', d); set({ icuDiag: d })
}

/**
 * Kar trener razbere iz tvojih voženj in vpiše v načrt:
 *  - merilnik moči (da/ne) → cilji v vatih ali utripu,
 *  - dejanske ure na teden ob začetku načrta → načrt raste od tu +10 % na teden (sestavi ta in naslednji teden znova).
 */
export async function deriveFromRides(): Promise<void> {
  const p = state.profile, today = state.today
  // samo vožnje, ki smejo v AI: izpeljanke v profilu (merilnik moči, ure) gredo v AI poziv — Strava ne sme niti posredno
  // (v3.49) zapisi iz načrta niso vožnje — ure iz njih bi bile ure načrta (krog), merilnika moči nimajo
  const acts = state.activities.filter(a => aiAllowed(a) && !isStandIn(a))
  try {
    if (p.gear.powerMeterAuto !== false || p.gear.powerMeter == null) {
      const pm = powerMeterFrom(acts, today)
      if (pm != null && pm !== p.gear.powerMeter) await updateProfile({ gear: { ...p.gear, powerMeter: pm, powerMeterAuto: true } })
    }
    // »največji napredek«: ko tvoje vožnje pokažejo, da zmoreš več, se ure normalnega tedna dvignejo same (nikoli same ne padejo)
    const pm = state.profile
    if (pm.hoursMode === 'max' && pm.event?.date) {
      const adv = hoursAdvice(acts, pm, today)
      if (pm.hoursPerWeek != null && adv.max >= pm.hoursPerWeek + 0.5) {
        await updateProfile({ hoursPerWeek: adv.max })
        void logChange(`Več ur: tvoje vožnje kažejo, da zmoreš več — normalen teden ${String(pm.hoursPerWeek).replace('.', ',')} → ${String(adv.max).replace('.', ',')} h (od naslednjega tedna).`)
        toast(`Največji napredek: tvoje vožnje kažejo, da zmoreš več — normalen teden ${String(pm.hoursPerWeek).replace('.', ',')} → ${String(adv.max).replace('.', ',')} h (od naslednjega tedna).`, 'info', 9000)
      }
    }
    const p2 = state.profile
    if (p2.event?.date && p2.baseHours == null) {
      const base = baselineHours(acts, today)
      if (base != null) {
        const prof = await updateProfile({ baseHours: base })
        await rebuildFromToday(prof, { old: p2 })
        const first = weekContext(prof, weekStartIso(today)).hours
        void logChange(`Načrt po tvojem dejanskem volumnu: zadnjih 8 tednov ${String(base).replace('.', ',')} h na teden → ta teden ${String(first).replace('.', ',')} h, nato +10 % na teden.`)
        toast(`Načrt prilagojen tvojemu dejanskemu volumnu: zadnjih 8 tednov ${String(base).replace('.', ',')} h na teden → ta teden ${String(first).replace('.', ',')} h, nato +10 % na teden.`, 'info', 9000)
      }
    }
  } catch { /* tiho */ }
}

/**
 * Načrt se nikoli ne izteče: ko se začne nov teden in naslednji še ni sestavljen (uvod sestavi samo dva tedna),
 * ga sestavi sam — tudi tekoči teden, če je prazen (prvi zagon po dolgem premoru). Obstoječih dni ne spreminja.
 * Teče ob zagonu (po usklajevanju) in ob polnoči, zato Danes nikoli ne pokaže »Ta teden še ni sestavljen«, ko je cilj znan.
 */
export async function ensureWeeks(): Promise<number> {
  const p = state.profile
  if (!p.onboardingDone || !(p.cycleStart || p.event)) return 0
  const ws = weekStartIso(state.today)
  const rain: Record<string, number> = {}
  if (state.weather) for (const k in state.weather) rain[k] = state.weather[k]!.rain
  const has = (start: string) => state.plan.some(d => d.date >= start && d.date <= addDays(start, 6))
  const out: PlanDay[] = []
  // (v3.49) opravljeni dnevi (tudi »Opravil« brez ure): načrt ve, v katerih tednih si vadil (tek in hoja, rast tedna)
  const done = state.plan.filter(d => d.done).map(d => ({ date: d.date, kind: d.kind }))
  if (!has(ws)) out.push(...buildWeek({ profile: p, activities: state.activities, weekStart: ws, rain, notBefore: state.today, checkins: state.checkins, done }).filter(d => d.date >= state.today))
  if (!has(addDays(ws, 7))) out.push(...buildWeek({ profile: p, activities: state.activities, weekStart: addDays(ws, 7), rain, notBefore: addDays(ws, 7), checkins: state.checkins, done }))
  if (!out.length) return 0
  await savePlanDays(out)
  for (const w of [...new Set(out.map(d => weekStartIso(d.date)))]) {
    const c = weekContext(p, w)
    // (v3.50) ure, kot so res v sestavljenem tednu (na kolesu, brez tekme) — isto kot Plan, ne formula
    const mins = weekBikeMinutes(out.filter(d => weekStartIso(d.date) === w && d.role !== 'dirka' && !d.raceId))
    const h = isCustom(p) ? `~${String(c.hours).replace('.', ',')} h` : mins ? `~${fmtDur(mins)}` : 'brez vožnje'
    void logChange(`Sestavil sem teden od ${dshortOf(w)}: ${c.phase === 'prehod' ? 'off-season' : c.easy ? 'lahek začetek' : c.recovery ? 'razbremenilni teden' : c.phaseName.toLowerCase()}, ${h}.`)
  }
  return out.length
}

/**
 * Sestavi ta in naslednji teden znova od danes naprej (opravljeni dnevi ostanejo). (v3.51) `old` = profil pred spremembo:
 * treningi, ki si jih dodal sam, ostanejo (keepOwn) — prej jih je pobrisala vsaka sprememba tekem, cilja, moči ali dni.
 */
export async function rebuildFromToday(prof: Profile = state.profile, o: { tomorrow?: boolean; old?: Profile } = {}): Promise<void> {
  const ws = weekStartIso(state.today)
  const rain: Record<string, number> = {}
  if (state.weather) for (const k in state.weather) rain[k] = state.weather[k]!.rain
  const doneDates = new Set(state.plan.filter(d => d.done).map(d => d.date))
  // če je danes že opravljen, gradi od jutri (test ali ključni trening ne sme pasti na današnji dan);
  // (v3.49) prav tako, ko je prvi dogovor pozno zvečer (danes treninga ni več mogoče narediti)
  const from = doneDates.has(state.today) || o.tomorrow ? addDays(state.today, 1) : state.today
  const done = state.plan.filter(d => d.done).map(d => ({ date: d.date, kind: d.kind }))
  const w1 = buildWeek({ profile: prof, activities: state.activities, weekStart: ws, rain, notBefore: from, checkins: state.checkins, done })
  // (v3.49) tudi naslednji teden ve za opravljene dneve (tek in hoja, rast tedna)
  const w2 = buildWeek({ profile: prof, activities: state.activities, weekStart: addDays(ws, 7), rain, notBefore: addDays(ws, 7), checkins: state.checkins, done })
  // (v3.49) pozen prvi dogovor: danes počitek z razlago (teden ostane sestavljen — tudi v nedeljo zvečer)
  // (v3.50) »začneva jutri« samo, ko je jutri trening — sicer dan prvega treninga (prej »jutri«, jutri pa počitek)
  const first = [...w1, ...w2].filter(d => d.date > state.today && d.kind !== 'pocitek' && !d.optional).sort((a, b) => a.date.localeCompare(b.date))[0]
  const when = !first || first.date === addDays(state.today, 1) ? 'jutri' : `v ${dayAcc(first.date)}`
  const late = o.tomorrow && !doneDates.has(state.today)
    ? w1.filter(d => d.date === state.today).slice(0, 1).map(d => ({ ...d, kind: 'pocitek' as const, title: 'Počitek', desc: `Danes je že pozno — začneva ${when}.`, durationMin: 0, zone: null, tssTarget: 0, why: null }))
    : []
  // dnevi pred danes ostanejo, kakršni so bili
  const built = [...w1, ...w2].filter(d => d.date >= from && !doneDates.has(d.date))
  await savePlanDays([...late, ...keepOwn(built, o.old ?? prof, prof)])
}

/* ---------- dogovor s trenerjem (»Sestaviva tvoj načrt«) ---------- */
/**
 * Shrani dogovor: osnovni podatki (spol, starost, višina, teža), dogovor v profil (ure, moč, oprema, prehrana) in
 * načrt od danes za ta in naslednji teden znova (opravljeni dnevi ostanejo). Novi uporabnik dobi vodnik na Danes.
 */
export async function applyAgreement(f: Focus, basics: Partial<Pick<Profile, 'sex' | 'age' | 'heightCm' | 'weightKg' | 'name' | 'trainTime' | 'push' | 'event' | 'races' | 'ftp' | 'ftpDate'>>): Promise<Profile> {
  const first = !state.profile.onboardingDone
  // (v3.49) trajna shramba ob prvem dogovoru, takoj ob dotiku »Dogovorjeno« — brez računa je načrt samo na tej napravi
  if (first) void requestPersist()
  // trainTime: null = različno (se shrani kot null), ostalo prazno se ne prepiše
  const clean = Object.fromEntries(Object.entries(basics).filter(([k, v]) => (k === 'trainTime' ? v !== undefined : v != null && v !== ''))) as Partial<Profile>
  const base = { ...state.profile, ...clean }
  const ws = weekStartIso(state.today)
  const old = state.profile
  const prof = await updateProfile({ ...clean, ...profileFromFocus(f, base, ws, state.today) })
  if (clean.weightKg) await saveCheckin({ date: state.today, weightKg: clean.weightKg })
  // (v3.49) prvi dogovor pozno (zvečer, »zjutraj« po poldnevu): načrt začne jutri — prej je ostal današnji trening, jutri »ni bilo«
  await rebuildFromToday(prof, { old, tomorrow: first && startsTomorrow(prof.trainTime ?? null, new Date().getHours()) })
  if (first) await updateSettings({ guideSeen: false })
  // (v3.50) »Sem vegan«, »Ne prenašam laktoze« iz uvoda gre v prehranske želje (če jih še ni) — prej so recepti to prezrli
  const diet = state.settings.foodPrefs ? null : foodPrefsFromWish([f.wish, ...(f.said || [])].join('. '))
  if (diet) { await updateSettings({ foodPrefs: diet, recipeAlt: null }); void logChange(`Prehranske želje iz pogovora: ${diet}.`, false) }
  void logChange(`${first ? 'Načrt' : 'Nov dogovor'}: ${f.title} — ${weekLine(f)} (${mixLine(f)}).`, false)
  return prof
}

/**
 * Dnevi brez časa (»Moj dogovor«): dogovor ostane, ta in naslednji teden se razporedita znova (opravljeno ostane).
 * Vrne false, če bi ostalo manj dni kot vadb — takrat je treba spremeniti dogovor (manj vadb), ne samo dneve.
 */
export async function setOffDays(off: number[]): Promise<boolean> {
  const f = state.profile.focus
  if (!f) return false
  const days = [...new Set(off.filter(d => Number.isInteger(d) && d >= 0 && d <= 6))].sort((a, b) => a - b)
  // samo dnevi — ostalo v dogovoru (strategija, izbor vaj, pojasnila) ostane, kot je; določena seja na dnevu brez časa
  // izgubi dan (razporedi se drugam, kardio po moči gre z njo), ko dan spet gre, ostane prosta
  const sessions = f.sessions.map(s => (s.day != null && days.includes(s.day) ? { ...s, day: null } : s))
  if (days.length > 6 || 7 - days.length < trainingDays(sessions)) return false
  const prefer = (f.preferDays || []).filter(d => !days.includes(d))
  const base: Focus = { ...f, offDays: days.length ? days : null, preferDays: prefer.length ? prefer : null, sessions }
  // »zakaj tako« (razmik med težkimi dnevi, počitek) velja za nov razpored; teden od Claude ostane njegov (samo dnevi)
  // (v3.50) pravila trenerja (focus/coach + rules, ~100 KB) se naložijo šele tu — niso v začetnem paketu
  const next: Focus = f.why?.length && f.by !== 'claude' ? (await import('@/domain/focus/coach')).coachReview(base, { age: state.profile.age, wantDays: trainingDays(base.sessions) }).focus : base
  const old = state.profile
  const prof = await updateProfile({ focus: next })
  await rebuildFromToday(prof, { old })
  void logChange(next.offDays?.length ? `Dnevi brez časa: ${daysLine(next.offDays)} — teden je razporejen znova.` : 'Vsi dnevi gredo — teden je razporejen znova.', false)
  return true
}

/* ---------- tekme, hribi, jedro ---------- */
/** Druge tekme sezone: shrani in takoj prilagodi ta in naslednji teden (kasnejši tedni se prilagodijo, ko pridejo na vrsto). */
export async function saveRaces(races: Race[]): Promise<void> {
  const clean = races.filter(r => r.name.trim() && r.date).sort((a, b) => a.date.localeCompare(b.date))
  const old = state.profile
  const prof = await updateProfile({ races: clean })
  await rebuildFromToday(prof, { old })
  void logChange('Tekme sezone so spremenjene — ta in naslednji teden sta sestavljena znova.', false)
}
/** Glavni cilj (npr. Franja): vrsta, dolžina, vzpon, rang — načrt se prilagodi takoj. */
export async function saveMainGoal(ev: NonNullable<Profile['event']>): Promise<void> {
  const old = state.profile
  const prof = await updateProfile({ event: ev })
  await rebuildFromToday(prof, { old })
  void logChange(`Glavni cilj: ${ev.name} — ta in naslednji teden sta sestavljena znova.`, false)
}
/**
 * Konec sezone → off-season: od tega ponedeljka N tednov počitka in vožnje po občutku (hribi po izbiri), nato trije lahki tedni
 * osnove in test FTP. Makrocikel do ciljev teče od tu naprej.
 */
export async function startOffSeason(weeks: number): Promise<void> {
  const ws = weekStartIso(state.today)
  const old = state.profile
  const prof = await updateProfile({ cycleStart: ws, offSeasonWeeks: Math.max(1, Math.min(6, Math.round(weeks))), offSeasonAt: state.today, offSeasonAskedAt: state.today })
  await rebuildFromToday(prof, { old })
  void logChange(`Začel si off-season (${prof.offSeasonWeeks} ${prof.offSeasonWeeks === 1 ? 'teden' : prof.offSeasonWeeks === 2 ? 'tedna' : prof.offSeasonWeeks! <= 4 ? 'tedne' : 'tednov'}) — počitek, nato osnova.`, false)
}
/** Kaj v off-seasonu (uporabnik izbere): kolo po občutku, kolo in hribi, več hribov — ta in naslednji teden znova. */
export async function setOffMix(mix: NonNullable<Profile['offMix']>): Promise<void> {
  const old = state.profile
  const prof = await updateProfile({ offMix: mix })
  await rebuildFromToday(prof, { old })
  void logChange(`Off-season: ${OFF_MIX[mix].label.toLowerCase()} — ta in naslednji teden sta sestavljena znova.`, false)
}
/**
 * Prej je predloga off-seasona sama dala hribe. Kdor še ni izbral (offMix prazen), dobi prihodnje neopravljene hribe
 * iz predloge enkrat sestavljene znova po privzetem (kolo po občutku); dnevi z zamenjavo »Hribi namesto kolesa« (swap)
 * in opravljeni dnevi ostanejo. Brez hribov iz predloge se ne zgodi nič — zato se ne ponavlja.
 */
/**
 * Dogovor = načrt (v3.39.1): star dogovor s kolesarskim načinom brez cilja tekma je dobil kolesarski sestavljalnik z
 * drugimi dnevi in urami. Zdaj velja dogovor — enkrat označi način in teden od danes sestavi znova (opravljeno ostane,
 * ročne zamenjave tudi).
 */
export async function agreementFix(): Promise<boolean> {
  const f = state.profile.focus
  if (!f || f.mode !== 'kolo' || f.aims.includes('tekma') || !f.sessions?.length) return false
  const old = state.profile
  const prof = await updateProfile({ focus: { ...f, mode: 'meri' } })
  const keepDates = new Set(state.plan.filter(d => d.date >= state.today && !d.done && d.swap).map(d => d.date))
  const keep = state.plan.filter(d => keepDates.has(d.date) && !d.done)
  await rebuildFromToday(prof, { old })
  if (keep.length) await savePlanDays(keep)
  void logChange(`Načrt zdaj sledi dogovoru: ${weekLine(f)} — dnevi in trajanja, kot sva se zmenila.`)
  return true
}

export async function offMixFix(): Promise<boolean> {
  const p = state.profile
  if (p.offMix || !offSeasonNow(p, state.today)) return false
  const end = addDays(weekStartIso(state.today), 13)
  const old = state.plan.some(d => d.date >= state.today && d.date <= end && !d.done && d.kind === 'pohod' && !d.swap
    && weekContext(p, weekStartIso(d.date)).phase === 'prehod')
  if (!old) return false
  // ročne zamenjave (»Hribi namesto kolesa«) so njegova odločitev — dnevi z njimi ostanejo, kakršni so
  const keepDates = new Set(state.plan.filter(d => d.date >= state.today && !d.done && d.swap).map(d => d.date))
  const keep = state.plan.filter(d => keepDates.has(d.date) && !d.done)
  await rebuildFromToday(p)
  if (keep.length) await savePlanDays(keep)
  void logChange('Off-season: hribe iz predloge sem zamenjal s kolesom po občutku — kaj delaš, izbereš sam (Danes → Kaj v off-seasonu).')
  toast('Off-season zdaj izbereš sam: privzeto kolo po občutku. Hribe dodaš na Danes pod »Kaj v off-seasonu«.', 'info', 9000)
  return true
}
export async function declineOffSeason(): Promise<void> { await updateProfile({ offSeasonAskedAt: state.today }) }
/** Konec off-seasona prej (začni z osnovo ta teden). */
export async function endOffSeason(): Promise<void> {
  const p = state.profile, ws = weekStartIso(state.today)
  if (!p.cycleStart) return
  const done = Math.max(0, Math.round((new Date(ws).getTime() - new Date(p.cycleStart).getTime()) / (7 * 86400_000)))
  const old = state.profile
  const prof = await updateProfile({ offSeasonWeeks: done })
  await rebuildFromToday(prof, { old })
  void logChange('Off-season končan — osnova začne ta teden z lahkimi tedni.', false)
}
/** Hribi namesto kolesa (in nazaj) — samo ta dan; na uri trening za ta dan izgine (ni več kolo). */
export async function hikeInstead(dayId: string): Promise<void> {
  const d = state.plan.find(x => x.id === dayId); if (!d) return
  await savePlanDay(hikeSwap(d, state.profile))
}
export async function backToBike(dayId: string): Promise<void> {
  const d = state.plan.find(x => x.id === dayId); if (!d?.swap) return
  await savePlanDay(swapBack(d))
}
/** Jedro po želji na izbran dan (neobvezno). */
export async function addCore(date: string): Promise<void> {
  // (v3.51) ali je ta dan vožnja (opis »Po kolesu ali zvečer« samo takrat)
  const ride = state.plan.some(d => d.date === date && (d.kind === 'kolo' || d.kind === 'test') && !d.optional)
  await savePlanDay(coreOnDemand(state.profile, state.activities, date, { ride }))
}
/** Nastavitve moči (kje, v katerih fazah): shrani in sestavi ta in naslednji teden znova. */
export async function setStrength(patch: Partial<Profile['strength']>, days?: number): Promise<void> {
  const old = state.profile
  const prof = await updateProfile({ strength: { ...state.profile.strength, ...patch }, ...(days != null ? { strengthDays: days } : {}) })
  if (prof.event?.date || prof.cycleStart) { await rebuildFromToday(prof, { old }); void logChange('Nastavitve moči so spremenjene — ta in naslednji teden sta sestavljena znova.', false) }
}

/** Ključni trening, ki danes ni bil narejen, gre na naslednji lahki dan; danes dobi vsebino tistega dne. */
export async function moveKeyToLater(dayId: string): Promise<string | null> {
  const d = state.plan.find(x => x.id === dayId)
  if (!d) return null
  const ws = weekStartIso(state.today)
  const week = state.plan.filter(x => x.date >= ws && x.date <= addDays(ws, 6))
  const r = moveKeySession(week, d, state.today, pauseLock(raceLock(state.plan, state.profile), state.profile))
  if (!r) return null
  await updatePlanDays(r)
  return r[1].date
}

/* ---------- treningi na uro: naslednjih 14 dni načrta → koledar intervals.icu → Garmin Connect → ura ---------- */
let pushTimer: number | null = null, pushBusy = false
/** Pošlji z zamikom (več sprememb načrta zapored = eno pošiljanje). ifStale: samo, če je od zadnjega minilo > 6 h. */
export function schedulePushWorkouts(delayMs = 2500, ifStale = false): void {
  if (typeof window === 'undefined') return
  // (v3.52) sveže za oba cilja (intervals.icu in Garmin neposredno) → brez pošiljanja
  const fresh = (i: { at: string; err: string | null } | null | undefined) => !!i && !i.err && Date.now() - new Date(i.at).getTime() < 6 * 3600_000
  if (ifStale && fresh(state.icuWorkouts) && (!garminPushOn() || fresh(state.garminWorkouts))) return
  if (pushTimer) clearTimeout(pushTimer)
  pushTimer = window.setTimeout(() => { pushTimer = null; void pushWorkouts(); if (garminPushOn()) void pushGarminWorkouts() }, delayMs)   // (v3.52) isti zamik tudi za Garmin (LENO: samo ob vklopu)
}
export async function pushWorkouts(manual = false): Promise<IcuWorkoutsInfo | null> {
  const c = state.settings.intervals
  if (!icuReady(c) || c.pushWorkouts === false || pushBusy || (typeof navigator !== 'undefined' && navigator.onLine === false)) return null
  const from = state.today, to = addDays(state.today, 13)
  const desired = state.plan.filter(d => d.date >= from && d.date <= to).map(d => icuWorkout(d, state.profile)).filter((w): w is IcuWorkout => !!w)
  // nič se ni spremenilo od zadnjega uspešnega pošiljanja (isti treningi, isto okno) → brez klicev (kvota)
  const sig = stableStr({ from, to, desired })
  if (!manual) {
    const last = await getKV<{ sig: string; at: number }>('icu.workouts.sig')
    if (last && last.sig === sig && Date.now() - last.at < 24 * 3600_000 && !state.icuWorkouts?.err) return state.icuWorkouts
    if (icuBudget(c).left <= 0) return null   // dnevni proračun porabljen — samodejno pošiljanje počaka do jutri
  }
  pushBusy = true
  const o = { essential: manual }
  try {
    const existing = await fetchEvents(c, from, to, o)
    const diff = workoutDiff(desired, existing)
    // novi in spremenjeni (naš uid) v enem zahtevku (upsert po uid); ostali posodobitve posebej
    const byId = new Map(existing.map(e => [e.id, e] as const))
    const bulk = [...diff.create, ...diff.update.filter(u => byId.get(u.id)?.uid === u.w.uid).map(u => u.w)]
    if (bulk.length) await createEvents(c, bulk, o)
    for (const u of diff.update) if (byId.get(u.id)?.uid !== u.w.uid) await updateEvent(c, u.id, u.w, o)
    for (const id of diff.remove) await deleteEvent(c, id, o)
    const changed = diff.create.length + diff.update.length
    const info: IcuWorkoutsInfo = { at: new Date().toISOString(), n: desired.length, changed, removed: diff.remove.length, err: null }
    await setKV('icu.workouts', info); set({ icuWorkouts: info })
    await setKV('icu.workouts.sig', { sig, at: Date.now() })
    if (manual) toast(changed || diff.remove.length
      ? `Na uro: ${changed ? `${changed}${NBSP}${plural(changed, ['poslan trening', 'poslana treninga', 'poslani treningi', 'poslanih treningov'])}` : ''}${changed && diff.remove.length ? ', ' : ''}${diff.remove.length ? `${diff.remove.length}${NBSP}${plural(diff.remove.length, ['pobrisan', 'pobrisana', 'pobrisani', 'pobrisanih'])}` : ''} — Garmin jih prenese ob naslednji sinhronizaciji.`
      // (v3.50) brez kolesa v naslednjih 14 dneh ni kaj poslati (prej »že enak načrtu (0 treningov)«)
      : desired.length ? `Koledar intervals.icu je že enak načrtu (${count(desired.length, W.trening)}).` : 'V naslednjih 14 dneh ni kolesarskega treninga — na uro gredo samo vožnje.', 'ok', 7000)
    return info
  } catch (e) {
    const info: IcuWorkoutsInfo = { at: new Date().toISOString(), n: 0, changed: 0, removed: 0, err: (e as Error)?.message || 'napaka' }
    await setKV('icu.workouts', info); set({ icuWorkouts: info })
    if (icuErrorKind(e) === 'auth') await setIcuErr(icuErrOf(e))
    if (manual) toast(info.err!, 'err', 7000)
    return null
  } finally { pushBusy = false }
}
/** Izklop »treningov na uro«: naše (formai-…) dogodke od danes naprej pobrišemo iz koledarja, da jih Garmin umakne z ure. Vrne število pobrisanih ali null ob napaki. */
export async function removeWorkouts(): Promise<number | null> {
  const c = state.settings.intervals
  if (!icuReady(c) || pushBusy) return null
  pushBusy = true
  const o = { essential: true }
  try {
    const existing = await fetchEvents(c, state.today, addDays(state.today, 30), o)
    const { remove } = workoutDiff([], existing)
    for (const id of remove) await deleteEvent(c, id, o)
    const info: IcuWorkoutsInfo = { at: new Date().toISOString(), n: 0, changed: 0, removed: remove.length, err: null }
    await setKV('icu.workouts', info); set({ icuWorkouts: info })
    await setKV('icu.workouts.sig', null)
    return remove.length
  } catch (e) {
    if (icuErrorKind(e) === 'auth') await setIcuErr(icuErrOf(e))
    toast((e as Error)?.message || 'Brisanje iz koledarja ni uspelo.', 'err', 7000)
    return null
  } finally { pushBusy = false }
}

/* ---------- vreme ---------- */
export async function refreshWeather(force = true): Promise<Forecast | null> {
  const pl = state.profile.place
  if (!pl) { set({ weather: null }); return null }
  try {
    const win = windowOf(state.profile.trainTime), wn = WINDOW_NAMES[state.profile.trainTime || 'popoldne']
    if (!force) { const c = await cachedForecast(pl.lat, pl.lon, win); if (c) set({ weather: c }) }
    const f = await forecast(pl.lat, pl.lon, win, wn); set({ weather: f }); return f
  } catch { return state.weather }
}

/* ---------- shramba: napake in več zavihkov (v3.49) ---------- */
/** Shramba se ne odpre ob zagonu: razlaga za uporabnika (namesto večnega logotipa FORMAI). */
export function storageBlockedMsg(e: unknown): string {
  return isQuota(e)
    ? 'Na napravi ni prostora za podatke FORMAI. Sprosti prostor (fotografije, aplikacije) in poskusi znova.'
    : 'Brskalnik ne dovoli shranjevanja (zasebni način ali blokirani piškotki). FORMAI hrani podatke na napravi — dovoli shranjevanje za formai.si ali odpri v navadnem oknu.'
}
const isQuota = (e: unknown) => /quota/i.test(String((e as { name?: string } | null)?.name || '')) || /quota|no space|disk is full/i.test(String((e as Error | null)?.message || ''))
/** Zapis ni uspel (polna ali blokirana shramba): »Ni prostora na napravi — obrok ni shranjen. …« */
export function storageFailMsg(e: unknown, what: string): string {
  return isQuota(e)
    ? `Ni prostora na napravi — ${what}. Sprosti prostor ali izvozi kopijo in poskusi znova.`
    : `Shramba na napravi ne dela — ${what}. Poskusi znova ali osveži stran.`
}
/** Zapis z obvestilom ob napaki; napaka gre naprej, da obrazec ostane odprt z vpisanim (prej tiho nič). */
async function writeOrTell<T>(what: string, fn: () => Promise<T>): Promise<T> {
  try { return await fn() } catch (e) { toast(storageFailMsg(e, what), 'err', 9000); throw e }
}

// dva odprta zavihka: zapis v enem → drugi prebere bazo znova (prej je star zavihek s starim stanjem povozil nov vpis)
const TAB_KEY = 'formai.tabs'
let tabs: { bc: BroadcastChannel | null } | null = null
let tabTimer: ReturnType<typeof setTimeout> | null = null
function onOtherTab(): void {
  if (tabTimer) clearTimeout(tabTimer)
  tabTimer = setTimeout(() => { tabTimer = null; void reloadAll().catch(() => undefined) }, 250)
}
/** Poslušaj zapise drugih zavihkov (BroadcastChannel, sicer dogodek storage). */
export function tabsListen(): void {
  if (tabs || typeof window === 'undefined') return
  let bc: BroadcastChannel | null = null
  try { if (typeof BroadcastChannel !== 'undefined') { bc = new BroadcastChannel('formai'); bc.onmessage = onOtherTab } } catch { bc = null }
  if (!bc) window.addEventListener('storage', e => { if (e.key === TAB_KEY) onOtherTab() })
  tabs = { bc }
}
function tabsTell(): void {
  if (!tabs) return
  if (tabs.bc) { try { tabs.bc.postMessage(Date.now()) } catch { /* zaprt */ } return }
  try { localStorage.setItem(TAB_KEY, String(Date.now())) } catch { /* zasebni način */ }
}
/** Lokalna sprememba: drugi zavihki in oblak (usklajevanje). */
export function touch(): Promise<void> { tabsTell(); return syncTouch() }

/* ---------- akcije ---------- */
// zapisi profila in nastavitev eden za drugim: vsak popravek se uporabi na zadnjem SHRANJENEM stanju (ne na morda
// zastarelem stanju zaslona) — sicer bi star posnetek (npr. brez žetona intervals.icu) dobil nov čas in prepisal novejše
let profileQ: Promise<unknown> = Promise.resolve()
let settingsQ: Promise<unknown> = Promise.resolve()
function queued<T>(q: 'p' | 's', fn: () => Promise<T>): Promise<T> {
  const prev = q === 'p' ? profileQ : settingsQ
  const run = prev.then(fn, fn)
  if (q === 'p') profileQ = run.catch(() => undefined); else settingsQ = run.catch(() => undefined)
  return run
}
export async function updateProfile(patch: Partial<Profile>) {
  // (v3.50) izhodišče teže za mejnik ob prvi znani teži (goalBasePatch)
  const p = await queued('p', async () => { const next = { ...(await repo.loadProfile()), ...patch }; return repo.saveProfile({ ...next, ...goalBasePatch(next, todayIso()) }) })
  set({ profile: p }); void touch()
  if ('place' in patch || 'trainTime' in patch) void refreshWeather(true)
  return p
}
/** patch je lahko funkcija shranjenih nastavitev (v3.49): seznam (npr. testi) se sestavi iz baze, ne iz morda zastarelega zaslona. */
export async function updateSettings(patch: Partial<Settings> | ((cur: Settings) => Partial<Settings>)) {
  // kar je uporabnik videl (pogovor na zaslonu) — za razlikovanje »Nov pogovor« od selitve na prazni napravi
  const seen = state.settings.coach
  let p: Partial<Settings> = typeof patch === 'function' ? {} : patch
  const saved = await queued('s', async () => {
    const cur = await repo.loadSettings()
    if (typeof patch === 'function') p = patch(cur)
    const next: Settings = { ...cur, ...p }
    if ('coach' in p) next.coach = coachWithMeta(cur.coach, p.coach, seen)
    return repo.saveSettings(next)
  })
  set({ settings: { ...repo.defaultSettings(), ...saved } }); void touch()
  if (p.accentHex) applyAccent(p.accentHex)
}
/**
 * Pogovor s trenerjem: prazen seznam, ko je uporabnik na zaslonu VIDEL sporočila = »Nov pogovor« (clearedAt — velja na
 * vseh napravah). Prazen seznam z naprave, ki pogovora še ni imela (selitev starega pogovora pred prvim usklajevanjem),
 * NI izbris — tudi če je sinhronizacija medtem že zapisala pogovor z računa. foldedTo in summaryAt ostaneta.
 */
function coachWithMeta(prev: Settings['coach'], next: Settings['coach'], seen: Settings['coach'] | undefined): Settings['coach'] {
  if (!next) return next ?? null
  const now = new Date().toISOString()
  const explicit = !!next.clearedAt && next.clearedAt !== prev?.clearedAt
  if (explicit || (!!seen?.msgs?.length && !!prev?.msgs?.length && !next.msgs?.length)) {
    return { msgs: next.msgs || [], summary: null, clearedAt: explicit ? next.clearedAt! : now }
  }
  // sicer: unija s shranjenim (kot pri usklajevanju) — zastarel posnetek zaslona ne izgubi sporočil, ki jih je
  // medtem prinesla sinhronizacija; strnjeno (foldedTo) in izbrisano (clearedAt) ostane izbrisano
  const summaryAt = !next.summary ? null : next.summaryAt ?? (next.summary === (prev?.summary ?? null) ? prev?.summaryAt ?? null : now)
  return mergeCoach(prev, { ...next, summary: next.summary ?? null, ...(summaryAt ? { summaryAt } : {}) }) ?? null
}
/** »Nov pogovor« s trenerjem: izbriše pogovor in povzetek na vseh napravah (clearedAt). */
export async function newCoachChat(): Promise<void> {
  await updateSettings({ coach: { msgs: [], summary: null, clearedAt: new Date().toISOString() } })
}
/** Ročni uvoz (datoteke, arhiv, posnetek, »Uvozi nove«): isti zaklep kot samodejni uvoz, izbrisane (grob) se ne vrnejo. */
export async function addActivities(list: Activity[]) {
  return repo.withImportLock(async () => {
    const before = new Set(state.activities.map(a => a.id))
    const tomb = await repo.getTomb()
    const cands = list.filter(a => !tomb[tombAct(a)])
    // (v3.49) prava vadba (datoteka, arhiv, posnetek, ročni vnos) zamenja zapis iz načrta istega dne in športa
    await dropStandIns(cands)
    const r = await repo.addActivities(cands)
    const all = await repo.allActivities()
    set({ activities: all }); void touch()
    const fresh = all.filter(a => !before.has(a.id))
    await linkToPlan(fresh)
    return { r, dates: fresh.map(a => a.date) }
  }).then(async x => { await autoAdapt(x.dates); return x.r })
}

/**
 * Po pretežki vožnji (včeraj ali danes) se dan za tem olajša sam: ključni trening gre na primeren lahki dan, lahka vožnja
 * postane regeneracija. Enkrat na dan (oznaka adapt ostane tudi po »Vrni prvotni načrt« in se prenese na druge naprave).
 */
export async function autoAdapt(dates: readonly string[]): Promise<void> {
  for (const date of [...new Set(dates)].filter(d => d >= addDays(state.today, -1) && d <= state.today).sort()) {
    const r = adaptAfterLoad(state.profile, state.plan, state.activities, date, state.today)
    if (!r || r.state !== 'predlog' || !r.days.length) continue
    await updatePlanDays(r.days)
    void logChange(`${date === state.today ? 'Današnja' : 'Včerajšnja'} vožnja je bila precej težja od načrta (obremenitev ${r.actual} namesto ~${r.planned}). ${r.text}`)
    toast(`${date === state.today ? 'Današnja' : 'Včerajšnja'} vožnja je bila precej težja od načrta (${r.actual}${NBSP}TSS namesto ~${r.planned}). ${r.text}`, 'info', 10000)
  }
}
/** »Prilagodi jutri« na kartici Po današnji vožnji. */
export async function applyLoadAdapt(date: string): Promise<LoadAdapt | null> {
  const r = adaptAfterLoad(state.profile, state.plan, state.activities, date, state.today)
  if (r && r.state === 'predlog' && r.days.length) await updatePlanDays(r.days)
  return r
}
/** »Vrni prvotni načrt«: prilagoditev po pretežki vožnji dneva `date` razveljavi. */
export async function undoLoadAdaptOf(date: string): Promise<void> {
  const days = undoLoadAdapt(state.plan, date)
  // prestavljen zamujeni ključni trening: pretekli dan ni več »prestavljen«, ampak izpuščen
  const src = state.plan.filter(d => d.date === date && d.missed === 'moved').map(d => ({ ...d, missed: 'skipped' as const, updatedAt: new Date().toISOString() }))
  if (days.length || src.length) await updatePlanDays([...days, ...src])
}

/**
 * Uvožena vožnja/vadba odkljuka načrtovano sejo istega dne — samo, če ji ustreza (ista vrsta, vsaj pol načrtovanega
 * trajanja: 20-minutna vožnja v službo ni 4-urna dolga). Poveže se tudi z ročno odkljukanim dnem brez aktivnosti.
 */
export async function linkToPlan(acts: readonly Activity[]) {
  let n = 0
  for (const a of acts) {
    if (a.date < addDays(state.today, -21) || state.plan.some(d => d.done?.activityId === a.id)) continue
    const cands = state.plan.filter(x => x.date === a.date && (!x.done || !x.done.activityId))
    const d = bestPlanMatch(a, cands)
    if (!d) continue
    const done = { at: d.done?.at || new Date().toISOString(), activityId: a.id }
    await repo.putPlanDay({ ...d, done })
    state = { ...state, plan: state.plan.map(x => (x.id === d.id ? { ...x, done } : x)) }
    n++
    // vožnja je le prišla pozno: ključni trening, ki smo ga že prestavili kot »ni bil narejen«, gre nazaj — kasnejši dan je spet lahek
    if (d.missed === 'moved') {
      const back = state.plan.filter(x => x.adapt?.after === d.date && x.adapt.prev && !x.done).map(x => ({ ...x, ...x.adapt!.prev!, updatedAt: new Date().toISOString(), adapt: { after: d.date, off: true } }))
      if (back.length) { await repo.putPlanDays(back); void logChange(`${d.title} je vendarle bil narejen (vožnja je prišla z ure pozneje) — ${dayAccOf(back[0]!.date)} je spet lahek dan.`); toast(`${d.title} je vendarle bil narejen — ${dayAccOf(back[0]!.date)} je spet lahek dan.`, 'info', 8000) }
    }
  }
  if (n) { await reloadPlan(); void touch() }
}
export async function saveActivity(a: Activity) { await writeOrTell('vadba ni shranjena', () => repo.putActivity(a)); set({ activities: await repo.allActivities() }); void touch() }
/** Kako je šlo (RPE 1–10, null = izbriši): na vadbo, če jo dan ima; sicer na dan načrta. Ne pošilja na uro. */
export async function rateSession(o: { activityId?: string | null; dayId?: string | null }, rpe: number | null): Promise<void> {
  const a0 = o.activityId ? state.activities.find(x => x.id === o.activityId) : null
  // (v3.49) zapis iz načrta: ocena gre na dan načrta (en vir, kot pri »Opravil« brez ure)
  if (a0?.planDayId) o = { dayId: a0.planDayId }
  const a = a0?.planDayId ? null : a0
  if (a) {
    // ročni vnos in datoteka brez moči in utripa: obremenitev iz občutka (prej samo povprečje za šport)
    const est = (a.source === 'manual' || a.source === 'file' || a.source === 'recorder') && !a.avgPower && !a.avgHr
    await saveActivity({ ...a, rpe, ...(est ? { tss: estimateTss({ ...a, rpe }, state.profile) } : {}) })
    return
  }
  const d = o.dayId ? state.plan.find(x => x.id === o.dayId) : null
  if (d) { await repo.putPlanDay({ ...d, rpe }); await reloadPlan(); void touch() }
}
export async function removeActivity(id: string) {
  const a0 = state.activities.find(a => a.id === id)
  await repo.deleteActivity(id); set({ activities: state.activities.filter(a => a.id !== id) })
  // dan v načrtu, ki je kazal na to aktivnost, ni več opravljen — (v3.49) tudi dan zapisa iz načrta
  const d = state.plan.find(x => x.done?.activityId === id) ?? (a0?.planDayId ? state.plan.find(x => x.id === a0.planDayId && x.done && !x.done.activityId) : undefined)
  if (d) { await repo.putPlanDay({ ...d, done: null }); await reloadPlan() }
  // (v3.49) izbrisana prava vadba, ki ni bila povezana: opravljen dan istega dne spet šteje iz načrta
  else if (a0 && !a0.planDayId) for (const x of state.plan.filter(x => x.date === a0.date && x.done && !x.done.activityId)) await syncStandIn(x, true)
  void touch()
}
/** Sestava celih dni (teden, nov načrt, AI prilagoditev): neopravljeni zapisi teh dni se zamenjajo s podanimi. */
export async function savePlanDays(days: PlanDay[]) { await repo.upsertPlanDays(days); await reloadPlan(); void touch(); schedulePushWorkouts() }
/** Posodobi samo te zapise (premik, prestavitev, prilagoditev) — drugi zapisi istih dni (npr. moč) ostanejo. */
export async function updatePlanDays(days: PlanDay[]) { await repo.putPlanDays(days); await reloadPlan(); void touch(); schedulePushWorkouts() }
/**
 * Razveljavi sestavo ali AI prilagoditev: vrne prejšnje dni in pobriše nove na datumih, kjer prej ni bilo ničesar.
 * `dates` = vsi datumi, ki jih je sprememba zapisala.
 */
export async function restorePlanDays(prev: PlanDay[], dates: Iterable<string>): Promise<void> {
  const had = new Set(prev.map(d => d.date))
  const gone = [...new Set(dates)].filter(d => !had.has(d))
  if (prev.length) await repo.upsertPlanDays(prev)
  if (gone.length) await repo.removePlanDates(gone)
  await reloadPlan(); void touch(); schedulePushWorkouts()
}
export async function savePlanDay(day: PlanDay) { await repo.putPlanDay(day); await reloadPlan(); void touch(); schedulePushWorkouts() }
/**
 * `min` = dejanski čas iz vodene vadbe ali »Krajše« (šteje v teden namesto načrtovanega, v3.48).
 * (v3.49) Brez povezane vadbe nastane zapis iz načrta (forma, ure, Napredek); odznačitev ali povezava s pravo vadbo ga pobriše.
 */
export async function setPlanDone(id: string, done: boolean, activityId?: string | null, min?: number | null) {
  const d = state.plan.find(x => x.id === id); if (!d) return
  // (v3.49) vožnja z ure je že povezana (prišla med vodeno vadbo): konec vadbe povezave ne pobriše
  const link = activityId || (done && d.done?.activityId) || null
  const now = new Date().toISOString()
  // (v3.49) »Opravil« na ključnem treningu, ki smo ga že prestavili kot »ni bil narejen« (pozabljena kljukica):
  // ciljni dan dobi nazaj svojo vsebino, dan ni več »prestavljen«
  const back = done && d.missed === 'moved' ? movedBack(d, now) : []
  const next: PlanDay = { ...d, ...(back.length ? { missed: null } : {}), done: done ? { at: now, activityId: link, ...(min != null && min > 0 ? { min: Math.round(min) } : {}) } : null }
  if (back.length) await repo.putPlanDays(back)
  await repo.putPlanDay(next)
  if (done) haptic('ok')
  await reloadPlan()
  await syncStandIn(next, true)
  void touch()
  if (back.length) {
    schedulePushWorkouts()
    const msg = `${d.title} je bil vendarle narejen — ${dayAccOf(back[0]!.date)} je spet po načrtu.`
    void logChange(msg); toast(msg, 'info', 8000)
  }
}

/**
 * (v3.49) Zapis iz načrta za ta dan: nastane ob »Opravil« ali vodeni vadbi brez ure (pretekli in današnji dan, ni prave
 * vadbe iste vrste), se posodobi ob drugih minutah, izgine ob odznačitvi ali povezavi s pravo vadbo.
 * `fresh` (dejanje uporabnika): id, ki ga je izbris že pokopal, dobi pripono — zapis se ne izgubi ob usklajevanju.
 */
async function syncStandIn(d: PlanDay, fresh = false): Promise<void> {
  const mine = state.activities.filter(a => a.planDayId === d.id)
  const sport = sportOfKind(d.kind)
  let want = d.date <= state.today && sport && !realOn(state.activities, d.date, sport, { plan: state.plan, dayId: d.id }) ? standInFor(d, state.profile, mine[0]) : null
  if (want && !mine[0] && fresh && (await repo.getTomb())[`a:id:${want.id}`]) want = { ...want, id: `${want.id}-${Date.now().toString(36)}` }
  let changed = false
  for (const a of mine) if (!want || a.id !== want.id) { await repo.deleteActivity(a.id); changed = true }
  if (want && (!mine[0] || standInChanged(mine[0], want))) { await repo.putActivity(want); changed = true }
  if (changed) set({ activities: await repo.allActivities() })
}

/** (v3.49) Prava vadba istega dne in športa zamenja zapis iz načrta (`extra` = vadbe, ki se pravkar uvažajo). Vrne, koliko jih je odpadlo. */
export async function dropStandIns(extra: readonly Activity[] = []): Promise<number> {
  const gone = standInsToDrop(state.activities, extra, state.plan)
  if (!gone.length) return 0
  for (const a of gone) await repo.deleteActivity(a.id)
  const ids = new Set(gone.map(a => a.id))
  set({ activities: state.activities.filter(a => !ids.has(a.id)) })
  return gone.length
}

/**
 * (v3.49) Opravljeni dnevi brez ure iz zadnjih 120 dni (stare kljukice, kopija, druga naprava s starejšo različico) dobijo
 * zapis iz načrta — da forma in ure tedna vidijo trening, ki je bil. Isti id na vseh napravah; izbrisani ne vstanejo.
 */
export async function ensureStandIns(): Promise<number> {
  const today = state.today, from = addDays(today, -120)
  const plan = (await repo.allPlan()).filter(d => d.date >= from && d.date <= today)
  const add = standInsToAdd(plan, state.activities, state.profile, { today, from, tomb: await repo.getTomb() })
  for (const a of add) await repo.putActivity(a)
  if (add.length) set({ activities: await repo.allActivities() })
  return add.length
}
async function reloadPlan() { const ws = weekStartIso(state.today); set({ plan: await repo.planBetween(addDays(ws, -14), addDays(ws, 20)) }) }
async function reloadMeals() {
  const [mealsToday, recentMeals] = await Promise.all([repo.mealsOn(state.today), repo.mealsBetween(addDays(state.today, -90), state.today)])
  set({ mealsToday, recentMeals })
}
export async function addMeal(m: MealEntry) { await writeOrTell('obrok ni shranjen', () => repo.putMeal(m)); haptic('ok'); await reloadMeals(); void touch() }
export async function removeMeal(id: string) { await repo.deleteMeal(id); await reloadMeals(); void touch() }
export async function saveCheckin(c0: DailyCheckin) {
  // (v3.49) dopolni shranjeni vnos dneva (polja, ki jih zapis nima, ostanejo); ob polni shrambi jasno obvestilo
  const c = await writeOrTell('vnos ni shranjen', () => repo.mergeCheckin(c0))
  set({ checkinToday: c.date === state.today ? c : state.checkinToday, checkins: await repo.allCheckins() })
  // teža v profilu (iz nje se računajo kalorije in beljakovine): (v3.49) 7-dnevno povprečje pri vsaj 3 tehtanjih,
  // sicer zadnje — prej zadnje tehtanje, zato je cilj skakal z vodo (±1 kg po polnjenju z OH ali vroči vožnji)
  if (c0.weightKg !== undefined) await weightFromWeighs()
  void touch()
  // načrt posluša jutranji vnos: noge zelo bolijo ali si na dnu → danes brez kolesa ali lažje (boljši vnos to vrne)
  if (c.date === state.today) await followState()
}
/**
 * (v3.49) Teža v profilu iz tehtanj: 7-dnevno povprečje (vsaj 3 tehtanja), sicer zadnje veljavno — tudi po izbrisu
 * napačnega (povprečje ga ne šteje več). Brez tehtanj ostane, kot je.
 */
async function weightFromWeighs(): Promise<void> {
  const kg = calcWeightKg(state.checkins)
  if (kg != null && state.profile.weightKg !== kg) await updateProfile({ weightKg: kg })
}
const kgSl = (x: number) => String(+x.toFixed(1)).replace('.', ',')
/**
 * (v3.49) Izbris napačnega tehtanja (97 namesto 79): teža tega dne gre ven (null — izbris velja tudi na drugih
 * napravah), teža v profilu se vrne na zadnje veljavno tehtanje, povprečje, cilj in kalorije se takoj popravijo.
 */
export async function removeWeigh(date: string): Promise<void> {
  const prev = state.checkins.find(c => c.date === date)
  if (prev?.weightKg == null) return
  const kg = prev.weightKg
  await saveCheckin({ date, weightKg: null })
  await weightFromWeighs()
  // (v3.49) izbrisano edino tehtanje: teža v profilu bi ostala napačna (97) — nazaj na izhodišče cilja, sicer povej
  let note = ''
  if (calcWeightKg(state.checkins) == null) {
    const start = state.profile.goalStart?.weightKg
    if (start && start > 0) { if (state.profile.weightKg !== start) await updateProfile({ weightKg: start }); note = ` Teža v profilu: ${kgSl(start)}${NBSP}kg (izhodišče cilja).` }
    else if (state.profile.weightKg) note = ` Teža v profilu ostane ${kgSl(state.profile.weightKg)}${NBSP}kg — popravi jo v Nastavitvah → Profil.`
  }
  undoToast(`Izbrisano tehtanje ${dm(date)} (${kgSl(kg)}${NBSP}kg).${note}`, () => saveCheckin({ date, weightKg: kg }))
}
/**
 * (v3.49) Izbris jutranjega vnosa dneva (energija, mišice, spanec): tehtanje tega dne ostane; brez tehtanja gre cel
 * vnos z grobom (ne vrne se z druge naprave). »Razveljavi« vrne prejšnje.
 */
export async function removeCheckin(date: string): Promise<void> {
  const prev = state.checkins.find(c => c.date === date)
  if (!prev) return
  if (prev.weightKg != null || prev.waistCm != null) await saveCheckin({ date, mood: null, soreness: null, sleepH: null, note: null })
  else {
    await writeOrTell('izbris ni shranjen', () => repo.deleteCheckin(date))
    set({ checkinToday: date === state.today ? null : state.checkinToday, checkins: await repo.allCheckins() })
    void touch()
    if (date === state.today) await followState()
  }
  const { updatedAt: _u, ...back } = prev; void _u
  undoToast(`Jutranji vnos ${dm(date)} je izbrisan.`, () => saveCheckin(back))
}

/* ---------- načrt posluša, kako si (jutranji vnos) ---------- */
/** Stopnja danes iz jutranjega vnosa, pripravljenosti, včerajšnjega jutra, forme in zadnjih treh dni. */
export function stateToday(s: AppState = state): StateRead {
  const series = formSeries(s.activities, s.today)
  const tsb = series.length ? series[series.length - 1]!.tsb : null
  const rec = wellnessActive(s.settings) ? recoveryOf(s.wellness, s.today, s.checkinToday?.sleepH ?? null) : null   // (v3.52) tudi Garmin Connect neposredno
  const ready = readinessOf(tsb, s.checkinToday, rec)
  const yesterday = s.checkins.find(c => c.date === addDays(s.today, -1)) ?? null
  return readState({ checkin: s.checkinToday, readiness: ready?.score ?? null, yesterday, tsb: s.activities.length >= 10 ? tsb : null, load3: load3(s.profile, s.plan, s.activities, s.today), easyHard: easyFeltHard(s.activities, s.plan, s.today) })
}
let stateChain: Promise<void> = Promise.resolve()
/**
 * Po jutranjem vnosu: stopnja ≥ 2 → prilagodi danes (in na dnu jutri), razen če je danes že prilagojeno ali si
 * prilagoditev zavrnil (»Vrni po načrtu«); stopnja < 2 → samodejna prilagoditev se vrne (vnos si popravil).
 * Zaporedno (hitri tapi v jutranjem vnosu ne smejo prilagoditi dvakrat).
 */
export function followState(): Promise<void> {
  stateChain = stateChain.then(async () => {
    const today = state.today
    const st = stateToday()
    const marked = state.plan.filter(d => d.byState?.date === today)
    const active = marked.filter(d => !d.byState!.off)
    if (st.level >= 2) {
      if (marked.length) return
      const r = adaptToState(state.profile, state.plan, today, st)
      if (r?.days.length) { await updatePlanDays(r.days); void logChange(`Po jutranjem vnosu (${st.reasons.join(', ') || 'počutje'}): ${r.lines.join(' ') || 'današnji trening je lažji.'}`) }
    } else if (active.length && active.every(d => d.byState!.auto)) {
      const back = undoState(state.plan, today, { keepOff: false })
      if (back.length) { await updatePlanDays(back); void logChange('Jutranji vnos je boljši — današnji trening je spet po načrtu.') }
    }
  }).catch(() => undefined)
  return stateChain
}
/** Izbran način za danes (sprehod, počitek, lahko vrtenje): prejšnja prilagoditev se vrne in nova velja (ni samodejna). */
export async function setStateMode(mode: StateMode): Promise<void> {
  const today = state.today
  const back = undoState(state.plan, today, { keepOff: false })
  const base = state.plan.map(d => back.find(b => b.id === d.id) ?? d)
  const st = stateToday({ ...state, plan: base })
  const r = adaptToState(state.profile, base, today, st, { mode })
  const byId = new Map<string, PlanDay>()
  for (const d of [...back, ...(r?.days ?? [])]) byId.set(d.id, d)
  if (byId.size) await updatePlanDays([...byId.values()])
}
/** »Vrni po načrtu«: današnja prilagoditev se vrne; danes je ne ponovimo sami. */
export async function undoStateToday(): Promise<void> {
  const back = undoState(state.plan, state.today, { keepOff: true })
  if (back.length) await updatePlanDays(back)
}
export async function addTest(t: TestEntry) {
  // (v3.49) rezultat izven razpona (5000 W, utrip 900) se ne shrani in ne prepiše FTP
  const bad = testError(t.kind, t.value)
  if (bad) { toast(bad, 'err'); return }
  // (v3.49) seznam iz baze, ne iz zaslona: drug zavihek je medtem morda vpisal svoj test
  let tests: TestEntry[] = []
  await writeOrTell('test ni shranjen', () => updateSettings(cur => {
    tests = [...(cur.tests || []).filter(x => x.id !== t.id), t].sort((a, b) => a.date.localeCompare(b.date))
    return { tests }
  }))
  // (v3.48) star test (starejši od zadnjega testa ali FTP v profilu) FTP ne prepiše
  const newest = latestFtpTest(tests)
  if (t.kind === 'ftp' && (newest?.id !== t.id || t.date < (state.profile.ftpDate || ''))) {
    // sporočilo pove, od česa je test starejši: od drugega testa ali od FTP, vpisanega ročno (po pregledu v3.48)
    if (state.profile.ftp) toast(newest?.id !== t.id ? `Test je starejši od zadnjega testa — FTP ostane ${state.profile.ftp} W.` : `Test je starejši od FTP, ki si ga vpisal ${dm(state.profile.ftpDate!)} — FTP ostane ${state.profile.ftp} W.`, 'info', 6000)
  } else if (t.kind === 'ftp') {
    const ftp = Math.round(t.value * 0.95)
    const w = state.profile.weightKg
    // uvodni test (do 14 dni po potrditvi cilja) postane izhodišče — cilji se preračunajo iz pravega FTP, ne ocene
    const gs = state.profile.goalStart
    const calib = gs && Math.abs(new Date(t.date).getTime() - new Date(gs.date).getTime()) <= 14 * 86400_000
    await updateProfile({ ftp, ftpDate: t.date, ...(calib ? { goalStart: { ...gs!, ftp } } : {}) })
    void logChange(`Nov FTP ${ftp} W (test) — od naslednjega tedna so vati v načrtu po njem.`, false)
    toast(`FTP ${ftp} W (95 % testa)${w ? ` = ${(ftp / w).toFixed(2).replace('.', ',')} W/kg` : ''}. Naslednji teden se sestavi z novimi vati.`, 'ok', 7000)
  }
  if (t.kind === 'p5') {
    const w = state.profile.weightKg
    if (w) toast(`5 min: ${(t.value / w).toFixed(2).replace('.', ',')} W/kg → VO2max ~${Math.round(10.8 * (t.value / w) + 7)} ml/kg/min (ocena).`, 'ok', 7000)
  }
  if (t.kind === 'rhr') await updateProfile({ restHr: Math.round(t.value) })
}
/** Najnovejši 20-min test (pri istem datumu zadnji vpisan). */
export function latestFtpTest(tests: readonly TestEntry[]): TestEntry | null {
  let best: TestEntry | null = null
  for (const x of tests) if (x.kind === 'ftp' && (!best || x.date >= best.date)) best = x
  return best
}
export async function removeTest(id: string) {
  // (v3.49) seznam iz baze (drug zavihek), ne iz zaslona
  let all: TestEntry[] = []
  await repo.addTomb(tombTest(id)); await updateSettings(cur => { all = cur.tests || []; return { tests: all.filter(x => x.id !== id) } })
  const gone = all.find(x => x.id === id)
  // (v3.48) izbrisan test, iz katerega je FTP: FTP spet po prejšnjem najnovejšem testu (ročno vpisan FTP ostane)
  const p = state.profile
  if (gone?.kind !== 'ftp' || p.ftpDate !== gone.date || p.ftp !== Math.round(gone.value * 0.95)) return
  const prev = latestFtpTest(all.filter(x => x.id !== id))
  if (!prev) return
  const ftp = Math.round(prev.value * 0.95)
  // uvodni test je bil tudi izhodišče cilja (addTest: calib) — izhodišče gre nazaj s FTP (po pregledu v3.48)
  const gs = p.goalStart
  const calib = gs && gs.ftp === p.ftp && Math.abs(new Date(gone.date).getTime() - new Date(gs.date).getTime()) <= 14 * 86400_000
  await updateProfile({ ftp, ftpDate: prev.date, ...(calib ? { goalStart: { ...gs!, ftp } } : {}) })
  void logChange(`FTP spet ${ftp} W (test ${dm(prev.date)}) — izbrisan je novejši test.`, false)
  toast(`FTP spet ${ftp} W (test ${dm(prev.date)}).`, 'ok')
}
export async function setMenu(menu: WeekMenu | null) { await updateSettings({ menu }) }
/** Prehranske želje za recepte. */
// (v3.50) nove želje: »drug predlog« ne velja več (druge jedi)
export async function setFoodPrefs(text: string) { await updateSettings({ foodPrefs: text.trim().slice(0, 200) || null, recipeAlt: null }) }
/** (v3.50) »drug predlog« za dan (po obroku) — shranjen, da Danes, Plan in nakupovalni seznam kažejo isto jed; starejši od 7 dni odpadejo. */
export async function setRecipeAlt(date: string, alt: Record<string, number>) {
  const keep = Object.fromEntries(Object.entries(state.settings.recipeAlt || {}).filter(([d]) => d >= addDays(state.today, -7) && d !== date))
  const clean = Object.fromEntries(Object.entries(alt).filter(([, v]) => Number.isInteger(v) && v > 0))
  await updateSettings({ recipeAlt: Object.keys(clean).length ? { ...keep, [date]: clean } : keep })
}
/** Recepti dneva z AI (shranjeni po datumu, starejši od 14 dni odpadejo); novi obroki se dodajo k že shranjenim za ta dan. */
export async function setDayMenu(date: string, slots: Record<string, import('@/domain/nutrition/recipes').Recipe> | null) {
  const cur = state.settings.dayMenus || {}
  const keep = Object.fromEntries(Object.entries(cur).filter(([d]) => d >= addDays(state.today, -14) && d !== date))
  const prev = cur[date]?.slots && typeof cur[date]!.slots === 'object' ? cur[date]!.slots : {}
  await updateSettings({ dayMenus: slots ? { ...keep, [date]: { at: new Date().toISOString(), slots: { ...prev, ...slots } } } : keep })
}

/* ---------- račun ---------- */
/** Prvo usklajevanje ni uspelo (omrežje, strežnik): poskusi znova takoj — polno usklajevanje. */
export async function retrySync(): Promise<void> { await syncNow().catch(() => undefined) }

export async function signIn(): Promise<AuthUser | null> {
  // (v3.50) pred Googlom: zastavica (preusmeritev se vrne z novim zagonom) in poslušanje prijave, če še ne teče
  markAuth()
  startAuth()
  const u = await signInGoogle()
  if (u) { set({ user: u, authKnown: true }); toast(`Prijavljen kot ${u.name || u.email || 'uporabnik'}`, 'ok') }
  return u
}
/** (v3.51) odjava, ko zadnje spremembe niso šle v oblak */
export const SIGNOUT_UNSYNCED = 'Zadnje spremembe še niso v oblaku (ni povezave) — nisem te odjavil. Na tej napravi ostanejo in gredo v oblak ob naslednji prijavi.'
export async function signOut(): Promise<void> {
  // zadnje usklajevanje samo, če sinhronizacija teče (po izbrisu računa je ustavljena — ne ustvari dokumenta znova)
  if (state.sync.state !== 'off') {
    await pushNow().catch(() => undefined)
    // (v3.51) brez povezave ali napaka oblaka: ne odjavi tiho — povej in ponudi »Odjavi vseeno« (prej »Odjavljen« brez besede)
    if (state.sync.state === 'error' || (typeof navigator !== 'undefined' && navigator.onLine === false)) {
      toast(SIGNOUT_UNSYNCED, 'err', 0, { label: 'Odjavi vseeno', run: () => void signOutNowAnyway() })
      return
    }
  }
  await signOutNowAnyway()
}
async function signOutNowAnyway(): Promise<void> {
  await signOutNow()
  // (v3.51) brez zastavice prijave se Firebase ob zagonu ne naloži več (razen če ima naprava račun usklajevanja)
  markAuth(false)
  stopSync()
  set({ user: null, pro: false, firstSync: null })
  toast('Odjavljen. Podatki ostanejo na tej napravi.', 'info')
}

/**
 * (v3.49) »Izbriši na napravi«: prijavljen se najprej odjavi (zadnje spremembe gredo v oblak), sicer bi se ob
 * naslednjem zagonu vse vrnilo iz oblaka. Oblak ostane. Vrne false, če odjava ni uspela (nič ni izbrisano).
 */
export async function wipeThisDevice(): Promise<boolean> {
  if (state.user) {
    if (state.sync.state !== 'off') await pushNow().catch(() => undefined)
    stopSync()
    try { await signOutNow() } catch {
      const u = state.user
      if (u && !state.accountClash) beginSync(u)
      toast('Odjava ni uspela — podatkov na napravi nisem izbrisal. Poskusi znova.', 'err', 8000)
      return false
    }
    set({ user: null, pro: false, firstSync: null })
  }
  await wipeDevice()
  return true
}

/** Vse lokalne podatke s te naprave (IndexedDB, ključi prve različice, ploščice karte) in stanje v pomnilniku. */
async function wipeDevice(): Promise<void> {
  await repo.wipeAll()
  try { localStorage.removeItem('formai.pilot') } catch { /* zasebni način */ }
  set({
    profile: repo.defaultProfile(), settings: repo.defaultSettings(), activities: [], plan: [], mealsToday: [], recentMeals: [], checkinToday: null, checkins: [],
    routeLib: null, icuWorkouts: null, icuDiag: null, icuErr: null, wellness: null, migration: null, cycle: null, garminErr: null,
  })
}

/**
 * Izbris računa: ustavi sinhronizacijo → strežnik (POST /account/delete; 403 reauth → ponovna prijava z Googlom in še en
 * poskus; 404 → stara pot na odjemalcu) → ob uspehu odklopi OAuth žeton intervals.icu, odjava in izbris vseh podatkov
 * na napravi (tudi ključev prve različice). Ob neuspehu se sinhronizacija nadaljuje.
 */
export async function deleteAccountAll(): Promise<{ ok: boolean; reauth?: boolean; error?: string }> {
  const creds = state.settings.intervals
  // treningi FORMAI v koledarju intervals.icu bi sicer ostali na uri — najprej jih pobriši (tuji ostanejo)
  if (creds && creds.pushWorkouts !== false) await removeWorkouts().catch(() => null)
  await garminBeforeAccountDelete()   // (v3.52) Garmin: soglasje preklicano (deregistracija), žetoni s strežnika
  const r = await deleteAccountOnServer(state.settings.pilot?.id ?? null)
  if (!r.ok) return { ok: false, reauth: r.reauth, error: r.error || 'Izbris ni uspel.' }
  if (creds?.token) await disconnectApp(creds).catch(() => undefined)
  await signOutNow()
  stopSync()
  await wipeDevice()
  set({ user: null, pro: false, firstSync: null, accountClash: null, syncDeleted: null })
  toast('Račun in vsi podatki so izbrisani.', 'ok', 7000)
  return { ok: true }
}

/** Drug račun na tej napravi: »Počisti in nadaljuj« — pobriše podatke prejšnjega računa s te naprave in začne usklajevanje. */
export async function acceptAccountSwitch(): Promise<void> {
  const u = state.user
  stopSync()
  await wipeDevice()
  set({ accountClash: null, syncDeleted: null, firstSync: null })
  await reloadAll()
  if (u) { beginSync(u); void checkPro() }
}
/** Drug račun na tej napravi: »Odjava« — podatki ostanejo nedotaknjeni, sinhronizacija se ne začne. */
export async function cancelAccountSwitch(): Promise<void> {
  set({ accountClash: null })
  stopSync()
  await signOutNow()
  set({ user: null, pro: false, firstSync: null })
}

export async function checkPro(): Promise<boolean> {
  try {
    const t = await idToken(); if (!t) return false
    let pro = false
    try {
      const r = await fetch(`${PROXY}/stripe/status`, { headers: { Authorization: `Bearer ${t}` } })
      if (r.ok) pro = !!((await r.json()) as { pro?: boolean }).pro
    } catch { /* strežnik te poti morda nima */ }
    // strežnik kvoto odloča po proUsers/{uid}.pro — isti dokument preberemo še neposredno (lastnik ga sme brati)
    if (!pro) pro = await proFromFirestore()
    set({ pro }); return pro
  } catch { return false }
}

/* ---------- trase ---------- */
let routesRunning = false
/**
 * Dopolni knjižnico tras iz voženj z Garmina (intervals.icu): največ na 6 h in največ 15 sledi naenkrat (kvota
 * intervals.icu), vsaka vožnja enkrat; ko je dnevni proračun porabljen, počaka. Odjava (401/403) gre v state.icuErr.
 */
export async function ensureRoutes(force = false): Promise<void> {
  const c = state.settings.intervals
  if (routesRunning) return
  const idle = async () => { if (!state.routeLib) set({ routeLib: await loadRouteLib() }) }
  if (!icuReady(c) || (typeof navigator !== 'undefined' && navigator.onLine === false)) { await idle(); return }
  const last = (await getKV<number>('routes.fillAt')) || 0
  // sledi so nenujne: pusti rezervo dnevnega proračuna za uvoz voženj in koledar
  const max = Math.min(ROUTE_STREAMS_PER_RUN, icuBudget(c).left - (c.token ? 20 : 100))
  if ((!force && Date.now() - last < 6 * 3600_000) || max <= 0) { await idle(); return }
  routesRunning = true; set({ routesBusy: true })
  try {
    await setKV('routes.fillAt', Date.now())
    const { lib, error } = await fillRouteLib(c, state.activities, max)
    set({ routeLib: lib })
    if (error && icuErrorKind(error) === 'auth') await setIcuErr(icuErrOf(error))
  }
  catch { /* tiho */ }
  finally { routesRunning = false; set({ routesBusy: false }) }
}

/**
 * Tempo za čas tras: umeritev na tvojih vožnjah (paceFactor) × učenje iz treningov (paceAdj: dejanski čas
 * od odhoda do prihoda proti oceni). k gre v vse ocene časa tras.
 */
let paceMemo: { key: string; acts: readonly Activity[]; plan: readonly PlanDay[]; val: { k: number; adj: ReturnType<typeof paceAdj> } } | null = null
export function routePace(lib: RouteLib | null = state.routeLib): { k: number; adj: ReturnType<typeof paceAdj> } {
  const p = state.profile
  const key = `${libSig(lib)}#${lib?.gen.length ?? 0}#${p.ftp}#${p.weightKg}#${state.today}`
  if (paceMemo && paceMemo.key === key && paceMemo.acts === state.activities && paceMemo.plan === state.plan) return paceMemo.val
  const recs = routesOf(lib), k0 = paceFactor(recs, p)
  const adj = paceAdj(lib?.raw || [], state.activities, state.plan, p, k0, state.today)
  const val = { k: +(k0 * adj.adj).toFixed(3), adj }
  paceMemo = { key, acts: state.activities, plan: state.plan, val }
  return val
}
/**
 * Nova trasa za dan (BRouter, profil za cestno kolo). (v3.52 LENO) Risanje (BRouter, profil cest, krogi čez klance)
 * je v ./routeGen — ni v začetnem paketu, prenese se ob prvi novi trasi (gumb na kartici ali autoRoutes).
 */
export const newRouteFor = (day: PlanDay, seed: number, replace = false): Promise<RouteRec> =>
  import('./routeGen').catch(() => { throw new Error('Del aplikacije za risanje tras se ni prenesel — preveri povezavo in poskusi znova.') }).then(m => m.newRouteFor(day, seed, replace))

/**
 * Trasa za danes in jutri brez klika: najprej tvoje pogoste poti (menjava, ne ista kot včeraj). Novo (BRouter)
 * nariše samo, če nobena tvoja ne ustreza treningu (čas ±12 %). Enkrat na dan na vožnjo.
 */
let autoRoutesRunning = false
export async function autoRoutes(): Promise<void> {
  if (autoRoutesRunning || typeof navigator !== 'undefined' && navigator.onLine === false) return
  const lib = state.routeLib
  if (!lib?.home) return
  autoRoutesRunning = true
  try {
    const p = state.profile, recs = routesOf(lib), k = routePace(lib).k
    for (const date of [state.today, addDays(state.today, 1)]) {
      const day = state.plan.find(d => d.date === date && (d.kind === 'kolo' || d.kind === 'test') && !d.done && d.role !== 'dirka')
      if (!day) continue
      const need = needOf(day, p)
      if (!need) continue
      const fits = (r: RouteRec[]) => { const b = suggestRoutes(r, need, p, state.today, k, lib.home)[0]; return b ? Math.abs(b.estMin - need.minutes) / need.minutes <= 0.12 : false }
      const gen = recs.filter(r => r.source === 'nova' && r.date === date)
      if (gen.length && fits(gen)) continue   // že narisana in ustreza
      // ustreza vsaj ena tvoja trasa (čas ±12 %, start doma) → brez nove; menjavo med njimi uredi točkovanje
      const own = suggestRoutes(recs.filter(r => r.source === 'voznja'), need, p, state.today, k, lib.home)
      const ownFits = own.some(s => Math.abs(s.estMin - need.minutes) / need.minutes <= 0.12 && (!lib.home || haversineM(lib.home, s.rec.start) < 3000))
      if (ownFits) continue
      if (gen.length && (await getKV<string>(`routes.retry.${date}`)) === state.today) continue   // danes že poskušeno
      await setKV(`routes.retry.${date}`, state.today)
      const seed = [...date].reduce((h, ch) => (h * 31 + ch.charCodeAt(0)) % 1000, 7) + (gen.length ? 13 : 0)
      try { await newRouteFor(day, seed, true) } catch { /* brez omrežja ali BRouter ne najde poti — ostane predlog iz voženj */ }
    }
  } finally { autoRoutesRunning = false }
}

/* ---------- testni program ---------- */
const anonId = () => Array.from(crypto.getRandomValues(new Uint8Array(8)), b => b.toString(16).padStart(2, '0')).join('')
/** Odgovor (a–d) na tedensko vprašanje: anonimno na strežnik, stanje v nastavitve (usklajeno med napravami). */
export async function answerPilot(q: PilotQ, a: string): Promise<void> {
  const s0 = state.settings.pilot || {}
  const id = s0.id || anonId()
  const start = state.profile.goalStart?.date ?? state.profile.createdAt?.slice(0, 10) ?? null
  const day = start ? Math.round((Date.parse(state.today) - Date.parse(start)) / 86_400_000) : null
  void sendPilot({ anon: id, code: s0.code ?? null, q, a, day, v: APP_VERSION })
  await updateSettings({ pilot: { ...afterAsk(s0, q, state.today), id } })
}
/** Preskok: to vprašanje in ta teden sta mimo (nič se ne pošlje). */
export async function skipPilot(q: PilotQ): Promise<void> { await updateSettings({ pilot: afterAsk(state.settings.pilot, q, state.today) }) }
export async function optOutPilot(): Promise<void> { await updateSettings({ pilot: { ...(state.settings.pilot || {}), optOut: true } }); toast('Vprašanj ne bo več. Hvala!', 'info') }

/* ---------- privolitev za AI ---------- */
export async function grantAiConsent() { await updateProfile({ aiConsentAt: new Date().toISOString(), aiConsentV: CONSENT_V }) }
export async function revokeAiConsent() { await updateProfile({ aiConsentAt: null }); toast('AI obdelava izklopljena. Tvoji podatki ostanejo; nasveti se ustavijo.', 'info') }

let toastId = 0
/** (v3.50) največ toliko obvestil hkrati (eno nad drugim) — prej je novo tiho prepisalo prejšnje */
export const MAX_TOASTS = 3
/**
 * Obvestilo. (v3.50) Vrsta: novo se doda k vidnim (isto besedilo se ne podvoji); napaka ne izgine sama (zapre jo
 * tap, × ali Esc); action = gumb v obvestilu (npr. »Osveži«), takšno ostane vsaj 8 s.
 * Vrne id (v3.50) — za dismissToast, ko stanje, o katerem obvestilo govori, mine (usklajevanje spet dela).
 */
export function toast(msg: string, kind: 'ok' | 'err' | 'info' = 'info', ms = 4200, action?: ToastAction): number {
  const id = ++toastId
  const t: Toast = { msg, kind, id, ...(action ? { action } : {}) }
  const next = trimToasts([...(state.toasts ?? []).filter(x => x.msg !== msg), t])
  set({ toasts: next, toast: t })
  if (kind !== 'err') setTimeout(() => dismissToast(id), action ? Math.max(ms, 8000) : ms)
  return id
}
/**
 * (v3.51) Preveč obvestil: najprej gre najstarejše, ki NI napaka — napaka ostane, dokler je ne zapreš (prej so jo
 * tri informativna obvestila tiho izrinila, tudi »Oblak ne sprejema sprememb« z gumbom »Prijava znova«).
 */
export function trimToasts(list: Toast[], max = MAX_TOASTS): Toast[] {
  const out = [...list]
  while (out.length > max) {
    // najnovejše ostane vedno; med starejšimi gre najprej najstarejše, ki ni napaka
    const i = out.findIndex((x, j) => x.kind !== 'err' && j < out.length - 1)
    out.splice(i < 0 ? 0 : i, 1)
  }
  return out
}
/** Zapri obvestilo (tap nanj, v3.48); z id samo tisto, brez id zadnje (Esc). */
export function dismissToast(id?: number): void {
  const list = state.toasts ?? (state.toast ? [state.toast] : [])
  const target = id ?? list[list.length - 1]?.id
  if (target == null || !list.some(t => t.id === target)) return
  const next = list.filter(t => t.id !== target)
  set({ toasts: next, toast: next[next.length - 1] ?? null })
}

export function applyAccent(hex: string) {
  if (!/^#[0-9a-fA-F]{6}$/.test(hex)) return
  const r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b = parseInt(hex.slice(5, 7), 16)
  const root = document.documentElement.style
  root.setProperty('--accent', hex)
  // mehka podlaga (--accent-soft) je v tokens.css iz --accent-rgb — v svetli temi z večjim deležem
  root.setProperty('--accent-rgb', `${r}, ${g}, ${b}`)
  // besedilo v barvi poudarka v svetli temi: temnejši odtenek istega tona (≥ 4,5 : 1)
  root.setProperty('--accent-deep', accentDeep(hex))
}

/* ---------- (v3.52) Garmin Connect neposredno ---------- */
/*
 * (v3.52 LENO) Prenos, odklop, možnosti in pošiljanje treningov/tras so v ./garminStore (ni v začetnem paketu; G08).
 * Tu ostanejo: tipi, polja stanja, čiste sinhrone funkcije (garminAllows, garminPushOn, garminPreview, combinedWellness)
 * in TANKI OVOJI z istimi imeni in podpisi, ki modul naložijo ob prvem klicu. Ob zagonu se modul naloži samo,
 * ko je Garmin povezan ali gre za vrnitev z Garmina (?garmin=…) — brez Garmina se ne prenese nikoli.
 */
export interface GarminSyncResult { added: number; upgraded: number; healthDays: number; cycleDays: number; error: string | null; skipped: string | null }
/** Zadnje pošiljanje treningov na Garmin (KV garmin.workouts): koliko poslanih, posodobljenih, pobrisanih, napake po dnevih. */
export interface GarminWorkoutsInfo { at: string; n: number; created: number; updated: number; removed: number; errors: { date: string; error: string }[]; err: string | null }
export interface AppState {
  /** (v3.52) treningi na uro neposredno na Garmin: zadnje pošiljanje (null = še nikoli) */
  garminWorkouts?: GarminWorkoutsInfo | null
}
export const GARMIN_CONNECT_ERR = 'Povezava z Garmin Connect ni uspela — Garmin je povezavo zavrnil ali je potekel čas (10 min). Na Uvozu tapni »Poveži z Garmin Connect« in jo znova potrdi.'
/** Ključi na napravi, ki jih bere že začetni paket (ostali so v garminStore): dnevi z ure z Garmina, cikel, zadnje pošiljanje treningov. */
export const G_WELL = 'garmin.wellness', G_CYCLE = 'garmin.cycle', GW_KEY = 'garmin.workouts'

/** Dnevi z ure, kot jih vidi aplikacija: intervals.icu (wellness.v1) + Garmin neposredno (garmin.wellness), Garmin ima prednost. */
export async function combinedWellness(icuDays?: WellnessDay[] | null): Promise<WellnessDay[] | null> {
  const icu = icuDays !== undefined ? icuDays : ((await getKV<{ at: number; days: WellnessDay[] }>(WELL_KEY))?.days ?? null)
  const g = state.settings.garmin?.connected && state.settings.garmin.health === true ? ((await getKV<{ at: number; days: WellnessDay[] }>(G_WELL))?.days ?? null) : null
  const all = mergeWellness(state.settings.wellnessOn ? icu : null, g)
  return all.length ? all : null
}
/** Ob zagonu: zadnje stanje pošiljanja na Garmin v pomnilnik (za Nastavitve). */
export async function loadGarminWorkoutsInfo(): Promise<void> {
  const i = await getKV<GarminWorkoutsInfo>(GW_KEY).catch(() => undefined)
  if (i) set({ garminWorkouts: i })
}
/** Dovoljenje: neznan seznam (null) = dovoli (strežnik odloči); znan seznam mora vsebovati ključ. */
export function garminAllows(g: GarminSettings | null | undefined, perm: 'ACTIVITY_EXPORT' | 'HEALTH_EXPORT' | 'MCT_EXPORT' | 'WORKOUT_IMPORT' | 'COURSE_IMPORT'): boolean {
  return !!g?.connected && (!Array.isArray(g.permissions) || g.permissions.includes(perm))
}
/** Ali so treningi na Garmin vklopljeni: povezan, pošiljanje ni izklopljeno, dovoljenje WORKOUT_IMPORT (ali dovoljenj še ne poznamo). */
export function garminPushOn(s: Settings = state.settings): boolean {
  const g = s.garmin
  return !!g?.connected && g.pushWorkouts !== false && (!g.permissions?.length || g.permissions.includes('WORKOUT_IMPORT'))
}
/** Trening dneva, kot bi šel na Garmin (za predogled v UI); null, če dan ne gre na uro. */
export const garminPreview = (day: PlanDay): GarminWorkout | null => garminWorkout(day, state.profile)

/** Garmin je v igri: povezan (nastavitve) ali vrnitev z Garmina (?garmin=ok|err) — šele takrat se njegov del kode prenese. */
function garminInPlay(): boolean {
  return !!state.settings.garmin?.connected || (typeof location !== 'undefined' && /[?&]garmin=/.test(location.search))
}
/** Modul se prenese ob prvem klicu; če ne pride (brez povezave, nova objava), obvestilo in izid »nič se ni zgodilo« — ovoji nikoli ne vržejo (kot prej). */
const GARMIN_LOAD_ERR = 'Del aplikacije za Garmin se ni prenesel — preveri povezavo in poskusi znova.'
async function withGarmin<T>(run: (m: typeof import('./garminStore')) => Promise<T>, fallback: T): Promise<T> {
  let m: typeof import('./garminStore')
  try { m = await import('./garminStore') } catch { toast(GARMIN_LOAD_ERR, 'err', 7000); return fallback }
  return run(m)
}
/** »Poveži z Garmin Connect« (gumb na Uvozu): preusmeritev na strežnik → Garmin. Brez prijave obvestilo. */
export const connectGarmin = (): Promise<void> => withGarmin(m => m.connectGarmin(), undefined)
/** Ob zagonu: vrnitev z Garmina (?garmin=ok|err) → nastavitve, obvestilo, prvi prenos. Vrne true, če je bila to vrnitev z Garmina. */
export const finishGarminConnect = (): Promise<boolean> => withGarmin(m => m.finishGarminConnect(), false)
/** Stanje s strežnika v nastavitve (dovoljenja, prekinjena povezava) — največ enkrat na dan, ali ročno. Brez povezave ali prijave null (brez prenosa modula). */
export const refreshGarminStatus = (force = false): Promise<GarminStatus | null> => (state.settings.garmin?.connected && state.user ? withGarmin(m => m.refreshGarminStatus(force), null) : Promise.resolve(null))
/** Prenos s strežnika: aktivnosti, zdravje (ob vklopu) in cikel (ob vklopu) — največ na 10 min (force: takoj). Brez povezave null (brez prenosa modula). */
export const syncGarmin = (force = false): Promise<GarminSyncResult | null> => (state.settings.garmin?.connected ? withGarmin(m => m.syncGarmin(force), null) : Promise.resolve(null))
/** »Odklopi Garmin«: strežnik odjavi, zdravje in cikel s te naprave stran, settings.garmin = null. VOŽNJE OSTANEJO. */
export const disconnectGarmin = (): Promise<boolean> => withGarmin(m => m.disconnectGarmin(), false)
/** Pred izbrisom računa: Garminu povemo, da soglasja ni več; napaka ne ustavi izbrisa. Brez povezave nič (brez prenosa modula). */
export const garminBeforeAccountDelete = (): Promise<void> => (state.settings.garmin?.connected ? withGarmin(m => m.garminBeforeAccountDelete(), undefined) : Promise.resolve())
/** Možnosti Garmina: health, cycle, pushWorkouts, pushCourses (vklop prenese/pošlje, izklop izbriše/pobriše). Brez nastavitve nič. */
export const setGarminOpt = (key: 'health' | 'cycle' | 'pushWorkouts' | 'pushCourses', on: boolean): Promise<void> => (state.settings.garmin ? withGarmin(m => m.setGarminOpt(key, on), undefined) : Promise.resolve())
/** Treningi naslednjih 14 dni → Garmin. manual = gumb v Nastavitvah (obvestilo tudi ob »nič novega«). Brez vklopa null (brez prenosa modula). */
export const pushGarminWorkouts = (manual = false): Promise<GarminWorkoutsInfo | null> => (garminPushOn() ? withGarmin(m => m.pushGarminWorkouts(manual), null) : Promise.resolve(null))
/** Naši prihodnji treningi pri Garminu stran. Vrne število pobrisanih ali null ob napaki. Brez povezave null (brez prenosa modula). */
export const removeGarminWorkouts = (): Promise<number | null> => (state.settings.garmin?.connected ? withGarmin(m => m.removeGarminWorkouts(), null) : Promise.resolve(null))
/** Trasa dneva na Garmin (Courses API). Vrne courseId ali null (napaka je v obvestilu). */
export const pushGarminCourse = (day: PlanDay, rec?: RouteRec | null): Promise<string | number | null> => withGarmin(m => m.pushGarminCourse(day, rec), null)
