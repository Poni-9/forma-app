import { useSyncExternalStore } from 'react'
import type { Activity, DailyCheckin, Focus, MealEntry, PlanDay, Profile, Race, Settings, TestEntry, WeekMenu } from '@/domain/types'
import * as repo from '@/data/repo'
import { migrateFromV1, repairAfterPreview, carryIntervalsFromV1, finishLegacyV1 } from '@/data/migrate'
import { todayIso, addDays, weekStartIso, estimateTss, formSeries } from '@/domain/training/load'
import { fetchActivities, fetchAthlete, fetchEvents, createEvents, updateEvent, deleteEvent, fetchWellness, icuReady, setIcuQuotaStore, icuBudget, icuErrorKind, disconnectApp, IcuError, type IcuErrKind, type IcuQuota } from '@/domain/intervals/client'
import type { WellnessDay } from '@/domain/wellness'
import { finishIcuOAuth } from '@/data/icuOauth'
import { capturePilotCode, flushPilot, sendPilot } from '@/data/pilot'
import { afterAsk, type PilotQ } from '@/domain/pilot'
import { APP_VERSION, PROXY } from '@/config'
import { plural, count, W, NBSP, dayGen } from '@/ui/format'
import { icuWorkout, workoutDiff, type IcuWorkout } from '@/domain/intervals/workouts'
import type { IcuDiag } from '@/domain/intervals/diagnosis'
import { powerMeterFrom, baselineHours, moveKeySession } from '@/domain/training/review'
import { missedKeys, applyMissed } from '@/domain/training/missed'
import { easyFeltHard } from '@/domain/coach/rpe'
import { raceLock } from '@/domain/training/protect'
import { undoToast } from '@/ui/Confirm'
import { hoursAdvice } from '@/domain/training/goal'
import { buildWeek, weekContext, hikeSwap, swapBack, coreOnDemand, adaptAfterLoad, undoLoadAdapt, type LoadAdapt } from '@/domain/training/planner'
import { offSeasonNow } from '@/domain/training/goalChange'
import { OFF_MIX } from '@/domain/training/offMix'
import { loadRouteLib, fillRouteLib, addGenerated, routesOf, libSig, ROUTE_STREAMS_PER_RUN, type RouteLib } from '@/data/routes'
import { needOf, suggestRoutes, paceFactor, paceAdj, workoutMinutes } from '@/domain/routes/match'
import { makeLoop, routedToRec, knownRoads } from '@/domain/routes/brouter'
import { climbTurnPoint, type RouteRec } from '@/domain/routes/analyze'
import { climbCandidates, pickClimbLoop, intervalStops, viaOf } from '@/domain/routes/climbLoop'
import { haversineM, decodePolyline, type LatLon } from '@/domain/import/polyline'
import { getKV, setKV, pruneKV } from '@/data/db'
import { trapErrors, flushFeedback } from '@/data/feedback'
import { accentDeep } from '@/ui/theme'
import { profileFromFocus, weekLine, mixLine, trainingDays } from '@/domain/focus/model'
import { daysLine } from '@/domain/focus/choices'
import { onAuth, signInGoogle, signOutNow, idToken, proFromFirestore, setAccountDeleteHooks, deleteAccount as deleteAccountOnServer, type AuthUser } from '@/data/firebase'
import { startSync, stopSync, touch, onSyncStatus, pushNow, syncNow, syncOwner, forgetRemote, type SyncStatus, type FirstSyncResult } from '@/data/sync'
import { tombTest, tombAct, stableStr, mergeCoach } from '@/data/merge'
import { restoreBackup, type ParsedBackup } from '@/data/backup'
import { sickify, unsickify, sickPeriod } from '@/domain/training/sick'
import { readState, adaptToState, undoState, load3, type StateMode, type StateRead } from '@/domain/training/state'
import { readinessOf } from '@/domain/readiness'
import { recoveryOf } from '@/domain/wellness'
import { aiAllowed } from '@/domain/import/provenance'
import { bestPlanMatch } from '@/domain/training/plandays'
import { dailyTarget, activityKcal } from '@/domain/nutrition/energy'
import { forecast, cachedForecast, windowOf, WINDOW_NAMES, type Forecast } from '@/domain/weather'
import { haptic } from '@/ui/haptic'

/** En vir resnice za UI. Piše se prek akcij, ki hkrati posodobijo IndexedDB, sprožijo sinhronizacijo in izris. */
export interface AppState {
  ready: boolean
  profile: Profile
  settings: Settings
  activities: Activity[]
  /** načrt za trenutni teden ± 2 tedna */
  plan: PlanDay[]
  mealsToday: MealEntry[]
  /** obroki zadnjih 90 dni (zgodovina, pogosti obroki, graf) */
  recentMeals: MealEntry[]
  checkinToday: DailyCheckin | null
  /** vsi jutranji vnosi (teža, spanec, počutje) */
  checkins: DailyCheckin[]
  weather: Forecast | null
  today: string
  toast: { msg: string; kind: 'ok' | 'err' | 'info'; id: number } | null
  migration: { activities: number; meals: number; plan: number } | null
  user: AuthUser | null
  /** null = še ne vemo (Firebase se nalaga) */
  authKnown: boolean
  sync: SyncStatus
  /** neomejen AI (proUsers/{uid}.pro na strežniku) */
  pro: boolean
  /** knjižnica tras (samo na tej napravi) */
  routeLib: RouteLib | null
  routesBusy: boolean
  /** treningi na uro: zadnje pošiljanje v koledar intervals.icu */
  icuWorkouts: IcuWorkoutsInfo | null
  /** zadnji uvoz iz intervals.icu: koliko je vrnil, koliko uporabnih, koliko Stravinih (za pošteno pojasnilo) */
  icuDiag: IcuDiag | null
  /**
   * Prvo usklajevanje z oblakom po prijavi: null = še teče (ali ni prijave); 'ok' = račun ima podatke (prevzeti);
   * 'empty' = račun je bil prazen (ta naprava je poslala svoje); 'error' = ni uspelo (NI prazen račun — ne začni uvoda).
   * Za staro rabo kot boolean: firstSyncDone(state).
   */
  firstSync: FirstSyncResult | null
  /** spanec, HRV, mirovni utrip z ure (intervals.icu) — samo na tej napravi, samo ob vklopu */
  wellness: WellnessDay[] | null
  /** prijava z drugim računom, kot mu pripadajo podatki na tej napravi — sinhronizacija čaka na odločitev */
  accountClash: AccountClash | null
  /** zadnja napaka povezave z intervals.icu (null = zadnji uvoz je uspel) */
  icuErr: IcuErrState | null
  /** dokument v oblaku je bil izbrisan na drugi napravi — sinhronizacija ustavljena, odjavljen */
  syncDeleted: { at: number } | null
  /** spremembe načrta: kaj je aplikacija (ali ti) spremenila in zakaj — Plan → Spremembe načrta (samo ta naprava) */
  changes: PlanChange[]
}
/** Ena sprememba načrta za »Spremembe načrta«: auto = aplikacija sama (ne tvoj klik). */
export interface PlanChange { at: string; text: string; auto: boolean }
export interface IcuWorkoutsInfo { at: string; n: number; changed: number; removed: number; err: string | null }
/** Drug račun na isti napravi: prevUid = račun, ki mu pripadajo lokalni podatki. */
export interface AccountClash { prevUid: string; prevEmail?: string }
/** Napaka intervals.icu za prikaz: auth = poveži znova, quota = počakaj (until), network = ni omrežja, other. */
export interface IcuErrState { at: number; kind: IcuErrKind; msg: string; until?: number | null }

let state: AppState = {
  ready: false, profile: repo.defaultProfile(), settings: repo.defaultSettings(), activities: [], plan: [], mealsToday: [], recentMeals: [], checkinToday: null, checkins: [], weather: null,
  today: todayIso(), toast: null, migration: null, user: null, authKnown: false, sync: { state: 'off' }, pro: false, routeLib: null, routesBusy: false, icuWorkouts: null, icuDiag: null, firstSync: null, wellness: null,
  accountClash: null, icuErr: null, syncDeleted: null, changes: [],
}
const subs = new Set<() => void>()
function emit() { for (const s of subs) s() }
function set(patch: Partial<AppState>) { state = { ...state, ...patch }; emit() }

export function useApp(): AppState {
  return useSyncExternalStore(cb => { subs.add(cb); return () => subs.delete(cb) }, () => state, () => state)
}
export function getState() { return state }
/** Prvo usklajevanje po prijavi je končano (uspešno ali ne) — nadomestek za nekdanji boolean firstSync. */
export function firstSyncDone(s: Pick<AppState, 'firstSync'> = state): boolean { return s.firstSync != null }
/** Prvo usklajevanje je uspelo (račun ima podatke ali je bil prazen). */
export function firstSyncOk(s: Pick<AppState, 'firstSync'> = state): boolean { return s.firstSync === 'ok' || s.firstSync === 'empty' }

/* ---------- zagon ---------- */
let booted = false
// Samodejni uvozi in izpeljave šele po prvem usklajevanju z oblakom: naprava s staro kopijo najprej
// prevzame podatke drugih naprav, šele nato kaj spreminja (največ 8 s čakanja, npr. brez povezave).
let openGate: () => void = () => undefined
const synced = new Promise<void>(r => { openGate = r })
export async function boot() {
  if (booted) return; booted = true
  // pripombe: zadnje napake aplikacije gredo zraven (samo besedilo napake)
  trapErrors()
  // kvota intervals.icu: premor po 429 in dnevna poraba preživita ponovni zagon
  void setIcuQuotaStore({ load: () => getKV<IcuQuota>('icu.quota'), save: q => setKV('icu.quota', q) })
  // izbris računa (tudi z zaslona, ki kliče firebase.deleteAccount neposredno): pred izbrisom ustavi sinhronizacijo
  setAccountDeleteHooks({
    before: () => stopSync(),
    failed: () => { const u = state.user; if (u && !state.accountClash) beginSync(u) },
    pilotId: () => state.settings.pilot?.id ?? null,
  })
  const mig = await migrateFromV1().catch(() => null)
  const fixed = await repairAfterPreview().catch(() => [] as string[])
  const icuCarried = await carryIntervalsFromV1().catch(() => false)
  // ključi prve različice (Stravine vožnje, API ključi) po uspešnem prevzemu stran — sicer bi ostali za vedno
  await finishLegacyV1().catch(() => 0)
  const purged = await repo.purgeExpired().catch(() => 0)
  void pruneKV().catch(() => 0)
  await reloadAll()
  if (purged) void touch()     // potekle (Strava §6.2) naj izginejo tudi iz oblaka
  set({ ready: true, migration: mig && mig.ran && (mig.activities || mig.meals || mig.plan) ? mig : null })
  // enkrat na napravo: kje je razlaga in kako sporočiš, kaj ni jasno (v3.29)
  void getKV<number>('hint.help').then(seen => {
    if (seen || !state.profile.onboardingDone) return
    void setKV('hint.help', 1)
    window.setTimeout(() => toast('Novo: »?« zgoraj razloži, kako aplikacija deluje in kaj pomenijo izrazi; oblaček pošlje pripombo s posnetkom zaslona.', 'info', 9000), 2500)
  }).catch(() => undefined)
  window.setTimeout(() => openGate(), 8000)
  void synced.then(() => deriveFromRides()).then(() => autoMissed())
  if (fixed.length) toast('Počiščeno po preizkusu: ' + fixed.join(', ') + '.', 'info', 6000)
  void refreshWeather(false)
  if (icuCarried) toast('Povezava z intervals.icu je prenesena iz stare aplikacije — vožnje se uvažajo same.', 'info', 7000)
  // testni program: koda povabila iz povezave (?pilot=…) v nastavitve; neposlani odgovori znova
  { const code = capturePilotCode(); if (code && state.settings.pilot?.code !== code) void updateSettings({ pilot: { ...(state.settings.pilot || {}), code } }) }
  void flushPilot()
  // pripombe, ki so čakale (brez povezave ali strežnik še brez poti), po usklajevanju — z žetonom, če si prijavljen
  void synced.then(() => flushFeedback()).catch(() => 0)
  // vrnitev z intervals.icu (»Poveži z intervals.icu«): koda → žeton prek strežnika
  void finishIcuOAuth().then(async r => {
    if (!r) return
    if ('error' in r) { toast(r.error, 'err', 8000); return }
    await updateSettings({ intervals: { athleteId: r.athleteId, apiKey: '', token: r.token, name: r.name || 'intervals.icu', pushWorkouts: false } })
    const ath = await fetchAthlete({ athleteId: r.athleteId, apiKey: '', token: r.token }).catch(() => null)
    if (ath) {
      const p0 = state.profile, patch: Partial<Profile> = {}
      if (ath.ftp && !p0.ftp) patch.ftp = ath.ftp
      if (ath.lthr && !p0.lthr) patch.lthr = ath.lthr
      if (ath.maxHr && !p0.maxHr) patch.maxHr = ath.maxHr
      if (ath.restHr && !p0.restHr) patch.restHr = ath.restHr
      if (Object.keys(patch).length) await updateProfile(patch)
    }
    toast(`Povezano z intervals.icu${r.name ? ` (${r.name})` : ''} — uvažam vožnje …`, 'ok', 6000)
    await setKV('icu.fullDone', false)
    void autoSyncIntervals(true)
  })
  // samodejni uvoz iz intervals.icu: ob zagonu in ob vrnitvi v aplikacijo (največ na 3 ure)
  // enkrat: ponovno preberi leto voženj iz intervals.icu (cone utripa, merilnik moči)
  if (!(await getKV<boolean>('icu.zones.v1'))) { await setKV('icu.fullDone', false); await setKV('icu.autoAt', 0); await setKV('icu.zones.v1', true) }
  void loadRouteLib().then(l => set({ routeLib: l }))
  void getKV<IcuWorkoutsInfo>('icu.workouts').then(i => { if (i) set({ icuWorkouts: i }) })
  void getKV<IcuDiag>('icu.diag').then(d => { if (d) set({ icuDiag: d }) })
  void getKV<IcuErrState>('icu.err').then(e => { if (e && typeof e.msg === 'string' && !state.icuErr) set({ icuErr: e }) })
  void getKV<{ at: number; days: WellnessDay[] }>(WELL_KEY).then(w => { if (w?.days?.length) set({ wellness: w.days }) })
  void synced.then(() => ensureWeeks()).then(() => offMixFix().catch(() => false)).then(() => autoSyncIntervals()).then(() => ensureRoutes()).then(() => autoRoutes()).then(() => schedulePushWorkouts(4000, true))
  // ob vrnitvi v aplikacijo (telefon po vožnji): najprej uskladi z oblakom, nato preveri nove vožnje — največ na 10 min
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') void syncNow({ quick: true }).then(() => autoSyncIntervals()).then(() => ensureRoutes()).then(() => autoRoutes()).then(() => schedulePushWorkouts(4000, true)) })
  // polnoč: osveži »danes«
  setInterval(() => { const t = todayIso(); if (t !== state.today) { set({ today: t }); void reloadAll().then(() => ensureWeeks()).then(() => autoMissed()) } }, 60_000)
  // račun in sinhronizacija — asinhrono, aplikacija dela tudi brez
  // enako stanje (npr. »usklajeno« → »usklajeno«): samo nova ura, brez ponovnega izrisa zaslona
  onSyncStatus(s => { if (s.state === state.sync.state && (s.msg || '') === (state.sync.msg || '')) state = { ...state, sync: s }; else set({ sync: s }) })
  onAuth(u => { void onUser(u) })
}

/* ---------- račun in sinhronizacija ---------- */
let authSeq = 0
/** Prijava/odjava: podatki na napravi pripadajo enemu računu — drug račun se ne združi brez odločitve (accountClash). */
async function onUser(u: AuthUser | null): Promise<void> {
  const seq = ++authSeq
  set({ user: u, authKnown: true })
  if (!u) { stopSync(); set({ pro: false, firstSync: null, accountClash: null }); openGate(); return }
  const owner = await syncOwner().catch(() => null)
  if (seq !== authSeq) return
  if (owner && owner.uid !== u.uid) {
    stopSync()
    set({ accountClash: clashOf(owner), firstSync: null })
    openGate()
    return
  }
  set({ accountClash: null, syncDeleted: null })
  beginSync(u)
  void checkPro()
}
const clashOf = (o: { uid: string; email: string | null } | null): AccountClash => ({ prevUid: o?.uid || '', ...(o?.email ? { prevEmail: o.email } : {}) })

function beginSync(u: AuthUser): void {
  set({ firstSync: null })
  startSync(u.uid, () => { void reloadAll() }, r => { openGate(); void reloadAll().then(() => set({ firstSync: r })) }, {
    email: u.email,
    onDeleted: () => { void onCloudDeleted() },
    onClash: () => { void syncOwner().then(o => set({ accountClash: clashOf(o), firstSync: null })) },
  })
}

/** Dokument v oblaku je izbrisan na drugi napravi: sinhronizacija je ustavljena, odjava; podatki na napravi ostanejo. */
async function onCloudDeleted(): Promise<void> {
  await forgetRemote().catch(() => undefined)
  set({ syncDeleted: { at: Date.now() }, firstSync: null })
  await signOutNow()
  set({ user: null, pro: false })
  toast('Račun je bil izbrisan na drugi napravi — odjavljen si. Podatki na tej napravi ostanejo, dokler jih ne izbrišeš.', 'info', 10000)
}

export async function reloadAll() {
  const today = todayIso()
  const ws = weekStartIso(today)
  const [profile, settings, activities, plan, mealsToday, recentMeals, checkinToday, checkins, changes] = await Promise.all([
    repo.loadProfile(), repo.loadSettings(), repo.allActivities(), repo.planBetween(addDays(ws, -14), addDays(ws, 20)), repo.mealsOn(today),
    repo.mealsBetween(addDays(today, -90), today), repo.getCheckin(today), repo.allCheckins(), getKV<PlanChange[]>(CHANGES_KEY).catch(() => null),
  ])
  set({ profile, settings, activities, plan, mealsToday, recentMeals, checkinToday: checkinToday || null, checkins, today, changes: Array.isArray(changes) ? changes : [] })
}

/* ---------- spremembe načrta (uporabnik 4. 10.: »težko razumeti, kaj in kako se dogaja«) ---------- */
const CHANGES_KEY = 'plan.changes'
/**
 * Zapiši spremembo načrta (poleg obvestila, ki po nekaj sekundah izgine): Plan → Spremembe načrta. Zadnjih 40;
 * isto besedilo v isti minuti se ne podvoji.
 */
export async function logChange(text: string, auto = true): Promise<void> {
  const t = text.replace(/\s+/g, ' ').trim().slice(0, 320)
  if (!t) return
  const at = new Date().toISOString()
  const list = [{ at, text: t, auto }, ...state.changes.filter(x => !(x.text === t && Date.parse(at) - Date.parse(x.at) < 60_000))].slice(0, 40)
  set({ changes: list })
  await setKV(CHANGES_KEY, list).catch(() => undefined)
}

/**
 * Obnovitev iz varnostne kopije: združi z napravo (nič se ne izbriše), osveži stanje, pošlje v oblak (če si prijavljen)
 * in dopolni tedna načrta. fromBackup: profil in nastavitve iz kopije (nova naprava).
 */
export async function restoreFromBackup(b: ParsedBackup, opts: { fromBackup?: boolean } = {}) {
  const r = await restoreBackup(b, opts)
  await reloadAll()
  if (state.settings.accentHex) applyAccent(state.settings.accentHex)
  if (r.changed) void touch()
  if (state.profile.onboardingDone) await ensureWeeks().catch(() => 0)
  return r
}
/**
 * »Bolan sem«: počitek za `days` dni od danes. Treningi v tem obdobju postanejo počitek (shranjeni v dnevu), prehrana
 * je brez deficita; na uro gre spremenjeni teden sam. Razveljavi v obvestilu.
 */
export async function setSick(days: number): Promise<void> {
  const prev = state.profile.sick ?? null
  const period = { ...sickPeriod(state.today, days), at: new Date().toISOString() }
  await updateProfile({ sick: period })
  const out = sickify(state.plan, period, new Date().toISOString())
  if (out.length) await savePlanDays(out)
  void logChange(`Bolan: počitek do vključno ${dayGen(period.to)} — treningi v tem času so počitek, prehrana brez deficita.`, false)
  undoToast(`Počitek do vključno ${dayGen(period.to)} — treningi so shranjeni, prehrana brez deficita. Hitro ozdravi.`, async () => {
    const back = unsickify(state.plan, period.from, new Date().toISOString())
    if (back.length) await savePlanDays(back)
    await updateProfile({ sick: prev })
  }, { ms: 8000 })
}
/** Bolezen traja dlje: še en dan počitka (obdobje ostane od istega začetka). */
export async function extendSick(): Promise<void> {
  const s = state.profile.sick
  if (!s || s.to < state.today) return
  const period = { ...s, to: addDays(s.to, 1) }
  await updateProfile({ sick: period })
  const out = sickify(state.plan, period, new Date().toISOString())
  if (out.length) await savePlanDays(out)
  toast(`Počitek do vključno ${dayGen(period.to)}.`, 'ok')
}
/** »Spet zdrav«: od danes naprej vrne shranjene treninge; obdobje bolezni se konča včeraj (prehrana spet po načrtu). */
export async function endSick(): Promise<void> {
  const s = state.profile.sick
  if (!s) return
  const back = unsickify(state.plan, state.today, new Date().toISOString())
  if (back.length) await savePlanDays(back)
  await updateProfile({ sick: s.from >= state.today ? null : { ...s, to: addDays(state.today, -1) } })
  if (back.length) void logChange('Spet zdrav: treningi od danes so vrnjeni po načrtu.', false)
  toast(back.length ? 'Dobrodošel nazaj. Treningi so vrnjeni — prve dni vozi lažje, če se ne počutiš povsem dobro.' : 'Dobrodošel nazaj.', 'ok', 7000)
}
/** Zadnji izvoz na tej napravi (opomnik za varnostno kopijo, ko ni prijave). */
export const LAST_EXPORT_KEY = 'backup.lastExportAt'
export async function markExported(): Promise<void> { await setKV(LAST_EXPORT_KEY, new Date().toISOString()) }

/* ---------- samodejni uvoz iz intervals.icu ---------- */
let icuBusy = false
/** Napaka intervals.icu → stanje za prikaz (odjava, kvota, omrežje, drugo). */
function icuErrOf(e: unknown): IcuErrState {
  const kind = icuErrorKind(e)
  const until = e instanceof IcuError && e.until ? e.until : null
  const raw = (e as Error)?.message || ''
  const msg = kind === 'auth' ? 'intervals.icu zavrača dostop — poveži znova.'
    : kind === 'network' ? (raw || 'intervals.icu ni dosegljiv — preveri povezavo.')
    : raw || (kind === 'quota' ? 'intervals.icu: preveč zahtevkov — poskusim znova kasneje.' : 'Uvoz iz intervals.icu ni uspel.')
  return { at: Date.now(), kind, msg, ...(until ? { until } : {}) }
}
/** Zadnja napaka intervals.icu (null = vse v redu); shrani se na napravi, da jo UI pokaže tudi po ponovnem zagonu. */
async function setIcuErr(e: IcuErrState | null): Promise<void> {
  if (stableStr(e) === stableStr(state.icuErr)) return
  set({ icuErr: e })
  await setKV('icu.err', e).catch(() => undefined)
}

interface IcuRun { added: number; error: IcuErrState | null; skipped: string | null }
/**
 * Uvoz iz intervals.icu (samodejni in ročni). Isti zaklep kot ročni uvoz datotek (dvojnikov ni), izbrisane vožnje
 * se ne vrnejo (grob), napaka se razvrsti (odjava, kvota, omrežje) v state.icuErr — nikoli tiho.
 */
async function runIcuImport(force: boolean): Promise<IcuRun> {
  const c = state.settings.intervals
  if (!icuReady(c)) return { added: 0, error: null, skipped: 'Povezava z intervals.icu ni nastavljena.' }
  if (icuBusy) return { added: 0, error: null, skipped: 'Uvoz iz intervals.icu že teče.' }
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return { added: 0, error: null, skipped: 'Ni povezave z internetom.' }
  const last = (await getKV<number>('icu.autoAt')) || 0
  if (!force && Date.now() - last < 10 * 60_000) return { added: 0, error: null, skipped: 'Pravkar preverjeno.' }
  // samodejno preverjanje v ozadju ne porabi več kot dnevni proračun te naprave (ročno »Preveri Garmin« gre vedno)
  if (!force && icuBudget(c).left <= 0) return { added: 0, error: null, skipped: 'Današnja kvota intervals.icu je porabljena — preverim jutri ali ročno.' }
  icuBusy = true
  let added = 0, error: IcuErrState | null = null
  let freshDates: string[] = []
  try {
    await setKV('icu.autoAt', Date.now())
    await repo.withImportLock(async () => {
      const full = !(await getKV<boolean>('icu.fullDone'))
      const today = todayIso()
      const r = await fetchActivities(c, addDays(today, full ? -365 : -21), addDays(today, 1))
      for (const a of r.activities) if (!a.tss) a.tss = estimateTss(a, state.profile)
      await setIcuDiag({ at: new Date().toISOString(), days: full ? 365 : 21, total: r.total, usable: r.activities.length, stravaStubs: r.stravaStubs, known: state.activities.filter(a => a.source === 'intervals').length })
      // sledi ne shranjujemo pri vožnjah — trase gradi knjižnica tras (ensureRoutes), samo na tej napravi
      const before = new Set(state.activities.map(a => a.id))
      // vožnja, ki si jo izbrisal (na tej ali drugi napravi), se ne uvozi znova
      const tomb = await repo.getTomb()
      const res = await repo.addActivities(r.activities.filter(a => !tomb[tombAct(a)]))
      added = res.added
      if (full) await setKV('icu.fullDone', true)
      if (res.added || res.upgraded) {
        const all = await repo.allActivities()
        set({ activities: all }); void touch()
        const fresh = all.filter(a => !before.has(a.id))
        await linkToPlan(fresh)
        freshDates = fresh.map(a => a.date)
        // današnja vožnja: koliko je res porabila proti načrtu → dnevni cilj se je že prilagodil; vprašaj za gorivo
        const ride = fresh.find(a => a.date === state.today && a.sport === 'kolo')
        const t = ride ? dailyTarget(state.profile, state.activities.filter(a => a.date === state.today), state.plan.filter(d => d.date === state.today), state.today) : null
        if (ride && t && adaptAfterLoad(state.profile, state.plan, state.activities, state.today, state.today)?.state !== 'predlog') {
          const f = (n: number) => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '\u202F'), k = activityKcal(ride, state.profile), d = t.plannedWas ? t.burn - t.plannedWas : 0
          toast(`Vožnja z Garmina: ${f(k)} kcal${t.plannedWas && Math.abs(d) >= 50 ? ` (načrt ${f(t.plannedWas)}, ${d > 0 ? '+' : '−'}${f(Math.abs(d))})` : ''} → današnji cilj ${f(t.kcal)} kcal. Na Danes vpiši, kaj si popil in pojedel na kolesu.`, 'info', 10000)
        } else if (res.added) toast(`intervals.icu: ${res.added}${NBSP}${plural(res.added, ['nova vožnja', 'novi vožnji', 'nove vožnje', 'novih voženj'])}.`, 'info', 5000)
      }
    })
    await setIcuErr(null)
    await autoAdapt(freshDates)
    if (state.settings.wellnessOn) await refreshWellness(false)
    // pražni in max utrip iz intervals.icu, če jih še nimamo (največ enkrat na dan)
    const p0 = state.profile
    if ((!p0.lthr || !p0.maxHr) && Date.now() - ((await getKV<number>('icu.athleteAt')) || 0) > 86400_000) {
      await setKV('icu.athleteAt', Date.now())
      const ath = await fetchAthlete(c).catch(() => null)
      if (ath) {
        const patch: Partial<Profile> = {}
        if (ath.lthr && !p0.lthr) patch.lthr = ath.lthr
        if (ath.maxHr && !p0.maxHr) patch.maxHr = ath.maxHr
        if (ath.restHr && !p0.restHr) patch.restHr = ath.restHr
        if (Object.keys(patch).length) await updateProfile(patch)
      }
    }
  } catch (e) {
    error = icuErrOf(e)
    await setIcuErr(error)
  } finally { icuBusy = false }
  await deriveFromRides()
  return { added, error, skipped: null }
}

/**
 * Nove vožnje iz intervals.icu brez klikanja: ob odprtju aplikacije, največ na 10 min (force: takoj).
 * Prvič leto nazaj (zgodovina za formo in napredek), nato zadnje 3 tedne.
 * Vrne število novih; null, ko uvoz ni tekel ALI ni uspel (napaka je v state.icuErr — ni »nove vožnje še ni«).
 */
export async function autoSyncIntervals(force = false): Promise<number | null> {
  const r = await runIcuImport(force)
  await autoMissed()
  return r.skipped || r.error ? null : r.added
}

/**
 * Ključni trening, ki je mimo in ni bil narejen (ali je bila namesto njega lahka vožnja): sam gre na naslednji lahek dan
 * tega tedna (nikoli ob drug trd dan ali tekmo), sicer ta teden odpade. Enkrat na sejo (oznaka missed), z obvestilom.
 * Teče po uvozu z ure (da včerajšnja vožnja že pride) in ob zagonu.
 */
let missedBusy = false
export async function autoMissed(): Promise<void> {
  if (missedBusy || !state.ready || !state.profile.onboardingDone) return
  missedBusy = true
  try {
    // eno sejo naenkrat — po vsaki shranitvi znova (prestavljena seja zasede lahek dan, ki ga naslednja ne sme dobiti)
    const skipped: string[] = []
    let moved: { text: string; src: PlanDay; to: PlanDay } | null = null
    for (let guard = 0; guard < 7; guard++) {
      const m = missedKeys(state.plan, state.activities, state.today, raceLock(state.plan, state.profile))[0]
      if (!m) break
      await updatePlanDays(applyMissed(m))
      if (m.to) moved = { text: m.text, src: m.day, to: m.to }
      else skipped.push(m.text)
    }
    // eno obvestilo: prestavitev z »Razveljavi« (izpuščene v isti vrstici), sicer samo izpuščene
    for (const t of [...(moved ? [moved.text] : []), ...skipped]) void logChange(t)
    if (moved) {
      const { src } = moved
      undoToast([moved.text, ...skipped.map(t => t.replace(/ — ta teden ga ni kam prestaviti.*$/, ' — izpuščen.'))].join(' '), () => undoMissed(src.id), { ms: 10000 })
    } else if (skipped.length) toast(skipped.join(' '), 'info', 9000)
  } finally { missedBusy = false }
}
/** Razveljavi samodejno prestavitev zamujenega ključnega treninga: ciljni dan dobi nazaj svojo vsebino, zamujeni ostane izpuščen. */
export async function undoMissed(srcId: string): Promise<void> {
  const cur = state.plan
  const s0 = cur.find(d => d.id === srcId)
  if (!s0) return
  const now = new Date().toISOString()
  const moved = cur.filter(d => d.adapt?.after === s0.date && d.adapt.prev && !d.adapt.off && !d.done)
  const back = moved.map(d => ({ ...d, ...d.adapt!.prev!, updatedAt: now, adapt: { after: s0.date, off: true } }))
  await updatePlanDays([...back, { ...s0, missed: 'skipped' as const, updatedAt: now }])
  const to = moved[0]
  void logChange(to ? `Razveljavil si prestavitev: ${s0.title} ostane izpuščen, ${dayAccOf(to.date)} je spet po načrtu.` : `${s0.title} ostane izpuščen.`, false)
  toast(to ? `${s0.title} ostane izpuščen — ${dayAccOf(to.date)} je spet po načrtu.` : `${s0.title} ostane izpuščen.`, 'ok')
}
/** »5. 10.« za spremembe načrta */
const dshortOf = (iso: string) => `${+iso.slice(8, 10)}. ${+iso.slice(5, 7)}.`
const dayAccOf = (iso: string) => ['nedelja', 'ponedeljek', 'torek', 'sreda', 'četrtek', 'petek', 'sobota'][new Date(iso + 'T12:00:00Z').getUTCDay()] ?? ''

/**
 * Ročno »Preveri Garmin« / »Uvozi nove«: { added } ali { added, error, kind } — ob napaki pove, kaj je narobe
 * (npr. »intervals.icu zavrača dostop — poveži znova« namesto »Nove vožnje še ni«).
 */
export async function syncIntervals(): Promise<{ added: number; error?: string; kind?: IcuErrKind | 'skipped' }> {
  const r = await runIcuImport(true)
  if (r.error) return { added: r.added, error: r.error.msg, kind: r.error.kind }
  if (r.skipped) return { added: 0, error: r.skipped, kind: 'skipped' }
  return { added: r.added }
}

/* ---------- spanec, HRV, mirovni utrip (intervals.icu) ---------- */
const WELL_KEY = 'wellness.v1'
let wellBusy = false
/** Zadnjih 35 dni (28 za tvoje običajno + teden) — samo ob vklopu, največ na 30 min, samo na tej napravi. */
export async function refreshWellness(force = true): Promise<number | null> {
  const c = state.settings.intervals
  if (!icuReady(c) || !state.settings.wellnessOn || wellBusy) return null
  const prev = await getKV<{ at: number; days: WellnessDay[] }>(WELL_KEY)
  if (!force && prev && Date.now() - prev.at < 30 * 60_000) return prev.days.length
  wellBusy = true
  try {
    const days = await fetchWellness(c, addDays(state.today, -35), state.today)
    await setKV(WELL_KEY, { at: Date.now(), days })
    set({ wellness: days })
    return days.length
  } catch (e) {
    if (icuErrorKind(e) === 'auth') await setIcuErr(icuErrOf(e))
    if (force) toast((e as Error).message, 'err')
    return null
  }
  finally { wellBusy = false }
}
/** Vklop/izklop: ob izklopu se podatki z ure takoj izbrišejo s te naprave. */
export async function setWellnessOn(on: boolean): Promise<void> {
  await updateSettings({ wellnessOn: on })
  if (on) { const n = await refreshWellness(true); if (n != null) toast(n ? `Spanec, HRV in utrip: ${n} dni z ure.` : 'intervals.icu še nima spanca ali HRV — v Garmin Connect preveri, da se »Wellness« deli z intervals.icu.', n ? 'ok' : 'info', 8000) }
  else { await setKV(WELL_KEY, null); set({ wellness: null }) }
}

/** Zadnji izid uvoza (za pojasnilo v Uvozu in na Danes), hrani se na napravi. */
export async function setIcuDiag(d: IcuDiag): Promise<void> {
  await setKV('icu.diag', d); set({ icuDiag: d })
}

/**
 * Kar trener razbere iz tvojih voženj in vpiše v načrt:
 *  - merilnik moči (da/ne) → cilji v vatih ali utripu,
 *  - dejanske ure na teden ob začetku načrta → načrt raste od tu +10 % na teden (sestavi ta in naslednji teden znova).
 */
export async function deriveFromRides(): Promise<void> {
  const p = state.profile, today = state.today
  // samo vožnje, ki smejo v AI: izpeljanke v profilu (merilnik moči, ure) gredo v AI poziv — Strava ne sme niti posredno
  const acts = state.activities.filter(a => aiAllowed(a))
  try {
    if (p.gear.powerMeterAuto !== false || p.gear.powerMeter == null) {
      const pm = powerMeterFrom(acts, today)
      if (pm != null && pm !== p.gear.powerMeter) await updateProfile({ gear: { ...p.gear, powerMeter: pm, powerMeterAuto: true } })
    }
    // »največji napredek«: ko tvoje vožnje pokažejo, da zmoreš več, se ure normalnega tedna dvignejo same (nikoli same ne padejo)
    const pm = state.profile
    if (pm.hoursMode === 'max' && pm.event?.date) {
      const adv = hoursAdvice(acts, pm, today)
      if (pm.hoursPerWeek != null && adv.max >= pm.hoursPerWeek + 0.5) {
        await updateProfile({ hoursPerWeek: adv.max })
        void logChange(`Več ur: tvoje vožnje kažejo, da zmoreš več — normalen teden ${String(pm.hoursPerWeek).replace('.', ',')} → ${String(adv.max).replace('.', ',')} h (od naslednjega tedna).`)
        toast(`Največji napredek: tvoje vožnje kažejo, da zmoreš več — normalen teden ${String(pm.hoursPerWeek).replace('.', ',')} → ${String(adv.max).replace('.', ',')} h (od naslednjega tedna).`, 'info', 9000)
      }
    }
    const p2 = state.profile
    if (p2.event?.date && p2.baseHours == null) {
      const base = baselineHours(acts, today)
      if (base != null) {
        const prof = await updateProfile({ baseHours: base })
        await rebuildFromToday(prof)
        const first = weekContext(prof, weekStartIso(today)).hours
        void logChange(`Načrt po tvojem dejanskem volumnu: zadnjih 8 tednov ${String(base).replace('.', ',')} h na teden → ta teden ${String(first).replace('.', ',')} h, nato +10 % na teden.`)
        toast(`Načrt prilagojen tvojemu dejanskemu volumnu: zadnjih 8 tednov ${String(base).replace('.', ',')} h na teden → ta teden ${String(first).replace('.', ',')} h, nato +10 % na teden.`, 'info', 9000)
      }
    }
  } catch { /* tiho */ }
}

/**
 * Načrt se nikoli ne izteče: ko se začne nov teden in naslednji še ni sestavljen (uvod sestavi samo dva tedna),
 * ga sestavi sam — tudi tekoči teden, če je prazen (prvi zagon po dolgem premoru). Obstoječih dni ne spreminja.
 * Teče ob zagonu (po usklajevanju) in ob polnoči, zato Danes nikoli ne pokaže »Ta teden še ni sestavljen«, ko je cilj znan.
 */
export async function ensureWeeks(): Promise<number> {
  const p = state.profile
  if (!p.onboardingDone || !(p.cycleStart || p.event)) return 0
  const ws = weekStartIso(state.today)
  const rain: Record<string, number> = {}
  if (state.weather) for (const k in state.weather) rain[k] = state.weather[k]!.rain
  const has = (start: string) => state.plan.some(d => d.date >= start && d.date <= addDays(start, 6))
  const out: PlanDay[] = []
  if (!has(ws)) out.push(...buildWeek({ profile: p, activities: state.activities, weekStart: ws, rain, notBefore: state.today, checkins: state.checkins }).filter(d => d.date >= state.today))
  if (!has(addDays(ws, 7))) out.push(...buildWeek({ profile: p, activities: state.activities, weekStart: addDays(ws, 7), rain, notBefore: addDays(ws, 7), checkins: state.checkins }))
  if (!out.length) return 0
  await savePlanDays(out)
  for (const w of [...new Set(out.map(d => weekStartIso(d.date)))]) {
    const c = weekContext(p, w)
    void logChange(`Sestavil sem teden od ${dshortOf(w)}: ${c.phase === 'prehod' ? 'off-season' : c.easy ? 'lahek začetek' : c.recovery ? 'razbremenilni teden' : c.phaseName.toLowerCase()}, ~${String(c.hours).replace('.', ',')} h.`)
  }
  return out.length
}

/** Sestavi ta in naslednji teden znova od danes naprej (opravljeni dnevi ostanejo). */
export async function rebuildFromToday(prof: Profile = state.profile): Promise<void> {
  const ws = weekStartIso(state.today)
  const rain: Record<string, number> = {}
  if (state.weather) for (const k in state.weather) rain[k] = state.weather[k]!.rain
  const doneDates = new Set(state.plan.filter(d => d.done).map(d => d.date))
  // če je danes že opravljen, gradi od jutri (test ali ključni trening ne sme pasti na današnji dan)
  const from = doneDates.has(state.today) ? addDays(state.today, 1) : state.today
  const w1 = buildWeek({ profile: prof, activities: state.activities, weekStart: ws, rain, notBefore: from, checkins: state.checkins })
  const w2 = buildWeek({ profile: prof, activities: state.activities, weekStart: addDays(ws, 7), rain, notBefore: addDays(ws, 7), checkins: state.checkins })
  // dnevi pred danes ostanejo, kakršni so bili
  await savePlanDays([...w1, ...w2].filter(d => d.date >= from && !doneDates.has(d.date)))
}

/* ---------- dogovor s trenerjem (»Sestaviva tvoj načrt«) ---------- */
/**
 * Shrani dogovor: osnovni podatki (spol, starost, višina, teža), dogovor v profil (ure, moč, oprema, prehrana) in
 * načrt od danes za ta in naslednji teden znova (opravljeni dnevi ostanejo). Novi uporabnik dobi vodnik na Danes.
 */
export async function applyAgreement(f: Focus, basics: Partial<Pick<Profile, 'sex' | 'age' | 'heightCm' | 'weightKg' | 'name'>>): Promise<Profile> {
  const first = !state.profile.onboardingDone
  const clean = Object.fromEntries(Object.entries(basics).filter(([, v]) => v != null && v !== '')) as Partial<Profile>
  const base = { ...state.profile, ...clean }
  const ws = weekStartIso(state.today)
  const prof = await updateProfile({ ...clean, ...profileFromFocus(f, base, ws, state.today) })
  if (clean.weightKg) await saveCheckin({ date: state.today, weightKg: clean.weightKg })
  await rebuildFromToday(prof)
  if (first) await updateSettings({ guideSeen: false })
  void logChange(`${first ? 'Načrt' : 'Nov dogovor'}: ${f.title} — ${weekLine(f)} (${mixLine(f)}).`, false)
  return prof
}

/**
 * Dnevi brez časa (»Moj dogovor«): dogovor ostane, ta in naslednji teden se razporedita znova (opravljeno ostane).
 * Vrne false, če bi ostalo manj dni kot vadb — takrat je treba spremeniti dogovor (manj vadb), ne samo dneve.
 */
export async function setOffDays(off: number[]): Promise<boolean> {
  const f = state.profile.focus
  if (!f) return false
  const days = [...new Set(off.filter(d => Number.isInteger(d) && d >= 0 && d <= 6))].sort((a, b) => a - b)
  // samo dnevi — ostalo v dogovoru (strategija, izbor vaj, pojasnila) ostane, kot je; določena seja na dnevu brez časa
  // izgubi dan (razporedi se drugam, kardio po moči gre z njo), ko dan spet gre, ostane prosta
  const sessions = f.sessions.map(s => (s.day != null && days.includes(s.day) ? { ...s, day: null } : s))
  if (days.length > 6 || 7 - days.length < trainingDays(sessions)) return false
  const prefer = (f.preferDays || []).filter(d => !days.includes(d))
  const next: Focus = { ...f, offDays: days.length ? days : null, preferDays: prefer.length ? prefer : null, sessions }
  const prof = await updateProfile({ focus: next })
  await rebuildFromToday(prof)
  void logChange(next.offDays?.length ? `Dnevi brez časa: ${daysLine(next.offDays)} — teden je razporejen znova.` : 'Vsi dnevi gredo — teden je razporejen znova.', false)
  return true
}

/* ---------- tekme, hribi, jedro ---------- */
/** Druge tekme sezone: shrani in takoj prilagodi ta in naslednji teden (kasnejši tedni se prilagodijo, ko pridejo na vrsto). */
export async function saveRaces(races: Race[]): Promise<void> {
  const clean = races.filter(r => r.name.trim() && r.date).sort((a, b) => a.date.localeCompare(b.date))
  const prof = await updateProfile({ races: clean })
  await rebuildFromToday(prof)
  void logChange('Tekme sezone so spremenjene — ta in naslednji teden sta sestavljena znova.', false)
}
/** Glavni cilj (npr. Franja): vrsta, dolžina, vzpon, rang — načrt se prilagodi takoj. */
export async function saveMainGoal(ev: NonNullable<Profile['event']>): Promise<void> {
  const prof = await updateProfile({ event: ev })
  await rebuildFromToday(prof)
  void logChange(`Glavni cilj: ${ev.name} — ta in naslednji teden sta sestavljena znova.`, false)
}
/**
 * Konec sezone → off-season: od tega ponedeljka N tednov počitka in vožnje po občutku (hribi po izbiri), nato trije lahki tedni
 * osnove in test FTP. Makrocikel do ciljev teče od tu naprej.
 */
export async function startOffSeason(weeks: number): Promise<void> {
  const ws = weekStartIso(state.today)
  const prof = await updateProfile({ cycleStart: ws, offSeasonWeeks: Math.max(1, Math.min(6, Math.round(weeks))), offSeasonAt: state.today, offSeasonAskedAt: state.today })
  await rebuildFromToday(prof)
  void logChange(`Začel si off-season (${prof.offSeasonWeeks} ${prof.offSeasonWeeks === 1 ? 'teden' : prof.offSeasonWeeks === 2 ? 'tedna' : prof.offSeasonWeeks! <= 4 ? 'tedne' : 'tednov'}) — počitek, nato osnova.`, false)
}
/** Kaj v off-seasonu (uporabnik izbere): kolo po občutku, kolo in hribi, več hribov — ta in naslednji teden znova. */
export async function setOffMix(mix: NonNullable<Profile['offMix']>): Promise<void> {
  const prof = await updateProfile({ offMix: mix })
  await rebuildFromToday(prof)
  void logChange(`Off-season: ${OFF_MIX[mix].label.toLowerCase()} — ta in naslednji teden sta sestavljena znova.`, false)
}
/**
 * Prej je predloga off-seasona sama dala hribe. Kdor še ni izbral (offMix prazen), dobi prihodnje neopravljene hribe
 * iz predloge enkrat sestavljene znova po privzetem (kolo po občutku); dnevi z zamenjavo »Hribi namesto kolesa« (swap)
 * in opravljeni dnevi ostanejo. Brez hribov iz predloge se ne zgodi nič — zato se ne ponavlja.
 */
export async function offMixFix(): Promise<boolean> {
  const p = state.profile
  if (p.offMix || !offSeasonNow(p, state.today)) return false
  const end = addDays(weekStartIso(state.today), 13)
  const old = state.plan.some(d => d.date >= state.today && d.date <= end && !d.done && d.kind === 'pohod' && !d.swap
    && weekContext(p, weekStartIso(d.date)).phase === 'prehod')
  if (!old) return false
  // ročne zamenjave (»Hribi namesto kolesa«) so njegova odločitev — dnevi z njimi ostanejo, kakršni so
  const keepDates = new Set(state.plan.filter(d => d.date >= state.today && !d.done && d.swap).map(d => d.date))
  const keep = state.plan.filter(d => keepDates.has(d.date) && !d.done)
  await rebuildFromToday(p)
  if (keep.length) await savePlanDays(keep)
  void logChange('Off-season: hribe iz predloge sem zamenjal s kolesom po občutku — kaj delaš, izbereš sam (Danes → Kaj v off-seasonu).')
  toast('Off-season zdaj izbereš sam: privzeto kolo po občutku. Hribe dodaš na Danes pod »Kaj v off-seasonu«.', 'info', 9000)
  return true
}
export async function declineOffSeason(): Promise<void> { await updateProfile({ offSeasonAskedAt: state.today }) }
/** Konec off-seasona prej (začni z osnovo ta teden). */
export async function endOffSeason(): Promise<void> {
  const p = state.profile, ws = weekStartIso(state.today)
  if (!p.cycleStart) return
  const done = Math.max(0, Math.round((new Date(ws).getTime() - new Date(p.cycleStart).getTime()) / (7 * 86400_000)))
  const prof = await updateProfile({ offSeasonWeeks: done })
  await rebuildFromToday(prof)
  void logChange('Off-season končan — osnova začne ta teden z lahkimi tedni.', false)
}
/** Hribi namesto kolesa (in nazaj) — samo ta dan; na uri trening za ta dan izgine (ni več kolo). */
export async function hikeInstead(dayId: string): Promise<void> {
  const d = state.plan.find(x => x.id === dayId); if (!d) return
  await savePlanDay(hikeSwap(d, state.profile))
}
export async function backToBike(dayId: string): Promise<void> {
  const d = state.plan.find(x => x.id === dayId); if (!d?.swap) return
  await savePlanDay(swapBack(d))
}
/** Jedro po želji na izbran dan (neobvezno). */
export async function addCore(date: string): Promise<void> {
  await savePlanDay(coreOnDemand(state.profile, state.activities, date))
}
/** Nastavitve moči (kje, v katerih fazah): shrani in sestavi ta in naslednji teden znova. */
export async function setStrength(patch: Partial<Profile['strength']>, days?: number): Promise<void> {
  const prof = await updateProfile({ strength: { ...state.profile.strength, ...patch }, ...(days != null ? { strengthDays: days } : {}) })
  if (prof.event?.date || prof.cycleStart) { await rebuildFromToday(prof); void logChange('Nastavitve moči so spremenjene — ta in naslednji teden sta sestavljena znova.', false) }
}

/** Ključni trening, ki danes ni bil narejen, gre na naslednji lahki dan; danes dobi vsebino tistega dne. */
export async function moveKeyToLater(dayId: string): Promise<string | null> {
  const d = state.plan.find(x => x.id === dayId)
  if (!d) return null
  const ws = weekStartIso(state.today)
  const week = state.plan.filter(x => x.date >= ws && x.date <= addDays(ws, 6))
  const r = moveKeySession(week, d, state.today, raceLock(state.plan, state.profile))
  if (!r) return null
  await updatePlanDays(r)
  return r[1].date
}

/* ---------- treningi na uro: naslednjih 14 dni načrta → koledar intervals.icu → Garmin Connect → ura ---------- */
let pushTimer: number | null = null, pushBusy = false
/** Pošlji z zamikom (več sprememb načrta zapored = eno pošiljanje). ifStale: samo, če je od zadnjega minilo > 6 h. */
export function schedulePushWorkouts(delayMs = 2500, ifStale = false): void {
  if (typeof window === 'undefined') return
  if (ifStale && state.icuWorkouts && !state.icuWorkouts.err && Date.now() - new Date(state.icuWorkouts.at).getTime() < 6 * 3600_000) return
  if (pushTimer) clearTimeout(pushTimer)
  pushTimer = window.setTimeout(() => { pushTimer = null; void pushWorkouts() }, delayMs)
}
export async function pushWorkouts(manual = false): Promise<IcuWorkoutsInfo | null> {
  const c = state.settings.intervals
  if (!icuReady(c) || c.pushWorkouts === false || pushBusy || (typeof navigator !== 'undefined' && navigator.onLine === false)) return null
  const from = state.today, to = addDays(state.today, 13)
  const desired = state.plan.filter(d => d.date >= from && d.date <= to).map(d => icuWorkout(d, state.profile)).filter((w): w is IcuWorkout => !!w)
  // nič se ni spremenilo od zadnjega uspešnega pošiljanja (isti treningi, isto okno) → brez klicev (kvota)
  const sig = stableStr({ from, to, desired })
  if (!manual) {
    const last = await getKV<{ sig: string; at: number }>('icu.workouts.sig')
    if (last && last.sig === sig && Date.now() - last.at < 24 * 3600_000 && !state.icuWorkouts?.err) return state.icuWorkouts
    if (icuBudget(c).left <= 0) return null   // dnevni proračun porabljen — samodejno pošiljanje počaka do jutri
  }
  pushBusy = true
  const o = { essential: manual }
  try {
    const existing = await fetchEvents(c, from, to, o)
    const diff = workoutDiff(desired, existing)
    // novi in spremenjeni (naš uid) v enem zahtevku (upsert po uid); ostali posodobitve posebej
    const byId = new Map(existing.map(e => [e.id, e] as const))
    const bulk = [...diff.create, ...diff.update.filter(u => byId.get(u.id)?.uid === u.w.uid).map(u => u.w)]
    if (bulk.length) await createEvents(c, bulk, o)
    for (const u of diff.update) if (byId.get(u.id)?.uid !== u.w.uid) await updateEvent(c, u.id, u.w, o)
    for (const id of diff.remove) await deleteEvent(c, id, o)
    const changed = diff.create.length + diff.update.length
    const info: IcuWorkoutsInfo = { at: new Date().toISOString(), n: desired.length, changed, removed: diff.remove.length, err: null }
    await setKV('icu.workouts', info); set({ icuWorkouts: info })
    await setKV('icu.workouts.sig', { sig, at: Date.now() })
    if (manual) toast(changed || diff.remove.length
      ? `Na uro: ${changed ? `${changed}${NBSP}${plural(changed, ['poslan trening', 'poslana treninga', 'poslani treningi', 'poslanih treningov'])}` : ''}${changed && diff.remove.length ? ', ' : ''}${diff.remove.length ? `${diff.remove.length}${NBSP}${plural(diff.remove.length, ['pobrisan', 'pobrisana', 'pobrisani', 'pobrisanih'])}` : ''} — Garmin jih prenese ob naslednji sinhronizaciji.`
      : `Koledar intervals.icu je že enak načrtu (${count(desired.length, W.trening)}).`, 'ok', 7000)
    return info
  } catch (e) {
    const info: IcuWorkoutsInfo = { at: new Date().toISOString(), n: 0, changed: 0, removed: 0, err: (e as Error)?.message || 'napaka' }
    await setKV('icu.workouts', info); set({ icuWorkouts: info })
    if (icuErrorKind(e) === 'auth') await setIcuErr(icuErrOf(e))
    if (manual) toast(info.err!, 'err', 7000)
    return null
  } finally { pushBusy = false }
}
/** Izklop »treningov na uro«: naše (formai-…) dogodke od danes naprej pobrišemo iz koledarja, da jih Garmin umakne z ure. Vrne število pobrisanih ali null ob napaki. */
export async function removeWorkouts(): Promise<number | null> {
  const c = state.settings.intervals
  if (!icuReady(c) || pushBusy) return null
  pushBusy = true
  const o = { essential: true }
  try {
    const existing = await fetchEvents(c, state.today, addDays(state.today, 30), o)
    const { remove } = workoutDiff([], existing)
    for (const id of remove) await deleteEvent(c, id, o)
    const info: IcuWorkoutsInfo = { at: new Date().toISOString(), n: 0, changed: 0, removed: remove.length, err: null }
    await setKV('icu.workouts', info); set({ icuWorkouts: info })
    await setKV('icu.workouts.sig', null)
    return remove.length
  } catch (e) {
    if (icuErrorKind(e) === 'auth') await setIcuErr(icuErrOf(e))
    toast((e as Error)?.message || 'Brisanje iz koledarja ni uspelo.', 'err', 7000)
    return null
  } finally { pushBusy = false }
}

/* ---------- vreme ---------- */
export async function refreshWeather(force = true): Promise<Forecast | null> {
  const pl = state.profile.place
  if (!pl) { set({ weather: null }); return null }
  try {
    const win = windowOf(state.profile.trainTime), wn = WINDOW_NAMES[state.profile.trainTime || 'popoldne']
    if (!force) { const c = await cachedForecast(pl.lat, pl.lon, win); if (c) set({ weather: c }) }
    const f = await forecast(pl.lat, pl.lon, win, wn); set({ weather: f }); return f
  } catch { return state.weather }
}

/* ---------- akcije ---------- */
// zapisi profila in nastavitev eden za drugim: vsak popravek se uporabi na zadnjem SHRANJENEM stanju (ne na morda
// zastarelem stanju zaslona) — sicer bi star posnetek (npr. brez žetona intervals.icu) dobil nov čas in prepisal novejše
let profileQ: Promise<unknown> = Promise.resolve()
let settingsQ: Promise<unknown> = Promise.resolve()
function queued<T>(q: 'p' | 's', fn: () => Promise<T>): Promise<T> {
  const prev = q === 'p' ? profileQ : settingsQ
  const run = prev.then(fn, fn)
  if (q === 'p') profileQ = run.catch(() => undefined); else settingsQ = run.catch(() => undefined)
  return run
}
export async function updateProfile(patch: Partial<Profile>) {
  const p = await queued('p', async () => repo.saveProfile({ ...(await repo.loadProfile()), ...patch }))
  set({ profile: p }); void touch()
  if ('place' in patch || 'trainTime' in patch) void refreshWeather(true)
  return p
}
export async function updateSettings(patch: Partial<Settings>) {
  // kar je uporabnik videl (pogovor na zaslonu) — za razlikovanje »Nov pogovor« od selitve na prazni napravi
  const seen = state.settings.coach
  const saved = await queued('s', async () => {
    const cur = await repo.loadSettings()
    const next: Settings = { ...cur, ...patch }
    if ('coach' in patch) next.coach = coachWithMeta(cur.coach, patch.coach, seen)
    return repo.saveSettings(next)
  })
  set({ settings: { ...repo.defaultSettings(), ...saved } }); void touch()
  if (patch.accentHex) applyAccent(patch.accentHex)
}
/**
 * Pogovor s trenerjem: prazen seznam, ko je uporabnik na zaslonu VIDEL sporočila = »Nov pogovor« (clearedAt — velja na
 * vseh napravah). Prazen seznam z naprave, ki pogovora še ni imela (selitev starega pogovora pred prvim usklajevanjem),
 * NI izbris — tudi če je sinhronizacija medtem že zapisala pogovor z računa. foldedTo in summaryAt ostaneta.
 */
function coachWithMeta(prev: Settings['coach'], next: Settings['coach'], seen: Settings['coach'] | undefined): Settings['coach'] {
  if (!next) return next ?? null
  const now = new Date().toISOString()
  const explicit = !!next.clearedAt && next.clearedAt !== prev?.clearedAt
  if (explicit || (!!seen?.msgs?.length && !!prev?.msgs?.length && !next.msgs?.length)) {
    return { msgs: next.msgs || [], summary: null, clearedAt: explicit ? next.clearedAt! : now }
  }
  // sicer: unija s shranjenim (kot pri usklajevanju) — zastarel posnetek zaslona ne izgubi sporočil, ki jih je
  // medtem prinesla sinhronizacija; strnjeno (foldedTo) in izbrisano (clearedAt) ostane izbrisano
  const summaryAt = !next.summary ? null : next.summaryAt ?? (next.summary === (prev?.summary ?? null) ? prev?.summaryAt ?? null : now)
  return mergeCoach(prev, { ...next, summary: next.summary ?? null, ...(summaryAt ? { summaryAt } : {}) }) ?? null
}
/** »Nov pogovor« s trenerjem: izbriše pogovor in povzetek na vseh napravah (clearedAt). */
export async function newCoachChat(): Promise<void> {
  await updateSettings({ coach: { msgs: [], summary: null, clearedAt: new Date().toISOString() } })
}
/** Ročni uvoz (datoteke, arhiv, posnetek, »Uvozi nove«): isti zaklep kot samodejni uvoz, izbrisane (grob) se ne vrnejo. */
export async function addActivities(list: Activity[]) {
  return repo.withImportLock(async () => {
    const before = new Set(state.activities.map(a => a.id))
    const tomb = await repo.getTomb()
    const r = await repo.addActivities(list.filter(a => !tomb[tombAct(a)]))
    const all = await repo.allActivities()
    set({ activities: all }); void touch()
    const fresh = all.filter(a => !before.has(a.id))
    await linkToPlan(fresh)
    return { r, dates: fresh.map(a => a.date) }
  }).then(async x => { await autoAdapt(x.dates); return x.r })
}

/**
 * Po pretežki vožnji (včeraj ali danes) se dan za tem olajša sam: ključni trening gre na primeren lahki dan, lahka vožnja
 * postane regeneracija. Enkrat na dan (oznaka adapt ostane tudi po »Vrni prvotni načrt« in se prenese na druge naprave).
 */
async function autoAdapt(dates: readonly string[]): Promise<void> {
  for (const date of [...new Set(dates)].filter(d => d >= addDays(state.today, -1) && d <= state.today).sort()) {
    const r = adaptAfterLoad(state.profile, state.plan, state.activities, date, state.today)
    if (!r || r.state !== 'predlog' || !r.days.length) continue
    await updatePlanDays(r.days)
    void logChange(`${date === state.today ? 'Današnja' : 'Včerajšnja'} vožnja je bila precej težja od načrta (obremenitev ${r.actual} namesto ~${r.planned}). ${r.text}`)
    toast(`${date === state.today ? 'Današnja' : 'Včerajšnja'} vožnja je bila precej težja od načrta (${r.actual}${NBSP}TSS namesto ~${r.planned}). ${r.text}`, 'info', 10000)
  }
}
/** »Prilagodi jutri« na kartici Po današnji vožnji. */
export async function applyLoadAdapt(date: string): Promise<LoadAdapt | null> {
  const r = adaptAfterLoad(state.profile, state.plan, state.activities, date, state.today)
  if (r && r.state === 'predlog' && r.days.length) await updatePlanDays(r.days)
  return r
}
/** »Vrni prvotni načrt«: prilagoditev po pretežki vožnji dneva `date` razveljavi. */
export async function undoLoadAdaptOf(date: string): Promise<void> {
  const days = undoLoadAdapt(state.plan, date)
  // prestavljen zamujeni ključni trening: pretekli dan ni več »prestavljen«, ampak izpuščen
  const src = state.plan.filter(d => d.date === date && d.missed === 'moved').map(d => ({ ...d, missed: 'skipped' as const, updatedAt: new Date().toISOString() }))
  if (days.length || src.length) await updatePlanDays([...days, ...src])
}

/**
 * Uvožena vožnja/vadba odkljuka načrtovano sejo istega dne — samo, če ji ustreza (ista vrsta, vsaj pol načrtovanega
 * trajanja: 20-minutna vožnja v službo ni 4-urna dolga). Poveže se tudi z ročno odkljukanim dnem brez aktivnosti.
 */
async function linkToPlan(acts: readonly Activity[]) {
  let n = 0
  for (const a of acts) {
    if (a.date < addDays(state.today, -21) || state.plan.some(d => d.done?.activityId === a.id)) continue
    const cands = state.plan.filter(x => x.date === a.date && (!x.done || !x.done.activityId))
    const d = bestPlanMatch(a, cands)
    if (!d) continue
    const done = { at: d.done?.at || new Date().toISOString(), activityId: a.id }
    await repo.putPlanDay({ ...d, done })
    state = { ...state, plan: state.plan.map(x => (x.id === d.id ? { ...x, done } : x)) }
    n++
    // vožnja je le prišla pozno: ključni trening, ki smo ga že prestavili kot »ni bil narejen«, gre nazaj — kasnejši dan je spet lahek
    if (d.missed === 'moved') {
      const back = state.plan.filter(x => x.adapt?.after === d.date && x.adapt.prev && !x.done).map(x => ({ ...x, ...x.adapt!.prev!, updatedAt: new Date().toISOString(), adapt: { after: d.date, off: true } }))
      if (back.length) { await repo.putPlanDays(back); void logChange(`${d.title} je vendarle bil narejen (vožnja je prišla z ure pozneje) — ${dayAccOf(back[0]!.date)} je spet lahek dan.`); toast(`${d.title} je vendarle bil narejen — ${dayAccOf(back[0]!.date)} je spet lahek dan.`, 'info', 8000) }
    }
  }
  if (n) { await reloadPlan(); void touch() }
}
export async function saveActivity(a: Activity) { await repo.putActivity(a); set({ activities: await repo.allActivities() }); void touch() }
/** Kako je šlo (RPE 1–10, null = izbriši): na vadbo, če jo dan ima; sicer na dan načrta. Ne pošilja na uro. */
export async function rateSession(o: { activityId?: string | null; dayId?: string | null }, rpe: number | null): Promise<void> {
  const a = o.activityId ? state.activities.find(x => x.id === o.activityId) : null
  if (a) {
    // ročni vnos in datoteka brez moči in utripa: obremenitev iz občutka (prej samo povprečje za šport)
    const est = (a.source === 'manual' || a.source === 'file' || a.source === 'recorder') && !a.avgPower && !a.avgHr
    await saveActivity({ ...a, rpe, ...(est ? { tss: estimateTss({ ...a, rpe }, state.profile) } : {}) })
    return
  }
  const d = o.dayId ? state.plan.find(x => x.id === o.dayId) : null
  if (d) { await repo.putPlanDay({ ...d, rpe }); await reloadPlan(); void touch() }
}
export async function removeActivity(id: string) {
  await repo.deleteActivity(id); set({ activities: state.activities.filter(a => a.id !== id) })
  // dan v načrtu, ki je kazal na to aktivnost, ni več opravljen
  const d = state.plan.find(x => x.done?.activityId === id)
  if (d) { await repo.putPlanDay({ ...d, done: null }); await reloadPlan() }
  void touch()
}
/** Sestava celih dni (teden, nov načrt, AI prilagoditev): neopravljeni zapisi teh dni se zamenjajo s podanimi. */
export async function savePlanDays(days: PlanDay[]) { await repo.upsertPlanDays(days); await reloadPlan(); void touch(); schedulePushWorkouts() }
/** Posodobi samo te zapise (premik, prestavitev, prilagoditev) — drugi zapisi istih dni (npr. moč) ostanejo. */
export async function updatePlanDays(days: PlanDay[]) { await repo.putPlanDays(days); await reloadPlan(); void touch(); schedulePushWorkouts() }
/**
 * Razveljavi sestavo ali AI prilagoditev: vrne prejšnje dni in pobriše nove na datumih, kjer prej ni bilo ničesar.
 * `dates` = vsi datumi, ki jih je sprememba zapisala.
 */
export async function restorePlanDays(prev: PlanDay[], dates: Iterable<string>): Promise<void> {
  const had = new Set(prev.map(d => d.date))
  const gone = [...new Set(dates)].filter(d => !had.has(d))
  if (prev.length) await repo.upsertPlanDays(prev)
  if (gone.length) await repo.removePlanDates(gone)
  await reloadPlan(); void touch(); schedulePushWorkouts()
}
export async function savePlanDay(day: PlanDay) { await repo.putPlanDay(day); await reloadPlan(); void touch(); schedulePushWorkouts() }
export async function setPlanDone(id: string, done: boolean, activityId?: string | null) {
  const d = state.plan.find(x => x.id === id); if (!d) return
  await repo.putPlanDay({ ...d, done: done ? { at: new Date().toISOString(), activityId: activityId || null } : null })
  if (done) haptic('ok')
  await reloadPlan(); void touch()
}
async function reloadPlan() { const ws = weekStartIso(state.today); set({ plan: await repo.planBetween(addDays(ws, -14), addDays(ws, 20)) }) }
async function reloadMeals() {
  const [mealsToday, recentMeals] = await Promise.all([repo.mealsOn(state.today), repo.mealsBetween(addDays(state.today, -90), state.today)])
  set({ mealsToday, recentMeals })
}
export async function addMeal(m: MealEntry) { await repo.putMeal(m); haptic('ok'); await reloadMeals(); void touch() }
export async function removeMeal(id: string) { await repo.deleteMeal(id); await reloadMeals(); void touch() }
export async function saveCheckin(c: DailyCheckin) {
  await repo.putCheckin(c)
  set({ checkinToday: c.date === state.today ? c : state.checkinToday, checkins: await repo.allCheckins() })
  // zadnja teža je tudi teža v profilu — iz nje se računajo kalorije
  if (c.weightKg && c.date >= (state.checkins.filter(x => x.weightKg).map(x => x.date).sort().pop() || '')) {
    if (state.profile.weightKg !== c.weightKg) await updateProfile({ weightKg: c.weightKg })
  }
  void touch()
  // načrt posluša jutranji vnos: noge zelo bolijo ali si na dnu → danes brez kolesa ali lažje (boljši vnos to vrne)
  if (c.date === state.today) await followState()
}

/* ---------- načrt posluša, kako si (jutranji vnos) ---------- */
/** Stopnja danes iz jutranjega vnosa, pripravljenosti, včerajšnjega jutra, forme in zadnjih treh dni. */
export function stateToday(s: AppState = state): StateRead {
  const series = formSeries(s.activities, s.today)
  const tsb = series.length ? series[series.length - 1]!.tsb : null
  const rec = s.settings.wellnessOn ? recoveryOf(s.wellness, s.today, s.checkinToday?.sleepH ?? null) : null
  const ready = readinessOf(tsb, s.checkinToday, rec)
  const yesterday = s.checkins.find(c => c.date === addDays(s.today, -1)) ?? null
  return readState({ checkin: s.checkinToday, readiness: ready?.score ?? null, yesterday, tsb: s.activities.length >= 10 ? tsb : null, load3: load3(s.profile, s.plan, s.activities, s.today), easyHard: easyFeltHard(s.activities, s.plan, s.today) })
}
let stateChain: Promise<void> = Promise.resolve()
/**
 * Po jutranjem vnosu: stopnja ≥ 2 → prilagodi danes (in na dnu jutri), razen če je danes že prilagojeno ali si
 * prilagoditev zavrnil (»Vrni po načrtu«); stopnja < 2 → samodejna prilagoditev se vrne (vnos si popravil).
 * Zaporedno (hitri tapi v jutranjem vnosu ne smejo prilagoditi dvakrat).
 */
export function followState(): Promise<void> {
  stateChain = stateChain.then(async () => {
    const today = state.today
    const st = stateToday()
    const marked = state.plan.filter(d => d.byState?.date === today)
    const active = marked.filter(d => !d.byState!.off)
    if (st.level >= 2) {
      if (marked.length) return
      const r = adaptToState(state.profile, state.plan, today, st)
      if (r?.days.length) { await updatePlanDays(r.days); void logChange(`Po jutranjem vnosu (${st.reasons.join(', ') || 'počutje'}): ${r.lines.join(' ') || 'današnji trening je lažji.'}`) }
    } else if (active.length && active.every(d => d.byState!.auto)) {
      const back = undoState(state.plan, today, { keepOff: false })
      if (back.length) { await updatePlanDays(back); void logChange('Jutranji vnos je boljši — današnji trening je spet po načrtu.') }
    }
  }).catch(() => undefined)
  return stateChain
}
/** Izbran način za danes (sprehod, počitek, lahko vrtenje): prejšnja prilagoditev se vrne in nova velja (ni samodejna). */
export async function setStateMode(mode: StateMode): Promise<void> {
  const today = state.today
  const back = undoState(state.plan, today, { keepOff: false })
  const base = state.plan.map(d => back.find(b => b.id === d.id) ?? d)
  const st = stateToday({ ...state, plan: base })
  const r = adaptToState(state.profile, base, today, st, { mode })
  const byId = new Map<string, PlanDay>()
  for (const d of [...back, ...(r?.days ?? [])]) byId.set(d.id, d)
  if (byId.size) await updatePlanDays([...byId.values()])
}
/** »Vrni po načrtu«: današnja prilagoditev se vrne; danes je ne ponovimo sami. */
export async function undoStateToday(): Promise<void> {
  const back = undoState(state.plan, state.today, { keepOff: true })
  if (back.length) await updatePlanDays(back)
}
export async function addTest(t: TestEntry) {
  const tests = [...(state.settings.tests || []).filter(x => x.id !== t.id), t].sort((a, b) => a.date.localeCompare(b.date))
  await updateSettings({ tests })
  if (t.kind === 'ftp') {
    const ftp = Math.round(t.value * 0.95)
    const w = state.profile.weightKg
    // uvodni test (do 14 dni po potrditvi cilja) postane izhodišče — cilji se preračunajo iz pravega FTP, ne ocene
    const gs = state.profile.goalStart
    const calib = gs && Math.abs(new Date(t.date).getTime() - new Date(gs.date).getTime()) <= 14 * 86400_000
    await updateProfile({ ftp, ftpDate: t.date, ...(calib ? { goalStart: { ...gs!, ftp } } : {}) })
    void logChange(`Nov FTP ${ftp} W (test) — od naslednjega tedna so vati v načrtu po njem.`, false)
    toast(`FTP ${ftp} W (95 % testa)${w ? ` = ${(ftp / w).toFixed(2).replace('.', ',')} W/kg` : ''}. Naslednji teden se sestavi z novimi vati.`, 'ok', 7000)
  }
  if (t.kind === 'p5') {
    const w = state.profile.weightKg
    if (w) toast(`5 min: ${(t.value / w).toFixed(2).replace('.', ',')} W/kg → VO2max ~${Math.round(10.8 * (t.value / w) + 7)} ml/kg/min (ocena).`, 'ok', 7000)
  }
  if (t.kind === 'rhr') await updateProfile({ restHr: Math.round(t.value) })
}
export async function removeTest(id: string) { await repo.addTomb(tombTest(id)); await updateSettings({ tests: (state.settings.tests || []).filter(x => x.id !== id) }) }
export async function setMenu(menu: WeekMenu | null) { await updateSettings({ menu }) }
/** Prehranske želje za recepte. */
export async function setFoodPrefs(text: string) { await updateSettings({ foodPrefs: text.trim().slice(0, 200) || null }) }
/** Recepti dneva z AI (shranjeni po datumu, starejši od 14 dni odpadejo); novi obroki se dodajo k že shranjenim za ta dan. */
export async function setDayMenu(date: string, slots: Record<string, import('@/domain/nutrition/recipes').Recipe> | null) {
  const cur = state.settings.dayMenus || {}
  const keep = Object.fromEntries(Object.entries(cur).filter(([d]) => d >= addDays(state.today, -14) && d !== date))
  const prev = cur[date]?.slots && typeof cur[date]!.slots === 'object' ? cur[date]!.slots : {}
  await updateSettings({ dayMenus: slots ? { ...keep, [date]: { at: new Date().toISOString(), slots: { ...prev, ...slots } } } : keep })
}

/* ---------- račun ---------- */
/** Prvo usklajevanje ni uspelo (omrežje, strežnik): poskusi znova takoj — polno usklajevanje. */
export async function retrySync(): Promise<void> { await syncNow().catch(() => undefined) }

export async function signIn(): Promise<AuthUser | null> {
  const u = await signInGoogle()
  if (u) { set({ user: u, authKnown: true }); toast(`Prijavljen kot ${u.name || u.email || 'uporabnik'}`, 'ok') }
  return u
}
export async function signOut() {
  // zadnje usklajevanje samo, če sinhronizacija teče (po izbrisu računa je ustavljena — ne ustvari dokumenta znova)
  if (state.sync.state !== 'off') await pushNow().catch(() => undefined)
  await signOutNow()
  stopSync()
  set({ user: null, pro: false, firstSync: null })
  toast('Odjavljen. Podatki ostanejo na tej napravi.', 'info')
}

/** Vse lokalne podatke s te naprave (IndexedDB, ključi prve različice, ploščice karte) in stanje v pomnilniku. */
async function wipeDevice(): Promise<void> {
  await repo.wipeAll()
  try { localStorage.removeItem('formai.pilot') } catch { /* zasebni način */ }
  set({
    profile: repo.defaultProfile(), settings: repo.defaultSettings(), activities: [], plan: [], mealsToday: [], recentMeals: [], checkinToday: null, checkins: [],
    routeLib: null, icuWorkouts: null, icuDiag: null, icuErr: null, wellness: null, migration: null,
  })
}

/**
 * Izbris računa: ustavi sinhronizacijo → strežnik (POST /account/delete; 403 reauth → ponovna prijava z Googlom in še en
 * poskus; 404 → stara pot na odjemalcu) → ob uspehu odklopi OAuth žeton intervals.icu, odjava in izbris vseh podatkov
 * na napravi (tudi ključev prve različice). Ob neuspehu se sinhronizacija nadaljuje.
 */
export async function deleteAccountAll(): Promise<{ ok: boolean; reauth?: boolean; error?: string }> {
  const creds = state.settings.intervals
  // treningi FORMAI v koledarju intervals.icu bi sicer ostali na uri — najprej jih pobriši (tuji ostanejo)
  if (creds && creds.pushWorkouts !== false) await removeWorkouts().catch(() => null)
  const r = await deleteAccountOnServer(state.settings.pilot?.id ?? null)
  if (!r.ok) return { ok: false, reauth: r.reauth, error: r.error || 'Izbris ni uspel.' }
  if (creds?.token) await disconnectApp(creds).catch(() => undefined)
  await signOutNow()
  stopSync()
  await wipeDevice()
  set({ user: null, pro: false, firstSync: null, accountClash: null, syncDeleted: null })
  toast('Račun in vsi podatki so izbrisani.', 'ok', 7000)
  return { ok: true }
}

/** Drug račun na tej napravi: »Počisti in nadaljuj« — pobriše podatke prejšnjega računa s te naprave in začne usklajevanje. */
export async function acceptAccountSwitch(): Promise<void> {
  const u = state.user
  stopSync()
  await wipeDevice()
  set({ accountClash: null, syncDeleted: null, firstSync: null })
  await reloadAll()
  if (u) { beginSync(u); void checkPro() }
}
/** Drug račun na tej napravi: »Odjava« — podatki ostanejo nedotaknjeni, sinhronizacija se ne začne. */
export async function cancelAccountSwitch(): Promise<void> {
  set({ accountClash: null })
  stopSync()
  await signOutNow()
  set({ user: null, pro: false, firstSync: null })
}

export async function checkPro(): Promise<boolean> {
  try {
    const t = await idToken(); if (!t) return false
    let pro = false
    try {
      const r = await fetch(`${PROXY}/stripe/status`, { headers: { Authorization: `Bearer ${t}` } })
      if (r.ok) pro = !!((await r.json()) as { pro?: boolean }).pro
    } catch { /* strežnik te poti morda nima */ }
    // strežnik kvoto odloča po proUsers/{uid}.pro — isti dokument preberemo še neposredno (lastnik ga sme brati)
    if (!pro) pro = await proFromFirestore()
    set({ pro }); return pro
  } catch { return false }
}

/* ---------- trase ---------- */
let routesRunning = false
/**
 * Dopolni knjižnico tras iz voženj z Garmina (intervals.icu): največ na 6 h in največ 15 sledi naenkrat (kvota
 * intervals.icu), vsaka vožnja enkrat; ko je dnevni proračun porabljen, počaka. Odjava (401/403) gre v state.icuErr.
 */
export async function ensureRoutes(force = false): Promise<void> {
  const c = state.settings.intervals
  if (routesRunning) return
  const idle = async () => { if (!state.routeLib) set({ routeLib: await loadRouteLib() }) }
  if (!icuReady(c) || (typeof navigator !== 'undefined' && navigator.onLine === false)) { await idle(); return }
  const last = (await getKV<number>('routes.fillAt')) || 0
  // sledi so nenujne: pusti rezervo dnevnega proračuna za uvoz voženj in koledar
  const max = Math.min(ROUTE_STREAMS_PER_RUN, icuBudget(c).left - (c.token ? 20 : 100))
  if ((!force && Date.now() - last < 6 * 3600_000) || max <= 0) { await idle(); return }
  routesRunning = true; set({ routesBusy: true })
  try {
    await setKV('routes.fillAt', Date.now())
    const { lib, error } = await fillRouteLib(c, state.activities, max)
    set({ routeLib: lib })
    if (error && icuErrorKind(error) === 'auth') await setIcuErr(icuErrOf(error))
  }
  catch { /* tiho */ }
  finally { routesRunning = false; set({ routesBusy: false }) }
}

/**
 * Tempo za čas tras: umeritev na tvojih vožnjah (paceFactor) × učenje iz treningov (paceAdj: dejanski čas
 * od odhoda do prihoda proti oceni). k gre v vse ocene časa tras.
 */
let paceMemo: { key: string; acts: readonly Activity[]; plan: readonly PlanDay[]; val: { k: number; adj: ReturnType<typeof paceAdj> } } | null = null
export function routePace(lib: RouteLib | null = state.routeLib): { k: number; adj: ReturnType<typeof paceAdj> } {
  const p = state.profile
  const key = `${libSig(lib)}#${lib?.gen.length ?? 0}#${p.ftp}#${p.weightKg}#${state.today}`
  if (paceMemo && paceMemo.key === key && paceMemo.acts === state.activities && paceMemo.plan === state.plan) return paceMemo.val
  const recs = routesOf(lib), k0 = paceFactor(recs, p)
  const adj = paceAdj(lib?.raw || [], state.activities, state.plan, p, k0, state.today)
  const val = { k: +(k0 * adj.adj).toFixed(3), adj }
  paceMemo = { key, acts: state.activities, plan: state.plan, val }
  return val
}
/** Ceste, ki jih že voziš (iz sledi voženj na tej napravi) — da nove trase niso naključne. */
let knownCache: { sig: string; f: (pts: readonly LatLon[]) => number } | null = null
function knownOf(lib: RouteLib): (pts: readonly LatLon[]) => number {
  const sig = libSig(lib)
  if (!knownCache || knownCache.sig !== sig) knownCache = { sig, f: knownRoads(lib.raw.filter(r => r.source === 'voznja').map(r => decodePolyline(r.poly))) }
  return knownCache.f
}

/**
 * Nova trasa za dan (BRouter, profil za cestno kolo): 4 smeri, izbere najboljšo za trening (brez makadama,
 * malo semaforjev in naselij, po cestah, ki jih že voziš, za Z2 ravno); za intervale čez tvoj najboljši klanec.
 * Dolžina tako, da ocenjeni čas ustreza treningu.
 */
export async function newRouteFor(day: PlanDay, seed: number, replace = false): Promise<RouteRec> {
  const lib = state.routeLib || await loadRouteLib()
  const home = lib.home
  if (!home) throw new Error('Za novo traso rabim vsaj eno vožnjo z Garmina (začetek poti). Ko pride prva, poskusi znova.')
  const need = needOf(day, state.profile)
  if (!need) throw new Error('Za ta dan ni vožnje.')
  const p = state.profile, recs = routesOf(lib), k = routePace(lib).k, known = knownOf(lib)
  const hard = need.need === 'vo2' || need.need === 'prag' || need.need === 'test'
  const mass = (p.weightKg || 75) + 9
  let rec: RouteRec | null = null
  const est = (prof: number[]) => workoutMinutes(prof, need, p, k)
  if (need.need === 'vo2' || need.need === 'prag') {
    // krog čez 2–4 različne podobne klance iz tvojih voženj: vsak interval na svojem klancu (brez gor–dol po istem)
    let use = pickClimbLoop(climbCandidates(recs, need, p, home, 20), need.reps, 4)
    for (let attempt = 0; use.length >= 2 && attempt < 3 && !rec; attempt++) {
      try {
        const { routed, via } = await makeLoop(home, need.minutes, est, { seed, wantFlat: false, via: viaOf(use), known })
        const r0 = routedToRec(routed, via, `Nova trasa · ${need.label} · ${use.length} klanci`, day.date)
        if (!r0) break
        r0.intervals = intervalStops(routed.pts, use, need.reps)
        const t = suggestRoutes([r0], need, p, state.today, k, home)[0]
        const q = routed.q
        const rough = !!q && (q.unpavedKm > 0.5 || q.urbanKm > r0.km * 0.3)
        if (t && Math.abs(t.estMin - need.minutes) / need.minutes <= 0.2 && !rough) { rec = r0; break }
        // prekratko → raje en klanec s ponovitvami ali krog prave dolžine; predolgo ali slabe ceste → en klanec manj
        if ((t && t.estMin < need.minutes * 0.8) || use.length <= 2) break
        use = use.slice(0, -1)
      } catch { break }
    }
  }
  if (!rec && hard) {
    // klanec do ~15 km od doma: tja v ogrevanju, ponovitve do točke, kjer se interval izteče (ne nujno do vrha), domov v izvozu
    const best = suggestRoutes(recs.filter(r => r.source === 'voznja'), need, p, state.today, k, home).find(s => s.climb && haversineM(home, s.climb.foot) < 15000)
    if (best?.climb) {
      const W = need.workW || (p.ftp || 200)
      const turn = climbTurnPoint(best.rec.poly, best.climb, W, mass, need.need === 'test' ? 20 : need.workMin || 10)
      try {
        const { routed, via } = await makeLoop(home, need.minutes, est, { seed, wantFlat: false, via: [best.climb.foot, turn], known })
        rec = routedToRec(routed, via, `Nova trasa · ${need.label}`, day.date)
        // če s klancem ne pride v čas (±15 %), raje raven krog prave dolžine — intervale narediš na ravnem
        if (rec) { const t = suggestRoutes([rec], need, p, state.today, k, home)[0]; if (t && Math.abs(t.estMin - need.minutes) / need.minutes > 0.15) rec = null }
      } catch { rec = null }
    }
  }
  if (!rec) {
    const { routed, via: pts } = await makeLoop(home, need.minutes, est, { seed, wantFlat: need.need === 'z2' || need.need === 'regen', known })
    rec = routedToRec(routed, pts, `Nova trasa · ${need.label}`, day.date)
  }
  if (!rec) throw new Error('Trasa je prekratka — poskusi znova.')
  const l2 = await addGenerated(rec, replace ? day.date : undefined)
  set({ routeLib: l2 })
  return rec
}

/**
 * Trasa za danes in jutri brez klika: najprej tvoje pogoste poti (menjava, ne ista kot včeraj). Novo (BRouter)
 * nariše samo, če nobena tvoja ne ustreza treningu (čas ±12 %). Enkrat na dan na vožnjo.
 */
let autoRoutesRunning = false
export async function autoRoutes(): Promise<void> {
  if (autoRoutesRunning || typeof navigator !== 'undefined' && navigator.onLine === false) return
  const lib = state.routeLib
  if (!lib?.home) return
  autoRoutesRunning = true
  try {
    const p = state.profile, recs = routesOf(lib), k = routePace(lib).k
    for (const date of [state.today, addDays(state.today, 1)]) {
      const day = state.plan.find(d => d.date === date && (d.kind === 'kolo' || d.kind === 'test') && !d.done && d.role !== 'dirka')
      if (!day) continue
      const need = needOf(day, p)
      if (!need) continue
      const fits = (r: RouteRec[]) => { const b = suggestRoutes(r, need, p, state.today, k, lib.home)[0]; return b ? Math.abs(b.estMin - need.minutes) / need.minutes <= 0.12 : false }
      const gen = recs.filter(r => r.source === 'nova' && r.date === date)
      if (gen.length && fits(gen)) continue   // že narisana in ustreza
      // ustreza vsaj ena tvoja trasa (čas ±12 %, start doma) → brez nove; menjavo med njimi uredi točkovanje
      const own = suggestRoutes(recs.filter(r => r.source === 'voznja'), need, p, state.today, k, lib.home)
      const ownFits = own.some(s => Math.abs(s.estMin - need.minutes) / need.minutes <= 0.12 && (!lib.home || haversineM(lib.home, s.rec.start) < 3000))
      if (ownFits) continue
      if (gen.length && (await getKV<string>(`routes.retry.${date}`)) === state.today) continue   // danes že poskušeno
      await setKV(`routes.retry.${date}`, state.today)
      const seed = [...date].reduce((h, ch) => (h * 31 + ch.charCodeAt(0)) % 1000, 7) + (gen.length ? 13 : 0)
      try { await newRouteFor(day, seed, true) } catch { /* brez omrežja ali BRouter ne najde poti — ostane predlog iz voženj */ }
    }
  } finally { autoRoutesRunning = false }
}

/* ---------- testni program ---------- */
const anonId = () => Array.from(crypto.getRandomValues(new Uint8Array(8)), b => b.toString(16).padStart(2, '0')).join('')
/** Odgovor (a–d) na tedensko vprašanje: anonimno na strežnik, stanje v nastavitve (usklajeno med napravami). */
export async function answerPilot(q: PilotQ, a: string): Promise<void> {
  const s0 = state.settings.pilot || {}
  const id = s0.id || anonId()
  const start = state.profile.goalStart?.date ?? state.profile.createdAt?.slice(0, 10) ?? null
  const day = start ? Math.round((Date.parse(state.today) - Date.parse(start)) / 86_400_000) : null
  void sendPilot({ anon: id, code: s0.code ?? null, q, a, day, v: APP_VERSION })
  await updateSettings({ pilot: { ...afterAsk(s0, q, state.today), id } })
}
/** Preskok: to vprašanje in ta teden sta mimo (nič se ne pošlje). */
export async function skipPilot(q: PilotQ): Promise<void> { await updateSettings({ pilot: afterAsk(state.settings.pilot, q, state.today) }) }
export async function optOutPilot(): Promise<void> { await updateSettings({ pilot: { ...(state.settings.pilot || {}), optOut: true } }); toast('Vprašanj ne bo več. Hvala!', 'info') }

/* ---------- privolitev za AI ---------- */
export async function grantAiConsent() { await updateProfile({ aiConsentAt: new Date().toISOString() }) }
export async function revokeAiConsent() { await updateProfile({ aiConsentAt: null }); toast('AI obdelava izklopljena. Tvoji podatki ostanejo; nasveti se ustavijo.', 'info') }

let toastId = 0
export function toast(msg: string, kind: 'ok' | 'err' | 'info' = 'info', ms = 4200) {
  const id = ++toastId
  set({ toast: { msg, kind, id } })
  setTimeout(() => { if (state.toast?.id === id) set({ toast: null }) }, ms)
}

export function applyAccent(hex: string) {
  if (!/^#[0-9a-fA-F]{6}$/.test(hex)) return
  const r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b = parseInt(hex.slice(5, 7), 16)
  const root = document.documentElement.style
  root.setProperty('--accent', hex)
  // mehka podlaga (--accent-soft) je v tokens.css iz --accent-rgb — v svetli temi z večjim deležem
  root.setProperty('--accent-rgb', `${r}, ${g}, ${b}`)
  // besedilo v barvi poudarka v svetli temi: temnejši odtenek istega tona (≥ 4,5 : 1)
  root.setProperty('--accent-deep', accentDeep(hex))
}
