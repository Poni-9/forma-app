import { useSyncExternalStore } from 'react'
import type { Activity, DailyCheckin, MealEntry, PlanDay, Profile, Settings, TestEntry, WeekMenu } from '@/domain/types'
import * as repo from '@/data/repo'
import { migrateFromV1, repairAfterPreview } from '@/data/migrate'
import { todayIso, addDays, weekStartIso } from '@/domain/training/load'
import { onAuth, signInGoogle, signOutNow, idToken, type AuthUser } from '@/data/firebase'
import { startSync, stopSync, touch, onSyncStatus, pushNow, type SyncStatus } from '@/data/sync'
import { forecast, cachedForecast, type Forecast } from '@/domain/weather'

/** En vir resnice za UI. Piše se prek akcij, ki hkrati posodobijo IndexedDB, sprožijo sinhronizacijo in izris. */
export interface AppState {
  ready: boolean
  profile: Profile
  settings: Settings
  activities: Activity[]
  /** načrt za trenutni teden ± 2 tedna */
  plan: PlanDay[]
  mealsToday: MealEntry[]
  /** obroki zadnjih 90 dni (zgodovina, pogosti obroki, graf) */
  recentMeals: MealEntry[]
  checkinToday: DailyCheckin | null
  /** vsi jutranji vnosi (teža, spanec, počutje) */
  checkins: DailyCheckin[]
  weather: Forecast | null
  today: string
  toast: { msg: string; kind: 'ok' | 'err' | 'info'; id: number } | null
  migration: { activities: number; meals: number; plan: number } | null
  user: AuthUser | null
  /** null = še ne vemo (Firebase se nalaga) */
  authKnown: boolean
  sync: SyncStatus
  /** neomejen AI (proUsers/{uid}.pro na strežniku) */
  pro: boolean
}

let state: AppState = {
  ready: false, profile: repo.defaultProfile(), settings: repo.defaultSettings(), activities: [], plan: [], mealsToday: [], recentMeals: [], checkinToday: null, checkins: [], weather: null,
  today: todayIso(), toast: null, migration: null, user: null, authKnown: false, sync: { state: 'off' }, pro: false,
}
const subs = new Set<() => void>()
function emit() { for (const s of subs) s() }
function set(patch: Partial<AppState>) { state = { ...state, ...patch }; emit() }

export function useApp(): AppState {
  return useSyncExternalStore(cb => { subs.add(cb); return () => subs.delete(cb) }, () => state, () => state)
}
export function getState() { return state }

/* ---------- zagon ---------- */
let booted = false
export async function boot() {
  if (booted) return; booted = true
  const mig = await migrateFromV1().catch(() => null)
  const fixed = await repairAfterPreview().catch(() => [] as string[])
  await repo.purgeExpired().catch(() => 0)
  await reloadAll()
  set({ ready: true, migration: mig && mig.ran && (mig.activities || mig.meals || mig.plan) ? mig : null })
  if (fixed.length) toast('Počiščeno po preizkusu: ' + fixed.join(', ') + '.', 'info', 6000)
  void refreshWeather(false)
  // polnoč: osveži »danes«
  setInterval(() => { const t = todayIso(); if (t !== state.today) { set({ today: t }); void reloadAll() } }, 60_000)
  // račun in sinhronizacija — asinhrono, aplikacija dela tudi brez
  onSyncStatus(s => set({ sync: s }))
  onAuth(u => {
    set({ user: u, authKnown: true })
    if (u) { startSync(u.uid, () => { void reloadAll() }); void checkPro() }
    else { stopSync(); set({ pro: false }) }
  })
}

export async function reloadAll() {
  const today = todayIso()
  const ws = weekStartIso(today)
  const [profile, settings, activities, plan, mealsToday, recentMeals, checkinToday, checkins] = await Promise.all([
    repo.loadProfile(), repo.loadSettings(), repo.allActivities(), repo.planBetween(addDays(ws, -14), addDays(ws, 20)), repo.mealsOn(today),
    repo.mealsBetween(addDays(today, -90), today), repo.getCheckin(today), repo.allCheckins(),
  ])
  set({ profile, settings, activities, plan, mealsToday, recentMeals, checkinToday: checkinToday || null, checkins, today })
}

/* ---------- vreme ---------- */
export async function refreshWeather(force = true): Promise<Forecast | null> {
  const pl = state.profile.place
  if (!pl) { set({ weather: null }); return null }
  try {
    if (!force) { const c = await cachedForecast(pl.lat, pl.lon); if (c) set({ weather: c }) }
    const f = await forecast(pl.lat, pl.lon); set({ weather: f }); return f
  } catch { return state.weather }
}

/* ---------- akcije ---------- */
export async function updateProfile(patch: Partial<Profile>) {
  const p = await repo.saveProfile({ ...state.profile, ...patch })
  set({ profile: p }); void touch()
  if ('place' in patch) void refreshWeather(true)
  return p
}
export async function updateSettings(patch: Partial<Settings>) {
  const s = { ...state.settings, ...patch }
  await repo.saveSettings(s); set({ settings: s }); void touch()
  if (patch.accentHex) applyAccent(patch.accentHex)
}
export async function addActivities(list: Activity[]) {
  const r = await repo.addActivities(list)
  set({ activities: await repo.allActivities() }); void touch()
  return r
}
export async function saveActivity(a: Activity) { await repo.putActivity(a); set({ activities: await repo.allActivities() }); void touch() }
export async function removeActivity(id: string) {
  await repo.deleteActivity(id); set({ activities: state.activities.filter(a => a.id !== id) })
  // dan v načrtu, ki je kazal na to aktivnost, ni več opravljen
  const d = state.plan.find(x => x.done?.activityId === id)
  if (d) { await repo.putPlanDay({ ...d, done: null }); await reloadPlan() }
  void touch()
}
export async function savePlanDays(days: PlanDay[]) { await repo.upsertPlanDays(days); await reloadPlan(); void touch() }
export async function savePlanDay(day: PlanDay) { await repo.putPlanDay(day); await reloadPlan(); void touch() }
export async function setPlanDone(id: string, done: boolean, activityId?: string | null) {
  const d = state.plan.find(x => x.id === id); if (!d) return
  await repo.putPlanDay({ ...d, done: done ? { at: new Date().toISOString(), activityId: activityId || null } : null })
  await reloadPlan(); void touch()
}
async function reloadPlan() { const ws = weekStartIso(state.today); set({ plan: await repo.planBetween(addDays(ws, -14), addDays(ws, 20)) }) }
async function reloadMeals() {
  const [mealsToday, recentMeals] = await Promise.all([repo.mealsOn(state.today), repo.mealsBetween(addDays(state.today, -90), state.today)])
  set({ mealsToday, recentMeals })
}
export async function addMeal(m: MealEntry) { await repo.putMeal(m); await reloadMeals(); void touch() }
export async function removeMeal(id: string) { await repo.deleteMeal(id); await reloadMeals(); void touch() }
export async function saveCheckin(c: DailyCheckin) {
  await repo.putCheckin(c)
  set({ checkinToday: c.date === state.today ? c : state.checkinToday, checkins: await repo.allCheckins() })
  // zadnja teža je tudi teža v profilu — iz nje se računajo kalorije
  if (c.weightKg && c.date >= (state.checkins.filter(x => x.weightKg).map(x => x.date).sort().pop() || '')) {
    if (state.profile.weightKg !== c.weightKg) await updateProfile({ weightKg: c.weightKg })
  }
  void touch()
}
export async function addTest(t: TestEntry) {
  const tests = [...(state.settings.tests || []).filter(x => x.id !== t.id), t].sort((a, b) => a.date.localeCompare(b.date))
  await updateSettings({ tests })
  if (t.kind === 'ftp') {
    const ftp = Math.round(t.value * 0.95)
    await updateProfile({ ftp, ftpDate: t.date })
    toast(`FTP nastavljen na ${ftp} W (95 % testa).`, 'ok', 6000)
  }
  if (t.kind === 'rhr') await updateProfile({ restHr: Math.round(t.value) })
}
export async function removeTest(id: string) { await updateSettings({ tests: (state.settings.tests || []).filter(x => x.id !== id) }) }
export async function setMenu(menu: WeekMenu | null) { await updateSettings({ menu }) }

/* ---------- račun ---------- */
export async function signIn(): Promise<AuthUser | null> {
  const u = await signInGoogle()
  if (u) { set({ user: u, authKnown: true }); toast(`Prijavljen kot ${u.name || u.email || 'uporabnik'}`, 'ok') }
  return u
}
export async function signOut() {
  await pushNow().catch(() => undefined)
  await signOutNow()
  stopSync()
  set({ user: null, pro: false })
  toast('Odjavljen. Podatki ostanejo na tej napravi.', 'info')
}
export async function checkPro(): Promise<boolean> {
  try {
    const t = await idToken(); if (!t) return false
    const r = await fetch('https://forma-ai-proxy-602565779369.europe-west1.run.app/stripe/status', { headers: { Authorization: `Bearer ${t}` } })
    if (!r.ok) return false
    const js = await r.json() as { pro?: boolean }
    set({ pro: !!js.pro }); return !!js.pro
  } catch { return false }
}

/* ---------- privolitev za AI ---------- */
export async function grantAiConsent() { await updateProfile({ aiConsentAt: new Date().toISOString() }) }
export async function revokeAiConsent() { await updateProfile({ aiConsentAt: null }); toast('AI obdelava izklopljena. Tvoji podatki ostanejo; nasveti se ustavijo.', 'info') }

let toastId = 0
export function toast(msg: string, kind: 'ok' | 'err' | 'info' = 'info', ms = 4200) {
  const id = ++toastId
  set({ toast: { msg, kind, id } })
  setTimeout(() => { if (state.toast?.id === id) set({ toast: null }) }, ms)
}

export function applyAccent(hex: string) {
  const r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b = parseInt(hex.slice(5, 7), 16)
  const root = document.documentElement.style
  root.setProperty('--accent', hex)
  root.setProperty('--accent-soft', `rgba(${r},${g},${b},.14)`)
}
