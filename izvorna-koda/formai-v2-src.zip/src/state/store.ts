import { useSyncExternalStore } from 'react'
import type { Activity, DailyCheckin, MealEntry, PlanDay, Profile, Settings, TestEntry, WeekMenu } from '@/domain/types'
import * as repo from '@/data/repo'
import { migrateFromV1, repairAfterPreview, carryIntervalsFromV1 } from '@/data/migrate'
import { todayIso, addDays, weekStartIso, estimateTss } from '@/domain/training/load'
import { fetchActivities, fetchAthlete, fetchEvents, createEvents, updateEvent, deleteEvent } from '@/domain/intervals/client'
import { icuWorkout, workoutDiff, type IcuWorkout } from '@/domain/intervals/workouts'
import type { IcuDiag } from '@/domain/intervals/diagnosis'
import { powerMeterFrom, baselineHours, moveKeySession } from '@/domain/training/review'
import { buildWeek, weekContext } from '@/domain/training/planner'
import { loadRouteLib, fillRouteLib, addGenerated, routesOf, type RouteLib } from '@/data/routes'
import { needOf, suggestRoutes, paceFactor, workoutMinutes } from '@/domain/routes/match'
import { makeLoop, routedToRec } from '@/domain/routes/brouter'
import { climbTurnPoint, type RouteRec } from '@/domain/routes/analyze'
import { haversineM } from '@/domain/import/polyline'
import { getKV, setKV } from '@/data/db'
import { onAuth, signInGoogle, signOutNow, idToken, proFromFirestore, type AuthUser } from '@/data/firebase'
import { startSync, stopSync, touch, onSyncStatus, pushNow, type SyncStatus } from '@/data/sync'
import { forecast, cachedForecast, windowOf, WINDOW_NAMES, type Forecast } from '@/domain/weather'

/** En vir resnice za UI. Piše se prek akcij, ki hkrati posodobijo IndexedDB, sprožijo sinhronizacijo in izris. */
export interface AppState {
  ready: boolean
  profile: Profile
  settings: Settings
  activities: Activity[]
  /** načrt za trenutni teden ± 2 tedna */
  plan: PlanDay[]
  mealsToday: MealEntry[]
  /** obroki zadnjih 90 dni (zgodovina, pogosti obroki, graf) */
  recentMeals: MealEntry[]
  checkinToday: DailyCheckin | null
  /** vsi jutranji vnosi (teža, spanec, počutje) */
  checkins: DailyCheckin[]
  weather: Forecast | null
  today: string
  toast: { msg: string; kind: 'ok' | 'err' | 'info'; id: number } | null
  migration: { activities: number; meals: number; plan: number } | null
  user: AuthUser | null
  /** null = še ne vemo (Firebase se nalaga) */
  authKnown: boolean
  sync: SyncStatus
  /** neomejen AI (proUsers/{uid}.pro na strežniku) */
  pro: boolean
  /** knjižnica tras (samo na tej napravi) */
  routeLib: RouteLib | null
  routesBusy: boolean
  /** treningi na uro: zadnje pošiljanje v koledar intervals.icu */
  icuWorkouts: IcuWorkoutsInfo | null
  /** zadnji uvoz iz intervals.icu: koliko je vrnil, koliko uporabnih, koliko Stravinih (za pošteno pojasnilo) */
  icuDiag: IcuDiag | null
}
export interface IcuWorkoutsInfo { at: string; n: number; changed: number; removed: number; err: string | null }

let state: AppState = {
  ready: false, profile: repo.defaultProfile(), settings: repo.defaultSettings(), activities: [], plan: [], mealsToday: [], recentMeals: [], checkinToday: null, checkins: [], weather: null,
  today: todayIso(), toast: null, migration: null, user: null, authKnown: false, sync: { state: 'off' }, pro: false, routeLib: null, routesBusy: false, icuWorkouts: null, icuDiag: null,
}
const subs = new Set<() => void>()
function emit() { for (const s of subs) s() }
function set(patch: Partial<AppState>) { state = { ...state, ...patch }; emit() }

export function useApp(): AppState {
  return useSyncExternalStore(cb => { subs.add(cb); return () => subs.delete(cb) }, () => state, () => state)
}
export function getState() { return state }

/* ---------- zagon ---------- */
let booted = false
export async function boot() {
  if (booted) return; booted = true
  const mig = await migrateFromV1().catch(() => null)
  const fixed = await repairAfterPreview().catch(() => [] as string[])
  const icuCarried = await carryIntervalsFromV1().catch(() => false)
  await repo.purgeExpired().catch(() => 0)
  await reloadAll()
  set({ ready: true, migration: mig && mig.ran && (mig.activities || mig.meals || mig.plan) ? mig : null })
  void deriveFromRides()
  if (fixed.length) toast('Počiščeno po preizkusu: ' + fixed.join(', ') + '.', 'info', 6000)
  void refreshWeather(false)
  if (icuCarried) toast('Povezava z intervals.icu je prenesena iz stare aplikacije — vožnje se uvažajo same.', 'info', 7000)
  // samodejni uvoz iz intervals.icu: ob zagonu in ob vrnitvi v aplikacijo (največ na 3 ure)
  // enkrat: ponovno preberi leto voženj iz intervals.icu (cone utripa, merilnik moči)
  if (!(await getKV<boolean>('icu.zones.v1'))) { await setKV('icu.fullDone', false); await setKV('icu.autoAt', 0); await setKV('icu.zones.v1', true) }
  void loadRouteLib().then(l => set({ routeLib: l }))
  void getKV<IcuWorkoutsInfo>('icu.workouts').then(i => { if (i) set({ icuWorkouts: i }) })
  void getKV<IcuDiag>('icu.diag').then(d => { if (d) set({ icuDiag: d }) })
  void autoSyncIntervals().then(() => ensureRoutes()).then(() => autoRoutes()).then(() => schedulePushWorkouts(4000, true))
  // ob vrnitvi v aplikacijo (telefon po vožnji): preveri nove vožnje — največ na 10 min
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') void autoSyncIntervals().then(() => ensureRoutes()).then(() => autoRoutes()).then(() => schedulePushWorkouts(4000, true)) })
  // polnoč: osveži »danes«
  setInterval(() => { const t = todayIso(); if (t !== state.today) { set({ today: t }); void reloadAll() } }, 60_000)
  // račun in sinhronizacija — asinhrono, aplikacija dela tudi brez
  onSyncStatus(s => set({ sync: s }))
  onAuth(u => {
    set({ user: u, authKnown: true })
    if (u) { startSync(u.uid, () => { void reloadAll() }); void checkPro() }
    else { stopSync(); set({ pro: false }) }
  })
}

export async function reloadAll() {
  const today = todayIso()
  const ws = weekStartIso(today)
  const [profile, settings, activities, plan, mealsToday, recentMeals, checkinToday, checkins] = await Promise.all([
    repo.loadProfile(), repo.loadSettings(), repo.allActivities(), repo.planBetween(addDays(ws, -14), addDays(ws, 20)), repo.mealsOn(today),
    repo.mealsBetween(addDays(today, -90), today), repo.getCheckin(today), repo.allCheckins(),
  ])
  set({ profile, settings, activities, plan, mealsToday, recentMeals, checkinToday: checkinToday || null, checkins, today })
}

/* ---------- samodejni uvoz iz intervals.icu ---------- */
let icuBusy = false
/**
 * Nove vožnje iz intervals.icu brez klikanja: ob odprtju aplikacije, največ na 3 ure.
 * Prvič leto nazaj (zgodovina za formo in napredek), nato zadnje 3 tedne.
 * Izvor in zastavice določi uvoz (Strava ne gre v AI in ne na karto); napake so tihe — ročni uvoz jih pokaže.
 */
export async function autoSyncIntervals(force = false): Promise<number | null> {
  const c = state.settings.intervals
  if (!c || !c.athleteId || !c.apiKey || icuBusy || (typeof navigator !== 'undefined' && navigator.onLine === false)) return null
  const last = (await getKV<number>('icu.autoAt')) || 0
  if (!force && Date.now() - last < 10 * 60_000) return null
  icuBusy = true
  let added = 0
  try {
    await setKV('icu.autoAt', Date.now())
    const full = !(await getKV<boolean>('icu.fullDone'))
    const today = todayIso()
    const r = await fetchActivities(c, addDays(today, full ? -365 : -21), addDays(today, 1))
    for (const a of r.activities) if (!a.tss) a.tss = estimateTss(a, state.profile)
    await setIcuDiag({ at: new Date().toISOString(), days: full ? 365 : 21, total: r.total, usable: r.activities.length, stravaStubs: r.stravaStubs, known: state.activities.filter(a => a.source === 'intervals').length })
    // sledi ne shranjujemo pri vožnjah — trase gradi knjižnica tras (ensureRoutes), samo na tej napravi
    const before = new Set(state.activities.map(a => a.id))
    const res = await repo.addActivities(r.activities)
    added = res.added
    if (full) await setKV('icu.fullDone', true)
    if (res.added || res.upgraded) {
      const all = await repo.allActivities()
      set({ activities: all }); void touch()
      await linkToPlan(all.filter(a => !before.has(a.id)))
      if (res.added) {
        const bits = [res.added ? `+${res.added} novih` : ''].filter(Boolean)
        toast(`intervals.icu: ${bits.join(' · ')}.`, 'info', 5000)
      }
    }
    // pražni in max utrip iz intervals.icu, če jih še nimamo (največ enkrat na dan)
    const p0 = state.profile
    if ((!p0.lthr || !p0.maxHr) && Date.now() - ((await getKV<number>('icu.athleteAt')) || 0) > 86400_000) {
      await setKV('icu.athleteAt', Date.now())
      const ath = await fetchAthlete(c).catch(() => null)
      if (ath) {
        const patch: Partial<Profile> = {}
        if (ath.lthr && !p0.lthr) patch.lthr = ath.lthr
        if (ath.maxHr && !p0.maxHr) patch.maxHr = ath.maxHr
        if (ath.restHr && !p0.restHr) patch.restHr = ath.restHr
        if (Object.keys(patch).length) await updateProfile(patch)
      }
    }
  } catch { /* tiho */ }
  finally { icuBusy = false }
  await deriveFromRides()
  return added
}

/** Zadnji izid uvoza (za pojasnilo v Uvozu in na Danes), hrani se na napravi. */
export async function setIcuDiag(d: IcuDiag): Promise<void> {
  await setKV('icu.diag', d); set({ icuDiag: d })
}

/**
 * Kar trener razbere iz tvojih voženj in vpiše v načrt:
 *  - merilnik moči (da/ne) → cilji v vatih ali utripu,
 *  - dejanske ure na teden ob začetku načrta → načrt raste od tu +10 % na teden (sestavi ta in naslednji teden znova).
 */
export async function deriveFromRides(): Promise<void> {
  const p = state.profile, today = state.today
  try {
    if (p.gear.powerMeterAuto !== false || p.gear.powerMeter == null) {
      const pm = powerMeterFrom(state.activities, today)
      if (pm != null && pm !== p.gear.powerMeter) await updateProfile({ gear: { ...p.gear, powerMeter: pm, powerMeterAuto: true } })
    }
    const p2 = state.profile
    if (p2.event?.date && p2.baseHours == null) {
      const base = baselineHours(state.activities, today)
      if (base != null) {
        const prof = await updateProfile({ baseHours: base })
        await rebuildFromToday(prof)
        const first = weekContext(prof, weekStartIso(today)).hours
        toast(`Načrt prilagojen tvojemu dejanskemu volumnu: zadnjih 8 tednov ${String(base).replace('.', ',')} h na teden → ta teden ${String(first).replace('.', ',')} h, nato +10 % na teden.`, 'info', 9000)
      }
    }
  } catch { /* tiho */ }
}

/** Sestavi ta in naslednji teden znova od danes naprej (opravljeni dnevi ostanejo). */
export async function rebuildFromToday(prof: Profile = state.profile): Promise<void> {
  const ws = weekStartIso(state.today)
  const rain: Record<string, number> = {}
  if (state.weather) for (const k in state.weather) rain[k] = state.weather[k]!.rain
  const doneDates = new Set(state.plan.filter(d => d.done).map(d => d.date))
  // če je danes že opravljen, gradi od jutri (test ali ključni trening ne sme pasti na današnji dan)
  const from = doneDates.has(state.today) ? addDays(state.today, 1) : state.today
  const w1 = buildWeek({ profile: prof, activities: state.activities, weekStart: ws, rain, notBefore: from })
  const w2 = buildWeek({ profile: prof, activities: state.activities, weekStart: addDays(ws, 7), rain, notBefore: addDays(ws, 7) })
  // dnevi pred danes ostanejo, kakršni so bili
  await savePlanDays([...w1, ...w2].filter(d => d.date >= from && !doneDates.has(d.date)))
}

/** Ključni trening, ki danes ni bil narejen, gre na naslednji lahki dan; danes dobi vsebino tistega dne. */
export async function moveKeyToLater(dayId: string): Promise<string | null> {
  const d = state.plan.find(x => x.id === dayId)
  if (!d) return null
  const ws = weekStartIso(state.today)
  const week = state.plan.filter(x => x.date >= ws && x.date <= addDays(ws, 6))
  const r = moveKeySession(week, d, state.today)
  if (!r) return null
  await savePlanDays(r)
  return r[1].date
}

/* ---------- treningi na uro: naslednjih 14 dni načrta → koledar intervals.icu → Garmin Connect → ura ---------- */
let pushTimer: number | null = null, pushBusy = false
/** Pošlji z zamikom (več sprememb načrta zapored = eno pošiljanje). ifStale: samo, če je od zadnjega minilo > 6 h. */
export function schedulePushWorkouts(delayMs = 2500, ifStale = false): void {
  if (typeof window === 'undefined') return
  if (ifStale && state.icuWorkouts && !state.icuWorkouts.err && Date.now() - new Date(state.icuWorkouts.at).getTime() < 6 * 3600_000) return
  if (pushTimer) clearTimeout(pushTimer)
  pushTimer = window.setTimeout(() => { pushTimer = null; void pushWorkouts() }, delayMs)
}
export async function pushWorkouts(manual = false): Promise<IcuWorkoutsInfo | null> {
  const c = state.settings.intervals
  if (!c || !c.athleteId || !c.apiKey || c.pushWorkouts === false || pushBusy || (typeof navigator !== 'undefined' && navigator.onLine === false)) return null
  pushBusy = true
  const from = state.today, to = addDays(state.today, 13)
  try {
    const desired = state.plan.filter(d => d.date >= from && d.date <= to).map(d => icuWorkout(d, state.profile)).filter((w): w is IcuWorkout => !!w)
    const existing = await fetchEvents(c, from, to)
    const diff = workoutDiff(desired, existing)
    if (diff.create.length) await createEvents(c, diff.create)
    for (const u of diff.update) await updateEvent(c, u.id, u.w)
    for (const id of diff.remove) await deleteEvent(c, id)
    const changed = diff.create.length + diff.update.length
    const info: IcuWorkoutsInfo = { at: new Date().toISOString(), n: desired.length, changed, removed: diff.remove.length, err: null }
    await setKV('icu.workouts', info); set({ icuWorkouts: info })
    if (manual) toast(changed || diff.remove.length ? `Na uro: ${changed} poslanih${diff.remove.length ? `, ${diff.remove.length} pobrisanih` : ''} — Garmin jih prenese ob naslednji sinhronizaciji.` : `Koledar intervals.icu je že enak načrtu (${desired.length} treningov).`, 'ok', 7000)
    return info
  } catch (e) {
    const info: IcuWorkoutsInfo = { at: new Date().toISOString(), n: 0, changed: 0, removed: 0, err: (e as Error)?.message || 'napaka' }
    await setKV('icu.workouts', info); set({ icuWorkouts: info })
    if (manual) toast(info.err!, 'err', 7000)
    return null
  } finally { pushBusy = false }
}
/** Izklop »treningov na uro«: naše (formai-…) dogodke od danes naprej pobrišemo iz koledarja, da jih Garmin umakne z ure. Vrne število pobrisanih ali null ob napaki. */
export async function removeWorkouts(): Promise<number | null> {
  const c = state.settings.intervals
  if (!c || !c.athleteId || !c.apiKey || pushBusy) return null
  pushBusy = true
  try {
    const existing = await fetchEvents(c, state.today, addDays(state.today, 30))
    const { remove } = workoutDiff([], existing)
    for (const id of remove) await deleteEvent(c, id)
    const info: IcuWorkoutsInfo = { at: new Date().toISOString(), n: 0, changed: 0, removed: remove.length, err: null }
    await setKV('icu.workouts', info); set({ icuWorkouts: info })
    return remove.length
  } catch (e) {
    toast((e as Error)?.message || 'Brisanje iz koledarja ni uspelo.', 'err', 7000)
    return null
  } finally { pushBusy = false }
}

/* ---------- vreme ---------- */
export async function refreshWeather(force = true): Promise<Forecast | null> {
  const pl = state.profile.place
  if (!pl) { set({ weather: null }); return null }
  try {
    const win = windowOf(state.profile.trainTime), wn = WINDOW_NAMES[state.profile.trainTime || 'popoldne']
    if (!force) { const c = await cachedForecast(pl.lat, pl.lon, win); if (c) set({ weather: c }) }
    const f = await forecast(pl.lat, pl.lon, win, wn); set({ weather: f }); return f
  } catch { return state.weather }
}

/* ---------- akcije ---------- */
export async function updateProfile(patch: Partial<Profile>) {
  const p = await repo.saveProfile({ ...state.profile, ...patch })
  set({ profile: p }); void touch()
  if ('place' in patch || 'trainTime' in patch) void refreshWeather(true)
  return p
}
export async function updateSettings(patch: Partial<Settings>) {
  const s = { ...state.settings, ...patch }
  await repo.saveSettings(s); set({ settings: s }); void touch()
  if (patch.accentHex) applyAccent(patch.accentHex)
}
export async function addActivities(list: Activity[]) {
  const before = new Set(state.activities.map(a => a.id))
  const r = await repo.addActivities(list)
  const all = await repo.allActivities()
  set({ activities: all }); void touch()
  await linkToPlan(all.filter(a => !before.has(a.id)))
  return r
}

/** Uvožena vožnja/vadba odkljuka načrtovano sejo istega dne in vrste — načrt ve, kje si, brez klikanja. */
async function linkToPlan(acts: readonly Activity[]) {
  let n = 0
  for (const a of acts) {
    if (a.date < addDays(state.today, -21) || state.plan.some(d => d.done?.activityId === a.id)) continue
    const fits = (k: string) => a.sport === 'moc' ? k === 'moc' : a.sport === 'kolo' ? k === 'kolo' || k === 'test' : k === a.sport
    const d = state.plan.filter(x => x.date === a.date && !x.done && fits(x.kind)).sort((x, y) => (x.optional ? 1 : 0) - (y.optional ? 1 : 0))[0]
    if (!d) continue
    await repo.putPlanDay({ ...d, done: { at: new Date().toISOString(), activityId: a.id } })
    state = { ...state, plan: state.plan.map(x => (x.id === d.id ? { ...x, done: { at: new Date().toISOString(), activityId: a.id } } : x)) }
    n++
  }
  if (n) { await reloadPlan(); void touch() }
}
export async function saveActivity(a: Activity) { await repo.putActivity(a); set({ activities: await repo.allActivities() }); void touch() }
export async function removeActivity(id: string) {
  await repo.deleteActivity(id); set({ activities: state.activities.filter(a => a.id !== id) })
  // dan v načrtu, ki je kazal na to aktivnost, ni več opravljen
  const d = state.plan.find(x => x.done?.activityId === id)
  if (d) { await repo.putPlanDay({ ...d, done: null }); await reloadPlan() }
  void touch()
}
export async function savePlanDays(days: PlanDay[]) { await repo.upsertPlanDays(days); await reloadPlan(); void touch(); schedulePushWorkouts() }
export async function savePlanDay(day: PlanDay) { await repo.putPlanDay(day); await reloadPlan(); void touch(); schedulePushWorkouts() }
export async function setPlanDone(id: string, done: boolean, activityId?: string | null) {
  const d = state.plan.find(x => x.id === id); if (!d) return
  await repo.putPlanDay({ ...d, done: done ? { at: new Date().toISOString(), activityId: activityId || null } : null })
  await reloadPlan(); void touch()
}
async function reloadPlan() { const ws = weekStartIso(state.today); set({ plan: await repo.planBetween(addDays(ws, -14), addDays(ws, 20)) }) }
async function reloadMeals() {
  const [mealsToday, recentMeals] = await Promise.all([repo.mealsOn(state.today), repo.mealsBetween(addDays(state.today, -90), state.today)])
  set({ mealsToday, recentMeals })
}
export async function addMeal(m: MealEntry) { await repo.putMeal(m); await reloadMeals(); void touch() }
export async function removeMeal(id: string) { await repo.deleteMeal(id); await reloadMeals(); void touch() }
export async function saveCheckin(c: DailyCheckin) {
  await repo.putCheckin(c)
  set({ checkinToday: c.date === state.today ? c : state.checkinToday, checkins: await repo.allCheckins() })
  // zadnja teža je tudi teža v profilu — iz nje se računajo kalorije
  if (c.weightKg && c.date >= (state.checkins.filter(x => x.weightKg).map(x => x.date).sort().pop() || '')) {
    if (state.profile.weightKg !== c.weightKg) await updateProfile({ weightKg: c.weightKg })
  }
  void touch()
}
export async function addTest(t: TestEntry) {
  const tests = [...(state.settings.tests || []).filter(x => x.id !== t.id), t].sort((a, b) => a.date.localeCompare(b.date))
  await updateSettings({ tests })
  if (t.kind === 'ftp') {
    const ftp = Math.round(t.value * 0.95)
    const w = state.profile.weightKg
    // uvodni test (do 14 dni po potrditvi cilja) postane izhodišče — cilji se preračunajo iz pravega FTP, ne ocene
    const gs = state.profile.goalStart
    const calib = gs && Math.abs(new Date(t.date).getTime() - new Date(gs.date).getTime()) <= 14 * 86400_000
    await updateProfile({ ftp, ftpDate: t.date, ...(calib ? { goalStart: { ...gs!, ftp } } : {}) })
    toast(`FTP ${ftp} W (95 % testa)${w ? ` = ${(ftp / w).toFixed(2).replace('.', ',')} W/kg` : ''}. Naslednji teden se sestavi z novimi vati.`, 'ok', 7000)
  }
  if (t.kind === 'p5') {
    const w = state.profile.weightKg
    if (w) toast(`5 min: ${(t.value / w).toFixed(2).replace('.', ',')} W/kg → VO2max ~${Math.round(10.8 * (t.value / w) + 7)} ml/kg/min (ocena).`, 'ok', 7000)
  }
  if (t.kind === 'rhr') await updateProfile({ restHr: Math.round(t.value) })
}
export async function removeTest(id: string) { await updateSettings({ tests: (state.settings.tests || []).filter(x => x.id !== id) }) }
export async function setMenu(menu: WeekMenu | null) { await updateSettings({ menu }) }

/* ---------- račun ---------- */
export async function signIn(): Promise<AuthUser | null> {
  const u = await signInGoogle()
  if (u) { set({ user: u, authKnown: true }); toast(`Prijavljen kot ${u.name || u.email || 'uporabnik'}`, 'ok') }
  return u
}
export async function signOut() {
  await pushNow().catch(() => undefined)
  await signOutNow()
  stopSync()
  set({ user: null, pro: false })
  toast('Odjavljen. Podatki ostanejo na tej napravi.', 'info')
}
export async function checkPro(): Promise<boolean> {
  try {
    const t = await idToken(); if (!t) return false
    let pro = false
    try {
      const r = await fetch('https://forma-ai-proxy-602565779369.europe-west1.run.app/stripe/status', { headers: { Authorization: `Bearer ${t}` } })
      if (r.ok) pro = !!((await r.json()) as { pro?: boolean }).pro
    } catch { /* strežnik te poti morda nima */ }
    // strežnik kvoto odloča po proUsers/{uid}.pro — isti dokument preberemo še neposredno (lastnik ga sme brati)
    if (!pro) pro = await proFromFirestore()
    set({ pro }); return pro
  } catch { return false }
}

/* ---------- trase ---------- */
let routesRunning = false
/** Dopolni knjižnico tras iz voženj z Garmina (intervals.icu). Tiho; ob napaki poskusi ob naslednjem zagonu. */
export async function ensureRoutes(): Promise<void> {
  const c = state.settings.intervals
  if (routesRunning) return
  if (!c || !c.athleteId || !c.apiKey || (typeof navigator !== 'undefined' && navigator.onLine === false)) { if (!state.routeLib) set({ routeLib: await loadRouteLib() }); return }
  routesRunning = true; set({ routesBusy: true })
  try { const { lib } = await fillRouteLib(c, state.activities); set({ routeLib: lib }) }
  catch { /* tiho */ }
  finally { routesRunning = false; set({ routesBusy: false }) }
}

/**
 * Nova trasa za dan (BRouter): za Z2/regeneracijo najbolj ravna od treh smeri, za intervale čez tvoj najboljši klanec,
 * sicer krog v novi smeri. Dolžina tako, da ocenjeni čas ustreza treningu.
 */
export async function newRouteFor(day: PlanDay, seed: number, replace = false): Promise<RouteRec> {
  const lib = state.routeLib || await loadRouteLib()
  const home = lib.home
  if (!home) throw new Error('Za novo traso rabim vsaj eno vožnjo z Garmina (začetek poti). Ko pride prva, poskusi znova.')
  const need = needOf(day, state.profile)
  if (!need) throw new Error('Za ta dan ni vožnje.')
  const p = state.profile, recs = routesOf(lib), k = paceFactor(recs, p)
  const hard = need.need === 'vo2' || need.need === 'prag' || need.need === 'test'
  const mass = (p.weightKg || 75) + 9
  let rec: RouteRec | null = null
  if (hard) {
    // klanec do ~15 km od doma: tja v ogrevanju, ponovitve do točke, kjer se interval izteče (ne nujno do vrha), domov v izvozu
    const best = suggestRoutes(recs.filter(r => r.source === 'voznja'), need, p, state.today, k, home).find(s => s.climb && haversineM(home, s.climb.foot) < 15000)
    if (best?.climb) {
      const W = need.workW || (p.ftp || 200)
      const turn = climbTurnPoint(best.rec.poly, best.climb, W, mass, need.need === 'test' ? 20 : need.workMin || 10)
      try {
        const { routed, via } = await makeLoop(home, need.minutes, prof => workoutMinutes(prof, need, p, k), { seed, wantFlat: false, via: [best.climb.foot, turn] })
        rec = routedToRec(routed, via, `Nova trasa · ${need.label}`, day.date)
        // če s klancem ne pride v čas (±15 %), raje raven krog prave dolžine — intervale narediš na ravnem
        if (rec) { const t = suggestRoutes([rec], need, p, state.today, k, home)[0]; if (t && Math.abs(t.estMin - need.minutes) / need.minutes > 0.15) rec = null }
      } catch { rec = null }
    }
  }
  if (!rec) {
    const { routed, via: pts } = await makeLoop(home, need.minutes, prof => workoutMinutes(prof, need, p, k), { seed, wantFlat: need.need === 'z2' || need.need === 'regen' })
    rec = routedToRec(routed, pts, `Nova trasa · ${need.label}`, day.date)
  }
  if (!rec) throw new Error('Trasa je prekratka — poskusi znova.')
  const l2 = await addGenerated(rec, replace ? day.date : undefined)
  set({ routeLib: l2 })
  return rec
}

/**
 * Trasa za danes in jutri brez klika: če nobena tvoja trasa ne ustreza treningu (čas ±12 %) ali si najboljšo vozil
 * v zadnjih 3 dneh, nariše novo (BRouter) — vsak dan drugo smer. Enkrat na dan na vožnjo.
 */
let autoRoutesRunning = false
export async function autoRoutes(): Promise<void> {
  if (autoRoutesRunning || typeof navigator !== 'undefined' && navigator.onLine === false) return
  const lib = state.routeLib
  if (!lib?.home) return
  autoRoutesRunning = true
  try {
    const p = state.profile, recs = routesOf(lib), k = paceFactor(recs, p)
    for (const date of [state.today, addDays(state.today, 1)]) {
      const day = state.plan.find(d => d.date === date && (d.kind === 'kolo' || d.kind === 'test') && !d.done && d.role !== 'dirka')
      if (!day) continue
      const need = needOf(day, p)
      if (!need) continue
      const fits = (r: RouteRec[]) => { const b = suggestRoutes(r, need, p, state.today, k, lib.home)[0]; return b ? Math.abs(b.estMin - need.minutes) / need.minutes <= 0.12 : false }
      const gen = recs.filter(r => r.source === 'nova' && r.date === date)
      if (gen.length && fits(gen)) continue   // že narisana in ustreza
      const best = suggestRoutes(recs.filter(r => r.source === 'voznja'), need, p, state.today, k, lib.home)[0]
      const recent = !!best?.rec.date && (new Date(state.today).getTime() - new Date(best.rec.date).getTime()) / 86400_000 <= 3
      const off = !best || Math.abs(best.estMin - need.minutes) / need.minutes > 0.12
      if (!gen.length && !off && !recent) continue
      if (gen.length && (await getKV<string>(`routes.retry.${date}`)) === state.today) continue   // danes že poskušeno
      await setKV(`routes.retry.${date}`, state.today)
      const seed = [...date].reduce((h, ch) => (h * 31 + ch.charCodeAt(0)) % 1000, 7) + (gen.length ? 13 : 0)
      try { await newRouteFor(day, seed, true) } catch { /* brez omrežja ali BRouter ne najde poti — ostane predlog iz voženj */ }
    }
  } finally { autoRoutesRunning = false }
}

/* ---------- privolitev za AI ---------- */
export async function grantAiConsent() { await updateProfile({ aiConsentAt: new Date().toISOString() }) }
export async function revokeAiConsent() { await updateProfile({ aiConsentAt: null }); toast('AI obdelava izklopljena. Tvoji podatki ostanejo; nasveti se ustavijo.', 'info') }

let toastId = 0
export function toast(msg: string, kind: 'ok' | 'err' | 'info' = 'info', ms = 4200) {
  const id = ++toastId
  set({ toast: { msg, kind, id } })
  setTimeout(() => { if (state.toast?.id === id) set({ toast: null }) }, ms)
}

export function applyAccent(hex: string) {
  const r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b = parseInt(hex.slice(5, 7), 16)
  const root = document.documentElement.style
  root.setProperty('--accent', hex)
  root.setProperty('--accent-soft', `rgba(${r},${g},${b},.14)`)
}
