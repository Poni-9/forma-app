import { useSyncExternalStore } from 'react'
import type { Activity, DailyCheckin, MealEntry, PlanDay, Profile, Settings, TestEntry, WeekMenu } from '@/domain/types'
import * as repo from '@/data/repo'
import { migrateFromV1, repairAfterPreview, carryIntervalsFromV1 } from '@/data/migrate'
import { todayIso, addDays, weekStartIso, estimateTss } from '@/domain/training/load'
import { fetchActivities } from '@/domain/intervals/client'
import { loadRouteLib, fillRouteLib, addGenerated, routesOf, type RouteLib } from '@/data/routes'
import { needOf, suggestRoutes, paceFactor, estMinutes } from '@/domain/routes/match'
import { makeLoop, routedToRec } from '@/domain/routes/brouter'
import type { RouteRec } from '@/domain/routes/analyze'
import { getKV, setKV } from '@/data/db'
import { onAuth, signInGoogle, signOutNow, idToken, proFromFirestore, type AuthUser } from '@/data/firebase'
import { startSync, stopSync, touch, onSyncStatus, pushNow, type SyncStatus } from '@/data/sync'
import { forecast, cachedForecast, type Forecast } from '@/domain/weather'

/** En vir resnice za UI. Piše se prek akcij, ki hkrati posodobijo IndexedDB, sprožijo sinhronizacijo in izris. */
export interface AppState {
  ready: boolean
  profile: Profile
  settings: Settings
  activities: Activity[]
  /** načrt za trenutni teden ± 2 tedna */
  plan: PlanDay[]
  mealsToday: MealEntry[]
  /** obroki zadnjih 90 dni (zgodovina, pogosti obroki, graf) */
  recentMeals: MealEntry[]
  checkinToday: DailyCheckin | null
  /** vsi jutranji vnosi (teža, spanec, počutje) */
  checkins: DailyCheckin[]
  weather: Forecast | null
  today: string
  toast: { msg: string; kind: 'ok' | 'err' | 'info'; id: number } | null
  migration: { activities: number; meals: number; plan: number } | null
  user: AuthUser | null
  /** null = še ne vemo (Firebase se nalaga) */
  authKnown: boolean
  sync: SyncStatus
  /** neomejen AI (proUsers/{uid}.pro na strežniku) */
  pro: boolean
  /** knjižnica tras (samo na tej napravi) */
  routeLib: RouteLib | null
  routesBusy: boolean
}

let state: AppState = {
  ready: false, profile: repo.defaultProfile(), settings: repo.defaultSettings(), activities: [], plan: [], mealsToday: [], recentMeals: [], checkinToday: null, checkins: [], weather: null,
  today: todayIso(), toast: null, migration: null, user: null, authKnown: false, sync: { state: 'off' }, pro: false, routeLib: null, routesBusy: false,
}
const subs = new Set<() => void>()
function emit() { for (const s of subs) s() }
function set(patch: Partial<AppState>) { state = { ...state, ...patch }; emit() }

export function useApp(): AppState {
  return useSyncExternalStore(cb => { subs.add(cb); return () => subs.delete(cb) }, () => state, () => state)
}
export function getState() { return state }

/* ---------- zagon ---------- */
let booted = false
export async function boot() {
  if (booted) return; booted = true
  const mig = await migrateFromV1().catch(() => null)
  const fixed = await repairAfterPreview().catch(() => [] as string[])
  const icuCarried = await carryIntervalsFromV1().catch(() => false)
  await repo.purgeExpired().catch(() => 0)
  await reloadAll()
  set({ ready: true, migration: mig && mig.ran && (mig.activities || mig.meals || mig.plan) ? mig : null })
  if (fixed.length) toast('Počiščeno po preizkusu: ' + fixed.join(', ') + '.', 'info', 6000)
  void refreshWeather(false)
  if (icuCarried) toast('Povezava z intervals.icu je prenesena iz stare aplikacije — vožnje se uvažajo same.', 'info', 7000)
  // samodejni uvoz iz intervals.icu: ob zagonu in ob vrnitvi v aplikacijo (največ na 3 ure)
  void loadRouteLib().then(l => set({ routeLib: l }))
  void autoSyncIntervals().then(() => ensureRoutes())
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') void autoSyncIntervals().then(() => ensureRoutes()) })
  // polnoč: osveži »danes«
  setInterval(() => { const t = todayIso(); if (t !== state.today) { set({ today: t }); void reloadAll() } }, 60_000)
  // račun in sinhronizacija — asinhrono, aplikacija dela tudi brez
  onSyncStatus(s => set({ sync: s }))
  onAuth(u => {
    set({ user: u, authKnown: true })
    if (u) { startSync(u.uid, () => { void reloadAll() }); void checkPro() }
    else { stopSync(); set({ pro: false }) }
  })
}

export async function reloadAll() {
  const today = todayIso()
  const ws = weekStartIso(today)
  const [profile, settings, activities, plan, mealsToday, recentMeals, checkinToday, checkins] = await Promise.all([
    repo.loadProfile(), repo.loadSettings(), repo.allActivities(), repo.planBetween(addDays(ws, -14), addDays(ws, 20)), repo.mealsOn(today),
    repo.mealsBetween(addDays(today, -90), today), repo.getCheckin(today), repo.allCheckins(),
  ])
  set({ profile, settings, activities, plan, mealsToday, recentMeals, checkinToday: checkinToday || null, checkins, today })
}

/* ---------- samodejni uvoz iz intervals.icu ---------- */
let icuBusy = false
/**
 * Nove vožnje iz intervals.icu brez klikanja: ob odprtju aplikacije, največ na 3 ure.
 * Prvič leto nazaj (zgodovina za formo in napredek), nato zadnje 3 tedne.
 * Izvor in zastavice določi uvoz (Strava ne gre v AI in ne na karto); napake so tihe — ročni uvoz jih pokaže.
 */
export async function autoSyncIntervals(force = false): Promise<void> {
  const c = state.settings.intervals
  if (!c || !c.athleteId || !c.apiKey || icuBusy || (typeof navigator !== 'undefined' && navigator.onLine === false)) return
  const last = (await getKV<number>('icu.autoAt')) || 0
  if (!force && Date.now() - last < 3 * 3600_000) return
  icuBusy = true
  try {
    await setKV('icu.autoAt', Date.now())
    const full = !(await getKV<boolean>('icu.fullDone'))
    const today = todayIso()
    const r = await fetchActivities(c, addDays(today, full ? -365 : -21), addDays(today, 1))
    for (const a of r.activities) if (!a.tss) a.tss = estimateTss(a, state.profile)
    // sledi ne shranjujemo pri vožnjah — trase gradi knjižnica tras (ensureRoutes), samo na tej napravi
    const before = new Set(state.activities.map(a => a.id))
    const res = await repo.addActivities(r.activities)
    if (full) await setKV('icu.fullDone', true)
    if (res.added || res.upgraded) {
      const all = await repo.allActivities()
      set({ activities: all }); void touch()
      await linkToPlan(all.filter(a => !before.has(a.id)))
      const bits = [res.added ? `+${res.added} novih` : '', res.upgraded ? `${res.upgraded} posodobljenih` : ''].filter(Boolean)
      toast(`intervals.icu: ${bits.join(' · ')}.`, 'info', 5000)
    }
  } catch { /* tiho */ }
  finally { icuBusy = false }
}

/* ---------- vreme ---------- */
export async function refreshWeather(force = true): Promise<Forecast | null> {
  const pl = state.profile.place
  if (!pl) { set({ weather: null }); return null }
  try {
    if (!force) { const c = await cachedForecast(pl.lat, pl.lon); if (c) set({ weather: c }) }
    const f = await forecast(pl.lat, pl.lon); set({ weather: f }); return f
  } catch { return state.weather }
}

/* ---------- akcije ---------- */
export async function updateProfile(patch: Partial<Profile>) {
  const p = await repo.saveProfile({ ...state.profile, ...patch })
  set({ profile: p }); void touch()
  if ('place' in patch) void refreshWeather(true)
  return p
}
export async function updateSettings(patch: Partial<Settings>) {
  const s = { ...state.settings, ...patch }
  await repo.saveSettings(s); set({ settings: s }); void touch()
  if (patch.accentHex) applyAccent(patch.accentHex)
}
export async function addActivities(list: Activity[]) {
  const before = new Set(state.activities.map(a => a.id))
  const r = await repo.addActivities(list)
  const all = await repo.allActivities()
  set({ activities: all }); void touch()
  await linkToPlan(all.filter(a => !before.has(a.id)))
  return r
}

/** Uvožena vožnja/vadba odkljuka načrtovano sejo istega dne in vrste — načrt ve, kje si, brez klikanja. */
async function linkToPlan(acts: readonly Activity[]) {
  let n = 0
  for (const a of acts) {
    if (a.date < addDays(state.today, -21) || state.plan.some(d => d.done?.activityId === a.id)) continue
    const fits = (k: string) => a.sport === 'moc' ? k === 'moc' : a.sport === 'kolo' ? k === 'kolo' || k === 'test' : k === a.sport
    const d = state.plan.filter(x => x.date === a.date && !x.done && fits(x.kind)).sort((x, y) => (x.optional ? 1 : 0) - (y.optional ? 1 : 0))[0]
    if (!d) continue
    await repo.putPlanDay({ ...d, done: { at: new Date().toISOString(), activityId: a.id } })
    state = { ...state, plan: state.plan.map(x => (x.id === d.id ? { ...x, done: { at: new Date().toISOString(), activityId: a.id } } : x)) }
    n++
  }
  if (n) { await reloadPlan(); void touch() }
}
export async function saveActivity(a: Activity) { await repo.putActivity(a); set({ activities: await repo.allActivities() }); void touch() }
export async function removeActivity(id: string) {
  await repo.deleteActivity(id); set({ activities: state.activities.filter(a => a.id !== id) })
  // dan v načrtu, ki je kazal na to aktivnost, ni več opravljen
  const d = state.plan.find(x => x.done?.activityId === id)
  if (d) { await repo.putPlanDay({ ...d, done: null }); await reloadPlan() }
  void touch()
}
export async function savePlanDays(days: PlanDay[]) { await repo.upsertPlanDays(days); await reloadPlan(); void touch() }
export async function savePlanDay(day: PlanDay) { await repo.putPlanDay(day); await reloadPlan(); void touch() }
export async function setPlanDone(id: string, done: boolean, activityId?: string | null) {
  const d = state.plan.find(x => x.id === id); if (!d) return
  await repo.putPlanDay({ ...d, done: done ? { at: new Date().toISOString(), activityId: activityId || null } : null })
  await reloadPlan(); void touch()
}
async function reloadPlan() { const ws = weekStartIso(state.today); set({ plan: await repo.planBetween(addDays(ws, -14), addDays(ws, 20)) }) }
async function reloadMeals() {
  const [mealsToday, recentMeals] = await Promise.all([repo.mealsOn(state.today), repo.mealsBetween(addDays(state.today, -90), state.today)])
  set({ mealsToday, recentMeals })
}
export async function addMeal(m: MealEntry) { await repo.putMeal(m); await reloadMeals(); void touch() }
export async function removeMeal(id: string) { await repo.deleteMeal(id); await reloadMeals(); void touch() }
export async function saveCheckin(c: DailyCheckin) {
  await repo.putCheckin(c)
  set({ checkinToday: c.date === state.today ? c : state.checkinToday, checkins: await repo.allCheckins() })
  // zadnja teža je tudi teža v profilu — iz nje se računajo kalorije
  if (c.weightKg && c.date >= (state.checkins.filter(x => x.weightKg).map(x => x.date).sort().pop() || '')) {
    if (state.profile.weightKg !== c.weightKg) await updateProfile({ weightKg: c.weightKg })
  }
  void touch()
}
export async function addTest(t: TestEntry) {
  const tests = [...(state.settings.tests || []).filter(x => x.id !== t.id), t].sort((a, b) => a.date.localeCompare(b.date))
  await updateSettings({ tests })
  if (t.kind === 'ftp') {
    const ftp = Math.round(t.value * 0.95)
    const w = state.profile.weightKg
    // uvodni test (do 14 dni po potrditvi cilja) postane izhodišče — cilji se preračunajo iz pravega FTP, ne ocene
    const gs = state.profile.goalStart
    const calib = gs && Math.abs(new Date(t.date).getTime() - new Date(gs.date).getTime()) <= 14 * 86400_000
    await updateProfile({ ftp, ftpDate: t.date, ...(calib ? { goalStart: { ...gs!, ftp } } : {}) })
    toast(`FTP ${ftp} W (95 % testa)${w ? ` = ${(ftp / w).toFixed(2).replace('.', ',')} W/kg` : ''}. Naslednji teden se sestavi z novimi vati.`, 'ok', 7000)
  }
  if (t.kind === 'p5') {
    const w = state.profile.weightKg
    if (w) toast(`5 min: ${(t.value / w).toFixed(2).replace('.', ',')} W/kg → VO2max ~${Math.round(10.8 * (t.value / w) + 7)} ml/kg/min (ocena).`, 'ok', 7000)
  }
  if (t.kind === 'rhr') await updateProfile({ restHr: Math.round(t.value) })
}
export async function removeTest(id: string) { await updateSettings({ tests: (state.settings.tests || []).filter(x => x.id !== id) }) }
export async function setMenu(menu: WeekMenu | null) { await updateSettings({ menu }) }

/* ---------- račun ---------- */
export async function signIn(): Promise<AuthUser | null> {
  const u = await signInGoogle()
  if (u) { set({ user: u, authKnown: true }); toast(`Prijavljen kot ${u.name || u.email || 'uporabnik'}`, 'ok') }
  return u
}
export async function signOut() {
  await pushNow().catch(() => undefined)
  await signOutNow()
  stopSync()
  set({ user: null, pro: false })
  toast('Odjavljen. Podatki ostanejo na tej napravi.', 'info')
}
export async function checkPro(): Promise<boolean> {
  try {
    const t = await idToken(); if (!t) return false
    let pro = false
    try {
      const r = await fetch('https://forma-ai-proxy-602565779369.europe-west1.run.app/stripe/status', { headers: { Authorization: `Bearer ${t}` } })
      if (r.ok) pro = !!((await r.json()) as { pro?: boolean }).pro
    } catch { /* strežnik te poti morda nima */ }
    // strežnik kvoto odloča po proUsers/{uid}.pro — isti dokument preberemo še neposredno (lastnik ga sme brati)
    if (!pro) pro = await proFromFirestore()
    set({ pro }); return pro
  } catch { return false }
}

/* ---------- trase ---------- */
let routesRunning = false
/** Dopolni knjižnico tras iz voženj z Garmina (intervals.icu). Tiho; ob napaki poskusi ob naslednjem zagonu. */
export async function ensureRoutes(): Promise<void> {
  const c = state.settings.intervals
  if (routesRunning) return
  if (!c || !c.athleteId || !c.apiKey || (typeof navigator !== 'undefined' && navigator.onLine === false)) { if (!state.routeLib) set({ routeLib: await loadRouteLib() }); return }
  routesRunning = true; set({ routesBusy: true })
  try { const { lib } = await fillRouteLib(c, state.activities); set({ routeLib: lib }) }
  catch { /* tiho */ }
  finally { routesRunning = false; set({ routesBusy: false }) }
}

/**
 * Nova trasa za dan (BRouter): za Z2/regeneracijo najbolj ravna od treh smeri, za intervale čez tvoj najboljši klanec,
 * sicer krog v novi smeri. Dolžina tako, da ocenjeni čas ustreza treningu.
 */
export async function newRouteFor(day: PlanDay, seed: number): Promise<RouteRec> {
  const lib = state.routeLib || await loadRouteLib()
  const home = lib.home
  if (!home) throw new Error('Za novo traso rabim vsaj eno vožnjo z Garmina (začetek poti). Ko pride prva, poskusi znova.')
  const need = needOf(day, state.profile)
  if (!need) throw new Error('Za ta dan ni vožnje.')
  const p = state.profile, recs = routesOf(lib), k = paceFactor(recs, p)
  const hard = need.need === 'vo2' || need.need === 'prag' || need.need === 'test'
  let via: [number, number][] | undefined
  if (hard) {
    const best = suggestRoutes(recs.filter(r => r.source === 'voznja'), need, p, state.today, k).find(s => s.climb)
    if (best?.climb) via = [best.climb.foot, best.climb.top]
  }
  const { routed, via: pts } = await makeLoop(home, need.minutes, prof => estMinutes({ prof }, need, p, k), { seed, wantFlat: need.need === 'z2' || need.need === 'regen', via })
  const rec = routedToRec(routed, pts, `Nova trasa · ${need.label}`, day.date)
  if (!rec) throw new Error('Trasa je prekratka — poskusi znova.')
  const l2 = await addGenerated(rec)
  set({ routeLib: l2 })
  return rec
}

/* ---------- privolitev za AI ---------- */
export async function grantAiConsent() { await updateProfile({ aiConsentAt: new Date().toISOString() }) }
export async function revokeAiConsent() { await updateProfile({ aiConsentAt: null }); toast('AI obdelava izklopljena. Tvoji podatki ostanejo; nasveti se ustavijo.', 'info') }

let toastId = 0
export function toast(msg: string, kind: 'ok' | 'err' | 'info' = 'info', ms = 4200) {
  const id = ++toastId
  set({ toast: { msg, kind, id } })
  setTimeout(() => { if (state.toast?.id === id) set({ toast: null }) }, ms)
}

export function applyAccent(hex: string) {
  const r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b = parseInt(hex.slice(5, 7), 16)
  const root = document.documentElement.style
  root.setProperty('--accent', hex)
  root.setProperty('--accent-soft', `rgba(${r},${g},${b},.14)`)
}
