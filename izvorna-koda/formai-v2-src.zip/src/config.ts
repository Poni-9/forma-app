/* Konfiguracija, ki jo je dovoljeno imeti v odjemalcu. Skrivnosti so na strežniku (Cloud Run). */
export const APP_URL = 'https://formai.si'
/** Brezplačna dnevna kvota AI na strežniku; neomejeno z dokumentom proUsers/{uid} → pro: true (Firebase konzola). */
export const FREE_AI_PER_DAY = 10
/** Strežnik (Cloud Run): AI, Stripe, izmenjava kode intervals.icu OAuth. */
export const PROXY = 'https://forma-ai-proxy-602565779369.europe-west1.run.app'
/**
 * intervals.icu OAuth (»Poveži z intervals.icu« z enim dotikom). Client ID dobiš na https://intervals.icu/oauth/apply
 * (redirect URI: https://formai.si/). Gumb se pokaže šele, ko strežnik javi, da je OAuth nastavljen (/health → icu),
 * torej ko intervals.icu aplikacijo odobri in je na strežniku ICU_CLIENT_SECRET; do takrat povezava z osebnim API ključem.
 * Skrivnost (client secret) je SAMO na strežniku (ICU_CLIENT_SECRET).
 */
export const ICU_CLIENT_ID = '1092'
export const ICU_SCOPES = 'ACTIVITY:READ,WELLNESS:READ,CALENDAR:WRITE,SETTINGS:READ'

/** Različica za pregled testnega programa (in Nastavitve). */
export const APP_VERSION = '3.23.1'
