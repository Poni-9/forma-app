/* Konfiguracija, ki jo je dovoljeno imeti v odjemalcu. Skrivnosti so na strežniku (Cloud Run). */
export const APP_URL = 'https://formai.si'
/** Brezplačna dnevna kvota AI na strežniku; neomejeno z dokumentom proUsers/{uid} → pro: true (Firebase konzola). */
export const FREE_AI_PER_DAY = 10
