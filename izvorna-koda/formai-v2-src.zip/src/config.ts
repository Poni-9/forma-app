/* Konfiguracija, ki jo je dovoljeno imeti v odjemalcu. Skrivnosti so na strežniku (Cloud Run). */
export const APP_URL = 'https://formai.si'
/**
 * Dnevna meja AI za brezplačne račune (strežnik: FREE_CALLS_PER_DAY). Blaž 4. 10.: »neomejeno, razen ena res visoka
 * omejitev« → 1000 na dan: pri normalni uporabi je ne dosežeš, ustavi pa skripto ali zlorabo (strošek). null = brez.
 * Pro (proUsers/{uid} → pro: true) je vedno brez omejitve.
 */
export const FREE_AI_PER_DAY: number | null = 1000
/** Strežnik (Cloud Run): AI, Stripe, izmenjava kode intervals.icu OAuth. */
export const PROXY = 'https://forma-ai-proxy-602565779369.europe-west1.run.app'
/**
 * intervals.icu OAuth (»Poveži z intervals.icu« z enim dotikom). Client ID dobiš na https://intervals.icu/oauth/apply
 * (redirect URI: https://formai.si/). Gumb se pokaže šele, ko strežnik javi, da je OAuth nastavljen (/health → icu),
 * torej ko intervals.icu aplikacijo odobri in je na strežniku ICU_CLIENT_SECRET; do takrat povezava z osebnim API ključem.
 * Skrivnost (client secret) je SAMO na strežniku (ICU_CLIENT_SECRET).
 */
export const ICU_CLIENT_ID = '1092'
export const ICU_SCOPES = 'ACTIVITY:READ,WELLNESS:READ,CALENDAR:WRITE,SETTINGS:READ'

/** Različica za pregled testnega programa (in Nastavitve). */
export const APP_VERSION = '3.32.0'
