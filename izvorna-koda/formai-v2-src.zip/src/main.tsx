import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { registerSW } from 'virtual:pwa-register'
import './styles/tokens.css'
import './styles/base.css'
import './styles/motion.css'
import { App } from './app/App'

registerSW({ immediate: true })

// Predpomnilniki stare aplikacije (sw.js »formai-…«) niso več v rabi — počisti jih enkrat.
try { if ('caches' in window) void caches.keys().then(ks => Promise.all(ks.filter(k => k.startsWith('formai-')).map(k => caches.delete(k)))) } catch { /* brez predpomnilnika */ }

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
