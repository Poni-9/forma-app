import './styles/tokens.css'
import './styles/base.css'
import './styles/motion.css'
import { gate } from './app/enter'

/*
 * Vstop je namenoma majhen: pristajalna stran (is-land) dobi samo CSS in ta modul. Aplikacija (React, stanje,
 * zasloni, Firebase) je v ./app/start in se naloži v načinu aplikacije ali ob vstopu s pristajalne strani (enter.ts).
 */

// Namestitveni poziv (Chrome) lahko pride, preden je aplikacija naložena — shrani ga in ga ob zagonu ponovi.
let bip: Event | null = null
const keepBip = (e: Event) => { e.preventDefault(); bip = e }
addEventListener('beforeinstallprompt', keepBip)

let app: Promise<typeof import('./app/start')> | null = null
const load = () => (app ??= import('./app/start').catch(e => { app = null; throw e }))

gate({
  load,
  start: () => {
    load().then(m => {
      removeEventListener('beforeinstallprompt', keepBip)
      m.start()
      if (bip) dispatchEvent(bip)
    }, () => {
      // brez omrežja in brez predpomnilnika (prvi obisk): povej, namesto da ostane samo logotip
      const root = document.getElementById('root')
      if (root) root.innerHTML = '<div class="boot0" style="display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:24px;text-align:center"><div>FORM<b>AI</b></div><p style="font-weight:600;font-size:14px;max-width:280px">Aplikacije ni bilo mogoče naložiti. Preveri povezavo in poskusi znova.</p><button class="btn primary sm" onclick="location.reload()">Poskusi znova</button></div>'
    })
  },
})
