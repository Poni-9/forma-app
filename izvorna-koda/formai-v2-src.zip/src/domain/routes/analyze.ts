import { encodePolyline, decodePolyline, haversineM, isValidLatLon, type LatLon } from '../import/polyline'

/**
 * TRASE — analiza sledi (brez omrežja, čiste funkcije).
 * Iz sledi in višin izračuna: dolžino, vzpon, profil (vsakih 50 m), klance in ali je krog.
 * Viri so samo uporabnikove vožnje z Garmina (prek intervals.icu) in trase, ki jih ustvari aplikacija —
 * Stravini podatki sem ne pridejo (API politika §5.3, §6.2).
 */

export interface Climb {
  /** začetek klanca v km od starta */
  atKm: number
  /** dolžina v km */
  km: number
  gainM: number
  /** povprečni naklon v % */
  grade: number
  /** vznožje in vrh (za ponovitve in za nove trase čez ta klanec) */
  foot: LatLon
  top: LatLon
}

export interface RouteRec {
  id: string
  source: 'voznja' | 'nova'
  name: string
  /** zadnjič prevožena (za vožnje) ali ustvarjena */
  date: string | null
  km: number
  gainM: number
  /** dejanski čas vožnje (min), če je bila prevožena */
  rodeMin: number | null
  loop: boolean
  start: LatLon
  /** zredčena sled (~40 m), kodirana */
  poly: string
  /** višine vsakih 50 m */
  prof: number[]
  climbs: Climb[]
  /** m vzpona na km */
  hilly: number
  /** kolikokrat prevožena (podobne vožnje združene) */
  times: number
  /** povezava na vožnjo v intervals.icu (za zemljevid) */
  icuId?: string | number | null
  /** točke za brouter-web (nove trase) */
  via?: LatLon[]
}

export const STEP_M = 50

/** Pripravi točke in višine: izpusti neveljavne, višine brez vrednosti zapolni s prejšnjo. */
export function cleanTrack(lat: (number | null)[], lng: (number | null)[], alt: (number | null)[] | null): { pts: LatLon[]; alt: number[] } {
  const pts: LatLon[] = [], h: number[] = []
  let lastH: number | null = null
  for (let i = 0; i < Math.min(lat.length, lng.length); i++) {
    const a = lat[i], b = lng[i]
    const z = alt ? alt[i] : null
    if (z != null && Number.isFinite(z)) lastH = z
    if (a == null || b == null) continue
    const p: LatLon = [+a, +b]
    if (!isValidLatLon(p)) continue
    pts.push(p); h.push(lastH ?? NaN)
  }
  // začetek brez višine: zapolni s prvo znano
  const first = h.find(x => Number.isFinite(x))
  for (let i = 0; i < h.length && !Number.isFinite(h[i]!); i++) h[i] = first ?? 0
  return { pts, alt: h }
}

/** Kumulativna razdalja v metrih. */
export function cumDist(pts: readonly LatLon[]): number[] {
  const d = [0]
  for (let i = 1; i < pts.length; i++) d.push(d[i - 1]! + haversineM(pts[i - 1]!, pts[i]!))
  return d
}

/** Višine na vsakih STEP_M metrov (linearna interpolacija) + glajenje (drseče povprečje 5 točk = 250 m). */
export function profileOf(d: readonly number[], alt: readonly number[], step = STEP_M): number[] {
  const total = d[d.length - 1] || 0
  const out: number[] = []
  let j = 0
  for (let s = 0; s <= total; s += step) {
    while (j < d.length - 2 && d[j + 1]! < s) j++
    const d0 = d[j]!, d1 = d[j + 1] ?? d0, a0 = alt[j]!, a1 = alt[j + 1] ?? a0
    const t = d1 > d0 ? (s - d0) / (d1 - d0) : 0
    out.push(a0 + (a1 - a0) * Math.max(0, Math.min(1, t)))
  }
  const k = 2
  return out.map((_, i) => { let s = 0, n = 0; for (let q = i - k; q <= i + k; q++) if (q >= 0 && q < out.length) { s += out[q]!; n++ } return Math.round(s / n) })
}

/** Vzpon iz zglajenega profila (s pragom 2 m proti šumu). */
export function gainOf(prof: readonly number[]): number {
  let g = 0, ref = prof[0] ?? 0
  for (const h of prof) {
    if (h > ref + 2) { g += h - ref; ref = h }
    else if (h < ref - 2) ref = h
  }
  return Math.round(g)
}

/** Točka na sledi na razdalji m (najbližja). */
function pointAt(pts: readonly LatLon[], d: readonly number[], m: number): LatLon {
  let lo = 0, hi = d.length - 1
  while (lo < hi) { const mid = (lo + hi) >> 1; if (d[mid]! < m) lo = mid + 1; else hi = mid }
  return pts[Math.min(lo, pts.length - 1)]!
}

/**
 * Klanci: od lokalnega minimuma navzgor, dokler se ne spusti več kot 10 m pod doseženi vrh
 * ali je 800 m ravno. Obdrži vzpone ≥ 35 m, ≥ 500 m, povprečno ≥ 3 %.
 */
export function climbsOf(prof: readonly number[], pts: readonly LatLon[], d: readonly number[], step = STEP_M): Climb[] {
  const out: Climb[] = []
  let i = 0
  while (i < prof.length - 1) {
    while (i < prof.length - 1 && prof[i + 1]! <= prof[i]!) i++
    const s = i
    let top = i, max = prof[i]!, j = i
    while (j < prof.length - 1) {
      j++
      if (prof[j]! > max) { max = prof[j]!; top = j }
      else if (max - prof[j]! > 10) break
      else if ((j - top) * step > 800) break
    }
    const gain = max - prof[s]!, len = (top - s) * step
    if (gain >= 35 && len >= 500 && gain / len >= 0.03) {
      out.push({ atKm: +(s * step / 1000).toFixed(1), km: +(len / 1000).toFixed(2), gainM: Math.round(gain), grade: +((gain / len) * 100).toFixed(1), foot: pointAt(pts, d, s * step), top: pointAt(pts, d, top * step) })
    }
    i = Math.max(top, s + 1)
  }
  return out
}

/** Redčenje na ~minM metrov za shranjevanje in risanje. */
function thin(pts: readonly LatLon[], minM: number): LatLon[] {
  if (pts.length < 2) return [...pts]
  const out: LatLon[] = [pts[0]!]
  for (const p of pts) if (haversineM(out[out.length - 1]!, p) >= minM) out.push(p)
  if (out[out.length - 1] !== pts[pts.length - 1]) out.push(pts[pts.length - 1]!)
  return out
}

/** Iz sledi in višin sestavi zapis trase. */
export function analyzeTrack(meta: Pick<RouteRec, 'id' | 'source' | 'name' | 'date' | 'rodeMin'> & { icuId?: string | number | null; via?: LatLon[] }, pts: readonly LatLon[], alt: readonly number[]): RouteRec | null {
  if (pts.length < 10) return null
  const d = cumDist(pts)
  const total = d[d.length - 1]!
  if (total < 2000) return null
  const prof = profileOf(d, alt)
  const gainM = gainOf(prof)
  const km = +(total / 1000).toFixed(1)
  return {
    ...meta, km, gainM, loop: haversineM(pts[0]!, pts[pts.length - 1]!) < 1000, start: pts[0]!,
    poly: encodePolyline(thin(pts, 40)), prof, climbs: climbsOf(prof, pts, d), hilly: +(gainM / Math.max(1, km)).toFixed(1), times: 1,
  }
}

/** Ali sta trasi v bistvu isti krog (za združevanje ponovljenih voženj). */
export function sameRoute(a: RouteRec, b: RouteRec): boolean {
  if (Math.abs(a.km - b.km) > Math.max(1.5, a.km * 0.06)) return false
  if (haversineM(a.start, b.start) > 600) return false
  const pa = decodePolyline(a.poly), pb = decodePolyline(b.poly)
  const sample = (p: LatLon[]) => Array.from({ length: 16 }, (_, k) => p[Math.floor((k / 16) * (p.length - 1))]!)
  const near = (p: LatLon, list: LatLon[]) => list.reduce((m, q) => Math.min(m, haversineM(p, q)), Infinity)
  const sa = sample(pa)
  const avg = sa.reduce((s, p) => s + near(p, pb), 0) / sa.length
  return avg < 350
}

/** Združi ponovljene vožnje iste trase: obdrži najnovejšo, šteje ponovitve. */
export function dedupeRoutes(recs: readonly RouteRec[]): RouteRec[] {
  const sorted = [...recs].sort((a, b) => (b.date || '').localeCompare(a.date || ''))
  const out: RouteRec[] = []
  for (const r of sorted) {
    const same = r.source === 'voznja' ? out.find(o => o.source === 'voznja' && sameRoute(o, r)) : undefined
    if (same) same.times++
    else out.push({ ...r })
  }
  return out
}

/** Dom = najpogostejši start voženj (celica ~400 m); vrne povprečje startov v tej celici. */
export function homeOf(starts: readonly LatLon[]): LatLon | null {
  if (!starts.length) return null
  const cell = (p: LatLon) => `${Math.round(p[0] / 0.0036)}:${Math.round(p[1] / 0.0052)}`
  const m = new Map<string, LatLon[]>()
  for (const p of starts) { const k = cell(p); m.set(k, [...(m.get(k) || []), p]) }
  const best = [...m.values()].sort((a, b) => b.length - a.length)[0]!
  return [best.reduce((s, p) => s + p[0], 0) / best.length, best.reduce((s, p) => s + p[1], 0) / best.length]
}

/* ---------- fizika: hitrost pri dani moči ---------- */
/** Hitrost (m/s) pri moči P (W) na naklonu grade (0,06 = 6 %). Spust omejen na 50 km/h. */
export function speedAt(P: number, grade: number, massKg: number, cda = 0.32, crr = 0.005, rho = 1.2): number {
  const g = 9.81, th = Math.atan(grade)
  const F = massKg * g * (Math.sin(th) + crr * Math.cos(th))
  const f = (v: number) => v * F + 0.5 * rho * cda * v ** 3 - P
  let lo = 0.3, hi = 30
  if (f(lo) > 0) return lo
  for (let i = 0; i < 32; i++) { const mid = (lo + hi) / 2; if (f(mid) > 0) hi = mid; else lo = mid }
  return Math.min((lo + hi) / 2, 13.9)
}

/** Ocena časa (min) za traso pri enakomerni moči P (npr. Z2 = 65 % FTP). */
export function rideMinutes(prof: readonly number[], P: number, massKg: number, step = STEP_M): number {
  let s = 0
  for (let i = 1; i < prof.length; i++) {
    const grade = (prof[i]! - prof[i - 1]!) / step
    s += step / speedAt(grade < -0.02 ? P * 0.3 : P, grade, massKg)
  }
  return Math.round(s / 60)
}

/** Koliko časa (s) traja klanec pri moči P. */
export function climbSeconds(c: Pick<Climb, 'km' | 'grade'>, P: number, massKg: number): number {
  return Math.round((c.km * 1000) / speedAt(P, c.grade / 100, massKg))
}

/** Točka na sledi, kjer se konča interval na klancu: od vznožja naprej toliko, kolikor prevoziš v workMin pri moči W (največ do vrha). */
export function climbTurnPoint(poly: string, c: Pick<Climb, 'atKm' | 'km' | 'grade' | 'top'>, W: number, massKg: number, workMin: number): LatLon {
  const dKm = (speedAt(W, c.grade / 100, massKg) * workMin * 60) / 1000
  if (dKm >= c.km) return c.top
  const pts = decodePolyline(poly)
  const target = (c.atKm + dKm) * 1000
  let d = 0
  for (let i = 1; i < pts.length; i++) { d += haversineM(pts[i - 1]!, pts[i]!); if (d >= target) return pts[i]! }
  return c.top
}

const DIRS = ['severu', 'severovzhodu', 'vzhodu', 'jugovzhodu', 'jugu', 'jugozahodu', 'zahodu', 'severozahodu']
/** Smer trase: kam gre najdlje od starta (»proti severu«). */
export function directionOf(poly: string): string | null {
  const pts = decodePolyline(poly)
  if (pts.length < 2) return null
  const s = pts[0]!
  let far = s, fd = 0
  for (const q of pts) { const d = haversineM(s, q); if (d > fd) { fd = d; far = q } }
  if (fd < 1500) return null
  const y = Math.sin(((far[1] - s[1]) * Math.PI) / 180) * Math.cos((far[0] * Math.PI) / 180)
  const x = Math.cos((s[0] * Math.PI) / 180) * Math.sin((far[0] * Math.PI) / 180) - Math.sin((s[0] * Math.PI) / 180) * Math.cos((far[0] * Math.PI) / 180) * Math.cos(((far[1] - s[1]) * Math.PI) / 180)
  const brg = ((Math.atan2(y, x) * 180) / Math.PI + 360) % 360
  return DIRS[Math.round(brg / 45) % 8]!
}

/** Ime trase za prikaz: Garminova imena (»Vodice Kolesarjenje«) so vsa enaka — takrat opis s km in smerjo. */
export function routeTitle(r: Pick<RouteRec, 'name' | 'km' | 'loop' | 'poly' | 'source'>): string {
  if (r.source === 'nova') return 'Nova trasa'
  const generic = /(kolesarjenje|ride|cycling|vožnja|voznja|biking)\s*$/i.test(r.name.trim())
  if (!generic) return r.name
  const dir = directionOf(r.poly)
  return `${String(r.km).replace('.', ',')} km ${r.loop ? 'krog' : 'trasa'}${dir ? ` proti ${dir}` : ''}`
}

