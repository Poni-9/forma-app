/**
 * Profil BRouter »cestno kolo za trening« — izpeljan iz profila fastbike-lowtraffic (BRouter, MIT licenca).
 * Spremembe: brez makadama in poljskih poti (track/path/footway samo, če so označene kot asfalt), neasfaltirane
 * ceste prepovedane, semafor stane kot 250 m ovinka (prej 20), mimo naselij (consider_town), brez stopnic,
 * kolesarske steze le asfaltne in rahlo dražje od cest. Pošlje se enkrat na sejo (BRouter vrne začasen id).
 */
export const ROAD_PROFILE_NAME = 'formai-cesta-v1'
export const ROAD_PROFILE = `---context:global
assign validForBikes = true
assign allow_steps           = false
assign allow_ferries         = true
assign allow_motorways       = false
assign use_proposed_cycleroutes = false
assign consider_traffic = true
assign consider_noise        = false
assign consider_river        = false
assign consider_forest       = false
assign consider_town         = true
assign consider_elevation = true
assign downhillcost       = 60
assign downhillcutoff     = 1.5
assign uphillcost         = 0
assign uphillcutoff       = 1.5
assign downhillcost       = if consider_elevation then downhillcost else 0
assign uphillcost         = if consider_elevation then uphillcost else 0
assign totalMass  = 90
assign maxSpeed   = 45
assign S_C_x      = 0.225
assign C_r        = 0.01
assign bikerPower = 100
assign turnInstructionMode          = 1
assign turnInstructionCatchingRange = 40
assign turnInstructionRoundabouts   = true
assign considerTurnRestrictions     = true
assign correctMisplacedViaPoints = false
assign correctMisplacedViaPointsDistance = 400
assign processUnusedTags            = false
---context:way
assign any_cycleroute
  switch not use_proposed_cycleroutes
    or route_bicycle_icn=yes or route_bicycle_ncn=yes or route_bicycle_rcn=yes route_bicycle_lcn=yes
    or route_bicycle_icn=yes|proposed or route_bicycle_ncn=yes|proposed or route_bicycle_rcn=yes|proposed route_bicycle_lcn=yes|proposed
assign nodeaccessgranted or any_cycleroute lcn=yes
assign ispaved or surface=paved or surface=asphalt or surface=concrete or surface=paving_stones or surface=sett or smoothness=excellent smoothness=good
assign isunpaved not or ispaved or ( and surface= smoothness= ) or surface=fine_gravel or surface=cobblestone smoothness=intermediate
assign turncost = if junction=roundabout then 0
                  else 90
assign initialclassifier =
     if route=ferry then 1
     else 0
assign initialcost switch route=ferry 10000 0
assign defaultaccess
       switch access=
              (
                    if motorroad=yes then false
                    else if highway=motorway|motorway_link then false
                    else true
              )
              switch or access=private access=no
                     false
                     true
assign bikeaccess =
       switch bicycle=
              switch bicycle_road=yes
                 true
                 switch vehicle=
                        ( if highway=footway then false else defaultaccess )
                        not vehicle=private|no
              not or bicycle=private or bicycle=no or bicycle=dismount bicycle=use_sidepath
assign footaccess =
       or bicycle=dismount
          switch foot=
                 defaultaccess
                 not or foot=private or foot=no foot=use_sidepath
assign accesspenalty
       switch bikeaccess
              0
              switch footaccess
                     5
                     switch any_cycleroute
                            15
                            switch bicycle=use_sidepath
                                   25
                                   10000
assign badoneway =
       if reversedirection=yes then
         if oneway:bicycle=yes then true
         else if oneway= then junction=roundabout
         else oneway=yes|true|1
       else oneway=-1
assign hascycleway = not
  and ( or cycleway= cycleway=no|none ) and ( or cycleway:left= cycleway:left=no ) and ( or cycleway:right= cycleway:right=no ) ( or cycleway:both= cycleway:both=no )
assign onewaypenalty =
       if ( badoneway ) then
       (
         if (
           and hascycleway
           or and cycleway:left=lane|track|shared_lane|share_busway
                  cycleway:left:oneway=no|-1
           or and cycleway:right=lane|track|shared_lane|share_busway
                  cycleway:right:oneway=no|-1
           or and cycleway:both=lane|track|shared_lane|share_busway
                  or cycleway:left:oneway=no|-1
                     cycleway:right:oneway=no|-1
           or cycleway=opposite|opposite_lane|opposite_track
           or cycleway:left=opposite|opposite_lane|opposite_track
              cycleway:right=opposite|opposite_lane|opposite_track
                                                             ) then 0
         else if ( oneway:bicycle=no                         ) then 0
         else if ( not footaccess                            ) then 100
         else if ( junction=roundabout|circular              ) then 60
         else if ( highway=primary|primary_link              ) then 50
         else if ( highway=secondary|secondary_link          ) then 30
         else if ( highway=tertiary|tertiary_link            ) then 20
         else 6.0
       )
       else 0.0
assign trafficpenalty =
      if not consider_traffic then 0
      else
      min switch hascycleway 0.3 100
      if   estimated_traffic_class=|1|2  then 0
      else if estimated_traffic_class=3 then multiply   0.3   consider_traffic
      else if estimated_traffic_class=4 then multiply   0.6   consider_traffic
      else if estimated_traffic_class=5 then multiply   0.9   consider_traffic
      else if estimated_traffic_class=6|7 then multiply 1.5   consider_traffic
      else 0
assign isresidentialorliving = or highway=residential|living_street living_street=yes
assign noise_penalty
   switch consider_noise
     switch estimated_noise_class=  0
     switch estimated_noise_class=1  0.3
     switch estimated_noise_class=2  0.5
     switch estimated_noise_class=3  0.7
     switch estimated_noise_class=4  1
     switch estimated_noise_class=5  1.2
     switch estimated_noise_class=6  1.5 0 0
assign no_river_penalty
   switch consider_river
     switch estimated_river_class=  3
     switch estimated_river_class=1  2
     switch estimated_river_class=2  1.5
     switch estimated_river_class=3  1
     switch estimated_river_class=4  0.5
     switch estimated_river_class=5  0.2
     switch estimated_river_class=6  0 99 0
assign no_forest_penalty
   switch consider_forest
     switch estimated_forest_class=  1
     switch estimated_forest_class=1  0.5
     switch estimated_forest_class=2  0.4
     switch estimated_forest_class=3  0.25
     switch estimated_forest_class=4  0.15
     switch estimated_forest_class=5  0.1
     switch estimated_forest_class=6  0 99 0
assign town_penalty
   switch consider_town
     switch estimated_town_class=  0
     switch estimated_town_class=1  0.2
     switch estimated_town_class=2  0.4
     switch estimated_town_class=3  0.6
     switch estimated_town_class=4  0.7
     switch estimated_town_class=5  0.8
     switch estimated_town_class=6  1 99 0
assign costfactor
  switch and highway= not route=ferry  10000
  switch or highway=proposed highway=abandoned 10000
  min 9999
  add max onewaypenalty accesspenalty
  add trafficpenalty
  add town_penalty
  add no_forest_penalty
  add no_river_penalty
  add noise_penalty
  switch or highway=motorway highway=motorway_link    switch allow_motorways 1.5 10000
  switch or highway=trunk highway=trunk_link          switch allow_motorways 1.5 10
  switch or highway=primary highway=primary_link      1.2
  switch or highway=secondary highway=secondary_link  1.1
  switch or highway=tertiary highway=tertiary_link    1.0
  switch    highway=unclassified                      switch isunpaved 10000 1.1
  switch    highway=pedestrian                        switch hascycleway 1.3 5
  switch    highway=steps                             switch allow_steps 120 10000
  switch    route=ferry                               switch allow_ferries 5.67 10000
  switch    highway=bridleway                         5
  switch    highway=cycleway                          switch isunpaved 10000 1.6
  switch    isresidentialorliving                     switch isunpaved 10000 1.4
  switch    highway=service                           switch isunpaved 10000 1.5
  switch or highway=track or highway=road or highway=path highway=footway
   switch ispaved 2.5 10000
  10.0
assign priorityclassifier =
  if      ( highway=motorway                         ) then  30
  else if ( highway=motorway_link                    ) then  29
  else if ( highway=trunk                            ) then  28
  else if ( highway=trunk_link                       ) then  27
  else if ( highway=primary                          ) then  26
  else if ( highway=primary_link                     ) then  25
  else if ( highway=secondary                        ) then  24
  else if ( highway=secondary_link                   ) then  23
  else if ( highway=tertiary                         ) then  22
  else if ( highway=tertiary_link                    ) then  21
  else if ( highway=unclassified                     ) then  20
  else if ( isresidentialorliving                    ) then  6
  else if ( highway=service                          ) then  6
  else if ( highway=cycleway                         ) then  6
  else if ( or bicycle=designated bicycle_road=yes   ) then  6
  else if ( highway=track                            ) then if tracktype=grade1 then 6 else 4
  else if ( highway=bridleway|road|path|footway      ) then  4
  else if ( highway=steps                            ) then  2
  else if ( highway=pedestrian                       ) then  2
  else 0
assign isbadoneway = not equal onewaypenalty 0
assign isgoodoneway = if reversedirection=yes then oneway=-1
                      else if oneway= then junction=roundabout else oneway=yes|true|1
assign isroundabout = junction=roundabout
assign islinktype = highway=motorway_link|trunk_link|primary_link|secondary_link|tertiary_link
assign isgoodforcars = if greater priorityclassifier 6 then true
                  else if ( or isresidentialorliving highway=service ) then true
                  else if ( and highway=track tracktype=grade1 ) then true
                  else false
assign classifiermask add          isbadoneway
                      add multiply isgoodoneway   2
                      add multiply isroundabout   4
                      add multiply islinktype     8
                          multiply isgoodforcars 16
assign dummyUsage = smoothness=
---context:node
assign defaultaccess
       switch access=
              1
              switch or access=private access=no
                     0
                     1
assign bikeaccess
       or nodeaccessgranted=yes
          switch bicycle=
                 switch vehicle=
                        defaultaccess
                        switch or vehicle=private vehicle=no
                               0
                               1
                 switch or bicycle=private or bicycle=no bicycle=dismount
                        0
                        1
assign footaccess
       or bicycle=dismount
          switch foot=
                 defaultaccess
                 switch or foot=private foot=no
                        0
                        1
assign initialcost
    switch or highway=traffic_signals and highway=crossing crossing=traffic_signals 250
       switch bikeaccess
              0
              switch footaccess
                     300
                     1000000
`
