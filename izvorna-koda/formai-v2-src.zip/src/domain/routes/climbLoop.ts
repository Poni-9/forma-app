import type { Profile } from '../types'
import { haversineM, type LatLon } from '../import/polyline'
import { climbSeconds, climbTurnPoint, speedAt, type Climb, type RouteRec } from './analyze'
import type { RouteNeed } from './match'

/**
 * INTERVALI ČEZ VEČ KLANCEV. Namesto N-krat gor in dol po istem klancu krog čez 2–4 različne, a podobne klance
 * iz tvojih voženj (podoben čas pri ciljnih vatih, podoben naklon): vsak interval na svojem klancu, vmes Z2 do
 * naslednjega. Klanci so razvrščeni po smeri okoli doma, da krog ne gre dvakrat po isti cesti. Pot med njimi
 * nariše BRouter s profilom za cestno kolo (brez makadama, mimo naselij, semafor je drag).
 */
export interface ClimbCand {
  /** za podvojene: isti klanec iz več voženj */
  key: string
  climb: Climb
  /** čas klanca pri ciljni moči (s) */
  sec: number
  /** točka, kjer se interval izteče (ne nujno vrh) */
  turn: LatLon
  /** oddaljenost vznožja od doma (km) in smer od doma (stopinje, 0 = sever) */
  distKm: number
  bearing: number
  /** kolikokrat je bila vožnja s tem klancem prevožena */
  times: number
}

const bearingOf = (a: LatLon, b: LatLon): number => {
  const la1 = (a[0] * Math.PI) / 180, la2 = (b[0] * Math.PI) / 180, dl = ((b[1] - a[1]) * Math.PI) / 180
  const y = Math.sin(dl) * Math.cos(la2), x = Math.cos(la1) * Math.sin(la2) - Math.sin(la1) * Math.cos(la2) * Math.cos(dl)
  return (((Math.atan2(y, x) * 180) / Math.PI) + 360) % 360
}
const angDiff = (a: number, b: number) => { const d = Math.abs(a - b) % 360; return d > 180 ? 360 - d : d }

/** Najkrajši čas klanca za interval: VO2max ~90 % intervala, prag ~70 % (ostanek po vrhu v istem tempu). */
export const needSecOf = (need: Pick<RouteNeed, 'need' | 'workMin'>): number => need.workMin * 60 * (need.need === 'vo2' ? 0.9 : 0.7)
/** VO2max gre tudi na strm klanec, prag ne (enakomerna moč). */
export const maxGradeOf = (need: Pick<RouteNeed, 'need'>): number => (need.need === 'vo2' ? 14 : 11)

/** Klanci iz tvojih voženj, primerni za interval te seje, do maxKm od doma; isti klanec iz več voženj samo enkrat. */
export function climbCandidates(recs: readonly RouteRec[], need: RouteNeed, p: Pick<Profile, 'ftp' | 'weightKg'>, home: LatLon, maxKm = 20): ClimbCand[] {
  const mass = (p.weightKg || 75) + 9, W = need.workW || p.ftp || 200
  const needSec = needSecOf(need), maxG = maxGradeOf(need)
  const out: ClimbCand[] = []
  for (const rec of [...recs].filter(r => r.source === 'voznja').sort((a, b) => b.times - a.times)) {
    for (const c of rec.climbs) {
      if (c.grade < 3.5 || c.grade > maxG) continue
      const sec = climbSeconds(c, W, mass)
      if (sec < needSec) continue
      const distKm = haversineM(home, c.foot) / 1000
      if (distKm > maxKm) continue
      if (out.some(o => haversineM(o.climb.foot, c.foot) < 300 && haversineM(o.climb.top, c.top) < 500)) continue   // isti klanec
      out.push({ key: `${c.foot[0].toFixed(3)},${c.foot[1].toFixed(3)}`, climb: c, sec, turn: climbTurnPoint(rec.poly, c, W, mass, need.workMin || 10), distKm: +distKm.toFixed(1), bearing: Math.round(bearingOf(home, c.foot)), times: rec.times })
    }
  }
  return out
}

/**
 * Izbor klancev za krog: 2–4 PODOBNI klanci (čas pri ciljni moči ±35 %, naklon ±2,5 %) v izseku do 150° okoli doma,
 * da je krog lep (ne tja in nazaj). Največ toliko klancev, kot je ponovitev. Vrne jih v vrstnem redu vožnje (po smeri).
 * Manj kot 2 → prazno (ostane en klanec s ponovitvami).
 */
export function pickClimbLoop(cands: readonly ClimbCand[], reps: number, maxClimbs = 4): ClimbCand[] {
  const k = Math.min(reps, maxClimbs, cands.length)
  if (k < 2) return []
  let best: { set: ClimbCand[]; score: number } | null = null
  for (const a of cands) {
    const sim = cands.filter(c => c !== a && Math.abs(c.sec - a.sec) / a.sec <= 0.35 && Math.abs(c.climb.grade - a.climb.grade) <= 2.5 && angDiff(c.bearing, a.bearing) <= 150)
    // najbližji po smeri, nato po razdalji od doma
    const pick = [a, ...sim.sort((x, y) => angDiff(x.bearing, a.bearing) - angDiff(y.bearing, a.bearing) || x.distKm - y.distKm).slice(0, k - 1)]
    if (pick.length < 2) continue
    // izsek vseh izbranih ≤ 150°
    const span = Math.max(...pick.flatMap(x => pick.map(y => angDiff(x.bearing, y.bearing))))
    if (span > 150) continue
    const far = Math.max(...pick.map(x => x.distKm))
    // več klancev je bolje; nato bližje domu, pogosteje prevoženi
    const score = pick.length * 10 - far * 0.3 + Math.min(3, pick.reduce((s, x) => s + Math.log2(1 + x.times), 0) * 0.3)
    if (!best || score > best.score) best = { set: pick, score }
  }
  if (!best) return []
  // vrstni red vožnje: po smeri okoli doma, začni pri tistem, ki je najbolj »na robu« izseka
  const set = [...best.set]
  const mid = circMean(set.map(x => x.bearing))
  return set.sort((x, y) => signed(x.bearing - mid) - signed(y.bearing - mid))
}
const signed = (d: number) => { let x = ((d % 360) + 360) % 360; if (x > 180) x -= 360; return x }
function circMean(bs: number[]): number {
  const s = bs.reduce((a, b) => a + Math.sin((b * Math.PI) / 180), 0), c = bs.reduce((a, b) => a + Math.cos((b * Math.PI) / 180), 0)
  return ((Math.atan2(s, c) * 180) / Math.PI + 360) % 360
}

/** Ponovitve po klancih: npr. 5 × na 3 klancih → 2, 2, 1 (prvi dobijo več). */
export function repsPerClimb(reps: number, n: number): number[] {
  return Array.from({ length: n }, (_, i) => Math.floor(reps / n) + (i < reps % n ? 1 : 0))
}

/** Interval na novi trasi: kje je klanec na trasi in koliko ponovitev. Zapiše se v RouteRec.intervals. */
export interface IntervalStop { atKm: number; km: number; grade: number; gainM: number; reps: number; sec: number }

/** Pozicija vznožij izbranih klancev na narisani trasi (km od starta), z dolžino, naklonom in ponovitvami. */
export function intervalStops(pts: readonly LatLon[], picked: readonly ClimbCand[], reps: number): IntervalStop[] {
  if (pts.length < 2) return []
  const cum: number[] = [0]
  for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1]! + haversineM(pts[i - 1]!, pts[i]!))
  const per = repsPerClimb(reps, picked.length)
  let from = 0
  return picked.map((c, j) => {
    // najbližja točka vznožju — po vrsti (naprej od prejšnjega klanca), da krog, ki gre mimo dvakrat, ne zamenja vrstnega reda
    let bi = from, bd = Infinity
    for (let i = from; i < pts.length; i++) { const d = haversineM(pts[i]!, c.climb.foot); if (d < bd) { bd = d; bi = i } }
    from = bi
    return { atKm: +(cum[bi]! / 1000).toFixed(1), km: c.climb.km, grade: c.climb.grade, gainM: c.climb.gainM, reps: per[j]!, sec: c.sec }
  })
}

/** Dodatni čas za ponovitve na istem klancu (gor v tempu, dol lahko), ko je ponovitev več kot klancev (min). */
export function repeatExtraMin(stops: readonly IntervalStop[], need: Pick<RouteNeed, 'workMin' | 'workW'>, p: Pick<Profile, 'ftp' | 'weightKg'>, k: number): number {
  const mass = (p.weightKg || 75) + 9, W = need.workW || p.ftp || 200, ftp = p.ftp || 200
  let s = 0
  for (const st of stops) {
    if (st.reps <= 1) continue
    const up = Math.min(st.sec, (need.workMin || 10) * 60)
    const down = (up * speedAt(W, st.grade / 100, mass)) / speedAt(ftp * 0.3, -st.grade / 100, mass)
    s += (st.reps - 1) * (up + down)
  }
  return (s / 60) * k
}

/** Točke poti za BRouter: vznožje → konec intervala za vsak klanec (dom na začetku in koncu doda makeLoop). */
export function viaOf(picked: readonly ClimbCand[]): LatLon[] { return picked.flatMap(c => [c.climb.foot, c.turn]) }

/** Za prikaz: »pri 5,2 km (2,1 km, 6 %) 2×« … */
export function stopsText(stops: readonly IntervalStop[]): string {
  const f1 = (x: number) => String(x).replace('.', ',')
  return stops.map((s, i) => `${i + 1}) pri ${f1(s.atKm)}. km (${f1(s.km)} km, ${f1(s.grade)}\u00a0%)${s.reps > 1 ? ` ${s.reps}×` : ''}`).join(' · ')
}

