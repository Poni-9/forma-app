/**
 * Garmin ura iz tvojih voženj (ime naprave iz intervals.icu) → ali ima prave zemljevide in kako na njej
 * hkrati teče trening (koraki) in proga (črta poti). Garmin prog ne sprejema samodejno (program za razvijalce
 * je ustavljen), zato proga gre na uro prek Garmin Connect, trening pa sam prek intervals.icu.
 * Čiste funkcije, brez omrežja.
 */
export interface WatchInfo {
  /** npr. »Garmin Forerunner 255«; null, če ga ne poznamo */
  name: string | null
  /** true = pravi zemljevid s cestami, false = samo črta poti, null = ne vemo */
  maps: boolean | null
  /** kolesarski števec (Edge), ne ura */
  edge: boolean
}

const EDGE = /\bedge\b/i
const EDGE_MAPS = /\bedge\s*(5[34]0|8[34]0|10[0-5]0|explore)/i
const WATCH_MAPS = /\b(forerunner|fr)\s*(94[05]|955|965|970)\b|f[eē]nix\s*(5\s*plus|6\s*(pro|sapphire|solar)|[78]|e\b)|\bepix\b|\benduro\b|\bmarq\b|\btactix\b|\bquatix\b|\bdescent\b|\bvenu\s*x1\b/i
const WATCH_NO_MAPS = /\b(forerunner|fr)\s*\d{2,3}\b|vivoactive|\bvenu\b|\binstinct\b|f[eē]nix\s*[56]\b/i

export function watchOf(acts: readonly { deviceName?: string | null; date: string }[]): WatchInfo {
  const last = [...acts].filter(a => (a.deviceName || '').trim() && /garmin|forerunner|fenix|fēnix|edge|epix|venu|vivoactive|instinct|enduro|marq/i.test(a.deviceName!))
    .sort((a, b) => b.date.localeCompare(a.date))[0]
  if (!last) return { name: null, maps: null, edge: false }
  const name = last.deviceName!.trim().replace(/^GARMIN\s+FR\s*/i, 'Garmin Forerunner ')
  if (EDGE.test(name)) return { name, maps: EDGE_MAPS.test(name), edge: true }
  if (WATCH_MAPS.test(name)) return { name, maps: true, edge: false }
  if (WATCH_NO_MAPS.test(name)) return { name, maps: false, edge: false }
  return { name, maps: null, edge: false }
}

/** Koraki od »Na uro« do vožnje s treningom in progo hkrati (meniji v angleščini, kot na uri). */
export function watchSteps(w: WatchInfo, course: string, workout: string, shared: boolean): string[] {
  const s: string[] = []
  s.push(shared
    ? 'V Garmin Connect potrdi uvoz proge (tip: kolesarjenje) in tapni »Send to Device« — ura jo dobi ob naslednji sinhronizaciji.'
    : 'Prenesi GPX → connect.garmin.com → Training & Planning → Courses → Import → shrani kot kolesarjenje → »Send to Device«.')
  if (w.edge) {
    s.push(`Na Edge: Navigation → Courses → »${course}« → Ride.`)
    s.push(`Nato: Training → Training Calendar (ali Workouts) → »${workout}« → Do Workout. Števec vodi oboje hkrati.`)
  } else {
    s.push('Na uri pritisni START → Bike, a še ne začni vožnje.')
    s.push(`Drži UP → Training → Training Calendar (ali Workouts) → »${workout}« → Do Workout.`)
    s.push(`Drži UP → Navigation → Courses → »${course}« → Do Course. Šele zdaj START.`)
  }
  s.push(w.maps === true ? 'Na zemljevidu vidiš ceste in svojo pot; ura zapiska, ko zaideš s poti.'
    : w.maps === false ? `${w.name ? w.name.replace(/^Garmin\s+/i, '') + ' nima' : 'Tvoja ura nima'} zemljevida s cestami: vidiš črto poti in puščico, kje si, ura pa zapiska, ko zaideš. Pri zavijanju pomaga, če si traso prej ogledaš na telefonu.`
    : 'Na zaslonu z zemljevidom vidiš črto poti; ura zapiska, ko zaideš s poti.')
  s.push('Prvič to poskusi doma, preden greš na cesto. Če ura ob nalaganju proge trening prekliče, najprej naloži progo, nato trening.')
  return s
}

/** Kratko ime proge za uro (seznam na uri prikaže ~20 znakov). */
export function courseName(date: string, title: string): string {
  const t = title.replace(/\s+/g, ' ').trim()
  return `FORMAI ${+date.slice(8)}.${+date.slice(5, 7)}. ${t.length > 18 ? t.slice(0, 18).trim() : t}`
}
