import type { Activity, PlanDay, Profile } from '../types'
import { climbSeconds, rideMinutes, speedAt, type Climb, type RouteRec } from './analyze'
import { haversineM, type LatLon } from '../import/polyline'
import { noPower, lthrZoneText } from '../training/zones'
import { stepsFor, type Step } from '../training/workout'

/**
 * Katera trasa za kateri trening. Deterministično (brez AI):
 *  - VO2max / prag / test → klanec, na katerem interval traja dovolj dolgo pri ciljnih vatih (ponovitve gor–dol),
 *  - Z2 / regeneracija → čim bolj ravno,
 *  - dolga → dolžina.
 * Čas trase je ocenjen s fiziko (moč, teža, naklon) in umerjen na tvoje dejanske čase voženj.
 */

export type Need = 'vo2' | 'prag' | 'test' | 'dolga' | 'z2' | 'regen'
export interface RouteNeed { need: Need; minutes: number; reps: number; workMin: number; workW: number | null; lo: number | null; hi: number | null; label: string; /** besedilo intenzivnosti za prikaz (vati ali utrip) */ wtxt?: string | null; /** koraki treninga (ogrevanje, intervali, iztek) — čas trase sledi njihovi intenzivnosti */ steps?: Step[] }

export function needOf(d: Pick<PlanDay, 'kind' | 'title' | 'durationMin' | 'zone' | 'role' | 'target'> & { desc?: string }, p: Pick<Profile, 'ftp'> & Partial<Pick<Profile, 'lthr' | 'maxHr' | 'restHr' | 'gear'>>): RouteNeed | null {
  if (d.kind !== 'kolo' && d.kind !== 'test') return null
  if (d.role === 'dirka') return null
  let steps: Step[] | undefined
  try { steps = stepsFor({ ...d, desc: d.desc || '' } as PlanDay, p as Profile) } catch { steps = undefined }
  const m = /(\d+)\s*×\s*(\d+)\s*min/.exec(d.title)
  const reps = m ? +m[1]! : 1, workMin = m ? +m[2]! : 0
  const ftp = p.ftp || 200
  const lo = d.target?.lo ?? null, hi = d.target?.hi ?? null
  const workW = lo && hi ? Math.round((lo + hi) / 2) : null
  const wt = noPower(p) ? (lthrZoneText(p, d.zone === 'Z5' ? 'Z5' : d.zone === 'Z3' ? 'Z3' : 'Z4') ?? null) : lo && hi ? `${lo}–${hi} W` : null
  const base = { minutes: d.durationMin || 60, reps, workMin, workW, lo, hi, wtxt: wt, steps }
  if (d.role === 'test' || d.kind === 'test') return { ...base, need: 'test', reps: 1, workMin: 20, workW: Math.round(ftp * 1.02), lo: Math.round(ftp * 0.98), hi: Math.round(ftp * 1.06), label: 'test FTP', wtxt: noPower(p) ? 'čim močneje, enakomerno' : `${Math.round(ftp * 0.98)}–${Math.round(ftp * 1.06)} W` }
  if (d.role === 'kljucna' && (/Z5/.test(d.zone || '') || /VO2/i.test(d.title))) return { ...base, need: 'vo2', label: 'VO2max ponovitve' }
  if (d.role === 'kljucna') return { ...base, need: 'prag', label: 'prag / sweet spot' }
  if (d.role === 'dolga') return { ...base, need: 'dolga', label: 'dolga vožnja' }
  if (d.role === 'regen') return { ...base, need: 'regen', label: 'regeneracija' }
  return { ...base, need: 'z2', label: 'Z2' }
}

export interface RouteSuggestion { rec: RouteRec; score: number; estMin: number; climb: Climb | null; climbSec: number | null; how: string; why: string }

const mmss = (s: number) => `${Math.floor(s / 60)}:${String(Math.round(s % 60)).padStart(2, '0')}`
const f1 = (x: number) => String(x).replace('.', ',')
const dshort = (iso: string) => `${+iso.slice(8)}. ${+iso.slice(5, 7)}.`
const daysBetween = (a: string, b: string) => Math.round((new Date(b).getTime() - new Date(a).getTime()) / 86400_000)

/** Umeritev: koliko dlje (ali krajše) si dejansko vozil od fizikalne ocene v Z2 (0,85–1,4). */
export function paceFactor(recs: readonly RouteRec[], p: Pick<Profile, 'ftp' | 'weightKg'>): number {
  const mass = (p.weightKg || 75) + 9, P = (p.ftp || 200) * 0.65
  const r = recs.filter(x => x.source === 'voznja' && x.rodeMin && x.km >= 10).map(x => x.rodeMin! / Math.max(1, rideMinutes(x.prof, P, mass))).sort((a, b) => a - b)
  if (r.length < 3) return 1.1
  const med = r[Math.floor(r.length / 2)]!
  return Math.max(0.85, Math.min(1.4, +med.toFixed(2)))
}

/** Ocena časa trase pri enakomerni moči (Z2 oz. regeneracija), umerjena. */
export function estMinutes(rec: Pick<RouteRec, 'prof'>, need: RouteNeed, p: Pick<Profile, 'ftp' | 'weightKg'>, k: number): number {
  const mass = (p.weightKg || 75) + 9, ftp = p.ftp || 200
  return Math.round(rideMinutes(rec.prof, ftp * (need.need === 'regen' ? 0.5 : 0.65), mass) * k)
}

/** Moč koraka kot delež FTP (brez merilnika so to ekvivalentne stopnje napora). */
function stepPower(s: Step, need: RouteNeed, ftp: number): number {
  if (s.kind === 'delo' && s.sets && s.sets > 1 && need.workW) return need.workW
  const f: Record<string, number> = { Z1: 0.5, Z2: 0.65, Z3: 0.83, Z4: 0.95, Z5: 1.1, max: 1.0 }
  return ftp * (f[s.z || (s.kind === 'delo' ? 'Z2' : 'Z1')] || 0.65)
}

/**
 * Ocena časa trase, ki SLEDI TRENINGU: ogrevanje lahko, intervali hitro, odmori in iztek počasi — po profilu trase.
 * Ko koraki zmanjkajo (trasa daljša od treninga), naprej v Z2. Umerjeno s k.
 */
export function workoutMinutes(prof: readonly number[], need: RouteNeed, p: Pick<Profile, 'ftp' | 'weightKg'>, k: number, step = 50): number {
  const steps = need.steps?.filter(s => s.sec > 0) || []
  if (!steps.length) return estMinutes({ prof: prof as number[] }, need, p, k)
  const mass = (p.weightKg || 75) + 9, ftp = p.ftp || 200
  let ti = 0, left = steps[0]!.sec / k, sec = 0   // k raztegne tudi korake (postanki, križišča)
  for (let i = 1; i < prof.length; i++) {
    const grade = (prof[i]! - prof[i - 1]!) / step
    const P = ti < steps.length ? stepPower(steps[ti]!, need, ftp) : ftp * 0.65
    const dt = step / speedAt(grade < -0.02 ? P * 0.3 : P, grade, mass)
    sec += dt
    if (ti < steps.length) { left -= dt; while (left <= 0 && ti < steps.length) { ti++; if (ti < steps.length) left += steps[ti]!.sec / k } }
  }
  return Math.round((sec * k) / 60)
}

/**
 * Učenje dolžine: kako dolgo so tvoje vožnje na dneve treninga DEJANSKO trajale glede na oceno po korakih
 * na isti sledi (čas od odhoda do prihoda, z rdečimi lučmi; mediana zadnjih do 8, zadnjih 60 dni).
 * Primer: trening 90 min, trasa ocenjena na 89 min, vozil 1 h 53 → naslednja trasa je krajša.
 */
export function paceAdj(raw: readonly RouteRec[], acts: readonly Activity[], plan: readonly PlanDay[], p: Pick<Profile, 'ftp' | 'weightKg'> & Partial<Profile>, k: number, today: string): { adj: number; n: number; last: { date: string; ratio: number } | null } {
  const rec = new Map(raw.filter(r => r.source === 'voznja').map(r => [r.id, r] as const))
  const act = new Map(acts.map(a => [a.id, a] as const))
  const rs: { date: string; ratio: number }[] = []
  for (const d of plan) {
    if (!d.done?.activityId || (d.kind !== 'kolo' && d.kind !== 'test') || d.date > today || daysBetween(d.date, today) > 60) continue
    const a = act.get(d.done.activityId), r = a ? rec.get(a.id) : undefined
    if (!a || !r || !a.durationMin) continue
    const actual = a.elapsedMin ? Math.min(a.elapsedMin, a.durationMin * 1.15) : a.durationMin
    const need = needOf(d, p as Profile)
    if (!need || actual < 20) continue
    const est = workoutMinutes(r.prof, need, p, k)
    if (est >= 15) rs.push({ date: d.date, ratio: actual / est })
  }
  if (!rs.length) return { adj: 1, n: 0, last: null }
  rs.sort((x, y) => y.date.localeCompare(x.date))
  const xs = rs.slice(0, 8).map(x => x.ratio).sort((a, b) => a - b)
  const med = xs.length % 2 ? xs[(xs.length - 1) / 2]! : (xs[xs.length / 2 - 1]! + xs[xs.length / 2]!) / 2
  const adj = xs.length === 1 ? (1 + med) / 2 : med                                  // ena vožnja → pol poti
  return { adj: +Math.max(0.85, Math.min(1.35, adj)).toFixed(3), n: xs.length, last: { date: rs[0]!.date, ratio: +rs[0]!.ratio.toFixed(2) } }
}

/** Ocena za prikaz in izbiro: na klancu (ponovitve gor–dol) enakomerna ocena + ponovitve, sicer po korakih treninga. */
export function routeMinutes(rec: Pick<RouteRec, 'prof'>, need: RouteNeed, p: Pick<Profile, 'ftp' | 'weightKg'>, k: number, climbExtraMin = 0, onClimb = false): number {
  return onClimb ? estMinutes(rec, need, p, k) + climbExtraMin : workoutMinutes(rec.prof, need, p, k)
}

/** Predlogi trase za dan (najboljša prva). */
export function suggestRoutes(recs: readonly RouteRec[], need: RouteNeed, p: Pick<Profile, 'ftp' | 'weightKg'>, today: string, k = paceFactor(recs, p), home: LatLon | null = null): RouteSuggestion[] {
  const mass = (p.weightKg || 75) + 9, ftp = p.ftp || 200
  const hard = need.need === 'vo2' || need.need === 'prag' || need.need === 'test'
  const out: RouteSuggestion[] = []
  for (const rec of recs) {
    let climb: Climb | null = null, climbSec: number | null = null, extra = 0
    if (hard) {
      const W = need.workW || ftp
      const needSec = need.workMin * 60 * (need.need === 'vo2' ? 0.9 : 0.7)
      const maxG = need.need === 'vo2' ? 14 : 11   // VO2max ponovitve gredo tudi na strm klanec, prag in test ne
      const c = rec.climbs.filter(x => x.grade >= 3.5 && x.grade <= maxG).map(x => ({ x, t: climbSeconds(x, W, mass) })).filter(x => x.t >= needSec).sort((a, b) => a.t - b.t)[0]
      if (c) {
        climb = c.x; climbSec = c.t
        // ponovitve na istem klancu: gor v tempu, dol lahko — vsaka dodatna ponovitev podaljša vožnjo
        const up = Math.min(c.t, need.workMin * 60), down = (up * speedAt(W, c.x.grade / 100, mass)) / speedAt(ftp * 0.3, -c.x.grade / 100, mass)
        extra = need.need === 'test' ? 0 : ((need.reps - 1) * (up + down)) / 60 * k
      }
    }
    const total = routeMinutes(rec, need, p, k, extra / 1, !!climb)
    let score = (Math.abs(total - need.minutes) / need.minutes) * 2
    if (hard && !climb) score += 0.6
    if (need.need === 'z2') score += rec.hilly / 40 + Math.max(0, rec.hilly - 8) / 8        // Z2: čim bolj enakomerno
    if (need.need === 'regen') score += rec.hilly / 20 + Math.max(0, rec.hilly - 5) / 4
    if (need.need === 'dolga' && rec.km < 40) score += 0.3
    if (rec.source === 'voznja') {
      // tvoje pogoste poti imajo prednost (prevožene 2× → −0,1, 4× → −0,2, 8× in več → −0,3) …
      score -= Math.min(0.3, 0.1 * Math.log2(Math.max(1, rec.times)))
      // … a menjavaj: ne iste kot včeraj ali predvčerajšnjim
      const ago = rec.date ? daysBetween(rec.date, today) : 99
      if (ago <= 1) score += 0.35
      else if (ago <= 3) score += 0.2
    } else {
      score += 0.3                                             // nova trasa: ko tvoje ne ustrezajo
      if (rec.quality) score += Math.min(0.4, rec.quality.signals * 0.02 + rec.quality.unpavedKm * 0.2)
    }
    // start daleč od doma = vožnja z avtom: med tednom skoraj nikoli, za dolgo vožnjo lahko
    const away = home ? haversineM(home, rec.start) / 1000 : 0
    if (away > 3) score += need.need === 'dolga' ? 0.5 : 1.2
    const why = whyText(need, rec, climb) + (away > 3 ? ` · start ${Math.round(away)} km od doma` : '')
    out.push({ rec, score: +score.toFixed(3), estMin: Math.round(total), climb, climbSec, how: howText(need, climb, climbSec, rec), why })
  }
  return out.sort((a, b) => a.score - b.score)
}

function howText(need: RouteNeed, c: Climb | null, t: number | null, rec: RouteRec): string {
  const W = need.wtxt || (need.lo && need.hi ? `${need.lo}–${need.hi} W` : '')
  const hr = /^(utrip|RPE|čim)/.test(W)
  const pri = W ? (hr ? ` (${W})` : ` pri ${W}`) : ''
  if ((need.need === 'vo2' || need.need === 'prag') && c && t) {
    const at = `klancu pri ${f1(c.atKm)}. km (${f1(c.km)} km, ${f1(c.grade)} %, +${c.gainM} m — v tem tempu ~${mmss(t)})`
    return need.need === 'vo2'
      ? `Intervale delaj na ${at}: ${need.reps}× gor ${need.workMin} min${pri}${t > need.workMin * 60 + 30 ? ', ko se čas izteče, obrni' : ''}; spust v lahkem = odmor.`
      : `${need.reps} × ${need.workMin} min na ${at}${t < need.workMin * 60 ? ' — zadnje minute nadaljuj po vrhu v istem tempu' : ''}; spust lahko.`
  }
  if (need.need === 'test' && c && t) return `20-minutni test na klancu pri ${f1(c.atKm)}. km (${f1(c.km)} km, ${f1(c.grade)} %, ~${mmss(t)} pri FTP)${t < 1200 ? ' — nadaljuj po vrhu, dokler ne mine 20 min' : ''}. Enakomerno, zadnjih 5 min stisni.`
  if (need.need === 'vo2' || need.need === 'prag' || need.need === 'test') return `Na tej trasi ni dovolj dolgega klanca — intervale naredi na najdaljšem ravnem odseku brez križišč in semaforjev.`
  if (need.need === 'dolga') return `Enakomerno v Z2${rec.climbs.length ? `, na klancih (${rec.climbs.length}) ne čez prag` : ''}. Jej po načrtu goriva.`
  if (need.need === 'regen') return 'Zelo lahko, samo vrtenje — na klancih v najlažjo prestavo.'
  return `Enakomerno v Z2${rec.hilly > 8 ? ' — na klancih ostani v Z2, raje počasneje' : ''}.`
}

function whyText(need: RouteNeed, rec: RouteRec, c: Climb | null): string {
  const parts: string[] = []
  if (c) parts.push(need.need === 'vo2' ? 'klanec za ponovitve' : need.need === 'test' ? 'enakomeren klanec za test' : 'dolg klanec za prag')
  else if (need.need === 'z2' || need.need === 'regen') parts.push(rec.hilly <= 6 ? 'ravna' : rec.hilly <= 10 ? 'rahlo razgibana' : 'hribovita')
  if (rec.source === 'voznja') parts.push(rec.times > 1 ? `prevoženo ${rec.times}×${rec.date ? `, zadnjič ${dshort(rec.date)}` : ''}` : rec.date ? `prevoženo ${dshort(rec.date)}` : 'tvoja vožnja')
  else parts.push('nova trasa')
  return parts.join(' · ')
}
