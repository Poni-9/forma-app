import type { PlanDay, Profile } from '../types'
import { climbSeconds, rideMinutes, speedAt, type Climb, type RouteRec } from './analyze'
import { haversineM, type LatLon } from '../import/polyline'

/**
 * Katera trasa za kateri trening. Deterministično (brez AI):
 *  - VO2max / prag / test → klanec, na katerem interval traja dovolj dolgo pri ciljnih vatih (ponovitve gor–dol),
 *  - Z2 / regeneracija → čim bolj ravno,
 *  - dolga → dolžina.
 * Čas trase je ocenjen s fiziko (moč, teža, naklon) in umerjen na tvoje dejanske čase voženj.
 */

export type Need = 'vo2' | 'prag' | 'test' | 'dolga' | 'z2' | 'regen'
export interface RouteNeed { need: Need; minutes: number; reps: number; workMin: number; workW: number | null; lo: number | null; hi: number | null; label: string }

export function needOf(d: Pick<PlanDay, 'kind' | 'title' | 'durationMin' | 'zone' | 'role' | 'target'>, p: Pick<Profile, 'ftp'>): RouteNeed | null {
  if (d.kind !== 'kolo' && d.kind !== 'test') return null
  if (d.role === 'dirka') return null
  const m = /(\d+)\s*×\s*(\d+)\s*min/.exec(d.title)
  const reps = m ? +m[1]! : 1, workMin = m ? +m[2]! : 0
  const ftp = p.ftp || 200
  const lo = d.target?.lo ?? null, hi = d.target?.hi ?? null
  const workW = lo && hi ? Math.round((lo + hi) / 2) : null
  const base = { minutes: d.durationMin || 60, reps, workMin, workW, lo, hi }
  if (d.role === 'test' || d.kind === 'test') return { ...base, need: 'test', reps: 1, workMin: 20, workW: Math.round(ftp * 1.02), lo: Math.round(ftp * 0.98), hi: Math.round(ftp * 1.06), label: 'test FTP' }
  if (d.role === 'kljucna' && (/Z5/.test(d.zone || '') || /VO2/i.test(d.title))) return { ...base, need: 'vo2', label: 'VO2max ponovitve' }
  if (d.role === 'kljucna') return { ...base, need: 'prag', label: 'prag / sweet spot' }
  if (d.role === 'dolga') return { ...base, need: 'dolga', label: 'dolga vožnja' }
  if (d.role === 'regen') return { ...base, need: 'regen', label: 'regeneracija' }
  return { ...base, need: 'z2', label: 'Z2' }
}

export interface RouteSuggestion { rec: RouteRec; score: number; estMin: number; climb: Climb | null; climbSec: number | null; how: string; why: string }

const mmss = (s: number) => `${Math.floor(s / 60)}:${String(Math.round(s % 60)).padStart(2, '0')}`
const f1 = (x: number) => String(x).replace('.', ',')
const dshort = (iso: string) => `${+iso.slice(8)}. ${+iso.slice(5, 7)}.`
const daysBetween = (a: string, b: string) => Math.round((new Date(b).getTime() - new Date(a).getTime()) / 86400_000)

/** Umeritev: koliko dlje (ali krajše) si dejansko vozil od fizikalne ocene v Z2 (0,85–1,4). */
export function paceFactor(recs: readonly RouteRec[], p: Pick<Profile, 'ftp' | 'weightKg'>): number {
  const mass = (p.weightKg || 75) + 9, P = (p.ftp || 200) * 0.65
  const r = recs.filter(x => x.source === 'voznja' && x.rodeMin && x.km >= 10).map(x => x.rodeMin! / Math.max(1, rideMinutes(x.prof, P, mass))).sort((a, b) => a - b)
  if (r.length < 3) return 1.1
  const med = r[Math.floor(r.length / 2)]!
  return Math.max(0.85, Math.min(1.4, +med.toFixed(2)))
}

/** Ocena časa trase za ta trening (min), umerjena. */
export function estMinutes(rec: Pick<RouteRec, 'prof'>, need: RouteNeed, p: Pick<Profile, 'ftp' | 'weightKg'>, k: number): number {
  const mass = (p.weightKg || 75) + 9, ftp = p.ftp || 200
  return Math.round(rideMinutes(rec.prof, ftp * (need.need === 'regen' ? 0.5 : 0.65), mass) * k)
}

/** Predlogi trase za dan (najboljša prva). */
export function suggestRoutes(recs: readonly RouteRec[], need: RouteNeed, p: Pick<Profile, 'ftp' | 'weightKg'>, today: string, k = paceFactor(recs, p), home: LatLon | null = null): RouteSuggestion[] {
  const mass = (p.weightKg || 75) + 9, ftp = p.ftp || 200
  const hard = need.need === 'vo2' || need.need === 'prag' || need.need === 'test'
  const out: RouteSuggestion[] = []
  for (const rec of recs) {
    const estMin = estMinutes(rec, need, p, k)
    let climb: Climb | null = null, climbSec: number | null = null, extra = 0
    if (hard) {
      const W = need.workW || ftp
      const needSec = need.workMin * 60 * (need.need === 'vo2' ? 0.9 : 0.7)
      const c = rec.climbs.filter(x => x.grade >= 3.5 && x.grade <= 11).map(x => ({ x, t: climbSeconds(x, W, mass) })).filter(x => x.t >= needSec).sort((a, b) => a.t - b.t)[0]
      if (c) {
        climb = c.x; climbSec = c.t
        // ponovitve na istem klancu: gor v tempu, dol lahko — vsaka dodatna ponovitev podaljša vožnjo
        const up = Math.min(c.t, need.workMin * 60), down = (up * speedAt(W, c.x.grade / 100, mass)) / speedAt(ftp * 0.3, -c.x.grade / 100, mass)
        extra = need.need === 'test' ? 0 : ((need.reps - 1) * (up + down)) / 60 * k
      }
    }
    const total = estMin + extra
    let score = (Math.abs(total - need.minutes) / need.minutes) * 2
    if (hard && !climb) score += 0.6
    if (need.need === 'z2') score += rec.hilly / 40 + Math.max(0, rec.hilly - 8) / 8        // Z2: čim bolj enakomerno
    if (need.need === 'regen') score += rec.hilly / 20 + Math.max(0, rec.hilly - 5) / 4
    if (need.need === 'dolga' && rec.km < 40) score += 0.3
    if (rec.date && rec.source === 'voznja' && daysBetween(rec.date, today) <= 2) score += 0.25
    if (rec.times > 1) score -= 0.05
    // start daleč od doma = vožnja z avtom: med tednom skoraj nikoli, za dolgo vožnjo lahko
    const away = home ? haversineM(home, rec.start) / 1000 : 0
    if (away > 3) score += need.need === 'dolga' ? 0.5 : 1.2
    const why = whyText(need, rec, climb) + (away > 3 ? ` · start ${Math.round(away)} km od doma` : '')
    out.push({ rec, score: +score.toFixed(3), estMin: Math.round(total), climb, climbSec, how: howText(need, climb, climbSec, rec), why })
  }
  return out.sort((a, b) => a.score - b.score)
}

function howText(need: RouteNeed, c: Climb | null, t: number | null, rec: RouteRec): string {
  const W = need.lo && need.hi ? `${need.lo}–${need.hi} W` : ''
  if ((need.need === 'vo2' || need.need === 'prag') && c && t) {
    const at = `klancu pri ${f1(c.atKm)}. km (${f1(c.km)} km, ${f1(c.grade)} %, +${c.gainM} m — pri ${W || 'ciljnih vatih'} ~${mmss(t)})`
    return need.need === 'vo2'
      ? `Intervale delaj na ${at}: ${need.reps}× gor ${need.workMin} min${W ? ` pri ${W}` : ''}${t > need.workMin * 60 + 30 ? ', ko se čas izteče, obrni' : ''}; spust v lahkem = odmor.`
      : `${need.reps} × ${need.workMin} min na ${at}${t < need.workMin * 60 ? ' — zadnje minute nadaljuj po vrhu v istem tempu' : ''}; spust lahko.`
  }
  if (need.need === 'test' && c && t) return `20-minutni test na klancu pri ${f1(c.atKm)}. km (${f1(c.km)} km, ${f1(c.grade)} %, ~${mmss(t)} pri FTP)${t < 1200 ? ' — nadaljuj po vrhu, dokler ne mine 20 min' : ''}. Enakomerno, zadnjih 5 min stisni.`
  if (need.need === 'vo2' || need.need === 'prag' || need.need === 'test') return `Na tej trasi ni dovolj dolgega klanca — intervale naredi na najdaljšem ravnem odseku brez križišč in semaforjev.`
  if (need.need === 'dolga') return `Enakomerno v Z2${rec.climbs.length ? `, na klancih (${rec.climbs.length}) ne čez prag` : ''}. Jej po načrtu goriva.`
  if (need.need === 'regen') return 'Zelo lahko, samo vrtenje — na klancih v najlažjo prestavo.'
  return `Enakomerno v Z2${rec.hilly > 8 ? ' — na klancih ostani v Z2, raje počasneje' : ''}.`
}

function whyText(need: RouteNeed, rec: RouteRec, c: Climb | null): string {
  const parts: string[] = []
  if (c) parts.push(need.need === 'vo2' ? 'klanec za ponovitve' : need.need === 'test' ? 'enakomeren klanec za test' : 'dolg klanec za prag')
  else if (need.need === 'z2' || need.need === 'regen') parts.push(rec.hilly <= 6 ? 'ravna' : rec.hilly <= 10 ? 'rahlo razgibana' : 'hribovita')
  if (rec.source === 'voznja') parts.push(rec.times > 1 ? `prevoženo ${rec.times}×${rec.date ? `, zadnjič ${dshort(rec.date)}` : ''}` : rec.date ? `prevoženo ${dshort(rec.date)}` : 'tvoja vožnja')
  else parts.push('nova trasa')
  return parts.join(' · ')
}
