import { cleanTrack, analyzeTrack, cumDist, gainOf, profileOf, type RouteRec, type RouteQuality } from './analyze'
import type { LatLon } from '../import/polyline'
import { ROAD_PROFILE } from './roadProfile'

/**
 * Nove trase prek BRouterja (brouter.de — odprtokoden usmerjevalnik na OpenStreetMap, brez ključa, CORS dovoljen).
 * Pošljejo se samo točke poti (start = tvoj običajni začetek voženj in 2 obrača) in naš profil, nič drugega.
 * Profil »cestno kolo za trening« (roadProfile.ts): brez makadama, semaforji dragi, mimo naselij. Če ga strežnik
 * ne sprejme, rezerva »fastbike-lowtraffic«.
 */
export const BROUTER = 'https://brouter.de/brouter'
export const BROUTER_PROFILE = 'fastbike-lowtraffic'

export type { RouteQuality }
export interface Routed { pts: LatLon[]; alt: number[]; km: number; q?: RouteQuality }

const UNPAVED = /^(gravel|unpaved|compacted|fine_gravel|dirt|earth|ground|grass|sand|mud|pebblestone|woodchips|rock)$/
const PAVED = /^(asphalt|paved|concrete|concrete:plates|paving_stones|sett|chipseal)$/
/** Semaforji, makadam, naselja, kolesarske steze in glavne ceste po odsekih poti. */
export function qualityOf(messages: unknown): RouteQuality | undefined {
  if (!Array.isArray(messages) || messages.length < 2 || !Array.isArray(messages[0])) return undefined
  const head = messages[0] as string[]
  const iD = head.indexOf('Distance'), iW = head.indexOf('WayTags'), iN = head.indexOf('NodeTags')
  if (iD < 0 || iW < 0) return undefined
  const q: RouteQuality = { signals: 0, unpavedKm: 0, urbanKm: 0, cyclewayKm: 0, bigRoadKm: 0 }
  for (const row of messages.slice(1) as string[][]) {
    const km = (+row[iD]! || 0) / 1000, wt = String(row[iW] || ''), nt = iN >= 0 ? String(row[iN] || '') : ''
    const hw = /(?:^|\s)highway=(\S+)/.exec(wt)?.[1] || '', sf = /(?:^|\s)surface=(\S+)/.exec(wt)?.[1] || ''
    if (/traffic_signals/.test(nt)) q.signals++
    if (UNPAVED.test(sf) || (/^(track|path|footway|bridleway)$/.test(hw) && !PAVED.test(sf))) q.unpavedKm += km
    if (/^(residential|living_street|service|pedestrian)$/.test(hw)) q.urbanKm += km
    if (hw === 'cycleway') q.cyclewayKm += km
    if (/^(primary|primary_link|trunk|trunk_link)$/.test(hw)) q.bigRoadKm += km
  }
  for (const k of ['unpavedKm', 'urbanKm', 'cyclewayKm', 'bigRoadKm'] as const) q[k] = +q[k].toFixed(1)
  return q
}

export async function brouterRoute(via: readonly LatLon[], profile = BROUTER_PROFILE): Promise<Routed> {
  const lonlats = via.map(p => `${p[1].toFixed(5)},${p[0].toFixed(5)}`).join('|')
  const r = await fetch(`${BROUTER}?lonlats=${lonlats}&profile=${profile}&alternativeidx=0&format=geojson`)
  if (!r.ok) throw new Error(`Usmerjevalnik ni našel poti (HTTP ${r.status}).`)
  const js = await r.json() as { features?: { properties?: Record<string, unknown>; geometry?: { coordinates?: number[][] } }[] }
  const f = js.features?.[0]
  const coords = f?.geometry?.coordinates || []
  if (coords.length < 2) throw new Error('Usmerjevalnik ni vrnil poti.')
  const t = cleanTrack(coords.map(c => c[1] ?? null), coords.map(c => c[0] ?? null), coords.map(c => (c[2] ?? null) as number | null))
  return { pts: t.pts, alt: t.alt, km: +(+(f?.properties?.['track-length'] as string || 0) / 1000).toFixed(1), q: qualityOf(f?.properties?.['messages']) }
}

/* ---------- naš profil: naloži se na strežnik enkrat na ~3 h (BRouter vrne začasen id) ---------- */
let roadId: { id: string; at: number } | null = null
async function roadProfileId(force = false): Promise<string | null> {
  if (!force && roadId && Date.now() - roadId.at < 3 * 3600_000) return roadId.id
  try {
    const r = await fetch(`${BROUTER}/profile`, { method: 'POST', body: ROAD_PROFILE, headers: { 'Content-Type': 'text/plain' } })
    const j = await r.json() as { profileid?: string }
    if (j.profileid && /^custom_\w+$/.test(j.profileid)) { roadId = { id: j.profileid, at: Date.now() }; return j.profileid }
  } catch { /* strežnik profila ne sprejme — rezerva spodaj */ }
  roadId = null
  return null
}
/** Pot za cestno kolo: naš profil, ob napaki še enkrat z novim id-jem, nazadnje fastbike-lowtraffic. */
export async function roadRoute(via: readonly LatLon[]): Promise<Routed> {
  const id = await roadProfileId()
  if (id) {
    try { return await brouterRoute(via, id) } catch {
      const id2 = await roadProfileId(true)
      if (id2) { try { return await brouterRoute(via, id2) } catch { /* rezerva */ } }
    }
  }
  return brouterRoute(via, BROUTER_PROFILE)
}

/**
 * Kazen za kakovost (manj je bolje), normirano na 40 km: semaforji, makadam, naselja, glavne ceste;
 * wantFlat: vzpon; known: delež poti po cestah, ki jih že voziš (0–1) — »kot folk vozi«, ne naključno.
 */
export function routePenalty(x: Pick<Routed, 'q' | 'km'>, hilly: number, wantFlat: boolean, known: number | null): number {
  const n = 40 / Math.max(10, x.km || 40), q = x.q
  const base = q ? (q.signals * 0.08 + q.unpavedKm * 0.5 + q.urbanKm * 0.06 + q.cyclewayKm * 0.03 + q.bigRoadKm * 0.02) * n : 0
  return +(base + (wantFlat ? hilly / 8 : 0) - (known ?? 0) * 0.8).toFixed(3)
}

/** Točka na razdalji km v smeri bearing (stopinje, 0 = sever). */
export function dest(p: LatLon, km: number, bearing: number): LatLon {
  const R = 6371, d = km / R, b = (bearing * Math.PI) / 180, la = (p[0] * Math.PI) / 180, lo = (p[1] * Math.PI) / 180
  const la2 = Math.asin(Math.sin(la) * Math.cos(d) + Math.cos(la) * Math.sin(d) * Math.cos(b))
  const lo2 = lo + Math.atan2(Math.sin(b) * Math.sin(d) * Math.cos(la), Math.cos(d) - Math.sin(la) * Math.sin(la2))
  return [+(la2 * 180 / Math.PI).toFixed(5), +(lo2 * 180 / Math.PI).toFixed(5)]
}

/**
 * Krog od doma dolg približno za targetMin (čas oceni estimate). Trikotnik: dom → 2 obrača → dom.
 * Preizkusi 4 smeri in vzame najboljšo za trening: brez makadama, čim manj semaforjev in naselij, po cestah,
 * ki jih že voziš (known), za Z2 čim bolj ravno. Nato do dvakrat popravi dolžino. Največ 6 klicev.
 */
export async function makeLoop(home: LatLon, targetMin: number, estimate: (prof: number[]) => number, opt: { seed: number; wantFlat: boolean; via?: LatLon[]; known?: (pts: readonly LatLon[]) => number }): Promise<{ routed: Routed; via: LatLon[] }> {
  if (opt.via?.length) {
    const via = [home, ...opt.via, home]
    return { routed: await roadRoute(via), via }
  }
  const prof = (x: Routed) => profileOf(cumDist(x.pts), x.alt)
  const pen = (x: Routed) => routePenalty(x, gainOf(prof(x)) / Math.max(1, x.km), opt.wantFlat, opt.known ? opt.known(x.pts) : null)
  const theta0 = (opt.seed * 137.5) % 360
  let r = Math.max(4, (targetMin / 60) * 26 / 3.9)
  const tri = (th: number, rad: number): LatLon[] => [home, dest(home, rad, th - 35), dest(home, rad, th + 35), home]
  const tries: { routed: Routed; via: LatLon[]; th: number; p: number }[] = []
  for (const add of [0, 90, 180, 270]) {
    const th = (theta0 + add) % 360, via = tri(th, r)
    try { const routed = await roadRoute(via); tries.push({ routed, via, th, p: pen(routed) }) } catch { /* ta smer ne gre */ }
  }
  tries.sort((a, b) => a.p - b.p)
  const first = tries[0]
  if (!first) throw new Error('Za to smer ni poti — poskusi znova.')
  let best: { routed: Routed; via: LatLon[] } = first
  // dolžina: do dvakrat popravi polmer v izbrani smeri, da se čas ujema (±7 %) — da prideš domov, ko se trening konča
  for (let i = 0; i < 2; i++) {
    const est = estimate(prof(best.routed))
    const ratio = targetMin / Math.max(1, est)
    if (Math.abs(1 - ratio) < 0.07) break
    r = r * ratio
    const via = tri(first.th, r)
    try { best = { routed: await roadRoute(via), via } } catch { break }
  }
  return best
}

/** Nova trasa kot zapis za knjižnico. */
export function routedToRec(routed: Routed, via: LatLon[], name: string, date: string): RouteRec | null {
  const rec = analyzeTrack({ id: `nova:${date}:${Date.now().toString(36)}`, source: 'nova', name, date, rodeMin: null, via }, routed.pts, routed.alt)
  if (rec && routed.q) rec.quality = routed.q
  return rec
}

/** Ceste, ki jih že voziš: mreža celic ~150 m iz tvojih voženj → delež nove poti po njih (0–1). */
export function knownRoads(tracks: readonly (readonly LatLon[])[]): (pts: readonly LatLon[]) => number {
  const cell = (p: LatLon) => `${Math.round(p[0] / 0.0014)}:${Math.round(p[1] / 0.002)}`
  const set = new Set<string>()
  for (const t of tracks) for (const p of t) set.add(cell(p))
  return pts => {
    if (!set.size || pts.length < 2) return 0
    let on = 0, n = 0
    for (let i = 0; i < pts.length; i += 2) {
      const p = pts[i]!, a = Math.round(p[0] / 0.0014), b = Math.round(p[1] / 0.002)
      n++
      outer: for (let da = -1; da <= 1; da++) for (let db = -1; db <= 1; db++) if (set.has(`${a + da}:${b + db}`)) { on++; break outer }
    }
    return n ? +(on / n).toFixed(2) : 0
  }
}

/** GPX 1.1 (trasa za Garmin Connect, Stravo, Komoot). */
export function toGpx(name: string, pts: readonly LatLon[], alt?: readonly number[]): string {
  const esc = (s: string) => s.replace(/[<>&"']/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' }[c]!))
  const trk = pts.map((p, i) => `<trkpt lat="${p[0].toFixed(6)}" lon="${p[1].toFixed(6)}">${alt && Number.isFinite(alt[i]) ? `<ele>${Math.round(alt[i]!)}</ele>` : ''}</trkpt>`).join('')
  return `<?xml version="1.0" encoding="UTF-8"?>\n<gpx version="1.1" creator="FORMAI" xmlns="http://www.topografix.com/GPX/1/1"><metadata><name>${esc(name)}</name></metadata><trk><name>${esc(name)}</name><type>cycling</type><trkseg>${trk}</trkseg></trk></gpx>\n`
}

/** Povezava na brouter-web (zemljevid OSM, uredi, izvozi). */
export function brouterWebUrl(via: readonly LatLon[]): string {
  const c = via[0]!
  return `https://brouter.de/brouter-web/#map=12/${c[0].toFixed(4)}/${c[1].toFixed(4)}/standard&lonlats=${via.map(p => `${p[1].toFixed(5)},${p[0].toFixed(5)}`).join(';')}&profile=${BROUTER_PROFILE}`
}
