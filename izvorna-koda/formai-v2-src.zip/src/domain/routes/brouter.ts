import { cleanTrack, analyzeTrack, cumDist, gainOf, profileOf, type RouteRec } from './analyze'
import type { LatLon } from '../import/polyline'

/**
 * Nove trase prek BRouterja (brouter.de — odprtokoden usmerjevalnik na OpenStreetMap, brez ključa, CORS dovoljen).
 * Pošljejo se samo točke poti (start = tvoj običajni začetek voženj in 2 obrača), nič drugega.
 * Profil »fastbike-lowtraffic«: cestno kolo, asfalt, manj prometa.
 */
export const BROUTER = 'https://brouter.de/brouter'
export const BROUTER_PROFILE = 'fastbike-lowtraffic'

export interface Routed { pts: LatLon[]; alt: number[]; km: number }

export async function brouterRoute(via: readonly LatLon[], profile = BROUTER_PROFILE): Promise<Routed> {
  const lonlats = via.map(p => `${p[1].toFixed(5)},${p[0].toFixed(5)}`).join('|')
  const r = await fetch(`${BROUTER}?lonlats=${lonlats}&profile=${profile}&alternativeidx=0&format=geojson`)
  if (!r.ok) throw new Error(`Usmerjevalnik ni našel poti (HTTP ${r.status}).`)
  const js = await r.json() as { features?: { properties?: Record<string, string>; geometry?: { coordinates?: number[][] } }[] }
  const f = js.features?.[0]
  const coords = f?.geometry?.coordinates || []
  if (coords.length < 2) throw new Error('Usmerjevalnik ni vrnil poti.')
  const t = cleanTrack(coords.map(c => c[1] ?? null), coords.map(c => c[0] ?? null), coords.map(c => (c[2] ?? null) as number | null))
  return { pts: t.pts, alt: t.alt, km: +(+(f?.properties?.['track-length'] || 0) / 1000).toFixed(1) }
}

/** Točka na razdalji km v smeri bearing (stopinje, 0 = sever). */
export function dest(p: LatLon, km: number, bearing: number): LatLon {
  const R = 6371, d = km / R, b = (bearing * Math.PI) / 180, la = (p[0] * Math.PI) / 180, lo = (p[1] * Math.PI) / 180
  const la2 = Math.asin(Math.sin(la) * Math.cos(d) + Math.cos(la) * Math.sin(d) * Math.cos(b))
  const lo2 = lo + Math.atan2(Math.sin(b) * Math.sin(d) * Math.cos(la), Math.cos(d) - Math.sin(la) * Math.sin(la2))
  return [+(la2 * 180 / Math.PI).toFixed(5), +(lo2 * 180 / Math.PI).toFixed(5)]
}

/**
 * Krog od doma dolg približno za targetMin (čas oceni estimate). Trikotnik: dom → 2 obrača → dom.
 * wantFlat: preizkusi tri smeri in vzame najbolj ravno. Največ 5 klicev.
 */
export async function makeLoop(home: LatLon, targetMin: number, estimate: (prof: number[]) => number, opt: { seed: number; wantFlat: boolean; via?: LatLon[] }): Promise<{ routed: Routed; via: LatLon[] }> {
  if (opt.via?.length) {
    const via = [home, ...opt.via, home]
    return { routed: await brouterRoute(via), via }
  }
  const prof = (x: Routed) => profileOf(cumDist(x.pts), x.alt)
  let theta = (opt.seed * 137.5) % 360
  let r = Math.max(4, (targetMin / 60) * 26 / 3.9)
  const tri = (th: number, rad: number): LatLon[] => [home, dest(home, rad, th - 35), dest(home, rad, th + 35), home]
  let best: { routed: Routed; via: LatLon[] } | null = null
  if (opt.wantFlat) {
    const tries: { routed: Routed; via: LatLon[]; hilly: number; th: number }[] = []
    for (const add of [0, 120, 240]) {
      const th = theta + add, via = tri(th, r)
      try { const routed = await brouterRoute(via); tries.push({ routed, via, th, hilly: gainOf(prof(routed)) / Math.max(1, routed.km) }) } catch { /* ta smer ne gre */ }
    }
    tries.sort((a, b) => a.hilly - b.hilly)
    if (tries[0]) { best = { routed: tries[0].routed, via: tries[0].via }; theta = tries[0].th }
  } else {
    const via = tri(theta, r)
    best = { routed: await brouterRoute(via), via }
  }
  if (!best) throw new Error('Za to smer ni poti — poskusi znova.')
  // dolžina: do trikrat popravi polmer, da se čas ujema (±7 %) — da prideš domov, ko se trening konča
  for (let i = 0; i < 3; i++) {
    const est = estimate(prof(best.routed))
    const ratio = targetMin / Math.max(1, est)
    if (Math.abs(1 - ratio) < 0.07) break
    r = r * ratio
    const via = tri(theta, r)
    try { best = { routed: await brouterRoute(via), via } } catch { break }
  }
  return best
}

/** Nova trasa kot zapis za knjižnico. */
export function routedToRec(routed: Routed, via: LatLon[], name: string, date: string): RouteRec | null {
  const rec = analyzeTrack({ id: `nova:${date}:${Date.now().toString(36)}`, source: 'nova', name, date, rodeMin: null, via }, routed.pts, routed.alt)
  return rec
}

/** GPX 1.1 (trasa za Garmin Connect, Stravo, Komoot). */
export function toGpx(name: string, pts: readonly LatLon[], alt?: readonly number[]): string {
  const esc = (s: string) => s.replace(/[<>&"']/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' }[c]!))
  const trk = pts.map((p, i) => `<trkpt lat="${p[0].toFixed(6)}" lon="${p[1].toFixed(6)}">${alt && Number.isFinite(alt[i]) ? `<ele>${Math.round(alt[i]!)}</ele>` : ''}</trkpt>`).join('')
  return `<?xml version="1.0" encoding="UTF-8"?>\n<gpx version="1.1" creator="FORMAI" xmlns="http://www.topografix.com/GPX/1/1"><metadata><name>${esc(name)}</name></metadata><trk><name>${esc(name)}</name><trkseg>${trk}</trkseg></trk></gpx>\n`
}

/** Povezava na brouter-web (zemljevid OSM, uredi, izvozi). */
export function brouterWebUrl(via: readonly LatLon[]): string {
  const c = via[0]!
  return `https://brouter.de/brouter-web/#map=12/${c[0].toFixed(4)}/${c[1].toFixed(4)}/standard&lonlats=${via.map(p => `${p[1].toFixed(5)},${p[0].toFixed(5)}`).join(';')}&profile=${BROUTER_PROFILE}`
}
