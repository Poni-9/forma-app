import type { Activity, DailyCheckin, MealEntry, PlanDay, Profile } from '@/domain/types'
import { dailyTarget, weightTrend, bmr, tdee, activityKcal, MIN_ABS_M, MIN_ABS_Z, MAX_DEFICIT, MAX_TRAINING_ADD } from '@/domain/nutrition/energy'
import { formSeries, addDays, weekStartIso } from '@/domain/training/load'

export interface Alert { kind: 'warn' | 'bad' | 'info'; text: string; to?: string }

/** Opozorila brez AI: kar človek spregleda, aplikacija pa vidi v številkah. Največ 3, najnujnejša prva. */
export function alerts(i: { profile: Profile; activities: readonly Activity[]; plan: readonly PlanDay[]; checkins: readonly DailyCheckin[]; recentMeals: readonly MealEntry[]; today: string; hour?: number }): Alert[] {
  const { profile: p, today } = i
  const out: Alert[] = []
  const byDay = (d: string) => i.recentMeals.filter(m => m.date === d)
  const tgt = dailyTarget(p, [], [])

  // premalo hrane — pod varno mejo dva dni zapored (samo dnevi, ko je vnos zabeležen)
  const b = bmr(p)
  if (b) {
    const floorAbs = p.sex === 'z' ? MIN_ABS_Z : MIN_ABS_M
    let n = 0
    for (let k = 1; k <= 3; k++) {
      const d = addDays(today, -k), m = byDay(d); if (!m.length) break
      const burn = Math.min(MAX_TRAINING_ADD, i.activities.filter(a => a.date === d).reduce((s, a) => s + activityKcal(a, p), 0))
      const floor = Math.max(b, floorAbs, burn > 0 ? b + burn / 2 : 0, (tdee(p) ?? 0) + burn - MAX_DEFICIT)
      if (m.reduce((s, x) => s + x.kcal, 0) < floor * 0.9) n++; else break
    }
    if (n >= 2) out.push({ kind: 'bad', text: `Vnos ${n} dni zapored pod varno mejo. Premalo hrane pomeni izgubo mišic in slab trening — jej do cilja.`, to: 'prehrana' })
  }
  // beljakovine
  if (tgt) {
    let n = 0
    for (let k = 1; k <= 5; k++) { const m = byDay(addDays(today, -k)); if (!m.length) break; if (m.reduce((s, x) => s + (x.proteinG || 0), 0) < tgt.proteinG * 0.8) n++; else break }
    if (n >= 3) out.push({ kind: 'warn', text: `Beljakovine pod ciljem ${n} dni zapored (cilj ${tgt.proteinG} g). Brez njih v deficitu gre mišica — skuta, jajca, piščanec, jogurt.`, to: 'prehrana' })
  }
  // teža pada prehitro / tehtanje
  const tr = weightTrend(i.checkins)
  if (tr && tr.deltaWeek != null && tr.deltaWeek < -0.7) out.push({ kind: 'warn', text: `Teža pada ${(-tr.deltaWeek).toFixed(2).replace('.', ',')} kg na teden — prehitro, gre mišica in z njo vati. Dodaj 200–300 kcal na dan.`, to: 'napredek' })
  if (tr) { const days = Math.round((new Date(today).getTime() - new Date(tr.lastDate).getTime()) / 86400_000); if (days >= 7) out.push({ kind: 'info', text: `Zadnje tehtanje pred ${days} dnevi — stehtaj se jutri zjutraj.`, to: 'napredek' }) }
  // spanec
  const sl = i.checkins.filter(c => c.date > addDays(today, -5) && c.sleepH).map(c => c.sleepH as number)
  if (sl.length >= 3) { const a = sl.reduce((s, x) => s + x, 0) / sl.length; if (a < 6.5) out.push({ kind: 'warn', text: `Spanec zadnje dni povprečno ${a.toFixed(1).replace('.', ',')} h. Pod 7 h trpita regeneracija in izguba maščobe.` }) }
  // forma
  const s = formSeries(i.activities, today), last = s[s.length - 1]
  if (last && last.tsb < -30) out.push({ kind: 'bad', text: `Forma ${Math.round(last.tsb)} — preutrujen. Dan ali dva lahko, potem naprej.`, to: 'plan' })
  // neoznačene seje ta teden
  const ws = weekStartIso(today)
  const open = i.plan.filter(d => d.date >= ws && d.date < today && d.kind !== 'pocitek' && !d.optional && !d.done)
  if (open.length) out.push({ kind: 'info', text: `${open.length === 1 ? 'Ena seja ta teden ni označena' : `${open.length} seje ta teden niso označene`} — označi ali uvozi, da načrt ve, kje si.`, to: 'plan' })
  // FTP
  if (p.ftp && p.ftpDate) { const d = Math.round((new Date(today).getTime() - new Date(p.ftpDate).getTime()) / 86400_000); if (d > 63) out.push({ kind: 'info', text: `FTP je star ${Math.round(d / 7)} tednov — 20-minutni test da prave vate za intervale.`, to: 'napredek' }) }
  else if (!p.ftp && i.activities.some(a => a.avgPower)) out.push({ kind: 'info', text: 'Imaš moč v vožnjah, FTP pa ni nastavljen — vpiši 20-minutni test.', to: 'napredek' })
  // zvečer brez obroka
  if ((i.hour ?? new Date().getHours()) >= 20 && !byDay(today).length) out.push({ kind: 'info', text: 'Danes še ni zabeleženega obroka.', to: 'prehrana' })
  const rank = { bad: 0, warn: 1, info: 2 }
  return out.sort((a, b) => rank[a.kind] - rank[b.kind]).slice(0, 3)
}
