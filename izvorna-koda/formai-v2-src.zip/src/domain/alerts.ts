import type { Activity, DailyCheckin, MealEntry, PlanDay, Profile } from '@/domain/types'
import { dailyTarget, weightTrend, bmr, tdee, activityKcal, restDuring, lossTooFast, LOSS_TOO_FAST_TIP, MIN_ABS_M, MIN_ABS_Z, MAX_DEFICIT, goalDeficit, isMinor } from '@/domain/nutrition/energy'
import { formSeries, addDays, weekStartIso } from '@/domain/training/load'
import { activityMinutes } from '@/domain/training/plandays'

export interface Alert { kind: 'warn' | 'bad' | 'info'; text: string; to?: string }

/**
 * (v3.49) Ali je dan vpisan cel (za opozorila o vnosu): vsaj 3 obroki ali vsaj 2 z večernim (večerja, »drugo« ali vpis
 * po 17h). Gorivo na kolesu ni obrok. Dan z zajtrkom in kosilom je neznan, ne »pod mejo« — večerja je morda pozabljena.
 */
export function dayLogged(m: readonly Pick<MealEntry, 'slot' | 'time'>[]): boolean {
  const meals = m.filter(x => x.slot !== 'med_vadbo')
  const evening = meals.some(x => x.slot === 'vecerja' || x.slot === 'drugo' || +(/^(\d{1,2}):/.exec(x.time || '')?.[1] ?? 0) >= 17)
  return meals.length >= 3 || (meals.length >= 2 && evening)
}
const DAY_ACC = ['nedeljo', 'ponedeljek', 'torek', 'sredo', 'četrtek', 'petek', 'soboto']
const dayAccOf = (iso: string) => DAY_ACC[new Date(iso + 'T12:00:00Z').getUTCDay()]!

/**
 * Opozorila brez AI: kar človek spregleda, aplikacija pa vidi v številkah (premalo hrane, beljakovine, teža pada
 * prehitro, spanec, preutrujenost, FTP). Največ 3, najnujnejša prva. Na Danes so pod treningom — najprej konkretno.
 * Opomniki niso opozorila: neoznačene seje so pri tednu (unmarkedSessions), tehtanje pri teži (daysSinceWeigh),
 * »še ni obroka« pokaže obroč kalorij.
 */
export function alerts(i: { profile: Profile; activities: readonly Activity[]; plan: readonly PlanDay[]; checkins: readonly DailyCheckin[]; recentMeals: readonly MealEntry[]; today: string; hour?: number }): Alert[] {
  const { profile: p, today } = i
  const out: Alert[] = []
  const byDay = (d: string) => i.recentMeals.filter(m => m.date === d)
  const tgt = dailyTarget(p, [], [])
  // (v3.51) besedila o hujšanju samo pri deficitu (mladoletni in vzdrževanje ga nimajo)
  const def = goalDeficit(p, today) > 0

  // premalo hrane — pod varno mejo dva dni zapored (samo dnevi, ko je vnos zabeležen)
  // (v3.49) dan šteje samo, če je vpisan cel (dayLogged); dan z zajtrkom in kosilom, večerje pa ni, je neznan —
  // takrat namesto rdečega opozorila vprašanje, ali je večerja pozabljena
  const b = bmr(p)
  if (b) {
    const floorAbs = p.sex === 'z' ? MIN_ABS_Z : MIN_ABS_M
    let n = 0
    const miss: string[] = []
    for (let k = 1; k <= 3; k++) {
      const d = addDays(today, -k), m = byDay(d); if (!m.length) break
      // (v3.49) kot v dnevnem cilju: poraba brez osnove za čas treninga
      const burn = i.activities.filter(a => a.date === d).reduce((s, a) => { const k = activityKcal(a, p); return s + k - restDuring(tdee(p) ?? 0, k, activityMinutes(a)) }, 0)
      const floor = Math.max(b, floorAbs, burn > 0 ? b + burn / 2 : 0, (tdee(p) ?? 0) + burn - MAX_DEFICIT)
      if (m.reduce((s, x) => s + x.kcal, 0) >= floor * 0.9) break
      if (!dayLogged(m)) { if (n) break; miss.push(d); continue }
      if (miss.length) break
      n++
    }
    if (n >= 2) out.push({ kind: 'bad', text: `Vnos ${n === 2 ? '2 dneva' : `${n} dni`} zapored pod varno mejo. Premalo hrane pomeni izgubo mišic in slab trening — jej do cilja.`, to: 'prehrana' })
    else if (miss.length >= 2) out.push({ kind: 'info', text: `Za ${miss.map(dayAccOf).join(' in ')} ni vpisane večerje — dodaj jo, da so številke prave.`, to: 'prehrana' })
  }
  // beljakovine
  // (v3.49) dan šteje samo, če je vpisan cel in so beljakovine znane pri vsaj 70 % kalorij (prazno = ne vem, ne 0 g);
  // neznani del dobi beljakovine v istem razmerju kot znani
  if (tgt) {
    let n = 0
    for (let k = 1; k <= 5; k++) {
      const m = byDay(addDays(today, -k)); if (!m.length || !dayLogged(m)) break
      const all = m.reduce((s, x) => s + x.kcal, 0)
      const known = m.filter(x => x.proteinG != null || x.slot === 'med_vadbo')
      const share = all > 0 ? known.reduce((s, x) => s + x.kcal, 0) / all : 0
      if (share < 0.7) break
      if (known.reduce((s, x) => s + (x.proteinG || 0), 0) / share < tgt.proteinG * 0.8) n++; else break
    }
    if (n >= 3) out.push({ kind: 'warn', text: `Beljakovine pod ciljem ${n} dni zapored (cilj ${tgt.proteinG} g). ${def ? 'Brez njih v deficitu gre mišica' : 'Brez njih je obnova počasnejša'} — skuta, jajca, piščanec, jogurt.`, to: 'prehrana' })
  }
  // teža pada prehitro / tehtanje
  const tr = weightTrend(i.checkins)
  // (v3.50) en prag kot Danes in Napredek (lossTooFast, 0,5 kg na teden) brez nihanja tehtanj in isti nasvet (prej 0,7 in »200–300«)
  if (tr && tr.deltaWeek != null && lossTooFast(-tr.deltaWeek - (tr.noise ?? 0))) out.push({ kind: 'warn', text: `Teža pada ${(-tr.deltaWeek).toFixed(2).replace('.', ',')} kg na teden — ${LOSS_TOO_FAST_TIP}`, to: 'napredek' })
  // spanec
  const sl = i.checkins.filter(c => c.date > addDays(today, -5) && c.sleepH).map(c => c.sleepH as number)
  if (sl.length >= 3) { const a = sl.reduce((s, x) => s + x, 0) / sl.length; if (a < 6.5) out.push({ kind: 'warn', text: `Spanec zadnje dni povprečno ${a.toFixed(1).replace('.', ',')} h — cilj je ${isMinor(p) ? '8–10 h, sicer trpita rast in obnova' : `7–9 h, sicer trpi obnova${def ? ' in izguba maščobe' : ''}`}.` }) }
  // forma
  const s = formSeries(i.activities, today), last = s[s.length - 1]
  if (last && last.tsb < -30) out.push({ kind: 'bad', text: `Forma ${Math.round(last.tsb)} — preutrujen. Dan ali dva lahko, potem naprej.`, to: 'plan' })
  // FTP
  if (p.ftp && p.ftpDate) { const d = Math.round((new Date(today).getTime() - new Date(p.ftpDate).getTime()) / 86400_000); if (d > 63) out.push({ kind: 'info', text: `FTP je star ${Math.round(d / 7)} tednov — 20-minutni test da prave vate za intervale.`, to: 'napredek' }) }
  else if (!p.ftp && i.activities.some(a => a.avgPower)) out.push({ kind: 'info', text: 'Imaš moč v vožnjah, FTP pa ni nastavljen — vpiši 20-minutni test.', to: 'napredek' })
  const rank = { bad: 0, warn: 1, info: 2 }
  return out.sort((a, b) => rank[a.kind] - rank[b.kind]).slice(0, 3)
}

/** Pretekli dnevi tega tedna z neoznačeno sejo (ne počitek, ne po želji) — pri tednu na Danes, ne kot opozorilo. */
export function unmarkedSessions(plan: readonly PlanDay[], today: string): number {
  const ws = weekStartIso(today)
  return plan.filter(d => d.date >= ws && d.date < today && d.kind !== 'pocitek' && !d.optional && !d.done).length
}

/** Dni od zadnjega tehtanja (null = še nikoli) — pri teži na Danes. */
export function daysSinceWeigh(checkins: readonly DailyCheckin[], today: string): number | null {
  const last = checkins.filter(c => c.weightKg).map(c => c.date).sort().pop()
  return last ? Math.round((Date.parse(today + 'T12:00:00Z') - Date.parse(last + 'T12:00:00Z')) / 86400_000) : null
}
