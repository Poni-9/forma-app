import type { Activity } from '../types'
import { deriveFlags, INTERVALS_SAFE_ORIGINS } from '../import/provenance'
import { decodePolyline, encodePolyline, thinTrack, type LatLon } from '../import/polyline'
import { sportOfType } from '../training/load'
import { wellnessFromIcu, type WellnessDay } from '../wellness'

const BASE = 'https://intervals.icu/api/v1'
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
/** Časovna omejitev enega zahtevka na intervals.icu. */
export const ICU_TIMEOUT_MS = 30_000

export interface IntervalsCreds { athleteId: string; apiKey: string; token?: string | null }

/** Povezava je uporabna: OAuth žeton ali osebni API ključ (+ Athlete ID). */
export function icuReady(c: IntervalsCreds | null | undefined): c is IntervalsCreds { return !!c && !!c.athleteId && (!!c.token || !!c.apiKey) }

function auth(c: IntervalsCreds): string { return c.token ? `Bearer ${c.token}` : 'Basic ' + btoa('API_KEY:' + c.apiKey.trim()) }

/* ---------- napake ---------- */
/** Vrsta napake: odjava/preklican dostop, kvota, omrežje (tudi časovna omejitev), drugo. */
export type IcuErrKind = 'auth' | 'quota' | 'network' | 'other'
export class IcuError extends Error {
  constructor(readonly kind: IcuErrKind, message: string, readonly status: number | null = null, readonly until: number | null = null) {
    super(message); this.name = 'IcuError'
  }
}
const busyMsg = (until: number) => `intervals.icu: preveč zahtevkov — poskusim znova čez ~${Math.max(1, Math.ceil((until - Date.now()) / 60000))} min.`
/** 429: do Retry-After ne kličemo več (tudi po ponovnem zagonu — čas je shranjen). */
export class IcuBusy extends IcuError {
  declare readonly until: number
  constructor(until: number) { super('quota', busyMsg(until), 429, until); this.name = 'IcuBusy' }
}
/** Dnevni proračun zahtevkov te naprave je porabljen — nenujni klici (sledi, koledar) počakajo do jutri. */
export class IcuBudget extends IcuError {
  declare readonly until: number
  constructor(until: number) { super('quota', 'Današnja kvota intervals.icu za to napravo je porabljena — sledi in koledar nadaljujem jutri.', null, until); this.name = 'IcuBudget' }
}
/** Razvrsti katero koli napako (tudi TypeError iz fetch, AbortError) v vrsto za UI. */
export function icuErrorKind(e: unknown): IcuErrKind {
  if (e instanceof IcuError) return e.kind
  const n = (e as { name?: unknown } | null)?.name
  if (n === 'AbortError' || n === 'TimeoutError' || e instanceof TypeError) return 'network'
  return 'other'
}
const accessMsg = (status: number) => `intervals.icu zavrača dostop (HTTP ${status}) — preveri Athlete ID in ključ.`

/* ---------- kvote ---------- */
/**
 * Kvote intervals.icu: aplikacija z OAuth 100 zahtevkov na uporabnika na dan (skupaj najmanj 5000), v 15 min 1/8 tega;
 * osebni API ključ 5000 na dan in 2500 v 15 min. Prekoračitev vrne 429 + Retry-After. Takrat do izteka ne kličemo več,
 * da ena naprava ne porabi skupne kvote in da vožnje ne obveljajo za »brez sledi«.
 * Poleg tega ima vsaka naprava dnevni proračun (OAuth 80, ključ 1000): ko je porabljen, nenujni klici (sledi,
 * pošiljanje koledarja) počakajo do jutri; nujni (seznam voženj, ročna dejanja) gredo še naprej.
 */
export const ICU_DAILY_BUDGET = { oauth: 80, key: 1000 } as const
export interface IcuQuota { pauseUntil: number; day: string; used: number }
/** Shramba kvote (store jo nastavi na IndexedDB, da premor po 429 in poraba dneva preživita ponovni zagon). */
export interface IcuQuotaStore { load(): Promise<IcuQuota | null | undefined>; save(q: IcuQuota): Promise<void> }
let quota: IcuQuota = { pauseUntil: 0, day: '', used: 0 }
let qStore: IcuQuotaStore | null = null
let qReady: Promise<void> | null = null
const pad = (n: number) => String(n).padStart(2, '0')
const localDay = (t: number) => { const d = new Date(t); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}` }
const nextMidnight = (t: number) => { const d = new Date(t); d.setHours(24, 0, 0, 0); return d.getTime() }
const budgetOf = (c: IntervalsCreds) => (c.token ? ICU_DAILY_BUDGET.oauth : ICU_DAILY_BUDGET.key)

export function setIcuQuotaStore(s: IcuQuotaStore | null): Promise<void> {
  qStore = s
  qReady = s ? s.load().then(v => {
    if (!v) return
    const day = localDay(Date.now())
    quota = {
      pauseUntil: Math.max(quota.pauseUntil, +v.pauseUntil || 0),
      day,
      used: Math.max(quota.day === day ? quota.used : 0, v.day === day ? +v.used || 0 : 0),
    }
  }).catch(() => undefined) : null
  return qReady || Promise.resolve()
}
function persist() { if (qStore) void qStore.save({ ...quota }).catch(() => undefined) }

/** Poraba dnevnega proračuna te naprave (za odločitev, ali nenujne klice sploh začeti). */
export function icuBudget(c: IntervalsCreds, now = Date.now()): { used: number; limit: number; left: number; pauseUntil: number } {
  const used = quota.day === localDay(now) ? quota.used : 0, limit = budgetOf(c)
  return { used, limit, left: Math.max(0, limit - used), pauseUntil: quota.pauseUntil > now ? quota.pauseUntil : 0 }
}

function timeoutSignal(ms: number): AbortSignal | undefined {
  try {
    const T = (AbortSignal as unknown as { timeout?: (ms: number) => AbortSignal }).timeout
    if (typeof T === 'function') return T.call(AbortSignal, ms)
    const ac = new AbortController(); setTimeout(() => ac.abort(), ms); return ac.signal
  } catch { return undefined }
}

/** Vsak klic na intervals.icu: premor po 429, dnevni proračun (nenujni klici), 30 s časovna omejitev. */
async function icuFetch(c: IntervalsCreds, url: string, init: RequestInit, essential = true): Promise<Response> {
  if (qReady) await qReady
  const now = Date.now()
  if (now < quota.pauseUntil) throw new IcuBusy(quota.pauseUntil)
  const day = localDay(now)
  if (quota.day !== day) quota = { ...quota, day, used: 0 }
  if (!essential && quota.used >= budgetOf(c)) throw new IcuBudget(nextMidnight(now))
  quota = { ...quota, used: quota.used + 1 }
  persist()
  let r: Response
  try { r = await fetch(url, { ...init, signal: init.signal ?? timeoutSignal(ICU_TIMEOUT_MS) }) }
  catch (e) {
    const n = (e as { name?: unknown } | null)?.name
    throw new IcuError('network', n === 'TimeoutError' || n === 'AbortError' ? 'intervals.icu se ni odzval v 30 s — poskusim znova kasneje.' : 'intervals.icu ni dosegljiv — preveri povezavo.')
  }
  if (r.status === 429) {
    const s = Number(r.headers.get('Retry-After'))
    quota = { ...quota, pauseUntil: Date.now() + (Number.isFinite(s) && s > 0 ? Math.min(s, 3600) : 300) * 1000 }
    persist()
    throw new IcuBusy(quota.pauseUntil)
  }
  return r
}
/** samo za teste */
export const resetIcuPause = () => { quota = { pauseUntil: 0, day: '', used: 0 } }

/** Odklop aplikacije v intervals.icu (samo za OAuth žeton). */
export async function disconnectApp(c: IntervalsCreds): Promise<void> {
  if (!c.token) return
  await icuFetch(c, `${BASE}/disconnect-app`, { method: 'DELETE', headers: { Authorization: auth(c) } }).catch(() => undefined)
}

export async function fetchAthlete(c: IntervalsCreds): Promise<{ name: string; ftp?: number; lthr?: number; maxHr?: number; restHr?: number }> {
  const r = await icuFetch(c, `${BASE}/athlete/${encodeURIComponent(c.athleteId.trim())}`, { headers: { Authorization: auth(c) } })
  if (!r.ok) throw new IcuError(r.status === 401 || r.status === 403 ? 'auth' : 'other', `intervals.icu: HTTP ${r.status} — preveri Athlete ID (oblika i12345) in API ključ.`, r.status)
  const d = await r.json()
  const ss = (d.sportSettings || []).find((s: any) => /ride|bike|cycl/i.test(JSON.stringify(s.types || s.type || ''))) || (d.sportSettings || [])[0]
  return {
    name: d.name || [d.firstname, d.lastname].filter(Boolean).join(' ') || 'povezan',
    ftp: ss?.ftp ? Math.round(ss.ftp) : undefined, lthr: ss?.lthr ? Math.round(ss.lthr) : undefined,
    maxHr: ss?.max_hr ? Math.round(ss.max_hr) : undefined, restHr: d.icu_resting_hr ? Math.round(d.icu_resting_hr) : undefined,
  }
}

export interface IntervalsImportResult {
  activities: Activity[]
  /** koliko jih je Stravinega izvora (prikazane, a ne v AI) */
  stravaOrigin: number
  /** Stravini zapisi, ki jih API ne izda (samo datum) — ne uvozimo jih */
  stravaStubs: number
  /** koliko zapisov je API sploh vrnil */
  total: number
  /** neznane vrednosti izvora (privzeto ne v AI) */
  unknownOrigins: string[]
  skippedShort: number
}

/** Stravin zapis brez podatkov: intervals.icu ga po Stravinih pravilih ne sme izdati (vrne le id, datum, izvor in opombo). */
export const isStravaStub = (a: any): boolean =>
  String(a?.source || a?.icu_sync_source || '').toUpperCase() === 'STRAVA' && (!!a?._note || !(a?.moving_time || a?.elapsed_time || a?.distance))

/** Prebere seznam aktivnosti; sled se pobere ločeno (fetchTrack), da ne obremenimo kvote. */
export async function fetchActivities(c: IntervalsCreds, oldestIso: string, newestIso: string): Promise<IntervalsImportResult> {
  const r = await icuFetch(c, `${BASE}/athlete/${encodeURIComponent(c.athleteId.trim())}/activities?oldest=${oldestIso}&newest=${newestIso}`, { headers: { Authorization: auth(c), Accept: 'application/json' } })
  if (r.status === 401 || r.status === 403) throw new IcuError('auth', accessMsg(r.status), r.status)
  if (!r.ok) throw new IcuError(r.status >= 500 ? 'network' : 'other', `intervals.icu: HTTP ${r.status}`, r.status)
  const acts: any[] = await r.json()
  const out: Activity[] = []; let stravaOrigin = 0, stravaStubs = 0, skippedShort = 0; const unknown = new Set<string>()
  const now = new Date().toISOString()
  const list = Array.isArray(acts) ? acts : []
  for (const a of list) {
    // najprej izvor: Stravin »stub« nima vrste ne trajanja — brez tega štetja bi izginil tiho (»ni aktivnosti«)
    if (isStravaStub(a)) { stravaOrigin++; stravaStubs++; continue }
    const sp = sportOfType(String(a.type || a.sport || a.activity_type || ''))
    if (!sp) continue
    const min = (a.moving_time || a.elapsed_time || 0) / 60, km = (a.distance || 0) / 1000
    if (sp === 'pohod' && (min < 15 || km < 1)) { skippedShort++; continue }
    if (sp !== 'pohod' && sp !== 'moc' && min < 5) { skippedShort++; continue }
    const origin = String(a.source || a.icu_sync_source || '').toUpperCase() || null
    if (origin === 'STRAVA') stravaOrigin++
    else if (!INTERVALS_SAFE_ORIGINS.has(origin || '')) unknown.add(origin || '(prazno)')
    const durationMin = Math.round(min) || null
    const distKm = a.distance != null ? +(km).toFixed(1) : null
    out.push({
      id: uid(), source: 'intervals', originHint: origin, deviceName: a.device_name || null, sport: sp,
      date: String(a.start_date_local || a.start_date || '').slice(0, 10), start: a.start_date ? new Date(a.start_date).toISOString() : null,
      name: a.name || 'Vožnja', distKm, durationMin, elapsedMin: a.elapsed_time ? Math.round(a.elapsed_time / 60) : null, elevM: a.total_elevation_gain != null ? Math.round(a.total_elevation_gain) : (a.icu_climb != null ? Math.round(a.icu_climb) : null),
      avgHr: a.average_heartrate ? Math.round(a.average_heartrate) : null, maxHr: a.max_heartrate ? Math.round(a.max_heartrate) : null,
      avgPower: a.icu_average_watts ? Math.round(a.icu_average_watts) : (a.average_watts ? Math.round(a.average_watts) : null),
      speedKmh: distKm && durationMin ? +(distKm / (durationMin / 60)).toFixed(1) : null, kcal: a.calories ? Math.round(a.calories) : null,
      tss: a.icu_training_load > 0 ? Math.round(a.icu_training_load) : null, polyline: null,
      hrZoneSec: Array.isArray(a.icu_hr_zone_times) && a.icu_hr_zone_times.some((x: number) => x > 0) ? a.icu_hr_zone_times.map((x: number) => Math.round(+x || 0)) : null,
      hrZoneTop: Array.isArray(a.icu_hr_zones) ? a.icu_hr_zones.map((x: number) => Math.round(+x || 0)) : null,
      deviceWatts: a.device_watts === true ? true : (a.average_heartrate || a.distance) ? false : null,
      trainer: a.trainer === true,
      ...deriveFlags('intervals', origin), ext: { intervalsId: a.id, icuCtl: Number.isFinite(+a.icu_ctl) && a.icu_ctl != null ? +a.icu_ctl : null, icuAtl: Number.isFinite(+a.icu_atl) && a.icu_atl != null ? +a.icu_atl : null }, createdAt: now, updatedAt: now,
    })
  }
  return { activities: out, stravaOrigin, stravaStubs, total: list.length, unknownOrigins: [...unknown], skippedShort }
}

/**
 * Spanec, HRV in mirovni utrip (intervals.icu »wellness«, iz Garmin Connect, Oure, Whoopa …).
 * Samo polja, ki jih rabimo; zapisi brez teh podatkov se izpustijo. Ostanejo samo na napravi.
 */
export async function fetchWellness(c: IntervalsCreds, oldestIso: string, newestIso: string): Promise<WellnessDay[]> {
  const f = 'id,sleepSecs,sleepScore,hrv,restingHR'
  const r = await icuFetch(c, `${BASE}/athlete/${encodeURIComponent(c.athleteId.trim())}/wellness?oldest=${oldestIso}&newest=${newestIso}&fields=${f}`, { headers: { Authorization: auth(c), Accept: 'application/json' } })
  if (r.status === 401 || r.status === 403) throw new IcuError('auth', accessMsg(r.status), r.status)
  if (!r.ok) throw new IcuError(r.status >= 500 ? 'network' : 'other', `intervals.icu wellness: HTTP ${r.status}`, r.status)
  const list: unknown = await r.json()
  return (Array.isArray(list) ? list : []).map(w => wellnessFromIcu(w as Record<string, unknown>)).filter((d): d is WellnessDay => !!d).sort((a, b) => a.date.localeCompare(b.date))
}

/**
 * Sled in višine vožnje. intervals.icu vrne latlng kot dva seznama (data = lat, data2 = lng). Nenujni klic (proračun).
 * 404 ali prazen/nerazumljiv odgovor → null (vožnja nima sledi, npr. trenažer).
 * 401/403 (odjava), 429 (kvota), 5xx, omrežje, porabljen proračun → napaka: vožnja NE obvelja za »brez sledi«
 * in pride znova na vrsto, ko povezava spet dela.
 */
export async function fetchStreams(c: IntervalsCreds, intervalsId: string | number): Promise<{ lat: (number | null)[]; lng: (number | null)[]; alt: (number | null)[] | null } | null> {
  const r = await icuFetch(c, `${BASE}/activity/${intervalsId}/streams?types=latlng,altitude`, { headers: { Authorization: auth(c) } }, false)
  if (r.status === 404) return null
  if (r.status === 401 || r.status === 403) throw new IcuError('auth', `intervals.icu sled: HTTP ${r.status} — dostop zavrnjen.`, r.status)
  if (!r.ok) throw new IcuError(r.status >= 500 ? 'network' : 'other', `intervals.icu sled: HTTP ${r.status}`, r.status)
  const js = await r.json().catch(() => null)
  const list: any[] = Array.isArray(js) ? js : []
  const ll = list.find(x => x && x.type === 'latlng'), al = list.find(x => x && x.type === 'altitude')
  if (!ll || !Array.isArray(ll.data)) return null
  let lat: (number | null)[], lng: (number | null)[]
  if (Array.isArray(ll.data2)) { lat = ll.data; lng = ll.data2 }
  else { lat = ll.data.map((p: any) => (Array.isArray(p) ? p[0] : null)); lng = ll.data.map((p: any) => (Array.isArray(p) ? p[1] : null)) }
  return { lat, lng, alt: al && Array.isArray(al.data) ? al.data : null }
}

export async function fetchTrack(c: IntervalsCreds, intervalsId: string | number): Promise<string | null> {
  const st = await fetchStreams(c, intervalsId)
  if (!st) return null
  const pts: LatLon[] = []
  for (let i = 0; i < Math.min(st.lat.length, st.lng.length); i++) { const a = st.lat[i], b = st.lng[i]; if (a != null && b != null) pts.push([+a, +b]) }
  const th = thinTrack(pts, 20)
  return th.length > 1 ? encodePolyline(th) : null
}

export { decodePolyline }

/* ---------- koledar: treningi na uro (intervals.icu → Garmin Connect) ---------- */
import type { IcuEventLite, IcuWorkout } from './workouts'
/** essential: ročno dejanje (pošlji zdaj, izklop) — gre mimo dnevnega proračuna; samodejno ponovno pošiljanje ne. */
export interface IcuCallOpts { essential?: boolean }

/** Načrtovani treningi v koledarju za obdobje (samo WORKOUT). */
export async function fetchEvents(c: IntervalsCreds, oldestIso: string, newestIso: string, o: IcuCallOpts = {}): Promise<IcuEventLite[]> {
  const r = await icuFetch(c, `${BASE}/athlete/${encodeURIComponent(c.athleteId.trim())}/events?oldest=${oldestIso}&newest=${newestIso}&category=WORKOUT`, { headers: { Authorization: auth(c), Accept: 'application/json' } }, !!o.essential)
  if (r.status === 401 || r.status === 403) throw new IcuError('auth', accessMsg(r.status), r.status)
  if (!r.ok) throw new IcuError(r.status >= 500 ? 'network' : 'other', `intervals.icu koledar: HTTP ${r.status}`, r.status)
  const list: any[] = await r.json()
  return (Array.isArray(list) ? list : []).map(e => ({ id: e.id, uid: e.uid ?? null, external_id: e.external_id ?? null, start_date_local: e.start_date_local ?? null, name: e.name ?? null, description: e.description ?? null, moving_time: e.moving_time ?? null, category: e.category ?? null }))
}

const eventBody = (w: IcuWorkout) => ({ uid: w.uid, external_id: w.uid, category: 'WORKOUT', type: 'Ride', start_date_local: `${w.date}T00:00:00`, name: w.name, description: w.description, moving_time: w.movingTime })

/** Ustvari ali posodobi treninge v koledarju z enim zahtevkom (upsert po uid). */
export async function createEvents(c: IntervalsCreds, ws: readonly IcuWorkout[], o: IcuCallOpts = {}): Promise<void> {
  if (!ws.length) return
  const r = await icuFetch(c, `${BASE}/athlete/${encodeURIComponent(c.athleteId.trim())}/events/bulk?upsertOnUid=true`, { method: 'POST', headers: { Authorization: auth(c), 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(ws.map(eventBody)) }, !!o.essential)
  if (r.status === 401 || r.status === 403) throw new IcuError('auth', accessMsg(r.status), r.status)
  if (!r.ok) throw new IcuError(r.status >= 500 ? 'network' : 'other', `intervals.icu koledar: HTTP ${r.status} pri pošiljanju`, r.status)
}

/** Posodobi obstoječi trening (po id dogodka). */
export async function updateEvent(c: IntervalsCreds, id: number, w: IcuWorkout, o: IcuCallOpts = {}): Promise<void> {
  const r = await icuFetch(c, `${BASE}/athlete/${encodeURIComponent(c.athleteId.trim())}/events/${id}`, { method: 'PUT', headers: { Authorization: auth(c), 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(eventBody(w)) }, !!o.essential)
  if (r.status === 401 || r.status === 403) throw new IcuError('auth', accessMsg(r.status), r.status)
  if (!r.ok) throw new IcuError(r.status >= 500 ? 'network' : 'other', `intervals.icu koledar: HTTP ${r.status} pri posodabljanju`, r.status)
}

export async function deleteEvent(c: IntervalsCreds, id: number, o: IcuCallOpts = {}): Promise<void> {
  const r = await icuFetch(c, `${BASE}/athlete/${encodeURIComponent(c.athleteId.trim())}/events/${id}`, { method: 'DELETE', headers: { Authorization: auth(c) } }, !!o.essential)
  if (r.status === 401 || r.status === 403) throw new IcuError('auth', accessMsg(r.status), r.status)
  if (!r.ok && r.status !== 404) throw new IcuError(r.status >= 500 ? 'network' : 'other', `intervals.icu koledar: HTTP ${r.status} pri brisanju`, r.status)
}
