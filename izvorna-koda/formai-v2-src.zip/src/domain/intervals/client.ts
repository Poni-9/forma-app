import type { Activity } from '../types'
import { deriveFlags, INTERVALS_SAFE_ORIGINS } from '../import/provenance'
import { decodePolyline, encodePolyline, thinTrack, type LatLon } from '../import/polyline'
import { sportOfType } from '../training/load'

const BASE = 'https://intervals.icu/api/v1'
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)

export interface IntervalsCreds { athleteId: string; apiKey: string }

function auth(c: IntervalsCreds): string { return 'Basic ' + btoa('API_KEY:' + c.apiKey.trim()) }

export async function fetchAthlete(c: IntervalsCreds): Promise<{ name: string; ftp?: number; lthr?: number; maxHr?: number; restHr?: number }> {
  const r = await fetch(`${BASE}/athlete/${encodeURIComponent(c.athleteId.trim())}`, { headers: { Authorization: auth(c) } })
  if (!r.ok) throw new Error(`intervals.icu: HTTP ${r.status} — preveri Athlete ID (oblika i12345) in API ključ.`)
  const d = await r.json()
  const ss = (d.sportSettings || []).find((s: any) => /ride|bike|cycl/i.test(JSON.stringify(s.types || s.type || ''))) || (d.sportSettings || [])[0]
  return {
    name: d.name || [d.firstname, d.lastname].filter(Boolean).join(' ') || 'povezan',
    ftp: ss?.ftp ? Math.round(ss.ftp) : undefined, lthr: ss?.lthr ? Math.round(ss.lthr) : undefined,
    maxHr: ss?.max_hr ? Math.round(ss.max_hr) : undefined, restHr: d.icu_resting_hr ? Math.round(d.icu_resting_hr) : undefined,
  }
}

export interface IntervalsImportResult {
  activities: Activity[]
  /** koliko jih je Stravinega izvora (prikazane, a ne v AI) */
  stravaOrigin: number
  /** neznane vrednosti izvora (privzeto ne v AI) */
  unknownOrigins: string[]
  skippedShort: number
}

/** Prebere seznam aktivnosti; sled se pobere ločeno (fetchTrack), da ne obremenimo kvote. */
export async function fetchActivities(c: IntervalsCreds, oldestIso: string, newestIso: string): Promise<IntervalsImportResult> {
  const r = await fetch(`${BASE}/athlete/${encodeURIComponent(c.athleteId.trim())}/activities?oldest=${oldestIso}&newest=${newestIso}`, { headers: { Authorization: auth(c), Accept: 'application/json' } })
  if (r.status === 401 || r.status === 403) throw new Error(`intervals.icu zavrača dostop (HTTP ${r.status}) — preveri Athlete ID in ključ.`)
  if (!r.ok) throw new Error(`intervals.icu: HTTP ${r.status}`)
  const acts: any[] = await r.json()
  const out: Activity[] = []; let stravaOrigin = 0, skippedShort = 0; const unknown = new Set<string>()
  const now = new Date().toISOString()
  for (const a of Array.isArray(acts) ? acts : []) {
    const sp = sportOfType(String(a.type || a.sport || a.activity_type || ''))
    if (!sp) continue
    const min = (a.moving_time || a.elapsed_time || 0) / 60, km = (a.distance || 0) / 1000
    if (sp === 'pohod' && (min < 15 || km < 1)) { skippedShort++; continue }
    if (sp !== 'pohod' && sp !== 'moc' && min < 5) { skippedShort++; continue }
    const origin = String(a.source || a.icu_sync_source || '').toUpperCase() || null
    if (origin === 'STRAVA') stravaOrigin++
    else if (!INTERVALS_SAFE_ORIGINS.has(origin || '')) unknown.add(origin || '(prazno)')
    const durationMin = Math.round(min) || null
    const distKm = a.distance != null ? +(km).toFixed(1) : null
    out.push({
      id: uid(), source: 'intervals', originHint: origin, deviceName: a.device_name || null, sport: sp,
      date: String(a.start_date_local || a.start_date || '').slice(0, 10), start: a.start_date ? new Date(a.start_date).toISOString() : null,
      name: a.name || 'Vožnja', distKm, durationMin, elevM: a.total_elevation_gain != null ? Math.round(a.total_elevation_gain) : (a.icu_climb != null ? Math.round(a.icu_climb) : null),
      avgHr: a.average_heartrate ? Math.round(a.average_heartrate) : null, maxHr: a.max_heartrate ? Math.round(a.max_heartrate) : null,
      avgPower: a.icu_average_watts ? Math.round(a.icu_average_watts) : (a.average_watts ? Math.round(a.average_watts) : null),
      speedKmh: distKm && durationMin ? +(distKm / (durationMin / 60)).toFixed(1) : null, kcal: a.calories ? Math.round(a.calories) : null,
      tss: a.icu_training_load > 0 ? Math.round(a.icu_training_load) : null, polyline: null,
      ...deriveFlags('intervals', origin), ext: { intervalsId: a.id }, createdAt: now, updatedAt: now,
    })
  }
  return { activities: out, stravaOrigin, unknownOrigins: [...unknown], skippedShort }
}

/** Polna latlng sled ene aktivnosti → kodirana, zredčena. Kliči samo za geoRetain aktivnosti. */
export async function fetchTrack(c: IntervalsCreds, intervalsId: string | number): Promise<string | null> {
  const r = await fetch(`${BASE}/activity/${intervalsId}/streams?types=latlng`, { headers: { Authorization: auth(c) } })
  if (!r.ok) return null
  const js = await r.json()
  const st = (Array.isArray(js) ? js : []).find((x: any) => x.type === 'latlng')
  const pts: LatLon[] = (st?.data || []).filter((p: any) => Array.isArray(p) && p.length === 2).map((p: any) => [+p[0], +p[1]] as LatLon)
  const th = thinTrack(pts, 20)
  return th.length > 1 ? encodePolyline(th) : null
}

export { decodePolyline }
