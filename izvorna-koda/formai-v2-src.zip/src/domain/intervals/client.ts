import type { Activity } from '../types'
import { deriveFlags, INTERVALS_SAFE_ORIGINS } from '../import/provenance'
import { decodePolyline, encodePolyline, thinTrack, type LatLon } from '../import/polyline'
import { sportOfType } from '../training/load'

const BASE = 'https://intervals.icu/api/v1'
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)

export interface IntervalsCreds { athleteId: string; apiKey: string }

function auth(c: IntervalsCreds): string { return 'Basic ' + btoa('API_KEY:' + c.apiKey.trim()) }

export async function fetchAthlete(c: IntervalsCreds): Promise<{ name: string; ftp?: number; lthr?: number; maxHr?: number; restHr?: number }> {
  const r = await fetch(`${BASE}/athlete/${encodeURIComponent(c.athleteId.trim())}`, { headers: { Authorization: auth(c) } })
  if (!r.ok) throw new Error(`intervals.icu: HTTP ${r.status} — preveri Athlete ID (oblika i12345) in API ključ.`)
  const d = await r.json()
  const ss = (d.sportSettings || []).find((s: any) => /ride|bike|cycl/i.test(JSON.stringify(s.types || s.type || ''))) || (d.sportSettings || [])[0]
  return {
    name: d.name || [d.firstname, d.lastname].filter(Boolean).join(' ') || 'povezan',
    ftp: ss?.ftp ? Math.round(ss.ftp) : undefined, lthr: ss?.lthr ? Math.round(ss.lthr) : undefined,
    maxHr: ss?.max_hr ? Math.round(ss.max_hr) : undefined, restHr: d.icu_resting_hr ? Math.round(d.icu_resting_hr) : undefined,
  }
}

export interface IntervalsImportResult {
  activities: Activity[]
  /** koliko jih je Stravinega izvora (prikazane, a ne v AI) */
  stravaOrigin: number
  /** Stravini zapisi, ki jih API ne izda (samo datum) — ne uvozimo jih */
  stravaStubs: number
  /** koliko zapisov je API sploh vrnil */
  total: number
  /** neznane vrednosti izvora (privzeto ne v AI) */
  unknownOrigins: string[]
  skippedShort: number
}

/** Stravin zapis brez podatkov: intervals.icu ga po Stravinih pravilih ne sme izdati (vrne le id, datum, izvor in opombo). */
export const isStravaStub = (a: any): boolean =>
  String(a?.source || a?.icu_sync_source || '').toUpperCase() === 'STRAVA' && (!!a?._note || !(a?.moving_time || a?.elapsed_time || a?.distance))

/** Prebere seznam aktivnosti; sled se pobere ločeno (fetchTrack), da ne obremenimo kvote. */
export async function fetchActivities(c: IntervalsCreds, oldestIso: string, newestIso: string): Promise<IntervalsImportResult> {
  const r = await fetch(`${BASE}/athlete/${encodeURIComponent(c.athleteId.trim())}/activities?oldest=${oldestIso}&newest=${newestIso}`, { headers: { Authorization: auth(c), Accept: 'application/json' } })
  if (r.status === 401 || r.status === 403) throw new Error(`intervals.icu zavrača dostop (HTTP ${r.status}) — preveri Athlete ID in ključ.`)
  if (!r.ok) throw new Error(`intervals.icu: HTTP ${r.status}`)
  const acts: any[] = await r.json()
  const out: Activity[] = []; let stravaOrigin = 0, stravaStubs = 0, skippedShort = 0; const unknown = new Set<string>()
  const now = new Date().toISOString()
  const list = Array.isArray(acts) ? acts : []
  for (const a of list) {
    // najprej izvor: Stravin »stub« nima vrste ne trajanja — brez tega štetja bi izginil tiho (»ni aktivnosti«)
    if (isStravaStub(a)) { stravaOrigin++; stravaStubs++; continue }
    const sp = sportOfType(String(a.type || a.sport || a.activity_type || ''))
    if (!sp) continue
    const min = (a.moving_time || a.elapsed_time || 0) / 60, km = (a.distance || 0) / 1000
    if (sp === 'pohod' && (min < 15 || km < 1)) { skippedShort++; continue }
    if (sp !== 'pohod' && sp !== 'moc' && min < 5) { skippedShort++; continue }
    const origin = String(a.source || a.icu_sync_source || '').toUpperCase() || null
    if (origin === 'STRAVA') stravaOrigin++
    else if (!INTERVALS_SAFE_ORIGINS.has(origin || '')) unknown.add(origin || '(prazno)')
    const durationMin = Math.round(min) || null
    const distKm = a.distance != null ? +(km).toFixed(1) : null
    out.push({
      id: uid(), source: 'intervals', originHint: origin, deviceName: a.device_name || null, sport: sp,
      date: String(a.start_date_local || a.start_date || '').slice(0, 10), start: a.start_date ? new Date(a.start_date).toISOString() : null,
      name: a.name || 'Vožnja', distKm, durationMin, elevM: a.total_elevation_gain != null ? Math.round(a.total_elevation_gain) : (a.icu_climb != null ? Math.round(a.icu_climb) : null),
      avgHr: a.average_heartrate ? Math.round(a.average_heartrate) : null, maxHr: a.max_heartrate ? Math.round(a.max_heartrate) : null,
      avgPower: a.icu_average_watts ? Math.round(a.icu_average_watts) : (a.average_watts ? Math.round(a.average_watts) : null),
      speedKmh: distKm && durationMin ? +(distKm / (durationMin / 60)).toFixed(1) : null, kcal: a.calories ? Math.round(a.calories) : null,
      tss: a.icu_training_load > 0 ? Math.round(a.icu_training_load) : null, polyline: null,
      hrZoneSec: Array.isArray(a.icu_hr_zone_times) && a.icu_hr_zone_times.some((x: number) => x > 0) ? a.icu_hr_zone_times.map((x: number) => Math.round(+x || 0)) : null,
      hrZoneTop: Array.isArray(a.icu_hr_zones) ? a.icu_hr_zones.map((x: number) => Math.round(+x || 0)) : null,
      deviceWatts: a.device_watts === true ? true : (a.average_heartrate || a.distance) ? false : null,
      trainer: a.trainer === true,
      ...deriveFlags('intervals', origin), ext: { intervalsId: a.id }, createdAt: now, updatedAt: now,
    })
  }
  return { activities: out, stravaOrigin, stravaStubs, total: list.length, unknownOrigins: [...unknown], skippedShort }
}

/** Polna latlng sled ene aktivnosti → kodirana, zredčena. Kliči samo za geoRetain aktivnosti. */
/** Sled in višine vožnje. intervals.icu vrne latlng kot dva seznama (data = lat, data2 = lng). */
export async function fetchStreams(c: IntervalsCreds, intervalsId: string | number): Promise<{ lat: (number | null)[]; lng: (number | null)[]; alt: (number | null)[] | null } | null> {
  const r = await fetch(`${BASE}/activity/${intervalsId}/streams?types=latlng,altitude`, { headers: { Authorization: auth(c) } })
  if (!r.ok) return null
  const js = await r.json()
  const list: any[] = Array.isArray(js) ? js : []
  const ll = list.find(x => x && x.type === 'latlng'), al = list.find(x => x && x.type === 'altitude')
  if (!ll || !Array.isArray(ll.data)) return null
  let lat: (number | null)[], lng: (number | null)[]
  if (Array.isArray(ll.data2)) { lat = ll.data; lng = ll.data2 }
  else { lat = ll.data.map((p: any) => (Array.isArray(p) ? p[0] : null)); lng = ll.data.map((p: any) => (Array.isArray(p) ? p[1] : null)) }
  return { lat, lng, alt: al && Array.isArray(al.data) ? al.data : null }
}

export async function fetchTrack(c: IntervalsCreds, intervalsId: string | number): Promise<string | null> {
  const st = await fetchStreams(c, intervalsId)
  if (!st) return null
  const pts: LatLon[] = []
  for (let i = 0; i < Math.min(st.lat.length, st.lng.length); i++) { const a = st.lat[i], b = st.lng[i]; if (a != null && b != null) pts.push([+a, +b]) }
  const th = thinTrack(pts, 20)
  return th.length > 1 ? encodePolyline(th) : null
}

export { decodePolyline }

/* ---------- koledar: treningi na uro (intervals.icu → Garmin Connect) ---------- */
import type { IcuEventLite, IcuWorkout } from './workouts'

/** Načrtovani treningi v koledarju za obdobje (samo WORKOUT). */
export async function fetchEvents(c: IntervalsCreds, oldestIso: string, newestIso: string): Promise<IcuEventLite[]> {
  const r = await fetch(`${BASE}/athlete/${encodeURIComponent(c.athleteId.trim())}/events?oldest=${oldestIso}&newest=${newestIso}&category=WORKOUT`, { headers: { Authorization: auth(c), Accept: 'application/json' } })
  if (!r.ok) throw new Error(`intervals.icu koledar: HTTP ${r.status}`)
  const list: any[] = await r.json()
  return (Array.isArray(list) ? list : []).map(e => ({ id: e.id, uid: e.uid ?? null, external_id: e.external_id ?? null, start_date_local: e.start_date_local ?? null, name: e.name ?? null, description: e.description ?? null, moving_time: e.moving_time ?? null, category: e.category ?? null }))
}

const eventBody = (w: IcuWorkout) => ({ uid: w.uid, external_id: w.uid, category: 'WORKOUT', type: 'Ride', start_date_local: `${w.date}T00:00:00`, name: w.name, description: w.description, moving_time: w.movingTime })

/** Ustvari treninge v koledarju (če uid že obstaja, ga posodobi). */
export async function createEvents(c: IntervalsCreds, ws: readonly IcuWorkout[]): Promise<void> {
  if (!ws.length) return
  const r = await fetch(`${BASE}/athlete/${encodeURIComponent(c.athleteId.trim())}/events/bulk?upsertOnUid=true`, { method: 'POST', headers: { Authorization: auth(c), 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(ws.map(eventBody)) })
  if (!r.ok) throw new Error(`intervals.icu koledar: HTTP ${r.status} pri pošiljanju`)
}

/** Posodobi obstoječi trening (po id dogodka). */
export async function updateEvent(c: IntervalsCreds, id: number, w: IcuWorkout): Promise<void> {
  const r = await fetch(`${BASE}/athlete/${encodeURIComponent(c.athleteId.trim())}/events/${id}`, { method: 'PUT', headers: { Authorization: auth(c), 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(eventBody(w)) })
  if (!r.ok) throw new Error(`intervals.icu koledar: HTTP ${r.status} pri posodabljanju`)
}

export async function deleteEvent(c: IntervalsCreds, id: number): Promise<void> {
  const r = await fetch(`${BASE}/athlete/${encodeURIComponent(c.athleteId.trim())}/events/${id}`, { method: 'DELETE', headers: { Authorization: auth(c) } })
  if (!r.ok && r.status !== 404) throw new Error(`intervals.icu koledar: HTTP ${r.status} pri brisanju`)
}
