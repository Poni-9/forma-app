/**
 * Pošteno pojasnilo po uvozu iz intervals.icu, ko trener voženj ne dobi.
 * Najpogostejši razlog: intervals.icu je napolnjen s Strave. Takih aktivnosti po Stravinih pravilih ne sme dati
 * drugim aplikacijam — API vrne samo »stub« (datum, brez podatkov), zato jih FORMAI ne vidi.
 * Rešitev je neposredna povezava ure z intervals.icu. Čista funkcija — stanje je v state/store.
 */
export interface IcuDiag {
  at: string
  /** koliko dni nazaj smo spraševali */
  days: number
  /** koliko zapisov je API sploh vrnil */
  total: number
  /** koliko jih je uporabnih (uvoženih) */
  usable: number
  /** Stravini zapisi, ki jih API ne izda */
  stravaStubs: number
  /** koliko voženj iz intervals.icu FORMAI že ima od prej */
  known: number
}

export const ICU_SETTINGS_URL = 'https://intervals.icu/settings'

export interface IcuAdvice { tone: 'warn' | 'info'; title: string; text: string }

export function importDiagnosis(d: IcuDiag | null | undefined): IcuAdvice | null {
  if (!d) return null
  if (d.stravaStubs > 0 && d.usable === 0) return {
    tone: 'warn',
    title: `${d.stravaStubs} ${d.stravaStubs === 1 ? 'vožnja je' : 'voženj je'} s Strave — FORMAI jih ne vidi`,
    text: 'intervals.icu jih je dobil s Strave, Stravina pravila pa mu prepovedujejo, da bi jih dal drugim aplikacijam (pokaže samo datum). Rešitev: v intervals.icu poveži uro NEPOSREDNO — Settings → okence Garmin Connect → Connect. Od takrat vsaka nova vožnja pride sem sama.',
  }
  if (d.stravaStubs > 0) return {
    tone: 'info',
    title: `${d.stravaStubs} od ${d.total} voženj je s Strave`,
    text: 'Teh FORMAI ne vidi (Stravina pravila). Poveži uro z intervals.icu neposredno, da ne manjka nobena.',
  }
  if (d.total === 0 && d.known === 0) return {
    tone: 'warn',
    title: `intervals.icu v zadnjih ${d.days} dneh nima nobene vožnje`,
    text: 'Ura najbrž še ni povezana z intervals.icu. V intervals.icu: Settings → okence Garmin Connect → Connect (neposredno, ne prek Strave). Nove vožnje pridejo same; starejše uvoziš z »Import all Garmin data« (Garmin izvoz pripravi v nekaj dneh).',
  }
  if (d.total > 0 && d.usable === 0) return {
    tone: 'info',
    title: `intervals.icu je vrnil ${d.total} zapisov, a nobenega uporabnega`,
    text: 'Vsi so krajši od 5 minut ali brez vrste športa.',
  }
  return null
}
