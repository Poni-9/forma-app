import { plural } from '@/ui/format'

/**
 * Pošteno pojasnilo po uvozu iz intervals.icu, ko trener voženj ne dobi.
 * Najpogostejši razlog: intervals.icu je napolnjen s Strave. Takih aktivnosti po Stravinih pravilih ne sme dati
 * drugim aplikacijam — API vrne samo »stub« (datum, brez podatkov), zato jih FORMAI ne vidi.
 * Rešitev je neposredna povezava ure z intervals.icu. Čista funkcija — stanje je v state/store.
 */
export interface IcuDiag {
  at: string
  /** koliko dni nazaj smo spraševali */
  days: number
  /** koliko zapisov je API sploh vrnil */
  total: number
  /** koliko jih je uporabnih (uvoženih) */
  usable: number
  /** Stravini zapisi, ki jih API ne izda */
  stravaStubs: number
  /** koliko voženj iz intervals.icu FORMAI že ima od prej */
  known: number
  /** (v3.50) prekratki (vožnja ali tek pod 5 min, hoja pod 15 min ali 1 km) — ne uvozimo jih */
  short?: number
}

export const ICU_SETTINGS_URL = 'https://intervals.icu/settings'
/**
 * (v3.50) Ena pot do nastavitve v intervals.icu (stran je v angleščini) — prej trikrat drugače na istem zaslonu
 * (»Settings → Garmin → Connect«, »Settings → okence Garmin Connect«, »Nastavitve → Povezave → Garmin Connect«).
 */
export const icuConnectPath = (garmin = true): string => `Settings → Connections → ${garmin ? 'Garmin Connect' : 'tvoja ura'} → Connect`
export const icuUploadPath = (garmin = true): string => `Settings → Connections → ${garmin ? 'Garmin Connect' : 'tvoja ura'} → »Upload planned workouts«`

export interface IcuAdvice { tone: 'warn' | 'info'; title: string; text: string }

/** noBike (v3.50): načrt brez kolesa — »vadba«, ne »vožnja«. */
export function importDiagnosis(d: IcuDiag | null | undefined, o: { noBike?: boolean } = {}): IcuAdvice | null {
  if (!d) return null
  const W1 = o.noBike ? (['vadba', 'vadbi', 'vadbe', 'vadb'] as const) : (['vožnja', 'vožnji', 'vožnje', 'voženj'] as const)
  // rodilnik: od 1 vožnje, od 5 voženj
  const ofN = (n: number) => (n === 1 ? (o.noBike ? 'vadbe' : 'vožnje') : W1[3])
  if (d.stravaStubs > 0 && d.usable === 0) return {
    tone: 'warn',
    title: `${d.stravaStubs} ${plural(d.stravaStubs, W1)} ${plural(d.stravaStubs, ['je', 'sta', 'so', 'je'])} s Strave — FORMAI ${plural(d.stravaStubs, ['jo', 'ju', 'jih', 'jih'])} ne vidi`,
    // (v3.50) »jo« / »ju« / »jih« po številu (prej vedno »jih«)
    text: `intervals.icu ${plural(d.stravaStubs, ['jo', 'ju', 'jih', 'jih'])} je dobil s Strave, Stravina pravila pa mu prepovedujejo, da bi ${plural(d.stravaStubs, ['jo', 'ju', 'jih', 'jih'])} dal drugim aplikacijam (pokaže samo datum). Rešitev: v intervals.icu poveži uro NEPOSREDNO — ${icuConnectPath()}. Od takrat vsaka nova ${W1[0]} pride sem sama.`,
  }
  if (d.stravaStubs > 0) return {
    tone: 'info',
    title: `${d.stravaStubs} od ${d.total} ${ofN(d.total)} je s Strave`,
    text: 'Teh FORMAI ne vidi (Stravina pravila). Poveži uro z intervals.icu neposredno, da ne manjka nobena.',
  }
  if (d.total === 0 && d.known === 0) return {
    tone: 'warn',
    title: `intervals.icu v zadnjih ${d.days} dneh nima nobene ${o.noBike ? 'vadbe' : 'vožnje'}`,
    text: `Ura najbrž še ni povezana z intervals.icu. V intervals.icu: ${icuConnectPath()} (neposredno, ne prek Strave). Nove ${W1[2]} pridejo same; starejše uvoziš z »Import all Garmin data« (Garmin izvoz pripravi v nekaj dneh).`,
  }
  if (d.total > 0 && d.usable === 0) {
    const s = d.short ?? null
    return {
      tone: 'info',
      title: `intervals.icu je vrnil ${d.total} ${plural(d.total, ['zapis', 'zapisa', 'zapise', 'zapisov'])}, a nobenega uporabnega`,
      // (v3.50) pravo število prekratkih (prej vedno »Vsi so krajši od 5 minut ali brez vrste športa«)
      text: s == null ? 'Vsi so krajši od 5 minut ali brez vrste športa.'
        : s >= d.total ? 'Vsi so prekratki (vožnja ali tek pod 5 min, hoja pod 15 min ali 1 km) — takih ne uvažam.'
        // (v3.50) »5 je prekratkih« (prej »5 jih je prekratkih«), ostanek s številom (prej vedno »ostali so«)
        : s > 0 ? `${s} ${plural(s, ['je prekratek', 'sta prekratka', 'so prekratki', 'je prekratkih'])} (pod 5 min, hoja pod 15 min), ${d.total - s} ${plural(d.total - s, ['je', 'sta', 'so', 'je'])} brez vrste športa.`
        : 'Nobeden nima vrste športa, ki jo poznam.',
    }
  }
  return null
}
