import type { PlanDay, Profile } from '../types'
import { stepsFor, type Step } from '../training/workout'
import { noPower } from '../training/zones'

/**
 * TRENING NA URO: dan iz načrta → strukturiran trening v besedilni obliki intervals.icu
 * (https://forum.intervals.icu/t/workout-builder-syntax-quick-guide/123701). intervals.icu ga pošlje v Garmin Connect,
 * ura ga vodi po korakih: brez merilnika moči so cilji v % pražnega utripa (LTHR), z merilnikom v vatih.
 * Čiste funkcije — omrežje je v state/store.
 */

export interface IcuWorkout { uid: string; date: string; name: string; description: string; movingTime: number }
export interface IcuEventLite { id: number; uid?: string | null; external_id?: string | null; start_date_local?: string | null; name?: string | null; description?: string | null; moving_time?: number | null; category?: string | null }

export const UID_PREFIX = 'formai-'
export const uidFor = (date: string) => `${UID_PREFIX}${date}`

/** Cone utripa po LTHR — iste kot v aplikaciji (Z1 < 81 %, Z2 81–89, Z3 90–93, Z4 94–100, Z5 > 100). */
const HR: Record<string, string> = { Z1: '60-80% LTHR', Z2: '81-89% LTHR', Z3: '90-93% LTHR', Z4: '94-100% LTHR', Z5: '100-108% LTHR', max: '95-105% LTHR' }
/** Cone moči (Coggan) v % FTP. */
const PW: Record<string, string> = { Z1: '45-55%', Z2: '56-75%', Z3: '76-90%', Z4: '91-105%', Z5: '106-120%', max: '100-110%' }

function targetOf(s: Step, day: PlanDay, p: Profile): string {
  const hr = noPower(p) || !p.ftp
  if (!hr && s.kind === 'delo' && s.sets && day.target) return `${day.target.lo}-${day.target.hi}w`
  const z = s.z || (s.kind === 'delo' ? 'Z2' : 'Z1')
  return (hr ? HR : PW)[z]!
}

export function durText(sec: number): string {
  const m = Math.floor(sec / 60), r = sec % 60
  if (!m) return `${r}s`
  return r ? `${m}m${String(r).padStart(2, '0')}` : `${m}m`
}

/** Besedilo koraka brez vsega, kar bi razčlenjevalnik intervals.icu vzel za cono, čas ali cilj (Z2, 4 × 4 min, %, W). */
const clean = (t: string) => t.replace(/\bZ\d\b|\d+(?:[.,]\d+)?\s*(?:min|m|s|%|w)?\b|[×]|[—–]/gi, ' ').replace(/\s+/g, ' ').trim()
const cap = (t: string) => t.charAt(0).toUpperCase() + t.slice(1)
const cue = (s: Step) => s.kind === 'ogrevanje' ? 'Ogrevanje' : s.kind === 'iztek' ? 'Iztek' : s.kind === 'test' ? 'Test' : cap(clean(s.label.replace(/\s*\d+\/\d+$/, '')) || (s.kind === 'lahko' ? 'Lahko' : 'Vožnja'))

/** Dan iz načrta kot trening za uro; null za počitek, moč, tek, dirko. */
export function icuWorkout(day: PlanDay, p: Profile): IcuWorkout | null {
  if (day.kind !== 'kolo' && day.kind !== 'test') return null
  if (day.role === 'dirka') return null
  const steps = stepsFor(day, p)
  if (!steps.length) return null
  const lines: string[] = []
  let total = 0
  for (let i = 0; i < steps.length; i++) {
    const s = steps[i]!
    // ponovitve: delo (1/N) + lahko → blok »Nx« z delom in odmorom (zadnji odmor se zlije v iztek)
    if (s.kind === 'delo' && s.sets && s.sets > 1 && s.set === 1 && steps[i + 1]?.kind === 'lahko') {
      const rest = steps[i + 1]!
      if (lines.length) lines.push('')
      lines.push(`${cue(s)} ${s.sets}x`)
      lines.push(`- ${durText(s.sec)} ${targetOf(s, day, p)}`)
      lines.push(`- ${cue(rest)} ${durText(rest.sec)} ${targetOf(rest, day, p)}`)
      total += s.sets * (s.sec + rest.sec)
      while (i + 1 < steps.length && (steps[i + 1]!.kind === 'delo' || (steps[i + 1]!.kind === 'lahko' && steps[i + 2]?.kind === 'delo'))) i++
      continue
    }
    if (!s.sec) continue
    if (lines.length && (s.kind === 'iztek' || steps[i - 1]?.kind === 'ogrevanje')) lines.push('')
    lines.push(`- ${cue(s)} ${durText(s.sec)} ${targetOf(s, day, p)}`)
    total += s.sec
  }
  return { uid: uidFor(day.date), date: day.date, name: day.title, description: lines.join('\n').replace(/\n{3,}/g, '\n\n').trim(), movingTime: total }
}

const norm = (s: string | null | undefined) => (s || '').replace(/\s+/g, ' ').trim().toLowerCase()

/** Naš ključ dogodka (uid ali external_id, oboje formai-<datum>). */
const keyOf = (e: IcuEventLite) => [e.uid, e.external_id].find(k => (k || '').startsWith(UID_PREFIX)) || null

/** Kaj ustvariti, kaj posodobiti (po id) in kaj pobrisati, da koledar intervals.icu ustreza načrtu — samo naši dogodki (formai-…). */
export function workoutDiff(desired: readonly IcuWorkout[], existing: readonly IcuEventLite[]): { create: IcuWorkout[]; update: { id: number; w: IcuWorkout }[]; remove: number[] } {
  const ours = existing.map(e => ({ e, k: keyOf(e) })).filter(x => x.k) as { e: IcuEventLite; k: string }[]
  const byKey = new Map<string, IcuEventLite>()
  const remove: number[] = []
  for (const { e, k } of ours) { if (byKey.has(k)) remove.push(e.id); else byKey.set(k, e) }   // dvojnik istega dne → stran
  const want = new Set(desired.map(d => d.uid))
  const create: IcuWorkout[] = [], update: { id: number; w: IcuWorkout }[] = []
  for (const d of desired) {
    const e = byKey.get(d.uid)
    if (!e) { create.push(d); continue }
    if (norm(e.name) !== norm(d.name) || norm(e.description) !== norm(d.description) || Math.abs((e.moving_time || 0) - d.movingTime) > 60) update.push({ id: e.id, w: d })
  }
  for (const [k, e] of byKey) if (!want.has(k)) remove.push(e.id)
  return { create, update, remove }
}
