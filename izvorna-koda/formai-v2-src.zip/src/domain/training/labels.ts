import type { PlanKind } from '../types'
/** Oznake brez React-a, da jih lahko uporabijo tudi domenski moduli (ics, obvestila). */
export function kindLabelPlain(k: PlanKind): string {
  return ({ kolo: 'Kolo', tek: 'Tek', pohod: 'Hoja', moc: 'Moč', pocitek: 'Počitek', test: 'Test' })[k]
}
