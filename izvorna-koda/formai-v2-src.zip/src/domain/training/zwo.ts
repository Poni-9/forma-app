import type { PlanDay, Profile } from '../types'
import { stepsFor, type Step } from './workout'
import { lthrOf } from './load'

/**
 * IZVOZ ZA TRENAŽER (.zwo — Zwift in druge aplikacije, ki berejo ta zapis). Moč je delež FTP (1,0 = FTP), zato trening
 * na trenažerju sledi FTP-ju, ki ga ima aplikacija za trenažer. Iz istih korakov kot izvajalnik in ura:
 * ogrevanje in iztek kot rampa, ponovitve kot IntervalsT, test in šprint »vse, kar gre« brez ERG (FreeRide).
 */
const MID: Record<string, number> = { Z1: 0.5, Z2: 0.65, Z3: 0.83, Z4: 0.98, Z5: 1.13 }

const f2 = (x: number) => String(Math.round(x * 100) / 100)
const esc = (t: string) => t.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')

/** Delež FTP za korak (iz opisa seje, cilja dneva ali cone). null = brez ERG (test, šprint). */
export function powerOf(s: Step, day: Pick<PlanDay, 'target'>, p: Pick<Profile, 'ftp'>): number | null {
  if (s.kind === 'test' || s.z === 'max') return null
  if (s.ftpShare) return (s.ftpShare[0] + s.ftpShare[1]) / 2
  if (s.kind === 'delo' && s.sets && day.target && p.ftp) return (day.target.lo + day.target.hi) / 2 / p.ftp
  return MID[s.z || (s.kind === 'delo' ? 'Z2' : 'Z1')] ?? 0.6
}

function txt(s: Step): string {
  const t = [s.label, s.target].filter(Boolean).join(' · ')
  return t ? `<textevent timeoffset="0" message="${esc(t.slice(0, 80))}"/>` : ''
}

/** .zwo za dan načrta (kolo ali test); null za počitek, moč, tek in dirko. */
export function zwoFor(day: PlanDay, p: Profile): { name: string; xml: string } | null {
  if ((day.kind !== 'kolo' && day.kind !== 'test') || day.role === 'dirka') return null
  const steps = stepsFor(day, p).filter(s => s.sec > 0)
  if (!steps.length) return null
  const out: string[] = []
  for (let i = 0; i < steps.length; i++) {
    const s = steps[i]!
    // ponovitve: delo + odmor z enakimi časi in močjo → en blok IntervalsT
    if (s.kind === 'delo' && (s.sets ?? 0) > 1 && steps[i + 1]?.kind === 'lahko') {
      const on = s, off = steps[i + 1]!
      const pOn = powerOf(on, day, p), pOff = powerOf(off, day, p)
      let n = 1, j = i + 2
      while (steps[j]?.kind === 'delo' && steps[j + 1]?.kind === 'lahko' && steps[j]!.sec === on.sec && steps[j + 1]!.sec === off.sec && powerOf(steps[j]!, day, p) === pOn && steps[j]!.group === on.group) { n++; j += 2 }
      if (n > 1 && pOn != null && pOff != null) {
        out.push(`    <IntervalsT Repeat="${n}" OnDuration="${on.sec}" OffDuration="${off.sec}" OnPower="${f2(pOn)}" OffPower="${f2(pOff)}">${txt(on)}</IntervalsT>`)
        i = j - 1
        continue
      }
    }
    const pw = powerOf(s, day, p)
    if (pw == null) { out.push(`    <FreeRide Duration="${s.sec}" FlatRoad="1">${txt(s)}</FreeRide>`); continue }
    if (s.kind === 'ogrevanje') { out.push(`    <Warmup Duration="${s.sec}" PowerLow="0.45" PowerHigh="${f2(Math.max(0.55, Math.min(0.75, pw)))}">${txt(s)}</Warmup>`); continue }
    if (s.kind === 'iztek') { out.push(`    <Cooldown Duration="${s.sec}" PowerLow="${f2(Math.max(0.5, Math.min(0.65, pw)))}" PowerHigh="0.4">${txt(s)}</Cooldown>`); continue }
    out.push(`    <SteadyState Duration="${s.sec}" Power="${f2(pw)}">${txt(s)}</SteadyState>`)
  }
  const desc = [day.desc, day.why].filter(Boolean).join(' ').slice(0, 600)
  const xml = [
    '<workout_file>',
    '  <author>FORMAI</author>',
    `  <name>${esc(day.title)}</name>`,
    `  <description>${esc(desc)}</description>`,
    '  <sportType>bike</sportType>',
    '  <tags><tag name="FORMAI"/></tags>',
    '  <workout>',
    ...out,
    '  </workout>',
    '</workout_file>',
    '',
  ].join('\n')
  const slug = day.title.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'trening'
  return { name: `formai-${day.date}-${slug}.zwo`, xml }
}

/* ---------- tvoje cone ---------- */
export interface ZoneRow { key: string; name: string; range: string }

/** Cone utripa po pražnem utripu (kot v intervals.icu in načrtu): Z1 < 81 %, Z2 81–89, Z3 90–93, Z4 94–100, Z5 > 100. */
export function hrZoneRows(p: Pick<Profile, 'lthr' | 'maxHr' | 'restHr'>): { lthr: number; estimated: boolean; rows: ZoneRow[] } | null {
  const L = lthrOf(p)
  if (!L) return null
  const r = (x: number) => Math.round(L * x)
  return {
    lthr: L, estimated: !p.lthr,
    rows: [
      { key: 'Z1', name: 'Regeneracija', range: `pod ${r(0.81)}` },
      { key: 'Z2', name: 'Vzdržljivost', range: `${r(0.81)}–${r(0.89)}` },
      { key: 'Z3', name: 'Tempo', range: `${r(0.9)}–${r(0.93)}` },
      { key: 'Z4', name: 'Prag', range: `${r(0.94)}–${L}` },
      { key: 'Z5', name: 'VO2max', range: `nad ${L}` },
    ],
  }
}

/** Cone moči (Coggan) iz FTP: Z1–Z7 v vatih. */
export function powerZoneRows(p: Pick<Profile, 'ftp'>): ZoneRow[] | null {
  if (!p.ftp) return null
  const f = p.ftp, w = (x: number) => Math.round(f * x)
  return [
    { key: 'Z1', name: 'Aktivni počitek', range: `pod ${w(0.56)}` },
    { key: 'Z2', name: 'Vzdržljivost', range: `${w(0.56)}–${w(0.75)}` },
    { key: 'Z3', name: 'Tempo', range: `${w(0.76)}–${w(0.9)}` },
    { key: 'Z4', name: 'Prag', range: `${w(0.91)}–${w(1.05)}` },
    { key: 'Z5', name: 'VO2max', range: `${w(1.06)}–${w(1.2)}` },
    { key: 'Z6', name: 'Anaerobno', range: `${w(1.21)}–${w(1.5)}` },
    { key: 'Z7', name: 'Šprint', range: `nad ${w(1.5)}` },
  ]
}
