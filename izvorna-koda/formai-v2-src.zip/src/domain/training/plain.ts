import type { PlanDay } from '../types'
import type { WeekCtx } from './planner'

/**
 * TEDEN Z BESEDAMI (Plan, vrh): kaj je ta teden in zakaj — brez »Osnova, teden 2/38, blok 3 + 1, 80/20«.
 * Številke ostanejo spodaj (Opravljeno, Pot do dirke).
 */
export function phaseLine(cx: Pick<WeekCtx, 'phase' | 'easy' | 'recovery' | 'offStage'> & Partial<Pick<WeekCtx, 'custom' | 'phaseDesc'>>): string {
  // načrt po meri: opis tedna v bloku (nov blok, rast, najtežji, lažji) — brez kolesarskih faz
  if (cx.custom) return cx.phaseDesc || ''
  if (cx.phase === 'prehod') return cx.offStage === 'pocitek' ? 'Off-season, počitek: kolo počiva, vse je po želji.' : cx.offStage === 'vrnitev' ? 'Off-season, vrnitev: lahke vožnje, da se navada vrne.' : 'Off-season: gibanje po občutku, brez intervalov in brez ure.'
  if (cx.easy) return 'Lahek začetek: lahke vožnje in kratki šprinti — telo se navadi na redne treninge.'
  if (cx.recovery && cx.phase !== 'dirka' && cx.phase !== 'tapering') return 'Razbremenilni teden: manj kot običajno — telo napreduje med počitkom.'
  switch (cx.phase) {
    case 'osnova': return 'Osnova: večinoma lahke vožnje — temelj, na katerem stoji vse naprej.'
    case 'gradnja': return 'Gradnja: dva težja treninga na teden dvigujeta moč, ostalo je lahko.'
    case 'specificno': return 'Specifično: treningi, ki so podobni tvoji dirki.'
    case 'tapering': return 'Pred dirko: manj vožnje, kratko in ostro — da boš na startu spočit.'
    case 'dirka': return 'Teden dirke: malo in kratko, da si na dan dirke svež.'
    case 'po': return 'Po cilju: lahko in po občutku.'
    default: return ''
  }
}

const n = (k: number, one: string, two: string, few: string, many: string) => `${k} ${k === 1 ? one : k === 2 ? two : k <= 4 ? few : many}`

/** »4 vožnje (1 ključna), 2 × moč« — kaj vse je v tednu (ključna = intervali, dolga, test ali tekma). */
export function weekCounts(items: readonly PlanDay[]): string {
  const act = items.filter(d => d.kind !== 'pocitek' && !d.optional)
  const bike = act.filter(d => d.kind === 'kolo' || d.kind === 'test')
  const key = bike.filter(d => d.role === 'kljucna' || d.role === 'dolga' || d.role === 'test' || d.role === 'dirka').length
  const moc = act.filter(d => d.kind === 'moc').length
  const hike = act.filter(d => d.kind === 'pohod').length
  const run = act.filter(d => d.kind === 'tek').length
  const parts: string[] = []
  if (bike.length) parts.push(`${n(bike.length, 'vožnja', 'vožnji', 'vožnje', 'voženj')}${key ? ` (${n(key, 'ključna', 'ključni', 'ključne', 'ključnih')})` : ''}`)
  if (hike) parts.push(`${hike} × hribi`)
  if (run) parts.push(`${run} × tek`)
  if (moc) parts.push(`${moc} × moč`)
  const opt = items.filter(d => d.optional && d.kind !== 'pocitek').length
  if (opt) parts.push(`${opt} po želji`)
  return parts.join(', ')
}

/**
 * NAPREDEK NA KRATKO (vrh zaslona Napredek): ali napreduješ — cilj, teža, doslednost v treh stavkih brez kratic.
 */
export function progressLines(o: {
  goal: { event: { name: string } | null; weeksToEvent: number | null; daysToEvent: number | null; ftp: number | null; wkg: number | null; expected: { wkg: number | null } | null; targetWkg: number | null }
  weight: { avg7: number; deltaWeek: number | null } | null
  done: number; planned: number
}): string[] {
  const f2 = (x: number) => x.toFixed(2).replace('.', ',')
  const f1 = (x: number) => x.toFixed(1).replace('.', ',')
  const out: string[] = []
  const g = o.goal
  if (g.event) {
    const left = g.daysToEvent != null && g.daysToEvent > 13 ? `${g.weeksToEvent} tednov` : g.daysToEvent ? `${g.daysToEvent} dni` : 'danes'
    if (!g.ftp || !g.wkg) out.push(`Do cilja (${g.event.name}) še ${left}. Moči (FTP) še ne poznam — po testu pokažem, ali si na poti.`)
    else {
      const d = g.expected?.wkg != null ? g.wkg - g.expected.wkg : null
      const st = d == null ? '' : d >= 0.03 ? ' — pred načrtom' : d <= -0.08 ? ` — malo za načrtom (po načrtu bi bil pri ${f2(g.expected!.wkg!)})` : ' — po načrtu'
      out.push(`Do cilja (${g.event.name}) še ${left}. Moč na kilogram ${f2(g.wkg)} W/kg${g.targetWkg ? `, cilj ${f2(g.targetWkg)}` : ''}${st}.`)
    }
  }
  if (o.weight) {
    const r = o.weight.deltaWeek
    out.push(`Teža ${f1(o.weight.avg7)} kg${r == null ? '' : r <= -0.75 ? ` — pada prehitro (${f1(r)} kg na teden), jej malo več` : r < -0.05 ? ` — pada (${f1(r)} kg na teden)` : r > 0.05 ? ` — gre gor (+${f1(r)} kg na teden)` : ' — stabilna'}.`)
  }
  if (o.planned) {
    const p = Math.round((o.done / o.planned) * 100)
    out.push(`Zadnje 4 tedne si naredil ${o.done} od ${o.planned} treningov po načrtu (${p} %)${p >= 85 ? ' — odlično' : p >= 65 ? ' — dobro' : ' — doslednost je največja rezerva'}.`)
  }
  return out
}
