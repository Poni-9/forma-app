import type { Activity, PlanDay, PlanKind, Profile } from '../types'
import { sameKind, swapsPlanned, bestPlanMatch, isHardDay } from './plandays'
import { ACTIVITY_RANGE, SPORT_MAX_KMH } from '../ranges'
import { EXERCISES, exByName, exById, strengthMinutes, type ExDef } from './exercises'
import { exercisesIn } from '../coach/exmention'
import { minMinutes } from './workout'
import { addDays, titleNoDur } from './load'
import { inPause, PHOTO_WHY } from './pause'
import { sanitizeGaps } from '../ai/sanitize'

/**
 * (v3.50) TRENING S SLIKE — čista logika (brez AI in shrambe):
 * 1) posnetek opravljenega treninga → aktivnost, ki odkljuka dan načrta (isti šport ali vzdržljivost namesto vzdržljivosti);
 * 2) slika treninga (tabla, list, objava) → dan načrta z vajami ali koraki, ki jih vodena vadba (stepsFor) razume;
 * 3) slika sebe → 2–3 poudarki in kratka seja moči po želji.
 * Vse, kar pride od AI, se tu preveri: zunaj razpona → prazno polje za ročni popravek. Slike se nikjer ne shranijo.
 */

/** Meje za branje s slike (trajanje 5–480 min, do 15 vaj, ponovitve 1–100, kg 0–400). */
export const PHOTO_LIMITS = {
  min: [5, 480], ex: 15, reps: [1, 100], kg: [0, 400], sets: [1, 10], restS: [0, 600], holdS: [5, 600],
  workS: [5, 3600], offS: [0, 1800], n: [1, 60], blockMin: [1, 120],
} as const

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
const numOf = (v: unknown): number | null => {
  if (typeof v === 'number') return Number.isFinite(v) ? v : null
  if (typeof v !== 'string' || !v.trim()) return null
  const x = +v.trim().replace(',', '.')
  return Number.isFinite(x) ? x : null
}
/** Število v razponu (zaokroženo na `step`) ali null. */
export function inLim(v: unknown, [lo, hi]: readonly [number, number], step = 1): number | null {
  const x = numOf(v)
  if (x == null || x < lo || x > hi) return null
  return Math.round(x / step) * step
}
/** Kratko besedilo iz AI: brez oznak, ena vrstica, skozi sanitizeGaps. */
export function txtOf(v: unknown, max: number): string {
  const s = typeof v === 'string' ? v : typeof v === 'number' ? String(v) : ''
  return sanitizeGaps(s.replace(/[*_#`<>]/g, '').replace(/\s+/g, ' ').trim(), true).slice(0, max).trim()
}

/* ================= 1) posnetek opravljenega treninga ================= */

/** Trajanje posnetka (min) — strožje od ročnega vnosa: 5–480 min. */
export const DONE_MIN: readonly [number, number] = PHOTO_LIMITS.min

/**
 * Posnetek, prebran z AI: številke izven razpona (ročni vnos, trajanje 5–480 min) izpadejo — polje ostane prazno za
 * ročni popravek, nič napačnega se ne shrani. Hitrost se preračuna iz ostalih.
 */
export function cleanShot<T extends Activity>(a: T): T {
  const dur = inLim(a.durationMin, DONE_MIN)
  const dist = inLim(a.distKm, [ACTIVITY_RANGE.dist[0], ACTIVITY_RANGE.dist[1]], 0.1)
  const pos = (v: unknown, r: readonly [number, number, ...unknown[]]) => { const x = inLim(v, [r[0], r[1]]); return x != null && x > 0 ? x : null }
  const out: T = {
    ...a, durationMin: dur, distKm: dist != null && dist > 0 ? +dist.toFixed(1) : null,
    elevM: inLim(a.elevM, [ACTIVITY_RANGE.elev[0], ACTIVITY_RANGE.elev[1]]), avgHr: pos(a.avgHr, ACTIVITY_RANGE.hr), avgPower: pos(a.avgPower, ACTIVITY_RANGE.power), kcal: pos(a.kcal, ACTIVITY_RANGE.kcal),
  }
  out.speedKmh = out.distKm && out.durationMin ? +(out.distKm / (out.durationMin / 60)).toFixed(1) : null
  return out
}

/** (v3.51) vzpon na uro (m): več je napačno prebrana enota ali ničla */
export const SHOT_MAX_CLIMB_H = 2000
/**
 * Napake predogleda (sporočilo pod polji): trajanje je obvezno (5–480 min), ostalo po razponih ročnega vnosa.
 * (v3.51) Ob vsakem shranjevanju še razdalja in vzpon glede na čas — prej le ob branju in samo, ko je AI prebral
 * trajanje (0 min · 300 km → vpišeš 45 min → shranjen tek 300 km).
 */
export function shotErrors(a: Pick<Activity, 'durationMin' | 'distKm' | 'elevM' | 'avgHr' | 'avgPower' | 'kcal'> & Partial<Pick<Activity, 'sport'>>): Partial<Record<'min' | 'dist' | 'elev' | 'hr' | 'power' | 'kcal', string>> {
  const e: Partial<Record<'min' | 'dist' | 'elev' | 'hr' | 'power' | 'kcal', string>> = {}
  const bad = (v: number | null | undefined, lo: number, hi: number) => v != null && (!Number.isFinite(v) || v < lo || v > hi)
  if (a.durationMin == null) e.min = 'Vpiši trajanje.'
  else if (bad(a.durationMin, DONE_MIN[0], DONE_MIN[1])) e.min = `Trajanje: od ${DONE_MIN[0]} do ${DONE_MIN[1]} min.`
  for (const [k, v, r] of [['dist', a.distKm, ACTIVITY_RANGE.dist], ['elev', a.elevM, ACTIVITY_RANGE.elev], ['hr', a.avgHr, ACTIVITY_RANGE.hr], ['power', a.avgPower, ACTIVITY_RANGE.power], ['kcal', a.kcal, ACTIVITY_RANGE.kcal]] as const) {
    if (bad(v, r[0], r[1])) e[k] = `${r[3]}: od ${r[0]} do ${r[1] >= 10000 ? '10 000' : r[1]}${r[2] ? ` ${r[2]}` : ''}.`
  }
  const h = !e.min && a.durationMin ? a.durationMin / 60 : null
  // šport brez svoje meje (moč, plavanje, drugo): plavanje 8 km/h, sicer 70 km/h — »joga 45 min · 300 km« ni vadba
  const max = !a.sport ? undefined : SPORT_MAX_KMH[a.sport] ?? (a.sport === 'plavanje' ? 8 : 70)
  if (h && max && !e.dist && a.distKm && a.distKm / h > max) e.dist = `Razdalja ne gre s tem časom (${Math.round(a.distKm / h)} km/h) — popravi razdaljo ali trajanje.`
  if (h && !e.elev && a.elevM && a.elevM / h > SHOT_MAX_CLIMB_H) e.elev = `Vzpon ne gre s tem časom (${Math.round(a.elevM / h)} m na uro) — popravi vzpon ali trajanje.`
  return e
}

/**
 * Dnevi, ki jih posnetek lahko odkljuka: zadnjih `back` dni do danes, trening (ne počitek), še brez prave vadbe
 * (»Opravil« brez ure se zamenja — zapis iz načrta odpade, nič se ne šteje dvakrat). Najnovejši prvi, obvezni pred neobveznimi.
 */
export function doneDayOptions(plan: readonly PlanDay[], today: string, back = 7): PlanDay[] {
  return plan.filter(d => d.date <= today && d.date >= addDays(today, -back) && d.kind !== 'pocitek' && !d.done?.activityId)
    .sort((a, b) => b.date.localeCompare(a.date) || (a.optional ? 1 : 0) - (b.optional ? 1 : 0))
}

type ActKey = Pick<Activity, 'sport' | 'durationMin' | 'date'> & Partial<Pick<Activity, 'elapsedMin' | 'distKm' | 'speedKmh'>>
/**
 * Ali vadba šteje za ta dan: ista vrsta (kolo ↔ kolo ali test, moč ↔ moč, tek ↔ tek) ali vzdržljivost namesto vzdržljivosti
 * (hribi namesto kolesa) po istem pravilu kot zapis iz načrta — vsaj 40 % načrtovanega trajanja (swapsPlanned).
 */
export function fitsDay(a: ActKey, d: Pick<PlanDay, 'kind' | 'durationMin'>): boolean {
  return d.kind !== 'pocitek' && (sameKind(a, d) || swapsPlanned(a, d))
}

/** (v3.51) Dan tekme ali testa — posnetek ga samodejno ne odkljuka (izbereš ga sam v »Dan v načrtu«). */
export const raceLike = (d: Pick<PlanDay, 'kind' | 'role' | 'raceId'>): boolean => !!d.raceId || d.role === 'dirka' || d.role === 'test' || d.kind === 'test'
/** (v3.51) vožnja na trenažerju ali v aplikaciji (Zwift, Rouvy …) — ni zunanja tekma */
const VIRTUAL = /zwift|watopia|rouvy|mywhoosh|whoosh|trainerroad|fulgaz|bkool|virtual|trenaž|sobno kolo|indoor/i
/**
 * (v3.51) Tekma ali test z vstopa na tem dnevu (kartica na Danes): samo ista vrsta, ne trenažer, trajanje ±30 %.
 * Prej je posnetek katere koli vožnje (Zwift 62 min) odkljukal »Kronometer Vodice« (30 min).
 */
function plausibleRace(a: ActKey & { name?: string | null; trainer?: boolean | null }, d: PlanDay): boolean {
  if (!sameKind(a, d) || a.trainer || VIRTUAL.test(a.name || '')) return false
  const m = a.durationMin, plan = d.durationMin
  return !m || !plan || Math.abs(m - plan) <= 0.3 * plan
}

/**
 * Kateri dan odkljukati: izbrani (vstop z Danes ali »Včeraj … si ga naredil?«), če mu vadba ustreza; sicer dan istega
 * datuma iste vrste (bestPlanMatch: obvezni, najbližje trajanje). null = dodatna vadba.
 * (v3.51) Tekma in test samo z vstopa na tem dnevu in ko se vadba ujema (plausibleRace); vzdržljivostni nadomestek
 * (hribi namesto kolesa) samo z vstopa na tem dnevu — drugače ju izbereš sam (A03, F16, H01).
 */
export function pickDoneDay(a: ActKey & { name?: string | null; trainer?: boolean | null }, plan: readonly PlanDay[], today: string, preferId?: string | null): PlanDay | null {
  const opts = doneDayOptions(plan, today)
  const pref = preferId ? opts.find(d => d.id === preferId) : undefined
  if (pref && fitsDay(a, pref) && (!raceLike(pref) || plausibleRace(a, pref))) return pref
  const same = opts.filter(d => d.date === a.date && !raceLike(d))
  return bestPlanMatch(a, same) ?? null
}

/* ================= 2) trening s slike → dan načrta ================= */

export type PhotoKind = 'moc' | 'kolo' | 'tek' | 'pohod'
export interface PhotoEx {
  name: string
  /** prazno (null / '') = neveljavno ali ga ni na sliki — popraviš ročno */
  sets: number | null
  /** »10«, »8–12« ali »30 s« (vaja na čas) */
  reps: string
  kg: number | null
  /** pavza med serijami (s) */
  rest: number | null
  /** vaja iz knjižnice (slika, figura, tehnika) */
  lib: string | null
}
export interface PhotoBlock {
  kind: 'ogrevanje' | 'ponovitve' | 'enakomerno' | 'iztek'
  /** trajanje (ogrevanje, enakomerno, iztek) */
  min: number | null
  /** ponovitve × delo / odmor */
  n: number | null
  workS: number | null
  restS: number | null
  /** intenzivnost v obliki, ki jo vodena vadba razume: »RPE 8«, »250–270 W«, »90–95 % FTP«, »tempo«, »šprint — vse, kar gre« */
  at: string
}
export interface PhotoWorkout { kind: PhotoKind; title: string; minutes: number | null; exercises: PhotoEx[]; blocks: PhotoBlock[]; note: string }

/** Angleška imena z table in objav → vaja iz knjižnice (bolj določena prva). */
const EN: readonly [RegExp, string][] = [
  [/goblet/i, 'goblet'], [/bulgarian|split squat/i, 'bolgarski'], [/(back|front|barbell|bb)\s*squat/i, 'pocep-p'], [/squat/i, 'pocep'],
  [/(barbell|bb)\s*(romanian|rdl)|romanian deadlift.*barbell/i, 'rdl-p'], [/romanian|\brdl\b|stiff[- ]leg/i, 'rdl-r'], [/deadlift/i, 'mrtvi'],
  // (v3.50) dipi pred »bench« (»Bench dips« ni potisk na klopi), poševna klop samo s potiskom (»Incline push-ups« so sklece)
  [/\bdips?\b/i, 'dipi'], [/incline\s*(?:db|dumbbell|barbell|bb)?\s*(?:bench\s*)?press|incline\s*bench/i, 'incline-r'], [/bench/i, 'bench'], [/push[- ]?ups?|press[- ]?ups?/i, 'sklece'],
  [/pull[- ]?ups?|chin[- ]?ups?/i, 'zgibi'], [/pull[- ]?down/i, 'pulldown'], [/(seated|cable)\s*row/i, 'kabel-v'],
  // (v3.50) ergometer samo za veslanje na napravi (prej »Upright row«, »Inverted row« → veslanje na ergometru)
  [/(bent[- ]?over|barbell)\s*row/i, 'veslanje-p'], [/(dumbbell|db|one[- ]arm)\s*row/i, 'veslanje-r'], [/\b(rowing|rower|erg)\b|concept\s*2|^row(\s+\d|$)/i, 'veslo'],
  [/(dumbbell|db)\s*(shoulder|overhead)\s*press/i, 'nadglavo-r'], [/overhead press|military press|\bohp\b|shoulder press/i, 'ohp'],
  // (v3.50) upogib kolen pred upogibom za biceps (prej »Leg curl« → upogib za biceps)
  [/lateral raise/i, 'odrocenje'], [/face ?pulls?/i, 'facepull'], [/(leg|hamstring|lying)\s*curls?/i, 'leg-curl'], [/(barbell|bb)\s*curl/i, 'biceps-p'], [/curls?\b/i, 'biceps-r'],
  [/push[- ]?downs?/i, 'triceps-k'], [/triceps|skull/i, 'triceps-r'], [/lunges?/i, 'izpadni'], [/step[- ]?ups?/i, 'stopanje-r'],
  [/hip thrusts?/i, 'hip-p'], [/glute bridge|hip bridge/i, 'most'], [/side plank/i, 'stranska'], [/plank/i, 'deska'], [/dead ?bugs?/i, 'deadbug'],
  // (v3.50) zamah samo z utežjo (»Leg swings« je razgibavanje nog, ne zamah z utežjo)
  [/mountain climbers?/i, 'plezalec'], [/burpees?/i, 'burpee'], [/jump(ing)? rope|double[- ]unders?|skipping/i, 'krozni'], [/(kettlebell|\bkb|russian)\s*swings?|^swings?$/i, 'zamah'],
  [/calf raises?/i, 'prsti'], [/leg press/i, 'presa'], [/leg extension/i, 'leg-ext'], [/russian twists?/i, 'zasuki-r'],
  [/bicycle crunch/i, 'kolesarcki'], [/hanging (knee|leg) raises?|knees? to (chest|elbows?)/i, 'kolena-vis'], [/leg raises?/i, 'dvig-nog'],
  [/superman/i, 'superman'], [/back extension|hyperextension/i, 'hiper'], [/ab ?wheel|roll[- ]?outs?/i, 'valjcek'], [/pallof/i, 'pallof'],
  [/hollow (hold|body)/i, 'coln'], [/pec ?deck|chest fly|\bfl(y|ies)\b/i, 'metuljcek'],
  // (v3.51) CrossFit s table
  [/wall ?balls?/i, 'wallball'], [/thrusters?/i, 'thruster'], [/box ?jumps?/i, 'boxjump'],
]
/**
 * Vaja iz knjižnice za ime s slike: točno ime, slovensko ime v katerem koli sklonu (»počepi s palico«, »mrtvega dviga« —
 * exercisesIn), angleško ime s table (»Back squat«, »Burpees«). null = vaje ni v knjižnici (ime ostane, brez slike).
 */
export function matchExercise(name: string): ExDef | null {
  const n = String(name || '').trim()
  if (!n) return null
  const exact = exByName(n)
  if (exact) return exact
  const sl = exercisesIn(n, 1)[0]
  if (sl) return sl
  // (v3.50) vaje, ki jih knjižnica nima, pa so podobne drugi (nordijski upogib ni upogib kolen na napravi): ime ostane
  if (/nordic/i.test(n)) return null
  const en = EN.find(([rx]) => rx.test(n))
  return en ? exById(en[1]) ?? null : null
}

/** Ponovitve: število 1–100, razpon »8–12« ali vaja na čas (5–600 s); drugo → '' (vpišeš ročno). */
export function repsOf(reps: unknown, sec?: unknown): string {
  const s = inLim(sec, PHOTO_LIMITS.holdS)
  if (s != null) return `${s} s`
  const t = typeof reps === 'string' ? reps.trim() : ''
  const timed = /^(\d+)\s*(s|sek\w*)$/i.exec(t)
  if (timed) { const x = inLim(timed[1], PHOTO_LIMITS.holdS); return x != null ? `${x} s` : '' }
  const rg = /^(\d+)\s*[–-]\s*(\d+)$/.exec(t)
  if (rg) { const a = inLim(rg[1], PHOTO_LIMITS.reps), b = inLim(rg[2], PHOTO_LIMITS.reps); return a != null && b != null && a < b ? `${a}–${b}` : '' }
  const n = inLim(typeof reps === 'number' ? reps : t, PHOTO_LIMITS.reps)
  return n != null ? String(n) : ''
}

/** odstotek utripa: HRmax, max HR, MHR, FCmax, HFmax, »maks. utripa«, »srčnega utripa« */
const HR_PCT = /hr\s*max|max\.?\s*hr|\bhr\b|\bmhr\b|fc\s*max|hf\s*max|utrip|srčn|\bbpm\b|heart/i
/** Intenzivnost ponovitev v obliki, ki jo razume vodena vadba (workout.ts intensity): RPE, vati, % FTP, tempo, šprint. */
export function atOf(v: unknown): string {
  const s = typeof v === 'string' ? v.trim() : typeof v === 'number' ? String(v) : ''
  if (!s) return ''
  const z = /^z\s*([1-5])$/i.exec(s)
  if (z) return ({ 1: 'zelo lahko', 2: 'lahko', 3: 'RPE 7', 4: 'RPE 8', 5: 'RPE 9' } as Record<string, string>)[z[1]!]!
  const rpe = /rpe\s*(\d{1,2})/i.exec(s)
  if (rpe) { const r = inLim(rpe[1], [1, 10]); return r != null ? `RPE ${r}` : '' }
  const w = /(\d{2,4})\s*(?:[–-]\s*(\d{2,4}))?\s*w\b/i.exec(s)
  if (w) { const a = inLim(w[1], [50, 2000]), b = w[2] ? inLim(w[2], [50, 2000]) : a; return a != null && b != null && a <= b ? (a === b ? `${a}–${a} W` : `${a}–${b} W`) : '' }
  const pc = /(\d{2,3})\s*(?:[–-]\s*(\d{2,3}))?\s*%/.exec(s)
  // (v3.50) % maks. utripa ni % FTP (»90–95 % HRmax« je VO2max, ne prag): po občutku (RPE) iz sredine razpona
  if (pc && HR_PCT.test(s)) {
    const a = inLim(pc[1], [40, 100]), b = pc[2] ? inLim(pc[2], [40, 100]) : a
    if (a == null || b == null || a > b) return ''
    const m = (a + b) / 2
    return m >= 90 ? 'RPE 9' : m >= 85 ? 'RPE 8' : m >= 75 ? 'RPE 7' : 'lahko'
  }
  if (pc) { const a = inLim(pc[1], [40, 200]), b = pc[2] ? inLim(pc[2], [40, 200]) : a; return a != null && b != null && a <= b ? `${a}–${b} % FTP` : '' }
  if (/šprint|sprint|max|vse,? kar gre|all[- ]?out/i.test(s)) return 'šprint — vse, kar gre'
  if (/tempo|prag|threshold|sweet/i.test(s)) return 'tempo'
  if (/utrip\s*\d|\d+\s*bpm/i.test(s)) { const h = /(\d{2,3})\s*(?:[–-]\s*(\d{2,3}))?/.exec(s); const a = h ? inLim(h[1], [60, 230]) : null, b = h?.[2] ? inLim(h[2], [60, 230]) : a; return a != null && b != null ? `utrip ${a}–${b}` : '' }
  if (/hitr|fast|hard|težk/i.test(s)) return 'RPE 8'
  return ''
}

/** (v3.51) Kilogrami s table: število ali »20 lb« / »45 lbs« (× 0,4536, na 0,5 kg) — prej je »20 lb« izpadel. */
export function kgOf(v: unknown): number | null {
  const lb = typeof v === 'string' ? /^\s*(\d+(?:[.,]\d+)?)\s*(?:lbs?|funt\w*)\s*$/i.exec(v) : null
  return inLim(lb ? +lb[1]!.replace(',', '.') * 0.4536 : typeof v === 'string' ? v.replace(/\s*kg\s*$/i, '') : v, PHOTO_LIMITS.kg, 0.5)
}
/**
 * (v3.51) Šport s slike, ki ga načrt še ne zna (plavanje, veslanje s koraki, drugo): ime za sporočilo ali null.
 * Prej »Na sliki nisem našel treninga« — trening je bil najden, a ni podprt.
 */
export function unsupportedKind(out: unknown): string | null {
  if (!out || typeof out !== 'object') return null
  const k = String((out as Record<string, unknown>).vrsta ?? '').toLowerCase()
  return /^(plav|swim)/.test(k) ? 'Plavanja' : /^(vesl|row)/.test(k) ? 'Veslanja' : /^(drug|other|smu|ski)/.test(k) ? 'Tega športa' : null
}

/** Odgovor AI (JSON) → osnutek treninga; null, če na sliki ni nič uporabnega (prazno ali nesmiselno). */
export function draftFromOut(out: unknown): PhotoWorkout | null {
  if (!out || typeof out !== 'object') return null
  const o = out as Record<string, unknown>
  const k = String(o.vrsta ?? '').toLowerCase()
  const kind: PhotoKind = /^(kolo|bike|cycl|zwift|trena)/.test(k) ? 'kolo' : /^(tek|run)/.test(k) ? 'tek' : /^(pohod|hrib|hoja|hike|walk)/.test(k) ? 'pohod' : 'moc'
  const exercises: PhotoEx[] = (Array.isArray(o.vaje) ? o.vaje : []).filter(x => x && typeof x === 'object').map(x => {
    const e = x as Record<string, unknown>
    const raw = txtOf(e.ime, 60)
    const lib = matchExercise(raw)
    return { name: lib ? lib.name : raw, sets: inLim(e.serije, PHOTO_LIMITS.sets), reps: repsOf(e.ponovitve, e.cas_s), kg: kgOf(e.kg), rest: inLim(e.pavza_s, PHOTO_LIMITS.restS), lib: lib ? lib.id : null }
  }).filter(e => e.name).slice(0, PHOTO_LIMITS.ex)
  const blocks: PhotoBlock[] = (Array.isArray(o.koraki) ? o.koraki : []).filter(x => x && typeof x === 'object').map(x => {
    const b = x as Record<string, unknown>
    const t = String(b.tip ?? '').toLowerCase()
    const bk: PhotoBlock['kind'] = /ogrev|warm/.test(t) ? 'ogrevanje' : /iztek|ohlaj|cool/.test(t) ? 'iztek' : /ponov|interval|rep/.test(t) ? 'ponovitve' : 'enakomerno'
    return { kind: bk, min: inLim(b.min, PHOTO_LIMITS.blockMin), n: bk === 'ponovitve' ? inLim(b.ponovitve, PHOTO_LIMITS.n) : null, workS: bk === 'ponovitve' ? inLim(b.delo_s, PHOTO_LIMITS.workS) : null, restS: bk === 'ponovitve' ? inLim(b.odmor_s, PHOTO_LIMITS.offS) : null, at: atOf(b.intenzivnost) }
  }).filter(b => b.kind === 'ponovitve' ? b.n != null || b.workS != null : b.min != null).slice(0, 12)
  const minutes = inLim(o.minut, PHOTO_LIMITS.min)
  const cardio = kind !== 'moc'
  if (cardio ? !blocks.length && minutes == null : !exercises.length) return null
  const title = txtOf(o.naslov, 60) || (cardio ? ({ kolo: 'Kolo', tek: 'Tek', pohod: 'Hribi' } as const)[kind] : 'Moč') + ' s slike'
  return { kind, title, minutes, exercises: cardio ? [] : exercises, blocks: cardio ? blocks : [], note: txtOf(o.opomba, 160) }
}

/** »4 min«, »30 s«, »1 min 30 s« — tako, kot ga bere vodena vadba. */
export function fmtS(sec: number): string {
  const s = Math.max(1, Math.round(sec))
  if (s < 60) return `${s} s`
  return s % 60 === 0 ? `${s / 60} min` : `${Math.floor(s / 60)} min ${s % 60} s`
}
/** Odmor, ko ga na sliki ni: polovica dela, 30 s – 5 min (vidiš ga v predogledu in ga lahko spremeniš). */
export const defaultRest = (work: number): number => Math.max(30, Math.min(300, Math.round(work / 2 / 15) * 15))
const blockOk = (b: PhotoBlock) => b.kind !== 'ponovitve' || (b.n != null && b.workS != null)
const hardAt = (at: string) => !!at && !/^(zelo lahko|lahko)$/.test(at)
/** Bloki dela po vrsti (ponovitve in trd enakomeren del, npr. »20 min tempo«) z odmorom: zapisan, sicer privzet; enakomeren 3 min. */
function workBlocks(w: PhotoWorkout): { n: number; work: number; rest: number; at: string }[] {
  return w.blocks.flatMap(b => b.kind === 'ponovitve' && blockOk(b) ? [{ n: b.n!, work: b.workS!, rest: Math.max(10, b.restS ?? defaultRest(b.workS!)), at: b.at }]
    : b.kind === 'enakomerno' && b.min != null && hardAt(b.at) ? [{ n: 1, work: b.min * 60, rest: 180, at: b.at }] : [])
}
const atText = (at: string) => (!at ? '' : /^(RPE|utrip|\d)/.test(at) ? ` pri ${at}` : ` ${at}`)
const noDrills = (s: string) => s.replace(/×/g, 'x')

/** Napake osnutka (ne gre v načrt, dokler jih ne popraviš). */
export function draftErrors(w: PhotoWorkout): string[] {
  const e: string[] = []
  if (w.kind === 'moc') {
    if (!w.exercises.length) e.push('Dodaj vsaj eno vajo.')
    const bad = w.exercises.filter(x => !x.name.trim() || x.sets == null || !x.reps)
    if (bad.length) e.push(`Vpiši serije in ponovitve (1–100 ali sekunde): ${bad.map(x => x.name || 'vaja').join(', ')}.`)
    const kg = w.exercises.filter(x => x.kg != null && (x.kg < 0 || x.kg > PHOTO_LIMITS.kg[1]))
    if (kg.length) e.push('Kilogrami: od 0 do 400.')
  } else {
    if (w.blocks.some(b => !blockOk(b))) e.push('Pri ponovitvah vpiši število in trajanje dela.')
    if (!w.blocks.some(b => b.kind === 'ponovitve' || b.kind === 'enakomerno') && w.minutes == null) e.push('Vpiši trajanje.')
  }
  if (w.minutes != null && (w.minutes < PHOTO_LIMITS.min[0] || w.minutes > PHOTO_LIMITS.min[1])) e.push(`Trajanje: od ${PHOTO_LIMITS.min[0]} do ${PHOTO_LIMITS.min[1]} min.`)
  return e
}

/**
 * Opis kardio treninga v obliki, ki jo razbere vodena vadba (workout.ts): »10 min ogrevanja, nato 5 × (3 min pri RPE 8 /
 * 2 min lahko), nato 1 × 20 min tempo. 5 min iztek.« — z ogrevanjem je trening ključen (bloki takoj po ogrevanju).
 */
export function draftDesc(w: PhotoWorkout): string {
  const blocks = workBlocks(w)
  const wu = w.blocks.find(b => b.kind === 'ogrevanje')?.min ?? (blocks.length ? 10 : null)
  const cd = w.blocks.find(b => b.kind === 'iztek')?.min ?? (blocks.length ? 5 : null)
  // vsak blok z zapisanim odmorom (»N × (delo / odmor)«): vodena vadba ga razbere enako, odmor je tudi presledek do naslednjega
  const parts = blocks.map(b => `${b.n} × (${fmtS(b.work)}${atText(b.at)} / ${fmtS(b.rest)} lahko)`)
  const head = [wu ? `${wu} min ogrevanja` : '', ...parts].filter(Boolean)
  const easy = w.blocks.filter(b => b.kind === 'enakomerno' && b.min != null && !hardAt(b.at)).reduce((s, b) => s + b.min!, 0)
  // opomba s slike brez »×«, da je vodena vadba ne bere kot ponovitve
  const lines = [head.length ? `${head.join(', nato ')}.` : '', easy ? `${easy} min enakomerno, pogovorni tempo.` : '', cd ? `${cd} min iztek.` : '', w.note ? `S slike: ${noDrills(w.note)}` : '']
  return lines.filter(Boolean).join(' ').replace(/\.\./g, '.')
}

/** Trajanje (min) tako, kot ga izvede vodena vadba: ogrevanje, bloki z odmori, presledki med bloki, enakomerno, iztek. */
export function draftMinutes(w: PhotoWorkout): number {
  if (w.kind === 'moc') {
    const ex = planExercises(w)
    return Math.max(PHOTO_LIMITS.min[0], Math.min(PHOTO_LIMITS.min[1], w.minutes ?? (ex.length ? strengthMinutes(ex) : 30)))
  }
  const blocks = workBlocks(w)
  const wu = w.blocks.find(b => b.kind === 'ogrevanje')?.min ?? (blocks.length ? 10 : 0)
  const cd = w.blocks.find(b => b.kind === 'iztek')?.min ?? (blocks.length ? 5 : 0)
  let sec = (wu + cd) * 60
  blocks.forEach((b, i) => { sec += b.n * b.work + (b.n - 1) * b.rest + (i ? blocks[i - 1]!.rest : 0) })
  sec += w.blocks.filter(b => b.kind === 'enakomerno' && b.min != null && !hardAt(b.at)).reduce((s, b) => s + b.min! * 60, 0)
  const min = Math.max(Math.ceil(sec / 60), minMinutes({ title: w.title, desc: draftDesc(w) }) || 0, w.minutes ?? 0)
  return Math.max(10, Math.min(PHOTO_LIMITS.min[1], min))
}

/**
 * (v3.51) Trajanje v polju ≠ trajanje korakov ali vaj: kar gre v načrt, povej pod poljem (prej tiho — polje 50,
 * v načrtu 83 min; pri moči 40 min v načrtu, vodena vadba ~49). `use` = predlagana vrednost za polje.
 */
export function durationNote(w: PhotoWorkout): { text: string; use: number } | null {
  if (w.minutes == null || w.minutes < PHOTO_LIMITS.min[0]) return null
  if (w.kind === 'moc') {
    const ex = planExercises(w)
    const m = ex.length ? strengthMinutes(ex) : 0
    return m && m > w.minutes + 5 ? { text: `Vaje trajajo ~${m} min — v načrt gre ${w.minutes} min.`, use: m } : null
  }
  const m = draftMinutes(w)
  return m > w.minutes ? { text: `Koraki trajajo ${m} min — v načrt gre ${m} min.`, use: m } : null
}

/** Cona dneva iz prvega trdega bloka (vodena vadba po njej vodi glavni blok): RPE 9 / šprint → Z5, RPE 8 / vati → Z4, tempo → Z3. */
export function draftZone(w: PhotoWorkout, p?: Pick<Profile, 'ftp'> | null): 'Z2' | 'Z3' | 'Z4' | 'Z5' | null {
  if (w.kind === 'moc') return null
  const b = w.blocks.find(x => (x.kind === 'ponovitve' && blockOk(x)) || (x.kind === 'enakomerno' && hardAt(x.at)))
  if (!b) return 'Z2'
  const at = b.at
  const r = /RPE (\d+)/.exec(at)
  if (r) return +r[1]! >= 9 ? 'Z5' : +r[1]! >= 8 ? 'Z4' : 'Z3'
  if (/šprint/.test(at)) return 'Z5'
  if (/tempo/.test(at)) return 'Z3'
  const pc = /(\d+)–(\d+) % FTP/.exec(at), w2 = /(\d+)–(\d+) W/.exec(at)
  const share = pc ? (+pc[1]! + +pc[2]!) / 200 : w2 && p?.ftp ? (+w2[1]! + +w2[2]!) / 2 / p.ftp : null
  if (share != null) return share >= 1.06 ? 'Z5' : share >= 0.91 ? 'Z4' : share >= 0.76 ? 'Z3' : 'Z2'
  return b.kind === 'enakomerno' ? 'Z3' : 'Z4'
}

/** Vaje osnutka v obliki načrta (samo veljavne): ponovitve »10« ali »30 s«, kg in pavza, če sta. */
export function planExercises(w: PhotoWorkout): NonNullable<PlanDay['exercises']> {
  return w.exercises.filter(e => e.name.trim() && e.sets != null && e.reps).slice(0, PHOTO_LIMITS.ex).map(e => ({
    name: e.name.trim().slice(0, 60), sets: e.sets!, reps: e.reps, ...(e.kg != null && e.kg > 0 ? { kg: e.kg } : {}), ...(e.rest != null ? { rest: e.rest } : {}),
  }))
}

/** Osnutek → dan načrta (nov zapis; `placeWorkout` odloči, ali zamenja počitek ali izbran trening tistega dne). */
export function draftToPlanDay(w: PhotoWorkout, date: string, p?: Pick<Profile, 'ftp'> | null, now: string = new Date().toISOString()): PlanDay {
  const kind: PlanKind = w.kind
  const dur = draftMinutes(w)
  const zone = draftZone(w, p)
  const h = dur / 60
  const tss = kind === 'kolo' ? Math.round(h * (zone === 'Z5' ? 100 : zone === 'Z4' ? 85 : zone === 'Z3' ? 70 : 50)) : kind === 'tek' ? Math.round(h * 78) : kind === 'moc' ? Math.round(h * 60) : Math.round(h * 40)
  const exercises = kind === 'moc' ? planExercises(w) : undefined
  const rest = exercises?.length && exercises.every(e => e.rest != null) && new Set(exercises.map(e => e.rest)).size === 1 ? ` Med serijami ${exercises[0]!.rest} s.` : ''
  const desc = kind === 'moc' ? `${w.note ? `S slike: ${w.note}` : 'Trening s slike.'}${rest}`.trim() : draftDesc(w)
  return {
    id: uid(), date, kind, title: w.title || 'Trening s slike', desc, durationMin: dur, zone, tssTarget: tss,
    ...(exercises ? { exercises } : {}), role: kind === 'moc' ? 'moc' : null, optional: false, target: null, kcalBurn: null,
    why: PHOTO_WHY, source: 'ai', createdAt: now, updatedAt: now, done: null,
  }
}

/** Kaj je ta dan v načrtu in ni opravljeno — izbira »Namesto: …« (počitek se zamenja sam). */
export function replaceOptions(plan: readonly PlanDay[], date: string): PlanDay[] {
  // tekma ostane (dan tekme ni za zamenjavo)
  return plan.filter(d => d.date === date && !d.done && d.kind !== 'pocitek' && !d.raceId && d.role !== 'dirka')
}

/**
 * (v3.51) »Začni zdaj« na dan s tekmo, opravljenim ali trdim treningom (razen tistega, ki ga zamenja »Namesto«):
 * vprašanje pred dodajanjem — prej sta dva tapa dodala 40–71 min poleg tekme brez opozorila.
 */
export function startNowWarn(plan: readonly PlanDay[], date: string, replaceId?: string | null): string | null {
  const there = plan.filter(d => d.date === date && d.kind !== 'pocitek' && d.id !== replaceId)
  const race = there.find(d => !!d.raceId || d.role === 'dirka')
  if (race) return `Danes imaš tekmo »${titleNoDur(race.title, race.durationMin)}«. Res dodam še ta trening?`
  const hard = there.find(d => !!d.done || isHardDay(d))
  return hard ? `Danes imaš že ${hard.done ? 'opravljen' : 'trd'} trening »${titleNoDur(hard.title, hard.durationMin)}«. Res dodam še tega?` : null
}

/**
 * Kam gre trening s slike: počitek tega dne (ni bolezen) se zamenja, izbran neopravljen trening tudi (»Namesto«), sicer
 * nov zapis poleg. Opravljeno se NIKOLI ne prepiše. `prev` = neopravljeni zapisi tega dne pred spremembo (za »Razveljavi«).
 */
export function placeWorkout(plan: readonly PlanDay[], day: PlanDay, o: { replaceId?: string | null } = {}): { write: PlanDay; prev: PlanDay[]; replaced: PlanDay | null } {
  const there = plan.filter(d => d.date === day.date)
  const prev = there.filter(d => !d.done)
  const pick = o.replaceId ? replaceOptions(there, day.date).find(d => d.id === o.replaceId) : undefined
  const rest = there.find(d => d.kind === 'pocitek' && !d.done && !d.sickPrev && !d.raceId)
  const target = pick ?? rest ?? null
  if (!target) return { write: day, prev, replaced: null }
  return { write: { ...day, id: target.id, createdAt: target.createdAt }, prev, replaced: target }
}

/* ================= 3) slika sebe → predlog vaj ================= */

export type SelfArea = 'drza' | 'jedro' | 'noge' | 'ravnotezje' | 'zgornji'
export interface SelfAdvice { points: string[]; area: SelfArea; title: string; perWeek: number; minutes: number; exercises: NonNullable<PlanDay['exercises']>; note: string }

/** Besedilo, ki ga na sliki sebe ne pokažemo: videz, maščoba, teža, obljube in roki. */
export const SELF_BAN = /%|odstot|ma[sš][cč]ob|privla[cč]|privlač|lepot|\blep(a|o|e|ega|ši|ša)?\b|\bgrd|debel|\bsuh[aeoi]?\b|vitk|kilogram|\bkg\b|\bte[žz](a|e|o)\b|\bbmi\b|\bitm\b|videz|izgled|obljub|zagotov|\bv \d+ (dneh|tednih|mesecih)|do poletja|sramot|lepš|seksi|six[\s-]?pack|izklesa/i
/** Poudarki s slike: največ 3 kratki stavki, brez ocene videza, maščobe, teže, obljub in rokov. */
export function cleanPoints(xs: unknown): string[] {
  return (Array.isArray(xs) ? xs : []).map(x => txtOf(x, 160)).filter(x => x.length >= 8 && !SELF_BAN.test(x)).slice(0, 3)
}
/** Privzete vaje po področju (lastna teža, doma) — ko AI ne predlaga vaj iz knjižnice. */
export const SELF_DEFAULT: Record<SelfArea, { title: string; ex: NonNullable<PlanDay['exercises']> }> = {
  drza: { title: 'Hrbet in zadnje rame', ex: [{ name: 'Superman z vlekom', sets: 3, reps: '10' }, { name: 'Superman', sets: 3, reps: '10' }, { name: 'Deska', sets: 3, reps: '30 s' }] },
  jedro: { title: 'Jedro', ex: [{ name: 'Deska', sets: 3, reps: '30 s' }, { name: 'Stranska deska', sets: 2, reps: '20 s' }, { name: 'Dead bug', sets: 3, reps: '10' }] },
  noge: { title: 'Noge in zadnjica', ex: [{ name: 'Počep', sets: 3, reps: '12' }, { name: 'Izpadni koraki', sets: 3, reps: '10' }, { name: 'Dvig bokov leže', sets: 3, reps: '12' }] },
  ravnotezje: { title: 'Leva in desna stran', ex: [{ name: 'Dvig bokov na eni nogi', sets: 3, reps: '10' }, { name: 'Bolgarski počep', sets: 3, reps: '8' }, { name: 'Stranska deska', sets: 2, reps: '20 s' }] },
  zgornji: { title: 'Zgornji del', ex: [{ name: 'Sklece', sets: 3, reps: '8' }, { name: 'Superman z vlekom', sets: 3, reps: '10' }, { name: 'Dipi na stolu', sets: 3, reps: '8' }] },
}
const AREAS = new Set<string>(['drza', 'jedro', 'noge', 'ravnotezje', 'zgornji'])
/** Seznam imen vaj iz knjižnice (za poziv — AI naj izbira med njimi, da ima vodena vadba slike). */
export const LIB_NAMES = (): string => EXERCISES.map(e => e.name).join(', ')

/** Odgovor AI → predlog (null: na sliki ni bilo nič uporabnega). Vaje iz knjižnice, sicer privzete za področje. */
export function selfFromOut(out: unknown): SelfAdvice | null {
  if (!out || typeof out !== 'object') return null
  const o = out as Record<string, unknown>
  const points = cleanPoints(o.poudarki)
  const area: SelfArea = AREAS.has(String(o.podrocje)) ? (String(o.podrocje) as SelfArea) : 'drza'
  const pr = (o.predlog && typeof o.predlog === 'object' ? o.predlog : {}) as Record<string, unknown>
  const ex = (Array.isArray(pr.vaje) ? pr.vaje : []).filter(x => x && typeof x === 'object').map(x => {
    const e = x as Record<string, unknown>
    const lib = matchExercise(txtOf(e.ime, 60))
    // (v3.51) predlog je za doma: vaja na napravi v fitnesu (»Face pull na kablu«) izpade, privzete so z lastno težo
    return lib && lib.eq !== 'fitnes' ? { name: lib.name, sets: inLim(e.serije, [1, 5]) ?? 3, reps: repsOf(e.ponovitve, e.cas_s) || (lib.time ? '30 s' : '10') } : null
  }).filter((x): x is { name: string; sets: number; reps: string } => !!x)
  const uniq = ex.filter((e, i) => ex.findIndex(x => x.name === e.name) === i).slice(0, 5)
  const def = SELF_DEFAULT[area]
  const title = txtOf(pr.naslov, 50)
  const note = txtOf(o.opomba, 160)
  if (!points.length && !uniq.length) return note ? { points: [], area, title: def.title, perWeek: 2, minutes: 15, exercises: [], note } : null
  return {
    points, area, title: title && !SELF_BAN.test(title) ? title : def.title,
    perWeek: inLim(pr.krat_na_teden, [1, 3]) ?? 2, minutes: inLim(pr.minut, [10, 30], 5) ?? 15,
    exercises: uniq.length >= 2 ? uniq : def.ex, note: SELF_BAN.test(note) ? '' : note,
  }
}

/**
 * Seje predloga v načrt: naslednjih 7 dni od danes, `perWeek` dni vsaj dan narazen — najprej dnevi počitka, nato dnevi brez
 * trdega treninga in brez moči; ne med boleznijo ali premorom »Ta teden …«. Neobvezne (ne štejejo v realizacijo), kot »Jedro po želji«.
 */
export function selfSessions(s: SelfAdvice, plan: readonly PlanDay[], p: Pick<Profile, 'sick' | 'weekPause'>, today: string, now: string = new Date().toISOString()): PlanDay[] {
  const dates = Array.from({ length: 7 }, (_, i) => addDays(today, i))
  const sick = (d: string) => !!p.sick && d >= p.sick.from && d <= p.sick.to
  const ok = dates.filter(d => !sick(d) && !inPause(p, d) && !plan.some(x => x.date === d && (x.kind === 'moc' || isHardDay(x) || !!x.sickPrev || !!x.raceId || x.role === 'dirka')))
  const rank = (d: string) => (plan.some(x => x.date === d && x.kind !== 'pocitek') ? 1 : 0)
  const order = [...ok].sort((a, b) => rank(a) - rank(b) || a.localeCompare(b))
  const pick: string[] = []
  for (const d of order) {
    if (pick.length >= s.perWeek) break
    if (pick.some(x => Math.abs((Date.parse(x) - Date.parse(d)) / 86400000) < 2)) continue
    pick.push(d)
  }
  return pick.sort().map(date => ({
    id: uid(), date, kind: 'moc' as const, title: s.title, desc: `Predlog s tvoje slike (grob vtis, ne meritev). Po želji — ne šteje v realizacijo tedna.`,
    durationMin: s.minutes, zone: null, tssTarget: Math.round((s.minutes / 60) * 60), exercises: s.exercises, role: 'moc' as const, optional: true,
    why: s.points[0] ?? null, source: 'ai' as const, createdAt: now, updatedAt: now, done: null,
  }))
}
