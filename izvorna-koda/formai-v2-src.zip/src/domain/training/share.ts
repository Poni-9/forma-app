import type { PlanDay } from '../types'
import { addDays, fmtDur } from './load'

const DOW = ['ned', 'pon', 'tor', 'sre', 'čet', 'pet', 'sob']
const dow = (iso: string) => DOW[new Date(iso + 'T12:00:00Z').getUTCDay()] ?? ''
const dm = (iso: string) => `${+iso.slice(8, 10)}. ${+iso.slice(5, 7)}.`

/**
 * Teden kot besedilo za deljenje (trenerju, bratu, v skupino): en dan v vrstico, glavna seja + dodatne,
 * trajanje in cilj dela; na koncu vsota. Brez osebnih podatkov (ni imena, teže, kalorij).
 */
export function weekText(days: readonly PlanDay[], weekStart: string): string {
  const prio = (d: PlanDay) => (d.kind === 'pocitek' ? 9 : d.optional ? 5 : d.kind === 'moc' ? 2 : 0)
  const lines: string[] = [`FORMAI · teden ${dm(weekStart)} – ${dm(addDays(weekStart, 6))}`]
  let min = 0, tss = 0
  for (let i = 0; i < 7; i++) {
    const date = addDays(weekStart, i)
    const items = days.filter(d => d.date === date).sort((a, b) => prio(a) - prio(b))
    const main = items[0]
    const label = `${dow(date)} ${dm(date)}`
    if (!main || main.kind === 'pocitek') { lines.push(`${label}: počitek`); continue }
    const part = (d: PlanDay) => `${d.title}${d.durationMin ? ` · ${fmtDur(d.durationMin)}` : ''}${d.target ? ` · ${d.target.lo}–${d.target.hi} W` : ''}${d.optional ? ' (po želji)' : ''}${d.done ? ' ✓' : ''}`
    const extra = items.slice(1).filter(d => d.kind !== 'pocitek')
    lines.push(`${label}: ${part(main)}${extra.length ? ' + ' + extra.map(part).join(' + ') : ''}`)
    for (const d of items) if (!d.optional && d.kind !== 'pocitek') { min += d.durationMin || 0; tss += d.tssTarget || 0 }
  }
  lines.push(`Skupaj ${fmtDur(min)}${tss ? ` · ${tss} TSS` : ''}`)
  return lines.join('\n')
}
