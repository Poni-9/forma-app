import type { PlanDay, Profile } from '../types'
import { addDays, fmtDur } from './load'
import { workText } from './zones'
import { PAUSE_TITLE } from './pause'

const DOW = ['ned', 'pon', 'tor', 'sre', 'čet', 'pet', 'sob']
const dow = (iso: string) => DOW[new Date(iso + 'T12:00:00Z').getUTCDay()] ?? ''
const dm = (iso: string) => `${+iso.slice(8, 10)}. ${+iso.slice(5, 7)}.`

/**
 * Teden kot besedilo za deljenje (trenerju, bratu, v skupino): en dan v vrstico, glavna seja + dodatne,
 * trajanje in cilj dela; na koncu vsota. Brez osebnih podatkov (ni imena, teže, kalorij).
 * (v3.50) S profilom je cilj dela kot v načrtu: brez merilnika utrip ali RPE, ne vati (`workText`).
 */
export function weekText(days: readonly PlanDay[], weekStart: string, p?: Pick<Profile, 'ftp' | 'maxHr' | 'restHr' | 'lthr' | 'gear'> | null): string {
  const prio = (d: PlanDay) => (d.kind === 'pocitek' ? 9 : d.optional ? 5 : d.kind === 'moc' ? 2 : 0)
  const tgt = (d: PlanDay) => (p ? workText(p, d) : d.target ? `${d.target.lo}–${d.target.hi} W` : null)
  const lines: string[] = [`FORMAI · teden ${dm(weekStart)} – ${dm(addDays(weekStart, 6))}`]
  let min = 0, tss = 0, pause = 0
  for (let i = 0; i < 7; i++) {
    const date = addDays(weekStart, i)
    const items = days.filter(d => d.date === date).sort((a, b) => prio(a) - prio(b))
    const main = items[0]
    const label = `${dow(date)} ${dm(date)}`
    // (v3.51) dan premora »Ta teden …« je »premor«, ne »počitek« (prej 7 × »počitek« in »Skupaj —«)
    if (main?.kind === 'pocitek' && (main.title || '').startsWith(PAUSE_TITLE)) { pause++; lines.push(`${label}: premor`); continue }
    if (!main || main.kind === 'pocitek') { lines.push(`${label}: počitek`); continue }
    const part = (d: PlanDay) => { const t = tgt(d); return `${d.title}${d.durationMin ? ` · ${fmtDur(d.durationMin)}` : ''}${t ? ` · ${t}` : ''}${d.optional ? ' (po želji)' : ''}${d.done ? ' ✓' : ''}` }
    const extra = items.slice(1).filter(d => d.kind !== 'pocitek')
    lines.push(`${label}: ${part(main)}${extra.length ? ' + ' + extra.map(part).join(' + ') : ''}`)
    for (const d of items) if (!d.optional && d.kind !== 'pocitek') { min += d.durationMin || 0; tss += d.tssTarget || 0 }
  }
  lines.push(min ? `Skupaj ${fmtDur(min)}${tss ? ` · ${tss} TSS` : ''}` : pause ? 'Skupaj: premor — brez treningov.' : 'Skupaj 0 min')
  return lines.join('\n')
}

/**
 * Napredek tedna (Danes, Plan): seje opravljeno / načrtovano (brez počitka in »po želji«) in minute — opravljeno je
 * dejanski čas povezane vadbe, sicer čas iz vodene vadbe (`done.min`, delno shranjena — v3.48), sicer načrtovani;
 * načrtovano vse seje tedna.
 */
export function weekProgress(week: readonly PlanDay[], acts: readonly { id: string; durationMin?: number | null }[]): { done: number; total: number; minDone: number; minAll: number } {
  const active = week.filter(d => d.kind !== 'pocitek' && !d.optional)
  const doneDays = active.filter(d => d.done)
  const minDone = doneDays.reduce((s, d) => { const a = d.done?.activityId ? acts.find(x => x.id === d.done!.activityId) : null; return s + (a?.durationMin ? Math.round(a.durationMin) : d.done?.min ? Math.round(d.done.min) : d.durationMin || 0) }, 0)
  return { done: doneDays.length, total: active.length, minDone, minAll: active.reduce((s, d) => s + (d.durationMin || 0), 0) }
}
