import type { Activity, PlanDay, PlanKind, Profile, Sport } from '../types'
import { estimateTss, titleNoDur } from './load'
import { estimatePlanKcal, doneShare } from '../nutrition/energy'
import { swapsPlanned } from './plandays'
import { deriveFlags } from '../import/provenance'

/**
 * (v3.49) TRENING BREZ URE ŠTEJE. Ko označiš »Opravil« ali končaš vodeno vadbo brez ure, nastane zapis iz načrta
 * (vir 'plan', planDayId = dan načrta): minute iz vodene vadbe ali vpisane (»Krajše«), sicer načrtovane; TSS in kcal
 * sorazmerno z načrtom. Šteje v formo, ure tedna (načrt raste od resnice), Napredek in rekorde.
 * Dan nanj ne kaže (done.activityId ostane prazen) — »izmerjeno« ostane samo, kar je res izmerjeno (prehrana,
 * preverba vožnje, AI »vožnja danes«). Prava vadba istega dne in športa (ura, intervals.icu, Strava, datoteka,
 * ročni vnos) ga zamenja — nič se ne šteje dvakrat. Odznačitev ga pobriše.
 */

export const isStandIn = (a: Pick<Activity, 'planDayId'>): boolean => !!a.planDayId

/** Šport zapisa za vrsto dneva (test FTP je vožnja); počitek nima zapisa. */
export function sportOfKind(kind: PlanKind): Sport | null {
  return kind === 'kolo' || kind === 'test' ? 'kolo' : kind === 'tek' || kind === 'pohod' || kind === 'moc' ? kind : null
}

/** Koliko minut šteje opravljen dan: dejanske (vodena vadba, »Krajše«), sicer načrtovane. */
export function doneMinutes(d: Pick<PlanDay, 'durationMin' | 'done'>): number {
  const m = d.done?.min
  return m != null && m > 0 ? Math.round(m) : Math.max(0, Math.round(d.durationMin || 0))
}

/** kolo, tek, hribi — vzdržljivost; vadba ene vrste ta dan je bila lahko namesto druge (hribi namesto kolesa) */
const ENDURANCE = new Set<Sport>(['kolo', 'tek', 'pohod'])

/**
 * Prava vadba (ne zapis iz načrta, ne demo) tega dne, ki šteje namesto zapisa iz načrta: istega športa, ali
 * vzdržljivostna namesto vzdržljivostne (»Opravil« na kolesu, z ure pa hribi), če ni povezana z drugim dnem načrta
 * (`plan`, `dayId`) — tako se dan nikoli ne šteje dvakrat.
 * (v3.49) Druga vzdržljivostna vrsta zamenja zapis samo, če ustreza dnevu (vsaj 40 % načrtovanega trajanja, swapsPlanned):
 * 30-min tek ob 90-min vožnji brez ure je druga vadba — zapis kolesa ostane, forma in dnevni cilj vidita isto.
 * Brez dneva načrta (`plan` prazen) kot prej: vsaka vzdržljivostna.
 */
export function realOn(acts: readonly Activity[], date: string, sport: Sport, o: { plan?: readonly PlanDay[]; dayId?: string | null } = {}): Activity | null {
  const other = (a: Activity) => !!o.plan?.some(x => x.done?.activityId === a.id && x.id !== o.dayId)
  const day = o.dayId ? o.plan?.find(x => x.id === o.dayId) ?? null : null
  const swap = (a: Activity) => (day ? swapsPlanned(a, day) : ENDURANCE.has(a.sport) && ENDURANCE.has(sport)) && !other(a)
  return acts.find(a => a.date === date && !isStandIn(a) && a.source !== 'demo' && (a.sport === sport || swap(a))) ?? null
}

/** Id zapisa: isti na vseh napravah (dan + čas kljukice) — dopolnitev starih kljukic na dveh napravah ga ne podvoji. */
export const standInId = (d: Pick<PlanDay, 'id' | 'done'>): string => `plan-${d.id}-${(Date.parse(d.done?.at || '') || 0).toString(36)}`

/**
 * Zapis iz načrta za opravljen dan brez povezane vadbe (null = ne šteje: ni opravljen, povezan s pravo vadbo,
 * počitek ali brez minut). `prev` = obstoječi zapis tega dne (ostane isti id).
 */
export function standInFor(d: PlanDay, p: Profile, prev?: Activity | null, now: string = new Date().toISOString()): Activity | null {
  const sport = sportOfKind(d.kind)
  if (!sport || !d.done || d.done.activityId) return null
  const min = doneMinutes(d)
  if (min <= 0) return null
  const share = doneShare(d)
  const tss = d.tssTarget != null && d.tssTarget > 0 && d.durationMin > 0 ? Math.round(d.tssTarget * share) : estimateTss({ sport, durationMin: min }, p)
  const k0 = d.kcalBurn != null && Number.isFinite(d.kcalBurn) && d.kcalBurn > 0 ? d.kcalBurn : estimatePlanKcal(d, p)
  return {
    id: prev?.id ?? standInId(d), source: 'plan', planDayId: d.id, sport, date: d.date, start: null,
    name: titleNoDur(d.title, d.durationMin), durationMin: min, distKm: null, tss, kcal: k0 > 0 ? Math.round(k0 * share) : null,
    polyline: null, ...deriveFlags('plan'), createdAt: prev?.createdAt ?? now, updatedAt: now,
  }
}

/** Ali se zapis spremeni (minute, obremenitev, ime …) — sicer ga ne pišemo znova (oblak, druge naprave). */
export function standInChanged(a: Activity, b: Activity): boolean {
  return a.id !== b.id || a.date !== b.date || a.sport !== b.sport || a.name !== b.name || a.durationMin !== b.durationMin || a.tss !== b.tss || (a.kcal ?? null) !== (b.kcal ?? null)
}

/**
 * Zapisi iz načrta, ki odpadejo: prava vadba istega dne in športa jih zamenja (`extra` = vadbe, ki se pravkar uvažajo),
 * in dvojnik za isti dan načrta (»Opravil« na dveh napravah brez povezave) — ostane novejši, na obeh napravah isti.
 */
export function standInsToDrop(acts: readonly Activity[], extra: readonly Activity[] = [], plan: readonly PlanDay[] = []): Activity[] {
  const all = [...acts, ...extra]
  const keep = new Map<string, Activity>()
  for (const a of acts) {
    if (!isStandIn(a)) continue
    const k = keep.get(a.planDayId!)
    if (!k || (a.updatedAt || '') + a.id > (k.updatedAt || '') + k.id) keep.set(a.planDayId!, a)
  }
  return acts.filter(a => isStandIn(a) && (keep.get(a.planDayId!) !== a || !!realOn(all, a.date, a.sport, { plan, dayId: a.planDayId })))
}

/**
 * Stare kljukice (pred v3.49) in dnevi, opravljeni na napravi brez te različice: kateri zapisi iz načrta manjkajo.
 * Samo pretekli in današnji dnevi od `from`; ne, če je ta dan prava vadba iste vrste ali zapis že obstaja ali je
 * bil izbrisan (grob — ne vstane sam).
 */
export function standInsToAdd(plan: readonly PlanDay[], acts: readonly Activity[], p: Profile, o: { today: string; from: string; tomb?: Record<string, number> }): Activity[] {
  const have = new Set(acts.filter(isStandIn).map(a => a.planDayId))
  const out: Activity[] = []
  for (const d of plan) {
    if (!d.done || d.done.activityId || d.date > o.today || d.date < o.from || have.has(d.id)) continue
    const sport = sportOfKind(d.kind)
    if (!sport || realOn(acts, d.date, sport, { plan, dayId: d.id })) continue
    const a = standInFor(d, p)
    if (a && !o.tomb?.[`a:id:${a.id}`]) out.push(a)
  }
  return out
}

/** Izbira minut za »Krajše«: korak 5, 10, 15 ali 30 min, do 7 možnosti, vse krajše od načrta. */
export function minuteOptions(planned: number): number[] {
  if (!(planned > 10)) return []
  const step = [5, 10, 15, 30, 60].find(s => Math.ceil(planned / s) - 1 <= 7) ?? 60
  const out: number[] = []
  for (let m = step; m < planned; m += step) out.push(m)
  return out
}
