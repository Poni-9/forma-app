import type { Profile } from '../types'

/**
 * KAJ V OFF-SEASONU — izbere uporabnik (prej je predloga sama dala hribe). Privzeto kolo po občutku; hribi samo,
 * če jih izbere. Besedila za kartice, povzetek tedna in AI na enem mestu.
 */
export type OffMix = NonNullable<Profile['offMix']>

export const OFF_MIX: Record<OffMix, { label: string; active: string; toast: string }> = {
  kolo: { label: 'Kolo po občutku', active: 'vožnja po občutku', toast: 'Off-season: kolo po občutku, brez hribov.' },
  mesano: { label: 'Kolo in hribi', active: 'vožnja po občutku in hribi', toast: 'Off-season: kolo po občutku in hribi.' },
  hribi: { label: 'Več hribov', active: 'večinoma hribi, kolo po občutku', toast: 'Off-season: večinoma hribi, kolo enkrat na teden.' },
}
export const OFF_MIX_KEYS: OffMix[] = ['kolo', 'mesano', 'hribi']

export const offMixOf = (p: Pick<Profile, 'offMix'>): OffMix => p.offMix ?? 'kolo'
