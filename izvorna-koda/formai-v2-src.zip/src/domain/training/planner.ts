import type { Activity, PhaseName, PlanContent, PlanDay, PlanKind, Profile, Race, RaceType } from '../types'
import { seasonGoals, peakGoals, raceTypeOf, raceMinutes, sideRaceMinutes, ftpForWeek, offStage, OFF_MAX, RACE_TYPES, type SeasonGoal, type OffStage } from './season'
import { addDays, formSeries, formReliable, todayIso, weekStartIso, estimateTss, fmtDur } from './load'
import { zoneText, noPower, lthrZoneText } from './zones'
import { isHardDay } from './plandays'
import { minMinutes } from './workout'

/**
 * NAČRT DO CILJA (osebna različica: Maraton Franja).
 * Makrocikel od začetka načrta do dneva dirke: osnova → gradnja → specifično → tapering → dirka.
 * V vsaki fazi bloki 3 + 1 (trije tedni rastoče obremenitve, četrti razbremenilni), 80/20:
 * pon počitek · tor VO2max + jedro · sre Z2 · čet prag / sweet spot · pet regeneracija + noge · sob dolga Z2 · ned Z2.
 * Vse deterministično — brez omrežja in brez AI. Vati iz FTP, ko ga poznamo.
 */

/** Verjetnost dežja po dnevih (0–100), če jo poznamo. */
export type RainByDate = Record<string, number | undefined>

export interface PlanInput {
  profile: Profile
  activities: readonly Activity[]
  /** prvi dan tedna (ISO, ponedeljek) — privzeto ta teden */
  weekStart?: string
  rain?: RainByDate
  /** prvi teden načrta: vključi uvodni 20-min test, če FTP ni svež */
  firstWeek?: boolean
  /** dnevi pred tem datumom so že mimo (privzeto danes) */
  notBefore?: string
}

/** Kateri ponedeljek naj bo začetek PRVEGA načrta: če je teden že večinoma mimo (čet+), naslednji. */
export function firstPlanWeekStart(today: string = todayIso()): string {
  const ws = weekStartIso(today)
  const dow = Math.round((new Date(today).getTime() - new Date(ws).getTime()) / 86400_000)
  return dow >= 3 ? addDays(ws, 7) : ws
}

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
const DAY = 86400_000
const weeksBetween = (a: string, b: string) => Math.round((new Date(b).getTime() - new Date(a).getTime()) / (7 * DAY))
const r5 = (x: number) => Math.round(x / 5) * 5
const clamp = (x: number, a: number, b: number) => Math.max(a, Math.min(b, x))
/** Dan v tednu v tožilniku (»v soboto«) — iz datuma, neodvisno od časovnega pasu naprave. */
const DAY_ACC = ['nedeljo', 'ponedeljek', 'torek', 'sredo', 'četrtek', 'petek', 'soboto']
const dayAcc = (iso: string) => DAY_ACC[new Date(iso + 'T12:00:00Z').getUTCDay()] ?? ''
/** »s ponedeljka«, »z nedelje« — od katerega dne (predlog z/s + rodilnik). */
const DAY_FROM = ['z nedelje', 's ponedeljka', 's torka', 's srede', 's četrtka', 's petka', 's sobote']
const dayFrom = (iso: string) => DAY_FROM[new Date(iso + 'T12:00:00Z').getUTCDay()] ?? ''
/** Tekma, pred katero je polnjenje z OH (8–10 g na kg zadnja dva dni). */
const CARB_LOAD_RACE_MIN = 150
/** Na kolesu 60+ g OH na uro samo na tekmah od 90 min naprej. */
const FUEL_RACE_MIN = 90

/** Privzeti cilj: Veliki maraton Franja BTC City 2027 — 13. 6. 2027, 156 km (franja.org). */
export const FRANJA_2027 = { name: 'Maraton Franja', date: '2027-06-13', distanceKm: 156 }

/* ====================================================================
   FAZE IN TEDEN V MAKROCIKLU
   ==================================================================== */
export type PhaseKey = PhaseName
export const PHASE_INFO: Record<PhaseKey, { name: string; desc: string }> = {
  prehod: { name: 'Off-season', desc: 'Počitek po sezoni: hribi, vožnja po občutku, drugi športi — brez intervalov in brez ure. Telo in glava se napolnita; FTP pade nekaj %, kar je normalno.' },
  osnova: { name: 'Osnova', desc: 'Aerobna baza: prvi tedni lahko (Z2, šprinti, tempo), nato sweet spot in VO2max v manjšem odmerku, moč 2×. Klanci, ravnina in šprint izmenično. Tu gre teža dol — deficit samo izven kolesa.' },
  gradnja: { name: 'Gradnja', desc: 'Dvig FTP: prag 3 × 15 in 2 × 20 min, VO2max 5 × 4 min, dolga vožnja s tempom v zadnji uri. Teža se ustali.' },
  specificno: { name: 'Specifično', desc: 'Za Franjo: VO2max, simulacija Kladja (2 × 20 min na klancu), dolge vožnje v tempu dirke z gorivom 60–80 g/h.' },
  tapering: { name: 'Tapering', desc: 'Volumen −40 %, intenzivnost ostane kratka in ostra. Noge se napolnijo.' },
  dirka: { name: 'Teden dirke', desc: 'Kratki pospeški in veliko spanja; pred dolgo dirko zadnja dva dni 8–10 g OH na kg telesne teže.' },
  po: { name: 'Po dirki', desc: 'Dva tedna lahko in po občutku — nato nov cilj.' },
}

export interface WeekCtx {
  phase: PhaseKey
  phaseName: string
  phaseDesc: string
  /** zaporedni teden od začetka načrta (1 = prvi) */
  week: number
  /** vseh tednov do vključno tedna dirke (ali 12 v ciklu brez dogodka) */
  total: number | null
  /** teden v bloku 3 + 1 */
  blockWeek: 1 | 2 | 3 | 4
  recovery: boolean
  /** ta teden je 20-minutni test FTP */
  test: boolean
  /** delež ciljnih ur */
  volume: number
  /** načrtovane ure na kolesu ta teden */
  hours: number
  weeksToEvent: number | null
  event: { name: string; date: string; distanceKm?: number | null } | null
  /** ali načrt sploh ima strukturo (dogodek ali začet cikel) */
  structured: boolean
  /** lahek začetek sezone (1–3. teden po začetku ali off-seasonu): brez intervalov — Z2, šprinti, tempo; 0 = ne */
  easy: 0 | 1 | 2 | 3
  /** vrsta naslednjega cilja sezone — vsebina specifičnega bloka */
  goalType: RaceType | null
  /** koliko ciljev A ima sezona */
  goals: number
  /** teden od konca off-seasona (1 = prvi teden osnove); null brez začetega načrta */
  baseWeek: number | null
  /** off-season: počitek → aktivni počitek → vrnitev */
  offStage?: OffStage
}

/** Ure na kolesu v »normalnem« tednu bloka (drugi teden). Prvi je ~12 % nižji, tretji ~12 % višji. */
export function targetHours(p: Pick<Profile, 'hoursPerWeek' | 'level'>): number {
  const h = p.hoursPerWeek || ({ 1: 4, 2: 6, 3: 9, 4: 12 } as Record<number, number>)[p.level || 3] || 9
  return clamp(h, 3, 30)
}

/**
 * Rast od tega, kar res voziš: prvi teden največ ~1,2 × dejanskih ur (vsaj 4 h), nato +10 % na teden.
 * Razbremenilni teden ~60 % zgornje meje. Brez podatkov (baseHours null) ni omejitve.
 */
export function rampCap(p: Pick<Profile, 'baseHours'>, since: number, recovery: boolean): number {
  if (p.baseHours == null || !Number.isFinite(p.baseHours)) return Infinity
  const c = Math.max(4, p.baseHours * 1.2) * Math.pow(1.1, Math.max(0, since))
  return recovery ? c * 0.6 : c
}

/**
 * URE IZ RESNICE. Načrt raste od tega, kar res treniraš, ne od tabele: ure na kolesu, teku in v hribih v zadnjih
 * treh polnih tednih pred tem tednom → strop tedna = 1,25 × max(zadnji teden, povprečje treh), vsaj 4 h.
 * Brez podatkov (manj kot 2 aktivnosti v teh tednih) stropa ni. Po bolezni ali premoru se načrt tako sam spusti
 * in spet postopno raste; v taperingu in tednu dirke ne velja (tam je obseg namenoma drugačen).
 */
export function realityCap(acts: readonly Activity[], weekStart: string): { cap: number; base: number; weeks: number[] } | null {
  const wk = (k: number) => { const s = addDays(weekStart, -7 * k), e = addDays(s, 6); return acts.filter(a => (a.sport === 'kolo' || a.sport === 'tek' || a.sport === 'pohod') && a.date >= s && a.date <= e) }
  const rows = [1, 2, 3].map(wk)
  if (rows.reduce((n, r) => n + r.length, 0) < 2) return null
  const hours = rows.map(r => +(r.reduce((t, a) => t + (a.durationMin || 0), 0) / 60).toFixed(1))
  const base = Math.max(hours[0]!, hours.reduce((t, h) => t + h, 0) / hours.length)
  return { cap: Math.round(Math.max(4, base * 1.25) * 2) / 2, base: +base.toFixed(1), weeks: hours }
}

/** Ure tedna za sestavo: cilj iz cikla, omejen s tem, kar res treniraš (realityCap). */
export function planHours(p: Profile, acts: readonly Activity[], weekStart: string): { hours: number; capped: boolean; base: number | null } {
  const ctx = weekContext(p, weekStart)
  if (ctx.phase === 'tapering' || ctx.phase === 'dirka') return { hours: ctx.hours, capped: false, base: null }
  const rc = realityCap(acts, weekStart)
  if (!rc || rc.cap >= ctx.hours) return { hours: ctx.hours, capped: false, base: rc?.base ?? null }
  return { hours: rc.cap, capped: true, base: rc.base }
}

function ftpStale(p: Pick<Profile, 'ftp' | 'ftpDate'>, weekStart: string): boolean {
  if (!p.ftp || !p.ftpDate) return true
  return (new Date(weekStart).getTime() - new Date(p.ftpDate).getTime()) / DAY > 28
}

export function weekContext(p: Profile, weekStart: string = weekStartIso(todayIso())): WeekCtx {
  const T = targetHours(p)
  const goals = seasonGoals(p), peaks = peakGoals(p)
  const start = p.cycleStart || weekStart
  const since = Math.max(0, weeksBetween(start, weekStart))
  // off-season na začetku načrta: tedni počitka in hribov (šteje se samo pri začetem načrtu)
  const off = p.cycleStart ? clamp(Math.round(p.offSeasonWeeks ?? 0), 0, OFF_MAX) : 0
  // faze se ravnajo po vrhovih forme (cilj A blizu drugega vrha se vozi v isti formi — samo teden tekme)
  const next = peaks.find(g => weekStartIso(g.date) >= weekStart) ?? null
  const prev = [...peaks].reverse().find(g => weekStartIso(g.date) < weekStart) ?? null
  const shown = next ?? prev
  const ev = shown ? { name: shown.name, date: shown.date, distanceKm: shown.distanceKm } : null
  const last = goals.length ? weekStartIso(goals[goals.length - 1]!.date) : null
  const total0 = last ? Math.max(1, weeksBetween(start, last) + 1) : null
  const e = since - off                                     // tedni od konca off-seasona (0 = prvi teden osnove)
  const mk = (phase: PhaseKey, o: Partial<WeekCtx>): WeekCtx => {
    const volume = o.volume ?? 1
    // teden cilja: dan dirke in polnjenje z OH po dejanskem cilju (ne vedno nedelja, ne pred vsako dirko)
    const phaseDesc = phase === 'dirka' && next
      ? `Kratki pospeški in veliko spanja${raceMinutes(next) >= CARB_LOAD_RACE_MIN ? ', zadnja dva dni 8–10 g OH na kg telesne teže' : ''}. Dirka v ${dayAcc(next.date)}.`
      : PHASE_INFO[phase].desc
    return {
      phase, phaseName: PHASE_INFO[phase].name, phaseDesc, week: since + 1, total: total0,
      blockWeek: 2, recovery: false, test: false, weeksToEvent: null, event: ev, structured: !!(ev || p.cycleStart),
      easy: 0, goalType: next?.type ?? null, goals: goals.length, baseWeek: p.cycleStart ? e + 1 : null,
      ...o, volume, hours: Math.round(Math.min(T * volume, rampCap(p, Math.max(0, e), !!o.recovery || phase === 'prehod')) * 2) / 2,
    }
  }
  if (p.cycleStart && since < off) {
    const st = offStage(since + 1, off)
    return mk('prehod', { weeksToEvent: next ? weeksBetween(weekStart, weekStartIso(next.date)) : null, volume: st === 'pocitek' ? 0.2 : st === 'vrnitev' ? 0.5 : 0.4, recovery: true, blockWeek: 4, offStage: st })
  }
  if (next) {
    const evWeek = weekStartIso(next.date)
    const wte = weeksBetween(weekStart, evWeek)
    let afterPo = -1                                        // tedni po počitku za prejšnjim ciljem (0 = prvi)
    if (prev) {
      // po cilju sezone teden lahko (pri dolgem razmiku do naslednjega dva)
      const ago = weeksBetween(weekStartIso(prev.date), weekStart), gap = weeksBetween(weekStartIso(prev.date), evWeek)
      const rest = gap >= 10 ? 2 : 1
      if (ago <= rest && wte >= 2) return mk('po', { weeksToEvent: wte, volume: 0.5, recovery: true, blockWeek: 4 })
      afterPo = ago - rest - 1
    }
    if (wte === 0) return mk('dirka', { weeksToEvent: 0, volume: 0.4, blockWeek: 4 })
    if (wte === 1) return mk('tapering', { weeksToEvent: 1, volume: 0.6, blockWeek: 4 })
    // bloki se štejejo NAZAJ od taperinga (zadnji teden pred taperingom je vedno težak);
    // med dvema ciljema NAPREJ od počitka (1, 2, 3, razbremenitev …), teden pred taperingom nikoli razbremenilni
    const idx = wte - 2, m = afterPo >= 0 ? afterPo % 4 : idx % 4
    const recovery = afterPo >= 0 ? m === 3 && wte > 2 : m === 3 && since >= off + 2   // v prvih dveh tednih po začetku ni razbremenitve
    const blockWeek = (afterPo >= 0 ? (recovery ? 4 : Math.min(3, m + 1)) : m === 3 ? (recovery ? 4 : 1) : 3 - m) as 1 | 2 | 3 | 4
    let phase: PhaseKey = idx <= 7 ? 'specificno' : idx <= 19 ? 'gradnja' : 'osnova'
    if (prev && phase === 'osnova') phase = 'gradnja'     // med cilji sezone ne nazaj v osnovo
    // lahek začetek sezone: prvi trije tedni po začetku (ali off-seasonu) brez intervalov, če je do prvega cilja dovolj časa
    const easyPlan = !!p.cycleStart && !!peaks[0] && weeksBetween(addDays(start, off * 7), weekStartIso(peaks[0].date)) >= 11
    const easy = easyPlan && !prev && e >= 0 && e < 3 ? ((e + 1) as 1 | 2 | 3) : 0
    // test FTP: po lahkih tednih (po off-seasonu vedno, sicer če FTP ni svež), brez lahkega začetka v prvem tednu; nato vsakih 8 tednov
    const first = easyPlan ? e === 3 && (off > 0 || ftpStale(p, weekStart)) : !!p.cycleStart && since === 0 && ftpStale(p, weekStart)
    const test = !easy && (first || (recovery && (afterPo >= 0 ? afterPo % 8 === 3 : idx % 8 === 3)))
    // po dolgem off-seasonu (4+ tednov) počasnejša gradnja: lahki tedni od ~50 %, osnova od ~80 % proti 100 % v 12 tednih
    const long = off >= 4
    const ramp = phase === 'osnova' ? Math.min(1, (long ? 0.8 : 0.85) + ((long ? 0.2 : 0.15) * Math.max(0, e)) / 12) : 1
    // lahki tedni: po off-seasonu od ~60 % ur navzgor (telo se vrača), brez off-seasona od ~75 %
    const volume = recovery ? 0.52 : easy ? (long ? [0.5, 0.6, 0.7] : off > 0 ? [0.6, 0.7, 0.8] : [0.75, 0.8, 0.85])[easy - 1]! : [0.88, 1, 1.12][blockWeek - 1]! * ramp * (phase === 'specificno' ? 0.95 : 1)
    return mk(phase, { weeksToEvent: wte, blockWeek, recovery, test, volume, easy })
  }
  if (prev) {
    const ago = weeksBetween(weekStartIso(prev.date), weekStart)
    // po zadnjem vrhu še cilji A v isti formi: teden lahko, nato vzdrževanje forme (specifično, bloki naprej)
    const later = goals.some(g => g.date >= weekStart)
    if (ago <= (later ? 1 : 2)) return mk('po', { weeksToEvent: -ago, volume: 0.5, recovery: true, blockWeek: 4 })
    if (later) {
      const m = (ago - 2) % 4, recovery = m === 3
      return mk('specificno', { weeksToEvent: null, blockWeek: (recovery ? 4 : Math.min(3, m + 1)) as 1 | 2 | 3 | 4, recovery, volume: recovery ? 0.52 : [0.88, 1, 1.12][Math.min(2, m)]! * 0.95 })
    }
    // nov cikel po zadnjem cilju (off-season ali nov začetek načrta po tekmi): šteje se od konca off-seasona
    // (oz. od konca počitka po tekmi) z lahkimi tedni in testom v 4. tednu — ne naravnost v trde tedne
    if (p.cycleStart && p.cycleStart > weekStartIso(prev.date)) return rolling(Math.max(0, Math.min(e, ago - 3)), -ago, true)
    return rolling(ago - 3, -ago, false)                  // po zadnjem cilju: sezona teče dalje v 12-tedenskih ciklih
  }
  // brez ciljev: ponavljajoči se 12-tedenski cikel (osnova 4 · gradnja 4 · specifično 4; vsak 4. razbremenilni)
  if (!p.cycleStart) return mk('osnova', { blockWeek: 2, volume: 1 })
  return rolling(e, null, true)

  /** 12-tedenski cikel; fresh = nov začetek (lahki trije tedni, nato razbremenilni s testom). */
  function rolling(n: number, wte: number | null, fresh: boolean): WeekCtx {
    const w = n % 12
    const phase: PhaseKey = w < 4 ? 'osnova' : w < 8 ? 'gradnja' : 'specificno'
    const blockWeek = ((w % 4) + 1) as 1 | 2 | 3 | 4
    const recovery = blockWeek === 4
    const easy = fresh && n < 3 ? ((n + 1) as 1 | 2 | 3) : 0
    // prvi test FTP: po lahkem začetku (4. teden) ali po off-seasonu; sicer takoj, če FTP ni svež
    const test = !easy && ((n === (off > 0 || fresh ? 3 : 0) && (off > 0 || ftpStale(p, weekStart))) || (recovery && w === 11))
    // lahki tedni kot pred ciljem: po off-seasonu od ~60 % ur (po dolgem od ~50 %), brez njega od ~75 %
    const volume = recovery ? 0.52 : easy ? (off >= 4 ? [0.5, 0.6, 0.7] : off > 0 ? [0.6, 0.7, 0.8] : [0.75, 0.8, 0.85])[easy - 1]! : [0.88, 1, 1.12][blockWeek - 1]!
    return mk(phase, { week: w + 1, total: 12, blockWeek, recovery, test, weeksToEvent: wte, easy, volume })
  }
}

/** Vsi tedni od začetka načrta do tedna zadnjega cilja sezone (za časovnico). */
export function macroWeeks(p: Profile, today: string = todayIso()): (WeekCtx & { weekStart: string })[] {
  const goals = seasonGoals(p)
  if (!goals.length) return []
  const first = p.cycleStart || weekStartIso(today)
  const last = weekStartIso(goals[goals.length - 1]!.date)
  const out: (WeekCtx & { weekStart: string })[] = []
  for (let ws = first; ws <= last && out.length < 80; ws = addDays(ws, 7)) out.push({ ...weekContext(p, ws), weekStart: ws })
  return out
}

/* ====================================================================
   MOČ ZA KOLESARJA: jedro in noge, 2 × 20–30 min (ne »mišice za ogledalo«).
   Napredovanje iz zadnje zabeležene seje z istim naslovom: obseg ponovitev ostane, kg se prevzamejo;
   ko je bila zgornja meja ponovitev zabeležena v vseh serijah, naslednjič +2,5 kg (težke vaje s palico +5 kg).
   ==================================================================== */
export type StrengthKind = 'jedro' | 'noge' | 'fitnesA' | 'fitnesB'
export type Exercise = { name: string; sets: number; reps: string; kg?: number | null }
const STR: Record<StrengthKind, [string, number, string][]> = {
  jedro: [['Deska', 3, '45–60 s'], ['Stranska deska', 3, '30–45 s'], ['Dvig nog leže', 3, '10–15'], ['Dead bug', 3, '8–12']],
  noge: [['Bolgarski počep', 3, '8–12'], ['Izpadni koraki', 3, '10–12'], ['Dvigi na prste', 3, '15–20'], ['Deska', 3, '45–60 s']],
  // fitnes (Rønnestad & Mujika 2014: težka moč 2 × na teden izven sezone, 4–10 ponovitev, večsklepne vaje za noge)
  fitnesA: [['Polovični počep s palico', 4, '5–8'], ['Nožna preša na eni nogi', 3, '6–8'], ['Romunski mrtvi dvig', 3, '6–8'], ['Dvig kolena na kablu (upogib kolka)', 3, '8–10'], ['Dvigi na prste stoje', 3, '10–12'], ['Deska', 3, '45–60 s']],
  fitnesB: [['Stopanje na klop z ročkami', 3, '6–8'], ['Hip thrust', 3, '6–8'], ['Bolgarski počep z ročkami', 3, '6–8'], ['Enoročno veslanje z ročko', 3, '8–10'], ['Pallof press', 3, '10–12'], ['Dead bug', 3, '8–12']],
}
export const STRENGTH_TITLE: Record<StrengthKind, string> = { jedro: 'Moč — jedro', noge: 'Moč — noge in jedro', fitnesA: 'Fitnes — noge (težko)', fitnesB: 'Fitnes — noge, hrbet, jedro' }
const STRENGTH_MIN: Record<StrengthKind, number> = { jedro: 20, noge: 30, fitnesA: 55, fitnesB: 50 }

export function strengthSession(kind: StrengthKind, p: Profile, activities: readonly Activity[], light = false): { title: string; exercises: Exercise[]; desc: string; progressed: boolean; min: number } {
  const ex: Exercise[] = STR[kind].map(([name, sets, reps]) => ({ name, sets: light ? Math.max(2, sets - 1) : sets, reps, kg: name === 'Bolgarski počep' && p.gear.dumbbells ? p.gear.dumbbellKg || null : null }))
  const title = STRENGTH_TITLE[kind]
  const last = [...activities].filter(a => a.sport === 'moc' && a.name === title && a.exercises && a.exercises.length).sort((a, b) => b.date.localeCompare(a.date))[0]
  let progressed = false
  if (last && !light) {
    for (const x of ex) {
      const z = last.exercises!.find(y => y.name.toLowerCase() === x.name.toLowerCase())
      if (!z) continue
      if (z.kg && Number.isFinite(z.kg) && z.kg > 0) x.kg = z.kg
      if (z.sets > x.sets) x.sets = Math.min(5, z.sets)
      // obseg ponovitev ostane (ne raste v nedogled); teža gor šele, ko je bila zgornja meja res zabeležena
      const top = repsTop(x.reps), got = repsLogged(z.reps)
      if (x.kg && top != null && got != null && got >= top) {
        const next = x.kg + (/počep s palico|mrtvi dvig|hip thrust/i.test(x.name) && x.kg >= 40 ? 5 : 2.5)
        const max = p.strength.equipment !== 'gym' && x.name === 'Bolgarski počep' ? p.gear.dumbbellKg ?? null : null   // doma: le toliko, kolikor imaš uteži
        if (max == null || next <= max) { x.kg = next; progressed = true }
      }
    }
  }
  const desc = light ? 'Lažja različica: manj serij, ista tehnika.'
    : kind === 'jedro' ? 'Po kolesu ali zvečer. Močan trup = zgornji del telesa miruje, vsi vati gredo v pedala.'
    : kind === 'fitnesA' ? 'Fitnes: 10 min ogrevanja (sobno kolo), nato težko — zadnji 2 ponovitvi naj bosta težki, tehnika pred kilogrami. Med serijami 2–3 min. Ko vse serije narediš z zgornjo mejo ponovitev, naslednjič +2,5–5 kg. Kilograme vpiši — naslednja seja jih prevzame.'
    : kind === 'fitnesB' ? 'Fitnes: 10 min ogrevanja, nato enonožne vaje (moč in ravnotežje za pedaliranje) + hrbet in jedro za držo na kolesu. Med serijami 90 s. Kilograme vpiši — naslednja seja jih prevzame.'
    : 'Počasi in s kontrolo. Noge za klance in stabilnost; ko dosežeš zgornjo mejo ponovitev, dodaj težo (nahrbtnik ali uteži).'
  return { title, exercises: ex, desc: progressed && !light ? desc + ' Prejšnjič zgornja meja ponovitev — teža je višja.' : desc, progressed, min: light ? Math.round(STRENGTH_MIN[kind] * 0.75) : STRENGTH_MIN[kind] }
}
/** Zgornja meja ponovitev (»6–8« → 8); pri vajah na čas (»45–60 s«) null — tam se ne dodaja teže. */
function repsTop(reps: string): number | null {
  if (/\ds\b|\d\s*s\b|sek/i.test(reps)) return null
  const m = String(reps).match(/(\d+)\s*[–-]\s*(\d+)/)
  return m ? +m[2]! : /^\s*\d+\s*$/.test(reps) ? +reps : null
}
/**
 * Koliko ponovitev je bilo zabeleženih v najslabši seriji: »8« → 8, »8, 8, 7« ali »8/8/7« → 7, razpon »6–8« → 6
 * (predpisan razpon, prepisan v dnevnik, ne pove, da je bila zgornja meja dosežena). Na čas ali brez števila: null.
 */
function repsLogged(reps: string): number | null {
  const s = String(reps ?? '')
  if (/\ds\b|\d\s*s\b|sek/i.test(s)) return null
  const range = s.match(/^\s*(\d+)\s*[–-]\s*(\d+)\s*$/)
  if (range) return Math.min(+range[1]!, +range[2]!)
  const nums = (s.match(/\d+/g) || []).map(Number).filter(n => Number.isFinite(n) && n > 0)
  return nums.length ? Math.min(...nums) : null
}

/* ====================================================================
   KNJIŽNICA SEJ — vati iz FTP
   ==================================================================== */
interface Sess {
  title: string; desc: string; min: number; zone: string; tss: number; target: { lo: number; hi: number } | null; role: NonNullable<PlanDay['role']>; why: string | null
  /** privzeto kolo (test: test); hribi = pohod */ kind?: PlanKind
  /** po želji (ne šteje v realizacijo) */ optional?: boolean
  /** ne krajša se in ne odpade, ko je teden čez proračun (predaktivacija pred tekmo) */ fixed?: boolean
  /** ključni trening, ki sme odpasti, ko je teden čez proračun (tapering, teden dirke) — manjša številka odpade prej */ drop?: number
}

const watts = (p: Profile, a: number, b: number) => (p.ftp ? { lo: Math.round(p.ftp * a), hi: Math.round(p.ftp * b) } : null)
function wtxt(p: Profile, a: number, b: number, z: 'Z1' | 'Z2' | 'Z3' | 'Z4' | 'Z5'): string {
  const w = watts(p, a, b)
  const pc = `${Math.round(a * 100)}–${Math.round(b * 100)} % FTP`
  if (noPower(p)) { const hr = lthrZoneText(p, z); if (hr) return `${hr}${w ? ` (≈ ${w.lo}–${w.hi} W, brez merilnika po občutku)` : ''}` }
  return w ? `${w.lo}–${w.hi} W (${pc})` : `${pc} (${zoneText(p, z)})`
}
const tssOf = (minutes: number, IF: number) => Math.round((minutes / 60) * IF * IF * 100)

function intervals(p: Profile, o: { name: string; reps: number; work: number; rest: number; a: number; b: number; z: 'Z3' | 'Z4' | 'Z5'; note: string; why?: string | null; min?: number }): Sess {
  const wu = 20, cd = 15
  const core = o.reps * o.work + (o.reps - 1) * o.rest
  const base = wu + core + cd
  const dur = Math.max(o.min || 0, r5(base))
  const extra = dur - base
  const IF = (o.a + o.b) / 2
  const desc = `20 min ogrevanje s 3 kratkimi pospeški · ${o.reps} × ${o.work} min pri ${wtxt(p, o.a, o.b, o.z)}, vmes ${o.rest} min lahko${extra >= 10 ? ` · nato ${extra} min Z2 (${zoneText(p, 'Z2')})` : ''} · 15 min iztek. ${o.note}`
  const tss = tssOf(o.reps * o.work, IF) + tssOf(dur - o.reps * o.work, 0.6)
  return { title: `${o.name} ${o.reps} × ${o.work} min`, desc, min: dur, zone: o.z, tss, target: watts(p, o.a, o.b), role: 'kljucna', why: o.why ?? null }
}

const WHY_VO2 = 'Dvigne strop — VO2max je tvoja najšibkejša točka. Samo enkrat na teden, spočit in nahranjen.'
function vo2(p: Profile, phase: PhaseKey, bw: number): Sess {
  const note = 'Enakomerno od prvega do zadnjega — če zadnjega ne zmoreš v razponu, je bil prvi prehiter.'
  if (phase === 'osnova') return intervals(p, { name: 'VO2max', reps: bw === 1 ? 4 : 5, work: 4, rest: 4, a: 1.08, b: 1.15, z: 'Z5', note, why: WHY_VO2, min: 75 })
  if (phase === 'gradnja') return bw === 2
    ? intervals(p, { name: 'VO2max', reps: 4, work: 5, rest: 5, a: 1.1, b: 1.15, z: 'Z5', note, why: WHY_VO2, min: 90 })
    : intervals(p, { name: 'VO2max', reps: bw === 1 ? 5 : 6, work: 4, rest: 4, a: 1.1, b: 1.18, z: 'Z5', note, why: WHY_VO2, min: 90 })
  if (bw === 3) return intervals(p, { name: 'VO2max', reps: 6, work: 3, rest: 3, a: 1.15, b: 1.2, z: 'Z5', note: 'Kratko in ostro — kot pospeški skupine na Kladju.', why: WHY_VO2, min: 90 })
  return intervals(p, { name: 'VO2max', reps: bw === 1 ? 5 : 4, work: bw === 1 ? 4 : 5, rest: bw === 1 ? 4 : 5, a: 1.1, b: 1.2, z: 'Z5', note, why: WHY_VO2, min: 90 })
}

const FUEL_LONG = 'Gorivo: od 30. minute 50–60 g ogljikovih hidratov na uro in 500–750 ml tekočine na uro — kaj vzeti in kdaj jesti piše v Gorivu.'
function dolga(p: Profile, phase: PhaseKey, min: number, recovery: boolean): Sess {
  const z2 = zoneText(p, 'Z2')
  if (recovery) return { title: 'Lahka daljša Z2', desc: `Mirno ${z2}, brez klancev na silo. ${FUEL_LONG}`, min, zone: 'Z2', tss: tssOf(min, 0.62), target: null, role: 'dolga', why: 'Razbremenilni teden: volumen dol, da se prilagoditve zgodijo.' }
  if (phase === 'gradnja' && min >= 150) return { title: 'Dolga Z2 + tempo', desc: `Enakomerno ${z2}; v zadnji uri 2 × 15 min tempo pri ${wtxt(p, 0.76, 0.88, 'Z3')}. ${FUEL_LONG}`, min, zone: 'Z2', tss: tssOf(min - 30, 0.65) + tssOf(30, 0.82), target: watts(p, 0.76, 0.88), role: 'dolga', why: 'Tempo na utrujenih nogah — točno to zahteva druga polovica Franje.' }
  if (phase === 'specificno' && min >= 150) return { title: 'Simulacija Franje', desc: `Z2 ${z2}; na daljših klancih 2 × 20 min pri ${wtxt(p, 0.85, 0.92, 'Z3')}. Gorivo kot na dirki: ~80 g OH na uro od 30. minute. Po možnosti v skupini.`, min, zone: 'Z2', tss: tssOf(min - 40, 0.66) + tssOf(40, 0.88), target: watts(p, 0.85, 0.92), role: 'dolga', why: 'Vadiš tempo, gorivo in vožnjo v skupini za dan D.' }
  return { title: 'Dolga Z2', desc: `Enakomerno ${z2}, visoka kadenca, brez špicev. ${FUEL_LONG}`, min, zone: 'Z2', tss: tssOf(min, 0.65), target: null, role: 'dolga', why: 'Dolga Z2 gradi motor: mitohondrije, kurjenje maščob, vzdržljivost za 156 km.' }
}
const z2Ride = (p: Profile, min: number, sunday = false): Sess => ({ title: sunday ? 'Z2 — sam ali v skupini' : 'Z2 vzdržljivost', desc: `Mirno ${zoneText(p, 'Z2')}, kadenca 90+. Če si utrujen, skrajšaj — ne pospešuj.${min >= 90 ? ' Od 30. minute ~40 g OH na uro.' : ''}`, min, zone: 'Z2', tss: tssOf(min, 0.65), target: null, role: 'lahka', why: null })
/** Ključni trening + Z2 za njim (velik obseg: dan je daljši, intervali ostanejo enaki). */
const longer = (p: Profile, s: Sess, add: number): Sess => add < 15 ? s : ({ ...s, min: s.min + add, tss: s.tss + tssOf(add, 0.65), desc: `${s.desc} Po izteku še ${add} min Z2 (${zoneText(p, 'Z2')}).` })
const regen = (p: Profile, min: number): Sess => ({ title: 'Regeneracija', desc: `Zelo lahko${p.ftp ? `, pod ${Math.round(p.ftp * 0.55)} W` : ''} (pod 55 % FTP) — noge samo vrtijo. Lahko tudi prosto.`, min, zone: 'Z1', tss: tssOf(min, 0.5), target: null, role: 'regen', why: 'Kri v nogah pospeši regeneracijo pred vikendom.' })
const testSess = (p: Profile): Sess => ({ title: '20-minutni test FTP', desc: `15 min ogrevanje s 3 × 1 min hitreje, 5 min lahko, 20 min enakomerno čim močneje, 10 min iztek. FTP = 95 % povprečja teh 20 min.${p.ftp ? ` Začni pri ~${Math.round(p.ftp * 1.02)} W in zadnjih 5 min stisni.` : ''}`, min: 60, zone: 'test', tss: 70, target: null, role: 'test', why: 'Nov FTP = prave cone in vati za naslednje tedne. Vpiši ga v Napredek.' })

/* ====================================================================
   CELOVIT KOLESAR: klanci, ravnina, šprint, vzdržljivost — izmenično skozi vse leto.
   Pred cilji sezone specifičen blok po vrsti dirke (šprint, klanci, vzpon, maraton, kronometer, cestna).
   ==================================================================== */
const sec = (x: number) => (x >= 60 ? `${Math.floor(x / 60)} min${x % 60 ? ` ${x % 60} s` : ''}` : `${x} s`)
/** Kratke ponovitve (napadi, šprinti, 30/15): serije × ponovitve × sekunde. */
function reps(p: Profile, o: { name: string; title?: string; sets: number; n: number; on: number; off: number; setRest: number; a: number; b: number; note: string; why: string; min?: number; z?: 'Z4' | 'Z5' }): Sess {
  const work = o.sets * (o.n * (o.on + o.off) - o.off) + (o.sets - 1) * o.setRest
  const dur = Math.max(o.min || 0, r5(20 + work / 60 + 15))
  const pc = `${Math.round(o.a * 100)}–${Math.round(o.b * 100)} % FTP`
  const w = watts(p, o.a, o.b)
  const how = noPower(p) ? `${o.b >= 1.4 ? 'vse, kar gre' : 'zelo trdo, a enakomerno'} (utrip tu zaostaja — vozi po občutku)` : w ? `${w.lo}–${w.hi} W (${pc})` : pc
  // 2 seriji, 3–4 serije, 5+ serij; med serijama (2) / serijami (3+)
  const setTxt = o.sets > 1 ? `${o.sets} ${o.sets === 2 ? 'seriji' : o.sets <= 4 ? 'serije' : 'serij'} × ` : ''
  const desc = `20 min ogrevanje s 3 kratkimi pospeški · ${setTxt}${o.n} × (${sec(o.on)} pri ${how} / ${sec(o.off)} lahko)${o.sets > 1 ? `, med ${o.sets === 2 ? 'serijama' : 'serijami'} ${sec(o.setRest)} lahko` : ''} · ostanek Z2 (${zoneText(p, 'Z2')}), 15 min iztek. ${o.note}`
  const tss = tssOf((o.sets * o.n * o.on) / 60, (o.a + o.b) / 2) + tssOf(dur - (o.sets * o.n * o.on) / 60, 0.62)
  return { title: o.title || `${o.name} ${setTxt}${o.n} × ${sec(o.on)}`, desc, min: dur, zone: o.z || 'Z5', tss, target: null, role: 'kljucna', why: o.why }
}
const WHY_SPRINT = 'Šprint vsak teden: živčno-mišična moč ostane skozi vse leto, utrujenosti skoraj ne naredi.'
/** Šprinti v lahki vožnji (6–8 × 10–15 s, vmes 4–5 min zelo lahko). */
function withSprints(s: Sess, heavy = false): Sess {
  const n = heavy ? 8 : 6, t = heavy ? 15 : 10
  return { ...s, title: `${s.title} + ${n} × ${t} s šprint`, desc: `${s.desc} Na sredi ${n} × ${t} s šprint — vse, kar gre, iz 25–30 km/h, izmenično sede in stoje; vmes 4–5 min zelo lahko.`, tss: s.tss + n * 2, why: s.why || WHY_SPRINT }
}
/** Rønnestad 2020: 30/15 v treh serijah je pri treniranih kolesarjih dvignil več kot 4 × 5 min. */
const thirty15 = (p: Profile) => reps(p, { name: '30/15', title: '30/15 — 3 serije × 13', sets: 3, n: 13, on: 30, off: 15, setRest: 180, a: 1.2, b: 1.3, note: 'Vsaka 30-sekundna ponovitev enako trdo kot prva; če pade, končaj serijo.', why: 'Kratki intervali z mikro odmori: veliko časa blizu VO2max in pospeški kot na dirki.', min: 90 })
function overUnder(p: Profile, climb = false): Sess {
  const s = intervals(p, { name: 'Over-under', reps: 3, work: 9, rest: 5, a: 0.95, b: 1.05, z: 'Z4', note: `Vsak interval 3 × (2 min pri 95 % + 1 min pri 105 % FTP)${climb ? ', na klancu' : ''} — pospeški nad pragom in okrevanje na pragu, kot na dirki.`, why: 'Spremembe tempa: napadi na klancu, beg, vodenje skupine.', min: 105 })
  return s
}
/** Ključni trening 2 (četrtek): izmenično ravnina, klanec, over-under; pred ciljem po vrsti dirke. */
function k2Of(p: Profile, ctx: WeekCtx, g: SeasonGoal | null): Sess {
  const bw = ctx.blockWeek
  if (ctx.phase === 'specificno' && g) return specific2(p, g, bw)
  if (ctx.phase === 'osnova') {
    const [reps, work] = bw === 1 ? [3, 12] : bw === 2 ? [3, 15] : [2, 20]
    const v = bw === 1 ? { t: 'Sweet spot na ravnini', note: 'Na ravnini v spodnjem držalu, kadenca 85–95 — moč za ravnino in vodenje.' }
      : bw === 2 ? { t: 'Sweet spot na klancu', note: 'Na klancu 4–7 %, sede, kadenca 70–80 — moč za klance.' }
      : { t: 'Sweet spot', note: 'Kjerkoli, enakomerno. Kadenca 85–95.' }
    return intervals(p, { name: v.t, reps, work, rest: 5, a: 0.88, b: 0.93, z: 'Z3', note: v.note, why: 'Sweet spot da največ aerobnega napredka na minuto; izmenično ravnina in klanec, da si dober povsod.', min: 90 })
  }
  if (bw === 3) return overUnder(p, g?.type === 'klanci' || g?.type === 'vzpon')
  const [reps, work, a, b] = bw === 1 ? [3, 12, 0.95, 1] : [3, 15, 0.93, 0.98]
  return intervals(p, { name: bw === 1 ? 'Prag na ravnini' : 'Prag na klancu', reps, work, rest: 5, a, b, z: 'Z4', note: bw === 1 ? 'Na ravnini v spodnjem držalu, enakomerno — kot beg ali vodenje skupine.' : 'Na klancu 5–8 %, sede, kadenca 75–85, enakomerno.', why: 'Prag premakne FTP; izmenično ravnina in klanec.', min: 105 })
}
/** Specifični blok pred ciljem: kar odloča na tej dirki. */
function specific2(p: Profile, g: SeasonGoal, bw: number): Sess {
  switch (g.type) {
    case 'vzpon': {
      const [reps, work] = bw === 1 ? [2, 20] : bw === 2 ? [3, 15] : [1, 30]
      return intervals(p, { name: 'Vzpon', reps, work, rest: 8, a: 0.95, b: 1.0, z: 'Z4', note: 'Na čim daljšem klancu s podobnim naklonom kot na tekmi; sede, prvih 5 min ne prehitro.', why: `Specifično za ${g.name}: enakomerno na pragu toliko časa, kot traja vzpon.`, min: 105 })
    }
    case 'klanci':
      return bw === 2 ? intervals(p, { name: 'Klanci', reps: 6, work: 3, rest: 3, a: 1.05, b: 1.1, z: 'Z5', note: 'Na klancu 5–8 %, vsak vzpon enako močno, navzdol mirno.', why: `Specifično za ${g.name}: ponavljajoči se klanci in napadi.`, min: 105 })
        : bw === 3 ? reps(p, { name: 'Napadi na klancu', title: 'Klanci z napadi 5 × 4 min', sets: 1, n: 5, on: 240, off: 240, setRest: 0, a: 1.0, b: 1.1, note: 'Vsak 4-min vzpon: prvih 20 s napad (130 %+), nato na pragu do vrha.', why: `Specifično za ${g.name}: napad in zdržati tempo do vrha.`, min: 105 })
        : overUnder(p, true)
    case 'sprint':
      return bw === 1 ? reps(p, { name: 'Napadi', sets: 3, n: 5, on: 30, off: 30, setRest: 300, a: 1.4, b: 1.6, note: 'Vsaka ponovitev kot napad iz skupine; na koncu serije 15 s šprint do konca.', why: `Specifično za ${g.name}: napadi in zaključek.`, min: 90 })
        : bw === 2 ? reps(p, { name: 'Šprint iz zavetrja', sets: 2, n: 4, on: 15, off: 285, setRest: 600, a: 1.8, b: 2.5, note: 'Vsak šprint iz 35–40 km/h, kot zadnjih 200 m; med serijama 10 min Z2.', why: `Specifično za ${g.name}: zaključni šprint.`, min: 90 })
        : reps(p, { name: '40/20', title: '40/20 — 3 serije × 8', sets: 3, n: 8, on: 40, off: 20, setRest: 240, a: 1.15, b: 1.25, note: 'Kot kriterij: vsak izhod iz ovinka in napad; zadnja ponovitev vsake serije šprint.', why: `Specifično za ${g.name}: dirka je niz pospeškov.`, min: 90 })
    case 'kronometer': {
      const [reps, work] = bw === 1 ? [2, 20] : bw === 2 ? [3, 12] : [1, 30]
      return intervals(p, { name: 'Kronometer v aero', reps, work, rest: 6, a: 0.95, b: 1.02, z: 'Z4', note: 'V aero položaju (ali spodnjem držalu), kadenca 90+, enakomerno; ravno cesto brez semaforjev.', why: `Specifično za ${g.name}: prag v položaju, v katerem boš dirkal.`, min: 105 })
    }
    case 'cestna':
      return bw === 1 ? specific2(p, { ...g, type: 'klanci' }, 2) : bw === 2 ? specific2(p, { ...g, type: 'sprint' }, 1) : overUnder(p)
    default: {                                            // maraton
      const franja = /franj/i.test(g.name)
      const [reps, work, a, b] = bw === 1 ? [2, 15, 0.95, 1] : bw === 2 ? [2, 20, 0.92, 0.97] : [3, 12, 0.97, 1.02]
      return intervals(p, { name: franja ? 'Kladje' : 'Dolgi klanec', reps, work, rest: 6, a, b, z: 'Z4', note: franja ? 'Po možnosti na klancu 5–8 % (Kladje: 7 km, 6,3 %). Sede, kadenca 75–85.' : 'Na daljšem klancu 5–8 %, sede, kadenca 75–85, enakomerno.', why: franja ? 'Specifično za glavni vzpon Franje — enakomerno, ne po špicah skupine.' : `Specifično za ${g.name}: dolg klanec na utrujenih nogah.`, min: 105 })
    }
  }
}
/** Ključni trening 1 (torek): VO2max; v gradnji vsak 3. teden 30/15; pred šprintersko dirko anaerobno. */
function k1Of(p: Profile, ctx: WeekCtx, g: SeasonGoal | null): Sess {
  if (ctx.phase === 'specificno' && g?.type === 'sprint') return ctx.blockWeek === 2 ? thirty15(p) : reps(p, { name: 'Anaerobno', title: '8 × 30 s vse, kar gre', sets: 1, n: 8, on: 30, off: 270, setRest: 0, a: 1.5, b: 2.0, note: 'Vsaka ponovitev do konca; odmor 4 min 30 s zelo lahko.', why: `Pred ${g.name}: kapaciteta za ponavljajoče se napade.`, min: 90 })
  if (ctx.phase === 'gradnja' && ctx.blockWeek === 3) return thirty15(p)
  // prvi VO2max po lahkem začetku: blago (4 × 4), nato po bloku
  const v = vo2(p, ctx.phase, ctx.phase === 'osnova' && ctx.baseWeek != null && ctx.baseWeek <= 6 ? 1 : ctx.blockWeek)
  if (ctx.phase === 'specificno' && (g?.type === 'klanci' || g?.type === 'vzpon')) return { ...v, desc: `${v.desc} Po možnosti na klancu 4–8 %.` }
  return v
}
/** Dolga vožnja: v osnovi izmenično ravnina in hribi; pred ciljem po vrsti in dolžini dirke. */
function longOf(p: Profile, ctx: WeekCtx, g: SeasonGoal | null, min: number): Sess {
  const z2 = zoneText(p, 'Z2')
  if (ctx.phase === 'osnova' && ctx.blockWeek === 2) return { ...dolga(p, 'osnova', min, false), title: 'Dolga Z2 po hribih', desc: `Z2 ${z2} po razgibani trasi — klance sede in enakomerno (do spodnje Z3), navzdol vrti. ${FUEL_LONG}`, why: 'Klanci v osnovi: moč in tehnika za vzpone brez velike utrujenosti.' }
  if (ctx.phase !== 'specificno' || !g || min < 150) return dolga(p, ctx.phase, min, false)
  const franja = /franj/i.test(g.name)
  switch (g.type) {
    case 'vzpon': return { title: 'Dolga + 3 dolgi klanci', desc: `Z2 ${z2}; na treh daljših klancih 12–20 min pri ${wtxt(p, 0.85, 0.92, 'Z3')}, sede. ${FUEL_LONG}`, min, zone: 'Z2', tss: tssOf(min - 50, 0.65) + tssOf(50, 0.88), target: watts(p, 0.85, 0.92), role: 'dolga', why: `Vzdržljivost na klancu za ${g.name}.` }
    case 'klanci': return { title: 'Dolga razgibana', desc: `Z2 ${z2} po razgibani trasi; vse klance v tempu ${wtxt(p, 0.85, 0.95, 'Z3')}, na vrhu 15 s pospešek čez rob. Gorivo kot na dirki: 70–80 g OH na uro.`, min, zone: 'Z2', tss: tssOf(min - 45, 0.66) + tssOf(45, 0.9), target: watts(p, 0.85, 0.95), role: 'dolga', why: `Razgibana dirka (${g.name}): klanec za klancem na utrujenih nogah.` }
    case 'sprint': return { title: 'Skupinska vožnja ali dirkalni trening', desc: `V skupini: zavetrina, pozicija, na tablah šprinti. Sam: Z2 ${z2} z 10 × 1 min pri ${wtxt(p, 1.15, 1.25, 'Z5')} (vmes 4 min) in 3 × 15 s šprint na koncu.`, min, zone: 'Z2', tss: tssOf(min - 20, 0.66) + tssOf(20, 1.0), target: null, role: 'dolga', why: `Šprinterska dirka (${g.name}): hitra vožnja v skupini in zaključek.` }
    case 'kronometer': return { title: 'Dolga + 3 × 15 min v aero', desc: `Z2 ${z2}; na ravnem 3 × 15 min v aero položaju pri ${wtxt(p, 0.88, 0.95, 'Z3')}. ${FUEL_LONG}`, min, zone: 'Z2', tss: tssOf(min - 45, 0.65) + tssOf(45, 0.9), target: watts(p, 0.88, 0.95), role: 'dolga', why: `Položaj in tempo za ${g.name}.` }
    default: return { title: franja ? 'Simulacija Franje' : 'Simulacija dirke', desc: `Z2 ${z2}; na daljših klancih 2 × 20 min pri ${wtxt(p, 0.85, 0.92, 'Z3')}. Gorivo kot na dirki: ~80 g OH na uro od 30. minute. Po možnosti v skupini.`, min, zone: 'Z2', tss: tssOf(min - 40, 0.66) + tssOf(40, 0.88), target: watts(p, 0.85, 0.92), role: 'dolga', why: `Vadiš tempo, gorivo in vožnjo v skupini za ${g.name}.` }
  }
}
/** Dolga vožnja pred dolgo dirko: vsaj ~80 % trajanja dirke (največ 6 h 30). */
const longFor = (g: SeasonGoal | null, phase: PhaseKey) => (g && (phase === 'specificno' || phase === 'gradnja') ? Math.min(390, r5(raceMinutes(g) * (phase === 'specificno' ? 0.85 : 0.75))) : 0)

/* ---------- lahek začetek sezone in off-season ---------- */
const WHY_EASY = 'Lahek začetek sezone: najprej baza in navada, intenzivnost pride v 4. tednu — tako se ne izčrpaš in ostane svežina za tekme.'
function easyKey(p: Profile, n: 1 | 2 | 3, day: 'tor' | 'cet', min: number): Sess {
  const z2 = zoneText(p, 'Z2')
  if (day === 'tor') return withSprints({ title: 'Z2', desc: `Mirno ${z2}, kadenca 90+.`, min, zone: 'Z2', tss: tssOf(min, 0.64), target: null, role: 'lahka', why: WHY_EASY }, n === 3)
  if (n === 1) return { title: 'Z2 + 5 × 1 min visoka kadenca', desc: `Mirno ${z2}; na sredi 5 × 1 min pri 110+ obratih (lahko, brez sile), vmes 3 min normalno.`, min, zone: 'Z2', tss: tssOf(min, 0.64), target: null, role: 'lahka', why: WHY_EASY }
  if (n === 2) return { title: 'Z2 + klanci z nizko kadenco', desc: `${z2}; na klancu 4 × 5 min sede pri 60–70 obratih (Z2–spodnja Z3, sila v pedalih, ne v dihanju), vmes navzdol lahko.`, min, zone: 'Z2', tss: tssOf(min, 0.68), target: null, role: 'lahka', why: 'Moč za klance brez visokega utripa — pripravi noge na intervale.' }
  return intervals(p, { name: 'Tempo', reps: 3, work: 10, rest: 5, a: 0.76, b: 0.85, z: 'Z3', note: 'Prvi malo trši trening sezone: enakomerno, pogovor še mogoč v kratkih stavkih.', why: 'Most do sweet spota in VO2max v naslednjih tednih.', min })
}
function hills(p: Profile, min: number, long = false): Sess {
  const hr = lthrZoneText(p, 'Z2')
  return { title: long ? 'Hribi — daljša tura' : 'Hribi', desc: `${Math.floor(min / 60)} h${min % 60 ? ` ${min % 60} min` : ''} hoje v hribe, gor v pogovornem tempu${hr ? ` (${hr})` : ''}, navzdol mirno. Brez ure in ciljev — samo uživaj.`, min, zone: 'Z2', tss: Math.round((min / 60) * 45), target: null, role: long ? 'dolga' : 'lahka', why: 'Off-season: gibanje brez pritiska, noge in glava se odpočijejo od kolesa.', kind: 'pohod' }
}
const feel = (p: Profile, min: number): Sess => ({ title: 'Po občutku', desc: `${min} min kolesa brez ure ali cilja — lahko, kjer ti je lepo (Z1–Z2${p.ftp ? `, pod ~${Math.round(p.ftp * 0.7)} W` : ''}). Lahko tudi tek, plavanje ali igra z žogo.`, min, zone: 'Z2', tss: tssOf(min, 0.58), target: null, role: 'lahka', why: 'Off-season: brez intervalov in brez pritiska — svežina za novo sezono.' })

/* ---------- vročina: pred poletnimi cilji ---------- */
/** Prilagoditev na vročino brez termometra: toplejša oblačila na lahkih vožnjah (10–14 dni pred poletnim ciljem). */
const HEAT = 'Prilagoditev na vročino (brez termometra): obleci se za ~10–15 °C topleje kot običajno (dolga majica + jopič ali pulover + dolge hlače). Vozi Z2 kot sicer; zadnjih 30–40 min naj ti bo vroče in se močno potiš, a še lahko govoriš. Utrip bo za isti tempo ~10 udarcev višji — tempa ne dvigaj. Pij po žeji z elektroliti; stehtaj se pred in po (izguba do ~2 % teže je v redu). Takoj nehaj in se ohladi ob glavobolu, vrtoglavici, slabosti, mrazenju, kurji koži ali zmedenosti. Če je zunaj nad 25 °C, vozi raje v najtoplejšem delu dneva v običajni opremi. Alternativa: 20–30 min savne ali tople kopeli takoj po lahki vožnji.'
function heat(s: Sess): Sess {
  return { ...s, title: `${s.title} · vročina`, desc: `${s.desc} ${HEAT}`, why: 'Poletna tekma: po 10–14 dneh vročinskih treningov se poveča volumen krvi in začneš prej potiti — v vročini zmoreš več. Kakovostni treningi ostanejo hladni.' }
}

/* ====================================================================
   TEDEN
   ==================================================================== */
export function buildWeek(inp: PlanInput): PlanDay[] {
  const p0 = inp.profile
  const start = inp.weekStart || weekStartIso(todayIso())
  // po off-seasonu je FTP nekaj % nižji, dokler ga ne izmeriš — vati v načrtu iz tega
  const p: Profile = { ...p0, ftp: ftpForWeek(p0, start) }
  const ctx = weekContext(p0, start)
  // vrh forme (cilj sezone), h kateremu gre ta teden — vrsta dirke določa specifični blok; po zadnjem vrhu naslednji cilj A
  const goal = peakGoals(p0).find(g => weekStartIso(g.date) >= start) ?? seasonGoals(p0).find(g => weekStartIso(g.date) >= start) ?? null
  const rain = inp.rain || {}
  const now = new Date().toISOString()
  const days = Array.from({ length: 7 }, (_, i) => addDays(start, i))
  const notBefore = inp.notBefore || todayIso()
  const open = (i: number) => days[i]! >= notBefore

  // utrujenost: pri TSB pod −25 teden −15 % (ne v razbremenitvi, taperingu ali tednu dirke) — samo, ko je forma zanesljiva
  // (vsaj 42 dni zgodovine ali stanje iz intervals.icu); prej je TSB le ocena in nov uporabnik ni »utrujen«
  const series = formSeries(inp.activities)
  const tsb = series.length ? series[series.length - 1]!.tsb : 0
  const tired = !ctx.recovery && ctx.phase !== 'tapering' && ctx.phase !== 'dirka' && ctx.phase !== 'po' && tsb < -25 && formReliable(inp.activities)
  // ure iz resnice: po bolezni, premoru ali tednih z manj treninga načrt ne skoči na tabelo, ampak raste od dejanskih ur
  const ph = planHours(p0, inp.activities, start)
  const total = Math.round(ph.hours * 60 * (tired ? 0.85 : 1))
  // proračun tedna (min na kolesu brez tekem): največ 1,1 × cilj tedna; razbremenilni ≤ 70 %, tapering ≤ 60 % zadnjega obremenilnega tedna
  const prevLoad = ctx.recovery || ctx.phase === 'tapering' ? prevLoadMin(p0, start) : null
  const budget = Math.round(Math.min(total * 1.1, prevLoad != null ? prevLoad * (ctx.phase === 'tapering' ? 0.6 : 0.7) : Infinity))
  const W = Math.min(total, budget)                          // koliko sestaviti v razbremenilnem tednu in taperingu
  const withTest = ctx.test || (!!inp.firstWeek && !ctx.easy && ctx.phase !== 'prehod' && ftpStale(p0, start))
  // moč samo v izbranih fazah (npr. fitnes v osnovi do januarja; potem jedro po želji)
  const strPhase = !p.strength.phases || !p.strength.phases.length || p.strength.phases.includes(ctx.phase)
  const strDays = p.strength.on && strPhase ? clamp(p.strengthDays ?? 2, 0, 2) : 0
  const gym = p.strength.equipment === 'gym'

  // sestava: po dnevih (0 = pon … 6 = ned) seznam sej
  const slot: (Sess | null)[] = Array(7).fill(null)
  const moc: (StrengthKind | null)[] = Array(7).fill(null)
  let light = false
  let carbDay: number | null = null                       // dan počitka s polnjenjem OH pred dolgo dirko

  if (ctx.phase === 'prehod') {
    // off-season brez intervalov in moči: počitek (vse po želji) → aktivni počitek (2 × po občutku, 2 × hribi) → vrnitev (lahke vožnje)
    const T4 = Math.max(120, total)
    if (ctx.offStage === 'pocitek') {
      slot[2] = { ...hills(p, 90), title: 'Sprehod ali hribi', desc: 'Po želji: sprehod ali lahka tura v hribe, brez ure. Ta teden je počitek — kolo lahko počiva.', optional: true }
      slot[5] = { ...hills(p, clamp(r5(T4 * 0.5), 90, 180), true), desc: 'Po želji: tura v hribe z družbo, v pogovornem tempu. Nič ne štejemo.', optional: true }
    } else if (ctx.offStage === 'vrnitev') {
      slot[1] = { ...z2Ride(p, clamp(r5(T4 * 0.2), 45, 90)), title: 'Lahka vožnja', why: 'Vrnitev na kolo: navada in lahko vrtenje, še brez struktur.' }
      slot[3] = { ...z2Ride(p, clamp(r5(T4 * 0.2), 45, 90)), title: 'Lahka vožnja', why: null }
      slot[5] = { ...z2Ride(p, clamp(r5(T4 * 0.35), 60, 150), true), title: 'Lahka daljša vožnja', why: null }
      slot[6] = hills(p, clamp(r5(T4 * 0.25), 60, 150))
    } else {
      slot[1] = feel(p, clamp(r5(T4 * 0.18), 45, 90))
      slot[2] = hills(p, clamp(r5(T4 * 0.3), 90, 180))
      slot[4] = feel(p, clamp(r5(T4 * 0.18), 45, 90))
      slot[5] = hills(p, clamp(r5(T4 * 0.34), 120, 240), true)
    }
  } else if (ctx.phase === 'po') {
    // po cilju: lahko in po občutku (pri velikem obsegu malo več, a brez intervalov)
    const d = clamp(r5(total * 0.22), 60, 120)
    slot[1] = z2Ride(p, d); slot[3] = z2Ride(p, d); slot[5] = z2Ride(p, clamp(r5(total * 0.36), 90, 180), true)
  } else if (ctx.phase === 'dirka' && goal) {
    // teden cilja sezone: dirka na njen dan v tednu (ne nujno nedelja)
    const ri = Math.max(0, days.indexOf(goal.date))
    const load = raceMinutes(goal) >= CARB_LOAD_RACE_MIN
    const km = W >= 180 ? 60 : 0                             // pri malo urah ključni treningi brez dodatne Z2
    slot[ri] = goalSess(p, goal)
    if (ri >= 1) slot[ri - 1] = openers(p, load)
    if (ri >= 3) slot[ri - 3] = { ...intervals(p, { name: 'Tempo dirke', reps: 3, work: 3, rest: 3, a: 0.95, b: 1.02, z: 'Z4', note: 'Občutek za tempo dirke.', min: Math.min(50, km) }), drop: 2 }
    if (ri >= 4) slot[ri - 4] = { ...z2Ride(p, 45), title: 'Lahka Z2' }
    if (ri >= 5) slot[ri - 5] = { ...intervals(p, { name: 'Predaktivacija', reps: 4, work: 1, rest: 3, a: 1.15, b: 1.25, z: 'Z5', note: 'Samo odpre noge — ne utruja.', why: 'Teden dirke: kratko in ostro, da ostaneš oster.', min: km }), drop: 1 }
    if (ri + 1 <= 6) slot[ri + 1] = regen(p, 45)
    if (ri + 2 <= 6) slot[ri + 2] = z2Ride(p, 60)
    if (ri >= 2 && load) carbDay = ri - 2
  } else if (ctx.phase === 'tapering') {
    // ključna dva ostaneta (pri malo urah brez dodatne Z2), ostalo iz proračuna: ≤ 60 % zadnjega obremenilnega tedna
    const km = W >= 300 ? 60 : 0
    slot[1] = intervals(p, { name: 'VO2max', reps: 3, work: 3, rest: 3, a: 1.1, b: 1.15, z: 'Z5', note: 'Samo ohranja ostrino.', why: 'Tapering: manj volumna, intenzivnost ostane.', min: km })
    slot[3] = { ...intervals(p, { name: 'Prag', reps: 2, work: 8, rest: 5, a: 0.95, b: 1.0, z: 'Z4', note: 'Kontroliran občutek za tempo.', why: 'Tapering: kratko na pragu.', min: km }), drop: 1 }
    const rest = W - slot[1].min - slot[3].min
    const sat = rest >= 60 ? clamp(r5(rest * 0.5), 60, 180) : 0
    if (sat) {
      const when = sat >= 90 ? 'v drugi uri' : 'na sredi'
      slot[5] = goal?.type === 'sprint'
        ? { ...dolga(p, 'osnova', sat, false), title: 'Z2 + 3 × 1 min + 3 šprinti', desc: `Z2 ${zoneText(p, 'Z2')}; ${when} 3 × 1 min pri ${wtxt(p, 1.15, 1.25, 'Z5')} in 3 × 15 s šprint (vmes 5 min lahko). Gorivo 60–80 g/h.`, target: null }
        : { ...dolga(p, 'osnova', sat, false), title: 'Z2 + 3 × 5 min tempo dirke', desc: `Z2 ${zoneText(p, 'Z2')}; ${when} 3 × 5 min pri ${wtxt(p, 0.88, 0.95, 'Z3')}${goal?.type === 'kronometer' ? ' v aero položaju' : goal?.type === 'vzpon' || goal?.type === 'klanci' ? ' na klancu' : ''}. Gorivo 60–80 g/h — preizkusi, kar boš jedel na dirki.`, target: watts(p, 0.88, 0.95) }
    }
    const r2 = rest - sat, wed = r2 >= 90 ? clamp(r5(r2 * 0.5), 45, 90) : 0, sun = r2 - wed >= 40 ? clamp(r5(r2 - wed), 40, 90) : 0
    if (wed) slot[2] = z2Ride(p, wed)
    if (sun) slot[6] = z2Ride(p, sun, true)
    if (strDays > 0) { moc[1] = 'jedro'; light = true }
  } else if (ctx.recovery) {
    // pri velikem obsegu (razbremenilni teden nad 8 h) so tudi lahki dnevi daljši — razbremenitev je ~50 %, ne 30 %;
    // pri malo urah krajši (najmanj 40 min), da je teden res lažji: ≤ 70 % zadnjega obremenilnega tedna
    const hiR = total > 480, proR = total > 720, d1 = proR ? 120 : hiR ? 90 : clamp(r5(W * 0.22), 40, 60), fri = proR ? 60 : 0
    slot[1] = { ...z2Ride(p, d1), title: 'Z2 + 4 × 30 s pospeški', desc: `Lahko ${zoneText(p, 'Z2')}; na sredi 4 × 30 s hitra kadenca (ne sila). Razbremenilni teden.` }
    slot[3] = z2Ride(p, d1)
    if (fri) slot[4] = regen(p, fri)
    if (withTest) { slot[5] = testSess(p); const sun = r5(W - 2 * d1 - fri - 60); if (sun >= 40) slot[6] = z2Ride(p, Math.min(sun, proR ? 240 : hiR ? 180 : 120), true) }
    else {
      const rest = W - 2 * d1 - fri, sat = clamp(r5(rest * 0.6), 60, proR ? 270 : hiR ? 210 : 150), sun = r5(rest - sat)
      slot[5] = sat >= 90 ? dolga(p, ctx.phase, sat, true) : { ...z2Ride(p, sat, true), title: 'Z2 — daljša vožnja' }
      if (sun >= 40) slot[6] = z2Ride(p, Math.min(sun, proR ? 210 : hiR ? 150 : 90), true)
    }
    if (strDays > 0) { moc[4] = 'jedro'; light = true }
  } else if (ctx.easy) {
    // lahek začetek sezone (3 tedne): torek Z2 + šprinti, četrtek kadenca → nizka kadenca na klancu → tempo; brez VO2max in praga
    const n = ctx.easy
    const tue = clamp(r5(total * 0.15), 45, 120), thu = clamp(r5(total * 0.16), 45, 120)
    slot[1] = easyKey(p, n, 'tor', tue); slot[3] = withTest ? testSess(p) : easyKey(p, n, 'cet', thu)
    const R = Math.max(90, total - slot[1].min - slot[3].min)
    const sat = clamp(r5(R * 0.45), 60, 300), wed = R >= 200 ? clamp(r5(R * 0.25), 45, 180) : 0, sun = clamp(r5(R - sat - wed), 45, 240)
    slot[5] = sat >= 90 ? (n === 2 ? longOf(p, { ...ctx, phase: 'osnova', blockWeek: 2 }, goal, sat) : dolga(p, 'osnova', sat, false)) : { ...z2Ride(p, sat, true), title: 'Z2 — daljša vožnja' }
    if (wed) slot[2] = z2Ride(p, wed)
    slot[6] = z2Ride(p, sun, true)
    if (strDays >= 2) { moc[1] = 'jedro'; moc[4] = 'noge' } else if (strDays === 1) moc[4] = 'noge'
    light = n === 1                                        // prvi teden tudi moč lažje
  } else if (total < 330) {
    // malo ur (začetek, načrt raste od tvojih dejanskih ur): EN ključni trening, ostalo Z2 — tako 80/20 drži tudi pri 4–5 h
    const key = withTest ? testSess(p) : ctx.blockWeek === 2 ? k2Of(p, ctx, goal) : k1Of(p, ctx, goal)
    slot[1] = key
    const R = Math.max(90, total - key.min)
    const sat = clamp(Math.max(r5(R * 0.55), Math.min(longFor(goal, ctx.phase), r5(R - 45))), 60, 180)
    const thu = clamp(r5(R - sat), 45, 90)
    slot[3] = withSprints(z2Ride(p, thu), goal?.type === 'sprint' && ctx.phase === 'specificno')
    slot[5] = sat >= 90 ? longOf(p, ctx, goal, sat) : { ...z2Ride(p, sat, true), title: 'Z2 — daljša vožnja' }
    const nStr = ctx.phase === 'specificno' ? Math.min(1, strDays) : strDays
    if (nStr >= 2) { moc[1] = 'jedro'; moc[4] = 'noge' } else if (nStr === 1) moc[4] = 'noge'
  } else {
    const k1 = k1Of(p, ctx, goal)
    const k2 = withTest ? testSess(p) : k2Of(p, ctx, goal)
    let R = total - k1.min - k2.min
    slot[1] = k1; slot[3] = k2
    if (R < 240) {
      // malo ur: dolga + ena Z2, brez srede in regeneracije
      const sat = clamp(Math.max(r5(R * 0.6), Math.min(longFor(goal, ctx.phase), r5(R - 45))), 60, 240), rest = r5(R - sat)
      slot[5] = longOf(p, ctx, goal, sat); if (rest >= 45) slot[6] = z2Ride(p, rest, true)
    } else {
      // profesionalni obseg (nad ~21 h): petek 2 h lahko, nad ~24 h še ponedeljek lahko vrtenje
      const pro = total > 1260
      const rg = pro ? 120 : R >= 330 ? 60 : R >= 270 ? 45 : 0
      R -= rg
      const mon = total > 1440 && open(0) ? 75 : 0
      if (mon) { slot[0] = { ...regen(p, mon), title: 'Lahko vrtenje', why: 'Pri velikem obsegu tudi ponedeljek ni prazen — samo kri po nogah.' }; R -= mon }
      // nad ~14,5 h na teden: višji stropi (sobota do 6 h, sreda in nedelja do 4 h; profi do 6,5 / 5,5 / 5,5 h), preostanek kot Z2 po ključnih treningih
      const hi = R > 630
      // pred dolgo dirko dolga vožnja vsaj ~80 % trajanja dirke (sreda in nedelja krajši)
      const satCap = pro ? 390 : hi ? 360 : 300
      const sat = clamp(Math.max(r5(R * 0.47), Math.min(longFor(goal, ctx.phase), satCap, r5(R - 150))), 120, Math.max(satCap, Math.min(390, longFor(goal, ctx.phase))))
      const wed = clamp(r5((R - sat) * 0.57), 60, pro ? 330 : hi ? 240 : 180)
      const sun = clamp(r5(R - sat - wed), 45, pro ? 330 : hi ? 240 : 150)
      // sreda: Z2 s šprinti vsak teden (pred šprintersko dirko daljši šprinti)
      slot[2] = withSprints(z2Ride(p, wed), goal?.type === 'sprint' && ctx.phase === 'specificno'); if (rg) slot[4] = regen(p, rg)
      slot[5] = longOf(p, ctx, goal, sat); slot[6] = z2Ride(p, sun, true)
      const left = hi ? r5(R - sat - wed - sun) : 0
      if (left >= 20) {
        const ext = pro ? 180 : 90
        const canK2 = slot[3]!.role !== 'test'
        const a1 = Math.min(ext, canK2 ? r5(left / 2) : left), a2 = canK2 ? Math.min(ext, r5(left - a1)) : 0
        slot[1] = longer(p, slot[1]!, a1); if (a2 >= 15) slot[3] = longer(p, slot[3]!, a2)
      }
    }
    if (ctx.phase === 'specificno' && slot[6] && goal?.type !== 'vzpon' && goal?.type !== 'kronometer') slot[6] = { ...slot[6], title: 'Skupinska vožnja ali Z2 + 6 × 30 s', desc: `V skupini vadi zavetrino in položaj v sredini — ista hitrost za 100 W manj. Sam: Z2 (${zoneText(p, 'Z2')}) s 6 × 30 s napadom${p.ftp ? ` (${Math.round(p.ftp * 1.5)} W in več)` : ' (nad 150 % FTP)'}, vmes 4 min lahko.`, why: 'Na dirki se skupina lomi v 30-sekundnih pospeških — te moraš preživeti.' }
    const nStr = ctx.phase === 'specificno' ? Math.min(1, strDays) : strDays
    if (nStr >= 2) { moc[1] = 'jedro'; moc[4] = 'noge' } else if (nStr === 1) moc[4] = 'noge'
    light = ctx.phase === 'specificno'
  }

  // vreme: dolga vožnja na bolj suh vikend dan
  const rs = rain[days[5]!] ?? 30, rn = rain[days[6]!] ?? 30
  if (slot[5]?.role === 'dolga' && slot[6]?.role === 'lahka' && rs >= 50 && rn + 20 <= rs) { const t = slot[5]; slot[5] = slot[6]; slot[6] = t }

  // osnova: nedeljska Z2 je lahko tudi hribi
  if (ctx.phase === 'osnova' && slot[6]?.role === 'lahka') slot[6] = { ...slot[6], desc: `${slot[6].desc} Namesto kolesa lahko greš v hribe — pri dnevu »Hribi namesto kolesa«.` }

  // poletni cilj (jun–avg): zadnja dva tedna pred njim do 3 lahke vožnje v toplejših oblačilih (prilagoditev na vročino)
  const summer = !!goal && [6, 7, 8].includes(+goal.date.slice(5, 7))
  if (summer && (ctx.phase === 'specificno' || ctx.phase === 'tapering') && ctx.weeksToEvent != null && ctx.weeksToEvent <= 2) {
    let n = 0
    for (const j of [2, 6, 1, 4]) { const x = slot[j]; if (n < 3 && x && x.role === 'lahka' && x.min <= 120 && !x.kind && /^(Z2|Lahka Z2)/.test(x.title) && !/šprint|pospešk|×/.test(x.title)) { slot[j] = heat(x); n++ } }
  }

  // druge tekme (B/C in cilji A, ki niso vrh tega tedna): dan prej predaktivacija, dan po lahko, pri pomembni (B) dva dni prej
  // brez trdega in teden −20 %, tekma za trening (C) nadomesti ključni trening. Dneva tekme (tudi cilja sezone) in polnjenja z OH
  // pred njim nič ne prepiše; dve tekmi na isti dan ostaneta vidni v enem dnevu (načrt velja za pomembnejšo).
  const races = racesAround(p0, days, ctx.phase === 'dirka' ? goal?.id ?? null : null)
  const testAt = slot.findIndex(x => x?.role === 'test'), test0 = testAt >= 0 ? slot[testAt]! : null
  const carbDays = new Set<number>(carbDay != null ? [carbDay] : [])
  const locked = (j: number) => j < 0 || j > 6 || slot[j]?.role === 'dirka' || carbDays.has(j)
  const raceIdAt = new Map<number, string>()
  const sameDay = new Map<number, Race[]>()
  for (const { i, race } of races) sameDay.set(i, [...(sameDay.get(i) || []), race])
  for (const [i, list] of [...sameDay.entries()].sort((a, b) => a[0] - b[0])) {
    const race = [...list].sort((a, b) => (a.prio === b.prio ? sideRaceMinutes(b) - sideRaceMinutes(a) : a.prio === 'B' ? -1 : b.prio === 'B' ? 1 : 0))[0]!
    const load = sideRaceMinutes(race) >= CARB_LOAD_RACE_MIN
    if (i === 7) { if (!locked(6)) { slot[6] = openers(p, load); moc[6] = null } continue }          // tekma v ponedeljek naslednjega tedna
    if (slot[i]?.role === 'dirka') {
      // isti dan kot cilj sezone: cilj ostane, druga tekma je zapisana zraven
      slot[i] = { ...slot[i]!, why: `${slot[i]!.why ? slot[i]!.why + ' ' : ''}Isti dan tudi ${list.map(r => r.name).join(', ')} — cilj sezone ima prednost.` }
      continue
    }
    const s = raceSess(p, race)
    slot[i] = list.length > 1
      ? { ...s, title: `${[race, ...list.filter(r => r !== race)].map(r => r.name).join(' + ')}${race.distanceKm ? ` — ${race.distanceKm} km` : ''}`, why: `Na isti dan ${list.length === 2 ? 'sta dve tekmi' : `je ${list.length} tekem`} — izberi eno; načrt velja za ${race.name}. ${s.why ?? ''}`.trim() }
      : s
    raceIdAt.set(i, race.id); moc[i] = null
    if (!locked(i - 1)) { slot[i - 1] = openers(p, load); moc[i - 1] = null }
    if (i - 2 >= 0) moc[i - 2] = null                                          // moč (težke noge) ne tik pred tekmo
    if (!locked(i + 1)) { slot[i + 1] = race.prio === 'B' ? regen(p, 45) : z2Ride(p, 60); moc[i + 1] = null }
    if (race.prio === 'B') {
      if (!locked(i - 2) && slot[i - 2] && hard(slot[i - 2]!)) slot[i - 2] = z2Ride(p, Math.min(60, slot[i - 2]!.min))
      for (let j = 0; j < 7; j++) { const x = slot[j]; if (x && !locked(j) && !x.fixed && Math.abs(j - i) > 2 && (x.role === 'lahka' || x.role === 'dolga')) slot[j] = { ...x, min: Math.min(x.min, Math.max(45, r5(x.min * 0.8))), tss: Math.round(x.tss * 0.8) } }
    } else {
      const keys = slot.map((x, j) => (x?.role === 'kljucna' && j !== i ? j : -1)).filter(j => j >= 0)
      if (keys.length >= 2) { const k = keys.sort((a, b) => Math.abs(a - i) - Math.abs(b - i))[0]!; slot[k] = z2Ride(p, Math.min(75, slot[k]!.min)) }
    }
    if (load && !locked(i - 2)) carbDays.add(i - 2)                             // dolga tekma: 2 dni prej polnjenje z OH
  }
  if (test0 && races.length && !slot.some(x => x?.role === 'test')) {
    // test je padel na tekmo ali tik ob njo — na dan vsaj 2 dni od tekme (prost, sicer namesto ključnega ali lahkega); sicer naslednjič
    const ok = (j: number) => open(j) && !locked(j) && races.every(r => Math.abs(r.i - j) >= 2)
    const to = [1, 2, 3, 4, 5, 6].find(j => ok(j) && !slot[j]) ?? [1, 2, 3, 4, 5, 6].find(j => ok(j) && slot[j]?.role === 'kljucna') ?? [1, 2, 3, 4, 5, 6].find(j => ok(j) && (slot[j]?.role === 'lahka' || slot[j]?.role === 'regen'))
    if (to != null) slot[to] = test0
  }

  // začetek sredi tedna: test ne sme pasti mimo — premakni ga na prvi prost dan (čet, pet, ned)
  if (withTest && slot.some(s => s?.role === 'test')) {
    const ti = slot.findIndex(s => s?.role === 'test')
    if (!open(ti)) {
      const to = [3, 4, 6, 2].find(i => open(i) && !locked(i) && slot[i]?.role !== 'dolga')
      if (to != null) { slot[to] = slot[ti]!; slot[ti] = null }
    }
  }

  // teden v proračun (najmanjše dolžine sej pri malo urah ne smejo narediti tedna daljšega od cilja)
  fitWeek(p, slot, budget, open)

  const CARB_TXT = 'Danes in jutri 8–10 g ogljikovih hidratov na kg (riž, testenine, kruh, sok), malo vlaknin in maščob.'
  const out: PlanDay[] = []
  const base = (date: string) => ({ id: uid(), date, source: 'rules' as const, createdAt: now, updatedAt: now, done: null })
  days.forEach((date, i) => {
    const s = slot[i], mk = moc[i]
    if (!open(i)) {
      out.push({ ...base(date), kind: 'pocitek', title: 'Pred začetkom', desc: 'Ta dan je bil pred začetkom načrta.', durationMin: 0, zone: null, tssTarget: 0, why: null })
      return
    }
    const carb = carbDays.has(i)
    if (!s && !mk) {
      out.push({ ...base(date), kind: 'pocitek', title: carb ? 'Počitek + polnjenje OH' : 'Počitek', desc: carb ? `${CARB_TXT} Noge gor.` : i === 0 ? 'Popoln počitek. Po želji 10 min raztezanja ali jedra.' : 'Prosto — spanec in hrana sta del treninga.', durationMin: 0, zone: null, tssTarget: 0, why: i === 0 ? 'Prilagoditev se zgodi med počitkom, ne med treningom.' : null })
      return
    }
    if (s) {
      const kind: PlanKind = s.kind ?? (s.role === 'test' ? 'test' : 'kolo')
      const rid = s.role === 'dirka' ? raceIdAt.get(i) ?? null : null
      out.push({ ...base(date), kind, title: s.title, desc: carb && !s.optional ? `${s.desc} ${CARB_TXT}` : s.desc, durationMin: s.min, zone: s.zone, tssTarget: s.tss, why: s.why, role: s.role, target: s.target, ...(rid ? { raceId: rid } : {}), ...(s.optional ? { optional: true } : {}) })
    }
    if (mk) {
      // fitnes: težke noge v torek (trd dan ostane trd, sreda–sobota sveže), petek enonožne + hrbet in jedro; 1 × na teden = težke noge
      const kindG: StrengthKind = gym ? (i === 1 || strDays === 1 ? 'fitnesA' : 'fitnesB') : mk
      const st = strengthSession(kindG, p, inp.activities, light)
      out.push({ ...base(date), kind: 'moc', title: st.title, desc: st.desc, durationMin: st.min, zone: null, tssTarget: Math.round(st.min * (gym ? 1 : 0.8)), exercises: st.exercises, role: 'moc', why: gym ? 'Težka moč izven sezone = boljša ekonomičnost in več moči na klancu (2 × na teden do konca osnove, nato vzdrževanje ali samo jedro).' : mk === 'jedro' ? 'Močan trup, stabilna drža na kolesu.' : 'Noge za klance, zaščita pred poškodbami.' })
    }
  })

  // razlaga tedna — na prvi aktivni dan
  const f = out.find(d => d.kind !== 'pocitek' && d.kind !== 'moc')
  if (f) {
    const h = ph.hours.toString().replace('.', ',')
    const capNote = ph.capped ? ` Manj od cilja (${ctx.hours.toString().replace('.', ',')} h): zadnje tedne si treniral ~${(ph.base ?? 0).toString().replace('.', ',')} h, načrt raste od tega.` : ''
    const head = ctx.phase === 'prehod'
      ? `Off-season (teden ${ctx.week}/${Math.round(p0.offSeasonWeeks ?? 1)}${ctx.offStage === 'pocitek' ? ', počitek' : ctx.offStage === 'vrnitev' ? ', vrnitev' : ', aktivni počitek'}) · ~${h} h: ${ctx.offStage === 'pocitek' ? 'kolo počiva, vse je po želji — sprehod, hribi, družba.' : ctx.offStage === 'vrnitev' ? 'lahke vožnje brez struktur, navada nazaj.' : 'hribi, vožnja po občutku, drugi športi — brez intervalov in brez ure.'} Nato lahki tedni osnove in počasna gradnja.`
      : ctx.easy
      ? `Lahek začetek sezone (teden ${ctx.easy}/3) · ${h} h: Z2, šprinti in ${ctx.easy === 1 ? 'visoka kadenca' : ctx.easy === 2 ? 'klanci z nizko kadenco' : 'prvi tempo'} — VO2max in prag pridejo v 4. tednu.`
      : ctx.weeksToEvent != null && ctx.weeksToEvent > 0
      ? `${ctx.phaseName}${ctx.recovery ? ' · razbremenilni teden' : ctx.phase === 'tapering' ? '' : ` · ${ctx.blockWeek}. teden bloka`} · ${h} h. ${ctx.event!.name} čez ${ctx.weeksToEvent} ${ctx.weeksToEvent === 1 ? 'teden' : ctx.weeksToEvent === 2 ? 'tedna' : ctx.weeksToEvent < 5 ? 'tedne' : 'tednov'}${goal && ctx.phase === 'specificno' ? ` (${RACE_TYPES[goal.type].l.toLowerCase()}: ${RACE_TYPES[goal.type].d})` : ''}.`
      : `${ctx.phaseName} · ${h} h.`
    const ftpNote = p.ftp && p0.ftp && p.ftp < p0.ftp && ctx.phase !== 'prehod' ? `Vati so iz FTP po off-seasonu ~${p.ftp} W (${Math.round((p.ftp / p0.ftp - 1) * 100)} %), dokler ga ne izmeriš s testom.` : ''
    const heatNote = out.some(d => /· vročina$/.test(d.title)) ? `Poletni cilj ${goal!.name}: lahke vožnje s » · vročina« so v toplejših oblačilih (navodila pri dnevu).` : ''

    const rl = races.filter(r => r.i < 7).map(r => `Tekma v ${dayAcc(r.race.date)}: ${r.race.name} (${r.race.prio === 'B' ? 'pomembna — dan prej samo predaktivacija, teden −20 %' : 'za trening — nadomesti ključni trening'}).`).join(' ')
    f.why = [head + capNote, ftpNote, heatNote, rl, tired ? `Ta teden −15 %: forma je ${Math.round(tsb)} (utrujenost visoka).` : '', f.why || ''].filter(Boolean).join(' ')
  }
  return out
}

/** Skupno načrtovano trajanje tedna (min) — brez neobveznih dni. */
export function weekMinutes(days: readonly PlanDay[]): number { return days.filter(d => !d.optional).reduce((s, d) => s + (d.durationMin || 0), 0) }
/** Ure na kolesu (brez moči) — primerjava s ciljem tedna. */
export function weekBikeMinutes(days: readonly PlanDay[]): number { return days.filter(d => !d.optional && (d.kind === 'kolo' || d.kind === 'test')).reduce((s, d) => s + (d.durationMin || 0), 0) }

/**
 * Napovedana forma na zadnji dan tedna, če opraviš vse načrtovano — vključno z današnjo sejo, ki še ni opravljena
 * (danes = izmerjeno do zdaj + načrtovano, kar še pride).
 */
export function forecastForm(activities: readonly Activity[], week: readonly PlanDay[], today: string = todayIso()): { ctl: number; atl: number; tsb: number; date: string } | null {
  if (!week.length) return null
  const s = formSeries(activities, today)
  // izhodišče: stanje ob koncu včeraj; današnja izmerjena obremenitev se prišteje spodaj skupaj z načrtom
  let prev: (typeof s)[number] | undefined
  for (let i = s.length - 1; i >= 0; i--) if (s[i]!.date < today) { prev = s[i]; break }
  const cur = s.find(x => x.date === today)
  let ctl = prev ? prev.ctl : cur ? cur.ctl : 0, atl = prev ? prev.atl : cur ? cur.atl : 0
  const measuredToday = prev ? cur?.tss ?? 0 : 0
  const byDate = new Map<string, number>()
  for (const d of week) if (d.date >= today && !d.done) byDate.set(d.date, (byDate.get(d.date) || 0) + (d.tssTarget || 0))
  const last = [...week].sort((a, b) => a.date.localeCompare(b.date))[week.length - 1]!.date
  if (last < today) { const x = cur ?? prev; return { ctl: Math.round(x?.ctl ?? 0), atl: Math.round(x?.atl ?? 0), tsb: Math.round((x?.ctl ?? 0) - (x?.atl ?? 0)), date: last } }
  for (let d = today; d <= last; d = addDays(d, 1)) {
    const tss = (byDate.get(d) || 0) + (d === today ? measuredToday : 0)
    ctl += (tss - ctl) / 42; atl += (tss - atl) / 7
  }
  return { ctl: Math.round(ctl), atl: Math.round(atl), tsb: Math.round(ctl - atl), date: last }
}

/** Minute po conah za načrtovan teden (ključne seje: 45 % v ciljni coni, 40 % Z2, 15 % Z1). */
export function zoneMinutes(week: readonly PlanDay[]): Record<'Z1' | 'Z2' | 'Z3' | 'Z4' | 'Z5', number> {
  const m = { Z1: 0, Z2: 0, Z3: 0, Z4: 0, Z5: 0 }
  for (const d of week) {
    if (d.kind === 'moc' || d.kind === 'pocitek' || d.optional) continue
    const raw = d.zone === 'test' ? 'Z4' : d.zone === 'dirka' ? 'Z3' : d.zone || 'Z2'
    const z = raw as keyof typeof m
    if (!(z in m)) continue
    const t = d.durationMin || 0
    if (d.role === 'kljucna' || d.role === 'test') {
      const w = Math.min(t, Math.round(t * 0.4))
      m[z] += w; m.Z2 += Math.round((t - w) * 0.7); m.Z1 += t - w - Math.round((t - w) * 0.7)
    } else if (z === 'Z1' || z === 'Z2') m[z] += t
    else { m[z] += Math.round(t * .45); m.Z2 += Math.round(t * .4); m.Z1 += Math.round(t * .15) }
  }
  return m
}

/**
 * »Olajšaj dan« brez AI: današnjo sejo prestavi na naslednji prost dan v tednu, danes pa ostane lahka Z1.
 * Nikoli na dan pred tekmo ali na dan polnjenja z OH; trd trening (ključni, test, dolga) nikoli ob drug trd dan ali tekmo
 * (sicer trije trdi dnevi zapored). Če takega dne ni, seja ta teden odpade — razlog je v `why` lahkega dne.
 * Vrne dneve za shranitev (po id-ju) ali null, če ni česa olajšati.
 */
export function easeDay(week: readonly PlanDay[], today: string): PlanDay[] | null {
  const cur = week.find(d => d.date === today && (d.kind === 'kolo' || d.kind === 'test') && !d.optional && !d.done)
  if (!cur) return null
  const busy = new Set(week.filter(d => d.kind !== 'pocitek' && d.kind !== 'moc' && !d.optional).map(d => d.date))
  const hardCur = isHardDay(cur)
  const hardAt = new Set(week.filter(d => d.id !== cur.id && !d.optional && isHardDay(d)).map(d => d.date))
  const raceAt = new Set(week.filter(d => d.role === 'dirka').map(d => d.date))
  const ok = (d: PlanDay) => d.date > today && !d.done && d.kind === 'pocitek' && !busy.has(d.date) && !/polnjenje/i.test(d.title)
    && !raceAt.has(addDays(d.date, 1))
    && (!hardCur || (!hardAt.has(addDays(d.date, -1)) && !hardAt.has(addDays(d.date, 1))))
  const later = [...week].filter(ok).sort((a, b) => a.date.localeCompare(b.date))[0]
  const now = new Date().toISOString()
  const out: PlanDay[] = []
  if (later) out.push({ ...cur, id: later.id, date: later.date, why: `Prestavljeno ${dayFrom(today)} zaradi nizke pripravljenosti.`, source: 'rules', updatedAt: now })
  const why = later ? `Seja je prestavljena na ${dayAcc(later.date)}.`
    : hardCur ? 'Ta seja ta teden odpade — ni prostega dne brez trdega treninga ali tekme ob njem; bolje en trening manj kot bolezen.'
    : 'Ta seja ta teden odpade — bolje en trening manj kot bolezen.'
  out.push({ ...cur, kind: 'kolo', title: 'Lahek dan — Z1', desc: 'Telo je dalo znak. 30–45 min zelo lahkega vrtenja ali sprehod, veliko vode, zgodaj spat.', durationMin: 40, zone: 'Z1', tssTarget: 20, target: null, role: 'regen', exercises: undefined, optional: true, why, source: 'rules', updatedAt: now })
  return out
}

/* ====================================================================
   PO PRETEŽKI VOŽNJI: DAN ZA TEM LAŽJE
   Namesto 45 min regeneracije so bile 3 ure → naslednji dan ne more biti po načrtu. Ključni trening gre na
   naslednji primeren lahki dan (nikoli ob drug trd dan ali tekmo), sicer ta teden odpade; lahka vožnja postane
   regeneracija. Tekma, počitek in že lahek dan ostanejo. Vse se da vrniti (adapt.prev).
   ==================================================================== */
const contentOf = (d: PlanDay): PlanContent => ({ kind: d.kind, title: d.title, desc: d.desc, durationMin: d.durationMin, zone: d.zone ?? null, tssTarget: d.tssTarget ?? null, role: d.role ?? null, target: d.target ?? null, kcalBurn: d.kcalBurn ?? null, why: d.why ?? null, optional: !!d.optional, ...(d.exercises ? { exercises: d.exercises } : {}) })
/** Načrtovana obremenitev dneva (TSS); počitek in moč 0. */
export const planLoad = (d: Pick<PlanDay, 'kind' | 'tssTarget' | 'durationMin' | 'zone'>): number =>
  d.kind === 'pocitek' || d.kind === 'moc' ? 0 : d.tssTarget ?? tssOf(d.durationMin || 0, d.zone === 'Z1' ? 0.5 : /Z[345]|test/.test(d.zone || '') ? 0.8 : 0.65)
const LOAD_SPORTS = new Set(['kolo', 'tek', 'pohod'])

export interface LoadAdapt {
  /** dan pretežke vožnje */ date: string
  /** dejanska in načrtovana obremenitev tega dne (TSS) */ actual: number; planned: number
  /** dan za tem (glavna seja pred prilagoditvijo); null = počitek */ next: PlanDay | null
  /** dnevi za shranitev (predlog); prazno pri info, prilagojeno in vrnjeno */ days: PlanDay[]
  /** kaj bo dan za tem — kratko, za kartico in obvestilo */ text: string
  state: 'predlog' | 'prilagojeno' | 'vrnjeno' | 'info'
}

/**
 * Ali je bila vožnja dneva `date` precej težja od načrta (≥ 60 TSS, ≥ 50 nad načrtom in ≥ 1,5 × načrt) in kaj to pomeni
 * za naslednji dan. null = ni bila pretežka ali je dan za tem že mimo.
 */
export function adaptAfterLoad(p: Profile, plan: readonly PlanDay[], acts: readonly Activity[], date: string, today: string): LoadAdapt | null {
  const mine = acts.filter(a => a.date === date && LOAD_SPORTS.has(a.sport))
  const actual = Math.round(mine.reduce((t, a) => t + (a.tss && a.tss > 0 ? a.tss : estimateTss(a, p)), 0))
  const planned = Math.round(plan.filter(d => d.date === date).reduce((t, d) => t + planLoad(d), 0))
  if (actual < 60 || actual - planned < 50 || actual < planned * 1.5) return null
  const tmr = addDays(date, 1)
  if (tmr < today) return null
  const Tw = tmr === today ? 'Danes' : 'Jutri'
  const day = plan.filter(d => d.date === tmr)
  const next = day.filter(d => !d.optional && (d.kind === 'kolo' || d.kind === 'test' || d.kind === 'tek' || d.kind === 'pohod')).sort((a, b) => planLoad(b) - planLoad(a))[0] ?? null
  const base = { date, actual, planned, next }
  // že prilagojeno (ali vrnjeno) po tem dnevu — tudi na drugi napravi
  const marked = plan.filter(d => d.adapt?.after === date)
  if (marked.length) {
    if (marked.every(d => d.adapt!.off)) return { ...base, days: [], state: 'vrnjeno', text: `${Tw} ostaja po prvotnem načrtu.` }
    const t = marked.find(d => d.date === tmr && !d.adapt!.off), mv = marked.find(d => d.date !== tmr && !d.adapt!.off)
    const what = t ? `${t.title.toLowerCase()} ${fmtDur(t.durationMin)}` : 'lažje', orig = t?.adapt?.prev?.title
    return { ...base, days: [], state: 'prilagojeno', text: `${Tw} ${what}${mv ? `, ${mv.title} je v ${dayAcc(mv.date)}` : orig ? ` namesto: ${orig}` : ''}.` }
  }
  if (next?.done) return null
  if (!next) {
    const moc = day.some(d => d.kind === 'moc' && !d.optional && !d.done)
    return { ...base, days: [], state: 'info', text: moc ? `${Tw} samo moč — če so noge težke, naredi manj serij.` : `${Tw} je počitek — ravno prav po taki vožnji.` }
  }
  if (next.role === 'dirka' || next.raceId) return { ...base, days: [], state: 'info', text: `${Tw} je tekma — načrta ne spreminjam. Zvečer več ogljikovih hidratov in zgodaj spat.` }
  if (next.kind !== 'kolo' && next.kind !== 'test') return { ...base, days: [], state: 'info', text: `${Tw}: ${next.title} — naredi krajše in lažje.` }
  if (next.role === 'regen' && next.durationMin <= 60) return { ...base, days: [], state: 'info', text: `${Tw} je že regeneracija — ravno prav.` }

  const now = new Date().toISOString()
  const rg = regen(p, clamp(r5(Math.min(45, next.durationMin || 45)), 30, 45))
  const why = `Po težki vožnji v ${dayAcc(date)} (${actual} TSS namesto ~${planned}) je ta dan lahek — telo se mora obnoviti, sicer trpijo naslednji treningi.`
  const easy = (d: PlanDay): PlanDay => ({ ...d, kind: 'kolo', title: rg.title, desc: rg.desc, durationMin: rg.min, zone: rg.zone, tssTarget: rg.tss, role: 'regen', target: null, kcalBurn: null, exercises: undefined, optional: false, swap: null, why, source: 'rules', updatedAt: now, adapt: { after: date, prev: contentOf(d) } })
  const lower = `${rg.title.toLowerCase()} ${fmtDur(rg.min)}`

  if (isHardDay(next)) {
    const rideMin = mine.filter(a => a.sport === 'kolo').reduce((t, a) => t + (a.durationMin || 0), 0)
    if (next.role === 'dolga' && rideMin >= next.durationMin * 0.7)
      return { ...base, days: [easy(next)], state: 'predlog', text: `${Tw} ${lower} namesto dolge vožnje — dolgo si že odpeljal.` }
    const end = addDays(weekStartIso(tmr), 6)
    const hardAt = new Set(plan.filter(d => d.id !== next.id && !d.optional && isHardDay(d)).map(d => d.date))
    const raceAt = new Set(plan.filter(d => d.role === 'dirka' || d.raceId).map(d => d.date))
    const cand = plan.filter(d => d.date > tmr && d.date <= end && !d.done && !d.optional && d.kind === 'kolo' && (d.role === 'lahka' || d.role === 'regen')
      && !hardAt.has(d.date) && !hardAt.has(addDays(d.date, -1)) && !hardAt.has(addDays(d.date, 1)) && !raceAt.has(d.date) && !raceAt.has(addDays(d.date, 1)))
      .sort((a, b) => a.date.localeCompare(b.date))[0]
    if (cand) {
      const moved: PlanDay = { ...cand, ...contentOf(next), why: `Prestavljeno ${dayFrom(tmr)}: dan po težki vožnji je lahek.`, source: 'rules', updatedAt: now, adapt: { after: date, prev: contentOf(cand) } }
      return { ...base, days: [easy(next), moved], state: 'predlog', text: `${Tw} ${lower}, ${next.title} gre na ${dayAcc(cand.date)}.` }
    }
    return { ...base, days: [easy(next)], state: 'predlog', text: `${Tw} ${lower} namesto: ${next.title} — ta teden ga ni kam prestaviti brez dveh trdih dni zapored.` }
  }
  return { ...base, days: [easy(next)], state: 'predlog', text: `${Tw} ${lower} namesto: ${next.title}, ${fmtDur(next.durationMin)}.` }
}

/** »Vrni prvotni načrt«: dnevom, prilagojenim po pretežki vožnji dneva `date`, vrne prvotno vsebino (oznaka ostane: ne prilagodi znova). */
export function undoLoadAdapt(plan: readonly PlanDay[], date: string): PlanDay[] {
  const now = new Date().toISOString()
  return plan.filter(d => d.adapt?.after === date && !d.adapt.off && d.adapt.prev && !d.done)
    .map(d => ({ ...d, ...d.adapt!.prev!, updatedAt: now, adapt: { after: date, off: true } }))
}

/* ====================================================================
   DRUGE TEKME, HRIBI NAMESTO KOLESA, JEDRO PO ŽELJI
   ==================================================================== */
/** Tekme v tem tednu (i = 0 … 6) in v ponedeljek naslednjega (i = 7, zaradi dneva prej). Glavni cilj ima svoj teden dirke. */
/** Tekme ta teden (in v ponedeljek naslednjega): B, C in cilji A, ki niso glavni dogodek tega tedna (ti štejejo kot B). */
function racesAround(p: Profile, days: readonly string[], goalId: string | null = null): { i: number; race: Race }[] {
  const next = addDays(days[6]!, 1)
  return (p.races || []).filter(r => r && r.date && r.date !== p.event?.date && r.id !== goalId && (days.includes(r.date) || r.date === next))
    .map(r => ({ i: r.date === next ? 7 : days.indexOf(r.date), race: r.prio === 'A' ? { ...r, prio: 'B' as const } : r })).sort((a, b) => a.i - b.i)
}
const hard = (x: Sess) => x.role === 'kljucna' || x.role === 'test' || (x.role === 'dolga' && x.min >= 150)
/** Dan pred tekmo; pred dolgo tekmo (≥ 150 min) še polnjenje z OH. Ne krajša se in ne odpade. */
function openers(p: Profile, load = false): Sess {
  const s = intervals(p, { name: 'Predaktivacija', reps: 3, work: 1, rest: 2, a: 1.1, b: 1.2, z: 'Z5', note: 'Dan pred tekmo: samo odpre noge, ne utruja. Zvečer več ogljikovih hidratov, zgodaj spat.', why: 'Jutri tekma — svež, a ne zaspan.', min: 40 })
  return { ...s, desc: `${s.desc}${load ? ' Danes in včeraj 8–10 g OH na kg (riž, testenine, kruh), malo vlaknin.' : ''}`, role: 'lahka', fixed: true }
}
/** OH na uro na tekmi po trajanju: 60+ g samo od 90 min naprej, krajša največ 30–60 g; null = pod 1 h, dovolj izotonik. */
function raceFuel(min: number, hi: string): string | null {
  return min >= FUEL_RACE_MIN ? hi : min >= 60 ? '30–60' : null
}

/** Minute zadnjega obremenilnega tedna pred tem (ne razbremenilni, off-season, po cilju, tapering, dirka); null brez njega. */
function prevLoadMin(p: Profile, weekStart: string): number | null {
  for (let k = 1; k <= 4; k++) {
    const ws = addDays(weekStart, -7 * k)
    if (!p.cycleStart || ws < p.cycleStart) return null
    const c = weekContext(p, ws)
    if (!c.recovery && c.phase !== 'prehod' && c.phase !== 'po' && c.phase !== 'tapering' && c.phase !== 'dirka') return Math.round(c.hours * 60)
  }
  return null
}

/** Krajša seja: nova dolžina, sorazmeren TSS; »dolga« pod 90 min postane navadna Z2, gorivo za ≥ 90 min odpade. */
function resize(p: Profile, s: Sess, min: number): Sess {
  if (s.role === 'dolga' && min < 90) return { ...z2Ride(p, min, true), title: 'Z2 — daljša vožnja' }
  const desc = (min < 90 ? s.desc.replace(' Od 30. minute ~40 g OH na uro.', '') : s.desc).replace(/^\d+ min kolesa/, `${min} min kolesa`)
  return { ...s, min, tss: s.min > 0 ? Math.round((s.tss * min) / s.min) : s.tss, desc }
}

/**
 * Teden v proračun (min na kolesu brez tekem in neobveznih dni): najprej se sorazmerno skrajšajo lahke, dolge in
 * regeneracijske vožnje (nobena pod 30 min), nato odpadejo najkrajše (regeneracija prva), nazadnje ključni treningi,
 * ki jih teden dovoli izpustiti (tapering, teden dirke). Tekme, test, ključni treningi in predaktivacija ostanejo.
 */
function fitWeek(p: Profile, slot: (Sess | null)[], budget: number, open: (i: number) => boolean): void {
  const DAYS = [0, 1, 2, 3, 4, 5, 6]
  const counts = (i: number) => { const x = slot[i]; return !!x && open(i) && !x.optional && (!x.kind || x.kind === 'test') && x.role !== 'dirka' }
  const sum = () => DAYS.reduce((t, i) => t + (counts(i) ? slot[i]!.min : 0), 0)
  // najmanj 30 min; seja s ponovitvami (šprinti, kadenca, klanci) ne krajša od svoje strukture z ogrevanjem in izvozom
  const floor = (s: Sess) => Math.max(30, minMinutes({ title: s.title, desc: s.desc, role: s.role }))
  for (let guard = 0; guard < 20; guard++) {
    const over = sum() - budget
    if (over <= 0) return
    const flex = DAYS.filter(i => counts(i) && !slot[i]!.fixed && (slot[i]!.role === 'lahka' || slot[i]!.role === 'dolga' || slot[i]!.role === 'regen'))
    const room = flex.reduce((t, i) => t + Math.max(0, slot[i]!.min - floor(slot[i]!)), 0)
    if (flex.length && room >= over) {
      for (const i of flex) {
        const r = slot[i]!.min - floor(slot[i]!)
        if (r <= 0) continue
        const cut = Math.min(r, Math.ceil((over * r) / room / 5) * 5)
        if (cut > 0) slot[i] = resize(p, slot[i]!, slot[i]!.min - cut)
      }
      continue
    }
    const rank = (i: number) => (slot[i]!.role === 'regen' ? 0 : slot[i]!.role === 'lahka' ? 1 : 2)
    const drop = [...flex].sort((a, b) => rank(a) - rank(b) || slot[a]!.min - slot[b]!.min || b - a)[0]
      ?? DAYS.filter(i => counts(i) && slot[i]!.drop != null).sort((a, b) => slot[a]!.drop! - slot[b]!.drop!)[0]
    if (drop == null) return
    slot[drop] = null
  }
}
function raceSess(p: Profile, r: Race): Sess {
  const km = r.distanceKm || null
  const t = raceTypeOf(r)
  const min = sideRaceMinutes(r)
  const tip: Record<RaceType, string> = {
    sprint: ' V zavetrini in blizu čela; zadnji kilometer v prvih 10, šprint 200–250 m pred ciljem.',
    vzpon: ' Ogrevanje 25 min; prvih 5 min ne prehitro, zadnja tretjina vse.',
    kronometer: ' Ogrevanje 25 min s 3 × 2 min na pragu; enakomerno, zadnjih 5 min vse.',
    klanci: p.ftp ? ` Na klancih enakomerno, ne čez ~${Math.round(p.ftp * 1.05)} W dlje kot 5 min; napade spremljaj le, če jih zmoreš.` : ' Na klancih enakomerno, napade spremljaj le, če jih zmoreš.',
    maraton: ' V zavetrini varčuj, dolge klance enakomerno.',
    cestna: p.ftp ? ` Na klancih ne čez ~${Math.round(p.ftp * 1.05)} W dlje kot 5 min, v zavetrini varčuj.` : ' Na klancih enakomerno, v zavetrini varčuj.',
  }
  const fuel = raceFuel(min, r.prio === 'B' ? '70–90' : '60–80')
  return {
    title: `${r.name}${km ? ` — ${km} km` : ''}`, min, zone: 'dirka', tss: tssOf(min, t === 'vzpon' || t === 'kronometer' ? 0.95 : r.prio === 'B' ? 0.82 : 0.78), target: null, role: 'dirka',
    desc: `Zajtrk 2–3 h prej (~2 g OH na kg), ogrevanje 15–20 min s 3 kratkimi pospeški.${tip[t]}${fuel ? ` Na kolesu ${fuel === '30–60' ? 'največ 30–60' : fuel} g OH na uro od 30. minute.` : ''}`,
    why: r.prio === 'B' ? 'Pomembna tekma: dva dni prej brez trdega, dan prej samo predaktivacija, dan po lahko.' : 'Tekma za trening: šteje kot ključni trening tega tedna — dan prej lahko, dan po lahko.',
  }
}
/** Cilj sezone na dan dirke: navodila po vrsti dirke. */
function goalSess(p: Profile, g: SeasonGoal): Sess {
  const min = raceMinutes(g), km = g.distanceKm
  const franja = /franj/i.test(g.name)
  const thr = watts(p, 0.95, 1.0)
  // gorivo po trajanju: 60+ g OH na uro samo od 90 min naprej (kratka dirka: največ 30–60 g, pod 1 h dovolj izotonik)
  const fuel = (hi: string) => { const f = raceFuel(min, hi); return f === '30–60' ? 'največ 30–60 g OH na uro' : f ? `${f} g OH na uro` : 'dovolj je izotonik' }
  const d: Record<RaceType, string> = {
    maraton: franja && min >= CARB_LOAD_RACE_MIN
      ? `Zajtrk 3 h pred startom (2–3 g OH/kg). Na kolesu ~85 g OH na uro od 30. minute (seznam in urnik v Gorivu), pijača z elektroliti. Ravnina v zavetrini, Vrhniški klanec mirno, Kladje (7 km, 6,3 %) enakomerno${thr ? ` pri ${thr.lo}–${thr.hi} W` : ' na pragu'} — ne po špicah skupine.`
      : `Zajtrk ${min >= CARB_LOAD_RACE_MIN ? '3 h' : '2–3 h'} pred startom (2–3 g OH/kg). Na kolesu ${fuel(min >= CARB_LOAD_RACE_MIN ? '80–90' : '60–80')}${min >= FUEL_RACE_MIN ? ' od 30. minute' : ''}, pijača z elektroliti. Ravnina v zavetrini, dolge klance enakomerno${thr ? ` do ~${thr.hi} W` : ' na pragu'} — ne po špicah skupine.`,
    vzpon: `Ogrevanje 25–30 min s 3 × 1 min na pragu. Prvih 5 min ne prehitro (${thr ? `~${thr.lo}–${thr.hi} W` : 'tik pod pragom'}), sredina enakomerno, zadnja tretjina vse.`,
    klanci: `Zajtrk 2–3 h prej. Na klancih enakomerno na pragu${thr ? ` (~${thr.hi} W)` : ''}, napade spremljaj le, če jih zmoreš; jej in pij od začetka (${fuel('70–90')}).`,
    sprint: 'Ogrevanje 20 min s 3 pospeški. V dirki v zavetrini in blizu čela; zadnji kilometer v prvih 10, šprint 200–250 m pred ciljem, iz zavetrja.',
    kronometer: `Ogrevanje 25–30 min s 3 × 2 min na pragu. Prvih 5 min ${thr ? `~${thr.lo} W` : 'pri 95 %'}, sredina ${thr ? `${thr.lo}–${thr.hi} W` : 'na pragu'}, zadnjih 5 min vse. Aero položaj, ravna linija.`,
    cestna: `Zajtrk 2–3 h prej. V zavetrini varčuj, na klancih enakomerno${thr ? ` do ~${thr.hi} W` : ''}; jej in pij od začetka (${fuel('60–90')}).`,
  }
  return { title: `${g.name}${km ? ` — ${km} km` : ''}`, desc: d[g.type], min, zone: 'dirka', tss: tssOf(min, g.type === 'vzpon' || g.type === 'kronometer' ? 0.95 : 0.76), target: g.type === 'vzpon' || g.type === 'kronometer' || franja ? thr : null, role: 'dirka', why: 'Cilj sezone — dan D.' }
}

/** Hribi namesto kolesa: lahki, dolgi in regeneracijski dnevi (ključni trening, test in tekma ne). */
export function canHike(d: Pick<PlanDay, 'kind' | 'role' | 'done'>): boolean {
  return d.kind === 'kolo' && !d.done && (!d.role || d.role === 'lahka' || d.role === 'dolga' || d.role === 'regen')
}
/** Enak aerobni učinek: vzpon v Z2 po utripu, ~15 % dlje od vožnje. Prvotni trening ostane v `swap` (nazaj z enim klikom). */
export function hikeSwap(d: PlanDay, p: Profile): PlanDay {
  const dur = clamp(r5(d.durationMin * 1.15), 60, 480)
  const hr = lthrZoneText(p, 'Z2')
  const h = (m: number) => `${Math.floor(m / 60)} h${m % 60 ? ` ${m % 60} min` : ''}`
  return {
    ...d, kind: 'pohod', title: d.role === 'dolga' ? 'Hribi — dolga tura' : 'Hribi namesto kolesa',
    desc: `${h(dur)} hoje v hribe: gor v Z2${hr ? ` (${hr})` : ' (še lahko govoriš v celih stavkih)'}, navzdol mirno. Enak aerobni učinek kot ${d.durationMin} min kolesa v Z2 — čim več vzpona, brez teka. Voda, nekaj za pojest; palice razbremenijo kolena navzdol.`,
    durationMin: dur, zone: 'Z2', tssTarget: Math.round((dur / 60) * 50), target: null, role: d.role === 'dolga' ? 'dolga' : 'lahka',
    swap: { kind: d.kind, title: d.title, desc: d.desc, durationMin: d.durationMin, zone: d.zone ?? null, tssTarget: d.tssTarget ?? null, role: d.role ?? null, target: d.target ?? null },
    why: 'Zamenjava: hribi so dober aerobni trening, pozimi pogosto prijetnejši od mrzlega kolesa.',
    updatedAt: new Date().toISOString(),
  }
}
export function swapBack(d: PlanDay): PlanDay {
  if (!d.swap) return d
  return { ...d, ...d.swap, swap: null, why: null, updatedAt: new Date().toISOString() }
}

/** Jedro po želji (15–20 min): neobvezno, ne šteje v realizacijo; ponovitve rastejo iz zadnje opravljene seje. */
export function coreOnDemand(p: Profile, activities: readonly Activity[], date: string): PlanDay {
  const st = strengthSession('jedro', p, activities)
  const now = new Date().toISOString()
  return { id: uid(), date, kind: 'moc', title: st.title, desc: `${st.desc} Po želji — ne šteje v realizacijo tedna.`, durationMin: st.min, zone: null, tssTarget: 15, exercises: st.exercises, role: 'moc', optional: true, why: 'Po želji: močan trup = stabilna drža, vsi vati gredo v pedala.', source: 'rules', createdAt: now, updatedAt: now, done: null }
}

