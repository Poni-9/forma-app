import type { Activity, PlanDay, PlanKind, Profile } from '../types'
import { addDays, formSeries, todayIso, weekStartIso } from './load'
import { zoneText } from './zones'

/**
 * NAČRT DO CILJA (osebna različica: Maraton Franja).
 * Makrocikel od začetka načrta do dneva dirke: osnova → gradnja → specifično → tapering → dirka.
 * V vsaki fazi bloki 3 + 1 (trije tedni rastoče obremenitve, četrti razbremenilni), 80/20:
 * pon počitek · tor VO2max + jedro · sre Z2 · čet prag / sweet spot · pet regeneracija + noge · sob dolga Z2 · ned Z2.
 * Vse deterministično — brez omrežja in brez AI. Vati iz FTP, ko ga poznamo.
 */

/** Verjetnost dežja po dnevih (0–100), če jo poznamo. */
export type RainByDate = Record<string, number | undefined>

export interface PlanInput {
  profile: Profile
  activities: readonly Activity[]
  /** prvi dan tedna (ISO, ponedeljek) — privzeto ta teden */
  weekStart?: string
  rain?: RainByDate
  /** prvi teden načrta: vključi uvodni 20-min test, če FTP ni svež */
  firstWeek?: boolean
  /** dnevi pred tem datumom so že mimo (privzeto danes) */
  notBefore?: string
}

/** Kateri ponedeljek naj bo začetek PRVEGA načrta: če je teden že večinoma mimo (čet+), naslednji. */
export function firstPlanWeekStart(today: string = todayIso()): string {
  const ws = weekStartIso(today)
  const dow = Math.round((new Date(today).getTime() - new Date(ws).getTime()) / 86400_000)
  return dow >= 3 ? addDays(ws, 7) : ws
}

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
const DAY = 86400_000
const weeksBetween = (a: string, b: string) => Math.round((new Date(b).getTime() - new Date(a).getTime()) / (7 * DAY))
const r5 = (x: number) => Math.round(x / 5) * 5
const clamp = (x: number, a: number, b: number) => Math.max(a, Math.min(b, x))

/** Privzeti cilj: Veliki maraton Franja BTC City 2027 — 13. 6. 2027, 156 km (franja.org). */
export const FRANJA_2027 = { name: 'Maraton Franja', date: '2027-06-13', distanceKm: 156 }

/* ====================================================================
   FAZE IN TEDEN V MAKROCIKLU
   ==================================================================== */
export type PhaseKey = 'osnova' | 'gradnja' | 'specificno' | 'tapering' | 'dirka' | 'po'
export const PHASE_INFO: Record<PhaseKey, { name: string; desc: string }> = {
  osnova: { name: 'Osnova', desc: 'Aerobna baza: veliko Z2, sweet spot in VO2max v manjšem odmerku, moč 2×. Tu gre teža dol — deficit samo izven kolesa.' },
  gradnja: { name: 'Gradnja', desc: 'Dvig FTP: prag 3 × 15 in 2 × 20 min, VO2max 5 × 4 min, dolga vožnja s tempom v zadnji uri. Teža se ustali.' },
  specificno: { name: 'Specifično', desc: 'Za Franjo: VO2max, simulacija Kladja (2 × 20 min na klancu), dolge vožnje v tempu dirke z gorivom 60–80 g/h.' },
  tapering: { name: 'Tapering', desc: 'Volumen −40 %, intenzivnost ostane kratka in ostra. Noge se napolnijo.' },
  dirka: { name: 'Teden dirke', desc: 'Kratki pospeški, veliko spanja, zadnja dva dni 8–10 g OH na kg telesne teže. V nedeljo dirka.' },
  po: { name: 'Po dirki', desc: 'Dva tedna lahko in po občutku — nato nov cilj.' },
}

export interface WeekCtx {
  phase: PhaseKey
  phaseName: string
  phaseDesc: string
  /** zaporedni teden od začetka načrta (1 = prvi) */
  week: number
  /** vseh tednov do vključno tedna dirke (ali 12 v ciklu brez dogodka) */
  total: number | null
  /** teden v bloku 3 + 1 */
  blockWeek: 1 | 2 | 3 | 4
  recovery: boolean
  /** ta teden je 20-minutni test FTP */
  test: boolean
  /** delež ciljnih ur */
  volume: number
  /** načrtovane ure na kolesu ta teden */
  hours: number
  weeksToEvent: number | null
  event: { name: string; date: string; distanceKm?: number | null } | null
  /** ali načrt sploh ima strukturo (dogodek ali začet cikel) */
  structured: boolean
}

/** Ure na kolesu v »normalnem« tednu bloka (drugi teden). Prvi je ~12 % nižji, tretji ~12 % višji. */
export function targetHours(p: Pick<Profile, 'hoursPerWeek' | 'level'>): number {
  const h = p.hoursPerWeek || ({ 1: 4, 2: 6, 3: 9, 4: 12 } as Record<number, number>)[p.level || 3] || 9
  return clamp(h, 3, 20)
}

function ftpStale(p: Pick<Profile, 'ftp' | 'ftpDate'>, weekStart: string): boolean {
  if (!p.ftp || !p.ftpDate) return true
  return (new Date(weekStart).getTime() - new Date(p.ftpDate).getTime()) / DAY > 28
}

export function weekContext(p: Profile, weekStart: string = weekStartIso(todayIso())): WeekCtx {
  const T = targetHours(p)
  const ev = p.event?.date ? { name: p.event.name, date: p.event.date, distanceKm: p.event.distanceKm ?? null } : null
  const start = p.cycleStart || weekStart
  const since = Math.max(0, weeksBetween(start, weekStart))
  const mk = (phase: PhaseKey, o: Partial<WeekCtx>): WeekCtx => {
    const volume = o.volume ?? 1
    return {
      phase, phaseName: PHASE_INFO[phase].name, phaseDesc: PHASE_INFO[phase].desc, week: since + 1, total: null,
      blockWeek: 2, recovery: false, test: false, weeksToEvent: null, event: ev, structured: !!(ev || p.cycleStart),
      ...o, volume, hours: Math.round(T * volume * 2) / 2,
    }
  }
  if (ev) {
    const evWeek = weekStartIso(ev.date)
    const wte = weeksBetween(weekStart, evWeek)
    const total = Math.max(1, weeksBetween(start, evWeek) + 1)
    if (wte < 0 && wte >= -2) return mk('po', { total, weeksToEvent: wte, volume: 0.5, recovery: true, blockWeek: 4 })
    if (wte < 0) return rolling(-wte - 3, wte)   // po dirki: sezona teče dalje v 12-tedenskih ciklih
    if (wte === 0) return mk('dirka', { total, weeksToEvent: 0, volume: 0.4, blockWeek: 4 })
    if (wte === 1) return mk('tapering', { total, weeksToEvent: 1, volume: 0.6, blockWeek: 4 })
    // bloki se štejejo NAZAJ od taperinga: zadnji teden pred taperingom je vedno težak
    const idx = wte - 2, m = idx % 4
    const recovery = m === 3 && since >= 2          // v prvih dveh tednih načrta ni razbremenitve
    const blockWeek = (m === 3 ? (recovery ? 4 : 1) : 3 - m) as 1 | 2 | 3 | 4
    const phase: PhaseKey = idx <= 7 ? 'specificno' : idx <= 19 ? 'gradnja' : 'osnova'
    const test = (!!p.cycleStart && since === 0 && ftpStale(p, weekStart)) || (recovery && idx % 8 === 3)
    const ramp = phase === 'osnova' ? Math.min(1, 0.85 + (0.15 * since) / 12) : 1
    const volume = recovery ? 0.52 : [0.88, 1, 1.12][blockWeek - 1]! * ramp * (phase === 'specificno' ? 0.95 : 1)
    return mk(phase, { total, weeksToEvent: wte, blockWeek, recovery, test, volume })
  }
  // brez dogodka: ponavljajoči se 12-tedenski cikel (osnova 4 · gradnja 4 · specifično 4; vsak 4. razbremenilni)
  if (!p.cycleStart) return mk('osnova', { blockWeek: 2, volume: 1 })
  return rolling(since, null)

  function rolling(n: number, wte: number | null): WeekCtx {
    const w = n % 12
    const phase: PhaseKey = w < 4 ? 'osnova' : w < 8 ? 'gradnja' : 'specificno'
    const blockWeek = ((w % 4) + 1) as 1 | 2 | 3 | 4
    const recovery = blockWeek === 4
    const test = (n === 0 && ftpStale(p, weekStart)) || (recovery && w === 11)
    return mk(phase, { week: w + 1, total: 12, blockWeek, recovery, test, weeksToEvent: wte, volume: recovery ? 0.52 : [0.88, 1, 1.12][blockWeek - 1]! })
  }
}

/** Vsi tedni od začetka načrta do tedna dirke (za časovnico). */
export function macroWeeks(p: Profile, today: string = todayIso()): (WeekCtx & { weekStart: string })[] {
  if (!p.event?.date) return []
  const first = p.cycleStart || weekStartIso(today)
  const last = weekStartIso(p.event.date)
  const out: (WeekCtx & { weekStart: string })[] = []
  for (let ws = first; ws <= last && out.length < 80; ws = addDays(ws, 7)) out.push({ ...weekContext(p, ws), weekStart: ws })
  return out
}

/* ====================================================================
   MOČ ZA KOLESARJA: jedro in noge, 2 × 20–30 min (ne »mišice za ogledalo«).
   Napredovanje iz zadnje zabeležene seje z istim naslovom (+1 ponovitev / +5 s, kg ostane).
   ==================================================================== */
export type StrengthKind = 'jedro' | 'noge'
export type Exercise = { name: string; sets: number; reps: string; kg?: number | null }
const STR: Record<StrengthKind, [string, number, string][]> = {
  jedro: [['Deska', 3, '45–60 s'], ['Stranska deska', 3, '30–45 s'], ['Dvig nog leže', 3, '10–15'], ['Dead bug', 3, '8–12']],
  noge: [['Bolgarski počep', 3, '8–12'], ['Izpadni koraki', 3, '10–12'], ['Dvigi na prste', 3, '15–20'], ['Deska', 3, '45–60 s']],
}
export const STRENGTH_TITLE: Record<StrengthKind, string> = { jedro: 'Moč — jedro', noge: 'Moč — noge in jedro' }
const STRENGTH_MIN: Record<StrengthKind, number> = { jedro: 20, noge: 30 }

export function strengthSession(kind: StrengthKind, p: Profile, activities: readonly Activity[], light = false): { title: string; exercises: Exercise[]; desc: string; progressed: boolean; min: number } {
  const ex: Exercise[] = STR[kind].map(([name, sets, reps]) => ({ name, sets: light ? Math.max(2, sets - 1) : sets, reps, kg: name === 'Bolgarski počep' && p.gear.dumbbells ? p.gear.dumbbellKg || null : null }))
  const title = STRENGTH_TITLE[kind]
  const last = [...activities].filter(a => a.sport === 'moc' && a.name === title && a.exercises && a.exercises.length).sort((a, b) => b.date.localeCompare(a.date))[0]
  let progressed = false
  if (last && !light) {
    for (const x of ex) {
      const z = last.exercises!.find(y => y.name.toLowerCase() === x.name.toLowerCase())
      if (!z) continue
      if (z.kg) x.kg = z.kg
      if (z.sets > x.sets) x.sets = Math.min(5, z.sets)
      const m = String(z.reps).match(/^(\d+)\s*[–-]\s*(\d+)(\s*s)?$/)
      if (m) { const inc = m[3] ? 5 : 1, hi = +m[2]! + inc; if (m[3] ? hi <= 120 : hi <= 20) { x.reps = `${+m[1]! + inc}–${hi}${m[3] ? ' s' : ''}`; progressed = true } }
    }
  }
  const desc = light ? 'Lažja različica: manj serij, ista tehnika.'
    : kind === 'jedro' ? 'Po kolesu ali zvečer. Močan trup = zgornji del telesa miruje, vsi vati gredo v pedala.'
    : 'Počasi in s kontrolo. Noge za klance in stabilnost; ko dosežeš zgornjo mejo ponovitev, dodaj težo (nahrbtnik ali uteži).'
  return { title, exercises: ex, desc: progressed && !light ? desc + ' Prejšnjič opravljeno — cilji so dvignjeni.' : desc, progressed, min: light ? Math.round(STRENGTH_MIN[kind] * 0.75) : STRENGTH_MIN[kind] }
}

/* ====================================================================
   KNJIŽNICA SEJ — vati iz FTP
   ==================================================================== */
interface Sess { title: string; desc: string; min: number; zone: string; tss: number; target: { lo: number; hi: number } | null; role: NonNullable<PlanDay['role']>; why: string | null }

const watts = (p: Profile, a: number, b: number) => (p.ftp ? { lo: Math.round(p.ftp * a), hi: Math.round(p.ftp * b) } : null)
function wtxt(p: Profile, a: number, b: number, z: 'Z1' | 'Z2' | 'Z3' | 'Z4' | 'Z5'): string {
  const w = watts(p, a, b)
  const pc = `${Math.round(a * 100)}–${Math.round(b * 100)} % FTP`
  return w ? `${w.lo}–${w.hi} W (${pc})` : `${pc} (${zoneText(p, z)})`
}
const tssOf = (minutes: number, IF: number) => Math.round((minutes / 60) * IF * IF * 100)

function intervals(p: Profile, o: { name: string; reps: number; work: number; rest: number; a: number; b: number; z: 'Z3' | 'Z4' | 'Z5'; note: string; why?: string | null; min?: number }): Sess {
  const wu = 20, cd = 15
  const core = o.reps * o.work + (o.reps - 1) * o.rest
  const base = wu + core + cd
  const dur = Math.max(o.min || 0, r5(base))
  const extra = dur - base
  const IF = (o.a + o.b) / 2
  const desc = `20 min ogrevanje s 3 kratkimi pospeški · ${o.reps} × ${o.work} min pri ${wtxt(p, o.a, o.b, o.z)}, vmes ${o.rest} min lahko${extra >= 10 ? ` · nato ${extra} min Z2 (${zoneText(p, 'Z2')})` : ''} · 15 min izvoz. ${o.note}`
  const tss = tssOf(o.reps * o.work, IF) + tssOf(dur - o.reps * o.work, 0.6)
  return { title: `${o.name} ${o.reps} × ${o.work} min`, desc, min: dur, zone: o.z, tss, target: watts(p, o.a, o.b), role: 'kljucna', why: o.why ?? null }
}

const WHY_VO2 = 'Dvigne strop — VO2max je tvoja najšibkejša točka. Samo enkrat na teden, spočit in nahranjen.'
function vo2(p: Profile, phase: PhaseKey, bw: number): Sess {
  const note = 'Enakomerno od prvega do zadnjega — če zadnjega ne zmoreš v razponu, je bil prvi prehiter.'
  if (phase === 'osnova') return intervals(p, { name: 'VO2max', reps: bw === 1 ? 4 : 5, work: 4, rest: 4, a: 1.08, b: 1.15, z: 'Z5', note, why: WHY_VO2, min: 75 })
  if (phase === 'gradnja') return bw === 2
    ? intervals(p, { name: 'VO2max', reps: 4, work: 5, rest: 5, a: 1.1, b: 1.15, z: 'Z5', note, why: WHY_VO2, min: 90 })
    : intervals(p, { name: 'VO2max', reps: bw === 1 ? 5 : 6, work: 4, rest: 4, a: 1.1, b: 1.18, z: 'Z5', note, why: WHY_VO2, min: 90 })
  if (bw === 3) return intervals(p, { name: 'VO2max', reps: 6, work: 3, rest: 3, a: 1.15, b: 1.2, z: 'Z5', note: 'Kratko in ostro — kot pospeški skupine na Kladju.', why: WHY_VO2, min: 90 })
  return intervals(p, { name: 'VO2max', reps: bw === 1 ? 5 : 4, work: bw === 1 ? 4 : 5, rest: bw === 1 ? 4 : 5, a: 1.1, b: 1.2, z: 'Z5', note, why: WHY_VO2, min: 90 })
}

function prag(p: Profile, phase: PhaseKey, bw: number): Sess {
  if (phase === 'osnova') {
    const [reps, work] = bw === 1 ? [3, 12] : bw === 2 ? [3, 15] : [2, 20]
    return intervals(p, { name: 'Sweet spot', reps, work, rest: 5, a: 0.88, b: 0.93, z: 'Z3', note: 'Težko, a ponovljivo. Kadenca 85–95.', why: 'Sweet spot da največ aerobnega napredka na minuto brez velike utrujenosti.', min: 90 })
  }
  if (phase === 'gradnja') {
    const [reps, work, a, b] = bw === 1 ? [3, 12, 0.95, 1] : bw === 2 ? [3, 15, 0.93, 0.98] : [2, 20, 0.92, 0.97]
    return intervals(p, { name: 'Prag', reps, work, rest: 5, a, b, z: 'Z4', note: 'Enakomerno — zadnja minuta vsakega intervala naj bo še obvladljiva.', why: 'Delo na pragu premakne FTP — tvojo številko za ravnino in dolge klance.', min: 105 })
  }
  const [reps, work, a, b] = bw === 1 ? [2, 15, 0.95, 1] : bw === 2 ? [2, 20, 0.92, 0.97] : [3, 12, 0.97, 1.02]
  return intervals(p, { name: 'Kladje', reps, work, rest: 6, a, b, z: 'Z4', note: 'Po možnosti na klancu 5–8 % (Kladje: 7 km, 6,3 %). Sede, kadenca 75–85.', why: 'Specifično za glavni vzpon Franje — enakomerno, ne po špicah skupine.', min: 105 })
}

const FUEL_LONG = 'Gorivo: od 30. minute 50–60 g ogljikovih hidratov na uro in 500–750 ml tekočine na uro — kaj vzeti in kdaj jesti piše v Gorivu.'
function dolga(p: Profile, phase: PhaseKey, min: number, recovery: boolean): Sess {
  const z2 = zoneText(p, 'Z2')
  if (recovery) return { title: 'Lahka daljša Z2', desc: `Mirno ${z2}, brez klancev na silo. ${FUEL_LONG}`, min, zone: 'Z2', tss: tssOf(min, 0.62), target: null, role: 'dolga', why: 'Razbremenilni teden: volumen dol, da se prilagoditve zgodijo.' }
  if (phase === 'gradnja' && min >= 150) return { title: 'Dolga Z2 + tempo', desc: `Enakomerno ${z2}; v zadnji uri 2 × 15 min tempo pri ${wtxt(p, 0.76, 0.88, 'Z3')}. ${FUEL_LONG}`, min, zone: 'Z2', tss: tssOf(min - 30, 0.65) + tssOf(30, 0.82), target: watts(p, 0.76, 0.88), role: 'dolga', why: 'Tempo na utrujenih nogah — točno to zahteva druga polovica Franje.' }
  if (phase === 'specificno' && min >= 150) return { title: 'Simulacija Franje', desc: `Z2 ${z2}; na daljših klancih 2 × 20 min pri ${wtxt(p, 0.85, 0.92, 'Z3')}. Gorivo kot na dirki: ~80 g OH na uro od 30. minute. Po možnosti v skupini.`, min, zone: 'Z2', tss: tssOf(min - 40, 0.66) + tssOf(40, 0.88), target: watts(p, 0.85, 0.92), role: 'dolga', why: 'Vadiš tempo, gorivo in vožnjo v skupini za dan D.' }
  return { title: 'Dolga Z2', desc: `Enakomerno ${z2}, visoka kadenca, brez špicev. ${FUEL_LONG}`, min, zone: 'Z2', tss: tssOf(min, 0.65), target: null, role: 'dolga', why: 'Dolga Z2 gradi motor: mitohondrije, kurjenje maščob, vzdržljivost za 156 km.' }
}
const z2Ride = (p: Profile, min: number, sunday = false): Sess => ({ title: sunday ? 'Z2 — sam ali v skupini' : 'Z2 vzdržljivost', desc: `Mirno ${zoneText(p, 'Z2')}, kadenca 90+. Če si utrujen, skrajšaj — ne pospešuj.${min >= 90 ? ' Od 30. minute ~40 g OH na uro.' : ''}`, min, zone: 'Z2', tss: tssOf(min, 0.65), target: null, role: 'lahka', why: null })
const regen = (p: Profile, min: number): Sess => ({ title: 'Regeneracija', desc: `Zelo lahko${p.ftp ? `, pod ${Math.round(p.ftp * 0.55)} W` : ''} (pod 55 % FTP) — noge samo vrtijo. Lahko tudi prosto.`, min, zone: 'Z1', tss: tssOf(min, 0.5), target: null, role: 'regen', why: 'Kri v nogah pospeši regeneracijo pred vikendom.' })
const testSess = (p: Profile): Sess => ({ title: '20-minutni test FTP', desc: `15 min ogrevanje s 3 × 1 min hitreje, 5 min lahko, 20 min enakomerno čim močneje, 10 min izvoz. FTP = 95 % povprečja teh 20 min.${p.ftp ? ` Začni pri ~${Math.round(p.ftp * 1.02)} W in zadnjih 5 min stisni.` : ''}`, min: 60, zone: 'test', tss: 70, target: null, role: 'test', why: 'Nov FTP = prave cone in vati za naslednje tedne. Vpiši ga v Napredek.' })

/* ====================================================================
   TEDEN
   ==================================================================== */
export function buildWeek(inp: PlanInput): PlanDay[] {
  const p = inp.profile
  const start = inp.weekStart || weekStartIso(todayIso())
  const ctx = weekContext(p, start)
  const rain = inp.rain || {}
  const now = new Date().toISOString()
  const days = Array.from({ length: 7 }, (_, i) => addDays(start, i))
  const notBefore = inp.notBefore || todayIso()
  const open = (i: number) => days[i]! >= notBefore

  // utrujenost: pri TSB pod −25 teden −15 % (ne v razbremenitvi, taperingu ali tednu dirke)
  const series = formSeries(inp.activities)
  const tsb = series.length ? series[series.length - 1]!.tsb : 0
  const tired = !ctx.recovery && ctx.phase !== 'tapering' && ctx.phase !== 'dirka' && ctx.phase !== 'po' && tsb < -25
  const total = Math.round(ctx.hours * 60 * (tired ? 0.85 : 1))
  const withTest = ctx.test || (!!inp.firstWeek && ftpStale(p, start))
  const strDays = p.strength.on ? clamp(p.strengthDays ?? 2, 0, 2) : 0

  // sestava: po dnevih (0 = pon … 6 = ned) seznam sej
  const slot: (Sess | null)[] = Array(7).fill(null)
  const moc: (StrengthKind | null)[] = Array(7).fill(null)
  let light = false

  if (ctx.phase === 'po') {
    slot[1] = z2Ride(p, 60); slot[3] = z2Ride(p, 60); slot[5] = z2Ride(p, 90, true)
  } else if (ctx.phase === 'dirka') {
    const km = ctx.event?.distanceKm || 156
    const raceMin = r5((km / 30) * 60)
    slot[1] = intervals(p, { name: 'Predaktivacija', reps: 4, work: 1, rest: 3, a: 1.15, b: 1.25, z: 'Z5', note: 'Samo odpre noge — ne utruja.', why: 'Teden dirke: kratko in ostro, da ostaneš oster.', min: 60 })
    slot[2] = { ...z2Ride(p, 45), title: 'Lahka Z2' }
    slot[3] = intervals(p, { name: 'Tempo dirke', reps: 3, work: 3, rest: 3, a: 0.95, b: 1.02, z: 'Z4', note: 'Občutek za tempo na Kladju.', min: 50 })
    slot[5] = intervals(p, { name: 'Predaktivacija', reps: 3, work: 1, rest: 2, a: 1.1, b: 1.2, z: 'Z5', note: 'Dan pred dirko: 30–40 min, nato noge gor. Zvečer testenine ali riž.', why: 'Svežina + odprte noge.', min: 35 })
    const klad = watts(p, 0.95, 1.0)
    slot[6] = { title: `${ctx.event?.name || 'Dirka'} — ${km} km`, desc: `Zajtrk 3 h pred startom (2–3 g OH/kg). Na kolesu ~85 g OH na uro od 30. minute (seznam in urnik v Gorivu), pijača z elektroliti. Ravnina v zavetrini, Vrhniški klanec mirno, Kladje (7 km, 6,3 %) enakomerno${klad ? ` pri ${klad.lo}–${klad.hi} W` : ' na pragu'} — ne po špicah skupine.`, min: raceMin, zone: 'dirka', tss: tssOf(raceMin, 0.75), target: klad, role: 'dirka', why: 'Dan D.' }
  } else if (ctx.phase === 'tapering') {
    const H = total
    slot[1] = intervals(p, { name: 'VO2max', reps: 3, work: 3, rest: 3, a: 1.1, b: 1.15, z: 'Z5', note: 'Samo ohranja ostrino.', why: 'Tapering: manj volumna, intenzivnost ostane.', min: 60 })
    slot[3] = intervals(p, { name: 'Prag', reps: 2, work: 8, rest: 5, a: 0.95, b: 1.0, z: 'Z4', note: 'Kontroliran občutek za tempo.', why: 'Tapering: kratko na pragu.', min: 60 })
    const rest = Math.max(120, H - 120)
    const sat = clamp(r5(rest * 0.5), 90, 180)
    slot[5] = { ...dolga(p, 'osnova', sat, false), title: 'Z2 + 3 × 5 min tempo dirke', desc: `Z2 ${zoneText(p, 'Z2')}; v drugi uri 3 × 5 min pri ${wtxt(p, 0.88, 0.95, 'Z3')}. Gorivo 60–80 g/h — preizkusi, kar boš jedel na dirki.`, target: watts(p, 0.88, 0.95) }
    slot[2] = z2Ride(p, clamp(r5(rest * 0.25), 45, 90))
    slot[6] = z2Ride(p, clamp(r5(rest * 0.25), 45, 90), true)
    if (strDays > 0) { moc[1] = 'jedro'; light = true }
  } else if (ctx.recovery) {
    slot[1] = { ...z2Ride(p, 60), title: 'Z2 + 4 × 30 s pospeški', desc: `Lahko ${zoneText(p, 'Z2')}; na sredi 4 × 30 s hitra kadenca (ne sila). Razbremenilni teden.` }
    slot[3] = z2Ride(p, 60)
    if (withTest) { slot[5] = testSess(p); slot[6] = z2Ride(p, clamp(r5(total - 180), 60, 120), true) }
    else { const rest = Math.max(120, total - 120); slot[5] = dolga(p, ctx.phase, clamp(r5(rest * 0.6), 90, 150), true); slot[6] = z2Ride(p, clamp(r5(rest * 0.4), 45, 90), true) }
    if (strDays > 0) { moc[4] = 'jedro'; light = true }
  } else {
    const k1 = vo2(p, ctx.phase, ctx.blockWeek)
    const k2 = withTest ? testSess(p) : prag(p, ctx.phase, ctx.blockWeek)
    let R = total - k1.min - k2.min
    slot[1] = k1; slot[3] = k2
    if (R < 240) {
      // malo ur: dolga + ena Z2, brez srede in regeneracije
      const sat = clamp(r5(R * 0.6), 60, 180), rest = r5(R - sat)
      slot[5] = dolga(p, ctx.phase, sat, false); if (rest >= 45) slot[6] = z2Ride(p, rest, true)
    } else {
      const rg = R >= 330 ? 60 : R >= 270 ? 45 : 0
      R -= rg
      const sat = clamp(r5(R * 0.47), 120, 300)
      const wed = clamp(r5(R * 0.3), 60, 180)
      const sun = clamp(r5(R - sat - wed), 45, 150)
      slot[2] = z2Ride(p, wed); if (rg) slot[4] = regen(p, rg)
      slot[5] = dolga(p, ctx.phase, sat, false); slot[6] = z2Ride(p, sun, true)
    }
    if (ctx.phase === 'specificno' && slot[6]) slot[6] = { ...slot[6], title: 'Skupinska vožnja ali Z2 + 6 × 30 s', desc: `V skupini vadi zavetrino in položaj v sredini — ista hitrost za 100 W manj. Sam: Z2 (${zoneText(p, 'Z2')}) s 6 × 30 s napadom${p.ftp ? ` (${Math.round(p.ftp * 1.5)} W in več)` : ' (nad 150 % FTP)'}, vmes 4 min lahko.`, why: 'Na dirki se skupina lomi v 30-sekundnih pospeških — te moraš preživeti.' }
    const nStr = ctx.phase === 'specificno' ? Math.min(1, strDays) : strDays
    if (nStr >= 2) { moc[1] = 'jedro'; moc[4] = 'noge' } else if (nStr === 1) moc[4] = 'noge'
    light = ctx.phase === 'specificno'
  }

  // vreme: dolga vožnja na bolj suh vikend dan
  const rs = rain[days[5]!] ?? 30, rn = rain[days[6]!] ?? 30
  if (slot[5]?.role === 'dolga' && slot[6]?.role === 'lahka' && rs >= 50 && rn + 20 <= rs) { const t = slot[5]; slot[5] = slot[6]; slot[6] = t }

  // začetek sredi tedna: test ne sme pasti mimo — premakni ga na prvi prost dan (čet, pet, ned)
  if (withTest && slot.some(s => s?.role === 'test')) {
    const ti = slot.findIndex(s => s?.role === 'test')
    if (!open(ti)) {
      const to = [3, 4, 6, 2].find(i => open(i) && slot[i]?.role !== 'dolga')
      if (to != null) { slot[to] = slot[ti]!; slot[ti] = null }
    }
  }

  const out: PlanDay[] = []
  const base = (date: string) => ({ id: uid(), date, source: 'rules' as const, createdAt: now, updatedAt: now, done: null })
  days.forEach((date, i) => {
    const s = slot[i], mk = moc[i]
    if (!open(i)) {
      out.push({ ...base(date), kind: 'pocitek', title: 'Pred začetkom', desc: 'Ta dan je bil pred začetkom načrta.', durationMin: 0, zone: null, tssTarget: 0, why: null })
      return
    }
    if (!s && !mk) {
      const race = ctx.phase === 'dirka' && i === 4
      out.push({ ...base(date), kind: 'pocitek', title: race ? 'Počitek + polnjenje OH' : 'Počitek', desc: race ? 'Danes in jutri 8–10 g ogljikovih hidratov na kg (riž, testenine, kruh, sok), malo vlaknin in maščob. Noge gor.' : i === 0 ? 'Popoln počitek. Po želji 10 min raztezanja ali jedra.' : 'Prosto — spanec in hrana sta del treninga.', durationMin: 0, zone: null, tssTarget: 0, why: i === 0 ? 'Prilagoditev se zgodi med počitkom, ne med treningom.' : null })
      return
    }
    if (s) {
      const kind: PlanKind = s.role === 'test' ? 'test' : 'kolo'
      out.push({ ...base(date), kind, title: s.title, desc: s.desc, durationMin: s.min, zone: s.zone, tssTarget: s.tss, why: s.why, role: s.role, target: s.target })
    }
    if (mk) {
      const st = strengthSession(mk, p, inp.activities, light)
      out.push({ ...base(date), kind: 'moc', title: st.title, desc: st.desc, durationMin: st.min, zone: null, tssTarget: Math.round(st.min * 0.8), exercises: st.exercises, role: 'moc', why: mk === 'jedro' ? 'Močan trup, stabilna drža na kolesu.' : 'Noge za klance, zaščita pred poškodbami.' })
    }
  })

  // razlaga tedna — na prvi aktivni dan
  const f = out.find(d => d.kind !== 'pocitek' && d.kind !== 'moc')
  if (f) {
    const head = ctx.weeksToEvent != null && ctx.weeksToEvent > 0
      ? `${ctx.phaseName}${ctx.recovery ? ' · razbremenilni teden' : ctx.phase === 'tapering' ? '' : ` · ${ctx.blockWeek}. teden bloka`} · ${ctx.hours.toString().replace('.', ',')} h. ${ctx.event!.name} čez ${ctx.weeksToEvent} ${ctx.weeksToEvent === 1 ? 'teden' : ctx.weeksToEvent === 2 ? 'tedna' : ctx.weeksToEvent < 5 ? 'tedne' : 'tednov'}.`
      : `${ctx.phaseName} · ${ctx.hours.toString().replace('.', ',')} h.`
    f.why = [head, tired ? `Ta teden −15 %: forma je ${Math.round(tsb)} (utrujenost visoka).` : '', f.why || ''].filter(Boolean).join(' ')
  }
  return out
}

/** Skupno načrtovano trajanje tedna (min) — brez neobveznih dni. */
export function weekMinutes(days: readonly PlanDay[]): number { return days.filter(d => !d.optional).reduce((s, d) => s + (d.durationMin || 0), 0) }
/** Ure na kolesu (brez moči) — primerjava s ciljem tedna. */
export function weekBikeMinutes(days: readonly PlanDay[]): number { return days.filter(d => !d.optional && (d.kind === 'kolo' || d.kind === 'test')).reduce((s, d) => s + (d.durationMin || 0), 0) }

/** Napovedana forma na zadnji dan tedna, če opraviš vse načrtovano. */
export function forecastForm(activities: readonly Activity[], week: readonly PlanDay[], today: string = todayIso()): { ctl: number; atl: number; tsb: number; date: string } | null {
  if (!week.length) return null
  const s = formSeries(activities, today)
  let ctl = s.length ? s[s.length - 1]!.ctl : 0, atl = s.length ? s[s.length - 1]!.atl : 0
  const byDate = new Map<string, number>()
  for (const d of week) if (d.date > today && !d.done) byDate.set(d.date, (byDate.get(d.date) || 0) + (d.tssTarget || 0))
  const last = [...week].sort((a, b) => a.date.localeCompare(b.date))[week.length - 1]!.date
  for (let d = addDays(today, 1); d <= last; d = addDays(d, 1)) { const tss = byDate.get(d) || 0; ctl += (tss - ctl) / 42; atl += (tss - atl) / 7 }
  return { ctl: Math.round(ctl), atl: Math.round(atl), tsb: Math.round(ctl - atl), date: last }
}

/** Minute po conah za načrtovan teden (ključne seje: 45 % v ciljni coni, 40 % Z2, 15 % Z1). */
export function zoneMinutes(week: readonly PlanDay[]): Record<'Z1' | 'Z2' | 'Z3' | 'Z4' | 'Z5', number> {
  const m = { Z1: 0, Z2: 0, Z3: 0, Z4: 0, Z5: 0 }
  for (const d of week) {
    if (d.kind === 'moc' || d.kind === 'pocitek' || d.optional) continue
    const raw = d.zone === 'test' ? 'Z4' : d.zone === 'dirka' ? 'Z3' : d.zone || 'Z2'
    const z = raw as keyof typeof m
    if (!(z in m)) continue
    const t = d.durationMin || 0
    if (d.role === 'kljucna' || d.role === 'test') {
      const w = Math.min(t, Math.round(t * 0.4))
      m[z] += w; m.Z2 += Math.round((t - w) * 0.7); m.Z1 += t - w - Math.round((t - w) * 0.7)
    } else if (z === 'Z1' || z === 'Z2') m[z] += t
    else { m[z] += Math.round(t * .45); m.Z2 += Math.round(t * .4); m.Z1 += Math.round(t * .15) }
  }
  return m
}

/**
 * »Olajšaj dan« brez AI: današnjo sejo prestavi na naslednji prost dan v tednu,
 * danes pa ostane lahka Z1. Vrne dneve za shranitev (po id-ju) ali null, če ni česa olajšati.
 */
export function easeDay(week: readonly PlanDay[], today: string): PlanDay[] | null {
  const cur = week.find(d => d.date === today && (d.kind === 'kolo' || d.kind === 'test') && !d.optional && !d.done)
  if (!cur) return null
  const busy = new Set(week.filter(d => d.kind !== 'pocitek' && d.kind !== 'moc' && !d.optional).map(d => d.date))
  const later = [...week].filter(d => d.date > today && !d.done && d.kind === 'pocitek' && !busy.has(d.date)).sort((a, b) => a.date.localeCompare(b.date))[0]
  const now = new Date().toISOString()
  const out: PlanDay[] = []
  const dn = (iso: string) => ['nedeljo', 'ponedeljek', 'torek', 'sredo', 'četrtek', 'petek', 'soboto'][new Date(iso).getDay()]
  if (later) out.push({ ...cur, id: later.id, date: later.date, why: `Prestavljeno z danes (${dn(today)}) zaradi nizke pripravljenosti.`, source: 'rules', updatedAt: now })
  out.push({ ...cur, kind: 'kolo', title: 'Lahek dan — Z1', desc: 'Telo je dalo znak. 30–45 min zelo lahkega vrtenja ali sprehod, veliko vode, zgodaj spat.', durationMin: 40, zone: 'Z1', tssTarget: 20, target: null, role: 'regen', exercises: undefined, optional: true, why: later ? `Seja je prestavljena na ${dn(later.date)}.` : 'Ta seja ta teden odpade — bolje en trening manj kot bolezen.', source: 'rules', updatedAt: now })
  return out
}
