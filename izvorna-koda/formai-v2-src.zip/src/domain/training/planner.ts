import { sickifyBuilt } from './sick'
import { pauseBuilt, pauseWeeks, pauseBefore, pauseLock, pauseAfter } from './pause'
import { badMornings } from './state'
import { raceLock, type RaceLock } from './protect'
import { OFF_MIX, offMixOf } from './offMix'
import type { Activity, DailyCheckin, PhaseName, PlanContent, PlanDay, PlanKind, Profile, Race, RaceType } from '../types'
import { seasonGoals, peakGoals, raceTypeOf, raceMinutes, sideRaceMinutes, ftpForWeek, offStage, OFF_MAX, RACE_TYPES, type SeasonGoal, type OffStage, type RiderLike } from './season'
import { addDays, formSeries, formReliable, todayIso, weekStartIso, estimateTss, fmtDur, lthrOf, STRENGTH_TSS_H } from './load'
import { zoneText, noPower, lthrZoneText } from './zones'
import { isHardDay } from './plandays'
import { minMinutes, stepsFor } from './workout'
import { buildFocusWeek, focusWeekContext, evidenceWeek, healthSafe } from './focusPlan'
import { isCustom } from '../focus/model'
import { fuelGph } from '../nutrition/fuelrate'

/**
 * NAČRT DO CILJA (osebna različica: Maraton Franja).
 * Makrocikel od začetka načrta do dneva dirke: osnova → gradnja → specifično → tapering → dirka.
 * V vsaki fazi bloki 3 + 1 (trije tedni rastoče obremenitve, četrti razbremenilni), 80/20:
 * pon počitek · tor VO2max + noge · sre Z2 · čet prag / sweet spot · pet regeneracija + jedro · sob dolga Z2 · ned Z2.
 * Vse deterministično — brez omrežja in brez AI. Vati iz FTP, ko ga poznamo.
 */

/** Verjetnost dežja po dnevih (0–100), če jo poznamo. */
export type RainByDate = Record<string, number | undefined>

export interface PlanInput {
  profile: Profile
  activities: readonly Activity[]
  /** prvi dan tedna (ISO, ponedeljek) — privzeto ta teden */
  weekStart?: string
  rain?: RainByDate
  /** prvi teden načrta: vključi uvodni 20-min test, če FTP ni svež */
  firstWeek?: boolean
  /** dnevi pred tem datumom so že mimo (privzeto danes) */
  notBefore?: string
  /** jutranji vnosi — več slabih juter zadnji teden (mišice zelo/boli, energija slabo/na tleh) = teden lažji */
  checkins?: readonly DailyCheckin[]
  /** že opravljeni dnevi (načrt po meri: odštejejo se od tedna in štejejo pri razmikih) */
  done?: readonly { date: string; kind: PlanKind }[]
  /** danes (privzeto todayIso()) — kateri tedni so že prihodnost za ure iz resnice (v3.48) */
  today?: string
}

/** Kateri ponedeljek naj bo začetek PRVEGA načrta: če je teden že večinoma mimo (čet+), naslednji. */
export function firstPlanWeekStart(today: string = todayIso()): string {
  const ws = weekStartIso(today)
  const dow = Math.round((new Date(today).getTime() - new Date(ws).getTime()) / 86400_000)
  return dow >= 3 ? addDays(ws, 7) : ws
}

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
const DAY = 86400_000
const weeksBetween = (a: string, b: string) => Math.round((new Date(b).getTime() - new Date(a).getTime()) / (7 * DAY))
const r5 = (x: number) => Math.round(x / 5) * 5
const clamp = (x: number, a: number, b: number) => Math.max(a, Math.min(b, x))
/** Dan v tednu v tožilniku (»v soboto«) — iz datuma, neodvisno od časovnega pasu naprave. */
const DAY_ACC = ['nedeljo', 'ponedeljek', 'torek', 'sredo', 'četrtek', 'petek', 'soboto']
const dayAcc = (iso: string) => DAY_ACC[new Date(iso + 'T12:00:00Z').getUTCDay()] ?? ''
const DAY_NOM = ['Nedelja', 'Ponedeljek', 'Torek', 'Sreda', 'Četrtek', 'Petek', 'Sobota']
/** »s ponedeljka«, »z nedelje« — od katerega dne (predlog z/s + rodilnik). */
const DAY_FROM = ['z nedelje', 's ponedeljka', 's torka', 's srede', 's četrtka', 's petka', 's sobote']
const dayFrom = (iso: string) => DAY_FROM[new Date(iso + 'T12:00:00Z').getUTCDay()] ?? ''
/** Tekma, pred katero je polnjenje z OH (8–10 g na kg zadnja dva dni). */
const CARB_LOAD_RACE_MIN = 150
/** Na kolesu 60+ g OH na uro samo na tekmah od 90 min naprej. */
const FUEL_RACE_MIN = 90

/** Privzeti cilj: Veliki maraton Franja BTC City 2027 — 13. 6. 2027, 156 km (franja.org). */
export const FRANJA_2027 = { name: 'Maraton Franja', date: '2027-06-13', distanceKm: 156 }

/* ====================================================================
   FAZE IN TEDEN V MAKROCIKLU
   ==================================================================== */
export type PhaseKey = PhaseName
export const PHASE_INFO: Record<PhaseKey, { name: string; desc: string }> = {
  prehod: { name: 'Off-season', desc: 'Počitek po sezoni: brez intervalov in brez ure — vožnja po občutku, po želji hribi ali drugi športi (izbereš sam). Telo in glava se napolnita; FTP pade nekaj %, kar je normalno.' },
  osnova: { name: 'Osnova', desc: 'Aerobna baza: prvi tedni lahko (Z2, šprinti, tempo), nato sweet spot in VO2max v manjšem odmerku, moč 2×. Klanci, ravnina in šprint izmenično. Tu gre teža dol — deficit samo izven kolesa.' },
  gradnja: { name: 'Gradnja', desc: 'Dvig FTP: prag 3 × 15 in 2 × 20 min, VO2max 5 × 4 min, dolga vožnja s tempom v zadnji uri. Teža se ustali.' },
  specificno: { name: 'Specifično', desc: 'Kar odloča na tvoji dirki: VO2max, tempo dirke na klancu ali ravnini, dolge vožnje z gorivom kot na dirki (~80 g/h).' },
  tapering: { name: 'Tapering', desc: 'Volumen −40 %, intenzivnost ostane kratka in ostra. Noge se napolnijo.' },
  dirka: { name: 'Teden dirke', desc: 'Kratki pospeški in veliko spanja; pred dolgo dirko zadnja dva dni 8–10 g OH na kg telesne teže.' },
  po: { name: 'Po dirki', desc: 'Dva tedna lahko in po občutku — nato nov cilj.' },
}

/** (v3.51) Moč v specifični fazi (placeStrength: spec → samo jedro v petek). */
export const STRENGTH_SPEC = 'Moč: samo jedro 1× na teden (noge so za kolo).'
/**
 * (v3.51) Kdaj je moč v tednu — iz istega pravila kot placeStrength (prej Nastavitve: »jedro (torek) in noge + jedro (petek)«,
 * načrt pa noge v torek in jedro v petek; fitnes »petek«, načrt četrtek).
 */
export function strengthPlanText(gym: boolean, n: number): string {
  if (n <= 0) return ''
  if (gym) return n >= 2 ? 'Fitnes: torek noge težko (polovični počep, nožna preša na eni nogi, romunski mrtvi dvig …), četrtek enonožne vaje + hrbet in jedro, ~50 min.' : 'Fitnes: torek noge težko (polovični počep, nožna preša na eni nogi, romunski mrtvi dvig …), ~65 min.'
  return n >= 2 ? 'Moč doma: noge + jedro v torek (po VO2max) in jedro v petek, 20–30 min.' : 'Moč doma: noge + jedro v torek (po VO2max), 30 min.'
}
/** Specifično pred Franjo (v3.48: samo, ko je cilj res Franja). */
const SPEC_FRANJA = 'Za Franjo: VO2max, simulacija Kladja (2 × 20 min na klancu), dolge vožnje v tempu dirke z gorivom ~80 g/h.'
/**
 * (v3.50) Opis osnove in gradnje po kolesarju, ne statičen: »moč N×« iz nastavitev (brez moči brez tega), stavek o teži samo
 * pri deficitu, začetniku (raven 1–2) v prvih 12 tednih sweet spot namesto praga — prej »moč 2× … Tu gre teža dol« tudi brez
 * moči in deficita ter »prag 3 × 15« začetniku, ki ima sweet spot.
 */
export function phaseDescFor(p: Pick<Profile, 'strength' | 'strengthDays' | 'deficit' | 'level'>, phase: 'osnova' | 'gradnja', baseWeek: number | null): string {
  const n = p.strength?.on ? clamp(p.strengthDays ?? 2, 0, 2) : 0
  const moc = n ? `, moč ${n}×` : ''
  const novice = (p.level ?? 3) <= 2 && baseWeek != null && baseWeek <= 12
  if (phase === 'osnova') return `Aerobna baza: prvi tedni lahko (Z2, šprinti, tempo), nato sweet spot${novice ? '' : ' in VO2max'} v manjšem odmerku${moc}. Klanci, ravnina in šprint izmenično.${(p.deficit ?? 0) > 0 ? ' Tu gre teža dol — deficit samo izven kolesa.' : ''}`
  return novice
    ? `Dvig FTP: sweet spot 3 × 12 do 2 × 20 min, blag VO2max 4 × 4 min, dolga vožnja s tempom v zadnji uri${moc}.${(p.deficit ?? 0) > 0 ? ' Teža se ustali.' : ''}`
    : `Dvig FTP: prag 3 × 15 in 2 × 20 min, VO2max 5 × 4 min, dolga vožnja s tempom v zadnji uri${moc}.${(p.deficit ?? 0) > 0 ? ' Teža se ustali.' : ''}`
}

export interface WeekCtx {
  phase: PhaseKey
  phaseName: string
  phaseDesc: string
  /** zaporedni teden od začetka načrta (1 = prvi) */
  week: number
  /** vseh tednov do vključno tedna dirke (ali 12 v ciklu brez dogodka) */
  total: number | null
  /** teden v bloku 3 + 1 */
  blockWeek: 1 | 2 | 3 | 4
  recovery: boolean
  /** ta teden je 20-minutni test FTP */
  test: boolean
  /** delež ciljnih ur */
  volume: number
  /** načrtovane ure na kolesu ta teden */
  hours: number
  weeksToEvent: number | null
  event: { name: string; date: string; distanceKm?: number | null } | null
  /** ali načrt sploh ima strukturo (dogodek ali začet cikel) */
  structured: boolean
  /** lahek začetek sezone (1–3. teden po začetku ali off-seasonu): brez intervalov — Z2, šprinti, tempo; 0 = ne */
  easy: 0 | 1 | 2 | 3
  /** vrsta naslednjega cilja sezone — vsebina specifičnega bloka */
  goalType: RaceType | null
  /** koliko ciljev A ima sezona */
  goals: number
  /** teden od konca off-seasona (1 = prvi teden osnove); null brez začetega načrta */
  baseWeek: number | null
  /** off-season: počitek → aktivni počitek → vrnitev */
  offStage?: OffStage
  /** načrt po meri (dogovor: fitnes, tek, kondicija) — bloki po 4 tedne namesto kolesarskih faz */
  custom?: boolean
}

/** Ure na kolesu v »normalnem« tednu bloka (drugi teden). Prvi je ~12 % nižji, tretji ~12 % višji. */
export function targetHours(p: Pick<Profile, 'hoursPerWeek' | 'level'>): number {
  const h = p.hoursPerWeek || ({ 1: 4, 2: 6, 3: 9, 4: 12 } as Record<number, number>)[p.level || 3] || 9
  return clamp(h, 3, 30)
}

/**
 * Rast od tega, kar res voziš: prvi teden največ ~1,2 × dejanskih ur (vsaj 4 h), nato +10 % na teden.
 * Razbremenilni teden ~60 % zgornje meje. Brez podatkov (baseHours null) ni omejitve.
 */
export function rampCap(p: Pick<Profile, 'baseHours'>, since: number, recovery: boolean): number {
  if (p.baseHours == null || !Number.isFinite(p.baseHours)) return Infinity
  const c = Math.max(4, p.baseHours * 1.2) * Math.pow(1.1, Math.max(0, since))
  return recovery ? c * 0.6 : c
}

const LOAD_SPORT = (a: Activity) => a.sport === 'kolo' || a.sport === 'tek' || a.sport === 'pohod'
/**
 * URE IZ RESNICE. Načrt raste od tega, kar res treniraš, ne od tabele: ure na kolesu, teku in v hribih v zadnjih
 * treh polnih tednih pred tem tednom → strop tedna = 1,25 × max(zadnji teden, povprečje treh), vsaj 4 h.
 * Po bolezni ali premoru se načrt tako sam spusti in spet postopno raste; v taperingu in tednu dirke je obseg delež
 * zadnjega polnega tedna (planHours).
 * (v3.48) »Ni podatkov« ni isto kot »ni treniral«: brez aktivnosti v teh tednih je nov uporabnik (brez starejše zgodovine)
 * brez stropa (null), po premoru (starejše vožnje so) pa najnižji začetek 4 h. Prihodnji tedni nimajo še nobene vožnje
 * — ne štejejo kot premor: strop tekočega tedna (iz polnih tednov) raste za ~10 % na teden.
 */
export function realityCap(acts: readonly Activity[], weekStart: string, today: string = todayIso(), skip?: ReadonlySet<string>): { cap: number; base: number; weeks: number[]; gap?: number } | null {
  // (v3.48) tedni po tekočem so napoved iz treh POLNIH tednov pred tekočim (+10 % na teden): nedokončan tekoči teden je ne
  // premika čez teden (prej ponedeljek »11 h od 28. 12.«, nedelja »od 7. 12.«; naslednji teden, sestavljen v ponedeljek, je
  // dobil ~0,8 × dejanskih ur), vožnja z datumom v prihodnosti (napačna ura naprave) pa ne premakne »danes«.
  const cur = weekStartIso(today)
  if (weekStart > cur) {
    const r = realityCap(acts, cur, today, skip)
    return r && { ...r, cap: Math.round(r.cap * Math.pow(1.1, weeksBetween(cur, weekStart)) * 2) / 2 }
  }
  // (v3.50) tedni namenskega premora (»Ta teden …«, skip) ne štejejo — trije polni tedni pred njimi (ni »dolg premor«)
  const ks: number[] = []
  for (let k = 1; ks.length < 3 && k <= 3 + (skip?.size ?? 0); k++) if (!skip?.has(addDays(weekStart, -7 * k))) ks.push(k)
  const wk = (k: number) => { const s = addDays(weekStart, -7 * k), e = addDays(s, 6); return acts.filter(a => LOAD_SPORT(a) && a.date >= s && a.date <= e) }
  const rows = ks.map(wk)
  const hours = rows.map(r => +(r.reduce((t, a) => t + (a.durationMin || 0), 0) / 60).toFixed(1))
  if (rows.reduce((n, r) => n + r.length, 0) < 2) {
    const older = acts.filter(a => LOAD_SPORT(a) && a.date < addDays(weekStart, -7 * (ks[ks.length - 1] ?? 3)))
    if (!older.length) return null
    // (v3.50) začetek po premoru ni za vsakogar 4 h: do 6 tednov premora polovica povprečja zadnjih 4 polnih tednov pred
    // premorom (vsaj 4 h) — U23 s 15 h je prej rabil 14 tednov nazaj do svojih ur; daljši premor kot prej 4 h
    const lastWs = weekStartIso(older.reduce((m, a) => (a.date > m ? a.date : m), older[0]!.date))
    const gap = Math.max(1, weeksBetween(lastWs, weekStart))
    let cap = 4
    if (gap <= 6) {
      const h4 = [0, 1, 2, 3].map(k => { const s = addDays(lastWs, -7 * k), e = addDays(s, 6); return older.filter(a => a.date >= s && a.date <= e).reduce((t, a) => t + (a.durationMin || 0), 0) / 60 })
      cap = Math.max(4, Math.round((h4.reduce((t, h) => t + h, 0) / 4) * 0.5 * 2) / 2)
    }
    return { cap, base: 0, weeks: hours, gap }
  }
  const base = Math.max(hours[0]!, hours.reduce((t, h) => t + h, 0) / hours.length)
  return { cap: Math.round(Math.max(4, base * 1.25) * 2) / 2, base: +base.toFixed(1), weeks: hours }
}

/** Obremenilni teden (šteje za rast ur ~10 % na teden): ne razbremenilni, off-season, po cilju, tapering, dirka. */
const loadWeekCtx = (c: WeekCtx) => !c.recovery && c.phase !== 'prehod' && c.phase !== 'po' && c.phase !== 'tapering' && c.phase !== 'dirka'
/**
 * (v3.50) Strop ur za teden: za prihodnje tedne raste ~10 % samo v obremenilnih tednih — prej je rasel tudi v razbremenilnem,
 * zato je bil teden po njem 20 % nad zadnjim obremenilnim (7,5 → 5,5 → 9 h), vrstica pa je obljubljala »~10 % na teden«.
 */
function capFor(p: Profile, acts: readonly Activity[], weekStart: string, today: string): ReturnType<typeof realityCap> {
  const cur = weekStartIso(today)
  // (v3.50) teden premora ne šteje ne v ure iz resnice ne v rast (+10 %)
  const skip = pauseWeeks(p)
  if (weekStart <= cur) return realityCap(acts, weekStart, today, skip)
  const r = realityCap(acts, cur, today, skip)
  if (!r) return null
  let n = 0
  for (let w = cur; w < weekStart; w = addDays(w, 7)) if (loadWeekCtx(weekContext(p, w)) && !skip.has(w)) n++
  return { ...r, cap: Math.round(r.cap * Math.pow(1.1, n) * 2) / 2 }
}

/**
 * (v3.50) Ure na kolesu v že sestavljenem tednu (shramba): brez tekme in brez »po želji«, na 0,1 h; null, če teden še ni
 * sestavljen. Sezona, meseci in vrstica tako kažejo isto številko kot trak tedna (prej formula 5,5 h ob tednu s 3 h 20 min).
 */
export function storedBikeHours(plan: readonly PlanDay[], weekStart: string): number | null {
  const end = addDays(weekStart, 6)
  const days = plan.filter(d => d.date >= weekStart && d.date <= end)
  if (!days.length) return null
  return Math.round(weekBikeMinutes(days.filter(d => d.role !== 'dirka' && !d.raceId)) / 6) / 10
}

/**
 * (v3.51) Cikel brez cilja s tednom 0 od tega ponedeljka naprej šteje bloke od konca lahkega začetka. Starejši cikli
 * (ob izdaji že v drugem bloku) ostanejo pri starem štetju — prej so ob prehodu dobili do 6 obremenilnih tednov zapored;
 * od 21. 9. naprej je do razbremenilnega tedna največ 3 obremenilne, tudi če je teden po izdaji že sestavljen po starem.
 */
export const NEW_COUNT_FROM = '2026-09-21'

/**
 * Ure tedna za sestavo: cilj iz cikla, omejen s tem, kar res treniraš (realityCap).
 * (v3.48) Tapering največ ~60 %, teden dirke ~40 % zadnjega polnega tedna, kot je bil res sestavljen (base = te ure).
 */
export function planHours(p: Profile, acts: readonly Activity[], weekStart: string, today: string = todayIso(), plan?: readonly PlanDay[]): { hours: number; capped: boolean; base: number | null; idle?: boolean; gap?: number; stored?: boolean; pause?: 'kratek' | 'dolg' } {
  // (v3.50) teden, ki je že sestavljen: ure iz shranjenega načrta, ne iz formule (B02)
  const stored = plan ? storedBikeHours(plan, weekStart) : null
  if (stored != null) return { hours: stored, capped: false, base: null, stored: true }
  const ctx = weekContext(p, weekStart)
  if (ctx.phase === 'tapering' || ctx.phase === 'dirka') {
    const lw = prevLoadWeek(p, weekStart)
    const last = lw ? planHours(p, acts, lw, today, plan).hours : realityCap(acts, weekStart, today, pauseWeeks(p))?.cap ?? null
    const h = last == null ? Infinity : Math.round(last * (ctx.phase === 'tapering' ? 0.6 : 0.4) * 2) / 2
    return h < ctx.hours ? { hours: Math.max(1, h), capped: true, base: last } : { hours: ctx.hours, capped: false, base: null }
  }
  const rc = capFor(p, acts, weekStart, today)
  // (v3.49) novinec po dogovoru brez ene vadbe od začetka načrta (realityCap zanj nima podatkov): načrt ne raste — ostane
  // na ravni 1. tedna, dokler ne začne (prej 0 od 4 sej in naslednji teden daljši)
  if (!rc && p.focus && p.cycleStart && weekStart > p.cycleStart) {
    const ev = evidenceWeek(weekStart, today)
    if (ev >= p.cycleStart && !acts.some(a => a.date >= p.cycleStart! && a.date <= addDays(ev, 6))) {
      const first = weekContext(p, p.cycleStart).hours
      if (first < ctx.hours) return { hours: first, capped: true, base: null, idle: true }
    }
  }
  const out = !rc || rc.cap >= ctx.hours ? { hours: ctx.hours, capped: false, base: rc?.base ?? null, gap: rc?.gap } : { hours: rc.cap, capped: true, base: rc.base, gap: rc.gap }
  // (v3.50) razbremenilni teden največ ~70 % zadnjega obremenilnega tedna — isto pravilo kot proračun v buildWeek, da
  // sezona in meseci ne obljubljajo 5,5 h ob sestavljenih 4 h 20 (B03)
  if (ctx.recovery && ctx.phase !== 'prehod' && ctx.phase !== 'po') {
    const lw = prevLoadWeek(p, weekStart)
    if (lw) { const h = Math.round(planHours(p, acts, lw, today, plan).hours * 0.7 * 2) / 2; if (h < out.hours) out.hours = Math.max(1, h) }
  }
  // (v3.50) prvi teden po premoru (»Ta teden …«): ne nad zadnjim obremenilnim tednom pred premorom (brez skoka na poln
  // obseg); po 8+ dneh premora ~80 % tega — lažji prehod, ne začetek pri 4 h
  const pb = pauseBefore(p, weekStart)
  if (pb && loadWeekCtx(ctx)) {
    const lw = prevLoadWeek(p, pb.first)
    const h0 = lw ? planHours(p, acts, lw, today, plan).hours : null
    const h = h0 == null ? null : pb.long ? Math.round(h0 * 0.8 * 2) / 2 : h0
    if (h != null && h < out.hours) return { ...out, hours: Math.max(1, h), capped: true, pause: pb.long ? 'dolg' : 'kratek' }
  }
  return out
}

function ftpStale(p: Pick<Profile, 'ftp' | 'ftpDate'>, weekStart: string): boolean {
  if (!p.ftp || !p.ftpDate) return true
  return (new Date(weekStart).getTime() - new Date(p.ftpDate).getTime()) / DAY > 28
}

export function weekContext(p: Profile, weekStart: string = weekStartIso(todayIso())): WeekCtx {
  if (isCustom(p)) return focusWeekContext(p, weekStart)
  const T = targetHours(p)
  const goals = seasonGoals(p), peaks = peakGoals(p)
  const start = p.cycleStart || weekStart
  const since = Math.max(0, weeksBetween(start, weekStart))
  // off-season na začetku načrta: tedni počitka in vožnje po občutku (hribi po izbiri; šteje se samo pri začetem načrtu)
  const off = p.cycleStart ? clamp(Math.round(p.offSeasonWeeks ?? 0), 0, OFF_MAX) : 0
  // faze se ravnajo po vrhovih forme (cilj A blizu drugega vrha se vozi v isti formi — samo teden tekme)
  const next = peaks.find(g => weekStartIso(g.date) >= weekStart) ?? null
  const prev = [...peaks].reverse().find(g => weekStartIso(g.date) < weekStart) ?? null
  const shown = next ?? prev
  const ev = shown ? { name: shown.name, date: shown.date, distanceKm: shown.distanceKm } : null
  const last = goals.length ? weekStartIso(goals[goals.length - 1]!.date) : null
  const total0 = last ? Math.max(1, weeksBetween(start, last) + 1) : null
  const e = since - off                                     // tedni od konca off-seasona (0 = prvi teden osnove)
  const mk = (phase: PhaseKey, o: Partial<WeekCtx>): WeekCtx => {
    const volume = o.volume ?? 1
    // teden cilja: dan dirke in polnjenje z OH po dejanskem cilju (ne vedno nedelja, ne pred vsako dirko)
    // (v3.51) v specifičnem je moč samo jedro 1× na teden (noge so za kolo) — prej brez pojasnila
    const strSpec = p.strength?.on && (p.strengthDays ?? 2) > 0 && (!p.strength.phases?.length || p.strength.phases.includes('specificno')) ? ` ${STRENGTH_SPEC}` : ''
    const phaseDesc = phase === 'dirka' && next
      ? `Kratki pospeški in veliko spanja${raceMinutes(next, p) >= CARB_LOAD_RACE_MIN ? ', zadnja dva dni 8–10 g OH na kg telesne teže' : ''}. Dirka v ${dayAcc(next.date)}.`
      : phase === 'specificno' && next && /franj/i.test(next.name) ? SPEC_FRANJA + strSpec
      : phase === 'osnova' || phase === 'gradnja' ? phaseDescFor(p, phase, p.cycleStart ? e + 1 : null)
      : phase === 'specificno' ? PHASE_INFO[phase].desc + strSpec
      : PHASE_INFO[phase].desc
    return {
      phase, phaseName: PHASE_INFO[phase].name, phaseDesc, week: since + 1, total: total0,
      blockWeek: 2, recovery: false, test: false, weeksToEvent: null, event: ev, structured: !!(ev || p.cycleStart),
      easy: 0, goalType: next?.type ?? null, goals: goals.length, baseWeek: p.cycleStart ? e + 1 : null,
      ...o, volume, hours: Math.round(Math.min(T * volume, rampCap(p, Math.max(0, e), !!o.recovery || phase === 'prehod')) * 2) / 2,
    }
  }
  if (p.cycleStart && since < off) {
    const st = offStage(since + 1, off)
    return mk('prehod', { weeksToEvent: next ? weeksBetween(weekStart, weekStartIso(next.date)) : null, volume: st === 'pocitek' ? 0.2 : st === 'vrnitev' ? 0.5 : 0.4, recovery: true, blockWeek: 4, offStage: st })
  }
  if (next) {
    const evWeek = weekStartIso(next.date)
    const wte = weeksBetween(weekStart, evWeek)
    let afterPo = -1, gap = 0                               // tedni po počitku za prejšnjim ciljem (0 = prvi); razmik med vrhovoma
    if (prev) {
      // po cilju sezone teden lahko; dva samo po glavnem cilju ali zelo dolgi dirki (5 h+) pri dolgem razmiku do naslednjega
      // (v3.49: prej dva tedna po ~40 % tudi po enodnevni dirki — U23 6,7 h po VN Kranj)
      const ago = weeksBetween(weekStartIso(prev.date), weekStart)
      gap = weeksBetween(weekStartIso(prev.date), evWeek)
      const rest = gap >= 10 && (prev.main || raceMinutes(prev, p) >= 300) ? 2 : 1
      if (ago <= rest && wte >= 2) return mk('po', { weeksToEvent: wte, volume: 0.5, recovery: true, blockWeek: 4 })
      afterPo = ago - rest - 1
    }
    if (wte === 0) return mk('dirka', { weeksToEvent: 0, volume: 0.4, blockWeek: 4 })
    if (wte === 1) return mk('tapering', { weeksToEvent: 1, volume: 0.6, blockWeek: 4 })
    // bloki se štejejo NAZAJ od taperinga (zadnji teden pred taperingom je vedno težak);
    // med dvema ciljema NAPREJ od počitka (1, 2, 3, razbremenitev …), teden pred taperingom nikoli razbremenilni
    const idx = wte - 2, m = afterPo >= 0 ? afterPo % 4 : idx % 4
    let recovery = afterPo >= 0 ? m === 3 && wte > 2 : m === 3 && since >= off + 2   // v prvih dveh tednih po začetku ni razbremenitve
    let blockWeek = (afterPo >= 0 ? (recovery ? 4 : Math.min(3, m + 1)) : m === 3 ? (recovery ? 4 : 1) : 3 - m) as 1 | 2 | 3 | 4
    let phase: PhaseKey = idx <= 7 ? 'specificno' : idx <= 19 ? 'gradnja' : 'osnova'
    // med cilji sezone ne nazaj v osnovo — (v3.48) razen pri razmiku 20+ tednov (npr. cilj A jeseni, glavni junija):
    // po počitku nov makrocikel z osnovo, sicer bi bližnja tekma pobrisala celo zimsko osnovo
    if (prev && phase === 'osnova' && gap < 20) phase = 'gradnja'
    // lahek začetek sezone: prvi trije tedni po začetku (ali off-seasonu) brez intervalov, če je do prvega cilja dovolj časa
    const easyPlan = !!p.cycleStart && !!peaks[0] && weeksBetween(addDays(start, off * 7), weekStartIso(peaks[0].date)) >= 11
    const easy = easyPlan && !prev && e >= 0 && e < 3 ? ((e + 1) as 1 | 2 | 3) : 0
    // (v3.50) lahki tedni so že lahki — v njih ni razbremenitve (prej 3. teden lahkega začetka hkrati razbremenilni: U23 15 h → 6 h)
    if (easy) recovery = false
    // (v3.50) po lahkem začetku se bloki štejejo NAPREJ (1, 2, 3, R …) in šele v zadnjih 8 tednih pred taperingom (specifično)
    // nazaj — prej so se šteli nazaj od taperinga, zato je po treh lahkih tednih prišel en teden bloka in takoj razbremenilni;
    // razbremenilni je najmanj 3 tedne po lahkem začetku. (v3.49: prvi teden bloka, nato 2., ne naravnost najtežji)
    // Zadnji trije tedni pred razbremenilnim na koncu gradnje (idx 8–10) ostanejo šteti nazaj, da ni dveh razbremenilnih skupaj;
    // razbremenilni naprej še pri idx 10, sicer bi bilo pred njim do 6 obremenilnih tednov zapored.
    let fwdTest = false
    const fwd = easyPlan && !prev && e >= 3 && (idx >= 11 || (idx === 10 && (e - 3) % 4 === 3))
    if (fwd) {
      const f = e - 3, mf = f % 4
      recovery = mf === 3
      blockWeek = (recovery ? 4 : mf + 1) as 1 | 2 | 3 | 4
      fwdTest = recovery && f % 8 === 7
    } else if (easyPlan && !prev && !recovery && (e === 3 || e === 4)) blockWeek = Math.min(blockWeek, e - 2) as 1 | 2
    // (v3.50) prehod v štetje nazaj (idx 10–8, pred razbremenilnim pri idx 7), ko se štetji ne ujemata — a = teden bloka
    // naprej pri idx 11 (0 = 1., 1 = 2., 2 = 3., 3 = razbremenilni = ujemata se). Prej: dvakrat »1. teden bloka« (1-1-2-3),
    // 5 obremenilnih zapored (1-2-1-2-3) ali blok, ki se začne z 2. tednom (R-2-3-R).
    const f11 = e - 3 + idx - 11
    if (easyPlan && !prev && !fwd && idx >= 8 && idx <= 10 && f11 >= 0) {
      const a = f11 % 4
      if (a === 0) blockWeek = (idx === 8 ? 2 : 12 - idx) as 2 | 3          // 1-2-3-2: blok podaljšan za en teden
      else if (a === 2) blockWeek = (idx === 9 ? 1 : 2) as 1 | 2            // R (idx 10) nato 1-2
      else if (a === 1 && f11 >= 5) { recovery = idx === 10; blockWeek = (idx === 10 ? 4 : idx === 9 ? 1 : 2) as 1 | 2 | 4 }   // 1-2-R-1-2
    }
    // test FTP: po lahkih tednih (po off-seasonu vedno, sicer če FTP ni svež), brez lahkega začetka v prvem tednu; nato vsakih
    // 8 tednov. (v3.49) Prvi test je v 1. tednu bloka ali razbremenilnem (ne v najtežjem), naslednji ne prej kot čez 4 tedne
    // (prej dva testa v dveh tednih); uvodni dnevi pred začetkom načrta niso prvi teden
    const firstAt = easyPlan ? off + 3 : 0
    const firstOn = !!p.cycleStart && (easyPlan ? off > 0 || ftpStale(p, addDays(start, firstAt * 7)) : ftpStale(p, start))
    const first = firstOn && since === firstAt && weekStart >= start
    const soon = firstOn && since > firstAt && since - firstAt < 4
    // (v3.50) na prehodu iz štetja naprej v štetje nazaj (razbremenilni pred specifičnim, idx 7): test, če je zadnji test naprej
    // star 7+ tednov — sicer bi bilo med testoma do 14 tednov
    let lateTest = false
    if (easyPlan && !prev && e >= 3 && !fwd && recovery && idx === 7) {
      const fc = e - 3, fmax = fc + idx - 10
      const ft = fmax >= 7 ? fmax - ((fmax - 7) % 8) : 0
      lateTest = fc - ft >= 7
    }
    const test = !easy && (first || (recovery && (fwd ? fwdTest : afterPo >= 0 ? afterPo % 8 === 3 : idx % 8 === 3 || lateTest) && !soon))
    // po dolgem off-seasonu (4+ tednov) počasnejša gradnja: lahki tedni od ~50 %, osnova od ~80 % proti 100 % v 12 tednih
    const long = off >= 4
    const ramp = phase === 'osnova' ? Math.min(1, (long ? 0.8 : 0.85) + ((long ? 0.2 : 0.15) * Math.max(0, e)) / 12) : 1
    // lahki tedni: po off-seasonu od ~60 % ur navzgor (telo se vrača), brez off-seasona od ~75 %
    const volume = recovery ? 0.52 : easy ? (long ? [0.5, 0.6, 0.7] : off > 0 ? [0.6, 0.7, 0.8] : [0.75, 0.8, 0.85])[easy - 1]! : [0.88, 1, 1.12][blockWeek - 1]! * ramp * (phase === 'specificno' ? 0.95 : 1)
    return mk(phase, { weeksToEvent: wte, blockWeek, recovery, test, volume, easy })
  }
  if (prev) {
    const ago = weeksBetween(weekStartIso(prev.date), weekStart)
    // po zadnjem vrhu še cilji A v isti formi: teden lahko, nato vzdrževanje forme (specifično, bloki naprej)
    const later = goals.some(g => g.date >= weekStart)
    // (v3.50) po zadnjem cilju se tedni štejejo od dirke (»Po dirki · teden 1/2«), brez »teden 39/38«
    if (ago <= (later ? 1 : 2)) return mk('po', { weeksToEvent: -ago, volume: 0.5, recovery: true, blockWeek: 4, ...(later ? {} : { week: ago, total: 2 }) })
    if (later) {
      const m = (ago - 2) % 4, recovery = m === 3
      return mk('specificno', { weeksToEvent: null, blockWeek: (recovery ? 4 : Math.min(3, m + 1)) as 1 | 2 | 3 | 4, recovery, volume: recovery ? 0.52 : [0.88, 1, 1.12][Math.min(2, m)]! * 0.95 })
    }
    // nov cikel po zadnjem cilju (off-season ali nov začetek načrta po tekmi): šteje se od konca off-seasona
    // (oz. od konca počitka po tekmi) z lahkimi tedni in testom v 4. tednu — ne naravnost v trde tedne
    if (p.cycleStart && p.cycleStart > weekStartIso(prev.date)) return rolling(Math.max(0, Math.min(e, ago - 3)), -ago, true)
    // (v3.50) po zadnjem cilju brez off-seasona ali novega cilja: lahki tedni (od ~60 %), ne naravnost 9,5 h z VO2max,
    // testom in močjo (prej skok s 5,5 h »po« na 9,5 h v enem tednu); test v 4. tednu
    return rolling(ago - 3, -ago, true, true)
  }
  // brez ciljev: ponavljajoči se 12-tedenski cikel (osnova 4 · gradnja 4 · specifično 4; vsak 4. razbremenilni)
  if (!p.cycleStart) return mk('osnova', { blockWeek: 2, volume: 1 })
  return rolling(e, null, true)

  /** 12-tedenski cikel; fresh = nov začetek (lahki trije tedni, nato razbremenilni s testom); postGoal = po zadnjem cilju. */
  function rolling(n: number, wte: number | null, fresh: boolean, postGoal = false): WeekCtx {
    // (v3.51) nov začetek: bloki se štejejo od konca lahkega začetka (kot s ciljem) — prej je bil 4. teden takoj razbremenilni
    // (novinec: 3 lahki tedni in nato teden 2 h); test FTP je v prvem tednu po lahkem začetku (torek lahko, četrtek test)
    // (v3.51) samo za cikle s tednom 0 od NEW_COUNT_FROM — starejšim se faza ne premakne (R8); do tedna 3 sta štetji enaki
    const v2 = fresh && addDays(weekStart, -7 * n) >= NEW_COUNT_FROM
    const m = v2 && n >= 3 ? n - 3 : n
    const w = m % 12
    // (v3.49) začetnik (raven 1–2) na novem začetku: prvi cikel 8 tednov osnove, nato gradnja — prej je bila osnova
    // le 4 tedne (vse lahki tedni) in že v 6. tednu prag 3 × 15 min
    const slow = fresh && m < 12 && (p.level ?? 3) <= 2
    const phase: PhaseKey = slow ? (w < 8 ? 'osnova' : 'gradnja') : w < 4 ? 'osnova' : w < 8 ? 'gradnja' : 'specificno'
    const easy = fresh && n < 3 ? ((n + 1) as 1 | 2 | 3) : 0
    const blockWeek = (easy ? 1 : (w % 4) + 1) as 1 | 2 | 3 | 4
    const recovery = !easy && blockWeek === 4
    // prvi test FTP: po lahkem začetku (4. teden) ali po off-seasonu; sicer takoj, če FTP ni svež; nato vsakih 8 tednov
    const test = !easy && ((n === (off > 0 || fresh ? 3 : 0) && (off > 0 || ftpStale(p, weekStart))) || (recovery && (v2 ? m % 8 === 7 : w === 11)))
    // lahki tedni kot pred ciljem: po off-seasonu (in po dirki) od ~60 % ur (po dolgem od ~50 %), brez njega od ~75 %
    const volume = recovery ? 0.52 : easy ? (off >= 4 ? [0.5, 0.6, 0.7] : off > 0 || postGoal ? [0.6, 0.7, 0.8] : [0.75, 0.8, 0.85])[easy - 1]! : [0.88, 1, 1.12][blockWeek - 1]!
    // (v3.51) lahek začetek ima svoje štetje (1/3, 2/3, 3/3), nato cikel od 1/12
    return mk(phase, { week: easy ? easy : w + 1, total: easy ? 3 : 12, blockWeek, recovery, test, weeksToEvent: wte, easy, volume })
  }
}

/** Vsi tedni od začetka načrta do tedna zadnjega cilja sezone (za časovnico). */
export function macroWeeks(p: Profile, today: string = todayIso()): (WeekCtx & { weekStart: string })[] {
  const goals = seasonGoals(p)
  if (!goals.length) return []
  const first = p.cycleStart || weekStartIso(today)
  const last = weekStartIso(goals[goals.length - 1]!.date)
  const out: (WeekCtx & { weekStart: string })[] = []
  for (let ws = first; ws <= last && out.length < 80; ws = addDays(ws, 7)) out.push({ ...weekContext(p, ws), weekStart: ws })
  return out
}
/**
 * (v3.48) Tedni sezone z urami iz načrta (planHours: rast od tega, kar res voziš), ne z zgornjo mejo faze —
 * stolpec tedna, »Ure po mesecih« in razdelek tedna kažejo isto številko (prej »zdaj 4,5 h« ob »oktober 8,5–9,5 h«).
 */
export function plannedMacro(p: Profile, acts: readonly Activity[], today: string = todayIso(), plan?: readonly PlanDay[]): (WeekCtx & { weekStart: string })[] {
  // (v3.50) že sestavljeni tedni (prejšnji, ta, naslednji) z urami iz shranjenega načrta, formula samo za tedne, ki še niso sestavljeni
  return macroWeeks(p, today).map(w => ({ ...w, hours: planHours(p, acts, w.weekStart, today, plan).hours }))
}
/**
 * (v3.51) Kolesar brez cilja: 12 tednov cikla od tega tedna z urami iz načrta (kot plannedMacro) — prej Plan ni imel
 * nobenega pogleda tednov naprej. Prazno s ciljem, brez začetega načrta in pri načrtu po meri.
 */
export function cycleMacro(p: Profile, acts: readonly Activity[], today: string = todayIso(), plan?: readonly PlanDay[]): (WeekCtx & { weekStart: string })[] {
  if (isCustom(p) || !p.cycleStart || seasonGoals(p).length) return []
  const ws0 = weekStartIso(today)
  return Array.from({ length: 12 }, (_, k) => { const ws = addDays(ws0, 7 * k); return { ...weekContext(p, ws), weekStart: ws, hours: planHours(p, acts, ws, today, plan).hours } })
}
/**
 * (v3.48) Kdaj načrt doseže normalen teden: ure tega tedna iz načrta, polne ure (največ izbrane) in teden, od katerega
 * veljajo. Isto pravilo kot vrstica o urah na Planu — kartica cilja v Napredku ne sme reči »11 h od 9. 11.«, Plan pa »od 4. 1.«.
 */
export function rampOf(p: Profile, acts: readonly Activity[], today: string = todayIso(), macro = plannedMacro(p, acts, today)): { now: number; to: number; at: string | null } {
  const ws = weekStartIso(today)
  const now = macro.find(w => w.weekStart === ws)?.hours ?? planHours(p, acts, ws, today).hours
  const load = macro.filter(w => w.weekStart > ws && !w.recovery && w.phase !== 'tapering' && w.phase !== 'dirka' && w.phase !== 'po' && w.phase !== 'prehod')
  const to = Math.min(targetHours(p), Math.max(now, ...load.map(w => w.hours)))
  return { now, to, at: load.find(w => w.hours >= to - 0.01)?.weekStart ?? null }
}

/* ====================================================================
   MOČ ZA KOLESARJA: jedro in noge, 2 × 20–30 min (ne »mišice za ogledalo«).
   Napredovanje iz zadnje zabeležene seje z istim naslovom: obseg ponovitev ostane, kg se prevzamejo;
   ko je bila zgornja meja ponovitev zabeležena v vseh serijah, naslednjič +2,5 kg (težke vaje s palico +5 kg).
   ==================================================================== */
export type StrengthKind = 'jedro' | 'noge' | 'fitnesA' | 'fitnesB'
export type Exercise = { name: string; sets: number; reps: string; kg?: number | null }
const STR: Record<StrengthKind, [string, number, string][]> = {
  jedro: [['Deska', 3, '45–60 s'], ['Stranska deska', 3, '30–45 s'], ['Dvig nog leže', 3, '10–15'], ['Dead bug', 3, '8–12']],
  noge: [['Bolgarski počep', 3, '8–12'], ['Izpadni koraki', 3, '10–12'], ['Dvigi na prste', 3, '15–20'], ['Deska', 3, '45–60 s']],
  // fitnes (Rønnestad & Mujika 2014: težka moč 2 × na teden izven sezone, 4–10 ponovitev, večsklepne vaje za noge)
  fitnesA: [['Polovični počep s palico', 4, '5–8'], ['Nožna preša na eni nogi', 3, '6–8'], ['Romunski mrtvi dvig', 3, '6–8'], ['Dvig kolena na kablu (upogib kolka)', 3, '8–10'], ['Dvigi na prste stoje', 3, '10–12'], ['Deska', 3, '45–60 s']],
  fitnesB: [['Stopanje na klop z ročkami', 3, '6–8'], ['Hip thrust', 3, '6–8'], ['Bolgarski počep z ročkami', 3, '6–8'], ['Enoročno veslanje z ročko', 3, '8–10'], ['Pallof press', 3, '10–12'], ['Dead bug', 3, '8–12']],
}
export const STRENGTH_TITLE: Record<StrengthKind, string> = { jedro: 'Moč — jedro', noge: 'Moč — noge in jedro', fitnesA: 'Fitnes — noge (težko)', fitnesB: 'Fitnes — noge, hrbet, jedro' }
// (v3.49) težke noge 65 min: s pavzami 2–3 min trajajo časovniki vodene vadbe ~59 min in serije še ~8 min (prej 55 min)
const STRENGTH_MIN: Record<StrengthKind, number> = { jedro: 20, noge: 30, fitnesA: 65, fitnesB: 50 }
/** lažji teden (serija manj): kot prej, ~¾ polne seje */
const STRENGTH_LIGHT_MIN: Record<StrengthKind, number> = { jedro: 15, noge: 23, fitnesA: 41, fitnesB: 38 }

export function strengthSession(kind: StrengthKind, p: Profile, activities: readonly Activity[], light = false): { title: string; exercises: Exercise[]; desc: string; progressed: boolean; min: number } {
  const ex: Exercise[] = STR[kind].map(([name, sets, reps]) => ({ name, sets: light ? Math.max(2, sets - 1) : sets, reps, kg: name === 'Bolgarski počep' && p.gear.dumbbells ? p.gear.dumbbellKg || null : null }))
  const title = STRENGTH_TITLE[kind]
  const last = [...activities].filter(a => a.sport === 'moc' && a.name === title && a.exercises && a.exercises.length).sort((a, b) => b.date.localeCompare(a.date))[0]
  let progressed = false
  // (v3.49) doma brez uteži (ali z vsemi, ki jih imaš): napredek s serijami, ponovitvami, počasnim spustom in časom
  const steps: string[] = []
  const home = kind === 'noge' || kind === 'jedro'
  if (last && !light) {
    for (const x of ex) {
      const z = last.exercises!.find(y => y.name.toLowerCase() === x.name.toLowerCase())
      if (!z) continue
      if (z.kg && Number.isFinite(z.kg) && z.kg > 0) x.kg = z.kg
      if (z.sets > x.sets) x.sets = Math.min(5, z.sets)
      // obseg ponovitev ostane (ne raste v nedogled); teža gor šele, ko je bila zgornja meja res zabeležena
      const top = repsTop(x.reps), got = repsLogged(z.reps)
      let up = false
      if (x.kg && top != null && got != null && got >= top) {
        const next = x.kg + (/počep s palico|mrtvi dvig|hip thrust/i.test(x.name) && x.kg >= 40 ? 5 : 2.5)
        const max = p.strength.equipment !== 'gym' && x.name === 'Bolgarski počep' ? p.gear.dumbbellKg ?? null : null   // doma: le toliko, kolikor imaš uteži
        if (max == null || next <= max) { x.kg = next; progressed = true; up = true }
      }
      if (!home || up) continue
      const step = homeStep(x, STR[kind].find(([n]) => n === x.name)?.[1] ?? 3, activities, title)
      if (step) steps.push(step)
    }
  }
  const desc = light ? 'Lažja različica: manj serij, ista tehnika.'
    : kind === 'jedro' ? 'Po kolesu ali zvečer. Močan trup = zgornji del telesa miruje, vsi vati gredo v pedala.'
    : kind === 'fitnesA' ? 'Fitnes: 10 min ogrevanja (sobno kolo), nato težko — zadnji 2 ponovitvi naj bosta težki, tehnika pred kilogrami. Med serijami 2–3 min. Ko vse serije narediš z zgornjo mejo ponovitev, naslednjič +2,5–5 kg. Kilograme vpiši — naslednja seja jih prevzame.'
    : kind === 'fitnesB' ? 'Fitnes: 10 min ogrevanja, nato enonožne vaje (moč in ravnotežje za pedaliranje) + hrbet in jedro za držo na kolesu. Med serijami 90 s. Kilograme vpiši — naslednja seja jih prevzame.'
    : 'Počasi in s kontrolo. Noge za klance in stabilnost; ko dosežeš zgornjo mejo ponovitev, dodaj težo (nahrbtnik ali uteži).'
  const more = steps.length ? ` Prejšnjič vse ponovitve — danes ${steps.join(', ')}.${ex.some(e => /počasi dol/.test(e.reps)) ? ' Ko zmoreš vse ponovitve počasi, dodaj nahrbtnik in vpiši kilograme.' : ''}` : ''
  return { title, exercises: ex, desc: (progressed && !light ? desc + ' Prejšnjič zgornja meja ponovitev — teža je višja.' : desc) + more, progressed: progressed || steps.length > 0, min: light ? STRENGTH_LIGHT_MIN[kind] : STRENGTH_MIN[kind] }
}
/**
 * (v3.49) Napredek moči doma brez uteži (prej 3 × 8–12 vseh 38 tednov): ko so bile vse serije na zgornji meji, najprej
 * serija več (do 4), nato več ponovitev, nato počasen spust (»počasi dol«). Vaja na čas (deska): po dveh polnih sejah
 * na istem času +15 s, do 90 s. Merilo so polne seje (lažji teden s serijo manj ne vrne na začetek). Spremeni vajo x
 * in vrne kratek opis napredka (ali null).
 */
function homeStep(x: Exercise, base: number, activities: readonly Activity[], title: string): string | null {
  const k = x.name.toLowerCase()
  const full = [...activities].filter(a => a.sport === 'moc' && a.name === title).sort((a, b) => b.date.localeCompare(a.date))
    .map(a => a.exercises?.find(e => e.name.toLowerCase() === k)).filter((e): e is Exercise => !!e && e.sets >= base)
  const z = full[0]
  if (!z) return null
  x.sets = Math.max(x.sets, Math.min(5, z.sets))
  const TIME = /^(\d+)\s*[–-]\s*(\d+)\s*s$/
  const tm = TIME.exec(x.reps.trim())
  if (tm) {
    const cur = TIME.exec(String(z.reps).trim()) ?? tm
    const lo = +cur[1]!, hi = +cur[2]!
    x.reps = `${lo}–${hi} s`
    if (hi >= 90 || full.length < 2 || !full.slice(0, 2).every(e => String(e.reps).trim() === x.reps)) return null
    x.reps = `${lo + 15}–${Math.min(90, hi + 15)} s`
    return `${x.name} ${x.reps}`
  }
  // brez uteži ali z vsemi utežmi, ki jih imaš (kg ostanejo)
  const top = repsTop(x.reps), got = repsLogged(z.reps)
  if (top == null || got == null || got < top) return null
  const lo = +(/^(\d+)/.exec(x.reps)?.[1] ?? top), span = Math.max(3, top - lo), hi2 = top + span
  if (z.sets < 4) { x.sets = Math.max(x.sets, Math.min(4, z.sets + 1)); return `${x.name} ${x.sets} serije` }
  if (got >= hi2) { x.reps = `${top}–${hi2}, počasi dol`; return `${x.name} počasi dol` }
  x.reps = `${top}–${hi2}`
  return `${x.name} ${x.reps}`
}
/** Zgornja meja ponovitev (»6–8« → 8); pri vajah na čas (»45–60 s«) null — tam se ne dodaja teže. */
function repsTop(reps: string): number | null {
  if (/\ds\b|\d\s*s\b|sek/i.test(reps)) return null
  const m = String(reps).match(/(\d+)\s*[–-]\s*(\d+)/)
  return m ? +m[2]! : /^\s*\d+\s*$/.test(reps) ? +reps : null
}
/**
 * Koliko ponovitev je bilo zabeleženih v najslabši seriji: »8« → 8, »8, 8, 7« ali »8/8/7« → 7, razpon »6–8« → 6
 * (predpisan razpon, prepisan v dnevnik, ne pove, da je bila zgornja meja dosežena). Na čas ali brez števila: null.
 */
function repsLogged(reps: string): number | null {
  const s = String(reps ?? '')
  if (/\ds\b|\d\s*s\b|sek/i.test(s)) return null
  const range = s.match(/^\s*(\d+)\s*[–-]\s*(\d+)\s*$/)
  if (range) return Math.min(+range[1]!, +range[2]!)
  const nums = (s.match(/\d+/g) || []).map(Number).filter(n => Number.isFinite(n) && n > 0)
  return nums.length ? Math.min(...nums) : null
}

/* ====================================================================
   KNJIŽNICA SEJ — vati iz FTP
   ==================================================================== */
interface Sess {
  title: string; desc: string; min: number; zone: string; tss: number; target: { lo: number; hi: number } | null; role: NonNullable<PlanDay['role']>; why: string | null
  /** privzeto kolo (test: test); hribi = pohod */ kind?: PlanKind
  /** po želji (ne šteje v realizacijo) */ optional?: boolean
  /** ne krajša se in ne odpade, ko je teden čez proračun (predaktivacija pred tekmo) */ fixed?: boolean
  /** ključni trening, ki sme odpasti, ko je teden čez proračun (tapering, teden dirke) — manjša številka odpade prej */ drop?: number
}

const watts = (p: Profile, a: number, b: number) => (p.ftp ? { lo: Math.round(p.ftp * a), hi: Math.round(p.ftp * b) } : null)
/** (v3.49) cona po občutku (brez merilnika in brez utripa) */
const RPE_OF: Record<'Z1' | 'Z2' | 'Z3' | 'Z4' | 'Z5', string> = { Z1: 'RPE 2 (zelo lahko)', Z2: 'RPE 3–4 (pogovorni tempo)', Z3: 'RPE 6–7 (zmerno težko)', Z4: 'RPE 8 (težko, a enakomerno)', Z5: 'RPE 9 (zelo težko)' }
function wtxt(p: Profile, a: number, b: number, z: 'Z1' | 'Z2' | 'Z3' | 'Z4' | 'Z5'): string {
  const w = watts(p, a, b)
  const pc = `${Math.round(a * 100)}–${Math.round(b * 100)} % FTP`
  if (noPower(p)) {
    const hr = lthrZoneText(p, z)
    if (hr) return `${hr}${w ? ` (≈ ${w.lo}–${w.hi} W, brez merilnika po občutku)` : ''}`
    // (v3.49) brez merilnika in brez utripa: po občutku, ne »76–85 % FTP« brez FTP
    return `${RPE_OF[z]}${w ? ` (≈ ${w.lo}–${w.hi} W)` : ''}`
  }
  return w ? `${w.lo}–${w.hi} W (${pc})` : `${pc} (${zoneText(p, z)})`
}
const tssOf = (minutes: number, IF: number) => Math.round((minutes / 60) * IF * IF * 100)

function intervals(p: Profile, o: { name: string; reps: number; work: number; rest: number; a: number; b: number; z: 'Z3' | 'Z4' | 'Z5'; note: string; why?: string | null; min?: number }): Sess {
  const wu = 20, cd = 15
  const core = o.reps * o.work + (o.reps - 1) * o.rest
  const base = wu + core + cd
  const dur = Math.max(o.min || 0, r5(base))
  const extra = dur - base
  // (v3.48) Z2 na 5 min, ostanek gre v iztek (prej »nato 19 min Z2«)
  const z2x = extra >= 10 ? r5(extra) : 0, cdx = cd + (z2x ? extra - z2x : 0)
  const IF = (o.a + o.b) / 2
  // (v3.48) kratki napori brez merilnika: »3 × 1 min zelo trdo (RPE 9)« — brez »pri po občutku«, zaostajanje utripa na koncu
  const feel = noPower(p) && o.work <= 2
  const how = feel ? `${o.z === 'Z5' ? 'zelo trdo' : 'trdo'} (RPE ${o.z === 'Z5' ? 9 : 8})` : `pri ${wtxt(p, o.a, o.b, o.z).replace(/^utrip /, 'utripu ')}`
  const desc = `20 min ogrevanje s 3 kratkimi pospeški · ${o.reps} × ${o.work} min ${how}, vmes ${o.rest} min lahko${z2x ? ` · nato ${z2x} min Z2 (${zoneText(p, 'Z2')})` : ''} · ${cdx} min iztek. ${o.note}${feel ? ' Brez merilnika moči: utrip pri kratkih naporih zaostaja — vozi po občutku.' : ''}`
  const tss = tssOf(o.reps * o.work, IF) + tssOf(dur - o.reps * o.work, 0.6)
  return { title: `${o.name} ${o.reps} × ${o.work} min`, desc, min: dur, zone: o.z, tss, target: watts(p, o.a, o.b), role: 'kljucna', why: o.why ?? null }
}

const WHY_VO2 = 'Dvigne strop: več kisika = hitrejši na klancu in v napadih. Enkrat na teden, spočit in nahranjen.'
function vo2(p: Profile, phase: PhaseKey, bw: number, g: SeasonGoal | null = null): Sess {
  const note = 'Enakomerno od prvega do zadnjega — če zadnjega ne zmoreš v razponu, je bil prvi prehiter.'
  if (phase === 'osnova') return intervals(p, { name: 'VO2max', reps: bw === 1 ? 4 : 5, work: 4, rest: 4, a: 1.08, b: 1.15, z: 'Z5', note, why: WHY_VO2, min: 75 })
  if (phase === 'gradnja') return bw === 2
    ? intervals(p, { name: 'VO2max', reps: 4, work: 5, rest: 5, a: 1.1, b: 1.15, z: 'Z5', note, why: WHY_VO2, min: 90 })
    : intervals(p, { name: 'VO2max', reps: bw === 1 ? 5 : 6, work: 4, rest: 4, a: 1.1, b: 1.18, z: 'Z5', note, why: WHY_VO2, min: 90 })
  if (bw === 3) return intervals(p, { name: 'VO2max', reps: 6, work: 3, rest: 3, a: 1.15, b: 1.2, z: 'Z5', note: `Kratko in ostro — kot pospeški ${g && /franj/i.test(g.name) ? 'skupine na Kladju' : 'v skupini'}.`, why: WHY_VO2, min: 90 })
  return intervals(p, { name: 'VO2max', reps: bw === 1 ? 5 : 4, work: bw === 1 ? 4 : 5, rest: bw === 1 ? 4 : 5, a: 1.1, b: 1.2, z: 'Z5', note, why: WHY_VO2, min: 90 })
}

/** (v3.50) OH na uro iz iste tabele kot Gorivo (nutrition/fuelrate.ts) — prej »50–60 g«, Gorivo pa 50 ali 60 */
const fuelLong = (min: number) => `Gorivo: od 30. minute ~${fuelGph({ kind: 'kolo', durationMin: min, role: 'dolga' })} g ogljikovih hidratov na uro in 500–750 ml tekočine na uro — kaj vzeti in kdaj jesti piše v Gorivu.`
const simFuel = (min: number, title: string) => `~${fuelGph({ kind: 'kolo', durationMin: min, role: 'dolga', title })} g OH na uro`
const z2Fuel = (min: number) => { const g = fuelGph({ kind: 'kolo', durationMin: min, zone: 'Z2', role: 'lahka' }); return g ? ` Od 30. minute ~${g} g OH na uro.` : '' }
/** Številka goriva v opisu po trajanju seje (dolga: ~50/60 g; lahka Z2 pod 90 min brez goriva). */
function fuelFix(s: Sess): Sess {
  let desc = s.desc
  if (s.role === 'dolga') desc = desc.replace(/(od 30\. minute |Gorivo )~\d+ g (ogljikovih hidratov|OH) na uro/g, (_m, a: string, b: string) => `${a}~${fuelGph({ kind: 'kolo', durationMin: s.min, role: 'dolga', title: s.title })} g ${b} na uro`)
  else if (s.role === 'lahka' && s.min < 90) desc = desc.replace(' Od 30. minute ~40 g OH na uro.', '')
  return desc === s.desc ? s : { ...s, desc }
}
/** (v3.48) Franja, Kladje in 156 km samo, ko je cilj res Franja; sicer dirka iz cilja ali splošno. */
function dolga(p: Profile, phase: PhaseKey, min: number, recovery: boolean, g: SeasonGoal | null = null): Sess {
  const z2 = zoneText(p, 'Z2')
  const franja = !!g && /franj/i.test(g.name)
  if (recovery) return { title: 'Lahka daljša Z2', desc: `Mirno ${z2}, brez klancev na silo. ${fuelLong(min)}`, min, zone: 'Z2', tss: tssOf(min, 0.62), target: null, role: 'dolga', why: 'Razbremenilni teden: volumen dol, da se prilagoditve zgodijo.' }
  if (phase === 'gradnja' && min >= 150) return { title: 'Dolga Z2 + tempo', desc: `Enakomerno ${z2}; v zadnji uri 2 × 15 min tempo pri ${wtxt(p, 0.76, 0.88, 'Z3')}. ${fuelLong(min)}`, min, zone: 'Z2', tss: tssOf(min - 30, 0.65) + tssOf(30, 0.82), target: watts(p, 0.76, 0.88), role: 'dolga', why: `Tempo na utrujenih nogah — točno to zahteva druga polovica ${franja ? 'Franje' : 'dolge dirke'}.` }
  if (phase === 'specificno' && min >= 150) return { title: franja ? 'Simulacija Franje' : g ? 'Simulacija dirke' : 'Dolga Z2 + tempo na klancih', desc: `Z2 ${z2}; na daljših klancih 2 × 20 min pri ${wtxt(p, 0.85, 0.92, 'Z3')}. ${g ? `Gorivo kot na dirki: ${simFuel(min, 'Simulacija')} od 30. minute. Po možnosti v skupini.` : fuelLong(min)}`, min, zone: 'Z2', tss: tssOf(min - 40, 0.66) + tssOf(40, 0.88), target: watts(p, 0.85, 0.92), role: 'dolga', why: g ? 'Vadiš tempo, gorivo in vožnjo v skupini za dan D.' : 'Tempo na klancih sredi dolge vožnje: vzdržljivost in gorivo v enem.' }
  return { title: 'Dolga Z2', desc: `Enakomerno ${z2}, visoka kadenca, brez špicev. ${fuelLong(min)}`, min, zone: 'Z2', tss: tssOf(min, 0.65), target: null, role: 'dolga', why: `Dolga Z2 gradi motor: mitohondrije, kurjenje maščob, vzdržljivost${g?.distanceKm && raceMinutes(g, p) >= CARB_LOAD_RACE_MIN ? ` za ${g.distanceKm} km` : ''}.` }
}
const z2Ride = (p: Profile, min: number, sunday = false): Sess => ({ title: sunday ? 'Z2 — sam ali v skupini' : 'Z2 vzdržljivost', desc: `Mirno ${zoneText(p, 'Z2')}, kadenca 90+. Če si utrujen, skrajšaj — ne pospešuj.${z2Fuel(min)}`, min, zone: 'Z2', tss: tssOf(min, 0.65), target: null, role: 'lahka', why: null })
/** (v3.50) Privzeti »Dodaj trening«: ista predloga in cona kot Z2 v načrtu (prej »kadenca 85–95« brez utripa/vatov). */
export function defaultZ2(p: Profile, min = 60): Pick<PlanDay, 'kind' | 'title' | 'desc' | 'durationMin' | 'zone' | 'tssTarget' | 'role' | 'target'> {
  const s = z2Ride(p, min)
  return { kind: 'kolo', title: s.title, desc: s.desc, durationMin: s.min, zone: s.zone, tssTarget: s.tss, role: s.role, target: null }
}
/** Ključni trening + Z2 za njim (velik obseg: dan je daljši, intervali ostanejo enaki). */
const longer = (p: Profile, s: Sess, add: number): Sess => add < 15 ? s : ({ ...s, min: s.min + add, tss: s.tss + tssOf(add, 0.65), desc: `${s.desc} Po izteku še ${add} min Z2 (${zoneText(p, 'Z2')}).` })
/** (v3.50) Zakaj po dnevu: petek »pred vikendom«, po tekmi »po tekmi«, sicer splošno (prej vedno »pred vikendom«, tudi v soboto po tekmi). */
const regen = (p: Profile, min: number, when: 'vikend' | 'tekma' | null = 'vikend'): Sess => ({ title: 'Regeneracija', desc: `Zelo lahko (${zoneText(p, 'Z1')}) — noge samo vrtijo. Lahko tudi prosto.`, min, zone: 'Z1', tss: tssOf(min, 0.5), target: null, role: 'regen', why: when === 'tekma' ? 'Kri v nogah pospeši regeneracijo po tekmi.' : when === 'vikend' ? 'Kri v nogah pospeši regeneracijo pred vikendom.' : 'Kri v nogah pospeši regeneracijo.' })
/** (v3.48) Iztek v opisu = ostanek do 60 min (kot v vodeni vadbi); brez merilnika moči brez vatov — pražni utrip. */
const testSess = (p: Profile): Sess => {
  const min = 60, cd = min - 40
  // (v3.50) brez merilnika in brez utripa: test na istem odseku, napredek je čas — ne »povprečni utrip«, ki ga ne more izmeriti
  const feel = noPower(p) && !lthrOf(p)
  const desc = feel
    ? `15 min ogrevanje s 3 × 1 min hitreje, 5 min lahko, 20 min čim močneje in enakomerno na istem klancu ali odseku kot zadnjič, ${cd} min iztek. Brez merilnika in utripa je tvoj napredek čas na odseku — zapiši ga.`
    : noPower(p)
    ? `15 min ogrevanje s 3 × 1 min hitreje, 5 min lahko, 20 min čim močneje in enakomerno, ${cd} min iztek. Brez merilnika moči: povprečni utrip zadnjih 15 min ≈ tvoj pražni utrip — vpiši ga v Nastavitve.`
    : `15 min ogrevanje s 3 × 1 min hitreje, 5 min lahko, 20 min enakomerno čim močneje, ${cd} min iztek. FTP = 95 % povprečja teh 20 min.${p.ftp ? ` Začni pri ~${Math.round(p.ftp * 1.02)} W in zadnjih 5 min stisni.` : ''}`
  return { title: '20-minutni test FTP', desc, min, zone: 'test', tss: 70, target: null, role: 'test', why: feel ? 'Isti odsek vsakih 8 tednov: hitrejši čas = napredek, tudi brez številk.' : noPower(p) ? 'Nov pražni utrip = prave cone za naslednje tedne.' : 'Nov FTP = prave cone in vati za naslednje tedne. Vpiši ga v Napredek.' }
}

/* ====================================================================
   CELOVIT KOLESAR: klanci, ravnina, šprint, vzdržljivost — izmenično skozi vse leto.
   Pred cilji sezone specifičen blok po vrsti dirke (šprint, klanci, vzpon, maraton, kronometer, cestna).
   ==================================================================== */
const sec = (x: number) => (x >= 60 ? `${Math.floor(x / 60)} min${x % 60 ? ` ${x % 60} s` : ''}` : `${x} s`)
/** Kratke ponovitve (napadi, šprinti, 30/15): serije × ponovitve × sekunde. */
function reps(p: Profile, o: { name: string; title?: string; sets: number; n: number; on: number; off: number; setRest: number; a: number; b: number; note: string; why: string; min?: number; z?: 'Z4' | 'Z5' }): Sess {
  const work = o.sets * (o.n * (o.on + o.off) - o.off) + (o.sets - 1) * o.setRest
  const dur = Math.max(o.min || 0, r5(20 + work / 60 + 15))
  const pc = `${Math.round(o.a * 100)}–${Math.round(o.b * 100)} % FTP`
  const w = watts(p, o.a, o.b)
  // (v3.48) brez merilnika »30 s zelo trdo, a enakomerno« (brez »pri«), zaostajanje utripa na koncu opisa
  const how = noPower(p) ? (o.b >= 1.4 ? 'vse, kar gre' : 'zelo trdo, a enakomerno') : `pri ${w ? `${w.lo}–${w.hi} W (${pc})` : pc}`
  // 2 seriji, 3–4 serije, 5+ serij; med serijama (2) / serijami (3+)
  const setTxt = o.sets > 1 ? `${o.sets} ${o.sets === 2 ? 'seriji' : o.sets <= 4 ? 'serije' : 'serij'} × ` : ''
  const desc = `20 min ogrevanje s 3 kratkimi pospeški · ${setTxt}${o.n} × (${sec(o.on)} ${how} / ${sec(o.off)} lahko)${o.sets > 1 ? `, med ${o.sets === 2 ? 'serijama' : 'serijami'} ${sec(o.setRest)} lahko` : ''} · ostanek Z2 (${zoneText(p, 'Z2')}), 15 min iztek. ${o.note}${noPower(p) ? ' Brez merilnika moči: utrip pri kratkih naporih zaostaja — vozi po občutku.' : ''}`
  const tss = tssOf((o.sets * o.n * o.on) / 60, (o.a + o.b) / 2) + tssOf(dur - (o.sets * o.n * o.on) / 60, 0.62)
  return { title: o.title || `${o.name} ${setTxt}${o.n} × ${sec(o.on)}`, desc, min: dur, zone: o.z || 'Z5', tss, target: null, role: 'kljucna', why: o.why }
}
const WHY_SPRINT = 'Šprint vsak teden: živčno-mišična moč ostane skozi vse leto, utrujenosti skoraj ne naredi.'
/** Šprinti v lahki vožnji (6–8 × 10–15 s, vmes 4–5 min zelo lahko). */
function withSprints(s: Sess, heavy = false): Sess {
  const n = heavy ? 8 : 6, t = heavy ? 15 : 10
  return { ...s, title: `${s.title} + ${n} × ${t} s šprint`, desc: `${s.desc} Na sredi ${n} × ${t} s šprint — vse, kar gre, iz 25–30 km/h, izmenično sede in stoje; vmes 4–5 min zelo lahko.`, tss: s.tss + n * 2, why: s.why || WHY_SPRINT }
}
/** Rønnestad 2020: 30/15 v treh serijah je pri treniranih kolesarjih dvignil več kot 4 × 5 min. */
const thirty15 = (p: Profile) => reps(p, { name: '30/15', title: '30/15 — 3 serije × 13', sets: 3, n: 13, on: 30, off: 15, setRest: 180, a: 1.2, b: 1.3, note: 'Vsaka 30-sekundna ponovitev enako trdo kot prva; če pade, končaj serijo.', why: 'Kratki intervali z mikro odmori: veliko časa blizu VO2max in pospeški kot na dirki.', min: 90 })
function overUnder(p: Profile, climb = false): Sess {
  // (v3.49) brez merilnika po občutku, ne »% FTP«; z merilnikom vati vsakega dela — vodena vadba in ura ju izmenjujeta
  const lo = watts(p, 0.93, 0.97), hi = watts(p, 1.03, 1.07)
  const parts = noPower(p) ? '2 min tik pod pragom + 1 min malo nad njim'
    : lo && hi ? `2 min pri ${lo.lo}–${lo.hi} W + 1 min pri ${hi.lo}–${hi.hi} W` : '2 min pri 93–97 % FTP + 1 min pri 103–107 % FTP'
  const s = intervals(p, { name: 'Over-under', reps: 3, work: 9, rest: 5, a: 0.95, b: 1.05, z: 'Z4', note: `Vsak interval 3 × (${parts})${climb ? ', na klancu' : ''} — pospeški nad pragom in okrevanje na pragu, kot na dirki.`, why: 'Spremembe tempa: napadi na klancu, beg, vodenje skupine.', min: 105 })
  return s
}
/** Ključni trening 2 (četrtek): izmenično ravnina, klanec, over-under; pred ciljem po vrsti dirke. */
function k2Of(p: Profile, ctx: WeekCtx, g: SeasonGoal | null): Sess {
  const bw = ctx.blockWeek
  if (ctx.phase === 'specificno' && g) return specific2(p, g, bw)
  // (v3.49) začetnik (raven 1–2) v prvih 12 tednih tudi v gradnji sweet spot, ne prag (kot blag prvi VO2max v k1Of)
  const novice = (p.level ?? 3) <= 2 && ctx.baseWeek != null && ctx.baseWeek <= 12 && ctx.phase !== 'specificno'
  if (ctx.phase === 'osnova' || novice) {
    const [reps, work] = bw === 1 ? [3, 12] : bw === 2 ? [3, 15] : [2, 20]
    const v = bw === 1 ? { t: 'Sweet spot na ravnini', note: 'Na ravnini v spodnjem držalu, kadenca 85–95 — moč za ravnino in vodenje.' }
      : bw === 2 ? { t: 'Sweet spot na klancu', note: 'Na klancu 4–7 %, sede, kadenca 70–80 — moč za klance.' }
      : { t: 'Sweet spot', note: 'Kjerkoli, enakomerno. Kadenca 85–95.' }
    return intervals(p, { name: v.t, reps, work, rest: 5, a: 0.88, b: 0.93, z: 'Z3', note: v.note, why: 'Sweet spot da največ aerobnega napredka na minuto; izmenično ravnina in klanec, da si dober povsod.', min: 90 })
  }
  if (bw === 3) return overUnder(p, g?.type === 'klanci' || g?.type === 'vzpon')
  const [reps, work, a, b] = bw === 1 ? [3, 12, 0.95, 1] : [3, 15, 0.93, 0.98]
  return intervals(p, { name: bw === 1 ? 'Prag na ravnini' : 'Prag na klancu', reps, work, rest: 5, a, b, z: 'Z4', note: bw === 1 ? 'Na ravnini v spodnjem držalu, enakomerno — kot beg ali vodenje skupine.' : 'Na klancu 5–8 %, sede, kadenca 75–85, enakomerno.', why: 'Prag premakne FTP; izmenično ravnina in klanec.', min: 105 })
}
/** Specifični blok pred ciljem: kar odloča na tej dirki. */
function specific2(p: Profile, g: SeasonGoal, bw: number): Sess {
  switch (g.type) {
    case 'vzpon': {
      const [reps, work] = bw === 1 ? [2, 20] : bw === 2 ? [3, 15] : [1, 30]
      return intervals(p, { name: 'Vzpon', reps, work, rest: 8, a: 0.95, b: 1.0, z: 'Z4', note: 'Na čim daljšem klancu s podobnim naklonom kot na tekmi; sede, prvih 5 min ne prehitro.', why: `Specifično za ${g.name}: enakomerno na pragu toliko časa, kot traja vzpon.`, min: 105 })
    }
    case 'klanci':
      return bw === 2 ? intervals(p, { name: 'Klanci', reps: 6, work: 3, rest: 3, a: 1.05, b: 1.1, z: 'Z5', note: 'Na klancu 5–8 %, vsak vzpon enako močno, navzdol mirno.', why: `Specifično za ${g.name}: ponavljajoči se klanci in napadi.`, min: 105 })
        : bw === 3 ? reps(p, { name: 'Napadi na klancu', title: 'Klanci z napadi 5 × 4 min', sets: 1, n: 5, on: 240, off: 240, setRest: 0, a: 1.0, b: 1.1, note: 'Vsak 4-min vzpon: prvih 20 s napad (130 %+), nato na pragu do vrha.', why: `Specifično za ${g.name}: napad in zdržati tempo do vrha.`, min: 105 })
        : overUnder(p, true)
    case 'sprint':
      return bw === 1 ? reps(p, { name: 'Napadi', sets: 3, n: 5, on: 30, off: 30, setRest: 300, a: 1.4, b: 1.6, note: 'Vsaka ponovitev kot napad iz skupine; na koncu serije 15 s šprint do konca.', why: `Specifično za ${g.name}: napadi in zaključek.`, min: 90 })
        : bw === 2 ? reps(p, { name: 'Šprint iz zavetrja', sets: 2, n: 4, on: 15, off: 285, setRest: 600, a: 1.8, b: 2.5, note: 'Vsak šprint iz 35–40 km/h, kot zadnjih 200 m; med serijama 10 min Z2.', why: `Specifično za ${g.name}: zaključni šprint.`, min: 90 })
        : reps(p, { name: '40/20', title: '40/20 — 3 serije × 8', sets: 3, n: 8, on: 40, off: 20, setRest: 240, a: 1.15, b: 1.25, note: 'Kot kriterij: vsak izhod iz ovinka in napad; zadnja ponovitev vsake serije šprint.', why: `Specifično za ${g.name}: dirka je niz pospeškov.`, min: 90 })
    case 'kronometer': {
      const [reps, work] = bw === 1 ? [2, 20] : bw === 2 ? [3, 12] : [1, 30]
      return intervals(p, { name: 'Kronometer v aero', reps, work, rest: 6, a: 0.95, b: 1.02, z: 'Z4', note: 'V aero položaju (ali spodnjem držalu), kadenca 90+, enakomerno; ravno cesto brez semaforjev.', why: `Specifično za ${g.name}: prag v položaju, v katerem boš dirkal.`, min: 105 })
    }
    case 'cestna':
      return bw === 1 ? specific2(p, { ...g, type: 'klanci' }, 2) : bw === 2 ? specific2(p, { ...g, type: 'sprint' }, 1) : overUnder(p)
    default: {                                            // maraton
      const franja = /franj/i.test(g.name)
      const [reps, work, a, b] = bw === 1 ? [2, 15, 0.95, 1] : bw === 2 ? [2, 20, 0.92, 0.97] : [3, 12, 0.97, 1.02]
      return intervals(p, { name: franja ? 'Kladje' : 'Dolgi klanec', reps, work, rest: 6, a, b, z: 'Z4', note: franja ? 'Po možnosti na klancu 5–8 % (Kladje: 7 km, 6,3 %). Sede, kadenca 75–85.' : 'Na daljšem klancu 5–8 %, sede, kadenca 75–85, enakomerno.', why: franja ? 'Specifično za glavni vzpon Franje — enakomerno, ne po špicah skupine.' : `Specifično za ${g.name}: dolg klanec na utrujenih nogah.`, min: 105 })
    }
  }
}
/** Ključni trening 1 (torek): VO2max; v gradnji vsak 3. teden 30/15; pred šprintersko dirko anaerobno. */
function k1Of(p: Profile, ctx: WeekCtx, g: SeasonGoal | null): Sess {
  if (ctx.phase === 'specificno' && g?.type === 'sprint') return ctx.blockWeek === 2 ? thirty15(p) : reps(p, { name: 'Anaerobno', title: '8 × 30 s vse, kar gre', sets: 1, n: 8, on: 30, off: 270, setRest: 0, a: 1.5, b: 2.0, note: 'Vsaka ponovitev do konca; odmor 4 min 30 s zelo lahko.', why: `Pred ${g.name}: kapaciteta za ponavljajoče se napade.`, min: 90 })
  // prvi VO2max po lahkem začetku: blago (4 × 4), nato po bloku. (v3.48) Ne glede na fazo (brez cilja je osnova le 4 tedne);
  // začetnik (raven 1–2) blago ves prvi blok gradnje (do 12. tedna) — tudi namesto 30/15
  const novice = (p.level ?? 3) <= 2 && ctx.baseWeek != null && ctx.baseWeek <= 12 && ctx.phase !== 'specificno'
  // (v3.50) popoln začetnik (raven 1) v prvem ciklu brez VO2max: sweet spot 3 × 8 min namesto 4 × 4 min »RPE 9« vsak drugi
  // teden od 5. tedna kolesarjenja — več tveganja kot koristi
  if (novice && (p.level ?? 3) <= 1) {
    const why = 'Prvi cikel brez VO2max: tempo in sweet spot zgradita osnovo, intervali pridejo v naslednjem ciklu.'
    return ctx.phase === 'osnova'
      ? intervals(p, { name: 'Tempo', reps: 3, work: 10, rest: 5, a: 0.76, b: 0.85, z: 'Z3', note: 'Enakomerno, pogovor še mogoč v kratkih stavkih.', why, min: 70 })
      : intervals(p, { name: 'Sweet spot', reps: 3, work: 8, rest: 4, a: 0.88, b: 0.93, z: 'Z3', note: 'Enakomerno, kadenca 85–95 — malo težje kot tempo.', why, min: 70 })
  }
  // (v3.50) raven 1 po prvem ciklu (13.–20. teden): prvi VO2max blago 4 × 4 min, brez 30/15 — prej takoj 5 × 4 min
  const first1 = (p.level ?? 3) <= 1 && ctx.baseWeek != null && ctx.baseWeek > 12 && ctx.baseWeek <= 20 && ctx.phase !== 'specificno'
  // (v3.49) 30/15 tudi ne v prvih 6 tednih po začetku (prej je obšel pravilo »prvi VO2max blag«, ker je preverjen prej)
  if (ctx.phase === 'gradnja' && ctx.blockWeek === 3 && !novice && !first1 && !(ctx.baseWeek != null && ctx.baseWeek <= 6)) return thirty15(p)
  if (first1) return { ...vo2(p, 'osnova', 1), why: `Prvi VO2max blago — 4 × 4 min, nato po bloku. ${WHY_VO2}` }
  const v = novice || (ctx.baseWeek != null && ctx.baseWeek <= 6) ? vo2(p, 'osnova', 1) : vo2(p, ctx.phase, ctx.blockWeek, g)
  if (ctx.phase === 'specificno' && (g?.type === 'klanci' || g?.type === 'vzpon')) return { ...v, desc: `${v.desc} Po možnosti na klancu 4–8 %.` }
  return v
}
/** Dolga vožnja: v osnovi izmenično ravnina in hribi; pred ciljem po vrsti in dolžini dirke. */
function longOf(p: Profile, ctx: WeekCtx, g: SeasonGoal | null, min: number): Sess {
  const z2 = zoneText(p, 'Z2')
  if (ctx.phase === 'osnova' && ctx.blockWeek === 2) return { ...dolga(p, 'osnova', min, false), title: 'Dolga Z2 po hribih', desc: `Z2 ${z2} po razgibani trasi — klance sede in enakomerno (do spodnje Z3), navzdol vrti. ${fuelLong(min)}`, why: 'Klanci v osnovi: moč in tehnika za vzpone brez velike utrujenosti.' }
  if (ctx.phase !== 'specificno' || !g || min < 150) return dolga(p, ctx.phase, min, false, g)
  const franja = /franj/i.test(g.name)
  switch (g.type) {
    // (v3.49) klanci kot ponovitve (»3 × 15 min … vmes 25 min Z2«), da jih vodena vadba in ura pokažeta — prej 3 h enakomerne Z2
    case 'vzpon': return { title: 'Dolga + 3 dolgi klanci', desc: `Z2 ${z2}; na sredi 3 × 15 min pri ${wtxt(p, 0.85, 0.92, 'Z3').replace(/^utrip /, 'utripu ')} na daljših klancih, sede, vmes 25 min Z2. ${fuelLong(min)}`, min, zone: 'Z2', tss: tssOf(min - 50, 0.65) + tssOf(50, 0.88), target: watts(p, 0.85, 0.92), role: 'dolga', why: `Vzdržljivost na klancu za ${g.name}.` }
    case 'klanci': return { title: 'Dolga razgibana', desc: `Z2 ${z2} po razgibani trasi; vse klance v tempu ${wtxt(p, 0.85, 0.95, 'Z3')}, na vrhu 15 s pospešek čez rob. Gorivo kot na dirki: ${simFuel(min, 'Dolga razgibana')}.`, min, zone: 'Z2', tss: tssOf(min - 45, 0.66) + tssOf(45, 0.9), target: watts(p, 0.85, 0.95), role: 'dolga', why: `Razgibana dirka (${g.name}): klanec za klancem na utrujenih nogah.` }
    case 'sprint': return { title: 'Skupinska vožnja ali dirkalni trening', desc: `V skupini: zavetrina, pozicija, na tablah šprinti. Sam: Z2 ${z2} z 10 × 1 min pri ${wtxt(p, 1.15, 1.25, 'Z5')} (vmes 4 min) in 3 × 15 s šprint na koncu.`, min, zone: 'Z2', tss: tssOf(min - 20, 0.66) + tssOf(20, 1.0), target: null, role: 'dolga', why: `Šprinterska dirka (${g.name}): hitra vožnja v skupini in zaključek.` }
    case 'kronometer': return { title: 'Dolga + 3 × 15 min v aero', desc: `Z2 ${z2}; na ravnem 3 × 15 min v aero položaju pri ${wtxt(p, 0.88, 0.95, 'Z3')}. ${fuelLong(min)}`, min, zone: 'Z2', tss: tssOf(min - 45, 0.65) + tssOf(45, 0.9), target: watts(p, 0.88, 0.95), role: 'dolga', why: `Položaj in tempo za ${g.name}.` }
    default: return { title: franja ? 'Simulacija Franje' : 'Simulacija dirke', desc: `Z2 ${z2}; na daljših klancih 2 × 20 min pri ${wtxt(p, 0.85, 0.92, 'Z3')}. Gorivo kot na dirki: ${simFuel(min, 'Simulacija')} od 30. minute. Po možnosti v skupini.`, min, zone: 'Z2', tss: tssOf(min - 40, 0.66) + tssOf(40, 0.88), target: watts(p, 0.85, 0.92), role: 'dolga', why: `Vadiš tempo, gorivo in vožnjo v skupini za ${g.name}.` }
  }
}
/** Dolga vožnja pred dolgo dirko: vsaj ~80 % trajanja dirke (največ 6 h 30). */
const longFor = (g: SeasonGoal | null, phase: PhaseKey, p?: RiderLike) => (g && (phase === 'specificno' || phase === 'gradnja') ? Math.min(390, r5(raceMinutes(g, p) * (phase === 'specificno' ? 0.85 : 0.75))) : 0)
/**
 * (v3.50) Pri malo urah (≤ ~5,5 h) dolga vožnja pred dolgo dirko (≥ 150 min) vsak drugi teden bloka (2. teden) do 75 %
 * trajanja dirke, največ 4 h — teden sme biti zato daljši od cilja. Prej je bil strop 3 h in kolesarka s 6 h ter Franjo
 * (4 h 40) ni nikoli vozila dlje kot 2 h 45 (59 % dirke). Vrne minute dolge ali 0.
 */
function bigLongFor(g: SeasonGoal | null, ctx: WeekCtx, p?: RiderLike): number {
  // 1. in 3. teden bloka = vsakih 14 dni; v gradnji ~65 %, v specifičnem ~75 % dirke
  if (!g || ctx.recovery || ctx.easy || (ctx.blockWeek !== 1 && ctx.blockWeek !== 3) || (ctx.phase !== 'specificno' && ctx.phase !== 'gradnja')) return 0
  const race = raceMinutes(g, p)
  return race >= 150 ? Math.min(240, r5(race * (ctx.phase === 'specificno' ? 0.75 : 0.65))) : 0
}
// (v3.50) dejanski delež dirke (prej vedno »~75 % njenega trajanja« ob dolgi s 37–49 % dirke)
const WHY_BIG_LONG = (min: number, race: number) => `Dolga vožnja ${fmtDur(min)} (~${Math.round((100 * min) / race)} % dirke, ki traja ${fmtDur(race)}): pred dolgo dirko enkrat na 14 dni čim daljša — ta teden je zato daljši.`

/* ---------- lahek začetek sezone in off-season ---------- */
// (v3.51) brez »v 4. tednu« (4. teden je lahko razbremenilni s testom) in brez »za tekme«, ko cilja ni
const WHY_EASY_HEAD = 'Lahek začetek sezone: najprej baza in navada, intenzivnost pride po lahkem začetku'
const whyEasy = (race: boolean) => `${WHY_EASY_HEAD} — tako se ne izčrpaš${race ? ' in ostane svežina za tekme' : ''}.`
function easyKey(p: Profile, n: 1 | 2 | 3, day: 'tor' | 'cet', min: number, race = true): Sess {
  const z2 = zoneText(p, 'Z2')
  const WHY_EASY = whyEasy(race)
  if (day === 'tor') return withSprints({ title: 'Z2', desc: `Mirno ${z2}, kadenca 90+.`, min, zone: 'Z2', tss: tssOf(min, 0.64), target: null, role: 'lahka', why: WHY_EASY }, n === 3)
  if (n === 1) return { title: 'Z2 + 5 × 1 min visoka kadenca', desc: `Mirno ${z2}; na sredi 5 × 1 min pri 110+ obratih (lahko, brez sile), vmes 3 min normalno.`, min, zone: 'Z2', tss: tssOf(min, 0.64), target: null, role: 'lahka', why: WHY_EASY }
  if (n === 2) return { title: 'Z2 + klanci z nizko kadenco', desc: `${z2}; na klancu 4 × 5 min sede pri 60–70 obratih (Z2–spodnja Z3, sila v pedalih, ne v dihanju), vmes navzdol lahko.`, min, zone: 'Z2', tss: tssOf(min, 0.68), target: null, role: 'lahka', why: 'Moč za klance brez visokega utripa — pripravi noge na intervale.' }
  return intervals(p, { name: 'Tempo', reps: 3, work: 10, rest: 5, a: 0.76, b: 0.85, z: 'Z3', note: 'Prvi malo trši trening sezone: enakomerno, pogovor še mogoč v kratkih stavkih.', why: 'Most do sweet spota in VO2max v naslednjih tednih.', min })
}
/**
 * (v3.51) Treniran tekmovalec (raven 3+, 10+ h na teden, »raje trdo«): lahek začetek sezone ostane (štetje tednov), a
 * četrtek 2. tedna je sweet spot, 3. tedna prag — prej trije tedni brez praga (U23 15 h, »raje trdo«).
 */
export const strongStart = (p: Pick<Profile, 'level' | 'push' | 'hoursPerWeek'>): boolean => (p.level ?? 0) >= 3 && p.push === 'trdo' && (p.hoursPerWeek ?? 0) >= 10
function strongKey(p: Profile, n: 2 | 3, min: number): Sess {
  const why = 'Treniran si in imaš raje trdo — prag pride že v lahkem začetku, VO2max po njem.'
  return n === 2
    ? intervals(p, { name: 'Sweet spot', reps: 3, work: 12, rest: 5, a: 0.88, b: 0.93, z: 'Z3', note: 'Enakomerno, dihanje globoko, a pod kontrolo.', why, min })
    : intervals(p, { name: 'Prag', reps: 3, work: 10, rest: 5, a: 0.95, b: 1.0, z: 'Z4', note: 'Enakomerno — zadnji enako močan kot prvi.', why, min })
}
function hills(p: Profile, min: number, long = false): Sess {
  const hr = lthrZoneText(p, 'Z2')
  return { title: long ? 'Hribi — daljša tura' : 'Hribi', desc: `${Math.floor(min / 60)} h${min % 60 ? ` ${min % 60} min` : ''} hoje v hribe, gor v pogovornem tempu${hr ? ` (${hr})` : ''}, navzdol mirno. Brez ure in ciljev — samo uživaj.`, min, zone: 'Z2', tss: Math.round((min / 60) * 45), target: null, role: long ? 'dolga' : 'lahka', why: 'Off-season: gibanje brez pritiska, noge in glava se odpočijejo od kolesa.', kind: 'pohod' }
}
const feel = (p: Profile, min: number): Sess => ({ title: 'Po občutku', desc: `${min} min kolesa brez ure ali cilja — lahko, kjer ti je lepo (Z1–Z2${p.ftp ? `, pod ~${Math.round(p.ftp * 0.7)} W` : ''}). Lahko tudi tek, plavanje ali igra z žogo.`, min, zone: 'Z2', tss: tssOf(min, 0.58), target: null, role: 'lahka', why: 'Off-season: brez intervalov in brez pritiska — svežina za novo sezono.' })

/* ---------- samo trenažer ---------- */
/**
 * (v3.50) Kolo zunaj izklopljeno (samo trenažer): opisi treningov brez klancev, skupine, trase in hitrosti — upor in kadenca
 * na trenažerju namesto naklona. Tekme ostanejo, kot so (vozijo se zunaj).
 */
const INDOOR: [RegExp, string][] = [
  [/^Sweet spot na ravnini/, 'Sweet spot'], [/^Sweet spot na klancu/, 'Sweet spot z nizko kadenco'],
  [/^Prag na ravnini/, 'Prag'], [/^Prag na klancu/, 'Prag z nizko kadenco'],
  [/^Dolga Z2 po hribih/, 'Dolga Z2'], [/^Z2 — sam ali v skupini/, 'Z2 vzdržljivost'],
  [/^Skupinska vožnja ali Z2 \+ 6 × 30 s/, 'Z2 + 6 × 30 s napad'], [/^Skupinska vožnja ali dirkalni trening/, 'Z2 + 10 × 1 min in šprinti'],
  [/^Z2 \+ klanci z nizko kadenco/, 'Z2 + nizka kadenca z uporom'], [/^Dolga \+ 3 dolgi klanci/, 'Dolga + 3 × 15 min z uporom'],
  [/^Dolga razgibana/, 'Dolga Z2 s tempom'], [/^Dolga Z2 \+ tempo na klancih/, 'Dolga Z2 + tempo'], [/^Klanci z napadi/, 'Napadi z uporom'],
  [/^Klanci (\d)/, 'Ponovitve z uporom $1'], [/^Šprint iz zavetrja/, 'Šprinti'], [/^Kronometer v aero/, 'Prag v aero'], [/^Dolgi klanec/, 'Dolgi prag'],
  [/Na ravnini v spodnjem držalu, kadenca 85–95 — moč za ravnino in vodenje\./, 'Na trenažerju v ERG, v spodnjem držalu, kadenca 85–95.'],
  [/Na klancu 4–7 %, sede, kadenca 70–80 — moč za klance\./, 'Na trenažerju v ERG z višjim uporom, sede, kadenca 70–80 — moč v nogah.'],
  [/Na ravnini v spodnjem držalu, enakomerno — kot beg ali vodenje skupine\./, 'Na trenažerju v ERG, v spodnjem držalu, enakomerno.'],
  [/Na klancu 5–8 %, sede, kadenca 75–85, enakomerno\./, 'Na trenažerju z višjim uporom, sede, kadenca 75–85, enakomerno.'],
  [/Na čim daljšem klancu s podobnim naklonom kot na tekmi;/, 'Na trenažerju z uporom kot na tekmi;'],
  [/Na klancu 5–8 %, vsak vzpon enako močno, navzdol mirno\./, 'Z višjim uporom, vsak blok enako močno, vmes mirno.'],
  [/Vsak 4-min vzpon: prvih 20 s napad \(130 %\+\), nato na pragu do vrha\./, 'Vsak 4-min blok: prvih 20 s napad (130 %+), nato na pragu do konca.'],
  [/Vsaka ponovitev kot napad iz skupine;/, 'Vsaka ponovitev kot napad;'], [/Vsak šprint iz 35–40 km\/h, kot zadnjih 200 m;/, 'Vsak šprint iz visoke kadence (ERG izklopljen);'],
  [/; ravno cesto brez semaforjev\./, '.'], [/Po možnosti na klancu 5–8 % \(Kladje: 7 km, 6,3 %\)\./, 'Na trenažerju z višjim uporom (kot Kladje, 6–7 %).'],
  [/Na daljšem klancu 5–8 %,/, 'Na trenažerju z višjim uporom,'], [/ Po možnosti na klancu 4–8 %\./, ' Na trenažerju z višjim uporom.'],
  [/ Po možnosti v skupini\./, ''], [/, iz 25–30 km\/h, izmenično sede in stoje/, ' (ERG izklopljen), izmenično sede in stoje'],
  [/ po razgibani trasi — klance sede in enakomerno \(do spodnje Z3\), navzdol vrti\./, ', enakomerno; vsakih 20 min 1 min stoje.'],
  [/ po razgibani trasi; vse klance v tempu ([^,]+), na vrhu 15 s pospešek čez rob\./, '; 6 × 8 min v tempu $1, na koncu vsakega 15 s pospešek.'],
  [/, brez klancev na silo\./, ', enakomerno.'], [/na daljših klancih (\d)/, '$1'], [/ na daljših klancih, sede,/, ' z višjim uporom, sede,'],
  [/na klancu 4 × 5 min sede pri 60–70 obratih/, 'z višjim uporom 4 × 5 min sede pri 60–70 obratih'], [/, vmes navzdol lahko\./, ', vmes lahko.'],
  [/V skupini: zavetrina, pozicija, na tablah šprinti\. Sam: /, ''], [/V skupini vadi zavetrino in položaj v sredini — ista hitrost za 100 W manj\. Sam: /, ''],
  [/na ravnem (3 × 15 min v aero)/, '$1'], [/ na klancu\./, ' z višjim uporom.'], [/, na klancu — /, ' — '],
  [/kot pospeški (skupine na Kladju|v skupini)\./, 'kot pospeški na dirki.'],
  [/ in vožnjo v skupini za /, ' za '], [/Tempo na klancih sredi dolge vožnje/, 'Tempo sredi dolge vožnje'],
  [/; izmenično ravnina in klanec, da si dober povsod\./, '.'], [/; izmenično ravnina in klanec\./, '.'], [/Klanci v osnovi: moč in tehnika za vzpone brez velike utrujenosti\./, 'Dolga Z2 gradi motor: vzdržljivost in kurjenje maščob.'],
  [/na istem klancu ali odseku kot zadnjič/, 'pri istem uporu kot zadnjič'], [/čas na odseku/, 'povprečna kadenca pri istem uporu'],
]
function indoorize(s: Sess): Sess {
  if (s.kind || s.role === 'dirka') return s
  const fix = (t: string | null) => (t == null ? t : INDOOR.reduce((x, [re, to]) => x.replace(re, to), t))
  // (v3.51) dolga na trenažerju ~85 % (največ 2 h 30) — brez spustov in postankov je enako naporna (prej 2 h 55 kot zunaj)
  const min = s.role === 'dolga' ? Math.min(s.min, 150, Math.max(90, r5(s.min * 0.85))) : s.min
  const more = min < s.min ? ` Na trenažerju je ${fmtDur(min)} enakovredno ~${fmtDur(s.min)} zunaj (brez spustov in postankov).` : ''
  return { ...s, title: fix(s.title)!, desc: fix(s.desc)! + more, why: fix(s.why), ...(min < s.min ? { min, tss: Math.round((s.tss * min) / s.min) } : {}) }
}

/* ---------- vročina: pred poletnimi cilji ---------- */
/** Prilagoditev na vročino brez termometra: toplejša oblačila na lahkih vožnjah (10–14 dni pred poletnim ciljem). */
const HEAT = 'Prilagoditev na vročino (brez termometra): obleci se za ~10–15 °C topleje kot običajno (dolga majica + jopič ali pulover + dolge hlače). Vozi Z2 kot sicer; zadnjih 30–40 min naj ti bo vroče in se močno potiš, a še lahko govoriš. Utrip bo za isti tempo ~10 udarcev višji — tempa ne dvigaj. Pij po žeji z elektroliti; stehtaj se pred in po (izguba do ~2 % teže je v redu). Takoj nehaj in se ohladi ob glavobolu, vrtoglavici, slabosti, mrazenju, kurji koži ali zmedenosti. Če je zunaj nad 25 °C, vozi raje v najtoplejšem delu dneva v običajni opremi. Alternativa: 20–30 min savne ali tople kopeli takoj po lahki vožnji.'
function heat(s: Sess): Sess {
  return { ...s, title: `${s.title} · vročina`, desc: `${s.desc} ${HEAT}`, why: 'Poletna tekma: po 10–14 dneh vročinskih treningov se poveča volumen krvi in začneš prej potiti — v vročini zmoreš več. Kakovostni treningi ostanejo hladni.' }
}

/* ====================================================================
   TEDEN
   ==================================================================== */
export function buildWeek(inp: PlanInput): PlanDay[] {
  // načrt po meri (dogovor s trenerjem: fitnes, tek, kondicija) — svoj sestavljalnik; (v3.50) premor »Ta teden …« velja tudi tu
  if (isCustom(inp.profile)) return pauseBuilt(buildFocusWeek(inp), inp.profile, new Date().toISOString())
  const p0 = inp.profile
  const start = inp.weekStart || weekStartIso(todayIso())
  // po off-seasonu je FTP nekaj % nižji, dokler ga ne izmeriš — vati v načrtu iz tega
  const p: Profile = { ...p0, ftp: ftpForWeek(p0, start) }
  const ctx = weekContext(p0, start)
  // vrh forme (cilj sezone), h kateremu gre ta teden — vrsta dirke določa specifični blok; po zadnjem vrhu naslednji cilj A
  const goal = peakGoals(p0).find(g => weekStartIso(g.date) >= start) ?? seasonGoals(p0).find(g => weekStartIso(g.date) >= start) ?? null
  const rain = inp.rain || {}
  const now = new Date().toISOString()
  const days = Array.from({ length: 7 }, (_, i) => addDays(start, i))
  const notBefore = inp.notBefore || todayIso()
  const open = (i: number) => days[i]! >= notBefore

  // utrujenost: pri TSB pod −25 teden −15 % (ne v razbremenitvi, taperingu ali tednu dirke) — samo, ko je forma zanesljiva
  // (vsaj 42 dni zgodovine ali stanje iz intervals.icu); prej je TSB le ocena in nov uporabnik ni »utrujen«
  const series = formSeries(inp.activities)
  const tsb = series.length ? series[series.length - 1]!.tsb : 0
  // in telo: 3 ali več slabih juter v zadnjih 7 dneh (noge zelo bolijo, energija na tleh) — načrt posluša, ne le številke
  const rough = badMornings(inp.checkins, addDays(todayIso(), -6), todayIso())
  const tiredTsb = tsb < -25 && formReliable(inp.activities)
  const tired = !ctx.recovery && ctx.phase !== 'tapering' && ctx.phase !== 'dirka' && ctx.phase !== 'po' && (tiredTsb || rough >= 3)
  // ure iz resnice: po bolezni, premoru ali tednih z manj treninga načrt ne skoči na tabelo, ampak raste od dejanskih ur
  const ph = planHours(p0, inp.activities, start, inp.today)
  const total = Math.round(ph.hours * 60 * (tired ? 0.85 : 1))
  // proračun tedna (min na kolesu brez tekem): največ 1,1 × cilj tedna; razbremenilni ≤ 70 %, tapering ≤ 60 % zadnjega obremenilnega tedna
  const prevLoad = ctx.recovery || ctx.phase === 'tapering' ? prevLoadMin(p0, inp.activities, start, inp.today) : null
  const budget = Math.round(Math.min(total * 1.1, prevLoad != null ? prevLoad * (ctx.phase === 'tapering' ? 0.6 : 0.7) : Infinity))
  const W = Math.min(total, budget)                          // koliko sestaviti v razbremenilnem tednu in taperingu
  // (v3.50) samo trenažer (kolo zunaj izklopljeno): brez klancev, skupine, hribov in vremena v opisih
  const indoor = p0.gear?.bikeOutdoor === false
  // (v3.50) novinec po dogovoru, ki po 3+ tednih še ni začel (ni ene vadbe od začetka): teden kot prvi teden — Z2, šprinti in
  // kadenca, brez testa; prej »Teden 7 · najtežji v bloku« in VO2max za nekoga, ki ni naredil nič
  const idleBrk = !!ph.idle && !!p0.cycleStart && weeksBetween(p0.cycleStart, start) >= 3
  // moč samo v izbranih fazah (npr. fitnes v osnovi do januarja; potem jedro po želji)
  const strPhase = !p.strength.phases || !p.strength.phases.length || p.strength.phases.includes(ctx.phase)
  const strDays = p.strength.on && strPhase ? clamp(p.strengthDays ?? 2, 0, 2) : 0
  const gym = p.strength.equipment === 'gym'
  // (v3.49) po premoru (zadnje tri tedne skoraj nič, starejše vožnje so): ta in naslednji teden brez intervalov — Z2,
  // šprinti in kadenca kot v lahkem začetku (prej VO2max že v prvem tednu, »Trener pravi« pa »prva dva tedna brez«)
  const loadPhase = ctx.phase === 'osnova' || ctx.phase === 'gradnja' || ctx.phase === 'specificno'
  // (v3.50) tudi, ko teden po premoru pade na razbremenilni teden bloka (bloki se štejejo naprej): teden je »po premoru«
  const brk = !ctx.easy && loadPhase && (ph.base === 0 || idleBrk)
  // test FTP ne v tednih po premoru ali pred začetkom (najprej navada, cone potem)
  // (v3.51) test FTP je padel v teden premora (»Ta teden …«): prvi teden po premoru — prej šele čez 8 tednov, cone pa stare
  const pauseTest = !brk && !ctx.test && !ctx.easy && loadPhase && !!pauseBefore(p0, start) && ftpStale(p0, start)
    && [...pauseWeeks(p0)].some(ws => ws < start && weekContext(p0, ws).test && !(inp.done || []).some(d => d.kind === 'test' && d.date >= ws && d.date <= addDays(ws, 6)))
  const withTest = !brk && (ctx.test || pauseTest || (!!inp.firstWeek && !ctx.easy && ctx.phase !== 'prehod' && ftpStale(p0, start)))
  // stopnja po premoru: tekoči teden brez vožnje v prejšnjem tednu = 1 (visoka kadenca), naslednji teden (sestavljen
  // teden prej) ali teden po vožnji = 2 (klanci z nizko kadenco) — prej »prejšnji teden tudi brez voženj v 3 tednih«,
  // kar je pri premoru 4+ tednov dalo stopnjo 2 vsem tednom (stopnje 1 nikoli)
  const back = brk && !idleBrk && (start > weekStartIso(inp.today || todayIso()) || inp.activities.some(a => LOAD_SPORT(a) && a.date >= addDays(start, -7) && a.date < start))
  const easyN = (ctx.easy || (brk ? (back ? 2 : 1) : 0)) as 0 | 1 | 2 | 3

  // sestava: po dnevih (0 = pon … 6 = ned) seznam sej
  const slot: (Sess | null)[] = Array(7).fill(null)
  const moc: (StrengthKind | null)[] = Array(7).fill(null)
  let light = false
  let carbDay: number | null = null                       // dan počitka s polnjenjem OH pred dolgo dirko
  const carbFor = new Map<number, string>()                // (v3.50) pred katero tekmo je polnjenje OH (ime v opisu dneva)
  // (v3.49) moč: noge na trd dan (torek, po ključnem — »trd dan trd«), dan pred dolgo vožnjo nikoli noge; druga moč doma
  // v petek samo jedro, v fitnesu (enonožne) v četrtek; v specifičnem samo jedro v petek (prej noge v petek pred Simulacijo)
  const placeStrength = (n: number, spec: boolean) => {
    if (spec) { if (n >= 1) moc[4] = 'jedro'; return }
    if (n >= 1) moc[1] = 'noge'
    if (n >= 2) { if (gym) moc[3] = 'noge'; else moc[4] = 'jedro' }
  }

  if (ctx.phase === 'prehod') {
    // off-season brez intervalov in moči: počitek (vse po želji) → aktivni počitek → vrnitev (lahke vožnje).
    // Kaj (kolo, kolo in hribi, več hribov) izbere uporabnik — privzeto kolo po občutku, hribi samo, če jih izbere.
    const T4 = Math.max(120, total)
    const mix = offMixOf(p)
    const easySpin = (min: number, title: string, desc: string): Sess => ({ ...feel(p, min), title, desc, optional: true })
    if (ctx.offStage === 'pocitek') {
      if (mix === 'kolo') {
        slot[2] = easySpin(clamp(r5(T4 * 0.2), 30, 60), 'Lahko vrtenje po želji', 'Po želji 30–60 min zelo lahko (Z1), brez ure in ciljev. Ta teden je počitek — če se ti ne da, kolo počiva.')
        slot[5] = easySpin(clamp(r5(T4 * 0.4), 60, 120), 'Lahka vožnja po želji', 'Po želji lahka vožnja, kjer ti je lepo — v pogovornem tempu, z družbo. Nič ne štejemo.')
      } else {
        slot[2] = { ...hills(p, 90), title: 'Sprehod ali hribi', desc: 'Po želji: sprehod ali lahka tura v hribe, brez ure. Ta teden je počitek — kolo lahko počiva.', optional: true }
        slot[5] = { ...hills(p, clamp(r5(T4 * 0.5), 90, 180), true), desc: 'Po želji: tura v hribe z družbo, v pogovornem tempu. Nič ne štejemo.', optional: true }
      }
    } else if (ctx.offStage === 'vrnitev') {
      slot[1] = { ...z2Ride(p, clamp(r5(T4 * 0.2), 45, 90)), title: 'Lahka vožnja', why: 'Vrnitev na kolo: navada in lahko vrtenje, še brez struktur.' }
      slot[3] = { ...z2Ride(p, clamp(r5(T4 * 0.2), 45, 90)), title: 'Lahka vožnja', why: null }
      slot[5] = { ...z2Ride(p, clamp(r5(T4 * 0.35), 60, 150), true), title: 'Lahka daljša vožnja', why: null }
      slot[6] = mix === 'kolo' ? { ...feel(p, clamp(r5(T4 * 0.25), 60, 150)), title: 'Po občutku' } : hills(p, clamp(r5(T4 * 0.25), 60, 150))
    } else if (mix === 'kolo') {
      slot[1] = feel(p, clamp(r5(T4 * 0.18), 45, 90))
      slot[2] = feel(p, clamp(r5(T4 * 0.24), 60, 120))
      slot[4] = feel(p, clamp(r5(T4 * 0.18), 45, 90))
      slot[5] = { ...feel(p, clamp(r5(T4 * 0.34), 90, 210)), title: 'Daljša vožnja po občutku', role: 'dolga' }
    } else if (mix === 'hribi') {
      slot[1] = feel(p, clamp(r5(T4 * 0.18), 45, 90))
      slot[2] = hills(p, clamp(r5(T4 * 0.3), 90, 180))
      slot[4] = hills(p, clamp(r5(T4 * 0.2), 60, 150))
      slot[5] = hills(p, clamp(r5(T4 * 0.34), 120, 240), true)
    } else {
      slot[1] = feel(p, clamp(r5(T4 * 0.18), 45, 90))
      slot[2] = hills(p, clamp(r5(T4 * 0.3), 90, 180))
      slot[4] = feel(p, clamp(r5(T4 * 0.18), 45, 90))
      slot[5] = hills(p, clamp(r5(T4 * 0.34), 120, 240), true)
    }
  } else if (ctx.phase === 'po') {
    // po cilju: lahko in po občutku (pri velikem obsegu malo več, a brez intervalov)
    const d = clamp(r5(total * 0.22), 60, 120)
    slot[1] = z2Ride(p, d); slot[3] = z2Ride(p, d); slot[5] = z2Ride(p, clamp(r5(total * 0.36), 90, 180), true)
  } else if (ctx.phase === 'dirka' && goal) {
    // teden cilja sezone: dirka na njen dan v tednu (ne nujno nedelja)
    const ri = Math.max(0, days.indexOf(goal.date))
    const load = raceMinutes(goal, p0) >= CARB_LOAD_RACE_MIN
    const km = W >= 180 ? 60 : 0                             // pri malo urah ključni treningi brez dodatne Z2
    slot[ri] = goalSess(p, goal, p0)
    if (ri >= 1) slot[ri - 1] = openers(p, load)
    if (ri >= 3) slot[ri - 3] = { ...intervals(p, { name: 'Tempo dirke', reps: 3, work: 3, rest: 3, a: 0.95, b: 1.02, z: 'Z4', note: 'Občutek za tempo dirke.', min: Math.min(50, km) }), drop: 2 }
    if (ri >= 4) slot[ri - 4] = { ...z2Ride(p, 45), title: 'Lahka Z2' }
    // (v3.48) 5 dni pred dirko ni predaktivacija (ta je dan prej) — kratki pospeški za ostrino
    if (ri >= 5) slot[ri - 5] = { ...intervals(p, { name: 'Pospeški', reps: 4, work: 1, rest: 3, a: 1.15, b: 1.25, z: 'Z5', note: 'Samo odpre noge — ne utruja.', why: 'Teden dirke: kratko in ostro, da ostaneš oster.', min: km }), drop: 1 }
    if (ri + 1 <= 6) slot[ri + 1] = regen(p, 45, 'tekma')
    if (ri + 2 <= 6) slot[ri + 2] = z2Ride(p, 60)
    if (ri >= 2 && load) { carbDay = ri - 2; carbFor.set(ri - 2, goal.name) }
  } else if (ctx.phase === 'tapering') {
    // ključna dva ostaneta (pri malo urah brez dodatne Z2), ostalo iz proračuna: ≤ 60 % zadnjega obremenilnega tedna
    const km = W >= 300 ? 60 : 0
    slot[1] = intervals(p, { name: 'VO2max', reps: 3, work: 3, rest: 3, a: 1.1, b: 1.15, z: 'Z5', note: 'Samo ohranja ostrino.', why: 'Tapering: manj volumna, intenzivnost ostane.', min: km })
    slot[3] = { ...intervals(p, { name: 'Prag', reps: 2, work: 8, rest: 5, a: 0.95, b: 1.0, z: 'Z4', note: 'Kontroliran občutek za tempo.', why: 'Tapering: kratko na pragu.', min: km }), drop: 1 }
    const rest = W - slot[1].min - slot[3].min
    const sat = rest >= 60 ? clamp(r5(rest * 0.5), 60, 180) : 0
    if (sat) {
      const when = sat >= 90 ? 'v drugi uri' : 'na sredi'
      slot[5] = goal?.type === 'sprint'
        ? { ...dolga(p, 'osnova', sat, false, goal), title: 'Z2 + 3 × 1 min + 3 šprinti', desc: `Z2 ${zoneText(p, 'Z2')}; ${when} 3 × 1 min pri ${wtxt(p, 1.15, 1.25, 'Z5')} in 3 × 15 s šprint (vmes 5 min lahko). Gorivo ${simFuel(sat, 'šprinti')}.`, target: null }
        : { ...dolga(p, 'osnova', sat, false, goal), title: 'Z2 + 3 × 5 min tempo dirke', desc: `Z2 ${zoneText(p, 'Z2')}; ${when} 3 × 5 min pri ${wtxt(p, 0.88, 0.95, 'Z3')}${goal?.type === 'kronometer' ? ' v aero položaju' : goal?.type === 'vzpon' || goal?.type === 'klanci' ? ' na klancu' : ''}. Gorivo ${simFuel(sat, 'tempo dirke')} — preizkusi, kar boš jedel na dirki.`, target: watts(p, 0.88, 0.95) }
    }
    const r2 = rest - sat, wed = r2 >= 90 ? clamp(r5(r2 * 0.5), 45, 90) : 0, sun = r2 - wed >= 40 ? clamp(r5(r2 - wed), 40, 90) : 0
    if (wed) slot[2] = z2Ride(p, wed)
    if (sun) slot[6] = z2Ride(p, sun, true)
    if (strDays > 0) { moc[1] = 'jedro'; light = true }
  } else if (ctx.recovery && !brk) {
    // pri velikem obsegu (razbremenilni teden nad 8 h) so tudi lahki dnevi daljši — razbremenitev je ~50 %, ne 30 %;
    // pri malo urah krajši (najmanj 40 min), da je teden res lažji: ≤ 70 % zadnjega obremenilnega tedna
    // (v3.51) stropi sobote in nedelje sledijo proračunu W (prej prag 8 h: teden 6,5–8 h je bil sestavljen v 6 h, s testom 5 h
    // — U23 s 16 h je padel na 5 h, −65 %); ostanek gre na torek in četrtek (do 90 min)
    const hiR = total > 480, proR = total > 720, fri = proR ? 60 : 0
    let d1 = proR ? 120 : hiR ? 90 : clamp(r5(W * 0.22), 40, 60)
    const satMax = proR ? 270 : clamp(r5(W * 0.4), 150, 270), sunMax = proR ? (withTest ? 240 : 210) : clamp(r5(W * (withTest ? 0.35 : 0.25)), withTest ? 120 : 90, withTest ? 240 : 210)
    const rest = W - 2 * d1 - fri - (withTest ? 60 : 0)
    const sat = withTest ? 0 : clamp(r5(rest * 0.6), 60, satMax)
    const sun = Math.min(r5(rest - sat), sunMax)
    const left = rest - sat - sun
    if (!proR && left >= 10) d1 = Math.min(90, d1 + Math.floor(left / 10) * 5)
    slot[1] = { ...z2Ride(p, d1), title: 'Z2 + 4 × 30 s pospeški', desc: `Lahko ${zoneText(p, 'Z2')}; na sredi 4 × 30 s hitra kadenca (ne sila). Razbremenilni teden.` }
    slot[3] = z2Ride(p, d1)
    if (fri) slot[4] = regen(p, fri)
    if (withTest) { slot[5] = testSess(p); if (sun >= 40) slot[6] = z2Ride(p, sun, true) }
    else {
      slot[5] = sat >= 90 ? dolga(p, ctx.phase, sat, true) : { ...z2Ride(p, sat, true), title: 'Z2 — daljša vožnja' }
      if (sun >= 40) slot[6] = z2Ride(p, sun, true)
    }
    if (strDays > 0) { moc[4] = 'jedro'; light = true }
  } else if (easyN) {
    // lahek začetek sezone (3 tedne) ali po premoru: torek Z2 + šprinti, četrtek kadenca → nizka kadenca na klancu → tempo; brez VO2max in praga
    const n = easyN
    const tue = clamp(r5(total * 0.15), 45, 120), thu = clamp(r5(total * 0.16), 45, 120)
    slot[1] = easyKey(p, n, 'tor', tue, !!goal); slot[3] = withTest ? testSess(p) : ctx.easy && n >= 2 && strongStart(p) ? strongKey(p, n as 2 | 3, thu) : easyKey(p, n, 'cet', thu, !!goal)
    // (v3.50) po premoru (ne lahek začetek sezone) brez »intenzivnost pride v 4. tednu« — razlaga tedna že pove, da sta prva dva tedna brez intervalov
    if (brk) for (const i of [1, 3]) if (slot[i]?.why?.startsWith(WHY_EASY_HEAD)) slot[i] = { ...slot[i]!, why: null }
    const R = Math.max(90, total - slot[1].min - slot[3].min)
    const sat = clamp(r5(R * 0.45), 60, 300), wed = R >= 200 ? clamp(r5(R * 0.25), 45, 180) : 0, sun = clamp(r5(R - sat - wed), 45, 240)
    slot[5] = sat >= 90 ? (n === 2 ? longOf(p, { ...ctx, phase: 'osnova', blockWeek: 2 }, goal, sat) : dolga(p, 'osnova', sat, false, goal)) : { ...z2Ride(p, sat, true), title: 'Z2 — daljša vožnja' }
    if (wed) slot[2] = z2Ride(p, wed)
    slot[6] = z2Ride(p, sun, true)
    placeStrength(strDays, false)
    light = n === 1                                        // prvi teden tudi moč lažje
  } else if (total < 330) {
    // malo ur (začetek, načrt raste od tvojih dejanskih ur): EN ključni trening, ostalo Z2 — tako 80/20 drži tudi pri 4–5 h
    const key = withTest ? testSess(p) : ctx.blockWeek === 2 ? k2Of(p, ctx, goal) : k1Of(p, ctx, goal)
    slot[1] = key
    const R = Math.max(90, total - key.min)
    // (v3.50) pred dolgo dirko vsak drugi teden dolga do 75 % dirke (največ 4 h) tudi pri malo urah — teden sme biti daljši
    const big = bigLongFor(goal, ctx, p0)
    const sat0 = clamp(Math.max(r5(R * 0.55), Math.min(longFor(goal, ctx.phase, p0), r5(R - 45))), 60, 180)
    // teden največ 1,1 × cilj (isti proračun kot fitWeek): dolga vzame rezervo in skrajša četrtek na 45 min
    const sat = big ? Math.max(sat0, Math.min(big, Math.floor((total * 1.1 - key.min - 45) / 5) * 5)) : sat0
    const thu = clamp(r5(R - sat), 45, 90)
    slot[3] = withSprints(z2Ride(p, thu), goal?.type === 'sprint' && ctx.phase === 'specificno')
    slot[5] = sat >= 90 ? longOf(p, ctx, goal, sat) : { ...z2Ride(p, sat, true), title: 'Z2 — daljša vožnja' }
    if (sat > sat0 && slot[5].role === 'dolga') slot[5] = { ...slot[5], why: WHY_BIG_LONG(sat, raceMinutes(goal!, p0)) }
    // (v3.51) teden s testom: torek lahko, test v četrtek (kot pri več urah) — prej test v torek, dan po počitku
    if (withTest) { const t = slot[1]; slot[1] = slot[3]; slot[3] = t }
    placeStrength(strDays, ctx.phase === 'specificno')
  } else {
    // (v3.50) teden s testom FTP: torek lahka vožnja s šprinti, test v četrtek po dveh lahkih dneh — prej VO2max dan ali dva
    // pred testom (test podceni FTP, cone prenizke 8 tednov)
    const k1 = withTest ? withSprints(z2Ride(p, clamp(r5(total * 0.15), 45, 90))) : k1Of(p, ctx, goal)
    const k2 = withTest ? testSess(p) : k2Of(p, ctx, goal)
    let R = total - k1.min - k2.min
    slot[1] = k1; slot[3] = k2
    if (R < 240) {
      // malo ur: dolga + ena Z2, brez srede in regeneracije
      const big = bigLongFor(goal, ctx, p0)
      const sat0 = clamp(Math.max(r5(R * 0.6), Math.min(longFor(goal, ctx.phase, p0), r5(R - 45))), 60, 240)
      // (v3.50) dolga do 75 % dirke tudi pri malo urah, a teden največ 1,1 × cilj (nedelja odpade)
      const sat = big ? Math.max(sat0, Math.min(big, Math.floor((total * 1.1 - k1.min - k2.min) / 5) * 5)) : sat0, rest = r5(R - sat)
      slot[5] = longOf(p, ctx, goal, sat); if (rest >= 45) slot[6] = z2Ride(p, rest, true)
      if (sat > sat0 && slot[5].role === 'dolga') slot[5] = { ...slot[5], why: WHY_BIG_LONG(sat, raceMinutes(goal!, p0)) }
    } else {
      // profesionalni obseg (nad ~21 h): petek 2 h lahko, nad ~24 h še ponedeljek lahko vrtenje
      const pro = total > 1260
      const rg = pro ? 120 : R >= 330 ? 60 : R >= 270 ? 45 : 0
      R -= rg
      const mon = total > 1440 && open(0) ? 75 : 0
      if (mon) { slot[0] = { ...regen(p, mon), title: 'Lahko vrtenje', why: 'Pri velikem obsegu tudi ponedeljek ni prazen — samo kri po nogah.' }; R -= mon }
      // nad ~14,5 h na teden: višji stropi (sobota do 6 h, sreda in nedelja do 4 h; profi do 6,5 / 5,5 / 5,5 h), preostanek kot Z2 po ključnih treningih
      const hi = R > 630
      // pred dolgo dirko dolga vožnja vsaj ~80 % trajanja dirke (sreda in nedelja krajši)
      const satCap = pro ? 390 : hi ? 360 : 300
      const sat = clamp(Math.max(r5(R * 0.47), Math.min(longFor(goal, ctx.phase, p0), satCap, r5(R - 150))), 120, Math.max(satCap, Math.min(390, longFor(goal, ctx.phase, p0))))
      const wed = clamp(r5((R - sat) * 0.57), 60, pro ? 330 : hi ? 240 : 180)
      const sun = clamp(r5(R - sat - wed), 45, pro ? 330 : hi ? 240 : 150)
      // sreda: Z2 s šprinti vsak teden (pred šprintersko dirko daljši šprinti)
      slot[2] = withSprints(z2Ride(p, wed), goal?.type === 'sprint' && ctx.phase === 'specificno'); if (rg) slot[4] = regen(p, rg)
      slot[5] = longOf(p, ctx, goal, sat); slot[6] = z2Ride(p, sun, true)
      const left = hi ? r5(R - sat - wed - sun) : 0
      if (left >= 20) {
        const ext = pro ? 180 : 90
        const canK2 = slot[3]!.role !== 'test'
        const a1 = Math.min(ext, canK2 ? r5(left / 2) : left), a2 = canK2 ? Math.min(ext, r5(left - a1)) : 0
        slot[1] = longer(p, slot[1]!, a1); if (a2 >= 15) slot[3] = longer(p, slot[3]!, a2)
      }
    }
    if (ctx.phase === 'specificno' && slot[6] && goal?.type !== 'vzpon' && goal?.type !== 'kronometer') slot[6] = { ...slot[6], title: 'Skupinska vožnja ali Z2 + 6 × 30 s', desc: `V skupini vadi zavetrino in položaj v sredini — ista hitrost za 100 W manj. Sam: Z2 (${zoneText(p, 'Z2')}) s 6 × 30 s napadom${noPower(p) ? ' (vse, kar gre)' : p.ftp ? ` (${Math.round(p.ftp * 1.5)} W in več)` : ' (nad 150 % FTP)'}, vmes 4 min lahko.`, why: 'Na dirki se skupina lomi v 30-sekundnih pospeških — te moraš preživeti.' }
    placeStrength(strDays, ctx.phase === 'specificno')
    light = ctx.phase === 'specificno'
  }

  // vreme: dolga vožnja na bolj suh vikend dan (ne na trenažerju)
  const rs = rain[days[5]!] ?? 30, rn = rain[days[6]!] ?? 30
  if (!indoor && slot[5]?.role === 'dolga' && slot[6]?.role === 'lahka' && rs >= 50 && rn + 20 <= rs) { const t = slot[5]; slot[5] = slot[6]; slot[6] = t }

  // osnova: nedeljska Z2 je lahko tudi hribi
  if (!indoor && ctx.phase === 'osnova' && slot[6]?.role === 'lahka') slot[6] = { ...slot[6], desc: `${slot[6].desc} Namesto kolesa lahko greš v hribe (Spremeni → Hribi namesto kolesa).` }

  // poletni cilj (jun–avg): zadnja dva tedna pred njim do 3 lahke vožnje v toplejših oblačilih (prilagoditev na vročino)
  const summer = !!goal && [6, 7, 8].includes(+goal.date.slice(5, 7))
  if (summer && (ctx.phase === 'specificno' || ctx.phase === 'tapering') && ctx.weeksToEvent != null && ctx.weeksToEvent <= 2) {
    let n = 0
    for (const j of [2, 6, 1, 4]) { const x = slot[j]; if (n < 3 && x && x.role === 'lahka' && x.min <= 120 && !x.kind && /^(Z2|Lahka Z2)/.test(x.title) && !/šprint|pospešk|×/.test(x.title)) { slot[j] = heat(x); n++ } }
  }

  // dnevi brez časa iz dogovora (kolesar s tekmo): seja s takega dne gre na najbližji dan s časom, ki je prost; ključna,
  // dolga ali test zamenja lahko vožnjo, lahka izpade, če prostega dne ni; moč gre na dan s časom brez moči in brez dolge
  const offs = new Set(p0.focus?.offDays || [])
  if (offs.size) {
    const can = (j: number) => j >= 0 && j <= 6 && open(j) && !offs.has(j)
    for (let d = 0; d < 7; d++) {
      if (!offs.has(d)) continue
      const x = slot[d]
      if (x && x.role !== 'dirka') {
        const near = [1, -1, 2, -2, 3, -3, 4, -4, 5, -5, 6, -6].map(k => d + k).filter(can)
        const free = near.find(j => !slot[j])
        if (free != null) slot[free] = x
        else if (x.role === 'kljucna' || x.role === 'dolga' || x.role === 'test') { const j = near.find(k => slot[k]?.role === 'lahka' || slot[k]?.role === 'regen'); if (j != null) slot[j] = x }
        slot[d] = null
      }
      if (moc[d]) { const j = [1, 3, 4, 2, 0, 6, 5].find(k => can(k) && !moc[k] && slot[k]?.role !== 'dolga'); if (j != null) moc[j] = moc[d] ?? null; moc[d] = null }
    }
  }

  // druge tekme (B/C in cilji A, ki niso vrh tega tedna): dan prej predaktivacija, dan po lahko, pri pomembni (B) dva dni prej
  // brez trdega in teden −20 %, tekma za trening (C) nadomesti ključni trening. Dneva tekme (tudi cilja sezone) in polnjenja z OH
  // pred njim nič ne prepiše; dve tekmi na isti dan ostaneta vidni v enem dnevu (načrt velja za pomembnejšo).
  const races = racesAround(p0, days, ctx.phase === 'dirka' ? goal?.id ?? null : null)
  const testAt = slot.findIndex(x => x?.role === 'test'), test0 = testAt >= 0 ? slot[testAt]! : null
  const carbDays = new Set<number>(carbDay != null ? [carbDay] : [])
  const locked = (j: number) => j < 0 || j > 6 || slot[j]?.role === 'dirka' || carbDays.has(j)
  const raceIdAt = new Map<number, string>()
  const sameDay = new Map<number, Race[]>()
  for (const { i, race } of races) sameDay.set(i, [...(sameDay.get(i) || []), race])
  for (const [i, list] of [...sameDay.entries()].sort((a, b) => a[0] - b[0])) {
    const race = [...list].sort((a, b) => (a.prio === b.prio ? sideRaceMinutes(b, p0) - sideRaceMinutes(a, p0) : a.prio === 'B' ? -1 : b.prio === 'B' ? 1 : 0))[0]!
    const load = sideRaceMinutes(race, p0) >= CARB_LOAD_RACE_MIN
    if (i === 7) { if (!locked(6)) { slot[6] = openers(p, load); moc[6] = null } continue }          // tekma v ponedeljek naslednjega tedna
    if (slot[i]?.role === 'dirka') {
      // isti dan kot cilj sezone: cilj ostane, druga tekma je zapisana zraven
      slot[i] = { ...slot[i]!, why: `${slot[i]!.why ? slot[i]!.why + ' ' : ''}Isti dan tudi ${list.map(r => r.name).join(', ')} — cilj sezone ima prednost.` }
      continue
    }
    const s = raceSess(p, race, p0)
    const lost = slot[i]
    slot[i] = list.length > 1
      ? { ...s, title: `${[race, ...list.filter(r => r !== race)].map(r => r.name).join(' + ')}${race.distanceKm ? ` — ${race.distanceKm} km` : ''}`, why: `Na isti dan ${list.length === 2 ? 'sta dve tekmi' : `je ${list.length} tekem`} — izberi eno; načrt velja za ${race.name}. ${s.why ?? ''}`.trim() }
      : s
    raceIdAt.set(i, race.id); moc[i] = null
    // (v3.50) tekma za trening (C): dan prej krajša Z2 (do 90 min) namesto predaktivacije, dolga vožnja ostane (prej je
    // sobotna dolga postala 40-min predaktivacija in teden padel za tretjino)
    // Dolga tekma C (150+ min) je sama dolga vožnja: dan prej Z2 do 60 min s polnjenjem OH.
    if (!locked(i - 1)) {
      const before = slot[i - 1]
      slot[i - 1] = race.prio === 'B' ? openers(p, load)
        : load ? { ...z2Ride(p, Math.min(60, Math.max(45, before?.min ?? 60))), desc: `${z2Ride(p, 60).desc} Danes in včeraj 8–10 g OH na kg (riž, testenine, kruh), malo vlaknin.`, fixed: true }
        : before?.role === 'dolga' ? before : z2Ride(p, Math.min(90, Math.max(45, before?.min ?? 60)))
      moc[i - 1] = null
    }
    if (i - 2 >= 0) moc[i - 2] = null                                          // moč (težke noge) ne tik pred tekmo
    // (v3.51) pred pomembno tekmo (B) tudi 3 dni prej ne noge (mišična bolečina je največja 48–72 h po vadbi) — samo jedro
    if (race.prio === 'B' && i - 3 >= 0 && moc[i - 3] && moc[i - 3] !== 'jedro') moc[i - 3] = 'jedro'
    // (v3.50) tekma C na dan dolge vožnje: dan po njej Z2 do 2 h (»tekma + Z2«), da teden ne izgubi dolge
    if (!locked(i + 1)) { slot[i + 1] = race.prio === 'B' ? regen(p, 45, 'tekma') : lost?.role === 'dolga' && !load ? { ...z2Ride(p, clamp(r5(lost.min * 0.6), 60, 120), true), why: 'Dolga vožnja je bila ta teden tekma — danes še Z2 za vzdržljivost.' } : z2Ride(p, 60); moc[i + 1] = null }
    if (race.prio === 'B') {
      if (!locked(i - 2) && slot[i - 2] && hard(slot[i - 2]!)) slot[i - 2] = z2Ride(p, Math.min(60, slot[i - 2]!.min))
      for (let j = 0; j < 7; j++) { const x = slot[j]; if (x && !locked(j) && !x.fixed && Math.abs(j - i) > 2 && (x.role === 'lahka' || x.role === 'dolga')) slot[j] = { ...x, min: Math.min(x.min, Math.max(45, r5(x.min * 0.8))), tss: Math.round(x.tss * 0.8) } }
    } else {
      const keys = slot.map((x, j) => (x?.role === 'kljucna' && j !== i ? j : -1)).filter(j => j >= 0)
      if (keys.length >= 2) { const k = keys.sort((a, b) => Math.abs(a - i) - Math.abs(b - i))[0]!; slot[k] = z2Ride(p, Math.min(75, slot[k]!.min)) }
    }
    if (load && !locked(i - 2)) { carbDays.add(i - 2); carbFor.set(i - 2, race.name) }   // dolga tekma: 2 dni prej polnjenje z OH
  }
  // (v3.50) trd dan ob testu: test ne stoji ob ključnem treningu, dolgi ali tekmi (prej VO2max dan pred testom)
  const hardNear = (j: number) => [j - 1, j + 1].some(k => k >= 0 && k <= 6 && !!slot[k] && hard(slot[k]!))
  if (test0 && races.length && !slot.some(x => x?.role === 'test')) {
    // test je padel na tekmo ali tik ob njo — na dan vsaj 2 dni od tekme (prost, sicer namesto ključnega ali lahkega); sicer naslednjič
    const ok = (j: number) => open(j) && !locked(j) && races.every(r => (j > r.i ? j - r.i >= 2 : r.i - j >= (r.race.prio === 'B' ? 3 : 2)))
    const to = [1, 2, 3, 4, 5, 6].find(j => ok(j) && !slot[j] && !hardNear(j)) ?? [1, 2, 3, 4, 5, 6].find(j => ok(j) && slot[j]?.role === 'kljucna') ?? [1, 2, 3, 4, 5, 6].find(j => ok(j) && (slot[j]?.role === 'lahka' || slot[j]?.role === 'regen') && !hardNear(j))
    if (to != null) slot[to] = test0
  }

  // začetek sredi tedna: test ne sme pasti mimo — premakni ga na prvi prost dan (čet, pet, ned)
  if (withTest && slot.some(s => s?.role === 'test')) {
    const ti = slot.findIndex(s => s?.role === 'test')
    if (!open(ti)) {
      const to = [3, 4, 6, 2].find(i => open(i) && !locked(i) && slot[i]?.role !== 'dolga' && !hardNear(i)) ?? [3, 4, 6, 2].find(i => open(i) && !locked(i) && slot[i]?.role !== 'dolga')
      if (to != null) { slot[to] = slot[ti]!; slot[ti] = null }
    }
  }

  // (v3.50) moč za noge ne na dan testa FTP in ne dan pred njim: na naslednji prost dan brez dolge/testa, sicer odpade
  // (jedro na dan testa ostane — ni nog)
  {
    const ti = slot.findIndex(s => s?.role === 'test')
    if (ti >= 0) for (const d of [ti, ti - 1]) {
      if (d < 0 || !moc[d] || (d === ti - 1 && moc[d] === 'jedro')) continue
      if (d === ti && moc[d] === 'jedro') continue
      const to = [d + 1, d + 2, d - 1, d - 2].find(j => j >= 0 && j <= 6 && j !== ti && j !== ti - 1 && open(j) && !moc[j] && slot[j]?.role !== 'dolga' && slot[j]?.role !== 'dirka' && slot[j + 1]?.role !== 'dolga' && !locked(j))
      if (to != null) moc[to] = moc[d]
      moc[d] = null
    }
  }

  // (v3.50) teden, sestavljen ob koncu tedna (nedelja ali sobota): če sta odprta največ dva dneva in sta prazna, gre nanj
  // najdaljša lahka ali dolga vožnja zaprtega dne — prej je kolesar, ki je odprl aplikacijo v nedeljo, dobil teden brez enega
  // treninga, zgoraj pa »5 h«
  const openIdx = [0, 1, 2, 3, 4, 5, 6].filter(open)
  if (openIdx.length > 0 && openIdx.length <= 2 && openIdx.every(i => !slot[i]) && !races.length && ctx.phase !== 'prehod') {
    const from = [0, 1, 2, 3, 4, 5, 6].filter(i => !open(i) && slot[i] && !slot[i]!.optional && !slot[i]!.kind && (slot[i]!.role === 'dolga' || slot[i]!.role === 'lahka')).sort((a, b) => slot[b]!.min - slot[a]!.min)[0]
    if (from != null) {
      const to = openIdx[openIdx.length - 1]!
      slot[to] = { ...slot[from]!, why: `${DAY_NOM[new Date(days[to]! + 'T12:00:00Z').getUTCDay()]}: ${slot[from]!.title} ${fmtDur(slot[from]!.min)} — teden se začne v ponedeljek.` }
      slot[from] = null
    }
  }

  // teden v proračun (najmanjše dolžine sej pri malo urah ne smejo narediti tedna daljšega od cilja)
  fitWeek(p, slot, budget, open)
  // (v3.48) »daljša vožnja« samo, če je res najdaljša vožnja tedna (pri malo urah je ključni trening lahko daljši)
  const longest = Math.max(0, ...slot.map((x, i) => (x && open(i) && !x.optional && !x.kind && x.role !== 'dirka' ? x.min : 0)))
  slot.forEach((x, i) => { if (x?.title === 'Z2 — daljša vožnja' && x.min < longest) slot[i] = { ...x, title: 'Z2 vožnja' } })
  if (indoor) slot.forEach((x, i) => { if (x) slot[i] = indoorize(x) })
  // (v3.50) gorivo v opisu po končnem trajanju (krajšanje v proračun, tekma B −20 %) — isto kot Gorivo (rideFuel)
  slot.forEach((x, i) => { if (x && !x.kind) slot[i] = fuelFix(x) })

  const CARB_TXT = 'Danes in jutri 8–10 g ogljikovih hidratov na kg (riž, testenine, kruh, sok), malo vlaknin in maščob.'
  const out: PlanDay[] = []
  const base = (date: string) => ({ id: uid(), date, source: 'rules' as const, createdAt: now, updatedAt: now, done: null })
  days.forEach((date, i) => {
    const s = slot[i], mk = moc[i]
    if (!open(i)) {
      out.push({ ...base(date), kind: 'pocitek', title: 'Pred začetkom', desc: 'Ta dan je bil pred začetkom načrta.', durationMin: 0, zone: null, tssTarget: 0, why: null })
      return
    }
    const carb = carbDays.has(i)
    // (v3.50) »Polnjenje OH pred VN Vodice: danes in jutri …« — prej brez imena tekme (dan po drugi tekmi ni bil jasen)
    const carbTxt = carbFor.get(i) ? `Polnjenje OH pred tekmo ${carbFor.get(i)}: danes in jutri 8–10 g ogljikovih hidratov na kg (riž, testenine, kruh, sok), malo vlaknin in maščob.` : CARB_TXT
    if (!s && !mk) {
      out.push({ ...base(date), kind: 'pocitek', title: carb ? 'Počitek + polnjenje OH' : 'Počitek', desc: carb ? `${carbTxt} Noge gor.` : i === 0 ? 'Popoln počitek. Po želji 10 min raztezanja ali jedra.' : 'Prosto — spanec in hrana sta del treninga.', durationMin: 0, zone: null, tssTarget: 0, why: i === 0 ? 'Prilagoditev se zgodi med počitkom, ne med treningom.' : null })
      return
    }
    if (s) {
      const kind: PlanKind = s.kind ?? (s.role === 'test' ? 'test' : 'kolo')
      const rid = s.role === 'dirka' ? raceIdAt.get(i) ?? null : null
      out.push({ ...base(date), kind, title: s.title, desc: carb && !s.optional ? `${s.desc} ${carbTxt}` : s.desc, durationMin: s.min, zone: s.zone, tssTarget: s.tss, why: s.why, role: s.role, target: s.target, ...(rid ? { raceId: rid } : {}), ...(s.optional ? { optional: true } : {}) })
    }
    if (mk) {
      // fitnes: težke noge v torek (trd dan ostane trd), četrtek enonožne + hrbet in jedro; 1 × na teden = težke noge.
      // (v3.49) Jedro ostane jedro (tapering, razbremenilni teden, specifično) — prej ga je fitnes zamenjal s težkimi nogami
      const kindG: StrengthKind = mk === 'jedro' ? 'jedro' : gym ? (i === 1 || strDays === 1 ? 'fitnesA' : 'fitnesB') : mk
      const gk = kindG === 'fitnesA' || kindG === 'fitnesB'
      const st = strengthSession(kindG, p, inp.activities, light)
      out.push({ ...base(date), kind: 'moc', title: st.title, desc: st.desc, durationMin: st.min, zone: null, tssTarget: Math.round((st.min * STRENGTH_TSS_H) / 60), exercises: st.exercises, role: 'moc', why: gk ? 'Težka moč izven sezone = boljša ekonomičnost in več moči na klancu (2 × na teden do konca osnove, nato vzdrževanje ali samo jedro).' : kindG === 'jedro' ? 'Močan trup, stabilna drža na kolesu.' : 'Noge za klance, zaščita pred poškodbami.' })
    }
  })

  // razlaga tedna — na prvi aktivni dan
  const f = out.find(d => d.kind !== 'pocitek' && d.kind !== 'moc')
  if (f) {
    const h = ph.hours.toString().replace('.', ',')
    // (v3.51) ure v razlagi = ure sestavljenega tedna na kolesu (brez tekme), ne formula (prej »Teden dirke · 4,5 h« ob 3 h 15)
    const bikeMin = weekBikeMinutes(out.filter(d => d.role !== 'dirka' && !d.raceId))
    const hasRace = out.some(d => d.role === 'dirka' || !!d.raceId)
    const hb = hasRace ? `treningi ${fmtDur(bikeMin)} + ${ctx.phase === 'dirka' ? 'dirka' : 'tekma'}` : bikeMin ? fmtDur(bikeMin) : 'brez vožnje'
    const dec = (x: number | null) => (x ?? 0).toString().replace('.', ',')
    const capNote = !ph.capped ? ''
      : ctx.phase === 'tapering' || ctx.phase === 'dirka' ? ` ${ctx.phase === 'tapering' ? 'Tapering je ~60 %' : 'Teden dirke je ~40 %'} tvojega zadnjega polnega tedna (${dec(ph.base)} h).`
      // (v3.50) po premoru »Ta teden …«: brez skoka na poln obseg
      : ph.pause ? (ph.pause === 'dolg' && p0.weekPause ? ` ${pauseAfter(p0.weekPause)} lažji teden (~80 % tedna pred premorom), nato po načrtu.` : ' Po premoru teden kot pred premorom — brez skoka na poln obseg.')
      // (v3.50) po krajšem premoru polovica prejšnjega obsega — s številko, ne vedno »4 h«
      : ph.base === 0 ? (ph.hours > 4 && ph.gap ? ` Po ${ph.gap} ${ph.gap === 1 ? 'tednu' : 'tednih'} premora začneš pri ~${h} h (polovica tega, kar si vozil prej) in raseš po ~10 % na teden.` : ' Po premoru začneš pri 4 h in raseš po ~10 % na teden.')
      // (v3.49) novinec brez ene zapisane vožnje od začetka: načrt ne raste
      : ph.idle ? ' Od začetka načrta še ni zapisane vožnje — načrt ostane na ravni 1. tedna, dokler ne začneš.'
      // (v3.48) brez še ene »ciljne« številke (prej »Manj od cilja (9,5 h)« ob 4,5 / 7 / 11 h na istem zaslonu)
      : ` Zadnje tedne si treniral ~${dec(ph.base)} h — načrt raste od tega, ~10 % na teden.`
    const brkNote = !brk ? '' : idleBrk ? ' Ker še nisi začel: lahek teden brez intervalov in testa — Z2, šprinti in kadenca, kot na začetku.' : ' Prva dva tedna po premoru brez intervalov — Z2, šprinti in kadenca, nato VO2max.'
    // (v3.49) začetek ob koncu tedna: dnevi do ponedeljka so uvodni, teden 1 se začne v ponedeljek
    const intro = !!p0.cycleStart && start < p0.cycleStart ? 'Uvodni dnevi — teden 1 se začne v ponedeljek. ' : ''
    const head = ctx.phase === 'prehod'
      ? `Off-season (teden ${ctx.week}/${Math.round(p0.offSeasonWeeks ?? 1)}${ctx.offStage === 'pocitek' ? ', počitek' : ctx.offStage === 'vrnitev' ? ', vrnitev' : ', aktivni počitek'}) · ~${h} h: ${ctx.offStage === 'pocitek' ? (offMixOf(p0) === 'kolo' ? 'kolo počiva ali lahko vrtenje po želji — nič ne štejemo.' : 'kolo počiva, vse je po želji — sprehod, hribi, družba.') : ctx.offStage === 'vrnitev' ? 'lahke vožnje brez struktur, navada nazaj.' : `${OFF_MIX[offMixOf(p0)].active} — brez intervalov in brez ure.`} Nato lahki tedni osnove in počasna gradnja.`
      : ctx.easy
      // (v3.51) brez »VO2max in prag pridejo v 4. tednu« — 4. teden je lahko razbremenilni s testom, začetnik VO2max dobi pozneje
      ? `Lahek začetek sezone (teden ${ctx.easy}/3) · ${hb}: Z2, šprinti in ${ctx.easy === 1 ? 'visoka kadenca' : ctx.easy === 2 ? 'klanci z nizko kadenco' : 'prvi tempo'} — intervali pridejo po lahkem začetku.`
      : ctx.weeksToEvent != null && ctx.weeksToEvent > 0
      ? `${ctx.phaseName}${ctx.recovery ? ' · razbremenilni teden' : ctx.phase === 'tapering' ? '' : ` · ${ctx.blockWeek}. teden bloka`} · ${hb}. ${ctx.event!.name} čez ${ctx.weeksToEvent} ${ctx.weeksToEvent === 1 ? 'teden' : ctx.weeksToEvent === 2 ? 'tedna' : ctx.weeksToEvent < 5 ? 'tedne' : 'tednov'}${goal && ctx.phase === 'specificno' ? ` (${RACE_TYPES[goal.type].l.toLowerCase()}: ${RACE_TYPES[goal.type].d})` : ''}.`
      // (v3.50) brez cilja enako kot s ciljem: razbremenilni teden, teden bloka in test FTP (prej samo »Osnova · 2 h.«)
      : `${ctx.phaseName}${ctx.recovery && ctx.phase !== 'po' ? ' · razbremenilni teden' : ctx.structured && loadPhase ? ` · ${ctx.blockWeek}. teden bloka` : ''}${withTest && slot.some(x => x?.role === 'test') ? ' · test FTP' : ''} · ${hb}.`
    const ftpNote = p.ftp && p0.ftp && p.ftp < p0.ftp && ctx.phase !== 'prehod' ? `Vati so iz FTP po off-seasonu ~${p.ftp} W (${Math.round((p.ftp / p0.ftp - 1) * 100)} %), dokler ga ne izmeriš s testom.` : ''
    const heatNote = out.some(d => /· vročina$/.test(d.title)) ? `Poletni cilj ${goal!.name}: lahke vožnje s » · vročina« so v toplejših oblačilih (navodila pri dnevu).` : ''

    const rl = races.filter(r => r.i < 7).map(r => `Tekma v ${dayAcc(r.race.date)}: ${r.race.name} (${r.race.prio === 'B' ? 'pomembna — dan prej samo predaktivacija, teden −20 %' : 'za trening — šteje kot ključni trening, dolga vožnja ostane'}).`).join(' ')
    const testNote = pauseTest && out.some(d => d.kind === 'test') ? 'Test FTP je bil v tednu premora — naredi ga ta teden, da so cone prave.' : ''
    f.why = [intro + head + capNote + brkNote, ftpNote, testNote, heatNote, rl, tired ? (tiredTsb ? `Ta teden −15 %: forma je ${Math.round(tsb)} (utrujenost visoka).` : `Ta teden −15 %: zadnji teden si bil ${rough}× utrujen ali z bolečimi nogami.`) : '', f.why || ''].filter(Boolean).join(' ')
  }
  // »Bolan sem«: dnevi v obdobju bolezni so počitek (sestavljeno se shrani za vrnitev)
  // slovnica: »pri utripu 154–160« (predloge pišejo »pri ${cona}«, cona brez merilnika je »utrip …«)
  for (const d of out) if (d.desc) d.desc = d.desc.replace(/\bpri utrip (?=\d|pod|nad)/g, 'pri utripu ')
  // (v3.50) zdravstvena omejitev iz dogovora (tlak, srce …): brez »vse, kar gre«; »Ta teden …«: dnevi premora brez treningov oz. brez kolesa
  return pauseBuilt(sickifyBuilt(healthSafe(out, p0), p0, now), p0, now)
}

/** Skupno načrtovano trajanje tedna (min) — brez neobveznih dni. */
export function weekMinutes(days: readonly PlanDay[]): number { return days.filter(d => !d.optional).reduce((s, d) => s + (d.durationMin || 0), 0) }
/** Ure na kolesu (brez moči) — primerjava s ciljem tedna. */
export function weekBikeMinutes(days: readonly PlanDay[]): number { return days.filter(d => !d.optional && (d.kind === 'kolo' || d.kind === 'test')).reduce((s, d) => s + (d.durationMin || 0), 0) }

/**
 * Napovedana forma na zadnji dan tedna, če opraviš vse načrtovano — vključno z današnjo sejo, ki še ni opravljena
 * (danes = izmerjeno do zdaj + načrtovano, kar še pride).
 */
export function forecastForm(activities: readonly Activity[], week: readonly PlanDay[], today: string = todayIso()): { ctl: number; atl: number; tsb: number; date: string; race?: boolean } | null {
  if (!week.length) return null
  const s = formSeries(activities, today)
  // izhodišče: stanje ob koncu včeraj; današnja izmerjena obremenitev se prišteje spodaj skupaj z načrtom
  let prev: (typeof s)[number] | undefined
  for (let i = s.length - 1; i >= 0; i--) if (s[i]!.date < today) { prev = s[i]; break }
  const cur = s.find(x => x.date === today)
  let ctl = prev ? prev.ctl : cur ? cur.ctl : 0, atl = prev ? prev.atl : cur ? cur.atl : 0
  const measuredToday = prev ? cur?.tss ?? 0 : 0
  const byDate = new Map<string, number>()
  for (const d of week) if (d.date >= today && !d.done) byDate.set(d.date, (byDate.get(d.date) || 0) + (d.tssTarget || 0))
  const last = [...week].sort((a, b) => a.date.localeCompare(b.date))[week.length - 1]!.date
  if (last < today) { const x = cur ?? prev; return { ctl: Math.round(x?.ctl ?? 0), atl: Math.round(x?.atl ?? 0), tsb: Math.round((x?.ctl ?? 0) - (x?.atl ?? 0)), date: last } }
  // (v3.50) teden s tekmo: forma zjutraj na dan tekme (»na startu«), brez obremenitve tekme same in dni po njej — prej
  // »forma v nedeljo ≈ −41« v tednu Franje, ker je štela tudi dirko (na startu −11)
  const race = week.filter(d => (d.role === 'dirka' || !!d.raceId) && d.date >= today && !d.done).sort((a, b) => a.date.localeCompare(b.date))[0]
  const end = race ? addDays(race.date, -1) : last
  for (let d = today; d <= end; d = addDays(d, 1)) {
    const tss = (byDate.get(d) || 0) + (d === today ? measuredToday : 0)
    ctl += (tss - ctl) / 42; atl += (tss - atl) / 7
  }
  return { ctl: Math.round(ctl), atl: Math.round(atl), tsb: Math.round(ctl - atl), date: race ? race.date : last, ...(race ? { race: true } : {}) }
}

/** Profil brez številk — za cone korakov, kadar profila ni (cona koraka je iz opisa, ne iz vatov). */
const ZONE_STUB = { ftp: null, maxHr: null, restHr: null, lthr: null, gear: { powerMeter: null }, strength: { on: false } } as unknown as Profile
/**
 * Minute po conah za načrtovan teden. (v3.50) Iz korakov vodene vadbe (kot »Kaj te čaka«): »Dolga Z2 + tempo« ima 30 min
 * Z3, 30/15 20 min trdo (prej ocena: tempo v dolgi 0 min, 30/15 36 min). Tekma: 45 % v coni, 40 % Z2, 15 % Z1 kot prej.
 */
export function zoneMinutes(week: readonly PlanDay[], p: Profile = ZONE_STUB): Record<'Z1' | 'Z2' | 'Z3' | 'Z4' | 'Z5', number> {
  const m = { Z1: 0, Z2: 0, Z3: 0, Z4: 0, Z5: 0 }
  for (const d of week) {
    if (d.kind === 'moc' || d.kind === 'pocitek' || d.optional) continue
    const t = d.durationMin || 0
    if (d.role !== 'dirka' && d.zone !== 'dirka') {
      let steps: ReturnType<typeof stepsFor> = []
      try { steps = stepsFor(d, p) } catch { steps = [] }
      const sec = steps.reduce((a, s) => a + s.sec, 0)
      if (steps.length && sec > 0) {
        // koraki na načrtovano trajanje (vsota korakov je trajanje dneva; varovalka za zaokrožitve)
        const k = (t * 60) / sec
        for (const s of steps) { const z = s.kind === 'test' ? 'Z4' : s.z === 'max' ? 'Z5' : s.z ?? 'Z2'; m[z] += (s.sec / 60) * k }
        continue
      }
    }
    const raw = d.zone === 'test' ? 'Z4' : d.zone === 'dirka' ? 'Z3' : d.zone || 'Z2'
    const z = raw as keyof typeof m
    if (!(z in m)) continue
    if (d.role === 'kljucna' || d.role === 'test') {
      const w = Math.min(t, Math.round(t * 0.4))
      m[z] += w; m.Z2 += Math.round((t - w) * 0.7); m.Z1 += t - w - Math.round((t - w) * 0.7)
    } else if (z === 'Z1' || z === 'Z2') m[z] += t
    else { m[z] += Math.round(t * .45); m.Z2 += Math.round(t * .4); m.Z1 += Math.round(t * .15) }
  }
  return { Z1: Math.round(m.Z1), Z2: Math.round(m.Z2), Z3: Math.round(m.Z3), Z4: Math.round(m.Z4), Z5: Math.round(m.Z5) }
}

/** Ali se da dan olajšati: vožnja ali test, ne po želji, ne opravljen; nikoli tekma in dan pred njo (v3.48). */
export function canEaseDay(d: Pick<PlanDay, 'date' | 'kind' | 'optional' | 'done' | 'role' | 'raceId'>, lock?: RaceLock): boolean {
  if ((d.kind !== 'kolo' && d.kind !== 'test') || d.optional || d.done) return false
  // tekma bi izginila (prej »Kolo · po želji — Lahek dan«), dan pred njo je predaktivacija
  const w = lock?.why(d.date)
  return d.role !== 'dirka' && !d.raceId && w !== 'dan tekme' && w !== 'dan pred tekmo'
}
/**
 * »Olajšaj dan« brez AI: današnjo sejo prestavi na naslednji prost dan v tednu, danes pa ostane lahka Z1.
 * Nikoli na dan pred tekmo ali na dan polnjenja z OH; trd trening (ključni, test, dolga) nikoli ob drug trd dan ali tekmo
 * (sicer trije trdi dnevi zapored). Če takega dne ni, seja ta teden odpade — razlog je v `why` lahkega dne.
 * Vrne dneve za shranitev (po id-ju) ali null, če ni česa olajšati.
 */
export function easeDay(week: readonly PlanDay[], today: string, lock: RaceLock = raceLock(week)): PlanDay[] | null {
  const cur = week.find(d => d.date === today && (d.kind === 'kolo' || d.kind === 'test') && !d.optional && !d.done)
  if (!cur || !canEaseDay(cur, lock)) return null
  const busy = new Set(week.filter(d => d.kind !== 'pocitek' && d.kind !== 'moc' && !d.optional).map(d => d.date))
  const hardCur = isHardDay(cur)
  const hardAt = new Set(week.filter(d => d.id !== cur.id && !d.optional && isHardDay(d)).map(d => d.date))
  const ok = (d: PlanDay) => d.date > today && !d.done && d.kind === 'pocitek' && !d.sickPrev && !busy.has(d.date) && !/polnjenje/i.test(d.title)
    && !lock.has(d.date)
    && (!hardCur || (!hardAt.has(addDays(d.date, -1)) && !hardAt.has(addDays(d.date, 1)) && !lock.afterRace(d.date)))
  const later = [...week].filter(ok).sort((a, b) => a.date.localeCompare(b.date))[0]
  const now = new Date().toISOString()
  const out: PlanDay[] = []
  if (later) out.push({ ...cur, id: later.id, date: later.date, why: `Prestavljeno ${dayFrom(today)}, ko si dan olajšal.`, source: 'rules', updatedAt: now })
  const why = later ? `Seja je prestavljena na ${dayAcc(later.date)}.`
    : hardCur ? 'Ta seja ta teden odpade — ni prostega dne brez trdega treninga ali tekme ob njem; bolje en trening manj kot bolezen.'
    : 'Ta seja ta teden odpade — bolje en trening manj kot bolezen.'
  out.push({ ...cur, kind: 'kolo', title: 'Lahek dan — Z1', desc: 'Lažji dan po tvoji izbiri: 30–45 min zelo lahko ali sprehod. Veliko vode, zgodaj spat.', durationMin: 40, zone: 'Z1', tssTarget: 20, target: null, role: 'regen', exercises: undefined, tail: null, optional: true, why, source: 'rules', updatedAt: now })
  return out
}

/* ====================================================================
   PO PRETEŽKI VOŽNJI: DAN ZA TEM LAŽJE
   Namesto 45 min regeneracije so bile 3 ure → naslednji dan ne more biti po načrtu. Ključni trening gre na
   naslednji primeren lahki dan (nikoli ob drug trd dan ali tekmo), sicer ta teden odpade; lahka vožnja postane
   regeneracija. Tekma, počitek in že lahek dan ostanejo. Vse se da vrniti (adapt.prev).
   ==================================================================== */
const contentOf = (d: PlanDay): PlanContent => ({ kind: d.kind, title: d.title, desc: d.desc, durationMin: d.durationMin, zone: d.zone ?? null, tssTarget: d.tssTarget ?? null, role: d.role ?? null, target: d.target ?? null, kcalBurn: d.kcalBurn ?? null, why: d.why ?? null, optional: !!d.optional, ...(d.exercises ? { exercises: d.exercises } : {}), tail: d.tail ?? null })
/** Načrtovana obremenitev dneva (TSS); počitek in moč 0. */
export const planLoad = (d: Pick<PlanDay, 'kind' | 'tssTarget' | 'durationMin' | 'zone'>): number =>
  d.kind === 'pocitek' || d.kind === 'moc' ? 0 : d.tssTarget ?? tssOf(d.durationMin || 0, d.zone === 'Z1' ? 0.5 : /Z[345]|test/.test(d.zone || '') ? 0.8 : 0.65)
const LOAD_SPORTS = new Set(['kolo', 'tek', 'pohod'])

export interface LoadAdapt {
  /** dan pretežke vožnje */ date: string
  /** dejanska in načrtovana obremenitev tega dne (TSS) */ actual: number; planned: number
  /** dan za tem (glavna seja pred prilagoditvijo); null = počitek */ next: PlanDay | null
  /** dnevi za shranitev (predlog); prazno pri info, prilagojeno in vrnjeno */ days: PlanDay[]
  /** kaj bo dan za tem — kratko, za kartico in obvestilo */ text: string
  state: 'predlog' | 'prilagojeno' | 'vrnjeno' | 'info'
}

/**
 * Ali je bila vožnja dneva `date` precej težja od načrta (≥ 60 TSS, ≥ 50 nad načrtom in ≥ 1,5 × načrt) in kaj to pomeni
 * za naslednji dan. null = ni bila pretežka ali je dan za tem že mimo.
 */
export function adaptAfterLoad(p: Profile, plan: readonly PlanDay[], acts: readonly Activity[], date: string, today: string): LoadAdapt | null {
  const mine = acts.filter(a => a.date === date && LOAD_SPORTS.has(a.sport))
  const actual = Math.round(mine.reduce((t, a) => t + (a.tss && a.tss > 0 ? a.tss : estimateTss(a, p)), 0))
  const planned = Math.round(plan.filter(d => d.date === date).reduce((t, d) => t + planLoad(d), 0))
  if (actual < 60 || actual - planned < 50 || actual < planned * 1.5) return null
  const tmr = addDays(date, 1)
  if (tmr < today) return null
  const Tw = tmr === today ? 'Danes' : 'Jutri'
  const day = plan.filter(d => d.date === tmr)
  const next = day.filter(d => !d.optional && (d.kind === 'kolo' || d.kind === 'test' || d.kind === 'tek' || d.kind === 'pohod')).sort((a, b) => planLoad(b) - planLoad(a))[0] ?? null
  const base = { date, actual, planned, next }
  // že prilagojeno (ali vrnjeno) po tem dnevu — tudi na drugi napravi
  const marked = plan.filter(d => d.adapt?.after === date)
  if (marked.length) {
    if (marked.every(d => d.adapt!.off)) return { ...base, days: [], state: 'vrnjeno', text: `${Tw} ostaja po prvotnem načrtu.` }
    const t = marked.find(d => d.date === tmr && !d.adapt!.off), mv = marked.find(d => d.date !== tmr && !d.adapt!.off)
    const what = t ? `${t.title.toLowerCase()} ${fmtDur(t.durationMin)}` : 'lažje', orig = t?.adapt?.prev?.title
    return { ...base, days: [], state: 'prilagojeno', text: `${Tw} ${what}${mv ? `, ${mv.title} je v ${dayAcc(mv.date)}` : orig ? ` namesto: ${orig}` : ''}.` }
  }
  if (next?.done) return null
  if (!next) {
    const moc = day.some(d => d.kind === 'moc' && !d.optional && !d.done)
    return { ...base, days: [], state: 'info', text: moc ? `${Tw} samo moč — če so noge težke, naredi manj serij.` : `${Tw} je počitek — ravno prav po taki vožnji.` }
  }
  if (next.role === 'dirka' || next.raceId) return { ...base, days: [], state: 'info', text: `${Tw} je tekma — načrta ne spreminjam. Zvečer več ogljikovih hidratov in zgodaj spat.` }
  if (next.kind !== 'kolo' && next.kind !== 'test') return { ...base, days: [], state: 'info', text: `${Tw}: ${next.title} — naredi krajše in lažje.` }
  if (next.role === 'regen' && next.durationMin <= 60) return { ...base, days: [], state: 'info', text: `${Tw} je že regeneracija — ravno prav.` }

  const now = new Date().toISOString()
  const rg = regen(p, clamp(r5(Math.min(45, next.durationMin || 45)), 30, 45))
  const why = `Po težki vožnji v ${dayAcc(date)} (${actual} TSS namesto ~${planned}) je ta dan lahek — telo se mora obnoviti, sicer trpijo naslednji treningi.`
  const easy = (d: PlanDay): PlanDay => ({ ...d, kind: 'kolo', title: rg.title, desc: rg.desc, durationMin: rg.min, zone: rg.zone, tssTarget: rg.tss, role: 'regen', target: null, kcalBurn: null, exercises: undefined, tail: null, optional: false, swap: null, why, source: 'rules', updatedAt: now, adapt: { after: date, prev: contentOf(d) } })
  const lower = `${rg.title.toLowerCase()} ${fmtDur(rg.min)}`

  if (isHardDay(next)) {
    const rideMin = mine.filter(a => a.sport === 'kolo').reduce((t, a) => t + (a.durationMin || 0), 0)
    if (next.role === 'dolga' && rideMin >= next.durationMin * 0.7)
      return { ...base, days: [easy(next)], state: 'predlog', text: `${Tw} ${lower} namesto dolge vožnje — dolgo si že odpeljal.` }
    const end = addDays(weekStartIso(tmr), 6)
    const hardAt = new Set(plan.filter(d => d.id !== next.id && !d.optional && isHardDay(d)).map(d => d.date))
    const lock = pauseLock(raceLock(plan, p), p)
    const cand = plan.filter(d => d.date > tmr && d.date <= end && !d.done && !d.optional && !d.sickPrev && d.kind === 'kolo' && (d.role === 'lahka' || d.role === 'regen')
      && !hardAt.has(d.date) && !hardAt.has(addDays(d.date, -1)) && !hardAt.has(addDays(d.date, 1)) && !lock.has(d.date) && !lock.afterRace(d.date))
      .sort((a, b) => a.date.localeCompare(b.date))[0]
    if (cand) {
      const moved: PlanDay = { ...cand, ...contentOf(next), why: `Prestavljeno ${dayFrom(tmr)}: dan po težki vožnji je lahek.`, source: 'rules', updatedAt: now, adapt: { after: date, prev: contentOf(cand) } }
      return { ...base, days: [easy(next), moved], state: 'predlog', text: `${Tw} ${lower}, ${next.title} gre na ${dayAcc(cand.date)}.` }
    }
    return { ...base, days: [easy(next)], state: 'predlog', text: `${Tw} ${lower} namesto: ${next.title} — ta teden ga ni kam prestaviti brez dveh trdih dni zapored.` }
  }
  return { ...base, days: [easy(next)], state: 'predlog', text: `${Tw} ${lower} namesto: ${next.title}, ${fmtDur(next.durationMin)}.` }
}

/** »Vrni prvotni načrt«: dnevom, prilagojenim po pretežki vožnji dneva `date`, vrne prvotno vsebino (oznaka ostane: ne prilagodi znova). */
export function undoLoadAdapt(plan: readonly PlanDay[], date: string): PlanDay[] {
  const now = new Date().toISOString()
  return plan.filter(d => d.adapt?.after === date && !d.adapt.off && d.adapt.prev && !d.done)
    .map(d => ({ ...d, ...d.adapt!.prev!, updatedAt: now, adapt: { after: date, off: true } }))
}

/* ====================================================================
   DRUGE TEKME, HRIBI NAMESTO KOLESA, JEDRO PO ŽELJI
   ==================================================================== */
/** Tekme v tem tednu (i = 0 … 6) in v ponedeljek naslednjega (i = 7, zaradi dneva prej). Glavni cilj ima svoj teden dirke. */
/** Tekme ta teden (in v ponedeljek naslednjega): B, C in cilji A, ki niso glavni dogodek tega tedna (ti štejejo kot B). */
function racesAround(p: Profile, days: readonly string[], goalId: string | null = null): { i: number; race: Race }[] {
  const next = addDays(days[6]!, 1)
  return (p.races || []).filter(r => r && r.date && r.date !== p.event?.date && r.id !== goalId && (days.includes(r.date) || r.date === next))
    .map(r => ({ i: r.date === next ? 7 : days.indexOf(r.date), race: r.prio === 'A' ? { ...r, prio: 'B' as const } : r })).sort((a, b) => a.i - b.i)
}
const hard = (x: Sess) => x.role === 'kljucna' || x.role === 'test' || (x.role === 'dolga' && x.min >= 150)
/** Dan pred tekmo; pred dolgo tekmo (≥ 150 min) še polnjenje z OH. Ne krajša se in ne odpade. */
function openers(p: Profile, load = false): Sess {
  const s = intervals(p, { name: 'Predaktivacija', reps: 3, work: 1, rest: 2, a: 1.1, b: 1.2, z: 'Z5', note: 'Dan pred tekmo: samo odpre noge, ne utruja. Zvečer več ogljikovih hidratov, zgodaj spat.', why: 'Jutri tekma — svež, a ne zaspan.', min: 40 })
  return { ...s, desc: `${s.desc}${load ? ' Danes in včeraj 8–10 g OH na kg (riž, testenine, kruh), malo vlaknin.' : ''}`, role: 'lahka', fixed: true }
}
/**
 * (v3.48) Zajtrk pred tekmo — isto pravilo kot Gorivo (fueling v energy.ts): od 150 min 2–3 g OH na kg 3 h prej
 * (druga tekma 2–3 h), od 90 min ~2 g, krajša 1–2 g. Prej je opis vedno pisal ~2 g, Gorivo pa 1–2 ali 2–3 g.
 */
export function raceBreakfast(min: number, other: boolean): string {
  const [lo, hi] = raceBreakfastGkg(min)
  return `Zajtrk ${min >= CARB_LOAD_RACE_MIN && !other ? '3' : '2–3'} h pred startom (${lo === hi ? `~${lo}` : `${lo}–${hi}`} g OH na kg)`
}
/** g OH na kg za zajtrk pred tekmo [od, do] — isto pravilo za opis tekme in Gorivo (v3.48). */
export function raceBreakfastGkg(min: number): [number, number] {
  return min >= CARB_LOAD_RACE_MIN ? [2, 3] : min >= FUEL_RACE_MIN ? [2, 2] : [1, 2]
}
/** OH na uro na tekmi po trajanju: 60+ g samo od 90 min naprej, krajša največ 30–60 g; null = pod 1 h, dovolj izotonik. */
function raceFuel(min: number, hi: string): string | null {
  // (v3.50) od 90 min iz iste tabele kot Gorivo (~70 / ~85 g), ne svoj razpon (»70–90«, »60–80«) — hi ostane za klice
  void hi
  return min >= FUEL_RACE_MIN ? `~${fuelGph({ kind: 'kolo', durationMin: min, role: 'dirka' })}` : min >= 60 ? '30–60' : null
}

/** Zadnji obremenilni teden pred tem (ne razbremenilni, off-season, po cilju, tapering, dirka); null brez njega. */
function prevLoadWeek(p: Profile, weekStart: string): string | null {
  // (v3.50) teden premora (»Ta teden …«) ni obremenilni teden — šteje teden pred njim
  const skip = pauseWeeks(p)
  for (let k = 1; k <= 4 + skip.size; k++) {
    const ws = addDays(weekStart, -7 * k)
    if (skip.has(ws)) continue
    if (!p.cycleStart || ws < p.cycleStart) return null
    const c = weekContext(p, ws)
    if (!c.recovery && c.phase !== 'prehod' && c.phase !== 'po' && c.phase !== 'tapering' && c.phase !== 'dirka') return ws
  }
  return null
}
/** Minute zadnjega obremenilnega tedna — kot je bil res sestavljen (planHours, v3.48), ne zgornja meja faze. */
function prevLoadMin(p: Profile, acts: readonly Activity[], weekStart: string, today?: string): number | null {
  const ws = prevLoadWeek(p, weekStart)
  return ws ? Math.round(planHours(p, acts, ws, today).hours * 60) : null
}

/** Krajša seja: nova dolžina, sorazmeren TSS; »dolga« pod 90 min postane navadna Z2, gorivo za ≥ 90 min odpade. */
function resize(p: Profile, s: Sess, min: number): Sess {
  if (s.role === 'dolga' && min < 90) return { ...z2Ride(p, min, true), title: 'Z2 — daljša vožnja' }
  const desc = (min < 90 ? s.desc.replace(/ Od 30\. minute ~\d+ g OH na uro\./, '') : s.desc).replace(/^\d+ min kolesa/, `${min} min kolesa`).replace(/(Gorivo: od 30\. minute )~\d+ g/, `$1~${fuelGph({ kind: 'kolo', durationMin: min, role: 'dolga', title: s.title })} g`)
  return { ...s, min, tss: s.min > 0 ? Math.round((s.tss * min) / s.min) : s.tss, desc }
}

/**
 * Teden v proračun (min na kolesu brez tekem in neobveznih dni): najprej se sorazmerno skrajšajo lahke, dolge in
 * regeneracijske vožnje (nobena pod 30 min), nato odpadejo najkrajše (regeneracija prva), nazadnje ključni treningi,
 * ki jih teden dovoli izpustiti (tapering, teden dirke). Tekme, test, ključni treningi in predaktivacija ostanejo.
 */
function fitWeek(p: Profile, slot: (Sess | null)[], budget: number, open: (i: number) => boolean): void {
  const DAYS = [0, 1, 2, 3, 4, 5, 6]
  const counts = (i: number) => { const x = slot[i]; return !!x && open(i) && !x.optional && (!x.kind || x.kind === 'test') && x.role !== 'dirka' }
  const sum = () => DAYS.reduce((t, i) => t + (counts(i) ? slot[i]!.min : 0), 0)
  // najmanj 30 min; seja s ponovitvami (šprinti, kadenca, klanci) ne krajša od svoje strukture z ogrevanjem in izvozom
  const floor = (s: Sess) => Math.max(30, minMinutes({ title: s.title, desc: s.desc, role: s.role }))
  for (let guard = 0; guard < 20; guard++) {
    const over = sum() - budget
    if (over <= 0) return
    const flex = DAYS.filter(i => counts(i) && !slot[i]!.fixed && (slot[i]!.role === 'lahka' || slot[i]!.role === 'dolga' || slot[i]!.role === 'regen'))
    const room = flex.reduce((t, i) => t + Math.max(0, slot[i]!.min - floor(slot[i]!)), 0)
    if (flex.length && room >= over) {
      for (const i of flex) {
        const r = slot[i]!.min - floor(slot[i]!)
        if (r <= 0) continue
        const cut = Math.min(r, Math.ceil((over * r) / room / 5) * 5)
        if (cut > 0) slot[i] = resize(p, slot[i]!, slot[i]!.min - cut)
      }
      continue
    }
    const rank = (i: number) => (slot[i]!.role === 'regen' ? 0 : slot[i]!.role === 'lahka' ? 1 : 2)
    const drop = [...flex].sort((a, b) => rank(a) - rank(b) || slot[a]!.min - slot[b]!.min || b - a)[0]
      ?? DAYS.filter(i => counts(i) && slot[i]!.drop != null).sort((a, b) => slot[a]!.drop! - slot[b]!.drop!)[0]
    if (drop == null) return
    slot[drop] = null
  }
}
/**
 * (v3.49) Tempo kronometra (prej samo »enakomerno, zadnjih 5 min vse« — brez številk): krajši od 40 min malo nad pragom,
 * daljši na pragu; prvih 5 min ne prehitro, na koncu vse. Z merilnikom vati, brez njega utrip iz pražnega utripa (LTHR),
 * brez obojega občutek (RPE). `main` = cilj glavnega dela (za vodeno vadbo).
 */
function ttPace(p: Profile, min: number): { text: string; main: { lo: number; hi: number } | null } {
  const short = min < 40, end = short ? 'zadnje 3 min vse' : 'zadnjih 5 min vse'
  const a = watts(p, short ? 0.95 : 0.9, short ? 1.0 : 0.95), b = watts(p, short ? 1.0 : 0.95, short ? 1.05 : 1.0)
  if (!noPower(p) && a && b) return { text: `Prvih 5 min ${a.lo}–${a.hi} W (ne prehitro), nato ${b.lo}–${b.hi} W, ${end}.`, main: b }
  const L = lthrOf(p)
  const text = L
    ? short ? `Prvih 5 min pri utripu ${L - 6}–${L} (ne prehitro), nato pri utripu ${L}–${L + 4}, ${end}.`
      : `Prvih 5 min tik pod pragom (utrip do ${Math.round(L * 0.93)}), nato na pragu (${lthrZoneText(p, 'Z4')}), ${end}.`
    : short ? `Prvih 5 min malo pod tem, kar zmoreš (RPE 7–8), nato RPE 9, ${end}.` : `Prvih 5 min tik pod pragom (RPE 7), nato na pragu (RPE 8), ${end}.`
  return { text, main: b }
}
function raceSess(p: Profile, r: Race, rider: RiderLike = p): Sess {
  const km = r.distanceKm || null
  const t = raceTypeOf(r)
  const min = sideRaceMinutes(r, rider)
  // (v3.49) tempo tudi na drugih tekmah: vati z merilnikom, sicer utrip na pragu (prej brez številk)
  const thr = watts(p, 0.95, 1.0), w = noPower(p) ? null : thr, hr = noPower(p) ? lthrZoneText(p, 'Z4') : null
  const tt = ttPace(p, min)
  const tip: Record<RaceType, string> = {
    sprint: ' V zavetrini in blizu čela; zadnji kilometer v prvih 10, šprint 200–250 m pred ciljem.',
    vzpon: ` Ogrevanje 25 min; prvih 5 min ne prehitro (${w ? `~${w.lo}–${w.hi} W` : hr ?? 'tik pod pragom'}), sredina enakomerno, zadnja tretjina vse.`,
    kronometer: ` Ogrevanje 25 min s 3 × 2 min na pragu. ${tt.text}`,
    klanci: p.ftp && !noPower(p) ? ` Na klancih enakomerno, ne čez ~${Math.round(p.ftp * 1.05)} W dlje kot 5 min; napade spremljaj le, če jih zmoreš.` : ` Na klancih enakomerno${hr ? ` na pragu (${hr})` : ''}, napade spremljaj le, če jih zmoreš.`,
    maraton: ` V zavetrini varčuj, dolge klance enakomerno${w ? ` do ~${w.hi} W` : hr ? ` na pragu (${hr})` : ''}.`,
    cestna: p.ftp && !noPower(p) ? ` Na klancih ne čez ~${Math.round(p.ftp * 1.05)} W dlje kot 5 min, v zavetrini varčuj.` : ` Na klancih enakomerno${hr ? ` na pragu (${hr})` : ''}, v zavetrini varčuj.`,
  }
  const fuel = raceFuel(min, r.prio === 'B' ? '70–90' : '60–80')
  // cilj za vodeno vadbo: kronometer glavni del tempa, vzpon in klanci prag (prej null — »Tekma (enakomerno)«)
  const target = t === 'kronometer' ? tt.main : t === 'vzpon' || t === 'klanci' ? thr : null
  return {
    title: `${r.name}${km ? ` — ${km} km` : ''}`, min, zone: 'dirka', tss: tssOf(min, t === 'vzpon' || t === 'kronometer' ? 0.95 : r.prio === 'B' ? 0.82 : 0.78), target, role: 'dirka',
    // vzpon in kronometer imata svoje ogrevanje (25 min) — ne še splošnega (prej dve različni ogrevanji v istem opisu)
    desc: `${raceBreakfast(min, true)}${t === 'vzpon' || t === 'kronometer' ? '.' : ', ogrevanje 15–20 min s 3 kratkimi pospeški.'}${tip[t]}${fuel ? ` Na kolesu ${fuel === '30–60' ? 'največ 30–60' : fuel} g OH na uro od 30. minute.` : ''}`,
    why: r.prio === 'B' ? 'Pomembna tekma: dva dni prej brez trdega, dan prej samo predaktivacija, dan po lahko.' : 'Tekma za trening: šteje kot ključni trening — dolga vožnja ostane, dan prej krajša Z2.',
  }
}
/** Cilj sezone na dan dirke: navodila po vrsti dirke. */
function goalSess(p: Profile, g: SeasonGoal, rider: RiderLike = p): Sess {
  const min = raceMinutes(g, rider), km = g.distanceKm
  const franja = /franj/i.test(g.name)
  const thr = watts(p, 0.95, 1.0)
  // (v3.49) brez merilnika moči navodila v utripu, ne v vatih (prej »Kladje pri 228–240 W«, ki jih ne vidi); cilj (target) ostane
  const hr = noPower(p) ? lthrZoneText(p, 'Z4') : null
  const w = noPower(p) ? null : thr, onThr = hr ? `na pragu (${hr})` : 'na pragu'
  // gorivo po trajanju: 60+ g OH na uro samo od 90 min naprej (kratka dirka: največ 30–60 g, pod 1 h dovolj izotonik)
  const fuel = (hi: string) => { const f = raceFuel(min, hi); return f === '30–60' ? 'največ 30–60 g OH na uro' : f ? `${f} g OH na uro` : 'dovolj je izotonik' }
  const d: Record<RaceType, string> = {
    maraton: franja && min >= CARB_LOAD_RACE_MIN
      ? `${raceBreakfast(min, false)}. Na kolesu ${raceFuel(min, '')} g OH na uro od 30. minute (seznam in urnik v Gorivu), pijača z elektroliti. Ravnina v zavetrini, Vrhniški klanec mirno, Kladje (7 km, 6,3 %) enakomerno ${w ? `pri ${w.lo}–${w.hi} W` : hr ? `pri ${hr.replace(/^utrip\b/, 'utripu')}` : 'na pragu'} — ne po špicah skupine.`
      : `${raceBreakfast(min, false)}. Na kolesu ${fuel(min >= CARB_LOAD_RACE_MIN ? '80–90' : '60–80')}${min >= FUEL_RACE_MIN ? ' od 30. minute' : ''}, pijača z elektroliti. Ravnina v zavetrini, dolge klance enakomerno ${w ? `do ~${w.hi} W` : onThr} — ne po špicah skupine.`,
    vzpon: `Ogrevanje 25–30 min s 3 × 1 min na pragu. Prvih 5 min ne prehitro (${w ? `~${w.lo}–${w.hi} W` : hr ?? 'tik pod pragom'}), sredina enakomerno, zadnja tretjina vse.`,
    klanci: `${raceBreakfast(min, false)}. Na klancih enakomerno ${w ? `na pragu (~${w.hi} W)` : onThr}, napade spremljaj le, če jih zmoreš; jej in pij od začetka (${fuel('70–90')}).`,
    sprint: 'Ogrevanje 20 min s 3 pospeški. V dirki v zavetrini in blizu čela; zadnji kilometer v prvih 10, šprint 200–250 m pred ciljem, iz zavetrja.',
    // (v3.49) tempo po trajanju (pod 40 min malo nad pragom) — isto kot pri drugih tekmah
    kronometer: `Ogrevanje 25–30 min s 3 × 2 min na pragu. ${ttPace(p, min).text} Aero položaj, ravna linija.`,
    cestna: `${raceBreakfast(min, false)}. V zavetrini varčuj, na klancih enakomerno${w ? ` do ~${w.hi} W` : hr ? ` ${onThr}` : ''}; jej in pij od začetka (${fuel('60–90')}).`,
  }
  return { title: `${g.name}${km ? ` — ${km} km` : ''}`, desc: d[g.type], min, zone: 'dirka', tss: tssOf(min, g.type === 'vzpon' || g.type === 'kronometer' ? 0.95 : 0.76), target: g.type === 'kronometer' ? ttPace(p, min).main : g.type === 'vzpon' || franja ? thr : null, role: 'dirka', why: 'Cilj sezone — dan D.' }
}

/** Hribi namesto kolesa: lahki, dolgi in regeneracijski dnevi (ključni trening, test in tekma ne). */
export function canHike(d: Pick<PlanDay, 'kind' | 'role' | 'done'>): boolean {
  return d.kind === 'kolo' && !d.done && (!d.role || d.role === 'lahka' || d.role === 'dolga' || d.role === 'regen')
}
/** Enak aerobni učinek: vzpon v Z2 po utripu, ~15 % dlje od vožnje. Prvotni trening ostane v `swap` (nazaj z enim klikom). */
export function hikeSwap(d: PlanDay, p: Profile): PlanDay {
  const dur = clamp(r5(d.durationMin * 1.15), 60, 480)
  const hr = lthrZoneText(p, 'Z2')
  const h = (m: number) => `${Math.floor(m / 60)} h${m % 60 ? ` ${m % 60} min` : ''}`
  return {
    ...d, kind: 'pohod', title: d.role === 'dolga' ? 'Hribi — dolga tura' : 'Hribi namesto kolesa',
    desc: `${h(dur)} hoje v hribe: gor v Z2${hr ? ` (${hr})` : ' (še lahko govoriš v celih stavkih)'}, navzdol mirno. Enak aerobni učinek kot ${d.durationMin} min kolesa v Z2 — čim več vzpona, brez teka. Voda, nekaj za pojest; palice razbremenijo kolena navzdol.`,
    // (v3.50) enak aerobni učinek = enaka obremenitev: TSS zamenjane vožnje (prej (ure × 50) = +33 % in forma je skočila)
    durationMin: dur, zone: 'Z2', tssTarget: d.tssTarget != null && d.tssTarget > 0 ? d.tssTarget : Math.round((dur / 60) * 50), target: null, role: d.role === 'dolga' ? 'dolga' : 'lahka',
    swap: { kind: d.kind, title: d.title, desc: d.desc, durationMin: d.durationMin, zone: d.zone ?? null, tssTarget: d.tssTarget ?? null, role: d.role ?? null, target: d.target ?? null },
    why: 'Zamenjava: hribi so dober aerobni trening, pozimi pogosto prijetnejši od mrzlega kolesa.',
    updatedAt: new Date().toISOString(),
  }
}
export function swapBack(d: PlanDay): PlanDay {
  if (!d.swap) return d
  return { ...d, ...d.swap, swap: null, why: null, updatedAt: new Date().toISOString() }
}

/** Jedro po želji (15–20 min): neobvezno, ne šteje v realizacijo; ponovitve rastejo iz zadnje opravljene seje. */
export function coreOnDemand(p: Profile, activities: readonly Activity[], date: string, o: { ride?: boolean } = {}): PlanDay {
  const st = strengthSession('jedro', p, activities)
  const now = new Date().toISOString()
  // (v3.51) dan brez kolesa: »Kadar koli danes« (prej »Po kolesu ali zvečer.« tudi na dan počitka)
  const desc = o.ride === false ? st.desc.replace(/^Po kolesu ali zvečer\. /, `Kadar koli danes — ${st.min} min. `) : st.desc
  return { id: uid(), date, kind: 'moc', title: st.title, desc: `${desc} Po želji — ne šteje v realizacijo tedna.`, durationMin: st.min, zone: null, tssTarget: 15, exercises: st.exercises, role: 'moc', optional: true, why: 'Po želji: močan trup = stabilna drža, vsi vati gredo v pedala.', source: 'rules', createdAt: now, updatedAt: now, done: null }
}

