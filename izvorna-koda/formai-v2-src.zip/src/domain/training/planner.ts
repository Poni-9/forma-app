import type { Activity, PlanDay, PlanKind, Profile } from '../types'
import { addDays, formSeries, todayIso, weekStartIso } from './load'
import { zoneText } from './zones'

/** Ukrivljenost dežja po dnevih (0–100), če jo poznamo; sicer 30. */
export type RainByDate = Record<string, number | undefined>

export interface PlanInput {
  profile: Profile
  activities: readonly Activity[]
  /** prvi dan tedna (ISO, ponedeljek) — privzeto ta teden */
  weekStart?: string
  rain?: RainByDate
  /** ali je to prvi teden (vključi 20-min test) */
  firstWeek?: boolean
  /** dnevi pred tem datumom so že mimo → počitek, in ne štejejo v razporeditev (privzeto danes) */
  notBefore?: string
}

/** Kateri ponedeljek naj bo začetek PRVEGA načrta: če je teden že večinoma mimo (čet+), naslednji. */
export function firstPlanWeekStart(today: string = todayIso()): string {
  const ws = weekStartIso(today)
  const dow = Math.round((new Date(today).getTime() - new Date(ws).getTime()) / 86400_000)
  return dow >= 3 ? addDays(ws, 7) : ws
}

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)

/* ====================================================================
   12-TEDENSKI CIKEL: osnova 4 → gradnja 4 → vrh 3 → test 1; vsak 4. teden razbremenilni.
   ==================================================================== */
export type Quality = 'sst' | 'prag' | 'vo2' | 'test'
export interface Phase { name: string; weeks: number[]; quality: Quality; desc: string }
export const PHASES: Phase[] = [
  { name: 'Osnova', weeks: [1, 2, 3, 4], quality: 'sst', desc: 'Z2 volumen in sweet spot. Motor se gradi tu.' },
  { name: 'Gradnja', weeks: [5, 6, 7, 8], quality: 'prag', desc: 'Intervali na pragu (3 × 10 min). Volumen ostane.' },
  { name: 'Vrh', weeks: [9, 10, 11], quality: 'vo2', desc: 'VO2max 4 × 4 min, manj volumna, več kakovosti.' },
  { name: 'Test', weeks: [12], quality: 'test', desc: 'Razbremenitev in 20-minutni test — nova izhodišča.' },
]
export const CYCLE_WEEKS = 12
export interface CycleInfo { week: number; length: number; phase: Phase; recovery: boolean }
export function cycleInfo(p: Pick<Profile, 'cycleStart'>, weekStart: string = weekStartIso(todayIso())): CycleInfo | null {
  if (!p.cycleStart) return null
  const w = Math.floor((new Date(weekStart).getTime() - new Date(p.cycleStart).getTime()) / (7 * 86400_000)) + 1
  if (w < 1 || w > CYCLE_WEEKS) return null
  const phase = PHASES.find(x => x.weeks.includes(w)) || PHASES[0]!
  return { week: w, length: CYCLE_WEEKS, phase, recovery: w % 4 === 0 }
}

/* ====================================================================
   MOČ DOMA: potisk · poteg · noge. Drog za zgibe in (po želji) uteži.
   Napredovanje: iz zadnje zabeležene seje z istim naslovom (kg, +1 ponovitev).
   ==================================================================== */
export type StrengthKind = 'potisk' | 'poteg' | 'noge'
export type Exercise = { name: string; sets: number; reps: string; kg?: number | null }
const BODY: Record<StrengthKind, [string, number, string][]> = {
  potisk: [['Sklece', 4, '8–15'], ['Dipsi med stoloma', 3, '8–12'], ['Pike sklece', 3, '6–10'], ['Deska', 3, '45–60 s']],
  poteg: [['Zgibi (ali negativni)', 4, 'max'], ['Avstralski zgibi', 3, '10–15'], ['Vesa na drogu', 3, '20–40 s'], ['Superman', 3, '12–15']],
  noge: [['Počepi', 4, '15–20'], ['Bolgarski počepi', 3, '8–10/noga'], ['Most za zadnjico', 3, '15'], ['Dvigi na prste', 3, '20']],
}
const NO_BAR: [string, number, string][] = [['Veslanje z brisačo pod mizo', 4, '10–15'], ['Obrnjeno veslanje', 3, '8–12'], ['Superman', 3, '12–15'], ['Vesa/drža lopatic', 3, '20 s']]
const WEIGHTS: Record<StrengthKind, [string, number, string]> = { potisk: ['Potisk nad glavo', 3, '8–12'], poteg: ['Veslanje z utežjo', 3, '10–12'], noge: ['Rumunski mrtvi dvig', 3, '10–12'] }
export const STRENGTH_TITLE: Record<StrengthKind, string> = { potisk: 'Moč — potisk', poteg: 'Moč — poteg', noge: 'Moč — noge' }

export function strengthSession(kind: StrengthKind, p: Profile, activities: readonly Activity[], light = false): { title: string; exercises: Exercise[]; desc: string; progressed: boolean } {
  const bar = p.gear.pullupBar !== false     // privzeto drog imamo
  const gym = p.strength.equipment === 'gym'
  let ex: Exercise[] = (kind === 'poteg' && !bar && !gym ? NO_BAR : BODY[kind]).map(([name, sets, reps]) => ({ name, sets: light ? Math.max(2, sets - 1) : sets, reps, kg: null }))
  if (p.gear.dumbbells || p.strength.equipment === 'home' || gym) { const w = WEIGHTS[kind]; ex.splice(2, 0, { name: w[0], sets: w[1], reps: w[2], kg: p.gear.dumbbellKg || null }) }
  const title = STRENGTH_TITLE[kind]
  // napredovanje iz zadnje zabeležene seje
  const last = [...activities].filter(a => a.sport === 'moc' && a.name === title && a.exercises && a.exercises.length).sort((a, b) => b.date.localeCompare(a.date))[0]
  let progressed = false
  if (last && !light) {
    for (const x of ex) {
      const z = last.exercises!.find(y => y.name.toLowerCase() === x.name.toLowerCase())
      if (!z) continue
      if (z.kg) x.kg = z.kg
      if (z.sets > x.sets) x.sets = Math.min(6, z.sets)
      const m = String(z.reps).match(/^(\d+)\s*[–-]\s*(\d+)(\s*s)?$/)
      if (m) { const inc = m[3] ? 5 : 1, hi = +m[2]! + inc; if (m[3] ? hi <= 120 : hi <= 25) { x.reps = `${+m[1]! + inc}–${hi}${m[3] ? ' s' : ''}`; progressed = true } }
    }
  }
  const desc = light ? 'Lažji teden: manj setov, ista tehnika. Zadnja ponovitev naj bo težka, ne nemogoča.'
    : progressed ? 'Prejšnjič si to sejo opravil — cilji so dvignjeni. Počasi, s kontrolo.'
    : 'Počasi, s kontrolo. Ko v vseh setih dosežeš zgornjo mejo ponovitev, naslednjič dodaj set ali težjo različico.'
  return { title, exercises: ex, desc, progressed }
}

function qualitySession(q: Quality, p: Profile, minutes: number, primaryRun: boolean): Pick<PlanDay, 'title' | 'desc' | 'zone' | 'durationMin' | 'tssTarget' | 'why'> {
  if (primaryRun) return { title: '6 × 2 min hitreje', desc: 'Po 12 min ogrevanja: 6 × 2 min hitro / 2 min hoja. Iztek 8 min.', durationMin: Math.max(40, minutes), zone: 'Z4', tssTarget: 60, why: 'En hiter dan na teden je dovolj — ostali gradijo osnovo.' }
  const ftp = p.ftp
  const w = (a: number, b: number) => (ftp ? ` (${Math.round(ftp * a)}–${Math.round(ftp * b)} W)` : ` (${zoneText(p, 'Z4')})`)
  switch (q) {
    case 'prag': return { title: 'Prag 3 × 10 min', desc: `15 min ogrevanje, 3 × 10 min pri 95–100 % FTP${w(.95, 1)}, vmes 5 min lahko, izvoz. Enakomerno — zadnja minuta vsakega intervala naj bo še obvladljiva.`, durationMin: Math.max(65, minutes), zone: 'Z4', tssTarget: 85, why: 'Delo na pragu premakne FTP; vse ostalo v tednu naj bo lažje.' }
    case 'vo2': return { title: 'VO2max 4 × 4 min', desc: `15 min ogrevanje s 3 kratkimi pospeški, 4 × 4 min pri 110–120 % FTP${ftp ? ` (${Math.round(ftp * 1.1)}–${Math.round(ftp * 1.2)} W)` : ''}, vmes 4 min lahko, izvoz.`, durationMin: Math.max(60, minutes), zone: 'Z5', tssTarget: 90, why: 'Kratki težki intervali dvignejo strop — samo enkrat na teden.' }
    default: return { title: 'Sweet spot 2 × 15 min', desc: `15 min ogrevanje, 2 × 15 min pri 88–93 % FTP${ftp ? ` (${Math.round(ftp * .88)}–${Math.round(ftp * .93)} W)` : ` (${zoneText(p, 'Z3')})`}, vmes 5 min lahko, izvoz.`, durationMin: Math.max(60, minutes), zone: 'Z3', tssTarget: 75, why: 'Sweet spot da največ motorja na minuto — težko, a ponovljivo.' }
  }
}

/**
 * Deterministični tedenski načrt — brez omrežja, brez AI.
 * Osebna različica: 2 × Z2 + 1 kakovostna (po fazi cikla), dolga vožnja na najbolj suh vikend dan,
 * moč doma potisk–poteg–noge z napredovanjem, hoja ob počitku (neobvezno), razbremenilni teden.
 */
export function buildWeek(inp: PlanInput): PlanDay[] {
  const p = inp.profile
  const start = inp.weekStart || weekStartIso(todayIso())
  const rain = inp.rain || {}
  const now = new Date().toISOString()
  const cycle = cycleInfo(p, start)

  // 1) Volumen: ure iz profila ali iz nivoja
  const hours = p.hoursPerWeek || ({ 1: 2, 2: 4, 3: 7, 4: 11 } as Record<number, number>)[p.level || 2] || 4

  // 2) Skaliranje glede na formo, realizacijo in cikel
  const series = formSeries(inp.activities)
  const tsb = series.length ? series[series.length - 1]!.tsb : 0
  const last14 = inp.activities.filter(a => a.date >= addDays(start, -14) && a.date < start)
  const recovery = !!(cycle && cycle.recovery)
  const loadScale = recovery ? 0.65 : tsb < -20 ? 0.85 : 1

  // 3) Primarni in sekundarni šport
  const noBike = p.gear.noBike && !p.gear.bikeOutdoor && !p.gear.trainer
  const primary: PlanKind = noBike ? 'tek' : 'kolo'
  const secondary: PlanKind | null = noBike ? 'pohod' : null

  // 4) Proračun dni
  const aktDni = hours <= 4 ? 3 : hours <= 7 ? 4 : 5
  const mocDni = p.strength.on ? Math.max(0, Math.min(4, p.strengthDays ?? (hours <= 4 ? 1 : 2))) : 0
  const quality: Quality | null = cycle ? (cycle.phase.quality === 'test' ? 'test' : cycle.phase.quality) : 'sst'
  const withTest = !!inp.firstWeek || quality === 'test'

  // 5) Razvrstitev po vremenu: dolg dan = najbolj suh vikend, kvaliteten = najbolj suh preostali (ne danes)
  const days = Array.from({ length: 7 }, (_, i) => addDays(start, i))
  const notBefore = inp.notBefore || todayIso()
  const avail = [0, 1, 2, 3, 4, 5, 6].filter(i => days[i]! >= notBefore)
  const wx = (i: number) => rain[days[i]!] ?? 30
  const weekend = [5, 6].filter(i => avail.includes(i))
  const dolg = (weekend.length ? weekend : avail.slice(-1)).sort((a, b) => wx(a) - wx(b))[0]
  const rest = avail.filter(i => i !== dolg)
  const kakovKandidati = rest.filter(i => days[i]! > notBefore || rest.length <= 1)
  const kakov = recovery && !withTest ? null : withTest ? (rest.find(i => i >= 2) ?? rest[0]) : (kakovKandidati.length ? kakovKandidati : rest).sort((a, b) => wx(a) - wx(b))[0]

  // vsaj en prost dan v tednu: raje en kolesarski dan manj (nad 3) kot brez počitka, potem manj moči
  let aktDniEff = Math.min(aktDni, avail.length)
  let mocEff = Math.min(mocDni, avail.length)
  while (avail.length >= 3 && aktDniEff + mocEff > avail.length - 1) {
    if (aktDniEff > 3 || (aktDniEff > 2 && mocEff <= 2)) aktDniEff--
    else if (mocEff > 0) mocEff--
    else aktDniEff--
  }
  const slots: (PlanKind | 'walk' | null)[] = Array(7).fill(null)
  if (dolg != null) slots[dolg] = primary
  if (kakov != null && kakov !== dolg) slots[kakov] = withTest ? 'test' : primary
  let remaining = aktDniEff - [dolg, kakov].filter((v, i, a) => v != null && a.indexOf(v) === i).length
  for (const i of [0, 2, 4, 1, 3, 5, 6]) {
    if (remaining <= 0) break
    if (!avail.includes(i) || slots[i]) continue
    if (aktDniEff <= 4 && kakov != null && Math.abs(i - kakov) === 1) continue
    slots[i] = remaining % 2 === 0 && secondary ? secondary : primary
    remaining--
  }
  let moc = mocEff
  const mocOrder: StrengthKind[] = ['potisk', 'poteg', 'noge']
  const mocKind: Record<number, StrengthKind> = {}
  const mocDays: number[] = []
  for (const i of [0, 2, 4, 1, 3, 5, 6]) {
    if (moc <= 0) break
    if (!avail.includes(i) || slots[i]) continue
    slots[i] = 'moc'; mocDays.push(i); moc--
  }
  // vrstni red v koledarju: potisk → poteg → noge
  mocDays.sort((a, b) => a - b).forEach((i, k) => { mocKind[i] = mocOrder[k % 3]! })
  // hoja ob počitku (neobvezno) — dviguje porabo brez utrujenosti
  for (const i of avail) if (!slots[i]) slots[i] = 'walk'

  // 6) Trajanja: ure na teden minus moč, razdeljene po kolesarskih dneh (dolga ≈ 1,6×)
  const bikeMin = Math.max(90, hours * 60 - mocEff * 40)
  const durBase = Math.max(30, Math.round(bikeMin / (Math.max(1, aktDniEff) + 0.6) / 5) * 5)
  const out: PlanDay[] = []
  days.forEach((date, i) => {
    const k = slots[i]
    const base = { id: uid(), date, source: 'rules' as const, createdAt: now, updatedAt: now, done: null }
    if (!k) {
      const mimo = date < notBefore
      out.push({ ...base, kind: 'pocitek', title: mimo ? 'Pred začetkom' : 'Počitek', desc: mimo ? 'Ta dan je bil pred začetkom načrta.' : 'Hoja, raztezanje, spanec.', durationMin: 0, zone: null, tssTarget: 0, why: mimo ? null : 'Prilagoditev se zgodi med počitkom, ne med treningom.' })
      return
    }
    if (k === 'walk') {
      out.push({ ...base, kind: 'pohod', title: 'Hoja 45–60 min', desc: 'Počitek od treninga, ne od gibanja. Hoja dvigne porabo brez utrujenosti — sprehod, po možnosti v klanec.', durationMin: 50, zone: 'Z1', tssTarget: 25, optional: true, why: 'Neobvezno. Na dan počitka šteje vsak korak, ne šteje pa v obremenitev.' })
      return
    }
    if (k === 'moc') {
      const s = strengthSession(mocKind[i] || 'potisk', p, inp.activities, recovery)
      out.push({ ...base, kind: 'moc', title: s.title, desc: s.desc, durationMin: recovery ? 30 : 40, zone: null, tssTarget: recovery ? 30 : 45, exercises: s.exercises, why: 'Moč doma 2–3× na teden gradi mišice in ščiti pred poškodbo. Napredek pride iz zabeleženih ponovitev.' })
      return
    }
    if (k === 'test') {
      out.push({ ...base, kind: primary === 'tek' ? 'tek' : 'kolo', title: '20-minutni test', desc: primary === 'tek' ? '10 min ogrevanje, 20 min enakomerno čim hitreje, 10 min iztek.' : '15 min ogrevanje s 3 × 1 min hitreje, 5 min lahko, 20 min enakomerno čim močneje, 10 min izvoz. FTP = 95 % povprečja teh 20 min.', durationMin: primary === 'tek' ? 45 : 60, zone: 'test', tssTarget: Math.round(70 * loadScale), why: 'Iz testa dobim tvoje cone natančno — načrt po tem postane tvoj.' })
      return
    }
    const isLong = i === dolg, isQuality = i === kakov
    if (k === 'pohod') {
      const d = isLong ? Math.max(120, Math.round(durBase * 1.6)) : durBase
      out.push({ ...base, kind: 'pohod', title: isLong ? 'Dolga hoja' : 'Hitra hoja', desc: 'Tempo, pri katerem lahko govoriš. Klanci so dobrodošli.', durationMin: Math.round(d * loadScale), zone: 'Z2', tssTarget: Math.round(d * 0.9 * loadScale) })
      return
    }
    if (k === 'tek') {
      if (isQuality) { const q = qualitySession('sst', p, durBase, true); out.push({ ...base, kind: 'tek', ...q, durationMin: Math.round(q.durationMin * loadScale), tssTarget: Math.round((q.tssTarget || 60) * loadScale) }) }
      else if (isLong) out.push({ ...base, kind: 'tek', title: 'Dolgi tek/hoja', desc: 'Tečeš tako počasi, da lahko govoriš v celih stavkih. Če ne moreš, hodi dlje.', durationMin: Math.round(Math.max(50, durBase * 1.2) * loadScale), zone: 'Z2', tssTarget: Math.round(70 * loadScale) })
      else out.push({ ...base, kind: 'tek', title: (p.level || 2) <= 1 ? '6 × (4 min tek / 2 min hoja)' : 'Lahek tek', desc: 'Pogovorni tempo. Če ne moreš govoriti, upočasni.', durationMin: Math.round(durBase * loadScale), zone: 'Z2', tssTarget: Math.round(durBase * 0.95 * loadScale) })
      return
    }
    // kolo
    if (isQuality) { const q = qualitySession(quality || 'sst', p, durBase, false); out.push({ ...base, kind: 'kolo', ...q, durationMin: Math.round(q.durationMin * loadScale), tssTarget: Math.round((q.tssTarget || 80) * loadScale) }) }
    else if (isLong) out.push({ ...base, kind: 'kolo', title: recovery ? 'Lahka daljša Z2' : 'Dolga vzdržljivostna Z2', desc: `Enakomeren tempo ${zoneText(p, 'Z2')}, brez špicev. Po prvi uri jej 40–60 g ogljikovih hidratov na uro. Zadnjih 20 min lahko malo pospešiš.`, durationMin: Math.round(Math.max(90, durBase * 1.6) * loadScale), zone: 'Z2', tssTarget: Math.round(durBase * 1.6 * 0.95 * loadScale), why: 'Dolga Z2 vožnja je temelj motorja in največja poraba maščob v tednu.' })
    else out.push({ ...base, kind: 'kolo', title: 'Lahka vožnja Z2', desc: `Mirno, ${zoneText(p, 'Z2')}, visoka kadenca, brez sprintov. Če si utrujen, skrajšaj, ne pospešuj.`, durationMin: Math.round(durBase * loadScale), zone: 'Z2', tssTarget: Math.round(durBase * 0.9 * loadScale) })
  })

  // 7) Razlaga o skaliranju — na prvi aktivni dan
  const f = out.find(d => d.kind !== 'pocitek' && !d.optional)
  if (f) {
    if (recovery) f.why = `Razbremenilni teden (${cycle!.week}/${cycle!.length}): −35 % volumna, brez intenzivnosti. Tu se zgodi napredek.`
    else if (loadScale < 1) f.why = (f.why ? f.why + ' ' : '') + `Ta teden je 15 % lažji: forma je ${tsb.toFixed(0)} (utrujenost visoka)${last14.length ? '' : ' in v zadnjih dveh tednih ni zabeleženih aktivnosti'}.`
    else if (cycle) f.why = `${cycle.phase.name}, teden ${cycle.week}/${cycle.length}. ${cycle.phase.desc}${f.why ? ' ' + f.why : ''}`
  }
  return out
}

/** Skupno načrtovano trajanje tedna (min) — brez neobveznih dni. */
export function weekMinutes(days: readonly PlanDay[]): number { return days.filter(d => !d.optional).reduce((s, d) => s + (d.durationMin || 0), 0) }

/** Napovedana forma na zadnji dan tedna, če opraviš vse načrtovano. */
export function forecastForm(activities: readonly Activity[], week: readonly PlanDay[], today: string = todayIso()): { ctl: number; atl: number; tsb: number; date: string } | null {
  if (!week.length) return null
  const s = formSeries(activities, today)
  let ctl = s.length ? s[s.length - 1]!.ctl : 0, atl = s.length ? s[s.length - 1]!.atl : 0
  for (const d of [...week].sort((a, b) => a.date.localeCompare(b.date))) {
    if (d.date <= today) continue
    const tss = d.done ? 0 : (d.tssTarget || 0)
    ctl += (tss - ctl) / 42; atl += (tss - atl) / 7
  }
  return { ctl: Math.round(ctl), atl: Math.round(atl), tsb: Math.round(ctl - atl), date: week[week.length - 1]!.date }
}

/** Minute po conah za načrtovan teden (kakovostne seje: 45 % v ciljni coni, 40 % Z2, 15 % Z1). */
export function zoneMinutes(week: readonly PlanDay[]): Record<'Z1' | 'Z2' | 'Z3' | 'Z4' | 'Z5', number> {
  const m = { Z1: 0, Z2: 0, Z3: 0, Z4: 0, Z5: 0 }
  for (const d of week) {
    if (d.kind === 'moc' || d.kind === 'pocitek' || d.optional) continue
    const z = (d.zone === 'test' ? 'Z4' : d.zone || 'Z2') as keyof typeof m
    if (!(z in m)) continue
    const t = d.durationMin || 0
    if (z === 'Z1' || z === 'Z2') m[z] += t
    else { m[z] += Math.round(t * .45); m.Z2 += Math.round(t * .4); m.Z1 += Math.round(t * .15) }
  }
  return m
}

/**
 * »Olajšaj dan« brez AI: današnjo sejo prestavi na naslednji prost dan v tednu (hoja/počitek),
 * danes pa ostane lahka hoja ali Z1. Vrne dneve za shranitev (po id-ju) ali null, če ni česa olajšati.
 */
export function easeDay(week: readonly PlanDay[], today: string): PlanDay[] | null {
  const cur = week.find(d => d.date === today && d.kind !== 'pocitek' && !d.optional && !d.done)
  if (!cur) return null
  const later = [...week].filter(d => d.date > today && !d.done && (d.optional || d.kind === 'pocitek')).sort((a, b) => a.date.localeCompare(b.date))[0]
  const now = new Date().toISOString()
  const out: PlanDay[] = []
  const dn = (iso: string) => ['nedeljo', 'ponedeljek', 'torek', 'sredo', 'četrtek', 'petek', 'soboto'][new Date(iso).getDay()]
  if (later) out.push({ ...cur, id: later.id, date: later.date, why: `Prestavljeno z danes (${dn(today)}) zaradi nizke pripravljenosti.`, source: 'rules', updatedAt: now })
  out.push({ ...cur, kind: 'pohod', title: 'Lahek dan — hoja ali Z1', desc: 'Telo je dalo znak. 30–45 min hoje ali zelo lahkega vrtenja, veliko vode, zgodaj spat.', durationMin: 40, zone: 'Z1', tssTarget: 20, exercises: undefined, optional: true, why: later ? `Seja je prestavljena na ${dn(later.date)}.` : 'Ta seja ta teden odpade — bolje en trening manj kot bolezen ali poškodba.', source: 'rules', updatedAt: now })
  return out
}
