import type { Profile, Race, RaceType } from '../types'

/**
 * SEZONA Z VEČ CILJI. Glavni cilj (profile.event, npr. Franja) in drugi cilji A so vrhovi forme: pred vsakim
 * specifičen blok za to vrsto dirke in tapering, po njem teden (ali dva) lahko. B in C sta tekmi med potjo.
 * Vrsta dirke določa vsebino specifičnega bloka; izven njega se trenira vse (klanci, ravnina, šprint, vzdržljivost).
 */
export const RACE_TYPES: Record<RaceType, { l: string; d: string; kmh: number }> = {
  sprint: { l: 'Šprint', d: 'ravninska ali kriterij, odloči zaključni šprint', kmh: 40 },
  klanci: { l: 'Klanci', d: 'razgibana, odločajo ponavljajoči se klanci in napadi', kmh: 31 },
  vzpon: { l: 'Vzpon', d: 'gorski kronometer ali cilj na vrhu, odloči dolg klanec', kmh: 15 },
  maraton: { l: 'Maraton', d: 'dolga (100+ km), odločita vzdržljivost in gorivo', kmh: 30 },
  kronometer: { l: 'Kronometer', d: 'sam proti uri na ravnem, odloči prag v aero položaju', kmh: 38 },
  cestna: { l: 'Cestna', d: 'mešano: klanci, ravnina, napadi', kmh: 34 },
}

type RaceLike = { name: string; distanceKm?: number | null; elevM?: number | null; type?: RaceType | null; level?: 'amater' | 'visji' | null }

/** Vzpon na km (m/km), če je znan. */
export const mPerKm = (r: RaceLike): number | null => (r.elevM != null && r.distanceKm ? r.elevM / r.distanceKm : null)

/** Vrsta dirke: vpisana ali ocenjena iz imena, dolžine in vzpona. */
export function raceTypeOf(r: RaceLike): RaceType {
  if (r.type) return r.type
  const n = r.name.toLowerCase(), km = r.distanceKm ?? 0, mpk = mPerKm(r)
  if (/kronometer|\bitt\b|\btt\b|contre|time trial/.test(n)) return /vzpon|gorsk|uphill|hill|na vrh|cronoscalata/.test(n) || (mpk ?? 0) >= 35 ? 'vzpon' : 'kronometer'
  if (/vzpon|gorsk|uphill|hill ?climb|na vrh|cronoscalata|bergrennen/.test(n) || ((mpk ?? 0) >= 35 && km > 0 && km <= 40)) return 'vzpon'
  if (/kriterij|criterium|kermesse|šprint|sprint/.test(n) || (mpk != null && mpk < 4 && km > 0 && km <= 90)) return 'sprint'
  if (mpk != null && mpk >= 15) return 'klanci'
  if (km >= 110 || /maraton|marathon|granfondo|gran fondo|franja/.test(n)) return 'maraton'
  return 'cestna'
}

export interface SeasonGoal { id: string; name: string; date: string; distanceKm: number | null; elevM: number | null; level: 'amater' | 'visji' | null; type: RaceType; main: boolean }

/** Cilji sezone (A): glavni cilj + druge tekme A, po datumu. */
export function seasonGoals(p: Pick<Profile, 'event' | 'races'>): SeasonGoal[] {
  const out: SeasonGoal[] = []
  if (p.event?.date) out.push({ id: 'main', name: p.event.name, date: p.event.date, distanceKm: p.event.distanceKm ?? null, elevM: p.event.elevM ?? null, level: p.event.level ?? null, type: raceTypeOf(p.event), main: true })
  for (const r of p.races || []) if (r.prio === 'A' && r.date !== p.event?.date) out.push({ id: r.id, name: r.name, date: r.date, distanceKm: r.distanceKm ?? null, elevM: r.elevM ?? null, level: r.level ?? null, type: raceTypeOf(r), main: false })
  return out.sort((a, b) => a.date.localeCompare(b.date))
}

/**
 * VRHOVI FORME. Vrh forme po taperingu zdrži 2–3 tedne, zato ima svoj specifičen blok in tapering le cilj, ki je vsaj
 * 5 tednov od drugega vrha. Glavni cilj je vedno vrh; bližnji cilj A se vozi v isti formi (prilagodi se samo teden tekme,
 * kot pri B). Tako tudi pri veliko tekmah načrt ne postane samo tapering.
 */
export const PEAK_GAP_DAYS = 35
const days = (a: string, b: string) => Math.round((Date.parse(b + 'T12:00:00Z') - Date.parse(a + 'T12:00:00Z')) / 86_400_000)
export function peakGoals(p: Pick<Profile, 'event' | 'races'>): SeasonGoal[] {
  const all = seasonGoals(p)
  const kept = all.filter(g => g.main)
  for (const g of all) if (!g.main && kept.every(k => Math.abs(days(k.date, g.date)) >= PEAK_GAP_DAYS)) kept.push(g)
  return kept.sort((a, b) => a.date.localeCompare(b.date))
}
/** Za cilj A, ki ni svoj vrh: s katerim vrhom si deli formo (za prikaz). */
export function peakOf(p: Pick<Profile, 'event' | 'races'>, id: string): SeasonGoal | null {
  const peaks = peakGoals(p), g = seasonGoals(p).find(x => x.id === id)
  if (!g || peaks.some(x => x.id === id)) return null
  return peaks.slice().sort((a, b) => Math.abs(days(a.date, g.date)) - Math.abs(days(b.date, g.date)))[0] ?? null
}

/** Tekme B in C (med potjo do ciljev). */
export function sideRaces(p: Pick<Profile, 'races'>): Race[] {
  return (p.races || []).filter(r => r.prio !== 'A')
}

/**
 * Ocena trajanja dirke (min): hitrost iz vzpona na km (38 km/h po ravnem, −0,45 km/h na vsak m/km; vzpon najmanj 12 km/h),
 * sicer iz vrste dirke; višji rang ~6 % hitreje. Brez dolžine: tipična dolžina za to vrsto.
 */
export function raceMinutes(r: RaceLike): number {
  const type = raceTypeOf(r)
  const km = r.distanceKm || (type === 'vzpon' ? 12 : type === 'sprint' ? 50 : type === 'kronometer' ? 25 : type === 'maraton' ? 156 : 90)
  const mpk = mPerKm(r)
  let v = mpk != null ? Math.max(12, Math.min(40, 38 - 0.45 * mpk)) : RACE_TYPES[type].kmh
  if (r.level === 'visji') v *= 1.06
  return Math.max(15, Math.round(((km / v) * 60) / 5) * 5)
}

/**
 * NAPORNOST TEKME 1–5 (za prikaz in načrt): trajanje (pod 1 h = 1 … nad 5 h = 5), +1 veliko klancev (15+ m/km),
 * +1 višji rang. Naporne tekme = daljše dolge vožnje v bloku pred njimi, daljši počitek po njih.
 */
export function raceDemand(r: RaceLike): { min: number; stars: number; hilly: boolean; long: boolean } {
  const min = raceMinutes(r), h = min / 60, mpk = mPerKm(r)
  const type = raceTypeOf(r)
  const hilly = type === 'klanci' || type === 'vzpon' || (mpk ?? 0) >= 15
  let stars = h < 1 ? 1 : h < 2 ? 2 : h < 3.5 ? 3 : h < 5 ? 4 : 5
  if ((mpk ?? 0) >= 15) stars++
  if (r.level === 'visji') stars++
  return { min, stars: Math.max(1, Math.min(5, stars)), hilly, long: h >= 3.5 }
}

/**
 * OFF-SEASON po zadnji tekmi (ali ko se odločiš): 2–6 tednov. Najprej počitek (tretjina, vsaj 1 teden: brez kolesa,
 * po želji sprehod ali hribi), nato aktivni počitek (hribi, vožnja po občutku, drugi športi), zadnji teden vrnitev
 * (lahke vožnje). Nato lahki tedni osnove in počasna gradnja.
 */
export const OFF_MAX = 6
export type OffStage = 'pocitek' | 'aktivno' | 'vrnitev'
export function offStage(week: number, total: number): OffStage {
  const rest = Math.max(1, Math.round(total / 3))
  if (week <= rest && total >= 2) return 'pocitek'
  if (week === total && total >= 3) return 'vrnitev'
  return 'aktivno'
}
/**
 * FTP po off-seasonu: po N tednih počitka in lahke vadbe je FTP nekaj % nižji (1 teden −1 %, 2 −3 %, 3 −5 %, 4 −7 %,
 * 5 −8 %, 6 −9 %), dokler ga ne izmeriš znova (test je po lahkih tednih osnove). Vrne FTP za vate v načrtu za teden weekStart.
 */
export const OFF_DROP = [0, 0.01, 0.03, 0.05, 0.07, 0.08, 0.09]
export function ftpForWeek(p: Pick<Profile, 'ftp' | 'ftpDate' | 'offSeasonWeeks' | 'cycleStart'>, weekStart: string): number | null {
  const off = Math.max(0, Math.min(OFF_MAX, p.offSeasonWeeks ?? 0))
  if (!p.ftp || !off || !p.cycleStart || weekStart < p.cycleStart) return p.ftp ?? null
  const end = new Date(Date.parse(p.cycleStart + 'T12:00:00Z') + off * 7 * 86_400_000).toISOString().slice(0, 10)
  if (p.ftpDate && p.ftpDate >= end) return p.ftp        // izmerjen po premoru
  return Math.round(p.ftp * (1 - OFF_DROP[off]!))
}
