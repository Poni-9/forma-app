import type { Profile, Race, RaceType } from '../types'

/**
 * SEZONA Z VEČ CILJI. Glavni cilj (profile.event, npr. Franja) in drugi cilji A so vrhovi forme: pred vsakim
 * specifičen blok za to vrsto dirke in tapering, po njem teden (ali dva) lahko. B in C sta tekmi med potjo.
 * Vrsta dirke določa vsebino specifičnega bloka; izven njega se trenira vse (klanci, ravnina, šprint, vzdržljivost).
 */
export const RACE_TYPES: Record<RaceType, { l: string; d: string; kmh: number }> = {
  sprint: { l: 'Šprint', d: 'ravninska ali kriterij, odloči zaključni šprint', kmh: 40 },
  klanci: { l: 'Klanci', d: 'razgibana, odločajo ponavljajoči se klanci in napadi', kmh: 31 },
  vzpon: { l: 'Vzpon', d: 'gorski kronometer ali cilj na vrhu, odloči dolg klanec', kmh: 15 },
  maraton: { l: 'Maraton', d: 'dolga (100+ km), odločita vzdržljivost in gorivo', kmh: 30 },
  kronometer: { l: 'Kronometer', d: 'sam proti uri na ravnem, odloči prag v aero položaju', kmh: 38 },
  cestna: { l: 'Cestna', d: 'mešano: klanci, ravnina, napadi', kmh: 34 },
}

type RaceLike = { name: string; distanceKm?: number | null; elevM?: number | null; type?: RaceType | null; level?: 'amater' | 'visji' | null }

/** Vzpon na km (m/km), če je znan. */
export const mPerKm = (r: RaceLike): number | null => (r.elevM != null && r.distanceKm ? r.elevM / r.distanceKm : null)

/** Vrsta dirke: vpisana ali ocenjena iz imena, dolžine in vzpona. */
export function raceTypeOf(r: RaceLike): RaceType {
  if (r.type) return r.type
  const n = r.name.toLowerCase(), km = r.distanceKm ?? 0, mpk = mPerKm(r)
  if (/kronometer|\bitt\b|\btt\b|contre|time trial/.test(n)) return /vzpon|gorsk|uphill|hill|na vrh|cronoscalata/.test(n) || (mpk ?? 0) >= 35 ? 'vzpon' : 'kronometer'
  if (/vzpon|gorsk|uphill|hill ?climb|na vrh|cronoscalata|bergrennen/.test(n) || ((mpk ?? 0) >= 35 && km > 0 && km <= 40)) return 'vzpon'
  if (/kriterij|criterium|kermesse|šprint|sprint/.test(n) || (mpk != null && mpk < 4 && km > 0 && km <= 90)) return 'sprint'
  if (mpk != null && mpk >= 15) return 'klanci'
  if (km >= 110 || /maraton|marathon|granfondo|gran fondo|franja/.test(n)) return 'maraton'
  return 'cestna'
}

export interface SeasonGoal { id: string; name: string; date: string; distanceKm: number | null; elevM: number | null; level: 'amater' | 'visji' | null; type: RaceType; main: boolean }

/** Cilji sezone (A): glavni cilj + druge tekme A, po datumu. */
export function seasonGoals(p: Pick<Profile, 'event' | 'races'>): SeasonGoal[] {
  const out: SeasonGoal[] = []
  if (p.event?.date) out.push({ id: 'main', name: p.event.name, date: p.event.date, distanceKm: p.event.distanceKm ?? null, elevM: p.event.elevM ?? null, level: p.event.level ?? null, type: raceTypeOf(p.event), main: true })
  for (const r of p.races || []) if (r.prio === 'A' && r.date !== p.event?.date) out.push({ id: r.id, name: r.name, date: r.date, distanceKm: r.distanceKm ?? null, elevM: r.elevM ?? null, level: r.level ?? null, type: raceTypeOf(r), main: false })
  return out.sort((a, b) => a.date.localeCompare(b.date))
}

/** Tekme B in C (med potjo do ciljev). */
export function sideRaces(p: Pick<Profile, 'races'>): Race[] {
  return (p.races || []).filter(r => r.prio !== 'A')
}

/**
 * Ocena trajanja dirke (min): hitrost iz vzpona na km (38 km/h po ravnem, −0,45 km/h na vsak m/km; vzpon najmanj 12 km/h),
 * sicer iz vrste dirke; višji rang ~6 % hitreje. Brez dolžine: tipična dolžina za to vrsto.
 */
export function raceMinutes(r: RaceLike): number {
  const type = raceTypeOf(r)
  const km = r.distanceKm || (type === 'vzpon' ? 12 : type === 'sprint' ? 50 : type === 'kronometer' ? 25 : type === 'maraton' ? 156 : 90)
  const mpk = mPerKm(r)
  let v = mpk != null ? Math.max(12, Math.min(40, 38 - 0.45 * mpk)) : RACE_TYPES[type].kmh
  if (r.level === 'visji') v *= 1.06
  return Math.max(15, Math.round(((km / v) * 60) / 5) * 5)
}

/**
 * NAPORNOST TEKME 1–5 (za prikaz in načrt): trajanje (pod 1 h = 1 … nad 5 h = 5), +1 veliko klancev (15+ m/km),
 * +1 višji rang. Naporne tekme = daljše dolge vožnje v bloku pred njimi, daljši počitek po njih.
 */
export function raceDemand(r: RaceLike): { min: number; stars: number; hilly: boolean; long: boolean } {
  const min = raceMinutes(r), h = min / 60, mpk = mPerKm(r)
  const type = raceTypeOf(r)
  const hilly = type === 'klanci' || type === 'vzpon' || (mpk ?? 0) >= 15
  let stars = h < 1 ? 1 : h < 2 ? 2 : h < 3.5 ? 3 : h < 5 ? 4 : 5
  if ((mpk ?? 0) >= 15) stars++
  if (r.level === 'visji') stars++
  return { min, stars: Math.max(1, Math.min(5, stars)), hilly, long: h >= 3.5 }
}

/**
 * FTP po off-seasonu: po N tednih počitka in lahke vadbe je FTP nekaj % nižji (1 teden −1 %, 2 −3 %, 3 −5 %, 4 −7 %),
 * dokler ga ne izmeriš znova (test je po lahkih tednih osnove). Vrne FTP za vate v načrtu za teden weekStart.
 */
export const OFF_DROP = [0, 0.01, 0.03, 0.05, 0.07]
export function ftpForWeek(p: Pick<Profile, 'ftp' | 'ftpDate' | 'offSeasonWeeks' | 'cycleStart'>, weekStart: string): number | null {
  const off = Math.max(0, Math.min(4, p.offSeasonWeeks ?? 0))
  if (!p.ftp || !off || !p.cycleStart || weekStart < p.cycleStart) return p.ftp ?? null
  const end = new Date(Date.parse(p.cycleStart + 'T12:00:00Z') + off * 7 * 86_400_000).toISOString().slice(0, 10)
  if (p.ftpDate && p.ftpDate >= end) return p.ftp        // izmerjen po premoru
  return Math.round(p.ftp * (1 - OFF_DROP[off]!))
}
