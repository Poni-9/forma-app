import type { Activity, PlanDay, Profile } from '../types'
import { addDays, fmtDur } from './load'
import { stepsFor, totalSec, hasDrills, hardFallback } from './workout'
import { offSeasonNow } from './goalChange'

/**
 * (v3.49) Danes: nasveti po današnjem dnevu (jutranji vnos), »Imam samo X min« (krajše, jedro ostane), pozen dogovor
 * (začne jutri) in prvi trening, ko je prvi dan počitek. Čiste funkcije — zasloni jih samo pokažejo.
 */
const r5 = (x: number) => Math.round(x / 5) * 5
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1)
/** (v3.49) TSS minute lahkega vrtenja (Z2, IF 0,65): 0,65² × 100 / 60 */
const TSS_EASY_PER_MIN = (0.65 * 0.65 * 100) / 60

/**
 * Blaga utrujenost na trd dan (»Po jutranjem vnosu«): nasvet po vrsti treninga. Dolga: spodnja Z2 in krajše za tretjino
 * (prej »naredi pol intervalov« tudi na dan dolge Z2), test: prestavi, ključni: daljše ogrevanje, pol intervalov.
 */
export function mildAdvice(d: Pick<PlanDay, 'kind' | 'durationMin'> & { role?: PlanDay['role'] }, reasons: readonly string[]): string {
  const why = cap(reasons.join(', ') || 'po jutranjem vnosu')
  if (d.kind === 'test' || d.role === 'test') return `${why}: test pri utrujenosti pokaže premalo — raje ga prestavi na svež dan (Spremeni → Premakni na drug dan), danes pa lahko.`
  if (d.role === 'dolga') {
    const short = Math.max(30, r5((d.durationMin || 0) * 2 / 3))
    return `${why}: drži se spodnjega dela Z2 in po potrebi skrajšaj na ~${fmtDur(short)}.${d.kind === 'kolo' ? ' Jej od 30. minute.' : ''}`
  }
  return `${why}: ogrevanje 15–20 min. Če noge ne odprejo, naredi pol intervalov ali samo Z2.`
}

/** Izbire za »Imam samo …«: 20, 30, 45, 60, 90 min — samo krajše od treninga, največ štiri. */
export function shortOptions(d: Pick<PlanDay, 'kind' | 'durationMin' | 'done' | 'role'>): number[] {
  if (d.done || d.kind === 'pocitek' || d.kind === 'test' || d.role === 'test' || d.role === 'dirka') return []
  return [20, 30, 45, 60, 90].filter(m => m <= d.durationMin - 10).slice(-4)
}

/**
 * (v3.50) Izbire, ki jih trening res doseže: vsaka možnost gre skozi `shortenDay`, ostanejo samo različne dosežene
 * minute (Tempo 3 × 10, 75 min: 20, 30 in 45 so vsi dali 50 min → zdaj »50 min · 1 h«). `floor` = najkrajše, kar gre,
 * ko je kakšna želja padla nanj (za vrstico »Krajše od 50 min ne gre«).
 */
export function shortChoices(d: PlanDay, p: Profile): { mins: number[]; floor: number | null } {
  const out: number[] = []
  let floor: number | null = null
  for (const m of shortOptions(d)) {
    const r = shortenDay(d, p, m)
    if (!r) continue
    if (r.min > m) floor = r.min
    if (!out.includes(r.min)) out.push(r.min)
  }
  return { mins: out.sort((a, b) => a - b), floor }
}

/**
 * (v3.50) Gorivo za moč na dan brez vožnje: »Pred« ne sme reči »lahko takoj po kolesu« (besedilo goriva je v energy.ts —
 * tu samo izbira za kartico na Danes in trenerja brez AI). `rideToday` = danes je še kolo ali test.
 */
export function strengthFuel<F extends { before: string }>(f: F | null, d: Pick<PlanDay, 'kind'> | null, rideToday: boolean): F | null {
  if (!f || d?.kind !== 'moc' || rideToday || !/po kolesu/i.test(f.before)) return f
  return { ...f, before: 'Lahek obrok 1–2 h prej (jogurt s sadjem, kruh z jajcem).' }
}

/**
 * (v3.50) Kaj je naslednje po končani vadbi: najprej še neopravljena seja istega dne (po kolesu še moč — prej
 * »Naslednji: torek«, čeprav je danes še moč), sicer prva seja naslednjih dni (kolo pred močjo). `sameDay` pove, da je danes.
 */
export function nextSession<T extends Pick<PlanDay, 'id' | 'date' | 'kind' | 'done' | 'optional'>>(plan: readonly T[], day: Pick<PlanDay, 'id' | 'date'>): { day: T; sameDay: boolean } | null {
  const moc = (d: T) => (d.kind === 'moc' ? 1 : 0)
  const today = plan.filter(d => d.date === day.date && d.id !== day.id && !d.done && !d.optional && d.kind !== 'pocitek').sort((a, b) => moc(a) - moc(b))[0]
  if (today) return { day: today, sameDay: true }
  const later = plan.filter(d => d.date > day.date && d.kind !== 'pocitek').sort((a, b) => a.date.localeCompare(b.date) || moc(a) - moc(b))[0]
  return later ? { day: later, sameDay: false } : null
}

/** Ogrevanje na 10 min in iztek na 5 min, kjer jih opis zapiše daljše (»15 min lahko, nato«, »zadnjih 10 min zelo lahko«). */
function trimWarm(desc: string): string {
  return desc
    .replace(/^(\s*)(\d+)(\s*min\s+(?:lahko|lahkega teka|hitre hoje)\b)/i, (m, a: string, n: string, b: string) => (+n > 10 ? `${a}10${b}` : m))
    .replace(/(\d+)(?:\s*[–-]\s*\d+)?(\s*min\s+ogrevanj)/gi, (m, n: string, b: string) => (+n > 10 ? `10${b}` : m))
    .replace(/(zadnjih\s+)(\d+)(\s*min\s+(?:zelo\s+)?lahko)/gi, (m, a: string, n: string, b: string) => (+n > 5 ? `${a}5${b}` : m))
    .replace(/(\d+)(\s*min\s+(?:iztek|izvoz))/gi, (m, n: string, b: string) => (+n > 5 ? `5${b}` : m))
}
/** Ogrevanje, kot ga zapiše opis (min), ali null. */
function warmIn(desc: string): number | null {
  const m = /(\d+)\s*min ogrevanj/i.exec(desc) ?? /^(\d+)\s*min\s+(?:lahko|lahkega teka|hitre hoje)\b[^.]*?,\s*nato\b/i.exec(desc.trim())
  return m ? +m[1]! : null
}
/** Trajanje v naslovu (»Kolo — lahko 1 h«) na novo dolžino; brez trajanja v naslovu ostane naslov. */
function retitle(title: string, from: number, to: number): string {
  const m = /\s(?:(\d+)\s*h(?:\s*(\d{1,2})\s*min)?|(\d+)\s*min)$/.exec(title)
  if (!m) return title
  const min = m[3] ? +m[3] : +m[1]! * 60 + (m[2] ? +m[2] : 0)
  return Math.abs(min - from) <= 1 ? `${title.slice(0, m.index)} ${fmtDur(to)}` : title
}
/** Ocena trajanja vadbe moči: časovniki vodene vadbe in ~40 s na serijo (min). */
const strengthMin = (d: PlanDay, p: Profile) => { const st = stepsFor(d, p); return (totalSec(st) + st.filter(s => s.kind === 'vaja' && !s.sec).length * 40) / 60 }

/**
 * »Imam samo X min«: krajši trening, jedro ostane. S ponovitvami (ključni, šprinti): ponovitve ostanejo, odpade lahek del,
 * po potrebi ogrevanje 10 min in iztek 5 min — trajanje ni krajše, kot ga ponovitve rabijo. Enakomerno (dolga, lahka):
 * sorazmerno krajše. Moč: vaje po vrsti, manj serij (najmanj 2), po potrebi brez zadnjih vaj (ostanejo vsaj 3).
 * Obremenitev in poraba sorazmerno. Vrne null, če krajše ne gre.
 */
export function shortenDay(d: PlanDay, p: Profile, want: number, now = new Date().toISOString()): { day: PlanDay; min: number } | null {
  const dur = d.durationMin || 0
  if (!shortOptions(d).length || want >= dur) return null
  let desc = d.desc || ''
  let min = Math.max(15, r5(want))
  let exercises = d.exercises
  let kept = false   // (v3.49) ponovitve ostanejo — odpade samo lahek del
  if (d.kind === 'moc') {
    if (!d.exercises?.length) return null
    const tail = d.tail?.durationMin || 0
    const ex = d.exercises.map(e => ({ ...e }))
    const est = () => strengthMin({ ...d, exercises: ex, tail: null }, p) + tail
    // najprej serija manj od zadnje vaje proti prvi, nato brez zadnjih dodatnih vaj
    for (let guard = 0; guard < 40 && est() > min; guard++) {
      const i = [...ex.keys()].reverse().find(k => ex[k]!.sets > 2)
      if (i != null) { ex[i]!.sets--; continue }
      if (ex.length > 3) { ex.pop(); continue }
      break
    }
    exercises = ex
    min = Math.max(min, r5(est()))
  } else {
    // ponovitve iz opisa ali, ko jih ni zapisanih, kot jih vodena vadba sestavi za ključni trening (da ostanejo iste)
    const syn = !hasDrills(desc) && !hasDrills(d.title) && d.role === 'kljucna' ? hardFallback(d, p, dur) : null
    if (syn) desc = syn
    if (syn || hasDrills(desc) || hasDrills(d.title)) {
      kept = true
      const steps = (x: string) => stepsFor({ ...d, desc: x, durationMin: min }, p)
      // vodena vadba sama skrajša ogrevanje, ko ni prostora — opis naj pove isto (»10 min ogrevanje«, ne »20 min«)
      const said = warmIn(desc)
      const wu = steps(desc).find(x => x.kind === 'ogrevanje')?.sec ?? 0
      if (said != null && said > 10 && wu < said * 60) desc = trimWarm(desc)
      min = Math.max(min, Math.ceil(totalSec(steps(desc)) / 60 / 5) * 5)
    }
  }
  if (min >= dur) return null
  const k = min / dur
  // obremenitev: ko ponovitve ostanejo, odpade samo lahko vrtenje (Z2 ≈ 0,65² × 100 / 60 ≈ 0,7 TSS na minuto) — prej
  // sorazmerno s časom (4 × 4 min VO2max 75 → 45 min: 75 → 45 TSS pri istem delu, forma podcenjena ~20 %)
  const tss = d.tssTarget == null ? null : kept ? Math.max(Math.round(d.tssTarget * k), Math.round(d.tssTarget - (dur - min) * TSS_EASY_PER_MIN)) : Math.round(d.tssTarget * k)
  const day: PlanDay = {
    ...d, desc, durationMin: min, title: retitle(d.title, dur, min), updatedAt: now,
    ...(exercises ? { exercises } : {}),
    ...(tss != null ? { tssTarget: tss } : {}),
    ...(d.kcalBurn ? { kcalBurn: Math.round(d.kcalBurn * k) } : {}),
  }
  return { day, min }
}

/**
 * Dogovor pozno (prvi): današnjega treninga ni več mogoče narediti — načrt začne jutri. Navada »zjutraj« po 12. uri,
 * »zvečer« po 21. uri, sicer po 20. uri (prej je načrt ob 21:30 pustil današnji tek, jutri pa »ni bilo«).
 */
export function startsTomorrow(trainTime: Profile['trainTime'], hour: number): boolean {
  return hour >= (trainTime === 'zjutraj' ? 12 : trainTime === 'zvecer' ? 21 : 20)
}

/**
 * Prvi trening načrta, ko danes ni treninga in še nobenega nisi naredil (prvi dan je počitek — Danes pove, kdaj začneš).
 * Null, ko je kakšen trening že za tabo: opravljen dan (tudi po želji), pretekli dan načrta, vadba v zadnjih 60 dneh,
 * dnevi bolezni ali off-season — samo za res novega uporabnika (v3.49: prej tudi po bolezni ali v off-seasonu »začneva …«).
 */
export function firstTraining(plan: readonly PlanDay[], today: string, ctx?: { activities?: readonly Activity[]; profile?: Pick<Profile, 'cycleStart' | 'offSeasonWeeks'> }): PlanDay | null {
  const train = (d: PlanDay) => d.kind !== 'pocitek' && !d.optional
  if (plan.some(d => d.done || d.sickPrev || (train(d) && d.date < today))) return null
  const from = addDays(today, -60)
  if (ctx?.activities?.some(a => a.date >= from && a.date <= today)) return null
  if (ctx?.profile && offSeasonNow(ctx.profile, today)) return null
  return plan.filter(d => train(d) && d.date > today).sort((a, b) => a.date.localeCompare(b.date))[0] ?? null
}
