import type { PlanDay } from '../types'

/**
 * INTENZIVNOST Z BESEDO. Namesto »Z2 · 63 TSS« na Danes: »lahko — še lahko govoriš«. Cona ostane kot pripis
 * (uporabnik z uro jo pozna), TSS je v Planu in Napredku.
 */
export type ZoneKey = 'Z1' | 'Z2' | 'Z3' | 'Z4' | 'Z5'

export const EFFORT: Record<ZoneKey, { w: string; talk: string }> = {
  Z1: { w: 'zelo lahko', talk: 'samo vrtenje nog' },
  Z2: { w: 'lahko', talk: 'še lahko govoriš v celih stavkih' },
  Z3: { w: 'zmerno', talk: 'govoriš v kratkih stavkih' },
  Z4: { w: 'težko', talk: 'rečeš le nekaj besed' },
  Z5: { w: 'zelo težko', talk: 'kratki napori, govoriti ne moreš' },
}

export const isZone = (z: unknown): z is ZoneKey => typeof z === 'string' && /^Z[1-5]$/.test(z)

/** »3 kratki pospeški«, »2 kratka pospeška«, »5 kratkih pospeškov«. */
const surges = (n: number) => (n === 1 ? '1 kratek pospešek' : n === 2 ? '2 kratka pospeška' : n >= 3 && n <= 4 ? `${n} kratki pospeški` : n >= 5 ? `${n} kratkih pospeškov` : 'kratki pospeški')

/**
 * Beseda za seje na kolesu, teku in v hribih (in test): { w: 'lahko', sub: 'Z2', talk } — pri intervalih »intervali« v
 * pripisu, ker je cona samo za težke dele. Moč in počitek: null (tam štejejo vaje ali trajanje).
 * (v3.48) Lahek dan s kratkimi pospeški (predaktivacija pred tekmo) je »lahko«, ne »zelo težko« po coni pospeškov;
 * tek in hribi z isto lestvico kot kolo.
 */
export function effortOf(d: Pick<PlanDay, 'kind' | 'zone' | 'target' | 'role'> & { title?: string }): { w: string; sub: string; talk: string } | null {
  if (d.kind === 'test' || d.role === 'test') return { w: 'test', sub: 'na polno', talk: 'po ogrevanju enakomerno na polno' }
  if ((d.kind !== 'kolo' && d.kind !== 'tek' && d.kind !== 'pohod') || !isZone(d.zone)) return null
  if ((d.role === 'lahka' || d.role === 'regen') && /^Z[345]$/.test(d.zone)) {
    const n = +(/(\d+)\s*×/.exec(d.title || '')?.[1] ?? 0)
    return { w: 'lahko', sub: surges(n), talk: 'lahka vožnja s kratkimi pospeški — ne utruja' }
  }
  const e = EFFORT[d.zone]
  return d.target ? { w: e.w, sub: `${d.zone} · intervali`, talk: `težki deli ${e.talk}, vmes lahko` } : { w: e.w, sub: d.zone, talk: e.talk }
}
