import type { Profile } from '../types'
import { lthrOf } from './load'

export interface Zone { key: string; name: string; lo: number; hi: number }

/** 5 con po utripu: Karvonen (rezerva), če poznamo mirovni utrip, sicer % max. */
export function hrZones5(p: Pick<Profile, 'maxHr' | 'restHr'>): Zone[] | null {
  if (!p.maxHr) return null
  const names = ['Regeneracija', 'Vzdržljivost', 'Tempo', 'Prag', 'VO2max']
  if (p.restHr) {
    const hrr = p.maxHr - p.restHr
    const b = [0.50, 0.60, 0.70, 0.80, 0.90, 1.0]
    return names.map((name, i) => ({ key: `C${i + 1}`, name, lo: Math.round(p.restHr! + b[i]! * hrr), hi: Math.round(p.restHr! + b[i + 1]! * hrr) }))
  }
  const b = [0.60, 0.68, 0.76, 0.84, 0.92, 1.0]
  return names.map((name, i) => ({ key: `C${i + 1}`, name, lo: Math.round(b[i]! * p.maxHr!), hi: Math.round(b[i + 1]! * p.maxHr!) }))
}

/** 7 con po moči (Coggan). */
export function powerZones7(p: Pick<Profile, 'ftp'>): Zone[] | null {
  if (!p.ftp) return null
  const f = p.ftp
  const def: [string, string, number, number][] = [
    ['Z1', 'Aktivni počitek', 0, .55], ['Z2', 'Vzdržljivost', .56, .75], ['Z3', 'Tempo', .76, .90],
    ['Z4', 'Prag', .91, 1.05], ['Z5', 'VO2max', 1.06, 1.20], ['Z6', 'Anaerobno', 1.21, 1.50], ['Z7', 'Sprint', 1.51, 2.5],
  ]
  return def.map(([key, name, lo, hi]) => ({ key, name, lo: Math.round(f * lo), hi: Math.round(f * hi) }))
}

/** Besedilo cone za načrt: »utrip 130–145« ali »190–225 W«. */
export function zoneText(p: Pick<Profile, 'ftp' | 'maxHr' | 'restHr' | 'lthr'>, key: 'Z1' | 'Z2' | 'Z3' | 'Z4' | 'Z5'): string {
  const pz = powerZones7(p)
  if (pz) { const z = pz.find(x => x.key === key); if (z) return `${z.lo}–${z.hi} W` }
  const hz = hrZones5(p)
  const map: Record<string, number> = { Z1: 0, Z2: 1, Z3: 2, Z4: 3, Z5: 4 }
  if (hz) { const z = hz[map[key]!]; if (z) return `utrip ${z.lo}–${z.hi}` }
  const l = lthrOf(p)
  if (l) return `utrip do ${Math.round(l * (key === 'Z2' ? 0.85 : key === 'Z4' ? 1.0 : 0.9))}`
  return { Z1: 'zelo lahko', Z2: 'pogovorni tempo', Z3: 'zmerno', Z4: 'težko, a enakomerno', Z5: 'zelo težko' }[key]
}
