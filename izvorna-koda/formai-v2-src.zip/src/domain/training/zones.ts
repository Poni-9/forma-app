import type { Profile } from '../types'
import { lthrOf } from './load'

export interface Zone { key: string; name: string; lo: number; hi: number }

/** 5 con po utripu: Karvonen (rezerva), če poznamo mirovni utrip, sicer % max. */
export function hrZones5(p: Pick<Profile, 'maxHr' | 'restHr'>): Zone[] | null {
  if (!p.maxHr) return null
  const names = ['Regeneracija', 'Vzdržljivost', 'Tempo', 'Prag', 'VO2max']
  if (p.restHr) {
    const hrr = p.maxHr - p.restHr
    const b = [0.50, 0.60, 0.70, 0.80, 0.90, 1.0]
    return names.map((name, i) => ({ key: `C${i + 1}`, name, lo: Math.round(p.restHr! + b[i]! * hrr), hi: Math.round(p.restHr! + b[i + 1]! * hrr) }))
  }
  const b = [0.60, 0.68, 0.76, 0.84, 0.92, 1.0]
  return names.map((name, i) => ({ key: `C${i + 1}`, name, lo: Math.round(b[i]! * p.maxHr!), hi: Math.round(b[i + 1]! * p.maxHr!) }))
}

/** 7 con po moči (Coggan). */
export function powerZones7(p: Pick<Profile, 'ftp'>): Zone[] | null {
  if (!p.ftp) return null
  const f = p.ftp
  const def: [string, string, number, number][] = [
    ['Z1', 'Aktivni počitek', 0, .55], ['Z2', 'Vzdržljivost', .56, .75], ['Z3', 'Tempo', .76, .90],
    ['Z4', 'Prag', .91, 1.05], ['Z5', 'VO2max', 1.06, 1.20], ['Z6', 'Anaerobno', 1.21, 1.50], ['Z7', 'Sprint', 1.51, 2.5],
  ]
  return def.map(([key, name, lo, hi]) => ({ key, name, lo: Math.round(f * lo), hi: Math.round(f * hi) }))
}

/** Brez merilnika moči (zaznano iz voženj ali nastavljeno): cilji so utrip in občutek, ne vati. */
export function noPower(p: { gear?: { powerMeter?: boolean | null } | null }): boolean { return p.gear?.powerMeter === false }

/**
 * Cone utripa po pražnem utripu (LTHR), enake kot v intervals.icu / Friel:
 * Z1 < 81 %, Z2 81–89 %, Z3 90–93 %, Z4 94–100 %, Z5 > 100 %.
 */
export function lthrZoneText(p: Pick<Profile, 'lthr' | 'maxHr' | 'restHr'>, key: 'Z1' | 'Z2' | 'Z3' | 'Z4' | 'Z5'): string | null {
  const L = lthrOf(p)
  if (!L) return null
  const r = (x: number) => Math.round(L * x)
  // brez lukenj: vsaka cona začne za ena nad zgornjo mejo prejšnje (prej npr. 165 in 172 nista bila v nobeni)
  return { Z1: `utrip pod ${r(0.81)}`, Z2: `utrip ${r(0.81)}–${r(0.89)}`, Z3: `utrip ${r(0.89) + 1}–${r(0.93)}`, Z4: `utrip ${r(0.93) + 1}–${L}`, Z5: `utrip nad ${L} · RPE 9` }[key]
}

/**
 * Cona dela seje s ciljem (target): Z5 in Z4 ostaneta, Z3 je tempo; dan Z2 (ali Z1) s ciljem je vožnja s tempom
 * (»Dolga Z2 + tempo«, »Z2 + 3 × 5 min tempo dirke«) — delo je Z3, ne Z4 (v3.48; prej utrip 172–184 ob opisu 165–171).
 * Tekma in drugo brez cone: Z4 (prag).
 */
export function workZone(zone: string | null | undefined): 'Z3' | 'Z4' | 'Z5' {
  return zone === 'Z5' ? 'Z5' : zone === 'Z3' || zone === 'Z2' || zone === 'Z1' ? 'Z3' : 'Z4'
}

/** Intenzivnost delovnega dela seje za prikaz: vati (z merilnikom) ali utrip in RPE (brez). */
export function workText(p: Pick<Profile, 'ftp' | 'maxHr' | 'restHr' | 'lthr' | 'gear'>, d: { target?: { lo: number; hi: number } | null; zone?: string | null }): string | null {
  if (!d.target) return null
  if (!noPower(p)) return `${d.target.lo}–${d.target.hi} W`
  const z = workZone(d.zone)
  return lthrZoneText(p, z) || { Z3: 'RPE 7', Z4: 'RPE 8', Z5: 'RPE 9' }[z]
}

/**
 * Cona moči v vatih z mejami kot v Napredku (powerZoneRows): Z1 »pod 140 W«, vsaka naslednja začne 1 W nad prejšnjo
 * (v3.48; prej »0–138 W« in luknje 139, 189 W med conami).
 */
export function powerZoneText(ftp: number, key: 'Z1' | 'Z2' | 'Z3' | 'Z4' | 'Z5' | 'Z6' | 'Z7'): string {
  const w = (x: number) => Math.round(ftp * x)
  return {
    Z1: `pod ${w(0.56)}`, Z2: `${w(0.56)}–${w(0.75)}`, Z3: `${w(0.75) + 1}–${w(0.9)}`, Z4: `${w(0.9) + 1}–${w(1.05)}`,
    Z5: `${w(1.05) + 1}–${w(1.2)}`, Z6: `${w(1.2) + 1}–${w(1.5)}`, Z7: `nad ${w(1.5)}`,
  }[key]
}

/** Besedilo cone za načrt: »utrip 130–145« ali »190–225 W«. */
export function zoneText(p: Pick<Profile, 'ftp' | 'maxHr' | 'restHr' | 'lthr'> & { gear?: Profile['gear'] }, key: 'Z1' | 'Z2' | 'Z3' | 'Z4' | 'Z5'): string {
  // brez merilnika ali brez FTP: cone iz pražnega utripa, kot Napredek (hrZoneRows) in tek (runZone) — prej brez FTP
  // po Karvonenu, zato dve različni številki za isto cono (v3.48)
  if (noPower(p) || !p.ftp) { const t = lthrZoneText(p, key); if (t) return t }
  if (p.ftp) return `${powerZoneText(p.ftp, key)} W`
  // ne praga ne max utripa ne FTP: z besedo
  return { Z1: 'zelo lahko', Z2: 'pogovorni tempo', Z3: 'zmerno', Z4: 'težko, a enakomerno', Z5: 'zelo težko' }[key]
}
