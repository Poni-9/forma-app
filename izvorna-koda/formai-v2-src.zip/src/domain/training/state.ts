import type { Activity, DailyCheckin, PlanContent, PlanDay, Profile } from '../types'
import { addDays, estimateTss, fmtDur, weekStartIso } from './load'
import { isHardDay } from './plandays'
import { raceLock, type RaceLock } from './protect'

/**
 * NAČRT POSLUŠA, KAKO SI. Jutranji vnos (mišice, energija, spanec), pripravljenost, včerajšnje jutro, utrujenost (forma)
 * in to, koliko si zadnje dni res naredil, dajo stopnjo:
 *   0 v redu · 1 malo utrujen (samo nasvet) · 2 utrujen (danes lažje) · 3 na dnu (danes brez treninga, jutri lažje).
 * Ko noge zelo bolijo, danes ni kolesa: sprehod (ali počitek). Ključni trening gre na kasnejši primeren dan tega tedna
 * (nikoli ob drug trd dan ali tekmo), sicer ta teden odpade. Vse se shrani v dan (byState.prev) — »Vrni po načrtu« vrne,
 * boljši jutranji vnos samodejno prilagoditev vrne. Brez AI, deterministično.
 */

export type StateMode = 'sprehod' | 'pocitek' | 'vrtenje'
export interface StateRead { level: 0 | 1 | 2 | 3; legs: boolean; reasons: string[] }
export interface StateInput {
  checkin: DailyCheckin | null
  /** pripravljenost 0–100 (forma, jutranji vnos, ura) */
  readiness?: number | null
  /** včerajšnji jutranji vnos */
  yesterday?: DailyCheckin | null
  /** forma (TSB) danes */
  tsb?: number | null
  /** zadnji 3 dnevi: dejanska in načrtovana obremenitev (TSS) */
  load3?: { actual: number; planned: number } | null
  /** lahki treningi zadnjih dni, ocenjeni »težko« ali »do konca« (Kako je šlo?) */
  easyHard?: number
}

const DAY_FROM = ['z nedelje', 's ponedeljka', 's torka', 's srede', 's četrtka', 's petka', 's sobote']
const DAY_ACC = ['nedeljo', 'ponedeljek', 'torek', 'sredo', 'četrtek', 'petek', 'soboto']
const dow = (iso: string) => new Date(iso + 'T12:00:00Z').getUTCDay()
const dayFrom = (iso: string) => DAY_FROM[dow(iso)] ?? ''
const dayAcc = (iso: string) => DAY_ACC[dow(iso)] ?? ''
const tssOf = (min: number, IF: number) => Math.round((min / 60) * IF * IF * 100)

/** Slabo jutro: mišice zelo boleče ali bolijo, ali energija slaba ali na tleh. */
export const badMorning = (c: Pick<DailyCheckin, 'soreness' | 'mood'>): boolean => (c.soreness ?? 0) >= 4 || (c.mood ?? 5) <= 2
/** Koliko slabih juter je bilo v obdobju [from, to]. */
export function badMornings(checkins: readonly DailyCheckin[] | undefined, from: string, to: string): number {
  return (checkins || []).filter(c => c.date >= from && c.date <= to && badMorning(c)).length
}

/** Koliko jutranjih vnosov zapored (do danes) ima »Boli« (mišice 5). Dan brez vnosa prekine niz. */
export function painStreak(checkins: readonly DailyCheckin[] | undefined, today: string): number {
  const by = new Map((checkins || []).map(c => [c.date, c]))
  let n = 0
  for (let d = today; (by.get(d)?.soreness ?? 0) >= 5; d = addDays(d, -1)) n++
  return n
}

/** Stopnja iz jutranjega vnosa in podatkov. Brez vnosa (mišice in energija) ni prilagoditve — ura sama načrta ne spremeni. */
export function readState(i: StateInput): StateRead {
  const c = i.checkin
  const s = c?.soreness ?? null, m = c?.mood ?? null, sl = c?.sleepH ?? null
  const why: string[] = []
  let L = 0
  const up = (n: number) => { L = Math.max(L, n) }
  if (s === 5) { up(3); why.push('noge bolijo') } else if (s === 4) { up(2); why.push('mišice zelo boleče') } else if (s === 3) { up(1); why.push('mišice precej boleče') }
  if (m === 1) { up(3); why.push('energija na tleh') } else if (m === 2) { up(1); why.push('malo energije') }
  if (s != null && m != null && s >= 4 && m <= 2) up(3)
  if (sl != null && sl <= 5) { up(1); why.push('malo spanca') }
  if (s == null && m == null) return { level: 0, legs: false, reasons: [] }
  if (i.readiness != null && i.readiness < 45) { up(2); why.push(`pripravljenost ${i.readiness}`) } else if (i.readiness != null && i.readiness < 60) up(1)
  // ko že nekaj ni prav: dve slabi jutri zapored, visoka utrujenost ali zadnje dni precej več od načrta — stopnja višje
  const bump = (r: string) => { if (L >= 1 && L < 3) { L++; why.push(r) } }
  if (i.yesterday && badMorning(i.yesterday)) bump('že včeraj slabo')
  if (i.tsb != null && i.tsb < -30) bump(`visoka utrujenost (forma ${Math.round(i.tsb)})`)
  const l3 = i.load3
  if (l3 && l3.actual >= l3.planned * 1.4 && l3.actual - l3.planned >= 80) bump(`zadnje 3 dni ${Math.round(l3.actual)} TSS namesto ~${Math.round(l3.planned)}`)
  // občutek po treningih: dva lahka, ki sta bila težka, sta znak utrujenosti — tudi ko je jutro v redu vsaj nasvet (1)
  if ((i.easyHard ?? 0) >= 2) { const r = `lahki treningi so bili težki (${i.easyHard}×)`; if (L === 0) { up(1); why.push(r) } else bump(r) }
  return { level: L as StateRead['level'], legs: s != null && s >= 4, reasons: [...new Set(why)] }
}

/** Načrtovana obremenitev dneva (TSS): počitek in moč 0, sicer cilj dneva ali ocena po coni. */
const planTss = (d: PlanDay) => (d.kind === 'pocitek' || d.kind === 'moc' || d.optional ? 0 : d.tssTarget ?? tssOf(d.durationMin || 0, /Z[45]|test/.test(d.zone || '') ? 0.8 : 0.65))
/** Zadnji trije dnevi (z današnjim): koliko si res naredil proti načrtu (kolo, tek, hoja). */
export function load3(p: Profile, plan: readonly PlanDay[], acts: readonly Activity[], today: string): { actual: number; planned: number } {
  const from = addDays(today, -2)
  const actual = acts.filter(a => a.date >= from && a.date <= today && (a.sport === 'kolo' || a.sport === 'tek' || a.sport === 'pohod')).reduce((t, a) => t + (a.tss && a.tss > 0 ? a.tss : estimateTss(a, p)), 0)
  const planned = plan.filter(d => d.date >= from && d.date < today).reduce((t, d) => t + planTss(d), 0)
  return { actual: Math.round(actual), planned: Math.round(planned) }
}

const contentOf = (d: PlanDay): PlanContent => ({ kind: d.kind, title: d.title, desc: d.desc, durationMin: d.durationMin, zone: d.zone ?? null, tssTarget: d.tssTarget ?? null, role: d.role ?? null, target: d.target ?? null, kcalBurn: d.kcalBurn ?? null, why: d.why ?? null, optional: !!d.optional, ...(d.exercises ? { exercises: d.exercises } : {}), tail: d.tail ?? null })
const prio = (d: PlanDay) => (d.kind === 'pocitek' ? 9 : d.optional ? 5 : d.kind === 'moc' ? 2 : 0)
const mainOn = (plan: readonly PlanDay[], date: string) => [...plan.filter(d => d.date === date)].sort((a, b) => prio(a) - prio(b))[0] ?? null
const isRace = (d: PlanDay) => d.role === 'dirka' || !!d.raceId
const isKey = (d: PlanDay) => d.role === 'kljucna' || d.role === 'test' || d.kind === 'test'

/** Vsebina dneva za način (brez kolesa: sprehod ali počitek; ali zelo lahko vrtenje). */
export function modeContent(mode: StateMode, p: Pick<Profile, 'ftp'>, why: string): PlanContent {
  if (mode === 'sprehod') return { kind: 'pohod', title: 'Sprehod', desc: 'Po želji 20–40 min lahkega sprehoda — kri v noge, brez napora in brez klancev. Če ne gre, počitek. Raztezanje in spanec.', durationMin: 30, zone: 'Z1', tssTarget: 10, role: 'regen', target: null, kcalBurn: null, why, optional: true }
  if (mode === 'pocitek') return { kind: 'pocitek', title: 'Počitek', desc: 'Danes brez treninga: spanec, hrana, tekočina. Telo se obnovi med počitkom.', durationMin: 0, zone: null, tssTarget: 0, role: null, target: null, kcalBurn: null, why, optional: false }
  return { kind: 'kolo', title: 'Lahko vrtenje', desc: `30–40 min zelo lahko (Z1${p.ftp ? `, pod ${Math.round(p.ftp * 0.55)} W` : ''}) — noge samo vrtijo, brez klancev. Če med vožnjo ni bolje, domov.`, durationMin: 35, zone: 'Z1', tssTarget: tssOf(35, 0.5), role: 'regen', target: null, kcalBurn: null, why, optional: true }
}

/** Kam s ključnim treningom: lahek dan kolesa od `from` do konca tedna, brez trdega dne ali tekme ob njem. */
function laterSlot(plan: readonly PlanDay[], src: PlanDay, from: string, skip: ReadonlySet<string>, lock: RaceLock): PlanDay | null {
  const end = addDays(weekStartIso(src.date), 6)
  const hardAt = new Set(plan.filter(d => d.id !== src.id && !d.optional && !skip.has(d.id) && isHardDay(d) && (d.date >= from || d.done)).map(d => d.date))
  return plan.filter(d => d.date >= from && d.date <= end && !d.done && !d.optional && !d.sickPrev && !skip.has(d.id) && d.kind === 'kolo' && (d.role === 'lahka' || d.role === 'regen')
    && !hardAt.has(d.date) && !hardAt.has(addDays(d.date, -1)) && !hardAt.has(addDays(d.date, 1)) && !lock.has(d.date) && !lock.afterRace(d.date))
    .sort((a, b) => a.date.localeCompare(b.date))[0] ?? null
}

export interface StateAdapt { days: PlanDay[]; mode: StateMode; lines: string[] }

/**
 * Prilagoditev za stopnjo ≥ 2 (ali izbran način): danes po načinu (privzeto: noge bolijo → sprehod, na dnu → počitek,
 * sicer lahko vrtenje), moč danes po želji brez nog, ključni/dolgi trening na kasnejši dan; na dnu (3) še jutri lažje.
 * null = ni kaj spremeniti (opravljeno, tekma, počitek, že prilagojeno danes).
 */
export function adaptToState(p: Profile, plan: readonly PlanDay[], today: string, st: StateRead, opts: { mode?: StateMode; now?: string } = {}): StateAdapt | null {
  if (st.level < 2 && !opts.mode) return null
  const now = opts.now ?? new Date().toISOString()
  const auto = !opts.mode
  const main = mainOn(plan, today)
  const reason = st.reasons.length ? st.reasons.join(', ') : 'po tvojem jutranjem vnosu'
  const why = `Prilagojeno počutju (${reason}).`
  const out: PlanDay[] = [], lines: string[] = []
  const used = new Set<string>()
  const lock = raceLock(plan, p)
  const mode: StateMode = opts.mode ?? (st.legs ? 'sprehod' : st.level >= 3 ? 'pocitek' : 'vrtenje')
  const mark = (d: PlanDay, m: NonNullable<PlanDay['byState']>['mode']) => ({ date: today, prev: contentOf(d), auto, mode: m })
  const okToday = !!main && !main.done && !isRace(main) && main.kind !== 'pocitek' && !main.sickPrev && !(auto && main.byState?.date === today)
  if (okToday) {
    const m = main!
    out.push({ ...m, ...modeContent(mode, p, why), exercises: undefined, tail: null, swap: null, updatedAt: now, byState: mark(m, mode) })
    used.add(m.id)
    lines.push(`Danes ${mode === 'sprehod' ? 'sprehod po želji' : mode === 'pocitek' ? 'počitek' : 'samo lahko vrtenje 30–40 min'} namesto: ${m.title}${m.durationMin ? `, ${fmtDur(m.durationMin)}` : ''}.`)
    // ključni ali dolgi trening ne izgine kar tako: kasnejši primeren dan tega tedna (na dnu šele čez 2 dni)
    if (isKey(m) || m.role === 'dolga') {
      // boleče noge ali na dnu: šele čez 2 dni (mišice rabijo 48–72 h), sicer že jutri
      const slot = laterSlot(plan, m, addDays(today, st.level >= 3 || st.legs ? 2 : 1), used, lock)
      if (slot) {
        out.push({ ...slot, ...contentOf(m), why: `Prestavljeno ${dayFrom(today)} — ${reason}.`, updatedAt: now, byState: mark(slot, 'premik') })
        used.add(slot.id)
        lines.push(`${m.title} gre na ${dayAcc(slot.date)}.`)
      } else lines.push(`${m.title} ta teden odpade — bolje en trening manj kot teden v luknji. Naslednji pride po načrtu.`)
    }
  }
  // moč danes: noge počivajo — samo jedro po želji
  for (const x of plan.filter(d => d.date === today && d.kind === 'moc' && !d.done && !d.optional && (!main || d.id !== main.id))) {
    if (!(st.legs || st.level >= 3) || (auto && x.byState?.date === today)) continue
    out.push({ ...x, optional: true, desc: `Noge počivajo — po želji samo jedro (deska, mrtvi hrošč, ptič-pes), brez počepov in izpadnih korakov. ${x.desc}`.trim(), updatedAt: now, byState: mark(x, 'moc') })
    lines.push('Moč danes po želji — samo jedro, brez nog.')
  }
  // na dnu: tudi jutri lažje (trd dan postane lahko vrtenje; ključni gre še kasneje)
  if (st.level >= 3) {
    const tm = mainOn(plan, addDays(today, 1))
    if (tm && !tm.done && !isRace(tm) && !tm.sickPrev && !used.has(tm.id) && isHardDay(tm) && !(auto && tm.byState?.date === today)) {
      out.push({ ...tm, ...modeContent('vrtenje', p, `Jutri lažje — danes si bil na dnu (${reason}).`), optional: false, exercises: undefined, tail: null, swap: null, updatedAt: now, byState: { date: today, prev: contentOf(tm), auto, mode: 'lazje' } })
      used.add(tm.id)
      const slot = isKey(tm) || tm.role === 'dolga' ? laterSlot(plan, tm, addDays(today, 3), used, lock) : null
      if (slot) {
        out.push({ ...slot, ...contentOf(tm), why: `Prestavljeno ${dayFrom(tm.date)} — po slabem dnevu najprej obnova.`, updatedAt: now, byState: mark(slot, 'premik') })
        used.add(slot.id)
        lines.push(`Jutri lahko vrtenje; ${tm.title} gre na ${dayAcc(slot.date)}.`)
      } else lines.push(`Jutri lahko vrtenje namesto: ${tm.title}.`)
    }
  }
  return out.length ? { days: out, mode, lines } : null
}

/** »Vrni po načrtu«: dnevi, prilagojeni po današnjem vnosu, dobijo nazaj prvotno vsebino; off = danes ne prilagodi znova. */
export function undoState(plan: readonly PlanDay[], date: string, opts: { keepOff?: boolean; now?: string } = {}): PlanDay[] {
  const now = opts.now ?? new Date().toISOString()
  const keepOff = opts.keepOff ?? true
  return plan.filter(d => d.byState?.date === date && !d.byState.off && d.byState.prev && !d.done)
    .map(d => ({ ...d, ...d.byState!.prev!, updatedAt: now, byState: keepOff ? { date, off: true } : null }))
}

/** Prilagoditev danes za prikaz: kaj je danes, kaj je šlo kam, kaj je jutri. */
export function stateNow(plan: readonly PlanDay[], today: string): { mode: StateMode | null; lines: string[]; auto: boolean } | null {
  const act = plan.filter(d => d.byState?.date === today && !d.byState.off && d.byState.prev)
  if (!act.length) return null
  const lines: string[] = []
  let mode: StateMode | null = null
  const t = act.find(d => d.date === today && (d.byState!.mode === 'sprehod' || d.byState!.mode === 'pocitek' || d.byState!.mode === 'vrtenje'))
  if (t) { mode = t.byState!.mode as StateMode; lines.push(`Danes ${mode === 'sprehod' ? 'sprehod po želji' : mode === 'pocitek' ? 'počitek' : 'samo lahko vrtenje'} namesto: ${t.byState!.prev!.title}.`) }
  for (const d of act.filter(x => x.byState!.mode === 'premik').sort((a, b) => a.date.localeCompare(b.date))) lines.push(`${d.title} gre na ${dayAcc(d.date)}.`)
  const tm = act.find(d => d.byState!.mode === 'lazje')
  if (tm) lines.push(`Jutri lahko vrtenje namesto: ${tm.byState!.prev!.title}.`)
  if (act.some(d => d.byState!.mode === 'moc')) lines.push('Moč danes po želji — samo jedro, brez nog.')
  const key = t?.byState?.prev && (t.byState.prev.role === 'kljucna' || t.byState.prev.role === 'test' || t.byState.prev.role === 'dolga' || t.byState.prev.kind === 'test')
  if (key && !act.some(d => d.byState!.mode === 'premik' && d.title === t!.byState!.prev!.title)) lines.push(`${t!.byState!.prev!.title} ta teden odpade.`)
  return { mode, lines, auto: act.every(d => d.byState!.auto) }
}
