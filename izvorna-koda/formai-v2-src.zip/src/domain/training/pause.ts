import type { PlanDay, Profile } from '../types'
import { addDays, weekStartIso } from './load'
import { isHardDay } from './plandays'
import type { RaceLock } from './protect'

/**
 * (v3.50) »TA TEDEN …« — premor po tvoji izbiri (Blaž: »rekel sem, da ta teden nočem nič, pa ni nič upoštevalo«).
 * Od danes do nedelje (ali še naslednji teden, največ 14 dni): brez treningov ali brez kolesa (moč, tek, hoja ostanejo).
 * Neopravljeni treningi v tem času odpadejo (shrani se v profil, sinhronizira kot ostalo); nov ali znova sestavljen
 * teden v tem času dobi isto (buildWeek → pauseBuilt), samodejni premiki vanj ne gredo (pauseLock).
 * Tedni premora za ure iz resnice ne štejejo kot dolg premor (pauseWeeks); po 8+ dneh je prehod lažji.
 */
export type PauseMode = 'vse' | 'kolo'
export type PauseReason = 'bolan' | 'potovanje' | 'volja' | 'drugo'
export interface WeekPause { from: string; to: string; mode: PauseMode; reason?: PauseReason | null; at?: string }

export const PAUSE_MAX_DAYS = 14
export const PAUSE_TITLE = 'Premor'
export const PAUSE_TITLE_KOLO = 'Premor — brez kolesa'
export const PAUSE_DESC = 'Brez treningov — premor po tvoji izbiri. Po želji sprehod ali raztezanje; ne šteje kot kršitev.'
export const PAUSE_DESC_KOLO = 'Brez kolesa — premor po tvoji izbiri. Po želji sprehod, tek ali moč; ne šteje kot kršitev.'
export const REASONS: { k: PauseReason; t: string }[] = [{ k: 'bolan', t: 'bolan' }, { k: 'potovanje', t: 'potovanje' }, { k: 'volja', t: 'brez volje' }, { k: 'drugo', t: 'drugo' }]
/** prvi dva dneva po dolgem premoru (8+ dni) */
export const BACK_TITLE_PAUSE = 'Lahka Z2 po premoru'

const DAY = 86_400_000
const days = (a: string, b: string) => Math.round((Date.parse(b + 'T12:00:00Z') - Date.parse(a + 'T12:00:00Z')) / DAY)
const dmOf = (iso: string) => `${+iso.slice(8, 10)}. ${+iso.slice(5, 7)}.`

/** Obdobje od danes do nedelje (ali do nedelje naslednjega tedna), največ 14 dni. */
export function pausePeriod(today: string, mode: PauseMode, o: { twoWeeks?: boolean; reason?: PauseReason | null } = {}): WeekPause {
  const sun = addDays(weekStartIso(today), 6)
  const to0 = o.twoWeeks ? addDays(sun, 7) : sun
  const to = days(today, to0) + 1 > PAUSE_MAX_DAYS ? addDays(today, PAUSE_MAX_DAYS - 1) : to0
  return { from: today, to, mode, ...(o.reason ? { reason: o.reason } : {}) }
}

/** Premor, ki velja danes (null, ko ga ni ali je mimo). */
export function activePause(p: Pick<Profile, 'weekPause'>, today: string): WeekPause | null {
  const w = p.weekPause
  return w && w.from <= today && w.to >= today ? w : null
}
/** Ali je dan v premoru (tudi pretekli dan premora). */
export function inPause(p: Pick<Profile, 'weekPause'>, date: string): boolean {
  const w = p.weekPause
  return !!w && date >= w.from && date <= w.to
}
/** Dolžina premora v dneh (vključno). */
export const pauseDays = (w: Pick<WeekPause, 'from' | 'to'>): number => days(w.from, w.to) + 1
/** (v3.50) »Po dveh tednih premora« samo pri 14 dneh, sicer »Po 8 dneh premora« (prej vedno »dveh tednih«, tudi pri 8 dneh). */
export const pauseAfter = (w: Pick<WeekPause, 'from' | 'to'>): string => { const n = pauseDays(w); return n >= 14 ? 'Po dveh tednih premora' : `Po ${n} dneh premora` }

/** Kaj premor vzame: brez treningov vse (tudi po želji), brez kolesa vožnje in teste. */
const hits = (d: PlanDay, mode: PauseMode) => (mode === 'vse' ? d.kind !== 'pocitek' : d.kind === 'kolo' || d.kind === 'test')
const protectedDay = (d: PlanDay) => !!d.done || !!d.raceId || d.role === 'dirka'
/** moč s kolesom na koncu (»tek v istem dnevu«): brez kolesa ostane samo moč */
function noBikeTail(d: PlanDay, now: string): PlanDay {
  if (d.tail?.kind !== 'kolo') return d
  const min = Math.max(0, (d.durationMin || 0) - (d.tail.durationMin || 0))
  return {
    ...d, tail: null, durationMin: min, updatedAt: now,
    title: d.title.replace(/\s*\+\s*kolo\s+\d+\s*min$/i, ''),
    desc: d.desc.replace(/\s*Nato [^.]*\.\s*$/, ''),
    tssTarget: d.tssTarget != null && d.durationMin ? Math.round((d.tssTarget * min) / d.durationMin) : d.tssTarget,
  }
}
function restOf(first: PlanDay, mode: PauseMode, now: string): PlanDay {
  return {
    id: first.id, date: first.date, kind: 'pocitek', title: mode === 'kolo' ? PAUSE_TITLE_KOLO : PAUSE_TITLE, desc: mode === 'kolo' ? PAUSE_DESC_KOLO : PAUSE_DESC,
    durationMin: 0, zone: null, tssTarget: 0, role: null, why: null, source: first.source, createdAt: first.createdAt, updatedAt: now, done: null,
  }
}
/** Zapisi enega dne v premoru: null = dan ostane, kot je; sicer vsi zapisi dneva (za zamenjavo neopravljenih). */
function pauseDate(all: readonly PlanDay[], mode: PauseMode, now: string): PlanDay[] | null {
  if (!all.length || all.some(d => d.sickPrev)) return null
  const hit = all.filter(d => !protectedDay(d) && hits(d, mode))
  const tail = mode === 'kolo' ? all.filter(d => !protectedDay(d) && !hits(d, mode) && d.tail?.kind === 'kolo') : []
  if (!hit.length && !tail.length) return null
  const keep = all.filter(d => !hit.includes(d)).map(d => (tail.includes(d) ? noBikeTail(d, now) : d)).filter(d => d.done || d.kind !== 'pocitek')
  return keep.length ? keep : [restOf(hit[0]!, mode, now)]
}

/** (v3.50) Zakaj pri treningu s slike (fromPhoto) — po njem ponovna sestava prepozna zapis, ki ga je dodal uporabnik. */
export const PHOTO_WHY = 'Trening s tvoje slike.'
/** jedro po želji in predlog s slike sebe */
const OWN_DESC = /Po želji — ne šteje v realizacijo tedna\.\s*$/
/** Ključ za primerjavo s sestavo: vrsta + naslov brez številk (»VO2max 5 × 4 min« = »VO2max 4 × 4 min«). */
export const planKey = (d: Pick<PlanDay, 'kind' | 'title'>): string => `${d.kind}|${(d.title || '').replace(/\d+(?:[.,]\d+)?/g, '#')}`
/**
 * (v3.50) Ali je neopravljen zapis dodal uporabnik sam (»Dodaj trening«, trening s slike, jedro po želji) — ponovna sestava
 * dni (sprememba ali preklic premora, teden po njem) ga ne pobriše. `old` = profil pred spremembo, `ref` = ključi (planKey)
 * zapisov, ki bi jih planer s profilom `old` sestavil za ta teden. Prilagoditve načrta (počutje, pretežka vožnja, zamenjava,
 * »po želji« iz načrta) niso lastni zapisi.
 */
export function ownDay(d: PlanDay, old: Pick<Profile, 'weekPause'>, ref: ReadonlySet<string>): boolean {
  if (protectedDay(d) || d.kind === 'pocitek' || d.sickPrev || d.byState || d.adapt || d.swap) return false
  if (d.why === PHOTO_WHY || OWN_DESC.test(d.desc || '')) return true
  if (d.optional) return false
  // na dnevu premora trening, ki bi ga premor umaknil: dodan po začetku premora
  const w = old.weekPause
  if (w && d.date >= w.from && d.date <= w.to && hits(d, w.mode)) return true
  return d.source === 'rules' && !ref.has(planKey(d))
}
/** (v3.50) Nova sestava dni + lastni zapisi: lastni ostanejo, na njihovem dnevu odpadeta počitek in sestavljen zapis iste vrste. */
export function withOwn(built: readonly PlanDay[], own: readonly PlanDay[]): PlanDay[] {
  if (!own.length) return [...built]
  return [...built.filter(b => !own.some(o => o.date === b.date && (b.kind === 'pocitek' || o.kind === b.kind))), ...own]
}

/**
 * Shranjeni dnevi od danes do konca premora → zapisi za savePlanDays (ti na teh datumih zamenjajo neopravljene).
 * Opravljeno, tekme in dnevi bolezni ostanejo; dnevi, ki se ne spremenijo, niso v izidu.
 */
export function pauseify(plan: readonly PlanDay[], w: WeekPause, today: string, now: string): PlanDay[] {
  const out: PlanDay[] = []
  const from = w.from > today ? w.from : today
  for (let date = from; date <= w.to; date = addDays(date, 1)) {
    const r = pauseDate(plan.filter(d => d.date === date), w.mode, now)
    if (r) out.push(...r)
  }
  return out
}

/**
 * Na novo sestavljen teden (buildWeek, »Sestavi znova«, ensureWeeks): dnevi premora brez treningov oz. brez kolesa;
 * po 8+ dneh premora sta prva dva dneva nazaj lahka (trd trening na kolesu → Z2 do 60 min), kot po bolezni.
 */
export function pauseBuilt(list: PlanDay[], p: Pick<Profile, 'weekPause'>, now: string): PlanDay[] {
  const w = p.weekPause
  if (!w?.from || !w.to) return list
  const dates = [...new Set(list.map(d => d.date))]
  const out: PlanDay[] = []
  const long = pauseDays(w) >= 8, until = addDays(w.to, 2)
  for (const date of dates) {
    const all = list.filter(d => d.date === date)
    if (date >= w.from && date <= w.to) { out.push(...(pauseDate(all, w.mode, now) ?? all)); continue }
    // (v3.50) tudi trd tek (intervali, dolgi tek) — prej samo kolo, list pa je vsem obljubil »prva dva dneva lažja«
    if (long && date > w.to && date <= until) { out.push(...all.map(d => !d.optional && !d.raceId && d.role !== 'dirka' && isHardDay(d) ? (d.kind === 'kolo' || d.kind === 'test' ? easeBack(d, w) : d.kind === 'tek' ? easeRun(d, w) : d) : d)); continue }
    out.push(...all)
  }
  return out
}
function easeBack(d: PlanDay, w: WeekPause): PlanDay {
  const min = Math.min(60, Math.max(30, d.durationMin || 60))
  return {
    ...d, kind: 'kolo', title: BACK_TITLE_PAUSE, desc: 'Prva dva dneva po premoru lahko: Z2, kadenca 90+, največ 60 min. Intervali pridejo potem.',
    durationMin: min, zone: 'Z2', tssTarget: Math.round(min * 0.7), role: 'lahka', target: null, kcalBurn: null, exercises: undefined, tail: null,
    why: `${pauseAfter(w)} prva dva dneva lahko — telo se navadi nazaj, nato po načrtu.`,
  }
}
/** (v3.50) prvi dva dneva po dolgem premoru: trd tek → lahek tek */
export const BACK_TITLE_RUN = 'Lahek tek po premoru'
function easeRun(d: PlanDay, w: WeekPause): PlanDay {
  const min = Math.min(40, Math.max(20, d.durationMin || 40))
  return {
    ...d, title: BACK_TITLE_RUN, desc: 'Prva dva dneva po premoru lahko: pogovorni tempo (Z2), največ 40 min. Hitri deli pridejo potem.',
    durationMin: min, zone: 'Z2', tssTarget: Math.round(min * 0.75), role: 'lahka', target: null, kcalBurn: null, tail: null,
    why: `${pauseAfter(w)} prva dva dneva lahko — telo se navadi nazaj, nato po načrtu.`,
  }
}

/** Ponedeljki tednov, ki jih premor zajame — za ure iz resnice ne štejejo (namenski premor ni »dolg premor«). */
export function pauseWeeks(p: Pick<Profile, 'weekPause'>): Set<string> {
  const w = p.weekPause, out = new Set<string>()
  if (!w?.from || !w.to || w.to < w.from) return out
  for (let ws = weekStartIso(w.from); ws <= w.to; ws = addDays(ws, 7)) out.add(ws)
  return out
}
/**
 * Teden takoj po premoru (tudi teden, v katerem je bil premor preklican sredi tedna): ponedeljek prvega tedna premora
 * in ali je bil premor dolg (8+ dni). null, če teden ni prvi po premoru.
 */
export function pauseBefore(p: Pick<Profile, 'weekPause'>, weekStart: string): { first: string; long: boolean } | null {
  const w = p.weekPause
  if (!w?.from || !w.to || weekStartIso(addDays(w.to, 1)) !== weekStart) return null
  return { first: weekStartIso(w.from), long: pauseDays(w) >= 8 }
}

/** Samodejni premiki (zamujen ključni, olajšaj dan, po pretežki vožnji, počutje) ne gredo na dan premora. */
export function pauseLock(lock: RaceLock, p: Pick<Profile, 'weekPause'>): RaceLock {
  if (!p.weekPause) return lock
  return { has: d => lock.has(d) || inPause(p, d), why: d => lock.why(d) ?? (inPause(p, d) ? 'premor' : null), afterRace: d => lock.afterRace(d) }
}

/** »do nedelje«, »danes«, »do nedelje, 1. 11.« (dva tedna) */
export function pauseUntil(w: Pick<WeekPause, 'to'>, today: string): string {
  if (w.to === today) return 'danes'
  return w.to === addDays(weekStartIso(today), 6) ? 'do nedelje' : `do ${new Date(w.to + 'T12:00:00Z').getUTCDay() === 0 ? 'nedelje, ' : ''}${dmOf(w.to)}`
}
/** »Ta teden: premor do nedelje (brez kolesa)« — za Danes, Plan in trenerja. */
export function pauseLine(w: WeekPause, today: string): string {
  const u = pauseUntil(w, today)
  return `${u === 'danes' ? 'Danes' : 'Ta teden'}: premor${u === 'danes' ? '' : ` ${u}`}${w.mode === 'kolo' ? ' (brez kolesa)' : ''}`
}
/** Vrstica za AI kontekst (brez razloga »bolan« — zdravje ne gre v AI). */
export function pauseAiLine(w: WeekPause, today: string): string | null {
  if (w.to < today) return null
  const why = w.reason && w.reason !== 'bolan' ? ` (razlog: ${REASONS.find(r => r.k === w.reason)?.t ?? w.reason})` : ''
  return `PREMOR po uporabnikovi izbiri od ${w.from} do vključno ${w.to}: ${w.mode === 'kolo' ? 'brez kolesa (moč, tek in hoja ostanejo)' : 'brez treningov'}${why}. V teh dneh ne predlagaj ${w.mode === 'kolo' ? 'voženj' : 'treningov'} in ne priganjaj; vadba po želji je v redu in ni kršitev. Po premoru se načrt nadaljuje brez skoka v obsegu.`
}

/* ---------- prepoznava v klepetu s trenerjem (na napravi, brez AI) ---------- */
const fold = (s: string) => s.toLowerCase().replace(/[čć]/g, 'c').replace(/š/g, 's').replace(/ž/g, 'z').replace(/đ/g, 'd').replace(/[^\p{L}\p{N}?!.,\s]/gu, ' ').replace(/\s+/g, ' ').trim()
const SCOPE = /\b(ta|cel|celi|ves) +ted(e)?n\b|\btega tedna\b|\bdo nedelje\b|\bta in naslednji teden\b/
const QUESTION = /^(ali|a|al|naj|kaj|kako|zakaj|koliko|kdaj|bi|lahko|je|ce|mi|si)\b/
// nikalnica počitka (»nočem počivati«, »ne bom počival«, »brez počitka«) in več treninga (»hočem več«, »bom več kolesaril«)
const NO_REST = /\b(nocem|ne zelim|ne bom|ne rabim|ne potrebujem|ne grem|brez)\s+(\w+\s+){0,2}(pociv\w*|pocitk\w*|premor\w*|pavz\w*|odmor\w*)/
const MORE = /(?<!\bne )\b(hocem|zelim|bom|bi|dodaj|daj)\s+(\w+\s+){0,2}vec\b/
const POS = [
  // nikalnica dejanja: »ta teden nočem nič«, »ne bom treniral«, »ne bom nič na kolesu«, »ne grem na kolo«
  /\b(nocem|ne zelim|ne bom|ne morem|ne grem|ne bi|ne mislim|ne nameravam)\s+(\w+\s+){0,3}(nic|vec|trenir\w*|trening\w*|vadi\w*|vadb\w*|telovad\w*|kolesar\w*|kolo|kolesu|kolesa|vozi\w*|vozil\w*)\b/,
  /\bnic\s+(ne bom|nocem|ne grem|ne bo)\b/,
  /\bbrez\s+(treningov|treninga|vadbe|vadb|kolesa|kolesarjenja|voznje|vozenj)\b/,
  // počitek kot odločitev (ne poročilo o preteklem: »sem počival« ne šteje)
  /\bpocivam\b|\b(bom|bi|grem)\s+(\w+\s+){0,3}pociva\w*|\b(vzamem|rabim|potrebujem|imam)\s+(\w+\s+){0,2}(premor|pavzo|pavza|odmor|pocitek)\b|\b(ta teden|do nedelje)\s+(je |bo )?(premor|pavza|odmor)\b/,
  /\b(preskoci|preskocim|preskocimo|izpusti|izpustim|izpustimo)\b/,
]
const BIKE = /\b(kolo|kolesa|kolesu|kolesom|kolesar\w*|vozil\w*|voznj\w*|vozenj\w*|vozit\w*|vozim)\b/
const GENERIC = /\b(trenir\w*|trening\w*|vadb\w*|vadi\w*|telovad\w*)\b/

/**
 * Ali uporabnik v klepetu pove, da ta teden ne bo treniral (ali kolesaril): »ta teden nočem nič«, »ta teden brez kolesa«,
 * »ne bom kolesaril ta teden«, »preskoči ta teden«. Vprašanje za nasvet (»Ali naj ta teden počivam?«), nikalnica počitka
 * (»nočem počivati«), več treninga in drugi tedni niso premor. Kolo, ko gre samo za kolo (brez »trening«, »vadba«).
 */
export function pauseIntent(text: string): { mode: PauseMode; twoWeeks: boolean } | null {
  const t = fold(text || '')
  if (!t || t.length > 400 || !SCOPE.test(t)) return null
  if (t.includes('?') && QUESTION.test(t)) return null
  if (NO_REST.test(t) || MORE.test(t)) return null
  if (!POS.some(r => r.test(t))) return null
  const mode: PauseMode = BIKE.test(t) && !GENERIC.test(t) ? 'kolo' : 'vse'
  return { mode, twoWeeks: /\bnaslednji\b/.test(t) }
}
