import type { PlanDay, Profile } from '../types'
import { addDays, weekStartIso } from './load'
import { isHardDay } from './plandays'
import type { RaceLock } from './protect'

/**
 * (v3.50) »TA TEDEN …« — premor po tvoji izbiri (Blaž: »rekel sem, da ta teden nočem nič, pa ni nič upoštevalo«).
 * Od danes do nedelje (ali še naslednji teden, največ 14 dni): brez treningov ali brez kolesa (moč, tek, hoja ostanejo).
 * Neopravljeni treningi v tem času odpadejo (shrani se v profil, sinhronizira kot ostalo); nov ali znova sestavljen
 * teden v tem času dobi isto (buildWeek → pauseBuilt), samodejni premiki vanj ne gredo (pauseLock).
 * Tedni premora za ure iz resnice ne štejejo kot dolg premor (pauseWeeks); po 8+ dneh je prehod lažji.
 */
export type PauseMode = 'vse' | 'kolo'
export type PauseReason = 'bolan' | 'potovanje' | 'volja' | 'drugo'
export interface WeekPause {
  from: string; to: string; mode: PauseMode; reason?: PauseReason | null; at?: string
  /** (v3.51) začetek prvega dela, ko je premor podaljšan čez 14 dni (nov del teče od dneva podaljšanja) — za ure in prehod po premoru */
  since?: string | null
}

export const PAUSE_MAX_DAYS = 14
export const PAUSE_TITLE = 'Premor'
export const PAUSE_TITLE_KOLO = 'Premor — brez kolesa'
export const PAUSE_DESC = 'Brez treningov — premor po tvoji izbiri. Po želji sprehod ali raztezanje; ne šteje kot kršitev.'
export const PAUSE_DESC_KOLO = 'Brez kolesa — premor po tvoji izbiri. Po želji sprehod, tek ali moč; ne šteje kot kršitev.'
export const REASONS: { k: PauseReason; t: string }[] = [{ k: 'bolan', t: 'bolan' }, { k: 'potovanje', t: 'potovanje' }, { k: 'volja', t: 'brez volje' }, { k: 'drugo', t: 'drugo' }]
/** prvi dva dneva po dolgem premoru (8+ dni) */
export const BACK_TITLE_PAUSE = 'Lahka Z2 po premoru'

const DAY = 86_400_000
const days = (a: string, b: string) => Math.round((Date.parse(b + 'T12:00:00Z') - Date.parse(a + 'T12:00:00Z')) / DAY)
const dmOf = (iso: string) => `${+iso.slice(8, 10)}. ${+iso.slice(5, 7)}.`

/** Obdobje od danes do nedelje (ali do nedelje naslednjega tedna), največ 14 dni. */
export function pausePeriod(today: string, mode: PauseMode, o: { twoWeeks?: boolean; reason?: PauseReason | null } = {}): WeekPause {
  const sun = addDays(weekStartIso(today), 6)
  const to0 = o.twoWeeks ? addDays(sun, 7) : sun
  const to = days(today, to0) + 1 > PAUSE_MAX_DAYS ? addDays(today, PAUSE_MAX_DAYS - 1) : to0
  return { from: today, to, mode, ...(o.reason ? { reason: o.reason } : {}) }
}

/** Premor, ki velja danes (null, ko ga ni ali je mimo). */
export function activePause(p: Pick<Profile, 'weekPause'>, today: string): WeekPause | null {
  const w = p.weekPause
  return w && w.from <= today && w.to >= today ? w : null
}
/** Ali je dan v premoru (tudi pretekli dan premora). */
export function inPause(p: Pick<Profile, 'weekPause'>, date: string): boolean {
  const w = p.weekPause
  return !!w && date >= w.from && date <= w.to
}
/** (v3.51) Prvi dan premora, tudi prvega dela pred podaljšanjem. */
export const pauseStart = (w: Pick<WeekPause, 'from' | 'since'>): string => (w.since && w.since < w.from ? w.since : w.from)
/** Dolžina premora v dneh (vključno; (v3.51) s prvim delom pred podaljšanjem). */
export const pauseDays = (w: Pick<WeekPause, 'from' | 'to' | 'since'>): number => days(pauseStart(w), w.to) + 1
/** (v3.50) »Po dveh tednih premora« samo pri 14 dneh, sicer »Po 8 dneh premora« (prej vedno »dveh tednih«, tudi pri 8 dneh). */
export const pauseAfter = (w: Pick<WeekPause, 'from' | 'to' | 'since'>): string => { const n = pauseDays(w); return n >= 14 ? 'Po dveh tednih premora' : `Po ${n} dneh premora` }

/** Kaj premor vzame: brez treningov vse (tudi po želji), brez kolesa vožnje in teste. */
const hits = (d: PlanDay, mode: PauseMode) => (mode === 'vse' ? d.kind !== 'pocitek' : d.kind === 'kolo' || d.kind === 'test')
const protectedDay = (d: PlanDay) => !!d.done || !!d.raceId || d.role === 'dirka'
/** moč s kolesom na koncu (»tek v istem dnevu«): brez kolesa ostane samo moč */
function noBikeTail(d: PlanDay, now: string): PlanDay {
  if (d.tail?.kind !== 'kolo') return d
  const min = Math.max(0, (d.durationMin || 0) - (d.tail.durationMin || 0))
  return {
    ...d, tail: null, durationMin: min, updatedAt: now,
    title: d.title.replace(/\s*\+\s*kolo\s+\d+\s*min$/i, ''),
    desc: d.desc.replace(/\s*Nato [^.]*\.\s*$/, ''),
    tssTarget: d.tssTarget != null && d.durationMin ? Math.round((d.tssTarget * min) / d.durationMin) : d.tssTarget,
  }
}
function restOf(first: PlanDay, mode: PauseMode, now: string): PlanDay {
  return {
    id: first.id, date: first.date, kind: 'pocitek', title: mode === 'kolo' ? PAUSE_TITLE_KOLO : PAUSE_TITLE, desc: mode === 'kolo' ? PAUSE_DESC_KOLO : PAUSE_DESC,
    durationMin: 0, zone: null, tssTarget: 0, role: null, why: null, source: first.source, createdAt: first.createdAt, updatedAt: now, done: null,
  }
}
/** Zapisi enega dne v premoru: null = dan ostane, kot je; sicer vsi zapisi dneva (za zamenjavo neopravljenih). */
/**
 * (v3.51) Tekma, ki ostane v premoru, obdrži predaktivacijo dan prej (prej je odpadla, tekma pa ostala). `races` = datumi
 * tekem (neopravljenih), ki jih vidi sestava.
 */
const OPENERS = /^Predaktivacija\b/
const racesIn = (list: readonly PlanDay[]) => new Set(list.filter(d => !d.done && (!!d.raceId || d.role === 'dirka')).map(d => d.date))
const openerKept = (d: PlanDay, races: ReadonlySet<string>) => OPENERS.test(d.title || '') && races.has(addDays(d.date, 1))
function pauseDate(all: readonly PlanDay[], mode: PauseMode, now: string, races: ReadonlySet<string> = new Set()): PlanDay[] | null {
  if (!all.length || all.some(d => d.sickPrev)) return null
  const hit = all.filter(d => !protectedDay(d) && !openerKept(d, races) && hits(d, mode))
  const tail = mode === 'kolo' ? all.filter(d => !protectedDay(d) && !openerKept(d, races) && !hits(d, mode) && d.tail?.kind === 'kolo') : []
  if (!hit.length && !tail.length) return null
  const keep = all.filter(d => !hit.includes(d)).map(d => (tail.includes(d) ? noBikeTail(d, now) : d)).filter(d => d.done || d.kind !== 'pocitek')
  return keep.length ? keep : [restOf(hit[0]!, mode, now)]
}

/** (v3.50) Zakaj pri treningu s slike (fromPhoto) — po njem ponovna sestava prepozna zapis, ki ga je dodal uporabnik. */
export const PHOTO_WHY = 'Trening s tvoje slike.'
/** (v3.51) Zakaj pri treningu, ki si ga dodal sam (»Dodaj trening«) — ponovna sestava ga prepozna tudi z naslovom iz načrta. */
export const OWN_WHY = 'Tvoj dodan trening.'
/** jedro po želji in predlog s slike sebe */
const OWN_DESC = /Po želji — ne šteje v realizacijo tedna\.\s*$/
/** Ključ za primerjavo s sestavo: vrsta + naslov brez številk (»VO2max 5 × 4 min« = »VO2max 4 × 4 min«). */
export const planKey = (d: Pick<PlanDay, 'kind' | 'title'>): string => `${d.kind}|${(d.title || '').replace(/\d+(?:[.,]\d+)?/g, '#')}`
/**
 * (v3.50) Ali je neopravljen zapis dodal uporabnik sam (»Dodaj trening«, trening s slike, jedro po želji) — ponovna sestava
 * dni (sprememba ali preklic premora, teden po njem) ga ne pobriše. `old` = profil pred spremembo, `ref` = ključi (planKey)
 * zapisov, ki bi jih planer s profilom `old` sestavil za ta teden. Prilagoditve načrta (počutje, pretežka vožnja, zamenjava,
 * »po želji« iz načrta) niso lastni zapisi.
 */
export function ownDay(d: PlanDay, old: Pick<Profile, 'weekPause'>, ref: ReadonlySet<string>): boolean {
  if (protectedDay(d) || d.kind === 'pocitek' || d.sickPrev || d.byState || d.adapt || d.swap) return false
  if (d.why === PHOTO_WHY || d.why === OWN_WHY || OWN_DESC.test(d.desc || '')) return true
  if (d.optional) return false
  // na dnevu premora trening, ki bi ga premor umaknil: dodan po začetku premora
  const w = old.weekPause
  if (w && d.date >= w.from && d.date <= w.to && hits(d, w.mode)) return true
  // (v3.51) vožnja, tek in hribi iz načrta imajo vlogo (lahka, ključna …), dodani sam pa ne — sestavljen dan iz starejše
  // različice (drug naslov) tako ni »lasten« in ga »sestavi znova« zamenja
  // (v3.51) test iz načrta ima vlogo »test« — lasten je samo dodan sam (OWN_WHY zgoraj ali brez vloge); prej je stari test
  // ob »Začni cikel znova« ostal kot »lasten« poleg nove vožnje
  return d.source === 'rules' && !ref.has(planKey(d)) && (d.kind === 'moc' || !d.role)
}
/** (v3.50) Nova sestava dni + lastni zapisi: lastni ostanejo, na njihovem dnevu odpadeta počitek in sestavljen zapis iste vrste. */
export function withOwn(built: readonly PlanDay[], own: readonly PlanDay[]): PlanDay[] {
  if (!own.length) return [...built]
  return [...built.filter(b => !own.some(o => o.date === b.date && (b.kind === 'pocitek' || o.kind === b.kind))), ...own]
}

/**
 * Shranjeni dnevi od danes do konca premora → zapisi za savePlanDays (ti na teh datumih zamenjajo neopravljene).
 * Opravljeno, tekme in dnevi bolezni ostanejo; dnevi, ki se ne spremenijo, niso v izidu.
 */
export function pauseify(plan: readonly PlanDay[], w: WeekPause, today: string, now: string): PlanDay[] {
  const out: PlanDay[] = []
  const from = w.from > today ? w.from : today
  const races = racesIn(plan)
  for (let date = from; date <= w.to; date = addDays(date, 1)) {
    const r = pauseDate(plan.filter(d => d.date === date), w.mode, now, races)
    if (r) out.push(...r)
  }
  return out
}

/**
 * Na novo sestavljen teden (buildWeek, »Sestavi znova«, ensureWeeks): dnevi premora brez treningov oz. brez kolesa;
 * po 8+ dneh premora sta prva dva dneva nazaj lahka (trd trening na kolesu → Z2 do 60 min), kot po bolezni.
 */
export function pauseBuilt(list: PlanDay[], p: Pick<Profile, 'weekPause'>, now: string): PlanDay[] {
  const w = p.weekPause
  if (!w?.from || !w.to) return list
  const dates = [...new Set(list.map(d => d.date))]
  const out: PlanDay[] = []
  // (v3.51) po 5–7 dneh premora (tudi preklican dvotedenski) prvi dan nazaj lahko — prej VO2max in noge takoj po 6 dneh
  const n = backDays(w), long = n > 0, until = addDays(w.to, n)
  const races = racesIn(list)
  for (const date of dates) {
    const all = list.filter(d => d.date === date)
    if (date >= w.from && date <= w.to) { out.push(...(pauseDate(all, w.mode, now, races) ?? all)); continue }
    // (v3.50) tudi trd tek (intervali, dolgi tek) — prej samo kolo, list pa je vsem obljubil »prva dva dneva lažja«
    if (long && date > w.to && date <= until) { out.push(...all.map(d => !d.optional && !d.raceId && d.role !== 'dirka' && isHardDay(d) ? (d.kind === 'kolo' || d.kind === 'test' ? easeBack(d, w) : d.kind === 'tek' ? easeRun(d, w) : d) : d)); continue }
    out.push(...all)
  }
  return out
}
/** (v3.51) Koliko dni po premoru je lahkih: po 8+ dneh dva, po 5–7 dneh eden, sicer nič. */
export const backDays = (w: Pick<WeekPause, 'from' | 'to' | 'since'>): number => { const n = pauseDays(w); return n >= 8 ? 2 : n >= 5 ? 1 : 0 }
const firstDays = (w: WeekPause) => (backDays(w) >= 2 ? 'Prva dva dneva' : 'Prvi dan')
const firstDaysLc = (w: WeekPause) => (backDays(w) >= 2 ? 'prva dva dneva' : 'prvi dan')
function easeBack(d: PlanDay, w: WeekPause): PlanDay {
  const min = Math.min(60, Math.max(30, d.durationMin || 60))
  return {
    ...d, kind: 'kolo', title: BACK_TITLE_PAUSE, desc: `${firstDays(w)} po premoru lahko: Z2, kadenca 90+, največ 60 min. Intervali pridejo potem.`,
    durationMin: min, zone: 'Z2', tssTarget: Math.round(min * 0.7), role: 'lahka', target: null, kcalBurn: null, exercises: undefined, tail: null,
    why: `${pauseAfter(w)} ${firstDaysLc(w)} lahko — telo se navadi nazaj, nato po načrtu.`,
  }
}
/** (v3.50) prvi dva dneva po dolgem premoru: trd tek → lahek tek */
export const BACK_TITLE_RUN = 'Lahek tek po premoru'
function easeRun(d: PlanDay, w: WeekPause): PlanDay {
  const min = Math.min(40, Math.max(20, d.durationMin || 40))
  return {
    ...d, title: BACK_TITLE_RUN, desc: `${firstDays(w)} po premoru lahko: pogovorni tempo (Z2), največ 40 min. Hitri deli pridejo potem.`,
    durationMin: min, zone: 'Z2', tssTarget: Math.round(min * 0.75), role: 'lahka', target: null, kcalBurn: null, tail: null,
    why: `${pauseAfter(w)} ${firstDaysLc(w)} lahko — telo se navadi nazaj, nato po načrtu.`,
  }
}

/** (v3.51) Premor, krajši od 3 dni, ni »teden premora« (ure in rast tečejo naprej). */
const SHORT_PAUSE = 3
/** Ponedeljki tednov, ki jih premor zajame — za ure iz resnice ne štejejo (namenski premor ni »dolg premor«). */
export function pauseWeeks(p: Pick<Profile, 'weekPause'>): Set<string> {
  const w = p.weekPause, out = new Set<string>()
  if (!w?.from || !w.to || w.to < w.from || pauseDays(w) < SHORT_PAUSE) return out
  for (let ws = weekStartIso(pauseStart(w)); ws <= w.to; ws = addDays(ws, 7)) out.add(ws)
  return out
}
/**
 * Teden takoj po premoru (tudi teden, v katerem je bil premor preklican sredi tedna): ponedeljek prvega tedna premora
 * in ali je bil premor dolg (8+ dni). null, če teden ni prvi po premoru.
 */
export function pauseBefore(p: Pick<Profile, 'weekPause'>, weekStart: string): { first: string; long: boolean } | null {
  const w = p.weekPause
  // (v3.51) premor 1–2 dni (npr. samo nedelja) ne zavre naslednjega tedna — prej 10 → 9 h z razlago »po premoru«
  if (!w?.from || !w.to || weekStartIso(addDays(w.to, 1)) !== weekStart || pauseDays(w) < SHORT_PAUSE) return null
  return { first: weekStartIso(pauseStart(w)), long: pauseDays(w) >= 8 }
}

/** Samodejni premiki (zamujen ključni, olajšaj dan, po pretežki vožnji, počutje) ne gredo na dan premora. */
export function pauseLock(lock: RaceLock, p: Pick<Profile, 'weekPause'>): RaceLock {
  if (!p.weekPause) return lock
  return { has: d => lock.has(d) || inPause(p, d), why: d => lock.why(d) ?? (inPause(p, d) ? 'premor' : null), afterRace: d => lock.afterRace(d) }
}

/** »do nedelje«, »danes«, »do nedelje, 1. 11.« (dva tedna) */
export function pauseUntil(w: Pick<WeekPause, 'to'>, today: string): string {
  if (w.to === today) return 'danes'
  return w.to === addDays(weekStartIso(today), 6) ? 'do nedelje' : `do ${new Date(w.to + 'T12:00:00Z').getUTCDay() === 0 ? 'nedelje, ' : ''}${dmOf(w.to)}`
}
/** »Ta teden: premor do nedelje (brez kolesa)« — za Danes, Plan in trenerja. */
export function pauseLine(w: WeekPause, today: string): string {
  const u = pauseUntil(w, today)
  const kolo = w.mode === 'kolo' ? ' (brez kolesa)' : ''
  // (v3.51) premor čez to nedeljo ni »Ta teden: …« (prej »Ta teden: premor do nedelje, 1. 11.« za dva tedna)
  const sun = addDays(weekStartIso(today), 6)
  if (w.to > sun) return w.to === addDays(sun, 7) ? `Ta in naslednji teden: premor${kolo}` : `Do ${dmOf(w.to)}: premor${kolo}`
  return `${u === 'danes' ? 'Danes' : 'Ta teden'}: premor${u === 'danes' ? '' : ` ${u}`}${kolo}`
}
/** (v3.51) Kratko za čip in list: »premor do nedelje (brez kolesa)«, »premor do nedelje, 1. 11.«, »premor danes«. */
export function pauseShort(w: WeekPause, today: string): string {
  return `premor ${pauseUntil(w, today)}${w.mode === 'kolo' ? ' (brez kolesa)' : ''}`
}
/** Vrstica za AI kontekst (brez razloga »bolan« — zdravje ne gre v AI). (v3.51) samo dejstvo, brez navodil o besedah (R10). */
export function pauseAiLine(w: WeekPause, today: string): string | null {
  if (w.to < today) return null
  const why = w.reason && w.reason !== 'bolan' ? ` (razlog: ${REASONS.find(r => r.k === w.reason)?.t ?? w.reason})` : ''
  return `PREMOR po uporabnikovi izbiri: uporabnik je sam izbral počitek od ${w.from} do vključno ${w.to} — ${w.mode === 'kolo' ? 'brez kolesa (moč, tek in hoja ostanejo)' : 'brez treningov'}${why}. V teh dneh ne predlagaj ${w.mode === 'kolo' ? 'voženj' : 'treningov'} in ne priganjaj; vadba po želji je v redu in ni kršitev. Po premoru se načrt nadaljuje brez skoka v obsegu.`
}

/* ---------- prepoznava v klepetu s trenerjem (na napravi, brez AI) ---------- */
const fold = (s: string) => s.toLowerCase().replace(/[čć]/g, 'c').replace(/š/g, 's').replace(/ž/g, 'z').replace(/đ/g, 'd').replace(/[^\p{L}\p{N}?!.,\s]/gu, ' ').replace(/\s+/g, ' ').trim()
// (v3.51) tudi »dva tedna«, »14 dni« (C32)
const SCOPE = /\b(ta|cel|celi|ves) +ted(e)?n\b|\btega tedna\b|\bdo nedelje\b|\bta in naslednji teden\b|\b(dva|2) tedna\b|\b14 dni\b/
const QUESTION = /^(ali|a|al|naj|kaj|kako|zakaj|koliko|kdaj|bi|lahko|je|ce|mi|si)\b/
// nikalnica počitka (»nočem počivati«, »ne bom počival«, »brez počitka«) in več treninga (»hočem več«, »bom več kolesaril«)
const NO_REST = /\b(nocem|ne zelim|ne bom|ne rabim|ne potrebujem|ne grem|brez)\s+(\w+\s+){0,2}(pociv\w*|pocitk\w*|premor\w*|pavz\w*|odmor\w*)|\bnimam\s+(\w+\s+)?(casa|volje)\s+za\s+(pociv\w*|pocit\w*|odmor\w*)/
const MORE = /(?<!\bne )\b(hocem|zelim|bom|bi|dodaj|daj)\s+(\w+\s+){0,2}vec\b/
/**
 * (v3.51) Delni premor ni premor (B04, C22): predmet, ki ni trening ali kolo (moč, intervali, VO2max, avto, sladkarije,
 * prehrana, deficit, zunaj, »več kot 3 ure«, v službo) — gumb bi pobrisal ves teden. Tak stavek ne ponudi ničesar.
 */
// (v3.51) čas, »zunaj« in »v službo« samo ob vožnji ali treningu (»delam po 12 ur«, »sem zunaj na terenu« sta razlog za premor)
const RIDE_W = '(vozn\\w*|vozenj\\w*|vozil\\w*|vozim|kolesar\\w*|kolo|kolesom|tek\\w*|tur\\w*|trening\\w*|trenir\\w*|vadb\\w*)'
const PARTIAL = new RegExp(String.raw`\b(moc|moci|mocjo|fitnes\w*|utez\w*|interval\w*|vo2\w*|tempo\w*|sprint\w*|avt[oau]\w*|sladk\w*|prehran\w*|jedel|jedla|jesti|deficit\w*|kalor\w*|trenazer\w*|z[1-5]|con[aeo]?)\b|\b(dolg|kratk|tezk|tezj|lazj|lahk)\w*\s+(\w+\s+)?(vozn\w*|vozenj\w*|tek\w*|tur\w*|trening\w*|vadb\w*|serij\w*)\b|\bvec kot\b|\b${RIDE_W}\s+(\w+\s+){0,2}(v (sluzbo|solo)|zunaj|\d+\s*(h|ur\w*|min\w*))\b|\b(zunaj|\d+\s*(h|ur\w*|min\w*))\s+(\w+\s+)?${RIDE_W}\b`)
/** »bom pa kolesaril«, »ampak bom vozil«, »samo kolo« — kolo ostane, zato ni premora (C22) */
const BIKE_STAYS = /\b(bom pa|pa bom|ampak bom|bom vseeno|vseeno bom|samo|le)\s+(\w+\s+)?(kolesar\w*|vozil\w*|vozim|kolo|kolesu)\b/
/** »ta teden bom samo tekel«, »samo moč«, »le fitnes« — brez kolesa (B14) */
const ONLY_OTHER = /\b(samo|le)\s+(\w+\s+){0,2}(tek\w*|tecem|tekla|hodil\w*|hodim|hoj\w*|sprehod\w*|moc|moci|fitnes\w*|plava\w*|telovad\w*)\b/
/**
 * (v3.51) Poročilo o preteklem (»ta teden sem samo tekel«, »sem bila samo na sprehodih«, »sem delal samo moč«) ni
 * odločitev — brez »bom«. Pretekli deležnik po »samo« (»samo tekla«) tudi brez »sem«.
 */
const PAST = /\b(sem|si|je|smo|ste|sta|so)\s+(\w+\s+){0,2}\w+(l|la|li|lo|le)\b|\b(samo|le)\s+(\w+\s+){0,2}(tekel|tekla|tekli|hodil\w*|plaval\w*|telovadil\w*|delal\w*)\b/
const WILL = /\b(bom|bomo|bova|bos|bo|bodo|hocem|nocem|grem|ne grem)\b/
/** (v3.51) dva tedna samo ob »tudi / še / in naslednji«, »ta in naslednji«, »dva tedna«, »14 dni«, »naslednji teden tudi ne« —
 * »naslednji teden pa po planu«, »od naslednjega normalno« sta nasprotje (prej vsak »naslednj…«) */
const TWO_WEEKS = /\bta in naslednj\w*\b|\b(tudi|se|in)\s+(ves\s+|cel\s+)?naslednj\w*\b|\bnaslednj\w*\s+(teden\s+)?(tudi|prav tako)\s+(ne|nic)\b|\b(dva|2) tedna\b|\b14 dni\b/
const POS = [
  // nikalnica dejanja: »ta teden nočem nič«, »ne bom treniral«, »ne bom nič na kolesu«, »ne grem na kolo«;
  // (v3.51) »več« samo na koncu ali pred treningom (»ne bom več jedel sladkarij« ni premor — B04)
  /\b(nocem|ne zelim|ne bom|ne morem|ne grem|ne bi|ne mislim|ne nameravam)\s+(\w+\s+){0,3}(nic|vec(?=\s*[.!,]|\s*$|\s+(nic|trenir|kolesar|vadi|vozi|telovad))|trenir\w*|trening\w*|vadi\w*|vadb\w*|telovad\w*|kolesar\w*|kolo|kolesu|kolesa|vozi\w*|vozil\w*)\b/,
  /\bnic\s+(ne bom|nocem|ne grem|ne bo)\b/,
  /\bbrez\s+(treningov|treninga|vadbe|vadb|kolesa|kolesarjenja|voznje|vozenj)\b/,
  // počitek kot odločitev (ne poročilo o preteklem: »sem počival« ne šteje)
  /\bpocivam\b|\b(bom|bi|grem)\s+(\w+\s+){0,3}pociva\w*|\b(vzamem|rabim|potrebujem|imam)\s+(\w+\s+){0,2}(premor|pavzo|pavza|odmor|pocitek)\b|\b(ta teden|do nedelje)\s+(je |bo )?(premor|pavza|odmor)\b/,
  /\b(preskoci|preskocim|preskocimo|izpusti|izpustim|izpustimo)\b/,
  // (v3.51) pogoste oblike (C03, B14): »ne treniram«, »nimam časa«, »ne utegnem«, »mi ni do treninga«, »nič treningov«,
  // »ta teden počitek.«, »pavza ta teden«, »na dopustu / morju«, »do nedelje me ne bo«, »kolo ostane doma«
  /\bne\s+(treniram|vadim|telovadim|kolesarim|vozim)\b|\bnimam\s+(\w+\s+)?(casa|volje)\b|\bne utegnem\b|\b(mi ni|ni mi)\s+do\b/,
  /\bnic\s+(treningov|treninga|vadbe|kolesa|kolesarjenja)\b|\b(ta teden|do nedelje)\s+(je |bo )?(pocitek|dopust)\s*([.!,]|$)|^(pavza|premor|pocitek|odmor)\s+(ta teden|do nedelje)\b/,
  /(?<!\b(bil|bila|bili|bile) )\bna\s+(dopust\w*|morje|morju|potovanj\w*|sluzbeni poti|sluzbeno pot)\b|\bme ne bo\b|\bkolo ostane doma\b/,
]
const BIKE = /\b(kolo|kolesa|kolesu|kolesom|kolesar\w*|vozil\w*|voznj\w*|vozenj\w*|vozit\w*|vozim)\b/
const GENERIC = /\b(trenir\w*|trening\w*|vadb\w*|vadi\w*|telovad\w*)\b/

/**
 * Ali uporabnik v klepetu pove, da ta teden ne bo treniral (ali kolesaril): »ta teden nočem nič«, »ta teden brez kolesa«,
 * »ne bom kolesaril ta teden«, »preskoči ta teden«. Vprašanje za nasvet (»Ali naj ta teden počivam?«), nikalnica počitka
 * (»nočem počivati«), več treninga in drugi tedni niso premor. Kolo, ko gre samo za kolo (brez »trening«, »vadba«).
 * (v3.51) Delni premor (samo moč, intervali …) ni premor; »samo tek / moč« je teden brez kolesa; »dva tedna« in
 * »naslednjega« sta dva tedna.
 */
export function pauseIntent(text: string): { mode: PauseMode; twoWeeks: boolean } | null {
  const t = fold(text || '')
  if (!t || t.length > 400 || !SCOPE.test(t)) return null
  if (t.includes('?') && QUESTION.test(t)) return null
  if (NO_REST.test(t) || MORE.test(t) || BIKE_STAYS.test(t)) return null
  // (v3.51) bolezen ni premor po izbiri — pod odgovorom je »Bolan sem« (prej oboje hkrati)
  if (sickIntent(text)) return null
  const twoWeeks = TWO_WEEKS.test(t)
  // »samo tek«: brez kolesa (pred PARTIAL — »samo moč« je tu teden brez kolesa, ne delni premor); (v3.51) ne poročilo o
  // preteklem in ne vprašanje brez odločitve (»sem samo tekel, je to ok?«)
  if (ONLY_OTHER.test(t) && !GENERIC.test(t.replace(ONLY_OTHER, ''))) return (PAST.test(t) || t.includes('?')) && !WILL.test(t) ? null : { mode: 'kolo', twoWeeks }
  // (v3.51) razlog za »ker« ne dela premora delnega (»ne bom treniral, ker delam po 12 ur«)
  if (PARTIAL.test(t.replace(/\bker\b.*$/, ''))) return null
  if (!POS.some(r => r.test(t))) return null
  const mode: PauseMode = BIKE.test(t) && !GENERIC.test(t) ? 'kolo' : 'vse'
  return { mode, twoWeeks }
}

/** (v3.51) Konec premora v klepetu (C23): »prekliči premor«, »ta teden pa vseeno treniram«, »spet bom treniral«. */
// (v3.51) »vseeno / spet / že« samo v sedanjiku ali z »bom« — »danes sem že vozil kolo v službo« je poročilo, ne preklic
const PAUSE_END = /\b(preklic\w*|koncaj\w*|konca[jm]\w*|odstran\w*|ukini\w*|zbrisi|izbrisi|odpovej\w*)\s+(\w+\s+){0,2}(premor\w*|pavz\w*)\b|\b(premor|pavza)\s+(je\s+)?(mimo|konec|koncan)\b|\b(vseeno|spet|ze)\s+(bom\s+(treniral\w*|vadil\w*|kolesaril\w*|vozil\w*)|treniram|vadim|kolesarim|vozim)\b|\bkonec\s+premora\b/
/** (v3.51) nikalnica preklica: »ne prekliči premora«, »nočem preklicati«, »nikar ne končaj« */
const NO_END = /\b(ne|nocem|ne zelim|ne bom|nikar|ni treba|ne rabim)\s+(\w+\s+)?(preklic\w*|koncaj\w*|konca\w*|odstran\w*|ukini\w*|zbrisi|izbrisi|odpovej\w*)|\bpremor\s+(naj\s+)?ostane\b/
export function pauseEndIntent(text: string): boolean {
  const t = fold(text || '')
  if (!t || t.length > 400) return false
  if (t.includes('?') && QUESTION.test(t)) return false
  return PAUSE_END.test(t) && !NO_END.test(t)
}

/** (v3.51) »Ta teden sem bolan« ni premor po izbiri — pod odgovorom »Bolan sem« (bolezen ima svoj potek nazaj, B14). */
// (v3.51) samo 1. oseba v sedanjiku: brez »je bolan« (brat, otrok), »sem bil bolan« (preteklost), »nisem zbolel« in
// »ne bom zbolela« (prej vse »Bolan sem«)
const SICK = /\b(sem|smo)\s+(?!bil\w*\s)(\w+\s+)?(bolan|bolna|prehlajen\w*|bolni)\b|\b(bolan|bolna|prehlajen\w*)\s+sem\b|\bimam\s+(\w+\s+)?(vrocino|gripo|prehlad|covid\w*|virozo|angino)\b|\b(sem|smo)\s+(\w+\s+)?(zbolel\w*)\b|\b(zbolel|zbolela)\s+sem\b/
export function sickIntent(text: string): boolean {
  const t = fold(text || '')
  if (!t || t.length > 400) return false
  if (t.includes('?') && QUESTION.test(t)) return false
  return SICK.test(t) && !/\b(ko|ce|kadar)\s+(sem|je|bom)\b/.test(t)
}
