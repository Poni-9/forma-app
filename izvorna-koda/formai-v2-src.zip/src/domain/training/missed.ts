import type { Activity, PlanContent, PlanDay } from '../types'
import { addDays, weekStartIso } from './load'
import { isHardDay, matchesPlanned } from './plandays'
import { checkRide } from './review'
import { raceLock, type RaceLock } from './protect'

/**
 * KLJUČNI TRENING, KI NI BIL NAREJEN. Dan je mimo, ključne seje (VO2max, prag, test) pa ni bilo — ali je bila
 * namesto nje lahka vožnja. Trener ga ne pusti kar izginiti: če je v tednu še lahek dan z odmorom pred in po njem
 * (nikoli ob drug trd dan, tekmo ali dan pred njo), gre seja tja; sicer ta teden odpade in naslednji pride po načrtu.
 * Pretekli dan ostane, kakršen je bil (»ni označeno«), da zgodovina pove resnico. Vse je mogoče vrniti (adapt.prev).
 */

const DAY_FROM = ['z nedelje', 's ponedeljka', 's torka', 's srede', 's četrtka', 's petka', 's sobote']
const DAY_ACC = ['nedeljo', 'ponedeljek', 'torek', 'sredo', 'četrtek', 'petek', 'soboto']
const dow = (iso: string) => new Date(iso + 'T12:00:00Z').getUTCDay()
export const dayFrom = (iso: string): string => DAY_FROM[dow(iso)] ?? ''
const dayAcc = (iso: string) => DAY_ACC[dow(iso)] ?? ''

const contentOf = (d: PlanDay): PlanContent => ({ kind: d.kind, title: d.title, desc: d.desc, durationMin: d.durationMin, zone: d.zone ?? null, tssTarget: d.tssTarget ?? null, role: d.role ?? null, target: d.target ?? null, kcalBurn: d.kcalBurn ?? null, why: d.why ?? null, optional: !!d.optional, ...(d.exercises ? { exercises: d.exercises } : {}) })

export const isKeySession = (d: Pick<PlanDay, 'role' | 'kind' | 'optional'>): boolean => !d.optional && (d.role === 'kljucna' || d.role === 'test' || d.kind === 'test')

export interface MissedKey {
  /** dan v načrtu, ki ni bil narejen */
  day: PlanDay
  /** ni bilo aktivnosti / bila je druga (lahka) vožnja */
  verdict: 'ni' | 'drugace'
  /** kam gre: lahek dan tega tedna (nova vsebina) — null = ta teden ga ni kam */
  to: PlanDay | null
  /** za obvestilo */
  text: string
}

/** Ali je bila seja tega dne narejena: povezana aktivnost ali aktivnost iste vrste z vsaj 40 % trajanja tistega dne. */
function doneOn(d: PlanDay, acts: readonly Activity[]): { done: boolean; act: Activity | null } {
  const linked = d.done?.activityId ? acts.find(a => a.id === d.done!.activityId) ?? null : null
  if (linked) return { done: true, act: linked }
  if (d.done) return { done: true, act: null }
  const same = acts.filter(a => a.date === d.date && matchesPlanned(a, d)).sort((a, b) => (b.durationMin || 0) - (a.durationMin || 0))[0] ?? null
  return { done: !!same, act: same }
}

/**
 * Ključne seje tega tedna, ki so mimo in niso bile narejene (ali so bile narejene drugače) in še niso obdelane.
 * `today` = danes; pregleda dneve od ponedeljka do včeraj.
 */
export function missedKeys(plan: readonly PlanDay[], acts: readonly Activity[], today: string, lock?: RaceLock): MissedKey[] {
  const ws = weekStartIso(today), end = addDays(ws, 6)
  const week = plan.filter(d => d.date >= ws && d.date <= end)
  const out: MissedKey[] = []
  for (const d of week) {
    if (d.date >= today || !isKeySession(d) || d.missed || d.adapt?.prev) continue   // prestavljena vsebina se ne šteje dvakrat
    const r = doneOn(d, acts)
    let verdict: MissedKey['verdict'] | null = null
    if (!r.done) verdict = 'ni'
    else if (r.act) { const c = checkRide(d, r.act); if (c && c.status === 'drugace') verdict = 'drugace' }
    if (!verdict) continue
    const to = moveTarget(week, d, today, lock)
    const what = `${d.date === addDays(today, -1) ? 'Včerajšnji' : cap(dayOf(d.date))} ${d.title}`
    const why = verdict === 'ni' ? 'ni bil narejen' : 'ni bil narejen (bila je lahka vožnja)'
    const text = to ? `${what} ${why} → prestavljen na ${dayAcc(to.date)}.` : `${what} ${why} — ta teden ga ni kam prestaviti, naslednji ključni pride po načrtu.`
    out.push({ day: d, verdict, to, text })
  }
  return out
}
const DAY_ADJ = ['nedeljski', 'ponedeljkov', 'torkov', 'sredin', 'četrtkov', 'petkov', 'sobotni']
const dayOf = (iso: string) => DAY_ADJ[dow(iso)] ?? ''
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1)

/**
 * Lahek dan (kolo, lahka/regen) od danes do konca tedna, še neopravljen, ki nima trdega dne ali tekme pred ali za sabo;
 * danes samo, če današnja seja še ni opravljena. Vrne nov dan z vsebino ključne seje (za shranitev) ali null.
 */
export function moveTarget(week: readonly PlanDay[], from: PlanDay, today: string, lock: RaceLock = raceLock(week)): PlanDay | null {
  // trd dan ob kandidatu: prihodnji trdi dnevi in pretekli, ki so bili res narejeni (izpuščen trd dan ne utruja)
  const hardAt = new Set(week.filter(d => d.id !== from.id && !d.optional && isHardDay(d) && (d.date >= today || d.done)).map(d => d.date))
  const cand = week.filter(d => d.date >= today && !d.done && !d.optional && !d.sickPrev && d.kind === 'kolo' && (d.role === 'lahka' || d.role === 'regen')
    && !hardAt.has(d.date) && !hardAt.has(addDays(d.date, -1)) && !hardAt.has(addDays(d.date, 1)) && !lock.has(d.date) && !lock.afterRace(d.date))
    .sort((a, b) => a.date.localeCompare(b.date))[0]
  if (!cand) return null
  const now = new Date().toISOString()
  return { ...cand, ...contentOf(from), why: `Prestavljeno ${dayFrom(from.date)} — ni bil narejen.`, source: 'rules', updatedAt: now, adapt: { after: from.date, prev: contentOf(cand) } }
}

/** Dnevi za shranitev: prestavljena vsebina (če je kam) in oznaka na preteklem dnevu, da se ne obdela znova. */
export function applyMissed(m: MissedKey): PlanDay[] {
  const now = new Date().toISOString()
  const src: PlanDay = { ...m.day, missed: m.to ? 'moved' : 'skipped', updatedAt: now }
  return m.to ? [src, m.to] : [src]
}
