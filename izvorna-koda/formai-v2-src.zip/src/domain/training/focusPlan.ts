import type { AgreedSession, Focus, PlanDay, PlanKind, Profile } from '../types'
import type { PlanInput, WeekCtx } from './planner'
import { addDays, todayIso, weekStartIso } from './load'
import { strengthWorkout, PART_LABEL, type PlanExercise } from './exercises'
import { sickifyBuilt } from './sick'
import { lthrZoneText, hrZones5, zoneText } from './zones'
import { AIM_LABEL } from '../focus/model'

/**
 * NAČRT PO MERI (dogovor s trenerjem): fitnes, vadba doma, tek, kolo in hribi po dogovorjenem tednu.
 * Bloki po 4 tedne: navada → rast → rast → lažji teden (manj serij, krajše). Seje so razporejene tako, da moč
 * ni dva dni zapored na istih mišicah, dolge seje (dolg tek, hribi) gredo na vikend, prosti dnevi so počitek.
 * Moč napreduje s kilogrami (zadnja izvedba), kardio z minutami (+8 % v 3. tednu bloka, nato lažji teden).
 */
const DAY = 86400_000
const weeksBetween = (a: string, b: string) => Math.round((new Date(b).getTime() - new Date(a).getTime()) / (7 * DAY))
const r5 = (x: number) => Math.round(x / 5) * 5
const clamp = (x: number, a: number, b: number) => Math.max(a, Math.min(b, x))

/** Teden v bloku 4: 1 navada, 2–3 rast, 4 lažji teden. */
export function focusWeekContext(p: Profile, weekStart: string): WeekCtx {
  const f = p.focus!
  const start = p.cycleStart || weekStart
  const since = Math.max(0, weeksBetween(start, weekStart))
  const blockWeek = ((since % 4) + 1) as 1 | 2 | 3 | 4
  const recovery = blockWeek === 4
  const volume = recovery ? 0.7 : [0.92, 1, 1.08][blockWeek - 1]!
  const mins = f.sessions.reduce((t, s) => t + s.min, 0)
  const phaseDesc = recovery
    ? 'Lažji teden: manj serij in krajši kardio — telo se okrepi med počitkom, naslednji blok začneš svež.'
    : blockWeek === 1 ? 'Nov blok: navada in tehnika — kilograme vpisuj, naslednje vadbe jih prevzamejo.'
    : blockWeek === 2 ? 'Rast: ista sestava, malo več — kjer si naredil vse ponovitve, je teža višja.'
    : 'Najtežji teden bloka: največ minut in serij, potem lažji teden.'
  return {
    phase: 'osnova', phaseName: f.title || 'Tvoj načrt', phaseDesc, week: since + 1, total: null, blockWeek, recovery, test: false,
    volume, hours: Math.round((mins / 60) * volume * 2) / 2, weeksToEvent: null, event: null, structured: true, easy: 0,
    goalType: null, goals: 0, baseWeek: since + 1, custom: true,
  }
}

/** Razpored po dnevih (0 = pon … 6 = ned): enakomerno razporejeni dnevi, izmenično moč in kardio, dolgo na vikend. */
export function scheduleWeek(sessions: readonly AgreedSession[], openDays: readonly number[], preferDays?: readonly number[] | null, startedDays: number = openDays.length): (number | null)[] {
  const out: (number | null)[] = Array(7).fill(null)
  if (!sessions.length || !openDays.length) return out
  // koliko sej gre v ta teden: cel teden vse dogovorjene (prost dan je dan brez časa ali vsaj eden), skrajšan teden
  // sorazmerno začetim dnevom; dnevi brez časa (začeti, a ne odprti) so že prosti dnevi
  const open = openDays.length, started = Math.max(open, startedDays), off = started - open
  const m = started >= 7
    ? Math.min(sessions.length, open, off ? 7 : 6)
    : Math.max(1, Math.min(Math.round((sessions.length * started) / 7 + 0.25), open, off || open === 1 ? open : open - 1))
  const pref = (preferDays || []).filter(d => openDays.includes(d))
  let days: number[]
  if (pref.length >= m) days = spread(pref, m)
  else {
    const PAT: Record<number, number[]> = { 1: [2], 2: [1, 4], 3: [0, 2, 4], 4: [0, 1, 3, 5], 5: [0, 1, 2, 4, 5], 6: [0, 1, 2, 3, 4, 5], 7: [0, 1, 2, 3, 4, 5, 6] }
    days = openDays.length >= 7 ? PAT[m]! : spread(openDays, m)
  }
  // prednost: seje po vrstnem redu dogovora; izmenično moč in kardio
  const pick = sessions.map((s, i) => ({ s, i })).slice(0, m)
  const str = pick.filter(x => x.s.type === 'fitnes' || x.s.type === 'doma'), car = pick.filter(x => !(x.s.type === 'fitnes' || x.s.type === 'doma'))
  const seq: { s: AgreedSession; i: number }[] = []
  const first = pick[0]!.s.type === 'fitnes' || pick[0]!.s.type === 'doma' ? str : car, second = first === str ? car : str
  for (let k = 0; seq.length < pick.length; k++) { if (first[k]) seq.push(first[k]!); if (second[k]) seq.push(second[k]!) }
  seq.forEach((x, k) => { out[days[k]!] = x.i })
  // dolga seja (dolg tek, dolga vožnja, hribi) na vikend, če je tam kardio ali prost dan
  const longIdx = seq.find(x => x.s.type === 'hribi' || x.s.cardio === 'dolgo')
  if (longIdx) {
    const at = out.indexOf(longIdx.i)
    const wk = [5, 6].find(d => openDays.includes(d) && (out[d] == null || !isStrength(sessions[out[d]!]!)))
    if (at >= 0 && at < 5 && wk != null) { const tmp = out[wk]; out[wk] = longIdx.i; out[at] = tmp ?? null }
  }
  // moč na istih mišicah ne dva dni zapored: zamenjaj z naslednjo sejo, ki ni ista
  for (let d = 1; d < 7; d++) {
    const a = out[d - 1], b = out[d]
    if (a == null || b == null || !sameMuscles(sessions[a]!, sessions[b]!)) continue
    const swap = out.findIndex((x, k) => k > d && x != null && !sameMuscles(sessions[a]!, sessions[x]!))
    if (swap > 0) { out[d] = out[swap]!; out[swap] = b }
  }
  // čez konec tedna: nedelja in ponedeljek naslednjega tedna (prva seja dogovora) ne na istih mišicah
  const sun = out[6], mon = sessions[0]
  if (sun != null && mon && sameMuscles(sessions[sun]!, mon)) {
    const k = out.findIndex((x, d) => d < 6 && x != null && !isStrength(sessions[x]!) && (d === 0 || out[d - 1] == null || !sameMuscles(sessions[out[d - 1]!]!, sessions[sun]!)) && (out[d + 1] == null || !sameMuscles(sessions[out[d + 1]!]!, sessions[sun]!)))
    if (k >= 0) { out[6] = out[k]!; out[k] = sun }
  }
  return out
}
const isStrength = (s: AgreedSession) => s.type === 'fitnes' || s.type === 'doma'
function sameMuscles(a: AgreedSession, b: AgreedSession): boolean {
  if (!isStrength(a) || !isStrength(b)) return false
  const up = new Set(['zgornji', 'potisk', 'poteg', 'roke']), low = new Set(['spodnji', 'noge'])
  const pa = a.part || 'celo', pb = b.part || 'celo'
  if (pa === 'celo' || pb === 'celo') return true
  if (pa === 'trebuh' || pb === 'trebuh') return pa === pb
  return (up.has(pa) && up.has(pb) && !((pa === 'potisk' && pb === 'poteg') || (pa === 'poteg' && pb === 'potisk'))) || (low.has(pa) && low.has(pb))
}
/** m dni čim bolj enakomerno iz razpoložljivih */
function spread(avail: readonly number[], m: number): number[] {
  if (m >= avail.length) return [...avail]
  if (m === 1) return [avail[Math.floor((avail.length - 1) / 2)]!]
  return Array.from({ length: m }, (_, j) => avail[Math.round((j * (avail.length - 1)) / (m - 1))]!)
}

/** Utrip za tek (ne vati): pražni utrip, sicer cone iz max utripa, sicer test govorjenja. */
function runZone(p: Profile, k: 'Z2' | 'Z3' | 'Z4'): string {
  const t = lthrZoneText(p, k)
  if (t) return t
  const hz = hrZones5(p)
  if (hz) { const z = hz[{ Z2: 1, Z3: 2, Z4: 3 }[k]]!; return `utrip ${z.lo}–${z.hi}` }
  return { Z2: 'še lahko govoriš v celih stavkih', Z3: 'rečeš le kratek stavek', Z4: 'samo posamezne besede' }[k]
}

interface Day0 { kind: PlanKind; title: string; desc: string; min: number; zone: string | null; tss: number; role: NonNullable<PlanDay['role']>; exercises?: PlanExercise[]; why: string | null }

/** Kardio seja: tek, kolo ali hribi po vrsti (lahko, intervali, tempo, dolgo) in ravni. */
export function cardioDay(p: Profile, f: Focus, s: AgreedSession, ctx: Pick<WeekCtx, 'volume' | 'recovery' | 'week'>): Day0 {
  const min = clamp(r5(s.min * ctx.volume), s.type === 'kolo' ? 30 : 15, 360)
  const lvl = f.level, c = s.cardio || 'lahko'
  if (s.type === 'hribi') {
    return { kind: 'pohod', title: `Hribi — ${fmtMin(min)}`, desc: `Tura v hribe v enakomernem tempu: v klanec počasi, da lahko govoriš (${runZone(p, 'Z2')}). Palice pomagajo kolenom pri spustu. Voda in prigrizek s sabo.`, min, zone: 'Z2', tss: Math.round(min * 0.6), role: 'dolga', why: null }
  }
  if (s.type === 'kolo') {
    if (c === 'intervali' && !ctx.recovery) {
      const n = lvl === 1 ? 3 : lvl === 2 ? 4 : 5
      return { kind: 'kolo', title: `Kolo — ${n} × 4 min hitro`, desc: `15 min lahko, nato ${n} × 4 min hitro (${zoneText(p, 'Z4')}), vmes 3 min lahko. Preostanek lahko, zadnjih 10 min zelo lahko.`, min, zone: 'Z4', tss: Math.round(min * 1.05), role: 'kljucna', why: null }
    }
    if (c === 'tempo' && !ctx.recovery) return { kind: 'kolo', title: 'Kolo — 2 × 12 min tempo', desc: `15 min lahko, nato 2 × 12 min tempo (${zoneText(p, 'Z3')}), vmes 5 min lahko. Ostalo lahko.`, min, zone: 'Z3', tss: Math.round(min * 0.95), role: 'kljucna', why: null }
    return { kind: 'kolo', title: c === 'dolgo' ? `Kolo — daljša vožnja ${fmtMin(min)}` : `Kolo — lahko ${fmtMin(min)}`, desc: `Enakomerno lahko (${zoneText(p, 'Z2')}), kadenca 85–95. ${c === 'dolgo' ? 'Od 45. minute jej in pij (30–60 g OH na uro).' : 'Če se počutiš svežega, zadnjih 10 min malo hitreje.'}`, min, zone: 'Z2', tss: Math.round(min * 0.7), role: c === 'dolgo' ? 'dolga' : 'lahka', why: null }
  }
  // tek
  if (c === 'intervali' && !ctx.recovery) {
    if (lvl === 1) {
      const n = clamp(Math.round((min - 15) / 3), 4, 10)
      return { kind: 'tek', title: `Tek in hoja — ${n} × 1 min hitreje`, desc: `10 min hitre hoje ali lahkega teka, nato ${n} × (1 min tek hitreje / 2 min hoja). Hitreje = ${runZone(p, 'Z4')}, ne na vso moč. Na koncu 5 min hoje.`, min, zone: 'Z4', tss: Math.round(min * 0.9), role: 'kljucna', why: 'Kratki hitri deli dvignejo kondicijo hitreje kot samo lahek tek — in so varni za začetek.' }
    }
    const n = lvl === 2 ? clamp(Math.round((min - 20) / 4), 4, 8) : clamp(Math.round((min - 20) / 5), 4, 7)
    const w = lvl === 2 ? 2 : 3
    return { kind: 'tek', title: `Tek — ${n} × ${w} min hitro`, desc: `12 min lahkega teka, nato ${n} × (${w} min hitro / 2 min lahko). Hitro = ${runZone(p, 'Z4')}. Enakomerno — zadnji naj bo enako hiter kot prvi. 5 min lahko na koncu.`, min, zone: 'Z4', tss: Math.round(min * 1.1), role: 'kljucna', why: 'Intervali so najhitrejša pot do kondicije.' }
  }
  if (c === 'tempo' && !ctx.recovery) {
    const t = clamp(r5((min - 15) * 0.6), 10, 40)
    return { kind: 'tek', title: `Tempo tek — ${t} min`, desc: `10 min lahko, nato ${t} min udobno hitro (${runZone(p, 'Z3')}), na koncu lahko do konca.`, min, zone: 'Z3', tss: Math.round(min * 1), role: 'kljucna', why: null }
  }
  const walk = lvl === 1 && c !== 'dolgo' ? ' Če je tek ves čas še pretežak, menjaj 3 min teka in 1 min hoje — tudi to šteje.' : ''
  return { kind: 'tek', title: c === 'dolgo' ? `Daljši lahek tek — ${fmtMin(min)}` : `Tek — lahko ${fmtMin(min)}`, desc: `Pogovorni tempo (${runZone(p, 'Z2')}).${walk} Na koncu 5 min raztezanja.`, min, zone: 'Z2', tss: Math.round(min * 0.75), role: c === 'dolgo' ? 'dolga' : 'lahka', why: null }
}

/** Seja moči: vaje (AI ali pravila), opis z ogrevanjem, pavzami in napredkom. */
export function strengthDay(_p: Profile, f: Focus, s: AgreedSession, ctx: Pick<WeekCtx, 'volume' | 'recovery' | 'week'>, activities: PlanInput['activities']): Day0 {
  const where = s.type === 'fitnes' ? 'fitnes' : 'doma'
  const part = s.part || 'celo'
  const min = clamp(r5(s.min * (ctx.recovery ? 0.85 : 1)), 15, 120)
  const w = strengthWorkout({ part, where, equip: f.equipment, level: f.level, aims: f.aims, muscles: f.muscles, min, week: ctx.week, light: ctx.recovery, limits: f.limits, activities, fixed: s.ex })
  const heavy = f.aims.includes('moc') && f.level >= 2
  const rest = heavy ? 'Med serijami 2–3 min pri osnovnih vajah, 90 s pri ostalih.' : f.aims.includes('misice') ? 'Med serijami 90 s.' : 'Med serijami 60 s — tempo drži kondicijo.'
  const tail = ctx.recovery ? 'Lažji teden: serija manj, ista teža in tehnika.' : 'Zadnji dve ponovitvi naj bosta težki, a s čisto tehniko. Ko narediš vse serije z zgornjo mejo ponovitev, je naslednjič teža višja — kilograme vpiši.'
  const desc = `${where === 'fitnes' ? '8–10 min ogrevanja (kolo ali veslanje), nato prva vaja 1–2 lažji seriji.' : '5 min ogrevanja: kroženje z rokami in boki, lahki počepi.'} ${rest} ${tail}${f.limits ? ` Pri bolečini (${f.limits}) vajo izpusti ali zamenjaj.` : ''}${w.progressed.length ? ` Teža gor: ${w.progressed.join(', ')}.` : ''}`
  return { kind: 'moc', title: `${where === 'fitnes' ? 'Fitnes' : 'Doma'} — ${PART_LABEL[part]}`, desc, min, zone: null, tss: Math.round(min * 0.8), role: 'moc', exercises: w.exercises, why: null }
}
const fmtMin = (m: number) => (m >= 60 ? `${Math.floor(m / 60)} h${m % 60 ? ` ${String(m % 60).padStart(2, '0')} min` : ''}` : `${m} min`)

/** Zakaj ta seja — osebno iz dogovora (AI), sicer iz ciljev. */
function whyOf(f: Focus, s: AgreedSession, d: Day0): string | null {
  if (s.why) return s.why
  if (d.why) return d.why
  if (d.kind === 'moc') {
    if (f.keepMuscle && f.aims.includes('hujsanje')) return 'Težke serije med hujšanjem povedo telesu, naj mišice obdrži — kilogrami naj ostanejo, maščoba gre dol.'
    if (f.aims.includes('misice')) return 'Mišice rastejo, ko se teža ali ponovitve počasi dvigujejo — zato vpisuj kilograme.'
    if (f.aims.includes('moc')) return 'Malo ponovitev s težko utežjo = več moči.'
    return f.aims.length ? `Za tvoj cilj: ${f.aims.map(a => AIM_LABEL[a]).join(', ')}.` : null
  }
  if (f.aims.includes('kondicija') && d.role === 'lahka') return 'Lahki kilometri so temelj kondicije — srce in pljuča se prilagajajo, ne da bi te izčrpali.'
  return null
}

/** Teden načrta po meri (enak vmesnik kot buildWeek). */
export function buildFocusWeek(inp: PlanInput): PlanDay[] {
  const p = inp.profile, f = p.focus!
  const start = inp.weekStart || weekStartIso(todayIso())
  const ctx = focusWeekContext(p, start)
  const now = new Date().toISOString()
  const days = Array.from({ length: 7 }, (_, i) => addDays(start, i))
  const notBefore = inp.notBefore || todayIso()
  // začeti dnevi (od začetka načrta) brez dni, ko nimaš časa
  const startedDays = days.map((d, i) => (d >= notBefore ? i : -1)).filter(i => i >= 0)
  const off = new Set(f.offDays || [])
  const openDays = startedDays.filter(i => !off.has(i))
  const order = scheduleWeek(f.sessions, openDays, f.preferDays, startedDays.length)
  const base = (date: string) => ({ id: uid(), date, source: 'rules' as const, createdAt: now, updatedAt: now, done: null })
  const out: PlanDay[] = []
  days.forEach((date, i) => {
    if (!startedDays.includes(i)) { out.push({ ...base(date), kind: 'pocitek', title: 'Pred začetkom', desc: 'Ta dan je bil pred začetkom načrta.', durationMin: 0, zone: null, tssTarget: 0, why: null }); return }
    if (off.has(i)) { out.push({ ...base(date), kind: 'pocitek', title: 'Počitek', desc: 'Ta dan nimaš časa — prosto. Po želji sprehod.', durationMin: 0, zone: null, tssTarget: 0, why: null }); return }
    const k = order[i]
    if (k == null) {
      out.push({ ...base(date), kind: 'pocitek', title: 'Počitek', desc: ctx.recovery ? 'Prosto. Sprehod in raztezanje sta dobrodošla.' : 'Prosto — spanec in hrana sta del treninga. Po želji sprehod.', durationMin: 0, zone: null, tssTarget: 0, why: null })
      return
    }
    const s = f.sessions[k]!
    const d = s.type === 'fitnes' || s.type === 'doma' ? strengthDay(p, f, s, ctx, inp.activities) : cardioDay(p, f, s, ctx)
    out.push({ ...base(date), kind: d.kind, title: d.title, desc: d.desc, durationMin: d.min, zone: d.zone, tssTarget: d.tss, role: d.role, why: whyOf(f, s, d), ...(d.exercises ? { exercises: d.exercises } : {}) })
  })
  // razlaga tedna na prvi aktivni dan
  const first = out.find(d => d.kind !== 'pocitek')
  if (first) {
    const h = String(ctx.hours).replace('.', ',')
    first.why = [`${f.title} · teden ${ctx.week} (${ctx.recovery ? 'lažji teden' : ctx.blockWeek === 1 ? 'nov blok' : 'rast'}) · ~${h} h.`, first.why || ''].filter(Boolean).join(' ')
  }
  return sickifyBuilt(out, p, now)
}

function uid(): string { return Date.now().toString(36) + Math.random().toString(36).slice(2, 10) }
