import type { AgreedSession, Focus, PlanDay, PlanKind, Profile } from '../types'
import type { PlanInput, WeekCtx } from './planner'
import { addDays, todayIso, weekStartIso } from './load'
import { strengthWorkout, PART_LABEL, type PlanExercise } from './exercises'
import { sickifyBuilt } from './sick'
import { lthrZoneText, hrZones5, zoneText } from './zones'
import { AIM_LABEL, tailsOf, isStrength, SPORT_LABEL, PART_NAME, CARDIO_LABEL } from '../focus/model'
import { DAY_SHORT, DAY_AT } from '../focus/choices'
import { hasDrills } from './workout'

/**
 * NAČRT PO MERI (dogovor s trenerjem): fitnes, vadba doma, tek, kolo in hribi po dogovorjenem tednu.
 * Bloki po 4 tedne: navada → rast → rast → lažji teden (manj serij, krajše). Seje so razporejene tako, da moč
 * ni dva dni zapored na istih mišicah, dolge seje (dolg tek, hribi) gredo na vikend, prosti dnevi so počitek.
 * Moč napreduje s kilogrami (zadnja izvedba), kardio z minutami (+8 % v 3. tednu bloka, nato lažji teden).
 */
const DAY = 86400_000
const weeksBetween = (a: string, b: string) => Math.round((new Date(b).getTime() - new Date(a).getTime()) / (7 * DAY))
const r5 = (x: number) => Math.round(x / 5) * 5
const clamp = (x: number, a: number, b: number) => Math.max(a, Math.min(b, x))

/** Teden v bloku 4: 1 navada, 2–3 rast, 4 lažji teden. */
export function focusWeekContext(p: Profile, weekStart: string): WeekCtx {
  const f = p.focus!
  const start = p.cycleStart || weekStart
  const since = Math.max(0, weeksBetween(start, weekStart))
  const blockWeek = ((since % 4) + 1) as 1 | 2 | 3 | 4
  // obseg tednov: kot ga je določil trener (Claude), sicer 1. teden točno kot v dogovoru (kar si videl, to dobiš),
  // 2. in 3. malo več, 4. lažji
  const own = f.block && f.block.length >= 4 ? f.block : null
  const volume = own ? own[blockWeek - 1]! : blockWeek === 4 ? 0.7 : [1, 1.05, 1.1][blockWeek - 1]!
  // lažji teden v trenerjevem bloku: samo izrazito najmanjši obseg (npr. 0,7 ob 1–1,1), ne kateri koli manjši
  const recovery = own ? volume === Math.min(...own) && volume <= 0.8 * Math.max(...own) : blockWeek === 4
  const mins = f.sessions.reduce((t, s) => t + s.min, 0)
  const phaseDesc = recovery
    ? 'Lažji teden: manj serij in krajši kardio — telo se okrepi med počitkom, naslednji blok začneš svež.'
    : blockWeek === 1 ? 'Nov blok: teden kot v dogovoru, poudarek na tehniki — kilograme vpisuj, naslednje vadbe jih prevzamejo.'
    : blockWeek === 2 ? 'Rast: ista sestava, malo več — kjer si naredil vse ponovitve, je teža višja.'
    : 'Najtežji teden bloka: največ minut in serij, potem lažji teden.'
  return {
    phase: 'osnova', phaseName: f.title || 'Tvoj načrt', phaseDesc, week: since + 1, total: null, blockWeek, recovery, test: false,
    volume, hours: Math.round((mins / 60) * volume * 2) / 2, weeksToEvent: null, event: null, structured: true, easy: 0,
    goalType: null, goals: 0, baseWeek: since + 1, custom: true,
  }
}

/**
 * Razpored po dnevih (0 = pon … 6 = ned). Določene seje (»fitnes torek in petek«) stojijo na svojem dnevu; ostale so
 * enakomerno razporejene po preostalih dneh, izmenično moč in kardio, dolga seja na vikend. Kardio z istim dnem kot moč
 * ni v razporedu posebej (pride na konec te vadbe). Določena seja, katere dan v tem tednu ni odprt (začetek sredi tedna),
 * ta teden izpade — ne seli se na dan, ki ga uporabnik ni izbral.
 */
export function scheduleWeek(sessions: readonly AgreedSession[], openDays: readonly number[], preferDays?: readonly number[] | null, startedDays: number = openDays.length,
  /** context: že opravljene vadbe tega tedna po dnevih (štejejo pri razmikih); quota: koliko sej še ta teden */
  o: { context?: readonly (AgreedSession | null)[]; quota?: number } = {}): (number | null)[] {
  const out: (number | null)[] = Array(7).fill(null)
  if (!sessions.length || !openDays.length || o.quota === 0) return out
  const ctx = o.context ?? Array(7).fill(null)
  const tails = tailsOf(sessions)
  const main = sessions.map((s, i) => ({ s, i })).filter(x => !tails.has(x.i))
  const pinned = main.filter(x => x.s.day != null)
  // kardio po moči (isti dan) ni svoj dan — razporejajo se samo glavne seje (prej je dobil svoj dan, ko ni bilo določenih)
  if (!pinned.length) {
    const sub = scheduleFree(main.map(x => x.s), openDays, preferDays, startedDays, o.quota, ctx)
    sub.forEach((k, d) => { if (k != null) out[d] = main[k]!.i })
    return out
  }
  pinned.filter(x => openDays.includes(x.s.day!)).forEach(x => { out[x.s.day!] = x.i })
  const placed = out.filter(x => x != null).length
  const free = main.filter(x => x.s.day == null)
  const rest = openDays.filter(d => out[d] == null)
  const started = Math.max(openDays.length, startedDays)
  // koliko prostih sej ta teden: cel teden vse (ob 7 odprtih dneh ostane en prost), začeti teden sorazmerno
  // cel teden: vse dogovorjene (7 samo, če je izrecno hotel vsak dan — to preveri dogovor)
  const m0 = started >= 7
    ? Math.min(free.length, rest.length)
    : Math.max(0, Math.min(free.length, rest.length, Math.round((main.length * started) / 7 + 0.25) - placed))
  const m = o.quota != null ? Math.max(0, Math.min(m0, o.quota - placed)) : m0
  if (m > 0 && rest.length) {
    // določene in že opravljene seje štejejo pri razmikih (težek dan pred prosto sejo, iste mišice …)
    const fixed: (AgreedSession | null)[] = out.map((k, d) => (k != null ? sessions[k]! : ctx[d] ?? null))
    const sub = scheduleFree(free.map(x => x.s), rest, preferDays, rest.length, m, fixed)
    sub.forEach((k, d) => { if (k != null) out[d] = free[k]!.i })
    fixAdjacent(out, sessions, new Set(rest))
  }
  return out
}
/**
 * Proste seje na dneve (Blaž, 11. 10.: »trener mora razmisliti — napredovanje, pavza vmes«): izmed odprtih dni izbere
 * tiste in tak vrstni red, da je med težkimi dnevi (moč, intervali, tempo) dan premora, da moč ni dva dni zapored na
 * istih mišicah, da je po težkem dnevu lažji ali prost dan, da so dnevi čim bolj enakomerni (tudi čez konec tedna) in
 * da gre dolga seja (dolg tek, hribi) na vikend. Določene seje (fixed) so že na svojih dnevih in štejejo zraven.
 */
function scheduleFree(sessions: readonly AgreedSession[], openDays: readonly number[], preferDays?: readonly number[] | null, startedDays: number = openDays.length, forceM?: number, fixed: readonly (AgreedSession | null)[] = Array(7).fill(null)): (number | null)[] {
  const out: (number | null)[] = Array(7).fill(null)
  if (!sessions.length || !openDays.length) return out
  // koliko sej gre v ta teden: cel teden vse dogovorjene (prost dan je dan brez časa ali vsaj eden), skrajšan teden
  // sorazmerno začetim dnevom; dnevi brez časa (začeti, a ne odprti) so že prosti dnevi
  const open = openDays.length, started = Math.max(open, startedDays), off = started - open
  const m = forceM != null ? Math.min(forceM, open, sessions.length) : started >= 7
    ? Math.min(sessions.length, open)
    : Math.max(1, Math.min(Math.round((sessions.length * started) / 7 + 0.25), open, off || open === 1 ? open : open - 1))
  if (m <= 0) return out
  const pref = (preferDays || []).filter(d => openDays.includes(d))
  const cand = pref.length >= m ? pref : [...openDays]
  const pick = sessions.map((s, i) => ({ s, i })).slice(0, m)
  const PAT: Record<number, number[]> = { 1: [2], 2: [1, 4], 3: [0, 2, 4], 4: [0, 1, 3, 5], 5: [0, 1, 2, 4, 5], 6: [0, 1, 2, 3, 4, 5], 7: [0, 1, 2, 3, 4, 5, 6] }
  const pat = PAT[m] || []
  let best: { days: number[]; seq: number[]; cost: number } | null = null
  const wholeWeek = started >= 7
  for (const days of combos(cand, m)) {
    for (const seq of perms(pick.length)) {
      const week: (AgreedSession | null)[] = fixed.map(x => x)
      days.forEach((d, k) => { week[d] = pick[seq[k]!]!.s })
      let cost = weekCost(week, wholeWeek ? null : fixed[0] ?? sessions[0] ?? null)
      // dolga seja (dolg tek, dolga vožnja, hribi) na vikend
      days.forEach((d, k) => { const s = pick[seq[k]!]!.s; if ((s.type === 'hribi' || s.cardio === 'dolgo') && d < 5 && openDays.some(x => x >= 5)) cost += 3 })
      // vrstni red dogovora je prednost pri enakih stroških; znan vzorec dni pri enakih stroških
      cost += seq.reduce((a, x, k) => a + (x !== k ? 0.3 : 0), 0) + (days.every((d, k) => d === pat[k]) ? 0 : 0.05)
      if (!best || cost < best.cost - 1e-9) best = { days: [...days], seq: [...seq], cost }
    }
  }
  if (best) best.days.forEach((d, k) => { out[d] = pick[best!.seq[k]!]!.i })
  return out
}
/** Ali je seja težka (moč, intervali, tempo) — po njej naj bo lažji ali prost dan. */
const isHard = (s: AgreedSession) => isStrength(s) || s.cardio === 'intervali' || s.cardio === 'tempo'
/**
 * Strošek tedna (manj je bolje): dva dneva vadbe zapored +1 (čez konec tedna tudi — teden se ponavlja), oba težka +3,
 * težek dan pred lažjim +0,5, moč na istih mišicah zapored +4; neenakomerni razmiki (varianca) kot drobiž.
 */
function weekCost(week: readonly (AgreedSession | null)[], nextMonday: AgreedSession | null): number {
  let cost = 0
  const wrap = nextMonday == null
  const days = week.map((s, d) => (s ? d : -1)).filter(d => d >= 0)
  for (let d = 0; d < 7; d++) {
    // nedelja → ponedeljek: cel teden se ponavlja (week[0]); začeti teden gleda prvo sejo naslednjega tedna
    const a = week[d], b = d < 6 ? week[d + 1] : wrap ? week[0] : nextMonday
    if (!a || !b) continue
    cost += 1
    if (isHard(a) && isHard(b)) cost += 3
    else if (isHard(a)) cost += 0.5
    if (sameMuscles(a, b)) cost += 4
    // noge (ali celo telo) dan pred intervali, tempom ali dolgo vadbo: utrujene noge pokvarijo ključni kardio
    if (isStrength(a) && (a.part === 'noge' || a.part === 'spodnji' || !a.part || a.part === 'celo') && !isStrength(b) && b.cardio && b.cardio !== 'lahko') cost += 2
    // dan po dolgi seji (dolg tek, dolga vožnja, tura) ni intervalov, tempa ali težke moči nog
    if (!isStrength(a) && (a.cardio === 'dolgo' || a.type === 'hribi') && (isHard(b) && (!isStrength(b) || b.part === 'noge' || b.part === 'spodnji' || b.part === 'celo' || !b.part))) cost += 2
  }
  if (days.length > 1) {
    const gaps = days.map((d, k) => (k + 1 < days.length ? days[k + 1]! - d : wrap ? 7 - d + days[0]! : 0)).filter(g => g > 0)
    const mean = gaps.reduce((a, b) => a + b, 0) / gaps.length
    cost += gaps.reduce((a, g) => a + (g - mean) * (g - mean), 0) / 10
  }
  // ista vrsta čim bolj narazen (Blaž, 13. 10.: »fitnes čim bolj razporejen čez teden, da se mišice regenerirajo«):
  // moč pon + sre in nato 5 dni nič je slabše kot pon + čet; enako (blažje) za kardio
  cost += spread(days.filter(d => isStrength(week[d]!)), wrap) * 1.2 + spread(days.filter(d => !isStrength(week[d]!)), wrap) * 0.4
  return cost
}
/** Kako neenakomerno so dnevi ene vrste: vsota kvadratov manjkajočih dni do idealnega razmika (7 / število). */
function spread(ds: readonly number[], wrap: boolean): number {
  if (ds.length < 2) return 0
  const ideal = 7 / ds.length
  let c = 0
  for (let k = 0; k < ds.length; k++) {
    const g = k + 1 < ds.length ? ds[k + 1]! - ds[k]! : wrap ? 7 - ds[k]! + ds[0]! : null
    if (g != null && g < ideal) c += (ideal - g) * (ideal - g)
  }
  return c
}
function* combos(arr: readonly number[], m: number): Generator<number[]> {
  const n = arr.length
  if (m > n) return
  const idx = Array.from({ length: m }, (_, i) => i)
  while (true) {
    yield idx.map(i => arr[i]!)
    let i = m - 1
    while (i >= 0 && idx[i] === n - m + i) i--
    if (i < 0) return
    idx[i]!++
    for (let j = i + 1; j < m; j++) idx[j] = idx[j - 1]! + 1
  }
}
function* perms(n: number): Generator<number[]> {
  const a = Array.from({ length: n }, (_, i) => i)
  const c = Array(n).fill(0)
  yield [...a]
  let i = 0
  while (i < n) {
    if (c[i] < i) {
      if (i % 2 === 0) [a[0], a[i]] = [a[i]!, a[0]!]; else [a[c[i]!], a[i]] = [a[i]!, a[c[i]!]!]
      yield [...a]
      c[i]!++; i = 0
    } else { c[i] = 0; i++ }
  }
}
/**
 * Vsebina od trenerja (Claude, »kaj«): opis dneva je trenerjev, aplikacija doda samo tvoje cone (vati, utrip).
 * V lažjem tednu (4. teden bloka) ostane lažja različica aplikacije — trener je sestavil običajen teden.
 */
function withWhat(p: Profile, s: AgreedSession, d: Day0, ctx: Pick<WeekCtx, 'recovery'>): Day0 {
  const what = (s.what || '').trim()
  if (!what) return d
  const w = /[.!?]$/.test(what) ? what : `${what}.`
  if (d.kind === 'moc') return { ...d, desc: `${w} ${d.desc}` }
  const hard = s.cardio === 'intervali' || s.cardio === 'tempo'
  if (ctx.recovery && hard) return { ...d, desc: `${d.desc} Lažji teden — trenerjev »${what.replace(/[.!?]$/, '')}« pride spet naslednji teden.` }
  const z = (k: 'Z2' | 'Z3' | 'Z4') => (s.type === 'kolo' ? zoneText(p, k) : runZone(p, k))
  const zones = s.type === 'hribi' ? '' : ` Lahko = ${z('Z2')}${hard ? `; ${s.cardio === 'tempo' ? 'tempo' : 'hitro'} = ${z(s.cardio === 'tempo' ? 'Z3' : 'Z4')}` : ''}.`
  const word = s.cardio === 'intervali' ? 'intervali' : s.cardio === 'tempo' ? 'tempo' : s.cardio === 'dolgo' ? (s.type === 'kolo' ? 'daljša vožnja' : s.type === 'tek' ? 'daljši tek' : 'daljša tura') : 'lahko'
  // trd dan: če trener ni zapisal ponovitev (»Intervali na trenažerju«), ostane struktura aplikacije (n × 4 min …) —
  // sicer vodena vadba in ura ne vesta, kaj je »hitro« in koliko (Blaž, 17. 10.: »tole niso lih intervali«)
  const keep = hard && !hasDrills(what) && hasDrills(d.desc)
  return { ...d, title: `${SPORT_LABEL[s.type]} — ${word} ${fmtMin(d.min)}`, desc: keep ? `${w} ${d.desc}` : `${w}${zones}` }
}

/** Moč na istih mišicah ne dva dni zapored: premakljivo sejo zamenjaj z drugo premakljivo, ki ni ista. */
function fixAdjacent(out: (number | null)[], sessions: readonly AgreedSession[], movable: ReadonlySet<number>): void {
  const bad = (d: number) => { const a = out[d - 1] ?? null, b = out[d] ?? null; return d > 0 && d < 7 && a != null && b != null && sameMuscles(sessions[a]!, sessions[b]!) }
  const swapOk = (x: number, y: number) => { const t = out[x] ?? null; out[x] = out[y] ?? null; out[y] = t; return [x, x + 1, y, y + 1].every(d => !bad(d)) }
  for (let d = 1; d < 7; d++) {
    if (!bad(d)) continue
    const me = movable.has(d) ? d : movable.has(d - 1) ? d - 1 : -1
    if (me < 0) continue
    for (const k of [0, 1, 2, 3, 4, 5, 6]) {
      if (k === me || !movable.has(k) || out[k] == null) continue
      if (swapOk(me, k)) break
      swapOk(me, k)   // nazaj
    }
  }
}
function sameMuscles(a: AgreedSession, b: AgreedSession): boolean {
  if (!isStrength(a) || !isStrength(b)) return false
  const up = new Set(['zgornji', 'potisk', 'poteg', 'roke']), low = new Set(['spodnji', 'noge'])
  const pa = a.part || 'celo', pb = b.part || 'celo'
  if (pa === 'celo' || pb === 'celo') return true
  if (pa === 'trebuh' || pb === 'trebuh') return pa === pb
  return (up.has(pa) && up.has(pb) && !((pa === 'potisk' && pb === 'poteg') || (pa === 'poteg' && pb === 'potisk'))) || (low.has(pa) && low.has(pb))
}

/** Utrip za tek (ne vati): pražni utrip, sicer cone iz max utripa, sicer test govorjenja. */
function runZone(p: Profile, k: 'Z2' | 'Z3' | 'Z4'): string {
  const t = lthrZoneText(p, k)
  if (t) return t
  const hz = hrZones5(p)
  if (hz) { const z = hz[{ Z2: 1, Z3: 2, Z4: 3 }[k]]!; return `utrip ${z.lo}–${z.hi}` }
  return { Z2: 'še lahko govoriš v celih stavkih', Z3: 'rečeš le kratek stavek', Z4: 'samo posamezne besede' }[k]
}

interface Day0 { kind: PlanKind; title: string; desc: string; min: number; zone: string | null; tss: number; role: NonNullable<PlanDay['role']>; exercises?: PlanExercise[]; why: string | null }

/** Kardio seja: tek, kolo ali hribi po vrsti (lahko, intervali, tempo, dolgo) in ravni. */
export function cardioDay(p: Profile, f: Focus, s: AgreedSession, ctx: Pick<WeekCtx, 'volume' | 'recovery' | 'week'>): Day0 {
  // teden od Claude: njegovo trajanje × obseg tedna iz njegovega bloka (brez razpona aplikacije)
  const min = f.by === 'claude' ? Math.max(5, Math.round(s.min * ctx.volume)) : clamp(r5(s.min * ctx.volume), s.type === 'kolo' ? 30 : 15, 360)
  const lvl = f.level, c = s.cardio || 'lahko'
  if (s.type === 'hribi') {
    return { kind: 'pohod', title: `Hribi — ${fmtMin(min)}`, desc: `Tura v hribe v enakomernem tempu: v klanec počasi, da lahko govoriš (${runZone(p, 'Z2')}). Palice pomagajo kolenom pri spustu. Voda in prigrizek s sabo.`, min, zone: 'Z2', tss: Math.round(min * 0.6), role: 'dolga', why: null }
  }
  if (s.type === 'kolo') {
    if (c === 'intervali' && !ctx.recovery) {
      const n = lvl === 1 ? 3 : lvl === 2 ? 4 : 5
      return { kind: 'kolo', title: `Kolo — ${n} × 4 min hitro`, desc: `15 min lahko, nato ${n} × 4 min hitro (${zoneText(p, 'Z4')}), vmes 3 min lahko. Preostanek lahko, zadnjih 10 min zelo lahko.`, min, zone: 'Z4', tss: Math.round(min * 1.05), role: 'kljucna', why: null }
    }
    if (c === 'tempo' && !ctx.recovery) return { kind: 'kolo', title: 'Kolo — 2 × 12 min tempo', desc: `15 min lahko, nato 2 × 12 min tempo (${zoneText(p, 'Z3')}), vmes 5 min lahko. Ostalo lahko.`, min, zone: 'Z3', tss: Math.round(min * 0.95), role: 'kljucna', why: null }
    return { kind: 'kolo', title: c === 'dolgo' ? `Kolo — daljša vožnja ${fmtMin(min)}` : `Kolo — lahko ${fmtMin(min)}`, desc: `Enakomerno lahko (${zoneText(p, 'Z2')}), kadenca 85–95. ${c === 'dolgo' ? 'Od 45. minute jej in pij (30–60 g OH na uro).' : 'Če se počutiš svežega, zadnjih 10 min malo hitreje.'}`, min, zone: 'Z2', tss: Math.round(min * 0.7), role: c === 'dolgo' ? 'dolga' : 'lahka', why: null }
  }
  // tek
  if (c === 'intervali' && !ctx.recovery) {
    if (lvl === 1) {
      const n = clamp(Math.round((min - 15) / 3), 4, 10)
      return { kind: 'tek', title: `Tek in hoja — ${n} × 1 min hitreje`, desc: `10 min hitre hoje ali lahkega teka, nato ${n} × (1 min tek hitreje / 2 min hoja). Hitreje = ${runZone(p, 'Z4')}, ne na vso moč. Na koncu 5 min hoje.`, min, zone: 'Z4', tss: Math.round(min * 0.9), role: 'kljucna', why: 'Kratki hitri deli dvignejo kondicijo hitreje kot samo lahek tek — in so varni za začetek.' }
    }
    const n = lvl === 2 ? clamp(Math.round((min - 20) / 4), 4, 8) : clamp(Math.round((min - 20) / 5), 4, 7)
    const w = lvl === 2 ? 2 : 3
    return { kind: 'tek', title: `Tek — ${n} × ${w} min hitro`, desc: `12 min lahkega teka, nato ${n} × (${w} min hitro / 2 min lahko). Hitro = ${runZone(p, 'Z4')}. Enakomerno — zadnji naj bo enako hiter kot prvi. 5 min lahko na koncu.`, min, zone: 'Z4', tss: Math.round(min * 1.1), role: 'kljucna', why: 'Intervali so najhitrejša pot do kondicije.' }
  }
  if (c === 'tempo' && !ctx.recovery) {
    const t = clamp(r5((min - 15) * 0.6), 10, 40)
    return { kind: 'tek', title: `Tempo tek — ${t} min`, desc: `10 min lahko, nato ${t} min udobno hitro (${runZone(p, 'Z3')}), na koncu lahko do konca.`, min, zone: 'Z3', tss: Math.round(min * 1), role: 'kljucna', why: null }
  }
  const walk = lvl === 1 && c !== 'dolgo' ? ' Če je tek ves čas še pretežak, menjaj 3 min teka in 1 min hoje — tudi to šteje.' : ''
  return { kind: 'tek', title: c === 'dolgo' ? `Daljši lahek tek — ${fmtMin(min)}` : `Tek — lahko ${fmtMin(min)}`, desc: `Pogovorni tempo (${runZone(p, 'Z2')}).${walk} Na koncu 5 min raztezanja.`, min, zone: 'Z2', tss: Math.round(min * 0.75), role: c === 'dolgo' ? 'dolga' : 'lahka', why: null }
}

/** Seja moči: vaje (AI ali pravila), opis z ogrevanjem, pavzami in napredkom. */
export function strengthDay(_p: Profile, f: Focus, s: AgreedSession, ctx: Pick<WeekCtx, 'volume' | 'recovery' | 'week'>, activities: PlanInput['activities']): Day0 {
  const where = s.type === 'fitnes' ? 'fitnes' : 'doma'
  const part = s.part || 'celo'
  const free = f.by === 'claude'
  // teden od Claude: trajanje in vaje točno njegove (obseg tedna iz njegovega bloka); sicer razpon aplikacije
  const min = free ? Math.max(5, Math.round(s.min * (ctx.recovery ? 0.85 : 1))) : clamp(r5(s.min * (ctx.recovery ? 0.85 : 1)), 15, 120)
  // proste roke samo za trenerjeve vaje s serijami (sestava od Claude); vaje od Gemini (rezerva) gredo skozi filtre
  const w = strengthWorkout({ part, where, equip: f.equipment, level: f.level, aims: f.aims, muscles: f.muscles, min, week: ctx.week, light: ctx.recovery, limits: f.limits, activities, fixed: s.ex, plan: free ? s.plan : null, free: free && !!s.plan?.length })
  const heavy = f.aims.includes('moc') && f.level >= 2
  const rest = heavy ? 'Med serijami 2–3 min pri osnovnih vajah, 90 s pri ostalih.' : f.aims.includes('misice') ? 'Med serijami 90 s.' : 'Med serijami 60 s — tempo drži kondicijo.'
  const tail = ctx.recovery ? 'Lažji teden: serija manj, ista teža in tehnika.' : 'Zadnji dve ponovitvi naj bosta težki, a s čisto tehniko. Ko narediš vse serije z zgornjo mejo ponovitev, je naslednjič teža višja — kilograme vpiši.'
  const desc = `${where === 'fitnes' ? '8–10 min ogrevanja (kolo ali veslanje), nato prva vaja 1–2 lažji seriji.' : '5 min ogrevanja: kroženje z rokami in boki, lahki počepi.'} ${rest} ${tail}${f.limits ? ` Pri bolečini (${f.limits}) vajo izpusti ali zamenjaj.` : ''}${w.progressed.length ? ` Teža gor: ${w.progressed.join(', ')}.` : ''}`
  return { kind: 'moc', title: `${where === 'fitnes' ? 'Fitnes' : 'Doma'} — ${PART_LABEL[part]}`, desc, min, zone: null, tss: Math.round(min * 0.8), role: 'moc', exercises: w.exercises, why: null }
}
const fmtMin = (m: number) => (m >= 60 ? `${Math.floor(m / 60)} h${m % 60 ? ` ${String(m % 60).padStart(2, '0')} min` : ''}` : `${m} min`)

/** Zakaj ta seja — osebno iz dogovora (AI), sicer iz ciljev. */
function whyOf(f: Focus, s: AgreedSession, d: Day0): string | null {
  if (s.why) return s.why
  if (d.why) return d.why
  if (d.kind === 'moc') {
    if (f.keepMuscle && f.aims.includes('hujsanje')) return 'Težke serije med hujšanjem povedo telesu, naj mišice obdrži — kilogrami naj ostanejo, maščoba gre dol.'
    if (f.aims.includes('misice')) return 'Mišice rastejo, ko se teža ali ponovitve počasi dvigujejo — zato vpisuj kilograme.'
    if (f.aims.includes('moc')) return 'Malo ponovitev s težko utežjo = več moči.'
    return f.aims.length ? `Za tvoj cilj: ${f.aims.map(a => AIM_LABEL[a]).join(', ')}.` : null
  }
  if (f.aims.includes('kondicija') && d.role === 'lahka') return 'Lahki kilometri so temelj kondicije — srce in pljuča se prilagajajo, ne da bi te izčrpali.'
  return null
}

/** Teden načrta po meri (enak vmesnik kot buildWeek). */
export function buildFocusWeek(inp: PlanInput): PlanDay[] {
  const p = inp.profile, f = p.focus!
  const start = inp.weekStart || weekStartIso(todayIso())
  const ctx = focusWeekContext(p, start)
  const now = new Date().toISOString()
  const days = Array.from({ length: 7 }, (_, i) => addDays(start, i))
  const notBefore = inp.notBefore || todayIso()
  // začeti dnevi (od začetka načrta) brez dni, ko nimaš časa
  const startedDays = days.map((d, i) => (d >= notBefore ? i : -1)).filter(i => i >= 0)
  const off = new Set(f.offDays || [])
  // že opravljeno ta teden (nov dogovor ali spremembe sredi tedna): te vadbe se odštejejo od dogovora in štejejo pri
  // razmikih — sicer bi teden dobil vse vadbe znova (npr. 4 fitnese od srede naprej, čeprav sta dva že za tabo)
  const doneIdx = new Map<number, PlanKind>()
  for (const d of inp.done || []) { const i = days.indexOf(d.date); if (i >= 0 && d.kind !== 'pocitek' && d.kind !== 'test') doneIdx.set(i, d.kind) }
  const openDays = startedDays.filter(i => !off.has(i) && !doneIdx.has(i))
  // teden, kot ga je videl v dogovoru (cel teden, vsi dnevi s časom) — načrt mu sledi (Blaž, 13. 10.: »plan je zelo
  // dobro naredil, ko sva se pogovarjala, potem pa ga je spremenil«)
  const full = scheduleWeek(f.sessions, [0, 1, 2, 3, 4, 5, 6].filter(i => !off.has(i)), f.preferDays, 7)
  let order: (number | null)[]
  if (startedDays.length === 7 && !doneIdx.size) order = full
  else {
    // začet teden ali že opravljeno: dogovorjene vadbe ostanejo na svojih dneh; opravljene se odštejejo (najprej tiste,
    // katerih dan je že mimo); zamujena vadba gre na prost dan samo, če ne pokvari razmika (nikoli dve težki ali iste
    // mišice zapored), in le do deleža tedna, ki je še pred tabo. Določena (»fitnes v torek«) se ne seli.
    const tails0 = tailsOf(f.sessions)
    const dayOf = new Map<number, number>(); full.forEach((k, d) => { if (k != null) dayOf.set(k, d) })
    const used = new Set<number>()
    const context: (AgreedSession | null)[] = Array(7).fill(null)
    for (const [i, kind] of [...doneIdx.entries()].sort((a, b) => a[0] - b[0])) {
      const fits = (s: AgreedSession) => (kind === 'moc' ? isStrength(s) : kind === 'tek' ? s.type === 'tek' : kind === 'kolo' ? s.type === 'kolo' : kind === 'pohod' ? s.type === 'hribi' : false)
      const cand = f.sessions.map((_, k) => k).filter(k => !used.has(k) && !tails0.has(k)).sort((x, y) => (dayOf.get(x) ?? 9) - (dayOf.get(y) ?? 9))
      let j = cand.find(k => fits(f.sessions[k]!) && (dayOf.get(k) ?? 9) <= i) ?? cand.find(k => fits(f.sessions[k]!))
      if (j == null && kind !== 'moc') j = cand.find(k => !isStrength(f.sessions[k]!))
      if (j == null) continue
      used.add(j); tails0.forEach((m, t) => { if (m === j) used.add(t) })
      context[i] = f.sessions[j]!
    }
    order = Array(7).fill(null)
    for (const d of openDays) { const k = full[d]; if (k != null && !used.has(k)) order[d] = k }
    const total = f.sessions.length - tails0.size
    const doneMain = [...used].filter(k => !tails0.has(k)).length
    const quota = Math.max(0, Math.min(total - doneMain, Math.round((total * startedDays.length) / 7 + 0.25)))
    // nedelja meji na ponedeljek naslednjega tedna (tam bo dogovorjena vadba)
    const at = (d: number): AgreedSession | null => (d === 7 ? (full[0] != null ? f.sessions[full[0]]! : null) : d < 0 || d > 6 ? null : order[d] != null ? f.sessions[order[d]!]! : context[d] ?? null)
    const fitsDay = (x: AgreedSession, d: number) => [at(d - 1), at(d + 1)].every(nb => !nb || (!(isHard(nb) && isHard(x)) && !sameMuscles(nb, x)))
    // vadba z dnem (njegov ali trenerjev dogovor) se nikoli ne seli na drug dan (Blaž, 16. 10.: »torka nisem nikoli
    // označil, pa mi ga da« — zamujena ponedeljkova je šla na torek); seli se samo vadba brez dneva
    const movable = (s: AgreedSession) => s.day == null
    const missed = f.sessions.map((_, k) => k).filter(k => !tails0.has(k) && !used.has(k) && !order.includes(k) && movable(f.sessions[k]!))
    for (const k of missed) {
      if (order.filter(x => x != null).length >= quota) break
      const x = f.sessions[k]!
      const d = openDays.filter(j => order[j] == null && fitsDay(x, j)).sort((p, q) => Number(at(p - 1) != null) + Number(at(p + 1) != null) - Number(at(q - 1) != null) - Number(at(q + 1) != null) || p - q)[0]
      if (d != null) order[d] = k
    }
  }
  const tailOf = new Map<number, number>(); tailsOf(f.sessions).forEach((i, j) => tailOf.set(i, j))
  const base = (date: string) => ({ id: uid(), date, source: 'rules' as const, createdAt: now, updatedAt: now, done: null })
  const out: PlanDay[] = []
  days.forEach((date, i) => {
    if (!startedDays.includes(i)) { out.push({ ...base(date), kind: 'pocitek', title: 'Pred začetkom', desc: 'Ta dan je bil pred začetkom načrta.', durationMin: 0, zone: null, tssTarget: 0, why: null }); return }
    if (off.has(i)) { out.push({ ...base(date), kind: 'pocitek', title: 'Počitek', desc: 'Ta dan nimaš časa — prosto. Po želji sprehod.', durationMin: 0, zone: null, tssTarget: 0, why: null }); return }
    const k = order[i]
    if (k == null) {
      out.push({ ...base(date), kind: 'pocitek', title: 'Počitek', desc: ctx.recovery ? 'Prosto. Sprehod in raztezanje sta dobrodošla.' : 'Prosto — spanec in hrana sta del treninga. Po želji sprehod.', durationMin: 0, zone: null, tssTarget: 0, why: null })
      return
    }
    const s = f.sessions[k]!
    // teden od Claude: kardio ostane njegov tudi v lažjem tednu (krajši po njegovem obsegu) — aplikacija ga ne zamenja
    const cctx = f.by === 'claude' ? { ...ctx, recovery: false } : ctx
    let d = withWhat(p, s, isStrength(s) ? strengthDay(p, f, s, ctx, inp.activities) : cardioDay(p, f, s, cctx), cctx)
    let tail: PlanDay['tail'] = null
    const tj = tailOf.get(k)
    if (tj != null && d.kind === 'moc') {
      // kardio po moči v istem dnevu (»fitnes, tek v istem dnevu«): ena vadba, kardio na koncu
      const c = withWhat(p, f.sessions[tj]!, cardioDay(p, f, f.sessions[tj]!, cctx), cctx)
      tail = { kind: c.kind as 'tek' | 'kolo' | 'pohod', title: c.title, desc: c.desc, durationMin: c.min, zone: c.zone }
      d = { ...d, title: `${d.title} + ${SPORT_LABEL[f.sessions[tj]!.type].toLowerCase()} ${c.min} min`, desc: `${d.desc} Nato ${c.title.replace(/ — /, ': ').toLowerCase()}.`, min: d.min + c.min, tss: d.tss + c.tss }
    }
    out.push({ ...base(date), kind: d.kind, title: d.title, desc: d.desc, durationMin: d.min, zone: d.zone, tssTarget: d.tss, role: d.role, why: whyOf(f, s, d), ...(d.exercises ? { exercises: d.exercises } : {}), ...(tail ? { tail } : {}) })
  })
  // razlaga tedna na prvi aktivni dan
  const first = out.find(d => d.kind !== 'pocitek')
  if (first) {
    const h = String(ctx.hours).replace('.', ',')
    first.why = [`${f.title} · teden ${ctx.week} (${ctx.recovery ? 'lažji teden' : ctx.blockWeek === 1 ? 'nov blok' : 'rast'}) · ~${h} h.`, first.why || ''].filter(Boolean).join(' ')
  }
  return sickifyBuilt(out, p, now)
}

function uid(): string { return Date.now().toString(36) + Math.random().toString(36).slice(2, 10) }

/** Seja z besedami za opis tedna: »fitnes zgornji del«, »tek intervali«. */
const sessWords = (s: AgreedSession) => `${SPORT_LABEL[s.type].toLowerCase()}${s.part ? ` ${PART_NAME[s.part]}` : s.cardio && s.cardio !== 'lahko' ? ` ${CARDIO_LABEL[s.cardio]}` : ''}`
/**
 * Teden z besedami, dan za dnem (cel teden, brez dni brez časa): »pon fitnes zgornji del · tor tek · čet fitnes spodnji del + tek«.
 * Za odgovor trenerja brez AI in za preverjanje, kaj je razpored res naredil.
 */
export function weekWords(f: Pick<Focus, 'sessions' | 'offDays' | 'preferDays'>): string {
  const open = [0, 1, 2, 3, 4, 5, 6].filter(d => !(f.offDays || []).includes(d))
  const order = scheduleWeek(f.sessions, open, f.preferDays, 7)
  const tailOf = new Map<number, number>(); tailsOf(f.sessions).forEach((i, j) => tailOf.set(i, j))
  return order.map((k, d) => (k == null ? null : `${DAY_SHORT[d]} ${sessWords(f.sessions[k]!)}${tailOf.has(k) ? ` + ${sessWords(f.sessions[tailOf.get(k)!]!)}` : ''}`)).filter(Boolean).join(' · ')
}
/** Določene seje z besedami: »Fitnes ob torkih in petkih (+ tek isti dan), kolo ob nedeljah« — prazno, če ni določenih dni. */
export function pinsWords(f: Pick<Focus, 'sessions'>): string {
  const tails = tailsOf(f.sessions)
  const by = new Map<string, number[]>()
  f.sessions.forEach((s, i) => { if (s.day != null && !tails.has(i)) by.set(s.type, [...(by.get(s.type) || []), s.day]) })
  const tailTypes = new Map<string, Set<string>>()
  tails.forEach((m, t) => { const k = f.sessions[m]!.type; tailTypes.set(k, new Set([...(tailTypes.get(k) || []), SPORT_LABEL[f.sessions[t]!.type].toLowerCase()])) })
  return [...by.entries()].map(([t, ds], i) => {
    const at = [...new Set(ds)].sort((a, b) => a - b).map(d => DAY_AT[d]!.replace(/^ob /, ''))
    const w = `${i ? SPORT_LABEL[t as AgreedSession['type']].toLowerCase() : SPORT_LABEL[t as AgreedSession['type']]} ob ${at.length > 1 ? `${at.slice(0, -1).join(', ')} in ${at[at.length - 1]}` : at[0]}`
    const tt = tailTypes.get(t)
    return tt && tt.size ? `${w} (+ ${[...tt].join(' in ')} isti dan)` : w
  }).join(', ')
}
