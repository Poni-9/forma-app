import type { Activity, DailyCheckin, Profile, TestEntry } from '../types'
import { bikeWeeks } from './review'
import { weightTrend } from '../nutrition/energy'
import { raceWeight, targetWeightOf, weeksFromStart, type RaceWeight } from '../nutrition/body'
import { targetHours, macroWeeks } from './planner'
import { todayIso, weekStartIso } from './load'

/**
 * Pot do cilja v številkah: W/kg zdaj → na dan dogodka.
 * »Pričakovano danes« = krivulja od izhodišča do cilja (glej FTP_PATH / KG_PATH);
 * »napoved« = dejanski trendi (FTP testi, 7-dnevna teža), ko jih je dovolj.
 */
export interface GoalStatus {
  event: { name: string; date: string; distanceKm?: number | null } | null
  daysToEvent: number | null
  weeksToEvent: number | null
  ftp: number | null
  weight: number | null
  wkg: number | null
  targetFtp: number | null
  targetWeight: number | null
  targetWkg: number | null
  start: { date: string; ftp: number | null; weightKg: number | null } | null
  startWkg: number | null
  expected: { ftp: number | null; weight: number | null; wkg: number | null } | null
  timePct: number | null
  projectedFtp: number | null
  projectedWeight: number | null
  projectedWkg: number | null
}

const DAY = 86400_000
const days = (a: string, b: string) => Math.round((new Date(b).getTime() - new Date(a).getTime()) / DAY)
const r2 = (x: number) => Math.round(x * 100) / 100

/** Predlog ciljnega FTP: +20 % do dirke (240 → 288 W) — idealen scenarij z 12–13 h strukturiranega treninga. */
export function suggestedTargetFtp(ftp: number | null | undefined): number | null { return ftp ? Math.round(ftp * 1.2) : null }

/**
 * NAJVEČJI MOŽNI FTP do dirke — ocena iz petih stvari:
 * 1) prostor za rast glede na zdajšnji W/kg (nižje = več prostora: 3,0 W/kg ≈ +20 % v sezoni, 4,0 ≈ +10 %, 4,5 ≈ +6 %, nad 5 ≈ +3 %),
 * 2) ure na teden (12 h = 100 %, 10 h ≈ 86 %; nad 12 h vedno manj na uro: 16 h ≈ 113 %, 20 h ≈ 123 %, največ 135 %),
 * 3) čas do dirke (polna sezona ~38 tednov; krajše = manj),
 * 4) sezone treninga (prva ×1,35, druga ×1,15, 3.–4. ×1, 5.–7. ×0,8, 8+ ×0,6 — po letih treninga je prostora manj),
 * 5) starost (do 20 let še zorenje ×1,1, 30+ ×0,95, 40+ ×0,9).
 * »Idealno« = vse po načrtu (brez bolezni, spanec, gorivo); »realno« = ~65 % tega prirastka. Genetskega stropa ne pozna nihče.
 */
export interface FtpPotential { base: number; ideal: number; realistic: number; gainPct: number; hours: number; weeks: number; seasons: number | null }
export function seasonsFactor(n: number | null | undefined): number { return n == null ? 1 : n <= 1 ? 1.35 : n <= 2 ? 1.15 : n <= 4 ? 1 : n <= 7 ? 0.8 : 0.6 }
export function ageFactor(age: number | null | undefined): number { return age == null ? 1 : age <= 20 ? 1.1 : age < 30 ? 1 : age < 40 ? 0.95 : 0.9 }
export function hoursFactor(h: number): number { return h <= 12 ? Math.max(0.6, Math.pow(h / 12, 0.8)) : Math.min(1.35, 1 + 0.45 * Math.log(h / 12)) }
export function ftpPotential(p: Profile, today: string = todayIso(), hoursOverride?: number): FtpPotential | null {
  const base = p.goalStart?.ftp ?? p.ftp
  const w = p.goalStart?.weightKg ?? p.weightKg
  if (!base || !w) return null
  const wkg = base / w
  const head = wkg < 2.5 ? 0.26 : wkg < 3.25 ? 0.2 : wkg < 3.8 ? 0.15 : wkg < 4.3 ? 0.1 : wkg < 5 ? 0.06 : 0.03
  const hours = hoursOverride ?? effectiveHours(p, today)
  const weeks = weeksFromStart(p, today) ?? 38
  const ft = Math.min(1, Math.pow(Math.max(4, weeks) / 38, 0.75))
  const g = head * hoursFactor(hours) * ft * seasonsFactor(p.trainingSeasons) * ageFactor(p.age)
  return { base, ideal: Math.round(base * (1 + g)), realistic: Math.round(base * (1 + g * 0.65)), gainPct: Math.round(g * 100), hours, weeks, seasons: p.trainingSeasons ?? null }
}
/**
 * Ure, ki jih načrt v povprečju res da do dirke: če načrt raste od tvojih dejanskih ur (+10 % na teden),
 * je povprečje nižje od ciljnih ur — in napredek temu primerno manjši. Zaokroženo na 0,5 h.
 */
export function effectiveHours(p: Profile, today: string = todayIso()): number {
  const T = targetHours(p)
  if (p.baseHours == null || !p.event?.date) return T
  const q = { ...p, cycleStart: p.cycleStart || weekStartIso(today) }
  const use = (x: Profile) => macroWeeks(x, today).filter(w => w.phase !== 'tapering' && w.phase !== 'dirka' && w.phase !== 'po')
  const withRamp = use(q), without = use({ ...q, baseHours: null })
  if (!withRamp.length || !without.length) return T
  const avg = (a: { hours: number }[]) => a.reduce((t, w) => t + w.hours, 0) / a.length
  return Math.round(T * (avg(withRamp) / Math.max(0.1, avg(without))) * 2) / 2
}
/** Ure, pri katerih načrt začne (rampCap prvega tedna), zaokroženo na 0,5 — null, če rampe ni. */
export function rampStart(p: Pick<Profile, 'baseHours'>): number | null {
  return p.baseHours == null ? null : Math.round(Math.max(4, p.baseHours * 1.2) * 2) / 2
}
/** Prvi teden (ponedeljek), ko načrt po rampi doseže izbrane ure (ne razbremenilni); null brez rampe ali če jih ne doseže. */
export function fullHoursWeek(p: Profile, today: string = todayIso()): string | null {
  if (p.baseHours == null || !p.event?.date) return null
  const T = targetHours(p)
  const w = macroWeeks({ ...p, cycleStart: p.cycleStart || weekStartIso(today) }, today).find(x => !x.recovery && x.hours >= T - 0.01)
  return w ? w.weekStart : null
}
export type { RaceWeight }

/**
 * »NAJVEČ, KAR GRE« — ure v normalnem tednu bloka, ki jih lahko zgradiš do dirke.
 * Iz tvojih voženj: 1,3 × najdaljši teden v zadnjem letu (povprečje leta in zadnjih 8 tednov samo za prikaz);
 * brez voženj iz vpisanih ur × 1,3. Najmanj 8 h; strop 18 h (tretji teden bloka ~20 h) — več samo, če si tak obseg že vozil
 * (najdaljši teden ali vpisane ure + 6 h, največ 30 h kot na profesionalnih pripravah); do 18 let 12 h. Če je dirka blizu, omeji še rast
 * (+10 % na teden od začetka, vsak 4. teden lažji, zadnjih 8 tednov specifično). Zaokroženo na 0,5 h.
 */
export interface HoursAdvice { max: number; start: number; recent: number | null; peak: number | null; yearAvg: number | null; basis: 'history' | 'stated' | 'none'; limitedBy: 'history' | 'cap' | 'time' | 'youth' | 'floor'; cap: number }
export function hoursAdvice(acts: readonly Activity[], p: Pick<Profile, 'hoursPerWeek' | 'age' | 'event'>, today: string = todayIso()): HoursAdvice {
  const half = (x: number) => Math.round(x * 2) / 2
  const { full } = bikeWeeks(acts, today, 52)
  const rides = full.reduce((t, w) => t + w.rides, 0)
  const has = full.length >= 4 && rides >= 6
  const last8 = full.slice(-8)
  const recent = has && last8.length >= 2 ? +(last8.reduce((t, w) => t + w.hours, 0) / last8.length).toFixed(1) : null
  const peak = has ? Math.max(...full.map(w => w.hours)) : null
  const yearAvg = has ? +(full.reduce((t, w) => t + w.hours, 0) / full.length).toFixed(1) : null
  const stated = p.hoursPerWeek && p.hoursPerWeek > 0 ? p.hoursPerWeek : null
  const basis: HoursAdvice['basis'] = has ? 'history' : stated ? 'stated' : 'none'
  // več, kot že voziš: nizek obseg +30 % (do 12 h), visok manj (20 h in več +10 %) — tveganje raste, korist na uro pada
  const mult = (h: number) => Math.max(1.1, Math.min(1.3, 1.3 - (h - 12) * 0.025))
  let max = has ? peak! * mult(peak!) : stated ? stated * mult(stated) : 10
  let limitedBy: HoursAdvice['limitedBy'] = 'history'
  // 18 h v normalnem tednu = ~20 h v tretjem tednu bloka; več le, če si tak obseg že vozil (profi do 30 h)
  const cap = p.age != null && p.age < 18 ? 12 : Math.min(30, Math.max(18, (has ? peak! : stated ?? 0) + 6))
  if (max < 8) { max = 8; limitedBy = 'floor' }
  if (max > cap) { max = cap; limitedBy = cap === 12 ? 'youth' : 'cap' }
  const start = half(Math.max(4, (recent ?? (stated ? stated * 0.8 : 4)) * 1.2))
  if (p.event?.date) {
    const wte = Math.floor((new Date(p.event.date).getTime() - new Date(today).getTime()) / (7 * DAY))
    const grow = Math.max(0, Math.floor((wte - 10) * 0.75))       // tedni rasti pred specifično fazo in taperingom
    const reach = start * Math.pow(1.1, grow)
    if (reach < max) { max = Math.max(start, reach); limitedBy = 'time' }
  }
  return { max: half(max), start: Math.min(start, half(max)), recent, peak, yearAvg, basis, limitedBy, cap }
}
export function raceWeightOf(p: Profile, today: string = todayIso()): RaceWeight | null { return raceWeight(p, weeksFromStart(p, today)) }

/**
 * Pot ni ravna črta: vati rastejo počasneje v osnovi, hitreje v gradnji; teža pade večinoma v osnovi.
 * Delež poti (čas 0 → 1 do dirke) → delež napredka. Vzorec: 240 → 255 (dec) → 275 (mar) → 288 W (jun),
 * 79 → 75 → 73 → 72 kg — idealen scenarij za 3,0 → 4,0 W/kg v 9 mesecih.
 */
const FTP_PATH: [number, number][] = [[0, 0], [0.34, 0.31], [0.68, 0.73], [1, 1]]
const KG_PATH: [number, number][] = [[0, 0], [0.34, 0.57], [0.68, 0.86], [1, 1]]
function along(path: [number, number][], t: number): number {
  const x = Math.max(0, Math.min(1, t))
  for (let i = 1; i < path.length; i++) { const [a, fa] = path[i - 1]!, [b, fb] = path[i]!; if (x <= b) return fa + (fb - fa) * ((x - a) / (b - a)) }
  return 1
}

/** Raven amaterja po W/kg (FTP) — okvirna lestvica za slovenske amaterske dirke. */
export const LEVELS: { min: number; name: string; desc: string }[] = [
  { min: 0, name: 'Začetnik', desc: 'pod 2,5 W/kg' },
  { min: 2.5, name: 'Povprečen amater', desc: '2,5–3,2 W/kg: zadnja polovica skupine, cilj je priti do konca' },
  { min: 3.3, name: 'Dober amater', desc: '3,3–3,7 W/kg: varno v glavnini, zgornjih 30 % na maratonih' },
  { min: 3.8, name: 'Top amater', desc: '3,8–4,3 W/kg: vodilne skupine, boj za vrh kategorije' },
  { min: 4.4, name: 'Elitni amater', desc: '4,4–5,0 W/kg: zmagovalci maratonov (2–3 leta dela nad 4,0)' },
  { min: 5.0, name: 'Kontinentalni profi', desc: '5,0–5,5 W/kg' },
  { min: 5.5, name: 'WorldTour', desc: '5,5–6,5 W/kg' },
]
export function levelOf(wkg: number | null | undefined) { if (!wkg) return null; let l = LEVELS[0]!; for (const x of LEVELS) if (wkg >= x.min - 0.05) l = x; return l }

/** Mejniki na poti (za tabelo): december, marec, dirka in »eno leto« po začetku. */
export interface Milestone { label: string; date: string; ftp: number | null; weight: number | null; wkg: number | null }
export function milestones(p: Profile): Milestone[] {
  const ev = p.event?.date, st = p.goalStart
  if (!ev || !st) return []
  const tF = p.targetFtp ?? ftpPotential(p, st.date)?.ideal ?? suggestedTargetFtp(st.ftp), tW = targetWeightOf(p, st.date) ?? st.weightKg
  const tot = Math.max(1, days(st.date, ev))
  const at = (t: number, label: string, date: string): Milestone => {
    const f = st.ftp && tF ? Math.round(st.ftp + (tF - st.ftp) * along(FTP_PATH, t)) : null
    const w = st.weightKg && tW ? +(st.weightKg + (tW - st.weightKg) * along(KG_PATH, t)).toFixed(1) : null
    return { label, date, ftp: f, weight: w, wkg: f && w ? r2(f / w) : null }
  }
  const add = (iso: string, d: number) => new Date(new Date(iso).getTime() + d * DAY).toISOString().slice(0, 10)
  const out = [at(0.34, 'po osnovi', add(st.date, Math.round(tot * 0.34))), at(0.68, 'po gradnji', add(st.date, Math.round(tot * 0.68))), at(1, p.event!.name, ev)]
  // eno leto po začetku: še ~+4 % FTP in −1 kg s sezono dirkanja (strop za 12 mesecev)
  const year = add(st.date, 365)
  if (year > ev && tF && tW) out.push({ label: 'eno leto', date: year, ftp: Math.round(tF * 1.04), weight: +(tW - 1).toFixed(1), wkg: r2((tF * 1.04) / (tW - 1)) })
  return out
}

export function goalStatus(p: Profile, checkins: readonly DailyCheckin[], tests: readonly TestEntry[] = [], today: string = todayIso()): GoalStatus {
  const ev = p.event?.date ? { name: p.event.name, date: p.event.date, distanceKm: p.event.distanceKm ?? null } : null
  const tr = weightTrend(checkins)
  const weight = tr ? tr.avg7 : p.weightKg ?? null
  const ftp = p.ftp ?? null
  const start = p.goalStart ?? null
  const targetFtp = p.targetFtp ?? ftpPotential(p, today)?.ideal ?? suggestedTargetFtp(start?.ftp ?? ftp)
  const targetWeight = targetWeightOf(p, today)
  const wkg = ftp && weight ? r2(ftp / weight) : null
  const targetWkg = targetFtp && (targetWeight || weight) ? r2(targetFtp / (targetWeight || weight!)) : null
  const startWkg = start?.ftp && start.weightKg ? r2(start.ftp / start.weightKg) : null
  const daysToEvent = ev ? Math.max(0, days(today, ev.date)) : null
  const weeksToEvent = daysToEvent != null ? Math.ceil(daysToEvent / 7) : null

  let timePct: number | null = null, expected: GoalStatus['expected'] = null
  if (ev && start) {
    const tot = Math.max(1, days(start.date, ev.date))
    timePct = Math.max(0, Math.min(1, days(start.date, today) / tot))
    const eF = start.ftp && targetFtp ? Math.round(start.ftp + (targetFtp - start.ftp) * along(FTP_PATH, timePct)) : null
    const eW = start.weightKg && targetWeight ? +(start.weightKg + (targetWeight - start.weightKg) * along(KG_PATH, timePct)).toFixed(1) : start.weightKg ?? null
    expected = { ftp: eF, weight: eW, wkg: eF && eW ? r2(eF / eW) : null }
  }

  // napoved FTP iz testov (FTP = 95 % 20-min), linearno, omejeno na realen razpon
  let projectedFtp: number | null = null
  const pts = tests.filter(t => t.kind === 'ftp' && (!start || t.date >= start.date)).map(t => ({ x: days(today, t.date), y: t.value * 0.95 })).sort((a, b) => a.x - b.x)
  if (ev && pts.length >= 2 && daysToEvent != null) {
    const n = pts.length, mx = pts.reduce((s, q) => s + q.x, 0) / n, my = pts.reduce((s, q) => s + q.y, 0) / n
    const den = pts.reduce((s, q) => s + (q.x - mx) ** 2, 0)
    if (den > 0) {
      const slope = pts.reduce((s, q) => s + (q.x - mx) * (q.y - my), 0) / den
      const last = pts[pts.length - 1]!.y
      projectedFtp = Math.round(Math.max(last * 0.9, Math.min(last * 1.3, last + slope * daysToEvent)))
    }
  }
  let projectedWeight: number | null = null
  if (ev && tr && tr.deltaWeek != null && weeksToEvent != null) {
    const w = tr.avg7 + tr.deltaWeek * weeksToEvent
    projectedWeight = +(targetWeight && tr.deltaWeek < 0 ? Math.max(targetWeight, w) : w).toFixed(1)
  }
  const pF = projectedFtp ?? null, pW = projectedWeight ?? (projectedFtp ? weight : null)
  return { event: ev, daysToEvent, weeksToEvent, ftp, weight, wkg, targetFtp, targetWeight, targetWkg, start, startWkg, expected, timePct, projectedFtp, projectedWeight, projectedWkg: pF && pW ? r2(pF / pW) : null }
}

/** Ocena VO2max iz 5-minutne največje moči (ACSM za kolo): ≈ 10,8 × W/kg + 7 ml/kg/min. */
export function vo2maxFromP5(watts: number, kg: number): number { return Math.round(10.8 * (watts / kg) + 7) }
