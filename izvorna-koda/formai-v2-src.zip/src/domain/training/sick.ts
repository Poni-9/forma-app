import type { PlanDay, Profile } from '../types'
import { addDays } from './load'
import { isHardDay } from './plandays'

/**
 * »BOLAN SEM« — počitek za nekaj dni. Neopravljeni treningi v tem obdobju postanejo en dan počitka na datum;
 * prvotni zapisi dneva se shranijo v ta dan (sickPrev), zato jih »Spet zdrav« vrne (tudi na drugi napravi — dan je
 * v oblaku). Opravljeni zapisi, tekme in dirke ostanejo, kot so. Tudi na novo sestavljen teden v tem obdobju
 * dobi počitek (buildWeek). Prehrana: v tem obdobju brez deficita (noDeficitDay).
 */
export const SICK_TITLE = 'Počitek — bolezen'
export const SICK_DESC = 'Spanec, tekočina, lahka hrana. Treningi tega dne so shranjeni — vrnejo se z »Spet zdrav« na Danes.'

export interface SickPeriod { from: string; to: string; at?: string }

/** Ali je datum v obdobju bolezni. */
export function inSick(p: Pick<Profile, 'sick'>, date: string): boolean {
  const s = p.sick
  return !!s && date >= s.from && date <= s.to
}

const protectedDay = (d: PlanDay) => !!d.done || !!d.raceId || d.role === 'dirka'

/**
 * Dnevi načrta v obdobju → en zapis počitka na datum (id prvega neopravljenega zapisa), prejšnji neopravljeni zapisi
 * v sickPrev. Vrne zapise za upsertPlanDays (ta na teh datumih zamenja neopravljene). Dnevi, ki so že počitek zaradi
 * bolezni ali imajo samo opravljeno/tekmo, ostanejo.
 */
export function sickify(plan: readonly PlanDay[], period: SickPeriod, now: string): PlanDay[] {
  const out: PlanDay[] = []
  const dates = [...new Set(plan.filter(d => d.date >= period.from && d.date <= period.to).map(d => d.date))].sort()
  for (const date of dates) {
    const all = plan.filter(d => d.date === date)
    if (all.some(d => d.sickPrev) || all.some(d => d.raceId || d.role === 'dirka')) continue
    const open = all.filter(d => !protectedDay(d))
    if (!open.length || open.every(d => d.kind === 'pocitek')) continue
    out.push(restOf(open, now))
  }
  return out
}

function restOf(open: readonly PlanDay[], now: string): PlanDay {
  const first = open[0]!
  return {
    id: first.id, date: first.date, kind: 'pocitek', title: SICK_TITLE, desc: SICK_DESC, durationMin: 0, zone: null, tssTarget: 0, role: null,
    source: first.source, createdAt: first.createdAt, updatedAt: now, done: null,
    sickPrev: open.map(d => ({ ...d, sickPrev: null })),
  }
}

/** Na novo sestavljen teden (buildWeek): dnevi v obdobju bolezni dobijo počitek, sestavljeno je shranjeno za vrnitev. */
export function sickifyBuilt(days: PlanDay[], p: Pick<Profile, 'sick'>, now: string): PlanDay[] {
  if (!p.sick) return days
  const hit = new Set(days.filter(d => inSick(p, d.date) && !protectedDay(d)).map(d => d.date))
  if (!hit.size) return days
  const out: PlanDay[] = []
  for (const d of days) {
    if (!hit.has(d.date)) { out.push(d); continue }
    if (out.some(x => x.date === d.date)) continue
    const same = days.filter(x => x.date === d.date && !protectedDay(x))
    out.push(same.every(x => x.kind === 'pocitek') ? same[0]! : restOf(same, now))
  }
  return out
}

/**
 * »Spet zdrav«: neopravljeni dnevi počitka zaradi bolezni od `from` naprej dobijo nazaj prvotne zapise. Vrne zapise za
 * upsertPlanDays. Pretekli dnevi bolezni ostanejo počitek (tako je bilo).
 * (v3.50) `sickFrom` = začetek bolezni: po 3+ dneh bolezni sta prva dva dneva nazaj lahka (ključni trening, test ali dolga
 * vožnja → lahka Z2 do 60 min) — prej je bil prvi dan nazaj »Sweet spot 3 × 12 min«. Razveljavitev (brez sickFrom) vrne vse.
 */
export const BACK_TITLE = 'Lahka Z2 po bolezni'
export function unsickify(plan: readonly PlanDay[], from: string, now: string, sickFrom?: string | null): PlanDay[] {
  const out: PlanDay[] = []
  for (const d of plan) {
    if (d.date < from || d.done || !d.sickPrev?.length) continue
    for (const x of d.sickPrev) out.push({ ...x, sickPrev: null, updatedAt: now })
  }
  const days = sickFrom ? Math.round((Date.parse(from + 'T12:00:00Z') - Date.parse(sickFrom + 'T12:00:00Z')) / 86_400_000) : 0
  if (days < 3) return out
  const until = addDays(from, 1)
  return out.map(d => (d.date > until || (d.kind !== 'kolo' && d.kind !== 'test') || d.optional || d.raceId || d.role === 'dirka' || !isHardDay(d) ? d : easeBack(d)))
}
function easeBack(d: PlanDay): PlanDay {
  const min = Math.min(60, Math.max(30, d.durationMin || 60))
  return {
    ...d, kind: 'kolo', title: BACK_TITLE, desc: 'Prva dva dneva po bolezni lahko: Z2, kadenca 90+, največ 60 min. Če je utrip v mirovanju še povišan, raje počitek.',
    durationMin: min, zone: 'Z2', tssTarget: Math.round(min * 0.7), role: 'lahka', target: null, kcalBurn: null, exercises: undefined, tail: null,
    why: 'Prva dva dneva po bolezni lahko — intervali se vrnejo, ko je utrip v mirovanju spet normalen.',
  }
}

/** Konec obdobja po n dneh od danes (vključno z danes). */
export function sickPeriod(today: string, days: number): SickPeriod {
  return { from: today, to: addDays(today, Math.max(1, Math.min(14, Math.round(days))) - 1) }
}
