import type { Activity, Profile, Sport } from '../types'

/** Prag utripa (LTHR): eksplicitno, sicer Karvonen 85 % rezerve, sicer 90 % max. */
export function lthrOf(p: Pick<Profile, 'lthr' | 'restHr' | 'maxHr'>): number | null {
  if (p.lthr) return p.lthr
  if (p.maxHr && p.restHr) return Math.round(p.restHr + 0.85 * (p.maxHr - p.restHr))
  if (p.maxHr) return Math.round(0.9 * p.maxHr)
  return null
}

/**
 * Ocena TSS v štirih stopnjah: moč (NP≈avg×1.05, IF² × ure × 100) → utrip (intenziteta proti LTHR)
 * → hitrost/šport → privzetek. Enako kot v prvi različici, da se zgodovina ne premakne.
 */
export function estimateTss(a: Pick<Activity, 'sport' | 'durationMin' | 'avgPower' | 'avgHr' | 'distKm' | 'elevM'>, p: Pick<Profile, 'ftp' | 'lthr' | 'restHr' | 'maxHr'>): number {
  const hours = Math.max(0, (a.durationMin || 0) / 60)
  if (!hours) return 0
  if (a.avgPower && p.ftp) {
    const np = a.avgPower * 1.05
    const IF = Math.max(0.4, Math.min(1.2, np / p.ftp))
    return Math.round(hours * IF * IF * 100)
  }
  const lthr = lthrOf(p)
  if (a.avgHr && lthr) {
    const intensity = Math.max(0.45, Math.min(1.15, a.avgHr / lthr))
    return Math.round(hours * intensity * intensity * 100)
  }
  const km = a.distKm || 0
  const spd = km && hours ? km / hours : 0
  const climbRatio = km ? (a.elevM || 0) / km : 0
  switch (a.sport) {
    case 'moc': return Math.round(hours * 70)
    case 'tek': return Math.round(hours * (spd < 9 ? 62 : spd < 12 ? 78 : 95))
    case 'pohod': return Math.round(hours * (55 + (climbRatio > 60 ? 15 : 0)))
    case 'plavanje': return Math.round(hours * 70)
    default: { // kolo / drugo
      let perH = spd < 18 ? 42 : spd < 24 ? 50 : spd < 30 ? 62 : 75
      if (climbRatio > 12) perH += 12
      return Math.round(hours * perH)
    }
  }
}

export interface FormPoint { date: string; ctl: number; atl: number; tsb: number; tss: number }

type FormAct = Pick<Activity, 'date' | 'tss'> & Partial<Pick<Activity, 'ext'>>
const ISO_DAY = /^\d{4}-\d{2}-\d{2}$/
const finite = (x: unknown): x is number => typeof x === 'number' && Number.isFinite(x)
/** Koliko dni zgodovine je potrebnih, da je forma (CTL τ = 42) zanesljiva. */
export const FORM_HISTORY_DAYS = 42

/**
 * Začetno stanje forme na dan pred prvo aktivnostjo — ne 0 (nov uporabnik bi sicer tedne izgledal utrujen):
 * CTL/ATL iz intervals.icu pri najstarejši aktivnosti (stanje ob koncu tistega dne, vrnjeno za dan nazaj),
 * sicer povprečni dnevni TSS prvih 42 dni (ali vseh, ki jih imamo) za oba.
 */
function seedOf(activities: readonly FormAct[], byDay: ReadonlyMap<string, number>, first: string, until: string): { ctl: number; atl: number } {
  const icu = activities.find(a => a.date === first && finite(a.ext?.icuCtl) && finite(a.ext?.icuAtl) && a.ext!.icuCtl! >= 0 && a.ext!.icuAtl! >= 0)
  if (icu) {
    const t = byDay.get(first) || 0
    return { ctl: Math.max(0, (icu.ext!.icuCtl! - t / 42) * (42 / 41)), atl: Math.max(0, (icu.ext!.icuAtl! - t / 7) * (7 / 6)) }
  }
  const end = addDays(first, FORM_HISTORY_DAYS - 1) < until ? addDays(first, FORM_HISTORY_DAYS - 1) : until
  let sum = 0, n = 0
  for (let d = first; d <= end; d = addDays(d, 1)) { sum += byDay.get(d) || 0; n++ }
  const m = n ? sum / n : 0
  return { ctl: m, atl: m }
}

/** Banister: CTL τ=42, ATL τ=7. Dnevni niz od dneva pred prvo aktivnostjo do danes (začetno stanje: seedOf). */
/** Ista tabela aktivnosti (app.activities) se bere na več zaslonih — serija forme se izračuna enkrat na dan. Ne spreminjaj vrnjenega. */
const formMemo = new WeakMap<object, { until: string; out: FormPoint[] }>()
export function formSeries(activities: readonly FormAct[], until: string = todayIso()): FormPoint[] {
  const hit = formMemo.get(activities)
  if (hit && hit.until === until) return hit.out
  const out = formSeriesOf(activities, until)
  formMemo.set(activities, { until, out })
  return out
}
function formSeriesOf(activities: readonly FormAct[], until: string): FormPoint[] {
  const acts = activities.filter(a => a && ISO_DAY.test(a.date || ''))
  if (!acts.length) return []
  const byDay = new Map<string, number>()
  for (const a of acts) byDay.set(a.date, (byDay.get(a.date) || 0) + (finite(a.tss) && a.tss > 0 ? a.tss : 0))
  const first = [...byDay.keys()].sort()[0]!
  const out: FormPoint[] = []
  const start = addDays(first, -1)
  let { ctl, atl } = seedOf(acts, byDay, first, until)
  for (let d = start; d <= until; d = addDays(d, 1)) {
    const tss = byDay.get(d) || 0
    if (d !== start) { ctl += (tss - ctl) / 42; atl += (tss - atl) / 7 }
    out.push({ date: d, ctl, atl, tsb: +(ctl - atl).toFixed(1), tss })
  }
  return out
}

const dayNum = (iso: string) => Math.round(Date.parse(iso + 'T12:00:00Z') / 86_400_000)
/** Koliko dni zgodovine aktivnosti je do danes (od najstarejše). */
export function historyDays(activities: readonly Pick<Activity, 'date'>[], today: string = todayIso()): number {
  let first: string | null = null
  for (const a of activities) if (a && ISO_DAY.test(a.date || '') && a.date <= today && (!first || a.date < first)) first = a.date
  return first ? dayNum(today) - dayNum(first) : 0
}
/**
 * Je forma (CTL/ATL/TSB) zanesljiva: vsaj 42 dni zgodovine ali začetno stanje iz intervals.icu pri najstarejši
 * aktivnosti. Prej so številke le ocena — načrt zaradi forme ne krči obsega, UI naj to pove.
 */
export function formReliable(activities: readonly FormAct[], today: string = todayIso()): boolean {
  if (historyDays(activities, today) >= FORM_HISTORY_DAYS) return true
  let first: string | null = null
  for (const a of activities) if (a && ISO_DAY.test(a.date || '') && a.date <= today && (!first || a.date < first)) first = a.date
  return !!first && activities.some(a => a.date === first && finite(a.ext?.icuCtl) && finite(a.ext?.icuAtl))
}

export type FormBand = 'svež' | 'dober' | 'produktiven' | 'utrujen'
export function formBand(tsb: number): { band: FormBand; color: 'ok' | 'kolo' | 'warn' | 'bad' } {
  if (tsb >= 10) return { band: 'svež', color: 'ok' }
  if (tsb >= -5) return { band: 'dober', color: 'kolo' }
  if (tsb >= -20) return { band: 'produktiven', color: 'warn' }
  return { band: 'utrujen', color: 'bad' }
}

/** Preprosta »pripravljenost« 0–100 iz TSB in bolečin. */
export function readiness(tsb: number, soreness?: number | null): number {
  let r = 60 + Math.max(-30, Math.min(30, tsb)) * 1.2
  if (soreness) r -= (soreness - 1) * 9
  return Math.round(Math.max(5, Math.min(100, r)))
}

export function sportOfType(t: string): Sport | null {
  const s = String(t || '').toLowerCase()
  if (!s) return null
  if (/virtual ?ride|ride|cycl|bike|kolo|gravel|mtb|mountain|ebike|velo/.test(s)) return 'kolo'
  if (/run|tek|jog|trail/.test(s)) return 'tek'
  if (/hike|walk|hoja|pohod|sprehod|nordic/.test(s)) return 'pohod'
  if (/weight|strength|moč|moc|vadba|workout|crossfit|gym|yoga|pilates/.test(s)) return 'moc'
  if (/swim|plav/.test(s)) return 'plavanje'
  return 'drugo'
}

/* ---- datumi (lokalni ISO) ---- */
export function todayIso(d: Date = new Date()): string {
  const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, '0'), dd = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${dd}`
}
/** Datumi se v zankah seštevajo tisočkrat (načrt, forma, grafi) — rezultati so v predpomnilniku. */
const dayCache = new Map<string, string>()
export function addDays(iso: string, n: number): string {
  const key = iso + '|' + n
  const hit = dayCache.get(key)
  if (hit !== undefined) return hit
  const [y, m, d] = iso.split('-').map(Number) as [number, number, number]
  const out = todayIso(new Date(y, m - 1, d + n))
  if (dayCache.size >= 20_000) dayCache.clear()
  dayCache.set(key, out)
  return out
}
export function weekStartIso(iso: string): string {
  const [y, m, d] = iso.split('-').map(Number) as [number, number, number]
  const dt = new Date(y, m - 1, d)
  const dow = (dt.getDay() + 6) % 7 // pon = 0
  return addDays(iso, -dow)
}
export function fmtDur(min: number | null | undefined): string {
  if (!min) return '—'
  const h = Math.floor(min / 60), m = Math.round(min % 60)
  return h ? `${h} h ${String(m).padStart(2, '0')} min` : `${m} min`
}
