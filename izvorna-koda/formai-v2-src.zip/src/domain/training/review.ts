import type { Activity, PlanDay, Profile } from '../types'
import { addDays, weekStartIso, fmtDur } from './load'

/**
 * TRENING V RESNICI — kaj si dejansko naredil (iz voženj z Garmina prek intervals.icu), ne kaj piše v načrtu.
 * Isto, kar trener pogleda najprej: koliko ur res voziš, ali so bili ključni treningi res ključni (utrip),
 * ali je 80/20 res 80/20, ali aerobna baza raste (hitrost na utrip) in ali imaš merilnik moči.
 * Čiste funkcije, brez omrežja.
 */

const bike = (a: Pick<Activity, 'sport'>) => a.sport === 'kolo'

export interface WeekVol { weekStart: string; hours: number; rides: number }

/** Ure na kolesu: n polnih tednov pred tekočim (od prvega tedna s podatki) + tekoči teden. */
export function bikeWeeks(acts: readonly Activity[], today: string, n = 8): { full: WeekVol[]; current: WeekVol } {
  const ws = weekStartIso(today)
  const first = acts.filter(bike).map(a => a.date).sort()[0]
  const full: WeekVol[] = []
  for (let k = n; k >= 1; k--) {
    const s = addDays(ws, -7 * k), e = addDays(s, 6)
    if (!first || e < first) continue
    const r = acts.filter(a => bike(a) && a.date >= s && a.date <= e)
    full.push({ weekStart: s, hours: +(r.reduce((t, a) => t + (a.durationMin || 0), 0) / 60).toFixed(1), rides: r.length })
  }
  const cur = acts.filter(a => bike(a) && a.date >= ws && a.date <= today)
  return { full, current: { weekStart: ws, hours: +(cur.reduce((t, a) => t + (a.durationMin || 0), 0) / 60).toFixed(1), rides: cur.length } }
}

/** Povprečne ure na teden (polni tedni); null, če je voženj premalo za oceno. */
export function baselineHours(acts: readonly Activity[], today: string, n = 8): number | null {
  const { full } = bikeWeeks(acts, today, n)
  const rides = full.reduce((t, w) => t + w.rides, 0)
  if (full.length < 2 || rides < 3) return null
  return +(full.reduce((t, w) => t + w.hours, 0) / full.length).toFixed(1)
}

/** Razdelitev časa po utripu: lahko (Z1–Z2), vmes (Z3), težko (Z4+) — v %. */
export function zoneSplit(acts: readonly Activity[]): { easy: number; mid: number; hard: number; minutes: number } | null {
  let e = 0, m = 0, h = 0
  for (const a of acts) {
    const z = a.hrZoneSec
    if (!bike(a) || !z || z.length < 4) continue
    e += (z[0] || 0) + (z[1] || 0); m += z[2] || 0; h += z.slice(3).reduce((t, x) => t + (x || 0), 0)
  }
  const t = e + m + h
  if (t < 30 * 60) return null
  return { easy: Math.round((e / t) * 100), mid: Math.round((m / t) * 100), hard: Math.round((h / t) * 100), minutes: Math.round(t / 60) }
}

export type CheckNeed = 'vo2' | 'prag' | 'test' | 'dolga' | 'z2' | 'regen'
export function needOfDay(d: Pick<PlanDay, 'role' | 'zone' | 'title' | 'kind'>): CheckNeed | null {
  if (d.kind !== 'kolo' && d.kind !== 'test') return null
  if (d.role === 'test' || d.kind === 'test') return 'test'
  if (d.role === 'kljucna') return /Z5/.test(d.zone || '') || /VO2/i.test(d.title) ? 'vo2' : 'prag'
  if (d.role === 'dolga') return 'dolga'
  if (d.role === 'regen') return 'regen'
  if (d.role === 'dirka') return null
  return 'z2'
}

export interface RideCheck { status: 'ok' | 'delno' | 'drugace'; verdict: string; detail: string; minutes: number; easyPct: number | null; hardMin: number | null }

/** Ali je vožnja ustrezala načrtovanemu treningu (po utripu in trajanju). */
export function checkRide(plan: Pick<PlanDay, 'role' | 'zone' | 'title' | 'kind' | 'durationMin'>, a: Pick<Activity, 'durationMin' | 'hrZoneSec' | 'hrZoneTop' | 'avgHr' | 'maxHr'>): RideCheck | null {
  const need = needOfDay(plan)
  if (!need) return null
  const min = a.durationMin || 0
  const z = a.hrZoneSec && a.hrZoneSec.length >= 4 ? a.hrZoneSec : null
  const tot = z ? z.reduce((t, x) => t + (x || 0), 0) : 0
  const easy = z ? (z[0] || 0) + (z[1] || 0) : 0, mid = z ? z[2] || 0 : 0, hard = z ? z.slice(3).reduce((t, x) => t + (x || 0), 0) : 0
  const easyPct = z && tot ? Math.round((easy / tot) * 100) : null
  const hardMin = z ? Math.round(hard / 60) : null
  const above = a.hrZoneTop && a.hrZoneTop[2] ? a.hrZoneTop[2] + 1 : null
  const detail = [fmtDur(min), easyPct != null ? `${easyPct} % lahko (Z1–Z2)` : null, hardMin != null ? `${hardMin} min${above ? ` nad ${above}` : ''} (prag in više)` : null, a.avgHr ? `povp. utrip ${Math.round(a.avgHr)}` : null].filter(Boolean).join(' · ')
  const m = /(\d+)\s*×\s*(\d+)\s*min/.exec(plan.title)
  const work = m ? +m[1]! * +m[2]! : 30
  const r = (status: RideCheck['status'], verdict: string): RideCheck => ({ status, verdict, detail, minutes: min, easyPct, hardMin })
  if (!z) {
    if (need === 'vo2' || need === 'prag' || need === 'test') return r('delno', 'Brez podatkov o utripu ne vem, ali so bili intervali narejeni.')
    return min >= plan.durationMin * 0.8 ? r('ok', 'Opravljeno po trajanju.') : r('delno', `Krajše od načrta (${fmtDur(min)} od ${fmtDur(plan.durationMin)}).`)
  }
  switch (need) {
    case 'vo2':
      if (hard >= 10 * 60) return r('ok', 'VO2max opravljen ✓')
      if (hard >= 4 * 60) return r('delno', `VO2max samo delno — ${hardMin} min nad pragom (cilj ~12).`)
      return r('drugace', `VO2max ni bil narejen — ${easyPct! >= 70 ? 'bila je lahka (Z2) vožnja' : 'bila je vožnja v tempu'}.`)
    case 'prag':
      if (mid + hard >= work * 60 * 0.6) return r('ok', 'Pražni trening opravljen ✓')
      if (mid + hard >= work * 60 * 0.3) return r('delno', `Prag samo delno — ${Math.round((mid + hard) / 60)} min v tempu ali više (cilj ~${work}).`)
      return r('drugace', 'Pražnega treninga ni bilo — bila je lahka vožnja.')
    case 'test':
      if (hard >= 12 * 60) return r('ok', 'Test opravljen — vpiši rezultat v Napredek ✓')
      return hard >= 6 * 60 ? r('delno', 'Test ni bil do konca — utrip ni bil dovolj dolgo visok.') : r('drugace', `Testa ni bilo — ${easyPct! >= 70 ? 'bila je lahka (Z2) vožnja' : 'bila je vožnja v tempu'}.`)
    case 'dolga':
      return min >= plan.durationMin * 0.8 ? r('ok', 'Dolga vožnja opravljena ✓') : r(min >= plan.durationMin * 0.5 ? 'delno' : 'drugace', `Krajše od načrta (${fmtDur(min)} od ${fmtDur(plan.durationMin)}).`)
    case 'regen':
      return easyPct! >= 90 && min <= plan.durationMin * 1.4 ? r('ok', 'Regeneracija ✓') : r('delno', 'Pretrdo ali predolgo za regeneracijo — naslednji ključni trening bo trpel.')
    default:
      if ((mid + hard) / tot > 0.25) return r('delno', `Pretežko za Z2 — ${100 - easyPct!} % časa nad Z2. Lahki dnevi naj bodo res lahki.`)
      return min >= plan.durationMin * 0.6 ? r('ok', 'Z2 opravljena ✓') : r('delno', `Krajše od načrta (${fmtDur(min)} od ${fmtDur(plan.durationMin)}).`)
  }
}

/** Ključni treningi (VO2max, prag, test, dolga) v obdobju: koliko jih je bilo res opravljenih. */
export function keyCompliance(plan: readonly PlanDay[], acts: readonly Activity[], from: string, to: string): { ok: number; total: number; items: { date: string; title: string; status: RideCheck['status'] | 'ni' }[] } {
  const items: { date: string; title: string; status: RideCheck['status'] | 'ni' }[] = []
  for (const d of plan.filter(x => x.date >= from && x.date <= to && !x.optional && (x.role === 'kljucna' || x.role === 'test' || x.role === 'dolga')).sort((a, b) => a.date.localeCompare(b.date))) {
    const a = d.done?.activityId ? acts.find(x => x.id === d.done!.activityId) : acts.find(x => bike(x) && x.date === d.date)
    const c = a ? checkRide(d, a) : null
    items.push({ date: d.date, title: d.title, status: c ? c.status : d.done ? 'ok' : 'ni' })
  }
  return { ok: items.filter(x => x.status === 'ok').length, total: items.length, items }
}

/** Aerobna učinkovitost brez merilnika moči: km/h na 100 udarcev na ravnih vožnjah (≥ 45 min, ne trenažer). */
export function efTrend(acts: readonly Activity[], today: string, weeks = 12): { weekStart: string; ef: number; n: number }[] {
  const ws = weekStartIso(today), out: { weekStart: string; ef: number; n: number }[] = []
  for (let k = weeks - 1; k >= 0; k--) {
    const s = addDays(ws, -7 * k), e = addDays(s, 6)
    const r = acts.filter(a => bike(a) && !a.trainer && a.date >= s && a.date <= e && (a.durationMin || 0) >= 45 && (a.avgHr || 0) >= 100 && a.speedKmh && a.distKm && (a.elevM || 0) / a.distKm <= 8)
    if (!r.length) continue
    const ef = r.reduce((t, a) => t + (a.speedKmh! / a.avgHr!) * 100, 0) / r.length
    out.push({ weekStart: s, ef: +ef.toFixed(1), n: r.length })
  }
  return out
}

/** Merilnik moči: true, če je vsaj ena vožnja v 120 dneh z izmerjeno močjo; false, če ≥ 3 vožnje brez; sicer ne vemo. */
export function powerMeterFrom(acts: readonly Activity[], today: string): boolean | null {
  const r = acts.filter(a => bike(a) && a.date >= addDays(today, -120) && a.deviceWatts != null)
  if (r.some(a => a.deviceWatts)) return true
  return r.filter(a => a.deviceWatts === false).length >= 3 ? false : null
}

/**
 * Prestavi ključni trening, ki danes ni bil narejen, na naslednji lahki dan tega tedna (ne jutri, če je jutri prav tako ključni).
 * Vrne oba dneva z zamenjano vsebino (datum in »opravljeno« ostaneta).
 */
export function moveKeySession(week: readonly PlanDay[], from: PlanDay, today: string): [PlanDay, PlanDay] | null {
  const end = addDays(weekStartIso(today), 6)
  const cands = week.filter(d => d.date > today && d.date <= end && !d.done && !d.optional && d.kind === 'kolo' && (d.role === 'lahka' || d.role === 'regen'))
    .sort((a, b) => a.date.localeCompare(b.date))
  const keyDates = new Set(week.filter(d => d.role === 'kljucna' || d.role === 'test' || d.role === 'dolga').map(d => d.date))
  const pick = cands.find(d => !keyDates.has(addDays(d.date, -1)) && !keyDates.has(addDays(d.date, 1)) && d.date > addDays(today, 1)) || cands.find(d => d.date > addDays(today, 1)) || cands[0]
  if (!pick) return null
  const content = (d: PlanDay) => ({ kind: d.kind, title: d.title, desc: d.desc, durationMin: d.durationMin, zone: d.zone ?? null, tssTarget: d.tssTarget ?? null, role: d.role ?? null, target: d.target ?? null, kcalBurn: d.kcalBurn ?? null, why: d.why ?? null })
  const now = new Date().toISOString()
  return [{ ...from, ...content(pick), updatedAt: now }, { ...pick, ...content(from), updatedAt: now }]
}

/** Kratek povzetek za AI trenerja in kartico v Napredku. */
export function realitySummary(p: Pick<Profile, 'hoursPerWeek' | 'gear'>, acts: readonly Activity[], plan: readonly PlanDay[], today: string): string[] {
  const L: string[] = []
  const bw = bikeWeeks(acts, today, 8), base = baselineHours(acts, today, 8)
  if (base != null) L.push(`Dejansko na kolesu zadnjih ${bw.full.length} polnih tednov: povprečno ${String(base).replace('.', ',')} h na teden (${bw.full.map(w => String(w.hours).replace('.', ',')).join(' · ')} h); ta teden doslej ${String(bw.current.hours).replace('.', ',')} h. Ciljne ure v načrtu: ${p.hoursPerWeek ?? '?'} h.`)
  const zs = zoneSplit(acts.filter(a => a.date >= addDays(today, -28)))
  if (zs) L.push(`Utrip zadnje 4 tedne (${zs.minutes} min z utripom): ${zs.easy} % lahko (Z1–Z2), ${zs.mid} % tempo (Z3), ${zs.hard} % prag in više — cilj je ~80 % lahko.`)
  const kc = keyCompliance(plan, acts, addDays(today, -14), addDays(today, -1))
  if (kc.total) L.push(`Ključni treningi zadnja 2 tedna: opravljenih po načrtu ${kc.ok} od ${kc.total} (${kc.items.map(i => `${i.date.slice(5)} ${i.title}: ${i.status === 'ok' ? 'da' : i.status === 'delno' ? 'delno' : i.status === 'drugace' ? 'drugače' : 'ni'}`).join('; ')}).`)
  const ef = efTrend(acts, today, 12)
  if (ef.length >= 3) L.push(`Aerobna učinkovitost (km/h na 100 udarcev, ravne vožnje): prej ${String(ef[0]!.ef).replace('.', ',')}, zdaj ${String(ef[ef.length - 1]!.ef).replace('.', ',')}.`)
  const pm = p.gear?.powerMeter
  if (pm === false) L.push('Nima merilnika moči: vati v načrtu so samo orientacija — vodi po utripu in občutku (RPE).')
  return L
}
