import type { Profile } from '../types'
import { weekStartIso } from './load'
import { OFF_MAX } from './season'

/**
 * SPREMEMBA CILJA SEZONE — tudi sredi off-seasona. Prej je potrditev istega cilja med off-seasonom pustila off-season
 * (načrt se ni spremenil: še vedno hribi in počitek). Zdaj izbereš: končaj off-season (osnova začne ta teden z lahkimi
 * tedni) ali ostani v off-seasonu do konca (nov cilj ga ne pobriše). Izven off-seasona: isti cilj = makrocikel teče
 * naprej, nov datum = nov makrocikel od tega tedna.
 */

const WEEK = 7 * 86_400_000

export interface OffNow { week: number; of: number; left: number }

/** Ali je ta teden off-season in kje v njem (teden od skupaj, preostali tedni z današnjim). null = ni off-season. */
export function offSeasonNow(p: Pick<Profile, 'cycleStart' | 'offSeasonWeeks'>, today: string): OffNow | null {
  if (!p.cycleStart) return null
  const of = Math.max(0, Math.min(OFF_MAX, Math.round(p.offSeasonWeeks ?? 0)))
  if (!of) return null
  const ws = weekStartIso(today)
  const since = Math.max(0, Math.round((Date.parse(ws + 'T12:00:00Z') - Date.parse(p.cycleStart + 'T12:00:00Z')) / WEEK))
  if (since >= of) return null
  return { week: since + 1, of, left: of - since }
}

/**
 * Del profila za makrocikel ob potrditvi cilja: cycleStart in offSeasonWeeks (ostala polja nastavi klicatelj).
 * keep = isti cilj (datum) in že začet makrocikel — teče naprej; firstWeek = prvi teden novega načrta.
 */
export function cyclePatch(p: Pick<Profile, 'cycleStart' | 'offSeasonWeeks' | 'event'>, goalDate: string, today: string, endOff: boolean):
  { patch: Pick<Profile, 'cycleStart'> & Partial<Pick<Profile, 'offSeasonWeeks'>>; keep: boolean; firstWeek: boolean; endedOff: boolean } {
  const ws = weekStartIso(today)
  const keep = !!p.cycleStart && p.event?.date === goalDate && p.cycleStart <= ws
  const off = offSeasonNow(p, today)
  if (!off) return { patch: { cycleStart: keep ? p.cycleStart! : ws, ...(keep ? {} : { offSeasonWeeks: 0 }) }, keep, firstWeek: !keep, endedOff: false }
  if (endOff) {
    // osnova začne ta teden: off-season = že minuli tedni (isti cilj) ali nov makrocikel brez off-seasona (nov cilj)
    return keep
      ? { patch: { cycleStart: p.cycleStart!, offSeasonWeeks: off.week - 1 }, keep, firstWeek: true, endedOff: true }
      : { patch: { cycleStart: ws, offSeasonWeeks: 0 }, keep, firstWeek: true, endedOff: true }
  }
  // ostani v off-seasonu: isti cilj nič ne spremeni; nov cilj začne makrocikel ta teden s preostankom off-seasona
  return keep
    ? { patch: { cycleStart: p.cycleStart! }, keep, firstWeek: false, endedOff: false }
    : { patch: { cycleStart: ws, offSeasonWeeks: off.left }, keep, firstWeek: true, endedOff: false }
}
