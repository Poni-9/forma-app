import type { PlanDay, Profile } from '../types'
import { kindLabelPlain } from './labels'

/** (v3.50) Ura začetka po »kdaj treniraš«: zjutraj 7:00, popoldne 16:30, zvečer 18:30, neznano 17:00. */
export function icsStartMinutes(trainTime: Profile['trainTime'] | undefined): number {
  return trainTime === 'zjutraj' ? 7 * 60 : trainTime === 'popoldne' ? 16 * 60 + 30 : trainTime === 'zvecer' ? 18 * 60 + 30 : 17 * 60
}
const hhmm = (min: number) => `${String(Math.floor(min / 60)).padStart(2, '0')}${String(min % 60).padStart(2, '0')}00`

/**
 * Teden načrta kot .ics — uporabnik ga uvozi v Google/Apple koledar. Brez strežnika, brez računa.
 * (v3.50) Ura iz »kdaj treniraš«; druga seja istega dne (moč) 10 min po koncu prve (prej sta se prekrivali ob 17:00 in
 * 18:00); tekma ob 8:00 kot »Tekma: …«; opravljeni dnevi izpuščeni; v opisu ni razlage tedna (»Zakaj«).
 */
export function weekToIcs(days: readonly PlanDay[], o: { trainTime?: Profile['trainTime'] } | number = {}): string {
  const startMin = typeof o === 'number' ? o * 60 : icsStartMinutes(o.trainTime)
  const esc = (s: string) => s.replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\n/g, '\\n')
  const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '')
  const lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//FORMAI//SL', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH', 'X-WR-CALNAME:FORMAI trening']
  // kolo/tek/test pred močjo, tekma prva — vrstni red shrambe ni vrstni red dneva
  const order = (d: PlanDay) => (d.role === 'dirka' ? 0 : d.kind === 'moc' ? 2 : 1)
  const sorted = [...days].filter(d => d.kind !== 'pocitek' && d.durationMin && !d.done).sort((a, b) => a.date.localeCompare(b.date) || order(a) - order(b))
  const endAt = new Map<string, number>()   // konec zadnje seje dneva (min od polnoči)
  for (const d of sorted) {
    const race = d.role === 'dirka'
    const prev = endAt.get(d.date)
    const start = race ? 8 * 60 : prev != null ? prev + 10 : startMin
    const end = start + d.durationMin
    endAt.set(d.date, end)
    const ymd = d.date.replace(/-/g, '')
    // konec čez polnoč: datum naslednjega dne
    const endDate = new Date(`${d.date}T00:00:00`); endDate.setMinutes(end)
    const endYmd = `${endDate.getFullYear()}${String(endDate.getMonth() + 1).padStart(2, '0')}${String(endDate.getDate()).padStart(2, '0')}`
    const desc = [d.desc, d.zone ? `Cona: ${d.zone}` : '', d.tssTarget ? `Cilj: ${d.tssTarget} TSS` : '', d.exercises ? d.exercises.map(e => `• ${e.name} ${e.sets} × ${e.reps}`).join('\n') : '', 'formai.si'].filter(Boolean).join('\n')
    lines.push('BEGIN:VEVENT', `UID:${d.id}@formai.si`, `DTSTAMP:${stamp}`, `DTSTART:${ymd}T${hhmm(start)}`, `DTEND:${endYmd}T${hhmm(end % 1440)}`,
      `SUMMARY:${esc(`${race ? 'Tekma' : kindLabelPlain(d.kind)}: ${d.title}`)}`, `DESCRIPTION:${esc(desc)}`, 'END:VEVENT')
  }
  lines.push('END:VCALENDAR')
  return lines.join('\r\n')
}

/** (v3.51) Koliko dogodkov gre v koledar (ne počitek, ne opravljeno, ne brez trajanja). */
export const icsCount = (days: readonly PlanDay[]): number => days.filter(d => d.kind !== 'pocitek' && d.durationMin && !d.done).length
/** Prenese .ics; (v3.51) brez dogodkov ne prenese nič in vrne 0 (prej prazen koledar brez obvestila). */
export function downloadIcs(days: readonly PlanDay[], name = 'formai-teden.ics', o: { trainTime?: Profile['trainTime'] } = {}): number {
  const n = icsCount(days)
  if (!n) return 0
  const blob = new Blob([weekToIcs(days, o)], { type: 'text/calendar;charset=utf-8' })
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; a.click()
  setTimeout(() => URL.revokeObjectURL(a.href), 5000)
  return n
}
