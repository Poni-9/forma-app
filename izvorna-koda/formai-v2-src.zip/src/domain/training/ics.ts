import type { PlanDay } from '../types'
import { kindLabelPlain } from './labels'

/** Teden načrta kot .ics — uporabnik ga uvozi v Google/Apple koledar. Brez strežnika, brez računa. */
export function weekToIcs(days: readonly PlanDay[], defaultHour = 17): string {
  const esc = (s: string) => s.replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\n/g, '\\n')
  const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '')
  const lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//FORMAI//SL', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH', 'X-WR-CALNAME:FORMAI trening']
  for (const d of days) {
    if (d.kind === 'pocitek' || !d.durationMin) continue
    const ymd = d.date.replace(/-/g, '')
    const hh = String(d.kind === 'moc' ? 18 : defaultHour).padStart(2, '0')
    const end = new Date(`${d.date}T${hh}:00:00`); end.setMinutes(end.getMinutes() + d.durationMin)
    const endStr = `${end.getFullYear()}${String(end.getMonth() + 1).padStart(2, '0')}${String(end.getDate()).padStart(2, '0')}T${String(end.getHours()).padStart(2, '0')}${String(end.getMinutes()).padStart(2, '0')}00`
    const desc = [d.desc, d.zone ? `Cona: ${d.zone}` : '', d.tssTarget ? `Cilj: ${d.tssTarget} TSS` : '', d.exercises ? d.exercises.map(e => `• ${e.name} ${e.sets} × ${e.reps}`).join('\n') : '', d.why ? `Zakaj: ${d.why}` : '', 'formai.si'].filter(Boolean).join('\n')
    lines.push('BEGIN:VEVENT', `UID:${d.id}@formai.si`, `DTSTAMP:${stamp}`, `DTSTART:${ymd}T${hh}0000`, `DTEND:${endStr}`,
      `SUMMARY:${esc(`${kindLabelPlain(d.kind)}: ${d.title}`)}`, `DESCRIPTION:${esc(desc)}`, 'END:VEVENT')
  }
  lines.push('END:VCALENDAR')
  return lines.join('\r\n')
}

export function downloadIcs(days: readonly PlanDay[], name = 'formai-teden.ics'): void {
  const blob = new Blob([weekToIcs(days)], { type: 'text/calendar;charset=utf-8' })
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; a.click()
  setTimeout(() => URL.revokeObjectURL(a.href), 5000)
}
