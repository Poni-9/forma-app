import type { PlanDay } from '../types'
import type { RaceLock } from './protect'

/**
 * PREMIK TRENINGA NA DRUG DAN. »Danes ne morem, v četrtek bom« — uporabnik izbere dan, seja zamenja mesto s tisto,
 * ki je tam (ali s počitkom). Datum, id, opravljeno in tekma ostanejo pri dnevu; vsebina gre tja in nazaj.
 * Samo prihodnji dnevi, ne opravljeni in ne dan tekme. Vse je mogoče razveljaviti (shranita se prejšnja zapisa).
 */

const CONTENT = ['kind', 'title', 'desc', 'durationMin', 'zone', 'tssTarget', 'role', 'target', 'kcalBurn', 'why', 'optional', 'exercises', 'tail', 'swap', 'source'] as const
type ContentKey = typeof CONTENT[number]

function contentOf(d: PlanDay): Pick<PlanDay, ContentKey> {
  const out = {} as Record<string, unknown>
  for (const k of CONTENT) if (k in d) out[k] = d[k]
  return out as Pick<PlanDay, ContentKey>
}

/** Ali se seja sme premakniti (prihodnji dan, ni opravljena, ni tekma, ni počitek). */
export function canMove(d: PlanDay, today: string, lock?: RaceLock): boolean {
  // dan pred tekmo (predaktivacija) in polnjenje z OH ostaneta: menjava bi tja pripeljala drug trening
  return d.date >= today && !d.done && !d.raceId && d.role !== 'dirka' && d.kind !== 'pocitek' && !lock?.has(d.date)
}

/** Ali je dan primeren cilj premika (prihodnji, ni opravljen, ni tekma, drug datum). */
export function canReceive(d: PlanDay, from: PlanDay, today: string): boolean {
  return d.date !== from.date && d.date >= today && !d.done && !d.raceId && d.role !== 'dirka' && !d.sickPrev   // ne na dan bolezni
}

/**
 * S katero sejo na ciljnem datumu se zamenja: iste vrste, če je; sicer glavna seja dneva (ne moč); sicer katerakoli.
 */
export function partnerOn(plan: readonly PlanDay[], from: PlanDay, date: string, today: string): PlanDay | null {
  const there = plan.filter(d => d.date === date && canReceive(d, from, today))
  if (!there.length) return null
  return there.find(d => d.kind === from.kind) ?? there.find(d => d.kind !== 'moc') ?? there[0]!
}

/** Zamenjaj vsebino dveh dni; vrne oba za shranitev (prejšnja zapisa shrani klicatelj za razveljavitev). */
export function swapDays(a: PlanDay, b: PlanDay): [PlanDay, PlanDay] {
  const now = new Date().toISOString()
  const ca = contentOf(a), cb = contentOf(b)
  const strip = (d: PlanDay): PlanDay => { const { kind: _k, title: _t, desc: _d, durationMin: _m, zone: _z, tssTarget: _s, role: _r, target: _g, kcalBurn: _c, why: _w, optional: _o, exercises: _e, tail: _tl, swap: _p, source: _u, adapt: _ad, ...rest } = d; return rest as PlanDay }
  return [
    { ...strip(a), ...cb, adapt: null, updatedAt: now },
    { ...strip(b), ...ca, adapt: null, updatedAt: now },
  ]
}

/** Dnevi, kamor je sejo mogoče premakniti: od danes do konca naslednjega tedna, ki so v načrtu. */
export function moveTargets(plan: readonly PlanDay[], from: PlanDay, today: string, until: string, lock?: RaceLock): { date: string; partner: PlanDay }[] {
  const dates = [...new Set(plan.filter(d => d.date >= today && d.date <= until && !lock?.has(d.date)).map(d => d.date))].sort()
  const out: { date: string; partner: PlanDay }[] = []
  for (const date of dates) { const partner = partnerOn(plan, from, date, today); if (partner) out.push({ date, partner }) }
  return out
}
