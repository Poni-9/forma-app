import type { PlanDay, Profile } from '../types'
import { zoneText, workText, noPower, lthrZoneText } from './zones'

/**
 * Trening kot zaporedje korakov za izvajalnik s časovnikom.
 * Iz opisa (sicer naslova) dneva razberemo strukturo — »4 × 6 min«, »3 serije × 13 × (30 s / 15 s)«, »6 × 10 s šprint«,
 * »6 × (4 min tek / 2 min hoja)« — in jo postavimo v vožnjo (takoj po ogrevanju, na sredi, v drugi uri ali na koncu);
 * preostanek do načrtovanega trajanja je Z2, da se trening na uri konča ob istem času kot v načrtu.
 * Brez strukture: ogrevanje → enakomerno → iztek. Moč: vaje × serije s pavzo.
 */
export type StepKind = 'ogrevanje' | 'delo' | 'lahko' | 'iztek' | 'vaja' | 'pavza' | 'test'
export interface Step {
  kind: StepKind
  label: string
  /** trajanje v sekundah; 0 = brez časovnika (vaja, ki jo potrdiš) */
  sec: number
  target?: string | null
  note?: string
  /** cona koraka — za izvoz na uro (intervals.icu → Garmin) */
  z?: 'Z1' | 'Z2' | 'Z3' | 'Z4' | 'Z5' | 'max'
  /** za moč; pri intervalih: ponovitev v bloku (seriji) */
  set?: number
  sets?: number
  reps?: string
  /** blok intervalov (vsi koraki istega niza imajo isto številko) */
  group?: number
  /** serija v bloku (30/15: 3 serije × 13) */
  series?: number
  seriesOf?: number
  /** ciljna moč kot delež FTP [od, do], razbrana iz opisa seje (za uro v vatih) */
  ftpShare?: [number, number]
}

const SEC = 60
type Zn = 'Z1' | 'Z2' | 'Z3' | 'Z4' | 'Z5'
type Z = NonNullable<Step['z']>
const zone = (p: Profile, z: Zn) => zoneText(p, z)

/** Kako naj se počuti — RPE (1–10), dihanje, kadenca. */
export const CUE: Record<string, string> = {
  ogrevanje: 'Lahko, kadenca 85–95. Zadnjih 5 min 3 × 30 s hitreje, da odpreš noge.',
  Z1: 'Zelo lahko (RPE 2/10) — noge samo vrtijo, dihanje umirjeno.',
  Z2: 'RPE 3–4/10 — pogovarjaš se v celih stavkih, dihaš skozi nos. Kadenca 85–95.',
  Z3: 'RPE 7/10 — lahko rečeš stavek, noge počasi gorijo. Kadenca 85–95, ramena sproščena.',
  Z4: 'RPE 8/10 — samo kratke besede. Enakomerno, kadenca 85–95.',
  Z5: 'RPE 9/10 — dihaš hitro in globoko, a zdržiš do konca. Sede, kadenca 95–105.',
  max: 'RPE 10/10 — vse, kar gre, s tehniko: sede ali stoje, visoka kadenca. Potem res lahko.',
  tempo: 'RPE 6/10 — enakomerno, kot tempo skupine na ravnini. Jej pred blokom.',
  kadenca: 'Lahko, brez sile — samo hitre noge, zgornji del telesa miren.',
  nizka: 'Sede, sila v pedalih, dihanje mirno — ne v utrip.',
  odmor: 'Vrti lahko, 2–3 požirke. Pripravi se na naslednjega.',
  iztek: 'Zelo lahko, noge vrtijo. Pij. Po treningu v 45 min beljakovine in OH.',
}
/** Tehnika vaj za moč. */
export const HOW: Record<string, string> = {
  'Deska': 'Komolci pod rameni, telo v ravni črti, stisni zadnjico in trebuh, ne povesi bokov.',
  'Stranska deska': 'Komolec pod ramo, boki visoko, telo v ravni črti — vsaka stran posebej.',
  'Dvig nog leže': 'Križ pritisnjen v tla, noge počasi dol do 10 cm nad tlemi in nazaj.',
  'Dead bug': 'Križ v tleh; nasprotno roko in nogo počasi iztegni, izdihni, zamenjaj.',
  'Bolgarski počep': 'Zadnja noga na stolu, sprednje koleno nad prsti, spusti se navpično do 90°, poriv skozi peto.',
  'Izpadni koraki': 'Dolg korak, zadnje koleno skoraj do tal, trup pokončen, izmenično.',
  'Dvigi na prste': 'Na robu stopnice: gor hitro, 2 s dol, polna amplituda.',
}

/** »30 s«, »4 min«, »4 min 30 s« (kratki koraki), dolgi zaokroženi na minute. */
export function fmtStep(sec: number): string {
  const s = Math.max(0, Math.round(sec))
  if (s < 60) return `${s} s`
  if (s % 60 === 0) return `${s / 60} min`
  return s < 600 ? `${Math.floor(s / 60)} min ${s % 60} s` : `${Math.round(s / 60)} min`
}
const serije = (n: number) => (n === 2 ? 'seriji' : n <= 4 ? 'serije' : 'serij')

/** Kratek povzetek strukture za pregled pred treningom: »20 min ogrevanje · 4 × 4 min 259–276 W, vmes 4 min · …«. */
export function structureLines(steps: readonly Step[]): string[] {
  const out: string[] = []
  const tgt = (s: Step) => (s.target ? (/^(utrip|RPE|vse)/.test(s.target) ? ` (${s.target})` : ` pri ${s.target}`) : '')
  for (let i = 0; i < steps.length; i++) {
    const s = steps[i]!
    if (s.kind === 'delo' && s.group != null && s.set === 1 && (s.series ?? 1) === 1) {
      // cel blok (vse serije) v eni vrstici
      let j = i
      while (j + 1 < steps.length && steps[j + 1]!.group === s.group) j++
      const n = s.sets ?? 1
      const rest = n > 1 && steps[i + 1]?.kind === 'lahko' && steps[i + 1]!.group === s.group ? steps[i + 1]!.sec : 0
      const one = n > 1 ? `${n} × ${fmtStep(s.sec)}${tgt(s)}${rest ? `, vmes ${fmtStep(rest)} lahko` : ''}` : `${fmtStep(s.sec)} ${s.label.toLowerCase()}${tgt(s)}`
      const S = s.seriesOf ?? 1
      const sr = S > 1 ? steps.slice(i, j + 1).find(x => x.kind === 'lahko' && /^Med serij/.test(x.label))?.sec ?? 0 : 0
      out.push(S > 1 ? `${S} ${serije(S)} × ${one}${sr ? `; med ${S === 2 ? 'serijama' : 'serijami'} ${fmtStep(sr)} lahko` : ''}` : one)
      i = j
      continue
    }
    if (s.kind === 'delo' && s.sets && s.sets > 1 && s.set === 1) {
      const rest = steps[i + 1]?.kind === 'lahko' ? steps[i + 1]!.sec : 0
      out.push(`${s.sets} × ${fmtStep(s.sec)}${tgt(s)}${rest ? `, vmes ${fmtStep(rest)} lahko` : ''}`)
      while (i + 1 < steps.length && ((steps[i + 1]!.kind === 'delo' && (steps[i + 1]!.set ?? 0) > 1) || (steps[i + 1]!.kind === 'lahko' && steps[i + 2]?.kind === 'delo' && (steps[i + 2]!.set ?? 0) > 1))) i++
      continue
    }
    if (s.kind === 'vaja') { if (s.set === 1) out.push(`${s.label}: ${s.sets} × ${s.reps}`); continue }
    if (s.kind === 'pavza') continue
    out.push(`${s.sec ? fmtStep(s.sec) + ' ' : ''}${s.kind === 'ogrevanje' ? 'ogrevanje' : s.kind === 'iztek' ? 'iztek' : s.label}${s.target ? ` (${s.target})` : ''}`)
  }
  return out
}

/* ---------- razbiranje strukture iz besedila ---------- */
type Where = 'start' | 'middle' | 'hour2' | 'end'
interface Drill {
  at: number; end: number
  series: number; reps: number; work: number
  /** odmor med ponovitvami (s); null = ni zapisan */
  rest: number | null
  seriesRest: number
  /** besedilo intenzivnosti (»pri 259–276 W (108–115 % FTP)«, »šprint — vse, kar gre«) */
  txt: string
  where: Where | null
  walkRun: boolean
}
const DUR = String.raw`\d+\s*min(?:\s+\d+\s*s)?|\d+\s*s`
/** serije × ponovitve × (delo / odmor): »3 serije × 13 × (30 s pri … / 15 s lahko)«, »6 × (4 min tek / 2 min hoja)« */
const RE_REPS = new RegExp(String.raw`(?:(\d+)\s*serij[aei]?\s*×\s*)?(\d+)\s*×\s*\(\s*(${DUR})\b((?:[^()/]|\([^()]*\))*?)\/\s*(${DUR})\b([^()]*?)\)`, 'g')
/** »4 × 6 min«, »2 × 15 min tempo« (ne »3 × (2 min …«) */
const RE_MIN = /(\d+)\s*×\s*(\d+(?:[.,]\d+)?)\s*min\b(?!\s*\d+\s*s\b)/g
/** »6 × 10 s šprint«, »4 × 30 s hitra kadenca« */
const RE_SEC = /(\d+)\s*×\s*(\d+)\s*s\b/g
const secOf = (t: string): number => {
  const m = /(\d+)\s*min(?:\s+(\d+)\s*s)?/.exec(t)
  if (m) return +m[1]! * 60 + (m[2] ? +m[2] : 0)
  const q = /(\d+)\s*s/.exec(t)
  return q ? +q[1]! : 0
}
/** Konec stavka: pika, ki ji sledi velika začetnica ali konec besedila (»od 30. minute« ni konec). */
function sentenceBounds(text: string): number[] {
  const out: number[] = []
  const re = /\.(?=\s+[A-ZČŠŽĆĐ]|\s*$)/g
  for (let m = re.exec(text); m; m = re.exec(text)) out.push(m.index)
  return out
}
function whereIn(t: string): Where | null {
  if (/na sredi/i.test(t)) return 'middle'
  if (/v drugi uri/i.test(t)) return 'hour2'
  if (/v zadnji uri|na koncu/i.test(t)) return 'end'
  return null
}
/** Odmor »vmes 4 min«, »(vmes 4–5 min zelo lahko)«, »vmes 4 min 30 s«; povprečje razpona. */
function restIn(t: string): number | null {
  const m = /vmes\s+(?:navzdol\s+)?(\d+(?:[.,]\d+)?)(?:\s*[–-]\s*(\d+(?:[.,]\d+)?))?\s*min(?:\s+(\d+)\s*s)?/i.exec(t)
  if (!m) return null
  const a = +m[1]!.replace(',', '.'), b = m[2] ? +m[2].replace(',', '.') : a
  return Math.round(((a + b) / 2) * 60) + (m[3] ? +m[3] : 0)
}

function parseDrills(text: string): Drill[] {
  const found: Drill[] = []
  const taken: [number, number][] = []
  const free = (a: number, b: number) => taken.every(([x, y]) => b <= x || a >= y)
  for (const m of text.matchAll(RE_REPS)) {
    const at = m.index!, end = at + m[0].length
    taken.push([at, end])
    found.push({ at, end, series: m[1] ? Math.max(1, +m[1]) : 1, reps: +m[2]!, work: secOf(m[3]!), rest: secOf(m[5]!), seriesRest: 0, txt: m[4] || '', where: null, walkRun: /hoja/i.test(m[6] || '') })
  }
  for (const m of text.matchAll(RE_MIN)) {
    const at = m.index!, end = at + m[0].length
    if (!free(at, end)) continue
    taken.push([at, end])
    found.push({ at, end, series: 1, reps: +m[1]!, work: Math.round(+m[2]!.replace(',', '.') * 60), rest: null, seriesRest: 0, txt: '', where: null, walkRun: false })
  }
  for (const m of text.matchAll(RE_SEC)) {
    const at = m.index!, end = at + m[0].length
    if (!free(at, end)) continue
    taken.push([at, end])
    found.push({ at, end, series: 1, reps: +m[1]!, work: +m[2]!, rest: null, seriesRest: 0, txt: '', where: null, walkRun: false })
  }
  const list = found.filter(d => d.reps >= 1 && d.reps <= 60 && d.work > 0 && d.series <= 10).sort((a, b) => a.at - b.at)
  const ends = sentenceBounds(text)
  list.forEach((d, k) => {
    const sEnd = ends.find(e => e >= d.end) ?? text.length
    const sStart = [...ends].reverse().find(e => e < d.at) ?? -1
    const next = list[k + 1] && list[k + 1]!.at < sEnd ? list[k + 1]!.at : sEnd
    const after = text.slice(d.end, sEnd)
    if (!d.txt) { const t = text.slice(d.end, next); const v = t.search(/vmes/i); d.txt = v >= 0 ? t.slice(0, v) : t }
    if (d.rest == null) d.rest = restIn(after)
    if (d.series > 1) { const sr = /med\s+serijam[ai]\s+(\d+)\s*min(?:\s+(\d+)\s*s)?/i.exec(after); d.seriesRest = sr ? +sr[1]! * 60 + (sr[2] ? +sr[2] : 0) : 180 }
    const prevEnd = k && list[k - 1]!.end > sStart ? list[k - 1]!.end : sStart + 1
    d.where = whereIn(text.slice(prevEnd, d.at)) ?? whereIn(text.slice(d.end, next)) ?? (k && list[k - 1]!.end > sStart ? list[k - 1]!.where : null)
  })
  return list
}

/** Odmor med ponovitvami: zapisan, sicer kratke (≤ 60 s) 4 min, ključni ~60 % dela, v Z2 vožnji 5 min (10 min pri blokih ≥ 15 min). */
function drillRest(d: Drill, key: boolean): number {
  return d.rest ?? (d.work <= 60 ? 240 : key ? Math.max(60, Math.round((d.work * 0.6) / 60) * 60) : d.work >= 15 * SEC ? 10 * SEC : 5 * SEC)
}

/**
 * Najkrajše smiselno trajanje seje s strukturo (min): bloki z odmori + 5 min ogrevanja in 5 min izvoza, na 5 min navzgor;
 * 0 brez strukture. Načrt seje ne skrajša pod to (sicer bi se ponovitve na uri izšle čez načrtovani čas).
 */
export function minMinutes(day: Pick<PlanDay, 'title' | 'desc'> & { role?: PlanDay['role'] | null }): number {
  const fromDesc = parseDrills(day.desc || '')
  const drills = fromDesc.length ? fromDesc : parseDrills(day.title || '')
  if (!drills.length) return 0
  const key = day.role === 'kljucna' || /\d+\s*min ogrevanj/i.test(fromDesc.length ? day.desc || '' : day.title || '')
  let sec = 0
  drills.forEach((d, k) => {
    const r = drillRest(d, key)
    sec += d.series * (d.reps * d.work + (d.reps - 1) * r) + (d.series - 1) * d.seriesRest
    if (k) sec += drillRest(drills[k - 1]!, key)
  })
  return Math.ceil((sec / 60 + 10) / 5) * 5
}

/** Intenzivnost ponovitev iz besedila: vati ali % FTP → delež FTP in cona; sicer ključne besede. */
function intensity(txt: string, p: Profile): { share: [number, number] | null; open: boolean; z: Z | null; kind: 'kadenca' | 'nizka' | 'tempo' | 'sprint' | null; cad: string | null } {
  const cadM = /(\d+\s*[–-]\s*\d+|\d+\+?)\s*obrat/.exec(txt)
  const cad = cadM ? cadM[1]!.replace(/\s+/g, '') : null
  const kind = cad ? (+(cad.match(/\d+/g)?.pop() ?? 90) <= 80 ? 'nizka' : 'kadenca') : /kadenc/i.test(txt) ? 'kadenca' : /šprint|vse, kar gre|napad/i.test(txt) ? 'sprint' : /tempo/i.test(txt) ? 'tempo' : null
  const ftp = p.ftp && p.ftp > 0 ? p.ftp : null
  let share: [number, number] | null = null, open = false
  const w2 = /(\d{2,4})\s*[–-]\s*(\d{2,4})\s*W\b/.exec(txt), pc2 = /(\d{2,3})\s*[–-]\s*(\d{2,3})\s*%\s*FTP/.exec(txt)
  const w1 = /(\d{2,4})\s*W\s+in\s+več/.exec(txt), pc1 = /nad\s+(\d{2,3})\s*%\s*FTP/.exec(txt)
  if (w2 && ftp) share = [+w2[1]! / ftp, +w2[2]! / ftp]
  else if (pc2) share = [+pc2[1]! / 100, +pc2[2]! / 100]
  else if (w1 && ftp) { share = [+w1[1]! / ftp, (+w1[1]! / ftp) * 1.3]; open = true }
  else if (pc1) { share = [+pc1[1]! / 100, (+pc1[1]! / 100) * 1.3]; open = true }
  let z: Z | null = null
  if (share) { const m = (share[0] + share[1]) / 2; z = m < 0.56 ? 'Z1' : m < 0.76 ? 'Z2' : m < 0.91 ? 'Z3' : m < 1.06 ? 'Z4' : m < 1.5 ? 'Z5' : 'max' }
  else if (kind === 'kadenca' || kind === 'nizka') z = 'Z2'
  else if (kind === 'sprint') z = 'max'
  else if (kind === 'tempo') z = 'Z3'
  else { const r = /RPE\s*(\d+)/.exec(txt); if (r) z = +r[1]! >= 9 ? 'Z5' : +r[1]! >= 8 ? 'Z4' : 'Z3' }
  return { share, open, z, kind, cad }
}

export function stepsFor(day: PlanDay, p: Profile): Step[] {
  if (day.kind === 'pocitek') return []
  if (day.kind === 'moc') return strengthSteps(day)
  const dur = Math.max(10, Number.isFinite(day.durationMin) ? day.durationMin : 0)
  const total = dur * SEC

  // 20-minutni test — samo, kadar je dan res test (ne »2 × 20 min« praga ali Kladja)
  if (day.kind === 'test' || day.role === 'test') {
    const wu = day.kind === 'tek' ? 10 : 15
    const easy = dur - wu - 20 >= 15 ? 5 : 0                     // »5 min lahko« pred testom, če je čas
    return [
      { kind: 'ogrevanje', z: 'Z2', label: 'Ogrevanje', sec: wu * SEC, target: zone(p, 'Z2'), note: 'Zadnjih 5 min nekaj kratkih pospeškov.' },
      ...(easy ? [{ kind: 'lahko' as const, z: 'Z1' as const, label: 'Lahko', sec: easy * SEC, target: zone(p, 'Z1'), note: 'Zadihaj, pij — takoj za tem test.' }] : []),
      noPower(p)
        ? { kind: 'test', z: 'max', label: '20-minutni test', sec: 20 * SEC, target: 'čim močneje, enakomerno', note: 'Prvih 5 min malo pod tem, kar misliš, da zmoreš; sredina enakomerno; zadnjih 5 min stisni vse. Brez merilnika moči: povprečni utrip zadnjih 15 min ≈ tvoj pražni utrip (LTHR) — vpiši ga v Nastavitve, cone se posodobijo. Še bolje na istem klancu kot zadnjič: čas je tvoj napredek.' }
        : { kind: 'test', z: 'max', label: '20-minutni test', sec: 20 * SEC, target: p.ftp ? `začni pri ~${Math.round(p.ftp * 1.02)} W` : 'čim močneje, enakomerno', note: 'Prvih 5 min malo pod tem, kar misliš, da zmoreš; sredina enakomerno; zadnjih 5 min stisni vse. Sede, kadenca 90+. Povprečje vpiši v Napredek → Testi.' },
      { kind: 'iztek', z: 'Z1', label: 'Iztek', sec: Math.max(5, dur - wu - easy - 20) * SEC, target: zone(p, 'Z1') },
    ]
  }

  const tw = workText(p, day)

  // dirka: en dolg korak; vodilo po tekmi (Kladje samo pri Franji)
  if (day.role === 'dirka') return [{ kind: 'delo', label: day.title, sec: total, target: tw ? (/franj/i.test(day.title) ? `Kladje ${tw}` : tw) : 'enakomerno', note: day.desc }]

  // struktura iz opisa (sicer iz naslova)
  const fromDesc = parseDrills(day.desc || '')
  const drills = fromDesc.length ? fromDesc : parseDrills(day.title)
  const src = fromDesc.length ? day.desc || '' : day.title
  if (drills.length) return assemble(day, p, drills, src, total, tw)

  // enakomerno (dolga, lahka)
  const wu = Math.min(15, Math.max(5, Math.round(dur * 0.12)))
  const cd = Math.min(10, Math.max(5, Math.round(dur * 0.08)))
  const main = Math.max(5 * SEC, total - (wu + cd) * SEC)
  const z = day.zone === 'Z3' ? 'Z3' : day.zone === 'Z1' ? 'Z1' : 'Z2'
  return [
    { kind: 'ogrevanje', z: 'Z1', label: 'Ogrevanje', sec: wu * SEC, target: zone(p, 'Z1'), note: 'Lahko, kadenca 85–95.' },
    { kind: 'delo', z, label: day.title, sec: main, target: day.kind === 'kolo' ? zone(p, z) : 'pogovorni tempo', note: (z === 'Z1' ? CUE.Z1 : z === 'Z3' ? CUE.Z3 : CUE.Z2) + (dur >= 75 ? ' Jej in pij po urniku — aplikacija te opomni.' : '') },
    { kind: 'iztek', z: 'Z1', label: 'Iztek', sec: cd * SEC, target: zone(p, 'Z1'), note: CUE.iztek },
  ]
}

/** Ogrevanje, bloki na svojem mestu, Z2 do načrtovanega trajanja, izvoz. */
function assemble(day: PlanDay, p: Profile, drills: Drill[], src: string, total: number, tw: string | null): Step[] {
  const dur = total / SEC
  const bike = day.kind !== 'tek' && day.kind !== 'pohod'
  const key = day.role === 'kljucna' || /\d+\s*min ogrevanj/i.test(src)
  const keyZone: Zn = day.zone === 'Z3' ? 'Z3' : day.zone === 'Z5' ? 'Z5' : 'Z4'
  const wuM = /(\d+)\s*min ogrevanj/i.exec(src), cdM = /(\d+)\s*min (?:izvoz|iztek)/i.exec(src)
  let wu = (wuM ? +wuM[1]! : key ? Math.min(15, Math.max(8, Math.round(dur * 0.2))) : Math.min(15, Math.max(5, Math.round(dur * 0.12)))) * SEC
  let cd = (cdM ? +cdM[1]! : key ? Math.min(10, Math.max(5, Math.round(dur * 0.12))) : Math.min(10, Math.max(5, Math.round(dur * 0.08)))) * SEC
  const fuelNote = dur >= 75 ? ' Jej in pij po urniku — aplikacija te opomni.' : ''

  const restZ = (d: Drill): Zn => (key || d.work <= 60 ? 'Z1' : 'Z2')
  const blocks = drills.map((d, g) => {
    const it = intensity(d.txt, p)
    const main = key && g === 0 && !d.walkRun
    const z: Z = main ? (it.share && it.z ? it.z : keyZone) : it.z ?? (key ? keyZone : 'Z3')
    const zz: Zn = z === 'max' ? 'Z5' : z
    const share = it.share ?? null
    const target = d.walkRun ? 'pogovorni tempo'
      : main && tw ? tw
      : it.kind === 'kadenca' || it.kind === 'nizka' ? `${zone(p, 'Z2')}${it.cad ? ` · kadenca ${it.cad}` : ''}`
      : share ? (noPower(p) ? lthrZoneText(p, zz) ?? zone(p, zz) : p.ftp ? (it.open ? `${Math.round(p.ftp * share[0])}+ W` : `${Math.round(p.ftp * share[0])}–${Math.round(p.ftp * share[1])} W`) : it.open ? `${Math.round(share[0] * 100)}+ % FTP` : `${Math.round(share[0] * 100)}–${Math.round(share[1] * 100)} % FTP`)
      : z === 'max' ? 'vse, kar gre'
      : tw || zone(p, zz)
    const label = d.walkRun ? 'Tek' : it.kind === 'sprint' ? (/šprint|vse, kar gre/i.test(d.txt) ? 'Šprint' : 'Napad') : it.kind === 'kadenca' ? 'Kadenca' : it.kind === 'nizka' ? 'Nizka kadenca' : d.series > 1 || d.work < 60 ? 'Ponovitev' : key ? 'Interval' : 'Blok'
    const cue = it.kind === 'kadenca' ? CUE.kadenca! : it.kind === 'nizka' ? CUE.nizka! : it.kind === 'tempo' || (!key && !main && z === 'Z3') ? CUE.tempo! : CUE[z]!
    const rest = drillRest(d, key)
    const rz = restZ(d)
    const out: Step[] = []
    for (let s = 1; s <= d.series; s++) {
      for (let i = 1; i <= d.reps; i++) {
        const note = (d.series > 1 && i === 1 ? `Serija ${s}/${d.series}. ` : '') + (main && i === 1 ? cue + ' Prvih 30 s ne prehitro.' : main && i === d.reps ? cue + ' Zadnji — daj vse v razponu.' : cue)
        out.push({ kind: 'delo', z, label: d.reps > 1 ? `${label} ${i}/${d.reps}` : label, sec: d.work, target, set: i, sets: d.reps, group: g, ...(d.series > 1 ? { series: s, seriesOf: d.series } : {}), ...(share ? { ftpShare: share } : {}), note })
        if (i < d.reps) out.push({ kind: 'lahko', z: rz, label: d.walkRun ? 'Hoja' : 'Lahko', sec: rest, target: d.walkRun ? 'hitra hoja' : zone(p, rz), note: CUE.odmor, group: g })
      }
      if (s < d.series) out.push({ kind: 'lahko', z: rz, label: `Med ${d.series === 2 ? 'serijama' : 'serijami'}`, sec: d.seriesRest, target: zone(p, rz), note: 'Vrti lahko, pij. Naslednja serija enako kakovostno kot prva.', group: g })
    }
    return { d, steps: out, rest, rz }
  })
  const gap = (b: (typeof blocks)[number]): Step => ({ kind: 'lahko', z: b.rz, label: 'Lahko', sec: b.rest, target: zone(p, b.rz), note: CUE.odmor })
  const seq = (list: typeof blocks): Step[] => list.flatMap((b, k) => (k ? [gap(list[k - 1]!), ...b.steps] : b.steps))
  const head = blocks.filter(b => b.d.where !== 'end'), tail = blocks.filter(b => b.d.where === 'end')
  const place: Where = head.length ? head[0]!.d.where ?? (key ? 'start' : day.role === 'dolga' ? 'end' : 'middle') : 'end'
  const A = place === 'end' ? [] : seq(head), B = place === 'end' ? seq([...head, ...tail]) : seq(tail)
  // med blokom na sredi in blokom na koncu vsaj odmor prvega (Z2 vmes ga nadomesti, če je dovolj dolga)
  const needGap = A.length && B.length ? head[head.length - 1]!.rest : 0
  // Z2 do načrtovanega trajanja (ogrevanje in izvoz se skrajšata, če je struktura daljša od načrta)
  let fill = total - wu - cd - totalSec(A) - totalSec(B)
  if (fill < needGap) { const c = Math.min(needGap - fill, Math.max(0, cd - 5 * SEC)); cd -= c; fill += c }
  if (fill < needGap) { const c = Math.min(needGap - fill, Math.max(0, wu - 5 * SEC)); wu -= c; fill += c }
  fill = Math.max(0, fill)
  if (!needGap && fill > 0 && fill < 3 * SEC) { cd += fill; fill = 0 }
  let before = place === 'start' ? 0 : place === 'middle' ? Math.round(fill / 2 / SEC) * SEC : place === 'hour2' ? Math.min(fill, Math.max(0, Math.round((60 * SEC - wu) / SEC) * SEC)) : fill
  if (fill - before < needGap) before = Math.max(0, fill - needGap)
  if (before < SEC) before = 0
  let between = fill - before
  if (!needGap && between > 0 && between < SEC) { cd += between; between = 0 }
  const z2 = (sec: number): Step[] => (sec >= 30 ? [{ kind: 'lahko', z: 'Z2', label: 'Z2 vzdržljivost', sec, target: bike ? zone(p, 'Z2') : 'pogovorni tempo', note: CUE.Z2 + fuelNote }] : [])
  // kratek presledek med blokoma je odmor (lahko), daljši je Z2
  const mid: Step[] = A.length && B.length && between > 0 && between < 3 * SEC ? [{ ...gap(head[head.length - 1]!), sec: between }] : z2(between)
  return [
    key
      ? { kind: 'ogrevanje', z: 'Z2', label: 'Ogrevanje', sec: wu, target: zone(p, 'Z2'), note: CUE.ogrevanje }
      : { kind: 'ogrevanje', z: 'Z1', label: 'Ogrevanje', sec: wu, target: zone(p, 'Z1'), note: 'Lahko, kadenca 85–95.' },
    ...z2(before), ...A, ...mid, ...B,
    { kind: 'iztek', z: 'Z1', label: 'Iztek', sec: cd, target: zone(p, 'Z1'), note: CUE.iztek },
  ]
}

function strengthSteps(day: PlanDay): Step[] {
  const ex = day.exercises || []
  if (!ex.length) return [{ kind: 'vaja', label: day.title, sec: 0, note: day.desc }]
  const steps: Step[] = [{ kind: 'ogrevanje', label: 'Ogrevanje', sec: 5 * SEC, note: 'Kroženje, lahki počepi, izpadni koraki brez uteži.' }]
  for (const e of ex) {
    const timed = /(\d+)\s*s\b/.exec(e.reps)
    for (let s = 1; s <= e.sets; s++) {
      steps.push({ kind: 'vaja', label: e.name, sec: timed ? +timed[1]! : 0, reps: e.reps + (e.kg ? ` · ${e.kg} kg` : ''), set: s, sets: e.sets, note: (HOW[e.name] ? HOW[e.name] + ' ' : '') + (timed ? '' : 'Ko končaš serijo, tapni naprej.') })
      if (s < e.sets) steps.push({ kind: 'pavza', label: 'Pavza', sec: 60 })
    }
    steps.push({ kind: 'pavza', label: 'Pavza med vajami', sec: 90, note: 'Pij, zadihaj, pripravi naslednjo vajo.' })
  }
  steps.pop()
  steps.push({ kind: 'iztek', label: 'Raztezanje', sec: 4 * SEC, note: 'Noge, kolki, hrbet — vsak razteg 30 s.' })
  return steps
}

export function totalSec(steps: readonly Step[]): number { return steps.reduce((s, x) => s + x.sec, 0) }
export function fmtClock(sec: number): string {
  const s = Math.max(0, Math.round(sec)), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(r).padStart(2, '0')}` : `${m}:${String(r).padStart(2, '0')}`
}
