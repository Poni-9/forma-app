import type { PlanDay, Profile } from '../types'
import { zoneText } from './zones'

/**
 * Trening kot zaporedje korakov za izvajalnik s časovnikom.
 * Iz naslova in opisa dneva razberemo strukturo (»4 × 6 min«, »6 × (4 min tek / 2 min hoja)«),
 * sicer naredimo ogrevanje → enakomerno → iztek. Moč: vaje × serije s pavzo.
 */
export type StepKind = 'ogrevanje' | 'delo' | 'lahko' | 'iztek' | 'vaja' | 'pavza' | 'test'
export interface Step {
  kind: StepKind
  label: string
  /** trajanje v sekundah; 0 = brez časovnika (vaja, ki jo potrdiš) */
  sec: number
  target?: string | null
  note?: string
  /** za moč */
  set?: number
  sets?: number
  reps?: string
}

const SEC = 60
const zone = (p: Profile, z: 'Z1' | 'Z2' | 'Z3' | 'Z4' | 'Z5') => zoneText(p, z)

/** Kako naj se počuti — RPE (1–10), dihanje, kadenca. */
export const CUE: Record<string, string> = {
  ogrevanje: 'Lahko, kadenca 85–95. Zadnjih 5 min 3 × 30 s hitreje, da odpreš noge.',
  Z1: 'Zelo lahko (RPE 2/10) — noge samo vrtijo, dihanje umirjeno.',
  Z2: 'RPE 3–4/10 — pogovarjaš se v celih stavkih, dihaš skozi nos. Kadenca 85–95.',
  Z3: 'RPE 7/10 — lahko rečeš stavek, noge počasi gorijo. Kadenca 85–95, ramena sproščena.',
  Z4: 'RPE 8/10 — samo kratke besede. Enakomerno, kadenca 85–95.',
  Z5: 'RPE 9/10 — dihaš hitro in globoko, a zdržiš do konca. Sede, kadenca 95–105.',
  tempo: 'RPE 6/10 — enakomerno, kot tempo skupine na ravnini. Jej pred blokom.',
  odmor: 'Vrti lahko, 2–3 požirke. Pripravi se na naslednjega.',
  iztek: 'Zelo lahko, noge vrtijo. Pij. Po treningu v 45 min beljakovine in OH.',
}
/** Tehnika vaj za moč. */
export const HOW: Record<string, string> = {
  'Deska': 'Komolci pod rameni, telo v ravni črti, stisni zadnjico in trebuh, ne povesi bokov.',
  'Stranska deska': 'Komolec pod ramo, boki visoko, telo v ravni črti — vsaka stran posebej.',
  'Dvig nog leže': 'Križ pritisnjen v tla, noge počasi dol do 10 cm nad tlemi in nazaj.',
  'Dead bug': 'Križ v tleh; nasprotno roko in nogo počasi iztegni, izdihni, zamenjaj.',
  'Bolgarski počep': 'Zadnja noga na stolu, sprednje koleno nad prsti, spusti se navpično do 90°, poriv skozi peto.',
  'Izpadni koraki': 'Dolg korak, zadnje koleno skoraj do tal, trup pokončen, izmenično.',
  'Dvigi na prste': 'Na robu stopnice: gor hitro, 2 s dol, polna amplituda.',
}

/** Kratek povzetek strukture za pregled pred treningom: »20 min ogrevanje · 4 × 4 min 259–276 W, vmes 4 min · …«. */
export function structureLines(steps: readonly Step[]): string[] {
  const out: string[] = []
  const m = (sec: number) => `${Math.round(sec / 60)} min`
  for (let i = 0; i < steps.length; i++) {
    const s = steps[i]!
    if (s.kind === 'delo' && s.sets && s.sets > 1 && s.set === 1) {
      const rest = steps[i + 1]?.kind === 'lahko' ? steps[i + 1]!.sec : 0
      out.push(`${s.sets} × ${m(s.sec)}${s.target ? ` pri ${s.target}` : ''}${rest ? `, vmes ${m(rest)} lahko` : ''}`)
      while (i + 1 < steps.length && (steps[i + 1]!.kind === 'delo' || (steps[i + 1]!.kind === 'lahko' && steps[i + 2]?.kind === 'delo'))) i++
      continue
    }
    if (s.kind === 'vaja') { if (s.set === 1) out.push(`${s.label}: ${s.sets} × ${s.reps}`); continue }
    if (s.kind === 'pavza') continue
    out.push(`${s.sec ? m(s.sec) + ' ' : ''}${s.kind === 'ogrevanje' ? 'ogrevanje' : s.kind === 'iztek' ? 'izvoz' : s.label}${s.target ? ` (${s.target})` : ''}`)
  }
  return out
}

export function stepsFor(day: PlanDay, p: Profile): Step[] {
  if (day.kind === 'pocitek') return []
  if (day.kind === 'moc') return strengthSteps(day)
  const total = Math.max(10, day.durationMin) * SEC
  const text = `${day.title} ${day.desc}`

  // 20-minutni test
  if (day.kind === 'test' || /20[- ]?min/.test(day.title)) {
    const wu = day.kind === 'tek' || /tek/i.test(text) ? 10 : 15
    return [
      { kind: 'ogrevanje', label: 'Ogrevanje', sec: wu * SEC, target: zone(p, 'Z2'), note: 'Zadnjih 5 min nekaj kratkih pospeškov.' },
      { kind: 'test', label: '20-minutni test', sec: 20 * SEC, target: p.ftp ? `začni pri ~${Math.round(p.ftp * 1.02)} W` : 'čim močneje, enakomerno', note: 'Prvih 5 min malo pod tem, kar misliš, da zmoreš; sredina enakomerno; zadnjih 5 min stisni vse. Sede, kadenca 90+. Povprečje vpiši v Napredek → Testi.' },
      { kind: 'iztek', label: 'Iztek', sec: Math.max(5, day.durationMin - wu - 20) * SEC, target: zone(p, 'Z1') },
    ]
  }

  const tw = day.target ? `${day.target.lo}–${day.target.hi} W` : null

  // dirka: en dolg korak z vodilom za Kladje
  if (day.role === 'dirka') return [{ kind: 'delo', label: day.title, sec: total, target: tw ? `Kladje ${tw}` : 'enakomerno', note: day.desc }]

  // dolga vožnja z bloki (tempo v zadnji uri, simulacija dirke): Z2 → bloki na koncu → iztek
  const lb = day.role === 'dolga' && tw ? text.match(/(\d+)\s*×\s*(\d+)\s*min/) : null
  if (lb) {
    const reps = +lb[1]!, work = +lb[2]!, gap = work >= 15 ? 10 : 5
    const wu = 15, cd = 10
    const blocks = reps * work + (reps - 1) * gap
    const z2 = Math.max(10, day.durationMin - wu - cd - blocks)
    const steps: Step[] = [{ kind: 'ogrevanje', label: 'Ogrevanje', sec: wu * SEC, target: zone(p, 'Z1'), note: CUE.ogrevanje }, { kind: 'lahko', label: 'Z2', sec: z2 * SEC, target: zone(p, 'Z2'), note: CUE.Z2 + ' Jej in pij po urniku — aplikacija te opomni.' }]
    for (let i = 1; i <= reps; i++) {
      steps.push({ kind: 'delo', label: `Blok ${i}/${reps}`, sec: work * SEC, target: tw, set: i, sets: reps, note: CUE.tempo })
      if (i < reps) steps.push({ kind: 'lahko', label: 'Z2', sec: gap * SEC, target: zone(p, 'Z2'), note: CUE.Z2 })
    }
    steps.push({ kind: 'iztek', label: 'Iztek', sec: cd * SEC, target: zone(p, 'Z1'), note: CUE.iztek })
    return steps
  }

  // intervali: »4 × 6 min«, »6 × 2 min«, »6 × (4 min tek / 2 min hoja)«
  const m = text.match(/(\d+)\s*×\s*\(?\s*(\d+(?:[.,]\d+)?)\s*min(?:\s*(?:tek|hitro|hitreje|delo))?\s*(?:\/\s*(\d+(?:[.,]\d+)?)\s*min)?/i)
  if (m) {
    const reps = +m[1]!, work = +m[2]!.replace(',', '.')
    const restM = text.match(/(?:vmes|odmor|pavza)\s*(\d+(?:[.,]\d+)?)\s*min/i)
    const rest = m[3] ? +m[3].replace(',', '.') : restM ? +restM[1]!.replace(',', '.') : Math.max(1, Math.round(work * 0.6))
    const isWalkRun = /hoja/i.test(text)
    const workZone = day.zone === 'Z3' ? 'Z3' : day.zone === 'Z5' ? 'Z5' : 'Z4'
    // ogrevanje, izvoz in dodatna Z2 iz opisa (»20 min ogrevanje«, »nato 15 min Z2«, »15 min izvoz«), sicer ocena
    const wuM = text.match(/(\d+)\s*min ogrevanj/i), cdM = text.match(/(\d+)\s*min (?:izvoz|iztek)/i), exM = text.match(/nato (\d+) min Z2/i)
    const wu = wuM ? +wuM[1]! : Math.min(15, Math.max(8, Math.round(day.durationMin * 0.2)))
    const cd = cdM ? +cdM[1]! : Math.min(10, Math.max(5, Math.round(day.durationMin * 0.12)))
    const steps: Step[] = [{ kind: 'ogrevanje', label: 'Ogrevanje', sec: wu * SEC, target: zone(p, 'Z2'), note: CUE.ogrevanje }]
    for (let i = 1; i <= reps; i++) {
      steps.push({ kind: 'delo', label: isWalkRun ? `Tek ${i}/${reps}` : `Interval ${i}/${reps}`, sec: Math.round(work * SEC), target: isWalkRun ? 'pogovorni tempo' : tw || zone(p, workZone), set: i, sets: reps, note: i === 1 ? CUE[workZone] + ' Prvih 30 s ne prehitro.' : i === reps ? CUE[workZone] + ' Zadnji — daj vse v razponu.' : CUE[workZone] })
      if (i < reps) steps.push({ kind: 'lahko', label: isWalkRun ? 'Hoja' : 'Lahko', sec: Math.round(rest * SEC), target: isWalkRun ? 'hitra hoja' : zone(p, 'Z1'), note: CUE.odmor })
    }
    if (exM) steps.push({ kind: 'lahko', label: 'Z2', sec: +exM[1]! * SEC, target: zone(p, 'Z2'), note: CUE.Z2 })
    steps.push({ kind: 'iztek', label: 'Iztek', sec: cd * SEC, target: zone(p, 'Z1'), note: CUE.iztek })
    return steps
  }

  // enakomerno (dolga, lahka)
  const wu = Math.min(15, Math.max(5, Math.round(day.durationMin * 0.12)))
  const cd = Math.min(10, Math.max(5, Math.round(day.durationMin * 0.08)))
  const main = Math.max(5 * SEC, total - (wu + cd) * SEC)
  const z = day.zone === 'Z3' ? 'Z3' : day.zone === 'Z1' ? 'Z1' : 'Z2'
  return [
    { kind: 'ogrevanje', label: 'Ogrevanje', sec: wu * SEC, target: zone(p, 'Z1'), note: 'Lahko, kadenca 85–95.' },
    { kind: 'delo', label: day.title, sec: main, target: day.kind === 'kolo' ? zone(p, z) : 'pogovorni tempo', note: (z === 'Z1' ? CUE.Z1 : z === 'Z3' ? CUE.Z3 : CUE.Z2) + (day.durationMin >= 75 ? ' Jej in pij po urniku — aplikacija te opomni.' : '') },
    { kind: 'iztek', label: 'Iztek', sec: cd * SEC, target: zone(p, 'Z1'), note: CUE.iztek },
  ]
}

function strengthSteps(day: PlanDay): Step[] {
  const ex = day.exercises || []
  if (!ex.length) return [{ kind: 'vaja', label: day.title, sec: 0, note: day.desc }]
  const steps: Step[] = [{ kind: 'ogrevanje', label: 'Ogrevanje', sec: 5 * SEC, note: 'Kroženje, lahki počepi, izpadni koraki brez uteži.' }]
  for (const e of ex) {
    const timed = /(\d+)\s*s\b/.exec(e.reps)
    for (let s = 1; s <= e.sets; s++) {
      steps.push({ kind: 'vaja', label: e.name, sec: timed ? +timed[1]! : 0, reps: e.reps + (e.kg ? ` · ${e.kg} kg` : ''), set: s, sets: e.sets, note: (HOW[e.name] ? HOW[e.name] + ' ' : '') + (timed ? '' : 'Ko končaš serijo, tapni naprej.') })
      if (s < e.sets) steps.push({ kind: 'pavza', label: 'Pavza', sec: 60 })
    }
    steps.push({ kind: 'pavza', label: 'Pavza med vajami', sec: 90, note: 'Pij, zadihaj, pripravi naslednjo vajo.' })
  }
  steps.pop()
  steps.push({ kind: 'iztek', label: 'Raztezanje', sec: 4 * SEC, note: 'Noge, kolki, hrbet — vsak razteg 30 s.' })
  return steps
}

export function totalSec(steps: readonly Step[]): number { return steps.reduce((s, x) => s + x.sec, 0) }
export function fmtClock(sec: number): string {
  const s = Math.max(0, Math.round(sec)), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(r).padStart(2, '0')}` : `${m}:${String(r).padStart(2, '0')}`
}
