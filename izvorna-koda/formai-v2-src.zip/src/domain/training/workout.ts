import type { PlanDay, Profile } from '../types'
import { zoneText } from './zones'

/**
 * Trening kot zaporedje korakov za izvajalnik s časovnikom.
 * Iz naslova in opisa dneva razberemo strukturo (»4 × 6 min«, »6 × (4 min tek / 2 min hoja)«),
 * sicer naredimo ogrevanje → enakomerno → iztek. Moč: vaje × serije s pavzo.
 */
export type StepKind = 'ogrevanje' | 'delo' | 'lahko' | 'iztek' | 'vaja' | 'pavza' | 'test'
export interface Step {
  kind: StepKind
  label: string
  /** trajanje v sekundah; 0 = brez časovnika (vaja, ki jo potrdiš) */
  sec: number
  target?: string | null
  note?: string
  /** za moč */
  set?: number
  sets?: number
  reps?: string
}

const SEC = 60
const zone = (p: Profile, z: 'Z1' | 'Z2' | 'Z3' | 'Z4' | 'Z5') => zoneText(p, z)

export function stepsFor(day: PlanDay, p: Profile): Step[] {
  if (day.kind === 'pocitek') return []
  if (day.kind === 'moc') return strengthSteps(day)
  const total = Math.max(10, day.durationMin) * SEC
  const text = `${day.title} ${day.desc}`

  // 20-minutni test
  if (day.kind === 'test' || /20[- ]?min/.test(day.title)) {
    const wu = day.kind === 'tek' || /tek/i.test(text) ? 10 : 15
    return [
      { kind: 'ogrevanje', label: 'Ogrevanje', sec: wu * SEC, target: zone(p, 'Z2'), note: 'Zadnjih 5 min nekaj kratkih pospeškov.' },
      { kind: 'test', label: '20-minutni test', sec: 20 * SEC, target: 'čim močneje, enakomerno', note: 'Začni malo pod tem, kar misliš, da zmoreš. Zadnjih 5 min stisni.' },
      { kind: 'iztek', label: 'Iztek', sec: Math.max(5, day.durationMin - wu - 20) * SEC, target: zone(p, 'Z1') },
    ]
  }

  // intervali: »4 × 6 min«, »6 × 2 min«, »6 × (4 min tek / 2 min hoja)«
  const m = text.match(/(\d+)\s*×\s*\(?\s*(\d+(?:[.,]\d+)?)\s*min(?:\s*(?:tek|hitro|hitreje|delo))?\s*(?:\/\s*(\d+(?:[.,]\d+)?)\s*min)?/i)
  if (m) {
    const reps = +m[1]!, work = +m[2]!.replace(',', '.')
    const restM = text.match(/(?:vmes|odmor|pavza)\s*(\d+(?:[.,]\d+)?)\s*min/i)
    const rest = m[3] ? +m[3].replace(',', '.') : restM ? +restM[1]!.replace(',', '.') : Math.max(1, Math.round(work * 0.6))
    const isWalkRun = /hoja/i.test(text)
    const workZone = day.zone === 'Z3' ? 'Z3' : day.zone === 'Z5' ? 'Z5' : 'Z4'
    const wu = Math.min(15, Math.max(8, Math.round(day.durationMin * 0.2)))
    const cd = Math.min(10, Math.max(5, Math.round(day.durationMin * 0.12)))
    const steps: Step[] = [{ kind: 'ogrevanje', label: 'Ogrevanje', sec: wu * SEC, target: zone(p, 'Z2') }]
    for (let i = 1; i <= reps; i++) {
      steps.push({ kind: 'delo', label: isWalkRun ? `Tek ${i}/${reps}` : `Interval ${i}/${reps}`, sec: Math.round(work * SEC), target: isWalkRun ? 'pogovorni tempo' : zone(p, workZone), set: i, sets: reps })
      if (i < reps) steps.push({ kind: 'lahko', label: isWalkRun ? 'Hoja' : 'Lahko', sec: Math.round(rest * SEC), target: isWalkRun ? 'hitra hoja' : zone(p, 'Z1') })
    }
    steps.push({ kind: 'iztek', label: 'Iztek', sec: cd * SEC, target: zone(p, 'Z1') })
    return steps
  }

  // enakomerno (dolga, lahka)
  const wu = Math.min(15, Math.max(5, Math.round(day.durationMin * 0.12)))
  const cd = Math.min(10, Math.max(5, Math.round(day.durationMin * 0.08)))
  const main = Math.max(5 * SEC, total - (wu + cd) * SEC)
  const z = day.zone === 'Z3' ? 'Z3' : 'Z2'
  return [
    { kind: 'ogrevanje', label: 'Ogrevanje', sec: wu * SEC, target: zone(p, 'Z1') },
    { kind: 'delo', label: day.title, sec: main, target: day.kind === 'kolo' ? zone(p, z) : 'pogovorni tempo', note: day.desc },
    { kind: 'iztek', label: 'Iztek', sec: cd * SEC, target: zone(p, 'Z1') },
  ]
}

function strengthSteps(day: PlanDay): Step[] {
  const ex = day.exercises || []
  if (!ex.length) return [{ kind: 'vaja', label: day.title, sec: 0, note: day.desc }]
  const steps: Step[] = [{ kind: 'ogrevanje', label: 'Ogrevanje', sec: 5 * SEC, note: 'Kroženje, lahki počepi, izpadni koraki brez uteži.' }]
  for (const e of ex) {
    const timed = /(\d+)\s*s\b/.exec(e.reps)
    for (let s = 1; s <= e.sets; s++) {
      steps.push({ kind: 'vaja', label: e.name, sec: timed ? +timed[1]! : 0, reps: e.reps + (e.kg ? ` · ${e.kg} kg` : ''), set: s, sets: e.sets, note: timed ? undefined : 'Ko končaš serijo, tapni naprej.' })
      if (s < e.sets) steps.push({ kind: 'pavza', label: 'Pavza', sec: 60 })
    }
    steps.push({ kind: 'pavza', label: 'Pavza med vajami', sec: 90 })
  }
  steps.pop()
  steps.push({ kind: 'iztek', label: 'Raztezanje', sec: 4 * SEC, note: 'Noge, kolki, hrbet — vsak razteg 30 s.' })
  return steps
}

export function totalSec(steps: readonly Step[]): number { return steps.reduce((s, x) => s + x.sec, 0) }
export function fmtClock(sec: number): string {
  const s = Math.max(0, Math.round(sec)), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(r).padStart(2, '0')}` : `${m}:${String(r).padStart(2, '0')}`
}
