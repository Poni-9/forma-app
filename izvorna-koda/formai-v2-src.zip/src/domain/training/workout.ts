import type { PlanDay, Profile } from '../types'
import { zoneText, workText, noPower, lthrZoneText, workZone } from './zones'
import { exByName } from './exercises'
import { titleNoDur, lthrOf } from './load'

/**
 * Trening kot zaporedje korakov za izvajalnik s časovnikom.
 * Iz opisa (sicer naslova) dneva razberemo strukturo — »4 × 6 min«, »3 serije × 13 × (30 s / 15 s)«, »6 × 10 s šprint«,
 * »6 × (4 min tek / 2 min hoja)« — in jo postavimo v vožnjo (takoj po ogrevanju, na sredi, v drugi uri ali na koncu);
 * preostanek do načrtovanega trajanja je Z2, da se trening na uri konča ob istem času kot v načrtu.
 * Brez strukture: ogrevanje → enakomerno → iztek. Moč: vaje × serije s pavzo.
 */
export type StepKind = 'ogrevanje' | 'delo' | 'lahko' | 'iztek' | 'vaja' | 'pavza' | 'test'
export interface Step {
  kind: StepKind
  label: string
  /** trajanje v sekundah; 0 = brez časovnika (vaja, ki jo potrdiš) */
  sec: number
  target?: string | null
  note?: string
  /** cona koraka — za izvoz na uro (intervals.icu → Garmin) */
  z?: 'Z1' | 'Z2' | 'Z3' | 'Z4' | 'Z5' | 'max'
  /** za moč; pri intervalih: ponovitev v bloku (seriji) */
  set?: number
  sets?: number
  reps?: string
  /** blok intervalov (vsi koraki istega niza imajo isto številko) */
  group?: number
  /** serija v bloku (30/15: 3 serije × 13) */
  series?: number
  seriesOf?: number
  /** ciljna moč kot delež FTP [od, do], razbrana iz opisa seje (za uro v vatih) */
  ftpShare?: [number, number]
}

const SEC = 60
type Zn = 'Z1' | 'Z2' | 'Z3' | 'Z4' | 'Z5'
type Z = NonNullable<Step['z']>
const zone = (p: Profile, z: Zn) => zoneText(p, z)
/** Cona za korak: kolo po zoneText (vati ali utrip), tek in hoja po pražnem utripu kot runZone — nikoli vati (v3.48). */
const zoneFor = (p: Profile, kind: PlanDay['kind'], z: Zn) => (kind === 'tek' || kind === 'pohod' ? lthrZoneText(p, z) ?? zone(p, z) : zone(p, z))

/** Kako naj se počuti — RPE (1–10), dihanje, kadenca. */
export const CUE: Record<string, string> = {
  ogrevanje: 'Lahko, kadenca 85–95. Zadnjih 5 min 3 × 30 s hitreje, da odpreš noge.',
  Z1: 'Zelo lahko (RPE 2/10) — noge samo vrtijo, dihanje umirjeno.',
  Z2: 'RPE 3–4/10 — pogovarjaš se v celih stavkih, dihaš skozi nos. Kadenca 85–95.',
  Z3: 'RPE 7/10 — lahko rečeš stavek, noge počasi gorijo. Kadenca 85–95, ramena sproščena.',
  Z4: 'RPE 8/10 — samo kratke besede. Enakomerno, kadenca 85–95.',
  Z5: 'RPE 9/10 — dihaš hitro in globoko, a zdržiš do konca. Sede, kadenca 95–105.',
  max: 'RPE 10/10 — vse, kar gre, s tehniko: sede ali stoje, visoka kadenca. Potem res lahko.',
  tempo: 'RPE 6/10 — enakomerno, kot tempo skupine na ravnini. Jej pred blokom.',
  klanec: 'RPE 6–7/10 — sede, enakomerno od dna do vrha, kadenca 70–85. Jej pred klancem.',
  kadenca: 'Lahko, brez sile — samo hitre noge, zgornji del telesa miren.',
  nizka: 'Sede, sila v pedalih, dihanje mirno — ne v utrip.',
  odmor: 'Vrti lahko, 2–3 požirke. Pripravi se na naslednjega.',
  iztek: 'Zelo lahko, noge vrtijo. Pij. Po treningu v 45 min beljakovine in OH.',
}
/** (v3.49) Tek in hoja: lahek tek, hoja vmes in hitra hoja (prej »Vrti lahko«, »kadenca 85–95« kot na kolesu). */
const RUN_EASY = 'Počasi — toliko, da lahko govoriš. Kratki, lahkotni koraki.'
const WALK = 'Hitra hoja: roke zraven, dihaj enakomerno.'
const WALK_REST = 'Hodi hitro in zadihaj. Pripravi se na naslednji tek.'
/** (v3.50) ogrevanje po vrsti: kolo s kadenco, tek s kratkim korakom, hribi s hitro hojo (prej »kadenca 85–95« tudi pri hoji) */
const warmNote = (kind: PlanDay['kind']): string => (kind === 'tek' ? 'Lahek tek, kratek korak.' : kind === 'pohod' ? 'Hitra hoja, da se ogreješ.' : 'Lahko, kadenca 85–95.')
/** (v3.50) tek in hribi: isti občutek (RPE) brez kolesarskih napotkov (kadenca, »noge vrtijo«, »sede«) */
const FOOT: Record<string, string> = {
  Z1: 'Zelo lahko (RPE 2/10) — dihanje umirjeno.',
  Z2: 'RPE 3–4/10 — pogovarjaš se v celih stavkih, dihaš skozi nos.',
  Z3: 'RPE 7/10 — lahko rečeš stavek, dihanje globoko. Ramena sproščena.',
  Z4: 'RPE 8/10 — samo kratke besede. Enakomerno.',
  Z5: 'RPE 9/10 — dihaš hitro in globoko, a zdržiš do konca.',
  max: 'RPE 10/10 — vse, kar gre, s tehniko. Potem res lahko.',
  tempo: 'RPE 6/10 — enakomerno, udobno hitro.',
  klanec: 'RPE 6–7/10 — enakomerno od dna do vrha, krajši korak.',
  odmor: 'Lahek tek ali hoja, 2–3 požirke. Pripravi se na naslednjega.',
  iztek: 'Zelo lahko ali hoja. Pij. Po treningu v 45 min beljakovine in OH.',
}
const cueOf = (kind: PlanDay['kind'], k: string): string => ((kind === 'tek' || kind === 'pohod') && FOOT[k] ? FOOT[k]! : CUE[k]!)
/** (v3.50) kratka hitra kadenca brez številke obratov: cilj je kadenca, ne utrip (v 30 s utrip ne pove ničesar) */
const CAD_DEFAULT = '100–110'
/** Tehnika vaj za moč. */
export const HOW: Record<string, string> = {
  'Deska': 'Komolci pod rameni, telo v ravni črti, stisni zadnjico in trebuh, ne povesi bokov.',
  'Stranska deska': 'Komolec pod ramo, boki visoko, telo v ravni črti — vsaka stran posebej.',
  'Dvig nog leže': 'Križ pritisnjen v tla, noge počasi dol do 10 cm nad tlemi in nazaj.',
  'Dead bug': 'Križ v tleh; nasprotno roko in nogo počasi iztegni, izdihni, zamenjaj.',
  'Bolgarski počep': 'Zadnja noga na stolu, sprednje koleno nad prsti, spusti se navpično do 90°, poriv skozi peto.',
  'Izpadni koraki': 'Dolg korak, zadnje koleno skoraj do tal, trup pokončen, izmenično.',
  'Dvigi na prste': 'Na robu stopnice: gor hitro, 2 s dol, polna amplituda.',
}

/** »30 s«, »4 min«, »4 min 30 s« (kratki koraki), dolgi zaokroženi na minute. */
export function fmtStep(sec: number): string {
  const s = Math.max(0, Math.round(sec))
  if (s < 60) return `${s} s`
  if (s % 60 === 0) return `${s / 60} min`
  return s < 600 ? `${Math.floor(s / 60)} min ${s % 60} s` : `${Math.round(s / 60)} min`
}
const serije = (n: number) => (n === 2 ? 'seriji' : n <= 4 ? 'serije' : 'serij')

/** Kratek povzetek strukture za pregled pred treningom: »20 min ogrevanje · 4 × 4 min 259–276 W, vmes 4 min · …«. */
export function structureLines(steps: readonly Step[]): string[] {
  const out: string[] = []
  // »pri« samo pred vati in % FTP; besedni cilji v oklepaju (prej »5 × 1 min pri pogovorni tempo«, »pri pod 140 W«) (v3.48)
  const tgt = (s: Step) => (s.target ? (/^\d/.test(s.target) ? ` pri ${s.target}` : ` (${s.target})`) : '')
  for (let i = 0; i < steps.length; i++) {
    const s = steps[i]!
    if (s.kind === 'delo' && s.group != null && s.set === 1 && (s.series ?? 1) === 1) {
      // cel blok (vse serije) v eni vrstici
      let j = i
      while (j + 1 < steps.length && steps[j + 1]!.group === s.group) j++
      const n = s.sets ?? 1
      const rest = n > 1 && steps[i + 1]?.kind === 'lahko' && steps[i + 1]!.group === s.group ? steps[i + 1]!.sec : 0
      // tek in hoja: »5 × 1 min teka (utrip …), vmes 2 min hoje« (v3.48)
      const walk = steps[i + 1]?.label === 'Hoja'
      // (v3.49) over-under: »3 × (2 min pri … + 1 min pri …)«
      const o = isAltPair(steps, i) ? steps[i + 1]! : null
      const one = o ? `${n} × (${fmtStep(s.sec)}${tgt(s)} + ${fmtStep(o.sec)}${tgt(o)})`
        : n > 1 ? `${n} × ${fmtStep(s.sec)}${walk ? ' teka' : ''}${tgt(s)}${rest ? `, vmes ${fmtStep(rest)} ${walk ? 'hoje' : 'lahko'}` : ''}` : `${fmtStep(s.sec)} ${s.label.toLowerCase()}${tgt(s)}`
      const S = s.seriesOf ?? 1
      const sr = S > 1 ? steps.slice(i, j + 1).find(x => x.kind === 'lahko' && /^Med serij/.test(x.label))?.sec ?? 0 : 0
      out.push(S > 1 ? `${S} ${serije(S)} × ${one}${sr ? `; med ${S === 2 ? 'serijama' : 'serijami'} ${fmtStep(sr)} lahko` : ''}` : one)
      i = j
      continue
    }
    if (s.kind === 'delo' && s.sets && s.sets > 1 && s.set === 1) {
      const rest = steps[i + 1]?.kind === 'lahko' ? steps[i + 1]!.sec : 0
      out.push(`${s.sets} × ${fmtStep(s.sec)}${tgt(s)}${rest ? `, vmes ${fmtStep(rest)} lahko` : ''}`)
      while (i + 1 < steps.length && ((steps[i + 1]!.kind === 'delo' && (steps[i + 1]!.set ?? 0) > 1) || (steps[i + 1]!.kind === 'lahko' && steps[i + 2]?.kind === 'delo' && (steps[i + 2]!.set ?? 0) > 1))) i++
      continue
    }
    if (s.kind === 'vaja') { if (s.set === 1) out.push(s.label === FIN_LABEL ? `${s.label}: ${s.reps}` : `${s.label}: ${s.sets} × ${s.reps}`); continue }
    // (v3.51) tek in hoja: ostanek hoje po zadnjem teku je del izteka (prej posebna vrstica »1 min 30 s hitra hoja«)
    if (s.label === 'Hitra hoja' && steps[i + 1]?.kind === 'iztek' && steps[i + 1]!.target === 'hoja') { out.push(`${fmtStep(s.sec + steps[i + 1]!.sec)} iztek (hoja)`); i++; continue }
    if (s.kind === 'pavza') continue
    // (v3.50) test »20 min test (…)« (prej »20 min 20-minutni test«); za trajanjem z malo začetnico kot ogrevanje in iztek (»5 min lahko«)
    const name = s.kind === 'ogrevanje' ? 'ogrevanje' : s.kind === 'iztek' ? 'iztek' : s.kind === 'test' ? 'test' : s.sec && /^[A-ZČŠŽ][a-zčšž]/.test(s.label) ? s.label.charAt(0).toLowerCase() + s.label.slice(1) : s.label
    out.push(`${s.sec ? fmtStep(s.sec) + ' ' : ''}${name}${s.target ? ` (${s.target})` : ''}`)
  }
  return out
}

/** (v3.49) Ponovitev over-underja: korak dela, za njim takoj drugo delo iste ponovitve (isti blok, serija in številka). */
export const isAltPair = (steps: readonly Step[], i: number): boolean => {
  const a = steps[i], b = steps[i + 1]
  return !!a && !!b && a.kind === 'delo' && b.kind === 'delo' && a.group != null && a.group === b.group && a.set != null && a.set === b.set && (a.series ?? 1) === (b.series ?? 1)
}

/** (v3.49) Dolžina serije over-underja od koraka i (n ponovitev × 2 dela) ali 0, če tam ni začetka take serije. */
export function altRun(steps: readonly Step[], i: number): number {
  const n = steps[i]?.sets ?? 0
  if (n < 2 || steps[i]!.set !== 1) return 0
  for (let k = 0; k < n; k++) if (!isAltPair(steps, i + 2 * k) || steps[i + 2 * k]!.set !== k + 1) return 0
  return 2 * n
}

/* ---------- razbiranje strukture iz besedila ---------- */
type Where = 'start' | 'middle' | 'hour2' | 'end'
interface Drill {
  at: number; end: number
  series: number; reps: number; work: number
  /** odmor med ponovitvami (s); null = ni zapisan */
  rest: number | null
  seriesRest: number
  /** besedilo intenzivnosti (»pri 259–276 W (108–115 % FTP)«, »šprint — vse, kar gre«) */
  txt: string
  where: Where | null
  walkRun: boolean
  /** (v3.49) over-under: vsaka ponovitev je delo pod pragom + takoj delo nad njim (brez odmora) */
  alt?: { work: number; txt: string }
}
const DUR = String.raw`\d+\s*min(?:\s+\d+\s*s)?|\d+\s*s`
/** serije × ponovitve × (delo / odmor): »3 serije × 13 × (30 s pri … / 15 s lahko)«, »6 × (4 min tek / 2 min hoja)« */
const RE_REPS = new RegExp(String.raw`(?:(\d+)\s*serij[aei]?\s*×\s*)?(\d+)\s*×\s*\(\s*(${DUR})\b((?:[^()/]|\([^()]*\))*?)\/\s*(${DUR})\b([^()]*?)\)`, 'g')
/** (v3.49) over-under: »3 × (2 min pri 223–233 W + 1 min pri 247–257 W)« — oba dela sta delo, brez odmora vmes */
const RE_OU = new RegExp(String.raw`(?:(\d+)\s*serij[aei]?\s*×\s*)?(\d+)\s*×\s*\(\s*(${DUR})\b((?:[^()+]|\([^()]*\))*?)\+\s*(${DUR})\b((?:[^()]|\([^()]*\))*?)\)`, 'g')
/** »4 × 6 min«, »2 × 15 min tempo« (ne »3 × (2 min …«) */
const RE_MIN = /(\d+)\s*×\s*(\d+(?:[.,]\d+)?)\s*min\b(?!\s*\d+\s*s\b)/g
/** »6 × 10 s šprint«, »4 × 30 s hitra kadenca« */
const RE_SEC = /(\d+)\s*×\s*(\d+)\s*s\b/g
const secOf = (t: string): number => {
  const m = /(\d+)\s*min(?:\s+(\d+)\s*s)?/.exec(t)
  if (m) return +m[1]! * 60 + (m[2] ? +m[2] : 0)
  const q = /(\d+)\s*s/.exec(t)
  return q ? +q[1]! : 0
}
/** Konec stavka: pika, ki ji sledi velika začetnica ali konec besedila (»od 30. minute« ni konec). */
function sentenceBounds(text: string): number[] {
  const out: number[] = []
  const re = /\.(?=\s+[A-ZČŠŽĆĐ]|\s*$)/g
  for (let m = re.exec(text); m; m = re.exec(text)) out.push(m.index)
  return out
}
function whereIn(t: string): Where | null {
  if (/na sredi/i.test(t)) return 'middle'
  if (/v drugi uri/i.test(t)) return 'hour2'
  // »na koncu lahko (do konca)«, »na koncu 5 min hoje« je iztek, ne mesto bloka (v3.48)
  if (/v zadnji uri|na koncu(?!\s+(?:lahko|\d+\s*min\s+(?:lahko|hoje)))/i.test(t)) return 'end'
  return null
}
/** Odmor »vmes 4 min«, »(vmes 4–5 min zelo lahko)«, »vmes 4 min 30 s«; povprečje razpona. */
function restIn(t: string): number | null {
  const m = /vmes\s+(?:navzdol\s+)?(\d+(?:[.,]\d+)?)(?:\s*[–-]\s*(\d+(?:[.,]\d+)?))?\s*min(?:\s+(\d+)\s*s)?/i.exec(t)
  if (!m) return null
  const a = +m[1]!.replace(',', '.'), b = m[2] ? +m[2].replace(',', '.') : a
  return Math.round(((a + b) / 2) * 60) + (m[3] ? +m[3] : 0)
}

function parseDrills(text: string): Drill[] {
  const found: Drill[] = []
  const taken: [number, number][] = []
  const free = (a: number, b: number) => taken.every(([x, y]) => b <= x || a >= y)
  for (const m of text.matchAll(RE_REPS)) {
    const at = m.index!, end = at + m[0].length
    taken.push([at, end])
    found.push({ at, end, series: m[1] ? Math.max(1, +m[1]) : 1, reps: +m[2]!, work: secOf(m[3]!), rest: secOf(m[5]!), seriesRest: 0, txt: m[4] || '', where: null, walkRun: /hoja/i.test(m[6] || '') })
  }
  for (const m of text.matchAll(RE_OU)) {
    const at = m.index!, end = at + m[0].length
    if (!free(at, end)) continue
    taken.push([at, end])
    // drugi del lahek (»+ 1 min hoje«, »+ 2 min lahko«): navadne ponovitve z odmorom, ne over-under
    const easy = /hoj|lahk|počasi|odmor|vrti/i.test(m[6] || '')
    found.push({ at, end, series: m[1] ? Math.max(1, +m[1]) : 1, reps: +m[2]!, work: secOf(m[3]!), rest: easy ? secOf(m[5]!) : 0, seriesRest: 0, txt: m[4] || '', where: null, walkRun: easy && /hoj/i.test(m[6] || ''), ...(easy ? {} : { alt: { work: secOf(m[5]!), txt: m[6] || '' } }) })
  }
  for (const m of text.matchAll(RE_MIN)) {
    const at = m.index!, end = at + m[0].length
    if (!free(at, end)) continue
    taken.push([at, end])
    found.push({ at, end, series: 1, reps: +m[1]!, work: Math.round(+m[2]!.replace(',', '.') * 60), rest: null, seriesRest: 0, txt: '', where: null, walkRun: false })
  }
  for (const m of text.matchAll(RE_SEC)) {
    const at = m.index!, end = at + m[0].length
    if (!free(at, end)) continue
    taken.push([at, end])
    found.push({ at, end, series: 1, reps: +m[1]!, work: +m[2]!, rest: null, seriesRest: 0, txt: '', where: null, walkRun: false })
  }
  const list = found.filter(d => d.reps >= 1 && d.reps <= 60 && d.work > 0 && d.series <= 10).sort((a, b) => a.at - b.at)
  const ends = sentenceBounds(text)
  list.forEach((d, k) => {
    const sEnd = ends.find(e => e >= d.end) ?? text.length
    const sStart = [...ends].reverse().find(e => e < d.at) ?? -1
    const next = list[k + 1] && list[k + 1]!.at < sEnd ? list[k + 1]!.at : sEnd
    const after = text.slice(d.end, sEnd)
    if (!d.txt) { const t = text.slice(d.end, next); const v = t.search(/vmes/i); d.txt = v >= 0 ? t.slice(0, v) : t }
    if (d.rest == null) d.rest = restIn(after)
    if (d.series > 1) { const sr = /med\s+serijam[ai]\s+(\d+)\s*min(?:\s+(\d+)\s*s)?/i.exec(after); d.seriesRest = sr ? +sr[1]! * 60 + (sr[2] ? +sr[2] : 0) : 180 }
    const prevEnd = k && list[k - 1]!.end > sStart ? list[k - 1]!.end : sStart + 1
    d.where = whereIn(text.slice(prevEnd, d.at)) ?? whereIn(text.slice(d.end, next)) ?? (k && list[k - 1]!.end > sStart ? list[k - 1]!.where : null)
  })
  // (v3.49) »3 × 9 min …, vmes 5 min. Vsak interval 3 × (2 min … + 1 min …)« je en niz: 3 serije po 3 × (pod + nad pragom),
  // med serijami odmor bloka — prej 3 × 9 min enakomerno (opis z »+« ni bil razbran)
  return list.flatMap((d, k) => {
    if (!d.alt || !k) return [d]
    const sStart = [...ends].reverse().find(e => e < d.at) ?? -1
    const prev = list[k - 1]!
    if (!/vsak interval/i.test(text.slice(sStart + 1, d.at)) || prev.alt || prev.series > 1 || prev.work !== d.reps * (d.work + d.alt.work)) return [d]
    Object.assign(prev, { series: prev.reps, reps: d.reps, work: d.work, alt: d.alt, txt: d.txt, seriesRest: prev.rest ?? 5 * SEC, rest: 0 })
    return []
  })
}

/** Odmor med ponovitvami: zapisan, sicer kratke (≤ 60 s) 4 min, ključni ~60 % dela, v Z2 vožnji 5 min (10 min pri blokih ≥ 15 min). */
function drillRest(d: Drill, key: boolean): number {
  return d.rest ?? (d.work <= 60 ? 240 : key ? Math.max(60, Math.round((d.work * 0.6) / 60) * 60) : d.work >= 15 * SEC ? 10 * SEC : 5 * SEC)
}

/**
 * Najkrajše smiselno trajanje seje s strukturo (min): bloki z odmori + 5 min ogrevanja in 5 min izvoza, na 5 min navzgor;
 * 0 brez strukture. Načrt seje ne skrajša pod to (sicer bi se ponovitve na uri izšle čez načrtovani čas).
 */
export function minMinutes(day: Pick<PlanDay, 'title' | 'desc'> & { role?: PlanDay['role'] | null }): number {
  const fromDesc = parseDrills(day.desc || '')
  const drills = fromDesc.length ? fromDesc : parseDrills(day.title || '')
  if (!drills.length) return 0
  const key = day.role === 'kljucna' || /\d+\s*min ogrevanj/i.test(fromDesc.length ? day.desc || '' : day.title || '')
  let sec = 0
  drills.forEach((d, k) => {
    const r = drillRest(d, key)
    sec += d.series * (d.reps * (d.work + (d.alt?.work ?? 0)) + (d.reps - 1) * r) + (d.series - 1) * d.seriesRest
    if (k) sec += drillRest(drills[k - 1]!, key)
  })
  return Math.ceil((sec / 60 + 10) / 5) * 5
}

/** Intenzivnost ponovitev iz besedila: vati ali % FTP → delež FTP in cona; sicer ključne besede. */
function intensity(txt: string, p: Profile): { share: [number, number] | null; open: boolean; z: Z | null; kind: 'kadenca' | 'nizka' | 'tempo' | 'sprint' | null; cad: string | null } {
  const cadM = /(\d+\s*[–-]\s*\d+|\d+\+?)\s*obrat/.exec(txt)
  const cad = cadM ? cadM[1]!.replace(/\s+/g, '') : null
  const kind = cad ? (+(cad.match(/\d+/g)?.pop() ?? 90) <= 80 ? 'nizka' : 'kadenca') : /kadenc/i.test(txt) ? 'kadenca' : /šprint|vse, kar gre|napad/i.test(txt) ? 'sprint' : /tempo/i.test(txt) ? 'tempo' : null
  const ftp = p.ftp && p.ftp > 0 ? p.ftp : null
  let share: [number, number] | null = null, open = false
  const w2 = /(\d{2,4})\s*[–-]\s*(\d{2,4})\s*W\b/.exec(txt), pc2 = /(\d{2,3})\s*[–-]\s*(\d{2,3})\s*%\s*FTP/.exec(txt)
  const w1 = /(\d{2,4})\s*W\s+in\s+več/.exec(txt), pc1 = /nad\s+(\d{2,3})\s*%\s*FTP/.exec(txt)
  if (w2 && ftp) share = [+w2[1]! / ftp, +w2[2]! / ftp]
  else if (pc2) share = [+pc2[1]! / 100, +pc2[2]! / 100]
  else if (w1 && ftp) { share = [+w1[1]! / ftp, (+w1[1]! / ftp) * 1.3]; open = true }
  else if (pc1) { share = [+pc1[1]! / 100, (+pc1[1]! / 100) * 1.3]; open = true }
  let z: Z | null = null
  if (share) { const m = (share[0] + share[1]) / 2; z = m < 0.56 ? 'Z1' : m < 0.76 ? 'Z2' : m < 0.91 ? 'Z3' : m < 1.06 ? 'Z4' : m < 1.5 ? 'Z5' : 'max' }
  else if (kind === 'kadenca' || kind === 'nizka') z = 'Z2'
  else if (kind === 'sprint') z = 'max'
  else if (kind === 'tempo') z = 'Z3'
  else { const r = /RPE\s*(\d+)/.exec(txt); if (r) z = +r[1]! >= 9 ? 'Z5' : +r[1]! >= 8 ? 'Z4' : 'Z3' }
  return { share, open, z, kind, cad }
}

export function stepsFor(day: PlanDay, p: Profile): Step[] {
  if (day.kind === 'pocitek') return []
  if (day.kind === 'moc') return strengthSteps(day, p)
  const dur = Math.max(10, Number.isFinite(day.durationMin) ? day.durationMin : 0)
  const total = dur * SEC

  // 20-minutni test — samo, kadar je dan res test (ne »2 × 20 min« praga ali Kladja)
  if (day.kind === 'test' || day.role === 'test') {
    const wu = day.kind === 'tek' ? 10 : 15
    const easy = dur - wu - 20 >= 15 ? 5 : 0                     // »5 min lahko« pred testom, če je čas
    return [
      { kind: 'ogrevanje', z: 'Z2', label: 'Ogrevanje', sec: wu * SEC, target: zoneFor(p, day.kind, 'Z2'), note: 'Zadnjih 5 min nekaj kratkih pospeškov.' },
      ...(easy ? [{ kind: 'lahko' as const, z: 'Z1' as const, label: 'Lahko', sec: easy * SEC, target: zoneFor(p, day.kind, 'Z1'), note: 'Zadihaj, pij — takoj za tem test.' }] : []),
      noPower(p)
        ? { kind: 'test', z: 'max', label: '20-minutni test', sec: 20 * SEC, target: 'čim močneje, enakomerno', note: 'Prvih 5 min malo pod tem, kar misliš, da zmoreš; sredina enakomerno; zadnjih 5 min stisni vse. Brez merilnika moči: povprečni utrip zadnjih 15 min ≈ tvoj pražni utrip (LTHR) — vpišeš ga na koncu, cone se posodobijo. Najbolje na istem klancu kot zadnjič, da se rezultati dajo primerjati.' }
        : { kind: 'test', z: 'max', label: '20-minutni test', sec: 20 * SEC, target: p.ftp ? `začni pri ~${Math.round(p.ftp * 1.02)} W` : 'čim močneje, enakomerno', note: 'Prvih 5 min malo pod tem, kar misliš, da zmoreš; sredina enakomerno; zadnjih 5 min stisni vse. Sede, kadenca 90+. Povprečje vpiši v Napredek → Testi.' },
      { kind: 'iztek', z: 'Z1', label: 'Iztek', sec: Math.max(5, dur - wu - easy - 20) * SEC, target: zoneFor(p, day.kind, 'Z1') },
    ]
  }

  const tw = workText(p, day)

  // dirka: ogrevanje iz opisa in korak »Tekma« brez časovnika (konča se z »Zaključi«); vodilo po tekmi (Kladje samo pri Franji)
  if (day.role === 'dirka') return raceSteps(day, p, tw)

  // struktura iz opisa (sicer iz naslova)
  const fromDesc = parseDrills(day.desc || '')
  const drills = fromDesc.length ? fromDesc : parseDrills(day.title)
  const src = fromDesc.length ? day.desc || '' : day.title
  if (drills.length) return assemble(day, p, drills, src, total, tw)
  // en blok brez »N ×« (»10 min lahko, nato 15 min udobno hitro (utrip …)«) je 1 × 15 min — prej 2 × 8 min iz hardFallback (v3.48)
  const one = ONE_BLOCK.test(day.desc || '') ? (day.desc || '').replace(ONE_BLOCK, 'nato 1 × $1 min ') : null
  const d1 = one ? parseDrills(one) : []
  if (one && d1.length) return assemble(day, p, d1, one, total, tw)
  // trd dan brez zapisanih ponovitev (Blaž, 17. 10.: »Kolo — intervali 1 h« je bil 48 min enakomerno Z2 — »tole niso lih
  // intervali«): aplikacija doda ponovitve po trajanju in ravni, namesto da bi intervali postali lahka vožnja
  const syn = hardFallback(day, p, dur)
  if (syn) { const d2 = parseDrills(syn); if (d2.length) return assemble(day, p, d2, syn, total, tw) }

  // enakomerno (dolga, lahka)
  // ogrevanje in iztek na 5 min (prej »13 min ogrevanje · 84 min · 8 min iztek«)
  // (v3.51) ogrevanje in iztek, kot ju piše opis (trening s slike: »10 min ogrevanja. … 10 min iztek.«) — prej 15/95/10 ob vpisanih 10/100/10
  const wuT = /(\d+)\s*min ogrevanj/i.exec(day.desc || ''), cdT = /(\d+)\s*min (?:izvoz|iztek)/i.exec(day.desc || '')
  const ownM = (m: RegExpExecArray | null) => (m && +m[1]! > 0 && +m[1]! <= dur / 3 ? +m[1]! : null)
  const wu = ownM(wuT) ?? Math.min(15, r5m(dur * 0.12))
  const cd = ownM(cdT) ?? Math.min(10, r5m(dur * 0.08))
  const main = Math.max(5 * SEC, total - (wu + cd) * SEC)
  const z = day.zone === 'Z3' ? 'Z3' : day.zone === 'Z1' ? 'Z1' : 'Z2'
  const fuel = dur >= 75 ? ' Jej in pij po urniku — aplikacija te opomni.' : ''
  // (v3.49) razgibana dolga vožnja: navodilo za klance iz opisa v koraku (»Vse klance v tempu …«) — prej samo Z2
  const hillM = day.kind === 'kolo' ? /\b(?:vse )?klance\b[^.;]*/i.exec(day.desc || '') : null
  const hill = hillM ? `${hillM[0].charAt(0).toUpperCase()}${hillM[0].slice(1).trim()}. ` : ''
  // regeneracija (Z1): en korak — ogrevanje, delo in iztek v isti coni so bili trije enaki koraki z dvema piskoma (v3.48)
  if (z === 'Z1') return [{ kind: 'delo', z, label: steadyLabel(day), sec: total, target: day.kind === 'kolo' ? zone(p, 'Z1') : 'zelo lahko', note: cueOf(day.kind, 'Z1') + fuel }]
  return [
    { kind: 'ogrevanje', z: 'Z1', label: 'Ogrevanje', sec: wu * SEC, target: zoneFor(p, day.kind, 'Z1'), note: warmNote(day.kind) },
    { kind: 'delo', z, label: steadyLabel(day), sec: main, target: day.kind === 'kolo' ? zone(p, z) : 'pogovorni tempo', note: hill + cueOf(day.kind, z === 'Z3' ? 'Z3' : 'Z2') + fuel },
    { kind: 'iztek', z: 'Z1', label: 'Iztek', sec: cd * SEC, target: zoneFor(p, day.kind, 'Z1'), note: cueOf(day.kind, 'iztek') },
  ]
}

/** Na 5 min, najmanj 5 (ogrevanje in iztek). */
const r5m = (x: number) => Math.max(5, Math.round(x / 5) * 5)
/** »nato 15 min udobno hitro«, »nato 20 min tempo« — en blok dela brez »N ×«. */
const ONE_BLOCK = /\bnato\s+(\d+)\s*min\s+(?=(?:udobno\s+)?hitro|tempo|na pragu|sweet spot)/i

/**
 * (v3.48) Tekma v vodeni vadbi: ogrevanje iz opisa (»Ogrevanje 25 min s 3 × 2 min na pragu«), nato korak »Tekma« brez
 * časovnika — štoparica teče, dokler ne tapneš »Zaključi« (prej odštevanje 30:00, ki se je končalo samo, tudi sredi proge).
 * Opomba koraka je tempo tekme, brez zajtrka in goriva (to je pred vadbo in v opomnikih).
 */
function raceSteps(day: PlanDay, p: Profile, tw: string | null): Step[] {
  const desc = refreshHr((day.desc || '').replace(/\s+/g, ' ').trim(), p)
  const wm = /ogrevanje\s+(\d+)(?:\s*[–-]\s*\d+)?\s*min([^.;]*)/i.exec(desc)
  const pace = desc.split(/(?<=[.!?])\s+(?=[A-ZČŠŽ])/u)
    .filter(x => !/^(Zajtrk|Na kolesu|Dan prej)\b/u.test(x))
    .map(x => x.replace(/^Ogrevanje[^.;]*[.;]\s*/u, '').trim())
    .filter(Boolean).join(' ')
  const extra = wm ? wm[2]!.trim() : ''
  return [
    ...(wm ? [{ kind: 'ogrevanje' as const, z: 'Z2' as const, label: 'Ogrevanje', sec: +wm[1]! * SEC, target: zone(p, 'Z2'), note: `Lahko${extra ? `, ${extra}` : ''}.` }] : []),
    { kind: 'delo', label: 'Tekma', sec: 0, target: raceTarget(desc, p) ?? (tw ? (/franj/i.test(day.title) ? `Kladje ${tw}` : tw) : 'enakomerno'), note: `${pace ? pace.charAt(0).toUpperCase() + pace.slice(1) + ' ' : ''}Ko prečkaš cilj, tapni Zaključi.` },
  ]
}

/**
 * (v3.49) Kronometer: cilj glavnega dela iz tempa v opisu (»Prvih 5 min …, nato pri utripu 184–188« / »nato 240–252 W«) —
 * kratek kronometer je malo nad pragom, splošni »na pragu« iz cilja dneva bi bil prenizek. Sicer null.
 * (v3.50) S profilom: utrip po TRENUTNEM pražnem utripu (nov test ga spremeni, opis dneva pa ostane star).
 */
export function raceTarget(desc: string | null | undefined, p?: Pick<Profile, 'lthr' | 'maxHr' | 'restHr' | 'ftp' | 'gear'> | null): string | null {
  const m = /Prvih 5 min [^.]*?, nato (?:pri utripu (\d+–\d+)|(\d+–\d+ W)|na pragu \(([^)]+)\)|(RPE \d+))/.exec(p ? refreshHr(desc || '', p) : desc || '')
  return m ? (m[1] ? `utrip ${m[1]}` : m[2] ?? m[3] ?? m[4]!) : null
}

/**
 * (v3.50) Utrip v opisu dneva po novem pražnem utripu (test brez merilnika): vsaka številka za »utrip/utripu (pod|nad|do)«
 * × novi / stari prag — cone so deleži praga (149–164 pri 184 → 154–169 pri 190). Prej so opisi ostali s staro lestvico.
 */
export function rescaleHr(text: string | null | undefined, from: number | null | undefined, to: number | null | undefined): string {
  const t = text || ''
  if (!t || !from || !to || from === to) return t
  const k = to / from
  return t.replace(/(utrip(?:u|a)?\s+(?:pod\s+|nad\s+|do\s+)?)(\d{2,3})(?:\s*–\s*(\d{2,3}))?/gi, (_m, pre: string, a: string, b?: string) => `${pre}${Math.round(+a * k)}${b ? `–${Math.round(+b * k)}` : ''}`)
}

/**
 * (v3.50) Tempo tekme v utripu po trenutnem pražnem utripu: opis (»nato pri utripu 184–188«, »utrip do 171«, »na pragu
 * (utrip 172–184)«) je nastal ob sestavi tedna; po testu brez merilnika bi vodena vadba sicer kazala staro lestvico.
 * Kratek kronometer: vse številke zamaknjene za razliko pražnega utripa; daljši: meje iz con. Brez pražnega utripa ali
 * z merilnikom nespremenjeno.
 */
export function refreshHr(desc: string, p: Pick<Profile, 'lthr' | 'maxHr' | 'restHr' | 'ftp' | 'gear'>): string {
  const L = lthrOf(p)
  if (!L || !noPower(p) || !desc) return desc
  const short = /nato pri utripu (\d+)–(\d+)/.exec(desc)
  if (short) {
    const d = L - +short[1]!
    return d ? desc.replace(/pri utripu (\d+)–(\d+)/g, (_, a: string, b: string) => `pri utripu ${+a + d}–${+b + d}`) : desc
  }
  const z4 = lthrZoneText(p, 'Z4')
  return desc.replace(/utrip do \d+/, `utrip do ${Math.round(L * 0.93)}`).replace(/na pragu \(utrip \d+–\d+\)/, z4 ? `na pragu (${z4})` : 'na pragu')
}

/**
 * (v3.51) Opis dneva za prikaz brez merilnika moči: razpon utripa dela po trenutnih conah (opis je nastal ob sestavi — prej
 * vrstica cilja »165–171«, opis »166–171«), »pri utripu« (ne »pri utrip«) in brez »≈ … W« (vatov brez merilnika ne vidiš).
 * Razpon, ki ni razpon dela (več kot 3 udarce stran), ostane. Z merilnikom nespremenjeno.
 */
export function descShown(desc: string, p: Pick<Profile, 'lthr' | 'maxHr' | 'restHr' | 'ftp' | 'gear'>, d: { target?: { lo: number; hi: number } | null; zone?: string | null }): string {
  if (!desc || !noPower(p)) return desc
  const wt = workText(p, d)
  const m = wt ? /^utrip (\d+)–(\d+)$/.exec(wt) : null
  return desc
    .replace(/pri utripu? (\d{2,3})–(\d{2,3})/g, (_x, a: string, b: string) => {
      const near = !!m && Math.abs(+a - +m[1]!) <= 3 && Math.abs(+b - +m[2]!) <= 3
      return `pri utripu ${near ? `${m![1]}–${m![2]}` : `${a}–${b}`}`
    })
    .replace(/\s*\(≈\s*\d+–\d+\s*W(?:, brez merilnika po občutku)?\)/g, '')
}

/** Ali besedilo vsebuje ponovitve, ki jih vodena vadba razume (»4 × 6 min«, »6 × (1 min / 2 min)«, »8 × 30 s«). */
export const hasDrills = (text: string | null | undefined): boolean => parseDrills(text || '').length > 0

/**
 * Ponovitve za trd dan, ki jih nima zapisanih (intervali Z4/Z5 ali tempo Z3 ključnega dne): po trajanju in ravni, enako
 * kot privzete seje aplikacije (kolo n × 4 min / 3 min, tek n × (2–3 min / 2 min), tempo 2 × 10–12 min). Sicer null.
 */
export function hardFallback(day: Pick<PlanDay, 'kind' | 'zone' | 'title' | 'desc' | 'role'>, p: Profile, dur: number): string | null {
  if (day.kind !== 'kolo' && day.kind !== 'tek') return null
  const txt = `${day.title} ${day.desc || ''}`
  const intervals = day.zone === 'Z4' || day.zone === 'Z5' || /\binterval/i.test(day.title)
  const tempo = !intervals && day.zone === 'Z3' && (day.role === 'kljucna' || /tempo|prag|sweet/i.test(txt))
  if (!intervals && !tempo) return null
  const lvl = p.focus?.level ?? (p.level != null ? Math.min(3, Math.max(1, p.level)) : 2)
  if (day.kind === 'kolo') {
    if (tempo) { const n = dur >= 75 ? 3 : 2; return dur < 40 ? null : `15 min lahko, nato ${n} × ${dur >= 55 ? 12 : 8} min tempo, vmes 5 min lahko.` }
    const avail = dur - 25
    if (avail < 12) return null
    const z5 = day.zone === 'Z5'
    const on = z5 ? 3 : 4, off = z5 ? 3 : 3
    const n = Math.max(2, Math.min(lvl === 1 ? 3 : lvl === 2 ? 4 : 5, Math.floor((avail + off) / (on + off))))
    return `15 min lahko, nato ${n} × ${on} min ${z5 ? 'zelo hitro' : 'hitro'}, vmes ${off} min lahko. Preostanek lahko, zadnjih 10 min zelo lahko.`
  }
  if (tempo) return dur < 30 ? null : `10 min lahko, nato 2 × ${dur >= 50 ? 12 : 8} min udobno hitro, vmes 3 min lahko.`
  if (dur < 20) return null
  const w = lvl >= 3 ? 3 : 2
  const n = Math.max(3, Math.min(lvl === 1 ? 6 : 8, Math.round((dur - 17) / (w + 2))))
  return `12 min lahkega teka, nato ${n} × (${w} min hitro / 2 min lahko). 5 min lahko na koncu.`
}

/** Ime enakomernega dela: brez trajanja celega treninga (»125 min Kolo — daljša vožnja 2 h 30 min« je zmedlo — korak je 125 min). */
function steadyLabel(day: PlanDay): string { return titleNoDur(day.title, day.durationMin) }

/** Ogrevanje, bloki na svojem mestu, Z2 do načrtovanega trajanja, izvoz. */
function assemble(day: PlanDay, p: Profile, drills: Drill[], src: string, total: number, tw: string | null): Step[] {
  const dur = total / SEC
  const bike = day.kind !== 'tek' && day.kind !== 'pohod'
  const key = day.role === 'kljucna' || /\d+\s*min ogrevanj/i.test(src)
  const keyZone: Zn = day.zone === 'Z3' ? 'Z3' : day.zone === 'Z5' ? 'Z5' : 'Z4'
  const zn = (z: Zn) => zoneFor(p, day.kind, z)
  // ogrevanje in iztek tudi, kot ju piše opis (»15 min lahko, nato«, »12 min lahkega teka, nato«, »zadnjih 10 min zelo
  // lahko«, »5 min lahko na koncu«), sicer po trajanju na 5 min (prej 11, 12, 14 min ogrevanja, 7–9 min izteka) (v3.48)
  const wuM = /(\d+)\s*min ogrevanj/i.exec(src) ?? /^(\d+)\s*min\s+(?:lahko|lahkega teka|hitre hoje)\b[^.]*?,\s*nato\b/i.exec(src.trim())
  const cdM = /(\d+)\s*min (?:izvoz|iztek)/i.exec(src) ?? /zadnjih\s+(\d+)\s*min\s+(?:zelo\s+)?lahko/i.exec(src) ?? /(\d+)\s*min\s+(?:lahko|hoje)\s+na koncu/i.exec(src) ?? /na koncu\s+(\d+)\s*min\s+(?:hoje|lahko)/i.exec(src)
  const fromTxt = (m: RegExpExecArray | null) => (m && +m[1]! > 0 && +m[1]! <= dur / 2 ? +m[1]! : null)
  let wu = (fromTxt(wuM) ?? (key ? Math.min(15, Math.max(10, r5m(dur * 0.2))) : Math.min(15, r5m(dur * 0.12)))) * SEC
  let cd = (fromTxt(cdM) ?? (key ? Math.min(10, r5m(dur * 0.12)) : Math.min(10, r5m(dur * 0.08)))) * SEC
  const fuelNote = dur >= 75 ? ' Jej in pij po urniku — aplikacija te opomni.' : ''
  // (v3.49) lahek tek in hoja (začetnik): bloki takoj po ogrevanju, ogrevanje in ostanek sta hitra hoja, tek v Z2
  const walkDay = !key && day.kind === 'tek' && drills.every(d => d.walkRun)

  const restZ = (d: Drill): Zn => (key || d.work <= 60 ? 'Z1' : 'Z2')
  const blocks = drills.map((d0, g) => {
    // over-under samo na kolesu; drugje (tek) je drugi del odmor
    if (d0.alt && bike) return { d: d0, steps: overUnderSteps(d0, g, p, zn), rest: drillRest(d0, key), rz: 'Z1' as Zn }
    const d: Drill = d0.alt ? { ...d0, rest: d0.alt.work, alt: undefined } : d0
    const it = intensity(d.txt, p)
    const main = key && g === 0 && !d.walkRun
    const share = it.share ?? null
    // blok, ki je delo dneva v Z2 vožnji (»3 × 5 min tempo dirke« pri 88–95 % FTP): cona dneva (tempo, Z3), ne Z4 iz vatov (v3.48)
    const dayWork = !key && !!day.target && !!share && !!p.ftp && Math.abs(share[0] * p.ftp - day.target.lo) <= 2
    const z: Z = main ? (it.share && it.z ? it.z : keyZone) : dayWork ? workZone(day.zone) : it.z ?? (key ? keyZone : walkDay ? 'Z2' : 'Z3')
    const zz: Zn = z === 'max' ? 'Z5' : z
    // tek in hoja: hitri del ima cilj iz opisa (»Hitreje = utrip 163–174«), »pogovorni tempo« samo lahek tek (v3.48)
    const fastRun = d.walkRun && (key || /hitr/i.test(d.txt))
    // kratki napori brez merilnika: utrip zaostaja — po občutku (kot opis), ne »utrip nad 184« (v3.48)
    const feel = bike && noPower(p) && d.work <= 120 && (z === 'Z4' || z === 'Z5' || z === 'max')
    const target = d.walkRun ? (fastRun ? zn(zz) : 'pogovorni tempo')
      : feel ? (z === 'max' ? 'vse, kar gre' : `RPE ${z === 'Z4' ? 8 : 9} · po občutku`)
      : main && tw ? tw
      // (v3.50) kratka hitra kadenca (do 2 min): cilj so obrati in lahka prestava, ne utrip (prej »utrip 149–164« za 30 s)
      : it.kind === 'kadenca' && d.work <= 120 ? `kadenca ${it.cad ?? CAD_DEFAULT} · lahka prestava`
      : it.kind === 'kadenca' || it.kind === 'nizka' ? `${zone(p, 'Z2')}${it.cad ? ` · kadenca ${it.cad}` : ''}`
      : share ? (noPower(p) ? lthrZoneText(p, zz) ?? zone(p, zz) : p.ftp ? (it.open ? `${Math.round(p.ftp * share[0])}+ W` : `${Math.round(p.ftp * share[0])}–${Math.round(p.ftp * share[1])} W`) : it.open ? `${Math.round(share[0] * 100)}+ % FTP` : `${Math.round(share[0] * 100)}–${Math.round(share[1] * 100)} % FTP`)
      : z === 'max' ? 'vse, kar gre'
      : tw || zn(zz)
    // (v3.49) blok na klancu v dolgi vožnji (»3 × 15 min … na daljših klancih«): »Klanec«, ne »Tempo … na ravnini«
    const climb = !key && !d.walkRun && /na (?:daljših |dolgih )?klanc/i.test(d.txt)
    const label = climb ? 'Klanec' : d.walkRun ? 'Tek' : it.kind === 'sprint' ? (/šprint|vse, kar gre/i.test(d.txt) ? 'Šprint' : 'Napad') : it.kind === 'kadenca' ? 'Kadenca' : it.kind === 'nizka' ? 'Nizka kadenca' : d.series > 1 || d.work < 60 ? 'Ponovitev' : z === 'Z3' && (d.reps === 1 || !key) ? 'Tempo' : key ? 'Interval' : 'Blok'
    const cue = climb ? cueOf(day.kind, 'klanec') : walkDay ? RUN_EASY : it.kind === 'kadenca' ? CUE.kadenca! : it.kind === 'nizka' ? CUE.nizka! : it.kind === 'tempo' || (!key && !main && z === 'Z3') ? cueOf(day.kind, 'tempo') : cueOf(day.kind, z)
    const rest = drillRest(d, key)
    const rz = restZ(d)
    const out: Step[] = []
    for (let s = 1; s <= d.series; s++) {
      for (let i = 1; i <= d.reps; i++) {
        const note = (d.series > 1 && i === 1 ? `Serija ${s}/${d.series}. ` : '') + (main && i === 1 ? cue + ' Prvih 30 s ne prehitro.' : main && i === d.reps ? cue + ' Zadnji — daj vse v razponu.' : cue)
        out.push({ kind: 'delo', z, label: d.reps > 1 ? `${label} ${i}/${d.reps}` : label, sec: d.work, target, set: i, sets: d.reps, group: g, ...(d.series > 1 ? { series: s, seriesOf: d.series } : {}), ...(share ? { ftpShare: share } : {}), note })
        if (i < d.reps) out.push({ kind: 'lahko', z: rz, label: d.walkRun ? 'Hoja' : 'Lahko', sec: rest, target: d.walkRun ? 'hitra hoja' : zn(rz), note: d.walkRun ? WALK_REST : cueOf(day.kind, 'odmor'), group: g })
      }
      if (s < d.series) out.push({ kind: 'lahko', z: rz, label: `Med ${d.series === 2 ? 'serijama' : 'serijami'}`, sec: d.seriesRest, target: zn(rz), note: `${bike ? 'Vrti lahko' : 'Lahko ali hoja'}, pij. Naslednja serija enako kakovostno kot prva.`, group: g })
    }
    return { d, steps: out, rest, rz }
  })
  const gap = (b: (typeof blocks)[number]): Step => ({ kind: 'lahko', z: b.rz, label: 'Lahko', sec: b.rest, target: zn(b.rz), note: cueOf(day.kind, 'odmor') })
  const seq = (list: typeof blocks): Step[] => list.flatMap((b, k) => (k ? [gap(list[k - 1]!), ...b.steps] : b.steps))
  const head = blocks.filter(b => b.d.where !== 'end'), tail = blocks.filter(b => b.d.where === 'end')
  const place: Where = head.length ? head[0]!.d.where ?? (key || walkDay ? 'start' : day.role === 'dolga' ? 'end' : 'middle') : 'end'
  const A = place === 'end' ? [] : seq(head), B = place === 'end' ? seq([...head, ...tail]) : seq(tail)
  // med blokom na sredi in blokom na koncu vsaj odmor prvega (Z2 vmes ga nadomesti, če je dovolj dolga)
  const needGap = A.length && B.length ? head[head.length - 1]!.rest : 0
  // Z2 do načrtovanega trajanja (ogrevanje in izvoz se skrajšata, če je struktura daljša od načrta)
  let fill = total - wu - cd - totalSec(A) - totalSec(B)
  if (fill < needGap) { const c = Math.min(needGap - fill, Math.max(0, cd - 5 * SEC)); cd -= c; fill += c }
  if (fill < needGap) { const c = Math.min(needGap - fill, Math.max(0, wu - 5 * SEC)); wu -= c; fill += c }
  fill = Math.max(0, fill)
  // (v3.50) iztek, kot ga piše opis (»na koncu 5 min hoje«), ostane tak — ostanek gre v lahek del pred njim (prej 6 min 30 s izteka)
  if (!needGap && fill > 0 && fill < 3 * SEC && fromTxt(cdM) == null) { cd += fill; fill = 0 }
  let before = place === 'start' ? 0 : place === 'middle' ? Math.round(fill / 2 / SEC) * SEC : place === 'hour2' ? Math.min(fill, Math.max(0, Math.round((60 * SEC - wu) / SEC) * SEC)) : fill
  if (fill - before < needGap) before = Math.max(0, fill - needGap)
  if (before < SEC) before = 0
  let between = fill - before
  if (!needGap && between > 0 && between < SEC) { cd += between; between = 0 }
  // tek: »Lahek tek«, hribi: »Hoja« (prej »Z2 vzdržljivost« tudi pri teku) (v3.48)
  const z2 = (sec: number): Step[] => (sec >= 30 ? [walkDay
    ? { kind: 'lahko', z: 'Z1', label: 'Hitra hoja', sec, target: null, note: WALK }
    : { kind: 'lahko', z: 'Z2', label: bike ? 'Z2 vzdržljivost' : day.kind === 'pohod' ? 'Hoja' : 'Lahek tek', sec, target: bike ? zone(p, 'Z2') : 'pogovorni tempo', note: cueOf(day.kind, 'Z2') + fuelNote }] : [])
  // kratek presledek med blokoma je odmor (lahko), daljši je Z2
  const mid: Step[] = A.length && B.length && between > 0 && between < 3 * SEC ? [{ ...gap(head[head.length - 1]!), sec: between }] : z2(between)
  return [
    key
      ? { kind: 'ogrevanje', z: 'Z2', label: 'Ogrevanje', sec: wu, target: zn('Z2'), note: bike ? CUE.ogrevanje : `${warmNote(day.kind)} Zadnjih 5 min 3 × 30 s hitreje, da odpreš noge.` }
      : walkDay ? { kind: 'ogrevanje', z: 'Z1', label: 'Ogrevanje', sec: wu, target: 'hitra hoja', note: WALK }
      : { kind: 'ogrevanje', z: 'Z1', label: 'Ogrevanje', sec: wu, target: zn('Z1'), note: warmNote(day.kind) },
    ...z2(before), ...A, ...mid, ...B,
    { kind: 'iztek', z: 'Z1', label: 'Iztek', sec: cd, target: walkDay ? 'hoja' : zn('Z1'), note: walkDay ? 'Hoja, da se dihanje umiri. Nato raztezanje.' : cueOf(day.kind, 'iztek') },
  ]
}

/** (v3.49) delež FTP iz dela over-underja: razpon (vati, % FTP) ali ena številka (»pri 95 %«, »pri 228 W«) */
function partShare(txt: string, p: Profile): [number, number] | null {
  const it = intensity(txt, p).share
  if (it) return it
  const pc = /(\d{2,3})\s*%/.exec(txt), w = /(\d{2,4})\s*W\b/.exec(txt)
  return pc ? [+pc[1]! / 100, +pc[1]! / 100] : w && p.ftp ? [+w[1]! / p.ftp, +w[1]! / p.ftp] : null
}
const OU_UNDER = 'RPE 7/10 — tik pod pragom: enakomerno, okrevaš, a ne popustiš.'
const OU_OVER = 'RPE 8–9/10 — malo nad pragom: pospeši, noge zapečejo. Nato nazaj pod prag, ne lahko.'
/**
 * (v3.49) Over-under: v vsaki seriji izmenično »Pod pragom« in »Nad pragom« brez odmora, med serijami lahko. Z merilnikom
 * vati vsakega dela, brez njega občutek (utrip pri 1-min menjavah zaostaja). Delež FTP ostane za trenažer (.zwo).
 */
function overUnderSteps(d: Drill, g: number, p: Profile, zn: (z: Zn) => string): Step[] {
  const ftp = p.ftp && p.ftp > 0 ? p.ftp : null
  const sh1 = partShare(d.txt, p) ?? [0.93, 0.97], sh2 = partShare(d.alt!.txt, p) ?? [1.03, 1.07]
  const tgt = (sh: [number, number], feel: string) => (noPower(p) ? feel
    : ftp ? (sh[0] === sh[1] ? `${Math.round(ftp * sh[0])} W` : `${Math.round(ftp * sh[0])}–${Math.round(ftp * sh[1])} W`)
    : sh[0] === sh[1] ? `${Math.round(sh[0] * 100)} % FTP` : `${Math.round(sh[0] * 100)}–${Math.round(sh[1] * 100)} % FTP`)
  const t1 = tgt(sh1, 'tik pod pragom · RPE 7'), t2 = tgt(sh2, 'malo nad pragom · RPE 8–9')
  const out: Step[] = []
  for (let s = 1; s <= d.series; s++) {
    const ser = d.series > 1 ? { series: s, seriesOf: d.series } : {}
    for (let i = 1; i <= d.reps; i++) {
      const lead = d.series > 1 && i === 1 ? `Serija ${s}/${d.series}. ` : ''
      out.push({ kind: 'delo', z: 'Z4', label: `Pod pragom ${i}/${d.reps}`, sec: d.work, target: t1, set: i, sets: d.reps, group: g, ...ser, ftpShare: sh1, note: lead + OU_UNDER })
      out.push({ kind: 'delo', z: 'Z5', label: `Nad pragom ${i}/${d.reps}`, sec: d.alt!.work, target: t2, set: i, sets: d.reps, group: g, ...ser, ftpShare: sh2, note: OU_OVER })
    }
    if (s < d.series) out.push({ kind: 'lahko', z: 'Z1', label: `Med ${d.series === 2 ? 'serijama' : 'serijami'}`, sec: d.seriesRest, target: zn('Z1'), note: 'Vrti lahko, pij. Naslednja serija enako kakovostno kot prva.', group: g })
  }
  return out
}

/** Kako se vaja izvede: kolesarske vaje (HOW), sicer knjižnica vaj. */
export const howOf = (name: string): string => HOW[name] || exByName(name)?.how || ''

/** (v3.51) ime koraka »na koncu« s slike (structureLines ga zapiše brez »1 × …«) */
export const FIN_LABEL = 'Na koncu s slike'
/** (v3.51) Opomba s slike (opis »S slike: …«) z AMRAP, EMOM, »na koncu« ali »finisher« → korak; minute → časovnik. */
export function finisherOf(desc: string): Step | null {
  const m = /S slike:\s*(.+?)(?:\s+Med serijami \d+ s\.)?$/.exec(desc || '')
  const t = m?.[1]?.trim()
  if (!t || !/\b(amrap|emom|na koncu|finisher|for time)\b/i.test(t)) return null
  const min = /(\d{1,2})\s*min/i.exec(t)
  const sec = min && +min[1]! >= 1 && +min[1]! <= 30 ? +min[1]! * SEC : 0
  return { kind: 'vaja', label: FIN_LABEL, sec, reps: t.replace(/\.$/, ''), set: 1, sets: 1, note: sec ? 'Čim več krogov v tem času, lepo izvedeno. Ko se izteče, sledi raztezanje.' : 'Naredi, kot piše, nato tapni naprej.' }
}
function strengthSteps(day: PlanDay, p: Profile): Step[] {
  const ex = day.exercises || []
  if (!ex.length) return [{ kind: 'vaja', label: day.title, sec: 0, note: day.desc }, ...tailSteps(day, p)]
  // ogrevanje in pavze, kot piše opis (»8–10 min ogrevanja (kolo ali veslanje)«, »… 90 s pri ostalih«) — prej vedno
  // 5 min in 60 s (v3.48)
  const desc = day.desc || ''
  const wm = /(\d+)(?:\s*[–-]\s*\d+)?\s*min ogrevanj[a-z]*(?:\s*\(([^)]+)\)|:\s*([^.]+))?/i.exec(desc)
  const wuMin = wm ? Math.max(3, Math.min(15, +wm[1]!)) : 5
  const wuNote = wm && (wm[2] || wm[3]) ? `${(wm[2] || wm[3])!.trim().replace(/^./, c => c.toUpperCase())}.` : 'Kroženje, lahki počepi, izpadni koraki brez uteži.'
  const restTxt = /(\d+)\s*s pri ostalih/i.exec(desc) ?? /med serijami\s+(\d+)\s*s\b/i.exec(desc)
  // (v3.49) tudi v minutah in z razponom (»Med serijami 2–3 min« = 150 s) — prej 60 s pri težkih počepih
  const restMin = restTxt ? null : /med serijami\s+(\d+)(?:\s*[–-]\s*(\d+))?\s*min\b/i.exec(desc)
  const minRest = restTxt ? +restTxt[1]! : restMin ? Math.round(((+restMin[1]! + +(restMin[2] ?? restMin[1]!)) / 2) * 60) : 0
  const steps: Step[] = [{ kind: 'ogrevanje', label: 'Ogrevanje', sec: wuMin * SEC, note: wuNote }]
  for (const e of ex) {
    const timed = /(\d+)\s*s\b/.exec(e.reps)
    const how = howOf(e.name)
    // pavza po vaji: težke serije dlje (do 3 min), sicer 60 s ali kot piše opis; med vajami vsaj 90 s;
    // (v3.49) vaje s palico brez svoje pavze (kolesarski fitnes) najmanj 2 min; pavza v minutah ne velja za vaje na čas (deska)
    const bar = e.rest == null && !timed && /počep s palico|mrtvi dvig|hip thrust/i.test(e.name) ? 120 : 0
    const rest = Math.max(30, Math.min(180, Math.max(e.rest ?? 60, restMin && timed ? 0 : minRest, bar)))
    for (let s = 1; s <= e.sets; s++) {
      steps.push({ kind: 'vaja', label: e.name, sec: timed ? +timed[1]! : 0, reps: e.reps + (e.kg ? ` · ${String(e.kg).replace('.', ',')} kg` : ''), set: s, sets: e.sets, note: (how ? how + ' ' : '') + (timed ? '' : 'Ko končaš serijo, tapni naprej.') })
      // (v3.51) »Odmor« — »Pavza« je gumb, ki ustavi čas (prej korak »Pavza 1:00« nad gumbom »Pavza«)
      if (s < e.sets) steps.push({ kind: 'pavza', label: 'Odmor', sec: rest })
    }
    steps.push({ kind: 'pavza', label: 'Odmor med vajami', sec: Math.max(90, rest), note: 'Pij, zadihaj, pripravi naslednjo vajo.' })
  }
  steps.pop()
  // (v3.51) opomba s slike (»AMRAP 10 min na koncu …«) je del treninga: zadnji korak pred raztezanjem, s časovnikom,
  // ko pove minute (prej samo v opisu dneva — vodena vadba je ni imela)
  const fin = finisherOf(desc)
  if (fin) steps.push({ kind: 'pavza', label: 'Odmor med vajami', sec: 90, note: 'Pij, zadihaj — pride še zadnji del s slike.' }, fin)
  steps.push(...tailSteps(day, p))
  steps.push({ kind: 'iztek', label: 'Raztezanje', sec: 4 * SEC, note: 'Noge, kolki, hrbet — vsak razteg 30 s.' })
  return steps
}
/** Kardio po moči v istem dnevu (dogovor »tek v istem dnevu«): koraki te seje (brez ogrevanja — telo je že ogreto) pred raztezanjem. */
function tailSteps(day: PlanDay, p: Profile): Step[] {
  const t = day.tail
  if (!t || !t.durationMin) return []
  // (v3.49) trd je po coni ali besedi — »Tek in hoja — 6 × 2 min teka« (Z2) je lahek, čeprav ima »×«
  const sub: PlanDay = { ...day, kind: t.kind, title: t.title.replace(/\s+—?\s*\d+\s*(?:min|h)\b.*$/u, '').replace(/\s+—\s*$/, ''), desc: t.desc, durationMin: t.durationMin, zone: t.zone ?? null, exercises: undefined, tail: null, role: /interval|tempo/i.test(t.title) || /Z[345]/.test(t.zone || '') || (/×/.test(t.title) && !t.zone) ? 'kljucna' : 'lahka' }
  const all = stepsFor(sub, p)
  const wu = all.filter(x => x.kind === 'ogrevanje').reduce((a, x) => a + x.sec, 0)
  const steps = all.filter(x => x.kind !== 'ogrevanje')
  if (!steps.length) return []
  // telo je po moči že ogreto: čas ogrevanja gre v enakomerni del (lahko / en sam blok), ne v interval; sicer v iztek
  const steady = steps.findIndex(x => (x.kind === 'lahko' && x.group == null) || (x.kind === 'delo' && x.group == null && !x.set))
  const into = steady >= 0 ? steady : steps.findIndex(x => x.kind === 'iztek')
  if (into >= 0 && wu > 0) steps[into] = { ...steps[into]!, sec: steps[into]!.sec + wu }
  return [{ kind: 'pavza', label: 'Po moči na kardio', sec: 2 * SEC, note: `Pij, preobuj se — sledi ${t.title.replace(/ — /, ': ').toLowerCase()}.` }, ...steps]
}

export function totalSec(steps: readonly Step[]): number { return steps.reduce((s, x) => s + x.sec, 0) }
/** »4:05« ali »1:04:05«; `long` = vedno z urami (»0:01:55«), da se ujema z »od 1:45:00« (v3.48). */
export function fmtClock(sec: number, long = false): string {
  const s = Math.max(0, Math.round(sec)), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60
  return h || long ? `${h}:${String(m).padStart(2, '0')}:${String(r).padStart(2, '0')}` : `${m}:${String(r).padStart(2, '0')}`
}
