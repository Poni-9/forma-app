import type { Activity, Sport } from '../types'
import { addDays, weekStartIso } from './load'

/**
 * REKORDI IN LETNI SEŠTEVKI po športu (privzeto kolo; v3.50 tudi tek in hoja — iz vseh vadb, ki jih imaš, samo za
 * prikaz tebi, ne gre v AI). Letos proti lani do istega dne v letu (pošteno tudi januarja).
 * (v3.50) Rekordi šele od 3 vadb tega športa; »nov« je rekord iz zadnjih 14 dni, ki je presegel prejšnjega (prej so
 * bili po prvi vožnji vsi štirje »nov«).
 */
export interface RideRecord { value: number; date: string; name: string; fresh: boolean }
export interface WeekRecord { weekStart: string; min: number; km: number; fresh: boolean }
export interface Records { distance: RideRecord | null; duration: RideRecord | null; climb: RideRecord | null; week: WeekRecord | null }

/** Najmanj vadb športa za rekorde. */
export const RECORDS_MIN = 3

export function records(acts: readonly Activity[], today: string, sport: Sport = 'kolo'): Records {
  const mine = acts.filter(a => a.sport === sport)
  if (mine.length < RECORDS_MIN) return { distance: null, duration: null, climb: null, week: null }
  const fromFresh = addDays(today, -13)
  const best = (val: (a: Activity) => number | null | undefined, min: number): RideRecord | null => {
    let b: Activity | null = null, bv = 0, before = 0
    for (const a of mine) {
      const v = val(a) || 0
      if (a.date < fromFresh) before = Math.max(before, v)
      if (v > bv || (v === bv && b && a.date < b.date)) { b = a; bv = v }
    }
    return b && bv >= min ? { value: bv, date: b.date, name: b.name, fresh: b.date >= fromFresh && before > 0 && bv > before } : null
  }
  const weeks = new Map<string, { min: number; km: number }>()
  for (const a of mine) {
    const k = weekStartIso(a.date), w = weeks.get(k) || { min: 0, km: 0 }
    w.min += a.durationMin || 0; w.km += a.distKm || 0
    weeks.set(k, w)
  }
  const freshWeek = weekStartIso(fromFresh)
  let week: WeekRecord | null = null, weekBefore = 0
  for (const [k, w] of weeks) {
    if (k < freshWeek) weekBefore = Math.max(weekBefore, w.min)
    if (!week || w.min > week.min) week = { weekStart: k, min: Math.round(w.min), km: Math.round(w.km), fresh: k >= freshWeek }
  }
  if (week) week.fresh = week.fresh && weekBefore > 0 && week.min > weekBefore
  return {
    distance: best(a => a.distKm, 1),
    duration: best(a => a.durationMin, 10),
    climb: best(a => a.elevM, 50),
    week: week && week.min >= 30 ? week : null,
  }
}

export interface YearSum { n: number; km: number; min: number; elev: number }
const empty = (): YearSum => ({ n: 0, km: 0, min: 0, elev: 0 })

/** Šport letos do danes in lani do istega dne (29. 2. → 28. 2.). */
export function yearTotals(acts: readonly Activity[], today: string, sport: Sport = 'kolo'): { year: number; now: YearSum; prev: YearSum } {
  const y = +today.slice(0, 4), md = today.slice(5)
  const prevEnd = `${y - 1}-${md === '02-29' ? '02-28' : md}`
  const now = empty(), prev = empty()
  for (const a of acts) {
    if (a.sport !== sport) continue
    const s = a.date >= `${y}-01-01` && a.date <= today ? now : a.date >= `${y - 1}-01-01` && a.date <= prevEnd ? prev : null
    if (!s) continue
    s.n++; s.km += a.distKm || 0; s.min += a.durationMin || 0; s.elev += a.elevM || 0
  }
  const r = (s: YearSum): YearSum => ({ n: s.n, km: Math.round(s.km), min: Math.round(s.min), elev: Math.round(s.elev) })
  return { year: y, now: r(now), prev: r(prev) }
}

/**
 * (v3.50) Glavni šport za »Letos in rekordi«: kolo, ko je v načrtu (kolesar ali kolo v dogovoru); sicer tek ali hoja —
 * kar je bilo v zadnjem letu pogosteje (prej je tekač ali pohodnik razdelek izgubil).
 */
export function recordSport(acts: readonly Activity[], today: string, bike: boolean): Sport {
  if (bike) return 'kolo'
  const from = addDays(today, -365)
  const n = (s: Sport) => acts.filter(a => a.sport === s && a.date >= from && a.date <= today).length
  return n('pohod') > n('tek') ? 'pohod' : 'tek'
}
