import type { Activity } from '../types'
import { addDays, weekStartIso } from './load'

/**
 * REKORDI IN LETNI SEŠTEVKI na kolesu (iz vseh vadb, ki jih imaš — samo za prikaz tebi, ne gre v AI).
 * Rekord je »nov«, če je iz zadnjih 14 dni. Letos proti lani do istega dne v letu (pošteno tudi januarja).
 */
export interface RideRecord { value: number; date: string; name: string; fresh: boolean }
export interface WeekRecord { weekStart: string; min: number; km: number; fresh: boolean }
export interface Records { distance: RideRecord | null; duration: RideRecord | null; climb: RideRecord | null; week: WeekRecord | null }

const bike = (a: Activity) => a.sport === 'kolo'

export function records(acts: readonly Activity[], today: string): Records {
  const fromFresh = addDays(today, -13)
  const best = (val: (a: Activity) => number | null | undefined, min: number): RideRecord | null => {
    let b: Activity | null = null, bv = 0
    for (const a of acts) {
      if (!bike(a)) continue
      const v = val(a) || 0
      if (v > bv || (v === bv && b && a.date < b.date)) { b = a; bv = v }
    }
    return b && bv >= min ? { value: bv, date: b.date, name: b.name, fresh: b.date >= fromFresh } : null
  }
  const weeks = new Map<string, { min: number; km: number }>()
  for (const a of acts) {
    if (!bike(a)) continue
    const k = weekStartIso(a.date), w = weeks.get(k) || { min: 0, km: 0 }
    w.min += a.durationMin || 0; w.km += a.distKm || 0
    weeks.set(k, w)
  }
  let week: WeekRecord | null = null
  for (const [k, w] of weeks) if (!week || w.min > week.min) week = { weekStart: k, min: Math.round(w.min), km: Math.round(w.km), fresh: k >= weekStartIso(fromFresh) }
  return {
    distance: best(a => a.distKm, 1),
    duration: best(a => a.durationMin, 10),
    climb: best(a => a.elevM, 50),
    week: week && week.min >= 30 ? week : null,
  }
}

export interface YearSum { n: number; km: number; min: number; elev: number }
const empty = (): YearSum => ({ n: 0, km: 0, min: 0, elev: 0 })

/** Na kolesu letos do danes in lani do istega dne (29. 2. → 28. 2.). */
export function yearTotals(acts: readonly Activity[], today: string): { year: number; now: YearSum; prev: YearSum } {
  const y = +today.slice(0, 4), md = today.slice(5)
  const prevEnd = `${y - 1}-${md === '02-29' ? '02-28' : md}`
  const now = empty(), prev = empty()
  for (const a of acts) {
    if (!bike(a)) continue
    const s = a.date >= `${y}-01-01` && a.date <= today ? now : a.date >= `${y - 1}-01-01` && a.date <= prevEnd ? prev : null
    if (!s) continue
    s.n++; s.km += a.distKm || 0; s.min += a.durationMin || 0; s.elev += a.elevM || 0
  }
  const r = (s: YearSum): YearSum => ({ n: s.n, km: Math.round(s.km), min: Math.round(s.min), elev: Math.round(s.elev) })
  return { year: y, now: r(now), prev: r(prev) }
}
