import type { Activity, PlanDay, Sport } from '../types'

/**
 * AKTIVNOST ↔ DAN V NAČRTU. Čiste funkcije, ki jih uporabljata dnevni cilj kalorij (energy.ts) in samodejno
 * odkljukanje načrta (store, linkToPlan) — da oba odločata enako.
 * Aktivnost je »načrtovana seja« samo, če je iste vrste in traja vsaj pol načrtovanega:
 * 20-minutna vožnja v službo ni 4-urna dolga vožnja, ki še pride.
 */

/** Tipična hitrost (km/h), ko trajanje manjka in poznamo le razdaljo. */
const SPEED: Record<Sport, number> = { kolo: 25, tek: 10, pohod: 4.5, plavanje: 2.5, moc: 0, drugo: 12 }
const pos = (x: unknown): number | null => (typeof x === 'number' && Number.isFinite(x) && x > 0 ? x : null)

/** Kolikšen del načrtovanega trajanja mora imeti aktivnost, da šteje kot ta seja. */
export const MATCH_SHARE = 0.5

/**
 * Trajanje aktivnosti (min): čas gibanja, sicer čas s postanki, sicer iz razdalje pri izmerjeni ali tipični hitrosti
 * (kolo 25 km/h, tek 10, hoja 4,5). null = ne vemo.
 */
export function activityMinutes(a: Pick<Activity, 'sport' | 'durationMin'> & Partial<Pick<Activity, 'elapsedMin' | 'distKm' | 'speedKmh'>>): number | null {
  const d = pos(a.durationMin) ?? pos(a.elapsedMin)
  if (d) return d
  const km = pos(a.distKm), v = pos(a.speedKmh) ?? pos(SPEED[a.sport])
  return km && v ? Math.round((km / v) * 60) : null
}

/** Ista vrsta: kolo ↔ kolo ali test, moč ↔ moč, tek ↔ tek … */
export function sameKind(a: Pick<Activity, 'sport'>, d: Pick<PlanDay, 'kind'>): boolean {
  return a.sport === 'moc' ? d.kind === 'moc' : a.sport === 'kolo' ? d.kind === 'kolo' || d.kind === 'test' : d.kind === a.sport
}

/**
 * Ali je aktivnost ta seja iz načrta: ista vrsta in vsaj 50 % načrtovanega trajanja.
 * Aktivnost brez trajanja (in brez razdalje) šteje — ne vemo drugače, dvojno štetje bi bilo slabše.
 */
export function matchesPlanned(a: Pick<Activity, 'sport' | 'durationMin'> & Partial<Pick<Activity, 'elapsedMin' | 'distKm' | 'speedKmh'>>, d: Pick<PlanDay, 'kind' | 'durationMin'>): boolean {
  if (d.kind === 'pocitek' || !sameKind(a, d)) return false
  const m = activityMinutes(a), plan = pos(d.durationMin)
  if (m == null || plan == null) return true
  return m >= MATCH_SHARE * plan
}

/**
 * Med kandidati (dnevi istega datuma, še neopravljeni) izbere tistega, ki mu aktivnost ustreza:
 * obvezni pred neobveznimi, nato najbližje trajanje. null, če ni nobenega (aktivnost je dodatna).
 */
export function bestPlanMatch<T extends Pick<PlanDay, 'kind' | 'durationMin' | 'date'> & { optional?: boolean }>(a: Pick<Activity, 'sport' | 'durationMin' | 'date'> & Partial<Pick<Activity, 'elapsedMin' | 'distKm' | 'speedKmh'>>, days: readonly T[]): T | null {
  const m = activityMinutes(a)
  const ok = days.filter(d => (!a.date || !d.date || d.date === a.date) && matchesPlanned(a, d))
  if (!ok.length) return null
  const gap = (d: T) => (m == null ? 0 : Math.abs(m - (d.durationMin || 0)))
  return [...ok].sort((x, y) => (x.optional ? 1 : 0) - (y.optional ? 1 : 0) || gap(x) - gap(y))[0] ?? null
}

/**
 * Trd dan za razpored: ključni trening, test, tekma, dolga vožnja (tudi krajša — v tednu je vedno eden od
 * stebrov) ali brez vloge v conah Z4/Z5. Ob trdem dnevu ne sme stati drug trd dan (dva zapored sta največ).
 */
export function isHardDay(d: Pick<PlanDay, 'kind' | 'zone' | 'durationMin'> & { role?: PlanDay['role'] }): boolean {
  if (d.kind === 'test' || d.role === 'kljucna' || d.role === 'test' || d.role === 'dirka' || d.role === 'dolga') return true
  if (d.role) return false
  return (d.kind === 'kolo' || d.kind === 'tek') && /Z[45]|test|dirka/.test(d.zone || '')
}
