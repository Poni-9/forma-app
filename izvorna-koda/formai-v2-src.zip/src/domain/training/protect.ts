import type { PlanDay, Profile } from '../types'
import { addDays } from './load'
import { plannedRaceMinutes } from './season'

/**
 * ZAŠČITA TEKEM PRI PREMIKIH. Samodejni premiki (počutje, zamujen ključni, pretežka vožnja, lažji dan) in ročni
 * »Premakni« ne smejo postaviti treninga na dan tekme, na dan pred njo (predaktivacija) ali na dan polnjenja z OH
 * pred dolgo tekmo — tudi kadar je tekma že v naslednjem tednu in je v tem tednu ni v načrtu (npr. tekma v ponedeljek).
 */

type RaceProfile = Pick<Profile, 'event' | 'races'> | null | undefined

/** enako kot CARB_LOAD_MIN v nutrition/energy.ts (uvoz bi naredil krog planner → state → energy → planner) */
export const LOAD_RACE_MIN = 150

/** Datumi tekem: iz načrta (dirka, povezana tekma) in iz profila (cilj sezone in druge tekme). */
export function raceDates(plan: readonly PlanDay[], p?: RaceProfile): Set<string> {
  const s = new Set<string>()
  for (const d of plan) if (d.role === 'dirka' || d.raceId) s.add(d.date)
  if (p?.event?.date) s.add(p.event.date)
  for (const r of p?.races || []) if (r?.date) s.add(r.date)
  return s
}

/** Dnevi polnjenja z OH: 2 dni pred tekmo, dolgo vsaj 150 min (dan prej je že zaklenjen kot dan pred tekmo). */
function loadDates(p: RaceProfile): Set<string> {
  const s = new Set<string>()
  if (!p) return s
  const all = [...(p.event?.date ? [{ ...p.event, id: null as string | null }] : []), ...(p.races || []).filter(r => r?.date && r.date !== p.event?.date)]
  for (const r of all) {
    let min = 0
    try { min = plannedRaceMinutes(p, r) } catch { min = 0 }
    if (min >= LOAD_RACE_MIN) s.add(addDays(r.date, -2))
  }
  return s
}

export interface RaceLock {
  /** dan tekme, dan pred njo, polnjenje z OH */ has(date: string): boolean
  why(date: string): string | null
  /** dan po tekmi — tja ne gre trd trening */ afterRace(date: string): boolean
}

/** Zaklenjeni dnevi: tekma, dan pred tekmo, polnjenje z OH pred dolgo tekmo. */
export function raceLock(plan: readonly PlanDay[], p?: RaceProfile): RaceLock {
  const races = raceDates(plan, p), load = loadDates(p)
  const why = (date: string): string | null =>
    races.has(date) ? 'dan tekme' : races.has(addDays(date, 1)) ? 'dan pred tekmo' : load.has(date) ? 'polnjenje z OH pred tekmo' : null
  return { has: date => why(date) !== null, why, afterRace: date => races.has(addDays(date, -1)) }
}
