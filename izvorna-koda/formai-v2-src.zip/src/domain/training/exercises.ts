import type { Activity, FocusAim, FocusEquip, Muscle, SessionPart } from '../types'

/**
 * KNJIŽNICA VAJ ZA MOČ (fitnes, ročke, elastike, drog, lastna teža) — za načrt po meri (dogovor s trenerjem).
 * Vsaka vaja ima mišice (prva je glavna), opremo, raven, gibalni vzorec (za izbiro in zamenjavo) in kratko tehniko.
 * Seje so sestavljene iz vzorcev (npr. zgornji del: vodoravni potisk, vodoravni poteg, navpični potisk …), vaja se izbere
 * po opremi, ravni in omejitvah; osnovne vaje ostanejo iste (napredek s kilogrami), dodatne se vrtijo po tednih.
 */
export type Pattern = 'pocep' | 'kolk' | 'enonozno' | 'potiskV' | 'potiskN' | 'potegV' | 'potegN' | 'trebuh' | 'biceps' | 'triceps' | 'ramena' | 'zadnjica' | 'meca' | 'kondicija'
export type Limit = 'koleno' | 'hrbet' | 'rama'
export interface ExDef {
  id: string
  name: string
  /** mišice — prva je glavna */
  m: Muscle[]
  /** oprema, ki jo vaja rabi ('nic' = samo lastna teža) */
  eq: FocusEquip
  lvl: 1 | 2 | 3
  pat: Pattern
  /** vaja na čas (sekunde) */
  time?: boolean
  /** osnovna večsklepna vaja: težje serije, daljša pavza, napredek s kilogrami */
  big?: boolean
  /** z ročko/utežjo, ki jo vpišeš (kg) */
  kg?: boolean
  how: string
  /** izpusti pri teh omejitvah */
  avoid?: Limit[]
}

export const EXERCISES: readonly ExDef[] = [
  /* ---- lastna teža ---- */
  { id: 'sklece', name: 'Sklece', m: ['prsa', 'roke', 'ramena'], eq: 'nic', lvl: 2, pat: 'potiskV', big: true, how: 'Dlani malo širše od ramen, telo v ravni črti od glave do pet. Prsi do tal, komolci približno 45° od telesa.', avoid: ['rama'] },
  { id: 'sklece-kolena', name: 'Sklece na kolenih', m: ['prsa', 'roke', 'ramena'], eq: 'nic', lvl: 1, pat: 'potiskV', big: true, how: 'Kolena na tleh, telo od kolen do glave ravno. Ko narediš 15 lepih, preidi na prave sklece.' },
  { id: 'sklece-noge', name: 'Sklece z nogami na stolu', m: ['prsa', 'ramena', 'roke'], eq: 'nic', lvl: 3, pat: 'potiskV', big: true, how: 'Stopala na stolu, telo ravno, prsi proti tlom med dlanmi — težje za zgornji del prsi in ramena.', avoid: ['rama'] },
  { id: 'pike', name: 'Pike sklece', m: ['ramena', 'roke'], eq: 'nic', lvl: 2, pat: 'potiskN', how: 'Boki visoko (telo v obliki črke V), glava gre proti tlom med dlanmi, nato potisni nazaj.', avoid: ['rama'] },
  { id: 'pocep', name: 'Počep', m: ['noge', 'zadnjica'], eq: 'nic', lvl: 1, pat: 'pocep', big: true, how: 'Stopala v širini ramen, boki nazaj in dol, kolena v smeri prstov, pete na tleh. Do vzporedno ali kolikor gre brez bolečine.' },
  { id: 'izpadni', name: 'Izpadni koraki', m: ['noge', 'zadnjica'], eq: 'nic', lvl: 1, pat: 'enonozno', how: 'Velik korak naprej, zadnje koleno skoraj do tal, trup pokončen. Izmenično.', avoid: ['koleno'] },
  { id: 'bolgarski', name: 'Bolgarski počep', m: ['noge', 'zadnjica'], eq: 'nic', lvl: 2, pat: 'enonozno', how: 'Zadnja noga na stolu, sprednje koleno nad prsti, spusti se navpično do 90°, poriv skozi peto.', avoid: ['koleno'] },
  { id: 'most', name: 'Dvig bokov leže', m: ['zadnjica', 'noge'], eq: 'nic', lvl: 1, pat: 'zadnjica', how: 'Leže na hrbtu, stopala blizu zadnjice. Stisni zadnjico in dvigni boke do ravne črte, zgoraj zadrži 1 s.' },
  { id: 'most1', name: 'Dvig bokov na eni nogi', m: ['zadnjica', 'noge'], eq: 'nic', lvl: 2, pat: 'zadnjica', how: 'Kot dvig bokov, a z eno nogo v zraku — boki ostanejo vodoravni.' },
  { id: 'deska', name: 'Deska', m: ['trebuh'], eq: 'nic', lvl: 1, pat: 'trebuh', time: true, how: 'Komolci pod rameni, telo v ravni črti, stisni zadnjico in trebuh, ne povesi bokov.' },
  { id: 'stranska', name: 'Stranska deska', m: ['trebuh'], eq: 'nic', lvl: 1, pat: 'trebuh', time: true, how: 'Komolec pod ramo, boki visoko, telo v ravni črti — vsaka stran posebej.' },
  { id: 'deadbug', name: 'Dead bug', m: ['trebuh'], eq: 'nic', lvl: 1, pat: 'trebuh', how: 'Križ v tleh; nasprotno roko in nogo počasi iztegni, izdihni, zamenjaj.' },
  { id: 'dvig-nog', name: 'Dvig nog leže', m: ['trebuh'], eq: 'nic', lvl: 1, pat: 'trebuh', how: 'Križ pritisnjen v tla, noge počasi dol do 10 cm nad tlemi in nazaj.', avoid: ['hrbet'] },
  { id: 'kolesarcki', name: 'Kolesarski trebušnjaki', m: ['trebuh'], eq: 'nic', lvl: 1, pat: 'trebuh', how: 'Leže, dlani ob glavi, komolec proti nasprotnemu kolenu, druga noga iztegnjena. Počasi, ne vleci vratu.' },
  { id: 'plezalec', name: 'Plezalec', m: ['trebuh', 'ramena'], eq: 'nic', lvl: 1, pat: 'trebuh', time: true, how: 'Položaj za sklece, kolena izmenično hitro proti prsim, boki ostanejo nizko.' },
  { id: 'coln', name: 'Drža čolnička', m: ['trebuh'], eq: 'nic', lvl: 2, pat: 'trebuh', time: true, how: 'Leže na hrbtu, križ pritisnjen v tla, ramena in iztegnjene noge malo od tal. Drži.', avoid: ['hrbet'] },
  { id: 'superman', name: 'Superman', m: ['hrbet', 'zadnjica'], eq: 'nic', lvl: 1, pat: 'kolk', how: 'Leže na trebuhu, hkrati dvigni roke in noge za nekaj cm, zgoraj 2 s, počasi dol.' },
  { id: 'dipi', name: 'Dipi na stolu', m: ['roke', 'prsa'], eq: 'nic', lvl: 1, pat: 'triceps', how: 'Dlani na robu stola, komolci gredo nazaj (ne narazen), spusti se do 90° v komolcih.', avoid: ['rama'] },
  { id: 'prsti', name: 'Dvigi na prste', m: ['noge'], eq: 'nic', lvl: 1, pat: 'meca', how: 'Na robu stopnice: počasi gor na prste in počasi dol pod rob.' },
  { id: 'burpee', name: 'Burpee', m: ['noge', 'prsa', 'trebuh'], eq: 'nic', lvl: 2, pat: 'kondicija', how: 'Počep, dlani na tla, skok nazaj v desko, noge nazaj pod telo, skok gor. Enakomerno, ne na vso moč.', avoid: ['koleno'] },
  { id: 'krozni', name: 'Poskoki s kolebnico ali brez', m: ['noge'], eq: 'nic', lvl: 1, pat: 'kondicija', time: true, how: 'Lahki poskoki na prstih, kolena mehka. Brez kolebnice samo posnemaj vrtenje.', avoid: ['koleno'] },
  /* ---- drog za zgibe ---- */
  { id: 'zgibi', name: 'Zgibi', m: ['hrbet', 'roke'], eq: 'drog', lvl: 3, pat: 'potegN', big: true, how: 'Dlani malo širše od ramen, iz polnega visa brada nad drog, brez zamaha. Počasi dol.' },
  { id: 'negativni', name: 'Negativni zgibi', m: ['hrbet', 'roke'], eq: 'drog', lvl: 1, pat: 'potegN', big: true, how: 'Skoči ali stopi do brade nad drogom, nato se 3–5 s počasi spuščaj do polnega visa.' },
  { id: 'kolena-vis', name: 'Dvig kolen v visenju', m: ['trebuh'], eq: 'drog', lvl: 2, pat: 'trebuh', how: 'V visu dvigni kolena do prsi brez zamaha, počasi dol.' },
  /* ---- ročke (doma ali v fitnesu) ---- */
  { id: 'goblet', name: 'Goblet počep', m: ['noge', 'zadnjica'], eq: 'utezi', lvl: 1, pat: 'pocep', big: true, kg: true, how: 'Ročko drži pred prsmi, komolci gredo na dnu med kolena; prsi gor, pete na tleh.' },
  { id: 'rdl-r', name: 'Romunski mrtvi dvig z ročkami', m: ['zadnjica', 'noge', 'hrbet'], eq: 'utezi', lvl: 1, pat: 'kolk', big: true, kg: true, how: 'Kolena rahlo pokrčena, boki nazaj, hrbet raven, ročke drsijo ob nogah do sredine golenic.', avoid: ['hrbet'] },
  { id: 'potisk-r', name: 'Potisk z ročkami', m: ['prsa', 'roke', 'ramena'], eq: 'utezi', lvl: 1, pat: 'potiskV', big: true, kg: true, how: 'Na klopi ali tleh: ročke nad prsmi, spusti do komolcev pod 45° od telesa, potisni gor.' },
  { id: 'veslanje-r', name: 'Enoročno veslanje z ročko', m: ['hrbet', 'roke'], eq: 'utezi', lvl: 1, pat: 'potegV', big: true, kg: true, how: 'Roka in koleno na klopi, hrbet raven, potegni ročko k boku, komolec ob telesu.' },
  { id: 'nadglavo-r', name: 'Potisk nad glavo z ročkami', m: ['ramena', 'roke'], eq: 'utezi', lvl: 1, pat: 'potiskN', kg: true, how: 'Stoje ali sede, trebuh napet: ročke od ramen nad glavo, brez usločenja v križu.', avoid: ['rama'] },
  { id: 'odrocenje', name: 'Odročenje z ročkami', m: ['ramena'], eq: 'utezi', lvl: 1, pat: 'ramena', kg: true, how: 'Komolci rahlo pokrčeni, ročke v stran do višine ramen, počasi dol. Lahka teža, brez zamaha.' },
  { id: 'biceps-r', name: 'Upogib za biceps z ročkami', m: ['roke'], eq: 'utezi', lvl: 1, pat: 'biceps', kg: true, how: 'Komolci ob telesu, ročke gor brez zamaha, počasi dol.' },
  { id: 'triceps-r', name: 'Iztegi za triceps nad glavo', m: ['roke'], eq: 'utezi', lvl: 1, pat: 'triceps', kg: true, how: 'Ročka za glavo, komolci kažejo naprej-gor, iztegni roke nad glavo.', avoid: ['rama'] },
  { id: 'izpadni-r', name: 'Izpadni koraki z ročkami', m: ['noge', 'zadnjica'], eq: 'utezi', lvl: 2, pat: 'enonozno', kg: true, how: 'Ročke ob telesu, velik korak naprej, zadnje koleno skoraj do tal, trup pokončen.', avoid: ['koleno'] },
  { id: 'stopanje-r', name: 'Stopanje na klop z ročkami', m: ['noge', 'zadnjica'], eq: 'utezi', lvl: 1, pat: 'enonozno', kg: true, how: 'Cela stopala na klopi, poriv skozi peto zgornje noge, spodnja samo spremlja. Počasi dol.' },
  { id: 'hip-r', name: 'Hip thrust z ročko', m: ['zadnjica', 'noge'], eq: 'utezi', lvl: 1, pat: 'zadnjica', kg: true, how: 'Lopatice na klopi ali kavču, ročka na bokih, dvigni boke do ravne črte in stisni zadnjico.' },
  { id: 'zasuki-r', name: 'Ruski zasuki z ročko', m: ['trebuh'], eq: 'utezi', lvl: 2, pat: 'trebuh', kg: true, how: 'Sede, trup rahlo nazaj, ročko vodi z ene strani na drugo, gib iz trupa.', avoid: ['hrbet'] },
  { id: 'zamah', name: 'Zamah z utežjo', m: ['zadnjica', 'noge', 'hrbet'], eq: 'utezi', lvl: 2, pat: 'kondicija', kg: true, how: 'Boki nazaj in nato močno naprej — moč pride iz bokov, ne iz rok. Hrbet raven.', avoid: ['hrbet'] },
  /* ---- elastike ---- */
  { id: 'veslanje-e', name: 'Veslanje z elastiko', m: ['hrbet', 'roke'], eq: 'elastike', lvl: 1, pat: 'potegV', big: true, how: 'Elastika zataknjena v višini prsi, potegni komolce nazaj, stisni lopatice skupaj.' },
  { id: 'razteg-e', name: 'Razteg elastike pred prsmi', m: ['ramena', 'hrbet'], eq: 'elastike', lvl: 1, pat: 'ramena', how: 'Iztegnjene roke pred prsmi, raztegni elastiko do prsi, lopatice skupaj, počasi nazaj.' },
  { id: 'biceps-e', name: 'Upogib za biceps z elastiko', m: ['roke'], eq: 'elastike', lvl: 1, pat: 'biceps', how: 'Stopi na elastiko, komolci ob telesu, dlani gor do ramen, počasi dol.' },
  { id: 'pallof', name: 'Pallof press', m: ['trebuh'], eq: 'elastike', lvl: 1, pat: 'trebuh', how: 'Elastika ob strani v višini prsi: potisni roke naravnost naprej in ne pusti, da te zasuka.' },
  { id: 'koraki-e', name: 'Stranski koraki z elastiko', m: ['zadnjica'], eq: 'elastike', lvl: 1, pat: 'zadnjica', how: 'Elastika nad koleni, rahel počep, majhni koraki vstran, kolena navzven.' },
  /* ---- fitnes (naprave, palica, kabli) ---- */
  { id: 'pocep-p', name: 'Počep s palico', m: ['noge', 'zadnjica'], eq: 'fitnes', lvl: 2, pat: 'pocep', big: true, kg: true, how: 'Palica na zgornjem delu hrbta, stopala v širini ramen, boki nazaj in dol do vzporedno, hrbet raven.', avoid: ['koleno', 'hrbet'] },
  { id: 'presa', name: 'Nožna preša', m: ['noge', 'zadnjica'], eq: 'fitnes', lvl: 1, pat: 'pocep', big: true, kg: true, how: 'Stopala v širini ramen, spusti do 90° v kolenih, kolen na vrhu ne zakleni.' },
  { id: 'mrtvi', name: 'Mrtvi dvig', m: ['hrbet', 'zadnjica', 'noge'], eq: 'fitnes', lvl: 3, pat: 'kolk', big: true, kg: true, how: 'Palica nad sredino stopal, hrbet raven, potisni tla stran in iztegni boke in kolena hkrati. Tehnika pred kilogrami.', avoid: ['hrbet'] },
  { id: 'rdl-p', name: 'Romunski mrtvi dvig s palico', m: ['zadnjica', 'noge', 'hrbet'], eq: 'fitnes', lvl: 2, pat: 'kolk', big: true, kg: true, how: 'Kolena rahlo pokrčena, boki nazaj, palica drsi ob nogah do sredine golenic, hrbet raven.', avoid: ['hrbet'] },
  { id: 'bench', name: 'Potisk s palico na ravni klopi', m: ['prsa', 'roke', 'ramena'], eq: 'fitnes', lvl: 2, pat: 'potiskV', big: true, kg: true, how: 'Lopatice skupaj in dol, palica do spodnjega dela prsi, komolci ~45°. Pri težkih serijah z varovanjem.', avoid: ['rama'] },
  { id: 'incline-r', name: 'Potisk z ročkami na poševni klopi', m: ['prsa', 'ramena', 'roke'], eq: 'fitnes', lvl: 1, pat: 'potiskV', big: true, kg: true, how: 'Klop na 30°, ročke nad zgornjim delom prsi, spusti s kontrolo, potisni gor in malo skupaj.' },
  { id: 'metuljcek', name: 'Metuljček na napravi', m: ['prsa'], eq: 'fitnes', lvl: 1, pat: 'potiskV', kg: true, how: 'Komolci rahlo pokrčeni, roke skupaj pred prsmi, zgoraj stisni prsi, počasi nazaj.' },
  { id: 'pulldown', name: 'Poteg na prsi', m: ['hrbet', 'roke'], eq: 'fitnes', lvl: 1, pat: 'potegN', big: true, kg: true, how: 'Širok prijem, drog potegni do zgornjega dela prsi, komolci navzdol, brez zibanja.' },
  { id: 'kabel-v', name: 'Veslanje na kablu sede', m: ['hrbet', 'roke'], eq: 'fitnes', lvl: 1, pat: 'potegV', big: true, kg: true, how: 'Prsi gor, ročaj potegni k trebuhu, lopatice skupaj, počasi nazaj.' },
  { id: 'veslanje-p', name: 'Veslanje s palico v predklonu', m: ['hrbet', 'roke'], eq: 'fitnes', lvl: 2, pat: 'potegV', big: true, kg: true, how: 'Predklon z ravnim hrbtom, palico potegni k spodnjemu delu prsi, komolci ob telesu.', avoid: ['hrbet'] },
  { id: 'ohp', name: 'Potisk s palico nad glavo', m: ['ramena', 'roke'], eq: 'fitnes', lvl: 2, pat: 'potiskN', big: true, kg: true, how: 'Stoje, trebuh in zadnjica napeta, palica od ključnic nad glavo, glava gre skozi »okno«.', avoid: ['rama', 'hrbet'] },
  { id: 'facepull', name: 'Face pull na kablu', m: ['ramena', 'hrbet'], eq: 'fitnes', lvl: 1, pat: 'ramena', kg: true, how: 'Vrv v višini oči, potegni k obrazu, komolci visoko in navzven.' },
  { id: 'triceps-k', name: 'Iztegi za triceps na kablu', m: ['roke'], eq: 'fitnes', lvl: 1, pat: 'triceps', kg: true, how: 'Komolci ob telesu, iztegni roke navzdol, počasi nazaj.' },
  { id: 'biceps-p', name: 'Upogib za biceps s palico', m: ['roke'], eq: 'fitnes', lvl: 1, pat: 'biceps', kg: true, how: 'Komolci ob telesu, palica gor brez zamaha, počasi dol.' },
  { id: 'leg-curl', name: 'Upogib kolen na napravi', m: ['noge'], eq: 'fitnes', lvl: 1, pat: 'kolk', kg: true, how: 'Počasi gor in dol, boki ostanejo na blazini.' },
  { id: 'leg-ext', name: 'Izteg kolen na napravi', m: ['noge'], eq: 'fitnes', lvl: 1, pat: 'pocep', kg: true, how: 'Iztegni kolena do skoraj ravno, zgoraj 1 s, počasi dol.', avoid: ['koleno'] },
  { id: 'hip-p', name: 'Hip thrust s palico', m: ['zadnjica', 'noge'], eq: 'fitnes', lvl: 2, pat: 'zadnjica', big: true, kg: true, how: 'Lopatice na klopi, palica z blazino na bokih, dvigni boke do ravne črte, brada k prsim.' },
  { id: 'prsti-n', name: 'Dvigi na prste na napravi', m: ['noge'], eq: 'fitnes', lvl: 1, pat: 'meca', kg: true, how: 'Polna amplituda: čisto dol in čisto gor, zgoraj 1 s.' },
  { id: 'kabel-zasuk', name: 'Zasuki na kablu', m: ['trebuh'], eq: 'fitnes', lvl: 1, pat: 'trebuh', kg: true, how: 'Kabel v višini prsi, roke iztegnjene, vrtenje iz trupa, boki mirni.' },
  { id: 'bradlja', name: 'Dvig kolen na bradlji', m: ['trebuh'], eq: 'fitnes', lvl: 2, pat: 'trebuh', how: 'Podlakti na blazinah, hrbet ob naslonu, kolena do prsi brez zamaha.' },
  { id: 'valjcek', name: 'Valjček za trebuh', m: ['trebuh'], eq: 'fitnes', lvl: 3, pat: 'trebuh', how: 'Na kolenih, počasi naprej, kolikor zdržiš z ravnim hrbtom, nazaj s trebuhom.', avoid: ['hrbet'] },
  { id: 'hiper', name: 'Hiperekstenzija', m: ['hrbet', 'zadnjica'], eq: 'fitnes', lvl: 1, pat: 'kolk', how: 'Na napravi spusti trup in ga dvigni do ravne črte — ne usloči se nazaj.' },
  { id: 'veslo', name: 'Veslanje na ergometru', m: ['hrbet', 'noge'], eq: 'fitnes', lvl: 1, pat: 'kondicija', time: true, how: 'Noge, trup, roke — in nazaj v obratnem vrstnem redu. Enakomerno, dihaj.' },
]

export const MUSCLE_LABEL: Record<Muscle, string> = { trebuh: 'trebuh', prsa: 'prsa', hrbet: 'hrbet', ramena: 'ramena', roke: 'roke', noge: 'noge', zadnjica: 'zadnjica' }
export const PART_LABEL: Record<SessionPart, string> = { celo: 'celo telo', zgornji: 'zgornji del', spodnji: 'spodnji del', potisk: 'prsa, ramena, triceps', poteg: 'hrbet in biceps', noge: 'noge in zadnjica', trebuh: 'trebuh', roke: 'roke in ramena' }
/** mišice, ki jih del telesa pokrije (za prednostne mišice in zemljevid) */
export const PART_MUSCLES: Record<SessionPart, Muscle[]> = {
  celo: ['noge', 'prsa', 'hrbet', 'zadnjica', 'trebuh', 'ramena', 'roke'], zgornji: ['prsa', 'hrbet', 'ramena', 'roke'], spodnji: ['noge', 'zadnjica', 'trebuh'],
  potisk: ['prsa', 'ramena', 'roke'], poteg: ['hrbet', 'roke', 'ramena'], noge: ['noge', 'zadnjica'], trebuh: ['trebuh'], roke: ['roke', 'ramena'],
}
/** vzorci po delih telesa — vrstni red je vrstni red vaj v seji */
const SLOTS: Record<SessionPart, Pattern[]> = {
  celo: ['pocep', 'potiskV', 'potegV', 'kolk', 'potegN', 'trebuh'],
  zgornji: ['potiskV', 'potegV', 'potiskN', 'potegN', 'biceps', 'triceps', 'ramena'],
  spodnji: ['pocep', 'kolk', 'enonozno', 'zadnjica', 'trebuh', 'meca'],
  noge: ['pocep', 'kolk', 'enonozno', 'zadnjica', 'meca', 'trebuh'],
  potisk: ['potiskV', 'potiskN', 'potiskV', 'ramena', 'triceps', 'trebuh'],
  poteg: ['potegN', 'potegV', 'ramena', 'biceps', 'potegV', 'trebuh'],
  trebuh: ['trebuh', 'trebuh', 'trebuh', 'trebuh', 'kondicija'],
  roke: ['biceps', 'triceps', 'ramena', 'biceps', 'triceps', 'trebuh'],
}
/** prednostna mišica → vzorec, ki jo dodatno trenira */
const EXTRA: Record<Muscle, Pattern[]> = { trebuh: ['trebuh'], prsa: ['potiskV'], hrbet: ['potegV', 'potegN'], ramena: ['ramena', 'potiskN'], roke: ['biceps', 'triceps'], noge: ['enonozno', 'pocep'], zadnjica: ['zadnjica'] }

/** Različice iste vaje (sklece na kolenih, počep z ročko …): v eni seji samo ena iz družine. */
const FAMILY: Record<string, string> = {
  'sklece-kolena': 'sklece', 'sklece-noge': 'sklece', most1: 'most', 'hip-r': 'most', 'hip-p': 'most', goblet: 'pocep', 'pocep-p': 'pocep',
  'rdl-p': 'rdl-r', mrtvi: 'rdl-r', 'veslanje-e': 'veslanje-r', 'veslanje-p': 'veslanje-r', negativni: 'zgibi',
  'biceps-e': 'biceps-r', 'biceps-p': 'biceps-r', 'triceps-k': 'triceps-r', 'izpadni-r': 'izpadni',
}
export const familyOf = (id: string): string => FAMILY[id] ?? id
export const exByName = (name: string): ExDef | undefined => EXERCISES.find(e => e.name.toLowerCase() === name.toLowerCase())
export const exById = (id: string): ExDef | undefined => EXERCISES.find(e => e.id === id)

/** Omejitve iz besedila (»koleno me boli«, »križ«, »rama«). */
export function limitsOf(text: string | null | undefined): Limit[] {
  const t = (text || '').toLowerCase()
  const out: Limit[] = []
  if (/kolen|koleno|menisk|vez/.test(t)) out.push('koleno')
  if (/hrbet|hrbt|križ|kriz|ledv|disk/.test(t)) out.push('hrbet')
  if (/\bram[aeiou]\b|ramen|ramn|rotator/.test(t)) out.push('rama')
  return out
}

/** Kaj je na voljo: v fitnesu vse naprave, ročke, drog in elastike; doma samo, kar imaš (vedno lastna teža). */
export function equipFor(where: 'fitnes' | 'doma', own: readonly FocusEquip[]): FocusEquip[] {
  return where === 'fitnes' ? ['fitnes', 'utezi', 'drog', 'elastike', 'nic'] : [...new Set<FocusEquip>([...own.filter(e => e !== 'fitnes'), 'nic'])]
}
/** prednost opreme: v fitnesu naprave in palice, doma ročke, potem elastike, drog in lastna teža */
const EQ_RANK: Record<'fitnes' | 'doma', Record<FocusEquip, number>> = {
  fitnes: { fitnes: 0, utezi: 1, drog: 2, elastike: 4, nic: 3 },
  doma: { utezi: 0, drog: 1, elastike: 2, nic: 3, fitnes: 9 },
}

/** Kandidati za vzorec: oprema, raven (najvišja svoja), omejitve; razvrščeni po opremi in najbližji ravni. */
export function candidates(pat: Pattern, o: { where: 'fitnes' | 'doma'; equip: readonly FocusEquip[]; level: 1 | 2 | 3; limits: readonly Limit[] }): ExDef[] {
  const eq = new Set(o.equip)
  return EXERCISES
    .filter(e => e.pat === pat && eq.has(e.eq) && e.lvl <= o.level && !(e.avoid || []).some(l => o.limits.includes(l)))
    .sort((a, b) => EQ_RANK[o.where][a.eq] - EQ_RANK[o.where][b.eq] || (o.level - a.lvl) - (o.level - b.lvl) || EXERCISES.indexOf(a) - EXERCISES.indexOf(b))
}

export interface PlanExercise { name: string; sets: number; reps: string; kg?: number | null; rest?: number | null }

/** Serije, ponovitve in pavza po cilju in ravni. Lažji teden: serija manj. */
export function dose(e: ExDef, aims: readonly FocusAim[], level: 1 | 2 | 3, light = false): { sets: number; reps: string; rest: number } {
  let sets: number, reps: string, rest: number
  // z obremenitvijo (palica, naprava, ročke): težke serije; lastna teža: več ponovitev (4–6 sklec ni dražljaj)
  const loaded = !!e.kg || e.eq === 'fitnes'
  const cut = aims.includes('definicija') || aims.includes('hujsanje')
  if (e.time) {
    sets = level === 1 ? 2 : 3
    reps = e.pat === 'kondicija' ? (level === 1 ? '30 s' : '40 s') : level === 1 ? '20–30 s' : level === 2 ? '30–45 s' : '45–60 s'
    rest = 45
  } else if (e.pat === 'kondicija') { sets = 3; reps = level === 1 ? '8–10' : '10–15'; rest = 60 }
  else if (aims.includes('moc') && e.big && level >= 2 && loaded) { sets = level === 3 ? 5 : 4; reps = '4–6'; rest = 150 }
  // hujšanje z ohranjanjem mišic: osnovne vaje ostanejo težke (6–10), da telo mišic ne »odvrže«
  else if (cut && e.big && level >= 2 && loaded) { sets = level === 3 ? 4 : 3; reps = '6–10'; rest = 120 }
  else if (aims.includes('moc') && e.big && level >= 2) { sets = level === 3 ? 4 : 3; reps = e.eq === 'drog' ? '5–8' : '8–15'; rest = 90 }
  else if (aims.includes('misice')) { sets = e.big ? (level === 1 ? 3 : 4) : 3; reps = e.big ? '8–12' : '10–15'; rest = e.big ? 105 : 75 }
  else { sets = e.big ? 3 : level === 1 ? 2 : 3; reps = level === 1 ? '10–12' : '10–15'; rest = 60 }
  if (e.pat === 'trebuh' && !e.time) { reps = level === 1 ? '10–12' : '12–15'; rest = 45 }
  if (level === 1) sets = Math.min(sets, 3)
  if (light) sets = Math.max(2, sets - 1)
  return { sets, reps, rest }
}

/** Zgornja meja ponovitev (»8–12« → 12); na čas null. */
export function repsTopOf(reps: string): number | null {
  if (/\ds\b|\d\s*s\b|sek/i.test(reps)) return null
  const m = String(reps).match(/(\d+)\s*[–-]\s*(\d+)/)
  return m ? +m[2]! : /^\s*\d+\s*$/.test(reps) ? +reps : null
}
/** Najslabša zabeležena serija (»10, 10, 9« → 9; razpon »8–12« → 8). */
export function repsLoggedOf(reps: string): number | null {
  const s = String(reps ?? '')
  if (/\ds\b|\d\s*s\b|sek/i.test(s)) return null
  const range = s.match(/^\s*(\d+)\s*[–-]\s*(\d+)\s*$/)
  if (range) return Math.min(+range[1]!, +range[2]!)
  const nums = (s.match(/\d+/g) || []).map(Number).filter(n => Number.isFinite(n) && n > 0)
  return nums.length ? Math.min(...nums) : null
}
/** Korak teže: palica pri osnovnih vajah 5 kg (nad 40 kg), ročke 2 kg, drugo 2,5 kg. */
export function kgStep(e: ExDef | undefined, kg: number): number {
  if (!e) return 2.5
  if (e.eq === 'fitnes' && e.big && kg >= 40 && (e.pat === 'pocep' || e.pat === 'kolk' || e.pat === 'zadnjica')) return 5
  return e.eq === 'utezi' ? 2 : 2.5
}

/** Zadnja zabeležena izvedba vaje (iz opravljenih vadb moči). */
export function lastDone(name: string, activities: readonly Activity[]): { kg: number | null; reps: string; sets: number; date: string } | null {
  const k = name.toLowerCase()
  const a = [...activities].filter(x => x.sport === 'moc' && x.exercises?.some(e => e.name.toLowerCase() === k)).sort((x, y) => y.date.localeCompare(x.date))[0]
  const e = a?.exercises?.find(z => z.name.toLowerCase() === k)
  return a && e ? { kg: e.kg != null && Number.isFinite(e.kg) && e.kg > 0 ? e.kg : null, reps: e.reps, sets: e.sets, date: a.date } : null
}

/**
 * Seja moči za načrt po meri: vaje po vzorcih dela telesa, prednostne mišice dobijo dodatno vajo (trebuh v vsaki seji),
 * število vaj po času, osnovne vaje ostanejo (napredek), dodatne se vrtijo po tednih. Kilogrami iz zadnje izvedbe —
 * ko so bile vse serije na zgornji meji ponovitev, je teža višja.
 */
export function strengthWorkout(o: {
  part: SessionPart; where: 'fitnes' | 'doma'; equip: readonly FocusEquip[]; level: 1 | 2 | 3; aims: readonly FocusAim[]; muscles: readonly Muscle[]
  min: number; week: number; light?: boolean; limits?: string | null; activities?: readonly Activity[]
  /** vaje, ki jih je izbral AI (id-ji) — veljavne (oprema, raven, omejitve) gredo v tem vrstnem redu, manjkajoče dopolnijo pravila */
  fixed?: readonly string[] | null
}): { exercises: PlanExercise[]; progressed: string[]; skipped: boolean } {
  const lim = limitsOf(o.limits)
  const ctx = { where: o.where, equip: equipFor(o.where, o.equip), level: o.level, limits: lim }
  const n = Math.max(3, Math.min(7, Math.round((o.min - 10) / 8)))
  let order: Pattern[], fill: Pattern[]
  if (o.part === 'trebuh') {
    order = Array.from({ length: n }, (_, i) => (i === n - 1 && n >= 5 ? 'kondicija' : 'trebuh') as Pattern)
    fill = ['trebuh', 'trebuh']
  } else {
    const base = SLOTS[o.part].filter(p => p !== 'trebuh')
    const abs = SLOTS[o.part].includes('trebuh') || o.muscles.includes('trebuh') ? 1 : 0
    // prednostne mišice, ki jih ta del telesa pokrije: dodatna vaja (največ dve)
    const ext = [...new Set(o.muscles.filter(m => m !== 'trebuh' && PART_MUSCLES[o.part].includes(m)).map(m => EXTRA[m][o.week % EXTRA[m].length]!))].slice(0, 2)
    const room = Math.max(2, n - abs - ext.length)
    order = [...base.slice(0, room), ...ext, ...(abs ? ['trebuh' as Pattern] : [])]
    fill = base.slice(room)
  }
  const want = order.length
  const used = new Set<string>()
  const fam = new Set<string>()
  const chosen: ExDef[] = []
  let skipped = false
  // izbor AI: samo vaje iz knjižnice, ki jih imaš na voljo (oprema, raven z eno stopnjo rezerve, brez omejitev)
  // in ki sodijo k delu telesa (glavna mišica; trebuh in kondicija povsod), največ dve iz istega vzorca
  if (o.fixed?.length) {
    const eq = new Set(ctx.equip)
    const fits = (e: ExDef) => o.part === 'celo' || e.pat === 'trebuh' || e.pat === 'kondicija' || PART_MUSCLES[o.part].includes(e.m[0]!)
    const perPat = new Map<Pattern, number>()
    for (const id of o.fixed) {
      const e = exById(id)
      if (!e || used.has(e.id) || fam.has(familyOf(e.id)) || !eq.has(e.eq) || e.lvl > Math.min(3, o.level + 1) || (e.avoid || []).some(l => lim.includes(l)) || !fits(e)) continue
      if ((perPat.get(e.pat) || 0) >= 2) continue
      perPat.set(e.pat, (perPat.get(e.pat) || 0) + 1)
      used.add(e.id); fam.add(familyOf(e.id)); chosen.push(e)
      if (chosen.length >= 8) break
    }
    // AI je izbral (skoraj) dovolj: njegov vrstni red; premalo za čas seje → dopolnijo pravila (samo manjkajoči vzorci)
    if (chosen.length >= Math.max(3, want - 1)) return finish()
  }
  const need = [...order]
  for (const e of chosen) { const k = need.indexOf(e.pat); if (k >= 0) need.splice(k, 1) }
  const queue = [...need, ...fill]
  for (const pat of queue) {
    if (chosen.length >= want) break
    const c = candidates(pat, ctx).filter(e => !used.has(e.id) && !fam.has(familyOf(e.id)))
    if (!c.length) { skipped = true; continue }
    // prva (osnovna) vaja ostane ista — napredek s kilogrami; ostale se vrtijo po tednih
    const pick = !chosen.length ? c[0]! : c[(o.week + chosen.length) % Math.min(c.length, 3)]!
    used.add(pick.id); fam.add(familyOf(pick.id)); chosen.push(pick)
  }
  return finish()

  function finish() {
  const progressed: string[] = []
  const exercises = chosen.map(e => {
    const d = dose(e, o.aims, o.level, o.light)
    let kg: number | null = null
    const last = o.activities ? lastDone(e.name, o.activities) : null
    if (e.kg && last?.kg) {
      kg = last.kg
      const top = repsTopOf(d.reps), got = repsLoggedOf(last.reps)
      if (!o.light && top != null && got != null && got >= top) { kg = Math.round((kg + kgStep(e, kg)) * 2) / 2; progressed.push(e.name) }
    }
    return { name: e.name, sets: d.sets, reps: d.reps, kg, rest: d.rest }
  })
  return { exercises, progressed, skipped }
  }
}

/** Zamenjava vaje (npr. naprava je zasedena): isti vzorec, ista ali manjša raven, druga oprema iz razpoložljive. */
export function swapOptions(name: string, o: { where: 'fitnes' | 'doma'; equip: readonly FocusEquip[]; level: 1 | 2 | 3; limits?: string | null }, exclude: readonly string[] = []): ExDef[] {
  const e = exByName(name)
  if (!e) return []
  const ex = new Set(exclude.map(x => x.toLowerCase()))
  return candidates(e.pat, { where: o.where, equip: equipFor(o.where, o.equip), level: o.level, limits: limitsOf(o.limits) })
    .filter(x => x.id !== e.id && !ex.has(x.name.toLowerCase()))
    .slice(0, 4)
}

/* ---------- osebni rekordi in mišice ---------- */
export interface Record1 { name: string; kg: number | null; reps: number | null; e1rm: number | null; date: string }
/** Najboljša izvedba vsake vaje: s kg po ocenjenem 1RM (Epley), brez kg po ponovitvah. */
export function personalRecords(activities: readonly Activity[]): Record1[] {
  const best = new Map<string, Record1>()
  for (const a of activities) {
    if (a.sport !== 'moc' || !a.exercises) continue
    for (const x of a.exercises) {
      const reps = repsLoggedOf(x.reps)
      if (reps == null) continue
      const kg = x.kg != null && Number.isFinite(x.kg) && x.kg > 0 ? x.kg : null
      const e1rm = kg ? Math.round(kg * (1 + Math.min(reps, 12) / 30) * 2) / 2 : null
      const k = x.name.toLowerCase(), prev = best.get(k)
      const better = !prev || (e1rm != null ? (prev.e1rm ?? 0) < e1rm : prev.e1rm == null && (prev.reps ?? 0) < reps)
      if (better) best.set(k, { name: x.name, kg, reps, e1rm, date: a.date })
    }
  }
  return [...best.values()].sort((a, b) => (b.e1rm ?? 0) - (a.e1rm ?? 0) || (b.reps ?? 0) - (a.reps ?? 0))
}

/** Serije po mišicah (glavna mišica 1, ostale 0,5) — za zemljevid mišic. */
export function setsByMuscle(items: readonly { name: string; sets: number }[]): Record<Muscle, number> {
  const out: Record<Muscle, number> = { trebuh: 0, prsa: 0, hrbet: 0, ramena: 0, roke: 0, noge: 0, zadnjica: 0 }
  for (const x of items) {
    const e = exByName(x.name)
    if (!e) continue
    e.m.forEach((m, i) => { out[m] += (i === 0 ? 1 : 0.5) * Math.max(0, x.sets || 0) })
  }
  return out
}
