import type { Activity, ExPlan, FocusAim, FocusEquip, Muscle, SessionPart } from '../types'

/**
 * KNJIŽNICA VAJ ZA MOČ (fitnes, ročke, elastike, drog, lastna teža) — za načrt po meri (dogovor s trenerjem).
 * Vsaka vaja ima mišice (prva je glavna), opremo, raven, gibalni vzorec (za izbiro in zamenjavo) in kratko tehniko.
 * Seje so sestavljene iz vzorcev (npr. zgornji del: vodoravni potisk, vodoravni poteg, navpični potisk …), vaja se izbere
 * po opremi, ravni in omejitvah; vaje ostanejo iste ves blok 4 tednov (napredek s kilogrami), dodatne se menjajo z novim blokom.
 */
export type Pattern = 'pocep' | 'kolk' | 'enonozno' | 'potiskV' | 'potiskN' | 'potegV' | 'potegN' | 'trebuh' | 'biceps' | 'triceps' | 'ramena' | 'zadnjica' | 'meca' | 'kondicija'
export type Limit = 'koleno' | 'hrbet' | 'rama'
export interface ExDef {
  id: string
  name: string
  /** mišice — prva je glavna */
  m: Muscle[]
  /** oprema, ki jo vaja rabi ('nic' = samo lastna teža) */
  eq: FocusEquip
  lvl: 1 | 2 | 3
  pat: Pattern
  /** vaja na čas (sekunde) */
  time?: boolean
  /** osnovna večsklepna vaja: težje serije, daljša pavza, napredek s kilogrami */
  big?: boolean
  /** z ročko/utežjo, ki jo vpišeš (kg) */
  kg?: boolean
  how: string
  /** izpusti pri teh omejitvah */
  avoid?: Limit[]
  /** (v3.51) samo za trening s slike (CrossFit tabla) — načrt je sam ne izbira */
  photo?: boolean
}

export const EXERCISES: readonly ExDef[] = [
  /* ---- lastna teža ---- */
  { id: 'sklece', name: 'Sklece', m: ['prsa', 'roke', 'ramena'], eq: 'nic', lvl: 2, pat: 'potiskV', big: true, how: 'Dlani malo širše od ramen, telo v ravni črti od glave do pet. Prsi do tal, komolci približno 45° od telesa.', avoid: ['rama'] },
  { id: 'sklece-kolena', name: 'Sklece na kolenih', m: ['prsa', 'roke', 'ramena'], eq: 'nic', lvl: 1, pat: 'potiskV', big: true, how: 'Kolena na tleh, telo od kolen do glave ravno. Ko narediš 15 lepih, preidi na prave sklece.' },
  { id: 'sklece-noge', name: 'Sklece z nogami na stolu', m: ['prsa', 'ramena', 'roke'], eq: 'nic', lvl: 3, pat: 'potiskV', big: true, how: 'Stopala na stolu, telo ravno, prsi proti tlom med dlanmi — težje za zgornji del prsi in ramena.', avoid: ['rama'] },
  { id: 'pike', name: 'Pike sklece', m: ['ramena', 'roke'], eq: 'nic', lvl: 2, pat: 'potiskN', how: 'Boki visoko (telo v obliki črke V), glava gre proti tlom med dlanmi, nato potisni nazaj.', avoid: ['rama'] },
  { id: 'pocep', name: 'Počep', m: ['noge', 'zadnjica'], eq: 'nic', lvl: 1, pat: 'pocep', big: true, how: 'Stopala v širini ramen, boki nazaj in dol, kolena v smeri prstov, pete na tleh. Do vzporedno ali kolikor gre brez bolečine.' },
  { id: 'izpadni', name: 'Izpadni koraki', m: ['noge', 'zadnjica'], eq: 'nic', lvl: 1, pat: 'enonozno', how: 'Velik korak naprej, zadnje koleno skoraj do tal, trup pokončen. Izmenično.', avoid: ['koleno'] },
  { id: 'bolgarski', name: 'Bolgarski počep', m: ['noge', 'zadnjica'], eq: 'nic', lvl: 2, pat: 'enonozno', how: 'Zadnja noga na stolu, sprednje koleno nad prsti, spusti se navpično do 90°, poriv skozi peto.', avoid: ['koleno'] },
  { id: 'most', name: 'Dvig bokov leže', m: ['zadnjica', 'noge'], eq: 'nic', lvl: 1, pat: 'zadnjica', how: 'Leže na hrbtu, stopala blizu zadnjice. Stisni zadnjico in dvigni boke do ravne črte, zgoraj zadrži 1 s.' },
  { id: 'most1', name: 'Dvig bokov na eni nogi', m: ['zadnjica', 'noge'], eq: 'nic', lvl: 2, pat: 'zadnjica', how: 'Kot dvig bokov, a z eno nogo v zraku — boki ostanejo vodoravni.' },
  { id: 'deska', name: 'Deska', m: ['trebuh'], eq: 'nic', lvl: 1, pat: 'trebuh', time: true, how: 'Komolci pod rameni, telo v ravni črti, stisni zadnjico in trebuh, ne povesi bokov.' },
  { id: 'stranska', name: 'Stranska deska', m: ['trebuh'], eq: 'nic', lvl: 1, pat: 'trebuh', time: true, how: 'Komolec pod ramo, boki visoko, telo v ravni črti — vsaka stran posebej.' },
  { id: 'deadbug', name: 'Dead bug', m: ['trebuh'], eq: 'nic', lvl: 1, pat: 'trebuh', how: 'Križ v tleh; nasprotno roko in nogo počasi iztegni, izdihni, zamenjaj.' },
  { id: 'dvig-nog', name: 'Dvig nog leže', m: ['trebuh'], eq: 'nic', lvl: 1, pat: 'trebuh', how: 'Križ pritisnjen v tla, noge počasi dol do 10 cm nad tlemi in nazaj.', avoid: ['hrbet'] },
  { id: 'kolesarcki', name: 'Kolesarski trebušnjaki', m: ['trebuh'], eq: 'nic', lvl: 1, pat: 'trebuh', how: 'Leže, dlani ob glavi, komolec proti nasprotnemu kolenu, druga noga iztegnjena. Počasi, ne vleci vratu.' },
  { id: 'plezalec', name: 'Plezalec', m: ['trebuh', 'ramena'], eq: 'nic', lvl: 1, pat: 'trebuh', time: true, how: 'Položaj za sklece, kolena izmenično hitro proti prsim, boki ostanejo nizko.' },
  { id: 'coln', name: 'Drža čolnička', m: ['trebuh'], eq: 'nic', lvl: 2, pat: 'trebuh', time: true, how: 'Leže na hrbtu, križ pritisnjen v tla, ramena in iztegnjene noge malo od tal. Drži.', avoid: ['hrbet'] },
  { id: 'superman', name: 'Superman', m: ['hrbet', 'zadnjica'], eq: 'nic', lvl: 1, pat: 'kolk', how: 'Leže na trebuhu, hkrati dvigni roke in noge za nekaj cm, zgoraj 2 s, počasi dol.' },
  // (v3.50) poteg brez opreme — prej doma brez opreme ni bilo nobene vaje za hrbet
  { id: 'superman-vlek', name: 'Superman z vlekom', m: ['hrbet', 'ramena'], eq: 'nic', lvl: 1, pat: 'potegV', how: 'Leže na trebuhu, roke naprej, prsi malo od tal. Potegni komolce k bokom in stisni lopatice skupaj, 2 s zadrži, roke spet naprej.' },
  { id: 'dipi', name: 'Dipi na stolu', m: ['roke', 'prsa'], eq: 'nic', lvl: 1, pat: 'triceps', how: 'Dlani na robu stola, komolci gredo nazaj (ne narazen), spusti se do 90° v komolcih.', avoid: ['rama'] },
  { id: 'prsti', name: 'Dvigi na prste', m: ['noge'], eq: 'nic', lvl: 1, pat: 'meca', how: 'Na robu stopnice: počasi gor na prste in počasi dol pod rob.' },
  { id: 'burpee', name: 'Burpee', m: ['noge', 'prsa', 'trebuh'], eq: 'nic', lvl: 2, pat: 'kondicija', how: 'Počep, dlani na tla, skok nazaj v desko, noge nazaj pod telo, skok gor. Enakomerno, ne na vso moč.', avoid: ['koleno'] },
  { id: 'krozni', name: 'Poskoki s kolebnico ali brez', m: ['noge'], eq: 'nic', lvl: 1, pat: 'kondicija', time: true, how: 'Lahki poskoki na prstih, kolena mehka. Brez kolebnice samo posnemaj vrtenje.', avoid: ['koleno'] },
  /* ---- drog za zgibe ---- */
  { id: 'zgibi', name: 'Zgibi', m: ['hrbet', 'roke'], eq: 'drog', lvl: 3, pat: 'potegN', big: true, how: 'Dlani malo širše od ramen, iz polnega visa brada nad drog, brez zamaha. Počasi dol.' },
  { id: 'negativni', name: 'Negativni zgibi', m: ['hrbet', 'roke'], eq: 'drog', lvl: 1, pat: 'potegN', big: true, how: 'Skoči ali stopi do brade nad drogom, nato se 3–5 s počasi spuščaj do polnega visa.' },
  { id: 'kolena-vis', name: 'Dvig kolen v visenju', m: ['trebuh'], eq: 'drog', lvl: 2, pat: 'trebuh', how: 'V visu dvigni kolena do prsi brez zamaha, počasi dol.' },
  /* ---- ročke (doma ali v fitnesu) ---- */
  { id: 'goblet', name: 'Goblet počep', m: ['noge', 'zadnjica'], eq: 'utezi', lvl: 1, pat: 'pocep', big: true, kg: true, how: 'Ročko drži pred prsmi, komolci gredo na dnu med kolena; prsi gor, pete na tleh.' },
  { id: 'rdl-r', name: 'Romunski mrtvi dvig z ročkami', m: ['zadnjica', 'noge', 'hrbet'], eq: 'utezi', lvl: 1, pat: 'kolk', big: true, kg: true, how: 'Kolena rahlo pokrčena, boki nazaj, hrbet raven, ročke drsijo ob nogah do sredine golenic.', avoid: ['hrbet'] },
  { id: 'potisk-r', name: 'Potisk z ročkami', m: ['prsa', 'roke', 'ramena'], eq: 'utezi', lvl: 1, pat: 'potiskV', big: true, kg: true, how: 'Na klopi ali tleh: ročke nad prsmi, spusti do komolcev pod 45° od telesa, potisni gor.' },
  { id: 'veslanje-r', name: 'Enoročno veslanje z ročko', m: ['hrbet', 'roke'], eq: 'utezi', lvl: 1, pat: 'potegV', big: true, kg: true, how: 'Roka in koleno na klopi, hrbet raven, potegni ročko k boku, komolec ob telesu.' },
  { id: 'nadglavo-r', name: 'Potisk nad glavo z ročkami', m: ['ramena', 'roke'], eq: 'utezi', lvl: 1, pat: 'potiskN', kg: true, how: 'Stoje ali sede, trebuh napet: ročke od ramen nad glavo, brez usločenja v križu.', avoid: ['rama'] },
  { id: 'odrocenje', name: 'Odročenje z ročkami', m: ['ramena'], eq: 'utezi', lvl: 1, pat: 'ramena', kg: true, how: 'Komolci rahlo pokrčeni, ročke v stran do višine ramen, počasi dol. Lahka teža, brez zamaha.' },
  { id: 'biceps-r', name: 'Upogib za biceps z ročkami', m: ['roke'], eq: 'utezi', lvl: 1, pat: 'biceps', kg: true, how: 'Komolci ob telesu, ročke gor brez zamaha, počasi dol.' },
  { id: 'triceps-r', name: 'Iztegi za triceps nad glavo', m: ['roke'], eq: 'utezi', lvl: 1, pat: 'triceps', kg: true, how: 'Ročka za glavo, komolci kažejo naprej-gor, iztegni roke nad glavo.', avoid: ['rama'] },
  { id: 'izpadni-r', name: 'Izpadni koraki z ročkami', m: ['noge', 'zadnjica'], eq: 'utezi', lvl: 2, pat: 'enonozno', kg: true, how: 'Ročke ob telesu, velik korak naprej, zadnje koleno skoraj do tal, trup pokončen.', avoid: ['koleno'] },
  { id: 'stopanje-r', name: 'Stopanje na klop z ročkami', m: ['noge', 'zadnjica'], eq: 'utezi', lvl: 1, pat: 'enonozno', kg: true, how: 'Cela stopala na klopi, poriv skozi peto zgornje noge, spodnja samo spremlja. Počasi dol.' },
  { id: 'hip-r', name: 'Hip thrust z ročko', m: ['zadnjica', 'noge'], eq: 'utezi', lvl: 1, pat: 'zadnjica', kg: true, how: 'Lopatice na klopi ali kavču, ročka na bokih, dvigni boke do ravne črte in stisni zadnjico.' },
  { id: 'zasuki-r', name: 'Ruski zasuki z ročko', m: ['trebuh'], eq: 'utezi', lvl: 2, pat: 'trebuh', kg: true, how: 'Sede, trup rahlo nazaj, ročko vodi z ene strani na drugo, gib iz trupa.', avoid: ['hrbet'] },
  { id: 'zamah', name: 'Zamah z utežjo', m: ['zadnjica', 'noge', 'hrbet'], eq: 'utezi', lvl: 2, pat: 'kondicija', kg: true, how: 'Boki nazaj in nato močno naprej — moč pride iz bokov, ne iz rok. Hrbet raven.', avoid: ['hrbet'] },
  /* ---- elastike ---- */
  { id: 'veslanje-e', name: 'Veslanje z elastiko', m: ['hrbet', 'roke'], eq: 'elastike', lvl: 1, pat: 'potegV', big: true, how: 'Elastika zataknjena v višini prsi, potegni komolce nazaj, stisni lopatice skupaj.' },
  { id: 'razteg-e', name: 'Razteg elastike pred prsmi', m: ['ramena', 'hrbet'], eq: 'elastike', lvl: 1, pat: 'ramena', how: 'Iztegnjene roke pred prsmi, raztegni elastiko do prsi, lopatice skupaj, počasi nazaj.' },
  { id: 'biceps-e', name: 'Upogib za biceps z elastiko', m: ['roke'], eq: 'elastike', lvl: 1, pat: 'biceps', how: 'Stopi na elastiko, komolci ob telesu, dlani gor do ramen, počasi dol.' },
  { id: 'pallof', name: 'Pallof press', m: ['trebuh'], eq: 'elastike', lvl: 1, pat: 'trebuh', how: 'Elastika ob strani v višini prsi: potisni roke naravnost naprej in ne pusti, da te zasuka.' },
  { id: 'koraki-e', name: 'Stranski koraki z elastiko', m: ['zadnjica'], eq: 'elastike', lvl: 1, pat: 'zadnjica', how: 'Elastika nad koleni, rahel počep, majhni koraki vstran, kolena navzven.' },
  /* ---- fitnes (naprave, palica, kabli) ---- */
  { id: 'pocep-p', name: 'Počep s palico', m: ['noge', 'zadnjica'], eq: 'fitnes', lvl: 2, pat: 'pocep', big: true, kg: true, how: 'Palica na zgornjem delu hrbta, stopala v širini ramen, boki nazaj in dol do vzporedno, hrbet raven.', avoid: ['koleno', 'hrbet'] },
  { id: 'presa', name: 'Nožna preša', m: ['noge', 'zadnjica'], eq: 'fitnes', lvl: 1, pat: 'pocep', big: true, kg: true, how: 'Stopala v širini ramen, spusti do 90° v kolenih, kolen na vrhu ne zakleni.' },
  { id: 'mrtvi', name: 'Mrtvi dvig', m: ['hrbet', 'zadnjica', 'noge'], eq: 'fitnes', lvl: 3, pat: 'kolk', big: true, kg: true, how: 'Palica nad sredino stopal, hrbet raven, potisni tla stran in iztegni boke in kolena hkrati. Tehnika pred kilogrami.', avoid: ['hrbet'] },
  { id: 'rdl-p', name: 'Romunski mrtvi dvig s palico', m: ['zadnjica', 'noge', 'hrbet'], eq: 'fitnes', lvl: 2, pat: 'kolk', big: true, kg: true, how: 'Kolena rahlo pokrčena, boki nazaj, palica drsi ob nogah do sredine golenic, hrbet raven.', avoid: ['hrbet'] },
  { id: 'bench', name: 'Potisk s palico na ravni klopi', m: ['prsa', 'roke', 'ramena'], eq: 'fitnes', lvl: 2, pat: 'potiskV', big: true, kg: true, how: 'Lopatice skupaj in dol, palica do spodnjega dela prsi, komolci ~45°. Pri težkih serijah z varovanjem.', avoid: ['rama'] },
  { id: 'incline-r', name: 'Potisk z ročkami na poševni klopi', m: ['prsa', 'ramena', 'roke'], eq: 'fitnes', lvl: 1, pat: 'potiskV', big: true, kg: true, how: 'Klop na 30°, ročke nad zgornjim delom prsi, spusti s kontrolo, potisni gor in malo skupaj.' },
  { id: 'metuljcek', name: 'Metuljček na napravi', m: ['prsa'], eq: 'fitnes', lvl: 1, pat: 'potiskV', kg: true, how: 'Komolci rahlo pokrčeni, roke skupaj pred prsmi, zgoraj stisni prsi, počasi nazaj.' },
  { id: 'pulldown', name: 'Poteg na prsi', m: ['hrbet', 'roke'], eq: 'fitnes', lvl: 1, pat: 'potegN', big: true, kg: true, how: 'Širok prijem, drog potegni do zgornjega dela prsi, komolci navzdol, brez zibanja.' },
  { id: 'kabel-v', name: 'Veslanje na kablu sede', m: ['hrbet', 'roke'], eq: 'fitnes', lvl: 1, pat: 'potegV', big: true, kg: true, how: 'Prsi gor, ročaj potegni k trebuhu, lopatice skupaj, počasi nazaj.' },
  { id: 'veslanje-p', name: 'Veslanje s palico v predklonu', m: ['hrbet', 'roke'], eq: 'fitnes', lvl: 2, pat: 'potegV', big: true, kg: true, how: 'Predklon z ravnim hrbtom, palico potegni k spodnjemu delu prsi, komolci ob telesu.', avoid: ['hrbet'] },
  { id: 'ohp', name: 'Potisk s palico nad glavo', m: ['ramena', 'roke'], eq: 'fitnes', lvl: 2, pat: 'potiskN', big: true, kg: true, how: 'Stoje, trebuh in zadnjica napeta, palica od ključnic nad glavo, glava gre skozi »okno«.', avoid: ['rama', 'hrbet'] },
  { id: 'facepull', name: 'Face pull na kablu', m: ['ramena', 'hrbet'], eq: 'fitnes', lvl: 1, pat: 'ramena', kg: true, how: 'Vrv v višini oči, potegni k obrazu, komolci visoko in navzven.' },
  { id: 'triceps-k', name: 'Iztegi za triceps na kablu', m: ['roke'], eq: 'fitnes', lvl: 1, pat: 'triceps', kg: true, how: 'Komolci ob telesu, iztegni roke navzdol, počasi nazaj.' },
  { id: 'biceps-p', name: 'Upogib za biceps s palico', m: ['roke'], eq: 'fitnes', lvl: 1, pat: 'biceps', kg: true, how: 'Komolci ob telesu, palica gor brez zamaha, počasi dol.' },
  { id: 'leg-curl', name: 'Upogib kolen na napravi', m: ['noge'], eq: 'fitnes', lvl: 1, pat: 'kolk', kg: true, how: 'Počasi gor in dol, boki ostanejo na blazini.' },
  { id: 'leg-ext', name: 'Izteg kolen na napravi', m: ['noge'], eq: 'fitnes', lvl: 1, pat: 'pocep', kg: true, how: 'Iztegni kolena do skoraj ravno, zgoraj 1 s, počasi dol.', avoid: ['koleno'] },
  { id: 'hip-p', name: 'Hip thrust s palico', m: ['zadnjica', 'noge'], eq: 'fitnes', lvl: 2, pat: 'zadnjica', big: true, kg: true, how: 'Lopatice na klopi, palica z blazino na bokih, dvigni boke do ravne črte, brada k prsim.' },
  { id: 'prsti-n', name: 'Dvigi na prste na napravi', m: ['noge'], eq: 'fitnes', lvl: 1, pat: 'meca', kg: true, how: 'Polna amplituda: čisto dol in čisto gor, zgoraj 1 s.' },
  { id: 'kabel-zasuk', name: 'Zasuki na kablu', m: ['trebuh'], eq: 'fitnes', lvl: 1, pat: 'trebuh', kg: true, how: 'Kabel v višini prsi, roke iztegnjene, vrtenje iz trupa, boki mirni.' },
  { id: 'bradlja', name: 'Dvig kolen na bradlji', m: ['trebuh'], eq: 'fitnes', lvl: 2, pat: 'trebuh', how: 'Podlakti na blazinah, hrbet ob naslonu, kolena do prsi brez zamaha.' },
  { id: 'valjcek', name: 'Valjček za trebuh', m: ['trebuh'], eq: 'fitnes', lvl: 3, pat: 'trebuh', how: 'Na kolenih, počasi naprej, kolikor zdržiš z ravnim hrbtom, nazaj s trebuhom.', avoid: ['hrbet'] },
  { id: 'hiper', name: 'Hiperekstenzija', m: ['hrbet', 'zadnjica'], eq: 'fitnes', lvl: 1, pat: 'kolk', how: 'Na napravi spusti trup in ga dvigni do ravne črte — ne usloči se nazaj.' },
  { id: 'veslo', name: 'Veslanje na ergometru', m: ['hrbet', 'noge'], eq: 'fitnes', lvl: 1, pat: 'kondicija', time: true, how: 'Noge, trup, roke — in nazaj v obratnem vrstnem redu. Enakomerno, dihaj.' },
  /* ---- (v3.51) s table v fitnesu (Wall ball, Thruster, Box jump) — vodena vadba ima tehniko in figuro ---- */
  { id: 'wallball', name: 'Met žoge v steno', m: ['noge', 'ramena', 'zadnjica'], eq: 'fitnes', lvl: 2, pat: 'kondicija', kg: true, photo: true, how: 'Žoga pred prsmi, počep do vzporedno, nato iz nog potisni žogo v cilj na steni. Ujemi jo in takoj v naslednji počep.', avoid: ['koleno'] },
  { id: 'thruster', name: 'Potisk s počepom', m: ['noge', 'ramena', 'roke'], eq: 'utezi', lvl: 2, pat: 'kondicija', kg: true, photo: true, how: 'Ročki ali palica na ramenih, počep, nato iz nog v en gib potisk nad glavo. Hrbet raven, komolci naprej.', avoid: ['rama', 'koleno'] },
  { id: 'boxjump', name: 'Skok na škatlo', m: ['noge', 'zadnjica'], eq: 'fitnes', lvl: 2, pat: 'kondicija', photo: true, how: 'Zamah z rokami, skok z obema nogama, mehak doskok na celo stopalo. Na škatli se zravnaj in stopi dol.', avoid: ['koleno'] },
]

export const MUSCLE_LABEL: Record<Muscle, string> = { trebuh: 'trebuh', prsa: 'prsa', hrbet: 'hrbet', ramena: 'ramena', roke: 'roke', noge: 'noge', zadnjica: 'zadnjica' }
export const PART_LABEL: Record<SessionPart, string> = { celo: 'celo telo', zgornji: 'zgornji del', spodnji: 'spodnji del', potisk: 'prsa, ramena, triceps', poteg: 'hrbet in biceps', noge: 'noge in zadnjica', trebuh: 'trebuh', roke: 'roke in ramena' }
/** mišice, ki jih del telesa pokrije (za prednostne mišice in zemljevid) */
export const PART_MUSCLES: Record<SessionPart, Muscle[]> = {
  celo: ['noge', 'prsa', 'hrbet', 'zadnjica', 'trebuh', 'ramena', 'roke'], zgornji: ['prsa', 'hrbet', 'ramena', 'roke'], spodnji: ['noge', 'zadnjica', 'trebuh'],
  potisk: ['prsa', 'ramena', 'roke'], poteg: ['hrbet', 'roke', 'ramena'], noge: ['noge', 'zadnjica'], trebuh: ['trebuh'], roke: ['roke', 'ramena'],
}
/** vzorci po delih telesa — vrstni red je vrstni red vaj v seji */
const SLOTS: Record<SessionPart, Pattern[]> = {
  celo: ['pocep', 'potiskV', 'potegV', 'kolk', 'potegN', 'trebuh'],
  zgornji: ['potiskV', 'potegV', 'potiskN', 'potegN', 'biceps', 'triceps', 'ramena'],
  spodnji: ['pocep', 'kolk', 'enonozno', 'zadnjica', 'trebuh', 'meca'],
  noge: ['pocep', 'kolk', 'enonozno', 'zadnjica', 'meca', 'trebuh'],
  potisk: ['potiskV', 'potiskN', 'potiskV', 'ramena', 'triceps', 'trebuh'],
  poteg: ['potegN', 'potegV', 'ramena', 'biceps', 'potegV', 'trebuh'],
  trebuh: ['trebuh', 'trebuh', 'trebuh', 'trebuh', 'kondicija'],
  roke: ['biceps', 'triceps', 'ramena', 'biceps', 'triceps', 'trebuh'],
}
/** prednostna mišica → vzorec, ki jo dodatno trenira */
const EXTRA: Record<Muscle, Pattern[]> = { trebuh: ['trebuh'], prsa: ['potiskV'], hrbet: ['potegV', 'potegN'], ramena: ['ramena', 'potiskN'], roke: ['biceps', 'triceps'], noge: ['enonozno', 'pocep'], zadnjica: ['zadnjica'] }

/** Različice iste vaje (sklece na kolenih, počep z ročko …): v eni seji samo ena iz družine. */
const FAMILY: Record<string, string> = {
  'sklece-kolena': 'sklece', 'sklece-noge': 'sklece', most1: 'most', 'hip-r': 'most', 'hip-p': 'most', goblet: 'pocep', 'pocep-p': 'pocep',
  'rdl-p': 'rdl-r', mrtvi: 'rdl-r', 'veslanje-e': 'veslanje-r', 'veslanje-p': 'veslanje-r', negativni: 'zgibi',
  'biceps-e': 'biceps-r', 'biceps-p': 'biceps-r', 'triceps-k': 'triceps-r', 'izpadni-r': 'izpadni', 'superman-vlek': 'superman',
}
export const familyOf = (id: string): string => FAMILY[id] ?? id
export const exByName = (name: string): ExDef | undefined => EXERCISES.find(e => e.name.toLowerCase() === name.toLowerCase())
export const exById = (id: string): ExDef | undefined => EXERCISES.find(e => e.id === id)

/** Omejitve iz besedila (»koleno me boli«, »križ«, »rama«). */
export function limitsOf(text: string | null | undefined): Limit[] {
  const t = (text || '').toLowerCase()
  const out: Limit[] = []
  if (/kolen|koleno|menisk|vez/.test(t)) out.push('koleno')
  if (/hrbet|hrbt|križ|kriz|ledv|disk/.test(t)) out.push('hrbet')
  if (/\bram[aeiou]\b|ramen|ramn|rotator/.test(t)) out.push('rama')
  return out
}
/** (v3.50) zdravstvene omejitve iz besed (»imam visok krvni tlak«, »sladkorna«, »po operaciji«) → kratke oznake */
const HEALTH: [RegExp, string][] = [
  [/srce ali krvni tlak/u, 'srce ali krvni tlak'],
  [/(?:nizek|nizk\p{L}*)\s+(?:krvn\p{L}*\s+)?(?:tlak|pritisk)|hipotenz/u, 'nizek krvni tlak'],
  [/(?:krvn|visok|povi(?:š|s)an)\p{L}*\s+(?:krvn\p{L}*\s+)?(?:tlak|pritisk)|hipertenz/u, 'visok krvni tlak'],
  [/te(?:ž|z)av\p{L}* s srcem|sr(?:č|c)n\p{L}* (?:bolez|napak|te(?:ž|z)av|popu(?:š|s)(?:č|c)an|aritmij)|aritmij|infarkt|(?<![\p{L}])stent|spodbujevalnik|angin[aeo] pektoris|(?:^|,\s*)srce(?=\s*,|\s*$)/u, 'srce'],
  [/sladkorn\p{L}* bolez|imam sladkorno|diabet/u, 'sladkorna bolezen'], [/astm/u, 'astma'], [/nose(?:č|c)(?:n|a(?![\p{L}])|e(?![\p{L}]))/u, 'nosečnost'],
  [/operacij|operiran/u, 'po operaciji'], [/epilep/u, 'epilepsija'],
]
export function healthOf(text: string | null | undefined): string[] {
  const t = (text || '').toLowerCase()
  const out: string[] = []
  for (const [rx, l] of HEALTH) if (rx.test(t) && !out.includes(l)) out.push(l)
  // »srce ali krvni tlak« (vprašalnik) zajame tlak; nizek tlak ni visok
  return out.filter(l => !(l === 'visok krvni tlak' && (out.includes('srce ali krvni tlak') || out.includes('nizek krvni tlak'))))
}
/**
 * (v3.51) Zdravje iz prostega besedila (pogajanje, želja): samo kar velja zate — brez nikalnice tik pred izrazom
 * (»nimam visokega pritiska«, »nisem noseča«, »brez težav s srcem«) in brez druge osebe (»mama ima visok pritisk«).
 * Stavek se deli na dele pri ločilih in »ampak/vendar/jaz pa«. Oznake v `limits` bere healthOf.
 */
const NEG_BEFORE = /(?:^|[^\p{L}])(?:ni|nimam|nima|nimava|nimamo|nisem|nisi|nismo|brez|ne|nikoli)(?:\s+\p{L}+){0,2}\s*$/u
const OTHER_PERSON = /(?:^|[^\p{L}])(?:mam[aie]|mami|o(?:č|c)e|o(?:č|c)i|ati|brat\p{L}*|sestr\p{L}*|partner\p{L}*|(?:ž|z)en[aei]|mo(?:ž|z)(?:a|u|em)?|prijatelj\p{L}*|sin(?:a|u|om)?|h(?:č|c)i|h(?:č|c)erk\p{L}*|babic\p{L}*|dedek|dedi|tet[aei]|stric\p{L}*|on[ao]?|ima|imata|imajo)(?![\p{L}])/u
export function healthSaid(text: string | null | undefined): string[] {
  const out: string[] = []
  for (const part of (text || '').toLowerCase().split(/[,.;!?\n]+|\s(?:ampak|vendar|jaz pa|sam pa)\s/u)) {
    for (const [rx, l] of HEALTH) {
      const m = rx.exec(part)
      if (!m || out.includes(l)) continue
      const pre = part.slice(0, m.index)
      if (NEG_BEFORE.test(pre) || OTHER_PERSON.test(pre)) continue
      out.push(l)
    }
  }
  return out.filter(l => !(l === 'visok krvni tlak' && (out.includes('srce ali krvni tlak') || out.includes('nizek krvni tlak'))))
}
/** (v3.50) besede za opis dneva: »Pišeš, da imaš visok krvni tlak« */
export const HEALTH_SAY: Record<string, string> = {
  'srce ali krvni tlak': 'imaš težave s srcem ali krvnim tlakom', 'nizek krvni tlak': 'imaš nizek krvni tlak', 'visok krvni tlak': 'imaš visok krvni tlak',
  srce: 'imaš težave s srcem', 'sladkorna bolezen': 'imaš sladkorno bolezen', astma: 'imaš astmo', 'nosečnost': 'pričakuješ otroka', 'po operaciji': 'si po operaciji', epilepsija: 'imaš epilepsijo',
}

/** Kaj je na voljo: v fitnesu vse naprave, ročke, drog in elastike; doma samo, kar imaš (vedno lastna teža). */
export function equipFor(where: 'fitnes' | 'doma', own: readonly FocusEquip[]): FocusEquip[] {
  return where === 'fitnes' ? ['fitnes', 'utezi', 'drog', 'elastike', 'nic'] : [...new Set<FocusEquip>([...own.filter(e => e !== 'fitnes'), 'nic'])]
}
/** prednost opreme: v fitnesu naprave in palice, doma ročke, potem elastike, drog in lastna teža */
const EQ_RANK: Record<'fitnes' | 'doma', Record<FocusEquip, number>> = {
  fitnes: { fitnes: 0, utezi: 1, drog: 2, elastike: 4, nic: 3 },
  doma: { utezi: 0, drog: 1, elastike: 2, nic: 3, fitnes: 9 },
}

/** Kandidati za vzorec: oprema, raven (najvišja svoja), omejitve; razvrščeni po opremi in najbližji ravni. */
export function candidates(pat: Pattern, o: { where: 'fitnes' | 'doma'; equip: readonly FocusEquip[]; level: 1 | 2 | 3; limits: readonly Limit[] }): ExDef[] {
  const eq = new Set(o.equip)
  return EXERCISES
    .filter(e => !e.photo && e.pat === pat && eq.has(e.eq) && e.lvl <= o.level && !(e.avoid || []).some(l => o.limits.includes(l)))
    .sort((a, b) => EQ_RANK[o.where][a.eq] - EQ_RANK[o.where][b.eq] || (o.level - a.lvl) - (o.level - b.lvl) || EXERCISES.indexOf(a) - EXERCISES.indexOf(b))
}

export interface PlanExercise { name: string; sets: number; reps: string; kg?: number | null; rest?: number | null }

/** (v3.50) sekund na serijo brez časovnika (nastavitev, 4–15 ponovitev) — za oceno trajanja seje */
export const SET_SEC = 35
/**
 * (v3.50) Ocena trajanja seje moči v minutah, kot jo izvede vodena vadba (workout.ts strengthSteps): ogrevanje 5 min,
 * serije (na čas po zgornji meji, sicer 35 s) s pavzami, med vajami vsaj 90 s, raztezanje 4 min. Prej je bilo število vaj
 * samo iz minut (45 min → vodena vadba 53 min, 60 min → 72–78 min).
 */
export interface SessionTiming { /** ogrevanje (fitnes 8 min, doma 5) */ wuMin: number; /** najkrajša pavza iz opisa seje (»90 s pri ostalih«) */ minRest: number }
/** (v3.50) ogrevanje in najkrajša pavza, kot ju zapiše opis seje (focusPlan strengthDay) in bere vodena vadba */
export const sessionTiming = (o: { where: 'fitnes' | 'doma'; aims: readonly FocusAim[]; level: number }): SessionTiming =>
  ({ wuMin: o.where === 'fitnes' ? 8 : 5, minRest: restText(o.aims, o.level).minRest })
/** (v3.50) čista moč: cilj moč brez mišic in hujšanja (»Več mišic in moči« je hipertrofija, »vitka in močna« hujšanje) */
const pureStrength = (aims: readonly FocusAim[]) => aims.includes('moc') && !aims.includes('misice') && !aims.includes('hujsanje') && !aims.includes('definicija')
/** (v3.50) pavza v opisu seje po istem pravilu kot dose(): čista moč 2–3 min, mišice + moč ali hujšanje 2 min pri osnovnih */
export function restText(aims: readonly FocusAim[], level: number): { text: string; minRest: number } {
  const cut = aims.includes('hujsanje') || aims.includes('definicija')
  if (pureStrength(aims) && level >= 2) return { text: 'Med serijami 2–3 min pri osnovnih vajah, 90 s pri ostalih.', minRest: 90 }
  if (level >= 2 && (cut || (aims.includes('moc') && aims.includes('misice')))) return { text: 'Med serijami 2 min pri osnovnih vajah, 90 s pri ostalih.', minRest: 90 }
  if (aims.includes('misice')) return { text: 'Med serijami 90 s.', minRest: 90 }
  return { text: 'Med serijami 60 s — tempo drži kondicijo.', minRest: 60 }
}
/**
 * (v3.50) Cilji za odmerek: mladoletni (raven do 2, 1. blok) in zdravstvena omejitev (tlak, srce …) brez težkih serij —
 * mišice 8–12, sicer 10–15 (prej 16-letnik 4 × 4–6 s palico v 1. tednu).
 */
export function safeAims(aims: readonly FocusAim[], o: { minor?: boolean; health?: boolean }): FocusAim[] {
  if (!o.minor && !o.health) return [...aims]
  const muscle = aims.some(a => a === 'misice' || a === 'moc' || a === 'definicija')
  return [...new Set<FocusAim>([...aims.filter(a => a !== 'moc' && a !== 'hujsanje' && a !== 'definicija'), ...(muscle ? ['misice' as const] : [])])]
}
export function strengthMinutes(ex: readonly PlanExercise[], t: SessionTiming = { wuMin: 5, minRest: 60 }): number {
  let sec = t.wuMin * 60 + 4 * 60
  const restOf = (e: PlanExercise) => Math.max(30, Math.min(180, Math.max(e.rest ?? 60, t.minRest)))
  ex.forEach((e, i) => {
    const re = /(\d+)\s*s\b/g; let setSec = 0; for (let m = re.exec(e.reps); m; m = re.exec(e.reps)) setSec = Math.max(setSec, +m[1]!)
    sec += e.sets * (setSec || SET_SEC) + (e.sets - 1) * restOf(e)
    if (i) sec += Math.max(90, restOf(ex[i - 1]!))
  })
  return Math.round(sec / 60)
}
/**
 * (v3.50) Seja naj traja toliko, kot si rekel: čez proračun (+10 %) najprej krajše pavze dodatnih vaj (na najkrajšo), nato
 * serija manj pri dodatnih (najmanj 2), nato serija manj pri osnovnih razen prve (najmanj 3), nazadnje vaja ven (ostanejo
 * vsaj 3, trebuh ostane). Prva (osnovna) vaja ostane, kot je — nosi napredek s kilogrami.
 */
export function fitToMinutes(ex: PlanExercise[], min: number, t: SessionTiming = { wuMin: 5, minRest: 60 }): PlanExercise[] {
  const cap = min * 1.1
  const out = ex.map(e => ({ ...e }))
  const big = (e: PlanExercise) => !!exByName(e.name)?.big
  const over = () => strengthMinutes(out, t) > cap
  if (!over()) return out
  for (let i = 1; i < out.length && over(); i++) if (!big(out[i]!) && (out[i]!.rest ?? 60) > t.minRest) out[i]!.rest = t.minRest
  for (let i = 1; i < out.length && over(); i++) if (!big(out[i]!) && out[i]!.sets > 2) out[i]!.sets -= 1
  for (let i = 1; i < out.length && over(); i++) if (big(out[i]!) && out[i]!.sets > 3) out[i]!.sets -= 1
  // vaja ven: zadnja, ki ni trebuh (trebuh je v vsaki seji namenoma)
  while (out.length > 3 && over()) { const k = out.map((_e, i) => i).reverse().find(i => i >= 1 && exByName(out[i]!.name)?.pat !== 'trebuh') ?? out.length - 1; out.splice(k, 1) }
  return out
}

/** Serije, ponovitve in pavza po cilju in ravni. Lažji teden: serija manj. */
export function dose(e: ExDef, aims: readonly FocusAim[], level: 1 | 2 | 3, light = false): { sets: number; reps: string; rest: number } {
  let sets: number, reps: string, rest: number
  // z obremenitvijo (palica, naprava, ročke): težke serije; lastna teža: več ponovitev (4–6 sklec ni dražljaj)
  const loaded = !!e.kg || e.eq === 'fitnes'
  const cut = aims.includes('definicija') || aims.includes('hujsanje')
  if (e.time) {
    sets = level === 1 ? 2 : 3
    reps = e.pat === 'kondicija' ? (level === 1 ? '30 s' : '40 s') : level === 1 ? '20–30 s' : level === 2 ? '30–45 s' : '45–60 s'
    rest = 45
  } else if (e.pat === 'kondicija') { sets = 3; reps = level === 1 ? '8–10' : '10–15'; rest = 60 }
  // (v3.50) 4–6 samo za čisto moč — prej je »moč« prevladala tudi pri »Več mišic in moči« in »vitka in močna«
  else if (pureStrength(aims) && e.big && level >= 2 && loaded) { sets = level === 3 ? 5 : 4; reps = '4–6'; rest = 150 }
  // hujšanje z ohranjanjem mišic: osnovne vaje ostanejo težke (6–10), da telo mišic ne »odvrže«
  else if (cut && e.big && level >= 2 && loaded) { sets = level === 3 ? 4 : 3; reps = '6–10'; rest = 120 }
  // (v3.50) mišice in moč: osnovne 4 × 6–8 (moč in masa), ostale kot pri mišicah
  else if (aims.includes('moc') && aims.includes('misice') && e.big && level >= 2 && loaded) { sets = 4; reps = '6–8'; rest = 120 }
  else if (aims.includes('moc') && e.big && level >= 2) { sets = level === 3 ? 4 : 3; reps = e.eq === 'drog' ? '5–8' : '8–15'; rest = 90 }
  else if (aims.includes('misice')) { sets = e.big ? (level === 1 ? 3 : 4) : 3; reps = e.big ? '8–12' : '10–15'; rest = e.big ? 105 : 75 }
  else { sets = e.big ? 3 : level === 1 ? 2 : 3; reps = level === 1 ? '10–12' : '10–15'; rest = 60 }
  if (e.pat === 'trebuh' && !e.time) { reps = level === 1 ? '10–12' : '12–15'; rest = 45 }
  if (level === 1) sets = Math.min(sets, 3)
  if (light) sets = Math.max(2, sets - 1)
  return { sets, reps, rest }
}

/** Zgornja meja ponovitev (»8–12« → 12); na čas null. */
export function repsTopOf(reps: string): number | null {
  if (/\ds\b|\d\s*s\b|sek/i.test(reps)) return null
  const m = String(reps).match(/(\d+)\s*[–-]\s*(\d+)/)
  return m ? +m[2]! : /^\s*\d+\s*$/.test(reps) ? +reps : null
}
/** Najslabša zabeležena serija (»10, 10, 9« → 9; razpon »8–12« → 8). */
export function repsLoggedOf(reps: string): number | null {
  const s = String(reps ?? '')
  if (/\ds\b|\d\s*s\b|sek/i.test(s)) return null
  const range = s.match(/^\s*(\d+)\s*[–-]\s*(\d+)\s*$/)
  if (range) return Math.min(+range[1]!, +range[2]!)
  const nums = (s.match(/\d+/g) || []).map(Number).filter(n => Number.isFinite(n) && n > 0)
  return nums.length ? Math.min(...nums) : null
}
/** Korak teže: palica pri osnovnih vajah 5 kg (nad 40 kg), ročke 2 kg, drugo 2,5 kg. */
export function kgStep(e: ExDef | undefined, kg: number): number {
  if (!e) return 2.5
  if (e.eq === 'fitnes' && e.big && kg >= 40 && (e.pat === 'pocep' || e.pat === 'kolk' || e.pat === 'zadnjica')) return 5
  return e.eq === 'utezi' ? 2 : 2.5
}

/** Zadnja zabeležena izvedba vaje (iz opravljenih vadb moči). */
export function lastDone(name: string, activities: readonly Activity[]): { kg: number | null; reps: string; sets: number; date: string } | null {
  const k = name.toLowerCase()
  const a = [...activities].filter(x => x.sport === 'moc' && x.exercises?.some(e => e.name.toLowerCase() === k)).sort((x, y) => y.date.localeCompare(x.date))[0]
  const e = a?.exercises?.find(z => z.name.toLowerCase() === k)
  return a && e ? { kg: e.kg != null && Number.isFinite(e.kg) && e.kg > 0 ? e.kg : null, reps: e.reps, sets: e.sets, date: a.date } : null
}

/**
 * Seja moči za načrt po meri: vaje po vzorcih dela telesa, prednostne mišice dobijo dodatno vajo (trebuh v vsaki seji),
 * število vaj po času, osnovne vaje ostanejo (napredek), dodatne se menjajo po blokih. Kilogrami iz zadnje izvedbe —
 * ko so bile vse serije na zgornji meji ponovitev, je teža višja.
 */
export function strengthWorkout(o: {
  part: SessionPart; where: 'fitnes' | 'doma'; equip: readonly FocusEquip[]; level: 1 | 2 | 3; aims: readonly FocusAim[]; muscles: readonly Muscle[]
  min: number; week: number; light?: boolean; limits?: string | null; activities?: readonly Activity[]
  /** (v3.49) ista seja večkrat na teden (celo telo A/B): 0 = prva, 1 = druga … — druga dobi druge dodatne vaje */
  variant?: number
  /** vaje, ki jih je izbral AI (id-ji) — veljavne (oprema, raven, omejitve) gredo v tem vrstnem redu, manjkajoče dopolnijo pravila */
  fixed?: readonly string[] | null
  /** vaje s serijami in ponovitvami od trenerja (Claude) */
  plan?: readonly ExPlan[] | null
  /** trener ima proste roke: njegove vaje veljajo, kot jih je dal (samo vaje, ki jih ta kraj vadbe ima) */
  free?: boolean
  /** (v3.50) mlajši od 18: v 1. bloku (raven do 2) brez težkih serij, negativnih zgibov in mrtvega dviga */
  minor?: boolean
  /** (v3.50) zdravstvena omejitev (tlak, srce …): brez težkih serij */
  health?: boolean
}): { exercises: PlanExercise[]; progressed: string[]; skipped: boolean; aims: FocusAim[] } {
  const lim = limitsOf(o.limits)
  const ctx = { where: o.where, equip: equipFor(o.where, o.equip), level: o.level, limits: lim }
  const young = !!o.minor && o.level <= 2 && o.week <= 4
  const aims = safeAims(o.aims, { minor: young, health: o.health })
  const banned = new Set(young ? ['negativni', 'mrtvi'] : [])
  const timing = sessionTiming({ where: o.where, aims, level: o.level })
  const n = Math.max(3, Math.min(7, Math.round((o.min - 10) / 8)))
  // (v3.49) vaje ostanejo iste ves blok (4 tedne), da »naslednjič teža višja« velja za vse — nove šele z novim blokom
  // (prej so se dodatne menjale vsak teden in se vrnile šele čez 3 tedne). V 1. bloku kot prej v 1. tednu.
  const rot = Math.floor((Math.max(1, o.week) - 1) / 4) + 1 + (o.variant ?? 0)
  let order: Pattern[], fill: Pattern[]
  if (o.part === 'trebuh') {
    order = Array.from({ length: n }, (_, i) => (i === n - 1 && n >= 5 ? 'kondicija' : 'trebuh') as Pattern)
    fill = ['trebuh', 'trebuh']
  } else {
    const base = SLOTS[o.part].filter(p => p !== 'trebuh')
    const abs = SLOTS[o.part].includes('trebuh') || o.muscles.includes('trebuh') ? 1 : 0
    // prednostne mišice, ki jih ta del telesa pokrije: dodatna vaja (največ dve)
    const ext = [...new Set(o.muscles.filter(m => m !== 'trebuh' && PART_MUSCLES[o.part].includes(m)).map(m => EXTRA[m][rot % EXTRA[m].length]!))].slice(0, 2)
    // (v3.50) celo telo tudi v kratki seji: noge, potisk in poteg (prej 30 min = počep, sklece, deska — brez hrbta)
    const room = Math.max(o.part === 'celo' && n <= 3 ? 3 : 2, n - abs - ext.length)
    order = [...base.slice(0, room), ...ext, ...(abs ? ['trebuh' as Pattern] : [])]
    fill = base.slice(room)
  }
  const want = order.length
  const used = new Set<string>()
  const fam = new Set<string>()
  const chosen: ExDef[] = []
  let skipped = false
  const given = new Map<string, ExPlan>()
  // trener (Claude) s prostimi rokami: njegove vaje v njegovem vrstnem redu, z njegovimi serijami in ponovitvami —
  // izpade samo vaja, ki je ni v knjižnici ali je na tem kraju ni mogoče delati (doma ni naprav)
  // (v3.51) varovalke veljajo tudi za trenerja (C04): mladoletnemu v 1. bloku brez mrtvega dviga in negativnih zgibov,
  // brez vaj, ki obremenijo bolečino (koleno, hrbet, rama); mladoletnemu in z zdravstveno omejitvijo brez težkih serij
  // (pod 8 ponovitev → serije in ponovitve po pravilih)
  if (o.free && o.plan?.length) {
    const eq = new Set(ctx.equip)
    for (const x of o.plan) {
      const e = exById(x.id)
      if (!e || used.has(e.id) || !eq.has(e.eq) || banned.has(e.id) || (e.avoid || []).some(l => lim.includes(l))) continue
      used.add(e.id); chosen.push(e)
      const heavy = (young || !!o.health) && (repsLoggedOf(x.reps ?? '') ?? 99) < 8
      if (x.sets && !heavy) given.set(e.id, x)
    }
    if (chosen.length) return finish()
  }
  // izbor AI: samo vaje iz knjižnice, ki jih imaš na voljo (oprema, raven z eno stopnjo rezerve, brez omejitev)
  // in ki sodijo k delu telesa (glavna mišica; trebuh in kondicija povsod), največ dve iz istega vzorca
  if (o.fixed?.length) {
    const eq = new Set(ctx.equip)
    const fits = (e: ExDef) => o.part === 'celo' || e.pat === 'trebuh' || e.pat === 'kondicija' || PART_MUSCLES[o.part].includes(e.m[0]!)
    const perPat = new Map<Pattern, number>()
    for (const id of o.fixed) {
      const e = exById(id)
      if (!e || banned.has(e.id) || used.has(e.id) || fam.has(familyOf(e.id)) || !eq.has(e.eq) || e.lvl > Math.min(3, o.level + 1) || (e.avoid || []).some(l => lim.includes(l)) || !fits(e)) continue
      if ((perPat.get(e.pat) || 0) >= 2) continue
      perPat.set(e.pat, (perPat.get(e.pat) || 0) + 1)
      used.add(e.id); fam.add(familyOf(e.id)); chosen.push(e)
      if (chosen.length >= 8) break
    }
    // AI je izbral (skoraj) dovolj: njegov vrstni red; premalo za čas seje → dopolnijo pravila (samo manjkajoči vzorci)
    if (chosen.length >= Math.max(3, want - 1)) return finish()
  }
  const need = [...order]
  for (const e of chosen) { const k = need.indexOf(e.pat); if (k >= 0) need.splice(k, 1) }
  const queue = [...need, ...fill]
  // (v3.50) čas je proračun: ko je vaj po vzorcih dovolj, a je seja še krajša od dogovora (doma 30 min → 3 vaje = 22 min),
  // pridejo še vaje iz zaloge (fill), dokler je prostora za celo vajo; največ 7
  const room = () => chosen.length < 7 && strengthMinutes(doseAll(chosen), timing) + 5 <= o.min
  for (const pat of queue) {
    if (chosen.length >= want && !(chosen.length >= 3 && room())) break
    const c0 = candidates(pat, ctx).filter(e => !banned.has(e.id) && !used.has(e.id) && !fam.has(familyOf(e.id)))
    if (!c0.length) { if (chosen.length < want) skipped = true; continue }
    // (v3.49) v fitnesu naprave, palice, ročke in drog — elastika in stol (pike sklece, dipi na stolu) samo, če drugega ni
    const gymOnly = o.where === 'fitnes' && pat !== 'trebuh' && pat !== 'kondicija' ? c0.filter(e => e.eq !== 'nic' && e.eq !== 'elastike') : []
    // dodatna vaja zaradi časa (čez vzorce) v fitnesu samo z napravo ali utežjo — stol in elastika tu ne
    const c = gymOnly.length ? gymOnly : chosen.length >= want && o.where === 'fitnes' && pat !== 'trebuh' && pat !== 'kondicija' ? [] : c0
    if (!c.length) continue
    // prva (osnovna) vaja ostane ista — napredek s kilogrami; ostale se menjajo po blokih
    const pick = !chosen.length ? c[0]! : c[(rot + chosen.length) % Math.min(c.length, 3)]!
    used.add(pick.id); fam.add(familyOf(pick.id)); chosen.push(pick)
  }
  return finish()

  function doseAll(list: readonly ExDef[]): PlanExercise[] {
    return list.map(e => { const g = given.get(e.id); const d = dose(e, aims, o.level, o.light); return { name: e.name, sets: g?.sets ? (o.light ? Math.max(1, g.sets - 1) : g.sets) : d.sets, reps: g?.reps ?? d.reps, rest: g?.rest ?? d.rest } })
  }
  function finish() {
  const progressed: string[] = []
  // (v3.50) seja v času dogovora: pavze in serije dodatnih vaj, nato vaja manj (trenerjev prost načrt ostane, kot je)
  const fitted = o.free && o.plan?.length ? null : fitToMinutes(doseAll(chosen), o.min, timing)
  const exercises = chosen.filter(e => !fitted || fitted.some(x => x.name === e.name)).map(e => {
    const fit = fitted?.find(x => x.name === e.name)
    const g = given.get(e.id)
    const d0 = dose(e, aims, o.level, o.light)
    // trenerjeve serije in ponovitve; lažji teden: serija manj
    const d = g ? { sets: o.light ? Math.max(1, g.sets - 1) : g.sets, reps: g.reps, rest: g.rest ?? d0.rest } : d0
    let kg: number | null = g?.kg && e.kg ? g.kg : null
    const last = o.activities ? lastDone(e.name, o.activities) : null
    if (e.kg && last?.kg) {
      kg = last.kg
      const top = repsTopOf(d.reps), got = repsLoggedOf(last.reps)
      if (!o.light && top != null && got != null && got >= top) { kg = Math.round((kg + kgStep(e, kg)) * 2) / 2; progressed.push(e.name) }
    }
    return { name: e.name, sets: fit?.sets ?? d.sets, reps: d.reps, kg, rest: fit?.rest ?? d.rest }
  })
  return { exercises, progressed, skipped, aims }
  }
}

/**
 * Zamenjava vaje (npr. naprava je zasedena): isti vzorec, ista ali manjša raven, druga oprema iz razpoložljive.
 * (v3.50) Ko vzorec ne da ničesar (doma brez opreme: bolgarski počep, izpadni koraki, dvigi na prste), vaje z isto glavno
 * mišico (počep, dvig bokov) — kdor ga boli koleno, ima zamenjavo. Kondicija in trebuh ne nadomeščata nog.
 */
export function swapOptions(name: string, o: { where: 'fitnes' | 'doma'; equip: readonly FocusEquip[]; level: 1 | 2 | 3; limits?: string | null }, exclude: readonly string[] = []): ExDef[] {
  const e = exByName(name)
  if (!e) return []
  const ex = new Set(exclude.map(x => x.toLowerCase()))
  const ctx = { where: o.where, equip: equipFor(o.where, o.equip), level: o.level, limits: limitsOf(o.limits) }
  const ok = (x: ExDef) => x.id !== e.id && !ex.has(x.name.toLowerCase())
  const same = candidates(e.pat, ctx).filter(ok).slice(0, 4)
  if (same.length) return same
  const eq = new Set(ctx.equip)
  return EXERCISES.filter(x => ok(x) && x.pat !== 'kondicija' && x.pat !== e.pat && e.m.includes(x.m[0]!) && eq.has(x.eq) && x.lvl <= o.level && !(x.avoid || []).some(l => ctx.limits.includes(l))).slice(0, 4)
}

/* ---------- osebni rekordi in mišice ---------- */
export interface Record1 { name: string; kg: number | null; reps: number | null; e1rm: number | null; date: string }
/** Najboljša izvedba vsake vaje: s kg po ocenjenem 1RM (Epley), brez kg po ponovitvah. */
export function personalRecords(activities: readonly Activity[]): Record1[] {
  const best = new Map<string, Record1>()
  for (const a of activities) {
    if (a.sport !== 'moc' || !a.exercises) continue
    for (const x of a.exercises) {
      const reps = repsLoggedOf(x.reps)
      if (reps == null) continue
      const kg = x.kg != null && Number.isFinite(x.kg) && x.kg > 0 ? x.kg : null
      const e1rm = kg ? Math.round(kg * (1 + Math.min(reps, 12) / 30) * 2) / 2 : null
      const k = x.name.toLowerCase(), prev = best.get(k)
      const better = !prev || (e1rm != null ? (prev.e1rm ?? 0) < e1rm : prev.e1rm == null && (prev.reps ?? 0) < reps)
      if (better) best.set(k, { name: x.name, kg, reps, e1rm, date: a.date })
    }
  }
  return [...best.values()].sort((a, b) => (b.e1rm ?? 0) - (a.e1rm ?? 0) || (b.reps ?? 0) - (a.reps ?? 0))
}

/** Serije po mišicah (glavna mišica 1, ostale 0,5) — za zemljevid mišic. */
export function setsByMuscle(items: readonly { name: string; sets: number }[]): Record<Muscle, number> {
  const out: Record<Muscle, number> = { trebuh: 0, prsa: 0, hrbet: 0, ramena: 0, roke: 0, noge: 0, zadnjica: 0 }
  for (const x of items) {
    const e = exByName(x.name)
    if (!e) continue
    e.m.forEach((m, i) => { out[m] += (i === 0 ? 1 : 0.5) * Math.max(0, x.sets || 0) })
  }
  return out
}
