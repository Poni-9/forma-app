/**
 * SPANEC, HRV IN MIROVNI UTRIP z ure (Garmin → intervals.icu → FORMAI).
 * Zdravstveni podatki: samo ob izrecnem vklopu, samo na tej napravi (ne v oblak, ne v AI).
 * Iz njih je jutranja pripravljenost bolj natančna: slaba noč, HRV pod običajnim ali višji mirovni utrip → lažji dan.
 */
export interface WellnessDay {
  /** dan (lokalni ISO) — spanec in nočni HRV sta pripisana jutru, ko se zbudiš */
  date: string
  sleepH: number | null
  /** Garminova ocena spanca 0–100 */
  sleepScore: number | null
  /** nočni HRV (rMSSD, ms) */
  hrv: number | null
  /** mirovni utrip (udarci/min) */
  rhr: number | null
  /** (v3.52) povprečni stres dneva 1–100 (Garmin Connect neposredno; −1 = ni meritve → null) */
  stress?: number | null
  /** (v3.52) Body Battery ob prebujanju (ali najvišji v dnevu) 0–100 (Garmin Connect neposredno) */
  bodyBattery?: number | null
  /** (v3.52 popravki) true = bodyBattery je res ob prebujanju; sicer je najvišji v dnevu */
  bbAtWake?: boolean
}

/**
 * (v3.52) Ali so podatki z ure vklopljeni: prek intervals.icu (wellnessOn) ALI prek Garmin Connect neposredno (garmin.health).
 * Ena odločitev za vse zaslone (Danes, pripravljenost, jutranji vnos, trener brez AI).
 */
export function wellnessActive(s: { wellnessOn?: boolean; garmin?: { connected?: boolean; health?: boolean } | null } | null | undefined): boolean {
  return !!s && (!!s.wellnessOn || (!!s.garmin?.connected && s.garmin.health === true))
}

const num = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) && v > 0 ? v : null)

/** Zapis intervals.icu (Wellness) → naš dan. */
export function wellnessFromIcu(w: Record<string, unknown>): WellnessDay | null {
  const date = typeof w.id === 'string' ? w.id.slice(0, 10) : null
  if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) return null
  const secs = num(w.sleepSecs)
  const d: WellnessDay = {
    date,
    sleepH: secs ? Math.round((secs / 3600) * 10) / 10 : null,
    sleepScore: num(w.sleepScore) != null ? Math.round(num(w.sleepScore)!) : null,
    hrv: num(w.hrv) != null ? Math.round(num(w.hrv)! * 10) / 10 : null,
    rhr: num(w.restingHR) != null ? Math.round(num(w.restingHR)!) : null,
  }
  return d.sleepH == null && d.hrv == null && d.rhr == null && d.sleepScore == null ? null : d
}

export interface Baseline { mean: number; lo: number; hi: number; n: number }
export interface Recovery {
  date: string
  sleepH: number | null
  sleepScore: number | null
  hrv: number | null
  /** običajni razpon HRV (povprečje ± 1 SD na log lestvici, zadnjih 28 dni brez danes) */
  hrvBase: Baseline | null
  /** odklon današnjega HRV v SD (na log lestvici); negativno = pod običajnim */
  hrvZ: number | null
  rhr: number | null
  rhrBase: Baseline | null
  rhrDelta: number | null
  /** (v3.52) stres z Garmina — povprečni stres VČERAJŠNJEGA (celega) dne; današnji je šele delen (null, če ga ni) */
  stress?: number | null
  /** (v3.52) Body Battery z Garmina danes (null, če ga ni); bodyBatteryAtWake: true = ob prebujanju, sicer najvišji v dnevu */
  bodyBattery?: number | null
  bodyBatteryAtWake?: boolean
  /** odbitek od pripravljenosti (0–30) in razlogi, ki jih pokažemo */
  penalty: number
  reasons: string[]
}

const mean = (a: number[]) => a.reduce((s, x) => s + x, 0) / a.length
const sd = (a: number[]) => { const m = mean(a); return Math.sqrt(a.reduce((s, x) => s + (x - m) ** 2, 0) / Math.max(1, a.length - 1)) }
const addDays = (iso: string, n: number) => { const d = new Date(iso + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10) }

/**
 * Današnje okrevanje iz podatkov ure. Primerjava s TVOJIM običajnim (zadnjih 28 dni, vsaj 7 meritev):
 * HRV — ln(rMSSD) pod povprečjem za več kot 0,75 SD = pod običajnim (−8), za več kot 1,5 SD = precej (−15);
 * mirovni utrip +4 do +6 = −6, +7 ali več = −12; spanec pod 5,5 h −15, pod 6,5 h −7, 8 h ali več +4; ocena spanca pod 50 −6.
 * (v3.52) Garmin neposredno, zmerno: povprečni stres VČERAJŠNJEGA dne ≥ 50 = −4 »včeraj visok stres« (današnji je zjutraj
 * šele delen — večinoma spanec); Body Battery ob prebujanju pod 30 = −6 »Body Battery nizek«. Skupni odbitek ostane omejen na 30.
 * Brez podatkov za danes vrne null. Ročni vnos spanca (jutranji tapi) ima prednost pred uro.
 */
export function recoveryOf(days: readonly WellnessDay[] | null | undefined, today: string, manualSleepH?: number | null): Recovery | null {
  if (!days?.length) return null
  const t = days.find(d => d.date === today)
  if (!t) return null
  const from = addDays(today, -28)
  const prev = days.filter(d => d.date < today && d.date >= from)
  const reasons: string[] = []
  let pen = 0

  // HRV na log lestvici (porazdelitev rMSSD je asimetrična)
  const hv = prev.map(d => d.hrv).filter((x): x is number => x != null)
  let hrvBase: Baseline | null = null, hrvZ: number | null = null
  if (hv.length >= 7) {
    const ln = hv.map(Math.log), m = mean(ln), s = Math.max(0.04, sd(ln))
    hrvBase = { mean: Math.round(Math.exp(m)), lo: Math.round(Math.exp(m - s)), hi: Math.round(Math.exp(m + s)), n: hv.length }
    if (t.hrv != null) {
      hrvZ = Math.round(((Math.log(t.hrv) - m) / s) * 100) / 100
      if (hrvZ < -1.5) { pen += 15; reasons.push('HRV precej pod običajnim') }
      else if (hrvZ < -0.75) { pen += 8; reasons.push('HRV pod običajnim') }
    }
  }
  // mirovni utrip
  const rv = prev.map(d => d.rhr).filter((x): x is number => x != null)
  let rhrBase: Baseline | null = null, rhrDelta: number | null = null
  if (rv.length >= 7) {
    const m = mean(rv), s = sd(rv)
    rhrBase = { mean: Math.round(m), lo: Math.round(m - s), hi: Math.round(m + s), n: rv.length }
    if (t.rhr != null) {
      rhrDelta = Math.round(t.rhr - m)
      if (rhrDelta >= 7) { pen += 12; reasons.push(`mirovni utrip +${rhrDelta}`) }
      else if (rhrDelta >= 4) { pen += 6; reasons.push(`mirovni utrip +${rhrDelta}`) }
    }
  }
  // spanec z ure (če ga nisi vpisal sam)
  if (manualSleepH == null && t.sleepH != null) {
    if (t.sleepH < 5.5) { pen += 15; reasons.push('malo spanja') }
    else if (t.sleepH < 6.5) { pen += 7; reasons.push('kratek spanec') }
    else if (t.sleepH >= 8) pen -= 4
  }
  if (t.sleepScore != null && t.sleepScore < 50) { pen += 6; reasons.push('slaba kakovost spanja') }
  // (v3.52) stres in Body Battery z Garmina — zmerno (sta izpeljana iz HRV, ki je že upoštevan); stres je včerajšnji cel dan
  const stress = days.find(d => d.date === addDays(today, -1))?.stress ?? null, bb = t.bodyBattery ?? null
  if (stress != null && stress >= 50) { pen += 4; reasons.push('včeraj visok stres') }
  if (bb != null && bb < 30) { pen += 6; reasons.push('Body Battery nizek') }

  return { date: today, sleepH: t.sleepH, sleepScore: t.sleepScore, hrv: t.hrv, hrvBase, hrvZ, rhr: t.rhr, rhrBase, rhrDelta, ...(stress != null || bb != null ? { stress, bodyBattery: bb, ...(bb != null && t.bbAtWake ? { bodyBatteryAtWake: true } : {}) } : {}), penalty: Math.max(-4, Math.min(30, pen)), reasons }
}

/** Ure spanca → gumb jutranjega vnosa (≤5, 6, 7, 8, 9+). */
export function sleepBucket(h: number): 5 | 6 | 7 | 8 | 9 {
  return h < 5.5 ? 5 : h < 6.5 ? 6 : h < 7.5 ? 7 : h < 8.5 ? 8 : 9
}

/** »7 h 12 min« */
export function fmtSleep(h: number): string {
  const m = Math.round(h * 60)
  return `${Math.floor(m / 60)} h${m % 60 ? ` ${String(m % 60).padStart(2, '0')} min` : ''}`
}

/**
 * Združi dneve z ure iz dveh virov po datumu: Garmin neposredno ima prednost pred intervals.icu (isti podatki, brez
 * posrednika); polja, ki jih Garminov dan nima, ostanejo iz drugega vira. Urejeno po datumu.
 */
export function mergeWellness(icu: readonly WellnessDay[] | null | undefined, garmin: readonly WellnessDay[] | null | undefined): WellnessDay[] {
  const m = new Map<string, WellnessDay>()
  for (const d of icu || []) m.set(d.date, { ...d })
  for (const g of garmin || []) {
    const e = m.get(g.date)
    if (!e) { m.set(g.date, { ...g }); continue }
    const out: WellnessDay = { ...e }
    for (const k of ['sleepH', 'sleepScore', 'hrv', 'rhr', 'stress', 'bodyBattery'] as const) if (g[k] != null) (out as unknown as Record<string, unknown>)[k] = g[k]
    if (g.bodyBattery != null) { if (g.bbAtWake) out.bbAtWake = true; else delete out.bbAtWake }
    m.set(g.date, out)
  }
  return [...m.values()].sort((a, b) => a.date.localeCompare(b.date))
}
