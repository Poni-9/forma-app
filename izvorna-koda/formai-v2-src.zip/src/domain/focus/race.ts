import type { Profile } from '../types'

/**
 * (v3.49) TEKMA IZ BESED: »Maraton Franja 13. junija 2027, dolga trasa 156 km« → ime, datum, km. Kolesar s tekmo jo v
 * vprašalniku potrdi; ob »Dogovorjeno« postane glavni cilj (profile.event) — načrt do tekme namesto 12-tedenskega cikla.
 * Vrsta tekme ostane samodejna (raceTypeOf iz imena in km), da se ob urejanju dolžine sama prilagodi.
 */
export interface RaceGuess { name: string; date: string; distanceKm: number | null; /** (v3.50) »Glavna tekma A«, »Tekma B« iz besed */ prio?: 'A' | 'B' | 'C' }

const MONTH_FORMS: [string, number][] = [
  ['januar(?:ja)?|jan', 1], ['februar(?:ja)?|feb', 2], ['mar(?:ec|ca)|mar', 3], ['april(?:a)?|apr', 4], ['maj(?:a)?', 5], ['junij(?:a)?|jun', 6],
  ['julij(?:a)?|jul', 7], ['avgust(?:a)?|avg', 8], ['septemb(?:er|ra)|sept?', 9], ['oktob(?:er|ra)|okt', 10], ['novemb(?:er|ra)|nov', 11], ['decemb(?:er|ra)|dec', 12],
]
const MONTH_RX = new RegExp(`(?:^|[^\\p{L}\\d])(\\d{1,2})\\.?\\s*(${MONTH_FORMS.map(m => m[0]).join('|')})\\.?(?![\\p{L}])(?:\\s*(\\d{4}))?`, 'giu')
// »13. 6. 2027«, »13.6.«, »2027-06-13« (ne »1.5 h«, »3,5 km«)
const NUM_RX = /(?:^|[^\d.,])(\d{1,2})\.\s*(\d{1,2})\.(?:\s*(\d{4}))?(?!\d)/g
const ISO_RX = /(?:^|[^\d])(\d{4})-(\d{2})-(\d{2})(?!\d)/g
// beseda o tekmi v istem stavku (sicer je datum lahko kaj drugega: »do 1. junija 5 kg manj«)
const RACE_WORD = /tekm|dirk|maraton|marathon|granfondo|gran fondo|fondo|kronometer|vzpon|kriterij|franj|dolomit|[öo]tztal|race/i
/** znana imena (cela, kot jih pišejo prijavnice) */
const KNOWN: [RegExp, string][] = [[/franj/i, 'Maraton Franja'], [/dolomit/i, 'Maratona dles Dolomites'], [/[öo]tztal/i, 'Ötztaler Radmarathon']]
/** (v3.50) znana tekma z datumom (kot FRANJA_2027 v planner.ts): »Maraton Franja 2027«, »junija Franja« brez dneva */
export const KNOWN_RACE = { franja: { rx: /franj/i, name: 'Maraton Franja', date: '2027-06-13', distanceKm: 156 } } as const
const FILLER = /^(?:in|pa|ter|rad bi(?: šel| sel| odpeljal| prevozil)?(?: na)?|želim(?: na)?|hočem(?: na)?|moj cilj je|cilj je|cilj|glavni cilj|pripravljam se na|pripravljen na|grem na|tekmujem na|peljem|prijavljen(?: sem)? na|prijavil sem se na|udeležil bi se|tekma|dirka|na|je|bo|v|dne|dan)\s+/iu

const iso = (y: number, m: number, d: number) => `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`
function real(y: number, m: number, d: number): string | null {
  const t = new Date(Date.UTC(y, m - 1, d))
  return t.getUTCFullYear() === y && t.getUTCMonth() === m - 1 && t.getUTCDate() === d ? iso(y, m, d) : null
}
/** brez leta: prvi tak dan po danes */
function withYear(m: number, d: number, y: number | null, today: string): string | null {
  if (y) return real(y, m, d)
  const y0 = +today.slice(0, 4)
  const a = real(y0, m, d)
  return a && a > today ? a : real(y0 + 1, m, d)
}
const addYears = (today: string, n: number) => `${+today.slice(0, 4) + n}${today.slice(4)}`

/** stavek okoli mesta at (ločila . ! ? ; in novi vrstici; pika za številko dneva ni konec stavka) */
function sentenceAt(t: string, at: number, end: number): { from: number; to: number } {
  let from = 0
  for (let i = at - 1; i >= 0; i--) if (/[!?;\n]/.test(t[i]!) || (t[i] === '.' && !/\d/.test(t[i - 1] || ''))) { from = i + 1; break }
  let to = t.length
  for (let i = end; i < t.length; i++) if (/[!?;\n]/.test(t[i]!) || (t[i] === '.' && !/\d/.test(t[i - 1] || '') && !/\d/.test(t[i + 1] || ''))) { to = i; break }
  return { from, to }
}
/**
 * (v3.50) Besede pred datumom za to tekmo: za prejšnjim datumom ali koncem stavka (»… 2. 5. 2027. Tekma B: Kronometer«)
 * in oznaka (»Glavna tekma A:«, »Tekma B:«, »Cilj:«) posebej — prej je bilo ime »Glavna tekma A: VN Kranj«.
 */
function nearOf(t: string, sFrom: number, at: number): { near: string; prio: RaceGuess['prio'] | null } {
  const parts = t.slice(sFrom, at).split(/\d{4}\s*\.?|\d{1,2}\.\s*\d{1,2}\.|[.!?;]\s+(?=\p{Lu})/u)
  const last = (parts[parts.length - 1] || '').trim()
  const label = /^(?:[^:]*?(?:tekm|cilj|dirk)\p{L}*(?:\s+[abc])?)\s*:\s*/iu.exec(last)?.[0] ?? ''
  const m = /glavn|(?:tekm|cilj|dirk)\p{L}*\s+([abc])(?![\p{L}])|(?<![\p{L}])([abc])[\s-]?(?:tekm|cilj|dirk)/iu.exec(label || last)
  const prio = m ? ((m[1] || m[2])?.toUpperCase() as RaceGuess['prio']) ?? 'A' : null
  return { near: last.slice(label.length).trim(), prio }
}
/** ime tekme: znano ime, sicer besede tik pred datumom (»Maraton Franja 13. …«, »Kronometer Vodice, 23. 10.«) */
function nameNear(t: string, sFrom: number, at: number, sentence: string): string {
  const { near } = nearOf(t, sFrom, at)
  // (v3.50) znano ime iz besed te tekme (stavek je lahko daljši: »Tekma B: … 18. 4. 2027. Glavna tekma A: Franja …«)
  for (const [rx, n] of KNOWN) if (rx.test(near || sentence)) return n
  const raw = near.replace(/[,:–—(-]+\s*$/u, '').trim()
  let before = `${raw} `
  for (let k = 0; k < 6 && FILLER.test(before); k++) before = before.replace(FILLER, '')
  // »Dirka 5. 7.« — brez besede pred datumom ostane »Dirka«
  before = (before.trim() || raw).replace(/\s+(?:na|dne|je|bo|v|ki bo|ki je)$/iu, '').trim()
  const words = before.split(/\s+/).filter(Boolean).slice(-5)
  const name = words.join(' ').replace(/^[^\p{L}\d]+|[^\p{L}\d)]+$/gu, '')
  // ime: z veliko začetnico ali beseda o tekmi (»maraton«), ne poljuben del stavka
  return name && name.length <= 40 && (/\p{Lu}/u.test(name) || RACE_WORD.test(name)) ? name.charAt(0).toUpperCase() + name.slice(1) : ''
}

/**
 * Prva tekma z datumom v besedilu (datum po danes in do 2 leti naprej). any = odgovor na vprašanje »Katera tekma in
 * kdaj?« — tam velja vsak datum; v prosti želji samo datum ob besedi o tekmi (»maraton«, »dirka«, »Franja« …).
 */
export function raceIn(text: string | null | undefined, today: string, o: { any?: boolean } = {}): RaceGuess | null {
  // (v3.50) z več tekmami glavna (»Glavna tekma A«), sicer prva
  const all = racesIn(text, today, o)
  if (all.length) return all.find(r => r.prio === 'A') ?? all[0]!
  const t = String(text || '')
  // (v3.50) znana tekma brez dneva (»Maraton Franja 2027«, »junija Franja«): njen datum, če leto in mesec ne nasprotujeta —
  // prej null in načrt brez tekme
  const k = KNOWN_RACE.franja
  if (k.rx.test(t) && k.date > today && k.date <= addYears(today, 2)) {
    const yr = /(?<!\d)(20\d\d)(?!\d)/.exec(t)?.[1]
    const months = MONTH_FORMS.filter(([f]) => new RegExp(`(?<![\\p{L}])(?:${f})\\.?(?![\\p{L}])`, 'iu').test(t)).map(m => m[1])
    // v prosti želji samo z letom ali mesecem (»lani sem bil na Franji« ni cilj), v odgovoru o tekmi tudi samo ime
    if ((o.any || yr || months.length) && (!yr || yr === k.date.slice(0, 4)) && (!months.length || months.includes(6)) && !/(?<![\p{L}])lani(?![\p{L}])/iu.test(t)) {
      const km = /(?<![\d.,])(\d{2,3})\s*km(?![\p{L}])/u.exec(t)
      return { name: k.name, date: k.date, distanceKm: km && +km[1]! >= 20 && +km[1]! <= 400 ? +km[1]! : k.distanceKm }
    }
  }
  return null
}

/** (v3.50) Vse tekme z datumom v besedilu (prej samo prva — »Tekma B: Kronometer Vodice 18. 4.« se ni shranila). */
export function racesIn(text: string | null | undefined, today: string, o: { any?: boolean } = {}): RaceGuess[] {
  const t = String(text || '')
  if (!t.trim()) return []
  const out: RaceGuess[] = []
  const hits: { at: number; end: number; date: string }[] = []
  for (const m of t.matchAll(MONTH_RX)) {
    const lead = m[0].search(/\d/)
    const mon = MONTH_FORMS.findIndex(([f]) => new RegExp(`^(?:${f})$`, 'iu').test(m[2]!.replace(/\.$/, '')))
    const d = mon >= 0 ? withYear(mon + 1, +m[1]!, m[3] ? +m[3] : null, today) : null
    if (d) hits.push({ at: m.index! + lead, end: m.index! + m[0].length, date: d })
  }
  for (const m of t.matchAll(NUM_RX)) {
    const lead = m[0].search(/\d/)
    const d = +m[1]!, mo = +m[2]!
    const date = mo >= 1 && mo <= 12 ? withYear(mo, d, m[3] ? +m[3] : null, today) : null
    if (date && !hits.some(h => Math.abs(h.at - (m.index! + lead)) < 3)) hits.push({ at: m.index! + lead, end: m.index! + m[0].length, date })
  }
  for (const m of t.matchAll(ISO_RX)) {
    const date = real(+m[1]!, +m[2]!, +m[3]!)
    const lead = m[0].search(/\d/)
    if (date) hits.push({ at: m.index! + lead, end: m.index! + m[0].length, date })
  }
  hits.sort((a, b) => a.at - b.at)
  for (const h of hits) {
    if (h.date <= today || h.date > addYears(today, 2)) continue
    const s = sentenceAt(t, h.at, h.end)
    const sentence = t.slice(s.from, s.to)
    if (!o.any && !RACE_WORD.test(sentence)) continue
    const km = /(?<![\d.,])(\d{2,3})\s*km(?![\p{L}])(?!\s*(?:na teden|tedensko))/u.exec(sentence)
    const dist = km && +km[1]! >= 5 && +km[1]! <= 400 ? +km[1]! : null
    if (out.some(r => r.date === h.date)) continue
    const { prio } = nearOf(t, s.from, h.at)
    out.push({ name: nameNear(t, s.from, h.at, sentence) || 'Tekma', date: h.date, distanceKm: dist, ...(prio ? { prio } : {}) })
  }
  return out
}

/** vprašanje vprašalnika o tekmi (po oznaki ali besedilu) */
const Q_RACE = /katera tekma|tvoja tekma|tvoji tekmi|tvoje tekme|tekma, za katero|za katero tekmo|kdaj je tekma|datum tekme/i
/**
 * Tekma iz pogovora: odgovor na vprašanje o tekmi (»Da« = tista iz želje, »Še ne vem« = brez), sicer iz želje in
 * odgovorov (pot z AI, kjer trener vpraša po svoje).
 */
export function raceFromTalk(wish: string, qa: readonly { id?: string; q: string; a: string }[], today: string): RaceGuess | null {
  const x = qa.find(y => y.id === 'tekma' || Q_RACE.test(y.q))
  if (x) {
    const a = x.a.trim()
    if (!a || /^(?:še ne vem|se ne vem|še nimam|se nimam|ne vem|nimam|brez)/i.test(a)) return null
    if (/^(?:da|ja|tako|drži|prav)(?![\p{L}])/iu.test(a)) return raceIn(wish, today) ?? raceIn(wish, today, { any: true })
    return raceIn(a, today, { any: true }) ?? null
  }
  return raceIn([wish, ...qa.map(y => y.a)].join('. '), today)
}
/** (v3.50) Druge tekme iz pogovora (poleg glavne, ki jo vrne raceFromTalk): »Tekma B: Kronometer Vodice 18. 4. 2027«. */
export function moreRacesFromTalk(wish: string, qa: readonly { id?: string; q: string; a: string }[], today: string): RaceGuess[] {
  const main = raceFromTalk(wish, qa, today)
  if (!main) return []
  const x = qa.find(y => y.id === 'tekma' || Q_RACE.test(y.q))
  const a = x?.a.trim() ?? ''
  const src = !x ? racesIn([wish, ...qa.map(y => y.a)].join('. '), today) : /^(?:da|ja|tako|drži|prav)(?![\p{L}])/iu.test(a) ? racesIn(wish, today) : racesIn(a, today, { any: true })
  return src.filter(r => r.date !== main.date)
}

/** »Maraton Franja · 13. 6. 2027 · 156 km« */
export function raceLine(r: RaceGuess): string {
  const [y, m, d] = r.date.split('-').map(Number)
  return `${r.name} · ${d}. ${m}. ${y}${r.distanceKm ? ` · ${r.distanceKm} km` : ''}`
}
/** (v3.50) več tekem za vprašanje: »VN Kranj · 2. 5. 2027 (cilj A), Kronometer Vodice · 18. 4. 2027 (B)« — glavna prva */
export function racesLine(rs: readonly RaceGuess[]): string {
  const main = rs.find(r => r.prio === 'A') ?? rs[0]
  const order = main ? [main, ...rs.filter(r => r !== main)] : []
  return order.map(r => `${raceLine(r)}${r.prio ? ` (${r.prio === 'A' ? 'cilj A' : r.prio})` : ''}`).join(', ')
}
/** glavni cilj v profilu iz tekme (vrsta samodejna) */
export function eventOf(r: RaceGuess, prev?: Profile['event']): NonNullable<Profile['event']> {
  const same = !!prev && prev.date === r.date
  return { ...(same ? prev! : {}), name: r.name.slice(0, 60), date: r.date, distanceKm: r.distanceKm ?? (same ? prev!.distanceKm ?? null : null) }
}
