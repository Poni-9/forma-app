import { fmtDur } from '@/domain/training/load'
import type { AgreedSession, CardioKind, ExPlan, Focus, FocusAim, FocusEquip, FocusSport, Muscle, Profile, SessionPart } from '../types'
import { parseLevel } from './dose'

/**
 * DOGOVOR S TRENERJEM (»Sestaviva tvoj načrt«): uporabnik pove, kaj želi, AI vpraša naprej in predlaga realen teden,
 * dogovorita se — iz dogovora je načrt po meri (fitnes, tek, kondicija …) ali kolesarski načrt (cilj, ure, moč).
 * Tu so oznake, preverjanje (AI ali vprašalnik lahko vrne karkoli) in prenos v profil (prehrana, ure, oprema).
 * Varovalke prehrane ostanejo v nutrition/energy (nikoli pod BMR, pod 18 let brez deficita, strop deficita).
 */
export const SPORT_LABEL: Record<FocusSport, string> = { fitnes: 'Fitnes', doma: 'Vadba doma', tek: 'Tek', kolo: 'Kolo', hribi: 'Hribi' }
export const AIM_LABEL: Record<FocusAim, string> = {
  misice: 'več mišic', moc: 'več moči', kondicija: 'kondicija', vzdrzljivost: 'vzdržljivost', hujsanje: 'manj maščobe',
  definicija: 'vitka, definirana postava', zdravje: 'zdravje in gibanje', tekma: 'tekma', gibljivost: 'gibljivost',
}
export const MUSCLE_NAME: Record<Muscle, string> = { trebuh: 'trebuh', prsa: 'prsa', hrbet: 'hrbet', ramena: 'ramena', roke: 'roke', noge: 'noge', zadnjica: 'zadnjica' }
export const EQUIP_LABEL: Record<FocusEquip, string> = { fitnes: 'fitnes (naprave, palice)', utezi: 'ročke ali uteži doma', elastike: 'elastike', drog: 'drog za zgibe', nic: 'brez opreme' }
export const LEVEL_LABEL: Record<1 | 2 | 3, string> = { 1: 'začetnik', 2: 'nekaj izkušenj', 3: 'izkušen' }
export const CARDIO_LABEL: Record<CardioKind, string> = { lahko: 'lahko', intervali: 'intervali', tempo: 'tempo', dolgo: 'dolgo' }
export const PART_NAME: Record<SessionPart, string> = { celo: 'celo telo', zgornji: 'zgornji del', spodnji: 'spodnji del', potisk: 'prsa, ramena, triceps', poteg: 'hrbet in biceps', noge: 'noge in zadnjica', trebuh: 'trebuh', roke: 'roke in ramena' }

const SPORTS = Object.keys(SPORT_LABEL) as FocusSport[]
const AIMS = Object.keys(AIM_LABEL) as FocusAim[]
const MUSCLES = Object.keys(MUSCLE_NAME) as Muscle[]
const EQUIPS = Object.keys(EQUIP_LABEL) as FocusEquip[]
const PARTS = Object.keys(PART_NAME) as SessionPart[]
const CARDIO = Object.keys(CARDIO_LABEL) as CardioKind[]
/** razpon trajanja po vrsti (min) */
const MIN_RANGE: Record<FocusSport, [number, number]> = { fitnes: [25, 120], doma: [15, 90], tek: [15, 150], kolo: [30, 300], hribi: [30, 360] }
/** strop tedna: 20 h (več je za profesionalce, ne za aplikacijo) */
export const MAX_WEEK_MIN = 20 * 60

/**
 * Strategija trenerja za prikaz: vrstice brez »– «. Kalorije računa aplikacija z varovalkami in so vsak dan druge (dan
 * treninga več) — trenerjeva ena številka (»Prehrana: ~2300 kcal«) bi se tepla z obročem v Prehrani, zato jo zamenja
 * kazalec na cilj dneva. Beljakovine in ostalo ostane.
 */
export function strategyLines(strategy: string | null | undefined): string[] {
  const KCAL = /(?:okoli|približno|cca\.?|~|≈)?\s*\d[\d.,\s]{1,6}(?:\s*[–-]\s*\d[\d.,\s]{1,6})?\s*kcal(?:\s+(?:na|\/)\s*dan)?/gi
  return (strategy || '').split('\n').map(l => l.replace(/^[–-]\s*/, '').trim()).filter(Boolean)
    .map(l => l.replace(KCAL, 'kalorije po dnevu (v Prehrani; na dan treninga več)').replace(/\s{2,}/g, ' '))
}
/**
 * (v3.48) Strategija za Moj dogovor in vodnik: brez vrstice, ki ponovi teden in bloke (»2 dneva · ~3 h na teden: Kolo 2×.
 * Bloki po 4 tedne …«) — oboje je že nad njo. Starejši načrti jo imajo še shranjeno.
 */
export function dealStrategy(f: Pick<Focus, 'sessions' | 'strategy'>): string[] {
  const wl = weekLine(f)
  return strategyLines(f.strategy).filter(l => !l.startsWith(wl) && !/^Bloki po \d+ tedn/i.test(l))
}
/**
 * Teden od Claude (Blaž, 14. 10.: »AI-ju moraš dati vso svobodo, nič ne omejuj … potem pa iz odgovora naredi plan«):
 * trener odloči število dni, trajanja in vaje — aplikacija zavrne samo nesmisel (pokvarjen odgovor).
 */
const FREE_RANGE: [number, number] = [5, 720]
const FREE_WEEK_MIN = 50 * 60

const pickArr = <T extends string>(x: unknown, allowed: readonly T[], max = 9): T[] =>
  Array.isArray(x) ? [...new Set(x.map(v => String(v ?? '').trim().toLowerCase()).filter((v): v is T => (allowed as readonly string[]).includes(v)))].slice(0, max) : []
const clamp = (x: number, a: number, b: number) => Math.max(a, Math.min(b, x))
const r5 = (x: number) => Math.round(x / 5) * 5
const txt = (x: unknown, max: number) => String(x ?? '').replace(/\s+/g, ' ').trim().slice(0, max)
/** besedilo po vrsticah (strategija): presledki v vrstici stisnjeni, prelomi ostanejo */
const lines = (x: unknown, max: number) => String(x ?? '').split(/\r?\n/).map(l => l.replace(/\s+/g, ' ').trim()).filter(Boolean).join('\n').slice(0, max)

export const isStrength = (s: Pick<AgreedSession, 'type'>): boolean => s.type === 'fitnes' || s.type === 'doma'
/**
 * Seje, ki gredo v isti dan takoj po moči (»fitnes, tek v istem dnevu«): indeks kardia → indeks moči.
 * Kardio z »after« je vezan na prvo sejo moči pred njim v seznamu, ki še nima kardia (sicer na prvo prosto moč);
 * kardio z istim določenim dnem kot moč velja enako. Takih sej ni treba razporejati posebej — pridejo na konec vadbe moči.
 */
export function tailsOf(sessions: readonly AgreedSession[]): Map<number, number> {
  const out = new Map<number, number>(), used = new Set<number>()
  const take = (j: number, i: number) => { used.add(i); out.set(j, i) }
  sessions.forEach((c, j) => {
    if (isStrength(c) || !c.after) return
    let i = -1
    for (let k = j - 1; k >= 0; k--) if (isStrength(sessions[k]!) && !used.has(k)) { i = k; break }
    if (i < 0) i = sessions.findIndex((s, k) => isStrength(s) && !used.has(k))
    if (i >= 0) take(j, i)
  })
  sessions.forEach((c, j) => {
    if (isStrength(c) || out.has(j) || c.day == null) return
    const i = sessions.findIndex((s, k) => !used.has(k) && isStrength(s) && s.day === c.day)
    if (i >= 0) take(j, i)
  })
  return out
}
/** Koliko dni v tednu je vadbe (moč in kardio v istem dnevu štejeta za en dan). */
export const trainingDays = (sessions: readonly AgreedSession[]): number => sessions.length - tailsOf(sessions).size

/** Ena seja iz AI ali vprašalnika: vrsta, del telesa (moč), vrsta kardia, trajanje v razponu. */
function cleanPlan(x: unknown): ExPlan[] | null {
  if (!Array.isArray(x)) return null
  const out: ExPlan[] = []
  for (const v of x) {
    if (!v || typeof v !== 'object') continue
    const o = v as Record<string, unknown>
    const id = String(o.id ?? '')
    if (!/^[a-z0-9-]{2,24}$/.test(id) || out.some(e => e.id === id)) continue
    const sets = clamp(Math.round(Number(o.sets) || 3), 1, 12)
    const reps = txt(o.reps, 24) || '8–12'
    const rest = Number.isFinite(Number(o.rest)) && Number(o.rest) > 0 ? clamp(Math.round(Number(o.rest)), 10, 600) : null
    const kg = Number.isFinite(Number(o.kg)) && Number(o.kg) > 0 ? Math.min(500, Math.round(Number(o.kg) * 2) / 2) : null
    out.push({ id, sets, reps, rest, kg })
    if (out.length >= 16) break
  }
  return out.length ? out : null
}

export function cleanSession(x: unknown, sports: readonly FocusSport[] = [], free = false): AgreedSession | null {
  if (!x || typeof x !== 'object') return null
  const o = x as Record<string, unknown>
  const type = String(o.type ?? '').toLowerCase() as FocusSport
  if (!SPORTS.includes(type)) return null
  if (sports.length && !sports.includes(type)) return null
  const strength = type === 'fitnes' || type === 'doma'
  const part = strength ? (PARTS.includes(String(o.part ?? '').toLowerCase() as SessionPart) ? String(o.part).toLowerCase() as SessionPart : 'celo') : null
  const cardio = !strength ? (CARDIO.includes(String(o.cardio ?? '').toLowerCase() as CardioKind) ? String(o.cardio).toLowerCase() as CardioKind : 'lahko') : null
  const [lo, hi] = free ? FREE_RANGE : MIN_RANGE[type]
  const min = clamp(free ? Math.round(Number(o.min) || (strength ? 50 : 45)) : r5(Number(o.min) || (strength ? 50 : 45)), lo, hi)
  const ex = Array.isArray(o.ex) ? o.ex.map(v => String(v)).filter(v => /^[a-z0-9-]{2,24}$/.test(v)).slice(0, free ? 16 : 8) : null
  const plan = strength ? cleanPlan(o.plan) : null
  const why = txt(o.why, free ? 300 : 160) || null
  const what = txt(o.what, free ? 400 : 200) || null
  const dn = o.day == null || o.day === '' ? NaN : Number(o.day)
  const day = Number.isInteger(dn) && dn >= 0 && dn <= 6 ? dn : null
  const after = !strength && !!(o.after ?? o.poMoci)
  return { type, part, cardio, min, ...(ex && ex.length ? { ex } : {}), ...(plan ? { plan } : {}), ...(why ? { why } : {}), ...(what ? { what } : {}), ...(day != null && !after ? { day } : {}), ...(after ? { after: true } : {}) }
}

/**
 * Dogovor iz neznanega vira (AI, vprašalnik, sinhronizacija) → veljaven Focus ali null.
 * Varovalke: 1–6 dni vadbe (vsaj en dan počitka; začetnik največ 5; kardio po moči v istem dnevu je isti dan), teden do 20 h,
 * trajanje v razponu vrste, mlajši od 18 brez hujšanja.
 */
export function normalizeFocus(x: unknown, o: { age?: number | null; now?: string; by?: Focus['by'] } = {}): Focus | null {
  if (!x || typeof x !== 'object') return null
  const r = x as Record<string, unknown>
  const declared = pickArr(r.sports, SPORTS)
  // teden od Claude: trener odloči sam (brez stropov dni, trajanj in tedna — samo zaščita pred nesmislom)
  const free = (o.by || r.by) === 'claude'
  // seje veljajo tudi, če AI vrste ni naštel med »sporti« (prej so izpadle in predlog je bil neuporaben)
  let sessions = (Array.isArray(r.sessions) ? r.sessions : []).map(s => cleanSession(s, [], free)).filter((s): s is AgreedSession => !!s)
  let sports = [...new Set([...declared, ...sessions.map(s => s.type)])]
  if (!sessions.length) return null
  // raven: število ali besede (»nekaj izkušenj«); brez podatka začetnik (varno) — trener jo popravi iz odgovorov (levelFrom)
  const level = parseLevel(r.level) ?? 1
  // vsaj en dan počitka na teden (največ 6 dni vadbe), začetnik največ 5
  // dnevi brez časa: tam ni vadbe — vsaj en dan ostane prost za vadbo
  const dayList = (v: unknown) => (Array.isArray(v) ? [...new Set(v.map(Number).filter(d => Number.isInteger(d) && d >= 0 && d <= 6))].sort((a, b) => a - b) : [])
  const offDays = dayList(r.offDays).slice(0, 6)
  // kardio z istim določenim dnem kot moč je kardio po moči (»after«) — dan ima od nje; na en dan sicer ena seja
  {
    const tails = tailsOf(sessions)
    sessions = sessions.map((s, j) => (tails.has(j) ? { ...s, day: null, after: true } : s))
    const seen = new Set<number>()
    sessions = sessions.map(s => {
      if (s.day == null) return s
      if (seen.has(s.day)) return { ...s, day: null }
      seen.add(s.day); return s
    })
  }
  // določena seja na dnevu brez časa izgubi dan (razporedi se drugam); njen kardio ostane z njo
  sessions = sessions.map(s => (s.day != null && offDays.includes(s.day) ? { ...s, day: null } : s))
  // kardio po moči brez seje moči v dogovoru je navaden kardio
  if (!sessions.some(isStrength)) sessions = sessions.map(s => { if (!s.after) return s; const { after: _a, ...rest } = s; return rest })
  // največ dni vadbe: najprej izpadejo nedoločene seje (od zadnje), šele nato določene (z njihovim kardiem)
  // vsak dan (7) samo na izrecno željo in ne za začetnika; trener (coachReview) potem en dan naredi zelo lahek
  const cap = free ? 7 - offDays.length : Math.min(r.everyDay && level > 1 ? 7 : level === 1 ? 5 : 6, 7 - offDays.length)
  while (trainingDays(sessions) > cap) {
    const tails = tailsOf(sessions)
    const main = sessions.map((_, i) => i).filter(i => !tails.has(i))
    const drop = [...main].reverse().find(i => sessions[i]!.day == null) ?? main[main.length - 1]!
    const gone = new Set([drop, ...[...tails.entries()].filter(([, m]) => m === drop).map(([t]) => t)])
    sessions = sessions.filter((_, i) => !gone.has(i))
  }
  // teden do 20 h: skrajšaj najdaljše
  let tot = sessions.reduce((t, s) => t + s.min, 0)
  const maxWeek = free ? FREE_WEEK_MIN : MAX_WEEK_MIN
  while (tot > maxWeek) {
    const i = sessions.reduce((b, s, k) => (s.min > sessions[b]!.min ? k : b), 0)
    const s = sessions[i]!, lo = free ? FREE_RANGE[0] : MIN_RANGE[s.type][0], cut = Math.min(s.min - lo, tot - maxWeek, 60)
    if (cut <= 0) break
    sessions[i] = { ...s, min: s.min - r5(Math.max(5, cut)) }
    tot = sessions.reduce((t, x) => t + x.min, 0)
  }
  let aims = pickArr(r.aims, AIMS)
  const minor = o.age != null && o.age < 18
  if (minor) aims = aims.filter(a => a !== 'hujsanje')
  const equipment = pickArr(r.equipment, EQUIPS)
  const days = trainingDays(sessions)
  const minutes = clamp(r5(sessions.reduce((t, s) => t + s.min, 0) / days), 15, 300)
  const preferDays = dayList(r.preferDays).filter(d => !offDays.includes(d))
  const f: Focus = {
    v: 1, mode: 'meri', wish: txt(r.wish, 600), sports, aims, muscles: pickArr(r.muscles, MUSCLES, 7), days, minutes, level,
    equipment: equipment.length ? equipment : sports.includes('fitnes') ? ['fitnes'] : ['nic'],
    limits: txt(r.limits, 200) || null, title: txt(r.title, 40) || '', sessions,
    notes: (Array.isArray(r.notes) ? r.notes : []).map(n => txt(n, free ? 400 : 240)).filter(Boolean).slice(0, free ? 10 : 6),
    main: r.main === 'kardio' || r.main === 'moc' || r.main === 'oboje' ? r.main : null,
    everyDay: !!r.everyDay,
    said: Array.isArray(r.said) && r.said.length ? [...new Set(r.said.map(n => txt(n, 220)).filter(Boolean))].slice(-12) : null,
    keepMuscle: !!r.keepMuscle || (aims.includes('hujsanje') && (aims.includes('misice') || aims.includes('moc') || aims.includes('definicija'))),
    strategy: lines(r.strategy, free ? 4000 : 1600) || null,
    why: Array.isArray(r.why) && r.why.length ? r.why.map(n => txt(n, free ? 300 : 220)).filter(Boolean).slice(0, free ? 10 : 6) : null,
    block: Array.isArray(r.block) && r.block.length >= 4 && r.block.slice(0, 4).every(v => Number.isFinite(Number(v)) && Number(v) > 0) ? r.block.slice(0, 4).map(v => clamp(Math.round(Number(v) * 100) / 100, 0.3, 1.6)) : null,
    preferDays: preferDays.length ? preferDays : null,
    offDays: offDays.length ? offDays : null,
    at: o.now || new Date().toISOString(), by: o.by || (r.by === 'claude' ? 'claude' : r.by === 'ai' ? 'ai' : 'pravila'),
  }
  // teden od Claude je načrt (tudi kolesar s tekmo — trener je to upošteval v tednu in bloku)
  f.mode = free ? 'meri' : modeOf(f)
  if (!f.title) f.title = titleOf(f)
  return f
}

/** Delež časa na kolesu v dogovoru (0–1). */
export function bikeShare(f: Pick<Focus, 'sessions'>): number {
  const all = f.sessions.reduce((t, s) => t + s.min, 0) || 1
  return f.sessions.filter(s => s.type === 'kolo').reduce((t, s) => t + s.min, 0) / all
}
/**
 * Kolesarski načrt (periodizacija do tekme, FTP, teden dirke) samo za kolesarja s tekmo — kolo je glavnina tedna IN cilj
 * je tekma. Sicer velja dogovor, kot je (Blaž, 13. 10.: »plan je zelo dobro naredil, ko sva se pogovarjala, potem pa ga ni
 * dal v plan oziroma ga je spremenil« — kolesarski sestavljalnik je imel svoje dneve in ure).
 */
export function modeOf(f: Pick<Focus, 'sessions' | 'aims'>): Focus['mode'] {
  return bikeShare(f) >= 0.6 && f.aims.includes('tekma') ? 'kolo' : 'meri'
}
/** Načrt sledi dogovoru (seje, dnevi, trajanja) — tudi pri starih dogovorih s »kolo« brez cilja tekma. */
export const usesAgreement = (f?: Pick<Focus, 'mode' | 'aims' | 'sessions'> | null): boolean => !!f?.sessions?.length && (f.mode === 'meri' || !(f.aims || []).includes('tekma'))

/** Ime načrta, če ga AI ni dal: »Moč in kondicija«, »Fitnes in tek« … */
export function titleOf(f: Pick<Focus, 'sessions' | 'aims'>): string {
  const types = [...new Set(f.sessions.map(s => s.type))]
  const a = f.aims
  if (a.includes('definicija') || (a.includes('hujsanje') && (a.includes('misice') || a.includes('moc')))) return a.includes('kondicija') ? 'Vitko, močno, v kondiciji' : 'Vitka in močna postava'
  if (a.includes('misice')) return types.includes('tek') || types.includes('kolo') ? 'Mišice in kondicija' : 'Več mišic'
  if (a.includes('moc')) return 'Moč'
  if (a.includes('hujsanje')) return 'Manj maščobe, več energije'
  if (a.includes('kondicija') || a.includes('vzdrzljivost')) return types.length > 1 ? 'Kondicija' : `${SPORT_LABEL[types[0]!]} za kondicijo`
  return types.map(t => SPORT_LABEL[t]).join(' in ') || 'Moj načrt'
}

/** Seja z besedami: »Fitnes · zgornji del · 50 min«, »Tek · intervali · 35 min«. */
export function sessionLabel(s: AgreedSession): string {
  const what = s.part ? PART_NAME[s.part] : s.cardio ? CARDIO_LABEL[s.cardio] : ''
  return `${SPORT_LABEL[s.type]}${what ? ` · ${what}` : ''} · ${fmtDur(s.min)}`
}
/** Kratko o tednu: »5 dni · ~4,5 h na teden«. */
export function weekLine(f: Pick<Focus, 'sessions'>): string {
  const h = Math.round(f.sessions.reduce((t, s) => t + s.min, 0) / 30) / 2
  const n = trainingDays(f.sessions)
  return `${n} ${n === 1 ? 'dan' : n === 2 ? 'dneva' : n <= 4 ? 'dnevi' : 'dni'} · ~${String(h).replace('.', ',')} h na teden`
}
/** Seje skupaj po vrsti: »Fitnes 3× · Tek 2×«. */
export function mixLine(f: Pick<Focus, 'sessions'>): string {
  const n = new Map<FocusSport, number>()
  for (const s of f.sessions) n.set(s.type, (n.get(s.type) || 0) + 1)
  return [...n.entries()].map(([t, k]) => `${SPORT_LABEL[t]} ${k}×`).join(' · ')
}
export function aimsLine(f: Pick<Focus, 'aims' | 'keepMuscle' | 'muscles'>): string {
  const a = f.aims.map(x => AIM_LABEL[x])
  if (f.keepMuscle && f.aims.includes('hujsanje')) a.push('mišice ostanejo')
  if (f.muscles.length) a.push(`poudarek: ${f.muscles.map(m => MUSCLE_NAME[m]).join(', ')}`)
  return a.join(' · ')
}

/**
 * Dogovor → profil: ure, moč, oprema in prehrana (cilj, deficit, beljakovine). Deficit samo pri hujšanju in nikoli
 * pod 18 let; z ohranjanjem mišic zmernejši (350 kcal) in beljakovine 2,0 g/kg. Preostale varovalke so v prehrani.
 */
export function profileFromFocus(f: Focus, p: Profile, weekStart: string, today: string): Partial<Profile> {
  const minutes = f.sessions.reduce((t, s) => t + s.min, 0)
  const strengthN = f.sessions.filter(s => s.type === 'fitnes' || s.type === 'doma').length
  const gym = f.sessions.some(s => s.type === 'fitnes') || f.equipment.includes('fitnes')
  const bike = f.sports.includes('kolo')
  const minor = p.age != null && p.age < 18
  const lose = !minor && (f.aims.includes('hujsanje') || f.aims.includes('definicija'))
  const keepDeficit = p.goal === 'shujsati' && p.deficit != null && p.deficit > 0 ? p.deficit : null
  const goal: Profile['goal'] = lose ? 'shujsati' : bikeShare(f) >= 0.6 ? (f.aims.includes('tekma') && p.event ? 'dirka' : 'hitrejsi') : 'forma'
  const protein = f.keepMuscle || f.aims.includes('misice') || f.aims.includes('moc') || f.aims.includes('definicija') ? 2.0 : p.proteinGkg ?? null
  return {
    focus: f,
    goal,
    deficit: lose ? keepDeficit ?? (f.keepMuscle || f.aims.includes('definicija') ? 350 : 400) : 0,
    proteinGkg: protein,
    hoursPerWeek: Math.max(1, Math.round((minutes / 60) * 2) / 2),
    hoursMode: 'own',
    level: (f.level === 1 ? 1 : f.level === 2 ? 2 : 3) as Profile['level'],
    strength: { ...p.strength, on: strengthN > 0, equipment: gym ? 'gym' : f.equipment.some(e => e === 'utezi' || e === 'drog' || e === 'elastike') ? 'home' : 'none', phases: null },
    strengthDays: Math.min(4, strengthN),
    gear: { ...p.gear, ...bikeGear(f.wish, p.gear, bike), noBike: !bike, dumbbells: f.equipment.includes('utezi') || p.gear.dumbbells, pullupBar: f.equipment.includes('drog') || p.gear.pullupBar },
    cycleStart: weekStart,
    goalStart: { date: today, ftp: p.ftp ?? null, weightKg: p.weightKg ?? null },
    offSeasonWeeks: 0,
    onboardingDone: true,
  }
}

/** Izbire pri kolesu (»Kolo: trenažer doma, merilnik moči.«) → oprema za kolesarski načrt (zunaj, trenažer, vati). */
function bikeGear(wish: string, g: Profile['gear'], bike: boolean): Pick<Profile['gear'], 'bikeOutdoor' | 'trainer' | 'powerMeter'> {
  const k = /kolo: ([^.]*)/.exec(wish.toLowerCase())?.[1] ?? ''
  const trainer = /trenaž/.test(k) || g.trainer
  const outdoor = /zunaj|gorsko|gravel/.test(k) || (bike ? g.bikeOutdoor || !trainer : g.bikeOutdoor)
  return { bikeOutdoor: outdoor, trainer, powerMeter: /merilnik/.test(k) ? true : g.powerMeter ?? null }
}

/** Ali profil uporablja načrt po meri (fitnes, tek, kondicija) namesto kolesarskega. */
export const isCustom = (p: Pick<Profile, 'focus'>): boolean => usesAgreement(p.focus)
