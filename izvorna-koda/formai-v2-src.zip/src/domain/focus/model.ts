import type { AgreedSession, CardioKind, Focus, FocusAim, FocusEquip, FocusSport, Muscle, Profile, SessionPart } from '../types'

/**
 * DOGOVOR S TRENERJEM (»Sestaviva tvoj načrt«): uporabnik pove, kaj želi, AI vpraša naprej in predlaga realen teden,
 * dogovorita se — iz dogovora je načrt po meri (fitnes, tek, kondicija …) ali kolesarski načrt (cilj, ure, moč).
 * Tu so oznake, preverjanje (AI ali vprašalnik lahko vrne karkoli) in prenos v profil (prehrana, ure, oprema).
 * Varovalke prehrane ostanejo v nutrition/energy (nikoli pod BMR, pod 18 let brez deficita, strop deficita).
 */
export const SPORT_LABEL: Record<FocusSport, string> = { fitnes: 'Fitnes', doma: 'Vadba doma', tek: 'Tek', kolo: 'Kolo', hribi: 'Hribi' }
export const AIM_LABEL: Record<FocusAim, string> = {
  misice: 'več mišic', moc: 'več moči', kondicija: 'kondicija', vzdrzljivost: 'vzdržljivost', hujsanje: 'manj maščobe',
  definicija: 'vitka, definirana postava', zdravje: 'zdravje in gibanje', tekma: 'tekma', gibljivost: 'gibljivost',
}
export const MUSCLE_NAME: Record<Muscle, string> = { trebuh: 'trebuh', prsa: 'prsa', hrbet: 'hrbet', ramena: 'ramena', roke: 'roke', noge: 'noge', zadnjica: 'zadnjica' }
export const EQUIP_LABEL: Record<FocusEquip, string> = { fitnes: 'fitnes (naprave, palice)', utezi: 'ročke ali uteži doma', elastike: 'elastike', drog: 'drog za zgibe', nic: 'brez opreme' }
export const LEVEL_LABEL: Record<1 | 2 | 3, string> = { 1: 'začetnik', 2: 'nekaj izkušenj', 3: 'izkušen' }
export const CARDIO_LABEL: Record<CardioKind, string> = { lahko: 'lahko', intervali: 'intervali', tempo: 'tempo', dolgo: 'dolgo' }
export const PART_NAME: Record<SessionPart, string> = { celo: 'celo telo', zgornji: 'zgornji del', spodnji: 'spodnji del', potisk: 'prsa, ramena, triceps', poteg: 'hrbet in biceps', noge: 'noge in zadnjica', trebuh: 'trebuh', roke: 'roke in ramena' }

const SPORTS = Object.keys(SPORT_LABEL) as FocusSport[]
const AIMS = Object.keys(AIM_LABEL) as FocusAim[]
const MUSCLES = Object.keys(MUSCLE_NAME) as Muscle[]
const EQUIPS = Object.keys(EQUIP_LABEL) as FocusEquip[]
const PARTS = Object.keys(PART_NAME) as SessionPart[]
const CARDIO = Object.keys(CARDIO_LABEL) as CardioKind[]
/** razpon trajanja po vrsti (min) */
const MIN_RANGE: Record<FocusSport, [number, number]> = { fitnes: [25, 120], doma: [15, 90], tek: [15, 150], kolo: [30, 300], hribi: [60, 360] }
/** strop tedna: 20 h (več je za profesionalce, ne za aplikacijo) */
export const MAX_WEEK_MIN = 20 * 60

const pickArr = <T extends string>(x: unknown, allowed: readonly T[], max = 9): T[] =>
  Array.isArray(x) ? [...new Set(x.map(v => String(v ?? '').trim().toLowerCase()).filter((v): v is T => (allowed as readonly string[]).includes(v)))].slice(0, max) : []
const clamp = (x: number, a: number, b: number) => Math.max(a, Math.min(b, x))
const r5 = (x: number) => Math.round(x / 5) * 5
const txt = (x: unknown, max: number) => String(x ?? '').replace(/\s+/g, ' ').trim().slice(0, max)

/** Ena seja iz AI ali vprašalnika: vrsta, del telesa (moč), vrsta kardia, trajanje v razponu. */
export function cleanSession(x: unknown, sports: readonly FocusSport[]): AgreedSession | null {
  if (!x || typeof x !== 'object') return null
  const o = x as Record<string, unknown>
  const type = String(o.type ?? '').toLowerCase() as FocusSport
  if (!SPORTS.includes(type)) return null
  if (sports.length && !sports.includes(type)) return null
  const strength = type === 'fitnes' || type === 'doma'
  const part = strength ? (PARTS.includes(String(o.part ?? '').toLowerCase() as SessionPart) ? String(o.part).toLowerCase() as SessionPart : 'celo') : null
  const cardio = !strength ? (CARDIO.includes(String(o.cardio ?? '').toLowerCase() as CardioKind) ? String(o.cardio).toLowerCase() as CardioKind : 'lahko') : null
  const [lo, hi] = MIN_RANGE[type]
  const min = clamp(r5(Number(o.min) || (strength ? 50 : 45)), lo, hi)
  const ex = Array.isArray(o.ex) ? o.ex.map(v => String(v)).filter(v => /^[a-z0-9-]{2,24}$/.test(v)).slice(0, 8) : null
  const why = txt(o.why, 160) || null
  return { type, part, cardio, min, ...(ex && ex.length ? { ex } : {}), ...(why ? { why } : {}) }
}

/**
 * Dogovor iz neznanega vira (AI, vprašalnik, sinhronizacija) → veljaven Focus ali null.
 * Varovalke: 1–6 sej (ena na dan, vsaj en dan počitka; začetnik največ 5), teden do 20 h, trajanje v razponu vrste, mlajši od 18 brez hujšanja.
 */
export function normalizeFocus(x: unknown, o: { age?: number | null; now?: string; by?: Focus['by'] } = {}): Focus | null {
  if (!x || typeof x !== 'object') return null
  const r = x as Record<string, unknown>
  let sports = pickArr(r.sports, SPORTS)
  const level = ([1, 2, 3] as const).find(l => l === Number(r.level)) ?? 1
  let sessions = (Array.isArray(r.sessions) ? r.sessions : []).map(s => cleanSession(s, sports)).filter((s): s is AgreedSession => !!s)
  if (!sports.length) sports = [...new Set(sessions.map(s => s.type))]
  if (!sessions.length) return null
  // vsaj en dan počitka na teden (največ 6 sej), začetnik največ 5
  sessions = sessions.slice(0, level === 1 ? 5 : 6)
  // teden do 20 h: skrajšaj najdaljše
  let tot = sessions.reduce((t, s) => t + s.min, 0)
  while (tot > MAX_WEEK_MIN) {
    const i = sessions.reduce((b, s, k) => (s.min > sessions[b]!.min ? k : b), 0)
    const s = sessions[i]!, lo = MIN_RANGE[s.type][0], cut = Math.min(s.min - lo, tot - MAX_WEEK_MIN, 60)
    if (cut <= 0) break
    sessions[i] = { ...s, min: s.min - r5(Math.max(5, cut)) }
    tot = sessions.reduce((t, x) => t + x.min, 0)
  }
  let aims = pickArr(r.aims, AIMS)
  const minor = o.age != null && o.age < 18
  if (minor) aims = aims.filter(a => a !== 'hujsanje')
  const equipment = pickArr(r.equipment, EQUIPS)
  const days = sessions.length
  const minutes = clamp(r5(sessions.reduce((t, s) => t + s.min, 0) / days), 15, 300)
  const preferDays = Array.isArray(r.preferDays) ? [...new Set(r.preferDays.map(Number).filter(d => Number.isInteger(d) && d >= 0 && d <= 6))].sort((a, b) => a - b).slice(0, 7) : null
  const f: Focus = {
    v: 1, mode: 'meri', wish: txt(r.wish, 600), sports, aims, muscles: pickArr(r.muscles, MUSCLES, 7), days, minutes, level,
    equipment: equipment.length ? equipment : sports.includes('fitnes') ? ['fitnes'] : ['nic'],
    limits: txt(r.limits, 200) || null, title: txt(r.title, 40) || '', sessions,
    notes: (Array.isArray(r.notes) ? r.notes : []).map(n => txt(n, 240)).filter(Boolean).slice(0, 6),
    keepMuscle: !!r.keepMuscle || (aims.includes('hujsanje') && (aims.includes('misice') || aims.includes('moc') || aims.includes('definicija'))),
    strategy: txt(r.strategy, 1600) || null,
    preferDays: preferDays && preferDays.length ? preferDays : null,
    at: o.now || new Date().toISOString(), by: o.by || (r.by === 'ai' ? 'ai' : 'pravila'),
  }
  f.mode = modeOf(f)
  if (!f.title) f.title = titleOf(f)
  return f
}

/** Kolesarski načrt (periodizacija, FTP, tekme), ko je kolo glavnina tedna; sicer načrt po meri. */
export function modeOf(f: Pick<Focus, 'sessions' | 'aims'>): Focus['mode'] {
  const all = f.sessions.reduce((t, s) => t + s.min, 0) || 1
  const bike = f.sessions.filter(s => s.type === 'kolo').reduce((t, s) => t + s.min, 0)
  return bike / all >= 0.6 ? 'kolo' : 'meri'
}

/** Ime načrta, če ga AI ni dal: »Moč in kondicija«, »Fitnes in tek« … */
export function titleOf(f: Pick<Focus, 'sessions' | 'aims'>): string {
  const types = [...new Set(f.sessions.map(s => s.type))]
  const a = f.aims
  if (a.includes('definicija') || (a.includes('hujsanje') && (a.includes('misice') || a.includes('moc')))) return a.includes('kondicija') ? 'Vitko, močno, v kondiciji' : 'Vitka in močna postava'
  if (a.includes('misice')) return types.includes('tek') || types.includes('kolo') ? 'Mišice in kondicija' : 'Več mišic'
  if (a.includes('moc')) return 'Moč'
  if (a.includes('hujsanje')) return 'Manj maščobe, več energije'
  if (a.includes('kondicija') || a.includes('vzdrzljivost')) return types.length > 1 ? 'Kondicija' : `${SPORT_LABEL[types[0]!]} za kondicijo`
  return types.map(t => SPORT_LABEL[t]).join(' in ') || 'Moj načrt'
}

/** Seja z besedami: »Fitnes · zgornji del · 50 min«, »Tek · intervali · 35 min«. */
export function sessionLabel(s: AgreedSession): string {
  const what = s.part ? PART_NAME[s.part] : s.cardio ? CARDIO_LABEL[s.cardio] : ''
  return `${SPORT_LABEL[s.type]}${what ? ` · ${what}` : ''} · ${s.min} min`
}
/** Kratko o tednu: »5 dni · ~4,5 h na teden«. */
export function weekLine(f: Pick<Focus, 'sessions'>): string {
  const h = Math.round(f.sessions.reduce((t, s) => t + s.min, 0) / 30) / 2
  return `${f.sessions.length} ${f.sessions.length === 1 ? 'dan' : f.sessions.length === 2 ? 'dneva' : f.sessions.length <= 4 ? 'dnevi' : 'dni'} · ~${String(h).replace('.', ',')} h na teden`
}
/** Seje skupaj po vrsti: »Fitnes 3× · Tek 2×«. */
export function mixLine(f: Pick<Focus, 'sessions'>): string {
  const n = new Map<FocusSport, number>()
  for (const s of f.sessions) n.set(s.type, (n.get(s.type) || 0) + 1)
  return [...n.entries()].map(([t, k]) => `${SPORT_LABEL[t]} ${k}×`).join(' · ')
}
export function aimsLine(f: Pick<Focus, 'aims' | 'keepMuscle' | 'muscles'>): string {
  const a = f.aims.map(x => AIM_LABEL[x])
  if (f.keepMuscle && f.aims.includes('hujsanje')) a.push('mišice ostanejo')
  if (f.muscles.length) a.push(`poudarek: ${f.muscles.map(m => MUSCLE_NAME[m]).join(', ')}`)
  return a.join(' · ')
}

/**
 * Dogovor → profil: ure, moč, oprema in prehrana (cilj, deficit, beljakovine). Deficit samo pri hujšanju in nikoli
 * pod 18 let; z ohranjanjem mišic zmernejši (350 kcal) in beljakovine 2,0 g/kg. Preostale varovalke so v prehrani.
 */
export function profileFromFocus(f: Focus, p: Profile, weekStart: string, today: string): Partial<Profile> {
  const minutes = f.sessions.reduce((t, s) => t + s.min, 0)
  const strengthN = f.sessions.filter(s => s.type === 'fitnes' || s.type === 'doma').length
  const gym = f.sessions.some(s => s.type === 'fitnes') || f.equipment.includes('fitnes')
  const bike = f.sports.includes('kolo')
  const minor = p.age != null && p.age < 18
  const lose = !minor && (f.aims.includes('hujsanje') || f.aims.includes('definicija'))
  const keepDeficit = p.goal === 'shujsati' && p.deficit != null && p.deficit > 0 ? p.deficit : null
  const goal: Profile['goal'] = lose ? 'shujsati' : f.mode === 'kolo' ? (f.aims.includes('tekma') && p.event ? 'dirka' : 'hitrejsi') : 'forma'
  const protein = f.keepMuscle || f.aims.includes('misice') || f.aims.includes('moc') || f.aims.includes('definicija') ? 2.0 : p.proteinGkg ?? null
  return {
    focus: f,
    goal,
    deficit: lose ? keepDeficit ?? (f.keepMuscle || f.aims.includes('definicija') ? 350 : 400) : 0,
    proteinGkg: protein,
    hoursPerWeek: Math.max(1, Math.round((minutes / 60) * 2) / 2),
    hoursMode: 'own',
    level: (f.level === 1 ? 1 : f.level === 2 ? 2 : 3) as Profile['level'],
    strength: { ...p.strength, on: strengthN > 0, equipment: gym ? 'gym' : f.equipment.some(e => e === 'utezi' || e === 'drog' || e === 'elastike') ? 'home' : 'none', phases: null },
    strengthDays: Math.min(4, strengthN),
    gear: { ...p.gear, bikeOutdoor: bike ? p.gear.bikeOutdoor || !p.gear.trainer : p.gear.bikeOutdoor, noBike: !bike, dumbbells: f.equipment.includes('utezi') || p.gear.dumbbells, pullupBar: f.equipment.includes('drog') || p.gear.pullupBar },
    cycleStart: weekStart,
    goalStart: { date: today, ftp: p.ftp ?? null, weightKg: p.weightKg ?? null },
    offSeasonWeeks: 0,
    onboardingDone: true,
  }
}

/** Ali profil uporablja načrt po meri (fitnes, tek, kondicija) namesto kolesarskega. */
export const isCustom = (p: Pick<Profile, 'focus'>): boolean => p.focus?.mode === 'meri' && !!p.focus.sessions?.length
