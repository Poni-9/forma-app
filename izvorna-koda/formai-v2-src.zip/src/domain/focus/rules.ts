import type { AgreedSession, Focus, FocusAim, FocusEquip, FocusSport, Muscle, SessionPart } from '../types'
import { normalizeFocus, titleOf, weekLine, mixLine } from './model'
import { DAY_OPTS, atDays } from './choices'
import type { QA, QuestionsOut } from '../ai/focusAi'

/**
 * REZERVA BREZ AI: ko AI ne odgovori (ni povezave, poln dnevni limit, napaka), gre pogovor naprej z vprašanji in
 * predlogom po pravilih — začetek načrta mora vedno delati. Pogajanje brez AI razume hitre odgovore (več, manj …).
 */
export function ruleQuestions(wish: string): QuestionsOut {
  const w = wish.toLowerCase()
  const qs: QuestionsOut['questions'] = [
    { id: 'dni', text: 'Koliko dni na teden lahko treniraš?', multi: false, options: ['2', '3', '4', '5', '6'], other: false },
    { id: 'cas', text: 'Koliko časa imaš za eno vadbo?', multi: false, options: ['30 min', '45 min', '60 min', '90 min'], other: false },
    { id: 'kje', text: 'Kje boš vadil?', multi: true, options: ['V fitnesu', 'Doma brez opreme', 'Doma z ročkami', 'Doma z elastikami', 'Imam drog za zgibe'], other: false },
    { id: 'kardio', text: 'Kateri kardio ti ustreza?', multi: true, options: ['Tek', 'Kolo', 'Hribi', 'Brez kardia'], other: false },
    { id: 'izkusnje', text: 'Koliko izkušenj imaš z vadbo?', multi: false, options: ['Začenjam', 'Nekaj izkušenj', 'Treniram redno'], other: false },
  ]
  if (!/(mišic|misic|moč|moc|hujš|husj|shujš|kondic|vzdržlj|definic|vitk|six|trebuh)/.test(w)) qs.push({ id: 'cilji', text: 'Kaj ti je najpomembnejše?', multi: true, options: ['Več mišic', 'Več moči', 'Manj maščobe', 'Kondicija', 'Zdravje'], other: false })
  qs.push({ id: 'nedni', text: 'Kateri dnevi ti zagotovo ne gredo?', multi: true, options: [...DAY_OPTS, 'Vsi gredo'], other: false })
  qs.push({ id: 'poskodbe', text: 'Te kaj boli ali imaš poškodbo?', multi: true, options: ['Ne', 'Koleno', 'Hrbet', 'Rama'], other: true })
  return { understood: '', questions: qs.slice(0, 8), enough: true }
}

export { DAY_OPTS }
// cele besede (»ob torkih«, »v četrtek«, »sobote«); »torej«, »petkrat«, »četrt ure«, »sredi tedna« niso dnevi
const END = '(?:a|u|om|ih|i|e|ov|ah)?'
const word = (w: string) => new RegExp(`(?:^|[^\\p{L}])(?:${w})(?![\\p{L}])`, 'gu')
const DAY_WORD = [`ponedelj\\p{L}*`, `tor(?:ek|k${END})`, `sred(?:a|o|e|ah|ami)`, `(?:č|c)etrt(?:ek|k${END})`, `pet(?:ek|k${END})`, `sobot\\p{L}*`, `nedelj\\p{L}*`].map(word)
// okrajšave iz izbire (»Tor, Čet«) — v prostem besedilu ne, ker je »pet« tam navadno število
const DAY_ABBR = ['pon', 'tor', 'sre', '(?:č|c)et', 'pet', 'sob', 'ned'].map(w => word(`${w}\\.?`))
const WEEKEND = word('vikend\\p{L}*')
function dayHits(t: string, short: boolean): { d: number; at: number }[] {
  const out: { d: number; at: number }[] = []
  const scan = (r: RegExp, ds: number[]) => { r.lastIndex = 0; for (let m = r.exec(t); m; m = r.exec(t)) ds.forEach(d => out.push({ d, at: m!.index })) }
  DAY_WORD.forEach((r, i) => scan(r, [i]))
  if (short) DAY_ABBR.forEach((r, i) => scan(r, [i]))
  scan(WEEKEND, [5, 6])
  return out
}
/** »Tor, Čet« (izbira, short) ali »ob torkih in četrtkih«, »čez vikend« → [1, 3] … (0 = pon … 6 = ned) */
export function daysIn(text: string, short = false): number[] {
  return [...new Set(dayHits(text.toLowerCase(), short).map(h => h.d))].sort((a, b) => a - b)
}
const NO_TIME = /ne (?:morem|gre|utegnem|pridem|bom mogl\p{L}*)|nimam (?:časa|casa)|ni (?:časa|casa)|nisem (?:doma|prost\p{L}*)|zaseden\p{L}*/gu
const CAN = /(?:^|[^\p{L}])(?:lahko|gre|imam (?:čas|cas)\p{L}*|sem prost\p{L}*|ustreza)(?![\p{L}])/gu
/**
 * Dnevi brez časa iz besed: dan velja za »ne gre«, če mu je v istem stavku bližje »ne morem / nimam časa« kot »lahko«
 * (»ob torkih ne morem, ob petkih pa lahko« → [1]; »ob petkih pa ne morem« → [4]).
 */
export function offDaysIn(text: string): number[] {
  const out = new Set<number>()
  for (const s of text.toLowerCase().split(/[.;!?\n]+/)) {
    const no = [...s.matchAll(NO_TIME)].map(m => ({ a: m.index!, b: m.index! + m[0].length }))
    if (!no.length) continue
    const yes = [...s.matchAll(CAN)].map(m => m.index!).filter(i => !no.some(n => i >= n.a && i < n.b))
    const dist = (at: number, xs: number[]) => Math.min(Infinity, ...xs.map(x => Math.abs(x - at)))
    for (const h of dayHits(s, false)) if (dist(h.at, no.map(n => n.a)) <= dist(h.at, yes)) out.add(h.d)
  }
  return [...out].sort((a, b) => a - b)
}
const byId = (qa: readonly QA[], id: string) => qa.filter(x => x.id === id || x.q === id)
const has = (qa: readonly QA[], id: string, rx: RegExp) => byId(qa, id).some(x => rx.test(x.a.toLowerCase()))
const ans = (qa: readonly QA[], id: string) => byId(qa, id)[0]?.a ?? ''

/** Cilji in mišice iz besed (»six pack«, »vitka postava«, »ne izgubiti mišic«, »samo zgornji del«). */
export function wishSignals(wish: string): { aims: FocusAim[]; muscles: Muscle[]; sports: FocusSport[]; keepMuscle: boolean; upperOnly: boolean } {
  const w = wish.toLowerCase()
  const aims = new Set<FocusAim>()
  const muscles = new Set<Muscle>()
  const sports = new Set<FocusSport>()
  if (/hujš|husj|shujš|kilogram|maščob|mascob|kil dol|izgubit/.test(w)) aims.add('hujsanje')
  if (/vitk|definic|lin\b|lean|six|šest|sixpack|trebuš/.test(w)) aims.add('definicija')
  if (/mišic|misic|masa|nabit|bicep|mišičast/.test(w)) aims.add('misice')
  if (/moč\b|moc\b|močn|mocn|močan|mocan|težk|tezk/.test(w)) aims.add('moc')
  if (/kondic|sapa|vzdrž|vzdrz|kardio|sopih/.test(w)) aims.add('kondicija')
  if (/zdrav|gibanj|hrbet me|počutj|pocutj/.test(w)) aims.add('zdravje')
  if (/six|šest|sixpack|trebuh|trebuš|trebus/.test(w)) muscles.add('trebuh')
  if (/rok|bicep|tricep/.test(w)) muscles.add('roke')
  if (/prs/.test(w)) muscles.add('prsa')
  if (/ramen|ramena/.test(w)) muscles.add('ramena')
  if (/hrbet|hrbt/.test(w) && !/boli|bolečin/.test(w)) muscles.add('hrbet')
  if (/zadnjic|rit\b|glute/.test(w)) muscles.add('zadnjica')
  if (/\bnog/.test(w) && !/brez nog/.test(w)) muscles.add('noge')
  if (/fitnes|fitnes|gym|teretan|uteži|utezi|ročk|rock/.test(w)) sports.add('fitnes')
  if (/\btek|teč|tec[ie]|tekač|run/.test(w)) sports.add('tek')
  if (/kolo|koles|bicikl/.test(w)) sports.add('kolo')
  if (/hrib|pohod|planin/.test(w)) sports.add('hribi')
  if (/doma\b|brez opreme/.test(w)) sports.add('doma')
  const keepMuscle = /ne izgub|nočem izgub|nocem izgub|ohran|obdrž|obdrz/.test(w) || (aims.has('hujsanje') && (aims.has('misice') || aims.has('moc') || aims.has('definicija')))
  const upperOnly = /samo zgornj|le zgornj|zgornji del|samo roke|samo trebuh/.test(w)
  return { aims: [...aims], muscles: [...muscles], sports: [...sports], keepMuscle, upperOnly }
}

/** Predlog po pravilih iz odgovorov in besed. */
export function ruleProposal(wish: string, qa: readonly QA[], age?: number | null): { reply: string; focus: Focus; quick: string[] } {
  const sig = wishSignals(wish)
  const n = Math.max(2, Math.min(6, parseInt(ans(qa, 'dni'), 10) || 3))
  const min = Math.max(25, Math.min(90, parseInt(ans(qa, 'cas'), 10) || 45))
  const level: 1 | 2 | 3 = has(qa, 'izkusnje', /redno/) ? 3 : has(qa, 'izkusnje', /nekaj/) ? 2 : 1
  const gym = has(qa, 'kje', /fitnes/) || sig.sports.includes('fitnes')
  const equipment: FocusEquip[] = [...new Set<FocusEquip>([
    ...(gym ? ['fitnes' as const] : []), ...(has(qa, 'kje', /ročk|rock/) ? ['utezi' as const] : []),
    ...(has(qa, 'kje', /elastik/) ? ['elastike' as const] : []), ...(has(qa, 'kje', /drog/) ? ['drog' as const] : []), 'nic' as const,
  ])]
  const cardioTypes: FocusSport[] = has(qa, 'kardio', /brez/) ? [] : ([['tek', /tek/], ['kolo', /kolo/], ['hribi', /hrib/]] as [FocusSport, RegExp][]).filter(([, rx]) => has(qa, 'kardio', rx)).map(([s]) => s)
  const cardio = cardioTypes.length ? cardioTypes : sig.sports.filter(s => s === 'tek' || s === 'kolo' || s === 'hribi')
  const aims = new Set<FocusAim>(sig.aims)
  if (has(qa, 'cilji', /mišic/)) aims.add('misice')
  if (has(qa, 'cilji', /moč/)) aims.add('moc')
  if (has(qa, 'cilji', /maščob/)) aims.add('hujsanje')
  if (has(qa, 'cilji', /kondic/)) aims.add('kondicija')
  if (has(qa, 'cilji', /zdrav/)) aims.add('zdravje')
  if (!aims.size) aims.add('zdravje')
  const injuries = ['Koleno', 'Hrbet', 'Rama'].filter(x => has(qa, 'poskodbe', new RegExp(x.toLowerCase()))).join(', ').toLowerCase()
  // dnevi brez časa (iz vprašalnika ali iz besed »ob torkih ne morem«)
  const offDays = [...new Set([...daysIn(ans(qa, 'nedni'), true), ...offDaysIn(wish)])].slice(0, 5)
  // kardio: pri kondiciji ali hujšanju 1–2 na teden (od 4 dni dalje 2), sicer 1 od 3 dni dalje
  const wantCardio = cardio.length > 0
  const nc = !wantCardio ? 0 : (aims.has('kondicija') || aims.has('hujsanje')) ? (n >= 4 ? 2 : 1) : n >= 3 ? 1 : 0
  const ns = Math.max(sig.sports.length && !sig.sports.some(s => s === 'fitnes' || s === 'doma') && wantCardio ? 0 : 1, n - nc)
  const where: 'fitnes' | 'doma' = gym ? 'fitnes' : 'doma'
  const parts: SessionPart[] = sig.upperOnly
    ? (['zgornji', 'potisk', 'poteg', 'zgornji'] as SessionPart[]).slice(0, ns)
    : ns === 1 ? ['celo'] : ns === 2 ? (level === 1 ? ['celo', 'celo'] : ['zgornji', 'spodnji']) : ns === 3 ? (level === 1 ? ['celo', 'celo', 'celo'] : ['potisk', 'noge', 'poteg']) : ['zgornji', 'spodnji', 'potisk', 'poteg'].slice(0, ns) as SessionPart[]
  const sessions: AgreedSession[] = parts.map(part => ({ type: where, part, min }))
  for (let k = 0; k < nc; k++) {
    const type = cardio[k % cardio.length]!
    sessions.push({ type, cardio: type === 'hribi' ? 'lahko' : aims.has('kondicija') && k === 0 ? 'intervali' : 'lahko', min: type === 'kolo' ? Math.max(45, min) : type === 'hribi' ? 150 : Math.max(25, Math.min(50, min - 10)) })
  }
  const focus = normalizeFocus({ wish, sports: [...new Set(sessions.map(s => s.type))], aims: [...aims], muscles: sig.muscles, level, equipment, limits: injuries || null, keepMuscle: sig.keepMuscle, sessions, offDays, notes: notesFor([...aims], sig.muscles) }, { age, by: 'pravila' })!
  focus.title = titleOf(focus)
  const off = focus.offDays?.length ? ` ${atDays(focus.offDays).replace(/^o/, 'O')} ni vadbe.` : ''
  const reply = `Predlagam ${weekLine(focus)}: ${mixLine(focus)}.${aims.has('hujsanje') && sig.keepMuscle ? ' Moč ostane težka, da med hujšanjem obdržiš mišice.' : ''}${off} Če želiš več ali manj, povej.`
  return { reply, focus, quick: QUICK }
}
const QUICK = ['Več kardia', 'Več moči', 'Manj dni', 'Več dni', 'Krajše vadbe']

export function notesFor(aims: readonly FocusAim[], muscles: readonly Muscle[]): string[] {
  const out: string[] = []
  if (muscles.includes('trebuh') || aims.includes('definicija')) out.push('Trebušne mišice se vidijo pri nizkem deležu maščobe — vaje jih okrepijo, vidnost pa prinese prehrana.')
  if (aims.includes('hujsanje')) out.push('Hujšanje: zmeren deficit in dovolj beljakovin — tako gre dol maščoba, ne mišice.')
  if (aims.includes('kondicija')) out.push('Kondicija raste najhitreje z mešanico lahkega kardia in kratkih intervalov.')
  return out
}

/** Pogajanje brez AI: hitri odgovori spremenijo teden po pravilih. Vrne null, če odgovora ne razume. */
export function ruleAdjust(f: Focus, say: string, age?: number | null): Focus | null {
  const t = say.toLowerCase()
  let s = f.sessions.map(x => ({ ...x }))
  let off = [...(f.offDays || [])]
  const strength = (x: AgreedSession) => x.type === 'fitnes' || x.type === 'doma'
  const where = s.find(strength)?.type ?? (f.equipment.includes('fitnes') ? 'fitnes' : 'doma')
  const cardioType = (s.find(x => !strength(x))?.type ?? (f.sports.find(x => x === 'tek' || x === 'kolo' || x === 'hribi') || 'tek')) as FocusSport
  // »ob torkih ne morem«, »v petek nimam časa« → prost dan (seje ostanejo, razporedijo se na druge dni)
  const noDays = offDaysIn(t), canDays = /(lahko|gre|imam čas)/.test(t) && !noDays.length ? daysIn(t) : []
  if (noDays.length) off = [...new Set([...off, ...noDays])]
  else if (canDays.length && canDays.some(d => off.includes(d))) off = off.filter(d => !canDays.includes(d))
  else if (/več kardi|vec kardi/.test(t)) { const i = s.findIndex(strength); if (s.length >= 7 && i >= 0) s[i] = { type: cardioType, cardio: 'lahko', min: 40 }; else s.push({ type: cardioType, cardio: 'lahko', min: 40 }) }
  else if (/več moč|vec moc/.test(t)) { const i = s.findIndex(x => !strength(x)); if (i >= 0 && s.length >= 5) s[i] = { type: where, part: 'celo', min: 50 }; else s.push({ type: where, part: 'celo', min: 50 }) }
  else if (/manj dni|manj vadb/.test(t)) { if (s.length > 1) s = s.slice(0, -1) }
  else if (/več dni|vec dni/.test(t)) { if (s.length < 7) s.push(s.length % 2 ? { type: cardioType, cardio: 'lahko', min: 40 } : { type: where, part: 'celo', min: 50 }) }
  else if (/krajš|krajs/.test(t)) s = s.map(x => ({ ...x, min: Math.max(20, x.min - 10) }))
  else if (/daljš|daljs/.test(t)) s = s.map(x => ({ ...x, min: x.min + 10 }))
  else if (/nog/.test(t)) { const i = s.findIndex(x => strength(x) && x.part !== 'spodnji' && x.part !== 'noge'); if (i >= 0) s[i] = { ...s[i]!, part: 'noge' } }
  else if (/brez tek/.test(t)) s = s.filter(x => x.type !== 'tek')
  else return null
  if (!s.length) return null
  const next = normalizeFocus({ ...f, sessions: s, sports: [...new Set(s.map(x => x.type))], offDays: off }, { age, by: f.by })
  if (next) { next.title = f.title; next.notes = f.notes }
  return next
}

/** Strategija brez AI. */
export function ruleStrategy(f: Focus, n: { kcal: number | null; proteinG: number | null; deficit: number }): string {
  const out = [`– ${weekLine(f)}: ${mixLine(f)}. Bloki po 4 tedne: 3 tedne rast, nato lažji teden.`]
  if (f.sessions.some(s => s.type === 'fitnes' || s.type === 'doma')) out.push('– Moč: vpisuj kilograme — ko narediš vse ponovitve, je naslednjič teža višja. Tako mišice dobijo razlog, da ostanejo in rastejo.')
  if (f.sessions.some(s => s.type === 'tek' || s.type === 'kolo')) out.push('– Kardio: večinoma lahko, en hitrejši trening na teden — kondicija raste brez izčrpanosti.')
  if (n.kcal) out.push(`– Prehrana: ~${n.kcal} kcal na dan${n.deficit ? ` (deficit ${n.deficit} kcal)` : ''}${n.proteinG ? `, beljakovine ~${n.proteinG} g` : ''} — številke so v Prehrani in se prilagajajo treningu.`)
  out.push('– Spanec 7–9 h: ko spiš manj, se napredek ustavi prej kot pri izpuščenem treningu.')
  out.push(f.aims.includes('hujsanje') ? '– Pričakuj 0,25–0,75 kg na teden; prve 4 tedne se pozna predvsem moč in energija.' : '– Prvi 4 tedni: navada in tehnika; po 8–12 tednih se napredek pozna na kilogramih in kondiciji.')
  return out.join('\n')
}
