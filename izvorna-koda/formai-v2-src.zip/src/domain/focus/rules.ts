import type { AgreedSession, CardioKind, Focus, FocusAim, FocusEquip, FocusSport, Muscle, Profile, SessionPart } from '../types'
import { normalizeFocus, titleOf, weekLine, mixLine, isStrength, tailsOf, trainingDays, usesAgreement, fastCardio, kgStrength, STRAT_REPS, STRAT_EASY, healthNote } from './model'
import { DAY_OPTS, DAY_SHORT, atDays, otherSportDays, otherSportIn } from './choices'
import { levelFrom, minutesRange, minutesIn as perSessionIn, weekMinutesIn, rangeIn, explicitDays, explicitCounts, ftpIn } from './dose'
import { raceIn, racesIn, raceLine, racesLine, raceFromTalk, KNOWN_RACE } from './race'
import { weekWords, pinsWords, RUN_WALK, runWalkFrom } from '../training/focusPlan'
import { limitsOf, healthOf, healthSaid, HEALTH_SAY } from '../training/exercises'
import { fmtStep } from '../training/workout'
import type { QA, QuestionsOut } from '../ai/focusAi'

/**
 * REZERVA BREZ AI: ko AI ne odgovori (ni povezave, poln dnevni limit, napaka), gre pogovor naprej z vprašanji in
 * predlogom po pravilih — začetek načrta mora vedno delati. Pogajanje brez AI razume hitre odgovore (več, manj …).
 */
export function ruleQuestions(wish: string, o: { avail?: readonly number[] | null; today?: string | null; event?: Profile['event']; ftp?: number | null } = {}): QuestionsOut {
  // po tem, kar je izbral (Blaž, 13. 10.: »za vse — kolesar dobi vprašanja o kolesu, ne o fitnesu«)
  const w = wish.toLowerCase()
  const sig = wishSignals(wish)
  const has = (x: FocusSport) => sig.sports.includes(x)
  const unsure = /še ne vem/.test(w) || !sig.sports.length
  const strength = has('fitnes') || has('doma') || sig.aims.some(a => a === 'misice' || a === 'moc')
  const onlyCardio = !strength && !unsure
  const engine = sig.aims.some(a => a === 'kondicija' || a === 'hujsanje' || a === 'vzdrzljivost' || a === 'tekma')
  const nAvail = o.avail?.length ? Math.min(6, o.avail.length) : 6
  const qs: QuestionsOut['questions'] = []
  // (v3.49) kolesar s tekmo: katera in kdaj — napisano tekmo samo potrdi (prej je ni vprašal ne shranil: 12-tedenski cikel
  // brez cilja); glavni cilj, ki ga že ima, ostane
  const today = o.today ?? null
  // (v3.50) tudi tekač in pohodnik (prej samo kolesar: »polmaraton 25. 10. 2026« ni bil ne vprašan ne shranjen); več
  // tekem iz istega stavka skupaj (»Glavna tekma A: … Tekma B: …« — prej se je druga izgubila); tekač brez datuma samo,
  // ko izrecno piše o tekmi (»Polmaraton ali več« je dolžina teka, ne tekma)
  const r = today ? raceIn(wish, today) : null
  const rs = today ? racesIn(wish, today) : []
  const askRace = has('kolo') || !!r || /tekm|dirk/.test(w.replace(/tek: [^.]*\./, ''))
  if ((has('kolo') || has('tek') || has('hribi')) && askRace && sig.aims.includes('tekma') && today && !(o.event?.date && o.event.date > today)) {
    qs.push(rs.length > 1
      ? { id: 'tekma', text: `${rs.length === 2 ? 'Tvoji tekmi' : 'Tvoje tekme'}: ${racesLine(rs)}. Je prav?`, multi: false, options: ['Da', 'Še nimam datuma'], other: true }
      : r
      ? { id: 'tekma', text: `Tvoja tekma: ${raceLine(r)}. Je prav?`, multi: false, options: ['Da', 'Še nimam datuma'], other: true }
      : { id: 'tekma', text: 'Katera tekma in kdaj? (npr. Maraton Franja, 13. 6. 2027)', multi: false, options: ['Še ne vem'], other: true })
  }
  // (v3.50) merilnik moči brez FTP v besedah: vprašaj (prej »Moč (FTP) še ne poznam« in načrt v % FTP brez vatov)
  if (has('kolo') && /merilnik/.test(w) && !o.ftp && ftpIn(wish) == null) qs.push({ id: 'ftp', text: 'Kakšen je tvoj FTP (20-minutni test ali ocena ure)?', multi: false, options: ['Ne vem — izmeriva ga'], other: true })
  const dayOpts = ['2', '3', '3–4', '4', '4–5', '5', '6'].filter(x => +x.slice(-1) <= nAvail)
  // (v3.49) brez vprašanj z eno samo možnostjo ali s tem, kar je že napisal (»dvakrat na teden po 30 minut«)
  if (dayOpts.length > 1 && explicitDays(wish) == null) qs.push({ id: 'dni', text: o.avail?.length ? `Koliko od teh ${o.avail.length} dni bi res treniral?` : 'Koliko dni na teden lahko treniraš?', multi: false, options: dayOpts, other: false })
  if (onlyCardio && (has('kolo') || has('hribi'))) { if (!weekMinutesIn(wish) && !perSessionIn(wish)) qs.push({ id: 'ure', text: 'Koliko ur na teden imaš za to?', multi: false, options: ['2–3 h', '4–5 h', '6–8 h', '9–12 h'], other: true }) }
  else if (!perSessionIn(wish)) qs.push({ id: 'cas', text: 'Koliko časa imaš za eno vadbo?', multi: false, options: ['30 min', '45 min', '1 h', '1 h 30 min', ...(has('kolo') ? ['2 h ali več'] : [])], other: true })
  if (!levelFrom(wish)) qs.push({ id: 'izkusnje', text: 'Koliko že treniraš?', multi: false, options: ['Začenjam', 'Občasno', 'Redno, več let'], other: false })
  if (unsure) qs.push({ id: 'kardio', text: 'Kaj ti je dostopno ali bi rad poskusil?', multi: true, options: ['Fitnes', 'Vadba doma', 'Tek', 'Kolo', 'Hoja ali pohod'], other: false })
  if (has('doma')) qs.push({ id: 'kje', text: 'Kakšno opremo imaš doma?', multi: true, options: ['Nič', 'Ročke', 'Elastike', 'Drog za zgibe'], other: false })
  else if (strength && !has('fitnes') && !unsure) qs.push({ id: 'kje', text: 'Kje boš delal moč?', multi: true, options: ['V fitnesu', 'Doma brez opreme', 'Doma z ročkami', 'Imam drog za zgibe'], other: false })
  // (v3.50) poudarek preskoči samo postava, ki že pove del telesa (six pack, samo zgornji del) — prej vsaka (»vitka in
  // močna« ni mogla izbrati nog in zadnjice)
  if (has('fitnes') && !/postava: [^.]*(?:six pack|samo zgornji)/.test(w)) qs.push({ id: 'poudarek', text: 'Na kaj se pri moči osredotočiš?', multi: true, options: ['Celo telo', 'Zgornji del', 'Noge in zadnjica', 'Trebuh'], other: false })
  if (has('kolo') && !/kolo: /.test(w)) qs.push({ id: 'kolo', text: 'Kje kolesariš med tednom?', multi: false, options: ['Zunaj', 'Na trenažerju', 'Oboje'], other: false })
  if (has('kolo') && !sig.aims.includes('tekma')) qs.push({ id: 'kolocilj', text: 'Imaš na kolesu kakšen cilj?', multi: false, options: ['Samo forma', 'Dolga tura', 'Maraton ali granfondo', 'Dirka'], other: true })
  if (has('tek') && !/tek: /.test(w)) qs.push({ id: 'km', text: 'Koliko km na teden zdaj pretečeš?', multi: false, options: ['Še ne tečem', 'Do 10 km', '10–25 km', '25–40 km', 'Več kot 40 km'], other: false })
  // (v3.50) kolesar brez tekme v želji: katera in kdaj (prej »Dirka« ali »Maraton« brez datuma — načrt brez tekme)
  // (v3.50) »nimam tekme«, »ne tekmujem«: brez vprašanja o tekmi
  if (has('kolo') && !sig.aims.includes('tekma') && !sig.noRace && today && !(o.event?.date && o.event.date > today)) qs.push({ id: 'tekma', text: 'Imaš tekmo? Katera in kdaj? (npr. Maraton Franja, 13. 6. 2027)', multi: false, options: ['Ne', ...(today < KNOWN_RACE.franja.date ? ['Maraton Franja, 13. 6. 2027'] : [])], other: true })
  if (!unsure && !has('kolo') && !has('tek') && !has('hribi') && engine) qs.push({ id: 'kardio', text: 'Kateri kardio ti ustreza?', multi: true, options: ['Tek', 'Kolo', 'Hoja ali pohod', 'Brez kardia'], other: false })
  if (!sig.aims.length) qs.push({ id: 'cilji', text: 'Kaj ti je najpomembnejše?', multi: true, options: ['Kondicija', 'Manj kilogramov', 'Več mišic in moči', 'Hitrejši in vzdržljivejši', 'Zdravje'], other: false })
  // dneve, ko ima čas, je povedal v 1. koraku — vprašanje o dnevih brez časa le, če jih ni
  if (!o.avail?.length) qs.push({ id: 'nedni', text: 'Kateri dnevi ti zagotovo ne gredo?', multi: true, options: [...DAY_OPTS, 'Vsi gredo'], other: false })
  // (v3.50) tudi zdravstvena težava (srce, tlak) — prej samo koleno, hrbet, rama
  qs.push({ id: 'poskodbe', text: 'Te kaj boli, imaš poškodbo ali zdravstveno težavo?', multi: true, options: ['Ne', 'Koleno', 'Hrbet', 'Rama', 'Srce ali tlak'], other: true })
  // poškodbe vedno ostanejo (zadnje); ostalo po pomembnosti do 8
  return { understood: '', questions: [...qs.slice(0, -1).slice(0, 7), qs[qs.length - 1]!], enough: true }
}

export { DAY_OPTS }
/* ---------- besede o dnevih, vadbah in času ---------- */
const word = (w: string) => new RegExp(`(?:^|[^\\p{L}])(?:${w})(?![\\p{L}])`, 'gu')
// cele besede tudi v pogovornem jeziku (»pondelk«, »tork«, »četrk«, »sobta«); »torej«, »petkrat«, »četrt ure«, »sredi tedna« niso dnevi
const END = '(?:a|u|om|ih|i|e|ov|ah)?'
const DAY_SRC = [`pon[a-zč]{0,3}del\\p{L}*`, `tor(?:ek|k${END})`, `sred(?:a|o|e|ah|ami)`, `(?:č|c)etr(?:t)?(?:ek|k${END})`, `pet(?:ek|k${END})`, `sobo?t\\p{L}*`, `nede?lj\\p{L}*`]
const DAY_WORD = DAY_SRC.map(word)
// okrajšave: pon, tor, sre, čet, sob, ned so enoznačne tudi v prostem besedilu; »pet« je tam navadno število —
// velja samo v izbiri (short) ali v naštevanju ob drugem dnevu (»tor, pet«), ne pred enoto (»pet km«)
const ABBR_SRC = ['pon', 'tor', 'sre', '(?:č|c)et', 'pet', 'sob', 'ned']
const DAY_ABBR = ABBR_SRC.map(w => word(`${w}\\.?`))
const WEEKEND = word('vikend\\p{L}*|kon(?:ec|cu) tedna')
const UNIT_AFTER = /^\.?\s*(?:km|ur[aei]?|h\b|min|minut|dni|dnev|krat|x|×|do\b|-|–|km\b)/u
const DAY_ANY = `(?:${[...DAY_SRC, ...ABBR_SRC.map(w => `${w}\\.?`), 'vikend\\p{L}*'].join('|')})`
// »torek, četrtek in petek« → »torek in četrtek in petek« (vejica v naštevanju dni ni nov del stavka)
const DAY_LIST_COMMA = new RegExp(`(${DAY_ANY})\\s*,\\s*(?=(?:(?:in|pa|ter|ali)\\s+)?(?:(?:v|ob|na)\\s+)?${DAY_ANY}(?![\\p{L}]))`, 'giu')
// »od ponedeljka do petka« → vsi dnevi vmes
const DAY_RANGE = new RegExp(`od\\s+(${DAY_ANY})\\s+do\\s+(${DAY_ANY})(?![\\p{L}])`, 'giu')
function dayHits(t: string, short: boolean): { d: number; at: number; end: number }[] {
  const out: { d: number; at: number; end: number }[] = []
  const scan = (r: RegExp, ds: number[]) => { r.lastIndex = 0; for (let m = r.exec(t); m; m = r.exec(t)) { const lead = m[0].length - m[0].trimStart().length; ds.forEach(d => out.push({ d, at: m!.index + lead, end: m!.index + m![0].length })) } }
  DAY_WORD.forEach((r, i) => scan(r, [i]))
  DAY_ABBR.forEach((r, i) => { if (i !== 4 || short) scan(r, [i]) })
  scan(WEEKEND, [5, 6])
  if (!short) {
    const pet: { d: number; at: number; end: number }[] = []
    DAY_ABBR[4]!.lastIndex = 0
    for (let m = DAY_ABBR[4]!.exec(t); m; m = DAY_ABBR[4]!.exec(t)) {
      const lead = m[0].length - m[0].trimStart().length, at = m.index + lead, end = m.index + m[0].length
      if (out.some(h => Math.abs(h.at - at) <= 9) && !UNIT_AFTER.test(t.slice(end, end + 8))) pet.push({ d: 4, at, end })
    }
    out.push(...pet)
  }
  return out
}
/** en dan iz besede (za obsege) */
const dayOf = (w: string): number => { const h = dayHits(` ${w.toLowerCase()}`, true); return h.length ? h[0]!.d : -1 }
/** »od ponedeljka do petka« → »pon in tor in sre in čet in pet«; vejice v naštevanju dni → »in«; decimalke ostanejo cele */
function normText(text: string): string {
  return text.toLowerCase()
    .replace(/(\d)[.,](\d)/g, '$1·$2')
    .replace(DAY_RANGE, (_m, a: string, b: string) => { const x = dayOf(a), y = dayOf(b); if (x < 0 || y < 0) return _m; const ds: string[] = []; for (let d = x; ; d = (d + 1) % 7) { ds.push(DAY_SHORT[d]!); if (d === y || ds.length > 7) break } return ds.join(' in ') })
    .replace(DAY_LIST_COMMA, '$1 in ')
}
/** »Tor, Čet« (izbira, short) ali »ob torkih in četrtkih«, »čez vikend«, »od pon do sre« → [1, 3] … (0 = pon … 6 = ned) */
export function daysIn(text: string, short = false): number[] {
  return [...new Set(dayHits(normText(text), short).map(h => h.d))].sort((a, b) => a - b)
}
// »iz torka na sredo«, »namesto torka sreda«, »ne v torek, ampak v sredo«: torek je izvor, ne cilj
const FROM = /(?:^|[^\p{L}])(?:iz|z|s|namesto|od|ne|ne v|ne ob)\s*$/u
// »iz torka in petka na sredo«: dan za »in« takoj za izvornim dnevom je tudi izvor (ne pa »na sredo«)
const JOIN = /^\s*(?:in|pa|ter|ali)\s+$/u
function splitDays(t: string): { src: number[]; dst: number[] } {
  const hits = dayHits(t, false).sort((a, b) => a.at - b.at)
  const src: number[] = [], dst: number[] = []
  const isSrc: boolean[] = []
  hits.forEach((h, k) => {
    const p = k > 0 ? hits[k - 1]! : null
    const s = FROM.test(t.slice(Math.max(0, h.at - 10), h.at)) || (p != null && isSrc[k - 1] === true && JOIN.test(t.slice(p.end, h.at)))
    isSrc.push(s)
    if (s) src.push(h.d); else dst.push(h.d)
  })
  return { src: [...new Set(src)], dst: [...new Set(dst)].sort((a, b) => a - b) }
}
const srcDays = (t: string): number[] => splitDays(t).src
/** ciljni dnevi v delu stavka (brez izvornih: »iz torka«, »namesto torka«, »ne v torek«) */
const targetDays = (t: string): number[] => splitDays(t).dst
// nimam časa (ta dan ni vadbe)
const NO_TIME = /ne (?:morem|gre|utegnem|pridem|bom mog\p{L}*|bo (?:ni(?:č|c)|n(?:č|c)|vadbe|treninga))|naj ne bo|nimam (?:časa|casa)|ni (?:časa|casa)|nisem (?:doma|prost\p{L}*)|zaseden\p{L}*|naj bo prost\p{L}*|(?:^|[^\p{L}])prost[aoi]?(?![\p{L}])|po(?:č|c)itek|brez (?:vadbe|treninga)|(?:^|[^\p{L}])fraj(?![\p{L}])|tudi ne(?![\p{L}])/gu
// (v3.50) dan brez časa tudi: ne treniram / ne vadim, odpade, počivam, služba do večera, za družino; samo dan + »ne«
const OFF_MORE = /ne (?:treniram|vadim|telovadim|bom treniral\p{L}*)|no(?:č|c)em trenir\p{L}*|odpade|po(?:č|c)ivam|(?:delam|slu(?:ž|z)b\p{L}*|(?:š|s)iht\p{L}*|v slu(?:ž|z)bi)\s+do\s+(?:1[89]|2[0-3])|za dru(?:ž|z)ino/gu
const DAY_SEQ = `(?:(?:v|ob|na)\\s+)?${DAY_ANY}(?:\\s+(?:in|pa|ter|ali)\\s+(?:(?:v|ob|na)\\s+)?${DAY_ANY})*`
const BARE_NO = new RegExp(`^(?:(?:in|pa|ter|tudi)\\s+)?${DAY_SEQ}\\s+(?:pa\\s+|tudi\\s+)?ne$|^(?:pa\\s+)?ne\\s+${DAY_SEQ}$`, 'u')
// lahko (ta dan gre) — »ne gre« ni »gre«
const CAN = /(?:^|[^\p{L}])(?:lahko|gre|imam (?:čas|cas)\p{L}*|sem prost\p{L}*|ustreza|pa(?:š|s)e)(?![\p{L}])/gu
const canHits = (c: string): number[] => [...c.matchAll(CAN)].filter(m => !/(?:^|\s)ne\s*$/.test(c.slice(Math.max(0, m.index! - 4), m.index! + 1))).map(m => m.index!)
// te vadbe ne delam (ta dan ali sploh)
const NOT_GO = /ne hodim|ne grem|ne telovadim|ne delam|ne treniram|no(?:č|c)em|ne (?:morem|gre|utegnem)/u
const SPORT_RX: [FocusSport, RegExp][] = [
  ['fitnes', word('fitnes\\p{L}*|gym|teretan\\p{L}*')],
  ['doma', word('doma|doma(?:č|c)\\p{L}*|brez opreme')],
  ['tek', word('tek(?:a|u|om|i|ov|e)?|te(?:č|c)(?:t|i|em|e(?:š|s)|e|imo|ete|ejo)?|tekel|tekla|tekat\\p{L}*|tekanj\\p{L}*|lauf\\p{L}*')],
  ['kolo', word('kol(?:o|esa|esu|esom|es|esar\\p{L}*)|bicikl\\p{L}*')],
  ['hribi', word('hrib\\p{L}*|pohod\\p{L}*|planin\\p{L}*')],
]
// »sem doma«, »nisem doma«, »delam doma« je o tem, kje si — ne vadba doma
const AT_HOME = /(?:^|[^\p{L}])(?:sem|nisem|bom|nismo|bomo|ni|ostanem|ostal[aie]?|grem|pridem|delam|od)\s+doma(?![\p{L}])/u
const HOME_TRAIN = /vadb\p{L}* doma|doma(?:č|c)\p{L}* vadb|brez opreme|doma (?:vadim|treniram|telovadim|z ročk|z utež)/u
// vadba za »namesto«, »brez«, »ne« je izvor, ne cilj (»tek namesto kolesa«)
const NOT_THIS = /(?:^|[^\p{L}])(?:namesto|brez|ne)\s*$/u
/** vadbe v delu stavka (brez tistih za »namesto / brez«) */
function sportsIn(t: string): FocusSport[] {
  const out: FocusSport[] = []
  for (const [k, rx] of SPORT_RX) {
    rx.lastIndex = 0
    const hits = [...t.matchAll(rx)].map(m => m.index! + (m[0].length - m[0].trimStart().length))
    rx.lastIndex = 0
    if (!hits.length) continue
    if (k === 'doma' && AT_HOME.test(t) && !HOME_TRAIN.test(t)) continue
    if (hits.every(at => NOT_THIS.test(t.slice(Math.max(0, at - 9), at)))) continue
    out.push(k)
  }
  return out
}
const SAME = /(?:^|[^\p{L}])(?:ist[iaoe]|istem|istih|enak\p{L}*|takrat|tist[iaoe])(?![\p{L}])/u
const AFTER = /po (?:fitnes\p{L}*|vadbi|mo(?:č|c)i|treningu|ute(?:ž|z)\p{L}*)|zraven|skupaj|v enem|(?:^|[^\p{L}])vmes(?![\p{L}])/u
const REST = /(?:^|[^\p{L}])(?:ostal\p{L}*|preostal\p{L}*|drug[ei] dn\p{L}*)(?![\p{L}])/u
const MOVE = new RegExp(`premakn\\p{L}*|prestav\\p{L}*|(?:^|[^\\p{L}])(?:namesto|iz|z|s)\\s+${DAY_ANY}(?![\\p{L}])`, 'u')
const ONLY = /(?:^|[^\p{L}])(?:samo|le|to(?:č|c)no|izklju(?:č|c)no)(?![\p{L}])/u
const hasNo = (c: string) => { NO_TIME.lastIndex = 0; const r = NO_TIME.test(c); NO_TIME.lastIndex = 0; return r }
/** stavki in deli stavkov (vejica, podpičje): vsaka vrstica je en pomen; naštevanje dni z vejicami ostane skupaj */
const clauses = (text: string): string[] => normText(text).split(/[.;!?\n,]+/).map(c => c.trim()).filter(Boolean)

/**
 * Dnevi brez časa iz besed: dan velja za »ne gre«, če je v istem delu stavka »ne morem / nimam časa / naj ne bo nič«
 * in ni v njem besede »lahko« bliže dnevu; del stavka, ki omenja vadbo (»v fitnes ne hodim ob sobotah«), ni cel dan
 * brez časa — to je stvar te vadbe (notOnIn). (»ob torkih ne morem, ob petkih pa lahko« → [1]; »ob petkih pa ne morem« → [4])
 */
export function offDaysIn(text: string): number[] {
  const out = new Set<number>()
  for (const c of clauses(text)) {
    // (v3.50) »ob nedeljah ne treniram«, »sreda odpade«, »v nedeljo počivam«, »ob petkih delam do 20h«, »vikend je za
    // družino«, »petek ne« — prej noben dan brez časa
    const bare = BARE_NO.test(c)
    OFF_MORE.lastIndex = 0
    const more = OFF_MORE.test(c); OFF_MORE.lastIndex = 0
    if (!(hasNo(c) || more || bare) || sportsIn(c).length) continue
    if (bare) { dayHits(c, true).forEach(h => out.add(h.d)); continue }
    const no = [...c.matchAll(NO_TIME), ...c.matchAll(OFF_MORE)].map(m => m.index!)
    const yes = canHits(c)
    const dist = (at: number, xs: number[]) => Math.min(Infinity, ...xs.map(x => Math.abs(x - at)))
    for (const h of dayHits(c, false)) if (dist(h.at, no) <= dist(h.at, yes)) out.add(h.d)
  }
  return [...out].sort((a, b) => a - b)
}
/** »ob torkih spet lahko«, »v sredo pa lahko« → dnevi, ki spet gredo (deli stavka z »lahko« in brez »ne morem«) */
export function canDaysIn(text: string): number[] {
  const out = new Set<number>()
  for (const c of clauses(text)) if (!hasNo(c) && canHits(c).length && !NOT_GO.test(c)) daysIn(c).forEach(d => out.add(d))
  return [...out].sort((a, b) => a - b)
}
/** »v fitnes ne hodim sobote, nedelje, torka …«, »ob sredah nimam časa za tek« → vadba te vrste ta dan ne gre. */
export function notOnIn(text: string): Map<FocusSport, number[]> {
  const out = new Map<FocusSport, number[]>()
  for (const c of clauses(text)) {
    if (!(NOT_GO.test(c) || hasNo(c))) continue
    const ds = daysIn(c), sp = sportsIn(c)
    if (ds.length) sp.forEach(x => out.set(x, [...new Set([...(out.get(x) || []), ...ds])].sort((a, b) => a - b)))
  }
  return out
}
/** trajanje v delu stavka (»20 min teka«, »1,5 h«, »2 uri«) */
function minutesIn(c: string): number | null {
  const m = /(\d{2,3})\s*min/.exec(c); if (m) return +m[1]!
  const h = /(\d(?:·\d)?)\s*(?:h|ur[aeio]?|uri)(?![\p{L}])/u.exec(c); if (h) return Math.round(parseFloat(h[1]!.replace('·', '.')) * 60)
  return null
}
const cardioKindIn = (c: string): CardioKind => (/dolg|dalj(?:š|s)|najdalj/.test(c) ? 'dolgo' : /interval/.test(c) ? 'intervali' : /tempo/.test(c) ? 'tempo' : 'lahko')
export interface Pin { type: FocusSport; day: number; min: number | null; cardio: CardioKind; /** kardio takoj po moči (isti del stavka kot moč, »v istem dnevu«, »po fitnesu«) */ after: boolean; /** »samo ta dva dneva« */ only: boolean; /** »dodaj še …«: nova seja, ne premik obstoječe */ add: boolean; /** »tek namesto kolesa«: te vadbe izpadejo */ instead: FocusSport[] }
// »po fitnesu«, »po moči«: sklic na moč, ne nova seja moči
const AFTER_REF = /po (?:fitnes\p{L}*|vadbi|mo(?:č|c)i|treningu|ute(?:ž|z)\p{L}*)/gu
const ADD = /dodaj|dodatn\p{L}*|(?:^|[^\p{L}])(?:š|s)e (?:en[aoi]?|enkrat|kak(?:š|s)n\p{L}*|kdaj)(?![\p{L}])/u
const INSTEAD = /(?:^|[^\p{L}])(?:namesto|raje kot)\s+(\p{L}+)/gu
/** »tek namesto kolesa« → [kolo] */
function insteadIn(c: string): FocusSport[] {
  const out = new Set<FocusSport>()
  for (const m of c.matchAll(INSTEAD)) for (const [k, rx] of SPORT_RX) { rx.lastIndex = 0; if (rx.test(` ${m[1]} `)) out.add(k); rx.lastIndex = 0 }
  return [...out]
}
/**
 * Določeni dnevi iz besed: »torek in petek fitnes, tek v istem dnevu, nedelja kolo« → [fitnes tor, fitnes pet, tek tor po
 * moči, tek pet po moči, kolo ned]. Del stavka o času (»ne morem«), o tem, česar ne dela, o premiku (»iz torka na sredo«)
 * ali o ostalem (»ostalo kolo«) ne določa dni; »v istem dnevu« / »po fitnesu« / »vmes« veže na prej omenjene dni moči;
 * »tek po fitnesu ob torkih« določa le tek (fitnes je sklic). strengthDays = dnevi moči iz obstoječega dogovora.
 */
export function pinsIn(text: string, o: { strengthDays?: readonly number[] } = {}): Pin[] {
  const out: Pin[] = []
  let last: number[] = [], lastSport: FocusSport[] = []
  const strengthDays = () => { const d = out.filter(p => isStrength({ type: p.type })).map(p => p.day); return d.length ? [...new Set(d)] : [...(o.strengthDays || [])] }
  for (const c of clauses(text)) {
    if (hasNo(c) || NOT_GO.test(c) || REST.test(c) || MOVE.test(c)) continue
    // »tek po fitnesu«: fitnes je sklic (tek je po njem), ne seja moči za določitev
    AFTER_REF.lastIndex = 0
    const ref = AFTER_REF.test(c); AFTER_REF.lastIndex = 0
    let sp = sportsIn(ref ? c.replace(AFTER_REF, 'po tem') : c)
    const strengthRef = ref && sp.some(x => !isStrength({ type: x })) && sportsIn(c).some(x => isStrength({ type: x })) && !sp.some(x => isStrength({ type: x }))
    let ds = targetDays(c), bound = strengthRef
    if (!ds.length && sp.some(x => !isStrength({ type: x }))) {
      // »tek po fitnesu«, »tek v istem dnevu«: kardio na dneve moči (moč v tem delu stavka je le sklic)
      if (AFTER.test(c)) { ds = strengthDays(); bound = true; sp = sp.filter(x => !isStrength({ type: x })) }
      else if (SAME.test(c)) { ds = last; bound = true }
    }
    if (!ds.length) { if (sp.length) lastSport = sp; continue }
    last = ds
    // »fitnes ne v torek, ampak v sredo«: drugi del stavka je še o fitnesu
    const use = sp.length ? sp : /^(?:ampak|temve(?:č|c)|raje|pa raje|pa(?:č|c))(?![\p{L}])/u.test(c) ? lastSport : []
    if (!use.length) continue
    lastSport = use
    const min = minutesIn(c), kind = cardioKindIn(c), only = ONLY.test(c), add = ADD.test(c), instead = insteadIn(c)
    const withStrength = use.some(x => isStrength({ type: x }))
    for (const type of use) for (const day of ds) {
      if (out.some(p => p.type === type && p.day === day)) continue
      // kardio v istem delu stavka kot moč (»fitnes s tekom«) ali vezan nanjo = po moči isti dan
      const after = !isStrength({ type }) && (bound || withStrength || strengthDays().includes(day))
      out.push({ type, day, min, cardio: kind, after, only, add, instead: instead.filter(x => x !== type) })
    }
  }
  return out
}
/** »premakni fitnes iz torka na sredo«, »tek namesto torka v četrtek« → premiki: vadba (ali vse), z dneva na dan. */
export function movesIn(text: string): { type: FocusSport | null; from: number[]; to: number[] }[] {
  const out: { type: FocusSport | null; from: number[]; to: number[] }[] = []
  for (const c of clauses(text)) {
    if (hasNo(c) || NOT_GO.test(c)) continue
    const from = srcDays(c), to = targetDays(c)
    if (!from.length || !to.length) continue
    const sp = sportsIn(c)
    out.push({ type: sp[0] ?? null, from, to })
  }
  return out
}
/**
 * Dnevi iz prejšnjega dogovora ostanejo, ko uporabnik ni govoril o dnevih (»več kardia«), AI pa jih je spremenil ali
 * izpustil: določene seje iste vrste dobijo prejšnji dan, kardio po moči ostane pri svoji seji moči.
 */
export function keepDayStructure(prev: Focus, next: Focus, age?: number | null): Focus {
  let s: AgreedSession[] = next.sessions.map(x => ({ ...x }))
  const prevTails = tailsOf(prev.sessions)
  // določeni dnevi po vrsti: prejšnja seja z dnem → nova seja iste vrste s tem dnem (najprej brez dneva, sicer tista,
  // ki ji je AI dal drug dan)
  const prevPins = prev.sessions.filter((x, i) => x.day != null && !prevTails.has(i))
  for (const p of prevPins) {
    if (s.some(x => x.type === p.type && x.day === p.day)) continue
    const mineDays = prevPins.filter(q => q.type === p.type).map(q => q.day)
    let i = s.findIndex(x => x.type === p.type && x.day == null && !x.after)
    if (i < 0) i = s.findIndex(x => x.type === p.type && !x.after && !mineDays.includes(x.day ?? -1))
    if (i >= 0) { s = s.map(x => (x.day === p.day && !x.after && x.type !== p.type ? { ...x, day: null } : x)); s[i] = { ...s[i]!, day: p.day } }
  }
  // kardio po moči: k-ta seja moči je imela kardio te vrste → nova k-ta seja moči ga dobi (iz prostih sej te vrste)
  const ordOf = (list: readonly AgreedSession[]) => { const m = new Map<number, number>(); list.forEach((x, i) => { if (isStrength(x)) m.set(i, m.size) }); return m }
  const prevOrd = ordOf(prev.sessions)
  const want = [...prevTails.entries()].map(([t, m]) => ({ ord: prevOrd.get(m)!, type: prev.sessions[t]!.type, tail: prev.sessions[t]! }))
  for (const w of want) {
    const ord = ordOf(s)
    const mi = [...ord.entries()].find(([, o]) => o === w.ord)?.[0]
    if (mi == null) continue
    const tails = tailsOf(s)
    if ([...tails.values()].includes(mi)) continue
    // prosta seja te vrste postane kardio po moči; če je ni, se prejšnji kardio po moči vrne (uporabnik ga ni odpovedal)
    const ci = s.findIndex(x => x.type === w.type && !isStrength(x) && !x.after && x.day == null)
    const c: AgreedSession = ci >= 0 ? { ...s[ci]!, after: true } : { ...w.tail, day: null, after: true }
    if (ci >= 0) s = s.filter((_, i) => i !== ci)
    const at = s.findIndex((x, i) => isStrength(x) && ordOf(s).get(i) === w.ord)
    s = [...s.slice(0, at + 1), c, ...s.slice(at + 1)]
  }
  const out = normalizeFocus({ ...next, sessions: s, offDays: [...new Set([...(next.offDays || []), ...(prev.offDays || [])])] }, { age, by: next.by, now: next.at })
  if (!out) return next
  out.title = next.title; out.notes = next.notes; out.strategy = next.strategy ?? null
  return out
}
/** Ali besedilo sploh govori o dnevih (določeni dnevi, dnevi brez časa, »v fitnes ne hodim ob …«). */
export const mentionsDays = (text: string): boolean => daysIn(text).length > 0 || pinsIn(text).length > 0 || notOnIn(text).size > 0 || offDaysIn(text).length > 0
/** »ostalo kolo ali doma« → vadbe za preostale dni. */
export function restSportsIn(text: string): FocusSport[] {
  const out = new Set<FocusSport>()
  for (const c of clauses(text)) if (REST.test(c) && !hasNo(c) && !NOT_GO.test(c)) sportsIn(c).forEach(x => out.add(x))
  return [...out]
}
/** enakomerno m dni iz razpoložljivih */
const spreadDays = (avail: readonly number[], m: number): number[] => (m >= avail.length ? [...avail] : m === 1 ? [avail[Math.floor((avail.length - 1) / 2)]!] : Array.from({ length: m }, (_, j) => avail[Math.round((j * (avail.length - 1)) / (m - 1))]!))
/** (v3.49) freq: cilj mišice — vsaka mišica vsaj 2× na teden (2 vadbi celo telo A/B, 3 zgornji/spodnji/celo, 4 zgornji/spodnji ×2) */
const strengthParts = (n: number, freq = false): SessionPart[] => (n <= 1 ? ['celo']
  : freq ? (n === 2 ? ['celo', 'celo'] : n === 3 ? ['zgornji', 'spodnji', 'celo'] : ['zgornji', 'spodnji', 'zgornji', 'spodnji', 'celo', 'celo'])
  : n === 2 ? ['zgornji', 'spodnji'] : n === 3 ? ['potisk', 'noge', 'poteg'] : ['zgornji', 'spodnji', 'potisk', 'poteg', 'celo', 'celo'])
/** (v3.49) dva dneva zapored (tudi nedelja–ponedeljek) */
export const adjacentDays = (days: readonly (number | null | undefined)[]): boolean => {
  const d = days.filter((x): x is number => x != null)
  return d.some((a, i) => d.some((b, j) => i !== j && (b - a + 7) % 7 === 1))
}
const cardioMin = (t: FocusSport, kind: CardioKind, base?: number | null) => (kind === 'dolgo' ? Math.max(60, base ?? 0) : t === 'kolo' ? Math.max(45, base ?? 60) : t === 'hribi' ? 150 : Math.max(20, Math.min(45, (base ?? 40) - 10)))
/** indeksi kardia po moči (after) za vsako sejo moči */
const tailIndex = (s: readonly AgreedSession[]): Map<number, number> => { const m = new Map<number, number>(); tailsOf(s).forEach((i, j) => m.set(i, j)); return m }

/**
 * Dnevi iz besed na dogovor (AI ali pravila): določene vadbe na svoje dni (moč: točno ti dnevi; kardio: ti dnevi, ostali
 * teki ostanejo prosti), kardio po moči v istem dnevu ostane z njo ob vsaki spremembi, premiki (»iz torka na sredo«),
 * vadbe, ki jih ta dan ne dela, na druge dni, dnevi brez časa in spet prosti dnevi, »ostalo kolo ali doma« za preostale
 * seje. Besede uporabnika so zavezujoče — tudi ko jih AI v predlogu ni upošteval. Vrne null, če besedilo ne govori o dnevih.
 */
export function applyDayWords(f: Focus, text: string, age?: number | null): Focus | null {
  const strengthDays0 = f.sessions.filter(x => isStrength(x) && x.day != null).map(x => x.day!)
  const pins = pinsIn(text, { strengthDays: strengthDays0 }), notOn = notOnIn(text), noDays = offDaysIn(text), rest = restSportsIn(text), moves = movesIn(text), canDays = canDaysIn(text)
  if (!pins.length && !notOn.size && !noDays.length && !canDays.length && !rest.length && !moves.length) return null
  let s: AgreedSession[] = f.sessions.map(x => ({ ...x }))
  let off = [...new Set([...(f.offDays || []), ...noDays])].filter(d => !canDays.includes(d) || noDays.includes(d))
  const sMin = s.find(isStrength)?.min ?? f.minutes
  const cMin = s.find(x => !isStrength(x) && !x.after)?.min ?? null
  const dayTaken = (d: number, except: number[] = []) => s.some((x, i) => x.day === d && !x.after && !except.includes(i))
  // 1. premiki: »premakni fitnes iz torka na sredo« — samo seje na izvornem dnevu
  for (const mv of moves) {
    const cand = s.map((x, i) => ({ x, i })).filter(({ x }) => !x.after && x.day != null && mv.from.includes(x.day) && (!mv.type || x.type === mv.type))
    cand.forEach(({ i }, k) => { const to = mv.to[Math.min(k, mv.to.length - 1)]!; off = off.filter(d => d !== to); s[i] = { ...s[i]!, day: to } })
  }
  // 2. določene vadbe
  const pinnedTypes = [...new Set(pins.map(p => p.type))]
  const strengthPins = pins.filter(p => isStrength({ type: p.type }))
  for (const type of [...new Set(strengthPins.map(p => p.type))]) {
    const mine = strengthPins.filter(p => p.type === type).sort((a, b) => a.day - b.day)
    off = off.filter(d => !mine.some(p => p.day === d))
    const tails = tailIndex(s)
    const old = s.map((x, i) => ({ x, i })).filter(({ x }) => x.type === type)
    // (v3.49) cilj mišice: celo telo A/B, razen ko sta dneva zapored (iste mišice dva dni zapored)
    const parts = strengthParts(mine.length, f.aims.includes('misice') && f.level >= 2 && !(mine.length === 2 && adjacentDays(mine.map(x => x.day))))
    const keepParts = old.length === mine.length
    // moč: točno ti dnevi — stare seje te vrste (z njihovim kardiem po moči) zamenjajo nove, kardio po moči ostane z njo
    const fresh: AgreedSession[] = []
    mine.forEach((p, k) => {
      const base = old[k]?.x ?? old[old.length - 1]?.x
      fresh.push({ type, part: keepParts && base?.part ? base.part : parts[k % parts.length]!, min: p.min ?? base?.min ?? sMin, day: p.day, ...(base?.ex ? { ex: base.ex } : {}), ...(base?.why ? { why: base.why } : {}) })
      const t = old[k] ? tails.get(old[k]!.i) : undefined
      if (t != null) fresh.push({ ...s[t]!, day: null, after: true })
    })
    const gone = new Set(old.flatMap(({ i }) => [i, ...(tails.has(i) ? [tails.get(i)!] : [])]))
    s = [...s.filter((_, i) => !gone.has(i)), ...fresh]
  }
  for (const type of [...new Set(pins.filter(p => !isStrength({ type: p.type })).map(p => p.type))]) {
    const mine = pins.filter(p => p.type === type).sort((a, b) => a.day - b.day)
    off = off.filter(d => !mine.some(p => p.day === d))
    for (const p of mine) {
      const strengthAt = s.findIndex(x => isStrength(x) && x.day === p.day)
      if (p.after && strengthAt >= 0) {
        // kardio po moči: za to sejo moči (zamenja prejšnjega, če je)
        const tails = tailIndex(s)
        const old = tails.has(strengthAt) ? s[tails.get(strengthAt)!]! : s.find(x => x.type === type && !x.after && x.day == null)
        const tail: AgreedSession = { type, cardio: p.cardio !== 'lahko' ? p.cardio : old?.cardio ?? 'lahko', min: p.min ?? (p.cardio === 'dolgo' ? cardioMin(type, 'dolgo', old?.min) : Math.min(25, old?.min ?? 20)), after: true }
        const drop = tails.has(strengthAt) ? tails.get(strengthAt)! : old ? s.indexOf(old) : -1
        s = s.filter((_, i) => i !== drop)
        const at = s.findIndex(x => isStrength(x) && x.day === p.day)
        s = [...s.slice(0, at + 1), tail, ...s.slice(at + 1)]
      } else {
        // samostojen kardio na ta dan: najprej seja te vrste brez dneva (ali s tem dnem); »kolo ob sobotah« premakne že
        // določeno kolo z drugega dneva (ne podvoji), »dodaj še kolo ob sobotah« doda novo
        let i = s.findIndex(x => x.type === type && !x.after && (x.day === p.day || x.day == null) && !dayTaken(p.day, [s.indexOf(x)]))
        if (i < 0 && !p.add) i = s.findIndex(x => x.type === type && !x.after && x.day != null && !mine.some(q => q.day === x.day) && !dayTaken(p.day, [s.indexOf(x)]))
        const base = i >= 0 ? s[i]! : undefined
        const kind: CardioKind = p.cardio !== 'lahko' ? p.cardio : base?.cardio ?? 'lahko'
        const next: AgreedSession = { ...(base ?? { type }), type, cardio: kind, min: p.min ?? (p.cardio !== 'lahko' && p.cardio !== base?.cardio ? cardioMin(type, kind, base?.min) : base?.min ?? cardioMin(type, kind, cMin ?? sMin)), day: p.day }
        if (i >= 0) s[i] = next; else s.push(next)
      }
      // »tek namesto kolesa ob sobotah«: kolo izpade — najprej tisto na ta dan, sicer prosto, sicer katero koli
      for (const gone of p.instead) {
        const tails = tailIndex(s)
        const j = [s.findIndex(x => x.type === gone && !x.after && x.day === p.day), s.findIndex(x => x.type === gone && !x.after && x.day == null), s.findIndex(x => x.type === gone && !x.after)].find(k => k >= 0)
        if (j == null) continue
        const drop = new Set([j, ...(tails.has(j) ? [tails.get(j)!] : [])])
        s = s.filter((_, k) => !drop.has(k))
      }
    }
    // »samo ob sobotah«: druge seje te vrste izpadejo (tudi kardio po moči na drugih dnevih)
    if (mine.some(p => p.only)) {
      const ofTail = tailsOf(s)   // kardio po moči → njegova seja moči (dan)
      const dayOfIdx = (i: number) => (ofTail.has(i) ? s[ofTail.get(i)!]!.day : s[i]!.day)
      s = s.filter((x, i) => x.type !== type || mine.some(p => p.day === dayOfIdx(i)))
    }
  }
  // 3. vadbe, ki jih ta dan ne dela: seje te vrste na teh dneh (ali brez dneva) na druge dni; kardio po moči na takem dnevu izpade
  for (const [type, bad] of notOn) {
    if (pinnedTypes.includes(type)) continue
    const tails = tailIndex(s)
    const tailOfStrength = new Map([...tails.entries()].map(([i, j]) => [j, i]))
    // kardio po moči te vrste na slabem dnevu → izpade
    s = s.filter((x, j) => !(x.type === type && x.after && tailOfStrength.has(j) && s[tailOfStrength.get(j)!]!.day != null && bad.includes(s[tailOfStrength.get(j)!]!.day!)))
    const mine = s.map((x, i) => ({ x, i })).filter(({ x }) => x.type === type && !x.after && (x.day == null || bad.includes(x.day)))
    if (!mine.length) continue
    const okDays = [0, 1, 2, 3, 4, 5, 6].filter(d => !bad.includes(d) && !off.includes(d) && !dayTaken(d, mine.map(m => m.i)))
    const n = Math.min(mine.length, okDays.length)
    const days = spreadDays(okDays, n)
    const gone = new Set<number>()
    const tl = tailIndex(s)
    mine.forEach(({ i }, k) => { if (k < n) s[i] = { ...s[i]!, day: days[k]! }; else { gone.add(i); if (tl.has(i)) gone.add(tl.get(i)!) } })
    s = s.filter((_, i) => !gone.has(i))
  }
  // 4. »ostalo kolo ali doma«: preostale (nedoločene) seje drugih vrst zamenjajo te vadbe
  if (rest.length) {
    const tails = tailsOf(s)   // kardio po moči → njegova moč
    // ostane: določene seje in seje določene vrste; kardio po moči le skupaj s svojo močjo
    const keepMain = (i: number) => s[i]!.day != null || pinnedTypes.includes(s[i]!.type)
    const keep = s.filter((_, i) => (tails.has(i) ? keepMain(tails.get(i)!) : keepMain(i)))
    const loose = s.filter((_, i) => !tails.has(i) && !keepMain(i)).length
    const n = Math.max(rest.length, loose, pins.length ? 1 : 0)
    const add: AgreedSession[] = Array.from({ length: n }, (_, k) => { const type = rest[k % rest.length]!; return isStrength({ type }) ? { type, part: 'celo', min: sMin } : { type, cardio: 'lahko', min: cardioMin(type, 'lahko', cMin ?? sMin) } })
    s = [...keep, ...add]
  }
  const next = normalizeFocus({ ...f, sessions: orderSessions(s), sports: [...new Set(s.map(x => x.type))], offDays: off, preferDays: (f.preferDays || []).filter(d => !off.includes(d)) }, { age, by: f.by, now: f.at })
  if (!next) return null
  next.title = f.title || next.title
  next.notes = f.notes
  next.strategy = f.strategy ?? null
  return next
}
/** Seje po dnevih v tednu (določene najprej, po dnevu; kardio po moči takoj za svojo močjo), nedoločene na koncu. */
export function orderSessions(s: readonly AgreedSession[]): AgreedSession[] {
  const tails = tailsOf(s)
  const tailOf = new Map<number, number>(); tails.forEach((m, t) => tailOf.set(m, t))
  const mains = s.map((x, i) => ({ x, i })).filter(({ i }) => !tails.has(i))
  const sorted = [...mains].sort((a, b) => (a.x.day ?? 9) - (b.x.day ?? 9) || a.i - b.i)
  const out: AgreedSession[] = []
  for (const { x, i } of sorted) { out.push(x); if (tailOf.has(i)) out.push({ ...s[tailOf.get(i)!]!, after: true, day: null }) }
  return out
}

// vprašanja po oznaki (vprašalnik brez AI) ali po besedilu (vprašanja, ki jih je sestavil AI, nato pa ni odgovoril)
const Q_TEXT: Record<string, RegExp> = {
  ure: /ur\p{L}* na teden|koliko ur/iu,
  dni: /koliko dni|dni na teden|dni lahko|kolikokrat/i, cas: /koliko (?:časa|casa|minut)|dolg[aeo] (?:vadb|trening)|minut na/i, kje: /\bkje\b|oprem|fitnes(?:u|a)? ali doma/i,
  ftp: /ftp/i,
  kardio: /kardio|tek.*kolo|kolo.*tek|kakšen tek/i, izkusnje: /izkuš|izkus|kako dolgo|hodiš v fitnes/i, cilji: /najpomembn|cilj/i, nedni: /ne gre|ne gredo|nimaš časa|nimas casa|ne moreš|ne mores|brez časa/i, poskodbe: /boli|poškod|poskod/i,
}
const byId = (qa: readonly QA[], id: string) => qa.filter(x => x.id === id || x.q === id || (Q_TEXT[id] ? Q_TEXT[id]!.test(x.q) : false))
const has = (qa: readonly QA[], id: string, rx: RegExp) => byId(qa, id).some(x => rx.test(x.a.toLowerCase()))
const ans = (qa: readonly QA[], id: string) => byId(qa, id)[0]?.a ?? ''
/** (v3.50) FTP iz želje (»FTP 320 W«) ali odgovora na vprašanje o FTP (»280«, »280 W«) — sicer null */
export const ftpFromTalk = (wish: string, qa: readonly QA[]): number | null => ftpIn(wish) ?? ftpIn(ans(qa, 'ftp'), true)

/**
 * (v3.50) Zanikano ni cilj ne šport: »Nimam tekme«, »ne kolesa, ne ure«, »brez kolesa«, »ne maram teka«, »ne tekmujem« —
 * prej je »Nimam tekme« prižgal cilj tekma (in vprašanje »Katera tekma in kdaj?«), »ne kolesa« pa vprašanji o kolesu.
 */
const NEGATED = /(?<![\p{L}])(?:nimam|nima|nisem|brez|ne|niti)\s+(?:(?:nobene|nobenega|nobenih|več|še|rad|rada|vozim|maram|grem|imam|hodim)\s+)?\p{L}+/gu
/** (v3.50) izrecno brez tekme (»nimam tekme«, »ne tekmujem«, »brez tekem«) — brez vprašanja o tekmi */
export const noRaceIn = (wish: string): boolean => /(?<![\p{L}])(?:nimam|brez|ne\s+(?:bom\s+)?(?:imel|imam))\s+(?:nobene\s+|nobenih\s+|še\s+)?tekm|(?<![\p{L}])ne\s+tekmujem|(?<![\p{L}])nisem\s+tekmoval/u.test(wish.toLowerCase())
/** Cilji in mišice iz besed (»six pack«, »vitka postava«, »ne izgubiti mišic«, »samo zgornji del«). */
export function wishSignals(wish: string): { aims: FocusAim[]; muscles: Muscle[]; sports: FocusSport[]; keepMuscle: boolean; upperOnly: boolean; noRace: boolean } {
  // »merilnik moči« (kolo) ni cilj moč; »šest dni« ni six pack; »težko najdem čas« ni moč; »ne izgubiti mišic« ni hujšanje
  // (v3.50) »vitka in močna« je postava (definicija), ne cilj moč — prej je prižgala težke serije 4 × 4–6
  const w = wish.toLowerCase().replace(/merilni\p{L}* mo(?:č|c)\p{L}*|wat\p{L}*/gu, 'merilnik').replace(/vitk\p{L}*\s+in\s+mo(?:č|c)n\p{L}*/gu, 'vitka')
  // (v3.50) brez zanikanih besed — za tekmo in športe (kolo, tek, hribi)
  const wn = w.replace(NEGATED, ' ')
  const aims = new Set<FocusAim>()
  const muscles = new Set<Muscle>()
  const sports = new Set<FocusSport>()
  // »manj kilogramov«, »shujšati« — ne »imam 100 kilogramov« ali »ne izgubiti mišic«
  if (/hujš|husj|shujš|manj kilogram|kilogram\p{L}* manj|kil\p{L}* dol|maščob|mascob|izgubit(?!\p{L}*\s+mi(?:š|s)ic)/u.test(w)) aims.add('hujsanje')
  if (/vitk|definic|lin\b|lean|six|šestk|sixpack|trebuš/.test(w)) aims.add('definicija')
  if (/mišic|misic|(?<![\p{L}])mas[aeo](?![\p{L}])|nabit|bicep|mišičast/u.test(w)) aims.add('misice')
  // »pomoč« ni moč
  if (/(?<![\p{L}])(?:mo(?:č|c)i?(?![\p{L}])|močn|mocn|močan|mocan)|težk\p{L}* (?:ute|serij|tež)|tezk\p{L}* (?:ute|serij)|(?<![\p{L}])(?:uteži|utezi|ročk)/u.test(w)) aims.add('moc')
  if (/kondic|sapa|vzdrž|vzdrz|kardio|sopih/.test(w)) aims.add('kondicija')
  if (/vzdržljiv|vzdrzljiv|hitrejš|hitrejs|daljš\p{L}* (?:vožnj|tek)/u.test(w)) aims.add('vzdrzljivost')
  // (v3.50) »tekma v soboto« pri nogometu (drug šport) ni cilj tekma
  if (/tekm|dirk|maraton|granfondo|gran fondo/.test(wn.split(/[.!?;\n]+/).filter(s => !otherSportIn(s)).join('. '))) aims.add('tekma')
  if (/zdrav|gibanj|hrbet me|počutj|pocutj/.test(w)) aims.add('zdravje')
  if (/six|šestk|sixpack|trebuh|trebuš|trebus/.test(w)) muscles.add('trebuh')
  if (/(?<![\p{L}])(?:rok[aeiou]?(?![\p{L}])|bicep|tricep)/u.test(w)) muscles.add('roke')
  if (/(?<![\p{L}])prs[aiou]?(?![\p{L}])|prsn/u.test(w)) muscles.add('prsa')
  if (/ramen|ramena/.test(w)) muscles.add('ramena')
  if (/hrbet|hrbt/.test(w) && !/boli|bolečin/.test(w)) muscles.add('hrbet')
  if (/zadnjic|rit\b|glute/.test(w)) muscles.add('zadnjica')
  if (/(?<![\p{L}])nog(?:e|a|ami|ah|o|i)?(?![\p{L}])/u.test(w) && !/brez nog/.test(w)) muscles.add('noge')
  if (/fitnes|gym|teretan/.test(w)) sports.add('fitnes')
  // tek: »tek, teka, tečem, tekač« — ne »tekme, tekočine, tekst, tečaj, brunch«
  if (/(?<![\p{L}])(?:tek(?:a|e|i|om|ov|ih|el|la|li)?(?![\p{L}])|tekač\p{L}*|tekaš\p{L}*|teč(?:em|eš|e|emo|ete|ejo|i)(?![\p{L}])|tec(?:i|em)(?![\p{L}])|run(?:ning|ner)?(?![\p{L}]))/u.test(wn)) sports.add('tek')
  if (/kolo|koles|bicikl|trenažer|trenazer/.test(wn)) sports.add('kolo')
  // »po hribih (trail)« je tek, »trenažer doma« je kolo
  const ww = w.replace(/po hribih \(trail\)|trail/g, '').replace(/trenaž\p{L}* doma|trenaz\p{L}* doma/gu, '')
  if (/hrib|pohod|planin|(?:^|[^\p{L}])hoj[aeo]?(?![\p{L}])|sprehod/u.test(ww.replace(NEGATED, ' '))) sports.add('hribi')
  // vadba doma — ne »delam od doma«, »sem doma«; ročke ali elastike brez fitnesa so vadba doma
  if ((/(?<![\p{L}])doma(?![\p{L}])/u.test(ww) && !AT_HOME.test(ww)) || HOME_TRAIN.test(ww) || /(?:treniram|vadim|telovadim|vadil|treniral)\p{L}*\s+doma/u.test(ww) || (/(?<![\p{L}])(?:ročk|rock|elastik)/u.test(ww) && !sports.has('fitnes'))) sports.add('doma')
  const keepMuscle = /ne izgub|nočem izgub|nocem izgub|ohran|obdrž|obdrz/.test(w) || (aims.has('hujsanje') && (aims.has('misice') || aims.has('moc') || aims.has('definicija')))
  const upperOnly = /samo zgornj|le zgornj|samo roke|samo trebuh|brez nog/.test(w)
  return { aims: [...aims], muscles: [...muscles], sports: [...sports], keepMuscle, upperOnly, noRace: noRaceIn(w) }
}

/** Predlog po pravilih iz odgovorov in besed. */
export function ruleProposal(wish: string, qa: readonly QA[], age?: number | null, o: { avail?: readonly number[] | null; today?: string | null; body?: Pick<Profile, 'weightKg' | 'heightCm'> | null } = {}): { reply: string; focus: Focus; quick: string[] } {
  // izbire, želja in odgovori (»Hoja ali pohod«, »Na trenažerju«, »Ročke«) skupaj
  const sig = wishSignals([wish, ...qa.filter(x => !/boli|poškod|poskod/i.test(x.q)).map(x => x.a)].join('. '))
  const availN = o.avail?.length ? o.avail.length : 7
  // (v3.49) dnevi in čas, ki jih je napisal sam (vprašanja zanje vprašalnik izpusti): »dvakrat na teden po 30 minut«
  const n = Math.max(Math.min(2, availN), Math.min(6, availN, parseInt(ans(qa, 'dni'), 10) || explicitDays(wish) || Math.min(3, availN)))
  // čas na vadbo (»1 h 30 min«, »45 min«) ali tedenske ure (»4–5 h«) na vadbo; odgovor o tednu ima prednost pred željo
  const week0 = rangeIn(byId(qa, 'ure')[0]?.a, 1, 30)
  const per = minutesRange(ans(qa, 'cas')) ?? (week0 ? null : perSessionIn(wish))
  const wm = week0 ? null : weekMinutesIn(wish)
  const week = week0 ?? (wm ? { lo: wm.lo / 60, hi: wm.hi / 60 } : null)
  // (v3.50) povedan čas pod 25 min (doma 15–20 min) velja — prej vedno vsaj 25
  const min = Math.max(per ? 15 : 25, Math.min(120, per ? per.lo : week ? Math.round((week.lo * 60) / n / 5) * 5 : 45))
  const level: 1 | 2 | 3 = levelFrom(wish, qa) ?? (has(qa, 'izkusnje', /redno/) ? 3 : has(qa, 'izkusnje', /nekaj/) ? 2 : 1)
  const gym = has(qa, 'kje', /fitnes/) || sig.sports.includes('fitnes')
  const equipment: FocusEquip[] = [...new Set<FocusEquip>([
    ...(gym ? ['fitnes' as const] : []), ...(has(qa, 'kje', /ročk|rock/) ? ['utezi' as const] : []),
    ...(has(qa, 'kje', /elastik/) ? ['elastike' as const] : []), ...(has(qa, 'kje', /drog/) ? ['drog' as const] : []), 'nic' as const,
  ])]
  const cardioTypes: FocusSport[] = has(qa, 'kardio', /brez/) ? [] : ([['tek', /tek/], ['kolo', /kolo/], ['hribi', /hrib|hoj|pohod/]] as [FocusSport, RegExp][]).filter(([, rx]) => has(qa, 'kardio', rx)).map(([s]) => s)
  const cardio = cardioTypes.length ? cardioTypes : sig.sports.filter(s => s === 'tek' || s === 'kolo' || s === 'hribi')
  const aims = new Set<FocusAim>(sig.aims)
  if (has(qa, 'cilji', /mišic/)) aims.add('misice')
  if (has(qa, 'cilji', /moč/)) aims.add('moc')
  if (has(qa, 'cilji', /maščob/)) aims.add('hujsanje')
  if (has(qa, 'cilji', /kondic/)) aims.add('kondicija')
  if (has(qa, 'cilji', /zdrav/)) aims.add('zdravje')
  if (!aims.size) aims.add('zdravje')
  // (v3.50) in zdravstvena težava iz vprašalnika (»Srce ali tlak«, svoje besede: »astma«)
  const hurt = ans(qa, 'poskodbe').toLowerCase()
  const injuries = [...['Koleno', 'Hrbet', 'Rama'].filter(x => has(qa, 'poskodbe', new RegExp(x.toLowerCase()))).map(x => x.toLowerCase()),
    ...(/srce|tlak/.test(hurt) ? ['srce ali krvni tlak'] : []), ...healthOf(hurt.replace(/srce ali tlak/g, ''))].join(', ')
  // dnevi brez časa (iz 1. koraka — dnevi brez časa so vsi, ki jih ni izbral —, iz vprašalnika ali iz besed »ob torkih ne morem«)
  const noAvail = o.avail?.length ? [0, 1, 2, 3, 4, 5, 6].filter(d => !o.avail!.includes(d)) : []
  // (v3.50) dnevi drugega športa (»nogomet ob torkih in četrtkih«) niso prosti za vadbo
  const offDays = [...new Set([...noAvail, ...byId(qa, 'nedni').flatMap(x => daysIn(x.a, true)), ...offDaysIn(wish), ...otherSportDays(wish).map(x => x.day)])]
  // kardio: pri kondiciji ali hujšanju 1–2 na teden (od 4 dni dalje 2), sicer 1 od 3 dni dalje
  const wantCardio = cardio.length > 0
  // samo kardio (kolesar, tekač, pohodnik brez fitnesa in brez cilja mišice/moč): vse vadbe so kardio (Blaž, 13. 10.:
  // »kaj pa če je kdo samo kolesar«); sicer razmerje po cilju (trener ga pri prvem predlogu še uskladi z »glavnim«)
  const strengthWanted = gym || has(qa, 'kje', /doma|ročk|rock|elastik|drog/) || sig.sports.some(s => s === 'fitnes' || s === 'doma') || aims.has('misice') || aims.has('moc')
  const nc = !wantCardio ? 0 : !strengthWanted ? n : (aims.has('kondicija') || aims.has('hujsanje') || aims.has('vzdrzljivost')) ? (n >= 4 ? 2 : 1) : n >= 3 ? 1 : 0
  const ns = n - nc
  const where: 'fitnes' | 'doma' = gym ? 'fitnes' : 'doma'
  // (v3.49) cilj mišice: vsaka mišica vsaj 2× na teden — 2 vadbi celo telo (A/B), 3 zgornji/spodnji/celo, 4 zgornji/spodnji ×2
  // (prej 2 vadbi zgornji + spodnji, 3 potisk/noge/poteg: vsaka mišica 1× na teden)
  const freq = aims.has('misice')
  const parts: SessionPart[] = sig.upperOnly
    ? (ns === 1 ? ['zgornji'] : (['potisk', 'poteg', 'zgornji', 'roke'] as SessionPart[]).slice(0, ns))
    : ns === 1 ? ['celo'] : ns === 2 ? (level === 1 || freq ? ['celo', 'celo'] : ['zgornji', 'spodnji']) : ns === 3 ? (level === 1 ? ['celo', 'celo', 'celo'] : freq ? ['zgornji', 'spodnji', 'celo'] : ['potisk', 'noge', 'poteg'])
    : (freq ? ['zgornji', 'spodnji', 'zgornji', 'spodnji'] : ['zgornji', 'spodnji', 'potisk', 'poteg']).slice(0, ns) as SessionPart[]
  const sessions: AgreedSession[] = parts.map(part => ({ type: where, part, min }))
  for (let k = 0; k < nc; k++) {
    const type = cardio[k % cardio.length]!
    const fast = level >= 2 && (aims.has('kondicija') || aims.has('vzdrzljivost') || aims.has('tekma'))
    // izkušen s 4+ kardio: drugi kakovostni trening je tempo (dva težka na teden), zadnji dolg
    const kind: CardioKind = type === 'hribi' ? 'lahko' : k === 0 && fast ? 'intervali' : k === 1 && fast && level === 3 && nc >= 4 ? 'tempo' : k === nc - 1 && nc >= 3 && level >= 2 ? 'dolgo' : 'lahko'
    sessions.push({ type, cardio: kind, min: kind === 'dolgo' ? Math.round(Math.min(type === 'kolo' ? 180 : 100, min * 1.5) / 5) * 5 : type === 'kolo' ? Math.max(45, min) : type === 'hribi' ? Math.max(60, min) : Math.max(25, Math.min(50, min - 10)) })
  }
  // (v3.50) tek in hoja že v dogovoru, kot ga bo sestavil načrt (začetnik, »začenjam s tekom«, ITM 28+) — prej dogovor
  // »Tek · lahko 25 min«, Plan »Tek in hoja — 6 × 1 min teka«; tek, izbran šele v vprašalniku (o teku ni bilo vprašanja),
  // pri ravni do 2 prav tako (prej 45 min teka v kosu od 1. tedna)
  const runAsked = cardioTypes.includes('tek') && !wishSignals(wish).sports.includes('tek') && level <= 2
  if (runAsked || runWalkFrom(o.body ?? {}, { wish, level, by: 'pravila' }) != null) {
    for (const s of sessions) if (s.type === 'tek' && (runAsked || s.cardio === 'lahko')) { s.cardio = 'lahko'; s.walk = true }
  }
  let focus = normalizeFocus({ wish, sports: [...new Set(sessions.map(s => s.type))], aims: [...aims], muscles: sig.muscles, level, equipment, limits: injuries || null, keepMuscle: sig.keepMuscle, sessions, offDays, notes: notesFor([...aims], sig.muscles, sessions) }, { age, by: 'pravila' })!
  // besede o dnevih (»torek in petek fitnes, tek v istem dnevu, ostalo kolo«) veljajo tudi brez AI — iz želje in iz prostih odgovorov
  focus = applyDayWords(focus, wish, age) ?? focus
  const free = qa.filter(x => !byId(qa, 'nedni').includes(x) && /[a-zčšž]{3,}/i.test(x.a) && x.a.length > 6).map(x => x.a).join('. ')
  if (free) focus = applyDayWords(focus, free, age) ?? focus
  focus.title = titleOf(focus)
  // (v3.49) kolesar s tekmo: ime načrta po tekmi (»Do tekme: Maraton Franja«), ne »Kolo za kondicijo«
  const race = o.today ? raceFromTalk(wish, qa, o.today) : null
  if (race && !usesAgreement(focus)) focus.title = raceTitle(race.name)
  // (v3.49) »pretečem 5 km brez ustavljanja« je cilj načrta (prej ime »Manj maščobe, več energije«, 5 km nikjer)
  const km = /(?:pretek\p{L}*|preteč\p{L}*|teč[ei]\p{L}*)\D{0,24}?(\d{1,2})\s*km\b[^.]*?(?:brez ustavlj|ne da bi se ustavil)/iu.exec(wish)
  if (km && focus.sessions.some(s => s.type === 'tek')) focus.title = `Do ${km[1]} km brez ustavljanja`
  focus.notes = fitNotes(focus.notes, focus.sessions)
  // (v3.50) »3 dni« v stavku; mladoletnemu nič o hujšanju (prej »… da med hujšanjem obdržiš mišice«)
  const minor = age != null && age < 18
  const reply = `Predlagam ${weekLine(focus, { acc: true })}: ${mixLine(focus)}.${aims.has('hujsanje') && sig.keepMuscle && !minor ? ' Moč ostane težka, da med hujšanjem obdržiš mišice.' : ''} ${daysReply(focus)} Če želiš več ali manj, povej.`
  return { reply, focus, quick: quickFor(focus) }
}
/** (v3.50) povedane ure na teden: odgovor »9–12 h« (sredina) ali »Treniram 15 ur na teden« v želji — sicer null */
export function statedWeekHours(wish: string, qa: readonly QA[]): number | null {
  const a = rangeIn(byId(qa, 'ure')[0]?.a, 1, 30)
  const w = a ? null : weekMinutesIn(wish)
  const h = a ? (a.lo + a.hi) / 2 : w ? (w.lo + w.hi) / 120 : null
  return h == null ? null : Math.min(20, Math.round(h * 2) / 2)
}
/**
 * (v3.50) Kolesarski način (načrt do tekme): povedane ure veljajo — teden dogovora se le sorazmerno raztegne (ali skrči).
 * Prej je »Treniram 15 ur na teden« tiho postal ~12 h (stropi posamezne vožnje), načrt pa je začel pri 9 h.
 */
export function withStatedHours(f: Focus, hours: number | null): Focus {
  if (hours == null || usesAgreement(f) || f.by === 'claude') return f
  const sum = f.sessions.reduce((t, s) => t + s.min, 0), want = Math.round(hours * 60)
  if (!sum || Math.abs(sum - want) < 30) return f
  const sessions = f.sessions.map(s => ({ ...s, min: Math.max(30, Math.min(300, Math.round((s.min * want) / sum / 5) * 5)) }))
  const days = trainingDays(sessions) || 1
  return { ...f, sessions, minutes: Math.max(15, Math.min(300, Math.round(sessions.reduce((t, s) => t + s.min, 0) / days / 5) * 5)) }
}
/** (v3.49) ime kolesarskega načrta s tekmo */
export const raceTitle = (name: string): string => (name && name !== 'Tekma' ? `Do tekme: ${name}`.slice(0, 40) : 'Kolo do tekme')
const QUICK = ['Več kardia', 'Več moči', 'Manj dni', 'Več dni', 'Krajše vadbe']
/**
 * (v3.49) Hitri odgovori po tednu: ves teden kardio (kolesar) »Več ur / Manj ur« — »več kardia« bi bil isti teden;
 * začetnik s tekom še »Tek in hoja«.
 */
export function quickFor(f: Pick<Focus, 'sessions' | 'level' | 'mode' | 'aims'>): string[] {
  const cardioOnly = !f.sessions.some(isStrength)
  const base = cardioOnly ? ['Več ur', 'Manj ur', 'Manj dni', 'Več dni', ...(usesAgreement(f) ? ['Več moči'] : [])] : QUICK
  const walk = f.level === 1 && f.sessions.some(s => s.type === 'tek' && !s.walk)
  return walk ? ['Tek in hoja', ...base.slice(0, 4)] : base
}
/** Dnevi z besedami za odgovor trenerja: določene vadbe, dnevi brez časa, teden dan za dnem. */
export function daysReply(f: Focus): string {
  const pins = pinsWords(f)
  const off = f.offDays?.length ? `${atDays(f.offDays).replace(/^o/, 'O')} ni vadbe.` : ''
  return [pins ? `${pins}.` : '', off, `Teden: ${weekWords(f)}.`].filter(Boolean).join(' ')
}

const KOND_MIX = 'Kondicija raste najhitreje z mešanico lahkega kardia in kratkih intervalov.'
const KOND_EASY = 'Kondicijo zdaj gradiš z rednim lahkim kardiem — intervali pridejo, ko je to navada.'
/** (v3.48) Vrstica o kondiciji po tednu: o intervalih samo, ko jih teden ima (lahek kardio brez intervalov → druga vrstica). */
/** (v3.50) teden brez kardia: brez vrstice o kardiu in intervalih (prej tudi pri »Brez kardia«) */
const kondNote = (sessions?: readonly Pick<AgreedSession, 'type' | 'cardio'>[]): string | null =>
  sessions && !sessions.some(s => !isStrength(s)) ? null : sessions && !sessions.some(s => s.cardio === 'intervali') ? KOND_EASY : KOND_MIX
export function notesFor(aims: readonly FocusAim[], muscles: readonly Muscle[], sessions?: readonly Pick<AgreedSession, 'type' | 'cardio'>[]): string[] {
  const out: string[] = []
  // (v3.50) samo, ko je izbral trebuh ali six pack — ne pri »vitka in močna«
  if (muscles.includes('trebuh')) out.push('Trebušne mišice se vidijo pri nizkem deležu maščobe — vaje jih okrepijo, vidnost pa prinese prehrana.')
  if (aims.includes('hujsanje')) out.push('Hujšanje: zmeren deficit in dovolj beljakovin — tako gre dol maščoba, ne mišice.')
  const k = aims.includes('kondicija') ? kondNote(sessions) : null
  if (k) out.push(k)
  return out
}
/** (v3.48) Pojasnila po spremembi tedna (trener je npr. intervale začetniku zamenjal z lahkim kardiem): vrstica o kondiciji sledi tednu. */
export function fitNotes(notes: readonly string[], sessions: readonly Pick<AgreedSession, 'type' | 'cardio'>[]): string[] {
  return notes.map(n => (n === KOND_MIX || n === KOND_EASY ? kondNote(sessions) : n)).filter((n): n is string => !!n)
}

/**
 * Pogajanje brez AI: besede o dnevih (»torek in petek fitnes, tek v istem dnevu«, »v fitnes ne hodim ob sobotah«,
 * »ob torkih ne morem«) in hitri odgovori (več kardia, manj dni, krajše …) spremenijo teden po pravilih.
 * Vrne null, če odgovora ne razume.
 */
/** (v3.51) »ne maram teka«, »nočem kolesa«, »tek mi ne paše« = »brez teka« (C19) */
const DISLIKE = /(?:ne maram|no(?:č|c)em|ne (?:ž|z)elim|ne bi)\s+(?:ve(?:č|c)\s+)?(tek\p{L}*|te(?:č|c)\p{L}*|kol\p{L}*|fitnes\p{L}*|hoj\p{L}*)|(?<![\p{L}])(tek\p{L}*|kol\p{L}*|fitnes\p{L}*|hoj\p{L}*)\s+mi\s+ne\s+(?:pa(?:š|s)e|ustreza|le(?:ž|z)i|di(?:š|s)i)/u
const canonNo = (w: string) => (/^te/.test(w) ? 'teka' : /^kol/.test(w) ? 'kolesa' : /^fitnes/.test(w) ? 'fitnesa' : 'hoje')
/** (v3.51) »nočem nog«, »ne maram treninga nog« (C07) */
const NO_LEGS = /brez nog|ne nog|samo zgornj|le zgornj|(?:no(?:č|c)em|ne maram|ne (?:ž|z)elim|ne bi)\s+(?:\p{L}+\s+){0,2}nog/u
/** (v3.51) »nočem intervalov«, »ne bi tempa« (C07) */
const NO_FAST = /(?:brez|manj|no(?:č|c)em|ne maram|ne (?:ž|z)elim|ne bi)\s+(?:\p{L}+\s+){0,2}?(?:interval\p{L}*|temp(?:o|a|om)(?![\p{L}])|hitr\p{L}*)/u
/** (v3.51) »naj bo lažje«, »manj naporno«, »prenaporno je« (C50) */
const EASIER = /(?:naj bo|bolj|malo|raje)\s+la(?:ž|z)j\p{L}*|manj napor\p{L}*|prenapor\p{L}*|preve(?:č|c) napor\p{L}*|pre(?:te(?:ž|z)k)\p{L}*/u
const SPORT_OF = (w: string): FocusSport | null => (/^(?:tek|te(?:č|c))/.test(w) ? 'tek' : /^kol/.test(w) ? 'kolo' : /^fitnes/.test(w) ? 'fitnes' : /^(?:hoj|hrib|pohod)/.test(w) ? 'hribi' : /^doma|^vadb/.test(w) ? 'doma' : /^mo(?:č|c)/.test(w) ? 'fitnes' : null)
/** (v3.51) »samo fitnes«, »le tek« (C19) */
const ONLY_SPORT = /(?<![\p{L}])(?:samo|le|izklju(?:č|c)no)\s+(fitnes\p{L}*|tek\p{L}*|te(?:č|c)\p{L}*|kol\p{L}*|hoj\p{L}*|vadb\p{L}* doma)/u
/** (v3.51) »rad bi tudi kolo«, »dodaj moč«, »tudi fitnes« (C19) — »dodaj tek/kolo« ostane v »več kardia« */
const ALSO_SPORT = /(?<![\p{L}])(?:tudi|dodaj\p{L}*)\s+(?:\p{L}+\s+)?(mo(?:č|c)\p{L}*|fitnes\p{L}*|kol\p{L}*|tek\p{L}*|te(?:č|c)i)/u
/** (v3.51) »kardio raje na kolesu«, »kardio naj bo tek« (C19) */
const CARDIO_TO = /kardi\p{L}*\s+(?:raje|raj(?:š|s)i|naj bo|bi)\s+(?:\p{L}+\s+)?(?:na\s+|s\s+)?(kol\p{L}*|tek\p{L}*|te(?:č|c)\p{L}*|hoj\p{L}*|hrib\p{L}*)/u
export function ruleAdjust(f: Focus, say: string, age?: number | null): Focus | null {
  const t = say.toLowerCase().replace(new RegExp(DISLIKE.source, 'gu'), (_m, a?: string, b?: string) => `brez ${canonNo(a || b || '')}`)
  const keep = (next: Focus | null) => { if (next) { next.title = f.title; next.notes = f.notes; next.strategy = f.strategy ?? null } return next }
  // (v3.51) zdravje v pogajanju (C21): »imam visok pritisk«, »sem noseča« → omejitve, brez hitrih intervalov; pojasnilo z zdravnikom
  // (v3.51) brez nikalnice in druge osebe (»nimam visokega pritiska«, »mama ima …« — R3); oznake (»srce«) healthOf prebere nazaj (R2)
  const hl = healthSaid(t)
  if (hl.length) {
    const limits = [...new Set([...(f.limits ? f.limits.split(/,\s*/) : []), ...hl])].join(', ').slice(0, 200)
    const next = keep(normalizeFocus({ ...f, limits, sessions: f.sessions.map(x => (x.cardio === 'intervali' ? { ...x, cardio: 'tempo' as CardioKind } : x)) }, { age, by: f.by, now: f.at }))
    const all = healthOf(limits)
    if (next && all.length) next.notes = [...f.notes.filter(n => !/zdravnik/i.test(n)), healthNote(all)]
    return next
  }
  // (v3.50) bolečina ni prošnja za več nog (prej »noge me bolijo« → vadba za noge): koleno, hrbet ali rama gre v
  // omejitve (vaje jih izpustijo), sicer je brez AI ne razumem
  if (/(?<![\p{L}])(?:bol(?:i|ijo|el\p{L}*)|bole(?:č|c)\p{L}*)(?![\p{L}])|po(?:š|s)kod|nateg|zvin/u.test(t)) {
    const lim = limitsOf(t)
    if (!lim.length) return null
    return keep(normalizeFocus({ ...f, limits: [...new Set([...(f.limits ? f.limits.split(/,\s*/) : []), ...lim])].join(', ') }, { age, by: f.by, now: f.at }))
  }
  const byDays = applyDayWords(f, say, age)
  if (byDays) return byDays
  let s = f.sessions.map(x => ({ ...x }))
  const strength = isStrength
  const where = s.find(strength)?.type ?? (f.equipment.includes('fitnes') ? 'fitnes' : 'doma')
  const cardioType = (s.find(x => !strength(x))?.type ?? (f.sports.find(x => x === 'tek' || x === 'kolo' || x === 'hribi') || 'tek')) as FocusSport
  // indeksi se po vsakem izbrisu spremenijo → kardio po moči vsakič znova
  // (v3.49) ves teden kardio (kolesar): najprej izpade lahka vadba, ne dolga vožnja ali intervali
  const cardioOnly = !s.some(strength)
  const lastLoose = () => {
    const tails = tailsOf(s)
    if (cardioOnly) for (let i = s.length - 1; i >= 0; i--) if (!tails.has(i) && s[i]!.day == null && (s[i]!.cardio ?? 'lahko') === 'lahko') return i
    for (let i = s.length - 1; i >= 0; i--) if (!tails.has(i) && s[i]!.day == null) return i
    for (let i = s.length - 1; i >= 0; i--) if (!tails.has(i)) return i
    return -1
  }
  const dropOne = () => { const i = lastLoose(); if (i < 0) return; const tails = tailsOf(s); const gone = new Set([i, ...[...tails.entries()].filter(([, m]) => m === i).map(([j]) => j)]); s = s.filter((_, k) => !gone.has(k)) }
  // (v3.49) nov dan: ves teden kardio → kardio (prej je kolesar dobil »vadbo doma«), trajanje po vrsti (kolo 1 h)
  const extraDay = (): AgreedSession => (cardioOnly || trainingDays(s) % 2 ? { type: cardioType, cardio: 'lahko', min: cardioOnly ? cardioMin(cardioType, 'lahko', null) : 40 } : { type: where, part: 'celo', min: 50 })
  // (v3.49) več ali manj časa: vse vadbe ~15 % daljše ali krajše (dnevi ostanejo)
  const scale = (k: number) => { s = s.map(x => (x.after ? x : { ...x, min: Math.max(15, Math.round((x.min * k) / 5) * 5) })) }
  const nDays0 = /(\d)\s*(?:dni|dneva|dan|krat|x)(?![\p{L}])/u.exec(t)
  // (v3.51) tudi z besedo (»tri dni«, »raje dva dni«) — C18
  const nDays = nDays0 ? +nDays0[1]! : explicitDays(say)
  const moreTime = /(?:več|vec)\s+(?:ur(?:e|o)?(?![\p{L}])|časa|casa)/u.test(t) || (cardioOnly && /več kardi|vec kardi/.test(t))
  const lessTime = /manj\s+(?:ur(?:e|o)?(?![\p{L}])|časa|casa)/u.test(t) || (cardioOnly && /manj kardi/.test(t))
  // (v3.49) »hoja in tek izmenično«, »še ne zmorem teči 25 minut«: teki postanejo tek in hoja (vsak teden več teka);
  // nikalnica ob hoji (»hoja me ne zanima«, »brez hoje«) ni prošnja za hojo
  const noWalk = /več tek|vec tek|manj hoj|brez hoj|hoj\p{L}*\s+(?:me\s+|pa\s+)?ne(?![\p{L}])|ne\s+(?:maram|želim|zelim)\s+hoj/u.test(t)
  const walkAsk = (/hoj\p{L}*.*te[kč]|te[kč]\p{L}*.*hoj|izmeni(?:č|c)n/u.test(t) || (/ne zmorem|pretež|pretez/u.test(t) && /te[kč]/u.test(t))) && !noWalk
  // (v3.50) število vadb po športu (»fitnes raje 3x«, »2x tek«) — prej je »3x« štelo kot 3 dni (»Prav.« brez spremembe)
  const counts: Partial<Record<FocusSport, number>> = { ...explicitCounts(say) }
  for (const c of clauses(say)) {
    const sp = sportsIn(c), m = /(?<![\d.,])([1-6])\s*(?:x|×|krat)(?![\p{L}\d])|(?<![\p{L}])(enkrat|dvakrat|trikrat|(?:š|s)tirikrat|petkrat)(?![\p{L}])/u.exec(c)
    if (sp.length === 1 && m && !dayHits(c, false).length && counts[sp[0]!] == null) counts[sp[0]!] = m[1] ? +m[1] : ({ enkrat: 1, dvakrat: 2, trikrat: 3, štirikrat: 4, stirikrat: 4, petkrat: 5 } as Record<string, number>)[m[2]!]!
  }
  // (v3.50) »namesto teka kolo«, »kolo namesto teka«: vrsta se zamenja (trajanje ostane)
  const swap = clauses(say).map(c => { const from = insteadIn(c); return { from: from[0], to: sportsIn(c).find(x => !from.includes(x)) } }).find(x => x.from && x.to && x.from !== x.to)
  // (v3.50) čas ene vrste (»tek naj bo 30 min«, »fitnes 45 min«) brez dni
  const durs = clauses(say).map(c => ({ sp: sportsIn(c), min: minutesIn(c), days: dayHits(c, false).length })).filter(x => x.sp.length === 1 && x.min && !x.days && !ADD.test(say.toLowerCase()))
  const noDays = !daysIn(say).length
  // (v3.51) čas na vadbo brez športa (»imam samo 30 minut«, »vadbe naj bodo 30 min«, »uro na vadbo«) — C18
  const perMin = durs.length || sportsIn(normText(say)).length ? null : perSessionIn(say.replace(/(?<![\p{L}\d])(?:eno\s+)?uro(?![\p{L}])/giu, '60 min').replace(/(?<![\p{L}])pol ure(?![\p{L}])/giu, '30 min'))
  const cardioTo = CARDIO_TO.exec(t), onlySp = ONLY_SPORT.exec(t), alsoSp = ALSO_SPORT.exec(t)
  if (Object.keys(counts).length) {
    for (const [type, k] of Object.entries(counts) as [FocusSport, number][]) {
      const mine = () => { const tails = tailsOf(s); return s.map((_, i) => i).filter(i => s[i]!.type === type && !tails.has(i)) }
      for (let g = 0; g < 7 && mine().length > k; g++) {
        const ids = mine(), i = [...ids].reverse().find(j => s[j]!.day == null) ?? ids[ids.length - 1]!
        const tails = tailsOf(s); const gone = new Set([i, ...[...tails.entries()].filter(([, m]) => m === i).map(([j]) => j)])
        s = s.filter((_, j) => !gone.has(j))
      }
      for (let g = 0; g < 7 && mine().length < k && trainingDays(s) < 6; g++) s.push(isStrength({ type }) ? { type, part: 'celo', min: s.find(strength)?.min ?? 50 } : { type, cardio: 'lahko', min: cardioMin(type, 'lahko', s.find(x => x.type === type)?.min ?? null) })
    }
  }
  else if (moreTime) scale(1.15)
  else if (lessTime) scale(0.85)
  else if (walkAsk && s.some(x => x.type === 'tek')) s = s.map(x => (x.type === 'tek' ? { ...x, cardio: 'lahko', walk: true } : x))
  else if (swap && s.some(x => x.type === swap.from)) {
    const to = swap.to!
    s = s.map(x => (x.type !== swap.from ? x : isStrength({ type: to }) ? { type: to, part: 'celo', min: Math.max(30, x.min) }
      : { type: to, cardio: to === 'hribi' || isStrength(x) ? 'lahko' : x.cardio ?? 'lahko', min: to === 'kolo' || to === 'hribi' ? Math.max(45, x.min) : x.min, ...(x.day != null ? { day: x.day } : {}), ...(x.after ? { after: true } : {}) }))
  }
  // (v3.50) »brez intervalov« / »želim intervale«, »več tempa«: prvi lahek kardio postane hitrejši (trener ga začetniku vrne)
  // (v3.51) »kardio raje na kolesu«: vrsta kardia se zamenja (C19)
  else if (cardioTo && SPORT_OF(cardioTo[1]!) && s.some(x => !strength(x) && x.type !== SPORT_OF(cardioTo[1]!))) {
    const to = SPORT_OF(cardioTo[1]!)!
    s = s.map(x => { if (strength(x) || x.type === to) return x; const { walk: _w, ...r } = x; return { ...r, type: to, cardio: to === 'hribi' ? 'lahko' : x.cardio ?? 'lahko', min: to === 'kolo' || to === 'hribi' ? Math.max(45, x.min) : x.min } })
  }
  // »nočem intervalov« (v3.51: tudi »nočem«, »ne bi« — prej je dodalo intervale, C07)
  else if (NO_FAST.test(t)) s = s.map(x => (x.cardio === 'intervali' || x.cardio === 'tempo' ? { ...x, cardio: 'lahko' } : x))
  // (v3.51) »naj bo lažje«: brez hitrih delov; če jih ni, vadbe ~10 % krajše (C50)
  else if (EASIER.test(t)) {
    const fast = (x: AgreedSession) => x.cardio === 'intervali' || x.cardio === 'tempo'
    if (s.some(fast)) s = s.map(x => (fast(x) ? { ...x, cardio: 'lahko' } : x)); else scale(0.9)
  }
  // (v3.51) »samo fitnes«: ostane samo ta vrsta (če je ni, postane vsa vadba te vrste) — C19
  else if (onlySp && SPORT_OF(onlySp[1]!) && noDays) {
    const to = SPORT_OF(onlySp[1]!)!, mineOf = (x: AgreedSession) => x.type === to || (isStrength({ type: to }) && strength(x))
    s = s.some(mineOf) ? s.filter(mineOf).map(x => { if (!x.after) return x; const { after: _a, ...r } = x; return r })
      : s.filter(x => !x.after).map(x => (isStrength({ type: to }) ? { type: to, part: 'celo' as SessionPart, min: Math.max(30, x.min) } : { type: to, cardio: 'lahko' as CardioKind, min: to === 'kolo' || to === 'hribi' ? Math.max(45, x.min) : x.min }))
  }
  // (v3.51) »rad bi tudi kolo«, »dodaj moč«: ena seja te vrste (C19)
  else if (alsoSp && SPORT_OF(alsoSp[1]!) && noDays && (isStrength({ type: SPORT_OF(alsoSp[1]!)! }) || /tudi/.test(alsoSp[0]!))) {
    const to = SPORT_OF(alsoSp[1]!)!
    // »moč« = kjer že dela moč (ali kar ima: fitnes / doma), »fitnes« = fitnes
    const add: AgreedSession = isStrength({ type: to }) ? { type: /^mo/.test(alsoSp[1]!) ? where : 'fitnes', part: 'celo', min: s.find(strength)?.min ?? 45 } : { type: to, cardio: 'lahko', min: cardioMin(to, 'lahko', s.find(x => x.type === to)?.min ?? null) }
    const i = s.findIndex(x => !x.after && x.day == null && x.type !== to && (x.cardio ?? 'lahko') === 'lahko' && !strength(x) === !isStrength(add))
    if (trainingDays(s) >= 6 && i >= 0) s[i] = add; else s.push(add)
  }
  else if (/(?<![\p{L}])(?:interval\p{L}*|temp(?:o|a|om)(?![\p{L}])|hitrej(?:š|s)\p{L}*\s+(?:tek|vo(?:ž|z)nj|kardi|trening))/u.test(t)) {
    const kind: CardioKind = /temp(?:o|a|om)(?![\p{L}])/u.test(t) ? 'tempo' : 'intervali'
    const i = s.findIndex(x => !strength(x) && !x.after && x.type !== 'hribi' && (x.cardio ?? 'lahko') === 'lahko')
    if (i >= 0) { const { walk: _w, ...x } = s[i]!; s[i] = { ...x, cardio: kind } }
    else if (!s.some(x => x.cardio === kind)) s.push({ type: cardioType === 'hribi' ? 'tek' : cardioType, cardio: kind, min: 40 })
  }
  else if (noDays && /brez (?:fitnes\p{L}*|mo(?:č|c)i|vadb\p{L}* doma|ute(?:ž|z)\p{L}*)/u.test(t)) {
    if (!s.some(x => !strength(x))) return null
    s = s.filter(x => !strength(x)).map(x => { if (!x.after) return x; const { after: _a, ...r } = x; return r })
  }
  else if (noDays && /brez (?:hoj\p{L}*|hrib\p{L}*|pohod\p{L}*)/u.test(t)) s = s.some(x => x.type === 'hribi') && s.some(x => x.type !== 'hribi') ? s.filter(x => x.type !== 'hribi') : s.map(x => { if (!x.walk) return x; const { walk: _w, ...r } = x; return r })
  else if (/(?:dodaj\p{L}*|(?:š|s)e)\s+(?:(?:en\p{L}*|kak(?:š|s)n\p{L}*)\s+)?(?:hoj\p{L}*|sprehod\p{L}*|pohod\p{L}*)|(?:več|vec)\s+hoj/u.test(t)) s.push({ type: 'hribi', cardio: 'lahko', min: 45 })
  else if (durs.length) for (const d of durs) s = s.map(x => (x.type === d.sp[0] && !x.after ? { ...x, min: d.min! } : x))
  else if (perMin) { const m = Math.max(15, Math.min(300, Math.round(perMin.hi / 5) * 5)); s = s.map(x => (x.after ? x : { ...x, min: m })) }
  else if (/(?:več|vec)\s+po(?:č|c)itk|manj trening/u.test(t)) { if (trainingDays(s) > 1) dropOne() }
  else if (/več kardi|vec kardi|več tek|vec tek|dodaj tek|več kolesa|vec kolesa|dodaj kolo|dodaj kardi/.test(t)) {
    const type = /kolo|koles/.test(t) ? 'kolo' : /tek/.test(t) ? 'tek' : cardioType
    AFTER_REF.lastIndex = 0
    const afterStrength = AFTER_REF.test(t) || /po vadbi|v istem dnevu|isti dan|zraven|vmes/.test(t); AFTER_REF.lastIndex = 0
    const withTail = new Set(tailsOf(s).values())
    const mains = s.map((_, i) => i).filter(i => strength(s[i]!) && !withTail.has(i))
    if (afterStrength && mains.length) {
      // »dodaj tek po fitnesu«: kardio takoj po vsaki seji moči, ki ga še nima (ni nov dan)
      const out: AgreedSession[] = []
      s.forEach((x, i) => { out.push(x); if (mains.includes(i)) out.push({ type, cardio: 'lahko', min: 20, after: true }) })
      s = out
    } else {
      const i = s.findIndex(strength)
      if (trainingDays(s) >= 6 && i >= 0) s[i] = { type, cardio: 'lahko', min: 40 }; else s.push({ type, cardio: 'lahko', min: 40 })
    }
  }
  else if (/manj kardi|manj tek|brez tek|brez kardi|manj kolesa|brez kolesa/.test(t)) { const type = /kolo|koles/.test(t) ? 'kolo' : /tek/.test(t) ? 'tek' : null; const all = /brez/.test(t); const idx = s.map((_, i) => i).filter(i => !strength(s[i]!) && (!type || s[i]!.type === type)); const gone = new Set(all ? idx : idx.slice(-1))
    if (gone.size && gone.size < s.length) s = s.filter((_, i) => !gone.has(i))
    // (v3.51) »brez teka«, ko je tek ves teden (C30): namesto njega hoja (pri kolesu ali kardiu vadba doma) — prej »Tako že je«
    else if (all && gone.size && gone.size === s.length) s = s.map(x => (type === 'tek' ? { type: 'hribi', cardio: 'lahko', min: Math.max(30, x.min), ...(x.day != null ? { day: x.day } : {}) } : { type: 'doma', part: 'celo', min: Math.max(30, Math.min(60, x.min)), ...(x.day != null ? { day: x.day } : {}) }))
  }
  else if (/več moč|vec moc|več fitnes|vec fitnes/.test(t)) { const i = s.findIndex(x => !strength(x) && !x.after); if (i >= 0 && trainingDays(s) >= 5) s[i] = { type: where, part: 'celo', min: 50 }; else s.push({ type: where, part: 'celo', min: 50 }) }
  else if (nDays) { const want = Math.max(1, Math.min(6, nDays)); while (trainingDays(s) > want) { const before = s.length; dropOne(); if (s.length === before) break } while (trainingDays(s) < want && s.length < 7) s.push(extraDay()) }
  else if (/manj dni|manj vadb/.test(t)) { if (trainingDays(s) > 1) dropOne() }
  else if (/več dni|vec dni|več vadb|vec vadb/.test(t)) { if (trainingDays(s) < 6) s.push(extraDay()) }
  else if (/krajš|krajs/.test(t)) s = s.map(x => ({ ...x, min: Math.max(20, x.min - 10) }))
  else if (/daljš|daljs/.test(t)) s = s.map(x => ({ ...x, min: x.min + 10 }))
  else if (NO_LEGS.test(t)) s = s.map(x => (strength(x) && (x.part === 'noge' || x.part === 'spodnji' || x.part === 'celo') ? { ...x, part: 'zgornji' } : x))
  else if (/nog/.test(t)) { const i = s.findIndex(x => strength(x) && x.part !== 'spodnji' && x.part !== 'noge'); if (i >= 0) s[i] = { ...s[i]!, part: 'noge' } }
  else return null
  if (!s.length) return null
  return keep(normalizeFocus({ ...f, sessions: s, sports: [...new Set(s.map(x => x.type))] }, { age, by: f.by, now: f.at }))
}
/** (v3.49) Popravek po pravilih z besedami (številke tedna zaslon doda enkrat: »Spremenil: …«). */
export function adjustNote(prev: Pick<Focus, 'sessions'> & Partial<Pick<Focus, 'limits'>>, next: Pick<Focus, 'sessions'> & Partial<Pick<Focus, 'limits'>>): string {
  // minute iz prve stopnje lestvice (tek in hoja po pogajanju vedno začne na njej) — prej »1 min teka in 2 min hoje«,
  // ki je ni na nobeni stopnji
  const [, run, walk] = RUN_WALK[0]!
  if (next.sessions.some(s => s.walk) && !prev.sessions.some(s => s.walk)) return `Prav — teki so zdaj tek in hoja: najprej ${fmtStep(run)} teka in ${fmtStep(walk)} hoje, vsak teden več teka.`
  // (v3.51) odgovor pove, kaj je drugače (C07, C21, C30, C18) — prej samo »Prav.«
  const nh = healthOf(next.limits).filter(h => !healthOf(prev.limits).includes(h))
  if (nh.length) return `Prav — ker ${nh.map(h => HEALTH_SAY[h] ?? `imaš ${h}`).join(' in ')}, je teden brez hitrih intervalov in težkih serij. Pred začetkom se posvetuj z zdravnikom.`
  const fast = (x: Pick<AgreedSession, 'cardio'>) => x.cardio === 'intervali' || x.cardio === 'tempo'
  if (prev.sessions.some(fast) && !next.sessions.some(fast)) return 'Prav — brez intervalov, ves kardio je lahek.'
  const legs = (x: Pick<AgreedSession, 'part'>) => x.part === 'noge' || x.part === 'spodnji'
  if (prev.sessions.some(legs) && !next.sessions.some(legs) && next.sessions.some(isStrength)) return 'Prav — brez vadbe za noge, moč je za zgornji del in trup.'
  const types = (x: Pick<Focus, 'sessions'>) => new Set(x.sessions.map(s => s.type))
  const pt = types(prev), nt = types(next)
  if (pt.size === 1 && nt.size === 1 && [...pt][0] !== [...nt][0]) {
    const was = [...pt][0]!, now = [...nt][0]!
    const W: Record<FocusSport, string> = { tek: 'teka', kolo: 'kolesa', fitnes: 'fitnesa', doma: 'vadbe doma', hribi: 'hoje' }
    const N: Record<FocusSport, string> = { tek: 'tek', kolo: 'kolo', fitnes: 'fitnes', doma: 'vadba doma', hribi: 'hoja' }
    return `Prav — namesto ${W[was]} je zdaj ${N[now]}. Če želiš raje kaj drugega (kolo, hoja, vadba doma), povej.`
  }
  const mins = [...new Set(next.sessions.filter(s => !s.after).map(s => s.min))]
  if (mins.length === 1 && prev.sessions.some(s => !s.after && s.min !== mins[0]) && prev.sessions.length === next.sessions.length) return `Prav — vadbe so zdaj po ${mins[0]} min.`
  return 'Prav.'
}

/** Strategija brez AI. */
export function ruleStrategy(f: Focus, n: { kcal: number | null; proteinG: number | null; deficit: number }): string {
  // brez vrstice »teden: mešanica. Bloki po 4 tedne …« (v3.48) — teden in bloki so v Mojem dogovoru in vodniku že nad strategijo
  const out: string[] = []
  // (v3.49) kilogrami samo z opremo, »en hitrejši« samo z intervali ali tempom; kalorije kot kazalec, primanjkljaj kot številka
  if (f.sessions.some(s => s.type === 'fitnes' || s.type === 'doma')) out.push(kgStrength(f) ? '– Moč: vpisuj kilograme — ko narediš vse ponovitve, je naslednjič teža višja. Tako mišice dobijo razlog, da ostanejo in rastejo.' : `– ${STRAT_REPS}`)
  if (f.sessions.some(s => s.type === 'tek' || s.type === 'kolo')) out.push(fastCardio(f.sessions) ? '– Kardio: večinoma lahko, en hitrejši trening na teden — kondicija raste brez izčrpanosti.' : `– ${STRAT_EASY}`)
  if (n.kcal) out.push(`– Prehrana: kalorije po dnevu so v Prehrani (na dan treninga več)${n.deficit ? `, primanjkljaj ~${n.deficit} kcal` : ''}${n.proteinG ? `, beljakovine ~${n.proteinG} g` : ''}.`)
  out.push('– Spanec 7–9 h: ko spiš manj, se napredek ustavi prej kot pri izpuščenem treningu.')
  // (v3.50) po tem, kar dogovor ima: kilogrami samo z utežmi, izkušenemu ne »navada in tehnika«
  const shows = kgStrength(f) ? 'na kilogramih pri vajah in na kondiciji' : f.sessions.some(isStrength) ? 'na ponovitvah in kondiciji' : 'na kondiciji'
  out.push(f.aims.includes('hujsanje') ? '– Pričakuj 0,3–0,5 kg na teden; prve 4 tedne se pozna predvsem moč in energija.' : `– Prvi 4 tedni: ${f.level >= 3 ? 'ritem novega tedna' : 'navada in tehnika'}; po 8–12 tednih se napredek pozna ${shows}.`)
  return out.join('\n')
}
