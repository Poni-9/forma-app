import type { AgreedSession, CardioKind, Focus, FocusAim, FocusEquip, FocusSport, Muscle, SessionPart } from '../types'
import { normalizeFocus, titleOf, weekLine, mixLine, isStrength, tailsOf, trainingDays } from './model'
import { DAY_OPTS, DAY_SHORT, atDays } from './choices'
import { weekWords, pinsWords } from '../training/focusPlan'
import type { QA, QuestionsOut } from '../ai/focusAi'

/**
 * REZERVA BREZ AI: ko AI ne odgovori (ni povezave, poln dnevni limit, napaka), gre pogovor naprej z vprašanji in
 * predlogom po pravilih — začetek načrta mora vedno delati. Pogajanje brez AI razume hitre odgovore (več, manj …).
 */
export function ruleQuestions(wish: string): QuestionsOut {
  const w = wish.toLowerCase()
  const qs: QuestionsOut['questions'] = [
    { id: 'dni', text: 'Koliko dni na teden lahko treniraš?', multi: false, options: ['2', '3', '4', '5', '6'], other: false },
    { id: 'cas', text: 'Koliko časa imaš za eno vadbo?', multi: false, options: ['30 min', '45 min', '60 min', '90 min'], other: false },
    { id: 'kje', text: 'Kje boš vadil?', multi: true, options: ['V fitnesu', 'Doma brez opreme', 'Doma z ročkami', 'Doma z elastikami', 'Imam drog za zgibe'], other: false },
    { id: 'kardio', text: 'Kateri kardio ti ustreza?', multi: true, options: ['Tek', 'Kolo', 'Hribi', 'Brez kardia'], other: false },
    { id: 'izkusnje', text: 'Koliko izkušenj imaš z vadbo?', multi: false, options: ['Začenjam', 'Nekaj izkušenj', 'Treniram redno'], other: false },
  ]
  if (!/(mišic|misic|moč|moc|hujš|husj|shujš|kondic|vzdržlj|definic|vitk|six|trebuh)/.test(w)) qs.push({ id: 'cilji', text: 'Kaj ti je najpomembnejše?', multi: true, options: ['Več mišic', 'Več moči', 'Manj maščobe', 'Kondicija', 'Zdravje'], other: false })
  qs.push({ id: 'nedni', text: 'Kateri dnevi ti zagotovo ne gredo?', multi: true, options: [...DAY_OPTS, 'Vsi gredo'], other: false })
  qs.push({ id: 'poskodbe', text: 'Te kaj boli ali imaš poškodbo?', multi: true, options: ['Ne', 'Koleno', 'Hrbet', 'Rama'], other: true })
  return { understood: '', questions: qs.slice(0, 8), enough: true }
}

export { DAY_OPTS }
/* ---------- besede o dnevih, vadbah in času ---------- */
const word = (w: string) => new RegExp(`(?:^|[^\\p{L}])(?:${w})(?![\\p{L}])`, 'gu')
// cele besede tudi v pogovornem jeziku (»pondelk«, »tork«, »četrk«, »sobta«); »torej«, »petkrat«, »četrt ure«, »sredi tedna« niso dnevi
const END = '(?:a|u|om|ih|i|e|ov|ah)?'
const DAY_SRC = [`pon[a-zč]{0,3}del\\p{L}*`, `tor(?:ek|k${END})`, `sred(?:a|o|e|ah|ami)`, `(?:č|c)etr(?:t)?(?:ek|k${END})`, `pet(?:ek|k${END})`, `sobo?t\\p{L}*`, `nede?lj\\p{L}*`]
const DAY_WORD = DAY_SRC.map(word)
// okrajšave: pon, tor, sre, čet, sob, ned so enoznačne tudi v prostem besedilu; »pet« je tam navadno število —
// velja samo v izbiri (short) ali v naštevanju ob drugem dnevu (»tor, pet«), ne pred enoto (»pet km«)
const ABBR_SRC = ['pon', 'tor', 'sre', '(?:č|c)et', 'pet', 'sob', 'ned']
const DAY_ABBR = ABBR_SRC.map(w => word(`${w}\\.?`))
const WEEKEND = word('vikend\\p{L}*|kon(?:ec|cu) tedna')
const UNIT_AFTER = /^\.?\s*(?:km|ur[aei]?|h\b|min|minut|dni|dnev|krat|x|×|do\b|-|–|km\b)/u
const DAY_ANY = `(?:${[...DAY_SRC, ...ABBR_SRC.map(w => `${w}\\.?`), 'vikend\\p{L}*'].join('|')})`
// »torek, četrtek in petek« → »torek in četrtek in petek« (vejica v naštevanju dni ni nov del stavka)
const DAY_LIST_COMMA = new RegExp(`(${DAY_ANY})\\s*,\\s*(?=(?:(?:in|pa|ter|ali)\\s+)?(?:(?:v|ob|na)\\s+)?${DAY_ANY}(?![\\p{L}]))`, 'giu')
// »od ponedeljka do petka« → vsi dnevi vmes
const DAY_RANGE = new RegExp(`od\\s+(${DAY_ANY})\\s+do\\s+(${DAY_ANY})(?![\\p{L}])`, 'giu')
function dayHits(t: string, short: boolean): { d: number; at: number; end: number }[] {
  const out: { d: number; at: number; end: number }[] = []
  const scan = (r: RegExp, ds: number[]) => { r.lastIndex = 0; for (let m = r.exec(t); m; m = r.exec(t)) { const lead = m[0].length - m[0].trimStart().length; ds.forEach(d => out.push({ d, at: m!.index + lead, end: m!.index + m![0].length })) } }
  DAY_WORD.forEach((r, i) => scan(r, [i]))
  DAY_ABBR.forEach((r, i) => { if (i !== 4 || short) scan(r, [i]) })
  scan(WEEKEND, [5, 6])
  if (!short) {
    const pet: { d: number; at: number; end: number }[] = []
    DAY_ABBR[4]!.lastIndex = 0
    for (let m = DAY_ABBR[4]!.exec(t); m; m = DAY_ABBR[4]!.exec(t)) {
      const lead = m[0].length - m[0].trimStart().length, at = m.index + lead, end = m.index + m[0].length
      if (out.some(h => Math.abs(h.at - at) <= 9) && !UNIT_AFTER.test(t.slice(end, end + 8))) pet.push({ d: 4, at, end })
    }
    out.push(...pet)
  }
  return out
}
/** en dan iz besede (za obsege) */
const dayOf = (w: string): number => { const h = dayHits(` ${w.toLowerCase()}`, true); return h.length ? h[0]!.d : -1 }
/** »od ponedeljka do petka« → »pon in tor in sre in čet in pet«; vejice v naštevanju dni → »in«; decimalke ostanejo cele */
function normText(text: string): string {
  return text.toLowerCase()
    .replace(/(\d)[.,](\d)/g, '$1·$2')
    .replace(DAY_RANGE, (_m, a: string, b: string) => { const x = dayOf(a), y = dayOf(b); if (x < 0 || y < 0) return _m; const ds: string[] = []; for (let d = x; ; d = (d + 1) % 7) { ds.push(DAY_SHORT[d]!); if (d === y || ds.length > 7) break } return ds.join(' in ') })
    .replace(DAY_LIST_COMMA, '$1 in ')
}
/** »Tor, Čet« (izbira, short) ali »ob torkih in četrtkih«, »čez vikend«, »od pon do sre« → [1, 3] … (0 = pon … 6 = ned) */
export function daysIn(text: string, short = false): number[] {
  return [...new Set(dayHits(normText(text), short).map(h => h.d))].sort((a, b) => a - b)
}
// »iz torka na sredo«, »namesto torka sreda«, »ne v torek, ampak v sredo«: torek je izvor, ne cilj
const FROM = /(?:^|[^\p{L}])(?:iz|z|s|namesto|od|ne|ne v|ne ob)\s*$/u
// »iz torka in petka na sredo«: dan za »in« takoj za izvornim dnevom je tudi izvor (ne pa »na sredo«)
const JOIN = /^\s*(?:in|pa|ter|ali)\s+$/u
function splitDays(t: string): { src: number[]; dst: number[] } {
  const hits = dayHits(t, false).sort((a, b) => a.at - b.at)
  const src: number[] = [], dst: number[] = []
  const isSrc: boolean[] = []
  hits.forEach((h, k) => {
    const p = k > 0 ? hits[k - 1]! : null
    const s = FROM.test(t.slice(Math.max(0, h.at - 10), h.at)) || (p != null && isSrc[k - 1] === true && JOIN.test(t.slice(p.end, h.at)))
    isSrc.push(s)
    if (s) src.push(h.d); else dst.push(h.d)
  })
  return { src: [...new Set(src)], dst: [...new Set(dst)].sort((a, b) => a - b) }
}
const srcDays = (t: string): number[] => splitDays(t).src
/** ciljni dnevi v delu stavka (brez izvornih: »iz torka«, »namesto torka«, »ne v torek«) */
const targetDays = (t: string): number[] => splitDays(t).dst
// nimam časa (ta dan ni vadbe)
const NO_TIME = /ne (?:morem|gre|utegnem|pridem|bom mog\p{L}*|bo (?:ni(?:č|c)|n(?:č|c)|vadbe|treninga))|naj ne bo|nimam (?:časa|casa)|ni (?:časa|casa)|nisem (?:doma|prost\p{L}*)|zaseden\p{L}*|naj bo prost\p{L}*|(?:^|[^\p{L}])prost[aoi]?(?![\p{L}])|po(?:č|c)itek|brez (?:vadbe|treninga)|(?:^|[^\p{L}])fraj(?![\p{L}])|tudi ne(?![\p{L}])/gu
// lahko (ta dan gre) — »ne gre« ni »gre«
const CAN = /(?:^|[^\p{L}])(?:lahko|gre|imam (?:čas|cas)\p{L}*|sem prost\p{L}*|ustreza|pa(?:š|s)e)(?![\p{L}])/gu
const canHits = (c: string): number[] => [...c.matchAll(CAN)].filter(m => !/(?:^|\s)ne\s*$/.test(c.slice(Math.max(0, m.index! - 4), m.index! + 1))).map(m => m.index!)
// te vadbe ne delam (ta dan ali sploh)
const NOT_GO = /ne hodim|ne grem|ne telovadim|ne delam|ne treniram|no(?:č|c)em|ne (?:morem|gre|utegnem)/u
const SPORT_RX: [FocusSport, RegExp][] = [
  ['fitnes', word('fitnes\\p{L}*|gym|teretan\\p{L}*')],
  ['doma', word('doma|doma(?:č|c)\\p{L}*|brez opreme')],
  ['tek', word('tek(?:a|u|om|i|ov|e)?|te(?:č|c)(?:t|i|em|e(?:š|s)|e|imo|ete|ejo)?|tekel|tekla|tekat\\p{L}*|tekanj\\p{L}*|lauf\\p{L}*')],
  ['kolo', word('kol(?:o|esa|esu|esom|es|esar\\p{L}*)|bicikl\\p{L}*')],
  ['hribi', word('hrib\\p{L}*|pohod\\p{L}*|planin\\p{L}*')],
]
// »sem doma«, »nisem doma«, »delam doma« je o tem, kje si — ne vadba doma
const AT_HOME = /(?:^|[^\p{L}])(?:sem|nisem|bom|nismo|bomo|ni|ostanem|ostal[aie]?|grem|pridem|delam|od)\s+doma(?![\p{L}])/u
const HOME_TRAIN = /vadb\p{L}* doma|doma(?:č|c)\p{L}* vadb|brez opreme|doma (?:vadim|treniram|telovadim|z ročk|z utež)/u
// vadba za »namesto«, »brez«, »ne« je izvor, ne cilj (»tek namesto kolesa«)
const NOT_THIS = /(?:^|[^\p{L}])(?:namesto|brez|ne)\s*$/u
/** vadbe v delu stavka (brez tistih za »namesto / brez«) */
function sportsIn(t: string): FocusSport[] {
  const out: FocusSport[] = []
  for (const [k, rx] of SPORT_RX) {
    rx.lastIndex = 0
    const hits = [...t.matchAll(rx)].map(m => m.index! + (m[0].length - m[0].trimStart().length))
    rx.lastIndex = 0
    if (!hits.length) continue
    if (k === 'doma' && AT_HOME.test(t) && !HOME_TRAIN.test(t)) continue
    if (hits.every(at => NOT_THIS.test(t.slice(Math.max(0, at - 9), at)))) continue
    out.push(k)
  }
  return out
}
const SAME = /(?:^|[^\p{L}])(?:ist[iaoe]|istem|istih|enak\p{L}*|takrat|tist[iaoe])(?![\p{L}])/u
const AFTER = /po (?:fitnes\p{L}*|vadbi|mo(?:č|c)i|treningu|ute(?:ž|z)\p{L}*)|zraven|skupaj|v enem|(?:^|[^\p{L}])vmes(?![\p{L}])/u
const REST = /(?:^|[^\p{L}])(?:ostal\p{L}*|preostal\p{L}*|drug[ei] dn\p{L}*)(?![\p{L}])/u
const MOVE = new RegExp(`premakn\\p{L}*|prestav\\p{L}*|(?:^|[^\\p{L}])(?:namesto|iz|z|s)\\s+${DAY_ANY}(?![\\p{L}])`, 'u')
const ONLY = /(?:^|[^\p{L}])(?:samo|le|to(?:č|c)no|izklju(?:č|c)no)(?![\p{L}])/u
const hasNo = (c: string) => { NO_TIME.lastIndex = 0; const r = NO_TIME.test(c); NO_TIME.lastIndex = 0; return r }
/** stavki in deli stavkov (vejica, podpičje): vsaka vrstica je en pomen; naštevanje dni z vejicami ostane skupaj */
const clauses = (text: string): string[] => normText(text).split(/[.;!?\n,]+/).map(c => c.trim()).filter(Boolean)

/**
 * Dnevi brez časa iz besed: dan velja za »ne gre«, če je v istem delu stavka »ne morem / nimam časa / naj ne bo nič«
 * in ni v njem besede »lahko« bliže dnevu; del stavka, ki omenja vadbo (»v fitnes ne hodim ob sobotah«), ni cel dan
 * brez časa — to je stvar te vadbe (notOnIn). (»ob torkih ne morem, ob petkih pa lahko« → [1]; »ob petkih pa ne morem« → [4])
 */
export function offDaysIn(text: string): number[] {
  const out = new Set<number>()
  for (const c of clauses(text)) {
    if (!hasNo(c) || sportsIn(c).length) continue
    const no = [...c.matchAll(NO_TIME)].map(m => m.index!)
    const yes = canHits(c)
    const dist = (at: number, xs: number[]) => Math.min(Infinity, ...xs.map(x => Math.abs(x - at)))
    for (const h of dayHits(c, false)) if (dist(h.at, no) <= dist(h.at, yes)) out.add(h.d)
  }
  return [...out].sort((a, b) => a - b)
}
/** »ob torkih spet lahko«, »v sredo pa lahko« → dnevi, ki spet gredo (deli stavka z »lahko« in brez »ne morem«) */
export function canDaysIn(text: string): number[] {
  const out = new Set<number>()
  for (const c of clauses(text)) if (!hasNo(c) && canHits(c).length && !NOT_GO.test(c)) daysIn(c).forEach(d => out.add(d))
  return [...out].sort((a, b) => a - b)
}
/** »v fitnes ne hodim sobote, nedelje, torka …«, »ob sredah nimam časa za tek« → vadba te vrste ta dan ne gre. */
export function notOnIn(text: string): Map<FocusSport, number[]> {
  const out = new Map<FocusSport, number[]>()
  for (const c of clauses(text)) {
    if (!(NOT_GO.test(c) || hasNo(c))) continue
    const ds = daysIn(c), sp = sportsIn(c)
    if (ds.length) sp.forEach(x => out.set(x, [...new Set([...(out.get(x) || []), ...ds])].sort((a, b) => a - b)))
  }
  return out
}
/** trajanje v delu stavka (»20 min teka«, »1,5 h«, »2 uri«) */
function minutesIn(c: string): number | null {
  const m = /(\d{2,3})\s*min/.exec(c); if (m) return +m[1]!
  const h = /(\d(?:·\d)?)\s*(?:h|ur[aeio]?|uri)(?![\p{L}])/u.exec(c); if (h) return Math.round(parseFloat(h[1]!.replace('·', '.')) * 60)
  return null
}
const cardioKindIn = (c: string): CardioKind => (/dolg/.test(c) ? 'dolgo' : /interval/.test(c) ? 'intervali' : /tempo/.test(c) ? 'tempo' : 'lahko')
export interface Pin { type: FocusSport; day: number; min: number | null; cardio: CardioKind; /** kardio takoj po moči (isti del stavka kot moč, »v istem dnevu«, »po fitnesu«) */ after: boolean; /** »samo ta dva dneva« */ only: boolean; /** »dodaj še …«: nova seja, ne premik obstoječe */ add: boolean; /** »tek namesto kolesa«: te vadbe izpadejo */ instead: FocusSport[] }
// »po fitnesu«, »po moči«: sklic na moč, ne nova seja moči
const AFTER_REF = /po (?:fitnes\p{L}*|vadbi|mo(?:č|c)i|treningu|ute(?:ž|z)\p{L}*)/gu
const ADD = /dodaj|dodatn\p{L}*|(?:^|[^\p{L}])(?:š|s)e (?:en[aoi]?|enkrat|kak(?:š|s)n\p{L}*|kdaj)(?![\p{L}])/u
const INSTEAD = /(?:^|[^\p{L}])(?:namesto|raje kot)\s+(\p{L}+)/gu
/** »tek namesto kolesa« → [kolo] */
function insteadIn(c: string): FocusSport[] {
  const out = new Set<FocusSport>()
  for (const m of c.matchAll(INSTEAD)) for (const [k, rx] of SPORT_RX) { rx.lastIndex = 0; if (rx.test(` ${m[1]} `)) out.add(k); rx.lastIndex = 0 }
  return [...out]
}
/**
 * Določeni dnevi iz besed: »torek in petek fitnes, tek v istem dnevu, nedelja kolo« → [fitnes tor, fitnes pet, tek tor po
 * moči, tek pet po moči, kolo ned]. Del stavka o času (»ne morem«), o tem, česar ne dela, o premiku (»iz torka na sredo«)
 * ali o ostalem (»ostalo kolo«) ne določa dni; »v istem dnevu« / »po fitnesu« / »vmes« veže na prej omenjene dni moči;
 * »tek po fitnesu ob torkih« določa le tek (fitnes je sklic). strengthDays = dnevi moči iz obstoječega dogovora.
 */
export function pinsIn(text: string, o: { strengthDays?: readonly number[] } = {}): Pin[] {
  const out: Pin[] = []
  let last: number[] = [], lastSport: FocusSport[] = []
  const strengthDays = () => { const d = out.filter(p => isStrength({ type: p.type })).map(p => p.day); return d.length ? [...new Set(d)] : [...(o.strengthDays || [])] }
  for (const c of clauses(text)) {
    if (hasNo(c) || NOT_GO.test(c) || REST.test(c) || MOVE.test(c)) continue
    // »tek po fitnesu«: fitnes je sklic (tek je po njem), ne seja moči za določitev
    AFTER_REF.lastIndex = 0
    const ref = AFTER_REF.test(c); AFTER_REF.lastIndex = 0
    let sp = sportsIn(ref ? c.replace(AFTER_REF, 'po tem') : c)
    const strengthRef = ref && sp.some(x => !isStrength({ type: x })) && sportsIn(c).some(x => isStrength({ type: x })) && !sp.some(x => isStrength({ type: x }))
    let ds = targetDays(c), bound = strengthRef
    if (!ds.length && sp.some(x => !isStrength({ type: x }))) {
      // »tek po fitnesu«, »tek v istem dnevu«: kardio na dneve moči (moč v tem delu stavka je le sklic)
      if (AFTER.test(c)) { ds = strengthDays(); bound = true; sp = sp.filter(x => !isStrength({ type: x })) }
      else if (SAME.test(c)) { ds = last; bound = true }
    }
    if (!ds.length) { if (sp.length) lastSport = sp; continue }
    last = ds
    // »fitnes ne v torek, ampak v sredo«: drugi del stavka je še o fitnesu
    const use = sp.length ? sp : /^(?:ampak|temve(?:č|c)|raje|pa raje|pa(?:č|c))(?![\p{L}])/u.test(c) ? lastSport : []
    if (!use.length) continue
    lastSport = use
    const min = minutesIn(c), kind = cardioKindIn(c), only = ONLY.test(c), add = ADD.test(c), instead = insteadIn(c)
    const withStrength = use.some(x => isStrength({ type: x }))
    for (const type of use) for (const day of ds) {
      if (out.some(p => p.type === type && p.day === day)) continue
      // kardio v istem delu stavka kot moč (»fitnes s tekom«) ali vezan nanjo = po moči isti dan
      const after = !isStrength({ type }) && (bound || withStrength || strengthDays().includes(day))
      out.push({ type, day, min, cardio: kind, after, only, add, instead: instead.filter(x => x !== type) })
    }
  }
  return out
}
/** »premakni fitnes iz torka na sredo«, »tek namesto torka v četrtek« → premiki: vadba (ali vse), z dneva na dan. */
export function movesIn(text: string): { type: FocusSport | null; from: number[]; to: number[] }[] {
  const out: { type: FocusSport | null; from: number[]; to: number[] }[] = []
  for (const c of clauses(text)) {
    if (hasNo(c) || NOT_GO.test(c)) continue
    const from = srcDays(c), to = targetDays(c)
    if (!from.length || !to.length) continue
    const sp = sportsIn(c)
    out.push({ type: sp[0] ?? null, from, to })
  }
  return out
}
/**
 * Dnevi iz prejšnjega dogovora ostanejo, ko uporabnik ni govoril o dnevih (»več kardia«), AI pa jih je spremenil ali
 * izpustil: določene seje iste vrste dobijo prejšnji dan, kardio po moči ostane pri svoji seji moči.
 */
export function keepDayStructure(prev: Focus, next: Focus, age?: number | null): Focus {
  let s: AgreedSession[] = next.sessions.map(x => ({ ...x }))
  const prevTails = tailsOf(prev.sessions)
  // določeni dnevi po vrsti: prejšnja seja z dnem → nova seja iste vrste s tem dnem (najprej brez dneva, sicer tista,
  // ki ji je AI dal drug dan)
  const prevPins = prev.sessions.filter((x, i) => x.day != null && !prevTails.has(i))
  for (const p of prevPins) {
    if (s.some(x => x.type === p.type && x.day === p.day)) continue
    const mineDays = prevPins.filter(q => q.type === p.type).map(q => q.day)
    let i = s.findIndex(x => x.type === p.type && x.day == null && !x.after)
    if (i < 0) i = s.findIndex(x => x.type === p.type && !x.after && !mineDays.includes(x.day ?? -1))
    if (i >= 0) { s = s.map(x => (x.day === p.day && !x.after && x.type !== p.type ? { ...x, day: null } : x)); s[i] = { ...s[i]!, day: p.day } }
  }
  // kardio po moči: k-ta seja moči je imela kardio te vrste → nova k-ta seja moči ga dobi (iz prostih sej te vrste)
  const ordOf = (list: readonly AgreedSession[]) => { const m = new Map<number, number>(); list.forEach((x, i) => { if (isStrength(x)) m.set(i, m.size) }); return m }
  const prevOrd = ordOf(prev.sessions)
  const want = [...prevTails.entries()].map(([t, m]) => ({ ord: prevOrd.get(m)!, type: prev.sessions[t]!.type, tail: prev.sessions[t]! }))
  for (const w of want) {
    const ord = ordOf(s)
    const mi = [...ord.entries()].find(([, o]) => o === w.ord)?.[0]
    if (mi == null) continue
    const tails = tailsOf(s)
    if ([...tails.values()].includes(mi)) continue
    // prosta seja te vrste postane kardio po moči; če je ni, se prejšnji kardio po moči vrne (uporabnik ga ni odpovedal)
    const ci = s.findIndex(x => x.type === w.type && !isStrength(x) && !x.after && x.day == null)
    const c: AgreedSession = ci >= 0 ? { ...s[ci]!, after: true } : { ...w.tail, day: null, after: true }
    if (ci >= 0) s = s.filter((_, i) => i !== ci)
    const at = s.findIndex((x, i) => isStrength(x) && ordOf(s).get(i) === w.ord)
    s = [...s.slice(0, at + 1), c, ...s.slice(at + 1)]
  }
  const out = normalizeFocus({ ...next, sessions: s, offDays: [...new Set([...(next.offDays || []), ...(prev.offDays || [])])] }, { age, by: next.by, now: next.at })
  if (!out) return next
  out.title = next.title; out.notes = next.notes; out.strategy = next.strategy ?? null
  return out
}
/** Ali besedilo sploh govori o dnevih (določeni dnevi, dnevi brez časa, »v fitnes ne hodim ob …«). */
export const mentionsDays = (text: string): boolean => daysIn(text).length > 0 || pinsIn(text).length > 0 || notOnIn(text).size > 0 || offDaysIn(text).length > 0
/** »ostalo kolo ali doma« → vadbe za preostale dni. */
export function restSportsIn(text: string): FocusSport[] {
  const out = new Set<FocusSport>()
  for (const c of clauses(text)) if (REST.test(c) && !hasNo(c) && !NOT_GO.test(c)) sportsIn(c).forEach(x => out.add(x))
  return [...out]
}
/** enakomerno m dni iz razpoložljivih */
const spreadDays = (avail: readonly number[], m: number): number[] => (m >= avail.length ? [...avail] : m === 1 ? [avail[Math.floor((avail.length - 1) / 2)]!] : Array.from({ length: m }, (_, j) => avail[Math.round((j * (avail.length - 1)) / (m - 1))]!))
const strengthParts = (n: number): SessionPart[] => (n <= 1 ? ['celo'] : n === 2 ? ['zgornji', 'spodnji'] : n === 3 ? ['potisk', 'noge', 'poteg'] : ['zgornji', 'spodnji', 'potisk', 'poteg', 'celo', 'celo'])
const cardioMin = (t: FocusSport, kind: CardioKind, base?: number | null) => (kind === 'dolgo' ? Math.max(60, base ?? 0) : t === 'kolo' ? Math.max(45, base ?? 60) : t === 'hribi' ? 150 : Math.max(20, Math.min(45, (base ?? 40) - 10)))
/** indeksi kardia po moči (after) za vsako sejo moči */
const tailIndex = (s: readonly AgreedSession[]): Map<number, number> => { const m = new Map<number, number>(); tailsOf(s).forEach((i, j) => m.set(i, j)); return m }

/**
 * Dnevi iz besed na dogovor (AI ali pravila): določene vadbe na svoje dni (moč: točno ti dnevi; kardio: ti dnevi, ostali
 * teki ostanejo prosti), kardio po moči v istem dnevu ostane z njo ob vsaki spremembi, premiki (»iz torka na sredo«),
 * vadbe, ki jih ta dan ne dela, na druge dni, dnevi brez časa in spet prosti dnevi, »ostalo kolo ali doma« za preostale
 * seje. Besede uporabnika so zavezujoče — tudi ko jih AI v predlogu ni upošteval. Vrne null, če besedilo ne govori o dnevih.
 */
export function applyDayWords(f: Focus, text: string, age?: number | null): Focus | null {
  const strengthDays0 = f.sessions.filter(x => isStrength(x) && x.day != null).map(x => x.day!)
  const pins = pinsIn(text, { strengthDays: strengthDays0 }), notOn = notOnIn(text), noDays = offDaysIn(text), rest = restSportsIn(text), moves = movesIn(text), canDays = canDaysIn(text)
  if (!pins.length && !notOn.size && !noDays.length && !canDays.length && !rest.length && !moves.length) return null
  let s: AgreedSession[] = f.sessions.map(x => ({ ...x }))
  let off = [...new Set([...(f.offDays || []), ...noDays])].filter(d => !canDays.includes(d) || noDays.includes(d))
  const sMin = s.find(isStrength)?.min ?? f.minutes
  const cMin = s.find(x => !isStrength(x) && !x.after)?.min ?? null
  const dayTaken = (d: number, except: number[] = []) => s.some((x, i) => x.day === d && !x.after && !except.includes(i))
  // 1. premiki: »premakni fitnes iz torka na sredo« — samo seje na izvornem dnevu
  for (const mv of moves) {
    const cand = s.map((x, i) => ({ x, i })).filter(({ x }) => !x.after && x.day != null && mv.from.includes(x.day) && (!mv.type || x.type === mv.type))
    cand.forEach(({ i }, k) => { const to = mv.to[Math.min(k, mv.to.length - 1)]!; off = off.filter(d => d !== to); s[i] = { ...s[i]!, day: to } })
  }
  // 2. določene vadbe
  const pinnedTypes = [...new Set(pins.map(p => p.type))]
  const strengthPins = pins.filter(p => isStrength({ type: p.type }))
  for (const type of [...new Set(strengthPins.map(p => p.type))]) {
    const mine = strengthPins.filter(p => p.type === type).sort((a, b) => a.day - b.day)
    off = off.filter(d => !mine.some(p => p.day === d))
    const tails = tailIndex(s)
    const old = s.map((x, i) => ({ x, i })).filter(({ x }) => x.type === type)
    const parts = strengthParts(mine.length)
    const keepParts = old.length === mine.length
    // moč: točno ti dnevi — stare seje te vrste (z njihovim kardiem po moči) zamenjajo nove, kardio po moči ostane z njo
    const fresh: AgreedSession[] = []
    mine.forEach((p, k) => {
      const base = old[k]?.x ?? old[old.length - 1]?.x
      fresh.push({ type, part: keepParts && base?.part ? base.part : parts[k % parts.length]!, min: p.min ?? base?.min ?? sMin, day: p.day, ...(base?.ex ? { ex: base.ex } : {}), ...(base?.why ? { why: base.why } : {}) })
      const t = old[k] ? tails.get(old[k]!.i) : undefined
      if (t != null) fresh.push({ ...s[t]!, day: null, after: true })
    })
    const gone = new Set(old.flatMap(({ i }) => [i, ...(tails.has(i) ? [tails.get(i)!] : [])]))
    s = [...s.filter((_, i) => !gone.has(i)), ...fresh]
  }
  for (const type of [...new Set(pins.filter(p => !isStrength({ type: p.type })).map(p => p.type))]) {
    const mine = pins.filter(p => p.type === type).sort((a, b) => a.day - b.day)
    off = off.filter(d => !mine.some(p => p.day === d))
    for (const p of mine) {
      const strengthAt = s.findIndex(x => isStrength(x) && x.day === p.day)
      if (p.after && strengthAt >= 0) {
        // kardio po moči: za to sejo moči (zamenja prejšnjega, če je)
        const tails = tailIndex(s)
        const old = tails.has(strengthAt) ? s[tails.get(strengthAt)!]! : s.find(x => x.type === type && !x.after && x.day == null)
        const tail: AgreedSession = { type, cardio: p.cardio !== 'lahko' ? p.cardio : old?.cardio ?? 'lahko', min: p.min ?? (p.cardio === 'dolgo' ? cardioMin(type, 'dolgo', old?.min) : Math.min(25, old?.min ?? 20)), after: true }
        const drop = tails.has(strengthAt) ? tails.get(strengthAt)! : old ? s.indexOf(old) : -1
        s = s.filter((_, i) => i !== drop)
        const at = s.findIndex(x => isStrength(x) && x.day === p.day)
        s = [...s.slice(0, at + 1), tail, ...s.slice(at + 1)]
      } else {
        // samostojen kardio na ta dan: najprej seja te vrste brez dneva (ali s tem dnem); »kolo ob sobotah« premakne že
        // določeno kolo z drugega dneva (ne podvoji), »dodaj še kolo ob sobotah« doda novo
        let i = s.findIndex(x => x.type === type && !x.after && (x.day === p.day || x.day == null) && !dayTaken(p.day, [s.indexOf(x)]))
        if (i < 0 && !p.add) i = s.findIndex(x => x.type === type && !x.after && x.day != null && !mine.some(q => q.day === x.day) && !dayTaken(p.day, [s.indexOf(x)]))
        const base = i >= 0 ? s[i]! : undefined
        const kind: CardioKind = p.cardio !== 'lahko' ? p.cardio : base?.cardio ?? 'lahko'
        const next: AgreedSession = { ...(base ?? { type }), type, cardio: kind, min: p.min ?? (p.cardio !== 'lahko' && p.cardio !== base?.cardio ? cardioMin(type, kind, base?.min) : base?.min ?? cardioMin(type, kind, cMin ?? sMin)), day: p.day }
        if (i >= 0) s[i] = next; else s.push(next)
      }
      // »tek namesto kolesa ob sobotah«: kolo izpade — najprej tisto na ta dan, sicer prosto, sicer katero koli
      for (const gone of p.instead) {
        const tails = tailIndex(s)
        const j = [s.findIndex(x => x.type === gone && !x.after && x.day === p.day), s.findIndex(x => x.type === gone && !x.after && x.day == null), s.findIndex(x => x.type === gone && !x.after)].find(k => k >= 0)
        if (j == null) continue
        const drop = new Set([j, ...(tails.has(j) ? [tails.get(j)!] : [])])
        s = s.filter((_, k) => !drop.has(k))
      }
    }
    // »samo ob sobotah«: druge seje te vrste izpadejo (tudi kardio po moči na drugih dnevih)
    if (mine.some(p => p.only)) {
      const ofTail = tailsOf(s)   // kardio po moči → njegova seja moči (dan)
      const dayOfIdx = (i: number) => (ofTail.has(i) ? s[ofTail.get(i)!]!.day : s[i]!.day)
      s = s.filter((x, i) => x.type !== type || mine.some(p => p.day === dayOfIdx(i)))
    }
  }
  // 3. vadbe, ki jih ta dan ne dela: seje te vrste na teh dneh (ali brez dneva) na druge dni; kardio po moči na takem dnevu izpade
  for (const [type, bad] of notOn) {
    if (pinnedTypes.includes(type)) continue
    const tails = tailIndex(s)
    const tailOfStrength = new Map([...tails.entries()].map(([i, j]) => [j, i]))
    // kardio po moči te vrste na slabem dnevu → izpade
    s = s.filter((x, j) => !(x.type === type && x.after && tailOfStrength.has(j) && s[tailOfStrength.get(j)!]!.day != null && bad.includes(s[tailOfStrength.get(j)!]!.day!)))
    const mine = s.map((x, i) => ({ x, i })).filter(({ x }) => x.type === type && !x.after && (x.day == null || bad.includes(x.day)))
    if (!mine.length) continue
    const okDays = [0, 1, 2, 3, 4, 5, 6].filter(d => !bad.includes(d) && !off.includes(d) && !dayTaken(d, mine.map(m => m.i)))
    const n = Math.min(mine.length, okDays.length)
    const days = spreadDays(okDays, n)
    const gone = new Set<number>()
    const tl = tailIndex(s)
    mine.forEach(({ i }, k) => { if (k < n) s[i] = { ...s[i]!, day: days[k]! }; else { gone.add(i); if (tl.has(i)) gone.add(tl.get(i)!) } })
    s = s.filter((_, i) => !gone.has(i))
  }
  // 4. »ostalo kolo ali doma«: preostale (nedoločene) seje drugih vrst zamenjajo te vadbe
  if (rest.length) {
    const tails = tailsOf(s)   // kardio po moči → njegova moč
    // ostane: določene seje in seje določene vrste; kardio po moči le skupaj s svojo močjo
    const keepMain = (i: number) => s[i]!.day != null || pinnedTypes.includes(s[i]!.type)
    const keep = s.filter((_, i) => (tails.has(i) ? keepMain(tails.get(i)!) : keepMain(i)))
    const loose = s.filter((_, i) => !tails.has(i) && !keepMain(i)).length
    const n = Math.max(rest.length, loose, pins.length ? 1 : 0)
    const add: AgreedSession[] = Array.from({ length: n }, (_, k) => { const type = rest[k % rest.length]!; return isStrength({ type }) ? { type, part: 'celo', min: sMin } : { type, cardio: 'lahko', min: cardioMin(type, 'lahko', cMin ?? sMin) } })
    s = [...keep, ...add]
  }
  const next = normalizeFocus({ ...f, sessions: orderSessions(s), sports: [...new Set(s.map(x => x.type))], offDays: off, preferDays: (f.preferDays || []).filter(d => !off.includes(d)) }, { age, by: f.by, now: f.at })
  if (!next) return null
  next.title = f.title || next.title
  next.notes = f.notes
  next.strategy = f.strategy ?? null
  return next
}
/** Seje po dnevih v tednu (določene najprej, po dnevu; kardio po moči takoj za svojo močjo), nedoločene na koncu. */
export function orderSessions(s: readonly AgreedSession[]): AgreedSession[] {
  const tails = tailsOf(s)
  const tailOf = new Map<number, number>(); tails.forEach((m, t) => tailOf.set(m, t))
  const mains = s.map((x, i) => ({ x, i })).filter(({ i }) => !tails.has(i))
  const sorted = [...mains].sort((a, b) => (a.x.day ?? 9) - (b.x.day ?? 9) || a.i - b.i)
  const out: AgreedSession[] = []
  for (const { x, i } of sorted) { out.push(x); if (tailOf.has(i)) out.push({ ...s[tailOf.get(i)!]!, after: true, day: null }) }
  return out
}

// vprašanja po oznaki (vprašalnik brez AI) ali po besedilu (vprašanja, ki jih je sestavil AI, nato pa ni odgovoril)
const Q_TEXT: Record<string, RegExp> = {
  dni: /koliko dni|dni na teden|dni lahko|kolikokrat/i, cas: /koliko (?:časa|casa|minut)|dolg[aeo] (?:vadb|trening)|minut na/i, kje: /\bkje\b|oprem|fitnes(?:u|a)? ali doma/i,
  kardio: /kardio|tek.*kolo|kolo.*tek|kakšen tek/i, izkusnje: /izkuš|izkus|kako dolgo|hodiš v fitnes/i, cilji: /najpomembn|cilj/i, nedni: /ne gre|ne gredo|nimaš časa|nimas casa|ne moreš|ne mores|brez časa/i, poskodbe: /boli|poškod|poskod/i,
}
const byId = (qa: readonly QA[], id: string) => qa.filter(x => x.id === id || x.q === id || (Q_TEXT[id] ? Q_TEXT[id]!.test(x.q) : false))
const has = (qa: readonly QA[], id: string, rx: RegExp) => byId(qa, id).some(x => rx.test(x.a.toLowerCase()))
const ans = (qa: readonly QA[], id: string) => byId(qa, id)[0]?.a ?? ''

/** Cilji in mišice iz besed (»six pack«, »vitka postava«, »ne izgubiti mišic«, »samo zgornji del«). */
export function wishSignals(wish: string): { aims: FocusAim[]; muscles: Muscle[]; sports: FocusSport[]; keepMuscle: boolean; upperOnly: boolean } {
  const w = wish.toLowerCase()
  const aims = new Set<FocusAim>()
  const muscles = new Set<Muscle>()
  const sports = new Set<FocusSport>()
  if (/hujš|husj|shujš|kilogram|maščob|mascob|kil dol|izgubit/.test(w)) aims.add('hujsanje')
  if (/vitk|definic|lin\b|lean|six|šest|sixpack|trebuš/.test(w)) aims.add('definicija')
  if (/mišic|misic|masa|nabit|bicep|mišičast/.test(w)) aims.add('misice')
  if (/mo(?:č|c)(?![\p{L}])|močn|mocn|močan|mocan|težk|tezk/u.test(w)) aims.add('moc')
  if (/kondic|sapa|vzdrž|vzdrz|kardio|sopih/.test(w)) aims.add('kondicija')
  if (/zdrav|gibanj|hrbet me|počutj|pocutj/.test(w)) aims.add('zdravje')
  if (/six|šest|sixpack|trebuh|trebuš|trebus/.test(w)) muscles.add('trebuh')
  if (/rok|bicep|tricep/.test(w)) muscles.add('roke')
  if (/prs/.test(w)) muscles.add('prsa')
  if (/ramen|ramena/.test(w)) muscles.add('ramena')
  if (/hrbet|hrbt/.test(w) && !/boli|bolečin/.test(w)) muscles.add('hrbet')
  if (/zadnjic|rit\b|glute/.test(w)) muscles.add('zadnjica')
  if (/\bnog/.test(w) && !/brez nog/.test(w)) muscles.add('noge')
  if (/fitnes|fitnes|gym|teretan|uteži|utezi|ročk|rock/.test(w)) sports.add('fitnes')
  if (/\btek|teč|tec[ie]|tekač|run/.test(w)) sports.add('tek')
  if (/kolo|koles|bicikl/.test(w)) sports.add('kolo')
  if (/hrib|pohod|planin/.test(w)) sports.add('hribi')
  if (/doma\b|brez opreme/.test(w)) sports.add('doma')
  const keepMuscle = /ne izgub|nočem izgub|nocem izgub|ohran|obdrž|obdrz/.test(w) || (aims.has('hujsanje') && (aims.has('misice') || aims.has('moc') || aims.has('definicija')))
  const upperOnly = /samo zgornj|le zgornj|zgornji del|samo roke|samo trebuh/.test(w)
  return { aims: [...aims], muscles: [...muscles], sports: [...sports], keepMuscle, upperOnly }
}

/** Predlog po pravilih iz odgovorov in besed. */
export function ruleProposal(wish: string, qa: readonly QA[], age?: number | null): { reply: string; focus: Focus; quick: string[] } {
  const sig = wishSignals(wish)
  const n = Math.max(2, Math.min(6, parseInt(ans(qa, 'dni'), 10) || 3))
  const min = Math.max(25, Math.min(90, parseInt(ans(qa, 'cas'), 10) || 45))
  const level: 1 | 2 | 3 = has(qa, 'izkusnje', /redno/) ? 3 : has(qa, 'izkusnje', /nekaj/) ? 2 : 1
  const gym = has(qa, 'kje', /fitnes/) || sig.sports.includes('fitnes')
  const equipment: FocusEquip[] = [...new Set<FocusEquip>([
    ...(gym ? ['fitnes' as const] : []), ...(has(qa, 'kje', /ročk|rock/) ? ['utezi' as const] : []),
    ...(has(qa, 'kje', /elastik/) ? ['elastike' as const] : []), ...(has(qa, 'kje', /drog/) ? ['drog' as const] : []), 'nic' as const,
  ])]
  const cardioTypes: FocusSport[] = has(qa, 'kardio', /brez/) ? [] : ([['tek', /tek/], ['kolo', /kolo/], ['hribi', /hrib/]] as [FocusSport, RegExp][]).filter(([, rx]) => has(qa, 'kardio', rx)).map(([s]) => s)
  const cardio = cardioTypes.length ? cardioTypes : sig.sports.filter(s => s === 'tek' || s === 'kolo' || s === 'hribi')
  const aims = new Set<FocusAim>(sig.aims)
  if (has(qa, 'cilji', /mišic/)) aims.add('misice')
  if (has(qa, 'cilji', /moč/)) aims.add('moc')
  if (has(qa, 'cilji', /maščob/)) aims.add('hujsanje')
  if (has(qa, 'cilji', /kondic/)) aims.add('kondicija')
  if (has(qa, 'cilji', /zdrav/)) aims.add('zdravje')
  if (!aims.size) aims.add('zdravje')
  const injuries = ['Koleno', 'Hrbet', 'Rama'].filter(x => has(qa, 'poskodbe', new RegExp(x.toLowerCase()))).join(', ').toLowerCase()
  // dnevi brez časa (iz vprašalnika ali iz besed »ob torkih ne morem«)
  const offDays = [...new Set([...byId(qa, 'nedni').flatMap(x => daysIn(x.a, true)), ...offDaysIn(wish)])]
  // kardio: pri kondiciji ali hujšanju 1–2 na teden (od 4 dni dalje 2), sicer 1 od 3 dni dalje
  const wantCardio = cardio.length > 0
  const nc = !wantCardio ? 0 : (aims.has('kondicija') || aims.has('hujsanje')) ? (n >= 4 ? 2 : 1) : n >= 3 ? 1 : 0
  const ns = Math.max(sig.sports.length && !sig.sports.some(s => s === 'fitnes' || s === 'doma') && wantCardio ? 0 : 1, n - nc)
  const where: 'fitnes' | 'doma' = gym ? 'fitnes' : 'doma'
  const parts: SessionPart[] = sig.upperOnly
    ? (['zgornji', 'potisk', 'poteg', 'zgornji'] as SessionPart[]).slice(0, ns)
    : ns === 1 ? ['celo'] : ns === 2 ? (level === 1 ? ['celo', 'celo'] : ['zgornji', 'spodnji']) : ns === 3 ? (level === 1 ? ['celo', 'celo', 'celo'] : ['potisk', 'noge', 'poteg']) : ['zgornji', 'spodnji', 'potisk', 'poteg'].slice(0, ns) as SessionPart[]
  const sessions: AgreedSession[] = parts.map(part => ({ type: where, part, min }))
  for (let k = 0; k < nc; k++) {
    const type = cardio[k % cardio.length]!
    sessions.push({ type, cardio: type === 'hribi' ? 'lahko' : aims.has('kondicija') && k === 0 ? 'intervali' : 'lahko', min: type === 'kolo' ? Math.max(45, min) : type === 'hribi' ? 150 : Math.max(25, Math.min(50, min - 10)) })
  }
  let focus = normalizeFocus({ wish, sports: [...new Set(sessions.map(s => s.type))], aims: [...aims], muscles: sig.muscles, level, equipment, limits: injuries || null, keepMuscle: sig.keepMuscle, sessions, offDays, notes: notesFor([...aims], sig.muscles) }, { age, by: 'pravila' })!
  // besede o dnevih (»torek in petek fitnes, tek v istem dnevu, ostalo kolo«) veljajo tudi brez AI — iz želje in iz prostih odgovorov
  focus = applyDayWords(focus, wish, age) ?? focus
  const free = qa.filter(x => !byId(qa, 'nedni').includes(x) && /[a-zčšž]{3,}/i.test(x.a) && x.a.length > 6).map(x => x.a).join('. ')
  if (free) focus = applyDayWords(focus, free, age) ?? focus
  focus.title = titleOf(focus)
  const reply = `Predlagam ${weekLine(focus)}: ${mixLine(focus)}.${aims.has('hujsanje') && sig.keepMuscle ? ' Moč ostane težka, da med hujšanjem obdržiš mišice.' : ''} ${daysReply(focus)} Če želiš več ali manj, povej.`
  return { reply, focus, quick: QUICK }
}
const QUICK = ['Več kardia', 'Več moči', 'Manj dni', 'Več dni', 'Krajše vadbe']
/** Dnevi z besedami za odgovor trenerja: določene vadbe, dnevi brez časa, teden dan za dnem. */
export function daysReply(f: Focus): string {
  const pins = pinsWords(f)
  const off = f.offDays?.length ? `${atDays(f.offDays).replace(/^o/, 'O')} ni vadbe.` : ''
  return [pins ? `${pins}.` : '', off, `Teden: ${weekWords(f)}.`].filter(Boolean).join(' ')
}

export function notesFor(aims: readonly FocusAim[], muscles: readonly Muscle[]): string[] {
  const out: string[] = []
  if (muscles.includes('trebuh') || aims.includes('definicija')) out.push('Trebušne mišice se vidijo pri nizkem deležu maščobe — vaje jih okrepijo, vidnost pa prinese prehrana.')
  if (aims.includes('hujsanje')) out.push('Hujšanje: zmeren deficit in dovolj beljakovin — tako gre dol maščoba, ne mišice.')
  if (aims.includes('kondicija')) out.push('Kondicija raste najhitreje z mešanico lahkega kardia in kratkih intervalov.')
  return out
}

/**
 * Pogajanje brez AI: besede o dnevih (»torek in petek fitnes, tek v istem dnevu«, »v fitnes ne hodim ob sobotah«,
 * »ob torkih ne morem«) in hitri odgovori (več kardia, manj dni, krajše …) spremenijo teden po pravilih.
 * Vrne null, če odgovora ne razume.
 */
export function ruleAdjust(f: Focus, say: string, age?: number | null): Focus | null {
  const t = say.toLowerCase()
  const byDays = applyDayWords(f, say, age)
  if (byDays) return byDays
  let s = f.sessions.map(x => ({ ...x }))
  const strength = isStrength
  const where = s.find(strength)?.type ?? (f.equipment.includes('fitnes') ? 'fitnes' : 'doma')
  const cardioType = (s.find(x => !strength(x))?.type ?? (f.sports.find(x => x === 'tek' || x === 'kolo' || x === 'hribi') || 'tek')) as FocusSport
  // indeksi se po vsakem izbrisu spremenijo → kardio po moči vsakič znova
  const lastLoose = () => { const tails = tailsOf(s); for (let i = s.length - 1; i >= 0; i--) if (!tails.has(i) && s[i]!.day == null) return i; for (let i = s.length - 1; i >= 0; i--) if (!tails.has(i)) return i; return -1 }
  const dropOne = () => { const i = lastLoose(); if (i < 0) return; const tails = tailsOf(s); const gone = new Set([i, ...[...tails.entries()].filter(([, m]) => m === i).map(([j]) => j)]); s = s.filter((_, k) => !gone.has(k)) }
  const nDays = /(\d)\s*(?:dni|dneva|dan|krat|x)(?![\p{L}])/u.exec(t)
  if (/več kardi|vec kardi|več tek|vec tek|dodaj tek|več kolesa|vec kolesa|dodaj kolo|dodaj kardi/.test(t)) {
    const type = /kolo|koles/.test(t) ? 'kolo' : /tek/.test(t) ? 'tek' : cardioType
    AFTER_REF.lastIndex = 0
    const afterStrength = AFTER_REF.test(t) || /po vadbi|v istem dnevu|isti dan|zraven|vmes/.test(t); AFTER_REF.lastIndex = 0
    const withTail = new Set(tailsOf(s).values())
    const mains = s.map((_, i) => i).filter(i => strength(s[i]!) && !withTail.has(i))
    if (afterStrength && mains.length) {
      // »dodaj tek po fitnesu«: kardio takoj po vsaki seji moči, ki ga še nima (ni nov dan)
      const out: AgreedSession[] = []
      s.forEach((x, i) => { out.push(x); if (mains.includes(i)) out.push({ type, cardio: 'lahko', min: 20, after: true }) })
      s = out
    } else {
      const i = s.findIndex(strength)
      if (trainingDays(s) >= 6 && i >= 0) s[i] = { type, cardio: 'lahko', min: 40 }; else s.push({ type, cardio: 'lahko', min: 40 })
    }
  }
  else if (/manj kardi|manj tek|brez tek|brez kardi|manj kolesa|brez kolesa/.test(t)) { const type = /kolo|koles/.test(t) ? 'kolo' : /tek/.test(t) ? 'tek' : null; const all = /brez/.test(t); const idx = s.map((_, i) => i).filter(i => !strength(s[i]!) && (!type || s[i]!.type === type)); const gone = new Set(all ? idx : idx.slice(-1)); if (gone.size && gone.size < s.length) s = s.filter((_, i) => !gone.has(i)) }
  else if (/več moč|vec moc|več fitnes|vec fitnes/.test(t)) { const i = s.findIndex(x => !strength(x) && !x.after); if (i >= 0 && trainingDays(s) >= 5) s[i] = { type: where, part: 'celo', min: 50 }; else s.push({ type: where, part: 'celo', min: 50 }) }
  else if (nDays) { const want = Math.max(1, Math.min(6, +nDays[1]!)); while (trainingDays(s) > want) { const before = s.length; dropOne(); if (s.length === before) break } while (trainingDays(s) < want && s.length < 7) s.push(trainingDays(s) % 2 ? { type: cardioType, cardio: 'lahko', min: 40 } : { type: where, part: 'celo', min: 50 }) }
  else if (/manj dni|manj vadb/.test(t)) { if (trainingDays(s) > 1) dropOne() }
  else if (/več dni|vec dni|več vadb|vec vadb/.test(t)) { if (trainingDays(s) < 6) s.push(trainingDays(s) % 2 ? { type: cardioType, cardio: 'lahko', min: 40 } : { type: where, part: 'celo', min: 50 }) }
  else if (/krajš|krajs/.test(t)) s = s.map(x => ({ ...x, min: Math.max(20, x.min - 10) }))
  else if (/daljš|daljs/.test(t)) s = s.map(x => ({ ...x, min: x.min + 10 }))
  else if (/brez nog|ne nog|samo zgornj|le zgornj/.test(t)) s = s.map(x => (strength(x) && (x.part === 'noge' || x.part === 'spodnji' || x.part === 'celo') ? { ...x, part: 'zgornji' } : x))
  else if (/nog/.test(t)) { const i = s.findIndex(x => strength(x) && x.part !== 'spodnji' && x.part !== 'noge'); if (i >= 0) s[i] = { ...s[i]!, part: 'noge' } }
  else return null
  if (!s.length) return null
  const next = normalizeFocus({ ...f, sessions: s, sports: [...new Set(s.map(x => x.type))] }, { age, by: f.by, now: f.at })
  if (next) { next.title = f.title; next.notes = f.notes; next.strategy = f.strategy ?? null }
  return next
}

/** Strategija brez AI. */
export function ruleStrategy(f: Focus, n: { kcal: number | null; proteinG: number | null; deficit: number }): string {
  const out = [`– ${weekLine(f)}: ${mixLine(f)}. Bloki po 4 tedne: 3 tedne rast, nato lažji teden.`]
  if (f.sessions.some(s => s.type === 'fitnes' || s.type === 'doma')) out.push('– Moč: vpisuj kilograme — ko narediš vse ponovitve, je naslednjič teža višja. Tako mišice dobijo razlog, da ostanejo in rastejo.')
  if (f.sessions.some(s => s.type === 'tek' || s.type === 'kolo')) out.push('– Kardio: večinoma lahko, en hitrejši trening na teden — kondicija raste brez izčrpanosti.')
  if (n.kcal) out.push(`– Prehrana: ~${n.kcal} kcal na dan${n.deficit ? ` (deficit ${n.deficit} kcal)` : ''}${n.proteinG ? `, beljakovine ~${n.proteinG} g` : ''} — številke so v Prehrani in se prilagajajo treningu.`)
  out.push('– Spanec 7–9 h: ko spiš manj, se napredek ustavi prej kot pri izpuščenem treningu.')
  out.push(f.aims.includes('hujsanje') ? '– Pričakuj 0,25–0,75 kg na teden; prve 4 tedne se pozna predvsem moč in energija.' : '– Prvi 4 tedni: navada in tehnika; po 8–12 tednih se napredek pozna na kilogramih in kondiciji.')
  return out.join('\n')
}
