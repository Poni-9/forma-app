import type { AgreedSession, Focus, FocusAim, FocusSport } from '../types'

/**
 * ODMERek NAČRTA (Blaž, 13. 10.: »dober plan je najpomembnejša funkcija — tu moraš res premisliti«).
 * Iz besed in odgovorov: raven, razpon dni in časa, izrecno število vadb po športu; iz cilja in »glavnega«: razmerje
 * moč : kardio za dano število dni. Vse čiste funkcije — uporablja jih trener (coachReview) po vsakem predlogu.
 */

/** »3-4«, »3 do 4«, »3–4 krat«, »60 do 75 minut« → { lo, hi }; eno število → lo = hi. */
export function rangeIn(text: string | null | undefined, lo0 = 1, hi0 = 600): { lo: number; hi: number } | null {
  if (!text) return null
  const t = text.toLowerCase().replace(/(\d),(\d)/g, '$1.$2')
  const r = /(\d{1,3}(?:\.\d)?)\s*(?:-|–|—|do|ali|in|\/)\s*(\d{1,3}(?:\.\d)?)/.exec(t)
  if (r) {
    const a = +r[1]!, b = +r[2]!
    if (a >= lo0 && b <= hi0 && a <= b) return { lo: a, hi: b }
  }
  const one = /(\d{1,3}(?:\.\d)?)/.exec(t)
  if (one) { const v = +one[1]!; if (v >= lo0 && v <= hi0) return { lo: v, hi: v } }
  return null
}
/**
 * (v3.49) »uro« je čas samo s števnikom (»eno uro«), pred »časa / na vadbo / na trening« ali kot cel odgovor — ne
 * »Imam Garmin uro«, »pametno uro«, »uro imam« (prej 1 h na vadbo, ki je preglasila odgovor »6–8 h na teden«).
 */
const ONE_HOUR = /(?:^|\s)(?:eno\s+uro(?![\p{L}])|uro(?=\s+(?:časa|casa|na\s+(?:vadbo|trening|dan)|za\s+(?:vadbo|trening))(?![\p{L}])))/u
/** »1 h 30 min«, »1 h in pol«, »uro in pol«, »eno uro« → minute (ostalo ostane) */
function normDur(text: string): string {
  return text.toLowerCase().replace(/(\d),(\d)/g, '$1.$2')
    .replace(/(\d+(?:\.\d)?)\s*(?:h|ur\p{L}*)\s*(?:in\s*)?(\d{1,2})\s*min\p{L}*/gu, (_, h, m) => `${Math.round(+h * 60 + +m)} min`)
    .replace(/(\d+)\s*h\s*(\d{1,2})(?![\d\p{L}])/gu, (_, h, m) => `${+h * 60 + +m} min`)
    .replace(/(\d+)\s*(?:h|ur\p{L}*)\s*in pol/gu, (_, h) => `${+h * 60 + 30} min`)
    .replace(/(?:^|\s)(?:eno\s+)?uro in pol/u, ' 90 min').replace(ONE_HOUR, ' 60 min').replace(/^\s*uro\s*[.!]?\s*$/u, '60 min')
    // (v3.50) »po pol ure«, »tri četrt ure« (prej vprašalnik vseeno vprašal, koliko časa imaš za vadbo)
    .replace(/(?:^|\s)tri\s*(?:č|c)etrt\s+ure(?![\p{L}])/u, ' 45 min').replace(/(?:^|\s)pol\s+ure(?![\p{L}])/u, ' 30 min')
}
/** Odgovor na »koliko časa za vadbo«: »60 do 75«, »1 h«, »1,5 ure«, »45 min«, »1 h 30 min« → minute (do 4 brez enote = ure). */
export function minutesRange(text: string | null | undefined): { lo: number; hi: number } | null {
  if (!text) return null
  const t = normDur(text)
  const r = rangeIn(t, 0.5, 300)
  if (!r) return null
  const hours = /\d\s*(?:h\b|ur[aei]?|uri)/.test(t) && !/min/.test(t)
  const k = hours || r.hi <= 4 ? 60 : 1
  const lo = Math.round(r.lo * k), hi = Math.round(r.hi * k)
  return lo >= 10 && hi <= 360 ? { lo, hi } : null
}
const DUR_RX = /(?<![\d.])(\d{1,3}(?:\.\d)?)(?:\s*(?:-|–|—|do|ali)\s*(\d{1,3}(?:\.\d)?))?\s*(min\p{L}*|h(?![\p{L}])|ur[aeio]?(?![\p{L}]))/gu
/**
 * tedenski čas: »na teden« tik ob trajanju (»4-5 h na teden«, »na teden imam 4-5 h«), ne ob številu dni (»1 h, 4x na teden«);
 * (v3.49) »po 30 minut« je čas na vadbo (»dvakrat na teden po 30 minut«), ne na teden
 */
const weeklyAt = (before: string, after: string) => /^\s*(?:na teden|tedensko|v tednu|na tedn\p{L}*)/u.test(after) || (!/(?:^|[^\p{L}])po\s*$/u.test(before) && /(?:na teden|tedensko|v tednu)\s+(?:\p{L}+\s+){0,2}$/u.test(before))
/** trajanje, ki velja za eno vrsto vadbe (»dolga vožnja naj bo 3 h«) ali tempo (»10 km v 50 min«) — ne čas za vsako vadbo */
const SESSION_BEFORE = /(?:dolg\p{L}*|vožnj\p{L}*|tek\p{L}*|kol[oe]\p{L}*|fitnes\p{L}*|mo[čc]i?|interval\p{L}*|tempo|pohod\p{L}*|tur[aeo]|ogrevanj\p{L}*)\s+(?:\p{L}+\s+){0,3}$|\d\s*km\s+(?:v|za|pod)\s*$/u
/**
 * Čas na vadbo v prostem besedilu — samo z enoto (»60 do 75 minut«): drugače so številke dnevi, kilogrami …
 * Ne: tedenski čas (»na teden imam 4-5 h«) in del vadbe (»dodaj 20 min teka po fitnesu«).
 */
export function minutesIn(text: string | null | undefined): { lo: number; hi: number } | null {
  if (!text) return null
  const t = normDur(text)
  for (const m of t.matchAll(DUR_RX)) {
    const before = t.slice(Math.max(0, m.index! - 24), m.index!), after = t.slice(m.index! + m[0].length, m.index! + m[0].length + 28)
    if (weeklyAt(before, after) || SESSION_BEFORE.test(before)) continue
    if (/^\s*(?:tek\p{L}*|kol\p{L}*|hoj\p{L}*|sprehod\p{L}*|vožnj\p{L}*|kardi\p{L}*|ogrevanj\p{L}*|razteg\p{L}*|po (?:fitnes|mo[čc]|vadb|trening)\p{L}*)/u.test(after)) continue
    const r = minutesRange(`${m[1]}${m[2] ? `-${m[2]}` : ''} ${m[3]!.startsWith('min') ? 'min' : 'h'}`)
    if (r) return r
  }
  return null
}
/** Tedenski čas v besedah (»na teden imam 4-5 h«, »6 ur tedensko«) → minute na teden. */
export function weekMinutesIn(text: string | null | undefined): { lo: number; hi: number } | null {
  if (!text) return null
  const t = normDur(text)
  for (const m of t.matchAll(DUR_RX)) {
    const before = t.slice(Math.max(0, m.index! - 24), m.index!), after = t.slice(m.index! + m[0].length, m.index! + m[0].length + 24)
    if (!weeklyAt(before, after)) continue
    const k = m[3]!.startsWith('min') ? 1 : 60
    const lo = Math.round(+m[1]! * k), hi = Math.round(+(m[2] ?? m[1])! * k)
    if (lo >= 60 && hi <= 20 * 60 && lo <= hi) return { lo, hi }
  }
  return null
}
/**
 * (v3.50) FTP iz besed: »FTP 320 W«, »FTP je 280«, »moj ftp: 250 W«, »prag 300 W« (vati) → število v razponu 80–600, sicer
 * null. Odgovor na vprašanje o FTP je lahko samo število (»280«, »280 W«). Prej se je »FTP 320 W« prezrl.
 */
export function ftpIn(text: string | null | undefined, bare = false): number | null {
  const t = String(text || '').toLowerCase()
  const m = /(?<![\p{L}])ftp\p{L}*\s*(?:je|:|=|okoli|približno|cca\.?|~)?\s*(\d{2,3})(?!\d|[.,]\d)/u.exec(t)
    ?? /(?<![\p{L}])(?:prag|pražn\p{L}*\s+moč\p{L}*)\s*(?:je|:|okoli|približno|~)?\s*(\d{2,3})\s*(?:w|vat\p{L}*)(?![\p{L}])/u.exec(t)
    ?? (bare ? /^\s*(?:okoli|približno|~)?\s*(\d{2,3})\s*(?:w|vat\p{L}*)?\s*$/u.exec(t) : null)
  const n = m ? +m[1]! : NaN
  return n >= 80 && n <= 600 ? n : null
}
/** »3-4 krat na teden«, »3 do 4 dni«, »4–5 treningov« → razpon dni (null, če ni razpona z enoto; »1-2 dni počitka« ne). */
export function daysRangeIn(text: string | null | undefined): { lo: number; hi: number } | null {
  if (!text) return null
  const m = /(?<![\d.])([1-7])\s*(?:-|–|—|do|ali)\s*([1-7])\s*(?:x|×|krat|dni|dneva|dan|trening\p{L}*|vadb\p{L}*|na teden)(?![\p{L}])(?!\s*(?:počitk|pocitk|prost|odmor|pavz|brez))/u.exec(text.toLowerCase())
  if (!m) return null
  const lo = +m[1]!, hi = +m[2]!
  return lo < hi ? { lo, hi } : null
}
/** Raven, kot jo vrne AI: 2, "2", "nekaj izkušenj", "izkušen" → 1–3; null, če je ne razume. */
export function parseLevel(v: unknown): 1 | 2 | 3 | null {
  const n = Number(v)
  if (n === 1 || n === 2 || n === 3) return n
  const s = String(v ?? '').toLowerCase()
  if (/začet|zacet|novin|^1/.test(s)) return 1
  if (/nekaj|srednj|občas|obcas|^2/.test(s)) return 2
  if (/izkuš|izkus|napred|redno|^3/.test(s)) return 3
  return null
}

/** »Občasno«, »1–3 leta«, »več kot 3 leta«, »treniram redno«, »začenjam« → raven (null, če ne pove nič o izkušnjah). */
function levelWords(a: string, strict = false): 1 | 2 | 3 | null {
  const t = a.toLowerCase()
  if (/manj kot (?:\d+ )?(?:leto|let|mesec)|začenjam|začetnik|nikoli|še ne (?:tečem|treniram|kolesarim|hodim)|še nisem|ne treniram|novinec|prvič/.test(t)) return 1
  // »več let nisem nič treniral«, »dolgo nisem« — po dolgem premoru je začetek kot začetnik
  if (/(?:več let|dolgo|leto|let)\s+(?:\p{L}+\s+){0,1}?nisem|nisem\s+(?:nič|ničesar|več)\s+(?:\p{L}+\s+)?(?:treniral|vadil|telovadil|tekel|kolesaril|delal)|dolgo nisem|že dolgo ne/u.test(t)) return 1
  const yrs = [...t.matchAll(/(\d{1,2})(?:\s*(?:-|–|do)\s*(\d{1,2}))?\s*(?:let|leta|leto)(?![\p{L}])/gu)].map(m => +(m[2] ?? m[1]!))
  if (yrs.length) { const y = Math.max(...yrs); return y >= 3 ? 3 : y >= 1 ? 2 : 1 }
  if (/(?:treniram|hodim|vadim|tečem|kolesarim)\s+(?:že\s+)?(?:redno|več let|leta)|več let|izkušen|tekmujem|napreden/.test(t) || (!strict && /redno/.test(t))) return 3
  if (/nekaj izkušenj|občasno|kdaj pa kdaj/.test(t) || (!strict && /nekaj|srednje/.test(t))) return 2
  return null
}
/**
 * Raven iz izbir in odgovorov (Blaž, 13. 10.: z 5–8 zgibi je dobil načrt za začetnika): izbira »Izkušnje« > odgovor na
 * vprašanje o izkušnjah > zgibi (3–9 = nekaj izkušenj, 10+ = izkušen) > tekaški kilometri na teden > izbire pri teku in
 * besede v želji. null, če ni povedal nič. Starost (»30 let«) v želji ni izkušnja — leta šteje samo v odgovoru o izkušnjah.
 */
export function levelFrom(wish: string | null | undefined, qa: readonly { q: string; a: string }[] = []): 1 | 2 | 3 | null {
  const t = (wish || '').toLowerCase()
  const pick = /izkušnje: ([^.]*)/.exec(t)?.[1]
  if (pick) return /redno|več let/.test(pick) ? 3 : /občasno|nekaj/.test(pick) ? 2 : /začenjam/.test(pick) ? 1 : null
  for (const x of qa) if (/izkuš|izkus|treniraš|treniras|koliko (?:časa|casa|let) že|kako dolgo|že treniraš|redno/i.test(x.q) && !/dni|dan |ur\p{L}* na|minut|časa imaš|casa imas/iu.test(x.q)) { const l = levelWords(x.a); if (l) return l }
  // zgibi: v odgovoru (»Koliko zgibov? → 5 do 8«) ali v besedah, ko pove, koliko jih zmore (»naredim 5 do 8 zgibov«; »rad bi 10« ne)
  const pullQa = qa.find(x => /zgib/i.test(x.q) && /\d/.test(x.a))
  const pull = pullQa ? /(\d{1,2})/.exec(pullQa.a) : /(?:naredim|zmorem|potegnem|uspe mi|naredil|zmore)\s+(?:\p{L}+\s+){0,2}?(\d{1,2})(?:\s*(?:-|–|do)\s*\d{1,2})?\s*(?:zgib|vzgib)/u.exec(t)
  if (pull) { const n = +pull[1]!; return n >= 10 ? 3 : n >= 3 ? 2 : 1 }
  const kmQa = qa.find(x => /km|kilometr/i.test(x.q) && (/\d/.test(x.a) || /še ne|nič|ne tečem/i.test(x.a)))
  if (kmQa) { if (/še ne|nič|ne tečem/i.test(kmQa.a)) return 1; const n = Math.max(...[...kmQa.a.matchAll(/(\d{1,3})/g)].map(m => +m[1]!)); return n >= 30 ? 3 : n >= 10 ? 2 : 1 }
  // izbira pri teku (želja »rad bi pretekel maraton« ni izkušnja)
  const run = /tek: ([^.]*)/.exec(t)?.[1]
  if (run) { if (/polmaraton/.test(run)) return 3; if (/do 10 km/.test(run)) return 2; if (/začenjam/.test(run)) return 1 }
  return levelWords(t.replace(/\d{1,2}\s*(?:let|leta|leto)(?![\p{L}])/gu, ''), true)
}

/** za številom stoji šport (»3x fitnes«, »dva dni fitnes«, »dvakrat na teden tečem«) — to je število vadb tega športa, ne dni */
const SPORT_W = '(?:fitnes\\p{L}*|mo(?:č|c)i?|tek(?:a|e|i|om)?|tečem|kol(?:o|esa|esu|esarjenj\\p{L}*|esarim)|hrib\\p{L}*|pohod\\p{L}*|doma|telovadim)'
const SPORT_AFTER = new RegExp(`^\\s*(?:na teden\\s*)?(?:(?:v|na|s|z)\\s+)?${SPORT_W}(?![\\p{L}])`, 'u')
const SPORT_BEFORE = new RegExp(`(?<![\\p{L}])${SPORT_W}\\s*$`, 'u')
/** »2 dni počitka«, »1 dan na teden prost« — to so prosti dnevi */
const REST_AFTER = /^\s*(?:na teden\s*)?(?:počitk|pocitk|prost|odmor|pavz|brez|fraj)/u
const NUM_WORD: Record<string, number> = { dva: 2, tri: 3, štiri: 4, stiri: 4, pet: 5, šest: 6, sest: 6, sedem: 7 }
/**
 * »5 dni«, »petkrat«, »4x na teden« v besedah uporabnika → izrecno želeno število dni (null, če ga ni povedal).
 * Ne: »3x fitnes«, »fitnes 3x« (to je fitnes), »2 dni počitka«, »14 dni«, »5x5«, »pet kilogramov«, »dva otroka«.
 */
export function explicitDays(text: string | null | undefined): number | null {
  if (!text) return null
  const t = text.toLowerCase()
  // »vsak dan«, »vse dni«, »cel teden« = 7
  if (/vsak dan|vse dni|cel teden/u.test(t)) return 7
  const hits: { n: number; at: number; end: number }[] = []
  for (const m of t.matchAll(/(?<![\d.,])(\d)\s*(?:dni|dneva|dan|krat|x|×)(?![\d\p{L}])/gu)) hits.push({ n: +m[1]!, at: m.index!, end: m.index! + m[0].length })
  for (const m of t.matchAll(/(?<![\p{L}])(dva|tri|štiri|stiri|pet|šest|sest|sedem)(?:krat|\s*(?:dni|dneva|krat|x))(?![\p{L}])/gu)) hits.push({ n: NUM_WORD[m[1]!]!, at: m.index!, end: m.index! + m[0].length })
  const ok = hits.sort((a, b) => a.at - b.at).find(h => !SPORT_AFTER.test(t.slice(h.end)) && !SPORT_BEFORE.test(t.slice(Math.max(0, h.at - 16), h.at)) && !REST_AFTER.test(t.slice(h.end)))
  return ok && ok.n >= 1 && ok.n <= 7 ? ok.n : null
}

/** Izrecno število vadb po športu v besedah: »3x fitnes«, »dva teka«, »enkrat kolo« → { fitnes: 3, tek: 2, kolo: 1 }. */
export function explicitCounts(text: string | null | undefined): Partial<Record<FocusSport, number>> {
  const out: Partial<Record<FocusSport, number>> = {}
  if (!text) return out
  const t = text.toLowerCase()
  const NUM: Record<string, number> = { en: 1, ena: 1, enkrat: 1, dva: 2, dve: 2, dvakrat: 2, tri: 3, trikrat: 3, štiri: 4, stiri: 4, štirikrat: 4, pet: 5, petkrat: 5 }
  // cele besede (»tekme«, »kolegom«, »tečaj« niso šport)
  const SP: [FocusSport, RegExp][] = [['fitnes', /^(?:fitnes\p{L}*|mo(?:č|c)i?|teretan\p{L}*|telovadim)$/u], ['doma', /^doma$/], ['tek', /^(?:tek|teka|teke|teki|tekom|tekov|tekih|tečem|teče)$/u], ['kolo', /^(?:kolo|kolesa|kolesu|kolesom|kolesarjenj\p{L}*|kolesarim|vožnj\p{L}*|vožnje|vožnji)$/u], ['hribi', /^(?:hrib\p{L}*|pohod\p{L}*|sprehod\p{L}*)$/u]]
  const NUMS = '\\d|enkrat|ena|en|dvakrat|dva|dve|trikrat|tri|štirikrat|štiri|stiri|petkrat|pet'
  const num = (x: string) => (/\d/.test(x) ? +x : NUM[x] ?? 0)
  // šport najprej: »fitnes 3x, kolo 2x«
  for (const m of t.matchAll(new RegExp(`(?<![\\p{L}])(\\p{L}+)\\s+(${NUMS})\\s*(?:x|×|krat)(?![\\p{L}\\d])`, 'gu'))) {
    const n = num(m[2]!)
    if (!n || n > 7) continue
    for (const [sp, r] of SP) if (r.test(m[1]!) && out[sp] == null) out[sp] = n
  }
  const rx = /(?<![\p{L}\d.,])(\d|enkrat|ena|en|dvakrat|dva|dve|trikrat|tri|štirikrat|štiri|stiri|petkrat|pet)(?=x|×|krat|[^\p{L}\d]|$)\s*(?:x|×|krat)?\s*(?:na teden\s*)?(?:(?:dni|dneva|dan)\s+)?(?:(?:v|na|s|z)\s+)?(\p{L}+)/gu
  for (const m of t.matchAll(rx)) {
    const n = /\d/.test(m[1]!) ? +m[1]! : NUM[m[1]!] ?? 0
    if (!n || n > 7) continue
    for (const [sp, s] of SP) if (s.test(m[2]!) && out[sp] == null) out[sp] = n
  }
  return out
}

/**
 * Razmerje moč : kardio za n dni vadbe. Glavno »moč« — večinoma moč; »kardio« — večinoma kardio (moč 0, če je ni
 * izbral in ne želi mišic ali moči); »oboje« — pol-pol (moč ima prednost pri lihem, razen pri kondiciji, hujšanju, tekmi).
 */
export function targetMix(n: number, o: { main?: 'kardio' | 'oboje' | 'moc' | null; aims: readonly FocusAim[]; strengthOk: boolean; cardioOk: boolean; level: 1 | 2 | 3 }): { s: number; c: number } {
  if (n <= 0) return { s: 0, c: 0 }
  if (!o.cardioOk) return { s: n, c: 0 }
  if (!o.strengthOk) return { s: 0, c: n }
  const wantsMuscle = o.aims.some(a => a === 'misice' || a === 'moc' || a === 'definicija')
  const wantsEngine = o.aims.some(a => a === 'kondicija' || a === 'vzdrzljivost' || a === 'hujsanje' || a === 'tekma')
  let s: number
  // glavno moč: kardio 1× od 4 dni dalje; s ciljem kondicija, hujšanje, vzdržljivost ali tekma že od 3 dni
  if (o.main === 'moc') s = n <= 2 ? n : n - Math.max(wantsEngine ? 1 : 0, Math.floor(n / 4))
  else if (o.main === 'kardio') s = n <= 2 ? (wantsMuscle ? 1 : 0) : n <= 4 ? 1 : 2
  else s = n % 2 === 0 ? n / 2 : wantsEngine && !wantsMuscle ? (n - 1) / 2 : (n + 1) / 2
  // začetnik: moč 2–3× na teden je dovolj (celo telo)
  if (o.level === 1) s = Math.min(s, 3)
  s = Math.max(0, Math.min(n, s))
  return { s, c: n - s }
}

/**
 * Najdaljša smiselna vadba po vrsti in ravni (ko ima čas, ga trener porabi — do te meje): moč 50/70/75, lahek tek
 * 35/50/60, lahko kolo 60/90/120, intervali in tempo 45–90, dolga seja 1,5× časa do 60–180.
 */
export function ceilMin(s: Pick<AgreedSession, 'type' | 'cardio'>, level: 1 | 2 | 3): number {
  const L = level - 1
  if (isStrength(s)) return [50, 70, 75][L]!
  if (s.type === 'hribi') return 300
  const bike = s.type === 'kolo'
  if (s.cardio === 'dolgo') return bike ? [90, 150, 180][L]! : [60, 80, 100][L]!
  if (s.cardio === 'intervali' || s.cardio === 'tempo') return bike ? [60, 75, 90][L]! : [45, 50, 60][L]!
  return bike ? [60, 90, 120][L]! : [35, 50, 60][L]!
}

/** Seja moči ali kardia za dodajanje/menjavo (vrsta po tem, kar je v dogovoru). */
export function freshSession(f: Pick<Focus, 'sports' | 'equipment' | 'level' | 'sessions'>, kind: 'moc' | 'kardio', min: number): AgreedSession {
  if (kind === 'moc') {
    const type: FocusSport = f.sports.includes('fitnes') || f.equipment.includes('fitnes') ? 'fitnes' : 'doma'
    return { type, part: 'celo', min: Math.max(30, Math.min(ceilMin({ type, cardio: null }, f.level), min)) }
  }
  const cardio = (['kolo', 'tek', 'hribi'] as FocusSport[]).filter(s => f.sports.includes(s))
  const pool = cardio.length ? cardio : (['tek'] as FocusSport[])
  // najmanj zastopan kardio šport
  const used = (t: FocusSport) => f.sessions.filter(x => x.type === t && !x.after).length
  const type = [...pool].sort((a, b) => used(a) - used(b))[0]!
  // nova seja po meri ravni (začetnik: lahek tek do 35 min, ne 60)
  return { type, cardio: 'lahko', min: type === 'hribi' ? Math.max(45, min) : Math.max(type === 'tek' ? 20 : 30, Math.min(ceilMin({ type, cardio: 'lahko' }, f.level), min)) }
}

const isStrength = (s: Pick<AgreedSession, 'type'>) => s.type === 'fitnes' || s.type === 'doma'
export const isMainCardio = (s: AgreedSession) => !isStrength(s) && !s.after
