import type { AgreedSession, Focus, SessionPart } from '../types'
import { isStrength, tailsOf, normalizeFocus, trainingDays, PART_NAME } from './model'
import { wishSignals } from './rules'
import { scheduleWeek } from '../training/focusPlan'
import { DAY_SHORT, atDays } from './choices'

/**
 * TRENER RAZMISLI (Blaž, 11. 10.: »upošteva moje želje, ok, ampak mora še razmisliti, a je to pametno — napredovanje,
 * pavza vmes — in narediti najboljši možen plan«). Želje in dnevi uporabnika so okvir; tu se predlog (AI ali pravila)
 * pregleda kot bi ga trener: delitev sej moči (ne dvakrat isti del), lažji kardio po moči za začetnika, razmik med
 * težkimi dnevi, napredovanje po blokih. Kar spremeni ali zakaj je tako, pove v kratkih vrsticah (`focus.why`).
 */
export interface CoachReview { focus: Focus; why: string[]; changed: string[] }

const UPPER: readonly SessionPart[] = ['potisk', 'poteg', 'zgornji', 'roke', 'trebuh']
const GENERAL: readonly SessionPart[] = ['zgornji', 'spodnji', 'potisk', 'poteg', 'noge', 'celo']
/** del z razlago: »potisk (prsa, ramena, triceps)« */
const partWord = (p: SessionPart) => (p === 'potisk' ? 'potisk (prsa, ramena, triceps)' : p === 'poteg' ? 'poteg (hrbet, biceps)' : PART_NAME[p])
/** isti del večkrat → delitev po delu: zgornji ×2 = potisk + poteg … */
const SAME_PLAN: Partial<Record<SessionPart, SessionPart[]>> = { zgornji: ['potisk', 'poteg', 'zgornji', 'roke'], potisk: ['potisk', 'poteg', 'zgornji'], poteg: ['poteg', 'potisk', 'zgornji'], roke: ['roke', 'zgornji', 'potisk'], spodnji: ['spodnji', 'noge'], noge: ['noge', 'spodnji'] }

/**
 * Deli sej moči: isti del večkrat (dvakrat »zgornji del«) se razdeli (potisk + poteg), podvojen del dobi dopolnilnega;
 * dvakrat celo telo pri izkušenih = zgornji + spodnji (začetnik ostane pri celem telesu).
 */
export function splitStrengthParts(parts: readonly SessionPart[], o: { upperOnly: boolean; level: 1 | 2 | 3 }): SessionPart[] {
  if (parts.length < 2) return [...parts]
  const out = [...parts]
  // celo telo večkrat: začetnik ostane (vsaka vaja dvakrat na teden), izkušen dobi delitev
  if (out.every(p => p === 'celo')) {
    if (o.level < 2) return out
    const plan = o.upperOnly ? ['potisk', 'poteg', 'zgornji', 'roke'] : out.length === 2 ? ['zgornji', 'spodnji'] : out.length === 3 ? ['potisk', 'noge', 'poteg'] : ['zgornji', 'spodnji', 'potisk', 'poteg', 'celo', 'celo']
    return out.map((_, i) => (plan[i] ?? 'celo') as SessionPart)
  }
  // vse seje isti del (ne celo): delitev po tem delu
  if (out.every(p => p === out[0]) && SAME_PLAN[out[0]!]) {
    const plan = SAME_PLAN[out[0]!]!
    return out.map((p, i) => plan[i] ?? p)
  }
  const pref = o.upperOnly ? UPPER : GENERAL
  const seen = new Set<SessionPart>()
  for (let i = 0; i < out.length; i++) {
    const p = out[i]!
    if (p === 'celo' || !seen.has(p)) { seen.add(p); continue }
    const next = pref.find(x => !seen.has(x) && x !== 'celo') ?? (o.upperOnly ? 'zgornji' : 'celo')
    out[i] = next
    seen.add(next)
  }
  return out
}

const isHard = (s: AgreedSession) => isStrength(s) || s.cardio === 'intervali' || s.cardio === 'tempo'

/** Koliko vadb na teden je za to raven pametno za začetek (začetnik 4, nekaj izkušenj 5, izkušen 6). */
export const SENSIBLE_DAYS: Record<1 | 2 | 3, number> = { 1: 4, 2: 5, 3: 6 }
/** »5 dni«, »petkrat«, »4x na teden« v besedah uporabnika → izrecno želeno število dni (null, če ga ni povedal) */
export function explicitDays(text: string | null | undefined): number | null {
  if (!text) return null
  const t = text.toLowerCase()
  const m = /(\d)\s*(?:dni|dneva|dan|krat|x|×)(?![\p{L}])/u.exec(t) ?? /(?:^|[^\p{L}])(?:dva|tri|štiri|stiri|pet|šest|sest)(?:krat)?\s*(?:dni|dneva|krat|x)?(?![\p{L}])/u.exec(t)
  if (!m) return null
  const n = m[1] ? +m[1] : { dva: 2, tri: 3, štiri: 4, stiri: 4, pet: 5, šest: 6, sest: 6 }[m[0].trim().replace(/krat|\s*(?:dni|dneva|x)$/g, '').trim()] ?? null
  return n != null && n >= 1 && n <= 7 ? n : null
}
/** Odstrani zadnjo prosto sejo (najprej vrste, ki jih je največ), s kardiem po moči vred; določene šele, ko prostih ni. */
function dropSession(sessions: AgreedSession[]): AgreedSession[] {
  const tails = tailsOf(sessions)
  const main = sessions.map((_, i) => i).filter(i => !tails.has(i))
  const count = new Map<string, number>(); main.forEach(i => count.set(sessions[i]!.type, (count.get(sessions[i]!.type) || 0) + 1))
  const pick = (list: number[]) => [...list].sort((a, b) => (count.get(sessions[b]!.type)! - count.get(sessions[a]!.type)!) || b - a)[0]
  const loose = main.filter(i => sessions[i]!.day == null)
  const drop = loose.length ? pick(loose) : pick(main)
  if (drop == null) return sessions
  const gone = new Set([drop, ...[...tails.entries()].filter(([, m]) => m === drop).map(([t]) => t)])
  return sessions.filter((_, i) => !gone.has(i))
}

export function coachReview(f: Focus, o: { age?: number | null; /** število dni, ki ga je uporabnik izrecno povedal (ostane, trener le opozori) */ wantDays?: number | null } = {}): CoachReview {
  const why: string[] = []
  const changed: string[] = []
  let sessions: AgreedSession[] = f.sessions.map(x => ({ ...x }))

  // 0. preveč vadb za raven: začetnik 4, nekaj izkušenj 5 — razen če je število dni izrecno njegova želja (potem opozorilo)
  const cap = SENSIBLE_DAYS[f.level]
  const n0 = trainingDays(sessions)
  if (n0 > cap) {
    if (o.wantDays != null && o.wantDays >= n0) {
      why.push(`Hočeš ${n0} vadb na teden — ${f.level === 1 ? 'za začetnika' : 'pri nekaj izkušnjah'} je to zgornja meja. Prve 4 tedne so lažje (manj serij); če bo preveč, reci »manj dni« in dam ${cap}.`)
    } else {
      while (trainingDays(sessions) > cap) { const next = dropSession(sessions); if (next.length === sessions.length) break; sessions = next }
      why.push(`${f.level === 1 ? 'Začetnik' : 'Nekaj izkušenj'}: ${cap} vadbe na teden namesto ${n0} — telo rabi dneve, da se prilagodi, in napredek pride iz vadb, ki jih res narediš. ${n0 > cap + 1 ? 'Več' : 'Peto'} dodava po 4 tednih (ali reci »${n0} dni«).`)
      changed.push('manj vadb')
    }
  }
  const sig = wishSignals(f.wish)
  const upperOnly = sig.upperOnly || (f.muscles.length > 0 && f.muscles.every(m => m !== 'noge' && m !== 'zadnjica') && /samo zgornj|le zgornj|brez nog|ne nog/.test(f.wish.toLowerCase()))

  // 1. delitev moči
  const sIdx = sessions.map((s, i) => (isStrength(s) ? i : -1)).filter(i => i >= 0)
  if (sIdx.length >= 2) {
    const before = sIdx.map(i => (sessions[i]!.part || 'celo') as SessionPart)
    const after = splitStrengthParts(before, { upperOnly, level: f.level })
    if (after.some((p, k) => p !== before[k])) {
      sIdx.forEach((i, k) => { sessions[i] = { ...sessions[i]!, part: after[k]! } })
      const dup = before.find((p, k) => before.indexOf(p) !== k)
      why.push(dup && dup !== 'celo'
        ? `${sIdx.length === 2 ? 'Dve vadbi' : `${sIdx.length} vadbe`} »${PART_NAME[dup]}« sem razdelil na ${after.map(partWord).join(' + ')} — iste mišice tako počivajo 2–3 dni, kar je pogoj, da rastejo.`
        : `Moč sem razdelil na ${after.map(partWord).join(' + ')} — vsak del dobi svojo vadbo in dovolj počitka vmes.`)
      changed.push('deli moči')
    } else if (before.every(p => p === 'celo') && f.level === 1) {
      why.push('Začetnik: celo telo na vsaki vadbi — vsaka vaja dvakrat na teden je najhitrejša pot do navade in moči; delitev pride po nekaj tednih.')
    }
  }

  // 2. kardio po moči: za začetnika lahek (intervali in tempo pridejo pozneje)
  const tails = tailsOf(sessions)
  if (f.level === 1) {
    let n = 0
    tails.forEach((_, t) => { const s = sessions[t]!; if (s.cardio === 'intervali' || s.cardio === 'tempo') { sessions[t] = { ...s, cardio: 'lahko' }; n++ } })
    if (n) { why.push('Tek po moči je lahek — kot začetnik hitre dele dodaš po 4 tednih, ko je tehnika ustaljena.'); changed.push('kardio po moči lahek') }
  }

  // 3. razmik med težkimi dnevi (iz razporeda, ki ga bo naredila aplikacija)
  const open = [0, 1, 2, 3, 4, 5, 6].filter(d => !(f.offDays || []).includes(d))
  const order = scheduleWeek(sessions, open, f.preferDays, 7)
  const hardDays = order.map((k, d) => (k != null && isHard(sessions[k]!) ? d : -1)).filter(d => d >= 0)
  const trainDays = order.map((k, d) => (k != null ? d : -1)).filter(d => d >= 0)
  const adjacentHard: [number, number][] = []
  for (const d of hardDays) { const n = (d + 1) % 7; if (hardDays.includes(n)) adjacentHard.push([d, n]) }
  const nDays = trainingDays(sessions)
  if (nDays >= 2) {
    if (!adjacentHard.length) why.push(`Težki dnevi (${hardDays.map(d => DAY_SHORT[d]).join(', ')}) imajo vmes vedno dan premora — takrat telo gradi, kar si na vadbi sprožil.`)
    else {
      const [a, b] = adjacentHard[0]!
      const sa = sessions[order[a]!]!, sb = sessions[order[b]!]!
      const diff = isStrength(sa) && isStrength(sb) ? 'na različnih mišicah' : 'različni (moč in kardio)'
      why.push(`Pri ${nDays} vadbah na ${open.length} dni sta ${DAY_SHORT[a]} in ${DAY_SHORT[b]} zapored — vadbi sta ${diff}, ostali težki dnevi imajo premor.`)
    }
    const restN = 7 - trainDays.length
    why.push(`${restN} ${restN === 1 ? 'dan' : restN === 2 ? 'dneva' : 'dni'} počitka na teden (${atDays([0, 1, 2, 3, 4, 5, 6].filter(d => !trainDays.includes(d)))}) — spanec in hrana sta del treninga.`)
  }

  // 4. napredovanje
  why.push('Napredovanje po blokih 4 tednov: 1. teden navada in tehnika, 2. in 3. več (teža in minute gor), 4. lažji teden — tako greš naprej brez pretreniranosti.')

  const next = changed.length ? normalizeFocus({ ...f, sessions, why: why.slice(0, 5) }, { age: o.age, by: f.by, now: f.at }) : null
  const focus: Focus = next ? { ...next, title: f.title || next.title, notes: f.notes, strategy: f.strategy ?? null } : { ...f, why: why.slice(0, 5) }
  return { focus, why: why.slice(0, 5), changed }
}
