import type { AgreedSession, Focus, FocusAim, FocusSport, SessionPart } from '../types'
import { isStrength, tailsOf, normalizeFocus, trainingDays, PART_NAME, kgStrength } from './model'
import { wishSignals, fitNotes, adjacentDays } from './rules'
import { scheduleWeek, otherCtx } from '../training/focusPlan'
import { DAY_SHORT, atDays, picksStrength, picksCardio, otherSportDays, type Picks } from './choices'
import type { DoseHint } from '../ai/focusAi'
import { targetMix, freshSession, ceilMin, rangeIn, daysRangeIn, minutesIn, minutesRange, weekMinutesIn, levelFrom, explicitCounts, explicitDays } from './dose'
import { fmtDur } from '../training/load'
import { healthOf } from '../training/exercises'

const fmtMin = (m: number) => fmtDur(m)
/** (v3.48) Najdaljša vadba po krajšanju (brez kardia takoj po moči), z »raje lažje« (−15 % v 3b) — za razlago trajanj. */
const beginnerTop = (ss: readonly AgreedSession[], k: number) => { const top = Math.max(0, ...ss.filter(x => !x.after).map(x => x.min)); return k < 1 && top > 30 ? Math.max(30, Math.round(top * k / 5) * 5) : top }

/**
 * TRENER RAZMISLI (Blaž, 11. 10.: »upošteva moje želje, ok, ampak mora še razmisliti, a je to pametno — napredovanje,
 * pavza vmes — in narediti najboljši možen plan«). Želje in dnevi uporabnika so okvir; tu se predlog (AI ali pravila)
 * pregleda kot bi ga trener: delitev sej moči (ne dvakrat isti del), lažji kardio po moči za začetnika, razmik med
 * težkimi dnevi, napredovanje po blokih. Kar spremeni ali zakaj je tako, pove v kratkih vrsticah (`focus.why`).
 */
export interface CoachReview { focus: Focus; why: string[]; changed: string[] }

const UPPER: readonly SessionPart[] = ['potisk', 'poteg', 'zgornji', 'roke', 'trebuh']
/** običajne delitve po številu sej moči: 2 zgornji/spodnji, 3 potisk/noge/poteg, 4 zgornji/spodnji ×2, 5 PPL + ZS, 6 PPL ×2 */
const STD_SPLIT: Record<number, SessionPart[]> = { 2: ['zgornji', 'spodnji'], 3: ['potisk', 'noge', 'poteg'], 4: ['zgornji', 'spodnji', 'zgornji', 'spodnji'], 5: ['potisk', 'noge', 'poteg', 'zgornji', 'spodnji'], 6: ['potisk', 'noge', 'poteg', 'potisk', 'noge', 'poteg'] }
const sameSplit = (a: readonly SessionPart[], b: readonly SessionPart[]) => a.length === b.length && [...a].sort().join() === [...b].sort().join()
const GENERAL: readonly SessionPart[] = ['zgornji', 'spodnji', 'potisk', 'poteg', 'noge', 'celo']
/** del z razlago: »potisk (prsa, ramena, triceps)« */
const partWord = (p: SessionPart) => (p === 'potisk' ? 'potisk (prsa, ramena, triceps)' : p === 'poteg' ? 'poteg (hrbet, biceps)' : PART_NAME[p])
/** isti del večkrat → delitev po delu: zgornji ×2 = potisk + poteg … */
const SAME_PLAN: Partial<Record<SessionPart, SessionPart[]>> = { zgornji: ['potisk', 'poteg', 'zgornji', 'roke'], potisk: ['potisk', 'poteg', 'zgornji'], poteg: ['poteg', 'potisk', 'zgornji'], roke: ['roke', 'zgornji', 'potisk'], spodnji: ['spodnji', 'noge'], noge: ['noge', 'spodnji'] }

/**
 * Deli sej moči: isti del večkrat (dvakrat »zgornji del«) se razdeli (potisk + poteg), podvojen del dobi dopolnilnega;
 * dvakrat celo telo pri izkušenih = zgornji + spodnji (začetnik ostane pri celem telesu).
 */
export function splitStrengthParts(parts: readonly SessionPart[], o: { upperOnly: boolean; level: 1 | 2 | 3; aims?: readonly FocusAim[]; days?: readonly (number | null | undefined)[] }): SessionPart[] {
  if (parts.length < 2) return [...parts]
  // (v3.49) cilj mišice: vsaka mišica vsaj 2× na teden (celo telo A/B, zgornji/spodnji/celo), kjer dnevi to dopuščajo
  const freq = !o.upperOnly && o.level >= 2 && !!o.aims?.includes('misice')
  // znana delitev (zgornji/spodnji ×2, PPL ×2) ostane, kot je
  if (!o.upperOnly && o.level >= 2 && STD_SPLIT[parts.length] && sameSplit(parts, STD_SPLIT[parts.length]!)) return [...parts]
  const out = [...parts]
  // celo telo večkrat: začetnik ostane (vsaka vaja dvakrat na teden), izkušen dobi delitev
  if (out.every(p => p === 'celo')) {
    if (o.level < 2) return out
    // dvakrat celo telo ostane — razen na zaporednih dneh (iste mišice dva dni zapored)
    if (freq && out.length === 2 && !adjacentDays(o.days || [])) return out
    const plan = o.upperOnly ? ['potisk', 'poteg', 'zgornji', 'roke'] : out.length === 2 ? ['zgornji', 'spodnji'] : out.length === 3 ? (freq ? ['zgornji', 'spodnji', 'celo'] : ['potisk', 'noge', 'poteg']) : ['zgornji', 'spodnji', 'potisk', 'poteg', 'celo', 'celo']
    return out.map((_, i) => (plan[i] ?? 'celo') as SessionPart)
  }
  // vse seje isti del (ne celo): delitev po tem delu
  if (out.every(p => p === out[0]) && SAME_PLAN[out[0]!]) {
    const plan = SAME_PLAN[out[0]!]!
    return out.map((p, i) => plan[i] ?? p)
  }
  const pref = o.upperOnly ? UPPER : GENERAL
  const seen = new Set<SessionPart>()
  for (let i = 0; i < out.length; i++) {
    const p = out[i]!
    if (p === 'celo' || !seen.has(p)) { seen.add(p); continue }
    const next = pref.find(x => !seen.has(x) && x !== 'celo') ?? (o.upperOnly ? 'zgornji' : 'celo')
    out[i] = next
    seen.add(next)
  }
  return out
}

const isHard = (s: AgreedSession) => isStrength(s) || s.cardio === 'intervali' || s.cardio === 'tempo'

/** Koliko vadb na teden je za to raven pametno za začetek (začetnik 4, nekaj izkušenj 5, izkušen 6). */
export const SENSIBLE_DAYS: Record<1 | 2 | 3, number> = { 1: 4, 2: 5, 3: 6 }
// (v3.49) explicitDays je v dose.ts (rabi ga tudi vprašalnik brez AI — rules.ts), tu ostane za stare uvoze
export { explicitDays }
/** Odstrani zadnjo prosto sejo (najprej vrste, ki jih je največ), s kardiem po moči vred; določene šele, ko prostih ni. */
function dropSession(sessions: AgreedSession[]): AgreedSession[] {
  const tails = tailsOf(sessions)
  const main = sessions.map((_, i) => i).filter(i => !tails.has(i))
  const count = new Map<string, number>(); main.forEach(i => count.set(sessions[i]!.type, (count.get(sessions[i]!.type) || 0) + 1))
  const pick = (list: number[]) => [...list].sort((a, b) => (count.get(sessions[b]!.type)! - count.get(sessions[a]!.type)!) || b - a)[0]
  const loose = main.filter(i => sessions[i]!.day == null)
  const drop = loose.length ? pick(loose) : pick(main)
  if (drop == null) return sessions
  const gone = new Set([drop, ...[...tails.entries()].filter(([, m]) => m === drop).map(([t]) => t)])
  return sessions.filter((_, i) => !gone.has(i))
}

/** Kar trener ve iz pogovora (vse neobvezno). */
export interface CoachOpts {
  age?: number | null
  /** število dni, ki ga je uporabnik izrecno povedal (»4 dni«) — velja; več od tega ne, manj samo z opozorilom */
  wantDays?: number | null
  /** razpon dni (»3-4 krat na teden«): izkušen in ne »raje lažje« dobi zgornjo mejo, sicer spodnjo */
  daysRange?: { lo: number; hi: number } | null
  /** tip: raje lažje / zmerno / trdo */
  push?: 'lahko' | 'zmerno' | 'trdo' | null
  /** glavno: kardio / oboje / moč */
  main?: 'kardio' | 'oboje' | 'moc' | null
  /** koliko minut ima za eno vadbo (strop) — starejši način, enako kot minRange { lo: x, hi: x } */
  sessionMin?: number | null
  /** čas na vadbo (»60 do 75 minut«): zgornja meja je strop, vadbe trener napolni do sredine (do mere za raven) */
  minRange?: { lo: number; hi: number } | null
  /** pogajanje brez besed o dnevih: število vadb ostane, kot ga je dal AI po njegovi pripombi (ne dodajaj, ne odvzemaj) */
  asIs?: boolean
  /** vadbe podaljšaj do časa, ki ga ima (v pogajanju samo, če je o času govoril — »krajše« naj ostane krajše) */
  raise?: boolean
  /** tedenski čas (»6–8 h na teden«) v minutah — razdeli se na vadbe, če časa na vadbo ni povedal */
  weekMin?: { lo: number; hi: number } | null
  /** raven iz njegovih izbir in odgovorov (»Izkušnje: občasno«, 5–8 zgibov) — ima prednost pred AI */
  levelHint?: 1 | 2 | 3 | null
  /**
   * Prvi predlog: razmerje moč : kardio po cilju in »glavnem« (in izrecnem številu: »3x fitnes«). V pogajanju ga ni —
   * tam odloča uporabnik s svojimi besedami. strengthOk / cardioOk: ali je moč oz. kardio sploh izbral.
   */
  mix?: { strengthOk: boolean; cardioOk: boolean; counts?: Partial<Record<FocusSport, number>>; cardioSports?: readonly FocusSport[] } | null
  /** (v3.50) koliko zdaj preteče (odgovor »10–25 km«): strop teka na teden v prvem predlogu */
  run?: { said: string; cap: number } | null
}
/** (v3.50) odgovor o km na teden → strop minut teka na teden (~6 min na km, zgornja meja razpona) */
export function runCapOf(a: string): { said: string; cap: number } | null {
  const t = a.toLowerCase()
  const r = /(\d{1,3})\s*[–-]\s*(\d{1,3})\s*km/.exec(t), d = /do\s+(\d{1,3})\s*km/.exec(t)
  const hi = r ? +r[2]! : d ? +d[1]! : null
  return hi && hi <= 60 ? { said: a.trim().replace(/^do\b/i, 'do'), cap: Math.max(60, hi * 6 + (hi <= 10 ? 15 : 0)) } : null
}

const LEVEL_WORD: Record<1 | 2 | 3, string> = { 1: 'Začetnik', 2: 'Nekaj izkušenj', 3: 'Izkušen' }
const ORD: Record<number, string> = { 3: 'Tretjo', 4: 'Četrto', 5: 'Peto', 6: 'Šesto', 7: 'Sedmo' }
const vadbe = (n: number) => (n === 1 ? 'vadba' : n === 2 ? 'vadbi' : n <= 4 ? 'vadbe' : 'vadb')
const CARDIO_WORD: Record<string, string> = { kolo: 'kolo', tek: 'tek', hribi: 'hoja ali pohod' }
const r5 = (x: number) => Math.round(x / 5) * 5

/**
 * Koliko vadb: njegova beseda (»4 dni«) > razpon (»3-4«: izkušen in ne »raje lažje« zgornja meja, a ne čez pametno za
 * raven) > nič (AI predlaga, trener omeji na pametno za raven: začetnik 4, nekaj izkušenj 5, izkušen 6; tip ±1).
 */
const saidStrength = (c?: Partial<Record<FocusSport, number>>) => (c && (c.fitnes != null || c.doma != null) ? (c.fitnes ?? 0) + (c.doma ?? 0) : null)
const saidCardio = (c?: Partial<Record<FocusSport, number>>) => (c && (c.tek != null || c.kolo != null || c.hribi != null) ? (c.tek ?? 0) + (c.kolo ?? 0) + (c.hribi ?? 0) : null)
/**
 * Razmerje moč : kardio za n vadb — izrecno število (»3x fitnes«) velja; ostanek gre v drugo vrsto samo, če jo je
 * izbral; sicer po cilju in »glavnem« (targetMix). Isto za trenerja in za poziv AI.
 */
export function mixFor(n: number, o: { main?: CoachOpts['main']; aims: readonly FocusAim[]; level: 1 | 2 | 3; strengthOk: boolean; cardioOk: boolean; counts?: Partial<Record<FocusSport, number>> }): { s: number; c: number } {
  const sSaid = saidStrength(o.counts), cSaid = saidCardio(o.counts)
  if (sSaid != null && cSaid != null) { const k = Math.min(n, sSaid); return { s: k, c: n - k } }
  if (sSaid != null) { const k = Math.min(n, sSaid); return o.cardioOk || !o.strengthOk ? { s: k, c: n - k } : { s: n, c: 0 } }
  if (cSaid != null) { const k = Math.min(n, cSaid); return o.strengthOk || !o.cardioOk ? { s: n - k, c: k } : { s: 0, c: n } }
  return targetMix(n, { main: o.main ?? null, aims: o.aims, strengthOk: o.strengthOk, cardioOk: o.cardioOk, level: o.level })
}

export function planDays(level: 1 | 2 | 3, o: Pick<CoachOpts, 'wantDays' | 'daysRange' | 'push'>, openDays: number, everyDay = false): { cap: number; want: number | null; range: { lo: number; hi: number } | null } {
  const cap = Math.max(2, Math.min(6, SENSIBLE_DAYS[level] + (o.push === 'trdo' ? 1 : o.push === 'lahko' ? -1 : 0)))
  // začetnik največ 5 (tako kot varovalke v dogovoru), vsak dan samo izkušenejši
  const maxDays = Math.min(openDays, level === 1 ? 5 : everyDay ? 7 : 6)
  let want: number | null = o.wantDays ?? null
  const range = want == null && o.daysRange ? o.daysRange : null
  if (range) {
    want = level >= 2 && o.push !== 'lahko' ? range.hi : range.lo
    if (want > cap) want = Math.max(range.lo, cap)
  }
  if (want != null) want = Math.max(1, Math.min(want, maxDays))
  return { cap, want, range }
}

export function coachReview(f0: Focus, o: CoachOpts = {}): CoachReview {
  const why: string[] = []
  const changed: string[] = []
  // raven iz njegovih besed (izbira »Izkušnje«, zgibi, kilometri) ima prednost pred AI — ta jo je včasih izpustil (= začetnik)
  let f = f0
  if (o.levelHint && o.levelHint !== f0.level) { f = { ...f0, level: o.levelHint }; changed.push('raven') }
  let sessions: AgreedSession[] = f.sessions.map(x => ({ ...x }))

  // 0. ŠTEVILO VADB: njegove besede (»4 dni«, »3-4 krat«) > pametno za raven (začetnik 4, nekaj izkušenj 5, izkušen 6;
  //    kdor je raje manj naložen, dan manj, kdor je raje trdo, dan več) > dnevi, ko ima čas
  // »vsak dan« (7) je izrecna želja — dogovor to ve (sicer ga varovalke spustijo na 6)
  if (o.wantDays === 7 && !f.everyDay && f.level > 1) { f = { ...f, everyDay: true }; changed.push('vsak dan') }
  const planned = planDays(f.level, o, 7 - (f.offDays?.length || 0), !!f.everyDay)
  const { cap, range } = planned
  const n0 = trainingDays(sessions)
  const want = o.asIs ? n0 : planned.want
  // čas na vadbo: »60 do 75 minut« ali tedenske ure (kolesar: »6–8 h na teden«) razdeljene na vadbe
  const nPlan = want ?? n0
  const minR = o.minRange ?? (o.sessionMin ? { lo: o.sessionMin, hi: o.sessionMin } : null)
    ?? (o.weekMin && nPlan ? { lo: Math.max(20, r5(o.weekMin.lo / nPlan)), hi: Math.max(30, r5(o.weekMin.hi / nPlan)) } : null)
  const minTarget = minR ? r5((minR.lo + minR.hi) / 2) : null
  if (want != null && n0 > want) {
    // AI je dal več, kot je rekel: velja njegova beseda
    while (trainingDays(sessions) > want) { const next = dropSession(sessions); if (next.length === sessions.length) break; sessions = next }
    changed.push('manj vadb')
    why.push(range ? `Rekel si ${range.lo}–${range.hi}× na teden: ${want} ${want === range.hi ? '— že treniraš, zato zgornja meja' : 'za začetek, več dodava po 4 tednih'}.` : `${want} ${want === 1 ? 'vadba' : want <= 4 ? 'vadbe' : 'vadb'} na teden, kot si rekel.`)
  } else if (n0 > cap && !(want != null && want >= n0)) {
    while (trainingDays(sessions) > cap) { const next = dropSession(sessions); if (next.length === sessions.length) break; sessions = next }
    why.push(`${LEVEL_WORD[f.level]}: ${cap} ${vadbe(cap)} na teden namesto ${n0} — telo rabi dneve, da se prilagodi, in napredek pride iz vadb, ki jih res narediš. ${n0 > cap + 1 ? 'Več' : ORD[cap + 1] ?? 'Več'} dodava po 4 tednih (ali reci »${n0} dni«).`)
    changed.push('manj vadb')
  } else if (n0 > cap) {
    // (v3.50) rekel je več, kot jih dogovor dovoli (začetnik največ 5, prosti dnevi): povej njegovo število, ne našega
    const said = o.wantDays != null && o.wantDays > n0 ? o.wantDays : null
    why.push(said
      ? `Rekel si ${said === 7 ? 'vsak dan' : `${said}× na teden`} — ${f.level === 1 && n0 === 5 ? `za začetek jih dam ${n0}, ${said === n0 + 1 ? ORD[n0 + 1]!.toLowerCase() : 'več'} dodava po 4 tednih, ko telo zdrži` : `dni s časom je ${n0}, zato ${n0} ${vadbe(n0)}`}. Prve 4 tedne so lažje (manj serij); če bo preveč, reci »manj dni« in dam ${cap}.`
      : `Hočeš ${n0} ${vadbe(n0)} na teden — ${f.level === 1 ? 'za začetnika' : f.level === 2 ? 'pri nekaj izkušnjah' : 'tudi za izkušenega'} je to zgornja meja. Prve 4 tedne so lažje (manj serij); če bo preveč, reci »manj dni« in dam ${cap}.`)
  }
  // premalo vadb za to, kar je rekel: dodaj (vrsta po razmerju, ki ga hoče)
  const sOk = o.mix ? o.mix.strengthOk : sessions.some(isStrength)
  const cOk = o.mix ? o.mix.cardioOk : sessions.some(x => !isStrength(x))
  const sportsAll = [...new Set([...f.sports, ...(o.mix?.cardioSports || [])])]
  const mixOf = (n: number) => targetMix(n, { main: o.main ?? f.main ?? null, aims: f.aims, strengthOk: sOk || !cOk, cardioOk: cOk || !sOk, level: f.level })
  if (want != null && trainingDays(sessions) < want) {
    const tgt = mixOf(want)
    while (trainingDays(sessions) < want) {
      const tails = tailsOf(sessions)
      const mainS = sessions.filter((_, i) => !tails.has(i))
      const sN = mainS.filter(isStrength).length
      const kind: 'moc' | 'kardio' = sN < tgt.s ? 'moc' : mainS.length - sN < tgt.c ? 'kardio' : tgt.s >= tgt.c ? 'moc' : 'kardio'
      sessions.push(freshSession({ sports: sportsAll, equipment: f.equipment, level: f.level, sessions }, kind, minTarget ?? f.minutes ?? 45))
    }
    changed.push('vec vadb')
    if (want > cap) why.push(`${want} ${vadbe(want)} na teden, kot hočeš — ${f.level === 1 ? 'za začetnika' : 'pri tvoji ravni'} je to veliko: prve 4 tedne so lažje (manj serij); če bo preveč, reci »manj dni« in dam ${cap}.`)
    else why.push(range ? `Rekel si ${range.lo}–${range.hi}× na teden: ${want}${want === range.hi && range.hi > range.lo ? ' — že treniraš, zato zgornja meja' : ' za začetek, več dodava po 4 tednih'}.` : `${want} ${want <= 4 ? 'vadbe' : 'vadb'} na teden, kot si rekel.`)

  }

  // 0b. RAZMERJE MOČ : KARDIO (samo prvi predlog): po cilju in »glavnem« ali po izrecnem številu (»3x fitnes«)
  if (o.mix) {
    const tails = tailsOf(sessions)
    const mainIdx = sessions.map((_, i) => i).filter(i => !tails.has(i))
    const n = mainIdx.length
    const tgt = mixFor(n, { main: o.main ?? f.main ?? null, aims: f.aims, level: f.level, strengthOk: sOk || !cOk, cardioOk: cOk || !sOk, counts: o.mix.counts })
    const sSaid = saidStrength(o.mix.counts), cSaid = saidCardio(o.mix.counts)
    const strengthNow = () => mainIdx.filter(i => isStrength(sessions[i]!))
    const cardioNow = () => mainIdx.filter(i => !isStrength(sessions[i]!))
    // menjajo se samo seje brez dneva, ki ga je rekel; moč brez kardia po njej; dolga seja ostane
    const hasTail = (i: number) => [...tailsOf(sessions).values()].includes(i)
    let swapped = 0
    for (let guard = 0; guard < 7 && strengthNow().length > tgt.s; guard++) {
      const i = [...strengthNow()].reverse().find(k => sessions[k]!.day == null && !hasTail(k))
      if (i == null) break
      const x = freshSession({ sports: sportsAll, equipment: f.equipment, level: f.level, sessions }, 'kardio', Math.max(minTarget ?? 0, sessions[i]!.min))
      sessions[i] = x; swapped++
    }
    for (let guard = 0; guard < 7 && cardioNow().length > tgt.c; guard++) {
      const i = [...cardioNow()].reverse().find(k => sessions[k]!.day == null && sessions[k]!.cardio !== 'dolgo') ?? [...cardioNow()].reverse().find(k => sessions[k]!.day == null)
      if (i == null) break
      sessions[i] = freshSession({ sports: sportsAll, equipment: f.equipment, level: f.level, sessions }, 'moc', Math.max(minTarget ?? 0, sessions[i]!.min)); swapped++
    }
    // kardio vrste, ki jih ni izbral (AI je dal tek, on hoče kolo): zamenjaj z izbranimi (vrsta in trajanje ostaneta)
    const cWant = (o.mix.cardioSports || []).filter(x => x === 'kolo' || x === 'tek' || x === 'hribi') as FocusSport[]
    const saidC = o.mix.counts || {}
    if (cWant.length) {
      let sw = 0
      for (const i of cardioNow()) {
        const x = sessions[i]!
        if (cWant.includes(x.type) || saidC[x.type] != null || x.day != null) continue
        const used = (t: FocusSport) => sessions.filter(y => y.type === t).length
        const to = [...cWant].sort((a, b) => used(a) - used(b))[0]!
        sessions[i] = { ...x, type: to, cardio: to === 'hribi' ? 'lahko' : x.cardio, min: to === 'hribi' ? Math.max(45, x.min) : x.min }
        sw++
      }
      if (sw) { changed.push('vrsta kardia'); why.push(`Kardio je ${cWant.map(t => CARDIO_WORD[t]).join(' in ')}, kot si izbral — ne drugi šport.`) }
    }
    if (swapped) {
      changed.push('razmerje')
      const s = strengthNow().length, k = cardioNow().length
      const cw = [...new Set(cardioNow().map(i => CARDIO_WORD[sessions[i]!.type] ?? sessions[i]!.type))].join(' in ')
      const m = o.main ?? f.main
      const reason = sSaid != null || cSaid != null ? 'kot si rekel' : m === 'kardio' ? (s ? 'glavno ti je kardio, moč ostane za jedro in noge' : 'glavno ti je kardio') : m === 'moc' ? (k ? 'glavno ti je moč, kardio je za srce in obnovo' : 'glavno ti je moč') : 'moč in kondicija rasteta skupaj'
      why.push(`Razmerje: ${s ? `${s}× moč` : ''}${s && k ? ' + ' : ''}${k ? `${k}× ${cw || 'kardio'}` : ''} — ${reason}.`)
    }
  }
  const sig = wishSignals(f.wish)
  const upperOnly = sig.upperOnly || (f.muscles.length > 0 && f.muscles.every(m => m !== 'noge' && m !== 'zadnjica') && /samo zgornj|le zgornj|brez nog|ne nog/.test(f.wish.toLowerCase()))
  // število sej moči se je spremenilo (dodal, zamenjal): deli na novo — ena seja je celo telo, dve zgornji + spodnji …
  if (changed.includes('razmerje') || changed.includes('vec vadb')) {
    const idx = sessions.map((x, i) => (isStrength(x) ? i : -1)).filter(i => i >= 0)
    const k = idx.length
    const plan: SessionPart[] = upperOnly
      ? (k === 1 ? ['zgornji'] : ['potisk', 'poteg', 'zgornji', 'roke'])
      : k === 1 ? ['celo'] : f.level === 1 ? Array(k).fill('celo')
      // (v3.49) cilj mišice: vsaka mišica 2× na teden
      : f.aims.includes('misice') && k === 2 ? ['celo', 'celo'] : f.aims.includes('misice') && k === 3 ? ['zgornji', 'spodnji', 'celo'] : (STD_SPLIT[k] ?? ['celo'])
    idx.forEach((i, j) => { sessions[i] = { ...sessions[i]!, part: plan[j] ?? 'celo' } })
  }

  // 1. delitev moči
  const sIdx = sessions.map((s, i) => (isStrength(s) ? i : -1)).filter(i => i >= 0)
  if (sIdx.length >= 2) {
    const before = sIdx.map(i => (sessions[i]!.part || 'celo') as SessionPart)
    const freq = !upperOnly && f.level >= 2 && f.aims.includes('misice')
    const after = splitStrengthParts(before, { upperOnly, level: f.level, aims: f.aims, days: sIdx.map(i => sessions[i]!.day) })
    if (after.some((p, k) => p !== before[k])) {
      sIdx.forEach((i, k) => { sessions[i] = { ...sessions[i]!, part: after[k]! } })
      const dup = before.find((p, k) => before.indexOf(p) !== k)
      why.push(dup && dup !== 'celo'
        ? `${sIdx.length === 2 ? 'Dve vadbi' : `${sIdx.length} vadbe`} »${PART_NAME[dup]}« sem razdelil na ${after.map(partWord).join(' + ')} — iste mišice tako počivajo 2–3 dni, kar je pogoj, da rastejo.`
        : freq && after.includes('celo') ? `Moč sem razdelil na ${after.map(partWord).join(' + ')} — vsaka mišica pride na vrsto 2× na teden, vmes ima dovolj počitka.`
        : `Moč sem razdelil na ${after.map(partWord).join(' + ')} — vsak del dobi svojo vadbo in dovolj počitka vmes.`)
      changed.push('deli moči')
    } else if (before.every(p => p === 'celo') && f.level === 1) {
      why.push('Začetnik: celo telo na vsaki vadbi — vsaka vaja dvakrat na teden je najhitrejša pot do navade in moči; delitev pride po nekaj tednih.')
    } else if (freq && before.length === 2 && before.every(p => p === 'celo')) {
      // (v3.49) cilj mišice: dvakrat celo telo (A/B) namesto zgornji + spodnji
      why.push('Celo telo 2× na teden — vsaka mišica dobi dva dražljaja na teden (pri delitvi na zgornji in spodnji del samo enega).')
    }
  }

  // 2. kardio po moči: za začetnika lahek (intervali in tempo pridejo pozneje)
  const tails = tailsOf(sessions)
  if (f.level === 1) {
    let n = 0
    tails.forEach((_, t) => { const s = sessions[t]!; if (s.cardio === 'intervali' || s.cardio === 'tempo') { sessions[t] = { ...s, cardio: 'lahko' }; n++ } })
    if (n) { why.push('Tek po moči je lahek — kot začetnik hitre dele dodaš po 4 tednih, ko je tehnika ustaljena.'); changed.push('kardio po moči lahek') }
  }

  // raje lažje (prvi predlog): vadbe so na koncu ~15 % krajše (3b) — razlaga pove končno dolžino
  const lightK = o.push === 'lahko' && o.mix ? 0.85 : 1
  // vrstice teh pravil pridejo v »zakaj tako« za razmikom in počitkom (tisto je najpomembnejše)
  const later: string[] = []
  let touched = false
  // 3c. TRAJANJA PO RAVNI IN VRSTI (AI včasih da začetniku 90 min moči ali 20 min »dolgega« teka):
  //     moč začetnik 30–50, sicer 35–75; lahek kardio 20–90, intervali 25–50, tempo 30–60, dolgo 60–180 (hribi do 300);
  //     čas na vadbo iz vprašalnika je strop (dolga seja sme čez do 1,5×)
  {
    // (v3.50) touched: tudi sprememba za 5 min velja (prej se je zavrgla — rekel 30 min, dobil 25); n in up le za razlago
    let n = 0, up = 0, down = 0
    sessions = sessions.map(x => {
      const y = { ...x }
      const [lo, hi0] = isStrength(y) ? (f.level === 1 ? [30, 50] : [35, 75])
        : y.type === 'hribi' ? [30, 300] : y.cardio === 'dolgo' ? [60, 180] : y.cardio === 'intervali' ? [25, 50] : y.cardio === 'tempo' ? [30, 60] : [20, 90]
      // (v3.49) v pogajanju in pri spremembi dni do mere za raven (ceilMin), do katere jih je trener podaljšal v prvem
      // predlogu — prej je vsak krog kolesarju vožnje skrajšal (»več kardia«: 7 h 15 min → 6 h 25 min)
      const hi = o.mix ? hi0 : Math.max(hi0, ceilMin(y, f.level))
      let m = Math.max(lo, Math.min(hi, y.min))
      if (y.after) m = Math.min(m, 30)   // kardio takoj po moči: kratek
      // začetnik pri teku: kratko (sklepi in kite se prilagajajo počasneje kot srce) — lahek do 40 min, dolg do 60
      if (f.level === 1 && y.type === 'tek') m = Math.min(m, y.cardio === 'dolgo' ? 60 : 40)
      if (minR && !y.after) m = Math.min(m, y.cardio === 'dolgo' ? r5(minR.hi * 1.5) : minR.hi)
      // ima čas (»60 do 75 minut«): vadba ga porabi — do sredine razpona, a ne čez mero za raven (lahek tek začetnika 35 min)
      if (minR && minTarget && o.raise !== false && !y.after && y.type !== 'hribi') {
        const goal = Math.min(y.cardio === 'dolgo' ? Math.max(minTarget, r5(minR.hi * 1.25)) : minTarget, ceilMin(y, f.level))
        if (m < goal) { if (r5(goal) - y.min >= 10) up++; m = goal }
      }
      m = Math.max(15, Math.round(m / 5) * 5)
      if (m !== y.min) { touched = true; if (Math.abs(m - y.min) >= 10) { n++; if (m < y.min) down++ } y.min = m }
      return y
    })
    const shown = r5(minTarget ? minTarget * lightK : 0)
    const had = o.minRange || o.sessionMin ? `Imaš ${minR!.lo === minR!.hi ? fmtMin(minR!.hi) : `${minR!.lo}–${minR!.hi} min`} na vadbo` : o.weekMin ? `Imaš ${o.weekMin.lo === o.weekMin.hi ? fmtMin(o.weekMin.hi) : `${o.weekMin.lo / 60}–${o.weekMin.hi / 60} h`} na teden` : 'Imaš čas'
    // (v3.50) »(lahke krajše …)« samo, ko je kakšna lahka vadba res krajša od tega časa
    const lightShorter = !!minTarget && sessions.some(x => !isStrength(x) && !x.after && x.type !== 'hribi' && (x.cardio ?? 'lahko') === 'lahko' && x.min < minTarget)
    if (n) { changed.push('trajanja'); later.push(up ? `${had} — vadbe sem podaljšal do ~${fmtMin(shown)}${o.weekMin && !o.minRange ? ', dolga ob vikendu več' : ''}${lightShorter ? ' (lahke krajše po meri tvoje ravni)' : ''}: čas, ki ga imaš, naj dela zate.` : !down ? 'Trajanja sem umeril na mero za tvojo vrsto vadbe — dovolj dolgo, da deluje.' : f.level === 1 ? `Vadbe sem skrajšal na mero začetnika, do ${fmtMin(beginnerTop(sessions, lightK))} — bolje ${trainingDays(sessions)}× na teden krajše kot redko predolgo.` : 'Trajanja sem umeril: moč do 75 min, intervali do 50, lahek kardio po potrebi — več ne prinese več.') }
  }
  // 3d. največ težkega kardia (intervali, tempo): začetnik 0 (prve 4 tedne), nekaj izkušenj 1, izkušen 2; po 50. letu 1
  {
    const maxHard = f.level === 1 ? 0 : f.level === 2 || (o.age != null && o.age >= 50) ? 1 : 2
    let seen = 0, n = 0
    sessions = sessions.map(x => {
      if (isStrength(x) || (x.cardio !== 'intervali' && x.cardio !== 'tempo')) return x
      seen++
      if (seen <= maxHard) return x
      n++; return { ...x, cardio: 'lahko' as const }
    })
    if (n) { changed.push('manj intervalov'); later.push(f.level === 1 ? 'Kot začetnik začneš z lahkim kardiem — intervali pridejo po 4 tednih, ko tehnika in sklepi zdržijo.' : o.age != null && o.age >= 50 ? 'Po 50. letu en težek kardio na teden — obnova traja dlje, zato drugi kardio lahek.' : `Največ ${maxHard} ${maxHard === 1 ? 'težek kardio' : 'težka kardia'} na teden (intervali ali tempo) — več ne pospeši napredka, poveča pa utrujenost in poškodbe.`) }
    // (v3.50) zdravstvena omejitev (tlak, srce …): namesto hitrih intervalov zmeren tempo (dogovor in načrt isto)
    const health = healthOf(f.limits)
    if (health.length && sessions.some(x => x.cardio === 'intervali')) {
      sessions = sessions.map(x => (x.cardio === 'intervali' ? { ...x, cardio: 'tempo' as const } : x))
      changed.push('zdravje'); later.push(`Zaradi zdravja (${health.join(', ')}): namesto hitrih intervalov zmeren tempo — intenzivnost raste počasi.`)
    }
  }
  // 3e. kondicija / vzdržljivost / hujšanje z ≥ 3 kardio sejami: ena je dolga (vikend) — to gradi motor
  {
    const tails = tailsOf(sessions)
    const cardioIdx = sessions.map((_, i) => i).filter(i => !isStrength(sessions[i]!) && !tails.has(i))
    const engine = f.aims.includes('kondicija') || f.aims.includes('vzdrzljivost') || f.aims.includes('hujsanje') || f.aims.includes('tekma')
    // dve kardio seji zadostujeta, ko je kardio glavno ali je cilj vzdržljivost oz. tekma (dolga vožnja/tek je jedro tedna)
    const enough = cardioIdx.length >= 3 || (cardioIdx.length >= 2 && (o.main === 'kardio' || f.aims.includes('vzdrzljivost') || f.aims.includes('tekma')))
    // samo pri prvem predlogu — v pogajanju (»več kardia«) ne naredi iz lahkega teka dolgega
    const wantLong = !!o.mix && f.level >= 2 && enough && engine && !sessions.some(x => x.cardio === 'dolgo')
    if (wantLong) {
      const i = cardioIdx.find(k => sessions[k]!.cardio === 'lahko') ?? cardioIdx[cardioIdx.length - 1]!
      const x = sessions[i]!
      sessions[i] = { ...x, cardio: 'dolgo', min: Math.max(60, x.min, Math.min(x.type === 'kolo' ? 120 : 75, Math.round(x.min * 1.5 / 5) * 5)) }
      // (v3.50) »En tek … daljši in lahek« (prej »Ena tek … daljša«)
      changed.push('dolga'); later.push(`${x.type === 'kolo' ? 'Ena vožnja na teden je daljša in lahka' : x.type === 'tek' ? 'En tek na teden je daljši in lahek' : 'Ena kardio vadba na teden je daljša in lahka'} (ob vikendu, če gre) — dolga lahka vadba najbolj gradi kondicijo.`)
    }
  }
  // 3f. sedem dni: en dan je zelo lahek (sprehod ali lahek kardio do 30 min) — telo rabi vsaj en dan obnove
  if (trainingDays(sessions) >= 7) {
    const tails = tailsOf(sessions)
    // najprej lahek kardio (ne edini intervali, ne dolga), nato najkrajša seja
    const rank = (x: AgreedSession) => (isStrength(x) ? 3 : x.cardio === 'lahko' ? 0 : x.cardio === 'dolgo' ? 2 : 1)
    const cand = sessions.map((_, i) => i).filter(i => !tails.has(i)).sort((a, b) => rank(sessions[a]!) - rank(sessions[b]!) || sessions[a]!.min - sessions[b]!.min)[0]
    if (cand != null) {
      const x = sessions[cand]!
      sessions[cand] = isStrength(x) ? { type: f.sports.includes('hribi') ? 'hribi' : f.sports.includes('kolo') ? 'kolo' : 'tek', cardio: 'lahko', min: 30, ...(x.day != null ? { day: x.day } : {}) } : { ...x, cardio: 'lahko', min: Math.min(30, x.min) }
      changed.push('lahek dan'); later.push('Sedem dni, kot hočeš — en dan je zelo lahek (do 30 min sprehoda ali lahkega kardia): to je tvoj dan obnove, brez njega napredek zastane.')
    }
  }
  // 3g. (v3.50) tek na teden po tem, koliko zdaj preteče (»10–25 km« ≈ do 2 h 30 min, 6 min na km) — prej je odgovor
  //     vplival samo na raven: 6 dni z »10–25 km« je dalo 3 h 15 min teka od 1. tedna
  if (o.run && o.mix) {
    const runIdx = sessions.map((_, i) => i).filter(i => sessions[i]!.type === 'tek')
    const tot = runIdx.reduce((t, i) => t + sessions[i]!.min, 0)
    if (tot > o.run.cap) {
      const k = o.run.cap / tot
      runIdx.forEach(i => { const x = sessions[i]!; sessions[i] = { ...x, min: Math.max(20, r5(x.min * k)) } })
      changed.push('tek na teden')
      why.push(`Zdaj tečeš ${o.run.said} na teden — teka je ~${fmtMin(runIdx.reduce((t, i) => t + sessions[i]!.min, 0))} na teden, da kite in sklepi sledijo; več dodava, ko to zmoreš brez bolečin.`)
    }
  }
  // 3. razmik med težkimi dnevi (iz razporeda, ki ga bo naredila aplikacija)
  const open = [0, 1, 2, 3, 4, 5, 6].filter(d => !(f.offDays || []).includes(d))
  const order = scheduleWeek(sessions, open, f.preferDays, 7, { context: otherCtx(f) })
  const hardDays = order.map((k, d) => (k != null && isHard(sessions[k]!) ? d : -1)).filter(d => d >= 0)
  const trainDays = order.map((k, d) => (k != null ? d : -1)).filter(d => d >= 0)
  const adjacentHard: [number, number][] = []
  for (const d of hardDays) { const n = (d + 1) % 7; if (hardDays.includes(n)) adjacentHard.push([d, n]) }
  const nDays = trainingDays(sessions)
  if (nDays >= 2) {
    if (!adjacentHard.length && hardDays.length >= 2) why.push(`Težki dnevi (${hardDays.map(d => DAY_SHORT[d]).join(', ')}) imajo vmes vedno dan premora — takrat telo gradi, kar si na vadbi sprožil.`)
    else if (adjacentHard.length) {
      const pairs = adjacentHard.map(([a, b]) => `${DAY_SHORT[a]}–${DAY_SHORT[b]}`)
      const allDiff = adjacentHard.every(([a, b]) => !(isStrength(sessions[order[a]!]!) && isStrength(sessions[order[b]!]!)) || ['potisk', 'poteg', 'zgornji', 'roke', 'trebuh'].includes(sessions[order[a]!]!.part ?? 'celo') !== ['potisk', 'poteg', 'zgornji', 'roke', 'trebuh'].includes(sessions[order[b]!]!.part ?? 'celo'))
      why.push(`Pri ${nDays} vadbah na ${open.length} dni ${pairs.length === 1 ? `sta ${pairs[0]} zapored` : `so zapored ${pairs.join(', ')}`} — ${allDiff ? 'vedno različna vrsta ali različne mišice' : 'drugače ne gre v te dni'}${pairs.length === 1 ? ', ostali težki dnevi imajo premor' : ''}.`)
    }
    // ista vrsta čim bolj narazen (Blaž, 13. 10.: »fitnes čim bolj razporejen čez teden, da se mišice regenerirajo«)
    const sDays = order.map((k, d) => (k != null && isStrength(sessions[k]!) ? d : -1)).filter(d => d >= 0)
    if (sDays.length >= 2 && sDays.length <= 4) why.push(`Moč (${sDays.map(d => DAY_SHORT[d]).join(', ')}) je čim bolj narazen — vsaka mišica ima ${sDays.length <= 2 ? '3–4 dni' : '2–3 dni'} za obnovo, preden spet pride na vrsto.`)
    // (v3.50) dnevi drugega športa (nogomet …) niso počitek
    const other = otherSportDays(f.wish).filter(x => !trainDays.includes(x.day))
    const restDays = [0, 1, 2, 3, 4, 5, 6].filter(d => !trainDays.includes(d) && !other.some(x => x.day === d))
    const restN = restDays.length
    if (other.length) why.push(`${other[0]!.name} (${other.map(x => DAY_SHORT[x.day]).join(', ')}) šteje kot trening — moč in hitri kardio sem dal stran od teh dni, kolikor gre.`)
    if (restN > 0) why.push(`${restN} ${restN === 1 ? 'dan' : restN === 2 ? 'dneva' : 'dni'} počitka na teden (${atDays(restDays)}) — spanec in hrana sta del treninga.`)
  }

  // 3b. tip: raje lažje → kardio brez intervalov/tempa (lahko) in vadbe do 15 % krajše; raje trdo → nič krajšega, pove, da bo naložil
  // (samo pri prvem predlogu — sicer bi se vadbe krajšale v vsakem krogu pogajanja)
  if (o.push === 'lahko' && o.mix) {
    let touched = false
    sessions = sessions.map(x => {
      const y = { ...x }
      if (!isStrength(y) && (y.cardio === 'intervali' || y.cardio === 'tempo')) { y.cardio = 'lahko'; touched = true }
      if (y.min > 30 && !y.after) { y.min = Math.max(30, Math.round(y.min * 0.85 / 5) * 5); touched = true }
      return y
    })
    if (touched) { changed.push('lazje'); why.push('Raje si manj naložen: vadbe so malo krajše in kardio lahek — napredek pride z rednostjo, ne s trpljenjem.') }
  } else if (o.push === 'trdo') why.push('Rad si naložen: serije in intervali bodo zahtevnejši, a dan premora med težkimi dnevi ostane — tam nastane napredek.')

  why.push(...later)
  // (v3.50) tek in hoja velja za vse lahke teke (načrt jih tako sestavi) — tudi za tek, ki ga je trener dodal
  if (sessions.some(x => x.walk) && sessions.some(x => x.type === 'tek' && x.cardio === 'lahko' && !x.walk)) { sessions = sessions.map(x => (x.type === 'tek' && x.cardio === 'lahko' ? { ...x, walk: true } : x)); touched = true }
  // 4. napredovanje — (v3.50) po tem, kar teden ima: teža samo z utežmi, tek in hoja v deležu teka (prej »teža in minute
  // gor« tudi tekaču brez uteži)
  const up = [kgStrength({ sessions, equipment: f.equipment }) ? 'teža' : sessions.some(isStrength) ? 'ponovitve' : null, sessions.some(x => !isStrength(x) && !x.walk) ? 'minute' : null].filter(Boolean)
  const grow = [up.length ? `${up.join(' in ')} gor` : null, sessions.some(x => x.walk) ? 'daljši deli teka' : null].filter(Boolean)
  why.push(`Napredovanje po blokih 4 tednov: 1. teden točno tak (tehnika), 2. in 3. malo več${grow.length ? ` (${grow.join(', ')})` : ''}, 4. lažji teden — tako greš naprej brez pretreniranosti.`)

  const next = changed.length || touched ? normalizeFocus({ ...f, sessions, sports: [...new Set([...f.sports, ...sessions.map(x => x.type)])], why: why.slice(0, 6) }, { age: o.age, by: f.by, now: f.at }) : null
  // pojasnila sledijo tednu (v3.48): intervale je začetniku zamenjal lahek kardio → ne »… kratkih intervalov«
  const focus: Focus = next ? { ...next, title: f.title || next.title, notes: fitNotes(f.notes, next.sessions), strategy: f.strategy ?? null } : { ...f, why: why.slice(0, 6) }
  return { focus, why: why.slice(0, 6), changed }
}

/* ---------- kaj je rekel → mere trenerja ---------- */
const Q_DAYS = /koliko.*dni|dni na teden|od teh \d+ dni|kolikokrat|dni bi|treningov na teden|vadb na teden/i
const Q_TIME = /koliko (?:časa|casa|minut)|dolg[aeo] (?:vadb|trening)|minut na|časa za (?:eno )?vadbo|časa imaš za|na vadbo|na trening/i
const Q_WEEK = /ur\p{L}* na teden|na teden.*\bur|tedensk\p{L}* (?:ur|čas)|koliko ur/iu
/**
 * Iz želje, odgovorov in pripombe → mere za trenerja (coachReview). Pripomba ima prednost pred odgovori, odgovori pred
 * željo. Razmerje moč : kardio samo pri prvem predlogu (v pogajanju odloča, kar reče).
 */
export function coachOptsFrom(i: {
  wish: string; qa: readonly { q: string; a: string; id?: string }[]; feedback?: string | null; age?: number | null
  push?: CoachOpts['push']; main?: CoachOpts['main']; everyDay?: boolean
  strengthOk: boolean; cardioOk: boolean; cardioSports?: readonly FocusSport[]
}): CoachOpts {
  const fb = i.feedback || ''
  // vprašanje o dnevih po besedilu, sicer odgovor, ki je samo število ali razpon dni (»3-4«), pri vprašanju o tednu/treningih
  const qDays = i.qa.find(x => x.id === 'dni' || Q_DAYS.test(x.q))?.a
    ?? i.qa.find(x => /^\s*[1-7]\s*(?:[-–]\s*[1-7])?\s*(?:x|krat|dni|dneva)?\s*$/i.test(x.a) && !/ur\p{L}*|minut|časa|casa|zgib|km|kilometr|let|kg/iu.test(x.q))?.a ?? ''
  const qWeek = i.qa.find(x => Q_WEEK.test(x.q))?.a ?? ''
  const qTime = i.qa.find(x => x.id === 'cas' || (Q_TIME.test(x.q) && !Q_WEEK.test(x.q)))?.a ?? ''
  const qRange = (() => { const r = rangeIn(qDays, 1, 7); return r && r.lo < r.hi ? r : null })()
  // dnevi: pripomba (»4 dni«, »3-4x«) > odgovor (»4«, »3-4«) > želja (»3-4 krat na teden«, »5 dni«)
  let wantDays: number | null = null, daysRange: { lo: number; hi: number } | null = null
  const fbRange = daysRangeIn(fb), fbOne = fbRange ? null : explicitDays(fb)
  if (fbOne) wantDays = fbOne
  else if (fbRange) daysRange = fbRange
  else if (/^\s*[1-7]\s*$/.test(qDays)) wantDays = +qDays
  else if (qRange) daysRange = qRange
  else if (explicitDays(qDays)) wantDays = explicitDays(qDays)
  else if (daysRangeIn(i.wish)) daysRange = daysRangeIn(i.wish)
  else wantDays = explicitDays(i.wish) ?? (i.everyDay ? 7 : null)
  // »3x fitnes in 2x kolo« brez števila dni: dni je toliko, kolikor vadb našteje (ko našteje vsaj dva športa)
  const counts = explicitCounts([i.wish, ...i.qa.map(x => x.a)].join('. '))
  const sameDay = /po fitnes|po mo[čc]i|po vadbi|isti dan|istem dnevu|zraven/.test([i.wish, ...i.qa.map(x => x.a)].join(' ').toLowerCase())
  if (wantDays == null && !daysRange && !fb && !sameDay && Object.keys(counts).length >= 2) wantDays = Math.min(7, Object.values(counts).reduce((t, n) => t + (n || 0), 0))
  // (v3.49) pripomba o času brez številke (»več ur«, »krajše vadbe«, kolesarju »več kardia«) zamenja čas iz odgovorov —
  // sicer bi ga trener takoj vrnil na staro mero (prej je »več kardia« kolesarju skrajšal teden)
  const fbl = fb.toLowerCase()
  const fbTime = /(?:več|vec|manj) (?:ur|časa|casa)|dalj(?:š|s)|krajš|krajs/u.test(fbl) || (!i.strengthOk && /(?:več|vec|manj) kardi/u.test(fbl))
  const wk = fbTime ? null : rangeIn(qWeek, 1, 30)
  // (v3.49) odgovor »6–8 h na teden« ima prednost pred minutami iz proste želje
  const minRange = minutesIn(fb) ?? (fbTime ? null : minutesRange(qTime) ?? (wk ? null : minutesIn(i.wish)))
  const weekMin = minRange ? null : wk ? { lo: wk.lo * 60, hi: wk.hi * 60 } : weekMinutesIn(fb) ?? (fbTime ? null : weekMinutesIn(i.wish))
  const levelHint = levelFrom(i.wish, i.qa)
  // pogajanje: dnevi in podaljševanje samo, če je o tem govoril zdaj (sicer velja, kar je AI naredil po njegovi pripombi)
  const asIs = !!fb && !fbOne && !fbRange
  const raise = !fb || !!minutesIn(fb)
  const kmA = i.qa.find(x => x.id === 'km' || /km na teden|kilometr/i.test(x.q))?.a
  return {
    age: i.age, push: i.push, main: i.main, wantDays: asIs ? null : wantDays, daysRange: asIs ? null : daysRange, minRange, weekMin, levelHint, asIs, raise,
    mix: fb ? null : { strengthOk: i.strengthOk, cardioOk: i.cardioOk, counts, cardioSports: i.cardioSports },
    run: fb || !kmA ? null : runCapOf(kmA),
  }
}

const KIND_WORD: Record<FocusSport, string> = { fitnes: 'fitnes', doma: 'vadba doma', tek: 'tek', kolo: 'kolo', hribi: 'hoja/hribi' }
/**
 * Kaj se je spremenilo glede na prejšnji teden (Blaž, 13. 10.: »sploh mu nisem rekel, da ne bo tako, kot je zdaj«) —
 * da vidi vsako spremembo: »fitnes 3× → 2×, kolo 1× → 2×; skupaj 4 h → 4 h 30 min«. null, če je teden enak.
 */
export function weekDiff(a: Pick<Focus, 'sessions'>, b: Pick<Focus, 'sessions'>): string | null {
  const count = (f: Pick<Focus, 'sessions'>) => { const m = new Map<FocusSport, number>(); f.sessions.forEach(x => m.set(x.type, (m.get(x.type) || 0) + 1)); return m }
  const ca = count(a), cb = count(b)
  const kinds = [...new Set([...ca.keys(), ...cb.keys()])]
  const parts = kinds.filter(k => (ca.get(k) || 0) !== (cb.get(k) || 0)).map(k => `${KIND_WORD[k]} ${ca.get(k) || 0}× → ${cb.get(k) || 0}×`)
  const ta = a.sessions.reduce((t, x) => t + x.min, 0), tb = b.sessions.reduce((t, x) => t + x.min, 0)
  if (Math.abs(ta - tb) >= 15) parts.push(`skupaj ${fmtMin(ta)} → ${fmtMin(tb)} na teden`)
  return parts.length ? parts.join(', ') : null
}

/**
 * Vse, kar trener in AI rabita iz 1. koraka, odgovorov in pripombe (isto v aplikaciji in v testih s personami):
 * kaj je izbral (moč, kardio, »še ne vem«), mere (coachOptsFrom) in odmerek za poziv AI.
 */
export function planInputs(i: {
  picks: Picks; wish: string; qa: readonly { q: string; a: string; id?: string }[]; feedback?: string | null; age?: number | null
  push?: CoachOpts['push']; main: 'kardio' | 'oboje' | 'moc'; everyDay?: boolean; avail?: readonly number[] | null
}): { opts: CoachOpts; dose: DoseHint } {
  const sigAll = wishSignals([i.wish, ...i.qa.filter(x => !/boli|poškod|poskod/i.test(x.q)).map(x => x.a)].join('. '))
  const sPicked = picksStrength(i.picks) || sigAll.sports.some(x => x === 'fitnes' || x === 'doma') || sigAll.aims.some(a => a === 'misice' || a === 'moc')
  const cPicked = picksCardio(i.picks) || sigAll.sports.some(x => x === 'tek' || x === 'kolo' || x === 'hribi')
  const unsure = !!i.picks.delam?.includes('Še ne vem') || (!sPicked && !cPicked)
  const engine = sigAll.aims.some(a => a === 'kondicija' || a === 'hujsanje' || a === 'vzdrzljivost' || a === 'tekma')
  const cardioSports = (['kolo', 'tek', 'hribi'] as const).filter(x => sigAll.sports.includes(x))
  const strengthOk = sPicked || unsure, cardioOk = cPicked || unsure || engine
  const opts = coachOptsFrom({ wish: i.wish, qa: i.qa, feedback: i.feedback, age: i.age, push: i.push, main: i.main, everyDay: i.everyDay, strengthOk, cardioOk, cardioSports })
  const lvl = opts.levelHint ?? null
  const pd = planDays(lvl ?? 2, opts, i.avail?.length || 7, opts.wantDays === 7)
  const mix = !i.feedback && pd.want ? mixFor(pd.want, { main: i.main, aims: sigAll.aims, strengthOk, cardioOk, level: lvl ?? 2, counts: opts.mix?.counts }) : null
  return { opts, dose: { level: lvl, days: i.feedback ? null : pd.want, range: i.feedback ? null : pd.range, min: opts.minRange ?? null, mix, cardio: cardioSports.map(x => (x === 'hribi' ? 'hoja/hribi' : x)) } }
}
