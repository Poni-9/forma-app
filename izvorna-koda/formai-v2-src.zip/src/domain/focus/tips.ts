/**
 * NASVETI ZA ČAKANJE (Blaž, 14. 10.: »tukaj bi morala biti kakšna boljša animacija, da človek lažje počaka«). Ko trener
 * (Claude) razmišlja minuto ali več, kartica med čakanjem kroži kratke nasvete — izbrane po športih, ki jih uporabnik
 * dela. Samo splošno sprejeta vadbena znanja, brez zdravstvenih trditev in brez kaloričnih številk (te računa
 * aplikacija z varovalkami).
 */
export type TipTag = 'splosno' | 'tek' | 'kolo' | 'moc' | 'hribi' | 'prehrana'

const TIPS: readonly { tag: TipTag; t: string }[] = [
  { tag: 'splosno', t: 'Napredek nastane med počitkom: trening da dražljaj, telo se okrepi v dneh za njim.' },
  { tag: 'splosno', t: 'Spanec 7–9 ur na noč je za odrasle del treninga, ne dodatek.' },
  { tag: 'splosno', t: 'Lažji teden vsakih nekaj tednov ni izguba — telo takrat utrdi, kar si zgradil.' },
  { tag: 'splosno', t: 'Rednost premaga popolnost: trije treningi vsak teden so več vredni kot pet en teden in nič naslednjega.' },
  { tag: 'splosno', t: 'Prvih 5–10 minut vadbe naj bo lažjih — mišice in sklepi se ogrejejo.' },
  { tag: 'splosno', t: 'Lahki dnevi naj bodo res lahki, da imaš za težke dneve dovolj moči.' },
  { tag: 'tek', t: 'Pogovorni tempo: če lahko govoriš v celih stavkih, tečeš dovolj lahko za osnovno vzdržljivost.' },
  { tag: 'tek', t: 'Za začetek je menjavanje hoje in teka povsem v redu — iz tedna v teden je teka več.' },
  { tag: 'tek', t: 'Obseg teka povečuj postopno: kite in sklepi se prilagajajo počasneje kot srce in pljuča.' },
  { tag: 'tek', t: 'Krajši, hitrejši koraki pogosto manj obremenijo kolena kot dolgi.' },
  { tag: 'kolo', t: 'Večina ur na kolesu naj bo v lahki coni — tam se gradi temelj vzdržljivosti.' },
  { tag: 'kolo', t: 'Na daljših vožnjah jej in pij že od začetka, ne šele, ko si lačen.' },
  { tag: 'kolo', t: 'Višja kadenca (okoli 80–95 obratov na minuto) pogosto manj utrudi noge kot težke prestave.' },
  { tag: 'kolo', t: 'Intervali so začimba: za večino sta dovolj en do dva težka treninga na teden.' },
  { tag: 'moc', t: 'Tehnika pred kilogrami: zadnji ponovitvi naj bosta težki, a še čisti.' },
  { tag: 'moc', t: 'Ko vse serije narediš z lepo tehniko, naslednjič dodaj malo teže ali ponovitev.' },
  { tag: 'moc', t: 'Večsklepne vaje (počep, potisk, poteg) delajo največ mišic naenkrat — zato so na začetku vadbe.' },
  { tag: 'moc', t: 'Med serijami težkih vaj si vzemi 1,5–3 minute odmora, pri lažjih je dovolj minuta.' },
  { tag: 'moc', t: 'Trebušne mišice okrepijo vaje, vidne pa jih naredi predvsem nižji delež maščobe.' },
  { tag: 'hribi', t: 'Hoja v hrib je odličen lahek kardio: srce dela, sklepi so manj obremenjeni kot pri teku.' },
  { tag: 'hribi', t: 'Na turo vzemi pijačo, prigrizek in vetrovko — vreme v hribih se hitro spremeni.' },
  { tag: 'prehrana', t: 'Beljakovine razporedi čez dan — v vsak obrok nekaj.' },
  { tag: 'prehrana', t: 'Po daljšem treningu v nekaj urah pojej obrok z ogljikovimi hidrati in beljakovinami.' },
  { tag: 'prehrana', t: 'Pij čez dan; pri vadbi, daljši od ure, tudi med njo.' },
]

/** Kateri športi so v besedilu (izbire, besede, odgovori) — za izbor nasvetov in figure med čakanjem. */
export function sportsIn(text: string): TipTag[] {
  const s = text.toLowerCase()
  const out: TipTag[] = []
  const word = '(?![a-zčšž])'
  if (new RegExp(`\\bkol(o|a|u|om|esa|esu|esom|esar\\w*)${word}|gravel|trenaž|\\bmtb\\b`).test(s)) out.push('kolo')
  if (new RegExp(`\\b(tek|teka|teku|tekom|tekač\\w*|tekaš|teči|tečem|tečeš|teče)${word}|maraton|trail`).test(s)) out.push('tek')
  if (/fitnes|fitness|moč|mišic|uteži|vadba doma|six ?pack|postav|trebuh|zgornji del|sklec|počep/.test(s)) out.push('moc')
  if (new RegExp(`hrib|\\bhoj[aeo]${word}|hodim|pohod|\\btur[aeo]${word}`).test(s)) out.push('hribi')
  return out
}

/** Nasveti za te športe (njihovi najprej, nato splošni in prehrana), premešani glede na seme — vsako čakanje drugače. */
export function tipsFor(tags: readonly TipTag[], seed = Date.now()): string[] {
  const mine = TIPS.filter(x => tags.includes(x.tag))
  const rest = TIPS.filter(x => x.tag === 'splosno' || x.tag === 'prehrana')
  const mix = (a: typeof TIPS) => [...a].map((x, i) => ({ x, k: Math.sin(seed / 997 + i * 12.9898) })).sort((p, q) => p.k - q.k).map(p => p.x.t)
  const a = mix(mine), b = mix(rest)
  // izmenično: dva njegova, en splošen
  const out: string[] = []
  while (a.length || b.length) { if (a.length) out.push(a.shift()!); if (a.length) out.push(a.shift()!); if (b.length) out.push(b.shift()!) }
  return [...new Set(out)]
}

/** figura, ki med čakanjem izvaja njegov šport (id vaje ali kardio) */
export interface FigSpec { id?: string | null; fallback?: 'pavza' | 'tek' | 'kolo' | 'hoja'; label: string }

/** figure za njegove športe (kolo, tek, hoja, moč v fitnesu ali doma) — kar dela, to figura izvaja med čakanjem */
export function figsFor(tags: readonly TipTag[], text = ''): FigSpec[] {
  const out: FigSpec[] = []
  if (tags.includes('kolo')) out.push({ fallback: 'kolo', label: 'Kolo' })
  if (tags.includes('tek')) out.push({ fallback: 'tek', label: 'Tek' })
  if (tags.includes('moc')) {
    const s = text.toLowerCase()
    const gym = /fitnes|fitness|uteži/.test(s), home = /doma/.test(s)
    if (gym || !home) out.push({ id: 'goblet', label: 'Počep z utežjo' })
    if (home) out.push({ id: 'sklece', label: 'Sklece' })
  }
  if (tags.includes('hribi')) out.push({ fallback: 'hoja', label: 'Hoja' })
  return out.length ? out : [{ fallback: 'tek', label: 'Tek' }, { id: 'sklece', label: 'Sklece' }]
}
