/**
 * IZBIRE (Blaž, 7. 10.: »kot pri Claudu — ti pošlje izbiro: hočeš vitko postavo, kaj rad delaš, kdaj nimaš časa«).
 * V 1. koraku uporabnik tapne, kar velja, in/ali pove po svoje. Izbire gredo v želje kot kratki stavki
 * (»Postava: vitka in močna. Rad delam: fitnes, tek.«), ki jih razumeta AI in vprašalnik brez AI; ob novem
 * dogovoru se iz shranjenih želja spet prižgejo.
 */
export interface ChoiceGroup { id: string; lead: string; label: string; opts: readonly string[] }
export const CHOICE_GROUPS: readonly ChoiceGroup[] = [
  { id: 'postava', lead: 'Postava', label: 'Kakšno postavo želiš?', opts: ['Vitka in močna', 'Mišičasta', 'Manj maščobe', 'Six pack'] },
  { id: 'delam', lead: 'Rad delam', label: 'Kaj rad delaš?', opts: ['Fitnes', 'Tek', 'Kolo', 'Hribi', 'Doma, brez opreme'] },
  { id: 'se', lead: 'Še', label: 'Še kaj?', opts: ['Ful kondicije', 'Ne izgubiti mišic', 'Samo zgornji del', 'Hitrejši na kolesu', 'Zdravje in počutje'] },
]
export type Picks = Record<string, string[]>

/** Izbire in svoje besede → ena želja (izbire po vrstnem redu skupin in možnosti). */
export function composeWish(picks: Picks, text: string): string {
  const lines = CHOICE_GROUPS.map(g => {
    const p = g.opts.filter(o => picks[g.id]?.includes(o))
    return p.length ? `${g.lead}: ${p.map(o => o.toLowerCase()).join(', ')}.` : ''
  }).filter(Boolean)
  return [...lines, text.trim()].filter(Boolean).join(' ')
}

const LEAD_RX = new RegExp(`^(${CHOICE_GROUPS.map(g => g.lead).join('|')}): ([^.]*)\\.\\s*`)
/** Shranjena želja → izbire in ostanek besedila (obratno od composeWish). */
export function splitWish(wish: string): { picks: Picks; text: string } {
  const picks: Picks = {}
  let rest = (wish || '').trim()
  for (let m = LEAD_RX.exec(rest); m; m = LEAD_RX.exec(rest)) {
    const g = CHOICE_GROUPS.find(x => x.lead === m![1])!
    const seg = m[2]!.toLowerCase()
    const found = g.opts.filter(o => seg.includes(o.toLowerCase()))
    if (found.length) picks[g.id] = [...new Set([...(picks[g.id] || []), ...found])]
    rest = rest.slice(m[0].length)
  }
  return { picks, text: rest }
}

/** Dnevi (0 = pon … 6 = ned) */
export const DAY_OPTS = ['Pon', 'Tor', 'Sre', 'Čet', 'Pet', 'Sob', 'Ned']
export const DAY_NAME = ['ponedeljek', 'torek', 'sreda', 'četrtek', 'petek', 'sobota', 'nedelja']
export const DAY_AT = ['ob ponedeljkih', 'ob torkih', 'ob sredah', 'ob četrtkih', 'ob petkih', 'ob sobotah', 'ob nedeljah']
export const DAY_SHORT = ['pon', 'tor', 'sre', 'čet', 'pet', 'sob', 'ned']
/** »tor, čet« */
export const daysLine = (days: readonly number[]): string => [...days].sort((a, b) => a - b).map(d => DAY_SHORT[d]).filter(Boolean).join(', ')
/** »ob torkih in četrtkih« */
export const atDays = (days: readonly number[]): string => {
  const w = [...days].sort((a, b) => a - b).map(d => DAY_AT[d]!.replace(/^ob /, '')).filter(Boolean)
  return w.length ? `ob ${w.length > 1 ? `${w.slice(0, -1).join(', ')} in ${w[w.length - 1]}` : w[0]}` : ''
}
