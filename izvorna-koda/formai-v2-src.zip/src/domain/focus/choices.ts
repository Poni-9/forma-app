/**
 * IZBIRE (Blaž, 7. 10.: »kot pri Claudu — ti pošlje izbiro: hočeš vitko postavo, kaj rad delaš, kdaj nimaš časa«).
 * V 1. koraku uporabnik tapne, kar velja, in/ali pove po svoje. Izbire gredo v želje kot kratki stavki
 * (»Postava: vitka in močna. Rad delam: fitnes, tek.«), ki jih razumeta AI in vprašalnik brez AI; ob novem
 * dogovoru se iz shranjenih želja spet prižgejo.
 */
export type Picks = Record<string, string[]>
export interface ChoiceGroup {
  id: string; lead: string; label: string; opts: readonly string[]
  /** skupina se pokaže šele, ko je izbrano kaj, na kar se navezuje (kolesar ne vidi postave, fitnes ne vidi trenažerja) */
  show?: (p: Picks) => boolean
  /** ena sama izbira */
  single?: boolean
}
const on = (p: Picks, g: string, ...o: string[]) => o.some(x => p[g]?.includes(x))
/** izbral je moč (fitnes, doma) ali cilj mišice/moč */
export const picksStrength = (p: Picks) => on(p, 'delam', 'Fitnes', 'Vadba doma') || on(p, 'cilj', 'Več mišic in moči')
/** izbral je kardio (tek, kolo, hribi) */
export const picksCardio = (p: Picks) => on(p, 'delam', 'Tek', 'Kolo', 'Hribi in hoja')
/**
 * Splošno za vsakogar (Blaž, 13. 10.: »za vse, ne samo za fitnes — najprej ne ve, kaj bo kdo delal«): najprej cilj,
 * kaj rad dela in izkušnje; nato samo skupine, ki se nanašajo na njegove izbire (moč in postava, kolo, tek).
 */
export const CHOICE_GROUPS: readonly ChoiceGroup[] = [
  { id: 'cilj', lead: 'Cilj', label: 'Kaj bi rad dosegel?', opts: ['Boljša kondicija', 'Manj kilogramov', 'Več mišic in moči', 'Hitrejši in vzdržljivejši', 'Pripravljen na tekmo', 'Zdravje in počutje'] },
  // (v3.50) »Drug šport« (nogomet, košarka …): kateri in kdaj napiše v polje pod izbirami (»Drug šport: nogomet tor, čet; tekma sob.«)
  { id: 'delam', lead: 'Rad delam', label: 'Kaj rad delaš?', opts: ['Fitnes', 'Vadba doma', 'Tek', 'Kolo', 'Hribi in hoja', 'Drug šport', 'Še ne vem'] },
  { id: 'raven', lead: 'Izkušnje', label: 'Koliko že treniraš?', opts: ['Začenjam', 'Občasno', 'Redno, več let'], single: true },
  { id: 'postava', lead: 'Postava', label: 'Moč in postava', opts: ['Vitka in močna', 'Mišičasta', 'Six pack', 'Ne izgubiti mišic', 'Samo zgornji del'], show: picksStrength },
  { id: 'kolo', lead: 'Kolo', label: 'Kolo', opts: ['Zunaj po cesti', 'Gorsko ali gravel', 'Trenažer doma', 'Merilnik moči'], show: p => on(p, 'delam', 'Kolo') },
  { id: 'tek', lead: 'Tek', label: 'Tek', opts: ['Začenjam s tekom', 'Tečem do 10 km', 'Polmaraton ali več', 'Po hribih (trail)'], show: p => on(p, 'delam', 'Tek'), single: true },
]
export const visibleGroups = (p: Picks) => CHOICE_GROUPS.filter(g => !g.show || g.show(p))

/** (v3.50) vrstica drugega športa v želji */
export const OTHER_LEAD = 'Drug šport'
/** Izbire in svoje besede → ena želja (samo vidne skupine, po vrstnem redu skupin in možnosti). */
export function composeWish(picks: Picks, text: string, other = ''): string {
  const lines = visibleGroups(picks).map(g => {
    const p = g.opts.filter(o => picks[g.id]?.includes(o))
    return p.length ? `${g.lead}: ${p.map(o => o.toLowerCase()).join(', ')}.` : ''
  }).filter(Boolean)
  // (v3.50) drug šport z dnevi (samo, ko je izbran): bere ga načrt (otherSportDays) — ti dnevi niso prosti za vadbo
  const o = picks.delam?.includes(OTHER_LEAD) ? other.replace(/[.\s]+$/u, '').replace(/\.\s*/g, '; ').trim() : ''
  return [...lines, o ? `${OTHER_LEAD}: ${o}.` : '', text.trim()].filter(Boolean).join(' ')
}

/** stare izbire (pred 13. 10.) → nove; česar ni, ostane v besedilu */
const LEGACY: Record<string, [string, string][]> = {
  'še': [['ful kondicije', 'cilj:Boljša kondicija'], ['ne izgubiti mišic', 'postava:Ne izgubiti mišic'], ['samo zgornji del', 'postava:Samo zgornji del'], ['hitrejši na kolesu', 'cilj:Hitrejši in vzdržljivejši|delam:Kolo'], ['zdravje in počutje', 'cilj:Zdravje in počutje']],
  postava: [['manj maščobe', 'cilj:Manj kilogramov']],
  'rad delam': [['hribi', 'delam:Hribi in hoja'], ['doma, brez opreme', 'delam:Vadba doma']],
}
const LEADS = [...CHOICE_GROUPS.map(g => g.lead), 'Še', 'Drug šport']
const LEAD_RX = new RegExp(`^(${LEADS.join('|')}): ([^.]*)\\.\\s*`)
/** Shranjena želja → izbire in ostanek besedila (obratno od composeWish; razume tudi stare izbire). */
export function splitWish(wish: string): { picks: Picks; text: string; other?: string } {
  const picks: Picks = {}
  const add = (g: string, o: string) => { picks[g] = [...new Set([...(picks[g] || []), o])] }
  const left: string[] = []
  let rest = (wish || '').trim()
  let other = ''
  for (let m = LEAD_RX.exec(rest); m; m = LEAD_RX.exec(rest)) {
    const lead = m[1]!, g = CHOICE_GROUPS.find(x => x.lead === lead)
    if (lead === OTHER_LEAD) { other = m[2]!.trim(); rest = rest.slice(m[0].length); continue }
    let seg = m[2]!.toLowerCase()
    // stare »doma, brez opreme« ima vejico — najprej celotne stare izbire
    for (const [old, to] of LEGACY[lead.toLowerCase()] || []) {
      if (!seg.includes(old)) continue
      seg = seg.replace(old, '')
      for (const t of to.split('|')) { const [gid, o] = t.split(':') as [string, string]; add(gid, o) }
    }
    // izbire z vejico (»Redno, več let«) najprej cele
    for (const o of g?.opts.filter(x => x.includes(',')) || []) if (seg.includes(o.toLowerCase())) { seg = seg.replace(o.toLowerCase(), ''); add(g!.id, o) }
    for (const item of seg.split(',').map(x => x.trim()).filter(Boolean)) {
      const o = g?.opts.find(x => x.toLowerCase() === item)
      if (g && o) add(g.id, o)
      else left.push(item)
    }
    rest = rest.slice(m[0].length)
  }
  const extra = left.length ? `${left.map((x, i) => (i ? x : x.charAt(0).toUpperCase() + x.slice(1))).join(', ')}.` : ''
  return { picks, text: [extra, rest].filter(Boolean).join(' '), ...(other ? { other } : {}) }
}

/* (v3.50) DRUG ŠPORT z dnevi (»Igram nogomet: treningi ob torkih in četrtkih, tekma v soboto«) — ti dnevi niso počitek
   in niso prosti za vadbo; načrt jih pokaže z imenom športa (prej »Počitek — ta dan nimaš časa«). */
const OTHER_SPORT: [RegExp, string][] = [
  [/nogomet|futsal/u, 'Nogomet'], [/ko(?:š|s)ark/u, 'Košarka'], [/odbojk/u, 'Odbojka'], [/rokomet/u, 'Rokomet'], [/hokej/u, 'Hokej'],
  [/plavanj|plavam/u, 'Plavanje'], [/tenis/u, 'Tenis'], [/badminton/u, 'Badminton'], [/squash/u, 'Squash'], [/(?<![\p{L}])ples|balet/u, 'Ples'],
  [/judo|karate|borilni|boks/u, 'Borilni šport'], [/gimnastik/u, 'Gimnastika'], [/atletik/u, 'Atletika'], [/vaterpolo/u, 'Vaterpolo'], [/floorball/u, 'Floorball'],
]
const DAY_STEM: [RegExp, number[]][] = [
  [/(?<![\p{L}])pon(?:[a-zč]{0,3}del\p{L}*)?(?![\p{L}])/u, [0]], [/(?<![\p{L}])tor(?:ek|k(?:a|u|om|ih|i|e)?)?(?![\p{L}])/u, [1]],
  [/(?<![\p{L}])sre(?:da|do|de|dah|dami)?(?![\p{L}])/u, [2]], [/(?<![\p{L}])(?:č|c)et(?:rtek|rtk(?:a|u|om|ih|i|e)?)?(?![\p{L}])/u, [3]],
  [/(?<![\p{L}])pet(?:ek|k(?:a|u|om|ih|i|e))(?![\p{L}])/u, [4]], [/(?<![\p{L}])sob(?:ota|oto|ote|otah|otami)?(?![\p{L}])/u, [5]],
  [/(?<![\p{L}])ned(?:elja|eljo|elje|eljah|eljami)?(?![\p{L}])/u, [6]], [/vikend\p{L}*|kon(?:ec|cu) tedna/u, [5, 6]],
]
const stemDays = (t: string): number[] => DAY_STEM.flatMap(([rx, ds]) => (rx.test(t) ? ds : []))
/** ime drugega športa v besedilu (»Nogomet«) ali null */
export const otherSportIn = (text: string): string | null => { const t = text.toLowerCase(); return OTHER_SPORT.find(([rx]) => rx.test(t))?.[1] ?? null }
export interface OtherSport { day: number; name: string; match: boolean }
/** Drug šport po dnevih iz besed (en stavek: šport in dnevi; del stavka s »tekmo« je tekma). */
export function otherSportDays(text: string | null | undefined): OtherSport[] {
  const out: OtherSport[] = []
  for (const s of String(text || '').toLowerCase().split(/[.!?;\n]+/)) {
    const name = otherSportIn(s)
    if (!name || /ne igram|ne treniram|nehal|prenehal|več ne/u.test(s)) continue
    for (const part of s.split(',')) for (const d of stemDays(part)) if (!out.some(x => x.day === d)) out.push({ day: d, name, match: /tekm/u.test(part) })
  }
  return out.sort((a, b) => a.day - b.day)
}

/** Dnevi (0 = pon … 6 = ned) */
export const DAY_OPTS = ['Pon', 'Tor', 'Sre', 'Čet', 'Pet', 'Sob', 'Ned']
export const DAY_NAME = ['ponedeljek', 'torek', 'sreda', 'četrtek', 'petek', 'sobota', 'nedelja']
export const DAY_AT = ['ob ponedeljkih', 'ob torkih', 'ob sredah', 'ob četrtkih', 'ob petkih', 'ob sobotah', 'ob nedeljah']
export const DAY_SHORT = ['pon', 'tor', 'sre', 'čet', 'pet', 'sob', 'ned']
/** »tor, čet« */
export const daysLine = (days: readonly number[]): string => [...days].sort((a, b) => a - b).map(d => DAY_SHORT[d]).filter(Boolean).join(', ')
/** »ob torkih in četrtkih« */
export const atDays = (days: readonly number[]): string => {
  const w = [...days].sort((a, b) => a - b).map(d => DAY_AT[d]!.replace(/^ob /, '')).filter(Boolean)
  return w.length ? `ob ${w.length > 1 ? `${w.slice(0, -1).join(', ')} in ${w[w.length - 1]}` : w[0]}` : ''
}
