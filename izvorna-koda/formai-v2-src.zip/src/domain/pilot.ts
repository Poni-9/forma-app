/**
 * TESTNI PROGRAM BREZ NADLEGOVANJA — ključna vprašanja z enim klikom (A–D), enkrat na teden,
 * ob naključnem trenutku med uporabo. Vrstni red po pomembnosti za izboljšavo aplikacije: najprej, ali je načrt
 * prav težak in jasen, potem kaj pomaga, kaj izboljšati, ali bi pogrešal (PMF), zaupanje, prehrana, trener, cena.
 * Odgovori gredo anonimno (naključna oznaka namesto imena in e-pošte) razvijalcu; vidi jih na formai.si/#/pilot.
 */
export type PilotQ = 'plan_fit' | 'clarity' | 'plan_block' | 'value' | 'pmf' | 'pain' | 'data' | 'trust' | 'nutrition' | 'coach' | 'feel' | 'ease' | 'recommend' | 'pay'

export interface PilotQuestion {
  q: PilotQ
  text: string
  /** štirje odgovori: a, b, c, d */
  options: [string, string, string, string]
  /** najprej po toliko tednih uporabe; nato največ vsakih `every` tednov */
  minWeek: number
  every: number
  /** samo, če uporablja ta del aplikacije */
  needs?: 'meals' | 'coach'
  /** za pregled: kaj iz odgovorov izboljšamo */
  why: string
}

export const LETTERS = ['a', 'b', 'c', 'd'] as const

/** Banka vprašanj po pomembnosti (prvo, ki je na vrsti, dobi prednost). */
export const QUESTIONS: PilotQuestion[] = [
  { q: 'plan_fit', text: 'Kako ti je ustrezal načrt v zadnjem tednu?', options: ['Ravno prav', 'Prelahek', 'Pretežek', 'Nisem mu sledil'], minWeek: 1, every: 3, why: 'obremenitev načrta: ure in intenzivnost' },
  { q: 'clarity', text: 'Ali veš, kaj točno narediti na treningu?', options: ['Popolnoma', 'Večinoma', 'Deloma', 'Ne'], minWeek: 1, every: 8, why: 'jasnost navodil in vodenja' },
  { q: 'plan_block', text: 'Kaj te je najbolj oviralo pri treningu?', options: ['Premalo časa', 'Utrujenost', 'Vreme', 'Nič'], minWeek: 2, every: 6, why: 'kaj prilagoditi: čas, počitek, trenažer' },
  { q: 'value', text: 'Kaj ti v FORMAI najbolj pomaga?', options: ['Načrt treninga', 'Vodenje med treningom', 'Prehrana', 'AI trener'], minWeek: 2, every: 8, why: 'kaj razvijati naprej' },
  { q: 'pmf', text: 'Kako bi se počutil, če FORMAI ne bi mogel več uporabljati?', options: ['Zelo razočaran', 'Malo razočaran', 'Vseeno bi mi bilo', 'Ga skoraj ne uporabljam'], minWeek: 3, every: 6, why: 'ali je aplikacija nepogrešljiva (cilj ≥ 40 % »zelo razočaran«)' },
  { q: 'pain', text: 'Kaj naj najprej izboljšam?', options: ['Načrt treninga', 'Prehrano', 'Preglednost aplikacije', 'Povezavo z uro'], minWeek: 3, every: 8, why: 'prednostni seznam razvoja' },
  { q: 'data', text: 'Kako pridejo tvoje vožnje v FORMAI?', options: ['Same z ure', 'Vpišem jih ročno', 'Ne pridejo', 'Ne vem kako'], minWeek: 2, every: 8, why: 'povezava z uro (intervals.icu)' },
  { q: 'pay', text: 'Koliko bi za FORMAI plačal na mesec?', options: ['Nič', 'Do 5 €', '5–10 €', 'Več kot 10 €'], minWeek: 6, every: 8, why: 'cena po testnem obdobju' },
  { q: 'trust', text: 'Ali zaupaš vatom in kalorijam v aplikaciji?', options: ['Da', 'Večinoma', 'Ne preveč', 'Ne vem, kaj pomenijo'], minWeek: 4, every: 8, why: 'razlage številk' },
  { q: 'nutrition', text: 'Kako ti gre prehrana po načrtu?', options: ['Sledim ji', 'Deloma', 'Težko', 'Je ne uporabljam'], minWeek: 3, every: 6, needs: 'meals', why: 'prehrana in razpored obrokov' },
  { q: 'coach', text: 'Kako koristni so odgovori trenerja?', options: ['Zelo', 'Deloma', 'Premalo konkretni', 'Ga ne uporabljam'], minWeek: 3, every: 6, needs: 'coach', why: 'AI trener' },
  { q: 'feel', text: 'Kako se počutiš po zadnjem tednu treninga?', options: ['Močnejši', 'Enako', 'Preutrujen', 'Ne vem'], minWeek: 4, every: 6, why: 'ali načrt deluje (napredek brez pretreniranosti)' },
  { q: 'ease', text: 'Kako enostavna je aplikacija za uporabo?', options: ['Zelo', 'V redu', 'Zapletena', 'Zelo zapletena'], minWeek: 2, every: 8, why: 'preglednost in poenostavitve' },
  { q: 'recommend', text: 'Bi FORMAI priporočil prijatelju kolesarju?', options: ['Zagotovo', 'Verjetno', 'Verjetno ne', 'Ne'], minWeek: 5, every: 8, why: 'priporočila (rast brez oglasov)' },
]
export const questionOf = (q: string): PilotQuestion | undefined => QUESTIONS.find(x => x.q === q)

export interface PilotState {
  /** anonimna oznaka (naključna), da se odgovori istega uporabnika povežejo — brez imena in e-pošte */
  id?: string | null
  /** koda povabila (klub, znanec, QR) iz povezave formai.si/?pilot=KODA */
  code?: string | null
  /** kdaj je bilo zadnje vprašanje prikazano (odgovor ali preskok) — največ eno na teden */
  lastAsk?: string | null
  /** kdaj je bilo katero vprašanje nazadnje prikazano */
  asked?: Partial<Record<PilotQ, string>> | null
  optOut?: boolean
}

const days = (a: string, b: string) => Math.round((Date.parse(b + 'T12:00:00Z') - Date.parse(a + 'T12:00:00Z')) / 86_400_000)

/**
 * Ali je ta teden na vrsti vprašanje in katero. Prvo po 7 dneh uporabe, nato največ eno na 7 dni
 * (tudi preskočeno šteje). Vprašanje, ki ga ta del aplikacije ne zadeva, se preskoči.
 */
export function pilotDue(s: PilotState | null | undefined, start: string | null | undefined, today: string, use: { meals?: boolean; coach?: boolean } = {}): PilotQuestion | null {
  const st = s || {}
  if (st.optOut || !start) return null
  const used = days(start, today)
  if (used < 7) return null
  if (st.lastAsk && days(st.lastAsk, today) < 7) return null
  const week = Math.floor(used / 7)
  // med vprašanji, ki so na vrsti, izberi najbolj »zapadlega« glede na njegov ritem, utežno po pomembnosti:
  // ključna (načrt) se vračajo pogosteje, a vsako pride na vrsto; še nevprašano šteje kot 2 × zapadlo
  const N = QUESTIONS.length
  let best: PilotQuestion | null = null, score = 0
  QUESTIONS.forEach((q, i) => {
    if (week < q.minWeek) return
    if (q.needs === 'meals' && !use.meals) return
    if (q.needs === 'coach' && !use.coach) return
    const last = st.asked?.[q.q]
    if (last && days(last, today) < q.every * 7) return
    const x = (last ? days(last, today) / (q.every * 7) : 2) * (1 + (0.5 * (N - i)) / N)
    if (x > score) { best = q; score = x }
  })
  return best
}

/** Po prikazu (odgovor ali preskok): zapomni si vprašanje in teden. */
export function afterAsk(s: PilotState | null | undefined, q: PilotQ, today: string): PilotState {
  const st = s || {}
  return { ...st, lastAsk: today, asked: { ...(st.asked || {}), [q]: today } }
}

/** Koda povabila iz povezave (?pilot=KODA): velike črke, številke, pomišljaj; največ 24 znakov. */
export function cleanCode(v: string | null | undefined): string | null {
  const c = String(v || '').trim().toUpperCase().replace(/\s+/g, '-').replace(/[^A-Z0-9-]/g, '').slice(0, 24)
  return c || null
}

/** PMF (Sean Ellis): delež »zelo razočaran« med tistimi, ki aplikacijo uporabljajo (brez »ga skoraj ne uporabljam«). */
export function pmfOf(answers: readonly string[]): { pct: number; n: number } | null {
  const used = answers.filter(a => a !== 'd')
  if (!used.length) return null
  return { pct: Math.round((used.filter(a => a === 'a').length / used.length) * 100), n: used.length }
}
