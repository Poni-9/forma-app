/**
 * (v3.49) »Zadnjih 7 dni«: povprečje pojedenega proti povprečju ciljev ISTIH dni (s treningom tistega dne) — prej proti
 * »cilju brez treninga«, zato je kolesar, ki je na cilju, videl ~400 kcal preveč na dan.
 * Štejejo samo dnevi z vpisom in z znanim ciljem.
 */
export interface WeekBalance { n: number; avgEaten: number; avgTarget: number | null; diff: number | null }
export function weekBalance(days: readonly { eaten: number; target: number | null }[]): WeekBalance {
  const d = days.filter(x => x.eaten > 0)
  const t = d.filter(x => x.target != null && x.target > 0)
  const avg = (a: number[]) => Math.round(a.reduce((s, x) => s + x, 0) / a.length)
  const avgEaten = d.length ? avg(d.map(x => x.eaten)) : 0
  const avgTarget = t.length ? avg(t.map(x => x.target!)) : null
  return { n: d.length, avgEaten, avgTarget, diff: t.length ? avg(t.map(x => x.eaten)) - avgTarget! : null }
}
