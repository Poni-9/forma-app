import { lowFiberRule, type RaceSoon } from './race'
import { raceBreakfastGkg } from '../training/planner'
import type { MealEntry, PlanDay, Profile } from '../types'
import type { DailyTarget } from './energy'
import { fuelGph, isHardRide, isRaceSim, SHORT_RACE_FUEL } from './fuelrate'

/**
 * VODENJE PREHRANE — kaj in koliko jesti danes, razporejeno okoli treninga, in koliko na kolesu.
 * Deterministično (brez AI): dnevni cilj iz energy.ts se razdeli na obroke; vsak obrok ima kcal, beljakovine,
 * ogljikove hidrate in primer s količinami iz navadne slovenske trgovine.
 * Na kolesu: ogljikovi hidrati na uro po vrsti vožnje (ISSN: 30–60 g/h, na dolgih in dirki do 90 g/h),
 * tekočina po temperaturi (~350 ml/h v hladnem do ~850 ml/h v vročini, ACSM: 0,4–0,8 l/h, prilagodi po sebi)
 * in po tem, koliko si dejansko spil na zadnjih vožnjah; začetek po ~30 min, nato vsakih ~20 min.
 */

/* ---------- gorivo na kolesu ---------- */
/** opomnik med vožnjo: v minuti atMin — kaj pojesti ali popiti */
export interface FuelCue { atMin: number; text: string; solid: boolean; short: string }
export interface RideFuel {
  /** ogljikovi hidrati na uro */
  gph: number
  /** skupaj za vožnjo */
  totalCarbs: number
  /** koliko OH je v stvareh, ki jih vzameš s seboj (≈ totalCarbs, zaokroženo navzgor na cele kose) */
  carriedCarbs: number
  fluidMl: number
  bottles: number
  /** kaj vzeti s seboj */
  items: string[]
  /** kdaj jesti in piti */
  schedule: string
  /** časovnica opomnikov med vožnjo */
  cues: FuelCue[]
  /** vsakih koliko minut opomnik (0 = brez) */
  everyMin: number
  /** prvič po minutah */
  firstAt: number
  /** gramov OH na 20 minut (ritem) */
  perReminder: number
  /** kaj vzeti — po kosih (za vpis, koliko si res porabil) */
  plan: FuelPlanItem[]
  /** tekočina na uro in zakaj (temperatura, tvoje zadnje vožnje) */
  fluidNote: string
  /** (v3.50) OH, ki jih komplet ne pokrije (vsi kosi na stropu ali brez trde hrane) — v `items` je zapisan manjko */
  missingCarbs?: number
}
export interface FuelPlanItem { key: FuelKey | 'voda'; name: string; n: number; carbs: number; kcal: number; ml: number }
/** Okoliščine vožnje: temperatura v oknu treninga in koliko piješ ti (iz vpisov po vožnjah). */
export interface FuelCtx {
  tempC?: number | null; fluidFactor?: number | null
  /** tekma danes ali v 2 dneh → obroki z malo vlakninami */
  race?: RaceSoon | null
  /** danes vadba moči, tek ali hribi (ne vožnja): obroki okoli vadbe, nasvet brez »vožnje« */
  workout?: boolean
  /** (v3.50) glavna seja dneva je za nami: brez oznak »pred vožnjo«, nasvet za obrok po njej */
  rideDone?: boolean
  /** (v3.50) ura dejanskega začetka seje (z ure, 0–24): razpored obrokov po njej, ne po »kdaj običajno treniraš« */
  startH?: number | null
  /** (v3.50) lahki deli vodene vadbe (min od–do): opomniki za hrano padejo v odmor, ne v interval (Vadba) */
  restWindows?: readonly { from: number; to: number }[] | null
}

type RideLike = Pick<PlanDay, 'kind' | 'durationMin' | 'zone'> & { role?: PlanDay['role']; title?: string; raceId?: string | null }

/* ---------- kaj imaš za na kolo: konkretne stvari iz slovenske trgovine, z OH na kos ---------- */
export type FuelKey = 'iso_domaci' | 'iso_kupljen' | 'frutabela' | 'ploscica' | 'gel' | 'banana' | 'dateljni' | 'sendvic' | 'rizevi'
/** name: v stavku (»2 × bidon domačega izotonika«) · label: kratko ime za izbiro (»domači izotonik«) · acc: v tožilniku za opomnik (»Pojej banano«, v3.48) */
export interface FuelItem { key: FuelKey; name: string; label: string; acc: string; carbs: number; kcal: number; kind: 'drink' | 'solid' | 'gel'; desc: string }
export const FUEL_ITEMS: FuelItem[] = [
  // (v3.50) sol z mero: ¼ žličke (~1,5 g) namesto »ščep« — v vročini (850–1000 ml na uro) je ščep premalo natrija
  { key: 'iso_domaci', name: 'bidon domačega izotonika', label: 'domači izotonik', acc: 'bidon domačega izotonika', carbs: 40, kcal: 160, kind: 'drink', desc: '750 ml vode + 40 g sladkorja ali maltodekstrina + ¼ žličke soli (~1,5 g) ≈ 40 g OH' },
  { key: 'iso_kupljen', name: 'bidon kupljenega izotonika', label: 'kupljen izotonik', acc: 'bidon kupljenega izotonika', carbs: 45, kcal: 180, kind: 'drink', desc: 'Isostar, Powerade ipd. — 750 ml ≈ 45 g OH' },
  { key: 'frutabela', name: 'Frutabela', label: 'Frutabela', acc: 'Frutabelo', carbs: 19, kcal: 100, kind: 'solid', desc: 'sadna ploščica 30 g ≈ 19 g OH' },
  { key: 'ploscica', name: 'energijska ploščica', label: 'energijska ploščica', acc: 'energijsko ploščico', carbs: 40, kcal: 200, kind: 'solid', desc: 'PowerBar, Enervit ipd. ≈ 40 g OH' },
  { key: 'banana', name: 'banana', label: 'banana', acc: 'banano', carbs: 25, kcal: 105, kind: 'solid', desc: '≈ 25 g OH' },
  { key: 'dateljni', name: 'pest datljev', label: 'datlji', acc: 'pest datljev', carbs: 30, kcal: 125, kind: 'solid', desc: '4–5 datljev ≈ 30 g OH' },
  { key: 'sendvic', name: 'sendvič z marmelado', label: 'sendvič', acc: 'sendvič z marmelado', carbs: 45, kcal: 250, kind: 'solid', desc: '2 rezini kruha + marmelada ali med ≈ 45 g OH' },
  { key: 'rizevi', name: 'riževi kolački', label: 'riževi kolački', acc: 'riževe kolačke', carbs: 30, kcal: 150, kind: 'solid', desc: 'domači, kos ≈ 30 g OH' },
  { key: 'gel', name: 'gel', label: 'gel', acc: 'gel', carbs: 25, kcal: 100, kind: 'gel', desc: '≈ 25 g OH' },
]
export const DEFAULT_KIT: FuelKey[] = ['iso_domaci', 'frutabela', 'banana', 'gel']
const ITEM = Object.fromEntries(FUEL_ITEMS.map(i => [i.key, i])) as Record<FuelKey, FuelItem>
/** vrstni red trde hrane po vrsti vožnje (kar imaš, v tem vrstnem redu) */
const ORDER: Record<'hard' | 'race' | 'long' | 'easy', FuelKey[]> = {
  hard: ['gel', 'frutabela', 'banana', 'dateljni', 'ploscica', 'rizevi', 'sendvic'],
  race: ['ploscica', 'sendvic', 'rizevi', 'frutabela', 'gel', 'banana', 'dateljni'],
  long: ['sendvic', 'rizevi', 'ploscica', 'frutabela', 'banana', 'dateljni', 'gel'],
  easy: ['banana', 'frutabela', 'dateljni', 'rizevi', 'sendvic', 'ploscica', 'gel'],
}
/** (v3.50) litri na 0,05 l (»0,75 l«, »1,65 l«), ne na desetinko (»0,8 l« ob »1 × bidon« 750 ml)
 *  (v3.51) en zapis za vse: časovnica in »Načrt je bil« (prej 0,25 l — ista vožnja 1,65 / 1,75 / 1,5 l) */
export const l1 = (ml: number) => String(Math.round(ml / 50) / 20).replace('.', ',')
const hm = (m: number) => `${Math.floor(m / 60)}:${String(m % 60).padStart(2, '0')}`
/** (v3.50) čas opomnika premakni v najbližji lahki del vadbe (odmor), če je znan in opomnik pade v interval */
export function snapToRest(t: number, windows: readonly { from: number; to: number }[] | null | undefined): number {
  if (!windows?.length || windows.some(w => t >= w.from && t <= w.to)) return t
  let best = t, dist = Infinity
  for (const w of windows) {
    // najbližja točka okna, minuto od roba (opomnik ne pade točno na menjavo koraka)
    const c = Math.max(w.from, Math.min(w.to, w.to - w.from >= 2 ? (t < w.from ? w.from + 1 : w.to - 1) : t))
    const d = Math.abs(c - t)
    if (d < dist) { dist = d; best = Math.round(c) }
  }
  return best
}
/** (v3.50) lahki deli vadbe (ogrevanje, odmor, iztek) iz korakov vodene vadbe — za ctx.restWindows; brez dela ni oken */
export function restWindowsOf(steps: readonly { kind: string; sec: number }[]): { from: number; to: number }[] {
  const out: { from: number; to: number }[] = []
  let t = 0
  for (const s of steps) {
    const m = Math.max(0, s.sec || 0) / 60
    if (m > 0 && s.kind !== 'delo' && s.kind !== 'test') out.push({ from: t, to: t + m })
    t += m
  }
  return steps.some(s => s.kind === 'delo' || s.kind === 'test') ? out : []
}

/** Tekočina na uro po temperaturi v oknu treninga (brez napovedi: ~20 °C). Trdi treningi +50 ml. */
export function fluidPerHour(tempC: number | null | undefined, hard: boolean): number {
  const t = tempC ?? 20
  const base = t < 12 ? 350 : t < 18 ? 450 : t < 23 ? 550 : t < 28 ? 700 : 850
  return base + (hard ? 50 : 0)
}
/**
 * Koliko piješ ti: razmerje popito / predlagano na zadnjih vožnjah (vpis »Na kolesu«, zadnjih 60 dni, do 6).
 * Ena vožnja šteje pol; meje 0,7–1,15 — tudi če piješ malo, v vročini ne gre pod 70 % priporočila.
 */
export function fluidFactorOf(meals: readonly MealEntry[], today?: string): { f: number; n: number } {
  const from = today ? new Date(new Date(today).getTime() - 60 * 86400_000).toISOString().slice(0, 10) : ''
  const rs = meals.filter(m => m.slot === 'med_vadbo' && (m.planMl || 0) >= 300 && m.fluidMl != null && m.date >= from)
    .sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6).map(m => m.fluidMl! / m.planMl!).sort((a, b) => a - b)
  if (!rs.length) return { f: 1, n: 0 }
  const med = rs.length % 2 ? rs[(rs.length - 1) / 2]! : (rs[rs.length / 2 - 1]! + rs[rs.length / 2]!) / 2
  const f = rs.length === 1 ? (1 + med) / 2 : med
  return { f: +Math.max(0.7, Math.min(1.15, f)).toFixed(2), n: rs.length }
}

/**
 * Gorivo za vožnjo. Vse se sešteje: bidoni z domačim izotonikom (40 g OH na 750 ml) + trda hrana in geli = skupaj.
 * Časovnica: od 30. minute vsakih 20 min opomnik (ne v zadnjih 15 min); trda hrana razporejena enakomerno,
 * vmes požirki izotonika; opomnik za dolivanje, ko bidona zmanjka.
 */
export function rideFuel(d: RideLike | null, kitIn?: readonly string[] | null, ctx: FuelCtx = {}): RideFuel | null {
  if (!d || (d.kind !== 'kolo' && d.kind !== 'test')) return null
  // (v3.50) null = privzeti komplet; prazen seznam = samo voda (prej je prazen pomenil privzeti — »samo voda« ni bilo mogoče izbrati)
  const kit = new Set<FuelKey>(((kitIn == null ? DEFAULT_KIT : kitIn) as FuelKey[]).filter(k => k in ITEM))
  const drink = kit.has('iso_domaci') ? ITEM.iso_domaci : kit.has('iso_kupljen') ? ITEM.iso_kupljen : null
  const ISO = drink ? drink.carbs : 0
  const min = d.durationMin || 0
  const hours = min / 60
  const race = d.role === 'dirka'
  const sim = isRaceSim(d.title)   // generalka za dirko: vadiš dirkalno gorivo
  const hard = isHardRide(d)
  // (v3.50) OH na uro iz ene tabele (fuelrate.ts) — isto berejo opisi sej in »Med« na Danes;
  // prazen komplet = samo voda (OH 0, z opombo, če bi vožnja OH rabila)
  const waterOnly = kitIn != null && !kit.size
  const wanted = fuelGph(d)
  const gph = waterOnly ? 0 : wanted
  const totalCarbs = gph ? Math.round((gph * Math.max(0, hours - 0.5)) / 5) * 5 : 0
  // tekočina: po temperaturi in po tem, koliko dejansko spiješ (ni vroče → manj; ne siliti v 1,5 l, ki ga ne spiješ)
  const perH = fluidPerHour(ctx.tempC, hard || race), ff = ctx.fluidFactor ?? 1
  const fluidMl = Math.max(400, Math.round((hours * perH * ff) / 50) * 50)
  const fluidNote = `~${Math.round((perH * ff) / 50) * 50} ml na uro pri ${ctx.tempC != null ? `${Math.round(ctx.tempC)} °C` : '~20 °C'}${Math.abs(ff - 1) >= 0.05 ? ', prilagojeno temu, koliko spiješ ti' : ''}`
  const bottles = Math.max(1, Math.ceil(fluidMl / 750))
  const carried = Math.min(2, bottles)
  const refills = bottles - carried
  // (v3.50) v načrtu za vpis je toliko bidonov, kolikor jih predvidoma spiješ (tudi dolite) — »vse po načrtu« = predlagano
  const halfBottles = (ml: number) => Math.max(0, Math.round((ml / 750) * 2) / 2)
  if (!totalCarbs) {
    const items = [`${carried} × bidon vode (skupaj ~${fluidMl} ml${refills ? ', dolij na postanku' : ''})${min >= 60 ? ' — ob vročini z elektroliti' : ''}`]
    if (waterOnly && wanted) items.push('Samo voda — brez OH na kolesu (na vožnjah nad 90 min to ni priporočeno; v Nastavitvah dodaj izotonik, banano ali gel).')
    return { gph, totalCarbs, carriedCarbs: 0, fluidMl, bottles, items, schedule: race && min < 60 ? SHORT_RACE_FUEL : min < 60 ? 'Samo voda.' : 'Voda po žeji, na kolesu ne jej — seja je lahka ali kratka.', cues: [], everyMin: 0, firstAt: 0, perReminder: 0, plan: [{ key: 'voda', name: 'bidon vode', n: Math.max(0.5, halfBottles(fluidMl)), carbs: 0, kcal: 0, ml: 750 }], fluidNote }
  }

  // 1) bidoni: celi bidoni izotonika (če ga imaš), a le toliko, kolikor jih res spiješ, in ne več OH, kot jih rabiš (+10 g);
  //    ostali bidoni voda, manjkajoči OH gredo v trdo hrano in gele
  const drinkable = Math.max(1, Math.floor(fluidMl / 750 + 0.25))
  const iso = drink ? Math.min(drinkable, bottles, Math.max(1, Math.floor((totalCarbs + 10) / ISO))) : 0
  const isoCarried = Math.min(iso, carried), isoRefill = iso - isoCarried
  const water = carried - isoCarried
  // 2) ostanek s trdo hrano iz tvojega kompleta: dolge = prava hrana najprej, lahke = banane/Frutabela, intervali in dirka = geli
  let rest = totalCarbs - iso * ISO
  const long = min >= 150
  const order = ORDER[hard ? 'hard' : race || sim ? 'race' : long ? 'long' : 'easy'].filter(k => kit.has(k))
  // (v3.50) brez trde hrane v kompletu ni več gela, ki ga nimaš — manjko se izpiše (prej »1 × gel« pri kompletu samo z izotonikom)
  const solidsList = order
  const count = new Map<FuelKey, number>()
  const capOf = (k: FuelKey) => (ITEM[k].kind === 'gel' ? 6 : k === 'sendvic' || k === 'rizevi' || k === 'ploscica' ? 2 : 3)
  let guard = 0
  while (rest > 10 && guard++ < 30) {
    // najprej večji kosi, dokler je prostora; potem manjši; (v3.50) ko so vsi kosi na stropu, konec — ne 6 banan
    const pick = solidsList.find(k => (count.get(k) || 0) < capOf(k) && rest >= ITEM[k].carbs * 0.6) || solidsList.find(k => (count.get(k) || 0) < capOf(k))
    if (!pick) break
    count.set(pick, (count.get(pick) || 0) + 1); rest -= ITEM[pick].carbs
  }
  const missingCarbs = rest > 10 ? Math.round(rest / 5) * 5 : 0
  const solidCarbs = [...count.entries()].reduce((s, [k, n]) => s + n * ITEM[k].carbs, 0)
  const carriedCarbs = iso * ISO + solidCarbs

  const items: string[] = []
  if (isoCarried) items.push(`${isoCarried} × ${drink!.name} (${drink!.desc})`)
  if (water) items.push(`${water} × bidon vode`)
  // (v3.50) pri dolivanju tudi bidon vode, ne samo vrečka izotonika (5 h: 4 bidoni, 2 neseš, 2 doliješ — 1 izotonik + 1 voda)
  const waterRefill = refills - isoRefill
  if (refills) {
    const bits: string[] = []
    if (isoRefill) bits.push(drink!.key === 'iso_domaci' ? `${isoRefill} × vrečka s 40 g sladkorja/maltodekstrina in ¼ žličke soli` : `${isoRefill} × 750 ml izotonika (kupi ali vzemi s seboj)`)
    if (waterRefill > 0) bits.push(`${waterRefill} × voda`)
    items.push(`za dolivanje na postanku${refills > 1 ? ` (${refills} ×)` : ''}: ${bits.join(', ')}`)
  }
  for (const k of solidsList) {
    const n = count.get(k) || 0
    if (!n) continue
    const it = ITEM[k]
    const when = it.kind === 'gel' ? (hard ? ' — v odmoru med intervali' : race || sim ? ' — pred klanci' : '') : long && it.carbs >= 30 ? ' — v prvi polovici' : ''
    items.push(`${n} × ${it.name} (${it.desc}${n > 1 ? ', vsak' : ''})${when}`)
  }
  if (missingCarbs) items.push(`Do ~${totalCarbs} g OH manjka ~${missingCarbs} g — v Nastavitvah dodaj ${solidsList.length ? 'izotonik ali gel' : 'gel ali banano'}.`)

  // 3) časovnica: trda hrana enakomerno od 30. min do 20 min pred koncem (prej mreža po 20 min: 0:30, 0:50, 1:30);
  //    pitje vsakih 20 min vmes, kjer ni hrane; ploščice prve, geli zadnji
  //    (v3.50) če Vadba pove, kje so lahki deli (odmori), opomnik za hrano pade tja, ne v interval
  const solids: [string, number, string][] = solidsList.flatMap(k => Array.from({ length: count.get(k) || 0 }, () => [ITEM[k].name, ITEM[k].carbs, ITEM[k].acc] as [string, number, string]))
  const lastT = Math.max(30, min - 20)
  const at = new Map<number, [string, number, string][]>()
  solids.forEach((x, k) => {
    const t0 = solids.length === 1 ? Math.min(30, lastT) : Math.round((30 + (k * (lastT - 30)) / (solids.length - 1)) / 5) * 5
    const t = snapToRest(t0, ctx.restWindows)
    at.set(t, [...(at.get(t) || []), x])
  })
  const times = new Set<number>(at.keys())
  for (let t = 30; t <= min - 15; t += 20) if (![...at.keys()].some(s0 => Math.abs(s0 - t) < 10)) times.add(t)
  if (!times.size) times.add(Math.max(15, Math.round(min / 2)))
  const rate = fluidMl / Math.max(1, min)               // ml na minuto
  const empties: number[] = []
  for (let r = 0; r < Math.ceil(refills / 2); r++) empties.push(((carried + r * 2) * 750) / rate)
  const told = new Set<number>()   // opomnik za dolivanje enkrat na prazna bidona
  // (v3.48) pitje po dejanski potrebi: tretjina urne količine na 20 min (v vročini več); »⅓ bidona« samo pri ~250 ml
  const sip = Math.max(100, Math.round((perH * ff) / 3 / 50) * 50)
  const sipG = Math.round((ISO * sip) / 750)
  const cues: FuelCue[] = [...times].sort((a, b) => a - b).map(t => {
    const eat = at.get(t)
    const e0 = empties.find(e => t > e - 35 && t <= e - 15 && !told.has(e))
    if (e0 != null) told.add(e0)
    const refill = e0 != null ? ' Bidona bosta kmalu prazna — na naslednjem postanku dolij.' : ''
    if (eat) {
      // kratko ime v imenovalniku (časovnica »0:30 banana«), opomnik v tožilniku (»Pojej banano«)
      const what = eat.map(([n]) => n).join(' + '), acc = eat.map(([, , a]) => a).join(' + '), g = eat.reduce((s, [, q]) => s + q, 0)
      return { atMin: t, solid: true, short: what, text: `Pojej ${acc} (~${g} g OH) in popij 3–4 požirke.${refill}` }
    }
    return drink
      ? { atMin: t, solid: false, short: 'izotonik', text: `Popij ${sip === 250 ? `~⅓ bidona izotonika (~250 ml, ~${sipG} g OH)` : `~${sip} ml izotonika (~${sipG} g OH)`}.${refill}` }
      : { atMin: t, solid: false, short: 'voda', text: `Popij ~${sip} ml vode.${refill}` }
  })
  const food = cues.filter(c => c.solid)
  const schedule = `Pij od začetka: 3–4 požirke vsakih 10–15 min (${drink ? `izotonik${water ? ', vodo po žeji' : ''}` : 'voda'}).${food.length ? ` Hrana: ${food.map(c => `${hm(c.atMin)} ${c.short}`).join(', ')}.` : ''} Skupaj ~${carriedCarbs} g OH in ~${l1(fluidMl)} l tekočine — ${fluidNote}.`
  const perReminder = Math.max(5, Math.round(gph / 3 / 5) * 5)
  const plan: FuelPlanItem[] = []
  if (iso) plan.push({ key: drink!.key, name: drink!.name, n: iso, carbs: drink!.carbs, kcal: drink!.kcal, ml: 750 })
  // voda: kolikor je predvidoma spiješ ob izotoniku (po pol bidona, tudi dolito), ne kolikor bidonov neseš
  // (v3.50) prej samo, če si nesel bidon vode — 1,65 l načrta je imelo v listu 1,5 l in »vse po načrtu« je učilo 0,91
  // (v3.51) voda šele, ko je ob izotoniku vsaj 200 ml za popiti (90 min: 850 ml je bilo 1 izotonik + pol bidona = 1,25 l)
  const waterN = iso ? ((water || waterRefill > 0) && fluidMl - iso * 750 >= 200 ? Math.max(0.5, halfBottles(fluidMl - iso * 750)) : 0) : Math.max(0.5, halfBottles(fluidMl))
  if (waterN) plan.push({ key: 'voda', name: 'bidon vode', n: waterN, carbs: 0, kcal: 0, ml: 750 })
  for (const k of solidsList) { const n = count.get(k) || 0; if (n) plan.push({ key: k, name: ITEM[k].name, n, carbs: ITEM[k].carbs, kcal: ITEM[k].kcal, ml: 0 }) }
  return { gph, totalCarbs, carriedCarbs, fluidMl, bottles, items, schedule, cues, everyMin: 20, firstAt: 30, perReminder, plan, fluidNote, ...(missingCarbs ? { missingCarbs } : {}) }
}

/**
 * (v3.49) GORIVO NA TEKU (prej ga Prehrana ni imela, Danes pa je predlagal banano in ploščico med tekom): do 75 min samo
 * voda; daljši tek gel (~25 g OH) od 45. minute vsakih 30 min (ne v zadnjih 15 min) in 400–600 ml vode na uro po
 * temperaturi — mehka steklenička, pas ali krog mimo pitnika. Ista oblika kot gorivo na kolesu (časovnica, vpis).
 */
export const RUN_FUEL_MIN = 75
export function runFuel(d: RideLike | null, ctx: FuelCtx = {}): RideFuel | null {
  if (!d || d.kind !== 'tek') return null
  const min = d.durationMin || 0
  const t = ctx.tempC ?? 18
  const perH = t < 20 ? 400 : t < 25 ? 500 : 600
  const fluidMl = Math.max(250, Math.round(((min / 60) * perH) / 50) * 50)
  const fluidNote = `~${perH} ml na uro pri ${ctx.tempC != null ? `${Math.round(ctx.tempC)} °C` : '~18 °C'}`
  const water = `~${l1(fluidMl)} l vode — mehka steklenička, pas ali krog mimo pitnika`
  const times: number[] = []
  if (min >= RUN_FUEL_MIN) for (let at = 45; at <= min - 15; at += 30) times.push(at)
  const gel = ITEM.gel
  const n = times.length
  const cues: FuelCue[] = times.map(at => ({ atMin: at, solid: true, short: 'gel', text: 'Pojej gel (~25 g OH) in popij nekaj požirkov vode.' }))
  const items = [...(n ? [`${n} × gel (≈ 25 g OH${n > 1 ? ', vsak' : ''})`] : []), water]
  const schedule = n
    ? `Gel v ${times.map(x => `${x}.`).join(', ').replace(/, ([^,]*)$/, ' in $1')} minuti z nekaj požirki vode, sicer pij po žeji — skupaj ~${l1(fluidMl)} l. Banana in ploščica med tekom ne gresta.`
    : `Samo voda po žeji (~${l1(fluidMl)} l) — pri teku do ${RUN_FUEL_MIN} min gorivo med tekom ni potrebno.`
  const plan: FuelPlanItem[] = [...(n ? [{ key: 'gel' as const, name: gel.name, n, carbs: gel.carbs, kcal: gel.kcal, ml: 0 }] : []), { key: 'voda', name: 'voda (0,5 l)', n: Math.max(0.5, Math.round((fluidMl / 500) * 2) / 2), carbs: 0, kcal: 0, ml: 500 }]
  return { gph: n ? Math.round((n * gel.carbs) / (min / 60)) : 0, totalCarbs: n * gel.carbs, carriedCarbs: n * gel.carbs, fluidMl, bottles: 0, items, schedule, cues, everyMin: n ? 30 : 0, firstAt: n ? 45 : 0, perReminder: n ? gel.carbs : 0, plan, fluidNote }
}

/**
 * Vpis »Na kolesu«: koliko si res popil in pojedel (kosi, bidoni po pol) → obrok, ki šteje v dnevne kalorije,
 * in podatek za prihodnjo tekočino (popito / predlagano).
 */
/** Kaj lahko vpišeš po vožnji: najprej načrtovano, nato ostalo iz kompleta (npr. Frutabela namesto gela) in voda. */
export function fuelChoices(rf: Pick<RideFuel, 'plan'>, kit?: readonly string[] | null): FuelPlanItem[] {
  const out = [...rf.plan]
  const have = new Set(out.map(x => x.key))
  const extra = FUEL_ITEMS.filter(i => !have.has(i.key) && (!kit || !kit.length || kit.includes(i.key)))
  for (const i of extra) out.push({ key: i.key, name: i.name, n: 0, carbs: i.carbs, kcal: i.kcal, ml: i.kind === 'drink' ? 750 : 0 })
  if (!have.has('voda')) out.push({ key: 'voda', name: 'bidon vode', n: 0, carbs: 0, kcal: 0, ml: 750 })
  return out
}

/** Okoliščine za gorivo na dan: temperatura v oknu treninga in koliko običajno spiješ. */
export function fuelCtxOf(weather: Record<string, { tmax: number }> | null | undefined, meals: readonly MealEntry[], date: string, today: string): FuelCtx {
  return { tempC: weather?.[date]?.tmax ?? null, fluidFactor: fluidFactorOf(meals, today).f }
}

export function fuelEntry(rf: Pick<RideFuel, 'plan' | 'fluidMl'>, got: Record<string, number>, title: string, where = 'Na kolesu'): { name: string; kcal: number; carbsG: number; fluidMl: number; planMl: number } {
  const bits: string[] = []
  let kcal = 0, carbs = 0, ml = 0
  for (const it of fuelChoices(rf)) {
    const n = Math.max(0, got[it.key] ?? 0)
    if (!n) continue
    kcal += n * it.kcal; carbs += n * it.carbs; ml += n * it.ml
    bits.push(`${String(n).replace('.', ',')} × ${it.name}`)
  }
  // (v3.50) predlagano = kar je v načrtu za vpis (bidoni po pol), ne surovi ml — »vse po načrtu« je faktor 1, ne 0,91
  const planMl = rf.plan.reduce((s, x) => s + x.n * x.ml, 0) || rf.fluidMl
  return { name: bits.length ? `${where} (${title}): ${bits.join(', ')}` : `${where} (${title}): nič`, kcal: Math.round(kcal), carbsG: Math.round(carbs), fluidMl: Math.round(ml), planMl }
}

/* ---------- obroki dneva ---------- */
export interface Food { name: string; per: number; unit: 'g' | 'kos' | 'ml'; kcal: number; p: number; c: number; f: number }
/** (v3.50) kalorije in makri so usklajeni: 4·B + 4·OH + 9·M je v ±5 % kcal (razen pijač z alkoholom) — test to drži */
export const F: Record<string, Food> = {
  oves: { name: 'ovseni kosmiči', per: 100, unit: 'g', kcal: 370, p: 13, c: 60, f: 7 },
  jogurt: { name: 'grški jogurt 2 %', per: 100, unit: 'g', kcal: 73, p: 10, c: 4, f: 2 },
  banana: { name: 'banana', per: 1, unit: 'kos', kcal: 105, p: 1.3, c: 24, f: 0.4 },
  med: { name: 'med', per: 100, unit: 'g', kcal: 304, p: 0, c: 76, f: 0 },
  kruh: { name: 'polnozrnat kruh', per: 100, unit: 'g', kcal: 250, p: 9, c: 45, f: 3 },
  riz: { name: 'riž (suh)', per: 100, unit: 'g', kcal: 350, p: 7, c: 77, f: 1 },
  testenine: { name: 'testenine (suhe)', per: 100, unit: 'g', kcal: 355, p: 12, c: 71, f: 1.5 },
  krompir: { name: 'krompir', per: 100, unit: 'g', kcal: 77, p: 2, c: 17, f: 0.1 },
  piscanec: { name: 'piščančje prsi', per: 100, unit: 'g', kcal: 110, p: 23, c: 0, f: 1.5 },
  tuna: { name: 'tuna v lastnem soku (odcejena)', per: 100, unit: 'g', kcal: 110, p: 25, c: 0, f: 1 },
  jajce: { name: 'jajce', per: 1, unit: 'kos', kcal: 75, p: 6.5, c: 0.5, f: 5 },
  skuta: { name: 'skuta', per: 100, unit: 'g', kcal: 90, p: 12, c: 3, f: 3 },
  mleko: { name: 'mleko 1,5 %', per: 100, unit: 'ml', kcal: 47, p: 3.4, c: 4.9, f: 1.5 },
  olje: { name: 'olivno olje', per: 100, unit: 'g', kcal: 900, p: 0, c: 0, f: 100 },
  oreski: { name: 'oreški', per: 100, unit: 'g', kcal: 620, p: 20, c: 15, f: 55 },
  zelenjava: { name: 'zelenjava', per: 100, unit: 'g', kcal: 30, p: 2, c: 5, f: 0.3 },
  sadje: { name: 'sadje (jabolko, hruška)', per: 100, unit: 'g', kcal: 52, p: 0.3, c: 12, f: 0.2 },
  omaka: { name: 'paradižnikova omaka', per: 100, unit: 'g', kcal: 30, p: 1.3, c: 5.5, f: 0.3 },
  fizol: { name: 'fižol ali čičerika (kuhana)', per: 100, unit: 'g', kcal: 120, p: 8, c: 20, f: 1 },
  // (v3.51) čičerika posebej v receptih in nakupu (v receptu je fizol »fižol (kuhan)«; ocena brez AI ostane »fižol ali čičerika«)
  cicerika: { name: 'čičerika (kuhana)', per: 100, unit: 'g', kcal: 120, p: 8, c: 20, f: 1 },
  // malo vlaknin (2 dni pred tekmo)
  belkruh: { name: 'bel kruh ali žemlja', per: 100, unit: 'g', kcal: 265, p: 9, c: 49, f: 3.2 },
  marmelada: { name: 'marmelada', per: 100, unit: 'g', kcal: 250, p: 0.4, c: 62, f: 0.1 },
  rizb: { name: 'bel riž (suh)', per: 100, unit: 'g', kcal: 350, p: 7, c: 78, f: 0.7 },
  testenineb: { name: 'bele testenine (suhe)', per: 100, unit: 'g', kcal: 355, p: 12, c: 72, f: 1.5 },
  krompirb: { name: 'krompir brez lupine', per: 100, unit: 'g', kcal: 77, p: 2, c: 17, f: 0.1 },
  // za recepte
  puran: { name: 'puranje prsi', per: 100, unit: 'g', kcal: 105, p: 23, c: 0, f: 1 },
  losos: { name: 'losos (file)', per: 100, unit: 'g', kcal: 200, p: 20, c: 0, f: 13 },
  tofu: { name: 'tofu', per: 100, unit: 'g', kcal: 120, p: 12, c: 2, f: 7 },
  leca: { name: 'leča (kuhana)', per: 100, unit: 'g', kcal: 115, p: 9, c: 20, f: 0.4 },
  kefir: { name: 'kefir', per: 100, unit: 'ml', kcal: 50, p: 3.3, c: 4, f: 2.3 },
  sir: { name: 'sir (edamec)', per: 100, unit: 'g', kcal: 350, p: 25, c: 0, f: 27 },
  cebula: { name: 'čebula in česen', per: 100, unit: 'g', kcal: 40, p: 1, c: 9, f: 0.1 },
  solata: { name: 'zelena solata in paradižnik', per: 100, unit: 'g', kcal: 20, p: 1, c: 3.5, f: 0.2 },
  jabolko: { name: 'jabolko', per: 1, unit: 'kos', kcal: 80, p: 0.4, c: 19, f: 0.3 },
  kuskus: { name: 'kuskus (suh)', per: 100, unit: 'g', kcal: 360, p: 12, c: 72, f: 1.5 },
  // (v3.49) slovenska kuhinja in več rastlinskih beljakovin (na 100 g ali ml surovega)
  ajda: { name: 'ajdova kaša (suha)', per: 100, unit: 'g', kcal: 345, p: 12, c: 70, f: 3 },
  polenta: { name: 'koruzni zdrob za polento (suh)', per: 100, unit: 'g', kcal: 360, p: 8, c: 77, f: 2 },
  jesprenj: { name: 'ješprenj (suh)', per: 100, unit: 'g', kcal: 350, p: 10, c: 78, f: 1 },
  govedina: { name: 'goveje meso za golaž (pusto)', per: 100, unit: 'g', kcal: 140, p: 21, c: 0, f: 6 },
  mleto: { name: 'mleto meso (pusto, goveje ali puranje)', per: 100, unit: 'g', kcal: 170, p: 20, c: 0, f: 10 },
  oslic: { name: 'oslič (file)', per: 100, unit: 'g', kcal: 80, p: 17, c: 0, f: 1 },
  sunka: { name: 'puranja šunka', per: 100, unit: 'g', kcal: 105, p: 19, c: 1.5, f: 2.5 },
  zelje: { name: 'kislo zelje', per: 100, unit: 'g', kcal: 20, p: 1, c: 4, f: 0.1 },
  sojmleko: { name: 'sojin napitek', per: 100, unit: 'ml', kcal: 40, p: 3.3, c: 2.5, f: 1.8 },
  sojjogurt: { name: 'sojin jogurt (navaden)', per: 100, unit: 'g', kcal: 55, p: 4, c: 3, f: 3 },
  arasid: { name: 'arašidovo maslo', per: 100, unit: 'g', kcal: 590, p: 25, c: 20, f: 46 },
  sok: { name: '100 % sadni sok', per: 100, unit: 'ml', kcal: 45, p: 0.5, c: 10.5, f: 0.1 },
  moka: { name: 'bela moka', per: 100, unit: 'g', kcal: 340, p: 10, c: 72, f: 1.5 },
  // (v3.50) več rastlinskih beljakovin za vegana (prej skoraj samo tofu): sojini koščki (suhi), zamrznjen edamame
  sojkos: { name: 'sojini koščki ali granulat (suhi)', per: 100, unit: 'g', kcal: 340, p: 50, c: 33, f: 1.5 },
  edamame: { name: 'edamame (zamrznjen, oluščen)', per: 100, unit: 'g', kcal: 125, p: 11, c: 9, f: 5 },
  // (v3.50) za oceno brez AI: najpogostejši dodatki, »grehi« in pijače (prej »Ne poznam« ali null) — niso v receptih
  maslo: { name: 'maslo', per: 100, unit: 'g', kcal: 740, p: 0.7, c: 0.6, f: 82 },
  smetana: { name: 'kisla smetana', per: 100, unit: 'g', kcal: 200, p: 2.8, c: 3.5, f: 20 },
  majoneza: { name: 'majoneza', per: 100, unit: 'g', kcal: 680, p: 1, c: 2, f: 75 },
  salama: { name: 'salama', per: 100, unit: 'g', kcal: 330, p: 17, c: 1, f: 29 },
  hrenovka: { name: 'hrenovka', per: 100, unit: 'g', kcal: 290, p: 12, c: 2, f: 26 },
  pomfri: { name: 'pomfri', per: 100, unit: 'g', kcal: 310, p: 3.5, c: 40, f: 15 },
  pica: { name: 'pica', per: 100, unit: 'g', kcal: 250, p: 11, c: 30, f: 9 },
  burek: { name: 'burek', per: 100, unit: 'g', kcal: 300, p: 8, c: 30, f: 16 },
  sendvic: { name: 'sendvič', per: 100, unit: 'g', kcal: 250, p: 12, c: 28, f: 9 },
  golaz: { name: 'golaž', per: 100, unit: 'g', kcal: 120, p: 10, c: 5, f: 6.5 },
  palacinka: { name: 'palačinke', per: 100, unit: 'g', kcal: 220, p: 7, c: 28, f: 8 },
  pecivo: { name: 'pecivo (zavitek, rogljiček, krof)', per: 100, unit: 'g', kcal: 350, p: 6, c: 45, f: 15 },
  musli: { name: 'müsli', per: 100, unit: 'g', kcal: 380, p: 10, c: 67, f: 7 },
  keksi: { name: 'keksi', per: 100, unit: 'g', kcal: 480, p: 6, c: 68, f: 19 },
  cokolada: { name: 'čokolada', per: 100, unit: 'g', kcal: 540, p: 7, c: 58, f: 31 },
  cips: { name: 'čips', per: 100, unit: 'g', kcal: 540, p: 6, c: 50, f: 35 },
  kava: { name: 'kava (črna)', per: 1, unit: 'kos', kcal: 2, p: 0.2, c: 0.3, f: 0 },
  belakava: { name: 'kava z mlekom', per: 1, unit: 'kos', kcal: 24, p: 1.5, c: 2.2, f: 1 },
  gazirana: { name: 'gazirana pijača (kola)', per: 100, unit: 'ml', kcal: 42, p: 0, c: 10.5, f: 0 },
  pivo: { name: 'pivo', per: 100, unit: 'ml', kcal: 43, p: 0.5, c: 3.6, f: 0 },
  vino: { name: 'vino', per: 100, unit: 'ml', kcal: 80, p: 0.1, c: 2.5, f: 0 },
}
/** (v3.50) pijače z alkoholom: kalorije niso iz 4·B + 4·OH + 9·M (alkohol 7 kcal/g) */
export const F_ALCOHOL = new Set(['pivo', 'vino'])
export type Tpl = [keyof typeof F, number][]
export const TPL: Record<string, Tpl> = {
  zajtrk: [['oves', 70], ['jogurt', 200], ['banana', 1], ['med', 15]],
  kosilo: [['riz', 90], ['piscanec', 150], ['zelenjava', 200], ['olje', 10]],
  obnova: [['testenine', 100], ['tuna', 120], ['omaka', 150], ['olje', 5]],
  vecerja: [['krompir', 300], ['jajce', 3], ['zelenjava', 250], ['olje', 10]],
  malica: [['skuta', 250], ['sadje', 150], ['oreski', 15]],
  pred: [['kruh', 60], ['med', 20], ['banana', 1]],
  stroc: [['fizol', 250], ['kruh', 60], ['zelenjava', 200], ['olje', 10]],
}
/** Isti obroki z malo vlakninami: bel kruh, riž, testenine, krompir brez lupine; brez zelenjave, stročnic, oreškov, sadja z lupino. */
export const TPL_LF: Record<string, Tpl> = {
  zajtrk: [['belkruh', 100], ['marmelada', 30], ['jogurt', 200], ['banana', 1]],
  kosilo: [['rizb', 110], ['piscanec', 150], ['olje', 10]],
  obnova: [['testenineb', 110], ['tuna', 120], ['omaka', 150], ['olje', 5]],
  vecerja: [['krompirb', 400], ['jajce', 3], ['olje', 10]],
  malica: [['skuta', 200], ['banana', 1], ['med', 20]],
  pred: [['belkruh', 60], ['med', 20], ['banana', 1]],
  stroc: [['rizb', 110], ['piscanec', 150], ['olje', 10]],
}
const r10 = (x: number) => Math.max(10, Math.round(x / 10) * 10)
const SMALL = new Set(['olje', 'med', 'oreski', 'marmelada', 'arasid'])
/** količina sestavine po faktorju: kosi celi, majhne stvari (olje, med) na 5, ostalo na 10 */
export const qtyOf = (key: string, q: number, k: number): number => { const f = F[key]!; return f.unit === 'kos' ? Math.max(1, Math.round(q * k)) : SMALL.has(key) ? Math.max(5, Math.round((q * k) / 5) * 5) : r10(q * k) }
/**
 * DOMAČA MERA (Blaž, 16. 10.: »za jest naj bo realno … koliko bi moral pojesti česa«): grami z mero, ki jo poznaš iz
 * kuhinje — rezine kruha, žlice kosmičev, lonček skute, kuhan riž. Samo, kjer je mera jasna; sicer samo grami.
 */
const pl = (n: number, one: string, two: string, few: string, many: string) => (n === 1 ? one : n === 2 ? two : n <= 4 ? few : many)
const half = (x: number) => Math.max(0.5, Math.round(x * 2) / 2)
const halfTxt = (x: number) => (x === 0.5 ? '½' : Number.isInteger(x) ? String(x) : `${Math.floor(x)}½`)
/** (v3.49) lonček, kozarec po številu (prej »6 lončka« pri receptu za 3 osebe); pol in 1½ »lončka« */
const cup = (k: number, w: [string, string, string, string]) => `${halfTxt(k)} ${Number.isInteger(k) ? pl(k, ...w) : w[1]}`
const LONCEK: [string, string, string, string] = ['lonček', 'lončka', 'lončki', 'lončkov'], KOZAREC: [string, string, string, string] = ['kozarec', 'kozarca', 'kozarci', 'kozarcev']
/**
 * (v3.50) pol mere, kjer je pol prav (»20 g kruha« = ½ rezine, ne »1 rezina«; 15 g olja = 1½ žlice, ne »2 žlici«); pri
 * lončku in kozarcu samo, ko je količina blizu mere (160 g skute ni »½ lončka«) — sicer samo grami
 */
const halfW = (x: number, w: [string, string, string, string], gen: string) => { const k = half(x); return `${halfTxt(k)} ${Number.isInteger(k) ? pl(k, ...w) : gen}` }
const near = (x: number) => Math.abs(x - half(x)) <= 0.08
export function measureOf(key: string, q: number): string | null {
  const n = (per: number) => Math.max(1, Math.round(q / per))
  switch (key) {
    case 'kruh': case 'belkruh': return halfW(q / 40, ['rezina', 'rezini', 'rezine', 'rezin'], 'rezine')
    // (v3.51) žlice in žličke samo do 5 (kosmiči do 100 g — ena porcija) — »9 žličk medu« in »28 žlic« kosmičev nihče ne meri
    case 'oves': { const k = n(10); return q > 100 ? null : `≈ ${k} ${pl(k, 'žlica', 'žlici', 'žlice', 'žlic')}` }
    case 'med': case 'marmelada': { const k = n(7); return k > 5 ? null : `${k} ${pl(k, 'žlička', 'žlički', 'žličke', 'žličk')}` }
    case 'olje': return q > 50 ? null : halfW(q / 10, ['žlica', 'žlici', 'žlice', 'žlic'], 'žlice')
    case 'oreski': return q < 10 ? null : q <= 18 ? '½ pesti' : `${n(30)} ${pl(n(30), 'pest', 'pesti', 'pesti', 'pesti')}`
    // (v3.50) pod 100 g sadja ni »1 kos« (60 g je pol jabolka)
    case 'sadje': return q < 100 ? null : halfW(q / 150, ['kos', 'kosa', 'kosi', 'kosov'], 'kosa')
    // (v3.51) po pol kosa (80 g je pol krompirja, ne »≈ 1 kos«)
    // (v3.51) pod 60 g brez mere (30 g ni »½ kosa« — pol krompirja je ~75 g)
    case 'krompir': case 'krompirb': return q < 60 ? null : `≈ ${halfW(q / 150, ['kos', 'kosa', 'kosi', 'kosov'], 'kosa')}`
    case 'skuta': return near(q / 250) ? cup(half(q / 250), LONCEK) : null
    // (v3.50) lonček grškega jogurta je tu 150 g (v nakupu je velik lonček 500 g) — prej isti »lonček« za 150 in 500 g
    case 'jogurt': return near(q / 150) ? `${cup(half(q / 150), LONCEK)} po 150 g` : null
    case 'mleko': case 'kefir': return near(q / 250) ? cup(half(q / 250), KOZAREC) : null
    case 'riz': case 'rizb': return `kuhanega ≈ ${gTxt(q * 2.6)}`
    case 'testenine': case 'testenineb': return `kuhanih ≈ ${gTxt(q * 2.3)}`
    case 'kuskus': return `kuhanega ≈ ${gTxt(q * 2.5)}`
    // (v3.49) slovenske jedi in rastlinski napitki
    case 'ajda': return `kuhane ≈ ${gTxt(q * 3)}`
    case 'jesprenj': return `kuhanega ≈ ${gTxt(q * 3)}`
    case 'sojmleko': case 'sok': return cup(half(q / (key === 'sok' ? 200 : 250)), KOZAREC)
    case 'arasid': { const k = n(15); return k > 5 ? null : `${k} ${pl(k, 'žlica', 'žlici', 'žlice', 'žlic')}` }
    case 'sunka': { const k = n(15); return k > 10 ? null : `${k} ${pl(k, 'rezina', 'rezini', 'rezine', 'rezin')}` }
    default: return null
  }
}
/** (v3.50) pol kosa sadja (»½ banane«) v primeru majhnega obroka; jajce ostane celo */
const HALF_OF: Record<string, string> = { banana: '½ banane', jabolko: '½ jabolka' }
/** (v3.51) od 1000 g ali ml v kg ali l z decimalno vejico (prej »mleko 1200 ml«, »jogurt 1320 g«) */
const bigQty = (q: number, unit: 'g' | 'ml') => (q >= 1000 ? `${String(Math.round(q / 100) / 10).replace('.', ',')} ${unit === 'g' ? 'kg' : 'l'}` : `${q} ${unit}`)
/** (v3.51) grami z ločilom tisočic (»≈ 1 040 g«) */
const gTxt = (x: number) => { const g = Math.round(x / 10) * 10; return g >= 1000 ? `${Math.floor(g / 1000)}\u00a0${String(g % 1000).padStart(3, '0')} g` : `${g} g` }
export const qtyText = (key: string, qq: number): string => { const f = F[key]!; if (f.unit === 'kos') return qq === 0.5 && HALF_OF[key] ? HALF_OF[key]! : `${qq} × ${f.name}`; const m = measureOf(key, qq); return `${f.name} ${bigQty(qq, f.unit)}${m ? ` (${m})` : ''}` }
/**
 * Predloga obroka, pomerjena na kalorije: količine, besedilo in makrohranila.
 * (v3.50) Primer ne sme biti več kot 15 % čez kalorije obroka (prej do +46 %: faktor najmanj 0,5 in cele banane/jajca —
 * pri hujšanju so primeri skupaj dali 1 427 kcal pri cilju 1 313). Faktor gre do 0,3, sadje sme biti pol kosa.
 */
export const EXAMPLE_OVER_MAX = 1.15
export function scaled(tpl: Tpl, kcal: number): { text: string; kcal: number; p: number; c: number; f: number; items: { key: string; qty: number }[] } {
  const base = tpl.reduce((s, [k, q]) => s + (F[k]!.kcal * q) / F[k]!.per, 0)
  const qty = (key: string, q: number, k: number) => (HALF_OF[key] && q * k < 0.75 ? 0.5 : qtyOf(key, q, k))
  const build = (k: number) => {
    let tk = 0, tp = 0, tc = 0, tf = 0
    const items = tpl.map(([key, q]) => {
      const f = F[key]!
      const qq = qty(key, q, k)
      tk += (f.kcal * qq) / f.per; tp += (f.p * qq) / f.per; tc += (f.c * qq) / f.per; tf += (f.f * qq) / f.per
      return { key: key as string, qty: qq }
    })
    return { text: items.map(i => qtyText(i.key, i.qty)).join(' · '), kcal: Math.round(tk), p: Math.round(tp), c: Math.round(tc), f: Math.round(tf), items }
  }
  let k = Math.max(0.3, Math.min(2, kcal / base))
  let out = build(k)
  for (let i = 0; i < 4 && out.kcal > kcal * EXAMPLE_OVER_MAX && k > 0.3; i++) { k = Math.max(0.3, k * (kcal / out.kcal) * 0.98); out = build(k) }
  return out
}
/** (v3.50) majhen glavni obrok (pod 200 kcal): jogurt s sadjem namesto skrčene večerje (krompir, 2 jajci = 350 kcal pri 240) */
export const TPL_SMALL: Tpl = [['jogurt', 150], ['sadje', 100]]
export const TPL_SMALL_LF: Tpl = [['jogurt', 200], ['med', 10]]
/** pred vadbo, majhen: banana z medom (lahko, malo vlaknin) */
export const TPL_SMALL_PRED: Tpl = [['banana', 1], ['med', 10]]
export function exampleFor(tpl: string, kcal: number, lf: boolean): ReturnType<typeof scaled> | null {
  const t = kcal < 200 ? (tpl === 'pred' ? TPL_SMALL_PRED : lf ? TPL_SMALL_LF : TPL_SMALL) : (lf ? TPL_LF : TPL)[tpl]
  return t ? scaled(t, kcal) : null
}

export interface MealSlotPlan { key: string; label: string; when: string; slot: MealEntry['slot']; kcal: number; proteinG: number; carbsG: number; example: string; exampleKcal: number; exampleP: number; tpl?: string; /** koliko je že pojedeno (po prilagoditvi čez dan) */ got?: number; /** primer z malo vlakninami (pred tekmo) */ lf?: boolean; /** obrok tik pred vožnjo (2–3 h ali manj): brez stročnic, malo maščob in vlaknin */ beforeRide?: boolean; /** (v3.50) nevpisan obrok, katerega čas je mimo — ni več v načrtu, kalorije so v naslednjih */ skipped?: boolean }
export interface DayNutrition { total: number; onBike: { carbs: number; kcal: number; /** (v3.49) banane v gorivu na kolesu — štejejo v dnevno mejo banan */ bananas?: number } | null; slots: MealSlotPlan[]; tip: string; /** preostali obroki so prilagojeni pojedenemu */ adjusted?: boolean; /** tudi z večjimi obroki ne pride do cilja (strop 1,35 ×) */ short?: number; /** tekma danes ali v 2 dneh: malo vlaknin */ race?: RaceSoon | null; /** (v3.49) glavna vožnja dneva je za nami (dayMealsOf) */ rideDone?: boolean; /** (v3.50) vožnja je za nami, gorivo na kolesu ni vpisano (šteje 0) */ fuelMissing?: boolean }

/**
 * OH dneva (brez goriva na kolesu) razdeli na obroke: sorazmerno s prostorom za OH v obroku (kcal − beljakovine),
 * obroka okoli vožnje z večjim deležem; noben obrok ne dobi več OH, kot jih gre v njegove kalorije.
 * Vsota je natanko `total`, če gre v obroke (sicer vsi obroki do roba).
 */
/**
 * Beljakovine dneva na obroke: vsak glavni obrok vsaj 20–25 g (0,3 g/kg — toliko, da mišice dobijo signal), ostalo
 * sorazmerno s kalorijami obroka (kosilo več kot malica), noben obrok čez 40 % svojih kalorij (malica 290 kcal ne dobi
 * 40 g); »pred vadbo« 10 g. Vsota je dnevni cilj, če gre v obroke.
 */
export function splitProtein(total: number, slots: readonly { kcal: number; pred: boolean }[], weightKg: number): number[] {
  const out = slots.map(s => (s.pred ? Math.min(10, total) : 0))
  const main = slots.map((_, i) => i).filter(i => !slots[i]!.pred)
  const cap = (i: number) => Math.max(0, Math.floor((slots[i]!.kcal * 0.4) / 4))
  const base = Math.min(25, Math.max(20, Math.round(weightKg * 0.3)))
  let rem = Math.max(0, total - out.reduce((a, b) => a + b, 0))
  // najprej osnova vsakemu obroku (če cilja ni dovolj za vse osnove, sorazmerno manj)
  const floors = main.map(i => Math.min(cap(i), base))
  const sumF = floors.reduce((a, b) => a + b, 0)
  const sc = sumF > rem ? rem / sumF : 1
  main.forEach((i, j) => { out[i] = Math.floor(floors[j]! * sc); rem -= out[i]! })
  for (let guard = 0; rem > 0 && guard < 20; guard++) {
    const open = main.filter(i => out[i]! < cap(i))
    if (!open.length) break
    const sumK = open.reduce((s, i) => s + slots[i]!.kcal, 0)
    let used = 0
    for (const i of open) { const add = Math.min(cap(i) - out[i]!, Math.floor((rem * slots[i]!.kcal) / sumK)); out[i]! += add; used += add }
    if (!used) for (const i of [...open].sort((a, b) => slots[b]!.kcal - slots[a]!.kcal)) { if (used >= rem) break; out[i]! += 1; used += 1 }
    rem -= used
  }
  return out
}
function splitCarbs(total: number, slots: readonly { kcal: number; proteinG: number; around: boolean }[]): number[] {
  const cap = slots.map(s => Math.max(0, Math.floor((s.kcal - s.proteinG * 4) / 4)))
  const T = Math.min(Math.max(0, Math.round(Number.isFinite(total) ? total : 0)), cap.reduce((a, b) => a + b, 0))
  const val = slots.map(() => 0)
  // sorazmerno (obroka okoli vožnje ×1,5); kdor bi dobil več, kot gre vanj, dobi rob, ostanek gre drugim
  let pool = slots.map((_, i) => i).filter(i => cap[i]! > 0), left = T
  for (let guard = 0; guard <= slots.length && pool.length && left > 0; guard++) {
    const w = pool.map(i => cap[i]! * (slots[i]!.around ? 1.5 : 1)), W = w.reduce((a, b) => a + b, 0)
    const full = pool.filter((i, k) => (left * w[k]!) / W >= cap[i]!)
    if (!full.length) { pool.forEach((i, k) => { val[i] = (left * w[k]!) / W }); left = 0; break }
    for (const i of full) { val[i] = cap[i]!; left -= cap[i]! }
    pool = pool.filter(i => !full.includes(i))
  }
  // cela števila, vsota ostane (največji ostanki dobijo +1)
  const out = val.map(v => Math.floor(v))
  let rem = T - out.reduce((a, b) => a + b, 0)
  for (const { i } of val.map((v, i) => ({ i, r: v - Math.floor(v) })).sort((a, b) => b.r - a.r)) { if (rem <= 0) break; if (out[i]! < cap[i]!) { out[i]! += 1; rem-- } }
  return out
}

/** obrok načrta: ključ, ime, kdaj, termin, delež kalorij, predloga */
type MealS = [string, string, string, MealEntry['slot'], number, keyof typeof TPL]
/**
 * (v3.49) Razpored obrokov dneva okoli vožnje — en vir za Prehrano (dayMealPlan) ter »Pred« in »Po« na Danes in v Vadbi
 * (fueling), da isti dan ne dobi dveh različnih nasvetov.
 */
/**
 * (v3.50) Katera seja dobi obroke okoli sebe: vožnja ≥ 45 min ali tekma; tek ≥ 45 min, hribi ≥ 90 min, moč ≥ 40 min
 * (prej samo kolo — tekač je dobil nasvet »OH pred vadbo in po njej«, obroki pa brez termina vadbe).
 */
export function aroundSession(main: RideLike | null): boolean {
  if (!main) return false
  const m = main.durationMin || 0
  if (main.kind === 'kolo' || main.kind === 'test') return m >= 45 || main.role === 'dirka'
  return (main.kind === 'tek' && m >= 45) || (main.kind === 'pohod' && m >= 90) || (main.kind === 'moc' && m >= 40)
}
/** (v3.50) besede za sejo v razporedu: vožnja / tek / vadba (hribi, moč) */
// (v3.51) pohod: »pred pohodom / po pohodu« (prej »vadba« ob »Kalorije pohoda«)
const sessWords = (k: RideLike['kind'] | undefined) => (k === 'tek' ? { pred: 'pred tekom', po: 'Po teku', poM: 'po teku', ime: 'tek', nj: 'njem' } : k === 'pohod' ? { pred: 'pred pohodom', po: 'Po pohodu', poM: 'po pohodu', ime: 'pohod', nj: 'njem' } : k === 'kolo' || k === 'test' || !k ? { pred: 'pred vožnjo', po: 'Po vožnji', poM: 'po vožnji', ime: 'vožnja', nj: 'njej' } : { pred: 'pred vadbo', po: 'Po vadbi', poM: 'po vadbi', ime: 'vadba', nj: 'njej' })
/** (v3.50) razpored po uri začetka seje (z ure): do 11h zjutraj, 11–16 popoldne, pozneje zvečer */
export const trainTimeOfHour = (h: number): NonNullable<Profile['trainTime']> => (h < 11 ? 'zjutraj' : h < 16 ? 'popoldne' : 'zvecer')
export function mealScheduleOf(p: Pick<Profile, 'trainTime'>, main: RideLike | null, ctx: Pick<FuelCtx, 'race' | 'rideDone' | 'startH'> = {}): { plan: MealS[]; ride: boolean; raceDay: boolean; raceH: string; longAm: boolean; t: NonNullable<Profile['trainTime']>; /** (v3.50) besede seje (vožnja, tek, vadba) */ w: ReturnType<typeof sessWords> } {
  // tekma je vožnja tudi pod 45 min (kronometer): plan ima obrok po tekmi (v3.48); (v3.50) tudi tek, hribi in moč
  const ride = aroundSession(main)
  const w = sessWords(main?.kind)
  const rmin = main?.durationMin || 0
  // (v3.50) ura dejanskega začetka (z ure) ima prednost pred »kdaj običajno treniraš« — po jutranji vožnji ni več
  // »Kosilo · 2–3 h pred vožnjo«, ampak kosilo po vožnji
  const t: NonNullable<Profile['trainTime']> = ride && ctx.startH != null && Number.isFinite(ctx.startH) ? trainTimeOfHour(ctx.startH) : p.trainTime || 'popoldne'
  // (v3.49) dan tekme: obroki po startu, ne po tem, kdaj običajno treniraš (prej »Kosilo · 2–3 h pred vožnjo« ali
  // »Pred vožnjo · 45–60 min« namesto zajtrka 3 h prej); ura zajtrka in OH po istem pravilu kot raceBreakfast (v3.48)
  const raceDay = ride && main!.role === 'dirka'
  const other = !!main?.raceId || (!!ctx.race && !ctx.race.main)
  const raceH = rmin >= 150 && !other ? '3' : '2–3'
  // (v3.49) dolga jutranja vožnja: zajtrk pred njo in kosilo po njej (prej »Po vožnji — zajtrk« ob ~12h in takoj za njim kosilo)
  // (v3.50) tudi krajša, če se po uri konča ob 11h ali pozneje (obrok po njej je kosilo, ne zajtrk)
  const endsLate = ctx.startH != null && Number.isFinite(ctx.startH) && ctx.startH + rmin / 60 >= 11
  const longAm = ride && !raceDay && t === 'zjutraj' && (rmin >= 150 || endsLate)
  const P = w.pred, PO = w.po, POM = w.poM
  const plan: MealS[] = !ride
    ? [['zajtrk', 'Zajtrk', 'zjutraj', 'zajtrk', 0.25, 'zajtrk'], ['kosilo', 'Kosilo', 'opoldne', 'kosilo', 0.35, 'kosilo'], ['malica', 'Malica', 'popoldne', 'malica', 0.12, 'malica'], ['vecerja', 'Večerja', 'zvečer', 'vecerja', 0.28, 'vecerja']]
    : raceDay
    ? [['zajtrk', 'Zajtrk pred tekmo', `${raceH} h pred startom`, 'zajtrk', 0.28, 'zajtrk'], ['pred', 'Pred startom', '30–60 min prej, lahko', 'malica', 0.07, 'pred'], ['obnova', 'Po tekmi', 'v 1 h po cilju', 'kosilo', 0.35, 'obnova'], ['vecerja', 'Večerja', 'zvečer', 'vecerja', 0.3, 'vecerja']]
    : longAm
    ? [['zajtrk', `Zajtrk ${P}`, '1–2 h prej', 'zajtrk', 0.2, 'zajtrk'], ['obnova', `${PO} — kosilo`, `v 45 min ${POM}`, 'kosilo', 0.35, 'obnova'], ['malica', 'Malica', 'popoldne', 'malica', 0.15, 'malica'], ['vecerja', 'Večerja', 'zvečer', 'vecerja', 0.3, 'stroc']]
    : t === 'zjutraj'
    ? [['pred', `${P[0]!.toUpperCase()}${P.slice(1)}`, '45–60 min prej, lahko', 'zajtrk', 0.12, 'pred'], ['obnova', `${PO} — zajtrk`, `v 45 min ${POM}`, 'zajtrk', 0.3, 'zajtrk'], ['kosilo', 'Kosilo', 'opoldne', 'kosilo', 0.3, 'kosilo'], ['vecerja', 'Večerja', 'zvečer', 'vecerja', 0.28, 'stroc']]
    : t === 'zvecer'
    ? [['zajtrk', 'Zajtrk', 'zjutraj', 'zajtrk', 0.25, 'zajtrk'], ['kosilo', 'Kosilo', 'opoldne', 'kosilo', 0.3, 'kosilo'], ['pred', `Malica ${P}`, '1–2 h prej', 'malica', 0.15, 'pred'], ['obnova', `${PO} — večerja`, `v 45 min ${POM}`, 'vecerja', 0.3, 'obnova']]
    : [['zajtrk', 'Zajtrk', 'zjutraj', 'zajtrk', 0.26, 'zajtrk'], ['kosilo', 'Kosilo', `2–3 h ${P}`, 'kosilo', 0.3, 'kosilo'], ['obnova', `${PO} — večerja`, `v 45 min ${POM}`, 'vecerja', 0.28, 'obnova'], ['malica', 'Zvečer', 'pred spanjem', 'drugo', 0.16, 'malica']]
  // (v3.50) seja je za nami: obrok, ki je bil »2–3 h pred vožnjo« in še ni pojeden, je zdaj obrok po njej (A11, D06)
  // (v3.51) z znano uro začetka (z ure) po 13h je bilo kosilo pred sejo: »pred vožnjo«, ne »po vožnji« ob »Po vožnji — večerja«
  const wasBefore = ctx.startH != null && Number.isFinite(ctx.startH) && ctx.startH >= 13
  if (ctx.rideDone) for (const s of plan) if (s[0] !== 'pred' && new RegExp(`\\b${P}$`).test(s[2])) s[2] = wasBefore ? P : POM
  return { plan, ride, raceDay, raceH, longAm, t, w }
}

/**
 * Razporedi dnevni cilj na obroke. Kalorije za gorivo na kolesu se odštejejo prve (so del dnevnega cilja).
 * OH obrokov skupaj z gorivom na kolesu = OH dnevnega cilja (tudi pri polnjenju z OH pred tekmo).
 * @param main glavna vožnja dneva (ali null, če je dan počitka / samo moč)
 */
export function dayMealPlan(p: Pick<Profile, 'weightKg' | 'trainTime'> & { fuelKit?: string[] | null }, target: Pick<DailyTarget, 'kcal' | 'proteinG' | 'carbsG'> & Partial<Pick<DailyTarget, 'deficit'>>, main: RideLike | null, ctx: FuelCtx = {}): DayNutrition {
  const fuel = main ? rideFuel(main, p.fuelKit, ctx) : null
  // (v3.48) odšteje se to, kar res neseš (cele banane, bidoni), ne zaokrožen izračun OH na uro
  const bike = fuel && fuel.totalCarbs ? { carbs: fuel.carriedCarbs, kcal: Math.round(fuel.plan.reduce((s, x) => s + x.n * x.kcal, 0)), bananas: fuel.plan.find(x => x.key === 'banana')?.n || 0 } : null
  const rest = Math.max(0, target.kcal - (bike?.kcal || 0))
  const { plan, ride, raceDay, raceH, longAm, t, w: sw } = mealScheduleOf(p, main, ctx)
  const rmin = main?.durationMin || 0, w = p.weightKg || 75
  // pred tekmo malo vlaknin: dan ali 2 dni prej vsi obroki, na dan tekme obroki do starta (pred »po vožnji«);
  // brez obroka po tekmi (tekme ni v planu) večerja normalno (v3.48)
  const race = ctx.race ?? null
  const afterIdx = plan.findIndex(s => s[0] === 'obnova')
  const lfAt = (i: number) => !!race && (race.inDays > 0 || (afterIdx < 0 ? i < plan.length - 1 : i < afterIdx))
  const kcals = plan.map(([, , , , share]) => Math.round((rest * share) / 10) * 10)
  // (v3.49) zajtrk pred tekmo ima vsaj spodnjo mejo OH po teži (~80 % kalorij iz OH) — kalorije zanj dajo ostali obroki
  const [bLo] = raceBreakfastGkg(rmin)
  const minK = raceDay ? Math.round((bLo * w * 4) / 0.8 / 10) * 10 : 0
  if (raceDay && kcals[0]! < minK && rest > minK * 1.5) {
    const others = kcals.slice(1).reduce((a, b) => a + b, 0), f = (rest - minK) / others
    for (let i = 1; i < kcals.length; i++) kcals[i] = Math.round((kcals[i]! * f) / 10) * 10
    kcals[0] = minK
  }
  const prots = splitProtein(target.proteinG, plan.map(([key], i) => ({ kcal: kcals[i]!, pred: key === 'pred' })), w)
  // (v3.50) »pred vožnjo/tekom/vadbo« — oznaka obroka tik pred sejo (brez stročnic, malo maščob); po seji je ni več
  const preRe = /pred (vožnjo|tekmo|tekom|vadbo|pohodom)/
  const carbs = splitCarbs(Math.max(0, (target.carbsG || 0) - (bike?.carbs || 0)), plan.map(([key, label, when], i) => ({ kcal: kcals[i]!, proteinG: prots[i]!, around: key === 'pred' || key === 'obnova' || preRe.test(label) || preRe.test(when) })))
  if (raceDay) {
    // OH zajtrka do spodnje meje (2 g na kg pri dolgi tekmi): iz večerje, nato iz obroka po tekmi — vsota ostane
    let need = Math.min(Math.round(bLo * w), Math.floor((kcals[0]! - prots[0]! * 4) / 4)) - carbs[0]!
    for (const i of [3, 2, 1]) { if (need <= 0) break; const take = Math.min(need, carbs[i]!); carbs[i]! -= take; carbs[0]! += take; need -= take }
  }
  const slots: MealSlotPlan[] = plan.map(([key, label, when, slot, , tpl], i) => {
    const kcal = kcals[i]!, proteinG = prots[i]!, carbsG = carbs[i]!
    const lf = lfAt(i)
    const ex = exampleFor(tpl, kcal, lf) ?? scaled(TPL[tpl]!, kcal)
    const beforeRide = ride && (key === 'pred' || preRe.test(when) || preRe.test(label))
    return { key, label, when, slot, kcal, proteinG, carbsG, example: ex.text, exampleKcal: ex.kcal, exampleP: ex.p, tpl, ...(lf ? { lf } : {}), ...(beforeRide ? { beforeRide } : {}) }
  })
  // stavek o deficitu samo, ko je deficit (v3.48)
  const def = (target.deficit || 0) > 0
  const bike0 = main?.kind === 'kolo' || main?.kind === 'test'
  // (v3.50) besede po vrsti seje (tek, hribi, moč niso »vožnja« in »na kolesu«); po seji nasvet za obrok po njej
  const whereNot = bike0 ? 'nikoli na kolesu' : 'nikoli okoli vadbe'
  const after = plan.find(s => s[0] === 'obnova')
  const tip = race ? lowFiberRule(race)
    : !ride && ctx.workout
    ? `Dan vadbe: ogljikovi hidrati pred vadbo in v obroku po njej (v 45 minutah), beljakovine na vse obroke.${def ? ' Primanjkljaj nastane pri ostalih obrokih, ne okoli vadbe.' : ''}`
    : !ride
    // (v3.50) brez naštevanja riža in testenin — recept pod nasvetom jih ima (količine so že po cilju dneva)
    ? 'Dan brez vadbe: manj ogljikovih hidratov kot na dan vadbe, več zelenjave in beljakovin — količine v receptih so že prilagojene. Beljakovine razdeli na 4 obroke.'
    : raceDay
    ? `Dan tekme: zajtrk ${raceH} h pred startom z veliko OH in malo vlaknin, 30–60 min prej banana ali gel, v 1 h po cilju obrok z beljakovinami in OH.`
    : ctx.rideDone
    ? `${sw.ime[0]!.toUpperCase()}${sw.ime.slice(1)} je za tabo — ${after ? after[1].replace(/^.*— /, '') : 'obrok'} ${sw.poM} z OH in beljakovinami v 45 min, naprej normalno.${def ? ' Deficit ostane pri ostalih obrokih.' : ''}`
    : `Ogljikovi hidrati okoli ${bike0 ? 'vožnje' : main?.kind === 'tek' ? 'teka' : main?.kind === 'pohod' ? 'pohoda' : 'vadbe'}: ${longAm ? `zajtrk ${sw.pred} in kosilo po ${sw.nj}` : `kosilo ${t === 'zjutraj' ? `in zajtrk ${sw.poM}` : `${sw.pred} in obrok po ${sw.nj}`}`} naj bosta bogata z OH.${def ? ` Deficit ustvariš pri ostalih obrokih, ${whereNot}.` : ''}`
  return { total: target.kcal, onBike: bike, slots, tip, race }
}

/**
 * Čez dan: pojedeni obroki ostanejo, kot so; preostali se sorazmerno prilagodijo, da skupaj z gorivom na kolesu
 * pridejo do cilja — največ 1,35 × prvotnega (dvojna večerja ni rešitev; kar manjka, pove `short`).
 * Gorivo na kolesu: vpisano (»Med vožnjo«) namesto načrtovanega. Ko je vožnja že opravljena (opts.rideDone) in gorivo
 * ni vpisano, velja 0 — ne predpostavljamo, da je bilo pojedeno, in obrokov po vožnji zato ne krčimo.
 * Beljakovine ostanejo po načrtu.
 */
/** Pojedeno razdeli na načrtovane obroke istega termina (zajtrk je lahko »pred vožnjo« in »po vožnji«) — nič dvakrat. */
const hOf = (t?: string | null) => { const m = /^(\d{1,2}):(\d{2})/.exec(t || ''); return m ? +m[1]! + +m[2]! / 60 : null }
/**
 * (v3.50) Vpis v terminu prigrizka pred sejo (»Pred startom«, »Malica pred vožnjo«) šteje zanj samo, če je bil pred
 * sejo: pred znano uro začetka (z ure) in ne za že vpisanim obrokom po seji (malica ob 16h po tekmi ni »Pred startom«).
 * Sicer gre v naslednji obrok istega termina ali ostane med pojedenim (preostali obroki se prilagodijo).
 */
export function gotBySlot(dp: Pick<DayNutrition, 'slots'>, meals: readonly MealEntry[], opts: { startH?: number | null } = {}): Map<string, number> {
  const got = new Map<string, number>()
  const ob = dp.slots.find(x => x.key === 'obnova')
  for (const sl of [...new Set(dp.slots.map(x => x.slot))]) {
    const ms = meals.filter(m => m.slot === sl)
    const own = dp.slots.filter(x => x.slot === sl)
    const pred = own.find(x => x.key === 'pred')
    // prvi vpis obroka po seji v drugem terminu (kosilo po tekmi) — kar je za njim, ni bilo pred sejo
    const obT = ob && ob.slot !== sl ? Math.min(...meals.filter(m => m.slot === ob.slot).map(m => hOf(m.time) ?? Infinity)) : Infinity
    const after = (m: MealEntry) => { const h = hOf(m.time); return h != null && ((opts.startH != null && h > opts.startH) || h > obT) }
    let left = ms.reduce((s, m) => s + m.kcal, 0)
    let leftPre = pred ? ms.filter(m => !after(m)).reduce((s, m) => s + m.kcal, 0) : left
    own.forEach((x, i) => {
      const last = i === own.length - 1
      const g = x === pred ? (last ? leftPre : Math.min(leftPre, x.kcal)) : last ? left : Math.min(left, x.kcal)
      got.set(x.key, g); left -= g; leftPre = Math.max(0, Math.min(leftPre - (x === pred ? g : 0), left))
    })
  }
  return got
}

/** (v3.50) beljakovinski prigrizek nad ciljem (skuta s sadjem), ko do cilja beljakovin manjka vsaj 20 g */
export const PROT_SNACK_KCAL = 250
export const TPL_PROT: Tpl = [['skuta', 250], ['sadje', 100]]
export const TPL_PROT_LF: Tpl = [['skuta', 250], ['med', 10]]
export function adjustToEaten(dp: DayNutrition, meals: readonly MealEntry[], target: number, opts: { rideDone?: boolean; weightKg?: number | null; /** (v3.50) ura začetka seje (z ure) */ startH?: number | null; /** (v3.50) ključi obrokov, katerih čas je mimo (dayMealsOf po uri) */ past?: readonly string[]; /** (v3.50) koliko beljakovin do cilja še manjka */ proteinLeft?: number } = {}): DayNutrition {
  const bike = meals.filter(m => m.slot === 'med_vadbo')
  const bikeKcal = bike.length ? bike.reduce((s, m) => s + (m.kcal || 0), 0) : opts.rideDone ? 0 : (dp.onBike?.kcal || 0)
  const missedFuel = !bike.length && !!opts.rideDone && (dp.onBike?.kcal || 0) > 0
  const eatenAll = meals.filter(m => m.slot !== 'med_vadbo').reduce((s, m) => s + m.kcal, 0)
  const got = gotBySlot(dp, meals, { startH: opts.startH })
  // (v3.50) nevpisan obrok, katerega čas je mimo (zajtrk ob 14h), ni več prihodnji: kalorije gredo v naslednje obroke
  // (prej »Zajtrk 537 kcal« ob 14h, obroč pa »Še 1 396«) — samo, ko danes vpisuješ (vsaj en obrok), obroka okoli seje ne
  const skipped = new Set(eatenAll > 0 ? dp.slots.filter(x => opts.past?.includes(x.key) && !(got.get(x.key)! > 0) && x.key !== 'pred' && x.key !== 'obnova').map(x => x.key) : [])
  const open = dp.slots.filter(x => !(got.get(x.key)! > 0) && !skipped.has(x.key))
  const planned = open.reduce((s, x) => s + x.kcal, 0)
  const flag = (x: MealSlotPlan) => (skipped.has(x.key) ? { skipped: true } : {})
  // (v3.48) tudi vpis v terminu, ki ga načrt nima (malica na dan vožnje), prilagodi preostale obroke
  if (!planned || !eatenAll && !bike.length && !missedFuel) return { ...dp, slots: dp.slots.map(x => ({ ...x, got: got.get(x.key) || 0, ...flag(x) })), ...(skipped.size ? { adjusted: true } : {}), ...(missedFuel ? { fuelMissing: true } : {}) }
  const remaining = target - bikeKcal - eatenAll
  // (v3.50) gorivo po vožnji ni vpisano: obroki največ 1,15 × (prej 1,35 × — kosilo 1 201 kcal, čeprav si na kolesu morda jedel)
  const f = Math.max(0, Math.min(missedFuel ? 1.15 : 1.35, remaining / planned))
  // (v3.48) obnova po vožnji ostane, tudi če si nad ciljem (beljakovine + OH, ~0,3 + 1 g na kg); prigrizek pred vožnjo vsaj 150 kcal
  const w = opts.weightKg && opts.weightKg > 0 ? opts.weightKg : 0
  // (v3.50) kalorije dosežene, beljakovin manjka ≥ 20 g: zadnji odprti obrok je beljakovinski prigrizek ~250 kcal
  // (prej »Malica 10 kcal«, »Večerja 30 kcal«, obroč pa »52 g beljakovin«)
  const pLeft = opts.proteinLeft ?? 0
  const protKey = pLeft >= 20 && f < 0.5 && !open.some(o => o.key === 'obnova') ? [...open].reverse().find(o => o.key !== 'pred')?.key ?? null : null
  const floorOf = (x: MealSlotPlan) => Math.min(x.kcal, x.key === 'obnova' ? Math.max(250, Math.round((w * 1.3 * 4) / 10) * 10) : x.key === 'pred' && !opts.rideDone ? 150 : x.key === protKey ? PROT_SNACK_KCAL : 0)
  // (v3.50) beljakovine skrčenega obroka največ 45 % njegovih kalorij (prej »Večerja 240 kcal · B 38 g« = 63 %);
  // ostanek gre v druge odprte obroke, kolikor gre vanje
  const pCap = (kcal: number) => Math.max(0, Math.floor((kcal * 0.45) / 4))
  let pExtra = 0
  const slots0 = dp.slots.map(x => {
    if (!open.includes(x)) return { ...x, got: got.get(x.key) || 0, ...flag(x) }
    const kcal = Math.max(floorOf(x), Math.round((x.kcal * f) / 10) * 10)
    if (Math.abs(kcal - x.kcal) < 20) return { ...x, got: 0 }
    const snack = x.key === protKey && kcal <= PROT_SNACK_KCAL
    const proteinG = snack ? Math.min(pCap(kcal), Math.max(x.proteinG, pLeft)) : Math.min(x.proteinG, pCap(kcal))
    pExtra += Math.max(0, x.proteinG - proteinG)
    // OH obroka sorazmerno z novimi kalorijami (ne več, kot jih gre vanje)
    const carbsG = Math.max(0, Math.min(Math.floor((kcal - proteinG * 4) / 4), x.kcal > 0 ? Math.round((x.carbsG * kcal) / x.kcal) : 0))
    // (v3.50) primer po predlogi, ki ne gre več kot 15 % čez obrok; pod 200 kcal manjša predloga (jogurt s sadjem)
    const ex = snack ? scaled(x.lf ? TPL_PROT_LF : TPL_PROT, kcal) : x.tpl && kcal >= 150 ? exampleFor(x.tpl, kcal, !!x.lf) : null
    // »ali nič« samo za prigrizek (malica, zvečer); glavni obrok ostane, le majhen
    const small = x.slot === 'malica' || x.slot === 'drugo' ? 'lahko kaj majhnega z beljakovinami (jogurt, skuta) ali nič' : 'majhen obrok z beljakovinami (jogurt, skuta ali jajce)'
    return { ...x, kcal, proteinG, carbsG, got: 0, ...(ex ? { example: ex.text, exampleKcal: ex.kcal, exampleP: ex.p } : kcal < 150 ? { example: small, exampleKcal: 0, exampleP: 0 } : {}) }
  })
  const openKeys = new Set(open.map(o => o.key))
  const slots = slots0.map(x => {
    if (!pExtra || !openKeys.has(x.key)) return x
    const add = Math.min(pExtra, Math.max(0, pCap(x.kcal) - x.proteinG))
    if (!add) return x
    pExtra -= add
    const proteinG = x.proteinG + add
    return { ...x, proteinG, carbsG: Math.max(0, Math.min(x.carbsG, Math.floor((x.kcal - proteinG * 4) / 4))) }
  })
  const newOpen = slots.filter(x => open.some(o => o.key === x.key)).reduce((s, x) => s + x.kcal, 0)
  const short = Math.max(0, Math.round((remaining - newOpen) / 10) * 10)
  return { ...dp, slots, adjusted: skipped.size > 0 || slots.some((x, i) => x.kcal !== dp.slots[i]!.kcal), short: short >= 150 ? short : 0, ...(missedFuel ? { fuelMissing: true } : {}) }
}

