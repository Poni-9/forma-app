import type { MealEntry, PlanDay, Profile } from '../types'
import type { DailyTarget } from './energy'

/**
 * VODENJE PREHRANE — kaj in koliko jesti danes, razporejeno okoli treninga, in koliko na kolesu.
 * Deterministično (brez AI): dnevni cilj iz energy.ts se razdeli na obroke; vsak obrok ima kcal, beljakovine,
 * ogljikove hidrate in primer s količinami iz navadne slovenske trgovine.
 * Na kolesu: ogljikovi hidrati na uro po vrsti vožnje (ISSN: 30–60 g/h, na dolgih in dirki do 90 g/h),
 * tekočina 500–750 ml na uro, začetek po ~30 min, nato vsakih ~20 min.
 */

/* ---------- gorivo na kolesu ---------- */
/** opomnik med vožnjo: v minuti atMin — kaj pojesti ali popiti */
export interface FuelCue { atMin: number; text: string; solid: boolean; short: string }
export interface RideFuel {
  /** ogljikovi hidrati na uro */
  gph: number
  /** skupaj za vožnjo */
  totalCarbs: number
  /** koliko OH je v stvareh, ki jih vzameš s seboj (≈ totalCarbs, zaokroženo navzgor na cele kose) */
  carriedCarbs: number
  fluidMl: number
  bottles: number
  /** kaj vzeti s seboj */
  items: string[]
  /** kdaj jesti in piti */
  schedule: string
  /** časovnica opomnikov med vožnjo */
  cues: FuelCue[]
  /** vsakih koliko minut opomnik (0 = brez) */
  everyMin: number
  /** prvič po minutah */
  firstAt: number
  /** gramov OH na 20 minut (ritem) */
  perReminder: number
}

type RideLike = Pick<PlanDay, 'kind' | 'durationMin' | 'zone'> & { role?: PlanDay['role']; title?: string }

const ISO = 40, BAR = 40, BAN = 25, GEL = 25
const l1 = (ml: number) => (ml / 1000).toFixed(1).replace('.', ',')
const hm = (m: number) => `${Math.floor(m / 60)}:${String(m % 60).padStart(2, '0')}`

/**
 * Gorivo za vožnjo. Vse se sešteje: bidoni z domačim izotonikom (40 g OH na 750 ml) + trda hrana in geli = skupaj.
 * Časovnica: od 30. minute vsakih 20 min opomnik (ne v zadnjih 15 min); trda hrana razporejena enakomerno,
 * vmes požirki izotonika; opomnik za dolivanje, ko bidona zmanjka.
 */
export function rideFuel(d: RideLike | null): RideFuel | null {
  if (!d || (d.kind !== 'kolo' && d.kind !== 'test')) return null
  const min = d.durationMin || 0
  const hours = min / 60
  const race = d.role === 'dirka'
  const sim = /Simulacija/i.test(d.title || '')   // generalka za dirko: vadiš dirkalno gorivo
  const hard = d.role === 'kljucna' || d.role === 'test' || /Z[4-5]|test/.test(d.zone || '')
  let gph = 0
  if (race) gph = 85
  else if (d.role === 'regen' || min < 60) gph = 0
  else if (hard) gph = min >= 75 ? 70 : 40
  else if (sim) gph = 80
  else if (d.role === 'dolga') gph = min >= 150 ? 60 : 50
  else gph = min >= 90 ? 40 : 0
  const totalCarbs = gph ? Math.round((gph * Math.max(0, hours - 0.5)) / 5) * 5 : 0
  const fluidMl = Math.max(500, Math.round((hours * (hard || race ? 700 : 600)) / 50) * 50)
  const bottles = Math.max(1, Math.ceil(fluidMl / 750))
  const carried = Math.min(2, bottles)
  const refills = bottles - carried
  if (!totalCarbs) {
    const items = [`${carried} × bidon vode (skupaj ~${fluidMl} ml${refills ? ', dolij na postanku' : ''})${min >= 60 ? ' — ob vročini z elektroliti' : ''}`]
    return { gph, totalCarbs, carriedCarbs: 0, fluidMl, bottles, items, schedule: min < 60 ? 'Samo voda.' : 'Voda po žeji, na kolesu ne jej — seja je lahka ali kratka.', cues: [], everyMin: 0, firstAt: 0, perReminder: 0 }
  }

  // 1) bidoni: celi bidoni izotonika, a ne več OH, kot jih rabiš (+10 g); ostali bidoni voda
  const iso = Math.min(bottles, Math.max(1, Math.floor((totalCarbs + 10) / ISO)))
  const isoCarried = Math.min(iso, carried), isoRefill = iso - isoCarried
  const water = carried - isoCarried
  // 2) ostanek: na dolgih najprej ploščice (prava hrana v prvi polovici), na lahkih banane, na intervalih in dirki geli
  let rest = totalCarbs - iso * ISO
  const long = min >= 150
  let bars = 0, bananas = 0, gels = 0
  while (rest > 10) {
    if (long && bars < 2 && rest >= 30) { bars++; rest -= BAR }
    else if (!hard && !race && !sim && bananas < 2) { bananas++; rest -= BAN }
    else { gels++; rest -= GEL }
  }
  const carriedCarbs = iso * ISO + bars * BAR + bananas * BAN + gels * GEL

  const items: string[] = [`${isoCarried} × bidon izotonika (750 ml vode + 40 g sladkorja ali maltodekstrina + ščep soli ≈ 40 g OH)`]
  if (water) items.push(`${water} × bidon vode`)
  if (refills) items.push(`za dolivanje na postanku${isoRefill ? `: ${isoRefill} × vrečka s 40 g sladkorja/maltodekstrina in ščepom soli` : ' (voda)'}`)
  if (bars) items.push(`${bars} × ploščica (≈ 40 g OH) — v prvi polovici`)
  if (bananas) items.push(`${bananas} × banana (≈ 25 g OH)`)
  if (gels) items.push(`${gels} × gel (≈ 25 g OH)${hard ? ' — v odmoru med intervali' : race || sim ? ' — po ploščicah in pred klanci' : ''}`)

  // 3) časovnica: od 30. min vsakih 20 min, ne v zadnjih 15 min; trda hrana enakomerno razporejena (ploščice prve, geli zadnji)
  const times: number[] = []
  for (let t = 30; t <= min - 15; t += 20) times.push(t)
  if (!times.length) times.push(Math.max(15, Math.round(min / 2)))
  const solids: [string, number][] = [...Array(bars).fill(['ploščica', BAR]), ...Array(bananas).fill(['banana', BAN]), ...Array(gels).fill(['gel', GEL])]
  const at = new Map<number, [string, number][]>()
  solids.forEach((x, k) => { const idx = Math.min(times.length - 1, Math.round((k * times.length) / solids.length)); at.set(idx, [...(at.get(idx) || []), x]) })
  const rate = fluidMl / Math.max(1, min)               // ml na minuto
  const empties: number[] = []
  for (let r = 0; r < Math.ceil(refills / 2); r++) empties.push(((carried + r * 2) * 750) / rate)
  const cues: FuelCue[] = times.map((t, idx) => {
    const eat = at.get(idx)
    const refill = empties.some(e => t > e - 35 && t <= e - 15) ? ' Bidona bosta kmalu prazna — na naslednjem postanku dolij.' : ''
    if (eat) {
      const what = eat.map(([n]) => n).join(' + '), g = eat.reduce((s, [, q]) => s + q, 0)
      return { atMin: t, solid: true, short: what, text: `Pojej ${what} (~${g} g OH) in popij 3–4 požirke.${refill}` }
    }
    return { atMin: t, solid: false, short: 'izotonik', text: `Popij ~⅓ bidona izotonika (~200 ml, ~${Math.round(ISO / 3.75)} g OH).${refill}` }
  })
  const food = cues.filter(c => c.solid)
  const schedule = `Pij od začetka: 3–4 požirke vsakih 10–15 min (izotonik${water ? ', vodo po žeji' : ''}).${food.length ? ` Hrana: ${food.map(c => `${hm(c.atMin)} ${c.short}`).join(', ')}.` : ''} Skupaj ~${totalCarbs} g OH in ~${l1(fluidMl)} l tekočine.`
  const perReminder = Math.max(5, Math.round(gph / 3 / 5) * 5)
  return { gph, totalCarbs, carriedCarbs, fluidMl, bottles, items, schedule, cues, everyMin: 20, firstAt: 30, perReminder }
}

/* ---------- obroki dneva ---------- */
interface Food { name: string; per: number; unit: 'g' | 'kos' | 'ml'; kcal: number; p: number; c: number; f: number }
const F: Record<string, Food> = {
  oves: { name: 'ovseni kosmiči', per: 100, unit: 'g', kcal: 370, p: 13, c: 60, f: 7 },
  jogurt: { name: 'grški jogurt 2 %', per: 100, unit: 'g', kcal: 73, p: 10, c: 4, f: 2 },
  banana: { name: 'banana', per: 1, unit: 'kos', kcal: 105, p: 1.3, c: 27, f: 0.4 },
  med: { name: 'med', per: 100, unit: 'g', kcal: 304, p: 0, c: 82, f: 0 },
  kruh: { name: 'polnozrnat kruh', per: 100, unit: 'g', kcal: 250, p: 9, c: 45, f: 3 },
  riz: { name: 'riž (suh)', per: 100, unit: 'g', kcal: 350, p: 7, c: 77, f: 1 },
  testenine: { name: 'testenine (suhe)', per: 100, unit: 'g', kcal: 355, p: 12, c: 71, f: 1.5 },
  krompir: { name: 'krompir', per: 100, unit: 'g', kcal: 77, p: 2, c: 17, f: 0.1 },
  piscanec: { name: 'piščančje prsi', per: 100, unit: 'g', kcal: 110, p: 23, c: 0, f: 1.5 },
  tuna: { name: 'tuna v lastnem soku (odcejena)', per: 100, unit: 'g', kcal: 110, p: 25, c: 0, f: 1 },
  jajce: { name: 'jajce', per: 1, unit: 'kos', kcal: 75, p: 6.5, c: 0.5, f: 5 },
  skuta: { name: 'skuta', per: 100, unit: 'g', kcal: 90, p: 12, c: 3, f: 3 },
  mleko: { name: 'mleko 1,5 %', per: 100, unit: 'ml', kcal: 47, p: 3.4, c: 4.9, f: 1.5 },
  olje: { name: 'olivno olje', per: 100, unit: 'g', kcal: 900, p: 0, c: 0, f: 100 },
  oreski: { name: 'oreški', per: 100, unit: 'g', kcal: 620, p: 20, c: 15, f: 55 },
  zelenjava: { name: 'zelenjava', per: 100, unit: 'g', kcal: 30, p: 2, c: 5, f: 0.3 },
  sadje: { name: 'sadje (jabolko, hruška)', per: 100, unit: 'g', kcal: 52, p: 0.3, c: 14, f: 0.2 },
  omaka: { name: 'paradižnikova omaka', per: 100, unit: 'g', kcal: 30, p: 1.3, c: 5, f: 0.3 },
  fizol: { name: 'fižol ali čičerika (kuhana)', per: 100, unit: 'g', kcal: 120, p: 8, c: 20, f: 1 },
}
type Tpl = [keyof typeof F, number][]
const TPL: Record<string, Tpl> = {
  zajtrk: [['oves', 70], ['jogurt', 200], ['banana', 1], ['med', 15]],
  kosilo: [['riz', 90], ['piscanec', 150], ['zelenjava', 200], ['olje', 10]],
  obnova: [['testenine', 100], ['tuna', 120], ['omaka', 150], ['olje', 5]],
  vecerja: [['krompir', 300], ['jajce', 3], ['zelenjava', 250], ['olje', 10]],
  malica: [['skuta', 250], ['sadje', 150], ['oreski', 15]],
  pred: [['kruh', 60], ['med', 20], ['banana', 1]],
  stroc: [['fizol', 250], ['kruh', 60], ['zelenjava', 200], ['olje', 10]],
}
const r10 = (x: number) => Math.max(10, Math.round(x / 10) * 10)
function scaled(tpl: Tpl, kcal: number): { text: string; kcal: number; p: number; c: number; f: number } {
  const base = tpl.reduce((s, [k, q]) => s + (F[k]!.kcal * q) / F[k]!.per, 0)
  const k = Math.max(0.5, Math.min(2, kcal / base))
  let tk = 0, tp = 0, tc = 0, tf = 0
  const parts = tpl.map(([key, q]) => {
    const f = F[key]!
    const qq = f.unit === 'kos' ? Math.max(1, Math.round(q * k)) : key === 'olje' || key === 'med' || key === 'oreski' ? Math.max(5, Math.round((q * k) / 5) * 5) : r10(q * k)
    tk += (f.kcal * qq) / f.per; tp += (f.p * qq) / f.per; tc += (f.c * qq) / f.per; tf += (f.f * qq) / f.per
    return f.unit === 'kos' ? `${qq} × ${f.name}` : `${f.name} ${qq} ${f.unit}`
  })
  return { text: parts.join(' · '), kcal: Math.round(tk), p: Math.round(tp), c: Math.round(tc), f: Math.round(tf) }
}

export interface MealSlotPlan { key: string; label: string; when: string; slot: MealEntry['slot']; kcal: number; proteinG: number; carbsG: number; example: string; exampleKcal: number; exampleP: number }
export interface DayNutrition { total: number; onBike: { carbs: number; kcal: number } | null; slots: MealSlotPlan[]; tip: string }

/**
 * Razporedi dnevni cilj na obroke. Kalorije za gorivo na kolesu se odštejejo prve (so del dnevnega cilja).
 * @param main glavna vožnja dneva (ali null, če je dan počitka / samo moč)
 */
export function dayMealPlan(p: Pick<Profile, 'weightKg' | 'trainTime'>, target: Pick<DailyTarget, 'kcal' | 'proteinG' | 'carbsG'>, main: RideLike | null): DayNutrition {
  const fuel = main ? rideFuel(main) : null
  const bike = fuel && fuel.totalCarbs ? { carbs: fuel.totalCarbs, kcal: fuel.totalCarbs * 4 } : null
  const rest = Math.max(0, target.kcal - (bike?.kcal || 0))
  const ride = !!main && (main.kind === 'kolo' || main.kind === 'test') && (main.durationMin || 0) >= 45
  const t = p.trainTime || 'popoldne'
  type S = [string, string, string, MealEntry['slot'], number, keyof typeof TPL]
  const plan: S[] = !ride
    ? [['zajtrk', 'Zajtrk', 'zjutraj', 'zajtrk', 0.25, 'zajtrk'], ['kosilo', 'Kosilo', 'opoldne', 'kosilo', 0.35, 'kosilo'], ['malica', 'Malica', 'popoldne', 'malica', 0.12, 'malica'], ['vecerja', 'Večerja', 'zvečer', 'vecerja', 0.28, 'vecerja']]
    : t === 'zjutraj'
    ? [['pred', 'Pred vožnjo', '45–60 min prej, lahko', 'zajtrk', 0.12, 'pred'], ['obnova', 'Po vožnji — zajtrk', 'v 45 min po vožnji', 'zajtrk', 0.3, 'zajtrk'], ['kosilo', 'Kosilo', 'opoldne', 'kosilo', 0.3, 'kosilo'], ['vecerja', 'Večerja', 'zvečer', 'vecerja', 0.28, 'stroc']]
    : t === 'zvecer'
    ? [['zajtrk', 'Zajtrk', 'zjutraj', 'zajtrk', 0.25, 'zajtrk'], ['kosilo', 'Kosilo', 'opoldne', 'kosilo', 0.3, 'kosilo'], ['pred', 'Malica pred vožnjo', '1–2 h prej', 'malica', 0.15, 'pred'], ['obnova', 'Po vožnji — večerja', 'v 45 min po vožnji', 'vecerja', 0.3, 'obnova']]
    : [['zajtrk', 'Zajtrk', 'zjutraj', 'zajtrk', 0.26, 'zajtrk'], ['kosilo', 'Kosilo', '2–3 h pred vožnjo', 'kosilo', 0.3, 'kosilo'], ['obnova', 'Po vožnji — večerja', 'v 45 min po vožnji', 'vecerja', 0.28, 'obnova'], ['malica', 'Zvečer', 'pred spanjem', 'drugo', 0.16, 'malica']]
  const protSlots = plan.filter(s => s[0] !== 'pred').length
  const slots: MealSlotPlan[] = plan.map(([key, label, when, slot, share, tpl]) => {
    const kcal = Math.round((rest * share) / 10) * 10
    const proteinG = key === 'pred' ? 10 : Math.round(target.proteinG / protSlots)
    const carbsG = Math.round(((kcal - proteinG * 4) * (key === 'pred' || key === 'obnova' ? 0.75 : 0.5)) / 4)
    const ex = scaled(TPL[tpl]!, kcal)
    return { key, label, when, slot, kcal, proteinG, carbsG, example: ex.text, exampleKcal: ex.kcal, exampleP: ex.p }
  })
  const tip = !ride
    ? 'Dan brez vožnje: manj ogljikovih hidratov (manj riža, testenin, kruha), več zelenjave in beljakovin. Beljakovine razdeli na 4 obroke.'
    : `Ogljikovi hidrati okoli vožnje: kosilo ${t === 'zjutraj' ? 'in zajtrk po vožnji' : 'pred vožnjo in obrok po njej'} naj bosta bogata z OH. Deficit ustvariš pri ostalih obrokih, nikoli na kolesu.`
  return { total: target.kcal, onBike: bike, slots, tip }
}
