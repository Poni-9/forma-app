import type { MealEntry, PlanDay, Profile } from '../types'
import type { DailyTarget } from './energy'

/**
 * VODENJE PREHRANE — kaj in koliko jesti danes, razporejeno okoli treninga, in koliko na kolesu.
 * Deterministično (brez AI): dnevni cilj iz energy.ts se razdeli na obroke; vsak obrok ima kcal, beljakovine,
 * ogljikove hidrate in primer s količinami iz navadne slovenske trgovine.
 * Na kolesu: ogljikovi hidrati na uro po vrsti vožnje (ISSN: 30–60 g/h, na dolgih in dirki do 90 g/h),
 * tekočina po temperaturi (~350 ml/h v hladnem do ~850 ml/h v vročini, ACSM: 0,4–0,8 l/h, prilagodi po sebi)
 * in po tem, koliko si dejansko spil na zadnjih vožnjah; začetek po ~30 min, nato vsakih ~20 min.
 */

/* ---------- gorivo na kolesu ---------- */
/** opomnik med vožnjo: v minuti atMin — kaj pojesti ali popiti */
export interface FuelCue { atMin: number; text: string; solid: boolean; short: string }
export interface RideFuel {
  /** ogljikovi hidrati na uro */
  gph: number
  /** skupaj za vožnjo */
  totalCarbs: number
  /** koliko OH je v stvareh, ki jih vzameš s seboj (≈ totalCarbs, zaokroženo navzgor na cele kose) */
  carriedCarbs: number
  fluidMl: number
  bottles: number
  /** kaj vzeti s seboj */
  items: string[]
  /** kdaj jesti in piti */
  schedule: string
  /** časovnica opomnikov med vožnjo */
  cues: FuelCue[]
  /** vsakih koliko minut opomnik (0 = brez) */
  everyMin: number
  /** prvič po minutah */
  firstAt: number
  /** gramov OH na 20 minut (ritem) */
  perReminder: number
  /** kaj vzeti — po kosih (za vpis, koliko si res porabil) */
  plan: FuelPlanItem[]
  /** tekočina na uro in zakaj (temperatura, tvoje zadnje vožnje) */
  fluidNote: string
}
export interface FuelPlanItem { key: FuelKey | 'voda'; name: string; n: number; carbs: number; kcal: number; ml: number }
/** Okoliščine vožnje: temperatura v oknu treninga in koliko piješ ti (iz vpisov po vožnjah). */
export interface FuelCtx { tempC?: number | null; fluidFactor?: number | null }

type RideLike = Pick<PlanDay, 'kind' | 'durationMin' | 'zone'> & { role?: PlanDay['role']; title?: string }

/* ---------- kaj imaš za na kolo: konkretne stvari iz slovenske trgovine, z OH na kos ---------- */
export type FuelKey = 'iso_domaci' | 'iso_kupljen' | 'frutabela' | 'ploscica' | 'gel' | 'banana' | 'dateljni' | 'sendvic' | 'rizevi'
/** name: v stavku (»2 × bidon domačega izotonika«) · label: kratko ime za izbiro (»domači izotonik«) */
export interface FuelItem { key: FuelKey; name: string; label: string; carbs: number; kcal: number; kind: 'drink' | 'solid' | 'gel'; desc: string }
export const FUEL_ITEMS: FuelItem[] = [
  { key: 'iso_domaci', name: 'bidon domačega izotonika', label: 'domači izotonik', carbs: 40, kcal: 160, kind: 'drink', desc: '750 ml vode + 40 g sladkorja ali maltodekstrina + ščep soli ≈ 40 g OH' },
  { key: 'iso_kupljen', name: 'bidon kupljenega izotonika', label: 'kupljen izotonik', carbs: 45, kcal: 180, kind: 'drink', desc: 'Isostar, Powerade ipd. — 750 ml ≈ 45 g OH' },
  { key: 'frutabela', name: 'Frutabela', label: 'Frutabela', carbs: 19, kcal: 100, kind: 'solid', desc: 'sadna ploščica 30 g ≈ 19 g OH' },
  { key: 'ploscica', name: 'energijska ploščica', label: 'energijska ploščica', carbs: 40, kcal: 200, kind: 'solid', desc: 'PowerBar, Enervit ipd. ≈ 40 g OH' },
  { key: 'banana', name: 'banana', label: 'banana', carbs: 25, kcal: 105, kind: 'solid', desc: '≈ 25 g OH' },
  { key: 'dateljni', name: 'pest datljev', label: 'datlji', carbs: 30, kcal: 125, kind: 'solid', desc: '4–5 datljev ≈ 30 g OH' },
  { key: 'sendvic', name: 'sendvič z marmelado', label: 'sendvič', carbs: 45, kcal: 250, kind: 'solid', desc: '2 rezini kruha + marmelada ali med ≈ 45 g OH' },
  { key: 'rizevi', name: 'riževi kolački', label: 'riževi kolački', carbs: 30, kcal: 150, kind: 'solid', desc: 'domači, kos ≈ 30 g OH' },
  { key: 'gel', name: 'gel', label: 'gel', carbs: 25, kcal: 100, kind: 'gel', desc: '≈ 25 g OH' },
]
export const DEFAULT_KIT: FuelKey[] = ['iso_domaci', 'frutabela', 'banana', 'gel']
const ITEM = Object.fromEntries(FUEL_ITEMS.map(i => [i.key, i])) as Record<FuelKey, FuelItem>
/** vrstni red trde hrane po vrsti vožnje (kar imaš, v tem vrstnem redu) */
const ORDER: Record<'hard' | 'race' | 'long' | 'easy', FuelKey[]> = {
  hard: ['gel', 'frutabela', 'banana', 'dateljni', 'ploscica', 'rizevi', 'sendvic'],
  race: ['ploscica', 'sendvic', 'rizevi', 'frutabela', 'gel', 'banana', 'dateljni'],
  long: ['sendvic', 'rizevi', 'ploscica', 'frutabela', 'banana', 'dateljni', 'gel'],
  easy: ['banana', 'frutabela', 'dateljni', 'rizevi', 'sendvic', 'ploscica', 'gel'],
}
const l1 = (ml: number) => (ml / 1000).toFixed(1).replace('.', ',')
const hm = (m: number) => `${Math.floor(m / 60)}:${String(m % 60).padStart(2, '0')}`

/** Tekočina na uro po temperaturi v oknu treninga (brez napovedi: ~20 °C). Trdi treningi +50 ml. */
export function fluidPerHour(tempC: number | null | undefined, hard: boolean): number {
  const t = tempC ?? 20
  const base = t < 12 ? 350 : t < 18 ? 450 : t < 23 ? 550 : t < 28 ? 700 : 850
  return base + (hard ? 50 : 0)
}
/**
 * Koliko piješ ti: razmerje popito / predlagano na zadnjih vožnjah (vpis »Na kolesu«, zadnjih 60 dni, do 6).
 * Ena vožnja šteje pol; meje 0,7–1,15 — tudi če piješ malo, v vročini ne gre pod 70 % priporočila.
 */
export function fluidFactorOf(meals: readonly MealEntry[], today?: string): { f: number; n: number } {
  const from = today ? new Date(new Date(today).getTime() - 60 * 86400_000).toISOString().slice(0, 10) : ''
  const rs = meals.filter(m => m.slot === 'med_vadbo' && (m.planMl || 0) >= 300 && m.fluidMl != null && m.date >= from)
    .sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6).map(m => m.fluidMl! / m.planMl!).sort((a, b) => a - b)
  if (!rs.length) return { f: 1, n: 0 }
  const med = rs.length % 2 ? rs[(rs.length - 1) / 2]! : (rs[rs.length / 2 - 1]! + rs[rs.length / 2]!) / 2
  const f = rs.length === 1 ? (1 + med) / 2 : med
  return { f: +Math.max(0.7, Math.min(1.15, f)).toFixed(2), n: rs.length }
}

/**
 * Gorivo za vožnjo. Vse se sešteje: bidoni z domačim izotonikom (40 g OH na 750 ml) + trda hrana in geli = skupaj.
 * Časovnica: od 30. minute vsakih 20 min opomnik (ne v zadnjih 15 min); trda hrana razporejena enakomerno,
 * vmes požirki izotonika; opomnik za dolivanje, ko bidona zmanjka.
 */
export function rideFuel(d: RideLike | null, kitIn?: readonly string[] | null, ctx: FuelCtx = {}): RideFuel | null {
  if (!d || (d.kind !== 'kolo' && d.kind !== 'test')) return null
  const kit = new Set<FuelKey>(((kitIn && kitIn.length ? kitIn : DEFAULT_KIT) as FuelKey[]).filter(k => k in ITEM))
  const drink = kit.has('iso_domaci') ? ITEM.iso_domaci : kit.has('iso_kupljen') ? ITEM.iso_kupljen : null
  const ISO = drink ? drink.carbs : 0
  const min = d.durationMin || 0
  const hours = min / 60
  const race = d.role === 'dirka'
  const sim = /Simulacija/i.test(d.title || '')   // generalka za dirko: vadiš dirkalno gorivo
  const hard = d.role === 'kljucna' || d.role === 'test' || /Z[4-5]|test/.test(d.zone || '')
  let gph = 0
  if (race) gph = 85
  else if (d.role === 'regen' || min < 60) gph = 0
  else if (hard) gph = min >= 75 ? 70 : 40
  else if (sim) gph = 80
  else if (d.role === 'dolga') gph = min >= 150 ? 60 : 50
  else gph = min >= 90 ? 40 : 0
  const totalCarbs = gph ? Math.round((gph * Math.max(0, hours - 0.5)) / 5) * 5 : 0
  // tekočina: po temperaturi in po tem, koliko dejansko spiješ (ni vroče → manj; ne siliti v 1,5 l, ki ga ne spiješ)
  const perH = fluidPerHour(ctx.tempC, hard || race), ff = ctx.fluidFactor ?? 1
  const fluidMl = Math.max(400, Math.round((hours * perH * ff) / 50) * 50)
  const fluidNote = `~${Math.round((perH * ff) / 50) * 50} ml na uro pri ${ctx.tempC != null ? `${Math.round(ctx.tempC)} °C` : '~20 °C'}${Math.abs(ff - 1) >= 0.05 ? ', prilagojeno temu, koliko spiješ ti' : ''}`
  const bottles = Math.max(1, Math.ceil(fluidMl / 750))
  const carried = Math.min(2, bottles)
  const refills = bottles - carried
  if (!totalCarbs) {
    const items = [`${carried} × bidon vode (skupaj ~${fluidMl} ml${refills ? ', dolij na postanku' : ''})${min >= 60 ? ' — ob vročini z elektroliti' : ''}`]
    return { gph, totalCarbs, carriedCarbs: 0, fluidMl, bottles, items, schedule: min < 60 ? 'Samo voda.' : 'Voda po žeji, na kolesu ne jej — seja je lahka ali kratka.', cues: [], everyMin: 0, firstAt: 0, perReminder: 0, plan: [{ key: 'voda', name: 'bidon vode', n: carried, carbs: 0, kcal: 0, ml: 750 }], fluidNote }
  }

  // 1) bidoni: celi bidoni izotonika (če ga imaš), a le toliko, kolikor jih res spiješ, in ne več OH, kot jih rabiš (+10 g);
  //    ostali bidoni voda, manjkajoči OH gredo v trdo hrano in gele
  const drinkable = Math.max(1, Math.floor(fluidMl / 750 + 0.25))
  const iso = drink ? Math.min(drinkable, bottles, Math.max(1, Math.floor((totalCarbs + 10) / ISO))) : 0
  const isoCarried = Math.min(iso, carried), isoRefill = iso - isoCarried
  const water = carried - isoCarried
  // 2) ostanek s trdo hrano iz tvojega kompleta: dolge = prava hrana najprej, lahke = banane/Frutabela, intervali in dirka = geli
  let rest = totalCarbs - iso * ISO
  const long = min >= 150
  const order = ORDER[hard ? 'hard' : race || sim ? 'race' : long ? 'long' : 'easy'].filter(k => kit.has(k))
  const solidsList = order.length ? order : (['gel'] as FuelKey[])
  const count = new Map<FuelKey, number>()
  const capOf = (k: FuelKey) => (ITEM[k].kind === 'gel' ? 6 : k === 'sendvic' || k === 'rizevi' || k === 'ploscica' ? 2 : 3)
  let guard = 0
  while (rest > 10 && guard++ < 30) {
    // najprej večji kosi, dokler je prostora; potem manjši; nazadnje karkoli
    const pick = solidsList.find(k => (count.get(k) || 0) < capOf(k) && rest >= ITEM[k].carbs * 0.6) || solidsList.find(k => (count.get(k) || 0) < capOf(k)) || solidsList[0]!
    count.set(pick, (count.get(pick) || 0) + 1); rest -= ITEM[pick].carbs
  }
  const solidCarbs = [...count.entries()].reduce((s, [k, n]) => s + n * ITEM[k].carbs, 0)
  const carriedCarbs = iso * ISO + solidCarbs

  const items: string[] = []
  if (isoCarried) items.push(`${isoCarried} × ${drink!.name} (${drink!.desc})`)
  if (water) items.push(`${water} × bidon vode${!drink ? ' (izotonika nimaš v kompletu — OH so v hrani)' : ''}`)
  if (refills) items.push(`za dolivanje na postanku${isoRefill ? (drink!.key === 'iso_domaci' ? `: ${isoRefill} × vrečka s 40 g sladkorja/maltodekstrina in ščepom soli` : `: ${isoRefill} × 750 ml izotonika (kupi ali vzemi s seboj)`) : ' (voda)'}`)
  const bars = 0, bananas = count.get('banana') || 0, gels = count.get('gel') || 0
  for (const k of solidsList) {
    const n = count.get(k) || 0
    if (!n) continue
    const it = ITEM[k]
    const when = it.kind === 'gel' ? (hard ? ' — v odmoru med intervali' : race || sim ? ' — pred klanci' : '') : long && it.carbs >= 30 ? ' — v prvi polovici' : ''
    items.push(`${n} × ${it.name} (${it.desc}${n > 1 ? ', vsak' : ''})${when}`)
  }
  void bars; void bananas; void gels

  // 3) časovnica: od 30. min vsakih 20 min, ne v zadnjih 15 min; trda hrana enakomerno razporejena (ploščice prve, geli zadnji)
  const times: number[] = []
  for (let t = 30; t <= min - 15; t += 20) times.push(t)
  if (!times.length) times.push(Math.max(15, Math.round(min / 2)))
  const solids: [string, number][] = solidsList.flatMap(k => Array.from({ length: count.get(k) || 0 }, () => [ITEM[k].name, ITEM[k].carbs] as [string, number]))
  const at = new Map<number, [string, number][]>()
  solids.forEach((x, k) => { const idx = Math.min(times.length - 1, Math.round((k * times.length) / solids.length)); at.set(idx, [...(at.get(idx) || []), x]) })
  const rate = fluidMl / Math.max(1, min)               // ml na minuto
  const empties: number[] = []
  for (let r = 0; r < Math.ceil(refills / 2); r++) empties.push(((carried + r * 2) * 750) / rate)
  const cues: FuelCue[] = times.map((t, idx) => {
    const eat = at.get(idx)
    const refill = empties.some(e => t > e - 35 && t <= e - 15) ? ' Bidona bosta kmalu prazna — na naslednjem postanku dolij.' : ''
    if (eat) {
      const what = eat.map(([n]) => n).join(' + '), g = eat.reduce((s, [, q]) => s + q, 0)
      return { atMin: t, solid: true, short: what, text: `Pojej ${what} (~${g} g OH) in popij 3–4 požirke.${refill}` }
    }
    return drink
      ? { atMin: t, solid: false, short: 'izotonik', text: `Popij ~⅓ bidona izotonika (~200 ml, ~${Math.round(ISO / 3.75)} g OH).${refill}` }
      : { atMin: t, solid: false, short: 'voda', text: `Popij 3–4 požirke vode.${refill}` }
  })
  const food = cues.filter(c => c.solid)
  const schedule = `Pij od začetka: 3–4 požirke vsakih 10–15 min (${drink ? `izotonik${water ? ', vodo po žeji' : ''}` : 'voda'}).${food.length ? ` Hrana: ${food.map(c => `${hm(c.atMin)} ${c.short}`).join(', ')}.` : ''} Skupaj ~${totalCarbs} g OH in ~${l1(fluidMl)} l tekočine — ${fluidNote}.`
  const perReminder = Math.max(5, Math.round(gph / 3 / 5) * 5)
  const plan: FuelPlanItem[] = []
  if (iso) plan.push({ key: drink!.key, name: drink!.name, n: iso, carbs: drink!.carbs, kcal: drink!.kcal, ml: 750 })
  // voda: kolikor je predvidoma spiješ ob izotoniku (po pol bidona), ne kolikor bidonov neseš
  const waterN = water ? Math.max(0.5, Math.round(((fluidMl - iso * 750) / 750) * 2) / 2) : !iso && carried ? carried : 0
  if (waterN) plan.push({ key: 'voda', name: 'bidon vode', n: waterN, carbs: 0, kcal: 0, ml: 750 })
  for (const k of solidsList) { const n = count.get(k) || 0; if (n) plan.push({ key: k, name: ITEM[k].name, n, carbs: ITEM[k].carbs, kcal: ITEM[k].kcal, ml: 0 }) }
  return { gph, totalCarbs, carriedCarbs, fluidMl, bottles, items, schedule, cues, everyMin: 20, firstAt: 30, perReminder, plan, fluidNote }
}

/**
 * Vpis »Na kolesu«: koliko si res popil in pojedel (kosi, bidoni po pol) → obrok, ki šteje v dnevne kalorije,
 * in podatek za prihodnjo tekočino (popito / predlagano).
 */
/** Kaj lahko vpišeš po vožnji: najprej načrtovano, nato ostalo iz kompleta (npr. Frutabela namesto gela) in voda. */
export function fuelChoices(rf: Pick<RideFuel, 'plan'>, kit?: readonly string[] | null): FuelPlanItem[] {
  const out = [...rf.plan]
  const have = new Set(out.map(x => x.key))
  const extra = FUEL_ITEMS.filter(i => !have.has(i.key) && (!kit || !kit.length || kit.includes(i.key)))
  for (const i of extra) out.push({ key: i.key, name: i.name, n: 0, carbs: i.carbs, kcal: i.kcal, ml: i.kind === 'drink' ? 750 : 0 })
  if (!have.has('voda')) out.push({ key: 'voda', name: 'bidon vode', n: 0, carbs: 0, kcal: 0, ml: 750 })
  return out
}

/** Okoliščine za gorivo na dan: temperatura v oknu treninga in koliko običajno spiješ. */
export function fuelCtxOf(weather: Record<string, { tmax: number }> | null | undefined, meals: readonly MealEntry[], date: string, today: string): FuelCtx {
  return { tempC: weather?.[date]?.tmax ?? null, fluidFactor: fluidFactorOf(meals, today).f }
}

export function fuelEntry(rf: Pick<RideFuel, 'plan' | 'fluidMl'>, got: Record<string, number>, title: string): { name: string; kcal: number; carbsG: number; fluidMl: number; planMl: number } {
  const bits: string[] = []
  let kcal = 0, carbs = 0, ml = 0
  for (const it of fuelChoices(rf)) {
    const n = Math.max(0, got[it.key] ?? 0)
    if (!n) continue
    kcal += n * it.kcal; carbs += n * it.carbs; ml += n * it.ml
    bits.push(`${String(n).replace('.', ',')} × ${it.name}`)
  }
  return { name: bits.length ? `Na kolesu (${title}): ${bits.join(', ')}` : `Na kolesu (${title}): nič`, kcal: Math.round(kcal), carbsG: Math.round(carbs), fluidMl: Math.round(ml), planMl: rf.fluidMl }
}

/* ---------- obroki dneva ---------- */
interface Food { name: string; per: number; unit: 'g' | 'kos' | 'ml'; kcal: number; p: number; c: number; f: number }
const F: Record<string, Food> = {
  oves: { name: 'ovseni kosmiči', per: 100, unit: 'g', kcal: 370, p: 13, c: 60, f: 7 },
  jogurt: { name: 'grški jogurt 2 %', per: 100, unit: 'g', kcal: 73, p: 10, c: 4, f: 2 },
  banana: { name: 'banana', per: 1, unit: 'kos', kcal: 105, p: 1.3, c: 27, f: 0.4 },
  med: { name: 'med', per: 100, unit: 'g', kcal: 304, p: 0, c: 82, f: 0 },
  kruh: { name: 'polnozrnat kruh', per: 100, unit: 'g', kcal: 250, p: 9, c: 45, f: 3 },
  riz: { name: 'riž (suh)', per: 100, unit: 'g', kcal: 350, p: 7, c: 77, f: 1 },
  testenine: { name: 'testenine (suhe)', per: 100, unit: 'g', kcal: 355, p: 12, c: 71, f: 1.5 },
  krompir: { name: 'krompir', per: 100, unit: 'g', kcal: 77, p: 2, c: 17, f: 0.1 },
  piscanec: { name: 'piščančje prsi', per: 100, unit: 'g', kcal: 110, p: 23, c: 0, f: 1.5 },
  tuna: { name: 'tuna v lastnem soku (odcejena)', per: 100, unit: 'g', kcal: 110, p: 25, c: 0, f: 1 },
  jajce: { name: 'jajce', per: 1, unit: 'kos', kcal: 75, p: 6.5, c: 0.5, f: 5 },
  skuta: { name: 'skuta', per: 100, unit: 'g', kcal: 90, p: 12, c: 3, f: 3 },
  mleko: { name: 'mleko 1,5 %', per: 100, unit: 'ml', kcal: 47, p: 3.4, c: 4.9, f: 1.5 },
  olje: { name: 'olivno olje', per: 100, unit: 'g', kcal: 900, p: 0, c: 0, f: 100 },
  oreski: { name: 'oreški', per: 100, unit: 'g', kcal: 620, p: 20, c: 15, f: 55 },
  zelenjava: { name: 'zelenjava', per: 100, unit: 'g', kcal: 30, p: 2, c: 5, f: 0.3 },
  sadje: { name: 'sadje (jabolko, hruška)', per: 100, unit: 'g', kcal: 52, p: 0.3, c: 14, f: 0.2 },
  omaka: { name: 'paradižnikova omaka', per: 100, unit: 'g', kcal: 30, p: 1.3, c: 5, f: 0.3 },
  fizol: { name: 'fižol ali čičerika (kuhana)', per: 100, unit: 'g', kcal: 120, p: 8, c: 20, f: 1 },
}
type Tpl = [keyof typeof F, number][]
const TPL: Record<string, Tpl> = {
  zajtrk: [['oves', 70], ['jogurt', 200], ['banana', 1], ['med', 15]],
  kosilo: [['riz', 90], ['piscanec', 150], ['zelenjava', 200], ['olje', 10]],
  obnova: [['testenine', 100], ['tuna', 120], ['omaka', 150], ['olje', 5]],
  vecerja: [['krompir', 300], ['jajce', 3], ['zelenjava', 250], ['olje', 10]],
  malica: [['skuta', 250], ['sadje', 150], ['oreski', 15]],
  pred: [['kruh', 60], ['med', 20], ['banana', 1]],
  stroc: [['fizol', 250], ['kruh', 60], ['zelenjava', 200], ['olje', 10]],
}
const r10 = (x: number) => Math.max(10, Math.round(x / 10) * 10)
function scaled(tpl: Tpl, kcal: number): { text: string; kcal: number; p: number; c: number; f: number } {
  const base = tpl.reduce((s, [k, q]) => s + (F[k]!.kcal * q) / F[k]!.per, 0)
  const k = Math.max(0.5, Math.min(2, kcal / base))
  let tk = 0, tp = 0, tc = 0, tf = 0
  const parts = tpl.map(([key, q]) => {
    const f = F[key]!
    const qq = f.unit === 'kos' ? Math.max(1, Math.round(q * k)) : key === 'olje' || key === 'med' || key === 'oreski' ? Math.max(5, Math.round((q * k) / 5) * 5) : r10(q * k)
    tk += (f.kcal * qq) / f.per; tp += (f.p * qq) / f.per; tc += (f.c * qq) / f.per; tf += (f.f * qq) / f.per
    return f.unit === 'kos' ? `${qq} × ${f.name}` : `${f.name} ${qq} ${f.unit}`
  })
  return { text: parts.join(' · '), kcal: Math.round(tk), p: Math.round(tp), c: Math.round(tc), f: Math.round(tf) }
}

export interface MealSlotPlan { key: string; label: string; when: string; slot: MealEntry['slot']; kcal: number; proteinG: number; carbsG: number; example: string; exampleKcal: number; exampleP: number; tpl?: string; /** koliko je že pojedeno (po prilagoditvi čez dan) */ got?: number }
export interface DayNutrition { total: number; onBike: { carbs: number; kcal: number } | null; slots: MealSlotPlan[]; tip: string; /** preostali obroki so prilagojeni pojedenemu */ adjusted?: boolean; /** tudi z večjimi obroki ne pride do cilja (strop 1,35 ×) */ short?: number }

/**
 * Razporedi dnevni cilj na obroke. Kalorije za gorivo na kolesu se odštejejo prve (so del dnevnega cilja).
 * @param main glavna vožnja dneva (ali null, če je dan počitka / samo moč)
 */
export function dayMealPlan(p: Pick<Profile, 'weightKg' | 'trainTime'> & { fuelKit?: string[] | null }, target: Pick<DailyTarget, 'kcal' | 'proteinG' | 'carbsG'>, main: RideLike | null, ctx: FuelCtx = {}): DayNutrition {
  const fuel = main ? rideFuel(main, p.fuelKit, ctx) : null
  const bike = fuel && fuel.totalCarbs ? { carbs: fuel.totalCarbs, kcal: fuel.totalCarbs * 4 } : null
  const rest = Math.max(0, target.kcal - (bike?.kcal || 0))
  const ride = !!main && (main.kind === 'kolo' || main.kind === 'test') && (main.durationMin || 0) >= 45
  const t = p.trainTime || 'popoldne'
  type S = [string, string, string, MealEntry['slot'], number, keyof typeof TPL]
  const plan: S[] = !ride
    ? [['zajtrk', 'Zajtrk', 'zjutraj', 'zajtrk', 0.25, 'zajtrk'], ['kosilo', 'Kosilo', 'opoldne', 'kosilo', 0.35, 'kosilo'], ['malica', 'Malica', 'popoldne', 'malica', 0.12, 'malica'], ['vecerja', 'Večerja', 'zvečer', 'vecerja', 0.28, 'vecerja']]
    : t === 'zjutraj'
    ? [['pred', 'Pred vožnjo', '45–60 min prej, lahko', 'zajtrk', 0.12, 'pred'], ['obnova', 'Po vožnji — zajtrk', 'v 45 min po vožnji', 'zajtrk', 0.3, 'zajtrk'], ['kosilo', 'Kosilo', 'opoldne', 'kosilo', 0.3, 'kosilo'], ['vecerja', 'Večerja', 'zvečer', 'vecerja', 0.28, 'stroc']]
    : t === 'zvecer'
    ? [['zajtrk', 'Zajtrk', 'zjutraj', 'zajtrk', 0.25, 'zajtrk'], ['kosilo', 'Kosilo', 'opoldne', 'kosilo', 0.3, 'kosilo'], ['pred', 'Malica pred vožnjo', '1–2 h prej', 'malica', 0.15, 'pred'], ['obnova', 'Po vožnji — večerja', 'v 45 min po vožnji', 'vecerja', 0.3, 'obnova']]
    : [['zajtrk', 'Zajtrk', 'zjutraj', 'zajtrk', 0.26, 'zajtrk'], ['kosilo', 'Kosilo', '2–3 h pred vožnjo', 'kosilo', 0.3, 'kosilo'], ['obnova', 'Po vožnji — večerja', 'v 45 min po vožnji', 'vecerja', 0.28, 'obnova'], ['malica', 'Zvečer', 'pred spanjem', 'drugo', 0.16, 'malica']]
  const protSlots = plan.filter(s => s[0] !== 'pred').length
  const slots: MealSlotPlan[] = plan.map(([key, label, when, slot, share, tpl]) => {
    const kcal = Math.round((rest * share) / 10) * 10
    const proteinG = key === 'pred' ? 10 : Math.round(target.proteinG / protSlots)
    const carbsG = Math.round(((kcal - proteinG * 4) * (key === 'pred' || key === 'obnova' ? 0.75 : 0.5)) / 4)
    const ex = scaled(TPL[tpl]!, kcal)
    return { key, label, when, slot, kcal, proteinG, carbsG, example: ex.text, exampleKcal: ex.kcal, exampleP: ex.p, tpl }
  })
  const tip = !ride
    ? 'Dan brez vožnje: manj ogljikovih hidratov (manj riža, testenin, kruha), več zelenjave in beljakovin. Beljakovine razdeli na 4 obroke.'
    : `Ogljikovi hidrati okoli vožnje: kosilo ${t === 'zjutraj' ? 'in zajtrk po vožnji' : 'pred vožnjo in obrok po njej'} naj bosta bogata z OH. Deficit ustvariš pri ostalih obrokih, nikoli na kolesu.`
  return { total: target.kcal, onBike: bike, slots, tip }
}

/**
 * Čez dan: pojedeni obroki ostanejo, kot so; preostali se sorazmerno prilagodijo, da skupaj z gorivom na kolesu
 * pridejo do cilja — največ 1,35 × prvotnega (dvojna večerja ni rešitev; kar manjka, pove `short`).
 * Gorivo na kolesu: vpisano (»Med vožnjo«) namesto načrtovanega. Beljakovine ostanejo po načrtu.
 */
export function adjustToEaten(dp: DayNutrition, meals: readonly MealEntry[], target: number): DayNutrition {
  const bike = meals.filter(m => m.slot === 'med_vadbo')
  const bikeKcal = bike.length ? bike.reduce((s, m) => s + m.kcal, 0) : (dp.onBike?.kcal || 0)
  const eatenAll = meals.filter(m => m.slot !== 'med_vadbo').reduce((s, m) => s + m.kcal, 0)
  // pojedeno razdeli na načrtovane obroke istega termina (zajtrk je lahko »pred vožnjo« in »po vožnji«)
  const got = new Map<string, number>()
  for (const sl of [...new Set(dp.slots.map(x => x.slot))]) {
    let left = meals.filter(m => m.slot === sl).reduce((s, m) => s + m.kcal, 0)
    const own = dp.slots.filter(x => x.slot === sl)
    own.forEach((x, i) => { const g = i === own.length - 1 ? left : Math.min(left, x.kcal); got.set(x.key, g); left -= g })
  }
  const open = dp.slots.filter(x => !(got.get(x.key)! > 0))
  const planned = open.reduce((s, x) => s + x.kcal, 0)
  if (!planned || open.length === dp.slots.length && !bike.length) return { ...dp, slots: dp.slots.map(x => ({ ...x, got: got.get(x.key) || 0 })) }
  const remaining = target - bikeKcal - eatenAll
  const f = Math.max(0, Math.min(1.35, remaining / planned))
  const slots = dp.slots.map(x => {
    if (!open.includes(x)) return { ...x, got: got.get(x.key) || 0 }
    const kcal = Math.round((x.kcal * f) / 10) * 10
    if (Math.abs(kcal - x.kcal) < 20) return { ...x, got: 0 }
    const carbsG = Math.max(0, Math.round(((kcal - x.proteinG * 4) * (x.key === 'pred' || x.key === 'obnova' ? 0.75 : 0.5)) / 4))
    const ex = x.tpl && TPL[x.tpl] && kcal >= 150 ? scaled(TPL[x.tpl]!, kcal) : null
    return { ...x, kcal, carbsG, got: 0, ...(ex ? { example: ex.text, exampleKcal: ex.kcal, exampleP: ex.p } : kcal < 150 ? { example: 'lahko kaj majhnega z beljakovinami (jogurt, skuta) ali nič' } : {}) }
  })
  const newOpen = slots.filter(x => open.some(o => o.key === x.key)).reduce((s, x) => s + x.kcal, 0)
  const short = Math.max(0, Math.round((remaining - newOpen) / 10) * 10)
  return { ...dp, slots, adjusted: slots.some((x, i) => x.kcal !== dp.slots[i]!.kcal), short: short >= 150 ? short : 0 }
}

