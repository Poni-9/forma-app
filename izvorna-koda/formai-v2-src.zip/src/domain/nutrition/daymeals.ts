import type { Activity, MealEntry, PlanDay, Profile, Settings } from '../types'
import type { DailyTarget } from './energy'
import { adjustToEaten, dayMealPlan, fuelCtxOf, gotBySlot, type DayNutrition, type MealSlotPlan } from './dayplan'
import { raceSoon } from './race'
import { dayRecipes, type Recipe, type RecipeCtx } from './recipes'

/**
 * Obroki dneva na enem mestu — Danes (naslednji obrok) in Prehrana (cel dan) računata isto:
 * glavna vožnja dneva, ali je za nami, obroki prilagojeni pojedenemu (danes), recept za obrok (AI za ta dan, če obrok
 * ni bistveno drugačen od takrat, sicer knjižnica po pravilih).
 */
export interface DayMealsIn {
  p: Profile; target: DailyTarget; plan: readonly PlanDay[]; activities: readonly Activity[]; meals: readonly MealEntry[]
  recentMeals: readonly MealEntry[]; weather: Record<string, { tmax: number }> | null | undefined; day: string; today: string
}
export interface DayMeals { dp: DayNutrition; main: PlanDay | null; rideDone: boolean; workout: boolean; training: boolean }

export function dayMealsOf(x: DayMealsIn): DayMeals {
  const { p, target, plan, activities, meals, day, today } = x
  const main0 = plan.filter(d => d.date === day && (d.kind === 'kolo' || d.kind === 'test') && !d.optional).sort((a, b) => b.durationMin - a.durationMin)[0] || null
  const workout = plan.some(d => d.date === day && d.kind !== 'pocitek' && d.kind !== 'kolo' && d.kind !== 'test' && !d.optional)
  const training = plan.some(d => d.date === day && d.kind !== 'pocitek' && !d.optional)
  // vožnja je za nami (označena ali pripeljana z ure): nevpisano gorivo na kolesu šteje 0, ne »po načrtu«
  const rideDone = !!main0 && (!!main0.done || activities.some(a => a.date === day && a.sport === 'kolo' && (a.durationMin || 0) >= main0.durationMin * 0.5))
  // (v3.48) vožnje ni bilo in ne šteje več (pozno zvečer, dan mimo): obroki kot dan brez vožnje — brez goriva in »po vožnji«
  const main = main0 && !rideDone && (target.plannedDropped || 0) > 0 && !target.plannedBurn ? null : main0
  const dp0 = dayMealPlan(p, target, main, { ...fuelCtxOf(x.weather, x.recentMeals, day, today), race: raceSoon(p, day), workout })
  // pretekli dan: pojedeno razdeljeno po obrokih kot danes (v3.48 — dva obroka istega termina ne štejeta istega dvakrat)
  const got = day === today ? null : gotBySlot(dp0, meals)
  const dp = day === today ? adjustToEaten(dp0, meals, target.kcal, { rideDone, weightKg: p.weightKg }) : { ...dp0, slots: dp0.slots.map(s => ({ ...s, got: got!.get(s.key) || 0 })) }
  return { dp, main, rideDone, workout, training }
}

/** koliko je obroka že pojedenega (po prilagoditvi čez dan ali po vpisih istega termina) */
export const gotOf = (sl: MealSlotPlan, meals: readonly MealEntry[]) => sl.got ?? meals.filter(m => m.slot === sl.slot).reduce((a, m) => a + m.kcal, 0)
/** do te ure je še nepojeden obrok »naslednji« (v3.48: zvečer ni zajtrk); obrok po vožnji se ravna po vožnji, ne po uri */
const SLOT_UNTIL: Partial<Record<MealEntry['slot'], number>> = { zajtrk: 11, kosilo: 16, malica: 19 }
/**
 * Prvi obrok, ki še ni (večinoma) pojeden. Preskoči obrok, ki ga nisi vpisal, a si že vpisal poznejše kosilo ali večerjo,
 * in (z uro `now`, »HH:MM« ali ura) obrok, katerega čas je mimo — kalorij ne prenaša, ker nevpisano ne pomeni nepojedeno.
 */
export function nextSlotOf(dp: DayNutrition, meals: readonly MealEntry[], now?: number | string | null): MealSlotPlan | null {
  const h = typeof now === 'number' ? now : typeof now === 'string' && /^\d{1,2}:\d{2}/.test(now) ? +now.split(':')[0]! + +now.split(':')[1]!.slice(0, 2) / 60 : null
  const got = dp.slots.map(sl => gotOf(sl, meals))
  // kosilo in večerja imata stalen vrstni red (malica in »drugo« sta lahko kadar koli)
  const lastMain = got.reduce((a, g, i) => (g > 0 && (dp.slots[i]!.slot === 'kosilo' || dp.slots[i]!.slot === 'vecerja') ? i : a), -1)
  return dp.slots.find((sl, i) => {
    if (got[i]! >= sl.kcal * 0.85) return false
    if (got[i]! > 0) return true
    if (i < lastMain) return false
    const until = sl.key === 'obnova' ? null : SLOT_UNTIL[sl.slot]
    return h == null || until == null || h < until
  }) ?? null
}

export function recipeCtxOf(p: Profile, target: Pick<DailyTarget, 'deficit'>, settings: Pick<Settings, 'foodPrefs'>, training: boolean, alt?: Record<string, number>): RecipeCtx {
  return { deficit: target.deficit > 0, keepMuscle: !!p.focus?.keepMuscle, training, prefs: settings.foodPrefs, ...(alt ? { alt } : {}) }
}

/** AI recept za obrok velja, če obrok ni za več kot 20 % drugačen od takrat in nisi prosil za drug predlog. */
export function aiRecipeOk(a: Recipe | null | undefined, sl: MealSlotPlan, alt?: Record<string, number>): a is Recipe {
  return !!a && Array.isArray(a.ingredients) && Array.isArray(a.steps) && Number.isFinite(a.kcal) && Math.abs(a.kcal - sl.kcal) <= sl.kcal * 0.2 && !(alt?.[sl.key])
}

/** Recepti za obroke dneva: AI za ta dan, kjer velja, sicer knjižnica po pravilih. */
export function recipesOf(dp: DayNutrition, day: string, ctx: RecipeCtx, settings: Pick<Settings, 'dayMenus'>): Record<string, Recipe> {
  const ai = settings.dayMenus?.[day]?.slots
  const rules = dayRecipes(dp, day, ctx)
  const out: Record<string, Recipe> = {}
  for (const sl of dp.slots) {
    const a = ai && typeof ai === 'object' ? ai[sl.key] : undefined
    const r = aiRecipeOk(a, sl, ctx.alt) ? a : rules[sl.key]
    if (r) out[sl.key] = r
  }
  return out
}
