import type { Activity, MealEntry, PlanDay, Profile, Settings } from '../types'
import type { DailyTarget } from './energy'
import { adjustToEaten, aroundSession, dayMealPlan, fuelCtxOf, gotBySlot, type DayNutrition, type MealSlotPlan } from './dayplan'
import { raceSoon } from './race'
import { dayRecipes, recipeOkFor, type Recipe, type RecipeCtx } from './recipes'
import { slotAt, TYPICAL } from './slots'

/**
 * Obroki dneva na enem mestu — Danes (naslednji obrok) in Prehrana (cel dan) računata isto:
 * glavna vožnja dneva, ali je za nami, obroki prilagojeni pojedenemu (danes), recept za obrok (AI za ta dan, če obrok
 * ni bistveno drugačen od takrat, sicer knjižnica po pravilih).
 */
export interface DayMealsIn {
  p: Profile; target: DailyTarget; plan: readonly PlanDay[]; activities: readonly Activity[]; meals: readonly MealEntry[]
  recentMeals: readonly MealEntry[]; weather: Record<string, { tmax: number }> | null | undefined; day: string; today: string
  /** (v3.50) ura zdaj (danes): nevpisan obrok, katerega čas je mimo, ni več v načrtu — kalorije gredo v naslednje obroke */
  hour?: number | null
}
export interface DayMeals { dp: DayNutrition; main: PlanDay | null; rideDone: boolean; workout: boolean; training: boolean }

/** (v3.50) ura začetka aktivnosti (lokalno, 0–24) iz `start` (ISO) — null, če je ni */
export function startHourOf(a: Pick<Activity, 'start'> | null | undefined): number | null {
  if (!a?.start) return null
  const d = new Date(a.start)
  return Number.isFinite(d.getTime()) ? d.getHours() + d.getMinutes() / 60 : null
}

export function dayMealsOf(x: DayMealsIn): DayMeals {
  const { p, target, plan, activities, meals, day, today } = x
  const main0 = plan.filter(d => d.date === day && (d.kind === 'kolo' || d.kind === 'test') && !d.optional).sort((a, b) => b.durationMin - a.durationMin)[0] || null
  const workout = plan.some(d => d.date === day && d.kind !== 'pocitek' && d.kind !== 'kolo' && d.kind !== 'test' && !d.optional)
  const training = plan.some(d => d.date === day && d.kind !== 'pocitek' && !d.optional)
  // (v3.50) brez vožnje: obroki okoli teka (≥ 45 min), hribov (≥ 90 min) ali moči (≥ 40 min) — prej samo okoli kolesa
  const sess0 = main0 ?? (plan.filter(d => d.date === day && !d.optional && (d.kind === 'tek' || d.kind === 'pohod' || d.kind === 'moc') && aroundSession(d)).sort((a, b) => b.durationMin - a.durationMin)[0] || null)
  const sport = (k: PlanDay['kind']) => (k === 'test' ? 'kolo' : k)
  // seja je za nami (označena ali pripeljana z ure): nevpisano gorivo na kolesu šteje 0, ne »po načrtu«
  const doneAct = sess0 ? activities.filter(a => a.date === day && a.sport === sport(sess0.kind) && (a.durationMin || 0) >= sess0.durationMin * 0.5).sort((a, b) => (b.durationMin || 0) - (a.durationMin || 0))[0] : undefined
  const sessDone = !!sess0 && (!!sess0.done || !!doneAct)
  const rideDone = !!main0 && sessDone
  // (v3.50) dejanska ura seje z ure: razpored obrokov po njej (po jutranji vožnji ni »Kosilo · 2–3 h pred vožnjo«)
  const startH = startHourOf(doneAct ?? (sess0?.done?.activityId ? activities.find(a => a.id === sess0.done!.activityId) : null))
  // (v3.48) vožnje ni bilo in ne šteje več (pozno zvečer, dan mimo): obroki kot dan brez vožnje — brez goriva in »po vožnji«
  const main = main0 && !rideDone && (target.plannedDropped || 0) > 0 && !target.plannedBurn ? null : main0
  const sess = main0 ? main : sess0 && !sessDone && (target.plannedDropped || 0) > 0 && !target.plannedBurn ? null : sess0
  const dp0 = dayMealPlan(p, target, sess, { ...fuelCtxOf(x.weather, x.recentMeals, day, today), race: raceSoon(p, day), workout, rideDone: sessDone, startH })
  // pretekli dan: pojedeno razdeljeno po obrokih kot danes (v3.48 — dva obroka istega termina ne štejeta istega dvakrat)
  const got = day === today ? null : gotBySlot(dp0, meals, { startH })
  // (v3.50) obroki, katerih čas je mimo (zajtrk po 11h …), in koliko beljakovin še manjka (nad ciljem beljakovinski prigrizek)
  const h = x.hour
  const past = day === today && h != null && Number.isFinite(h) ? dp0.slots.filter(s => { const u = SLOT_UNTIL[s.slot]; return u != null && h >= u }).map(s => s.key) : undefined
  const proteinLeft = Math.round(target.proteinG - meals.reduce((s, m) => s + (m.proteinG || 0), 0))
  const dp1 = day === today ? adjustToEaten(dp0, meals, target.kcal, { rideDone, weightKg: p.weightKg, startH, past, proteinLeft }) : { ...dp0, slots: dp0.slots.map(s => ({ ...s, got: got!.get(s.key) || 0 })) }
  // (v3.49) vožnja za nami: »naslednji obrok« in obrok novega vpisa to vesta (prigrizek pred vožnjo ni več na vrsti)
  // (v3.50) tudi tek, hribi ali moč, okoli katerih so obroki
  const dp = rideDone || (sessDone && dp1.slots.some(s => s.key === 'obnova')) ? { ...dp1, rideDone: true } : dp1
  return { dp, main, rideDone, workout, training }
}

/** koliko je obroka že pojedenega (po prilagoditvi čez dan ali po vpisih istega termina) */
export const gotOf = (sl: MealSlotPlan, meals: readonly MealEntry[]) => sl.got ?? meals.filter(m => m.slot === sl.slot).reduce((a, m) => a + m.kcal, 0)
/**
 * do te ure je še nepojeden obrok »naslednji« (v3.48: zvečer ni zajtrk); obrok po vožnji se ravna po vožnji, ne po uri
 * (v3.50) tudi večerja do 22h in prigrizek zvečer do 23h (prej ob 23:58 še »Večerja · 502 kcal«)
 */
export const SLOT_UNTIL: Partial<Record<MealEntry['slot'], number>> = { zajtrk: 11, kosilo: 16, malica: 19, vecerja: 22, drugo: 23 }
/** (v3.50) obrok pod tem (nad ciljem skrčen na drobiž) ni »naslednji« in nima številke kalorij */
export const TINY_KCAL = 120
/**
 * Prvi obrok, ki še ni (večinoma) pojeden. Preskoči obrok, ki ga nisi vpisal, a si že vpisal poznejše kosilo ali večerjo,
 * in (z uro `now`, »HH:MM« ali ura) obrok, katerega čas je mimo — kalorij ne prenaša, ker nevpisano ne pomeni nepojedeno.
 * (v3.49) Delno pojeden obrok je »naslednji« samo v svojem času: ne, če je vpisano poznejše kosilo ali večerja, če je
 * njegova ura mimo ali če je pojedenega vsaj 60 % (zajtrk 620 / 770 ni več na vrsti ob 13h). Ostanek gre v odprte obroke
 * (adjustToEaten). Prigrizek pred vožnjo, ki je že za nami, ni več na vrsti.
 */
export function nextSlotOf(dp: DayNutrition, meals: readonly MealEntry[], now?: number | string | null): MealSlotPlan | null {
  const h = typeof now === 'number' ? now : typeof now === 'string' && /^\d{1,2}:\d{2}/.test(now) ? +now.split(':')[0]! + +now.split(':')[1]!.slice(0, 2) / 60 : null
  const got = dp.slots.map(sl => gotOf(sl, meals))
  // kosilo in večerja imata stalen vrstni red (malica in »drugo« sta lahko kadar koli)
  const lastMain = got.reduce((a, g, i) => (g > 0 && (dp.slots[i]!.slot === 'kosilo' || dp.slots[i]!.slot === 'vecerja') ? i : a), -1)
  return dp.slots.find((sl, i) => {
    if (got[i]! >= sl.kcal * 0.85) return false
    // (v3.50) nevpisan obrok, katerega čas je mimo (kalorije so šle v naslednje), in drobiž nad ciljem nista na vrsti
    if (sl.skipped) return false
    if (!got[i] && sl.kcal < TINY_KCAL && sl.key !== 'obnova' && sl.key !== 'pred') return false
    // prigrizek pred vožnjo po vožnji ni več na vrsti (kosilo »2–3 h pred vožnjo« ostane — vožnja je bila morda dopoldne)
    if (dp.rideDone && sl.key === 'pred') return false
    const until = sl.key === 'obnova' ? null : SLOT_UNTIL[sl.slot]
    const past = h != null && until != null && h >= until
    if (got[i]! > 0) return !(i < lastMain || past || got[i]! >= sl.kcal * 0.6)
    if (i < lastMain) return false
    return !past
  }) ?? null
}

const minOf = (t: string) => { const m = /^(\d{1,2}):(\d{2})/.exec(t || ''); return m ? +m[1]! * 60 + +m[2]! : NaN }
/**
 * (v3.49) Obrok za nov vpis po uri IN po načrtu dneva (prej samo po uri: kosilo ob 15:30 = malica, malica pred večerno
 * vožnjo = večerja, večerja po vožnji ob 21:15 = »drugo«):
 *  - obrok po opravljeni vožnji, ki še ni vpisan, gre v svoj termin (večerja 15–23:30, zajtrk do 12h, kosilo do 16:30),
 *  - kosilo do 16:30, dokler ni vpisano,
 *  - malica pred večerno vožnjo (vožnja še ni opravljena) od 15h do 19h ostane malica.
 */
export function slotFor(time: string, dp: Pick<DayNutrition, 'slots' | 'rideDone'> | null, meals: readonly Pick<MealEntry, 'slot'>[]): MealEntry['slot'] {
  const base = slotAt(time), t = minOf(time)
  if (!dp || !Number.isFinite(t) || t < 5 * 60) return base
  const has = (s: MealEntry['slot']) => meals.some(m => m.slot === s)
  const ob = dp.slots.find(s => s.key === 'obnova')
  if (dp.rideDone && ob) {
    const same = dp.slots.filter(s => s.slot === ob.slot)
    const open = meals.filter(m => m.slot === ob.slot).length <= same.indexOf(ob)
    const [from, until] = ob.slot === 'vecerja' ? [15 * 60, 23.5 * 60] : ob.slot === 'zajtrk' ? [0, 12 * 60] : ob.slot === 'kosilo' ? [0, 16.5 * 60] : [0, 0]
    if (open && t >= from && t < until) return ob.slot
  }
  const lunchAt = dp.slots.findIndex(s => s.slot === 'kosilo')
  if (base === 'malica' && t >= 15 * 60 && t < 16.5 * 60 && lunchAt >= 0 && !has('kosilo')) return 'kosilo'
  const pred = dp.slots.findIndex(s => s.key === 'pred' && s.slot === 'malica')
  if (!dp.rideDone && pred > lunchAt && lunchAt >= 0 && t >= 15 * 60 && t < 19 * 60 && !has('malica')) return 'malica'
  // (v3.50) pozna večerja (21–23h), dokler večerja še ni vpisana, je večerja (prej »Drugo · 21:15«)
  if (base === 'drugo' && t >= 21 * 60 && t < 23 * 60 && !has('vecerja') && dp.slots.some(s => s.slot === 'vecerja')) return 'vecerja'
  return base
}

/** konec običajnega časa glavnega obroka (min) — po njem je pogost obrok tega termina vpis za nazaj */
const MAIN_END: Partial<Record<MealEntry['slot'], number>> = { zajtrk: 10 * 60, kosilo: 15 * 60, vecerja: 21 * 60 }
/**
 * (v3.49) Pogost obrok z enim tapom: v svoj običajni termin (zajtrk ostane zajtrk). Če tega obroka danes še ni in je
 * njegov čas mimo, je to vpis za nazaj (tipična ura); če je že vpisan ali njegov čas šele pride, šteje zdajšnji obrok.
 * Malica je lahko kadar koli (ostane malica, ura zdaj).
 */
export function repeatSlot(usual: MealEntry['slot'], now: string, meals: readonly Pick<MealEntry, 'slot'>[], dp: Pick<DayNutrition, 'slots' | 'rideDone'> | null): { slot: MealEntry['slot']; time: string; back: boolean } {
  const cur = slotFor(now, dp, meals)
  if (usual === cur || usual === 'malica') return { slot: usual, time: now, back: false }
  const end = MAIN_END[usual]
  if (end != null && !meals.some(m => m.slot === usual) && minOf(now) >= end) return { slot: usual, time: TYPICAL[usual], back: true }
  return { slot: cur, time: now, back: false }
}

export function recipeCtxOf(p: Profile, target: Pick<DailyTarget, 'deficit'>, settings: Pick<Settings, 'foodPrefs'>, training: boolean, alt?: Record<string, number>): RecipeCtx {
  return { deficit: target.deficit > 0, keepMuscle: !!p.focus?.keepMuscle, training, prefs: settings.foodPrefs, ...(alt ? { alt } : {}) }
}

/**
 * AI recept za obrok velja, če obrok ni za več kot 20 % drugačen od takrat in nisi prosil za drug predlog.
 * (v3.49) In samo, če ustreza prehranskim željam (tudi tistim, ki si jih nastavil po receptu) — sicer recept po pravilih.
 */
export function aiRecipeOk(a: Recipe | null | undefined, sl: MealSlotPlan, alt?: Record<string, number>, prefs?: string | null): a is Recipe {
  return !!a && Array.isArray(a.ingredients) && Array.isArray(a.steps) && Number.isFinite(a.kcal) && Math.abs(a.kcal - sl.kcal) <= sl.kcal * 0.2 && !(alt?.[sl.key]) && recipeOkFor(a, prefs)
}

/** Recepti za obroke dneva: AI za ta dan, kjer velja, sicer knjižnica po pravilih. */
export function recipesOf(dp: DayNutrition, day: string, ctx0: RecipeCtx, settings: Pick<Settings, 'dayMenus'> & Partial<Pick<Settings, 'recipeAlt'>>): Record<string, Recipe> {
  const ai = settings.dayMenus?.[day]?.slots
  // (v3.50) »drug predlog« je shranjen po dnevu: Danes, Plan in nakup kažejo isto jed kot Prehrana (prej samo do odhoda z zaslona)
  const saved = settings.recipeAlt?.[day]
  const ctx: RecipeCtx = ctx0.alt || !saved || typeof saved !== 'object' ? ctx0 : { ...ctx0, alt: saved }
  const rules = dayRecipes(dp, day, ctx)
  const out: Record<string, Recipe> = {}
  for (const sl of dp.slots) {
    const a = ai && typeof ai === 'object' ? ai[sl.key] : undefined
    const r = aiRecipeOk(a, sl, ctx.alt, ctx.prefs) ? a : rules[sl.key]
    if (r) out[sl.key] = r
  }
  return out
}

/**
 * (v3.49) Recepti za danes in naslednje dni (danes samo obroki, ki še niso pojedeni) — za nakupovalni seznam brez AI
 * in prijave. Isti izračun kot Prehrana za vsak dan (cilj tega dne, trening, želje, shranjeni AI recepti).
 */
export function recipesAhead(x: Omit<DayMealsIn, 'day' | 'target'> & { settings: Pick<Settings, 'foodPrefs' | 'dayMenus'> & Partial<Pick<Settings, 'recipeAlt'>>; days: number; targetOf: (day: string) => DailyTarget | null; /** »drug predlog« za dan, ki je odprt */ alt?: Record<string, number>; altDay?: string }): { day: string; recipes: Recipe[] }[] {
  const out: { day: string; recipes: Recipe[] }[] = []
  for (let i = 0; i < x.days; i++) {
    const day = new Date(Date.parse(`${x.today}T12:00:00Z`) + i * 86400_000).toISOString().slice(0, 10)
    const target = x.targetOf(day)
    if (!target) continue
    const meals = day === x.today ? x.meals : []
    const dm = dayMealsOf({ ...x, target, meals, day })
    const rs = recipesOf(dm.dp, day, recipeCtxOf(x.p, target, x.settings, dm.training, day === x.altDay ? x.alt : undefined), x.settings)
    out.push({ day, recipes: dm.dp.slots.filter(sl => day !== x.today || (gotOf(sl, meals) < sl.kcal * 0.85 && !sl.skipped)).map(sl => rs[sl.key]).filter((r): r is Recipe => !!r) })
  }
  return out
}
