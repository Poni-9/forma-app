/**
 * (v3.50) GORIVO NA URO — ENA TABELA po trajanju in intenzivnosti vožnje. Berejo jo rideFuel (Gorivo, Danes, Vadba),
 * fueling »Med« (energy.ts) in opisi sej v načrtu (planner.ts) — prej je isti kolesar bral tri različne številke
 * (Danes »samo voda«, opis »~40 g/h«, trener »0–30 g/h«; dolga »50–60«, simulacija »~80«, Franja »~85«, tekma B »70–90«).
 * Brez uvozov, da jo lahko kliče tudi planner.ts (dayplan.ts uvaža planner).
 */
export interface FuelRateIn { kind: string; durationMin: number; zone?: string | null; role?: string | null; title?: string | null }

/** Simulacija dirke, razgibana dolga in tempo dirke v dolgi: gorivo kot na dirki (opis: »preizkusi, kar boš jedel na dirki«). */
export const isRaceSim = (title?: string | null) => /Simulacija|razgibana|tempo na klancih|tempo dirke/i.test(title || '')
export const isHardRide = (d: Pick<FuelRateIn, 'role' | 'zone'>) => d.role === 'kljucna' || d.role === 'test' || /Z[4-5]|test/.test(d.zone || '')

/**
 * Gramov OH na uro (0 = samo voda): tekma ≥ 150 min 85, ≥ 90 min 70, 60–89 min 45, krajša 30; regeneracija in vožnje
 * pod 60 min 0; intervali ≥ 75 min 70, krajši 40; simulacija dirke 80; dolga ≥ 150 min 60, krajša 50; Z2 ≥ 90 min 40.
 */
export function fuelGph(d: FuelRateIn): number {
  if (d.kind !== 'kolo' && d.kind !== 'test') return 0
  const min = d.durationMin || 0
  if (d.role === 'dirka') return min >= 150 ? 85 : min >= 90 ? 70 : min >= 60 ? 45 : 30
  if (d.role === 'regen' || min < 60) return 0
  if (isHardRide(d)) return min >= 75 ? 70 : 40
  if (isRaceSim(d.title)) return 80
  if (d.role === 'dolga') return min >= 150 ? 60 : 50
  return min >= 90 ? 40 : 0
}

/** »~60 g OH na uro« za opise (prazno pri 0). */
export function fuelGphText(d: FuelRateIn): string {
  const g = fuelGph(d)
  return g ? `~${g} g OH na uro` : ''
}
