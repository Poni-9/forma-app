import type { MealEntry } from '../types'

/**
 * Obrok po uri — samodejno, kot je takrat čas: 5–10 zajtrk, 10–12 malica, 12–15 kosilo, 15–17 malica,
 * 17–21 večerja, sicer drugo. Če ročno izbereš obrok, ki ni zdajšnji (zajtrk popoldne), je to vpis za nazaj:
 * dobi tipično uro tega obroka, da se v seznamu dneva uvrsti tja (zajtrk 7:30 pred kosilom).
 */
export type Slot = MealEntry['slot']

const mins = (hhmm: string) => { const m = /^(\d{1,2}):(\d{2})/.exec(hhmm || ''); return m ? +m[1]! * 60 + +m[2]! : NaN }
export const hhmm = (d: Date = new Date()) => d.toTimeString().slice(0, 5)

export function slotAt(time: string): Slot {
  const t = mins(time)
  if (!Number.isFinite(t)) return 'drugo'
  const h = t / 60
  return h < 5 ? 'drugo' : h < 10 ? 'zajtrk' : h < 12 ? 'malica' : h < 15 ? 'kosilo' : h < 17 ? 'malica' : h < 21 ? 'vecerja' : 'drugo'
}

/** Tipična ura obroka (za vpis za nazaj in za razvrščanje vpisov brez ure). */
export const TYPICAL: Record<Slot, string> = { zajtrk: '07:30', malica: '10:30', kosilo: '13:00', med_vadbo: '16:00', vecerja: '19:00', drugo: '21:00' }

/**
 * Ura ob ročni izbiri obroka. Isti obrok kot zdaj → zdaj. Drug obrok → tipična ura tega obroka
 * (malica: popoldanska 16:00, če je dopoldanska že mimo in je popoldne; sicer 10:30). Drugo in med vožnjo → zdaj.
 */
export function timeForSlot(slot: Slot, now: string): string {
  if (slot === 'drugo' || slot === 'med_vadbo' || slotAt(now) === slot) return now
  if (slot === 'malica') return mins(now) >= 15 * 60 ? '16:00' : '10:30'
  return TYPICAL[slot]
}

/** Vpisi dneva po času (brez ure → tipična ura obroka), nato po času vnosa. */
export function byTime(a: Pick<MealEntry, 'time' | 'slot' | 'createdAt'>, b: Pick<MealEntry, 'time' | 'slot' | 'createdAt'>): number {
  const ta = mins(a.time || TYPICAL[a.slot]), tb = mins(b.time || TYPICAL[b.slot])
  return ta - tb || (a.createdAt || '').localeCompare(b.createdAt || '')
}

/** »Dodaj …« v tožilniku. */
export const SLOT_ACC: Record<Slot, string> = { zajtrk: 'zajtrk', malica: 'malico', kosilo: 'kosilo', med_vadbo: 'obrok med vožnjo', vecerja: 'večerjo', drugo: 'prigrizek' }

/**
 * Ura slike obroka: EXIF (ura posnetka) ali čas datoteke iz galerije, če sta iz izbranega dne in vsaj 5 min
 * v preteklosti; sicer zdaj (danes) ali tipična ura (pretekli dan). Vrne uro HH:MM.
 */
export function photoTime(day: string, today: string, exif: { date: string; time: string } | null, lastModified: number | null, now: Date = new Date()): string | null {
  if (exif && exif.date === day) return exif.time
  if (lastModified && Number.isFinite(lastModified)) {
    const lm = new Date(lastModified)
    const iso = new Date(lm.getTime() - lm.getTimezoneOffset() * 60000).toISOString().slice(0, 10)
    if (iso === day && now.getTime() - lm.getTime() > 5 * 60_000) return hhmm(lm)
  }
  return day === today ? hhmm(now) : null
}
