import type { Profile } from '../types'

/**
 * PRED TEKMO: MALO VLAKNIN. Zadnja 2 dni pred tekmo (glavni cilj ali druga tekma) in na dan tekme do starta
 * jej ogljikove hidrate z malo vlakninami — manj prebavnih težav med dirko in manj teže v črevesju na startu.
 * OH ostanejo visoki (polnjenje), beljakovine normalne.
 */
export interface RaceSoon { name: string; date: string; inDays: 0 | 1 | 2; main: boolean }

const DAY = 86_400_000
const dayDiff = (from: string, to: string) => Math.round((Date.parse(to + 'T12:00:00Z') - Date.parse(from + 'T12:00:00Z')) / DAY)

function racesOf(p: Pick<Profile, 'event' | 'races'>): { name: string; date: string; main: boolean }[] {
  return [
    ...(p.event?.date ? [{ name: p.event.name, date: p.event.date, main: true }] : []),
    ...(p.races || []).map(r => ({ name: r.name, date: r.date, main: false })),
  ]
}

/** Najbližja tekma danes ali v naslednjih dveh dneh (null, če je ni). */
export function raceSoon(p: Pick<Profile, 'event' | 'races'>, date: string): RaceSoon | null {
  let best: RaceSoon | null = null
  for (const r of racesOf(p)) {
    const d = dayDiff(date, r.date)
    if (d >= 0 && d <= 2 && (!best || d < best.inDays)) best = { name: r.name, date: r.date, inDays: d as 0 | 1 | 2, main: r.main }
  }
  return best
}

/** Dnevi z malo vlakninami v obdobju [from, to]: 2 dni pred vsako tekmo in dan tekme (za tedenski jedilnik). */
export function lowFiberDays(p: Pick<Profile, 'event' | 'races'>, from: string, to: string): { date: string; race: string; inDays: number }[] {
  const out: { date: string; race: string; inDays: number }[] = []
  for (const r of racesOf(p)) for (let k = 0; k <= 2; k++) {
    const d = new Date(Date.parse(r.date + 'T12:00:00Z') - k * DAY).toISOString().slice(0, 10)
    if (d >= from && d <= to && !out.some(x => x.date === d && x.inDays <= k)) out.push({ date: d, race: r.name, inDays: k })
  }
  return out.sort((a, b) => a.date.localeCompare(b.date))
}

export const LOW_FIBER_YES = 'bel kruh ali žemlja, bel riž, bele testenine, krompir brez lupine, zrela banana, med, marmelada, sok brez pulpe, jogurt, skuta, jajca, piščanec, riba'
export const LOW_FIBER_NO = 'polnozrnat kruh, kosmiči in polnozrnate testenine, stročnice (fižol, čičerika, leča), surova zelenjava in solata, sadje z lupino, suho sadje, oreški in semena'

export const whenSl = (inDays: number) => (inDays === 0 ? 'danes' : inDays === 1 ? 'jutri' : 'pojutrišnjem')

/** Kratko pravilo za zaslon in AI. */
export function lowFiberRule(r: RaceSoon): string {
  return r.inDays === 0
    ? `${r.name} je danes: do starta malo vlaknin in maščob (zajtrk 3 h prej: bel kruh z medom ali marmelado, banana, jogurt). Po tekmi jej normalno.`
    : `${r.name} je ${whenSl(r.inDays)}: ${r.inDays === 2 ? 'od danes' : 'še danes'} malo vlaknin (pod ~15 g na dan) — ${LOW_FIBER_YES}. Brez: ${LOW_FIBER_NO}. Ogljikovi hidrati ostanejo visoki.`
}
