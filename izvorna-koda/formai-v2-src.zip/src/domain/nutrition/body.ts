import type { Profile } from '../types'

/**
 * NAJBOLJŠA TEŽA ZA KOLESARJA — iz sestave telesa, ne iz želje.
 * Maščoba: vpisana (vaga, kaliper) ali ocena iz BMI (Deurenberg in sod., 1991: 1,2·BMI + 0,23·starost − 10,8·spol − 5,4).
 * Pusta masa ostane, cilj je ~10 % maščobe (moški; ženske ~18 %) — raven treniranih cestnih kolesarjev (BMI ~22–23).
 * Varovalke: nikoli pod BMI 20,5 (m) / 19,5 (ž), nikoli nad izhodiščem, največ ~0,45 kg na teden do konca gradnje.
 * Izhodišče je teža ob potrditvi cilja — cilj se med hujšanjem ne premika.
 */
export interface RaceWeight { kg: number; lo: number; hi: number; bf: number; targetBf: number; lbm: number; measured: boolean; limitedByTime: boolean; floorKg: number }

const r05 = (x: number) => Math.round(x * 2) / 2

export function bodyFatPct(p: Pick<Profile, 'sex' | 'age' | 'heightCm' | 'bodyFatPct'>, weightKg: number): { pct: number; measured: boolean } | null {
  if (p.bodyFatPct && p.bodyFatPct >= 3 && p.bodyFatPct <= 60) return { pct: p.bodyFatPct, measured: true }
  if (!p.heightCm || !p.age || !p.sex || p.age < 18) return null
  const bmi = weightKg / (p.heightCm / 100) ** 2
  const pct = 1.2 * bmi + 0.23 * p.age - 10.8 * (p.sex === 'm' ? 1 : 0) - 5.4
  return { pct: Math.max(4, Math.min(55, +pct.toFixed(1))), measured: false }
}

/** @param weeksToEvent tedni do dirke — teža naj bo dosežena do ~68 % poti (konec gradnje) s ≤ 0,45 kg na teden */
export function raceWeight(p: Pick<Profile, 'sex' | 'age' | 'heightCm' | 'bodyFatPct' | 'weightKg' | 'goalStart'>, weeksToEvent?: number | null): RaceWeight | null {
  const base = p.goalStart?.weightKg ?? p.weightKg
  if (!base || !p.heightCm) return null
  const bf = bodyFatPct(p, base)
  if (!bf) return null
  const male = p.sex === 'm'
  const targetBf = male ? 10 : 18
  const lbm = base * (1 - bf.pct / 100)
  const floorKg = r05((male ? 20.5 : 19.5) * (p.heightCm / 100) ** 2)
  const clampKg = (x: number) => Math.min(base, Math.max(floorKg, x))
  let kg = clampKg(r05(lbm / (1 - targetBf / 100)))
  const lo = clampKg(r05(lbm / (1 - (targetBf - 1) / 100)))
  const hi = clampKg(r05(lbm / (1 - (targetBf + 2) / 100)))
  let limitedByTime = false
  if (weeksToEvent != null && weeksToEvent > 0) {
    const maxLoss = 0.45 * Math.max(1, weeksToEvent * 0.68)
    if (base - kg > maxLoss) { kg = r05(base - maxLoss); limitedByTime = true }
  }
  return { kg, lo: Math.min(lo, kg), hi: Math.max(hi, kg), bf: bf.pct, targetBf, lbm: +lbm.toFixed(1), measured: bf.measured, limitedByTime, floorKg }
}

/** Ciljna teža, ki jo uporablja aplikacija: ročna (če obstaja) ali izračunana. */
export function targetWeightOf(p: Pick<Profile, 'sex' | 'age' | 'heightCm' | 'bodyFatPct' | 'weightKg' | 'goalStart' | 'targetWeightKg' | 'event'>, today?: string): number | null {
  if (p.targetWeightKg) return p.targetWeightKg
  return raceWeight(p, weeksFromStart(p, today))?.kg ?? null
}
/** Tedni od potrditve cilja (ali od danes) do dirke — stalno izhodišče, da se cilj ne premika. */
export function weeksFromStart(p: Pick<Profile, 'goalStart' | 'event'>, today?: string): number | null {
  const from = p.goalStart?.date || today
  if (!p.event?.date || !from) return null
  return Math.max(0, Math.round((new Date(p.event.date).getTime() - new Date(from).getTime()) / (7 * 86400_000)))
}
