import type { Profile } from '../types'
import { usesAgreement } from '@/domain/focus/model'

/**
 * NAJBOLJŠA TEŽA ZA KOLESARJA — iz sestave telesa, ne iz želje.
 * Maščoba: vpisana (vaga, kaliper) ali ocena iz BMI (Deurenberg in sod., 1991: 1,2·BMI + 0,23·starost − 10,8·spol − 5,4).
 * Pusta masa ostane, cilj je ~10 % maščobe (moški; ženske ~18 %) — raven treniranih cestnih kolesarjev (BMI ~22–23).
 * Varovalke: nikoli pod BMI 20,5 (m) / 19,5 (ž), nikoli nad izhodiščem, največ ~0,45 kg na teden do konca gradnje.
 * Izhodišče je teža ob potrditvi cilja — cilj se med hujšanjem ne premika.
 */
export interface RaceWeight { kg: number; lo: number; hi: number; bf: number; targetBf: number; lbm: number; measured: boolean; limitedByTime: boolean; floorKg: number }

const r05 = (x: number) => Math.round(x * 2) / 2
/**
 * (v3.50) Polnoletnost je ZNANA: vpisana starost 18+. Brez vpisane starosti (uvod dovoli nadaljevati brez nje) ni ciljne
 * teže, najboljše teže iz maščobe ne tempa hujšanja — varno privzeto kot pri mladoletnih (prej »cilj ~10 % maščobe«).
 */
export const adultKnown = (p: Pick<Profile, 'age'>): boolean => p.age != null && p.age >= 18

export function bodyFatPct(p: Pick<Profile, 'sex' | 'age' | 'heightCm' | 'bodyFatPct'>, weightKg: number): { pct: number; measured: boolean } | null {
  if (p.bodyFatPct && p.bodyFatPct >= 3 && p.bodyFatPct <= 60) return { pct: p.bodyFatPct, measured: true }
  if (!p.heightCm || !p.age || !p.sex || p.age < 18) return null
  const bmi = weightKg / (p.heightCm / 100) ** 2
  const pct = 1.2 * bmi + 0.23 * p.age - 10.8 * (p.sex === 'm' ? 1 : 0) - 5.4
  return { pct: Math.max(4, Math.min(55, +pct.toFixed(1))), measured: false }
}

/** @param weeksToEvent tedni do dirke — teža naj bo dosežena do ~68 % poti (konec gradnje) s ≤ 0,45 kg na teden */
export function raceWeight(p: Pick<Profile, 'sex' | 'age' | 'heightCm' | 'bodyFatPct' | 'weightKg' | 'goalStart'>, weeksToEvent?: number | null): RaceWeight | null {
  const base = p.goalStart?.weightKg ?? p.weightKg
  if (!base || !p.heightCm) return null
  // (v3.50) do 18. leta ni najboljše teže tudi z vpisano maščobo (prej 16-letnik z 20 % → »70 kg, ~10 % maščobe«); brez starosti tudi ne
  if (!adultKnown(p)) return null
  const bf = bodyFatPct(p, base)
  if (!bf) return null
  const male = p.sex === 'm'
  const targetBf = male ? 10 : 18
  const lbm = base * (1 - bf.pct / 100)
  const floorKg = r05((male ? 20.5 : 19.5) * (p.heightCm / 100) ** 2)
  const clampKg = (x: number) => Math.min(base, Math.max(floorKg, x))
  let kg = clampKg(r05(lbm / (1 - targetBf / 100)))
  const lo = clampKg(r05(lbm / (1 - (targetBf - 1) / 100)))
  const hi = clampKg(r05(lbm / (1 - (targetBf + 2) / 100)))
  let limitedByTime = false
  if (weeksToEvent != null && weeksToEvent > 0) {
    const maxLoss = 0.45 * Math.max(1, weeksToEvent * 0.68)
    if (base - kg > maxLoss) { kg = r05(base - maxLoss); limitedByTime = true }
  }
  return { kg, lo: Math.min(lo, kg), hi: Math.max(hi, kg), bf: bf.pct, targetBf, lbm: +lbm.toFixed(1), measured: bf.measured, limitedByTime, floorKg }
}

/**
 * (v3.50) ZDRAVA CILJNA TEŽA za hujšanje brez kolesarske tekme (fitnes, tek, »manj kilogramov«): prvi mejnik je
 * −10 % izhodišča, a nikoli pod ITM 21 (ženske) / 22 (moški) — kar je bližje. Prej je vsak dobil tekmovalno težo
 * kolesarja (10 % / 18 % maščobe): ženska 60 kg → 53 kg, tekač 95 kg → 76,5 kg, 45-letnica 78 kg → 57,5 kg.
 */
export const HEALTHY_BMI_M = 22, HEALTHY_BMI_Z = 21, FIRST_STEP = 0.9
export function healthyTargetWeight(p: Pick<Profile, 'sex' | 'age' | 'heightCm' | 'weightKg' | 'goalStart'>): number | null {
  const base = p.goalStart?.weightKg ?? p.weightKg
  if (!base || !p.heightCm || !adultKnown(p)) return null
  const bmiKg = r05((p.sex === 'm' ? HEALTHY_BMI_M : HEALTHY_BMI_Z) * (p.heightCm / 100) ** 2)
  return Math.min(base, Math.max(bmiKg, r05(base * FIRST_STEP)))
}
/**
 * (v3.50) Izhodišče teže za mejnik (−10 %) se zapiše ob prvi znani teži, ko je teža cilj — prej je bil brez njega mejnik
 * vedno −10 % TRENUTNE teže (100 → 90, pri 91 kg že 82 …) in deficit se ni ustavil na mejniku. Brez profila z dirko brez
 * izhodišča (tam bi nov začetek premaknil mejnike poti). Vrne popravek profila ali null.
 */
export function goalBasePatch(p: Pick<Profile, 'weightKg' | 'goalStart' | 'goal' | 'deficit' | 'ftp' | 'event' | 'createdAt'>, today: string): Pick<Profile, 'goalStart'> | null {
  if (!p.weightKg || !(p.weightKg > 0) || p.goalStart?.weightKg) return null
  if (!(p.goal === 'shujsati' || (p.deficit != null && p.deficit > 0))) return null
  if (p.goalStart) return { goalStart: { ...p.goalStart, weightKg: p.weightKg } }
  if (p.event?.date) return null
  return { goalStart: { date: (p.createdAt || '').slice(0, 10) || today, ftp: p.ftp ?? null, weightKg: p.weightKg } }
}
type TargetP = Pick<Profile, 'sex' | 'age' | 'heightCm' | 'bodyFatPct' | 'weightKg' | 'goalStart' | 'targetWeightKg' | 'event'> & Partial<Pick<Profile, 'goal' | 'deficit' | 'focus'>>
/**
 * Ciljna teža, ki jo uporablja aplikacija: ročna (če obstaja) ali izračunana.
 * (v3.50) Izračunana: tekmovalna teža (sestava telesa) samo za kolesarski cilj z datumom tekme; pri hujšanju brez tekme
 * ali v načrtu po meri zdrav prvi mejnik; brez namena hujšati (brez deficita, cilj ni »shujšati«) je ni — mejniki teže
 * ne obljubljajo padca, ki ga deficit 0 ne prinese (prej U23 brez deficita »70 → 68 kg«). Do 18. leta nikoli.
 */
export function targetWeightOf(p: TargetP, today?: string, custom?: boolean): number | null {
  if (p.targetWeightKg) return p.targetWeightKg
  if (!adultKnown(p)) return null
  if (!(p.goal === 'shujsati' || (p.deficit != null && p.deficit > 0))) return null
  const own = custom ?? usesAgreement(p.focus)
  if (!own && p.event?.date) return raceWeight(p, weeksFromStart(p, today))?.kg ?? null
  return healthyTargetWeight(p)
}
/**
 * (v3.48) Ciljna teža za prikaz na Danes in v Napredku: ročno vpisana; izračunana samo, ko je teža res cilj (hujšanje ali
 * kolesarski cilj z datumom, kjer jo kaže kartica cilja) — nikoli pod 18 let. Prej je izračunana »najboljša teža«
 * dobil vsak (tudi načrt »forma« in mladoletni) skupaj z nasvetom »dodaj hojo«.
 */
export function shownTargetWeight(p: TargetP & Pick<Profile, 'goal'>, custom: boolean, today?: string): number | null {
  if (!adultKnown(p)) return null
  if (p.targetWeightKg) return p.targetWeightKg
  return p.goal === 'shujsati' || (!custom && !!p.event?.date) ? targetWeightOf(p, today, custom) : null
}
/** Tedni od potrditve cilja (ali od danes) do dirke — stalno izhodišče, da se cilj ne premika. */
export function weeksFromStart(p: Pick<Profile, 'goalStart' | 'event'>, today?: string): number | null {
  const from = p.goalStart?.date || today
  if (!p.event?.date || !from) return null
  return Math.max(0, Math.round((new Date(p.event.date).getTime() - new Date(from).getTime()) / (7 * 86400_000)))
}
