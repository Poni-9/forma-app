import { F, TPL_LF, qtyOf, qtyText, type Tpl, type MealSlotPlan, type DayNutrition } from './dayplan'

/**
 * RECEPTI (Blaž, 10. 10.: »pri hrani naj dobiš tudi recept — kaj ti priporoča jesti, koliko in kako se naredi«).
 * Vsak obrok dneva dobi jed iz knjižnice: sestavine z grami (iz navadne slovenske trgovine), priprava po korakih,
 * koliko minut in zakaj prav ta obrok zate (beljakovine, OH okoli vadbe, primanjkljaj, mišice). Količine so pomerjene
 * na kalorije in beljakovine obroka iz dnevnega cilja (energy.ts → dayplan.ts), zato se jed ne ponavlja dan za dnem
 * (vsak dan druga iz knjižnice) in se spremeni, ko se spremeni dan treninga. Brez AI; AI lahko doda svoje recepte
 * (actions.ts), ki gredo skozi iste varovalke (kalorije in beljakovine obroka).
 * Prehranske želje (»vegetarijansko«, »brez laktoze«, »ne maram rib«) izločijo jedi s temi sestavinami.
 */
export type Contains = 'meso' | 'riba' | 'mleko' | 'gluten' | 'jajca' | 'oreski' | 'soja'
export interface Dish { id: string; name: string; tpl: string; items: Tpl; steps: string[]; minutes: number; contains: Contains[] }

export const DISHES: readonly Dish[] = [
  // zajtrk
  { id: 'kasa', name: 'Ovsena kaša z jogurtom in banano', tpl: 'zajtrk', items: [['oves', 70], ['jogurt', 200], ['banana', 1], ['med', 15]], minutes: 10, contains: ['mleko', 'gluten'],
    steps: ['Ovsene kosmiče zalij z vodo ali mlekom (2 : 1), kuhaj 3–4 min in mešaj, da se zgosti.', 'Odstavi, vmešaj polovico jogurta.', 'Na vrh banano na rezine, preostali jogurt in med.'] },
  { id: 'omleta-z', name: 'Omleta s kruhom in zelenjavo', tpl: 'zajtrk', items: [['jajce', 3], ['kruh', 60], ['zelenjava', 120], ['olje', 5]], minutes: 12, contains: ['jajca', 'gluten'],
    steps: ['Zelenjavo (papriko, paradižnik, špinačo) na kocke in 3 min pražite na olju.', 'Jajca razžvrkljaj s ščepom soli, prelij čez zelenjavo in peci na srednjem ognju 3–4 min, nato preloži.', 'Postrezi s kruhom.'] },
  { id: 'skuta-z', name: 'Skuta s sadjem in oreški', tpl: 'zajtrk', items: [['skuta', 250], ['sadje', 150], ['oreski', 15], ['med', 10]], minutes: 5, contains: ['mleko', 'oreski'],
    steps: ['Skuto zmešaj z medom (po želji z žlico jogurta, da je mehkejša).', 'Sadje nareži in dodaj, potresi z oreški.'] },
  { id: 'jogurt-z', name: 'Jogurt z ovsenimi kosmiči in jabolkom', tpl: 'zajtrk', items: [['jogurt', 250], ['oves', 50], ['jabolko', 1], ['med', 10]], minutes: 5, contains: ['mleko', 'gluten'],
    steps: ['Kosmiče vmešaj v jogurt in pusti 5 min, da se zmehčajo (ali čez noč v hladilniku).', 'Jabolko na kocke, med po vrhu.'] },
  { id: 'kasa-voda', name: 'Ovsena kaša na vodi z banano in oreški', tpl: 'zajtrk', items: [['oves', 70], ['banana', 1], ['oreski', 15], ['med', 15]], minutes: 8, contains: ['gluten', 'oreski'],
    steps: ['Kosmiče zalij z vodo (2 : 1), kuhaj 3–4 min in mešaj.', 'Dodaj banano na rezine, oreške in med.'] },
  { id: 'tofu-z', name: 'Umešan tofu z zelenjavo in krompirjem', tpl: 'zajtrk', items: [['tofu', 200], ['zelenjava', 150], ['krompir', 150], ['olje', 10]], minutes: 20, contains: ['soja'],
    steps: ['Krompir na kocke kuhaj 10 min (ali uporabi kuhan od prej).', 'Tofu zdrobi z vilicami, pražite na olju 4 min s ščepom soli, kurkume in popra.', 'Dodaj krompir in zelenjavo (paprika, špinača), pražite še 5 min.'] },
  // kosilo
  { id: 'pisc-riz', name: 'Piščanec z rižem in zelenjavo', tpl: 'kosilo', items: [['riz', 90], ['piscanec', 150], ['zelenjava', 200], ['cebula', 50], ['olje', 10]], minutes: 30, contains: ['meso'],
    steps: ['Riž skuhaj v dvojni količini slane vode (12–15 min).', 'Piščančje prsi nareži na trakove, posoli in popopraj; na olju jih pečite 3 min na vsaki strani, nato jih vzemi iz ponve.', 'V isti ponvi prepraži čebulo in česen, dodaj zelenjavo (paprika, bučke, brokoli) in pražite 5–6 min.', 'Vrni piščanca, premešaj, postrezi na rižu.'] },
  { id: 'test-tuna', name: 'Testenine s tuno in paradižnikovo omako', tpl: 'kosilo', items: [['testenine', 100], ['tuna', 120], ['omaka', 150], ['cebula', 40], ['olje', 5]], minutes: 20, contains: ['riba', 'gluten'],
    steps: ['Testenine skuhaj v slani vodi po navodilu (8–10 min).', 'Čebulo in česen prepraži na olju, dodaj paradižnikovo omako in kuhaj 5 min; začini z origanom.', 'Vmešaj odcejeno tuno, segrej in premešaj s testeninami.'] },
  { id: 'puran-kr', name: 'Puran s krompirjem in solato', tpl: 'kosilo', items: [['krompir', 300], ['puran', 150], ['solata', 200], ['olje', 10]], minutes: 30, contains: ['meso'],
    steps: ['Krompir olupi, nareži na kose in kuhaj 15–18 min (ali peci v pečici na 200 °C 25 min).', 'Puranje prsi posoli, popopraj in pečite na olju 4 min na vsaki strani.', 'Solato in paradižnik zabeli z malo olja in kisa.'] },
  { id: 'cicerika', name: 'Čičerikin curry z rižem', tpl: 'kosilo', items: [['fizol', 250], ['riz', 80], ['zelenjava', 150], ['cebula', 50], ['olje', 10]], minutes: 25, contains: [],
    steps: ['Riž skuhaj (12–15 min).', 'Čebulo in česen prepraži na olju, dodaj žličko curryja in zelenjavo, pražite 5 min.', 'Dodaj odcejeno čičeriko in 1 dl vode (ali kokosovega mleka), kuhaj 8 min; posoli.', 'Postrezi na rižu.'] },
  { id: 'losos-kr', name: 'Losos s krompirjem in zelenjavo', tpl: 'kosilo', items: [['losos', 150], ['krompir', 300], ['zelenjava', 200], ['olje', 5]], minutes: 30, contains: ['riba'],
    steps: ['Krompir na kose in zelenjavo daj na pekač z oljem, soljo in paprikinim prahom; peci na 200 °C 20 min.', 'Losos posoli in položi na pekač k zelenjavi, peci še 12 min.', 'Pokapaj z limono.'] },
  { id: 'tofu-riz', name: 'Tofu z rižem in zelenjavo', tpl: 'kosilo', items: [['tofu', 200], ['riz', 90], ['zelenjava', 200], ['cebula', 40], ['olje', 10]], minutes: 25, contains: ['soja'],
    steps: ['Riž skuhaj (12–15 min).', 'Tofu na kocke, popeci na olju do zlate barve (6–8 min), dodaj žlico sojine omake.', 'Dodaj čebulo, česen in zelenjavo, pražite 5 min; postrezi na rižu.'] },
  // po vadbi (obnova)
  { id: 'test-tuna-o', name: 'Testenine s tuno in paradižnikovo omako', tpl: 'obnova', items: [['testenine', 100], ['tuna', 120], ['omaka', 150], ['olje', 5]], minutes: 20, contains: ['riba', 'gluten'],
    steps: ['Testenine skuhaj po navodilu (8–10 min).', 'Omako segrej z oljem in origanom, vmešaj odcejeno tuno.', 'Premešaj s testeninami — v 45 minutah po vadbi.'] },
  { id: 'riz-pisc-o', name: 'Riž s piščancem in zelenjavo', tpl: 'obnova', items: [['riz', 100], ['piscanec', 140], ['zelenjava', 150], ['olje', 5]], minutes: 25, contains: ['meso'],
    steps: ['Riž skuhaj (12–15 min).', 'Piščanca na trakove pečite na olju 6–8 min, dodaj zelenjavo in pražite še 5 min.', 'Posoli, premešaj z rižem.'] },
  { id: 'shake', name: 'Skutin shake z banano in ovsom', tpl: 'obnova', items: [['skuta', 200], ['banana', 1], ['mleko', 250], ['oves', 40], ['med', 10]], minutes: 5, contains: ['mleko', 'gluten'],
    steps: ['Vse daj v mešalnik in zmešaj do gladkega.', 'Popij v 30 minutah po vadbi; če je pregosto, dodaj mleko.'] },
  { id: 'leca-riz', name: 'Leča z rižem in zelenjavo', tpl: 'obnova', items: [['leca', 250], ['riz', 70], ['zelenjava', 150], ['cebula', 40], ['olje', 5]], minutes: 25, contains: [],
    steps: ['Riž skuhaj (12–15 min).', 'Čebulo in česen prepraži, dodaj zelenjavo in kuhano lečo (iz pločevinke, odcejeno), segrevaj 8 min; posoli, dodaj kumino.', 'Postrezi na rižu.'] },
  // večerja
  { id: 'krompir-jajca', name: 'Krompir z jajci in zelenjavo', tpl: 'vecerja', items: [['krompir', 300], ['jajce', 3], ['zelenjava', 250], ['olje', 10]], minutes: 25, contains: ['jajca'],
    steps: ['Krompir skuhaj v olupku (20 min), olupi in nareži na kolobarje.', 'Na olju popeci krompir 5 min, dodaj zelenjavo in pražite še 5 min.', 'Prelij z razžvrkljanimi jajci in peci 3–4 min; posoli.'] },
  { id: 'solata-tuna', name: 'Solata s tuno in fižolom', tpl: 'vecerja', items: [['tuna', 120], ['fizol', 200], ['solata', 250], ['kruh', 40], ['olje', 10]], minutes: 10, contains: ['riba', 'gluten'],
    steps: ['Solato in paradižnik nareži, dodaj odcejen fižol in tuno.', 'Zabeli z oljem, kisom ali limono, soljo in poprom.', 'Postrezi s kruhom.'] },
  { id: 'tofu-zel', name: 'Tofu s pečeno zelenjavo in krompirjem', tpl: 'vecerja', items: [['tofu', 200], ['zelenjava', 250], ['krompir', 200], ['olje', 10]], minutes: 30, contains: ['soja'],
    steps: ['Krompir in zelenjavo na kose daj na pekač z oljem in soljo, peci na 200 °C 20 min.', 'Tofu na kocke, pokapaj s sojino omako, dodaj na pekač in peci še 10 min.'] },
  { id: 'omleta-sir', name: 'Omleta z zelenjavo in sirom', tpl: 'vecerja', items: [['jajce', 3], ['zelenjava', 250], ['sir', 40], ['kruh', 40], ['olje', 5]], minutes: 15, contains: ['jajca', 'mleko', 'gluten'],
    steps: ['Zelenjavo na kocke in 4 min pražite na olju.', 'Prelij z razžvrkljanimi jajci, potresi s sirom, peci 3–4 min in preloži.', 'Postrezi s kruhom.'] },
  { id: 'pec-pisc', name: 'Pečen piščanec s pečeno zelenjavo', tpl: 'vecerja', items: [['piscanec', 150], ['zelenjava', 300], ['krompir', 200], ['olje', 10]], minutes: 35, contains: ['meso'],
    steps: ['Zelenjavo (bučke, paprika, čebula) in krompir na kose daj na pekač, pokapaj z oljem, posoli, dodaj rožmarin.', 'Piščanca posoli in popopraj, položi med zelenjavo.', 'Peci na 200 °C 25–30 min.'] },
  // malica
  { id: 'skuta-m', name: 'Skuta s sadjem', tpl: 'malica', items: [['skuta', 250], ['sadje', 150], ['oreski', 15]], minutes: 5, contains: ['mleko', 'oreski'],
    steps: ['Skuto zmešaj z malo jogurta ali mleka, da je mehkejša.', 'Dodaj narezano sadje in oreške.'] },
  { id: 'jogurt-m', name: 'Jogurt z banano in oreški', tpl: 'malica', items: [['jogurt', 250], ['banana', 1], ['oreski', 10]], minutes: 3, contains: ['mleko', 'oreski'],
    steps: ['Banano nareži v jogurt, potresi z oreški.'] },
  { id: 'kruh-skuta', name: 'Kruh s skuto in paradižnikom', tpl: 'malica', items: [['kruh', 60], ['skuta', 150], ['solata', 100]], minutes: 5, contains: ['mleko', 'gluten'],
    steps: ['Skuto posoli in namaži na kruh.', 'Obloži s paradižnikom in zeleno solato.'] },
  { id: 'kefir-m', name: 'Kefir z ovsenimi kosmiči', tpl: 'malica', items: [['kefir', 300], ['oves', 40], ['med', 10]], minutes: 3, contains: ['mleko', 'gluten'],
    steps: ['Kosmiče in med vmešaj v kefir; po 5 minutah so mehki.'] },
  { id: 'humus-m', name: 'Humus s kruhom in zelenjavo', tpl: 'malica', items: [['fizol', 150], ['kruh', 60], ['zelenjava', 100], ['olje', 10]], minutes: 8, contains: ['gluten'],
    steps: ['Čičeriko (odcejeno) zmelji z oljem, limono, česnom in soljo v namaz.', 'Namaži na kruh, zraven korenje ali papriko na palčke.'] },
  { id: 'banana-or', name: 'Banana z oreški in jabolkom', tpl: 'malica', items: [['banana', 1], ['oreski', 20], ['jabolko', 1]], minutes: 2, contains: ['oreski'],
    steps: ['Sadje nareži, zraven pest oreškov.'] },
  { id: 'cicerika-m', name: 'Hrustljava čičerika z jabolkom', tpl: 'malica', items: [['fizol', 150], ['jabolko', 1], ['olje', 5]], minutes: 25, contains: [],
    steps: ['Odcejeno čičeriko osuši, pokapaj z oljem, posoli in potresi s papriko v prahu.', 'Peci na 200 °C 20 min, da postane hrustljava (lahko za več dni naprej).', 'Zraven jabolko.'] },
  // pred vadbo
  { id: 'kruh-med', name: 'Kruh z medom in banana', tpl: 'pred', items: [['kruh', 60], ['med', 20], ['banana', 1]], minutes: 3, contains: ['gluten'],
    steps: ['Kruh namaži z medom, zraven banano.', '45–60 min pred vadbo; brez maščob in težke hrane.'] },
  { id: 'sadje-pred', name: 'Banana in jabolko', tpl: 'pred', items: [['banana', 1], ['jabolko', 1]], minutes: 1, contains: [],
    steps: ['Sadje pojej 30–45 min pred vadbo — lahki ogljikovi hidrati, nič težkega.'] },
  { id: 'oves-med', name: 'Ovseni kosmiči z mlekom in medom', tpl: 'pred', items: [['oves', 50], ['mleko', 200], ['med', 15]], minutes: 5, contains: ['mleko', 'gluten'],
    steps: ['Kosmiče zalij z mlekom, dodaj med; po želji kuhaj 2 min.'] },
  { id: 'banana-jog', name: 'Banana z jogurtom', tpl: 'pred', items: [['banana', 1], ['jogurt', 150], ['med', 10]], minutes: 2, contains: ['mleko'],
    steps: ['Banano nareži v jogurt, dodaj med. Lahko in hitro — uro pred vadbo.'] },
  // stročnice (večerja po jutranji vadbi)
  { id: 'fizol-enol', name: 'Fižolova enolončnica s kruhom', tpl: 'stroc', items: [['fizol', 250], ['kruh', 60], ['zelenjava', 200], ['cebula', 50], ['olje', 10]], minutes: 25, contains: ['gluten'],
    steps: ['Čebulo in česen prepraži na olju, dodaj narezano zelenjavo (korenje, paprika) in pražite 5 min.', 'Dodaj fižol s tekočino iz pločevinke in 2 dl vode, kuhaj 10 min; posoli, dodaj lovorov list.', 'Postrezi s kruhom.'] },
  { id: 'leca-juha', name: 'Lečina juha s krompirjem', tpl: 'stroc', items: [['leca', 250], ['zelenjava', 200], ['krompir', 150], ['cebula', 50], ['olje', 10]], minutes: 30, contains: [],
    steps: ['Čebulo, česen in korenje prepraži na olju 5 min.', 'Dodaj krompir na kocke, lečo in 5 dl vode; kuhaj 20 min, posoli in dodaj kumino.'] },
]
const PROTEIN_KEYS = new Set(['piscanec', 'tuna', 'jajce', 'skuta', 'jogurt', 'tofu', 'puran', 'losos', 'leca', 'fizol', 'kefir', 'sir', 'mleko'])


/** besede za sestavino (osnova) → kaj vsebuje */
const ING_WORDS: [RegExp, Contains][] = [
  [/\bmes[oa]\b|mesn|pi(?:š|s)(?:č|c)an|puran|govedin|svinjin|salam|(?:š|s)unk/u, 'meso'],
  [/\brib\p{L}*|tun[aeio]|losos|morsk/u, 'riba'],
  [/laktoz|mle(?:č|c)n|\bmlek|jogurt|skut|sir\b|sira\b|kefir/u, 'mleko'],
  [/gluten|celiak|p(?:š|s)eni(?:č|c)|kruh/u, 'gluten'],
  [/jajc/u, 'jajca'],
  [/ore(?:š|s)(?:k|č|c)|mandl|le(?:š|s)nik|arašid|arasid/u, 'oreski'],
  [/\bsoj|tofu/u, 'soja'],
]
const NEG = /ne maram|ne jem|brez|alergi|ne prenašam|ne prena(?:š|s)am|ne smem|sovra(?:ž|z)im|nikoli/u
const POS = /rad imam|rada imam|jem\b|lahko|mi pa(?:š|s)e|ni problem|ne (?:š|s)kodi|ne dela te(?:ž|z)av|nisem|ni alergij/u
/**
 * Prehranske želje iz besed po delih stavka: »vegetarijansko«, »brez laktoze«, »ne maram rib«, »alergija na oreške«,
 * »rad imam ribe, brez mleka« (ribe ostanejo, mleko izpade), »nisem vegetarijanec« (nič ne izpade).
 */
export function exclusionsOf(prefs: string | null | undefined): { contains: Contains[]; words: string[] } {
  const contains = new Set<Contains>()
  const words: string[] = []
  let carry = false   // »ne maram rib, piščanca, brokolija«: nikalnica velja še za naštevanje za vejico
  for (const c0 of (prefs || '').toLowerCase().split(/[,;.\n]+|\s+(?:in|pa|ampak|ter)\s+/u).map(x => x.trim()).filter(Boolean)) {
    const c = ` ${c0} `
    const neg = NEG.test(c), pos = POS.test(c)
    const bare = !neg && !pos && c0.split(/\s+/).length <= 2 && !/vege|vegan|laktoz|gluten|celiak/.test(c)
    if (/nisem|ni(?:sem)? vege|nisem vegan/.test(c)) { carry = false; continue }
    if (/vegan/.test(c) && !pos) { ['meso', 'riba', 'mleko', 'jajca'].forEach(x => contains.add(x as Contains)); carry = false; continue }
    if (/vege|brez mesa|mesa ne|ne jem mesa|ne maram mesa/.test(c) && !pos) { contains.add('meso'); contains.add('riba'); carry = false; continue }
    if (/laktoz|celiak|gluten/.test(c) && !pos && !/brez laktoze ni|brez glutena ni/.test(c)) { if (/laktoz/.test(c)) contains.add('mleko'); if (/gluten|celiak/.test(c)) contains.add('gluten') }
    if (!neg && !(bare && carry)) { carry = false; continue }
    carry = true
    // »ne maram X in Y«, »brez X, Y«: sestavine za nikalnico (ali naštevanje za njo)
    const after = neg ? c.split(NEG).slice(1).join(' ') : c
    for (const [rx, k] of ING_WORDS) if (rx.test(after)) contains.add(k)
    for (const m of after.matchAll(/[\p{L}]{4,}/gu)) {
      const w = m[0]
      if (/^(?:ne|na|za|brez|jem|jesti|maram|imam|alergij\p{L}*|nikoli|sploh|zelo|ni(?:č|c)|hran[aeo]|jedi|nobene|noben|problem\p{L}*|te(?:ž|z)av\p{L}*|vsega|lahko|smem|prena(?:š|s)am)$/u.test(w)) continue
      if (!ING_WORDS.some(([rx]) => rx.test(w))) words.push(w)
    }
  }
  return { contains: [...contains], words: [...new Set(words)] }
}
// groba osnova besede (brez končnice): »piščanca« → »pišča«, »brokolija« → »brokol«, »riža« → »riž«
const stem = (w: string) => w.toLowerCase().replace(/\(.*?\)/g, '').trim().slice(0, Math.max(3, w.length - 2))
/** Ali jed ustreza željam (brez izločenih sestavin in besed). */
export function dishOk(d: Dish, ex: ReturnType<typeof exclusionsOf>): boolean {
  if (d.contains.some(c => ex.contains.includes(c))) return false
  const tokens = `${d.name} ${d.items.map(([k]) => F[k]!.name.replace(/\(.*?\)/g, '')).join(' ')}`.toLowerCase().split(/[^\p{L}]+/u).filter(x => x.length >= 3)
  return !ex.words.some(w => { const st = stem(w); return tokens.some(tok => tok.startsWith(st) || st.startsWith(stem(tok))) })
}

export interface Recipe {
  dish: string; name: string; kcal: number; p: number; c: number; f: number; minutes: number
  ingredients: { key: string; qty: number; text: string }[]
  steps: string[]
  /** zakaj prav ta obrok zate */
  why: string
  /** vir: knjižnica (pravila) ali AI */
  by: 'pravila' | 'ai'
}
export interface RecipeCtx { deficit: boolean; keepMuscle: boolean; training: boolean; prefs?: string | null; /** zamik za »drug predlog« */ alt?: Record<string, number> }

const r1 = (x: number) => Math.round(x)
/** zgornje meje količin (na obrok), da beljakovine ne napihnejo jedi v nesmisel */
const CAP: Record<string, number> = { jajce: 5, skuta: 400, jogurt: 400, kefir: 500, mleko: 500, piscanec: 300, puran: 300, tuna: 250, losos: 250, tofu: 350, leca: 400, fizol: 400, sir: 80 }
/** največ, za koliko sme beljakovinski dodatek preseči kalorije obroka */
const KCAL_OVER = 1.15
const kcalOfItem = (x: { key: string; qty: number }) => (F[x.key]!.kcal * x.qty) / F[x.key]!.per
/**
 * Jed pomeri na obrok: najprej po kalorijah (×0,3–2), nato beljakovine — če jih je premalo (< 90 % obroka), gre gor
 * beljakovinsko najgostejša sestavina (do 2× osnove in do zgornje meje), ostale sorazmerno dol (ne pod 40 %), da kalorije
 * ostanejo; kalorije smejo čez obrok največ za 15 % (fižol ali jogurt se ne napihneta v nesmisel). Pri primanjkljaju olja
 * manj. Če beljakovin še vedno manjka, to pove besedilo »zakaj«, izbira jedi pa raje vzame tako, ki jih doseže (bestFits).
 */
export function fitDish(d: Dish, kcal: number, proteinG: number, ctx: Pick<RecipeCtx, 'deficit'>): Omit<Recipe, 'why' | 'by'> {
  const tot = (items: { key: string; qty: number }[]) => items.reduce((a, i) => { const f = F[i.key]!; return { k: a.k + (f.kcal * i.qty) / f.per, p: a.p + (f.p * i.qty) / f.per, c: a.c + (f.c * i.qty) / f.per, f: a.f + (f.f * i.qty) / f.per } }, { k: 0, p: 0, c: 0, f: 0 })
  const tpl: Tpl = ctx.deficit ? d.items.map(([k, q]) => (k === 'olje' ? [k, Math.max(5, q - 5)] : [k, q]) as [keyof typeof F, number]) : d.items
  const base = tpl.reduce((s, [k, q]) => s + (F[k]!.kcal * q) / F[k]!.per, 0)
  const k = Math.max(0.3, Math.min(2, kcal / base))
  let items = tpl.map(([key, q]) => ({ key: key as string, qty: qtyOf(key as string, q, k) }))
  let t = tot(items)
  // kos (banana, jajce) ne gre pod 1: če jed zato preseže obrok, ostale sestavine še malo dol
  if (t.k > kcal * 1.05) {
    const fixed = items.filter(x => x.qty === qtyOf(x.key, x.qty, 0.01))
    const fixedK = fixed.reduce((s, x) => s + kcalOfItem(x), 0)
    const restBase = tpl.filter(([key]) => !fixed.some(x => x.key === key)).reduce((s, [key, q]) => s + (F[key]!.kcal * q) / F[key]!.per, 0)
    if (fixed.length && restBase > 0) {
      const k2 = Math.max(0.3, Math.min(k, (kcal - fixedK) / restBase))
      items = tpl.map(([key, q]) => ({ key: key as string, qty: fixed.some(x => x.key === key) ? qtyOf(key as string, q, k) : qtyOf(key as string, q, k2) }))
      t = tot(items)
    }
  }
  // kos zaokrožen navzgor čez obrok (2 banani namesto 1,6): en kos manj, če je potem bližje obroku
  for (let n = 0; n < 4 && t.k > kcal * 1.1; n++) {
    const cand = items.map((x, i) => ({ x, i })).filter(({ x }) => F[x.key]!.unit === 'kos' && x.qty > 1).sort((a, b) => kcalOfItem(b.x) - kcalOfItem(a.x))[0]
    if (!cand) break
    const next = items.map((x, i) => (i === cand.i ? { ...x, qty: x.qty - 1 } : x))
    const tn = tot(next)
    if (Math.abs(tn.k - kcal) >= Math.abs(t.k - kcal)) break
    items = next; t = tn
  }
  // beljakovine: najgostejša beljakovinska sestavina (g beljakovin na kcal) gor, ostalo sorazmerno dol
  const pi = items.map((x, i) => ({ x, i })).filter(({ x }) => PROTEIN_KEYS.has(x.key)).sort((a, b) => F[b.x.key]!.p / F[b.x.key]!.kcal - F[a.x.key]!.p / F[a.x.key]!.kcal)[0]
  // velik obrok: ko je beljakovin precej čez cilj (skuta 450 g), gre beljakovinska sestavina nazaj proti osnovi, ostalo gor
  if (pi && t.p > proteinG * 1.3 && k > 1) {
    const f = F[pi.x.key]!
    const baseQ = tpl.find(([key]) => key === pi.x.key)![1]
    const perP = f.p / f.per, perK = f.kcal / f.per
    const otherP = t.p - perP * pi.x.qty
    const q2 = qtyOf(pi.x.key, Math.max(baseQ, Math.min(pi.x.qty, (proteinG * 1.15 - otherP) / perP)), 1)
    if (q2 < pi.x.qty) {
      const others = items.filter((_, i) => i !== pi.i)
      const restK = others.reduce((s, x) => s + kcalOfItem(x), 0)
      const g = restK > 0 ? Math.min(1.6, (kcal - perK * q2) / restK) : 1
      items = items.map((x, i) => (i === pi.i ? { ...x, qty: q2 } : g > 1 ? { ...x, qty: qtyOf(x.key, x.qty, g) } : x))
      t = tot(items)
    }
  }
  if (pi && t.p < proteinG * 0.9) {
    const f = F[pi.x.key]!
    const perK = f.kcal / f.per, perP = f.p / f.per
    const baseQ = tpl.find(([key]) => key === pi.x.key)![1]
    const need = proteinG * 0.95 - t.p
    const others = items.filter((_, i) => i !== pi.i)
    const restK = others.reduce((s, x) => s + kcalOfItem(x), 0)
    // kalorije ostalih sestavin, ko gredo na 40 % (kos ne pod 1) → koliko beljakovinske sestavine gre še v obrok
    const floorK = others.reduce((s, x) => s + kcalOfItem({ key: x.key, qty: qtyOf(x.key, x.qty, 0.4) }), 0)
    const maxQ = Math.min(baseQ * 2, CAP[pi.x.key] ?? baseQ * 2, (kcal * KCAL_OVER - floorK) / perK)
    let q2 = qtyOf(pi.x.key, Math.min(maxQ, pi.x.qty + need / perP), 1)
    // zaokrožitev navzgor čez mejo → korak dol
    const down = (q: number) => { const a = qtyOf(pi.x.key, q - (f.unit === 'kos' ? 1 : 5), 1); return a < q ? a : qtyOf(pi.x.key, q - 10, 1) }
    while (q2 > pi.x.qty && perK * q2 + floorK > kcal * KCAL_OVER + 1) { const n = down(q2); q2 = n < q2 ? n : pi.x.qty }
    // če tudi z dodatkom ne pride do 85 % beljakovin (fižol v humusu), jed ostane uravnotežena — izbira raje vzame drugo
    if (q2 > pi.x.qty && t.p + perP * (q2 - pi.x.qty) < proteinG * 0.85) q2 = pi.x.qty
    if (q2 > pi.x.qty) {
      const target = Math.max(0, kcal - perK * q2)
      const g = restK > 0 && target < restK ? Math.max(0.4, target / restK) : 1
      items = items.map((x, i) => (i === pi.i ? { ...x, qty: q2 } : g < 1 ? { ...x, qty: qtyOf(x.key, x.qty, g) } : x))
      t = tot(items)
    }
  }
  return { dish: d.id, name: d.name, kcal: r1(t.k), p: r1(t.p), c: r1(t.c), f: r1(t.f), minutes: d.minutes, ingredients: items.map(i => ({ ...i, text: qtyText(i.key, i.qty) })), steps: d.steps }
}

/** Zakaj ta obrok zate: beljakovine, OH glede na vadbo, primanjkljaj, mišice — iz številk obroka. */
export function whyRecipe(r: Pick<Recipe, 'p' | 'c' | 'f'>, slot: Pick<MealSlotPlan, 'key' | 'proteinG'>, ctx: RecipeCtx): string {
  const bits: string[] = []
  const short = r.p < slot.proteinG * 0.85
  bits.push(`${r.p} g beljakovin${short ? ` (obrok jih ima ~${slot.proteinG} — dodaj jogurt ali skuto)` : ctx.keepMuscle && ctx.deficit ? ' — da med hujšanjem mišice ostanejo' : ' za mišice in sitost'}`)
  if (slot.key === 'pred') bits.push(`${r.c} g lahkih ogljikovih hidratov za energijo na vadbi`)
  else if (slot.key === 'obnova') bits.push(`${r.c} g ogljikovih hidratov za obnovo po vadbi`)
  else if (ctx.training) bits.push(`${r.c} g ogljikovih hidratov — dan vadbe`)
  else bits.push(`${r.c} g ogljikovih hidratov — dan brez vadbe, zato manj`)
  if (ctx.deficit && r.f <= 18) bits.push('malo maščob: tu nastane tvoj primanjkljaj, ne na vadbi')
  return bits.join(' · ') + '.'
}

const dayOfYear = (iso: string) => { const d = /^\d{4}-\d{2}-\d{2}$/.test(iso) ? Math.floor((new Date(`${iso}T12:00:00`).getTime() - new Date(`${iso.slice(0, 4)}-01-01T12:00:00`).getTime()) / 86400_000) : 0; return Number.isFinite(d) ? d : 0 }
/** obrok, premajhen za recept (ostanek po pojedenem) */
export const MIN_RECIPE_KCAL = 150
/** Jedi za obrok po željah: izločene sestavine (alergije, vegetarijansko) veljajo vedno; če besede »ne maram X« izločijo vse, besede popustijo. */
export function dishesFor(tpl: string, prefs?: string | null): Dish[] {
  const all = DISHES.filter(d => d.tpl === tpl)
  const ex = exclusionsOf(prefs)
  const ok = all.filter(d => dishOk(d, ex))
  if (ok.length) return ok
  return all.filter(d => dishOk(d, { contains: ex.contains, words: [] }))
}
/**
 * Jedi obroka po ustreznosti: kalorije blizu obroku in beljakovine dosežene (manjko šteje dvojno). Vrne boljšo polovico
 * (vsaj 2, da se dnevi in »drug predlog« še razlikujejo) — malica s 40 g beljakovin tako dobi skuto, ne banane.
 */
export function bestFits(list: readonly Dish[], sl: Pick<MealSlotPlan, 'kcal' | 'proteinG'>, ctx: Pick<RecipeCtx, 'deficit'>): { d: Dish; fit: Omit<Recipe, 'why' | 'by'> }[] {
  const scored = list.map(d => {
    const fit = fitDish(d, sl.kcal, sl.proteinG, ctx)
    const score = Math.abs(fit.kcal - sl.kcal) / Math.max(1, sl.kcal) + (2 * Math.max(0, sl.proteinG * 0.9 - fit.p)) / Math.max(1, sl.proteinG)
    return { d, fit, score }
  }).sort((a, b) => a.score - b.score)
  // jedi, ki obrok res dosežejo (beljakovine ≥ 85 %, kalorije ±20 %); če jih ni dovolj, boljša polovica
  const good = scored.filter(x => x.fit.p >= sl.proteinG * 0.85 && Math.abs(x.fit.kcal - sl.kcal) <= sl.kcal * 0.2)
  const pick = good.length >= 2 ? good : scored.slice(0, Math.max(2, Math.ceil(scored.length / 2)))
  return pick.map(({ d, fit }) => ({ d, fit }))
}
/** Koliko jedi pride v poštev za obrok (za gumb »drug predlog«). */
export function dishChoices(sl: Pick<MealSlotPlan, 'kcal' | 'proteinG' | 'tpl' | 'key' | 'lf'>, ctx: RecipeCtx): number {
  if (sl.lf) return 1
  return bestFits(dishesFor(sl.tpl || sl.key, ctx.prefs), sl, ctx).length
}
/**
 * Recepti dneva po pravilih: vsak obrok dobi jed iz knjižnice (med ustreznimi vsak dan drugo, »drug predlog« naslednjo),
 * pomerjeno na kalorije in beljakovine obroka. Pred tekmo (malo vlaknin) obrok dobi preprosto jed z malo vlaknin.
 */
export function dayRecipes(dp: Pick<DayNutrition, 'slots'>, date: string, ctx: RecipeCtx): Record<string, Recipe> {
  const out: Record<string, Recipe> = {}
  const seed = dayOfYear(date)
  dp.slots.forEach((sl, i) => {
    if (sl.kcal < MIN_RECIPE_KCAL) return
    if (sl.lf) {
      const t = TPL_LF[sl.tpl || 'kosilo']
      if (!t) return
      const fit = fitDish({ id: `lf-${sl.key}`, name: 'Malo vlaknin pred tekmo', tpl: sl.tpl || 'kosilo', items: t, minutes: 15, contains: [], steps: ['Bel kruh, riž ali testenine, brez lupine in surove zelenjave; po navadni pripravi.'] }, sl.kcal, sl.proteinG, ctx)
      out[sl.key] = { ...fit, why: 'Malo vlaknin pred tekmo — želodec miren, OH visoki.', by: 'pravila' }
      return
    }
    const list = bestFits(dishesFor(sl.tpl || sl.key, ctx.prefs), sl, ctx)
    if (!list.length) return
    const { fit } = list[(seed + i + (ctx.alt?.[sl.key] || 0)) % list.length]!
    out[sl.key] = { ...fit, why: whyRecipe(fit, sl, ctx), by: 'pravila' }
  })
  return out
}
