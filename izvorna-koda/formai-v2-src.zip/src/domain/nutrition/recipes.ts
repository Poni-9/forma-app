import { F, qtyOf, qtyText, type Tpl, type MealSlotPlan, type DayNutrition } from './dayplan'

/**
 * RECEPTI (Blaž, 10. 10.: »pri hrani naj dobiš tudi recept — kaj ti priporoča jesti, koliko in kako se naredi«).
 * Vsak obrok dneva dobi jed iz knjižnice: sestavine z grami (iz navadne slovenske trgovine), priprava po korakih,
 * koliko minut in zakaj prav ta obrok zate (beljakovine, OH okoli vadbe, primanjkljaj, mišice). Količine so pomerjene
 * na kalorije in beljakovine obroka iz dnevnega cilja (energy.ts → dayplan.ts), zato se jed ne ponavlja dan za dnem
 * (vsak dan druga iz knjižnice) in se spremeni, ko se spremeni dan treninga. Brez AI; AI lahko doda svoje recepte
 * (actions.ts), ki gredo skozi iste varovalke (kalorije in beljakovine obroka).
 * Prehranske želje (»vegetarijansko«, »brez laktoze«, »ne maram rib«) izločijo jedi s temi sestavinami.
 */
export type Contains = 'meso' | 'riba' | 'mleko' | 'gluten' | 'jajca' | 'oreski' | 'soja'
export interface Dish { id: string; name: string; tpl: string; items: Tpl; steps: string[]; minutes: number; contains: Contains[]; /** prigrizek (shake): ne za glavni obrok */ snack?: boolean; /** samo, če po željah ni nobene druge jedi (malo beljakovin) */ fallback?: boolean }

export const DISHES: readonly Dish[] = [
  // zajtrk
  { id: 'kasa', name: 'Ovsena kaša z jogurtom in banano', tpl: 'zajtrk', items: [['oves', 70], ['jogurt', 200], ['banana', 1], ['med', 15]], minutes: 10, contains: ['mleko', 'gluten'],
    steps: ['Ovsene kosmiče zalij z vodo ali mlekom (2 : 1), kuhaj 3–4 min in mešaj, da se zgosti.', 'Odstavi, vmešaj polovico jogurta.', 'Na vrh banano na rezine, preostali jogurt in med.'] },
  { id: 'omleta-z', name: 'Omleta s kruhom in zelenjavo', tpl: 'zajtrk', items: [['jajce', 3], ['kruh', 60], ['zelenjava', 120], ['olje', 5]], minutes: 12, contains: ['jajca', 'gluten'],
    steps: ['Zelenjavo (papriko, paradižnik, špinačo) na kocke in 3 min praži na olju.', 'Jajca razžvrkljaj s ščepom soli, prelij čez zelenjavo in peci na srednjem ognju 3–4 min, nato preloži.', 'Postrezi s kruhom.'] },
  { id: 'skuta-z', name: 'Skuta s sadjem in oreški', tpl: 'zajtrk', items: [['skuta', 250], ['sadje', 150], ['oreski', 15], ['med', 10]], minutes: 5, contains: ['mleko', 'oreski'],
    steps: ['Skuto zmešaj z medom (po želji z žlico jogurta, da je mehkejša).', 'Sadje nareži in dodaj, potresi z oreški.'] },
  { id: 'jogurt-z', name: 'Jogurt z ovsenimi kosmiči in jabolkom', tpl: 'zajtrk', items: [['jogurt', 250], ['oves', 50], ['jabolko', 1], ['med', 10]], minutes: 5, contains: ['mleko', 'gluten'],
    steps: ['Kosmiče vmešaj v jogurt in pusti 5 min, da se zmehčajo (ali čez noč v hladilniku).', 'Jabolko na kocke, med po vrhu.'] },
  { id: 'kasa-voda', name: 'Ovsena kaša na vodi z banano in oreški', tpl: 'zajtrk', items: [['oves', 70], ['banana', 1], ['oreski', 15], ['med', 15]], minutes: 8, contains: ['gluten', 'oreski'],
    steps: ['Kosmiče zalij z vodo (2 : 1), kuhaj 3–4 min in mešaj.', 'Dodaj banano na rezine, oreške in med.'] },
  { id: 'tofu-z', name: 'Umešan tofu z zelenjavo in krompirjem', tpl: 'zajtrk', items: [['tofu', 200], ['zelenjava', 150], ['krompir', 150], ['olje', 10]], minutes: 20, contains: ['soja'],
    steps: ['Krompir na kocke kuhaj 10 min (ali uporabi kuhan od prej).', 'Tofu zdrobi z vilicami, praži na olju 4 min s ščepom soli, kurkume in popra.', 'Dodaj krompir in zelenjavo (paprika, špinača), praži še 5 min.'] },
  // (v3.48) več veganskih zajtrkov
  { id: 'tofu-kruh', name: 'Kruh s tofujem in paradižnikom', tpl: 'zajtrk', items: [['kruh', 80], ['tofu', 150], ['solata', 100], ['olje', 5]], minutes: 8, contains: ['gluten', 'soja'],
    steps: ['Tofu nareži na rezine, posoli in popeci na olju 2–3 min na vsaki strani.', 'Kruh obloži s tofujem, paradižnikom in zeleno solato.'] },
  // kosilo
  { id: 'pisc-riz', name: 'Piščanec z rižem in zelenjavo', tpl: 'kosilo', items: [['riz', 90], ['piscanec', 150], ['zelenjava', 200], ['cebula', 50], ['olje', 10]], minutes: 30, contains: ['meso'],
    steps: ['Riž skuhaj v dvojni količini slane vode (12–15 min).', 'Piščančje prsi nareži na trakove, posoli in popopraj; na olju jih peci 3 min na vsaki strani, nato jih vzemi iz ponve.', 'V isti ponvi prepraži čebulo in česen, dodaj zelenjavo (paprika, bučke, brokoli) in praži 5–6 min.', 'Vrni piščanca, premešaj, postrezi na rižu.'] },
  { id: 'test-tuna', name: 'Testenine s tuno in paradižnikovo omako', tpl: 'kosilo', items: [['testenine', 100], ['tuna', 120], ['omaka', 150], ['cebula', 40], ['olje', 5]], minutes: 20, contains: ['riba', 'gluten'],
    steps: ['Testenine skuhaj v slani vodi po navodilu (8–10 min).', 'Čebulo in česen prepraži na olju, dodaj paradižnikovo omako in kuhaj 5 min; začini z origanom.', 'Vmešaj odcejeno tuno, segrej in premešaj s testeninami.'] },
  { id: 'puran-kr', name: 'Puran s krompirjem in solato', tpl: 'kosilo', items: [['krompir', 300], ['puran', 150], ['solata', 200], ['olje', 10]], minutes: 30, contains: ['meso'],
    steps: ['Krompir olupi, nareži na kose in kuhaj 15–18 min (ali peci v pečici na 200 °C 25 min).', 'Puranje prsi posoli, popopraj in peci na olju 4 min na vsaki strani.', 'Solato in paradižnik zabeli z malo olja in kisa.'] },
  { id: 'cicerika', name: 'Čičerikin curry z rižem', tpl: 'kosilo', items: [['fizol', 250], ['riz', 80], ['zelenjava', 150], ['cebula', 50], ['olje', 10]], minutes: 25, contains: [],
    steps: ['Riž skuhaj (12–15 min).', 'Čebulo in česen prepraži na olju, dodaj žličko curryja in zelenjavo, praži 5 min.', 'Dodaj odcejeno čičeriko in 1 dl vode (ali kokosovega mleka), kuhaj 8 min; posoli.', 'Postrezi na rižu.'] },
  { id: 'losos-kr', name: 'Losos s krompirjem in zelenjavo', tpl: 'kosilo', items: [['losos', 150], ['krompir', 300], ['zelenjava', 200], ['olje', 5]], minutes: 30, contains: ['riba'],
    steps: ['Krompir na kose in zelenjavo daj na pekač z oljem, soljo in paprikinim prahom; peci na 200 °C 20 min.', 'Losos posoli in položi na pekač k zelenjavi, peci še 12 min.', 'Pokapaj z limono.'] },
  { id: 'tofu-riz', name: 'Tofu z rižem in zelenjavo', tpl: 'kosilo', items: [['tofu', 200], ['riz', 90], ['zelenjava', 200], ['cebula', 40], ['olje', 10]], minutes: 25, contains: ['soja'],
    steps: ['Riž skuhaj (12–15 min).', 'Tofu na kocke, popeci na olju do zlate barve (6–8 min), dodaj žlico sojine omake.', 'Dodaj čebulo, česen in zelenjavo, praži 5 min; postrezi na rižu.'] },
  // (v3.48) lahko vegetarijansko kosilo pred vožnjo (malo maščob, brez stročnic)
  { id: 'test-skuta', name: 'Testenine s skuto in paradižnikovo omako', tpl: 'kosilo', items: [['testenine', 100], ['skuta', 150], ['omaka', 150], ['olje', 5]], minutes: 15, contains: ['mleko', 'gluten'],
    steps: ['Testenine skuhaj v slani vodi po navodilu (8–10 min).', 'Omako segrej z oljem, česnom in origanom.', 'Odcejene testenine premešaj z omako, na vrh daj skuto.'] },
  { id: 'test-tofu', name: 'Testenine s tofujem in paradižnikovo omako', tpl: 'kosilo', items: [['testenine', 100], ['tofu', 150], ['omaka', 150], ['olje', 5]], minutes: 20, contains: ['soja', 'gluten'],
    steps: ['Testenine skuhaj v slani vodi po navodilu (8–10 min).', 'Tofu na kocke popeci na olju 5 min, dodaj omako in origano ter segrevaj 3 min.', 'Premešaj s testeninami.'] },
  // po vadbi (obnova)
  { id: 'test-tuna-o', name: 'Testenine s tuno in paradižnikovo omako', tpl: 'obnova', items: [['testenine', 100], ['tuna', 120], ['omaka', 150], ['olje', 5]], minutes: 20, contains: ['riba', 'gluten'],
    steps: ['Testenine skuhaj po navodilu (8–10 min).', 'Omako segrej z oljem in origanom, vmešaj odcejeno tuno.', 'Premešaj s testeninami — v 45 minutah po vadbi.'] },
  { id: 'riz-pisc-o', name: 'Riž s piščancem in zelenjavo', tpl: 'obnova', items: [['riz', 100], ['piscanec', 140], ['zelenjava', 150], ['olje', 5]], minutes: 25, contains: ['meso'],
    steps: ['Riž skuhaj (12–15 min).', 'Piščanca na trakove peci na olju 6–8 min, dodaj zelenjavo in praži še 5 min.', 'Posoli, premešaj z rižem.'] },
  { id: 'shake', name: 'Skutin shake z banano in ovsom', tpl: 'obnova', items: [['skuta', 200], ['banana', 1], ['mleko', 250], ['oves', 40], ['med', 10]], minutes: 5, contains: ['mleko', 'gluten'], snack: true,
    steps: ['Vse daj v mešalnik in zmešaj do gladkega.', 'Popij v 30 minutah po vadbi; če je pregosto, dodaj mleko.'] },
  { id: 'leca-riz', name: 'Leča z rižem in zelenjavo', tpl: 'obnova', items: [['leca', 250], ['riz', 70], ['zelenjava', 150], ['cebula', 40], ['olje', 5]], minutes: 25, contains: [],
    steps: ['Riž skuhaj (12–15 min).', 'Čebulo in česen prepraži, dodaj zelenjavo in kuhano lečo (iz pločevinke, odcejeno), segrevaj 8 min; posoli, dodaj kumino.', 'Postrezi na rižu.'] },
  // (v3.48) več vegetarijanskih in veganskih obrokov po vadbi — ne vsak dan »Leča z rižem«
  { id: 'test-tofu-o', name: 'Testenine s tofujem in paradižnikovo omako', tpl: 'obnova', items: [['testenine', 100], ['tofu', 150], ['omaka', 150], ['olje', 5]], minutes: 20, contains: ['soja', 'gluten'],
    steps: ['Testenine skuhaj po navodilu (8–10 min).', 'Tofu na kocke popeci na olju 5 min, dodaj omako in origano ter segrevaj 3 min.', 'Premešaj s testeninami — v 45 minutah po vadbi.'] },
  { id: 'kuskus-cic-o', name: 'Kuskus s čičeriko in zelenjavo', tpl: 'obnova', items: [['kuskus', 90], ['fizol', 200], ['zelenjava', 150], ['olje', 10]], minutes: 15, contains: ['gluten'],
    steps: ['Kuskus prelij z enako količino vrele slane vode, pokrij in pusti 5 min; razrahljaj z vilicami.', 'Zelenjavo na kocke praži na olju 5 min, dodaj odcejeno čičeriko in kumino ter segrevaj 3 min.', 'Premešaj s kuskusom — v 45 minutah po vadbi.'] },
  { id: 'krompir-cic-o', name: 'Pečen krompir s čičeriko in zelenjavo', tpl: 'obnova', items: [['krompir', 350], ['fizol', 200], ['zelenjava', 150], ['olje', 10]], minutes: 30, contains: [],
    steps: ['Krompir na kose, odcejeno čičeriko in zelenjavo daj na pekač, pokapaj z oljem, posoli in potresi s papriko v prahu.', 'Peci na 200 °C 25 min, vmes enkrat premešaj.'] },
  { id: 'test-jajca-o', name: 'Testenine z jajci, zelenjavo in sirom', tpl: 'obnova', items: [['testenine', 100], ['jajce', 2], ['sir', 30], ['zelenjava', 100], ['olje', 5]], minutes: 15, contains: ['jajca', 'mleko', 'gluten'],
    steps: ['Testenine skuhaj po navodilu (8–10 min).', 'Zelenjavo na kocke praži na olju 4 min, dodaj odcejene testenine.', 'Vmešaj razžvrkljana jajca in nariban sir, mešaj na nizkem ognju 1–2 min, da se jajca strdijo.'] },
  // večerja
  { id: 'krompir-jajca', name: 'Krompir z jajci in zelenjavo', tpl: 'vecerja', items: [['krompir', 300], ['jajce', 3], ['zelenjava', 250], ['olje', 10]], minutes: 25, contains: ['jajca'],
    steps: ['Krompir skuhaj v olupku (20 min), olupi in nareži na kolobarje.', 'Na olju popeci krompir 5 min, dodaj zelenjavo in praži še 5 min.', 'Prelij z razžvrkljanimi jajci in peci 3–4 min; posoli.'] },
  { id: 'solata-tuna', name: 'Solata s tuno in fižolom', tpl: 'vecerja', items: [['tuna', 120], ['fizol', 200], ['solata', 250], ['kruh', 40], ['olje', 10]], minutes: 10, contains: ['riba', 'gluten'],
    steps: ['Solato in paradižnik nareži, dodaj odcejen fižol in tuno.', 'Zabeli z oljem, kisom ali limono, soljo in poprom.', 'Postrezi s kruhom.'] },
  { id: 'tofu-zel', name: 'Tofu s pečeno zelenjavo in krompirjem', tpl: 'vecerja', items: [['tofu', 200], ['zelenjava', 250], ['krompir', 200], ['olje', 10]], minutes: 30, contains: ['soja'],
    steps: ['Krompir in zelenjavo na kose daj na pekač z oljem in soljo, peci na 200 °C 20 min.', 'Tofu na kocke, pokapaj s sojino omako, dodaj na pekač in peci še 10 min.'] },
  { id: 'omleta-sir', name: 'Omleta z zelenjavo in sirom', tpl: 'vecerja', items: [['jajce', 3], ['zelenjava', 250], ['sir', 40], ['kruh', 40], ['olje', 5]], minutes: 15, contains: ['jajca', 'mleko', 'gluten'],
    steps: ['Zelenjavo na kocke in 4 min praži na olju.', 'Prelij z razžvrkljanimi jajci, potresi s sirom, peci 3–4 min in preloži.', 'Postrezi s kruhom.'] },
  { id: 'pec-pisc', name: 'Pečen piščanec s pečeno zelenjavo', tpl: 'vecerja', items: [['piscanec', 150], ['zelenjava', 300], ['krompir', 200], ['olje', 10]], minutes: 35, contains: ['meso'],
    steps: ['Zelenjavo (bučke, paprika, čebula) in krompir na kose daj na pekač, pokapaj z oljem, posoli, dodaj rožmarin.', 'Piščanca posoli in popopraj, položi med zelenjavo.', 'Peci na 200 °C 25–30 min.'] },
  // malica
  { id: 'skuta-m', name: 'Skuta s sadjem', tpl: 'malica', items: [['skuta', 250], ['sadje', 150], ['oreski', 15]], minutes: 5, contains: ['mleko', 'oreski'],
    steps: ['Skuto zmešaj z malo jogurta ali mleka, da je mehkejša.', 'Dodaj narezano sadje in oreške.'] },
  { id: 'jogurt-m', name: 'Jogurt z banano in oreški', tpl: 'malica', items: [['jogurt', 250], ['banana', 1], ['oreski', 10]], minutes: 3, contains: ['mleko', 'oreski'],
    steps: ['Banano nareži v jogurt, potresi z oreški.'] },
  { id: 'kruh-skuta', name: 'Kruh s skuto in paradižnikom', tpl: 'malica', items: [['kruh', 60], ['skuta', 150], ['solata', 100]], minutes: 5, contains: ['mleko', 'gluten'],
    steps: ['Skuto posoli in namaži na kruh.', 'Obloži s paradižnikom in zeleno solato.'] },
  { id: 'kefir-m', name: 'Kefir z ovsenimi kosmiči', tpl: 'malica', items: [['kefir', 300], ['oves', 40], ['med', 10]], minutes: 3, contains: ['mleko', 'gluten'],
    steps: ['Kosmiče in med vmešaj v kefir; po 5 minutah so mehki.'] },
  { id: 'humus-m', name: 'Humus s kruhom in zelenjavo', tpl: 'malica', items: [['fizol', 150], ['kruh', 60], ['zelenjava', 100], ['olje', 10]], minutes: 8, contains: ['gluten'],
    steps: ['Čičeriko (odcejeno) zmelji z oljem, limono, česnom in soljo v namaz.', 'Namaži na kruh, zraven korenje ali papriko na palčke.'] },
  { id: 'banana-or', name: 'Banana z oreški in jabolkom', tpl: 'malica', items: [['banana', 1], ['oreski', 20], ['jabolko', 1]], minutes: 2, contains: ['oreski'],
    steps: ['Sadje nareži, zraven pest oreškov.'] },
  { id: 'cicerika-m', name: 'Hrustljava čičerika z jabolkom', tpl: 'malica', items: [['fizol', 150], ['jabolko', 1], ['olje', 5]], minutes: 25, contains: [],
    steps: ['Odcejeno čičeriko osuši, pokapaj z oljem, posoli in potresi s papriko v prahu.', 'Peci na 200 °C 20 min, da postane hrustljava (lahko za več dni naprej).', 'Zraven jabolko.'] },
  // pred vadbo
  { id: 'kruh-med', name: 'Kruh z medom in banana', tpl: 'pred', items: [['kruh', 60], ['med', 20], ['banana', 1]], minutes: 3, contains: ['gluten'],
    steps: ['Kruh namaži z medom, zraven banano.', '45–60 min pred vadbo; brez maščob in težke hrane.'] },
  { id: 'sadje-pred', name: 'Banana in jabolko', tpl: 'pred', items: [['banana', 1], ['jabolko', 1]], minutes: 1, contains: [],
    steps: ['Sadje pojej 30–45 min pred vadbo — lahki ogljikovi hidrati, nič težkega.'] },
  { id: 'oves-med', name: 'Ovseni kosmiči z mlekom in medom', tpl: 'pred', items: [['oves', 50], ['mleko', 200], ['med', 15]], minutes: 5, contains: ['mleko', 'gluten'],
    steps: ['Kosmiče zalij z mlekom, dodaj med; po želji kuhaj 2 min.'] },
  { id: 'banana-jog', name: 'Banana z jogurtom', tpl: 'pred', items: [['banana', 1], ['jogurt', 150], ['med', 10]], minutes: 2, contains: ['mleko'],
    steps: ['Banano nareži v jogurt, dodaj med. Lahko in hitro — uro pred vadbo.'] },
  // stročnice (večerja po jutranji vadbi)
  { id: 'fizol-enol', name: 'Fižolova enolončnica s kruhom', tpl: 'stroc', items: [['fizol', 250], ['kruh', 60], ['zelenjava', 200], ['cebula', 50], ['olje', 10]], minutes: 25, contains: ['gluten'],
    steps: ['Čebulo in česen prepraži na olju, dodaj narezano zelenjavo (korenje, paprika) in praži 5 min.', 'Dodaj fižol s tekočino iz pločevinke in 2 dl vode, kuhaj 10 min; posoli, dodaj lovorov list.', 'Postrezi s kruhom.'] },
  { id: 'leca-juha', name: 'Lečina juha s krompirjem', tpl: 'stroc', items: [['leca', 250], ['zelenjava', 200], ['krompir', 150], ['cebula', 50], ['olje', 10]], minutes: 30, contains: [],
    steps: ['Čebulo, česen in korenje prepraži na olju 5 min.', 'Dodaj krompir na kocke, lečo in 5 dl vode; kuhaj 20 min, posoli in dodaj kumino.'] },
]
/**
 * PRED TEKMO: jedi z malo vlaknin (v3.48) — prava imena in koraki, po prehranskih željah kot ostale jedi.
 * Samo bel kruh, bel riž, bele testenine, krompir brez lupine, zrela banana, med, marmelada, mlečni izdelki, jajca,
 * meso, riba, tofu; brez zelenjave, stročnic, oreškov in sadja z lupino. Za vsak obrok je jed brez živil, ki jih
 * želje izločijo (contains: []), da se obrok vedno pomeri.
 */
export const LF_DISHES: readonly Dish[] = [
  // zajtrk
  { id: 'lf-kruh-jogurt', name: 'Bel kruh z marmelado in jogurtom', tpl: 'zajtrk', items: [['belkruh', 100], ['marmelada', 30], ['jogurt', 200], ['banana', 1]], minutes: 3, contains: ['gluten', 'mleko'],
    steps: ['Bel kruh ali žemljo namaži z marmelado.', 'Zraven jogurt in zrela banana.'] },
  { id: 'lf-riz-mleko', name: 'Mlečni riž z banano in medom', tpl: 'zajtrk', items: [['rizb', 80], ['mleko', 300], ['banana', 1], ['med', 15]], minutes: 25, contains: ['mleko'],
    steps: ['Bel riž kuhaj v mleku 20–25 min na nizkem ognju; mešaj, da se ne prime (lahko že zvečer).', 'Sladkaj z medom, zraven zrela banana na rezine.'] },
  { id: 'lf-jajca-kruh', name: 'Umešana jajca z belim kruhom', tpl: 'zajtrk', items: [['jajce', 3], ['belkruh', 100], ['med', 15], ['olje', 5]], minutes: 8, contains: ['jajca', 'gluten'],
    steps: ['Jajca razžvrkljaj s ščepom soli in jih na olju umešaj 2–3 min.', 'Zraven bel kruh z medom.'] },
  { id: 'lf-tofu-kruh', name: 'Umešan tofu z belim kruhom', tpl: 'zajtrk', items: [['tofu', 150], ['belkruh', 100], ['marmelada', 20], ['olje', 5]], minutes: 8, contains: ['soja', 'gluten'],
    steps: ['Tofu zdrobi z vilicami in ga na olju praži 4 min s ščepom soli in kurkume.', 'Zraven bel kruh z marmelado.'] },
  { id: 'lf-riz-banana', name: 'Riž z banano in medom', tpl: 'zajtrk', items: [['rizb', 80], ['banana', 1], ['med', 20]], minutes: 15, contains: [], fallback: true,
    steps: ['Bel riž skuhaj v vodi (12–15 min).', 'Primešaj zrelo banano na rezine in med.'] },
  // kosilo
  { id: 'lf-pisc-riz', name: 'Bel riž s piščancem', tpl: 'kosilo', items: [['rizb', 110], ['piscanec', 150], ['olje', 10]], minutes: 20, contains: ['meso'],
    steps: ['Bel riž skuhaj v dvojni količini slane vode (12–15 min).', 'Piščanca nareži na trakove, posoli in ga na olju peci 3 min na vsaki strani.', 'Postrezi na rižu — brez solate in surove zelenjave.'] },
  { id: 'lf-test-tuna', name: 'Bele testenine s tuno in paradižnikovo omako', tpl: 'kosilo', items: [['testenineb', 110], ['tuna', 120], ['omaka', 150], ['olje', 5]], minutes: 15, contains: ['riba', 'gluten'],
    steps: ['Bele testenine skuhaj v slani vodi po navodilu (8–10 min).', 'Omako segrej z oljem in origanom, vmešaj odcejeno tuno.', 'Premešaj s testeninami.'] },
  { id: 'lf-tofu-riz', name: 'Bel riž s tofujem', tpl: 'kosilo', items: [['rizb', 110], ['tofu', 180], ['olje', 10]], minutes: 20, contains: ['soja'],
    steps: ['Bel riž skuhaj (12–15 min).', 'Tofu na kocke popeci na olju do zlate barve (6–8 min), dodaj žlico sojine omake.', 'Postrezi na rižu.'] },
  { id: 'lf-riz-jajca', name: 'Bel riž z jajci', tpl: 'kosilo', items: [['rizb', 110], ['jajce', 3], ['olje', 5]], minutes: 18, contains: ['jajca'],
    steps: ['Bel riž skuhaj (12–15 min).', 'Jajca razžvrkljaj, na olju jih umešaj 2–3 min in premešaj z rižem; posoli.'] },
  { id: 'lf-riz-omaka', name: 'Bel riž s paradižnikovo omako', tpl: 'kosilo', items: [['rizb', 110], ['omaka', 200], ['olje', 10]], minutes: 15, contains: [], fallback: true,
    steps: ['Bel riž skuhaj (12–15 min).', 'Omako segrej z oljem, soljo in baziliko ter jo prelij čez riž.'] },
  // po vadbi (obnova)
  { id: 'lf-test-tuna-o', name: 'Bele testenine s tuno', tpl: 'obnova', items: [['testenineb', 110], ['tuna', 120], ['omaka', 150], ['olje', 5]], minutes: 15, contains: ['riba', 'gluten'],
    steps: ['Bele testenine skuhaj po navodilu (8–10 min).', 'Omako segrej z oljem, vmešaj odcejeno tuno in premešaj s testeninami.'] },
  { id: 'lf-pisc-pire-o', name: 'Piščanec s pire krompirjem', tpl: 'obnova', items: [['krompirb', 350], ['piscanec', 140], ['olje', 5]], minutes: 25, contains: ['meso'],
    steps: ['Krompir olupi, nareži in kuhaj 15–18 min; odcedi in pretlači z žlico olja in soljo.', 'Piščanca na trakove peci na olju 6–8 min.'] },
  { id: 'lf-tofu-test-o', name: 'Bele testenine s tofujem in paradižnikovo omako', tpl: 'obnova', items: [['testenineb', 110], ['tofu', 150], ['omaka', 150], ['olje', 5]], minutes: 20, contains: ['soja', 'gluten'],
    steps: ['Bele testenine skuhaj po navodilu (8–10 min).', 'Tofu na kocke popeci na olju 5 min, dodaj omako in segrevaj 3 min.', 'Premešaj s testeninami.'] },
  { id: 'lf-riz-jajca-o', name: 'Bel riž z jajci', tpl: 'obnova', items: [['rizb', 100], ['jajce', 3], ['olje', 5]], minutes: 18, contains: ['jajca'],
    steps: ['Bel riž skuhaj (12–15 min).', 'Jajca razžvrkljaj, na olju jih umešaj 2–3 min in premešaj z rižem; posoli.'] },
  { id: 'lf-pire-omaka-o', name: 'Pire krompir s paradižnikovo omako', tpl: 'obnova', items: [['krompirb', 400], ['omaka', 150], ['olje', 10]], minutes: 25, contains: [], fallback: true,
    steps: ['Krompir olupi, kuhaj 15–18 min in pretlači z oljem in soljo.', 'Zraven segreta paradižnikova omaka.'] },
  // večerja (tudi po jutranji vadbi)
  { id: 'lf-krompir-jajca', name: 'Krompir brez lupine z jajci', tpl: 'vecerja', items: [['krompirb', 400], ['jajce', 3], ['olje', 10]], minutes: 25, contains: ['jajca'],
    steps: ['Krompir olupi, nareži in kuhaj 15–18 min; odcedi.', 'Na olju ga popeci 5 min, prelij z razžvrkljanimi jajci in peci 3–4 min; posoli.'] },
  { id: 'lf-losos-pire', name: 'Losos s pire krompirjem', tpl: 'vecerja', items: [['krompirb', 350], ['losos', 130], ['olje', 5]], minutes: 25, contains: ['riba'],
    steps: ['Krompir olupi, kuhaj 15–18 min in pretlači z žlico olja in soljo.', 'Losos posoli in peci v pečici na 200 °C 12–15 min (ali v ponvi 4 min na vsaki strani).'] },
  { id: 'lf-test-pisc-v', name: 'Bele testenine s piščancem', tpl: 'vecerja', items: [['testenineb', 100], ['piscanec', 130], ['omaka', 150], ['olje', 5]], minutes: 20, contains: ['meso', 'gluten'],
    steps: ['Bele testenine skuhaj po navodilu (8–10 min).', 'Piščanca na kocke peci na olju 6 min, dodaj omako in segrevaj 3 min.', 'Premešaj s testeninami.'] },
  { id: 'lf-tofu-krompir', name: 'Tofu s krompirjem brez lupine', tpl: 'vecerja', items: [['krompirb', 350], ['tofu', 180], ['olje', 10]], minutes: 25, contains: ['soja'],
    steps: ['Krompir olupi, nareži in kuhaj 15–18 min; odcedi.', 'Tofu na kocke popeci na olju 6–8 min, dodaj krompir in praži še 3 min; posoli.'] },
  { id: 'lf-krompir-omaka', name: 'Krompir brez lupine s paradižnikovo omako', tpl: 'vecerja', items: [['krompirb', 400], ['omaka', 150], ['olje', 10]], minutes: 25, contains: [], fallback: true,
    steps: ['Krompir olupi, nareži in kuhaj 15–18 min; odcedi.', 'Prelij s segreto paradižnikovo omako in oljem; posoli.'] },
  // malica
  { id: 'lf-skuta-banana', name: 'Skuta z banano in medom', tpl: 'malica', items: [['skuta', 200], ['banana', 1], ['med', 20]], minutes: 3, contains: ['mleko'],
    steps: ['Skuto zmešaj z medom (po želji z žlico jogurta, da je mehkejša).', 'Zraven zrela banana.'] },
  { id: 'lf-jogurt-banana', name: 'Jogurt z banano in medom', tpl: 'malica', items: [['jogurt', 250], ['banana', 1], ['med', 15]], minutes: 2, contains: ['mleko'],
    steps: ['Banano nareži v jogurt, dodaj med.'] },
  { id: 'lf-kruh-marmelada', name: 'Bel kruh z marmelado', tpl: 'malica', items: [['belkruh', 80], ['marmelada', 30]], minutes: 2, contains: ['gluten'],
    steps: ['Bel kruh ali žemljo namaži z marmelado.'] },
  { id: 'lf-banana-med', name: 'Banana z medom', tpl: 'malica', items: [['banana', 2], ['med', 15]], minutes: 2, contains: [], fallback: true,
    steps: ['Zrelo banano nareži in pokapaj z medom.'] },
  // pred vadbo
  { id: 'lf-kruh-med-p', name: 'Bel kruh z medom in banano', tpl: 'pred', items: [['belkruh', 60], ['med', 20], ['banana', 1]], minutes: 3, contains: ['gluten'],
    steps: ['Bel kruh namaži z medom, zraven zrela banana.', '45–60 min pred vadbo; brez maščob in težke hrane.'] },
  { id: 'lf-banana-jog-p', name: 'Banana z jogurtom', tpl: 'pred', items: [['banana', 1], ['jogurt', 150], ['med', 10]], minutes: 2, contains: ['mleko'],
    steps: ['Banano nareži v jogurt, dodaj med — uro pred vadbo.'] },
  { id: 'lf-banana-p', name: 'Banana z medom', tpl: 'pred', items: [['banana', 1], ['med', 15]], minutes: 1, contains: [],
    steps: ['Zrela banana in žlička medu 30–45 min pred vadbo.'] },
]
/** predloga obroka → jedi z malo vlakninami (večerja po jutranji vadbi je večerja) */
const lfTplOf = (tpl: string) => (tpl === 'stroc' ? 'vecerja' : tpl)
const PROTEIN_KEYS = new Set(['piscanec', 'tuna', 'jajce', 'skuta', 'jogurt', 'tofu', 'puran', 'losos', 'leca', 'fizol', 'kefir', 'sir', 'mleko'])


/** besede za sestavino (osnova) → kaj vsebuje */
const ING_WORDS: [RegExp, Contains][] = [
  // (v3.48) svinjina, govedina, salama, šunka niso »vse meso«: gredo med besede (izločijo jedi s tem imenom), piščanec in puran ostaneta
  [/\bmes[oa]\b|mesn|pi(?:š|s)(?:č|c)an|puran/u, 'meso'],
  [/\brib\p{L}*|tun[aeio]|losos|morsk/u, 'riba'],
  [/laktoz|mle(?:č|c)n|\bmlek|jogurt|skut|sir\b|sira\b|kefir/u, 'mleko'],
  [/gluten|celiak|p(?:š|s)eni(?:č|c)|kruh/u, 'gluten'],
  [/jajc/u, 'jajca'],
  [/ore(?:š|s)(?:k|č|c)|mandl|le(?:š|s)nik|arašid|arasid/u, 'oreski'],
  [/\bsoj|tofu/u, 'soja'],
]
const NEG = /ne maram|ne jem|brez|alergi|ne prenašam|ne prena(?:š|s)am|ne smem|sovra(?:ž|z)im|nikoli/u
const POS = /rad imam|rada imam|jem\b|lahko|mi pa(?:š|s)e|ni problem|ne (?:š|s)kodi|ne dela te(?:ž|z)av|nisem|ni alergij/u
/**
 * Prehranske želje iz besed po delih stavka: »vegetarijansko«, »brez laktoze«, »ne maram rib«, »alergija na oreške«,
 * »rad imam ribe, brez mleka« (ribe ostanejo, mleko izpade), »nisem vegetarijanec« (nič ne izpade).
 */
export function exclusionsOf(prefs: string | null | undefined): { contains: Contains[]; words: string[] } {
  const contains = new Set<Contains>()
  const words: string[] = []
  let carry = false   // »ne maram rib, piščanca, brokolija«: nikalnica velja še za naštevanje za vejico
  for (const c0 of (prefs || '').toLowerCase().split(/[,;.\n]+|\s+(?:in|pa|ampak|ter)\s+/u).map(x => x.trim()).filter(Boolean)) {
    const c = ` ${c0} `
    const neg = NEG.test(c), pos = POS.test(c)
    const bare = !neg && !pos && c0.split(/\s+/).length <= 2 && !/vege|vegan|laktoz|gluten|celiak/.test(c)
    if (/nisem|ni(?:sem)? vege|nisem vegan/.test(c)) { carry = false; continue }
    if (/vegan/.test(c) && !pos) { ['meso', 'riba', 'mleko', 'jajca'].forEach(x => contains.add(x as Contains)); carry = false; continue }
    if (/vege|brez mesa|mesa ne|ne jem mesa|ne maram mesa/.test(c) && !pos) { contains.add('meso'); contains.add('riba'); carry = false; continue }
    if (/laktoz|celiak|gluten/.test(c) && !pos && !/brez laktoze ni|brez glutena ni/.test(c)) { if (/laktoz/.test(c)) contains.add('mleko'); if (/gluten|celiak/.test(c)) contains.add('gluten') }
    if (!neg && !(bare && carry)) { carry = false; continue }
    carry = true
    // »ne maram X in Y«, »brez X, Y«: sestavine za nikalnico (ali naštevanje za njo)
    const after = neg ? c.split(NEG).slice(1).join(' ') : c
    for (const [rx, k] of ING_WORDS) if (rx.test(after)) contains.add(k)
    for (const m of after.matchAll(/[\p{L}]{4,}/gu)) {
      const w = m[0]
      if (/^(?:ne|na|za|brez|jem|jesti|maram|imam|alergij\p{L}*|nikoli|sploh|zelo|ni(?:č|c)|hran[aeo]|jedi|nobene|noben|problem\p{L}*|te(?:ž|z)av\p{L}*|vsega|lahko|smem|prena(?:š|s)am)$/u.test(w)) continue
      if (!ING_WORDS.some(([rx]) => rx.test(w))) words.push(w)
    }
  }
  return { contains: [...contains], words: [...new Set(words)] }
}
// groba osnova besede (brez končnice): »piščanca« → »pišča«, »brokolija« → »brokol«, »riža« → »riž«
const stem = (w: string) => w.toLowerCase().replace(/\(.*?\)/g, '').trim().slice(0, Math.max(3, w.length - 2))
/** Ali jed ustreza željam (brez izločenih sestavin in besed). */
export function dishOk(d: Dish, ex: ReturnType<typeof exclusionsOf>): boolean {
  if (d.contains.some(c => ex.contains.includes(c))) return false
  const tokens = `${d.name} ${d.items.map(([k]) => F[k]!.name.replace(/\(.*?\)/g, '')).join(' ')}`.toLowerCase().split(/[^\p{L}]+/u).filter(x => x.length >= 3)
  return !ex.words.some(w => { const st = stem(w); return tokens.some(tok => tok.startsWith(st) || st.startsWith(stem(tok))) })
}

export interface Recipe {
  dish: string; name: string; kcal: number; p: number; c: number; f: number; minutes: number
  ingredients: { key: string; qty: number; text: string; /** dodatek k jedi (kruh, banana, jogurt), da obrok doseže svoje */ side?: boolean }[]
  steps: string[]
  /** zakaj prav ta obrok zate */
  why: string
  /** vir: knjižnica (pravila) ali AI */
  by: 'pravila' | 'ai'
}
export interface RecipeCtx { deficit: boolean; keepMuscle: boolean; training: boolean; prefs?: string | null; /** zamik za »drug predlog« */ alt?: Record<string, number> }

const r1 = (x: number) => Math.round(x)
/** zgornje meje količin (na obrok), da beljakovine ne napihnejo jedi v nesmisel */
const CAP: Record<string, number> = { jajce: 4, skuta: 250, jogurt: 350, kefir: 400, mleko: 400, piscanec: 220, puran: 220, tuna: 160, losos: 200, tofu: 250, leca: 300, fizol: 300, sir: 50 }
/**
 * REALNE PORCIJE (Blaž, 16. 10.: »za jest naj bo realno … ne na hojladri«): največ, kar človek poje v enem obroku.
 * Prej se je jed samo sorazmerno napihnila (zajtrk: 350 g skute in 340 g sadja); zdaj sestavina ne gre čez mero —
 * kar obroku manjka, doda dodatek, kot bi ga dal vsak (rezina kruha, banana, lonček jogurta).
 */
export const PORTION_MAX: Record<string, number> = {
  oves: 100, jogurt: 350, banana: 2, med: 25, kruh: 120, riz: 130, testenine: 140, krompir: 450, piscanec: 220, tuna: 160, jajce: 4,
  skuta: 250, mleko: 400, olje: 15, oreski: 30, zelenjava: 350, sadje: 300, omaka: 250, fizol: 300, belkruh: 150, marmelada: 40,
  rizb: 140, testenineb: 150, krompirb: 500, puran: 220, losos: 200, tofu: 250, leca: 300, kefir: 400, sir: 50, cebula: 60, solata: 300, jabolko: 2, kuskus: 130,
}
/** največ, za koliko sme beljakovinski dodatek preseči kalorije obroka */
const KCAL_OVER = 1.15
const kcalOfItem = (x: { key: string; qty: number }) => (F[x.key]!.kcal * x.qty) / F[x.key]!.per
/**
 * Jed pomeri na obrok: najprej po kalorijah (×0,3–2), nato beljakovine — če jih je premalo (< 90 % obroka), gre gor
 * beljakovinsko najgostejša sestavina (do 2× osnove in do zgornje meje), ostale sorazmerno dol (ne pod 40 %), da kalorije
 * ostanejo; kalorije smejo čez obrok največ za 15 % (fižol ali jogurt se ne napihneta v nesmisel). Pri primanjkljaju olja
 * manj. Če beljakovin še vedno manjka, to pove besedilo »zakaj«, izbira jedi pa raje vzame tako, ki jih doseže (bestFits).
 * (v3.48) Pred tekmo (lf) dodatki brez vlaknin (bel kruh, banana); pred vožnjo (beforeRide) tudi, zelenjave in solate
 * največ 150 g in olja manj.
 */
export type FitCtx = Pick<RecipeCtx, 'deficit'> & Partial<Pick<RecipeCtx, 'prefs'>> & { lf?: boolean; beforeRide?: boolean }
export function fitDish(d: Dish, kcal: number, proteinG: number, ctx: FitCtx, carbsG?: number): Omit<Recipe, 'why' | 'by'> {
  const tot = (items: { key: string; qty: number }[]) => items.reduce((a, i) => { const f = F[i.key]!; return { k: a.k + (f.kcal * i.qty) / f.per, p: a.p + (f.p * i.qty) / f.per, c: a.c + (f.c * i.qty) / f.per, f: a.f + (f.f * i.qty) / f.per } }, { k: 0, p: 0, c: 0, f: 0 })
  const light = !!(ctx.lf || ctx.beforeRide)
  const tpl: Tpl = ctx.deficit || ctx.beforeRide ? d.items.map(([k, q]) => (k === 'olje' ? [k, Math.max(5, q - 5)] : [k, q]) as [keyof typeof F, number]) : d.items
  const base = tpl.reduce((s, [k, q]) => s + (F[k]!.kcal * q) / F[k]!.per, 0)
  const k = Math.max(0.3, Math.min(2, kcal / base))
  let items = tpl.map(([key, q]) => ({ key: key as string, qty: qtyOf(key as string, q, k) }))
  let t = tot(items)
  // kos (banana, jajce) ne gre pod 1: če jed zato preseže obrok, ostale sestavine še malo dol
  if (t.k > kcal * 1.05) {
    const fixed = items.filter(x => x.qty === qtyOf(x.key, x.qty, 0.01))
    const fixedK = fixed.reduce((s, x) => s + kcalOfItem(x), 0)
    const restBase = tpl.filter(([key]) => !fixed.some(x => x.key === key)).reduce((s, [key, q]) => s + (F[key]!.kcal * q) / F[key]!.per, 0)
    if (fixed.length && restBase > 0) {
      const k2 = Math.max(0.3, Math.min(k, (kcal - fixedK) / restBase))
      items = tpl.map(([key, q]) => ({ key: key as string, qty: fixed.some(x => x.key === key) ? qtyOf(key as string, q, k) : qtyOf(key as string, q, k2) }))
      t = tot(items)
    }
  }
  // kos zaokrožen navzgor čez obrok (2 banani namesto 1,6): en kos manj, če je potem bližje obroku
  for (let n = 0; n < 4 && t.k > kcal * 1.1; n++) {
    const cand = items.map((x, i) => ({ x, i })).filter(({ x }) => F[x.key]!.unit === 'kos' && x.qty > 1).sort((a, b) => kcalOfItem(b.x) - kcalOfItem(a.x))[0]
    if (!cand) break
    const next = items.map((x, i) => (i === cand.i ? { ...x, qty: x.qty - 1 } : x))
    const tn = tot(next)
    if (Math.abs(tn.k - kcal) >= Math.abs(t.k - kcal)) break
    items = next; t = tn
  }
  // beljakovine: najgostejša beljakovinska sestavina (g beljakovin na kcal) gor, ostalo sorazmerno dol
  const pi = items.map((x, i) => ({ x, i })).filter(({ x }) => PROTEIN_KEYS.has(x.key)).sort((a, b) => F[b.x.key]!.p / F[b.x.key]!.kcal - F[a.x.key]!.p / F[a.x.key]!.kcal)[0]
  // velik obrok: ko je beljakovin precej čez cilj (skuta 450 g), gre beljakovinska sestavina nazaj proti osnovi, ostalo gor
  if (pi && t.p > proteinG * 1.3 && k > 1) {
    const f = F[pi.x.key]!
    const baseQ = tpl.find(([key]) => key === pi.x.key)![1]
    const perP = f.p / f.per, perK = f.kcal / f.per
    const otherP = t.p - perP * pi.x.qty
    const q2 = qtyOf(pi.x.key, Math.max(baseQ, Math.min(pi.x.qty, (proteinG * 1.15 - otherP) / perP)), 1)
    if (q2 < pi.x.qty) {
      const others = items.filter((_, i) => i !== pi.i)
      const restK = others.reduce((s, x) => s + kcalOfItem(x), 0)
      const g = restK > 0 ? Math.min(1.6, (kcal - perK * q2) / restK) : 1
      items = items.map((x, i) => (i === pi.i ? { ...x, qty: q2 } : g > 1 ? { ...x, qty: qtyOf(x.key, x.qty, g) } : x))
      t = tot(items)
    }
  }
  if (pi && t.p < proteinG * 0.9) {
    const f = F[pi.x.key]!
    const perK = f.kcal / f.per, perP = f.p / f.per
    const baseQ = tpl.find(([key]) => key === pi.x.key)![1]
    const need = proteinG * 0.95 - t.p
    const others = items.filter((_, i) => i !== pi.i)
    const restK = others.reduce((s, x) => s + kcalOfItem(x), 0)
    // kalorije ostalih sestavin, ko gredo na 40 % (kos ne pod 1) → koliko beljakovinske sestavine gre še v obrok
    const floorK = others.reduce((s, x) => s + kcalOfItem({ key: x.key, qty: qtyOf(x.key, x.qty, 0.4) }), 0)
    const maxQ = Math.min(baseQ * 2, CAP[pi.x.key] ?? baseQ * 2, (kcal * KCAL_OVER - floorK) / perK)
    let q2 = qtyOf(pi.x.key, Math.min(maxQ, pi.x.qty + need / perP), 1)
    // zaokrožitev navzgor čez mejo → korak dol
    const down = (q: number) => { const a = qtyOf(pi.x.key, q - (f.unit === 'kos' ? 1 : 5), 1); return a < q ? a : qtyOf(pi.x.key, q - 10, 1) }
    while (q2 > pi.x.qty && perK * q2 + floorK > kcal * KCAL_OVER + 1) { const n = down(q2); q2 = n < q2 ? n : pi.x.qty }
    // če tudi z dodatkom ne pride do 85 % beljakovin (fižol v humusu), jed ostane uravnotežena — izbira raje vzame drugo
    if (q2 > pi.x.qty && t.p + perP * (q2 - pi.x.qty) < proteinG * 0.85) q2 = pi.x.qty
    if (q2 > pi.x.qty) {
      const target = Math.max(0, kcal - perK * q2)
      const g = restK > 0 && target < restK ? Math.max(0.4, target / restK) : 1
      items = items.map((x, i) => (i === pi.i ? { ...x, qty: q2 } : g < 1 ? { ...x, qty: qtyOf(x.key, x.qty, g) } : x))
      t = tot(items)
    }
  }
  // realne porcije: nobena sestavina čez mero na obrok; pred vožnjo zelenjave in solate največ 150 g (v3.48)
  const maxOf = (key: string) => (ctx.beforeRide && (key === 'zelenjava' || key === 'solata') ? 150 : PORTION_MAX[key])
  items = items.map(x => (maxOf(x.key) != null && x.qty > maxOf(x.key)! ? { ...x, qty: maxOf(x.key)! } : x))
  t = tot(items)
  // dodatek, ko jed z realnimi porcijami ne doseže obroka (največ dva)
  const sides: { key: string; qty: number }[] = []
  const ex = exclusionsOf(ctx.prefs)
  const allowed = (key: string) => !(SIDE_CONTAINS[key] || []).some(c => ex.contains.includes(c)) && !items.some(x => x.key === key) && !wordsHit(F[key]!.name, ex.words)
  for (let n = 0; n < 2; n++) {
    const all = [...items, ...sides]
    const tt = tot(all)
    const miss = kcal - tt.k
    // dodatek že pri ~5 % manjka (prej 10 %: dan z vožnjo je bil skupaj ~150 kcal pod ciljem — skrit primanjkljaj)
    if (miss < Math.max(50, kcal * 0.05)) break
    const needP = tt.p < proteinG * 0.85, needC = carbsG != null ? tt.c < carbsG * 0.8 : true
    const morning = d.tpl === 'zajtrk' || d.tpl === 'malica' || d.tpl === 'pred'
    // (v3.48) beljakovine tudi brez mleka (tofu, čičerika — k glavnemu obroku); pred tekmo in vožnjo brez polnozrnatega
    // kruha in sadja z lupino; ko beljakovinskega dodatka ni, vsaj OH, da obrok doseže svoje
    const carbOrder = light ? ['banana', 'belkruh'] : needC ? (morning ? ['banana', 'kruh', 'sadje'] : ['kruh', 'sadje', 'banana']) : ['sadje', 'kruh', 'banana']
    const order = needP ? ['jogurt', 'skuta', 'mleko', ...(morning ? [] : ['tofu', ...(light ? [] : ['fizol'])]), ...carbOrder] : carbOrder
    const key = order.find(k => allowed(k) && !sides.some(x => x.key === k))
    if (!key) break
    const f = F[key]!
    const unitK = f.unit === 'kos' ? f.kcal : (f.kcal * SIDE_STEP[key]!) / f.per
    const steps = Math.max(1, Math.min(SIDE_MAX[key]!, Math.round(miss / unitK)))
    sides.push({ key, qty: f.unit === 'kos' ? steps : steps * SIDE_STEP[key]! })
  }
  const all = [...items, ...sides]
  t = tot(all)
  const sideTxt = sides.map(x => qtyText(x.key, x.qty))
  return {
    dish: d.id, name: d.name, kcal: r1(t.k), p: r1(t.p), c: r1(t.c), f: r1(t.f), minutes: d.minutes,
    ingredients: [...items.map(i => ({ ...i, text: qtyText(i.key, i.qty) })), ...sides.map((i, j) => ({ ...i, text: `zraven: ${sideTxt[j]}`, side: true }))],
    // dodatek je med sestavinami (»zraven: …«) — ne še enkrat kot korak priprave
    steps: d.steps,
  }
}
/** dodatki k jedi: korak (g ali kos) in največ korakov; kaj vsebujejo (za želje) */
const SIDE_STEP: Record<string, number> = { kruh: 40, belkruh: 40, sadje: 150, banana: 1, jogurt: 150, skuta: 125, mleko: 250, tofu: 100, fizol: 150 }
const SIDE_MAX: Record<string, number> = { kruh: 3, belkruh: 3, sadje: 2, banana: 2, jogurt: 2, skuta: 2, mleko: 1, tofu: 2, fizol: 1 }
const SIDE_CONTAINS: Record<string, Contains[]> = { kruh: ['gluten'], belkruh: ['gluten'], jogurt: ['mleko'], skuta: ['mleko'], mleko: ['mleko'], tofu: ['soja'] }
/** ali ime živila zadene katero od besed »ne maram …« */
const wordsHit = (name: string, words: readonly string[]) => {
  const tokens = name.replace(/\(.*?\)/g, '').toLowerCase().split(/[^\p{L}]+/u).filter(x => x.length >= 3)
  return words.some(w => { const st = stem(w); return tokens.some(tok => tok.startsWith(st) || st.startsWith(stem(tok))) })
}

/** Kaj dodati za beljakovine po željah (v3.48: vegan in brez laktoze ne dobita »jogurt ali skuto«). */
function proteinAdd(ex: ReturnType<typeof exclusionsOf>, lf: boolean, have: readonly string[]): string | null {
  const ok = (c: Contains) => !ex.contains.includes(c)
  if (ok('mleko')) return 'jogurt ali skuto'
  const opts = [ok('soja') && !have.includes('tofu') ? 'tofu' : null, !lf && !have.includes('fizol') ? 'čičeriko' : null, ok('jajca') && !have.includes('jajce') ? 'jajce' : null].filter((x): x is string => !!x).slice(0, 2)
  return opts.length ? opts.join(' ali ') : null
}

/** Zakaj ta obrok zate: beljakovine, OH glede na vadbo, primanjkljaj, mišice — iz številk obroka. */
export function whyRecipe(r: Pick<Recipe, 'p' | 'c' | 'f'> & Partial<Pick<Recipe, 'ingredients'>>, slot: Pick<MealSlotPlan, 'key' | 'proteinG'> & Partial<Pick<MealSlotPlan, 'lf'>>, ctx: RecipeCtx): string {
  const bits: string[] = []
  const short = r.p < slot.proteinG * 0.85
  const add = short ? proteinAdd(exclusionsOf(ctx.prefs), !!slot.lf, (r.ingredients || []).map(i => i.key)) : null
  bits.push(`${r.p} g beljakovin${short ? ` (obrok jih ima ~${slot.proteinG}${add ? ` — dodaj ${add}` : ''})` : ctx.keepMuscle && ctx.deficit ? ' — da med hujšanjem mišice ostanejo' : ' za mišice in sitost'}`)
  if (slot.key === 'pred') bits.push(`${r.c} g lahkih ogljikovih hidratov za energijo na vadbi`)
  else if (slot.key === 'obnova') bits.push(`${r.c} g ogljikovih hidratov za obnovo po vadbi`)
  else if (ctx.training) bits.push(`${r.c} g ogljikovih hidratov — dan vadbe`)
  else bits.push(`${r.c} g ogljikovih hidratov — dan brez vadbe, zato manj`)
  if (ctx.deficit && r.f <= 18 && (slot.key === 'kosilo' || slot.key === 'vecerja')) bits.push('malo maščob — primanjkljaj je pri obrokih, ne na vadbi')
  return bits.join(' · ') + '.'
}

// dan v letu po UTC (v3.48): premik ure (DST) ne sme dati dveh dni z istim številom (isti recepti dva dni zapored)
const dayOfYear = (iso: string) => { const d = /^\d{4}-\d{2}-\d{2}$/.test(iso) ? Math.round((Date.parse(`${iso}T12:00:00Z`) - Date.UTC(+iso.slice(0, 4), 0, 1, 12)) / 86400_000) : 0; return Number.isFinite(d) ? d : 0 }
/** obrok, premajhen za recept (ostanek po pojedenem) */
export const MIN_RECIPE_KCAL = 150
/** Jedi za obrok po željah: izločene sestavine (alergije, vegetarijansko) veljajo vedno; če besede »ne maram X« izločijo vse, besede popustijo. */
export function dishesFor(tpl: string, prefs?: string | null, lib: readonly Dish[] = DISHES): Dish[] {
  const all = lib.filter(d => d.tpl === tpl)
  const ex = exclusionsOf(prefs)
  const ok = all.filter(d => dishOk(d, ex))
  // jed »za silo« (malo beljakovin) samo, če po željah ni nobene druge
  const main = ok.filter(d => !d.fallback)
  if (main.length) return main
  if (ok.length) return ok
  return all.filter(d => dishOk(d, { contains: ex.contains, words: [] }))
}
/**
 * Jedi obroka po ustreznosti: kalorije blizu obroku in beljakovine dosežene (manjko šteje dvojno). Vrne boljšo polovico
 * (vsaj 2, da se dnevi in »drug predlog« še razlikujejo) — malica s 40 g beljakovin tako dobi skuto, ne banane.
 */
export function bestFits(list: readonly Dish[], sl: Pick<MealSlotPlan, 'kcal' | 'proteinG'> & Partial<Pick<MealSlotPlan, 'carbsG' | 'beforeRide' | 'lf'>>, ctx: FitCtx): { d: Dish; fit: Omit<Recipe, 'why' | 'by'> }[] {
  // prigrizek (shake) ni večerja: za glavni obrok (> 600 kcal) samo, če ni ničesar drugega
  const meal = sl.kcal > 600 && list.some(d => !d.snack) ? list.filter(d => !d.snack) : list
  const fctx: FitCtx = { ...ctx, ...(sl.lf ? { lf: true } : {}), ...(sl.beforeRide ? { beforeRide: true } : {}) }
  const scored = meal.map(d => {
    const fit = fitDish(d, sl.kcal, sl.proteinG, fctx, sl.carbsG)
    // prava jed za obrok: kalorije, beljakovine, ogljikovi hidrati dneva (dan vadbe več, brez vadbe manj); pred vožnjo
    // brez stročnic in težke (mastne, vlaknate) hrane; dodatek k jedi je v redu, a jed, ki obrok doseže sama, je boljša
    const carbs = sl.carbsG ? Math.abs(fit.c - sl.carbsG) / Math.max(30, sl.carbsG) : 0
    // (v3.48) zelenjava, solata in sadje po pomerjenih količinah, ne po predlogi
    const fresh = fit.ingredients.filter(i => i.key === 'zelenjava' || i.key === 'solata' || i.key === 'sadje').reduce((s, i) => s + i.qty, 0)
    const heavy = sl.beforeRide && (d.items.some(([k]) => k === 'fizol' || k === 'leca' || k === 'losos') || fit.f > 22 || fresh >= 250) ? 1 : 0
    const sides = fit.ingredients.filter(i => i.side).length * 0.08
    const score = Math.abs(fit.kcal - sl.kcal) / Math.max(1, sl.kcal) + (2 * Math.max(0, sl.proteinG * 0.9 - fit.p)) / Math.max(1, sl.proteinG) + 0.6 * carbs + heavy + sides
    return { d, fit, score, heavy }
  }).sort((a, b) => a.score - b.score)
  // pred vožnjo težke jedi (stročnice, losos, mastno) sploh ne, če je kaj drugega — ne le slabša ocena
  if (sl.beforeRide && scored.some(x => !x.heavy)) scored.splice(0, scored.length, ...scored.filter(x => !x.heavy))
  // jedi, ki obrok res dosežejo (beljakovine ≥ 85 %, kalorije ±20 %); če jih ni dovolj, boljša polovica
  const good = scored.filter(x => x.fit.p >= sl.proteinG * 0.85 && Math.abs(x.fit.kcal - sl.kcal) <= sl.kcal * 0.2)
  const pick = good.length >= 2 ? good : scored.slice(0, Math.max(2, Math.ceil(scored.length / 2)))
  return pick.map(({ d, fit }) => ({ d, fit }))
}
/** Ustrezne jedi za obrok: pred tekmo (lf) iz jedi z malo vlakninami, sicer iz knjižnice — oboje po željah. */
function fitsFor(sl: Pick<MealSlotPlan, 'kcal' | 'proteinG' | 'tpl' | 'key'> & Partial<Pick<MealSlotPlan, 'carbsG' | 'beforeRide' | 'lf'>>, ctx: RecipeCtx) {
  const tpl = sl.tpl || sl.key
  return sl.lf ? bestFits(dishesFor(lfTplOf(tpl), ctx.prefs, LF_DISHES), sl, ctx) : bestFits(dishesFor(tpl, ctx.prefs), sl, ctx)
}
/** Koliko jedi pride v poštev za obrok (za gumb »drug predlog«; v3.48 tudi pred tekmo). */
export function dishChoices(sl: Pick<MealSlotPlan, 'kcal' | 'proteinG' | 'tpl' | 'key' | 'lf'> & Partial<Pick<MealSlotPlan, 'carbsG' | 'beforeRide'>>, ctx: RecipeCtx): number {
  return fitsFor(sl, ctx).length
}
/**
 * Recepti dneva po pravilih: vsak obrok dobi jed iz knjižnice (med ustreznimi vsak dan drugo, »drug predlog« naslednjo),
 * pomerjeno na kalorije in beljakovine obroka. Pred tekmo (malo vlaknin) obrok dobi jed z malo vlakninami (LF_DISHES) —
 * s pravim imenom in po željah; opozorilo o vlakninah je enkrat nad obroki.
 */
export function dayRecipes(dp: Pick<DayNutrition, 'slots'>, date: string, ctx: RecipeCtx): Record<string, Recipe> {
  const out: Record<string, Recipe> = {}
  const seed = dayOfYear(date)
  const used = new Set<string>()
  dp.slots.forEach((sl, i) => {
    if (sl.kcal < MIN_RECIPE_KCAL) return
    const list = fitsFor(sl, ctx)
    if (!list.length) return
    // raznolikost čez dan (Blaž, 16. 10.: »za jest naj bo realno«): ista osnova (riž, piščanec …) ne dvakrat v istem dnevu,
    // če je med ustreznimi jedmi druga; »drug predlog« še vedno kroži od naslednje jedi naprej
    const at = (seed + i + (ctx.alt?.[sl.key] || 0)) % list.length
    const order = list.map((_, k) => list[(at + k) % list.length]!)
    const fresh = order.find(x => { const b = basesOf(x.d); return !(b.carb && used.has(b.carb)) && !(b.prot && used.has(b.prot)) })
    const { d, fit } = fresh ?? order[0]!
    const b = basesOf(d); if (b.carb) used.add(b.carb); if (b.prot) used.add(b.prot)
    out[sl.key] = { ...fit, why: sl.lf ? `${whyRecipe(fit, sl, ctx)} Malo vlaknin — želodec na tekmi ostane miren.` : whyRecipe(fit, sl, ctx), by: 'pravila' }
  })
  return out
}

/** glavni vir ogljikovih hidratov in beljakovin jedi (za raznolikost čez dan) */
const CARB_BASE = new Set(['riz', 'testenine', 'krompir', 'kruh', 'oves', 'kuskus', 'tortilja', 'ajda', 'polenta', 'kvinoja'])
const PROT_BASE = new Set(['piscanec', 'puran', 'tuna', 'losos', 'tofu', 'jajce', 'skuta', 'fizol', 'leca', 'govedina', 'sir', 'cizerna'])
/** bel riž je riž, bel kruh je kruh … (dan tekme: riž pred tekmo in po njej je še vedno riž dvakrat) */
const BASE_OF: Record<string, string> = { rizb: 'riz', testenineb: 'testenine', krompirb: 'krompir', belkruh: 'kruh' }
export function basesOf(d: Pick<Dish, 'items'>): { carb: string | null; prot: string | null } {
  const top = (set: Set<string>) => d.items.map(([k, q]) => [BASE_OF[k] ?? k, q] as const).filter(([k]) => set.has(k)).sort((a, b) => b[1] - a[1])[0]?.[0] ?? null
  return { carb: top(CARB_BASE), prot: top(PROT_BASE) }
}
