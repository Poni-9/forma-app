import { F, qtyOf, qtyText, type Tpl, type MealSlotPlan, type DayNutrition } from './dayplan'

/**
 * RECEPTI (Blaž, 10. 10.: »pri hrani naj dobiš tudi recept — kaj ti priporoča jesti, koliko in kako se naredi«).
 * Vsak obrok dneva dobi jed iz knjižnice: sestavine z grami (iz navadne slovenske trgovine), priprava po korakih,
 * koliko minut in zakaj prav ta obrok zate (beljakovine, OH okoli vadbe, primanjkljaj, mišice). Količine so pomerjene
 * na kalorije in beljakovine obroka iz dnevnega cilja (energy.ts → dayplan.ts), zato se jed ne ponavlja dan za dnem
 * (vsak dan druga iz knjižnice) in se spremeni, ko se spremeni dan treninga. Brez AI; AI lahko doda svoje recepte
 * (actions.ts), ki gredo skozi iste varovalke (kalorije in beljakovine obroka).
 * Prehranske želje (»vegetarijansko«, »brez laktoze«, »ne maram rib«) izločijo jedi s temi sestavinami.
 */
export type Contains = 'meso' | 'riba' | 'mleko' | 'gluten' | 'jajca' | 'oreski' | 'soja'
export interface Dish { id: string; name: string; tpl: string; items: Tpl; steps: string[]; minutes: number; contains: Contains[]; /** prigrizek (shake): ne za glavni obrok */ snack?: boolean; /** samo, če po željah ni nobene druge jedi (malo beljakovin) */ fallback?: boolean; /** (v3.49) jed tudi za ta obrok (jota, ričet in lečina juha so tudi večerja) */ also?: readonly string[]
  /** (v3.50) katera zelenjava (za nakupovalni seznam; »zelenjava« se razdeli po vrstah) */ veg?: readonly string[]
  /** (v3.50) veganska različica besedila: marmelada namesto medu */ vg?: { name: string; steps: string[] }
  /** (v3.51) začimbe in drobno iz korakov (limona, česen, curry) — samo za nakupovalni seznam, brez gramov */ extra?: readonly string[] }

export const DISHES: readonly Dish[] = [
  // zajtrk
  { id: 'kasa', name: 'Ovsena kaša z jogurtom in banano', tpl: 'zajtrk', items: [['oves', 70], ['jogurt', 200], ['banana', 1], ['med', 15]], minutes: 10, contains: ['mleko', 'gluten'],
    steps: ['Ovsene kosmiče zalij z dvakrat toliko vode (z mlekom ima obrok ~50 kcal več na dl), kuhaj 3–4 min in mešaj, da se zgosti.', 'Odstavi, vmešaj polovico jogurta.', 'Na vrh banano na rezine, preostali jogurt in med.'] },
  { id: 'omleta-z', name: 'Omleta s kruhom in zelenjavo', tpl: 'zajtrk', items: [['jajce', 3], ['kruh', 60], ['zelenjava', 120], ['olje', 5]], minutes: 12, contains: ['jajca', 'gluten'], veg: ['paprika', 'paradižnik', 'špinača'],
    steps: ['Zelenjavo (papriko, paradižnik, špinačo) na kocke in 3 min praži na olju.', 'Jajca razžvrkljaj s ščepom soli, prelij čez zelenjavo in peci na srednjem ognju 3–4 min, nato preloži.', 'Postrezi s kruhom.'] },
  { id: 'skuta-z', name: 'Skuta s sadjem in oreški', tpl: 'zajtrk', items: [['skuta', 250], ['sadje', 150], ['oreski', 15], ['med', 10]], minutes: 5, contains: ['mleko', 'oreski'],
    steps: ['Skuto zmešaj z medom (po želji z žlico jogurta, da je mehkejša).', 'Sadje nareži in dodaj, potresi z oreški.'] },
  { id: 'jogurt-z', name: 'Jogurt z ovsenimi kosmiči in jabolkom', tpl: 'zajtrk', also: ['malica'], items: [['jogurt', 250], ['oves', 50], ['jabolko', 1], ['med', 10]], minutes: 5, contains: ['mleko', 'gluten'],
    steps: ['Kosmiče vmešaj v jogurt in pusti 5 min, da se zmehčajo (ali čez noč v hladilniku).', 'Jabolko na kocke, med po vrhu.'] },
  { id: 'kasa-voda', name: 'Ovsena kaša na vodi z banano in oreški', tpl: 'zajtrk', items: [['oves', 70], ['banana', 1], ['oreski', 15], ['med', 15]], minutes: 8, contains: ['gluten', 'oreski'],
    steps: ['Kosmiče zalij z dvakrat toliko vode, kuhaj 3–4 min in mešaj.', 'Dodaj banano na rezine, oreške in med.'],
    vg: { name: 'Ovsena kaša na vodi z banano in oreški', steps: ['Kosmiče zalij z dvakrat toliko vode, kuhaj 3–4 min in mešaj.', 'Dodaj banano na rezine, oreške in žličko marmelade.'] } },
  { id: 'tofu-z', name: 'Umešan tofu z zelenjavo in krompirjem', tpl: 'zajtrk', items: [['tofu', 200], ['zelenjava', 150], ['krompir', 150], ['olje', 10]], extra: ['kurkuma'], minutes: 20, contains: ['soja'], veg: ['paprika', 'špinača'],
    steps: ['Krompir na kocke kuhaj 10 min (ali uporabi kuhan od prej).', 'Tofu zdrobi z vilicami, praži na olju 4 min s ščepom soli, kurkume in popra.', 'Dodaj krompir in zelenjavo (paprika, špinača), praži še 5 min.'] },
  // (v3.48) več veganskih zajtrkov
  { id: 'tofu-kruh', name: 'Kruh s tofujem in paradižnikom', tpl: 'zajtrk', also: ['malica'], items: [['kruh', 80], ['tofu', 150], ['solata', 100], ['olje', 5]], minutes: 8, contains: ['gluten', 'soja'],
    steps: ['Tofu nareži na rezine, posoli in popeci na olju 2–3 min na vsaki strani.', 'Kruh obloži s tofujem, paradižnikom in zeleno solato.'] },
  // kosilo
  { id: 'pisc-riz', name: 'Piščanec z rižem in zelenjavo', tpl: 'kosilo', items: [['riz', 90], ['piscanec', 150], ['zelenjava', 200], ['cebula', 50], ['olje', 10]], minutes: 30, contains: ['meso'], veg: ['paprika', 'bučke', 'brokoli'],
    steps: ['Riž skuhaj v dvojni količini slane vode (12–15 min).', 'Piščančje prsi nareži na trakove, posoli in popopraj; na olju jih peci 3 min na vsaki strani, nato jih vzemi iz ponve.', 'V isti ponvi prepraži čebulo in česen, dodaj zelenjavo (paprika, bučke, brokoli) in praži 5–6 min.', 'Vrni piščanca, premešaj, postrezi na rižu.'] },
  { id: 'test-tuna', name: 'Testenine s tuno in paradižnikovo omako', tpl: 'kosilo', items: [['testenine', 100], ['tuna', 120], ['omaka', 150], ['cebula', 40], ['olje', 5]], extra: ['origano'], minutes: 20, contains: ['riba', 'gluten'],
    steps: ['Testenine skuhaj v slani vodi po navodilu (8–10 min).', 'Čebulo in česen prepraži na olju, dodaj paradižnikovo omako in kuhaj 5 min; začini z origanom.', 'Vmešaj odcejeno tuno, segrej in premešaj s testeninami.'] },
  { id: 'puran-kr', name: 'Puran s krompirjem in solato', tpl: 'kosilo', items: [['krompir', 300], ['puran', 150], ['solata', 200], ['olje', 10]], minutes: 30, contains: ['meso'],
    steps: ['Krompir olupi, nareži na kose in kuhaj 15–18 min (ali peci v pečici na 200 °C 25 min).', 'Puranje prsi posoli, popopraj in peci na olju 4 min na vsaki strani.', 'Solato in paradižnik zabeli z malo olja in kisa.'] },
  { id: 'cicerika', name: 'Curry s čičeriko in rižem', tpl: 'kosilo', also: ['vecerja'], items: [['cicerika', 250], ['riz', 80], ['zelenjava', 150], ['cebula', 50], ['olje', 10]], extra: ['curry'], minutes: 25, contains: [], veg: ['paprika', 'bučke'],
    steps: ['Riž skuhaj (12–15 min).', 'Čebulo in česen prepraži na olju, dodaj žličko curryja in zelenjavo (papriko, bučke), praži 5 min.', 'Dodaj odcejeno čičeriko in 1 dl vode (ali kokosovega mleka), kuhaj 8 min; posoli.', 'Postrezi na rižu.'] },
  { id: 'losos-kr', name: 'Losos s krompirjem in zelenjavo', tpl: 'kosilo', items: [['losos', 150], ['krompir', 300], ['zelenjava', 200], ['olje', 5]], extra: ['limona'], minutes: 30, contains: ['riba'], veg: ['brokoli', 'korenje'],
    steps: ['Krompir na kose in zelenjavo (brokoli, korenje) daj na pekač z oljem, soljo in paprikinim prahom; peci na 200 °C 20 min.', 'Losos posoli in položi na pekač k zelenjavi, peci še 12 min.', 'Pokapaj z limono.'] },
  { id: 'tofu-riz', name: 'Tofu z rižem in zelenjavo', tpl: 'kosilo', items: [['tofu', 200], ['riz', 90], ['zelenjava', 200], ['cebula', 40], ['olje', 10]], extra: ['sojina omaka'], minutes: 25, contains: ['soja'], veg: ['paprika', 'brokoli'],
    steps: ['Riž skuhaj (12–15 min).', 'Tofu na kocke, popeci na olju do zlate barve (6–8 min), dodaj žlico sojine omake.', 'Dodaj čebulo, česen in zelenjavo (papriko, brokoli), praži 5 min; postrezi na rižu.'] },
  // (v3.48) lahko vegetarijansko kosilo pred vožnjo (malo maščob, brez stročnic)
  { id: 'test-skuta', name: 'Testenine s skuto in paradižnikovo omako', tpl: 'kosilo', items: [['testenine', 100], ['skuta', 150], ['omaka', 150], ['olje', 5]], extra: ['česen', 'origano'], minutes: 15, contains: ['mleko', 'gluten'],
    steps: ['Testenine skuhaj v slani vodi po navodilu (8–10 min).', 'Omako segrej z oljem, česnom in origanom.', 'Odcejene testenine premešaj z omako, na vrh daj skuto.'] },
  { id: 'test-tofu', name: 'Testenine s tofujem in paradižnikovo omako', tpl: 'kosilo', items: [['testenine', 100], ['tofu', 150], ['omaka', 150], ['olje', 5]], minutes: 20, contains: ['soja', 'gluten'],
    steps: ['Testenine skuhaj v slani vodi po navodilu (8–10 min).', 'Tofu na kocke popeci na olju 5 min, dodaj omako in origano ter segrevaj 3 min.', 'Premešaj s testeninami.'] },
  // po vadbi (obnova)
  { id: 'test-tuna-o', name: 'Testenine s tuno in paradižnikovo omako', tpl: 'obnova', items: [['testenine', 100], ['tuna', 120], ['omaka', 150], ['olje', 5]], extra: ['origano'], minutes: 20, contains: ['riba', 'gluten'],
    steps: ['Testenine skuhaj po navodilu (8–10 min).', 'Omako segrej z oljem in origanom, vmešaj odcejeno tuno.', 'Premešaj s testeninami — v 45 minutah po vadbi.'] },
  { id: 'riz-pisc-o', name: 'Riž s piščancem in zelenjavo', tpl: 'obnova', items: [['riz', 100], ['piscanec', 140], ['zelenjava', 150], ['olje', 5]], minutes: 25, contains: ['meso'], veg: ['paprika', 'bučke'],
    steps: ['Riž skuhaj (12–15 min).', 'Piščanca na trakove peci na olju 6–8 min, dodaj zelenjavo (papriko, bučke) in praži še 5 min.', 'Posoli, premešaj z rižem.'] },
  { id: 'shake', name: 'Skutin shake z banano in ovsom', tpl: 'obnova', items: [['skuta', 200], ['banana', 1], ['mleko', 250], ['oves', 40], ['med', 10]], minutes: 5, contains: ['mleko', 'gluten'], snack: true,
    steps: ['Vse daj v mešalnik in zmešaj do gladkega.', 'Popij v 30 minutah po vadbi; če je pregosto, dodaj mleko.'] },
  { id: 'leca-riz', name: 'Leča z rižem in zelenjavo', tpl: 'obnova', items: [['leca', 250], ['riz', 70], ['zelenjava', 150], ['cebula', 40], ['olje', 5]], extra: ['kumina'], minutes: 25, contains: [], veg: ['korenje', 'paprika'],
    steps: ['Riž skuhaj (12–15 min).', 'Čebulo in česen prepraži, dodaj zelenjavo (korenje, papriko) in kuhano lečo (iz pločevinke, odcejeno), segrevaj 8 min; posoli, dodaj kumino.', 'Postrezi na rižu.'] },
  // (v3.48) več vegetarijanskih in veganskih obrokov po vadbi — ne vsak dan »Leča z rižem«
  { id: 'test-tofu-o', name: 'Testenine s tofujem in paradižnikovo omako', tpl: 'obnova', items: [['testenine', 100], ['tofu', 150], ['omaka', 150], ['olje', 5]], minutes: 20, contains: ['soja', 'gluten'],
    steps: ['Testenine skuhaj po navodilu (8–10 min).', 'Tofu na kocke popeci na olju 5 min, dodaj omako in origano ter segrevaj 3 min.', 'Premešaj s testeninami — v 45 minutah po vadbi.'] },
  { id: 'kuskus-cic-o', name: 'Kuskus s čičeriko in zelenjavo', tpl: 'obnova', items: [['kuskus', 90], ['cicerika', 200], ['zelenjava', 150], ['olje', 10]], extra: ['kumina'], minutes: 15, contains: ['gluten'], veg: ['paprika', 'bučke'],
    steps: ['Kuskus prelij z enako količino vrele slane vode, pokrij in pusti 5 min; razrahljaj z vilicami.', 'Zelenjavo (papriko, bučke) na kocke praži na olju 5 min, dodaj odcejeno čičeriko in kumino ter segrevaj 3 min.', 'Premešaj s kuskusom — v 45 minutah po vadbi.'] },
  { id: 'krompir-cic-o', name: 'Pečen krompir s čičeriko in zelenjavo', tpl: 'obnova', items: [['krompir', 350], ['cicerika', 200], ['zelenjava', 150], ['olje', 10]], extra: ['mleta paprika'], minutes: 30, contains: [], veg: ['bučke', 'korenje'],
    steps: ['Krompir na kose, odcejeno čičeriko in zelenjavo (bučke, korenje) daj na pekač, pokapaj z oljem, posoli in potresi s papriko v prahu.', 'Peci na 200 °C 25 min, vmes enkrat premešaj.'] },
  { id: 'test-jajca-o', name: 'Testenine z jajci, zelenjavo in sirom', tpl: 'obnova', items: [['testenine', 100], ['jajce', 2], ['sir', 30], ['zelenjava', 100], ['olje', 5]], minutes: 15, contains: ['jajca', 'mleko', 'gluten'], veg: ['bučke', 'paprika'],
    steps: ['Testenine skuhaj po navodilu (8–10 min).', 'Zelenjavo (bučke, papriko) na kocke praži na olju 4 min, dodaj odcejene testenine.', 'Vmešaj razžvrkljana jajca in nariban sir, mešaj na nizkem ognju 1–2 min, da se jajca strdijo.'] },
  // večerja
  { id: 'krompir-jajca', name: 'Krompir z jajci in zelenjavo', tpl: 'vecerja', items: [['krompir', 300], ['jajce', 3], ['zelenjava', 250], ['olje', 10]], minutes: 25, contains: ['jajca'], veg: ['paprika', 'špinača'],
    steps: ['Krompir skuhaj v olupku (20 min), olupi in nareži na kolobarje.', 'Na olju popeci krompir 5 min, dodaj zelenjavo (papriko, špinačo) in praži še 5 min.', 'Prelij z razžvrkljanimi jajci in peci 3–4 min; posoli.'] },
  { id: 'solata-tuna', name: 'Solata s tuno in fižolom', tpl: 'vecerja', items: [['tuna', 120], ['fizol', 200], ['solata', 250], ['kruh', 40], ['olje', 10]], extra: ['limona'], minutes: 10, contains: ['riba', 'gluten'],
    steps: ['Solato in paradižnik nareži, dodaj odcejen fižol in tuno.', 'Zabeli z oljem, kisom ali limono, soljo in poprom.', 'Postrezi s kruhom.'] },
  { id: 'tofu-zel', name: 'Tofu s pečeno zelenjavo in krompirjem', tpl: 'vecerja', items: [['tofu', 200], ['zelenjava', 250], ['krompir', 200], ['olje', 10]], extra: ['sojina omaka'], minutes: 30, contains: ['soja'], veg: ['bučke', 'paprika', 'korenje'],
    steps: ['Krompir in zelenjavo (bučke, papriko, korenje) na kose daj na pekač z oljem in soljo, peci na 200 °C 20 min.', 'Tofu na kocke, pokapaj s sojino omako, dodaj na pekač in peci še 10 min.'] },
  { id: 'omleta-sir', name: 'Omleta z zelenjavo in sirom', tpl: 'vecerja', items: [['jajce', 3], ['zelenjava', 250], ['sir', 40], ['kruh', 40], ['olje', 5]], minutes: 15, contains: ['jajca', 'mleko', 'gluten'], veg: ['paprika', 'bučke'],
    steps: ['Zelenjavo (papriko, bučke) na kocke in 4 min praži na olju.', 'Prelij z razžvrkljanimi jajci, potresi s sirom, peci 3–4 min in preloži.', 'Postrezi s kruhom.'] },
  { id: 'pec-pisc', name: 'Pečen piščanec s pečeno zelenjavo', tpl: 'vecerja', items: [['piscanec', 150], ['zelenjava', 300], ['krompir', 200], ['olje', 10]], extra: ['rožmarin'], minutes: 35, contains: ['meso'], veg: ['bučke', 'paprika', 'čebula'],
    steps: ['Zelenjavo (bučke, paprika, čebula) in krompir na kose daj na pekač, pokapaj z oljem, posoli, dodaj rožmarin.', 'Piščanca posoli in popopraj, položi med zelenjavo.', 'Peci na 200 °C 25–30 min.'] },
  // malica
  { id: 'skuta-m', name: 'Skuta s sadjem', tpl: 'malica', items: [['skuta', 250], ['sadje', 150], ['oreski', 15]], minutes: 5, contains: ['mleko', 'oreski'],
    steps: ['Skuto zmešaj z malo jogurta ali mleka, da je mehkejša.', 'Dodaj narezano sadje in oreške.'] },
  { id: 'jogurt-m', name: 'Jogurt z banano in oreški', tpl: 'malica', items: [['jogurt', 250], ['banana', 1], ['oreski', 10]], minutes: 3, contains: ['mleko', 'oreski'],
    steps: ['Banano nareži v jogurt, potresi z oreški.'] },
  { id: 'kruh-skuta', name: 'Kruh s skuto in paradižnikom', tpl: 'malica', also: ['zajtrk'], items: [['kruh', 60], ['skuta', 150], ['solata', 100]], minutes: 5, contains: ['mleko', 'gluten'],
    steps: ['Skuto posoli in namaži na kruh.', 'Obloži s paradižnikom in zeleno solato.'] },
  { id: 'kefir-m', name: 'Kefir z ovsenimi kosmiči', tpl: 'malica', items: [['kefir', 300], ['oves', 40], ['med', 10]], minutes: 3, contains: ['mleko', 'gluten'],
    steps: ['Kosmiče in med vmešaj v kefir; po 5 minutah so mehki.'] },
  { id: 'humus-m', name: 'Humus s kruhom in zelenjavo', tpl: 'malica', items: [['cicerika', 150], ['kruh', 60], ['zelenjava', 100], ['olje', 10]], extra: ['česen', 'limona'], minutes: 8, contains: ['gluten'], veg: ['korenje', 'paprika'],
    steps: ['Čičeriko (odcejeno) zmelji z oljem, limono, česnom in soljo v namaz.', 'Namaži na kruh, zraven korenje ali papriko na palčke.'] },
  { id: 'banana-or', name: 'Banana z oreški in jabolkom', tpl: 'malica', items: [['banana', 1], ['oreski', 20], ['jabolko', 1]], minutes: 2, contains: ['oreski'],
    steps: ['Sadje nareži, zraven pest oreškov.'] },
  { id: 'cicerika-m', name: 'Hrustljava čičerika z jabolkom', tpl: 'malica', items: [['cicerika', 150], ['jabolko', 1], ['olje', 5]], extra: ['mleta paprika'], minutes: 25, contains: [],
    steps: ['Odcejeno čičeriko osuši, pokapaj z oljem, posoli in potresi s papriko v prahu.', 'Peci na 200 °C 20 min, da postane hrustljava (lahko za več dni naprej).', 'Zraven jabolko.'] },
  // pred vadbo
  { id: 'kruh-med', name: 'Kruh z medom in banano', tpl: 'pred', items: [['kruh', 60], ['med', 20], ['banana', 1]], minutes: 3, contains: ['gluten'],
    steps: ['Kruh namaži z medom, zraven banano.', 'Brez maščob in težke hrane.'],
    vg: { name: 'Kruh z marmelado in banano', steps: ['Kruh namaži z marmelado, zraven banano.', 'Brez maščob in težke hrane.'] } },
  { id: 'sadje-pred', name: 'Banana in jabolko', tpl: 'pred', items: [['banana', 1], ['jabolko', 1]], minutes: 1, contains: [],
    steps: ['Lahki ogljikovi hidrati, nič težkega.'] },
  // (v3.50) brez banane (»ne maram banan«; vegan brez glutena je prej dobil banano)
  { id: 'sok-pred', name: 'Jabolko in kozarec soka', tpl: 'pred', items: [['jabolko', 1], ['sok', 200]], minutes: 1, contains: [],
    steps: ['Jabolko in kozarec 100 % sadnega soka — lahki ogljikovi hidrati, nič težkega.'] },
  { id: 'oves-med', name: 'Ovseni kosmiči z mlekom in medom', tpl: 'pred', items: [['oves', 50], ['mleko', 200], ['med', 15]], minutes: 5, contains: ['mleko', 'gluten'],
    steps: ['Kosmiče zalij z mlekom, dodaj med; po želji kuhaj 2 min.'] },
  { id: 'banana-jog', name: 'Banana z jogurtom', tpl: 'pred', items: [['banana', 1], ['jogurt', 150], ['med', 10]], minutes: 2, contains: ['mleko'],
    steps: ['Banano nareži v jogurt, dodaj med. Lahko in hitro.'] },
  // stročnice (večerja po jutranji vadbi)
  { id: 'fizol-enol', name: 'Fižolova enolončnica s kruhom', tpl: 'stroc', items: [['fizol', 250], ['kruh', 60], ['zelenjava', 200], ['cebula', 50], ['olje', 10]], extra: ['lovorov list'], minutes: 25, contains: ['gluten'], veg: ['korenje', 'paprika'],
    steps: ['Čebulo in česen prepraži na olju, dodaj narezano zelenjavo (korenje, paprika) in praži 5 min.', 'Dodaj fižol s tekočino iz pločevinke in 2 dl vode, kuhaj 10 min; posoli, dodaj lovorov list.', 'Postrezi s kruhom.'] },
  { id: 'leca-juha', name: 'Lečina juha s krompirjem', tpl: 'stroc', also: ['vecerja'], items: [['leca', 250], ['zelenjava', 200], ['krompir', 150], ['cebula', 50], ['olje', 10]], extra: ['kumina'], minutes: 30, contains: [], veg: ['korenje'],
    steps: ['Čebulo, česen in korenje prepraži na olju 5 min.', 'Dodaj krompir na kocke, lečo in 5 dl vode; kuhaj 20 min, posoli in dodaj kumino.'] },
  // (v3.49) slovenska kuhinja: kar ljudje res kuhajo doma (ajdova kaša, polenta, ričet, jota, golaž, bolonjska, juha, oslič, sendvič)
  { id: 'polenta-z', name: 'Polenta z jogurtom', tpl: 'zajtrk', items: [['polenta', 70], ['jogurt', 250], ['med', 10]], minutes: 10, contains: ['mleko'],
    steps: ['Koruzni zdrob vsipaj v 3 dl vrele slane vode in mešaj 5 min (instant polenta), da se zgosti.', 'Postrezi toplo z jogurtom, po vrhu med.'] },
  { id: 'ajda-pisc', name: 'Ajdova kaša s piščancem in gobami', tpl: 'kosilo', items: [['ajda', 80], ['piscanec', 140], ['zelenjava', 200], ['cebula', 40], ['olje', 10]], minutes: 30, contains: ['meso'], veg: ['šampinjoni'],
    steps: ['Ajdovo kašo operi in jo kuhaj v dvojni količini slane vode 15–20 min, da vpije vodo.', 'Piščanca nareži na koščke in ga na olju peci 5–6 min; dodaj čebulo in narezane šampinjone ter praži še 5 min.', 'Premešaj s kašo, posoli in popopraj.'] },
  { id: 'ajda-jajce', name: 'Ajdova kaša z jajci in zelenjavo', tpl: 'kosilo', items: [['ajda', 80], ['jajce', 2], ['zelenjava', 200], ['sir', 20], ['olje', 10]], minutes: 25, contains: ['jajca', 'mleko'], veg: ['bučke', 'paprika', 'šampinjoni'],
    steps: ['Ajdovo kašo operi in jo kuhaj v dvojni količini slane vode 15–20 min.', 'Zelenjavo (bučke, papriko, gobe) na kocke praži na olju 5 min, vmešaj kašo.', 'Na vrh ubij jajca, pokrij in peci 4–5 min, da se beljak strdi; potresi z naribanim sirom.'] },
  { id: 'golaz', name: 'Goveji golaž s polento', tpl: 'kosilo', items: [['govedina', 150], ['polenta', 70], ['cebula', 60], ['omaka', 100], ['olje', 10]], extra: ['sladka paprika', 'kumina'], minutes: 90, contains: ['meso'],
    steps: ['Čebulo drobno nareži in jo na olju praži 10 min, da porjavi; dodaj na kocke narezano govedino, sladko papriko in kumino.', 'Prilij paradižnikovo omako in 3 dl vode, pokrij in duši 60–80 min (v loncu na pritisk 30 min), da se meso zmehča; posoli.', 'Koruzni zdrob vsipaj v 3 dl vrele slane vode in mešaj 5 min; postrezi z golažem (skuhaj več — golaž je naslednji dan še boljši).'] },
  { id: 'bolonjska', name: 'Testenine z bolonjsko omako', tpl: 'kosilo', also: ['obnova'], items: [['testenine', 100], ['mleto', 120], ['omaka', 150], ['cebula', 40], ['olje', 5]], extra: ['origano'], minutes: 25, contains: ['meso', 'gluten'],
    steps: ['Čebulo in česen prepraži na olju, dodaj mleto meso in ga praži 6–8 min, da razpade in porjavi.', 'Prilij paradižnikovo omako, dodaj origano, posoli in kuhaj 10 min.', 'Testenine skuhaj v slani vodi (8–10 min) in jih prelij z omako.'] },
  { id: 'oslic-kr', name: 'Oslič s krompirjem in blitvo', tpl: 'kosilo', also: ['vecerja'], items: [['oslic', 180], ['krompir', 300], ['zelenjava', 200], ['olje', 10]], extra: ['česen', 'limona'], minutes: 25, contains: ['riba'], veg: ['blitva'],
    steps: ['Krompir olupi, nareži na kose in ga skupaj z narezano blitvo kuhaj v slani vodi 15–18 min; odcedi in zabeli z oljem in strtim česnom.', 'Oslič posoli in ga na olju peci 3–4 min na vsaki strani (ali v pečici na 200 °C 15 min).', 'Pokapaj z limono.'] },
  { id: 'ricet', name: 'Ričet z ješprenjem in fižolom', tpl: 'kosilo', also: ['vecerja', 'stroc'], items: [['jesprenj', 60], ['fizol', 200], ['zelenjava', 150], ['cebula', 40], ['olje', 5]], extra: ['lovorov list'], minutes: 45, contains: ['gluten'], veg: ['korenje', 'zelena'],
    steps: ['Ješprenj operi in ga kuhaj v 1 l vode 20 min.', 'Dodaj na kocke narezano korenje, zeleno in čebulo ter odcejen fižol, kuhaj še 15–20 min.', 'Posoli, popopraj in dodaj lovorov list; ričet naj bo gost (skuhaj več — za dva dni).'] },
  { id: 'jota', name: 'Jota s kislim zeljem in fižolom', tpl: 'kosilo', also: ['vecerja', 'stroc'], items: [['fizol', 200], ['zelje', 200], ['krompir', 200], ['cebula', 40], ['olje', 10]], extra: ['lovorov list'], minutes: 35, contains: [],
    steps: ['Krompir olupi, nareži na kocke in ga s kislim zeljem kuhaj v 8 dl vode 20 min.', 'Na olju prepraži čebulo in česen, dodaj odcejen fižol in vse stresi v lonec.', 'Kuhaj še 10 min, posoli, popopraj, dodaj lovorov list; del krompirja pretlači, da se jota zgosti.'] },
  { id: 'juha-zel', name: 'Zelenjavna juha z jajci in kruhom', tpl: 'vecerja', items: [['zelenjava', 300], ['krompir', 150], ['jajce', 2], ['kruh', 60], ['olje', 5]], minutes: 30, contains: ['jajca', 'gluten'], veg: ['korenje', 'zelena', 'por', 'bučke', 'čebula'],
    steps: ['Na olju prepraži čebulo in na kocke narezano zelenjavo (korenje, zelena, por, bučka) 5 min.', 'Dodaj krompir na kocke in 1 l vode, kuhaj 20 min; posoli.', 'Jajca razžvrkljaj in jih med mešanjem vlij v vrelo juho, kuhaj še 1 min. Postrezi s kruhom.'] },
  { id: 'sendvic-sunka', name: 'Sendvič s puranjo šunko in sirom', tpl: 'malica', items: [['kruh', 80], ['sunka', 60], ['sir', 20], ['solata', 60]], minutes: 5, contains: ['meso', 'gluten', 'mleko'],
    steps: ['Kruh ali žemljo obloži s šunko, sirom, zeleno solato in paradižnikom.'] },
  // (v3.49) več veganskih in vegetarijanskih zajtrkov in malic (ne vsak dan tofu)
  { id: 'kasa-soj', name: 'Ovsena kaša na sojinem napitku z arašidovim maslom', tpl: 'zajtrk', items: [['oves', 70], ['sojmleko', 250], ['arasid', 15], ['sojjogurt', 100]], extra: ['cimet'], minutes: 8, contains: ['gluten', 'soja', 'oreski'],
    steps: ['Kosmiče zalij s sojinim napitkom, kuhaj 3–4 min in mešaj, da se zgosti.', 'Vmešaj arašidovo maslo, na vrh daj sojin jogurt in cimet.'] },
  { id: 'kuskus-tofu', name: 'Kuskus s tofujem in zelenjavo', tpl: 'kosilo', items: [['kuskus', 100], ['tofu', 150], ['zelenjava', 150], ['olje', 5]], extra: ['sojina omaka'], minutes: 15, contains: ['soja', 'gluten'], veg: ['paprika', 'bučke'],
    steps: ['Kuskus prelij z enako količino vrele slane vode, pokrij in pusti 5 min; razrahljaj z vilicami.', 'Tofu na kocke popeci na olju 6–8 min, dodaj zelenjavo (papriko, bučke) in žlico sojine omake ter praži še 4 min.', 'Premešaj s kuskusom.'] },
  { id: 'palacinke', name: 'Palačinke s skuto', tpl: 'kosilo', items: [['moka', 100], ['mleko', 250], ['jajce', 2], ['skuta', 200], ['med', 20]], minutes: 30, contains: ['gluten', 'jajca', 'mleko'],
    steps: ['Moko, mleko, jajca in ščep soli zmešaj v gladko testo in pusti 10 min.', 'V ponvi, namazani s kapljico olja, peci tanke palačinke, 1 min na vsaki strani.', 'Skuto zmešaj z medom in nadevaj palačinke.'] },
  { id: 'ajda-mleko', name: 'Ajdova kaša na mleku z jabolkom in cimetom', tpl: 'zajtrk', items: [['ajda', 60], ['mleko', 300], ['med', 10], ['jabolko', 1]], extra: ['cimet'], minutes: 20, contains: ['mleko'],
    steps: ['Ajdovo kašo operi in jo kuhaj v mleku na nizkem ognju 15–20 min; mešaj, da se ne prime (lahko že zvečer).', 'Sladkaj z medom, na vrh naribano jabolko in cimet.'] },
  { id: 'ajda-soj', name: 'Ajdova kaša na sojinem napitku z arašidovim maslom', tpl: 'zajtrk', items: [['ajda', 60], ['sojmleko', 300], ['arasid', 15], ['jabolko', 1]], extra: ['cimet'], minutes: 20, contains: ['soja', 'oreski'],
    steps: ['Ajdovo kašo operi in jo kuhaj v sojinem napitku na nizkem ognju 15–20 min; mešaj, da se ne prime.', 'Vmešaj arašidovo maslo, na vrh naribano jabolko in cimet.'] },
  { id: 'kruh-arasid', name: 'Kruh z arašidovim maslom in sojinim napitkom', tpl: 'malica', also: ['zajtrk'], items: [['kruh', 60], ['arasid', 20], ['sojmleko', 250]], minutes: 3, contains: ['gluten', 'oreski', 'soja'],
    steps: ['Kruh namaži z arašidovim maslom, zraven kozarec sojinega napitka.'] },
  { id: 'oves-noc', name: 'Ovseni kosmiči čez noč s sojinim jogurtom', tpl: 'zajtrk', items: [['oves', 60], ['sojjogurt', 150], ['sojmleko', 100], ['arasid', 15]], minutes: 5, contains: ['gluten', 'soja', 'oreski'],
    steps: ['Zvečer zmešaj kosmiče, sojin jogurt in sojin napitek v kozarcu ali skledi, pokrij in daj v hladilnik.', 'Zjutraj vmešaj arašidovo maslo in po želji cimet ali sadje.'] },
  { id: 'sojjog-z', name: 'Sojin jogurt s kosmiči in jabolkom', tpl: 'zajtrk', also: ['malica'], items: [['sojjogurt', 250], ['oves', 50], ['jabolko', 1], ['oreski', 15]], minutes: 5, contains: ['soja', 'gluten', 'oreski'],
    steps: ['Kosmiče vmešaj v sojin jogurt in pusti 5 min (ali čez noč v hladilniku).', 'Dodaj jabolko na kocke in oreške.'] },
  // (v3.50) vegan in vegetarijanec: kosila brez tofuja in stročnic (prej ričet 5 od 7 kosil) — sojini koščki kot mleto meso
  { id: 'bolonjska-soj', name: 'Testenine z bolonjsko omako iz sojinih koščkov', tpl: 'kosilo', also: ['obnova'], items: [['testenine', 100], ['sojkos', 50], ['omaka', 150], ['cebula', 40], ['olje', 5]], extra: ['origano'], minutes: 25, contains: ['soja', 'gluten'],
    steps: ['Sojine koščke (granulat) prelij z vrelo vodo in pusti 10 min, nato jih ožmi.', 'Čebulo in česen prepraži na olju, dodaj koščke in praži 5 min; prilij paradižnikovo omako, dodaj origano, posoli in kuhaj 10 min.', 'Testenine skuhaj v slani vodi (8–10 min) in jih prelij z omako.'] },
  { id: 'golaz-soj', name: 'Sojin golaž s polento', tpl: 'kosilo', items: [['sojkos', 60], ['polenta', 70], ['cebula', 60], ['omaka', 100], ['zelenjava', 100], ['olje', 10]], extra: ['sladka paprika', 'kumina'], minutes: 35, contains: ['soja'], veg: ['paprika'],
    steps: ['Sojine koščke prelij z vrelo vodo in pusti 10 min, nato jih ožmi.', 'Čebulo na olju praži 10 min, da porjavi; dodaj koščke, narezano papriko, sladko papriko v prahu in kumino, prilij omako in 2 dl vode ter kuhaj 15 min; posoli.', 'Koruzni zdrob vsipaj v 3 dl vrele slane vode in mešaj 5 min; postrezi z golažem.'] },
  { id: 'ajda-sojkos', name: 'Ajdova kaša s sojinimi koščki in gobami', tpl: 'kosilo', also: ['vecerja'], items: [['ajda', 80], ['sojkos', 50], ['zelenjava', 200], ['cebula', 40], ['olje', 10]], minutes: 30, contains: ['soja'], veg: ['šampinjoni', 'paprika'],
    steps: ['Ajdovo kašo operi in jo kuhaj v dvojni količini slane vode 15–20 min.', 'Sojine koščke prelij z vrelo vodo, pusti 10 min in ožmi; na olju jih praži 5 min s čebulo, narezanimi šampinjoni in papriko.', 'Premešaj s kašo, posoli in popopraj.'] },
  // (v3.50) veganska malica z beljakovinami (prej humus, sojin jogurt, kruh z arašidovim maslom — vsi pri ~50 % beljakovin obroka)
  { id: 'edamame-m', name: 'Edamame s soljo in limono', tpl: 'malica', items: [['edamame', 200]], extra: ['limona'], minutes: 6, contains: ['soja'],
    steps: ['Zamrznjen oluščen edamame skuhaj v slani vodi 4–5 min in odcedi.', 'Posoli in pokapaj z limono — topel ali hladen.'] },
  // (v3.50) več malic z beljakovinami brez skute in banane (prej »ne maram skute« 11 od 14 malic »Jogurt z banano«)
  { id: 'jogurt-or-m', name: 'Grški jogurt z oreški in medom', tpl: 'malica', items: [['jogurt', 250], ['oreski', 10], ['med', 10]], minutes: 2, contains: ['mleko', 'oreski'],
    steps: ['Jogurt potresi z oreški in pokapaj z medom.'] },
  { id: 'kruh-tuna-m', name: 'Kruh s tuno in paradižnikom', tpl: 'malica', items: [['kruh', 50], ['tuna', 80], ['solata', 80]], extra: ['limona'], minutes: 4, contains: ['riba', 'gluten'],
    steps: ['Odcejeno tuno zmešaj s kapljico limone in poprom, namaži na kruh.', 'Obloži s paradižnikom in zeleno solato.'] },
  // (v3.50) majhen glavni obrok (pod 300 kcal — ostanek po pojedenem, manjši človek): ne skrčena jed (»testenine 10 g«)
  { id: 'majhen-jogurt', name: 'Jogurt s sadjem', tpl: 'majhen', items: [['jogurt', 200], ['sadje', 150]], minutes: 2, contains: ['mleko'],
    steps: ['Sadje nareži v jogurt.'] },
  { id: 'majhen-skuta', name: 'Skuta z jabolkom', tpl: 'majhen', also: ['malica'], items: [['skuta', 150], ['jabolko', 1]], minutes: 2, contains: ['mleko'],
    steps: ['Skuto zmešaj z žlico vode ali jogurta, da je mehkejša; zraven jabolko.'] },
  { id: 'majhen-jajca', name: 'Jajca s paradižnikom in kruhom', tpl: 'majhen', items: [['jajce', 2], ['solata', 150], ['kruh', 30]], minutes: 10, contains: ['jajca', 'gluten'],
    steps: ['Jajca skuhaj (8 min) ali jih umešaj na kapljici olja.', 'Zraven paradižnik in rezina kruha.'] },
  { id: 'majhen-sojjog', name: 'Sojin jogurt s sadjem', tpl: 'majhen', items: [['sojjogurt', 200], ['sadje', 150]], minutes: 2, contains: ['soja'],
    steps: ['Sadje nareži v sojin jogurt.'] },
  { id: 'majhen-cic', name: 'Čičerika s paradižnikom', tpl: 'majhen', items: [['cicerika', 150], ['solata', 150], ['olje', 5]], extra: ['limona'], minutes: 5, contains: [],
    steps: ['Odcejeno čičeriko premešaj s paradižnikom, oljem, soljo in limono.'] },
  // (v3.51) brez glutena in oreškov: zajtrk in malica (prej brez glutena 3 zajtrki, »alergija na oreške« sendvič 10 od 14 malic)
  { id: 'jajca-krompir-z', name: 'Umešana jajca s krompirjem in papriko', tpl: 'zajtrk', items: [['jajce', 3], ['krompir', 200], ['zelenjava', 100], ['olje', 5]], minutes: 15, contains: ['jajca'], veg: ['paprika'],
    steps: ['Krompir na kocke kuhaj 10 min (ali uporabi kuhan od prej).', 'Na olju ga popeci 3 min, dodaj papriko na kocke in praži še 2 min.', 'Prelij z razžvrkljanimi jajci, mešaj 2–3 min, da se strdijo; posoli.'] },
  // (v3.51) veganski malici z beljakovinami (prej je beljakovine malice dosegel samo »Edamame s soljo in limono«)
  { id: 'tofu-m', name: 'Pečen tofu s paradižnikom', tpl: 'malica', items: [['tofu', 180], ['solata', 100], ['olje', 5]], minutes: 10, contains: ['soja'], extra: ['sojina omaka'],
    steps: ['Tofu nareži na kocke in ga na olju peci 5–6 min, da porjavi; pokapaj s sojino omako (lahko vnaprej za dva dni).', 'Zraven paradižnik na krhlje.'] },
  { id: 'edamame-sol', name: 'Solata z edamamejem in paradižnikom', tpl: 'malica', items: [['edamame', 150], ['solata', 150], ['kruh', 30], ['olje', 5]], minutes: 8, contains: ['soja', 'gluten'], extra: ['limona'],
    steps: ['Zamrznjen edamame skuhaj v slani vodi 4–5 min, odcedi in ohladi.', 'Premešaj s paradižnikom in zeleno solato, zabeli z oljem, limono in soljo; zraven rezina kruha.'] },
  { id: 'jajca-m', name: 'Kuhana jajca s paradižnikom', tpl: 'malica', items: [['jajce', 3], ['solata', 150]], minutes: 10, contains: ['jajca'],
    steps: ['Jajca kuhaj 8–9 min, ohladi v mrzli vodi in olupi.', 'Zraven paradižnik na krhlje, posoli.'] },
]
/**
 * PRED TEKMO: jedi z malo vlaknin (v3.48) — prava imena in koraki, po prehranskih željah kot ostale jedi.
 * Samo bel kruh, bel riž, bele testenine, krompir brez lupine, zrela banana, med, marmelada, mlečni izdelki, jajca,
 * meso, riba, tofu; brez zelenjave, stročnic, oreškov in sadja z lupino. Za vsak obrok je jed brez živil, ki jih
 * želje izločijo (contains: []), da se obrok vedno pomeri.
 */
export const LF_DISHES: readonly Dish[] = [
  // zajtrk
  { id: 'lf-kruh-jogurt', name: 'Bel kruh z marmelado in jogurtom', tpl: 'zajtrk', items: [['belkruh', 100], ['marmelada', 30], ['jogurt', 200], ['banana', 1]], minutes: 3, contains: ['gluten', 'mleko'],
    steps: ['Bel kruh ali žemljo namaži z marmelado.', 'Zraven jogurt in zrela banana.'] },
  { id: 'lf-riz-mleko', name: 'Mlečni riž z banano in medom', tpl: 'zajtrk', items: [['rizb', 80], ['mleko', 300], ['banana', 1], ['med', 15]], minutes: 25, contains: ['mleko'],
    steps: ['Bel riž kuhaj v mleku 20–25 min na nizkem ognju; mešaj, da se ne prime (lahko že zvečer).', 'Sladkaj z medom, zraven zrela banana na rezine.'] },
  { id: 'lf-jajca-kruh', name: 'Umešana jajca z belim kruhom', tpl: 'zajtrk', items: [['jajce', 3], ['belkruh', 100], ['med', 15], ['olje', 5]], minutes: 8, contains: ['jajca', 'gluten'],
    steps: ['Jajca razžvrkljaj s ščepom soli in jih na olju umešaj 2–3 min.', 'Zraven bel kruh z medom.'] },
  { id: 'lf-tofu-kruh', name: 'Umešan tofu z belim kruhom', tpl: 'zajtrk', items: [['tofu', 150], ['belkruh', 100], ['marmelada', 20], ['olje', 5]], extra: ['kurkuma'], minutes: 8, contains: ['soja', 'gluten'],
    steps: ['Tofu zdrobi z vilicami in ga na olju praži 4 min s ščepom soli in kurkume.', 'Zraven bel kruh z marmelado.'] },
  { id: 'lf-riz-banana', name: 'Riž z banano in medom', tpl: 'zajtrk', items: [['rizb', 80], ['banana', 1], ['med', 20]], minutes: 15, contains: [], fallback: true,
    steps: ['Bel riž skuhaj v vodi (12–15 min).', 'Primešaj zrelo banano na rezine in med.'],
    vg: { name: 'Riž z banano in marmelado', steps: ['Bel riž skuhaj v vodi (12–15 min).', 'Primešaj zrelo banano na rezine in žlico marmelade.'] } },
  // kosilo
  { id: 'lf-pisc-riz', name: 'Bel riž s piščancem', tpl: 'kosilo', items: [['rizb', 110], ['piscanec', 150], ['olje', 10]], minutes: 20, contains: ['meso'],
    steps: ['Bel riž skuhaj v dvojni količini slane vode (12–15 min).', 'Piščanca nareži na trakove, posoli in ga na olju peci 3 min na vsaki strani.', 'Postrezi na rižu — brez solate in surove zelenjave.'] },
  { id: 'lf-test-tuna', name: 'Bele testenine s tuno in paradižnikovo omako', tpl: 'kosilo', items: [['testenineb', 110], ['tuna', 120], ['omaka', 150], ['olje', 5]], minutes: 15, contains: ['riba', 'gluten'],
    steps: ['Bele testenine skuhaj v slani vodi po navodilu (8–10 min).', 'Omako segrej z oljem in origanom, vmešaj odcejeno tuno.', 'Premešaj s testeninami.'] },
  { id: 'lf-tofu-riz', name: 'Bel riž s tofujem', tpl: 'kosilo', items: [['rizb', 110], ['tofu', 180], ['olje', 10]], extra: ['sojina omaka'], minutes: 20, contains: ['soja'],
    steps: ['Bel riž skuhaj (12–15 min).', 'Tofu na kocke popeci na olju do zlate barve (6–8 min), dodaj žlico sojine omake.', 'Postrezi na rižu.'] },
  { id: 'lf-riz-jajca', name: 'Bel riž z jajci', tpl: 'kosilo', items: [['rizb', 110], ['jajce', 3], ['olje', 5]], minutes: 18, contains: ['jajca'],
    steps: ['Bel riž skuhaj (12–15 min).', 'Jajca razžvrkljaj, na olju jih umešaj 2–3 min in premešaj z rižem; posoli.'] },
  { id: 'lf-riz-omaka', name: 'Bel riž s paradižnikovo omako', tpl: 'kosilo', items: [['rizb', 110], ['omaka', 200], ['olje', 10]], minutes: 15, contains: [], fallback: true,
    steps: ['Bel riž skuhaj (12–15 min).', 'Omako segrej z oljem, soljo in baziliko ter jo prelij čez riž.'] },
  // po vadbi (obnova)
  { id: 'lf-test-tuna-o', name: 'Bele testenine s tuno', tpl: 'obnova', items: [['testenineb', 110], ['tuna', 120], ['omaka', 150], ['olje', 5]], minutes: 15, contains: ['riba', 'gluten'],
    steps: ['Bele testenine skuhaj po navodilu (8–10 min).', 'Omako segrej z oljem, vmešaj odcejeno tuno in premešaj s testeninami.'] },
  { id: 'lf-pisc-pire-o', name: 'Piščanec s pire krompirjem', tpl: 'obnova', items: [['krompirb', 350], ['piscanec', 140], ['olje', 5]], minutes: 25, contains: ['meso'],
    steps: ['Krompir olupi, nareži in kuhaj 15–18 min; odcedi in pretlači z žlico olja in soljo.', 'Piščanca na trakove peci na olju 6–8 min.'] },
  { id: 'lf-tofu-test-o', name: 'Bele testenine s tofujem in paradižnikovo omako', tpl: 'obnova', items: [['testenineb', 110], ['tofu', 150], ['omaka', 150], ['olje', 5]], minutes: 20, contains: ['soja', 'gluten'],
    steps: ['Bele testenine skuhaj po navodilu (8–10 min).', 'Tofu na kocke popeci na olju 5 min, dodaj omako in segrevaj 3 min.', 'Premešaj s testeninami.'] },
  { id: 'lf-riz-jajca-o', name: 'Bel riž z jajci', tpl: 'obnova', items: [['rizb', 100], ['jajce', 3], ['olje', 5]], minutes: 18, contains: ['jajca'],
    steps: ['Bel riž skuhaj (12–15 min).', 'Jajca razžvrkljaj, na olju jih umešaj 2–3 min in premešaj z rižem; posoli.'] },
  { id: 'lf-pire-omaka-o', name: 'Pire krompir s paradižnikovo omako', tpl: 'obnova', items: [['krompirb', 400], ['omaka', 150], ['olje', 10]], minutes: 25, contains: [], fallback: true,
    steps: ['Krompir olupi, kuhaj 15–18 min in pretlači z oljem in soljo.', 'Zraven segreta paradižnikova omaka.'] },
  // večerja (tudi po jutranji vadbi)
  { id: 'lf-krompir-jajca', name: 'Krompir brez lupine z jajci', tpl: 'vecerja', items: [['krompirb', 400], ['jajce', 3], ['olje', 10]], minutes: 25, contains: ['jajca'],
    steps: ['Krompir olupi, nareži in kuhaj 15–18 min; odcedi.', 'Na olju ga popeci 5 min, prelij z razžvrkljanimi jajci in peci 3–4 min; posoli.'] },
  { id: 'lf-losos-pire', name: 'Losos s pire krompirjem', tpl: 'vecerja', items: [['krompirb', 350], ['losos', 130], ['olje', 5]], minutes: 25, contains: ['riba'],
    steps: ['Krompir olupi, kuhaj 15–18 min in pretlači z žlico olja in soljo.', 'Losos posoli in peci v pečici na 200 °C 12–15 min (ali v ponvi 4 min na vsaki strani).'] },
  { id: 'lf-test-pisc-v', name: 'Bele testenine s piščancem', tpl: 'vecerja', items: [['testenineb', 100], ['piscanec', 130], ['omaka', 150], ['olje', 5]], minutes: 20, contains: ['meso', 'gluten'],
    steps: ['Bele testenine skuhaj po navodilu (8–10 min).', 'Piščanca na kocke peci na olju 6 min, dodaj omako in segrevaj 3 min.', 'Premešaj s testeninami.'] },
  { id: 'lf-tofu-krompir', name: 'Tofu s krompirjem brez lupine', tpl: 'vecerja', items: [['krompirb', 350], ['tofu', 180], ['olje', 10]], minutes: 25, contains: ['soja'],
    steps: ['Krompir olupi, nareži in kuhaj 15–18 min; odcedi.', 'Tofu na kocke popeci na olju 6–8 min, dodaj krompir in praži še 3 min; posoli.'] },
  { id: 'lf-krompir-omaka', name: 'Krompir brez lupine s paradižnikovo omako', tpl: 'vecerja', items: [['krompirb', 400], ['omaka', 150], ['olje', 10]], minutes: 25, contains: [], fallback: true,
    steps: ['Krompir olupi, nareži in kuhaj 15–18 min; odcedi.', 'Prelij s segreto paradižnikovo omako in oljem; posoli.'] },
  // malica
  { id: 'lf-skuta-banana', name: 'Skuta z banano in medom', tpl: 'malica', items: [['skuta', 200], ['banana', 1], ['med', 20]], minutes: 3, contains: ['mleko'],
    steps: ['Skuto zmešaj z medom (po želji z žlico jogurta, da je mehkejša).', 'Zraven zrela banana.'] },
  { id: 'lf-jogurt-banana', name: 'Jogurt z banano in medom', tpl: 'malica', items: [['jogurt', 250], ['banana', 1], ['med', 15]], minutes: 2, contains: ['mleko'],
    steps: ['Banano nareži v jogurt, dodaj med.'] },
  { id: 'lf-kruh-marmelada', name: 'Bel kruh z marmelado', tpl: 'malica', items: [['belkruh', 80], ['marmelada', 30]], minutes: 2, contains: ['gluten'],
    steps: ['Bel kruh ali žemljo namaži z marmelado.'] },
  { id: 'lf-banana-med', name: 'Banana z medom', tpl: 'malica', items: [['banana', 2], ['med', 15]], minutes: 2, contains: [], fallback: true,
    steps: ['Zrelo banano nareži in pokapaj z medom.'],
    vg: { name: 'Banana z marmelado', steps: ['Zrelo banano nareži in zraven pojej žlico marmelade.'] } },
  // pred vadbo
  { id: 'lf-kruh-med-p', name: 'Bel kruh z medom in banano', tpl: 'pred', items: [['belkruh', 60], ['med', 20], ['banana', 1]], minutes: 3, contains: ['gluten'],
    steps: ['Bel kruh namaži z medom, zraven zrela banana.', 'Brez maščob in težke hrane.'],
    vg: { name: 'Bel kruh z marmelado in banano', steps: ['Bel kruh namaži z marmelado, zraven zrela banana.', 'Brez maščob in težke hrane.'] } },
  { id: 'lf-banana-jog-p', name: 'Banana z jogurtom', tpl: 'pred', items: [['banana', 1], ['jogurt', 150], ['med', 10]], minutes: 2, contains: ['mleko'],
    steps: ['Banano nareži v jogurt, dodaj med.'] },
  { id: 'lf-banana-p', name: 'Banana z medom', tpl: 'pred', items: [['banana', 1], ['med', 15]], minutes: 1, contains: [],
    steps: ['Zrela banana in žlička medu.'],
    vg: { name: 'Banana z marmelado', steps: ['Zrela banana in žlička marmelade.'] } },
]
/** predloga obroka → jedi z malo vlakninami (večerja po jutranji vadbi je večerja) */
const lfTplOf = (tpl: string) => (tpl === 'stroc' ? 'vecerja' : tpl)
// (v3.50) sojin napitek ni beljakovinska sestavina (3 g na 100 ml — kosmiči čez noč so bili v 550 g tekočine); sojini koščki in edamame so
/** (v3.51) stročnice (fižol, čičerika, leča) */
const LEGUMES = new Set(['fizol', 'cicerika', 'leca'])
const PROTEIN_KEYS = new Set(['piscanec', 'tuna', 'jajce', 'skuta', 'jogurt', 'tofu', 'puran', 'losos', 'leca', 'fizol', 'cicerika', 'kefir', 'sir', 'mleko', 'govedina', 'mleto', 'oslic', 'sunka', 'sojjogurt', 'sojkos', 'edamame'])


/**
 * besede za skupino živil → kaj vsebuje. (v3.50) Skupino sproži samo beseda za skupino (meso, ribe, mlečni izdelki,
 * gluten, soja); posamezno živilo (skuta, sir, jogurt, piščanec, puran, tuna, losos, kruh, tofu) gre med besede in izloči
 * samo jedi s tem živilom — prej je »ne maram skute« izločil vseh 18 mlečnih jedi, »ne maram piščanca« golaž in bolonjsko.
 */
const ING_WORDS: [RegExp, Contains][] = [
  // (v3.48) svinjina, govedina, salama, šunka niso »vse meso«: gredo med besede (izločijo jedi s tem imenom)
  [/\bmes[oa]\b|mesn/u, 'meso'],
  [/\brib(?:a|e|i|o|ah|ami|j\p{L}*)?\b|morsk/u, 'riba'],
  // (v3.49) »laktoza« ni »mleko«: brez laktoze = izdelki brez laktoze (lactoseFree), brez mleka = brez mlečnih izdelkov
  [/mle(?:č|c)n|\bmlek/u, 'mleko'],
  [/gluten|celiak|p(?:š|s)eni(?:č|c)/u, 'gluten'],
  // (v3.50) jajčevec ni jajce
  [/jaj(?:c|č)(?!ev)/u, 'jajca'],
  [/ore(?:š|s)(?:k|č|c)|mandl|le(?:š|s)nik|arašid|arasid/u, 'oreski'],
  [/\bsoj/u, 'soja'],
]
/** (v3.50) »ne jem rdečega mesa«: govedina in svinjina (golaž, bolonjska) — piščanec, puran in šunka ostanejo */
const RED_MEAT = ['govedina', 'golaž', 'bolonjsko', 'svinjina']
/** (v3.50) »perutnina«: piščanec in puran (ne vse meso) */
const POULTRY = ['piščanec', 'puran']
// (v3.51) tudi »ne pijem mleka«
const NEG = /ne maram|ne jem|ne pijem|brez|alergi|ne prenašam|ne prena(?:š|s)am|ne smem|sovra(?:ž|z)im|nikoli|(?<!\p{L})ni(?:č|c)(?!\p{L})/u
const POS = /rad imam|rada imam|jem\b|lahko|mi pa(?:š|s)e|ni problem|ne (?:š|s)kodi|ne dela te(?:ž|z)av|nisem|ni alergij/u
/** (v3.50) alergija (ali »ne prenašam«, »ne smem«): posamezno živilo izloči svojo skupino — alergija je vedno strožja od »ne maram« */
const ALLERGY = /alergi|ne prena(?:š|s)am|ne smem/u
const ALLERGY_ING: [RegExp, Contains][] = [
  [/(?<!\p{L})sir(?!up)|skut|jogurt|kefir|smetan|(?<!\p{L})masl[oa](?!\p{L})|mocarel|parmez/u, 'mleko'],
  [/kruh|testenin|kuskus|(?<!\p{L})mok[aeo](?!\p{L})|je(?:š|s)prenj/u, 'gluten'],
  [/(?<!\p{L})tun[aeiou]?(?!\p{L})|losos|osli(?:č|c)|sardel|postrv/u, 'riba'],
  [/tofu|edamame/u, 'soja'],
]
/** (v3.50) zelena (gomolj) ni zelenjava in ne zelena solata — »alergija na zeleno« je prej izločila vse jedi z zelenjavo */
const CELERY = 'zelena'
const CELERY_RE = /(?<!\p{L})zelen[aeio]?(?!\p{L})(?!\s+solat)/u
/** (v3.50) »gobe« so v jedeh šampinjoni */
const ALIAS: [RegExp, string][] = [[/^gob/u, 'šampinjoni']]
/** (v3.50) kratke besede (3 črke), ki niso živilo, čeprav se z njimi začne ime živila (»fižol ali čičerika«, »polenta«) */
const SHORT_STOP = /^(?:ali|sem|pri|kot|ker|vse|tak|kar|ter|pač|pac|več|vec|dan|jem|nič|nic|pol|tri|dve|ena|eno|med)$/u
/**
 * Prehranske želje iz besed po delih stavka: »vegetarijansko«, »brez laktoze«, »ne maram rib«, »alergija na oreške«,
 * »rad imam ribe, brez mleka« (ribe ostanejo, mleko izpade), »nisem vegetarijanec« (nič ne izpade).
 */
export interface Exclusions { contains: Contains[]; words: string[]; /** (v3.49) »brez laktoze«: mlečni izdelki brez laktoze (trdi sir ostane) */ lactoseFree?: boolean; /** (v3.50) vegan: tudi brez medu (namesto njega marmelada) */ vegan?: boolean
  /** (v3.50) besede iz stavka z alergijo: ne popustijo nikoli (tudi ko izločijo vse jedi obroka) */ hard?: string[]
  /** (v3.51) brez svinjine (»ne jem svinjine«, halal): pršut, slanina, ocvirki, klobase, salama — v AI receptih */ pork?: boolean
  /** (v3.51) »ne maram čebule / česna«: začimba, ki jo izpustiš — jed ostane, sestavine in nakupa ni */ skip?: ('čebula' | 'česen')[]
  /** (v3.51) brez sladkorja (tudi sladkorna bolezen): brez medu, marmelade in soka */ noSugar?: boolean }
/** (v3.51) svinjina v besedilu AI recepta (puranja in piščančja šunka nista svinjina) */
const PORK_RE = /svinj|pr(?:š|s)ut|slanin|ocvir|(?:š|s)peh|klobas|salam|hrenovk|pancet|kranjsk|(?:š|s)unk|čevap|cevap/u
const NOT_PORK = /(?:puranj|pi(?:š|s)(?:č|c)an|kokoš|kokos)\p{L}*\s+(?:(?:š|s)unk|klobas|salam|hrenovk|pr(?:š|s)ut)\p{L}*/gu
/** (v3.51) dan v tednu za »ob petkih«, »med tednom«, »ob vikendih« (0 = nedelja) */
const WEEKDAY: [RegExp, number[]][] = [[/ponedelj/u, [1]], [/tork/u, [2]], [/sred/u, [3]], [/(?:č|c)etrt/u, [4]], [/petk/u, [5]], [/sobot/u, [6]], [/nedelj/u, [0]], [/vikend/u, [0, 6]], [/delavnik|med tednom/u, [1, 2, 3, 4, 5]]]
/**
 * (v3.51) Želje za ta dan: del z dnem v tednu (»ne jem mesa ob petkih«) velja samo na ta dan, brez dneva tega dela ni;
 * drugi časovni deli (»zvečer«, »včasih«) niso trajne želje. Prej je »ob petkih« izločil meso vse dni.
 */
export function prefsOn(prefs: string | null | undefined, date?: string): string {
  const wd = date && /^\d{4}-\d{2}-\d{2}$/.test(date) ? new Date(`${date}T12:00:00Z`).getUTCDay() : -1
  const src = prefs || ''
  if (!TIMED.test(` ${src.toLowerCase()} `)) return src.replace(/^[\s,;.]+|[\s,;.]+$/gu, '')
  // (v3.51) časovni del izreže samo svoj del stavka (do »in / pa / ter«, vejice ali oklepaja) — prej je
  // »ne jem mesa ob petkih in alergija na oreške« izbrisal tudi alergijo, »vegan in zvečer ne jem kruha« vegana
  return src.split(/([,;.\n()]+)/u).map((part, i) => {
    if (i % 2) return /[()]/u.test(part) ? ', ' : part
    if (!TIMED.test(` ${part.toLowerCase()} `)) return part
    const groups: string[] = []
    for (const s of part.split(/\s+(?:in|pa|ampak|ter)\s+/iu)) {
      // nadaljevanje naštevanja (»ne jem mesa in rib ob petkih«) ostane v isti želji
      if (groups.length && !NEW_PREF.test(` ${s.toLowerCase()} `)) groups[groups.length - 1] += ` in ${s}`
      else groups.push(s)
    }
    return groups.map(g => {
      const low = ` ${g.toLowerCase()} `, m = TIMED.exec(low)
      if (!m) return g
      const strip = () => low.replace(TIMED_ALL, ' ').replace(DAY_TAIL, ' ').replace(/\s+/gu, ' ').trim()
      // (v3.51) alergija, vegan, vegetarijanec in celiakija veljajo vse dni, tudi s časovnim delom
      if (ALWAYS_PREF.test(low)) return strip()
      if (!WEEKDAY.some(([rx]) => rx.test(m[0]))) return ''
      // »ob petkih in sobotah«: vsi dnevi za časovnim delom
      const days = new Set<number>()
      for (const d of low.slice(m.index).match(DAY_WORDS) || []) for (const x of WEEKDAY.find(([rx]) => rx.test(d))?.[1] || []) days.add(x)
      return days.has(wd) ? strip() : ''
    }).filter(g => g.trim()).join(' in ')
  }).join('').replace(/(?:\s*,\s*){2,}/gu, ', ').replace(/^[\s,;.]+|[\s,;.]+$/gu, '')
}
/** (v3.51) začetek nove želje v delu stavka (ne nadaljevanje naštevanja) */
const NEW_PREF = /alergi|ne prena(?:š|s)am|ne smem|ne maram|ne jem|ne pijem|brez|nikoli|vegan|vege|pescetar|peskatar|pesketar|celiak|gluten|laktoz|(?<!\p{L})jem(?!\p{L})|rad[a]? imam|lahko/u
/** (v3.51) želja, ki ne izpade nikoli (tudi s »zvečer« ali »ob petkih«) */
const ALWAYS_PREF = /alergi|ne prena(?:š|s)am|ne smem|vegan|vegetar|celiak|gluten/u
/** (v3.51) imena dni za »ob petkih in sobotah« */
const DAY_WORDS = /(?<!\p{L})(?:ponedelj\p{L}*|tork\p{L}*|torek|sred(?:ah|a|o|e)(?!\p{L})|(?:č|c)etrt(?:k\p{L}*|ek)|pet(?:k\p{L}*|ek)(?!\p{L})|sobot\p{L}*|nedelj\p{L}*|vikend\p{L}*|delavnik\p{L}*)/gu
const DAY_TAIL = /(?<!\p{L})(?:in|ter|ali)\s+(?:ob\s+)?(?:ponedeljkih|torkih|sredah|(?:č|c)etrtkih|petkih|sobotah|nedeljah|vikendih|praznikih)(?!\p{L})/gu
/** (v3.51) del želja, ki velja samo na nekatere dni (za opombo v listu želja) */
export const hasTimedPrefs = (prefs: string | null | undefined): boolean => (prefs || '').split(/[,;.\n]+/u).some(x => TIMED.test(` ${x.toLowerCase()} `))
/** (v3.51) opomba za želje, ki jih recepti ne upoštevajo (sladkorna bolezen, keto) */
export function prefsNote(prefs: string | null | undefined): string | null {
  const t = (prefs || '').toLowerCase()
  return /sladkorn|diabet|keto|nizkoogljik|nizko ogljik|low.?carb/u.test(t) ? 'Sladkorne bolezni in keto prehrane recepti ne upoštevajo — OH so za trening. Posvetuj se z zdravnikom ali dietetikom.' : null
}
export function exclusionsOf(prefs0: string | null | undefined, date?: string): Exclusions {
  const prefs = prefsOn(prefs0, date)
  const contains = new Set<Contains>()
  const words: string[] = [], hard: string[] = []
  let lactoseFree = false, vegan = false, pork = false, noSugar = false
  const skip = new Set<'čebula' | 'česen'>()
  let carry = false   // »ne maram rib, piščanca, brokolija«: nikalnica velja še za naštevanje za vejico
  let carryHard = false   // (v3.50) »alergija na sir, skuto«: alergija velja tudi za naštevanje
  const low = (prefs || '').toLowerCase()
  // (v3.51) halal, košer: brez svinjine; sladkorna bolezen: brez medu in marmelade
  if (/halal|ko(?:š|s)er/u.test(low)) pork = true
  if (/sladkorn|diabet/u.test(low)) noSugar = true
  for (const c0 of low.split(/[,;.\n]+|\s+(?:in|pa|ampak|ter)\s+/u).map(x => x.trim()).filter(Boolean)) {
    const c = ` ${c0} `
    const neg = NEG.test(c), pos = POS.test(c)
    // (v3.50) »…, sicer zdrav«: nikalnica se ne prenese (prej je »zdrav« izločil zdrob za polento)
    const bare = !neg && !pos && c0.split(/\s+/).length <= 2 && !/vege|vegan|laktoz|gluten|celiak|pescetar|peskatar/.test(c) && !/^(?:sicer|drugače|drugace|vendar|razen|tudi|zato|ker|ampak)(?!\p{L})/u.test(c0)
    if (/nisem|ni(?:sem)? vege|nisem vegan/.test(c)) { carry = false; continue }
    if (/vegan/.test(c) && !pos) { ['meso', 'riba', 'mleko', 'jajca'].forEach(x => contains.add(x as Contains)); vegan = true; carry = false; continue }
    // (v3.50) pescetarijanec: brez mesa, ribe ostanejo
    if (/pescetar|peskatar|pesketar/.test(c) && !pos) { contains.add('meso'); carry = false; continue }
    if (/vege|brez mesa|mesa ne|ne jem mesa|ne maram mesa|ni(?:č|c) mesa/.test(c) && !/rde(?:č|c)/.test(c) && !pos) { contains.add('meso'); contains.add('riba'); carry = false; continue }
    if (/laktoz|celiak|gluten/.test(c) && !pos && !/brez laktoze ni|brez glutena ni/.test(c)) { if (/laktoz/.test(c)) lactoseFree = true; if (/gluten|celiak/.test(c)) contains.add('gluten') }
    if (!neg && !(bare && carry)) { carry = false; carryHard = false; continue }
    const allergy: boolean = neg ? ALLERGY.test(c) : carryHard
    carry = true; carryHard = allergy
    // »ne maram X in Y«, »brez X, Y«: sestavine za nikalnico (ali naštevanje za njo)
    const after = neg ? c.split(NEG).slice(1).join(' ') : c
    // (v3.51) svinjina (pršut, slanina, klobase) — v AI receptih
    if (/svinj/u.test(after)) pork = true
    // (v3.51) »ne pijem mleka«: samo mleko kot pijača (jogurt, skuta, sir ostanejo), ne vse mlečno
    if (/ne pijem/u.test(c)) { for (const m of after.matchAll(/\p{L}{4,}/gu)) if (!/^(?:jesti|nikoli|sploh|zelo|ve(?:č|c))$/u.test(m[0])) { words.push(m[0]); if (allergy) hard.push(m[0]) } continue }
    // (v3.50) rdeče meso in perutnina nista vse meso
    if (/rde(?:č|c)\p{L}*\s+mes/u.test(after)) { words.push(...RED_MEAT); if (allergy) hard.push(...RED_MEAT); continue }
    if (/perutnin/u.test(after)) { words.push(...POULTRY); if (allergy) hard.push(...POULTRY); continue }
    for (const [rx, k] of ING_WORDS) if (rx.test(after)) contains.add(k)
    if (allergy) for (const [rx, k] of ALLERGY_ING) if (rx.test(after)) contains.add(k)
    const add = (w: string) => { words.push(w); if (allergy) hard.push(w) }
    // (v3.50) tudi besede s 3 črkami, ki so živilo (»sir«, »gob«, »por«, »riž«; »med« samo na koncu: ne »med vožnjo«)
    for (const m of after.matchAll(/[\p{L}]{3,}/gu)) {
      const w = m[0]
      if (/^(?:ne|na|za|brez|jem|jesti|maram|imam|alergij\p{L}*|nikoli|sploh|zelo|ni(?:č|c)|hran[aeo]|jedi|nobene|noben|problem\p{L}*|te(?:ž|z)av\p{L}*|vsega|lahko|smem|prena(?:š|s)am|laktoz\p{L}*|izdelk\p{L}*|posebn\p{L}*|drug\p{L}*|sicer|zdrav\p{L}*)$/u.test(w)) continue
      if (w.length === 3 && !(w === 'med' ? !/\p{L}/u.test(after.slice(m.index! + 3)) : !SHORT_STOP.test(w) && foodToks().some(t => t.startsWith(w)))) continue
      if (ING_WORDS.some(([rx]) => rx.test(w))) continue
      // (v3.51) čebula in česen sta začimba: jed ostane, v receptu ju izpustiš (pri alergiji ostane izločitev)
      if (!allergy && /^(?:(?:č|c)ebul|(?:č|c)esn|(?:č|c)esen)/u.test(w)) { skip.add(/^(?:č|c)ebul/u.test(w) ? 'čebula' : 'česen'); continue }
      // (v3.51) »brez sladkorja«: brez medu, marmelade in soka (beseda sama ne zadene nobene jedi)
      if (/^sladk/u.test(w)) { noSugar = true; continue }
      // »alergija na zeleno«: zelena (gomolj), ne »zelene solate« ali zelenjave
      if (/^zelen[aeio]?$/u.test(w) && !/^\s+solat/u.test(after.slice(m.index! + w.length))) { add(CELERY); continue }
      add(w)
      for (const [rx, a] of ALIAS) if (rx.test(w)) add(a)
    }
  }
  // (v3.51) »vegetarijanec, jem pa ribe«: ribe, ki jih izrecno ješ, ostanejo (pescetarijanec) — razen pri alergiji
  if (contains.has('riba') && !vegan && /(?:(?<!ne )jem|rad[a]? imam|lahko jem)\s+(?:pa\s+|tudi\s+|(?:š|s)e\s+)?rib|rib\p{L}*\s+(?:pa\s+|tudi\s+)?(?:jem|lahko)/u.test(low) && !/alergi\p{L}*\s+(?:na\s+)?rib|ne prena(?:š|s)am rib/u.test(low)) contains.delete('riba')
  return { contains: [...contains], words: [...new Set(words)], ...(lactoseFree && !contains.has('mleko') ? { lactoseFree } : {}), ...(vegan ? { vegan } : {}), ...(hard.length ? { hard: [...new Set(hard)] } : {}),
    ...(pork ? { pork } : {}), ...(skip.size ? { skip: [...skip] } : {}), ...(noSugar ? { noSugar } : {}) }
}
/** (v3.50) besede imen živil in jedi (za kratke besede in želje iz uvoda) */
let FOOD_TOKS: string[] | null = null
const foodToks = (): string[] => (FOOD_TOKS ??= [...new Set([...Object.values(F).map(f => f.name), ...DISHES.map(d => `${d.name} ${(d.veg || []).join(' ')}`)].flatMap(n => toks(n)))])
/** (v3.50) ali je beseda živilo iz knjižnice: osnova s 4 črkami (»zdrav« ni »zdrob«, »riža« je »riž«, »sira« je »sir«) */
const isFoodWord = (w: string): boolean => {
  if (w === CELERY) return true
  const s4 = (x: string) => x.slice(0, Math.max(4, x.length - 2))
  const st = s4(w)
  return foodToks().some(t => t.startsWith(st) || (t.length >= 3 && st.startsWith(s4(t))))
}
/** (v3.51) pogosta živila, ki jih ni v imenih jedi (za želje iz uvoda) */
const COMMON_FOOD = /^(?:svinj|goved|telet|jagnj|kaš|ka(?:š|s)e|gob|grah|gra(?:š|s)k|pa(?:š|s)tet|mlek)/u
/** (v3.50) omejitev na del tedna ali dneva (»ob petkih ne jem mesa«, »po 19h«, »včasih«) ni trajna prehranska želja */
const TIMED = /(?<!\p{L})ob\s+(?:ponedelj|tork|sred|(?:č|c)etrt|petk|sobot|nedelj|vikend|praznik|delavnik)\p{L}*|(?<!\p{L})(?:v(?:č|c)asih|zve(?:č|c)er|zjutraj|med tednom|ob vikendih|pred spanjem)(?!\p{L})|(?<!\p{L})po\s+\d+(?:\s*h|\s*uri|(?!\p{L}))/u
const TIMED_ALL = new RegExp(TIMED.source, 'gu')
/**
 * (v3.50) Prehranske želje iz uvoda (»Sem vegan.«, »Ne prenašam laktoze.«, »alergija na oreške«) — za prehranske želje
 * profila ob dogovoru (prej se je izgubilo: vegan je dobil polento z jogurtom). Samo stavki o hrani: »ne maram teka« ali
 * »brez poškodb« ne. Vrne null, če v besedilu ni nič o hrani.
 */
export function foodPrefsFromWish(text: string | null | undefined): string | null {
  const out: string[] = []
  const push = (x: string) => { if (!out.includes(x)) out.push(x) }
  for (const c1 of (text || '').toLowerCase().split(/[.;!?\n]+|,\s+(?=ne |brez |alergi|nisem |sem )/u).map(x => x.trim()).filter(Boolean)) {
    // (v3.50) del z omejitvijo na dan ali čas (»ob petkih ne jem mesa«, »včasih jem ribe«) ni trajna želja
    // (v3.51) brez dneva izpade samo časovni del stavka (»ne jem mesa ob petkih in alergija na oreške« obdrži alergijo)
    const c0 = prefsOn(c1).trim()
    if (!c0) continue
    const ex = exclusionsOf(c0)
    if (ex.vegan) { push('vegan'); continue }
    if (/pescetar|peskatar|pesketar/u.test(c0) && ex.contains.includes('meso')) { push('pescetarijansko'); continue }
    // (v3.51) »vegetarijanec, jem pa ribe« je pescetarijanec
    if (/vege/u.test(c0) && ex.contains.includes('meso')) { push(ex.contains.includes('riba') ? 'vegetarijansko' : 'pescetarijansko'); continue }
    if (ex.lactoseFree && !ex.contains.length && !ex.words.length) { push('brez laktoze'); continue }
    if (/gluten|celiak/u.test(c0) && ex.contains.includes('gluten') && !ex.words.length) { push('brez glutena'); continue }
    // ostalo (»ne maram rib«, »alergija na oreške«, »ne jem svinjine«): samo, če gre za hrano iz knjižnice
    // (v3.50) beseda mora biti živilo (osnova s 4 črkami) — prej se je »zdrav« ujel z »zdrob« po predponi
    // (v3.51) tudi svinjina, čebula, česen, kaša, gobe in sladkor (prej »ne jem svinjine« in »ne maram česna« nista prišla v želje)
    const food = ex.contains.length > 0 || !!ex.pork || !!ex.skip || !!ex.noSugar || ex.words.some(w => isFoodWord(w) || COMMON_FOOD.test(w))
    if (food && (ex.contains.length || ex.words.length || ex.lactoseFree || ex.pork || ex.skip || ex.noSugar)) push(c0.replace(/^(?:in|pa|ter)\s+/u, '').slice(0, 80))
  }
  const t = out.join(', ').slice(0, 200)
  return t || null
}
/**
 * (v3.49) Tofu (in sojin napitek) samo, ko želje izločijo meso, mleko ali jajca ali tofu omenijo same — vsejedec ga ne
 * dobi za zajtrk in dan pred tekmo (prej »Umešan tofu 250 g« za zajtrk, »Bel riž s tofujem« pred Franjo).
 */
export function soyOk(ex: Exclusions, prefs?: string | null): boolean {
  if (ex.contains.includes('soja')) return false
  // (v3.51) samo pozitivna omemba: »ne maram tofuja« ne doda soje vsejedcu (prej več sojinih jedi kot brez želja)
  return ex.contains.some(c => c === 'meso' || c === 'mleko' || c === 'jajca') || (/tofu|\bsoj/u.test((prefs || '').toLowerCase()) && !ex.words.some(w => /^(?:tofu|soj)/u.test(w)))
}
/** (v3.49) mlečni izdelki brez laktoze: ime v sestavinah (trdi sir — edamec — laktoze skoraj nima) */
const LACTOSE_FREE: Record<string, string> = { jogurt: 'grški jogurt brez laktoze', mleko: 'mleko 1,5 % brez laktoze', skuta: 'skuta ali grški jogurt brez laktoze', kefir: 'kefir ali jogurt brez laktoze' }
/** besedilo sestavine; pri »brez laktoze« mlečni izdelek brez laktoze */
export function ingText(key: string, qty: number, lactoseFree?: boolean): string {
  const t = qtyText(key, qty), n = (lactoseFree ? LACTOSE_FREE[key] : undefined) ?? REC_NAME[key]
  return n ? t.replace(F[key]!.name, n) : t
}
/** (v3.51) ime v receptu in nakupu, kjer je ime v tabeli živil širše (ocena brez AI: »fižol ali čičerika«) */
const REC_NAME: Record<string, string> = { fizol: 'fižol (kuhan)' }
const nameOf = (key: string) => REC_NAME[key] ?? F[key]!.name
// groba osnova besede (brez končnice): »piščanca« → »pišča«, »brokolija« → »brokol«, »riža« → »riž«
// (v3.51) od 5 črk osnova vsaj 4 črke: »zelja« → »zelj« (prej »zel«, ki je zadel zelenjavo in zeleno solato)
const stem = (w: string) => w.toLowerCase().replace(/\(.*?\)/g, '').trim().slice(0, Math.max(w.length >= 5 ? 4 : 3, w.length - 2))
const toks = (s: string, min = 3): string[] => s.replace(/\(.*?\)/g, '').toLowerCase().split(/[^\p{L}]+/u).filter(x => x.length >= min)
/** (v3.50) beseda »ne maram« zadene imena (obe smeri predpone) ali korake (samo naprej, besede z vsaj 4 črkami); zelena posebej */
function wordHit(w: string, nameToks: readonly string[], stepToks: readonly string[], text: string): boolean {
  if (w === CELERY) return CELERY_RE.test(text)
  const st = stem(w)
  return nameToks.some(tok => tok.startsWith(st) || st.startsWith(stem(tok))) || stepToks.some(tok => tok.startsWith(st))
}
/** (v3.50) besedilo jedi za želje: ime, sestavine, vrste zelenjave in koraki (prej brez zelenjave v korakih in `veg`) */
const DISH_TXT = new WeakMap<Dish, { name: string[]; steps: string[]; text: string }>()
function dishTxt(d: Dish) {
  let t = DISH_TXT.get(d)
  if (!t) {
    const names = `${d.name} ${d.items.map(([k]) => nameOf(k).replace(/\(.*?\)/g, '')).join(' ')} ${(d.veg || []).join(' ')}`
    t = { name: toks(names), steps: toks(d.steps.join(' '), 4), text: `${names} ${d.steps.join(' ')}`.toLowerCase() }
    DISH_TXT.set(d, t)
  }
  return t
}
const dishHit = (d: Dish, words: readonly string[]): boolean => { if (!words.length) return false; const t = dishTxt(d); return words.some(w => wordHit(w, t.name, t.steps, t.text)) }
/** Ali jed ustreza željam (brez izločenih sestavin in besed). */
export function dishOk(d: Dish, ex: ReturnType<typeof exclusionsOf>): boolean {
  if (d.contains.some(c => ex.contains.includes(c))) return false
  return !dishHit(d, ex.words)
}

/**
 * (v3.49) Kaj vsebuje besedilo AI recepta (ime in sestavine) — prej je AI recept šel mimo želja (vegetarijanec je dobil
 * »Piščančji wok«). Širše kot pri knjižnici: govedina, šunka, oslič, mocarela … Rastlinski napitki in maslo niso mleko.
 */
const TEXT_WORDS: [RegExp, Contains][] = [
  // kokoš, kokošji, kokoska (brez strešice) — ne kokos, kokosov (v3.49: »kokos 20 g« je bil meso)
  // (v3.50) tudi »kurji file«, »kurja bedra«, perutnina
  [/\bmes[oau]\b|mesn|mlet\p{L}*\s+mes|pi(?:š|s)(?:č|c)an|puran|koko(?:š|s(?=j|k|i(?![\p{L}])))|\bkurj\p{L}*|\bkur[aeo]\b|perutnin|govej|goved|telet|svinj|(?:š|s)unk|salam|pr(?:š|s)ut|slanin|klobas|hrenovk|(?:č|c)evap|jagnj|zrez|pe(?:č|c)enk|gola(?:ž|z)|bolonjsk|kebab|burger/u, 'meso'],
  // (v3.50) »tunina«, »tuno«; skuša samo na začetku besede (»kuskus« ni riba), edamame ni sir edamec
  [/\brib(?:a|e|i|o|ah|ami)?\b|\bribj|\btun(?:a|e|i|o|u|in\p{L}*)?(?![\p{L}])|losos|osli(?:č|c)|sardel|(?<!\p{L})sku(?:š|s)|postrv|brancin|orad|kozic|lignj|(?:š|s)koljk|morsk|in(?:ć|č|c)un|bakala/u, 'riba'],
  [/mlek|mle(?:č|c)n|jogurt|skut|\bsir(?:a|u|om|i|ov|e)?\b|kefir|smetan|\bmasl(?:o|a|om|u)\b|parmez|mocarel|mozzarel|\bfet[aeo]\b|rikot|maskarpon|edam(?!ame)|gavd|ementaler/u, 'mleko'],
  // (v3.51) tudi müsli, granola, pica, burek, krekerji, drobtine, keksi, pecivo, panirano, seitan (prej SPREJET pri celiakiji)
  // (v3.51) tudi sojina omaka (pšenica; tamari je brez glutena), teriyaki, zdrob (griz), krutoni, lazanja, rezanci, cmoki, štruklji
  [/kruh|testenin|(?:š|s)paget|makaron|p(?:š|s)eni(?:č|c)|\bmok[aeo]\b|kuskus|kus-kus|bulgur|je(?:č|c)men|je(?:š|s)prenj|(?<!\p{L})pir(?:[aeo]|in\p{L}*)(?!\p{L})|\bovs|ovsen|tortilj|(?:ž|z)emlj|njok|sendvi(?:č|c)|toast|m(?:ü|u)sli|granol|(?<!\p{L})pic[aeiou](?!\p{L})|(?<!\p{L})pizz|burek|kreker|drobtin|keks|pi(?:š|s)kot|pecivo|roglji(?:č|c)|(?<!\p{L})krof|(?:jabol(?:č|c)n|sirov|orehov|skutin|makov)\p{L}*\s+zavit|panir|seitan|pala(?:č|c)ink|(?<!\p{L})pivo|(?<!\p{L})piva(?!\p{L})|sojin\p{L}*\s+omak(?!\p{L}*\s+brez\s+glutena)|teriyak|(?<!\p{L})zdrob(?:a|om|u)?(?!\p{L})|(?<!\p{L})gri(?:z|ž)(?:a|om|u)?(?!\p{L})|kruton|lazanj|rezanc|(?<!\p{L})cmok|(?:š|s)trukl/u, 'gluten'],
  // (v3.50) jajčevec ni jajce
  [/jaj(?:c|č)(?!ev)|omlet/u, 'jajca'],
  [/ore(?:š|s)|oreh|mandl|le(?:š|s)nik|ara(?:š|s)id|indijsk|pistacij|pinjol/u, 'oreski'],
  [/\bsoj|tofu|tempeh|edamame/u, 'soja'],
]
// rastlinski »napitki«, »jogurti« in »masla« (tudi kakavovo) niso mlečni izdelki; »brez glutena« ni gluten
const PLANT = /(?:soj|ovsen|ri(?:ž|z)ev|mandljev|kokosov|kakavov|rastlinsk|ara(?:š|s)idov|le(?:š|s)nikov|indijsk)\p{L}*\s+(?:mlek|napit|jogurt|masl|smetan|sir|pija)\p{L}*/gu
// (v3.49) moke brez glutena (koruzna, ajdova, riževa, mandljeva, kokosova, prosena) niso gluten — kot ajda in polenta v knjižnici
const GF_FLOUR = /(?:koruzn|ajdov|ri(?:ž|z)ev|mandljev|kokosov|prosen|kvinoj|(?:č|c)i(?:č|c)erik|krompirjev|tapiok)\p{L}*\s+(?:mok|zdrob|rezanc|testenin)\p{L}*/gu
const LACTOSE = /mlek|mle(?:č|c)n|jogurt|skut|kefir|smetan|rikot|maskarpon|mocarel|mozzarel|sve(?:ž|z)\p{L}*\s+sir|sladoled/u
/** (v3.50) med (živalski izdelek — večina veganov ga ne je); ne predlog »med« pred številko ali »med kuhanjem« */
const HONEY = /(?<!\p{L})(?:med(?=\s*(?:\d|\(|,|;|$))|medu|medom|meden\p{L}*)(?!\p{L})/u
/** (v3.51) živalski izdelki, ki niso meso, riba, mleko ali jajca (beljakovine v prahu, želatina) */
const VEGAN_NO = /whey|sirotk|kazein|(?:ž|z)elatin|kolagen|jaj(?:č|c)n|beljak\p{L}*\s+v\s+prahu(?!\s*\(?(?:rastlin|grah|soj|ri(?:ž|z)))/u
/** Ali AI recept (ime in sestavine) ustreza prehranskim željam; pri »brez laktoze« samo mlečni izdelki brez laktoze ali trdi sir. */
export function recipeOkFor(r: Pick<Recipe, 'name' | 'ingredients'>, prefs: string | null | undefined, date?: string): boolean {
  const ex = exclusionsOf(prefs, date)
  if (!ex.contains.length && !ex.words.length && !ex.lactoseFree && !ex.pork && !ex.noSugar) return true
  const parts = [r.name, ...r.ingredients.map(i => i.text)].map(t => (t || '').toLowerCase())
  for (const t0 of parts) {
    // (v3.50) vegan: brez medu; (v3.51) tudi brez sirotke (whey), kazeina, želatine in kolagena
    if (ex.vegan && (HONEY.test(t0) || VEGAN_NO.test(t0))) return false
    // (v3.51) brez svinjine: pršut, slanina, ocvirki, klobase (puranja šunka ostane)
    if (ex.pork && PORK_RE.test(t0.replace(NOT_PORK, ' '))) return false
    // (v3.51) brez sladkorja: med, marmelada, sladkor, sirup
    if (ex.noSugar && (HONEY.test(t0) || /marmelad|sladkor(?!\p{L}*\s+bolez)|sirup|nutel|(?:č|c)okolad/u.test(t0.replace(/brez\s+(?:dodanega\s+)?sladkorja/gu, ' ')))) return false
    const milk = t0.replace(PLANT, ' '), glu = t0.replace(/\p{L}+\s+brez\s+glutena/gu, ' ').replace(GF_FLOUR, ' ')
    for (const [rx, k] of TEXT_WORDS) {
      if (!ex.contains.includes(k)) continue
      if (rx.test(k === 'mleko' ? milk : k === 'gluten' ? glu : t0)) return false
    }
    if (ex.lactoseFree && !/brez laktoze/u.test(t0) && LACTOSE.test(milk)) return false
  }
  return !wordsHit(parts.join(' '), ex.words)
}

export interface Recipe {
  dish: string; name: string; kcal: number; p: number; c: number; f: number; minutes: number
  ingredients: { key: string; qty: number; text: string; /** dodatek k jedi (kruh, banana, jogurt), da obrok doseže svoje */ side?: boolean }[]
  steps: string[]
  /** zakaj prav ta obrok zate */
  why: string
  /** vir: knjižnica (pravila) ali AI */
  by: 'pravila' | 'ai'
}
export interface RecipeCtx { deficit: boolean; keepMuscle: boolean; training: boolean; prefs?: string | null; /** zamik za »drug predlog« */ alt?: Record<string, number> }

const r1 = (x: number) => Math.round(x)
/** zgornje meje količin (na obrok), da beljakovine ne napihnejo jedi v nesmisel */
// (v3.50) tofu največ zavitek (200 g; prej 250)
const CAP: Record<string, number> = { jajce: 4, skuta: 250, jogurt: 350, kefir: 400, mleko: 400, piscanec: 220, puran: 220, tuna: 160, losos: 200, tofu: 200, leca: 300, fizol: 300, cicerika: 300, sir: 50, govedina: 220, mleto: 180, oslic: 250, sunka: 100, sojmleko: 400, sojjogurt: 350, sojkos: 90, edamame: 250 }
/**
 * REALNE PORCIJE (Blaž, 16. 10.: »za jest naj bo realno … ne na hojladri«): največ, kar človek poje v enem obroku.
 * Prej se je jed samo sorazmerno napihnila (zajtrk: 350 g skute in 340 g sadja); zdaj sestavina ne gre čez mero —
 * kar obroku manjka, doda dodatek, kot bi ga dal vsak (rezina kruha, banana, lonček jogurta).
 */
// (v3.50) krožnik ne čez ~800 g: krompir 350 g (≈ 2 kosa; prej 450), solata 200, zelenjava 300, tofu zavitek 200
export const PORTION_MAX: Record<string, number> = {
  oves: 100, jogurt: 350, banana: 2, med: 25, kruh: 120, riz: 130, testenine: 140, krompir: 350, piscanec: 220, tuna: 160, jajce: 4,
  skuta: 250, mleko: 400, olje: 15, oreski: 30, zelenjava: 300, sadje: 300, omaka: 250, fizol: 300, cicerika: 300, belkruh: 150, marmelada: 40,
  rizb: 140, testenineb: 150, krompirb: 400, puran: 220, losos: 200, tofu: 200, leca: 300, kefir: 400, sir: 50, cebula: 60, solata: 200, jabolko: 2, kuskus: 130,
  ajda: 120, polenta: 120, jesprenj: 100, govedina: 220, mleto: 180, oslic: 250, sunka: 100, zelje: 300, sojmleko: 400, sojjogurt: 350, arasid: 30, sok: 400, moka: 140,
  sojkos: 90, edamame: 250,
}
/** (v3.50) pred vožnjo (lahko) in po dolgi vožnji ali tekmi (obnova brez težke hrane) */
const BEFORE_RIDE_MAX: Record<string, number> = { zelenjava: 150, solata: 150, skuta: 150, oreski: 10, sadje: 150 }
const RECOVERY_MAX: Record<string, number> = { fizol: 150, cicerika: 150, leca: 150, zelenjava: 200, solata: 150, sir: 30 }
/** (v3.50) teža krožnika v g (kos: banana ~120 g, jabolko ~180 g, jajce ~55 g; brez dodatkov »zraven«) */
const KOS_G: Record<string, number> = { banana: 120, jabolko: 180, jajce: 55 }
const PLATE_MAX = 800
export const plateG = (r: Pick<Recipe, 'ingredients'>) => r.ingredients.filter(i => !i.side && F[i.key]).reduce((s, i) => s + (F[i.key]!.unit === 'kos' ? (KOS_G[i.key] ?? 100) * i.qty : i.qty), 0)
/** največ, za koliko sme beljakovinski dodatek preseči kalorije obroka */
const KCAL_OVER = 1.15
const kcalOfItem = (x: { key: string; qty: number }) => (F[x.key]!.kcal * x.qty) / F[x.key]!.per
/**
 * Jed pomeri na obrok: najprej po kalorijah (×0,3–2), nato beljakovine — če jih je premalo (< 90 % obroka), gre gor
 * beljakovinsko najgostejša sestavina (do 2× osnove in do zgornje meje), ostale sorazmerno dol (ne pod 40 %), da kalorije
 * ostanejo; kalorije smejo čez obrok največ za 15 % (fižol ali jogurt se ne napihneta v nesmisel). Pri primanjkljaju olja
 * manj. Če beljakovin še vedno manjka, to pove besedilo »zakaj«, izbira jedi pa raje vzame tako, ki jih doseže (bestFits).
 * (v3.48) Pred tekmo (lf) dodatki brez vlaknin (bel kruh, banana); pred vožnjo (beforeRide) tudi, zelenjave in solate
 * največ 150 g in olja manj.
 */
export type FitCtx = Pick<RecipeCtx, 'deficit'> & Partial<Pick<RecipeCtx, 'prefs' | 'training'>> & { lf?: boolean; beforeRide?: boolean; /** (v3.49) koliko banan še gre v dan (meja dneva, skupaj z gorivom na kolesu) */ bananas?: number; /** (v3.50) obrok po dolgi vožnji ali tekmi: lahko (malo stročnic, maščob, zelenjave) */ recovery?: boolean }
/** (v3.50) zamenjava živila, ki ga ne maraš, ko za obrok ni jedi brez njega (banana → jabolko); rodilnik za »brez …« */
const SWAP: Record<string, readonly string[]> = { banana: ['jabolko', 'sadje'], jabolko: ['sadje', 'banana'], sadje: ['jabolko', 'banana'], med: ['marmelada'], marmelada: ['med'] }
const GEN: Record<string, string> = { banana: 'banane', jabolko: 'jabolka', sadje: 'sadja', med: 'medu', marmelada: 'marmelade' }
const ACC: Record<string, string> = { banana: 'banano', jabolko: 'jabolko', sadje: 'drugo sadje', med: 'med', marmelada: 'marmelado' }
/** (v3.50) najmanj, da je sestavina še del jedi (prej »riž 30 g« v curryju z rižem, »testenine 10 g«, »kosmiči 10 g«) */
// (osnova velja od 300 kcal; manjši glavni obrok je »majhen obrok« — jogurt s sadjem, jajca s kruhom)
const MIN_QTY: Record<string, number> = { riz: 40, rizb: 40, testenine: 40, testenineb: 40, kuskus: 40, ajda: 40, polenta: 40, jesprenj: 40, krompir: 80, krompirb: 80, oves: 20, oreski: 10, kruh: 30, belkruh: 30, solata: 50 }
const MIN_ALWAYS = new Set(['oves', 'oreski'])
// (v3.51) obložen kruh (»Kruh s …«, sendvič): kruh vsaj rezina in solata vsaj 50 g že od 250 kcal (prej »kruh 20 g (½ rezine)« in
// 20 g solate ob 160 g tofuja); pri drugih jedeh je kruh priloga, ki gre dol
const MIN_FROM: Record<string, number> = { kruh: 250, belkruh: 250, solata: 250 }
const SANDWICH = /^(?:bel\s+)?kruh|^sendvi/iu
/** (v3.50) kosmiči in kaša: mleko, napitek in jogurt največ 5 × kosmičev (prej 50 g kosmičev v 550 g tekočine) */
const LIQ = ['mleko', 'sojmleko', 'jogurt', 'sojjogurt'], GRAIN = ['oves', 'ajda'], LIQ_MAX = 5
export function fitDish(d: Dish, kcal: number, proteinG: number, ctx: FitCtx, carbsG?: number): Omit<Recipe, 'why' | 'by'> {
  const tot = (items: { key: string; qty: number }[]) => items.reduce((a, i) => { const f = F[i.key]!; return { k: a.k + (f.kcal * i.qty) / f.per, p: a.p + (f.p * i.qty) / f.per, c: a.c + (f.c * i.qty) / f.per, f: a.f + (f.f * i.qty) / f.per } }, { k: 0, p: 0, c: 0, f: 0 })
  const light = !!(ctx.lf || ctx.beforeRide)
  const ex = exclusionsOf(ctx.prefs)
  const minQ = (key: string) => (MIN_ALWAYS.has(key) || kcal >= (MIN_FROM[key] != null && SANDWICH.test(d.name) ? MIN_FROM[key]! : 300) ? MIN_QTY[key] ?? 0 : 0)
  // (v3.50) vegan: marmelada namesto medu; živilo, ki ga ne maraš (ko jedi brez njega za obrok ni), zamenja podobno
  const swapped: [string, string][] = []
  // (v3.51) »ne maram čebule« in »brez sladkorja«: sestavino izpustiš (jed ostane), kalorije pomeri ostalo
  const noOnion = !!ex.skip?.includes('čebula'), noSugarItems = d.items.filter(([k]) => ex.noSugar && (k === 'med' || k === 'marmelada'))
  const src0: Tpl = d.items.filter(([k]) => !(noOnion && k === 'cebula') && !noSugarItems.some(([x]) => x === k)).map(([k0, q]) => {
    const key = k0 as string
    const to = key === 'med' && ex.vegan ? 'marmelada' : ex.words.length && wordsHit(nameOf(key), ex.words) ? SWAP[key]?.find(x => !wordsHit(nameOf(x), ex.words) && !(x === 'med' && ex.vegan)) : undefined
    if (!to) return [k0, q]
    if (!(key === 'med' && ex.vegan)) swapped.push([key, to])
    const f = F[key]!, g = F[to]!
    const q2 = f.unit === 'kos' && g.unit === 'kos' ? q : g.unit === 'kos' ? Math.max(1, Math.round((f.kcal * q) / f.per / g.kcal)) : Math.round(((f.kcal * q) / f.per / g.kcal) * g.per)
    return [to as keyof typeof F, q2]
  })
  // dvakrat isto živilo (banana in jabolko → jabolko): skupaj
  const src: Tpl = src0.reduce<Tpl>((a, [k1, q]) => { const i = a.findIndex(([k2]) => k2 === k1); if (i >= 0) a[i] = [k1, a[i]![1] + q]; else a.push([k1, q]); return a }, [])
  const tpl: Tpl = ctx.deficit || ctx.beforeRide || ctx.recovery ? src.map(([k, q]) => (k === 'olje' ? [k, Math.max(5, q - 5)] : [k, q]) as [keyof typeof F, number]) : src
  const base = tpl.reduce((s, [k, q]) => s + (F[k]!.kcal * q) / F[k]!.per, 0)
  const k = Math.max(0.3, Math.min(2, kcal / base))
  let items = tpl.map(([key, q]) => ({ key: key as string, qty: qtyOf(key as string, q, k) }))
  let t = tot(items)
  // kos (banana, jajce) ne gre pod 1: če jed zato preseže obrok, ostale sestavine še malo dol
  if (t.k > kcal * 1.05) {
    const fixed = items.filter(x => x.qty === qtyOf(x.key, x.qty, 0.01))
    const fixedK = fixed.reduce((s, x) => s + kcalOfItem(x), 0)
    const restBase = tpl.filter(([key]) => !fixed.some(x => x.key === key)).reduce((s, [key, q]) => s + (F[key]!.kcal * q) / F[key]!.per, 0)
    if (fixed.length && restBase > 0) {
      const k2 = Math.max(0.3, Math.min(k, (kcal - fixedK) / restBase))
      items = tpl.map(([key, q]) => ({ key: key as string, qty: fixed.some(x => x.key === key) ? qtyOf(key as string, q, k) : qtyOf(key as string, q, k2) }))
      t = tot(items)
    }
  }
  // kos zaokrožen navzgor čez obrok (2 banani namesto 1,6): en kos manj, če je potem bližje obroku
  for (let n = 0; n < 4 && t.k > kcal * 1.1; n++) {
    const cand = items.map((x, i) => ({ x, i })).filter(({ x }) => F[x.key]!.unit === 'kos' && x.qty > 1).sort((a, b) => kcalOfItem(b.x) - kcalOfItem(a.x))[0]
    if (!cand) break
    const next = items.map((x, i) => (i === cand.i ? { ...x, qty: x.qty - 1 } : x))
    const tn = tot(next)
    if (Math.abs(tn.k - kcal) >= Math.abs(t.k - kcal)) break
    items = next; t = tn
  }
  // beljakovine: najgostejša beljakovinska sestavina (g beljakovin na kcal) gor, ostalo sorazmerno dol
  const pi = items.map((x, i) => ({ x, i })).filter(({ x }) => PROTEIN_KEYS.has(x.key)).sort((a, b) => F[b.x.key]!.p / F[b.x.key]!.kcal - F[a.x.key]!.p / F[a.x.key]!.kcal)[0]
  // velik obrok: ko je beljakovin precej čez cilj (skuta 450 g), gre beljakovinska sestavina nazaj proti osnovi, ostalo gor
  if (pi && t.p > proteinG * 1.3 && k > 1) {
    const f = F[pi.x.key]!
    const baseQ = tpl.find(([key]) => key === pi.x.key)![1]
    const perP = f.p / f.per, perK = f.kcal / f.per
    const otherP = t.p - perP * pi.x.qty
    const q2 = qtyOf(pi.x.key, Math.max(baseQ, Math.min(pi.x.qty, (proteinG * 1.15 - otherP) / perP)), 1)
    if (q2 < pi.x.qty) {
      const others = items.filter((_, i) => i !== pi.i)
      const restK = others.reduce((s, x) => s + kcalOfItem(x), 0)
      const g = restK > 0 ? Math.min(1.6, (kcal - perK * q2) / restK) : 1
      items = items.map((x, i) => (i === pi.i ? { ...x, qty: q2 } : g > 1 ? { ...x, qty: qtyOf(x.key, x.qty, g) } : x))
      t = tot(items)
    }
  }
  if (pi && t.p < proteinG * 0.9) {
    const f = F[pi.x.key]!
    const perK = f.kcal / f.per, perP = f.p / f.per
    const baseQ = tpl.find(([key]) => key === pi.x.key)![1]
    const need = proteinG * 0.95 - t.p
    const others = items.filter((_, i) => i !== pi.i)
    const restK = others.reduce((s, x) => s + kcalOfItem(x), 0)
    // kalorije ostalih sestavin, ko gredo na 40 % (kos ne pod 1) → koliko beljakovinske sestavine gre še v obrok
    // (v3.50) osnova (riž, testenine, krompir, kosmiči) ne pod svojo mero — prej »riž 30 g« ob 240 g čičerike
    const lowQ = (x: { key: string; qty: number }, g: number) => Math.max(qtyOf(x.key, x.qty, g), Math.min(x.qty, minQ(x.key)))
    const floorK = others.reduce((s, x) => s + kcalOfItem({ key: x.key, qty: lowQ(x, 0.4) }), 0)
    // (v3.50) stročnice največ ×1,5 osnove (prej ×2: »čičerika 240 g, riž 30 g« v curryju z rižem)
    const grow = LEGUMES.has(pi.x.key) ? 1.5 : 2
    const maxQ = Math.min(baseQ * grow, CAP[pi.x.key] ?? baseQ * grow, (kcal * KCAL_OVER - floorK) / perK)
    let q2 = qtyOf(pi.x.key, Math.min(maxQ, pi.x.qty + need / perP), 1)
    // zaokrožitev navzgor čez mejo → korak dol
    const down = (q: number) => { const a = qtyOf(pi.x.key, q - (f.unit === 'kos' ? 1 : 5), 1); return a < q ? a : qtyOf(pi.x.key, q - 10, 1) }
    while (q2 > pi.x.qty && perK * q2 + floorK > kcal * KCAL_OVER + 1) { const n = down(q2); q2 = n < q2 ? n : pi.x.qty }
    // če tudi z dodatkom ne pride do 85 % beljakovin (fižol v humusu), jed ostane uravnotežena — izbira raje vzame drugo
    // (v3.51) meja 75 % (prej 85 %): obložen kruh z rezino kruha (E17) do beljakovin pride z več tofuja
    if (q2 > pi.x.qty && t.p + perP * (q2 - pi.x.qty) < proteinG * 0.75) q2 = pi.x.qty
    if (q2 > pi.x.qty) {
      const target = Math.max(0, kcal - perK * q2)
      const g = restK > 0 && target < restK ? Math.max(0.4, target / restK) : 1
      items = items.map((x, i) => (i === pi.i ? { ...x, qty: q2 } : g < 1 ? { ...x, qty: lowQ(x, g) } : x))
      t = tot(items)
    }
  }
  // realne porcije: nobena sestavina čez mero na obrok; pred vožnjo zelenjave in solate največ 150 g (v3.48)
  // (v3.50) pred vožnjo tudi skuta 150 g in oreški 10 g (prej 250 g skute pred 3-urno vožnjo); po dolgi vožnji ali tekmi
  // stročnic 150 g in zelenjave 200 g (prej 300 g čičerike in 280 g zelenjave po tekmi)
  const maxOf = (key: string) => (ctx.beforeRide ? BEFORE_RIDE_MAX[key] : undefined) ?? (ctx.recovery ? RECOVERY_MAX[key] : undefined) ?? PORTION_MAX[key]
  items = items.map(x => (maxOf(x.key) != null && x.qty > maxOf(x.key)! ? { ...x, qty: maxOf(x.key)! } : x))
  // (v3.50) kosmiči in kaša niso juha: tekočina in jogurt največ 5 × kosmičev (najprej manj napitka, nato jogurta)
  const grain = d.snack ? 0 : items.filter(x => GRAIN.includes(x.key)).reduce((a, x) => a + x.qty, 0)
  if (grain > 0) {
    let over = items.filter(x => LIQ.includes(x.key)).reduce((a, x) => a + x.qty, 0) - grain * LIQ_MAX
    for (const key of LIQ) {
      if (over <= 0) break
      const i = items.findIndex(x => x.key === key)
      if (i < 0) continue
      const q = Math.max(0, Math.floor((items[i]!.qty - over) / 10) * 10)
      over -= items[i]!.qty - q
      items = q > 0 ? items.map((x, j) => (j === i ? { ...x, qty: q } : x)) : items.filter((_, j) => j !== i)
    }
  }
  // (v3.50) drobiž po pomanjšanju: osnova (riž, testenine, krompir, kosmiči) ne pod mero, oreški najmanj 10 g (prej 5 g)
  items = items.map(x => (x.qty < minQ(x.key) ? { ...x, qty: minQ(x.key) } : x))
  // (v3.50) krožnik največ ~800 g (prej 900–1 000 g: krompir 450 g + solata 300 g): najprej manj zelenjave in solate (ne pod
  // 100 g), nato krompirja (ne pod 200 g); kar manjka kalorij, doda dodatek
  for (const key of ['zelenjava', 'solata', 'zelje', 'krompir', 'krompirb']) {
    const over = plateG({ ingredients: items.map(x => ({ ...x, text: '' })) }) - PLATE_MAX
    if (over <= 0) break
    const i = items.findIndex(x => x.key === key)
    if (i < 0) continue
    const q = Math.max(key.startsWith('krompir') ? 200 : 100, Math.floor((items[i]!.qty - over) / 10) * 10)
    if (q < items[i]!.qty) items = items.map((x, j) => (j === i ? { ...x, qty: q } : x))
  }
  // (v3.49) banane: ne čez to, kar še gre v dan (jed z banano jo obdrži eno)
  if (ctx.bananas != null) items = items.map(x => (x.key === 'banana' && x.qty > Math.max(1, ctx.bananas!) ? { ...x, qty: Math.max(1, ctx.bananas!) } : x))
  t = tot(items)
  // dodatek, ko jed z realnimi porcijami ne doseže obroka (največ dva)
  const sides: { key: string; qty: number }[] = []
  const soy = soyOk(ex, ctx.prefs)
  const banLeft = () => (ctx.bananas == null ? 99 : ctx.bananas - [...items, ...sides].filter(x => x.key === 'banana').reduce((a, x) => a + x.qty, 0))
  const allowed = (key: string) => !(SIDE_CONTAINS[key] || []).some(c => ex.contains.includes(c)) && !items.some(x => x.key === key) && !wordsHit(nameOf(key), ex.words) && (!(key === 'tofu' || key === 'sojjogurt') || soy) && (key !== 'banana' || banLeft() >= 1) && !(ex.noSugar && key === 'sok')
  for (let n = 0; n < 2; n++) {
    const all = [...items, ...sides]
    const tt = tot(all)
    const miss = kcal - tt.k
    // dodatek že pri ~5 % manjka (prej 10 %: dan z vožnjo je bil skupaj ~150 kcal pod ciljem — skrit primanjkljaj)
    if (miss < Math.max(50, kcal * 0.05)) break
    const needP = tt.p < proteinG * 0.85, needC = carbsG != null ? tt.c < carbsG * 0.8 : true
    const morning = d.tpl === 'zajtrk' || d.tpl === 'malica' || d.tpl === 'pred'
    // (v3.48) beljakovine tudi brez mleka (tofu, čičerika — k glavnemu obroku); pred tekmo in vožnjo brez polnozrnatega
    // kruha in sadja z lupino; ko beljakovinskega dodatka ni, vsaj OH, da obrok doseže svoje
    const carbOrder = light ? ['banana', 'belkruh', 'sok'] : needC ? (morning ? ['banana', 'kruh', 'sadje', 'sok'] : ['kruh', 'sadje', 'banana']) : ['sadje', 'kruh', 'banana']
    // (v3.49) vegan: sojin jogurt k zajtrku in malici (prej brez beljakovinskega dodatka)
    // (v3.51) k slanemu obroku kuhana jajca, tofu ali čičerika; jogurt samo kot sladica (en lonček) — prej »zraven: grški jogurt 300 g« k leči z rižem
    const order = needP ? (morning ? ['jogurt', 'skuta', 'mleko', 'sojjogurt'] : ['jajce', 'tofu', ...(light ? [] : ['cicerika']), 'jogurt']).concat(carbOrder) : carbOrder
    const key = order.find(k => allowed(k) && !sides.some(x => x.key === k))
    if (!key) break
    const f = F[key]!
    const unitK = f.unit === 'kos' ? f.kcal : (f.kcal * SIDE_STEP[key]!) / f.per
    const steps = Math.max(1, Math.min(!morning && key === 'jogurt' ? 1 : SIDE_MAX[key]!, key === 'banana' ? banLeft() : 99, Math.round(miss / unitK)))
    sides.push({ key, qty: f.unit === 'kos' ? steps : steps * SIDE_STEP[key]! })
  }
  const all = [...items, ...sides]
  t = tot(all)
  const sideTxt = sides.map(x => sideText(x.key, x.qty, ex.lactoseFree, !(d.tpl === 'zajtrk' || d.tpl === 'malica' || d.tpl === 'pred')))
  // (v3.50) veganska različica besedila (marmelada namesto medu); zamenjano živilo, ki ga ne maraš, pove ime in prvi korak
  const vg = ex.vegan && d.vg ? d.vg : null
  const swapNote = swapped.map(([a, b]) => `Namesto ${GEN[a]} vzemi ${ACC[b]}.`)
  // (v3.51) čebula in česen v korakih: izpusti ju (jed ostane); brez sladkorja: med in marmelado izpusti
  // (v3.51) brez glutena: sojina omaka brez glutena (tamari) — navadna je iz pšenice
  const steps0 = (vg ? vg.steps : d.steps).map(x => (ex.contains.includes('gluten') ? gfSoy(x) : x))
  const inSteps = (rx: RegExp) => rx.test(steps0.join(' ')) || d.items.some(([k]) => k === 'cebula')
  const sk = (ex.skip || []).filter(x => inSteps(x === 'čebula' ? /(?:č|c)ebul/iu : /(?:č|c)esn|(?:č|c)esen/iu))
  const onionNote = sk.length === 2 ? 'Brez čebule in česna: v korakih ju izpusti — namesto njiju ščep kumine ali sladke paprike.' : sk[0] === 'čebula' ? 'Brez čebule: v korakih jo izpusti — namesto nje ščep kumine ali sladke paprike.' : sk[0] === 'česen' ? 'Brez česna: v korakih ga izpusti.' : null
  const sugarNote = noSugarItems.length ? 'Brez medu in marmelade (brez sladkorja): sladkanje v korakih izpusti — po želji cimet.' : null
  const garlicOnly = !noOnion && !!ex.skip?.includes('česen')
  return {
    dish: d.id, name: `${vg ? vg.name : d.name}${swapped.length ? ` (brez ${swapped.map(([a]) => GEN[a]).join(' in ')})` : noSugarItems.length ? ` (brez ${noSugarItems.map(([k]) => GEN[k]).join(' in ')})` : ''}`, kcal: r1(t.k), p: r1(t.p), c: r1(t.c), f: r1(t.f), minutes: d.minutes,
    ingredients: [...items.map(i => ({ ...i, text: garlicOnly && i.key === 'cebula' ? ingText(i.key, i.qty).replace(F.cebula!.name, 'čebula') : ingText(i.key, i.qty, ex.lactoseFree) })), ...sides.map((i, j) => ({ ...i, text: sideTxt[j]!, side: true }))],
    // dodatek je med sestavinami (»zraven: …«) — ne še enkrat kot korak priprave
    steps: [...swapNote, ...(onionNote ? [onionNote] : []), ...(sugarNote ? [sugarNote] : []), ...steps0],
  }
}
/** (v3.51) sojina omaka je iz pšenice: pri »brez glutena« sojina omaka brez glutena (tamari) */
const gfSoy = (t: string): string => t.replace(/(sojin\p{L}*)\s+(omak\p{L}*)(?!\s+brez\s+glutena)/gu, '$1 $2 brez glutena (tamari)')
/** (v3.51) čisti viri OH (ne stročnice — te so beljakovina) */
const TRIM_KEYS = ['riz', 'rizb', 'testenine', 'testenineb', 'krompir', 'krompirb', 'kruh', 'belkruh', 'oves', 'kuskus', 'ajda', 'polenta', 'jesprenj', 'moka', 'sadje', 'sok', 'med', 'marmelada']
const TRIM_SIDES = new Set(['kruh', 'belkruh', 'banana', 'sadje', 'sok'])
/** (v3.51) recept z manj OH za `cut` g: najprej OH dodatek »zraven«, nato glavni vir OH (ne pod mero jedi in ne pod polovico) */
function trimCarbs(fit: Omit<Recipe, 'why' | 'by'>, cut: number, lf?: boolean): Omit<Recipe, 'why' | 'by'> {
  let left = cut
  const cOf = (i: { key: string; qty: number }) => (F[i.key]!.c * i.qty) / F[i.key]!.per
  let ings = fit.ingredients.map(i => ({ ...i }))
  for (const i of ings.filter(x => x.side && TRIM_SIDES.has(x.key))) { if (left <= 0) break; left -= cOf(i); ings = ings.filter(x => x !== i) }
  for (const i of ings.filter(x => !x.side && F[x.key] && F[x.key]!.unit !== 'kos' && TRIM_KEYS.includes(x.key)).sort((a, b) => cOf(b) - cOf(a))) {
    if (left <= 0) break
    const per = F[i.key]!.c / F[i.key]!.per, step = SMALL_KEYS.has(i.key) ? 5 : 10
    const q2 = Math.max(MIN_QTY[i.key] ?? 0, Math.ceil(i.qty / 2 / step) * step, Math.ceil((i.qty - left / per) / step) * step)
    if (q2 >= i.qty) continue
    left -= (i.qty - q2) * per
    i.qty = q2; i.text = ingText(i.key, q2, lf)
  }
  const t = ings.filter(i => F[i.key]).reduce((a, i) => { const f = F[i.key]!; return { k: a.k + (f.kcal * i.qty) / f.per, p: a.p + (f.p * i.qty) / f.per, c: a.c + (f.c * i.qty) / f.per, f: a.f + (f.f * i.qty) / f.per } }, { k: 0, p: 0, c: 0, f: 0 })
  return { ...fit, ingredients: ings, kcal: r1(t.k), p: r1(t.p), c: r1(t.c), f: r1(t.f) }
}
const SMALL_KEYS = new Set(['olje', 'med', 'oreski', 'marmelada', 'arasid'])
/** (v3.51) besedilo dodatka: k slanemu obroku »2 kuhani jajci«, jogurt kot sladica (prej »zraven: grški jogurt 300 g« k leči z rižem) */
function sideText(key: string, qty: number, lf?: boolean, savory = false): string {
  if (key === 'jajce') return `zraven: ${qty} ${qty === 1 ? 'kuhano jajce' : qty === 2 ? 'kuhani jajci' : 'kuhana jajca'}`
  if (savory && key === 'jogurt') return `za sladico: ${ingText(key, qty, lf)}`
  return `zraven: ${ingText(key, qty, lf)}`
}
/** dodatki k jedi: korak (g ali kos) in največ korakov; kaj vsebujejo (za želje) */
const SIDE_STEP: Record<string, number> = { kruh: 40, belkruh: 40, sadje: 150, banana: 1, jogurt: 150, skuta: 125, mleko: 250, tofu: 100, cicerika: 150, sok: 200, sojjogurt: 150, jajce: 1 }
const SIDE_MAX: Record<string, number> = { kruh: 3, belkruh: 3, sadje: 2, banana: 2, jogurt: 2, skuta: 2, mleko: 1, tofu: 2, cicerika: 1, sok: 1, sojjogurt: 2, jajce: 2 }
const SIDE_CONTAINS: Record<string, Contains[]> = { kruh: ['gluten'], belkruh: ['gluten'], jogurt: ['mleko'], skuta: ['mleko'], mleko: ['mleko'], tofu: ['soja'], sojjogurt: ['soja'], jajce: ['jajca'] }
/** ali ime živila zadene katero od besed »ne maram …« */
const wordsHit = (name: string, words: readonly string[]) => {
  if (!words.length) return false
  const tokens = toks(name), text = name.toLowerCase()
  return words.some(w => wordHit(w, tokens, [], text))
}
/** (v3.51) ali živilo iz primera (»skuta«, »kruh z jajcem«) ustreza željam: skupine (alergije, vegan) in živila, ki jih ne maraš */
export const foodOk = (name: string, contains: readonly Contains[], ex: Exclusions): boolean => !contains.some(c => ex.contains.includes(c)) && !wordsHit(name, ex.words)

/** Kaj dodati za beljakovine po željah (v3.48: vegan in brez laktoze ne dobita »jogurt ali skuto«). */
// (v3.51) noLegume: ko je OH že čez cilj obroka, ne čičerika (doda OH) — samo tofu ali jajce
function proteinAdd(ex: ReturnType<typeof exclusionsOf>, lf: boolean, have: readonly string[], morning = false, noLegume = false): string | null {
  const ok = (c: Contains) => !ex.contains.includes(c)
  // (v3.50) brez živil, ki jih ne maraš (»ne maram skute« → samo jogurt)
  const like = (key: string) => !wordsHit(nameOf(key), ex.words)
  if (ok('mleko')) {
    const m = [like('jogurt') ? 'jogurt' : null, like('skuta') ? 'skuto' : null].filter(Boolean).join(' ali ')
    if (m) return ex.lactoseFree ? `${m} brez laktoze` : m
  }
  // (v3.50) vegan zjutraj in za malico: sojin jogurt ali napitek (prej »dodaj tofu« k humusu in kosmičem čez noč)
  if (morning && ok('soja') && !have.includes('sojjogurt') && like('sojjogurt')) return 'sojin jogurt (150 g) ali kozarec sojinega napitka'
  const opts = [ok('soja') && !have.includes('tofu') && like('tofu') ? (noLegume ? '100 g tofuja' : 'tofu') : null, !lf && !noLegume && !have.includes('cicerika') && !have.includes('fizol') && like('cicerika') ? 'čičeriko' : null, ok('jajca') && !have.includes('jajce') && like('jajce') ? 'jajce' : null].filter((x): x is string => !!x).slice(0, 2)
  return opts.length ? opts.join(' ali ') : null
}
/** (v3.51) glavni vir OH v rodilniku (»vzemi ~60 g polente namesto 80 g«) */
const CARB_GEN: Record<string, string> = { riz: 'riža', rizb: 'riža', testenine: 'testenin', testenineb: 'testenin', krompir: 'krompirja', krompirb: 'krompirja', kruh: 'kruha', belkruh: 'kruha', oves: 'kosmičev', kuskus: 'kuskusa', ajda: 'ajdove kaše', polenta: 'polente', jesprenj: 'ješprenja', moka: 'moke', leca: 'leče', fizol: 'fižola', cicerika: 'čičerike', sadje: 'sadja', sok: 'soka' }
/** (v3.51) presežek OH obroka: katere sestavine vzemi manj in koliko (null, če ni glavne OH sestavine v gramih) */
function lessCarb(r: Pick<Recipe, 'c'> & Partial<Pick<Recipe, 'ingredients'>>, goal: number): string | null {
  const main = (r.ingredients || []).filter(i => !i.side && F[i.key] && F[i.key]!.unit !== 'kos' && CARB_GEN[i.key]).sort((a, b) => (F[b.key]!.c * b.qty) / F[b.key]!.per - (F[a.key]!.c * a.qty) / F[a.key]!.per)[0]
  if (!main) return null
  const f = F[main.key]!, q2 = Math.max(MIN_QTY[main.key] ?? 20, Math.round((main.qty - (r.c - goal) / (f.c / f.per)) / 10) * 10)
  return q2 < main.qty ? `vzemi ~${q2} ${f.unit} ${CARB_GEN[main.key]} namesto ${main.qty} ${f.unit}` : null
}
/** (v3.51) opozorilo o OH šele nad 25 % in vsaj 15 g čez cilj obroka (prej že pri +15 %, tudi pri +5 g) */
const carbsOver = (c: number, goal: number | undefined) => !!goal && c > Math.max(goal * 1.25, goal + 15)

/** Zakaj ta obrok zate: beljakovine, OH glede na vadbo, primanjkljaj, mišice — iz številk obroka. */
export function whyRecipe(r: Pick<Recipe, 'p' | 'c' | 'f'> & Partial<Pick<Recipe, 'ingredients'>>, slot: Pick<MealSlotPlan, 'key' | 'proteinG'> & Partial<Pick<MealSlotPlan, 'lf' | 'carbsG' | 'tpl' | 'label'>>, ctx: RecipeCtx): string {
  const bits: string[] = []
  // (v3.51) pred vadbo ali startom (in pred tekmo) ne opominjaj za beljakovine — mlečno in težko tik pred startom ni prav
  const pre = slot.key === 'pred'
  const short = !pre && !slot.lf && r.p < slot.proteinG * 0.85
  const tpl = slot.tpl || slot.key
  const over = !ctx.training && !slot.lf && slot.key !== 'obnova' && !pre && carbsOver(r.c, slot.carbsG)
  const add = short ? proteinAdd(exclusionsOf(ctx.prefs), !!slot.lf, (r.ingredients || []).map(i => i.key), tpl === 'zajtrk' || tpl === 'malica' || tpl === 'pred', over || (!!slot.carbsG && r.c > slot.carbsG * 1.15)) : null
  if (!pre) bits.push(`${r.p} g beljakovin${short ? ` (obrok jih ima ~${slot.proteinG}${add ? ` — dodaj ${add}` : ''})` : ctx.keepMuscle && ctx.deficit ? ' — da med hujšanjem mišice ostanejo' : ' za mišice in sitost'}`)
  if (pre) bits.push(`${r.c} g lahkih ogljikovih hidratov za energijo na ${/start/iu.test(slot.label || '') ? 'startu' : 'vadbi'}`)
  else if (slot.key === 'obnova') bits.push(`${r.c} g ogljikovih hidratov za obnovo po vadbi`)
  // (v3.50) pred tekmo je to polnjenje, ne »zato manj«; več OH od cilja obroka pove, kaj narediti (prej »136 g — zato manj«)
  else if (slot.lf) bits.push(`${r.c} g ogljikovih hidratov — polnjenje pred tekmo`)
  // (v3.51) imenuj sestavino in koliko (prej »pojej manj priloge« tudi pri polenti z jogurtom)
  else if (over) { const less = lessCarb(r, slot.carbsG!); bits.push(`${r.c} g ogljikovih hidratov (cilj obroka ${slot.carbsG} g) — ${less ?? 'izberi drug predlog'}`) }
  else if (ctx.training) bits.push(`${r.c} g ogljikovih hidratov — dan vadbe`)
  else bits.push(`${r.c} g ogljikovih hidratov — dan brez vadbe, zato manj`)
  if (ctx.deficit && r.f <= 18 && (slot.key === 'kosilo' || slot.key === 'vecerja')) bits.push('malo maščob — primanjkljaj je pri obrokih, ne na vadbi')
  return bits.join(' · ') + '.'
}

/** obrok, premajhen za recept (ostanek po pojedenem) */
export const MIN_RECIPE_KCAL = 150
/** Jedi za obrok po željah: izločene sestavine (alergije, vegetarijansko) veljajo vedno; če besede »ne maram X« izločijo vse, besede popustijo. */
export function dishesFor(tpl: string, prefs?: string | null, lib: readonly Dish[] = DISHES): Dish[] {
  const all = lib.filter(d => d.tpl === tpl || !!d.also?.includes(tpl))
  const ex = exclusionsOf(prefs)
  const ok0 = all.filter(d => dishOk(d, ex))
  // (v3.49) vsejedec: jedi s sojo (tofu) samo, če ni druge
  const noSoy = soyOk(ex, prefs) ? ok0 : ok0.filter(d => !d.contains.includes('soja'))
  const ok = noSoy.some(d => !d.fallback) ? noSoy : ok0
  // jed »za silo« (malo beljakovin) samo, če po željah ni nobene druge
  const main = ok.filter(d => !d.fallback)
  if (main.length) return main
  if (ok.length) return ok
  // (v3.50) besede popustijo: samo jedi z najmanj živili, ki jih ne maraš in jih ni s čim zamenjati (banano zamenja
  // jabolko — fitDish); prej vse jedi obroka, tudi »Banana in jabolko« za »ne maram banan«
  // (v3.50) besede iz alergije ne popustijo nikoli; jed z zelenjavo, ki je ne maraš (v korakih), šteje kot manjko
  const rest = all.filter(d => dishOk(d, { contains: ex.contains, words: ex.hard ?? [] }))
  const miss = (d: Dish) => d.items.filter(([k]) => wordsHit(nameOf(k), ex.words) && !SWAP[k]?.some(x => !wordsHit(nameOf(x), ex.words))).length
    + (dishHit({ ...d, items: [] }, ex.words) ? 1 : 0)
  const lo = Math.min(...rest.map(miss))
  return rest.filter(d => miss(d) === lo)
}
/**
 * Jedi obroka po ustreznosti: kalorije blizu obroku in beljakovine dosežene (manjko šteje dvojno). Vrne boljšo polovico
 * (vsaj 2, da se dnevi in »drug predlog« še razlikujejo) — malica s 40 g beljakovin tako dobi skuto, ne banane.
 */
export function bestFits(list: readonly Dish[], sl: Pick<MealSlotPlan, 'kcal' | 'proteinG'> & Partial<Pick<MealSlotPlan, 'carbsG' | 'beforeRide' | 'lf'>>, ctx: FitCtx): { d: Dish; fit: Omit<Recipe, 'why' | 'by'> }[] {
  return scoreFits(list, sl, ctx).pick
}
type Fit = { d: Dish; fit: Omit<Recipe, 'why' | 'by'> }
/** ustrezne jedi (pick) in še druge, ki obrok skoraj dosežejo (wide: beljakovine ≥ 70 %, kalorije ±25 %) — za raznolikost (v3.49) */
function scoreFits(list: readonly Dish[], sl: Pick<MealSlotPlan, 'kcal' | 'proteinG'> & Partial<Pick<MealSlotPlan, 'carbsG' | 'beforeRide' | 'lf'>>, ctx: FitCtx): { pick: Fit[]; wide: Fit[] } {
  // prigrizek (shake) ni večerja: za glavni obrok (> 600 kcal) samo, če ni ničesar drugega
  const meal = sl.kcal > 600 && list.some(d => !d.snack) ? list.filter(d => !d.snack) : list
  const fctx: FitCtx = { ...ctx, ...(sl.lf ? { lf: true } : {}), ...(sl.beforeRide ? { beforeRide: true } : {}) }
  const scored = meal.map(d => {
    const fit = fitDish(d, sl.kcal, sl.proteinG, fctx, sl.carbsG)
    // prava jed za obrok: kalorije, beljakovine, ogljikovi hidrati dneva (dan vadbe več, brez vadbe manj); pred vožnjo
    // brez stročnic in težke (mastne, vlaknate) hrane; dodatek k jedi je v redu, a jed, ki obrok doseže sama, je boljša
    // (v3.50) dan brez vadbe: presežek OH šteje več (prej 10–18 % čez OH obroka pri kosilu z »manj riža, testenin«)
    const carbs = !sl.carbsG ? 0 : ctx.training === false ? (1.0 * Math.max(0, fit.c - sl.carbsG) + 0.3 * Math.max(0, sl.carbsG - fit.c)) / Math.max(30, sl.carbsG) : (0.6 * Math.abs(fit.c - sl.carbsG)) / Math.max(30, sl.carbsG)
    // (v3.48) zelenjava, solata in sadje po pomerjenih količinah, ne po predlogi
    const fresh = fit.ingredients.filter(i => i.key === 'zelenjava' || i.key === 'solata' || i.key === 'sadje').reduce((s, i) => s + i.qty, 0)
    // (v3.50) pred vožnjo tudi veliko skute ali sira (kazein, počasna prebava) in maščob nad 30 % obroka
    const cheese = fit.ingredients.filter(i => i.key === 'skuta' || i.key === 'sir').reduce((s, i) => s + i.qty, 0)
    const heavy = sl.beforeRide && (d.items.some(([k]) => LEGUMES.has(k as string) || k === 'losos') || fit.f > Math.max(15, (sl.kcal * 0.3) / 9) || fresh >= 250 || cheese >= 200) ? 1
      // (v3.50) po dolgi vožnji ali tekmi: brez veliko stročnic in maščob
      : fctx.recovery && (fit.ingredients.some(i => LEGUMES.has(i.key) && i.qty >= 200) || fit.f > 25) ? 1 : 0
    const sides = fit.ingredients.filter(i => i.side).length * 0.08
    // (v3.50) krožnik nad ~700 g (krompir 450 g + solata 300 g) je manj realen
    const plate = Math.max(0, plateG(fit) - 700) / 100 * 0.1
    const score = Math.abs(fit.kcal - sl.kcal) / Math.max(1, sl.kcal) + (2 * Math.max(0, sl.proteinG * 0.9 - fit.p)) / Math.max(1, sl.proteinG) + carbs + heavy + sides + plate
    return { d, fit, score, heavy }
  }).sort((a, b) => a.score - b.score)
  // pred vožnjo (in po dolgi vožnji) težke jedi (stročnice, losos, mastno) sploh ne, če je kaj drugega — ne le slabša ocena
  if ((sl.beforeRide || fctx.recovery) && scored.some(x => !x.heavy)) scored.splice(0, scored.length, ...scored.filter(x => !x.heavy))
  // jedi, ki obrok res dosežejo (beljakovine ≥ 85 %, kalorije ±20 %); če jih ni dovolj, boljša polovica
  const good = scored.filter(x => x.fit.p >= sl.proteinG * 0.85 && Math.abs(x.fit.kcal - sl.kcal) <= sl.kcal * 0.2)
  const pick = good.length >= 2 ? good : scored.slice(0, Math.max(2, Math.ceil(scored.length / 2)))
  const wide = scored.filter(x => !pick.includes(x) && x.fit.p >= sl.proteinG * 0.7 && Math.abs(x.fit.kcal - sl.kcal) <= sl.kcal * 0.25)
  return { pick: pick.map(({ d, fit }) => ({ d, fit })), wide: wide.map(({ d, fit }) => ({ d, fit })) }
}
/** Ustrezne jedi za obrok: pred tekmo (lf) iz jedi z malo vlakninami, sicer iz knjižnice — oboje po željah. */
function fitsAll(sl: Pick<MealSlotPlan, 'kcal' | 'proteinG' | 'tpl' | 'key'> & Partial<Pick<MealSlotPlan, 'carbsG' | 'beforeRide' | 'lf'>>, ctx: RecipeCtx & Pick<FitCtx, 'bananas' | 'recovery'>) {
  return scoreFits(libOf(sl, ctx.prefs), sl, ctx)
}
/** (v3.50) glavni obrok pod 300 kcal: majhen obrok z beljakovinami (jogurt s sadjem, jajca s kruhom), ne skrčena jed */
export const SMALL_MAIN_KCAL = 300
const MAIN_TPL = new Set(['kosilo', 'obnova', 'vecerja', 'stroc'])
/** jedi za obrok (po željah): pred tekmo iz jedi z malo vlakninami, majhen glavni obrok iz majhnih */
function libOf(sl: Pick<MealSlotPlan, 'kcal' | 'tpl' | 'key'> & Partial<Pick<MealSlotPlan, 'lf'>>, prefs?: string | null): Dish[] {
  const tpl = sl.tpl || sl.key
  const small = sl.kcal < SMALL_MAIN_KCAL && MAIN_TPL.has(tpl)
  return sl.lf ? dishesFor(small ? 'malica' : lfTplOf(tpl), prefs, LF_DISHES) : dishesFor(small ? 'majhen' : tpl, prefs)
}
const fitsFor = (sl: Parameters<typeof fitsAll>[0], ctx: RecipeCtx) => fitsAll(sl, ctx).pick
/** Koliko jedi pride v poštev za obrok (za gumb »drug predlog«; v3.48 tudi pred tekmo). */
export function dishChoices(sl: Pick<MealSlotPlan, 'kcal' | 'proteinG' | 'tpl' | 'key' | 'lf'> & Partial<Pick<MealSlotPlan, 'carbsG' | 'beforeRide'>>, ctx: RecipeCtx): number {
  return fitsFor(sl, ctx).length
}
/** (v3.49) največ banan na dan v obrokih skupaj z gorivom na kolesu (prej 4–7 na dan v obrokih pri dolgih vožnjah) */
export const DAY_BANANAS = 3
const bananasOf = (r: Pick<Recipe, 'ingredients'>) => r.ingredients.filter(z => z.key === 'banana').reduce((a, z) => a + z.qty, 0)
/** zaporedni dan po UTC, tudi čez novo leto — za kroženje jedi iz dneva v dan (premik ure, DST, ne da dveh dni z istim številom) */
const dayIndex = (iso: string) => { const t = /^\d{4}-\d{2}-\d{2}$/.test(iso) ? Math.round(Date.parse(`${iso}T12:00:00Z`) / 86400_000) : 0; return Number.isFinite(t) ? t : 0 }
/** kandidat za obrok: jed, njeni osnovi, banane in lastna kazen (le skoraj ustrezna jed, mesto v vrsti) */
type Cand = Fit & { b: { carb: string | null; prot: string | null }; ban: number; own: number; /** (v3.50) beljakovinski dodatek »zraven« (tofu, čičerika) — tudi ta ne dvakrat na dan */ xs: string[] }
/** (v3.50) dodatki, ki štejejo kot beljakovina dneva */
const SIDE_PROT = new Set(['tofu', 'cicerika'])
type SlotC = { sl: MealSlotPlan; c: Cand[] }
const MAX_CANDS = 8
/** (v3.49) Kandidati za obroke dneva: ustrezne jedi, nato jedi, ki obrok le skoraj dosežejo (kazen 2, pod 80 % beljakovin 3). */
function candsOf(slots: readonly MealSlotPlan[], fits: readonly ({ pick: Fit[]; wide: Fit[] } | null)[]): SlotC[] {
  const out: SlotC[] = []
  slots.forEach((sl, i) => {
    const f = fits[i]
    if (!f || !f.pick.length) return
    const near = (x: Fit) => (x.fit.p >= sl.proteinG * 0.8 ? 2 : 3)
    out.push({ sl, c: [...f.pick, ...f.wide].slice(0, MAX_CANDS).map((x, k) => ({ ...x, b: basesOf(x.d), xs: x.fit.ingredients.filter(i => i.side && SIDE_PROT.has(i.key)).map(i => i.key), ban: bananasOf(x.fit), own: (k >= f.pick.length ? near(x) : 0) + k * 0.01 })) })
  })
  return out
}
/**
 * kazen izbire dneva: lastne kazni, ista osnova drugič v dnevu (riž 4, beljakovina — tofu, piščanec — 7, stročnice 2:
 * humus in čičerika sta za vegana skoraj edina beljakovina), vsaka banana čez mejo dneva 8
 */
const DUP = (c: Cand, k: string) => (k === c.b.carb ? 4 : LEGUMES.has(k) ? 2 : 7)
function dayCost(sel: readonly Cand[], budget: number): number {
  const seen = new Set<string>()
  let cost = 0, ban = 0
  for (const c of sel) {
    cost += c.own; ban += c.ban
    for (const k of [c.b.carb, c.b.prot, ...c.xs]) if (k) { if (seen.has(k)) cost += DUP(c, k); seen.add(k) }
  }
  return cost + Math.max(0, ban - budget) * 8
}
/**
 * (v3.49) Jedi dneva izbrane skupaj (prej po vrsti: zajtrk je vzel tofu, vegansko kosilo pred vožnjo pa ga je moralo še
 * enkrat): najmanjša skupna kazen med vsemi kombinacijami (največ 8 jedi na obrok).
 */
function bestDay(cs: readonly SlotC[], budget: number, rot?: { limit: number; extra: (j: number, c: Cand) => number }): Cand[] {
  let best = Infinity, bestSel: Cand[] = []
  const sel: Cand[] = []
  // (v3.50) z rot: najmanjša kazen kroženja med dnevi, ki so od najboljšega dneva največ NEAR slabši
  const go = (j: number, cost: number, ext: number, seen: ReadonlySet<string>, ban: number) => {
    const total = cost + Math.max(0, ban - budget) * 8
    if (rot && total > rot.limit) return
    if (total + ext >= best) return
    if (j === cs.length) { best = total + ext; bestSel = [...sel]; return }
    for (const c of cs[j]!.c) {
      const ks = [c.b.carb, c.b.prot, ...c.xs].filter((k): k is string => !!k)
      const s2 = new Set(seen); let add = c.own
      for (const k of ks) { if (s2.has(k)) add += DUP(c, k); s2.add(k) }
      sel.push(c); go(j + 1, cost + add, ext + (rot ? rot.extra(j, c) : 0), s2, ban + c.ban); sel.pop()
    }
  }
  go(0, 0, 0, new Set(), 0)
  return bestSel
}
/** kako blizu najboljšemu dnevu mora biti jed, da kroži (ista osnova drugič v dnevu ali banana čez mejo nikoli); (v3.51) 4, prej 3 */
const NEAR = 4
/**
 * (v3.50) Kako daleč je jed od svojega dneva v krogu obroka (0 = na vrsti, do ~1 = tik ob njem): krog je STALEN vrstni
 * red jedi obroka (knjižnica po željah, neodvisno od dneva), vsak dan je na vrsti naslednja. Če ta danes ne gre, je
 * najboljša tista pol kroga stran — ni bila na vrsti včeraj in ne bo jutri.
 */
function turnRank(ids: readonly string[], id: string, day: number): number {
  const n = ids.length
  if (n < 2) return 0
  const i = ids.indexOf(id)
  if (i < 0) return 1
  const r0 = ((day % n) + n) % n
  if (i === r0) return 0
  const mid = (r0 + Math.floor(n / 2)) % n
  const fwd = (i - mid + n) % n, back = (mid - i + n) % n
  return (1 + Math.min(fwd, back) * 2 + (fwd <= back ? 0 : 1)) / (n + 2)
}
/** kazen kroženja: jed daleč od svojega dneva v krogu, ista jed kot včeraj (v istem obroku); koliko dni nazaj; (v3.51) vsaka
 * ponovitev v teh dneh in močno tretja (prej sendvič 10 od 14 malic, polenta 8 od 14 zajtrkov brez glutena) */
const ROT = 4, REP = 4, HIST = 6, REP2 = 1, REP3 = 6
// (v3.49) isti izračun se med izrisom ponovi (obroč šteje, Danes in Prehrana) — zadnjih nekaj dni v predpomnilniku
const CACHE = new Map<string, Record<string, Recipe>>()
/**
 * Recepti dneva po pravilih: vsak obrok dobi jed iz knjižnice (med ustreznimi vsak dan drugo, »drug predlog« naslednjo),
 * pomerjeno na kalorije in beljakovine obroka. Pred tekmo (malo vlaknin) obrok dobi jed z malo vlakninami (LF_DISHES) —
 * s pravim imenom in po željah; opozorilo o vlakninah je enkrat nad obroki.
 * (v3.49) Jedi dneva se izberejo skupaj (ista beljakovina ali osnova ne dvakrat na dan, meja banan), nato v vsakem obroku
 * krožijo enakovredne jedi iz dneva v dan (prej 10 od 14 kosil »Testenine s tofujem«). »Drug predlog« zamenja samo ta
 * obrok (naslednja najboljša jed), ostali obroki dneva ostanejo.
 */
export function dayRecipes(dp: Pick<DayNutrition, 'slots'> & Partial<Pick<DayNutrition, 'onBike' | 'race'>>, date: string, ctx0: RecipeCtx): Record<string, Recipe> {
  // (v3.51) želje za ta dan (»ne jem mesa ob petkih« samo ob petkih)
  const ctx: RecipeCtx = ctx0.prefs ? { ...ctx0, prefs: prefsOn(ctx0.prefs, date) } : ctx0
  // (v3.50) obnova po tekmi ali dolgi vožnji (na kolesu ≥ 120 g OH ≈ 2,5 h): lahka — prej 300 g čičerike in 41 g maščob
  const longDay = dp.race?.inDays === 0 || (dp.onBike?.carbs || 0) >= 120
  const key = JSON.stringify([date, dp.slots.map(s => [s.key, s.kcal, s.proteinG, s.carbsG, s.tpl, s.lf, s.beforeRide]), dp.onBike?.bananas || 0, longDay, ctx.deficit, ctx.keepMuscle, ctx.training, ctx.prefs || '', ctx.alt || {}])
  const hit = CACHE.get(key)
  if (hit) return hit
  const budget = Math.max(0, DAY_BANANAS - (dp.onBike?.bananas || 0))
  const fitsWith = (bananas: number) => dp.slots.map(sl => (sl.kcal < MIN_RECIPE_KCAL ? null : fitsAll(sl, { ...ctx, alt: undefined, bananas, ...(longDay && sl.key === 'obnova' ? { recovery: true } : {}) })))
  let cs = candsOf(dp.slots, fitsWith(budget))
  let sel = bestDay(cs, budget)
  // preveč banan čez dan (obroki + kolo): znova, banane samo, kjer so del jedi
  const bans = (s: readonly Cand[]) => s.reduce((a, c) => a + c.ban, 0)
  if (bans(sel) > budget) {
    const cs0 = candsOf(dp.slots, fitsWith(0)), s0 = bestDay(cs0, budget)
    if (bans(s0) < bans(sel)) { cs = cs0; sel = s0 }
  }
  // (v3.50) kroženje iz dneva v dan: dan, ki je od najboljšega največ NEAR slabši in ima najmanjšo kazen kroženja — jed na
  // vrsti v stalnem krogu obroka, ne ista kot včeraj (z istimi obroki). Prej obrok za obrokom
  // ok[(dan + j) % ok.length]: ustreznih jedi je bilo vsak dan drugače veliko, indeks je padal na isto jed (polenta 6 od
  // 13 zajtrkov, vegan ričet 5 od 7 kosil).
  const limit = dayCost(sel, budget) + NEAR, day = dayIndex(date)
  const ids = cs.map(s => libOf(s.sl, ctx.prefs).map(d => d.id))
  // (v3.51) tudi jed, ki je bila v zadnjih dneh že dvakrat (prej sendvič 10 od 14 malic pri »alergija na oreške«)
  const extraOf = (d: number, hist: readonly Cand[][]) => (j: number, c: Cand) => { const n = hist.filter(h => h[j]?.d.id === c.d.id).length; return ROT * turnRank(ids[j]!, c.d.id, d) + (hist[hist.length - 1]?.[j]?.d.id === c.d.id ? REP : 0) + Math.max(0, n - 1) * REP2 + (n >= 3 ? REP3 : 0) }
  const turn = (d: number, hist: readonly Cand[][]) => bestDay(cs, budget, { limit, extra: extraOf(d, hist) })
  // včeraj po istem pravilu z istimi obroki (od 6 dni nazaj naprej — z vsakim dnem bližje temu, kar je res bilo)
  const hist: Cand[][] = []
  for (let d = day - HIST; d < day; d++) hist.push(turn(d, hist))
  const rotSel = turn(day, hist)
  if (rotSel.length === sel.length) sel = rotSel
  // (v3.51) dan brez vadbe: OH vseh receptov skupaj največ 12 % čez cilj (prej ženska 58 kg na dan počitka 183 g pri cilju
  // 147 g) — jed ostane (kroženje), manj je priloge: najprej OH dodatek (kruh, sadje), nato riž, testenine, krompir …
  const goal = cs.reduce((a, s) => a + (s.sl.carbsG || 0), 0)
  if (!ctx.training && goal > 0) {
    let over = sel.reduce((a, c) => a + c.fit.c, 0) - goal * 1.1
    if (over > goal * 0.02) {
      const lf = !!exclusionsOf(ctx.prefs).lactoseFree
      const order = sel.map((c, k) => ({ k, o: c.fit.c - (cs[k]!.sl.carbsG || 0) })).sort((x, y) => y.o - x.o)
      for (const { k } of order) {
        if (over <= 0) break
        const t = trimCarbs(sel[k]!.fit, over, lf)
        over -= sel[k]!.fit.c - t.c
        sel = sel.map((o, m) => (m === k ? { ...o, fit: t } : o))
      }
    }
  }
  // »drug predlog«: v tem obroku po vrsti naslednja najboljša jed (glede na ostale obroke dneva)
  cs.forEach((s, j) => {
    const a = ctx.alt?.[s.sl.key] || 0
    if (!a || !sel[j]) return
    const base = sel[j]!
    const rest = s.c.filter(c => c !== base).map(c => ({ c, cost: dayCost(sel.map((o, m) => (m === j ? c : o)), budget) })).sort((p, q) => p.cost - q.cost).map(x => x.c)
    sel[j] = [base, ...rest][a % (rest.length + 1)]!
  })
  const out: Record<string, Recipe> = {}
  cs.forEach((s, j) => {
    const c = sel[j]; if (!c) return
    out[s.sl.key] = { ...c.fit, why: s.sl.lf ? `${whyRecipe(c.fit, s.sl, ctx)} Malo vlaknin — želodec na tekmi ostane miren.` : whyRecipe(c.fit, s.sl, ctx), by: 'pravila' }
  })
  if (CACHE.size > 40) CACHE.delete(CACHE.keys().next().value!)
  CACHE.set(key, out)
  return out
}

/** glavni vir ogljikovih hidratov in beljakovin jedi (za raznolikost čez dan) */
const CARB_BASE = new Set(['riz', 'testenine', 'krompir', 'kruh', 'oves', 'kuskus', 'tortilja', 'ajda', 'polenta', 'kvinoja', 'jesprenj'])
const PROT_BASE = new Set(['piscanec', 'puran', 'tuna', 'losos', 'tofu', 'jajce', 'skuta', 'jogurt', 'fizol', 'cicerika', 'leca', 'govedina', 'sir', 'mleto', 'oslic', 'sunka', 'sojjogurt', 'sojmleko', 'sojkos', 'edamame'])
/** bel riž je riž, bel kruh je kruh … (dan tekme: riž pred tekmo in po njej je še vedno riž dvakrat) */
const BASE_OF: Record<string, string> = { rizb: 'riz', testenineb: 'testenine', krompirb: 'krompir', belkruh: 'kruh' }
export function basesOf(d: Pick<Dish, 'items'>): { carb: string | null; prot: string | null } {
  const top = (set: Set<string>) => d.items.map(([k, q]) => [BASE_OF[k] ?? k, q] as const).filter(([k]) => set.has(k)).sort((a, b) => b[1] - a[1])[0]?.[0] ?? null
  return { carb: top(CARB_BASE), prot: top(PROT_BASE) }
}

/**
 * (v3.49) RECEPT ZA VEČ OSEB: sestavine za n oseb (kuhaš za družino ali za dva dni). Jed iz knjižnice se preračuna po
 * gramih (z domačo mero), AI recept po številkah v besedilu (odstotki, npr. »mleko 1,5 %«, ostanejo). Kalorije in
 * makrohranila recepta ostanejo za tvojo porcijo.
 */
export function scaleIngredients(r: Pick<Recipe, 'ingredients'>, n: number, prefs?: string | null): string[] {
  if (!(n > 1)) return r.ingredients.map(i => i.text)
  const lf = !!exclusionsOf(prefs).lactoseFree
  return r.ingredients.map(i => {
    if (F[i.key] && i.qty > 0) {
      if (i.side) return sideText(i.key, i.qty * n, lf, i.text.startsWith('za sladico'))
      const t = ingText(i.key, i.qty * n, lf)
      // (v3.51) »ne maram česna«: v receptu je samo čebula
      return i.key === 'cebula' && !i.text.includes('česen') ? t.replace(F.cebula!.name, 'čebula') : t
    }
    return scaleText(i.text, n)
  })
}
/**
 * (v3.51) Koraki za n oseb: voda in tekočina (dl, l, ml) in grami v korakih (prej »320 g zdroba v 3 dl vode« za 4 osebe);
 * minute, stopinje in razmerja ostanejo.
 */
export function scaleSteps(steps: readonly string[], n: number): string[] {
  if (!(n > 1)) return [...steps]
  return steps.map(st => st.replace(/(\d+(?:[.,]\d+)?)(\s*)(dl|ml|l|g|kg)(?!\p{L})/gu, (_m, num: string, sp: string, unit: string) => unitTxt(parseFloat(num.replace(',', '.')) * n, unit, sp)))
}
/** (v3.51) količina z enoto: g in ml na 5 (od 1000 kg in l), l, dl in kg na 0,1 — brez ulomkov (prej »37½ g«, »1½ l«) */
function unitTxt(x: number, unit: string, sp = ' '): string {
  const dec = (v: number) => String(Math.round(v * 10) / 10).replace('.', ',')
  if ((unit === 'g' || unit === 'ml') && x >= 1000) return `${dec(x / 1000)}${sp || ' '}${unit === 'g' ? 'kg' : 'l'}`
  if (unit === 'g' || unit === 'ml') return `${x >= 10 ? Math.round(x / 5) * 5 : Math.round(x)}${sp}${unit}`
  return `${dec(x)}${sp}${unit}`
}
/** (v3.50) oblike samostalnika za število: 1, 2, 3–4, 5+, in za ulomek (»1½ čebule«); (v3.51) s spolom za pridevnik */
const NOUNS: readonly (readonly [string, string, string, string, string])[] = [
  ['jajce', 'jajci', 'jajca', 'jajc', 'jajca'], ['rezina', 'rezini', 'rezine', 'rezin', 'rezine'], ['žlica', 'žlici', 'žlice', 'žlic', 'žlice'],
  ['žlička', 'žlički', 'žličke', 'žličk', 'žličke'], ['kos', 'kosa', 'kosi', 'kosov', 'kosa'], ['lonček', 'lončka', 'lončki', 'lončkov', 'lončka'],
  ['kozarec', 'kozarca', 'kozarci', 'kozarcev', 'kozarca'], ['skodelica', 'skodelici', 'skodelice', 'skodelic', 'skodelice'],
  ['strok', 'stroka', 'stroki', 'strokov', 'stroka'], ['glavica', 'glavici', 'glavice', 'glavic', 'glavice'], ['pest', 'pesti', 'pesti', 'pesti', 'pesti'],
  ['čebula', 'čebuli', 'čebule', 'čebul', 'čebule'], ['banana', 'banani', 'banane', 'banan', 'banane'], ['jabolko', 'jabolki', 'jabolka', 'jabolk', 'jabolka'],
  ['paradižnik', 'paradižnika', 'paradižniki', 'paradižnikov', 'paradižnika'], ['paprika', 'papriki', 'paprike', 'paprik', 'paprike'],
  ['limona', 'limoni', 'limone', 'limon', 'limone'], ['krompir', 'krompirja', 'krompirji', 'krompirjev', 'krompirja'], ['pločevinka', 'pločevinki', 'pločevinke', 'pločevink', 'pločevinke'],
  // (v3.51) pogosti v AI receptih (prej »3 bučka«, »2 tortilja«, »3 ščep soli«)
  ['bučka', 'bučki', 'bučke', 'bučk', 'bučke'], ['tortilja', 'tortilji', 'tortilje', 'tortilj', 'tortilje'], ['korenček', 'korenčka', 'korenčki', 'korenčkov', 'korenčka'],
  ['kocka', 'kocki', 'kocke', 'kock', 'kocke'], ['vejica', 'vejici', 'vejice', 'vejic', 'vejice'], ['ščep', 'ščepa', 'ščepi', 'ščepov', 'ščepa'],
  ['kumara', 'kumari', 'kumare', 'kumar', 'kumare'], ['žemlja', 'žemlji', 'žemlje', 'žemelj', 'žemlje'], ['list', 'lista', 'listi', 'listov', 'lista'],
  ['avokado', 'avokada', 'avokadi', 'avokadov', 'avokada'],
]
const NOUN_M = new Set(['kos', 'lonček', 'kozarec', 'strok', 'paradižnik', 'krompir', 'korenček', 'ščep', 'list', 'avokado']), NOUN_N = new Set(['jajce', 'jabolko'])
/** (v3.51) pridevnik pred samostalnikom (»1 srednja čebula« ×3 = »3 srednje čebule«, ne »3 srednja čebula«) */
const ADJ = ['srednj', 'velik', 'manjš', 'majhn', 'večj', 'debel', 'drobn', 'zrel', 'cel']
function adjForm(word: string, noun: readonly string[], idx: number): string | null {
  const w = word.toLowerCase().replace(/^majhen$/u, 'majhn'), st = ADJ.find(a => w.startsWith(a) && /^(?:i|a|e|o|ih|ega|em|ima)?$/u.test(w.slice(a.length)))
  if (!st) return null
  const g = NOUN_M.has(noun[0]!) ? 'm' : NOUN_N.has(noun[0]!) ? 'n' : 'f', soft = /[jčšžc]$/u.test(st)
  const end = g === 'm' ? ['i', 'a', 'i', 'ih', 'ega'] : g === 'n' ? [soft ? 'e' : 'o', 'i', 'a', 'ih', 'ega'] : ['a', 'i', 'e', 'ih', 'e']
  const f = st + end[idx]
  return word[0] !== word[0]!.toLowerCase() ? f[0]!.toUpperCase() + f.slice(1) : f
}
const FRAC: Record<string, number> = { '½': 0.5, '¼': 0.25, '¾': 0.75, '⅓': 1 / 3, '⅔': 2 / 3 }
const fracTxt = (v: number) => { const w = Math.floor(v + 1e-9), r = v - w; const f = Math.abs(r - 0.5) < 0.01 ? '½' : Math.abs(r - 0.25) < 0.01 ? '¼' : Math.abs(r - 0.75) < 0.01 ? '¾' : null; return f ? `${w || ''}${f}` : r < 0.01 ? String(w) : String(Math.round(v * 10) / 10).replace('.', ',') }
const UNITS = new Set(['g', 'ml', 'l', 'dl', 'kg', 'dag', 'cl'])
/**
 * (v3.50) Besedilo AI sestavine za n oseb: ulomki (»1/2«, »½«, »1 1/2«) kot število, nato število in samostalnik skupaj —
 * »1/2 čebule« ×3 = »1½ čebule« (prej »3/6 čebule«), »2 jajci« ×3 = »6 jajc«, »1 žlica« ×3 = »3 žlice«; odstotki ostanejo.
 * (v3.51) »pol« in »četrt« sta število, pridevnik pred samostalnikom se uskladi, enote brez ulomkov (»40 g«, »1,5 l«).
 */
export function scaleText(text: string, n: number): string {
  const rx = /(\d+\s+\d+\/\d+|\d+\/\d+|\d*[½¼¾⅓⅔]|\d+(?:[.,]\d+)?|(?<!\p{L})(?:pol|četrt|cetrt)(?!\p{L}))(\s*%)?(\s*)(\p{L}+)?(?:(\s+)(\p{L}+))?/giu
  return text.replace(rx, (m, num: string, pct: string | undefined, sp: string, word: string | undefined, sp2: string | undefined, word2: string | undefined) => {
    if (pct) return m
    let v: number
    const mixed = /^(\d+)\s+(\d+)\/(\d+)$/.exec(num), frac = /^(\d+)\/(\d+)$/.exec(num), uni = /^(\d*)([½¼¾⅓⅔])$/u.exec(num)
    if (/^pol$/iu.test(num)) v = 0.5
    else if (/^(?:četrt|cetrt)$/iu.test(num)) v = 0.25
    else if (mixed) v = +mixed[1]! + +mixed[2]! / +mixed[3]!
    else if (frac) v = +frac[1]! / +frac[2]!
    else if (uni) v = (uni[1] ? +uni[1] : 0) + FRAC[uni[2]!]!
    else v = parseFloat(num.replace(',', '.'))
    if (!Number.isFinite(v)) return m
    const x = v * n
    const rest = word2 != null ? `${sp2}${word2}` : ''
    if (word && UNITS.has(word.toLowerCase())) return `${unitTxt(x, word.toLowerCase(), sp)}${rest}`
    const whole = Math.abs(x - Math.round(x)) < 0.01
    const idx = !whole ? 4 : Math.round(x) === 1 ? 0 : Math.round(x) === 2 ? 1 : Math.round(x) <= 4 ? 2 : 3
    const nounOf = (w?: string) => (w ? NOUNS.find(f => f.includes(w.toLowerCase())) : undefined)
    const cap = (w: string, form: string) => (w[0] !== w[0]!.toLowerCase() ? form[0]!.toUpperCase() + form.slice(1) : form)
    // pridevnik in samostalnik (»2 veliki jajci« ×3 = »6 velikih jajc«)
    const n2 = nounOf(word2), adj = word && n2 ? adjForm(word, n2, idx) : null
    if (adj && n2) return `${fracTxt(x)}${sp}${adj}${sp2}${cap(word2!, n2[idx]!)}`
    const noun = nounOf(word)
    if (!noun) return `${fracTxt(x)}${sp}${word ?? ''}${rest}`
    return `${fracTxt(x)}${sp}${cap(word!, noun[idx]!)}${rest}`
  })
}

/** (v3.49) nakup: pakiranje sestavine (velikost v g, ml ali kosih in ime) */
const PACK: Record<string, [number, string, string, string, string]> = {
  // (v3.50) grški jogurt v nakupu: velik lonček 500 g (v receptu »lonček po 150 g«)
  skuta: [250, 'lonček', 'lončka', 'lončki', 'lončkov'], jogurt: [500, 'velik lonček', 'velika lončka', 'veliki lončki', 'velikih lončkov'], kefir: [500, 'lonček', 'lončka', 'lončki', 'lončkov'],
  sojjogurt: [400, 'lonček', 'lončka', 'lončki', 'lončkov'], mleko: [1000, 'liter', 'litra', 'litri', 'litrov'], sojmleko: [1000, 'liter', 'litra', 'litri', 'litrov'],
  testenine: [500, 'paket', 'paketa', 'paketi', 'paketov'], testenineb: [500, 'paket', 'paketa', 'paketi', 'paketov'], riz: [1000, 'paket', 'paketa', 'paketi', 'paketov'],
  rizb: [1000, 'paket', 'paketa', 'paketi', 'paketov'], oves: [500, 'paket', 'paketa', 'paketi', 'paketov'], kuskus: [500, 'paket', 'paketa', 'paketi', 'paketov'],
  ajda: [500, 'paket', 'paketa', 'paketi', 'paketov'], polenta: [500, 'paket', 'paketa', 'paketi', 'paketov'], jesprenj: [500, 'paket', 'paketa', 'paketi', 'paketov'],
  moka: [1000, 'paket', 'paketa', 'paketi', 'paketov'], tuna: [110, 'pločevinka', 'pločevinki', 'pločevinke', 'pločevink'], fizol: [240, 'pločevinka', 'pločevinki', 'pločevinke', 'pločevink'], cicerika: [240, 'pločevinka', 'pločevinki', 'pločevinke', 'pločevink'],
  leca: [240, 'pločevinka', 'pločevinki', 'pločevinke', 'pločevink'], tofu: [200, 'paket', 'paketa', 'paketi', 'paketov'], sunka: [100, 'zavitek', 'zavitka', 'zavitki', 'zavitkov'],
  jajce: [10, 'škatla', 'škatli', 'škatle', 'škatel'], sojkos: [200, 'paket', 'paketa', 'paketi', 'paketov'], edamame: [400, 'vrečka', 'vrečki', 'vrečke', 'vrečk'],
}
const SHOP_SAME: Record<string, string> = { krompirb: 'krompir' }
const plN = (n: number, w: readonly string[]) => (n === 1 ? w[0] : n === 2 ? w[1] : n <= 4 ? w[2] : w[3])!
/**
 * (v3.49) NAKUPOVALNI SEZNAM IZ RECEPTOV (brez AI in prijave): sestavine receptov po pravilih seštete po živilu in
 * zaokrožene na pakiranje (skuta po 250 g, testenine po 500 g, jajca po 10); sestavine AI receptov, kot so napisane.
 */
export function shoppingList(recipes: readonly (Pick<Recipe, 'ingredients'> & Partial<Pick<Recipe, 'dish'>>)[], prefs?: string | null): string[] {
  return shoppingGroups(recipes, prefs).flatMap(g => g.items)
}
/** (v3.50) oddelki trgovine; olje, med in marmelado imaš verjetno doma; (v3.51) začimbe in drobno iz korakov */
export const SHOP_GROUPS = ['Sadje in zelenjava', 'Mlečni izdelki, jajca in tofu', 'Meso in ribe', 'Kruh, kosmiči, riž in testenine', 'Konzerve, stročnice in drugo', 'Začimbe in drobno', 'Verjetno imaš doma', 'Iz AI receptov'] as const
const G_SPICE = 5, G_HOME = 6, G_AI = 7
const GROUP_OF: Record<string, number> = {
  zelenjava: 0, solata: 0, cebula: 0, krompir: 0, banana: 0, jabolko: 0, sadje: 0, zelje: 0,
  jogurt: 1, skuta: 1, mleko: 1, kefir: 1, sir: 1, jajce: 1, sojjogurt: 1, sojmleko: 1, tofu: 1,
  piscanec: 2, puran: 2, govedina: 2, mleto: 2, sunka: 2, losos: 2, oslic: 2,
  kruh: 3, belkruh: 3, oves: 3, riz: 3, rizb: 3, testenine: 3, testenineb: 3, kuskus: 3, ajda: 3, polenta: 3, jesprenj: 3, moka: 3,
  olje: G_HOME, med: G_HOME, marmelada: G_HOME,
}
/** (v3.51) teža kosa za nakup (paradižnik, glava solate, jabolko ali hruška) */
const SHOP_KOS: Record<string, [number, readonly string[]]> = { paradižnik: [120, ['kos', 'kosa', 'kosi', 'kosov']], 'zelena solata': [250, ['glava', 'glavi', 'glave', 'glav']] }
/**
 * (v3.50) Nakupovalni seznam po oddelkih; »zelenjava« po vrstah iz receptov (paprika, bučke, blitva …) in »čebula in
 * česen« posebej — prej »zelenjava: 3 kg« brez vrste in vse po abecedi (mleko ob mesu ob moki).
 * (v3.51) Solata in paradižnik posebej, jabolka in sadje v eni vrstici, zelena (gomolj), začimbe iz korakov.
 */
export function shoppingGroups(recipes: readonly (Pick<Recipe, 'ingredients'> & Partial<Pick<Recipe, 'dish'>>)[], prefs?: string | null): { title: string; items: string[] }[] {
  const ex = exclusionsOf(prefs), lf = !!ex.lactoseFree
  const noOnion = !!ex.skip?.includes('čebula'), noGarlic = !!ex.skip?.includes('česen')
  const sum = new Map<string, number>(), veg = new Map<string, number>()
  const ai: string[] = [], spice: string[] = []
  const addV = (name: string, q: number) => { if (!(name === 'čebula' && noOnion) && !(name === 'česen' && noGarlic)) veg.set(name, (veg.get(name) || 0) + q) }
  for (const r of recipes) {
    const d = r.dish ? DISHES.find(x => x.id === r.dish) ?? LF_DISHES.find(x => x.id === r.dish) : undefined
    for (const x0 of d?.extra || []) { const x = ex.contains.includes('gluten') ? gfSoy(x0) : x0; if (!spice.includes(x) && !wordsHit(x0, ex.words) && !(x === 'česen' && noGarlic)) spice.push(x) }
    for (const i of r.ingredients) {
      if (F[i.key] && i.qty > 0) {
        // (v3.50) brez zelenjave, ki je ne maraš ali ti škodi (»ne maram brokolija«, »alergija na zeleno«): grami gredo ostalim vrstam
        if (i.key === 'zelenjava') { const ok = (d?.veg || []).filter(v => !wordsHit(v, ex.words) && !(v === 'čebula' && noOnion)); const vs = ok.length ? ok : ['zelenjava po izbiri']; for (const v of vs) addV(v, i.qty / vs.length); continue }
        if (i.key === 'cebula') { addV('čebula', i.qty * 0.85); addV('česen', i.qty * 0.15); continue }
        // (v3.51) »zelena solata in paradižnik« sta dve živili (prej »620 g« v eni vrstici)
        if (i.key === 'solata') { addV('paradižnik', i.qty * 0.6); addV('zelena solata', i.qty * 0.4); continue }
        const k = SHOP_SAME[i.key] ?? i.key; sum.set(k, (sum.get(k) || 0) + i.qty)
      } else if (i.text && !ai.includes(i.text)) ai.push(i.text)
    }
  }
  const amtOf = (q: number, unit: string) => { const g = Math.ceil(q / 10) * 10; return { g, t: g >= 1000 ? `${String(Math.round(g / 100) / 10).replace('.', ',')} ${unit === 'ml' ? 'l' : 'kg'}` : `${g} ${unit}` } }
  const groups: string[][] = SHOP_GROUPS.map(() => [])
  // (v3.51) jabolka (kosi) in sadje (jabolko, hruška; grami) v eni vrstici — prej »jabolko: 1 kos« in »sadje: 670 g«
  const fruitG = sum.get('sadje') || 0
  if (fruitG > 0) {
    const n = Math.ceil(sum.get('jabolko') || 0) + Math.max(1, Math.round(fruitG / 150))
    groups[0]!.push(`jabolka ali hruške: ≈ ${n} ${plN(n, ['kos', 'kosa', 'kosi', 'kosov'])}`)
    sum.delete('sadje'); sum.delete('jabolko')
  }
  for (const [k, q] of sum) {
    const f = F[k]!, name = (lf && LACTOSE_FREE[k]) || nameOf(k), pk = PACK[k]
    let line: string
    if (f.unit === 'kos') { const n = Math.ceil(q), b = pk ? Math.ceil(n / pk[0]) : 0; line = `${name}: ${n} ${plN(n, ['kos', 'kosa', 'kosi', 'kosov'])}${pk && n > pk[0] ? ` (${b} ${plN(b, pk.slice(1) as string[])} po ${pk[0]})` : ''}` }
    else {
      const { g, t } = amtOf(q, f.unit)
      const packs = pk ? Math.ceil(g / pk[0]) : 0
      const per = pk ? (pk[1] === 'liter' ? '' : pk[0] >= 1000 ? ` po ${pk[0] / 1000} kg` : ` po ${pk[0]} ${f.unit}`) : ''
      line = `${name}: ${t}${pk ? ` (${packs} ${plN(packs, pk.slice(1) as string[])}${per})` : ''}`
    }
    groups[GROUP_OF[k] ?? 4]!.push(line)
  }
  for (const [v, q] of veg) {
    const { g, t } = amtOf(q, 'g'), kos = SHOP_KOS[v], kn = kos ? Math.max(1, Math.round(g / kos[0])) : 0
    groups[0]!.push(v === 'česen' ? `česen: ${t} (≈ ${Math.max(1, Math.round(g / 45))} ${plN(Math.max(1, Math.round(g / 45)), ['glavica', 'glavici', 'glavice', 'glavic'])})`
      : kos ? `${v}: ${t} (≈ ${kn} ${plN(kn, kos[1])})` : `${v === 'zelena' ? 'zelena (gomolj)' : v}: ${t}`)
  }
  // (v3.51) začimbe in drobno iz korakov (limona, curry, lovorov list) — brez česna, ki je že med zelenjavo
  groups[G_SPICE]!.push(...spice.filter(x => !veg.has(x)))
  groups[G_AI]!.push(...ai.map(t => `${t} (AI recept)`))
  return SHOP_GROUPS.map((title, i) => ({ title, items: i === G_AI ? groups[i]! : groups[i]!.sort((a, b) => a.localeCompare(b, 'sl')) })).filter(g => g.items.length)
}
/**
 * (v3.51) Kljukice nakupa: veljajo 7 dni od dneva, ko si jih začel (prej so se pobrisale v ponedeljek, tudi če si v
 * soboto kupil za 7 dni). Vrne shranjene kljukice za danes ali prazno.
 */
export const SHOP_GOT_DAYS = 7
export function shopGotOf(raw: unknown, today: string): { from: string; got: Record<string, boolean> } {
  const o = raw && typeof raw === 'object' ? (raw as { from?: unknown; got?: unknown }) : null
  const from = typeof o?.from === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(o.from) ? o.from : null
  const days = from ? Math.round((Date.parse(`${today}T12:00:00Z`) - Date.parse(`${from}T12:00:00Z`)) / 864e5) : -1
  if (!from || days < 0 || days >= SHOP_GOT_DAYS || !o?.got || typeof o.got !== 'object') return { from: today, got: {} }
  return { from, got: o.got as Record<string, boolean> }
}
