import { F } from './dayplan'

/**
 * (v3.49) OCENA OBROKA BREZ AI — iz tabele živil, ki jo že uporabljajo recepti (F). Za vpis brez prijave, brez povezave
 * ali ko AI ne odgovori (prej je ostala samo ročna številka kalorij). Prepozna navadna živila v opisu
 * (»ovseni kosmiči 70 g, jogurt 200 g in banana«) s količino ali običajno porcijo. Vedno samo ocena — uporabnik jo preveri.
 */
type Key = keyof typeof F
interface LocalFood { key: Key; re: RegExp; portion: number; /** teža kosa ali rezine v g (kruh, sir, banana, jajce) */ piece?: number; /** g kuhanega na g suhega (riž, testenine) */ cooked?: number
  /** (v3.50) teža kosa, ko piše »kos« ali »rezina« — pica: cela je `piece`, kos je manjši */ slice?: number }
/** vrstni red šteje: daljše in bolj določene besede prej (paradižnikova omaka pred zelenjavo, bel kruh pred kruhom) */
const FOODS: LocalFood[] = [
  // (v3.50) sestavljene jedi in pijače, ki jih tabela prej ni poznala (pica, burek, kava z mlekom, pivo …) — pred
  // sestavinami, da »müsli« ni ovseni kosmiči, »čokoladno mleko« pa ostane mleko (mleko je pred čokolado)
  { key: 'belakava', re: /belakava/, portion: 1 },
  { key: 'kava', re: /\bkav[aeoi]?\b|espresso|\bkafe/, portion: 1 },
  { key: 'musli', re: /m[üu]sli|granol|koruzn\w* kosmi/, portion: 60 },
  // (v3.50) »1 pica« je cela pica (prej en kos, 120 g); kos samo z »kos« ali »rezina«
  { key: 'pica', re: /\bpic[aeio]\b|pizz/, portion: 350, piece: 350, slice: 120 },
  { key: 'burek', re: /\bbur(e)?k/, portion: 250, piece: 250 },
  { key: 'sendvic', re: /sendvi[čc]|toast z|hamburger|kebab/, portion: 200, piece: 200 },
  { key: 'golaz', re: /gola[žz]|ri[čc]et|\bjot[aeio]\b|ene[čc]olonc/, portion: 350 },
  { key: 'palacinka', re: /pala[čc]in/, portion: 150, piece: 75 },
  { key: 'pecivo', re: /zavit|roglji|\bkrof|[šs]trudl|pecivo|potic|ka[šs]tel/, portion: 100, piece: 90 },
  { key: 'pivo', re: /\bpiv[aou]?\b|\bpivc/, portion: 500 },
  { key: 'vino', re: /\bvin[aou]?\b|\bspritzer|[šs]pricer/, portion: 200 },
  { key: 'gazirana', re: /koka[- ]?kol|\bcola\b|\bkol[aei]\b|pepsi|gazira|sprite|fanta|ledeni [čc]aj/, portion: 330 },
  { key: 'sok', re: /\bsok/, portion: 250 },
  { key: 'arasid', re: /ara[šs]idov\w* masl/, portion: 15 },
  { key: 'oves', re: /ovs|kosmi[čc]/, portion: 60 },
  { key: 'jogurt', re: /jogurt/, portion: 150 },
  { key: 'kefir', re: /kefir/, portion: 250 },
  { key: 'mleko', re: /mlek/, portion: 250 },
  { key: 'skuta', re: /skut/, portion: 250 },
  { key: 'smetana', re: /smetan/, portion: 30 },
  { key: 'maslo', re: /masl(?!in)/, portion: 10 },   // masline niso maslo
  { key: 'majoneza', re: /majonez|tatarsk/, portion: 15 },
  { key: 'sir', re: /\bsir(?!up|ot)|edamec|gavda|gauda|mocarel|parmez|grana|trapist|ementaler/, portion: 40, piece: 20 },   // (v3.49) sirup in sirotka nista sir
  { key: 'cokolada', re: /[čc]okolad|nutell|[čc]okoladn/, portion: 25 },
  { key: 'keksi', re: /keks|pi[šs]kot|napolitank|vaflj/, portion: 30, piece: 10 },
  { key: 'cips', re: /[čc]ips|smoki|flips|kreker/, portion: 40 },
  { key: 'banana', re: /banan/, portion: 1, piece: 120 },
  { key: 'jabolko', re: /jabol/, portion: 1, piece: 150 },
  { key: 'sadje', re: /hru[šs]k|pomaran[čc]|jagod|borovnic|sadj|grozdj|kivi|breskv|mandarin/, portion: 150 },
  { key: 'marmelada', re: /marmelad|d[žz]em/, portion: 20 },
  { key: 'med', re: /\bmed(om|u)?\b(?!\s+(vo[žz]njo|vadbo|treningom|tekom|tednom))/, portion: 15 },
  { key: 'hrenovka', re: /hrenov|klobas|kranjsk/, portion: 100, piece: 50 },
  { key: 'salama', re: /salam|mortadel|pr[šs]ut|pa[šs]tet/, portion: 40, piece: 10 },
  { key: 'sunka', re: /[šs]unk/, portion: 45, piece: 15 },
  { key: 'belkruh', re: /bel\w* kruh|[žz]emlj|toast|baget|kajzer/, portion: 80, piece: 40 },
  { key: 'kruh', re: /kruh|rezin/, portion: 80, piece: 40 },
  // (v3.50) grami žit brez pridevnika so KUHANI (kot jih stehtaš na krožniku); »suh«, »surov« ali »nekuhan« = suhi grami
  { key: 'riz', re: /ri[žz]/, portion: 70, cooked: 2.6 },
  { key: 'testenine', re: /testenin|[šs]paget|makaron|penne|fusil|ravio|njok|lazanj/, portion: 90, cooked: 2.3 },
  { key: 'kuskus', re: /kuskus/, portion: 70, cooked: 2.5 },
  { key: 'ajda', re: /ajdov\w* ka[šs]|\bajd/, portion: 60, cooked: 3 },
  { key: 'jesprenj', re: /je[šs]prenj/, portion: 60, cooked: 3 },
  { key: 'polenta', re: /polent|koruzn\w* zdrob/, portion: 60, cooked: 4 },
  { key: 'pomfri', re: /pomfri/, portion: 150 },
  { key: 'krompir', re: /krompir/, portion: 250 },
  { key: 'piscanec', re: /pi[šs][čc]an|pi[šs][čc]an[čc]j/, portion: 150 },
  { key: 'puran', re: /puran/, portion: 150 },
  { key: 'losos', re: /losos/, portion: 150 },
  { key: 'tuna', re: /tun[aeoi]\b|tuno/, portion: 110 },
  { key: 'tofu', re: /tofu/, portion: 150 },
  { key: 'jajce', re: /jaj[cč]|jajk|omlet/, portion: 2, piece: 55 },
  { key: 'omaka', re: /omak/, portion: 150 },
  { key: 'fizol', re: /fi[žz]ol|[čc]i[čc]erik/, portion: 200 },
  { key: 'leca', re: /\ble[čc][aeoi]\b/, portion: 200 },
  { key: 'solata', re: /solat/, portion: 150 },
  { key: 'zelenjava', re: /zelenjav|brokol|paradi[žz]nik|kumar|paprik|korenj|bu[čc]k|[šs]pina[čc]|cvet[aá]?a/, portion: 150 },
  { key: 'oreski', re: /ore[šs]|oreh|mandelj|le[šs]nik|ara[šs]id|indij|pistacij/, portion: 30 },
  { key: 'olje', re: /\bolj(?!k)/, portion: 10 },   // (v3.49) oljke niso olje (»10 oljk« je bilo 100 g olja = 900 kcal)
]
/** (v3.50) nadev v orodniku (»sirom«, »šunko«, »gobami«); pijače in sadje na -o (pivo, vino, mleko, jabolko) niso nadev */
const FILLING = /^(?!(?:piv|vin|mlek|jabolk|kakav|sadj)o$)\p{L}+(?:om|em|ami|mi|ema|o)$/u
const WORD_N: Record<string, number> = { pol: 0.5, en: 1, ena: 1, eno: 1, enega: 1, dva: 2, dve: 2, dvema: 2, tri: 3, treh: 3, štiri: 4, stiri: 4, pet: 5 }
const norm = (s: string) => s.toLowerCase().replace(/\s+/g, ' ').trim()

export interface LocalItem { key: string; name: string; qty: string; amount: number; kcal: number; p: number; c: number; f: number }
export interface LocalMeal { kcal: number; p: number; c: number; f: number; items: LocalItem[]; /** deli opisa, ki jih ne poznam */ unknown: string[] }

/** Vsota živil iz tabele: [ključ, količina v enoti tabele (g, ml ali kos)]. */
export function sumFoods(list: readonly [string, number][]): { kcal: number; p: number; c: number; f: number } {
  let kcal = 0, p = 0, c = 0, f = 0
  for (const [k, q] of list) { const x = F[k]; if (!x || !(q > 0)) continue; const r = q / x.per; kcal += x.kcal * r; p += x.p * r; c += x.c * r; f += x.f * r }
  return { kcal: Math.round(kcal), p: Math.round(p), c: Math.round(c), f: Math.round(f) }
}

/** (v3.50) suhi grami žit: »suh«, »surov«, »nekuhan« (prej samo »suh|surov«) */
const RAW = /suh|surov|nekuhan/
/** (v3.50) besedne enote: »pol litra«, »2 deci«, »skodelica« (prej samo za številke — »pol litra mleka« = 125 ml) */
const WORD_UNIT: [RegExp, string][] = [[/\blit(e)?r\w*/, 'l'], [/\bdec(i|ilit)\w*/, 'dl'], [/skodelic\w*/, 'kozar']]
/** Količina v enoti tabele iz besedila dela opisa (»200 g«, »2 rezini«, »pol«, »kozarec«); brez količine običajna porcija. */
function amountOf(part: string, food: LocalFood): number {
  const unit = F[food.key]!.unit
  const m = /(\d+(?:[.,]\d+)?)\s*(kg|dag|g|dl|ml|l|kos\w*|rezin\w*|[žz]li[čc]k\w*|[žz]lic\w*|lon[čc]\w*|kozar\w*)?(?![\p{L}])/u.exec(part)
  const w = Object.keys(WORD_N).find(k => new RegExp(`(^|\\s)${k}(\\s|$)`).test(part))
  const n = m ? +m[1]!.replace(',', '.') : w ? WORD_N[w]! : null
  const u = m?.[2] || WORD_UNIT.find(([re]) => re.test(part))?.[1] || (/(rezin|kos|[žz]li[čc]k|[žz]lic|lon[čc]|kozar)/.exec(part)?.[1] ?? '')
  const raw = RAW.test(part)
  // grami ali mililitri → enota tabele (kuhan riž in testenine na suho težo, kos iz teže kosa)
  const fromG = (g: number) => (unit === 'kos' ? Math.max(0.5, Math.round((g / (food.piece || 100)) * 2) / 2) : food.cooked && !raw ? g / food.cooked : g)
  if (n != null && /^(kg)$/.test(u)) return fromG(n * 1000)
  if (n != null && /^dag$/.test(u)) return fromG(n * 10)
  if (n != null && /^(g|ml)$/.test(u)) return fromG(n)
  if (n != null && u === 'dl') return fromG(n * 100)
  if (n != null && u === 'l') return fromG(n * 1000)
  const k = n ?? 1
  if (/^[žz]li[čc]k/.test(u)) return fromG(k * (food.key === 'med' || food.key === 'marmelada' ? 7 : 5))
  if (/^[žz]lic/.test(u)) return fromG(k * (food.key === 'med' || food.key === 'marmelada' ? 20 : 10))
  if (/^lon[čc]/.test(u)) return fromG(k * (food.key === 'skuta' ? 250 : 150))
  if (/^kozar/.test(u)) return fromG(k * 250)
  if (/^(rezin|kos)/.test(u)) return unit === 'kos' ? k : k * (food.slice || food.piece || food.portion)
  if (n != null && n > 10 && unit !== 'kos') return fromG(n)                 // »jogurt 200« = 200 g
  if (unit === 'kos') return n != null ? n : food.portion                      // »3 jajca«, »banana«
  return n != null ? n * (food.piece || food.portion) : food.portion          // »2 kruha« = 2 rezini, »pol skute«
}

/**
 * Oceni obrok iz opisa. Null = ničesar ne prepoznam (takrat ostane ročni vpis).
 * Deli opisa: vejica, »in«, »z/s«, »+«, »ter«, nova vrstica.
 */
export function estimateMeal(desc: string): LocalMeal | null {
  const s0 = norm(desc)
    // (v3.50) odstotek maščobe ni količina (»mleko 1,5 %« je bilo 1,5 porcije = 375 ml)
    .replace(/\d+(?:[.,]\d+)?\s*%/g, ' ').replace(/\s+/g, ' ').trim()
    // (v3.50) decimalna vejica ni ločilo (»0,5 l« je bilo »0« in »5 l« → količina 0)
    .replace(/(\d),(\d)/g, '$1.$2')
    // (v3.50) kava z mlekom je ena pijača (~40 ml mleka), ne kava + 250 ml mleka
    .replace(/\bbel\w* kav\w*|\bkav\w* z mlekom|kapu[čc]in\w*|cappuccino|\blatte\b|macchiato|makiat\w*/g, 'belakava')
    // (v3.50) nadev sestavljene jedi je že v njej (»burek s sirom«, »pica s šunko«, »sendvič s šunko«)
    // (v3.50) tudi naštevanje nadeva v orodniku (»pica s šunko in sirom«, »s šunko, sirom in gobami«) — ne »burek s sirom in jogurt«
    .replace(/\b(bur(?:e)?k\w*|pic[aeio]|pizz\w*|sendvi[čc]\w*)\s+(?:z|s)\s+\p{L}+((?:\s*(?:,|\bin\b)\s*\p{L}+)*)/gu, (_m, dish: string, more: string) => {
      const rest = (more || '').split(/\s*(?:,|\bin\b)\s*/u).filter(Boolean)
      const k = rest.findIndex(w => !FILLING.test(w))
      return k < 0 ? dish : `${dish} in ${rest.slice(k).join(' in ')}`
    })
  const parts = s0.split(/\s*(?:,|;|\+|\n|\bin\b|\bter\b|\bz\b|\bs\b|\bpa\b)\s*/).map(x => x.trim()).filter(Boolean)
  const items: LocalItem[] = [], unknown: string[] = []
  let at = 0
  for (const part of parts) {
    const food = FOODS.find(x => x.re.test(part))
    // (v3.50) neznan del s predlogom iz opisa (»z ajvarjem«, ne »ajvarjem« — sklon je tak, kot si ga napisal)
    const i = s0.indexOf(part, at); if (i >= 0) at = i + part.length
    const prep = i > 0 ? /(?:^|\s)([zs])\s+$/.exec(s0.slice(Math.max(0, i - 3), i))?.[1] : undefined
    if (!food) { if (/\p{L}{3,}/u.test(part)) unknown.push(prep ? `${prep} ${part}` : part); continue }
    const amount = Math.round(amountOf(part, food) * 10) / 10
    if (!(amount > 0)) continue
    const x = F[food.key]!, s = sumFoods([[food.key, amount]])
    const raw = RAW.test(part)
    const qty = x.unit === 'kos' ? `${String(amount).replace('.', ',')} ${amount === 1 ? 'kos' : amount === 2 ? 'kosa' : amount <= 4 ? 'kosi' : 'kosov'}`
      : food.cooked ? `${raw ? 'suhih' : 'kuhanih'} ${Math.round(raw ? amount : amount * food.cooked)} g` : `${Math.round(amount)} ${x.unit}`
    items.push({ key: food.key, name: x.name.replace(/ \(suh[aei]?\)/, ''), qty, amount, ...s })
  }
  if (!items.length) return null
  const t = sumFoods(items.map(i => [i.key, i.amount] as [string, number]))
  return { ...t, items, unknown }
}
