import { F, type Food } from './dayplan'

/**
 * (v3.49) OCENA OBROKA BREZ AI — iz tabele živil, ki jo že uporabljajo recepti (F). Za vpis brez prijave, brez povezave
 * ali ko AI ne odgovori (prej je ostala samo ročna številka kalorij). Prepozna navadna živila v opisu
 * (»ovseni kosmiči 70 g, jogurt 200 g in banana«) s količino ali običajno porcijo. Vedno samo ocena — uporabnik jo preveri.
 */
/** (v3.51) živila samo za oceno brez AI (niso v receptih): meso, ribe, sestavljene jedi, juhe, napitki, gorivo za kolo.
 * Na 100 g ali ml (ali na kos); 4·B + 4·OH + 9·M je v ±5 % kcal kot v F — test to drži. */
export const LF: Record<string, Food> = {
  svinjina: { name: 'svinjsko meso (zrezek, pečenka)', per: 100, unit: 'g', kcal: 210, p: 26, c: 0, f: 11.5 },
  paniran: { name: 'paniran zrezek (dunajski, ocvrt)', per: 100, unit: 'g', kcal: 260, p: 18, c: 12, f: 15.5 },
  cevapcici: { name: 'čevapčiči ali pleskavica', per: 100, unit: 'g', kcal: 250, p: 17, c: 2, f: 19.5 },
  klobasa: { name: 'klobasa (kranjska)', per: 100, unit: 'g', kcal: 300, p: 13, c: 1, f: 27 },
  slanina: { name: 'slanina', per: 100, unit: 'g', kcal: 450, p: 13, c: 1, f: 44 },
  ocvirki: { name: 'ocvirki', per: 100, unit: 'g', kcal: 600, p: 30, c: 0, f: 53 },
  riba: { name: 'riba (postrv, brancin, orada)', per: 100, unit: 'g', kcal: 140, p: 20, c: 0, f: 6.5 },
  bolonjeze: { name: 'testenine z mesno omako', per: 100, unit: 'g', kcal: 160, p: 8, c: 20, f: 5.3 },
  lazanja: { name: 'lazanja', per: 100, unit: 'g', kcal: 165, p: 9, c: 14, f: 8.2 },
  sarma: { name: 'sarma ali polnjena paprika', per: 100, unit: 'g', kcal: 130, p: 7, c: 6, f: 8.7 },
  musaka: { name: 'musaka', per: 100, unit: 'g', kcal: 150, p: 7, c: 9, f: 9.5 },
  tortelini: { name: 'tortelini ali ravioli (kuhani)', per: 100, unit: 'g', kcal: 220, p: 9, c: 30, f: 7.2 },
  rizota: { name: 'rižota', per: 100, unit: 'g', kcal: 140, p: 3.5, c: 20, f: 5 },
  zganci: { name: 'žganci (ajdovi ali koruzni)', per: 100, unit: 'g', kcal: 120, p: 4, c: 23, f: 1.3 },
  pire: { name: 'pire krompir', per: 100, unit: 'g', kcal: 110, p: 2, c: 15, f: 4.5 },
  griz: { name: 'mlečni zdrob (griz)', per: 100, unit: 'g', kcal: 100, p: 3.8, c: 15, f: 2.8 },
  juha: { name: 'juha z rezanci (goveja, piščančja)', per: 100, unit: 'ml', kcal: 60, p: 3.5, c: 6, f: 2.4 },
  juhazel: { name: 'zelenjavna juha', per: 100, unit: 'ml', kcal: 40, p: 1.2, c: 5, f: 1.7 },
  juhakrem: { name: 'kremna juha', per: 100, unit: 'ml', kcal: 80, p: 2, c: 7, f: 5 },
  minestra: { name: 'mineštra ali pašta fižol', per: 100, unit: 'g', kcal: 100, p: 5, c: 15, f: 2.2 },
  protein: { name: 'beljakovine v prahu', per: 100, unit: 'g', kcal: 380, p: 78, c: 8, f: 4.5 },
  proteinbar: { name: 'beljakovinska ploščica', per: 1, unit: 'kos', kcal: 220, p: 20, c: 20, f: 7 },
  ploscica: { name: 'energijska ploščica', per: 1, unit: 'kos', kcal: 200, p: 5, c: 40, f: 2.2 },
  gel: { name: 'gel', per: 1, unit: 'kos', kcal: 100, p: 0, c: 25, f: 0 },
  izotonik: { name: 'izotonik', per: 100, unit: 'ml', kcal: 24, p: 0, c: 6, f: 0 },
  frutabela: { name: 'Frutabela', per: 1, unit: 'kos', kcal: 100, p: 0.5, c: 19, f: 2.5 },
  namaz: { name: 'čokoladni namaz (nutela)', per: 100, unit: 'g', kcal: 540, p: 6, c: 57, f: 31 },
  kakav: { name: 'kakav z mlekom', per: 100, unit: 'ml', kcal: 75, p: 3.4, c: 10, f: 2.3 },
  torta: { name: 'torta', per: 100, unit: 'g', kcal: 330, p: 5, c: 40, f: 16.5 },
  sladoled: { name: 'sladoled', per: 100, unit: 'g', kcal: 200, p: 3.5, c: 24, f: 10 },
  lubenica: { name: 'lubenica ali melona', per: 100, unit: 'g', kcal: 32, p: 0.6, c: 7.2, f: 0.2 },
  kecap: { name: 'kečap ali gorčica', per: 100, unit: 'g', kcal: 100, p: 1.5, c: 22, f: 0.8 },
  caj: { name: 'čaj (nesladkan)', per: 100, unit: 'ml', kcal: 1, p: 0, c: 0.2, f: 0 },
}
/** tabela za oceno: F (recepti) + LF */
const T: Record<string, Food> = { ...F, ...LF }
type Key = string
interface LocalFood { key: Key; re: RegExp; /** (v3.51) ime v oceni, kadar ni ime iz tabele (kivi, ne »sadje (jabolko, hruška)«) */ name?: string; portion: number; /** teža kosa ali rezine v g (kruh, sir, banana, jajce) */ piece?: number; /** g kuhanega na g suhega (riž, testenine) */ cooked?: number
  /** (v3.50) teža kosa, ko piše »kos« ali »rezina« — pica: cela je `piece`, kos je manjši */ slice?: number }
/** vrstni red šteje: daljše in bolj določene besede prej (paradižnikova omaka pred zelenjavo, bel kruh pred kruhom) */
const FOODS: LocalFood[] = [
  // (v3.50) sestavljene jedi in pijače, ki jih tabela prej ni poznala (pica, burek, kava z mlekom, pivo …) — pred
  // sestavinami, da »müsli« ni ovseni kosmiči, »čokoladno mleko« pa ostane mleko (mleko je pred čokolado)
  { key: 'belakava', re: /belakava/, portion: 1 },
  { key: 'kava', re: /\bkav[aeoi]?\b|espresso|\bkafe/, portion: 1 },
  // (v3.51) ledeni čaj je sladka pijača (gazirana), ne nesladkan čaj
  { key: 'caj', re: /(?<!leden\p{L}{0,4})(?:^|\s)[čc]aj[aeu]?(?:\s|$)/u, portion: 250 },
  // (v3.51) juhe pred mesom in zelenjavo (»piščančja juha« ni 150 g prsi, »zelenjavna juha« ni 150 g zelenjave)
  { key: 'juhakrem', re: /kremn\w* juh|juh\w* krem|bu[čc]n\w* juh|gobov\w* juh/, portion: 300 },
  { key: 'juhazel', re: /zelenjavn\w* juh|paradi[žz]nikov\w* juh|krompirjev\w* juh|bistr\w* juh/, portion: 300 },
  { key: 'minestra', re: /mine[šs]tr|pa[šs]t\w* (?:e )?fi[žz]ol/, portion: 400 },
  { key: 'juha', re: /juh/, portion: 350 },
  // (v3.51) sestavljene jedi z omako ali nadevom (prej gole testenine ali nič)
  { key: 'bolonjeze', re: /bolonj|bolognes|mesn\w* omak/, portion: 400 },
  { key: 'lazanja', re: /lazanj/, portion: 380, piece: 380, slice: 300 },
  { key: 'sarma', re: /\bsarm|polnjen\w* paprik/, portion: 400, piece: 200 },
  { key: 'musaka', re: /musak/, portion: 350 },
  { key: 'tortelini', re: /tortel|ravio/, portion: 250 },
  { key: 'rizota', re: /\bri[žz]ot/, portion: 300 },
  { key: 'musli', re: /m[üu]sli(?! plo)|granol|koruzn\w* kosmi/, portion: 60 },
  // (v3.50) »1 pica« je cela pica (prej en kos, 120 g); kos samo z »kos« ali »rezina«
  { key: 'pica', re: /\bpic[aeio]\b|pizz/, portion: 350, piece: 350, slice: 120 },
  { key: 'burek', re: /\bbur(e)?k/, portion: 250, piece: 250 },
  { key: 'sendvic', re: /sendvi[čc]|toast z|hamburger|kebab/, portion: 200, piece: 200 },
  { key: 'golaz', re: /gola[žz]|ri[čc]et|\bjot[aeio]\b|ene[čc]olonc/, portion: 350 },
  { key: 'palacinka', re: /pala[čc]in/, portion: 150, piece: 75 },
  // (v3.51) rogljiček in krof sta manjša od kosa zavitka (prej oba 100 g)
  { key: 'pecivo', name: 'rogljiček', re: /roglji/, portion: 60, piece: 60 },
  { key: 'pecivo', name: 'krof', re: /\bkrof/, portion: 75, piece: 75 },
  { key: 'pecivo', re: /zavit|[šs]trudl|pecivo|potic|ka[šs]tel/, portion: 100, piece: 90 },
  { key: 'torta', re: /\btort[aeoi]?\b|\btortic|kola[čc]/, portion: 120, piece: 120, slice: 120 },
  { key: 'sladoled', re: /sladoled/, portion: 100, piece: 60 },
  { key: 'pivo', re: /\bpiv[aou]?\b|\bpivc/, portion: 500 },
  { key: 'vino', re: /\bvin[aou]?\b|\bspritzer|[šs]pricer/, portion: 200 },
  { key: 'gazirana', re: /koka[- ]?kol|\bcola\b|\bkol[aei]\b|pepsi|gazira|sprite|fanta|leden\w* [čc]aj/, portion: 330 },
  // (v3.51) gorivo iz kompleta za kolo (Gorivo ga pozna, ocena prej ne)
  { key: 'izotonik', re: /izoton|isostar|powerade|[šs]portn\w* napit/, portion: 500 },
  { key: 'sok', re: /\bsok/, portion: 250 },
  // (v3.51) beljakovinski napitki in ploščice (prej nič ali samo mleko)
  { key: 'proteinbar', re: /(?:protein|beljakovin)\w* plo[šs][čc]/, portion: 1 },
  { key: 'ploscica', re: /plo[šs][čc]ic|powerbar/, portion: 1 },
  { key: 'frutabela', re: /frutabel/, portion: 1 },
  { key: 'gel', re: /\bgel(?:a|i|e|ov|om)?\b/, portion: 1 },
  { key: 'protein', re: /protein|beljakovin\w* (?:napit|[šs]ejk|prah|shake)|\bwhey|[šs]ejk/, portion: 30 },
  // (v3.51) čokoladno mleko je kakav z mlekom (~75 kcal na 100 ml), ne navadno mleko 1,5 %
  { key: 'kakav', name: 'čokoladno mleko', re: /[čc]okoladn\w* mlek/, portion: 250 },
  { key: 'kakav', re: /kakav|kakao|vro[čc]\w* [čc]okolad/, portion: 250 },
  { key: 'arasid', re: /ara[šs]idov\w* masl/, portion: 15 },
  { key: 'oves', re: /ovs|kosmi[čc]/, portion: 60 },
  { key: 'jogurt', re: /jogurt/, portion: 150 },
  { key: 'kefir', re: /kefir/, portion: 250 },
  { key: 'griz', re: /\bgri[zž]|mle[čc]n\w* zdrob/, portion: 250 },
  { key: 'mleko', re: /mlek/, portion: 250 },
  { key: 'skuta', re: /skut/, portion: 250 },
  { key: 'smetana', re: /smetan/, portion: 30 },
  { key: 'maslo', re: /masl(?!in)/, portion: 10 },   // masline niso maslo
  { key: 'majoneza', re: /majonez|tatarsk/, portion: 15 },
  { key: 'kecap', re: /ke[čc]ap|ketchup|gor[čc]ic/, portion: 15 },
  { key: 'sir', re: /\bsir(?!up|ot)|edamec|gavda|gauda|mocarel|parmez|grana|trapist|ementaler/, portion: 40, piece: 20 },   // (v3.49) sirup in sirotka nista sir
  // (v3.51) namaz je svoje živilo (»lešnikov namaz« ni oreški); tablica čokolade je 100 g, kocka 10 g
  { key: 'namaz', re: /nutel|namaz|[čc]okoladn\w* krem/, portion: 25 },
  // (v3.51) kocka (košček) je 10 g — »2 kocki« sta bili 200 g kot dve tablici
  { key: 'cokolada', re: /[čc]okolad/, portion: 25, piece: 100, slice: 10 },
  { key: 'keksi', re: /keks|pi[šs]kot|napolitank|vaflj/, portion: 30, piece: 10 },
  { key: 'cips', re: /[čc]ips|smoki|flips|kreker/, portion: 40 },
  { key: 'banana', re: /banan/, portion: 1, piece: 120 },
  { key: 'jabolko', re: /jabol/, portion: 1, piece: 150 },
  // (v3.51) sadje s težo kosa (kivi ni jabolko), sadna solata ni zelena solata, lubenica ni kruh
  { key: 'sadje', name: 'sadna solata', re: /sadn\w* (?:solat|kup)/, portion: 250 },
  { key: 'lubenica', re: /lubenic|melon/, portion: 300, piece: 300, slice: 200 },
  { key: 'sadje', name: 'kivi', re: /kivi/, portion: 75, piece: 75 },
  { key: 'sadje', name: 'mandarina', re: /mandarin|klementin/, portion: 80, piece: 80 },
  { key: 'sadje', name: 'pomaranča', re: /pomaran[čc]/, portion: 180, piece: 180 },
  { key: 'sadje', name: 'hruška ali breskev', re: /hru[šs]k|breskv|nektarin/, portion: 150, piece: 150 },
  { key: 'sadje', name: 'sadje', re: /sadj|sadn|jagod|borovnic|grozdj|malin|[čc]e[šs]nj|marelic/, portion: 150 },
  { key: 'marmelada', re: /marmelad|d[žz]em/, portion: 20 },
  { key: 'med', re: /\bmed(om|u)?\b(?!\s+(vo[žz]njo|vadbo|treningom|tekom|tednom|malico|kosilom|zajtrkom))/, portion: 15 },
  // (v3.51) meso, ki ga tabela prej ni poznala: kranjska je kos 180 g, ne 100 g hrenovke
  { key: 'hrenovka', re: /hrenov/, portion: 100, piece: 50 },
  { key: 'klobasa', re: /klobas|kranjsk/, portion: 180, piece: 180 },
  { key: 'slanina', re: /slanin|pan[čc]et|\bbacon/, portion: 30, piece: 10 },
  { key: 'ocvirki', re: /ocvirk|zasek/, portion: 30 },
  { key: 'salama', re: /salam|mortadel|pr[šs]ut|pa[šs]tet/, portion: 40, piece: 10 },
  { key: 'sunka', re: /[šs]unk/, portion: 45, piece: 15 },
  { key: 'belkruh', name: 'lepinja ali tortilja', re: /lepinj|pita kruh|tortilj/, portion: 100, piece: 100 },
  // (v3.51) žemlja je kos ~70 g (»2 žemlji« sta bili 80 g — kot dve rezini kruha)
  { key: 'belkruh', name: 'žemlja', re: /[žz]emlj|kajzer/, portion: 70, piece: 70 },
  { key: 'belkruh', re: /bel\w* kruh|toast|baget/, portion: 80, piece: 40 },
  // (v3.51) »rezina« sama ni kruh (»rezina lubenice« je bila 40 g kruha)
  { key: 'kruh', re: /kruh/, portion: 80, piece: 40 },
  // (v3.50) grami žit brez pridevnika so KUHANI (kot jih stehtaš na krožniku); »suh«, »surov« ali »nekuhan« = suhi grami
  // (v3.51) »griz« ni riž; rezanci so testenine
  { key: 'riz', re: /\bri[žz]/, portion: 70, cooked: 2.6 },
  { key: 'testenine', re: /testenin|[šs]paget|makaron|penne|fusil|njok|rezanc/, portion: 90, cooked: 2.3 },
  { key: 'kuskus', re: /kuskus/, portion: 70, cooked: 2.5 },
  { key: 'zganci', re: /[žz]ganc/, portion: 300 },
  { key: 'ajda', re: /ajdov\w* ka[šs]|\bajd/, portion: 60, cooked: 3 },
  { key: 'jesprenj', re: /je[šs]prenj/, portion: 60, cooked: 3 },
  { key: 'polenta', re: /polent|koruzn\w* zdrob/, portion: 60, cooked: 4 },
  { key: 'pomfri', re: /pomfri|ocvrt\w* krompir/, portion: 150 },
  { key: 'pire', re: /\bpire/, portion: 250 },
  { key: 'krompir', re: /krompir/, portion: 250 },
  // (v3.51) paniran zrezek pred piščancem (»ocvrt piščanec« ni kuhan); svinjina in govedina z zrezkom ali pečenko
  { key: 'paniran', re: /dunajsk|panira|pohan|cordon|nugget|ocvrt\w*\s+(?:pi[šs][čc]|zrez|mes|rib|osli|puran|lign|kalamar)/, portion: 150, piece: 150 },
  // (v3.51) pleskavica je ena jed (~200 g), ne čevapčič 25 g
  { key: 'cevapcici', name: 'pleskavica', re: /pleskavic/, portion: 200, piece: 200 },
  { key: 'cevapcici', re: /[čc]evap/, portion: 200, piece: 25 },
  { key: 'piscanec', re: /pi[šs][čc]an|pi[šs][čc]an[čc]j/, portion: 150 },
  { key: 'puran', re: /puran/, portion: 150 },
  { key: 'govedina', re: /goved|govej|telet|tele[čc]|biftek|steak|zrezek iz goved/, portion: 150 },
  { key: 'mleto', re: /mlet\w* mes|polpet|mesn\w* kroglic|karbonadl/, portion: 150 },
  { key: 'svinjina', re: /svinj|pe[čc]enk|\bkare\b|zarebrn|kotlet|\bzrez|vratovin|rebrc|(?:^|\s)mes[ao]?(?:\s|$)/, portion: 150 },
  { key: 'losos', re: /losos/, portion: 150 },
  { key: 'tuna', re: /tun[aeoi]\b|tuno/, portion: 110 },
  { key: 'oslic', re: /osli[čc]/, portion: 150 },
  { key: 'riba', re: /postrv|brancin|\borad|sku[šs]|sardel|\brib[aeiou]?\b|ribj|\bribic/, portion: 180 },
  { key: 'tofu', re: /tofu/, portion: 150 },
  { key: 'jajce', re: /jaj[cč]|jajk|omlet/, portion: 2, piece: 55 },
  { key: 'omaka', re: /omak/, portion: 150 },
  { key: 'fizol', re: /fi[žz]ol|[čc]i[čc]erik/, portion: 200 },
  { key: 'leca', re: /\ble[čc][aeoi]\b/, portion: 200 },
  { key: 'solata', re: /solat/, portion: 150 },
  { key: 'zelenjava', re: /zelenjav|brokol|paradi[žz]nik|kumar|paprik|korenj|bu[čc]k|[šs]pina[čc]|cvet[aá]?a/, portion: 150 },
  { key: 'oreski', re: /ore[šs]|oreh|mandelj|le[šs]nik|ara[šs]id|indij|pistacij/, portion: 30 },
  { key: 'olje', re: /\bolj(?!k)/, portion: 10 },   // (v3.49) oljke niso olje (»10 oljk« je bilo 100 g olja = 900 kcal)
]
/** (v3.50) nadev v orodniku (»sirom«, »šunko«, »gobami«); pijače in sadje na -o (pivo, vino, mleko, jabolko) niso nadev */
const FILLING = /^(?!(?:piv|vin|mlek|jabolk|kakav|sadj)o$)\p{L}+(?:om|em|ami|mi|ema|o)$/u
/** (v3.51) do »deset« (»šest jajc« je bilo 2 jajci); »četrt« = ¼ */
const WORD_N: Record<string, number> = { pol: 0.5, četrt: 0.25, en: 1, ena: 1, eno: 1, enega: 1, dva: 2, dve: 2, dvema: 2, tri: 3, treh: 3, štiri: 4, stiri: 4, pet: 5, šest: 6, sest: 6, sedem: 7, osem: 8, devet: 9, deset: 10 }
const norm = (s: string) => s.toLowerCase().replace(/\s+/g, ' ').trim()

export interface LocalItem { key: string; name: string; qty: string; amount: number; kcal: number; p: number; c: number; f: number }
export interface LocalMeal { kcal: number; p: number; c: number; f: number; items: LocalItem[]; /** deli opisa, ki jih ne poznam */ unknown: string[] }

/** Vsota živil iz tabele: [ključ, količina v enoti tabele (g, ml ali kos)]. */
export function sumFoods(list: readonly [string, number][]): { kcal: number; p: number; c: number; f: number } {
  let kcal = 0, p = 0, c = 0, f = 0
  for (const [k, q] of list) { const x = T[k]; if (!x || !(q > 0)) continue; const r = q / x.per; kcal += x.kcal * r; p += x.p * r; c += x.c * r; f += x.f * r }
  return { kcal: Math.round(kcal), p: Math.round(p), c: Math.round(c), f: Math.round(f) }
}

/** (v3.50) suhi grami žit: »suh«, »surov«, »nekuhan« (prej samo »suh|surov«) */
const RAW = /suh|surov|nekuhan/
/** (v3.50) besedne enote: »pol litra«, »2 deci«, »skodelica« (prej samo za številke — »pol litra mleka« = 125 ml) */
const WORD_UNIT: [RegExp, string][] = [[/\blit(e)?r\w*/, 'l'], [/\bdec(i|ilit)\w*/, 'dl'], [/skodelic\w*/, 'kozar']]
/** (v3.51) enota za besednim številom: »pol kg«, »pol kile«, »dve deki« (»pol kg krompirja« je bil 125 g) */
const WORD_N_UNIT: [RegExp, string][] = [[/^(kg|kil\p{L}*)$/u, 'kg'], [/^(dag|dek\p{L}*)$/u, 'dag'], [/^(g|gram\p{L}*)$/u, 'g'], [/^dl$/, 'dl'], [/^ml$/, 'ml'], [/^l$/, 'l']]
/** Količina v enoti tabele iz besedila dela opisa (»200 g«, »2 rezini«, »pol«, »kozarec«); brez količine običajna porcija. */
function amountOf(part: string, food: LocalFood): number {
  const unit = T[food.key]!.unit
  const m = /(\d+(?:[.,]\d+)?)\s*(kg|dag|g|dl|ml|l|kos\w*|kock\w*|ko[šs][čc]\w*|rezin\w*|[žz]li[čc]k\w*|[žz]lic\w*|lon[čc]\w*|kozar\w*)?(?![\p{L}])/u.exec(part)
  const w = Object.keys(WORD_N).find(k => new RegExp(`(^|\\s)${k}(\\s|$)`).test(part))
  const n = m ? +m[1]!.replace(',', '.') : w ? WORD_N[w]! : null
  const wNext = !m && w ? new RegExp(`(?:^|\\s)${w}\\s+(\\p{L}+)`, 'u').exec(part)?.[1] : undefined
  const wu = wNext ? WORD_N_UNIT.find(([re]) => re.test(wNext))?.[1] : undefined
  const u = m?.[2] || wu || WORD_UNIT.find(([re]) => re.test(part))?.[1] || (/(rezin|kos|kock|ko[šs][čc]|[žz]li[čc]k|[žz]lic|lon[čc]|kozar|tablic|kepic)/.exec(part)?.[1] ?? '')
  const raw = RAW.test(part)
  // grami ali mililitri → enota tabele (kuhan riž in testenine na suho težo, kos iz teže kosa)
  const fromG = (g: number) => (unit === 'kos' ? Math.max(0.5, Math.round((g / (food.piece || 100)) * 2) / 2) : food.cooked && !raw ? g / food.cooked : g)
  if (n != null && /^(kg)$/.test(u)) return fromG(n * 1000)
  if (n != null && /^dag$/.test(u)) return fromG(n * 10)
  if (n != null && /^(g|ml)$/.test(u)) return fromG(n)
  if (n != null && u === 'dl') return fromG(n * 100)
  if (n != null && u === 'l') return fromG(n * 1000)
  const k = n ?? 1
  if (/^[žz]li[čc]k/.test(u)) return fromG(k * (food.key === 'med' || food.key === 'marmelada' ? 7 : 5))
  if (/^[žz]lic/.test(u)) return fromG(k * (food.key === 'med' || food.key === 'marmelada' ? 20 : 10))
  if (/^lon[čc]/.test(u)) return fromG(k * (food.key === 'skuta' ? 250 : 150))
  // (v3.51) kozarec vina je 150 ml (prej 250 ml kot za vodo)
  if (/^kozar/.test(u)) return fromG(k * (food.key === 'vino' ? 150 : 250))
  // (v3.51) tablica čokolade in kepica sladoleda: cel kos
  if (/^(tablic|kepic)/.test(u)) return unit === 'kos' ? k : k * (food.piece || food.portion)
  if (/^(rezin|kos|kock|ko[šs][čc])/.test(u)) return unit === 'kos' ? k : k * (food.slice || food.piece || food.portion)
  if (n != null && n > 10 && unit !== 'kos') return fromG(n)                 // »jogurt 200« = 200 g
  if (unit === 'kos') return n != null ? n : food.portion                      // »3 jajca«, »banana«
  return n != null ? n * (food.piece || food.portion) : food.portion          // »2 kruha« = 2 rezini, »pol skute«
}

/** (v3.51) ocvrto ali praženo: + olje (»pražen krompir« je bil kuhan, »jajca na oko« brez maščobe) */
const FRIED = /ocvrt|pra[žz]en|na oko|\bcvrt|na olju|na maslu|\bfrit/
const FRIED_IN = new Set(['pomfri', 'paniran', 'cips', 'olje', 'maslo', 'pecivo', 'burek', 'cevapcici', 'klobasa', 'slanina', 'ocvirki', 'hrenovka', 'palacinka'])
/** (v3.51) besede, ki niso živilo (pridevniki, mere, čas) — ostanek dela, ki ni med njimi, gre v »Ne poznam« */
const NOT_FOOD = /^(gr[šs]k|navad|kuhan|pe[čc]en|pra[žz]|ocvrt|du[šs]en|sve[žz]|doma[čc]|polnozrn|bel|[čc]rn|temn|pust|mast|nemast|posnet|lahk|sladk|nesladk|slan|velik|majhn|mal[aeio]?$|porcij|kro[žz]nik|skodel|kozar|lon[čc]|kos|rezin|[žz]li[čc]|[žz]lic|pest|tablic|kepic|dec|lit|gram|kil|dek|zajtr|kosil|ve[čc]erj|malic|vo[žz]nj|trening|vadb|tek|pred|brez|malo|veliko|dvojn|dvakrat|trikrat|suh|surov|nekuh|oliv|son[čc]n|kisl|ekolo|cel|polovic|[čc]etrt|nekaj|sam|vro[čc]|hlad|topl|mlad|pol|ena|dva|dve|tri|pet|[šs]est|sedem|osem|devet|deset|[šs]tiri|enega|dvema|treh|ve[čc]|manj|zelo|okoli|pribli|prepe[čc]|nareza|tanek|tank|debel|odcej|lastn|soku|kupljen|light|zero|ohlajen|mrzl|gost|mlet|zmlet|panira|dunajsk|kranjsk|rdeč|rumen|zelen|kokt|ledeni|navadn|cvrt|mle[čc]n|energij)/
const leftover = (part: string, re: RegExp): string => {
  // ujemanje razširi na cele besede, odstrani števila, enote in besede, ki niso živilo
  const m = re.exec(part); if (!m) return ''
  let a = m.index, b = a + m[0].length
  while (a > 0 && /\p{L}/u.test(part[a - 1]!)) a--
  while (b < part.length && /\p{L}/u.test(part[b]!)) b++
  return (part.slice(0, a) + ' ' + part.slice(b)).split(/\s+/).filter(w => /^\p{L}{5,}$/u.test(w) && !NOT_FOOD.test(w) && !FOODS.some(f => f.re.test(w))).join(' ')
}

/**
 * Oceni obrok iz opisa. Null = ničesar ne prepoznam (takrat ostane ročni vpis).
 * Deli opisa: vejica, »in«, »z/s«, »+«, »ter«, nova vrstica.
 */
export function estimateMeal(desc: string): LocalMeal | null {
  const s0 = norm(desc)
    // (v3.50) odstotek maščobe ni količina (»mleko 1,5 %« je bilo 1,5 porcije = 375 ml)
    .replace(/\d+(?:[.,]\d+)?\s*%/g, ' ').replace(/\s+/g, ' ').trim()
    // (v3.51) ulomki: »1/2 pice«, »½«, »polovica« (prej cela pica)
    .replace(/(\d+)\s*\/\s*(\d+)/g, (m0: string, a: string, b: string) => (+b ? String(Math.round((+a / +b) * 100) / 100) : m0))
    .replace(/½/g, ' 0.5 ').replace(/¼/g, ' 0.25 ').replace(/¾/g, ' 0.75 ')
    .replace(/(^|\s)polovic\p{L}*/gu, '$1pol').replace(/(^|\s)[čc]etrt(?:ina|ino|ine|ini|in)?(?!\p{L})/gu, '$1četrt')   // (v3.51) »četrtek« ni četrt
    // (v3.50) decimalna vejica ni ločilo (»0,5 l« je bilo »0« in »5 l« → količina 0)
    .replace(/(\d),(\d)/g, '$1.$2')
    // (v3.50) kava z mlekom je ena pijača (~40 ml mleka), ne kava + 250 ml mleka
    .replace(/\bbel\w* kav\w*|\bkav\w* z mlekom|kapu[čc]in\w*|cappuccino|\blatte\b|macchiato|makiat\w*/g, 'belakava')
    // (v3.51) kakav z mlekom je ena pijača; juha z rezanci ali zakuho je ena jed
    .replace(/\b(kakav\w*|kakao)\s+z\s+mlek\w*/g, '$1')
    .replace(/(juh\p{L}*)\s+(?:z|s)\s+(?:rezanc|zakuh|fritat|ribano|jajc|cmo[čc]|[žz]likrof|kro[čc]|kruhov)\p{L}*/gu, '$1')
    .replace(/\bjuh\p{L}*\s+(?:z|s)\s+zelenjav\p{L}*/gu, 'zelenjavna juha')
    // (v3.51) »namaz na kruhu« je kruh + namaz
    .replace(/\s+na\s+(kruh|[žz]emlj|toast|prepe[čc]en)/g, ' in $1')
    // (v3.51) »jajca na maslu« so jajca in maslo (prej samo maslo 10 g, jajca so tiho izpadla)
    .replace(/\s+na\s+(masl\p{L}*|olj(?!k)\p{L}*)/gu, (_m, w: string) => ` in ${/^masl/u.test(w) ? 'maslo' : 'olje'}`)
    // (v3.50) nadev sestavljene jedi je že v njej (»burek s sirom«, »pica s šunko«, »sendvič s šunko«)
    // (v3.50) tudi naštevanje nadeva v orodniku (»pica s šunko in sirom«, »s šunko, sirom in gobami«) — ne »burek s sirom in jogurt«
    .replace(/\b(bur(?:e)?k\w*|pic[aeio]|pizz\w*|sendvi[čc]\w*)\s+(?:z|s)\s+\p{L}+((?:\s*(?:,|\bin\b)\s*\p{L}+)*)/gu, (_m, dish: string, more: string) => {
      const rest = (more || '').split(/\s*(?:,|\bin\b)\s*/u).filter(Boolean)
      const k = rest.findIndex(w => !FILLING.test(w))
      return k < 0 ? dish : `${dish} in ${rest.slice(k).join(' in ')}`
    })
  // (v3.51) meje besed tudi ob šumnikih (»pašta« ni »pa« + »šta«)
  const parts = s0.split(/\s*(?:,|;|\+|\n|(?<!\p{L})(?:in|ter|z|s|pa)(?!\p{L}))\s*/u).map(x => x.trim()).filter(Boolean)
  const items: LocalItem[] = [], unknown: string[] = []
  let at = 0
  for (const part0 of parts) {
    // (v3.51) »2x jogurt«, »jogurt 2x« = dve porciji (prej ena)
    const mx = /(?:^|\s)(\d+)\s*[x×](?=\s|$)|(?:^|\s)[x×]\s*(\d+)(?=\s|$)/.exec(part0)
    const mult = mx ? +(mx[1] ?? mx[2])! : 1
    const part = mx ? `${part0.slice(0, mx.index)} ${part0.slice(mx.index + mx[0].length)}`.trim() : part0
    const food = FOODS.find(x => x.re.test(part))
    // (v3.50) neznan del s predlogom iz opisa (»z ajvarjem«, ne »ajvarjem« — sklon je tak, kot si ga napisal)
    const i = s0.indexOf(part0, at); if (i >= 0) at = i + part0.length
    const prep = i > 0 ? /(?:^|\s)([zs])\s+$/.exec(s0.slice(Math.max(0, i - 3), i))?.[1] : undefined
    if (!food) { if (/\p{L}{3,}/u.test(part)) unknown.push(prep ? `${prep} ${part}` : part); continue }
    const amount = Math.round(amountOf(part, food) * mult * 10) / 10
    if (!(amount > 0)) continue
    const x = T[food.key]!, s = sumFoods([[food.key, amount]])
    const raw = RAW.test(part)
    // (v3.51) kava je skodelica, ne »1 kos«
    const cup = food.key === 'kava' || food.key === 'belakava'
    const qty = x.unit === 'kos' ? `${String(amount).replace('.', ',')} ${cup ? (amount === 1 ? 'skodelica' : amount === 2 ? 'skodelici' : amount <= 4 ? 'skodelice' : 'skodelic') : amount === 1 ? 'kos' : amount === 2 ? 'kosa' : amount <= 4 ? 'kosi' : 'kosov'}`
      : food.cooked ? `${raw ? 'suhih' : 'kuhanih'} ${Math.round(raw ? amount : amount * food.cooked)} g` : `${Math.round(amount)} ${x.unit}`
    items.push({ key: food.key, name: food.name ?? x.name.replace(/ \(suh[aei]?\)/, ''), qty, amount, ...s })
    if (FRIED.test(part) && !FRIED_IN.has(food.key)) items.push({ key: 'olje', name: 'olje (cvrtje, praženje)', qty: '10 g', amount: 10, ...sumFoods([['olje', 10]]) })
    // (v3.51) neznana beseda ob znanem živilu ne izgine tiho (»špageti carbonara« je bil samo testenine)
    const rest = leftover(part, food.re); if (rest) unknown.push(rest)
  }
  if (!items.length) return null
  const t = sumFoods(items.map(i => [i.key, i.amount] as [string, number]))
  return { ...t, items, unknown }
}
