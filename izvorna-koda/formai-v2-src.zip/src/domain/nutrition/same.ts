import type { MealEntry } from '../types'

/**
 * ISTI OBROK KOT ZADNJIČ — brez tabele hrane: samo tvoji vpisi. Ko napišeš isto kot že kdaj (»ovseni kosmiči z
 * jogurtom in banano«), dobiš svoje zadnje (morda popravljene) številke namesto nove AI ocene, ki se lahko vsakič
 * razlikuje. Oceno z AI lahko vseeno zahtevaš.
 */
export function normSaid(t: string): string {
  return t.toLowerCase().normalize('NFC').replace(/[.,;:!?()"'»«]+/g, ' ').replace(/\s+/g, ' ').trim()
}

/** Zadnji obrok z istim opisom (kot si ga napisal) ali istim imenom; brez goriva med vožnjo. null = ga ni. */
export function sameMealBefore(meals: readonly MealEntry[], desc: string): MealEntry | null {
  const key = normSaid(desc)
  if (key.length < 4) return null
  let best: MealEntry | null = null
  for (const m of meals) {
    if (m.fuel || m.forDay || !m.kcal) continue
    if (m.said !== key && normSaid(m.name) !== key) continue
    if (!best || m.date > best.date || (m.date === best.date && (m.createdAt || '') > (best.createdAt || ''))) best = m
  }
  return best
}
