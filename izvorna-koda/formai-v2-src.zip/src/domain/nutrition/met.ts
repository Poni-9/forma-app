/**
 * (v3.49) MET za tek in hojo (Compendium of Physical Activities, 2011) — en vir za načrt, zabeležene teke in tek z hojo.
 * Prej je bil vsak tek 9,5 MET (≈ 9,7 km/h), tudi 30 min teka in hoje začetnika.
 */
/** lahek tek začetnika v pogovornem tempu (~8 km/h) */
export const MET_RUN_EASY = 8
/** hitra hoja med teki in na koncu (~5,5 km/h) */
export const MET_WALK_BRISK = 4.5

/** Načrtovan tek po vrsti seje: tek in hoja ali začetnik 6,5 · lahek ali Z1 8 · Z2 9 · tempo, Z3+ in ključni 10,5. */
export function planRunMet(d: { title?: string | null; zone?: string | null; role?: string | null }, level?: number | null): number {
  if (/hoj/i.test(d.title || '') || level === 1) return 6.5
  if (d.role === 'kljucna' || d.role === 'test' || d.role === 'dirka' || /Z[3-5]|tempo/i.test(d.zone || '') || /tempo/i.test(d.title || '')) return 10.5
  if (d.role === 'regen' || d.role === 'lahka' || d.zone === 'Z1') return 8
  return 9
}

/** Compendium: tek km/h → MET (6,4 km/h 6,0 … 16,1 km/h 14,5); pod 6,4 km/h je to večinoma hoja. */
const RUN_MET: [number, number][] = [[4.8, 3.5], [6.4, 6], [8, 8.3], [9.7, 9.8], [10.8, 10.5], [12.1, 11.5], [13.8, 12.3], [16.1, 14.5]]
/** Zabeležen tek po hitrosti (km/h, vzpon že preračunan), vmes linearno; neznana hitrost 9. */
export function runMetBySpeed(v: number | null): number {
  if (v == null || !(v > 0)) return 9
  if (v <= RUN_MET[0]![0]) return RUN_MET[0]![1]
  for (let i = 1; i < RUN_MET.length; i++) {
    const [v1, m1] = RUN_MET[i]!, [v0, m0] = RUN_MET[i - 1]!
    if (v <= v1) return +(m0 + ((v - v0) / (v1 - v0)) * (m1 - m0)).toFixed(2)
  }
  return RUN_MET[RUN_MET.length - 1]![1]
}
