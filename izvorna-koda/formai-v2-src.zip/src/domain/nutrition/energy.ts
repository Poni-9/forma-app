import { inSick } from '../training/sick'
import { raceSoon } from './race'
import type { Activity, MealEntry, PlanDay, Profile } from '../types'
import { weekContext } from '../training/planner'
import { weekStartIso, todayIso } from '../training/load'
import { raceMinutes, plannedRaceMinutes } from '../training/season'
import { activityMinutes, matchesPlanned, sameKind } from '../training/plandays'
import { targetWeightOf } from './body'

/* ====================================================================
   VAROVALKE — omejitve so v aritmetiki, ne v promptu.
   Prompt ne more popraviti številke, ki jo model dobi kot dejstvo.
   ==================================================================== */
export const MAX_DEFICIT = 750          // kcal/dan pod vzdrževanjem — več ni varno brez nadzora
export const MAX_ADJ_DOWN = -400        // (zgodovinsko) največ, kar je trening smel znižati cilj — ne velja več
/** Največ verjetne porabe na uro aktivnosti (napaka naprave ali uvoza, npr. 5000 kcal v 1 h) — ni omejitev treninga. */
export const MAX_KCAL_PER_HOUR = 1100
export const MIN_ABS_M = 1500           // absolutno dno (moški)
export const MIN_ABS_Z = 1200           // absolutno dno (ženske)
export const MAX_WEEKLY_LOSS_KG = 0.5   // nad tem: napotitev k zdravniku

export function profileComplete(p: Pick<Profile, 'weightKg' | 'heightCm' | 'age' | 'sex'>): boolean {
  return !!(p.weightKg && p.heightCm && p.age && p.sex)
}
export function isMinor(p: Pick<Profile, 'age'>): boolean { return !!p.age && p.age < 18 }

/** Mifflin-St Jeor. Vrne null, če profil ni popoln — nikoli ne ugibamo. */
export function bmr(p: Pick<Profile, 'weightKg' | 'heightCm' | 'age' | 'sex'>): number | null {
  if (!profileComplete(p)) return null
  const base = 10 * p.weightKg! + 6.25 * p.heightCm! - 5 * p.age!
  return Math.round(p.sex === 'm' ? base + 5 : base - 161)
}

/** Faktor aktivnosti iz tedenskih ur (brez treninga — tega dodamo dnevno posebej). */
export function activityFactor(hoursPerWeek?: number | null): number {
  const h = hoursPerWeek || 0
  return h <= 2 ? 1.35 : h <= 5 ? 1.45 : h <= 9 ? 1.55 : 1.65
}

/** Faktor gibanja IZVEN treninga (1,3 sedeče · 1,4 zmerno · 1,5 veliko hoje). Trening se prišteje dnevno. */
export function neatFactor(p: Pick<Profile, 'neat'>): number {
  return p.neat && p.neat >= 1.2 && p.neat <= 1.6 ? p.neat : 1.4
}

/** Vzdrževanje BREZ treninga: BMR × gibanje izven treninga. */
export function tdee(p: Profile): number | null {
  const b = bmr(p)
  if (b == null) return null
  return Math.round(b * neatFactor(p))
}

/** Ciljni deficit: nastavljen (300/500/750) ali 500 pri cilju »shujšati«. Mladoletni: 0 — vedno vzdrževanje. */
export function goalDeficit(p: Profile, date: string = todayIso()): number {
  if (isMinor(p)) return 0
  // na najboljši teži (ali pod njo): vzdrževanje — hujšanje ni več cilj, cilj so vati
  const tw = targetWeightOf(p, date)
  if (tw && p.weightKg && p.weightKg <= tw) return 0
  if (p.deficit != null && p.deficit > 0) return Math.min(MAX_DEFICIT, Math.round(p.deficit))
  if (p.goal === 'shujsati') return 500
  return 0
}

/* ---------- tekme: polnjenje z OH in dnevi brez deficita ---------- */
const DAY_MS = 86_400_000
const dayDiff = (from: string, to: string) => Math.round((Date.parse(to + 'T12:00:00Z') - Date.parse(from + 'T12:00:00Z')) / DAY_MS)
/** Dolga tekma (≥ 150 min): 2 dni prej polnjenje z OH 8–10 g na kg. */
export const CARB_LOAD_MIN = 150
/** Tekma ≥ 90 min: dan prej več OH (5–7 g na kg) in na kolesu vsaj 60 g OH na uro. */
export const RACE_FUEL_MIN = 90

function racesOf(p: Pick<Profile, 'event' | 'races'>): { name: string; date: string; min: number }[] {
  const out: { name: string; date: string; min: number }[] = []
  if (p.event?.date) out.push({ name: p.event.name, date: p.event.date, min: raceMinutes(p.event) })
  // trajanje kot v načrtu (druga tekma brez dolžine = 2 h), da prehrana in načrt govorita isto
  for (const r of p.races || []) if (r?.date && r.date !== p.event?.date) out.push({ name: r.name, date: r.date, min: plannedRaceMinutes(p, r) })
  return out
}

/**
 * OH pred tekmo za ta dan: 2 dni pred tekmo ≥ 150 min polnjenje 8 g na kg (spodnja meja 8–10 g),
 * dan pred tekmo 90–150 min 5 g na kg (spodnja meja 5–7 g). Kratke tekme (kronometer 30 min): normalen dan.
 */
export function raceCarbs(p: Pick<Profile, 'event' | 'races'>, date: string): { gkg: number; race: string; inDays: number; load: boolean } | null {
  let best: { gkg: number; race: string; inDays: number; load: boolean } | null = null
  for (const r of racesOf(p)) {
    const d = dayDiff(date, r.date)
    const gkg = (d === 1 || d === 2) && r.min >= CARB_LOAD_MIN ? 8 : d === 1 && r.min >= RACE_FUEL_MIN ? 5 : 0
    if (gkg && (!best || gkg > best.gkg)) best = { gkg, race: r.name, inDays: d, load: gkg >= 8 }
  }
  return best
}

/**
 * Dan brez deficita (tudi ročni cilj ne velja): tapering in teden cilja sezone, dan pred tekmo in dan tekme,
 * polnjenje z OH 2 dni pred dolgo tekmo. Vrne razlog za prikaz ali null.
 */
export function noDeficitDay(p: Profile, date: string): string | null {
  if (inSick(p, date)) return 'bolezen — brez deficita'
  const ctx = weekContext(p, weekStartIso(date))
  if (ctx.phase === 'tapering') return 'pred dirko brez deficita'
  if (ctx.phase === 'dirka') return ctx.event && date > ctx.event.date ? 'teden dirke brez deficita' : 'pred dirko brez deficita'
  // druga tekma: dan prej (polnjenje z OH) in na dan tekme brez deficita
  const rs = raceSoon(p, date)
  if (rs && rs.inDays <= 1) return rs.inDays ? 'dan pred tekmo brez deficita' : 'dan tekme brez deficita'
  const rc = raceCarbs(p, date)
  if (rc?.load) return 'polnjenje z OH pred tekmo, brez deficita'
  return null
}

/**
 * Deficit za konkreten dan: v specifični fazi polovica, v taperingu in tednu dirke nič;
 * na dan ključne seje, testa ali dolge vožnje (≥ 3 h) polovica — kakovost treninga je pomembnejša od grama.
 */
export function dayDeficit(p: Profile, todaysPlan: readonly PlanDay[], date: string): { kcal: number; note: string | null } {
  const full = Math.min(MAX_DEFICIT, goalDeficit(p, date))
  if (!full) { const tw = targetWeightOf(p, date); return { kcal: 0, note: tw && p.weightKg && p.weightKg <= tw ? 'si na najboljši teži, zato vzdrževanje' : null } }
  const protect = noDeficitDay(p, date)
  if (protect) return { kcal: 0, note: protect }
  const ph = weekContext(p, weekStartIso(date)).phase
  let k = ph === 'specificno' ? full * 0.5 : full, note: string | null = ph === 'specificno' ? 'specifična faza, zato pol' : null
  const hardDay = todaysPlan.some(d => !d.optional && (d.role === 'kljucna' || d.role === 'test' || d.role === 'dirka'))
  const longDay = todaysPlan.some(d => !d.optional && d.role === 'dolga' && d.durationMin >= 180)
  if (hardDay || longDay) { k *= 0.5; note = hardDay ? 'ključni trening, zato pol' : 'dolga vožnja, zato pol' }
  return { kcal: Math.round(k / 10) * 10, note }
}

/** Brez znanega trajanja je strop le proti tipkarski napaki (10 h × 1100 kcal), ne ocena ure. */
const MAX_KCAL_UNKNOWN_DURATION = 10 * MAX_KCAL_PER_HOUR + 100
const num = (x: unknown): number | null => (typeof x === 'number' && Number.isFinite(x) ? x : null)

/**
 * Poraba, ki je še verjetna za tako dolgo aktivnost (brez tega bi napaka naprave napihnila cilj).
 * Negativno ali neveljavno = 0. Brez znanega trajanja ne omejujemo po uri (5-urna vožnja brez trajanja ni 1 ura).
 */
export function plausibleKcal(kcal: number, minutes: number | null | undefined): number {
  const k = num(kcal)
  if (k == null || k <= 0) return 0
  const m = num(minutes)
  if (m == null || m <= 0) return Math.round(Math.min(k, MAX_KCAL_UNKNOWN_DURATION))
  const h = Math.max(0.25, m / 60)
  return Math.round(Math.min(k, h * MAX_KCAL_PER_HOUR + 100))
}

/**
 * MET ocena za dano trajanje (min). Hitrost: izmerjena, sicer razdalja / izmerjeno trajanje;
 * če je trajanje izračunano iz razdalje (assumedSpeed), tipična hitrost 25 km/h.
 */
function metKcal(a: Activity, p: Profile, minutes: number, assumedSpeed: boolean): number {
  const w = p.weightKg && p.weightKg > 0 ? p.weightKg : 75
  const dist = num(a.distKm), spd = num(a.speedKmh)
  const v = spd != null && spd > 0 ? spd : assumedSpeed ? 25 : dist != null && dist > 0 && minutes > 0 ? dist / (minutes / 60) : 0
  const met = a.sport === 'kolo' ? (v < 20 ? 6 : v < 26 ? 8 : 10)
    : a.sport === 'tek' ? 9.5 : a.sport === 'pohod' ? 4.5 : a.sport === 'moc' ? 4 : a.sport === 'plavanje' ? 7 : 5
  let k = met * w * (minutes / 60)
  if (a.avgHr && p.maxHr && a.avgHr > 0 && p.maxHr > 0) k *= Math.max(0.7, Math.min(1.3, (a.avgHr / p.maxHr) / 0.72))
  return Math.max(0, k)
}

/** Ocena porabe aktivnosti: kcal iz naprave (preverjene po trajanju), sicer MET ocena; trajanje tudi iz časa s postanki ali razdalje. */
export function activityKcal(a: Activity, p: Profile): number {
  const minutes = activityMinutes(a)
  const measured = num(a.durationMin) != null && a.durationMin! > 0 ? a.durationMin! : num(a.elapsedMin) != null && a.elapsedMin! > 0 ? a.elapsedMin! : null
  if (num(a.kcal) != null && a.kcal! > 0) return plausibleKcal(a.kcal!, measured ?? minutes)
  if (minutes == null) return 0
  return Math.round(metKcal(a, p, minutes, measured == null))
}

/**
 * Ali je poraba aktivnosti zanesljiva za zamenjavo načrta: kcal iz naprave, ki niso bile odrezane na verjetno
 * mejo in niso nesmiselno nizke (pod četrtino MET ocene), ali MET ocena iz izmerjenega trajanja.
 * Brez trajanja in brez kcal (samo razdalja ali nič) poraba ni znana.
 */
function burnReliable(a: Activity, p: Profile): boolean {
  const measured = num(a.durationMin) != null && a.durationMin! > 0 ? a.durationMin! : num(a.elapsedMin) != null && a.elapsedMin! > 0 ? a.elapsedMin! : null
  const k = num(a.kcal)
  if (k != null && k > 0) {
    if (measured == null) return true
    if (k > (measured / 60) * MAX_KCAL_PER_HOUR + 100) return false
    return k >= 0.25 * metKcal(a, p, measured, false)
  }
  return measured != null
}

export interface DailyTarget {
  /** cilj vnosa za danes */
  kcal: number
  /** vzdrževanje brez treninga */
  maintenance: number
  /** poraba današnjih aktivnosti (dejanska, izmerjena) */
  burn: number
  /** načrtovana poraba treningov, ki še niso izmerjeni (dokler vožnja ne pride z Garmina) */
  plannedBurn: number
  /** kaj je načrt predvidel za treninge, ki so že izmerjeni (za »načrt 1010 → izmerjeno 1230«) */
  plannedWas: number
  /** spodnja varna meja */
  floor: number
  proteinG: number
  carbsG: number
  fatG: number
  /** je cilj kdaj pritisnjen na dno? (za UI »Varno« / opozorilo) */
  clampedToFloor: boolean
  minor: boolean
  /** deficit, uporabljen za ta dan (po fazi in vrsti dneva) */
  deficit: number
  deficitNote: string | null
  /** ocena za opravljen trening brez zanesljive porabe (brez kcal in trajanja): dopolnjeno do načrtovane porabe */
  estimatedBurn?: number
  /** kcal, dodane za OH pred tekmo (8 g na kg 2 dni pred tekmo ≥ 150 min, 5 g na kg dan pred tekmo ≥ 90 min) */
  carbLoad?: number
  /** ročni cilj danes ne velja (tekma, tapering, polnjenje z OH) — velja osnova brez deficita */
  overrideOff?: boolean
  /** načrtovana poraba seje, ki je ni bilo (dan mimo ali pozno zvečer) — ne šteje več v cilj */
  plannedDropped?: number
}

/**
 * Dnevni cilj: vzdrževanje brez treninga − deficit + trening tistega dne. Prilagaja se čez dan:
 *  - trening = IZMERJENA poraba vseh današnjih aktivnosti (tudi nenačrtovanih)
 *    + NAČRTOVANA poraba treningov, ki še niso izmerjeni (tudi če si pritisnil »Opravil«, vožnja pa še ni prišla),
 *  - ko vožnja pride z Garmina, načrt zamenja izmerjeno: porabil več → cilj gor, manj → dol.
 *    Načrtovana seja je samo aktivnost iste vrste z vsaj pol načrtovanega trajanja (matchesPlanned); krajša
 *    (vožnja v službo pred dolgo vožnjo) šteje sproti, načrt pa ostane za razliko — cilj ne pade.
 *    Brez znane porabe (ni kcal ne trajanja) šteje vsaj načrt.
 *  - načrtovana seja, ki je ni bilo, šteje le, dokler se še lahko zgodi: pretekli dan ne več, danes do 21. ure
 *    (sicer bi bil včerajšnji cilj in graf zadnjih 7 dni napihnjen za trening, ki ga ni bilo).
 * Na dan treninga je zato cilj VIŠJI že zjutraj — gorivo pride pred vožnjo, ne po njej.
 * Brez stropa treninga: 5-urna vožnja z 2800 kcal šteje vse (sicer bi deficit prebil mejo 750).
 * Varovalke: nikoli pod BMR in 1500/1200 kcal, deficit največ 750, mladoletni brez deficita, trening se nikoli ne krči.
 */
/** Do te ure dneva šteje načrtovani trening, ki še ni narejen (zvečer ga ni več smiselno čakati). */
export const PLANNED_UNTIL_HOUR = 21
/** Ali za dan še šteje načrtovana (nenarejena) seja: pretekli dan ne, danes do 21. ure, prihodnji dnevi vedno. */
export function plannedStillCounts(day: string, today: string, hour: number): boolean {
  return day > today || (day === today && hour < PLANNED_UNTIL_HOUR)
}

export function dailyTarget(p: Profile, todaysActivities: readonly Activity[], todaysPlan: readonly PlanDay[], date?: string, opts?: { today?: string; hour?: number }): DailyTarget | null {
  const base = tdee(p)
  if (base == null) return null
  const b = bmr(p)!
  const day = date || todaysPlan[0]?.date || todaysActivities[0]?.date || todayIso()
  const today = opts?.today ?? todayIso()
  const hour = opts?.hour ?? new Date().getHours()
  // včerajšnji trening, ki ga ni bilo, ne šteje več; danes zvečer prav tako ne (cilj se vrne na dan brez treninga)
  const plannedOk = plannedStillCounts(day, today, hour)
  const kcalOf = (a: Activity) => activityKcal(a, p)
  const burn = todaysActivities.reduce((s, a) => s + kcalOf(a), 0)
  const byId = new Map(todaysActivities.map(a => [a.id, a] as const))
  const linked = new Set(todaysPlan.map(d => d.done?.activityId).filter((x): x is string => !!x))
  const free = todaysActivities.filter(a => !linked.has(a.id))
  const used = new Set<string>()
  const est = (d: PlanDay) => (d.kcalBurn != null && Number.isFinite(d.kcalBurn) && d.kcalBurn > 0 ? d.kcalBurn : estimatePlanKcal(d, p))
  const gap = (a: Activity, d: PlanDay) => { const m = activityMinutes(a); return m == null ? 0 : Math.abs(m - (d.durationMin || 0)) }
  let plannedBurn = 0, plannedWas = 0, estimatedBurn = 0, plannedDropped = 0
  const waiting: PlanDay[] = []
  for (const d of todaysPlan) {
    if (d.optional || d.kind === 'pocitek') continue
    const e = est(d)
    // izmerjeno: povezana aktivnost, sicer ista vrsta z vsaj pol načrtovanega trajanja (najbližja) — vožnja je tu, le še ni povezana
    const a = (d.done?.activityId ? byId.get(d.done.activityId) : undefined)
      ?? free.filter(x => !used.has(x.id) && matchesPlanned(x, d)).sort((x, y) => gap(x, d) - gap(y, d))[0]
    if (a) {
      used.add(a.id); plannedWas += e
      if (!burnReliable(a, p)) estimatedBurn += Math.max(0, e - kcalOf(a))
      continue
    }
    waiting.push(d)
  }
  // še pride (ali opravljeno brez ure): krajše aktivnosti iste vrste štejejo sproti, načrt ostane za razliko (nič dvakrat)
  for (const d of waiting) {
    const part = free.filter(x => !used.has(x.id) && sameKind(x, d))
    for (const x of part) used.add(x.id)
    const left = Math.max(0, est(d) - part.reduce((s, x) => s + kcalOf(x), 0))
    // ročno »Opravil« brez ure: trening je bil, poraba po načrtu (kadar koli); sicer načrt šteje le, dokler se seja še lahko zgodi
    if (d.done) estimatedBurn += left
    else if (plannedOk) plannedBurn += left
    else plannedDropped += left
  }
  const dd = dayDeficit(p, todaysPlan, day)
  const deficit = Math.min(MAX_DEFICIT, Math.max(0, dd.kcal))
  const minor = isMinor(p)
  const training = Math.max(0, burn) + plannedBurn + estimatedBurn
  // ročni cilj: na dan brez deficita (tekma, tapering, polnjenje z OH) ne velja, če je pod vzdrževanjem
  const ov = p.kcalOverride && p.kcalOverride > 0 && !minor ? p.kcalOverride : null
  const off = ov != null && ov < base ? noDeficitDay(p, day) : null
  let target = (ov != null ? (off ? base : ov) : base - deficit) + training
  const floorAbs = p.sex === 'z' ? MIN_ABS_Z : MIN_ABS_M
  // tla: nikoli pod BMR, nikoli pod 1500/1200, ob treningu vsaj BMR + pol porabe,
  // tudi ročni cilj ne sme preseči stropa deficita (750 pod dnevno porabo), mladoletni nikoli pod vzdrževanjem
  const floor = Math.round(Math.max(b, floorAbs, training > 0 ? b + training / 2 : 0, base + training - MAX_DEFICIT, minor ? base + training : 0))
  const clamped = target < floor
  if (clamped) target = floor
  target = Math.round(target)
  const w = p.weightKg!
  const gkg = p.proteinGkg && p.proteinGkg >= 1.2 && p.proteinGkg <= 2.6 ? p.proteinGkg : (p.goal === 'shujsati' || goalDeficit(p, day) > 0 ? 2.0 : 1.7)
  const proteinG = Math.round(w * gkg)
  const fatG = Math.round(Math.max(0.7 * w, (target * 0.25) / 9))
  let carbsG = Math.max(0, Math.round((target - proteinG * 4 - fatG * 9) / 4))
  // pred tekmo: OH vsaj 8 g na kg (2 dni pred tekmo ≥ 150 min) ali 5 g na kg (dan pred tekmo ≥ 90 min); kalorije gor, nič dol
  let carbLoad = 0
  const rc = raceCarbs(p, day)
  if (rc) {
    const want = Math.round(rc.gkg * w)
    if (want > carbsG) {
      carbsG = want
      const need = proteinG * 4 + fatG * 9 + carbsG * 4
      if (need > target) { carbLoad = need - target; target = need }
    }
  }
  return { kcal: target, maintenance: base, burn, plannedBurn, plannedWas, floor, proteinG, carbsG, fatG, clampedToFloor: clamped, minor, deficit, deficitNote: off ?? dd.note, estimatedBurn, carbLoad, overrideOff: !!off, plannedDropped }
}

/** Kako je cilj sestavljen — v eni vrstici (za Prehrano in Danes). */
export function targetParts(t: DailyTarget, p: Pick<Profile, 'kcalOverride'>): string {
  const f = (n: number) => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '\u202F')   // kot fmtKcal
  const own = !!p.kcalOverride && !t.minor
  const bits = [own && !t.overrideOff ? `tvoj cilj ${f(p.kcalOverride!)}` : `osnova ${f(t.maintenance)}${t.deficit ? ` − deficit ${f(t.deficit)}` : ''}${own && t.overrideOff ? ` (tvoj cilj ${f(p.kcalOverride!)} danes ne velja)` : ''}`]
  if (t.burn) {
    const d = t.plannedWas ? t.burn - t.plannedWas : 0
    bits.push(`trening ${f(t.burn)} izmerjeno${t.plannedWas && Math.abs(d) >= 50 ? ` (načrt ${f(t.plannedWas)}, ${d > 0 ? '+' : '−'}${f(Math.abs(d))})` : ''}`)
  }
  if (t.plannedBurn) bits.push(`trening ~${f(t.plannedBurn)} po načrtu — popravim, ko vožnja pride z Garmina`)
  if (t.estimatedBurn) bits.push(`trening ~${f(t.estimatedBurn)} po načrtu (vožnja nima podatka o porabi)`)
  if (t.plannedDropped && !t.burn && !t.plannedBurn && !t.estimatedBurn) bits.push(`trening 0 (načrtovanih ~${f(t.plannedDropped)} ni bilo zabeleženih)`)
  if (t.carbLoad) bits.push(`polnjenje z OH ${f(t.carbLoad)}`)
  return bits.join(' + ') + (t.clampedToFloor ? ' → dvignjeno na varno mejo' : '')
}

/** Ocena porabe načrtovane seje: iz FTP (kJ ≈ kcal pri ~24 % izkoristku), sicer MET. Nikoli negativna. */
export function estimatePlanKcal(d: PlanDay, p: Profile): number {
  const min = Number.isFinite(d.durationMin) && d.durationMin > 0 ? d.durationMin : 0
  const w = p.weightKg && p.weightKg > 0 ? p.weightKg : 75, h = min / 60
  if ((d.kind === 'kolo' || d.kind === 'test') && p.ftp && p.ftp > 0) {
    const IF: Record<string, number> = { Z1: 0.5, Z2: 0.65, Z3: 0.75, Z4: 0.78, Z5: 0.74, test: 0.8, dirka: 0.72 }
    return Math.round(p.ftp * (IF[d.zone || 'Z2'] ?? 0.65) * min * 0.06)
  }
  const met = d.kind === 'kolo' || d.kind === 'test' ? (/Z[4-5]|test|dirka/.test(d.zone || '') ? 9 : d.zone === 'Z1' ? 4.5 : 7) : d.kind === 'tek' ? 9.5 : d.kind === 'pohod' ? 4.5 : d.kind === 'moc' ? 4 : 0
  return Math.round(met * w * h)
}

export function sumMeals(m: readonly MealEntry[]) {
  return m.reduce((s, e) => ({ kcal: s.kcal + (e.kcal || 0), p: s.p + (e.proteinG || 0), c: s.c + (e.carbsG || 0), f: s.f + (e.fatG || 0) }), { kcal: 0, p: 0, c: 0, f: 0 })
}

/** Ali je cilj (kg/teden) prehiter za varno pot — če ja, povemo naravnost, ne klampamo tiho. */
export function lossTooFast(kgPerWeek: number): boolean { return kgPerWeek > MAX_WEEKLY_LOSS_KG }

/** Pravila za vsak prehranski AI poziv — dobesedno, ker se nanje zanaša vsaka številka. */
export const NUTRITION_RULES = `PRAVILA PREHRANE (zavezujoča):
- Nikoli ne predlagaj manj hrane od dnevnega cilja, ki ga dobiš kot številko.
- Vnos ni odvisen od forme (TSB), svežine ali oblike telesa. Ne povezuj ga z njimi.
- Brez preskakovanja obrokov, posta ali prenašanja kalorij med dnevi.
- Če je želena izguba teže nad 0,5 kg na teden, to pove uporabniku in priporoči zdravnika.
- Mladoletnim ne predlagaj deficita.
- Deficit nikoli na kolesu: na vožnjah nad 90 min 40–60 g OH na uro (Z2), 60–80 g na uro (intervali, dirka).`

/* ====================================================================
   TEŽA — trend iz jutranjih tehtanj (checkins). Šteje 7-dnevno povprečje.
   ==================================================================== */
export interface WeightTrend { last: number; lastDate: string; avg7: number; deltaWeek: number | null; first: { kg: number; date: string }; n: number }
export function weightTrend(checkins: readonly { date: string; weightKg?: number | null }[]): WeightTrend | null {
  const t = checkins.filter(c => c.weightKg && c.weightKg > 30).map(c => ({ date: c.date, kg: c.weightKg as number })).sort((a, b) => a.date.localeCompare(b.date))
  if (!t.length) return null
  const last = t[t.length - 1]!
  const days = (a: string, b: string) => Math.round((new Date(b).getTime() - new Date(a).getTime()) / 86400_000)
  const w0 = t.filter(x => days(x.date, last.date) <= 6), w1 = t.filter(x => days(x.date, last.date) >= 7 && days(x.date, last.date) <= 13)
  const avg = (a: { kg: number }[]) => a.reduce((s, x) => s + x.kg, 0) / a.length
  return { last: last.kg, lastDate: last.date, avg7: +avg(w0).toFixed(1), deltaWeek: w1.length ? +(avg(w0) - avg(w1)).toFixed(2) : null, first: t[0]!, n: t.length }
}

/* ====================================================================
   GORIVO za današnjo sejo — pred / med / po. Deterministično.
   ==================================================================== */
export interface Fueling { before: string; during: string; after: string }
export function fueling(d: Pick<PlanDay, 'kind' | 'durationMin' | 'zone'> & { role?: PlanDay['role']; raceId?: string | null } | null, p: Pick<Profile, 'weightKg'>): Fueling | null {
  if (!d || d.kind === 'pocitek') return null
  const w = p.weightKg || 75, t = d.durationMin || 0
  const hard = d.role === 'kljucna' || d.role === 'test' || d.role === 'dirka' || /Z[4-5]|test|dirka/.test(d.zone || '')
  if (d.kind === 'moc') return { before: 'Nič posebnega — lahko takoj po kolesu.', during: 'Voda.', after: `${Math.round(w * .3)}–${Math.round(w * .4)} g beljakovin v eni uri (skuta, jajca, jogurt, piščanec).` }
  if (d.role === 'dirka') {
    // polnjenje z OH (8–10 g na kg, 2 dni) samo pred tekmo ≥ 150 min; ≥ 90 min dan prej več OH in na kolesu 60+ g na uro;
    // kratka tekma (kronometer 30 min): normalen dan, na kolesu največ 30–60 g na uro. Druga tekma (raceId) ima manj goriva.
    const other = !!d.raceId, g = (k: number) => Math.round(w * k)
    const before = t >= CARB_LOAD_MIN
      ? `Dan prej in dva dni prej 8–10 g OH na kg (${g(8)}–${g(10)} g): riž, testenine, kruh, sok, malo vlaknin. Zajtrk ${other ? '2–3' : '3'} h pred startom: ${g(2)}–${g(3)} g OH, malo vlaknin in maščob.`
      : t >= RACE_FUEL_MIN
      ? `Dan prej več ogljikovih hidratov: ${g(5)}–${g(7)} g (riž, testenine, kruh). Zajtrk 2–3 h pred startom: ${g(2)} g OH, malo vlaknin in maščob.`
      : `Dan prej normalno — za tako kratko tekmo polnjenje z OH ni potrebno. Zajtrk 2–3 h pred startom: ${g(1)}–${g(2)} g OH, malo vlaknin in maščob.`
    const during = t >= RACE_FUEL_MIN
      ? other ? '60–90 g OH na uro od 30. minute (samo preizkušeno) · 500–750 ml na uro, ob vročini elektroliti.'
        : `${t >= CARB_LOAD_MIN ? '80–90 g OH na uro od prve ure' : '60–80 g OH na uro od 30. minute'} (geli, izotonik, ploščice — samo preizkušeno) · 500–750 ml na uro z elektroliti.`
      : `Največ 30–60 g OH na uro (izotonik ali gel)${t < 60 ? ' — pri tako kratki tekmi je dovolj nekaj požirkov izotonika' : ''} · 500–750 ml na uro.`
    const after = other
      ? `V eni uri ${g(0.3)}–${g(0.4)} g beljakovin + ~${g(1)} g OH (1 g na kg). Kalorije tekme so v dnevnem cilju.`
      : `V eni uri ${g(0.3)}–${g(0.4)} g beljakovin + ${g(1)}–${g(1.2)} g OH. Uživaj.`
    return { before, during, after }
  }
  if (t < 60) return { before: 'Nič posebnega; če si lačen, banana.', during: 'Voda, 500 ml.', after: `Normalen obrok z ${Math.round(w * .3)} g beljakovin.` }
  const oh = t < 90 ? (hard ? '30–60 g' : '0–30 g') : hard ? '60–80 g' : '40–60 g'
  return {
    before: t >= 120 || hard ? `1–2 h prej ${Math.round(w)}–${Math.round(w * 1.5)} g ogljikovih hidratov (kosmiči, kruh, banana), malo maščob. Ne treniraj lačen.` : '1 h prej lahek OH prigrizek (banana, kruh z medom).',
    during: `${oh} ogljikovih hidratov na uro${hard ? ' — intervali brez sladkorja ne gredo' : ' od prve ure'} (banana, ploščica, gel, izotonik) · 500–750 ml na uro, ob vročini elektroliti. Deficit nikoli na kolesu.`,
    after: `V 45 min: ${Math.round(w * .3)}–${Math.round(w * .4)} g beljakovin + ${Math.round(w * .8)}–${Math.round(w)} g ogljikovih hidratov. Kalorije vožnje so že v dnevnem cilju.`,
  }
}
