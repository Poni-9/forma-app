import { inSick } from '../training/sick'
import { inPause } from '../training/pause'
import { g as gx } from '../../ui/gender'
import type { Activity, MealEntry, PlanDay, Profile } from '../types'
import { weekContext, raceBreakfast, raceBreakfastGkg } from '../training/planner'
import { weekStartIso, todayIso } from '../training/load'
import { raceMinutes, plannedRaceMinutes } from '../training/season'
import { activityMinutes, matchesPlanned, sameKind, swapsPlanned } from '../training/plandays'
import { targetWeightOf, adultKnown, healthyTargetWeight } from './body'
import { planRunMet, runMetBySpeed } from './met'
import { mealScheduleOf, runFuel } from './dayplan'
import { fuelGph, SHORT_RACE_FUEL } from './fuelrate'
import { exclusionsOf, foodOk, type Contains } from './recipes'

/* ====================================================================
   VAROVALKE — omejitve so v aritmetiki, ne v promptu.
   Prompt ne more popraviti številke, ki jo model dobi kot dejstvo.
   ==================================================================== */
export const MAX_DEFICIT = 750          // kcal/dan pod vzdrževanjem — več ni varno brez nadzora
export const MAX_ADJ_DOWN = -400        // (zgodovinsko) največ, kar je trening smel znižati cilj — ne velja več
/** Največ verjetne porabe na uro aktivnosti (napaka naprave ali uvoza, npr. 5000 kcal v 1 h) — ni omejitev treninga. */
export const MAX_KCAL_PER_HOUR = 1100
export const MIN_ABS_M = 1500           // absolutno dno (moški)
export const MIN_ABS_Z = 1200           // absolutno dno (ženske)
export const MAX_WEEKLY_LOSS_KG = 0.5   // nad tem: napotitev k zdravniku

export function profileComplete(p: Pick<Profile, 'weightKg' | 'heightCm' | 'age' | 'sex'>): boolean {
  return !!(p.weightKg && p.heightCm && p.age && p.sex)
}
export function isMinor(p: Pick<Profile, 'age'>): boolean { return !!p.age && p.age < 18 }

/** Mifflin-St Jeor. Vrne null, če profil ni popoln — nikoli ne ugibamo. */
export function bmr(p: Pick<Profile, 'weightKg' | 'heightCm' | 'age' | 'sex'>): number | null {
  if (!profileComplete(p)) return null
  const base = 10 * p.weightKg! + 6.25 * p.heightCm! - 5 * p.age!
  return Math.round(p.sex === 'm' ? base + 5 : base - 161)
}

/** Faktor aktivnosti iz tedenskih ur (brez treninga — tega dodamo dnevno posebej). */
export function activityFactor(hoursPerWeek?: number | null): number {
  const h = hoursPerWeek || 0
  return h <= 2 ? 1.35 : h <= 5 ? 1.45 : h <= 9 ? 1.55 : 1.65
}

/** Faktor gibanja IZVEN treninga (1,3 sedeče · 1,4 zmerno · 1,5 veliko hoje). Trening se prišteje dnevno. */
/** Beljakovine na kg, ki veljajo: vpisane ali privzete (2,0 pri hujšanju ali deficitu, sicer 1,7). (v3.50) za čip v Nastavitvah. */
export function proteinGkgOf(p: Profile, day: string = todayIso()): number {
  // (v3.51) 2,0 samo, ko deficit res je (mladoletni s ciljem »shujšati« je brez deficita — prej 2,0 g na kg)
  return p.proteinGkg && p.proteinGkg >= 1.2 && p.proteinGkg <= 2.6 ? p.proteinGkg : ((p.goal === 'shujsati' && adultKnown(p)) || goalDeficit(p, day) > 0 ? 2.0 : 1.7)
}
export function neatFactor(p: Pick<Profile, 'neat'>): number {
  return p.neat && p.neat >= 1.2 && p.neat <= 1.6 ? p.neat : 1.4
}

/** Vzdrževanje BREZ treninga: BMR × gibanje izven treninga. */
export function tdee(p: Profile): number | null {
  const b = bmr(p)
  if (b == null) return null
  return Math.round(b * neatFactor(p))
}

/** Ciljni deficit: nastavljen (300/500/750) ali 500 pri cilju »shujšati«. Mladoletni: 0 — vedno vzdrževanje. */
export function goalDeficit(p: Profile, date: string = todayIso()): number {
  // (v3.50) brez vpisane starosti tudi brez deficita (prej le pod 18 let)
  if (!adultKnown(p)) return 0
  // na najboljši teži (ali pod njo): vzdrževanje — hujšanje ni več cilj, cilj so vati
  const tw = targetWeightOf(p, date)
  if (tw && p.weightKg && p.weightKg <= tw) return 0
  if (p.deficit != null && p.deficit > 0) return Math.min(MAX_DEFICIT, Math.round(p.deficit))
  if (p.goal === 'shujsati') return 500
  return 0
}

/* ---------- tekme: polnjenje z OH in dnevi brez deficita ---------- */
const DAY_MS = 86_400_000
const dayDiff = (from: string, to: string) => Math.round((Date.parse(to + 'T12:00:00Z') - Date.parse(from + 'T12:00:00Z')) / DAY_MS)
/** Dolga tekma (≥ 150 min): 2 dni prej polnjenje z OH 8–10 g na kg. */
export const CARB_LOAD_MIN = 150
/** Tekma ≥ 90 min: dan prej več OH (5–7 g na kg) in na kolesu vsaj 60 g OH na uro. */
export const RACE_FUEL_MIN = 90

function racesOf(p: Pick<Profile, 'event' | 'races'> & Partial<Pick<Profile, 'ftp' | 'weightKg'>>): { name: string; date: string; min: number }[] {
  const out: { name: string; date: string; min: number }[] = []
  if (p.event?.date) out.push({ name: p.event.name, date: p.event.date, min: raceMinutes(p.event, p) })
  // trajanje kot v načrtu (druga tekma brez dolžine = 2 h), da prehrana in načrt govorita isto
  for (const r of p.races || []) if (r?.date && r.date !== p.event?.date) out.push({ name: r.name, date: r.date, min: plannedRaceMinutes(p, r) })
  return out
}

/**
 * OH pred tekmo za ta dan: 2 dni pred tekmo ≥ 150 min polnjenje 8 g na kg (spodnja meja 8–10 g),
 * dan pred tekmo 90–150 min 5 g na kg (spodnja meja 5–7 g). Kratke tekme (kronometer 30 min): normalen dan.
 */
export function raceCarbs(p: Pick<Profile, 'event' | 'races'> & Partial<Pick<Profile, 'ftp' | 'weightKg'>>, date: string): { gkg: number; race: string; inDays: number; load: boolean } | null {
  let best: { gkg: number; race: string; inDays: number; load: boolean } | null = null
  for (const r of racesOf(p)) {
    const d = dayDiff(date, r.date)
    const gkg = (d === 1 || d === 2) && r.min >= CARB_LOAD_MIN ? 8 : d === 1 && r.min >= RACE_FUEL_MIN ? 5 : 0
    if (gkg && (!best || gkg > best.gkg)) best = { gkg, race: r.name, inDays: d, load: gkg >= 8 }
  }
  return best
}

/**
 * Dan brez deficita (tudi ročni cilj ne velja): tapering in teden cilja sezone, dan pred tekmo in dan tekme,
 * polnjenje z OH 2 dni pred dolgo tekmo. Vrne razlog za prikaz ali null.
 */
export function noDeficitDay(p: Profile, date: string): string | null {
  // (v3.50) razlog brez »brez deficita« na koncu — zaslon ga pove sam (»Brez deficita: dan dirke.«; prej »… pred dirko
  // brez deficita.« tudi na dan dirke in podvojeno)
  // (v3.51) premor z razlogom »bolan« je bolezen kot »Bolan sem« (prej je ostal deficit)
  if (inSick(p, date) || (inPause(p, date) && p.weekPause?.reason === 'bolan')) return 'bolezen'
  const ctx = weekContext(p, weekStartIso(date))
  if (ctx.phase === 'tapering') return 'pred dirko (tapering)'
  if (ctx.phase === 'dirka') return ctx.event && date === ctx.event.date ? 'dan dirke' : ctx.event && date > ctx.event.date ? 'teden dirke' : 'pred dirko'
  // druga tekma: dan prej (polnjenje z OH) in na dan tekme brez deficita — ne glede na dolžino tekme
  // (v3.48: malo vlaknin je po dolžini, raceSoon; deficit pa ostane izklopljen kot prej)
  const near = racesOf(p).map(r => dayDiff(date, r.date)).filter(d => d === 0 || d === 1).sort((a, b) => a - b)[0]
  if (near != null) return near ? 'dan pred tekmo' : 'dan tekme'
  const rc = raceCarbs(p, date)
  if (rc?.load) return 'polnjenje z OH pred tekmo'
  return null
}

/**
 * Deficit za konkreten dan: v specifični fazi polovica, v taperingu in tednu dirke nič;
 * na dan ključne seje, testa ali dolge vožnje (≥ 3 h) polovica — kakovost treninga je pomembnejša od grama.
 */
export function dayDeficit(p: Profile, todaysPlan: readonly PlanDay[], date: string): { kcal: number; note: string | null } {
  const full = Math.min(MAX_DEFICIT, goalDeficit(p, date))
  // (v3.51) razlog po vrsti cilja: zdrav prvi mejnik (−10 %) ni »najboljša teža«
  if (!full) { const tw = targetWeightOf(p, date); return { kcal: 0, note: tw && p.weightKg && p.weightKg <= tw ? (p.targetWeightKg ? 'ciljna teža je dosežena, zdaj vzdrževanje' : tw === healthyTargetWeight(p) ? 'prvi mejnik teže je dosežen, zdaj vzdrževanje — nov cilj nastaviš v Nastavitvah' : 'si na najboljši teži, zato vzdrževanje') : null } }
  const protect = noDeficitDay(p, date)
  if (protect) return { kcal: 0, note: protect }
  const ph = weekContext(p, weekStartIso(date)).phase
  let k = ph === 'specificno' ? full * 0.5 : full, note: string | null = ph === 'specificno' ? 'specifična faza, zato pol' : null
  const hardDay = todaysPlan.some(d => !d.optional && (d.role === 'kljucna' || d.role === 'test' || d.role === 'dirka'))
  const longDay = todaysPlan.some(d => !d.optional && d.role === 'dolga' && d.durationMin >= 180)
  if (hardDay || longDay) { k *= 0.5; note = hardDay ? 'ključni trening, zato pol' : 'dolga vožnja, zato pol' }
  return { kcal: Math.round(k / 10) * 10, note }
}

/** Brez znanega trajanja je strop le proti tipkarski napaki (10 h × 1100 kcal), ne ocena ure. */
const MAX_KCAL_UNKNOWN_DURATION = 10 * MAX_KCAL_PER_HOUR + 100
const num = (x: unknown): number | null => (typeof x === 'number' && Number.isFinite(x) ? x : null)

/**
 * Poraba, ki je še verjetna za tako dolgo aktivnost (brez tega bi napaka naprave napihnila cilj).
 * Negativno ali neveljavno = 0. Brez znanega trajanja ne omejujemo po uri (5-urna vožnja brez trajanja ni 1 ura).
 */
export function plausibleKcal(kcal: number, minutes: number | null | undefined): number {
  const k = num(kcal)
  if (k == null || k <= 0) return 0
  const m = num(minutes)
  if (m == null || m <= 0) return Math.round(Math.min(k, MAX_KCAL_UNKNOWN_DURATION))
  const h = Math.max(0.25, m / 60)
  return Math.round(Math.min(k, h * MAX_KCAL_PER_HOUR + 100))
}

/**
 * MET ocena za dano trajanje (min). Hitrost: izmerjena, sicer razdalja / izmerjeno trajanje;
 * če je trajanje izračunano iz razdalje (assumedSpeed), tipična hitrost 25 km/h.
 */
function metKcal(a: Activity, p: Profile, minutes: number, assumedSpeed: boolean): number {
  const w = p.weightKg && p.weightKg > 0 ? p.weightKg : 75
  const dist = num(a.distKm), spd = num(a.speedKmh)
  const v = spd != null && spd > 0 ? spd : assumedSpeed ? 25 : dist != null && dist > 0 && minutes > 0 ? dist / (minutes / 60) : 0
  // (v3.49) tek po hitrosti (prej vedno 9,5 MET); vzpon šteje kot ravnina (100 m ≈ 1 km), sicer je tek v hribe »počasen«
  const climb = Math.max(0, num(a.elevM) ?? 0) / 100
  const runV = assumedSpeed ? null : dist != null && dist > 0 && minutes > 0 ? (dist + climb) / (minutes / 60) : spd != null && spd > 0 ? spd : null
  const met = a.sport === 'kolo' ? (v < 20 ? 6 : v < 26 ? 8 : 10)
    : a.sport === 'tek' ? runMetBySpeed(runV) : a.sport === 'pohod' ? 4.5 : a.sport === 'moc' ? 4 : a.sport === 'plavanje' ? 7 : 5
  let k = met * w * (minutes / 60)
  if (a.avgHr && p.maxHr && a.avgHr > 0 && p.maxHr > 0) k *= Math.max(0.7, Math.min(1.3, (a.avgHr / p.maxHr) / 0.72))
  return Math.max(0, k)
}

/** Ocena porabe aktivnosti: kcal iz naprave (preverjene po trajanju), sicer MET ocena; trajanje tudi iz časa s postanki ali razdalje. */
export function activityKcal(a: Activity, p: Profile): number {
  const minutes = activityMinutes(a)
  const measured = num(a.durationMin) != null && a.durationMin! > 0 ? a.durationMin! : num(a.elapsedMin) != null && a.elapsedMin! > 0 ? a.elapsedMin! : null
  if (num(a.kcal) != null && a.kcal! > 0) return plausibleKcal(a.kcal!, measured ?? minutes)
  if (minutes == null) return 0
  return Math.round(metKcal(a, p, minutes, measured == null))
}

/**
 * Ali je poraba aktivnosti zanesljiva za zamenjavo načrta: kcal iz naprave, ki niso bile odrezane na verjetno
 * mejo in niso nesmiselno nizke (pod četrtino MET ocene), ali MET ocena iz izmerjenega trajanja.
 * Brez trajanja in brez kcal (samo razdalja ali nič) poraba ni znana.
 */
function burnReliable(a: Activity, p: Profile): boolean {
  const measured = num(a.durationMin) != null && a.durationMin! > 0 ? a.durationMin! : num(a.elapsedMin) != null && a.elapsedMin! > 0 ? a.elapsedMin! : null
  const k = num(a.kcal)
  if (k != null && k > 0) {
    if (measured == null) return true
    if (k > (measured / 60) * MAX_KCAL_PER_HOUR + 100) return false
    return k >= 0.25 * metKcal(a, p, measured, false)
  }
  return measured != null
}

export interface DailyTarget {
  /** cilj vnosa za danes */
  kcal: number
  /** vzdrževanje brez treninga */
  maintenance: number
  /** poraba današnjih aktivnosti (dejanska, izmerjena) */
  burn: number
  /** načrtovana poraba treningov, ki še niso izmerjeni (dokler vožnja ne pride z Garmina) */
  plannedBurn: number
  /** kaj je načrt predvidel za treninge, ki so že izmerjeni (za »načrt 1010 → izmerjeno 1230«) */
  plannedWas: number
  /** spodnja varna meja */
  floor: number
  proteinG: number
  carbsG: number
  fatG: number
  /** je cilj kdaj pritisnjen na dno? (za UI »Varno« / opozorilo) */
  clampedToFloor: boolean
  minor: boolean
  /** deficit, uporabljen za ta dan (po fazi in vrsti dneva) */
  deficit: number
  deficitNote: string | null
  /** ocena za opravljen trening brez zanesljive porabe (brez kcal in trajanja): dopolnjeno do načrtovane porabe */
  estimatedBurn?: number
  /** kcal, dodane za OH pred tekmo (8 g na kg 2 dni pred tekmo ≥ 150 min, 5 g na kg dan pred tekmo ≥ 90 min) */
  carbLoad?: number
  /** ročni cilj danes ne velja (tekma, tapering, polnjenje z OH) — velja osnova brez deficita */
  overrideOff?: boolean
  /** načrtovana poraba seje, ki je ni bilo (dan mimo ali pozno zvečer) — ne šteje več v cilj (v3.49: brez osnove za njen čas) */
  plannedDropped?: number
  /**
   * (v3.49) osnova za čas treninga: burn, plannedBurn in estimatedBurn so bruto (ura, kJ, MET) in vsebujejo tudi
   * porabo, ki je za tiste minute že v vzdrževanju — v cilj gre trening brez nje (sicer šteje dvakrat)
   */
  restIn?: number
  /** (v3.50) vrste sej dneva (kolo, tek, moč …) — razlaga cilja reče »vožnja« samo, ko so vse na kolesu */
  kinds?: PlanDay['kind'][]
}

/** (v3.49) Trening, ki gre v cilj: bruto poraba brez osnove za čas treninga. */
export function trainingIn(t: Pick<DailyTarget, 'burn' | 'plannedBurn'> & Partial<Pick<DailyTarget, 'estimatedBurn' | 'restIn'>>): number {
  return Math.max(0, t.burn + t.plannedBurn + (t.estimatedBurn || 0) - (t.restIn || 0))
}

/**
 * (v3.49) Teža za beljakovine: pri ITM nad 25 teža pri ITM 25 (prej 2 g na kg celotne teže: 184 g pri 92 kg, pri
 * kolesarki 39 % kalorij). Izmerjena nizka maščoba (mišičast, ne prekomerna teža) ostane cela teža.
 */
export function proteinRefKg(p: Pick<Profile, 'weightKg' | 'heightCm' | 'bodyFatPct' | 'sex'>): number {
  const w = p.weightKg && p.weightKg > 0 ? p.weightKg : 0
  if (!p.heightCm || p.heightCm <= 0) return w
  const bf = p.bodyFatPct
  if (bf != null && bf >= 3 && bf <= (p.sex === 'z' ? 28 : 20)) return w
  return Math.min(w, Math.round(25 * (p.heightCm / 100) ** 2 * 10) / 10)
}

/**
 * Dnevni cilj: vzdrževanje brez treninga − deficit + trening tistega dne. Prilagaja se čez dan:
 *  - trening = IZMERJENA poraba vseh današnjih aktivnosti (tudi nenačrtovanih)
 *    + NAČRTOVANA poraba treningov, ki še niso izmerjeni (tudi če si pritisnil »Opravil«, vožnja pa še ni prišla),
 *  - ko vožnja pride z Garmina, načrt zamenja izmerjeno: porabil več → cilj gor, manj → dol.
 *    Načrtovana seja je samo aktivnost iste vrste z vsaj pol načrtovanega trajanja (matchesPlanned); krajša
 *    (vožnja v službo pred dolgo vožnjo) šteje sproti, načrt pa ostane za razliko — cilj ne pade.
 *    Brez znane porabe (ni kcal ne trajanja) šteje vsaj načrt.
 *  - načrtovana seja, ki je ni bilo, šteje le, dokler se še lahko zgodi: pretekli dan ne več, danes do 21. ure
 *    (sicer bi bil včerajšnji cilj in graf zadnjih 7 dni napihnjen za trening, ki ga ni bilo).
 * Na dan treninga je zato cilj VIŠJI že zjutraj — gorivo pride pred vožnjo, ne po njej.
 * Brez stropa treninga: 5-urna vožnja z 2800 kcal šteje vse (sicer bi deficit prebil mejo 750).
 * Varovalke: nikoli pod BMR in 1500/1200 kcal, deficit največ 750, mladoletni brez deficita, trening se nikoli ne krči.
 */
/** Do te ure dneva šteje načrtovani trening, ki še ni narejen (zvečer ga ni več smiselno čakati). */
export const PLANNED_UNTIL_HOUR = 21
/** (v3.50) kdor trenira zvečer, vozi tudi 20:00–21:30 — njegova seja šteje do 23h (prej je cilj padel sredi vožnje) */
export const PLANNED_UNTIL_EVENING = 23
/** Ali za dan še šteje načrtovana (nenarejena) seja: pretekli dan ne, danes do 21. ure (»treniram zvečer« do 23.), prihodnji dnevi vedno. */
export function plannedStillCounts(day: string, today: string, hour: number, trainTime?: Profile['trainTime']): boolean {
  return day > today || (day === today && hour < (trainTime === 'zvecer' ? PLANNED_UNTIL_EVENING : PLANNED_UNTIL_HOUR))
}

/** (v3.49) Delež opravljenega treninga: dejanske minute (vodena vadba, »Krajše«) proti načrtu; brez njih cel trening (1). */
export function doneShare(d: Pick<PlanDay, 'durationMin' | 'done'>): number {
  const m = d.done?.min
  return m != null && m > 0 && d.durationMin > 0 ? Math.min(2, m / d.durationMin) : 1
}

export function dailyTarget(p: Profile, todaysActivities: readonly Activity[], todaysPlan: readonly PlanDay[], date?: string, opts?: { today?: string; hour?: number }): DailyTarget | null {
  const base = tdee(p)
  if (base == null) return null
  const b = bmr(p)!
  const day = date || todaysPlan[0]?.date || todaysActivities[0]?.date || todayIso()
  const today = opts?.today ?? todayIso()
  const hour = opts?.hour ?? new Date().getHours()
  // včerajšnji trening, ki ga ni bilo, ne šteje več; danes zvečer prav tako ne (cilj se vrne na dan brez treninga)
  const plannedOk = plannedStillCounts(day, today, hour, p.trainTime)
  const kcalOf = (a: Activity) => activityKcal(a, p)
  // (v3.49) zapis iz načrta (»Opravil«, vodena vadba brez ure) ni izmerjen — dan šteje po načrtu in dejanskih minutah
  const acts = todaysActivities.filter(a => !a.planDayId)
  const burn = acts.reduce((s, a) => s + kcalOf(a), 0)
  // (v3.49) poraba treninga je bruto in vsebuje osnovo za tiste minute, ki je v vzdrževanju že šteta (~75–105 kcal na uro)
  const restOf = (kcal: number, min: number | null | undefined) => restDuring(base, kcal, min)
  let restIn = acts.reduce((s, a) => s + restOf(kcalOf(a), activityMinutes(a)), 0)
  const byId = new Map(acts.map(a => [a.id, a] as const))
  const linked = new Set(todaysPlan.map(d => d.done?.activityId).filter((x): x is string => !!x))
  const free = acts.filter(a => !linked.has(a.id))
  const used = new Set<string>()
  const est = (d: PlanDay) => planKcal(d, p)
  const gap = (a: Activity, d: PlanDay) => { const m = activityMinutes(a); return m == null ? 0 : Math.abs(m - (d.durationMin || 0)) }
  let plannedBurn = 0, plannedWas = 0, estimatedBurn = 0, plannedDropped = 0
  const waiting: PlanDay[] = []
  // (v3.51) bolan ali premor brez vseh treningov: nogometa ta dan ni (prej cilj +675 kcal za tekmo, ki je bolan ne igra)
  const noOther = inSick(p, day) || (inPause(p, day) && p.weekPause?.mode === 'vse')
  for (const d of todaysPlan) {
    // (v3.51) dan drugega športa (nogomet) je v načrtu brez treninga, a s porabo (kcalBurn) — šteje
    if (d.optional || (d.kind === 'pocitek' && (!isOtherSportDay(d) || noOther))) continue
    const e = est(d)
    // izmerjeno: povezana aktivnost, sicer ista vrsta z vsaj pol načrtovanega trajanja (najbližja) — vožnja je tu, le še ni povezana
    // (v3.49) »Opravil« brez ure, z ure pa druga vzdržljivostna vadba, ki ustreza dnevu (hribi namesto kolesa): šteje ta —
    // kot pri zapisu iz načrta (realOn), da forma in cilj vidita isto; krajši tek ob vožnji ne (oboje šteje)
    const a = (d.done?.activityId ? byId.get(d.done.activityId) : undefined)
      ?? free.filter(x => !used.has(x.id) && matchesPlanned(x, d)).sort((x, y) => gap(x, d) - gap(y, d))[0]
      ?? (d.done && !d.done.activityId ? free.filter(x => !used.has(x.id) && swapsPlanned(x, d) && !todaysPlan.some(o => o !== d && !o.optional && sameKind(x, o))).sort((x, y) => gap(x, d) - gap(y, d))[0] : undefined)
      // (v3.51) nogomet z ure (šport »drugo«, plavanje) je ta dan drugega športa — prej sta štela oba (+675 kcal)
      ?? (isOtherSportDay(d) ? free.filter(x => !used.has(x.id) && OTHER_SPORTS.has(x.sport)).sort((x, y) => kcalOf(y) - kcalOf(x))[0] : undefined)
    if (a) {
      used.add(a.id); plannedWas += e
      if (!burnReliable(a, p)) { const add = Math.max(0, e - kcalOf(a)); estimatedBurn += add; restIn += restOf(add, planMinOf(d) - (activityMinutes(a) || 0)) }
      continue
    }
    waiting.push(d)
  }
  // še pride (ali opravljeno brez ure): krajše aktivnosti iste vrste štejejo sproti, načrt ostane za razliko (nič dvakrat)
  for (const d of waiting) {
    const part = free.filter(x => !used.has(x.id) && sameKind(x, d))
    for (const x of part) used.add(x.id)
    // (v3.49) delno opravljen (31 od 105 min): poraba po dejanskih minutah, ne za cel trening
    const share = d.done ? doneShare(d) : 1
    const left = Math.max(0, Math.round(est(d) * share) - part.reduce((s, x) => s + kcalOf(x), 0))
    const r = restOf(left, planMinOf(d) * share - part.reduce((s, x) => s + (activityMinutes(x) || 0), 0))
    // ročno »Opravil« brez ure: trening je bil, poraba po načrtu (kadar koli); sicer načrt šteje le, dokler se seja še lahko zgodi
    if (d.done) { estimatedBurn += left; restIn += r }
    else if (plannedOk) { plannedBurn += left; restIn += r }
    else plannedDropped += left - r
  }
  const dd = dayDeficit(p, todaysPlan, day)
  const deficit = Math.min(MAX_DEFICIT, Math.max(0, dd.kcal))
  const minor = isMinor(p)
  restIn = Math.round(restIn)
  const training = trainingIn({ burn: Math.max(0, burn), plannedBurn, estimatedBurn, restIn })
  // ročni cilj: na dan brez deficita (tekma, tapering, polnjenje z OH) ne velja, če je pod vzdrževanjem
  const ov = p.kcalOverride && p.kcalOverride > 0 && !minor ? p.kcalOverride : null
  const off = ov != null && ov < base ? noDeficitDay(p, day) : null
  let target = (ov != null ? (off ? base : ov) : base - deficit) + training
  const floorAbs = p.sex === 'z' ? MIN_ABS_Z : MIN_ABS_M
  // tla: nikoli pod BMR, nikoli pod 1500/1200, ob treningu vsaj BMR + pol porabe,
  // tudi ročni cilj ne sme preseči stropa deficita (750 pod dnevno porabo), mladoletni nikoli pod vzdrževanjem
  const floor = Math.round(Math.max(b, floorAbs, training > 0 ? b + training / 2 : 0, base + training - MAX_DEFICIT, minor ? base + training : 0))
  const clamped = target < floor
  if (clamped) target = floor
  target = Math.round(target)
  const w = p.weightKg!
  const gkg = proteinGkgOf(p, day)
  // (v3.49) beljakovine na ciljno težo pri ITM nad 25; maščobe 25 % kalorij, a največ 1,2 g na kg — na velikih dneh
  // gre energija v OH (prej 127 g maščob na dolgi vožnji, 157 g na Franji)
  const proteinG = Math.round(proteinRefKg(p) * gkg)
  const fatG = Math.round(Math.min(1.2 * w, Math.max(0.7 * w, (target * 0.25) / 9)))
  let carbsG = Math.max(0, Math.round((target - proteinG * 4 - fatG * 9) / 4))
  // pred tekmo: OH vsaj 8 g na kg (2 dni pred tekmo ≥ 150 min) ali 5 g na kg (dan pred tekmo ≥ 90 min); kalorije gor, nič dol
  let carbLoad = 0
  const rc = raceCarbs(p, day)
  if (rc) {
    const want = Math.round(rc.gkg * w)
    if (want > carbsG) {
      carbsG = want
      const need = proteinG * 4 + fatG * 9 + carbsG * 4
      if (need > target) { carbLoad = need - target; target = need }
    }
  }
  // (v3.51) dan nogometa je »trening«, ne »vožnja« (prej »popravim, ko bo vožnja zabeležena«)
  const kinds = [...new Set(todaysPlan.filter(d => !d.optional && (d.kind !== 'pocitek' || (isOtherSportDay(d) && !noOther))).map(d => d.kind))]
  return { kcal: target, maintenance: base, burn, plannedBurn, plannedWas, floor, proteinG, carbsG, fatG, clampedToFloor: clamped, minor, deficit, deficitNote: off ?? dd.note, estimatedBurn, carbLoad, overrideOff: !!off, plannedDropped: Math.round(plannedDropped), restIn, ...(kinds.length ? { kinds } : {}) }
}

/** (v3.51) dan drugega športa (nogomet): počitek iz načrta s porabo (kcalBurn) */
export const isOtherSportDay = (d: Pick<PlanDay, 'kind' | 'kcalBurn'>): boolean => d.kind === 'pocitek' && !!(d.kcalBurn && d.kcalBurn > 0)
/** (v3.51) športi z ure brez vrste v načrtu (nogomet, košarka, plavanje) — dan drugega športa */
const OTHER_SPORTS = new Set<Activity['sport']>(['drugo', 'plavanje'])
/** (v3.51) poraba drugega športa velja za ~90 min (otherSportKcal) — za osnovo med treningom */
export const OTHER_SPORT_MIN = 90
/** (v3.51) minute seje za osnovo med treningom (dan nogometa: 90 min — prej 0, poraba bruto) */
const planMinOf = (d: Pick<PlanDay, 'kind' | 'kcalBurn' | 'durationMin'>): number => (d.durationMin > 0 ? d.durationMin : isOtherSportDay(d) ? OTHER_SPORT_MIN : 0)
/** (v3.49) Osnova (vzdrževanje brez treninga), ki je v minutah treninga že šteta — nikoli več od same porabe. */
export function restDuring(maintenance: number, kcal: number, minutes: number | null | undefined): number {
  return Math.min(Math.max(0, kcal), (maintenance / 1440) * Math.max(0, minutes || 0))
}
/** (v3.49) Bruto poraba načrtovane seje: iz načrta (kcalBurn, npr. tek in hoja po deležu), sicer ocena. */
export function planKcal(d: PlanDay, p: Profile): number {
  return d.kcalBurn != null && Number.isFinite(d.kcalBurn) && d.kcalBurn > 0 ? d.kcalBurn : estimatePlanKcal(d, p)
}
/** (v3.49) Koliko seja doda k cilju: bruto poraba brez osnove za njen čas. */
export function planNetKcal(d: PlanDay, p: Profile): number {
  const g = planKcal(d, p), base = tdee(p)
  return Math.round(base == null ? g : g - restDuring(base, g, planMinOf(d)))
}

/**
 * Kako je cilj sestavljen — v eni vrstici (za Prehrano in Danes).
 * opts.garmin: vožnje pridejo z Garmina (intervals.icu) — samo takrat »popravim, ko vožnja pride z Garmina« (v3.48).
 */
export function targetParts(t: DailyTarget, p: Pick<Profile, 'kcalOverride'>, opts: { garmin?: boolean } = {}): string {
  const f = (n: number) => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '\u202F')   // kot fmtKcal
  const own = !!p.kcalOverride && !t.minor
  const bits = [own && !t.overrideOff ? `tvoj cilj ${f(p.kcalOverride!)}` : `osnova ${f(t.maintenance)}${t.deficit ? ` − deficit ${f(t.deficit)}` : ''}${own && t.overrideOff ? ` (tvoj cilj ${f(p.kcalOverride!)} danes ne velja)` : ''}`]
  if (t.burn) {
    const d = t.plannedWas ? t.burn - t.plannedWas : 0
    bits.push(`trening ${f(t.burn)} izmerjeno${t.plannedWas && Math.abs(d) >= 50 ? ` (načrt ${f(t.plannedWas)}, ${d > 0 ? '+' : '−'}${f(Math.abs(d))})` : ''}`)
  }
  // (v3.50) »vožnja« samo, ko so vse seje dneva na kolesu (tek, pohod, moč: »trening«)
  const bike = !t.kinds?.length || t.kinds.every(k => k === 'kolo' || k === 'test')
  const what = bike ? 'vožnja' : 'trening'
  if (t.plannedBurn) bits.push(`trening ~${f(t.plannedBurn)} po načrtu — ${opts.garmin ? `popravim, ko ${what} pride z Garmina` : `popravim, ko bo ${what} ${bike ? 'zabeležena' : 'zabeležen'}`}`)
  if (t.estimatedBurn) bits.push(`trening ~${f(t.estimatedBurn)} po načrtu (${what} nima podatka o porabi)`)
  // (v3.49) osnova za čas treninga je že v »osnova …« — odšteta, da ni šteta dvakrat
  if (t.restIn && t.restIn >= 10 && bits.length > 1) bits[bits.length - 1] += ` − osnova med treningom ${f(t.restIn)} (je že v osnovi)`
  if (t.plannedDropped && !t.burn && !t.plannedBurn && !t.estimatedBurn) bits.push(`trening 0 (načrtovanih ~${f(t.plannedDropped)} ni bilo zabeleženih)`)
  if (t.carbLoad) bits.push(`polnjenje z OH ${f(t.carbLoad)}`)
  return bits.join(' + ') + (t.clampedToFloor ? ' → dvignjeno na varno mejo' : '')
}

/** Ocena porabe načrtovane seje: iz FTP (kJ ≈ kcal pri ~24 % izkoristku), sicer MET. Nikoli negativna. */
export function estimatePlanKcal(d: PlanDay, p: Profile): number {
  const min = Number.isFinite(d.durationMin) && d.durationMin > 0 ? d.durationMin : 0
  const w = p.weightKg && p.weightKg > 0 ? p.weightKg : 75, h = min / 60
  if ((d.kind === 'kolo' || d.kind === 'test') && p.ftp && p.ftp > 0) {
    const IF: Record<string, number> = { Z1: 0.5, Z2: 0.65, Z3: 0.75, Z4: 0.78, Z5: 0.74, test: 0.8, dirka: 0.72 }
    return Math.round(p.ftp * (IF[d.zone || 'Z2'] ?? 0.65) * min * 0.06)
  }
  // (v3.49) tek po vrsti seje in ravni (prej vedno 9,5 MET: 30 min teka in hoje začetnika = 437 kcal)
  const met = d.kind === 'kolo' || d.kind === 'test' ? (/Z[4-5]|test|dirka/.test(d.zone || '') ? 9 : d.zone === 'Z1' ? 4.5 : 7) : d.kind === 'tek' ? planRunMet(d, p.focus?.level) : d.kind === 'pohod' ? 4.5 : d.kind === 'moc' ? 4 : 0
  return Math.round(met * w * h)
}

export function sumMeals(m: readonly MealEntry[]) {
  return m.reduce((s, e) => ({ kcal: s.kcal + (e.kcal || 0), p: s.p + (e.proteinG || 0), c: s.c + (e.carbsG || 0), f: s.f + (e.fatG || 0) }), { kcal: 0, p: 0, c: 0, f: 0 })
}

/** Ali je cilj (kg/teden) prehiter za varno pot — če ja, povemo naravnost, ne klampamo tiho. */
export function lossTooFast(kgPerWeek: number): boolean { return kgPerWeek > MAX_WEEKLY_LOSS_KG }
/** (v3.50) en stavek za »prehitro« (opozorilo na Danes in Napredek) — prej 200–300 proti 150–250 kcal */
export const LOSS_TOO_FAST_TIP = 'več kot 0,5 kg je prehitro, gre mišica in z njo moč. Dodaj 150–250 kcal na dan.'

/** Pravila za vsak prehranski AI poziv — dobesedno, ker se nanje zanaša vsaka številka. */
export const NUTRITION_RULES = `PRAVILA PREHRANE (zavezujoča):
- Nikoli ne predlagaj manj hrane od dnevnega cilja, ki ga dobiš kot številko.
- Vnos ni odvisen od forme (TSB), svežine ali oblike telesa. Ne povezuj ga z njimi.
- Brez preskakovanja obrokov, posta ali prenašanja kalorij med dnevi.
- Če je želena izguba teže nad 0,5 kg na teden, to pove uporabniku in priporoči zdravnika.
- Mladoletnim ne predlagaj deficita.
- Deficit nikoli na kolesu: OH na uro po tabeli Goriva — Z2 od 90 min ~${fuelGph({ kind: 'kolo', durationMin: 90, zone: 'Z2' })} g, dolga ~${fuelGph({ kind: 'kolo', durationMin: 120, role: 'dolga' })}–${fuelGph({ kind: 'kolo', durationMin: 180, role: 'dolga' })} g, intervali ~${fuelGph({ kind: 'kolo', durationMin: 90, role: 'kljucna' })} g, dirka ~${fuelGph({ kind: 'kolo', durationMin: 120, role: 'dirka' })}–${fuelGph({ kind: 'kolo', durationMin: 180, role: 'dirka' })} g.`

/* ====================================================================
   TEŽA — trend iz jutranjih tehtanj (checkins). Šteje 7-dnevno povprečje.
   ==================================================================== */
/**
 * (v3.49) Tempo teže = naklon premice skozi tehtanja zadnjih 3 tednov (prej razlika povprečij dveh tednov: dve tehtanji ali
 * vsakodnevno nihanje ±0,4 kg sta dali »prehitro« ali »gre gor«). Za tempo vsaj 4 tehtanja v vsaj 10 dneh; noise = koliko
 * kg na teden je še lahko samo nihanje (2 × napaka naklona).
 */
export const PACE_DAYS = 21, PACE_MIN_N = 4, PACE_MIN_SPAN = 10
export interface WeightTrend { last: number; lastDate: string; avg7: number; deltaWeek: number | null; first: { kg: number; date: string }; n: number; /** (v3.49) tehtanj v zadnjih 3 tednih */ nPace: number; /** (v3.49) ± kg na teden v okviru nihanja */ noise: number | null }
export function weightTrend(checkins: readonly { date: string; weightKg?: number | null }[]): WeightTrend | null {
  const t = checkins.filter(c => c.weightKg && c.weightKg > 30).map(c => ({ date: c.date, kg: c.weightKg as number })).sort((a, b) => a.date.localeCompare(b.date))
  if (!t.length) return null
  const last = t[t.length - 1]!
  const days = (a: string, b: string) => Math.round((new Date(b).getTime() - new Date(a).getTime()) / 86400_000)
  const w0 = t.filter(x => days(x.date, last.date) <= 6)
  const avg = (a: { kg: number }[]) => a.reduce((s, x) => s + x.kg, 0) / a.length
  // (v3.49) okno vključuje 21. dan: kdor se tehta enkrat na teden, ima tako 4 tehtanja (0, 7, 14, 21) — prej 3 in nikoli
  // tempa (ne »prehitro« ne kg/teden)
  const win = t.filter(x => days(x.date, last.date) <= PACE_DAYS)
  let deltaWeek: number | null = null, noise: number | null = null
  if (win.length >= PACE_MIN_N && days(win[0]!.date, last.date) >= PACE_MIN_SPAN) {
    const xs = win.map(x => -days(x.date, last.date)), mx = xs.reduce((s, x) => s + x, 0) / xs.length, my = avg(win)
    const sxx = xs.reduce((s, x) => s + (x - mx) ** 2, 0)
    const b = xs.reduce((s, x, i) => s + (x - mx) * (win[i]!.kg - my), 0) / sxx
    const res = xs.reduce((s, x, i) => s + (win[i]!.kg - my - b * (x - mx)) ** 2, 0)
    deltaWeek = +(b * 7).toFixed(2)
    noise = +(2 * 7 * Math.sqrt(res / Math.max(1, xs.length - 2) / sxx)).toFixed(2)
  }
  return { last: last.kg, lastDate: last.date, avg7: +avg(w0).toFixed(1), deltaWeek, first: t[0]!, n: t.length, nPace: win.length, noise }
}

/**
 * (v3.49) Teža za izračun (cilj kalorij, beljakovine): povprečje tehtanj zadnjih 7 dni do zadnjega, ko so vsaj 3;
 * sicer zadnje tehtanje (prej vedno zadnje — cilj je skakal z vodo ±1 kg). Null = ni tehtanj.
 */
export function calcWeightKg(checkins: readonly { date: string; weightKg?: number | null }[]): number | null {
  const tr = weightTrend(checkins)
  if (!tr) return null
  const days = (a: string) => Math.round((new Date(tr.lastDate).getTime() - new Date(a).getTime()) / 86400_000)
  const n7 = checkins.filter(c => c.weightKg && c.weightKg > 30 && days(c.date) >= 0 && days(c.date) <= 6).length
  return n7 >= 3 ? tr.avg7 : tr.last
}

/* ====================================================================
   GORIVO za današnjo sejo — pred / med / po. Deterministično.
   ==================================================================== */
export interface Fueling { before: string; during: string; after: string }
type FuelDay = Pick<PlanDay, 'kind' | 'durationMin' | 'zone'> & { role?: PlanDay['role']; raceId?: string | null; title?: string }
type FuelProfile = Pick<Profile, 'weightKg'> & Partial<Pick<Profile, 'focus' | 'trainTime' | 'deficit' | 'goal' | 'age' | 'sex' | 'heightCm' | 'bodyFatPct' | 'goalStart' | 'targetWeightKg' | 'event'>>
type FoodC = readonly [name: string, contains: readonly Contains[], lactoseFree?: string]
const SKUTA: FoodC = ['skuta', ['mleko'], 'skuta brez laktoze'], JOGURT: FoodC = ['jogurt', ['mleko'], 'jogurt brez laktoze'], JAJCA: FoodC = ['jajca', ['jajca']]
const PISC: FoodC = ['piščanec', ['meso']], TUNA: FoodC = ['tuna', ['riba']], TOFU: FoodC = ['tofu', ['soja']], STROC: FoodC = ['stročnice', []]
const SOJJ: FoodC = ['sojin jogurt', ['soja']], LECA: FoodC = ['leča', []], TEMPEH: FoodC = ['tempeh', ['soja']], CIC: FoodC = ['čičerika', []]
/**
 * (v3.51) Primeri po prehranskih željah: osnovni seznam (vegan, brez mesa, brez laktoze, vsejedec), iz katerega izpadejo
 * živila, ki jih alergija, dieta ali »ne maram« izločijo; manjkajoča dopolni rezerva. Prej je »alergija na mleko« dobila
 * skuto, »alergija na jajca« jajca, pescetarijanec piščanca, vegan z alergijo na arašide arašidovo maslo.
 */
function foodsFor(prefs: string | null | undefined, pick: (ex: ReturnType<typeof exclusionsOf>) => readonly FoodC[], spare: readonly FoodC[]): string {
  const ex = exclusionsOf(prefs), lf = !!ex.lactoseFree
  const base = pick(ex), out: FoodC[] = []
  for (const c of [...base, ...spare]) if (out.length < base.length && !out.some(o => o[0] === c[0]) && foodOk(c[0], c[1], ex) && !(lf && c[1].includes('mleko') && !c[2])) out.push(c)
  return out.map(c => (lf && c[2] ? c[2] : c[0])).join(', ')
}
/** (v3.51) Večerni prigrizek z beljakovinami in OH po omejitvah (prej vsem »skuta z banano, jogurt, kakav«). */
export function eveningSnack(prefs: string | null | undefined): string {
  return foodsFor(prefs, ex => (ex.vegan ? [['sojin jogurt z banano', ['soja']], ['kruh z arašidovim maslom', ['gluten', 'oreski']]]
    : ex.lactoseFree ? [['jogurt brez laktoze z banano', ['mleko'], 'jogurt brez laktoze z banano'], ['kruh z jajcem', ['gluten', 'jajca']]]
    : [['skuta z banano', ['mleko']], ['jogurt', ['mleko']], ['kakav', ['mleko']]]),
  [['kruh z jajcem', ['gluten', 'jajca']], ['kruh z arašidovim maslom', ['gluten', 'oreski']], ['sojin jogurt z banano', ['soja']], ['kruh s humusom', ['gluten']], ['riževi vaflji s humusom', []], ['banana z arašidovim maslom', ['oreski']]])
}
export function proteinFoods(prefs: string | null | undefined): string {
  return foodsFor(prefs, ex => (ex.vegan ? [TOFU, SOJJ, LECA, TEMPEH]
    : ex.contains.includes('meso') ? (ex.lactoseFree ? [JAJCA, TOFU, STROC, SKUTA] : [SKUTA, JAJCA, JOGURT, STROC])
    : ex.lactoseFree ? [JAJCA, PISC, TUNA, SKUTA] : [SKUTA, JAJCA, JOGURT, PISC]),
  [TUNA, PISC, STROC, TOFU, SOJJ, CIC, LECA, JOGURT])
}
/** (v3.51) lahek obrok pred močjo po omejitvah (prej vsem »jogurt s sadjem, kruh z jajcem«, tudi veganu) */
function lightMeal(prefs: string | null | undefined): string {
  return foodsFor(prefs, () => [['jogurt s sadjem', ['mleko'], 'jogurt brez laktoze s sadjem'], ['kruh z jajcem', ['gluten', 'jajca']]],
    [['sojin jogurt s sadjem', ['soja']], ['kruh z arašidovim maslom', ['gluten', 'oreski']], ['kruh s humusom', ['gluten']], ['riževi vaflji s humusom', []], ['banana', []]])
}
/** (v3.51) OH pred vadbo po željah: celiakija brez kruha in kosmičev, vegan brez medu (prej vsem »kruh z medom«) */
function preCarbs(prefs: string | null | undefined): { snack: string; oh: string } {
  const ex = exclusionsOf(prefs), glu = ex.contains.includes('gluten'), sweet = ex.vegan ? 'marmelado' : 'medom'
  return { snack: glu ? `banana ali riževi vaflji z ${sweet}` : `kruh z ${sweet} ali banana`, oh: glu ? 'riž, polenta, banana' : 'kosmiči, kruh, banana' }
}
/** (v3.50) okoliščine: na isti dan je tudi vožnja (moč po kolesu), seja je za nami, ura začetka z ure */
export interface FuelingOpts { withRide?: boolean; rideDone?: boolean; startH?: number | null; /** (v3.51) prehranske želje (Nastavitve) — primeri beljakovin */ prefs?: string | null }
/** (v3.50) kratka lahka seja (pod 45 min, moč pod 40 min): brez kartice goriva — »voda, nič posebnega« ni nasvet */
export const FUEL_SHORT_MIN = 45
/** (v3.50) besede po vrsti seje: kolo »na kolesu / vožnje«, tek »med tekom / teka«, pohod »na poti / pohoda«, moč »med vadbo / vadbe« */
const fuelWords = (k: FuelDay['kind']) => (k === 'kolo' || k === 'test' ? { in: 'na kolesu', of: 'vožnje' } : k === 'tek' ? { in: 'med tekom', of: 'teka' } : k === 'pohod' ? { in: 'na poti', of: 'pohoda' } : { in: 'med vadbo', of: 'vadbe' })
/**
 * (v3.49) »Pred« in »Po« iz istega razporeda obrokov kot Prehrana (mealScheduleOf) — prej Danes »1 h prej prigrizek«,
 * Prehrana pa »Kosilo · 2–3 h pred vožnjo«. Po lahki uri pri deficitu posebna obnova ni potrebna (prej »63–79 g OH«).
 * (v3.50) Razpored tudi za tek, hribe in moč; »Med« na kolesu iz iste tabele kot Gorivo (fuelrate.ts).
 */
export function fueling(d: FuelDay | null, p: FuelProfile, opts: FuelingOpts = {}): Fueling | null {
  const f = fuelingBase(d, p, !!opts.withRide, opts.prefs)
  if (!f || !d || (d.kind === 'moc' && opts.withRide)) return f
  const w = p.weightKg || 75, t = d.durationMin || 0, g = (k: number) => Math.round(w * k)
  const hard = d.role === 'kljucna' || d.role === 'test' || d.role === 'dirka' || /Z[4-5]|test|dirka/.test(d.zone || '')
  const sch = mealScheduleOf(p, d, { rideDone: opts.rideDone, startH: opts.startH })
  // dan tekme: zajtrk po pravilu tekme je že v »Pred«; kot v Prehrani še »Pred startom«
  if (d.role === 'dirka') return sch.raceDay ? { ...f, before: `${f.before} 30–60 min prej banana ali gel.` } : f
  const light = !hard && t < 90 && d.role !== 'dolga'
  const def = goalDeficit(p as Profile) > 0
  const after = sch.plan.find(s => s[0] === 'obnova')
  const ai = after ? sch.plan.indexOf(after) : -1
  const before = sch.ride ? [...sch.plan.slice(0, ai < 0 ? undefined : ai)].reverse().find(s => s[0] === 'pred' || /pred (vožnjo|tekom|vadbo|pohodom)/.test(s[1] + s[2])) : undefined
  const big = t >= 120 || hard
  const meal = after ? after[1].replace(/^Po (vožnji|teku|vadbi|pohodu) — /, '') : null
  const fw = fuelWords(d.kind), pc = preCarbs(opts.prefs)
  const beforeTxt = !before ? f.before
    : `${before[1]} · ${before[2]} (v Prehrani)${before[0] === 'kosilo' ? `${big ? `, z ${g(1)}–${g(1.5)} g OH in malo maščob` : ''}; 30–60 min prej banana, če si ${gx(p, 'lačen', 'lačna')}.`
      : before[0] === 'zajtrk' ? `: ${g(1)}–${g(1.5)} g OH (${pc.oh}), malo maščob. Ne treniraj ${gx(p, 'lačen', 'lačna')}.`
      : `: ${pc.snack}${big ? `, malo maščob — ne treniraj ${gx(p, 'lačen', 'lačna')}` : ''}.`}`
  // moč: po vadbi beljakovine (OH po moči niso nujni), z obrokom iz Prehrane
  const afterTxt = d.kind === 'moc'
    ? sch.ride && after && meal ? `${meal[0]!.toUpperCase()}${meal.slice(1)} ${after[2]} (v Prehrani): ${g(0.3)}–${g(0.4)} g beljakovin (${proteinFoods(opts.prefs)}).` : f.after
    : light && def
    ? `Naslednji obrok${sch.ride && meal ? ` (v Prehrani: ${meal} ${sch.w.poM})` : ''} normalno, z ${g(0.3)}–${g(0.4)} g beljakovin — posebna obnova po lahki uri ni potrebna.`
    : sch.ride && after && meal ? `${meal[0]!.toUpperCase()}${meal.slice(1)} ${after[2]} (v Prehrani): ${g(0.3)}–${g(0.4)} g beljakovin + ${g(0.8)}–${g(1)} g ogljikovih hidratov. Kalorije ${fw.of} so že v dnevnem cilju.`
    : f.after
  return { ...f, before: beforeTxt, after: afterTxt }
}
function fuelingBase(d: FuelDay | null, p: FuelProfile, withRide = false, prefs?: string | null): Fueling | null {
  if (!d || d.kind === 'pocitek') return null
  const w = p.weightKg || 75, t = d.durationMin || 0
  const hard = d.role === 'kljucna' || d.role === 'test' || d.role === 'dirka' || /Z[4-5]|test|dirka/.test(d.zone || '')
  // (v3.50) kratka lahka seja (25-min tek, hoja, 30-min vadba doma): brez »Pred: nič posebnega · Med: voda · Po: …«
  if (d.role !== 'dirka' && !hard && t < (d.kind === 'moc' ? 40 : FUEL_SHORT_MIN)) return null
  const fw = fuelWords(d.kind)
  // (v3.50) »takoj po kolesu« samo, ko je isti dan res vožnja (prej tudi na dan samo z močjo)
  if (d.kind === 'moc') return { before: withRide ? 'Nič posebnega — lahko takoj po kolesu.' : `Lahek obrok 1–2 h prej (${lightMeal(prefs)}) — na prazen želodec težke serije ne gredo.`, during: 'Voda.', after: `${Math.round(w * .3)}–${Math.round(w * .4)} g beljakovin v eni uri (${proteinFoods(prefs)}).` }
  if (d.role === 'dirka') {
    // polnjenje z OH (8–10 g na kg, 2 dni) samo pred tekmo ≥ 150 min; ≥ 90 min dan prej več OH in na kolesu 60+ g na uro;
    // kratka tekma (kronometer 30 min): normalen dan, na kolesu največ 30–60 g na uro. Druga tekma (raceId) ima manj goriva.
    const other = !!d.raceId, g = (k: number) => Math.round(w * k)
    // (v3.48) zajtrk po istem pravilu kot opis tekme (raceBreakfast); »Pred« velja za jutro tekme — brez »Dan prej …«
    // (polnjenje dan in dva prej sta v opisu tistih dni in v Prehrani)
    const [lo, hi] = raceBreakfastGkg(t)
    const before = `${raceBreakfast(t, other)}: ${lo === hi ? g(lo) : `${g(lo)}–${g(hi)}`} g OH, malo vlaknin in maščob.`
    // (v3.50) OH na uro iz iste tabele kot Gorivo in opis tekme (fuelrate.ts: ~85 od 150 min, ~70 od 90 min);
    // pod 60 min brez »ml na uro« (prej »nekaj požirkov … · 500–750 ml na uro«)
    // (v3.51) tekaška tekma: isti vir kot »Na teku« v Prehrani (geli, brez ploščic) — prej kolesarska tabela ~70 g na uro
    const run = d.kind === 'tek' && t >= RACE_FUEL_MIN ? runFuel(d) : null
    const during = run ? run.schedule
      : t >= RACE_FUEL_MIN
      ? `~${fuelGph({ ...d, kind: 'kolo' })} g OH na uro od 30. minute (geli, izotonik, ploščice — samo preizkušeno) · 500–750 ml na uro${other ? ', ob vročini elektroliti' : ' z elektroliti'}.`
      : t >= 60 ? 'Največ 30–60 g OH na uro (izotonik ali gel) · 500–750 ml na uro.'
      : SHORT_RACE_FUEL
    const after = other
      ? `V eni uri ${g(0.3)}–${g(0.4)} g beljakovin + ~${g(1)} g OH (1 g na kg). Kalorije tekme so v dnevnem cilju.`
      : `V eni uri ${g(0.3)}–${g(0.4)} g beljakovin + ${g(1)}–${g(1.2)} g OH. Uživaj.`
    return { before, during, after }
  }
  // (v3.49) tek: med tekom gel in voda (runFuel — isto kot »Na teku« v Prehrani), ne banana in ploščica
  if (d.kind === 'tek' && t >= 60) { const f = fuelingBase({ ...d, kind: 'pohod' }, p, false, prefs)!; return { ...f, during: runFuel(d)!.schedule, after: f.after.replace(fuelWords('pohod').of, fw.of) } }
  if (t < 60) return { before: `Nič posebnega; če si ${gx(p, 'lačen', 'lačna')}, banana.`, during: 'Voda, 500 ml.', after: `Normalen obrok z ${Math.round(w * .3)} g beljakovin.` }
  // (v3.50) na kolesu OH na uro iz iste tabele kot Gorivo (prej Z2 80 min »0–30 g«, Gorivo »samo voda«)
  const bike = d.kind === 'kolo' || d.kind === 'test'
  const gph = bike ? fuelGph(d) : 0
  const oh = bike ? (gph ? `~${gph} g` : '') : t < 90 ? (hard ? '30–60 g' : '0–30 g') : hard ? '60–80 g' : '40–60 g'
  const food = d.kind === 'pohod' ? 'banana, ploščica, sendvič' : 'banana, ploščica, gel, izotonik'
  return {
    before: t >= 120 || hard ? `1–2 h prej ${Math.round(w)}–${Math.round(w * 1.5)} g ogljikovih hidratov (${preCarbs(prefs).oh}), malo maščob. Ne treniraj ${gx(p, 'lačen', 'lačna')}.` : `1 h prej lahek OH prigrizek (${preCarbs(prefs).snack}).`,
    during: oh
      ? `${oh} ogljikovih hidratov na uro${hard ? ' — intervali brez sladkorja ne gredo' : bike ? ' od 30. minute' : ' od prve ure'} (${food}) · 500–750 ml na uro, ob vročini elektroliti. Deficit nikoli ${fw.in}.`
      : `Voda po žeji (500–750 ml na uro) — ${bike ? 'na kolesu ne jej' : 'hrana ni potrebna'}, seja je lahka ali kratka.`,
    after: `V 45 min: ${Math.round(w * .3)}–${Math.round(w * .4)} g beljakovin + ${Math.round(w * .8)}–${Math.round(w)} g ogljikovih hidratov. Kalorije ${fw.of} so že v dnevnem cilju.`,
  }
}
