import type { Activity, MealEntry, PlanDay, Profile } from '../types'

/* ====================================================================
   VAROVALKE — omejitve so v aritmetiki, ne v promptu.
   Prompt ne more popraviti številke, ki jo model dobi kot dejstvo.
   ==================================================================== */
export const MAX_DEFICIT = 750          // kcal/dan pod vzdrževanjem — več ni varno brez nadzora
export const MAX_ADJ_DOWN = -400        // (zgodovinsko) največ, kar je trening smel znižati cilj — ne velja več
export const MAX_TRAINING_ADD = 1200    // največ, kar trening doda dnevnemu cilju
export const MIN_ABS_M = 1500           // absolutno dno (moški)
export const MIN_ABS_Z = 1200           // absolutno dno (ženske)
export const MAX_WEEKLY_LOSS_KG = 0.5   // nad tem: napotitev k zdravniku

export function profileComplete(p: Pick<Profile, 'weightKg' | 'heightCm' | 'age' | 'sex'>): boolean {
  return !!(p.weightKg && p.heightCm && p.age && p.sex)
}
export function isMinor(p: Pick<Profile, 'age'>): boolean { return !!p.age && p.age < 18 }

/** Mifflin-St Jeor. Vrne null, če profil ni popoln — nikoli ne ugibamo. */
export function bmr(p: Pick<Profile, 'weightKg' | 'heightCm' | 'age' | 'sex'>): number | null {
  if (!profileComplete(p)) return null
  const base = 10 * p.weightKg! + 6.25 * p.heightCm! - 5 * p.age!
  return Math.round(p.sex === 'm' ? base + 5 : base - 161)
}

/** Faktor aktivnosti iz tedenskih ur (brez treninga — tega dodamo dnevno posebej). */
export function activityFactor(hoursPerWeek?: number | null): number {
  const h = hoursPerWeek || 0
  return h <= 2 ? 1.35 : h <= 5 ? 1.45 : h <= 9 ? 1.55 : 1.65
}

/** Faktor gibanja IZVEN treninga (1,3 sedeče · 1,4 zmerno · 1,5 veliko hoje). Trening se prišteje dnevno. */
export function neatFactor(p: Pick<Profile, 'neat'>): number {
  return p.neat && p.neat >= 1.2 && p.neat <= 1.6 ? p.neat : 1.4
}

/** Vzdrževanje BREZ treninga: BMR × gibanje izven treninga. */
export function tdee(p: Profile): number | null {
  const b = bmr(p)
  if (b == null) return null
  return Math.round(b * neatFactor(p))
}

/** Ciljni deficit: nastavljen (300/500/750) ali 500 pri cilju »shujšati«. Mladoletni: 0 — vedno vzdrževanje. */
export function goalDeficit(p: Profile): number {
  if (isMinor(p)) return 0
  if (p.deficit != null && p.deficit > 0) return Math.min(MAX_DEFICIT, Math.round(p.deficit))
  if (p.goal === 'shujsati') return 500
  return 0
}

/** Ocena porabe aktivnosti: kcal iz naprave, sicer MET ocena. */
export function activityKcal(a: Activity, p: Profile): number {
  if (a.kcal) return Math.round(a.kcal)
  const w = p.weightKg || 75
  const h = (a.durationMin || 0) / 60
  const met = a.sport === 'kolo' ? ((a.speedKmh || 0) < 20 ? 6 : (a.speedKmh || 0) < 26 ? 8 : 10)
    : a.sport === 'tek' ? 9.5 : a.sport === 'pohod' ? 4.5 : a.sport === 'moc' ? 4 : a.sport === 'plavanje' ? 7 : 5
  let k = met * w * h
  if (a.avgHr && p.maxHr) k *= Math.max(0.7, Math.min(1.3, (a.avgHr / p.maxHr) / 0.72))
  return Math.round(k)
}

export interface DailyTarget {
  /** cilj vnosa za danes */
  kcal: number
  /** vzdrževanje brez treninga */
  maintenance: number
  /** poraba današnjih aktivnosti (dejanska) */
  burn: number
  /** načrtovana poraba (iz plana) */
  plannedBurn: number
  /** spodnja varna meja */
  floor: number
  proteinG: number
  carbsG: number
  fatG: number
  /** je cilj kdaj pritisnjen na dno? (za UI »Varno« / opozorilo) */
  clampedToFloor: boolean
  minor: boolean
}

/**
 * Dnevni cilj: vzdrževanje brez treninga − deficit + trening tistega dne.
 * Trening = dejanska poraba, če je aktivnost zabeležena; sicer načrtovana (dokler seja ni opravljena).
 * Na dan treninga je zato cilj VIŠJI že zjutraj — gorivo pride pred vožnjo, ne po njej.
 */
export function dailyTarget(p: Profile, todaysActivities: readonly Activity[], todaysPlan: readonly PlanDay[]): DailyTarget | null {
  const base = tdee(p)
  if (base == null) return null
  const b = bmr(p)!
  const burn = todaysActivities.reduce((s, a) => s + activityKcal(a, p), 0)
  const plannedBurn = todaysPlan.filter(d => !d.done && !d.optional && d.kind !== 'pocitek').reduce((s, d) => s + (d.kcalBurn || estimatePlanKcal(d, p)), 0)
  const deficit = Math.min(MAX_DEFICIT, goalDeficit(p))
  const training = Math.min(MAX_TRAINING_ADD, burn > 0 ? burn : plannedBurn)
  let target = (p.kcalOverride && !isMinor(p) ? p.kcalOverride : base - deficit) + training
  const floorAbs = p.sex === 'z' ? MIN_ABS_Z : MIN_ABS_M
  // tla: nikoli pod BMR, nikoli pod 1500/1200, ob treningu vsaj BMR + pol porabe,
  // in tudi ročni cilj ne sme preseči stropa deficita (750 pod dnevno porabo)
  const floor = Math.max(b, floorAbs, training > 0 ? Math.round(b + training / 2) : 0, base + training - MAX_DEFICIT)
  const clamped = target < floor
  if (clamped) target = floor
  target = Math.round(target)
  const w = p.weightKg!
  const gkg = p.proteinGkg && p.proteinGkg >= 1.2 && p.proteinGkg <= 2.6 ? p.proteinGkg : (p.goal === 'shujsati' || goalDeficit(p) > 0 ? 2.0 : 1.7)
  const proteinG = Math.round(w * gkg)
  const fatG = Math.round(Math.max(0.7 * w, (target * 0.25) / 9))
  const carbsG = Math.max(0, Math.round((target - proteinG * 4 - fatG * 9) / 4))
  return { kcal: target, maintenance: base, burn, plannedBurn, floor, proteinG, carbsG, fatG, clampedToFloor: clamped, minor: isMinor(p) }
}

function estimatePlanKcal(d: PlanDay, p: Profile): number {
  const w = p.weightKg || 75, h = d.durationMin / 60
  const met = d.kind === 'kolo' ? (d.zone === 'Z4' || d.zone === 'test' ? 9 : 7) : d.kind === 'tek' ? 9.5 : d.kind === 'pohod' ? 4.5 : d.kind === 'moc' ? 4 : 0
  return Math.round(met * w * h)
}

export function sumMeals(m: readonly MealEntry[]) {
  return m.reduce((s, e) => ({ kcal: s.kcal + (e.kcal || 0), p: s.p + (e.proteinG || 0), c: s.c + (e.carbsG || 0), f: s.f + (e.fatG || 0) }), { kcal: 0, p: 0, c: 0, f: 0 })
}

/** Ali je cilj (kg/teden) prehiter za varno pot — če ja, povemo naravnost, ne klampamo tiho. */
export function lossTooFast(kgPerWeek: number): boolean { return kgPerWeek > MAX_WEEKLY_LOSS_KG }

/** Pravila za vsak prehranski AI poziv — dobesedno, ker se nanje zanaša vsaka številka. */
export const NUTRITION_RULES = `PRAVILA PREHRANE (zavezujoča):
- Nikoli ne predlagaj manj hrane od dnevnega cilja, ki ga dobiš kot številko.
- Vnos ni odvisen od forme (TSB), svežine ali oblike telesa. Ne povezuj ga z njimi.
- Brez preskakovanja obrokov, posta ali prenašanja kalorij med dnevi.
- Če je želena izguba teže nad 0,5 kg na teden, to pove uporabniku in priporoči zdravnika.
- Mladoletnim ne predlagaj deficita.`

/* ====================================================================
   TEŽA — trend iz jutranjih tehtanj (checkins). Šteje 7-dnevno povprečje.
   ==================================================================== */
export interface WeightTrend { last: number; lastDate: string; avg7: number; deltaWeek: number | null; first: { kg: number; date: string }; n: number }
export function weightTrend(checkins: readonly { date: string; weightKg?: number | null }[]): WeightTrend | null {
  const t = checkins.filter(c => c.weightKg && c.weightKg > 30).map(c => ({ date: c.date, kg: c.weightKg as number })).sort((a, b) => a.date.localeCompare(b.date))
  if (!t.length) return null
  const last = t[t.length - 1]!
  const days = (a: string, b: string) => Math.round((new Date(b).getTime() - new Date(a).getTime()) / 86400_000)
  const w0 = t.filter(x => days(x.date, last.date) <= 6), w1 = t.filter(x => days(x.date, last.date) >= 7 && days(x.date, last.date) <= 13)
  const avg = (a: { kg: number }[]) => a.reduce((s, x) => s + x.kg, 0) / a.length
  return { last: last.kg, lastDate: last.date, avg7: +avg(w0).toFixed(1), deltaWeek: w1.length ? +(avg(w0) - avg(w1)).toFixed(2) : null, first: t[0]!, n: t.length }
}

/* ====================================================================
   GORIVO za današnjo sejo — pred / med / po. Deterministično.
   ==================================================================== */
export interface Fueling { before: string; during: string; after: string }
export function fueling(d: Pick<PlanDay, 'kind' | 'durationMin' | 'zone'> | null, p: Pick<Profile, 'weightKg'>): Fueling | null {
  if (!d || d.kind === 'pocitek') return null
  const w = p.weightKg || 75, t = d.durationMin || 0, hard = /Z[3-5]|test/.test(d.zone || '')
  if (d.kind === 'moc') return { before: 'Lahek obrok 1–2 h prej ali nič — moč doma ne rabi posebne priprave.', during: 'Voda.', after: `V eni uri ${Math.round(w * .35)}–${Math.round(w * .45)} g beljakovin (skuta, jajca, jogurt, piščanec) — to gradi mišice.` }
  if (t < 60) return { before: 'Nič posebnega; če si lačen, banana.', during: 'Voda, 500 ml.', after: `Normalen obrok z ${Math.round(w * .3)} g beljakovin.` }
  const oh = t < 90 ? '30 g' : t < 150 ? '40–60 g' : '60–90 g'
  return {
    before: t >= 120 || hard ? `1–2 h prej: ${Math.round(w)}–${Math.round(w * 1.5)} g ogljikovih hidratov (kosmiči, kruh, banana), malo maščob.` : '1 h prej lahek OH prigrizek (banana, kruh z medom).',
    during: `${oh} ogljikovih hidratov na uro po prvi uri (banana, ploščica, gel, sok) · 500–750 ml na uro, ob vročini elektroliti. Ne vozi na prazno — v deficitu je to prva stvar, ki pokvari trening.`,
    after: `V 45 min: ${Math.round(w * .3)}–${Math.round(w * .4)} g beljakovin + ${Math.round(w * .8)}–${Math.round(w)} g ogljikovih hidratov. Kalorije treninga so že vštete v današnji cilj.`,
  }
}
