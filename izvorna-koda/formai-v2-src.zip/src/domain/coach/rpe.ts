import type { Activity, PlanDay } from '../types'
import { addDays } from '../training/load'

/**
 * »KAKO JE ŠLO?« — občutek napora po vadbi (RPE, lestvica 1–10). Pet stopenj za en tap; shrani se število.
 * Pove, česar ura ne: lahka vožnja, ki se zdi težka, je zgodnji znak utrujenosti (pred utripom in HRV).
 */
export const RPE_LEVELS: readonly [number, string][] = [[2, 'lahkotno'], [4, 'lahko'], [6, 'srednje'], [8, 'težko'], [10, 'do konca']]

/** Oznaka za število (tudi vmesna števila, npr. iz starejšega vpisa 1–10). */
export function rpeLabel(v: number | null | undefined): string | null {
  if (v == null || !Number.isFinite(v)) return null
  const lv = RPE_LEVELS.reduce((b, x) => (Math.abs(x[0] - v) < Math.abs(b[0] - v) ? x : b))
  return lv[1]
}

/** Veljavna vrednost RPE (1–10, celo število) ali null. */
export function cleanRpe(v: unknown): number | null {
  const n = typeof v === 'number' ? v : typeof v === 'string' ? Number(v) : NaN
  return Number.isFinite(n) && n >= 1 && n <= 10 ? Math.round(n) : null
}

/** Ali je bila vadba mišljena lahko: po dnevu načrta, sicer po conah utripa (≥ 80 % v Z1–Z2). null = ne vemo. */
export function meantEasy(a: Pick<Activity, 'sport' | 'hrZoneSec'>, day?: Pick<PlanDay, 'role' | 'zone' | 'kind'> | null): boolean | null {
  if (day) {
    if (day.role === 'kljucna' || day.role === 'test' || day.role === 'dirka' || day.kind === 'moc') return false
    if (day.role === 'lahka' || day.role === 'regen' || day.role === 'dolga') return true
    return day.zone ? /^Z[12]$/.test(day.zone) : null
  }
  if (a.sport !== 'kolo') return null
  const z = a.hrZoneSec
  if (!z || z.length < 3) return null
  const all = z.reduce((s, v) => s + (v || 0), 0)
  if (all < 600) return null
  return ((z[0] || 0) + (z[1] || 0)) / all >= 0.8
}

/** Dan načrta, ki ga je vadba pokrila (opravljeno z id-jem vadbe). */
function dayOf(plan: readonly PlanDay[], a: Pick<Activity, 'id'>): PlanDay | null {
  return plan.find(d => d.done?.activityId === a.id) ?? null
}

/**
 * Opozorilo iz občutka zadnjih 10 dni: vsaj dve lahki vožnji »težko« ali več → znak utrujenosti;
 * vsaj dva ključna treninga »lahko« ali manj → cilji so morda prenizki (test FTP). null = nič posebnega.
 */
export function rpeWarn(acts: readonly Activity[], plan: readonly PlanDay[], today: string): string | null {
  const from = addDays(today, -9)
  const inWin = (date: string) => date >= from && date <= today
  // ocene: na vadbi (povezan dan načrta pove, kaj je bilo mišljeno) ali na dnevu načrta brez ocenjene vadbe
  const rated: { rpe: number; easy: boolean | null; key: boolean }[] = []
  for (const a of acts) {
    const r = cleanRpe(a.rpe)
    if (r == null || !inWin(a.date)) continue
    const day = dayOf(plan, a)
    rated.push({ rpe: r, easy: meantEasy(a, day), key: !!day && (day.role === 'kljucna' || day.role === 'test') })
  }
  for (const d of plan) {
    const r = cleanRpe(d.rpe)
    if (r == null || !d.done || !inWin(d.date)) continue
    const a = d.done.activityId ? acts.find(x => x.id === d.done!.activityId) : null
    if (a && cleanRpe(a.rpe) != null) continue
    rated.push({ rpe: r, easy: meantEasy({ sport: 'kolo', hrZoneSec: null }, d), key: d.role === 'kljucna' || d.role === 'test' })
  }
  if (rated.length < 2) return null
  const easyHard = rated.filter(x => x.easy === true && x.rpe >= 8).length
  const hardEasy = rated.filter(x => x.key && x.rpe <= 4).length
  if (easyHard >= 2) return `Občutek: lahke vožnje so se ti v zadnjih 10 dneh ${easyHard}× zdele težke — zgodnji znak utrujenosti. Več spanca in hrane, lahko naj bo res lahko; intenzivnosti ne dodajaj, dokler se ne popravi.`
  if (hardEasy >= 2) return `Občutek: ključni treningi so se ti ${hardEasy}× zdeli lahki — cilji so morda prenizki. Ko bo na sporedu test FTP, ga naredi naspočit; vati se potem posodobijo.`
  return null
}

/**
 * Koliko lahkih treningov (po načrtu ali conah) je bilo v zadnjih `days` dneh (brez danes) ocenjenih »težko« ali »do konca«.
 * Za načrt: dva taka zapored sta znak utrujenosti, tudi ko je jutranji vnos v redu.
 */
export function easyFeltHard(acts: readonly Activity[], plan: readonly PlanDay[], today: string, days = 4): number {
  const from = addDays(today, -days), to = addDays(today, -1)
  const inWin = (date: string) => date >= from && date <= to
  let n = 0
  const counted = new Set<string>()
  for (const a of acts) {
    const r = cleanRpe(a.rpe)
    if (r == null || r < 8 || !inWin(a.date)) continue
    const day = dayOf(plan, a)
    if (meantEasy(a, day) === true) { n++; if (day) counted.add(day.id) }
  }
  for (const d of plan) {
    const r = cleanRpe(d.rpe)
    if (r == null || r < 8 || !d.done || !inWin(d.date) || counted.has(d.id)) continue
    const a = d.done.activityId ? acts.find(x => x.id === d.done!.activityId) : null
    if (a && cleanRpe(a.rpe) != null) continue
    if (meantEasy({ sport: 'kolo', hrZoneSec: null }, d) === true) n++
  }
  return n
}
