import type { Profile } from '../types'
import { bodyFatPct } from '../nutrition/body'

/**
 * (v3.49) LESTVICA TELESNE MAŠČOBE pod odgovorom trenerja (brez AI). Blaž je na »do kdaj bom izklesan, pokaži sliko«
 * dobil »zagotovim« in six-pack — zdaj aplikacija sama pokaže, kje je (ocena), kje se trebuh tipično pokaže in okvirni
 * čas kot razpon, nikoli obljube. Pod 18 let lestvice ni (rast, brez primanjkljaja); brez starosti ali spola tudi ne.
 */

const norm = (s: string) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd')
/** Vprašanje o videzu (slovenske oblike, tudi brez strešic). Ujemanje besed, brez »trebuh« sam zase (»boli me trebuh«). */
const LOOK_Q: readonly RegExp[] = [
  /izklesa/,
  /six[\s-]?pack|sixpack|six[\s-]?pak/,
  /trebusn\w*\s+misic/,
  /vidn\w*\s+(trebuh|trebusn|misic|kock)/,
  /kock\w*\s+na\s+trebuh/,
  /(kako|kaksen|kaksna|kaksne|kaj)\s+(bom|bi|bos)\s+(se\s+)?(iz|z)?gleda/,
  /(kako|kaksen|kaksna)\s+bom\s+videti/,
  /slik\w*\s+(sebe|mene|postav|telesa|kako\s+bom)/,
  /\bpostav[aeo]\b/,
  /\bdefiniran/,
  /mascob\w*\s+(okoli|na|pri|v)\s+(pas|trebuh|bok)/,
  /telesn\w*\s+mascob|odstot\w*\s+mascob|%\s*mascob/,
  /trebuh\w*.{0,30}\b(vid|pokaz|plosc)|\b(vid|pokaz|plosc)\w*.{0,30}trebuh/,
]
export function looksIntent(q: string): boolean {
  const t = norm(q)
  return LOOK_Q.some(r => r.test(t))
}

export interface FatBand { lo: number; hi: number | null; label: string; see: string }
/** Razponi in kaj se tipično vidi (moški, ženske) — od najnižjega do najvišjega. */
export const BANDS: Record<'m' | 'z', readonly FatBand[]> = {
  m: [
    { lo: 10, hi: 12, label: '10–12 %', see: 'Obrisi trebušnih mišic vidni tudi brez napenjanja, žile na rokah.' },
    { lo: 12, hi: 15, label: '12–15 %', see: 'Zgornje trebušne mišice se pokažejo ob dobri svetlobi, ramena in roke oblikovane.' },
    { lo: 15, hi: 20, label: '15–20 %', see: 'Trebuh ploščat, a brez obrisov; mišice rok in ramen se vidijo.' },
    { lo: 20, hi: 25, label: '20–25 %', see: 'Mehkejši trebuh in boki, obrisov mišic skoraj ni.' },
    { lo: 25, hi: null, label: 'nad 25 %', see: 'Maščoba okoli pasu in bokov je izrazita.' },
  ],
  z: [
    { lo: 15, hi: 18, label: '15–18 %', see: 'Zelo vitko, obrisi trebuha jasno vidni — za večino težko vzdržno.' },
    { lo: 18, hi: 21, label: '18–21 %', see: 'Pokažejo se obrisi trebušnih mišic, vidne mišice rok in nog.' },
    { lo: 21, hi: 25, label: '21–25 %', see: 'Vitko in čvrsto, trebuh ploščat, brez obrisov.' },
    { lo: 25, hi: 32, label: '25–32 %', see: 'Mehkejše oblike, maščoba na bokih in stegnih.' },
    { lo: 32, hi: null, label: 'nad 32 %', see: 'Maščoba okoli pasu, bokov in stegen je izrazita.' },
  ],
}
/** Kje se obrisi trebuha tipično pokažejo; cilj nikoli nižje od FLOOR. */
export const TARGET: Record<'m' | 'z', { lo: number; hi: number }> = { m: { lo: 10, hi: 12 }, z: { lo: 18, hi: 21 } }
/** (v3.50) Ploščat trebuh brez obrisov — prvi cilj pri vprašanju o maščobi okoli pasu (ne o trebušnih mišicah). */
export const WAIST_TARGET: Record<'m' | 'z', { lo: number; hi: number }> = { m: { lo: 15, hi: 20 }, z: { lo: 21, hi: 25 } }
/** Vprašanje o maščobi okoli pasu/bokov brez trebušnih mišic, six packa ali »izklesan«. */
export function waistIntent(q: string): boolean {
  const t = norm(q)
  return /mascob\w*\s+(okoli|na|pri|v)\s+(pas|trebuh|bok)|\bpas\w*\b.{0,20}mascob|obseg\w*\s+pas/.test(t) && !/six[\s-]?pa|trebusn\w*\s+misic|izklesa|kock|vidn\w*\s+(trebuh|trebusn|misic)|definiran/.test(t)
}
export const FLOOR: Record<'m' | 'z', number> = { m: 10, z: 16 }
/** zgornji rob zadnjega razpona na lestvici (za risanje) */
export const TOP: Record<'m' | 'z', number> = { m: 30, z: 38 }

/** Mesci pri ~0,5–1 odstotne točke na mesec ob zmernem primanjkljaju; null = že v razponu. */
export function monthsTo(nowPct: number, targetHi: number): { lo: number; hi: number } | null {
  const d = nowPct - targetHi
  if (!(d > 0)) return null
  return { lo: Math.max(1, Math.ceil(d / 1)), hi: Math.max(1, Math.ceil(d / 0.5)) }
}
const mesec = (n: number) => { const k = n % 100; return k === 1 ? 'mesec' : k === 2 ? 'meseca' : k === 3 || k === 4 ? 'mesece' : 'mesecev' }
export function monthsText(m: { lo: number; hi: number }): string {
  return `okvirno ${m.lo === m.hi ? m.lo : `${m.lo}–${m.hi}`} ${mesec(m.hi)} — ne obljuba`
}

export type BodyFatView =
  | { kind: 'minor'; text: string }
  | { kind: 'need'; text: string }
  | {
    kind: 'scale'; sex: 'm' | 'z'; bands: readonly FatBand[]; target: { lo: number; hi: number }; top: number
    /** zdaj: vpisana ali ocena (Deurenberg iz BMI, starosti in spola); null = ni višine ali teže */
    now: { pct: number; measured: boolean } | null
    months: { lo: number; hi: number } | null
    /** stavki pod lestvico */
    lines: string[]
  }

export const MINOR_TEXT = 'Telo še raste, zato ti lestvice maščobe ne pokažem. Zdaj štejejo moč, dovolj hrane (brez primanjkljaja) in spanec — trup krepiš z vajami za trebuh in hrbet.'
export const DEPENDS = 'Kdaj se trebuh pokaže, je odvisno od genetike, razporeditve maščobe in mišic — pri nekaterih šele nižje, pri drugih prej.'
export const STEPS = ['Obseg pasu enkrat na teden, zjutraj v višini popka — vpiši ga ob tehtanju.', 'Fotografija na 4 tedne: ista svetloba, ista poza.', 'Teža naj pada 0,3–0,5 kg na teden — hitreje gre tudi mišica.']

/**
 * Lestvica za profil; weightKg = zadnja teža (7-dnevno povprečje), sicer teža iz profila.
 * ask: vprašanje — (v3.50) pri maščobi okoli pasu je prvi cilj ploščat trebuh (ženske 21–25 %, moški 15–20 %), ne razpon
 * trebušnih mišic (prej 34 % → 18–21 % in »okvirno 13–26 mesecev«).
 */
export function bodyFatView(p: Pick<Profile, 'sex' | 'age' | 'heightCm' | 'weightKg' | 'bodyFatPct'>, weightKg?: number | null, ask?: string | null): BodyFatView {
  if (p.age != null && p.age < 18) return { kind: 'minor', text: MINOR_TEXT }
  if (!p.age || (p.sex !== 'm' && p.sex !== 'z')) return { kind: 'need', text: 'Lestvico telesne maščobe pokažem, ko v Nastavitvah vpišeš starost in spol.' }
  const sex = p.sex
  const kg = weightKg ?? p.weightKg ?? null
  // vpisana maščoba ima prednost (teža zanjo ni potrebna), sicer ocena iz BMI
  const now = kg ? bodyFatPct(p, kg) : bodyFatPct({ ...p, heightCm: null }, 0)
  const waist = !!ask && waistIntent(ask) && !!now && now.pct > WAIST_TARGET[sex].hi
  const tg = waist ? WAIST_TARGET[sex] : TARGET[sex]
  const target = { lo: Math.max(FLOOR[sex], tg.lo), hi: Math.max(FLOOR[sex], tg.hi) }
  const months = now ? monthsTo(now.pct, target.hi) : null
  const lines: string[] = []
  if (now && months) lines.push(`Pri zmernem primanjkljaju gre maščoba dol ~0,5–1 odstotne točke na mesec: ${monthsText(months)}.`)
  // (v3.50) en sam stavek o razponu: »si že v razponu« samo, ko časa do cilja ni (prej tudi ob »16–32 mesecev«)
  if (waist) lines.push(`Za ploščat trebuh je prvi cilj ~${target.lo}–${target.hi} %; obrisi trebušnih mišic se pokažejo šele pri ~${TARGET[sex].lo}–${TARGET[sex].hi} %.`)
  else if (now && !months) lines.push(`Si že v razponu, kjer se obrisi trebuha običajno pokažejo. Nižje od ${FLOOR[sex]} % ne ciljaj — naprej odločajo mišice trupa in razporeditev maščobe, ne hujšanje.`)
  else if (!now) lines.push('Za oceno, kje si zdaj, vpiši višino in težo (ali % maščobe) v Nastavitvah.')
  lines.push(DEPENDS)
  if (now && !now.measured) lines.push('»Zdaj« je ocena iz BMI, starosti in spola — pri mišičastih zgreši za nekaj odstotkov. Natančneje: vpiši % maščobe z vage ali kaliperja v Nastavitvah.')
  return { kind: 'scale', sex, bands: BANDS[sex], target, top: TOP[sex], now, months, lines }
}

/** Položaj na lestvici 0–1: razponi so enako široki (berljivo na telefonu), znotraj razpona linearno. */
export function scalePos(pct: number, bands: readonly FatBand[], top: number): number {
  const n = bands.length
  for (let i = 0; i < n; i++) {
    const b = bands[i]!, hi = b.hi ?? top
    if (pct <= hi || i === n - 1) return Math.max(0, Math.min(1, (i + Math.max(0, Math.min(1, (pct - b.lo) / (hi - b.lo)))) / n))
  }
  return 1
}
