import { EXERCISES, type ExDef } from '../training/exercises'

/**
 * (v3.49) Vaje iz knjižnice, ki jih omenja odgovor trenerja — pod odgovorom so ploščice s fotografijo ali figuro.
 * Ujemanje prenese slovenske sklone s preprostim deblom (»počep« → počepe, počepov; »mrtvi dvig« → mrtvega dviga;
 * »plezalec« → plezalca), kratke besede (na, z, s, za) morajo biti dobesedne, ena sama kratka beseda ne šteje.
 * Daljše ime ima prednost (»bolgarski počep« ni še »počep«). Kardio (tek, hoja, kolo) ni v knjižnici moči — ne šteje.
 */
const L = 'a-zčšžćđ'
const ENDS = ['ami', 'ega', 'emu', 'ima', 'imi', 'ih', 'om', 'em', 'ov', 'ev', 'mi', 'a', 'e', 'i', 'o', 'u']
const PREP = new Set(['z', 's', 'na', 'v', 'nad', 'pred', 'ali'])
const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')

function wordRx(w: string): string {
  if (w.length <= 3) return esc(w)
  // neobstojni e: plezalec → plezalca, čolniček → čolnička
  if (w.length >= 6 && /e[ck]$/.test(w)) return `${esc(w.slice(0, -2))}(?:e${w.slice(-1)}|${w.slice(-1)})[${L}]*`
  for (const e of ENDS) if (w.endsWith(e) && w.length - e.length >= 4) return `${esc(w.slice(0, -e.length))}[${L}]*`
  return `${esc(w)}[${L}]*`
}
const phraseRx = (p: string) => new RegExp(`(?<![${L}])${p.toLowerCase().split(/\s+/).filter(Boolean).map(wordRx).join('\\s+')}`, 'g')

/** Pogosta krajša imena (sicer samo polno ime in ime brez opreme na koncu, npr. »upogib za biceps«). */
const ALIAS: Record<string, readonly string[]> = {
  most: ['dvig bokov'], 'dvig-nog': ['dvig nog'], dipi: ['dipi'], coln: ['čolniček'], krozni: ['kolebnica'],
  bench: ['potisk na klopi', 'bench press'], 'nadglavo-r': ['potisk nad glavo'], 'veslanje-p': ['veslanje v predklonu'],
  odrocenje: ['odročenje'], metuljcek: ['metuljček'], 'kabel-zasuk': ['zasuki na kablu'], hiper: ['hiperekstenzija'],
}

type Entry = { id: string; words: number; len: number; rx: RegExp }
let TABLE: Entry[] | null = null
function table(): Entry[] {
  if (TABLE) return TABLE
  const seen = new Set<string>(), out: Entry[] = []
  const add = (id: string, phrase: string) => {
    const k = phrase.toLowerCase().trim()
    const w = k.split(/\s+/)
    // ena sama beseda: vsaj 4 črke (»most«, »dip« ne)
    if (!k || seen.has(k) || (w.length === 1 && k.length < 4)) return
    seen.add(k); out.push({ id, words: w.length, len: k.length, rx: phraseRx(k) })
  }
  for (const e of EXERCISES) add(e.id, e.name)
  for (const [id, xs] of Object.entries(ALIAS)) for (const x of xs) add(id, x)
  // ime brez opreme na koncu (»… z ročkami«, »… na napravi«), samo če ostaneta vsaj dve besedi
  for (const e of EXERCISES) {
    const w = e.name.toLowerCase().split(/\s+/)
    const cut = w.findIndex((x, i) => i >= 2 && PREP.has(x))
    if (cut >= 2) add(e.id, w.slice(0, cut).join(' '))
  }
  TABLE = out.sort((a, b) => b.words - a.words || b.len - a.len)
  return TABLE
}

/** Do `max` vaj po vrstnem redu omembe v besedilu. */
export function exercisesIn(text: string, max = 3): ExDef[] {
  let t = String(text || '').toLowerCase()
  if (!t.trim()) return []
  const hits: { at: number; id: string }[] = []
  for (const e of table()) {
    e.rx.lastIndex = 0
    let m: RegExpExecArray | null
    while ((m = e.rx.exec(t))) {
      hits.push({ at: m.index, id: e.id })
      // zadetek zakrij, da ga krajše ime (»počep« v »bolgarski počep«) ne ujame še enkrat
      t = t.slice(0, m.index) + ' '.repeat(m[0].length) + t.slice(m.index + m[0].length)
      e.rx.lastIndex = m.index + m[0].length
    }
  }
  const ids: string[] = []
  for (const h of hits.sort((a, b) => a.at - b.at)) if (!ids.includes(h.id)) ids.push(h.id)
  return ids.slice(0, max).map(id => EXERCISES.find(e => e.id === id)!).filter(Boolean)
}
