import type { Activity, DailyCheckin, MealEntry, PlanDay, Profile } from '../types'
import { addDays, fmtDur, formBand, formSeries, weekStartIso } from '../training/load'
import { weekContext } from '../training/planner'
import { checkRide, keyCompliance, zoneSplit } from '../training/review'
import { workText, zoneText } from '../training/zones'
import { dailyTarget, fueling, sumMeals, weightTrend } from '../nutrition/energy'
import { rideFuel, fuelCtxOf } from '../nutrition/dayplan'
import { recoveryOf, fmtSleep, type WellnessDay } from '../wellness'
import { readinessOf } from '../readiness'
import { clothing, wxShort, type DayWx } from '../weather'
import { rpeWarn, cleanRpe, rpeLabel } from './rpe'
import { stateNow } from '../training/state'

/**
 * TRENER BREZ AI. Ko AI ne odgovori (ponudnik ustavljen, ni prijave ali privolitve), hitra gumba »Kaj naj danes naredim?«
 * in »Pregled tedna« odgovorita iz načrta in tvojih podatkov — deterministično, brez ugibanja. Odgovori so označeni
 * (»iz načrta«) in NE gredo v AI (Trener jih izloči iz zgodovine, ki jo vidi model).
 */

export interface LocalCoachCtx {
  profile: Profile
  plan: readonly PlanDay[]
  activities: readonly Activity[]
  checkins: readonly DailyCheckin[]
  checkinToday: DailyCheckin | null
  wellness: readonly WellnessDay[] | null
  wellnessOn: boolean
  mealsToday: readonly MealEntry[]
  recentMeals: readonly MealEntry[]
  weather: Record<string, DayWx> | null
  today: string
}

const DOW = ['nedelja', 'ponedeljek', 'torek', 'sreda', 'četrtek', 'petek', 'sobota']
const dow = (iso: string) => DOW[new Date(iso + 'T12:00:00Z').getUTCDay()] ?? ''
const dm = (iso: string) => `${+iso.slice(8, 10)}. ${+iso.slice(5, 7)}.`
const n1 = (v: number) => String(Math.round(v * 10) / 10).replace('.', ',')
const kc = (v: number) => String(Math.round(v)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ')
const sgn = (v: number) => { const r = Math.round(v); return r > 0 ? `+${r}` : r < 0 ? `−${-r}` : '0' }

/** Glavna seja dneva: kolo/test pred močjo; neobvezno in počitek na koncu (kot Danes in Jutri). */
export function mainOf(plan: readonly PlanDay[], date: string): PlanDay | null {
  const prio = (d: PlanDay) => (d.kind === 'pocitek' ? 9 : d.optional ? 5 : d.kind === 'moc' ? 2 : 0)
  return [...plan.filter(d => d.date === date)].sort((a, b) => prio(a) - prio(b))[0] ?? null
}

function intensity(p: Profile, d: PlanDay): string | null {
  const w = workText(p, d)
  if (w) return `delovni del ${w}`
  if (d.kind === 'kolo' && d.zone && /^Z[1-5]$/.test(d.zone)) return `${d.zone} · ${zoneText(p, d.zone as 'Z2')}`
  return null
}

/** »Kaj naj danes naredim?« — seja, pripravljenost, forma, vreme, gorivo, hrana in jutri. */
export function localAdvice(c: LocalCoachCtx): string {
  const { profile: p, plan, today } = c
  const L: string[] = []
  const main = mainOf(plan, today)
  const extra = plan.filter(d => d.date === today && d !== main && d.kind === 'moc' && !d.optional)
  const series = formSeries(c.activities, today)
  const last = series[series.length - 1]
  const rec = c.wellnessOn ? recoveryOf(c.wellness, today, c.checkinToday?.sleepH ?? null) : null
  const ready = readinessOf(last ? last.tsb : null, c.checkinToday, rec)
  const wx = c.weather?.[today]

  if (!main) L.push('Za danes v načrtu ni ničesar — teden sestaviš v Planu (brez AI, takoj).')
  else if (main.kind === 'pocitek') L.push('Danes je počitek: hoja, raztezanje, spanec. Prilagoditev na trening se zgodi med počitkom — ne dodajaj.')
  else if (main.done) {
    const act = main.done.activityId ? c.activities.find(a => a.id === main.done!.activityId) : null
    const chk = act ? checkRide(main, act) : null
    L.push(`Današnji trening je opravljen: ${main.title}.${chk ? ` ${chk.verdict}.` : ''} Zdaj regeneracija: hrana, pijača, spanec.`)
  } else {
    const it = intensity(p, main)
    L.push(`Danes: ${main.title}${main.durationMin ? ` — ${fmtDur(main.durationMin)}` : ''}${main.optional ? ' (po želji)' : ''}.${it ? ` Cilj: ${it}.` : ''}`)
    if (main.exercises?.length) L.push(`Vaje: ${main.exercises.map(e => `${e.name} ${e.sets} × ${e.reps}`).join(', ')}.`)
    if (main.why) L.push(`Zakaj: ${main.why}`)
  }
  for (const x of extra) if (!x.done) L.push(`Dodatno: ${x.title} (${fmtDur(x.durationMin)}).`)
  // načrt je danes prilagojen počutju (jutranji vnos): kaj je šlo kam
  const sn = stateNow(plan, today)
  if (sn) L.push(`Prilagojeno tvojemu jutranjemu vnosu: ${sn.lines.join(' ')}`)

  if (ready && main && main.kind !== 'pocitek' && !main.done) {
    const why = ready.reasons.length ? ` (${ready.reasons.join(', ')}${rec?.sleepH != null ? `, ${fmtSleep(rec.sleepH)} spanca` : ''})` : ''
    L.push(ready.score < 45
      ? `Pripravljenost ${ready.score} — nizka${why}. Danes raje lažje: na Danes tapni »Olajšaj dan« ali naredi samo lahek del.`
      : ready.score < 60
        ? `Pripravljenost ${ready.score} — srednja${why}. Če se med ogrevanjem ne počutiš dobro, naredi manj; ključni del ne na silo.`
        : `Pripravljenost ${ready.score} — dobra. Pojdi po načrtu.`)
  }
  if (last && c.activities.length) {
    const b = formBand(last.tsb).band
    L.push(`Forma ${sgn(last.tsb)} (${b}) · kondicija ${Math.round(last.ctl)} · utrujenost ${Math.round(last.atl)}.${b === 'utrujen' ? ' Utrujenost je visoka — spanec in hrana sta danes pomembnejša od dodatnih minut.' : b === 'svež' ? ' Svež si — dober dan za kakovost, a ne dodajaj nad načrt.' : ''}`)
  }
  const outdoor = main && !main.done && (main.kind === 'kolo' || main.kind === 'tek' || main.kind === 'pohod')
  if (outdoor && wx) L.push(`Vreme: ${wxShort(wx)}. Obleci: ${clothing(wx)}.`)

  if (main && main.kind !== 'pocitek' && !main.done && !main.optional) {
    const f = fueling(main, p)
    const rf = rideFuel(main, p.fuelKit, fuelCtxOf(c.weather, c.recentMeals, main.date, today))
    if (f) L.push(`Pred: ${f.before}`)
    if (rf && rf.totalCarbs > 0) L.push(`Na kolesu: ~${rf.totalCarbs} g OH in ~${n1(rf.fluidMl / 1000)} l tekočine. Vzemi: ${rf.items.join('; ')}.`)
    else if (f) L.push(`Med: ${f.during}`)
    if (f) L.push(`Po: ${f.after}`)
  }

  const t = dailyTarget(p, c.activities.filter(a => a.date === today), plan.filter(d => d.date === today), today)
  if (t) {
    const e = sumMeals(c.mealsToday)
    const left = Math.max(0, t.kcal - e.kcal), leftP = Math.max(0, t.proteinG - Math.round(e.p))
    L.push(e.kcal > 0
      ? `Hrana: cilj ${kc(t.kcal)} kcal in ${t.proteinG} g beljakovin; vpisanih ${kc(e.kcal)} kcal in ${Math.round(e.p)} g — ostane ~${kc(left)} kcal in ${leftP} g beljakovin.`
      : `Hrana: cilj ${kc(t.kcal)} kcal in ${t.proteinG} g beljakovin (OH ${t.carbsG} g). Vpiši obroke, da vidiš, koliko ostane.`)
  }

  const tm = mainOf(plan, addDays(today, 1))
  if (tm) L.push(`Jutri: ${tm.kind === 'pocitek' ? 'počitek' : `${tm.title}${tm.durationMin ? `, ${fmtDur(tm.durationMin)}` : ''}`}.`)
  return L.join('\n')
}

/** »Pregled tedna« — opravljeno, ure, ključni treningi, intenzivnost, forma, teža, občutek (RPE) in kaj sledi. */
export function localReview(c: LocalCoachCtx): string {
  const { profile: p, plan, today } = c
  const ws = weekStartIso(today), we = addDays(ws, 6)
  const L: string[] = []
  const week = plan.filter(d => d.date >= ws && d.date <= we)
  const sessions = week.filter(d => d.kind !== 'pocitek' && !d.optional)
  const due = sessions.filter(d => d.date <= today)
  const done = sessions.filter(d => d.done).length
  const acts = c.activities.filter(a => a.date >= ws && a.date <= we)
  const bikeMin = acts.filter(a => a.sport === 'kolo').reduce((s, a) => s + (a.durationMin || 0), 0)
  const planBikeMin = sessions.filter(d => d.kind === 'kolo' || d.kind === 'test').reduce((s, d) => s + (d.durationMin || 0), 0)
  const tss = acts.reduce((s, a) => s + (a.tss || 0), 0)
  const cx = weekContext(p, ws)
  L.push(`Teden od ponedeljka ${dm(ws)}${cx.structured ? ` · ${cx.phaseName.toLowerCase()}${cx.total ? `, teden ${cx.week}/${cx.total}` : ''}${cx.recovery ? ' (razbremenilni)' : ''}` : ''}.`)
  if (!week.length) L.push('Ta teden še ni sestavljen — sestavi ga v Planu (brez AI, takoj).')
  else L.push(`Opravljeno ${done} od ${sessions.length} sej${due.length > done ? ` (do danes jih je bilo ${due.length})` : ''} · na kolesu ${fmtDur(bikeMin) === '—' ? '0 min' : fmtDur(bikeMin)} od ${fmtDur(planBikeMin)}${tss ? ` · ${Math.round(tss)} TSS` : ''}.`)

  const keys = keyCompliance(plan, c.activities, ws, addDays(today, -1))
  if (keys.total) {
    const word = (s: string) => (s === 'ok' ? 'po načrtu' : s === 'delno' ? 'delno' : s === 'drugace' ? 'drugače' : 'ni bilo')
    L.push(`Ključni: ${keys.items.map(i => `${i.title} (${dow(i.date).slice(0, 3)}) — ${word(i.status)}`).join('; ')}.`)
  }
  const zs = zoneSplit(c.activities.filter(a => a.date >= addDays(today, -13) && a.date <= today))
  if (zs && zs.minutes >= 60) L.push(`Intenzivnost zadnjih 14 dni: ${zs.easy} % lahko, ${zs.mid} % tempo, ${zs.hard} % prag in više — cilj ~80 % lahko.${zs.mid > 15 ? ' Veliko »sive cone«: lahke vožnje naj bodo res lahke, težke res težke.' : ''}`)

  const series = formSeries(c.activities, today)
  const last = series[series.length - 1], wk = series.length > 7 ? series[series.length - 8] : null
  if (last && c.activities.length) L.push(`Kondicija ${Math.round(last.ctl)}${wk ? ` (${sgn(last.ctl - wk.ctl)} v 7 dneh)` : ''} · utrujenost ${Math.round(last.atl)} · forma ${sgn(last.tsb)} (${formBand(last.tsb).band}).`)
  const tr = weightTrend(c.checkins)
  if (tr) L.push(`Teža ${n1(tr.avg7)} kg (7-dnevno povprečje)${tr.deltaWeek != null ? `, ${tr.deltaWeek > 0 ? '+' : tr.deltaWeek < 0 ? '−' : ''}${n1(Math.abs(tr.deltaWeek))} kg na teden` : ''}${p.targetWeightKg ? ` · cilj ${n1(p.targetWeightKg)} kg` : ''}.`)
  const rw = rpeWarn(c.activities, plan, today)
  if (rw) L.push(rw)

  const nextKey = plan.filter(d => d.date > today && (d.role === 'kljucna' || d.role === 'test') && !d.done).sort((a, b) => a.date.localeCompare(b.date))[0]
  if (nextKey) L.push(`Naslednji ključni: ${nextKey.title}, ${dow(nextKey.date)} ${dm(nextKey.date)}`)
  if (today >= addDays(ws, 5)) {
    const nx = weekContext(p, addDays(ws, 7))
    if (nx.structured) L.push(`Naslednji teden: ${nx.phaseName.toLowerCase()}${nx.recovery ? ' (razbremenilni)' : ''}, ~${n1(nx.hours)} h na kolesu.`)
  }
  return L.join('\n')
}

/**
 * Pretekli teden v treh vrsticah (za ponedeljek na Danes): seje in ure, ključni po načrtu, povprečen občutek.
 * null, če prejšnji teden ni imel načrta. Brez AI.
 */
export function lastWeekSummary(plan: readonly PlanDay[], acts: readonly Activity[], today: string): { from: string; lines: string[] } | null {
  const ws = addDays(weekStartIso(today), -7), we = addDays(ws, 6)
  const week = plan.filter(d => d.date >= ws && d.date <= we)
  const sessions = week.filter(d => d.kind !== 'pocitek' && !d.optional)
  if (!sessions.length) return null
  const done = sessions.filter(d => d.done).length
  const wa = acts.filter(a => a.date >= ws && a.date <= we)
  const bikeMin = wa.filter(a => a.sport === 'kolo').reduce((t, a) => t + (a.durationMin || 0), 0)
  const planBike = sessions.filter(d => d.kind === 'kolo' || d.kind === 'test').reduce((t, d) => t + (d.durationMin || 0), 0)
  const L = [`${done} od ${sessions.length} sej · na kolesu ${bikeMin ? fmtDur(Math.round(bikeMin)) : '0 min'} od ${fmtDur(planBike)}.`]
  const keys = keyCompliance(plan, acts, ws, we)
  if (keys.total) L.push(`Ključni in dolgi: ${keys.ok} od ${keys.total} po načrtu${keys.ok < keys.total ? ` (${keys.items.filter(i => i.status !== 'ok').map(i => `${i.title}: ${i.status === 'ni' ? 'ni bilo' : i.status === 'delno' ? 'delno' : 'drugače'}`).join('; ')})` : ''}.`)
  const rpes = [...wa.map(a => cleanRpe(a.rpe)), ...week.filter(d => d.done && !d.done.activityId).map(d => cleanRpe(d.rpe))].filter((x): x is number => x != null)
  if (rpes.length >= 2) { const avg = rpes.reduce((t, x) => t + x, 0) / rpes.length; L.push(`Občutek povprečno »${rpeLabel(avg)}« (${rpes.length} ocen).`) }
  return { from: ws, lines: L }
}
