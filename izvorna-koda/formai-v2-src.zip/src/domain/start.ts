import { addDays } from '@/domain/training/load'
import { isCustom } from '@/domain/focus/model'
import type { Profile } from '@/domain/types'

/*
 * (v3.49) Prvi dnevi z aplikacijo: »nimam ure« iz želje, prvi dan po uvodu, opomnik za varnostno kopijo brez računa.
 * Čiste funkcije — zasloni (Danes, Prvi koraki, vodnik) jih le berejo.
 */

/**
 * Kdor je v želji napisal »Nimam ure«, »brez ure«, »samo telefon«: brez koraka »Poveži uro«, vodnik govori o »Opravil«.
 * »Nimam ure na dan« ali »brez ure časa« je čas, ne ura.
 */
export function noWatchIn(wish: string | null | undefined): boolean {
  const w = String(wish || '').toLowerCase()
  if (/\bsamo\s+(?:s\s+)?telefon/.test(w)) return true
  return /(?:^|[^a-zčšž])(?:nimam|brez)\s+(?:pametne\s+|športne\s+|garmin\s+)?ure(?![a-zčšž])(?!\s+(?:na\s+(?:dan|teden)|časa|za|dnevno|tedensko|vsak))/.test(w)
    || /\bnimam\s+(?:garmina|pametne\s+ure|športne\s+ure)/.test(w)
}

/** Prvi dan po uvodu: dogovor je današnji, jutranjega vnosa pred danes pa ni (nov uporabnik, ne nov dogovor). */
export function firstDayOf(s: { today: string; profile: Pick<Profile, 'goalStart'>; checkins: readonly { date: string; mood?: unknown; soreness?: unknown }[] }): boolean {
  return s.profile.goalStart?.date === s.today && !s.checkins.some(c => c.date < s.today && (c.mood != null || c.soreness != null))
}

/**
 * (v3.50) Kolesar, ki je povedal, da nima tekme (»nimam tekme«, »ne tekmujem«, »brez tekem«) ali vozi za zdravje
 * (cilj zdravje brez tekme): brez pozivov k dirki na Danes (kartica cilja). Plan (»Nastavi dirko«) in vodnik sta drugje.
 */
export function noRaceWish(p: Pick<Profile, 'focus' | 'races'>): boolean {
  if ((p.races || []).length) return false
  const f = p.focus
  if (!f) return false
  const w = String(f.wish || '').toLowerCase()
  if (/(?:^|[^a-zčšž])(?:nimam|brez|ne\s+(?:bom\s+)?(?:imel|imam))\s+(?:nobene\s+|nobenih\s+|še\s+)?tekm/.test(w) || /\bne\s+tekmujem\b/.test(w)) return true
  return (f.aims || []).includes('zdravje') && !(f.aims || []).includes('tekma')
}

/**
 * (v3.50) Preproste besede namesto žargona (Z2, TSS) za načrt po meri brez povezane ure: začetnik, občasni ali kdor je
 * napisal »nimam ure« — »lahko« brez »(Z2)« in brez TSS. Izkušen ali z uro (intervals.icu) ostane, kot je.
 */
export function plainTerms(p: Pick<Profile, 'focus'>, intervalsOn: boolean): boolean {
  const f = p.focus
  return !!f && !intervalsOn && isCustom(p) && (f.level <= 2 || noWatchIn(f.wish))
}

/**
 * (v3.50) Namig za prvo težo pri vaji z utežjo, ko je še nikoli nisi vpisal (KG je bil prazen brez besede): s palico prazna
 * palica, sicer teža, s katero narediš vse ponovitve lepo.
 */
export function firstKgHint(name: string): string {
  return /palic/i.test(name)
    ? 'Prvič: začni s prazno palico (običajno 20 kg). Ko narediš vse ponovitve lepo, naslednjič dodaj 2,5 kg.'
    : 'Prvič: izberi težo, s katero narediš vse ponovitve lepo in ti ostaneta še 2–3 v rezervi. Ko gre zlahka, naslednjič več.'
}

/** Na Danes je kartica »Cilj sezone« (kolesar brez glavnega cilja, tekmovalni cilj) — isto pravilo kot v GoalCard. */
export function seasonCardOn(p: Pick<Profile, 'event' | 'goal'>): boolean {
  return !p.event?.date && (!p.goal || p.goal === 'dirka' || p.goal === 'hitrejsi')
}

/** Odlog opomnika za kopijo (KV, ISO datum, do katerega miruje). */
export const BACKUP_SNOOZE_KEY = 'backup.nudgeUntil'

/**
 * Opomnik za varnostno kopijo na Danes: brez računa, po 7 dneh uporabe, brez izvoza v zadnjih 30 dneh in ne med odlogom.
 * start = prvi dan uporabe (profil ustvarjen ali prvi dogovor).
 */
export function backupNudgeDue(o: { user: boolean; onboardingDone: boolean; start: string | null; today: string; lastExport: string | null; until: string | null }): boolean {
  if (o.user || !o.onboardingDone || !o.start) return false
  if (o.start > addDays(o.today, -7)) return false
  if (o.lastExport && o.lastExport.slice(0, 10) > addDays(o.today, -30)) return false
  return !o.until || o.until <= o.today
}

/** »Kasneje«: 30 dni miru; ko brskalnik podatkov ne zaščiti pred samodejnim brisanjem (persisted false), 14. */
export function backupSnooze(today: string, persisted: boolean | null): string {
  return addDays(today, persisted === false ? 14 : 30)
}
