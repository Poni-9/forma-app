import { getKV, setKV } from '@/data/db'

/**
 * Vreme za razporeditev tedna in prikaz: Open-Meteo, brez ključa, brez računa.
 * 7 dni: verjetnost padavin, temperatura, veter, koda. Predpomnjeno 3 ure na lokacijo.
 * Planer dolgo vožnjo postavi na najbolj suh dan; AI ob dežju predlaga trenažer.
 */
export type RainByDate = Record<string, number>
export interface DayWx { date: string; rain: number; tmax: number; tmin: number; wind: number; code: number }
export type Forecast = Record<string, DayWx>

const CODES: Record<number, string> = { 0: 'jasno', 1: 'pretežno jasno', 2: 'delno oblačno', 3: 'oblačno', 45: 'megla', 48: 'megla', 51: 'pršenje', 53: 'pršenje', 55: 'pršenje', 61: 'rahel dež', 63: 'dež', 65: 'močan dež', 66: 'leden dež', 67: 'leden dež', 71: 'sneg', 73: 'sneg', 75: 'močan sneg', 77: 'sodra', 80: 'plohe', 81: 'plohe', 82: 'nevihtne plohe', 85: 'snežne plohe', 86: 'snežne plohe', 95: 'nevihta', 96: 'nevihta s točo', 99: 'nevihta s točo' }
export function wxLabel(code: number): string { return CODES[code] || '' }
export function wxShort(d: DayWx | undefined | null): string {
  if (!d) return ''
  return `${wxLabel(d.code)} · ${d.tmin}–${d.tmax} °C${d.rain >= 30 ? ` · dež ${d.rain} %` : ''}${d.wind >= 30 ? ` · veter ${d.wind} km/h` : ''}`
}
/** Slabo za kolo zunaj: dež ≥ 60 %, veter ≥ 45 km/h ali mraz ≤ 2 °C. */
export function wxBad(d: DayWx | undefined | null): boolean { return !!d && (d.rain >= 60 || d.wind >= 45 || d.tmax <= 2) }

export async function forecast(lat: number, lon: number): Promise<Forecast> {
  const key = `wx7.${lat.toFixed(2)}.${lon.toFixed(2)}`
  const cached = await getKV<{ at: number; data: Forecast }>(key)
  if (cached && Date.now() - cached.at < 3 * 3600_000) return cached.data
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat.toFixed(3)}&longitude=${lon.toFixed(3)}&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max&timezone=auto&forecast_days=7`
  const r = await fetch(url)
  if (!r.ok) throw new Error('Vreme ni na voljo.')
  const js = await r.json() as { daily?: { time?: string[]; precipitation_probability_max?: (number | null)[]; temperature_2m_max?: (number | null)[]; temperature_2m_min?: (number | null)[]; wind_speed_10m_max?: (number | null)[]; weather_code?: (number | null)[] } }
  const d = js.daily || {}
  const out: Forecast = {}
  const t = d.time || []
  for (let i = 0; i < t.length; i++) {
    const date = t[i]!
    out[date] = { date, rain: d.precipitation_probability_max?.[i] ?? 0, tmax: Math.round(d.temperature_2m_max?.[i] ?? 0), tmin: Math.round(d.temperature_2m_min?.[i] ?? 0), wind: Math.round(d.wind_speed_10m_max?.[i] ?? 0), code: d.weather_code?.[i] ?? 0 }
  }
  await setKV(key, { at: Date.now(), data: out })
  return out
}

/** Samo verjetnost dežja po dnevih — kar rabi planer. */
export async function rainForecast(lat: number, lon: number): Promise<RainByDate> {
  const f = await forecast(lat, lon)
  const out: RainByDate = {}
  for (const k in f) out[k] = f[k]!.rain
  return out
}

/** Zadnja predpomnjena napoved brez omrežja (za izris). */
export async function cachedForecast(lat: number, lon: number): Promise<Forecast | null> {
  const c = await getKV<{ at: number; data: Forecast }>(`wx7.${lat.toFixed(2)}.${lon.toFixed(2)}`)
  return c ? c.data : null
}

/** Kraj → koordinate (Open-Meteo geocoding, brez ključa). */
export async function geocode(name: string): Promise<{ name: string; lat: number; lon: number } | null> {
  const r = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(name)}&count=1&language=sl&format=json`)
  if (!r.ok) return null
  const js = await r.json() as { results?: { name: string; latitude: number; longitude: number; admin1?: string }[] }
  const g = js.results?.[0]
  return g ? { name: g.name + (g.admin1 ? ', ' + g.admin1 : ''), lat: +g.latitude.toFixed(2), lon: +g.longitude.toFixed(2) } : null
}

/** Enkratno dovoljenje za lokacijo — samo za vreme; koordinate zaokrožimo na ~1 km in ne zapustijo naprave razen v vremenski poizvedbi. */
export function askLocation(): Promise<{ lat: number; lon: number } | null> {
  return new Promise(res => {
    if (!('geolocation' in navigator)) return res(null)
    navigator.geolocation.getCurrentPosition(
      pos => res({ lat: +pos.coords.latitude.toFixed(2), lon: +pos.coords.longitude.toFixed(2) }),
      () => res(null), { enableHighAccuracy: false, timeout: 8000, maximumAge: 3600_000 },
    )
  })
}
