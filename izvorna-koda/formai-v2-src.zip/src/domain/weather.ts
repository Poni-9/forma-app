import { getKV, setKV } from '@/data/db'

/**
 * Vreme za razporeditev tedna in prikaz: Open-Meteo, brez ključa, brez računa.
 * 7 dni po urah; za vsak dan povzamemo OKNO TRENINGA (npr. popoldne 13–18 h), ne celega dne —
 * dnevna koda Open-Meteo je najhujša koda dneva (jutranja megla → »megla« ob sončnem popoldnevu).
 * Danes: če je okno že mimo ali teče, velja stanje zdaj + preostanek okna. Predpomnjeno 1 uro na lokacijo in okno.
 * Planer dolgo vožnjo postavi na najbolj suh dan; AI ob dežju predlaga trenažer.
 */
export type RainByDate = Record<string, number>
export interface DayWx {
  date: string
  /** največja verjetnost padavin v oknu (%) */
  rain: number
  /** temperatura v oknu (°C) */
  tmax: number; tmin: number
  /** največji veter v oknu (km/h) */
  wind: number
  /** prevladujoča koda v oknu (če dežuje, koda dežja) */
  code: number
  /** okno treninga, npr. »popoldne« */
  win?: string
  /** stanje zdaj (samo danes) */
  now?: { t: number; code: number } | null
}
export type Forecast = Record<string, DayWx>
/** Okno treninga po urah [od, do) glede na navado. */
export type WxWindow = [number, number]
export const WINDOWS: Record<string, WxWindow> = { zjutraj: [7, 11], popoldne: [13, 18], zvecer: [17, 21] }
export const WINDOW_NAMES: Record<string, string> = { zjutraj: 'dopoldne', popoldne: 'popoldne', zvecer: 'zvečer' }
export function windowOf(trainTime: string | null | undefined): WxWindow { return WINDOWS[trainTime || 'popoldne'] || WINDOWS.popoldne! }

const CODES: Record<number, string> = { 0: 'jasno', 1: 'pretežno jasno', 2: 'delno oblačno', 3: 'oblačno', 45: 'megla', 48: 'megla', 51: 'pršenje', 53: 'pršenje', 55: 'pršenje', 61: 'rahel dež', 63: 'dež', 65: 'močan dež', 66: 'leden dež', 67: 'leden dež', 71: 'sneg', 73: 'sneg', 75: 'močan sneg', 77: 'sodra', 80: 'plohe', 81: 'plohe', 82: 'nevihtne plohe', 85: 'snežne plohe', 86: 'snežne plohe', 95: 'nevihta', 96: 'nevihta s točo', 99: 'nevihta s točo' }
export function wxLabel(code: number): string { return CODES[code] || '' }
export function wxShort(d: DayWx | undefined | null): string {
  if (!d) return ''
  const t = d.tmin === d.tmax ? `${d.tmax} °C` : `${d.tmin}–${d.tmax} °C`
  return `${wxLabel(d.code)} · ${t}${d.win ? ` ${d.win}` : ''}${d.rain >= 30 ? ` · dež ${d.rain} %` : ''}${d.wind >= 30 ? ` · veter ${d.wind} km/h` : ''}${d.now ? ` · zdaj ${d.now.t} °C${d.now.code !== d.code ? `, ${wxLabel(d.now.code)}` : ''}` : ''}`
}
/** Slabo za kolo zunaj: dež ≥ 60 %, veter ≥ 45 km/h ali mraz ≤ 2 °C. */
export function wxBad(d: DayWx | undefined | null): boolean { return !!d && (d.rain >= 60 || d.wind >= 45 || d.tmax <= 2) }

interface Hourly { time?: string[]; weather_code?: (number | null)[]; temperature_2m?: (number | null)[]; precipitation_probability?: (number | null)[]; wind_speed_10m?: (number | null)[] }
interface Current { time?: string; temperature_2m?: number | null; weather_code?: number | null }

/** Povzetek ur v oknu: prevladujoča koda (dež prevlada, če je verjetnost ≥ 50 %), razpon temperature, max padavine in veter. */
export function summarizeHours(date: string, rows: { code: number; t: number; rain: number; wind: number }[], win: string | undefined, now: { t: number; code: number } | null): DayWx {
  if (!rows.length) return { date, rain: 0, tmax: 0, tmin: 0, wind: 0, code: 0, win, now }
  const cnt = new Map<number, number>()
  for (const r of rows) cnt.set(r.code, (cnt.get(r.code) || 0) + 1)
  let code = [...cnt.entries()].sort((a, b) => b[1] - a[1] || b[0] - a[0])[0]![0]
  const rain = Math.max(...rows.map(r => r.rain))
  const wet = rows.filter(r => r.code >= 51).map(r => r.code)
  if (rain >= 50 && wet.length) code = Math.max(...wet)
  return { date, rain, tmax: Math.round(Math.max(...rows.map(r => r.t))), tmin: Math.round(Math.min(...rows.map(r => r.t))), wind: Math.round(Math.max(...rows.map(r => r.wind))), code, win, now }
}

export async function forecast(lat: number, lon: number, win: WxWindow = WINDOWS.popoldne!, winName?: string): Promise<Forecast> {
  const key = `wx7h.${lat.toFixed(2)}.${lon.toFixed(2)}.${win[0]}-${win[1]}`
  const cached = await getKV<{ at: number; data: Forecast }>(key)
  if (cached && Date.now() - cached.at < 3600_000) return cached.data
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat.toFixed(3)}&longitude=${lon.toFixed(3)}&hourly=weather_code,temperature_2m,precipitation_probability,wind_speed_10m&current=temperature_2m,weather_code&timezone=auto&forecast_days=7`
  const r = await fetch(url)
  if (!r.ok) throw new Error('Vreme ni na voljo.')
  const js = await r.json() as { hourly?: Hourly; current?: Current }
  const out = forecastFromHourly(js.hourly || {}, js.current || null, win, winName)
  await setKV(key, { at: Date.now(), data: out })
  return out
}

/** Iz urnih podatkov po dnevih; »zdaj« = čas iz odgovora (lokalni čas kraja). Čista funkcija za teste. */
export function forecastFromHourly(h: Hourly, cur: Current | null, win: WxWindow, winName?: string): Forecast {
  const byDay = new Map<string, { hour: number; code: number; t: number; rain: number; wind: number }[]>()
  const t = h.time || []
  for (let i = 0; i < t.length; i++) {
    const date = t[i]!.slice(0, 10), hour = +t[i]!.slice(11, 13)
    if (!byDay.has(date)) byDay.set(date, [])
    byDay.get(date)!.push({ hour, code: h.weather_code?.[i] ?? 0, t: h.temperature_2m?.[i] ?? 0, rain: h.precipitation_probability?.[i] ?? 0, wind: h.wind_speed_10m?.[i] ?? 0 })
  }
  const nowDate = cur?.time ? cur.time.slice(0, 10) : null, nowHour = cur?.time ? +cur.time.slice(11, 13) : null
  const out: Forecast = {}
  for (const [date, rows] of byDay) {
    let from = win[0], to = win[1]
    let now: { t: number; code: number } | null = null
    if (date === nowDate && nowHour != null) {
      now = { t: Math.round(cur?.temperature_2m ?? 0), code: cur?.weather_code ?? 0 }
      if (nowHour >= to) { from = nowHour; to = Math.min(24, nowHour + 3) }   // okno je mimo: naslednje 3 ure
      else if (nowHour > from) from = nowHour                                   // okno teče: od zdaj do konca
    }
    const inWin = rows.filter(r => r.hour >= from && r.hour < to)
    out[date] = summarizeHours(date, inWin.length ? inWin : rows, winName, now)
  }
  return out
}

/** Samo verjetnost dežja po dnevih — kar rabi planer. */
export async function rainForecast(lat: number, lon: number): Promise<RainByDate> {
  const f = await forecast(lat, lon)
  const out: RainByDate = {}
  for (const k in f) out[k] = f[k]!.rain
  return out
}

/** Zadnja predpomnjena napoved brez omrežja (za izris). */
export async function cachedForecast(lat: number, lon: number, win: WxWindow = WINDOWS.popoldne!): Promise<Forecast | null> {
  const c = await getKV<{ at: number; data: Forecast }>(`wx7h.${lat.toFixed(2)}.${lon.toFixed(2)}.${win[0]}-${win[1]}`)
  return c ? c.data : null
}

/** Kraj → koordinate (Open-Meteo geocoding, brez ključa). */
export async function geocode(name: string): Promise<{ name: string; lat: number; lon: number } | null> {
  const r = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(name)}&count=1&language=sl&format=json`)
  if (!r.ok) return null
  const js = await r.json() as { results?: { name: string; latitude: number; longitude: number; admin1?: string }[] }
  const g = js.results?.[0]
  return g ? { name: g.name + (g.admin1 ? ', ' + g.admin1 : ''), lat: +g.latitude.toFixed(2), lon: +g.longitude.toFixed(2) } : null
}

/** Enkratno dovoljenje za lokacijo — samo za vreme; koordinate zaokrožimo na ~1 km in ne zapustijo naprave razen v vremenski poizvedbi. */
export function askLocation(): Promise<{ lat: number; lon: number } | null> {
  return new Promise(res => {
    if (!('geolocation' in navigator)) return res(null)
    navigator.geolocation.getCurrentPosition(
      pos => res({ lat: +pos.coords.latitude.toFixed(2), lon: +pos.coords.longitude.toFixed(2) }),
      () => res(null), { enableHighAccuracy: false, timeout: 8000, maximumAge: 3600_000 },
    )
  })
}
