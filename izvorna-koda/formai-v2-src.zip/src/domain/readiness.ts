import type { DailyCheckin } from './types'
import type { Recovery } from './wellness'

/** Pripravljenost 0–100 iz forme, bolečin, spanca in energije — in podatkov ure (spanec, HRV, mirovni utrip), če so vklopljeni. */
export function readinessOf(tsb: number | null, c: DailyCheckin | null, rec?: Recovery | null): { score: number; label: string; color: string; reasons: string[] } | null {
  if (tsb == null && !c && !rec) return null
  let r = 60 + Math.max(-30, Math.min(30, tsb ?? 0)) * 1.2
  const why: string[] = []
  if (rec) { r -= rec.penalty; why.push(...rec.reasons) }
  if (c?.soreness) { r -= (c.soreness - 1) * 8; if (c.soreness >= 3) why.push('boleče mišice') }
  if (c?.sleepH) { if (c.sleepH <= 5) { r -= 15; why.push('malo spanja') } else if (c.sleepH === 6) { r -= 7; why.push('kratek spanec') } else if (c.sleepH >= 8) r += 4 }
  if (c?.mood) { if (c.mood <= 2) { r -= 10; why.push('malo energije') } else if (c.mood >= 4) r += 5 }
  if (tsb != null && tsb < -20) why.push('visoka utrujenost')
  let score = Math.round(Math.max(5, Math.min(100, r)))
  // telo ima zadnjo besedo: jasni znaki z ure (HRV, utrip, spanec) prevladajo nad svežino iz treninga
  if (rec && rec.penalty >= 20) score = Math.min(score, 44)
  else if (rec && rec.penalty >= 12) score = Math.min(score, 59)
  return { score, label: score >= 70 ? 'dobra' : score >= 45 ? 'srednja' : 'nizka', color: score >= 70 ? 'var(--ok)' : score >= 45 ? 'var(--warn)' : 'var(--bad)', reasons: why }
}
