import type { DailyCheckin } from './types'
import type { Recovery } from './wellness'

/**
 * Pripravljenost 0–100 iz forme, bolečin, spanca in energije — in podatkov ure (spanec, HRV, mirovni utrip), če so vklopljeni.
 * (v3.50) Brez jutranjega vnosa in brez ure je ni: forma sama (TSB) ne pove, kako si — prej je po prvem »Opravil«
 * iz nič skočil čip »pripravljenost 60« in ostal dneve.
 */
export function readinessOf(tsb: number | null, c: DailyCheckin | null, rec?: Recovery | null): { score: number; label: string; color: string; reasons: string[] } | null {
  // samo teža (npr. vpisana ob sestavi načrta) ni znak počutja — brez vnosa in ure pripravljenosti ni (prej »60«)
  const felt = !!c && (c.soreness != null || c.sleepH != null || c.mood != null)
  if (!felt && !rec) return null
  // svežina pomaga do +15; več pomeni dolgo brez treninga (kondicija pada), ne večjo pripravljenost
  let r = 60 + Math.max(-30, Math.min(15, tsb ?? 0)) * 1.2
  const why: string[] = []
  // (v3.50) »kondicija pada«, ne »forma pada« — forma je na istem zaslonu ploščica s +32 (prepočit)
  if (tsb != null && tsb >= 25) why.push('dolgo brez rednega treninga — kondicija pada')
  if (rec) { r -= rec.penalty; why.push(...rec.reasons) }
  if (c?.soreness) { r -= (c.soreness - 1) * 8; if (c.soreness >= 3) why.push('boleče mišice') }
  if (c?.sleepH) { if (c.sleepH <= 5) { r -= 15; why.push('malo spanja') } else if (c.sleepH === 6) { r -= 7; why.push('kratek spanec') } else if (c.sleepH >= 8) r += 4 }
  if (c?.mood) { if (c.mood <= 2) { r -= 10; why.push('malo energije') } else if (c.mood >= 4) r += 5 }
  if (tsb != null && tsb < -20) why.push('visoka utrujenost')
  let score = Math.round(Math.max(5, Math.min(100, r)))
  // telo ima zadnjo besedo: jasni znaki z ure (HRV, utrip, spanec) prevladajo nad svežino iz treninga
  if (rec && rec.penalty >= 20) score = Math.min(score, 44)
  else if (rec && rec.penalty >= 12) score = Math.min(score, 59)
  return { score, label: readinessLabel(score), color: score >= 70 ? 'var(--ok)' : score >= 45 ? 'var(--warn)' : 'var(--bad)', reasons: why }
}

/** (v3.50) Ena meja za besedo: »dobra« od 70, »srednja« od 45 — čip, list in trener brez AI povedo isto. */
export const readinessLabel = (score: number): 'dobra' | 'srednja' | 'nizka' => (score >= 70 ? 'dobra' : score >= 45 ? 'srednja' : 'nizka')
