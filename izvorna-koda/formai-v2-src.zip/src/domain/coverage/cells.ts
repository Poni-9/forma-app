import { decodePolyline, haversineM, type LatLon } from '../import/polyline'

/**
 * Karta pokritosti — celice, ne točke.
 * Lat/lon zaokrožimo na 4 decimalke (~11 m) in hranimo množico unikatnih celic.
 * 90 km vožnja ≈ 8.000 celic; 100+ voženj ≈ 150k celic — to je nekaj MB kot pakirana števila,
 * izris pa je unija množic, ne milijon točk. Surove koordinate NIKOLI ne gredo v oblak.
 */
export const CELL_DEC = 4
const SCALE = 10 ** CELL_DEC

/** Celica kot ena 53-bitna številka (lat in lon v 1e-4, zamaknjena v pozitivno). */
export function cellKey(lat: number, lon: number): number {
  const la = Math.round((lat + 90) * SCALE)    // 0 .. 1.8M
  const lo = Math.round((lon + 180) * SCALE)   // 0 .. 3.6M
  return la * 4_000_000 + lo
}
export function cellCenter(key: number): LatLon {
  const la = Math.floor(key / 4_000_000), lo = key % 4_000_000
  return [la / SCALE - 90, lo / SCALE - 180]
}

/** Vse celice, ki jih sled prečka — vključno z vmesnimi med točkama (da ni lukenj pri 20 m redčenju). */
export function cellsOfTrack(pts: readonly LatLon[], stepM = 8): Set<number> {
  const out = new Set<number>()
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i]!
    out.add(cellKey(a[0], a[1]))
    const b = pts[i + 1]
    if (!b) break
    const d = haversineM(a, b)
    const n = Math.min(60, Math.floor(d / stepM))
    for (let k = 1; k < n; k++) {
      const t = k / n
      out.add(cellKey(a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t))
    }
  }
  return out
}

export function cellsOfPolyline(encoded: string): Set<number> { return cellsOfTrack(decodePolyline(encoded)) }

/** Unija več množic celic. */
export function unionCells(sets: readonly Set<number>[]): Set<number> {
  const out = new Set<number>()
  for (const s of sets) for (const k of s) out.add(k)
  return out
}

/** Pakiranje za shrambo: sortirane delte v Uint32Array (delte so majhne → dobro stisljivo). */
export function packCells(cells: Set<number>): Uint32Array {
  const arr = Float64Array.from(cells).sort()
  const out = new Uint32Array(arr.length * 2)
  let prev = 0
  for (let i = 0; i < arr.length; i++) {
    const v = arr[i]!, d = v - prev
    out[i * 2] = Math.floor(d / 4_294_967_296)
    out[i * 2 + 1] = d >>> 0
    prev = v
  }
  return out
}
export function unpackCells(packed: Uint32Array): Set<number> {
  const out = new Set<number>()
  let prev = 0
  for (let i = 0; i < packed.length; i += 2) {
    const d = packed[i]! * 4_294_967_296 + packed[i + 1]!
    prev += d
    out.add(prev)
  }
  return out
}

/** Groba površina pokritosti v km² (celica ≈ 11 m × 11 m·cos φ). */
export function coverageAreaKm2(cells: Set<number>): number {
  let sum = 0
  for (const k of cells) { const [la] = cellCenter(k); sum += (11.1 * 11.1 * Math.cos(la * Math.PI / 180)) / 1e6 }
  return sum
}
