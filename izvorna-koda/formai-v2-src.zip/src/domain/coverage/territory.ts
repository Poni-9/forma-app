import type { Activity } from '../types'
import { cellCenter } from './cells'
import { addDays, todayIso } from '../training/load'

/**
 * »Ozemlje« v slogu INTVL: fine celice (~11 m) združimo v grobe ploščice (~100 m),
 * ki jih uporabnik doživlja kot osvojeno površino. Vsa igrifikacija je OSEBNA — ni
 * nasprotnikov, nič se ne resetira, nihče ti ne more ničesar vzeti.
 */
export const TERR_DEC = 3            // 1e-3° ≈ 111 m (S–J) × ~78 m (V–Z) na 46°
const T = 10 ** TERR_DEC

export function territoryKey(lat: number, lon: number): number {
  return Math.round((lat + 90) * T) * 400_000 + Math.round((lon + 180) * T)
}
export function territoryCenter(key: number): [number, number] {
  const la = Math.floor(key / 400_000), lo = key % 400_000
  return [la / T - 90, lo / T - 180]
}
/** Iz finih celic v grobe ploščice (unikatne). */
export function territoriesOf(cells: Set<number>): Set<number> {
  const out = new Set<number>()
  for (const k of cells) { const [la, lo] = cellCenter(k); out.add(territoryKey(la, lo)) }
  return out
}

/* ---------- nivo iz pobarvane površine ---------- */
export interface Level { n: number; name: string; minKm2: number; nextKm2: number | null; pct: number }
const LEVELS: [number, string][] = [
  [0, 'Prvi kilometri'], [0.5, 'Raziskovalec'], [2, 'Domačin'], [5, 'Kolesar občine'], [12, 'Kartograf'],
  [25, 'Regionalec'], [50, 'Osvajalec'], [100, 'Legenda pokrajine'], [200, 'Brez meja'],
]
export function levelFor(areaKm2: number): Level {
  let i = 0
  for (let k = 0; k < LEVELS.length; k++) if (areaKm2 >= LEVELS[k]![0]) i = k
  const cur = LEVELS[i]!, nxt = LEVELS[i + 1]
  const pct = nxt ? Math.max(0, Math.min(100, ((areaKm2 - cur[0]) / (nxt[0] - cur[0])) * 100)) : 100
  return { n: i + 1, name: cur[1], minKm2: cur[0], nextKm2: nxt ? nxt[0] : null, pct }
}

/* ---------- niz dni z aktivnostjo (vsaj 1 aktivnost na dan, dovoljen 1 prost dan vmes) ---------- */
export function streakDays(activities: readonly Pick<Activity, 'date' | 'source'>[], today = todayIso()): number {
  const days = new Set(activities.filter(a => a.source !== 'demo' || true).map(a => a.date))
  if (!days.size) return 0
  let streak = 0, gap = 0, d = today
  // danes še ni nujno opravljen — začni z včeraj, če danes ni nič
  if (!days.has(d)) d = addDays(d, -1)
  for (let i = 0; i < 400; i++) {
    if (days.has(d)) { streak++; gap = 0 }
    else { gap++; if (gap > 1) break }
    d = addDays(d, -1)
  }
  return streak
}

/* ---------- mesec ---------- */
export function monthStats(activities: readonly Pick<Activity, 'date' | 'distKm' | 'durationMin'>[], today = todayIso()) {
  const m = today.slice(0, 7)
  const inMonth = activities.filter(a => a.date.startsWith(m))
  const km = inMonth.reduce((s, a) => s + (a.distKm || 0), 0)
  const min = inMonth.reduce((s, a) => s + (a.durationMin || 0), 0)
  const prevM = addDays(today.slice(0, 7) + '-01', -1).slice(0, 7)
  const prevKm = activities.filter(a => a.date.startsWith(prevM)).reduce((s, a) => s + (a.distKm || 0), 0)
  return { km, min, n: inMonth.length, prevKm, goalKm: Math.max(50, Math.round((prevKm * 1.1) / 10) * 10) }
}
