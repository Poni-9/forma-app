/**
 * PREPROSTO POVEDANO. Uporabnik (4. 10.): »težko razumeti, kaj in kako se dogaja«. Tu so razlage izrazov in kako
 * aplikacija deluje — en vir za list »Kako deluje« in za tap na izraz (Z2, TSS, forma …). Brez številk uporabnika.
 */
import type { Profile } from './types'
import { isCustom } from './focus/model'
import { noPower } from './training/zones'

export type TermKey = 'cona' | 'ftp' | 'wkg' | 'tss' | 'forma' | 'kondicija' | 'pripravljenost' | 'kljucni' | 'faze' | 'razbremenilni' | 'oh' | 'deficit' | 'test'

export const TERMS: readonly { k: TermKey; t: string; d: string }[] = [
  { k: 'cona', t: 'Cone (Z1–Z5) — kako težko', d: 'Z1 zelo lahko (samo vrtenje) · Z2 lahko (še lahko govoriš v celih stavkih — večina treninga) · Z3 zmerno · Z4 težko (rečeš le nekaj besed) · Z5 zelo težko (kratki napori). Tvoje meje v utripu in vatih so v Napredku → Tvoje cone.' },
  { k: 'kljucni', t: 'Ključni trening', d: 'Najpomembnejši trening tedna — intervali ali dolga vožnja. Ostale vožnje so lahke. Če ključnega izpustiš, ga prestavim na prvi primeren dan tega tedna.' },
  { k: 'ftp', t: 'FTP', d: 'Največja moč v vatih, ki jo zdržiš približno eno uro. Iz nje so izračunane cone in napredek. Izmeriš jo z 20-minutnim testom (95 % povprečne moči).' },
  { k: 'wkg', t: 'W/kg', d: 'FTP, deljen s težo — kako hitro greš v klanec. Povprečen amater 2,5–3,2, dober 3,3–3,7, top amater 3,8–4,3, profesionalec 5–6,5. Raste z vati ali z manj kilogrami.' },
  { k: 'tss', t: 'TSS — obremenitev', d: 'Koliko te je trening utrudil. Ena ura na polno (pri FTP) = 100; ura lahke vožnje ~40–50. Iz njih se računa forma.' },
  { k: 'forma', t: 'Forma', d: 'Kondicija minus utrujenost. Plus pomeni spočit, minus utrujen. Med treningi je normalno malo v minusu; pred tekmo želiš +5 do +25.' },
  { k: 'kondicija', t: 'Kondicija in utrujenost', d: 'Kondicija je povprečna obremenitev zadnjih 6 tednov (kar si zgradil), utrujenost zadnjega tedna (kar te še teži). Kondicija raste počasi, utrujenost hitro pade s počitkom.' },
  { k: 'pripravljenost', t: 'Pripravljenost (0–100)', d: 'Kako pripravljen si danes: iz jutranjega vnosa (energija, mišice, spanec), forme in ure (spanec, HRV), če jo povežeš. Pod 45 je današnji trening lažji.' },
  { k: 'faze', t: 'Faze sezone', d: 'Off-season (počitek po sezoni) → osnova (veliko lahkih ur, temelj) → gradnja (več intervalov) → specifično (kot na tvoji dirki) → tapering (manj, da si na dirki spočit).' },
  { k: 'razbremenilni', t: 'Razbremenilni teden', d: 'Vsak četrti teden je lažji. Telo napreduje med počitkom, ne med treningom — zato ga ne preskakuj.' },
  { k: 'test', t: 'Test FTP', d: 'Po ogrevanju 20 minut enakomerno na polno. FTP je 95 % povprečne moči. Vsakih ~8 tednov, da so cone pravilne.' },
  { k: 'oh', t: 'OH — ogljikovi hidrati', d: 'Gorivo za trening (kruh, riž, testenine, sadje). Banana ima ~25 g. Na dolgi vožnji od 30. minute 40–80 g na uro.' },
  { k: 'deficit', t: 'Deficit', d: 'Koliko manj poješ, kot porabiš — tako hujšaš. Nikoli na kolesu in nikoli pod varno mejo; največ 750 kcal na dan.' },
]

export function termOf(k: TermKey) { return TERMS.find(x => x.k === k)! }

/** Kako deluje — kratko, v korakih (list »Kako deluje«). */
export const HOW: readonly { t: string; d: string }[] = [
  { t: 'Vsak dan ti povem, kaj narediti', d: 'Iz tvojega cilja (npr. dirke) in ur na teden sestavim trening za vsak dan. Na Danes je današnji, v Planu cel teden.' },
  { t: 'Zjutraj povej, kako si', d: 'Če te bolijo noge ali si slabo spal, današnji trening olajšam ali prestavim — in napišem, kaj in zakaj.' },
  { t: 'Po treningu', d: 'Z uro (Garmin Connect neposredno ali prek intervals.icu) se vožnja uvozi sama in odkljuka dan. Brez ure tapni »Opravil«.' },
  { t: 'Ko kaj izpustiš ali je pretežko', d: 'Ključni trening prestavim na prvi primeren lahek dan tega tedna (sicer odpade); po pretežki vožnji je naslednji dan lažji. Vse spremembe so v Planu → »Spremembe načrta«, z možnostjo razveljavitve.' },
  { t: 'Hrana', d: 'Obroč pove, koliko še poješ danes — trening je že vštet. Obrok slikaj, opiši ali vpiši; vsako številko lahko popraviš.' },
  { t: 'Trener', d: 'Vprašaj karkoli o svojem treningu in prehrani — odgovori iz tvojih podatkov.' },
  { t: 'Nekaj ni jasno ali ne dela?', d: 'Tapni »Pripomba« (oblaček zgoraj) — napišeš ali poveš, posnetek zaslona se doda sam. Gre naravnost razvijalcu.' },
]

/** (v3.48) Načrt po meri brez kolesa (fitnes, tek, hribi): »Kako deluje« brez dirke in voženj. */
const HOW_GENERAL: Partial<Record<number, { t: string; d: string }>> = {
  0: { t: 'Vsak dan ti povem, kaj narediti', d: 'Iz tvojega dogovora in časa, ki ga imaš, sestavim trening za vsak dan. Na Danes je današnji, v Planu cel teden.' },
  2: { t: 'Po treningu', d: 'Z uro se trening uvozi sam in odkljuka dan. Brez ure tapni »Opravil«.' },
  3: { t: 'Ko kaj izpustiš ali je pretežko', d: 'Ključni trening prestavim na prvi primeren lahek dan tega tedna (sicer odpade); po pretežki vadbi je naslednji dan lažji. Vse spremembe so v Planu → »Spremembe načrta«, z možnostjo razveljavitve.' },
}
/** (v3.48) Izrazi za načrt po meri brez kolesa: brez FTP, W/kg, testa FTP, OH na kolesu in faz do dirke; ostali splošno. */
const TERMS_GENERAL: Partial<Record<TermKey, string>> = {
  cona: 'Z1 zelo lahko · Z2 lahko (še lahko govoriš v celih stavkih — večina kardia) · Z3 zmerno · Z4 težko (rečeš le nekaj besed) · Z5 zelo težko (kratki napori). Če poznaš svoj utrip, so tvoje meje v Napredku → Tvoje cone.',
  kljucni: 'Najpomembnejši trening tedna — intervali ali dolga vadba. Ostali so lažji. Če ključnega izpustiš, ga prestavim na prvi primeren dan tega tedna.',
  tss: 'Koliko te je trening utrudil. Ena ura na pragu (najtežje, kar zdržiš eno uro) = 100; ura lahkega kardia ~40–50. Iz njih se računa forma.',
  forma: 'Kondicija minus utrujenost. Plus pomeni spočit, minus utrujen. Med treningi je normalno malo v minusu; pred tekmo ali testom želiš plus.',
  deficit: 'Koliko manj poješ, kot porabiš — tako hujšaš. Na dan težke vadbe manj, nikoli pod varno mejo; največ 750 kcal na dan.',
}
const BIKE_ONLY: readonly TermKey[] = ['ftp', 'wkg', 'test', 'oh', 'faze']
/** (v3.50) Kolesar brez merilnika moči: test meri pražni utrip, FTP ni izmerjen — cone so po utripu (prej »95 % povprečne moči«). */
const TERMS_NO_POWER: Partial<Record<TermKey, string>> = {
  test: 'Po ogrevanju 20 minut enakomerno na polno. Brez merilnika moči je povprečni utrip zadnjih 15 min tvoj pražni utrip — iz njega so cone. Vsakih ~8 tednov.',
  ftp: 'Največja moč v vatih, ki jo zdržiš približno eno uro. Brez merilnika moči je ne poznamo — tvoje cone so po utripu (Napredek → Tvoje cone). Z merilnikom jo izmeriš z 20-minutnim testom (95 % povprečne moči).',
}

/**
 * »Kako deluje« in izrazi za tega uporabnika: kolesar (tudi načrt po meri s kolesom) dobi kolesarsko različico,
 * načrt po meri brez kolesa splošno. Izraz, ki ga je tapnil (`keep`), ostane vedno.
 * (v3.50) Kolesar brez merilnika moči: test FTP in FTP po utripu (brez podatkov o opremi ostane kolesarska različica).
 */
export function helpFor(p: Pick<Profile, 'focus'> & { gear?: Profile['gear'] | null; ftp?: number | null }, keep?: TermKey | null): { how: readonly { t: string; d: string }[]; terms: readonly { k: TermKey; t: string; d: string }[] } {
  if (!isCustom(p) || (p.focus?.sports || []).includes('kolo')) {
    const np = p.gear ? noPower(p) : false
    return { how: HOW, terms: np ? TERMS.map(x => (TERMS_NO_POWER[x.k] ? { ...x, d: TERMS_NO_POWER[x.k]! } : x)) : TERMS }
  }
  return {
    how: HOW.map((h, i) => HOW_GENERAL[i] ?? h),
    terms: TERMS.filter(x => !BIKE_ONLY.includes(x.k) || x.k === keep).map(x => (TERMS_GENERAL[x.k] ? { ...x, d: TERMS_GENERAL[x.k]! } : x)),
  }
}
