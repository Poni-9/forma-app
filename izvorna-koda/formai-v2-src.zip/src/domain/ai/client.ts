import { idToken } from '@/data/firebase'

/** Cloud Run posrednik — ključ do Gemini je na strežniku, nikoli v odjemalcu. */
const PROXY = 'https://forma-ai-proxy-602565779369.europe-west1.run.app'
const DEFAULT_MODEL = 'gemini-flash-latest'

/** Del poziva. inlineData.data je base64 BREZ predpone data:. */
export type AiPart = { text: string } | { inlineData: { mimeType: string; data: string } }

export type AiErrorKind = 'auth' | 'quota' | 'network' | 'parse' | 'consent'

export class AiError extends Error {
  kind: AiErrorKind
  constructor(kind: AiErrorKind, message: string) {
    super(message)
    this.name = 'AiError'
    this.kind = kind
  }
}

/** Statusi, pri katerih ima ponovni poskus smisel. 402 in 401 sta dokončna. */
const RETRY_STATUS = new Set([429, 500, 502, 503, 504])
const BACKOFF = [1500, 3000]

const MSG_AUTH = 'Za AI se moraš prijaviti.'
const MSG_QUOTA = 'Dnevna AI kvota (10 klicev) je porabljena. Za neomejeno v Firebase konzoli (c-vaje → Firestore) ustvari proUsers/<uid> s poljem pro: true — uid je v Nastavitvah.'

function sleep(ms: number): Promise<void> {
  return new Promise(r => setTimeout(r, ms))
}

async function token(): Promise<string> {
  let t: string | null = null
  try { t = await idToken() } catch { t = null }
  if (!t) throw new AiError('auth', MSG_AUTH)
  return t
}

/** Ali je AI sploh na voljo — torej ali je uporabnik prijavljen. */
export async function aiAvailable(): Promise<boolean> {
  try { return !!(await idToken()) } catch { return false }
}

interface GeminiPart { text?: string }
interface GeminiCandidate { content?: { parts?: GeminiPart[] }; finishReason?: string }
interface GeminiResponse {
  candidates?: GeminiCandidate[]
  promptFeedback?: { blockReason?: string }
  text?: string
  error?: { message?: string }
}

function textOf(js: unknown): string {
  if (typeof js === 'string') return js
  const r = (js || {}) as GeminiResponse
  const blocked = r.promptFeedback?.blockReason
  if (blocked) throw new AiError('parse', 'Model je zavrnil odgovor na to vsebino.')
  const cand = r.candidates && r.candidates.length ? r.candidates[0] : undefined
  const parts = cand?.content?.parts
  if (parts && parts.length) {
    const joined = parts.map(p => (typeof p.text === 'string' ? p.text : '')).join('').trim()
    if (joined) return joined
  }
  if (typeof r.text === 'string' && r.text.trim()) return r.text.trim()
  throw new AiError('parse', 'AI ni vrnil besedila.')
}

interface CallOpts { model?: string; temp?: number; json?: boolean }

async function call(parts: AiPart[], opts: CallOpts): Promise<string> {
  const tok = await token()
  const gen: Record<string, unknown> = {}
  if (opts.temp != null) gen.temperature = opts.temp
  if (opts.json) gen.response_mime_type = 'application/json'
  const body: Record<string, unknown> = { contents: [{ role: 'user', parts }] }
  if (Object.keys(gen).length) body.generationConfig = gen
  const payload = JSON.stringify({ model: opts.model || DEFAULT_MODEL, body })

  let last: AiError = new AiError('network', 'AI ni odgovoril.')
  for (let attempt = 0; attempt <= BACKOFF.length; attempt++) {
    const wait = BACKOFF[attempt]
    let res: Response
    try {
      res = await fetch(`${PROXY}/api/gemini`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tok}` },
        body: payload,
      })
    } catch {
      last = new AiError('network', 'Ni povezave s strežnikom. Preveri internet in poskusi znova.')
      if (wait != null) { await sleep(wait); continue }
      throw last
    }
    if (res.status === 402) throw new AiError('quota', MSG_QUOTA)
    if (res.status === 401 || res.status === 403) throw new AiError('auth', MSG_AUTH)
    if (res.ok) {
      let js: unknown
      try { js = await res.json() } catch { throw new AiError('parse', 'AI odgovor ni bil berljiv.') }
      return textOf(js)
    }
    if (RETRY_STATUS.has(res.status)) {
      last = new AiError('network', `Strežnik trenutno ne zmore odgovoriti (HTTP ${res.status}). Poskusi čez minuto.`)
      if (wait != null) { await sleep(wait); continue }
      throw last
    }
    throw new AiError('network', `Napaka AI storitve (HTTP ${res.status}).`)
  }
  throw last
}

export async function askText(parts: AiPart[], opts?: { model?: string; temp?: number }): Promise<string> {
  return call(parts, { model: opts?.model, temp: opts?.temp })
}

/* Lestev popravkov JSON-a. Modela NIKOLI ne kličemo znova za popravilo — to podvoji strošek. */
function stripFences(s: string): string {
  const m = s.match(/```(?:json|JSON)?\s*([\s\S]*?)```/)
  return m && m[1] ? m[1] : s
}
function straightQuotes(s: string): string {
  return s.replace(/[“”„‟″]/g, '"').replace(/[‘’‚‛]/g, "'")
}
function dropTrailingCommas(s: string): string {
  return s.replace(/,(\s*[}\]])/g, '$1')
}
function sliceToBraces(s: string): string {
  const a = s.indexOf('{'), b = s.lastIndexOf('}')
  const c = s.indexOf('['), d = s.lastIndexOf(']')
  const objOk = a >= 0 && b > a
  const arrOk = c >= 0 && d > c
  if (objOk && (!arrOk || a < c)) return s.slice(a, b + 1)
  if (arrOk) return s.slice(c, d + 1)
  return s
}

function parseLoose<T>(raw: string): T | undefined {
  const s0 = raw.trim()
  const s1 = stripFences(s0).trim()
  const s2 = sliceToBraces(s1).trim()
  const s3 = straightQuotes(s2)
  const s4 = dropTrailingCommas(s3)
  for (const cand of [s0, s1, s2, s3, s4]) {
    if (!cand) continue
    try { return JSON.parse(cand) as T } catch { /* naslednja stopnja */ }
  }
  return undefined
}

export async function askJson<T>(parts: AiPart[], opts?: { model?: string; temp?: number }): Promise<T> {
  const raw = await call(parts, { model: opts?.model, temp: opts?.temp, json: true })
  const parsed = parseLoose<T>(raw)
  if (parsed === undefined) throw new AiError('parse', 'AI odgovor ni bil v pričakovani obliki. Poskusi znova.')
  return parsed
}
