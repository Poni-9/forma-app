import { idToken } from '@/data/firebase'
import { PROXY, FREE_AI_PER_DAY } from '@/config'
import { plural, W, NBSP } from '@/ui/format'

/** Cloud Run posrednik (PROXY) — ključ do Gemini je na strežniku, nikoli v odjemalcu. */
const DEFAULT_MODEL = 'gemini-flash-latest'
/**
 * Rezervni model: ko je najnovejši Flash preobremenjen (503 »high demand«) ali je njegova kvota polna (429),
 * gre isti zahtevek takoj na starejši, stabilen Flash (nameščeni strežnik upošteva izbiro modela).
 */
export const FALLBACK_MODEL = 'gemini-2.5-flash'
/** Časovna omejitev enega klica AI (slika + dolg kontekst lahko traja; dlje ne čakamo). */
export const AI_TIMEOUT_MS = 90_000

/** Del poziva. inlineData.data je base64 BREZ predpone data:. */
export type AiPart = { text: string } | { inlineData: { mimeType: string; data: string } }

// (v3.51) razred napake je v errors.ts — začetni paket (useAi) ga rabi brez celotnega odjemalca
import { AiError, type AiErrorKind } from './errors'
export { AiError, type AiErrorKind }

/** Statusi, pri katerih ima ponovni poskus smisel. 402 in 401 sta dokončna. */
const RETRY_STATUS = new Set([429, 500, 502, 503, 504])
const BACKOFF = [1500, 3000]

const MSG_AUTH = 'Za AI se moraš prijaviti.'
/** Dnevna meja strežnika; število iz odgovora (novejši strežnik ga pošlje) ali iz nastavitve, sicer brez števila. */
export function quotaMsg(limit?: number | null): string {
  const n = typeof limit === 'number' && limit > 0 ? limit : FREE_AI_PER_DAY
  return n ? `Današnja kvota AI (${n}${NBSP}${plural(n, W.dejanjeR)}) je porabljena — nova se odpre jutri.` : 'Današnja kvota AI je porabljena — nova se odpre jutri.'
}
/** Ponudnik AI je ustavil storitev (npr. porabljeno predplačilo pri Googlu → Gemini vrne 402). Ni uporabnikova kvota. */
export const MSG_PROVIDER = 'AI je trenutno ustavljen pri ponudniku (ne pri tebi) — popravljamo. Poskusi čez nekaj ur.'
const MSG_TIMEOUT = 'AI se ni odzval v 90 sekundah — poskusi znova čez minuto.'
/** (v3.49) preobremenjen strežnik ali model — brez »HTTP 503«, ki uporabniku nič ne pove */
const MSG_BUSY = 'AI zdaj ne more odgovoriti — poskusi čez minuto.'

/** AbortSignal s časovno omejitvijo (AbortSignal.timeout ali nadomestek za starejše brskalnike). */
function timeoutSignal(ms: number): AbortSignal | undefined {
  try {
    const T = (AbortSignal as unknown as { timeout?: (ms: number) => AbortSignal }).timeout
    if (typeof T === 'function') return T.call(AbortSignal, ms)
    const ac = new AbortController(); setTimeout(() => ac.abort(), ms); return ac.signal
  } catch { return undefined }
}

function sleep(ms: number): Promise<void> {
  return new Promise(r => setTimeout(r, ms))
}

async function token(force = false): Promise<string> {
  // samo testna gradnja (VITE_E2E=1 vite build): AI gre na prestreženi strežnik — v pravi gradnji te vrstice ni
  if (import.meta.env.VITE_E2E === '1') return 'e2e'
  let t: string | null = null
  try { t = await idToken(force) } catch { t = null }
  if (!t) throw new AiError('auth', MSG_AUTH)
  return t
}

/** Ali je AI sploh na voljo — torej ali je uporabnik prijavljen. */
export async function aiAvailable(): Promise<boolean> {
  try { return !!(await idToken()) } catch { return false }
}

interface GeminiPart { text?: string }
interface GeminiCandidate { content?: { parts?: GeminiPart[] }; finishReason?: string }
interface GeminiResponse {
  candidates?: GeminiCandidate[]
  promptFeedback?: { blockReason?: string }
  text?: string
  error?: { message?: string }
}

function textOf(js: unknown): string {
  if (typeof js === 'string') return js
  const r = (js || {}) as GeminiResponse
  const blocked = r.promptFeedback?.blockReason
  if (blocked) throw new AiError('parse', 'Model je zavrnil odgovor na to vsebino.')
  const cand = r.candidates && r.candidates.length ? r.candidates[0] : undefined
  const parts = cand?.content?.parts
  if (parts && parts.length) {
    const joined = parts.map(p => (typeof p.text === 'string' ? p.text : '')).join('').trim()
    if (joined) return joined
  }
  if (typeof r.text === 'string' && r.text.trim()) return r.text.trim()
  throw new AiError('parse', 'AI ni vrnil besedila.')
}

interface CallOpts { model?: string; temp?: number; json?: boolean }

async function call(parts: AiPart[], opts: CallOpts): Promise<string> {
  let tok = await token()
  let refreshed = false
  const gen: Record<string, unknown> = {}
  if (opts.temp != null) gen.temperature = opts.temp
  if (opts.json) gen.response_mime_type = 'application/json'
  const body: Record<string, unknown> = { contents: [{ role: 'user', parts }] }
  if (Object.keys(gen).length) body.generationConfig = gen
  let model = opts.model || DEFAULT_MODEL

  let last: AiError = new AiError('network', 'AI ni odgovoril.')
  for (let attempt = 0; attempt <= BACKOFF.length; attempt++) {
    const wait = BACKOFF[attempt]
    const payload = JSON.stringify({ model, body })
    let res: Response
    try {
      res = await fetch(`${PROXY}/api/gemini`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tok}` },
        body: payload,
        signal: timeoutSignal(AI_TIMEOUT_MS),
      })
    } catch (e) {
      // časovna omejitev: ne ponavljamo (vsak poskus bi spet čakal 90 s)
      const n = (e as { name?: unknown } | null)?.name
      if (n === 'TimeoutError' || n === 'AbortError') throw new AiError('network', MSG_TIMEOUT)
      last = new AiError('network', 'Ni povezave s strežnikom. Preveri internet in poskusi znova.')
      if (wait != null) { await sleep(wait); continue }
      throw last
    }
    if (res.status === 402) {
      // naš strežnik: {error:'limit'} = dnevna kvota; vse drugo (Gemini: »prepayment credits are depleted«) je ponudnik
      let js: { error?: unknown; limit?: unknown } | null = null
      try { js = await res.json() } catch { js = null }
      if (js && js.error === 'limit') throw new AiError('quota', quotaMsg(typeof js.limit === 'number' ? js.limit : null))
      throw new AiError('network', MSG_PROVIDER)
    }
    if (res.status === 401 || res.status === 403) {
      // naš strežnik: {error:'prijava_potrebna'|'neveljaven_token'} = prijava. Googlova napaka ({error:{status,…}}, npr.
      // 401 ACCESS_TOKEN_TYPE_UNSUPPORTED, 403 PERMISSION_DENIED) = ključ na strežniku, ne uporabnik (prej: »Za AI se moraš prijaviti.«)
      let js: { error?: unknown } | null = null
      try { js = await res.clone().json() } catch { js = null }
      if (js && typeof js.error === 'object' && js.error) throw new AiError('network', MSG_PROVIDER)
      // potekel ali zavrnjen žeton: enkrat z osveženim, šele nato »prijavi se«
      if (js && js.error === 'neveljaven_token' && !refreshed) { refreshed = true; tok = await token(true); attempt--; continue }
      throw new AiError('auth', MSG_AUTH)
    }
    if (res.status === 400) {
      // starejši strežnik posreduje napako Googla: neveljaven ali izbrisan ključ ni napaka uporabnika
      let js: { error?: unknown } | null = null
      try { js = await res.clone().json() } catch { js = null }
      const e = js && typeof js.error === 'object' && js.error ? js.error as { message?: unknown; details?: { reason?: unknown }[] } : null
      if (e && (/API key/i.test(String(e.message ?? '')) || (e.details || []).some(d => d && d.reason === 'API_KEY_INVALID'))) throw new AiError('network', MSG_PROVIDER)
    }
    if (res.ok) {
      let js: unknown
      try { js = await res.json() } catch (e) {
        const n = (e as { name?: unknown } | null)?.name
        if (n === 'TimeoutError' || n === 'AbortError') throw new AiError('network', MSG_TIMEOUT)
        throw new AiError('parse', 'AI odgovor ni bil berljiv.')
      }
      return textOf(js)
    }
    if (res.status === 503) {
      // novejši strežnik: ponudnik (Google) je ustavil storitev → ponavljanje ne pomaga
      let js: { error?: unknown } | null = null
      try { js = await res.clone().json() } catch { js = null }
      if (js && (js.error === 'ai_placilo' || js.error === 'ai_kljuc')) throw new AiError('network', MSG_PROVIDER)
    }
    if ((res.status === 503 || res.status === 429) && model !== FALLBACK_MODEL && attempt < BACKOFF.length) {
      // preobremenjen model ali polna kvota tega modela → takoj rezervni model, brez čakanja
      model = FALLBACK_MODEL
      last = new AiError('network', MSG_BUSY)
      continue
    }
    if (RETRY_STATUS.has(res.status)) {
      last = new AiError('network', MSG_BUSY)
      if (wait != null) { await sleep(wait); continue }
      throw last
    }
    throw new AiError('network', `Napaka AI storitve (HTTP ${res.status}).`)
  }
  throw last
}

export async function askText(parts: AiPart[], opts?: { model?: string; temp?: number }): Promise<string> {
  return call(parts, { model: opts?.model, temp: opts?.temp })
}

/* Lestev popravkov JSON-a. Modela NIKOLI ne kličemo znova za popravilo — to podvoji strošek. */
function stripFences(s: string): string {
  const m = s.match(/```(?:json|JSON)?\s*([\s\S]*?)```/)
  return m && m[1] ? m[1] : s
}
function straightQuotes(s: string): string {
  return s.replace(/[“”„‟″]/g, '"').replace(/[‘’‚‛]/g, "'")
}
function dropTrailingCommas(s: string): string {
  return s.replace(/,(\s*[}\]])/g, '$1')
}
function sliceToBraces(s: string): string {
  const a = s.indexOf('{'), b = s.lastIndexOf('}')
  const c = s.indexOf('['), d = s.lastIndexOf(']')
  const objOk = a >= 0 && b > a
  const arrOk = c >= 0 && d > c
  if (objOk && (!arrOk || a < c)) return s.slice(a, b + 1)
  if (arrOk) return s.slice(c, d + 1)
  return s
}

function parseLoose<T>(raw: string): T | undefined {
  const s0 = raw.trim()
  const s1 = stripFences(s0).trim()
  const s2 = sliceToBraces(s1).trim()
  const s3 = straightQuotes(s2)
  const s4 = dropTrailingCommas(s3)
  for (const cand of [s0, s1, s2, s3, s4]) {
    if (!cand) continue
    try { return JSON.parse(cand) as T } catch { /* naslednja stopnja */ }
  }
  return undefined
}

export async function askJson<T>(parts: AiPart[], opts?: { model?: string; temp?: number }): Promise<T> {
  const raw = await call(parts, { model: opts?.model, temp: opts?.temp, json: true })
  const parsed = parseLoose<T>(raw)
  if (parsed === undefined) throw new AiError('parse', 'AI odgovor ni bil v pričakovani obliki. Poskusi znova.')
  return parsed
}

/* ---------- Claude (Anthropic) — trener, ki sestavi načrt ---------- */
/**
 * Claude teče prek istega strežnika (/api/claude): ključ je samo tam, strežnik izbere model in strop izhoda.
 * Model pred odgovorom premisli (adaptive thinking, do največjega premisleka) — lahko traja minute, zato strežnik
 * odgovor pretaka: vsakih 10 s vrstica {hb, faza} (aplikacija pokaže, da trener dela), zadnja je rezultat.
 */
export const CLAUDE_TIMEOUT_MS = 900_000
export type ClaudePurpose = 'vprasanja' | 'predlog' | 'sestava'
export type ClaudeEffort = 'low' | 'medium' | 'high' | 'xhigh' | 'max'
export interface ClaudeRequest { purpose: ClaudePurpose; effort: ClaudeEffort; system: string; user: string; schema: Record<string, unknown>; /** slike, ki jih je uporabnik priložil (npr. postava, ki si jo želi) — base64 brez predpone */ images?: { mime: string; data: string }[] }
/** faza: trener premišljuje ali že piše odgovor; sec: koliko časa že */
export type ClaudeProgress = (p: { faza: 'misli' | 'pise'; sec: number }) => void
/** Sporočilo napake, ko Claude na strežniku ni (še) nastavljen ali ni dosegljiv — zaslon gre takrat na Gemini. */
export const CLAUDE_OFF = 'Claude trenutno ni na voljo.'
export const isClaudeOff = (e: unknown): boolean => e instanceof AiError && e.message === CLAUDE_OFF
/**
 * DOSTOP (Blaž, 14. 10.: »samo zame in za tistega, ki mu pošljem povezavo, ostali samo Gemini«): strežnik pove, ali
 * ima ta račun Claude trenerja (skrbnik ali povabilo) in ali je skrbnik (ustvarja povabila). Brez prijave: ne.
 * Preverjeno enkrat na 10 min za račun; brez povezave ali stari strežnik: ne (aplikacija gre na Gemini).
 */
export interface ClaudeAccess { ok: boolean; skrbnik: boolean; kljuc: boolean }
let claudeState: { at: number; key: string; v: ClaudeAccess } | null = null
const NO_ACCESS: ClaudeAccess = { ok: false, skrbnik: false, kljuc: false }
export async function claudeAccess(force = false): Promise<ClaudeAccess> {
  let tok: string
  try { tok = await token() } catch { return NO_ACCESS }
  const key = tok.slice(-24)
  if (!force && claudeState && claudeState.key === key && Date.now() - claudeState.at < 600_000) return claudeState.v
  let v = NO_ACCESS
  try {
    const r = await fetch(`${PROXY}/api/claude/dostop`, { headers: { Authorization: `Bearer ${tok}` }, signal: timeoutSignal(8000) })
    if (r.ok) { const js = (await r.json()) as Partial<ClaudeAccess>; v = { ok: !!js.ok, skrbnik: !!js.skrbnik, kljuc: !!js.kljuc } }
  } catch { v = NO_ACCESS }
  claudeState = { at: Date.now(), key, v }
  return v
}
/** Ali ta račun sestavlja načrt s Claude (sicer Gemini). */
export async function claudeReady(): Promise<boolean> { return (await claudeAccess()).ok }
/** Za teste in po unovčenem povabilu: pozabi stanje. */
export function resetClaudeState(): void { claudeState = null }

/** Skrbnik: nova enkratna povezava za povabilo (koda). */
export async function newClaudeInvite(): Promise<string> {
  const tok = await token()
  const r = await fetch(`${PROXY}/api/claude/povabilo/nova`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tok}` }, body: '{}', signal: timeoutSignal(10000) })
  const js = (await r.json().catch(() => null)) as { koda?: unknown } | null
  if (!r.ok || !js || typeof js.koda !== 'string') throw new AiError('network', r.status === 403 ? 'Povabila ustvarja samo skrbnik.' : 'Povabila ni bilo mogoče ustvariti. Poskusi znova.')
  return js.koda
}
/** Skrbnik: kdo ima Claude trenerja. */
export async function claudeInvitees(): Promise<{ email: string | null; t: number | null }[]> {
  const tok = await token()
  const r = await fetch(`${PROXY}/api/claude/povabila`, { headers: { Authorization: `Bearer ${tok}` }, signal: timeoutSignal(10000) })
  const js = (await r.json().catch(() => null)) as { uporabniki?: { email: string | null; t: number | null }[] } | null
  return r.ok && js?.uporabniki ? js.uporabniki : []
}
/** Prejemnik: unovči povabilo s svojim računom. */
export async function redeemClaudeInvite(koda: string): Promise<{ kljuc: boolean }> {
  const tok = await token()
  let r: Response
  try { r = await fetch(`${PROXY}/api/claude/povabilo`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tok}` }, body: JSON.stringify({ koda }), signal: timeoutSignal(10000) }) }
  catch { throw new AiError('network', 'Ni povezave s strežnikom. Preveri internet in poskusi znova.') }
  const js = (await r.json().catch(() => null)) as { ok?: unknown; kljuc?: unknown; error?: unknown } | null
  resetClaudeState()
  if (r.ok && js?.ok) return { kljuc: !!js.kljuc }
  if (r.status === 410) throw new AiError('network', 'To povabilo je že porabljeno — prosi za novo povezavo.')
  if (r.status === 404) throw new AiError('network', 'Povezava za povabilo ni veljavna.')
  if (r.status === 401) throw new AiError('auth', MSG_AUTH)
  throw new AiError('network', 'Povabila ni bilo mogoče potrditi. Poskusi znova.')
}

type ClaudeBody = { error?: unknown; status?: unknown; limit?: unknown; text?: unknown; stop?: unknown; hb?: unknown; faza?: unknown }
/** Prebere odgovor strežnika: NDJSON (vrstice, zadnja je rezultat) ali navaden JSON (napaka pred začetkom, stari strežnik). */
async function readClaude(res: Response, onProgress?: ClaudeProgress): Promise<ClaudeBody | null> {
  const ct = res.headers.get('content-type') || ''
  if (!/ndjson/.test(ct) || !res.body) { try { return (await res.json()) as ClaudeBody } catch { return null } }
  const reader = res.body.getReader()
  const dec = new TextDecoder()
  let buf = '', last: ClaudeBody | null = null
  const take = (line: string) => {
    if (!line.trim()) return
    let o: ClaudeBody
    try { o = JSON.parse(line) as ClaudeBody } catch { return }
    if (typeof o.hb === 'number') { onProgress?.({ faza: o.faza === 'pise' ? 'pise' : 'misli', sec: o.hb }); return }
    last = o
  }
  for (;;) {
    const { value, done } = await reader.read()
    if (done) break
    buf += dec.decode(value, { stream: true })
    let i: number
    while ((i = buf.indexOf('\n')) >= 0) { take(buf.slice(0, i)); buf = buf.slice(i + 1) }
  }
  take(buf + dec.decode())
  return last
}

/**
 * En klic Claude; vrne JSON po shemi. Strežnik ga opravi kot OPRAVILO do konca (tudi ko telefon zaklene zaslon ali
 * aplikacijo pošlje v ozadje): POST vrne opravilo, aplikacija ga spremlja (GET vsaki 2 s; omrežne napake vmes so
 * normalne — po vrnitvi spremlja naprej) in rezultat prevzame. signal (»ne čakam«, zaprt zaslon) model ustavi.
 * Stari strežnik (pretok NDJSON) še dela enako kot prej.
 */
/**
 * KOLIKO TRENER RAZMIŠLJA (Blaž, 14. 10.: »precej traja … da človek lažje počaka«): zadnjih 5 resničnih časov za vsak
 * namen in premislek (samo na tej napravi). Kartica razmisleka iz njih pokaže napredek in »prejšnjič: 1:48« — brez
 * izmišljenih odstotkov. Brez zgodovine: null (kartica pokaže okvirni čas namena).
 */
const TOOK_KEY = 'formai.claude-cas'
type Took = Record<string, number[]>
const tookRead = (): Took => { try { const v = JSON.parse(localStorage.getItem(TOOK_KEY) || '{}') as unknown; return v && typeof v === 'object' ? (v as Took) : {} } catch { return {} } }
export function claudeTook(purpose: ClaudePurpose, effort: ClaudeEffort, sec: number): void {
  if (!(sec > 0 && sec < 3600)) return
  try { const all = tookRead(); const k = `${purpose}:${effort}`; all[k] = [...(all[k] || []), Math.round(sec)].slice(-5); localStorage.setItem(TOOK_KEY, JSON.stringify(all)) } catch { /* brez shrambe: brez zgodovine */ }
}
/** srednji čas zadnjih premislekov (s) za ta namen in premislek; null = še ni zgodovine */
export function claudeTypical(purpose: ClaudePurpose, effort: ClaudeEffort): number | null {
  const xs = [...(tookRead()[`${purpose}:${effort}`] || [])].filter(x => typeof x === 'number' && x > 0).sort((a, b) => a - b)
  return xs.length ? xs[Math.floor(xs.length / 2)]! : null
}
/** zadnji čas (s) za ta namen in premislek */
export function claudeLast(purpose: ClaudePurpose, effort: ClaudeEffort): number | null {
  const xs = tookRead()[`${purpose}:${effort}`] || []
  return xs.length ? xs[xs.length - 1]! : null
}

export async function askClaude<T>(req: ClaudeRequest, opts?: { onProgress?: ClaudeProgress; /** prekini (uporabnik ne čaka več) — strežnik ustavi model */ signal?: AbortSignal }): Promise<T> {
  let tok = await token()
  const started = Date.now()
  const deadline = started + CLAUDE_TIMEOUT_MS
  const stopped = () => !!opts?.signal?.aborted
  const parse = (text: string): T => {
    const parsed = parseLoose<T>(text)
    if (parsed === undefined) throw new AiError('parse', 'Trenerjev odgovor ni bil v pričakovani obliki. Poskusi znova.')
    return parsed
  }
  const fail = (status: number, js: ClaudeBody | null): never => {
    if (status === 402 && js?.error === 'limit') throw new AiError('network', CLAUDE_OFF)   // strop trenerja: tiho na Gemini
    if (status === 401) throw new AiError('auth', MSG_AUTH)
    if (status === 403) { resetClaudeState(); throw new AiError('network', CLAUDE_OFF) }
    if (status === 404 || js?.error === 'claude_ni_nastavljen') resetClaudeState()
    // razlog z besedami (kartica »Claude tokrat ni odgovoril« ga pokaže)
    const WHY: Record<string, string> = { claude_prezaseden: 'Claude je trenutno preobremenjen', ai_placilo: 'Na računu Anthropic ni dobroimetja', claude_kljuc: 'Ključ Anthropic na strežniku ni veljaven', ai_casovna_omejitev: 'Premislek je trajal predolgo', claude_prekinjeno: 'Strežnik je prekinil premislek', claude_nedokoncano: 'Trener je razmišljal predolgo in ni dokončal odgovora', claude_prazno: 'Claude ni vrnil odgovora', claude_omejitev: 'Preveč zahtevkov naenkrat', preklicano: 'Preklicano' }
    if ([404, 429, 499, 500, 502, 503, 504].includes(status)) throw new AiError('network', typeof js?.error === 'string' && WHY[js.error] ? `${WHY[js.error]}.` : CLAUDE_OFF)
    throw new AiError('network', `Napaka trenerja (HTTP ${status}).`)
  }
  // 1) začni (ali se priklopi na isto, ki že teče)
  let res: Response | null = null
  let js: (ClaudeBody & { job?: ClaudeJob; ze?: boolean }) | null = null
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      res = await fetch(`${PROXY}/api/claude`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tok}` }, body: JSON.stringify(req), signal: opts?.signal ?? timeoutSignal(60_000) })
      // stari strežnik: pretok NDJSON do konca
      if (/ndjson/.test(res.headers.get('content-type') || '')) js = await readClaude(res, opts?.onProgress)
      else js = (await res.json().catch(() => null)) as typeof js
    } catch {
      if (stopped()) throw new AiError('network', CLAUDE_OFF)
      throw new AiError('network', 'Povezava s trenerjem se je prekinila. Preveri internet in poskusi znova.')
    }
    if (res.status === 401 && js?.error === 'neveljaven_token' && attempt === 0) { tok = await token(true); continue }
    break
  }
  if (!res) throw new AiError('network', CLAUDE_OFF)
  if (!js?.job) {
    // stari strežnik (NDJSON): rezultat ali napaka v zadnji vrstici
    const status = res.ok && js && typeof js.error === 'string' ? (typeof js.status === 'number' ? js.status : 502) : res.status
    if (status === 200 && js && typeof js.text === 'string') return parse(js.text)
    return fail(status, js)
  }
  // 2) spremljaj opravilo do konca
  const id = js.job.id
  let job: ClaudeJob = js.job
  // priklop na opravilo, ki je že teklo: čas ni celoten premislek (ne šteje v zgodovino)
  const joined = js.ze === true
  const drop = () => { void fetch(`${PROXY}/api/claude/job/${id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${tok}` }, keepalive: true }).catch(() => {}) }
  const onAbort = () => drop()
  opts?.signal?.addEventListener('abort', onAbort)
  try {
    for (let n = 0; ; n++) {
      opts?.onProgress?.({ faza: job.faza === 'pise' ? 'pise' : 'misli', sec: job.hb || 0 })
      if (job.state === 'koncano' && typeof job.text === 'string') { const out = parse(job.text); drop(); if (!joined) claudeTook(req.purpose, req.effort, (Date.now() - started) / 1000); return out }
      if (job.state === 'napaka') return fail(typeof job.status === 'number' ? job.status : 502, { error: job.error })
      if (stopped()) throw new AiError('network', CLAUDE_OFF)
      if (Date.now() > deadline) { drop(); throw new AiError('network', 'Trener je razmišljal predolgo — poskusi znova.') }
      await sleep(n < 5 ? 1500 : 2500)
      try {
        const g = await fetch(`${PROXY}/api/claude/job/${id}`, { headers: { Authorization: `Bearer ${tok}` }, cache: 'no-store', signal: timeoutSignal(15_000) })
        if (g.status === 401) { tok = await token(true); continue }
        if (g.status === 404) throw new AiError('network', CLAUDE_OFF)
        const gj = (await g.json().catch(() => null)) as { job?: ClaudeJob } | null
        if (gj?.job) job = gj.job
      } catch (e) {
        if (e instanceof AiError) throw e
        // brez povezave (zaslon zaklenjen, ozadje): opravilo teče naprej na strežniku — spremljaj naprej
      }
    }
  } finally { opts?.signal?.removeEventListener('abort', onAbort) }
}
interface ClaudeJob { id: string; state: 'tece' | 'koncano' | 'napaka'; faza?: string; hb?: number; text?: string; error?: string; status?: number }
