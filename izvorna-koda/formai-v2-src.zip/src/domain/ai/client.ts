import { idToken } from '@/data/firebase'
import { PROXY, FREE_AI_PER_DAY } from '@/config'
import { plural, W, NBSP } from '@/ui/format'

/** Cloud Run posrednik (PROXY) — ključ do Gemini je na strežniku, nikoli v odjemalcu. */
const DEFAULT_MODEL = 'gemini-flash-latest'
/**
 * Rezervni model: ko je najnovejši Flash preobremenjen (503 »high demand«) ali je njegova kvota polna (429),
 * gre isti zahtevek takoj na starejši, stabilen Flash (nameščeni strežnik upošteva izbiro modela).
 */
export const FALLBACK_MODEL = 'gemini-2.5-flash'
/** Časovna omejitev enega klica AI (slika + dolg kontekst lahko traja; dlje ne čakamo). */
export const AI_TIMEOUT_MS = 90_000

/** Del poziva. inlineData.data je base64 BREZ predpone data:. */
export type AiPart = { text: string } | { inlineData: { mimeType: string; data: string } }

export type AiErrorKind = 'auth' | 'quota' | 'network' | 'parse' | 'consent'

export class AiError extends Error {
  kind: AiErrorKind
  constructor(kind: AiErrorKind, message: string) {
    super(message)
    this.name = 'AiError'
    this.kind = kind
  }
}

/** Statusi, pri katerih ima ponovni poskus smisel. 402 in 401 sta dokončna. */
const RETRY_STATUS = new Set([429, 500, 502, 503, 504])
const BACKOFF = [1500, 3000]

const MSG_AUTH = 'Za AI se moraš prijaviti.'
/** Dnevna meja strežnika; število iz odgovora (novejši strežnik ga pošlje) ali iz nastavitve, sicer brez števila. */
export function quotaMsg(limit?: number | null): string {
  const n = typeof limit === 'number' && limit > 0 ? limit : FREE_AI_PER_DAY
  return n ? `Današnja kvota AI (${n}${NBSP}${plural(n, W.dejanjeR)}) je porabljena — nova se odpre jutri.` : 'Današnja kvota AI je porabljena — nova se odpre jutri.'
}
/** Ponudnik AI je ustavil storitev (npr. porabljeno predplačilo pri Googlu → Gemini vrne 402). Ni uporabnikova kvota. */
export const MSG_PROVIDER = 'AI je trenutno ustavljen pri ponudniku (ne pri tebi) — popravljamo. Poskusi čez nekaj ur.'
const MSG_TIMEOUT = 'AI se ni odzval v 90 sekundah — poskusi znova čez minuto.'

/** AbortSignal s časovno omejitvijo (AbortSignal.timeout ali nadomestek za starejše brskalnike). */
function timeoutSignal(ms: number): AbortSignal | undefined {
  try {
    const T = (AbortSignal as unknown as { timeout?: (ms: number) => AbortSignal }).timeout
    if (typeof T === 'function') return T.call(AbortSignal, ms)
    const ac = new AbortController(); setTimeout(() => ac.abort(), ms); return ac.signal
  } catch { return undefined }
}

function sleep(ms: number): Promise<void> {
  return new Promise(r => setTimeout(r, ms))
}

async function token(force = false): Promise<string> {
  let t: string | null = null
  try { t = await idToken(force) } catch { t = null }
  if (!t) throw new AiError('auth', MSG_AUTH)
  return t
}

/** Ali je AI sploh na voljo — torej ali je uporabnik prijavljen. */
export async function aiAvailable(): Promise<boolean> {
  try { return !!(await idToken()) } catch { return false }
}

interface GeminiPart { text?: string }
interface GeminiCandidate { content?: { parts?: GeminiPart[] }; finishReason?: string }
interface GeminiResponse {
  candidates?: GeminiCandidate[]
  promptFeedback?: { blockReason?: string }
  text?: string
  error?: { message?: string }
}

function textOf(js: unknown): string {
  if (typeof js === 'string') return js
  const r = (js || {}) as GeminiResponse
  const blocked = r.promptFeedback?.blockReason
  if (blocked) throw new AiError('parse', 'Model je zavrnil odgovor na to vsebino.')
  const cand = r.candidates && r.candidates.length ? r.candidates[0] : undefined
  const parts = cand?.content?.parts
  if (parts && parts.length) {
    const joined = parts.map(p => (typeof p.text === 'string' ? p.text : '')).join('').trim()
    if (joined) return joined
  }
  if (typeof r.text === 'string' && r.text.trim()) return r.text.trim()
  throw new AiError('parse', 'AI ni vrnil besedila.')
}

interface CallOpts { model?: string; temp?: number; json?: boolean }

async function call(parts: AiPart[], opts: CallOpts): Promise<string> {
  let tok = await token()
  let refreshed = false
  const gen: Record<string, unknown> = {}
  if (opts.temp != null) gen.temperature = opts.temp
  if (opts.json) gen.response_mime_type = 'application/json'
  const body: Record<string, unknown> = { contents: [{ role: 'user', parts }] }
  if (Object.keys(gen).length) body.generationConfig = gen
  let model = opts.model || DEFAULT_MODEL

  let last: AiError = new AiError('network', 'AI ni odgovoril.')
  for (let attempt = 0; attempt <= BACKOFF.length; attempt++) {
    const wait = BACKOFF[attempt]
    const payload = JSON.stringify({ model, body })
    let res: Response
    try {
      res = await fetch(`${PROXY}/api/gemini`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tok}` },
        body: payload,
        signal: timeoutSignal(AI_TIMEOUT_MS),
      })
    } catch (e) {
      // časovna omejitev: ne ponavljamo (vsak poskus bi spet čakal 90 s)
      const n = (e as { name?: unknown } | null)?.name
      if (n === 'TimeoutError' || n === 'AbortError') throw new AiError('network', MSG_TIMEOUT)
      last = new AiError('network', 'Ni povezave s strežnikom. Preveri internet in poskusi znova.')
      if (wait != null) { await sleep(wait); continue }
      throw last
    }
    if (res.status === 402) {
      // naš strežnik: {error:'limit'} = dnevna kvota; vse drugo (Gemini: »prepayment credits are depleted«) je ponudnik
      let js: { error?: unknown; limit?: unknown } | null = null
      try { js = await res.json() } catch { js = null }
      if (js && js.error === 'limit') throw new AiError('quota', quotaMsg(typeof js.limit === 'number' ? js.limit : null))
      throw new AiError('network', MSG_PROVIDER)
    }
    if (res.status === 401 || res.status === 403) {
      // naš strežnik: {error:'prijava_potrebna'|'neveljaven_token'} = prijava. Googlova napaka ({error:{status,…}}, npr.
      // 401 ACCESS_TOKEN_TYPE_UNSUPPORTED, 403 PERMISSION_DENIED) = ključ na strežniku, ne uporabnik (prej: »Za AI se moraš prijaviti.«)
      let js: { error?: unknown } | null = null
      try { js = await res.clone().json() } catch { js = null }
      if (js && typeof js.error === 'object' && js.error) throw new AiError('network', MSG_PROVIDER)
      // potekel ali zavrnjen žeton: enkrat z osveženim, šele nato »prijavi se«
      if (js && js.error === 'neveljaven_token' && !refreshed) { refreshed = true; tok = await token(true); attempt--; continue }
      throw new AiError('auth', MSG_AUTH)
    }
    if (res.status === 400) {
      // starejši strežnik posreduje napako Googla: neveljaven ali izbrisan ključ ni napaka uporabnika
      let js: { error?: unknown } | null = null
      try { js = await res.clone().json() } catch { js = null }
      const e = js && typeof js.error === 'object' && js.error ? js.error as { message?: unknown; details?: { reason?: unknown }[] } : null
      if (e && (/API key/i.test(String(e.message ?? '')) || (e.details || []).some(d => d && d.reason === 'API_KEY_INVALID'))) throw new AiError('network', MSG_PROVIDER)
    }
    if (res.ok) {
      let js: unknown
      try { js = await res.json() } catch (e) {
        const n = (e as { name?: unknown } | null)?.name
        if (n === 'TimeoutError' || n === 'AbortError') throw new AiError('network', MSG_TIMEOUT)
        throw new AiError('parse', 'AI odgovor ni bil berljiv.')
      }
      return textOf(js)
    }
    if (res.status === 503) {
      // novejši strežnik: ponudnik (Google) je ustavil storitev → ponavljanje ne pomaga
      let js: { error?: unknown } | null = null
      try { js = await res.clone().json() } catch { js = null }
      if (js && (js.error === 'ai_placilo' || js.error === 'ai_kljuc')) throw new AiError('network', MSG_PROVIDER)
    }
    if ((res.status === 503 || res.status === 429) && model !== FALLBACK_MODEL && attempt < BACKOFF.length) {
      // preobremenjen model ali polna kvota tega modela → takoj rezervni model, brez čakanja
      model = FALLBACK_MODEL
      last = new AiError('network', `Strežnik trenutno ne zmore odgovoriti (HTTP ${res.status}). Poskusi čez minuto.`)
      continue
    }
    if (RETRY_STATUS.has(res.status)) {
      last = new AiError('network', `Strežnik trenutno ne zmore odgovoriti (HTTP ${res.status}). Poskusi čez minuto.`)
      if (wait != null) { await sleep(wait); continue }
      throw last
    }
    throw new AiError('network', `Napaka AI storitve (HTTP ${res.status}).`)
  }
  throw last
}

export async function askText(parts: AiPart[], opts?: { model?: string; temp?: number }): Promise<string> {
  return call(parts, { model: opts?.model, temp: opts?.temp })
}

/* Lestev popravkov JSON-a. Modela NIKOLI ne kličemo znova za popravilo — to podvoji strošek. */
function stripFences(s: string): string {
  const m = s.match(/```(?:json|JSON)?\s*([\s\S]*?)```/)
  return m && m[1] ? m[1] : s
}
function straightQuotes(s: string): string {
  return s.replace(/[“”„‟″]/g, '"').replace(/[‘’‚‛]/g, "'")
}
function dropTrailingCommas(s: string): string {
  return s.replace(/,(\s*[}\]])/g, '$1')
}
function sliceToBraces(s: string): string {
  const a = s.indexOf('{'), b = s.lastIndexOf('}')
  const c = s.indexOf('['), d = s.lastIndexOf(']')
  const objOk = a >= 0 && b > a
  const arrOk = c >= 0 && d > c
  if (objOk && (!arrOk || a < c)) return s.slice(a, b + 1)
  if (arrOk) return s.slice(c, d + 1)
  return s
}

function parseLoose<T>(raw: string): T | undefined {
  const s0 = raw.trim()
  const s1 = stripFences(s0).trim()
  const s2 = sliceToBraces(s1).trim()
  const s3 = straightQuotes(s2)
  const s4 = dropTrailingCommas(s3)
  for (const cand of [s0, s1, s2, s3, s4]) {
    if (!cand) continue
    try { return JSON.parse(cand) as T } catch { /* naslednja stopnja */ }
  }
  return undefined
}

export async function askJson<T>(parts: AiPart[], opts?: { model?: string; temp?: number }): Promise<T> {
  const raw = await call(parts, { model: opts?.model, temp: opts?.temp, json: true })
  const parsed = parseLoose<T>(raw)
  if (parsed === undefined) throw new AiError('parse', 'AI odgovor ni bil v pričakovani obliki. Poskusi znova.')
  return parsed
}
