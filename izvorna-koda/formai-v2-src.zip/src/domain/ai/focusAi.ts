import type { AgreedSession, Focus, FocusEquip, Profile } from '@/domain/types'
import { normalizeFocus, tailsOf, SPORT_LABEL, PART_NAME, CARDIO_LABEL, AIM_LABEL, MUSCLE_NAME, LEVEL_LABEL } from '@/domain/focus/model'
import { EXERCISES, equipFor, limitsOf } from '@/domain/training/exercises'
import { daysLine, DAY_AT } from '@/domain/focus/choices'
import type { AiPart } from './client'

/**
 * AI V POGOVORU »SESTAVIVA TVOJ NAČRT«: vprašanja glede na to, kar je uporabnik povedal (vsakič nova), predlog tedna
 * in pogajanje (več, manj, drugače), ob sestavljanju izbor vaj iz knjižnice in osebna strategija.
 * AI dobi samo: želje in odgovore uporabnika, starost, spol, višino, težo — nikoli imena, e-pošte, kraja ali Strave.
 * Vse, kar vrne, gre skozi normalizeFocus (varovalke) — številke prehrane računa koda, ne AI.
 */
const PERSONA = [
  'Si FORMAI — osebni trener za fitnes, tek, kolo in kondicijo, ki skupaj z uporabnikom sestavi njegov osebni načrt.',
  'Odgovarjaj IZKLJUČNO v slovenščini, v drugi osebi (ti), kratko, toplo in pošteno — brez hvaljenja, brez napihnjenih obljub.',
  'Uporabnik odloča, kaj bo počel (vrsta vadbe, deli telesa); ti poveš po pravici, kaj je realno, in predlagaš najboljšo pot do tega.',
  'Nisi zdravnik: pri bolečini, poškodbi ali bolezni svetuješ previdnost in posvet z zdravnikom ali fizioterapevtom.',
  'Pod 18 let nikoli ne predlagaj hujšanja ali kaloričnega deficita.',
  'Vrni SAMO veljaven JSON v zahtevani obliki, brez ograd in brez besedila okoli njega.',
].join('\n')

export interface Basics { age?: number | null; sex?: 'm' | 'z' | null; heightCm?: number | null; weightKg?: number | null; /** dnevi, ko ima čas (0 = pon … 6 = ned) — okvir načrta */ avail?: readonly number[] | null; /** kdaj čez dan običajno vadi */ trainTime?: 'zjutraj' | 'popoldne' | 'zvecer' | null; /** raje lažje / zmerno / trdo */ push?: 'lahko' | 'zmerno' | 'trdo' | null; /** glavno: kardio / oboje / moč */ main?: 'kardio' | 'oboje' | 'moc' | null }
const TIME_WORD = { zjutraj: 'zjutraj', popoldne: 'čez dan', zvecer: 'zvečer' } as const
/** »Ima čas: pon, sre, pet, ned (4 dni), običajno zvečer; drugi dnevi ne gredo (tor, čet, sob).« */
export function availLine(b: Basics): string {
  const a = [...(b.avail || [])].filter(d => Number.isInteger(d) && d >= 0 && d <= 6).sort((x, y) => x - y)
  if (!a.length) return ''
  const no = [0, 1, 2, 3, 4, 5, 6].filter(d => !a.includes(d))
  return `${mainLine(b.main)}${pushLine(b.push)}Ima čas: ${daysLine(a)} (${a.length} ${a.length === 1 ? 'dan' : a.length === 2 ? 'dneva' : a.length <= 4 ? 'dnevi' : 'dni'} na teden)${b.trainTime ? `, običajno ${TIME_WORD[b.trainTime]}` : ''}${no.length ? `; drugi dnevi NE gredo (neGre: ${daysLine(no)} = [${no.join(', ')}])` : ''}.`
}
export interface QA { q: string; a: string; /** oznaka vprašanja (vprašalnik brez AI) */ id?: string }
export interface AiQuestion { id: string; text: string; multi: boolean; options: string[]; other: boolean }
export interface QuestionsOut { understood: string; questions: AiQuestion[]; enough: boolean }
export interface ProposalOut { reply: string; focus: Focus; quick: string[] }

function basicsLine(b: Basics): string {
  const x: string[] = []
  if (b.sex) x.push(b.sex === 'm' ? 'moški' : 'ženska')
  if (b.age) x.push(`${b.age} let`)
  if (b.heightCm) x.push(`${b.heightCm} cm`)
  if (b.weightKg) x.push(`${b.weightKg} kg`)
  return x.length ? x.join(', ') : 'ni podatkov'
}
const qaLines = (qa: readonly QA[]) => (qa.length ? qa.map(x => `- ${x.q} → ${x.a}`).join('\n') : '(še nič)')

/** Vprašanja: 1. krog 3–5, 2. krog samo manjkajoče (ali nič). */
export function questionsPrompt(i: { wish: string; basics: Basics; qa: readonly QA[]; round: 1 | 2 }): AiPart[] {
  return [{ text: [
    PERSONA,
    '',
    'NALOGA: uporabnik ti je povedal, kaj si želi. Postavi mu vprašanja, ki jih RES rabiš za dober in realen tedenski načrt — vprašanja naj izhajajo iz tega, kar je rekel (ne splošni vprašalnik).',
    i.round === 1
      ? 'To je 1. krog: 3–5 vprašanj.'
      : '2. krog: vprašaj samo, kar za načrt še manjka (0–3 vprašanja). Če je dovolj, vrni prazen seznam in "dovolj": true.',
    i.basics.avail?.length
      ? 'Za načrt moraš na koncu vedeti: koliko od dni, ko ima čas, bi res treniral in koliko časa na vadbo, kje vadi (fitnes ali doma — kakšna oprema), izkušnje, katera kardio vadba mu ustreza (tek, kolo, hribi), poudarek (deli telesa ali cilji), poškodbe ali omejitve. Dneve, ko ima čas, je že povedal (spodaj) — o dnevih NE sprašuj. Česar je že povedal ali izbral, ne sprašuj znova (želja se lahko začne z njegovimi izbirami: »Postava: …«, »Rad delam: …«, »Še: …«). Vprašanja dobi eno za drugim kot v pogovoru — najpomembnejše naj bo prvo.'
      : 'Za načrt moraš na koncu vedeti: koliko dni na teden in koliko časa na vadbo, kateri dnevi mu ne gredo (kdaj nima časa), kje vadi (fitnes ali doma — kakšna oprema), izkušnje, katera kardio vadba mu ustreza (tek, kolo, hribi), poudarek (deli telesa ali cilji), poškodbe ali omejitve. Česar je že povedal ali izbral, ne sprašuj znova (želja se lahko začne z njegovimi izbirami: »Postava: …«, »Rad delam: …«, »Še: …«). Pri dnevih ponudi možnosti pon, tor, sre, čet, pet, sob, ned in »vsi gredo«. Vprašanja dobi eno za drugim kot v pogovoru — najpomembnejše naj bo prvo.',
    'Vsako vprašanje ima 2–6 kratkih možnosti (do 5 besed; pri dnevih 8); "vec": true, če lahko izbere več; "drugo": true, če mu dovoliš svoj odgovor. Brez vprašanj o imenu, e-pošti ali kraju.',
    '',
    `O uporabniku: ${basicsLine(i.basics)}`,
    availLine(i.basics),
    `Kaj si želi (njegove besede): »${i.wish.slice(0, 900)}«`,
    'Dosedanja vprašanja in odgovori:',
    qaLines(i.qa),
    '',
    'Oblika:',
    '{"razumel":"1–2 stavka: kaj si razumel, z njegovimi poudarki","vprasanja":[{"id":"kratek_id","vprasanje":"…?","vec":false,"moznosti":["…","…"],"drugo":true}],"dovolj":false}',
  ].filter(Boolean).join('\n') }]
}

export function parseQuestions(raw: unknown): QuestionsOut | null {
  if (!raw || typeof raw !== 'object') return null
  const r = raw as Record<string, unknown>
  const qs = Array.isArray(r.vprasanja) ? r.vprasanja : Array.isArray(r.questions) ? r.questions : []
  const questions: AiQuestion[] = []
  for (const x of qs) {
    if (!x || typeof x !== 'object') continue
    const o = x as Record<string, unknown>
    const text = String(o.vprasanje ?? o.text ?? '').replace(/\s+/g, ' ').trim().slice(0, 160)
    const options = (Array.isArray(o.moznosti) ? o.moznosti : Array.isArray(o.options) ? o.options : []).map(v => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, 48)).filter(Boolean)
    if (text.length < 5 || options.length < 2) continue
    questions.push({ id: String(o.id ?? `q${questions.length + 1}`).replace(/[^a-z0-9_]/gi, '').slice(0, 24) || `q${questions.length + 1}`, text, multi: !!(o.vec ?? o.multi), options: [...new Set(options)].slice(0, 8), other: o.drugo !== false && o.other !== false })
    if (questions.length >= 5) break
  }
  const understood = String(r.razumel ?? r.understood ?? '').replace(/\s+/g, ' ').trim().slice(0, 300)
  const enough = !!(r.dovolj ?? r.enough) || !questions.length
  return { understood, questions, enough }
}

/** Kakšen tip je: koliko ga sme trener naložiti (načrt in ton). */
export const PUSH_WORD = { lahko: 'raje LAŽJE — manj naložen: manj serij in krajše vadbe, brez trdih intervalov, teden lažji; ne priganjaj', zmerno: 'zmerno — običajno napredovanje', trdo: 'raje TRDO — rad je naložen: več serij in intervalov, polno število dni, zahtevnejši ton (a vseeno dan premora med težkimi dnevi)' } as const
export const pushLine = (v?: 'lahko' | 'zmerno' | 'trdo' | null) => (v ? `Tip: ${PUSH_WORD[v]}. ` : '')
export const MAIN_WORD = { kardio: 'GLAVNO mu je KARDIO (kolo, tek, hoja): večina sej je kardio, moč največ 1–2× na teden in kratka (jedro, noge); za lahek dan raje sprehod ali lahek pohod kot fitnes', oboje: 'glavno: oboje — moč in kardio uravnoteženo', moc: 'GLAVNO mu je MOČ (fitnes): večina sej je moč, kardio kot dopolnilo (1–2× lahek)' } as const
export const mainLine = (v?: 'kardio' | 'oboje' | 'moc' | null) => (v ? `${MAIN_WORD[v]}. ` : '')

const TYPES_HELP = [
  'Vrste sej: "fitnes" (naprave, palice, ročke) in "doma" — z "del": celo | zgornji | spodnji | potisk | poteg | noge | trebuh | roke;',
  '"tek", "kolo" — z "kardio": lahko | intervali | tempo | dolgo; "hribi" (pohod). "min" = trajanje v minutah.',
  'Cilji: misice, moc, kondicija, vzdrzljivost, hujsanje, definicija, zdravje, tekma, gibljivost. Mišice: trebuh, prsa, hrbet, ramena, roke, noge, zadnjica.',
  'Oprema: fitnes, utezi, elastike, drog, nic. Raven: 1 začetnik, 2 nekaj izkušenj, 3 izkušen. Dnevi: 0 = pon … 6 = ned (samo, če jih je povedal).',
  '"dan" pri seji (0 = pon … 6 = ned): VEDNO ga nastavi, ko uporabnik pove, na kateri dan želi to vadbo (»fitnes torek in petek« = točno dve seji fitnesa z "dan": 1 in 4, ne več); ko pove, kdaj vadbe ne dela (»v fitnes ne hodim ob sobotah«), postavi te seje na druge dni z "dan". Dve seji na isti dan samo tako: moč in takoj za njo kardio (tek/kolo) s "poMoci": true (»tek v istem dnevu«, »tek po fitnesu«) — tak kardio je v seznamu takoj za sejo moči in nima "dan". Seje brez "dan" razporedi aplikacija. Uporabnikove besede o dnevih so zavezujoče — v odgovoru ne obljubljaj dni, ki jih ne postaviš v "dan".',
  '"neGre": dnevi, ko nima časa (0 = pon … 6 = ned) — na te dni ne sme biti vadbe, zato je sej največ toliko, kolikor je ostalih dni. "dnevi": dnevi, ki si jih želi (če jih je povedal).',
].join('\n')

/** Predlog tedna ali popravek po uporabnikovem odzivu (pogajanje). */
export function proposalPrompt(i: { wish: string; basics: Basics; qa: readonly QA[]; prev?: Focus | null; feedback?: string | null; /** prejšnje pripombe v pogajanju (vse še veljajo) */ history?: readonly string[] | null }): AiPart[] {
  const hist = [...new Set((i.history || []).filter(Boolean))].slice(-10)
  const prevTxt = i.prev ? `Prejšnji predlog: ${i.prev.title} — ${i.prev.sessions.map(s => `${s.type}${s.part ? '/' + s.part : ''}${s.cardio ? '/' + s.cardio : ''} ${s.min} min${s.day != null ? ` dan=${s.day}` : ''}${s.after ? ' poMoci' : ''}`).join(', ')}${i.prev.offDays?.length ? `; ne gre (neGre): ${daysLine(i.prev.offDays)} = [${i.prev.offDays.join(', ')}]` : ''}` : ''
  return [{ text: [
    PERSONA,
    '',
    i.feedback
      ? `NALOGA: uporabnik je na tvoj predlog odgovoril: »${i.feedback.slice(0, 400)}«. Popravi predlog po njegovih željah (on odloča); če je nekaj nerealno ali tvegano, to v odgovoru pošteno povej s številkami in predlagaj najbližjo dobro možnost.`
      : 'NALOGA: predlagaj realen tedenski načrt, ki čim bolje uresniči, kar si želi, v času, ki ga ima. Če si želi več, kot gre (npr. 19 h, ima pa 6), povej po pravici s številkami in predlagaj, kaj je pametno.',
    hist.length ? `Kar je že povedal prej (prejšnji dogovor in ta pogovor) — VSE še velja, zadnja beseda ima prednost: ${hist.map((h, k) => `${k + 1}. »${h.slice(0, 200)}«`).join(' ')}` : '',
    'POSLUŠAJ DOBESEDNO: vsaka njegova želja (šport, dnevi, število vadb, trajanje, kaj noče) mora biti vidna v "seje" — nič ne izpusti in nič ne dodaj, česar ni hotel; ne vračaj stvari, ki jih je prej odpovedal. V "odgovor" najprej ena vrstica »Upošteval: …« (po njegovih besedah, kratko), potem največ 2 kratka stavka bistva. Če česa res ne moreš upoštevati, povej zakaj v enem stavku. Trajanja piši v urah in minutah (»1 h 15 min«, »45 min«), nikoli »200 min«.',
    'Pravila: ena vadba na dan (največ 6 dni, začetnik največ 5; 7 dni SAMO, če to izrecno hoče — potem je en dan zelo lahek, npr. hoja ali lahek kardio 30 min), skupni čas ne več, kot ga ima. Če reče »v nedeljo daljši trening« ali »ob vikendih daljše«, to velja VSAK teden: ta seja dobi "dan" in "kardio": "dolgo" (ali več min) — nikoli je ne krajšaj. Izjema: po moči je lahko isti dan še kratek kardio (tek ali kolo) — obe seji dobita isti "dan". Moč na istih mišicah ne dva dni zapored. Pri hujšanju z ohranjanjem mišic: težke serije moči ostanejo, zmeren deficit (to izračuna aplikacija), kardio za kondicijo.',
    'RAZMISLI KOT TRENER, ne samo prepiši želje: (1) dve seji moči nista isti del — dve vadbi zgornjega dela = potisk (prsa, ramena, triceps) + poteg (hrbet, biceps), tri = potisk + noge + poteg; celo telo dvakrat je prav samo za začetnika; (2) med težkimi dnevi (moč, intervali, tempo) je dan premora ali lažji dan — če ima čas 4 dni, sta najboljša dva para (npr. pon/sre/pet/ned), ne 4 dni zapored; (3) začetnik: lahek kardio, intervali šele po 4 tednih; (4) napredovanje: 1. teden navada in tehnika, 2.–3. več, 4. lažji (to naredi aplikacija — ti povej, da je tako); (5) če je kakšna želja nespametna (preveč dni, isti del dvakrat zapored, intervali po težki moči), to v "odgovor" pošteno povej in predlagaj boljšo možnost — uporabnik odloča. V "odgovor" v 1–2 stavkih povej, ZAKAJ je teden tak (razmik, delitev, napredovanje).',
    i.feedback && i.prev?.sessions.some(s => s.day != null) ? 'Dneve ("dan") iz prejšnjega predloga ohrani, razen če uporabnik zdaj spremeni dneve.' : '',
    'SAMOPREVERBA pred odgovorom: poglej cel teden kot trener — ali je razporejen enakomerno (ne dva prosta dneva skupaj in nato pet vadb zapored, če ima čas tudi drugje), ali je vsaka njegova želja (tudi prejšnje) notri, ali je kaj nelogičnega (isti del dvakrat zapored, intervali dan po težki moči, daljša vadba na dan z malo časa). Kar ni dobro, popravi, preden odgovoriš.',
    'Trebuh: vaje ga okrepijo, vidnost »six packa« pa je stvar nizkega deleža maščobe — to pošteno povej, če je cilj. Če hoče samo zgornji del: spoštuj, a enkrat omeni, kaj noge prinesejo (tek jih delno pokrije).',
    TYPES_HELP,
    '',
    `O uporabniku: ${basicsLine(i.basics)}`,
    availLine(i.basics) ? `${availLine(i.basics)} Seje samo na dneve, ko ima čas; "neGre" mora vsebovati vse druge dneve.` : '',
    `Kaj si želi: »${i.wish.slice(0, 900)}«`,
    'Vprašanja in odgovori:',
    qaLines(i.qa),
    prevTxt,
    '',
    'Oblika:',
    '{"odgovor":"Upošteval: … + 1–2 kratka stavka bistva, pošteno","ime":"ime načrta, 2–4 besede","sporti":["fitnes","tek"],"cilji":["definicija","kondicija"],"misice":["trebuh"],"raven":2,"oprema":["fitnes"],"omejitve":"","ohraniMisice":true,"dnevi":[],"neGre":[1],"seje":[{"vrsta":"fitnes","del":"zgornji","min":55,"dan":1},{"vrsta":"tek","kardio":"lahko","min":20,"poMoci":true},{"vrsta":"tek","kardio":"intervali","min":35}],"opombe":["kratko pomembno pojasnilo"],"hitri":["3–5 kratkih odzivov za pogajanje, npr. Več kardia"]}',
  ].filter(Boolean).join('\n') }]
}

/**
 * prevOff: dnevi brez časa iz prejšnjega predloga — ostanejo tudi, če jih AI v popravku izpusti ali vrne prazen seznam
 * (dan spet sprosti uporabnik z besedami, npr. »ob torkih spet lahko« → applyDayWords).
 * keepDays: določeni dnevi iz prejšnjega predloga ostanejo (po vrsti in vrstnem redu), če jih AI v popravku izpusti,
 * uporabnik pa dni ni spreminjal.
 */
export function parseProposal(raw: unknown, o: { wish: string; age?: number | null; now?: string; prevOff?: number[] | null; keepDays?: readonly AgreedSession[] | null }): ProposalOut | null {
  if (!raw || typeof raw !== 'object') return null
  const r = raw as Record<string, unknown>
  const seje = Array.isArray(r.seje) ? r.seje : Array.isArray(r.sessions) ? r.sessions : []
  const focus = normalizeFocus({
    wish: o.wish, title: r.ime ?? r.title, sports: r.sporti ?? r.sports, aims: r.cilji ?? r.aims, muscles: r.misice ?? r.muscles, level: r.raven ?? r.level,
    equipment: r.oprema ?? r.equipment, limits: r.omejitve ?? r.limits, keepMuscle: r.ohraniMisice ?? r.keepMuscle, preferDays: r.dnevi ?? r.preferDays, offDays: [...(Array.isArray(r.neGre ?? r.offDays) ? (r.neGre ?? r.offDays) as unknown[] : []), ...(o.prevOff || [])],
    notes: r.opombe ?? r.notes,
    sessions: carryDays(seje.map(s => {
      const x = (s && typeof s === 'object' ? s : {}) as Record<string, unknown>
      return { type: String(x.vrsta ?? x.type ?? '').toLowerCase(), part: x.del ?? x.part, cardio: x.kardio ?? x.cardio, min: x.min, day: x.dan ?? x.day, after: x.poMoci ?? x.after }
    }), o.keepDays),
  }, { age: o.age, now: o.now, by: 'ai' })
  if (!focus) return null
  const reply = String(r.odgovor ?? r.reply ?? '').replace(/[*#`]/g, '').replace(/\s+/g, ' ').trim().slice(0, 700)
  const quick = (Array.isArray(r.hitri) ? r.hitri : []).map(v => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, 40)).filter(Boolean).slice(0, 5)
  return { reply, focus, quick }
}

/**
 * Določeni dnevi in kardio po moči iz prejšnjega predloga na nove seje iste vrste (po vrstnem redu), kadar jih AI ni
 * vrnil; kardio po moči pride v seznam takoj za svojo sejo moči (isto zaporedje moči kot prej).
 */
function carryDays<T extends { type: string; day?: unknown; after?: unknown }>(sessions: T[], prev?: readonly AgreedSession[] | null): T[] {
  if (!prev || !prev.some(s => s.day != null || s.after) || sessions.some(s => (s.day != null && s.day !== '') || s.after)) return sessions
  const strengthOf = (t: string) => t === 'fitnes' || t === 'doma'
  const tails = tailsOf(prev)
  // zaporedna številka seje moči, ki ji je prej pripadal kardio
  const strengthOrd = new Map<number, number>(); prev.forEach((s, i) => { if (strengthOf(s.type)) strengthOrd.set(i, strengthOrd.size) })
  const pool = prev.map((s, i) => ({ type: s.type, day: s.day ?? null, tailOf: tails.has(i) ? strengthOrd.get(tails.get(i)!)! : -1 })).filter(p => p.day != null || p.tailOf >= 0)
  const out: (T & { _tailOf?: number })[] = sessions.map(s => {
    const k = pool.findIndex(p => p.type === s.type)
    if (k < 0) return s
    const [p] = pool.splice(k, 1)
    return p!.tailOf >= 0 ? { ...s, after: true, _tailOf: p!.tailOf } : { ...s, day: p!.day }
  })
  const tailsNew = out.filter(s => s._tailOf != null), main = out.filter(s => s._tailOf == null)
  const res: T[] = []
  let ord = 0
  for (const s of main) {
    res.push(s)
    if (strengthOf(s.type)) { for (const t of tailsNew.filter(x => x._tailOf === ord)) { const { _tailOf: _o, ...rest } = t; res.push(rest as T) } ord++ }
  }
  for (const t of tailsNew.filter(x => x._tailOf! >= ord)) { const { _tailOf: _o, ...rest } = t; res.push(rest as T) }
  return res
}

/* ---------- ob sestavljanju: izbor vaj in osebna strategija ---------- */
/** Knjižnica za AI: samo vaje, ki jih uporabnik lahko dela (oprema doma in/ali fitnes, raven +1, brez omejitev). */
export function libraryFor(f: Pick<Focus, 'equipment' | 'level' | 'limits' | 'sessions'>): string {
  const where = new Set(f.sessions.filter(s => s.type === 'fitnes' || s.type === 'doma').map(s => s.type))
  const eq = new Set<FocusEquip>([...(where.has('fitnes') ? equipFor('fitnes', f.equipment) : []), ...(where.has('doma') ? equipFor('doma', f.equipment) : [])])
  const lim = limitsOf(f.limits)
  return EXERCISES.filter(e => eq.has(e.eq) && e.lvl <= Math.min(3, f.level + 1) && !(e.avoid || []).some(l => lim.includes(l)))
    .map(e => `${e.id} — ${e.name} (${e.m.join(', ')}; ${e.eq}; raven ${e.lvl}${e.time ? '; na čas' : ''})`).join('\n')
}

export function exercisesPrompt(f: Focus, basics: Basics): AiPart[] {
  const sess = f.sessions.map((s, i) => ({ s, i })).filter(x => x.s.type === 'fitnes' || x.s.type === 'doma')
  return [{ text: [
    PERSONA,
    '',
    'NALOGA: za vsako sejo moči izberi vaje IZKLJUČNO iz spodnjega seznama (uporabi id), v vrstnem redu izvajanja: najprej osnovne večsklepne vaje, trebuh na koncu. Število vaj: ~1 vaja na 8 min seje (3–7). Upoštevaj njegove želje, poudarke, raven in omejitve; seja "doma" samo z vajami brez opreme ali z opremo, ki jo ima doma.',
    `Uporabnik: ${basicsLine(basics)} · ${LEVEL_LABEL[f.level]} · cilji: ${f.aims.map(a => AIM_LABEL[a]).join(', ') || '—'} · poudarek: ${f.muscles.map(m => MUSCLE_NAME[m]).join(', ') || 'uravnoteženo'}${f.limits ? ` · omejitve: ${f.limits}` : ''}`,
    `Njegove besede: »${f.wish.slice(0, 600)}«`,
    'Seje:',
    ...sess.map(x => `- ${x.i}: ${SPORT_LABEL[x.s.type]}, ${x.s.part ? PART_NAME[x.s.part] : 'celo telo'}, ${x.s.min} min`),
    '',
    'Vaje (id — ime (mišice; oprema; raven)):',
    libraryFor(f),
    '',
    'Oblika: {"seje":[{"i":0,"vaje":["id","id"],"zakaj":"1 kratek osebni stavek, zakaj ta seja tako"}]}',
  ].join('\n') }]
}

export function parseExercises(raw: unknown, f: Focus): Focus {
  const r = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>
  const list = Array.isArray(r.seje) ? r.seje : []
  const known = new Set(EXERCISES.map(e => e.id))
  const sessions: AgreedSession[] = f.sessions.map(s => ({ ...s }))
  for (const x of list) {
    if (!x || typeof x !== 'object') continue
    const o = x as Record<string, unknown>
    const i = Number(o.i)
    const s = sessions[i]
    if (!s || !(s.type === 'fitnes' || s.type === 'doma')) continue
    const ex = (Array.isArray(o.vaje) ? o.vaje : []).map(v => String(v)).filter(v => known.has(v)).slice(0, 8)
    if (ex.length >= 3) s.ex = ex
    const why = String(o.zakaj ?? '').replace(/\s+/g, ' ').trim().slice(0, 160)
    if (why) s.why = why
  }
  return { ...f, sessions }
}

/** Osebna strategija: kako do cilja, prehrana s številkami aplikacije, kaj pričakovati — realno in zadržano. */
export function strategyPrompt(f: Focus, basics: Basics, nutrition: { kcal: number | null; proteinG: number | null; deficit: number }): AiPart[] {
  return [{ text: [
    PERSONA,
    '',
    'NALOGA: napiši osebno strategijo za ta načrt — kako bosta dosegla, kar si želi. 4–7 kratkih vrstic, vsaka se začne z »– «: trening (zakaj tak teden), prehrana (UPORABI točno številke spodaj, ne računaj svojih), spanec in vztrajnost, kaj realno pričakovati po 4, 8 in 12 tednih (zadržano, brez obljub, npr. hujšanje 0,25–0,75 kg na teden). Brez markdowna.',
    'Za vsako sejo napiši še en kratek osebni stavek, zakaj je v tednu.',
    `Uporabnik: ${basicsLine(basics)} · ${LEVEL_LABEL[f.level]}`,
    `Njegove besede: »${f.wish.slice(0, 600)}«`,
    `Načrt »${f.title}«: ${f.sessions.map((s, i) => `${i}: ${SPORT_LABEL[s.type]} ${s.part ? PART_NAME[s.part] : s.cardio ? CARDIO_LABEL[s.cardio] : ''} ${s.min} min`).join('; ')}`,
    `Cilji: ${f.aims.map(a => AIM_LABEL[a]).join(', ') || '—'}${f.keepMuscle ? ' · mišice naj ostanejo' : ''}${f.muscles.length ? ` · poudarek: ${f.muscles.map(m => MUSCLE_NAME[m]).join(', ')}` : ''}`,
    `Prehrana (izračunala aplikacija): ${nutrition.kcal ? `~${nutrition.kcal} kcal na dan` : 'kalorije še niso izračunane (manjkajo podatki)'}${nutrition.deficit ? `, deficit ${nutrition.deficit} kcal` : ', brez deficita'}${nutrition.proteinG ? `, beljakovine ~${nutrition.proteinG} g na dan` : ''}.`,
    '',
    'Oblika: {"strategija":"– …\\n– …","seje":["stavek za sejo 0","stavek za sejo 1"]}',
  ].join('\n') }]
}

export function parseStrategy(raw: unknown, f: Focus): Focus {
  const r = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>
  const strategy = String(r.strategija ?? r.strategy ?? '').replace(/[*#`]/g, '').replace(/\r/g, '').split('\n').map(l => l.trim()).filter(Boolean).map(l => (/^[–-]\s/.test(l) ? l.replace(/^-\s/, '– ') : `– ${l}`)).slice(0, 8).join('\n').slice(0, 1600)
  const why = Array.isArray(r.seje) ? r.seje.map(v => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, 160)) : []
  return { ...f, strategy: strategy || f.strategy || null, sessions: f.sessions.map((s, i) => (why[i] && !s.why ? { ...s, why: why[i] } : s)) }
}

/** Za kontekst trenerja (pogovor, pregled tedna): kaj si želi in kaj sta se dogovorila. */
export function focusContext(p: Pick<Profile, 'focus'>): string {
  const f = p.focus
  if (!f) return ''
  return [
    `Dogovor z uporabnikom (»${f.title}«): ${f.sessions.map(s => `${SPORT_LABEL[s.type]}${s.part ? ' ' + PART_NAME[s.part] : ''}${s.cardio ? ' ' + CARDIO_LABEL[s.cardio] : ''} ${s.min} min${s.day != null ? ` (vedno ${DAY_AT[s.day]})` : ''}${s.after ? ' (isti dan takoj po moči)' : ''}`).join(', ')}.`,
    `Cilji: ${f.aims.map(a => AIM_LABEL[a]).join(', ') || '—'}${f.keepMuscle ? '; pri hujšanju naj mišice ostanejo' : ''}${f.muscles.length ? `; poudarek: ${f.muscles.map(m => MUSCLE_NAME[m]).join(', ')}` : ''}${f.limits ? `; omejitve: ${f.limits}` : ''}.`,
    f.offDays?.length ? `Dnevi, ko nima časa (tja ne premikaj vadbe): ${daysLine(f.offDays)}.` : '',
    f.main ? `${MAIN_WORD[f.main]}.` : '',
    `Njegove besede: »${f.wish.slice(0, 400)}«`,
    f.said?.length ? `Kar je še povedal (velja še naprej — ne pozabi): ${f.said.slice(-8).map((x, k) => `${k + 1}. »${x.slice(0, 160)}«`).join(' ')}` : '',
  ].filter(Boolean).join('\n')
}
