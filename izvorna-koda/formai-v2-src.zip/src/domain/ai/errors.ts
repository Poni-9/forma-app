/** (v3.50) Napake AI za zaslone (useAi) — ločeno od actions.ts, da začetni paket ne nosi AI pozivov. */
/** (v3.51) razred napake je tu (prej v client.ts): začetni paket ne nosi več odjemalca AI (16 kB) */
export type AiErrorKind = 'auth' | 'quota' | 'network' | 'parse' | 'consent'

export class AiError extends Error {
  kind: AiErrorKind
  constructor(kind: AiErrorKind, message: string) {
    super(message)
    this.name = 'AiError'
    this.kind = kind
  }
}
/** Prijazno sporočilo za uporabnika iz AI napake. */
export function aiErrorText(e: unknown): string {
  if (e instanceof AiError) return e.message
  return (e as Error)?.message || 'AI trenutno ni na voljo.'
}
export function isConsentError(e: unknown): boolean { return e instanceof AiError && e.kind === 'consent' }
export function isAuthError(e: unknown): boolean { return e instanceof AiError && e.kind === 'auth' }
