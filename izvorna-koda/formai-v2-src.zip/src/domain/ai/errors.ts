import { AiError } from './client'

/** (v3.50) Napake AI za zaslone (useAi) — ločeno od actions.ts, da začetni paket ne nosi AI pozivov. */
export { AiError }
/** Prijazno sporočilo za uporabnika iz AI napake. */
export function aiErrorText(e: unknown): string {
  if (e instanceof AiError) return e.message
  return (e as Error)?.message || 'AI trenutno ni na voljo.'
}
export function isConsentError(e: unknown): boolean { return e instanceof AiError && e.kind === 'consent' }
export function isAuthError(e: unknown): boolean { return e instanceof AiError && e.kind === 'auth' }
