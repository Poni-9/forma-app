import type { Activity, PlanDay, Profile } from '@/domain/types'
import { aiAllowed } from '@/domain/import/provenance'
import { powerMeterFrom } from '@/domain/training/review'

/**
 * VAROVALKA: pogled na podatke, ki smejo v AI poziv (»AI-safe view«).
 * Stravini podatki (Strava API, intervals.icu z izvorom STRAVA, Stravin arhiv, GPX ali posnetek iz Strave)
 * ne smejo v AI ne neposredno ne posredno. Posredno bi šli prek:
 *  - kljukice »opravljeno« v načrtu, ki jo je postavila Stravina vožnja (linkToPlan) → »ključni trening: da«,
 *  - števila skritih aktivnosti (»3 aktivnosti ni v povzetku«) — tudi število je podatek,
 *  - izpeljank v profilu (merilnik moči iz voženj).
 * Zato vsak poziv gradimo iz tega pogleda: samo dovoljene aktivnosti, načrt brez kljukic, ki kažejo na
 * nedovoljeno ali neznano aktivnost, in samo »nekaj je skrito« (da/ne) za varovalko sanitizeGaps.
 */

/** Stavek za AI, ko del aktivnosti ni v kontekstu — brez števila. */
export const HIDDEN_NOTE = 'Opomba: nekaterih aktivnosti in z njimi povezanih opravljenih treningov ni v tem povzetku zaradi pravil o virih podatkov. Ne trdi, da uporabnik takrat ni treniral ali da je trening izpustil.'

/** Načrt za AI: kljukica ostane samo, če je ročna ali kaže na aktivnost, ki sme v AI. */
export function aiSafePlan(plan: readonly PlanDay[], activities: readonly Activity[]): PlanDay[] {
  const ok = new Set(activities.filter(a => aiAllowed(a)).map(a => a.id))
  return plan.map(d => {
    const id = d.done?.activityId
    if (!d.done || !id || ok.has(id)) return d
    const { doneAt: _d, ...rest } = d; void _d
    return { ...rest, done: null }
  })
}

export interface AiSafeView { profile: Profile; activities: Activity[]; plan: PlanDay[]; hidden: boolean }

/** Pogled za AI iz vseh podatkov aplikacije. */
export function aiSafeView(i: { profile: Profile; activities: readonly Activity[]; plan: readonly PlanDay[]; today: string }): AiSafeView {
  const activities = i.activities.filter(a => aiAllowed(a))
  const hidden = activities.length < i.activities.length
  const plan = aiSafePlan(i.plan, i.activities)
  // merilnik moči, ki ga je aplikacija razbrala iz voženj: samo iz voženj, ki smejo v AI
  let profile = i.profile
  if (profile.gear?.powerMeterAuto && hidden) {
    const pm = powerMeterFrom(activities, i.today)
    if (pm !== (profile.gear.powerMeter ?? null)) profile = { ...profile, gear: { ...profile.gear, powerMeter: pm } }
  }
  return { profile, activities, plan, hidden }
}
