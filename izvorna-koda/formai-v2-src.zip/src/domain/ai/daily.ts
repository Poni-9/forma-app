import type { DailyCheckin, PlanDay } from '@/domain/types'
import { getKV } from '@/data/db'
import type * as Actions from './actions'

/**
 * (v3.50) Nasvet dneva za Danes brez AI pozivov v začetnem paketu: odtis in shranjen nasvet sta tu (majhna), pozivi,
 * pravila sestave in klici (actions.ts) se naložijo šele ob prvi rabi — prej je začetni paket nosil vse (995 KB).
 */

/**
 * Odtis dneva za shranjen nasvet: današnji treningi (naslov, trajanje, prilagoditev, opravljeno) in počutje.
 * Ko se spremeni (npr. »noge bolijo« → sprehod), shranjen nasvet ne velja več — prej je »Trener pravi« ves dan govoril
 * o treningu, ki ga ni bilo več.
 */
export function adviceSig(s: { plan: readonly (Pick<PlanDay, 'date' | 'title' | 'durationMin' | 'byState' | 'done'> & Partial<Pick<PlanDay, 'desc' | 'exercises'>>)[]; today: string; checkinToday?: Pick<DailyCheckin, 'mood' | 'soreness'> | null }): string {
  // (v3.50) tudi opis in vaje (kratek odtis) — »Prilagodi teden« pogosto spremeni samo opis ali serije (prej je star nasvet veljal za svežega)
  const body = (d: Partial<Pick<PlanDay, 'desc' | 'exercises'>>) => hash(`${d.desc ?? ''}~${(d.exercises || []).map(e => `${e.name}:${e.sets}x${e.reps}@${e.kg ?? ''}`).join(',')}`)
  const day = s.plan.filter(d => d.date === s.today).map(d => `${d.title}|${d.durationMin}|${d.byState?.mode ?? ''}|${d.done ? 1 : 0}|${body(d)}`).sort().join(';')
  return `${day}#${s.checkinToday?.mood ?? ''}|${s.checkinToday?.soreness ?? ''}`
}
/** kratek odtis besedila (djb2) */
function hash(t: string): string {
  let h = 5381
  for (let i = 0; i < t.length; i++) h = ((h << 5) + h + t.charCodeAt(i)) | 0
  return (h >>> 0).toString(36)
}
export type DailyKV = { text: string; sig: string }
/** Shranjen nasvet za danes; stale = dan se je od takrat spremenil. Zapis pred v3.49 (brez odtisa) ne šteje — odtisa ne poznamo. */
export async function cachedDailyAdvice(today: string, sig: string): Promise<{ text: string; stale: boolean } | null> {
  const c = await getKV<DailyKV | string>(`ai.daily.${today}`)
  if (!c) return null
  if (typeof c === 'string') return null
  return c.text ? { text: c.text, stale: c.sig !== sig } : null
}

const actions = () => import('./actions')
/** dailyAdvice iz actions.ts — naloži se ob prvem klicu */
export async function dailyAdvice(...a: Parameters<typeof Actions.dailyAdvice>): ReturnType<typeof Actions.dailyAdvice> { return (await actions()).dailyAdvice(...a) }
/** adaptWeek iz actions.ts — naloži se ob prvem klicu */
export async function adaptWeek(...a: Parameters<typeof Actions.adaptWeek>): ReturnType<typeof Actions.adaptWeek> { return (await actions()).adaptWeek(...a) }
