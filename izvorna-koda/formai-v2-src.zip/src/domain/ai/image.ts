/* Priprava slik za model: pomanjšanje na canvas in ročno branje EXIF ure. */

export type PickedImage = {
  /** base64 BREZ predpone 'data:…' — tako ga pričakuje Gemini inline_data. */
  data: string
  mime: string
  /** poln data: URL za lokalni prikaz sličice */
  thumb: string
}

const OUT_MIME = 'image/jpeg'

type Decoded = { src: CanvasImageSource; w: number; h: number; close: () => void }

/**
 * Pomanjša sliko in vrne base64 za model ter sličico za prikaz.
 * Privzeto 1280 px daljša stranica pri kakovosti 0.85; sličica 110 px pri 0.7.
 */
export async function fileToBase64Resized(file: File, maxPx = 1280, quality = 0.85): Promise<PickedImage> {
  if (!file.type.startsWith('image/')) throw new Error('To ni slika.')
  const img = await decode(file)
  try {
    const full = render(img, maxPx, quality)
    const thumb = render(img, 110, 0.7)
    const comma = full.indexOf(',')
    if (comma < 0) throw new Error('Slike ni bilo mogoče pretvoriti.')
    return { data: full.slice(comma + 1), mime: OUT_MIME, thumb }
  } finally {
    img.close()
  }
}

function render(img: Decoded, maxPx: number, quality: number): string {
  const scale = Math.min(1, maxPx / Math.max(img.w, img.h))
  const w = Math.max(1, Math.round(img.w * scale))
  const h = Math.max(1, Math.round(img.h * scale))
  const cv = document.createElement('canvas')
  cv.width = w
  cv.height = h
  const ctx = cv.getContext('2d')
  if (!ctx) throw new Error('Risanje slike v tem brskalniku ni mogoče.')
  ctx.drawImage(img.src, 0, 0, w, h)
  return cv.toDataURL(OUT_MIME, quality)
}

/**
 * Dekodiranje z EXIF orientacijo. createImageBitmap z { imageOrientation: 'from-image' } obrne
 * sliko namesto nas; pri padcu na <img> orientacijo uporabi brskalnik sam (image-orientation: from-image
 * je privzetek), zato je ročno vrtenje odveč in bi sliko obrnilo dvakrat.
 */
async function decode(file: File): Promise<Decoded> {
  if (typeof createImageBitmap === 'function') {
    try {
      const bmp = await createImageBitmap(file, { imageOrientation: 'from-image' })
      return { src: bmp, w: bmp.width, h: bmp.height, close: () => bmp.close() }
    } catch {
      // starejši brskalniki ne poznajo možnosti imageOrientation — gremo na <img>
    }
  }
  const url = URL.createObjectURL(file)
  try {
    const el = await new Promise<HTMLImageElement>((res, rej) => {
      const i = new Image()
      i.onload = () => res(i)
      i.onerror = () => rej(new Error('Slike ni bilo mogoče prebrati.'))
      i.src = url
    })
    const w = el.naturalWidth || el.width
    const h = el.naturalHeight || el.height
    if (!w || !h) throw new Error('Slika je prazna.')
    return { src: el, w, h, close: () => URL.revokeObjectURL(url) }
  } catch (e) {
    URL.revokeObjectURL(url)
    throw e
  }
}

/* ---- EXIF ---- */

const HEAD_BYTES = 256 * 1024

/**
 * Ura (0–23) iz EXIF DateTimeOriginal (0x9003), sicer DateTime (0x0132). Bere samo prvih 256 kB
 * JPEG datoteke — EXIF je v APP1 takoj na začetku. Vrne null, če EXIF-a ni (npr. PNG, HEIC, posnetek zaslona).
 */
export async function exifHour(file: File): Promise<number | null> {
  let v: DataView
  try {
    v = new DataView(await file.slice(0, HEAD_BYTES).arrayBuffer())
  } catch {
    return null
  }
  if (v.byteLength < 4 || v.getUint16(0) !== 0xffd8) return null
  let off = 2
  while (off + 4 <= v.byteLength) {
    if (v.getUint8(off) !== 0xff) { off++; continue }
    const marker = v.getUint8(off + 1)
    if (marker === 0xff || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd8)) { off += 2; continue }
    if (marker === 0xda || marker === 0xd9) return null
    const len = v.getUint16(off + 2)
    if (len < 2) return null
    if (marker === 0xe1 && off + 10 <= v.byteLength && ascii(v, off + 4, 4, v.byteLength) === 'Exif') {
      return hourFromTiff(v, off + 10)
    }
    off += 2 + len
  }
  return null
}

function hourFromTiff(v: DataView, tiff: number): number | null {
  const end = v.byteLength
  if (tiff + 8 > end) return null
  const order = v.getUint16(tiff)
  if (order !== 0x4949 && order !== 0x4d4d) return null
  const le = order === 0x4949
  if (v.getUint16(tiff + 2, le) !== 0x2a) return null
  const ifd0 = v.getUint32(tiff + 4, le)
  const exifPtr = tagAt(v, tiff, ifd0, le, 0x8769)
  if (exifPtr && exifPtr.type === 4) {
    const sub = v.getUint32(exifPtr.off, le)
    const orig = tagAt(v, tiff, sub, le, 0x9003) || tagAt(v, tiff, sub, le, 0x9004)
    const h = orig ? parseHour(ascii(v, orig.off, orig.count, end)) : null
    if (h !== null) return h
  }
  const plain = tagAt(v, tiff, ifd0, le, 0x0132)
  return plain ? parseHour(ascii(v, plain.off, plain.count, end)) : null
}

type Tag = { type: number; count: number; off: number }

function tagAt(v: DataView, tiff: number, ifd: number, le: boolean, tag: number): Tag | null {
  const base = tiff + ifd
  const end = v.byteLength
  if (base < tiff || base + 2 > end) return null
  const n = v.getUint16(base, le)
  for (let i = 0; i < n; i++) {
    const e = base + 2 + i * 12
    if (e + 12 > end) return null
    if (v.getUint16(e, le) !== tag) continue
    const type = v.getUint16(e + 2, le)
    const count = v.getUint32(e + 4, le)
    const unit = type === 3 ? 2 : type === 4 || type === 9 ? 4 : type === 5 || type === 10 ? 8 : 1
    const size = count * unit
    // do 4 bajte je vrednost kar v polju, sicer je tam odmik od začetka TIFF
    const off = size > 4 ? tiff + v.getUint32(e + 8, le) : e + 8
    if (off < 0 || off >= end) return null
    return { type, count, off }
  }
  return null
}

function ascii(v: DataView, off: number, count: number, end: number): string {
  let s = ''
  for (let i = 0; i < count && off + i < end; i++) {
    const c = v.getUint8(off + i)
    if (!c) break
    s += String.fromCharCode(c)
  }
  return s
}

function parseHour(s: string): number | null {
  const m = /^\d{4}[:-]\d{2}[:-]\d{2}[ T](\d{2}):/.exec(s.trim())
  if (!m || !m[1]) return null
  const h = Number(m[1])
  return Number.isFinite(h) && h >= 0 && h <= 23 ? h : null
}
