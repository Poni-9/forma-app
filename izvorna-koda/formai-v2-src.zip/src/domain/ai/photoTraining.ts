import type { Activity, Profile } from '@/domain/types'
import { askJson, AiError, type AiPart } from './client'
import { fileToBase64Resized } from './image'
import { hasConsent, SELF_PHOTO_CONSENT_V } from './consent'
import { activityShotPrompt } from './prompts'
import { activityFromShot } from './actions'
import { todayIso } from '@/domain/training/load'
import { cleanShot, draftFromOut, unsupportedKind, selfFromOut, LIB_NAMES, PHOTO_LIMITS, defaultRest, planExercises, SELF_DEFAULT, type PhotoWorkout, type SelfAdvice } from '@/domain/training/fromPhoto'
import { strengthMinutes } from '@/domain/training/exercises'

/**
 * (v3.50) TRENING S SLIKE — AI klici (Blaž: »da dam sliko in mi naredi trening« … »vse troje«).
 * Slika gre v AI samo po privolitvi (enako kot obrok), pomanjšana; NE shrani se nikjer — ne v napravo ne v oblak, samo
 * rezultat. Vsak odgovor se preveri na odjemalcu (fromPhoto.ts). Strežnik ostane, kot je.
 */

// (v3.50) slika sebe: privolitev z vrstico o slikah sebe (v = 3); posnetek in tabla: katera koli privolitev
function requireConsent(p: Profile, v = 1) { if (!hasConsent(p, v)) throw new AiError('consent', 'Za AI nasvete potrebujem tvojo privolitev.') }
const bare = (b64: string) => (b64.includes('base64,') ? b64.split('base64,')[1]! : b64)
/**
 * (v3.51) Odgovor, ki ni JSON (»Oprostite, na sliki ne vidim podatkov.«): sporočilo lista z namigom namesto
 * »AI odgovor ni bil v pričakovani obliki« — druge napake (povezava, kvota, privolitev) ostanejo, kot so.
 */
export async function readable<T>(fn: () => Promise<T>, msg: string): Promise<T> {
  try { return await fn() } catch (e) {
    if (e instanceof AiError && e.kind === 'parse' && /pričakovani obliki/.test(e.message)) throw new AiError('parse', msg)
    throw e
  }
}
export const NO_SHOT = 'S te slike nisem prebral podatkov. Slikaj zaslon bližje — ali vpiši ročno.'

/* ---------- 1) posnetek opravljenega treninga ---------- */
/** Dopolnilo poziva za posnetek: tudi zaslon fitnes naprave ali trenažerja in fotografija ure. */
export const DONE_EXTRA = [
  'Posnetek je lahko tudi fotografija zaslona ure, trenažerja ali fitnes naprave (tekalna steza → "tek", sobno kolo ali trenažer → "kolo", veslo ali eliptični trenažer → "drugo", vadba za moč → "moc").',
  'Pri napravi beri čas, razdaljo, kcal, utrip in moč z zaslona; če ni enot, ne ugibaj.',
].join('\n')
export function doneShotPrompt(imageBase64: string, mime: string, today: string = todayIso()): AiPart[] {
  const [head, img] = activityShotPrompt(imageBase64, mime, today)
  return [{ text: `${(head as { text: string }).text}\n${DONE_EXTRA}` }, img!]
}
/** (v3.50) največja povprečna hitrost po športu (km/h) in vzpon na uro (m): več je napačno prebrana vejica ali enota */
export const SHOT_MAX_KMH: Partial<Record<Activity['sport'], number>> = { kolo: 70, tek: 25, pohod: 12 }
export const SHOT_MAX_CLIMB_H = 2000
/**
 * (v3.50) Kombinacije s posnetka: razdalja, ki ne ustreza času (»30,0 km« prebrano kot 300 v 60 min = 300 km/h), in
 * vzpon čez 2 000 m na uro ostaneta prazna za ročni vpis — vsako polje posebej je bilo v razponu, skupaj pa ne.
 */
export function senseShot<T extends Activity>(a: T): T {
  const h = a.durationMin && a.durationMin > 0 ? a.durationMin / 60 : null
  if (!h) return a
  const out: T = { ...a }
  const max = SHOT_MAX_KMH[a.sport]
  if (max && out.distKm && out.distKm / h > max) { out.distKm = null; out.speedKmh = null }
  if (out.elevM && out.elevM / h > SHOT_MAX_CLIMB_H) out.elevM = null
  return out
}
/** Opravljen trening s posnetka: isto branje kot Uvoz (vir 'screenshot', Strava → trener ne vidi), nato razponi. */
export async function doneFromPhoto(p: Profile, file: File, today: string = todayIso()): Promise<Activity> {
  return senseShot(cleanShot(await readable(() => activityFromShot(p, file, today, doneShotPrompt), NO_SHOT)))
}

/* ---------- 2) trening s slike ---------- */
export function workoutPhotoPrompt(imageBase64: string, mime: string): AiPart[] {
  const text = [
    'Si trener v slovenski aplikaciji FORMAI. Odgovarjaš izključno v slovenščini.',
    'Na sliki je trening, ki ga uporabnik želi narediti: tabla v fitnesu ali CrossFit WOD, objava z Instagrama, list od trenerja ali posnetek vadbe iz druge aplikacije.',
    'Preberi SAMO, kar na sliki piše. Ničesar ne dodajaj in ne izmišljuj — česar ni, je null.',
    '"vrsta": "moc" (vaje z utežmi ali lastno težo, WOD, veslo), "kolo" (kolo, trenažer, Zwift), "tek" ali "pohod" (hribi, hoja).',
    'Moč: "vaje" po vrsti — ime v slovenščini (če gre, točno ime s spodnjega seznama), serije, ponovitve (število) ali cas_s (vaja na čas), kg (lb pretvori v kg), pavza_s.',
    'Kolo, tek, hribi: "koraki" po vrsti — ogrevanje, ponovitve (število × delo_s / odmor_s @ intenzivnost), enakomerno, iztek. Intenzivnost kot "Z1"–"Z5", "RPE 1–10", "200–220 W", "90–95 % FTP" ali "utrip 150–160".',
    '"minut" = celotno trajanje, če piše ali ga lahko seštej iz korakov. "opomba" = kar je pomembno in ne gre v polja (npr. »AMRAP 20 min«, »3 krogi«), največ en stavek.',
    'Če na sliki ni treninga, vrni prazne "vaje" in "koraki".',
    'Prepoznaj aplikacijo, če je to posnetek zaslona (Strava je oranžna z logotipom Strava), in jo vrni v "app" ("strava", "drugo" ali null).',
    `Vaje v knjižnici: ${LIB_NAMES()}.`,
    '',
    'Vrni SAMO veljaven JSON te oblike, brez ograd in brez besedila okoli njega:',
    '{"app":null,"vrsta":"moc","naslov":"kratek naslov","minut":45,"vaje":[{"ime":"","serije":3,"ponovitve":10,"cas_s":null,"kg":null,"pavza_s":60}],"koraki":[{"tip":"ogrevanje","min":10,"ponovitve":null,"delo_s":null,"odmor_s":null,"intenzivnost":null}],"opomba":""}',
  ].join('\n')
  return [{ text }, { inlineData: { mimeType: mime, data: bare(imageBase64) } }]
}
export const NO_WORKOUT = 'Na sliki nisem našel treninga. Slikaj tablo ali list bližje in ostreje — ali ga vpiši ročno.'
/** (v3.51) Trening je na sliki, a ga načrt še ne zna (plavanje, veslanje s koraki) — ne »nisem našel«. */
export const unsupportedText = (what: string): string => `${what} še ne znam dodati v načrt — ko ga opraviš, ga vpiši ročno med vadbe (Aktivnosti).`
/** Posnetek iz Strave: rezultata ne uporabimo (Stravina pravila — nič iz Strave ne gre v trenerja). */
export const STRAVA_WORKOUT = 'To je posnetek iz Strave — tega ne smem uporabiti. Trening vpiši ročno.'
/** (v3.50) Skupno trajanje korakov s slike (min) brez zgornje meje: ponovitve z odmori, ogrevanje, enakomerno, iztek. */
export function draftRawMinutes(w: PhotoWorkout): number {
  let sec = 0
  for (const b of w.blocks) {
    if (b.kind === 'ponovitve') { if (b.n != null && b.workS != null) sec += b.n * b.workS + (b.n - 1) * (b.restS ?? defaultRest(b.workS)) }
    else if (b.min != null) sec += b.min * 60
  }
  return Math.round(sec / 60)
}
const firstNum = (s: string) => +(/\d+/.exec(s)?.[0] ?? 1)
/**
 * (v3.50) Trening s slike, daljši od 8 ur (20 × 30 min intervalov, 15 vaj × 10 serij × 100 ponovitev): največji del dobi
 * prazno polje (ponovitve oz. serije), da ga predogled pokaže kot napako za popravek — prej je šel skozi brez napake
 * (vodena vadba 705 min, TSS 680), tudi ko je bilo vsako polje posebej v razponu.
 */
export function senseDraft(w: PhotoWorkout): PhotoWorkout {
  const max = PHOTO_LIMITS.min[1]
  if (w.kind === 'moc') {
    const ex = w.exercises.map(e => ({ ...e }))
    for (let g = 0; g < ex.length && strengthMinutes(planExercises({ ...w, exercises: ex })) > max; g++) {
      const i = ex.reduce((bi, e, j) => (e.sets != null && (bi < 0 || e.sets * firstNum(e.reps) > ex[bi]!.sets! * firstNum(ex[bi]!.reps)) ? j : bi), -1)
      if (i < 0) break
      ex[i]!.sets = null
    }
    return { ...w, exercises: ex }
  }
  const blocks = w.blocks.map(b => ({ ...b }))
  const size = (b: PhotoWorkout['blocks'][number]) => (b.kind === 'ponovitve' ? (b.n != null && b.workS != null ? b.n * (b.workS + (b.restS ?? defaultRest(b.workS))) : 0) : 0)
  for (let g = 0; g < blocks.length && draftRawMinutes({ ...w, blocks }) > max; g++) {
    const i = blocks.reduce((bi, b, j) => (size(b) > 0 && (bi < 0 || size(b) > size(blocks[bi]!)) ? j : bi), -1)
    if (i >= 0) { blocks[i]!.n = null; continue }
    // brez ponovitev: najdaljši enakomeren del ostane prazen
    const k = blocks.reduce((bi, b, j) => (b.min != null && (bi < 0 || b.min > blocks[bi]!.min!) ? j : bi), -1)
    if (k < 0) break
    blocks[k]!.min = null
  }
  return { ...w, blocks }
}
/** Trening s slike → osnutek za predogled (preverjen; prazno ali nesmiselno → napaka z rezervno potjo). */
export async function workoutFromPhoto(p: Profile, file: File): Promise<PhotoWorkout> {
  requireConsent(p)
  const img = await fileToBase64Resized(file, 1280, 0.85)
  const out = await readable(() => askJson<unknown>(workoutPhotoPrompt(img.data, img.mime), { temp: 0.1 }), NO_WORKOUT)
  if (out && typeof out === 'object' && /strava/i.test(String((out as { app?: unknown }).app ?? ''))) throw new AiError('parse', STRAVA_WORKOUT)
  const w = draftFromOut(out)
  const other = w ? null : unsupportedKind(out)
  if (other) throw new AiError('parse', unsupportedText(other))
  if (!w) throw new AiError('parse', NO_WORKOUT)
  return senseDraft(w)
}

/* ---------- 3) slika sebe → predlog vaj ---------- */
export const MINOR_SELF = 'Za mlajše od 18 let ocene s slike ne delam — vaje za držo pa so v Vajah.'
export const NO_AGE_SELF = 'Za predlog s slike najprej vpiši starost v Nastavitvah → Profil.'
/** Pod 18 let ni na voljo; brez vpisane starosti tudi ne (ne vemo, ali je odrasel). */
export function selfAvailable(p: Pick<Profile, 'age'>): 'ok' | 'minor' | 'noage' {
  if (p.age == null || !(p.age > 0)) return 'noage'
  return p.age < 18 ? 'minor' : 'ok'
}
export function selfPhotoPrompt(imageBase64: string, mime: string): AiPart[] {
  const text = [
    'Si trener moči v slovenski aplikaciji FORMAI. Odgovarjaš izključno v slovenščini, tikaš, kratko.',
    'Na sliki je uporabnik (postava, drža). Daj SPOŠTLJIV, NEVTRALEN vtis, ki pove samo, KAJ TRENIRATI: drža (glava, ramena, zgornji hrbet), ravnotežje leve in desne strani, jedro, noge.',
    'PREPOVEDANO: ocena privlačnosti ali lepote, odstotek telesne maščobe, ocena teže, BMI ali ITM, besede o debelosti ali suhosti, obljube videza, roki (»v 8 tednih«), primerjave z drugimi, sramotenje, zdravstvene diagnoze.',
    'Vsak poudarek je en kratek stavek: kaj opaziš in kaj okrepiti (npr. »Ramena so rahlo naprej — okrepi zgornji hrbet in zadnje rame.«). Največ 3 poudarki. Ne piši, da je karkoli »narobe« s telesom.',
    'To je grob vtis s slike, ne meritev — tako ga tudi zapiši, brez gotovosti.',
    'Če osebe na sliki ne vidiš dovolj (obrezano, temno, več oseb, ni osebe), vrni prazne "poudarki" in v "opomba" povej, kakšno sliko potrebuješ.',
    `Vaje izberi s tega seznama (lastna teža ali preprosta oprema): ${LIB_NAMES()}.`,
    '',
    'Vrni SAMO veljaven JSON te oblike, brez ograd in brez besedila okoli njega:',
    '{"poudarki":["…"],"podrocje":"drza"|"jedro"|"noge"|"ravnotezje"|"zgornji","predlog":{"naslov":"Hrbet in zadnje rame","krat_na_teden":2,"minut":15,"vaje":[{"ime":"","serije":3,"ponovitve":10,"cas_s":null}]},"opomba":""}',
  ].join('\n')
  return [{ text }, { inlineData: { mimeType: mime, data: bare(imageBase64) } }]
}
export const NO_SELF = 'Na sliki te ne vidim dovolj — slikaj se v celoti, pri dobri svetlobi.'
/**
 * (v3.50) Druga plast filtra poudarkov (fromPhoto.SELF_BAN je prva): opisi maščobe, teže in videza brez besed »maščoba«,
 * »teža«, »kg« (»odvečne kile«, »mehko tkivo okoli pasu«, »trebušček«, »hruškasta postava«, »trebušne mišice se ne vidijo«).
 * Poudarek brez vaje (kaj okrepiti ali vaditi) izpade — ni navodilo, samo opis telesa.
 */
export const SELF_BAN_MORE = /(?<!\p{L})kil\p{L}*|odve(?:č|c)|trebu(?:š|s)(?:č|c)|mehk\p{L}*\s+tkiv|tkiv\p{L}*\s+okoli|okoli\s+pas\p{L}*|okrogl|oblin|polnej|hru(?:š|s)kast|(?:š|s)irok\p{L}*\s+(?:pas|bok)|ne\s+vidijo|niso\s+vidn|vidn\p{L}*\s+(?:trebu|mi(?:š|s)ic)/iu
const DO_VERB = /okrep|krep|razgib|vadi|vaj[aeo]|raztegn|razteg|aktivir|stabiliz|izbolj|trenir|oja(?:č|c)|delaj|dodaj|pazi|sprosti|poravn|potegni|dvigni|drži|vadb/iu
export function tidySelf(s: SelfAdvice): SelfAdvice {
  const bad = (x: string) => SELF_BAN_MORE.test(x)
  return { ...s, points: s.points.filter(x => !bad(x) && DO_VERB.test(x)), title: bad(s.title) ? SELF_DEFAULT[s.area].title : s.title, note: bad(s.note) ? '' : s.note }
}
/** Slika sebe → predlog (samo odrasli). V AI gre samo slika — brez profila, imena ali teže. */
export async function selfFromPhoto(p: Profile, file: File): Promise<SelfAdvice> {
  const av = selfAvailable(p)
  if (av !== 'ok') throw new AiError('parse', av === 'minor' ? MINOR_SELF : NO_AGE_SELF)
  requireConsent(p, SELF_PHOTO_CONSENT_V)
  const img = await fileToBase64Resized(file, 1024, 0.8)
  const out = await readable(() => askJson<unknown>(selfPhotoPrompt(img.data, img.mime), { temp: 0.2 }), NO_SELF)
  const s0 = selfFromOut(out)
  if (!s0) throw new AiError('parse', NO_SELF)
  const s = tidySelf(s0)
  if (!s.points.length && !s.exercises.length && !s.note) throw new AiError('parse', NO_SELF)
  return s
}
