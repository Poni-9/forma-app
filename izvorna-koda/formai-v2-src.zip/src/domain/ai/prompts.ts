import type { Activity, PlanDay, Profile } from '@/domain/types'
import { aiAllowed } from '@/domain/import/provenance'
import { formSeries, formBand, todayIso, addDays, weekStartIso } from '@/domain/training/load'
import { NUTRITION_RULES } from '@/domain/nutrition/energy'
import type { AiPart } from './client'
import { aiSafePlan, HIDDEN_NOTE } from './safe'
import { isCustom, LEVEL_LABEL } from '@/domain/focus/model'
import { focusContext } from './focusAi'
import { noPower } from '@/domain/training/zones'
import { pauseAiLine } from '@/domain/training/pause'
import { levelOf } from '@/domain/training/goal'

/**
 * (v3.49) Videz: nikoli obljube ali datuma (Blaž je dobil »zagotovim« in six-pack); slik trener ne more pokazati —
 * lestvico maščobe in slike vaj pokaže aplikacija sama pod odgovorom.
 */
export const LOOKS_RULE = 'O videzu (trebušne mišice, »izklesan«, postava) nikoli ne obljubljaj rezultata ali datuma in ne piši »zagotovim«. Povej, da je to odvisno od genetike in razporeditve maščobe, in daj merljive korake: tempo teže 0,3–0,5 kg na teden, obseg pasu, fotografija na 4 tedne. Slik ne moreš pokazati ne iskati: aplikacija sama pod odgovorom pokaže lestvico telesne maščobe (odraslim) in slike vaj iz svoje knjižnice — zato ne obljubljaj slik z interneta in ne pošiljaj povezav.'
/** (v3.50) mladoletni: brez tempa teže in lestvice maščobe (prej enako kot odraslim) */
export const LOOKS_RULE_MINOR = 'O videzu (trebušne mišice, »izklesan«, postava) nikoli ne obljubljaj rezultata ali datuma in ne piši »zagotovim«. Je mladoleten: telo še raste — brez hujšanja, primanjkljaja in tempa teže; merljivi koraki so ponovitve, moč pri vajah, kondicija in spanec. Slik ne moreš pokazati ne iskati: aplikacija sama pod odgovorom pokaže slike vaj iz svoje knjižnice — zato ne obljubljaj slik z interneta in ne pošiljaj povezav.'
/** (v3.50) starost ni vpisana: kot mladoleten brez hujšanja in tempa teže (ne vemo, ali je odrasel), a brez »telo še raste« */
export const LOOKS_RULE_NOAGE = 'O videzu (trebušne mišice, »izklesan«, postava) nikoli ne obljubljaj rezultata ali datuma in ne piši »zagotovim«. Starost ni vpisana: brez hujšanja, primanjkljaja in tempa teže, dokler je ne vpiše; merljivi koraki so ponovitve, moč pri vajah, kondicija in spanec. Slik ne moreš pokazati ne iskati: aplikacija sama pod odgovorom pokaže slike vaj iz svoje knjižnice — zato ne obljubljaj slik z interneta in ne pošiljaj povezav.'
/** (v3.50) Oznaka v kontekstu: starost ni vpisana. */
export const NOAGE_MARK = 'STAROST NI VPISANA'
/** (v3.49) Oznaka v kontekstu: brez merilnika moči — persona in naloge dajo utrip in RPE, ne vatov. */
export const NO_POWER_MARK = 'BREZ MERILNIKA MOČI'
/** (v3.50) Oznaka v kontekstu: pod 18 let (persona brez hujšanja in tempa teže). */
export const MINOR_MARK = 'MLADOLETEN'
/** (v3.50) Oznaka v kontekstu: uporabnica — persona piše v ženski obliki. */
export const FEMALE_MARK = 'Športnica:'
const FEMALE_RULE = 'Uporabnica je ženska — piši v ženski obliki (si naredila, bi morala, si utrujena).'
const PERSONA_HEAD = [
  'Si FORMAI — osebni kolesarski trener. Športnik hoče postati res dober kolesar do svoje dirke; vse ostalo (teža, moč, prehrana) služi temu cilju.',
  'Odgovarjaj IZKLJUČNO v slovenščini, v drugi osebi (ti), direktno in pošteno — brez olepševanja in brez napihnjenih številk.',
]
const NUMBERS_W = 'VEDNO s konkretnimi številkami iz konteksta: vati (izračunaj iz FTP, npr. 4 × 4 min pri 260–275 W), W/kg, trajanje, g ogljikovih hidratov na uro, kcal, ure na teden, datumi.'
const NUMBERS_HR = 'VEDNO s konkretnimi številkami iz konteksta: utrip (iz LTHR v kontekstu) in občutek (RPE), trajanje, g ogljikovih hidratov na uro, kcal, ure na teden, datumi. Nima merilnika moči — vatov ne dajaj kot cilj (kvečjemu kot orientacijo, če vpraša).'
// (v3.50) brez merilnika napredek ne iz W/kg (prej persona »izhajaj iz W/kg« ob »vatov ne dajaj kot cilj«)
const PROGRESS_W = 'Ko govoriš o napredku, izhajaj iz W/kg zdaj → cilj na dan dirke in iz mejnikov v kontekstu; povej, ali je na poti, pred ali za načrtom.'
const PROGRESS_HR = 'Ko govoriš o napredku, izhajaj iz testov, utripa in mejnikov v kontekstu — W/kg in vati so brez merilnika moči samo orientacija; povej, ali je na poti, pred ali za načrtom.'
/**
 * (v3.50) Primerjava z resnico je naloga nasveta za danes in pregleda tedna, ne klepeta — v klepetu je kontekst tih
 * (prej v personi: »najprej poglej trening v resnici« proti nalogi »brez ponavljanja stanja«).
 */
const REALITY_FIRST = 'Najprej poglej »trening v resnici« (dejanske ure na teden, utrip po conah, ali so bili ključni treningi res narejeni) in ga primerjaj z načrtom — povej naravnost, kje se razlikuje in kaj naj popravi.'
const PERSONA_TAIL = [
  'Drži se metode iz konteksta (80/20, dve ključni seji, bloki 3 + 1, tapering). Ne predlagaj stvari, ki odvračajo od cilja.',
  'Brez oznak markdown (brez **, #, tabel); za naštevanje uporabi kratke vrstice, ki se začnejo z »– «.',
  'Ne izmišljuj si podatkov — česar v kontekstu ni, tega ne veš in tako tudi povej.',
  'Ravni (»kako dober sem«) ocenjuj zadržano in brez hvaljenja: če FTP ni izmerjen z merilnikom moči (vpisan ali ocenjen iz utripa), to najprej povej; s profesionalci primerjaj samo, če to podpirajo izmerjeni podatki in rezultati.',
]
const personaBike = (power: boolean, looks: string) => [...PERSONA_HEAD, power ? NUMBERS_W : NUMBERS_HR, power ? PROGRESS_W : PROGRESS_HR, ...PERSONA_TAIL, looks, 'Nisi zdravnik: pri bolečini, poškodbi, vrtoglavici ali bolezni napoti k zdravniku.'].join('\n')

/** Oznaka v kontekstu: načrt po meri (fitnes, tek, kondicija) — drug trener, drugi poudarki. */
export const CUSTOM_MARK = 'NAČRT PO MERI'
const personaCustom = (looks: string) => [
  'Si FORMAI — osebni trener za fitnes, tek in kondicijo. Z uporabnikom sta se dogovorila za načrt (dogovor je v kontekstu) — vse, kar svetuješ, služi temu, kar si želi.',
  'Odgovarjaj IZKLJUČNO v slovenščini, v drugi osebi (ti), direktno in pošteno — brez olepševanja in brez napihnjenih obljub.',
  'S konkretnimi številkami iz konteksta: serije, ponovitve in kilogrami pri moči, minute in tempo (pogovorni tempo, utrip) pri kardiu, kcal in g beljakovin pri hrani, datumi.',
  'Ne govori o vatih, FTP, W/kg ali dirki, razen če jih omeni sam. Pri hujšanju z ohranjanjem mišic: težke serije ostanejo, beljakovine do cilja, zmeren primanjkljaj (izračuna ga aplikacija).',
  'Brez oznak markdown (brez **, #, tabel); za naštevanje uporabi kratke vrstice, ki se začnejo z »– «.',
  'Ne izmišljuj si podatkov — česar v kontekstu ni, tega ne veš in tako tudi povej.',
  looks,
  'Nisi zdravnik: pri bolečini, poškodbi, vrtoglavici ali bolezni napoti k zdravniku ali fizioterapevtu.',
].join('\n')
export const isCustomCtx = (ctx: string): boolean => ctx.includes(CUSTOM_MARK)
/** z merilnikom moči (ali neznano) — vati; z oznako NO_POWER_MARK utrip in RPE (v3.49) */
const hasPower = (ctx: string): boolean => !ctx.includes(NO_POWER_MARK)
const persona = (ctx: string): string => {
  const looks = ctx.includes(MINOR_MARK) ? LOOKS_RULE_MINOR : ctx.includes(NOAGE_MARK) ? LOOKS_RULE_NOAGE : LOOKS_RULE
  const base = isCustomCtx(ctx) ? personaCustom(looks) : personaBike(hasPower(ctx), looks)
  return ctx.includes(FEMALE_MARK) ? `${base}\n${FEMALE_RULE}` : base
}

const nn = (v: number | null | undefined): boolean => v != null && !Number.isNaN(v)
const r1 = (v: number): string => (Math.round(v * 10) / 10).toFixed(1)
/** (v3.50) decimalna vejica kot v aplikaciji (prej »1.5 h«, »70.2 kg« — model je prevzel piko) */
const dec = (v: number): string => String(Math.round(v * 10) / 10).replace('.', ',')
const DOW = ['nedelja', 'ponedeljek', 'torek', 'sreda', 'četrtek', 'petek', 'sobota']
const dowOf = (iso: string): string => DOW[new Date(iso + 'T12:00:00Z').getUTCDay()] ?? ''
/** (v3.50) »nedelja, 18. 10. 2026« — model ne računa dneva v tednu sam */
const dayName = (iso: string): string => `${dowOf(iso)}, ${+iso.slice(8, 10)}. ${+iso.slice(5, 7)}. ${iso.slice(0, 4)}`

function sexLabel(p: Profile): string {
  return p.sex === 'm' ? 'moški' : p.sex === 'z' ? 'ženska' : 'spol ni podan'
}

function goalLabel(p: Profile): string {
  switch (p.goal) {
    case 'hitrejsi': return 'biti hitrejši'
    case 'shujsati': return 'shujšati'
    case 'dirka': return 'priprava na dirko'
    case 'forma': return 'splošna forma'
    default: return 'cilj ni izbran'
  }
}

function levelLabel(p: Profile): string | null {
  switch (p.level) {
    case 1: return 'začetnik'
    case 2: return 'rekreativec'
    case 3: return 'napreden'
    case 4: return 'tekmovalec'
  }
  // (v3.50) brez vpisane ravni: načrt po meri iz dogovora, kolesar iz W/kg (prej »Raven: raven ni podana«)
  if (isCustom(p) && p.focus?.level) return LEVEL_LABEL[p.focus.level]
  const wkg = p.ftp && p.weightKg ? p.ftp / p.weightKg : null
  const lv = levelOf(wkg)
  return lv && wkg ? `${lv.name.toLowerCase()} (${wkg.toFixed(2).replace('.', ',')} W/kg)` : null
}
const EQUIP_L: Record<Profile['strength']['equipment'], string> = { gym: 'fitnes', home: 'doma', none: 'brez uteži' }

/** Profil brez identitete — ime, e-pošta in kraj NIKOLI ne gredo v poziv. */
function profileLines(p: Profile): string {
  const bits: string[] = [sexLabel(p)]
  if (nn(p.age)) bits.push(`${p.age} let`)
  if (p.push) bits.push(p.push === 'lahko' ? 'tip: raje lažje (manj naložen, ne priganjaj)' : p.push === 'trdo' ? 'tip: raje trdo (rad je naložen, zahtevnejši ton)' : 'tip: zmerno')
  if (nn(p.heightCm)) bits.push(`${p.heightCm} cm`)
  if (nn(p.weightKg)) bits.push(`${dec(p.weightKg as number)} kg`)
  if (nn(p.restHr)) bits.push(`utrip v mirovanju ${p.restHr}`)
  if (nn(p.maxHr)) bits.push(`maks. utrip ${p.maxHr}`)
  if (nn(p.lthr)) bits.push(`LTHR ${p.lthr}`)
  if (nn(p.ftp)) bits.push(`FTP ${p.ftp} W`)
  const gear: string[] = []
  if (p.gear.bikeOutdoor) gear.push('kolo zunaj')
  if (p.gear.trainer) gear.push('trenažer')
  if (p.gear.noBike) gear.push('brez kolesa')
  const lvl = levelLabel(p), hrs = nn(p.hoursPerWeek) ? `na voljo ${dec(p.hoursPerWeek as number)} h/teden` : ''
  const out = [
    `${p.sex === 'z' ? FEMALE_MARK : 'Športnik:'} ${bits.join(', ')}`,
    ...(p.age != null && p.age < 18 ? [`${MINOR_MARK} (pod 18 let): brez hujšanja, primanjkljaja in tempa teže — hrana za rast in trening.`] : []),
    ...(!(p.age != null && p.age > 0) ? [`${NOAGE_MARK}: brez hujšanja, primanjkljaja in tempa teže, dokler je ne vpiše.`] : []),
    `Cilj: ${goalLabel(p)}${p.raceDate ? `, tekma ${p.raceDate}` : ''}`,
    ...(lvl ? [`Raven: ${lvl}${hrs ? `, ${hrs}` : ''}`] : hrs ? [`Čas: ${hrs}`] : []),
    `Oprema: ${gear.length ? gear.join(', ') : 'ni podana'}${p.strength.on ? `; moč: da (${EQUIP_L[p.strength.equipment] ?? p.strength.equipment})` : '; moč: ne'}${noPower(p) ? `; ${NO_POWER_MARK} (cilji v utripu in RPE, ne v vatih)` : ''}`,
  ]
  return out.join('\n')
}

function actLine(a: Activity): string {
  const bits: string[] = [a.date, a.sport]
  if (nn(a.durationMin)) bits.push(`${Math.round(a.durationMin as number)} min`)
  if (nn(a.distKm)) bits.push(`${r1(a.distKm as number)} km`)
  if (nn(a.elevM)) bits.push(`${Math.round(a.elevM as number)} m vzpona`)
  if (nn(a.avgHr)) bits.push(`HR ${Math.round(a.avgHr as number)}`)
  if (nn(a.avgPower)) bits.push(`${Math.round(a.avgPower as number)} W`)
  if (nn(a.tss)) bits.push(`TSS ${Math.round(a.tss as number)}`)
  // občutek, ki ga je vpisal uporabnik (samo pri aktivnostih, ki jih AI sme videti — actLine dobi le te)
  if (nn(a.rpe) && (a.rpe as number) >= 1 && (a.rpe as number) <= 10) bits.push(`občutek ${Math.round(a.rpe as number)}/10`)
  return '- ' + bits.join(' · ')
}

function planLine(d: PlanDay): string {
  // (v3.50) z dnevom v tednu (»2026-10-18 ned«) — prej samo datum
  const bits: string[] = [`${d.date} ${dowOf(d.date).slice(0, 3)}`, d.kind, d.title, `${d.durationMin} min`]
  if (d.zone) bits.push(`cona ${d.zone}`)
  if (nn(d.tssTarget)) bits.push(`TSS ${Math.round(d.tssTarget as number)}`)
  if (d.done) bits.push('opravljeno')
  return '- ' + bits.join(' · ')
}

/**
 * Strnjen kontekst za vsak poziv.
 * V AI gre SAMO aktivnost, za katero aiAllowed(a) vrne true (Strava in neznani izvori odpadejo) — tudi posredno ne:
 * kljukica »opravljeno«, ki kaže na tako aktivnost, se v načrtu ne pokaže, števila skritih aktivnosti ne povemo.
 * hidden: aktivnosti je bilo več, kot jih je v seznamu (seznam je že filtriran — AI-safe view).
 * Nikoli: ime, e-pošta, kraj, natančna pot ali polyline.
 */
export function aiContext(activities: readonly Activity[], profile: Profile, plan: readonly PlanDay[], hidden = false, today: string = todayIso()): string {
  const allowed = activities.filter(a => aiAllowed(a))
  const sorted = [...allowed].sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0))
  const last30 = sorted.slice(0, 30)
  const anyHidden = hidden || allowed.length < activities.length
  const safePlan = aiSafePlan(plan, allowed)

  const series = formSeries(allowed, today)
  const now = series.length ? series[series.length - 1] : undefined
  const form = now
    ? `CTL (kondicija) ${Math.round(now.ctl)}, ATL (utrujenost) ${Math.round(now.atl)}, TSB (forma) ${r1(now.tsb)} — ${formBand(now.tsb).band}`
    : 'ni dovolj podatkov za formo'

  const weekAgo = addDays(today, -7)
  const weekTss = series.filter(s => s.date > weekAgo && s.date <= today).reduce((s, x) => s + x.tss, 0)

  const soon = [...safePlan]
    .filter(d => d.date >= today && d.date <= addDays(today, 7))
    .sort((a, b) => (a.date < b.date ? -1 : 1))
  // (v3.50) pretekli dnevi tega tedna z »opravljeno« — pregled tedna in prilagoditev vesta, kaj je bilo narejeno
  // (prej je bil v kontekstu samo načrt od danes naprej)
  const ws = weekStartIso(today)
  const past = [...safePlan].filter(d => d.date >= ws && d.date < today && d.kind !== 'pocitek' && !d.optional).sort((a, b) => (a.date < b.date ? -1 : 1))
  const custom = isCustom(profile)
  const tally = (xs: PlanDay[]) => `${xs.filter(d => d.done).length} od ${xs.length}`
  const pastStr = past.filter(d => d.kind === 'moc'), pastCardio = past.filter(d => d.kind !== 'moc')

  const parts: string[] = [
    ...(custom ? [`${CUSTOM_MARK} (fitnes, tek, kondicija — ne kolesarski načrt):`, focusContext(profile), ''] : profile.focus?.said?.length ? [`Kar je uporabnik povedal ob dogovoru (velja še naprej): ${profile.focus.said.slice(-8).map((x, k) => `${k + 1}. »${x.slice(0, 160)}«`).join(' ')}`, ''] : []),
    profileLines(profile),
    '',
    `Danes: ${dayName(today)} (${today})`,
    `Forma: ${form}`,
    `Obremenitev zadnjih 7 dni: ${Math.round(weekTss)} TSS`,
    '',
    `Zadnje aktivnosti (največ 30, od najnovejše):${last30.length ? '' : ' ni podatkov'}`,
    ...last30.map(actLine),
  ]
  if (past.length) {
    parts.push('', `Ta teden do danes (pretekli dnevi z oznako iz aplikacije)${custom ? ` — moč ${tally(pastStr)}${pastCardio.length ? `, kardio ${tally(pastCardio)}` : ''}` : ''}:`, ...past.map(planLine))
  }
  if (soon.length) {
    parts.push('', 'Načrt naslednjih 7 dni:', ...soon.map(planLine))
  }
  // (v3.50) premor »Ta teden …« (brez razloga »bolan«)
  const pz = profile.weekPause ? pauseAiLine(profile.weekPause, today) : null
  if (pz) parts.push('', pz)
  if (anyHidden) {
    // Uporabnik ima še aktivnosti, ki jih v AI ne smemo poslati — model naj ne sklepa, da jih ni (brez števila).
    parts.push('', HIDDEN_NOTE)
  }
  return parts.join('\n')
}

/** activities: če so podane, se kljukice, ki kažejo na aktivnost, ki ne sme v AI, iz načrta odstranijo (AI-safe). */
export function coachDailyPrompt(ctx: string, todayPlan: readonly PlanDay[], question?: string, activities?: readonly Activity[]): AiPart[] {
  const safe = activities ? aiSafePlan(todayPlan, activities) : todayPlan
  // (v3.49) pri moči tudi vaje iz načrta — naloga zahteva kilograme »iz načrta«, prej jih v pozivu ni bilo
  const exLine = (d: PlanDay) => (d.kind === 'moc' && d.exercises?.length ? `\n  vaje: ${d.exercises.map(e => `${e.name} ${e.sets}×${e.reps}${e.kg ? ` @${e.kg} kg` : ''}`).join(', ')}` : '')
  const plan = safe.length ? safe.map(d => `${planLine(d)}\n  navodilo: ${d.desc}${exLine(d)}`).join('\n') : 'danes ni načrtovane vadbe'
  const custom = isCustomCtx(ctx)
  // (v3.50) dan počitka: naloga brez serij, kilogramov in goriva za sejo, ki je ni (brez načrta ostane običajna naloga)
  const rest = safe.length > 0 && safe.every(d => d.kind === 'pocitek')
  const task = question
    ? `${question}\n\nTO JE NADALJEVANJE POGOVORA. Odgovori samo na zadnje vprašanje, kot bi odgovoril trener v klepetu: največ 120 besed, brez uvoda in brez ponavljanja stanja (zadnji tedni, zaostanek, ure, forma) — kontekst uporabi tiho, omeni ga samo, če vpraša ali če neposredno spremeni odgovor. Številke samo, kadar jih vprašanje rabi. Ne dodajaj »Naslednji korak«, razen če vpraša, kaj naj naredi. Če vprašanje ni povezano s ${custom ? 'treningom' : 'kolesarjenjem, treningom'}, zdravjem ali prehrano, to prijazno povej. Načrta v pogovoru ne spreminjaš — nikoli ne trdi, da si ga spremenil, premaknil ali odpovedal; premor (ta teden brez treningov ali brez kolesa) uporabnik uveljavi sam na Danes ali v Planu pod »Ta teden …«. Brez oznak markdown in brez emojijev.`
    : rest
      ? 'NALOGA: danes je dan počitka — v največ 60 besedah povej, kaj danes pomaga obnovi (hrana, beljakovine, spanec, sprehod ali raztezanje) in kaj ga čaka jutri. Brez serij, kilogramov in goriva za trening. Brez oznak markdown in brez emojijev.'
      : custom
        ? 'NALOGA: v največ 110 besedah povej, kaj naj danes naredi in zakaj — pri moči serije, ponovitve in kilograme (iz načrta in zadnjih vadb), pri kardiu tempo in trajanje, beljakovine danes in eno stvar, na katero naj pazi. Upoštevaj jutranje počutje, utrujenost in dogovor. Brez oznak markdown in brez emojijev.'
        : `${REALITY_FIRST}\nNALOGA: v največ 110 besedah povej, kaj naj danes naredi in zakaj — ${hasPower(ctx) ? 'z vati za današnjo sejo' : 'z utripom in občutkom (RPE) za današnjo sejo (nima merilnika moči)'}, gorivom (g OH na uro) in eno stvarjo, na katero naj pazi. Upoštevaj formo, jutranje počutje, plan in fazo do dirke. Brez oznak markdown in brez emojijev.`
  const text = [
    persona(ctx),
    '',
    NUTRITION_RULES,
    '',
    'KONTEKST:',
    ctx,
    '',
    'DANAŠNJI PLAN:',
    plan,
    '',
    task,
  ].join('\n')
  return [{ text }]
}

export function weeklyReviewPrompt(ctx: string): AiPart[] {
  const custom = isCustomCtx(ctx)
  const text = [
    persona(ctx),
    '',
    NUTRITION_RULES,
    '',
    'KONTEKST:',
    ctx,
    '',
    ...(custom ? [] : [REALITY_FIRST]),
    'NALOGA: napiši pregled zadnjega tedna v treh delih, vsak del največ dva stavka:',
    custom ? '1) Kaj je bilo dobro — z eno številko iz podatkov (treningi, kilogrami, minute, teža).' : '1) Kaj je bilo dobro — z eno številko iz podatkov (ure, ključni seji, teža, vati).',
    custom ? '2) Kaj je bilo slabo ali manjka — brez moraliziranja; je bila moč narejena po dogovoru (»Ta teden do danes« v kontekstu)?' : '2) Kaj je bilo slabo ali manjka — brez moraliziranja; ali sta bili obe ključni seji opravljeni?',
    custom ? '3) Kaj naredi naslednji teden — ena konkretna sprememba v okviru dogovora.' : '3) Kaj naredi naslednji teden — ena konkretna sprememba, v okviru faze do dirke.',
    'Skupaj največ 150 besed. Brez oznak markdown, brez emojijev.',
  ].join('\n')
  return [{ text }]
}

/** Oblika, ki jo mora vrniti adaptPlanPrompt. Integrator jo preslika v PlanDay. */
export const ADAPT_SCHEMA_HINT = `Vrni SAMO veljaven JSON te oblike, brez ograd in brez razlage okoli njega:
{
  "dnevi": [
    {
      "date": "YYYY-MM-DD",
      "kind": "kolo" | "tek" | "pohod" | "moc" | "pocitek" | "test",
      "title": "kratek naslov vadbe",
      "desc": "kako jo izvesti, 1-2 stavka",
      "durationMin": 0,
      "zone": "Z2" | "C3" | "pogovorni tempo" | null,
      "tssTarget": 0,
      "why": "zakaj ta dan, en stavek"
    }
  ],
  "povzetek": "kaj si spremenil in zakaj, največ dva stavka"
}
Pravila oblike: "dnevi" vsebuje natanko iste datume kot vhodni teden, v istem vrstnem redu.
"durationMin" je celo število minut (0 pri počitku). "tssTarget" je celo število ali null.
Vse besedilo je v slovenščini. Ne dodajaj polj, ki jih shema ne navaja.`

/** activities: če so podane, se kljukice, ki kažejo na aktivnost, ki ne sme v AI, iz tedna odstranijo (AI-safe). */
export function adaptPlanPrompt(ctx: string, week: readonly PlanDay[], activities?: readonly Activity[]): AiPart[] {
  const safe = activities ? aiSafePlan(week, activities) : week
  const lines = safe.length ? safe.map(d => `${planLine(d)}\n  navodilo: ${d.desc}`).join('\n') : 'teden je prazen'
  const custom = isCustomCtx(ctx)
  const text = [
    persona(ctx),
    '',
    'KONTEKST:',
    ctx,
    '',
    'OBSTOJEČI TEDEN:',
    lines,
    '',
    'NALOGA: prilagodi ta teden dejanskemu stanju — formi (TSB), jutranjemu počutju, opravljenim in izpuščenim vadbam, vremenu in opremi.',
    // (v3.50) pretekli dnevi so samo kontekst (»Ta teden do danes«) — prej je model zamujeni ključni trening prepisal v počitek
    'Spreminjaš samo dneve pod »OBSTOJEČI TEDEN« (od danes naprej); kar je bilo pred danes, je zgodovina — ne vračaj je.',
    ...(custom ? [
      'Pravila: ohrani vrste vadbe iz dogovora (moč, tek, kolo, hribi) in njihovo število, razen če je utrujen ali slabo spi — takrat skrajšaj ali prestavi; moč na istih mišicah ne dva dni zapored;',
      'kardio večinoma lahek (pogovorni tempo), največ en hitrejši trening; vsaj en dan počitka; ne povečuj obremenitve za več kot 10 %; v lažjem tednu brez dodatnega.',
      'V opisih kardia navedi tempo z besedo ali utrip (ne vatov). Dneve, ki so že opravljeni, pusti nespremenjene.',
    ] : [
      'Pravila: ohrani obe ključni seji (VO2max in prag/sweet spot), razen če je športnik utrujen (TSB pod -20 ali slabo počutje) — takrat eno prestavi ali skrajšaj; med ključnima sejama vsaj en lahek dan;',
      'dolga Z2 vožnja ostane (ob dežju na drug dan); 80/20; vsaj en dan počitka; ne povečuj obremenitve za več kot 10 %; v razbremenilnem tednu in taperingu brez dodatnih intervalov.',
      hasPower(ctx) ? 'V opisih navedi vate iz FTP. Dneve, ki so že opravljeni, pusti nespremenjene.' : 'V opisih navedi utrip iz LTHR in občutek (RPE), ne vatov — nima merilnika moči. Dneve, ki so že opravljeni, pusti nespremenjene.',
    ]),
    '',
    ADAPT_SCHEMA_HINT,
  ].join('\n')
  return [{ text }]
}

/** Base64 brez predpone data: — inlineData je ne sprejme. */
function bare(b64: string): string {
  const i = b64.indexOf('base64,')
  return i >= 0 ? b64.slice(i + 7) : b64
}

export function mealPhotoPrompt(
  imageBase64: string,
  mime: string,
  remainingKcal: number | null,
  remainingProteinG: number | null,
): AiPart[] {
  const left: string[] = []
  if (remainingKcal != null) left.push(`do dnevnega cilja mu ostane ${Math.round(remainingKcal)} kcal`)
  if (remainingProteinG != null) left.push(`in ${Math.round(remainingProteinG)} g beljakovin`)
  const text = [
    'Si prehranski ocenjevalec v slovenski aplikaciji FORMAI. Odgovarjaš izključno v slovenščini.',
    '',
    NUTRITION_RULES,
    '',
    left.length ? `Stanje uporabnika: ${left.join(' ')}.` : 'Stanja dnevnega cilja ne poznaš.',
    '',
    'POSTOPEK, po tem vrstnem redu:',
    '1) Če je na sliki kuhinjska tehtnica z odčitkom, PREBERI številko s tehtnice. Ta ima prednost pred vsako oceno. Zapiši jo v "grami_tehtnica".',
    '   Če je odčitek v drugi enoti (oz, lb), ga pretvori v grame. Če zaslon ni berljiv, pusti null.',
    '2) Prepoznaj jed ali sestavine. Bodi konkreten ("piščančji file z rižem"), ne splošen ("obrok").',
    '3) Oceni kcal in makrohranila ZA TISTO TEŽO — za odčitek s tehtnice, sicer za oceno teže na krožniku ("grami_ocena").',
    '   Če teža izhaja s tehtnice, "grami_ocena" pusti null in obratno.',
    '4) Če je hrana še v embalaži in je vidna deklaracija, uporabi vrednosti z deklaracije.',
    'Ne svetuj, naj uporabnik je manj. Ne komentiraj postave. Če slika ni hrana, vrni kcal 0 in v "opomba" povej, kaj vidiš.',
    '',
    'Vrni SAMO veljaven JSON te oblike, brez ograd in brez besedila okoli njega:',
    `{
  "jed": "ime jedi v slovenščini",
  "grami_tehtnica": 0,
  "grami_ocena": 0,
  "kcal": 0,
  "beljakovine_g": 0,
  "ogljikovi_hidrati_g": 0,
  "mascobe_g": 0,
  "obrok": "zajtrk" | "malica" | "kosilo" | "med_vadbo" | "vecerja" | "drugo",
  "zanesljivost": "visoka" | "srednja" | "nizka",
  "opomba": "kratka opomba, največ en stavek"
}`,
    '"grami_tehtnica", "grami_ocena", "ogljikovi_hidrati_g" in "mascobe_g" so lahko null. "kcal" in "beljakovine_g" sta vedno števili.',
    '"zanesljivost" je "visoka" samo pri odčitku s tehtnice ali deklaraciji.',
  ].join('\n')
  return [{ text }, { inlineData: { mimeType: mime, data: bare(imageBase64) } }]
}

/** Aplikacije, ki jih prepoznamo na posnetku (polje "app"); "strava" pomeni: vadba ne gre v AI. */
export const SHOT_APPS = ['strava', 'garmin', 'wahoo', 'zwift', 'polar', 'suunto', 'coros', 'apple', 'komoot', 'drugo'] as const

export function activityShotPrompt(imageBase64: string, mime: string, today: string = todayIso()): AiPart[] {
  const text = [
    'Iz posnetka zaslona športne aplikacije (Garmin, Strava, Wahoo, Zwift, ura, merilnik …) preberi povzetek ene vadbe.',
    'Beri SAMO tisto, kar na sliki dejansko piše. Ničesar ne dopolnjuj po občutku — česar ni, je null.',
    'Enote pretvori v metrični sistem: milje v km, čevlje v metre. Čas pretvori v minute (1:24:30 → 85).',
    `Današnji datum je ${today}. Vadba je bila danes ali prej — datum ne sme biti v prihodnosti.`,
    'Datum vrni kot ISO (YYYY-MM-DD). Če je zapisan brez leta, uporabi zadnji takšen pretekli datum (največ današnjega); »danes«, »včeraj« preračunaj iz današnjega datuma. Če datuma ni, vrni null.',
    'Šport preslikaj v eno od danih vrednosti; kar ne ustreza nobeni, je "drugo".',
    `Prepoznaj aplikacijo, iz katere je posnetek (logotip, barve, postavitev: Strava je oranžna z logotipom Strava), in jo vrni v "app": ${SHOT_APPS.map(x => `"${x}"`).join(' | ')} ali null, če ne veš.`,
    '',
    'Vrni SAMO veljaven JSON te oblike, brez ograd in brez besedila okoli njega:',
    `{
  "app": "strava" | "garmin" | "wahoo" | "zwift" | "polar" | "suunto" | "coros" | "apple" | "komoot" | "drugo" | null,
  "sport": "kolo" | "tek" | "pohod" | "moc" | "plavanje" | "drugo",
  "datum": "YYYY-MM-DD",
  "trajanje_min": 0,
  "razdalja_km": 0,
  "vzpon_m": 0,
  "povprecni_utrip": 0,
  "povprecna_moc": 0,
  "kcal": 0,
  "ime": "ime vadbe s slike",
  "zanesljivost": "visoka" | "srednja" | "nizka"
}`,
    'Vsa polja razen "sport" in "zanesljivost" so lahko null ("app" tudi). Besedilo je v slovenščini.',
    '"zanesljivost" je "nizka", če je slika zamegljena, obrezana ali če večine številk ni videti.',
  ].join('\n')
  return [{ text }, { inlineData: { mimeType: mime, data: bare(imageBase64) } }]
}


/**
 * Obrok iz opisa (napisan ali narekovan): »dva kosa kruha s pašteto in bela kava«. Ocena po sestavinah s tipičnimi
 * slovenskimi porcijami, kjer količina ni povedana. Brez moraliziranja; uporabnikove številke (grami, kosi) imajo prednost.
 */
export function mealTextPrompt(description: string, nowHHMM: string, remainingKcal: number | null, remainingProteinG: number | null, rules: string): AiPart[] {
  const left: string[] = []
  if (remainingKcal != null) left.push(`do dnevnega cilja mu ostane ${Math.round(remainingKcal)} kcal`)
  if (remainingProteinG != null) left.push(`in ${Math.round(remainingProteinG)} g beljakovin`)
  const text = [
    'Si prehranski ocenjevalec v slovenski aplikaciji FORMAI. Odgovarjaš izključno v slovenščini.',
    '',
    rules,
    '',
    left.length ? `Stanje uporabnika: ${left.join(' ')}.` : 'Stanja dnevnega cilja ne poznaš.',
    `Zdaj je ura ${nowHHMM}.`,
    '',
    'Uporabnik je z besedami opisal, kaj je pojedel ali popil (lahko narekovano, z napakami v prepoznavi govora):',
    `"""${description.slice(0, 1200)}"""`,
    '',
    'POSTOPEK:',
    '1) Razdeli opis na posamezne sestavine ali jedi (postavke). Popravi očitne napake prepoznave govora.',
    '2) Količine: če jih uporabnik pove (grami, kosi, žlice, skodelice, "velik/majhen"), jih upoštevaj. Sicer vzemi tipično slovensko porcijo',
    '   (npr. kos kruha 40 g, rogljič 60 g, jogurt 180 g, skodelica kave z mlekom 200 ml, krožnik testenin 300 g kuhanih, banana 120 g, jabolko 150 g).',
    '3) Za znane izdelke (npr. Frutabela, Cockta, Milka, Argeta) uporabi vrednosti z deklaracije.',
    '4) Za vsako postavko oceni kcal, beljakovine, ogljikove hidrate in maščobe za to količino. Vsote naj bodo vsota postavk.',
    '5) Če iz opisa izhaja obrok ali ura ("za zajtrk", "ob 10h", "včeraj zvečer" ne — samo danes), jo vrni; sicer null.',
    '6) Če je nekaj zelo nejasno in močno vpliva na kalorije (npr. količina olja, velikost porcije), zastavi ENO kratko vprašanje v "vprasanje", sicer null.',
    'Ne svetuj, naj uporabnik je manj, in ne komentiraj postave. Če opis ni hrana ali pijača, vrni prazne postavke, kcal 0 in vprašanje.',
    '',
    'Vrni SAMO veljaven JSON te oblike, brez ograd in brez besedila okoli njega:',
    `{
  "jed": "kratko ime obroka v slovenščini (do 60 znakov)",
  "postavke": [{ "ime": "kruh, polnozrnat", "kolicina": "2 kosa (~80 g)", "grami": 80, "kcal": 190, "beljakovine_g": 8, "ogljikovi_hidrati_g": 34, "mascobe_g": 2 }],
  "kcal": 0,
  "beljakovine_g": 0,
  "ogljikovi_hidrati_g": 0,
  "mascobe_g": 0,
  "obrok": "zajtrk | malica | kosilo | vecerja | drugo | null",
  "ura": "HH:MM ali null",
  "zanesljivost": "visoka | srednja | nizka",
  "vprasanje": null
}`,
  ].join('\n')
  return [{ text }]
}
