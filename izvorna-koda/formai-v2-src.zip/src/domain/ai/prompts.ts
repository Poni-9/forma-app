import type { Activity, PlanDay, Profile } from '@/domain/types'
import { aiAllowed } from '@/domain/import/provenance'
import { formSeries, formBand, todayIso, addDays } from '@/domain/training/load'
import { NUTRITION_RULES } from '@/domain/nutrition/energy'
import type { AiPart } from './client'

const PERSONA = [
  'Si FORMAI — osebni kolesarski trener. Športnik hoče postati res dober kolesar do svoje dirke; vse ostalo (teža, moč, prehrana) služi temu cilju.',
  'Odgovarjaj IZKLJUČNO v slovenščini, v drugi osebi (ti), direktno in pošteno — brez olepševanja in brez napihnjenih številk.',
  'VEDNO s konkretnimi številkami iz konteksta: vati (izračunaj iz FTP, npr. 4 × 4 min pri 260–275 W), W/kg, trajanje, g ogljikovih hidratov na uro, kcal, ure na teden, datumi.',
  'Ko govoriš o napredku, izhajaj iz W/kg zdaj → cilj na dan dirke in iz mejnikov v kontekstu; povej, ali je na poti, pred ali za načrtom.',
  'Drži se metode iz konteksta (80/20, dve ključni seji, bloki 3 + 1, tapering). Ne predlagaj stvari, ki odvračajo od cilja.',
  'Najprej poglej »trening v resnici« (dejanske ure na teden, utrip po conah, ali so bili ključni treningi res narejeni) in ga primerjaj z načrtom — povej naravnost, kje se razlikuje in kaj naj popravi. Če nima merilnika moči, daj cilje v utripu in občutku (RPE), vate samo kot orientacijo.',
  'Brez oznak markdown (brez **, #, tabel); za naštevanje uporabi kratke vrstice, ki se začnejo z »– «.',
  'Ne izmišljuj si podatkov — česar v kontekstu ni, tega ne veš in tako tudi povej.',
  'Nisi zdravnik: pri bolečini, poškodbi, vrtoglavici ali bolezni napoti k zdravniku.',
].join('\n')

const nn = (v: number | null | undefined): boolean => v != null && !Number.isNaN(v)
const r1 = (v: number): string => (Math.round(v * 10) / 10).toFixed(1)

function sexLabel(p: Profile): string {
  return p.sex === 'm' ? 'moški' : p.sex === 'z' ? 'ženska' : 'spol ni podan'
}

function goalLabel(p: Profile): string {
  switch (p.goal) {
    case 'hitrejsi': return 'biti hitrejši'
    case 'shujsati': return 'shujšati'
    case 'dirka': return 'priprava na dirko'
    case 'forma': return 'splošna forma'
    default: return 'cilj ni izbran'
  }
}

function levelLabel(p: Profile): string {
  switch (p.level) {
    case 1: return 'začetnik'
    case 2: return 'rekreativec'
    case 3: return 'napreden'
    case 4: return 'tekmovalec'
    default: return 'raven ni podana'
  }
}

/** Profil brez identitete — ime, e-pošta in kraj NIKOLI ne gredo v poziv. */
function profileLines(p: Profile): string {
  const bits: string[] = [sexLabel(p)]
  if (nn(p.age)) bits.push(`${p.age} let`)
  if (nn(p.heightCm)) bits.push(`${p.heightCm} cm`)
  if (nn(p.weightKg)) bits.push(`${p.weightKg} kg`)
  if (nn(p.restHr)) bits.push(`utrip v mirovanju ${p.restHr}`)
  if (nn(p.maxHr)) bits.push(`maks. utrip ${p.maxHr}`)
  if (nn(p.lthr)) bits.push(`LTHR ${p.lthr}`)
  if (nn(p.ftp)) bits.push(`FTP ${p.ftp} W`)
  const gear: string[] = []
  if (p.gear.bikeOutdoor) gear.push('kolo zunaj')
  if (p.gear.trainer) gear.push('trenažer')
  if (p.gear.noBike) gear.push('brez kolesa')
  const out = [
    `Športnik: ${bits.join(', ')}`,
    `Cilj: ${goalLabel(p)}${p.raceDate ? `, tekma ${p.raceDate}` : ''}`,
    `Raven: ${levelLabel(p)}${nn(p.hoursPerWeek) ? `, na voljo ${p.hoursPerWeek} h/teden` : ''}`,
    `Oprema: ${gear.length ? gear.join(', ') : 'ni podana'}${p.strength.on ? `; moč: da (${p.strength.equipment})` : '; moč: ne'}`,
  ]
  return out.join('\n')
}

function actLine(a: Activity): string {
  const bits: string[] = [a.date, a.sport]
  if (nn(a.durationMin)) bits.push(`${Math.round(a.durationMin as number)} min`)
  if (nn(a.distKm)) bits.push(`${r1(a.distKm as number)} km`)
  if (nn(a.elevM)) bits.push(`${Math.round(a.elevM as number)} m vzpona`)
  if (nn(a.avgHr)) bits.push(`HR ${Math.round(a.avgHr as number)}`)
  if (nn(a.avgPower)) bits.push(`${Math.round(a.avgPower as number)} W`)
  if (nn(a.tss)) bits.push(`TSS ${Math.round(a.tss as number)}`)
  return '- ' + bits.join(' · ')
}

function planLine(d: PlanDay): string {
  const bits: string[] = [d.date, d.kind, d.title, `${d.durationMin} min`]
  if (d.zone) bits.push(`cona ${d.zone}`)
  if (nn(d.tssTarget)) bits.push(`TSS ${Math.round(d.tssTarget as number)}`)
  if (d.done) bits.push('opravljeno')
  return '- ' + bits.join(' · ')
}

/**
 * Strnjen kontekst za vsak poziv.
 * V AI gre SAMO aktivnost, za katero aiAllowed(a) vrne true (Strava in neznani izvori odpadejo).
 * Nikoli: ime, e-pošta, kraj, natančna pot ali polyline.
 */
export function aiContext(activities: readonly Activity[], profile: Profile, plan: readonly PlanDay[]): string {
  const allowed = activities.filter(a => aiAllowed(a))
  const sorted = [...allowed].sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0))
  const last30 = sorted.slice(0, 30)
  const skipped = activities.length - allowed.length

  const today = todayIso()
  const series = formSeries(allowed, today)
  const now = series.length ? series[series.length - 1] : undefined
  const form = now
    ? `CTL (kondicija) ${Math.round(now.ctl)}, ATL (utrujenost) ${Math.round(now.atl)}, TSB (forma) ${r1(now.tsb)} — ${formBand(now.tsb).band}`
    : 'ni dovolj podatkov za formo'

  const weekAgo = addDays(today, -7)
  const weekTss = series.filter(s => s.date > weekAgo && s.date <= today).reduce((s, x) => s + x.tss, 0)

  const soon = [...plan]
    .filter(d => d.date >= today && d.date <= addDays(today, 7))
    .sort((a, b) => (a.date < b.date ? -1 : 1))

  const parts: string[] = [
    profileLines(profile),
    '',
    `Danes: ${today}`,
    `Forma: ${form}`,
    `Obremenitev zadnjih 7 dni: ${Math.round(weekTss)} TSS`,
    '',
    `Zadnje aktivnosti (največ 30, od najnovejše):${last30.length ? '' : ' ni podatkov'}`,
    ...last30.map(actLine),
  ]
  if (soon.length) {
    parts.push('', 'Načrt naslednjih 7 dni:', ...soon.map(planLine))
  }
  if (skipped > 0) {
    // Uporabnik ima še aktivnosti, ki jih v AI ne smemo poslati — model naj ne sklepa, da jih ni.
    parts.push('', `Opomba: ${skipped} aktivnosti ni v tem povzetku zaradi pravil o virih podatkov. Ne trdi, da uporabnik takrat ni treniral.`)
  }
  return parts.join('\n')
}

export function coachDailyPrompt(ctx: string, todayPlan: readonly PlanDay[], question?: string): AiPart[] {
  const plan = todayPlan.length ? todayPlan.map(d => `${planLine(d)}\n  navodilo: ${d.desc}`).join('\n') : 'danes ni načrtovane vadbe'
  const task = question
    ? `${question}\n\nTO JE NADALJEVANJE POGOVORA. Odgovori samo na zadnje vprašanje, kot bi odgovoril trener v klepetu: največ 120 besed, brez uvoda in brez ponavljanja stanja (zadnji tedni, zaostanek, ure, forma) — kontekst uporabi tiho, omeni ga samo, če vpraša ali če neposredno spremeni odgovor. Številke samo, kadar jih vprašanje rabi. Ne dodajaj »Naslednji korak«, razen če vpraša, kaj naj naredi. Če vprašanje ni povezano s kolesarjenjem, treningom, zdravjem ali prehrano, to prijazno povej.`
    : 'NALOGA: v največ 110 besedah povej, kaj naj danes naredi in zakaj — z vati za današnjo sejo, gorivom (g OH na uro) in eno stvarjo, na katero naj pazi. Upoštevaj formo, jutranje počutje, plan in fazo do dirke.'
  const text = [
    PERSONA,
    '',
    NUTRITION_RULES,
    '',
    'KONTEKST:',
    ctx,
    '',
    'DANAŠNJI PLAN:',
    plan,
    '',
    task,
  ].join('\n')
  return [{ text }]
}

export function weeklyReviewPrompt(ctx: string): AiPart[] {
  const text = [
    PERSONA,
    '',
    NUTRITION_RULES,
    '',
    'KONTEKST:',
    ctx,
    '',
    'NALOGA: napiši pregled zadnjega tedna v treh delih, vsak del največ dva stavka:',
    '1) Kaj je bilo dobro — z eno številko iz podatkov (ure, ključni seji, teža, vati).',
    '2) Kaj je bilo slabo ali manjka — brez moraliziranja; ali sta bili obe ključni seji opravljeni?',
    '3) Kaj naredi naslednji teden — ena konkretna sprememba, v okviru faze do dirke.',
    'Skupaj največ 150 besed. Brez oznak markdown, brez emojijev.',
  ].join('\n')
  return [{ text }]
}

/** Oblika, ki jo mora vrniti adaptPlanPrompt. Integrator jo preslika v PlanDay. */
export const ADAPT_SCHEMA_HINT = `Vrni SAMO veljaven JSON te oblike, brez ograd in brez razlage okoli njega:
{
  "dnevi": [
    {
      "date": "YYYY-MM-DD",
      "kind": "kolo" | "tek" | "pohod" | "moc" | "pocitek" | "test",
      "title": "kratek naslov vadbe",
      "desc": "kako jo izvesti, 1-2 stavka",
      "durationMin": 0,
      "zone": "Z2" | "C3" | "pogovorni tempo" | null,
      "tssTarget": 0,
      "why": "zakaj ta dan, en stavek"
    }
  ],
  "povzetek": "kaj si spremenil in zakaj, največ dva stavka"
}
Pravila oblike: "dnevi" vsebuje natanko iste datume kot vhodni teden, v istem vrstnem redu.
"durationMin" je celo število minut (0 pri počitku). "tssTarget" je celo število ali null.
Vse besedilo je v slovenščini. Ne dodajaj polj, ki jih shema ne navaja.`

export function adaptPlanPrompt(ctx: string, week: readonly PlanDay[]): AiPart[] {
  const lines = week.length ? week.map(d => `${planLine(d)}\n  navodilo: ${d.desc}`).join('\n') : 'teden je prazen'
  const text = [
    PERSONA,
    '',
    'KONTEKST:',
    ctx,
    '',
    'OBSTOJEČI TEDEN:',
    lines,
    '',
    'NALOGA: prilagodi ta teden dejanskemu stanju — formi (TSB), jutranjemu počutju, opravljenim in izpuščenim vadbam, vremenu in opremi.',
    'Pravila: ohrani obe ključni seji (VO2max in prag/sweet spot), razen če je športnik utrujen (TSB pod -20 ali slabo počutje) — takrat eno prestavi ali skrajšaj; med ključnima sejama vsaj en lahek dan;',
    'dolga Z2 vožnja ostane (ob dežju na drug dan); 80/20; vsaj en dan počitka; ne povečuj obremenitve za več kot 10 %; v razbremenilnem tednu in taperingu brez dodatnih intervalov.',
    'V opisih navedi vate iz FTP. Dneve, ki so že opravljeni, pusti nespremenjene.',
    '',
    ADAPT_SCHEMA_HINT,
  ].join('\n')
  return [{ text }]
}

/** Base64 brez predpone data: — inlineData je ne sprejme. */
function bare(b64: string): string {
  const i = b64.indexOf('base64,')
  return i >= 0 ? b64.slice(i + 7) : b64
}

export function mealPhotoPrompt(
  imageBase64: string,
  mime: string,
  remainingKcal: number | null,
  remainingProteinG: number | null,
): AiPart[] {
  const left: string[] = []
  if (remainingKcal != null) left.push(`do dnevnega cilja mu ostane ${Math.round(remainingKcal)} kcal`)
  if (remainingProteinG != null) left.push(`in ${Math.round(remainingProteinG)} g beljakovin`)
  const text = [
    'Si prehranski ocenjevalec v slovenski aplikaciji FORMAI. Odgovarjaš izključno v slovenščini.',
    '',
    NUTRITION_RULES,
    '',
    left.length ? `Stanje uporabnika: ${left.join(' ')}.` : 'Stanja dnevnega cilja ne poznaš.',
    '',
    'POSTOPEK, po tem vrstnem redu:',
    '1) Če je na sliki kuhinjska tehtnica z odčitkom, PREBERI številko s tehtnice. Ta ima prednost pred vsako oceno. Zapiši jo v "grami_tehtnica".',
    '   Če je odčitek v drugi enoti (oz, lb), ga pretvori v grame. Če zaslon ni berljiv, pusti null.',
    '2) Prepoznaj jed ali sestavine. Bodi konkreten ("piščančji file z rižem"), ne splošen ("obrok").',
    '3) Oceni kcal in makrohranila ZA TISTO TEŽO — za odčitek s tehtnice, sicer za oceno teže na krožniku ("grami_ocena").',
    '   Če teža izhaja s tehtnice, "grami_ocena" pusti null in obratno.',
    '4) Če je hrana še v embalaži in je vidna deklaracija, uporabi vrednosti z deklaracije.',
    'Ne svetuj, naj uporabnik je manj. Ne komentiraj postave. Če slika ni hrana, vrni kcal 0 in v "opomba" povej, kaj vidiš.',
    '',
    'Vrni SAMO veljaven JSON te oblike, brez ograd in brez besedila okoli njega:',
    `{
  "jed": "ime jedi v slovenščini",
  "grami_tehtnica": 0,
  "grami_ocena": 0,
  "kcal": 0,
  "beljakovine_g": 0,
  "ogljikovi_hidrati_g": 0,
  "mascobe_g": 0,
  "obrok": "zajtrk" | "malica" | "kosilo" | "med_vadbo" | "vecerja" | "drugo",
  "zanesljivost": "visoka" | "srednja" | "nizka",
  "opomba": "kratka opomba, največ en stavek"
}`,
    '"grami_tehtnica", "grami_ocena", "ogljikovi_hidrati_g" in "mascobe_g" so lahko null. "kcal" in "beljakovine_g" sta vedno števili.',
    '"zanesljivost" je "visoka" samo pri odčitku s tehtnice ali deklaraciji.',
  ].join('\n')
  return [{ text }, { inlineData: { mimeType: mime, data: bare(imageBase64) } }]
}

export function activityShotPrompt(imageBase64: string, mime: string): AiPart[] {
  const text = [
    'Iz posnetka zaslona športne aplikacije (Garmin, Strava, Wahoo, Zwift, ura, merilnik …) preberi povzetek ene vadbe.',
    'Beri SAMO tisto, kar na sliki dejansko piše. Ničesar ne dopolnjuj po občutku — česar ni, je null.',
    'Enote pretvori v metrični sistem: milje v km, čevlje v metre. Čas pretvori v minute (1:24:30 → 85).',
    'Datum vrni kot ISO (YYYY-MM-DD). Če je zapisan brez leta, uporabi tekoče leto. Če datuma ni, vrni null.',
    'Šport preslikaj v eno od danih vrednosti; kar ne ustreza nobeni, je "drugo".',
    '',
    'Vrni SAMO veljaven JSON te oblike, brez ograd in brez besedila okoli njega:',
    `{
  "sport": "kolo" | "tek" | "pohod" | "moc" | "plavanje" | "drugo",
  "datum": "YYYY-MM-DD",
  "trajanje_min": 0,
  "razdalja_km": 0,
  "vzpon_m": 0,
  "povprecni_utrip": 0,
  "povprecna_moc": 0,
  "kcal": 0,
  "ime": "ime vadbe s slike",
  "zanesljivost": "visoka" | "srednja" | "nizka"
}`,
    'Vsa polja razen "sport" in "zanesljivost" so lahko null. Besedilo je v slovenščini.',
    '"zanesljivost" je "nizka", če je slika zamegljena, obrezana ali če večine številk ni videti.',
  ].join('\n')
  return [{ text }, { inlineData: { mimeType: mime, data: bare(imageBase64) } }]
}
