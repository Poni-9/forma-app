import type { Activity } from '@/domain/types'
import { aiAllowed } from '@/domain/import/provenance'

/**
 * NEDOTAKLJIVA VAROVALKA — sanitizeGaps (prenos iz forma-trener.html).
 * Del uporabnikovih voženj (Strava, neznani izvori) AI ne sme videti. Zato AI ne sme trditi,
 * da uporabnik ni treniral: ko take aktivnosti obstajajo, iz AI besedila odstranimo stavke
 * o neaktivnosti, premoru ali pavzi. Regex je enak kot v stari aplikaciji.
 */
/** Izvirni regex iz forma-trener.html (nespremenjen). */
export const AI_GAP_RX_V1 = /(neaktivn\w*|popolne\s+neaktivnosti|premor\w*|pavz\w*|nisi\s+treniral\w*|brez\s+treningov?|brez\s+aktivnosti|vrn\w+\s+(se\s+)?po\s+(pavzi|premoru)|po\s+tednu\s+brez|počival\w*\s+(cel|ves)\s+teden|dolg\w+\s+odmor\w*|inactiv\w*|no\s+training|after\s+a\s+break)/i
/** Dopolnitev (samo strožje): »neaktiven«, »nisi vozil/kolesaril/bil aktiven«, »brez vožnje«. */
const AI_GAP_RX_EXTRA = /(neaktiv\w*|nisi\s+(vozil|kolesaril|bil\s+aktiven)\w*|brez\s+vo[žz]nj\w*)/i
export const AI_GAP_RX = { test: (x: string) => AI_GAP_RX_V1.test(x) || AI_GAP_RX_EXTRA.test(x) }

/** Ali ima uporabnik aktivnosti, ki jih AI ne vidi (Strava, neznan izvor, potekle). */
export function hasHiddenActivities(acts: readonly Activity[]): boolean {
  return acts.some(a => !aiAllowed(a))
}

/** Odstrani stavke o »premoru/neaktivnosti«, kadar AI ne vidi vseh aktivnosti. Odstavki ostanejo. */
export function sanitizeGaps(txt: string, hidden: boolean): string {
  try {
    if (!txt || !hidden) return txt
    const paras = String(txt).split(/\n\s*\n|\n/)
    const out = paras
      .map(p => p.split(/(?<=[.!?])\s+/).filter(x => !AI_GAP_RX.test(x)).join(' ').replace(/[ \t]{2,}/g, ' ').trim())
      .filter(Boolean)
    return out.join('\n\n').trim()
  } catch { return txt }
}

/** Isto za sezname (npr. šibkosti v profilu športnika). */
export function sanitizeList(list: readonly string[], hidden: boolean): string[] {
  if (!hidden) return [...list]
  return list.map(x => sanitizeGaps(x, true)).filter(Boolean)
}
