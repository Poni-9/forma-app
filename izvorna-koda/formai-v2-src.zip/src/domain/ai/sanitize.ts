import type { Activity } from '@/domain/types'
import { aiAllowed } from '@/domain/import/provenance'

/**
 * NEDOTAKLJIVA VAROVALKA — sanitizeGaps (prenos iz forma-trener.html).
 * Del uporabnikovih voženj (Strava, neznani izvori) AI ne sme videti. Zato AI ne sme trditi,
 * da uporabnik ni treniral: ko take aktivnosti obstajajo, iz AI besedila odstranimo stavke
 * o neaktivnosti, premoru ali pavzi. Regex je enak kot v stari aplikaciji.
 */
/** Izvirni regex iz forma-trener.html (nespremenjen). */
export const AI_GAP_RX_V1 = /(neaktivn\w*|popolne\s+neaktivnosti|premor\w*|pavz\w*|nisi\s+treniral\w*|brez\s+treningov?|brez\s+aktivnosti|vrn\w+\s+(se\s+)?po\s+(pavzi|premoru)|po\s+tednu\s+brez|počival\w*\s+(cel|ves)\s+teden|dolg\w+\s+odmor\w*|inactiv\w*|no\s+training|after\s+a\s+break)/i
/** Dopolnitev (samo strožje): »neaktiven«, »nisi vozil/kolesaril/bil aktiven«, »brez vožnje«. */
const AI_GAP_RX_EXTRA = /(neaktiv\w*|nisi\s+(vozil|kolesaril|bil\s+aktiven)\w*|brez\s+vo[žz]nj\w*)/i
export const AI_GAP_RX = { test: (x: string) => AI_GAP_RX_V1.test(x) || AI_GAP_RX_EXTRA.test(x) }

/** Ali ima uporabnik aktivnosti, ki jih AI ne vidi (Strava, neznan izvor, potekle). */
export function hasHiddenActivities(acts: readonly Activity[]): boolean {
  return acts.some(a => !aiAllowed(a))
}

/** Odstrani stavke o »premoru/neaktivnosti«, kadar AI ne vidi vseh aktivnosti. Odstavki ostanejo. */
export function sanitizeGaps(txt: string, hidden: boolean): string {
  try {
    if (!txt || !hidden) return txt
    const paras = String(txt).split(/\n\s*\n|\n/)
    const out = paras
      .map(p => p.split(/(?<=[.!?])\s+/).filter(x => !AI_GAP_RX.test(x)).join(' ').replace(/[ \t]{2,}/g, ' ').trim())
      .filter(Boolean)
    return out.join('\n\n').trim()
  } catch { return txt }
}

/**
 * (v3.49) Brez zagotovil v odgovorih trenerja (Blaž: »zagotovim« in six-pack do datuma). Varnostna mreža za primer, ko
 * model pravilo v pozivu preskoči: »zagotovim ti, da …« → »realno je, da …«, »zagotovo« → »verjetno«; stavek, ki obljublja
 * videz (six-pack, izklesan, trebušne mišice …) ali je samo zagotovilo, izpade. Če je kaj izpadlo, pride pripis.
 * Vrstice (alineje) ostanejo vrstice. sanitizeGaps ostane ločen in nespremenjen.
 */
// samo obljube v 1. osebi in »zagotovo« — »beljakovine zagotovijo regeneracijo« ni obljuba
const GUARANTEE = /(?<!\p{L})(zagotavljam|zagotovim|garantiram|obljubim|obljubljam|zagotovo|stoodstotno|100[\s-]*odstotno|garantirano|100\s*%\s+(?:zagotovo|gotovo|sigurno))(?!\p{L})/iu
const GUAR_DA = /(?<!\p{L})(zagotavljam|zagotovim|garantiram|obljubim|obljubljam)(\s+ti)?\s*,?\s+da(?!\p{L})/giu
const SURE = /(?<!\p{L})(stoodstotno|100[\s-]*odstotno|garantirano|100\s*%\s+(?:zagotovo|gotovo|sigurno))(?!\p{L})/giu
/** obljuba v 1. osebi (»To ti zagotovim.«) — stavek izpade */
const VOW = /(?<!\p{L})(zagotavljam|zagotovim|garantiram|obljubim|obljubljam)(?!\p{L})/iu
// (v3.50) »zagotovo« oslabi samo v obljubi izida (prihodnjik, rok, izid) — »Zagotovo vzemi gel« in »zagotovo ne treniraj«
// sta navodili, ne obljubi (prej »Verjetno vzemi gel«)
const ZAG = /(?<!\p{L})zagotovo(?!\p{L})/giu
const PROMISE = /(?<!\p{L})(?:bo|boš|bos|bom|bova|bosta|bomo|boste|bodo)(?!\p{L})|(?<!\p{L})do\s+(?:\d|konca|poletja|pomladi|jeseni|zime|novega|januar|februar|marc|april|maj|junij|julij|avgust|septemb|oktob|novemb|decemb)|(?<!\p{L})v\s+\d+\s+(?:dneh|tednih|mesecih|letih)|(?<!\p{L})(?:izgub|dosež|shujša|pridob)\p{L}*/iu
const LOOK = /(six[\s-]?pack|sixpack|izklesa\p{L}*|trebušn\p{L}*\s+mišic\p{L}*|vidn\p{L}*\s+trebuh\p{L}*|kock\p{L}*\s+na\s+trebuh\p{L}*|definiran\p{L}*|(?<!\p{L})postav[aeo](?!\p{L})|videz\p{L}*|(?:z|iz)gledal\p{L}*)/iu
export const HONEST_NOTE = 'Videza in roka zanj ti ne morem obljubiti — odvisno je od genetike, razporeditve maščobe in mišic. Merljivo pa je: obseg pasu, fotografija na 4 tedne in tempo teže 0,3–0,5 kg na teden.'
/** (v3.50) mladoletnemu brez tempa teže — hujšanja do 18. leta aplikacija ne svetuje */
export const HONEST_NOTE_MINOR = 'Videza in roka zanj ti ne morem obljubiti — telo še raste. Merljivo pa je: ponovitve, moč pri vajah in spanec.'
/** (v3.50) brez vpisane starosti brez tempa teže (ne vemo, ali je odrasel) — prej opomba kot odraslemu */
export const HONEST_NOTE_NOAGE = 'Videza in roka zanj ti ne morem obljubiti — odvisno je od genetike, razporeditve maščobe in mišic. Merljivo pa je: ponovitve, moč pri vajah in obseg pasu.'
const cap = (s: string, like: string) => (/^\p{Lu}/u.test(like) ? s.charAt(0).toUpperCase() + s.slice(1) : s)

export function honest(txt: string, o?: { minor?: boolean; noAge?: boolean }): string {
  try {
    if (!txt || !GUARANTEE.test(txt)) return txt
    let look = false
    const lines = String(txt).split('\n').map(line => {
      if (!line.trim()) return line
      const parts = line.split(/(?<=[.!?])\s+/).map(s => {
        let x = s.replace(GUAR_DA, m => cap('realno je, da', m)).replace(SURE, m => cap('verjetno', m))
        if (PROMISE.test(s) || LOOK.test(s)) x = x.replace(ZAG, m => cap('verjetno', m))
        // obljuba videza (tudi omiljena) ali golo zagotovilo (»To ti zagotovim.«) → stavek izpade
        if (x !== s && LOOK.test(s)) { look = true; return '' }
        if (VOW.test(x)) { if (LOOK.test(s)) look = true; return '' }
        return x
      }).filter(Boolean)
      return parts.length ? parts.join(' ') : null
    }).filter((l): l is string => l !== null)
    const out = lines.join('\n').replace(/\n{3,}/g, '\n\n').trim()
    const note = o?.minor ? HONEST_NOTE_MINOR : o?.noAge ? HONEST_NOTE_NOAGE : HONEST_NOTE
    return look || !out ? (out ? `${out}\n\n${note}` : note) : out
  } catch { return txt }
}

/** Isto za sezname (npr. šibkosti v profilu športnika). */
export function sanitizeList(list: readonly string[], hidden: boolean): string[] {
  if (!hidden) return [...list]
  return list.map(x => sanitizeGaps(x, true)).filter(Boolean)
}
