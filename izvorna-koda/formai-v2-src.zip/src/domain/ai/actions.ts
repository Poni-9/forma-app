import { lowFiberDays } from '../nutrition/race'
import type { Activity, CoachMsg, MealEntry, PlanDay, PlanKind, Profile } from '@/domain/types'
import { askJson, askText, AiError } from './client'
import { aiContext, coachDailyPrompt, weeklyReviewPrompt, adaptPlanPrompt, mealPhotoPrompt, mealTextPrompt, activityShotPrompt } from './prompts'
import { fileToBase64Resized, exifStamp } from './image'
import { slotAt } from '../nutrition/slots'
import { deriveFlags, STRAVA_ORIGIN } from '@/domain/import/provenance'
import { estimateTss, todayIso, weekStartIso, sportOfType, addDays } from '@/domain/training/load'
import { NUTRITION_RULES, dailyTarget, MIN_ABS_M, MIN_ABS_Z } from '@/domain/nutrition/energy'
import type { WeekMenu } from '@/domain/types'
import { getKV, setKV } from '@/data/db'
import { sanitizeGaps, sanitizeList, hasHiddenActivities } from './sanitize'
import { aiSafeView, aiSafePlan } from './safe'

/**
 * Visokonivojska AI dejanja za zaslone. Vsako preveri privolitev (profile.aiConsentAt) —
 * brez nje ne pošlje ničesar. Rezultati, ki se ne spreminjajo čez dan, se predpomnijo lokalno,
 * da ena dnevna kvota (10 klicev) ne izgori na osveževanju zaslona.
 * Vsak poziv gradimo iz AI-safe pogleda (safe.ts) in vsako besedilo AI, ki ga pokažemo, gre skozi sanitizeGaps.
 */
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)

export function hasConsent(p: Profile): boolean { return !!p.aiConsentAt }
function requireConsent(p: Profile) { if (!hasConsent(p)) throw new AiError('consent', 'Za AI nasvete potrebujem tvojo privolitev.') }

export interface Snapshot {
  profile: Profile; activities: Activity[]; plan: PlanDay[]; today: string
  /** osebni kontekst (cilji, prehrana, teža, počutje, vreme) */
  extra?: string
  /** uporabnik ima aktivnosti, ki jih AI ne sme videti (activities je že filtriran) — za varovalko sanitizeGaps */
  hidden?: boolean
}

/** AI-safe pogled posnetka — tudi če ga klicatelj ni sestavil s snapOf (vse aktivnosti, surovi načrt). */
function viewOf(s: Snapshot) {
  const v = aiSafeView({ profile: s.profile, activities: s.activities, plan: s.plan, today: s.today })
  return { ...v, hidden: v.hidden || !!s.hidden }
}
const hiddenOf = (s: Snapshot) => !!s.hidden || hasHiddenActivities(s.activities)
const ctxOf = (s: Snapshot) => { const v = viewOf(s); return aiContext(v.activities, v.profile, v.plan, v.hidden) + (s.extra ? '\n\n' + s.extra : '') }
/** Varovalka sanitizeGaps: AI ne vidi vseh voženj → ne sme trditi, da uporabnik ni treniral. */
const clean = (s: Snapshot, t: string) => sanitizeGaps(String(t ?? '').trim(), hiddenOf(s))
/** Kratko polje (naslov, opis, jed): očiščeno, sicer nadomestek. */
const cleanField = (hidden: boolean, t: unknown, max: number, fallback = ''): string => {
  const x = sanitizeGaps(String(t ?? '').trim(), hidden).slice(0, max).trim()
  return x || fallback
}

/* ---------- dnevni nasvet (predpomnjen na dan) ---------- */
export async function dailyAdvice(s: Snapshot, force = false): Promise<string> {
  requireConsent(s.profile)
  const key = `ai.daily.${s.today}`
  if (!force) { const c = await getKV<string>(key); if (c) return c }
  const v = viewOf(s)
  const txt = clean(s, await askText(coachDailyPrompt(ctxOf(s), v.plan.filter(d => d.date === s.today), undefined, v.activities), { temp: 0.5 }))
  await setKV(key, txt)
  return txt
}
export async function cachedDailyAdvice(today: string): Promise<string | null> { return (await getKV<string>(`ai.daily.${today}`)) || null }

/* ---------- pogovor ---------- */
export type ChatMsg = CoachMsg
export interface ChatMemory {
  msgs: ChatMsg[]; summary: string | null
  /** sporočila do tega časa so v povzetku (ne vrnejo se z druge naprave) */
  foldedTo?: string | null
  /** kdaj je bil povzetek posodobljen */
  summaryAt?: string | null
  /** »Nov pogovor« — sporočila do tega časa so izbrisana povsod */
  clearedAt?: string | null
}
/** koliko sporočil hranimo na zaslonu · koliko zadnjih vidi trener dobesedno · koliko jih naenkrat strnemo v povzetek */
export const CHAT_KEEP = 40, CHAT_CTX = 12, CHAT_FOLD = 20
/** trda meja, če povzetek ne uspe (brez omrežja, kvota): nič se ne izgubi, a pogovor ne raste v nedogled */
export const CHAT_HARD_MAX = 80
const CHAT_KEY = 'ai.chat'
/** Stari lokalni pogovor (pred sinhronizacijo) — enkratna selitev v nastavitve. */
export async function loadLegacyChat(): Promise<ChatMsg[]> { return (await getKV<ChatMsg[]>(CHAT_KEY)) || [] }
export async function clearLegacyChat(): Promise<void> { await setKV(CHAT_KEY, []) }

/** Odgovor trenerja + posodobljen spomin: zadnjih 40 sporočil dobesedno, starejše strnjene v povzetek, ki ga trener vedno vidi. */
export async function chat(s: Snapshot, question: string, mem: ChatMemory): Promise<ChatMemory> {
  requireConsent(s.profile)
  const hist = mem.msgs
  const recent = hist.slice(-CHAT_CTX).map(m => `${m.role === 'user' ? 'Uporabnik' : 'Trener'}: ${m.text}`).join('\n')
  const q = [mem.summary ? `KAR SI ZAPOMNI IZ PREJŠNJIH POGOVOROV (nadaljuj, ne začenjaj znova):\n${mem.summary}` : '', recent ? `ZADNJI POGOVOR:\n${recent}` : '', `NOVO VPRAŠANJE:\n${question}`].filter(Boolean).join('\n\n')
  const v = viewOf(s)
  const ans = clean(s, await askText(coachDailyPrompt(ctxOf(s), v.plan.filter(d => d.date === s.today), q, v.activities), { temp: 0.6 }))
  const now = new Date().toISOString()
  return addToChat(mem, [{ role: 'user', text: question, at: now }, { role: 'ai', text: ans, at: now }], v.hidden)
}

/**
 * Doda sporočila v pogovor (tudi nasvet za danes, pregled tedna, prilagoditev) — vse je v eni časovnici, trener vidi vse.
 * Najstarejši del gre v povzetek šele, ko povzetek USPE; ob napaki ostanejo vsa sporočila (do CHAT_HARD_MAX).
 */
export async function addToChat(mem: ChatMemory, add: ChatMsg[], hidden = true): Promise<ChatMemory> {
  const all = [...mem.msgs, ...add]
  const t = trimChat(all)
  if (!t.fold) return { ...mem, msgs: all }
  // meja ne sme razdeliti sporočil z istim časom (vprašanje in odgovor imata isti čas)
  let fold = t.fold, keep = t.keep
  while (keep.length && keep[0]!.at <= fold[fold.length - 1]!.at) { fold = [...fold, keep[0]!]; keep = keep.slice(1) }
  try {
    const summary = await foldSummary(mem.summary, fold, hidden)
    return { ...mem, msgs: keep, summary, foldedTo: fold[fold.length - 1]!.at, summaryAt: new Date().toISOString() }
  } catch {
    return { ...mem, msgs: all.slice(-CHAT_HARD_MAX) }
  }
}

/** Ko pogovor preseže 40 sporočil, gre najstarejših 20 v povzetek. */
export function trimChat(msgs: ChatMsg[]): { keep: ChatMsg[]; fold: ChatMsg[] | null } {
  if (msgs.length <= CHAT_KEEP) return { keep: msgs, fold: null }
  return { keep: msgs.slice(CHAT_FOLD), fold: msgs.slice(0, CHAT_FOLD) }
}

async function foldSummary(prev: string | null, old: ChatMsg[], hidden: boolean): Promise<string> {
  const text = old.map(m => `${m.role === 'user' ? 'Uporabnik' : 'Trener'}: ${m.text}`).join('\n')
  const prompt = `Si kolesarski trener in vodiš zapiske o svojem varovancu. ${prev ? `DOSEDANJI ZAPISKI:\n${prev}\n\n` : ''}NOV DEL POGOVORA:\n${text}\n\nPosodobi zapiske: največ 10 kratkih vrstic v slovenščini, samo kar je pomembno za nadaljevanje (dogovori, cilji, težave, kaj mu ustreza in kaj ne, odprte teme). Brez uvoda, brez naslovov.`
  const out = sanitizeGaps((await askText([{ text: prompt }], { temp: 0.2 })).trim(), hidden).slice(0, 1500)
  if (!out) throw new AiError('parse', 'Povzetek je prazen.')
  return out
}

/* ---------- tedenski pregled (predpomnjen na teden) ---------- */
export async function weeklyReview(s: Snapshot, force = false): Promise<string> {
  requireConsent(s.profile)
  const key = `ai.week.${weekStartIso(s.today)}`
  if (!force) { const c = await getKV<string>(key); if (c) return c }
  const txt = clean(s, await askText(weeklyReviewPrompt(ctxOf(s)), { temp: 0.4 }))
  await setKV(key, txt)
  return txt
}

/* ---------- prilagoditev tedna ---------- */
interface AdaptOut { dnevi: { date: string; kind: string; title: string; desc: string; durationMin: number; zone: string | null; tssTarget: number | null; why?: string }[]; povzetek?: string }
const KINDS = new Set<string>(['kolo', 'tek', 'pohod', 'moc', 'pocitek', 'test'])

export async function adaptWeek(s: Snapshot, week: PlanDay[], note?: string): Promise<{ days: PlanDay[]; summary: string }> {
  requireConsent(s.profile)
  if (!week.length) throw new AiError('parse', 'Ta teden še ni sestavljen.')
  const v = viewOf(s), hid = v.hidden
  // moč (jedro/noge) ostane, kot je — AI prilagaja samo kolo in počitek; en zapis na dan
  const fixed = week.filter(d => d.kind === 'moc')
  const rides = week.filter(d => d.kind !== 'moc')
  // v poziv gre teden brez kljukic, ki jih je postavila aktivnost, ki je AI ne sme videti (Strava)
  const promptWeek = aiSafePlan(rides, s.activities)
  const out = await askJson<AdaptOut>(adaptPlanPrompt(ctxOf(s) + (note ? '\n\nPOSEBNO NAVODILO: ' + note : '') + '\n\nMoč (jedro, noge) ostane nespremenjena — v JSON vrni samo spodnje dni.', promptWeek, v.activities), { temp: 0.3 })
  if (!out || !Array.isArray(out.dnevi)) throw new AiError('parse', 'AI ni vrnil načrta v pričakovani obliki.')
  const now = new Date().toISOString()
  const byDate = new Map(rides.map(d => [d.date, d]))
  const days: PlanDay[] = []
  const seen = new Set<string>()
  for (const d of out.dnevi) {
    const old = byDate.get(d.date)
    if (!old || seen.has(d.date)) continue    // AI ne sme dodajati datumov ne podvajati dni
    seen.add(d.date)
    if (old.done) { days.push(old); continue } // opravljeno ostane nedotaknjeno
    const kind = (KINDS.has(d.kind) && d.kind !== 'moc' ? d.kind : old.kind) as PlanKind
    const dur = Number.isFinite(+d.durationMin) ? Math.max(0, Math.min(360, Math.round(+d.durationMin))) : old.durationMin
    const title = cleanField(hid, d.title, 80, old.title)
    const same = kind === old.kind && title === old.title
    const zone = d.zone ? cleanField(hid, d.zone, 24) || null : null
    days.push({
      ...old, kind, title, desc: cleanField(hid, d.desc, 400, old.desc),
      durationMin: kind === 'pocitek' ? 0 : dur, zone,
      tssTarget: d.tssTarget != null && Number.isFinite(+d.tssTarget) ? Math.round(+d.tssTarget) : old.tssTarget,
      why: d.why ? (cleanField(hid, d.why, 200) || old.why) : old.why, source: 'ai', updatedAt: now,
      exercises: undefined, optional: kind === old.kind ? old.optional : false,
      role: kind === 'pocitek' ? null : same ? old.role : kind === 'test' ? 'test' : old.role, target: same ? old.target : null,
    })
  }
  // datumi, ki jih je AI izpustil, ostanejo taki, kot so
  for (const d of rides) if (!days.some(x => x.date === d.date)) days.push(d)
  days.push(...fixed)
  days.sort((a, b) => a.date.localeCompare(b.date))
  return { days, summary: cleanField(hid, out.povzetek, 300, 'Teden prilagojen.') }
}

/* ---------- fotografija obroka ---------- */
interface MealOut { jed: string; grami_tehtnica: number | null; grami_ocena: number | null; kcal: number; beljakovine_g: number; ogljikovi_hidrati_g: number | null; mascobe_g: number | null; obrok: string; zanesljivost: string; opomba: string }
const SLOTS = new Set<string>(['zajtrk', 'malica', 'kosilo', 'med_vadbo', 'vecerja', 'drugo'])

/** Obrok s slike. Obrok (zajtrk, kosilo …) po uri posnetka (EXIF), ne po ugibanju AI; `photo` = kdaj je bila slika posneta. */
export async function mealFromPhoto(p: Profile, file: File, remainingKcal: number | null, remainingProt: number | null): Promise<MealEntry & { photo: { date: string; time: string } | null }> {
  requireConsent(p)
  const img = await fileToBase64Resized(file, 1280, 0.85)
  const stamp = await exifStamp(file)
  const out = await askJson<MealOut>(mealPhotoPrompt(img.data, img.mime, remainingKcal, remainingProt), { temp: 0.2 })
  const kcal = Math.max(0, Math.round(+out.kcal || 0))
  let slot = (SLOTS.has(out.obrok) ? out.obrok : 'drugo') as MealEntry['slot']
  if (stamp) slot = slotAt(stamp.time)
  const conf: MealEntry['confidence'] = out.zanesljivost === 'visoka' || out.zanesljivost === 'srednja' || out.zanesljivost === 'nizka' ? out.zanesljivost : 'srednja'
  const n = (v: unknown) => (v != null && Number.isFinite(+v) ? Math.round(+v) : null)
  return {
    id: uid(), date: todayIso(), time: stamp ? stamp.time : new Date().toTimeString().slice(0, 5), slot, photo: stamp,
    name: cleanField(true, out.jed, 80, 'Obrok'), grams: n(out.grami_tehtnica) ?? n(out.grami_ocena), kcal,
    proteinG: n(out.beljakovine_g), carbsG: n(out.ogljikovi_hidrati_g), fatG: n(out.mascobe_g),
    confidence: conf, source: 'photo', thumb: img.thumb, createdAt: new Date().toISOString(),
  }
}

/* ---------- obrok iz opisa (besedilo ali glas) ---------- */
interface MealTextItem { ime?: string; kolicina?: string | null; grami?: number | null; kcal?: number; beljakovine_g?: number | null; ogljikovi_hidrati_g?: number | null; mascobe_g?: number | null }
interface MealTextOut { jed?: string; postavke?: MealTextItem[]; kcal?: number; beljakovine_g?: number | null; ogljikovi_hidrati_g?: number | null; mascobe_g?: number | null; obrok?: string | null; ura?: string | null; zanesljivost?: string; vprasanje?: string | null }
export type MealFromText = MealEntry & { question: string | null; aiSlot: boolean }

/**
 * Obrok iz opisa: postavke z ocenjenimi kcal in makrohranili; vsote se preračunajo iz postavk (model se lahko zmoti pri seštevanju).
 * Obrok/ura iz opisa (»za zajtrk«), sicer po zdajšnji uri. Vse besedilo gre skozi sanitizeGaps (cleanField).
 */
export async function mealFromText(p: Profile, description: string, remainingKcal: number | null, remainingProt: number | null, now: Date = new Date()): Promise<MealFromText> {
  requireConsent(p)
  const desc = String(description || '').trim()
  if (desc.length < 2) throw new AiError('parse', 'Napiši, kaj si pojedel.')
  const hhmm = now.toTimeString().slice(0, 5)
  const out = await askJson<MealTextOut>(mealTextPrompt(desc, hhmm, remainingKcal, remainingProt, NUTRITION_RULES), { temp: 0.2 })
  const num = (v: unknown) => (v != null && Number.isFinite(+v) && +v >= 0 ? +v : null)
  const items = (Array.isArray(out.postavke) ? out.postavke : []).slice(0, 12).map(it => ({
    name: cleanField(true, it.ime, 60, 'sestavina'), qty: it.kolicina ? cleanField(true, it.kolicina, 40) || null : null,
    kcal: Math.round(num(it.kcal) ?? 0), g: num(it.grami), p: num(it.beljakovine_g), c: num(it.ogljikovi_hidrati_g), f: num(it.mascobe_g),
  })).filter(it => it.kcal > 0 || it.p || it.c || it.f)
  const sum = (k: 'kcal' | 'p' | 'c' | 'f' | 'g') => items.reduce((s, it) => s + (it[k] ?? 0), 0)
  const has = (k: 'p' | 'c' | 'f' | 'g') => items.some(it => it[k] != null)
  const kcal = Math.round(items.length ? sum('kcal') : num(out.kcal) ?? 0)
  const r = (v: number | null) => (v == null ? null : Math.round(v))
  const time = /^([01]\d|2[0-3]):[0-5]\d$/.test(String(out.ura || '')) && String(out.ura) <= hhmm ? String(out.ura) : hhmm
  const aiSlot = !!out.obrok && SLOTS.has(out.obrok) && out.obrok !== 'med_vadbo'
  const slot = (aiSlot ? out.obrok : slotAt(time)) as MealEntry['slot']
  const conf: MealEntry['confidence'] = out.zanesljivost === 'visoka' || out.zanesljivost === 'srednja' || out.zanesljivost === 'nizka' ? out.zanesljivost : 'srednja'
  const question = out.vprasanje ? cleanField(true, out.vprasanje, 160) || null : null
  return {
    id: uid(), date: todayIso(), time, slot, name: cleanField(true, out.jed, 80, desc.slice(0, 60)),
    grams: has('g') ? Math.round(sum('g')) : null, kcal,
    proteinG: items.length ? (has('p') ? r(sum('p')) : null) : r(num(out.beljakovine_g)),
    carbsG: items.length ? (has('c') ? r(sum('c')) : null) : r(num(out.ogljikovi_hidrati_g)),
    fatG: items.length ? (has('f') ? r(sum('f')) : null) : r(num(out.mascobe_g)),
    confidence: conf, source: 'text', thumb: null, createdAt: new Date().toISOString(),
    items: items.map(it => ({ name: it.name, qty: it.qty, kcal: it.kcal })), question, aiSlot,
  }
}

/* ---------- posnetek zaslona aktivnosti ---------- */
interface ShotOut { app?: string | null; sport: string; datum: string | null; trajanje_min: number | null; razdalja_km: number | null; vzpon_m: number | null; povprecni_utrip: number | null; povprecna_moc: number | null; kcal: number | null; ime: string | null; zanesljivost: string }

/** Posnetek iz Strave (polje app ali ime z oznako Strava) — vadba ne gre v AI. */
export function shotIsStrava(out: Pick<ShotOut, 'app' | 'ime'>): boolean {
  return /strava/i.test(String(out.app || '')) || /\bstrava\b/i.test(String(out.ime || ''))
}

/**
 * Aktivnost s posnetka zaslona. Datum: iz posnetka, a nikoli v prihodnosti (takrat danes + opomba);
 * posnetek Strave dobi izvor STRAVA → trener ga ne vidi (aiEligible false).
 */
export async function activityFromShot(p: Profile, file: File, today: string = todayIso()): Promise<Activity> {
  requireConsent(p)
  const img = await fileToBase64Resized(file, 1280, 0.85)
  const out = await askJson<ShotOut>(activityShotPrompt(img.data, img.mime, today), { temp: 0.1 })
  const sport = sportOfType(out.sport) || 'kolo'
  const iso = out.datum && /^\d{4}-\d{2}-\d{2}$/.test(out.datum) && !Number.isNaN(Date.parse(out.datum)) ? out.datum : null
  const future = !!iso && iso > today
  const date = iso && !future ? iso : today
  const num = (v: unknown): number | null => (v != null && Number.isFinite(+v) ? +v : null)
  const now = new Date().toISOString()
  const names: Record<string, string> = { kolo: 'Vožnja', tek: 'Tek', pohod: 'Hoja', moc: 'Moč', plavanje: 'Plavanje', drugo: 'Aktivnost' }
  const dist = num(out.razdalja_km), dur = num(out.trajanje_min)
  const strava = shotIsStrava(out)
  const notes = [
    out.zanesljivost === 'nizka' ? 'Prebrano s posnetka — nizka zanesljivost, preveri številke.' : '',
    future ? `Datum s posnetka (${iso}) je v prihodnosti — nastavljen je današnji, popravi ga po potrebi.` : '',
    strava ? 'Posnetek iz Strave — trener te vadbe ne vidi (Stravina pravila).' : '',
  ].filter(Boolean).join(' ')
  const a: Activity = {
    id: uid(), source: 'screenshot', originHint: strava ? STRAVA_ORIGIN : null, sport, date, start: null, name: cleanField(true, out.ime, 80, names[sport] || 'Aktivnost'),
    distKm: dist != null ? +dist.toFixed(1) : null, durationMin: dur != null ? Math.round(dur) : null,
    elevM: num(out.vzpon_m) != null ? Math.round(num(out.vzpon_m) as number) : null,
    avgHr: num(out.povprecni_utrip) != null ? Math.round(num(out.povprecni_utrip) as number) : null,
    avgPower: num(out.povprecna_moc) != null ? Math.round(num(out.povprecna_moc) as number) : null,
    kcal: num(out.kcal) != null ? Math.round(num(out.kcal) as number) : null,
    speedKmh: dist && dur ? +(dist / (dur / 60)).toFixed(1) : null, tss: null, polyline: null,
    ...(notes ? { notes } : {}),
    ...deriveFlags('screenshot', strava ? STRAVA_ORIGIN : null), createdAt: now, updatedAt: now,
  }
  a.tss = estimateTss(a, p)
  return a
}

/* ---------- hladilnik → kaj naj skuham ---------- */
export interface Suggestion { name: string; desc: string; kcal: number; proteinG: number; carbsG: number; fatG: number; minutes?: number | null; missing?: string | null }
/** hidden: ali ima uporabnik aktivnosti, ki jih AI ne vidi (neznano = true — varovalka vedno teče) */
export async function fridgeMeals(p: Profile, file: File, remainingKcal: number | null, remainingProt: number | null, training: string | null, hidden = true): Promise<{ seen: string[]; ideas: Suggestion[] }> {
  requireConsent(p)
  const img = await fileToBase64Resized(file, 1280, 0.8)
  const text = [
    'Si prehranski pomočnik v slovenski aplikaciji. Odgovarjaš izključno v slovenščini.', '', NUTRITION_RULES, '',
    'Na sliki je vsebina hladilnika ali shrambe. Prepoznaj živila.',
    `Danes do cilja ostane ${remainingKcal != null ? Math.max(300, Math.round(remainingKcal)) : 'neznano'} kcal in ${remainingProt != null ? Math.max(20, Math.round(remainingProt)) : 'neznano'} g beljakovin. Današnji trening: ${training || 'brez'}.`,
    'Cilj uporabnika: hujšanje z ohranjanjem mišic — visoke beljakovine, sit obrok, preprosta priprava.',
    'Sestavi 3 obroke IZ TEGA, KAR JE NA SLIKI (največ ena manjkajoča sestavina).',
    'Vrni SAMO JSON: {"vidim":["živilo", …],"predlogi":[{"jed":"","opis":"sestavine s količinami v gramih, ena vrstica","kcal":0,"b":0,"oh":0,"m":0,"minut":0,"manjka":""}]}',
  ].join('\n')
  const out = await askJson<{ vidim?: string[]; predlogi?: { jed: string; opis: string; kcal: number; b: number; oh: number; m: number; minut?: number; manjka?: string }[] }>([{ text }, { inlineData: { mimeType: img.mime, data: img.data.includes('base64,') ? img.data.split('base64,')[1]! : img.data } }], { temp: 0.5 })
  const n = (v: unknown) => (Number.isFinite(+(v as number)) ? Math.round(+(v as number)) : 0)
  return {
    seen: sanitizeList((Array.isArray(out.vidim) ? out.vidim : []).slice(0, 14).map(x => String(x ?? '').slice(0, 60)), hidden).filter(Boolean),
    ideas: (Array.isArray(out.predlogi) ? out.predlogi : []).slice(0, 3).map(x => ({ name: cleanField(hidden, x.jed, 60, 'Obrok'), desc: cleanField(hidden, x.opis, 220), kcal: n(x.kcal), proteinG: n(x.b), carbsG: n(x.oh), fatG: n(x.m), minutes: x.minut ? n(x.minut) : null, missing: x.manjka ? cleanField(hidden, x.manjka, 60) || null : null })),
  }
}

/* ---------- predlog obroka za preostanek dneva ---------- */
export async function mealIdeas(s: Snapshot, remainingKcal: number, remainingProt: number): Promise<Suggestion[]> {
  requireConsent(s.profile)
  const hid = hiddenOf(s)
  const text = [
    'Si prehranski pomočnik v slovenski aplikaciji. Odgovarjaš izključno v slovenščini.', '', NUTRITION_RULES, '', 'KONTEKST:', ctxOf(s), '',
    `Danes do cilja ostane ${Math.round(remainingKcal)} kcal in ${Math.max(0, Math.round(remainingProt))} g beljakovin. Ura: ${new Date().toTimeString().slice(0, 5)}.`,
    'Predlagaj 3 obroke za preostanek dneva: visoke beljakovine, sit, preprosto, sestavine iz slovenske trgovine, študentski proračun. Vsak predlog naj bo v okviru preostanka.',
    'Vrni SAMO JSON: {"predlogi":[{"jed":"","opis":"sestavine s količinami, ena vrstica","kcal":0,"b":0,"oh":0,"m":0,"minut":0}]}',
  ].join('\n')
  const out = await askJson<{ predlogi?: { jed: string; opis: string; kcal: number; b: number; oh: number; m: number; minut?: number }[] }>([{ text }], { temp: 0.6 })
  const n = (v: unknown) => (Number.isFinite(+(v as number)) ? Math.round(+(v as number)) : 0)
  return (Array.isArray(out.predlogi) ? out.predlogi : []).slice(0, 3).map(x => ({ name: cleanField(hid, x.jed, 60, 'Obrok'), desc: cleanField(hid, x.opis, 220), kcal: n(x.kcal), proteinG: n(x.b), carbsG: n(x.oh), fatG: n(x.m), minutes: x.minut ? n(x.minut) : null }))
}

/* ---------- jedilnik za teden + nakupovalni seznam ---------- */
const dShort = (iso: string) => `${+iso.slice(8)}. ${+iso.slice(5, 7)}.`
/** Kaj dodati, ko je dan pod varno mejo (za prikaz pri malici). */
function topUpIdea(kcal: number): string {
  if (kcal <= 250) return 'jogurt in banana'
  if (kcal <= 450) return 'kruh s sirom in sadje'
  return 'dodatna malica: kruh s sirom, jogurt, oreški in sadje'
}

/**
 * Jedilnik za 7 dni. Cilj vsakega dne izračuna aplikacija (dailyTarget z načrtom TEGA dne — trening dvigne cilj);
 * dailyKcal (od zaslona) je samo nadomestek, če profil ni popoln. Po odgovoru AI se vsak dan preveri proti varni
 * meji (BMR, 1500/1200): dan pod mejo dobi dodatek pri malici do meje (low, addKcal), jedilnik pa pojasnilo (note).
 */
export async function weekMenu(s: Snapshot, dailyKcal: number, proteinG: number, favourites: string[]): Promise<WeekMenu> {
  requireConsent(s.profile)
  const v = viewOf(s), hid = v.hidden
  const p = s.profile
  const ws = weekStartIso(s.today)
  const dates = Array.from({ length: 7 }, (_, i) => addDays(ws, i))
  const absFloor = p.sex === 'z' ? MIN_ABS_Z : MIN_ABS_M
  const perDay = dates.map(date => {
    const plan = v.plan.filter(d => d.date === date)
    const t = dailyTarget(p, v.activities.filter(a => a.date === date), plan, date, { today: s.today })
    const training = plan.filter(d => d.kind !== 'pocitek' && !d.optional).map(d => `${d.kind} ${d.durationMin} min`).join(' + ')
    return { date, target: t ? t.kcal : Math.max(absFloor, Math.round(dailyKcal)), floor: t ? t.floor : absFloor, protein: t ? t.proteinG : proteinG, training }
  })
  const text = [
    'Si prehranski pomočnik v slovenski aplikaciji. Odgovarjaš izključno v slovenščini.', '', NUTRITION_RULES, '', 'KONTEKST:', ctxOf(s), '',
    'DNEVNI CILJI (izračunala aplikacija — na dan s treningom je cilj višji; noben dan ne sme biti pod spodnjo mejo):',
    ...perDay.map(x => `- ${x.date}: ${x.target} kcal (spodnja meja ${x.floor} kcal), beljakovine ${x.protein} g${x.training ? `; trening: ${x.training}` : '; brez treninga'}`),
    ...(() => { const lf = lowFiberDays(p, ws, dates[6]!); return lf.length ? [`Tekme: ${[...new Set(lf.map(x => x.race))].join(', ')}. Ti dnevi naj imajo malo vlaknin (2 dni pred tekmo, na dan tekme zajtrk in kosilo pred startom): ${lf.map(x => x.date).join(', ')} — bel kruh, riž, testenine, krompir brez lupine, banana; brez polnozrnatega, stročnic, solate, surove zelenjave, oreškov. OH visoki.`] : [] })(),
    `Rad je: ${favourites.length ? favourites.join(', ') : 'ni podatka'}.`,
    'Sestavi jedilnik za 7 dni: zajtrk, kosilo, malica, večerja — preprosto, ponavljajoče se sestavine (manj odpadkov), slovenska trgovina, študentski proračun. Vsota dneva ("kcal") naj bo čim bliže cilju tega dne.',
    `Datumi: ${dates.join(', ')}.`,
    'Vrni SAMO JSON: {"dnevi":[{"datum":"YYYY-MM-DD","zajtrk":"jed s količinami","kosilo":"","malica":"","vecerja":"","kcal":0,"b":0}],"nakup":["10–20 stvari s količinami za cel teden"]}',
  ].join('\n')
  const out = await askJson<{ dnevi?: { datum: string; zajtrk: string; kosilo: string; malica: string; vecerja: string; kcal: number; b: number }[]; nakup?: string[] }>([{ text }], { temp: 0.6 })
  const used = new Set<string>()
  const days: WeekMenu['days'] = []
  for (const d of Array.isArray(out.dnevi) ? out.dnevi : []) {
    if (!d || !dates.includes(d.datum) || used.has(d.datum)) continue
    used.add(d.datum)
    const pd = perDay.find(x => x.date === d.datum)!
    let kcal = Math.max(0, Math.round(+d.kcal || 0))
    let malica = cleanField(hid, d.malica, 300)
    let low = false, addKcal: number | null = null
    if (kcal > 0 && kcal < pd.floor) {
      // pod varno mejo: dodatek do meje (zaokroženo navzgor na 50 kcal), vpisan pri malici
      addKcal = Math.ceil((pd.floor - kcal) / 50) * 50
      kcal += addKcal
      low = true
      malica = `${malica ? malica + ' + ' : ''}dodatek do varne meje ~${addKcal} kcal (npr. ${topUpIdea(addKcal)})`
    } else if (kcal <= 0) low = true   // AI ni navedel kalorij — ne vemo, ali dan doseže varno mejo
    days.push({
      date: d.datum, zajtrk: cleanField(hid, d.zajtrk, 300), kosilo: cleanField(hid, d.kosilo, 300), malica, vecerja: cleanField(hid, d.vecerja, 300),
      kcal, proteinG: Math.max(0, Math.round(+d.b || 0)), targetKcal: pd.target, floorKcal: pd.floor, low, addKcal,
    })
  }
  days.sort((a, b) => a.date.localeCompare(b.date))
  const topped = days.filter(x => x.low && x.addKcal), unknown = days.filter(x => x.low && !x.addKcal)
  const note = [
    topped.length ? `AI je za ${topped.map(x => dShort(x.date)).join(', ')} predlagal manj od tvoje varne meje — pri malici je dodan dodatek do meje.` : '',
    unknown.length ? `Za ${unknown.map(x => dShort(x.date)).join(', ')} AI ni navedel kalorij — pojej vsaj svojo varno mejo.` : '',
  ].filter(Boolean).join(' ') || null
  return {
    weekStart: ws, days,
    shopping: sanitizeList((Array.isArray(out.nakup) ? out.nakup : []).slice(0, 30).map(x => String(x ?? '').slice(0, 120)), hid).filter(Boolean),
    bought: {}, at: new Date().toISOString(),
    lowDays: days.filter(x => x.low).map(x => x.date), note,
  }
}

/* ---------- mesečna ocena ---------- */
export async function monthReview(s: Snapshot, summary: string): Promise<string> {
  requireConsent(s.profile)
  const text = [PERSONA_SHORT, '', NUTRITION_RULES, '', 'KONTEKST:', ctxOf(s), '', 'POVZETEK MESECA:', summary, '',
    'NALOGA: ocena meseca v največ 130 besedah, trije odstavki brez naslovov: kaj se je premaknilo (FTP in W/kg, ure, teža) glede na mejnike do dirke, kaj je zaviralo, ena konkretna sprememba za naslednji mesec. Tikaj, brez emojijev, brez markdown.'].join('\n')
  return clean(s, await askText([{ text }], { temp: 0.5 }))
}

/* ---------- kakšen športnik si ---------- */
export interface AthleteProfile { type: string; summary: string; scores: Record<string, number>; strengths: string[]; weaknesses: string[]; focus: string }
export async function athleteProfile(s: Snapshot): Promise<AthleteProfile> {
  requireConsent(s.profile)
  const text = [PERSONA_SHORT, '', 'KONTEKST:', ctxOf(s), '',
    'NALOGA: oceni, kakšen kolesar je — SAMO iz podatkov v kontekstu, brez izmišljanja. Ocene 0–100 so relativne glede na rekreativnega kolesarja. Fokus naj pove, kaj naj do dirke dela drugače, da doseže ciljni W/kg.',
    'Vrni SAMO JSON: {"tip":"kratek naziv","opis":"2 stavka","ocene":{"vzdrzljivost":0,"prag":0,"vo2":0,"moc":0},"moci":["…"],"sibkosti":["…"],"fokus":"1 stavek, kaj naj naslednjih 8 tednov dela drugače"}'].join('\n')
  const out = await askJson<{ tip?: string; opis?: string; ocene?: Record<string, number>; moci?: string[]; sibkosti?: string[]; fokus?: string }>([{ text }], { temp: 0.4 })
  const sc: Record<string, number> = {}
  for (const k of ['vzdrzljivost', 'prag', 'vo2', 'moc']) sc[k] = Math.max(0, Math.min(100, Math.round(+(out.ocene?.[k] ?? 0)) || 0))
  const hid = hiddenOf(s)
  return { type: cleanField(hid, out.tip, 60), summary: cleanField(hid, out.opis, 300), scores: sc, strengths: sanitizeList((Array.isArray(out.moci) ? out.moci : []).slice(0, 4).map(String), hid), weaknesses: sanitizeList((Array.isArray(out.sibkosti) ? out.sibkosti : []).slice(0, 4).map(String), hid), focus: cleanField(hid, out.fokus, 200) }
}
const PERSONA_SHORT = 'Si FORMAI — osebni kolesarski trener; cilj športnika je dirka iz konteksta in ciljni W/kg. Odgovarjaš izključno v slovenščini, direktno, s konkretnimi številkami, v drugi osebi, brez markdown. Ne izmišljuj si podatkov. Nisi zdravnik.'

/** Prijazno sporočilo za uporabnika iz AI napake. */
export function aiErrorText(e: unknown): string {
  if (e instanceof AiError) return e.message
  return (e as Error)?.message || 'AI trenutno ni na voljo.'
}
export function isConsentError(e: unknown): boolean { return e instanceof AiError && e.kind === 'consent' }
export function isAuthError(e: unknown): boolean { return e instanceof AiError && e.kind === 'auth' }

export { AiError }
