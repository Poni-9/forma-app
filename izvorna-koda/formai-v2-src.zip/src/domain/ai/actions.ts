import type { Activity, CoachMsg, MealEntry, PlanDay, PlanKind, Profile } from '@/domain/types'
import { askJson, askText, AiError } from './client'
import { aiContext, coachDailyPrompt, weeklyReviewPrompt, adaptPlanPrompt, mealPhotoPrompt, activityShotPrompt } from './prompts'
import { fileToBase64Resized, exifHour } from './image'
import { deriveFlags } from '@/domain/import/provenance'
import { estimateTss, todayIso, weekStartIso, sportOfType } from '@/domain/training/load'
import { NUTRITION_RULES } from '@/domain/nutrition/energy'
import type { WeekMenu } from '@/domain/types'
import { getKV, setKV } from '@/data/db'
import { sanitizeGaps, sanitizeList, hasHiddenActivities } from './sanitize'

/**
 * Visokonivojska AI dejanja za zaslone. Vsako preveri privolitev (profile.aiConsentAt) —
 * brez nje ne pošlje ničesar. Rezultati, ki se ne spreminjajo čez dan, se predpomnijo lokalno,
 * da ena dnevna kvota (10 klicev) ne izgori na osveževanju zaslona.
 */
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)

export function hasConsent(p: Profile): boolean { return !!p.aiConsentAt }
function requireConsent(p: Profile) { if (!hasConsent(p)) throw new AiError('consent', 'Za AI nasvete potrebujem tvojo privolitev.') }

export interface Snapshot { profile: Profile; activities: Activity[]; plan: PlanDay[]; today: string; /** osebni kontekst (cilji, prehrana, teža, počutje, vreme) */ extra?: string }
const ctxOf = (s: Snapshot) => aiContext(s.activities, s.profile, s.plan) + (s.extra ? '\n\n' + s.extra : '')
/** Varovalka sanitizeGaps: AI ne vidi vseh voženj → ne sme trditi, da uporabnik ni treniral. */
const clean = (s: Snapshot, t: string) => sanitizeGaps(String(t).trim(), hasHiddenActivities(s.activities))

/* ---------- dnevni nasvet (predpomnjen na dan) ---------- */
export async function dailyAdvice(s: Snapshot, force = false): Promise<string> {
  requireConsent(s.profile)
  const key = `ai.daily.${s.today}`
  if (!force) { const c = await getKV<string>(key); if (c) return c }
  const ctx = ctxOf(s)
  const txt = clean(s, await askText(coachDailyPrompt(ctx, s.plan.filter(d => d.date === s.today)), { temp: 0.5 }))
  await setKV(key, txt)
  return txt
}
export async function cachedDailyAdvice(today: string): Promise<string | null> { return (await getKV<string>(`ai.daily.${today}`)) || null }

/* ---------- pogovor ---------- */
export type ChatMsg = CoachMsg
export interface ChatMemory { msgs: ChatMsg[]; summary: string | null }
/** koliko sporočil hranimo na zaslonu · koliko zadnjih vidi trener dobesedno · koliko jih naenkrat strnemo v povzetek */
export const CHAT_KEEP = 40, CHAT_CTX = 12, CHAT_FOLD = 20
const CHAT_KEY = 'ai.chat'
/** Stari lokalni pogovor (pred sinhronizacijo) — enkratna selitev v nastavitve. */
export async function loadLegacyChat(): Promise<ChatMsg[]> { return (await getKV<ChatMsg[]>(CHAT_KEY)) || [] }
export async function clearLegacyChat(): Promise<void> { await setKV(CHAT_KEY, []) }

/** Odgovor trenerja + posodobljen spomin: zadnjih 40 sporočil dobesedno, starejše strnjene v povzetek, ki ga trener vedno vidi. */
export async function chat(s: Snapshot, question: string, mem: ChatMemory): Promise<ChatMemory> {
  requireConsent(s.profile)
  const hist = mem.msgs
  const recent = hist.slice(-CHAT_CTX).map(m => `${m.role === 'user' ? 'Uporabnik' : 'Trener'}: ${m.text}`).join('\n')
  const q = [mem.summary ? `KAR SI ZAPOMNI IZ PREJŠNJIH POGOVOROV (nadaljuj, ne začenjaj znova):\n${mem.summary}` : '', recent ? `ZADNJI POGOVOR:\n${recent}` : '', `NOVO VPRAŠANJE:\n${question}`].filter(Boolean).join('\n\n')
  const ctx = ctxOf(s)
  const ans = clean(s, await askText(coachDailyPrompt(ctx, s.plan.filter(d => d.date === s.today), q), { temp: 0.6 }))
  const now = new Date().toISOString()
  const { keep, fold } = trimChat([...hist, { role: 'user' as const, text: question, at: now }, { role: 'ai' as const, text: ans, at: now }])
  // najstarejši del gre v povzetek (en klic), na zaslonu jih ostane ≥ 20
  const summary = fold ? await foldSummary(mem.summary, fold).catch(() => mem.summary) : mem.summary
  return { msgs: keep, summary }
}

/** Ko pogovor preseže 40 sporočil, gre najstarejših 20 v povzetek. */
export function trimChat(msgs: ChatMsg[]): { keep: ChatMsg[]; fold: ChatMsg[] | null } {
  if (msgs.length <= CHAT_KEEP) return { keep: msgs, fold: null }
  return { keep: msgs.slice(CHAT_FOLD), fold: msgs.slice(0, CHAT_FOLD) }
}

async function foldSummary(prev: string | null, old: ChatMsg[]): Promise<string> {
  const text = old.map(m => `${m.role === 'user' ? 'Uporabnik' : 'Trener'}: ${m.text}`).join('\n')
  const prompt = `Si kolesarski trener in vodiš zapiske o svojem varovancu. ${prev ? `DOSEDANJI ZAPISKI:\n${prev}\n\n` : ''}NOV DEL POGOVORA:\n${text}\n\nPosodobi zapiske: največ 10 kratkih vrstic v slovenščini, samo kar je pomembno za nadaljevanje (dogovori, cilji, težave, kaj mu ustreza in kaj ne, odprte teme). Brez uvoda, brez naslovov.`
  const out = await askText([{ text: prompt }], { temp: 0.2 })
  return out.trim().slice(0, 1500)
}

/* ---------- tedenski pregled (predpomnjen na teden) ---------- */
export async function weeklyReview(s: Snapshot, force = false): Promise<string> {
  requireConsent(s.profile)
  const key = `ai.week.${weekStartIso(s.today)}`
  if (!force) { const c = await getKV<string>(key); if (c) return c }
  const txt = clean(s, await askText(weeklyReviewPrompt(ctxOf(s)), { temp: 0.4 }))
  await setKV(key, txt)
  return txt
}

/* ---------- prilagoditev tedna ---------- */
interface AdaptOut { dnevi: { date: string; kind: string; title: string; desc: string; durationMin: number; zone: string | null; tssTarget: number | null; why?: string }[]; povzetek?: string }
const KINDS = new Set<string>(['kolo', 'tek', 'pohod', 'moc', 'pocitek', 'test'])

export async function adaptWeek(s: Snapshot, week: PlanDay[], note?: string): Promise<{ days: PlanDay[]; summary: string }> {
  requireConsent(s.profile)
  if (!week.length) throw new AiError('parse', 'Ta teden še ni sestavljen.')
  // moč (jedro/noge) ostane, kot je — AI prilagaja samo kolo in počitek; en zapis na dan
  const fixed = week.filter(d => d.kind === 'moc')
  const rides = week.filter(d => d.kind !== 'moc')
  const out = await askJson<AdaptOut>(adaptPlanPrompt(ctxOf(s) + (note ? '\n\nPOSEBNO NAVODILO: ' + note : '') + '\n\nMoč (jedro, noge) ostane nespremenjena — v JSON vrni samo spodnje dni.', rides), { temp: 0.3 })
  if (!out || !Array.isArray(out.dnevi)) throw new AiError('parse', 'AI ni vrnil načrta v pričakovani obliki.')
  const now = new Date().toISOString()
  const byDate = new Map(rides.map(d => [d.date, d]))
  const days: PlanDay[] = []
  const seen = new Set<string>()
  for (const d of out.dnevi) {
    const old = byDate.get(d.date)
    if (!old || seen.has(d.date)) continue    // AI ne sme dodajati datumov ne podvajati dni
    seen.add(d.date)
    if (old.done) { days.push(old); continue } // opravljeno ostane nedotaknjeno
    const kind = (KINDS.has(d.kind) && d.kind !== 'moc' ? d.kind : old.kind) as PlanKind
    const dur = Number.isFinite(+d.durationMin) ? Math.max(0, Math.min(360, Math.round(+d.durationMin))) : old.durationMin
    const same = kind === old.kind && String(d.title || old.title) === old.title
    days.push({
      ...old, kind, title: String(d.title || old.title).slice(0, 80), desc: String(d.desc || old.desc).slice(0, 400),
      durationMin: kind === 'pocitek' ? 0 : dur, zone: d.zone ? String(d.zone).slice(0, 24) : null,
      tssTarget: d.tssTarget != null && Number.isFinite(+d.tssTarget) ? Math.round(+d.tssTarget) : old.tssTarget,
      why: d.why ? (clean(s, String(d.why).slice(0, 200)) || old.why) : old.why, source: 'ai', updatedAt: now,
      exercises: undefined, optional: kind === old.kind ? old.optional : false,
      role: kind === 'pocitek' ? null : same ? old.role : kind === 'test' ? 'test' : old.role, target: same ? old.target : null,
    })
  }
  // datumi, ki jih je AI izpustil, ostanejo taki, kot so
  for (const d of rides) if (!days.some(x => x.date === d.date)) days.push(d)
  days.push(...fixed)
  days.sort((a, b) => a.date.localeCompare(b.date))
  return { days, summary: clean(s, String(out.povzetek || 'Teden prilagojen.').slice(0, 300)) || 'Teden prilagojen.' }
}

/* ---------- fotografija obroka ---------- */
interface MealOut { jed: string; grami_tehtnica: number | null; grami_ocena: number | null; kcal: number; beljakovine_g: number; ogljikovi_hidrati_g: number | null; mascobe_g: number | null; obrok: string; zanesljivost: string; opomba: string }
const SLOTS = new Set<string>(['zajtrk', 'malica', 'kosilo', 'med_vadbo', 'vecerja', 'drugo'])

export async function mealFromPhoto(p: Profile, file: File, remainingKcal: number | null, remainingProt: number | null): Promise<MealEntry> {
  requireConsent(p)
  const img = await fileToBase64Resized(file, 1280, 0.85)
  const hour = await exifHour(file)
  const out = await askJson<MealOut>(mealPhotoPrompt(img.data, img.mime, remainingKcal, remainingProt), { temp: 0.2 })
  const kcal = Math.max(0, Math.round(+out.kcal || 0))
  let slot = (SLOTS.has(out.obrok) ? out.obrok : 'drugo') as MealEntry['slot']
  if (hour != null) slot = hour < 10 ? 'zajtrk' : hour < 15 ? 'kosilo' : hour < 18 ? 'malica' : 'vecerja'
  const conf: MealEntry['confidence'] = out.zanesljivost === 'visoka' || out.zanesljivost === 'srednja' || out.zanesljivost === 'nizka' ? out.zanesljivost : 'srednja'
  const n = (v: unknown) => (v != null && Number.isFinite(+v) ? Math.round(+v) : null)
  return {
    id: uid(), date: todayIso(), time: hour != null ? `${String(hour).padStart(2, '0')}:00` : new Date().toTimeString().slice(0, 5), slot,
    name: String(out.jed || 'Obrok').slice(0, 80), grams: n(out.grami_tehtnica) ?? n(out.grami_ocena), kcal,
    proteinG: n(out.beljakovine_g), carbsG: n(out.ogljikovi_hidrati_g), fatG: n(out.mascobe_g),
    confidence: conf, source: 'photo', thumb: img.thumb, createdAt: new Date().toISOString(),
  }
}

/* ---------- posnetek zaslona aktivnosti ---------- */
interface ShotOut { sport: string; datum: string | null; trajanje_min: number | null; razdalja_km: number | null; vzpon_m: number | null; povprecni_utrip: number | null; povprecna_moc: number | null; kcal: number | null; ime: string | null; zanesljivost: string }

export async function activityFromShot(p: Profile, file: File): Promise<Activity> {
  requireConsent(p)
  const img = await fileToBase64Resized(file, 1280, 0.85)
  const out = await askJson<ShotOut>(activityShotPrompt(img.data, img.mime), { temp: 0.1 })
  const sport = sportOfType(out.sport) || 'kolo'
  const date = out.datum && /^\d{4}-\d{2}-\d{2}$/.test(out.datum) ? out.datum : todayIso()
  const num = (v: unknown): number | null => (v != null && Number.isFinite(+v) ? +v : null)
  const now = new Date().toISOString()
  const names: Record<string, string> = { kolo: 'Vožnja', tek: 'Tek', pohod: 'Hoja', moc: 'Moč', plavanje: 'Plavanje', drugo: 'Aktivnost' }
  const dist = num(out.razdalja_km), dur = num(out.trajanje_min)
  const a: Activity = {
    id: uid(), source: 'screenshot', sport, date, start: null, name: String(out.ime || names[sport] || 'Aktivnost').slice(0, 80),
    distKm: dist != null ? +dist.toFixed(1) : null, durationMin: dur != null ? Math.round(dur) : null,
    elevM: num(out.vzpon_m) != null ? Math.round(num(out.vzpon_m) as number) : null,
    avgHr: num(out.povprecni_utrip) != null ? Math.round(num(out.povprecni_utrip) as number) : null,
    avgPower: num(out.povprecna_moc) != null ? Math.round(num(out.povprecna_moc) as number) : null,
    kcal: num(out.kcal) != null ? Math.round(num(out.kcal) as number) : null,
    speedKmh: dist && dur ? +(dist / (dur / 60)).toFixed(1) : null, tss: null, polyline: null,
    notes: out.zanesljivost === 'nizka' ? 'Prebrano s posnetka — nizka zanesljivost, preveri številke.' : undefined,
    ...deriveFlags('screenshot'), createdAt: now, updatedAt: now,
  }
  a.tss = estimateTss(a, p)
  return a
}

/* ---------- hladilnik → kaj naj skuham ---------- */
export interface Suggestion { name: string; desc: string; kcal: number; proteinG: number; carbsG: number; fatG: number; minutes?: number | null; missing?: string | null }
export async function fridgeMeals(p: Profile, file: File, remainingKcal: number | null, remainingProt: number | null, training: string | null): Promise<{ seen: string[]; ideas: Suggestion[] }> {
  requireConsent(p)
  const img = await fileToBase64Resized(file, 1280, 0.8)
  const text = [
    'Si prehranski pomočnik v slovenski aplikaciji. Odgovarjaš izključno v slovenščini.', '', NUTRITION_RULES, '',
    'Na sliki je vsebina hladilnika ali shrambe. Prepoznaj živila.',
    `Danes do cilja ostane ${remainingKcal != null ? Math.max(300, Math.round(remainingKcal)) : 'neznano'} kcal in ${remainingProt != null ? Math.max(20, Math.round(remainingProt)) : 'neznano'} g beljakovin. Današnji trening: ${training || 'brez'}.`,
    'Cilj uporabnika: hujšanje z ohranjanjem mišic — visoke beljakovine, sit obrok, preprosta priprava.',
    'Sestavi 3 obroke IZ TEGA, KAR JE NA SLIKI (največ ena manjkajoča sestavina).',
    'Vrni SAMO JSON: {"vidim":["živilo", …],"predlogi":[{"jed":"","opis":"sestavine s količinami v gramih, ena vrstica","kcal":0,"b":0,"oh":0,"m":0,"minut":0,"manjka":""}]}',
  ].join('\n')
  const out = await askJson<{ vidim?: string[]; predlogi?: { jed: string; opis: string; kcal: number; b: number; oh: number; m: number; minut?: number; manjka?: string }[] }>([{ text }, { inlineData: { mimeType: img.mime, data: img.data.includes('base64,') ? img.data.split('base64,')[1]! : img.data } }], { temp: 0.5 })
  const n = (v: unknown) => (Number.isFinite(+(v as number)) ? Math.round(+(v as number)) : 0)
  return {
    seen: (out.vidim || []).slice(0, 14).map(String),
    ideas: (out.predlogi || []).slice(0, 3).map(x => ({ name: String(x.jed || 'Obrok').slice(0, 60), desc: String(x.opis || '').slice(0, 220), kcal: n(x.kcal), proteinG: n(x.b), carbsG: n(x.oh), fatG: n(x.m), minutes: x.minut ? n(x.minut) : null, missing: x.manjka ? String(x.manjka).slice(0, 60) : null })),
  }
}

/* ---------- predlog obroka za preostanek dneva ---------- */
export async function mealIdeas(s: Snapshot, remainingKcal: number, remainingProt: number): Promise<Suggestion[]> {
  requireConsent(s.profile)
  const text = [
    'Si prehranski pomočnik v slovenski aplikaciji. Odgovarjaš izključno v slovenščini.', '', NUTRITION_RULES, '', 'KONTEKST:', ctxOf(s), '',
    `Danes do cilja ostane ${Math.round(remainingKcal)} kcal in ${Math.max(0, Math.round(remainingProt))} g beljakovin. Ura: ${new Date().toTimeString().slice(0, 5)}.`,
    'Predlagaj 3 obroke za preostanek dneva: visoke beljakovine, sit, preprosto, sestavine iz slovenske trgovine, študentski proračun. Vsak predlog naj bo v okviru preostanka.',
    'Vrni SAMO JSON: {"predlogi":[{"jed":"","opis":"sestavine s količinami, ena vrstica","kcal":0,"b":0,"oh":0,"m":0,"minut":0}]}',
  ].join('\n')
  const out = await askJson<{ predlogi?: { jed: string; opis: string; kcal: number; b: number; oh: number; m: number; minut?: number }[] }>([{ text }], { temp: 0.6 })
  const n = (v: unknown) => (Number.isFinite(+(v as number)) ? Math.round(+(v as number)) : 0)
  return (out.predlogi || []).slice(0, 3).map(x => ({ name: String(x.jed || 'Obrok').slice(0, 60), desc: String(x.opis || '').slice(0, 220), kcal: n(x.kcal), proteinG: n(x.b), carbsG: n(x.oh), fatG: n(x.m), minutes: x.minut ? n(x.minut) : null }))
}

/* ---------- jedilnik za teden + nakupovalni seznam ---------- */
export async function weekMenu(s: Snapshot, dailyKcal: number, proteinG: number, favourites: string[]): Promise<WeekMenu> {
  requireConsent(s.profile)
  const ws = weekStartIso(s.today)
  const dates = Array.from({ length: 7 }, (_, i) => { const d = new Date(ws); d.setDate(d.getDate() + i); return d.toISOString().slice(0, 10) })
  const training = s.plan.filter(d => d.date >= ws && d.date <= dates[6]! && d.kind !== 'pocitek' && !d.optional).map(d => `${d.date} ${d.kind} ${d.durationMin} min`).join(', ')
  const text = [
    'Si prehranski pomočnik v slovenski aplikaciji. Odgovarjaš izključno v slovenščini.', '', NUTRITION_RULES, '', 'KONTEKST:', ctxOf(s), '',
    `Osnovni dnevni cilj ${dailyKcal} kcal; na dan s treningom dodaj približno porabo treninga. Beljakovine ${proteinG} g na dan.`,
    `Treningi ta teden: ${training || 'ni načrta'}.`,
    `Rad je: ${favourites.length ? favourites.join(', ') : 'ni podatka'}.`,
    'Sestavi jedilnik za 7 dni: zajtrk, kosilo, malica, večerja — preprosto, ponavljajoče se sestavine (manj odpadkov), slovenska trgovina, študentski proračun.',
    `Datumi: ${dates.join(', ')}.`,
    'Vrni SAMO JSON: {"dnevi":[{"datum":"YYYY-MM-DD","zajtrk":"jed s količinami","kosilo":"","malica":"","vecerja":"","kcal":0,"b":0}],"nakup":["10–20 stvari s količinami za cel teden"]}',
  ].join('\n')
  const out = await askJson<{ dnevi?: { datum: string; zajtrk: string; kosilo: string; malica: string; vecerja: string; kcal: number; b: number }[]; nakup?: string[] }>([{ text }], { temp: 0.6 })
  return {
    weekStart: ws,
    days: (out.dnevi || []).filter(d => dates.includes(d.datum)).map(d => ({ date: d.datum, zajtrk: String(d.zajtrk || ''), kosilo: String(d.kosilo || ''), malica: String(d.malica || ''), vecerja: String(d.vecerja || ''), kcal: Math.round(+d.kcal || 0), proteinG: Math.round(+d.b || 0) })),
    shopping: (out.nakup || []).slice(0, 30).map(String), bought: {}, at: new Date().toISOString(),
  }
}

/* ---------- mesečna ocena ---------- */
export async function monthReview(s: Snapshot, summary: string): Promise<string> {
  requireConsent(s.profile)
  const text = [PERSONA_SHORT, '', NUTRITION_RULES, '', 'KONTEKST:', ctxOf(s), '', 'POVZETEK MESECA:', summary, '',
    'NALOGA: ocena meseca v največ 130 besedah, trije odstavki brez naslovov: kaj se je premaknilo (FTP in W/kg, ure, teža) glede na mejnike do dirke, kaj je zaviralo, ena konkretna sprememba za naslednji mesec. Tikaj, brez emojijev, brez markdown.'].join('\n')
  return clean(s, await askText([{ text }], { temp: 0.5 }))
}

/* ---------- kakšen športnik si ---------- */
export interface AthleteProfile { type: string; summary: string; scores: Record<string, number>; strengths: string[]; weaknesses: string[]; focus: string }
export async function athleteProfile(s: Snapshot): Promise<AthleteProfile> {
  requireConsent(s.profile)
  const text = [PERSONA_SHORT, '', 'KONTEKST:', ctxOf(s), '',
    'NALOGA: oceni, kakšen kolesar je — SAMO iz podatkov v kontekstu, brez izmišljanja. Ocene 0–100 so relativne glede na rekreativnega kolesarja. Fokus naj pove, kaj naj do dirke dela drugače, da doseže ciljni W/kg.',
    'Vrni SAMO JSON: {"tip":"kratek naziv","opis":"2 stavka","ocene":{"vzdrzljivost":0,"prag":0,"vo2":0,"moc":0},"moci":["…"],"sibkosti":["…"],"fokus":"1 stavek, kaj naj naslednjih 8 tednov dela drugače"}'].join('\n')
  const out = await askJson<{ tip?: string; opis?: string; ocene?: Record<string, number>; moci?: string[]; sibkosti?: string[]; fokus?: string }>([{ text }], { temp: 0.4 })
  const sc: Record<string, number> = {}
  for (const k of ['vzdrzljivost', 'prag', 'vo2', 'moc']) sc[k] = Math.max(0, Math.min(100, Math.round(+(out.ocene?.[k] ?? 0))))
  const hid = hasHiddenActivities(s.activities)
  return { type: String(out.tip || '').slice(0, 60), summary: sanitizeGaps(String(out.opis || '').slice(0, 300), hid), scores: sc, strengths: sanitizeList((out.moci || []).slice(0, 4).map(String), hid), weaknesses: sanitizeList((out.sibkosti || []).slice(0, 4).map(String), hid), focus: sanitizeGaps(String(out.fokus || '').slice(0, 200), hid) }
}
const PERSONA_SHORT = 'Si FORMAI — osebni kolesarski trener; cilj športnika je dirka iz konteksta in ciljni W/kg. Odgovarjaš izključno v slovenščini, direktno, s konkretnimi številkami, v drugi osebi, brez markdown. Ne izmišljuj si podatkov. Nisi zdravnik.'

/** Prijazno sporočilo za uporabnika iz AI napake. */
export function aiErrorText(e: unknown): string {
  if (e instanceof AiError) return e.message
  return (e as Error)?.message || 'AI trenutno ni na voljo.'
}
export function isConsentError(e: unknown): boolean { return e instanceof AiError && e.kind === 'consent' }
export function isAuthError(e: unknown): boolean { return e instanceof AiError && e.kind === 'auth' }

export { AiError }
