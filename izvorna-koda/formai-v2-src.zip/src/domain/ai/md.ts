/**
 * (v3.49) Odgovor trenerja z markdownom (Gemini ga vrne kljub navodilu) → bloki za varen izris brez HTML-ja.
 * Podprto: **krepko** / __krepko__, naslovi #–###### (krepka vrstica), alineje »- «, »* «, »• «, »– « in oštevilčene »1. «.
 * Odstrani: povezave (ostane besedilo), slike, oznake HTML, poševno, kodo, tabele (vrstica z »·«), vodoravne črte.
 * Izris je vedno besedilo (React), nikoli innerHTML — oznake HTML in »javascript:« povezave se ne izvedejo.
 */
export interface Inline { t: string; b?: boolean }
export type Block = { k: 'p' | 'h'; c: Inline[] } | { k: 'ul' | 'ol'; items: Inline[][] }

const UL = /^\s*[-*•–—+]\s+(.*)$/
const OL = /^\s*(\d{1,2})[.)]\s+(.*)$/
const HEAD = /^\s{0,3}#{1,6}\s*(.*?)\s*#*\s*$/
const RULE = /^\s*([-*_=])(\s*\1){2,}\s*$/
const TABLE_SEP = /^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)*\|?\s*$/

/** Čiščenje znotraj vrstice (brez krepkega — to ostane za inline()). */
function scrub(s: string): string {
  return s
    .replace(/!\[[^\]]*\]\((?:[^()]|\([^()]*\))*\)/g, '')     // slike
    .replace(/\[([^\]]+)\]\((?:[^()]|\([^()]*\))*\)/g, '$1')  // povezave → besedilo (tudi »javascript:alert(1)«)
    .replace(/<\/?[a-z][^>]*>/gi, '')                     // oznake HTML
    .replace(/`([^`]*)`/g, '$1')                          // koda
    .replace(/(^|[^*\p{L}\d])\*(?![\s*])([^*\n]*?[^\s*])\*(?![*\p{L}\d])/gu, '$1$2')   // *poševno*
    .replace(/(\S)[ \t]{2,}/g, '$1 ')                     // presledki, ki ostanejo za odstranjenim
}

/** Krepko → deli; osamljene zvezdice in podčrtaji ob besedi izginejo. */
function inline(s: string): Inline[] {
  const out: Inline[] = []
  const rx = /\*\*(.+?)\*\*|__(.+?)__/g
  let i = 0, m: RegExpExecArray | null
  const push = (t: string, b?: boolean) => { const x = t.replace(/\*\*|__/g, ''); if (x) out.push(b ? { t: x, b: true } : { t: x }) }
  while ((m = rx.exec(s))) { push(s.slice(i, m.index)); push(m[1] ?? m[2] ?? '', true); i = m.index + m[0].length }
  push(s.slice(i))
  return out
}

export function mdBlocks(src: string): Block[] {
  const out: Block[] = []
  let gap = false
  for (const raw of String(src ?? '').replace(/\r\n?/g, '\n').split('\n')) {
    if (!raw.trim()) { gap = true; continue }
    if (RULE.test(raw) || TABLE_SEP.test(raw)) { gap = true; continue }
    let line = scrub(raw)
    if (/^\s*\|.*\|\s*$/.test(line)) line = line.trim().replace(/^\||\|$/g, '').split('|').map(x => x.trim()).filter(Boolean).join(' · ')
    if (!line.trim()) continue
    const last = out[out.length - 1]
    const h = HEAD.exec(line)
    const ul = !h && UL.exec(line), m = !h && !ul && OL.exec(line)
    // (v3.50) oštevilčen seznam samo po vrsti od 1 — »4. teden bloka je lažji« ali »13. 6. 2027 je Franja« ostane
    // besedilo (prej se je izrisalo kot »1. teden …« oz. »1. 6. 2027«)
    const ol = m && (last && last.k === 'ol' ? +m[1]! === last.items.length + 1 : +m[1]! === 1 && !/^\d{1,2}\.\s/.test(m[2]!)) ? m : null
    if (h) { const c = inline(h[1]!); if (c.length) out.push({ k: 'h', c }) }
    else if (ul || ol) {
      const k = ul ? 'ul' : 'ol', c = inline(ul ? ul[1]! : ol![2]!)
      // alineje istega seznama ostanejo skupaj tudi s prazno vrstico vmes (sanitizeGaps vrstice loči s prazno vrstico)
      if (last && last.k === k) last.items.push(c)
      else out.push({ k, items: [c] })
    } else {
      const c = inline(line.trim())
      if (last && last.k === 'p' && !gap) last.c.push({ t: '\n' }, ...c)
      else out.push({ k: 'p', c })
    }
    gap = false
  }
  return out
}

const txt = (c: Inline[]) => c.map(x => x.t).join('')
/** Golo besedilo za mesta brez izrisa blokov (npr. »Trener pravi« na Danes): brez oznak, alineje z »– «. */
export function plainAi(src: string): string {
  return mdBlocks(src).map(b => ('items' in b ? b.items.map((it, i) => `${b.k === 'ol' ? `${i + 1}.` : '–'} ${txt(it)}`).join('\n') : txt(b.c))).join('\n')
}
