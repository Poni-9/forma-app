import type { Activity, DailyCheckin, MealEntry, PlanDay, Profile, TestEntry } from '@/domain/types'
import { dailyTarget, weightTrend, goalDeficit } from '@/domain/nutrition/energy'
import { cycleInfo } from '@/domain/training/planner'
import { addDays } from '@/domain/training/load'
import { wxShort, type Forecast } from '@/domain/weather'
import { aiAllowed } from '@/domain/import/provenance'

/**
 * Osebni kontekst za AI: cilji (hujšanje, motor, mišice), prehrana v številkah, teža, počutje,
 * vreme in faza cikla. Brez imena in kraja — vreme gre v poziv samo kot pogoji, ne kot lokacija.
 */
export interface PersonalInput {
  profile: Profile
  activities: readonly Activity[]
  plan: readonly PlanDay[]
  checkins: readonly DailyCheckin[]
  recentMeals: readonly MealEntry[]
  tests?: readonly TestEntry[]
  weather?: Forecast | null
  today: string
}

const TEST_L: Record<TestEntry['kind'], string> = { ftp: '20-min test', sklece: 'sklece max', zgibi: 'zgibi max', deska: 'deska', pocep: 'počepi v 2 min', rhr: 'utrip v mirovanju' }

export function personalContext(i: PersonalInput): string {
  const p = i.profile, L: string[] = []
  // Samo aktivnosti, ki smejo v AI (Strava in neznani izvori NIKOLI — tudi ne posredno prek kcal ali moči).
  const acts = i.activities.filter(a => aiAllowed(a))
  const tr = weightTrend(i.checkins)
  const w = tr?.last ?? p.weightKg ?? null
  const eq: string[] = []
  if (p.gear.pullupBar !== false) eq.push('drog za zgibe')
  if (p.gear.dumbbells) eq.push(`uteži${p.gear.dumbbellKg ? ' ' + p.gear.dumbbellKg + ' kg' : ''}`)
  L.push('OSEBNI CILJI (vrstni red pomembnosti):')
  L.push(`1) Shujšati${p.targetWeightKg ? ` na ${p.targetWeightKg} kg` : ''}${w ? ` (zdaj ${w} kg)` : ''} — počasi, brez izgube mišic.`)
  L.push('2) Zgraditi aerobni motor (kolo: Z2 volumen + ena kakovostna seja na teden).')
  L.push(`3) Pridobiti mišice z vadbo doma${p.strength.on ? ` (${p.strengthDays ?? 2}× na teden${eq.length ? '; ' + eq.join(', ') : ''})` : ''}. Brez fitnesa.`)
  if (p.event?.date) L.push(`Dogodek: ${p.event.name} (${p.event.date}).`)

  const cy = cycleInfo(p, i.today)
  if (cy) L.push(`Cikel: ${cy.phase.name}, teden ${cy.week}/${cy.length}${cy.recovery ? ' (razbremenilni)' : ''}.`)

  if (tr) L.push(`Teža: zadnja ${tr.last} kg (${tr.lastDate}), 7-dnevno povprečje ${tr.avg7} kg${tr.deltaWeek != null ? `, sprememba proti prejšnjemu tednu ${tr.deltaWeek > 0 ? '+' : ''}${tr.deltaWeek} kg` : ''}.`)

  const tgt = dailyTarget(p, acts.filter(a => a.date === i.today), i.plan.filter(d => d.date === i.today))
  if (tgt) {
    const days = Array.from({ length: 7 }, (_, k) => addDays(i.today, -1 - k))
    const per = days.map(d => i.recentMeals.filter(m => m.date === d)).filter(x => x.length)
    const kc = per.map(x => x.reduce((s, m) => s + (m.kcal || 0), 0)), pr = per.map(x => x.reduce((s, m) => s + (m.proteinG || 0), 0))
    const avg = (a: number[]) => (a.length ? Math.round(a.reduce((s, x) => s + x, 0) / a.length) : 0)
    L.push(`Prehrana: današnji cilj ${tgt.kcal} kcal (vzdrževanje ${tgt.maintenance}, deficit ${goalDeficit(p)}; spodnja varna meja ${tgt.floor}), beljakovine ${tgt.proteinG} g.${per.length ? ` Zadnjih 7 dni (${per.length} dni zabeleženih): povprečno ${avg(kc)} kcal in ${avg(pr)} g beljakovin.` : ' Prehrana zadnjih dni ni zabeležena.'}`)
  }

  const c = i.checkins.find(x => x.date === i.today)
  if (c && (c.sleepH || c.soreness || c.mood)) L.push(`Jutro danes: spanec ${c.sleepH ?? '?'} h, bolečine ${c.soreness ?? '?'}/5 (1 = svež), počutje ${c.mood ?? '?'}/5${c.note ? `, opomba: ${c.note}` : ''}.`)
  const sleep = i.checkins.filter(x => x.date > addDays(i.today, -7) && x.sleepH).map(x => x.sleepH as number)
  if (sleep.length >= 3) L.push(`Spanec zadnjih dni povprečno ${(sleep.reduce((s, x) => s + x, 0) / sleep.length).toFixed(1)} h.`)

  const strength = [...acts].filter(a => a.sport === 'moc' && a.exercises?.length).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 3)
  if (strength.length) L.push('Zadnje seje moči: ' + strength.map(a => `${a.date} ${a.name}: ${a.exercises!.map(e => `${e.name} ${e.sets}×${e.reps}${e.kg ? '@' + e.kg + 'kg' : ''}`).join(', ')}`).join(' | '))

  const tests = [...(i.tests || [])].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6)
  if (tests.length) L.push('Testi: ' + tests.map(t => `${t.date} ${TEST_L[t.kind]} ${t.value} ${t.unit}`).join('; ') + '.')

  if (i.weather) {
    const wx = Object.values(i.weather).filter(d => d.date >= i.today).slice(0, 7)
    if (wx.length) L.push('Vreme naslednjih dni: ' + wx.map(d => `${d.date} ${wxShort(d)}`).join('; ') + `. ${p.gear.trainer ? 'Ob dežju ali močnem vetru kolo na trenažer.' : 'Trenažerja nima — ob dežju zamenjaj dneve.'}`)
  }
  return L.join('\n')
}
