import type { Activity, DailyCheckin, MealEntry, PlanDay, Profile, TestEntry } from '@/domain/types'
import { dailyTarget, weightTrend, goalDeficit } from '@/domain/nutrition/energy'
import { weekContext, targetHours } from '@/domain/training/planner'
import { goalStatus, milestones, levelOf, LEVELS, vo2maxFromP5, ftpPotential, raceWeightOf } from '@/domain/training/goal'
import { dayMealPlan, rideFuel } from '@/domain/nutrition/dayplan'
import { needOf, suggestRoutes } from '@/domain/routes/match'
import type { RouteRec } from '@/domain/routes/analyze'
import { addDays, weekStartIso } from '@/domain/training/load'
import { wxShort, type Forecast } from '@/domain/weather'
import { aiAllowed } from '@/domain/import/provenance'

/**
 * Osebni kontekst za AI. Glavni cilj: postati res dober kolesar do dirke (privzeto Maraton Franja 2027).
 * Vse ostalo (teža, moč, prehrana) služi temu. Brez imena in kraja — vreme gre v poziv samo kot pogoji.
 * Številke so iste kot v aplikaciji, da AI in zasloni govorijo isto.
 */
export interface PersonalInput {
  profile: Profile
  activities: readonly Activity[]
  plan: readonly PlanDay[]
  checkins: readonly DailyCheckin[]
  recentMeals: readonly MealEntry[]
  tests?: readonly TestEntry[]
  weather?: Forecast | null
  today: string
  /** trase: samo vožnje z Garmina (intervals.icu, ne Strava) in nove trase iz OpenStreetMap */
  routes?: readonly RouteRec[]
}

const TEST_L: Record<TestEntry['kind'], string> = { ftp: '20-min test', p5: '5-min največja moč', sklece: 'sklece max', zgibi: 'zgibi max', deska: 'deska', pocep: 'počepi v 2 min', rhr: 'utrip v mirovanju' }
const f2 = (x: number) => x.toFixed(2).replace('.', ',')
const fd = (iso: string) => `${+iso.slice(8)}. ${+iso.slice(5, 7)}. ${iso.slice(0, 4)}`

export function personalContext(i: PersonalInput): string {
  const p = i.profile, L: string[] = []
  // Samo aktivnosti, ki smejo v AI (Strava in neznani izvori NIKOLI — tudi ne posredno prek kcal ali moči).
  const acts = i.activities.filter(a => aiAllowed(a))
  const g = goalStatus(p, i.checkins, i.tests || [], i.today)
  const ctx = weekContext(p, weekStartIso(i.today))
  const franja = /franj/i.test(g.event?.name || '')

  L.push('GLAVNI CILJ (vse ostalo je drugotno): postati res dober kolesar.')
  if (g.event) L.push(`Dirka: ${g.event.name}, ${fd(g.event.date)}${g.event.distanceKm ? `, ${g.event.distanceKm} km` : ''}${franja ? ' (ravnina v skupini; Vrhniški klanec 4,6 km 4,1 %; Kladje 7 km 6,3 %, do 10 % — odločilni vzpon)' : ''}. Še ${g.weeksToEvent} tednov.`)
  const lv = levelOf(g.wkg), tl = levelOf(g.targetWkg)
  L.push(`Zdaj: FTP ${g.ftp ?? '?'} W${p.ftpDate ? ` (${fd(p.ftpDate)})` : ''}, teža ${g.weight ?? '?'} kg → ${g.wkg ? f2(g.wkg) : '?'} W/kg${lv ? ` (${lv.name.toLowerCase()})` : ''}. Cilj na dan dirke: ${g.targetFtp ?? '?'} W pri ${g.targetWeight ?? '?'} kg → ${g.targetWkg ? f2(g.targetWkg) : '?'} W/kg${tl ? ` (${tl.name.toLowerCase()})` : ''}.`)
  if (g.expected?.wkg) L.push(`Po načrtu bi moral biti danes pri ~${g.expected.ftp} W, ${g.expected.weight} kg (${f2(g.expected.wkg)} W/kg).${g.projectedWkg ? ` Napoved iz dejanskih testov in teže: ${f2(g.projectedWkg)} W/kg na dan dirke.` : ''}`)
  const rw = raceWeightOf(p, i.today), pot = ftpPotential(p, i.today)
  if (rw || pot) L.push(`Cilje je izračunala aplikacija (ne športnik):${rw ? ` najboljša teža ${rw.kg} kg (${rw.measured ? 'izmerjena' : 'ocenjena iz BMI'} maščoba ~${Math.round(rw.bf)} % → ~${rw.targetBf} %, pusta masa ${rw.lbm} kg ostane, razpon ${rw.lo}–${rw.hi} kg, nikoli pod BMI 20,5 = ${rw.floorKg} kg)` : ''}${pot ? `; največji možni FTP do dirke ${pot.ideal} W, realno ${pot.realistic} W (+${pot.gainPct} % pri ${pot.hours} h/teden v ${pot.weeks} tednih)` : ''}. Če vpraša, razloži, kako je to izračunano.`)
  const ms = milestones(p)
  if (ms.length) L.push('Mejniki: ' + ms.map(m => `${m.label} (${fd(m.date)}): ${m.weight} kg · ${m.ftp} W · ${m.wkg ? f2(m.wkg) : '?'} W/kg`).join('; ') + '.')
  L.push('Lestvica amaterjev (FTP W/kg): ' + LEVELS.slice(1).map(l => `${l.name} ${l.desc.split(':')[0]}`).join('; ') + '. Profi GC 6,0–6,5 W/kg.')
  L.push(`Faza: ${ctx.phaseName}${ctx.structured ? `, teden ${ctx.week}${ctx.total ? '/' + ctx.total : ''}` : ''}${ctx.recovery ? ' (razbremenilni)' : ctx.phase === 'osnova' || ctx.phase === 'gradnja' || ctx.phase === 'specificno' ? `, ${ctx.blockWeek}. teden bloka` : ''}${ctx.test ? ', ta teden test FTP' : ''}; načrt ${ctx.hours} h na kolesu (normalen teden ${targetHours(p)} h). ${ctx.phaseDesc}`)
  L.push('METODA (drži se je): polarizirano 80/20; dve ključni seji na teden — torek VO2max (4–6 × 3–5 min pri 108–120 % FTP, odmor 1:1) in četrtek sweet spot/prag (88–100 % FTP, 3 × 12–15 ali 2 × 20 min); sobota dolga Z2 (3–5 h), sreda in nedelja Z2 (56–75 % FTP), petek regeneracija pod 55 %; bloki 3 + 1 (četrti teden ~50 % volumna, brez intervalov); test FTP vsakih 8 tednov; moč 2 × 20–30 min (jedro + noge), ne bodybuilding; tapering zadnja 2 tedna (−40 %). Spanec 8–9 h je del treninga.')

  const tr = weightTrend(i.checkins)
  const def = goalDeficit(p)
  const tgt = dailyTarget(p, acts.filter(a => a.date === i.today), i.plan.filter(d => d.date === i.today), i.today)
  L.push(`PREHRANA: teža naj pada 0,3–0,5 kg na teden do ${p.targetWeightKg ?? '?'} kg (nad 0,7 kg je prehitro — gre mišica in moč), potem vzdrževanje; deficit ${def || 0} kcal samo izven kolesa (v specifični fazi pol, v taperingu nič, na ključne dni pol); na kolesu nad 90 min 40–60 g OH na uro (Z2), 60–80 g (intervali), 80–90 g (dirka); beljakovine ${tgt ? tgt.proteinG + ' g' : '1,8–2,0 g/kg'}.`)
  if (tr) L.push(`Teža: zadnja ${tr.last} kg (${tr.lastDate}), 7-dnevno povprečje ${tr.avg7} kg${tr.deltaWeek != null ? `, sprememba proti prejšnjemu tednu ${tr.deltaWeek > 0 ? '+' : ''}${tr.deltaWeek} kg` : ''}.`)
  if (tgt) {
    const days = Array.from({ length: 7 }, (_, k) => addDays(i.today, -1 - k))
    const per = days.map(d => i.recentMeals.filter(m => m.date === d)).filter(x => x.length)
    const kc = per.map(x => x.reduce((s, m) => s + (m.kcal || 0), 0)), pr = per.map(x => x.reduce((s, m) => s + (m.proteinG || 0), 0))
    const avg = (a: number[]) => (a.length ? Math.round(a.reduce((s, x) => s + x, 0) / a.length) : 0)
    L.push(`Danes: cilj ${tgt.kcal} kcal (vzdrževanje brez treninga ${tgt.maintenance}, deficit danes ${tgt.deficit}${tgt.deficitNote ? ' — ' + tgt.deficitNote : ''}; spodnja varna meja ${tgt.floor}), beljakovine ${tgt.proteinG} g, OH ${tgt.carbsG} g.${per.length ? ` Zadnjih 7 dni (${per.length} dni zabeleženih): povprečno ${avg(kc)} kcal in ${avg(pr)} g beljakovin.` : ' Prehrana zadnjih dni ni zabeležena.'}`)
    const ride = i.plan.filter(d => d.date === i.today && (d.kind === 'kolo' || d.kind === 'test') && !d.optional).sort((a, b) => b.durationMin - a.durationMin)[0] || null
    const dp = dayMealPlan(p, tgt, ride)
    L.push(`Razpored obrokov danes (trening ${p.trainTime || 'popoldne'}): ` + dp.slots.map(s => `${s.label} ${s.kcal} kcal / ${s.proteinG} g B`).join('; ') + (dp.onBike ? `; na kolesu ${dp.onBike.carbs} g OH` : '') + '.')
    const rf = ride ? rideFuel(ride) : null
    if (rf && rf.totalCarbs) L.push(`Gorivo za današnjo vožnjo: ${rf.gph} g OH na uro, skupaj ${rf.totalCarbs} g; s seboj: ${rf.items.join('; ')}.`)
    const need = ride ? needOf(ride, p) : null
    const sug = need && i.routes?.length ? suggestRoutes(i.routes, need, p, i.today)[0] : null
    if (sug) L.push(`Predlagana trasa danes (${sug.rec.source === 'nova' ? 'nova, OpenStreetMap' : 'iz njegovih voženj'}): ${String(sug.rec.km).replace('.', ',')} km, ${sug.rec.gainM} m vzpona, ~${sug.estMin} min; ${sug.why}. ${sug.how}`)
  }

  const c = i.checkins.find(x => x.date === i.today)
  if (c && (c.sleepH || c.soreness || c.mood)) L.push(`Jutro danes: spanec ${c.sleepH ?? '?'} h, mišice ${c.soreness ?? '?'}/5 (1 = sveže), energija ${c.mood ?? '?'}/5${c.note ? `, opomba: ${c.note}` : ''}.`)
  const sleep = i.checkins.filter(x => x.date > addDays(i.today, -7) && x.sleepH).map(x => x.sleepH as number)
  if (sleep.length >= 3) L.push(`Spanec zadnjih dni povprečno ${(sleep.reduce((s, x) => s + x, 0) / sleep.length).toFixed(1)} h.`)

  const strength = [...acts].filter(a => a.sport === 'moc' && a.exercises?.length).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 2)
  if (strength.length) L.push('Zadnje seje moči: ' + strength.map(a => `${a.date} ${a.name}: ${a.exercises!.map(e => `${e.name} ${e.sets}×${e.reps}${e.kg ? '@' + e.kg + 'kg' : ''}`).join(', ')}`).join(' | '))

  const tests = [...(i.tests || [])].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6)
  if (tests.length) L.push('Testi: ' + tests.map(t => `${t.date} ${TEST_L[t.kind]} ${t.value} ${t.unit}${t.kind === 'ftp' ? ` (FTP ${Math.round(t.value * 0.95)} W)` : t.kind === 'p5' && g.weight ? ` (ocena VO2max ${vo2maxFromP5(t.value, g.weight)} ml/kg/min)` : ''}`).join('; ') + '.')

  const eq: string[] = []
  if (p.gear.bikeOutdoor) eq.push('kolo zunaj')
  if (p.gear.trainer) eq.push('trenažer')
  if (p.gear.dumbbells) eq.push(`uteži${p.gear.dumbbellKg ? ' ' + p.gear.dumbbellKg + ' kg' : ''}`)
  if (eq.length) L.push(`Oprema: ${eq.join(', ')}.`)
  if (i.weather) {
    const wx = Object.values(i.weather).filter(d => d.date >= i.today).slice(0, 7)
    if (wx.length) L.push('Vreme naslednjih dni: ' + wx.map(d => `${d.date} ${wxShort(d)}`).join('; ') + `. ${p.gear.trainer ? 'Ob dežju ali močnem vetru ključne seje na trenažer.' : 'Trenažerja nima — ob dežju zamenjaj dneve, ključni seji ne izpusti.'}`)
  }
  return L.join('\n')
}
