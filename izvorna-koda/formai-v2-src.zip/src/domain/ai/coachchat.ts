import type { PlanDay } from '@/domain/types'
import { todayIso, addDays, fmtDur, weekStartIso } from '@/domain/training/load'

/**
 * (v3.50) Kateri teden prilagodi »Prilagodi teden«: dnevi od danes do nedelje — ali naslednji teden (če je sestavljen),
 * ko v tem ni več neopravljenih treningov (v3.50: tudi v nedeljo — današnji trening najprej). Prej je v nedeljo prilagajal teden, ki je mimo (samo današnji
 * počitek), in v poziv dal tudi pretekle dni.
 */
export function adaptTarget(plan: readonly PlanDay[], today: string): { days: PlanDay[]; next: boolean } | null {
  const ws = weekStartIso(today), we = addDays(ws, 6), nws = addDays(ws, 7), nwe = addDays(ws, 13)
  const cur = plan.filter(d => d.date >= today && d.date <= we)
  const nxt = plan.filter(d => d.date >= nws && d.date <= nwe)
  const left = cur.some(d => d.kind !== 'pocitek' && !d.done && !d.optional)
  // (v3.50) tudi v nedeljo: današnji neopravljen trening najprej (prej je prilagodil naslednji teden, današnje dolge ne)
  if (nxt.length && !left) return { days: nxt, next: true }
  return cur.length ? { days: cur, next: false } : null
}

/**
 * (v3.51) Ta teden nima več neopravljenih treningov, naslednji pa še ni sestavljen — »Prilagodi teden« nima česa prilagoditi
 * (prej klic AI za en opravljen dan in »Dnevi ostanejo, kot so bili«) — C49.
 */
export function adaptDone(plan: readonly PlanDay[], today: string): boolean {
  const ws = weekStartIso(today), we = addDays(ws, 6), nws = addDays(ws, 7), nwe = addDays(ws, 13)
  const cur = plan.filter(d => d.date >= today && d.date <= we)
  if (!cur.length || cur.some(d => d.kind !== 'pocitek' && !d.done && !d.optional) || !(cur.some(d => d.done) || today === we)) return false
  return !plan.some(d => d.date >= nws && d.date <= nwe)
}

/** Pomožne funkcije za pogovor s trenerjem (čiste, testirane). */
const WD = ['pon', 'tor', 'sre', 'čet', 'pet', 'sob', 'ned']

/** Ločilnik v pogovoru: danes / včeraj / 22. 9. (lokalni datum sporočila). */
export function dayLabel(iso: string, today: string): string {
  const d = todayIso(new Date(iso))
  if (d === today) return 'danes'
  if (d === addDays(today, -1)) return 'včeraj'
  const [, m, dd] = d.split('-').map(Number)
  return `${dd}. ${m}.`
}

/** Odgovor na »Prilagodi ta teden« gre v pogovor (ne v toast, ki izgine): povzetek + kateri dnevi so drugačni. */
export function adaptText(summary: string, before: readonly PlanDay[], after: readonly PlanDay[]): string {
  const lines = after
    .filter(d => { if (d.kind === 'moc') return false; const o = before.find(x => x.date === d.date && x.kind !== 'moc'); return !!o && (o.title !== d.title || o.durationMin !== d.durationMin || o.kind !== d.kind) })
    .map(d => { const [y, m, dd] = d.date.split('-').map(Number) as [number, number, number]; const wd = WD[(new Date(y, m - 1, dd).getDay() + 6) % 7]; return `– ${wd} ${dd}. ${m}.: ${d.title}${d.durationMin ? ` · ${fmtDur(d.durationMin)}` : ''}` })
  return `${summary}\n\n${lines.length ? 'Spremenjeno:\n' + lines.join('\n') : 'Dnevi ostanejo, kot so bili.'}`
}
