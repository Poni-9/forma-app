import type { PlanDay } from '@/domain/types'
import { todayIso, addDays, fmtDur } from '@/domain/training/load'

/** Pomožne funkcije za pogovor s trenerjem (čiste, testirane). */
const WD = ['pon', 'tor', 'sre', 'čet', 'pet', 'sob', 'ned']

/** Ločilnik v pogovoru: danes / včeraj / 22. 9. (lokalni datum sporočila). */
export function dayLabel(iso: string, today: string): string {
  const d = todayIso(new Date(iso))
  if (d === today) return 'danes'
  if (d === addDays(today, -1)) return 'včeraj'
  const [, m, dd] = d.split('-').map(Number)
  return `${dd}. ${m}.`
}

/** Odgovor na »Prilagodi ta teden« gre v pogovor (ne v toast, ki izgine): povzetek + kateri dnevi so drugačni. */
export function adaptText(summary: string, before: readonly PlanDay[], after: readonly PlanDay[]): string {
  const lines = after
    .filter(d => { if (d.kind === 'moc') return false; const o = before.find(x => x.date === d.date && x.kind !== 'moc'); return !!o && (o.title !== d.title || o.durationMin !== d.durationMin || o.kind !== d.kind) })
    .map(d => { const [y, m, dd] = d.date.split('-').map(Number) as [number, number, number]; const wd = WD[(new Date(y, m - 1, dd).getDay() + 6) % 7]; return `– ${wd} ${dd}. ${m}.: ${d.title}${d.durationMin ? ` · ${fmtDur(d.durationMin)}` : ''}` })
  return `${summary}\n\n${lines.length ? 'Spremenjeno:\n' + lines.join('\n') : 'Dnevi ostanejo, kot so bili.'}`
}
