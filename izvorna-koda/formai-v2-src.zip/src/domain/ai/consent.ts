import type { Profile } from '@/domain/types'

/**
 * Različica besedila privolitve za AI. 1 = Google Gemini; 2 = od 14. 10. 2026 še Anthropic Claude (sestavi načrt
 * uporabnikom s povabilom). Za Gemini velja vsaka privolitev; za Claude mora biti potrjeno besedilo različice 2 —
 * kdor je privolil prej, ga ob prvem klicu Claude vidi in potrdi znova.
 */
export const CONSENT_V = 2
export function hasConsent(p: Pick<Profile, 'aiConsentAt' | 'aiConsentV'>, v = 1): boolean { return !!p.aiConsentAt && (v <= 1 || (p.aiConsentV ?? 1) >= v) }
