import type { Profile } from '@/domain/types'

/**
 * Različica besedila privolitve za AI. 1 = Google Gemini; 2 = od 14. 10. 2026 še Anthropic Claude (sestavi načrt
 * uporabnikom s povabilom). Za Gemini velja vsaka privolitev; za Claude mora biti potrjeno besedilo različice 2 —
 * kdor je privolil prej, ga ob prvem klicu Claude vidi in potrdi znova.
 */
export const CONSENT_V = 2

/**
 * (v3.48) Kaj gre v AI in kaj nikoli — EN vir za list privolitve in Nastavitve → Račun in AI (prej trije različni seznami).
 * Sprememba vsebine = novo besedilo privolitve: premisli, ali je treba dvigniti CONSENT_V.
 */
export const AI_SENT: readonly string[] = [
  'številke profila (starost, spol, višina, teža, FTP, utrip)',
  'povzetek treningov in načrta',
  'jutranji vnosi (počutje, mišice, spanec)',
  'besedilo tvojih vprašanj in pogovora',
  'posnetek glasu, ko narekuješ (samo za prepis v besedilo, ne shrani se)',
  'slike in opisi obrokov, ki jih pošlješ v oceno',
  'slike, ki jih priložiš trenerju (npr. postava, ki si jo želiš)',
]
export const AI_NEVER: readonly string[] = [
  'ime',
  'e-naslov',
  'natančne poti (GPS sled ne zapusti naprave)',
  'vožnje Stravinega izvora',
  'spanec in HRV z ure',
]
/** Kdo obdeluje in kako prekličeš (list privolitve). */
export const AI_WHO: readonly string[] = [
  'Google Gemini; uporabnikom s povabilom načrt (vprašanja, predlog tedna, vaje in strategijo) sestavi Anthropic Claude.',
  'Oba prek plačljivega API-ja, kjer se vsebina ne uporablja za učenje modelov; Anthropic jo praviloma izbriše v 30 dneh.',
  'Klici gredo prek našega strežnika v EU (Google Cloud, Belgija).',
  'Ponudnika lahko obdelujeta tudi zunaj EU (npr. v ZDA), kar varujejo standardne pogodbene klavzule EU.',
  'Privolitev prekličeš v Nastavitvah — takoj in brez posledic za ostalo aplikacijo.',
]

export function hasConsent(p: Pick<Profile, 'aiConsentAt' | 'aiConsentV'>, v = 1): boolean { return !!p.aiConsentAt && (v <= 1 || (p.aiConsentV ?? 1) >= v) }
