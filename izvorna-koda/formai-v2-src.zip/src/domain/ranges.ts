/**
 * Razponi številk, ki jih vpiše uporabnik (v3.48): profil (uvod, Sestavi, Nastavitve) in ročni vnos vadbe.
 * Vrednost izven razpona dobi sporočilo pod poljem — ne shrani se in ne izgine tiho (prej 7,6 kg → 14 g beljakovin).
 */

/** [spodaj, zgoraj, enota, oznaka v sporočilu] */
type Range = readonly [number, number, string, string]

export const PROFILE_RANGE = {
  age: [12, 99, 'let', 'Starost'],
  height: [120, 230, 'cm', 'Višina'],
  weight: [30, 250, 'kg', 'Teža'],
  maxHr: [100, 230, '', 'Max utrip'],
  restHr: [25, 120, '', 'Mirovni utrip'],
  lthr: [80, 220, '', 'Pražni utrip'],
  ftp: [50, 600, 'W', 'FTP'],
  hours: [1, 30, 'h', 'Ure na teden'],
  bf: [3, 60, '%', 'Maščoba'],
  /** ročni cilj kalorij (Nastavitve → Prehrana); pod varno mejo velja varna meja */
  kcal: [800, 6000, 'kcal', 'Ročni cilj'],
  /** (v3.50) teža uteži (Nastavitve → Oprema) — prej brez razpona, 9 999 kg je šlo v vaje */
  dumbbellKg: [1, 60, 'kg', 'Teža uteži'],
} as const satisfies Record<string, Range>

export const ACTIVITY_RANGE = {
  min: [1, 1440, 'min', 'Trajanje'],
  dist: [0, 500, 'km', 'Razdalja'],
  elev: [0, 10000, 'm', 'Vzpon'],
  hr: [30, 230, '', 'Utrip'],
  power: [0, 2000, 'W', 'Moč'],
  kcal: [0, 10000, 'kcal', 'Kalorije'],
} as const satisfies Record<string, Range>

/**
 * (v3.49) Testi (Napredek → Vpiši test): 20-min test do 630 W (FTP = 95 % ostane v razponu profila do 600 W),
 * mirovni utrip kot v profilu. Prej je 5000 namesto 500 dalo FTP 4750 W.
 */
export const TEST_RANGE = {
  ftp: [60, 630, 'W', '20-min test'],
  p5: [80, 800, 'W', '5-min test'],
  rhr: PROFILE_RANGE.restHr,
  lthr: PROFILE_RANGE.lthr,
  deska: [5, 600, 's', 'Deska'],
  zgibi: [1, 200, '', 'Zgibi'],
  sklece: [1, 200, '', 'Sklece'],
  pocep: [1, 200, '', 'Počepi'],
} as const satisfies Record<string, Range>
/** (v3.49) Obrok iz kopije ali oblaka: kalorije izven razpona → obrok se izpusti (ročni vnos ima strožjo mejo 5 000). */
export const MEAL_KCAL_RANGE = [0, 10000, 'kcal', 'Kalorije obroka'] as const satisfies Range

export type ProfileKey = keyof typeof PROFILE_RANGE
export type ActivityKey = keyof typeof ACTIVITY_RANGE
export type TestKey = keyof typeof TEST_RANGE

/** (v3.49) Sporočilo za rezultat testa izven razpona (»20-min test: od 60 do 630 W.«); neznana vrsta → null. */
export function testError(kind: string, v: string | number | null | undefined): string | null {
  const r = (TEST_RANGE as Record<string, Range>)[kind]
  return r ? rangeMsg(v, r) : null
}
/**
 * (v3.49) Velik skok 20-min testa (> 15 % od zadnjega testa ali, brez njega, od FTP v profilu) — pred shranitvijo
 * vprašaj (tipkarska napaka 340 namesto 240 prepiše vse vate v načrtu).
 */
export function testJump(kind: string, value: number, lastTest: number | null | undefined, ftp: number | null | undefined): string | null {
  if (kind !== 'ftp' || !(value > 0)) return null
  const base = lastTest && lastTest > 0 ? lastTest : ftp && ftp > 0 ? ftp / 0.95 : null
  if (!base) return null
  const d = value / base - 1
  if (Math.abs(d) <= 0.15) return null
  const pct = Math.round(Math.abs(d) * 100)
  const ref = lastTest && lastTest > 0 ? `zadnjega testa (${Math.round(lastTest)} W)` : `tvojega FTP (${Math.round(ftp!)} W)`
  return `To je ${pct} % ${d > 0 ? 'več' : 'manj'} od ${ref}. Shranim?`
}

/** Število iz polja (vejica ali pika); prazno ali ne-število → null. */
export const parseNum = (v: string | number | null | undefined): number | null => {
  const s = v == null ? '' : String(v).trim()
  if (!s) return null
  const x = +s.replace(',', '.')
  return Number.isFinite(x) ? x : null
}
/** 10000 → »10 000« (nad 9999 s presledkom, kot v slovenščini). */
const fmtN = (n: number) => (n >= 10000 ? String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') : String(n))
const msgOf = ([lo, hi, u, label]: Range) => `${label}: od ${fmtN(lo)} do ${fmtN(hi)}${u ? ` ${u}` : ''}.`

/** Sporočilo za vrednost izven razpona (»Teža: od 30 do 250 kg.«); prazno polje je v redu (izpolniš pozneje). */
export function rangeMsg(v: string | number | null | undefined, r: Range): string | null {
  const s = v == null ? '' : String(v).trim()
  if (!s) return null
  const x = parseNum(s)
  return x == null || x < r[0] || x > r[1] ? msgOf(r) : null
}
/** Vrednost v razponu ali null (prazno ali izven razpona). */
export function inRange(v: string | number | null | undefined, r: Range): number | null {
  const x = parseNum(v)
  return x != null && x >= r[0] && x <= r[1] ? x : null
}

/** Napake polj profila (samo podana polja): ključ → sporočilo. (v3.50) tudi vrstni red utripov med podanimi polji. */
export function profileErrors(f: Partial<Record<ProfileKey, string>>): Partial<Record<ProfileKey, string>> {
  const out: Partial<Record<ProfileKey, string>> = {}
  for (const k of Object.keys(f) as ProfileKey[]) {
    if (!(k in PROFILE_RANGE)) continue
    const m = rangeMsg(f[k], PROFILE_RANGE[k])
    if (m) out[k] = m
  }
  return { ...hrOrderErrors(f), ...out }
}

type HrKey = 'maxHr' | 'lthr' | 'restHr'
/**
 * (v3.50) Utripi po vrsti: mirovni < pražni < max. Prej se je max 150 pod pražnim 184 shranil brez besede — cone utripa
 * in ocena TSS sta bili narobe. `blame`: spremenjena polja (sporočilo gre k polju, ki ga je uporabnik spremenil).
 */
export function hrOrderErrors(f: Partial<Record<HrKey, string | number | null>>, blame?: readonly string[]): Partial<Record<HrKey, string>> {
  const mx = inRange(f.maxHr, PROFILE_RANGE.maxHr), lt = inRange(f.lthr, PROFILE_RANGE.lthr), rs = inRange(f.restHr, PROFILE_RANGE.restHr)
  const out: Partial<Record<HrKey, string>> = {}
  const on = (a: HrKey, b: HrKey): HrKey => (!blame || blame.includes(a) || !blame.includes(b) ? a : b)
  if (mx != null && lt != null && mx <= lt) {
    const k = on('maxHr', 'lthr')
    out[k] = k === 'maxHr' ? `Max utrip mora biti višji od pražnega (${lt}).` : `Pražni utrip mora biti nižji od max utripa (${mx}).`
  }
  if (rs != null && lt != null && rs >= lt) {
    const k = on('restHr', 'lthr')
    if (!out[k]) out[k] = k === 'restHr' ? `Mirovni utrip mora biti nižji od pražnega (${lt}).` : `Pražni utrip mora biti višji od mirovnega (${rs}).`
  } else if (rs != null && mx != null && rs >= mx) {
    const k = on('restHr', 'maxHr')
    if (!out[k]) out[k] = k === 'restHr' ? `Mirovni utrip mora biti nižji od max utripa (${mx}).` : `Max utrip mora biti višji od mirovnega (${rs}).`
  }
  // pri blame samo polja, ki so bila spremenjena (staro stanje profila ne blokira)
  if (blame) for (const k of Object.keys(out) as HrKey[]) if (!blame.includes(k)) delete out[k]
  return out
}

/** Napake ročnega vnosa vadbe (trajanje, razdalja, vzpon, utrip, moč, kcal): ključ → sporočilo. */
export function manualActivityErrors(f: Partial<Record<ActivityKey, string | number | null>>): Partial<Record<ActivityKey, string>> {
  const out: Partial<Record<ActivityKey, string>> = {}
  for (const k of Object.keys(f) as ActivityKey[]) {
    if (!(k in ACTIVITY_RANGE)) continue
    const m = rangeMsg(f[k], ACTIVITY_RANGE[k])
    if (m) out[k] = m
  }
  return out
}
