/**
 * Razponi številk, ki jih vpiše uporabnik (v3.48): profil (uvod, Sestavi, Nastavitve) in ročni vnos vadbe.
 * Vrednost izven razpona dobi sporočilo pod poljem — ne shrani se in ne izgine tiho (prej 7,6 kg → 14 g beljakovin).
 */

/** [spodaj, zgoraj, enota, oznaka v sporočilu] */
type Range = readonly [number, number, string, string]

export const PROFILE_RANGE = {
  age: [12, 99, 'let', 'Starost'],
  height: [120, 230, 'cm', 'Višina'],
  weight: [30, 250, 'kg', 'Teža'],
  maxHr: [100, 230, '', 'Max utrip'],
  restHr: [25, 120, '', 'Mirovni utrip'],
  lthr: [80, 220, '', 'Pražni utrip'],
  ftp: [50, 600, 'W', 'FTP'],
  hours: [1, 30, 'h', 'Ure na teden'],
  bf: [3, 60, '%', 'Maščoba'],
  /** ročni cilj kalorij (Nastavitve → Prehrana); pod varno mejo velja varna meja */
  kcal: [800, 6000, 'kcal', 'Ročni cilj'],
} as const satisfies Record<string, Range>

export const ACTIVITY_RANGE = {
  min: [1, 1440, 'min', 'Trajanje'],
  dist: [0, 500, 'km', 'Razdalja'],
  elev: [0, 10000, 'm', 'Vzpon'],
  hr: [30, 230, '', 'Utrip'],
  power: [0, 2000, 'W', 'Moč'],
  kcal: [0, 10000, 'kcal', 'Kalorije'],
} as const satisfies Record<string, Range>

export type ProfileKey = keyof typeof PROFILE_RANGE
export type ActivityKey = keyof typeof ACTIVITY_RANGE

/** Število iz polja (vejica ali pika); prazno ali ne-število → null. */
export const parseNum = (v: string | number | null | undefined): number | null => {
  const s = v == null ? '' : String(v).trim()
  if (!s) return null
  const x = +s.replace(',', '.')
  return Number.isFinite(x) ? x : null
}
/** 10000 → »10 000« (nad 9999 s presledkom, kot v slovenščini). */
const fmtN = (n: number) => (n >= 10000 ? String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') : String(n))
const msgOf = ([lo, hi, u, label]: Range) => `${label}: od ${fmtN(lo)} do ${fmtN(hi)}${u ? ` ${u}` : ''}.`

/** Sporočilo za vrednost izven razpona (»Teža: od 30 do 250 kg.«); prazno polje je v redu (izpolniš pozneje). */
export function rangeMsg(v: string | number | null | undefined, r: Range): string | null {
  const s = v == null ? '' : String(v).trim()
  if (!s) return null
  const x = parseNum(s)
  return x == null || x < r[0] || x > r[1] ? msgOf(r) : null
}
/** Vrednost v razponu ali null (prazno ali izven razpona). */
export function inRange(v: string | number | null | undefined, r: Range): number | null {
  const x = parseNum(v)
  return x != null && x >= r[0] && x <= r[1] ? x : null
}

/** Napake polj profila (samo podana polja): ključ → sporočilo. */
export function profileErrors(f: Partial<Record<ProfileKey, string>>): Partial<Record<ProfileKey, string>> {
  const out: Partial<Record<ProfileKey, string>> = {}
  for (const k of Object.keys(f) as ProfileKey[]) {
    if (!(k in PROFILE_RANGE)) continue
    const m = rangeMsg(f[k], PROFILE_RANGE[k])
    if (m) out[k] = m
  }
  return out
}

/** Napake ročnega vnosa vadbe (trajanje, razdalja, vzpon, utrip, moč, kcal): ključ → sporočilo. */
export function manualActivityErrors(f: Partial<Record<ActivityKey, string | number | null>>): Partial<Record<ActivityKey, string>> {
  const out: Partial<Record<ActivityKey, string>> = {}
  for (const k of Object.keys(f) as ActivityKey[]) {
    if (!(k in ACTIVITY_RANGE)) continue
    const m = rangeMsg(f[k], ACTIVITY_RANGE[k])
    if (m) out[k] = m
  }
  return out
}
