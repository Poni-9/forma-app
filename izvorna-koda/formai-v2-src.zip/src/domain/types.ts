/* Jedrne domenske oblike. Brez odvisnosti od UI ali shrambe. */

export type Sport = 'kolo' | 'tek' | 'pohod' | 'moc' | 'plavanje' | 'drugo';

/** Od kod je aktivnost prišla. To je nosilna odločitev arhitekture:
 *  vsaka aktivnost nosi izvor, pravila (AI, karta) berejo zastavice — nikoli ne ugibajo. */
export type ActivitySource =
  | 'file'            // posamezna GPX/FIT/TCX datoteka, ki jo je naložil uporabnik
  | 'archive'         // uvoz arhiva (Garmin GDPR izvoz, Strava arhiv) — tudi uporabnikove datoteke
  | 'intervals'       // intervals.icu API (osebni ključ ali OAuth)
  | 'screenshot'      // posnetek zaslona → AI vid
  | 'manual'          // ročni vnos
  | 'recorder'        // FORMAI PWA snemalnik
  | 'strava_api'      // Strava API — SAMO prikaz, 7 dni, nikoli AI, nikoli karta
  | 'demo';

export interface Activity {
  id: string;
  source: ActivitySource;
  /** Pri intervals.icu: od kod je aktivnost prišla v intervals (GARMIN, STRAVA, UPLOAD …). */
  originHint?: string | null;
  /** Naprava, če jo poznamo (FIT device_info / intervals device_name). */
  deviceName?: string | null;

  sport: Sport;
  /** ISO datum (lokalni), npr. 2026-08-22 */
  date: string;
  /** Točen začetek ISO (UTC), če ga poznamo — za deduplikacijo ±90 s */
  start?: string | null;
  name: string;

  distKm?: number | null;
  /** čas gibanja (min) */
  durationMin?: number | null;
  /** čas od starta do cilja z vsemi postanki (min) — za dolžino tras */
  elapsedMin?: number | null;
  elevM?: number | null;
  avgHr?: number | null;
  maxHr?: number | null;
  avgPower?: number | null;
  speedKmh?: number | null;
  kcal?: number | null;
  /** Ocenjena ali prebrana obremenitev (TSS). */
  tss?: number | null;
  /** čas v conah utripa (s) — iz intervals.icu (7 con po pražnem utripu) */
  hrZoneSec?: number[] | null;
  /** zgornje meje teh con utripa (udarci/min) */
  hrZoneTop?: number[] | null;
  /** moč izmerjena z merilnikom (true) ali ne (false); null = ne vemo */
  deviceWatts?: boolean | null;
  /** vožnja na trenažerju */
  trainer?: boolean | null;
  notes?: string;
  /** Moč: dejansko opravljene vaje (serije × ponovitve, kg). */
  exercises?: { name: string; sets: number; reps: string; kg?: number | null }[];

  /** Kodirana sled (Google polyline, 1e-5), zredčena na ~20 m. NIKOLI ne gre v oblak. */
  polyline?: string | null;

  /** Izpeljane zastavice — izračunane ob zapisu, berejo jih pravila. */
  aiEligible: boolean;
  geoRetain: boolean;
  /** Če je nastavljen, zapis poteče (Strava §6.2: 7 dni). */
  expiresAt?: string | null;

  /** Zunanji ID-ji za deduplikacijo med viri. */
  ext?: { intervalsId?: string | number; stravaId?: string | number; fileName?: string; /** kondicija (CTL) in utrujenost (ATL) po intervals.icu ob tej aktivnosti — za začetno stanje forme */ icuCtl?: number | null; icuAtl?: number | null };

  createdAt: string;
  updatedAt: string;
}

export type Sex = 'm' | 'z' | null;

export interface Profile {
  name?: string;
  sex: Sex;
  age?: number | null;
  heightCm?: number | null;
  weightKg?: number | null;
  restHr?: number | null;
  maxHr?: number | null;
  lthr?: number | null;
  ftp?: number | null;
  ftpDate?: string | null;
  /** Cilj iz prijave. */
  goal?: 'hitrejsi' | 'shujsati' | 'dirka' | 'forma' | null;
  raceDate?: string | null;
  /** Oprema: kolo zunaj, trenažer, brez kolesa; doma: drog za zgibe, uteži. */
  gear: { bikeOutdoor: boolean; trainer: boolean; noBike: boolean; pullupBar?: boolean; dumbbells?: boolean; dumbbellKg?: number | null; /** merilnik moči na kolesu (null = ne vemo); powerMeterAuto = zaznano iz voženj */ powerMeter?: boolean | null; powerMeterAuto?: boolean };
  /** Samoocena forme 1–4 (začenjam … tekmujem). */
  level?: 1 | 2 | 3 | 4 | null;
  /** Tedenske ure, ki jih ima na voljo. */
  hoursPerWeek?: number | null;
  /** Kako so bile ure izbrane: »največ, kar gre« (iz voženj) ali sam določil. */
  hoursMode?: 'max' | 'own' | null;
  /** Moč kot dodatek. */
  strength: { on: boolean; equipment: 'none' | 'home' | 'gym'; /** faze, v katerih je moč v načrtu (null = vse), npr. samo osnova */ phases?: PhaseName[] | null };
  /** Koliko vadb moči na teden (0–4). Privzeto 3, če je moč vklopljena. */
  strengthDays?: number | null;
  /** Dnevni deficit pod vzdrževanjem (kcal) — omejen na MAX_DEFICIT. */
  deficit?: number | null;
  /** Faktor gibanja izven treninga (1,3 sedeče · 1,4 zmerno · 1,5 veliko hoje). */
  neat?: number | null;
  /** Beljakovine g/kg (1,6–2,2). */
  proteinGkg?: number | null;
  /** Ciljna teža. */
  targetWeightKg?: number | null;
  /** Glavni cilj z datumom (npr. Franja) — prvi cilj sezone (A); načrt je makrocikel do tega in drugih ciljev A. */
  event?: { name: string; date: string; distanceKm?: number | null; type?: RaceType | null; elevM?: number | null; level?: 'amater' | 'visji' | null } | null;
  /** Druge tekme v sezoni (A = še en cilj sezone, B, C): načrt se jim prilagodi, dodaš jih kadarkoli. */
  races?: Race[] | null;
  /** Off-season na začetku načrta: tedni počitka, hribov in vožnje po občutku (0–4). Po njem je FTP nekaj % nižji. */
  offSeasonWeeks?: number | null;
  /** Koliko sezon že resno treniraš (1 = prva) — več sezon = manj prostora za napredek (FTP, W/kg). */
  trainingSeasons?: number | null;
  /** Kdaj se je začel zadnji off-season (ali je bil vprašanje »konec sezone?« zavrnjen) — da ne sprašujemo znova. */
  offSeasonAt?: string | null;
  offSeasonAskedAt?: string | null;
  /** Ciljni FTP na dan dogodka (W). */
  targetFtp?: number | null;
  /** Delež maščobe v %, če ga poznaš (vaga, kaliper) — sicer ocena iz BMI. */
  bodyFatPct?: number | null;
  /** Kaj imaš za na kolo (ključi iz FUEL_ITEMS); null = privzeto (domači izotonik, Frutabela, banana, gel). */
  fuelKit?: string[] | null;
  /** Kdaj običajno treniraš — za razpored obrokov. */
  trainTime?: 'zjutraj' | 'popoldne' | 'zvecer' | null;
  /** Izhodišče ob potrditvi cilja — za »na poti« in napoved. */
  goalStart?: { date: string; ftp: number | null; weightKg: number | null } | null;
  /** Začetek načrta (ponedeljek, ISO): makrocikel do dogodka ali 12-tedenski cikel brez dogodka. */
  cycleStart?: string | null;
  /** Dejanske ure na kolesu na teden ob začetku načrta (povprečje zadnjih polnih tednov) — načrt raste od tu +10 % na teden. */
  baseHours?: number | null;
  /** Kraj za vreme (opcijsko). */
  place?: { name: string; lat: number; lon: number } | null;
  /** Dnevni cilj kalorij — če ga je uporabnik ročno nastavil; sicer izračun. */
  kcalOverride?: number | null;
  /** Privolitev za AI obdelavo (GDPR). */
  aiConsentAt?: string | null;
  onboardingDone: boolean;
  createdAt: string;
  updatedAt: string;
  /** Sinhronizacija: kdaj se je posamezno polje nazadnje spremenilo (ISO) — novejša sprememba polja zmaga,
   *  ne glede na to, katera naprava je kaj drugega spremenila kasneje. Vzdržuje ga repo.saveProfile. */
  fieldAt?: Record<string, string>;
}

export type PlanKind = 'kolo' | 'tek' | 'pohod' | 'moc' | 'pocitek' | 'test';
export type PhaseName = 'prehod' | 'osnova' | 'gradnja' | 'specificno' | 'tapering' | 'dirka' | 'po';
/** Vrsta dirke — določa, kaj se trenira v specifičnem bloku pred njo (šprint, klanci, vzpon, maraton, kronometer, cestna). */
export type RaceType = 'sprint' | 'klanci' | 'vzpon' | 'maraton' | 'kronometer' | 'cestna';
/**
 * Tekma v sezoni. A = cilj sezone (vrh forme: specifičen blok za to vrsto dirke + tapering; več jih je lahko),
 * B = pomembna (kratek počitek pred njo), C = za trening (brez počitka, nadomesti ključni trening).
 */
export interface Race {
  id: string; name: string; date: string; distanceKm?: number | null; prio: 'A' | 'B' | 'C'; type?: RaceType | null
  /** skupni vzpon (m), če ga veš — več klancev = več dela na klancih v bloku pred tekmo */
  elevM?: number | null
  /** rang: amaterska ali višji rang (UCI, U23, elite) — hitrejša, težja, napadi */
  level?: 'amater' | 'visji' | null
}

export interface PlanDay {
  id: string;
  /** ISO datum */
  date: string;
  kind: PlanKind;
  title: string;
  /** kratek opis, kako izvesti */
  desc: string;
  durationMin: number;
  /** ciljna cona, npr. Z2 ali C2, ali 'pogovorni tempo' */
  zone?: string | null;
  tssTarget?: number | null;
  /** za moč: seznam vaj */
  exercises?: { name: string; sets: number; reps: string; kg?: number | null }[];
  /** neobvezen dan — ne šteje v realizacijo */
  optional?: boolean;
  /** vloga v tednu: ključna seja, dolga, lahka, regeneracija, test, dirka, moč */
  role?: 'kljucna' | 'dolga' | 'lahka' | 'regen' | 'test' | 'dirka' | 'moc' | null;
  /** ciljna moč delovnih intervalov (W) */
  target?: { lo: number; hi: number } | null;
  /** kcal poraba (ocena) in vnos (cilj) */
  kcalBurn?: number | null;
  /** opravljeno: povezava na aktivnost ali ročna kljukica */
  done?: { at: string; activityId?: string | null } | null;
  /** kdaj se je »opravljeno« nazadnje spremenilo (tudi odkljukano) — pri združevanju naprav ima svoj čas */
  doneAt?: string | null;
  /** zakaj ta dan (razlaga trenerja) */
  why?: string | null;
  /** zamenjava (npr. hribi namesto kolesa): prvotni trening, da ga vrneš z enim klikom */
  swap?: Pick<PlanDay, 'kind' | 'title' | 'desc' | 'durationMin' | 'zone' | 'tssTarget' | 'role' | 'target'> | null;
  /** dan tekme (id iz profile.races) */
  raceId?: string | null;
  /**
   * Prilagojeno po pretežki vožnji dneva `after` (olajšano ali prestavljeno): prvotna vsebina za »Vrni prvotni načrt«.
   * off = uporabnik je vrnil prvotni načrt — oznaka ostane, da se isti dan ne prilagodi znova (tudi na drugi napravi).
   */
  adapt?: { after: string; prev?: PlanContent | null; off?: boolean } | null;
  source: 'rules' | 'ai';
  createdAt: string;
  updatedAt: string;
}

/** Vsebina dneva v načrtu (brez datuma, id-ja in stanja) — za zamenjave in vračanje. */
export type PlanContent = Pick<PlanDay, 'kind' | 'title' | 'desc' | 'durationMin' | 'zone' | 'tssTarget' | 'role' | 'target' | 'kcalBurn' | 'why' | 'optional' | 'exercises'>

export interface MealEntry {
  id: string;
  date: string;          // ISO datum
  time?: string | null;  // HH:MM
  slot: 'zajtrk' | 'malica' | 'kosilo' | 'med_vadbo' | 'vecerja' | 'drugo';
  name: string;
  grams?: number | null;
  kcal: number;
  proteinG?: number | null;
  carbsG?: number | null;
  fatG?: number | null;
  confidence?: 'visoka' | 'srednja' | 'nizka' | null;
  source: 'manual' | 'photo' | 'suggest' | 'text';
  /** ocena po sestavinah (opis z besedilom ali glasom) — samo za prikaz; vsote so v kcal/proteinG/carbsG/fatG */
  items?: { name: string; qty?: string | null; kcal: number }[] | null;
  thumb?: string | null; // majhna base64 sličica — SAMO lokalno
  createdAt: string;
  /** zadnja sprememba — pri združevanju naprav zmaga novejša različica */
  updatedAt?: string;
  /** vpis »Na kolesu«: popito in predlagano (ml) — iz tega se uči, koliko piješ */
  fluidMl?: number | null;
  planMl?: number | null;
  /** dan načrta, za katerega je vpis goriva */
  forDay?: string | null;
  /** vpis goriva po kosih (ključ iz FUEL_ITEMS ali 'voda' → število, bidoni po pol) — za urejanje */
  fuel?: Record<string, number> | null;
}

export interface DailyCheckin {
  date: string;
  soreness?: 1 | 2 | 3 | 4 | 5 | null;   // 1 = svež, 5 = zelo boleč
  sleepH?: number | null;
  mood?: 1 | 2 | 3 | 4 | 5 | null;
  weightKg?: number | null;
  waistCm?: number | null;
  note?: string | null;
  /** zadnja sprememba — pri združevanju naprav je novejši osnova */
  updatedAt?: string;
}

/** Test (20-min FTP, max sklece, max zgibi, deska …). Hrani se v kv 'tests'. */
export interface TestEntry {
  id: string;
  date: string;
  kind: 'ftp' | 'p5' | 'sklece' | 'zgibi' | 'deska' | 'pocep' | 'rhr';
  value: number;
  unit: string;
}

export interface WeekMenu {
  weekStart: string;
  days: {
    date: string; zajtrk: string; kosilo: string; malica: string; vecerja: string; kcal: number; proteinG: number;
    /** cilj tega dne (z načrtovanim treningom) in spodnja varna meja (BMR / 1500 / 1200) */
    targetKcal?: number | null; floorKcal?: number | null;
    /** jedilnik tega dne je pod varno mejo — koliko kcal je dodanih (dodatek je vpisan pri malici) */
    low?: boolean; addKcal?: number | null;
  }[];
  shopping: string[];
  bought: Record<number, boolean>;
  at: string;
  /** dnevi, kjer je AI jedilnik pod varno mejo (dopolnjeni z dodatkom), in pojasnilo za prikaz */
  lowDays?: string[];
  note?: string | null;
}

export interface Settings {
  accentHex?: string;         // odtenek zelene iz dizajna
  intervals?: { athleteId: string; apiKey: string; /** OAuth žeton (»Poveži z intervals.icu«) — namesto API ključa; athleteId je tedaj '0' (lastnik žetona) */ token?: string | null; name?: string; /** treningi za naslednjih 14 dni v koledar intervals.icu → Garmin (privzeto vklopljeno) */ pushWorkouts?: boolean; /** uporabnik je potrdil, da je v intervals.icu vklopil »Upload planned workouts« */ planUploadOk?: boolean } | null;
  lang: 'sl' | 'en';
  installPromptDismissedAt?: string | null;
  /** Testi (FTP, sklece, zgibi …) — v nastavitvah, da se sinhronizirajo. */
  tests?: TestEntry[];
  /** Tedenski jedilnik + nakupovalni seznam (AI). */
  menu?: WeekMenu | null;
  /** AI profil športnika (ocena iz zgodovine). */
  athleteProfile?: { at: string; type: string; summary: string; scores: Record<string, number>; strengths: string[]; weaknesses: string[]; focus: string } | null;
  /** Vodnik »Kako deluje« je bil prikazan (false = pokaži ob naslednjem odprtju Danes). */
  guideSeen?: boolean;
  /** Kartica »Prvi koraki« na Danes je skrita (ali opravljena). */
  startDone?: boolean;
  /** Spanec, HRV in mirovni utrip iz intervals.icu za jutranjo pripravljenost (izrecna privolitev; podatki samo na napravi). */
  wellnessOn?: boolean;
  /** Testni program: anonimna oznaka, koda povabila, kdaj so bila vprašanja (in ali jih ne želiš). */
  pilot?: import('./pilot').PilotState | null;
  /** Mesečne AI ocene po ključu YYYY-MM. */
  monthReviews?: Record<string, { at: string; text: string }>;
  /** Pogovor s trenerjem — sinhroniziran med napravami; starejši del je strnjen v povzetek (spomin trenerja). */
  coach?: {
    msgs: CoachMsg[]; summary?: string | null
    /** »Nov pogovor«: sporočila do tega časa so izbrisana na vseh napravah */
    clearedAt?: string | null
    /** sporočila do tega časa so že v povzetku (ne vrnejo se z druge naprave) */
    foldedTo?: string | null
    /** kdaj je bil povzetek nazadnje posodobljen */
    summaryAt?: string | null
  } | null;
  /** zadnja sprememba nastavitev (za združevanje naprav) */
  updatedAt?: string;
  /** Sinhronizacija: kdaj se je posamezno polje nazadnje spremenilo (ISO); vzdržuje ga repo.saveSettings. */
  fieldAt?: Record<string, string>;
}
export interface CoachMsg { role: 'user' | 'ai'; text: string; at: string; /** posebni odgovori v istem pogovoru: nasvet za danes, pregled tedna, prilagojen teden */ kind?: 'advice' | 'review' | 'adapt' }
