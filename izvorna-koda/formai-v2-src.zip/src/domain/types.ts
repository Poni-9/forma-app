/* Jedrne domenske oblike. Brez odvisnosti od UI ali shrambe. */

export type Sport = 'kolo' | 'tek' | 'pohod' | 'moc' | 'plavanje' | 'drugo';

/** Od kod je aktivnost prišla. To je nosilna odločitev arhitekture:
 *  vsaka aktivnost nosi izvor, pravila (AI, karta) berejo zastavice — nikoli ne ugibajo. */
export type ActivitySource =
  | 'file'            // posamezna GPX/FIT/TCX datoteka, ki jo je naložil uporabnik
  | 'archive'         // uvoz arhiva (Garmin GDPR izvoz, Strava arhiv) — tudi uporabnikove datoteke
  | 'intervals'       // intervals.icu API (osebni ključ ali OAuth)
  | 'screenshot'      // posnetek zaslona → AI vid
  | 'manual'          // ročni vnos
  | 'recorder'        // FORMAI PWA snemalnik
  | 'strava_api'      // Strava API — SAMO prikaz, 7 dni, nikoli AI, nikoli karta
  | 'demo';

export interface Activity {
  id: string;
  source: ActivitySource;
  /** Pri intervals.icu: od kod je aktivnost prišla v intervals (GARMIN, STRAVA, UPLOAD …). */
  originHint?: string | null;
  /** Naprava, če jo poznamo (FIT device_info / intervals device_name). */
  deviceName?: string | null;

  sport: Sport;
  /** ISO datum (lokalni), npr. 2026-08-22 */
  date: string;
  /** Točen začetek ISO (UTC), če ga poznamo — za deduplikacijo ±90 s */
  start?: string | null;
  name: string;

  distKm?: number | null;
  /** čas gibanja (min) */
  durationMin?: number | null;
  /** čas od starta do cilja z vsemi postanki (min) — za dolžino tras */
  elapsedMin?: number | null;
  elevM?: number | null;
  avgHr?: number | null;
  maxHr?: number | null;
  avgPower?: number | null;
  speedKmh?: number | null;
  kcal?: number | null;
  /** Ocenjena ali prebrana obremenitev (TSS). */
  tss?: number | null;
  /** čas v conah utripa (s) — iz intervals.icu (7 con po pražnem utripu) */
  hrZoneSec?: number[] | null;
  /** zgornje meje teh con utripa (udarci/min) */
  hrZoneTop?: number[] | null;
  /** moč izmerjena z merilnikom (true) ali ne (false); null = ne vemo */
  deviceWatts?: boolean | null;
  /** vožnja na trenažerju */
  trainer?: boolean | null;
  notes?: string;
  /** Moč: dejansko opravljene vaje (serije × ponovitve, kg). */
  exercises?: { name: string; sets: number; reps: string; kg?: number | null }[];

  /** Kodirana sled (Google polyline, 1e-5), zredčena na ~20 m. NIKOLI ne gre v oblak. */
  polyline?: string | null;

  /** Izpeljane zastavice — izračunane ob zapisu, berejo jih pravila. */
  aiEligible: boolean;
  geoRetain: boolean;
  /** Če je nastavljen, zapis poteče (Strava §6.2: 7 dni). */
  expiresAt?: string | null;

  /** Zunanji ID-ji za deduplikacijo med viri. */
  ext?: { intervalsId?: string | number; stravaId?: string | number; fileName?: string };

  createdAt: string;
  updatedAt: string;
}

export type Sex = 'm' | 'z' | null;

export interface Profile {
  name?: string;
  sex: Sex;
  age?: number | null;
  heightCm?: number | null;
  weightKg?: number | null;
  restHr?: number | null;
  maxHr?: number | null;
  lthr?: number | null;
  ftp?: number | null;
  ftpDate?: string | null;
  /** Cilj iz prijave. */
  goal?: 'hitrejsi' | 'shujsati' | 'dirka' | 'forma' | null;
  raceDate?: string | null;
  /** Oprema: kolo zunaj, trenažer, brez kolesa; doma: drog za zgibe, uteži. */
  gear: { bikeOutdoor: boolean; trainer: boolean; noBike: boolean; pullupBar?: boolean; dumbbells?: boolean; dumbbellKg?: number | null; /** merilnik moči na kolesu (null = ne vemo); powerMeterAuto = zaznano iz voženj */ powerMeter?: boolean | null; powerMeterAuto?: boolean };
  /** Samoocena forme 1–4 (začenjam … tekmujem). */
  level?: 1 | 2 | 3 | 4 | null;
  /** Tedenske ure, ki jih ima na voljo. */
  hoursPerWeek?: number | null;
  /** Kako so bile ure izbrane: »največ, kar gre« (iz voženj) ali sam določil. */
  hoursMode?: 'max' | 'own' | null;
  /** Moč kot dodatek. */
  strength: { on: boolean; equipment: 'none' | 'home' | 'gym' };
  /** Koliko vadb moči na teden (0–4). Privzeto 3, če je moč vklopljena. */
  strengthDays?: number | null;
  /** Dnevni deficit pod vzdrževanjem (kcal) — omejen na MAX_DEFICIT. */
  deficit?: number | null;
  /** Faktor gibanja izven treninga (1,3 sedeče · 1,4 zmerno · 1,5 veliko hoje). */
  neat?: number | null;
  /** Beljakovine g/kg (1,6–2,2). */
  proteinGkg?: number | null;
  /** Ciljna teža. */
  targetWeightKg?: number | null;
  /** Dogodek/cilj z datumom (dirka, izziv) — načrt je makrocikel do tega dne. */
  event?: { name: string; date: string; distanceKm?: number | null } | null;
  /** Ciljni FTP na dan dogodka (W). */
  targetFtp?: number | null;
  /** Delež maščobe v %, če ga poznaš (vaga, kaliper) — sicer ocena iz BMI. */
  bodyFatPct?: number | null;
  /** Kaj imaš za na kolo (ključi iz FUEL_ITEMS); null = privzeto (domači izotonik, Frutabela, banana, gel). */
  fuelKit?: string[] | null;
  /** Kdaj običajno treniraš — za razpored obrokov. */
  trainTime?: 'zjutraj' | 'popoldne' | 'zvecer' | null;
  /** Izhodišče ob potrditvi cilja — za »na poti« in napoved. */
  goalStart?: { date: string; ftp: number | null; weightKg: number | null } | null;
  /** Začetek načrta (ponedeljek, ISO): makrocikel do dogodka ali 12-tedenski cikel brez dogodka. */
  cycleStart?: string | null;
  /** Dejanske ure na kolesu na teden ob začetku načrta (povprečje zadnjih polnih tednov) — načrt raste od tu +10 % na teden. */
  baseHours?: number | null;
  /** Kraj za vreme (opcijsko). */
  place?: { name: string; lat: number; lon: number } | null;
  /** Dnevni cilj kalorij — če ga je uporabnik ročno nastavil; sicer izračun. */
  kcalOverride?: number | null;
  /** Privolitev za AI obdelavo (GDPR). */
  aiConsentAt?: string | null;
  onboardingDone: boolean;
  createdAt: string;
  updatedAt: string;
}

export type PlanKind = 'kolo' | 'tek' | 'pohod' | 'moc' | 'pocitek' | 'test';

export interface PlanDay {
  id: string;
  /** ISO datum */
  date: string;
  kind: PlanKind;
  title: string;
  /** kratek opis, kako izvesti */
  desc: string;
  durationMin: number;
  /** ciljna cona, npr. Z2 ali C2, ali 'pogovorni tempo' */
  zone?: string | null;
  tssTarget?: number | null;
  /** za moč: seznam vaj */
  exercises?: { name: string; sets: number; reps: string; kg?: number | null }[];
  /** neobvezen dan — ne šteje v realizacijo */
  optional?: boolean;
  /** vloga v tednu: ključna seja, dolga, lahka, regeneracija, test, dirka, moč */
  role?: 'kljucna' | 'dolga' | 'lahka' | 'regen' | 'test' | 'dirka' | 'moc' | null;
  /** ciljna moč delovnih intervalov (W) */
  target?: { lo: number; hi: number } | null;
  /** kcal poraba (ocena) in vnos (cilj) */
  kcalBurn?: number | null;
  /** opravljeno: povezava na aktivnost ali ročna kljukica */
  done?: { at: string; activityId?: string | null } | null;
  /** zakaj ta dan (razlaga trenerja) */
  why?: string | null;
  source: 'rules' | 'ai';
  createdAt: string;
  updatedAt: string;
}

export interface MealEntry {
  id: string;
  date: string;          // ISO datum
  time?: string | null;  // HH:MM
  slot: 'zajtrk' | 'malica' | 'kosilo' | 'med_vadbo' | 'vecerja' | 'drugo';
  name: string;
  grams?: number | null;
  kcal: number;
  proteinG?: number | null;
  carbsG?: number | null;
  fatG?: number | null;
  confidence?: 'visoka' | 'srednja' | 'nizka' | null;
  source: 'manual' | 'photo' | 'suggest';
  thumb?: string | null; // majhna base64 sličica — SAMO lokalno
  createdAt: string;
  /** zadnja sprememba — pri združevanju naprav zmaga novejša različica */
  updatedAt?: string;
  /** vpis »Na kolesu«: popito in predlagano (ml) — iz tega se uči, koliko piješ */
  fluidMl?: number | null;
  planMl?: number | null;
  /** dan načrta, za katerega je vpis goriva */
  forDay?: string | null;
  /** vpis goriva po kosih (ključ iz FUEL_ITEMS ali 'voda' → število, bidoni po pol) — za urejanje */
  fuel?: Record<string, number> | null;
}

export interface DailyCheckin {
  date: string;
  soreness?: 1 | 2 | 3 | 4 | 5 | null;   // 1 = svež, 5 = zelo boleč
  sleepH?: number | null;
  mood?: 1 | 2 | 3 | 4 | 5 | null;
  weightKg?: number | null;
  waistCm?: number | null;
  note?: string | null;
  /** zadnja sprememba — pri združevanju naprav je novejši osnova */
  updatedAt?: string;
}

/** Test (20-min FTP, max sklece, max zgibi, deska …). Hrani se v kv 'tests'. */
export interface TestEntry {
  id: string;
  date: string;
  kind: 'ftp' | 'p5' | 'sklece' | 'zgibi' | 'deska' | 'pocep' | 'rhr';
  value: number;
  unit: string;
}

export interface WeekMenu {
  weekStart: string;
  days: { date: string; zajtrk: string; kosilo: string; malica: string; vecerja: string; kcal: number; proteinG: number }[];
  shopping: string[];
  bought: Record<number, boolean>;
  at: string;
}

export interface Settings {
  accentHex?: string;         // odtenek zelene iz dizajna
  intervals?: { athleteId: string; apiKey: string; name?: string; /** treningi za naslednjih 14 dni v koledar intervals.icu → Garmin (privzeto vklopljeno) */ pushWorkouts?: boolean } | null;
  lang: 'sl' | 'en';
  installPromptDismissedAt?: string | null;
  /** Testi (FTP, sklece, zgibi …) — v nastavitvah, da se sinhronizirajo. */
  tests?: TestEntry[];
  /** Tedenski jedilnik + nakupovalni seznam (AI). */
  menu?: WeekMenu | null;
  /** AI profil športnika (ocena iz zgodovine). */
  athleteProfile?: { at: string; type: string; summary: string; scores: Record<string, number>; strengths: string[]; weaknesses: string[]; focus: string } | null;
  /** Vodnik »Kako deluje« je bil prikazan (false = pokaži ob naslednjem odprtju Danes). */
  guideSeen?: boolean;
  /** Mesečne AI ocene po ključu YYYY-MM. */
  monthReviews?: Record<string, { at: string; text: string }>;
  /** Pogovor s trenerjem — sinhroniziran med napravami; starejši del je strnjen v povzetek (spomin trenerja). */
  coach?: { msgs: CoachMsg[]; summary?: string | null } | null;
  /** zadnja sprememba nastavitev (za združevanje naprav) */
  updatedAt?: string;
}
export interface CoachMsg { role: 'user' | 'ai'; text: string; at: string; /** posebni odgovori v istem pogovoru: nasvet za danes, pregled tedna, prilagojen teden */ kind?: 'advice' | 'review' | 'adapt' }
