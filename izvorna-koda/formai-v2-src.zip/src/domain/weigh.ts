import type { DailyCheckin } from './types'
import { PROFILE_RANGE } from './ranges'

/**
 * (v3.49) Tehtanje: tipkarska napaka (97 namesto 79) se ne shrani tiho — nad 3 kg razlike od povprečja zadnjih 7 dni
 * (ali zadnjega tehtanja, ali teže v profilu) vprašamo; napačno tehtanje se da izbrisati (Napredek → Teža).
 */
export const WEIGH_JUMP_KG = 3

const ok = (kg: unknown): kg is number => typeof kg === 'number' && Number.isFinite(kg) && kg >= PROFILE_RANGE.weight[0] && kg <= PROFILE_RANGE.weight[1]
const f1 = (x: number) => x.toFixed(1).replace('.', ',')
const days = (a: string, b: string) => Math.round((Date.parse(b + 'T12:00:00Z') - Date.parse(a + 'T12:00:00Z')) / 86400_000)

/** Zadnja tehtanja (najnovejše prvo), največ n — za seznam z izbrisom. */
export function recentWeighs(checkins: readonly Pick<DailyCheckin, 'date' | 'weightKg'>[], n = 14): { date: string; kg: number }[] {
  return checkins.filter(c => ok(c.weightKg)).map(c => ({ date: c.date, kg: c.weightKg as number })).sort((a, b) => b.date.localeCompare(a.date)).slice(0, n)
}

/** Primerjava: povprečje tehtanj v 7 dneh pred (in z) zadnjim tehtanjem do `date`, brez tehtanja tega dne. */
export function weighRef(date: string, checkins: readonly Pick<DailyCheckin, 'date' | 'weightKg'>[], profileKg?: number | null): { kg: number; label: string } | null {
  const t = checkins.filter(c => c.date !== date && c.date <= date && ok(c.weightKg)).sort((a, b) => a.date.localeCompare(b.date))
  // tehtanje za nazaj (pred vsemi drugimi): primerjaj z najbližjim kasnejšim
  const src = t.length ? t : checkins.filter(c => c.date !== date && ok(c.weightKg)).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 1)
  if (!src.length) return ok(profileKg) ? { kg: profileKg, label: 'teža v profilu' } : null
  const last = src[src.length - 1]!
  const win = src.filter(c => days(c.date, last.date) <= 6)
  if (win.length > 1) return { kg: +(win.reduce((s, c) => s + (c.weightKg as number), 0) / win.length).toFixed(1), label: 'tvoje povprečje' }
  return { kg: last.weightKg as number, label: 'zadnje tehtanje' }
}

/** Zamenjani števki (97 ↔ 79): predlog, če je obrnjena številka blizu primerjave. */
export function swappedDigits(kg: number, ref: number): number | null {
  const whole = Math.floor(kg), rest = +(kg - whole).toFixed(1)
  const s = String(whole)
  if (s.length !== 2 || s[0] === s[1]) return null
  const alt = +(+(s[1]! + s[0]!) + rest).toFixed(1)
  return Math.abs(alt - ref) <= WEIGH_JUMP_KG ? alt : null
}

/**
 * Sporočilo za potrditev, ko je novo tehtanje več kot 3 kg od primerjave:
 * »To je 17,2 kg več kot tvoje povprečje (79,8 kg) — morda 79,0 kg? Je prav?«; sicer null.
 */
export function weighJump(kg: number, date: string, checkins: readonly Pick<DailyCheckin, 'date' | 'weightKg'>[], profileKg?: number | null): string | null {
  if (!ok(kg)) return null
  const ref = weighRef(date, checkins, profileKg)
  if (!ref) return null
  const d = +(kg - ref.kg).toFixed(1)
  if (Math.abs(d) <= WEIGH_JUMP_KG) return null
  const alt = swappedDigits(kg, ref.kg)
  return `To je ${f1(Math.abs(d))} kg ${d > 0 ? 'več' : 'manj'} kot ${ref.label} (${f1(ref.kg)} kg)${alt != null ? ` — morda ${f1(alt)} kg?` : '.'} Je prav?`
}

/** Teža za profil po izbrisu tehtanja: zadnje veljavno tehtanje (null = ni nobenega). */
export function latestWeigh(checkins: readonly Pick<DailyCheckin, 'date' | 'weightKg'>[]): { date: string; kg: number } | null {
  return recentWeighs(checkins, 1)[0] ?? null
}
