import type { PlanDay } from '../types'

/**
 * (v3.52 LENO) Pravila in prikaz menstrualnega cikla — ČISTE funkcije brez odvisnosti, ki jih rabita Danes in
 * Prehrana (začetni paket). Branje Garminovega mct zapisa (MCT_FIELDS, cycleFromMct, upsertCycle) je v ./cycle,
 * ki se prenese šele z garminStore. SAMO prikaz in pravila v aplikaciji; NIKOLI v AI poziv.
 */

export type CyclePhase = 'menstrualna' | 'folikularna' | 'ovulacija' | 'lutealna'

export interface CycleDay {
  /** dan, za katerega velja zapis (lokalni ISO) */
  date: string
  /** dan v ciklu (1 = prvi dan menstruacije) */
  dayInCycle: number | null
  /** dolžina cikla (dni) — dejanska ali napovedana */
  cycleLength: number | null
  /** dolžina menstruacije (dni), če jo Garmin da */
  periodLength: number | null
  phase: CyclePhase | null
  /** Garminova napoved (ni potrjeno z vnosom) */
  predicted: boolean
  /** začetek zadnje menstruacije (ISO), če ga Garmin da */
  periodStartDate: string | null
}

/** Faza iz dneva v ciklu, če je Garmin ne pove: menstruacija (periodLength, privzeto 5), ovulacija ±1 dan okoli dolžina − 14, med njima folikularna, po njej lutealna. */
export function phaseFromDay(dayInCycle: number, cycleLength: number | null, periodLength: number | null): CyclePhase {
  const len = cycleLength && cycleLength >= 20 && cycleLength <= 45 ? cycleLength : 28
  const per = periodLength && periodLength >= 2 && periodLength <= 8 ? periodLength : 5
  if (dayInCycle <= per) return 'menstrualna'
  const ov = len - 14
  if (dayInCycle >= ov - 1 && dayInCycle <= ov + 1) return 'ovulacija'
  return dayInCycle < ov ? 'folikularna' : 'lutealna'
}

const addDays = (iso: string, n: number) => { const d = new Date(iso + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10) }
const daysBetween = (a: string, b: string) => Math.round((new Date(b + 'T12:00:00Z').getTime() - new Date(a + 'T12:00:00Z').getTime()) / 86400_000)

/**
 * Stanje cikla za dan: zapis tega dne; sicer izpeljava iz zadnjega zapisa pred njim (največ 35 dni nazaj) —
 * dan v ciklu se premakne za razliko dni (modulo dolžina cikla), oznaka `predicted: true`. Brez podatkov null.
 */
export function cycleOn(cycle: readonly CycleDay[] | null | undefined, date: string): CycleDay | null {
  if (!cycle?.length) return null
  const exact = cycle.find(c => c.date === date)
  if (exact) return exact
  const prev = [...cycle].filter(c => c.date < date && c.dayInCycle != null).sort((a, b) => b.date.localeCompare(a.date))[0]
  if (!prev) return null
  const gap = daysBetween(prev.date, date)
  if (gap > 35) return null
  const len = prev.cycleLength ?? 28
  const day = ((prev.dayInCycle! - 1 + gap) % len) + 1
  return { ...prev, date, dayInCycle: day, phase: phaseFromDay(day, prev.cycleLength, prev.periodLength), predicted: true, periodStartDate: day <= gap ? addDays(date, -(day - 1)) : prev.periodStartDate }
}

/** Pozna lutealna faza: zadnjih 5 dni cikla (dan ≥ dolžina − 4) ali lutealna faza brez znanega dneva. */
export function lateLuteal(c: CycleDay): boolean {
  if (c.phase !== 'lutealna') return false
  if (c.dayInCycle == null) return true
  return c.dayInCycle >= (c.cycleLength ?? 28) - 4
}

/** Trd dan v načrtu: ključna seja, test, Z4/Z5 ali intervalni naslov. */
export function hardDay(d: Pick<PlanDay, 'kind' | 'role' | 'zone' | 'title' | 'optional'> | null | undefined): boolean {
  if (!d || d.optional || d.kind === 'pocitek') return false
  if (d.role === 'kljucna' || d.role === 'test' || d.kind === 'test') return true
  if (d.zone && /^Z[45]$/.test(d.zone)) return true
  return /interval|vo2|prag|sweet|over.?under|30\/15|40\/20|šprint|sprint/i.test(d.title || '')
}

export interface CycleAdvice {
  /** ponudi »Olajšaj dan« (trd dan v menstrualni ali pozni lutealni fazi) */
  easeOffer: boolean
  /** opomba v prehrani (brez spreminjanja kcal) */
  nutritionNote: string | null
  /** kratka opomba za Danes/pripravljenost (zmerno, brez trditev o zdravju) */
  coachNote: string | null
  /** faza za prikaz */
  phase: CyclePhase | null
  dayInCycle: number | null
  predicted: boolean
}

export const CYCLE_TEXT = {
  ironNote: 'Več železa (meso, stročnice, zelena zelenjava) in vitamina C.',
  appetiteNote: 'Apetit je lahko večji — to je normalno, cilj ostane isti.',
  menstrualCoach: 'Menstrualna faza — če se počutiš slabše, trd dan olajšaj; lahkega ni treba spreminjati.',
  lateLutealCoach: 'Pozna lutealna faza — počutje in spanec sta lahko slabša; trd dan lahko olajšaš.',
  predicted: '(napoved)',
} as const

/**
 * Pravila cikla — čista funkcija za UI (2. val), NE za AI:
 * menstrualna ali pozna lutealna faza + trd dan → ponudi »Olajšaj dan«; prehrana: menstrualna → železo in vitamin C,
 * lutealna → apetit je lahko večji (kcal se NE spremenijo). Brez podatkov za ta dan → vse prazno.
 */
export function cycleAdvice(cycle: readonly CycleDay[] | null | undefined, day: Pick<PlanDay, 'kind' | 'role' | 'zone' | 'title' | 'optional'> | null | undefined, today: string): CycleAdvice {
  const none: CycleAdvice = { easeOffer: false, nutritionNote: null, coachNote: null, phase: null, dayInCycle: null, predicted: false }
  const c = cycleOn(cycle, today)
  if (!c || !c.phase) return none
  const sensitive = c.phase === 'menstrualna' || lateLuteal(c)
  const nap = c.predicted ? ` ${CYCLE_TEXT.predicted}` : ''
  return {
    easeOffer: sensitive && hardDay(day),
    nutritionNote: c.phase === 'menstrualna' ? CYCLE_TEXT.ironNote : c.phase === 'lutealna' ? CYCLE_TEXT.appetiteNote : null,
    coachNote: c.phase === 'menstrualna' ? CYCLE_TEXT.menstrualCoach + nap : lateLuteal(c) ? CYCLE_TEXT.lateLutealCoach + nap : null,
    phase: c.phase, dayInCycle: c.dayInCycle, predicted: c.predicted,
  }
}

/** Slovenska oznaka faze za prikaz. */
export const PHASE_LABEL: Record<CyclePhase, string> = { menstrualna: 'menstrualna faza', folikularna: 'folikularna faza', ovulacija: 'ovulacija', lutealna: 'lutealna faza' }
