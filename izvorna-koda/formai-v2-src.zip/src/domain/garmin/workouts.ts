import type { PlanDay, Profile } from '../types'
import { stepsFor, altRun, structureLines, type Step } from '../training/workout'
import { noPower } from '../training/zones'
import { lthrOf, addDays } from '../training/load'
import { inPause } from '../training/pause'
import { stableStr } from '@/data/merge'

/**
 * (v3.52) TRENING NA URO NEPOSREDNO: dan iz načrta → Garminov JSON za Training API (prek našega strežnika, ki ga
 * pošlje na POST /training-api/rest/v2/workouts in razporedi na datum). Ura ga vodi po korakih; cilji so ABSOLUTNI
 * (vati ali utrip v bpm) — relativni (% FTP, % LTHR) po izkušnjah skupnosti pristanejo kot odprt korak.
 * Čiste funkcije — omrežje je v state/store (pushGarminWorkouts) in domain/garmin/pushClient.
 *
 * [DOMNEVA] shema po skupnosti — preveri po uradnem Training API PDF (Garmin Connect Developer Program → Training API)
 * po odobritvi; uradna specifikacija ob pisanju ni bila dostopna (SPEC.md §6.2). Polja, ki jih je treba potrditi:
 *   - trening: workoutName, description, sport ('CYCLING' | 'RUNNING'), estimatedDurationInSecs, workoutProvider,
 *     workoutSourceId, steps[]
 *   - korak (type 'WorkoutStep'): stepOrder (zaporedna številka čez vse korake, tudi gnezdene), intensity
 *     ('WARMUP' | 'ACTIVE' | 'REST' | 'COOLDOWN'; alternativi po FIT: 'INTERVAL', 'RECOVERY'), description,
 *     durationType 'TIME' + durationValue (s), targetType ('POWER' W | 'HEART_RATE' bpm | 'OPEN'), targetValueLow/High
 *   - ponovitev (type 'WorkoutRepeatStep'): stepOrder, repeatType 'REPEAT_UNTIL_STEPS_CMPLT', repeatValue (N), steps[]
 *   - odgovor: { workoutId }; razpored POST …/workouts/schedule { workoutId, date } → { scheduleId }
 * Naša polja ZA STREŽNIK (strežnik jih pred pošiljanjem Garminu odstrani): uid, date, hash.
 * Vsa preslikava je v TEJ datoteki — ob drugačni uradni shemi se popravi samo tu (tipi spodaj + garminWorkout).
 */

export type GarminSport = 'CYCLING' | 'RUNNING'
export type GarminIntensity = 'WARMUP' | 'ACTIVE' | 'REST' | 'COOLDOWN'
export type GarminTargetType = 'POWER' | 'HEART_RATE' | 'OPEN'

export interface GarminWorkoutStep {
  type: 'WorkoutStep'
  stepOrder: number
  intensity: GarminIntensity
  description?: string
  durationType: 'TIME'
  /** sekunde */
  durationValue: number
  targetType: GarminTargetType
  /** W pri POWER, bpm pri HEART_RATE; pri OPEN ju ni */
  targetValueLow?: number
  targetValueHigh?: number
}
export interface GarminRepeatStep {
  type: 'WorkoutRepeatStep'
  stepOrder: number
  repeatType: 'REPEAT_UNTIL_STEPS_CMPLT'
  repeatValue: number
  steps: GarminWorkoutStep[]
}
export type GarminStep = GarminWorkoutStep | GarminRepeatStep

export interface GarminWorkout {
  /** naš ključ (formai-<datum>) — strežnik ga uporabi za garminWorkouts/{uid}/{date}; Garminu ga ne pošlje */
  uid: string
  /** YYYY-MM-DD — datum razporeda */
  date: string
  /** stabilen podpis vsebine (workoutHash) — strežnik ob enakem preskoči */
  hash: string
  workoutName: string
  description: string
  sport: GarminSport
  estimatedDurationInSecs: number
  workoutProvider: 'FORMAI'
  workoutSourceId: string
  steps: GarminStep[]
}

export const UID_PREFIX = 'formai-'
export const uidFor = (date: string) => `${UID_PREFIX}${date}`
/** Največ znakov imena treninga (Garminova meja ni objavljena; ura prikaže ~30). */
export const NAME_MAX = 80
export const NAME_PREFIX = 'FORMAI · '

/** Cone utripa po LTHR — iste kot intervals.icu izvoz (Z1 60–80 %, Z2 81–89, Z3 90–93, Z4 94–100, Z5 100–108, test 95–105). */
const HRP: Record<string, [number, number]> = { Z1: [0.60, 0.80], Z2: [0.81, 0.89], Z3: [0.90, 0.93], Z4: [0.94, 1.00], Z5: [1.00, 1.08], max: [0.95, 1.05] }
/** Cone moči (Coggan) kot delež FTP — iste kot intervals.icu izvoz. */
const PWP: Record<string, [number, number]> = { Z1: [0.45, 0.55], Z2: [0.56, 0.75], Z3: [0.76, 0.90], Z4: [0.91, 1.05], Z5: [1.06, 1.20], max: [1.00, 1.10] }

type Target = Pick<GarminWorkoutStep, 'targetType' | 'targetValueLow' | 'targetValueHigh'>
const range = (type: Exclude<GarminTargetType, 'OPEN'>, lo: number, hi: number): Target => ({ targetType: type, targetValueLow: Math.round(Math.min(lo, hi)), targetValueHigh: Math.round(Math.max(lo, hi)) })
const OPEN: Target = { targetType: 'OPEN' }

/** Cilj koraka: vati (kolo z merilnikom in FTP), sicer utrip v bpm iz pražnega utripa; brez obojega odprt korak. */
function targetOf(s: Step, day: PlanDay, p: Profile, sport: GarminSport): Target {
  const z = s.z || (s.kind === 'delo' ? 'Z2' : 'Z1')
  const hr = sport === 'RUNNING' || noPower(p) || !p.ftp
  if (!hr) {
    const f = p.ftp!
    // vati iz opisa seje (delež FTP) — tudi za šprinte in bloke v Z2 vožnji, ki nimajo cilja dneva
    if (s.kind === 'delo' && s.ftpShare) return range('POWER', f * s.ftpShare[0], f * s.ftpShare[1])
    if (s.kind === 'delo' && s.sets && day.target) return range('POWER', day.target.lo, day.target.hi)
    // šprint »vse, kar gre«: vsaj 150 % FTP (ura naj ne piska pri 110 %)
    if (s.kind === 'delo' && s.z === 'max') return range('POWER', f * 1.5, f * 3)
    const [lo, hi] = PWP[z] ?? PWP.Z2!
    return range('POWER', f * lo, f * hi)
  }
  const L = lthrOf(p)
  if (!L) return OPEN
  const [lo, hi] = HRP[z] ?? HRP.Z2!
  return range('HEART_RATE', L * lo, L * hi)
}

const cap = (t: string) => t.charAt(0).toUpperCase() + t.slice(1)
/** Kratko ime koraka za uro (brez številke ponovitve »3/5«). */
const cue = (s: Step): string => s.kind === 'ogrevanje' ? 'Ogrevanje' : s.kind === 'iztek' ? 'Iztek' : s.kind === 'test' ? 'Test' : cap((s.label || '').replace(/\s*\d+\/\d+$/, '').trim()) || (s.kind === 'lahko' ? 'Lahko' : 'Vožnja')
const intensityOf = (s: Step): GarminIntensity => s.kind === 'ogrevanje' ? 'WARMUP' : s.kind === 'iztek' ? 'COOLDOWN' : s.kind === 'lahko' ? 'REST' : 'ACTIVE'

/** Šport za Garmin: kolo in test → CYCLING, tek → RUNNING; moč (katalog vaj ni potrjen), hoja, počitek → null. */
export function garminSportOf(day: Pick<PlanDay, 'kind'>): GarminSport | null {
  if (day.kind === 'kolo' || day.kind === 'test') return 'CYCLING'
  if (day.kind === 'tek') return 'RUNNING'
  return null
}

/** Ime treninga: »FORMAI · <naslov>«, ≤ NAME_MAX znakov (ime je edino, kar se pri Garminu ohrani — po njem ujemamo). */
export function workoutNameOf(title: string): string {
  const t = (title || 'Trening').replace(/\s+/g, ' ').trim()
  const full = NAME_PREFIX + t
  return full.length <= NAME_MAX ? full : full.slice(0, NAME_MAX - 1).trimEnd() + '…'
}

/**
 * Dan iz načrta kot trening za uro; null za počitek, moč, pohod, dirko in dneve brez korakov.
 * Ponovitve (vsaka serija posebej) so blok WorkoutRepeatStep z delom in odmorom; ura naredi tudi odmor za zadnjo
 * ponovitvijo, zato se ta odšteje od naslednjega lahkega koraka (»carry«) — trening na uri traja toliko kot v načrtu.
 */
export function garminWorkout(day: PlanDay, p: Profile): GarminWorkout | null {
  const sport = garminSportOf(day)
  if (!sport || day.role === 'dirka' || day.raceId) return null
  const steps = stepsFor(day, p).filter(s => s.kind !== 'pavza')
  if (!steps.length || steps.some(s => s.kind === 'vaja' || !(s.sec > 0))) return null
  const out: GarminStep[] = []
  let order = 0, total = 0, carry = 0
  const T = (s: Step, sec: number, intensity = intensityOf(s)): GarminWorkoutStep => ({ type: 'WorkoutStep', stepOrder: ++order, intensity, description: cue(s), durationType: 'TIME', durationValue: sec, ...targetOf(s, day, p, sport) })
  // del iste serije: naslednja ponovitev (set > 1) ali odmor pred njo — nova serija ali nov blok začne s set = 1
  const sameBlock = (k: number) => { const n = steps[k], m = steps[k + 1]; return !!n && ((n.kind === 'delo' && (n.set ?? 0) > 1) || (n.kind === 'lahko' && m?.kind === 'delo' && (m.set ?? 0) > 1)) }
  for (let i = 0; i < steps.length; i++) {
    const s = steps[i]!
    // over-under: serija je blok z dvema deloma (pod in nad pragom) brez odmora
    const alt = altRun(steps, i)
    if (alt) {
      const o = steps[i + 1]!
      const rep: GarminRepeatStep = { type: 'WorkoutRepeatStep', stepOrder: ++order, repeatType: 'REPEAT_UNTIL_STEPS_CMPLT', repeatValue: s.sets!, steps: [] }
      rep.steps.push(T(s, s.sec, 'ACTIVE'), T(o, o.sec, 'ACTIVE'))
      out.push(rep)
      total += s.sets! * (s.sec + o.sec)
      i += alt - 1
      continue
    }
    if (s.kind === 'delo' && s.sets && s.sets > 1 && s.set === 1 && steps[i + 1]?.kind === 'lahko') {
      const rest = steps[i + 1]!
      let j = i
      while (j + 1 < steps.length && sameBlock(j + 1)) j++
      const next = steps[j + 1]
      if (next && (next.kind === 'lahko' || (next.kind === 'iztek' && next.sec > carry + rest.sec))) {
        const rep: GarminRepeatStep = { type: 'WorkoutRepeatStep', stepOrder: ++order, repeatType: 'REPEAT_UNTIL_STEPS_CMPLT', repeatValue: s.sets, steps: [] }
        rep.steps.push(T(s, s.sec, 'ACTIVE'), T(rest, rest.sec, 'REST'))
        out.push(rep)
        total += s.sets * (s.sec + rest.sec)
        carry += rest.sec
      } else {
        // blok tik pred kratkim iztekom: posamezni koraki (brez odmora za zadnjo ponovitvijo)
        for (let k = i; k <= j; k++) { const x = steps[k]!; out.push(T(x, x.sec)); total += x.sec }
      }
      i = j
      continue
    }
    let sec = s.sec
    // odmor za zadnjo ponovitvijo bloka je že na uri: naslednji lahki korak (ali iztek) je toliko krajši
    if (carry && (s.kind === 'lahko' || s.kind === 'iztek')) {
      if (sec > carry) { sec -= carry; carry = 0 } else if (s.kind === 'lahko') { carry -= sec; sec = 0 }
    }
    if (!sec) continue
    out.push(T(s, sec))
    total += sec
  }
  if (!out.length) return null
  const description = descriptionOf(steps)
  const w: Omit<GarminWorkout, 'hash'> = {
    uid: uidFor(day.date), date: day.date,
    workoutName: workoutNameOf(day.title), description, sport, estimatedDurationInSecs: total,
    workoutProvider: 'FORMAI', workoutSourceId: uidFor(day.date), steps: out,
  }
  return { ...w, hash: workoutHash(w) }
}

/** Kratek slovenski opis (struktura seje), ≤ 500 znakov. */
export function descriptionOf(steps: readonly Step[]): string {
  const t = structureLines(steps).join(' · ').replace(/\s+/g, ' ').trim()
  return t.length <= 500 ? t : t.slice(0, 499).trimEnd() + '…'
}

/** Stabilen podpis vsebine treninga (brez hash, uid, date in workoutSourceId, ki je iz datuma): djb2 nad urejenim JSON, 8 šestnajstiških znakov. */
export function workoutHash(w: Omit<GarminWorkout, 'hash' | 'uid' | 'date'> & Partial<Pick<GarminWorkout, 'hash' | 'uid' | 'date'>>): string {
  const { hash: _h, uid: _u, date: _d, workoutSourceId: _s, ...rest } = w
  const s = stableStr(rest)
  let h = 5381
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0
  return h.toString(16).padStart(8, '0')
}

/**
 * Treningi za uro: dnevi od today naprej (days dni), en trening na dan — brez počitka, dirke, opravljenih dni in dni
 * premora (tudi če načrt še ni prestavljen: »brez treningov« vzame vse, »brez kolesa« kolo in test).
 * Če sta na isti dan dva (moč + kolo, tek + kolo), ima prednost kolo/test, nato tek.
 */
export function garminWorkoutsFor(plan: readonly PlanDay[], p: Profile, today: string, days = 14): GarminWorkout[] {
  const cand = garminCandidates(plan, p, today, days)
  const out: GarminWorkout[] = []
  const seen = new Set<string>()
  for (const d of cand) {
    if (seen.has(d.date)) continue
    const g = garminWorkout(d, p)
    if (!g) continue
    seen.add(d.date); out.push(g)
  }
  return out
}
/** Dan premora: »brez treningov« vzame vse, »brez kolesa« kolo in test. */
export function garminPaused(p: Pick<Profile, 'weekPause'>, d: Pick<PlanDay, 'date' | 'kind'>): boolean {
  const w = p.weekPause
  return !!w && inPause(p, d.date) && (w.mode === 'vse' || d.kind === 'kolo' || d.kind === 'test')
}
/** Dnevi načrta, ki gredo na uro (okno, brez počitka/dirke/opravljenih/premora, šport za uro), urejeni po datumu in prednosti. */
function garminCandidates(plan: readonly PlanDay[], p: Profile, today: string, days: number): PlanDay[] {
  const to = addDays(today, Math.max(1, days) - 1)
  const rank = (d: PlanDay) => (d.kind === 'kolo' || d.kind === 'test' ? 0 : d.kind === 'tek' ? 1 : 2)
  return plan
    .filter(d => d.date >= today && d.date <= to && !d.done && d.kind !== 'pocitek' && d.role !== 'dirka' && !d.raceId && !garminPaused(p, d) && garminSportOf(d))
    .sort((a, b) => a.date.localeCompare(b.date) || rank(a) - rank(b))
}
/**
 * (v3.52 popravki) Id-ji dni, ki so na uri — natanko tisti, ki jih garminWorkoutsFor pošlje (okno `days` dni od today,
 * brez dni premora, en trening na dan). Za oznako »na uri« v Planu: dan čez 14 dni ali v premoru je ne dobi.
 */
export function onGarminWatchIds(plan: readonly PlanDay[], p: Profile, today: string, days = 14): Set<string> {
  const out = new Set<string>()
  const seen = new Set<string>()
  for (const d of garminCandidates(plan, p, today, days)) {
    if (seen.has(d.date)) continue
    if (!garminWorkout(d, p)) continue
    seen.add(d.date); out.add(d.id)
  }
  return out
}
