import { PROXY } from '@/config'
import { idToken } from '@/data/firebase'
import type { GarminWorkout } from './workouts'
import type { GarminCourse } from './course'
import { todayIso } from '../training/load'

/**
 * (v3.52) Klici našega strežnika za pošiljanje NA Garmin (treningi, trase). Strežnik ima žetone in govori z Garminom;
 * aplikacija pošlje samo naš JSON s Firebase ID žetonom. Napake so slovenske in nikoli tihe (napačna shema pri
 * Garminu → `errors[]` po dnevih oz. izjema GarminPushError z besedilom za obvestilo).
 * Dogovor s strežnikom: IMPL-BRIEF.md »Strežniški API« (PUT/DELETE /garmin/workouts, PUT /garmin/course).
 */

export interface GarminPushResult { created: number; updated: number; skipped: number; removed: number; errors: { date: string; error: string }[] }
export interface GarminCourseResult { courseId: string | number }

export class GarminPushError extends Error {
  constructor(public code: string, public status: number, msg: string) { super(msg); this.name = 'GarminPushError' }
}

/** Največ treningov v enem klicu (strežnik sprejme do 14). */
export const PUSH_MAX = 14

/** Koda strežnika → slovensko besedilo za obvestilo. */
export function garminErrorText(code: string | null | undefined, status: number): string {
  switch (code) {
    case 'prijava_potrebna': return 'Za pošiljanje na Garmin se prijavi (Google).'
    case 'ni_povezave': return 'Garmin ni povezan — poveži ga v Nastavitvah.'
    case 'garmin_ni_nastavljen': return 'Povezava z Garminom na strežniku še ni nastavljena.'
    case 'garmin_401': case 'garmin_403': return 'Garmin je zavrnil dostop — poveži Garmin znova.'
    case 'garmin_429': return 'Garmin trenutno sprejme preveč zahtev — poskusi čez nekaj minut.'
    // (v3.52 popravki) kode strežnika, ki prej niso imele besedila (»strežnik 409«)
    case 'povezava_prekinjena': return 'Garmin je prekinil povezavo — poveži znova.'
    case 'ni_dovoljenja': return 'Garmin za ta račun ne deli teh podatkov — v Garmin Connect preveri dovoljenja za FORMAI.'
    case 'prevec_klicev': return 'Preveč zahtevkov na Garmin — poskusi čez minuto.'
    case 'prevec_treningov': return `Preveč treningov v enem pošiljanju (največ ${PUSH_MAX}).`
    case 'neveljavno': return 'Garmin je trening zavrnil kot neveljaven — oblika treninga še ni usklajena z Garminom.'
    default:
      if (code && /^garmin_\d+$/.test(code)) return `Garmin je zavrnil trening (napaka ${code.slice(7)}) — morda oblika treninga še ni usklajena z Garminom.`
      if (status === 0) return 'Pošiljanje na Garmin ni uspelo — ni omrežja?'
      return `Pošiljanje na Garmin ni uspelo (strežnik ${status}).`
  }
}

async function call<T>(path: string, method: 'PUT' | 'DELETE', body?: unknown, fetchImpl: typeof fetch = fetch): Promise<T> {
  const t = await idToken().catch(() => null)
  if (!t) throw new GarminPushError('prijava_potrebna', 401, garminErrorText('prijava_potrebna', 401))
  let r: Response
  try {
    r = await fetchImpl(`${PROXY}${path}`, { method, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${t}` }, ...(body !== undefined ? { body: JSON.stringify(body) } : {}) })
  } catch { throw new GarminPushError('omrezje', 0, garminErrorText(null, 0)) }
  const d = await r.json().catch(() => ({})) as Record<string, unknown>
  if (!r.ok) { const code = typeof d.error === 'string' ? d.error : 'napaka'; throw new GarminPushError(code, r.status, garminErrorText(code, r.status)) }
  return d as T
}

/**
 * Pošlji treninge (do PUSH_MAX) — strežnik primerja hash, ustvari/posodobi/pobriše pri Garminu in razporedi na datume.
 * (v3.52 popravki) `today` = LOKALNI datum uporabnika: strežnik po njem briše dni ≥ danes (UTC datum bi ob 00:30 pri nas
 * še bil »včeraj« in bi pobrisal včerajšnji trening oz. pustil današnjega).
 */
export async function putGarminWorkouts(workouts: readonly GarminWorkout[], fetchImpl?: typeof fetch, today: string = todayIso()): Promise<GarminPushResult> {
  const d = await call<Partial<GarminPushResult>>('/garmin/workouts', 'PUT', { workouts: workouts.slice(0, PUSH_MAX), today }, fetchImpl)
  return { created: +(d.created ?? 0), updated: +(d.updated ?? 0), skipped: +(d.skipped ?? 0), removed: +(d.removed ?? 0), errors: Array.isArray(d.errors) ? d.errors.map(e => ({ date: String(e?.date ?? ''), error: String(e?.error ?? 'napaka') })) : [] }
}

/** Pobriši vse naše prihodnje treninge pri Garminu (izklop, odklop, premor brez treningov); `today` = lokalni datum (glej putGarminWorkouts). */
export async function deleteGarminWorkouts(fetchImpl?: typeof fetch, today: string = todayIso()): Promise<number> {
  const d = await call<{ removed?: number }>(`/garmin/workouts?today=${encodeURIComponent(today)}`, 'DELETE', undefined, fetchImpl)
  return +(d.removed ?? 0)
}

/** Pošlji traso (Courses API) — vrne courseId pri Garminu. */
export async function putGarminCourse(course: GarminCourse, fetchImpl?: typeof fetch): Promise<GarminCourseResult> {
  const d = await call<{ courseId?: string | number }>('/garmin/course', 'PUT', { course }, fetchImpl)
  if (d.courseId == null) throw new GarminPushError('napaka', 200, 'Garmin trase ni sprejel (brez courseId).')
  return { courseId: d.courseId }
}
