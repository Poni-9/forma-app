import { mergeWellness, type WellnessDay } from '../wellness'

/**
 * (v3.52) Garmin Connect neposredno — ZDRAVJE (Health API: dailies, sleeps, hrv, stressDetails) → WellnessDay.
 * Zdravstveni podatki: samo ob izrecnem vklopu (settings.garmin.health), samo na napravi, v AI nikoli surovi
 * (gredo le prek recoveryOf → pripravljenost, kot do zdaj pri intervals.icu).
 * Polja po SPEC §4 (dailies [URADNO-STARO], ostalo [POSREDNO]) — vsa neobvezna; neznano se preskoči, nič se ne sesuje.
 */

export interface GarminDaily {
  summaryId?: string; calendarDate?: string; durationInSeconds?: number
  restingHeartRateInBeatsPerMinute?: number
  averageStressLevel?: number; maxStressLevel?: number
  /** (v3.52 popravki) zapis pokriva šele del dneva — povprečni stres še ni dnevni */
  partial?: boolean
  /** [DOMNEVA] Body Battery v dailies — MyDataHelps jih ne našteva; zanesljiv vir je stressDetails */
  bodyBatteryHighestValue?: number; bodyBatteryLowestValue?: number
  steps?: number; t?: number; [k: string]: unknown
}
export interface GarminSleep {
  summaryId?: string; calendarDate?: string
  startTimeInSeconds?: number; startTimeOffsetInSeconds?: number
  /** spanec brez budnosti in nemerljivega */
  durationInSeconds?: number
  deepSleepDurationInSeconds?: number; lightSleepDurationInSeconds?: number
  /** pozor: remSleepInSeconds, ne remSleepDurationInSeconds (SPEC §4.2) */
  remSleepInSeconds?: number; awakeDurationInSeconds?: number
  validation?: string
  overallSleepScore?: { value?: number; qualifierKey?: string } | null
  t?: number; [k: string]: unknown
}
export interface GarminHrv {
  summaryId?: string; calendarDate?: string
  startTimeInSeconds?: number; startTimeOffsetInSeconds?: number
  /** nočni HRV (ms) */
  lastNightAvg?: number; lastNight5MinHigh?: number
  t?: number; [k: string]: unknown
}
/**
 * stressDetails, oklešteni na strežniku: brez seznamov, samo izpeljanke Body Battery in povprečni stres.
 * (v3.52 popravki) Dogovor s strežnikom: `bodyBatteryAtWake` = vrednost ob koncu spanca (strežnik jo izpelje iz
 * bodyBatteryActivityEvents RECOVERY, sicer je ni), `partial` = zapis pokriva šele del dneva (sinhronizacija sredi dneva).
 */
export interface GarminStress {
  summaryId?: string; calendarDate?: string
  startTimeInSeconds?: number; startTimeOffsetInSeconds?: number; durationInSeconds?: number
  averageStressLevel?: number
  bodyBatteryMax?: number; bodyBatteryMin?: number; bodyBatteryAtWake?: number; bodyBatteryLast?: number
  partial?: boolean
  t?: number; [k: string]: unknown
}
export interface GarminHealth {
  dailies?: GarminDaily[]; sleeps?: GarminSleep[]; hrv?: GarminHrv[]; stress?: GarminStress[]
  bodyComps?: unknown[]; userMetrics?: unknown[]
}

const num = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) ? v : null)
const pos = (v: unknown): number | null => { const n = num(v); return n != null && n > 0 ? n : null }
const isDate = (s: unknown): s is string => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s)
const localDate = (startSec: number, offsetSec: number | null | undefined) => new Date((startSec + (offsetSec || 0)) * 1000).toISOString().slice(0, 10)

/** Dan zapisa: calendarDate; brez njega lokalni datum začetka (+ pri spancu trajanje → jutro, ko se zbudiš). */
function dayOf(r: { calendarDate?: string; startTimeInSeconds?: number; startTimeOffsetInSeconds?: number }, addSec = 0): string | null {
  if (isDate(r.calendarDate)) return r.calendarDate
  const s = pos(r.startTimeInSeconds)
  return s ? localDate(s + addSec, num(r.startTimeOffsetInSeconds)) : null
}
/** Isti dan pride večkrat (sinhronizacija sredi dneva): obvelja zapis z najdaljšim trajanjem, ob enakem novejši (t). */
function latest<T extends { durationInSeconds?: number; t?: number }>(list: readonly T[], key: (r: T) => string | null): Map<string, T> {
  const out = new Map<string, T>()
  for (const r of list) {
    const k = key(r); if (!k) continue
    const cur = out.get(k)
    if (!cur) { out.set(k, r); continue }
    const d1 = num(cur.durationInSeconds) ?? 0, d2 = num(r.durationInSeconds) ?? 0
    if (d2 > d1 || (d2 === d1 && (num(r.t) ?? 0) >= (num(cur.t) ?? 0))) out.set(k, r)
  }
  return out
}

/**
 * Ali zapis pokriva CEL dan: strežnik pove s `partial: false`; brez te oznake (starejši strežnik) šteje zapis z
 * trajanjem celega dneva (86 400 s). Delni dan (sinhronizacija zjutraj: večinoma spanec) bi dal lažno nizek stres.
 */
export const wholeDay = (r: { partial?: boolean; durationInSeconds?: number } | null | undefined): boolean =>
  !!r && (r.partial === false || (r.partial == null && (num(r.durationInSeconds) ?? 0) >= 86_400))

/**
 * Health zapisi → dnevi. Spanec je pripisan jutru (calendarDate pri sleeps je dan prebujanja), nočni HRV prav tako;
 * mirovni utrip iz dailies; stres = povprečni stres dneva (−1 = ni → null) SAMO iz zapisov za cel dan (današnji delni
 * dan ne šteje — pripravljenost vzame včerajšnji); Body Battery = ob prebujanju (bodyBatteryAtWake, bbAtWake: true),
 * sicer najvišji v dnevu (stressDetails), sicer dailies.bodyBatteryHighestValue [DOMNEVA]. Dnevi brez podatkov se izpustijo.
 */
export function wellnessFromGarmin(h: GarminHealth | null | undefined): WellnessDay[] {
  if (!h) return []
  const dailies = latest(Array.isArray(h.dailies) ? h.dailies : [], r => dayOf(r))
  // spanec: calendarDate je jutro; brez njega konec spanca (start + trajanje) v lokalnem času; začasni (TENTATIVE) štejejo, končni jih zamenjajo
  const sleeps = latest(Array.isArray(h.sleeps) ? h.sleeps : [], r => dayOf(r, num(r.durationInSeconds) ?? 0))
  const hrv = latest(Array.isArray(h.hrv) ? h.hrv : [], r => dayOf(r, num(r.durationInSeconds) ?? 0))
  const stress = latest(Array.isArray(h.stress) ? h.stress : [], r => dayOf(r))
  const days = new Set<string>([...dailies.keys(), ...sleeps.keys(), ...hrv.keys(), ...stress.keys()])
  const out: WellnessDay[] = []
  for (const date of [...days].sort()) {
    const d = dailies.get(date), s = sleeps.get(date), v = hrv.get(date), st = stress.get(date)
    const secs = s ? pos(s.durationInSeconds) : null
    const score = s?.overallSleepScore ? num(s.overallSleepScore.value) : null
    const avgStress = (wholeDay(st) ? pos(st?.averageStressLevel) : null) ?? (wholeDay(d) ? pos(d?.averageStressLevel) : null)
    const atWake = num(st?.bodyBatteryAtWake)
    const bb = atWake ?? num(st?.bodyBatteryMax) ?? num(d?.bodyBatteryHighestValue)
    const w: WellnessDay = {
      date,
      sleepH: secs ? Math.round((secs / 3600) * 10) / 10 : null,
      sleepScore: score != null && score >= 0 && score <= 100 ? Math.round(score) : null,
      hrv: v && pos(v.lastNightAvg) != null ? Math.round(pos(v.lastNightAvg)! * 10) / 10 : null,
      rhr: d && pos(d.restingHeartRateInBeatsPerMinute) != null ? Math.round(pos(d.restingHeartRateInBeatsPerMinute)!) : null,
    }
    if (avgStress != null && avgStress <= 100) w.stress = Math.round(avgStress)
    if (bb != null && bb >= 0 && bb <= 100) { w.bodyBattery = Math.round(bb); if (atWake != null) w.bbAtWake = true }
    if (w.sleepH == null && w.sleepScore == null && w.hrv == null && w.rhr == null && w.stress == null && w.bodyBattery == null) continue
    out.push(w)
  }
  return out
}

// (v3.52 LENO) mergeWellness je v ../wellness (rabi ga že začetni paket: combinedWellness v store) — tu re-export za obstoječe uvoze
export { mergeWellness } from '../wellness'

/** Novi dnevi z Garmina čez shranjene (isti datum → novi); obdrži zadnjih `keep` dni. */
export function upsertWellnessDays(prev: readonly WellnessDay[] | null | undefined, fresh: readonly WellnessDay[], keep = 60): WellnessDay[] {
  const all = mergeWellness(prev, fresh)
  return all.length > keep ? all.slice(all.length - keep) : all
}
