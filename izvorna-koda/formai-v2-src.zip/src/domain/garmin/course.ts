import type { RouteRec } from '../routes/analyze'
import { decodePolyline, haversineM, type LatLon } from '../import/polyline'

/**
 * (v3.52) TRASA NA URO NEPOSREDNO: trasa iz knjižnice (RouteRec: kodirana sled ~40 m + višine na 50 m) → Garminov JSON
 * za Courses API (prek našega strežnika, PUT /garmin/course). Garmin trase na napravi loči PO IMENU, zato ima ime
 * unikaten konec (datum). Čiste funkcije — omrežje je v state/store (pushGarminCourse).
 *
 * [DOMNEVA] shema po skupnosti — preveri po uradnem Courses API PDF po odobritvi (SPEC.md §7). Polja, ki jih je treba
 * potrditi: courseName, description, distanceInMeters, elevationGainInMeters, coordinateSystem ('WGS84'),
 * activityType ('ROAD_CYCLING' — možno tudi 'CYCLING'), geoPoints[] { latitude, longitude, elevation }, največje
 * število točk (tu ≤ 2 000), odgovor { courseId }. Vsa preslikava je v TEJ datoteki.
 */

export interface GarminGeoPoint { latitude: number; longitude: number; elevation?: number }
export interface GarminCourse {
  courseName: string
  description?: string
  distanceInMeters: number
  elevationGainInMeters: number
  coordinateSystem: 'WGS84'
  activityType: 'ROAD_CYCLING'
  geoPoints: GarminGeoPoint[]
}

/** Največ točk v trasi (meja ni objavljena; FIT trase so tipično 20–55 kB). */
export const COURSE_MAX_POINTS = 2000
export const COURSE_NAME_MAX = 60
/** korak profila višin v RouteRec.prof (m) — kot analyze.ts STEP_M */
const PROF_STEP_M = 50

/** Enakomerno razredčenje na največ max točk; prva in zadnja ostaneta. */
export function thinEven<T>(pts: readonly T[], max = COURSE_MAX_POINTS): T[] {
  if (pts.length <= max) return [...pts]
  const out: T[] = []
  const n = Math.max(2, max)
  for (let k = 0; k < n; k++) out.push(pts[Math.round((k * (pts.length - 1)) / (n - 1))]!)
  return out
}

/** Ime trase: »FORMAI · <ime> · <d. m.>« ≤ COURSE_NAME_MAX znakov — ime je ključ pri Garminu, datum ga naredi unikatnega. */
export function courseNameOf(name: string, date: string): string {
  const suffix = ` · ${+date.slice(8, 10)}. ${+date.slice(5, 7)}.`
  const base = 'FORMAI · '
  const room = COURSE_NAME_MAX - base.length - suffix.length
  let n = (name || 'Trasa').replace(/\s+/g, ' ').trim()
  if (n.length > room) n = n.slice(0, Math.max(1, room - 1)).trimEnd() + '…'
  return base + n + suffix
}

/**
 * Trasa za Garmin: točke iz kodirane sledi, višina iz profila (vsakih 50 m, linearno), razdalja iz sledi (ali rec.km),
 * vzpon rec.gainM. null, če sled nima vsaj dveh točk.
 */
export function garminCourse(rec: Pick<RouteRec, 'poly' | 'prof' | 'km' | 'gainM' | 'name'>, date: string, name = rec.name): GarminCourse | null {
  const raw = decodePolyline(rec.poly || '')
  if (raw.length < 2) return null
  // kumulativna razdalja po celi sledi (za višino in dolžino), nato razredčenje po indeksih
  const cum = [0]
  for (let i = 1; i < raw.length; i++) cum.push(cum[i - 1]! + haversineM(raw[i - 1]!, raw[i]!))
  const total = cum[cum.length - 1]!
  const prof = rec.prof || []
  const elevAt = (m: number): number | null => {
    if (!prof.length) return null
    const x = m / PROF_STEP_M, i = Math.min(prof.length - 1, Math.floor(x)), j = Math.min(prof.length - 1, i + 1)
    const t = x - i
    return Math.round((prof[i]! + (prof[j]! - prof[i]!) * Math.max(0, Math.min(1, t))) * 10) / 10
  }
  const geoPoints: GarminGeoPoint[] = thinEven(raw.map((_, i) => i), COURSE_MAX_POINTS).map(i => {
    const p: LatLon = raw[i]!, e = elevAt(cum[i]!)
    return { latitude: +p[0].toFixed(6), longitude: +p[1].toFixed(6), ...(e != null ? { elevation: e } : {}) }
  })
  const dist = total > 0 ? Math.round(total) : Math.round((rec.km || 0) * 1000)
  return {
    courseName: courseNameOf(name, date),
    description: `Trasa iz FORMAI za ${+date.slice(8, 10)}. ${+date.slice(5, 7)}. ${date.slice(0, 4)} — ${(rec.km || dist / 1000).toFixed(1).replace('.', ',')} km, ${Math.round(rec.gainM || 0)} m vzpona.`,
    distanceInMeters: dist,
    elevationGainInMeters: Math.max(0, Math.round(rec.gainM || 0)),
    coordinateSystem: 'WGS84',
    activityType: 'ROAD_CYCLING',
    geoPoints,
  }
}
