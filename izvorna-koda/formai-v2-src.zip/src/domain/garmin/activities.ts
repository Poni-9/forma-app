import type { Activity, Profile, Sport } from '../types'
import { deriveFlags } from '../import/provenance'
import { autoName } from '../import/autoName'
import { estimateTss } from '../training/load'

/**
 * (v3.52) Garmin Connect neposredno — AKTIVNOSTI.
 * Garminov povzetek (Activity API, push na naš strežnik, polja 1:1 po SPEC §3.1) + podrobnosti, ki jih strežnik
 * izračuna iz vzorcev (activityDetails: povprečna moč, NP, max utrip, kadenca, polilinija) → naša Activity.
 * Vir 'garmin' (uporabnikovi podatki, AI dovoljen), originHint 'GARMIN_API' (ročno vnesena 'GARMIN_API_MANUAL'),
 * deviceName iz povzetka (pripis »Garmin [model]« je pogoj Garmina).
 */

/** Podrobnosti, ki jih strežnik izpelje iz activityDetails.samples (vzorcev ne hrani). */
export interface GarminDetails {
  avgWatts?: number | null
  /** normalizirana moč (30 s drseče povprečje, ^4, povprečje, ^0,25) */
  np?: number | null
  maxHr?: number | null
  avgCadence?: number | null
  elevGain?: number | null
  /** Google encoded polyline (≤ 2 000 točk) */
  polyline?: string | null
  hrZoneSec?: number[] | null
}

/** Zapis s strežnika (GET /garmin/activities): Garminov povzetek + details? + t (ms prejema na strežniku). */
export interface GarminActivityRec {
  summaryId?: string
  activityId?: string | number
  activityName?: string
  activityDescription?: string
  activityType?: string
  startTimeInSeconds?: number
  startTimeOffsetInSeconds?: number
  durationInSeconds?: number
  distanceInMeters?: number
  activeKilocalories?: number
  deviceName?: string
  averageHeartRateInBeatsPerMinute?: number
  maxHeartRateInBeatsPerMinute?: number
  averageSpeedInMetersPerSecond?: number
  totalElevationGainInMeters?: number
  averageBikeCadenceInRoundsPerMinute?: number
  isParent?: boolean
  parentSummaryId?: string | number
  manual?: boolean
  details?: GarminDetails | null
  t?: number
  [k: string]: unknown
}

const num = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) ? v : typeof v === 'string' && v.trim() !== '' && Number.isFinite(+v) ? +v : null)
const pos = (v: unknown): number | null => { const n = num(v); return n != null && n > 0 ? n : null }

/**
 * Garminov activityType (SPEC §3.5: prost niz, velike črke s podčrtaji; uradni seznam ni javen) → naš šport.
 * Najprej znane vrednosti, nato varovalka po delih besede (BIK/CYCL/RIDE → kolo, RUN → tek …), sicer 'drugo'.
 * indoor: trenažer / tekalna steza / notranje kolo.
 */
export function garminSport(activityType: string | null | undefined): { sport: Sport; indoor: boolean } {
  const t = String(activityType || '').toUpperCase().trim()
  const indoor = /INDOOR|VIRTUAL|TREADMILL|TRAINER/.test(t)
  if (!t) return { sport: 'drugo', indoor: false }
  if (/^(CYCLING|ROAD_BIKING|GRAVEL_CYCLING|MOUNTAIN_BIKING|VIRTUAL_RIDE|INDOOR_CYCLING|CYCLOCROSS|TRACK_CYCLING|BMX|E_BIKE_FITNESS|E_BIKE_MOUNTAIN|E_ENDURO_MTB|ENDURO_MTB|DOWNHILL_BIKING|RECUMBENT_CYCLING|BIKE_COMMUTE|HAND_CYCLING|INDOOR_HAND_CYCLING)$/.test(t)) return { sport: 'kolo', indoor }
  if (/^(RUNNING|TRAIL_RUNNING|TREADMILL_RUNNING|TRACK_RUNNING|INDOOR_RUNNING|VIRTUAL_RUN|OBSTACLE_RUN|STREET_RUNNING|ULTRA_RUN)$/.test(t)) return { sport: 'tek', indoor }
  if (/^(WALKING|HIKING|CASUAL_WALKING|SPEED_WALKING|INDOOR_WALKING|MOUNTAINEERING)$/.test(t)) return { sport: 'pohod', indoor }
  if (/^(STRENGTH_TRAINING|FITNESS_EQUIPMENT|INDOOR_CARDIO|CARDIO_TRAINING|YOGA|PILATES|HIIT|ELLIPTICAL|STAIR_CLIMBING|INDOOR_ROWING|BREATHWORK)$/.test(t)) return { sport: 'moc', indoor }
  if (/^(SWIMMING|LAP_SWIMMING|OPEN_WATER_SWIMMING)$/.test(t)) return { sport: 'plavanje', indoor }
  // varovalka po delih besede (nove ali neznane vrednosti)
  if (/BIK|CYCL|RIDE/.test(t)) return { sport: 'kolo', indoor }
  if (/RUN/.test(t)) return { sport: 'tek', indoor }
  if (/WALK|HIK/.test(t)) return { sport: 'pohod', indoor }
  if (/STRENGTH|CARDIO|HIIT|YOGA|PILATES|FITNESS/.test(t)) return { sport: 'moc', indoor }
  if (/SWIM/.test(t)) return { sport: 'plavanje', indoor }
  return { sport: 'drugo', indoor }
}

/** Lokalni datum (YYYY-MM-DD) iz Unix sekund + zamika (SPEC: lokalni čas = start + offset). */
export function garminLocalDate(startSec: number, offsetSec: number | null | undefined): string {
  return new Date((startSec + (offsetSec || 0)) * 1000).toISOString().slice(0, 10)
}

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)

/**
 * Garminov zapis → Activity. null = ne uvozimo: brez začetka/trajanja, starš MULTI_SPORT (deli pridejo posebej),
 * prekratko (kot pri intervals.icu: pohod pod 15 min ali 1 km, ostalo pod 5 min; moč brez meje).
 * TSS: iz NP in FTP, če sta (ure × (NP/FTP)² × 100), sicer ocena kot pri uvozu iz intervals.icu.
 * Sled se shrani samo, če zastavica geoRetain to dovoli.
 */
export function activityFromGarmin(r: GarminActivityRec, p: Pick<Profile, 'ftp' | 'lthr' | 'restHr' | 'maxHr'>, nowIso: string = new Date().toISOString()): Activity | null {
  const start = pos(r.startTimeInSeconds), durS = pos(r.durationInSeconds)
  if (!start || !durS) return null
  if (r.isParent === true) return null
  const { sport, indoor } = garminSport(r.activityType)
  const min = durS / 60, km = (pos(r.distanceInMeters) || 0) / 1000
  if (sport === 'pohod' && (min < 15 || km < 1)) return null
  if (sport !== 'pohod' && sport !== 'moc' && min < 5) return null
  const d = r.details || null
  const manual = r.manual === true
  const originHint = manual ? 'GARMIN_API_MANUAL' : 'GARMIN_API'
  const dev = String(r.deviceName || '').trim()
  const deviceName = dev && dev.toLowerCase() !== 'unknown' ? dev : null
  const durationMin = Math.round(min) || null
  const distKm = pos(r.distanceInMeters) != null ? +km.toFixed(1) : null
  const avgPower = d && pos(d.avgWatts) != null ? Math.round(pos(d.avgWatts)!) : null
  const np = d && pos(d.np) != null ? Math.round(pos(d.np)!) : null
  const avgHr = pos(r.averageHeartRateInBeatsPerMinute) != null ? Math.round(pos(r.averageHeartRateInBeatsPerMinute)!) : null
  const maxHr = pos(r.maxHeartRateInBeatsPerMinute) ?? (d ? pos(d.maxHr) : null)
  const elev = num(r.totalElevationGainInMeters) ?? (d ? num(d.elevGain) : null)
  const spd = pos(r.averageSpeedInMetersPerSecond)
  const flags = deriveFlags('garmin', originHint)
  const a: Activity = {
    id: uid(), source: 'garmin', originHint, deviceName, sport,
    date: garminLocalDate(start, num(r.startTimeOffsetInSeconds)), start: new Date(start * 1000).toISOString(),
    name: String(r.activityName || '').trim() || autoName(sport, distKm, durationMin),
    distKm, durationMin, elapsedMin: durationMin, elevM: elev != null ? Math.round(elev) : null,
    avgHr, maxHr: maxHr != null ? Math.round(maxHr) : null, avgPower,
    speedKmh: spd ? +(spd * 3.6).toFixed(1) : distKm && durationMin ? +(distKm / (durationMin / 60)).toFixed(1) : null,
    kcal: pos(r.activeKilocalories) != null ? Math.round(pos(r.activeKilocalories)!) : null,
    tss: null,
    hrZoneSec: d && Array.isArray(d.hrZoneSec) && d.hrZoneSec.some(x => x > 0) ? d.hrZoneSec.map(x => Math.round(+x || 0)) : null,
    deviceWatts: avgPower != null ? true : (avgHr || distKm) ? false : null,
    trainer: indoor,
    polyline: flags.geoRetain && d?.polyline ? d.polyline : null,
    ...flags,
    ext: { ...(r.activityId != null && String(r.activityId) !== '' ? { garminId: String(r.activityId) } : {}), ...(r.summaryId ? { garminSummaryId: String(r.summaryId) } : {}) },
    createdAt: nowIso, updatedAt: nowIso,
  }
  // brez activityId (starejši push) je ključ summaryId — da dedup med sinhronizacijami dela
  if (!a.ext!.garminId && a.ext!.garminSummaryId) a.ext!.garminId = `s:${a.ext!.garminSummaryId}`
  a.tss = np && p.ftp ? Math.round((durS / 3600) * Math.pow(Math.max(0.4, Math.min(1.2, np / p.ftp)), 2) * 100) : estimateTss(a, p) || null
  return a
}

/** Ali je to ista vožnja kot zapis iz intervals.icu, ki je prišel z Garmina (start ±90 s, isti šport) — za dedup brez dvojnika. */
export function sameRideAsIcu(garmin: Pick<Activity, 'start' | 'sport'>, icu: Pick<Activity, 'source' | 'originHint' | 'start' | 'sport'>): boolean {
  if (icu.source !== 'intervals' || !/^GARMIN/.test(String(icu.originHint || '').toUpperCase())) return false
  if (!garmin.start || !icu.start || garmin.sport !== icu.sport) return false
  return Math.abs(new Date(garmin.start).getTime() - new Date(icu.start).getTime()) <= 90_000
}

/**
 * Obstoječi zapis iz intervals.icu dobi Garminove id-je in podatke, ki jih še nima (moč, NP→TSS ne, max utrip, sled, cone).
 * Vrne null, če ni kaj spremeniti.
 */
export function enrichIcuWithGarmin(e: Activity, g: Activity): Activity | null {
  const ext = { ...(e.ext || {}) }
  let changed = false
  if (g.ext?.garminId && ext.garminId !== g.ext.garminId) { ext.garminId = g.ext.garminId; changed = true }
  if (g.ext?.garminSummaryId && ext.garminSummaryId !== g.ext.garminSummaryId) { ext.garminSummaryId = g.ext.garminSummaryId; changed = true }
  const m: Activity = { ...e, ext }
  const take = <K extends keyof Activity>(k: K) => { if ((e[k] == null) && g[k] != null) { (m as Record<K, Activity[K]>)[k] = g[k]; changed = true } }
  take('avgPower'); take('maxHr'); take('avgHr'); take('kcal'); take('elevM'); take('hrZoneSec'); take('deviceName')
  if (e.deviceWatts == null && g.deviceWatts != null) { m.deviceWatts = g.deviceWatts; changed = true }
  if (!e.polyline && g.polyline && e.geoRetain) { m.polyline = g.polyline; changed = true }
  return changed ? m : null
}
