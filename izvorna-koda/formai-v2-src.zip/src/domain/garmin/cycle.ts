/**
 * (v3.52) Garmin Connect neposredno — MENSTRUALNI CIKEL (Women's Health API, `mct`).
 * SAMO prikaz in pravila v aplikaciji. NIKOLI v AI poziv (test: tests/v352-garmin-data-ai.test.ts).
 * Samo ob izrecnem vklopu (settings.garmin.cycle) in dovoljenju MCT_EXPORT; podatki ostanejo na napravi (KV garmin.cycle).
 *
 * Preslikava polj je [DOMNEVA] (SPEC §5: rekonstruirano iz ROOK 1:1; uradni PDF ni dostopen) — vsa polja neobvezna,
 * imena v `MCT_FIELDS` spodaj; PO URADNEM PDF POPRAVI SAMO TAM. Napačna shema → zapis se preskoči, nič se ne sesuje.
 */

// (v3.52 LENO) tipi in pravila so v ./cycleRules (začetni paket: Danes, Prehrana); tu je samo branje Garminovega zapisa
import { phaseFromDay, type CyclePhase, type CycleDay } from './cycleRules'
export * from './cycleRules'

/** [DOMNEVA] Imena polj v Garminovem mct zapisu — preveri po uradnem PDF (Women's Health API) in popravi tu. */
export const MCT_FIELDS = {
  date: ['calendarDate'],
  dayInCycle: ['dayInCycle', 'cycleDay'],
  cycleLength: ['cycleLength', 'predictedCycleLength'],
  periodLength: ['periodLength', 'lengthOfPeriod'],
  periodStart: ['periodStartDate'],
  predicted: ['isPredictedCycle', 'predictedCycle'],
  phaseType: ['currentPhaseType', 'phaseType', 'currentPhase'],
  /** currentPhase kot številka: 1 menstrualna, 2 folikularna, 3 ovulacija, 4 lutealna [DOMNEVA] */
  phaseNumber: ['currentPhase'],
} as const

const isDate = (s: unknown): s is string => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s)
const num = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) ? v : typeof v === 'string' && v.trim() !== '' && Number.isFinite(+v) ? +v : null)
const pick = (r: Record<string, unknown>, keys: readonly string[]): unknown => { for (const k of keys) if (r[k] !== undefined && r[k] !== null) return r[k]; return undefined }

/** Garminova oznaka faze (besedilo ali številka) → naša; neznano → null. */
export function phaseOf(v: unknown): CyclePhase | null {
  if (typeof v === 'number') return v === 1 ? 'menstrualna' : v === 2 ? 'folikularna' : v === 3 ? 'ovulacija' : v === 4 ? 'lutealna' : null
  const s = String(v ?? '').toUpperCase()
  if (!s) return null
  if (/MENS|PERIOD/.test(s)) return 'menstrualna'
  if (/FOLL/.test(s)) return 'folikularna'
  if (/OVUL/.test(s)) return 'ovulacija'
  if (/LUT/.test(s)) return 'lutealna'
  return null
}

/** Surov mct zapis → CycleDay; null, če ni datuma ali ničesar uporabnega. */
export function cycleFromMct(rec: unknown): CycleDay | null {
  if (!rec || typeof rec !== 'object') return null
  const r = rec as Record<string, unknown>
  const date = pick(r, MCT_FIELDS.date)
  if (!isDate(date)) return null
  const dayInCycle = num(pick(r, MCT_FIELDS.dayInCycle))
  const cycleLength = num(pick(r, MCT_FIELDS.cycleLength))
  const periodLength = num(pick(r, MCT_FIELDS.periodLength))
  const ps = pick(r, MCT_FIELDS.periodStart)
  const periodStartDate = isDate(ps) ? ps : null
  const pr = pick(r, MCT_FIELDS.predicted)
  const predicted = pr === true || pr === 'true'
  let phase = phaseOf(pick(r, MCT_FIELDS.phaseType))
  if (!phase && dayInCycle != null && dayInCycle >= 1) phase = phaseFromDay(dayInCycle, cycleLength, periodLength)
  if (dayInCycle == null && !phase && !periodStartDate) return null
  return {
    date, dayInCycle: dayInCycle != null && dayInCycle >= 1 && dayInCycle <= 60 ? Math.round(dayInCycle) : null,
    cycleLength: cycleLength != null && cycleLength >= 15 && cycleLength <= 60 ? Math.round(cycleLength) : null,
    periodLength: periodLength != null && periodLength >= 1 && periodLength <= 14 ? Math.round(periodLength) : null,
    phase, predicted, periodStartDate,
  }
}

/** Novi zapisi čez shranjene (isti datum → novi), urejeno po datumu, zadnjih `keep` dni. */
export function upsertCycle(prev: readonly CycleDay[] | null | undefined, fresh: readonly CycleDay[], keep = 120): CycleDay[] {
  const m = new Map<string, CycleDay>()
  for (const d of prev || []) m.set(d.date, d)
  for (const d of fresh) m.set(d.date, d)
  const all = [...m.values()].sort((a, b) => a.date.localeCompare(b.date))
  return all.length > keep ? all.slice(all.length - keep) : all
}
