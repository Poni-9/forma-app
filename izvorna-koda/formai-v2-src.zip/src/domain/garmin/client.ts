import { PROXY } from '@/config'
import { idToken, timeoutSignal } from '@/data/firebase'
import type { GarminActivityRec } from './activities'
import type { GarminHealth } from './wellness'

/**
 * (v3.52) Garmin Connect neposredno — KLICI STREŽNIKA (Cloud Run forma-ai-proxy, poti /garmin/*).
 * Žetoni Garmina so SAMO na strežniku; aplikacija se predstavi s Firebase ID žetonom (Authorization: Bearer).
 * Dogovor o poteh in napakah: IMPL-BRIEF »Strežniški API« — obe strani ga držita točno.
 * Napake so slovenske in nikoli tihe (GarminError.kind za UI: auth = prijava, none = ni povezave, off = strežnik brez ključev …).
 */

export type GarminErrKind = 'auth' | 'none' | 'off' | 'broken' | 'garmin' | 'network' | 'other'
export class GarminError extends Error {
  kind: GarminErrKind; status: number; code: string | null
  constructor(kind: GarminErrKind, msg: string, status = 0, code: string | null = null) { super(msg); this.name = 'GarminError'; this.kind = kind; this.status = status; this.code = code }
}

export const GARMIN_TIMEOUT_MS = 30_000
/** Največ zapisov na stran pri /garmin/activities (strežnik) — če jih pride toliko, je še kaj. */
export const GARMIN_PAGE = 200

let live: boolean | null = null
let probe: Promise<boolean> | null = null
/** Ali je »Poveži z Garmin Connect« na voljo: strežnik javi, da ima ključe (/health → garmin). */
export const garminOn = (): boolean => live === true
/** Enkrat na zagon vpraša strežnik; do odgovora (ali brez omrežja) gumba ni. */
export function garminLive(): Promise<boolean> {
  if (!probe) probe = fetch(`${PROXY}/health`, { signal: timeoutSignal(GARMIN_TIMEOUT_MS) }).then(r => r.json()).then((d: { garmin?: boolean }) => (live = d?.garmin === true)).catch(() => (live = false))
  return probe
}
/** Samo za teste. */
export const resetGarminProbe = (): void => { live = null; probe = null }

/** Slovensko sporočilo za kodo napake strežnika (IMPL-BRIEF) ali HTTP stanje. */
export function garminErrOf(status: number, code: string | null): GarminError {
  if (status === 401 || code === 'prijava_potrebna') return new GarminError('auth', 'Prijava je potekla — prijavi se znova, da se Garmin podatki prenesejo.', status, code)
  // (v3.52 popravki) kode strežnika s slovenskim besedilom (prej »napaka strežnika (409)«)
  if (code === 'povezava_prekinjena') return new GarminError('broken', 'Garmin je prekinil povezavo — poveži znova.', status, code)
  if (code === 'ni_dovoljenja' || status === 403) return new GarminError('garmin', 'Garmin za ta račun ne deli teh podatkov — v Garmin Connect preveri dovoljenja za FORMAI.', status, code)
  if (code === 'prevec_klicev' || status === 429) return new GarminError('garmin', 'Preveč zahtevkov na Garmin — poskusi čez minuto.', status, code)
  if (status === 409 || code === 'ni_povezave') return new GarminError('none', 'Garmin ni povezan — poveži ga znova.', status, code)
  if (status === 503 || code === 'garmin_ni_nastavljen') return new GarminError('off', 'Garmin na strežniku še ni nastavljen.', status, code)
  if (code && /^garmin_(\d{3})$/.test(code)) {
    const s = +code.slice(7)
    return new GarminError('garmin', s === 401 || s === 403 ? 'Garmin je zavrnil dostop — poveži znova.' : s === 429 ? 'Garmin: preveč zahtevkov — poskusim znova kasneje.' : `Garmin je vrnil napako (${s}).`, status, code)
  }
  if (status >= 500) return new GarminError('network', 'Strežnik trenutno ni dosegljiv — poskusim znova kasneje.', status, code)
  return new GarminError('other', `Garmin: napaka strežnika${status ? ` (${status})` : ''}.`, status, code)
}
/** Sporočilo za prikaz iz katere koli napake (GarminError, omrežje, drugo). */
export function garminErrMsg(e: unknown): string {
  if (e instanceof GarminError) return e.message
  const m = String((e as Error | null)?.message || '')
  if (/network|fetch|abort|Failed to fetch|NetworkError/i.test(m) || (typeof navigator !== 'undefined' && navigator.onLine === false)) return 'Strežnik ni dosegljiv — preveri povezavo.'
  return m || 'Garmin: neznana napaka.'
}

async function call<T>(path: string, init: RequestInit = {}): Promise<T> {
  const t = await idToken().catch(() => null)
  if (!t) throw new GarminError('auth', 'Garmin deluje s prijavo — prijavi se.', 401, 'prijava_potrebna')
  let r: Response
  try {
    r = await fetch(`${PROXY}${path}`, { ...init, headers: { Accept: 'application/json', ...(init.body ? { 'Content-Type': 'application/json' } : {}), ...(init.headers || {}), Authorization: `Bearer ${t}` }, signal: init.signal ?? timeoutSignal(GARMIN_TIMEOUT_MS) })
  } catch (e) {
    throw new GarminError('network', (e as Error)?.name === 'AbortError' ? 'Strežnik se ne odziva — poskusi znova.' : 'Strežnik ni dosegljiv — preveri povezavo.')
  }
  const d = await r.json().catch(() => null) as (T & { error?: string }) | null
  if (!r.ok) throw garminErrOf(r.status, typeof d?.error === 'string' ? d.error : null)
  if (d == null || typeof d !== 'object') throw new GarminError('other', 'Garmin: nerazumljiv odgovor strežnika.', r.status)
  return d
}

/** GET /garmin/status */
export interface GarminStatus { connected: boolean; broken?: boolean; userId: string | null; permissions: string[] | null; connectedAt: string | null; lastPushAt: string | null }
export async function fetchGarminStatus(): Promise<GarminStatus> {
  const d = await call<Partial<GarminStatus>>('/garmin/status')
  return {
    connected: d.connected === true, ...(d.broken === true ? { broken: true } : {}),
    userId: typeof d.userId === 'string' ? d.userId : d.userId != null ? String(d.userId) : null,
    permissions: Array.isArray(d.permissions) ? d.permissions.map(String) : null,
    connectedAt: typeof d.connectedAt === 'string' ? d.connectedAt : typeof d.connectedAt === 'number' ? new Date(d.connectedAt).toISOString() : null,
    lastPushAt: typeof d.lastPushAt === 'string' ? d.lastPushAt : typeof d.lastPushAt === 'number' ? new Date(d.lastPushAt).toISOString() : null,
  }
}

/** Naslov za začetek povezave: brskalnik gre na strežnik (z ID žetonom v poizvedbi), ta ga preusmeri na Garmin (OAuth2 PKCE). */
export function garminAuthUrl(token: string): string { return `${PROXY}/garmin/auth?t=${encodeURIComponent(token)}` }
/** »Poveži z Garmin Connect«: preusmeritev (ne fetch — Garmin CORS ne dovoli). Brez prijave vrže GarminError('auth'). */
export async function startGarminConnect(): Promise<void> {
  const t = await idToken(true).catch(() => null)
  if (!t) throw new GarminError('auth', 'Za povezavo z Garminom se najprej prijavi (Garmin žetone hrani strežnik na tvojem računu).', 401, 'prijava_potrebna')
  location.href = garminAuthUrl(t)
}

/** Izid vrnitve z Garmina (?garmin=ok|err v naslovu). null = ni vrnitve. Parameter se pobriše iz naslova. */
export function garminReturnParam(): 'ok' | 'err' | null {
  if (typeof location === 'undefined') return null
  const q = new URLSearchParams(location.search)
  const v = q.get('garmin')
  if (!v) return null
  q.delete('garmin')
  const rest = q.toString()
  try { history.replaceState(null, '', location.pathname + (rest ? `?${rest}` : '') + (location.hash && /^#\/./.test(location.hash) ? location.hash : '#/uvoz')) } catch { /* ni */ }
  return v === 'ok' ? 'ok' : 'err'
}

/**
 * (v3.52 popravki) Paginacija po dogovoru s strežnikom: `now` v odgovoru = največji vrnjeni `t` (ne ura strežnika — zapis
 * pusha dobi `t` ob zapisu, zato bi ura strežnika preskočila zapise, ki se ravno zapisujejo); `more` = je še kaj → kliči
 * znova s since = now. Brez `now` v odgovoru je null (klicatelj vzame največji t zapisov, nikoli Date.now()).
 */
export interface GarminPage { now: number | null; more: boolean }
const pageOf = (d: Record<string, unknown>): GarminPage => ({ now: typeof d.now === 'number' && Number.isFinite(d.now) ? d.now : null, more: d.more === true })
/** GET /garmin/activities?since=<ms> → zapisi z t > since (največ GARMIN_PAGE), now = največji vrnjeni t, more = je še kaj. */
export async function fetchGarminActivities(since: number): Promise<{ items: GarminActivityRec[] } & GarminPage> {
  const d = await call<Record<string, unknown>>(`/garmin/activities?since=${Math.max(0, Math.floor(since))}`)
  return { items: Array.isArray(d.items) ? (d.items.filter(x => x && typeof x === 'object') as GarminActivityRec[]) : [], ...pageOf(d) }
}
/** GET /garmin/health?since=<ms> → dailies, sleeps, hrv, stress (stressDetails oklešteni), bodyComps, userMetrics. */
export async function fetchGarminHealth(since: number): Promise<GarminHealth & GarminPage> {
  const d = await call<Record<string, unknown>>(`/garmin/health?since=${Math.max(0, Math.floor(since))}`)
  const arr = <T,>(v: unknown): T[] => (Array.isArray(v) ? (v.filter(x => x && typeof x === 'object') as T[]) : [])
  return { dailies: arr(d.dailies), sleeps: arr(d.sleeps), hrv: arr(d.hrv), stress: arr(d.stress ?? d.stressDetails), bodyComps: arr(d.bodyComps), userMetrics: arr(d.userMetrics), ...pageOf(d) }
}
/** GET /garmin/cycle?since=<ms> → surovi mct zapisi (samo z dovoljenjem MCT_EXPORT). */
export async function fetchGarminCycle(since: number): Promise<{ mct: unknown[] } & GarminPage> {
  const d = await call<Record<string, unknown>>(`/garmin/cycle?since=${Math.max(0, Math.floor(since))}`)
  return { mct: Array.isArray(d.mct) ? d.mct : [], ...pageOf(d) }
}
/**
 * Naslednji `since` po strani: `now` odgovora (največji vrnjeni t), brez njega največji t zapisov; nikoli nazaj in
 * nikoli Date.now(). Prazna stran brez `now` ga ne premakne.
 */
export function nextSince(cur: number, page: GarminPage, items: readonly { t?: unknown }[]): number {
  const maxT = items.reduce((m, x) => Math.max(m, typeof x.t === 'number' && Number.isFinite(x.t) ? x.t : 0), 0)
  return Math.max(cur, page.now ?? maxT, maxT)
}
/** POST /garmin/disconnect — strežnik odjavi pri Garminu (DELETE user/registration), pobriše žetone in podatke. 409 (ni povezave) šteje kot uspeh. */
export async function garminDisconnect(): Promise<void> {
  try { await call<{ ok?: boolean }>('/garmin/disconnect', { method: 'POST' }) } catch (e) { if (!(e instanceof GarminError && e.kind === 'none')) throw e }
}
