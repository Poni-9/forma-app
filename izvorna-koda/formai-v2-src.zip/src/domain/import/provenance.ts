import type { Activity, ActivitySource } from '../types'

/**
 * Izvori v intervals.icu, za katere VEMO, da niso Strava.
 * Seznam ni popoln in tudi ne more biti — zato je privzetek ZAPRT: neznan izvor ne gre v AI.
 * Ko se v opozorilu pojavi nova vrednost, jo dodaj sem.
 */
export const INTERVALS_SAFE_ORIGINS = new Set([
  'GARMIN', 'GARMIN_CONNECT', 'POLAR', 'SUUNTO', 'WAHOO', 'COROS', 'ZWIFT',
  'UPLOAD', 'MANUAL', 'FILE', 'DROPBOX', 'TRAINERROAD', 'ROUVY', 'WHOOP', 'OURA', 'FITBIT',
  'HAMMERHEAD', 'BRYTON', 'IGPSPORT', 'MAGENE', 'XERT', 'CONCEPT2', 'ELITE', 'TACX',
  'KINOMAP', 'MYWHOOSH', 'PELOTON', 'DECATHLON', 'APPLE', 'HUAWEI', 'SPORTTRACKS',
  'RIDE_WITH_GPS', 'NOLIO', 'TODAYS_PLAN',
])

export const STRAVA_API_TTL_DAYS = 7

/**
 * Izračuna izpeljani zastavici za aktivnost. Kliče se ob ZAPISU; pravila nato berejo samo zastavici.
 *
 * - Strava API: nikoli AI (§5.3), nikoli hramba lokacije (§5.7), poteče po 7 dneh (§6.2).
 * - intervals.icu: samo znan, ne-Stravin izvor. Stravini podatki, ki so pripotovali skozi
 *   tretjo stran, ostanejo Stravini — pot pravila ne odpravi.
 * - vse ostalo (datoteke, arhiv, posnetek, ročno, snemalnik): uporabnikovo → dovoljeno.
 */
export function deriveFlags(
  source: ActivitySource,
  originHint?: string | null,
  now: Date = new Date(),
): Pick<Activity, 'aiEligible' | 'geoRetain' | 'expiresAt'> {
  if (source === 'strava_api') {
    const exp = new Date(now.getTime() + STRAVA_API_TTL_DAYS * 86400_000).toISOString()
    return { aiEligible: false, geoRetain: false, expiresAt: exp }
  }
  if (source === 'intervals') {
    const ok = INTERVALS_SAFE_ORIGINS.has(String(originHint || '').toUpperCase())
    return { aiEligible: ok, geoRetain: ok, expiresAt: null }
  }
  if (source === 'demo') return { aiEligible: false, geoRetain: true, expiresAt: null }   // demo: karta da (da se vidi, kaj je), AI ne
  return { aiEligible: true, geoRetain: true, expiresAt: null }
}

/** Ali sme aktivnost v AI poziv. Edino mesto, ki to odloča. */
export function aiAllowed(a: Pick<Activity, 'aiEligible' | 'expiresAt'>): boolean {
  if (!a.aiEligible) return false
  if (a.expiresAt && new Date(a.expiresAt).getTime() < Date.now()) return false
  return true
}

/** Ali sme sled te aktivnosti na trajno karto pokritosti. */
export function geoAllowed(a: Pick<Activity, 'geoRetain' | 'polyline'>): boolean {
  return !!a.geoRetain && !!a.polyline
}

/** Človeku berljiva oznaka izvora za UI (»Garmin · trener vidi«). */
export function sourceLabel(a: Pick<Activity, 'source' | 'originHint' | 'deviceName'>): string {
  switch (a.source) {
    case 'intervals': {
      const o = String(a.originHint || '').toUpperCase()
      if (o === 'GARMIN' || o === 'GARMIN_CONNECT') return 'Garmin'
      if (o === 'STRAVA') return 'Strava (prek intervals.icu)'
      if (o) return o.charAt(0) + o.slice(1).toLowerCase().replace(/_/g, ' ')
      return 'intervals.icu'
    }
    case 'file': return 'Datoteka'
    case 'archive': return 'Arhiv'
    case 'screenshot': return 'Posnetek'
    case 'manual': return 'Ročno'
    case 'recorder': return 'FORMAI'
    case 'strava_api': return 'Strava'
    case 'demo': return 'Demo'
  }
}
