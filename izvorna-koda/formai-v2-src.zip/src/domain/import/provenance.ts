import type { Activity, ActivitySource } from '../types'

/**
 * Izvori v intervals.icu, za katere VEMO, da niso Strava.
 * Seznam ni popoln in tudi ne more biti — zato je privzetek ZAPRT: neznan izvor ne gre v AI.
 * Ko se v opozorilu pojavi nova vrednost, jo dodaj sem.
 */
export const INTERVALS_SAFE_ORIGINS = new Set([
  'GARMIN', 'GARMIN_CONNECT', 'POLAR', 'SUUNTO', 'WAHOO', 'COROS', 'ZWIFT',
  'UPLOAD', 'MANUAL', 'FILE', 'DROPBOX', 'TRAINERROAD', 'ROUVY', 'WHOOP', 'OURA', 'FITBIT',
  'HAMMERHEAD', 'BRYTON', 'IGPSPORT', 'MAGENE', 'XERT', 'CONCEPT2', 'ELITE', 'TACX',
  'KINOMAP', 'MYWHOOSH', 'PELOTON', 'DECATHLON', 'APPLE', 'HUAWEI', 'SPORTTRACKS',
  'RIDE_WITH_GPS', 'NOLIO', 'TODAYS_PLAN',
])

export const STRAVA_API_TTL_DAYS = 7
/** originHint za datoteke, arhive in posnetke zaslona, ki izvirajo iz Strave. */
export const STRAVA_ORIGIN = 'STRAVA'

/**
 * Izračuna izpeljani zastavici za aktivnost. Kliče se ob ZAPISU; pravila nato berejo samo zastavici.
 *
 * - Strava API: nikoli AI (§5.3), nikoli hramba lokacije (§5.7), poteče po 7 dneh (§6.2).
 * - intervals.icu: samo znan, ne-Stravin izvor. Stravini podatki, ki so pripotovali skozi
 *   tretjo stran, ostanejo Stravini — pot pravila ne odpravi.
 * - Stravin izvoz (arhiv, GPX iz Strave) in posnetek zaslona Strave (originHint 'STRAVA'): nikoli AI;
 *   sled je uporabnikova datoteka in ostane samo na tej napravi (karta), pri posnetku sledi ni.
 * - vse ostalo (datoteke, arhiv, posnetek, ročno, snemalnik): uporabnikovo → dovoljeno.
 */
export function deriveFlags(
  source: ActivitySource,
  originHint?: string | null,
  now: Date = new Date(),
): Pick<Activity, 'aiEligible' | 'geoRetain' | 'expiresAt'> {
  if (source === 'strava_api') {
    const exp = new Date(now.getTime() + STRAVA_API_TTL_DAYS * 86400_000).toISOString()
    return { aiEligible: false, geoRetain: false, expiresAt: exp }
  }
  if (source === 'intervals') {
    const ok = INTERVALS_SAFE_ORIGINS.has(String(originHint || '').toUpperCase())
    return { aiEligible: ok, geoRetain: ok, expiresAt: null }
  }
  if (source === 'demo') return { aiEligible: false, geoRetain: true, expiresAt: null }   // demo: karta da (da se vidi, kaj je), AI ne
  if (String(originHint || '').toUpperCase() === STRAVA_ORIGIN) return { aiEligible: false, geoRetain: source !== 'screenshot', expiresAt: null }
  return { aiEligible: true, geoRetain: true, expiresAt: null }
}

/**
 * Stravin izvoz (»Download your data«): v korenu activities.csv (in profile.csv, …), vožnje v mapi activities/
 * (.fit.gz, .gpx, .tcx.gz z imeni po Stravinih številkah). Garminov izvoz ima DI_CONNECT/… in *_summarizedActivities.json.
 */
const STRAVA_EXPORT_CSV = new Set(['profile.csv', 'bikes.csv', 'shoes.csv', 'clubs.csv', 'segments.csv', 'starred_segments.csv', 'routes.csv', 'starred_routes.csv', 'goals.csv', 'global_challenges.csv', 'group_challenges.csv', 'followers.csv', 'following.csv', 'comments.csv', 'media.csv', 'contacts.csv', 'connected_apps.csv', 'applications.csv', 'reactions.csv'])
export function isStravaArchive(entryNames: readonly string[]): boolean {
  const names = entryNames.map(n => n.replace(/\\/g, '/').replace(/^\/+/, ''))
  const base = (n: string) => (n.split('/').pop() || '').toLowerCase()
  const hasCsv = names.some(n => base(n) === 'activities.csv')
  const hasDir = names.some(n => /(^|\/)activities\/\d+\.(fit|gpx|tcx)(\.gz)?$/i.test(n))
  const other = names.some(n => STRAVA_EXPORT_CSV.has(base(n)))
  return (hasCsv && (hasDir || other)) || (hasDir && other)
}

/** GPX/TCX, ki ga je izdelala Strava (creator="StravaGPX …", avtor Strava). */
export function isStravaFileText(head: string): boolean {
  return /<gpx[^>]*\bcreator\s*=\s*["'][^"']*strava/i.test(head) || /<(Author|Creator)[^>]*>[\s\S]{0,200}?<Name>\s*Strava/i.test(head) || /strava\.com\/activities\//i.test(head)
}

/** Ali sme aktivnost v AI poziv. Edino mesto, ki to odloča. */
export function aiAllowed(a: Pick<Activity, 'aiEligible' | 'expiresAt'>): boolean {
  if (!a.aiEligible) return false
  if (a.expiresAt && new Date(a.expiresAt).getTime() < Date.now()) return false
  return true
}

/** Ali sme sled te aktivnosti na trajno karto pokritosti. */
export function geoAllowed(a: Pick<Activity, 'geoRetain' | 'polyline'>): boolean {
  return !!a.geoRetain && !!a.polyline
}

/**
 * Garmin pripis (pogoj Garmin API, ki velja tudi za podatke prek intervals.icu): ob podatkih z Garmin naprave
 * prikaži »Garmin [model]«. Vrne null, če aktivnost ni z Garmin naprave.
 */
export function garminDevice(a: Pick<Activity, 'originHint' | 'deviceName'>): string | null {
  const o = String(a.originHint || '').toUpperCase()
  const d = String(a.deviceName || '').trim()
  if (!(o === 'GARMIN' || o === 'GARMIN_CONNECT' || /garmin/i.test(d))) return null
  if (!d) return 'Garmin'
  const n = d.replace(/^GARMIN\s+FR\s*/i, 'Garmin Forerunner ').replace(/^garmin\b/i, 'Garmin')
  return /^Garmin\b/.test(n) ? n : `Garmin ${n}`
}

/** Ali so med aktivnostmi (iz intervals.icu) tudi podatki z Garmin naprav — za pripis pod izračuni. */
export function hasGarminData(acts: readonly Pick<Activity, 'source' | 'originHint' | 'deviceName'>[]): boolean {
  return acts.some(a => a.source === 'intervals' && garminDevice(a) != null)
}

/** Človeku berljiva oznaka izvora za UI (»Garmin · trener vidi«). */
export function sourceLabel(a: Pick<Activity, 'source' | 'originHint' | 'deviceName'>): string {
  switch (a.source) {
    case 'intervals': {
      const o = String(a.originHint || '').toUpperCase()
      if (o === 'GARMIN' || o === 'GARMIN_CONNECT') return garminDevice(a) || 'Garmin'
      if (o === 'STRAVA') return 'Strava (prek intervals.icu)'
      if (o) return o.charAt(0) + o.slice(1).toLowerCase().replace(/_/g, ' ')
      return 'intervals.icu'
    }
    case 'file': return String(a.originHint || '').toUpperCase() === STRAVA_ORIGIN ? 'Datoteka iz Strave' : 'Datoteka'
    case 'archive': return String(a.originHint || '').toUpperCase() === STRAVA_ORIGIN ? 'Stravin arhiv' : 'Arhiv'
    case 'screenshot': return String(a.originHint || '').toUpperCase() === STRAVA_ORIGIN ? 'Posnetek Strave' : 'Posnetek'
    case 'manual': return 'Ročno'
    case 'recorder': return 'FORMAI'
    case 'strava_api': return 'Strava'
    case 'demo': return 'Demo'
  }
}
