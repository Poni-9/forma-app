import { ACTIVITY_FILE_RE, gunzip, parseFit, parseGpx, parseTcx, type ParsedActivity } from './parsers'

export interface ArchiveProgress { found: number; done: number; failed: number }

/**
 * Odpre arhiv (Garmin Connect izvoz, Garminov GDPR izvoz z ZIP-i v ZIP-u, Stravin arhiv z .gz)
 * in razčleni vse aktivnostne datoteke. Ne shranjuje — to je naloga klicatelja (en zapis na koncu).
 */
export async function parseArchive(file: File, onProgress?: (p: ArchiveProgress) => void): Promise<{ parsed: ParsedActivity[]; failed: number; found: number }> {
  const { default: JSZip } = await import('jszip')
  const entries: { name: string; entry: any }[] = []
  async function walk(zip: any, depth: number) {
    const names = Object.keys(zip.files).filter(n => !zip.files[n].dir)
    for (const n of names) {
      if (ACTIVITY_FILE_RE.test(n)) { entries.push({ name: n, entry: zip.files[n] }); continue }
      if (depth < 2 && /\.zip$/i.test(n)) {
        try { await walk(await JSZip.loadAsync(await zip.files[n].async('arraybuffer')), depth + 1) } catch { /* preskoči pokvarjen notranji zip */ }
      }
    }
  }
  await walk(await JSZip.loadAsync(await file.arrayBuffer()), 0)
  const parsed: ParsedActivity[] = []
  let failed = 0, done = 0
  onProgress?.({ found: entries.length, done, failed })
  for (const it of entries) {
    try {
      let f = new File([await it.entry.async('blob')], it.name.split('/').pop()!, { type: 'application/octet-stream' })
      if (/\.gz$/i.test(f.name)) f = await gunzip(f, f.name)
      const low = f.name.toLowerCase()
      const r = low.endsWith('.gpx') ? await parseGpx(f, f.name) : low.endsWith('.tcx') ? await parseTcx(f, f.name) : await parseFit(f, f.name)
      parsed.push(r)
    } catch { failed++ }
    done++
    if (done % 10 === 0) { onProgress?.({ found: entries.length, done, failed }); await new Promise(r => setTimeout(r, 0)) }
  }
  onProgress?.({ found: entries.length, done, failed })
  return { parsed, failed, found: entries.length }
}
