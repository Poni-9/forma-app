import { ACTIVITY_FILE_RE, gunzip, parseFit, parseGpx, parseTcx, readArrayBuffer, ImportError, whyOf, type ParsedActivity } from './parsers'
import { isStravaArchive, STRAVA_ORIGIN } from './provenance'

export interface ArchiveProgress { found: number; done: number; failed: number }

/**
 * Odpre arhiv (Garmin Connect izvoz, Garminov GDPR izvoz z ZIP-i v ZIP-u, Stravin arhiv z .gz)
 * in razčleni vse aktivnostne datoteke. Ne shranjuje — to je naloga klicatelja (en zapis na koncu).
 * Stravin izvoz (activities.csv + activities/…) označi vse vožnje z izvorom STRAVA: gredo na karto na tej
 * napravi, v AI pa nikoli (toActivity → deriveFlags).
 */
export async function parseArchive(file: File, onProgress?: (p: ArchiveProgress) => void): Promise<{ parsed: ParsedActivity[]; failed: number; found: number; strava: boolean; fails: { name: string; why: string }[] }> {
  // (v3.50) knjižnica ni v predpomnilniku (brez povezave) ali datoteka ni .zip: slovensko, brez angleške napake s povezavo
  let JSZip: any
  try { JSZip = (await import('jszip')).default } catch { throw new ImportError('offline-lib', 'za odpiranje arhiva rabim povezavo — poskusi, ko boš na spletu') }
  const entries: { name: string; entry: any }[] = []
  const allNames: string[] = []
  async function walk(zip: any, depth: number) {
    const names = Object.keys(zip.files).filter(n => !zip.files[n].dir)
    if (depth === 0) allNames.push(...Object.keys(zip.files))
    for (const n of names) {
      if (ACTIVITY_FILE_RE.test(n)) { entries.push({ name: n, entry: zip.files[n] }); continue }
      if (depth < 2 && /\.zip$/i.test(n)) {
        try { await walk(await JSZip.loadAsync(await zip.files[n].async('arraybuffer')), depth + 1) } catch { /* preskoči pokvarjen notranji zip */ }
      }
    }
  }
  let root: any
  try { root = await JSZip.loadAsync(await readArrayBuffer(file)) } catch { throw new ImportError('invalid', ZIP_BAD) }
  await walk(root, 0)
  const strava = isStravaArchive(allNames)
  const parsed: ParsedActivity[] = []
  const fails: { name: string; why: string }[] = []
  let failed = 0, done = 0
  onProgress?.({ found: entries.length, done, failed })
  for (const it of entries) {
    try {
      let f = new File([await it.entry.async('blob')], it.name.split('/').pop()!, { type: 'application/octet-stream' })
      if (/\.gz$/i.test(f.name)) f = await gunzip(f, f.name)
      const low = f.name.toLowerCase()
      const r = low.endsWith('.gpx') ? await parseGpx(f, f.name) : low.endsWith('.tcx') ? await parseTcx(f, f.name) : await parseFit(f, f.name)
      parsed.push(strava ? { ...r, originHint: STRAVA_ORIGIN } : r)
    } catch (e) { failed++; if (fails.length < 5) fails.push({ name: it.name.split('/').pop()!, why: whyOf(e) }) }
    done++
    if (done % 10 === 0) { onProgress?.({ found: entries.length, done, failed }); await new Promise(r => setTimeout(r, 0)) }
  }
  onProgress?.({ found: entries.length, done, failed })
  return { parsed, failed, found: entries.length, strava, fails }
}
/** (v3.50) Namesto »Can't find end of central directory : is this a zip file ? …« (JSZip). */
export const ZIP_BAD = 'to ni arhiv .zip (ali je poškodovan) — izberi izvoz Garmina ali Strave ali posamezne .fit/.gpx datoteke'
