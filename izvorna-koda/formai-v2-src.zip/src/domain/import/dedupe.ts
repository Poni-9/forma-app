import type { Activity } from '../types'

type Key = Pick<Activity, 'start' | 'durationMin' | 'date' | 'sport' | 'distKm'> & { source?: Activity['source']; createdAt?: string }
/** (v3.50) Ročni vnos in posnetek: brez začetka, številke na pamet (»90 min«, »okoli 40 km«). */
const LOOSE = new Set<Activity['source']>(['manual', 'screenshot'])
export const looseEntry = (a: Key): boolean => !a.start && !!a.source && LOOSE.has(a.source)
/** (v3.50) vadba je bila pred vpisom istega dne, največ ~6 h prej (vpis takoj po vadbi ali popoldne za jutranjo) */
const LOOSE_BEFORE_H = 6
const dayOf = (t: number) => { const d = new Date(t); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}` }
/**
 * (v3.50) Ura dneva: ročni vnos (ali posnetek) za danes je vpisan PO vadbi. Vadba z ure, ki se je začela po vpisu ali
 * končala več kot 6 h pred njim, je druga vadba — jutranja v službo in večerna domov sta dve (prej je ura povozila
 * ročni vnos in nanjo prenesla občutek in opombo).
 */
export function apartInDay(loose: Key, timed: Key): boolean {
  if (!loose.createdAt || !timed.start) return false
  const at = Date.parse(loose.createdAt), st = Date.parse(timed.start)
  if (!Number.isFinite(at) || !Number.isFinite(st) || dayOf(at) !== loose.date) return false
  const end = st + (timed.durationMin || 0) * 60_000
  return st > at + 15 * 60_000 || end < at - LOOSE_BEFORE_H * 3600_000
}

/**
 * Ali sta zapisa ista aktivnost? Začetek ±90 s IN podobno trajanje.
 * Brez natančnega začetka: isti dan + šport + podobna razdalja.
 * (Strava beleži čas premikanja, Garmin skupni čas — zato toleranca, ne točno ujemanje.)
 * (v3.50) Ročni vnos ali posnetek brez začetka: isti dan + šport + trajanje ±20 % (tudi brez razdalje), razdalja ±10 %
 * — prej je bila »90 min« ročno in ista vožnja z ure dvakrat (ure tedna, forma in kalorije ×2).
 */
export function sameActivity(a: Key, b: Key): boolean {
  if (a.start && b.start) {
    const dt = Math.abs(new Date(a.start).getTime() - new Date(b.start).getTime())
    if (dt > 90_000) return false
    const ta = a.durationMin || 0, tb = b.durationMin || 0
    if (!ta || !tb) return true
    return Math.abs(ta - tb) <= Math.max(3, Math.min(ta, tb) * 0.15)
  }
  if (a.date !== b.date || a.sport !== b.sport) return false
  const da = a.distKm || 0, db = b.distKm || 0
  if (looseEntry(a) || looseEntry(b)) {
    if ((looseEntry(a) && apartInDay(a, b)) || (looseEntry(b) && apartInDay(b, a))) return false
    const ta = a.durationMin || 0, tb = b.durationMin || 0
    const timeOk = !!ta && !!tb && Math.abs(ta - tb) <= Math.max(5, Math.max(ta, tb) * 0.2)
    const distOk = !!da && !!db && Math.abs(da - db) <= Math.max(0.5, Math.max(da, db) * 0.1)
    // kar je znano na obeh straneh, se mora ujemati; vsaj eno mora biti znano
    if (ta && tb && da && db) return timeOk && distOk
    return timeOk || distOk
  }
  if (!da && !db) {
    // brez razdalje (moč, trenažer brez podatkov): isto le ob podobnem trajanju — dve vadbi moči na dan sta lahko resnični
    const ta = a.durationMin || 0, tb = b.durationMin || 0
    if (!ta || !tb) return false
    return Math.abs(ta - tb) <= Math.max(5, Math.min(ta, tb) * 0.15)
  }
  return Math.abs(da - db) <= Math.max(0.3, da * 0.04)
}

/** Katere od kandidatov so nove glede na obstoječe in med seboj. */
export function splitNew<T extends Activity>(existing: readonly Activity[], candidates: readonly T[]): { fresh: T[]; dupes: T[] } {
  const fresh: T[] = [], dupes: T[] = []
  for (const c of candidates) {
    if (existing.some(e => sameActivity(e, c)) || fresh.some(f => sameActivity(f, c))) dupes.push(c)
    else fresh.push(c)
  }
  return { fresh, dupes }
}

/**
 * Ob dvojniku iz dveh virov obdrži bogatejšega: raje s sledjo, raje z močjo/utripom.
 * (v3.50) Zapis z ure ali iz datoteke ima prednost pred ročnim vnosom ali posnetkom z istimi podatki.
 */
export function richer(a: Activity, b: Activity): Activity {
  const score = (x: Activity) => (x.polyline ? 4 : 0) + (x.avgPower ? 2 : 0) + (x.avgHr ? 1 : 0) + (x.kcal ? 1 : 0) + (LOOSE.has(x.source) ? 0 : 0.5)
  return score(b) > score(a) ? b : a
}
