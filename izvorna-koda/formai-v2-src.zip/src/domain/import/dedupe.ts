import type { Activity } from '../types'

/**
 * Ali sta zapisa ista aktivnost? Začetek ±90 s IN podobno trajanje.
 * Brez natančnega začetka: isti dan + šport + podobna razdalja.
 * (Strava beleži čas premikanja, Garmin skupni čas — zato toleranca, ne točno ujemanje.)
 */
export function sameActivity(a: Pick<Activity, 'start' | 'durationMin' | 'date' | 'sport' | 'distKm'>, b: Pick<Activity, 'start' | 'durationMin' | 'date' | 'sport' | 'distKm'>): boolean {
  if (a.start && b.start) {
    const dt = Math.abs(new Date(a.start).getTime() - new Date(b.start).getTime())
    if (dt > 90_000) return false
    const ta = a.durationMin || 0, tb = b.durationMin || 0
    if (!ta || !tb) return true
    return Math.abs(ta - tb) <= Math.max(3, Math.min(ta, tb) * 0.15)
  }
  if (a.date !== b.date || a.sport !== b.sport) return false
  const da = a.distKm || 0, db = b.distKm || 0
  if (!da && !db) {
    // brez razdalje (moč, trenažer brez podatkov): isto le ob podobnem trajanju — dve vadbi moči na dan sta lahko resnični
    const ta = a.durationMin || 0, tb = b.durationMin || 0
    if (!ta || !tb) return false
    return Math.abs(ta - tb) <= Math.max(5, Math.min(ta, tb) * 0.15)
  }
  return Math.abs(da - db) <= Math.max(0.3, da * 0.04)
}

/** Katere od kandidatov so nove glede na obstoječe in med seboj. */
export function splitNew<T extends Activity>(existing: readonly Activity[], candidates: readonly T[]): { fresh: T[]; dupes: T[] } {
  const fresh: T[] = [], dupes: T[] = []
  for (const c of candidates) {
    if (existing.some(e => sameActivity(e, c)) || fresh.some(f => sameActivity(f, c))) dupes.push(c)
    else fresh.push(c)
  }
  return { fresh, dupes }
}

/** Ob dvojniku iz dveh virov obdrži bogatejšega: raje s sledjo, raje z močjo/utripom. */
export function richer(a: Activity, b: Activity): Activity {
  const score = (x: Activity) => (x.polyline ? 4 : 0) + (x.avgPower ? 2 : 0) + (x.avgHr ? 1 : 0) + (x.kcal ? 1 : 0)
  return score(b) > score(a) ? b : a
}
