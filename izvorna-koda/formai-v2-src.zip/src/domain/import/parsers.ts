import type { Activity, ActivitySource, Sport } from '../types'
import { encodePolyline, haversineM, isValidLatLon, thinTrack, type LatLon } from './polyline'
import { deriveFlags } from './provenance'
import { sportOfType } from '../training/load'

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)

/** Surov rezultat razčlenjevanja — brez TSS (ta potrebuje profil) in brez zastavic. */
export interface ParsedActivity {
  sport: Sport
  name: string
  start: string | null
  date: string
  distKm: number | null
  durationMin: number | null
  elevM: number | null
  avgHr: number | null
  maxHr: number | null
  avgPower: number | null
  kcal: number | null
  polyline: string | null
  deviceName: string | null
  fileName: string
}

/** Blob → besedilo; ne zanaša se na Blob.text() (manjka v starejših Safarijih in v jsdom). */
export function readText(blob: Blob): Promise<string> {
  if (typeof (blob as any).text === 'function') return (blob as any).text()
  return new Promise((res, rej) => {
    const fr = new FileReader()
    fr.onload = () => res(String(fr.result || ''))
    fr.onerror = () => rej(fr.error || new Error('Branje datoteke ni uspelo.'))
    fr.readAsText(blob)
  })
}
export function readArrayBuffer(blob: Blob): Promise<ArrayBuffer> {
  if (typeof (blob as any).arrayBuffer === 'function') return (blob as any).arrayBuffer()
  return new Promise((res, rej) => {
    const fr = new FileReader()
    fr.onload = () => res(fr.result as ArrayBuffer)
    fr.onerror = () => rej(fr.error || new Error('Branje datoteke ni uspelo.'))
    fr.readAsArrayBuffer(blob)
  })
}

function localDate(iso: string | null): string {
  const d = iso ? new Date(iso) : new Date()
  const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, '0'), dd = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${dd}`
}

function finish(pts: LatLon[]): string | null {
  const th = thinTrack(pts.filter(isValidLatLon), 20)
  return th.length > 1 ? encodePolyline(th) : null
}

function guessSport(spd: number | null, hint: string | null): Sport {
  const h = hint ? sportOfType(hint) : null
  if (h && h !== 'drugo') return h
  if (spd == null) return 'kolo'
  return spd < 7 ? 'pohod' : spd < 14 ? 'tek' : 'kolo'
}

/* ---------------- GPX ---------------- */
export async function parseGpx(file: File | Blob, fileName = (file as File).name || 'aktivnost.gpx'): Promise<ParsedActivity> {
  const txt = await readText(file)
  const doc = new DOMParser().parseFromString(txt, 'application/xml')
  if (doc.querySelector('parsererror')) throw new Error('Neveljavna GPX datoteka.')
  const tp = Array.from(doc.getElementsByTagName('trkpt'))
  if (tp.length < 2) throw new Error('GPX ne vsebuje sledi (trkpt).')
  let distM = 0, elev = 0, lastEle: number | null = null
  const hrs: number[] = []; let t0: string | null = null, t1: string | null = null
  let prev: LatLon | null = null
  const pts: LatLon[] = []
  for (const p of tp) {
    const lat = +p.getAttribute('lat')!, lon = +p.getAttribute('lon')!
    const cur: LatLon = [lat, lon]
    if (isValidLatLon(cur)) { pts.push(cur); if (prev) distM += haversineM(prev, cur); prev = cur }
    const eleEl = p.getElementsByTagName('ele')[0]
    if (eleEl) { const e = +eleEl.textContent!; if (!isNaN(e)) { if (lastEle != null && e > lastEle) elev += e - lastEle; lastEle = e } }
    const tEl = p.getElementsByTagName('time')[0]
    if (tEl) { if (!t0) t0 = tEl.textContent; t1 = tEl.textContent }
    for (const el of Array.from(p.getElementsByTagName('*'))) if (el.localName === 'hr') { const v = +el.textContent!; if (v > 40 && v < 230) hrs.push(v) }
  }
  const durationMin = t0 && t1 ? Math.max(1, Math.round((new Date(t1).getTime() - new Date(t0).getTime()) / 60000)) : null
  const distKm = +(distM / 1000).toFixed(1)
  const spd = durationMin && distKm ? distKm / (durationMin / 60) : null
  let name = 'GPX aktivnost'
  const nEl = doc.getElementsByTagName('name')[0]; if (nEl && nEl.textContent!.trim()) name = nEl.textContent!.trim().slice(0, 60)
  const typeEl = doc.getElementsByTagName('type')[0]
  return {
    sport: guessSport(spd, typeEl?.textContent || null), name, start: t0 ? new Date(t0).toISOString() : null, date: localDate(t0),
    distKm, durationMin, elevM: Math.round(elev), avgHr: hrs.length ? Math.round(hrs.reduce((a, b) => a + b, 0) / hrs.length) : null,
    maxHr: hrs.length ? Math.max(...hrs) : null, avgPower: null, kcal: null, polyline: finish(pts), deviceName: null, fileName,
  }
}

/* ---------------- TCX ---------------- */
export async function parseTcx(file: File | Blob, fileName = (file as File).name || 'aktivnost.tcx'): Promise<ParsedActivity> {
  const txt = await readText(file)
  const doc = new DOMParser().parseFromString(txt, 'application/xml')
  if (doc.querySelector('parsererror')) throw new Error('Neveljavna TCX datoteka.')
  const tps = Array.from(doc.getElementsByTagName('Trackpoint'))
  if (!tps.length) throw new Error('TCX ne vsebuje sledi.')
  const val = (el: Element, tag: string) => { const x = el.getElementsByTagName(tag)[0]; return x ? x.textContent!.trim() : null }
  const pts: LatLon[] = []; const hrs: number[] = []; let t0: string | null = null, t1: string | null = null, distM: number | null = null, elev = 0, lastEle: number | null = null
  for (const tp of tps) {
    const t = val(tp, 'Time'); if (t) { if (!t0) t0 = t; t1 = t }
    const pos = tp.getElementsByTagName('Position')[0]
    if (pos) { const la = +val(pos, 'LatitudeDegrees')!, lo = +val(pos, 'LongitudeDegrees')!; if (isValidLatLon([la, lo])) pts.push([la, lo]) }
    const ele = val(tp, 'AltitudeMeters'); if (ele != null) { const e = +ele; if (!isNaN(e)) { if (lastEle != null && e > lastEle) elev += e - lastEle; lastEle = e } }
    const d = val(tp, 'DistanceMeters'); if (d != null && !isNaN(+d)) distM = +d
    const hrEl = tp.getElementsByTagName('HeartRateBpm')[0]; if (hrEl) { const v = +val(hrEl, 'Value')!; if (v > 40 && v < 230) hrs.push(v) }
  }
  const durationMin = t0 && t1 ? Math.max(1, Math.round((new Date(t1).getTime() - new Date(t0).getTime()) / 60000)) : null
  const distKm = distM != null ? +(distM / 1000).toFixed(1) : null
  const spd = durationMin && distKm ? distKm / (durationMin / 60) : null
  const actEl = doc.getElementsByTagName('Activity')[0]
  return {
    sport: guessSport(spd, actEl?.getAttribute('Sport') || null), name: fileName.replace(/\.tcx(\.gz)?$/i, ''), start: t0 ? new Date(t0).toISOString() : null, date: localDate(t0),
    distKm, durationMin, elevM: Math.round(elev), avgHr: hrs.length ? Math.round(hrs.reduce((a, b) => a + b, 0) / hrs.length) : null, maxHr: hrs.length ? Math.max(...hrs) : null,
    avgPower: null, kcal: null, polyline: finish(pts), deviceName: null, fileName,
  }
}

/* ---------------- FIT ---------------- */
let fitMod: any = null
export async function parseFit(file: File | Blob, fileName = (file as File).name || 'aktivnost.fit'): Promise<ParsedActivity> {
  const buf = await readArrayBuffer(file)
  if (!fitMod) fitMod = await import('fit-file-parser')
  const FitParser = fitMod.default || fitMod.FitParser || fitMod
  const fp = new FitParser({ force: true, speedUnit: 'km/h', lengthUnit: 'km', elapsedRecordField: true })
  const data: any = await new Promise((res, rej) => fp.parse(buf, (err: any, d: any) => (err || !d) ? rej(new Error(String(err || 'FIT ni berljiv'))) : res(d)))
  const ss = (data.sessions && data.sessions[0]) || (data.activity?.sessions?.[0]) || {}
  const start = ss.start_time ? new Date(ss.start_time) : null
  const distKm = ss.total_distance != null ? +(+ss.total_distance).toFixed(1) : null
  const durationMin = Math.round(((ss.total_timer_time || ss.total_elapsed_time || 0)) / 60) || null
  let recs: any[] = Array.isArray(data.records) ? data.records : []
  if (!recs.length) {
    const laps = ss.laps || data.activity?.sessions?.[0]?.laps || []
    for (const lp of laps) if (Array.isArray(lp.records)) recs = recs.concat(lp.records)
  }
  const pts: LatLon[] = recs.filter(x => x && x.position_lat != null && x.position_long != null).map(x => [+x.position_lat, +x.position_long] as LatLon)
  const dev = (data.device_infos || []).find((d: any) => d && d.manufacturer)
  const spd = distKm && durationMin ? distKm / (durationMin / 60) : null
  return {
    sport: guessSport(spd, String(ss.sport || data.sport || '')), name: fileName.replace(/\.fit(\.gz)?$/i, ''), start: start ? start.toISOString() : null, date: localDate(start ? start.toISOString() : null),
    distKm, durationMin, elevM: ss.total_ascent != null ? Math.round(ss.total_ascent) : null, avgHr: ss.avg_heart_rate ? Math.round(ss.avg_heart_rate) : null,
    maxHr: ss.max_heart_rate ? Math.round(ss.max_heart_rate) : null, avgPower: ss.avg_power ? Math.round(ss.avg_power) : null, kcal: ss.total_calories ? Math.round(ss.total_calories) : null,
    polyline: finish(pts), deviceName: dev ? String(dev.manufacturer) + (dev.product_name ? ' ' + dev.product_name : '') : null, fileName,
  }
}

/* ---------------- gzip ---------------- */
export async function gunzip(blob: Blob, name: string): Promise<File> {
  if (typeof DecompressionStream === 'undefined') throw new Error('Brskalnik ne zna odpakirati .gz — uporabi namizni Chrome ali Safari 16.4+.')
  const ds = new DecompressionStream('gzip')
  const out = await new Response(blob.stream().pipeThrough(ds)).blob()
  return new File([out], name.replace(/\.gz$/i, ''), { type: 'application/octet-stream' })
}

/** Razčleni katero koli podprto datoteko po končnici (po potrebi odpakira .gz). */
export async function parseAny(file: File): Promise<ParsedActivity> {
  let f = file
  let n = f.name.toLowerCase()
  if (n.endsWith('.gz')) { f = await gunzip(f, f.name); n = f.name.toLowerCase() }
  if (n.endsWith('.gpx')) return parseGpx(f, f.name)
  if (n.endsWith('.tcx')) return parseTcx(f, f.name)
  if (n.endsWith('.fit')) return parseFit(f, f.name)
  throw new Error('Nepodprta datoteka: ' + file.name)
}

export const ACTIVITY_FILE_RE = /\.(fit|gpx|tcx)(\.gz)?$/i

/** Iz surovega razčlenjenega zapisa naredi Activity z izvorom in zastavicami. TSS doda klicatelj (potrebuje profil). */
export function toActivity(p: ParsedActivity, source: ActivitySource, tss: number | null): Activity {
  const now = new Date().toISOString()
  return {
    id: uid(), source, originHint: null, deviceName: p.deviceName, sport: p.sport, date: p.date, start: p.start, name: p.name,
    distKm: p.distKm, durationMin: p.durationMin, elevM: p.elevM, avgHr: p.avgHr, maxHr: p.maxHr, avgPower: p.avgPower, speedKmh: p.distKm && p.durationMin ? +(p.distKm / (p.durationMin / 60)).toFixed(1) : null,
    kcal: p.kcal, tss, polyline: p.polyline, ...deriveFlags(source, null), ext: { fileName: p.fileName }, createdAt: now, updatedAt: now,
  }
}
