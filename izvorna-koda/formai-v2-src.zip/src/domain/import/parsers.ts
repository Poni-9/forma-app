import type { Activity, ActivitySource, Sport } from '../types'
import { isAutoName, autoName } from './autoName'
import { encodePolyline, haversineM, isValidLatLon, thinTrack, type LatLon } from './polyline'
import { deriveFlags, isStravaFileText, STRAVA_ORIGIN } from './provenance'
import { sportOfType } from '../training/load'

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)

/** Surov rezultat razčlenjevanja — brez TSS (ta potrebuje profil) in brez zastavic. */
export interface ParsedActivity {
  sport: Sport
  name: string
  start: string | null
  date: string
  distKm: number | null
  durationMin: number | null
  elevM: number | null
  avgHr: number | null
  maxHr: number | null
  avgPower: number | null
  kcal: number | null
  polyline: string | null
  deviceName: string | null
  fileName: string
  /** izvor datoteke, če ga poznamo: 'STRAVA' = izvoz iz Strave (GPX creator, Stravin arhiv) → nikoli v AI */
  originHint?: string | null
  /** (v3.51) čas s postanki (durationMin je čas gibanja), ko se razlikujeta */
  elapsedMin?: number | null
  /** (v3.51) vati so z merilnika (iz datoteke) */
  deviceWatts?: boolean | null
}

/** Blob → besedilo; ne zanaša se na Blob.text() (manjka v starejših Safarijih in v jsdom). */
export function readText(blob: Blob): Promise<string> {
  if (typeof (blob as any).text === 'function') return (blob as any).text()
  return new Promise((res, rej) => {
    const fr = new FileReader()
    fr.onload = () => res(String(fr.result || ''))
    fr.onerror = () => rej(fr.error || new Error('Branje datoteke ni uspelo.'))
    fr.readAsText(blob)
  })
}
export function readArrayBuffer(blob: Blob): Promise<ArrayBuffer> {
  if (typeof (blob as any).arrayBuffer === 'function') return (blob as any).arrayBuffer()
  return new Promise((res, rej) => {
    const fr = new FileReader()
    fr.onload = () => res(fr.result as ArrayBuffer)
    fr.onerror = () => rej(fr.error || new Error('Branje datoteke ni uspelo.'))
    fr.readAsArrayBuffer(blob)
  })
}

function localDate(iso: string | null): string {
  const d = iso ? new Date(iso) : new Date()
  const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, '0'), dd = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${dd}`
}

function finish(pts: LatLon[]): string | null {
  const th = thinTrack(pts.filter(isValidLatLon), 20)
  return th.length > 1 ? encodePolyline(th) : null
}

/** (v3.50) Garminova vadba moči v FIT ima šport »training« (sub_sport strength_training), naprave za fitnes »fitness_equipment«. */
const STRENGTH_RE = /(^|[^a-z])training|strength|fitness_equipment|hiit/
/** (v3.50) kardio naprave (eliptični, stopnice, veslo) in dihanje, joga, pilates niso moč — prej so odkljukali dan moči */
const CARDIO_RE = /elliptical|stair|rowing|(^|[^a-z])row([^a-z]|$)|breathing|yoga|pilates|cardio|meditation|mobility|flexibility|stretch/
/**
 * (v3.51) Znani športi, ki niso kolo, tek, hoja, moč ne plavanje (smučanje, drsanje, veslanje, žoge, plezanje …), ostanejo
 * »drugo«. Prej je odločila hitrost: smuk 40 km/h = kolo, tek na smučeh = tek, kajak = tek, nogomet = hoja.
 */
const OTHER_RE = /ski|snowboard|skat|paddl|kayak|canoe|sail|surf|soccer|football|futsal|tennis|squash|badminton|padel|basket|volley|handball|hockey|rugby|cricket|lacrosse|climb|boulder|golf|boxing|martial|mountaineer|motor|driving|horse|wakeboard|kite/
export function guessSport(spd: number | null, hint: string | null, distKm: number | null = null): Sport {
  if (hint && CARDIO_RE.test(hint.toLowerCase())) return 'drugo'
  if (hint && OTHER_RE.test(hint.toLowerCase())) return 'drugo'
  const h = hint ? sportOfType(hint) : null
  if (h && h !== 'drugo') return h
  // (v3.50) moč iz ure ni kolo (prej: brez hitrosti → »kolo«, vadba moči je štela kot vožnja)
  if (hint && STRENGTH_RE.test(hint.toLowerCase())) return 'moc'
  if (spd == null) return distKm ? 'kolo' : 'drugo'
  return spd < 7 ? 'pohod' : spd < 14 ? 'tek' : 'kolo'
}

/**
 * (v3.50) Napaka branja z razlogom (Uvoz pokaže ime datoteke in zakaj). Sporočilo je kratko, z malo začetnico.
 * offline-lib: bralnik .fit ali .zip še ni na napravi in ni povezave (datoteka je v redu).
 */
export type ImportWhy = 'unsupported' | 'route' | 'notrack' | 'invalid' | 'offline-lib'
export class ImportError extends Error {
  constructor(readonly why: ImportWhy, message: string) { super(message); this.name = 'ImportError' }
}
export const IMPORT_WHY: Record<ImportWhy, string> = {
  unsupported: 'nepodprta vrsta — sprejmem .fit, .gpx, .tcx (tudi .gz) in .zip',
  route: 'to je pot brez časa (načrtovana trasa), ne vožnja — vožnjo izvozi iz ure ali jo vpiši ročno',
  notrack: 'datoteka nima sledi',
  invalid: 'datoteka je poškodovana ali ni prave vrste',
  'offline-lib': 'za prvo branje te vrste datotek rabim povezavo — poskusi, ko boš na spletu',
}
/** Razlog iz napake (ImportError ali tuja napaka knjižnice, ki je ne kažemo). */
export function whyOf(e: unknown): string {
  return e instanceof ImportError ? e.message : IMPORT_WHY.invalid
}
/** »moja.csv: nepodprta vrsta — …« za prvo napako; pri več še »(in še 2)«. */
export function importFailText(fails: readonly { name: string; why: string }[]): string {
  const f = fails[0]
  return f ? `${f.name}: ${f.why}${fails.length > 1 ? ` (in še ${fails.length - 1})` : ''}.` : ''
}

/**
 * (v3.50) Vzpon kot pri Garminu in Stravi: višina zglajena (drseče povprečje 5 točk), šteje le dvig nad 3 m od zadnjega
 * dna. Prej je štel vsak šum GPS višine: ravna vožnja s ±2 m na točko je dobila 1 200 m vzpona.
 */
export function climbOf(eles: readonly number[]): number {
  if (eles.length < 2) return 0
  const sm = eles.map((_, i) => {
    let s = 0, n = 0
    for (let j = Math.max(0, i - 2); j <= Math.min(eles.length - 1, i + 2); j++) { s += eles[j]!; n++ }
    return s / n
  })
  let up = 0, ref = sm[0]!
  for (const e of sm) {
    if (e > ref + 3) { up += e - ref; ref = e }
    else if (e < ref) ref = e
  }
  return Math.round(up)
}

/**
 * (v3.51) Čas gibanja iz točk sledi (kot FIT »timer time«): odsek šteje, ko se premikaš hitreje od 1,5 km/h. Prej je
 * GPX/TCX štel od prve do zadnje točke — vožnja z uro kave je bila 2 h s 15 km/h (ure tedna, kalorije in TSS napihnjeni).
 * Brez razdalje med točkami (trenažer, moč) ali pod 0,5 km gibanja velja ves čas (null).
 */
export function movingMinOf(segs: readonly { dt: number; dm: number | null; de?: number | null }[]): number | null {
  let mov = 0, dist = 0, known = 0
  // (v3.51) počasen odsek na strmem (vsaj 3 m višine na minuto v ±2 min okoli njega) je vzpon ali spust, ne postanek —
  // prej je ura po ferati s 1,2 km/h vodoravno izpadla (pohod 180 → 120 min); šum višine med postankom se v oknu izniči
  const n = segs.length, ct = new Array<number>(n + 1).fill(0), ce = new Array<number>(n + 1).fill(0)
  segs.forEach((x, i) => { ct[i + 1] = ct[i]! + (x.dt > 0 ? x.dt : 0); ce[i + 1] = ce[i]! + (x.dt > 0 && x.de != null && Number.isFinite(x.de) ? x.de : 0) })
  let lo = 0, hi = 0
  for (let i = 0; i < n; i++) {
    const { dt, dm } = segs[i]!
    if (!(dt > 0) || dm == null) continue
    known++
    if ((dm / dt) * 3.6 > 1.5) { mov += dt; dist += dm; continue }
    while (ct[lo + 1]! < ct[i]! - CLIMB_WIN_S) lo++
    if (hi < i) hi = i
    while (hi < n - 1 && ct[hi + 1]! <= ct[i + 1]! + CLIMB_WIN_S) hi++
    const span = ct[hi + 1]! - ct[lo]!
    if (span > 0 && Math.abs(ce[hi + 1]! - ce[lo]!) / (span / 60) >= CLIMB_M_PER_MIN) { mov += dt; dist += dm }
  }
  if (!known || dist < 500 || mov < 60) return null
  return Math.max(1, Math.round(mov / 60))
}
/** (v3.51) navpična hitrost, pri kateri je počasen odsek vzpon (strm pohod ~5–8 m na minuto), in pol okna v sekundah */
const CLIMB_M_PER_MIN = 3, CLIMB_WIN_S = 120
/** (v3.51) Povprečni vati iz točk, ko jih ima vsaj polovica točk; sicer null. */
function avgWatts(ws: readonly number[], points: number): number | null {
  if (!ws.length || ws.length < points * 0.5) return null
  const a = Math.round(ws.reduce((t, v) => t + v, 0) / ws.length)
  return a > 0 ? a : null
}
const watt = (el: Element): number | null => { const v = +String(el.textContent || '').trim(); return Number.isFinite(v) && v >= 0 && v <= 2000 ? v : null }

// (v3.51) imena v svojem majhnem modulu — intervals.icu jih rabi ob zagonu, razčlenjevalniki (GPX, FIT, TCX) pa ne
export { isAutoName, autoName } from './autoName'
const nameOr = (n: string, sport: Sport, distKm: number | null, durationMin: number | null) => (isAutoName(n) ? autoName(sport, distKm, durationMin) : n)

/* ---------------- GPX ---------------- */
export async function parseGpx(file: File | Blob, fileName = (file as File).name || 'aktivnost.gpx'): Promise<ParsedActivity> {
  const txt = await readText(file)
  const strava = isStravaFileText(txt.slice(0, 4000))
  const doc = new DOMParser().parseFromString(txt, 'application/xml')
  if (doc.querySelector('parsererror')) throw new ImportError('invalid', 'datoteka ni veljaven GPX')
  const tp = Array.from(doc.getElementsByTagName('trkpt'))
  // samo točke poti (rtept) = načrtovana trasa
  if (tp.length < 2) { const route = doc.getElementsByTagName('rtept').length > 1; throw new ImportError(route ? 'route' : 'notrack', IMPORT_WHY[route ? 'route' : 'notrack']) }
  let distM = 0
  const eles: number[] = []
  const hrs: number[] = []; let t0: string | null = null, t1: string | null = null
  let prev: LatLon | null = null
  const pts: LatLon[] = []
  // (v3.51) odseki za čas gibanja in vati iz razširitev (<power>, <gpxtpx:power>)
  const segs: { dt: number; dm: number | null; de: number | null }[] = [], ws: number[] = []
  let prevT: number | null = null, prevAt: LatLon | null = null, prevE: number | null = null
  for (const p of tp) {
    const lat = +p.getAttribute('lat')!, lon = +p.getAttribute('lon')!
    const cur: LatLon = [lat, lon]
    const ok = isValidLatLon(cur)
    if (ok) { pts.push(cur); if (prev) distM += haversineM(prev, cur); prev = cur }
    const eleEl = p.getElementsByTagName('ele')[0]
    let eNow: number | null = null
    if (eleEl) { const e = +eleEl.textContent!; if (!isNaN(e)) { eles.push(e); eNow = e } }
    const tEl = p.getElementsByTagName('time')[0]
    if (tEl) { if (!t0) t0 = tEl.textContent; t1 = tEl.textContent }
    const tm = tEl ? Date.parse(tEl.textContent || '') : NaN
    if (Number.isFinite(tm)) {
      if (prevT != null) segs.push({ dt: (tm - prevT) / 1000, dm: ok && prevAt ? haversineM(prevAt, cur) : null, de: eNow != null && prevE != null ? eNow - prevE : null })
      prevT = tm; if (ok) prevAt = cur; if (eNow != null) prevE = eNow
    }
    for (const el of Array.from(p.getElementsByTagName('*'))) {
      if (el.localName === 'hr') { const v = +el.textContent!; if (v > 40 && v < 230) hrs.push(v) }
      else if (el.localName === 'power') { const v = watt(el); if (v != null) ws.push(v) }
    }
  }
  // (v3.50) pot brez časa (načrtovana trasa iz Komoota ali Strave) ni vožnja — prej je postala današnja vožnja brez trajanja
  if (!t0 || !t1 || t0 === t1) throw new ImportError('route', IMPORT_WHY.route)
  const elapsedMin = Math.max(1, Math.round((new Date(t1).getTime() - new Date(t0).getTime()) / 60000))
  const moving = movingMinOf(segs)
  const durationMin = moving != null && moving < elapsedMin ? moving : elapsedMin
  const avgPower = avgWatts(ws, tp.length)
  const distKm = +(distM / 1000).toFixed(1)
  const spd = durationMin && distKm ? distKm / (durationMin / 60) : null
  let name = 'GPX aktivnost'
  const nEl = doc.getElementsByTagName('name')[0]; if (nEl && nEl.textContent!.trim()) name = nEl.textContent!.trim().slice(0, 60)
  const typeEl = doc.getElementsByTagName('type')[0]
  const sport = guessSport(spd, typeEl?.textContent || null, distKm)
  return {
    sport, name: nameOr(name, sport, distKm, durationMin), start: new Date(t0).toISOString(), date: localDate(t0),
    distKm, durationMin, elevM: climbOf(eles), avgHr: hrs.length ? Math.round(hrs.reduce((a, b) => a + b, 0) / hrs.length) : null,
    maxHr: hrs.length ? Math.max(...hrs) : null, avgPower, kcal: null, polyline: finish(pts), deviceName: null, fileName,
    ...(strava ? { originHint: STRAVA_ORIGIN } : {}), ...(durationMin < elapsedMin ? { elapsedMin } : {}), ...(avgPower ? { deviceWatts: true } : {}),
  }
}

/* ---------------- TCX ---------------- */
export async function parseTcx(file: File | Blob, fileName = (file as File).name || 'aktivnost.tcx'): Promise<ParsedActivity> {
  const txt = await readText(file)
  const strava = isStravaFileText(txt.slice(0, 4000)) || isStravaFileText(txt.slice(-4000))
  const doc = new DOMParser().parseFromString(txt, 'application/xml')
  if (doc.querySelector('parsererror')) throw new ImportError('invalid', 'datoteka ni veljaven TCX')
  const tps = Array.from(doc.getElementsByTagName('Trackpoint'))
  if (!tps.length) throw new ImportError('notrack', IMPORT_WHY.notrack)
  const val = (el: Element, tag: string) => { const x = el.getElementsByTagName(tag)[0]; return x ? x.textContent!.trim() : null }
  const pts: LatLon[] = []; const hrs: number[] = []; let t0: string | null = null, t1: string | null = null, distM: number | null = null
  const eles: number[] = []
  // (v3.51) odseki za čas gibanja (razdalja iz DistanceMeters, sicer iz položaja) in vati (<Watts>, tudi ns3:Watts)
  const segs: { dt: number; dm: number | null; de: number | null }[] = [], ws: number[] = []
  let prevT: number | null = null, prevD: number | null = null, prevAt: LatLon | null = null, prevE: number | null = null
  for (const tp of tps) {
    const t = val(tp, 'Time'); if (t) { if (!t0) t0 = t; t1 = t }
    const pos = tp.getElementsByTagName('Position')[0]
    let at: LatLon | null = null
    if (pos) { const la = +val(pos, 'LatitudeDegrees')!, lo = +val(pos, 'LongitudeDegrees')!; if (isValidLatLon([la, lo])) { at = [la, lo]; pts.push(at) } }
    const ele = val(tp, 'AltitudeMeters'); let eNow: number | null = null; if (ele != null) { const e = +ele; if (!isNaN(e)) { eles.push(e); eNow = e } }
    const d = val(tp, 'DistanceMeters'); const dNow = d != null && !isNaN(+d) ? +d : null
    if (dNow != null) distM = dNow
    const hrEl = tp.getElementsByTagName('HeartRateBpm')[0]; if (hrEl) { const v = +val(hrEl, 'Value')!; if (v > 40 && v < 230) hrs.push(v) }
    for (const el of Array.from(tp.getElementsByTagName('*'))) if (el.localName === 'Watts') { const v = watt(el); if (v != null) ws.push(v); break }
    const tm = t ? Date.parse(t) : NaN
    if (Number.isFinite(tm)) {
      if (prevT != null) segs.push({ dt: (tm - prevT) / 1000, dm: dNow != null && prevD != null ? Math.max(0, dNow - prevD) : at && prevAt ? haversineM(prevAt, at) : null, de: eNow != null && prevE != null ? eNow - prevE : null })
      prevT = tm
      if (eNow != null) prevE = eNow
      if (dNow != null) prevD = dNow
      if (at) prevAt = at
    }
  }
  // (v3.50) trasa (Course) brez časa ni vadba
  if (!t0 || !t1 || t0 === t1) throw new ImportError('route', IMPORT_WHY.route)
  const elapsedMin = Math.max(1, Math.round((new Date(t1).getTime() - new Date(t0).getTime()) / 60000))
  const moving = movingMinOf(segs)
  const durationMin = moving != null && moving < elapsedMin ? moving : elapsedMin
  const avgPower = avgWatts(ws, tps.length)
  // (v3.51) kalorije z ure: vsota krogov (<Lap><Calories>) — prej jih je Prehrana ocenila sama
  const lapKcal = Array.from(doc.getElementsByTagName('Lap')).reduce((s, lap) => {
    const c = Array.from(lap.children).find(x => x.localName === 'Calories'), v = c ? +String(c.textContent || '').trim() : NaN
    return Number.isFinite(v) && v > 0 ? s + v : s
  }, 0)
  const kcal = lapKcal >= 50 && lapKcal <= 10000 ? Math.round(lapKcal) : null
  const distKm = distM != null ? +(distM / 1000).toFixed(1) : null
  const spd = durationMin && distKm ? distKm / (durationMin / 60) : null
  const actEl = doc.getElementsByTagName('Activity')[0]
  const sport = guessSport(spd, actEl?.getAttribute('Sport') || null, distKm)
  return {
    sport, name: nameOr(fileName.replace(/\.tcx(\.gz)?$/i, ''), sport, distKm, durationMin), start: new Date(t0).toISOString(), date: localDate(t0),
    distKm, durationMin, elevM: climbOf(eles), avgHr: hrs.length ? Math.round(hrs.reduce((a, b) => a + b, 0) / hrs.length) : null, maxHr: hrs.length ? Math.max(...hrs) : null,
    avgPower, kcal, polyline: finish(pts), deviceName: null, fileName,
    ...(strava ? { originHint: STRAVA_ORIGIN } : {}), ...(durationMin < elapsedMin ? { elapsedMin } : {}), ...(avgPower ? { deviceWatts: true } : {}),
  }
}

/* ---------------- FIT ---------------- */
let fitMod: any = null
/** nalaganje bralnika .fit (testi ga zamenjajo, da preverijo brez povezave) */
let fitLoader: () => Promise<any> = () => import('fit-file-parser')
export function setFitLoaderForTests(f: (() => Promise<any>) | null): void { fitLoader = f || (() => import('fit-file-parser')); fitMod = null }
export async function parseFit(file: File | Blob, fileName = (file as File).name || 'aktivnost.fit'): Promise<ParsedActivity> {
  const buf = await readArrayBuffer(file)
  // (v3.50) bralnik ni v predpomnilniku namestitve: brez povezave to ni »neberljiva datoteka«
  if (!fitMod) { try { fitMod = await fitLoader() } catch { throw new ImportError('offline-lib', IMPORT_WHY['offline-lib']) } }
  const FitParser = fitMod.default || fitMod.FitParser || fitMod
  const fp = new FitParser({ force: true, speedUnit: 'km/h', lengthUnit: 'km', elapsedRecordField: true })
  const data: any = await new Promise((res, rej) => fp.parse(buf, (err: any, d: any) => (err || !d) ? rej(new ImportError('invalid', 'datoteka ni veljaven FIT')) : res(d)))
  const ss = (data.sessions && data.sessions[0]) || (data.activity?.sessions?.[0]) || {}
  const start = ss.start_time ? new Date(ss.start_time) : null
  const distKm = ss.total_distance != null ? +(+ss.total_distance).toFixed(1) : null
  const durationMin = Math.round(((ss.total_timer_time || ss.total_elapsed_time || 0)) / 60) || null
  let recs: any[] = Array.isArray(data.records) ? data.records : []
  if (!recs.length) {
    const laps = ss.laps || data.activity?.sessions?.[0]?.laps || []
    for (const lp of laps) if (Array.isArray(lp.records)) recs = recs.concat(lp.records)
  }
  const pts: LatLon[] = recs.filter(x => x && x.position_lat != null && x.position_long != null).map(x => [+x.position_lat, +x.position_long] as LatLon)
  const dev = (data.device_infos || []).find((d: any) => d && d.manufacturer)
  const spd = distKm && durationMin ? distKm / (durationMin / 60) : null
  // (v3.50) podvrsta najprej: strength_training → moč, indoor_cycling → kolo, treadmill → tek
  const sub = String(ss.sub_sport || '').toLowerCase()
  const sport = guessSport(spd, [sub && sub !== 'generic' ? sub : '', String(ss.sport || data.sport || '')].filter(Boolean).join(' '), distKm)
  return {
    sport, name: nameOr(fileName.replace(/\.fit(\.gz)?$/i, ''), sport, distKm, durationMin), start: start ? start.toISOString() : null, date: localDate(start ? start.toISOString() : null),
    distKm, durationMin, elevM: ss.total_ascent != null ? Math.round(ss.total_ascent) : null, avgHr: ss.avg_heart_rate ? Math.round(ss.avg_heart_rate) : null,
    maxHr: ss.max_heart_rate ? Math.round(ss.max_heart_rate) : null, avgPower: ss.avg_power ? Math.round(ss.avg_power) : null, kcal: ss.total_calories ? Math.round(ss.total_calories) : null,
    polyline: finish(pts), deviceName: dev ? String(dev.manufacturer) + (dev.product_name ? ' ' + dev.product_name : '') : null, fileName,
  }
}

/* ---------------- gzip ---------------- */
export async function gunzip(blob: Blob, name: string): Promise<File> {
  if (typeof DecompressionStream === 'undefined') throw new ImportError('unsupported', 'brskalnik ne zna odpakirati .gz — uporabi namizni Chrome ali Safari 16.4+')
  const ds = new DecompressionStream('gzip')
  const out = await new Response(blob.stream().pipeThrough(ds)).blob()
  return new File([out], name.replace(/\.gz$/i, ''), { type: 'application/octet-stream' })
}

/** Razčleni katero koli podprto datoteko po končnici (po potrebi odpakira .gz). */
export async function parseAny(file: File): Promise<ParsedActivity> {
  let f = file
  let n = f.name.toLowerCase()
  if (n.endsWith('.gz')) { f = await gunzip(f, f.name); n = f.name.toLowerCase() }
  if (n.endsWith('.gpx')) return parseGpx(f, f.name)
  if (n.endsWith('.tcx')) return parseTcx(f, f.name)
  if (n.endsWith('.fit')) return parseFit(f, f.name)
  throw new ImportError('unsupported', IMPORT_WHY.unsupported)
}

export const ACTIVITY_FILE_RE = /\.(fit|gpx|tcx)(\.gz)?$/i

/** Iz surovega razčlenjenega zapisa naredi Activity z izvorom in zastavicami. TSS doda klicatelj (potrebuje profil). */
export function toActivity(p: ParsedActivity, source: ActivitySource, tss: number | null): Activity {
  const now = new Date().toISOString()
  return {
    id: uid(), source, originHint: p.originHint ?? null, deviceName: p.deviceName, sport: p.sport, date: p.date, start: p.start, name: p.name,
    distKm: p.distKm, durationMin: p.durationMin, elevM: p.elevM, avgHr: p.avgHr, maxHr: p.maxHr, avgPower: p.avgPower, speedKmh: p.distKm && p.durationMin ? +(p.distKm / (p.durationMin / 60)).toFixed(1) : null,
    kcal: p.kcal, tss, polyline: p.polyline, ...deriveFlags(source, p.originHint ?? null), ext: { fileName: p.fileName }, createdAt: now, updatedAt: now,
    ...(p.elapsedMin != null ? { elapsedMin: p.elapsedMin } : {}), ...(p.deviceWatts != null ? { deviceWatts: p.deviceWatts } : {}),
  }
}
