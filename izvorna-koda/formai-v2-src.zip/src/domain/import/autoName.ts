import type { Sport } from '../types'

/* (v3.51) iz parsers.ts: intervals.icu (začetni paket) rabi samo imena — razčlenjevalniki se naložijo z Uvozom */
const SPORT_NAME: Record<Sport, string> = { kolo: 'Kolo', tek: 'Tek', pohod: 'Hoja', moc: 'Moč', plavanje: 'Plavanje', drugo: 'Vadba' }
/** (v3.50) Ime datoteke iz ure ali arhiva, ki ni ime (»1234567890«, »12345678_ACTIVITY«, »2026-05-10-08-15-00«). */
export function isAutoName(s: string | null | undefined): boolean {
  const t = String(s || '').trim()
  return !t || /^[\d\s_.:T-]+$/i.test(t) || /^\d+_ACTIVITY$/i.test(t) || /^activity[_ -]?\d+$/i.test(t) || t === 'GPX aktivnost'
}
/** (v3.50) Ime iz športa in razdalje: »Kolo 62 km«, »Tek 8,2 km«, »Moč 45 min«. */
export function autoName(sport: Sport, distKm: number | null | undefined, durationMin: number | null | undefined): string {
  const l = SPORT_NAME[sport] || 'Vadba'
  if (distKm && distKm >= 0.5 && sport !== 'moc') return `${l} ${distKm >= 20 ? Math.round(distKm) : String(Math.round(distKm * 10) / 10).replace('.', ',')} km`
  if (durationMin && durationMin > 0) return `${l} ${Math.round(durationMin)} min`
  return l
}
