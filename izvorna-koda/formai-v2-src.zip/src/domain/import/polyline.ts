/* Google encoded polyline (1e-5) + redčenje sledi. Preverjeno proti kanoničnemu testnemu vektorju. */

export type LatLon = [number, number]

export function decodePolyline(str: string): LatLon[] {
  let i = 0, lat = 0, lng = 0
  const pts: LatLon[] = []
  while (i < str.length) {
    let b: number, sh = 0, res = 0
    do { b = str.charCodeAt(i++) - 63; res |= (b & 0x1f) << sh; sh += 5 } while (b >= 0x20)
    lat += (res & 1) ? ~(res >> 1) : (res >> 1)
    sh = 0; res = 0
    do { b = str.charCodeAt(i++) - 63; res |= (b & 0x1f) << sh; sh += 5 } while (b >= 0x20)
    lng += (res & 1) ? ~(res >> 1) : (res >> 1)
    pts.push([lat / 1e5, lng / 1e5])
  }
  return pts
}

export function encodePolyline(pts: readonly LatLon[]): string {
  let out = '', pLat = 0, pLng = 0
  const chunk = (v: number) => {
    v = v < 0 ? ~(v << 1) : (v << 1)
    while (v >= 0x20) { out += String.fromCharCode((0x20 | (v & 0x1f)) + 63); v >>= 5 }
    out += String.fromCharCode(v + 63)
  }
  for (const p of pts) {
    const lat = Math.round(p[0] * 1e5), lng = Math.round(p[1] * 1e5)
    chunk(lat - pLat); chunk(lng - pLng)
    pLat = lat; pLng = lng
  }
  return out
}

const R = 6371000
const rad = (x: number) => x * Math.PI / 180

/** Razdalja v metrih (haversine). */
export function haversineM(a: LatLon, b: LatLon): number {
  const dLat = rad(b[0] - a[0]), dLon = rad(b[1] - a[1])
  const s = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a[0])) * Math.cos(rad(b[0])) * Math.sin(dLon / 2) ** 2
  return 2 * R * Math.asin(Math.sqrt(s))
}

/** Skupna dolžina sledi v km. */
export function trackLengthKm(pts: readonly LatLon[]): number {
  let m = 0
  for (let i = 1; i < pts.length; i++) m += haversineM(pts[i - 1]!, pts[i]!)
  return m / 1000
}

/**
 * Redčenje sledi na ~minM metrov. GPX/FIT snemata vsako sekundo, kar je za našo rabo
 * (ujemanje na 25 m) 10× preveč točk. Začetek in konec sta vedno ohranjena.
 */
export function thinTrack(pts: readonly LatLon[], minM = 20): LatLon[] {
  if (pts.length < 2) return [...pts]
  const out: LatLon[] = [pts[0]!]
  for (const p of pts) {
    if (haversineM(out[out.length - 1]!, p) >= minM) out.push(p)
  }
  const last = pts[pts.length - 1]!
  if (out[out.length - 1] !== last) out.push(last)
  return out
}

export function isValidLatLon(p: readonly [number, number]): boolean {
  return Number.isFinite(p[0]) && Number.isFinite(p[1]) && Math.abs(p[0]) <= 90 && Math.abs(p[1]) <= 180 && !(p[0] === 0 && p[1] === 0)
}
