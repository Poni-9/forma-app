import type { Auth, User } from 'firebase/auth'
import type { Firestore } from 'firebase/firestore'

/* Javna konfiguracija projekta 'c-vaje' — ista kot jo uporablja stara aplikacija. */
const CFG = {
  apiKey: 'AIzaSyAY1WM27EA9qzxXpTQ6N5AkTgX3UFR1MUs',
  authDomain: 'c-vaje.firebaseapp.com',
  projectId: 'c-vaje',
  storageBucket: 'c-vaje.firebasestorage.app',
  messagingSenderId: '602565779369',
  appId: '1:602565779369:web:9a50487da9f4d515f1eeb8',
}

export type AuthUser = { uid: string; email: string | null; name: string | null; photo: string | null }

export interface FbCore {
  auth: Auth
  fs: Firestore
  authMod: typeof import('firebase/auth')
  fsMod: typeof import('firebase/firestore')
}

let booting: Promise<FbCore | null> | null = null

/** Leni zagon — SDK se prenese šele ob prvem klicu, zato začetni bundle ostane majhen.
 *  Ob napaki (brez omrežja, blokiran skript) vrne null in aplikacija dela naprej lokalno. */
export function core(): Promise<FbCore | null> {
  if (!booting) booting = init().catch(() => null)
  return booting
}

async function init(): Promise<FbCore | null> {
  const [appMod, authMod, fsMod] = await Promise.all([
    import('firebase/app'), import('firebase/auth'), import('firebase/firestore'),
  ])
  const app = appMod.getApps().length ? appMod.getApp() : appMod.initializeApp(CFG)
  const auth = authMod.getAuth(app)
  try { await authMod.setPersistence(auth, authMod.browserLocalPersistence) } catch { /* zasebni način */ }
  // po vrnitvi s preusmeritvene prijave je treba rezultat pobrati, sicer seja ne obstane
  try { await authMod.getRedirectResult(auth) } catch { /* ni preusmeritve */ }
  return { auth, fs: fsMod.getFirestore(app), authMod, fsMod }
}

function toUser(u: User | null): AuthUser | null {
  if (!u) return null
  return { uid: u.uid, email: u.email, name: u.displayName, photo: u.photoURL }
}

function codeOf(e: unknown): string {
  const c = (e as { code?: unknown } | null)?.code
  return typeof c === 'string' ? c : ''
}

export function onAuth(cb: (u: AuthUser | null) => void): () => void {
  let off: (() => void) | null = null
  let dead = false
  void core().then(c => {
    if (dead) return
    if (!c) { cb(null); return }
    off = c.authMod.onAuthStateChanged(c.auth, u => { if (!dead) cb(toUser(u)) })
  })
  return () => { dead = true; if (off) { off(); off = null } }
}

export async function signInGoogle(): Promise<AuthUser | null> {
  const c = await core()
  if (!c) throw new Error('Prijava ni na voljo — ni povezave s strežnikom.')
  const prov = new c.authMod.GoogleAuthProvider()
  prov.setCustomParameters({ prompt: 'select_account' })
  try {
    const r = await c.authMod.signInWithPopup(c.auth, prov)
    return toUser(r.user)
  } catch (e) {
    const code = codeOf(e)
    if (code === 'auth/popup-closed-by-user' || code === 'auth/user-cancelled') return null
    // na mobilnih brskalnikih je pojavno okno pogosto blokirano — padec na preusmeritev
    if (code === 'auth/popup-blocked' || code === 'auth/cancelled-popup-request' || code === 'auth/operation-not-supported-in-this-environment') {
      try { await c.authMod.signInWithRedirect(c.auth, prov) } catch { /* stran se že preusmerja */ }
      return null
    }
    if (code === 'auth/network-request-failed') throw new Error('Prijava ni uspela — preveri povezavo.')
    throw new Error('Prijava ni uspela.')
  }
}

export async function signOutNow(): Promise<void> {
  const c = await core()
  if (!c) return
  try { await c.authMod.signOut(c.auth) } catch { /* seja se počisti ob ponovnem zagonu */ }
}

export async function idToken(): Promise<string | null> {
  const c = await core()
  if (!c) return null
  try { return (await c.auth.currentUser?.getIdToken()) || null } catch { return null }
}

/** Ali ima prijavljeni uporabnik neomejen AI (proUsers/{uid}.pro — piše ga samo lastnik v konzoli). */
export async function proFromFirestore(): Promise<boolean> {
  const c = await core()
  const u = c?.auth.currentUser
  if (!c || !u) return false
  try { const d = await c.fsMod.getDoc(c.fsMod.doc(c.fs, 'proUsers', u.uid)); return d.exists() && (d.data() as { pro?: unknown }).pro === true } catch { return false }
}

export async function currentUser(): Promise<AuthUser | null> {
  const c = await core()
  if (!c) return null
  try { return toUser(c.auth.currentUser) } catch { return null }
}

/** Izbris računa (GDPR). Skupaj z računom pobriše tudi dokument formaSync/{uid} — ta je vezan
 *  izključno na ta uid, zato po izbrisu računa ne bi bil več dosegljiv nikomur. */
export async function deleteAccount(): Promise<{ ok: boolean; reauth: boolean }> {
  const c = await core()
  if (!c) return { ok: false, reauth: false }
  const u = c.auth.currentUser
  if (!u) return { ok: false, reauth: false }
  try {
    try { await c.fsMod.deleteDoc(c.fsMod.doc(c.fs, 'formaSync', u.uid)) } catch { /* dokumenta morda ni */ }
    await c.authMod.deleteUser(u)
    return { ok: true, reauth: false }
  } catch (e) {
    if (codeOf(e) === 'auth/requires-recent-login') return { ok: false, reauth: true }
    return { ok: false, reauth: false }
  }
}
