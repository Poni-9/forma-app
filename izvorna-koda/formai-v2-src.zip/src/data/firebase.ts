import type { Auth, User } from 'firebase/auth'
import type { Firestore } from 'firebase/firestore'
import { PROXY } from '@/config'

/* Javna konfiguracija projekta 'c-vaje' — ista kot jo uporablja stara aplikacija. */
const CFG = {
  apiKey: 'AIzaSyAY1WM27EA9qzxXpTQ6N5AkTgX3UFR1MUs',
  authDomain: 'c-vaje.firebaseapp.com',
  projectId: 'c-vaje',
  storageBucket: 'c-vaje.firebasestorage.app',
  messagingSenderId: '602565779369',
  appId: '1:602565779369:web:9a50487da9f4d515f1eeb8',
}

export type AuthUser = { uid: string; email: string | null; name: string | null; photo: string | null }

export interface FbCore {
  auth: Auth
  fs: Firestore
  authMod: typeof import('firebase/auth')
  fsMod: typeof import('firebase/firestore')
}

let booting: Promise<FbCore | null> | null = null

/** Leni zagon — SDK se prenese šele ob prvem klicu, zato začetni bundle ostane majhen.
 *  Ob napaki (brez omrežja, blokiran skript) vrne null in aplikacija dela naprej lokalno;
 *  neuspeh se NE zapomni — naslednji klic poskusi znova. */
export function core(): Promise<FbCore | null> {
  if (!booting) {
    const p: Promise<FbCore | null> = init().catch(() => { if (booting === p) booting = null; return null })
    booting = p
  }
  return booting
}

async function init(): Promise<FbCore | null> {
  const [appMod, authMod, fsMod] = await Promise.all([
    import('firebase/app'), import('firebase/auth'), import('firebase/firestore'),
  ])
  const app = appMod.getApps().length ? appMod.getApp() : appMod.initializeApp(CFG)
  const auth = authMod.getAuth(app)
  try { await authMod.setPersistence(auth, authMod.browserLocalPersistence) } catch { /* zasebni način */ }
  // po vrnitvi s preusmeritvene prijave je treba rezultat pobrati, sicer seja ne obstane
  try { await authMod.getRedirectResult(auth) } catch { /* ni preusmeritve */ }
  return { auth, fs: fsMod.getFirestore(app), authMod, fsMod }
}

function toUser(u: User | null): AuthUser | null {
  if (!u) return null
  return { uid: u.uid, email: u.email, name: u.displayName, photo: u.photoURL }
}

function codeOf(e: unknown): string {
  const c = (e as { code?: unknown } | null)?.code
  return typeof c === 'string' ? c : ''
}

/** Stanje prijave. Če se Firebase ob zagonu ne naloži (brez omrežja), poskusi znova, ko je omrežje nazaj. */
export function onAuth(cb: (u: AuthUser | null) => void): () => void {
  let off: (() => void) | null = null
  let dead = false
  let offOnline: (() => void) | null = null
  const attach = () => {
    void core().then(c => {
      if (dead || off) return
      if (!c) {
        cb(null)
        if (!offOnline && typeof window !== 'undefined') {
          const again = () => { offOnline?.(); offOnline = null; attach() }
          window.addEventListener('online', again, { once: true })
          offOnline = () => window.removeEventListener('online', again)
        }
        return
      }
      off = c.authMod.onAuthStateChanged(c.auth, u => { if (!dead) cb(toUser(u)) })
    })
  }
  attach()
  return () => { dead = true; offOnline?.(); offOnline = null; if (off) { off(); off = null } }
}

export async function signInGoogle(): Promise<AuthUser | null> {
  const c = await core()
  if (!c) throw new Error('Prijava ni na voljo — ni povezave s strežnikom.')
  const prov = new c.authMod.GoogleAuthProvider()
  prov.setCustomParameters({ prompt: 'select_account' })
  try {
    const r = await c.authMod.signInWithPopup(c.auth, prov)
    return toUser(r.user)
  } catch (e) {
    const code = codeOf(e)
    if (code === 'auth/popup-closed-by-user' || code === 'auth/user-cancelled') return null
    // na mobilnih brskalnikih je pojavno okno pogosto blokirano — padec na preusmeritev
    if (code === 'auth/popup-blocked' || code === 'auth/cancelled-popup-request' || code === 'auth/operation-not-supported-in-this-environment') {
      try { await c.authMod.signInWithRedirect(c.auth, prov) } catch { /* stran se že preusmerja */ }
      return null
    }
    if (code === 'auth/network-request-failed') throw new Error('Prijava ni uspela — preveri povezavo.')
    throw new Error('Prijava ni uspela.')
  }
}

export async function signOutNow(): Promise<void> {
  const c = await core()
  if (!c) return
  try { await c.authMod.signOut(c.auth) } catch { /* seja se počisti ob ponovnem zagonu */ }
}

export async function idToken(force = false): Promise<string | null> {
  const c = await core()
  if (!c) return null
  try { return (await c.auth.currentUser?.getIdToken(force)) || null } catch { return null }
}

/** Ali ima prijavljeni uporabnik neomejen AI (proUsers/{uid}.pro — piše ga samo lastnik v konzoli). */
export async function proFromFirestore(): Promise<boolean> {
  const c = await core()
  const u = c?.auth.currentUser
  if (!c || !u) return false
  try { const d = await c.fsMod.getDoc(c.fsMod.doc(c.fs, 'proUsers', u.uid)); return d.exists() && (d.data() as { pro?: unknown }).pro === true } catch { return false }
}

export async function currentUser(): Promise<AuthUser | null> {
  const c = await core()
  if (!c) return null
  try { return toUser(c.auth.currentUser) } catch { return null }
}

/* ---------- izbris računa (GDPR) ---------- */

export interface DeleteResult {
  ok: boolean
  /** Google je zahteval svežo prijavo in je ponovna prijava odpovedala ali bila preklicana */
  reauth: boolean
  /** kratko pojasnilo za uporabnika (ob napaki) */
  error?: string
  /** 'server': strežnik je pobrisal vse (račun, oblak, AI kvote, plačila); 'client': samo oblak in račun (strežnik poti še nima) */
  via?: 'server' | 'client'
}

/**
 * Kljuke za izbris računa, ki jih nastavi store: pred izbrisom ustavi sinhronizacijo (sicer bi druga naprava ali
 * ta sama dokument takoj znova ustvarila), ob neuspehu jo zažene znova; pilotId gre strežniku (anonimni odgovori).
 */
export interface DeleteHooks { before?: () => void; failed?: () => void; pilotId?: () => string | null | undefined }
let hooks: DeleteHooks = {}
export function setAccountDeleteHooks(h: DeleteHooks): void { hooks = h }

/** Ponovna prijava z Googlom v pojavnem oknu (za dejanja, ki zahtevajo svežo prijavo). */
async function reauthGoogle(c: FbCore): Promise<boolean> {
  const u = c.auth.currentUser
  if (!u) return false
  try {
    const prov = new c.authMod.GoogleAuthProvider()
    prov.setCustomParameters({ prompt: 'select_account', ...(u.email ? { login_hint: u.email } : {}) })
    await c.authMod.reauthenticateWithPopup(u, prov)
    return true
  } catch { return false }
}

/** Stara pot (strežnik /account/delete še ni nameščen): dokument v oblaku + račun, s sveža prijavo ob zahtevi. */
async function deleteOnClient(c: FbCore): Promise<DeleteResult> {
  const u = c.auth.currentUser
  if (!u) return { ok: false, reauth: false, error: 'Nisi prijavljen.' }
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      try { await c.fsMod.deleteDoc(c.fsMod.doc(c.fs, 'formaSync', u.uid)) } catch { /* dokumenta morda ni */ }
      await c.authMod.deleteUser(u)
      return { ok: true, reauth: false, via: 'client' }
    } catch (e) {
      if (codeOf(e) === 'auth/requires-recent-login' && attempt === 0 && await reauthGoogle(c)) continue
      if (codeOf(e) === 'auth/requires-recent-login') return { ok: false, reauth: true, error: 'Google zahteva svežo prijavo — potrdi prijavo in ponovi izbris.' }
      return { ok: false, reauth: false, error: 'Izbris ni uspel — preveri povezavo in poskusi znova.' }
    }
  }
  return { ok: false, reauth: true, error: 'Google zahteva svežo prijavo — potrdi prijavo in ponovi izbris.' }
}

/**
 * Izbris računa (GDPR) prek strežnika: POST {PROXY}/account/delete z žetonom (Bearer) in {pilotId?}.
 * Strežnik pobriše račun, formaSync/{uid}, AI kvote in dnevnik, plačila; odgovor 403 {error:'reauth'} pomeni, da je
 * prijava starejša od 10 min → ponovna prijava z Googlom in še en poskus. 404 (pot še ni nameščena) → stara pot na odjemalcu.
 * Pred klicem se ustavi sinhronizacija (kljuka before), ob neuspehu se nadaljuje (kljuka failed).
 */
export async function deleteAccount(pilotId?: string | null): Promise<DeleteResult> {
  const c = await core()
  if (!c) return { ok: false, reauth: false, error: 'Ni povezave s strežnikom.' }
  if (!c.auth.currentUser) return { ok: false, reauth: false, error: 'Nisi prijavljen.' }
  hooks.before?.()
  const pid = pilotId ?? hooks.pilotId?.() ?? null
  let res: DeleteResult = { ok: false, reauth: false, error: 'Izbris ni uspel.' }
  try {
    for (let attempt = 0; attempt < 2; attempt++) {
      const u = c.auth.currentUser
      if (!u) { res = { ok: false, reauth: false, error: 'Nisi prijavljen.' }; break }
      let tok: string
      try { tok = await u.getIdToken(true) } catch { res = { ok: false, reauth: false, error: 'Ni povezave — izbris ni uspel.' }; break }
      let r: Response
      try {
        r = await fetch(`${PROXY}/account/delete`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tok}` },
          body: JSON.stringify(pid ? { pilotId: pid } : {}),
          signal: timeoutSignal(30_000),
        })
      } catch { res = { ok: false, reauth: false, error: 'Ni povezave s strežnikom — izbris ni uspel.' }; break }
      if (r.ok) { res = { ok: true, reauth: false, via: 'server' }; break }
      if (r.status === 404) { res = await deleteOnClient(c); break }
      if (r.status === 403) {
        const body = await r.json().catch(() => ({})) as { error?: string }
        if (body?.error === 'reauth') {
          if (attempt === 0 && await reauthGoogle(c)) continue
          res = { ok: false, reauth: true, error: 'Za izbris računa potrdi prijavo z Googlom in poskusi znova.' }
          break
        }
      }
      res = { ok: false, reauth: false, error: `Izbris ni uspel (strežnik ${r.status}).` }
      break
    }
  } catch { res = { ok: false, reauth: false, error: 'Izbris ni uspel.' } }
  if (!res.ok) hooks.failed?.()
  return res
}

/** AbortSignal s časovno omejitvijo (AbortSignal.timeout ali nadomestek za starejše brskalnike). */
export function timeoutSignal(ms: number): AbortSignal | undefined {
  try {
    const T = (AbortSignal as unknown as { timeout?: (ms: number) => AbortSignal }).timeout
    if (typeof T === 'function') return T.call(AbortSignal, ms)
    const ac = new AbortController()
    setTimeout(() => ac.abort(), ms)
    return ac.signal
  } catch { return undefined }
}
