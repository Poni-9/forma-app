import { db, getKV, setKV, KV } from './db'
import type { Activity, DailyCheckin, MealEntry, PlanDay, Profile, Settings } from '@/domain/types'
import { splitNew, richer } from '@/domain/import/dedupe'

/* ---------- profil / nastavitve ---------- */
export function defaultProfile(): Profile {
  const now = new Date().toISOString()
  return { sex: null, gear: { bikeOutdoor: true, trainer: false, noBike: false, dumbbells: false, dumbbellKg: null }, strength: { on: true, equipment: 'none' }, strengthDays: 2, goal: 'dirka', deficit: 400, neat: 1.4, proteinGkg: 1.8, onboardingDone: false, createdAt: now, updatedAt: now }
}
export function defaultSettings(): Settings { return { lang: 'sl', accentHex: '#A3E635', intervals: null } }

export async function loadProfile(): Promise<Profile> {
  const d = defaultProfile(), s = await getKV<Profile>(KV.profile)
  if (!s) return d
  // novejša polja (drog, deficit, cikel …) dobijo privzetke, shranjeno ima prednost
  return { ...d, ...s, gear: { ...d.gear, ...(s.gear || {}) }, strength: { ...d.strength, ...(s.strength || {}) } }
}
export async function saveProfile(p: Profile): Promise<Profile> { const v = { ...p, updatedAt: new Date().toISOString() }; await setKV(KV.profile, v); return v }
export async function loadSettings(): Promise<Settings> { return { ...defaultSettings(), ...((await getKV<Settings>(KV.settings)) || {}) } }
export async function saveSettings(s: Settings): Promise<void> { await setKV(KV.settings, s) }

/* ---------- aktivnosti ---------- */
export async function allActivities(): Promise<Activity[]> {
  const rows = await (await db()).getAll('activities')
  return rows.sort((a, b) => (b.date + (b.start || '')).localeCompare(a.date + (a.start || '')))
}
export async function activitiesBetween(fromIso: string, toIso: string): Promise<Activity[]> {
  return (await db()).getAllFromIndex('activities', 'by-date', IDBKeyRange.bound(fromIso, toIso))
}
export async function putActivity(a: Activity): Promise<void> { await (await db()).put('activities', { ...a, updatedAt: new Date().toISOString() }) }
export async function deleteActivity(id: string): Promise<void> { await (await db()).delete('activities', id) }

/** Množični vnos z deduplikacijo: ena transakcija, vrne števce za pošteno poročilo. */
export async function addActivities(candidates: Activity[]): Promise<{ added: number; dupes: number; upgraded: number }> {
  const existing = await allActivities()
  // 1) isti zapis iz istega vira (ponovni uvoz iz intervals.icu) — prepoznan po ID-ju vira, ne po času
  const refresh: [Activity, Activity][] = [], rest: Activity[] = []
  // (samo za svež uvoz z novim id-jem — kopija iz oblaka z istim id-jem gre po običajni poti)
  for (const c of candidates) { const e = existing.find(x => x.id !== c.id && sameExternal(x, c)); if (e) refresh.push([e, c]); else rest.push(c) }
  const { fresh, dupes } = splitNew(existing, rest)
  const d = await db()
  const tx = d.transaction('activities', 'readwrite')
  let upgraded = 0, same = 0
  for (const a of fresh) await tx.store.put(a)
  // Vir je avtoritativen za izvor in zastavice: »neznan izvor« postane Garmin (trener vidi) ali Strava (ne vidi).
  for (const [e, c] of refresh) {
    const changed = (e.originHint || null) !== (c.originHint || null) || e.aiEligible !== c.aiEligible || e.geoRetain !== c.geoRetain || (!e.polyline && !!c.polyline && c.geoRetain)
    if (!changed) { same++; continue }
    // podatki: nove vrednosti, kjer jih vir da (Stravini zapisi v intervals.icu so lahko okrnjeni); zastavice: VEDNO iz vira
    const m: Activity = { ...e }
    for (const [k, v] of Object.entries(c)) if (v !== null && v !== undefined) (m as unknown as Record<string, unknown>)[k] = v
    Object.assign(m, { id: e.id, createdAt: e.createdAt,
      originHint: c.originHint ?? null, aiEligible: c.aiEligible, geoRetain: c.geoRetain, expiresAt: c.expiresAt ?? null,
      polyline: c.geoRetain ? (c.polyline || e.polyline || null) : null, updatedAt: new Date().toISOString() })
    // brez polj z vrednostjo undefined (oblak jih zavrne)
    if (e.exercises) m.exercises = e.exercises; else delete m.exercises
    const notes = e.notes ?? c.notes
    if (notes != null) m.notes = notes; else delete m.notes
    await tx.store.put(m)
    upgraded++
  }
  // 2) dvojnik iz drugega vira je lahko bogatejši (sled, moč) — nadgradi obstoječega
  let richerN = 0
  for (const c of dupes) {
    const e = existing.find(x => x.id !== c.id && sameKeyish(x, c))
    if (e) { const r = richer(e, c); if (r === c) { await tx.store.put({ ...c, id: e.id, createdAt: e.createdAt }); richerN++ } }
  }
  await tx.done
  return { added: fresh.length, dupes: dupes.length - richerN + same, upgraded: upgraded + richerN }
}
function sameExternal(a: Activity, b: Activity) {
  return a.source === 'intervals' && b.source === 'intervals' && a.ext?.intervalsId != null && String(a.ext.intervalsId) === String(b.ext?.intervalsId)
}
function sameKeyish(a: Activity, b: Activity) {
  if (a.start && b.start) return Math.abs(new Date(a.start).getTime() - new Date(b.start).getTime()) <= 90_000
  return a.date === b.date && a.sport === b.sport && Math.abs((a.distKm || 0) - (b.distKm || 0)) <= Math.max(0.3, (a.distKm || 0) * 0.04)
}

/** Izbriše potekle zapise (Strava §6.2). Kliče se ob zagonu. */
export async function purgeExpired(): Promise<number> {
  const now = Date.now(); let n = 0
  const d = await db(); const tx = d.transaction('activities', 'readwrite')
  for (const a of await tx.store.getAll()) if (a.expiresAt && new Date(a.expiresAt).getTime() < now) { await tx.store.delete(a.id); n++ }
  await tx.done
  return n
}

/* ---------- načrt ---------- */
export async function planBetween(fromIso: string, toIso: string): Promise<PlanDay[]> {
  const rows = await (await db()).getAllFromIndex('plan', 'by-date', IDBKeyRange.bound(fromIso, toIso))
  return rows.sort((a, b) => a.date.localeCompare(b.date))
}
export async function allPlan(): Promise<PlanDay[]> { return (await (await db()).getAll('plan')).sort((a, b) => a.date.localeCompare(b.date)) }
export async function putPlanDay(p: PlanDay): Promise<void> { await (await db()).put('plan', { ...p, updatedAt: new Date().toISOString() }) }
/** Zamenja načrt za dane datume (en dan = en zapis). */
export async function upsertPlanDays(days: PlanDay[]): Promise<void> {
  const d = await db(); const tx = d.transaction('plan', 'readwrite')
  const dates = new Set(days.map(x => x.date))
  for (const old of await tx.store.getAll()) if (dates.has(old.date) && !old.done) await tx.store.delete(old.id)
  for (const x of days) await tx.store.put(x)
  await tx.done
}

/* ---------- obroki / check-in ---------- */
export async function mealsOn(dateIso: string): Promise<MealEntry[]> {
  const rows = await (await db()).getAllFromIndex('meals', 'by-date', dateIso)
  return rows.sort((a, b) => (a.time || '').localeCompare(b.time || '') || a.createdAt.localeCompare(b.createdAt))
}
export async function putMeal(m: MealEntry): Promise<void> { await (await db()).put('meals', m) }
export async function deleteMeal(id: string): Promise<void> { await (await db()).delete('meals', id) }
export async function getCheckin(dateIso: string): Promise<DailyCheckin | undefined> { return (await db()).get('checkins', dateIso) }
export async function allCheckins(): Promise<DailyCheckin[]> { return (await (await db()).getAll('checkins')).sort((a, b) => a.date.localeCompare(b.date)) }
export async function mealsBetween(fromIso: string, toIso: string): Promise<MealEntry[]> {
  const rows = await (await db()).getAllFromIndex('meals', 'by-date', IDBKeyRange.bound(fromIso, toIso))
  return rows.sort((a, b) => a.date.localeCompare(b.date) || (a.time || '').localeCompare(b.time || '') || a.createdAt.localeCompare(b.createdAt))
}
export async function putCheckin(c: DailyCheckin): Promise<void> { await (await db()).put('checkins', c) }

/* ---------- pokritost ---------- */
export async function loadCoverage(region: string): Promise<Uint32Array | null> { return (await (await db()).get('coverage', region))?.packed || null }
export async function saveCoverage(region: string, packed: Uint32Array): Promise<void> { await (await db()).put('coverage', { region, packed, updatedAt: new Date().toISOString() }) }

/* ---------- izvoz / izbris (GDPR) ---------- */
export async function exportAll() {
  const d = await db()
  return {
    exportedAt: new Date().toISOString(), version: 2,
    profile: await getKV(KV.profile), settings: await getKV(KV.settings),
    activities: await d.getAll('activities'), plan: await d.getAll('plan'), meals: await d.getAll('meals'), checkins: await d.getAll('checkins'),
  }
}
export async function wipeAll(): Promise<void> {
  const d = await db()
  for (const s of ['activities', 'plan', 'meals', 'checkins', 'kv', 'coverage'] as const) await d.clear(s)
}

/* ---------- za sinhronizacijo ---------- */
export async function allMeals(): Promise<MealEntry[]> { return (await db()).getAll('meals') }
/** Zamenja celotne zbirke (zadnji zapis iz oblaka zmaga). Profil in nastavitve gredo posebej. */
export async function replaceCollections(p: { activities: Activity[]; plan: PlanDay[]; meals: MealEntry[]; checkins: DailyCheckin[] }): Promise<void> {
  const d = await db()
  const tx = d.transaction(['activities', 'plan', 'meals', 'checkins'], 'readwrite')
  await tx.objectStore('activities').clear(); for (const a of p.activities) if (a && a.id) await tx.objectStore('activities').put(a)
  await tx.objectStore('plan').clear(); for (const x of p.plan) if (x && x.id) await tx.objectStore('plan').put(x)
  await tx.objectStore('meals').clear(); for (const m of p.meals) if (m && m.id) await tx.objectStore('meals').put(m)
  await tx.objectStore('checkins').clear(); for (const c of p.checkins) if (c && c.date) await tx.objectStore('checkins').put(c)
  await tx.done
}
