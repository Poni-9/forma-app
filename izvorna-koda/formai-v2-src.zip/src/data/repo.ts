import { db, getKV, setKV, KV } from './db'
import type { Activity, DailyCheckin, MealEntry, PlanDay, Profile, Settings } from '@/domain/types'
import { splitNew, richer } from '@/domain/import/dedupe'
import { stableStr, tombAct, tombMeal, mergeTomb, type Tomb } from './merge'

/* ---------- profil / nastavitve ---------- */
/** Privzeti profil. Deficit 0: uvod ga nastavi samo pri cilju »shujšati« (mladoletni ga nikoli nimajo). */
export function defaultProfile(): Profile {
  const now = new Date().toISOString()
  return { sex: null, gear: { bikeOutdoor: true, trainer: false, noBike: false, dumbbells: false, dumbbellKg: null }, strength: { on: true, equipment: 'none' }, strengthDays: 2, goal: 'dirka', deficit: 0, neat: 1.4, proteinGkg: 1.8, onboardingDone: false, createdAt: now, updatedAt: now }
}
export function defaultSettings(): Settings { return { lang: 'sl', accentHex: '#A3E635', intervals: null } }

const META = new Set(['updatedAt', 'fieldAt'])
const nil = (v: unknown) => v === undefined || v === null
/**
 * Čas spremembe za vsako polje (fieldAt): polje, ki se je spremenilo glede na shranjeno, dobi »zdaj«; ostala obdržijo svoj čas.
 * Privzeta vrednost, ki jo je zapolnilo nalaganje (npr. intervals: null), ni sprememba — sicer bi nova naprava
 * s privzetimi nastavitvami »novejše« prepisala pravo povezavo na drugi napravi.
 */
export function stampFields<T extends { updatedAt?: string; fieldAt?: Record<string, string> }>(prev: T | null | undefined, next: T, defaults: Partial<T>, now: string, prevView?: Partial<T>): Record<string, string> {
  const P = (prev || {}) as Record<string, unknown>, N = next as Record<string, unknown>, D = defaults as Record<string, unknown>
  let at: Record<string, string>
  if (prev?.fieldAt && typeof prev.fieldAt === 'object') at = { ...prev.fieldAt }
  else {
    // prvi zapis v novi obliki: polja z vrednostjo dobijo čas zadnje spremembe starega zapisa (prazna in privzeta ne)
    at = {}
    if (prev?.updatedAt) for (const [k, v] of Object.entries(P)) if (!META.has(k) && k !== 'createdAt' && !nil(v) && stableStr(v) !== stableStr(D[k])) at[k] = prev.updatedAt
  }
  // shranjeno, kot ga vidi nalaganje (s privzetki) — privzetek, ki ga je dodalo nalaganje, ni sprememba
  const eff: Record<string, unknown> = (prevView as Record<string, unknown> | undefined) ?? { ...D, ...P }
  for (const k of new Set([...Object.keys(eff), ...Object.keys(N)])) {
    if (META.has(k) || k === 'createdAt') continue
    if (stableStr(eff[k] ?? null) !== stableStr(N[k] ?? null)) at[k] = now
  }
  return Object.fromEntries(Object.keys(at).sort().map(k => [k, at[k]!]))
}

/** Shranjeni profil s privzetki za novejša polja (drog, deficit, cikel …); shranjeno ima prednost. */
function withProfileDefaults(s: Profile | undefined, d: Profile = defaultProfile()): Profile {
  if (!s) return d
  return { ...d, ...s, gear: { ...d.gear, ...(s.gear || {}) }, strength: { ...d.strength, ...(s.strength || {}) } }
}
export async function loadProfile(): Promise<Profile> {
  return withProfileDefaults(await getKV<Profile>(KV.profile))
}
/** Shrani profil in zabeleži čas sprememb posameznih polj (branje in zapis v eni transakciji). */
export async function saveProfile(p: Profile): Promise<Profile> {
  const tx = (await db()).transaction('kv', 'readwrite')
  const prev = (await tx.store.get(KV.profile)) as Profile | undefined
  const now = new Date().toISOString()
  const { fieldAt: _f, ...rest } = p; void _f
  const d = defaultProfile()
  const v: Profile = { ...rest, updatedAt: now, fieldAt: stampFields(prev, rest as Profile, d, now, withProfileDefaults(prev, d)) }
  await tx.store.put(v, KV.profile)
  await tx.done
  return v
}
export async function loadSettings(): Promise<Settings> { return { ...defaultSettings(), ...((await getKV<Settings>(KV.settings)) || {}) } }
/** Shrani nastavitve in zabeleži čas sprememb posameznih polj (branje in zapis v eni transakciji). */
export async function saveSettings(s: Settings): Promise<Settings> {
  const tx = (await db()).transaction('kv', 'readwrite')
  const prev = (await tx.store.get(KV.settings)) as Settings | undefined
  const now = new Date().toISOString()
  const { fieldAt: _f, ...rest } = s; void _f
  const v: Settings = { ...rest, updatedAt: now, fieldAt: stampFields(prev, rest as Settings, defaultSettings(), now) }
  await tx.store.put(v, KV.settings)
  await tx.done
  return v
}

/* ---------- aktivnosti ---------- */
export async function allActivities(): Promise<Activity[]> {
  const rows = await (await db()).getAll('activities')
  return rows.sort((a, b) => (b.date + (b.start || '')).localeCompare(a.date + (a.start || '')))
}
export async function activitiesBetween(fromIso: string, toIso: string): Promise<Activity[]> {
  return (await db()).getAllFromIndex('activities', 'by-date', IDBKeyRange.bound(fromIso, toIso))
}
export async function putActivity(a: Activity): Promise<void> { await (await db()).put('activities', { ...a, updatedAt: new Date().toISOString() }) }
export async function deleteActivity(id: string): Promise<void> {
  const d = await db(), a = await d.get('activities', id)
  await d.delete('activities', id)
  if (a) await addTomb(tombAct(a))
}

/**
 * Eno uvažanje naenkrat — samodejni uvoz iz intervals.icu in ročni uvoz (»Uvozi nove«, datoteke) čakata drug na
 * drugega, tudi med zavihki (navigator.locks, kjer je na voljo). Ne gnezdi (klic znotraj zaklepa bi čakal nase).
 */
let importChain: Promise<unknown> = Promise.resolve()
export function withImportLock<T>(fn: () => Promise<T>): Promise<T> {
  const run = (): Promise<T> => {
    const locks = typeof navigator !== 'undefined' ? (navigator as Navigator & { locks?: LockManager }).locks : undefined
    return locks && typeof locks.request === 'function' ? (locks.request('formai-import', () => fn()) as Promise<T>) : fn()
  }
  const p = importChain.then(run, run)
  importChain = p.catch(() => undefined)
  return p
}

/**
 * Množični vnos z deduplikacijo: branje obstoječih, primerjava in zapis so ENA transakcija — dva hkratna uvoza istih
 * voženj (samodejni + ročni) ne moreta obeh dodati (druga transakcija počaka in vidi zapise prve). Vrne števce.
 */
export async function addActivities(candidates: Activity[]): Promise<{ added: number; dupes: number; upgraded: number }> {
  const d = await db()
  const tx = d.transaction('activities', 'readwrite')
  const existing = await tx.store.getAll()
  // 1) isti zapis iz istega vira (ponovni uvoz iz intervals.icu) — prepoznan po ID-ju vira, ne po času
  const refresh: [Activity, Activity][] = [], rest: Activity[] = []
  // (samo za svež uvoz z novim id-jem — kopija iz oblaka z istim id-jem gre po običajni poti)
  const seenExt = new Set<string>()
  let batchDupes = 0
  for (const c of candidates) {
    const e = existing.find(x => x.id !== c.id && sameExternal(x, c))
    if (e) { refresh.push([e, c]); continue }
    // isti zapis dvakrat v istem paketu
    const k = c.source === 'intervals' && c.ext?.intervalsId != null ? String(c.ext.intervalsId) : null
    if (k && seenExt.has(k)) { batchDupes++; continue }
    if (k) seenExt.add(k)
    rest.push(c)
  }
  const { fresh, dupes } = splitNew(existing, rest)
  let upgraded = 0, same = 0
  for (const a of fresh) await tx.store.put(a)
  // Vir je avtoritativen za izvor in zastavice: »neznan izvor« postane Garmin (trener vidi) ali Strava (ne vidi).
  for (const [e, c] of refresh) {
    const changed = (e.originHint || null) !== (c.originHint || null) || e.aiEligible !== c.aiEligible || e.geoRetain !== c.geoRetain || (!e.polyline && !!c.polyline && c.geoRetain)
      || (!e.hrZoneSec && !!c.hrZoneSec) || (e.deviceWatts == null && c.deviceWatts != null)   // novi podatki iz vira (cone utripa, merilnik moči)
      || (e.elapsedMin == null && c.elapsedMin != null)                                           // čas s postanki (za dolžino tras)
    if (!changed) { same++; continue }
    // podatki: nove vrednosti, kjer jih vir da (Stravini zapisi v intervals.icu so lahko okrnjeni); zastavice: VEDNO iz vira
    const m: Activity = { ...e }
    for (const [k, v] of Object.entries(c)) if (v !== null && v !== undefined) (m as unknown as Record<string, unknown>)[k] = v
    Object.assign(m, { id: e.id, createdAt: e.createdAt,
      originHint: c.originHint ?? null, aiEligible: c.aiEligible, geoRetain: c.geoRetain, expiresAt: c.expiresAt ?? null,
      polyline: c.geoRetain ? (c.polyline || e.polyline || null) : null, updatedAt: new Date().toISOString() })
    // brez polj z vrednostjo undefined (oblak jih zavrne)
    if (e.exercises) m.exercises = e.exercises; else delete m.exercises
    if (e.named) { m.name = e.name; m.named = true }
    if (e.rpe !== undefined) m.rpe = e.rpe
    const notes = e.notes ?? c.notes
    if (notes != null) m.notes = notes; else delete m.notes
    await tx.store.put(m)
    upgraded++
  }
  // 2) dvojnik iz drugega vira je lahko bogatejši (sled, moč) — nadgradi obstoječega
  let richerN = 0
  for (const c of dupes) {
    const e = existing.find(x => x.id !== c.id && sameKeyish(x, c))
    if (e) { const r = richer(e, c); if (r === c) { await tx.store.put({ ...c, id: e.id, createdAt: e.createdAt, ...userFields(e) }); richerN++ } }
  }
  await tx.done
  return { added: fresh.length, dupes: dupes.length - richerN + same + batchDupes, upgraded: upgraded + richerN }
}
/** Kar je vpisal uporabnik (občutek, opomba, preimenovanje, vaje) — bogatejši uvoz iste vožnje tega ne povozi. */
function userFields(e: Activity): Partial<Activity> {
  const o: Partial<Activity> = {}
  if (e.rpe != null) o.rpe = e.rpe
  if (e.notes) o.notes = e.notes
  if (e.named) { o.name = e.name; o.named = true }
  if (e.exercises) o.exercises = e.exercises
  return o
}
function sameExternal(a: Activity, b: Activity) {
  return a.source === 'intervals' && b.source === 'intervals' && a.ext?.intervalsId != null && String(a.ext.intervalsId) === String(b.ext?.intervalsId)
}
function sameKeyish(a: Activity, b: Activity) {
  if (a.start && b.start) return Math.abs(new Date(a.start).getTime() - new Date(b.start).getTime()) <= 90_000
  return a.date === b.date && a.sport === b.sport && Math.abs((a.distKm || 0) - (b.distKm || 0)) <= Math.max(0.3, (a.distKm || 0) * 0.04)
}

/** Izbriše potekle zapise (Strava §6.2). Kliče se ob zagonu; ob izbrisu naj klicatelj sproži usklajevanje. */
export async function purgeExpired(): Promise<number> {
  const now = Date.now(); let n = 0
  const d = await db(); const tx = d.transaction('activities', 'readwrite')
  for (const a of await tx.store.getAll()) if (a.expiresAt && new Date(a.expiresAt).getTime() < now) { await tx.store.delete(a.id); n++ }
  await tx.done
  return n
}

/* ---------- načrt ---------- */
/** »opravljeno« ima svoj čas (doneAt): ob spremembi kljukice (tudi odkljukanju) zdaj, sicer ostane. */
function stampDone(prev: PlanDay | undefined, v: PlanDay, now: string): PlanDay {
  const was = prev?.done ?? null, is = v.done ?? null
  if (stableStr(was) !== stableStr(is)) { if (prev || is) v.doneAt = now; else delete v.doneAt }
  else if (prev?.doneAt) v.doneAt = prev.doneAt
  else if (!v.doneAt) delete v.doneAt
  return v
}
export async function planBetween(fromIso: string, toIso: string): Promise<PlanDay[]> {
  const rows = await (await db()).getAllFromIndex('plan', 'by-date', IDBKeyRange.bound(fromIso, toIso))
  return rows.sort((a, b) => a.date.localeCompare(b.date))
}
export async function allPlan(): Promise<PlanDay[]> { return (await (await db()).getAll('plan')).sort((a, b) => a.date.localeCompare(b.date)) }
export async function putPlanDay(p: PlanDay): Promise<void> {
  const tx = (await db()).transaction('plan', 'readwrite')
  const now = new Date().toISOString()
  await tx.store.put(stampDone(await tx.store.get(p.id), { ...p, updatedAt: now }, now))
  await tx.done
}
/**
 * Posodobi te zapise načrta (po id-ju), drugih zapisov istih dni NE pobriše — za premik, prestavitev, prilagoditev
 * enega ali dveh vnosov (moč na istem dnevu ostane). Za sestavo celih dni je upsertPlanDays.
 */
export async function putPlanDays(days: PlanDay[]): Promise<void> {
  const tx = (await db()).transaction('plan', 'readwrite')
  const now = new Date().toISOString()
  for (const x of days) await tx.store.put(stampDone(await tx.store.get(x.id), { ...x, updatedAt: now }, now))
  await tx.done
}
/** Zamenja načrt za dane datume: neopravljeni zapisi teh dni se pobrišejo, zapišejo se podani (sestava dni). */
export async function upsertPlanDays(days: PlanDay[]): Promise<void> {
  const d = await db(); const tx = d.transaction('plan', 'readwrite')
  const dates = new Set(days.map(x => x.date))
  const all = await tx.store.getAll()
  const byId = new Map(all.map(x => [x.id, x] as const))
  for (const old of all) if (dates.has(old.date) && !old.done) await tx.store.delete(old.id)
  const now = new Date().toISOString()
  for (const x of days) await tx.store.put(stampDone(byId.get(x.id), { ...x, updatedAt: now }, now))
  await tx.done
}

/** Pobriše neopravljene zapise načrta na danih datumih (razveljavitev sestave: dnevi, ki prej niso obstajali). */
export async function removePlanDates(dates: readonly string[]): Promise<number> {
  if (!dates.length) return 0
  const want = new Set(dates)
  const d = await db(); const tx = d.transaction('plan', 'readwrite')
  let n = 0
  for (const x of await tx.store.getAll()) if (want.has(x.date) && !x.done) { await tx.store.delete(x.id); n++ }
  await tx.done
  return n
}

/* ---------- obroki / check-in ---------- */
export async function mealsOn(dateIso: string): Promise<MealEntry[]> {
  const rows = await (await db()).getAllFromIndex('meals', 'by-date', dateIso)
  return rows.sort((a, b) => (a.time || '').localeCompare(b.time || '') || a.createdAt.localeCompare(b.createdAt))
}
export async function putMeal(m: MealEntry): Promise<void> { await (await db()).put('meals', { ...m, updatedAt: new Date().toISOString() }) }
export async function deleteMeal(id: string): Promise<void> { await (await db()).delete('meals', id); await addTomb(tombMeal(id)) }
export async function getCheckin(dateIso: string): Promise<DailyCheckin | undefined> { return (await db()).get('checkins', dateIso) }
export async function allCheckins(): Promise<DailyCheckin[]> { return (await (await db()).getAll('checkins')).sort((a, b) => a.date.localeCompare(b.date)) }
export async function mealsBetween(fromIso: string, toIso: string): Promise<MealEntry[]> {
  const rows = await (await db()).getAllFromIndex('meals', 'by-date', IDBKeyRange.bound(fromIso, toIso))
  return rows.sort((a, b) => a.date.localeCompare(b.date) || (a.time || '').localeCompare(b.time || '') || a.createdAt.localeCompare(b.createdAt))
}
export async function putCheckin(c: DailyCheckin): Promise<void> { await (await db()).put('checkins', { ...c, updatedAt: new Date().toISOString() }) }

/* ---------- pokritost ---------- */
export async function loadCoverage(region: string): Promise<Uint32Array | null> { return (await (await db()).get('coverage', region))?.packed || null }
export async function saveCoverage(region: string, packed: Uint32Array): Promise<void> { await (await db()).put('coverage', { region, packed, updatedAt: new Date().toISOString() }) }

/* ---------- izvoz / izbris (GDPR) ---------- */
export async function exportAll() {
  const d = await db()
  return {
    exportedAt: new Date().toISOString(), version: 2,
    profile: await getKV(KV.profile), settings: await getKV(KV.settings),
    activities: await d.getAll('activities'), plan: await d.getAll('plan'), meals: await d.getAll('meals'), checkins: await d.getAll('checkins'),
  }
}

/** Ključi prve različice (forma-trener.html, kalorije.html) v localStorage: vožnje (tudi s Strave), API ključi, pogovor, dnevniki. */
const LEGACY_EXACT = new Set(['kalorije_v1', 'kolesarski_trener_v1'])
const LEGACY_RX = /^(forma_|formai_)/
/** Pobriše ključe prve različice (nove različice uporabljajo »formai.« s piko). Vrne število pobrisanih. */
export function removeLegacyV1Keys(): number {
  let n = 0
  try {
    const keys: string[] = []
    for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k) keys.push(k) }
    for (const k of keys) if (LEGACY_RX.test(k) || LEGACY_EXACT.has(k)) { localStorage.removeItem(k); n++ }
  } catch { /* zasebni način */ }
  return n
}

/**
 * Izbriše VSE na tej napravi: IndexedDB (aktivnosti, načrt, obroki, jutranji vnosi, nastavitve, trase, pokritost,
 * podatki z ure), ključe prve različice v localStorage (sicer bi se ob naslednjem zagonu uvozili znova) in
 * predpomnjene ploščice zemljevida.
 */
export async function wipeAll(): Promise<void> {
  const d = await db()
  for (const s of ['activities', 'plan', 'meals', 'checkins', 'kv', 'coverage'] as const) await d.clear(s)
  removeLegacyV1Keys()
  try { sessionStorage.removeItem('icu.oauth.state') } catch { /* ni */ }
  try { if (typeof caches !== 'undefined') await caches.delete('tiles') } catch { /* ni predpomnilnika */ }
}

/* ---------- za sinhronizacijo ---------- */
export async function allMeals(): Promise<MealEntry[]> { return (await db()).getAll('meals') }

/** Grobovi: izbris na eni napravi velja tudi na drugih (sicer bi združevanje zapis obudilo). */
export const TOMB_KEY = 'sync.tomb'
export async function getTomb(): Promise<Tomb> { return (await getKV<Tomb>(TOMB_KEY)) || {} }
export async function addTomb(key: string): Promise<void> {
  const tx = (await db()).transaction('kv', 'readwrite')
  const t = { ...(((await tx.store.get(TOMB_KEY)) as Tomb | undefined) || {}) }
  t[key] = Date.now()
  await tx.store.put(t, TOMB_KEY)
  await tx.done
}

type Coll = 'activities' | 'plan' | 'meals' | 'checkins'
const keyOf = (c: Coll, x: { id?: string; date?: string }) => (c === 'checkins' ? x.date : x.id) as string
/**
 * Zapiše združeno stanje na napravo — samo zapise, ki se razlikujejo od posnetka pred združevanjem.
 * Zapis, ki si ga medtem spremenil ali dodal (npr. obrok med usklajevanjem), ostane nedotaknjen;
 * združi se ob naslednjem usklajevanju. Vrne true, če se je na napravi kaj spremenilo.
 */
export async function applyMerged(before: Record<Coll, { id?: string; date?: string }[]> & { profile: Profile | null; settings: Settings | null; tomb: Tomb },
  after: Record<Coll, { id?: string; date?: string }[]> & { profile: Profile | null; settings: Settings | null; tomb: Tomb }): Promise<boolean> {
  let changed = false
  const d = await db()
  const colls: Coll[] = ['activities', 'plan', 'meals', 'checkins']
  const work = colls.filter(c => stableStr(before[c]) !== stableStr(after[c]))
  if (work.length) {
    const tx = d.transaction(work, 'readwrite')
    for (const c of work) {
      const store = tx.objectStore(c)
      const snap = new Map(before[c].map(x => [keyOf(c, x), stableStr(x)] as const))
      const next = new Map(after[c].map(x => [keyOf(c, x), x] as const))
      for (const k of new Set([...snap.keys(), ...next.keys()])) {
        if (!k) continue
        const cur = await store.get(k as never)
        const curS = cur ? stableStr(cur) : null, snapS = snap.get(k) ?? null
        if (curS !== snapS) continue                       // medtem spremenjeno na tej napravi — pusti za naslednjič
        const n = next.get(k)
        if (n) { if (stableStr(n) !== snapS) { await store.put(n as never); changed = true } }
        else if (cur) { await store.delete(k as never); changed = true }
      }
    }
    await tx.done
  }
  // profil in nastavitve: samo, če se na napravi medtem nista spremenila (brez novega časovnega žiga)
  const curP = (await getKV<Profile>(KV.profile)) ?? null
  if (stableStr(curP) === stableStr(before.profile) && after.profile && stableStr(after.profile) !== stableStr(before.profile)) { await setKV(KV.profile, after.profile); changed = true }
  const curS = (await getKV<Settings>(KV.settings)) ?? null
  if (stableStr(curS) === stableStr(before.settings) && after.settings && stableStr(after.settings) !== stableStr(before.settings)) { await setKV(KV.settings, after.settings); changed = true }
  const t = mergeTomb(await getTomb(), after.tomb, Date.now())
  if (stableStr(t) !== stableStr(await getTomb())) await setKV(TOMB_KEY, t)
  return changed
}
/** Zamenja celotne zbirke (zadnji zapis iz oblaka zmaga). Profil in nastavitve gredo posebej. */
export async function replaceCollections(p: { activities: Activity[]; plan: PlanDay[]; meals: MealEntry[]; checkins: DailyCheckin[] }): Promise<void> {
  const d = await db()
  const tx = d.transaction(['activities', 'plan', 'meals', 'checkins'], 'readwrite')
  await tx.objectStore('activities').clear(); for (const a of p.activities) if (a && a.id) await tx.objectStore('activities').put(a)
  await tx.objectStore('plan').clear(); for (const x of p.plan) if (x && x.id) await tx.objectStore('plan').put(x)
  await tx.objectStore('meals').clear(); for (const m of p.meals) if (m && m.id) await tx.objectStore('meals').put(m)
  await tx.objectStore('checkins').clear(); for (const c of p.checkins) if (c && c.date) await tx.objectStore('checkins').put(c)
  await tx.done
}
