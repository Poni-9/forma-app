/**
 * Firestore ne sprejme vrednosti `undefined` (setDoc vrže »Unsupported field value: undefined«),
 * ne neskončnih števil kot pričakovanih vrednosti in praznih imen polj. Pred zapisom v oblak zato
 * vse očistimo: `undefined` v objektih izpustimo, v seznamih postane `null`, NaN/±∞ → null,
 * Date → ISO niz. Oblika podatkov ostane enaka, kot jo prebere aplikacija.
 */
export function cloudSafe<T>(x: T): T {
  const walk = (v: unknown): unknown => {
    if (v === undefined || typeof v === 'function' || typeof v === 'symbol') return undefined
    if (typeof v === 'number') return Number.isFinite(v) ? v : null
    if (v instanceof Date) return Number.isNaN(v.getTime()) ? null : v.toISOString()
    if (Array.isArray(v)) return v.map(i => { const w = walk(i); return w === undefined ? null : w })
    if (v && typeof v === 'object') {
      const o: Record<string, unknown> = {}
      for (const [k, val] of Object.entries(v as Record<string, unknown>)) {
        if (!k) continue
        const w = walk(val)
        if (w !== undefined) o[k] = w
      }
      return o
    }
    return v
  }
  return walk(x) as T
}
