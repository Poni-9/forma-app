import { openDB, type DBSchema, type IDBPDatabase } from 'idb'
import type { Activity, DailyCheckin, MealEntry, PlanDay, Profile, Settings } from '@/domain/types'

/** Lokalna shramba: vsak zapis svoja vrstica — ne en blob. Sledi ostanejo tu (nikoli v oblak). */
interface FormaiDB extends DBSchema {
  activities: { key: string; value: Activity; indexes: { 'by-date': string; 'by-start': string } }
  plan: { key: string; value: PlanDay; indexes: { 'by-date': string } }
  meals: { key: string; value: MealEntry; indexes: { 'by-date': string } }
  checkins: { key: string; value: DailyCheckin }
  kv: { key: string; value: unknown }
  /** pakirane celice pokritosti po regiji */
  coverage: { key: string; value: { region: string; packed: Uint32Array; updatedAt: string } }
}

let dbp: Promise<IDBPDatabase<FormaiDB>> | null = null
export function db(): Promise<IDBPDatabase<FormaiDB>> {
  if (!dbp) {
    dbp = openDB<FormaiDB>('formai', 1, {
      upgrade(d) {
        const a = d.createObjectStore('activities', { keyPath: 'id' })
        a.createIndex('by-date', 'date'); a.createIndex('by-start', 'start')
        d.createObjectStore('plan', { keyPath: 'id' }).createIndex('by-date', 'date')
        d.createObjectStore('meals', { keyPath: 'id' }).createIndex('by-date', 'date')
        d.createObjectStore('checkins', { keyPath: 'date' })
        d.createObjectStore('kv')
        d.createObjectStore('coverage', { keyPath: 'region' })
      },
    })
  }
  return dbp
}

export const KV = {
  profile: 'profile',
  settings: 'settings',
  migrated: 'migratedFromV1',
  lastIntervalsSync: 'lastIntervalsSync',
} as const

export async function getKV<T>(key: string): Promise<T | undefined> { return (await db()).get('kv', key) as Promise<T | undefined> }
export async function setKV<T>(key: string, val: T): Promise<void> { await (await db()).put('kv', val as any, key) }

export type { Profile, Settings }
