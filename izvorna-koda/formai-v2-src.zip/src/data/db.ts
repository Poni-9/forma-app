import { openDB, type DBSchema, type IDBPDatabase } from 'idb'
import type { Activity, DailyCheckin, MealEntry, PlanDay, Profile, Settings } from '@/domain/types'

/** Lokalna shramba: vsak zapis svoja vrstica — ne en blob. Sledi ostanejo tu (nikoli v oblak). */
interface FormaiDB extends DBSchema {
  activities: { key: string; value: Activity; indexes: { 'by-date': string; 'by-start': string } }
  plan: { key: string; value: PlanDay; indexes: { 'by-date': string } }
  meals: { key: string; value: MealEntry; indexes: { 'by-date': string } }
  checkins: { key: string; value: DailyCheckin }
  kv: { key: string; value: unknown }
  /** pakirane celice pokritosti po regiji */
  coverage: { key: string; value: { region: string; packed: Uint32Array; updatedAt: string } }
}

/** Različica sheme. Nova različica = nov korak v upgrade() (stari koraki ostanejo, da se posodobi vsaka stara baza). */
const DB_VERSION = 1

let dbp: Promise<IDBPDatabase<FormaiDB>> | null = null
let persistAsked = false

/**
 * Odpre bazo enkrat na zagon. Neuspešno odpiranje se NE zapomni (naslednji klic poskusi znova);
 * ko brskalnik povezavo prekine (terminated) ali jo zahteva novejša različica v drugem zavihku (blocking),
 * jo zapremo in naslednji klic odpre novo.
 */
export function db(): Promise<IDBPDatabase<FormaiDB>> {
  if (dbp) return dbp
  try { return open() } catch (e) { return Promise.reject(e) }   // npr. IndexedDB ni na voljo (zasebni način)
}
function open(): Promise<IDBPDatabase<FormaiDB>> {
  const p: Promise<IDBPDatabase<FormaiDB>> = openDB<FormaiDB>('formai', DB_VERSION, {
    upgrade(d, oldVersion) {
      // različica 1: osnovne zbirke (preverjeno po imenu — tudi napol ustvarjena baza se dopolni)
      if (oldVersion < 1) {
        if (!d.objectStoreNames.contains('activities')) {
          const a = d.createObjectStore('activities', { keyPath: 'id' })
          a.createIndex('by-date', 'date'); a.createIndex('by-start', 'start')
        }
        if (!d.objectStoreNames.contains('plan')) d.createObjectStore('plan', { keyPath: 'id' }).createIndex('by-date', 'date')
        if (!d.objectStoreNames.contains('meals')) d.createObjectStore('meals', { keyPath: 'id' }).createIndex('by-date', 'date')
        if (!d.objectStoreNames.contains('checkins')) d.createObjectStore('checkins', { keyPath: 'date' })
        if (!d.objectStoreNames.contains('kv')) d.createObjectStore('kv')
        if (!d.objectStoreNames.contains('coverage')) d.createObjectStore('coverage', { keyPath: 'region' })
      }
      // naslednje različice: if (oldVersion < 2) { … }
    },
    // drug zavihek ima odprto starejšo različico — odpiranje počaka, da jo zapre (tam se sproži blocking)
    blocked() { /* ne ukrepamo: drugi zavihek dobi »blocking« in zapre povezavo */ },
    // novejša različica (drug zavihek po posodobitvi) čaka na nas → zapri, naslednji klic odpre novo
    blocking() { void p.then(d => d.close()).catch(() => undefined); if (dbp === p) dbp = null },
    // brskalnik je povezavo prekinil (npr. pomanjkanje prostora, iOS v ozadju)
    terminated() { if (dbp === p) dbp = null },
  })
  dbp = p
  p.then(() => { void askPersist() }, () => { if (dbp === p) dbp = null })
  return p
}

/** Prosi brskalnik, naj podatkov ne briše sam (enkrat na zagon; brez vpliva, če ne podpira). */
async function askPersist(): Promise<void> {
  if (persistAsked) return
  persistAsked = true
  try {
    const s = typeof navigator !== 'undefined' ? navigator.storage : undefined
    if (s?.persist && !(await s.persisted?.())) await s.persist()
  } catch { /* ni podprto */ }
}

/** Samo za teste: pozabi odprto povezavo (nova tovarna IndexedDB). */
export function resetDbForTests(): void { dbp = null; persistAsked = false }

export const KV = {
  profile: 'profile',
  settings: 'settings',
  migrated: 'migratedFromV1',
  lastIntervalsSync: 'lastIntervalsSync',
} as const

export async function getKV<T>(key: string): Promise<T | undefined> { return (await db()).get('kv', key) as Promise<T | undefined> }
export async function setKV<T>(key: string, val: T): Promise<void> { await (await db()).put('kv', val as any, key) }
export async function delKV(key: string): Promise<void> { await (await db()).delete('kv', key) }

/** Števec, povečan v eni transakciji (dva hkratna klica ne izgubita koraka). ifMissing: vrednost, če števca še ni. Vrne novo vrednost. */
export async function bumpKV(key: string, ifMissing = 0): Promise<number> {
  const tx = (await db()).transaction('kv', 'readwrite')
  const cur = await tx.store.get(key)
  const next = (typeof cur === 'number' && Number.isFinite(cur) ? cur : ifMissing) + 1
  await tx.store.put(next, key)
  await tx.done
  return next
}

/**
 * Pospravi zapise, ki rastejo brez konca: ai.daily.<datum>, ai.week.<datum>, routes.retry.<datum> starejše od 30 dni.
 * Kliče se ob zagonu. Vrne število pobrisanih.
 */
export async function pruneKV(now: number = Date.now(), days = 30): Promise<number> {
  const cut = new Date(now - days * 86400_000).toISOString().slice(0, 10)
  const rx = /^(ai\.daily|ai\.week|routes\.retry)\.(\d{4}-\d{2}-\d{2})$/
  const tx = (await db()).transaction('kv', 'readwrite')
  let n = 0
  for (const k of await tx.store.getAllKeys()) {
    const m = rx.exec(String(k))
    if (m && m[2]! < cut) { await tx.store.delete(k); n++ }
  }
  await tx.done
  return n
}

export type { Profile, Settings }
