import { PROXY, APP_VERSION } from '@/config'
import { idToken } from '@/data/firebase'
import { getKV, setKV } from '@/data/db'
import { fetchPilotSummary } from '@/data/pilot'

/**
 * PRIPOMBE (Blaž, 4. 10.: »kot pri studentsi — uporabnik pove, posnetek zaslona, pošlje pritožbo; da mi pošlje in
 * ti to potem popraviš«). Pripomba gre na naš strežnik (Firestore `feedback`); skrbnik jih vidi na zaslonu Pripombe.
 * Brez povezave (ali dokler strežnik poti še nima) počaka v vrsti na napravi in gre ob naslednjem zagonu.
 */

export type FbKind = 'nejasno' | 'napaka' | 'predlog'
export const FB_KINDS: readonly [FbKind, string][] = [['nejasno', 'Ni jasno'], ['napaka', 'Napaka'], ['predlog', 'Predlog']]

export interface FbMeta { v: string; route: string; w: number; h: number; ua: string; lang: string; online: boolean; at: string; errs: string[] }
export interface Feedback { id: string; kind: FbKind; text: string; shot: string | null; meta: FbMeta; anon: string
  /** besedilo je že šlo prek /pilot/answer (strežnik brez /feedback) — v vrsti čaka samo še posnetek */
  textSent?: boolean }

const QUEUE = 'feedback.queue', ANON = 'feedback.anon'
export const FB_TEXT_MAX = 3000
/** posnetek do ~700 KB besedila (Firestore: dokument do 1 MiB) */
export const FB_SHOT_MAX = 700_000

/* ---------- zadnje napake v aplikaciji (pomagajo popraviti; samo besedilo napake, brez podatkov) ---------- */
const errs: string[] = []
let trapped = false
export function trapErrors(): void {
  if (trapped || typeof window === 'undefined') return
  trapped = true
  const add = (m: string) => { errs.push(`${new Date().toISOString().slice(11, 19)} ${m}`.slice(0, 220)); if (errs.length > 8) errs.shift() }
  window.addEventListener('error', e => add(String(e.message || 'napaka')))
  window.addEventListener('unhandledrejection', e => { const r = (e as PromiseRejectionEvent).reason; add(String((r && (r as Error).message) || r || 'zavrnitev')) })
}
export const recentErrors = (): string[] => [...errs]

async function anonId(): Promise<string> {
  const have = await getKV<string>(ANON).catch(() => null)
  if (have && /^[a-f0-9]{16}$/.test(have)) return have
  const a = Array.from(crypto.getRandomValues(new Uint8Array(8)), b => b.toString(16).padStart(2, '0')).join('')
  await setKV(ANON, a).catch(() => undefined)
  return a
}

export async function makeFeedback(o: { kind: FbKind; text: string; shot: string | null; route: string }): Promise<Feedback> {
  const shot = o.shot && o.shot.startsWith('data:image/') && o.shot.length <= FB_SHOT_MAX ? o.shot : null
  return {
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 8),
    kind: o.kind, text: o.text.trim().slice(0, FB_TEXT_MAX), shot,
    meta: {
      v: APP_VERSION, route: o.route.slice(0, 60), w: window.innerWidth, h: window.innerHeight,
      ua: navigator.userAgent.slice(0, 200), lang: navigator.language || '', online: navigator.onLine !== false,
      at: new Date().toISOString(), errs: recentErrors(),
    },
    anon: await anonId(),
  }
}

/* ---------- strežnik še brez /feedback: besedilo prek nameščene poti testnega programa ----------
   /pilot/answer sprejme odgovor do 200 znakov (q = »pripomba_<vrsta>«): besedilo gre v kosih »#id i/n …«,
   prvi kos nosi zaslon in velikost. Posnetek počaka v vrsti, dokler strežnik nima /feedback. */
export const PILOT_PREFIX = 'pripomba_'
const PART = 170, MAX_PARTS = 6
/** »Android · Chrome« — vrsta naprave (cel niz brskalnika gre samo na /feedback). */
export function shortUa(ua: string): string {
  const os = /iPhone|iPad|iPod/.test(ua) ? 'iOS' : /Android/.test(ua) ? 'Android' : /Windows/.test(ua) ? 'Windows' : /CrOS/.test(ua) ? 'ChromeOS' : /Mac OS X|Macintosh/.test(ua) ? 'Mac' : /linux/i.test(ua) ? 'Linux' : '?'
  const br = /Edg(A|iOS)?\//.test(ua) ? 'Edge' : /SamsungBrowser/.test(ua) ? 'Samsung' : /Firefox|FxiOS/.test(ua) ? 'Firefox' : /CriOS|Chrome\//.test(ua) ? 'Chrome' : /Safari\//.test(ua) ? 'Safari' : '?'
  return `${os} · ${br}`
}
/** konec pripombe: naprava in zadnje tri napake aplikacije (skrajšane) — da se da napako najti tudi brez /feedback */
const tailOf = (m: FbMeta) => ` ⟦${shortUa(m.ua || '')}${m.errs?.length ? ` · napake: ${m.errs.slice(-3).map(e => e.replace(/^\d\d:\d\d:\d\d /, '').slice(0, 80)).join(' | ')}` : ''}⟧`
/** rez brez razpolovljenega emojija (par nadomestnih znakov ostane skupaj) */
const cutAt = (s: string, n: number) => (n < s.length && /[\uD800-\uDBFF]/.test(s[n - 1]!) ? n - 1 : n)
export function pilotParts(f: Pick<Feedback, 'id' | 'text' | 'shot' | 'meta'>): string[] {
  const head = `[${f.meta.route || '?'} ${f.meta.w}×${f.meta.h}${f.shot ? ' +posnetek' : ''}] `
  const tail = tailOf(f.meta)
  let text = f.text.trim() || '(samo posnetek zaslona)'
  const room = (PART - 1) * MAX_PARTS - head.length - tail.length   // −1 na kos: rez se lahko umakne za znak
  if (text.length > room) text = text.slice(0, cutAt(text, room - 1)) + '…'
  const body = head + text + tail
  const out: string[] = []
  for (let i = 0; i < body.length;) { const j = cutAt(body, Math.min(body.length, i + PART)); out.push(body.slice(i, j)); i = j }
  return out.map((s, i) => `#${f.id} ${i + 1}/${out.length} ${s}`)
}
async function viaPilot(f: Feedback): Promise<boolean> {
  for (const a of pilotParts(f)) {
    const r = await fetch(`${PROXY}/pilot/answer`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ anon: f.anon, code: null, q: PILOT_PREFIX + f.kind, a, day: null, v: f.meta.v }) }).catch(() => null)
    if (!r || !r.ok) return false
  }
  return true
}

/** ok = vse poslano; text = besedilo poslano (prek testnega programa), posnetek čaka; retry = vse znova; drop = zavrženo */
type Sent = 'ok' | 'text' | 'retry' | 'drop'
async function post(f: Feedback): Promise<Sent> {
  const t = await idToken().catch(() => null)
  try {
    const r = await fetch(`${PROXY}/feedback`, { method: 'POST', headers: { 'Content-Type': 'application/json', ...(t ? { Authorization: `Bearer ${t}` } : {}) }, body: JSON.stringify(f) })
    if (r.ok) return 'ok'
    // prevelik posnetek: pošlji brez njega
    if (r.status === 413 && f.shot) return post({ ...f, shot: null })
    // neveljavno (400) se ne popravi s ponavljanjem
    if (r.status === 400) return 'drop'
    // strežnik še brez poti: besedilo takoj prek testnega programa; posnetek (če je) počaka
    if (r.status === 404 && !f.textSent && (await viaPilot(f))) return f.shot ? 'text' : 'ok'
    return 'retry'
  } catch { return 'retry' }
}

async function enqueue(f: Feedback) {
  const q = (await getKV<Feedback[]>(QUEUE)) || []
  await setKV(QUEUE, [...q.filter(x => x.id !== f.id), f].slice(-10))
}
/**
 * Pošlji takoj; brez povezave ali ob napaki strežnika v vrsto (največ 10) in ob naslednjem zagonu znova.
 * Dokler strežnik nima /feedback, gre besedilo prek testnega programa (uporabnik dobi »poslano«), posnetek čaka.
 */
export async function sendFeedback(f: Feedback): Promise<'poslano' | 'v vrsti'> {
  const r = await post(f)
  if (r === 'ok' || r === 'drop') return 'poslano'
  await enqueue(r === 'text' ? { ...f, textSent: true } : f)
  return r === 'text' ? 'poslano' : 'v vrsti'
}
/** Ena praznitev naenkrat (zagon in Nastavitve hkrati bi sicer isto pripombo poslala dvakrat). */
let flushing: Promise<number> | null = null
export function flushFeedback(): Promise<number> {
  return (flushing ??= doFlush().finally(() => { flushing = null }))
}
async function doFlush(): Promise<number> {
  const q = (await getKV<Feedback[]>(QUEUE).catch(() => null)) || []
  if (!q.length) return 0
  const left: Feedback[] = []
  let sent = 0
  for (const f of q) {
    const r = await post(f)
    if (r === 'retry') left.push(f)
    else if (r === 'text') { left.push({ ...f, textSent: true }); sent++ }
    else sent++
  }
  // med pošiljanjem je lahko prišla nova pripomba — ostane v vrsti
  const seen = new Set(q.map(f => f.id))
  const now = (await getKV<Feedback[]>(QUEUE).catch(() => null)) || []
  await setKV(QUEUE, [...left, ...now.filter(f => !seen.has(f.id))].slice(-10))
  return sent
}
/** Koliko pripomb še ni prišlo do razvijalca (posnetek, ki čaka na posodobljen strežnik, ne šteje). */
export async function queuedFeedback(): Promise<number> { return ((await getKV<Feedback[]>(QUEUE).catch(() => null)) || []).filter(f => !f.textSent).length }

/* ---------- posnetek zaslona: to, kar uporabnik vidi (brez Stravinih vadb — data-noshot) ---------- */
const BLANK = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7'
export async function captureScreen(timeoutMs = 6000): Promise<string | null> {
  if (typeof document === 'undefined') return null
  const node = document.body
  const w = window.innerWidth, h = window.innerHeight, y = window.scrollY
  const job = (async () => {
    const { toJpeg } = await import('html-to-image')
    const bg = getComputedStyle(document.body).backgroundColor || '#0F1216'
    const url = await toJpeg(node, {
      quality: 0.72, backgroundColor: bg, pixelRatio: Math.min(2, 1100 / Math.max(1, w)),
      width: w, height: h, canvasWidth: w, canvasHeight: h,
      style: { transform: `translateY(${-y}px)`, transformOrigin: 'top left' },
      imagePlaceholder: BLANK, cacheBust: false,
      filter: n => !(n instanceof HTMLElement && (n.dataset.noshot != null || n.classList.contains('toast-host') || n.classList.contains('veil') || n.classList.contains('sheet'))),
    })
    return url.length <= FB_SHOT_MAX ? url : null
  })()
  const late = new Promise<null>(r => setTimeout(() => r(null), timeoutMs))
  try { return await Promise.race([job, late]) } catch { return null }
}

/* ---------- skrbnik: seznam in stanje (strežnik preveri, da je prijavljeni skrbnik) ---------- */
export interface FbRow { id: string; kind: FbKind; text: string; status: 'novo' | 'reseno'; hasShot: boolean; meta: Partial<FbMeta>; email: string | null; anon: string; at: number | null
  /** pripomba iz testnega programa: posnetek pride, ko bo strežnik posodobljen */
  shotLater?: boolean }
async function adminFetch(path: string, init?: RequestInit): Promise<Response | { error: string }> {
  const t = await idToken().catch(() => null)
  if (!t) return { error: 'Za pregled se prijavi z Googlom.' }
  try {
    const r = await fetch(`${PROXY}${path}`, { ...init, headers: { ...(init?.headers || {}), Authorization: `Bearer ${t}` } })
    if (r.status === 403) return { error: 'Ta račun nima dostopa do pripomb.' }
    if (!r.ok) return { error: `Strežnik: ${r.status}${r.status === 404 ? ' (pot še ni nameščena — posodobi strežnik)' : ''}` }
    return r
  } catch { return { error: 'Ni povezave s strežnikom.' } }
}
/** Pripombe, ki so šle prek testnega programa (strežnik brez /feedback): kosi »#id i/n …« → ena pripomba. */
export function rowsFromPilot(answers: readonly { anon: string; q: string; a: string; v: string; at: number | null }[]): FbRow[] {
  const by = new Map<string, { kind: FbKind; anon: string; v: string; at: number | null; parts: Map<number, string>; n: number }>()
  for (const x of answers) {
    if (!x.q.startsWith(PILOT_PREFIX)) continue
    const m = /^#(\S+) (\d+)\/(\d+) ([\s\S]*)$/.exec(x.a)
    if (!m) continue
    const key = `${x.anon}_${m[1]}`
    const kind = (x.q.slice(PILOT_PREFIX.length) as FbKind)
    const e = by.get(key) ?? { kind: FB_KINDS.some(([k]) => k === kind) ? kind : 'nejasno', anon: x.anon, v: x.v, at: x.at, parts: new Map(), n: +m[3]! }
    e.parts.set(+m[2]!, m[4]!)
    if (x.at != null && (e.at == null || x.at < e.at)) e.at = x.at
    by.set(key, e)
  }
  return [...by.entries()].map(([key, e]) => {
    const raw = Array.from({ length: e.n }, (_, i) => e.parts.get(i + 1) ?? '…').join('')
    const h = /^\[(\S+) (\d+)×(\d+)( \+posnetek)?\] ?/.exec(raw)
    let text = h ? raw.slice(h[0].length) : raw
    const t = / ⟦([^⟦⟧]*)⟧$/.exec(text)
    if (t) text = text.slice(0, t.index)
    const [ua, er] = t ? t[1]!.split(' · napake: ') : []
    return {
      id: `p:${key}`, kind: e.kind, text, status: 'novo' as const, hasShot: false, shotLater: !!h?.[4],
      meta: { route: h?.[1] ?? '?', w: h ? +h[2]! : undefined, h: h ? +h[3]! : undefined, v: e.v, ...(ua ? { ua } : {}), ...(er ? { errs: er.split(' | ') } : {}) },
      email: null, anon: e.anon, at: e.at,
    }
  })
}
/** Rešene pripombe iz testnega programa (strežnik jim stanja ne hrani) — na napravi skrbnika. */
const RESOLVED = 'formai.fb.resolved'
const resolvedIds = (): Set<string> => { try { return new Set(JSON.parse(localStorage.getItem(RESOLVED) || '[]') as string[]) } catch { return new Set() } }
export async function fetchFeedbackList(all = false): Promise<{ rows: FbRow[] } | { error: string }> {
  const [r, pilot] = await Promise.all([adminFetch(`/feedback/list${all ? '?vse=1' : ''}`), fetchPilotSummary()])
  const full: FbRow[] = 'error' in r ? [] : ((await r.json().catch(() => ({}))) as { items?: FbRow[] }).items || []
  // dostop: skrbnik je, kdor dobi seznam (nov strežnik) ali pregled testnega programa (nameščen strežnik)
  if ('error' in r && 'error' in pilot) return { error: r.error.includes('404') ? pilot.error : r.error }
  const done = resolvedIds(), have = new Set(full.map(x => x.id))
  const fromPilot = 'error' in pilot ? [] : rowsFromPilot(pilot.rows)
    .filter(x => !have.has(x.id.slice(2)))
    .map(x => (done.has(x.id) ? { ...x, status: 'reseno' as const } : x))
    .filter(x => all || x.status === 'novo')
  return { rows: [...full, ...fromPilot].sort((a, b) => (b.at ?? 0) - (a.at ?? 0)) }
}
export async function fetchFeedbackShot(id: string): Promise<string | null> {
  const r = await adminFetch(`/feedback/${encodeURIComponent(id)}`)
  if ('error' in r) return null
  const d = await r.json().catch(() => ({})) as { shot?: string | null }
  return d.shot || null
}
export async function setFeedbackStatus(id: string, status: 'novo' | 'reseno'): Promise<boolean> {
  if (id.startsWith('p:')) {
    const s = resolvedIds(); if (status === 'reseno') s.add(id); else s.delete(id)
    try { localStorage.setItem(RESOLVED, JSON.stringify([...s])) } catch { return false }
    return true
  }
  const r = await adminFetch(`/feedback/${encodeURIComponent(id)}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) })
  return !('error' in r)
}
/** Ali je prijavljeni skrbnik (strežnik odgovori na seznam) — za povezavo v Nastavitvah. */
export async function isFeedbackAdmin(): Promise<boolean> {
  const r = await fetchFeedbackList(false)
  return !('error' in r)
}
