import { PROXY } from '@/config'
import { idToken } from '@/data/firebase'
import { getKV, setKV } from '@/data/db'
import { cleanCode } from '@/domain/pilot'

/**
 * Testni program: koda povabila iz povezave (?pilot=KODA, tudi iz QR) in pošiljanje odgovorov.
 * Odgovor: anonimna oznaka, koda, vprašanje, odgovor (a–d), dan uporabe, različica — brez imena, e-pošte in podatkov o treningu.
 */
const CODE_KEY = 'formai.pilot', QUEUE = 'pilot.queue'

/** Ob zagonu: ?pilot=KODA → shrani (do uvoda v localStorage) in počisti naslov. */
export function capturePilotCode(): string | null {
  const q = new URLSearchParams(location.search)
  const c = cleanCode(q.get('pilot'))
  if (c) {
    try { localStorage.setItem(CODE_KEY, c) } catch { /* zasebni način */ }
    q.delete('pilot')
    const rest = q.toString()
    history.replaceState(null, '', location.pathname + (rest ? `?${rest}` : '') + location.hash)
  }
  try { return c || localStorage.getItem(CODE_KEY) } catch { return c }
}

export interface PilotAnswer { anon: string; code: string | null; q: string; a: string; day: number | null; v: string }

async function post(x: PilotAnswer): Promise<boolean> {
  try {
    const r = await fetch(`${PROXY}/pilot/answer`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(x) })
    return r.ok
  } catch { return false }
}

/** Pošlji; brez omrežja v vrsto in ob naslednjem zagonu znova. */
export async function sendPilot(x: PilotAnswer): Promise<void> {
  if (await post(x)) return
  const q = (await getKV<PilotAnswer[]>(QUEUE)) || []
  await setKV(QUEUE, [...q, x].slice(-30))
}
export async function flushPilot(): Promise<void> {
  const q = (await getKV<PilotAnswer[]>(QUEUE)) || []
  if (!q.length) return
  const left: PilotAnswer[] = []
  for (const x of q) if (!(await post(x))) left.push(x)
  await setKV(QUEUE, left)
}

export interface PilotRow { anon: string; code: string | null; q: string; a: string; day: number | null; v: string; at: number | null }
/** Pregled za razvijalca (strežnik preveri, da je prijavljeni skrbnik). */
export async function fetchPilotSummary(): Promise<{ rows: PilotRow[] } | { error: string }> {
  const t = await idToken().catch(() => null)
  if (!t) return { error: 'Za pregled se prijavi z Googlom.' }
  try {
    const r = await fetch(`${PROXY}/pilot/summary`, { headers: { Authorization: `Bearer ${t}` } })
    if (r.status === 403) return { error: 'Ta račun nima dostopa do pregleda.' }
    if (!r.ok) return { error: `Strežnik: ${r.status}${r.status === 404 ? ' (pot še ni nameščena)' : ''}` }
    const d = await r.json() as { answers?: PilotRow[] }
    return { rows: d.answers || [] }
  } catch { return { error: 'Ni povezave s strežnikom.' } }
}
