import type { Activity, ActivitySource, MealEntry, PlanDay, Profile } from '@/domain/types'
import { deriveFlags } from '@/domain/import/provenance'
import { sportOfType } from '@/domain/training/load'
import { addActivities, loadProfile, saveProfile, upsertPlanDays, putMeal, allActivities, deleteActivity, allMeals, deleteMeal, getCheckin, putCheckin, loadSettings, saveSettings } from './repo'
import { getKV, setKV, KV } from './db'

/**
 * Prevzem podatkov iz prve različice (forma-trener.html / kalorije.html), ki živi na isti domeni
 * in piše v localStorage 'forma_trener_v1' in 'kalorije_v1'. Teče enkrat, nič ne briše.
 * Izvor se ohrani in se preslika v nove zastavice (Strava → ne AI, ne karta).
 */
export async function migrateFromV1(): Promise<{ ran: boolean; activities: number; meals: number; plan: number } | null> {
  if (await getKV<boolean>(KV.migrated)) return null
  let raw: any = null, kal: any = null
  try { raw = JSON.parse(localStorage.getItem('forma_trener_v1') || 'null') } catch { raw = null }
  try { kal = JSON.parse(localStorage.getItem('kalorije_v1') || 'null') } catch { kal = null }
  if (!raw && !kal) { await setKV(KV.migrated, true); return { ran: false, activities: 0, meals: 0, plan: 0 } }

  const now = new Date().toISOString()
  // --- profil ---
  const p0 = raw?.settings?.profile || {}
  const prof = await loadProfile()
  const akt = aktOf(p0.aktivnosti)
  const merged: Profile = {
    ...prof,
    name: p0.ime || prof.name, sex: sexFromV1(p0.spol) || prof.sex,
    age: p0.starost || prof.age, heightCm: p0.visina || prof.heightCm, weightKg: p0.teza || prof.weightKg,
    restHr: p0.restHr || prof.restHr, maxHr: p0.maxHr || prof.maxHr, lthr: p0.lthr || prof.lthr, ftp: p0.ftp || prof.ftp, ftpDate: p0.ftpDatum || prof.ftpDate,
    hoursPerWeek: p0.ure || prof.hoursPerWeek,
    place: p0.krajLat && p0.krajLon ? { name: p0.kraj || '', lat: +p0.krajLat, lon: +p0.krajLon } : prof.place,
    gear: { ...prof.gear, bikeOutdoor: akt ? akt.includes('kolo') || !akt.length : prof.gear.bikeOutdoor, trainer: akt ? akt.includes('trenazer') : prof.gear.trainer, noBike: akt ? akt.length > 0 && !akt.includes('kolo') && !akt.includes('trenazer') : prof.gear.noBike },
    strength: { on: akt ? akt.includes('moc') || prof.strength.on : prof.strength.on, equipment: prof.strength.equipment },
    targetWeightKg: p0.ciljTeza ? +p0.ciljTeza : prof.targetWeightKg,
    event: p0.ciljDatum && p0.cilj ? { name: String(p0.cilj).slice(0, 60), date: String(p0.ciljDatum).slice(0, 10) } : prof.event,
    onboardingDone: !!(localStorage.getItem('forma_onb_done') || p0.ime || p0.teza),
    updatedAt: now,
  }
  await saveProfile(merged)
  // teža iz profila → prvo tehtanje (trend se začne tu)
  if (p0.teza && !(await getCheckin(now.slice(0, 10)))) await putCheckin({ date: now.slice(0, 10), weightKg: +p0.teza })

  // --- aktivnosti ---
  const acts: Activity[] = []
  for (const r of (raw?.rides || [])) {
    if (!r || r.demo) continue
    const src: ActivitySource = r.source === 'strava' ? 'strava_api' : r.source === 'intervals' ? 'intervals' : r.source === 'shot' ? 'screenshot' : r.notes === 'GPX uvoz' || r.trackSrc ? 'file' : 'manual'
    const originHint = r.icuOrigin || null
    const flags = deriveFlags(src, originHint)
    // Strava API zapisi: 7-dnevni TTL od ZDAJ (stari zapisi so tako ali tako starejši → izbrisani ob prvem čiščenju)
    acts.push({
      id: String(r.id || Math.random().toString(36).slice(2)), source: src, originHint, deviceName: r.sourceDeviceName || null,
      sport: (sportOfType(r.sport) || 'kolo'), date: String(r.date || '').slice(0, 10), start: r.start || null, name: r.name || 'Vožnja',
      distKm: r.dist ?? null, durationMin: r.time ?? null, elevM: r.elev ?? null, avgHr: r.avgHr ?? null, maxHr: r.maxHr ?? null,
      avgPower: r.avgPower ?? r.watts ?? null, speedKmh: r.speed ?? null, kcal: r.kcal ?? null, tss: r.tss ?? null,
      polyline: flags.geoRetain ? (r.polyline || null) : null, notes: r.notes || undefined,
      ...flags, ext: { intervalsId: r.icuId, stravaId: r.stravaId }, createdAt: now, updatedAt: now,
    })
  }
  const res = acts.length ? await addActivities(acts) : { added: 0, dupes: 0, upgraded: 0 }

  // --- načrt (zadnjih 60 dni) ---
  const planDays: PlanDay[] = []
  const cutoff = new Date(Date.now() - 60 * 86400_000).toISOString().slice(0, 10)
  const mealCutoff = new Date(Date.now() - 180 * 86400_000).toISOString().slice(0, 10)
  for (const pl of (raw?.plans || [])) for (const d of (pl?.dnevi || pl?.days || [])) {
    if (!d?.datum || d.datum < cutoff) continue
    const t = String(d.tip || '').toLowerCase()
    const kind = /poč|rest|počitek/.test(t) ? 'pocitek' : /moč|moc|strength/.test(t) ? 'moc' : /tek|run/.test(t) ? 'tek' : /pohod|hoj|walk/.test(t) ? 'pohod' : 'kolo'
    planDays.push({ id: 'v1-' + d.datum + '-' + kind, date: d.datum, kind, title: d.naslov || d.tip || '', desc: d.opis || '', durationMin: +d.trajanje_min || 0, zone: null, tssTarget: d.tss_ocena ?? null, why: d.zakaj || null, source: 'ai', createdAt: now, updatedAt: now, done: d.opravljeno ? { at: now, activityId: null } : null })
  }
  if (planDays.length) await upsertPlanDays(planDays)

  // --- obroki (zadnjih 45 dni) ---
  let meals = 0
  const days = kal?.days || kal?.dnevi || {}
  for (const [date, dd] of Object.entries<any>(days)) {
    if (date < mealCutoff) continue
    for (const e of (dd?.entries || [])) {
      if (!e) continue
      const slotRaw = String(e.meal || e.obrok || '').toLowerCase()
      const slot: MealEntry['slot'] = /zajtrk/.test(slotRaw) ? 'zajtrk' : /kosil/.test(slotRaw) ? 'kosilo' : /večer|vecer/.test(slotRaw) ? 'vecerja' : /malic/.test(slotRaw) ? 'malica' : /vožn|vozn|vadb/.test(slotRaw) ? 'med_vadbo' : 'drugo'
      await putMeal({ id: String(e.id || Math.random().toString(36).slice(2)), date, time: e.time || null, slot, name: e.jed || e.name || 'Obrok', grams: e.grami ?? null, kcal: Math.round(+e.kcal || 0), proteinG: e.b ?? e.beljakovine_g ?? null, carbsG: e.oh ?? null, fatG: e.m ?? null, confidence: null, source: e.op === 'predlog' ? 'suggest' : e.thumb ? 'photo' : 'manual', thumb: null, createdAt: e.ts ? new Date(e.ts).toISOString() : now })
      meals++
    }
  }
  await setKV(KV.migrated, true)
  return { ran: true, activities: res.added, meals, plan: planDays.length }
}

/** Stari zapis spola: 'moški' / 'ženska' / 'm' / 'z'. */
export function sexFromV1(v: unknown): 'm' | 'z' | null {
  const s = String(v || '').trim().toLowerCase()
  if (!s) return null
  if (/^(ž|z|f|w)/.test(s)) return 'z'
  if (/^m/.test(s)) return 'm'
  return null
}
/** Stare »aktivnosti« so bile seznam ['kolo','pohod','moc'] ali objekt {kolo:1,…}. */
function aktOf(v: unknown): string[] | null {
  if (Array.isArray(v)) return v.map(x => String(x).toLowerCase())
  if (v && typeof v === 'object') return Object.entries(v as Record<string, unknown>).filter(([, x]) => !!x).map(([k]) => k.toLowerCase())
  return null
}

const DEMO_MEALS: [string, number][] = [['Ovsena kaša, banana, oreški', 520], ['Testenine, piščanec, solata', 780]]

/**
 * Enkratno popravilo po preizkusni objavi na /v2/ (ista domena → ista IndexedDB):
 *  - demo podatki (vir 'demo', profil »Demo«) iz preizkusa ne smejo ostati med tvojimi,
 *  - prva preslikava je spol 'moški' zapisala kot prazen, moč iz seznama kot izklopljeno.
 */
/**
 * Povezava z intervals.icu iz stare aplikacije (state.icu) → nastavitve. Enkrat na napravo.
 * Brez tega bi moral Athlete ID in ključ vpisati še enkrat, samodejni uvoz pa ne bi tekel.
 */
export async function carryIntervalsFromV1(): Promise<boolean> {
  const KEY = 'repair.icu.v1'
  if (await getKV<boolean>(KEY)) return false
  let raw: any = null
  try { raw = JSON.parse(localStorage.getItem('forma_trener_v1') || 'null') } catch { raw = null }
  const icu = raw?.icu
  const s = await loadSettings()
  let done = false
  if (!s.intervals && icu?.athleteId && icu?.apiKey) {
    await saveSettings({ ...s, intervals: { athleteId: String(icu.athleteId).trim(), apiKey: String(icu.apiKey).trim(), name: icu.name ? String(icu.name) : undefined } })
    done = true
  }
  await setKV(KEY, true)
  return done
}

export async function repairAfterPreview(): Promise<string[]> {
  const KEY = 'repair.preview.v1'
  if (await getKV<boolean>(KEY)) return []
  const log: string[] = []
  const demo = (await allActivities()).filter(a => a.source === 'demo')
  for (const a of demo) await deleteActivity(a.id)
  if (demo.length) {
    for (const m of await allMeals()) if (DEMO_MEALS.some(([n, k]) => m.name === n && m.kcal === k)) await deleteMeal(m.id)
    log.push(`odstranjenih ${demo.length} demo aktivnosti`)
  }
  let raw: any = null
  try { raw = JSON.parse(localStorage.getItem('forma_trener_v1') || 'null') } catch { raw = null }
  const p0 = raw?.settings?.profile || null
  const prof = await loadProfile()
  const patch: Partial<Profile> = {}
  const wasDemo = prof.name === 'Demo'
  if (wasDemo) {
    Object.assign(patch, { name: p0?.ime || undefined, age: p0?.starost || null, heightCm: p0?.visina || null, weightKg: p0?.teza || null, maxHr: p0?.maxHr || null, restHr: p0?.restHr || null, ftp: p0?.ftp || null, hoursPerWeek: p0?.ure || null, level: null })
    log.push('profil »Demo« zamenjan')
  }
  const sex = sexFromV1(p0?.spol)
  if (sex && (!prof.sex || wasDemo)) patch.sex = sex
  const akt = aktOf(p0?.aktivnosti)
  if (akt && akt.includes('moc') && !prof.strength.on) patch.strength = { ...prof.strength, on: true }
  if (p0?.ciljTeza && !prof.targetWeightKg) patch.targetWeightKg = +p0.ciljTeza
  if (Object.keys(patch).length) await saveProfile({ ...prof, ...patch })
  await setKV(KEY, true)
  return log
}
