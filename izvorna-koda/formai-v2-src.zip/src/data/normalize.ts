import type { Activity, DailyCheckin, MealEntry, PlanDay, Sport } from '@/domain/types'
import { ACTIVITY_RANGE, MEAL_KCAL_RANGE, PROFILE_RANGE, inRange } from '@/domain/ranges'

/**
 * (v3.49) Zapisi od zunaj (kopija, oblak, stara različica): manjkajoča ali napačna polja popravimo ob branju, da en
 * nepopoln zapis ne sesuje zaslona (prej obrok brez imena → Prehrana »Cannot read properties of undefined«).
 * Veljaven zapis ostane isti predmet. Neznanih vrednosti (vir, obrok) ne zavržemo — samo manjkajoče dopolnimo.
 */
const finite = (x: unknown): x is number => typeof x === 'number' && Number.isFinite(x)
const numOrNull = (x: unknown): number | null => (finite(x) ? x : null)
const strOr = (x: unknown, d: string): string => (typeof x === 'string' && x.trim() ? x : d)

/** Obrok: ime niz (ali »Obrok«), obrok in vir niz, kalorije število, makri število ali null, čas vpisa niz. */
export function normalizeMeal(m: MealEntry): MealEntry {
  if (!m || typeof m !== 'object') return m
  const r = m as unknown as Record<string, unknown>
  const bad = typeof r.name !== 'string' || !r.name.trim() || typeof r.slot !== 'string' || !r.slot || !finite(r.kcal)
    || typeof r.createdAt !== 'string' || typeof r.source !== 'string'
    || (r.time != null && typeof r.time !== 'string')
    || (['grams', 'proteinG', 'carbsG', 'fatG'] as const).some(k => r[k] != null && !finite(r[k]))
    || (r.items != null && !Array.isArray(r.items))
  if (!bad) return m
  return {
    ...m,
    name: strOr(r.name, 'Obrok'),
    slot: strOr(r.slot, 'drugo') as MealEntry['slot'],
    kcal: finite(r.kcal) ? r.kcal : 0,
    source: strOr(r.source, 'manual') as MealEntry['source'],
    time: typeof r.time === 'string' ? r.time : null,
    grams: numOrNull(r.grams), proteinG: numOrNull(r.proteinG), carbsG: numOrNull(r.carbsG), fatG: numOrNull(r.fatG),
    items: Array.isArray(r.items) ? (r.items as unknown[]).filter((x): x is NonNullable<MealEntry['items']>[number] => !!x && typeof x === 'object' && typeof (x as { name?: unknown }).name === 'string' && finite((x as { kcal?: unknown }).kcal)) : null,
    createdAt: typeof r.createdAt === 'string' ? r.createdAt : `${m.date}T12:00:00.000Z`,
  }
}

/**
 * Razponi pri uvozu kopije (v3.49): vrednost aktivnosti izven razpona → null (zapis ostane), tehtanje izven
 * 30–250 kg se izpusti. Vrne zapis in število izpuščenih vrednosti.
 */
const ACT_FIELDS: [keyof Activity, readonly [number, number, string, string]][] = [
  ['durationMin', ACTIVITY_RANGE.min], ['elapsedMin', ACTIVITY_RANGE.min], ['distKm', ACTIVITY_RANGE.dist], ['elevM', ACTIVITY_RANGE.elev],
  ['avgHr', ACTIVITY_RANGE.hr], ['maxHr', ACTIVITY_RANGE.hr], ['avgPower', ACTIVITY_RANGE.power], ['kcal', ACTIVITY_RANGE.kcal],
]
export function clampActivity(a: Activity): { a: Activity; skipped: number } {
  let out: Activity | null = null, skipped = 0
  for (const [k, r] of ACT_FIELDS) {
    const v = (a as unknown as Record<string, unknown>)[k]
    if (v == null) continue
    if (finite(v) && inRange(v, r) != null) continue
    out = out || { ...a }
    ;(out as unknown as Record<string, unknown>)[k] = null
    skipped++
  }
  return { a: out || a, skipped }
}
/** Obrok iz kopije: kalorije izven 0–10 000 → obrok se izpusti (null). */
export function mealInRange(m: MealEntry): boolean { return finite(m.kcal) && inRange(m.kcal, MEAL_KCAL_RANGE) != null }
const PROFILE_FIELDS: [string, readonly [number, number, string, string]][] = [
  ['age', PROFILE_RANGE.age], ['heightCm', PROFILE_RANGE.height], ['weightKg', PROFILE_RANGE.weight], ['maxHr', PROFILE_RANGE.maxHr], ['restHr', PROFILE_RANGE.restHr],
  ['lthr', PROFILE_RANGE.lthr], ['ftp', PROFILE_RANGE.ftp], ['hoursPerWeek', PROFILE_RANGE.hours], ['bodyFatPct', PROFILE_RANGE.bf],
]
/**
 * Profil iz kopije: številka izven razpona se odstrani skupaj s svojim časom spremembe — pri združevanju velja
 * vrednost na napravi (ne izgine in je ne povozi 7,6 kg).
 */
export function clampProfile<P extends object>(p: P): { p: P; skipped: number } {
  const r = p as unknown as Record<string, unknown>
  let out: Record<string, unknown> | null = null, skipped = 0
  for (const [k, rg] of PROFILE_FIELDS) {
    const v = r[k]
    if (v == null || (finite(v) && inRange(v, rg) != null)) continue
    out = out || { ...r, ...(r.fieldAt && typeof r.fieldAt === 'object' ? { fieldAt: { ...(r.fieldAt as Record<string, string>) } } : {}) }
    delete out[k]
    if (out.fieldAt) delete (out.fieldAt as Record<string, string>)[k]
    skipped++
  }
  return { p: (out || p) as P, skipped }
}
/** Jutranji vnos iz kopije: teža izven razpona se odstrani; vnos brez česa drugega se izpusti (null). */
export function clampCheckin(c: DailyCheckin): { c: DailyCheckin | null; skipped: number } {
  if (c.weightKg == null || (finite(c.weightKg) && inRange(c.weightKg, PROFILE_RANGE.weight) != null)) return { c, skipped: 0 }
  const { weightKg: _w, ...rest } = c; void _w
  const left = Object.entries(rest).some(([k, v]) => k !== 'date' && k !== 'updatedAt' && v != null)
  return { c: left ? rest as DailyCheckin : null, skipped: 1 }
}

/* ---------- (v3.50) načrt, vadbe in jutranji vnosi ob branju (baza, oblak, kopija) ---------- */
const ISO_DAY = /^\d{4}-\d{2}-\d{2}$/
const isObj = (x: unknown): x is Record<string, unknown> => !!x && typeof x === 'object' && !Array.isArray(x)
const strOrNull = (x: unknown): string | null => (typeof x === 'string' ? x : null)
const KIND_TITLE: Record<string, string> = { kolo: 'Kolo', tek: 'Tek', pohod: 'Pohod', moc: 'Moč', pocitek: 'Počitek', test: 'Test' }
const SPORTS: readonly Sport[] = ['kolo', 'tek', 'pohod', 'moc', 'plavanje', 'drugo']
const SPORT_NAME: Record<Sport, string> = { kolo: 'Kolo', tek: 'Tek', pohod: 'Pohod', moc: 'Moč', plavanje: 'Plavanje', drugo: 'Vadba' }

type Ex = NonNullable<PlanDay['exercises']>[number]
const exBad = (x: unknown) => !isObj(x) || typeof x.name !== 'string' || !x.name.trim() || !finite(x.sets) || typeof x.reps !== 'string'
  || (x.kg != null && !finite(x.kg)) || (x.rest != null && !finite(x.rest))
/** Vaje: samo predmeti z imenom; serije število, ponovitve niz (»8« iz 8). Seznam brez napak ostane isti predmet. */
function normalizeExercises(list: unknown): Ex[] | undefined {
  if (!Array.isArray(list)) return undefined
  if (!list.some(exBad)) return list as Ex[]
  return list.filter((x): x is Record<string, unknown> => isObj(x) && typeof x.name === 'string' && !!x.name.trim()).map(x => (exBad(x) ? {
    ...x, name: x.name as string,
    sets: finite(x.sets) && x.sets > 0 ? x.sets : 1,
    reps: typeof x.reps === 'string' ? x.reps : finite(x.reps) ? String(x.reps) : '',
    kg: numOrNull(x.kg), rest: numOrNull(x.rest),
  } : x) as Ex)
}

/**
 * Dan načrta: brez id-ja, datuma ali vrste → null (izpusti). Naslov po vrsti (»Moč«), opis '', trajanje 0, vaje samo
 * veljavne (prej vaja brez imena ali »exercises« kot niz → Danes, Plan in Vadba »Ta zaslon se ni naložil«).
 * Veljaven dan ostane isti predmet.
 */
export function normalizePlanDay(d: PlanDay): PlanDay | null {
  if (!isObj(d)) return null
  const r = d as unknown as Record<string, unknown>
  if (typeof r.id !== 'string' || !r.id || typeof r.date !== 'string' || !ISO_DAY.test(r.date) || typeof r.kind !== 'string' || !r.kind) return null
  const tail = r.tail
  const tailBad = tail != null && (!isObj(tail) || typeof tail.kind !== 'string' || typeof tail.title !== 'string' || typeof tail.desc !== 'string' || !finite(tail.durationMin))
  const target = r.target
  const bad = typeof r.title !== 'string' || !r.title.trim() || typeof r.desc !== 'string' || !finite(r.durationMin)
    || (r.exercises != null && (!Array.isArray(r.exercises) || r.exercises.some(exBad)))
    || tailBad || (r.done != null && !isObj(r.done)) || (r.zone != null && typeof r.zone !== 'string')
    || (target != null && (!isObj(target) || !finite(target.lo) || !finite(target.hi)))
    || (r.sickPrev != null && !Array.isArray(r.sickPrev)) || (r.source != null && typeof r.source !== 'string')
  if (!bad) return d
  const out: PlanDay = {
    ...d,
    title: strOr(r.title, KIND_TITLE[r.kind] ?? 'Trening'),
    desc: typeof r.desc === 'string' ? r.desc : '',
    durationMin: finite(r.durationMin) && r.durationMin >= 0 ? r.durationMin : 0,
    zone: typeof r.zone === 'string' ? r.zone : null,
    done: isObj(r.done) ? d.done : null,
    target: isObj(target) && finite(target.lo) && finite(target.hi) ? d.target : null,
    sickPrev: Array.isArray(r.sickPrev) ? d.sickPrev : null,
    source: (typeof r.source === 'string' ? r.source : 'rules') as PlanDay['source'],
  }
  if (r.zone === undefined) delete out.zone
  if (r.done === undefined) delete out.done
  if (r.target === undefined) delete out.target
  if (r.sickPrev === undefined) delete out.sickPrev
  const ex = normalizeExercises(r.exercises)
  if (ex) out.exercises = ex; else delete out.exercises
  if (tailBad) {
    out.tail = isObj(tail) && typeof tail.kind === 'string'
      ? { ...(tail as object), kind: tail.kind as NonNullable<PlanDay['tail']>['kind'], title: strOr(tail.title, KIND_TITLE[tail.kind] ?? 'Trening'), desc: typeof tail.desc === 'string' ? tail.desc : '', durationMin: finite(tail.durationMin) ? tail.durationMin : 0 }
      : null
  }
  return out
}

/** Lokalni datum iz časa začetka (ISO z uro) — za vadbo brez datuma. */
function dayOfStart(start: unknown): string | null {
  if (typeof start !== 'string') return null
  const t = Date.parse(start)
  if (!Number.isFinite(t)) return null
  const x = new Date(t)
  return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`
}
const ACT_NUMS = ['distKm', 'durationMin', 'elapsedMin', 'elevM', 'avgHr', 'maxHr', 'avgPower', 'speedKmh', 'kcal', 'tss', 'rpe'] as const
let warnedAct = false
/**
 * Vadba: brez id-ja → null; datum niz (sicer iz začetka, sicer izpusti); šport iz znanih (sicer »drugo«), ime niz,
 * številke število ali null (prej `date: 20261018` ali `sport: 42` → Napredek, Aktivnosti in Plan se niso naložili).
 * Veljavna vadba ostane isti predmet.
 */
export function normalizeActivity(a: Activity): Activity | null {
  if (!isObj(a)) return null
  const r = a as unknown as Record<string, unknown>
  if (typeof r.id !== 'string' || !r.id) return null
  const dateOk = typeof r.date === 'string' && ISO_DAY.test(r.date)
  const date = dateOk ? r.date as string : dayOfStart(r.start)
  if (!date) {
    if (!warnedAct) { warnedAct = true; console.warn('FORMAI: vadba brez datuma je izpuščena', r.id) }
    return null
  }
  const sportOk = typeof r.sport === 'string' && (SPORTS as readonly string[]).includes(r.sport)
  const bad = !dateOk || !sportOk || typeof r.name !== 'string' || typeof r.source !== 'string'
    || ACT_NUMS.some(k => r[k] != null && !finite(r[k]))
    || (r.start != null && typeof r.start !== 'string')
    || (r.exercises != null && (!Array.isArray(r.exercises) || r.exercises.some(exBad)))
    || (r.hrZoneSec != null && !Array.isArray(r.hrZoneSec)) || (r.hrZoneTop != null && !Array.isArray(r.hrZoneTop))
    || (r.aiEligible != null && typeof r.aiEligible !== 'boolean') || (r.geoRetain != null && typeof r.geoRetain !== 'boolean')
  if (!bad) return a
  const sport = (sportOk ? r.sport : 'drugo') as Sport
  const out = { ...a, date, sport, name: typeof r.name === 'string' ? r.name : SPORT_NAME[sport], source: (typeof r.source === 'string' ? r.source : 'manual') as Activity['source'] } as Activity
  const o = out as unknown as Record<string, unknown>
  for (const k of ACT_NUMS) if (o[k] != null && !finite(o[k])) o[k] = null
  if (r.start != null && typeof r.start !== 'string') o.start = null
  for (const k of ['hrZoneSec', 'hrZoneTop'] as const) if (o[k] != null && !Array.isArray(o[k])) o[k] = null
  // pokvarjena zastavica: AI vadbe ne vidi in sled se ne hrani (varna stran)
  for (const k of ['aiEligible', 'geoRetain'] as const) if (o[k] != null && typeof o[k] !== 'boolean') o[k] = false
  const ex = normalizeExercises(r.exercises)
  if (ex) out.exercises = ex; else delete out.exercises
  return out
}

const scale5 = (x: unknown) => (finite(x) && Number.isInteger(x) && x >= 1 && x <= 5 ? x as 1 | 2 | 3 | 4 | 5 : null)
/**
 * Jutranji vnos: brez datuma → null; teža, spanec, pas število ali null, počutje 1–5, opomba niz; teža izven razpona
 * gre ven (clampCheckin). Prej je `weightKg: "osemdeset"` dal graf teže z `NaN`. Veljaven vnos ostane isti predmet.
 */
export function normalizeCheckin(c: DailyCheckin): DailyCheckin | null {
  if (!isObj(c)) return null
  const r = c as unknown as Record<string, unknown>
  if (typeof r.date !== 'string' || !ISO_DAY.test(r.date)) return null
  const bad = (['sleepH', 'weightKg', 'waistCm'] as const).some(k => r[k] != null && !finite(r[k]))
    || (['soreness', 'mood'] as const).some(k => r[k] != null && scale5(r[k]) == null)
    || (r.note != null && typeof r.note !== 'string')
  const fixed: DailyCheckin = !bad ? c : {
    ...c, sleepH: numOrNull(r.sleepH), weightKg: numOrNull(r.weightKg), waistCm: numOrNull(r.waistCm),
    soreness: scale5(r.soreness), mood: scale5(r.mood), note: strOrNull(r.note),
  }
  return clampCheckin(fixed).c
}

/** Seznam skozi normalizacijo: pokvarjeni zapisi se popravijo, nepopravljivi izpustijo. Brez sprememb isti seznam. */
export function normalizeList<T>(list: readonly T[], f: (x: T) => T | null): T[] {
  let changed = false
  const out: T[] = []
  for (const x of list) { const y = f(x); if (y !== x) changed = true; if (y) out.push(y) }
  return changed ? out : list as T[]
}
