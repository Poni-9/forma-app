import { getKV, setKV } from './db'
import type { Activity } from '@/domain/types'
import type { LatLon } from '@/domain/import/polyline'
import { fetchStreams, type IntervalsCreds } from '@/domain/intervals/client'
import { analyzeTrack, cleanTrack, dedupeRoutes, homeOf, type RouteRec } from '@/domain/routes/analyze'

/**
 * Knjižnica tras — samo na tej napravi (sledi nikoli ne gredo v oblak).
 * raw: ena trasa na vožnjo (Garmin prek intervals.icu, samo vožnje z geoRetain = ne Strava),
 * gen: nove trase, ki jih je ustvarila aplikacija (po datumu).
 */
export interface RouteLib { v: 1; raw: RouteRec[]; gen: RouteRec[]; home: LatLon | null; done: string[]; at: number }
const KEY = 'routes.v1'

export async function loadRouteLib(): Promise<RouteLib> {
  return (await getKV<RouteLib>(KEY)) || { v: 1, raw: [], gen: [], home: null, done: [], at: 0 }
}
export async function saveRouteLib(l: RouteLib): Promise<void> { await setKV(KEY, l) }

/** Trase za predloge: vožnje (združene) + nove. */
export function routesOf(l: RouteLib | null): RouteRec[] {
  if (!l) return []
  return [...dedupeRoutes(l.raw), ...l.gen]
}

/**
 * Dopolni knjižnico s sledmi voženj, ki jih še nima (največ max naenkrat, zaporedno).
 * Vožnje brez GPS (trenažer) se zabeležijo kot obdelane, da jih ne sprašujemo znova.
 */
export async function fillRouteLib(creds: IntervalsCreds, acts: readonly Activity[], max = 40): Promise<{ lib: RouteLib; added: number }> {
  const lib = await loadRouteLib()
  const done = new Set(lib.done)
  const todo = acts
    .filter(a => a.sport === 'kolo' && a.source === 'intervals' && a.geoRetain && a.ext?.intervalsId != null && !done.has(a.id) && (a.distKm || 0) >= 3)
    .sort((a, b) => b.date.localeCompare(a.date)).slice(0, max)
  let added = 0
  for (const a of todo) {
    try {
      const st = await fetchStreams(creds, a.ext!.intervalsId!)
      done.add(a.id)
      if (!st) continue
      const t = cleanTrack(st.lat, st.lng, st.alt)
      const rec = analyzeTrack({ id: a.id, source: 'voznja', name: a.name || 'Vožnja', date: a.date, rodeMin: a.durationMin ?? null, icuId: a.ext!.intervalsId ?? null }, t.pts, t.alt)
      if (rec) { lib.raw = [...lib.raw.filter(x => x.id !== rec.id), rec]; added++ }
    } catch { break }   // omrežje ali kvota — nadaljuj ob naslednjem zagonu
  }
  // vožnje, ki jih ni več (izbrisane), ven
  const ids = new Set(acts.map(a => a.id))
  lib.raw = lib.raw.filter(r => ids.has(r.id))
  lib.done = [...done].filter(id => ids.has(id))
  lib.home = homeOf(lib.raw.map(r => r.start))
  lib.at = Date.now()
  await saveRouteLib(lib)
  return { lib, added }
}

export async function addGenerated(rec: RouteRec, replaceDate?: string): Promise<RouteLib> {
  const lib = await loadRouteLib()
  lib.gen = [rec, ...lib.gen.filter(g => g.id !== rec.id && !(replaceDate && g.date === replaceDate))].slice(0, 20)
  await saveRouteLib(lib)
  return lib
}
