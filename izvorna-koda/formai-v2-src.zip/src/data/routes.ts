import { getKV, setKV } from './db'
import { stableStr } from './merge'
import type { Activity } from '@/domain/types'
import type { LatLon } from '@/domain/import/polyline'
import { fetchStreams, type IntervalsCreds } from '@/domain/intervals/client'
import { analyzeTrack, cleanTrack, dedupeRoutes, homeOf, type RouteRec } from '@/domain/routes/analyze'

/**
 * Knjižnica tras — samo na tej napravi (sledi nikoli ne gredo v oblak).
 * raw: ena trasa na vožnjo (Garmin prek intervals.icu, samo vožnje z geoRetain = ne Strava),
 * gen: nove trase, ki jih je ustvarila aplikacija (po datumu).
 * done: obdelane vožnje (po id-ju intervals.icu »icu:…«; starejši zapisi po lokalnem id-ju) — sled se prenese enkrat.
 */
export interface RouteLib { v: 1; raw: RouteRec[]; gen: RouteRec[]; home: LatLon | null; done: string[]; at: number }
const KEY = 'routes.v1'
/** največ toliko sledi na en zagon (kvota intervals.icu: aplikacija z OAuth ima 100 zahtevkov na dan) */
export const ROUTE_STREAMS_PER_RUN = 15

export async function loadRouteLib(): Promise<RouteLib> {
  return (await getKV<RouteLib>(KEY)) || { v: 1, raw: [], gen: [], home: null, done: [], at: 0 }
}
export async function saveRouteLib(l: RouteLib): Promise<void> { await setKV(KEY, l) }

/** Podpis voženj v knjižnici (id, dolžina sledi, datum, čas) — ob enakem podpisu je združevanje enako. */
export function libSig(l: RouteLib | null): string {
  return l ? l.raw.map(r => `${r.id}:${r.poly.length}:${r.date || ''}:${r.rodeMin ?? ''}`).join('|') : ''
}
let deduped: { sig: string; out: RouteRec[] } | null = null
/**
 * Trase za predloge: vožnje (združene) + nove. Združevanje (primerjava sledi) teče enkrat na spremembo knjižnice,
 * ne ob vsakem odprtju zaslona. Vrnjenih zapisov ne spreminjaj.
 */
export function routesOf(l: RouteLib | null): RouteRec[] {
  if (!l) return []
  const sig = libSig(l)
  if (!deduped || deduped.sig !== sig) deduped = { sig, out: dedupeRoutes(l.raw) }
  return [...deduped.out, ...l.gen]
}

const icuKey = (id: string | number) => `icu:${id}`
/** Vožnja sme v knjižnico tras: kolo iz intervals.icu, z izvorom, ki sme na karto (ne Strava). */
const routable = (a: Activity) => a.sport === 'kolo' && a.source === 'intervals' && !!a.geoRetain && a.ext?.intervalsId != null

/**
 * Dopolni knjižnico s sledmi voženj, ki jih še nima (največ max naenkrat, zaporedno, vsaka vožnja enkrat).
 * Vožnje brez GPS (trenažer, 404, prazna sled) se zabeležijo kot obdelane, da jih ne sprašujemo znova.
 * Napaka (odjava 401/403, kvota 429 ali poraba dnevnega proračuna, strežnik, omrežje) ustavi krog — vožnja NI
 * označena in pride na vrsto ob naslednjem zagonu. Knjižnica se shrani samo, če se je kaj spremenilo.
 */
export async function fillRouteLib(creds: IntervalsCreds, acts: readonly Activity[], max = ROUTE_STREAMS_PER_RUN): Promise<{ lib: RouteLib; added: number; error: unknown }> {
  const lib = await loadRouteLib()
  const before = stableStr({ raw: libSig(lib), gen: lib.gen.map(g => g.id), home: lib.home, done: [...lib.done].sort() })
  const done = new Set(lib.done)
  const have = new Set(lib.raw.map(r => r.id))
  const haveIcu = new Set(lib.raw.map(r => (r.icuId != null ? String(r.icuId) : '')).filter(Boolean))
  const todo = acts
    .filter(a => routable(a) && (a.distKm || 0) >= 3 && !done.has(a.id) && !done.has(icuKey(a.ext!.intervalsId!)) && !have.has(a.id) && !haveIcu.has(String(a.ext!.intervalsId)))
    .sort((a, b) => b.date.localeCompare(a.date)).slice(0, Math.max(0, max))
  let added = 0, error: unknown = null
  for (const a of todo) {
    let st: Awaited<ReturnType<typeof fetchStreams>>
    try { st = await fetchStreams(creds, a.ext!.intervalsId!) }
    catch (e) { error = e; break }   // odjava, kvota, strežnik, omrežje — nadaljuj ob naslednjem zagonu
    done.add(icuKey(a.ext!.intervalsId!))
    if (!st) continue
    const t = cleanTrack(st.lat, st.lng, st.alt)
    const rec = analyzeTrack({ id: a.id, source: 'voznja', name: a.name || 'Vožnja', date: a.date, rodeMin: a.durationMin ?? null, icuId: a.ext!.intervalsId ?? null }, t.pts, t.alt)
    if (rec) { lib.raw = [...lib.raw.filter(x => x.id !== rec.id), rec]; added++ }
  }
  // vožnje, ki jih ni več (izbrisane) ali ne smejo na karto (npr. izvor naknadno prepoznan kot Strava), ven
  const ok = new Map(acts.filter(routable).map(a => [a.id, a] as const))
  const icuOk = new Set([...ok.values()].map(a => icuKey(a.ext!.intervalsId!)))
  // ista vožnja pod novim lokalnim id-jem (združitev naprav) — trasa ostane, samo id se posodobi
  const byIcu = new Map([...ok.values()].map(a => [String(a.ext!.intervalsId), a.id] as const))
  lib.raw = lib.raw
    .map(r => (ok.has(r.id) || r.icuId == null || !byIcu.has(String(r.icuId)) ? r : { ...r, id: byIcu.get(String(r.icuId))! }))
    .filter((r, i, arr) => ok.has(r.id) && arr.findIndex(x => x.id === r.id) === i)
  lib.done = [...done].filter(id => ok.has(id) || icuOk.has(id)).sort()
  lib.home = homeOf(lib.raw.map(r => r.start))
  const after = stableStr({ raw: libSig(lib), gen: lib.gen.map(g => g.id), home: lib.home, done: lib.done })
  if (after !== before) { lib.at = Date.now(); await saveRouteLib(lib) }
  return { lib, added, error }
}

export async function addGenerated(rec: RouteRec, replaceDate?: string): Promise<RouteLib> {
  const lib = await loadRouteLib()
  lib.gen = [rec, ...lib.gen.filter(g => g.id !== rec.id && !(replaceDate && g.date === replaceDate))].slice(0, 20)
  await saveRouteLib(lib)
  return lib
}
