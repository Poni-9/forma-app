import { core } from './firebase'
import * as repo from './repo'
import { getKV, setKV } from './db'
import { cloudSafe } from './cloudSafe'
import { mergeState, stableStr, type SyncState, type Tomb } from './merge'
import type { Activity, DailyCheckin, MealEntry, PlanDay, Profile, Settings } from '@/domain/types'

/**
 * Sinhronizacija v Firestore: dokument 'formaSync/{uid}', polje 'v2'.
 * Isti dokument uporablja stara aplikacija (polji 'forma' in 'kalorije') — teh se ne dotikamo.
 *
 * Pravila:
 *  1) Sledi (polyline) in sličice (thumb) NIKOLI ne gredo v oblak — ostanejo na napravi.
 *  2) Nobena naprava ne prepiše druge. Ob vsakem usklajevanju se podatki te naprave in oblaka ZDRUŽIJO
 *     (merge.ts: unija po zapisih, izbris samo z grobom). Branje, združitev in zapis v oblak so ena
 *     transakcija — če medtem piše druga naprava, se vse ponovi z njenimi podatki.
 *  (Do 24. 9. 2026 je veljalo »novejša naprava prepiše vse« — tako so izginjali obroki.)
 */
export interface SyncStatus { state: 'off' | 'idle' | 'push' | 'pull' | 'error'; at?: number; msg?: string }

interface CloudV2 {
  _v: 2
  _ts: number
  profile: Profile
  settings: Settings
  activities: Activity[]
  plan: PlanDay[]
  meals: MealEntry[]
  checkins: DailyCheckin[]
  tomb?: Tomb
  trimmed?: boolean
}

// nova imena ključev: prvo usklajevanje po posodobitvi je vedno polna združitev
const K = { localTs: 'sync.localTs', syncedLocal: 'sync2.syncedLocal', remoteTs: 'sync2.remoteTs' }
const MAX_BYTES = 700_000          // Firestore meja je 1 MiB; puščamo rezervo za polji stare aplikacije
const KEEP_ACTS = 400
const KEEP_MEAL_DAYS = 120

let status: SyncStatus = { state: 'off' }
const subs = new Set<(s: SyncStatus) => void>()
function setStatus(s: SyncStatus) { status = s; for (const f of subs) f(s) }
export function onSyncStatus(cb: (s: SyncStatus) => void): () => void { subs.add(cb); cb(status); return () => { subs.delete(cb) } }
export function syncStatus(): SyncStatus { return status }

let uid: string | null = null
let timer: number | null = null
let pushTimer: number | null = null
let running: Promise<boolean> | null = null
let onChanged: (() => void) | null = null
let offVis: (() => void) | null = null
/**
 * Poslušanje oblaka (onSnapshot): _ts zadnjega zapisa v oblaku, kot ga je javil strežnik; null = ne poslušamo
 * (napaka, preizkusi) → takrat vsakih 20 s polno usklajevanje kot prej. Ko poslušamo in se ni nič spremenilo
 * ne tu ne v oblaku, usklajevanje ne prenese dokumenta in ne bere baze (prej ~0,5 MB vsakih 20 s).
 */
let snapTs: number | null = null
let offSnap: (() => void) | null = null
let lastFull = 0
const FULL_EVERY = 5 * 60_000

/** Kliče store ob vsaki lokalni spremembi: zabeleži čas in načrtuje usklajevanje. */
export async function touch(): Promise<void> {
  await setKV(K.localTs, Date.now())
  if (!uid) return
  if (pushTimer) clearTimeout(pushTimer)
  pushTimer = window.setTimeout(() => { pushTimer = null; void syncNow() }, 3000)
}

/* ---------- oblika za oblak ---------- */
const actOrder = (a: Activity, b: Activity) => (b.date + (b.start || '')).localeCompare(a.date + (a.start || '')) || a.id.localeCompare(b.id)
const mealOrder = (a: MealEntry, b: MealEntry) => a.date.localeCompare(b.date) || (a.time || '').localeCompare(b.time || '') || (a.createdAt || '').localeCompare(b.createdAt || '') || a.id.localeCompare(b.id)

/** Stanje → zapis za oblak: brez sledi in sličic, urejeno (za primerjavo), po potrebi skrajšano. */
export function toCloud(s: SyncState, ts: number): { payload: CloudV2; bytes: number } {
  let activities = s.activities.map(a => ({ ...a, polyline: null })).sort(actOrder)
  let meals = s.meals.map(m => ({ ...m, thumb: null })).sort(mealOrder)
  const plan = [...s.plan].sort((a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id))
  const checkins = [...s.checkins].sort((a, b) => a.date.localeCompare(b.date))
  // cloudSafe: Firestore zavrne cel zapis že zaradi enega polja `undefined`
  const make = (trimmed: boolean): CloudV2 => cloudSafe({
    _v: 2, _ts: ts,
    profile: s.profile || repo.defaultProfile(),
    settings: s.settings || repo.defaultSettings(),
    activities, plan, meals, checkins, tomb: s.tomb || {}, trimmed,
  } as CloudV2)
  let payload = make(false)
  let bytes = JSON.stringify(payload).length
  if (bytes > MAX_BYTES) {
    activities = activities.slice(0, KEEP_ACTS)
    const cutoff = new Date(Date.now() - KEEP_MEAL_DAYS * 86400_000).toISOString().slice(0, 10)
    meals = meals.filter(m => m.date >= cutoff)
    payload = make(true)
    bytes = JSON.stringify(payload).length
  }
  return { payload, bytes }
}

export function fromCloud(v: Partial<CloudV2>): SyncState {
  const arr = <T,>(x: T[] | undefined) => (Array.isArray(x) ? x.filter(Boolean) : [])
  return {
    profile: v.profile || null, settings: v.settings || null,
    activities: arr(v.activities), plan: arr(v.plan), meals: arr(v.meals), checkins: arr(v.checkins),
    tomb: v.tomb && typeof v.tomb === 'object' ? v.tomb : {},
  }
}

async function readLocal(): Promise<SyncState> {
  const all = await repo.exportAll()
  return {
    profile: (all.profile as Profile | undefined) ?? null,
    settings: (all.settings as Settings | undefined) ?? null,
    activities: all.activities as Activity[], plan: all.plan as PlanDay[], meals: all.meals as MealEntry[], checkins: all.checkins as DailyCheckin[],
    tomb: await repo.getTomb(),
  }
}

/* ---------- usklajevanje ---------- */
/** Prebere oblak, združi s to napravo, zapiše razlike na obe strani. Vrne true, če se je na napravi kaj spremenilo. */
async function syncOnce(): Promise<boolean> {
  const localTs = (await getKV<number>(K.localTs)) || 0
  const synced = (await getKV<number>(K.syncedLocal)) || 0
  const known = (await getKV<number>(K.remoteTs)) || 0
  // oblak se ni spremenil (javlja poslušalec) in tu ni novega → brez prenosa; vsakih 5 min vseeno polno
  if (snapTs != null && snapTs === known && localTs <= synced && Date.now() - lastFull < FULL_EVERY) return false
  const c = await core()
  if (!c) throw new Error('Ni povezave.')
  const ref = c.fsMod.doc(c.fs, 'formaSync', uid!)
  const local = await readLocal()
  let merged: SyncState | null = null, remoteTs = 0, wrote = 0
  await c.fsMod.runTransaction(c.fs, async tx => {
    merged = null; wrote = 0
    const snap = await tx.get(ref)
    const v2 = snap.exists() ? (snap.data() as { v2?: CloudV2 }).v2 : undefined
    remoteTs = v2?._ts || 0
    if (v2 && remoteTs === known && localTs <= synced) return            // nič novega ne tu ne v oblaku
    const remote = v2 ? fromCloud(v2) : null
    const m = remote ? mergeState(local, remote, Date.now()) : local
    merged = m
    if (remote && stableStr(toCloud(m, 0).payload) === stableStr(toCloud(remote, 0).payload)) return
    const out = toCloud(m, Math.max(Date.now(), remoteTs + 1))
    if (out.bytes > 950_000) throw new Error('Podatkov je preveč za sinhronizacijo (nad 950 kB).')
    // mergeFields: polje v2 se zamenja v celoti, polja stare aplikacije ostanejo
    tx.set(ref, { v2: out.payload }, { mergeFields: ['v2'] })
    wrote = out.payload._ts
  })
  const m = merged as SyncState | null
  const changed = m ? await repo.applyMerged(local, m) : false
  await setKV(K.syncedLocal, localTs)
  await setKV(K.remoteTs, wrote || remoteTs)
  if (snapTs != null && wrote) snapTs = wrote     // lastni zapis: poslušalec ga bo javil, a ni nov
  lastFull = Date.now()
  return changed
}

/** Poslušalec dokumenta v oblaku: ob zapisu druge naprave takoj uskladi (brez rednega prenašanja). */
async function listen(u: string): Promise<void> {
  const c = await core().catch(() => null)
  if (!c || uid !== u || typeof c.fsMod.onSnapshot !== 'function') return
  const ref = c.fsMod.doc(c.fs, 'formaSync', u)
  offSnap = c.fsMod.onSnapshot(ref, { includeMetadataChanges: false }, snap => {
    if (uid !== u || snap.metadata.fromCache || snap.metadata.hasPendingWrites) return
    const ts = (snap.exists() ? (snap.get('v2._ts') as number | undefined) : undefined) || 0
    const first = snapTs == null
    snapTs = ts
    // med tekočim usklajevanjem: še enkrat po njem (poceni, če je že vse prevzeto)
    void getKV<number>(K.remoteTs).then(known => { if (first || ts !== (known || 0)) void (running ? running.finally(() => syncNow()) : syncNow()) })
  }, () => { snapTs = null; offSnap?.(); offSnap = null })     // napaka (pravila, omrežje) → redno usklajevanje
}

/** Uskladi zdaj (ena naenkrat — sočasni klici dobijo isti rezultat). */
export function syncNow(): Promise<boolean> {
  if (!uid) return Promise.resolve(false)
  if (running) return running
  // »usklajujem« šele, če traja več kot 0,7 s — hitro usklajevanje v ozadju (vsakih 20 s) ne sproži izrisa zaslona
  const busy = setTimeout(() => setStatus({ state: 'pull', at: Date.now() }), 700)
  running = syncOnce()
    .then(changed => { setStatus({ state: 'idle', at: Date.now(), msg: changed ? 'Združeno s podatki druge naprave.' : undefined }); if (changed) onChanged?.(); return changed })
    .catch(e => { setStatus({ state: 'error', at: Date.now(), msg: (e as Error)?.message || 'Usklajevanje ni uspelo.' }); return false })
    .finally(() => { clearTimeout(busy); running = null })
  return running
}
/** Za staro ime (gumb »uskladi zdaj«, odjava). */
export const pushNow = async (): Promise<void> => { await syncNow() }

/* ---------- življenjski cikel ---------- */
/** onFirst: ko je prvo usklajevanje končano (uspešno ali ne) — šele takrat smejo teči samodejni uvozi. */
export function startSync(u: string, onPulled?: () => void, onFirst?: () => void): void {
  stopSync()
  uid = u
  onChanged = onPulled || null
  setStatus({ state: 'idle', at: Date.now() })
  void syncNow().finally(() => onFirst?.())
  void listen(u)
  // ko poslušalec teče, je to le poceni preverba (brez omrežja); sicer polno usklajevanje kot prej
  timer = window.setInterval(() => { void syncNow() }, 20_000)
  const onVis = () => { void syncNow() }
  const onFocus = () => { void syncNow() }
  const onUnload = () => { void syncNow() }
  document.addEventListener('visibilitychange', onVis)
  window.addEventListener('focus', onFocus)
  window.addEventListener('beforeunload', onUnload)
  offVis = () => { document.removeEventListener('visibilitychange', onVis); window.removeEventListener('focus', onFocus); window.removeEventListener('beforeunload', onUnload) }
}

export function stopSync(): void {
  if (offSnap) { offSnap(); offSnap = null }
  snapTs = null; lastFull = 0
  if (timer) { clearInterval(timer); timer = null }
  if (pushTimer) { clearTimeout(pushTimer); pushTimer = null }
  if (offVis) { offVis(); offVis = null }
  uid = null
  onChanged = null
  setStatus({ state: 'off' })
}

/** Za preizkus: sledi iz oblaka se ne smejo izgubiti (zdaj to naredi merge.ts). */
export function keepLocalTracks(remote: Activity[], local: Activity[]): Activity[] {
  const mine = new Map(local.filter(a => a.polyline).map(a => [a.id, a.polyline as string] as const))
  return remote.map(a => (!a.polyline && mine.has(a.id)) ? { ...a, polyline: mine.get(a.id) as string } : a)
}
