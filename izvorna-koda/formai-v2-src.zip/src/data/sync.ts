import { core } from './firebase'
import * as repo from './repo'
import { getKV, setKV } from './db'
import type { Activity, DailyCheckin, MealEntry, PlanDay, Profile, Settings } from '@/domain/types'

/**
 * Sinhronizacija v Firestore: dokument 'formaSync/{uid}', polje 'v2'.
 * Isti dokument uporablja stara aplikacija (polji 'forma' in 'kalorije') — teh se ne dotikamo,
 * ker so varnostna pravila znana samo za to pot.
 *
 * Dve trdi pravili:
 *  1) Sledi (polyline) in sličice (thumb) NIKOLI ne gredo v oblak — ostanejo na napravi.
 *  2) Ob prvem združevanju naprave z oblakom se podatki ZDRUŽIJO (nič se ne izgubi);
 *     šele potem velja »zadnji zapis zmaga« po časovnem žigu dokumenta.
 */
export interface SyncStatus { state: 'off' | 'idle' | 'push' | 'pull' | 'error'; at?: number; msg?: string }

interface CloudV2 {
  _v: 2
  _ts: number
  profile: Profile
  settings: Settings
  activities: Activity[]
  plan: PlanDay[]
  meals: MealEntry[]
  checkins: DailyCheckin[]
  trimmed?: boolean
}

const K = { localTs: 'sync.localTs', pushedTs: 'sync.pushedTs', remoteTs: 'sync.remoteTs', init: (uid: string) => `sync.init.${uid}` }
const MAX_BYTES = 700_000          // Firestore meja je 1 MiB; puščamo rezervo za polji stare aplikacije
const KEEP_ACTS = 400
const KEEP_MEAL_DAYS = 120

let status: SyncStatus = { state: 'off' }
const subs = new Set<(s: SyncStatus) => void>()
function setStatus(s: SyncStatus) { status = s; for (const f of subs) f(s) }
export function onSyncStatus(cb: (s: SyncStatus) => void): () => void { subs.add(cb); cb(status); return () => { subs.delete(cb) } }
export function syncStatus(): SyncStatus { return status }

let uid: string | null = null
let timer: number | null = null
let pushTimer: number | null = null
let busy = false
let offVis: (() => void) | null = null

/** Kliče store ob vsaki lokalni spremembi: zabeleži čas in načrtuje pošiljanje. */
export async function touch(): Promise<void> {
  await setKV(K.localTs, Date.now())
  if (!uid) return
  if (pushTimer) clearTimeout(pushTimer)
  pushTimer = window.setTimeout(() => { pushTimer = null; void pushNow() }, 3000)
}

/* ---------- oblika za oblak ---------- */
function stripActivity(a: Activity): Activity { return { ...a, polyline: null } }
function stripMeal(m: MealEntry): MealEntry { return { ...m, thumb: null } }

async function buildPayload(): Promise<{ payload: CloudV2; bytes: number }> {
  const all = await repo.exportAll()
  const localTs = (await getKV<number>(K.localTs)) || Date.now()
  let activities = (all.activities as Activity[]).map(stripActivity).sort((a, b) => (b.date + (b.start || '')).localeCompare(a.date + (a.start || '')))
  let meals = (all.meals as MealEntry[]).map(stripMeal)
  let trimmed = false
  const make = (): CloudV2 => ({
    _v: 2, _ts: localTs,
    profile: (all.profile as Profile) || repo.defaultProfile(),
    settings: (all.settings as Settings) || repo.defaultSettings(),
    activities, plan: all.plan as PlanDay[], meals, checkins: all.checkins as DailyCheckin[], trimmed,
  })
  let payload = make()
  let bytes = JSON.stringify(payload).length
  if (bytes > MAX_BYTES) {
    trimmed = true
    activities = activities.slice(0, KEEP_ACTS)
    const cutoff = new Date(Date.now() - KEEP_MEAL_DAYS * 86400_000).toISOString().slice(0, 10)
    meals = meals.filter(m => m.date >= cutoff)
    payload = make()
    bytes = JSON.stringify(payload).length
  }
  return { payload, bytes }
}

/* ---------- pošiljanje ---------- */
export async function pushNow(): Promise<void> {
  if (!uid || busy) return
  const localTs = (await getKV<number>(K.localTs)) || 0
  const pushedTs = (await getKV<number>(K.pushedTs)) || 0
  if (localTs <= pushedTs) return
  const c = await core()
  if (!c) { setStatus({ state: 'error', at: Date.now(), msg: 'Ni povezave.' }); return }
  busy = true
  setStatus({ state: 'push', at: Date.now() })
  try {
    const { payload, bytes } = await buildPayload()
    if (bytes > 950_000) throw new Error('Podatkov je preveč za sinhronizacijo (nad 950 kB).')
    await c.fsMod.setDoc(c.fsMod.doc(c.fs, 'formaSync', uid), { v2: payload }, { merge: true })
    await setKV(K.pushedTs, payload._ts)
    await setKV(K.remoteTs, payload._ts)
    setStatus({ state: 'idle', at: Date.now(), msg: payload.trimmed ? 'Sinhronizirano (najstarejši zapisi ostanejo samo na tej napravi).' : undefined })
  } catch (e) {
    setStatus({ state: 'error', at: Date.now(), msg: (e as Error).message || 'Pošiljanje ni uspelo.' })
  } finally { busy = false }
}

/* ---------- prevzem ---------- */
/** Ob prevzemu iz oblaka lokalnih sledi ne smemo izgubiti — po id-ju jih prenesemo na prevzeti zapis. */
export function keepLocalTracks(remote: Activity[], local: Activity[]): Activity[] {
  const mine = new Map(local.filter(a => a.polyline).map(a => [a.id, a.polyline as string] as const))
  return remote.map(a => (!a.polyline && mine.has(a.id)) ? { ...a, polyline: mine.get(a.id) as string } : a)
}
function keepLocalThumbs(remote: MealEntry[], local: MealEntry[]): MealEntry[] {
  const mine = new Map(local.filter(m => m.thumb).map(m => [m.id, m.thumb as string] as const))
  return remote.map(m => (!m.thumb && mine.has(m.id)) ? { ...m, thumb: mine.get(m.id) as string } : m)
}

export async function pullNow(): Promise<boolean> {
  if (!uid || busy) return false
  const c = await core()
  if (!c) return false
  busy = true
  setStatus({ state: 'pull', at: Date.now() })
  try {
    const snap = await c.fsMod.getDoc(c.fsMod.doc(c.fs, 'formaSync', uid))
    const remote = (snap.exists() ? (snap.data() as { v2?: CloudV2 }).v2 : undefined) || null
    const initialized = !!(await getKV<boolean>(K.init(uid)))
    const localTs = (await getKV<number>(K.localTs)) || 0
    const remoteTs = (await getKV<number>(K.remoteTs)) || 0

    if (!remote) {
      // v oblaku še ni nič — lokalno je vir resnice
      await setKV(K.init(uid), true)
      setStatus({ state: 'idle', at: Date.now() })
      busy = false
      await pushNow()
      return false
    }

    if (!initialized) {
      // prva združitev te naprave z oblakom: ZDRUŽI, nikoli ne prepiši
      await mergeRemote(remote)
      await setKV(K.init(uid), true)
      await setKV(K.remoteTs, remote._ts)
      await setKV(K.localTs, Date.now())
      setStatus({ state: 'idle', at: Date.now(), msg: 'Podatki združeni z oblakom.' })
      busy = false
      await pushNow()
      return true
    }

    if (remote._ts > localTs && remote._ts !== remoteTs) {
      // druga naprava je novejša → prevzemi njeno stanje (sledi ostanejo lokalne)
      await replaceWithRemote(remote)
      await setKV(K.remoteTs, remote._ts)
      await setKV(K.localTs, remote._ts)
      await setKV(K.pushedTs, remote._ts)
      setStatus({ state: 'idle', at: Date.now(), msg: 'Prevzeto z druge naprave.' })
      return true
    }
    setStatus({ state: 'idle', at: Date.now() })
    return false
  } catch (e) {
    setStatus({ state: 'error', at: Date.now(), msg: (e as Error).message || 'Prevzem ni uspel.' })
    return false
  } finally { busy = false }
}

async function mergeRemote(r: CloudV2): Promise<void> {
  const localProfile = await repo.loadProfile()
  const remoteNewer = (r.profile?.updatedAt || '') > (localProfile.updatedAt || '')
  const localHasData = !!(localProfile.onboardingDone || localProfile.name)
  if (remoteNewer || !localHasData) await repo.saveProfile({ ...localProfile, ...r.profile, onboardingDone: localProfile.onboardingDone || !!r.profile?.onboardingDone })
  const s = await repo.loadSettings()
  await repo.saveSettings({ ...s, ...(r.settings || {}), intervals: s.intervals || r.settings?.intervals || null })
  const local = await repo.allActivities()
  if (r.activities?.length) await repo.addActivities(keepLocalTracks(r.activities, local))
  if (r.plan?.length) await repo.upsertPlanDays(r.plan.filter(d => !!d && !!d.date))
  for (const m of r.meals || []) if (m && m.id) await repo.putMeal(m)
  for (const ck of r.checkins || []) if (ck && ck.date) await repo.putCheckin(ck)
}

async function replaceWithRemote(r: CloudV2): Promise<void> {
  const localActs = await repo.allActivities()
  const localMeals = await repo.allMeals()
  await repo.replaceCollections({
    activities: keepLocalTracks(r.activities || [], localActs),
    plan: (r.plan || []).filter(d => !!d && !!d.date),
    meals: keepLocalThumbs(r.meals || [], localMeals),
    checkins: r.checkins || [],
  })
  if (r.profile) await repo.saveProfile(r.profile)
  if (r.settings) await repo.saveSettings(r.settings)
}

/* ---------- življenjski cikel ---------- */
export function startSync(u: string, onPulled?: () => void): void {
  stopSync()
  uid = u
  setStatus({ state: 'idle', at: Date.now() })
  const tick = async () => { const got = await pullNow(); if (got) onPulled?.(); await pushNow() }
  void tick()
  timer = window.setInterval(tick, 20_000)
  const onVis = () => { if (document.visibilityState === 'hidden') void pushNow(); else void tick() }
  const onFocus = () => { void tick() }
  const onUnload = () => { void pushNow() }
  document.addEventListener('visibilitychange', onVis)
  window.addEventListener('focus', onFocus)
  window.addEventListener('beforeunload', onUnload)
  offVis = () => { document.removeEventListener('visibilitychange', onVis); window.removeEventListener('focus', onFocus); window.removeEventListener('beforeunload', onUnload) }
}

export function stopSync(): void {
  if (timer) { clearInterval(timer); timer = null }
  if (pushTimer) { clearTimeout(pushTimer); pushTimer = null }
  if (offVis) { offVis(); offVis = null }
  uid = null
  setStatus({ state: 'off' })
}
