import { core } from './firebase'
import * as repo from './repo'
import { getKV, setKV, bumpKV } from './db'
import { cloudSafe } from './cloudSafe'
import { mergeState, stableStr, withoutDeviceLocal, keepDeviceLocal, type SyncState } from './merge'
import type { Activity, DailyCheckin, MealEntry, PlanDay, Profile, Settings } from '@/domain/types'

/**
 * Sinhronizacija v Firestore: dokument 'formaSync/{uid}', polje 'v2'.
 * Isti dokument uporablja stara aplikacija (polji 'forma' in 'kalorije') — teh se ne dotikamo.
 *
 * Pravila:
 *  1) Sledi (polyline), sličice (thumb) in podatki z ure (spanec, HRV, utrip; nastavitev wellnessOn) NIKOLI ne gredo v oblak.
 *  2) Nobena naprava ne prepiše druge. Ob vsakem usklajevanju se podatki te naprave in oblaka ZDRUŽIJO
 *     (merge.ts: unija po zapisih, izbris samo z grobom). Branje, združitev in zapis v oblak so ena
 *     transakcija — če medtem piše druga naprava, se vse ponovi z njenimi podatki.
 *  3) Naprava, ki se s tem računom še ni uspešno uskladila, profila in nastavitev ne pošlje čez račun:
 *     prvo usklajevanje vzame profil in nastavitve z računa (razen novejše povezave intervals.icu in privolitve za AI).
 *  4) Podatki na napravi pripadajo enemu računu (sync.owner). Drug račun na isti napravi se ne združi
 *     (store vpraša, ali naj podatke prejšnjega računa pobriše).
 *  5) Če dokumenta v oblaku ni več, naprava pa se je z njim že usklajevala, je bil račun izbrisan drugje:
 *     sinhronizacija se ustavi in dokument se NE ustvari znova.
 */
export interface SyncStatus { state: 'off' | 'idle' | 'push' | 'pull' | 'error'; at?: number; msg?: string }
/** Izid prvega usklajevanja po prijavi: 'ok' = račun ima podatke (prevzeti), 'empty' = račun je bil prazen (naprava je poslala svoje), 'error' = ni uspelo. */
export type FirstSyncResult = 'ok' | 'empty' | 'error'
export interface SyncOwner { uid: string; email: string | null }

interface CloudV2 {
  _v: 2
  _ts: number
  profile: Profile | null
  settings: Settings | null
  activities: Activity[]
  plan: PlanDay[]
  meals: MealEntry[]
  checkins: DailyCheckin[]
  tomb?: Record<string, number>
  /** zastarelo — pisale so ga stare različice; ne pišemo ga več */
  trimmed?: boolean
}

export type SyncErrorKind = 'network' | 'clash' | 'deleted' | 'size' | 'denied' | 'other'
export class SyncError extends Error {
  constructor(readonly kind: SyncErrorKind, message: string) { super(message); this.name = 'SyncError' }
}

// števec sprememb (monoton, ne ura) in stanje zadnjega usklajevanja
const K = { localSeq: 'sync3.localSeq', syncedSeq: 'sync3.syncedSeq', remoteTs: 'sync2.remoteTs', owner: 'sync.owner' }
/** Firestore meja je 1 MiB (UTF-8); puščamo rezervo za polji stare aplikacije. */
export const MAX_BYTES = 700_000
export const HARD_MAX_BYTES = 950_000
/** načrt in jutranji vnosi v oblaku: zadnjih 400 dni (na napravi ostane vse) */
export const KEEP_HISTORY_DAYS = 400
/** stopnje krajšanja kopije v oblaku, dokler ni pod MAX_BYTES (na napravi ostane vse) */
const LEVELS = [
  { acts: Infinity, mealDays: Infinity, histDays: KEEP_HISTORY_DAYS },
  { acts: 400, mealDays: 120, histDays: KEEP_HISTORY_DAYS },
  { acts: 250, mealDays: 60, histDays: 180 },
  { acts: 120, mealDays: 30, histDays: 90 },
]

/** števec sprememb, dokler ga ni (prva sprememba ga dvigne nad to vrednost) */
const LOCAL_SEQ_START = 1

let status: SyncStatus = { state: 'off' }
const subs = new Set<(s: SyncStatus) => void>()
function setStatus(s: SyncStatus) { status = s; for (const f of subs) f(s) }
export function onSyncStatus(cb: (s: SyncStatus) => void): () => void { subs.add(cb); cb(status); return () => { subs.delete(cb) } }
export function syncStatus(): SyncStatus { return status }

let uid: string | null = null
let timer: number | null = null
let pushTimer: number | null = null
let running: Promise<boolean> | null = null
let onChanged: (() => void) | null = null
let offVis: (() => void) | null = null
let hooks: SyncHooks = {}
let firstCb: ((r: FirstSyncResult) => void) | null = null
let firstState: 'pending' | 'error' | 'done' = 'done'
/**
 * Poslušanje oblaka (onSnapshot): največji _ts, ki ga je javil strežnik (nikoli nazaj); null = ne poslušamo
 * (napaka, preizkusi) → takrat vsakih 20 s polno usklajevanje kot prej. Ko poslušamo in se ni nič spremenilo
 * ne tu ne v oblaku, usklajevanje ne prenese dokumenta in ne bere baze (prej ~0,5 MB vsakih 20 s).
 */
let snapTs: number | null = null
let offSnap: (() => void) | null = null
let lastFull = 0
/** poslušalec je videl izbris ali _ts nazaj — naslednje usklajevanje je polno */
let forceFull = false
const FULL_EVERY = 5 * 60_000

/** Kliče store ob vsaki lokalni spremembi: poveča števec sprememb in načrtuje usklajevanje. */
export async function touch(): Promise<void> {
  await bumpKV(K.localSeq, LOCAL_SEQ_START)
  if (!uid) return
  if (pushTimer) clearTimeout(pushTimer)
  pushTimer = window.setTimeout(() => { pushTimer = null; void syncNow({ quick: true }) }, 3000)
}

/* ---------- oblika za oblak ---------- */
const actOrder = (a: Activity, b: Activity) => (b.date + (b.start || '')).localeCompare(a.date + (a.start || '')) || a.id.localeCompare(b.id)
const mealOrder = (a: MealEntry, b: MealEntry) => a.date.localeCompare(b.date) || (a.time || '').localeCompare(b.time || '') || (a.createdAt || '').localeCompare(b.createdAt || '') || a.id.localeCompare(b.id)
const stripAct = (a: Activity): Activity => { const { polyline: _p, ...rest } = a; void _p; return rest as Activity }
const stripMeal = (m: MealEntry): MealEntry => { const { thumb: _t, ...rest } = m; void _t; return rest as MealEntry }
const utf8Len = (s: string) => (typeof TextEncoder !== 'undefined' ? new TextEncoder().encode(s).length : unescape(encodeURIComponent(s)).length)

/**
 * Stanje → zapis za oblak: brez sledi, sličic in nastavitev naprave, urejeno (za primerjavo), načrt in jutranji
 * vnosi zadnjih 400 dni; če je večje od MAX_BYTES (UTF-8), stopnjevano skrajšano (aktivnosti, obroki, zgodovina).
 */
export function toCloud(s: SyncState, ts: number, now: number = Date.now()): { payload: CloudV2; bytes: number; level: number } {
  const day = (d: number) => (Number.isFinite(d) ? new Date(now - d * 86400_000).toISOString().slice(0, 10) : '')
  const acts = s.activities.filter(a => !(a.expiresAt && Date.parse(a.expiresAt) < now)).map(stripAct).sort(actOrder)
  const meals = s.meals.map(stripMeal).sort(mealOrder)
  const plan = [...s.plan].sort((a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id))
  const checkins = [...s.checkins].sort((a, b) => a.date.localeCompare(b.date))
  const settings = s.settings ? withoutDeviceLocal(s.settings) : null
  let payload!: CloudV2, bytes = 0, level = 0
  for (; level < LEVELS.length; level++) {
    const L = LEVELS[level]!, hist = day(L.histDays), mealCut = day(L.mealDays)
    // cloudSafe: Firestore zavrne cel zapis že zaradi enega polja `undefined`
    payload = cloudSafe({
      _v: 2, _ts: ts, profile: s.profile ?? null, settings,
      activities: Number.isFinite(L.acts) ? acts.slice(0, L.acts) : acts,
      plan: plan.filter(d => d.date >= hist), meals: meals.filter(m => m.date >= mealCut), checkins: checkins.filter(c => c.date >= hist),
      tomb: s.tomb || {},
    } as CloudV2)
    bytes = utf8Len(JSON.stringify(payload))
    if (bytes <= MAX_BYTES) break
  }
  return { payload, bytes, level: Math.min(level, LEVELS.length - 1) }
}

export function fromCloud(v: Partial<CloudV2>): SyncState {
  const arr = <T,>(x: T[] | undefined) => (Array.isArray(x) ? x.filter(Boolean) : [])
  return {
    profile: v.profile || null, settings: v.settings ? withoutDeviceLocal(v.settings) : null,
    activities: arr(v.activities), plan: arr(v.plan), meals: arr(v.meals), checkins: arr(v.checkins),
    tomb: v.tomb && typeof v.tomb === 'object' ? v.tomb : {},
  }
}

async function readLocal(): Promise<SyncState> {
  const all = await repo.exportAll()
  return {
    profile: (all.profile as Profile | undefined) ?? null,
    settings: (all.settings as Settings | undefined) ?? null,
    activities: all.activities as Activity[], plan: all.plan as PlanDay[], meals: all.meals as MealEntry[], checkins: all.checkins as DailyCheckin[],
    tomb: await repo.getTomb(),
  }
}

function fsError(e: unknown): SyncError {
  if (e instanceof SyncError) return e
  const code = String((e as { code?: unknown } | null)?.code || '')
  if (code === 'permission-denied' || code === 'unauthenticated') return new SyncError('denied', 'Oblak je zavrnil dostop — odjavi se in prijavi znova.')
  if (code === 'unavailable' || code === 'deadline-exceeded' || code === 'cancelled') return new SyncError('network', 'Oblak trenutno ni dosegljiv — poskusim znova.')
  if (code === 'resource-exhausted') return new SyncError('network', 'Oblak je začasno preobremenjen — poskusim znova kasneje.')
  if (code === 'invalid-argument') return new SyncError('size', 'Oblak je zavrnil zapis (prevelik ali neveljaven) — podatki ostanejo na tej napravi.')
  return new SyncError('other', `Usklajevanje ni uspelo${(e as Error)?.message ? `: ${(e as Error).message}` : '.'}`)
}

/* ---------- usklajevanje ---------- */
interface Once { changed: boolean; remote: 'had' | 'empty' | 'skip' }
/** Prebere oblak, združi s to napravo, zapiše razlike na obe strani. */
async function syncOnce(full: boolean): Promise<Once> {
  const u = uid!
  const owner = (await getKV<SyncOwner>(K.owner)) || null
  if (owner && owner.uid !== u) throw new SyncError('clash', 'Na tej napravi so podatki drugega računa — usklajevanje je ustavljeno.')
  const first = !owner
  // prvič po posodobitvi (števca še ni): kot da je lokalna sprememba — nič neposlanega se ne izgubi
  const localSeq = (await getKV<number>(K.localSeq)) ?? LOCAL_SEQ_START
  const synced = (await getKV<number>(K.syncedSeq)) ?? 0
  const known = (await getKV<number>(K.remoteTs)) || 0
  // oblak se ni spremenil (javlja poslušalec) in tu ni novega → brez prenosa; vsakih 5 min vseeno polno
  if (!full && !first && !forceFull && snapTs != null && snapTs === known && localSeq <= synced && Date.now() - lastFull < FULL_EVERY) return { changed: false, remote: 'skip' }
  const c = await core()
  if (!c) throw new SyncError('network', 'Ni povezave s strežnikom — usklajevanje poskusim znova.')
  const ref = c.fsMod.doc(c.fs, 'formaSync', u)
  const local = await readLocal()
  let merged: SyncState | null = null, remoteTs = 0, wrote = 0, had = false, gone = false
  try {
    await c.fsMod.runTransaction(c.fs, async tx => {
      merged = null; wrote = 0; gone = false; had = false
      const now = Date.now()
      const snap = await tx.get(ref)
      // dokumenta ni, ta naprava pa se je s tem računom že usklajevala → izbrisan drugje: NE ustvari ga znova
      if (!snap.exists() && known > 0 && owner?.uid === u) { gone = true; return }
      const v2 = snap.exists() ? (snap.data() as { v2?: CloudV2 }).v2 : undefined
      had = !!v2
      remoteTs = v2?._ts || 0
      if (v2 && !first && remoteTs === known && localSeq <= synced) return            // nič novega ne tu ne v oblaku
      const remote = v2 ? fromCloud(v2) : null
      const m = remote ? mergeState(local, remote, now, first ? { authority: 'b' } : {}) : { ...local }
      m.settings = keepDeviceLocal(m.settings, local.settings)
      merged = m
      if (remote && stableStr(toCloud(m, 0, now).payload) === stableStr(toCloud(remote, 0, now).payload)) return
      const out = toCloud(m, Math.max(now, remoteTs + 1), now)
      if (out.bytes > HARD_MAX_BYTES) throw new SyncError('size', `Podatkov je preveč za oblak (${Math.round(out.bytes / 1000)} kB, meja ${Math.round(HARD_MAX_BYTES / 1000)} kB) — ostanejo na tej napravi.`)
      // mergeFields: polje v2 se zamenja v celoti, polja stare aplikacije ostanejo
      tx.set(ref, { v2: out.payload }, { mergeFields: ['v2'] })
      wrote = out.payload._ts
    })
  } catch (e) { throw fsError(e) }
  if (gone) throw new SyncError('deleted', 'Podatki v oblaku so bili izbrisani (izbris računa na drugi napravi) — usklajevanje je ustavljeno.')
  const m = merged as SyncState | null
  const changed = m ? await repo.applyMerged(local, m) : false
  await setKV(K.syncedSeq, localSeq)
  await setKV(K.remoteTs, wrote || remoteTs)
  if (!owner) await setKV<SyncOwner>(K.owner, { uid: u, email: hooks.email ?? null })
  else if (hooks.email && owner.email !== hooks.email) await setKV<SyncOwner>(K.owner, { uid: u, email: hooks.email })
  // lastni zapis: poslušalec ga bo javil, a ni nov — snapTs nikoli nazaj (sicer bi zamudili novejši zapis druge naprave)
  if (snapTs != null && wrote) snapTs = Math.max(snapTs, wrote)
  forceFull = false
  lastFull = Date.now()
  return { changed, remote: had ? 'had' : 'empty' }
}

/** Poslušalec dokumenta v oblaku: ob zapisu druge naprave takoj uskladi (brez rednega prenašanja). */
async function listen(u: string): Promise<void> {
  const c = await core().catch(() => null)
  if (!c || uid !== u || typeof c.fsMod.onSnapshot !== 'function') return
  const ref = c.fsMod.doc(c.fs, 'formaSync', u)
  offSnap = c.fsMod.onSnapshot(ref, { includeMetadataChanges: false }, snap => {
    if (uid !== u || snap.metadata.fromCache || snap.metadata.hasPendingWrites) return
    const exists = snap.exists()
    const ts = (exists ? (snap.get('v2._ts') as number | undefined) : undefined) || 0
    const first = snapTs == null
    // izbris dokumenta ali _ts nazaj: polno usklajevanje (ne bližnjica)
    if (!exists || (snapTs != null && ts < snapTs)) forceFull = true
    snapTs = snapTs == null ? ts : Math.max(snapTs, ts)
    // med tekočim usklajevanjem: še enkrat po njem (poceni, če je že vse prevzeto)
    void getKV<number>(K.remoteTs).then(known => { if (first || forceFull || ts !== (known || 0)) void (running ? running.finally(() => syncNow({ quick: true })) : syncNow({ quick: true })) })
  }, () => { snapTs = null; offSnap?.(); offSnap = null })     // napaka (pravila, omrežje) → redno usklajevanje
}

function reportFirst(r: FirstSyncResult) {
  if (!firstCb || firstState === 'done') return
  if (r === 'error') { if (firstState === 'pending') { firstState = 'error'; firstCb(r) } return }
  firstState = 'done'; firstCb(r)
}

/**
 * Uskladi zdaj (ena naenkrat — sočasni klici dobijo isti rezultat). Privzeto polno (gumb »uskladi zdaj«,
 * odjava); quick: sme uporabiti bližnjico poslušalca (ozadje, časovnik, vrnitev v aplikacijo).
 */
export function syncNow(opts: { quick?: boolean; force?: boolean } = {}): Promise<boolean> {
  if (!uid) return Promise.resolve(false)
  const full = !!opts.force || !opts.quick
  // med usklajevanjem v ozadju: ročno (polno) usklajevanje teče takoj za njim, ne vrne rezultata bližnjice
  if (running) return full ? running.then(() => syncNow(opts), () => syncNow(opts)) : running
  const me = uid
  // »usklajujem« šele, če traja več kot 0,7 s — hitro usklajevanje v ozadju (vsakih 20 s) ne sproži izrisa zaslona
  const busy = setTimeout(() => setStatus({ state: 'pull', at: Date.now() }), 700)
  running = syncOnce(full)
    .then(r => {
      if (uid !== me) return false
      setStatus({ state: 'idle', at: Date.now(), msg: r.changed ? 'Združeno s podatki druge naprave.' : undefined })
      if (r.remote !== 'skip') reportFirst(r.remote === 'had' ? 'ok' : 'empty')
      if (r.changed) onChanged?.()
      return r.changed
    })
    .catch(e => {
      const err = e instanceof SyncError ? e : fsError(e)
      if (uid !== me) return false
      if (err.kind === 'deleted' || err.kind === 'clash') {
        const h = hooks, cb = firstCb, st = firstState
        stopSync()
        setStatus({ state: 'error', at: Date.now(), msg: err.message })
        if (cb && st !== 'done') cb('error')
        if (err.kind === 'deleted') h.onDeleted?.()
        else h.onClash?.()
        return false
      }
      setStatus({ state: 'error', at: Date.now(), msg: err.message })
      reportFirst('error')
      return false
    })
    .finally(() => { clearTimeout(busy); running = null })
  return running
}
/** Za staro ime (gumb »uskladi zdaj«, odjava): polno usklajevanje. */
export const pushNow = async (): Promise<void> => { await syncNow() }

/* ---------- življenjski cikel ---------- */
export interface SyncHooks {
  /** e-pošta računa (za vprašanje ob drugem računu na isti napravi) */
  email?: string | null
  /** dokument v oblaku je izbrisan drugje: sinhronizacija je že ustavljena */
  onDeleted?: () => void
  /** podatki na napravi pripadajo drugemu računu: sinhronizacija je že ustavljena */
  onClash?: () => void
}
/**
 * onFirst: ko je prvo usklajevanje končano — 'ok' | 'empty' ali 'error' (ob napaki se ob prvem kasnejšem uspehu
 * pokliče še enkrat z 'ok' | 'empty'). Šele takrat smejo teči samodejni uvozi.
 */
export function startSync(u: string, onPulled?: () => void, onFirst?: (r: FirstSyncResult) => void, h: SyncHooks = {}): void {
  stopSync()
  uid = u
  onChanged = onPulled || null
  hooks = h
  firstCb = onFirst || null
  firstState = 'pending'
  setStatus({ state: 'idle', at: Date.now() })
  void syncNow({ quick: true })
  void listen(u)
  // ko poslušalec teče, je to le poceni preverba (brez omrežja); sicer polno usklajevanje kot prej
  timer = window.setInterval(() => { void syncNow({ quick: true }) }, 20_000)
  const onVis = () => { void syncNow({ quick: true }) }
  const onFocus = () => { void syncNow({ quick: true }) }
  const onUnload = () => { void syncNow({ quick: true }) }
  document.addEventListener('visibilitychange', onVis)
  window.addEventListener('focus', onFocus)
  window.addEventListener('beforeunload', onUnload)
  offVis = () => { document.removeEventListener('visibilitychange', onVis); window.removeEventListener('focus', onFocus); window.removeEventListener('beforeunload', onUnload) }
}

export function stopSync(): void {
  if (offSnap) { offSnap(); offSnap = null }
  snapTs = null; lastFull = 0; forceFull = false
  if (timer) { clearInterval(timer); timer = null }
  if (pushTimer) { clearTimeout(pushTimer); pushTimer = null }
  if (offVis) { offVis(); offVis = null }
  uid = null
  onChanged = null
  hooks = {}
  firstCb = null; firstState = 'done'
  setStatus({ state: 'off' })
}

/** Račun, s katerim se je ta naprava nazadnje uspešno uskladila (null = še nikoli). */
export async function syncOwner(): Promise<SyncOwner | null> { return (await getKV<SyncOwner>(K.owner)) || null }

/**
 * Po izbrisu dokumenta v oblaku (na drugi napravi): pozabi stanje oblaka. Če se kasneje prijaviš z istim računom
 * (obstaja še), ta naprava dokument ustvari znova iz svojih podatkov, namesto da bi te vsakič znova odjavila.
 */
export async function forgetRemote(): Promise<void> { await setKV(K.remoteTs, 0); await setKV(K.syncedSeq, 0) }

/** Za preizkus: sledi iz oblaka se ne smejo izgubiti (zdaj to naredi merge.ts). */
export function keepLocalTracks(remote: Activity[], local: Activity[]): Activity[] {
  const mine = new Map(local.filter(a => a.polyline).map(a => [a.id, a.polyline as string] as const))
  return remote.map(a => (!a.polyline && mine.has(a.id)) ? { ...a, polyline: mine.get(a.id) as string } : a)
}
