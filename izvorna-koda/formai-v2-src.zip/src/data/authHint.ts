/**
 * (v3.50) Firebase (prijava, oblak: ~150 KB gz, 3 deli) se ob zagonu naloži samo, če je na tej napravi prijava ali je
 * bila: zastavica ob prijavi, račun, s katerim se je naprava že usklajevala, ali seja Firebase v shrambi. Sicer šele ob
 * »Prijava z Googlom«. Prej se je naložil ob vsakem zagonu, tudi brez računa.
 */
export const AUTH_FLAG = 'formai.auth'
const SESSION_PREFIX = 'firebase:authUser:'

/** Ob prijavi (tudi pred preusmeritvijo na Google) in ko Firebase javi uporabnika. */
export function markAuth(on = true): void { try { localStorage.setItem(AUTH_FLAG, on ? '1' : '0') } catch { /* zasebni način */ } }

/** Hitra preverba brez Firebase: zastavica ali shranjena seja (browserLocalPersistence v localStorage). */
export function authHintSync(): boolean {
  try {
    if (localStorage.getItem(AUTH_FLAG) === '1') return true
    for (let i = 0; i < localStorage.length; i++) if (localStorage.key(i)?.startsWith(SESSION_PREFIX)) return true
    return false
  } catch { return true }   // ne vemo → kot prej
}

/** Seja Firebase v IndexedDB (privzeta shramba): true/false, null = ne vemo. Baze ne ustvari. */
export async function idbSession(): Promise<boolean | null> {
  try {
    const f = indexedDB as IDBFactory & { databases?: () => Promise<{ name?: string }[]> }
    if (typeof f.databases !== 'function') return null
    if (!(await f.databases()).some(d => d.name === 'firebaseLocalStorageDb')) return false
    return await new Promise<boolean | null>(res => {
      const q = indexedDB.open('firebaseLocalStorageDb')
      q.onerror = () => res(null)
      q.onblocked = () => res(null)
      q.onsuccess = () => {
        const db = q.result
        try {
          if (!db.objectStoreNames.contains('firebaseLocalStorage')) { db.close(); res(null); return }
          const g = db.transaction('firebaseLocalStorage', 'readonly').objectStore('firebaseLocalStorage').getAllKeys()
          g.onsuccess = () => { db.close(); res(g.result.some(k => String(k).startsWith(SESSION_PREFIX))) }
          g.onerror = () => { db.close(); res(null) }
        } catch { db.close(); res(null) }
      }
    })
  } catch { return null }
}

/** Odločitev ob zagonu: owner = račun, s katerim se je naprava že usklajevala. Neznano (null) → naloži kot prej. */
export function shouldBootAuth(o: { hint: boolean; owner: boolean; idb: boolean | null }): boolean {
  return o.hint || o.owner || o.idb !== false
}
