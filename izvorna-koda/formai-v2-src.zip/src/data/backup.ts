import type { Activity, DailyCheckin, MealEntry, PlanDay, Profile, Settings } from '@/domain/types'
import { mergeState, withoutDeviceLocal, keepDeviceLocal, tombMeal, tombAct, type SyncState } from './merge'
import * as repo from './repo'

/**
 * VARNOSTNA KOPIJA — obnovitev iz datoteke »Izvozi vse« (formai-izvoz-….json).
 * Kopija se ZDRUŽI s tem, kar je na napravi, z istimi pravili kot usklajevanje z oblakom: nič se ne izbriše,
 * isti zapis ostane v novejši različici. Profil in nastavitve: po času sprememb polj — ali, na željo (nova naprava),
 * iz kopije (kot prvo usklajevanje z računom). Nastavitve samo te naprave ostanejo, kot so.
 */

/**
 * Izvoz za datoteko (»Izvozi vse«): brez ključa in žetona intervals.icu — datoteka lahko konča kjerkoli (e-pošta,
 * oblak, USB). Povezava ostane na napravi in v računu; uvoz kopije obstoječe povezave na napravi ne pobriše.
 */
export async function exportForFile(): Promise<Awaited<ReturnType<typeof repo.exportAll>>> {
  const all = await repo.exportAll()
  return { ...all, settings: withoutSecrets(all.settings as Settings | undefined) }
}
export function withoutSecrets(s: Settings | null | undefined): Settings | undefined {
  if (!s || typeof s !== 'object') return s ?? undefined
  const { intervals: _icu, ...rest } = s
  if (!s.fieldAt || !('intervals' in s.fieldAt)) return rest as Settings
  const { intervals: _f, ...fa } = s.fieldAt
  return { ...rest, fieldAt: fa } as Settings
}

export interface BackupInfo { exportedAt: string | null; activities: number; plan: number; meals: number; checkins: number; profile: boolean }
export interface ParsedBackup { state: SyncState; info: BackupInfo }

const MAX = 50_000
const isObj = (x: unknown): x is Record<string, unknown> => !!x && typeof x === 'object' && !Array.isArray(x)
const ISO_DAY = /^\d{4}-\d{2}-\d{2}$/
const str = (x: unknown) => typeof x === 'string' && x.length > 0 && x.length < 200

/** Prebere in preveri datoteko; neveljavne zapise izpusti. Vrže Error s slovenskim sporočilom, če to ni kopija FORMAI. */
export function parseBackup(text: string): ParsedBackup {
  let raw: unknown
  try { raw = JSON.parse(text) } catch { throw new Error('Datoteka ni varnostna kopija FORMAI (ni veljaven JSON).') }
  if (!isObj(raw) || !(Array.isArray(raw.activities) || Array.isArray(raw.plan) || Array.isArray(raw.meals) || isObj(raw.profile))) throw new Error('Datoteka ni varnostna kopija FORMAI.')
  if (raw.version != null && raw.version !== 2) throw new Error('Kopija je iz druge različice aplikacije — uvoz ni mogoč.')
  const arr = (x: unknown) => (Array.isArray(x) ? x.slice(0, MAX) : [])
  const activities = arr(raw.activities).filter((a): a is Activity => isObj(a) && str(a.id) && typeof a.date === 'string' && ISO_DAY.test(a.date) && str(a.sport))
  const plan = arr(raw.plan).filter((d): d is PlanDay => isObj(d) && str(d.id) && typeof d.date === 'string' && ISO_DAY.test(d.date) && str(d.kind))
  const meals = arr(raw.meals).filter((m): m is MealEntry => isObj(m) && str(m.id) && typeof m.date === 'string' && ISO_DAY.test(m.date) && typeof m.kcal === 'number' && Number.isFinite(m.kcal))
  const checkins = arr(raw.checkins).filter((c): c is DailyCheckin => isObj(c) && typeof c.date === 'string' && ISO_DAY.test(c.date))
  const profile = isObj(raw.profile) ? (raw.profile as unknown as Profile) : null
  const settings = isObj(raw.settings) ? withoutDeviceLocal(raw.settings as unknown as Settings) : null
  if (!activities.length && !plan.length && !meals.length && !checkins.length && !profile) throw new Error('Kopija je prazna.')
  return {
    state: { profile, settings, activities, plan, meals, checkins, tomb: {} },
    info: { exportedAt: typeof raw.exportedAt === 'string' ? raw.exportedAt : null, activities: activities.length, plan: plan.length, meals: meals.length, checkins: checkins.length, profile: !!profile },
  }
}

/** Kar je na napravi zdaj (kot za usklajevanje). */
async function local(): Promise<SyncState> {
  const all = await repo.exportAll()
  return {
    profile: (all.profile as Profile | undefined) ?? null, settings: (all.settings as Settings | undefined) ?? null,
    activities: all.activities as Activity[], plan: all.plan as PlanDay[], meals: all.meals as MealEntry[], checkins: all.checkins as DailyCheckin[],
    tomb: await repo.getTomb(),
  }
}

/** Združi kopijo z napravo in zapiše razlike. Vrne, koliko zapisov je novih. fromBackup: profil in nastavitve iz kopije. */
export async function restoreBackup(b: ParsedBackup, opts: { fromBackup?: boolean } = {}): Promise<{ activities: number; plan: number; meals: number; checkins: number; changed: boolean; deleted: number }> {
  const before = await local()
  // kopija nima grobov: kar si po izvozu izbrisal na tej napravi, ostane izbrisano (grobovi te naprave veljajo)
  const merged = mergeState(before, { ...b.state, tomb: {} }, Date.now(), opts.fromBackup ? { authority: 'b' } : {})
  merged.settings = keepDeviceLocal(merged.settings, before.settings)
  // kopija brez povezave intervals.icu (nov izvoz je nima) ne odklopi te naprave
  if (merged.settings && !b.state.settings?.intervals && before.settings?.intervals && !merged.settings.intervals) merged.settings = { ...merged.settings, intervals: before.settings.intervals }
  const changed = await repo.applyMerged(before, merged)
  const plus = (k: 'activities' | 'plan' | 'meals' | 'checkins') => Math.max(0, merged[k].length - before[k].length)
  // zapisi iz kopije, ki si jih po izvozu izbrisal na tej napravi — ostanejo izbrisani (povemo, koliko)
  const t = before.tomb
  const deleted = b.state.meals.filter(m => t[tombMeal(m.id)]).length + b.state.activities.filter(a => t[tombAct(a)] || t[`a:id:${a.id}`]).length
  return { activities: plus('activities'), plan: plus('plan'), meals: plus('meals'), checkins: plus('checkins'), changed, deleted }
}
