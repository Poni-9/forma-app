import type { SyncStatus } from './sync'

/**
 * (v3.50) Opozorila usklajevanja z ukrepom (prej samo rdeča pika na avatarju):
 *  - napaka: takoj pri zavrnjenem dostopu ali prevelikih podatkih, sicer ko traja > 10 min (in je povezava);
 *    največ enkrat na dan; izbris računa in drug račun imata svoja obvestila;
 *  - skrajšana kopija v oblaku: enkrat ob prvem krajšanju (in ob vsaki novi stopnji).
 */
export interface NoticeMem { errSince: number | null; errDay: string | null; trimKey: string | null }
export const NOTICE_EMPTY: NoticeMem = { errSince: null, errDay: null, trimKey: null }
export const ERR_AFTER_MS = 10 * 60_000
export interface SyncNotice { mem: NoticeMem; err?: { msg: string; denied: boolean }; trim?: string }

const hhmm = (ms: number) => { const d = new Date(ms); return `${d.getHours()}:${String(d.getMinutes()).padStart(2, '0')}` }

export function syncNotice(s: SyncStatus, mem: NoticeMem, now: number, today: string, online = true): SyncNotice {
  let m = mem
  const out: SyncNotice = { mem: m }
  if (s.state === 'error') {
    if (s.kind === 'deleted' || s.kind === 'clash') return out
    const since = m.errSince ?? s.at ?? now
    if (m.errSince == null) m = { ...m, errSince: since }
    const now1 = s.kind === 'denied' || s.kind === 'size'
    if ((now1 || (online && now - since >= ERR_AFTER_MS)) && m.errDay !== today) {
      m = { ...m, errDay: today }
      const denied = s.kind === 'denied'
      out.err = {
        denied,
        msg: denied ? `Oblak ne sprejema sprememb od ${hhmm(since)} — prijavi se znova. Podatki so na tej napravi.`
          : `Oblak ne sprejema sprememb od ${hhmm(since)}. ${s.msg || 'Usklajevanje ni uspelo.'}`,
      }
    }
  } else if (s.state === 'idle' || s.state === 'off') {
    if (m.errSince != null) m = { ...m, errSince: null }
    if (s.state === 'idle' && s.trimmed !== undefined) {
      const key = s.trimmed ? `${s.trimmed.acts}/${s.trimmed.mealDays}` : null
      if (key !== m.trimKey) {
        if (key && s.trimmed) out.trim = `Oblak hrani zadnjih ${s.trimmed.acts} vadb in ${s.trimmed.mealDays} dni obrokov; vse ostane na tej napravi — izvozi kopijo.`
        m = { ...m, trimKey: key }
      }
    }
  }
  out.mem = m
  return out
}
