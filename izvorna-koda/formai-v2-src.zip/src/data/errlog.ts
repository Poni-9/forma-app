/* ---------- zadnje napake v aplikaciji (pomagajo popraviti; samo besedilo napake, brez podatkov) ----------
   (v3.51) iz feedback.ts: zagon in meje napak rabijo samo to — pošiljanje pripomb se naloži, ko je treba */
const errs: string[] = []
let trapped = false
export function trapErrors(): void {
  if (trapped || typeof window === 'undefined') return
  trapped = true
  const add = (m: string) => { errs.push(`${new Date().toISOString().slice(11, 19)} ${m}`.slice(0, 220)); if (errs.length > 8) errs.shift() }
  window.addEventListener('error', e => add(String(e.message || 'napaka')))
  window.addEventListener('unhandledrejection', e => { const r = (e as PromiseRejectionEvent).reason; add(String((r && (r as Error).message) || r || 'zavrnitev')) })
}
export const recentErrors = (): string[] => [...errs]
/** (v3.49) Napaka, ki jo ujame meja zaslona (React je ne javi kot window.error) — gre zraven pripombe. */
export function noteError(m: string): void { errs.push(`${new Date().toISOString().slice(11, 19)} ${m}`.slice(0, 220)); if (errs.length > 8) errs.shift() }
