import { ICU_CLIENT_ID, ICU_SCOPES, PROXY } from '@/config'
import { idToken } from '@/data/firebase'

/**
 * »Poveži z intervals.icu« z enim dotikom (OAuth). Brskalnik gre na intervals.icu, uporabnik potrdi dostop,
 * intervals.icu vrne ?code=… na formai.si; strežnik kodo zamenja za žeton (skrivnost ostane na strežniku).
 * Žeton gre v nastavitve (usklajene med tvojimi napravami) — nova avtorizacija na drugi napravi bi staro razveljavila.
 */
const KEY = 'icu.oauth.state'
let live: boolean | null = null
let probe: Promise<boolean> | null = null
/** Ali je »Poveži z intervals.icu« na voljo: Client ID v aplikaciji IN strežnik javi, da ima skrivnost (/health → icu). */
export const icuOauthOn = (): boolean => !!ICU_CLIENT_ID && live === true
/** Enkrat na zagon vpraša strežnik; do odgovora (ali brez omrežja) ostane povezava z API ključem. */
export function probeIcuOauth(): Promise<boolean> {
  if (!ICU_CLIENT_ID) return Promise.resolve(false)
  if (!probe) probe = fetch(`${PROXY}/health`).then(r => r.json()).then((d: { icu?: boolean }) => (live = d?.icu === true)).catch(() => (live = false))
  return probe
}
const redirectUri = () => `${location.origin}/`

export function startIcuOAuth(): void {
  const state = Array.from(crypto.getRandomValues(new Uint8Array(12)), b => b.toString(16).padStart(2, '0')).join('')
  try { sessionStorage.setItem(KEY, state) } catch { /* zasebni način: preverba stanja spodaj pade in povezava ne uspe */ }
  const q = new URLSearchParams({ client_id: ICU_CLIENT_ID, redirect_uri: redirectUri(), scope: ICU_SCOPES, state })
  location.href = `https://intervals.icu/oauth/authorize?${q}`
}

export interface IcuOauthResult { token: string; athleteId: string; name: string | null; scope: string | null }

/** Ob zagonu: če je v naslovu ?code=…&state=… iz intervals.icu, zamenjaj kodo za žeton in počisti naslov. */
export async function finishIcuOAuth(): Promise<IcuOauthResult | { error: string } | null> {
  const q = new URLSearchParams(location.search)
  const code = q.get('code'), state = q.get('state'), err = q.get('error')
  if (!code && !err) return null
  let want: string | null = null
  try { want = sessionStorage.getItem(KEY); sessionStorage.removeItem(KEY) } catch { /* ni */ }
  history.replaceState(null, '', location.pathname + '#/uvoz')
  if (err) return { error: err === 'access_denied' ? 'Dostop ni bil potrjen.' : `intervals.icu: ${err}` }
  if (!state || !want || state !== want) return { error: 'Povezava ni uspela (neveljavno stanje) — poskusi znova.' }
  try {
    const t = await idToken().catch(() => null)
    const r = await fetch(`${PROXY}/icu/token`, { method: 'POST', headers: { 'Content-Type': 'application/json', ...(t ? { Authorization: `Bearer ${t}` } : {}) }, body: JSON.stringify({ code, redirect_uri: redirectUri() }) })
    const d = await r.json().catch(() => ({})) as { access_token?: string; scope?: string; athlete?: { id?: string | number; name?: string } }
    if (!r.ok || !d.access_token) return { error: `Povezava ni uspela (strežnik ${r.status}).` }
    return { token: d.access_token, athleteId: '0', name: d.athlete?.name ?? null, scope: d.scope ?? null }
  } catch { return { error: 'Povezava ni uspela — ni omrežja?' } }
}
