import type { Activity, CoachMsg, DailyCheckin, MealEntry, PlanDay, Profile, Settings, TestEntry } from '@/domain/types'

/**
 * Združevanje podatkov dveh naprav (ta naprava + oblak) — NOBEN zapis se ne izgubi.
 * Prej je veljalo »novejša naprava prepiše vse«: računalnik s staro kopijo je ob samodejnem uvozu vožnje
 * postal »novejši« in pobrisal obroke, vnesene na telefonu. Zdaj:
 *  - obroki, aktivnosti, testi: unija po id-ju; isti zapis → novejša različica (updatedAt);
 *    izbris velja samo z grobom (tomb), ki ga zapiše naprava, na kateri si izbrisal,
 *  - ista vožnja, ki jo je vsaka naprava uvozila sama (drug id), postane ena (po id-ju intervals.icu),
 *  - check-in: po datumu, novejši je osnova, manjkajoča polja (ki jih ni) iz drugega — izbrisano (null) ostane izbrisano,
 *  - načrt: po dnevih iz naprave, ki je dan spremenila zadnja, a isti vnos (id) se združi po vnosu in
 *    »opravljeno« ima svoj čas — kljukica se ne izgubi zaradi druge spremembe istega dne,
 *  - profil, nastavitve: vsako polje ima svoj čas spremembe (fieldAt) — novejša sprememba polja zmaga,
 *    nepovezana novejša sprememba (npr. barva) ne pobriše žetona intervals.icu ali preklica privolitve za AI;
 *    pogovor s trenerjem je unija sporočil, testi in mesečne ocene se združijo.
 * Pravila so simetrična (merge(a, b) = merge(b, a)), da se naprave ne prepirajo in ne pišejo v krogu.
 * Čiste funkcije, brez omrežja in baze.
 */
export type Tomb = Record<string, number>
export interface SyncState {
  profile: Profile | null
  settings: Settings | null
  activities: Activity[]
  plan: PlanDay[]
  meals: MealEntry[]
  checkins: DailyCheckin[]
  tomb: Tomb
}

/** Grobovi (izbrisi) živijo 120 dni — dovolj, da jih vidi vsaka naprava, ki se kdaj odpre. */
export const TOMB_DAYS = 120

/** Nastavitve, ki ostanejo samo na tej napravi (ne gredo v oblak in jih druga naprava ne spremeni). */
export const DEVICE_LOCAL_SETTINGS = ['wellnessOn'] as const
/** Pogovor s trenerjem: največ toliko sporočil po združitvi (starejša so v povzetku). */
export const COACH_MAX_MSGS = 80

/** Niz z urejenimi ključi — za primerjavo vsebine in odločanje ob enakih časih. */
export function stableStr(x: unknown): string {
  return JSON.stringify(x, (_k, v: unknown) => v && typeof v === 'object' && !Array.isArray(v)
    ? Object.fromEntries(Object.keys(v as Record<string, unknown>).sort().map(k => [k, (v as Record<string, unknown>)[k]]))
    : v) ?? ''
}

const tm = (s?: string | null) => (s ? Date.parse(s) || 0 : 0)
const nil = (v: unknown) => v === undefined || v === null

/** Novejši od dveh; ob enakem času odloči vsebina (deterministično, neodvisno od vrstnega reda). */
function newer<T>(a: T, b: T, ta: number, tb: number, view: (x: T) => unknown = x => x): T {
  if (ta !== tb) return ta > tb ? a : b
  return stableStr(view(a)) >= stableStr(view(b)) ? a : b
}

/** Ključ aktivnosti čez naprave: id v intervals.icu (vsaka naprava si da svoj lokalni id). */
export function actKey(a: Pick<Activity, 'id' | 'ext'>): string {
  const i = a.ext?.intervalsId
  if (i != null && String(i) !== '') return `icu:${i}`
  const s = a.ext?.stravaId
  if (s != null && String(s) !== '') return `strava:${s}`
  return `id:${a.id}`
}
export const tombMeal = (id: string) => `m:${id}`
export const tombAct = (a: Pick<Activity, 'id' | 'ext'>) => `a:${actKey(a)}`
export const tombTest = (id: string) => `t:${id}`

export function mergeTomb(a: Tomb | null | undefined, b: Tomb | null | undefined, now: number): Tomb {
  const out: Tomb = {}, min = now - TOMB_DAYS * 86400_000
  for (const src of [a || {}, b || {}]) for (const [k, v] of Object.entries(src)) {
    if (typeof v === 'number' && Number.isFinite(v) && v >= min && (out[k] ?? 0) < v) out[k] = v
  }
  return out
}

/* ---------- obroki ---------- */
const mealT = (m: MealEntry) => tm(m.updatedAt) || tm(m.createdAt)
const mealView = (m: MealEntry) => ({ ...m, thumb: null })
export function mergeMeals(a: readonly MealEntry[], b: readonly MealEntry[], tomb: Tomb): MealEntry[] {
  const out = new Map<string, MealEntry>()
  for (const m of [...a, ...b]) {
    if (!m || !m.id || tomb[tombMeal(m.id)]) continue
    const e = out.get(m.id)
    if (!e) { out.set(m.id, m); continue }
    const w = newer(e, m, mealT(e), mealT(m), mealView)
    // sličica je samo na napravi, ki je slikala — ohrani jo ne glede na to, katera različica zmaga
    const thumb = w.thumb || e.thumb || m.thumb || null
    out.set(m.id, thumb === (w.thumb ?? null) ? w : { ...w, thumb })
  }
  return [...out.values()].sort((x, y) => x.date.localeCompare(y.date) || (x.time || '').localeCompare(y.time || '') || (x.createdAt || '').localeCompare(y.createdAt || '') || x.id.localeCompare(y.id))
}

/* ---------- aktivnosti ---------- */
const actT = (x: Activity) => tm(x.updatedAt) || tm(x.createdAt)
const actView = (x: Activity) => ({ ...x, polyline: null })
const actScore = (x: Activity) => (x.polyline ? 4 : 0) + (x.avgPower ? 2 : 0) + (x.avgHr ? 1 : 0) + (x.kcal ? 1 : 0)

/** Združi skupino zapisov iste aktivnosti: enoten id (najstarejši), vsebina najnovejša, sled ohranjena. */
function fold(g: Activity[], best: Activity, remap: Record<string, string>): Activity {
  const canon = g.reduce((p, c) => ((c.createdAt || '') + '|' + c.id) < ((p.createdAt || '') + '|' + p.id) ? c : p)
  const poly = best.polyline || g.find(x => x.polyline)?.polyline || null
  for (const x of g) if (x.id !== canon.id) remap[x.id] = canon.id
  if (best.id === canon.id && best.createdAt === canon.createdAt && poly === (best.polyline ?? null)) return best
  return { ...best, id: canon.id, createdAt: canon.createdAt, ...(poly !== (best.polyline ?? null) ? { polyline: poly } : {}) }
}

export function mergeActivities(a: readonly Activity[], b: readonly Activity[], tomb: Tomb, now: number): { list: Activity[]; remap: Record<string, string> } {
  // 1) isti id na obeh straneh → novejša vsebina (lokalna sled ostane)
  const byId = new Map<string, Activity>()
  for (const x of [...a, ...b]) {
    if (!x || !x.id) continue
    const e = byId.get(x.id)
    if (!e) { byId.set(x.id, x); continue }
    let w = newer(e, x, actT(e), actT(x), actView)
    // občutek (RPE), vpisan na drugi napravi, ostane, če ga novejša različica sploh nima (null = izbrisan, undefined = nikoli)
    const o = w === e ? x : e
    if (w.rpe === undefined && o.rpe != null) w = { ...w, rpe: o.rpe }
    const poly = w.polyline || e.polyline || x.polyline || null
    byId.set(x.id, poly === (w.polyline ?? null) ? w : { ...w, polyline: poly })
  }
  // 2) ista vožnja iz intervals.icu pod dvema lokalnima id-jema → ena
  const groups = new Map<string, Activity[]>()
  for (const x of byId.values()) {
    if (x.expiresAt && tm(x.expiresAt) && tm(x.expiresAt) < now) continue       // Strava §6.2: potekli ne vstanejo
    if (tomb[tombAct(x)] || tomb[`a:id:${x.id}`]) continue
    const k = actKey(x), g = groups.get(k)
    if (g) g.push(x); else groups.set(k, [x])
  }
  const remap: Record<string, string> = {}
  const one: Activity[] = []
  for (const g of groups.values()) one.push(g.length === 1 ? g[0]! : fold(g, g.reduce((p, c) => newer(p, c, actT(p), actT(c), actView)), remap))
  // 3) ista vožnja iz dveh virov (npr. datoteka FIT na eni napravi, intervals.icu na drugi): isti šport, začetek ±90 s
  one.sort((x, y) => tm(x.start) - tm(y.start) || x.id.localeCompare(y.id))
  const used = new Set<number>(), list: Activity[] = []
  for (let i = 0; i < one.length; i++) {
    if (used.has(i)) continue
    let cur = one[i]!
    const t0 = tm(cur.start)
    if (t0) for (let j = i + 1; j < one.length; j++) {
      const y = one[j]!
      if (tm(y.start) - t0 > 90_000) break
      if (used.has(j) || y.sport !== cur.sport) continue
      const kx = actKey(cur), ky = actKey(y)
      if (kx === ky || (!kx.startsWith('id:') && !ky.startsWith('id:'))) continue   // dve različni vožnji v intervals.icu pustimo
      const sx = actScore(cur), sy = actScore(y)
      cur = fold([cur, y], sx !== sy ? (sx > sy ? cur : y) : newer(cur, y, actT(cur), actT(y), actView), remap)
      used.add(j)
    }
    list.push(cur)
  }
  // verige preimenovanj (a → b → c) razreši do končnega id-ja
  for (const k of Object.keys(remap)) { let v = remap[k]!, n = 0; while (remap[v] && n++ < 20) v = remap[v]!; remap[k] = v }
  return { list: list.sort((x, y) => (y.date + (y.start || '')).localeCompare(x.date + (x.start || '')) || x.id.localeCompare(y.id)), remap }
}

/* ---------- načrt ---------- */
const entT = (x: PlanDay) => tm(x.updatedAt) || tm(x.createdAt)
/** čas zadnje spremembe »opravljeno« (tudi odkljukanja); stari zapisi brez doneAt: čas kljukice */
const doneT = (x: PlanDay) => tm(x.doneAt) || (x.done ? tm(x.done.at) : 0)
const dayT = (xs: readonly PlanDay[]) => xs.reduce((m, x) => Math.max(m, entT(x)), 0)
const dayView = (xs: readonly PlanDay[]) => [...xs].sort((x, y) => x.id.localeCompare(y.id))
/** vrsta »reže« v dnevu: glavni trening ali moč; neobvezni vnosi nimajo reže (lahko jih je več) */
const slotOf = (x: PlanDay): string | null => (x.optional ? null : x.kind === 'moc' ? 'moc' : 'main')

/** Isti vnos na obeh napravah: vsebina iz novejše različice, »opravljeno« po svojem času. */
export function mergePlanEntry(x: PlanDay, y: PlanDay): PlanDay {
  const base = newer(x, y, entT(x), entT(y))
  const dx = doneT(x), dy = doneT(y)
  const d = dx !== dy ? (dx > dy ? x : y) : (stableStr(x.done ?? null) >= stableStr(y.done ?? null) ? x : y)
  const done = d.done ?? null, doneAt = d.doneAt || null
  if (stableStr(base.done ?? null) === stableStr(done) && (base.doneAt || null) === doneAt) return base
  const out: PlanDay = { ...base, done }
  if (doneAt) out.doneAt = doneAt; else delete out.doneAt
  return out
}

export function mergePlan(a: readonly PlanDay[], b: readonly PlanDay[], remap: Record<string, string> = {}): PlanDay[] {
  const group = (xs: readonly PlanDay[]) => { const g = new Map<string, PlanDay[]>(); for (const x of xs) if (x && x.id && x.date) (g.get(x.date) ?? g.set(x.date, []).get(x.date)!).push(x); return g }
  const ga = group(a), gb = group(b)
  const picked: { d: PlanDay; t: number }[] = []
  for (const date of new Set([...ga.keys(), ...gb.keys()])) {
    const A = ga.get(date) || [], B = gb.get(date) || []
    let res: PlanDay[]
    if (!A.length || !B.length) res = A.length ? A : B
    else {
      // nabor vnosov dneva: iz naprave, ki je dan spremenila zadnja (sicer bi dve neodvisni sestavi tedna dali dvojne treninge)
      const W = newer(A, B, dayT(A), dayT(B), dayView), L = W === A ? B : A
      const lById = new Map(L.map(x => [x.id, x] as const))
      const wIds = new Set(W.map(x => x.id))
      // »opravljeno« z druge naprave se ne izgubi: vnos, ki ga zmagovalni dan nima, a je tam opravljen, ostane
      const kept = L.filter(x => !wIds.has(x.id) && x.done)
      const keptSlots = new Set(kept.map(slotOf).filter(Boolean))
      res = W.map(w => { const l = lById.get(w.id); return l ? mergePlanEntry(w, l) : w })
        .filter(w => w.done || !keptSlots.has(slotOf(w)))          // opravljen trening te reže nadomesti neopravljenega
        .concat(kept)
    }
    const t = dayT(res)
    for (const d of res) {
      const to = d.done?.activityId ? remap[d.done.activityId] : undefined
      picked.push({ d: to ? { ...d, done: { ...d.done!, activityId: to } } : d, t })
    }
  }
  // isti id na dveh dnevih (redko: premik seje) → obdrži novejšega
  const byId = new Map<string, { d: PlanDay; t: number }>()
  for (const p of picked) { const e = byId.get(p.d.id); if (!e || newer(e, p, e.t, p.t, v => v.d) === p) byId.set(p.d.id, p) }
  return [...byId.values()].map(p => p.d).sort((x, y) => x.date.localeCompare(y.date) || x.id.localeCompare(y.id))
}

/* ---------- check-in ---------- */
export function mergeCheckins(a: readonly DailyCheckin[], b: readonly DailyCheckin[]): DailyCheckin[] {
  const out = new Map<string, DailyCheckin>()
  for (const c of [...a, ...b]) {
    if (!c || !c.date) continue
    const e = out.get(c.date)
    if (!e) { out.set(c.date, c); continue }
    const w = newer(e, c, tm(e.updatedAt), tm(c.updatedAt)), o = w === e ? c : e
    const m: Record<string, unknown> = { ...w }
    // samo polja, ki jih novejši NIMA; polje, ki ga je novejši izbrisal (null), ostane izbrisano
    for (const [k, v] of Object.entries(o)) if (v != null && m[k] === undefined) m[k] = v
    out.set(c.date, m as unknown as DailyCheckin)
  }
  return [...out.values()].sort((x, y) => x.date.localeCompare(y.date))
}

/* ---------- polja s svojim časom (profil, nastavitve) ---------- */
type Stamped = { updatedAt?: string; fieldAt?: Record<string, string> }
const META = new Set(['updatedAt', 'fieldAt'])

/** Čas spremembe polja: fieldAt; stari zapisi (brez fieldAt) — čas celega zapisa, prazno polje pa nikoli ne zmaga. */
export function keyTime(o: Stamped, k: string): number {
  const f = o.fieldAt
  if (f && typeof f === 'object') return tm(f[k])
  return nil((o as Record<string, unknown>)[k]) ? 0 : tm(o.updatedAt)
}

/** Polje za poljem: novejša sprememba zmaga; ob enakem času neprazno pred praznim, sicer vsebina. */
function mergeFields(a: Stamped, b: Stamped, skip: ReadonlySet<string>, only?: ReadonlySet<string>): { out: Record<string, unknown>; at: Record<string, string> } {
  const A = a as Record<string, unknown>, B = b as Record<string, unknown>
  const out: Record<string, unknown> = {}, at: Record<string, string> = {}
  for (const k of new Set([...Object.keys(A), ...Object.keys(B)])) {
    if (META.has(k) || skip.has(k) || (only && !only.has(k))) continue
    const ta = keyTime(a, k), tb = keyTime(b, k), va = A[k], vb = B[k]
    const pickA = ta !== tb ? ta > tb : nil(va) !== nil(vb) ? !nil(va) : stableStr(va) >= stableStr(vb)
    const v = pickA ? va : vb, t = Math.max(ta, tb)
    if (v !== undefined) out[k] = v
    if (t > 0) at[k] = new Date(t).toISOString()
  }
  return { out, at }
}
const laterIso = (x?: string | null, y?: string | null): string | undefined => {
  const tx = tm(x), ty = tm(y)
  if (!tx && !ty) return x || y || undefined
  return tx === ty ? ((x || '') >= (y || '') ? x! : y!) : tx > ty ? x! : y!
}
const orderKeys = <T extends Record<string, unknown>>(o: T): T => Object.fromEntries(Object.keys(o).sort().map(k => [k, o[k]])) as T

/* ---------- profil ---------- */
/** Polja profila, ki imajo svoj čas tudi ob prvem usklajevanju nove naprave (privolitev za AI). */
const STICKY_PROFILE = new Set(['aiConsentAt'])
const isReal = (p: Profile) => !!(p.onboardingDone || p.name)

export function mergeProfile(a: Profile | null, b: Profile | null): Profile | null {
  if (!a) return b
  if (!b) return a
  // nova, prazna naprava ne sme prepisati pravega profila, tudi če je njen privzeti profil »novejši«
  const da = isReal(a), db = isReal(b)
  if (da !== db) return da ? a : b
  const { out, at } = mergeFields(a, b, new Set())
  const res = { ...out, updatedAt: laterIso(a.updatedAt, b.updatedAt) || a.updatedAt } as Profile
  if (Object.keys(at).length) res.fieldAt = orderKeys(at)
  return res
}

/** Prvo usklajevanje te naprave z računom: profil z računa velja (lokalni uvod ga ne prepiše), razen privolitve za AI po času. */
export function mergeProfileFirst(local: Profile | null, remote: Profile | null): Profile | null {
  if (!remote || !local || !isReal(remote)) return mergeProfile(local, remote)
  const sticky = mergeFields(local, remote, new Set(), STICKY_PROFILE)
  const res: Profile = { ...remote }
  for (const k of STICKY_PROFILE) {
    if (k in sticky.out) (res as unknown as Record<string, unknown>)[k] = sticky.out[k]
    else delete (res as unknown as Record<string, unknown>)[k]
  }
  const at = { ...(remote.fieldAt || {}), ...sticky.at }
  if (Object.keys(at).length) res.fieldAt = orderKeys(at); else delete res.fieldAt
  return res
}

/* ---------- pogovor s trenerjem ---------- */
type Coach = NonNullable<Settings['coach']>
const msgKey = (m: CoachMsg) => `${m.at}|${m.role}|${m.text}`
/**
 * Unija sporočil (ključ: čas + vloga + besedilo). Prazen seznam na eni napravi NE pobriše druge;
 * izbris velja samo s časom »nov pogovor« (clearedAt), strnjeno v povzetek pa s foldedTo.
 */
export function mergeCoach(a: Coach | null | undefined, b: Coach | null | undefined): Coach | null | undefined {
  if (a === undefined && b === undefined) return undefined
  if (!a && !b) return null
  const clearedAt = laterIso(a?.clearedAt, b?.clearedAt)
  const foldedTo = laterIso(a?.foldedTo, b?.foldedTo)
  const cut = laterIso(clearedAt, foldedTo)
  // stari zapisi (brez foldedTo): stran s povzetkom ima v seznamu samo sporočila po strnjenem delu — starejša so v povzetku
  const implied = [a, b].filter(c => c && c.summary && !c.foldedTo && c.msgs?.[0]?.at).map(c => c!.msgs[0]!.at).sort().pop()
  const seen = new Map<string, CoachMsg>()
  for (const m of [...(a?.msgs || []), ...(b?.msgs || [])]) {
    if (!m || typeof m.at !== 'string' || typeof m.text !== 'string') continue
    if ((cut && m.at <= cut) || (implied && m.at < implied)) continue
    const k = msgKey(m), e = seen.get(k)
    seen.set(k, e && stableStr(e) >= stableStr(m) ? e : m)
  }
  const msgs = [...seen.values()]
    .sort((x, y) => x.at.localeCompare(y.at) || (x.role === y.role ? 0 : x.role === 'user' ? -1 : 1) || x.text.localeCompare(y.text))
    .slice(-COACH_MAX_MSGS)
  // povzetek: novejši (summaryAt); stari zapisi brez časa — neprazen pred praznim
  const sa = tm(a?.summaryAt), sb = tm(b?.summaryAt)
  const va = a?.summary ?? null, vb = b?.summary ?? null
  const pickA = sa !== sb ? sa > sb : nil(va) !== nil(vb) ? !nil(va) : stableStr(va) >= stableStr(vb)
  let summary = pickA ? va : vb
  const summaryAt = pickA ? a?.summaryAt ?? null : b?.summaryAt ?? null
  if (clearedAt && (!summaryAt || summaryAt <= clearedAt)) summary = null
  const out: Coach = { msgs, summary }
  if (clearedAt) out.clearedAt = clearedAt
  if (foldedTo) out.foldedTo = foldedTo
  if (summaryAt && summary != null) out.summaryAt = summaryAt
  return out
}

/* ---------- nastavitve ---------- */
/** Polja, ki se ob prvem usklajevanju nove naprave združijo po času (povezava intervals.icu), ne po računu. */
const STICKY_SETTINGS = new Set(['intervals'])
/** Polja s posebnim združevanjem. */
const SPECIAL_SETTINGS = new Set(['tests', 'monthReviews', 'coach'])

/** Nastavitve brez polj, ki ostanejo samo na napravi (za oblak in za združevanje). */
export function withoutDeviceLocal(s: Settings): Settings {
  const out = { ...s } as Record<string, unknown>
  let fa: Record<string, string> | undefined = s.fieldAt ? { ...s.fieldAt } : undefined
  for (const k of DEVICE_LOCAL_SETTINGS) { delete out[k]; if (fa) delete fa[k] }
  if (fa) out.fieldAt = fa
  return out as unknown as Settings
}

export interface MergeOpts {
  /** b (oblak) je avtoriteta za profil in nastavitve: prvo uspešno usklajevanje te naprave z računom */
  authority?: 'b'
}

export function mergeSettings(a: Settings | null, b: Settings | null, tomb: Tomb, opts: MergeOpts = {}): Settings | null {
  if (!a) return b ? withoutDeviceLocal(b) : b
  if (!b) return withoutDeviceLocal(a)
  const A = withoutDeviceLocal(a), B = withoutDeviceLocal(b)
  const skip = new Set<string>([...SPECIAL_SETTINGS])
  let out: Record<string, unknown>, at: Record<string, string>
  if (opts.authority === 'b') {
    // oblak velja za vsa polja, ki jih ima; lokalno samo, kjer ga ni; povezava intervals.icu po času
    const sticky = mergeFields(A, B, skip, STICKY_SETTINGS)
    out = {}; at = {}
    const Ar = A as unknown as Record<string, unknown>, Br = B as unknown as Record<string, unknown>
    for (const k of new Set([...Object.keys(Ar), ...Object.keys(Br)])) {
      if (META.has(k) || skip.has(k) || STICKY_SETTINGS.has(k)) continue
      const useB = Br[k] !== undefined
      const v = useB ? Br[k] : Ar[k], t = keyTime(useB ? B : A, k)
      if (v !== undefined) out[k] = v
      if (t > 0) at[k] = new Date(t).toISOString()
    }
    Object.assign(out, sticky.out); Object.assign(at, sticky.at)
  } else ({ out, at } = mergeFields(A, B, skip))
  const res = out as unknown as Settings
  if (a.tests || b.tests) {
    const t = new Map<string, TestEntry>()
    for (const x of [...(a.tests || []), ...(b.tests || [])]) {
      if (!x || !x.id || tomb[tombTest(x.id)]) continue
      const e = t.get(x.id); t.set(x.id, e ? newer(e, x, 0, 0) : x)
    }
    res.tests = [...t.values()].sort((x, y) => x.date.localeCompare(y.date) || x.id.localeCompare(y.id))
  }
  if (a.monthReviews || b.monthReviews) {
    const r: NonNullable<Settings['monthReviews']> = {}
    for (const src of [a.monthReviews || {}, b.monthReviews || {}]) for (const [k, v] of Object.entries(src)) { if (!v) continue; const e = r[k]; r[k] = e ? newer(e, v, tm(e.at), tm(v.at)) : v }
    res.monthReviews = orderKeys(r)
  }
  const coach = mergeCoach(a.coach, b.coach)
  if (coach !== undefined) res.coach = coach
  for (const k of SPECIAL_SETTINGS) { const t = Math.max(keyTime(A, k), keyTime(B, k)); if (t > 0) at[k] = new Date(t).toISOString() }
  const u = laterIso(a.updatedAt, b.updatedAt)
  if (u) res.updatedAt = u
  if (Object.keys(at).length) res.fieldAt = orderKeys(at)
  return res
}

/* ---------- vse skupaj ---------- */
export function mergeState(a: SyncState, b: SyncState, now: number, opts: MergeOpts = {}): SyncState {
  const tomb = mergeTomb(a.tomb, b.tomb, now)
  const acts = mergeActivities(a.activities, b.activities, tomb, now)
  return {
    profile: opts.authority === 'b' ? mergeProfileFirst(a.profile, b.profile) : mergeProfile(a.profile, b.profile),
    settings: mergeSettings(a.settings, b.settings, tomb, opts),
    activities: acts.list,
    plan: mergePlan(a.plan, b.plan, acts.remap),
    meals: mergeMeals(a.meals, b.meals, tomb),
    checkins: mergeCheckins(a.checkins, b.checkins),
    tomb,
  }
}

/** Nastavitve samo te naprave (wellnessOn …) ostanejo, kot so na napravi — iz oblaka se ne prevzamejo. */
export function keepDeviceLocal(merged: Settings | null, local: Settings | null): Settings | null {
  if (!merged) return merged
  const out = { ...merged } as Record<string, unknown>
  const loc = (local || {}) as Record<string, unknown>
  for (const k of DEVICE_LOCAL_SETTINGS) { if (loc[k] !== undefined) out[k] = loc[k]; else delete out[k] }
  if (local?.fieldAt) {
    const fa = { ...(merged.fieldAt || {}) }
    for (const k of DEVICE_LOCAL_SETTINGS) { if (local.fieldAt[k]) fa[k] = local.fieldAt[k]!; else delete fa[k] }
    out.fieldAt = fa
  }
  return out as unknown as Settings
}
