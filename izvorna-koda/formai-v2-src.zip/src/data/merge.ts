import type { Activity, CoachMsg, DailyCheckin, MealEntry, PlanDay, Profile, Settings, TestEntry } from '@/domain/types'

/**
 * Združevanje podatkov dveh naprav (ta naprava + oblak) — NOBEN zapis se ne izgubi.
 * Prej je veljalo »novejša naprava prepiše vse«: računalnik s staro kopijo je ob samodejnem uvozu vožnje
 * postal »novejši« in pobrisal obroke, vnesene na telefonu. Zdaj:
 *  - obroki, aktivnosti, testi: unija po id-ju; isti zapis → novejša različica (updatedAt);
 *    izbris velja samo z grobom (tomb), ki ga zapiše naprava, na kateri si izbrisal,
 *  - ista vožnja, ki jo je vsaka naprava uvozila sama (drug id), postane ena (po id-ju intervals.icu),
 *  - check-in: po datumu, novejši je osnova, manjkajoča polja iz drugega,
 *  - načrt: po dnevih — cel dan iz naprave, ki je ta dan spremenila zadnja,
 *  - profil, nastavitve: novejši; pogovor s trenerjem, testi in mesečne ocene se združijo.
 * Pravila so simetrična (merge(a, b) = merge(b, a)), da se naprave ne prepirajo in ne pišejo v krogu.
 * Čiste funkcije, brez omrežja in baze.
 */
export type Tomb = Record<string, number>
export interface SyncState {
  profile: Profile | null
  settings: Settings | null
  activities: Activity[]
  plan: PlanDay[]
  meals: MealEntry[]
  checkins: DailyCheckin[]
  tomb: Tomb
}

/** Grobovi (izbrisi) živijo 120 dni — dovolj, da jih vidi vsaka naprava, ki se kdaj odpre. */
export const TOMB_DAYS = 120

/** Niz z urejenimi ključi — za primerjavo vsebine in odločanje ob enakih časih. */
export function stableStr(x: unknown): string {
  return JSON.stringify(x, (_k, v: unknown) => v && typeof v === 'object' && !Array.isArray(v)
    ? Object.fromEntries(Object.keys(v as Record<string, unknown>).sort().map(k => [k, (v as Record<string, unknown>)[k]]))
    : v) ?? ''
}

const tm = (s?: string | null) => (s ? Date.parse(s) || 0 : 0)

/** Novejši od dveh; ob enakem času odloči vsebina (deterministično, neodvisno od vrstnega reda). */
function newer<T>(a: T, b: T, ta: number, tb: number, view: (x: T) => unknown = x => x): T {
  if (ta !== tb) return ta > tb ? a : b
  return stableStr(view(a)) >= stableStr(view(b)) ? a : b
}

/** Ključ aktivnosti čez naprave: id v intervals.icu (vsaka naprava si da svoj lokalni id). */
export function actKey(a: Pick<Activity, 'id' | 'ext'>): string {
  const i = a.ext?.intervalsId
  if (i != null && String(i) !== '') return `icu:${i}`
  const s = a.ext?.stravaId
  if (s != null && String(s) !== '') return `strava:${s}`
  return `id:${a.id}`
}
export const tombMeal = (id: string) => `m:${id}`
export const tombAct = (a: Pick<Activity, 'id' | 'ext'>) => `a:${actKey(a)}`
export const tombTest = (id: string) => `t:${id}`

export function mergeTomb(a: Tomb | null | undefined, b: Tomb | null | undefined, now: number): Tomb {
  const out: Tomb = {}, min = now - TOMB_DAYS * 86400_000
  for (const src of [a || {}, b || {}]) for (const [k, v] of Object.entries(src)) {
    if (typeof v === 'number' && Number.isFinite(v) && v >= min && (out[k] ?? 0) < v) out[k] = v
  }
  return out
}

/* ---------- obroki ---------- */
const mealT = (m: MealEntry) => tm(m.updatedAt) || tm(m.createdAt)
const mealView = (m: MealEntry) => ({ ...m, thumb: null })
export function mergeMeals(a: readonly MealEntry[], b: readonly MealEntry[], tomb: Tomb): MealEntry[] {
  const out = new Map<string, MealEntry>()
  for (const m of [...a, ...b]) {
    if (!m || !m.id || tomb[tombMeal(m.id)]) continue
    const e = out.get(m.id)
    if (!e) { out.set(m.id, m); continue }
    const w = newer(e, m, mealT(e), mealT(m), mealView)
    // sličica je samo na napravi, ki je slikala — ohrani jo ne glede na to, katera različica zmaga
    const thumb = w.thumb || e.thumb || m.thumb || null
    out.set(m.id, thumb === (w.thumb ?? null) ? w : { ...w, thumb })
  }
  return [...out.values()].sort((x, y) => x.date.localeCompare(y.date) || (x.time || '').localeCompare(y.time || '') || (x.createdAt || '').localeCompare(y.createdAt || '') || x.id.localeCompare(y.id))
}

/* ---------- aktivnosti ---------- */
const actT = (x: Activity) => tm(x.updatedAt) || tm(x.createdAt)
const actView = (x: Activity) => ({ ...x, polyline: null })
const actScore = (x: Activity) => (x.polyline ? 4 : 0) + (x.avgPower ? 2 : 0) + (x.avgHr ? 1 : 0) + (x.kcal ? 1 : 0)

/** Združi skupino zapisov iste aktivnosti: enoten id (najstarejši), vsebina najnovejša, sled ohranjena. */
function fold(g: Activity[], best: Activity, remap: Record<string, string>): Activity {
  const canon = g.reduce((p, c) => ((c.createdAt || '') + '|' + c.id) < ((p.createdAt || '') + '|' + p.id) ? c : p)
  const poly = best.polyline || g.find(x => x.polyline)?.polyline || null
  for (const x of g) if (x.id !== canon.id) remap[x.id] = canon.id
  if (best.id === canon.id && best.createdAt === canon.createdAt && poly === (best.polyline ?? null)) return best
  return { ...best, id: canon.id, createdAt: canon.createdAt, ...(poly !== (best.polyline ?? null) ? { polyline: poly } : {}) }
}

export function mergeActivities(a: readonly Activity[], b: readonly Activity[], tomb: Tomb, now: number): { list: Activity[]; remap: Record<string, string> } {
  // 1) isti id na obeh straneh → novejša vsebina (lokalna sled ostane)
  const byId = new Map<string, Activity>()
  for (const x of [...a, ...b]) {
    if (!x || !x.id) continue
    const e = byId.get(x.id)
    if (!e) { byId.set(x.id, x); continue }
    const w = newer(e, x, actT(e), actT(x), actView)
    const poly = w.polyline || e.polyline || x.polyline || null
    byId.set(x.id, poly === (w.polyline ?? null) ? w : { ...w, polyline: poly })
  }
  // 2) ista vožnja iz intervals.icu pod dvema lokalnima id-jema → ena
  const groups = new Map<string, Activity[]>()
  for (const x of byId.values()) {
    if (x.expiresAt && tm(x.expiresAt) && tm(x.expiresAt) < now) continue       // Strava §6.2: potekli ne vstanejo
    if (tomb[tombAct(x)] || tomb[`a:id:${x.id}`]) continue
    const k = actKey(x), g = groups.get(k)
    if (g) g.push(x); else groups.set(k, [x])
  }
  const remap: Record<string, string> = {}
  const one: Activity[] = []
  for (const g of groups.values()) one.push(g.length === 1 ? g[0]! : fold(g, g.reduce((p, c) => newer(p, c, actT(p), actT(c), actView)), remap))
  // 3) ista vožnja iz dveh virov (npr. datoteka FIT na eni napravi, intervals.icu na drugi): isti šport, začetek ±90 s
  one.sort((x, y) => tm(x.start) - tm(y.start) || x.id.localeCompare(y.id))
  const used = new Set<number>(), list: Activity[] = []
  for (let i = 0; i < one.length; i++) {
    if (used.has(i)) continue
    let cur = one[i]!
    const t0 = tm(cur.start)
    if (t0) for (let j = i + 1; j < one.length; j++) {
      const y = one[j]!
      if (tm(y.start) - t0 > 90_000) break
      if (used.has(j) || y.sport !== cur.sport) continue
      const kx = actKey(cur), ky = actKey(y)
      if (kx === ky || (!kx.startsWith('id:') && !ky.startsWith('id:'))) continue   // dve različni vožnji v intervals.icu pustimo
      const sx = actScore(cur), sy = actScore(y)
      cur = fold([cur, y], sx !== sy ? (sx > sy ? cur : y) : newer(cur, y, actT(cur), actT(y), actView), remap)
      used.add(j)
    }
    list.push(cur)
  }
  // verige preimenovanj (a → b → c) razreši do končnega id-ja
  for (const k of Object.keys(remap)) { let v = remap[k]!, n = 0; while (remap[v] && n++ < 20) v = remap[v]!; remap[k] = v }
  return { list: list.sort((x, y) => (y.date + (y.start || '')).localeCompare(x.date + (x.start || '')) || x.id.localeCompare(y.id)), remap }
}

/* ---------- načrt ---------- */
const dayT = (xs: readonly PlanDay[]) => xs.reduce((m, x) => Math.max(m, tm(x.updatedAt) || tm(x.createdAt)), 0)
const dayView = (xs: readonly PlanDay[]) => [...xs].sort((x, y) => x.id.localeCompare(y.id))
export function mergePlan(a: readonly PlanDay[], b: readonly PlanDay[], remap: Record<string, string> = {}): PlanDay[] {
  const group = (xs: readonly PlanDay[]) => { const g = new Map<string, PlanDay[]>(); for (const x of xs) if (x && x.id && x.date) (g.get(x.date) ?? g.set(x.date, []).get(x.date)!).push(x); return g }
  const ga = group(a), gb = group(b)
  const picked: { d: PlanDay; t: number }[] = []
  for (const date of new Set([...ga.keys(), ...gb.keys()])) {
    const A = ga.get(date) || [], B = gb.get(date) || []
    const pick = !A.length ? B : !B.length ? A : newer(A, B, dayT(A), dayT(B), dayView)
    const t = dayT(pick)
    for (const d of pick) {
      const to = d.done?.activityId ? remap[d.done.activityId] : undefined
      picked.push({ d: to ? { ...d, done: { ...d.done!, activityId: to } } : d, t })
    }
  }
  // isti id na dveh dnevih (redko: premik seje) → obdrži novejšega
  const byId = new Map<string, { d: PlanDay; t: number }>()
  for (const p of picked) { const e = byId.get(p.d.id); if (!e || newer(e, p, e.t, p.t, v => v.d) === p) byId.set(p.d.id, p) }
  return [...byId.values()].map(p => p.d).sort((x, y) => x.date.localeCompare(y.date) || x.id.localeCompare(y.id))
}

/* ---------- check-in ---------- */
export function mergeCheckins(a: readonly DailyCheckin[], b: readonly DailyCheckin[]): DailyCheckin[] {
  const out = new Map<string, DailyCheckin>()
  for (const c of [...a, ...b]) {
    if (!c || !c.date) continue
    const e = out.get(c.date)
    if (!e) { out.set(c.date, c); continue }
    const w = newer(e, c, tm(e.updatedAt), tm(c.updatedAt)), o = w === e ? c : e
    const m: Record<string, unknown> = { ...w }
    for (const [k, v] of Object.entries(o)) if (v != null && m[k] == null) m[k] = v
    out.set(c.date, m as unknown as DailyCheckin)
  }
  return [...out.values()].sort((x, y) => x.date.localeCompare(y.date))
}

/* ---------- profil ---------- */
export function mergeProfile(a: Profile | null, b: Profile | null): Profile | null {
  if (!a) return b
  if (!b) return a
  // nova, prazna naprava ne sme prepisati pravega profila, tudi če je njen privzeti profil »novejši«
  const da = !!(a.onboardingDone || a.name), db = !!(b.onboardingDone || b.name)
  if (da !== db) return da ? a : b
  return newer(a, b, tm(a.updatedAt), tm(b.updatedAt))
}

/* ---------- nastavitve ---------- */
function mergeCoach(base: Settings, other: Settings): Settings['coach'] {
  const bc = base.coach, oc = other.coach
  if ('coach' in base && (bc == null || !bc.msgs?.length)) return bc ?? null      // nov pogovor na novejši napravi velja
  if (!bc) return oc ?? null
  if (!oc?.msgs?.length) return bc
  const key = (m: CoachMsg) => `${m.role}|${m.at}`
  const have = new Set(bc.msgs.map(key))
  const from = bc.msgs[0]?.at || ''                                                 // starejše je že v povzetku
  const extra = oc.msgs.filter(m => m && m.at >= from && !have.has(key(m)))
  if (!extra.length) return bc
  return { ...bc, msgs: [...bc.msgs, ...extra].sort((x, y) => x.at.localeCompare(y.at) || (x.role === y.role ? 0 : x.role === 'user' ? -1 : 1)) }
}
function pickAt<T extends { at: string }>(base: Settings, other: Settings, k: 'menu' | 'athleteProfile'): T | null | undefined {
  const x = base[k] as T | null | undefined, y = other[k] as T | null | undefined
  if (x && y) return newer(x, y, tm(x.at), tm(y.at))
  return k in base ? x : y
}
export function mergeSettings(a: Settings | null, b: Settings | null, tomb: Tomb): Settings | null {
  if (!a) return b
  if (!b) return a
  const base = newer(a, b, tm(a.updatedAt), tm(b.updatedAt)), other = base === a ? b : a
  const out: Settings = { ...base }
  if (!out.intervals && other.intervals && !tm(base.updatedAt)) out.intervals = other.intervals
  if (a.tests || b.tests) {
    const t = new Map<string, TestEntry>()
    for (const x of [...(a.tests || []), ...(b.tests || [])]) {
      if (!x || !x.id || tomb[tombTest(x.id)]) continue
      const e = t.get(x.id); t.set(x.id, e ? newer(e, x, 0, 0) : x)
    }
    out.tests = [...t.values()].sort((x, y) => x.date.localeCompare(y.date) || x.id.localeCompare(y.id))
  }
  if (a.monthReviews || b.monthReviews) {
    const r: NonNullable<Settings['monthReviews']> = { ...(other.monthReviews || {}) }
    for (const [k, v] of Object.entries(base.monthReviews || {})) { const e = r[k]; r[k] = e ? newer(e, v, tm(e.at), tm(v.at)) : v }
    out.monthReviews = r
  }
  const menu = pickAt<NonNullable<Settings['menu']>>(base, other, 'menu')
  if (menu !== undefined) out.menu = menu
  const ap = pickAt<NonNullable<Settings['athleteProfile']>>(base, other, 'athleteProfile')
  if (ap !== undefined) out.athleteProfile = ap
  const coach = mergeCoach(base, other)
  if (coach !== undefined && (coach !== null || 'coach' in base || 'coach' in other)) out.coach = coach
  return out
}

/* ---------- vse skupaj ---------- */
export function mergeState(a: SyncState, b: SyncState, now: number): SyncState {
  const tomb = mergeTomb(a.tomb, b.tomb, now)
  const acts = mergeActivities(a.activities, b.activities, tomb, now)
  return {
    profile: mergeProfile(a.profile, b.profile),
    settings: mergeSettings(a.settings, b.settings, tomb),
    activities: acts.list,
    plan: mergePlan(a.plan, b.plan, acts.remap),
    meals: mergeMeals(a.meals, b.meals, tomb),
    checkins: mergeCheckins(a.checkins, b.checkins),
    tomb,
  }
}
