#!/usr/bin/env node
/**
 * Objava FORMAI v2 na GitHub Pages, v podmapo repozitorija forma-app.
 *
 *   node scripts/deploy.mjs            → objavi na formai.si/v2/  (privzeto, varno ob živi stari aplikaciji)
 *   node scripts/deploy.mjs --root     → objavi v koren formai.si  (ZAMENJA staro aplikacijo — samo namerno)
 *
 * Ne dela commita in ne potiska sam: to naredi klicatelj, da je korak objave viden in preklicljiv.
 */
import { execSync } from 'node:child_process'
import { cpSync, existsSync, mkdirSync, rmSync, readdirSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const here = dirname(fileURLToPath(import.meta.url))
const appDir = resolve(here, '..')
const pagesRepo = resolve(appDir, '..', 'forma-app')
const toRoot = process.argv.includes('--root')
const base = toRoot ? '/' : '/v2/'
const outDir = toRoot ? pagesRepo : join(pagesRepo, 'v2')

if (!existsSync(join(pagesRepo, '.git'))) {
  console.error('Ne najdem repozitorija GitHub Pages:', pagesRepo)
  process.exit(1)
}

console.log(`Gradim z base="${base}" …`)
execSync('npx vite build', { cwd: appDir, stdio: 'inherit', env: { ...process.env, BASE_PATH: base } })

const dist = join(appDir, 'dist')
if (!existsSync(dist)) { console.error('Build ni ustvaril dist/'); process.exit(1) }

if (toRoot) {
  console.error('\nObjava v koren bi prepisala živo aplikacijo (index.html, forma-trener.html, kalorije.html).')
  console.error('To je namerno onemogočeno v skripti. Naredi ročno, ko bo v2 dosegla parnost.')
  process.exit(2)
}

// Podmapa /v2: pobriši staro vsebino, prekopiraj novo.
if (existsSync(outDir)) rmSync(outDir, { recursive: true, force: true })
mkdirSync(outDir, { recursive: true })
cpSync(dist, outDir, { recursive: true })

const files = readdirSync(outDir)
console.log(`\nObjavljeno v ${outDir}`)
console.log(`Datotek: ${files.length} — ${files.slice(0, 8).join(', ')}${files.length > 8 ? ' …' : ''}`)
console.log('\nNaslednji korak: commit + push v repozitoriju forma-app → https://formai.si/v2/')
